# Accessibility Delta — Atlas Design System v7 → v8 Accessibility Pass

This archive applies the first deep accessibility upgrade to the PolicyOS Atlas design system.

## Standards baseline

- WCAG 2.2 AA as the product UI target.
- WAI-ARIA Authoring Practices Guide for custom widget semantics and keyboard behavior.
- VPAT/ACR evidence readiness for future Section 508 / EN 301 549 procurement contexts.

## Modified foundations

- `colors_and_type.css`
- `landing/colors_and_type.css`

Changes:

- Added focus, target-size, hit-area, high-contrast, forced-colors, reduced-transparency, and skip-link utilities.
- Added dark/high-contrast overrides for focus and primary action tokens.
- Added `--surface-gradient-start` and `--surface-gradient-end` tokens used by the dashboard shell.
- Changed primary button gradient to `#115e57 → #0f635d` so warm-white button text passes AA contrast on both endpoints.
- Marked vibrant colors as chart/decorative colors, not normal text colors.

## Modified dashboard prototype

- `ui_kits/dashboard/index.html`
- `ui_kits/dashboard/Components.jsx`
- `ui_kits/dashboard/Sidebar.jsx`
- Multiple dashboard screen modules under `ui_kits/dashboard/*.jsx`

Changes:

- Loaded shared design-system CSS into the dashboard prototype.
- Added skip link and named `main` landmark.
- Added screen metadata, document title updates, and focus routing on screen change.
- Split duplicate `evidence` route into `evidence_fabric` and `evidence_synthesis`.
- Converted clickable cards to `InteractiveCard`, a native button-backed primitive.
- Added keyboard support and accessible names to interactive SVG graph nodes.
- Added `aria-expanded` / `aria-controls` to collapsible reasoning steps.
- Added explicit `type="button"` on dashboard and prototype buttons.
- Replaced sidebar semantic glyphs with the approved 10 Atlas radicals only.

## Modified landing/design prototypes

- `landing/auth.html`
- `landing/design-canvas.jsx`
- `preview/*.html` and `landing/*.html` button type cleanup

Changes:

- Added explicit labels/IDs/autocomplete to auth, signup, and checkout inputs.
- Converted visual checkbox rows to real checkbox inputs with accessible labels.
- Added accessible password visibility control label.
- Added keyboard/dialog semantics to the design-canvas focus overlay.
- Added accessible names and target sizes to design-canvas navigation dots and buttons.

## Added evidence and process files

- `accessibility/README.md`
- `accessibility/wcag-2.2-aa-matrix.md`
- `accessibility/keyboard-interaction-matrix.md`
- `accessibility/component-a11y-contract.md`
- `accessibility/vpat-acr-readiness.md`
- `accessibility/release-checklist.md`
- `accessibility/contrast-audit.md`
- `accessibility/audit-results.md`
- `tokens/accessibility.tokens.json`
- `scripts/a11y_contrast_audit.py`
- `scripts/a11y_static_lint.py`

## Current audit result

- Static heuristic blockers: 0
- Static heuristic warnings: 0
- Token contrast: normal text semantic pairs pass; vibrant chart pairs are restricted for normal text.

## Not a formal certification

This pass adds design-system evidence and reduces known accessibility debt. It is not a completed third-party audit, VPAT, or legal conformance claim. A formal release still requires browser-level automated testing, manual keyboard testing, screen-reader testing, and flow-level validation with real product data.
