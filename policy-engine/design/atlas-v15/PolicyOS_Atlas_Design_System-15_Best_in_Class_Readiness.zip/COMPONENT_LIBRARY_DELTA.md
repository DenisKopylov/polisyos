# v10 Component Library Delta

This release converts Atlas from a prototype UI kit into a production component library layer.

## Added

- `packages/atlas-ui` React package with typed TSX source.
- Token-only `atlas-ui.css` component stylesheet.
- Public exports for foundational primitives, forms, feedback, data display and PolicyOS governance patterns.
- `component-library/component-manifest.json` with maturity, owner, Storybook coverage, token dependencies, states and accessibility contracts.
- `component-library/components/*.md` docs with usage, style, code, accessibility, content and state guidance.
- Storybook-ready stories for foundations, forms, feedback/data, navigation/overlays and PolicyOS governance, plus `.storybook` configuration with a11y addon wiring.
- `scripts/component_build.py` and `scripts/component_lint.py` quality gates, including source/docs/export/story/build-artifact validation.
- `dist/atlas-ui` build mirror for consumers.

## Design-system governance change

`ui_kits/dashboard/Components.jsx` remains only as a static prototype compatibility shim. New production surfaces should consume `@policyos/atlas-ui`.

## Current status

- Stable: Button, Badge, Panel, Card, MetricCard, RunCard, form primitives including TextArea, Toast, EmptyState, Skeleton, GovernanceGate.
- Beta: Tabs, Dialog, DataTable.
- Backlog: combobox, tooltip, popover, menu, data-grid sorting/selection, chart primitives, focus-return trap for app-level dialogs.

## Testing and verification scaffolding

- Added `component-library/testing-strategy.md` for static, runtime and Storybook accessibility verification.
- Added `packages/atlas-ui/vitest.config.ts`, `packages/atlas-ui/tests/setup.ts` and `packages/atlas-ui/tests/component-contract.test.tsx` as the starter contract-test suite.
- Added package scripts for Storybook, component tests and Storybook a11y tests. These require installing the package dev dependencies in a product workspace.

## v10 hardening pass

- Added `TextArea` as a manifest-tracked component rather than an untracked form export.
- Added full story coverage metadata to the component manifest and lint gate.
- Hardened Dialog with Escape dismiss, focus trap and focus return.
- Hardened Tabs roving-focus keyboard behavior.
- Hardened Badge, Checkbox, GovernanceGate and DataTable accessibility contracts.
