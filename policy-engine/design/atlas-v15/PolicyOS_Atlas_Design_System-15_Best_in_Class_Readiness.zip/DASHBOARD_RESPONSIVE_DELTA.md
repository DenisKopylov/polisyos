# v13 Dashboard Responsive Model Delta

## Goal

Close best-in-class gap 6: **Dashboard responsive model пока не production-level**.

## Added / changed

- Added a canonical dashboard responsive manifest with five window classes: `compact`, `medium`, `expanded`, `large` and `extra-large`.
- Added responsive acceptance criteria for every window class, including navigation behavior, content columns, touch target expectations, data density and scroll containment.
- Added generated mirrors for product consumers:
  - `packages/atlas-ui/dashboard-responsive.json`
  - `dist/dashboard-responsive/responsive-manifest.json`
  - `dist/atlas-ui/dashboard-responsive.json`
  - `packages/atlas-ui/src/dashboard-responsive-contracts.ts`
- Migrated the runtime dashboard away from desktop-only inline shell sizing into class-based responsive layout hooks.
- Added a controlled compact/medium drawer contract with `aria-controls`, `aria-expanded`, Escape close, backdrop close, route-change close and body scroll locking.
- Added compact bottom navigation for primary operator destinations.
- Added desktop full rail and expanded icon-rail behavior with persistent accessible names and `aria-current`.
- Added responsive shell/grid/scroll/pane CSS selectors to `packages/atlas-ui/src/atlas-ui.css` and runtime dashboard CSS.
- Added typed dashboard primitives: `DashboardShell`, `DashboardSidebar`, `DashboardTopBar`, `ResponsiveGrid` and `ScrollRegion`.
- Added responsive docs under `dashboard-responsive/` and component-level docs under `component-library/components/`.
- Preserved `DataTable` responsive contracts for `responsiveMode="scroll|cards"`, `density`, `mobileLabel` and `priority`.
- Added `scripts/dashboard_responsive_build.py` and `scripts/dashboard_responsive_lint.py`, then wired both into `npm run verify:full`.

## Release evidence

- `dashboard-responsive/build-evidence.md`
- `dashboard-responsive/audit-results.md`
- `component-library/dashboard-responsive/dashboard-responsive-audit.md`
- `dist/verification/dashboard-responsive-audit.md`
- `dist/verification/verification-report.md`

## Gate summary

- Window classes: **5**
- Layout patterns: **5**
- Acceptance criteria: **18**
- Responsive lint blockers: **0**
- Responsive lint warnings: **0**

## Remaining hardening

Browser-level Playwright viewport snapshots and manual assistive-technology evidence are the next layer. This ZIP provides the architecture, tokens, docs, source hooks, generated contracts and static gates needed to add browser evidence without redesigning the responsive model.
