
# Atlas v14 Data Visualization Delta

## Scope

v14 formalizes data visualization as a production design-system layer. Charts are now governed by chart grammar, tokens, component APIs, state matrices, accessibility rules and release gates.

## Added

- `data-visualization/` documentation and `data-viz-manifest.json`.
- data-visualization tokens in `tokens/source/component.tokens.json` plus dark/high-contrast/preferred-contrast mode coverage.
- 14 React components: `ChartFrame`, `ChartLegend`, `ChartTooltip`, `ChartDataTable`, `DataVizTable`, `Sparkline`, `LineChart`, `BarChart`, `UncertaintyBand`, `Heatmap`, `CausalGraph`, `ProvenanceGraph`, `ProvenanceMap`, `ChartAnnotation`.
- Storybook-ready `DataVisualization.stories.tsx` and a package example.
- State matrix entries and component docs for every new data-viz component.
- `scripts/data_viz_build.py` and `scripts/data_viz_lint.py`.

## Quality bar

A visualization is production-ready only when it includes a text summary, exact-value table or linked data alternative, source/caption context, no color-only semantics, high-contrast behavior and export/print durability.
