# Atlas v12 Forms and Data Entry Delta

This release closes the weak forms/data-entry coverage identified in the best-in-class design-system review. Atlas now treats form flows as a governed product layer with native semantics, validation recovery, state matrices, token-only styling and PolicyOS-specific guidance.

## Added public components

### Form structure

- `Form`
- `FormSection`
- `FieldGroup`
- `ValidationSummary`

### Choice and selection

- `RadioGroup`
- `CheckboxGroup`
- `Combobox`
- `TokenInput`

### Text, search and secrets

- `SearchField`
- `PasswordField`
- `SecretField`
- `CharacterCount`

### Bounded values and evidence intake

- `NumberField`
- `RangeField`
- `DateField`
- `DateRangeField`
- `FileUpload`

## Design-system changes

- Added `component-library/forms/` with principles, validation pattern, field anatomy, autocomplete guidance, PolicyOS data-entry patterns and migration checklist.
- Added per-component docs in `component-library/components/*.md`.
- Added per-component state matrix docs in `component-library/state-matrix/components/*.md`.
- Expanded `component-library/component-manifest.json` from 18 to 35 governed package components.
- Expanded canonical state matrix coverage from 176 states in v11 to 317 states in v12.
- Added `packages/atlas-ui/stories/DataEntry.stories.tsx` with a full evidence/governance form example.
- Added runtime state hooks and token-only CSS for form sections, validation summaries, choice groups, input adornments, file upload, tokens and combobox popups.

## Token changes

New component tokens include:

- `--atlas-form-section-surface`
- `--atlas-form-section-border`
- `--atlas-validation-summary-surface`
- `--atlas-validation-summary-border`
- `--atlas-validation-summary-link`
- `--atlas-input-addon-surface`
- `--atlas-file-upload-surface`
- `--atlas-file-upload-border`
- `--atlas-token-surface`
- `--atlas-token-border`
- `--atlas-combobox-surface`
- `--atlas-combobox-border`
- `--atlas-combobox-shadow`

## Accessibility contract

- Labels and legends are required for all input-producing components.
- Helper and error text are connected with `aria-describedby`.
- Invalid states expose `aria-invalid` where the component owns a native control.
- `ValidationSummary` uses `role="alert"`, programmatic focus support and links to invalid controls.
- `PasswordField` and `SecretField` reveal controls expose `aria-pressed` and accessible names.
- `Combobox` exposes `role="combobox"`, `aria-expanded`, `aria-controls`, `aria-activedescendant` and a `listbox` popup.
- High-contrast/forced-colors and density modes are covered in every new state matrix.

## Verification

Final generated evidence for this release:

- Token schema lint: 0 blockers / 0 findings.
- Token static lint: 0 core raw-color findings; legacy baseline unchanged at 1,933 findings.
- Component lint: 35 components / 35 required / 0 blockers / 0 warnings.
- State matrix lint: 35 components / 317 supported states / 53 rejected states / 0 blockers / 0 warnings.
- Accessibility static lint: 0 blockers / 0 warnings.
- Verification report: all required artifacts and evidence present.

## Remaining best-in-class work

This release provides architecture, source, docs, stories and static gates. The next hardening layer should add browser-level Playwright + axe coverage, Storybook visual regression snapshots and real assistive-technology test evidence for the composite components, especially `Combobox`, `TokenInput` and `DateRangeField`.
