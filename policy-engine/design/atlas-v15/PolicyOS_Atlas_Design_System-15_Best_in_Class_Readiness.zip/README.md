
# PolicyOS Atlas Design System

Atlas is the PolicyOS design-system package. Current layers include accessibility, design tokens, production component library, component state matrix, forms/data-entry, responsive dashboard and formal data visualization.

## Current release

`15.0.0-accessibility-modes`

## Verification

```bash
npm run verify
```

For source changes, run the specific gates listed in `dist/verification/verification-report.md`.

Core artifacts live in `tokens/`, `component-library/`, `dashboard-responsive/`, `data-visualization/`, `packages/atlas-ui/` and `dist/`.


## v15 Theming Accessibility Modes

Atlas now includes a formal theming/accessibility-modes layer: forced colors, high contrast, automatic dark mode, reduced motion, reduced transparency, large text, color-safe encodings, density and print/export contracts. See `theming/README.md` and `THEMING_ACCESSIBILITY_MODES_DELTA.md`.


## Best-in-class readiness overlay

This archive now includes a non-runtime readiness layer for governance, internationalization, Figma parity, content design, security/privacy UX, product-flow patterns and archive-level release consistency. These artifacts do not replace browser, product-code or assistive-technology validation; they make those later checks easier to run and harder to scope incorrectly.

Start with:

- `BEST_IN_CLASS_READINESS.md`
- `best-in-class/readiness-matrix.md`
- `best-in-class/evidence-index.md`
- `governance/README.md`
- `internationalization/README.md`
- `figma/README.md`
- `content-design/README.md`
- `security-privacy-ux/README.md`
- `product-patterns/README.md`

Archive-only gates:

```bash
npm run release:lint
npm run readiness:lint
```
