---
name: polisyos-atlas-design
description: Use this skill to generate well-branded interfaces and assets for PolicyOS Atlas (PolisyOS), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping the Atlas Control Room dashboard.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

Key files to read first:
- README.md — full design system guide, visual foundations, content fundamentals, iconography
- colors_and_type.css — all CSS custom properties (drop into any HTML prototype)
- assets/ — logos, Janus medallion, all 10 glyph SVGs
- ui_kits/dashboard/index.html — interactive hi-fi prototype of Atlas Control Room

Design system essentials:
- Fonts: Manrope (sans, headings/body), IBM Plex Mono (labels/eyebrows), Instrument Serif italic (citations only)
- Colors: paper #fbf8f2 · sand #f4efe6 · ink #17191d · graphite #28333c · slate #40515f
- Signal: teal #115e57 (ok/approved) · ember #92391d (blocked/fail) · gold #6c5111 (pending/warn)
- Vibrant (charts/decoration): teal-vibrant #1c8b82 · ember-vibrant #cb5a2e · gold-vibrant #b58b2b
- Radii: pill 999px · card 22px · panel 28px · shell 38px
- Background: warm sandstone with radial teal/ember glows; graphite sidebar
- Glyphs: 10 bespoke radicals — intervention⊙ evidence▲ provenance⟿ transport⇄ counterfactual⋌ identifiability≔ reproducibility⟳ governance-pass⊡ blocker⊘ freshness◷
- No emoji. No third-party icon libraries for domain concepts.
- Tone: analytical, operator-grade, sentence case, no marketing fluff

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.
