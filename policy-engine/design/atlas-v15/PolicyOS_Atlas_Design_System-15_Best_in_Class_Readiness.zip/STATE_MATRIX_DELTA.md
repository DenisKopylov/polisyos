# Atlas v11 State Matrix Delta

Generated: `2026-06-08T19:47:48Z`

## What changed

v11 turns component states from short prose lists into a production state contract:

- Added global state taxonomy and precedence rules.
- Added per-component machine-readable state matrices for all 18 package components.
- Added generated per-component state docs under `component-library/state-matrix/components/`.
- Added package-level `state-matrix.json` and `state-taxonomy.json` exports.
- Added `scripts/state_matrix_lint.py` and wired it into root verification.
- Added token-only CSS selectors for canonical state hooks such as `data-state`, `aria-pressed`, `aria-invalid`, `:focus-visible`, `:hover`, `:disabled`, forced-colors and reduced-motion.
- Extended component source to expose stable `data-state` / `data-status` hooks where useful.
- Added Checkbox `indeterminate` support with DOM mixed state and `aria-checked="mixed"`.
- Added `StateMatrix.stories.tsx` as a Storybook-ready state grid.

## Why it matters

A best-in-class design system treats states as a contract, not screenshots. Each state now has:

- trigger;
- visual contract;
- DOM / ARIA contract;
- token dependencies;
- keyboard behavior;
- combination rules;
- acceptance criteria;
- test evidence;
- explicit rejected states.

## New commands

```bash
npm run state:lint
npm run components:lint
npm run verify
```
