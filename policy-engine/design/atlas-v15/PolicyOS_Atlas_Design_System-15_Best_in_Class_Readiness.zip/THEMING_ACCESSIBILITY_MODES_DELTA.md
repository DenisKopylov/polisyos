# Atlas v15 Theming Accessibility Modes Delta

Version: `15.0.0-accessibility-modes`

## Added

- `theming/` contract layer with mode manifest, resolution docs, testing contract and migration checklist.
- New source tokens: `tokens/source/theme.tokens.json`.
- New mode files: forced colors, auto dark, reduced motion, manual reduced transparency, large text, color-safe and print/export.
- New package components: `ThemeProvider`, `ThemeToggle`, `AccessibilityModePanel`.
- New package exports: `@policyos/atlas-ui/theming`, `theme-manifest`, `theme-modes`, `theme-contracts`.
- New scripts: `scripts/theming_build.py`, `scripts/theming_lint.py`.
- Dashboard prototype controls for theme, density, motion, transparency, text scale and color-safe mode.

## Contract

Atlas now treats accessibility modes as independent axes: color scheme, contrast, forced colors, motion, transparency, density, text scale, color-safe and print/export. The root attributes are standardized as `data-atlas-*` attributes with legacy `data-theme`/`data-density` compatibility.

## Verification

Run `npm run verify:full` to rebuild and verify token, component, state, responsive, data-viz, theming and accessibility evidence.
