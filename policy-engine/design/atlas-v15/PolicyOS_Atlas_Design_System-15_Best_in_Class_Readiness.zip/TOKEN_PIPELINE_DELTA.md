# Token pipeline delta — v9

This pass upgrades Atlas from manually maintained CSS custom properties to a reproducible token pipeline.

## Added

- `tokens/source/primitive.tokens.json` — DTCG-style primitive source of truth.
- `tokens/source/semantic.tokens.json` — product meaning and aliases.
- `tokens/source/component.tokens.json` — component-scoped API tokens for Button, Badge, Panel, MetricCard, RunCard and Sidebar rail.
- `tokens/modes/*.tokens.json` — dark, high contrast, prefers-contrast, reduced-transparency and density mode overrides.
- `scripts/token_build.py` — dependency-free generator for CSS, TypeScript, Tailwind, Figma handoff, manifest and audit.
- `scripts/token_schema_lint.py`, `scripts/token_static_lint.py`, `scripts/token_lint.py` — dependency-free schema, alias, artifact and hard-coded visual value gates with a legacy baseline.
- `tokens/generated/*` and `dist/tokens/*` — generated consumer artifacts.
- `tokens/README.md` and `tokens/token-contract.md` — operating documentation.

## Changed

- `colors_and_type.css` and `landing/colors_and_type.css` are now generated from token source files.
- Runtime dashboard JSX (`ui_kits/dashboard/*.jsx` plus `index.html`) was migrated away from hard-coded `#hex` / raw `rgba()` values to CSS variables, RGB channel tokens and component tokens.
- Shared primitives now consume component tokens: `--atlas-button-*`, `--atlas-badge-*`, `--atlas-panel-*`, `--atlas-metric-*`, `--atlas-rail-*`.
- `tokens/accessibility.tokens.json` is now a compatibility pointer; accessibility primitives live in `tokens/source/primitive.tokens.json`.

## Verification

- `python3 scripts/token_build.py` generated **188 root CSS variables** and **102 mode override variables**.
- `python3 scripts/token_lint.py` completed with **PASS**: token schema lint has **0 blockers / 0 findings**; static drift lint has **0 core findings** and a tracked legacy/prototype baseline of **1,933** findings in `tokens/hardcoded-baseline.json`.
- `python3 scripts/a11y_static_lint.py` completed with **0 blockers / 0 warnings**.
- `python3 scripts/a11y_contrast_audit.py` regenerated the contrast report.

## Scope note

The shared runtime dashboard shell and primitives are tokenized and guarded against hard-coded color drift. Historical static landing/preview prototypes still contain inline design exploration styles; they now consume generated token CSS and are tracked as a separate migration surface whose baseline must only decrease.
