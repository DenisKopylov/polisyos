# Atlas Accessibility Contract

Atlas accessibility is treated as a product contract, not a visual afterthought. This package establishes the first production-grade accessibility layer for the design system and dashboard prototype.

## Target baseline

- **WCAG target:** WCAG 2.2 AA for product surfaces, with AAA-compatible choices when they do not reduce operator density.
- **Keyboard target:** every interactive component must be reachable, operable, and visibly focused by keyboard.
- **Assistive technology target:** components expose role, name, value, state, and status changes in a way that screen readers can understand.
- **Government/enterprise readiness:** design evidence should be traceable to VPAT/ACR sections for WCAG, Section 508, and EN 301 549.

## What changed in this pass

1. Added accessible focus, target-size, forced-colors, high-contrast, reduced-motion, and reduced-transparency tokens to `colors_and_type.css`.
2. Improved primary action contrast by replacing the lighter button gradient with a darker AA-safe teal range.
3. Added `.sr-only`, `.skip-link`, `.atlas-click-target`, and preference-aware CSS utilities.
4. Converted dashboard clickable cards from non-semantic `div onClick` patterns to native button-backed `InteractiveCard` patterns.
5. Added keyboard semantics to SVG graph nodes where a native HTML button cannot be used.
6. Added a dashboard skip link, main landmark, screen labels, focus routing, and unique navigation IDs.
7. Added explicit labels, IDs, autocomplete hints, and real checkbox inputs in the auth/checkout artboard.
8. Added contrast and static accessibility audit scripts under `scripts/`.

## Accessibility design principles

### 1. Native before ARIA

Use native HTML controls whenever possible: `button`, `a`, `input`, `select`, `textarea`, `dialog`, `summary/details`. Use ARIA only when native semantics cannot express the interaction, such as an interactive SVG map node.

### 2. Focus is a visible brand asset

Atlas focus is not a browser accident. It is a first-class design token using a high-contrast teal ring plus offset. Focus must remain visible on glass, graphite, paper, dark mode, and forced-colors mode.

### 3. Color never carries meaning alone

Teal/ember/gold are semantic signals, but every status also needs text, shape, glyph, label, or pattern. Charts need a table equivalent and a textual summary.

### 4. Density is not an excuse

Operator UIs can be dense while preserving keyboard order, minimum target size, readable contrast, and screen-reader names. Compact density can reduce padding, but must not erase focus or state.

### 5. Evidence must be testable

Every component needs a small evidence trail: contrast result, keyboard interaction, screen-reader name/state, known exceptions, and test coverage.

## Directory map

```
accessibility/
  README.md                         This contract
  wcag-2.2-aa-matrix.md             WCAG-oriented acceptance matrix
  keyboard-interaction-matrix.md    Keyboard behavior by component class
  component-a11y-contract.md        Required component documentation fields
  contrast-audit.md                 Generated contrast results
  vpat-acr-readiness.md             VPAT/ACR evidence map
  release-checklist.md              Accessibility release gate checklist
  audit-results.md                  Generated static audit results

scripts/
  a11y_contrast_audit.py            Token contrast checker
  a11y_static_lint.py               Static heuristics for dashboard/landing code

tokens/
  accessibility.tokens.json         Accessibility token source draft
```

## References

- WCAG 2.2: https://www.w3.org/TR/WCAG22/
- WAI-ARIA Authoring Practices Guide: https://www.w3.org/WAI/ARIA/apg/
- VPAT: https://www.itic.org/policy/accessibility/vpat
- Section 508 accessibility conformance reporting: https://www.section508.gov/sell/acr/
