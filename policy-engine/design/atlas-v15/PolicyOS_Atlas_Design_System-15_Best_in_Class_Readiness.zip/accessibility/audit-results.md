# Atlas Static Accessibility Lint

Generated: `2026-06-09T17:33:15Z`

This heuristic scan catches common accessibility regressions in the static prototype package. It should be paired with browser-level axe/Playwright checks and manual assistive-technology testing.

- Blockers: **0**
- Warnings: **0**

No findings for the configured static heuristics.
