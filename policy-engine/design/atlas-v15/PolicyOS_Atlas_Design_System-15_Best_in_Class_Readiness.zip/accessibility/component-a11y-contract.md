# Component Accessibility Contract

Every Atlas component should document the following fields before it is promoted to stable.

## Required documentation fields

| Field | Description |
|---|---|
| Role | Native element or ARIA role used by the component. |
| Name | How the accessible name is computed. |
| Value/state | `aria-pressed`, `aria-selected`, `aria-expanded`, `checked`, `disabled`, validation state, busy state. |
| Keyboard | Supported keys and focus order. |
| Focus | Focus-ring placement, focus return, and focus containment if applicable. |
| Pointer target | Minimum target dimensions in default and compact density. |
| Contrast | Required text and non-text color pairs. |
| Motion | Motion behavior and reduced-motion fallback. |
| Screen reader notes | Announcements, live region behavior, descriptive text, chart summaries. |
| Error behavior | Inline error, validation summary, and recovery path. |
| Do / do not | Correct and incorrect usage. |
| Test evidence | Unit, interaction, axe, visual regression, and manual AT checks. |

## Component maturity levels

| Level | Criteria |
|---|---|
| Experimental | Visual concept only. May be inaccessible. Must not ship in production. |
| Beta | Has semantic element choice, keyboard behavior, labels, and contrast review. |
| Stable | Has full docs, tests, WCAG mapping, keyboard/AT evidence, and migration notes. |
| Deprecated | Has removal timeline and accessible replacement. |

## Stable component minimum

A stable Atlas component must satisfy:

1. No known keyboard blockers.
2. No color-pair failures for intended text use.
3. Explicit accessible name for icon-only or non-text controls.
4. Reduced-motion-safe behavior.
5. High-contrast/forced-colors fallback.
6. State matrix for default, hover, focus-visible, active, disabled, loading, selected, error, and busy states as applicable.
