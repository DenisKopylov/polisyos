# Atlas Contrast Audit

Generated: `2026-06-08T19:05:02Z`

This audit covers high-risk token pairs used for text and controls. It does not replace a full screenshot-based audit of every component state.

| Pair | Foreground | Background | Intended use | Ratio | Required | Status | Notes |
|---|---:|---:|---|---:|---:|---|---|
| primary text on paper | `#17191d` | `#fbf8f2` | normal text | 16.60:1 | 4.5:1 | PASS |  |
| secondary slate text on paper | `#40515f` | `#fbf8f2` | normal text | 7.74:1 | 4.5:1 | PASS |  |
| muted graphite on sand | `#40515f` | `#f4efe6` | normal text | 7.16:1 | 4.5:1 | PASS |  |
| teal semantic text on paper | `#115e57` | `#fbf8f2` | normal text | 7.17:1 | 4.5:1 | PASS |  |
| ember semantic text on paper | `#92391d` | `#fbf8f2` | normal text | 7.01:1 | 4.5:1 | PASS |  |
| gold semantic text on paper | `#6c5111` | `#fbf8f2` | normal text | 7.02:1 | 4.5:1 | PASS |  |
| primary button text on start | `#fff9f1` | `#115e57` | button text | 7.27:1 | 4.5:1 | PASS |  |
| primary button text on end | `#fff9f1` | `#0f635d` | button text | 6.77:1 | 4.5:1 | PASS |  |
| dark sidebar text | `#fff9f0` | `#17191d` | normal text | 16.81:1 | 4.5:1 | PASS |  |
| dark theme primary text | `#eef5ff` | `#16202b` | normal text | 15.00:1 | 4.5:1 | PASS |  |
| dark theme slate text | `#a1b3c8` | `#16202b` | normal text | 7.68:1 | 4.5:1 | PASS |  |
| dark theme teal text | `#5fd3ca` | `#16202b` | normal text | 9.14:1 | 4.5:1 | PASS |  |
| vibrant teal on paper | `#1c8b82` | `#fbf8f2` | decorative/chart or large text only | 3.91:1 | 4.5:1 | RESTRICT | Use semantic teal for normal text. |
| vibrant ember on paper | `#cb5a2e` | `#fbf8f2` | decorative/chart or large text only | 3.93:1 | 4.5:1 | RESTRICT | Use semantic ember for normal text. |
| vibrant gold on paper | `#b58b2b` | `#fbf8f2` | decorative/chart or large text only | 2.96:1 | 4.5:1 | RESTRICT | Use semantic gold for normal text. |

## Interpretation

- `PASS` means the pair meets the listed threshold for the stated use.
- `RESTRICT` means the pair must not be used for normal body/UI text at that size. It can remain valid for charts, decoration, icons, fills, or large text where separately verified.
- Primary action contrast now passes against both ends of the button gradient.

Restricted pairs: 3

## JSON summary

```json
[
  {
    "name": "primary text on paper",
    "foreground": "#17191d",
    "background": "#fbf8f2",
    "ratio": 16.6,
    "required": 4.5,
    "status": "PASS",
    "intended_use": "normal text"
  },
  {
    "name": "secondary slate text on paper",
    "foreground": "#40515f",
    "background": "#fbf8f2",
    "ratio": 7.74,
    "required": 4.5,
    "status": "PASS",
    "intended_use": "normal text"
  },
  {
    "name": "muted graphite on sand",
    "foreground": "#40515f",
    "background": "#f4efe6",
    "ratio": 7.16,
    "required": 4.5,
    "status": "PASS",
    "intended_use": "normal text"
  },
  {
    "name": "teal semantic text on paper",
    "foreground": "#115e57",
    "background": "#fbf8f2",
    "ratio": 7.17,
    "required": 4.5,
    "status": "PASS",
    "intended_use": "normal text"
  },
  {
    "name": "ember semantic text on paper",
    "foreground": "#92391d",
    "background": "#fbf8f2",
    "ratio": 7.01,
    "required": 4.5,
    "status": "PASS",
    "intended_use": "normal text"
  },
  {
    "name": "gold semantic text on paper",
    "foreground": "#6c5111",
    "background": "#fbf8f2",
    "ratio": 7.02,
    "required": 4.5,
    "status": "PASS",
    "intended_use": "normal text"
  },
  {
    "name": "primary button text on start",
    "foreground": "#fff9f1",
    "background": "#115e57",
    "ratio": 7.27,
    "required": 4.5,
    "status": "PASS",
    "intended_use": "button text"
  },
  {
    "name": "primary button text on end",
    "foreground": "#fff9f1",
    "background": "#0f635d",
    "ratio": 6.77,
    "required": 4.5,
    "status": "PASS",
    "intended_use": "button text"
  },
  {
    "name": "dark sidebar text",
    "foreground": "#fff9f0",
    "background": "#17191d",
    "ratio": 16.81,
    "required": 4.5,
    "status": "PASS",
    "intended_use": "normal text"
  },
  {
    "name": "dark theme primary text",
    "foreground": "#eef5ff",
    "background": "#16202b",
    "ratio": 15.0,
    "required": 4.5,
    "status": "PASS",
    "intended_use": "normal text"
  },
  {
    "name": "dark theme slate text",
    "foreground": "#a1b3c8",
    "background": "#16202b",
    "ratio": 7.68,
    "required": 4.5,
    "status": "PASS",
    "intended_use": "normal text"
  },
  {
    "name": "dark theme teal text",
    "foreground": "#5fd3ca",
    "background": "#16202b",
    "ratio": 9.14,
    "required": 4.5,
    "status": "PASS",
    "intended_use": "normal text"
  },
  {
    "name": "vibrant teal on paper",
    "foreground": "#1c8b82",
    "background": "#fbf8f2",
    "ratio": 3.91,
    "required": 4.5,
    "status": "RESTRICT",
    "intended_use": "decorative/chart or large text only"
  },
  {
    "name": "vibrant ember on paper",
    "foreground": "#cb5a2e",
    "background": "#fbf8f2",
    "ratio": 3.93,
    "required": 4.5,
    "status": "RESTRICT",
    "intended_use": "decorative/chart or large text only"
  },
  {
    "name": "vibrant gold on paper",
    "foreground": "#b58b2b",
    "background": "#fbf8f2",
    "ratio": 2.96,
    "required": 4.5,
    "status": "RESTRICT",
    "intended_use": "decorative/chart or large text only"
  }
]
```

