# Keyboard Interaction Matrix

Atlas components follow native browser keyboard behavior whenever possible. Custom composites must explicitly document keyboard interaction.

| Component / pattern | Tab behavior | Enter | Space | Arrow keys | Escape | Notes |
|---|---|---|---|---|---|---|
| Button | Focuses in DOM order | Activates | Activates | N/A | N/A | Must include `type="button"` unless it submits a form. |
| Link | Focuses in DOM order | Opens/navigates | Scrolls page by browser default | N/A | N/A | Use links only for navigation, not commands. |
| InteractiveCard | Focuses once as a button | Activates card action | Activates card action | N/A | N/A | Use for run cards, evidence cards, selectable records. Do not nest buttons inside. |
| Checkbox | Focuses in DOM order | N/A | Toggles | N/A | N/A | Use real `input type="checkbox"`; visual box is decorative. |
| Radio group | First checked item or first item | N/A | Selects focused item | Moves/selects within group | N/A | Needed for future plan picker and segmented controls. |
| Tabs | Active tab in tab order | Activates | Activates | Left/right move tabs; home/end optional | N/A | Use APG tab pattern. |
| Sidebar navigation | Each nav item is a button | Changes screen | Changes screen | Future: up/down roving focus | N/A | Current prototype uses native button tab order. |
| SVG graph node | Focuses each node | Selects node | Selects node | Future: spatial movement | N/A | Requires `role="button"`, `tabIndex="0"`, `focusable="true"`, `aria-label`, and key handler. |
| Disclosure / accordion | Header button focuses | Expands/collapses | Expands/collapses | Optional up/down between headers | Optional close | Header needs `aria-expanded` + `aria-controls`. |
| Dialog / modal | Focus moves into dialog | Activates focused control | Activates focused control | N/A | Closes if dismissible | Must trap focus and restore focus to opener. Planned primitive. |
| Toast / status | Usually not focusable | N/A | N/A | N/A | N/A | Needs live-region announcement and persistent review path for errors. |
| Data table | Tab enters table controls only | Activates control | Activates control | Future: grid navigation only for interactive grids | N/A | Static tables should remain regular tables, not ARIA grids. |

## Prohibited patterns

- `div onClick` without native semantics.
- Icon-only controls without accessible names.
- Hover-only reveal of critical actions.
- Pointer-only graph interactions.
- Keyboard focus removed with `outline: none` and no replacement.
- Cards with nested interactive controls unless focus order and event bubbling are explicitly designed.
