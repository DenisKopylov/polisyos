# Accessibility Release Checklist

Use this checklist before marking a design-system release as stable.

## Automated checks

- [ ] `python3 scripts/a11y_contrast_audit.py` has no failures for intended text pairs.
- [ ] `python3 scripts/a11y_static_lint.py` has no blocking findings.
- [ ] Storybook/Playwright axe checks pass for stable components.
- [ ] Visual regression includes focus-visible states.
- [ ] Reduced-motion snapshots are covered for animated components.

## Manual keyboard checks

- [ ] Tab order follows reading/order-of-operation order.
- [ ] Every interactive control is reachable.
- [ ] Every focused control has a visible focus indicator.
- [ ] Enter/Space activate controls as expected.
- [ ] Escape behavior is defined for overlays.
- [ ] Focus returns to opener after dismissing overlays.
- [ ] No hover-only critical action.

## Manual screen-reader checks

- [ ] Page/screen title is meaningful.
- [ ] Landmarks are present and named.
- [ ] Controls have accessible names.
- [ ] Selected/current/expanded/pressed states are announced.
- [ ] Validation errors are associated with fields.
- [ ] Async status changes are announced.
- [ ] Charts have summaries and data-table alternatives.

## Design checks

- [ ] Text contrast meets WCAG AA for intended size.
- [ ] Non-text indicators meet 3:1 where they convey information.
- [ ] Color is not the only indicator.
- [ ] Target sizes meet 24px minimum and Atlas 44px preferred where practical.
- [ ] High-contrast/forced-colors mode remains usable.
- [ ] Reduced-transparency mode removes essential glass dependency.

## Documentation checks

- [ ] Component docs include role, name, state, keyboard, focus, contrast, and error behavior.
- [ ] Known exceptions are explicit and tracked.
- [ ] Migration notes are provided for breaking semantic changes.
