# VPAT / Accessibility Conformance Report Readiness

This file maps Atlas design-system evidence to the kind of artifacts needed for a future VPAT or Accessibility Conformance Report. It is not a completed VPAT.

## Target editions

- WCAG 2.2 AA evidence for web UI.
- Section 508 evidence for U.S. public-sector procurement contexts.
- EN 301 549 evidence for EU public-sector procurement contexts.

## Evidence inventory

| Evidence item | Location | Status |
|---|---|---|
| Token contrast report | `accessibility/contrast-audit.md` | Added |
| Static semantic lint report | `accessibility/audit-results.md` | Added |
| Keyboard behavior matrix | `accessibility/keyboard-interaction-matrix.md` | Added |
| Component accessibility contract | `accessibility/component-a11y-contract.md` | Added |
| WCAG acceptance matrix | `accessibility/wcag-2.2-aa-matrix.md` | Added |
| Component state matrices | Per component docs | Needed |
| Screen-reader test notes | Per release | Needed |
| Automated axe/Playwright reports | CI output | Needed |
| Manual keyboard traversal videos/notes | Release evidence | Needed |
| VPAT claims with remarks | Formal ACR | Needed after real audit |

## Claiming discipline

Do not claim conformance because the design system has accessible components. Conformance requires testing the implemented product flows, content, data states, browser combinations, and assistive technology combinations.

## Recommended audit sample for Atlas

1. Sign in and passkey/SSO fallback.
2. Scenario composer, including constraints and launch controls.
3. Run monitoring and failure triage.
4. Decision workspace and decision packet export.
5. Evidence fabric, lineage, and provenance certificate.
6. Fairness audit and dispute ledger.
7. Checkout/billing flow if shipped as product UI.
