# WCAG 2.2 AA Matrix

This matrix translates WCAG 2.2 AA into Atlas design-system acceptance criteria. It is not a formal audit; it is the working evidence model for the design system.

| Area | WCAG anchor | Atlas requirement | Current status | Evidence / next action |
|---|---:|---|---|---|
| Text contrast | 1.4.3 | Normal UI text must meet 4.5:1; large text 3:1. Vibrant chart colors are not allowed as normal text on paper without a darker semantic alias. | Improved | `contrast-audit.md`; primary button gradient moved to darker teal. |
| Non-text contrast | 1.4.11 | Focus rings, borders conveying state, glyphs, graph nodes, and control indicators must meet 3:1 against adjacent colors. | In progress | Added focus tokens and forced-colors fallback. Need full component audit. |
| Keyboard | 2.1.1 | Every interactive element must be operable with keyboard. Pointer-only cards are prohibited. | Improved | Dashboard cards converted to `InteractiveCard`; SVG graph nodes have Enter/Space support. |
| No keyboard trap | 2.1.2 | Composite widgets must define exit behavior and focus return. | Planned | Needed for future dialogs, drawers, command palette, popovers. |
| Focus visible | 2.4.7 | All focusable elements must display a visible, non-obscured focus indicator. | Improved | Global `:focus-visible`, `.skip-link`, `.atlas-click-target`. |
| Focus not obscured | 2.4.11 | Sticky headers, shells, drawers, and modals must not hide the focused element. | Planned | Added focus-routing baseline; needs viewport tests. |
| Page titles | 2.4.2 | Screen changes update the browser title in the prototype and production shell. | Improved | Dashboard updates title per selected screen. |
| Landmarks | 1.3.1 / 2.4.1 | App shell requires skip link, `nav`, and `main`; major panels should use section/article when meaningful. | Improved | Dashboard skip link + `main` landmark + `nav`. |
| Labels or instructions | 3.3.2 | Form controls must have explicit labels and clear helper/error text. | Improved | Auth/checkout artboard fields now have labels/IDs and autocomplete hints. |
| Accessible name | 4.1.2 | Icon buttons, cards, graph nodes, and chips need explicit names. | Improved | `aria-label` added to button-backed cards and SVG nodes. |
| Status messages | 4.1.3 | Async run launches, failures, copy-to-clipboard, sync status, and validation outcomes use live-region rules. | Planned | Add `Toast`, `InlineStatus`, and `LiveRegion` primitives. |
| Target size | 2.5.8 | Pointer targets should be at least 24px; Atlas default target is 44px where layout allows. | Improved | Added target-size tokens and click-target class. |
| Reduced motion | 2.2.2 / 2.3.3 | Motion must respect `prefers-reduced-motion`. | Improved | Global reduced-motion behavior exists; component motion specs still needed. |
| Accessible authentication | 3.3.8 | Authentication must not depend on cognitive puzzles; passkey/SSO flows need accessible alternatives. | In progress | Auth artboard now labels inputs; flow-level spec needed. |

## Release gate

A component cannot be marked **stable** until all applicable rows above are either passing or documented as intentionally not applicable.
