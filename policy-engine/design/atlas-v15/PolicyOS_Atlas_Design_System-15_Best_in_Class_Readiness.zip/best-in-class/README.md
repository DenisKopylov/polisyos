# Best-in-class readiness pack

This folder defines the archive-level standard for making Atlas closer to a best-in-class design system before product-code integration starts.

## Operating principle

A best-in-class design system is not just a token set or component package. It needs:

- durable governance;
- machine-readable contracts;
- accessibility and mode evidence;
- localization readiness;
- design-to-code parity;
- security/privacy UX rules;
- product-flow patterns;
- release consistency;
- anti-patterns that are actively rejected.

## Included artifacts

| File | Purpose |
|---|---|
| `readiness-matrix.md` | Area-by-area maturity matrix |
| `readiness-scorecard.json` | Machine-readable readiness scorecard |
| `evidence-index.md` | Where proof currently lives in the archive |
| `browser-and-at-evidence-plan.md` | Later runtime/manual validation plan |
| `anti-patterns.md` | No-go decisions and rejection criteria |
| `archive-hardening-checklist.md` | ZIP/package hygiene checklist |
| `component-roadmap.md` | Component maturity and next coverage targets |
| `zip-change-log.md` | What this overlay changed |

## Gate status

Archive-only readiness is validated by `scripts/best_in_class_lint.py`. Runtime readiness remains intentionally out of scope until product integration and browser test infrastructure are added.

