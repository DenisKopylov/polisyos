# Atlas no-go anti-patterns

These patterns are rejected in production Atlas surfaces.

| Anti-pattern | Why it is blocked | Preferred pattern | Evidence/gate |
|---|---|---|---|
| Raw hex/rgb colors in product UI | Breaks theming, contrast and mode consistency | Use semantic/component tokens | Token static lint |
| `div` or `span` as button | Breaks keyboard and semantics | Native `button` or governed Button | Static a11y lint + review |
| Hover-only actions | Invisible to keyboard/touch users | Persistent action or focus/touch equivalent | Component review |
| Color-only status | Fails color-safe and non-visual use | Add label, shape, icon, pattern or text | Data-viz/accessibility audit |
| Unlabeled icon button | Not announced by screen readers | `aria-label` or visible label | Static a11y lint |
| Modal without focus return | Causes keyboard trap/disorientation | Governed Dialog/AlertDialog contract | Runtime keyboard evidence |
| Table used as interactive grid | Creates wrong keyboard model | DataTable for read tables; DataGrid for grid behavior | Component governance |
| Chart without summary/table/source | Excludes non-visual and audit workflows | ChartFrame + ChartDataTable + source metadata | Data-viz lint |
| Disabled action without explanation | Users cannot recover | Disabled reason, permission state or request-access flow | Content/security UX review |
| Truncated legal/audit-critical text | Destroys auditability | Expand/copy/open full text | Content design review |
| Sensitive value copied silently | Leaks secrets or PII | Explicit reveal/copy with audit event | Security/privacy UX review |
| Directional CSS physical properties for layout | Breaks RTL | Logical properties and bidi-safe strings | I18n lint/review |
| Concatenated translated strings | Breaks grammar and localization | Full sentence templates with variables/plurals | Translation contract review |

