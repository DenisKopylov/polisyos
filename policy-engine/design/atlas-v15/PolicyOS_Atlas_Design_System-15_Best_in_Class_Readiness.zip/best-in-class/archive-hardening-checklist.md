# Archive hardening checklist

Use this before sending a ZIP to design, engineering, procurement, security or accessibility reviewers.

## Metadata

- [ ] Root `package.json` version matches current release notes.
- [ ] Root `README.md` current release matches package version.
- [ ] `packages/atlas-ui/package.json` and `packages/atlas-ui/dist/package.json` match root package version.
- [ ] Generated verification summaries name the current release.
- [ ] Stale previous-release wording is only used for historical sections, not current-release claims.

## Evidence

- [ ] Token generated outputs are present in `tokens/generated/` and `dist/tokens/`.
- [ ] Component manifest, state matrix and package mirrors are present.
- [ ] Accessibility, responsive, data-viz and theming audit outputs are present.
- [ ] Known restrictions and exceptions are listed.
- [ ] Runtime-only gaps are explicitly marked as later gates.

## Governance

- [ ] RACI is present.
- [ ] RFC and ADR templates are present.
- [ ] Deprecation policy exists.
- [ ] Component health model exists.
- [ ] Adoption metrics are defined.
- [ ] Exception register exists.

## Design/product coverage

- [ ] I18n/RTL contract exists.
- [ ] Figma parity contract exists.
- [ ] Content-design system exists.
- [ ] Security/privacy UX contract exists.
- [ ] Product-flow pattern contracts exist.
- [ ] Anti-pattern library exists.

