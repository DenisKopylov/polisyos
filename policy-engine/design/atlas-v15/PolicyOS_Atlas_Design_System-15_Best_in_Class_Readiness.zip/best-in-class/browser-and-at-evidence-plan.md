# Browser and assistive-technology evidence plan

This plan is intentionally not implemented in the ZIP. It defines what must be proven after product-code or Storybook runtime integration begins.

## Browser automation evidence

| Gate | Scope | Required output |
|---|---|---|
| Storybook axe | All stable stories and critical beta stories | `dist/verification/browser-a11y-report.md` |
| Keyboard flows | Dialog, Tabs, Combobox, TokenInput, DataTable, ThemeProvider, DashboardShell | `dist/verification/keyboard-report.md` |
| Visual regression | Light, dark, high contrast, forced colors, reduced motion, large text, color-safe, compact | `dist/verification/visual-regression-report.md` |
| Focus regression | Focus-visible states, portals, drawers, dialogs, sticky headers, scroll regions | Screenshot evidence and diff baseline |
| Responsive runtime | 320, 375, 768, 1024, 1440, print/export | Screenshot matrix and layout assertions |

## Manual assistive-technology matrix

| Platform | Browser | AT | Minimum flows |
|---|---|---|---|
| Windows | Edge/Chrome | NVDA | auth, forms, validation, dialog, data table, dashboard nav |
| Windows | Edge/Chrome | JAWS | auth, forms, validation, dialog, data table, dashboard nav |
| macOS | Safari | VoiceOver | dashboard, charts, popovers, theme modes |
| iOS | Safari | VoiceOver | compact nav, forms, data cards, dialogs |
| Android | Chrome | TalkBack | density modes, charts, file upload, keyboard-free flows |

## Required note format

Each manual AT note must record:

- build identifier;
- operating system and browser versions;
- AT name and version;
- component or flow;
- expected announcement;
- observed announcement;
- keyboard/touch path;
- issue severity;
- owner and disposition.

