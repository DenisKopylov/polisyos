# Component roadmap toward best-in-class coverage

Atlas already has broad primitive coverage. The next best-in-class move is not to add more arbitrary components; it is to close complex interaction gaps with strong keyboard, state and accessibility contracts.

## P0: critical interactive primitives

| Component/pattern | Why it matters | Acceptance notes |
|---|---|---|
| AlertDialog | Destructive and blocking decisions | Focus trap, least-destructive default, clear consequence copy |
| Drawer/Sheet | Responsive dashboard navigation and side workflows | Focus management, escape/close, scroll containment |
| Popover | Contextual evidence and metadata | Trigger relationship, dismissal, no hover-only content |
| Tooltip | Non-essential hints only | Never required to complete task; keyboard/touch accessible strategy |
| Menu/MenuButton | Actions and account/workspace menus | APG-grade keyboard model |
| LiveRegion | Async system events and job status | Polite/assertive severity rules |

## P1: complex data/product patterns

| Component/pattern | Why it matters | Acceptance notes |
|---|---|---|
| DataGrid | Sort/filter/resize/pin/select/virtualize | Separate from DataTable; documented grid keyboard model |
| TreeView | Evidence hierarchy, lineage and policy navigation | Roving tabindex, expand/collapse semantics |
| CommandPalette | Expert workflow acceleration | Search, keyboard-first, permissions-aware results |
| Stepper | Review, onboarding and appeal flows | Current step, completed/error states and summary |
| StatusTimeline | Audit and job histories | Source/time metadata and live updates |
| SplitPane | Dense review workflows | Keyboard resize and persistence |

## P2: polish and authoring utility

| Component/pattern | Why it matters |
|---|---|
| CopyButton | Provenance IDs, logs, audit references |
| CodeBlock | API and policy snippets |
| Kbd | Keyboard help and training |
| Avatar/IdentityChip | Reviewer/operator identity |
| Tag/FilterChip | Evidence and policy filters |

