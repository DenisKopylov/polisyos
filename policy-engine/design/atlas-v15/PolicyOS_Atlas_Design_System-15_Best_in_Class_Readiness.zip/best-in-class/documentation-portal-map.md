# Documentation portal map

The ZIP can stay markdown-first, but a best-in-class delivery should expose a searchable documentation portal later.

## Recommended information architecture

| Section | Content |
|---|---|
| Foundations | Color, type, spacing, elevation, motion, density and modes |
| Tokens | Source format, aliases, generated outputs, migration and diff policy |
| Components | Anatomy, props, states, accessibility, keyboard, examples, do/don't |
| Patterns | Forms, dashboards, evidence intake, review, disputes, export and jobs |
| Data visualization | Chart selection, grammar, alternatives, color/encoding and uncertainty |
| Accessibility | WCAG matrix, APG mapping, AT evidence, keyboard and exceptions |
| Theming | Mode resolution, forced colors, high contrast, density and print |
| I18n | Locale, RTL/bidi, pseudo-locales and translation contract |
| Governance | RFCs, ADRs, ownership, releases, deprecation and adoption metrics |
| Figma/code parity | Token sync, component mapping, variant parity and drift reports |
| Releases | Changelog, migration guides, breaking changes and support windows |

