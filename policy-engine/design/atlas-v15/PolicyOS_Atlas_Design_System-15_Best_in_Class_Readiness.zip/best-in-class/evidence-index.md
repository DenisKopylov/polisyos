# Atlas evidence index

This index maps design-system claims to current archive evidence and later runtime evidence.

| Claim | Current archive evidence | Evidence type | Later evidence needed |
|---|---|---|---|
| Tokens are generated and linted | `tokens/source/`, `tokens/generated/`, `dist/tokens/`, `tokens/generated/token-lint-results.md` | Machine-readable + generated output | Token diff checks across releases |
| Components are governed | `component-library/component-manifest.json`, `component-library/components/`, `packages/atlas-ui/src/components/` | Manifest + docs + source | Usage/adoption telemetry |
| States are explicitly modeled | `component-library/state-matrix/component-state-matrix.json`, `component-library/state-matrix/components/` | Machine-readable + generated docs | Visual snapshots per mode/state |
| Forms/data-entry are covered | `component-library/forms/`, `packages/atlas-ui/stories/DataEntry.stories.tsx` | Contract + story evidence | Keyboard/AT evidence in browser |
| Responsive dashboard is specified | `dashboard-responsive/`, `dist/dashboard-responsive/responsive-manifest.json` | Contract + lint output | Viewport screenshots and touch QA |
| Data visualization has accessible alternatives | `data-visualization/`, `dist/data-visualization/`, chart grammar files | Contract + manifest | Browser focus and table-export snapshots |
| Theming/accessibility modes are formalized | `theming/`, `tokens/modes/`, `dist/theming/` | Token/mode contracts | Visual regression across mode matrix |
| Static accessibility is checked | `accessibility/`, `scripts/a11y_static_lint.py`, `scripts/a11y_contrast_audit.py` | Static lint + contrast | axe/Playwright + manual AT notes |
| Governance is documented | `governance/` | Process docs | Decision log and adoption dashboard over time |
| I18n/RTL is scoped | `internationalization/` | Contract docs | Pseudo-locale screenshots and localized QA |
| Figma/code parity is scoped | `figma/` | Mapping contract | Figma library audit export |
| Security/privacy UX is scoped | `security-privacy-ux/` | UX standards | Product security review evidence |
| Product flows are standardized | `product-patterns/` | Pattern contracts | End-to-end flow tests |

