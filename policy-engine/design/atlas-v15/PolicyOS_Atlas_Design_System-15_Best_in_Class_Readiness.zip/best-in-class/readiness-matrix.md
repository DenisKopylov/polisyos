# Atlas best-in-class readiness matrix

Release: `15.0.0-accessibility-modes`  
Scope: archive/package readiness, not product integration.

| Pillar | Current coverage in archive | Missing for best-in-class | Added in this overlay | Runtime later? | Priority |
|---|---|---|---|---|---|
| Release consistency | Root package is v15; some docs still referenced v14 | Single current-release source of truth | README cleanup, `release_consistency_lint.py`, report | No | P0 |
| Token governance | DTCG-style sources, generated CSS/TS/Tailwind/Figma outputs | Cross-platform outputs and token diff policy | Token-source version alignment and release linting | Partial | P1 |
| Component coverage | 56 components, 491 states, manifest, stories | Component health and owner freshness | `governance/component-health.*`, roadmap | Partial | P0 |
| Accessibility docs | WCAG matrix, keyboard matrix, static lint, contrast audit | Manual AT evidence and browser-based axe/keyboard snapshots | `browser-and-at-evidence-plan.md`, exception register | Yes | P0 |
| Theming modes | 16 modes and mode-resolution docs | Visual matrix evidence and Figma parity | Mode evidence expectations across readiness docs | Yes | P1 |
| Governance | Contribution and maturity model | RACI, RFC, ADR, deprecation, adoption metrics | Full `governance/` folder | No | P0 |
| I18n/RTL | Some responsive/logical behavior | Locale, pseudo-locale, RTL/bidi contracts | Full `internationalization/` folder | Partial | P1 |
| Figma parity | Token export exists | Component and variant parity mapping | Full `figma/` folder | No | P1 |
| Content design | Scattered guidance | Voice, terminology, error and trust-copy standards | Full `content-design/` folder | No | P1 |
| Security/privacy UX | SecretField and governance language | Redaction, audit trail, permission, destructive action standards | Full `security-privacy-ux/` folder | Partial | P1 |
| Product-flow patterns | Screens and UI examples | Canonical workflow contracts | Full `product-patterns/` folder | Partial | P1 |
| Documentation portal | Markdown/docs exist | Searchable portal and docs IA | `documentation-portal-map.md` | Yes | P2 |
| Anti-patterns | Some lint rules | Explicit no-go library | `anti-patterns.md` | Partial | P0 |

## Readiness interpretation

- **P0** items are archive-level trust blockers: metadata, governance, health, evidence planning and anti-patterns.
- **P1** items move Atlas toward enterprise/public-sector maturity: i18n, Figma parity, content design, privacy UX and product flows.
- **P2** items are ecosystem multipliers: documentation portal, cross-platform outputs and adoption dashboards.

