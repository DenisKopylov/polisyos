# ZIP change log: best-in-class readiness overlay

Date: `2026-06-09`  
Base release: `15.0.0-accessibility-modes`

## Changed existing files

- `README.md`: current release corrected from stale v14 wording to `15.0.0-accessibility-modes` and added readiness overlay entry points.
- `packages/atlas-ui/README.md`: removed stale v14 title and clarified v15 theming/accessibility modes.
- `dist/verification/full-verify-summary.md`: corrected current-release wording to v15 and marked runtime evidence as later.
- `tokens/source/*.tokens.json`: aligned Atlas extension version metadata to `15.0.0-accessibility-modes` where the version field exists.
- `package.json`: added archive-only `release:lint` and `readiness:lint` scripts and added new readiness folders to the package file list.

## Added new folders

- `best-in-class/`
- `governance/`
- `internationalization/`
- `figma/`
- `content-design/`
- `security-privacy-ux/`
- `product-patterns/`

## Added new scripts

- `scripts/release_consistency_lint.py`
- `scripts/best_in_class_lint.py`
- `scripts/component_health_build.py`

## Generated new evidence

- `dist/verification/release-consistency-report.md`
- `dist/verification/best-in-class-readiness-report.md`
- `governance/component-health.json`
- `governance/component-health.md`
- `figma/component-parity-index.md`

