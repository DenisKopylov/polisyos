# Atlas component library

This folder defines the production component layer for Atlas. The goal is to move from prototype globals to a governed UI library that engineering, design, accessibility and product teams can rely on.

## Architecture

```text
tokens/source + tokens/modes
        ↓
dist/tokens/atlas.tokens.css
        ↓
packages/atlas-ui/src/atlas-ui.css
        ↓
packages/atlas-ui/src/components/*
        ↓
dist/atlas-ui package mirror
```

The component layer is intentionally boring: predictable API, native semantics, token-only styles, automated gates and explicit documentation.

## Definition of done

A component is not stable until it has:

1. typed public props and exported types;
2. token-only styling;
3. native semantics first, ARIA only where needed;
4. keyboard behavior documented and implemented for composite widgets;
5. state matrix in docs;
6. Storybook-ready story;
7. manifest entry with owner, maturity level and story coverage;
8. static lint passing;
9. migration notes if it replaces a prototype pattern.

## Maturity model

- **experimental** — exploration, not for production flows.
- **beta** — usable behind team agreement; API may change.
- **stable** — public API, docs, states and accessibility contract are complete.
- **deprecated** — replacement exists; migration guidance required.

## Current package

- Source: `packages/atlas-ui/src`
- CSS: `packages/atlas-ui/src/atlas-ui.css`
- Manifest: `component-library/component-manifest.json`
- Build output: `dist/atlas-ui`
- Audit: `component-library/component-library-audit.md`
- Stories: `packages/atlas-ui/stories/*.stories.tsx`


## State matrix contract

v12 requires every component to have a canonical state matrix. A state is complete only when it defines trigger, visual contract, DOM/ARIA contract, token dependencies, keyboard behavior, combination rules, acceptance criteria and test evidence.

Key files:

- `state-matrix.md` — human overview and coverage table.
- `state-matrix/state-taxonomy.json` — shared state vocabulary and precedence.
- `state-matrix/component-state-matrix.json` — machine-readable source of truth.
- `state-matrix/components/*.md` — generated per-component docs.
- `state-matrix-audit.md` — generated gate result.

Run:

```bash
python3 scripts/state_matrix_lint.py
```


## Forms and data-entry coverage

v12 adds a dedicated form system layer:

- Structure: `Form`, `FormSection`, `FieldGroup`, `ValidationSummary`.
- Choices: `RadioGroup`, `CheckboxGroup`.
- Text/security: `SearchField`, `PasswordField`, `SecretField`, `TokenInput`, `CharacterCount`.
- Bounded values: `NumberField`, `RangeField`, `DateField`, `DateRangeField`, `Combobox`.
- Evidence intake: `FileUpload`.

The supporting guidance lives in `component-library/forms/`. Every new component is represented in `component-manifest.json`, `state-matrix/component-state-matrix.json`, per-component docs and `packages/atlas-ui/stories/DataEntry.stories.tsx`.


## Responsive dashboard primitives

v13 promotes dashboard layout behavior into the component library through `DashboardShell`, `DashboardTopBar`, `ResponsiveGrid` and `ScrollRegion`. Their canonical behavioral contract lives in `dashboard-responsive/responsive-contract.json` and their states are represented in the state matrix.

## Data visualization components

Atlas v14 adds chart primitives and a grammar-based visualization contract. Meaningful charts require visible summaries and data alternatives; color-only meaning is rejected.


## v14 Data Visualization

Atlas now includes a formal data visualization system: chart grammar, chart selection, accessible alternatives, tokenized palettes, visualization components, state matrices and `data-viz` build/lint gates. See `DATA_VISUALIZATION_DELTA.md` and `data-visualization/README.md`.
