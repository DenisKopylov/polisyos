# Atlas v12 build evidence

Generated: `2026-06-09T07:31:16Z`

| Gate | Result | Evidence |
|---|---|---|
| Token build | PASS | `Generated 347 root vars and 173 mode vars.` |
| Token schema lint | PASS | Source tokens 347; mode tokens 173; exported CSS variables 520; blockers 0; total findings 0. |
| Token static lint | PASS | Core design-system files 0 findings; legacy/prototype findings 1933 and equal to baseline. |
| Token aggregate lint | PASS | schema PASS; static-drift PASS. |
| State matrix build | PASS | Built state matrix for 35 components and 317 states. |
| Component build | PASS | TypeScript build generated `dist/atlas-ui` with component-state-matrix mirror. |
| Component lint | PASS | Components in manifest 35; required v12 components 35; story coverage required; blockers 0; warnings 0. |
| State matrix lint | PASS | Components in matrix 35; supported states 317; rejected states 53; blockers 0; warnings 0. |
| Accessibility contrast audit | PASS WITH RESTRICTIONS | Semantic text/control pairs pass; vibrant chart/decorative colors are restricted for normal text. |
| Accessibility static lint | PASS | Blockers 0; warnings 0. |
| Verification | PASS | `dist/verification/verification-report.md` shows all required artifacts and evidence present. |

## Notes

Storybook/Vitest runtime tests are scaffolded but require installing package dev dependencies in a product workspace. The checked ZIP includes static contract gates, generated evidence artifacts and Storybook-ready examples for the v12 form/data-entry layer.
