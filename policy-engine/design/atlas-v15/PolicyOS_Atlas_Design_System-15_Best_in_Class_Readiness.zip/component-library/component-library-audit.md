# Atlas Component Library Audit

Generated: `2026-06-09T17:33:11Z`

## Gate summary

- Components in manifest: **56**
- Required v15 components: **56**
- Story coverage required: **yes**
- Blockers: **0**
- Warnings: **0**

## Findings

| Severity | Subject | Message |
|---|---|---|
| — | — | No findings. |

## Components

| Component | Status | Docs | Source |
|---|---|---|---|
| Button | `stable` | `component-library/components/button.md` | `packages/atlas-ui/src/components/Button/Button.tsx` |
| Badge | `stable` | `component-library/components/badge.md` | `packages/atlas-ui/src/components/Badge/Badge.tsx` |
| Panel | `stable` | `component-library/components/panel.md` | `packages/atlas-ui/src/components/Panel/Panel.tsx` |
| Card | `stable` | `component-library/components/card.md` | `packages/atlas-ui/src/components/Card/Card.tsx` |
| MetricCard | `stable` | `component-library/components/metric-card.md` | `packages/atlas-ui/src/components/MetricCard/MetricCard.tsx` |
| RunCard | `stable` | `component-library/components/run-card.md` | `packages/atlas-ui/src/components/RunCard/RunCard.tsx` |
| TextField | `stable` | `component-library/components/text-field.md` | `packages/atlas-ui/src/components/Field/TextField.tsx` |
| TextArea | `stable` | `component-library/components/text-area.md` | `packages/atlas-ui/src/components/Field/TextArea.tsx` |
| SelectField | `stable` | `component-library/components/select-field.md` | `packages/atlas-ui/src/components/Field/SelectField.tsx` |
| Checkbox | `stable` | `component-library/components/checkbox.md` | `packages/atlas-ui/src/components/Field/Checkbox.tsx` |
| Switch | `stable` | `component-library/components/switch.md` | `packages/atlas-ui/src/components/Field/Switch.tsx` |
| Tabs | `beta` | `component-library/components/tabs.md` | `packages/atlas-ui/src/components/Tabs/Tabs.tsx` |
| Dialog | `beta` | `component-library/components/dialog.md` | `packages/atlas-ui/src/components/Dialog/Dialog.tsx` |
| Toast | `stable` | `component-library/components/toast.md` | `packages/atlas-ui/src/components/Toast/Toast.tsx` |
| EmptyState | `stable` | `component-library/components/empty-state.md` | `packages/atlas-ui/src/components/EmptyState/EmptyState.tsx` |
| Skeleton | `stable` | `component-library/components/skeleton.md` | `packages/atlas-ui/src/components/Skeleton/Skeleton.tsx` |
| DataTable | `beta` | `component-library/components/data-table.md` | `packages/atlas-ui/src/components/DataTable/DataTable.tsx` |
| GovernanceGate | `stable` | `component-library/components/governance-gate.md` | `packages/atlas-ui/src/components/GovernanceGate/GovernanceGate.tsx` |
| Form | `stable` | `component-library/components/form.md` | `packages/atlas-ui/src/components/Form/Form.tsx` |
| FormSection | `stable` | `component-library/components/form-section.md` | `packages/atlas-ui/src/components/Form/FormSection.tsx` |
| FieldGroup | `stable` | `component-library/components/field-group.md` | `packages/atlas-ui/src/components/Form/FieldGroup.tsx` |
| ValidationSummary | `stable` | `component-library/components/validation-summary.md` | `packages/atlas-ui/src/components/Form/ValidationSummary.tsx` |
| RadioGroup | `stable` | `component-library/components/radio-group.md` | `packages/atlas-ui/src/components/DataEntry/RadioGroup.tsx` |
| CheckboxGroup | `stable` | `component-library/components/checkbox-group.md` | `packages/atlas-ui/src/components/DataEntry/CheckboxGroup.tsx` |
| SearchField | `stable` | `component-library/components/search-field.md` | `packages/atlas-ui/src/components/DataEntry/SearchField.tsx` |
| PasswordField | `stable` | `component-library/components/password-field.md` | `packages/atlas-ui/src/components/DataEntry/PasswordField.tsx` |
| SecretField | `stable` | `component-library/components/secret-field.md` | `packages/atlas-ui/src/components/DataEntry/SecretField.tsx` |
| NumberField | `stable` | `component-library/components/number-field.md` | `packages/atlas-ui/src/components/DataEntry/NumberField.tsx` |
| RangeField | `stable` | `component-library/components/range-field.md` | `packages/atlas-ui/src/components/DataEntry/RangeField.tsx` |
| DateField | `stable` | `component-library/components/date-field.md` | `packages/atlas-ui/src/components/DataEntry/DateField.tsx` |
| DateRangeField | `beta` | `component-library/components/date-range-field.md` | `packages/atlas-ui/src/components/DataEntry/DateRangeField.tsx` |
| FileUpload | `stable` | `component-library/components/file-upload.md` | `packages/atlas-ui/src/components/DataEntry/FileUpload.tsx` |
| TokenInput | `beta` | `component-library/components/token-input.md` | `packages/atlas-ui/src/components/DataEntry/TokenInput.tsx` |
| Combobox | `beta` | `component-library/components/combobox.md` | `packages/atlas-ui/src/components/DataEntry/Combobox.tsx` |
| CharacterCount | `stable` | `component-library/components/character-count.md` | `packages/atlas-ui/src/components/DataEntry/CharacterCount.tsx` |
| DashboardShell | `beta` | `component-library/components/dashboard-shell.md` | `packages/atlas-ui/src/components/DashboardShell/DashboardShell.tsx` |
| DashboardTopBar | `beta` | `component-library/components/dashboard-top-bar.md` | `packages/atlas-ui/src/components/DashboardShell/DashboardTopBar.tsx` |
| ResponsiveGrid | `stable` | `component-library/components/responsive-grid.md` | `packages/atlas-ui/src/components/DashboardShell/ResponsiveGrid.tsx` |
| ScrollRegion | `stable` | `component-library/components/scroll-region.md` | `packages/atlas-ui/src/components/Responsive/ScrollRegion.tsx` |
| ChartFrame | `stable` | `component-library/components/chart-frame.md` | `packages/atlas-ui/src/components/DataVisualization/ChartFrame.tsx` |
| ChartLegend | `stable` | `component-library/components/chart-legend.md` | `packages/atlas-ui/src/components/DataVisualization/ChartLegend.tsx` |
| ChartTooltip | `beta` | `component-library/components/chart-tooltip.md` | `packages/atlas-ui/src/components/DataVisualization/ChartTooltip.tsx` |
| Sparkline | `stable` | `component-library/components/sparkline.md` | `packages/atlas-ui/src/components/DataVisualization/Sparkline.tsx` |
| BarChart | `stable` | `component-library/components/bar-chart.md` | `packages/atlas-ui/src/components/DataVisualization/BarChart.tsx` |
| LineChart | `stable` | `component-library/components/line-chart.md` | `packages/atlas-ui/src/components/DataVisualization/LineChart.tsx` |
| Heatmap | `beta` | `component-library/components/heatmap.md` | `packages/atlas-ui/src/components/DataVisualization/Heatmap.tsx` |
| UncertaintyBand | `stable` | `component-library/components/uncertainty-band.md` | `packages/atlas-ui/src/components/DataVisualization/UncertaintyBand.tsx` |
| ProvenanceGraph | `beta` | `component-library/components/provenance-graph.md` | `packages/atlas-ui/src/components/DataVisualization/ProvenanceGraph.tsx` |
| ChartDataTable | `stable` | `component-library/components/chart-data-table.md` | `packages/atlas-ui/src/components/DataVisualization/ChartDataTable.tsx` |
| CausalGraph | `beta` | `component-library/components/causal-graph.md` | `packages/atlas-ui/src/components/DataVisualization/CausalGraph.tsx` |
| ProvenanceMap | `stable` | `component-library/components/provenance-map.md` | `packages/atlas-ui/src/components/DataVisualization/ProvenanceMap.tsx` |
| ChartAnnotation | `stable` | `component-library/components/chart-annotation.md` | `packages/atlas-ui/src/components/DataVisualization/ChartAnnotation.tsx` |
| DataVizTable | `stable` | `component-library/components/data-viz-table.md` | `packages/atlas-ui/src/components/DataVisualization/DataVizTable.tsx` |
| ThemeProvider | `stable` | `component-library/components/theme-provider.md` | `packages/atlas-ui/src/components/Theming/ThemeProvider.tsx` |
| ThemeToggle | `stable` | `component-library/components/theme-toggle.md` | `packages/atlas-ui/src/components/Theming/ThemeToggle.tsx` |
| AccessibilityModePanel | `stable` | `component-library/components/accessibility-mode-panel.md` | `packages/atlas-ui/src/components/Theming/AccessibilityModePanel.tsx` |
