# AccessibilityModePanel

Exposes the full accessibility mode axis set through labelled native controls.

## Usage

Use `AccessibilityModePanel` when a product surface needs to expose or apply Atlas accessibility theming modes through the package contract.

## Style

The component uses `--atlas-theme-*`, semantic color tokens, focus tokens and density tokens. It must not introduce raw color values in source.

## Code contract

Source: `packages/atlas-ui/src/components/Theming/AccessibilityModePanel.tsx`. Import from `@policyos/atlas-ui`.

## Accessibility

Native controls are preferred. Focus-visible is preserved across high contrast, forced colors, reduced motion and density modes. Labels describe the current mode and the effect of the next action.

## State matrix

Canonical state matrix: `component-library/state-matrix/components/accessibility-mode-panel.md`.

## Content guidance

Use user-facing labels such as Auto, Light, Dark, High contrast, Reduced motion, Reduced transparency, Large text and Color-safe. Do not describe these as visual preferences only; they are accessibility preferences.
