# AdaptiveDataRegion

**Status:** beta  
**Owner:** Design System / Data Display  
**Source:** `packages/atlas-ui/src/components/DashboardLayout/AdaptiveDataRegion.tsx`

## Usage

Use `AdaptiveDataRegion` for the v13 responsive dashboard model. Named local scroll/data region for dense tables, graphs and timelines with summary text for narrow contexts.

```tsx
import { AdaptiveDataRegion } from '@policyos/atlas-ui';
```

## Style

This component is token-only. Current token dependencies:

- `--atlas-dashboard-data-region-min-block`
- `--line`
- `--panel`
- `--focus-ring`

## Code contract

- Exported from `packages/atlas-ui/src/index.ts`.
- Public props are TypeScript typed.
- Styling is class-based through `atlas-ui.css`.
- Do not introduce raw `#hex`, `rgb()` or `rgba()` values in component source.
- Dashboard chrome adapts by viewport; content inside `DashboardMain` should prefer container-aware primitives.

## Accessibility

- scrollable table regions have names.
- summary can describe dense visual data.
- keyboard focus exposes local scrolling.

## State matrix

Canonical v13 state contract: `component-library/state-matrix/components/adaptive-data-region.md` and `component-library/state-matrix/component-state-matrix.json#/components/AdaptiveDataRegion`.

| State | Kind | Trigger | DOM / ARIA contract | Priority |
|---|---|---|---|---|
| `table` | layout | Component enters `table` state. | Exposed through native landmarks, ARIA or `data-state`/responsive CSS without changing DOM order. | P0 |
| `cards` | layout | Component enters `cards` state. | Exposed through native landmarks, ARIA or `data-state`/responsive CSS without changing DOM order. | P0 |
| `graph` | layout | Component enters `graph` state. | Exposed through native landmarks, ARIA or `data-state`/responsive CSS without changing DOM order. | P0 |
| `timeline` | layout | Component enters `timeline` state. | Exposed through native landmarks, ARIA or `data-state`/responsive CSS without changing DOM order. | P0 |
| `scrollable` | layout | Component enters `scrollable` state. | Exposed through native landmarks, ARIA or `data-state`/responsive CSS without changing DOM order. | P0 |

Rejected states and combination rules are documented in the canonical state-matrix artifact.

## Content guidance

- Keep route titles short enough for compact topbars.
- Do not remove evidence, confidence, reviewer or governance context at narrow widths.
- Prefer local scrolling or card alternatives for dense data instead of whole-page horizontal scrolling.
