# Badge

**Status:** stable  
**Owner:** Design System / UI Foundations  
**Source:** `packages/atlas-ui/src/components/Badge/Badge.tsx`

## Usage

Use `Badge` when the product needs the stable Atlas implementation rather than a screen-local prototype pattern. Import it from `@policyos/atlas-ui` and load token CSS before component CSS.

```tsx
import { Badge } from '@policyos/atlas-ui';
```

## Style

This component must use component or semantic tokens only. Current token dependencies:

- `--atlas-badge-ok-bg`
- `--atlas-badge-warn-bg`
- `--atlas-badge-fail-bg`

## Code contract

- Exported from `packages/atlas-ui/src/index.ts`.
- Public props are TypeScript typed.
- Styling is class-based through `atlas-ui.css`.
- Do not introduce raw `#hex`, `rgb()` or `rgba()` values in component source.

## Accessibility

- non-interactive by default.
- optional role=status for dynamic updates.
- tone is not the only carrier of meaning.
- Use semantic text in addition to color for status or severity.

## State matrix

Canonical v11 state contract: `component-library/state-matrix/components/badge.md` and `component-library/state-matrix/component-state-matrix.json#/components/Badge`.

| State | Kind | Trigger | DOM / ARIA contract | Priority |
|---|---|---|---|---|
| `neutral` | status | tone="neutral". | Plain text unless status=true. | P0 |
| `info` | status | tone="info". | Plain text unless status=true. | P0 |
| `success` | status | tone="success". | Text must contain the status, not only color. | P0 |
| `warning` | status | tone="warning". | Text must contain the status, not only color. | P0 |
| `danger` | status | tone="danger". | Text must contain the status, not only color. | P0 |
| `status` | a11y | status=true for changing status text. | role="status" exposes polite announcement. | P0 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | No semantic change; forced-colors uses system colors where appropriate. | P0 |
| `density` | mode | Container or product shell applies a density mode. | No semantic change. | P1 |

Rejected states and combination rules are documented in the canonical state-matrix artifact.

## Content guidance

- Labels should be specific to the user action or data object.
- Avoid internal abbreviations unless already defined in the same surface.
- For PolicyOS governance flows, include evidence, confidence or reviewer context where it changes the decision.
