# Button

**Status:** stable  
**Owner:** Design System / UI Foundations  
**Source:** `packages/atlas-ui/src/components/Button/Button.tsx`

## Usage

Use `Button` when the product needs the stable Atlas implementation rather than a screen-local prototype pattern. Import it from `@policyos/atlas-ui` and load token CSS before component CSS.

```tsx
import { Button } from '@policyos/atlas-ui';
```

## Style

This component must use component or semantic tokens only. Current token dependencies:

- `--atlas-button-primary-bg`
- `--atlas-button-ghost-bg`
- `--focus-ring`

## Code contract

- Exported from `packages/atlas-ui/src/index.ts`.
- Public props are TypeScript typed.
- Styling is class-based through `atlas-ui.css`.
- Do not introduce raw `#hex`, `rgb()` or `rgba()` values in component source.

## Accessibility

- native button semantics.
- type defaults to button.
- loading exposes aria-busy and text alternative.
- visible focus ring.
- Use semantic text in addition to color for status or severity.

## State matrix

Canonical v11 state contract: `component-library/state-matrix/components/button.md` and `component-library/state-matrix/component-state-matrix.json#/components/Button`.

| State | Kind | Trigger | DOM / ARIA contract | Priority |
|---|---|---|---|---|
| `default` | interaction | Button is enabled and idle. | Native semantic element remains available to keyboard and assistive tech. | P0 |
| `hover` | interaction | Pointer enters enabled control. | No ARIA change. | P0 |
| `focus-visible` | interaction | Keyboard, switch control or programmatic focus reaches the element. | Native focus target or roving tabindex target. | P0 |
| `active` | interaction | Pointer down, Enter or Space activation. | Native activation event fires once. | P0 |
| `disabled` | interaction | Action is unavailable or blocked by permissions/prerequisites. | Use native disabled where possible; otherwise aria-disabled with blocked handlers. | P0 |
| `loading` | async | Consumer passes loading=true while an action is pending. | aria-busy=true and hidden loading text precedes label in accessible name. | P0 |
| `variant-primary` | variant | variant="primary". | No semantic change; action importance is conveyed by placement and label. | P0 |
| `variant-danger` | variant | variant="danger" for destructive or irreversible actions. | No ARIA change; label must name the destructive action. | P0 |
| `icon-only` | content | size="icon" or visual label is absent. | Requires aria-label or aria-labelledby supplied by consumer. | P0 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | No semantic change; forced-colors uses system colors where appropriate. | P0 |
| `reduced-motion` | mode | User sets prefers-reduced-motion: reduce. | No semantic change; loading labels remain exposed. | P0 |
| `density` | mode | Container or product shell applies a density mode. | No semantic change. | P1 |

Rejected states and combination rules are documented in the canonical state-matrix artifact.

## Content guidance

- Labels should be specific to the user action or data object.
- Avoid internal abbreviations unless already defined in the same surface.
- For PolicyOS governance flows, include evidence, confidence or reviewer context where it changes the decision.
