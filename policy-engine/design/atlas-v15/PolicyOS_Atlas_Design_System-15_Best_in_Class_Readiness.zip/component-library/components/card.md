# Card

**Status:** stable  
**Owner:** Design System / UI Foundations  
**Source:** `packages/atlas-ui/src/components/Card/Card.tsx`

## Usage

Use `Card` when the product needs the stable Atlas implementation rather than a screen-local prototype pattern. Import it from `@policyos/atlas-ui` and load token CSS before component CSS.

```tsx
import { Card } from '@policyos/atlas-ui';
```

## Style

This component must use component or semantic tokens only. Current token dependencies:

- `--atlas-panel-surface`
- `--atlas-panel-border`

## Code contract

- Exported from `packages/atlas-ui/src/index.ts`.
- Public props are TypeScript typed.
- Styling is class-based through `atlas-ui.css`.
- Do not introduce raw `#hex`, `rgb()` or `rgba()` values in component source.

## Accessibility

- interactive card is a native button.
- selected state uses aria-pressed.
- do not nest buttons inside CardButton.
- Do not rely on color alone for meaning.

## State matrix

Canonical v11 state contract: `component-library/state-matrix/components/card.md` and `component-library/state-matrix/component-state-matrix.json#/components/Card`.

| State | Kind | Trigger | DOM / ARIA contract | Priority |
|---|---|---|---|---|
| `default` | interaction | CardButton is enabled and idle. | Native semantic element remains available to keyboard and assistive tech. | P0 |
| `hover` | interaction | Pointer enters enabled control. | No ARIA change. | P0 |
| `focus-visible` | interaction | Keyboard, switch control or programmatic focus reaches the element. | Native focus target or roving tabindex target. | P0 |
| `active` | interaction | Pointer down, Enter or Space activation. | Native activation event fires once. | P0 |
| `disabled` | interaction | Action is unavailable or blocked by permissions/prerequisites. | Use native disabled where possible; otherwise aria-disabled with blocked handlers. | P0 |
| `static` | layout | Card renders informational content. | article labelled by title when present. | P0 |
| `interactive` | interaction | CardButton renders a native button. | button with accessible name from title/description. | P0 |
| `selected` | selection | CardButton selected=true. | aria-pressed=true. | P0 |
| `content-overflow` | layout | Description or meta content exceeds one line. | No semantic change. | P1 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | No semantic change; forced-colors uses system colors where appropriate. | P0 |
| `reduced-motion` | mode | User sets prefers-reduced-motion: reduce. | No semantic change; loading labels remain exposed. | P0 |
| `density` | mode | Container or product shell applies a density mode. | No semantic change. | P1 |

Rejected states and combination rules are documented in the canonical state-matrix artifact.

## Content guidance

- Labels should be specific to the user action or data object.
- Avoid internal abbreviations unless already defined in the same surface.
- For PolicyOS governance flows, include evidence, confidence or reviewer context where it changes the decision.
