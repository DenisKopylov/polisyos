# CharacterCount

Use CharacterCount with TextArea or TextField when input length affects submission.

Canonical state matrix: `component-library/state-matrix/components/character-count.md`.

## Usage

Use CharacterCount with TextArea or TextField when input length affects submission. Prefer this component over ad-hoc form markup whenever the task collects policy, evidence, governance or account data. The component is designed for production flows where validation, keyboard use, screen readers, internationalization and auditability matter.

## Style

A polite live region that reports remaining or over-limit characters. Visual styling is token-only and inherits Atlas form density, high-contrast and dark-mode behavior. Do not hard-code colors, spacing or borders around this component; extend the relevant `--atlas-*` tokens instead.

## Code contract

Source: `packages/atlas-ui/src/components/DataEntry/CharacterCount.tsx`.

Import from the package root:

```tsx
import { CharacterCount } from '@policyos/atlas-ui';
```

The public API requires a visible label, legend or title whenever the component collects or summarizes user input. Error copy is passed through an `error` or `items` contract and must be actionable, not just descriptive.

## Accessibility

- Uses native HTML semantics wherever possible; ARIA is added only to connect labels, descriptions, validation messages or popup state.
- Help text and error text are connected with `aria-describedby`.
- Invalid states expose `aria-invalid` where the component owns a native input.
- Focus-visible remains visible in high-contrast and forced-colors modes.
- Required state must be expressed through both visual copy and programmatic attributes when applicable.

## State matrix

Canonical file: `component-library/state-matrix/components/character-count.md`.

Covered states include: default, warning, over-limit, live-update, high-contrast, density.

Focus-visible is an overlay state and must not disappear when the component is selected, invalid, open or hovered.

## Content guidance

Write labels as questions or noun phrases that match the data being collected. Helper text should give format, source, retention, privacy or governance guidance before the user makes an error. Error text should explain what went wrong and how to fix it. For dates, numbers, files and secrets, include constraints in text instead of relying on placeholders alone.
