# ChartAnnotation

Inline chart callout for assumptions, outliers, stale evidence and governance notes.

## Usage

Use `ChartAnnotation` when a PolicyOS surface communicates quantitative, causal, provenance or uncertainty information. Pair visual encodings with labels and a table equivalent when the chart affects decisions.

## Style

Use Atlas data visualization tokens only: chart surface, axis, grid, categorical palette, uncertainty fills, annotation borders and tooltip surfaces. Do not introduce raw color or chart-library defaults.

## Code contract

Import from `@policyos/atlas-ui`. Component source: `packages/atlas-ui/src/components/DataVisualization/ChartAnnotation.tsx`.

Canonical state matrix: `component-library/state-matrix/components/chart-annotation.md`.

## Accessibility

Provide a title, summary and table/long-description path for complex charts. Do not rely on color alone. Ensure focus-visible states and forced-colors fallbacks remain visible for interactive chart controls.

## State matrix

The canonical state matrix is `component-library/state-matrix/components/chart-annotation.md` and includes default, loading/empty/error or chart-specific states, high-contrast and density coverage.

## Content guidance

Write chart summaries as conclusions, not descriptions of marks. Include units, source dates and interval definitions whenever the chart can affect a decision.
