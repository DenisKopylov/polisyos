# Checkbox

**Status:** stable  
**Owner:** Design System / Forms  
**Source:** `packages/atlas-ui/src/components/Field/Checkbox.tsx`

## Usage

Use `Checkbox` when the product needs the stable Atlas implementation rather than a screen-local prototype pattern. Import it from `@policyos/atlas-ui` and load token CSS before component CSS.

```tsx
import { Checkbox } from '@policyos/atlas-ui';
```

## Style

This component must use component or semantic tokens only. Current token dependencies:

- `--target-min-wcag`
- `--accent`
- `--danger`

## Code contract

- Exported from `packages/atlas-ui/src/index.ts`.
- Public props are TypeScript typed.
- Styling is class-based through `atlas-ui.css`.
- Do not introduce raw `#hex`, `rgb()` or `rgba()` values in component source.

## Accessibility

- native checkbox semantics.
- label targets input.
- description/error connected with aria-describedby.
- Do not rely on color alone for meaning.

## State matrix

Canonical v11 state contract: `component-library/state-matrix/components/checkbox.md` and `component-library/state-matrix/component-state-matrix.json#/components/Checkbox`.

| State | Kind | Trigger | DOM / ARIA contract | Priority |
|---|---|---|---|---|
| `unchecked` | selection | checked/defaultChecked are false and indeterminate=false. | role=checkbox from native input; checked=false. | P0 |
| `checked` | selection | checked/defaultChecked true. | Native checked state. | P0 |
| `indeterminate` | selection | indeterminate=true. | aria-checked=mixed and DOM indeterminate property set. | P0 |
| `focus-visible` | interaction | Keyboard focus reaches input. | Native focus target. | P0 |
| `required` | validation | required=true. | required and aria-required set. | P0 |
| `invalid` | validation | error prop is provided. | aria-invalid=true and error id in aria-describedby. | P0 |
| `disabled` | interaction | disabled=true. | Native disabled removes from tab order. | P0 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | No semantic change; forced-colors uses system colors where appropriate. | P0 |
| `reduced-motion` | mode | User sets prefers-reduced-motion: reduce. | No semantic change; loading labels remain exposed. | P0 |
| `density` | mode | Container or product shell applies a density mode. | No semantic change. | P1 |

Rejected states and combination rules are documented in the canonical state-matrix artifact.

## Content guidance

- Labels should be specific to the user action or data object.
- Avoid internal abbreviations unless already defined in the same surface.
- For PolicyOS governance flows, include evidence, confidence or reviewer context where it changes the decision.
