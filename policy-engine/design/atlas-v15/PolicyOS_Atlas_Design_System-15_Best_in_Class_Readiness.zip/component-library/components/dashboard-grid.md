# DashboardGrid

DashboardGrid is part of the v13 dashboard responsive model. It turns the Atlas runtime dashboard from a desktop-only prototype into a reusable, breakpoint-aware product surface.

## Usage

Use `DashboardGrid` when composing operator dashboards, review queues, governance consoles or data-dense decision workspaces that must work across phone, tablet, desktop, wide desktop, print and reduced-motion contexts.

## Style

All visual behavior is driven by dashboard tokens such as `--atlas-dashboard-main-padding`, `--atlas-dashboard-grid-gap`, `--atlas-dashboard-sidebar-docked-width` and `--atlas-dashboard-topbar-height`. Do not hard-code viewport-specific colors in component source.

## Code contract

Source: `packages/atlas-ui/src/components/Dashboard/DashboardGrid.tsx`.

Import from the package root:

```tsx
import { DashboardGrid } from '@policyos/atlas-ui';
```

The component exposes `data-atlas-component` and `data-state` hooks so responsive, accessibility and visual-regression tests do not depend on private class names.

## Accessibility

The component preserves landmarks, visible focus, keyboard navigation and target-size constraints across docked, rail and drawer layouts. Drawer navigation must be controlled by a labelled button with `aria-expanded`; print/export mode must not clip hidden table content.

## State matrix

Canonical state matrix: `component-library/state-matrix/components/dashboard-grid.md`.

Supported states: auto, metrics, content-sidebar, split, stack, compact-gap, single-column, high-contrast, density.

## Content guidance

Keep dashboard labels short enough for rail and drawer layouts. Use explicit summaries for dense tables/charts so compressed layouts still communicate purpose before a user scrolls horizontally.
