# DashboardMain

**Status:** stable  
**Owner:** Design System / Dashboard Layout  
**Source:** `packages/atlas-ui/src/components/DashboardLayout/DashboardMain.tsx`

## Usage

Use `DashboardMain` for the v13 responsive dashboard model. Named main workspace landmark with focus handoff and container-query boundary for dashboard content.

```tsx
import { DashboardMain } from '@policyos/atlas-ui';
```

## Style

This component is token-only. Current token dependencies:

- `--atlas-dashboard-main-padding`
- `--atlas-dashboard-main-gap`
- `--surface-gradient-start`
- `--surface-gradient-end`

## Code contract

- Exported from `packages/atlas-ui/src/index.ts`.
- Public props are TypeScript typed.
- Styling is class-based through `atlas-ui.css`.
- Do not introduce raw `#hex`, `rgb()` or `rgba()` values in component source.
- Dashboard chrome adapts by viewport; content inside `DashboardMain` should prefer container-aware primitives.

## Accessibility

- named main landmark required.
- programmatic focus supports route changes.
- container queries avoid viewport-only content behavior.

## State matrix

Canonical v13 state contract: `component-library/state-matrix/components/dashboard-main.md` and `component-library/state-matrix/component-state-matrix.json#/components/DashboardMain`.

| State | Kind | Trigger | DOM / ARIA contract | Priority |
|---|---|---|---|---|
| `default` | layout | Component enters `default` state. | Exposed through native landmarks, ARIA or `data-state`/responsive CSS without changing DOM order. | P0 |
| `focused` | layout | Component enters `focused` state. | Exposed through native landmarks, ARIA or `data-state`/responsive CSS without changing DOM order. | P0 |
| `compact` | layout | Component enters `compact` state. | Exposed through native landmarks, ARIA or `data-state`/responsive CSS without changing DOM order. | P0 |
| `medium` | layout | Component enters `medium` state. | Exposed through native landmarks, ARIA or `data-state`/responsive CSS without changing DOM order. | P0 |
| `expanded` | layout | Component enters `expanded` state. | Exposed through native landmarks, ARIA or `data-state`/responsive CSS without changing DOM order. | P0 |

Rejected states and combination rules are documented in the canonical state-matrix artifact.

## Content guidance

- Keep route titles short enough for compact topbars.
- Do not remove evidence, confidence, reviewer or governance context at narrow widths.
- Prefer local scrolling or card alternatives for dense data instead of whole-page horizontal scrolling.
