# DashboardShell

**Status:** beta  
**Owner:** Design System / Dashboard Layout  
**Source:** `packages/atlas-ui/src/components/DashboardShell/DashboardShell.tsx`

## Usage

Use `DashboardShell` for the v13 responsive dashboard model. Top-level dashboard shell that coordinates frame, responsive sidebar drawer state, topbar and main workspace composition.

```tsx
import { DashboardShell } from '@policyos/atlas-ui';
```

## Style

This component is token-only. Current token dependencies:

- `--atlas-dashboard-frame-max`
- `--atlas-dashboard-shell-radius`
- `--atlas-dashboard-shell-border`
- `--atlas-dashboard-layout-min-height`

## Code contract

- Exported from `packages/atlas-ui/src/index.ts`.
- Public props are TypeScript typed.
- Styling is class-based through `atlas-ui.css`.
- Do not introduce raw `#hex`, `rgb()` or `rgba()` values in component source.
- Dashboard chrome adapts by viewport; content inside `DashboardMain` should prefer container-aware primitives.

## Accessibility

- preserves one primary navigation and one main landmark.
- drawer backdrop is a native button.
- does not transform-scale content.

## State matrix

Canonical v13 state contract: `component-library/state-matrix/components/dashboard-shell.md` and `component-library/state-matrix/component-state-matrix.json#/components/DashboardShell`.

| State | Kind | Trigger | DOM / ARIA contract | Priority |
|---|---|---|---|---|
| `default` | layout | Component enters `default` state. | Exposed through native landmarks, ARIA or `data-state`/responsive CSS without changing DOM order. | P0 |
| `drawer-open` | layout | Component enters `drawer-open` state. | Exposed through native landmarks, ARIA or `data-state`/responsive CSS without changing DOM order. | P0 |
| `compact` | layout | Component enters `compact` state. | Exposed through native landmarks, ARIA or `data-state`/responsive CSS without changing DOM order. | P0 |
| `rail` | layout | Component enters `rail` state. | Exposed through native landmarks, ARIA or `data-state`/responsive CSS without changing DOM order. | P0 |
| `expanded` | layout | Component enters `expanded` state. | Exposed through native landmarks, ARIA or `data-state`/responsive CSS without changing DOM order. | P0 |

Rejected states and combination rules are documented in the canonical state-matrix artifact.

## Content guidance

- Keep route titles short enough for compact topbars.
- Do not remove evidence, confidence, reviewer or governance context at narrow widths.
- Prefer local scrolling or card alternatives for dense data instead of whole-page horizontal scrolling.
