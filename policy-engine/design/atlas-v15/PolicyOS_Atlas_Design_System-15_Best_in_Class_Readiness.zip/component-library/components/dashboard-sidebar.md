# DashboardSidebar

**Status:** beta  
**Owner:** Design System / Dashboard Navigation  
**Source:** `packages/atlas-ui/src/components/DashboardLayout/DashboardSidebar.tsx`

## Usage

Use `DashboardSidebar` for the v13 responsive dashboard model. Responsive primary dashboard navigation supporting expanded sidebar, icon rail and off-canvas drawer treatments.

```tsx
import { DashboardSidebar } from '@policyos/atlas-ui';
```

## Style

This component is token-only. Current token dependencies:

- `--atlas-dashboard-sidebar-width`
- `--atlas-dashboard-sidebar-rail-width`
- `--atlas-dashboard-sidebar-drawer-width`
- `--atlas-rail-bg`

## Code contract

- Exported from `packages/atlas-ui/src/index.ts`.
- Public props are TypeScript typed.
- Styling is class-based through `atlas-ui.css`.
- Do not introduce raw `#hex`, `rgb()` or `rgba()` values in component source.
- Dashboard chrome adapts by viewport; content inside `DashboardMain` should prefer container-aware primitives.

## Accessibility

- aria-current marks current screen.
- icon-only rail keeps labels in accessible names.
- target sizes stay token-backed.

## State matrix

Canonical v13 state contract: `component-library/state-matrix/components/dashboard-sidebar.md` and `component-library/state-matrix/component-state-matrix.json#/components/DashboardSidebar`.

| State | Kind | Trigger | DOM / ARIA contract | Priority |
|---|---|---|---|---|
| `default` | layout | Component enters `default` state. | Exposed through native landmarks, ARIA or `data-state`/responsive CSS without changing DOM order. | P0 |
| `current` | layout | Component enters `current` state. | Exposed through native landmarks, ARIA or `data-state`/responsive CSS without changing DOM order. | P0 |
| `rail` | layout | Component enters `rail` state. | Exposed through native landmarks, ARIA or `data-state`/responsive CSS without changing DOM order. | P0 |
| `drawer-open` | layout | Component enters `drawer-open` state. | Exposed through native landmarks, ARIA or `data-state`/responsive CSS without changing DOM order. | P0 |
| `drawer-closed` | layout | Component enters `drawer-closed` state. | Exposed through native landmarks, ARIA or `data-state`/responsive CSS without changing DOM order. | P0 |

Rejected states and combination rules are documented in the canonical state-matrix artifact.

## Content guidance

- Keep route titles short enough for compact topbars.
- Do not remove evidence, confidence, reviewer or governance context at narrow widths.
- Prefer local scrolling or card alternatives for dense data instead of whole-page horizontal scrolling.
