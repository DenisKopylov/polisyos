# DashboardTopBar

**Status:** stable  
**Owner:** Design System / Responsive Dashboard  
**Source:** `packages/atlas-ui/src/components/DashboardShell/DashboardTopBar.tsx`

## Usage

Use DashboardTopBar for the current workspace title, responsive menu control and density/theme/actions.

```tsx
import { DashboardTopBar } from '@policyos/atlas-ui';
```

## Style

This component must use component or semantic tokens only. Current token dependencies:

- `--atlas-dashboard-topbar-height`
- `--atlas-dashboard-topbar-surface`
- `--atlas-dashboard-topbar-border`

## Code contract

- Exported from `packages/atlas-ui/src/index.ts`.
- Public props are TypeScript typed.
- Styling is class-based through `atlas-ui.css`.
- Do not introduce raw `#hex`, `rgb()` or `rgba()` values in component source.
- Preserve DOM order as reading order when layouts collapse.

## Accessibility

- visible page title.
- menu button uses aria-controls and aria-expanded.
- actions remain keyboard reachable.
- Reflow must preserve information and functionality at the 320 CSS px contract.
- Target sizes must preserve the Atlas `--target-min` and `--target-min-wcag` contracts.

## State matrix

Canonical v13 state contract: `component-library/state-matrix/components/dashboard-top-bar.md` and `component-library/state-matrix/component-state-matrix.json#/components/DashboardTopBar`.

See the state matrix for supported states, rejected states and responsive combination rules.

## Content guidance

- Titles should describe the current workspace or user task, not internal implementation names.
- Responsive labels should stay meaningful when sidebars collapse to icon or rail modes.
- Avoid abbreviating navigation items unless the full label remains available through visible text, tooltip or accessible name.
