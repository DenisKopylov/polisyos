# DashboardTopBar

**Status:** stable  
**Owner:** Design System / Responsive Layout  
**Source:** `packages/atlas-ui/src/components/Responsive/DashboardTopBar.tsx`

## Usage

Use `DashboardTopBar` for production responsive dashboard layouts rather than screen-local prototype CSS. Import it from `@policyos/atlas-ui` and load token CSS before component CSS.

```tsx
import { DashboardTopBar } from '@policyos/atlas-ui';
```

## Style

This component uses responsive component tokens only. Current token dependencies:

- `--atlas-shell-mobile-topbar-height`
- `--atlas-shell-main-padding-mobile`
- `--atlas-shell-border`

## Code contract

- Exported from `packages/atlas-ui/src/index.ts`.
- Public props are TypeScript typed.
- Styling is class-based through `atlas-ui.css`.
- Do not introduce raw `#hex`, `rgb()` or `rgba()` values in component source.
- Canonical responsive behavior is documented in `dashboard-responsive/responsive-contract.json`.

## Accessibility

- header landmark.
- consumer-supplied menu button.
- visible title.
- status actions optional.

## State matrix

Canonical v13 state contract: `component-library/state-matrix/components/dashboard-topbar.md` and `component-library/state-matrix/component-state-matrix.json#/components/DashboardTopBar`.

| State | Kind | Trigger | DOM / ARIA contract | Priority |
|---|---|---|---|---|
| `default` | layout | See canonical matrix. | DOM order and landmarks remain stable. | P0 |
| `menu-available` | layout | See canonical matrix. | DOM order and landmarks remain stable. | P0 |
| `menu-expanded` | layout | See canonical matrix. | DOM order and landmarks remain stable. | P0 |
| `title-overflow` | layout | See canonical matrix. | DOM order and landmarks remain stable. | P0 |
| `high-contrast` | layout | See canonical matrix. | DOM order and landmarks remain stable. | P0 |
| `density` | layout | See canonical matrix. | DOM order and landmarks remain stable. | P0 |

Rejected states and combination rules are documented in the canonical state-matrix artifact.

## Content guidance

- Preserve governance, evidence and error context when stacking.
- Do not hide important dashboard controls solely to fit a viewport.
- Prefer explicit labels for scroll regions and drawer controls.
