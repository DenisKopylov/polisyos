# DataTable

**Status:** beta  
**Owner:** Design System / Data Display  
**Source:** `packages/atlas-ui/src/components/DataTable/DataTable.tsx`

## Usage

Use `DataTable` when the product needs the stable Atlas implementation rather than a screen-local prototype pattern. Import it from `@policyos/atlas-ui` and load token CSS before component CSS.

```tsx
import { DataTable } from '@policyos/atlas-ui';
```

## Style

This component must use component or semantic tokens only. Current token dependencies:

- `--line`
- `--surface`
- `--muted`

## Code contract

- Exported from `packages/atlas-ui/src/index.ts`.
- Public props are TypeScript typed.
- Styling is class-based through `atlas-ui.css`.
- Do not introduce raw `#hex`, `rgb()` or `rgba()` values in component source.

## Accessibility

- caption required.
- semantic table elements.
- row key required.
- Do not rely on color alone for meaning.

## State matrix

Canonical v11 state contract: `component-library/state-matrix/components/data-table.md` and `component-library/state-matrix/component-state-matrix.json#/components/DataTable`.

| State | Kind | Trigger | DOM / ARIA contract | Priority |
|---|---|---|---|---|
| `with-rows` | data | rows.length > 0. | Native table semantics with caption and column headers. | P0 |
| `empty` | data | rows.length === 0. | Native table semantics remain intact. | P0 |
| `row-hover` | interaction | Pointer moves over row. | No ARIA change. | P1 |
| `horizontal-overflow` | layout | Table wider than container. | Native table remains inside scroll region. | P1 |
| `captioned` | a11y | caption prop is required. | caption element names table context. | P0 |
| `numeric-align-end` | data | column.align="end". | No semantic change. | P1 |
| `sorted-backlog` | backlog | Sorting is not in base DataTable yet. | Future aria-sort contract required. | P2 |
| `selected-row-backlog` | backlog | Row selection is not in base DataTable yet. | Future checkbox/aria-selected contract required. | P2 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | No semantic change; forced-colors uses system colors where appropriate. | P0 |
| `reduced-motion` | mode | User sets prefers-reduced-motion: reduce. | No semantic change; loading labels remain exposed. | P0 |
| `density` | mode | Container or product shell applies a density mode. | No semantic change. | P1 |

Rejected states and combination rules are documented in the canonical state-matrix artifact.

## Content guidance

- Labels should be specific to the user action or data object.
- Avoid internal abbreviations unless already defined in the same surface.
- For PolicyOS governance flows, include evidence, confidence or reviewer context where it changes the decision.
