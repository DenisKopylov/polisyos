# DataVizLegend

**Status:** stable  
**Owner:** Design System / Data Visualization  
**Source:** `packages/atlas-ui/src/components/DataVisualization/DataVizLegend.tsx`

## Usage

Use `DataVizLegend` as part of the Atlas data visualization system. Import it from `@policyos/atlas-ui` and load generated token CSS before component CSS.

```tsx
import { DataVizLegend } from '@policyos/atlas-ui';
```

## Style

This component must use component, semantic or data-visualization tokens only. Current token dependencies:

- `--atlas-viz-legend-gap`
- `--atlas-viz-series-1`
- `--atlas-viz-axis-line`

## Code contract

- Exported from `packages/atlas-ui/src/index.ts`.
- Public props are TypeScript typed.
- Styling is class-based through `atlas-ui.css`.
- Do not introduce raw `#hex`, `rgb()` or `rgba()` values in component source.
- Meaningful charts must be wrapped in `ChartFrame` or provide equivalent title/summary/data alternative.

## Accessibility

- role=list/listitem.
- labels visible as text.
- pattern support for non-color encoding.
- Do not rely on color alone for meaning.
- Provide table/list/long-description evidence for complex charts.

## State matrix

Canonical v14 state contract: `component-library/state-matrix/components/data-viz-legend.md` and `component-library/state-matrix/component-state-matrix.json#/components/DataVizLegend`.

| State | Kind | Trigger | DOM / ARIA contract | Priority |
|---|---|---|---|---|
| `with-items` | data-viz | Runtime condition for `with-items`. | Stable `data-state` plus documented semantics. | P0 |
| `empty` | data-viz | Runtime condition for `empty`. | Stable `data-state` plus documented semantics. | P0 |
| `row` | data-viz | Runtime condition for `row`. | Stable `data-state` plus documented semantics. | P0 |
| `column` | data-viz | Runtime condition for `column`. | Stable `data-state` plus documented semantics. | P0 |
| `patterned` | data-viz | Runtime condition for `patterned`. | Stable `data-state` plus documented semantics. | P0 |

Rejected states and combination rules are documented in the canonical state-matrix artifact.

## Content guidance

- Write the chart message before choosing the chart type.
- Include units, source notes and freshness when they change interpretation.
- Avoid abbreviations unless defined in the same surface.
- For PolicyOS governance flows, name uncertainty, evidence freshness and causal assumptions explicitly.
