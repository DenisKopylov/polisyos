# DataVizTable

**Status:** stable  
**Owner:** Design System / Data Visualization  
**Source:** `packages/atlas-ui/src/components/DataVisualization/DataVizTable.tsx`

## Usage

Use `DataVizTable` as the exact-value equivalent for a chart or as the primary display when exact values matter more than visual scanning.

```tsx
import { DataVizTable } from '@policyos/atlas-ui';
```

## Style

This component must use data-viz, component or semantic tokens only. Current token dependencies:

- `--atlas-table-surface`
- `--atlas-table-border`
- `--atlas-table-caption`

## Code contract

- Exported from `packages/atlas-ui/src/index.ts`.
- Public props are TypeScript typed.
- Styling is class-based through `atlas-ui.css`.
- Do not introduce raw `#hex`, `rgb()` or `rgba()` values in component source.
- Use `data-atlas-component="DataVizTable"` and stable `data-state` hooks for tests.

## Accessibility

- Provide an accessible name and description.
- Do not rely on color alone; pair color with label, shape, line style, direct annotation or table row.
- Preserve keyboard paths for interactive controls.
- Pair visual-only values with narrative summary and exact table equivalent when the chart carries decision evidence.

## State matrix

Canonical v14 state contract: `component-library/state-matrix/components/data-viz-table.md` and `component-library/state-matrix/component-state-matrix.json#/components/DataVizTable`.

Rejected states and combination rules are documented in the canonical state-matrix artifact.

## Content guidance

- State the decision question the visualization supports.
- Label units, cohorts, time windows and source freshness.
- Mention uncertainty, missing data and reviewer caveats in summary text.
- Keep labels concise, but do not hide critical context behind hover-only tooltips.
