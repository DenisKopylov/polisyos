# DecisionTimeline

**Status:** stable  
**Owner:** Design System / Data Visualization  
**Source:** `packages/atlas-ui/src/components/DataViz/DecisionTimeline.tsx`

## Usage

Use `DecisionTimeline` to show ordered evidence, intervention, review or refresh events.

```tsx
import { DecisionTimeline } from '@policyos/atlas-ui';
```

## Style

This component must use data-viz, component or semantic tokens only. Current token dependencies:

- `--atlas-chart-status-fresh`
- `--atlas-chart-status-stale`
- `--atlas-chart-status-blocked`

## Code contract

- Exported from `packages/atlas-ui/src/index.ts`.
- Public props are TypeScript typed.
- Styling is class-based through `atlas-ui.css`.
- Do not introduce raw `#hex`, `rgb()` or `rgba()` values in component source.
- Use `data-atlas-component="DecisionTimeline"` and stable `data-state` hooks for tests.

## Accessibility

- Provide an accessible name and description.
- Do not rely on color alone; pair color with label, shape, line style, direct annotation or table row.
- Preserve keyboard paths for interactive controls.
- Pair visual-only values with narrative summary and exact table equivalent when the chart carries decision evidence.

## State matrix

Canonical v14 state contract: `component-library/state-matrix/components/decision-timeline.md` and `component-library/state-matrix/component-state-matrix.json#/components/DecisionTimeline`.

Rejected states and combination rules are documented in the canonical state-matrix artifact.

## Content guidance

- State the decision question the visualization supports.
- Label units, cohorts, time windows and source freshness.
- Mention uncertainty, missing data and reviewer caveats in summary text.
- Keep labels concise, but do not hide critical context behind hover-only tooltips.
