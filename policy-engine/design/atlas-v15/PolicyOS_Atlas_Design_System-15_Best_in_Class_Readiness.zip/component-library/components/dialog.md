# Dialog

**Status:** beta  
**Owner:** Design System / Overlays  
**Source:** `packages/atlas-ui/src/components/Dialog/Dialog.tsx`

## Usage

Use `Dialog` when the product needs the stable Atlas implementation rather than a screen-local prototype pattern. Import it from `@policyos/atlas-ui` and load token CSS before component CSS.

```tsx
import { Dialog } from '@policyos/atlas-ui';
```

## Style

This component must use component or semantic tokens only. Current token dependencies:

- `--panel-strong`
- `--shadow-xl`
- `--radius-panel`

## Code contract

- Exported from `packages/atlas-ui/src/index.ts`.
- Public props are TypeScript typed.
- Styling is class-based through `atlas-ui.css`.
- Do not introduce raw `#hex`, `rgb()` or `rgba()` values in component source.

## Accessibility

- role=dialog.
- aria-modal=true.
- labelledby title.
- initial focus close control.
- Escape dismiss is supported.
- Keyboard focus is trapped inside the panel while open.
- Focus returns to the previously focused element on close.
- Do not rely on color alone for meaning.

## State matrix

Canonical v11 state contract: `component-library/state-matrix/components/dialog.md` and `component-library/state-matrix/component-state-matrix.json#/components/Dialog`.

| State | Kind | Trigger | DOM / ARIA contract | Priority |
|---|---|---|---|---|
| `closed` | overlay | open=false. | No dialog node exists in DOM. | P0 |
| `open` | overlay | open=true. | role=dialog, aria-modal=true, labelled by title and described by description. | P0 |
| `focus-trap` | a11y | Dialog is open and user tabs through focusables. | Document keydown handler wraps focus. | P0 |
| `escape-dismiss` | interaction | User presses Escape. | onClose fires and focus returns to previous element. | P0 |
| `backdrop-dismiss` | interaction | User clicks backdrop. | onClose fires; panel click stops propagation. | P0 |
| `with-actions` | content | actions prop is provided. | Actions retain their own native semantics. | P0 |
| `destructive-confirmation` | content | Dialog contains danger action. | Use Button danger plus copy; no ARIA change. | P1 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | No semantic change; forced-colors uses system colors where appropriate. | P0 |
| `reduced-motion` | mode | User sets prefers-reduced-motion: reduce. | No semantic change; loading labels remain exposed. | P0 |
| `density` | mode | Container or product shell applies a density mode. | No semantic change. | P1 |

Rejected states and combination rules are documented in the canonical state-matrix artifact.

## Content guidance

- Labels should be specific to the user action or data object.
- Avoid internal abbreviations unless already defined in the same surface.
- For PolicyOS governance flows, include evidence, confidence or reviewer context where it changes the decision.
