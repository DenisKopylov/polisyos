# EmptyState

**Status:** stable  
**Owner:** Design System / Feedback  
**Source:** `packages/atlas-ui/src/components/EmptyState/EmptyState.tsx`

## Usage

Use `EmptyState` when the product needs the stable Atlas implementation rather than a screen-local prototype pattern. Import it from `@policyos/atlas-ui` and load token CSS before component CSS.

```tsx
import { EmptyState } from '@policyos/atlas-ui';
```

## Style

This component must use component or semantic tokens only. Current token dependencies:

- `--atlas-panel-surface`
- `--muted`

## Code contract

- Exported from `packages/atlas-ui/src/index.ts`.
- Public props are TypeScript typed.
- Styling is class-based through `atlas-ui.css`.
- Do not introduce raw `#hex`, `rgb()` or `rgba()` values in component source.

## Accessibility

- clear title and description.
- action uses Button.
- icon hidden from AT unless meaningful.
- Do not rely on color alone for meaning.

## State matrix

Canonical v11 state contract: `component-library/state-matrix/components/empty-state.md` and `component-library/state-matrix/component-state-matrix.json#/components/EmptyState`.

| State | Kind | Trigger | DOM / ARIA contract | Priority |
|---|---|---|---|---|
| `empty` | content | No data exists yet. | section with visible heading. | P0 |
| `permission-denied` | content | User lacks permission. | No fake disabled controls; action links to request access if available. | P0 |
| `filtered-out` | content | Filters remove all rows/items. | Action button clears filters. | P0 |
| `not-found` | content | Requested object cannot be found. | Heading conveys state. | P1 |
| `offline` | content | Network state prevents loading. | Retry action is a native button if provided. | P1 |
| `with-action` | content | action prop is provided. | Action keeps native semantics. | P0 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | No semantic change; forced-colors uses system colors where appropriate. | P0 |
| `reduced-motion` | mode | User sets prefers-reduced-motion: reduce. | No semantic change; loading labels remain exposed. | P0 |
| `density` | mode | Container or product shell applies a density mode. | No semantic change. | P1 |

Rejected states and combination rules are documented in the canonical state-matrix artifact.

## Content guidance

- Labels should be specific to the user action or data object.
- Avoid internal abbreviations unless already defined in the same surface.
- For PolicyOS governance flows, include evidence, confidence or reviewer context where it changes the decision.
