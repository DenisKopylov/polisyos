# GovernanceGate

**Status:** stable  
**Owner:** Design System / PolicyOS Domain  
**Source:** `packages/atlas-ui/src/components/GovernanceGate/GovernanceGate.tsx`

## Usage

Use `GovernanceGate` when the product needs the stable Atlas implementation rather than a screen-local prototype pattern. Import it from `@policyos/atlas-ui` and load token CSS before component CSS.

```tsx
import { GovernanceGate } from '@policyos/atlas-ui';
```

## Style

This component must use component or semantic tokens only. Current token dependencies:

- `--success`
- `--warning`
- `--danger`
- `--atlas-panel-border`

## Code contract

- Exported from `packages/atlas-ui/src/index.ts`.
- Public props are TypeScript typed.
- Styling is class-based through `atlas-ui.css`.
- Do not introduce raw `#hex`, `rgb()` or `rgba()` values in component source.

## Accessibility

- status announced in aria-label.
- badge plus text status.
- domain pattern not generic alert.
- Use semantic text in addition to color for status or severity.

## State matrix

Canonical v11 state contract: `component-library/state-matrix/components/governance-gate.md` and `component-library/state-matrix/component-state-matrix.json#/components/GovernanceGate`.

| State | Kind | Trigger | DOM / ARIA contract | Priority |
|---|---|---|---|---|
| `pass` | domain-status | status="pass". | Status badge can announce dynamic change with role=status. | P0 |
| `review` | domain-status | status="review". | Status text and description explain pending review. | P0 |
| `blocked` | domain-status | status="blocked". | Description must identify blocker or next step. | P0 |
| `with-evidence-count` | content | evidenceCount is a number. | Count appears as text, not only visual badge. | P0 |
| `with-action` | content | action prop is provided. | Action keeps native semantics. | P0 |
| `stale-evidence` | domain-status | Consumer uses review/blocked plus stale evidence copy. | Evidence freshness is textual. | P1 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | No semantic change; forced-colors uses system colors where appropriate. | P0 |
| `reduced-motion` | mode | User sets prefers-reduced-motion: reduce. | No semantic change; loading labels remain exposed. | P0 |
| `density` | mode | Container or product shell applies a density mode. | No semantic change. | P1 |

Rejected states and combination rules are documented in the canonical state-matrix artifact.

## Content guidance

- Labels should be specific to the user action or data object.
- Avoid internal abbreviations unless already defined in the same surface.
- For PolicyOS governance flows, include evidence, confidence or reviewer context where it changes the decision.
