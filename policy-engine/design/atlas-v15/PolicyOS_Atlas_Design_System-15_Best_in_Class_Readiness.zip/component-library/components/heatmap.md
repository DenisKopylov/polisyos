
# Heatmap

**Status:** beta  
**Owner:** Design System / Data Visualization  
**Source:** `packages/atlas-ui/src/components/DataVisualization/Heatmap.tsx`

## Usage

Use `Heatmap` as part of the Atlas Data Visualization System when a PolicyOS surface needs production chart evidence rather than a screen-local SVG or canvas prototype. The component must be paired with `ChartFrame` summary/source context and, when exact values matter, `ChartDataTable`.

```tsx
import { Heatmap } from '@policyos/atlas-ui';
```

## Style

This component uses data-viz tokens only. Current token dependencies:

- `--atlas-viz-canvas-surface`
- `--atlas-viz-series-1`
- `--atlas-viz-axis`
- `--atlas-viz-grid`

Do not introduce raw color values in component source. Add chart-specific needs to `tokens/source/data-viz.tokens.json`.

## Code contract

- Exported from `packages/atlas-ui/src/index.ts`.
- Public props are TypeScript typed.
- Styling is class-based through `atlas-ui.css`.
- Runtime hooks: `data-atlas-component="Heatmap"` and `data-state`.
- The canonical chart grammar lives in `data-visualization/data-viz-manifest.json`.

## Accessibility

- Every production use needs a short text summary.
- Every decision-relevant chart needs a data-table equivalent or linked data download.
- Do not rely on color alone; pair color with label, shape, dash pattern or table values.
- SVG charts use title/description semantics; focusable graph nodes expose meaningful names.

## State matrix

Canonical v14 state contract: `component-library/state-matrix/components/heatmap.md` and `component-library/state-matrix/component-state-matrix.json#/components/Heatmap`.

| State | Kind | Trigger | DOM / ARIA contract | Priority |
|---|---|---|---|---|
| default | content | Heatmap receives valid chart content or dataset. | Root exposes data-atlas-component and data-state hooks; SVG charts expose title/description where applicable. | P0 |
| text-summary | accessibility | Consumer provides decision-relevant summary copy. | Summary is referenced by ChartFrame aria-describedby or duplicated in SVG desc. | P0 |
| data-table-equivalent | accessibility | Chart values affect a decision or need exact reading. | Table uses caption, headers and row labels for assistive technology. | P0 |
| no-color-alone | accessibility | Series/status/threshold meaning is color-coded. | Meaning remains available without color perception. | P0 |
| focus-visible | interaction | Focusable graph nodes or tooltip triggers receive keyboard focus. | Focusable SVG groups or controls expose meaningful aria-label. | P0 |
| high-contrast | mode | User enables high-contrast or forced-colors mode. | No semantic change; color-only meaning remains forbidden. | P0 |
| density | mode | Dashboard shell applies comfortable, compact or condensed density. | No semantic change. | P1 |
| reduced-motion | mode | User sets prefers-reduced-motion: reduce. | Live summaries remain available when animation is removed. | P1 |

Rejected states and combination rules are documented in the canonical state-matrix artifact.

## Content guidance

- Summaries should state the decision-relevant takeaway, not merely describe the chart shape.
- Include units, population, time period and source when relevant.
- For PolicyOS governance flows, name uncertainty, provenance, stale evidence and reviewer state explicitly.
