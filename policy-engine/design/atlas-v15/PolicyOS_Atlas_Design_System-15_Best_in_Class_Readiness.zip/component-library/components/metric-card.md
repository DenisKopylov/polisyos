# MetricCard

**Status:** stable  
**Owner:** Design System / Data Display  
**Source:** `packages/atlas-ui/src/components/MetricCard/MetricCard.tsx`

## Usage

Use `MetricCard` when the product needs the stable Atlas implementation rather than a screen-local prototype pattern. Import it from `@policyos/atlas-ui` and load token CSS before component CSS.

```tsx
import { MetricCard } from '@policyos/atlas-ui';
```

## Style

This component must use component or semantic tokens only. Current token dependencies:

- `--atlas-metric-surface`
- `--atlas-metric-label`
- `--atlas-metric-hint`

## Code contract

- Exported from `packages/atlas-ui/src/index.ts`.
- Public props are TypeScript typed.
- Styling is class-based through `atlas-ui.css`.
- Do not introduce raw `#hex`, `rgb()` or `rgba()` values in component source.

## Accessibility

- machine-readable aria-label.
- badge must not be only status carrier.
- Do not rely on color alone for meaning.

## State matrix

Canonical v11 state contract: `component-library/state-matrix/components/metric-card.md` and `component-library/state-matrix/component-state-matrix.json#/components/MetricCard`.

| State | Kind | Trigger | DOM / ARIA contract | Priority |
|---|---|---|---|---|
| `default` | content | label and value are provided. | section has synthesized aria-label label/value/hint. | P0 |
| `with-badge` | content | badge prop is provided. | Badge keeps its own status semantics. | P0 |
| `large-value` | content | Value is multi-digit or percentage. | Accessible label includes value as string. | P1 |
| `stale` | status | Consumer composes warning badge/hint for stale data. | Status must be in text, not only color. | P1 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | No semantic change; forced-colors uses system colors where appropriate. | P0 |
| `reduced-motion` | mode | User sets prefers-reduced-motion: reduce. | No semantic change; loading labels remain exposed. | P0 |
| `density` | mode | Container or product shell applies a density mode. | No semantic change. | P1 |

Rejected states and combination rules are documented in the canonical state-matrix artifact.

## Content guidance

- Labels should be specific to the user action or data object.
- Avoid internal abbreviations unless already defined in the same surface.
- For PolicyOS governance flows, include evidence, confidence or reviewer context where it changes the decision.
