# Panel

**Status:** stable  
**Owner:** Design System / UI Foundations  
**Source:** `packages/atlas-ui/src/components/Panel/Panel.tsx`

## Usage

Use `Panel` when the product needs the stable Atlas implementation rather than a screen-local prototype pattern. Import it from `@policyos/atlas-ui` and load token CSS before component CSS.

```tsx
import { Panel } from '@policyos/atlas-ui';
```

## Style

This component must use component or semantic tokens only. Current token dependencies:

- `--atlas-panel-surface`
- `--atlas-panel-border`
- `--radius-card`

## Code contract

- Exported from `packages/atlas-ui/src/index.ts`.
- Public props are TypeScript typed.
- Styling is class-based through `atlas-ui.css`.
- Do not introduce raw `#hex`, `rgb()` or `rgba()` values in component source.

## Accessibility

- section landmark semantics.
- aria-labelledby from title.
- explicit heading-level prop.
- Do not rely on color alone for meaning.

## State matrix

Canonical v11 state contract: `component-library/state-matrix/components/panel.md` and `component-library/state-matrix/component-state-matrix.json#/components/Panel`.

| State | Kind | Trigger | DOM / ARIA contract | Priority |
|---|---|---|---|---|
| `default` | layout | Panel renders without hero or actions. | section labelled by heading when title exists. | P0 |
| `hero` | variant | hero=true. | No semantic change. | P0 |
| `with-actions` | content | actions prop is provided. | Action controls keep their own semantics. | P0 |
| `nested` | layout | Panel is placed inside another surface. | Heading level must be chosen to preserve document outline. | P0 |
| `busy` | async | Consumer passes aria-busy=true while panel content refreshes. | aria-busy=true belongs on the section. | P1 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | No semantic change; forced-colors uses system colors where appropriate. | P0 |
| `reduced-motion` | mode | User sets prefers-reduced-motion: reduce. | No semantic change; loading labels remain exposed. | P0 |
| `density` | mode | Container or product shell applies a density mode. | No semantic change. | P1 |

Rejected states and combination rules are documented in the canonical state-matrix artifact.

## Content guidance

- Labels should be specific to the user action or data object.
- Avoid internal abbreviations unless already defined in the same surface.
- For PolicyOS governance flows, include evidence, confidence or reviewer context where it changes the decision.
