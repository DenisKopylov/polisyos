# ProvenanceGraph

**Status:** beta  
**Owner:** Design System / Data Visualization  
**Source:** `packages/atlas-ui/src/components/DataVisualization/ProvenanceGraph.tsx`

## Usage

Use `ProvenanceGraph` as part of the Atlas data visualization system when PolicyOS needs a reusable, tokenized and accessible chart primitive rather than a screen-local drawing. Import it from `@policyos/atlas-ui` and pair it with the canonical chart grammar.

```tsx
import { ProvenanceGraph } from '@policyos/atlas-ui';
```

## Style

This component uses component or semantic tokens only. Core token dependencies:

- `--atlas-dataviz-surface-subtle`
- `--atlas-dataviz-border`
- `--atlas-series-teal`
- `--atlas-series-ember`

## Code contract

- Exported from `packages/atlas-ui/src/index.ts`.
- Public props are TypeScript typed.
- Styling is class-based through `atlas-ui.css`.
- Do not introduce raw `#hex`, `rgb()` or `rgba()` values in component source.
- Use the data visualization manifest for chart selection and accessibility expectations.

## Accessibility

- Provide a chart title and a concise summary.
- Complex charts require a long description or data table equivalent.
- Color must not be the only carrier of meaning.
- Interactive marks must be keyboard reachable before being released as stable.

## State matrix

Canonical v14 state contract: `component-library/state-matrix/components/provenance-graph.md` and `component-library/state-matrix/component-state-matrix.json#/components/ProvenanceGraph`.

## Content guidance

- Title the chart as the user question or the decision insight.
- Summaries should state the key finding, threshold breach, uncertainty or missing-data caveat.
- Use units, sample sizes and freshness notes when the chart informs a governance decision.
