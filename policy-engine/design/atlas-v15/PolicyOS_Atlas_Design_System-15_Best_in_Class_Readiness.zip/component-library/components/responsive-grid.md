# ResponsiveGrid

**Status:** stable  
**Owner:** Design System / Layout Primitives  
**Source:** `packages/atlas-ui/src/components/DashboardShell/ResponsiveGrid.tsx`

## Usage

Use `ResponsiveGrid` for the v13 responsive dashboard model. Container-aware wrapping grid for metric cards, evidence cards and summary cards.

```tsx
import { ResponsiveGrid } from '@policyos/atlas-ui';
```

## Style

This component is token-only. Current token dependencies:

- `--atlas-responsive-grid-min-column`
- `--atlas-responsive-grid-dense-min-column`
- `--atlas-responsive-grid-wide-min-column`
- `--atlas-responsive-grid-gap`

## Code contract

- Exported from `packages/atlas-ui/src/index.ts`.
- Public props are TypeScript typed.
- Styling is class-based through `atlas-ui.css`.
- Do not introduce raw `#hex`, `rgb()` or `rgba()` values in component source.
- Dashboard chrome adapts by viewport; content inside `DashboardMain` should prefer container-aware primitives.

## Accessibility

- visual reflow does not change DOM order.
- supports zoom and narrow containers.
- no content is hidden by breakpoint alone.

## State matrix

Canonical v13 state contract: `component-library/state-matrix/components/responsive-grid.md` and `component-library/state-matrix/component-state-matrix.json#/components/ResponsiveGrid`.

| State | Kind | Trigger | DOM / ARIA contract | Priority |
|---|---|---|---|---|
| `default` | layout | Component enters `default` state. | Exposed through native landmarks, ARIA or `data-state`/responsive CSS without changing DOM order. | P0 |
| `dense` | layout | Component enters `dense` state. | Exposed through native landmarks, ARIA or `data-state`/responsive CSS without changing DOM order. | P0 |
| `wide` | layout | Component enters `wide` state. | Exposed through native landmarks, ARIA or `data-state`/responsive CSS without changing DOM order. | P0 |
| `single-column` | layout | Component enters `single-column` state. | Exposed through native landmarks, ARIA or `data-state`/responsive CSS without changing DOM order. | P0 |
| `multi-column` | layout | Component enters `multi-column` state. | Exposed through native landmarks, ARIA or `data-state`/responsive CSS without changing DOM order. | P0 |

Rejected states and combination rules are documented in the canonical state-matrix artifact.

## Content guidance

- Keep route titles short enough for compact topbars.
- Do not remove evidence, confidence, reviewer or governance context at narrow widths.
- Prefer local scrolling or card alternatives for dense data instead of whole-page horizontal scrolling.
