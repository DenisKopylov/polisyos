# RunCard

**Status:** stable  
**Owner:** Design System / PolicyOS Domain  
**Source:** `packages/atlas-ui/src/components/RunCard/RunCard.tsx`

## Usage

Use `RunCard` when the product needs the stable Atlas implementation rather than a screen-local prototype pattern. Import it from `@policyos/atlas-ui` and load token CSS before component CSS.

```tsx
import { RunCard } from '@policyos/atlas-ui';
```

## Style

This component must use component or semantic tokens only. Current token dependencies:

- `--atlas-metric-surface`
- `--atlas-panel-border`

## Code contract

- Exported from `packages/atlas-ui/src/index.ts`.
- Public props are TypeScript typed.
- Styling is class-based through `atlas-ui.css`.
- Do not introduce raw `#hex`, `rgb()` or `rgba()` values in component source.

## Accessibility

- native button behavior.
- status included in accessible label.
- artifacts and duration announced.
- Use semantic text in addition to color for status or severity.

## State matrix

Canonical v11 state contract: `component-library/state-matrix/components/run-card.md` and `component-library/state-matrix/component-state-matrix.json#/components/RunCard`.

| State | Kind | Trigger | DOM / ARIA contract | Priority |
|---|---|---|---|---|
| `default` | interaction | RunCard is enabled and idle. | Native semantic element remains available to keyboard and assistive tech. | P0 |
| `hover` | interaction | Pointer enters enabled control. | No ARIA change. | P0 |
| `focus-visible` | interaction | Keyboard, switch control or programmatic focus reaches the element. | Native focus target or roving tabindex target. | P0 |
| `active` | interaction | Pointer down, Enter or Space activation. | Native activation event fires once. | P0 |
| `disabled` | interaction | Action is unavailable or blocked by permissions/prerequisites. | Use native disabled where possible; otherwise aria-disabled with blocked handlers. | P0 |
| `success` | status | status="success". | Status included in aria-label. | P0 |
| `failed` | status | status="failed". | Status included in aria-label. | P0 |
| `blocked` | status | status="blocked". | Status included in aria-label. | P0 |
| `running` | status | status="running". | Status included in aria-label. | P0 |
| `pending` | status | status="pending". | Status included in aria-label. | P0 |
| `review` | status | status="review". | Status included in aria-label. | P0 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | No semantic change; forced-colors uses system colors where appropriate. | P0 |
| `reduced-motion` | mode | User sets prefers-reduced-motion: reduce. | No semantic change; loading labels remain exposed. | P0 |
| `density` | mode | Container or product shell applies a density mode. | No semantic change. | P1 |

Rejected states and combination rules are documented in the canonical state-matrix artifact.

## Content guidance

- Labels should be specific to the user action or data object.
- Avoid internal abbreviations unless already defined in the same surface.
- For PolicyOS governance flows, include evidence, confidence or reviewer context where it changes the decision.
