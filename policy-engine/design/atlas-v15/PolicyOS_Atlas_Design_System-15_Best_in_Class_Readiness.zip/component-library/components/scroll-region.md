# ScrollRegion

**Status:** stable  
**Owner:** Design System / Responsive Layout  
**Source:** `packages/atlas-ui/src/components/Responsive/ScrollRegion.tsx`

## Usage

Use `ScrollRegion` for production responsive dashboard layouts rather than screen-local prototype CSS. Import it from `@policyos/atlas-ui` and load token CSS before component CSS.

```tsx
import { ScrollRegion } from '@policyos/atlas-ui';
```

## Style

This component uses responsive component tokens only. Current token dependencies:

- `--atlas-scroll-region-border`
- `--atlas-scroll-region-surface`
- `--atlas-scroll-region-radius`
- `--atlas-scroll-region-shadow`

## Code contract

- Exported from `packages/atlas-ui/src/index.ts`.
- Public props are TypeScript typed.
- Styling is class-based through `atlas-ui.css`.
- Do not introduce raw `#hex`, `rgb()` or `rgba()` values in component source.
- Canonical responsive behavior is documented in `dashboard-responsive/responsive-contract.json`.

## Accessibility

- optional region role.
- aria-label for named scroll areas.
- keyboard focusable when needed.
- focus ring must not be clipped.

## State matrix

Canonical v13 state contract: `component-library/state-matrix/components/scroll-region.md` and `component-library/state-matrix/component-state-matrix.json#/components/ScrollRegion`.

| State | Kind | Trigger | DOM / ARIA contract | Priority |
|---|---|---|---|---|
| `overflow-ready` | layout | See canonical matrix. | DOM order and landmarks remain stable. | P0 |
| `horizontal` | layout | See canonical matrix. | DOM order and landmarks remain stable. | P0 |
| `vertical` | layout | See canonical matrix. | DOM order and landmarks remain stable. | P0 |
| `both-axes` | layout | See canonical matrix. | DOM order and landmarks remain stable. | P0 |
| `keyboard-focus` | layout | See canonical matrix. | DOM order and landmarks remain stable. | P0 |
| `high-contrast` | layout | See canonical matrix. | DOM order and landmarks remain stable. | P0 |
| `density` | layout | See canonical matrix. | DOM order and landmarks remain stable. | P0 |

Rejected states and combination rules are documented in the canonical state-matrix artifact.

## Content guidance

- Preserve governance, evidence and error context when stacking.
- Do not hide important dashboard controls solely to fit a viewport.
- Prefer explicit labels for scroll regions and drawer controls.
