# SelectField

**Status:** stable  
**Owner:** Design System / Forms  
**Source:** `packages/atlas-ui/src/components/Field/SelectField.tsx`

## Usage

Use `SelectField` when the product needs the stable Atlas implementation rather than a screen-local prototype pattern. Import it from `@policyos/atlas-ui` and load token CSS before component CSS.

```tsx
import { SelectField } from '@policyos/atlas-ui';
```

## Style

This component must use component or semantic tokens only. Current token dependencies:

- `--atlas-button-ghost-border`
- `--surface`
- `--danger`

## Code contract

- Exported from `packages/atlas-ui/src/index.ts`.
- Public props are TypeScript typed.
- Styling is class-based through `atlas-ui.css`.
- Do not introduce raw `#hex`, `rgb()` or `rgba()` values in component source.

## Accessibility

- native select semantics.
- label is required.
- error sets aria-invalid.
- Do not rely on color alone for meaning.

## State matrix

Canonical v11 state contract: `component-library/state-matrix/components/select-field.md` and `component-library/state-matrix/component-state-matrix.json#/components/SelectField`.

| State | Kind | Trigger | DOM / ARIA contract | Priority |
|---|---|---|---|---|
| `placeholder` | input | placeholder prop renders disabled empty option. | Native select/option semantics. | P0 |
| `selected` | input | value/defaultValue or user selection exists. | Native select value is available. | P0 |
| `open-native` | interaction | User opens browser/OS select popup. | Native combobox/select semantics. | P1 |
| `focus-visible` | interaction | Keyboard focus reaches select. | Native select focus. | P0 |
| `required` | validation | required=true. | required and aria-required set. | P0 |
| `invalid` | validation | error prop is provided. | aria-invalid=true and error id in aria-describedby. | P0 |
| `disabled` | interaction | disabled=true. | Native disabled removes from tab order. | P0 |
| `option-disabled` | input | option.disabled=true. | Native option disabled attribute. | P1 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | No semantic change; forced-colors uses system colors where appropriate. | P0 |
| `reduced-motion` | mode | User sets prefers-reduced-motion: reduce. | No semantic change; loading labels remain exposed. | P0 |
| `density` | mode | Container or product shell applies a density mode. | No semantic change. | P1 |

Rejected states and combination rules are documented in the canonical state-matrix artifact.

## Content guidance

- Labels should be specific to the user action or data object.
- Avoid internal abbreviations unless already defined in the same surface.
- For PolicyOS governance flows, include evidence, confidence or reviewer context where it changes the decision.
