# Skeleton

**Status:** stable  
**Owner:** Design System / Feedback  
**Source:** `packages/atlas-ui/src/components/Skeleton/Skeleton.tsx`

## Usage

Use `Skeleton` when the product needs the stable Atlas implementation rather than a screen-local prototype pattern. Import it from `@policyos/atlas-ui` and load token CSS before component CSS.

```tsx
import { Skeleton } from '@policyos/atlas-ui';
```

## Style

This component must use component or semantic tokens only. Current token dependencies:

- `--surface`
- `--panel-strong`
- `--motion-reduced-duration`

## Code contract

- Exported from `packages/atlas-ui/src/index.ts`.
- Public props are TypeScript typed.
- Styling is class-based through `atlas-ui.css`.
- Do not introduce raw `#hex`, `rgb()` or `rgba()` values in component source.

## Accessibility

- role=status.
- requires label.
- reduced-motion support.
- Do not rely on color alone for meaning.

## State matrix

Canonical v11 state contract: `component-library/state-matrix/components/skeleton.md` and `component-library/state-matrix/component-state-matrix.json#/components/Skeleton`.

| State | Kind | Trigger | DOM / ARIA contract | Priority |
|---|---|---|---|---|
| `loading` | async | Content is not ready. | role=status with polite loading label. | P0 |
| `reduced-motion` | mode | prefers-reduced-motion: reduce. | Loading label remains available. | P0 |
| `compact-density` | mode | Density mode reduces layout spacing. | No semantic change. | P1 |
| `composed-region-busy` | a11y | Skeleton appears inside aria-busy region. | Parent region may set aria-busy=true. | P1 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | No semantic change; forced-colors uses system colors where appropriate. | P0 |

Rejected states and combination rules are documented in the canonical state-matrix artifact.

## Content guidance

- Labels should be specific to the user action or data object.
- Avoid internal abbreviations unless already defined in the same surface.
- For PolicyOS governance flows, include evidence, confidence or reviewer context where it changes the decision.
