# Tabs

**Status:** beta  
**Owner:** Design System / Navigation  
**Source:** `packages/atlas-ui/src/components/Tabs/Tabs.tsx`

## Usage

Use `Tabs` when the product needs the stable Atlas implementation rather than a screen-local prototype pattern. Import it from `@policyos/atlas-ui` and load token CSS before component CSS.

```tsx
import { Tabs } from '@policyos/atlas-ui';
```

## Style

This component must use component or semantic tokens only. Current token dependencies:

- `--line`
- `--accent`
- `--target-min-compact`

## Code contract

- Exported from `packages/atlas-ui/src/index.ts`.
- Public props are TypeScript typed.
- Styling is class-based through `atlas-ui.css`.
- Do not introduce raw `#hex`, `rgb()` or `rgba()` values in component source.

## Accessibility

- role=tablist/tab/tabpanel.
- ArrowLeft/ArrowRight/Home/End support.
- selected tab has tabIndex=0.
- Do not rely on color alone for meaning.

## State matrix

Canonical v11 state contract: `component-library/state-matrix/components/tabs.md` and `component-library/state-matrix/component-state-matrix.json#/components/Tabs`.

| State | Kind | Trigger | DOM / ARIA contract | Priority |
|---|---|---|---|---|
| `selected` | selection | Item id equals active value. | aria-selected=true; tabIndex=0; controls selected panel. | P0 |
| `default` | selection | Tab is enabled but not selected. | aria-selected=false; tabIndex=-1. | P0 |
| `hover` | interaction | Pointer enters enabled tab. | No ARIA change. | P0 |
| `focus-visible` | interaction | Keyboard focus reaches selected tab. | Roving tabindex keeps one tab in tab order. | P0 |
| `disabled-tab` | interaction | item.disabled=true. | Native disabled button; skipped by arrow navigation. | P0 |
| `keyboard-navigation` | interaction | ArrowLeft/ArrowRight/Home/End. | role=tablist/tab/tabpanel relationships remain valid. | P0 |
| `overflow-review` | layout | Tab labels exceed available width. | No semantic change. | P1 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | No semantic change; forced-colors uses system colors where appropriate. | P0 |
| `reduced-motion` | mode | User sets prefers-reduced-motion: reduce. | No semantic change; loading labels remain exposed. | P0 |
| `density` | mode | Container or product shell applies a density mode. | No semantic change. | P1 |

Rejected states and combination rules are documented in the canonical state-matrix artifact.

## Content guidance

- Labels should be specific to the user action or data object.
- Avoid internal abbreviations unless already defined in the same surface.
- For PolicyOS governance flows, include evidence, confidence or reviewer context where it changes the decision.
