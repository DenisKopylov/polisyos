# TextArea

**Status:** stable  
**Owner:** Design System / Forms  
**Source:** `packages/atlas-ui/src/components/Field/TextArea.tsx`

## Usage

Use `TextArea` for multi-line operator input: scenario rationale, reviewer notes, evidence caveats and decision packet explanations. Import it from `@policyos/atlas-ui` and load token CSS before component CSS.

```tsx
import { TextArea } from '@policyos/atlas-ui';
```

## Style

This component uses the same field token contract as `TextField` so single-line and multi-line controls stay visually aligned.

- `--atlas-button-ghost-border`
- `--surface`
- `--danger`

## Code contract

- Exported from `packages/atlas-ui/src/index.ts`.
- Public props are TypeScript typed.
- `rows` defaults to `4` and can be overridden by the consuming flow.
- `label`, `description` and `error` are wired to the control through generated ids.
- Styling is class-based through `atlas-ui.css`.
- Do not introduce raw `#hex`, `rgb()` or `rgba()` values in component source.

## Accessibility

- Label is required and connected with `htmlFor` / `id`.
- Description and error text are connected with `aria-describedby`.
- Error sets `aria-invalid`.
- Required state exposes native `required` and `aria-required`.
- Do not rely on color alone for validation meaning.

## State matrix

Canonical v11 state contract: `component-library/state-matrix/components/text-area.md` and `component-library/state-matrix/component-state-matrix.json#/components/TextArea`.

| State | Kind | Trigger | DOM / ARIA contract | Priority |
|---|---|---|---|---|
| `empty` | input | No value or defaultValue is supplied. | Label remains associated with control. | P0 |
| `filled` | input | value/defaultValue is supplied or user enters data. | Value is available in native input. | P0 |
| `hover` | interaction | Pointer enters enabled editable control. | No ARIA change. | P0 |
| `focus-visible` | interaction | Keyboard/switch focus reaches control. | Native focus target. | P0 |
| `required` | validation | required=true. | required and aria-required are set. | P0 |
| `invalid` | validation | error prop is provided. | aria-invalid=true and error id is included in aria-describedby. | P0 |
| `disabled` | interaction | disabled=true. | Native disabled removes from tab order. | P0 |
| `readonly` | input | readOnly=true where supported. | readOnly attribute on native input/textarea. | P0 |
| `multiline-overflow` | layout | Text exceeds visible rows. | Native textarea value remains accessible. | P1 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | No semantic change; forced-colors uses system colors where appropriate. | P0 |
| `reduced-motion` | mode | User sets prefers-reduced-motion: reduce. | No semantic change; loading labels remain exposed. | P0 |
| `density` | mode | Container or product shell applies a density mode. | No semantic change. | P1 |

Rejected states and combination rules are documented in the canonical state-matrix artifact.

## Content guidance

- Labels should describe the decision artifact, not the UI shape.
- Helper text should tell operators what evidence or assumptions belong in the field.
- Error text should be corrective and specific.
