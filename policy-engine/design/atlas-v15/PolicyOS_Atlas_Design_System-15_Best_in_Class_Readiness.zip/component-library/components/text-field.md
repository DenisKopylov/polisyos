# TextField

**Status:** stable  
**Owner:** Design System / Forms  
**Source:** `packages/atlas-ui/src/components/Field/TextField.tsx`

## Usage

Use `TextField` when the product needs the stable Atlas implementation rather than a screen-local prototype pattern. Import it from `@policyos/atlas-ui` and load token CSS before component CSS.

```tsx
import { TextField } from '@policyos/atlas-ui';
```

## Style

This component must use component or semantic tokens only. Current token dependencies:

- `--atlas-button-ghost-border`
- `--surface`
- `--danger`

## Code contract

- Exported from `packages/atlas-ui/src/index.ts`.
- Public props are TypeScript typed.
- Styling is class-based through `atlas-ui.css`.
- Do not introduce raw `#hex`, `rgb()` or `rgba()` values in component source.

## Accessibility

- label is required.
- description/error connected with aria-describedby.
- error sets aria-invalid.
- Do not rely on color alone for meaning.

## State matrix

Canonical v11 state contract: `component-library/state-matrix/components/text-field.md` and `component-library/state-matrix/component-state-matrix.json#/components/TextField`.

| State | Kind | Trigger | DOM / ARIA contract | Priority |
|---|---|---|---|---|
| `empty` | input | No value or defaultValue is supplied. | Label remains associated with control. | P0 |
| `filled` | input | value/defaultValue is supplied or user enters data. | Value is available in native input. | P0 |
| `hover` | interaction | Pointer enters enabled editable control. | No ARIA change. | P0 |
| `focus-visible` | interaction | Keyboard/switch focus reaches control. | Native focus target. | P0 |
| `required` | validation | required=true. | required and aria-required are set. | P0 |
| `invalid` | validation | error prop is provided. | aria-invalid=true and error id is included in aria-describedby. | P0 |
| `disabled` | interaction | disabled=true. | Native disabled removes from tab order. | P0 |
| `readonly` | input | readOnly=true where supported. | readOnly attribute on native input/textarea. | P0 |
| `autocomplete` | input | autoComplete attribute is provided. | Native autocomplete hint is passed through. | P1 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | No semantic change; forced-colors uses system colors where appropriate. | P0 |
| `reduced-motion` | mode | User sets prefers-reduced-motion: reduce. | No semantic change; loading labels remain exposed. | P0 |
| `density` | mode | Container or product shell applies a density mode. | No semantic change. | P1 |

Rejected states and combination rules are documented in the canonical state-matrix artifact.

## Content guidance

- Labels should be specific to the user action or data object.
- Avoid internal abbreviations unless already defined in the same surface.
- For PolicyOS governance flows, include evidence, confidence or reviewer context where it changes the decision.
