# Toast

**Status:** stable  
**Owner:** Design System / Feedback  
**Source:** `packages/atlas-ui/src/components/Toast/Toast.tsx`

## Usage

Use `Toast` when the product needs the stable Atlas implementation rather than a screen-local prototype pattern. Import it from `@policyos/atlas-ui` and load token CSS before component CSS.

```tsx
import { Toast } from '@policyos/atlas-ui';
```

## Style

This component must use component or semantic tokens only. Current token dependencies:

- `--atlas-panel-border`
- `--panel-strong`
- `--success`
- `--danger`

## Code contract

- Exported from `packages/atlas-ui/src/index.ts`.
- Public props are TypeScript typed.
- Styling is class-based through `atlas-ui.css`.
- Do not introduce raw `#hex`, `rgb()` or `rgba()` values in component source.

## Accessibility

- role=status for non-critical.
- role=alert for danger.
- polite/assertive live regions.
- Use semantic text in addition to color for status or severity.

## State matrix

Canonical v11 state contract: `component-library/state-matrix/components/toast.md` and `component-library/state-matrix/component-state-matrix.json#/components/Toast`.

| State | Kind | Trigger | DOM / ARIA contract | Priority |
|---|---|---|---|---|
| `info` | feedback | tone="info". | role=status and aria-live=polite. | P0 |
| `success` | feedback | tone="success". | role=status and aria-live=polite. | P0 |
| `warning` | feedback | tone="warning". | role=status and aria-live=polite. | P0 |
| `danger` | feedback | tone="danger". | role=alert and aria-live=assertive. | P0 |
| `with-action` | content | action prop provided. | Action preserves its own accessible name. | P0 |
| `reduced-motion` | mode | User prefers reduced motion. | No semantic change. | P0 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | No semantic change; forced-colors uses system colors where appropriate. | P0 |
| `density` | mode | Container or product shell applies a density mode. | No semantic change. | P1 |

Rejected states and combination rules are documented in the canonical state-matrix artifact.

## Content guidance

- Labels should be specific to the user action or data object.
- Avoid internal abbreviations unless already defined in the same surface.
- For PolicyOS governance flows, include evidence, confidence or reviewer context where it changes the decision.
