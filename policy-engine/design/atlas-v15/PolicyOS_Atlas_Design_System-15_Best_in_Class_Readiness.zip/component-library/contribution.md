# Component contribution process

1. Start with a component RFC: problem, users, examples, non-goals and alternatives.
2. Add or reuse semantic/component tokens. Do not bind production components to primitive colors directly unless the token contract allows it.
3. Implement the component in `packages/atlas-ui/src/components` with typed props.
4. Add CSS in `packages/atlas-ui/src/atlas-ui.css` using token variables only.
5. Add Storybook-ready stories.
6. Add docs in `component-library/components/<component>.md`.
7. Add/update `component-library/component-manifest.json`.
8. Run `npm run verify`.
9. Record breaking changes in `packages/atlas-ui/CHANGELOG.md` and migration docs.

## API rules

- Prefer native HTML elements over custom roles.
- Prefer controlled and uncontrolled support only when both are tested.
- Every interactive component must forward refs.
- Every form control must require or generate an id and wire label, description and error states.
- Component variants must map to component tokens, not raw colors.
