# Atlas dashboard responsive model

**Version:** `13.0.0-dashboard-responsive`  
**Scope:** `ui_kits/dashboard`, `packages/atlas-ui/src/components/Responsive`, generated token outputs, and release gates.

This layer converts the dashboard from a desktop-scaled prototype into a production responsive shell. The contract is mobile-first, density-aware, accessible by keyboard and coarse pointer, and safe for public-sector evidence review surfaces.

## What is covered

- Breakpoint taxonomy from handset to operator wall.
- Persistent rail on desktop, compact rail on laptops, modal drawer on tablet/phone.
- Adaptive grids for hero, metrics, charts and cards.
- Horizontal scroll regions for genuinely data-dense surfaces.
- Touch target handling for coarse pointers.
- Print/export mode for decision packets and governance reviews.
- Static release gate in `scripts/responsive_lint.py`.

## Contract files

- `dashboard-responsive/responsive-contract.json`
- `dashboard-responsive/breakpoints.md`
- `dashboard-responsive/shell-behavior.md`
- `dashboard-responsive/data-dense-surfaces.md`
- `dashboard-responsive/print-export.md`
- `dashboard-responsive/responsive-audit.md`

## Consumer API

```tsx
import { DashboardShell, DashboardTopBar, ResponsiveGrid, ScrollRegion } from '@policyos/atlas-ui';
import '@policyos/atlas-ui/css';
```

Use `ResponsiveGrid` for product layouts rather than hard-coded `gridTemplateColumns`. Use `ScrollRegion` when the user benefits from preserving table columns instead of stacking content.
