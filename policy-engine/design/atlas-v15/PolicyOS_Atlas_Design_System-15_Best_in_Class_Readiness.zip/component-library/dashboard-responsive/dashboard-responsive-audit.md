# Atlas Dashboard Responsive Audit

Generated: `2026-06-09T18:11:18Z`

## Gate summary

- Window classes: **5**
- Required window classes: **5**
- Breakpoints: **7**
- Shell modes: **6**
- Layout patterns: **5**
- Responsive tokens checked: **10**
- Acceptance criteria: **18**
- Navigation modes covered: **expanded rail / icon rail / modal drawer / compact bottom nav**
- Data behavior covered: **wrapping grid / named local scroll / stacked table cards**
- Blockers: **0**
- Warnings: **0**

## Findings

| Severity | Subject | Message |
|---|---|---|
| — | — | No findings. |

## Evidence

- `dashboard-responsive/responsive-manifest.json` defines canonical window classes, layout patterns and acceptance criteria.
- `packages/atlas-ui/src/atlas-ui.css` provides token-only shell, drawer, rail, grid, pane and scroll-region behavior.
- `ui_kits/dashboard/index.html` consumes the class-based shell, sticky topbar, controlled drawer and compact bottom navigation.
- `ui_kits/dashboard/Sidebar.jsx` uses native buttons with persistent accessible names in full rail, icon rail and drawer modes.
- `DataTable` exposes scroll and card reflow modes for dense policy data.
