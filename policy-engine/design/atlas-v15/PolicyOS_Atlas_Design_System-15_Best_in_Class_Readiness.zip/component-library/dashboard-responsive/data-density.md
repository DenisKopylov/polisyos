# Data density and table responsiveness

PolicyOS screens contain dense evidence, governance and run data. Atlas v13 separates data-density choices from viewport choices.

## Density

- Comfortable: default operator mode and touch-friendly default.
- Compact: desktop operator mode for tables and lists.
- Condensed: high-density audit views only; must retain readable focus and hover states.

Density is expressed with `data-density`, not ad hoc font-size overrides.

## Tables

`DataTable` now supports:

```tsx
<DataTable
  caption="Evidence sources"
  responsiveMode="cards"
  density="compact"
  columns={[{ key: 'source', header: 'Source', mobileLabel: 'Source', cell: row => row.source }]}
  rows={rows}
  getRowKey={row => row.id}
/>
```

Default `responsiveMode="scroll"` gives a keyboard-focusable region with contained horizontal scrolling. `responsiveMode="cards"` converts rows into labeled cards below 640px when the columns can be represented linearly.

## Chart and graph exception rule

Charts, DAGs, heatmaps and lineage maps may keep horizontal scrolling when compression would remove meaning. Each exception needs a text summary or equivalent data table in product implementation.
