# Operator wall responsive contract

Operator wall layouts are permitted only in the `extra-large` window class. They may use three-column or supporting-pane patterns, but the primary decision surface, provenance state, governance status and alert recovery actions must remain visible without depending on hover.

## Requirements

- Use `atlas-dashboard-three-pane` or `atlas-dashboard-supporting-pane` only when the center surface remains at a readable measure.
- Keep decision-critical controls in the main landmark; supporting panes may duplicate context but must not be the only location of an action.
- Long-running status feeds must use named scroll regions so keyboard users can enter and exit them predictably.
- Wallboard views must support reduced motion and high contrast modes.
- Print/export mode must flatten decorative chrome and avoid clipping audit trails.

## Acceptance

At 1440, 1680 and 1920 CSS pixels the operator wall must not produce horizontal page scroll, clipped focus rings or hidden provenance state. Dense tables either remain in a labelled local scroll region or switch to card summaries with row labels preserved.
