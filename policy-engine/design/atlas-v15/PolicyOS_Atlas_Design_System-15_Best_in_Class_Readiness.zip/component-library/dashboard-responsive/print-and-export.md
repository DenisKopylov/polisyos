# Print and export mode

The dashboard supports a print/export media layer for decision packets and governance review.

## Contract

- Navigation rail, mobile top bar, drawer backdrop, skip link and tweaks panel are removed.
- Shell border radius, shadow and glass effects are removed.
- Main content uses the paper surface token.
- Panels avoid page breaks where possible.
- No evidence surface should rely on hover-only disclosure before export.
