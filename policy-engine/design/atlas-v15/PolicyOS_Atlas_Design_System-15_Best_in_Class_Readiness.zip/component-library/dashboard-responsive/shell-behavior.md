# Dashboard shell behavior

## Navigation

- `xs` through `md`: navigation is a modal drawer opened by a top-bar button.
- `lg`: navigation becomes a persistent compact rail.
- `xl` and wider: navigation uses the full persistent rail.

The drawer button must expose `aria-controls="atlas-dashboard-rail"` and `aria-expanded`. Escape closes the drawer. Navigation closes after route change.

## Layout

The shell no longer uses viewport transform scaling. It uses a capped frame, CSS grid, container queries and named responsive utility classes.

## Density

`data-density="comfortable|compact|condensed"` overrides shell padding and grid gaps through token mode files. Density may reduce visual spacing, but it must not reduce interactive target guidance below the WCAG 2.2 AA floor.
