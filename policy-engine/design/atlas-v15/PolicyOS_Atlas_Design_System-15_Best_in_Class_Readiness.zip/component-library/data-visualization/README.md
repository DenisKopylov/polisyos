# Atlas data visualization components

This package layer exposes reusable primitives for production charts and evidence dashboards. The components are intentionally small: they enforce accessible framing, tokenized styling and state hooks while allowing PolicyOS teams to plug in domain-specific data.

## Components

- ChartFrame
- ChartLegend
- ChartTooltip
- Sparkline
- BarChart
- LineChart
- Heatmap
- UncertaintyBand
- ProvenanceGraph

## Release contract

Use these components with `data-visualization/data-viz-manifest.json`, `component-library/state-matrix/component-state-matrix.json` and `scripts/data_viz_lint.py`.
