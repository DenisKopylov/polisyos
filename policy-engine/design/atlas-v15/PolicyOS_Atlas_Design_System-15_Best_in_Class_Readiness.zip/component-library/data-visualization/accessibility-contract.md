# Data Visualization Accessibility Contract

## Baseline

- WCAG 2.2 AA is the target.
- Meaningful graphical objects need non-text contrast or an equivalent long description/table.
- Complex charts need a short description and a long description/data alternative.
- Do not use color alone. Add labels, shape, pattern, stroke, ordering or direct annotation.
- Interactive marks must be keyboard reachable with visible focus and accessible names.

## Screen reader model

- `ChartFrame` exposes title and summary in normal document text.
- SVG charts use `role="img"` and label/description ids.
- Dense charts provide a table/list alternative adjacent to the plot.
- Tooltips are not the only place where values are exposed.

## Keyboard model

- Static charts do not add unnecessary tab stops.
- Interactive graph nodes are native buttons or equivalent keyboard controls.
- Tooltip/details disclosure must work with keyboard and pointer.
