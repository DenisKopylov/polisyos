# Chart accessibility guidance

Use native text around the chart, avoid hover-only meaning and provide data equivalents for complex images. When chart marks become controls, they must be keyboard reachable and expose role/name/state/value.
