# Data visualization component build summary

Generated: `2026-06-09T08:53:34Z`

- Components added: **8**
- Chart types cataloged: **14**
- Manifest: `data-visualization/visualization-manifest.json`
- Package export: `@policyos/atlas-ui/data-visualization`
