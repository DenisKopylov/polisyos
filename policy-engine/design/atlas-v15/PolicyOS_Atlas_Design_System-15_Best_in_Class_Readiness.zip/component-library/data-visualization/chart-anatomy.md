# Chart anatomy

A production Atlas chart has a question, title, summary, visual area, legend, annotations, data table and export path. The visual area is never the only source of truth for critical decision data.
