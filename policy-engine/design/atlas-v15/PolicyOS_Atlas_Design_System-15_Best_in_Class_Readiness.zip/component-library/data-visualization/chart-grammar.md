# Chart Grammar

Atlas charts use a stable grammar:

1. Frame: title, summary, actions and source note.
2. Scale: x/y/category/time mapping with explicit domain decisions.
3. Axis: labelled units, grid, baseline and tick density.
4. Mark: line, bar, point, interval, node, edge or area.
5. Encoding: position first, then length/shape/stroke/pattern/color.
6. Annotation: decision-relevant callouts only.
7. Data alternative: table, list or machine-readable data reference.

## Required slots

- `title`
- `summary`
- `plot`
- `dataAlternative`

## Optional slots

- `eyebrow`
- `legend`
- `axis`
- `annotation`
- `tooltip`
- `actions`
- `sourceNote`
