# Chart Selection Guide

Choose the chart from the relationship being explained.

| Relationship | Recommended pattern | Notes |
|---|---|---|
| Time series | Line chart, sparkline | Show trend, interval and freshness. |
| Ranking / magnitude | Bar chart | Prefer horizontal bars for long labels. |
| Part-to-whole | Stacked bar | Use only when the total and contribution both matter. |
| Distribution | Histogram, dot plot, box plot | Show spread and outliers, not only average. |
| Decomposition | Waterfall | Use for additive drivers. |
| Stage conversion | Funnel | Use only for sequential stages. |
| Matrix intensity | Heatmap | Needs labels and data alternative; never color-only. |
| Flow | Sankey/flow | Label major paths and provide a table fallback. |
| Causal structure | DAG / causal graph | Separate assumptions from evidence. |
| Uncertainty | Band/fan/interval | Name the interval level and assumptions. |
| Lineage | Provenance map | Include ordered source list and freshness. |

If the message cannot be written in two or three sentences, simplify the chart or split it into multiple views.
