# Color and Encoding

Atlas uses color as a supporting channel, not the primary channel.

## Palette types

- Categorical: separate nominal series.
- Sequential: encode ordered intensity.
- Diverging: encode distance from a meaningful midpoint.
- Uncertainty: encode interval, confidence and staleness.

## Redundant encodings

Use at least one redundant signal for critical meaning:

- direct labels;
- shape;
- stroke style;
- pattern;
- ordering;
- annotation text;
- table alternative.

## Reserved semantics

- Teal/success: approved, positive, passed, improving.
- Gold/warning: pending, ambiguous, stale, review needed.
- Ember/danger: blocked, failed, high risk, adverse.
- Graphite/neutral: baseline, reference, comparison.
