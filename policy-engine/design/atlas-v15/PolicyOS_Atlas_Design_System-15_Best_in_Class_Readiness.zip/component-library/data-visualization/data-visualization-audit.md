# Atlas Data Visualization Audit

Generated: `2026-06-09T09:16:24Z`

## Gate summary

- Chart types: **16**
- Required chart types: **16**
- Data-viz components: **14**
- Required data-viz components: **14**
- Required tokens checked: **8**
- Blockers: **0**
- Warnings: **0**

## Findings

| Severity | Subject | Message |
|---|---|---|
| — | — | No findings. |

## Chart type coverage

| Chart type | Primary component | Summary | Data table | Color-only |
|---|---|---|---|---|
| `line` | `LineChart` | True | True | False |
| `sparkline` | `Sparkline` | True | True | False |
| `bar` | `BarChart` | True | True | False |
| `stacked-bar` | `BarChart` | True | True | False |
| `distribution` | `ChartFrame` | True | True | False |
| `uncertainty-band` | `UncertaintyBand` | True | True | False |
| `heatmap` | `Heatmap` | True | True | False |
| `causal-dag` | `CausalGraph` | True | True | False |
| `provenance-lineage` | `ProvenanceMap` | True | True | False |
| `waterfall` | `ChartFrame` | True | True | False |
| `timeline` | `ChartFrame` | True | True | False |
| `gantt` | `ChartFrame` | True | True | False |
| `funnel` | `ChartFrame` | True | True | False |
| `sankey` | `ChartFrame` | True | True | False |
| `scatter` | `ChartFrame` | True | True | False |
| `map` | `ChartFrame` | True | True | False |
