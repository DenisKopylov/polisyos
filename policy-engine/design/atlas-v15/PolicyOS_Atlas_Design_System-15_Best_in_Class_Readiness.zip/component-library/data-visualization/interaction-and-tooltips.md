# Interaction and Tooltips

Tooltips are convenience, not accessibility evidence.

## Rules

- Values in a tooltip must also exist in table/list data.
- Hover-only interactions are not allowed for critical content.
- Keyboard focus must reveal the same details as hover.
- Tooltip content must include label, value, unit and context.
- For dense charts, provide a focused details panel rather than huge tooltips.
