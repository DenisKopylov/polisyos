# Responsive and Export Contract

## Responsive

- Charts reflow inside their container.
- Long labels wrap or move to table/card fallback.
- Dense plots use local scroll regions only when necessary.
- Touch targets are at least the global Atlas minimum.

## Export

- PDF/export mode includes title, summary, source note and data alternative.
- SVG is preferred when a static chart image must be exported.
- Screenshots are not source evidence; export the underlying data or decision packet.
