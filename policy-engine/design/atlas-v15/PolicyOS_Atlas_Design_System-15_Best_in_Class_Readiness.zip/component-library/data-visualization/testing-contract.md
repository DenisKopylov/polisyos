# Data Visualization Testing Contract

Required release checks:

- Token lint for zero raw colors in component source.
- Component lint for docs/story/source coverage.
- State matrix lint for all chart components.
- Data-viz lint for chart grammar and accessibility evidence.
- Contrast audit for text/control pairs and non-text contrast review notes.

Recommended browser checks:

- Playwright viewport matrix.
- Axe checks in Storybook.
- Visual regression snapshots for light/dark/high contrast.
- Manual screen reader pass for complex graph interactions.
