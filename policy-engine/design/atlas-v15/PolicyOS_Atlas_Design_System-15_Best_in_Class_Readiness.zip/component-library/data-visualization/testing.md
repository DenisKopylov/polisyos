# Chart testing

Use static lints for manifest coverage, visual snapshots for state grids and manual assistive-technology review for complex charts such as provenance graphs and uncertainty fans.
