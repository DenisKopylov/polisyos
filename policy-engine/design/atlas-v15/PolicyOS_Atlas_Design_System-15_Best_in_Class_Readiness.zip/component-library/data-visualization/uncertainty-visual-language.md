# Uncertainty Visual Language

PolicyOS charts must show uncertainty when the decision depends on estimates, forecasts or incomplete evidence.

## Required uncertainty metadata

- Interval level, for example 50%, 80% or 95%.
- Point estimate or median.
- Lower and upper bound.
- Model/evidence freshness.
- Assumption note when the uncertainty depends on causal or transportability assumptions.

## Visual treatments

- Band: interval around a line or point estimate.
- Fan: multiple interval levels over time.
- Error bar: compact interval around category estimate.
- Staleness marker: warning token plus label.
- Low-confidence marker: risk token plus explanation.
