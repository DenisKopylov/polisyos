# Atlas forms and data-entry system

Atlas v12 treats forms as a production workflow layer, not a loose set of inputs. The system covers layout, validation, grouped choices, secrets, files, numbers, dates, search, autocomplete, tokenized values and character limits.

## Principles

1. Native controls first: use HTML inputs, fieldsets, labels and buttons before ARIA widgets.
2. Explain before error: show format, constraint, privacy and source guidance near the control.
3. Error recovery is a flow: put `ValidationSummary` before the fields and a local error next to each invalid answer.
4. Data entry is auditable: domain forms should make source, freshness, retention, jurisdiction and permission constraints visible.
5. Modes are mandatory: light, dark, high-contrast, forced-colors and density modes must not change semantics.

## Component coverage

- Structure: `Form`, `FormSection`, `FieldGroup`, `ValidationSummary`.
- Choices: `RadioGroup`, `CheckboxGroup`, existing `Checkbox`, existing `Switch`.
- Text and secrets: existing `TextField`, existing `TextArea`, `SearchField`, `PasswordField`, `SecretField`, `TokenInput`, `CharacterCount`.
- Bounded values: `NumberField`, `RangeField`, `DateField`, `DateRangeField`, existing `SelectField`, `Combobox`.
- Evidence intake: `FileUpload`.

## Release gates

- `scripts/component_lint.py` checks source/docs/story/manifest coverage.
- `scripts/state_matrix_lint.py` checks state coverage.
- `scripts/token_static_lint.py` keeps new component sources free of raw colors.
