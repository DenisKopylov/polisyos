# Field anatomy

Every Atlas field follows the same anatomy: label or legend, optional helper text, native control, optional adornment/action, local validation message and stable `data-state`.

## Required wiring

- Label uses `htmlFor` or fieldset uses `legend`.
- Helper and error ids are included in `aria-describedby`.
- Required state is visible in text and programmatic where applicable.
- Prefix/suffix text is never the only way to understand the field.
- Placeholder text is optional and never replaces a label.

## Domain metadata

PolicyOS forms should expose jurisdiction, retention, privacy class, evidence source and review cadence where those affect user decisions.
