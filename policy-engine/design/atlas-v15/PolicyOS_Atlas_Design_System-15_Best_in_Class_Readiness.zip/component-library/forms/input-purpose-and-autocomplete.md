# Input purpose and autocomplete

When collecting personal data, products must set `autoComplete` tokens that identify input purpose. This supports browser autofill and WCAG input-purpose expectations.

## Examples

- Email: `autoComplete="email"`.
- Current password: `autoComplete="current-password"`.
- New password: `autoComplete="new-password"`.
- Address textarea: `autoComplete="street-address"`.
- One-time code: `autoComplete="one-time-code"`.

Use `autoComplete="off"` for API keys and short-lived secrets unless a product security review says otherwise.
