# Forms migration checklist

- Replace ad-hoc labelled inputs with Atlas field components.
- Replace visual-only grouped choices with `RadioGroup` or `CheckboxGroup`.
- Add `ValidationSummary` to every submit flow.
- Use `DateField`/`DateRangeField` instead of unlabelled date placeholders.
- Use `SecretField` for API keys and policy secrets.
- Use `FileUpload` with accept/type/size guidance for evidence intake.
- Add `CharacterCount` to bounded long-text fields.
- Check keyboard-only submit, error recovery and focus order.
- Check forced-colors and high-contrast mode.
