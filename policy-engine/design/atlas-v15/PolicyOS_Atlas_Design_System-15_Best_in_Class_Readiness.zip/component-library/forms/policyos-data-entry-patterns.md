# PolicyOS data-entry patterns

## Evidence upload

Use `FileUpload` with explicit `accept`, max size copy and source/provenance helper text. Pair server errors with `ValidationSummary`.

## Governance gate configuration

Use `FieldGroup`, `RadioGroup`, `CheckboxGroup`, `NumberField` and `SecretField` to capture thresholds, waiver requirements, retention rules and signing credentials.

## Scenario parameters

Use `FormSection` per domain area, `NumberField` for bounded values, `RangeField` for sensitivity sliders and `TokenInput` for jurisdictions, cohorts or intervention tags.

## Search and source selection

Use `SearchField` for broad filtering. Use `Combobox` only when selecting a single known object from a controlled set. Use `TokenInput` when multiple selections must remain visible and removable.
