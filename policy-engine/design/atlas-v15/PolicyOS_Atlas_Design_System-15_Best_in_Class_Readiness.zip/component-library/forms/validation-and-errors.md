# Validation and error recovery

Use validation when submitted data cannot be used. Show both a summary before the form and a local error next to the invalid answer. Error messages must say what went wrong and how to fix it.

## Required pattern

1. Disable native browser validation with `noValidate` on `Form`.
2. Validate on submit, on blur or after server response depending on the risk of interruption.
3. Render `ValidationSummary` before the first field.
4. Link each summary item to the invalid control or field group.
5. Set the field `error` prop so `aria-invalid` and `aria-describedby` are applied.
6. Move focus to the summary after failed submit.

## Error copy

Use: “Enter a review deadline after today.”

Avoid: “Invalid date.”

For PolicyOS flows, include the blocked consequence when useful: “Upload a CSV under 10 MB so the evidence parser can attach provenance.”
