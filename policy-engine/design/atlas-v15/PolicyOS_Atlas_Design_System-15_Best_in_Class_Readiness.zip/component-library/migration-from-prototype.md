# Migration from `ui_kits/dashboard/Components.jsx`

`ui_kits/dashboard/Components.jsx` is now a prototype compatibility shim. Production surfaces should import from `@policyos/atlas-ui`.

## Recommended order

1. Replace action controls with `Button`.
2. Replace ad hoc pills with `Badge`.
3. Replace static cards with `Panel`, `Card` and `MetricCard`.
4. Replace clickable cards with `CardButton` or domain components such as `RunCard`.
5. Replace ad hoc forms with `TextField`, `TextArea`, `SelectField`, `Checkbox` and `Switch`.
6. Replace tab-like controls with `Tabs`.
7. Replace modal overlays with `Dialog` for controlled modal flows; focus trap, Escape dismiss and focus return are built in.
8. Replace governance rows with `GovernanceGate` and future domain patterns.

## Bridge rule

Prototype code may keep global primitives for static HTML demos. Product code must not add new globals.
