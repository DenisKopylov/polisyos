# Atlas State Matrix Audit

Generated: `2026-06-09T17:33:12Z`

## Gate summary

- Components in matrix: **56**
- Required v15 components: **56**
- Supported states: **491**
- Explicitly rejected states: **92**
- Backlog states tracked: **2**
- Blockers: **0**
- Warnings: **0**

## Findings

| Severity | Subject | Message |
|---|---|---|
| — | — | No findings. |

## Component coverage

| Component | Supported states | P0 | Rejected | Backlog |
|---|---:|---:|---:|---:|
| AccessibilityModePanel | 9 | 5 | 1 | 0 |
| Badge | 8 | 7 | 2 | 0 |
| BarChart | 8 | 6 | 2 | 0 |
| Button | 12 | 11 | 2 | 0 |
| Card | 12 | 10 | 2 | 0 |
| CausalGraph | 9 | 7 | 2 | 0 |
| CharacterCount | 6 | 4 | 1 | 0 |
| ChartAnnotation | 7 | 6 | 2 | 0 |
| ChartDataTable | 8 | 6 | 2 | 0 |
| ChartFrame | 8 | 6 | 2 | 0 |
| ChartLegend | 8 | 6 | 2 | 0 |
| ChartTooltip | 9 | 6 | 2 | 0 |
| Checkbox | 10 | 9 | 2 | 0 |
| CheckboxGroup | 8 | 5 | 1 | 0 |
| Combobox | 8 | 5 | 1 | 0 |
| DashboardShell | 7 | 6 | 3 | 0 |
| DashboardTopBar | 8 | 6 | 1 | 0 |
| DataTable | 13 | 5 | 2 | 2 |
| DataVizTable | 7 | 5 | 2 | 0 |
| DateField | 9 | 5 | 1 | 0 |
| DateRangeField | 9 | 5 | 1 | 0 |
| Dialog | 10 | 8 | 2 | 0 |
| EmptyState | 9 | 6 | 2 | 0 |
| FieldGroup | 9 | 5 | 1 | 0 |
| FileUpload | 9 | 5 | 1 | 0 |
| Form | 6 | 3 | 1 | 0 |
| FormSection | 6 | 3 | 1 | 0 |
| GovernanceGate | 9 | 7 | 2 | 0 |
| Heatmap | 8 | 6 | 2 | 0 |
| LineChart | 8 | 6 | 2 | 0 |
| MetricCard | 7 | 4 | 2 | 0 |
| NumberField | 9 | 5 | 1 | 0 |
| Panel | 8 | 6 | 2 | 0 |
| PasswordField | 10 | 6 | 1 | 0 |
| ProvenanceGraph | 11 | 6 | 2 | 0 |
| ProvenanceMap | 8 | 6 | 2 | 0 |
| RadioGroup | 8 | 5 | 1 | 0 |
| RangeField | 9 | 5 | 1 | 0 |
| ResponsiveGrid | 7 | 6 | 3 | 0 |
| RunCard | 14 | 13 | 2 | 0 |
| ScrollRegion | 7 | 7 | 1 | 0 |
| SearchField | 9 | 5 | 1 | 0 |
| SecretField | 11 | 7 | 1 | 0 |
| SelectField | 11 | 8 | 2 | 0 |
| Skeleton | 5 | 3 | 2 | 0 |
| Sparkline | 8 | 6 | 2 | 0 |
| Switch | 8 | 7 | 2 | 0 |
| Tabs | 10 | 8 | 2 | 0 |
| TextArea | 12 | 10 | 2 | 0 |
| TextField | 12 | 10 | 2 | 0 |
| ThemeProvider | 9 | 5 | 1 | 0 |
| ThemeToggle | 9 | 5 | 1 | 0 |
| Toast | 8 | 7 | 2 | 0 |
| TokenInput | 9 | 5 | 1 | 0 |
| UncertaintyBand | 9 | 7 | 2 | 0 |
| ValidationSummary | 6 | 3 | 1 | 0 |
