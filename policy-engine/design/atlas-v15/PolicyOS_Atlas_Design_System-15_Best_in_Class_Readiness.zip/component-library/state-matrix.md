# Atlas component state matrix

Generated: `2026-06-09T07:31:16Z`

Version: `12.0.0-forms-data-entry`

This file is generated from `component-library/state-matrix/component-state-matrix.json`.

## Release contract

- Every production component has supported states, explicitly rejected states, combination rules and mode coverage.
- Every state declares trigger, visual contract, semantics, tokens, keyboard behavior, acceptance criteria and test evidence.
- Components may not add visual states without updating the canonical JSON, docs, story coverage and lint gates.
- v12 form and data-entry controls must preserve label, description, error and validation-summary wiring across modes.

## Coverage summary

| Component | Supported | P0 | Rejected | Modes | State docs |
|---|---:|---:|---:|---|---|
| Badge | 8 | 7 | 2 | high-contrast, reduced-motion, density | `component-library/state-matrix/components/badge.md` |
| Button | 12 | 11 | 2 | high-contrast, reduced-motion, density | `component-library/state-matrix/components/button.md` |
| Card | 12 | 10 | 2 | high-contrast, reduced-motion, density | `component-library/state-matrix/components/card.md` |
| CharacterCount | 6 | 4 | 1 | light, dark, high-contrast, forced-colors, density, reduced-motion | `component-library/state-matrix/components/character-count.md` |
| Checkbox | 10 | 9 | 2 | high-contrast, reduced-motion, density | `component-library/state-matrix/components/checkbox.md` |
| CheckboxGroup | 8 | 5 | 1 | light, dark, high-contrast, forced-colors, density, reduced-motion | `component-library/state-matrix/components/checkbox-group.md` |
| Combobox | 8 | 5 | 1 | light, dark, high-contrast, forced-colors, density, reduced-motion | `component-library/state-matrix/components/combobox.md` |
| DataTable | 11 | 5 | 2 | high-contrast, reduced-motion, density | `component-library/state-matrix/components/data-table.md` |
| DateField | 9 | 5 | 1 | light, dark, high-contrast, forced-colors, density, reduced-motion | `component-library/state-matrix/components/date-field.md` |
| DateRangeField | 9 | 5 | 1 | light, dark, high-contrast, forced-colors, density, reduced-motion | `component-library/state-matrix/components/date-range-field.md` |
| Dialog | 10 | 8 | 2 | high-contrast, reduced-motion, density | `component-library/state-matrix/components/dialog.md` |
| EmptyState | 9 | 6 | 2 | high-contrast, reduced-motion, density | `component-library/state-matrix/components/empty-state.md` |
| FieldGroup | 9 | 5 | 1 | light, dark, high-contrast, forced-colors, density, reduced-motion | `component-library/state-matrix/components/field-group.md` |
| FileUpload | 9 | 5 | 1 | light, dark, high-contrast, forced-colors, density, reduced-motion | `component-library/state-matrix/components/file-upload.md` |
| Form | 6 | 3 | 1 | light, dark, high-contrast, forced-colors, density, reduced-motion | `component-library/state-matrix/components/form.md` |
| FormSection | 6 | 3 | 1 | light, dark, high-contrast, forced-colors, density, reduced-motion | `component-library/state-matrix/components/form-section.md` |
| GovernanceGate | 9 | 7 | 2 | high-contrast, reduced-motion, density | `component-library/state-matrix/components/governance-gate.md` |
| MetricCard | 7 | 4 | 2 | high-contrast, reduced-motion, density | `component-library/state-matrix/components/metric-card.md` |
| NumberField | 9 | 5 | 1 | light, dark, high-contrast, forced-colors, density, reduced-motion | `component-library/state-matrix/components/number-field.md` |
| Panel | 8 | 6 | 2 | high-contrast, reduced-motion, density | `component-library/state-matrix/components/panel.md` |
| PasswordField | 10 | 6 | 1 | light, dark, high-contrast, forced-colors, density, reduced-motion | `component-library/state-matrix/components/password-field.md` |
| RadioGroup | 8 | 5 | 1 | light, dark, high-contrast, forced-colors, density, reduced-motion | `component-library/state-matrix/components/radio-group.md` |
| RangeField | 9 | 5 | 1 | light, dark, high-contrast, forced-colors, density, reduced-motion | `component-library/state-matrix/components/range-field.md` |
| RunCard | 14 | 13 | 2 | high-contrast, reduced-motion, density | `component-library/state-matrix/components/run-card.md` |
| SearchField | 9 | 5 | 1 | light, dark, high-contrast, forced-colors, density, reduced-motion | `component-library/state-matrix/components/search-field.md` |
| SecretField | 11 | 7 | 1 | light, dark, high-contrast, forced-colors, density, reduced-motion | `component-library/state-matrix/components/secret-field.md` |
| SelectField | 11 | 8 | 2 | high-contrast, reduced-motion, density | `component-library/state-matrix/components/select-field.md` |
| Skeleton | 5 | 3 | 2 | high-contrast, reduced-motion, density | `component-library/state-matrix/components/skeleton.md` |
| Switch | 8 | 7 | 2 | high-contrast, reduced-motion, density | `component-library/state-matrix/components/switch.md` |
| Tabs | 10 | 8 | 2 | high-contrast, reduced-motion, density | `component-library/state-matrix/components/tabs.md` |
| TextArea | 12 | 10 | 2 | high-contrast, reduced-motion, density | `component-library/state-matrix/components/text-area.md` |
| TextField | 12 | 10 | 2 | high-contrast, reduced-motion, density | `component-library/state-matrix/components/text-field.md` |
| Toast | 8 | 7 | 2 | high-contrast, reduced-motion, density | `component-library/state-matrix/components/toast.md` |
| TokenInput | 9 | 5 | 1 | light, dark, high-contrast, forced-colors, density, reduced-motion | `component-library/state-matrix/components/token-input.md` |
| ValidationSummary | 6 | 3 | 1 | light, dark, high-contrast, forced-colors, density, reduced-motion | `component-library/state-matrix/components/validation-summary.md` |

## Totals

- Components: **35**
- Supported states: **317**
- Explicitly rejected states: **53**
