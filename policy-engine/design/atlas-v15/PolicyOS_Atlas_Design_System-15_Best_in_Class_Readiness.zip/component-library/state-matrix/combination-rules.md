# Atlas state combination rules

This file defines cross-component rules that state authors must apply before adding or changing component states.

## Precedence

1. `disabled`
2. `loading`
3. `invalid`
4. `selected/checked/open`
5. `active`
6. `hover`
7. `focus-visible overlay`
8. `default`

## Required cross-state rules

- Disabled blocks hover, focus-visible, active and user-triggered loading unless component documents an exception.
- Focus-visible overlays selected, invalid, checked and open states and must not be hidden by shadows or borders.
- Invalid can combine with required and focus-visible; disabled takes precedence in visual treatment.
- Reduced motion and high contrast are mode states and must combine with every supported component state.
- Backlog states must include owner, rationale and future acceptance criteria before implementation.

## Component exceptions

Component-specific exceptions live in `component-library/state-matrix/component-state-matrix.json` under `components.<Name>.combinationRules`. Exceptions must be narrower than the global rule and must include accessibility rationale.

## Accessibility-first guidance

- Disabled components do not expose hover, active or focus-visible affordances.
- Loading controls that can cause duplicate destructive actions must also be disabled.
- Focus-visible always remains visible over selected, danger, warning and high-contrast treatments.
- Status meaning must remain available through text or semantics when color is removed.
- Backlog states are visible debt and must not be represented as done in product surfaces.
