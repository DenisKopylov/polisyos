# AdaptiveDataRegion state matrix

## Supported states

| State | Kind | Priority | Trigger | Semantics |
|---|---|---|---|---|
| `table` | data | P0 | mode="table". | Region is named and can be focused for local scrolling. |
| `cards` | data | P0 | mode="cards". | Region summary remains associated. |
| `graph` | data | P0 | mode="graph". | Region label and summary describe graph context. |
| `timeline` | data | P0 | mode="timeline". | Region can be focused for keyboard scrolling. |
| `scrollable` | layout | P0 | Content exceeds inline size. | Named region identifies scrollable content. |
| `high-contrast` | mode | P0 | Forced colors/high contrast active. | No semantic changes. |
| `density` | mode | P1 | Density mode applied. | No semantic changes. |

## Explicitly rejected states

- `selected` — not a meaningful state for this layout primitive.
- `checked` — not a meaningful state for this layout primitive.
- `invalid` — not a meaningful state for this layout primitive.

## Combination and precedence rules

- Responsive state must not remove keyboard focus or accessible names.
- High-contrast and density modes can combine with every viewport state.
- Drawer-open has priority over rail/expanded visual treatments only below the drawer breakpoint.

## Test coverage contract

- Covered by `packages/atlas-ui/stories/DashboardResponsive.stories.tsx`.
- Covered by `scripts/dashboard_responsive_lint.py`.
- Covered by component/state matrix static gates.

## Accessibility notes

- scrollable table regions have names.
- summary can describe dense visual data.
- keyboard focus exposes local scrolling.
