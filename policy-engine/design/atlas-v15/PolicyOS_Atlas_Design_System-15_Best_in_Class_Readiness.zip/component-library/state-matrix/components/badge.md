# Badge state matrix

**Matrix id:** `atlas.stateMatrix.Badge.v11`  
**Version:** `11.0.0-state-matrix`  
**Source:** `packages/atlas-ui/src/components/Badge/Badge.tsx`  
**Canonical JSON:** `component-library/state-matrix/component-state-matrix.json#/components/Badge`

## Anatomy

- root span
- tone attribute
- optional live status role

## Supported states

| State | Kind | Trigger | Visual contract | DOM / ARIA contract | Tokens | Keyboard | Priority |
|---|---|---|---|---|---|---|---|
| `neutral` | status | tone="neutral". | Neutral surface/text token pair. | Plain text unless status=true. | `--atlas-badge-neutral-bg`, `--atlas-badge-neutral-text` | No additional keyboard behavior. | P0 |
| `info` | status | tone="info". | Blue information token pair. | Plain text unless status=true. | `--atlas-badge-info-bg`, `--atlas-badge-info-text` | No additional keyboard behavior. | P0 |
| `success` | status | tone="success". | Teal success token pair. | Text must contain the status, not only color. | `--atlas-badge-ok-bg`, `--atlas-badge-ok-text` | No additional keyboard behavior. | P0 |
| `warning` | status | tone="warning". | Gold warning token pair. | Text must contain the status, not only color. | `--atlas-badge-warn-bg`, `--atlas-badge-warn-text` | No additional keyboard behavior. | P0 |
| `danger` | status | tone="danger". | Ember danger token pair. | Text must contain the status, not only color. | `--atlas-badge-fail-bg`, `--atlas-badge-fail-text` | No additional keyboard behavior. | P0 |
| `status` | a11y | status=true for changing status text. | Same as tone. | role="status" exposes polite announcement. | `tone tokens` | No focus; announcement only. | P0 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | Borders and focus rings remain visible; color-only meaning must have text or shape fallback. | No semantic change; forced-colors uses system colors where appropriate. | `--focus-ring`, `--focus-ring-outer` | Keyboard order and activation stay identical. | P0 |
| `density` | mode | Container or product shell applies a density mode. | Spacing and control height use density tokens while preserving 24px/44px target guidance as applicable. | No semantic change. | `--atlas-control-height-sm`, `--atlas-control-height-md`, `--atlas-control-height-lg`, `--target-min` | Touch and keyboard targets remain operable. | P1 |

## Explicitly rejected states

| State | Rationale | Alternative |
|---|---|---|
| `hover` | Badge is non-interactive and must not imply clickability. | Use composition or request a new component state through the DS RFC process. |
| `disabled` | Static status text is not operable; disabled is not meaningful. | Use composition or request a new component state through the DS RFC process. |

## Combination and precedence rules

| Rule |
|---|
| Tone states are mutually exclusive. |
| status announcement can combine with any tone. |
| High contrast requires text label to remain visible. |

## Test coverage contract

| Layer | Evidence |
|---|---|
| static | component_lint + state_matrix_lint |
| story | Foundations.stories.tsx + StateMatrix.stories.tsx |
| runtime | role/status smoke test backlog |
| manual | Screen-reader announcement when status changes |

## Accessibility notes

- Status meaning must be present in text.
- Use role=status only for dynamic changes.

## Mode coverage

- `high-contrast`
- `reduced-motion`
- `density`
