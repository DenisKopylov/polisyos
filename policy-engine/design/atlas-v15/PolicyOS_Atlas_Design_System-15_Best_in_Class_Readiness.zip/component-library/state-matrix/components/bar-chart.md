
# BarChart state matrix

**Matrix id:** `atlas.stateMatrix.BarChart.v14`  
**Version:** `14.0.0-data-visualization`  
**Source:** `packages/atlas-ui/src/components/DataVisualization/BarChart.tsx`  
**Canonical JSON:** `component-library/state-matrix/component-state-matrix.json#/components/BarChart`

## Anatomy

- root container
- title/summary evidence
- visual marks
- legend/direct labels
- data-table equivalent or source/caption

## Supported states

| State | Kind | Trigger | Visual contract | DOM / ARIA contract | Tokens | Keyboard | Priority |
|---|---|---|---|---|---|---|---|
| default | content | BarChart receives valid chart content or dataset. | Chart surface and marks use data-viz tokens and preserve readable spacing. | Root exposes data-atlas-component and data-state hooks; SVG charts expose title/description where applicable. | `--atlas-viz-canvas-surface`, `--atlas-viz-title` | Tab order skips static marks unless nodes are intentionally focusable. | P0 |
| text-summary | accessibility | Consumer provides decision-relevant summary copy. | Summary appears adjacent to the chart and remains visible in print/export. | Summary is referenced by ChartFrame aria-describedby or duplicated in SVG desc. | `--atlas-viz-summary` | Summary is part of normal reading order. | P0 |
| data-table-equivalent | accessibility | Chart values affect a decision or need exact reading. | Table sits below chart or is linked from the frame; plot remains uncluttered. | Table uses caption, headers and row labels for assistive technology. | `--atlas-viz-canvas-border`, `--atlas-viz-canvas-surface-raised` | Users can reach table via normal document navigation. | P0 |
| no-color-alone | accessibility | Series/status/threshold meaning is color-coded. | Color is paired with text, shape, dash pattern, direct label or table column. | Meaning remains available without color perception. | `--atlas-viz-dash-pattern`, `--atlas-viz-dot-pattern` | No extra keyboard behavior required. | P0 |
| focus-visible | interaction | Focusable graph nodes or tooltip triggers receive keyboard focus. | Focus ring is visible and not obscured by adjacent marks. | Focusable SVG groups or controls expose meaningful aria-label. | `--focus-ring`, `--focus-outline-width` | Tab/Shift+Tab order follows visual reading order. | P0 |
| high-contrast | mode | User enables high-contrast or forced-colors mode. | Axes, marks and selected/focus states remain visible with system colors or contrast tokens. | No semantic change; color-only meaning remains forbidden. | `--atlas-viz-axis`, `--atlas-viz-series-1`, `--focus-ring` | Keyboard behavior remains identical. | P0 |
| density | mode | Dashboard shell applies comfortable, compact or condensed density. | Frame padding, table density and legend wrapping adapt without clipping labels. | No semantic change. | `--atlas-viz-canvas-padding`, `--target-min` | Targets remain operable. | P1 |
| reduced-motion | mode | User sets prefers-reduced-motion: reduce. | Animated transitions or shimmer are disabled or shortened. | Live summaries remain available when animation is removed. | `--motion-reduced-duration` | No keyboard change. | P1 |

## Explicitly rejected states

| State | Rationale | Alternative |
|---|---|---|
| `color-only` | Color-only meaning fails the chart accessibility contract. | Pair color with text, shape, dash pattern, direct label or table column. |
| `tooltip-only` | Hover-only disclosure is not durable evidence and is not available to all users. | Put essential information in summary, caption, table or focusable detail. |

## Combination and precedence rules

| Rule |
|---|
| Focus-visible overlays hover/selected states and must not be hidden by chart marks. |
| High-contrast mode preserves axes, marks, summaries and table equivalence. |
| Density changes spacing, not evidence: title, summary, source and table remain available. |

## Test coverage contract

| Layer | Evidence |
|---|---|
| static | data_viz_lint + component_lint + state_matrix_lint |
| story | DataVisualization.stories.tsx + StateMatrix.stories.tsx |
| runtime | Playwright/axe chart frame and data table checks backlog |
| manual | Screen-reader and color-vision simulation backlog |

## Accessibility notes

- Use short summary plus long alternative or table for complex chart content.
- Never rely on color alone for series, status, threshold or confidence.
- Tooltips are progressive disclosure only and do not replace summary/table content.

## Mode coverage

- `high-contrast`
- `density`
- `reduced-motion`
