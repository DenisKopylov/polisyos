# Button state matrix

**Matrix id:** `atlas.stateMatrix.Button.v11`  
**Version:** `11.0.0-state-matrix`  
**Source:** `packages/atlas-ui/src/components/Button/Button.tsx`  
**Canonical JSON:** `component-library/state-matrix/component-state-matrix.json#/components/Button`

## Anatomy

- root button
- optional spinner
- visible label
- visually hidden loading label

## Supported states

| State | Kind | Trigger | Visual contract | DOM / ARIA contract | Tokens | Keyboard | Priority |
|---|---|---|---|---|---|---|---|
| `default` | interaction | Button is enabled and idle. | Baseline surface, text, border and shadow from component tokens. | Native semantic element remains available to keyboard and assistive tech. | `component tokens` | Tab reaches control when interactive. | P0 |
| `hover` | interaction | Pointer enters enabled control. | Uses tokenized hover transform/surface/border without relying on color alone. | No ARIA change. | `--atlas-state-hover-transform`, `--atlas-state-hover-surface` | No keyboard equivalent required; focus-visible covers keyboard discovery. | P0 |
| `focus-visible` | interaction | Keyboard, switch control or programmatic focus reaches the element. | 3px focus outline plus outer halo; not obscured by adjacent content. | Native focus target or roving tabindex target. | `--focus-ring`, `--focus-ring-outer`, `--focus-outline-width` | Tab/Shift+Tab order is predictable. | P0 |
| `active` | interaction | Pointer down, Enter or Space activation. | Pressed transform removes lift; no layout shift. | Native activation event fires once. | `--atlas-state-active-transform` | Enter and Space activate native buttons. | P0 |
| `disabled` | interaction | Action is unavailable or blocked by permissions/prerequisites. | Opacity and cursor use state tokens; color is not the only disabled cue. | Use native disabled where possible; otherwise aria-disabled with blocked handlers. | `--atlas-state-disabled-opacity`, `--atlas-state-disabled-cursor` | Disabled native controls are removed from tab order. | P0 |
| `loading` | async | Consumer passes loading=true while an action is pending. | Spinner appears before label; cursor becomes progress; component is disabled to prevent duplicate submits. | aria-busy=true and hidden loading text precedes label in accessible name. | `--atlas-button-loading-indicator` | Button cannot be activated while loading. | P0 |
| `variant-primary` | variant | variant="primary". | Accessible teal gradient with warm-white text. | No semantic change; action importance is conveyed by placement and label. | `--atlas-button-primary-bg`, `--atlas-button-primary-text`, `--atlas-button-primary-shadow` | Same as default. | P0 |
| `variant-danger` | variant | variant="danger" for destructive or irreversible actions. | Ember text/border/background plus explicit destructive copy. | No ARIA change; label must name the destructive action. | `--atlas-button-danger-bg`, `--atlas-button-danger-border`, `--atlas-button-danger-text` | Same as default. | P0 |
| `icon-only` | content | size="icon" or visual label is absent. | Maintains target size with no visible text. | Requires aria-label or aria-labelledby supplied by consumer. | `--target-min` | Same as default. | P0 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | Borders and focus rings remain visible; color-only meaning must have text or shape fallback. | No semantic change; forced-colors uses system colors where appropriate. | `--focus-ring`, `--focus-ring-outer` | Keyboard order and activation stay identical. | P0 |
| `reduced-motion` | mode | User sets prefers-reduced-motion: reduce. | Transitions, spinner and shimmer motion collapse to reduced duration or static treatment. | No semantic change; loading labels remain exposed. | `--motion-reduced-duration` | Keyboard order and activation stay identical. | P0 |
| `density` | mode | Container or product shell applies a density mode. | Spacing and control height use density tokens while preserving 24px/44px target guidance as applicable. | No semantic change. | `--atlas-control-height-sm`, `--atlas-control-height-md`, `--atlas-control-height-lg`, `--target-min` | Touch and keyboard targets remain operable. | P1 |

## Explicitly rejected states

| State | Rationale | Alternative |
|---|---|---|
| `selected` | Buttons are actions, not persistent choices. | Use Tabs, Checkbox, Switch or CardButton for persistent selected state. |
| `error` | Error belongs to the result or field, not the action control. | Show Toast, inline error or Dialog content. |

## Combination and precedence rules

| Rule |
|---|
| loading > disabled > active > hover > default visual precedence |
| danger variant does not override focus-visible outline |
| icon-only must never remove accessible name |

## Test coverage contract

| Layer | Evidence |
|---|---|
| static | component_lint + state_matrix_lint |
| story | Button.stories.tsx + StateMatrix.stories.tsx |
| runtime | component-contract.test.tsx covers loading and native semantics |
| manual | Keyboard, forced-colors and screen-reader smoke test before stable release |

## Accessibility notes

- Prefer native button semantics.
- Never use color-only labels for danger; copy must state the action.
- Loading state must expose text alternative.

## Mode coverage

- `high-contrast`
- `reduced-motion`
- `density`
