# Card state matrix

**Matrix id:** `atlas.stateMatrix.Card.v11`  
**Version:** `11.0.0-state-matrix`  
**Source:** `packages/atlas-ui/src/components/Card/Card.tsx`  
**Canonical JSON:** `component-library/state-matrix/component-state-matrix.json#/components/Card`

## Anatomy

- static Card article
- CardButton button variant
- title
- description
- meta/action slots

## Supported states

| State | Kind | Trigger | Visual contract | DOM / ARIA contract | Tokens | Keyboard | Priority |
|---|---|---|---|---|---|---|---|
| `default` | interaction | CardButton is enabled and idle. | Baseline surface, text, border and shadow from component tokens. | Native semantic element remains available to keyboard and assistive tech. | `component tokens` | Tab reaches control when interactive. | P0 |
| `hover` | interaction | Pointer enters enabled control. | Uses tokenized hover transform/surface/border without relying on color alone. | No ARIA change. | `--atlas-state-hover-transform`, `--atlas-state-hover-surface` | No keyboard equivalent required; focus-visible covers keyboard discovery. | P0 |
| `focus-visible` | interaction | Keyboard, switch control or programmatic focus reaches the element. | 3px focus outline plus outer halo; not obscured by adjacent content. | Native focus target or roving tabindex target. | `--focus-ring`, `--focus-ring-outer`, `--focus-outline-width` | Tab/Shift+Tab order is predictable. | P0 |
| `active` | interaction | Pointer down, Enter or Space activation. | Pressed transform removes lift; no layout shift. | Native activation event fires once. | `--atlas-state-active-transform` | Enter and Space activate native buttons. | P0 |
| `disabled` | interaction | Action is unavailable or blocked by permissions/prerequisites. | Opacity and cursor use state tokens; color is not the only disabled cue. | Use native disabled where possible; otherwise aria-disabled with blocked handlers. | `--atlas-state-disabled-opacity`, `--atlas-state-disabled-cursor` | Disabled native controls are removed from tab order. | P0 |
| `static` | layout | Card renders informational content. | Card surface and border only; no hover affordance. | article labelled by title when present. | `--atlas-card-surface`, `--atlas-card-border` | No additional keyboard behavior. | P0 |
| `interactive` | interaction | CardButton renders a native button. | Button card surface, border and hover elevation. | button with accessible name from title/description. | `--atlas-card-interactive-border`, `--atlas-card-hover-shadow` | No additional keyboard behavior. | P0 |
| `selected` | selection | CardButton selected=true. | Selected surface/border/shadow tokens. | aria-pressed=true. | `--atlas-state-selected-surface`, `--atlas-card-selected-border` | Tab reaches the selected button; Space/Enter activates. | P0 |
| `content-overflow` | layout | Description or meta content exceeds one line. | Content wraps without clipping focus ring. | No semantic change. | `--space-2` | No additional keyboard behavior. | P1 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | Borders and focus rings remain visible; color-only meaning must have text or shape fallback. | No semantic change; forced-colors uses system colors where appropriate. | `--focus-ring`, `--focus-ring-outer` | Keyboard order and activation stay identical. | P0 |
| `reduced-motion` | mode | User sets prefers-reduced-motion: reduce. | Transitions, spinner and shimmer motion collapse to reduced duration or static treatment. | No semantic change; loading labels remain exposed. | `--motion-reduced-duration` | Keyboard order and activation stay identical. | P0 |
| `density` | mode | Container or product shell applies a density mode. | Spacing and control height use density tokens while preserving 24px/44px target guidance as applicable. | No semantic change. | `--atlas-control-height-sm`, `--atlas-control-height-md`, `--atlas-control-height-lg`, `--target-min` | Touch and keyboard targets remain operable. | P1 |

## Explicitly rejected states

| State | Rationale | Alternative |
|---|---|---|
| `loading` | CardButton itself does not own async state. | Compose Skeleton or Badge inside Card content. |
| `error` | Error state belongs to content, not the Card shell. | Use composition or request a new component state through the DS RFC process. |

## Combination and precedence rules

| Rule |
|---|
| static and interactive are mutually exclusive |
| disabled overrides selected visual activation |
| focus-visible is always visible over selected state |

## Test coverage contract

| Layer | Evidence |
|---|---|
| static | component_lint + state_matrix_lint |
| story | Foundations.stories.tsx + StateMatrix.stories.tsx |
| runtime | selected aria-pressed test backlog |
| manual | Keyboard card activation |

## Accessibility notes

- Use Card for grouped content; use CardButton for action/selection.
- Selected state must be conveyed with aria-pressed.

## Mode coverage

- `high-contrast`
- `reduced-motion`
- `density`
