# CharacterCount state matrix

Component id: `atlas.stateMatrix.CharacterCount.v12`

Docs: `component-library/components/character-count.md`

## Supported states

| State | Priority | Trigger | Semantics |
|---|---|---|---|
| `default` | `P0` | Remaining count is above threshold. | aria-live polite announces count changes when rendered. |
| `warning` | `P0` | Remaining count is at or below warning threshold. | Message text states remaining characters. |
| `over-limit` | `P0` | Value length exceeds maxLength. | Message states number of characters over limit. |
| `live-update` | `P0` | User types in associated control. | aria-live polite avoids interrupting typing. |
| `high-contrast` | `P1` | High contrast mode active. | Live region preserved. |
| `density` | `P1` | Density mode active. | No semantic change. |

## Explicitly rejected states

| State | Rationale | Alternative |
|---|---|---|
| `interactive` | CharacterCount is status text, not an input. | Pair it with TextArea or TextField. |

## Combination and precedence rules

- Invalid state overrides hover and selected borders but must not suppress focus-visible.
- Disabled suppresses hover, active and submit behaviors.
- High-contrast and density are mode overlays, not mutually exclusive component states.

## Test coverage contract

- component_lint manifest/source/docs/story gate
- state_matrix_lint state contract gate
- Storybook-ready examples in DataEntry.stories.tsx
- manual keyboard and screen reader checklist in component-library/forms/validation-and-errors.md

## Accessibility notes

- Prefer native form controls before ARIA widgets.
- Every input has a visible label or legend and error/help ids wired through aria-describedby.
- Validation errors are recoverable and summarized before fields.
- Autocomplete/input purpose should be set by product teams for user personal data.

## Mode coverage

`light`, `dark`, `high-contrast`, `forced-colors`, `density`, `reduced-motion`
