# CheckboxGroup state matrix

Component id: `atlas.stateMatrix.CheckboxGroup.v12`

Docs: `component-library/components/checkbox-group.md`

## Supported states

| State | Priority | Trigger | Semantics |
|---|---|---|---|
| `empty` | `P0` | No option is selected. | fieldset/legend describes the group. |
| `selected` | `P0` | One or more options are selected. | Native checked state is exposed to assistive tech. |
| `focus-visible` | `P0` | Keyboard focus lands on a choice input. | Native radio/checkbox keyboard behavior remains available. |
| `invalid` | `P0` | error prop is provided. | aria-invalid and describedby connect group error. |
| `disabled` | `P1` | disabled is true. | fieldset disabled disables descendants. |
| `required` | `P0` | required is true. | Required attribute is applied to controls where meaningful. |
| `high-contrast` | `P1` | High contrast mode active. | Native input state remains readable. |
| `density` | `P1` | Density mode active. | DOM order unchanged. |

## Explicitly rejected states

| State | Rationale | Alternative |
|---|---|---|
| `free-text-entry` | CheckboxGroup is for bounded choices only. | Use TextField or TokenInput for free-form values. |

## Combination and precedence rules

- Invalid state overrides hover and selected borders but must not suppress focus-visible.
- Disabled suppresses hover, active and submit behaviors.
- High-contrast and density are mode overlays, not mutually exclusive component states.

## Test coverage contract

- component_lint manifest/source/docs/story gate
- state_matrix_lint state contract gate
- Storybook-ready examples in DataEntry.stories.tsx
- manual keyboard and screen reader checklist in component-library/forms/validation-and-errors.md

## Accessibility notes

- Prefer native form controls before ARIA widgets.
- Every input has a visible label or legend and error/help ids wired through aria-describedby.
- Validation errors are recoverable and summarized before fields.
- Autocomplete/input purpose should be set by product teams for user personal data.

## Mode coverage

`light`, `dark`, `high-contrast`, `forced-colors`, `density`, `reduced-motion`
