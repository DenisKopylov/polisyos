# Checkbox state matrix

**Matrix id:** `atlas.stateMatrix.Checkbox.v11`  
**Version:** `11.0.0-state-matrix`  
**Source:** `packages/atlas-ui/src/components/Field/Checkbox.tsx`  
**Canonical JSON:** `component-library/state-matrix/component-state-matrix.json#/components/Checkbox`

## Anatomy

- wrapper
- native checkbox input
- label
- description
- error

## Supported states

| State | Kind | Trigger | Visual contract | DOM / ARIA contract | Tokens | Keyboard | Priority |
|---|---|---|---|---|---|---|---|
| `unchecked` | selection | checked/defaultChecked are false and indeterminate=false. | Empty checkbox with visible label. | role=checkbox from native input; checked=false. | `--atlas-choice-box-surface`, `--atlas-choice-box-border` | Space toggles. | P0 |
| `checked` | selection | checked/defaultChecked true. | Native checked mark uses accent token. | Native checked state. | `--atlas-choice-box-checked`, `--atlas-choice-box-checkmark` | Space toggles. | P0 |
| `indeterminate` | selection | indeterminate=true. | Mixed visual mark; accent color. | aria-checked=mixed and DOM indeterminate property set. | `--accent` | Space toggles per native/browser behavior. | P0 |
| `focus-visible` | interaction | Keyboard focus reaches input. | Focus ring around checkbox. | Native focus target. | `--focus-ring` | Tab reaches input. | P0 |
| `required` | validation | required=true. | Asterisk in label. | required and aria-required set. | `--atlas-choice-label` | No additional keyboard behavior. | P0 |
| `invalid` | validation | error prop is provided. | Visible error text and invalid semantics. | aria-invalid=true and error id in aria-describedby. | `--atlas-field-error` | No additional keyboard behavior. | P0 |
| `disabled` | interaction | disabled=true. | Disabled opacity/cursor. | Native disabled removes from tab order. | `--atlas-state-disabled-opacity` | No additional keyboard behavior. | P0 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | Borders and focus rings remain visible; color-only meaning must have text or shape fallback. | No semantic change; forced-colors uses system colors where appropriate. | `--focus-ring`, `--focus-ring-outer` | Keyboard order and activation stay identical. | P0 |
| `reduced-motion` | mode | User sets prefers-reduced-motion: reduce. | Transitions, spinner and shimmer motion collapse to reduced duration or static treatment. | No semantic change; loading labels remain exposed. | `--motion-reduced-duration` | Keyboard order and activation stay identical. | P0 |
| `density` | mode | Container or product shell applies a density mode. | Spacing and control height use density tokens while preserving 24px/44px target guidance as applicable. | No semantic change. | `--atlas-control-height-sm`, `--atlas-control-height-md`, `--atlas-control-height-lg`, `--target-min` | Touch and keyboard targets remain operable. | P1 |

## Explicitly rejected states

| State | Rationale | Alternative |
|---|---|---|
| `readonly` | Native checkboxes do not support readonly. | Use composition or request a new component state through the DS RFC process. |
| `loading` | Async belongs to the action that submits the form. | Use composition or request a new component state through the DS RFC process. |

## Combination and precedence rules

| Rule |
|---|
| checked and indeterminate are mutually exclusive visually; indeterminate takes precedence |
| invalid can combine with checked/unchecked and required |
| disabled overrides focus and invalid interaction |

## Test coverage contract

| Layer | Evidence |
|---|---|
| static | state_matrix_lint |
| story | Forms.stories.tsx + StateMatrix.stories.tsx |
| runtime | component-contract.test.tsx covers native label toggling |
| manual | Mixed-state screen-reader review |

## Accessibility notes

- Use for independent boolean choices.
- For on/off settings with immediate effect, use Switch.

## Mode coverage

- `high-contrast`
- `reduced-motion`
- `density`
