# Combobox state matrix

Component id: `atlas.stateMatrix.Combobox.v12`

Docs: `component-library/components/combobox.md`

## Supported states

| State | Priority | Trigger | Semantics |
|---|---|---|---|
| `empty` | `P0` | Input has no query or value. | input has role combobox and controls listbox. |
| `open` | `P0` | User focuses field or activates disclosure. | aria-expanded true and aria-controls references listbox. |
| `active-option` | `P0` | Keyboard or pointer highlights an option. | aria-activedescendant references the active option id. |
| `selected` | `P0` | An option is committed. | onValueChange receives selected option value. |
| `invalid` | `P0` | error prop provided. | aria-invalid and aria-describedby connect error. |
| `disabled` | `P1` | disabled true. | Native disabled prevents focus/input. |
| `high-contrast` | `P1` | High contrast mode active. | Combobox/listbox roles remain. |
| `density` | `P1` | Density mode active. | Keyboard behavior unchanged. |

## Explicitly rejected states

| State | Rationale | Alternative |
|---|---|---|
| `multi-select` | This Combobox is single-select for v12. | Use TokenInput with product-managed suggestions. |

## Combination and precedence rules

- Invalid state overrides hover and selected borders but must not suppress focus-visible.
- Disabled suppresses hover, active and submit behaviors.
- High-contrast and density are mode overlays, not mutually exclusive component states.

## Test coverage contract

- component_lint manifest/source/docs/story gate
- state_matrix_lint state contract gate
- Storybook-ready examples in DataEntry.stories.tsx
- manual keyboard and screen reader checklist in component-library/forms/validation-and-errors.md

## Accessibility notes

- Prefer native form controls before ARIA widgets.
- Every input has a visible label or legend and error/help ids wired through aria-describedby.
- Validation errors are recoverable and summarized before fields.
- Autocomplete/input purpose should be set by product teams for user personal data.

## Mode coverage

`light`, `dark`, `high-contrast`, `forced-colors`, `density`, `reduced-motion`
