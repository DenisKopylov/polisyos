    # DashboardGrid state matrix

    Canonical state contract for `DashboardGrid` in the v13 dashboard responsive model.

    ## Supported states

    - `auto` — Auto grid
- `metrics` — Metrics grid
- `content-sidebar` — Content + sidebar
- `split` — Split grid
- `stack` — Stacked grid
- `compact-gap` — Compact gap
- `single-column` — Single column
- `high-contrast` — High contrast
- `density` — Density mode

    ## Explicitly rejected states

    - `desktop-only` — rejected because Atlas dashboards must preserve functionality below desktop width.
- `gesture-only` — rejected because keyboard and pointer alternatives are required.

    ## Combination and precedence rules

    - `focus-visible` has priority over hover, active, selected and breakpoint-specific visuals.
    - Drawer/rail/docked navigation may combine with high-contrast, reduced-motion and density modes.
    - Print/export mode removes decorative shell chrome and must expose content without scroll clipping.

    ## Test coverage contract

    - Covered by `packages/atlas-ui/stories/DashboardResponsive.stories.tsx`.
    - Covered by `scripts/responsive_lint.py` for breakpoint contract, CSS hooks and prototype wiring.
    - Covered by `scripts/state_matrix_lint.py` for canonical matrix completeness.

    ## Accessibility notes

    Keyboard order must remain sidebar/topbar/main. Mobile drawer controls use labelled buttons with `aria-expanded`; hidden drawers must not remain in the sequential focus order in production integrations.

    ## Mode coverage

    - high-contrast
    - reduced-motion
    - reduced-transparency
    - density
    - print/export
