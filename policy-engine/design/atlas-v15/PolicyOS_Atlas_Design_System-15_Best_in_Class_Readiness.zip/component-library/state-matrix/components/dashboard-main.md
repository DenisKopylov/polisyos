# DashboardMain state matrix

## Supported states

| State | Kind | Priority | Trigger | Semantics |
|---|---|---|---|---|
| `default` | layout | P0 | Main workspace renders active screen. | main landmark is named. |
| `focused` | interaction | P0 | Route change moves focus to main. | tabIndex=-1 enables focus handoff. |
| `compact` | responsive | P0 | Container is narrow. | DOM order remains source order. |
| `medium` | responsive | P0 | Container has tablet width. | No semantic changes. |
| `expanded` | responsive | P0 | Desktop container available. | No semantic changes. |
| `high-contrast` | mode | P0 | Forced colors/high contrast active. | No semantic changes. |
| `density` | mode | P1 | Density mode applied. | No semantic changes. |

## Explicitly rejected states

- `selected` — not a meaningful state for this layout primitive.
- `checked` — not a meaningful state for this layout primitive.
- `modal` — not a meaningful state for this layout primitive.

## Combination and precedence rules

- Responsive state must not remove keyboard focus or accessible names.
- High-contrast and density modes can combine with every viewport state.
- Drawer-open has priority over rail/expanded visual treatments only below the drawer breakpoint.

## Test coverage contract

- Covered by `packages/atlas-ui/stories/DashboardResponsive.stories.tsx`.
- Covered by `scripts/dashboard_responsive_lint.py`.
- Covered by component/state matrix static gates.

## Accessibility notes

- named main landmark required.
- programmatic focus supports route changes.
- container queries avoid viewport-only content behavior.
