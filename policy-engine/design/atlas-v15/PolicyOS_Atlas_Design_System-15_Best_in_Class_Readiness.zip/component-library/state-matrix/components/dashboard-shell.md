# DashboardShell state matrix

## Supported states

| State | Kind | Priority | Trigger | Semantics |
|---|---|---|---|---|
| `default` | layout | P0 | Shell renders with persistent sidebar layout. | Composition preserves sidebar and main workspace. |
| `drawer-open` | navigation | P0 | navOpen=true on compact shell. | Backdrop is a native button with an accessible close name. |
| `compact` | responsive | P0 | Viewport is below compact drawer breakpoint. | Landmarks remain stable; nav is off-canvas rather than duplicated. |
| `rail` | responsive | P0 | Viewport is in compact-desktop band. | Labels remain available through accessible names. |
| `expanded` | responsive | P0 | Viewport reaches desktop baseline. | No semantic changes. |
| `high-contrast` | mode | P0 | Forced colors or high-contrast mode active. | No semantic changes. |
| `density` | mode | P1 | Density mode applied. | No semantic changes. |

## Explicitly rejected states

- `modal-dialog` — not a meaningful state for this layout primitive.
- `selected` — not a meaningful state for this layout primitive.
- `invalid` — not a meaningful state for this layout primitive.

## Combination and precedence rules

- Responsive state must not remove keyboard focus or accessible names.
- High-contrast and density modes can combine with every viewport state.
- Drawer-open has priority over rail/expanded visual treatments only below the drawer breakpoint.

## Test coverage contract

- Covered by `packages/atlas-ui/stories/DashboardResponsive.stories.tsx`.
- Covered by `scripts/dashboard_responsive_lint.py`.
- Covered by component/state matrix static gates.

## Accessibility notes

- preserves one primary navigation and one main landmark.
- drawer backdrop is a native button.
- does not transform-scale content.
