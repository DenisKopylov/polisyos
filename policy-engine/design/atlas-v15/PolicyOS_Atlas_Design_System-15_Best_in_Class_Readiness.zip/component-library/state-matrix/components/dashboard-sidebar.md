# DashboardSidebar state matrix

## Supported states

| State | Kind | Priority | Trigger | Semantics |
|---|---|---|---|---|
| `default` | navigation | P0 | Sidebar renders expanded. | nav landmark exposes primary screens. |
| `current` | navigation | P0 | A nav item matches activeId. | aria-current="page" is set on the current item. |
| `rail` | responsive | P0 | Compact desktop shell. | Buttons keep title/aria-label for names. |
| `drawer-open` | responsive | P0 | open=true on compact shell. | Navigation remains the primary nav landmark. |
| `drawer-closed` | responsive | P0 | open=false on compact shell. | Closed drawer must not trap focus. |
| `high-contrast` | mode | P0 | Forced colors or high-contrast mode active. | No semantic changes. |
| `density` | mode | P1 | Density mode applied. | Target size remains within accessibility policy. |

## Explicitly rejected states

- `invalid` — not a meaningful state for this layout primitive.
- `loading` — not a meaningful state for this layout primitive.
- `pressed-toggle` — not a meaningful state for this layout primitive.

## Combination and precedence rules

- Responsive state must not remove keyboard focus or accessible names.
- High-contrast and density modes can combine with every viewport state.
- Drawer-open has priority over rail/expanded visual treatments only below the drawer breakpoint.

## Test coverage contract

- Covered by `packages/atlas-ui/stories/DashboardResponsive.stories.tsx`.
- Covered by `scripts/dashboard_responsive_lint.py`.
- Covered by component/state matrix static gates.

## Accessibility notes

- aria-current marks current screen.
- icon-only rail keeps labels in accessible names.
- target sizes stay token-backed.
