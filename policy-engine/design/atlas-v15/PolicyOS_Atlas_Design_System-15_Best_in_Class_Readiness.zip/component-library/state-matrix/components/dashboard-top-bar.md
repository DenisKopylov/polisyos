# DashboardTopBar state matrix

**Matrix id:** `atlas.stateMatrix.DashboardTopBar.v13`  
**Version:** `13.0.0-responsive-dashboard`  
**Source:** `packages/atlas-ui/src/components/DashboardShell/DashboardTopBar.tsx`  
**Canonical JSON:** `component-library/state-matrix/component-state-matrix.json#/components/DashboardTopBar`

## Anatomy

- header
- menu button
- kicker
- title
- subtitle
- actions

## Supported states

| State | Kind | Trigger | Visual contract | DOM / ARIA contract | Tokens | Keyboard | Priority |
|---|---|---|---|---|---|---|---|
| `default` | layout | Title and optional actions render. | Sticky-sized bar with tokenized surface. | Header contains the current page title. | `--atlas-dashboard-topbar-height` | Tab reaches menu and actions. | P0 |
| `menu-closed` | overlay | menuOpen is false. | Menu button shows closed state. | aria-expanded=false. | `--atlas-button-ghost-bg` | Enter or Space activates menu button. | P0 |
| `menu-open` | overlay | menuOpen is true. | Menu button remains visible and connected to drawer. | aria-expanded=true and aria-controls references sidebar. | `--focus-ring` | Activation can close or delegate to shell. | P0 |
| `actions-overflow` | layout | Actions exceed narrow width. | Actions row scrolls locally rather than forcing page overflow. | No semantic change. | `--atlas-dashboard-main-padding-mobile` | Each action remains keyboard reachable. | P0 |
| `compact-title` | layout | Narrow viewport or compact density. | Title truncates with ellipsis; subtitle may wrap or hide by product choice. | Full title should remain available in document title or main heading. | `--text-lg` | No keyboard change. | P1 |
| `focus-visible` | interaction | Keyboard focus reaches menu/action controls. | Focus ring is visible over glass surfaces. | Native focus is exposed. | `--focus-ring` | Tab and Shift+Tab order is predictable. | P0 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | Borders, focus rings and active navigation remain visible without relying on translucency. | No semantic change; system colors are honored in forced-colors. | `--focus-ring`, `--line` | Keyboard order and activation stay identical. | P0 |
| `density` | mode | Shell or ancestor sets data-density. | Padding, topbar height and gaps follow density tokens while preserving target size. | No semantic change. | `--atlas-dashboard-main-padding`, `--target-min` | All controls remain reachable and operable. | P1 |

## Explicitly rejected states

| State | Rationale | Alternative |
|---|---|---|
| `title-image-only` | Page identity must not rely on a logo or image. | Use text title plus optional logo. |

## Combination and precedence rules

| Rule |
|---|
| menu-open can combine with high-contrast and density. |
| actions-overflow must not hide focus rings. |
| compact-title cannot remove document title updates. |

## Test coverage contract

| Layer | Evidence |
|---|---|
| static | responsive_dashboard_lint |
| story | ResponsiveDashboard.stories.tsx |
| runtime | viewport/action overflow fixture |
| manual | keyboard menu button smoke test |

## Accessibility notes

- Menu button requires aria-controls when it opens a sidebar.
- Topbar title should match or summarize the current main landmark.

## Mode coverage

- `light`
- `dark`
- `high-contrast`
- `forced-colors`
- `density`
- `reduced-motion`
