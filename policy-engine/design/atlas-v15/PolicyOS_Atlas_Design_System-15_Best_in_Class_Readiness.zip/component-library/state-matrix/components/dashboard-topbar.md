# DashboardTopBar state matrix

**Matrix id:** `atlas.stateMatrix.DashboardTopBar.v13`  
**Version:** `13.0.0-dashboard-responsive`  
**Source:** `packages/atlas-ui/src/components/Responsive/DashboardTopBar.tsx`  
**Canonical JSON:** `component-library/state-matrix/component-state-matrix.json#/components/DashboardTopBar`

## Anatomy

- header
- start slot
- menu button slot
- copy block
- actions slot

## Supported states

| State | Kind | Trigger | Visual contract | DOM / ARIA contract | Tokens | Keyboard | Priority |
|---|---|---|---|---|---|---|---|
| `default` | layout | `default` responsive condition or prop is active. | Uses responsive tokens, grid rules and media/container query behavior without viewport scaling. | Landmarks, DOM order and accessible names remain stable across breakpoints. | `--atlas-responsive-grid-gap`, `--atlas-shell-main-padding`, `--focus-ring` | Keyboard order follows DOM order; focus remains visible and is not clipped. | P0 |
| `menu-available` | layout | `menu-available` responsive condition or prop is active. | Uses responsive tokens, grid rules and media/container query behavior without viewport scaling. | Landmarks, DOM order and accessible names remain stable across breakpoints. | `--atlas-responsive-grid-gap`, `--atlas-shell-main-padding`, `--focus-ring` | Keyboard order follows DOM order; focus remains visible and is not clipped. | P0 |
| `menu-expanded` | interaction | `menu-expanded` responsive condition or prop is active. | Uses responsive tokens, grid rules and media/container query behavior without viewport scaling. | Landmarks, DOM order and accessible names remain stable across breakpoints. | `--atlas-responsive-grid-gap`, `--atlas-shell-main-padding`, `--focus-ring` | Keyboard order follows DOM order; focus remains visible and is not clipped. | P0 |
| `title-overflow` | layout | `title-overflow` responsive condition or prop is active. | Uses responsive tokens, grid rules and media/container query behavior without viewport scaling. | Landmarks, DOM order and accessible names remain stable across breakpoints. | `--atlas-responsive-grid-gap`, `--atlas-shell-main-padding`, `--focus-ring` | Keyboard order follows DOM order; focus remains visible and is not clipped. | P0 |
| `high-contrast` | mode | `high-contrast` responsive condition or prop is active. | Uses responsive tokens, grid rules and media/container query behavior without viewport scaling. | Landmarks, DOM order and accessible names remain stable across breakpoints. | `--atlas-responsive-grid-gap`, `--atlas-shell-main-padding`, `--focus-ring` | Keyboard order follows DOM order; focus remains visible and is not clipped. | P0 |
| `density` | mode | `density` responsive condition or prop is active. | Uses responsive tokens, grid rules and media/container query behavior without viewport scaling. | Landmarks, DOM order and accessible names remain stable across breakpoints. | `--atlas-responsive-grid-gap`, `--atlas-shell-main-padding`, `--focus-ring` | Keyboard order follows DOM order; focus remains visible and is not clipped. | P0 |

## Explicitly rejected states

| State | Rationale | Alternative |
|---|---|---|
| `desktop-only` | Top bar exists to support drawer viewports. | Use DashboardShell rail on desktop. |

## Combination and precedence rules

| Rule |
|---|
| Focus-visible and keyboard access must survive every breakpoint. |
| Density cannot reduce required target size below the accessibility floor. |
| Print mode removes navigation chrome but preserves evidence content. |

## Test coverage contract

| Layer | Evidence |
|---|---|
| static | responsive_lint + component_lint + state_matrix_lint |
| story | ResponsiveDashboard.stories.tsx + StateMatrix.stories.tsx |
| runtime | Playwright viewport matrix backlog |
| manual | Phone/tablet/laptop/desktop/print review |

## Accessibility notes

- header landmark.
- consumer-supplied menu button.
- visible title.
- status actions optional.

## Mode coverage

- `high-contrast`
- `reduced-motion`
- `density`
- `print`
