# DataTable state matrix

**Matrix id:** `atlas.stateMatrix.DataTable.v11`  
**Version:** `11.0.0-state-matrix`  
**Source:** `packages/atlas-ui/src/components/DataTable/DataTable.tsx`  
**Canonical JSON:** `component-library/state-matrix/component-state-matrix.json#/components/DataTable`

## Anatomy

- scroll wrapper
- table
- caption
- thead
- tbody
- rows/cells

## Supported states

| State | Kind | Trigger | Visual contract | DOM / ARIA contract | Tokens | Keyboard | Priority |
|---|---|---|---|---|---|---|---|
| `with-rows` | data | rows.length > 0. | Rows render with tokenized borders and hover background. | Native table semantics with caption and column headers. | `--atlas-table-surface`, `--atlas-table-row-border` | No additional keyboard behavior. | P0 |
| `empty` | data | rows.length === 0. | Single empty row spans all columns. | Native table semantics remain intact. | `--atlas-empty-state-surface` | No additional keyboard behavior. | P0 |
| `row-hover` | interaction | Pointer moves over row. | Row hover background token. | No ARIA change. | `--atlas-table-row-hover-bg` | No additional keyboard behavior. | P1 |
| `horizontal-overflow` | layout | Table wider than container. | Wrapper scrolls horizontally without clipping focus or caption. | Native table remains inside scroll region. | `--atlas-table-border` | Keyboard users can tab to controls inside cells. | P1 |
| `captioned` | a11y | caption prop is required. | Caption is visually present and aligned start. | caption element names table context. | `--atlas-table-caption` | No additional keyboard behavior. | P0 |
| `numeric-align-end` | data | column.align="end". | Numeric cells align to end for scanning. | No semantic change. | `--space-3` | No additional keyboard behavior. | P1 |
| `sorted-backlog` | backlog | Sorting is not in base DataTable yet. | Not implemented in v11. | Future aria-sort contract required. | — | Future keyboard support on sortable headers. | P2 |
| `selected-row-backlog` | backlog | Row selection is not in base DataTable yet. | Not implemented in v11. | Future checkbox/aria-selected contract required. | — | No additional keyboard behavior. | P2 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | Borders and focus rings remain visible; color-only meaning must have text or shape fallback. | No semantic change; forced-colors uses system colors where appropriate. | `--focus-ring`, `--focus-ring-outer` | Keyboard order and activation stay identical. | P0 |
| `reduced-motion` | mode | User sets prefers-reduced-motion: reduce. | Transitions, spinner and shimmer motion collapse to reduced duration or static treatment. | No semantic change; loading labels remain exposed. | `--motion-reduced-duration` | Keyboard order and activation stay identical. | P0 |
| `density` | mode | Container or product shell applies a density mode. | Spacing and control height use density tokens while preserving 24px/44px target guidance as applicable. | No semantic change. | `--atlas-control-height-sm`, `--atlas-control-height-md`, `--atlas-control-height-lg`, `--target-min` | Touch and keyboard targets remain operable. | P1 |

## Explicitly rejected states

| State | Rationale | Alternative |
|---|---|---|
| `virtualized` | Base table does not virtualize rows. | Use a future data-grid primitive for large datasets. |
| `treegrid` | Hierarchical data is outside native table contract. | Use composition or request a new component state through the DS RFC process. |

## Combination and precedence rules

| Rule |
|---|
| empty and with-rows are mutually exclusive |
| caption is always required |
| row-hover must not be the only way to expose actions |

## Test coverage contract

| Layer | Evidence |
|---|---|
| static | component_lint + state_matrix_lint |
| story | FeedbackData.stories.tsx + StateMatrix.stories.tsx |
| runtime | native table/caption test backlog |
| manual | Horizontal overflow keyboard review |

## Accessibility notes

- Caption is required for context.
- Sorting/selection are explicitly backlog, not silently partial.

## Mode coverage

- `high-contrast`
- `reduced-motion`
- `density`
