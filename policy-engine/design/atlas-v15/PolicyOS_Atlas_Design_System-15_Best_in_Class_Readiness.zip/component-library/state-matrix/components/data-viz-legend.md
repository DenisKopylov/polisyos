# DataVizLegend state matrix

Canonical component: `DataVizLegend`  
Source: `packages/atlas-ui/src/components/DataVisualization/DataVizLegend.tsx`

## Supported states

| State | Kind | Trigger | DOM / ARIA contract | Priority |
|---|---|---|---|---|
| `with-items` | data-viz | DataVizLegend enters the `with-items` state. | Accessible name, visible summary or data alternative remains stable. | P0 |
| `empty` | data-viz | DataVizLegend enters the `empty` state. | Accessible name, visible summary or data alternative remains stable. | P0 |
| `row` | data-viz | DataVizLegend enters the `row` state. | Accessible name, visible summary or data alternative remains stable. | P0 |
| `column` | data-viz | DataVizLegend enters the `column` state. | Accessible name, visible summary or data alternative remains stable. | P0 |
| `patterned` | data-viz | DataVizLegend enters the `patterned` state. | Accessible name, visible summary or data alternative remains stable. | P1 |
| `high-contrast` | mode | DataVizLegend enters the `high-contrast` state. | Accessible name, visible summary or data alternative remains stable. | P0 |
| `density` | mode | DataVizLegend enters the `density` state. | Accessible name, visible summary or data alternative remains stable. | P1 |

## Explicitly rejected states

- `color-only`: critical meaning cannot be encoded with color alone.
- `tooltip-only`: values cannot exist only on hover or focus tooltip.

## Combination and precedence rules

- `disabled` or non-interactive contexts never remove chart summary or data alternative.
- `focus-visible` has precedence over hover, selected and active visual treatments.
- `high-contrast` can collapse palette variety but must preserve order, labels and non-color encodings.
- `density` modifies spacing and tick density only.

## Test coverage contract

- Story: `packages/atlas-ui/stories/DataVisualization.stories.tsx`.
- Lint: `scripts/data_viz_lint.py`.
- Component gate: `scripts/component_lint.py`.
- State gate: `scripts/state_matrix_lint.py`.

## Accessibility notes

- role=list/listitem.
- labels visible as text.
- pattern support for non-color encoding.
- Complex charts require a data alternative.
- Color-only meaning is rejected.

## Mode coverage

- high-contrast
- density
- reduced-motion
