# DataVizTable state matrix

Canonical ID: `atlas.stateMatrix.DataVizTable.v14`

## Supported states

- `with-rows` — With rows: Rows are present.
- `empty` — Empty: Rows are absent.
- `sorted` — Sorted: Consumer indicates sorted column.
- `overflow-scroll` — Overflow scroll: Table exceeds container width.
- `export` — Export evidence: Table included in print/PDF/CSV export.
- `high-contrast` — High contrast: High contrast active.
- `density` — Density: Compact or condensed table.

## Explicitly rejected states

- `color-only` — data visualization cannot rely on color alone.
- `tooltip-only-values` — decision-critical values require visible copy or table equivalent.

## Combination and precedence rules

- `error` wins over ready visual states.
- `loading` and `error` are mutually exclusive.
- `focus-visible` must remain visible above hover, selected, open and stale states.
- `high-contrast`, `density`, `forced-colors` and `print` are overlay modes.

## Test coverage contract

- Storybook story: `packages/atlas-ui/stories/DataVisualization.stories.tsx`.
- Component lint verifies source/docs/story coverage.
- State matrix lint verifies state fields, rejected states and mode coverage.
- Data visualization lint verifies chart grammar, table-equivalent and token contract.

## Accessibility notes

Use title/summary/description semantics, table equivalents for complex charts, non-color encodings and forced-colors fallbacks.
