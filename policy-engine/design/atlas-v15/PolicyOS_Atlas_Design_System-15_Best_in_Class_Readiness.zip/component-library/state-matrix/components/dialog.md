# Dialog state matrix

**Matrix id:** `atlas.stateMatrix.Dialog.v11`  
**Version:** `11.0.0-state-matrix`  
**Source:** `packages/atlas-ui/src/components/Dialog/Dialog.tsx`  
**Canonical JSON:** `component-library/state-matrix/component-state-matrix.json#/components/Dialog`

## Anatomy

- backdrop
- dialog panel
- title
- description
- close button
- content
- actions footer

## Supported states

| State | Kind | Trigger | Visual contract | DOM / ARIA contract | Tokens | Keyboard | Priority |
|---|---|---|---|---|---|---|---|
| `closed` | overlay | open=false. | Dialog is not rendered. | No dialog node exists in DOM. | — | Focus remains where it was. | P0 |
| `open` | overlay | open=true. | Scrim and panel surface tokens. | role=dialog, aria-modal=true, labelled by title and described by description. | `--atlas-dialog-scrim`, `--atlas-dialog-surface`, `--atlas-dialog-border` | Initial focus moves to close button. | P0 |
| `focus-trap` | a11y | Dialog is open and user tabs through focusables. | Focus never escapes panel while open. | Document keydown handler wraps focus. | — | Tab/Shift+Tab cycle within dialog. | P0 |
| `escape-dismiss` | interaction | User presses Escape. | Dialog closes without extra animation. | onClose fires and focus returns to previous element. | — | Escape closes once. | P0 |
| `backdrop-dismiss` | interaction | User clicks backdrop. | Dialog closes from outside click. | onClose fires; panel click stops propagation. | — | Pointer only; keyboard users use close/Escape. | P0 |
| `with-actions` | content | actions prop is provided. | Footer/action slot follows content. | Actions retain their own native semantics. | `--space-4` | Tab order reaches actions after content. | P0 |
| `destructive-confirmation` | content | Dialog contains danger action. | Danger action must be explicit and secondary safe exit remains available. | Use Button danger plus copy; no ARIA change. | `--atlas-button-danger-bg`, `--atlas-button-danger-text` | Tab order puts safe close/cancel before destructive action when appropriate. | P1 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | Borders and focus rings remain visible; color-only meaning must have text or shape fallback. | No semantic change; forced-colors uses system colors where appropriate. | `--focus-ring`, `--focus-ring-outer` | Keyboard order and activation stay identical. | P0 |
| `reduced-motion` | mode | User sets prefers-reduced-motion: reduce. | Transitions, spinner and shimmer motion collapse to reduced duration or static treatment. | No semantic change; loading labels remain exposed. | `--motion-reduced-duration` | Keyboard order and activation stay identical. | P0 |
| `density` | mode | Container or product shell applies a density mode. | Spacing and control height use density tokens while preserving 24px/44px target guidance as applicable. | No semantic change. | `--atlas-control-height-sm`, `--atlas-control-height-md`, `--atlas-control-height-lg`, `--target-min` | Touch and keyboard targets remain operable. | P1 |

## Explicitly rejected states

| State | Rationale | Alternative |
|---|---|---|
| `disabled` | Dialog is an overlay, not a disabled control. | Use composition or request a new component state through the DS RFC process. |
| `hover` | Dialog panel itself is not interactive. | Use composition or request a new component state through the DS RFC process. |

## Combination and precedence rules

| Rule |
|---|
| open implies focus-trap |
| Escape/backdrop dismissal can be disabled in a future blocking-dialog variant only by explicit API |
| destructive-confirmation requires clear action labels |

## Test coverage contract

| Layer | Evidence |
|---|---|
| static | component_lint + state_matrix_lint |
| story | NavigationOverlay.stories.tsx + StateMatrix.stories.tsx |
| runtime | focus trap/return test backlog |
| manual | Screen-reader modal review |

## Accessibility notes

- Dialog must always have a title.
- Focus must return to invoking control.

## Mode coverage

- `high-contrast`
- `reduced-motion`
- `density`
