# EmptyState state matrix

**Matrix id:** `atlas.stateMatrix.EmptyState.v11`  
**Version:** `11.0.0-state-matrix`  
**Source:** `packages/atlas-ui/src/components/EmptyState/EmptyState.tsx`  
**Canonical JSON:** `component-library/state-matrix/component-state-matrix.json#/components/EmptyState`

## Anatomy

- section
- optional icon
- title
- description
- optional action

## Supported states

| State | Kind | Trigger | Visual contract | DOM / ARIA contract | Tokens | Keyboard | Priority |
|---|---|---|---|---|---|---|---|
| `empty` | content | No data exists yet. | Icon/title/description with calm neutral surface. | section with visible heading. | `--atlas-empty-state-surface`, `--atlas-empty-title` | No additional keyboard behavior. | P0 |
| `permission-denied` | content | User lacks permission. | Same surface; copy names permission and next step. | No fake disabled controls; action links to request access if available. | `--atlas-empty-state-border` | No additional keyboard behavior. | P0 |
| `filtered-out` | content | Filters remove all rows/items. | Copy points to filter reset action. | Action button clears filters. | `--atlas-empty-state-surface` | No additional keyboard behavior. | P0 |
| `not-found` | content | Requested object cannot be found. | Copy distinguishes missing vs unauthorized when safe. | Heading conveys state. | `--atlas-empty-state-border` | No additional keyboard behavior. | P1 |
| `offline` | content | Network state prevents loading. | Copy names offline/retry behavior. | Retry action is a native button if provided. | `--atlas-empty-state-border` | No additional keyboard behavior. | P1 |
| `with-action` | content | action prop is provided. | Action is placed after explanatory copy. | Action keeps native semantics. | `--atlas-button-primary-bg` | Tab reaches action after description. | P0 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | Borders and focus rings remain visible; color-only meaning must have text or shape fallback. | No semantic change; forced-colors uses system colors where appropriate. | `--focus-ring`, `--focus-ring-outer` | Keyboard order and activation stay identical. | P0 |
| `reduced-motion` | mode | User sets prefers-reduced-motion: reduce. | Transitions, spinner and shimmer motion collapse to reduced duration or static treatment. | No semantic change; loading labels remain exposed. | `--motion-reduced-duration` | Keyboard order and activation stay identical. | P0 |
| `density` | mode | Container or product shell applies a density mode. | Spacing and control height use density tokens while preserving 24px/44px target guidance as applicable. | No semantic change. | `--atlas-control-height-sm`, `--atlas-control-height-md`, `--atlas-control-height-lg`, `--target-min` | Touch and keyboard targets remain operable. | P1 |

## Explicitly rejected states

| State | Rationale | Alternative |
|---|---|---|
| `hover` | EmptyState container is not interactive. | Use composition or request a new component state through the DS RFC process. |
| `loading` | Use Skeleton for loading; EmptyState is terminal/empty content. | Use composition or request a new component state through the DS RFC process. |

## Combination and precedence rules

| Rule |
|---|
| with-action can combine with any content state |
| permission-denied copy must avoid leaking unauthorized object details |
| filtered-out should offer reset when possible |

## Test coverage contract

| Layer | Evidence |
|---|---|
| static | state_matrix_lint |
| story | FeedbackData.stories.tsx + StateMatrix.stories.tsx |
| runtime | heading/action test backlog |
| manual | Content QA for permission and privacy wording |

## Accessibility notes

- Title should name the state, not blame the user.
- Description should include the next recoverable action.

## Mode coverage

- `high-contrast`
- `reduced-motion`
- `density`
