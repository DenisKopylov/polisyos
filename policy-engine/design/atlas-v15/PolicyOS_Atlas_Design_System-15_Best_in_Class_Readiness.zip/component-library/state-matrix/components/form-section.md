# FormSection state matrix

Component id: `atlas.stateMatrix.FormSection.v12`

Docs: `component-library/components/form-section.md`

## Supported states

| State | Priority | Trigger | Semantics |
|---|---|---|---|
| `default` | `P0` | Section renders with title and fields. | section has aria-labelledby pointing to title. |
| `with-aside` | `P1` | aside prop is supplied. | Aside remains in same labelled region. |
| `focus-visible` | `P0` | Nested field receives focus. | No roving tabindex is introduced. |
| `responsive` | `P0` | Viewport is narrow. | Reading order remains title, description, fields. |
| `high-contrast` | `P1` | High contrast mode active. | No semantic change. |
| `density` | `P1` | Density mode active. | No semantic change. |

## Explicitly rejected states

| State | Rationale | Alternative |
|---|---|---|
| `invalid` | Validation belongs to fields or ValidationSummary, not the layout section. | Place invalid controls inside the section. |

## Combination and precedence rules

- Invalid state overrides hover and selected borders but must not suppress focus-visible.
- Disabled suppresses hover, active and submit behaviors.
- High-contrast and density are mode overlays, not mutually exclusive component states.

## Test coverage contract

- component_lint manifest/source/docs/story gate
- state_matrix_lint state contract gate
- Storybook-ready examples in DataEntry.stories.tsx
- manual keyboard and screen reader checklist in component-library/forms/validation-and-errors.md

## Accessibility notes

- Prefer native form controls before ARIA widgets.
- Every input has a visible label or legend and error/help ids wired through aria-describedby.
- Validation errors are recoverable and summarized before fields.
- Autocomplete/input purpose should be set by product teams for user personal data.

## Mode coverage

`light`, `dark`, `high-contrast`, `forced-colors`, `density`, `reduced-motion`
