# Form state matrix

Component id: `atlas.stateMatrix.Form.v12`

Docs: `component-library/components/form.md`

## Supported states

| State | Priority | Trigger | Semantics |
|---|---|---|---|
| `default` | `P0` | Form renders with no validation summary. | form element is native and noValidate defaults true to support custom accessible validation. |
| `invalid` | `P0` | errorSummary is provided. | role alert summary is read before the user re-enters fields. |
| `submitting` | `P1` | Product disables submit actions or sets aria-busy while saving. | aria-busy may be applied by consumer at form or region level. |
| `focus-visible` | `P0` | Focus moves through controls inside the form. | DOM order matches visual order. |
| `high-contrast` | `P1` | High contrast mode active. | Native form semantics preserved. |
| `density` | `P1` | Density mode active. | No controls become smaller than target constraints. |

## Explicitly rejected states

| State | Rationale | Alternative |
|---|---|---|
| `field-level-error` | Form orchestrates errors but does not own individual field errors. | Use field error props and ValidationSummary. |

## Combination and precedence rules

- Invalid state overrides hover and selected borders but must not suppress focus-visible.
- Disabled suppresses hover, active and submit behaviors.
- High-contrast and density are mode overlays, not mutually exclusive component states.

## Test coverage contract

- component_lint manifest/source/docs/story gate
- state_matrix_lint state contract gate
- Storybook-ready examples in DataEntry.stories.tsx
- manual keyboard and screen reader checklist in component-library/forms/validation-and-errors.md

## Accessibility notes

- Prefer native form controls before ARIA widgets.
- Every input has a visible label or legend and error/help ids wired through aria-describedby.
- Validation errors are recoverable and summarized before fields.
- Autocomplete/input purpose should be set by product teams for user personal data.

## Mode coverage

`light`, `dark`, `high-contrast`, `forced-colors`, `density`, `reduced-motion`
