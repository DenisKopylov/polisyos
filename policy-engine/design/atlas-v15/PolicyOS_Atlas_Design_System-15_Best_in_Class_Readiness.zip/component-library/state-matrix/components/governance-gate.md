# GovernanceGate state matrix

**Matrix id:** `atlas.stateMatrix.GovernanceGate.v11`  
**Version:** `11.0.0-state-matrix`  
**Source:** `packages/atlas-ui/src/components/GovernanceGate/GovernanceGate.tsx`  
**Canonical JSON:** `component-library/state-matrix/component-state-matrix.json#/components/GovernanceGate`

## Anatomy

- section
- heading
- description
- evidence count
- status badge
- action slot

## Supported states

| State | Kind | Trigger | Visual contract | DOM / ARIA contract | Tokens | Keyboard | Priority |
|---|---|---|---|---|---|---|---|
| `pass` | domain-status | status="pass". | Approved gate surface and success badge. | Status badge can announce dynamic change with role=status. | `--atlas-gate-approved-bg`, `--atlas-gate-approved-text` | No additional keyboard behavior. | P0 |
| `review` | domain-status | status="review". | Review gate surface and warning badge. | Status text and description explain pending review. | `--atlas-gate-review-bg`, `--atlas-gate-review-text` | No additional keyboard behavior. | P0 |
| `blocked` | domain-status | status="blocked". | Blocked gate surface and danger badge. | Description must identify blocker or next step. | `--atlas-gate-blocked-bg`, `--atlas-gate-blocked-text` | No additional keyboard behavior. | P0 |
| `with-evidence-count` | content | evidenceCount is a number. | Metadata line shows evidence count. | Count appears as text, not only visual badge. | `--atlas-metric-hint` | No additional keyboard behavior. | P0 |
| `with-action` | content | action prop is provided. | Action appears below/after gate header. | Action keeps native semantics. | `--atlas-button-primary-bg` | Tab reaches action after gate content. | P0 |
| `stale-evidence` | domain-status | Consumer uses review/blocked plus stale evidence copy. | Warning/danger tone plus timestamp/source copy. | Evidence freshness is textual. | `--atlas-domain-evidence-stale-surface` | No additional keyboard behavior. | P1 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | Borders and focus rings remain visible; color-only meaning must have text or shape fallback. | No semantic change; forced-colors uses system colors where appropriate. | `--focus-ring`, `--focus-ring-outer` | Keyboard order and activation stay identical. | P0 |
| `reduced-motion` | mode | User sets prefers-reduced-motion: reduce. | Transitions, spinner and shimmer motion collapse to reduced duration or static treatment. | No semantic change; loading labels remain exposed. | `--motion-reduced-duration` | Keyboard order and activation stay identical. | P0 |
| `density` | mode | Container or product shell applies a density mode. | Spacing and control height use density tokens while preserving 24px/44px target guidance as applicable. | No semantic change. | `--atlas-control-height-sm`, `--atlas-control-height-md`, `--atlas-control-height-lg`, `--target-min` | Touch and keyboard targets remain operable. | P1 |

## Explicitly rejected states

| State | Rationale | Alternative |
|---|---|---|
| `hover` | GovernanceGate container is not interactive. | Use composition or request a new component state through the DS RFC process. |
| `selected` | Gate status is not a selectable UI choice. | Use composition or request a new component state through the DS RFC process. |

## Combination and precedence rules

| Rule |
|---|
| pass/review/blocked are mutually exclusive |
| blocked requires next-step copy |
| with-action can combine with all statuses |

## Test coverage contract

| Layer | Evidence |
|---|---|
| static | component_lint + state_matrix_lint |
| story | GovernanceGate.stories.tsx + StateMatrix.stories.tsx |
| runtime | status text/accessibility test backlog |
| manual | Domain review for blocker copy |

## Accessibility notes

- Gate status must be represented in text.
- Evidence count must not be the only proof of readiness.

## Mode coverage

- `high-contrast`
- `reduced-motion`
- `density`
