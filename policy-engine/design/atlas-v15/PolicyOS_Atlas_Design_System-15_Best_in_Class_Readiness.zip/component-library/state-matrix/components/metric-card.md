# MetricCard state matrix

**Matrix id:** `atlas.stateMatrix.MetricCard.v11`  
**Version:** `11.0.0-state-matrix`  
**Source:** `packages/atlas-ui/src/components/MetricCard/MetricCard.tsx`  
**Canonical JSON:** `component-library/state-matrix/component-state-matrix.json#/components/MetricCard`

## Anatomy

- section container
- metric label
- value
- hint
- optional badge

## Supported states

| State | Kind | Trigger | Visual contract | DOM / ARIA contract | Tokens | Keyboard | Priority |
|---|---|---|---|---|---|---|---|
| `default` | content | label and value are provided. | Metric surface, label and large value use component tokens. | section has synthesized aria-label label/value/hint. | `--atlas-metric-surface`, `--atlas-metric-label` | No additional keyboard behavior. | P0 |
| `with-badge` | content | badge prop is provided. | Badge appears in metric header; value remains dominant. | Badge keeps its own status semantics. | `--atlas-badge-neutral-bg` | No additional keyboard behavior. | P0 |
| `large-value` | content | Value is multi-digit or percentage. | Value remains on a single line where possible; wraps without clipping. | Accessible label includes value as string. | `--text-4xl` | No additional keyboard behavior. | P1 |
| `stale` | status | Consumer composes warning badge/hint for stale data. | Use warning badge and explicit timestamp copy. | Status must be in text, not only color. | `--atlas-badge-warn-bg`, `--atlas-badge-warn-text` | No additional keyboard behavior. | P1 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | Borders and focus rings remain visible; color-only meaning must have text or shape fallback. | No semantic change; forced-colors uses system colors where appropriate. | `--focus-ring`, `--focus-ring-outer` | Keyboard order and activation stay identical. | P0 |
| `reduced-motion` | mode | User sets prefers-reduced-motion: reduce. | Transitions, spinner and shimmer motion collapse to reduced duration or static treatment. | No semantic change; loading labels remain exposed. | `--motion-reduced-duration` | Keyboard order and activation stay identical. | P0 |
| `density` | mode | Container or product shell applies a density mode. | Spacing and control height use density tokens while preserving 24px/44px target guidance as applicable. | No semantic change. | `--atlas-control-height-sm`, `--atlas-control-height-md`, `--atlas-control-height-lg`, `--target-min` | Touch and keyboard targets remain operable. | P1 |

## Explicitly rejected states

| State | Rationale | Alternative |
|---|---|---|
| `hover` | MetricCard is not interactive. | Use composition or request a new component state through the DS RFC process. |
| `selected` | MetricCard is a display summary, not a selectable control. | Use composition or request a new component state through the DS RFC process. |

## Combination and precedence rules

| Rule |
|---|
| with-badge can combine with stale and density |
| stale requires explicit copy in hint or badge |
| large-value must not reduce contrast |

## Test coverage contract

| Layer | Evidence |
|---|---|
| static | state_matrix_lint |
| story | Foundations.stories.tsx + StateMatrix.stories.tsx |
| runtime | accessible-name smoke test backlog |
| manual | Number formatting review |

## Accessibility notes

- Always include units or context in label/hint.
- Do not rely on color to indicate trend.

## Mode coverage

- `high-contrast`
- `reduced-motion`
- `density`
