# Panel state matrix

**Matrix id:** `atlas.stateMatrix.Panel.v11`  
**Version:** `11.0.0-state-matrix`  
**Source:** `packages/atlas-ui/src/components/Panel/Panel.tsx`  
**Canonical JSON:** `component-library/state-matrix/component-state-matrix.json#/components/Panel`

## Anatomy

- section container
- optional eyebrow
- heading
- description
- actions region
- content slot

## Supported states

| State | Kind | Trigger | Visual contract | DOM / ARIA contract | Tokens | Keyboard | Priority |
|---|---|---|---|---|---|---|---|
| `default` | layout | Panel renders without hero or actions. | Tokenized panel surface, border and rim shadow. | section labelled by heading when title exists. | `--atlas-panel-surface`, `--atlas-panel-border` | No additional keyboard behavior. | P0 |
| `hero` | variant | hero=true. | Elevated hero background; still uses panel border. | No semantic change. | `--atlas-panel-hero-bg`, `--atlas-panel-border` | No additional keyboard behavior. | P0 |
| `with-actions` | content | actions prop is provided. | Header distributes heading and action controls with token spacing. | Action controls keep their own semantics. | `--space-4` | Tab order follows visual order. | P0 |
| `nested` | layout | Panel is placed inside another surface. | Border/surface remain visible without extra shadows. | Heading level must be chosen to preserve document outline. | `--atlas-panel-surface`, `--radius-card` | No additional keyboard behavior. | P0 |
| `busy` | async | Consumer passes aria-busy=true while panel content refreshes. | No spinner by default; compose Skeleton inside content. | aria-busy=true belongs on the section. | `--atlas-skeleton-base` | Focus should not be stolen during refresh. | P1 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | Borders and focus rings remain visible; color-only meaning must have text or shape fallback. | No semantic change; forced-colors uses system colors where appropriate. | `--focus-ring`, `--focus-ring-outer` | Keyboard order and activation stay identical. | P0 |
| `reduced-motion` | mode | User sets prefers-reduced-motion: reduce. | Transitions, spinner and shimmer motion collapse to reduced duration or static treatment. | No semantic change; loading labels remain exposed. | `--motion-reduced-duration` | Keyboard order and activation stay identical. | P0 |
| `density` | mode | Container or product shell applies a density mode. | Spacing and control height use density tokens while preserving 24px/44px target guidance as applicable. | No semantic change. | `--atlas-control-height-sm`, `--atlas-control-height-md`, `--atlas-control-height-lg`, `--target-min` | Touch and keyboard targets remain operable. | P1 |

## Explicitly rejected states

| State | Rationale | Alternative |
|---|---|---|
| `pressed` | Panel is a container, not a control. | Use composition or request a new component state through the DS RFC process. |
| `selected` | Persistent selection belongs to CardButton, Tabs or choice controls. | Use composition or request a new component state through the DS RFC process. |

## Combination and precedence rules

| Rule |
|---|
| hero can combine with with-actions and busy |
| nested state must preserve readable heading hierarchy |
| busy must not hide already-focused content |

## Test coverage contract

| Layer | Evidence |
|---|---|
| static | component_lint + state_matrix_lint |
| story | Foundations.stories.tsx + StateMatrix.stories.tsx |
| runtime | landmark/name checks backlog |
| manual | Heading hierarchy review |

## Accessibility notes

- Every panel title should map to a real heading.
- Actions must be native buttons/links.

## Mode coverage

- `high-contrast`
- `reduced-motion`
- `density`
