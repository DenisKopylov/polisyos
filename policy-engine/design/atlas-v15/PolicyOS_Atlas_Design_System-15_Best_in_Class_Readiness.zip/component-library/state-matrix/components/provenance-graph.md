# ProvenanceGraph state matrix

**Matrix id:** `atlas.stateMatrix.ProvenanceGraph.v14`  
**Version:** `14.0.0-data-visualization`  
**Source:** `packages/atlas-ui/src/components/DataVisualization/ProvenanceGraph.tsx`  
**Canonical JSON:** `component-library/state-matrix/component-state-matrix.json#/components/ProvenanceGraph`

## Anatomy

- chart frame
- node list
- edge list
- status labels
- data table equivalent

## Supported states

| State | Kind | Trigger | Visual contract | DOM / ARIA contract | Tokens | Keyboard | Priority |
|---|---|---|---|---|---|---|---|
| `ready` | data | Required data arrays contain at least one valid value. | Chart renders with tokenized marks, axes or textual equivalents. | Region or image has accessible title and summary. | `--atlas-dataviz-surface`, `--atlas-series-teal` | Tab reaches any external controls; static chart itself does not require focus. | P0 |
| `empty` | data | Data array is empty or unavailable. | Empty surface and explanatory copy replace misleading blank chart. | data-state="empty" and summary explains that no data is available. | `--atlas-dataviz-empty-surface`, `--atlas-dataviz-caption` | No hidden focus target remains. | P0 |
| `loading` | async | Data request is pending or chart is recalculating. | Loading surface appears without shifting layout. | aria-busy=true on chart frame when applicable. | `--atlas-dataviz-loading-surface`, `--motion-reduced-duration` | No interactive mark can be activated while loading. | P0 |
| `focus-visible` | interaction | Keyboard reaches chart controls, legend filters or actionable marks. | Focus outline uses global focus tokens and is not obscured. | Focused element exposes role, name and state. | `--focus-ring`, `--focus-ring-outer` | Tab and Shift+Tab order remains predictable. | P0 |
| `hover` | interaction | Pointer enters an enabled mark or tooltip trigger. | Hover affordance never contains the only critical value. | No ARIA-only change; details must also exist in summary/table. | `--atlas-dataviz-selection-ring`, `--atlas-dataviz-tooltip-surface` | Keyboard equivalent is required before stable interactive release. | P1 |
| `selected` | interaction | A legend filter or mark selection is active. | Selection uses outline/label/pattern in addition to color. | aria-pressed, aria-selected or textual state is used for actionable controls. | `--atlas-dataviz-selection-ring`, `--atlas-series-teal` | Space/Enter toggles selection when mark is actionable. | P1 |
| `stale-data` | data | Evidence timestamp falls outside freshness policy. | Dashed/patterned treatment and freshness label are shown. | Summary names the stale data caveat. | `--atlas-dataviz-unknown-pattern`, `--atlas-series-gold` | No additional keyboard behavior. | P1 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | System colors, borders, labels and patterns preserve meaning. | No semantic change; color-only meaning remains avoided. | `--atlas-dataviz-border`, `--atlas-dataviz-axis-line` | Keyboard behavior remains identical. | P0 |
| `reduced-motion` | mode | User requests reduced motion. | Animated transitions collapse to static or reduced duration. | No semantic change; updated summaries remain available. | `--motion-reduced-duration` | Keyboard behavior remains identical. | P0 |
| `density` | mode | Dashboard applies compact or condensed density. | Spacing compresses while labels and targets remain usable. | No semantic change. | `--atlas-chart-frame-padding`, `--target-min` | Touch and keyboard targets remain operable. | P1 |
| `print` | mode | Decision packet or browser print mode is active. | Shadows are removed and data table is visible. | Equivalent values remain in document flow. | `--atlas-dataviz-border` | Not applicable to keyboard after export. | P1 |

## Explicitly rejected states

| State | Rationale | Alternative |
|---|---|---|
| `form-submit` | Chart components do not submit data by themselves. | Use Form and Button components around chart filters. |
| `destructive` | Destructive actions belong to controls, not passive visualization marks. | Use Button variant danger or Dialog confirmation. |

## Combination and precedence rules

| Rule |
|---|
| loading and empty states override ready visuals |
| focus-visible must remain visible over hover/selected states |
| high-contrast mode must not remove labels or table equivalents |

## Test coverage contract

| Layer | Evidence |
|---|---|
| static | data_viz_lint, component_lint and state_matrix_lint |
| story | DataVisualization.stories.tsx and StateMatrix.stories.tsx |
| runtime | Component contract tests for public API and state hooks |
| manual | Keyboard, screen-reader summary, high-contrast and print/export review |

## Accessibility notes

- Provide title and summary for every chart.
- Provide data table equivalent or long description for complex charts.
- Never rely on color alone for status, confidence or risk.

## Mode coverage

- `high-contrast`
- `reduced-motion`
- `density`
- `print`
