# RangeField state matrix

Component id: `atlas.stateMatrix.RangeField.v12`

Docs: `component-library/components/range-field.md`

## Supported states

| State | Priority | Trigger | Semantics |
|---|---|---|---|
| `empty` | `P0` | No value or selected item is present. | Control has an associated label and optional help text. |
| `focus-visible` | `P0` | Keyboard focus enters the control. | Focused element is the native control or button. |
| `invalid` | `P0` | Error prop or validation state is supplied. | aria-invalid is true and error id is included in aria-describedby. |
| `disabled` | `P1` | disabled is true. | Native disabled attribute prevents focus and submission. |
| `required` | `P0` | required is true. | required and aria-required are set where applicable. |
| `hover` | `P2` | Pointer hovers an enabled control. | No semantic state change. |
| `high-contrast` | `P1` | forced-colors or high-contrast mode is active. | Native controls retain platform semantics. |
| `density` | `P1` | compact or condensed density mode is active. | DOM order and labels are unchanged. |
| `value-change` | `P0` | Slider thumb value changes. | Native range input exposes current value. |

## Explicitly rejected states

| State | Rationale | Alternative |
|---|---|---|
| `unlabelled` | RangeField requires a visible label. | Use label prop; use VisuallyHidden only when a visible label is impossible. |

## Combination and precedence rules

- Invalid state overrides hover and selected borders but must not suppress focus-visible.
- Disabled suppresses hover, active and submit behaviors.
- High-contrast and density are mode overlays, not mutually exclusive component states.

## Test coverage contract

- component_lint manifest/source/docs/story gate
- state_matrix_lint state contract gate
- Storybook-ready examples in DataEntry.stories.tsx
- manual keyboard and screen reader checklist in component-library/forms/validation-and-errors.md

## Accessibility notes

- Prefer native form controls before ARIA widgets.
- Every input has a visible label or legend and error/help ids wired through aria-describedby.
- Validation errors are recoverable and summarized before fields.
- Autocomplete/input purpose should be set by product teams for user personal data.

## Mode coverage

`light`, `dark`, `high-contrast`, `forced-colors`, `density`, `reduced-motion`
