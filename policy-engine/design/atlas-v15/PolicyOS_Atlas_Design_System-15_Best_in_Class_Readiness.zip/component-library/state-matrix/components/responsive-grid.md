# ResponsiveGrid state matrix

## Supported states

| State | Kind | Priority | Trigger | Semantics |
|---|---|---|---|---|
| `default` | layout | P0 | density="default" or omitted. | No semantic changes. |
| `dense` | layout | P0 | density="dense". | No semantic changes. |
| `wide` | layout | P0 | density="wide". | No semantic changes. |
| `single-column` | responsive | P0 | Container cannot fit multiple columns. | DOM order remains source order. |
| `multi-column` | responsive | P0 | Container can fit two or more columns. | DOM order remains source order. |
| `high-contrast` | mode | P0 | Forced colors/high contrast active. | No semantic changes. |
| `density` | mode | P1 | Density mode applied. | No semantic changes. |

## Explicitly rejected states

- `invalid` — not a meaningful state for this layout primitive.
- `selected` — not a meaningful state for this layout primitive.
- `loading` — not a meaningful state for this layout primitive.

## Combination and precedence rules

- Responsive state must not remove keyboard focus or accessible names.
- High-contrast and density modes can combine with every viewport state.
- Drawer-open has priority over rail/expanded visual treatments only below the drawer breakpoint.

## Test coverage contract

- Covered by `packages/atlas-ui/stories/DashboardResponsive.stories.tsx`.
- Covered by `scripts/dashboard_responsive_lint.py`.
- Covered by component/state matrix static gates.

## Accessibility notes

- visual reflow does not change DOM order.
- supports zoom and narrow containers.
- no content is hidden by breakpoint alone.
