# RunCard state matrix

**Matrix id:** `atlas.stateMatrix.RunCard.v11`  
**Version:** `11.0.0-state-matrix`  
**Source:** `packages/atlas-ui/src/components/RunCard/RunCard.tsx`  
**Canonical JSON:** `component-library/state-matrix/component-state-matrix.json#/components/RunCard`

## Anatomy

- button root
- run id
- duration/artifact meta
- status badge
- optional summary

## Supported states

| State | Kind | Trigger | Visual contract | DOM / ARIA contract | Tokens | Keyboard | Priority |
|---|---|---|---|---|---|---|---|
| `default` | interaction | RunCard is enabled and idle. | Baseline surface, text, border and shadow from component tokens. | Native semantic element remains available to keyboard and assistive tech. | `component tokens` | Tab reaches control when interactive. | P0 |
| `hover` | interaction | Pointer enters enabled control. | Uses tokenized hover transform/surface/border without relying on color alone. | No ARIA change. | `--atlas-state-hover-transform`, `--atlas-state-hover-surface` | No keyboard equivalent required; focus-visible covers keyboard discovery. | P0 |
| `focus-visible` | interaction | Keyboard, switch control or programmatic focus reaches the element. | 3px focus outline plus outer halo; not obscured by adjacent content. | Native focus target or roving tabindex target. | `--focus-ring`, `--focus-ring-outer`, `--focus-outline-width` | Tab/Shift+Tab order is predictable. | P0 |
| `active` | interaction | Pointer down, Enter or Space activation. | Pressed transform removes lift; no layout shift. | Native activation event fires once. | `--atlas-state-active-transform` | Enter and Space activate native buttons. | P0 |
| `disabled` | interaction | Action is unavailable or blocked by permissions/prerequisites. | Opacity and cursor use state tokens; color is not the only disabled cue. | Use native disabled where possible; otherwise aria-disabled with blocked handlers. | `--atlas-state-disabled-opacity`, `--atlas-state-disabled-cursor` | Disabled native controls are removed from tab order. | P0 |
| `success` | status | status="success". | Success border/status badge; run remains openable. | Status included in aria-label. | `--atlas-run-status-passed-bg`, `--atlas-status-dot-ok` | No additional keyboard behavior. | P0 |
| `failed` | status | status="failed". | Danger border/status badge. | Status included in aria-label. | `--atlas-run-status-failed-bg`, `--atlas-status-dot-fail` | No additional keyboard behavior. | P0 |
| `blocked` | status | status="blocked". | Danger status; copy should name blocker. | Status included in aria-label. | `--atlas-run-status-failed-bg`, `--atlas-status-dot-fail` | No additional keyboard behavior. | P0 |
| `running` | status | status="running". | Warning/running status badge. | Status included in aria-label. | `--atlas-run-status-running-bg`, `--atlas-status-dot-warn` | No additional keyboard behavior. | P0 |
| `pending` | status | status="pending". | Neutral pending status badge. | Status included in aria-label. | `--atlas-run-status-queued-bg`, `--atlas-status-dot-neutral` | No additional keyboard behavior. | P0 |
| `review` | status | status="review". | Info/review status badge. | Status included in aria-label. | `--atlas-badge-info-bg`, `--atlas-badge-info-text` | No additional keyboard behavior. | P0 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | Borders and focus rings remain visible; color-only meaning must have text or shape fallback. | No semantic change; forced-colors uses system colors where appropriate. | `--focus-ring`, `--focus-ring-outer` | Keyboard order and activation stay identical. | P0 |
| `reduced-motion` | mode | User sets prefers-reduced-motion: reduce. | Transitions, spinner and shimmer motion collapse to reduced duration or static treatment. | No semantic change; loading labels remain exposed. | `--motion-reduced-duration` | Keyboard order and activation stay identical. | P0 |
| `density` | mode | Container or product shell applies a density mode. | Spacing and control height use density tokens while preserving 24px/44px target guidance as applicable. | No semantic change. | `--atlas-control-height-sm`, `--atlas-control-height-md`, `--atlas-control-height-lg`, `--target-min` | Touch and keyboard targets remain operable. | P1 |

## Explicitly rejected states

| State | Rationale | Alternative |
|---|---|---|
| `loading` | RunCard opens a run; loading belongs to the detail region after activation. | Use composition or request a new component state through the DS RFC process. |
| `multi-select` | RunCard does not yet support bulk selection. | Use a future selectable DataTable pattern. |

## Combination and precedence rules

| Rule |
|---|
| disabled overrides all status interactions |
| status states are mutually exclusive |
| focus-visible must be visible over warning/danger border |

## Test coverage contract

| Layer | Evidence |
|---|---|
| static | component_lint + state_matrix_lint |
| story | Foundations.stories.tsx + StateMatrix.stories.tsx |
| runtime | accessible-name status test backlog |
| manual | Keyboard activation and status announcement review |

## Accessibility notes

- aria-label must include run id, status, duration and artifacts.
- Status badge text is required.

## Mode coverage

- `high-contrast`
- `reduced-motion`
- `density`
