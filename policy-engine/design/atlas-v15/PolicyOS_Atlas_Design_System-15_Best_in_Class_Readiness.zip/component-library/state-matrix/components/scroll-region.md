# ScrollRegion state matrix

**Matrix id:** `atlas.stateMatrix.ScrollRegion.v13`  
**Version:** `13.0.0-dashboard-responsive`  
**Source:** `packages/atlas-ui/src/components/Responsive/ScrollRegion.tsx`  
**Canonical JSON:** `component-library/state-matrix/component-state-matrix.json#/components/ScrollRegion`

## Anatomy

- scroll wrapper
- axis data attribute
- content slot

## Supported states

| State | Kind | Trigger | Visual contract | DOM / ARIA contract | Tokens | Keyboard | Priority |
|---|---|---|---|---|---|---|---|
| `overflow-ready` | layout | `overflow-ready` responsive condition or prop is active. | Uses responsive tokens, grid rules and media/container query behavior without viewport scaling. | Landmarks, DOM order and accessible names remain stable across breakpoints. | `--atlas-responsive-grid-gap`, `--atlas-shell-main-padding`, `--focus-ring` | Keyboard order follows DOM order; focus remains visible and is not clipped. | P0 |
| `horizontal` | layout | `horizontal` responsive condition or prop is active. | Uses responsive tokens, grid rules and media/container query behavior without viewport scaling. | Landmarks, DOM order and accessible names remain stable across breakpoints. | `--atlas-responsive-grid-gap`, `--atlas-shell-main-padding`, `--focus-ring` | Keyboard order follows DOM order; focus remains visible and is not clipped. | P0 |
| `vertical` | layout | `vertical` responsive condition or prop is active. | Uses responsive tokens, grid rules and media/container query behavior without viewport scaling. | Landmarks, DOM order and accessible names remain stable across breakpoints. | `--atlas-responsive-grid-gap`, `--atlas-shell-main-padding`, `--focus-ring` | Keyboard order follows DOM order; focus remains visible and is not clipped. | P0 |
| `both-axes` | layout | `both-axes` responsive condition or prop is active. | Uses responsive tokens, grid rules and media/container query behavior without viewport scaling. | Landmarks, DOM order and accessible names remain stable across breakpoints. | `--atlas-responsive-grid-gap`, `--atlas-shell-main-padding`, `--focus-ring` | Keyboard order follows DOM order; focus remains visible and is not clipped. | P0 |
| `keyboard-focus` | interaction | `keyboard-focus` responsive condition or prop is active. | Uses responsive tokens, grid rules and media/container query behavior without viewport scaling. | Landmarks, DOM order and accessible names remain stable across breakpoints. | `--atlas-responsive-grid-gap`, `--atlas-shell-main-padding`, `--focus-ring` | Keyboard order follows DOM order; focus remains visible and is not clipped. | P0 |
| `high-contrast` | mode | `high-contrast` responsive condition or prop is active. | Uses responsive tokens, grid rules and media/container query behavior without viewport scaling. | Landmarks, DOM order and accessible names remain stable across breakpoints. | `--atlas-responsive-grid-gap`, `--atlas-shell-main-padding`, `--focus-ring` | Keyboard order follows DOM order; focus remains visible and is not clipped. | P0 |
| `density` | mode | `density` responsive condition or prop is active. | Uses responsive tokens, grid rules and media/container query behavior without viewport scaling. | Landmarks, DOM order and accessible names remain stable across breakpoints. | `--atlas-responsive-grid-gap`, `--atlas-shell-main-padding`, `--focus-ring` | Keyboard order follows DOM order; focus remains visible and is not clipped. | P0 |

## Explicitly rejected states

| State | Rationale | Alternative |
|---|---|---|
| `hidden-overflow` | Hidden overflow makes evidence inaccessible on narrow viewports. | Use visible scroll affordance and labelled region. |

## Combination and precedence rules

| Rule |
|---|
| Focus-visible and keyboard access must survive every breakpoint. |
| Density cannot reduce required target size below the accessibility floor. |
| Print mode removes navigation chrome but preserves evidence content. |

## Test coverage contract

| Layer | Evidence |
|---|---|
| static | responsive_lint + component_lint + state_matrix_lint |
| story | ResponsiveDashboard.stories.tsx + StateMatrix.stories.tsx |
| runtime | Playwright viewport matrix backlog |
| manual | Phone/tablet/laptop/desktop/print review |

## Accessibility notes

- optional region role.
- aria-label for named scroll areas.
- keyboard focusable when needed.
- focus ring must not be clipped.

## Mode coverage

- `high-contrast`
- `reduced-motion`
- `density`
- `print`
