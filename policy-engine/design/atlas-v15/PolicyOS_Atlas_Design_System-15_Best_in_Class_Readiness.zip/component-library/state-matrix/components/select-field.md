# SelectField state matrix

**Matrix id:** `atlas.stateMatrix.SelectField.v11`  
**Version:** `11.0.0-state-matrix`  
**Source:** `packages/atlas-ui/src/components/Field/SelectField.tsx`  
**Canonical JSON:** `component-library/state-matrix/component-state-matrix.json#/components/SelectField`

## Anatomy

- field wrapper
- label
- description
- native select
- options
- error message

## Supported states

| State | Kind | Trigger | Visual contract | DOM / ARIA contract | Tokens | Keyboard | Priority |
|---|---|---|---|---|---|---|---|
| `placeholder` | input | placeholder prop renders disabled empty option. | Placeholder option appears until selected value exists. | Native select/option semantics. | `--atlas-field-placeholder` | No additional keyboard behavior. | P0 |
| `selected` | input | value/defaultValue or user selection exists. | Text uses field token; no placeholder styling. | Native select value is available. | `--atlas-field-text` | No additional keyboard behavior. | P0 |
| `open-native` | interaction | User opens browser/OS select popup. | Popup is rendered by platform/browser. | Native combobox/select semantics. | — | Alt+ArrowDown/Space behavior follows browser. | P1 |
| `focus-visible` | interaction | Keyboard focus reaches select. | Focus ring plus focus border. | Native select focus. | `--focus-ring`, `--atlas-field-focus-border` | Tab reaches select. | P0 |
| `required` | validation | required=true. | Asterisk in visible label. | required and aria-required set. | `--atlas-field-label` | No additional keyboard behavior. | P0 |
| `invalid` | validation | error prop is provided. | Invalid border/surface and visible error. | aria-invalid=true and error id in aria-describedby. | `--atlas-field-invalid-border`, `--atlas-field-error` | No additional keyboard behavior. | P0 |
| `disabled` | interaction | disabled=true. | Disabled opacity/cursor. | Native disabled removes from tab order. | `--atlas-state-disabled-opacity` | No additional keyboard behavior. | P0 |
| `option-disabled` | input | option.disabled=true. | Disabled option displayed by browser. | Native option disabled attribute. | — | No additional keyboard behavior. | P1 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | Borders and focus rings remain visible; color-only meaning must have text or shape fallback. | No semantic change; forced-colors uses system colors where appropriate. | `--focus-ring`, `--focus-ring-outer` | Keyboard order and activation stay identical. | P0 |
| `reduced-motion` | mode | User sets prefers-reduced-motion: reduce. | Transitions, spinner and shimmer motion collapse to reduced duration or static treatment. | No semantic change; loading labels remain exposed. | `--motion-reduced-duration` | Keyboard order and activation stay identical. | P0 |
| `density` | mode | Container or product shell applies a density mode. | Spacing and control height use density tokens while preserving 24px/44px target guidance as applicable. | No semantic change. | `--atlas-control-height-sm`, `--atlas-control-height-md`, `--atlas-control-height-lg`, `--target-min` | Touch and keyboard targets remain operable. | P1 |

## Explicitly rejected states

| State | Rationale | Alternative |
|---|---|---|
| `autocomplete` | SelectField is native select, not autocomplete. | Use future Combobox for filtering. |
| `multi-select` | Multi-select is intentionally excluded from this primitive. | Use composition or request a new component state through the DS RFC process. |

## Combination and precedence rules

| Rule |
|---|
| invalid can combine with placeholder and required |
| open-native behavior is browser-owned |
| disabled overrides open/focus/invalid |

## Test coverage contract

| Layer | Evidence |
|---|---|
| static | component_lint + state_matrix_lint |
| story | Forms.stories.tsx + StateMatrix.stories.tsx |
| runtime | component-contract.test.tsx covers native options |
| manual | Browser/AT select smoke test |

## Accessibility notes

- Use short option labels.
- Avoid placeholder as the only instruction.

## Mode coverage

- `high-contrast`
- `reduced-motion`
- `density`
