# Skeleton state matrix

**Matrix id:** `atlas.stateMatrix.Skeleton.v11`  
**Version:** `11.0.0-state-matrix`  
**Source:** `packages/atlas-ui/src/components/Skeleton/Skeleton.tsx`  
**Canonical JSON:** `component-library/state-matrix/component-state-matrix.json#/components/Skeleton`

## Anatomy

- status span
- animated shimmer pseudo-element

## Supported states

| State | Kind | Trigger | Visual contract | DOM / ARIA contract | Tokens | Keyboard | Priority |
|---|---|---|---|---|---|---|---|
| `loading` | async | Content is not ready. | Skeleton block shows tokenized base/sheen. | role=status with polite loading label. | `--atlas-skeleton-base`, `--atlas-skeleton-sheen` | No additional keyboard behavior. | P0 |
| `reduced-motion` | mode | prefers-reduced-motion: reduce. | Shimmer animation duration collapses; static block remains. | Loading label remains available. | `--motion-reduced-duration` | No additional keyboard behavior. | P0 |
| `compact-density` | mode | Density mode reduces layout spacing. | Block dimensions are consumer-controlled through CSS while radius/token stays consistent. | No semantic change. | `--atlas-skeleton-radius` | No additional keyboard behavior. | P1 |
| `composed-region-busy` | a11y | Skeleton appears inside aria-busy region. | Skeleton should not replace labels needed for orientation. | Parent region may set aria-busy=true. | — | Do not move focus during refresh. | P1 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | Borders and focus rings remain visible; color-only meaning must have text or shape fallback. | No semantic change; forced-colors uses system colors where appropriate. | `--focus-ring`, `--focus-ring-outer` | Keyboard order and activation stay identical. | P0 |

## Explicitly rejected states

| State | Rationale | Alternative |
|---|---|---|
| `interactive` | Skeleton is never interactive. | Use composition or request a new component state through the DS RFC process. |
| `error` | Use EmptyState/Toast/inline error for failed loads. | Use composition or request a new component state through the DS RFC process. |

## Combination and precedence rules

| Rule |
|---|
| loading can combine with reduced-motion and density |
| Skeleton itself must not receive focus |
| Parent busy state must not hide controls needed to cancel |

## Test coverage contract

| Layer | Evidence |
|---|---|
| static | state_matrix_lint |
| story | FeedbackData.stories.tsx + StateMatrix.stories.tsx |
| runtime | role=status test backlog |
| manual | Reduced-motion check |

## Accessibility notes

- Use label that describes loading content.
- Prefer preserving layout to avoid reflow.

## Mode coverage

- `high-contrast`
- `reduced-motion`
- `density`
