# Switch state matrix

**Matrix id:** `atlas.stateMatrix.Switch.v11`  
**Version:** `11.0.0-state-matrix`  
**Source:** `packages/atlas-ui/src/components/Field/Switch.tsx`  
**Canonical JSON:** `component-library/state-matrix/component-state-matrix.json#/components/Switch`

## Anatomy

- wrapper
- native checkbox input with role switch
- label
- description

## Supported states

| State | Kind | Trigger | Visual contract | DOM / ARIA contract | Tokens | Keyboard | Priority |
|---|---|---|---|---|---|---|---|
| `off` | selection | checked/defaultChecked false. | Thumb on start side; neutral track. | role=switch with unchecked state. | `--atlas-choice-box-surface` | Space toggles. | P0 |
| `on` | selection | checked/defaultChecked true. | Thumb moves to end; accent track. | role=switch with checked state. | `--accent`, `--teal-soft` | Space toggles. | P0 |
| `hover` | interaction | Pointer enters enabled switch. | Border uses field hover token. | No ARIA change. | `--atlas-field-hover-border` | No additional keyboard behavior. | P0 |
| `focus-visible` | interaction | Keyboard focus reaches switch. | Focus ring around switch. | Native focus target. | `--focus-ring` | Tab reaches switch. | P0 |
| `disabled` | interaction | disabled=true. | Disabled opacity/cursor. | Native disabled removes from tab order. | `--atlas-state-disabled-opacity` | No additional keyboard behavior. | P0 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | Borders and focus rings remain visible; color-only meaning must have text or shape fallback. | No semantic change; forced-colors uses system colors where appropriate. | `--focus-ring`, `--focus-ring-outer` | Keyboard order and activation stay identical. | P0 |
| `reduced-motion` | mode | User sets prefers-reduced-motion: reduce. | Transitions, spinner and shimmer motion collapse to reduced duration or static treatment. | No semantic change; loading labels remain exposed. | `--motion-reduced-duration` | Keyboard order and activation stay identical. | P0 |
| `density` | mode | Container or product shell applies a density mode. | Spacing and control height use density tokens while preserving 24px/44px target guidance as applicable. | No semantic change. | `--atlas-control-height-sm`, `--atlas-control-height-md`, `--atlas-control-height-lg`, `--target-min` | Touch and keyboard targets remain operable. | P1 |

## Explicitly rejected states

| State | Rationale | Alternative |
|---|---|---|
| `indeterminate` | Switch is strictly binary. | Use composition or request a new component state through the DS RFC process. |
| `error` | Switch errors should be represented at form/setting group level. | Use composition or request a new component state through the DS RFC process. |

## Combination and precedence rules

| Rule |
|---|
| on/off are mutually exclusive |
| disabled overrides hover/focus |
| high contrast must preserve thumb/track boundary |

## Test coverage contract

| Layer | Evidence |
|---|---|
| static | state_matrix_lint |
| story | Forms.stories.tsx + StateMatrix.stories.tsx |
| runtime | role switch test backlog |
| manual | Screen-reader on/off announcement |

## Accessibility notes

- Use for immediate settings, not form agreement statements.
- Label must describe the on state clearly.

## Mode coverage

- `high-contrast`
- `reduced-motion`
- `density`
