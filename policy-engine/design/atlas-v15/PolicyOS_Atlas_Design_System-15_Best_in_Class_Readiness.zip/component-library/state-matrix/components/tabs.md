# Tabs state matrix

**Matrix id:** `atlas.stateMatrix.Tabs.v11`  
**Version:** `11.0.0-state-matrix`  
**Source:** `packages/atlas-ui/src/components/Tabs/Tabs.tsx`  
**Canonical JSON:** `component-library/state-matrix/component-state-matrix.json#/components/Tabs`

## Anatomy

- tablist
- tab buttons
- tabpanel sections

## Supported states

| State | Kind | Trigger | Visual contract | DOM / ARIA contract | Tokens | Keyboard | Priority |
|---|---|---|---|---|---|---|---|
| `selected` | selection | Item id equals active value. | Selected text and indicator tokens. | aria-selected=true; tabIndex=0; controls selected panel. | `--atlas-tabs-selected-text`, `--atlas-tabs-indicator` | Arrow keys, Home and End move selection/focus. | P0 |
| `default` | selection | Tab is enabled but not selected. | Muted text; no indicator. | aria-selected=false; tabIndex=-1. | `--atlas-tabs-text` | No additional keyboard behavior. | P0 |
| `hover` | interaction | Pointer enters enabled tab. | Hover surface and ink text. | No ARIA change. | `--atlas-state-hover-surface` | No additional keyboard behavior. | P0 |
| `focus-visible` | interaction | Keyboard focus reaches selected tab. | Focus ring remains visible around tab. | Roving tabindex keeps one tab in tab order. | `--focus-ring` | Tab enters tablist; arrows navigate inside. | P0 |
| `disabled-tab` | interaction | item.disabled=true. | Disabled opacity/cursor. | Native disabled button; skipped by arrow navigation. | `--atlas-state-disabled-opacity` | No additional keyboard behavior. | P0 |
| `keyboard-navigation` | interaction | ArrowLeft/ArrowRight/Home/End. | Selected/focus moves without scroll jumps. | role=tablist/tab/tabpanel relationships remain valid. | — | ArrowLeft/ArrowRight wrap; Home/End jump. | P0 |
| `overflow-review` | layout | Tab labels exceed available width. | Tabs can wrap/scroll per consuming layout; focus ring must not clip. | No semantic change. | `--space-2` | No additional keyboard behavior. | P1 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | Borders and focus rings remain visible; color-only meaning must have text or shape fallback. | No semantic change; forced-colors uses system colors where appropriate. | `--focus-ring`, `--focus-ring-outer` | Keyboard order and activation stay identical. | P0 |
| `reduced-motion` | mode | User sets prefers-reduced-motion: reduce. | Transitions, spinner and shimmer motion collapse to reduced duration or static treatment. | No semantic change; loading labels remain exposed. | `--motion-reduced-duration` | Keyboard order and activation stay identical. | P0 |
| `density` | mode | Container or product shell applies a density mode. | Spacing and control height use density tokens while preserving 24px/44px target guidance as applicable. | No semantic change. | `--atlas-control-height-sm`, `--atlas-control-height-md`, `--atlas-control-height-lg`, `--target-min` | Touch and keyboard targets remain operable. | P1 |

## Explicitly rejected states

| State | Rationale | Alternative |
|---|---|---|
| `multi-select` | A tablist has one selected tab in this primitive. | Use composition or request a new component state through the DS RFC process. |
| `loading` | Loading belongs to selected tabpanel content. | Use composition or request a new component state through the DS RFC process. |

## Combination and precedence rules

| Rule |
|---|
| selected tab is the only tab with tabIndex=0 |
| disabled tabs are skipped by arrow navigation |
| focus-visible can combine with selected only in the current implementation |

## Test coverage contract

| Layer | Evidence |
|---|---|
| static | component_lint + state_matrix_lint |
| story | NavigationOverlay.stories.tsx + StateMatrix.stories.tsx |
| runtime | component-contract.test.tsx covers arrow navigation |
| manual | APG tab keyboard checklist |

## Accessibility notes

- Follows APG tab roles and roving focus pattern.
- Do not use Tabs as page navigation when links are needed.

## Mode coverage

- `high-contrast`
- `reduced-motion`
- `density`
