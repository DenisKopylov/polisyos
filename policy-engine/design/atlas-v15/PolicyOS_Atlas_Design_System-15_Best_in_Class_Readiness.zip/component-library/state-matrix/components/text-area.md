# TextArea state matrix

**Matrix id:** `atlas.stateMatrix.TextArea.v11`  
**Version:** `11.0.0-state-matrix`  
**Source:** `packages/atlas-ui/src/components/Field/TextArea.tsx`  
**Canonical JSON:** `component-library/state-matrix/component-state-matrix.json#/components/TextArea`

## Anatomy

- field wrapper
- label
- description
- textarea
- error message

## Supported states

| State | Kind | Trigger | Visual contract | DOM / ARIA contract | Tokens | Keyboard | Priority |
|---|---|---|---|---|---|---|---|
| `empty` | input | No value or defaultValue is supplied. | Placeholder/helper text visible; no invalid border. | Label remains associated with control. | `--atlas-field-surface`, `--atlas-field-placeholder` | No additional keyboard behavior. | P0 |
| `filled` | input | value/defaultValue is supplied or user enters data. | Text uses field text token. | Value is available in native input. | `--atlas-field-text` | No additional keyboard behavior. | P0 |
| `hover` | interaction | Pointer enters enabled editable control. | Border changes to hover token. | No ARIA change. | `--atlas-field-hover-border` | No keyboard behavior. | P0 |
| `focus-visible` | interaction | Keyboard/switch focus reaches control. | Focus ring plus focus border. | Native focus target. | `--focus-ring`, `--atlas-field-focus-border` | Tab and Shift+Tab reach control. | P0 |
| `required` | validation | required=true. | Asterisk appears in visible label. | required and aria-required are set. | `--atlas-field-label` | Native required validation applies. | P0 |
| `invalid` | validation | error prop is provided. | Invalid border/surface and visible error text. | aria-invalid=true and error id is included in aria-describedby. | `--atlas-field-invalid-border`, `--atlas-state-invalid-surface`, `--atlas-field-error` | Focus stays on field; error summary can move focus at form level. | P0 |
| `disabled` | interaction | disabled=true. | Disabled opacity/cursor; no hover/focus state. | Native disabled removes from tab order. | `--atlas-state-disabled-opacity` | Cannot be focused or edited. | P0 |
| `readonly` | input | readOnly=true where supported. | Readonly surface; text remains readable. | readOnly attribute on native input/textarea. | `--atlas-state-readonly-surface` | Can receive focus for selection/copy. | P0 |
| `multiline-overflow` | layout | Text exceeds visible rows. | Textarea scrolls/resizes without clipping focus ring. | Native textarea value remains accessible. | `--atlas-field-height` | Arrow keys move within text area. | P1 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | Borders and focus rings remain visible; color-only meaning must have text or shape fallback. | No semantic change; forced-colors uses system colors where appropriate. | `--focus-ring`, `--focus-ring-outer` | Keyboard order and activation stay identical. | P0 |
| `reduced-motion` | mode | User sets prefers-reduced-motion: reduce. | Transitions, spinner and shimmer motion collapse to reduced duration or static treatment. | No semantic change; loading labels remain exposed. | `--motion-reduced-duration` | Keyboard order and activation stay identical. | P0 |
| `density` | mode | Container or product shell applies a density mode. | Spacing and control height use density tokens while preserving 24px/44px target guidance as applicable. | No semantic change. | `--atlas-control-height-sm`, `--atlas-control-height-md`, `--atlas-control-height-lg`, `--target-min` | Touch and keyboard targets remain operable. | P1 |

## Explicitly rejected states

| State | Rationale | Alternative |
|---|---|---|
| `single-line` | TextArea is for multiline content. | Use TextField. |
| `open` | TextArea has no popup behavior. | Use composition or request a new component state through the DS RFC process. |

## Combination and precedence rules

| Rule |
|---|
| invalid can combine with multiline-overflow and focus-visible |
| disabled overrides readonly |
| density must preserve readable rows |

## Test coverage contract

| Layer | Evidence |
|---|---|
| static | state_matrix_lint |
| story | Forms.stories.tsx + StateMatrix.stories.tsx |
| runtime | field wiring test should mirror TextField |
| manual | Long text and high-contrast review |

## Accessibility notes

- Use for rationale, notes and evidence explanation.
- Do not hide required context in placeholder.

## Mode coverage

- `high-contrast`
- `reduced-motion`
- `density`
