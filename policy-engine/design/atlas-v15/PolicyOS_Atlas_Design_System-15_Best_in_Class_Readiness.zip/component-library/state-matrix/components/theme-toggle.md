# ThemeToggle state matrix

## Supported states

See `component-library/state-matrix/component-state-matrix.json` for the canonical machine-readable contract. This component supports default, focus-visible, high-contrast, forced-colors, reduced-motion, reduced-transparency, large-text, density and color-safe combinations where applicable.

## Explicitly rejected states

States that imply destructive action, hidden semantics or color-only meaning are rejected for theming controls.

## Combination and precedence rules

Forced colors overrides custom palettes. High contrast must preserve focus-visible. Reduced motion and reduced transparency must not remove semantics. Density and large text must preserve target-size policy.

## Test coverage contract

Static coverage is enforced by `component_lint`, `state_matrix_lint` and `theming_lint`. Browser coverage backlog includes Storybook, Playwright, axe and manual OS preference checks.
