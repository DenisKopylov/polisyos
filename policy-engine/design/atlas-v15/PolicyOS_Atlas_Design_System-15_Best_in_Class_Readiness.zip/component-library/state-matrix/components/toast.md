# Toast state matrix

**Matrix id:** `atlas.stateMatrix.Toast.v11`  
**Version:** `11.0.0-state-matrix`  
**Source:** `packages/atlas-ui/src/components/Toast/Toast.tsx`  
**Canonical JSON:** `component-library/state-matrix/component-state-matrix.json#/components/Toast`

## Anatomy

- root live region
- title
- message
- optional action

## Supported states

| State | Kind | Trigger | Visual contract | DOM / ARIA contract | Tokens | Keyboard | Priority |
|---|---|---|---|---|---|---|---|
| `info` | feedback | tone="info". | Info accent border. | role=status and aria-live=polite. | `--atlas-toast-info-accent` | No additional keyboard behavior. | P0 |
| `success` | feedback | tone="success". | Success accent border. | role=status and aria-live=polite. | `--atlas-toast-success-accent` | No additional keyboard behavior. | P0 |
| `warning` | feedback | tone="warning". | Warning accent border. | role=status and aria-live=polite. | `--atlas-toast-warning-accent` | No additional keyboard behavior. | P0 |
| `danger` | feedback | tone="danger". | Danger accent border. | role=alert and aria-live=assertive. | `--atlas-toast-danger-accent` | No additional keyboard behavior. | P0 |
| `with-action` | content | action prop provided. | Action sits in header; must be native control. | Action preserves its own accessible name. | `--atlas-button-ghost-bg` | Tab reaches action in normal order. | P0 |
| `reduced-motion` | mode | User prefers reduced motion. | No auto-slide animation in base component. | No semantic change. | `--motion-reduced-duration` | No additional keyboard behavior. | P0 |
| `high-contrast` | mode | User enables high-contrast or forced-colors mode. | Borders and focus rings remain visible; color-only meaning must have text or shape fallback. | No semantic change; forced-colors uses system colors where appropriate. | `--focus-ring`, `--focus-ring-outer` | Keyboard order and activation stay identical. | P0 |
| `density` | mode | Container or product shell applies a density mode. | Spacing and control height use density tokens while preserving 24px/44px target guidance as applicable. | No semantic change. | `--atlas-control-height-sm`, `--atlas-control-height-md`, `--atlas-control-height-lg`, `--target-min` | Touch and keyboard targets remain operable. | P1 |

## Explicitly rejected states

| State | Rationale | Alternative |
|---|---|---|
| `auto-dismiss` | Base Toast does not auto-dismiss to avoid timing accessibility issues. | Use composition or request a new component state through the DS RFC process. |
| `modal` | Toast is non-blocking feedback. | Use Dialog for blocking confirmation. |

## Combination and precedence rules

| Rule |
|---|
| tone states are mutually exclusive |
| danger uses assertive live region; all other tones polite |
| with-action can combine with any tone |

## Test coverage contract

| Layer | Evidence |
|---|---|
| static | component_lint + state_matrix_lint |
| story | FeedbackData.stories.tsx + StateMatrix.stories.tsx |
| runtime | live region role test backlog |
| manual | Screen-reader announcement timing review |

## Accessibility notes

- Do not use Toast for long-form instructions.
- Action labels must be specific.

## Mode coverage

- `high-contrast`
- `reduced-motion`
- `density`
