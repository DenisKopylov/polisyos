# ValidationSummary state matrix

Component id: `atlas.stateMatrix.ValidationSummary.v12`

Docs: `component-library/components/validation-summary.md`

## Supported states

| State | Priority | Trigger | Semantics |
|---|---|---|---|
| `empty` | `P1` | items array is empty. | No alert content is announced. |
| `invalid` | `P0` | One or more validation items are supplied. | role alert exposes validation overview. |
| `linked` | `P0` | Each item points to a field id/href. | Anchor target moves the user to the invalid control or group. |
| `focus-visible` | `P0` | Summary receives programmatic or keyboard focus. | tabIndex -1 supports programmatic focus after failed submit. |
| `high-contrast` | `P1` | High contrast mode active. | role alert remains intact. |
| `density` | `P1` | Density mode active. | List order unchanged. |

## Explicitly rejected states

| State | Rationale | Alternative |
|---|---|---|
| `success` | ValidationSummary is only for recoverable errors. | Use Toast or Panel for success confirmation. |

## Combination and precedence rules

- Invalid state overrides hover and selected borders but must not suppress focus-visible.
- Disabled suppresses hover, active and submit behaviors.
- High-contrast and density are mode overlays, not mutually exclusive component states.

## Test coverage contract

- component_lint manifest/source/docs/story gate
- state_matrix_lint state contract gate
- Storybook-ready examples in DataEntry.stories.tsx
- manual keyboard and screen reader checklist in component-library/forms/validation-and-errors.md

## Accessibility notes

- Prefer native form controls before ARIA widgets.
- Every input has a visible label or legend and error/help ids wired through aria-describedby.
- Validation errors are recoverable and summarized before fields.
- Autocomplete/input purpose should be set by product teams for user personal data.

## Mode coverage

`light`, `dark`, `high-contrast`, `forced-colors`, `density`, `reduced-motion`
