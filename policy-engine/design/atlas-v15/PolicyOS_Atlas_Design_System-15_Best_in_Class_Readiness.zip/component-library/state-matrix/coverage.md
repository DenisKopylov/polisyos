# Atlas state matrix coverage

Generated: `2026-06-09T08:53:34Z`

v14 extends the state matrix to data visualization primitives.

- Components covered: **50**
- Data visualization components added: **8**
- New states focus on chart loading, empty/error, stale evidence, uncertainty intervals, table equivalents, high-contrast and density overlays.

Run:

```bash
npm run states:build
npm run states:lint
```
