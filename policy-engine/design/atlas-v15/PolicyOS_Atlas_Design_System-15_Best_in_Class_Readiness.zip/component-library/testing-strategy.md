# Atlas component testing strategy

The v10 package uses three layers of evidence:

1. **Type/build gate** — `scripts/component_build.py` runs TypeScript and mirrors distributable ESM, declarations, CSS and package metadata into `dist/atlas-ui`.
2. **Static contract gate** — `scripts/component_lint.py` validates every manifest component has source, export, docs, story coverage, token/color discipline and build artifacts.
3. **Interactive/browser gate** — Storybook-ready stories are structured for `@storybook/addon-a11y` and future Playwright/axe checks in a connected product CI environment.

## Required checks before stable maturity

- Props compile in strict TypeScript.
- Component is exported from the public package index.
- Component has a manifest entry and owner.
- Docs include Usage, Style, Code contract, Accessibility, State matrix and Content guidance.
- Storybook story exists and references the component.
- Raw color values are not introduced in source or component CSS.
- Interactive controls use native elements first; ARIA is added only for composite roles or dynamic status.

## Browser checks to add in product CI

- Keyboard traversal snapshots for Tabs, Dialog, form controls and card buttons.
- Axe/Storybook accessibility run for all stories.
- Visual regression across light, dark, high-contrast, reduced-motion and density modes.
- Screen-reader smoke checks for dialog naming, live regions, form errors and governance status updates.
