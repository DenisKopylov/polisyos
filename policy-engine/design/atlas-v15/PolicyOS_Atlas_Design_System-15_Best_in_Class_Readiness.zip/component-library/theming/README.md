# Atlas Theming & Accessibility Modes

Version: `15.0.0-accessibility-modes`

This layer turns Atlas theming into a contract rather than a dark-mode toggle. It covers color scheme, contrast, forced colors, reduced motion, reduced transparency, density, large text, color-safe encodings and print/export behavior.

## Contract

- Source of truth: `theming/theme-manifest.json` and `tokens/source/theme.tokens.json`.
- Runtime attributes: `data-atlas-theme`, `data-atlas-contrast`, `data-atlas-motion`, `data-atlas-transparency`, `data-atlas-density`, `data-atlas-text-scale`, `data-atlas-color-safe`.
- Package components: `ThemeProvider`, `ThemeToggle`, `AccessibilityModePanel`.
- Browser preference modes: `prefers-color-scheme`, `prefers-contrast`, `forced-colors`, `prefers-reduced-motion`, `prefers-reduced-transparency`, `print`.

## Precedence

1. Forced colors and user-agent system palettes.
2. Explicit high-contrast user choice.
3. Explicit light/dark theme.
4. Automatic OS dark mode.
5. Contrast, color-safe, transparency, motion, text-scale and density axes.
6. Print/export.

## Evidence

Run:

```bash
npm run theming:build
npm run theming:lint
npm run verify:full
```
