# Atlas content design system

PolicyOS surfaces are evidence-heavy, decision-heavy and audit-heavy. Content must make system behavior understandable, recoverable and reviewable.

## Voice principles

1. **Precise, not verbose.** Say exactly what happened and what the user can do.
2. **Evidence-first.** Prefer source, timestamp and confidence over vague assurances.
3. **Calm under failure.** Errors should reduce uncertainty, not dramatize it.
4. **Operator-grade.** Avoid marketing copy in workflow-critical UI.
5. **Audit-friendly.** Preserve who/what/when/why and avoid irreversible ambiguity.

## Files

- `voice-and-tone.md`
- `terminology.md`
- `error-taxonomy.md`
- `microcopy-patterns.md`
- `trust-copy.md`

