# Error taxonomy

| Error type | User needs to know | Required UI elements |
|---|---|---|
| Validation | Which field, why, how to fix | Field error, summary link, specific recovery |
| Permission | What is blocked and how to request access | Reason, owner/path, request CTA |
| Authentication | Whether session/account/device is the issue | Safe recovery, no sensitive disclosure |
| Freshness/staleness | Which data is stale and impact | Source, timestamp, severity, refresh path |
| Policy conflict | Which rule conflicts and consequence | Rule, evidence, options, escalation |
| System failure | What failed and retry/escalation path | Plain error, retry, status link/details |
| Partial data | What is missing and whether action can continue | Missing scope, risk, continue/stop guidance |
| Export failure | What was not exported and whether any file is valid | File status, retry, audit note |
| Destructive blocked | Why destructive action cannot proceed | Reason, required permission/condition |

## Required copy fields

- Title.
- Cause.
- Impact.
- Recovery action.
- Evidence/source when relevant.
- Timestamp for system and audit failures.

