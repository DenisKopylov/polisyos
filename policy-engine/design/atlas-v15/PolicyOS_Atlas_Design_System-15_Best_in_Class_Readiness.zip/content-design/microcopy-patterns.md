# Microcopy patterns

## Buttons

- Use verbs: "Approve packet", "Request access", "Refresh evidence".
- Avoid vague CTAs: "Submit", "Continue" when consequence is unclear.
- Destructive actions name the object: "Delete draft packet".

## Confirmations

A confirmation must include:

- object being changed;
- consequence;
- reversibility;
- affected users/systems;
- audit impact;
- primary and secondary actions.

## Empty states

An empty state must include:

- what is empty;
- why it may be empty;
- first recovery action;
- permission explanation when relevant.

## Validation

- Put field-level errors near the field.
- Summarize errors at form top for long forms.
- Use specific examples when format matters.
- Do not blame users for system or permission failures.

