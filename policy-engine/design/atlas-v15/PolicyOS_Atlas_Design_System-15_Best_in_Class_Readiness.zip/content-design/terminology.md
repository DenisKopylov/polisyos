# Atlas terminology

| Preferred term | Avoid | Notes |
|---|---|---|
| Evidence | Data blob, artifact, stuff | Use when source/provenance matters |
| Evidence source | Connector, feed, system | Use source name when possible |
| Decision packet | Report, case file | Canonical review unit |
| Governance check | Compliance thing | Use for system or human gate |
| Blocker | Error, fail | Use when action cannot continue |
| Warning | Caution, maybe issue | Use when user can continue with risk |
| Freshness | Recency | Use for source currency/age |
| Provenance | Origin | Use in audit/data lineage contexts |
| Reviewer | Approver, user | Use for human decision role |
| Audit trail | Log | Use for durable decision history |
| Exception | Waiver | Use for time-bound rule deviation |
| Redaction | Masking | Redaction is durable output removal; masking is display behavior |

