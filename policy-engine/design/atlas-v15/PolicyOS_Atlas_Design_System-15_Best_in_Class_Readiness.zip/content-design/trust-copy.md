# Trust copy

Trust copy explains confidence, provenance and limits without overclaiming.

## Required patterns

| Scenario | Copy must include |
|---|---|
| Model/system recommendation | Source, rationale, confidence/limit and review path |
| Low confidence | Why confidence is low and what improves it |
| Stale evidence | Source, last refreshed time and impact |
| Missing evidence | What is missing and whether decision can continue |
| Conflicting evidence | Which sources disagree and what changed |
| Automated action | Trigger, rule, actor/system and audit trail link |
| Export/audit packet | Source set, timestamp and redaction status |

## Avoid

- Absolute certainty unless mathematically/systemically guaranteed.
- "Trusted" labels without explaining basis.
- Hiding source quality behind color alone.
- Summaries that omit material uncertainty.

