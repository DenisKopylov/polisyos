# Voice and tone

## Default voice

- Direct.
- Specific.
- Evidence-aware.
- Low-drama.
- Respectful of operator expertise.

## Tone by situation

| Situation | Tone | Example pattern |
|---|---|---|
| Success | Confirm outcome and next state | "Packet approved. Audit trail updated." |
| Warning | Explain risk and recovery | "Evidence freshness is below threshold. Review source before approval." |
| Error | State cause and action | "Upload failed because the file is encrypted. Remove encryption or upload a different file." |
| Permission denied | Explain access boundary | "You do not have access to this evidence source. Request reviewer access." |
| Destructive action | Plain consequence | "This removes the draft packet for all reviewers." |
| Uncertainty | Quantify or qualify | "Confidence is limited because two sources are stale." |

## Avoid

- "Oops", "Uh oh" and playful errors.
- "Something went wrong" without recovery.
- "Are you sure?" without consequence.
- "AI says" without evidence or source.
- Unexplained acronyms in user-facing surfaces.

