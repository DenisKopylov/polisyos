# Atlas Dashboard Responsive Model

**Version:** `13.0.0-dashboard-responsive`  
**Scope:** runtime dashboard prototype, `@policyos/atlas-ui` dashboard primitives, responsive token outputs and release gates.

This layer converts the dashboard from a desktop-scaled prototype into a production responsive shell. The contract is mobile-first, density-aware, keyboard-accessible, coarse-pointer safe and appropriate for policy operations surfaces with dense evidence, provenance and governance data.

## Canonical window classes

The source of truth is `dashboard-responsive/responsive-manifest.json`.

| Class | Range | Navigation | Content model |
|---|---:|---|---|
| `compact` | 0–599px | modal drawer + bottom quick nav | single column |
| `medium` | 600–904px | modal drawer | one column, two only when safe |
| `expanded` | 905–1239px | persistent icon rail | one to two columns |
| `large` | 1240–1439px | persistent full rail | two to three columns |
| `extra-large` | 1440px+ | persistent full rail | three columns plus supporting pane when useful |

## Layout patterns

The manifest and CSS expose these reusable patterns:

- `atlas-dashboard-grid` — default responsive grid.
- `atlas-dashboard-two-pane` — primary work area plus support context.
- `atlas-dashboard-three-pane` — large/extra-large operator layout.
- `atlas-dashboard-supporting-pane` — bounded detail rail that stacks on compact/medium.
- `atlas-dashboard-scroll-x` / `ScrollRegion` — named contained scroll for dense tables, timelines and provenance chains.

## Consumer API

```tsx
import '@policyos/atlas-ui/css';
import {
  DashboardShell,
  DashboardSidebar,
  DashboardTopBar,
  ResponsiveGrid,
  ScrollRegion,
  getAtlasDashboardWindowClass,
} from '@policyos/atlas-ui';
```

JSON consumers can import the manifest through `@policyos/atlas-ui/dashboard-responsive` or read the mirror at `dist/dashboard-responsive/responsive-manifest.json`.

## Runtime dashboard contract

- The application root exposes `data-atlas-dashboard-responsive="v13"` and `data-atlas-window-class`.
- Compact and medium drawers are controlled with `aria-controls`, `aria-expanded`, Escape close, backdrop close and route-change close.
- The drawer locks body scroll while open and returns focus to the first navigation control.
- Closed mobile drawer content is hidden/inert; desktop rail content remains keyboard reachable.
- Dense data surfaces must not create page-level horizontal scroll; use `ScrollRegion`, card reflow or explicit table containment.

## Release gates

```bash
npm run dashboard:responsive:build
npm run dashboard:responsive:lint
npm run verify:full
```

Generated evidence:

- `dashboard-responsive/build-evidence.md`
- `dashboard-responsive/audit-results.md`
- `dist/verification/dashboard-responsive-audit.md`
