# Dashboard breakpoint contract

Atlas uses five application-level window classes. They are not raw device names; they describe the usable application viewport and the navigation/content strategy.

## Compact: 0-599px

Use a full-bleed shell, sticky topbar, modal drawer navigation and a single content column. This class is optimized for inspection, triage, approval, short data-entry, and checking run status. Do not place a persistent side pane next to the main task.

Acceptance:

- 320px viewport has no horizontal page scroll.
- Every interactive control keeps at least `--target-min` hit area.
- Tables either scroll inside a bounded data surface or use a card-stack representation.
- Decision prose, evidence cards and validation summaries remain in source order.

## Medium: 600-904px

Use the same drawer navigation as compact. This class supports wider cards, charts and form sections, but side panes still stack unless the content has a proven two-up tablet pattern.

Acceptance:

- The topbar does not cover focused content.
- Form fields wrap without separating label/help/error text from the control.
- Charts scale to the container width.
- Supporting panes stack after the main work area.

## Expanded: 905-1239px

Use a persistent icon rail. Labels may collapse visually to reduce navigation cost, but every button keeps an accessible name and title.

Acceptance:

- Keyboard order starts at skip link, then rail, then main content.
- Three-pane screens collapse to one column or one plus supporting pane.
- The rail remains visually distinct from content in high-contrast and forced-colors modes.

## Large: 1240-1439px

Use a persistent full rail and two-column layouts. Three-pane views are allowed only when each pane keeps a usable measure.

Acceptance:

- Primary task remains visually dominant.
- Data-dense tables use compact density only when row actions remain target-safe.
- Supporting panes do not hide governance status or provenance.

## Extra large: 1440px+

Use a full rail and governed max-width shell. Three-pane and wallboard views are allowed, but prose measure remains capped and charts keep readable legends.

Acceptance:

- `--atlas-dashboard-frame-max` caps scan distance.
- Wallboard views retain semantic landmarks and keyboard navigation.
- Print/export mode remains a separate pattern, not a screenshot of the wide shell.
