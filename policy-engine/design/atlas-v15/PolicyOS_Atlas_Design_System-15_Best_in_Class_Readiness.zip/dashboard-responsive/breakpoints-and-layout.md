# Breakpoints and layout contract

Atlas uses named window classes rather than device names. A small laptop at high zoom and a phone can both hit compact behavior, so responsive rules are based on available CSS pixels and user preferences.

## Breakpoints

| Token | CSS var | Value | Use |
|---|---|---:|---|
| `responsive.breakpoint.xs` | `--atlas-breakpoint-xs` | 320px | WCAG reflow audit floor |
| `responsive.breakpoint.sm` | `--atlas-breakpoint-sm` | 480px | Small handset adjustments |
| `responsive.breakpoint.md` | `--atlas-breakpoint-md` | 768px | Drawer/topbar boundary |
| `responsive.breakpoint.lg` | `--atlas-breakpoint-lg` | 980px | Single-column content boundary |
| `responsive.breakpoint.xl` | `--atlas-breakpoint-xl` | 1280px | Icon rail to full rail boundary |
| `responsive.breakpoint.twoXl` | `--atlas-breakpoint-2xl` | 1680px | Operator shell max width |

CSS custom properties are exported for tooling and docs. Media queries use literal values for browser compatibility.

## Layout primitives

- Shell: `atlas-shell-frame`, `atlas-shell-surface`, `atlas-shell-grid`.
- Navigation: `atlas-sidebar`, `atlas-dashboard-topbar`, `atlas-mobile-bottom-nav`.
- Content: `atlas-dashboard-main`, `atlas-responsive-grid`, `atlas-responsive-split`, `atlas-responsive-scroller`.
- Table containment: `atlas-data-table-wrap` with `data-responsive-mode="scroll|cards"`.

## Reflow policy

Ordinary UI must become one-dimensional by the compact class. Exceptions are allowed only when a two-dimensional layout is essential: causal graphs, DAGs, lineage maps, dense audit tables and heatmaps. Exceptions must use a labeled, keyboard-focusable scroll container.
