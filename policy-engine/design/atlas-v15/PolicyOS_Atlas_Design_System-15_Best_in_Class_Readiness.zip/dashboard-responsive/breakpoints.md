# Breakpoints

Atlas uses named responsive ranges instead of one-off page breakpoints.

| Name | Min width | Primary behavior |
|---|---:|---|
| `xs` | 0px | Single column, drawer navigation, comfortable touch targets. |
| `sm` | 520px | Large phone, still drawer-first. |
| `md` | 760px | Tablet portrait; micro grids may use two columns only when labels remain visible. |
| `lg` | 980px | Persistent navigation returns. |
| `xl` | 1180px | Compact rail and multi-panel dashboard views. |
| `2xl` | 1440px | Full rail and wide desktop layouts. |
| `wall` | 1680px | Shell is capped to preserve scan length on operator-wall displays. |

Breakpoints are mirrored as design tokens for code/design-tool handoff, but CSS media queries use literal values because custom properties are not a safe media-query source across target environments.
