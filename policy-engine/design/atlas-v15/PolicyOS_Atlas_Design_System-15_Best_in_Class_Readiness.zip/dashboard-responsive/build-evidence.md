# Atlas Dashboard Responsive Build Evidence

Generated: `2026-06-09T18:11:15Z`

## Generated artifacts

- `packages/atlas-ui/dashboard-responsive.json`
- `dist/dashboard-responsive/responsive-manifest.json`
- `dist/atlas-ui/dashboard-responsive.json`
- `packages/atlas-ui/src/dashboard-responsive-contracts.ts`

## Summary

- Window classes: **5**
- Layout patterns: **5**
- Responsive tokens: **11**
- Acceptance criteria: **18**
