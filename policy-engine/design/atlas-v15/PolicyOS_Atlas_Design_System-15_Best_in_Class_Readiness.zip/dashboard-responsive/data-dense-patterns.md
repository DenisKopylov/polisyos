# Data-dense responsive patterns

Dense tables, timelines, graphs and lineage maps must not force page-level horizontal scroll. Wrap them in `ResponsiveDataRegion`.

## Rules

- Provide a visible caption or heading before the scroll viewport.
- Keep keyboard access to the scrollable viewport through `tabIndex=0` when horizontal scroll is required.
- Provide a chart/table text summary before visually dense evidence.
- Print/export mode expands overflow so decision packets are not clipped.
