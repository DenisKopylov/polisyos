# Data-dense surfaces

PolicyOS dashboards contain evidence ledgers, audit trails and metric grids that cannot always collapse without losing meaning.

## Rules

1. Prefer `ResponsiveGrid` for cards and summary panels.
2. Prefer semantic tables for row/column evidence.
3. Wrap wide evidence tables in `ScrollRegion` or `DataTable`, both of which preserve keyboard access and horizontal scrolling.
4. At phone widths, prototype legacy grids collapse to one column through the compatibility adapter in `atlas-ui.css`.
5. Do not hide governance, freshness, confidence or error columns solely to fit a viewport.

## Acceptance

- Scrollable regions must be discoverable by keyboard.
- Captions or labels must describe the table/region.
- Focus rings must not be clipped by scroll containers.
