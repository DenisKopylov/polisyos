# Dashboard layout contract

The dashboard shell uses a mobile-first contract while retaining desktop fidelity for operators.

## Breakpoint model

- `xs` / `sm`: drawer navigation and single-column content.
- `md`: drawer navigation; content-sidebar and split grids stack.
- `lg`: rail navigation; labels are visually hidden but available as accessible names.
- `xl` / `xxl`: docked navigation; content uses full dashboard grid.

## Acceptance criteria

- No core dashboard route may require horizontal page scroll.
- Dense tables/charts may scroll within a labelled `ResponsiveDataRegion`.
- Print/export removes shell chrome and expands scroll regions.
- Focus-visible remains visible after topbar/drawer/sticky transitions.
