# Dashboard responsive migration checklist

Use this checklist when migrating a dashboard screen from prototype layout to production responsive layout.

## Required

- Replace inline `gridTemplateColumns` with `.atlas-dashboard-grid`, `.atlas-dashboard-two-pane`, `.atlas-dashboard-three-pane` or `.atlas-dashboard-supporting-pane`.
- Replace fixed supporting-pane widths with bounded grid columns or CSS variables.
- Add `.atlas-dashboard-scroll-x` to dense comparison tables that must preserve columns.
- Verify 320px and 768px manually before marking the screen stable.
- Ensure all chart SVGs scale within their container.
- Keep the primary task first in DOM/source order.
- Avoid using compact density as a substitute for responsive layout.

## Evidence

For each stable dashboard surface, attach:

- screenshot or visual-regression snapshot for compact, medium, expanded and large;
- keyboard path note;
- table strategy note;
- overflow result;
- known exceptions or backlog items.

## Do not ship

- Document-level horizontal scroll.
- Drawer that cannot be closed with Escape.
- Navigation labels hidden without accessible names.
- Fixed panes beside content below 905px.
- Charts that require pinch zoom to understand the main trend.
