# Responsive navigation contract

Atlas dashboard navigation has three modes: docked, rail and drawer.

## Docked

Use on desktop and wide desktop. The sidebar is persistent, labelled and includes status/footer regions.

## Rail

Use on tablet landscape or constrained desktop. Labels can be visually hidden, but each control keeps an accessible name.

## Drawer

Use on phone and tablet portrait. The drawer is controlled by a labelled button with `aria-expanded` and closes after navigation or Escape. Production apps should add focus trap behavior when the drawer contains non-navigation interactive controls.
