# Print and export contract

Decision packets, audit trails and evidence tables must render without dashboard chrome.

## Rules

- Hide sidebar, topbar, glass effects and decorative background.
- Expand scroll regions and remove max block size.
- Preserve headings, captions, table headers and evidence notes.
