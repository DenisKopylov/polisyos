# Dashboard screen coverage

v13 adds a generic runtime reflow layer for every dashboard screen and specific shell/navigation behavior for all 30 routes.

| Surface class | Screens | v13 behavior |
|---|---|---|
| Overview cards | Command Center, Live Run Monitor, Capacity Planner | Auto-fit grids collapse to one column; metric cards keep semantic order. |
| Launch/review flows | Scenario Composer, Decision Workspace, Run Choreography | Main/support columns stack; action controls remain after content. |
| Evidence and governance | Evidence Fabric, Evidence Synthesis, Quality Budget, Fairness Audit, Embargo Manager | Tables/lists use contained scroll; side panels stack below primary evidence. |
| Causal/graph views | Causal Atlas, Identifiability, Sensitivity Rotor, Lineage Gravity, Argument Map | Visual canvases keep semantic minimums and use contained scrollers where needed. |
| Ops/audit views | Failure Triage, Ops Audit Trail, Dispute Ledger, Provenance Certificate | Filters and summary panels stack; dense rows remain scroll-contained. |
| Narrative/analysis | Profile Drift, Reasoning Chain, Uncertainty Decomposer, Counterfactual Explorer, Stakeholder Lens, Cohort Traveler, Stress-Test Theatre, Freshness Braid, Connector Cards, Schema Storyboard | Multi-panel layouts stack; supporting cards become full width. |

The static responsive lint guards shell artifacts; browser-level Playwright snapshots should be added next for all routes at 320, 480, 768, 980, 1280 and 1440 widths.
