# Responsive testing contract

## Static gate

`python3 scripts/dashboard_responsive_lint.py` verifies that the ZIP contains the responsive shell CSS, responsive source tokens, mobile topbar, drawer, bottom nav, Sidebar inerting and DataTable responsive APIs.

## Manual/browser gate to add in product CI

- 320 x 640: no page-level horizontal scroll except labeled data/graph containers.
- 480 x 800: drawer opens/closes on button, Escape and overlay.
- 768 x 1024: topbar/drawer boundary behavior.
- 980 x 768: content columns begin to reappear without clipping.
- 1280 x 800: icon rail/full rail boundary.
- 1440+ x 900: full operator dashboard parity.
- 400% browser zoom from a 1280px viewport: content reflows to 320 CSS px.
- Forced colors: shell, nav and overlay remain distinguishable.
- Reduced motion: drawer and hover transitions collapse to reduced duration.

## Evidence artifacts

- `dashboard-responsive/dashboard-responsive-audit.md`
- `dist/verification/verification-report.md`
- `tokens/generated/token-schema-lint.md`
- `tokens/generated/token-static-lint.md`
