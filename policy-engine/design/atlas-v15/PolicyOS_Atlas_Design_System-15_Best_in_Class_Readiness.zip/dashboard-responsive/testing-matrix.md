# Dashboard responsive testing matrix

## Viewports

Required viewport set for visual and interaction tests:

| Class | Widths | Notes |
|---|---:|---|
| Compact | 320, 360, 390, 412 | Minimum phone, common iPhone/Android widths. |
| Medium | 600, 768, 820, 904 | Tablet portrait and split-screen. |
| Expanded | 1024, 1180, 1239 | Tablet landscape / small desktop. |
| Large | 1280, 1366, 1439 | Common laptop widths. |
| Extra large | 1440, 1680, 1920 | Desktop/operator-wall layouts. |

## Interaction checks

- Skip link lands on `#main-content`.
- Compact drawer opens, focuses first nav button, closes on Escape and route change.
- Collapsed rail buttons expose accessible names.
- No viewport creates document-level horizontal scroll.
- Focus ring is not clipped by shell overflow.
- Tables either scroll within their own surface or stack as cards.
- Reduced-motion and forced-colors modes preserve navigation affordances.

## Evidence files

- `dashboard-responsive/audit-results.md`
- `dist/verification/dashboard-responsive-audit.md`
- future Playwright screenshots under `dist/verification/responsive-snapshots/`
