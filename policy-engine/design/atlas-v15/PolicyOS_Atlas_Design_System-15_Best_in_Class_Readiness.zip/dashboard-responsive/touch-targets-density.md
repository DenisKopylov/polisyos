# Touch targets and density

Comfortable dashboard mode uses a 44px target. Compact and condensed density are allowed for operator desktops but must be reviewed before touch-first deployment.

## Rules

- Primary navigation and topbar controls use `--target-min`.
- The WCAG 2.2 floor is `--target-min-wcag` at 24px.
- Condensed density is not the default for mobile or tablet portrait.
