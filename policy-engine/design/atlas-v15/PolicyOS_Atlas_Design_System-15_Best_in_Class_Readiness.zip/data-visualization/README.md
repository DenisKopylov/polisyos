
# Atlas Data Visualization System

Atlas data visualization turns PolicyOS charts into decision evidence. A chart is considered production-ready only when it has a readable chart type, a text summary, a data-table equivalent, non-color encodings, uncertainty/provenance treatment where relevant and export-safe behavior.

## Production contract

1. Start from the chart grammar in `chart-grammar.md` and choose the simplest chart that answers the decision question.
2. Wrap charts in `ChartFrame` so title, summary, caption/source and data table are never optional after design review.
3. Use package components for common primitives: `LineChart`, `BarChart`, `Sparkline`, `UncertaintyBand`, `Heatmap`, `CausalGraph` and `ProvenanceMap`.
4. Use `ChartLegend`, `ChartTooltip` and `ChartDataTable` for supporting evidence. Tooltips may reveal detail, but the chart must still be understandable without hover.
5. Use tokenized series colors plus shape, dash, label or table fallback. Do not rely on color alone.

## Required artifacts

- `data-viz-manifest.json` — machine-readable chart grammar and quality bar.
- `chart-grammar.md` — chart-type selection and mark/encoding rules.
- `accessibility-contract.md` — text alternatives, data tables, SVG roles and keyboard guidance.
- `color-encoding.md` — palette, non-color channels and high-contrast fallbacks.
- `uncertainty-provenance.md` — confidence intervals, assumptions, stale evidence and lineage treatment.
- `dashboard-patterns.md` — responsive, data-dense dashboard use.
- `testing-contract.md` — static, Storybook, Playwright/axe and manual screen-reader evidence.

## Package exports

```tsx
import '@policyos/atlas-ui/css';
import { ChartFrame, LineChart, ChartDataTable } from '@policyos/atlas-ui';
```

The JSON grammar is mirrored to `@policyos/atlas-ui/data-viz` and `dist/data-visualization/data-viz-manifest.json`.
