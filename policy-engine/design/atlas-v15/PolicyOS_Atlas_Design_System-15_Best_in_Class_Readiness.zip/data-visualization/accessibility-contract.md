
# Data visualization accessibility contract

## Required text alternatives

Every chart must include:

1. **Short summary**: one or two sentences with the decision-relevant takeaway.
2. **Long alternative**: nearby data table, structured explanation or linked data download for exact values.
3. **Source/caption**: source, time period and transformation notes when relevant.
4. **Non-color encoding**: shape, stroke pattern, label or table fallback for every color-coded meaning.

## SVG contract

- Use `role="img"` on standalone SVG charts.
- Provide `aria-labelledby` linking to SVG `title` and `desc` nodes.
- If a surrounding figure already contains the accessible summary, the SVG description should still name what the visual depicts.
- Interactive SVG groups must expose keyboard focus and a meaningful label.

## Keyboard and assistive technology

- Charts must not require hover to understand the result.
- Tooltip content must be reachable through focus or duplicated in a table/summary.
- Data tables should use captions, column headers and row labels.
- Causal/provenance nodes that are keyboard focusable must use a predictable DOM order matching the visual reading order.

## Color and contrast

- Meaningful graphical objects target WCAG non-text contrast.
- High-contrast and forced-colors modes preserve axes, marks, labels and focus outlines.
- Use of color alone is disallowed for status, threshold, confidence or series identity.
