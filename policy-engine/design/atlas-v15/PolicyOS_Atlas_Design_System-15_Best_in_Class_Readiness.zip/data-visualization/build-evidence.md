# Atlas Data Visualization Build Evidence

Generated: `2026-06-09T17:56:57Z`

## Generated artifacts

- `data-visualization/data-viz-manifest.json`
- `packages/atlas-ui/data-visualization.json`
- `packages/atlas-ui/data-viz.json`
- `packages/atlas-ui/chart-grammar.json`
- `dist/data-visualization/data-viz-manifest.json`
- `dist/data-visualization/data-viz.json`
- `dist/atlas-ui/data-visualization.json`
- `dist/atlas-ui/data-viz-manifest.json`
- `dist/atlas-ui/data-viz.json`
- `packages/atlas-ui/src/data-visualization-contracts.ts`

## Summary

- Chart types: **16**
- Production visualization components: **14**
- Required tokens: **10**
