
# Chart grammar

## Decision-first selection

| Question | Preferred chart | Required supporting evidence |
|---|---|---|
| How does a measure change over ordered time/scenario index? | Line chart | Summary, axis units, data table, source. |
| What is the quick direction of a KPI? | Sparkline | Current value, time window, text trend. |
| Which discrete category is larger/smaller? | Bar chart | Sorted labels, exact values, table. |
| How wide is uncertainty around an estimate? | Uncertainty band | Interval labels, assumptions, bounds table. |
| Which slices in a matrix need attention? | Heatmap | Direct labels, level legend, table of cells. |
| What causal assumptions produce the estimate? | Causal DAG | Assumption text, edge meaning, reviewer notes. |
| Where did this evidence come from? | Provenance map | Source, transform, freshness and failure status. |

## Mark grammar

- **Position and length** carry primary quantitative meaning.
- **Color** is a secondary channel and must be paired with labels, shape, stroke pattern or grouping.
- **Bands** represent intervals; midpoints must not hide bounds.
- **Edges** represent direction or lineage and must be labelled in text when interpretation matters.
- **Annotations** should explain outliers, governance thresholds and policy-relevant inflection points.

## Axis and labeling rules

- Axis labels include unit, population and time period where applicable.
- Do not abbreviate domain terms unless the same surface defines them.
- Start bar-chart quantitative axes at zero unless the docs explicitly justify otherwise.
- Prefer direct labels for small series counts; legends are acceptable when direct labels would clutter.
- Tooltips are progressive disclosure only, never the sole path to essential information.
