# Chart selection guide

Use the simplest representation that answers the question.

| Question | Preferred chart | Avoid |
|---|---|---|
| How did a measure change over time? | Line chart, sparkline for compact context | Pie, stacked area without total context |
| Which category is larger? | Bar chart | Donut or radial chart |
| What is the confidence interval? | Uncertainty band or fan | Single-value metric without interval |
| Where are risks clustered? | Heatmap with direct labels | Color-only map without table |
| Why did a value change? | Waterfall | Unannotated line chart |
| What evidence led to this decision? | Provenance graph or lineage table | Decorative network graph |

Each choice must include a fallback summary and table equivalent.
