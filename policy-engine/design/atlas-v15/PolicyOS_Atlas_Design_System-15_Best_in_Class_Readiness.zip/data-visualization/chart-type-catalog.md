# Atlas chart type catalog

## Line chart

**Status:** `stable`  
**Use for:** Trends over time with comparable intervals.  
**Requires:** axis labels, summary, table equivalent, non-color series encoding.

## Bar chart

**Status:** `stable`  
**Use for:** Compare discrete categories or ranked measures.  
**Requires:** baseline disclosure, sort rule, value labels when dense.

## Stacked bar

**Status:** `beta`  
**Use for:** Part-to-whole comparison when total and segments both matter.  
**Requires:** segment order, legend, table equivalent.

## Distribution plot

**Status:** `beta`  
**Use for:** Show spread, skew and outliers rather than averages only.  
**Requires:** binning method, outlier policy, summary statistics.

## Waterfall

**Status:** `stable`  
**Use for:** Explain positive/negative contribution to an outcome.  
**Requires:** starting total, ending total, sign encoding beyond color.

## Funnel

**Status:** `beta`  
**Use for:** Show drop-off through a staged process.  
**Requires:** stage definitions, denominator consistency, drop-off annotations.

## Sankey / lineage flow

**Status:** `experimental`  
**Use for:** Visualize evidence, money, users or data provenance flows.  
**Requires:** flow table, minimum link thickness, screen-reader summary.

## DAG / causal graph

**Status:** `stable`  
**Use for:** Show assumed causal structure and intervention/outcome relationships.  
**Requires:** node list, edge list, assumption legend, table/list equivalent.

## Uncertainty fan

**Status:** `stable`  
**Use for:** Show forecast intervals and confidence bands.  
**Requires:** interval definition, assumptions, stale-evidence state.

## Heatmap

**Status:** `beta`  
**Use for:** Show matrix intensity while preserving exact values in table form.  
**Requires:** scale legend, non-color labels or patterns, cell table.

## Timeline

**Status:** `stable`  
**Use for:** Show events, releases, evidence freshness and audit history.  
**Requires:** absolute dates, timezone, status legend.

## Gantt / roadmap

**Status:** `experimental`  
**Use for:** Show durations, dependencies and delivery risk.  
**Requires:** dependency table, slippage marker, print mode.

## Scatter plot

**Status:** `beta`  
**Use for:** Show relationship, clusters and outliers between two measures.  
**Requires:** axis definitions, outlier annotations, trend caveat.

## Geospatial / choropleth

**Status:** `experimental`  
**Use for:** Show geographic distribution only when geography is the decision variable.  
**Requires:** projection disclosure, region table, non-color fallback.
