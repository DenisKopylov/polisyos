# Chart types and decision tree

## Approved chart types

| Type | Use when | Avoid when |
|---|---|---|
| Line chart | Showing trends over ordered time or scenario steps. | Categories are unordered. |
| Bar chart | Comparing magnitudes across categories. | Values are continuous distributions. |
| Stacked bar | Showing part-to-whole across a small number of segments. | Precise comparison of inner segments is required. |
| Distribution | Showing spread, skew, outliers or uncertainty of a population. | Only one exact value matters. |
| Heatmap | Showing dense matrix patterns across two categorical axes. | Users need exact values without table support. |
| Timeline | Showing ordered events, policy changes or evidence freshness. | Events are not ordered or causal. |
| Provenance graph | Showing lineage, source dependency or evidence flow. | The relationship is simply hierarchical. |
| Uncertainty band | Showing an estimate with lower/upper bounds across time or scenario. | Bounds are unknown or unsupported. |
| Funnel | Showing stepwise conversion/drop-off through a process. | Steps are not sequential. |
| Data table | Showing exact values, audit evidence or dense detail. | The intended task is scanning for trend or outlier only. |

## Decision tree

1. Need exact values? Start with `DataVizTable`, optionally paired with a chart.
2. Need change over ordered time? Use `LineChart`; add `UncertaintyBand` when bounds matter.
3. Need category comparison? Use `BarChart` with direct labels.
4. Need lineage or dependency? Use `ProvenanceMap`.
5. Need event sequence? Use `DecisionTimeline`.
6. Need compact trend in a card? Use `Sparkline`, but never without a textual trend label.

## PolicyOS-specific patterns

- **Scenario impact:** Line chart with intervention marker and confidence band.
- **Governance pass rate:** Bar chart plus direct labels and table equivalent.
- **Evidence freshness:** Timeline with stale/blocked status chips.
- **Provenance review:** Provenance map with source cards and edge descriptions.
- **Risk distribution:** Distribution or heatmap with table fallback and explicit cohort.
