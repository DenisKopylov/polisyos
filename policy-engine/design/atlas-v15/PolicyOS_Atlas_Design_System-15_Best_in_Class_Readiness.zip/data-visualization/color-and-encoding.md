# Color and encoding

## Rule

Color must never be the only carrier of meaning. Atlas pairs color with at least one redundant channel: label, shape, stroke, pattern, position or annotation.

## Palette roles

- `--atlas-viz-color-1..8`: categorical series.
- `--atlas-viz-success`, `--atlas-viz-warning`, `--atlas-viz-danger`: semantic status.
- `--atlas-viz-observed`, `--atlas-viz-predicted`, `--atlas-viz-counterfactual`: model/evidence roles.
- `--atlas-viz-ci-50-fill`, `--atlas-viz-ci-80-fill`, `--atlas-viz-ci-95-fill`: uncertainty intervals.

## Non-color channels

Use line style for assumptions/projections, shape for node/series identity, pattern for print and forced-colors fallback, and annotation for stale evidence or governance blockers.
