
# Color and encoding

## Palette roles

| Role | Token | Use |
|---|---|---|
| Primary series | `--atlas-viz-series-1` | Main trend or selected scenario. |
| Secondary series | `--atlas-viz-series-2` | Comparator or baseline. |
| Warning series | `--atlas-viz-series-3` | Review, threshold or caution. |
| Alert series | `--atlas-viz-series-4` | Failure, blocker or negative contribution. |
| Neutral series | `--atlas-viz-series-5` | Context, historical or reference line. |
| Success series | `--atlas-viz-series-6` | Approved or positive status when text also says so. |

## Non-color redundancy

- Use dash patterns for baseline/reference/forecast lines.
- Use point shape or direct label for series identity when series count is small.
- Use text labels for status and governance thresholds.
- Use tables for exact values and for screen-reader access.

## Restricted usage

Vibrant chart colors are chart/decorative tokens. They are not normal body-text colors unless contrast is explicitly verified for the exact background and font size.
