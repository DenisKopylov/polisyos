
# Dashboard data-visualization patterns

## Responsive dashboard behavior

- Charts sit inside `ChartFrame` and inherit responsive dashboard spacing.
- At narrow widths, legends wrap before charts shrink below the minimum readable plot area.
- Data tables may move below the chart inside a contained scroll region.
- Dense dashboards should prefer small multiples over overloaded single charts.

## Operator surfaces

- Use `Sparkline` inside metric cards only for quick directional context.
- Use `UncertaintyBand` for forecasts and counterfactual estimates where bounds change the operational decision.
- Use `CausalGraph` for explainability/review screens, not as decorative network art.
- Use `ProvenanceMap` in evidence, audit and decision-packet surfaces.

## Export and print

- Print mode preserves title, summary, legend, source and data table.
- Tooltips are not considered export evidence.
- If a chart depends on interaction, export must include the selected state and the equivalent values.
