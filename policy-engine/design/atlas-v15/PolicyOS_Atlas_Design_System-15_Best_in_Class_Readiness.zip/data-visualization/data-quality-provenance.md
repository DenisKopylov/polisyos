# Data quality and provenance

## Provenance fields

Every analytic visual should track:

- source system;
- extraction/query reference;
- refresh time;
- model version where applicable;
- cohort/filter definition;
- transformations;
- known limitations;
- responsible owner.

## Quality flags

Atlas supports these quality labels: `fresh`, `stale`, `partial`, `estimated`, `blocked`, `manual-review` and `unknown`.

## PolicyOS review rule

If a chart supports a governance decision, the same evidence packet must include the data source, chart spec, summary, table equivalent and reviewer notes.
