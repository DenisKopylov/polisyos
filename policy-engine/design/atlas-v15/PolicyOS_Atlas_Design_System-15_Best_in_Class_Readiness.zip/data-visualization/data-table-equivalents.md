# Data table equivalents

## Requirement

Every complex visualization needs a data table equivalent that exposes the values needed to verify the visual conclusion.

## Minimum table fields

- dimension or category;
- measure and unit;
- series/status;
- source or model version where relevant;
- confidence interval or caveat where relevant;
- freshness timestamp for evidence-backed views.

## Placement

Place the table below the chart for decision contexts. For space-constrained dashboards, provide an expandable table region that remains available to keyboard and screen reader users.
