# Data table equivalent

Every production chart must provide equivalent values as an HTML table, downloadable data or a linked decision packet section.

## Minimum table fields

- Dimension labels.
- Measure values and units.
- Confidence interval or uncertainty range where applicable.
- Evidence source and freshness when used for governance decisions.
- Notes for missing, imputed or redacted values.
