# Chart interaction contract

Interactions must support exploration without hiding critical meaning.

## Allowed interaction patterns

- Legend filter with persistent text state.
- Keyboard-reachable mark inspection for actionable points.
- Brush/zoom only when reset is visible and keyboard accessible.
- Tooltip details that duplicate information available in a table or summary.

## Not allowed

- Hover-only evidence details.
- Color-only selected states.
- Animated transitions that obscure updated values.
- Panning that creates a keyboard trap.
