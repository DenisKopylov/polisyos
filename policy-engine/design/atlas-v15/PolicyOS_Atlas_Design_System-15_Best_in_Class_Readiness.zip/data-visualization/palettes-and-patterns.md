# Palettes and pattern fallbacks

Atlas chart color is exported through tokens, not hard-coded values.

## Palettes

- Categorical: `--atlas-series-teal`, `--atlas-series-blue`, `--atlas-series-gold`, `--atlas-series-ember`, `--atlas-series-purple`, `--atlas-series-cyan`, `--atlas-series-olive`, `--atlas-series-graphite`.
- Sequential: `--atlas-sequential-low`, `--atlas-sequential-mid`, `--atlas-sequential-high`.
- Diverging: `--atlas-diverging-negative`, `--atlas-diverging-neutral`, `--atlas-diverging-positive`.

## Fallbacks

Use labels, markers, dashed strokes, outlines, fills and table equivalents so status remains readable in color-safe, high-contrast and print modes.
