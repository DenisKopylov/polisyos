# PolicyOS visualization patterns

## Governance gate trend

Use `LineChart` or `Sparkline` for runs over time and `GovernanceGate` for discrete status.

## Evidence freshness heatmap

Use `Heatmap` with direct labels and a table note for stale or missing sources.

## Causal assumption surface

Use `ProvenanceGraph` or a causal DAG spec with adjustment-set notes and long description.

## Simulation uncertainty

Use `UncertaintyBand` with explicit low, mid and high estimates, confidence level and sample size.
