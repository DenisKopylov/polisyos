# PolicyOS visualization patterns

## Governance gates

Use status badges and annotations beside visual marks. Do not encode pass/fail by red/green color alone.

## Evidence provenance

Use lineage flows or causal graphs only when the structure changes the decision. Always include a node/edge list equivalent.

## Causal impact

Use observed, predicted and counterfactual roles with explicit uncertainty intervals. Label the intervention point.

## Fairness and audit

Show subgroup distributions, confidence intervals and minimum sample-size warnings. Provide exact values in a table.

## Decision packet export

Use print mode with summary, caveats, source dates and table fallback. Avoid tooltip-only values.
