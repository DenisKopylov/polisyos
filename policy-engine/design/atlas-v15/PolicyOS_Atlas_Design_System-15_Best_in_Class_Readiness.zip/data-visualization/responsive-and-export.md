# Responsive and export behavior

## Responsive chart behavior

Charts reflow by container size. At narrow widths, legends can stack, dense tables can scroll, and multi-series comparisons can switch to small multiples or cards.

## Print/PDF behavior

Print/export mode must preserve title, summary, legend, units, source date, interval definition and table equivalent. Tooltips are not part of export evidence.

## Operator wall behavior

Large dashboard displays can increase density and show more series, but they must not remove uncertainty or data freshness cues.
