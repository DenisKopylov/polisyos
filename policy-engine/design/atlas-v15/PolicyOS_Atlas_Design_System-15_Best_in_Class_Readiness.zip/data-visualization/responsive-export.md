# Responsive, print and export behavior

## Responsive behavior

- `xs` and `sm`: charts collapse into summary + table/card rows; dense axes may simplify ticks.
- `md`: charts may show scroll regions for dense time series.
- `lg` and wider: charts can use side legends and comparison panels.
- Operator wall: show fewer labels, stronger annotations and status summaries.

## Data tables

A chart may scroll horizontally, but the table equivalent must remain navigable and labelled. On narrow screens, table rows may transform to labelled cards.

## Print/export

Exported charts must include title, summary, unit, source, refresh time and table reference. Interactive-only states must be converted to static annotations.
