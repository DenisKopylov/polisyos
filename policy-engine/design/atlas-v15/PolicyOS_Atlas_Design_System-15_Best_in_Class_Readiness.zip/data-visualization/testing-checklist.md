# Data visualization testing checklist

## Static gates

- `npm run dataviz:build`
- `npm run dataviz:lint`
- `npm run states:lint`
- `npm run components:lint`
- `npm run tokens:lint`

## Browser-level gates to add in product CI

- Viewport matrix screenshots: `320`, `480`, `768`, `980`, `1280`, `1680` CSS px.
- Axe checks for chart pages.
- Keyboard pass for legend toggles, disclosures and tooltip alternatives.
- Screen-reader pass for `ChartFrame`, `LineChart`, `UncertaintyBand`, `ProvenanceMap` and table equivalents.
- Visual regression for high contrast, dark mode and reduced motion.

## Review questions

- Can a user understand the main claim without seeing color?
- Can exact values be recovered from a table?
- Is uncertainty present where the data requires it?
- Does the responsive version preserve the same decision context?
