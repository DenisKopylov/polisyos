
# Data visualization testing contract

## Static gates

- `scripts/data_viz_lint.py` validates chart grammar, required accessibility evidence, token exports and package/dist mirrors.
- `scripts/component_lint.py` enforces component docs, stories, source and token-only styling.
- `scripts/state_matrix_lint.py` enforces state coverage and mode coverage.

## Browser-level backlog

For full best-in-class evidence, add:

- Storybook snapshots for each chart type, high-contrast mode and compact density.
- Playwright viewport matrix for responsive chart/table behavior.
- axe checks on chart frames, data tables, legends and focusable graph nodes.
- Manual screen-reader pass for `CausalGraph`, `ProvenanceMap`, `Heatmap` and validation of chart summaries.

## Acceptance criteria

A visualization passes release review when it is understandable from text/table alone, visually legible in light/dark/high-contrast modes and not dependent on hover or color alone.
