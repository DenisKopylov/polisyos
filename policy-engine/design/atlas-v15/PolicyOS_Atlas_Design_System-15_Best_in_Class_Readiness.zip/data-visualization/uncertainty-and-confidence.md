# Uncertainty, confidence and missing data

PolicyOS charts must show uncertainty as a first-class state.

## Patterns

- Confidence interval: use `UncertaintyBand` or an uncertainty fan.
- Missing data: use explicit gaps, labels and a table note.
- Forecast/model values: use dashed stroke or pattern fallback.
- Stale evidence: annotate the chart and expose the freshness timestamp in text.
- Low sample size: label the sample size and avoid over-precise visual encoding.
