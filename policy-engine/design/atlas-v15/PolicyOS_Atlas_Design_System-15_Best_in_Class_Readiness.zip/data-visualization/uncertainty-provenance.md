
# Uncertainty, provenance and causal evidence

## Uncertainty

- Show midpoint and interval bounds when bounds change the decision.
- Label confidence/credible interval semantics in copy; do not assume the user knows whether a band means 50, 80 or 95 percent.
- Use wider/lighter bands for larger intervals and an explicit data table with low/mid/high columns.
- Never remove uncertainty from exported charts or decision packets.

## Provenance

- Every evidence visualization should expose source, transformation, freshness and reviewer state.
- Stale or failed stages must stay visible; hiding them weakens the audit trail.
- Provenance paths should match reading order and include a text list or table alternative.

## Causal diagrams

- Edges represent assumptions, not proof by themselves.
- Causal nodes need labels that are understandable outside the model team.
- Mark unobserved/confounded/stale nodes with shape or text, not just color.
