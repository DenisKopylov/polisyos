# Uncertainty visual language

## Interval hierarchy

- **50% interval**: inner band for operational dashboard scanning.
- **80% interval**: default forecast interval for most PolicyOS dashboards.
- **95% interval**: review interval for tail risk, policy approval and executive packets.

## Assumptions

Assumptions use dashed strokes, explicit labels and a visible assumption annotation. They are never hidden in a tooltip only.

## Stale evidence

Stale evidence uses the `stale-evidence` state and must include the last refreshed date in nearby copy.

## Missing data

Missing data is not zero. Use gaps, annotations and table notes to distinguish missing, suppressed, unavailable and not applicable.
