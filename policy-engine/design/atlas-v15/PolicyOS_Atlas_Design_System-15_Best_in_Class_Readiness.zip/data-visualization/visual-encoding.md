# Visual encoding contract

Encoding priority is position, length, area/angle only when approximate, then color, shape and texture as supporting channels. Atlas never relies on hue alone for policy status, confidence or risk.

## Encoding rules

- Use position and length for precise comparisons.
- Use color for grouping/status only with label, icon, stroke pattern or shape fallback.
- Use texture or dashed strokes for forecasts, stale evidence and modeled values.
- Use direct labels for thresholds and high-impact values.
- Keep legends close to the chart or use direct labels when space permits.
