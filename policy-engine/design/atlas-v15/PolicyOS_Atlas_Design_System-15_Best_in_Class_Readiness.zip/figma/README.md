# Figma and design-to-code parity

Atlas already exports Figma token JSON. This folder defines the parity contract needed to keep Figma components, React components, tokens, variants and documentation aligned.

## Parity requirements

| Layer | Requirement |
|---|---|
| Tokens | Figma variables/styles map to source tokens, not generated one-offs |
| Components | Stable React components have matching Figma components or documented no-design equivalent |
| Variants | Figma variants match public props and state matrix vocabulary |
| Modes | Figma mode collections map to Atlas light/dark/high-contrast/density/motion/color-safe modes |
| Docs | Figma component descriptions link back to Atlas docs and maturity status |
| Drift | Any drift needs owner, reason and review date |

## Files

- `component-parity.md`
- `component-parity-index.md`
- `variant-parity-contract.md`
- `token-sync-runbook.md`
- `figma-code-connect-map.json`
- `design-qa-checklist.md`

