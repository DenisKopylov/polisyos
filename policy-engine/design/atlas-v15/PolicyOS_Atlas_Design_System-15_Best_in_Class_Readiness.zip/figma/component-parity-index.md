# Generated component parity index

Release: `15.0.0-accessibility-modes`
Components: **56**

| React component | Figma target | Status | States | Drift status | Owner |
|---|---|---|---:|---|---|
| Button | Atlas/Button | stable | 12 | needs-figma-audit | Design System / UI Foundations |
| Badge | Atlas/Badge | stable | 8 | needs-figma-audit | Design System / UI Foundations |
| Panel | Atlas/Panel | stable | 8 | needs-figma-audit | Design System / UI Foundations |
| Card | Atlas/Card | stable | 12 | needs-figma-audit | Design System / UI Foundations |
| MetricCard | Atlas/MetricCard | stable | 7 | needs-figma-audit | Design System / Data Display |
| RunCard | Atlas/RunCard | stable | 14 | needs-figma-audit | Design System / PolicyOS Domain |
| TextField | Atlas/TextField | stable | 12 | needs-figma-audit | Design System / Forms |
| TextArea | Atlas/TextArea | stable | 12 | needs-figma-audit | Design System / Forms |
| SelectField | Atlas/SelectField | stable | 11 | needs-figma-audit | Design System / Forms |
| Checkbox | Atlas/Checkbox | stable | 10 | needs-figma-audit | Design System / Forms |
| Switch | Atlas/Switch | stable | 8 | needs-figma-audit | Design System / Forms |
| Tabs | Atlas/Tabs | beta | 10 | needs-figma-audit | Design System / Navigation |
| Dialog | Atlas/Dialog | beta | 10 | needs-figma-audit | Design System / Overlays |
| Toast | Atlas/Toast | stable | 8 | needs-figma-audit | Design System / Feedback |
| EmptyState | Atlas/EmptyState | stable | 9 | needs-figma-audit | Design System / Feedback |
| Skeleton | Atlas/Skeleton | stable | 5 | needs-figma-audit | Design System / Feedback |
| DataTable | Atlas/DataTable | beta | 13 | needs-figma-audit | Design System / Data Display |
| GovernanceGate | Atlas/GovernanceGate | stable | 9 | needs-figma-audit | Design System / PolicyOS Domain |
| Form | Atlas/Form | stable | 6 | needs-figma-audit | Design System / Form |
| FormSection | Atlas/FormSection | stable | 6 | needs-figma-audit | Design System / Form |
| FieldGroup | Atlas/FieldGroup | stable | 9 | needs-figma-audit | Design System / Form |
| ValidationSummary | Atlas/ValidationSummary | stable | 6 | needs-figma-audit | Design System / Form |
| RadioGroup | Atlas/RadioGroup | stable | 8 | needs-figma-audit | Design System / Data Entry |
| CheckboxGroup | Atlas/CheckboxGroup | stable | 8 | needs-figma-audit | Design System / Data Entry |
| SearchField | Atlas/SearchField | stable | 9 | needs-figma-audit | Design System / Data Entry |
| PasswordField | Atlas/PasswordField | stable | 10 | needs-figma-audit | Design System / Data Entry |
| SecretField | Atlas/SecretField | stable | 11 | needs-figma-audit | Design System / Data Entry |
| NumberField | Atlas/NumberField | stable | 9 | needs-figma-audit | Design System / Data Entry |
| RangeField | Atlas/RangeField | stable | 9 | needs-figma-audit | Design System / Data Entry |
| DateField | Atlas/DateField | stable | 9 | needs-figma-audit | Design System / Data Entry |
| DateRangeField | Atlas/DateRangeField | beta | 9 | needs-figma-audit | Design System / Data Entry |
| FileUpload | Atlas/FileUpload | stable | 9 | needs-figma-audit | Design System / Data Entry |
| TokenInput | Atlas/TokenInput | beta | 9 | needs-figma-audit | Design System / Data Entry |
| Combobox | Atlas/Combobox | beta | 8 | needs-figma-audit | Design System / Data Entry |
| CharacterCount | Atlas/CharacterCount | stable | 6 | needs-figma-audit | Design System / Data Entry |
| DashboardShell | Atlas/DashboardShell | beta | 7 | needs-figma-audit | Design System / Dashboard Layout |
| DashboardTopBar | Atlas/DashboardTopBar | beta | 8 | needs-figma-audit | Design System / Responsive Surfaces |
| ResponsiveGrid | Atlas/ResponsiveGrid | stable | 7 | needs-figma-audit | Design System / Layout Primitives |
| ScrollRegion | Atlas/ScrollRegion | stable | 7 | needs-figma-audit | Design System / Responsive Layout |
| ChartFrame | Atlas/ChartFrame | stable | 8 | needs-figma-audit | Design System / Data Visualization |
| ChartLegend | Atlas/ChartLegend | stable | 8 | needs-figma-audit | Design System / Data Visualization |
| ChartTooltip | Atlas/ChartTooltip | beta | 9 | needs-figma-audit | Design System / Data Visualization |
| Sparkline | Atlas/Sparkline | stable | 8 | needs-figma-audit | Design System / Data Visualization |
| BarChart | Atlas/BarChart | stable | 8 | needs-figma-audit | Design System / Data Visualization |
| LineChart | Atlas/LineChart | stable | 8 | needs-figma-audit | Design System / Data Visualization |
| Heatmap | Atlas/Heatmap | beta | 8 | needs-figma-audit | Design System / Data Visualization |
| UncertaintyBand | Atlas/UncertaintyBand | stable | 9 | needs-figma-audit | Design System / Data Visualization |
| ProvenanceGraph | Atlas/ProvenanceGraph | beta | 11 | needs-figma-audit | Design System / Data Visualization |
| ChartDataTable | Atlas/ChartDataTable | stable | 8 | needs-figma-audit | Design System / Data Visualization |
| CausalGraph | Atlas/CausalGraph | beta | 9 | needs-figma-audit | Design System / Data Visualization |
| ProvenanceMap | Atlas/ProvenanceMap | stable | 8 | needs-figma-audit | Design System / Data Visualization |
| ChartAnnotation | Atlas/ChartAnnotation | stable | 7 | needs-figma-audit | Design System / Data Visualization |
| DataVizTable | Atlas/DataVizTable | stable | 7 | needs-figma-audit | Design System / Data Visualization |
| ThemeProvider | Atlas/ThemeProvider | stable | 9 | needs-figma-audit | Design System / Accessibility Theming |
| ThemeToggle | Atlas/ThemeToggle | stable | 9 | needs-figma-audit | Design System / Accessibility Theming |
| AccessibilityModePanel | Atlas/AccessibilityModePanel | stable | 9 | needs-figma-audit | Design System / Accessibility Theming |
