# Component parity matrix

Use this matrix during Figma library audits.

| Field | Description |
|---|---|
| Figma component | Canonical design library component name |
| React component | Exported Atlas component name |
| Status | stable, beta, experimental, deprecated |
| Props/variants | Public props that must be represented as variants/properties |
| State matrix | Link to state matrix doc/source |
| Token dependencies | Key semantic/component tokens |
| Drift status | aligned, design-ahead, code-ahead, missing, intentional-gap |
| Owner | Person/team accountable |
| Review date | Last parity review |

## Required policy

- A stable React component without a Figma counterpart must have an intentional-gap note.
- A stable Figma component without a React counterpart must be marked design-ahead or deprecated.
- Variant names must use Atlas vocabulary, not product-specific labels.
- Accessibility modes must be represented as mode previews or documented examples.
- Deprecated variants must reference replacement variants.

