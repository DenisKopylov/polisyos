# Design QA checklist

Before handoff, designers check:

- [ ] Uses Atlas Figma components where available.
- [ ] Uses variables/tokens, not local one-off styles.
- [ ] Contains light/dark or relevant mode preview for critical screens.
- [ ] Long labels/errors do not clip.
- [ ] Focus, loading, error, empty and disabled states are represented.
- [ ] No color-only meaning.
- [ ] Data visualizations include summary and table/source alternative.
- [ ] Permission/sensitive-data states are represented.
- [ ] RTL/pseudo-locale risk is noted for dense layouts.
- [ ] Any exception is registered.

