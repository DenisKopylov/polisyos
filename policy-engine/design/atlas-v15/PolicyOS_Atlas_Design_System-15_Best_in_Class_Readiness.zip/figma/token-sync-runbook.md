# Token sync runbook

## Inputs

- `tokens/source/*.tokens.json`
- `tokens/modes/*.tokens.json`
- `tokens/generated/atlas.figma.tokens.json`
- `dist/tokens/atlas.figma.tokens.json`

## Sync steps

1. Run token build and lint.
2. Import/update Figma variables from generated Figma token JSON.
3. Verify mode collections: light, dark, high contrast, forced colors, density, motion, transparency, large text, color safe and print.
4. Spot-check component tokens for Button, Field, DataTable, ChartFrame and ThemeProvider examples.
5. Record sync date, commit/archive ID and drift notes.
6. Update `figma/component-parity.md` if variants changed.

## Token drift report fields

- token name;
- source value;
- Figma value;
- mode;
- severity;
- owner;
- disposition;
- review date.

