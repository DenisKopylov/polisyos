# Variant parity contract

## Required mappings

| Atlas concept | Figma representation | React representation |
|---|---|---|
| Component status | Component description/status badge | Manifest `status` |
| Size/density | Variant/property | Prop or inherited density mode |
| Tone/status | Variant/property | Prop using semantic status names |
| Interactive state | Component set/example, not arbitrary styling | State matrix and CSS selectors/data-state |
| Accessibility mode | Mode preview or variable mode | ThemeProvider/mode tokens |
| Disabled/loading/error | Variant/property when user-visible | Prop and state matrix entry |
| Icon placement | Logical start/end property | `icon`, `iconPosition` or slot contract |
| Responsive behavior | Example frame or note | Responsive prop/contract |

## Drift severity

| Severity | Example | Action |
|---|---|---|
| Critical | Figma variant suggests behavior code does not support | Block release/adoption |
| High | Token/mode mismatch affects accessibility | Fix before stable |
| Medium | Naming mismatch or missing example | Fix in next minor update |
| Low | Documentation/description drift | Fix in next docs pass |

