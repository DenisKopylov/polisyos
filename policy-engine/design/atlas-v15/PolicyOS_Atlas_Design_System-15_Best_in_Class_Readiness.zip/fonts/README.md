# Atlas Design System — Self-Hosted Fonts

The design system uses two typefaces from Google Fonts:

| Family | Weights | Usage |
|---|---|---|
| Manrope | 400 500 600 700 800 | All UI text, headings, buttons |
| IBM Plex Mono | 400 500 600 | Eyebrows, labels, timestamps, code |

## Download instructions

Run `./download.sh` from this folder (requires `curl`):

```bash
cd fonts/
chmod +x download.sh
./download.sh
```

Or manually download from Google Fonts:
- https://fonts.google.com/specimen/Manrope → select weights 400–800
- https://fonts.google.com/specimen/IBM+Plex+Mono → select weights 400–600

Unzip and place woff2 files here with these exact names:
```
fonts/
  Manrope-400.woff2
  Manrope-500.woff2
  Manrope-600.woff2
  Manrope-700.woff2
  Manrope-800.woff2
  IBMPlexMono-400.woff2
  IBMPlexMono-500.woff2
  IBMPlexMono-600.woff2
```

## Usage

Once files are in place, reference `fonts/fonts.css` in your HTML instead of the Google Fonts CDN link:

```html
<!-- Replace this: -->
<link href="https://fonts.googleapis.com/css2?family=Manrope..." rel="stylesheet">

<!-- With this: -->
<link rel="stylesheet" href="path/to/fonts/fonts.css">
```

`colors_and_type.css` already uses the correct font-family stacks — no other changes needed.

## Production (runtime-dashboard)

The production app bundles fonts via Vite. Drop the woff2 files into:
```
policy-engine/frontend/runtime-dashboard/src/assets/fonts/
```
And update the `@font-face` in `styles.css` accordingly.
