#!/usr/bin/env bash
# Atlas Design System — Font downloader
# Requires: curl, python3 (for URL extraction)
# Run from the fonts/ directory: ./download.sh

set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "Fetching Google Fonts CSS..."

CSS_URL="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=IBM+Plex+Mono:wght@400;500;600&display=swap"

FONT_CSS=$(curl -sL \
  -H "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36" \
  "$CSS_URL")

echo "$FONT_CSS" > _google_fonts_raw.css
echo "Saved raw CSS to _google_fonts_raw.css"

# Extract woff2 URLs
WOFF2_URLS=$(echo "$FONT_CSS" | grep -oP 'https://fonts\.gstatic\.com[^)]+\.woff2' | sort -u)
echo ""
echo "Found $(echo "$WOFF2_URLS" | wc -l | tr -d ' ') woff2 URLs"

# Download each, renaming based on the URL path
echo "$WOFF2_URLS" | while read -r url; do
  filename=$(basename "$url")
  echo "  Downloading $filename..."
  curl -sLo "$filename" "$url"
done

echo ""
echo "Done. Files in fonts/:"
ls -1 *.woff2 2>/dev/null || echo "  (no woff2 files — check _google_fonts_raw.css for errors)"
