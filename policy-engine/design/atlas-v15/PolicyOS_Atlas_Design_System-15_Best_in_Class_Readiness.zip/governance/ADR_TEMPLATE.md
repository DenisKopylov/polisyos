# ADR-YYYY-NNN: <decision title>

Date: YYYY-MM-DD  
Status: Proposed | Accepted | Superseded | Deprecated  
Owners: <names/teams>

## Context

What constraints, product needs or system risks led to this decision?

## Decision

What did we decide?

## Consequences

What becomes easier, harder or impossible?

## Alternatives considered

| Alternative | Pros | Cons | Why rejected |
|---|---|---|---|

## Evidence

Link to RFCs, audits, test outputs, Figma reviews or user research.

## Review date

When should this decision be revisited?

