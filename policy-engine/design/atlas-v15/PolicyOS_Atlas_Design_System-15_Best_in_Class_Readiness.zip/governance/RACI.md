# Atlas RACI

| Workstream | Responsible | Accountable | Consulted | Informed |
|---|---|---|---|---|
| Design tokens | Design System Engineering | Design System Lead | Brand, Accessibility, Product Design | Product teams |
| Component API | Design System Engineering | Frontend Platform Lead | Product Engineering, Accessibility | Consumers |
| Component UX/anatomy | Product Design Systems | Design System Lead | Content Design, Accessibility | Product teams |
| Accessibility contract | Accessibility Lead | Design System Lead | Engineering, QA, Legal/Compliance | Consumers |
| Theming/modes | Design System Engineering | Accessibility Lead | Brand, Product Design | Product teams |
| Data visualization grammar | Data Experience Lead | Product Design Lead | Accessibility, Analytics, Engineering | Product teams |
| Content standards | Content Design Lead | Product Design Lead | Legal/Compliance, Support | Consumers |
| Security/privacy UX | Security UX Lead | Security/Privacy Lead | Legal, Engineering, Product Design | Product teams |
| I18n/RTL | Localization Lead | Product Design Lead | Engineering, Accessibility | Consumers |
| Figma parity | Design System Designer | Design System Lead | Frontend Platform | Product designers |
| Release management | Design System Engineering | Design System Lead | QA, Accessibility, Product Owners | Consumers |
| Deprecation | Design System Engineering | Design System Lead | Consumers, Product Owners | All consumers |

## Decision rights

- Token naming and semantics: Design System Lead.
- Component API: Frontend Platform Lead with Design System Lead approval.
- Accessibility exceptions: Accessibility Lead with explicit risk acceptance.
- Security/privacy exceptions: Security/Privacy Lead.
- Breaking changes: Design System Lead and affected product owners.

