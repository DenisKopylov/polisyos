# Atlas governance operating model

Governance turns Atlas from a component collection into a durable design-system product. This folder defines ownership, decision flow, exception handling, adoption measurement, release rules and deprecation behavior.

## Governance principles

1. **System before screen.** New UI should use Atlas primitives unless an RFC approves an exception.
2. **Evidence before maturity.** Stable status requires docs, states, tokens, accessibility contract and test/evidence links.
3. **Accessibility is not a final QA step.** It is part of API, token, state and content design.
4. **Exceptions expire.** Any exception needs an owner, risk, mitigation and review date.
5. **Breaking changes are deliberate.** Consumers get migration notes and a support window.
6. **Design/code parity is measured.** Figma, tokens and React APIs must not silently drift.

## Files

| File | Purpose |
|---|---|
| `RACI.md` | Ownership across design, engineering, accessibility, product and security |
| `RFC_TEMPLATE.md` | Request format for new components, tokens, modes or breaking changes |
| `ADR_TEMPLATE.md` | Architecture decision record template |
| `deprecation-policy.md` | How APIs/components/tokens are sunset |
| `release-governance.md` | Release types, gates and evidence |
| `adoption-metrics.md` | How adoption and drift are measured |
| `exception-register.md` | Known exceptions and required fields |
| `component-health.schema.json` | Machine-readable schema for component health |
| `component-health.json` | Generated health inventory |
| `component-health.md` | Human-readable component health report |

## Review cadence

| Cadence | Review |
|---|---|
| Weekly | RFC triage, exceptions, blockers |
| Biweekly | Component health and design/code parity |
| Monthly | Adoption metrics, duplicate UI inventory, deprecated APIs |
| Release | Migration notes, evidence reports, stale metadata, acceptance checklist |
| Quarterly | Token architecture, accessibility modes, platform expansion and roadmap |

