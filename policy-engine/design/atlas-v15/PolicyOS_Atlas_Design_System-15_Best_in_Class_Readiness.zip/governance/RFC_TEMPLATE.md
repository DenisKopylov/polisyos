# Atlas RFC template

## Title

`RFC-YYYY-NNN: <short name>`

## Type

- [ ] New component
- [ ] Component API change
- [ ] Token change
- [ ] Theming/mode change
- [ ] Accessibility exception
- [ ] Figma parity change
- [ ] Deprecation/removal
- [ ] Product-flow pattern

## Problem

What user, product or system problem is not covered by existing Atlas assets?

## Non-goals

What is explicitly out of scope?

## Proposed solution

Describe the API, anatomy, states, tokens, content, accessibility behavior and design usage.

## Alternatives considered

Explain why existing components/patterns are insufficient.

## Accessibility impact

- Keyboard model:
- Screen-reader contract:
- Focus management:
- Mode support:
- WCAG/APG mapping:
- Known risk:

## I18n/content impact

- String expansion:
- RTL/bidi:
- Locale formatting:
- Translation variables/plurals:

## Security/privacy impact

- Sensitive data:
- Permission states:
- Audit trail:
- Redaction/export:

## Figma/code parity

- Figma component/variant:
- React component/props:
- Token dependencies:
- Drift risk:

## Migration plan

- Affected consumers:
- Codemod/manual changes:
- Support window:
- Deprecation notice:

## Evidence required before stable

- [ ] Manifest entry
- [ ] Component docs
- [ ] State matrix
- [ ] Storybook story
- [ ] Static lint
- [ ] Token lint
- [ ] Accessibility contract
- [ ] Browser evidence if interactive
- [ ] Manual AT evidence if composite/critical

