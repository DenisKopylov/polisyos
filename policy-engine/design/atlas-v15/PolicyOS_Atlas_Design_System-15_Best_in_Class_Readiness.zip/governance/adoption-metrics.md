# Atlas adoption metrics

These metrics help the design system operate like a product.

## Core metrics

| Metric | Definition | Target |
|---|---|---|
| Component adoption | % of eligible UI using Atlas components | >= 85% in mature product areas |
| Token adherence | % of UI styles using Atlas tokens | >= 95% |
| Duplicate UI count | Product-specific components duplicating Atlas behavior | Trending down monthly |
| Figma/code parity | % of stable components with matching Figma variants and React props | >= 95% |
| Accessibility exception count | Open exceptions by severity | Zero critical; decreasing high/medium |
| Deprecated API usage | Consumers still using deprecated props/tokens/components | Zero by removal window |
| Component health freshness | Components reviewed within cadence | >= 90% within 90 days |
| Runtime evidence coverage | Stable interactive components with browser/AT evidence | >= 90% after runtime gates exist |

## Suggested dashboard fields

- component name;
- maturity;
- owner;
- usage count;
- duplicate patterns replaced;
- open issues;
- accessibility risk;
- Figma drift;
- token drift;
- last reviewed date;
- next review date.

