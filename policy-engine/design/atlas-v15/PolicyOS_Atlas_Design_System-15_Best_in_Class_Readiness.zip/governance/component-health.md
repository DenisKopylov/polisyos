# Atlas component health

Release: `15.0.0-accessibility-modes`
Components: **56**

| Health | Count |
|---|---|
| ready | 39 |
| watch | 17 |
| needs-review | 0 |

| Component | Status | States | Health | Risks | Owner |
|---|---|---:|---|---|---|
| Button | stable | 12 | ready | none | Design System / UI Foundations |
| Badge | stable | 8 | ready | none | Design System / UI Foundations |
| Panel | stable | 8 | ready | none | Design System / UI Foundations |
| Card | stable | 12 | ready | none | Design System / UI Foundations |
| MetricCard | stable | 7 | ready | none | Design System / Data Display |
| RunCard | stable | 14 | ready | none | Design System / PolicyOS Domain |
| TextField | stable | 12 | ready | none | Design System / Forms |
| TextArea | stable | 12 | ready | none | Design System / Forms |
| SelectField | stable | 11 | ready | none | Design System / Forms |
| Checkbox | stable | 10 | ready | none | Design System / Forms |
| Switch | stable | 8 | ready | none | Design System / Forms |
| Tabs | beta | 10 | watch | maturity is beta | Design System / Navigation |
| Dialog | beta | 10 | watch | maturity is beta | Design System / Overlays |
| Toast | stable | 8 | ready | none | Design System / Feedback |
| EmptyState | stable | 9 | ready | none | Design System / Feedback |
| Skeleton | stable | 5 | watch | low state coverage | Design System / Feedback |
| DataTable | beta | 13 | watch | maturity is beta | Design System / Data Display |
| GovernanceGate | stable | 9 | ready | none | Design System / PolicyOS Domain |
| Form | stable | 6 | watch | low state coverage | Design System / Form |
| FormSection | stable | 6 | watch | low state coverage | Design System / Form |
| FieldGroup | stable | 9 | ready | none | Design System / Form |
| ValidationSummary | stable | 6 | watch | low state coverage | Design System / Form |
| RadioGroup | stable | 8 | ready | none | Design System / Data Entry |
| CheckboxGroup | stable | 8 | ready | none | Design System / Data Entry |
| SearchField | stable | 9 | ready | none | Design System / Data Entry |
| PasswordField | stable | 10 | ready | none | Design System / Data Entry |
| SecretField | stable | 11 | ready | none | Design System / Data Entry |
| NumberField | stable | 9 | ready | none | Design System / Data Entry |
| RangeField | stable | 9 | ready | none | Design System / Data Entry |
| DateField | stable | 9 | ready | none | Design System / Data Entry |
| DateRangeField | beta | 9 | watch | maturity is beta | Design System / Data Entry |
| FileUpload | stable | 9 | ready | none | Design System / Data Entry |
| TokenInput | beta | 9 | watch | maturity is beta | Design System / Data Entry |
| Combobox | beta | 8 | watch | maturity is beta | Design System / Data Entry |
| CharacterCount | stable | 6 | watch | low state coverage | Design System / Data Entry |
| DashboardShell | beta | 7 | watch | maturity is beta | Design System / Dashboard Layout |
| DashboardTopBar | beta | 8 | watch | maturity is beta | Design System / Responsive Surfaces |
| ResponsiveGrid | stable | 7 | ready | none | Design System / Layout Primitives |
| ScrollRegion | stable | 7 | ready | none | Design System / Responsive Layout |
| ChartFrame | stable | 8 | ready | none | Design System / Data Visualization |
| ChartLegend | stable | 8 | ready | none | Design System / Data Visualization |
| ChartTooltip | beta | 9 | watch | maturity is beta | Design System / Data Visualization |
| Sparkline | stable | 8 | ready | none | Design System / Data Visualization |
| BarChart | stable | 8 | ready | none | Design System / Data Visualization |
| LineChart | stable | 8 | ready | none | Design System / Data Visualization |
| Heatmap | beta | 8 | watch | maturity is beta | Design System / Data Visualization |
| UncertaintyBand | stable | 9 | ready | none | Design System / Data Visualization |
| ProvenanceGraph | beta | 11 | watch | maturity is beta | Design System / Data Visualization |
| ChartDataTable | stable | 8 | ready | none | Design System / Data Visualization |
| CausalGraph | beta | 9 | watch | maturity is beta | Design System / Data Visualization |
| ProvenanceMap | stable | 8 | ready | none | Design System / Data Visualization |
| ChartAnnotation | stable | 7 | ready | none | Design System / Data Visualization |
| DataVizTable | stable | 7 | ready | none | Design System / Data Visualization |
| ThemeProvider | stable | 9 | ready | none | Design System / Accessibility Theming |
| ThemeToggle | stable | 9 | ready | none | Design System / Accessibility Theming |
| AccessibilityModePanel | stable | 9 | ready | none | Design System / Accessibility Theming |
