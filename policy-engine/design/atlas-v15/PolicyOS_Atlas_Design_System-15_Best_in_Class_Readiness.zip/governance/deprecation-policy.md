# Atlas deprecation policy

## Deprecation states

| State | Meaning | Consumer action |
|---|---|---|
| Active | Preferred API/pattern | Use normally |
| Discouraged | Still supported, but no new adoption | Use replacement for new work |
| Deprecated | Replacement exists and migration path is documented | Migrate within support window |
| Removed | No longer shipped | Use replacement |

## Required deprecation fields

Every deprecated token, component, prop or pattern must include:

- replacement;
- reason;
- affected consumers;
- migration notes;
- first deprecated release;
- earliest removal release;
- owner;
- risk and mitigation;
- test or lint strategy.

## Default windows

| Change type | Minimum window |
|---|---|
| Token alias rename | 2 minor releases |
| Component prop rename | 2 minor releases |
| Component removal | 1 major release |
| Visual-only behavior change | 1 minor release with screenshots |
| Accessibility-critical correction | Can ship immediately, but must include migration notes |
| Security/privacy correction | Can ship immediately, with risk notes |

## Breaking-change checklist

- [ ] RFC accepted.
- [ ] Migration guide written.
- [ ] Changelog entry written.
- [ ] Deprecated API emits lint warning or docs warning.
- [ ] Replacement has stable maturity.
- [ ] Figma variant updated or mapped.
- [ ] Consumers notified.

