# Atlas exception register

Exceptions are temporary. Every exception needs an owner, risk rating, mitigation and review date.

| ID | Area | Item | Severity | Risk | Mitigation | Owner | Review date | Status |
|---|---|---|---|---|---|---|---|---|
| EX-001 | Accessibility | Runtime browser/AT evidence not included in ZIP | High | Static evidence cannot prove rendered behavior | Add Playwright/Storybook/AT evidence during integration phase | Accessibility Lead | 2026-07-31 | Open |
| EX-002 | Package engineering | Package remains private/internal | Medium | External publishability not proven | Add consumer smoke apps and exports tests before external publish | Frontend Platform | 2026-08-31 | Open |
| EX-003 | Visual regression | Mode/state screenshots not included | High | Mode regressions may escape static checks | Add visual matrix after Storybook runtime is active | Design System Engineering | 2026-07-31 | Open |
| EX-004 | I18n | Pseudo-locale screenshots not included | Medium | String expansion and RTL issues may be missed | Add pseudo-locale stories and screenshots in runtime phase | Localization Lead | 2026-08-31 | Open |
| EX-005 | Figma parity | Token export exists but component variant drift is not measured | Medium | Designers and engineers may diverge | Run parity review using `figma/component-parity.md` | Design System Lead | 2026-07-31 | Open |

