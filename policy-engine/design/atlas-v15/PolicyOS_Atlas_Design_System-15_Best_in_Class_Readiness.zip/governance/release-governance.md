# Atlas release governance

Current release: `15.0.0-accessibility-modes`

## Release types

| Type | Example | Required evidence |
|---|---|---|
| Patch | Bugfix, docs correction, token alias fix | Targeted lint/test evidence |
| Minor | New stable component, mode or pattern | Full archive gates + migration notes |
| Major | Breaking API, token scale or architecture change | RFC, ADR, migration plan and consumer signoff |
| Readiness overlay | Governance/docs/contracts without runtime integration | Release lint, readiness lint and clear runtime caveats |

## Archive release gates

```bash
npm run release:lint
npm run readiness:lint
npm run verify
```

## Runtime release gates later

- Storybook axe test output;
- keyboard interaction Playwright tests;
- visual regression across core modes;
- manual AT notes for critical flows;
- SSR/consumer smoke tests;
- bundle/exports checks.

## Release note requirements

Every release note must include:

- release version and date;
- new/changed/deprecated/removed sections;
- accessibility impact;
- token impact;
- Figma impact;
- migration notes;
- evidence links;
- known exceptions or restrictions.

