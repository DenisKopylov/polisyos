# Atlas internationalization and localization contract

Atlas must support products that operate across languages, scripts, timezones and regulatory contexts. This folder defines archive-level rules before runtime pseudo-locale and RTL screenshots are added.

## Required axes

| Axis | Requirement |
|---|---|
| Language | UI must not assume English length, grammar or word order |
| Locale | Date, time, number, currency and percent formatting must be locale-aware |
| Direction | Layout must support LTR, RTL and mixed-script bidi content |
| Timezone | Audit and policy times must declare timezone/source |
| Translation | No concatenated strings; use complete templates with variables/plurals |
| Legal/regulatory copy | Do not truncate critical obligations, decisions or audit text |
| Data visualization | Chart labels, summaries, tables and exports must localize together |

## Required test locales

| Locale | Purpose |
|---|---|
| `en-US` | Baseline LTR |
| `uk-UA` | Cyrillic, longer regulatory/product language |
| `de-DE` | String expansion and compound words |
| `ar` | RTL, Arabic script and bidi testing |
| `he` | RTL, Hebrew script and mixed English tokens |
| `ja-JP` | CJK density and no spaces between words |
| `pseudo-long` | 30-50% expansion stress |
| `pseudo-bidi` | Mixed LTR/RTL stress |

## Entry points

- `translation-contract.md`
- `rtl-bidi.md`
- `string-expansion.md`
- `locale-formatting.md`
- `i18n-test-matrix.md`
- `pseudo-locales.md`

