# I18n test matrix

| Surface | en-US | uk-UA | de-DE | ar | he | ja-JP | pseudo-long | pseudo-bidi |
|---|---|---|---|---|---|---|---|---|
| Auth | Required | Required | Required | Required | Optional | Optional | Required | Required |
| Dashboard shell | Required | Required | Required | Required | Required | Optional | Required | Required |
| Forms/data-entry | Required | Required | Required | Required | Required | Optional | Required | Required |
| Validation summary | Required | Required | Required | Required | Required | Optional | Required | Required |
| Dialog/overlay | Required | Required | Required | Required | Required | Optional | Required | Required |
| Data table | Required | Required | Required | Required | Required | Optional | Required | Required |
| Data visualization | Required | Required | Required | Required | Optional | Required | Required | Required |
| Export/print | Required | Required | Required | Required | Optional | Optional | Required | Required |
| Audit trail | Required | Required | Required | Required | Required | Optional | Required | Required |

Runtime phase output: screenshots and keyboard/focus notes per required cell.

