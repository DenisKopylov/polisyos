# Locale formatting contract

| Data type | Requirement |
|---|---|
| Date | Use locale formatter; declare timezone when audit-critical |
| Time | Include timezone/source for run, evidence, audit and policy events |
| Relative time | Provide absolute time on hover/detail/export |
| Number | Use locale grouping and decimal separators |
| Currency | Use locale and currency code; do not infer from language alone |
| Percent | Localize decimal separator and spacing |
| File size | Localize units while preserving exact bytes in detail when needed |
| Identifiers | Do not localize machine IDs; isolate when mixed with RTL text |
| Phone/address | Use product-region formatter, not generic string masks |

## Audit-critical timestamp format

For audit/export, include:

- local display time;
- timezone;
- UTC timestamp;
- source system if relevant.

