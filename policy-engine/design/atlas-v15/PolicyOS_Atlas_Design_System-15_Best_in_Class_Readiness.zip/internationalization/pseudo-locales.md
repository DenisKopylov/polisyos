# Pseudo-locales

## `pseudo-long`

Purpose: expose clipping, overflow, fixed-width assumptions and poor wrapping.

Rules:

- Expand Latin strings by 30-50%.
- Preserve variables and IDs.
- Add bracket markers around translated units.
- Avoid making text unreadable to reviewers.

## `pseudo-bidi`

Purpose: expose mixed-direction and logical-property bugs.

Rules:

- Wrap text with bidi markers in test environment only.
- Preserve machine identifiers.
- Include mixed English IDs inside RTL-like sentences.
- Test icon placement, navigation and table alignment.

## Fixture file

See `fixtures/pseudo-locale.examples.json`.

