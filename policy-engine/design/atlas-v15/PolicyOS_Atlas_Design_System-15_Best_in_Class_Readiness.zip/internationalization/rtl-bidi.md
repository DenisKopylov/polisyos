# RTL and bidirectional text contract

## Layout rules

- Prefer logical CSS properties: `inline-start`, `inline-end`, `block-start`, `margin-inline`, `padding-inline`.
- Do not encode direction in icon names unless there are mirrored assets.
- Navigation order must follow reading direction, but workflow order must remain semantically correct.
- Data tables must preserve column meaning; do not reorder identifiers or numbers in a way that breaks auditability.
- Mixed-script strings such as policy IDs, URLs, emails and evidence IDs need bidi isolation.

## Component requirements

| Component/pattern | RTL requirement |
|---|---|
| Button with icon | Icon placement follows logical start/end unless icon is semantic |
| Breadcrumbs | Separator mirrors and reading order is correct |
| Tabs | Arrow-key model follows documented direction behavior |
| DataTable/DataGrid | Numeric alignment and identifier order remain stable |
| Chart axes | Labels and summaries localize; numeric scale remains readable |
| Drawer/Sidebar | Placement uses logical side; focus order is predictable |
| Toast/Dialog | Focus and close action placement remain discoverable |

## Bidi isolation examples

Use isolation for dynamic LTR identifiers inside RTL text and for RTL names inside LTR sentences.

- Evidence ID: `EV-2026-00482`
- Email: `reviewer@example.com`
- URL: `https://policyos.example/case/42`
- Mixed person/team names in audit trails

