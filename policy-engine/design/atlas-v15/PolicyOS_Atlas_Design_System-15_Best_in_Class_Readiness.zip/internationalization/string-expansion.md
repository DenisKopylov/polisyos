# String expansion contract

## Expansion assumptions

| Content type | Minimum stress target |
|---|---|
| Navigation labels | +30% |
| Buttons | +40% |
| Form labels | +50% |
| Error messages | +50% |
| Table column headers | +40% |
| Chart labels | +40% |
| Empty states | +50% |
| Legal/audit copy | No truncation without full-text path |

## Required behavior

- Prefer wrapping over truncation for labels, errors and audit copy.
- Truncation requires accessible full text via title, description, disclosure or detail view.
- Buttons must not collapse icon/label relationships.
- Tables must support horizontal scroll or column priority/card reflow.
- Charts must preserve data-table alternatives when labels are long.
- Empty states must keep CTA visible after expansion.

