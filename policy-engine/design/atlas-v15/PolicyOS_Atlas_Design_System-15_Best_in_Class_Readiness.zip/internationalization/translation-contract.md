# Translation contract

## Hard rules

- Do not concatenate translated fragments to form a sentence.
- Do not embed text in images or SVGs unless a text alternative and localization path exists.
- Do not assume variables appear in English order.
- Do not use icon-only meaning without localized text.
- Do not truncate audit-critical, legal, permission or decision text without an expansion path.
- Do not hard-code date, time, number, currency or percent formats.
- Do not use uppercase as the only emphasis mechanism; some scripts do not have case.

## Template requirements

Every translatable string must support:

- stable message ID;
- description/context for translators;
- variables with semantic names;
- plural/select rules where relevant;
- fallback behavior;
- product/legal owner for regulated wording.

## Examples

| Bad | Good |
|---|---|
| `"Delete " + count + " items"` | `deleteItems.count` with plural rules |
| `"Last run: " + date` | `lastRun.timestamp` with locale date formatter |
| `"Access denied"` only | Title, reason, recovery path and request-access CTA |
| Abbreviated legal outcome | Full text with expandable detail and export-safe copy |

