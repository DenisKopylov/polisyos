import '../../../dist/tokens/atlas.tokens.css';
import '../src/atlas-ui.css';

export const parameters = {
  a11y: { test: 'error' },
  controls: { expanded: true }
};
