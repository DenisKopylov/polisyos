# @policyos/atlas-ui changelog

## 15.0.0-accessibility-modes

- Added ThemeProvider, ThemeToggle, AccessibilityModePanel and formal accessibility mode exports.
- Added forced-colors, high-contrast, dark-mode, reduced-motion, reduced-transparency, large-text, density and print/export contracts.
- Added ZIP-level best-in-class readiness pack for governance, i18n, content design, security/privacy UX, product patterns, Figma parity and future evidence gates.

## 14.0.0-data-visualization

- Added Atlas Data Visualization System grammar and package exports.
- Added ChartFrame, ChartLegend, ChartTooltip, ChartDataTable, Sparkline, LineChart, BarChart, UncertaintyBand, Heatmap, CausalGraph and ProvenanceMap.
- Added data-viz tokens, component docs, state matrices, Storybook-ready examples and data_viz_lint gate.
- Added JSON grammar export at @policyos/atlas-ui/data-viz with chart-type, accessibility and no-color-alone requirements.


## 12.0.0-forms-data-entry

- Added production form structure components: Form, FormSection, FieldGroup and ValidationSummary.
- Added data-entry components: RadioGroup, CheckboxGroup, SearchField, PasswordField, SecretField, NumberField, RangeField, DateField, DateRangeField, FileUpload, TokenInput, Combobox and CharacterCount.
- Expanded component manifest coverage from 18 to 35 components.
- Expanded state matrix coverage to 317 supported states and 53 explicitly rejected states.
- Added form/data-entry tokens, token-only CSS selectors and Storybook-ready DataEntry examples.
- Added form guidance for validation recovery, field anatomy, input purpose/autocomplete and PolicyOS evidence/governance data-entry patterns.

## 11.0.0-state-matrix

- Added canonical v11 state matrices for all production components.
- Added package exports for `state-matrix.json` and `state-taxonomy.json`.
- Added stable `data-state` hooks for state-driven docs, tests and visual QA.
- Added Checkbox indeterminate/mixed state support.
- Added StateMatrix Storybook coverage and state lint gate.

## 10.0.0-component-library

- Introduced the first production-grade Atlas React component package.
- Added typed exports for Button, Badge, Panel, Card, Field primitives, Tabs, Dialog, Toast, DataTable, EmptyState, Skeleton and PolicyOS domain patterns.
- Added token-only component CSS and manifest-backed component governance.
- Added Storybook-ready stories and migration guide from `ui_kits/dashboard/Components.jsx`.

## 13.0.0-dashboard-responsive

- Added responsive dashboard primitives and Storybook coverage.
- Added breakpoint contract, responsive docs and lint gate.
- Hardened standalone dashboard prototype for drawer/rail/docked navigation and print/export.

