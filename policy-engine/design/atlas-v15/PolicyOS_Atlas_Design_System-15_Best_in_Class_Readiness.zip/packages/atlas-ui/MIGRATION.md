# Migration from dashboard prototype primitives

The previous dashboard kit exposed globals through `Object.assign(window, ...)`. That file remains as a compatibility shim for static prototypes, but production code should import from `@policyos/atlas-ui`.

| Prototype global | Production import | Notes |
|---|---|---|
| `Button` | `import { Button } from '@policyos/atlas-ui'` | Adds typed props, loading state, ref forwarding and stable variants. |
| `Badge` | `import { Badge } from '@policyos/atlas-ui'` | Uses `tone` instead of prototype `kind`; `kind` is normalized by the bridge docs. |
| `Panel` | `import { Panel } from '@policyos/atlas-ui'` | Adds heading-level contract and landmark guidance. |
| `MetricCard` | `import { MetricCard } from '@policyos/atlas-ui'` | Adds machine-readable label/value semantics. |
| `RunCard` | `import { RunCard } from '@policyos/atlas-ui'` | Adds typed status, native button behavior and evidence metadata. |
| Ad hoc field markup | `TextField`, `SelectField`, `Checkbox`, `Switch` | Adds label/description/error wiring. |
| Ad hoc form wrappers | `Form`, `FormSection`, `FieldGroup`, `ValidationSummary` | Adds labelled structure, validation summary placement and state contracts. |
| Radio/checkbox card groups | `RadioGroup`, `CheckboxGroup` | Replaces visual-only choice cards with native fieldsets and inputs. |
| Search boxes | `SearchField` | Adds labelled search semantics, optional clear action and submit affordance. |
| Password/API key fields | `PasswordField`, `SecretField` | Adds reveal/copy actions with accessible names and privacy states. |
| Numeric/date/range/file inputs | `NumberField`, `RangeField`, `DateField`, `DateRangeField`, `FileUpload` | Adds units, constraints, helper/error wiring and state coverage. |
| Tag/chip entry | `TokenInput` | Adds visible selected values with labelled remove buttons. |
| Autocomplete/select search | `Combobox` | Adds ARIA combobox/listbox contract for single-select lookup. |
| Ad hoc tab markup | `Tabs` | Adds APG-style keyboard behavior. |
| Modal overlays | `Dialog` | Adds dialog semantics and close contract. |

## Migration sequence

1. Import tokens and Atlas UI CSS once at the app shell.
2. Replace global prototype primitives with package imports screen by screen.
3. Move raw state strings into typed unions where possible.
4. Use `component-library/component-manifest.json` to verify maturity, required states and accessibility notes.
5. Add `ValidationSummary` plus local field errors for every submit flow.
6. Set `autoComplete` where fields collect personal data.
7. Run `npm run verify` from the root package before merging.

## Migrating to v13 dashboard responsive primitives

Replace fixed dashboard shells with `DashboardShell`, use `DashboardSidebar` for docked/rail/drawer navigation, wrap dense tables in `ResponsiveDataRegion`, and use `DashboardGrid` variants instead of fixed `gridTemplateColumns` values.


## v13 Dashboard Responsive

Atlas UI now includes responsive table and layout helper CSS. `DataTable` exposes `responsiveMode`, `density`, `mobileLabel` and `priority` for scroll-contained or card-reflow behavior. The runtime dashboard shell consumes the responsive token layer and dashboard responsive CSS.


## Migrating to v15 accessibility modes

- Load generated Atlas tokens before Atlas UI CSS.
- Use `ThemeProvider` for app-level mode resolution.
- Use `ThemeToggle` only where user-controlled scheme switching is part of the product shell.
- Use `AccessibilityModePanel` for operator-facing accessibility preferences.
- Do not bypass mode tokens with raw colors, opacity or motion values.

## Using the best-in-class readiness pack

The readiness overlay adds governance and acceptance criteria but does not require runtime migration. Product teams should read `BEST_IN_CLASS_READINESS.md`, `best-in-class/readiness-matrix.md`, `best-in-class/evidence-index.md`, `governance/release-governance.md`, `figma/component-parity.md` and `best-in-class/browser-and-at-evidence-plan.md` before integration.
