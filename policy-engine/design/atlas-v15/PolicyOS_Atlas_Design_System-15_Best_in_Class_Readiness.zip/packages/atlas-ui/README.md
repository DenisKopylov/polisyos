# @policyos/atlas-ui

Current root release: `15.0.0-accessibility-modes`.

Atlas UI includes the v15 theming/accessibility modes layer plus a ZIP-level best-in-class readiness pack in the root archive. Runtime exports are unchanged by the readiness pack.

Atlas UI is the production component package for the PolicyOS Atlas design system. It turns the dashboard prototype primitives and form/data-entry patterns into stable, typed, accessible React components backed by generated design tokens.

## Install inside a product workspace

```bash
npm install @policyos/atlas-ui
```

```tsx
import '@policyos/atlas-ui/css';
import { Button, Form, FormSection, TextField, GovernanceGate } from '@policyos/atlas-ui';

export function ReviewPanel() {
  return (
    <Form title="Review packet">
      <FormSection title="Governance">
        <GovernanceGate
          title="Transportability review"
          status="review"
          evidenceCount={18}
          action={<Button variant="primary">Open packet</Button>}
        />
      </FormSection>
    </Form>
  );
}
```

Consumers must load Atlas tokens before the component CSS:

```tsx
import '@policyos/atlas-design-system/dist/tokens/atlas.tokens.css';
import '@policyos/atlas-ui/css';
```

## Component quality bar

A component is considered stable only when it has:

- typed public props;
- token-only styling;
- native semantics first;
- keyboard and screen-reader contract;
- state matrix covering default, hover, focus-visible, active, loading, disabled, error and high-contrast where relevant;
- Storybook-ready examples;
- documentation with usage, style, code, accessibility and content notes;
- a manifest entry with maturity status and owner.

See `component-manifest.json` and `/component-library` in the root design-system package.


## State matrix exports

v12 exposes the state and data-entry contract to consumers:

```ts
import stateMatrix from '@policyos/atlas-ui/state-matrix';
import stateTaxonomy from '@policyos/atlas-ui/state-taxonomy';
```

The JSON artifacts mirror `component-library/state-matrix/*` and are validated by `scripts/state_matrix_lint.py`. Consumers can use them to drive visual regression, Storybook docs, QA checklists and release dashboards.


## Forms and data entry

v12 adds production-ready form structure and data-entry controls:

- `Form`, `FormSection`, `FieldGroup`, `ValidationSummary`;
- `RadioGroup`, `CheckboxGroup`;
- `SearchField`, `PasswordField`, `SecretField`;
- `NumberField`, `RangeField`, `DateField`, `DateRangeField`;
- `FileUpload`, `TokenInput`, `Combobox`, `CharacterCount`.

Use these instead of ad-hoc form markup so label/description/error wiring, focus-visible, high-contrast mode and state matrices stay consistent.

## v13 dashboard responsive primitives

Import responsive dashboard primitives from the package root:

```tsx
import {
  DashboardShell,
  DashboardSidebar,
  DashboardTopBar,
  ResponsiveGrid,
  ScrollRegion,
  getAtlasDashboardWindowClass,
} from '@policyos/atlas-ui';
```

The canonical responsive contract is exported at `@policyos/atlas-ui/dashboard-responsive` and mirrored in `dist/atlas-ui/dashboard-responsive.json` plus `dist/dashboard-responsive/responsive-manifest.json`. `@policyos/atlas-ui/responsive-contract` remains available for compatibility with earlier v13 layout docs.

Atlas UI now includes responsive shell, rail, drawer, grid, pane and contained-scroll CSS. `DataTable` exposes `responsiveMode`, `density`, `mobileLabel` and `priority` for scroll-contained or card-reflow behavior. The runtime dashboard shell consumes the responsive token layer and the generated `dashboard-responsive-contracts.ts` helpers.


## v14 data visualization

Atlas UI now includes formal data-visualization primitives:

- `ChartFrame`, `ChartLegend`, `ChartTooltip`, `ChartDataTable`;
- `Sparkline`, `LineChart`, `BarChart`, `UncertaintyBand`, `Heatmap`;
- `CausalGraph` and `ProvenanceMap` for PolicyOS evidence, assumptions and lineage.

The canonical chart grammar is exported at `@policyos/atlas-ui/data-viz` and mirrored in `dist/data-visualization/data-viz-manifest.json`. Production chart usage requires text summary, data-table equivalent/source context and non-color encoding for meaningful distinctions.


## Theming and accessibility modes

Use `ThemeProvider`, `ThemeToggle` and `AccessibilityModePanel` to apply Atlas v15 accessibility modes. The package exports `./theming`, `./theme-manifest`, `./theme-modes` and `./theme-contracts` for application shells and audits.


## v15 theming accessibility modes

Atlas UI exposes `ThemeProvider`, `ThemeToggle` and `AccessibilityModePanel` plus machine-readable theme manifests for forced colors, high contrast, automatic dark mode, reduced motion, reduced transparency, large text, color-safe encodings, density and print/export workflows.
