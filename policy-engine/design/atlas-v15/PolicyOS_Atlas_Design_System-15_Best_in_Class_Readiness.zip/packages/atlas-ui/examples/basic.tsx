import '@policyos/atlas-design-system/dist/tokens/atlas.tokens.css';
import '@policyos/atlas-ui/css';
import { Badge, Button, Panel, TextField } from '@policyos/atlas-ui';

export function BasicAtlasExample() {
  return (
    <Panel
      title="Decision packet"
      eyebrow="Governance"
      description="Reviewer-ready summary with evidence and run metadata."
      actions={<Badge tone="warning">review</Badge>}
      hero
    >
      <TextField label="Reviewer note" description="This note is stored in the audit trail." />
      <Button variant="primary">Submit review</Button>
    </Panel>
  );
}
