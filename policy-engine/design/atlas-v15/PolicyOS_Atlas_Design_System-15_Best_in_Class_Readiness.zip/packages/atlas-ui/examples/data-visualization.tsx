
import '@policyos/atlas-ui/css';
import { ChartFrame, ChartDataTable, LineChart, UncertaintyBand } from '@policyos/atlas-ui';

const values = [
  { label: 'Q1', value: 42, low: 34, high: 50 },
  { label: 'Q2', value: 46, low: 36, high: 55 },
  { label: 'Q3', value: 50, low: 39, high: 61 },
];

export function DecisionEvidenceChart() {
  return (
    <ChartFrame
      title="Projected policy impact"
      summary="The midpoint improves each quarter, but uncertainty remains material for approval."
      source="PolicyOS synthetic example"
      dataTable={
        <ChartDataTable
          caption="Projected impact values"
          columns={[{ key: 'period', header: 'Period', rowHeader: true }, { key: 'low', header: 'Low', align: 'end' }, { key: 'mid', header: 'Midpoint', align: 'end' }, { key: 'high', header: 'High', align: 'end' }]}
          rows={values.map((item) => ({ period: item.label, low: item.low, mid: item.value, high: item.high }))}
        />
      }
    >
      <LineChart title="Midpoint trend" summary="The midpoint rises from Q1 to Q3." series={[{ id: 'midpoint', label: 'Midpoint', data: values }]} />
      <UncertaintyBand title="Projected interval" summary="The uncertainty band shows low and high bounds for each quarter." data={values} />
    </ChartFrame>
  );
}
