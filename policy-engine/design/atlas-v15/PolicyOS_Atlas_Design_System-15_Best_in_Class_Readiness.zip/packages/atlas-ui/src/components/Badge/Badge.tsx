import type * as React from 'react';
import { cx } from '../../utils/cx';
import type { AtlasTone } from '../../types';

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  tone?: AtlasTone;
  status?: boolean;
}

export function Badge({ tone = 'neutral', status = false, role, className, ...props }: BadgeProps) {
  return (
    <span
      {...props}
      className={cx('atlas-badge', className)}
      data-atlas-component="Badge"
      data-tone={tone}
      data-state={status ? 'status' : tone}
      role={status ? 'status' : role}
    />
  );
}
