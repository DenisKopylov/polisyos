import * as React from 'react';
import { cx } from '../../utils/cx';

export type ButtonVariant = 'primary' | 'secondary' | 'ghost' | 'quiet' | 'danger' | 'dark';
export type ButtonSize = 'sm' | 'md' | 'lg' | 'icon';
export type ButtonVisualState = 'default' | 'loading' | 'disabled';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  loading?: boolean;
  loadingLabel?: string;
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  {
    variant = 'secondary',
    size = 'md',
    loading = false,
    loadingLabel = 'Loading',
    disabled,
    className,
    children,
    type = 'button',
    ...props
  },
  ref,
) {
  const isDisabled = disabled || loading;
  const visualState: ButtonVisualState = loading ? 'loading' : isDisabled ? 'disabled' : 'default';
  return (
    <button
      ref={ref}
      type={type}
      className={cx('atlas-button', className)}
      data-atlas-component="Button"
      data-variant={variant}
      data-size={size}
      data-state={visualState}
      data-loading={loading || undefined}
      disabled={isDisabled}
      aria-busy={loading || undefined}
      {...props}
    >
      {loading ? <span className="atlas-spinner" aria-hidden="true" /> : null}
      {loading ? <span className="atlas-visually-hidden">{loadingLabel}</span> : null}
      {children}
    </button>
  );
});
