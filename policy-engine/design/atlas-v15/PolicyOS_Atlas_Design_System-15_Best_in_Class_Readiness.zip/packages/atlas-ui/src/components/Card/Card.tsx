import * as React from 'react';
import { cx } from '../../utils/cx';
import { useAtlasId } from '../../utils/ids';

export interface CardProps extends React.HTMLAttributes<HTMLElement> {
  title?: React.ReactNode;
  description?: React.ReactNode;
  action?: React.ReactNode;
  interactive?: false;
}

export interface CardButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  title: React.ReactNode;
  description?: React.ReactNode;
  meta?: React.ReactNode;
  selected?: boolean;
}

export const Card = React.forwardRef<HTMLElement, CardProps>(function Card(
  { title, description, action, id, className, children, ...props },
  ref,
) {
  const cardId = useAtlasId(id, 'atlas-card');
  const titleId = title ? `${cardId}-title` : undefined;
  return (
    <article
      ref={ref}
      id={cardId}
      className={cx('atlas-card', className)}
      data-atlas-component="Card"
      data-state="static"
      aria-labelledby={titleId}
      {...props}
    >
      {(title || description || action) ? (
        <header className="atlas-panel-header">
          <div>
            {title ? <h3 id={titleId} className="atlas-card-title">{title}</h3> : null}
            {description ? <p className="atlas-card-description">{description}</p> : null}
          </div>
          {action ? <div>{action}</div> : null}
        </header>
      ) : null}
      {children}
    </article>
  );
});

export const CardButton = React.forwardRef<HTMLButtonElement, CardButtonProps>(function CardButton(
  { title, description, meta, selected = false, disabled, className, children, ...props },
  ref,
) {
  const state = disabled ? 'disabled' : selected ? 'selected' : 'interactive';
  return (
    <button
      ref={ref}
      type="button"
      className={cx('atlas-card atlas-card-button', className)}
      data-atlas-component="CardButton"
      data-state={state}
      disabled={disabled}
      aria-pressed={selected}
      {...props}
    >
      <span className="atlas-card-title">{title}</span>
      {description ? <span className="atlas-card-description">{description}</span> : null}
      {meta ? <span className="atlas-run-meta">{meta}</span> : null}
      {children}
    </button>
  );
});
