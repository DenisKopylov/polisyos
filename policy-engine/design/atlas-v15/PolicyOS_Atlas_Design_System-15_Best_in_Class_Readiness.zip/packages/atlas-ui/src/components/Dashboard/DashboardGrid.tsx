import type * as React from 'react';
import { cx } from '../../utils/cx';

export interface DashboardGridProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'auto' | 'metrics' | 'content-sidebar' | 'split' | 'stack';
  minColumn?: string;
  gap?: 'default' | 'compact';
}

export function DashboardGrid({ variant = 'auto', minColumn, gap = 'default', className, style, children, ...props }: DashboardGridProps) {
  const styleWithColumn = minColumn ? { ...style, '--atlas-dashboard-grid-min': minColumn } as React.CSSProperties : style;
  return (
    <div
      className={cx('atlas-dashboard-grid', className)}
      data-atlas-component="DashboardGrid"
      data-variant={variant}
      data-gap={gap}
      data-state="responsive"
      style={styleWithColumn}
      {...props}
    >
      {children}
    </div>
  );
}
