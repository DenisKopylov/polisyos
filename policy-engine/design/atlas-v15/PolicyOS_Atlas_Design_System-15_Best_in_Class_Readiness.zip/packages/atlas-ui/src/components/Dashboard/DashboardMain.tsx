import type * as React from 'react';
import { cx } from '../../utils/cx';

export interface DashboardMainProps extends React.HTMLAttributes<HTMLElement> {
  title?: React.ReactNode;
  description?: React.ReactNode;
  actions?: React.ReactNode;
  maxMeasure?: boolean;
}

export function DashboardMain({ title, description, actions, maxMeasure = false, children, className, ...props }: DashboardMainProps) {
  return (
    <main
      className={cx('atlas-dashboard-main', maxMeasure && 'atlas-dashboard-main--max-measure', className)}
      data-atlas-component="DashboardMain"
      data-state={title ? 'with-heading' : 'content-only'}
      {...props}
    >
      {title || description || actions ? (
        <div className="atlas-dashboard-main-header">
          <div className="atlas-dashboard-main-copy">
            {title ? <h1 className="atlas-dashboard-main-title">{title}</h1> : null}
            {description ? <p className="atlas-dashboard-main-description">{description}</p> : null}
          </div>
          {actions ? <div className="atlas-dashboard-main-actions">{actions}</div> : null}
        </div>
      ) : null}
      <div className="atlas-dashboard-main-body">{children}</div>
    </main>
  );
}
