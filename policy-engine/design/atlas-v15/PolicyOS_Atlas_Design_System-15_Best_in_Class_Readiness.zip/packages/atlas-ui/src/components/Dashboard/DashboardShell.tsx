import type * as React from 'react';
import type { Density } from '../../types';
import { cx } from '../../utils/cx';

export type DashboardSidebarMode = 'auto' | 'docked' | 'rail' | 'drawer';

export interface DashboardShellProps extends React.HTMLAttributes<HTMLDivElement> {
  sidebar: React.ReactNode;
  topbar?: React.ReactNode;
  children: React.ReactNode;
  sidebarMode?: DashboardSidebarMode;
  density?: Density;
  navOpen?: boolean;
  contained?: boolean;
  ariaLabel?: string;
}

export function DashboardShell({ sidebar, topbar, children, sidebarMode = 'auto', density = 'comfortable', navOpen = false, contained = true, ariaLabel = 'Atlas dashboard', className, ...props }: DashboardShellProps) {
  return (
    <div
      className={cx('atlas-dashboard-shell', contained && 'atlas-dashboard-shell--contained', className)}
      data-atlas-component="DashboardShell"
      data-state={navOpen ? 'nav-open' : 'nav-closed'}
      data-sidebar-mode={sidebarMode}
      data-density={density}
      aria-label={ariaLabel}
      {...props}
    >
      {topbar ? <div className="atlas-dashboard-shell-topbar">{topbar}</div> : null}
      <div className="atlas-dashboard-shell-grid">
        <div className="atlas-dashboard-shell-sidebar">{sidebar}</div>
        <div className="atlas-dashboard-shell-content">{children}</div>
      </div>
    </div>
  );
}
