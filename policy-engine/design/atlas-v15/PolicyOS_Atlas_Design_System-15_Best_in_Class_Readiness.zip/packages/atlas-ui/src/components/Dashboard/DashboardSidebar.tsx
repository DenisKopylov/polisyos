import type * as React from 'react';
import { cx } from '../../utils/cx';

export interface DashboardNavItem {
  id: string;
  label: string;
  icon?: React.ReactNode;
  badge?: React.ReactNode;
  disabled?: boolean;
}

export interface DashboardSidebarProps extends React.HTMLAttributes<HTMLElement> {
  items: DashboardNavItem[];
  activeItemId?: string;
  onNavigate?: (id: string) => void;
  brand?: React.ReactNode;
  footer?: React.ReactNode;
  status?: React.ReactNode;
  mode?: 'docked' | 'rail' | 'drawer';
  open?: boolean;
  label?: string;
}

export function DashboardSidebar({ items, activeItemId, onNavigate, brand, footer, status, mode = 'docked', open = true, label = 'Dashboard navigation', className, ...props }: DashboardSidebarProps) {
  return (
    <aside
      className={cx('atlas-dashboard-sidebar', className)}
      data-atlas-component="DashboardSidebar"
      data-state={open ? 'open' : 'closed'}
      data-mode={mode}
      aria-label={label}
      aria-hidden={mode === 'drawer' && !open ? 'true' : undefined}
      {...props}
    >
      {brand ? <div className="atlas-dashboard-sidebar-brand">{brand}</div> : null}
      <nav className="atlas-dashboard-sidebar-nav" aria-label={label}>
        {items.map((item) => {
          const active = item.id === activeItemId;
          return (
            <button
              key={item.id}
              type="button"
              className="atlas-dashboard-sidebar-item"
              data-state={active ? 'active' : 'idle'}
              aria-current={active ? 'page' : undefined}
              aria-label={mode === 'rail' ? item.label : undefined}
              disabled={item.disabled}
              onClick={() => onNavigate?.(item.id)}
            >
              {item.icon ? <span className="atlas-dashboard-sidebar-icon" aria-hidden="true">{item.icon}</span> : null}
              <span className="atlas-dashboard-sidebar-label">{item.label}</span>
              {item.badge ? <span className="atlas-dashboard-sidebar-badge">{item.badge}</span> : null}
            </button>
          );
        })}
      </nav>
      {status ? <div className="atlas-dashboard-sidebar-status">{status}</div> : null}
      {footer ? <div className="atlas-dashboard-sidebar-footer">{footer}</div> : null}
    </aside>
  );
}
