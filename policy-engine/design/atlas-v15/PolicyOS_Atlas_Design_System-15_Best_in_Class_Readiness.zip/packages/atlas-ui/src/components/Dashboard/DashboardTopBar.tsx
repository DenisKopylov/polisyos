import type * as React from 'react';
import { cx } from '../../utils/cx';

export interface DashboardTopBarProps extends React.HTMLAttributes<HTMLElement> {
  title: React.ReactNode;
  subtitle?: React.ReactNode;
  actions?: React.ReactNode;
  navOpen?: boolean;
  onNavToggle?: () => void;
  navButtonLabel?: string;
  sticky?: boolean;
}

export function DashboardTopBar({ title, subtitle, actions, navOpen = false, onNavToggle, navButtonLabel = 'Toggle dashboard navigation', sticky = true, className, ...props }: DashboardTopBarProps) {
  return (
    <header
      className={cx('atlas-dashboard-topbar', sticky && 'atlas-dashboard-topbar--sticky', className)}
      data-atlas-component="DashboardTopBar"
      data-state={navOpen ? 'nav-open' : 'nav-closed'}
      {...props}
    >
      {onNavToggle ? (
        <button type="button" className="atlas-dashboard-nav-toggle" aria-label={navButtonLabel} aria-expanded={navOpen ? 'true' : 'false'} onClick={onNavToggle}>
          <span aria-hidden="true">≔</span>
        </button>
      ) : null}
      <div className="atlas-dashboard-topbar-copy">
        <h1 className="atlas-dashboard-topbar-title">{title}</h1>
        {subtitle ? <p className="atlas-dashboard-topbar-subtitle">{subtitle}</p> : null}
      </div>
      {actions ? <div className="atlas-dashboard-topbar-actions">{actions}</div> : null}
    </header>
  );
}
