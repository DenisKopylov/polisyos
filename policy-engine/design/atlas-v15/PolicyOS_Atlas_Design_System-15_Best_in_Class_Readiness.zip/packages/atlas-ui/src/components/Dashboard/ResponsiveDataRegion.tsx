import type * as React from 'react';
import { cx } from '../../utils/cx';

export interface ResponsiveDataRegionProps extends React.HTMLAttributes<HTMLElement> {
  caption?: React.ReactNode;
  summary?: React.ReactNode;
  overflowMode?: 'scroll' | 'stack' | 'cards';
  labelledBy?: string;
}

export function ResponsiveDataRegion({ caption, summary, overflowMode = 'scroll', labelledBy, className, children, ...props }: ResponsiveDataRegionProps) {
  return (
    <section
      className={cx('atlas-responsive-data-region', className)}
      data-atlas-component="ResponsiveDataRegion"
      data-state={overflowMode}
      data-overflow-mode={overflowMode}
      aria-labelledby={labelledBy}
      {...props}
    >
      {caption || summary ? (
        <div className="atlas-responsive-data-region-header">
          {caption ? <h2 id={labelledBy} className="atlas-responsive-data-region-title">{caption}</h2> : null}
          {summary ? <p className="atlas-responsive-data-region-summary">{summary}</p> : null}
        </div>
      ) : null}
      <div className="atlas-responsive-data-region-viewport" tabIndex={overflowMode === 'scroll' ? 0 : undefined}>
        {children}
      </div>
    </section>
  );
}
