import * as React from 'react';
import { cx } from '../../utils/cx';
import { useAtlasId } from '../../utils/ids';

export type AdaptiveDataRegionMode = 'table' | 'cards' | 'graph' | 'timeline';

export interface AdaptiveDataRegionProps extends React.HTMLAttributes<HTMLElement> {
  label: string;
  summary?: React.ReactNode;
  mode?: AdaptiveDataRegionMode;
}

export const AdaptiveDataRegion = React.forwardRef<HTMLElement, AdaptiveDataRegionProps>(function AdaptiveDataRegion(
  { label, summary, mode = 'table', id, className, children, ...props },
  ref,
) {
  const regionId = useAtlasId(id, 'atlas-data-region');
  const summaryId = summary ? `${regionId}-summary` : undefined;
  return (
    <section
      ref={ref}
      id={regionId}
      className={cx('atlas-adaptive-data-region', className)}
      data-atlas-component="AdaptiveDataRegion"
      data-state={mode}
      data-mode={mode}
      aria-label={label}
      aria-describedby={summaryId}
      {...props}
    >
      {summary ? <p id={summaryId} className="atlas-adaptive-data-region-summary">{summary}</p> : null}
      <div className="atlas-adaptive-data-region-scroll" tabIndex={mode === 'table' || mode === 'timeline' ? 0 : undefined}>
        {children}
      </div>
    </section>
  );
});
