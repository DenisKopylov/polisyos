import * as React from 'react';
import { cx } from '../../utils/cx';

export interface DashboardMainProps extends React.HTMLAttributes<HTMLElement> {
  label: string;
  focusable?: boolean;
}

export const DashboardMain = React.forwardRef<HTMLElement, DashboardMainProps>(function DashboardMain(
  { label, focusable = true, className, children, ...props },
  ref,
) {
  return (
    <main
      ref={ref}
      className={cx('atlas-dashboard-main', className)}
      data-atlas-component="DashboardMain"
      data-state="default"
      aria-label={label}
      tabIndex={focusable ? -1 : undefined}
      {...props}
    >
      {children}
    </main>
  );
});
