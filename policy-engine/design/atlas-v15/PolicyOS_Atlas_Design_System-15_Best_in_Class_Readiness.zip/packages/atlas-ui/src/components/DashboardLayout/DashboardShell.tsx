import * as React from 'react';
import { cx } from '../../utils/cx';

export interface DashboardShellProps extends React.HTMLAttributes<HTMLDivElement> {
  sidebar: React.ReactNode;
  topbar?: React.ReactNode;
  navOpen?: boolean;
  onDismissNavigation?: () => void;
  surfaceLabel?: string;
}

export const DashboardShell = React.forwardRef<HTMLDivElement, DashboardShellProps>(function DashboardShell(
  { sidebar, topbar, navOpen = false, onDismissNavigation, surfaceLabel = 'Atlas dashboard workspace', className, children, ...props },
  ref,
) {
  return (
    <div
      ref={ref}
      className={cx('atlas-dashboard-shell', className)}
      data-atlas-component="DashboardShell"
      data-state={navOpen ? 'drawer-open' : 'default'}
      {...props}
    >
      <div className="atlas-dashboard-frame">
        <div className="atlas-dashboard-surface" aria-label={surfaceLabel}>
          {topbar ? <div className="atlas-dashboard-topbar">{topbar}</div> : null}
          <div className="atlas-dashboard-layout" data-nav-open={navOpen ? 'true' : 'false'}>
            {sidebar}
            {onDismissNavigation ? (
              <button
                type="button"
                className="atlas-dashboard-drawer-backdrop"
                data-state={navOpen ? 'open' : 'closed'}
                aria-label="Close dashboard navigation"
                tabIndex={navOpen ? 0 : -1}
                onClick={onDismissNavigation}
              />
            ) : null}
            {children}
          </div>
        </div>
      </div>
    </div>
  );
});
