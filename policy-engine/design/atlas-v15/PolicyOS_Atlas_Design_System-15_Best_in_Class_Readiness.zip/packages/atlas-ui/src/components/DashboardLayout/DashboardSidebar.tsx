import * as React from 'react';
import { cx } from '../../utils/cx';

export interface DashboardNavItem {
  id: string;
  label: string;
  icon?: React.ReactNode;
  description?: string;
}

export interface DashboardSidebarProps extends React.HTMLAttributes<HTMLElement> {
  items: DashboardNavItem[];
  activeId: string;
  onNavigate: (id: string) => void;
  brand?: React.ReactNode;
  status?: React.ReactNode;
  footer?: React.ReactNode;
  open?: boolean;
  onClose?: () => void;
  closeLabel?: string;
  navigationLabel?: string;
}

export const DashboardSidebar = React.forwardRef<HTMLElement, DashboardSidebarProps>(function DashboardSidebar(
  {
    items,
    activeId,
    onNavigate,
    brand,
    status,
    footer,
    open = false,
    onClose,
    closeLabel = 'Close navigation',
    navigationLabel = 'Primary dashboard screens',
    className,
    ...props
  },
  ref,
) {
  return (
    <aside
      ref={ref}
      className={cx('atlas-dashboard-sidebar', className)}
      data-atlas-component="DashboardSidebar"
      data-state={open ? 'open' : 'closed'}
      aria-label={navigationLabel}
      {...props}
    >
      <div className="atlas-dashboard-sidebar-header">
        {brand ? <div className="atlas-dashboard-sidebar-brand">{brand}</div> : null}
        {onClose ? (
          <button type="button" className="atlas-dashboard-sidebar-close" aria-label={closeLabel} onClick={onClose}>
            <span aria-hidden="true">×</span>
          </button>
        ) : null}
      </div>
      <nav className="atlas-dashboard-sidebar-nav" aria-label={navigationLabel}>
        {items.map((item) => {
          const active = item.id === activeId;
          return (
            <button
              key={item.id}
              type="button"
              className="atlas-dashboard-sidebar-item"
              data-state={active ? 'current' : 'default'}
              aria-current={active ? 'page' : undefined}
              aria-label={`${item.label}${active ? ', current screen' : ''}`}
              title={item.label}
              onClick={() => onNavigate(item.id)}
            >
              {item.icon ? <span className="atlas-dashboard-sidebar-icon" aria-hidden="true">{item.icon}</span> : null}
              <span className="atlas-dashboard-sidebar-label">{item.label}</span>
              {item.description ? <span className="atlas-dashboard-sidebar-description">{item.description}</span> : null}
            </button>
          );
        })}
      </nav>
      {status ? <div className="atlas-dashboard-sidebar-status">{status}</div> : null}
      {footer ? <div className="atlas-dashboard-sidebar-footer">{footer}</div> : null}
    </aside>
  );
});
