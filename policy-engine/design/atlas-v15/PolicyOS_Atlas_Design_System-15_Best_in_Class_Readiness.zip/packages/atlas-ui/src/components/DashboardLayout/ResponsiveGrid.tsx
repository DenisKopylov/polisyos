import * as React from 'react';
import { cx } from '../../utils/cx';

export type ResponsiveGridDensity = 'default' | 'dense' | 'wide';

export interface ResponsiveGridProps extends React.HTMLAttributes<HTMLDivElement> {
  density?: ResponsiveGridDensity;
  minColumn?: string;
}

export const ResponsiveGrid = React.forwardRef<HTMLDivElement, ResponsiveGridProps>(function ResponsiveGrid(
  { density = 'default', minColumn, className, style, children, ...props },
  ref,
) {
  const customStyle = minColumn
    ? ({ ...style, '--atlas-responsive-grid-min': minColumn } as React.CSSProperties & Record<string, string>)
    : style;
  return (
    <div
      ref={ref}
      className={cx('atlas-responsive-grid', className)}
      data-atlas-component="ResponsiveGrid"
      data-state={density}
      data-density={density}
      style={customStyle}
      {...props}
    >
      {children}
    </div>
  );
});
