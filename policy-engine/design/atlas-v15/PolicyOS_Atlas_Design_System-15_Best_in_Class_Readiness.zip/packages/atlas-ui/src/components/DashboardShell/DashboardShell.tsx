import * as React from 'react';
import { cx } from '../../utils/cx';
import { useAtlasId } from '../../utils/ids';
import type { Density } from '../../types';

export interface DashboardShellProps extends React.HTMLAttributes<HTMLDivElement> {
  sidebar?: React.ReactNode;
  topBar?: React.ReactNode;
  mainId?: string;
  mainLabel?: string;
  sidebarId?: string;
  sidebarOpen?: boolean;
  onSidebarDismiss?: () => void;
  density?: Density;
}

export const DashboardShell = React.forwardRef<HTMLDivElement, DashboardShellProps>(function DashboardShell(
  {
    sidebar,
    topBar,
    mainId,
    mainLabel = 'Dashboard content',
    sidebarId,
    sidebarOpen = false,
    onSidebarDismiss,
    density,
    className,
    children,
    ...props
  },
  ref,
) {
  const resolvedMainId = useAtlasId(mainId, 'atlas-dashboard-main');
  const resolvedSidebarId = useAtlasId(sidebarId, 'atlas-dashboard-sidebar');
  const hasSidebar = Boolean(sidebar);
  return (
    <div
      ref={ref}
      className={cx('atlas-dashboard-shell', className)}
      data-atlas-component="DashboardShell"
      data-state={sidebarOpen ? 'nav-open' : 'nav-closed'}
      data-sidebar={hasSidebar ? 'present' : 'absent'}
      data-density={density}
      {...props}
    >
      {topBar ? <div className="atlas-dashboard-shell-topbar">{topBar}</div> : null}
      {hasSidebar ? (
        <div id={resolvedSidebarId} className="atlas-dashboard-shell-sidebar" data-state={sidebarOpen ? 'open' : 'closed'}>
          {sidebar}
        </div>
      ) : null}
      {hasSidebar ? (
        <button
          type="button"
          className="atlas-dashboard-shell-scrim"
          aria-label="Close dashboard navigation"
          aria-controls={resolvedSidebarId}
          aria-hidden={sidebarOpen ? undefined : 'true'}
          tabIndex={sidebarOpen ? 0 : -1}
          onClick={onSidebarDismiss}
        />
      ) : null}
      <main id={resolvedMainId} className="atlas-dashboard-shell-main" tabIndex={-1} aria-label={mainLabel} data-state="ready">
        {children}
      </main>
    </div>
  );
});
