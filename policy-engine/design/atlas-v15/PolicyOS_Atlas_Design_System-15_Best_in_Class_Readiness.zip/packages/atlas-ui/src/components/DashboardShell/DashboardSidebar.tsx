import * as React from 'react';
import { cx } from '../../utils/cx';

export interface DashboardSidebarItem {
  id: string;
  label: React.ReactNode;
  href?: string;
  icon?: React.ReactNode;
  badge?: React.ReactNode;
  disabled?: boolean;
}

export interface DashboardSidebarProps extends React.HTMLAttributes<HTMLElement> {
  label?: string;
  items?: DashboardSidebarItem[];
  activeId?: string;
  onNavigate?: (id: string) => void;
  header?: React.ReactNode;
  footer?: React.ReactNode;
  onClose?: () => void;
  closeLabel?: string;
}

export const DashboardSidebar = React.forwardRef<HTMLElement, DashboardSidebarProps>(function DashboardSidebar(
  {
    label = 'Dashboard navigation',
    items = [],
    activeId,
    onNavigate,
    header,
    footer,
    onClose,
    closeLabel = 'Close navigation',
    className,
    children,
    ...props
  },
  ref,
) {
  return (
    <aside ref={ref} className={cx('atlas-dashboard-sidebar', className)} aria-label={label} data-atlas-component="DashboardSidebar" data-state="default" {...props}>
      <div className="atlas-dashboard-sidebar-header">
        <div>{header}</div>
        {onClose ? <button type="button" className="atlas-dashboard-sidebar-close" aria-label={closeLabel} onClick={onClose}>Close</button> : null}
      </div>
      {items.length ? (
        <nav className="atlas-dashboard-sidebar-nav" aria-label={label}>
          {items.map((item) => {
            const active = item.id === activeId;
            const content = (
              <>
                {item.icon ? <span className="atlas-dashboard-sidebar-icon" aria-hidden="true">{item.icon}</span> : null}
                <span className="atlas-dashboard-sidebar-label">{item.label}</span>
                {item.badge ? <span className="atlas-dashboard-sidebar-badge">{item.badge}</span> : null}
              </>
            );
            if (item.href) {
              return (
                <a key={item.id} className="atlas-dashboard-sidebar-link" href={item.href} aria-current={active ? 'page' : undefined} data-state={active ? 'active' : 'default'}>
                  {content}
                </a>
              );
            }
            return (
              <button
                key={item.id}
                type="button"
                className="atlas-dashboard-sidebar-link"
                aria-current={active ? 'page' : undefined}
                data-state={active ? 'active' : 'default'}
                disabled={item.disabled}
                onClick={() => onNavigate?.(item.id)}
              >
                {content}
              </button>
            );
          })}
        </nav>
      ) : null}
      {children ? <div className="atlas-dashboard-sidebar-body">{children}</div> : null}
      {footer ? <footer className="atlas-dashboard-sidebar-footer">{footer}</footer> : null}
    </aside>
  );
});
