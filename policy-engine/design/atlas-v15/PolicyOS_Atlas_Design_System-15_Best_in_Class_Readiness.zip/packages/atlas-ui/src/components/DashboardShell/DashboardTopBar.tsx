import * as React from 'react';
import { cx } from '../../utils/cx';

export interface DashboardTopBarProps extends React.HTMLAttributes<HTMLElement> {
  title: React.ReactNode;
  subtitle?: React.ReactNode;
  actions?: React.ReactNode;
  menuButtonLabel?: string;
  menuControls?: string;
  menuOpen?: boolean;
  onMenuClick?: () => void;
}

export const DashboardTopBar = React.forwardRef<HTMLElement, DashboardTopBarProps>(function DashboardTopBar(
  {
    title,
    subtitle,
    actions,
    menuButtonLabel = 'Open navigation',
    menuControls,
    menuOpen = false,
    onMenuClick,
    className,
    ...props
  },
  ref,
) {
  return (
    <header ref={ref} className={cx('atlas-dashboard-topbar', className)} data-atlas-component="DashboardTopBar" data-state={menuOpen ? 'menu-open' : 'menu-closed'} {...props}>
      {onMenuClick ? (
        <button
          type="button"
          className="atlas-dashboard-menu-button"
          aria-label={menuButtonLabel}
          aria-controls={menuControls}
          aria-expanded={menuOpen}
          onClick={onMenuClick}
        >
          Menu
        </button>
      ) : null}
      <div className="atlas-dashboard-topbar-copy">
        <p className="atlas-dashboard-topbar-kicker">Atlas workspace</p>
        <h1 className="atlas-dashboard-topbar-title">{title}</h1>
        {subtitle ? <p className="atlas-dashboard-topbar-subtitle">{subtitle}</p> : null}
      </div>
      {actions ? <div className="atlas-dashboard-topbar-actions">{actions}</div> : null}
    </header>
  );
});
