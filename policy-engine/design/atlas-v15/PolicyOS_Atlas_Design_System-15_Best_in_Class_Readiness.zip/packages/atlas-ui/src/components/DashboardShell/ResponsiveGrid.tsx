import * as React from 'react';
import { cx } from '../../utils/cx';

export type ResponsiveGridMin = 'xs' | 'sm' | 'md' | 'lg';
export type ResponsiveGridGap = 'sm' | 'md' | 'lg';
export type ResponsiveGridColumns = 'auto' | 1 | 2 | 3 | 4;

export interface ResponsiveGridProps extends React.HTMLAttributes<HTMLDivElement> {
  minColumn?: ResponsiveGridMin;
  gap?: ResponsiveGridGap;
  columns?: ResponsiveGridColumns;
}

export const ResponsiveGrid = React.forwardRef<HTMLDivElement, ResponsiveGridProps>(function ResponsiveGrid(
  { minColumn = 'md', gap = 'md', columns = 'auto', className, style, children, ...props },
  ref,
) {
  const minVar = `var(--atlas-responsive-grid-min-${minColumn})`;
  const template = columns === 'auto' ? `repeat(auto-fit, minmax(min(100%, ${minVar}), 1fr))` : `repeat(${columns}, minmax(0, 1fr))`;
  const gridStyle: React.CSSProperties = { ...style, '--atlas-responsive-grid-template': template };
  return (
    <div
      ref={ref}
      className={cx('atlas-responsive-grid', className)}
      data-atlas-component="ResponsiveGrid"
      data-state={columns === 'auto' ? 'auto-fit' : 'fixed-columns'}
      data-gap={gap}
      data-min-column={minColumn}
      style={gridStyle}
      {...props}
    >
      {children}
    </div>
  );
});
