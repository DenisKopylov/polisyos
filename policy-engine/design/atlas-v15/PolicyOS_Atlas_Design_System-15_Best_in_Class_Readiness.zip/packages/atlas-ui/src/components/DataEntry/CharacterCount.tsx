import * as React from 'react';
import { cx } from '../../utils/cx';

export interface CharacterCountProps extends React.HTMLAttributes<HTMLParagraphElement> {
  value: string;
  maxLength: number;
  warningThreshold?: number;
  label?: (remaining: number, used: number, maxLength: number) => React.ReactNode;
}

export function CharacterCount({ value, maxLength, warningThreshold = 20, label, className, ...props }: CharacterCountProps) {
  const used = value.length;
  const remaining = maxLength - used;
  const state = remaining < 0 ? 'over-limit' : remaining <= warningThreshold ? 'warning' : 'default';
  const message = label ? label(remaining, used, maxLength) : remaining >= 0 ? `${remaining} characters remaining` : `${Math.abs(remaining)} characters over limit`;
  return (
    <p className={cx('atlas-character-count', className)} data-atlas-component="CharacterCount" data-state={state} aria-live="polite" {...props}>
      {message}
    </p>
  );
}
