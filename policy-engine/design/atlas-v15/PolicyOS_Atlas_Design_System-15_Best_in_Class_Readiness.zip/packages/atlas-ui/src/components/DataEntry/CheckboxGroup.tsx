import * as React from 'react';
import { cx } from '../../utils/cx';
import { joinIds, useAtlasId } from '../../utils/ids';
import type { RadioOption } from './RadioGroup';

export interface CheckboxGroupProps extends Omit<React.FieldsetHTMLAttributes<HTMLFieldSetElement>, 'onChange'> {
  legend: React.ReactNode;
  description?: React.ReactNode;
  error?: React.ReactNode;
  name?: string;
  options: RadioOption[];
  values?: string[];
  defaultValues?: string[];
  onValuesChange?: (values: string[]) => void;
  required?: boolean;
  layout?: 'stack' | 'inline' | 'grid';
}

export const CheckboxGroup = React.forwardRef<HTMLFieldSetElement, CheckboxGroupProps>(function CheckboxGroup(
  { legend, description, error, name, options, values, defaultValues = [], onValuesChange, required, layout = 'stack', id, className, disabled, ...props },
  ref,
) {
  const groupId = useAtlasId(id, 'atlas-checkbox-group');
  const groupName = name ?? groupId;
  const descriptionId = description ? `${groupId}-description` : undefined;
  const errorId = error ? `${groupId}-error` : undefined;
  const selected = values ?? defaultValues;
  function toggle(optionValue: string, checked: boolean) {
    const base = values ?? selected;
    const next = checked ? Array.from(new Set([...base, optionValue])) : base.filter((item) => item !== optionValue);
    onValuesChange?.(next);
  }
  return (
    <fieldset
      ref={ref}
      id={groupId}
      className={cx('atlas-choice-group', className)}
      data-atlas-component="CheckboxGroup"
      data-state={disabled ? 'disabled' : error ? 'invalid' : selected.length > 0 ? 'selected' : 'empty'}
      data-layout={layout}
      data-required={required || undefined}
      aria-describedby={joinIds(descriptionId, errorId)}
      disabled={disabled}
      {...props}
    >
      <legend className="atlas-field-group-legend">{legend}{required ? ' *' : null}</legend>
      {description ? <p id={descriptionId} className="atlas-field-description">{description}</p> : null}
      <div className="atlas-choice-list">
        {options.map((option) => {
          const optionId = `${groupId}-${option.value}`;
          const optionDescriptionId = option.description ? `${optionId}-description` : undefined;
          const checked = selected.includes(option.value);
          return (
            <label key={option.value} className="atlas-choice" htmlFor={optionId} data-state={checked ? 'checked' : 'unchecked'}>
              <input
                id={optionId}
                className="atlas-checkbox-control"
                type="checkbox"
                name={groupName}
                value={option.value}
                checked={values !== undefined ? checked : undefined}
                defaultChecked={values === undefined && defaultValues.includes(option.value) ? true : undefined}
                disabled={option.disabled}
                required={required && selected.length === 0 ? true : undefined}
                aria-invalid={Boolean(error) || undefined}
                aria-describedby={optionDescriptionId}
                onChange={(event) => toggle(option.value, Boolean((event.currentTarget as HTMLInputElement).checked))}
              />
              <span className="atlas-choice-copy">
                <span className="atlas-choice-label">{option.label}</span>
                {option.description ? <span id={optionDescriptionId} className="atlas-choice-description">{option.description}</span> : null}
              </span>
            </label>
          );
        })}
      </div>
      {error ? <p id={errorId} className="atlas-field-error">{error}</p> : null}
    </fieldset>
  );
});
