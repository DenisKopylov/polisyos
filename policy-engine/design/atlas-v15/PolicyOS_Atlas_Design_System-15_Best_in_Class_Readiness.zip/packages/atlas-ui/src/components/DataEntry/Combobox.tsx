import * as React from 'react';
import { cx } from '../../utils/cx';
import { joinIds, useAtlasId } from '../../utils/ids';

export interface ComboboxOption {
  label: string;
  value: string;
  description?: React.ReactNode;
  disabled?: boolean;
}

export interface ComboboxProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'onChange' | 'value' | 'defaultValue'> {
  label: React.ReactNode;
  description?: React.ReactNode;
  error?: React.ReactNode;
  options: ComboboxOption[];
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string, option?: ComboboxOption) => void;
  noResultsText?: React.ReactNode;
}

export const Combobox = React.forwardRef<HTMLInputElement, ComboboxProps>(function Combobox(
  { label, description, error, options, value, defaultValue = '', onValueChange, noResultsText = 'No matching options.', id, className, disabled, required, placeholder, ...props },
  ref,
) {
  const fieldId = useAtlasId(id, 'atlas-combobox');
  const listId = `${fieldId}-listbox`;
  const descriptionId = description ? `${fieldId}-description` : undefined;
  const errorId = error ? `${fieldId}-error` : undefined;
  const [query, setQuery] = React.useState(defaultValue);
  const [open, setOpen] = React.useState(false);
  const [activeIndex, setActiveIndex] = React.useState(0);
  const currentValue = value ?? query;
  const filtered = options.filter((option) => option.label.toLowerCase().includes(String(currentValue).toLowerCase()) || option.value.toLowerCase().includes(String(currentValue).toLowerCase()));
  const active = filtered[activeIndex];
  function commit(option: ComboboxOption | undefined) {
    if (!option || option.disabled) return;
    if (value === undefined) setQuery(option.label);
    onValueChange?.(option.value, option);
    setOpen(false);
  }
  function handleInput(next: string) {
    if (value === undefined) setQuery(next);
    onValueChange?.(next);
    setOpen(true);
    setActiveIndex(0);
  }
  function handleKeyDown(event: React.KeyboardEvent<HTMLInputElement>) {
    if (event.key === 'ArrowDown') {
      event.preventDefault();
      setOpen(true);
      setActiveIndex((index) => Math.min(index + 1, Math.max(filtered.length - 1, 0)));
    } else if (event.key === 'ArrowUp') {
      event.preventDefault();
      setActiveIndex((index) => Math.max(index - 1, 0));
    } else if (event.key === 'Enter' && open) {
      event.preventDefault();
      commit(active);
    } else if (event.key === 'Escape') {
      setOpen(false);
    }
  }
  return (
    <div className={cx('atlas-field atlas-combobox-field', className)} data-atlas-component="Combobox" data-state={disabled ? 'disabled' : error ? 'invalid' : open ? 'open' : currentValue ? 'filled' : 'empty'} data-required={required || undefined}>
      <label className="atlas-field-label" htmlFor={fieldId}>{label}{required ? ' *' : null}</label>
      {description ? <p id={descriptionId} className="atlas-field-description">{description}</p> : null}
      <div className="atlas-combobox-shell">
        <input
          ref={ref}
          id={fieldId}
          className="atlas-field-control atlas-combobox-control"
          type="text"
          role="combobox"
          disabled={disabled}
          required={required}
          value={currentValue}
          placeholder={placeholder}
          aria-autocomplete="list"
          aria-controls={listId}
          aria-expanded={open}
          aria-activedescendant={open && active ? `${fieldId}-option-${active.value}` : undefined}
          aria-required={required || undefined}
          aria-invalid={Boolean(error) || undefined}
          aria-describedby={joinIds(descriptionId, errorId)}
          onFocus={() => setOpen(true)}
          onChange={(event) => handleInput(String((event.currentTarget as HTMLInputElement).value))}
          onKeyDown={handleKeyDown}
          {...props}
        />
        <button className="atlas-input-action" type="button" disabled={disabled} aria-label={open ? 'Close options' : 'Open options'} aria-controls={listId} aria-expanded={open} onClick={() => setOpen((next) => !next)}>⌄</button>
      </div>
      {open ? (
        <div id={listId} className="atlas-combobox-listbox" role="listbox" aria-label={`${String(label)} options`}>
          {filtered.length > 0 ? filtered.map((option, index) => (
            <div
              key={option.value}
              id={`${fieldId}-option-${option.value}`}
              className="atlas-combobox-option"
              role="option"
              aria-selected={index === activeIndex}
              aria-disabled={option.disabled || undefined}
              data-state={index === activeIndex ? 'active' : 'default'}
              onClick={() => commit(option)}
            >
              <span className="atlas-combobox-option-label">{option.label}</span>
              {option.description ? <span className="atlas-combobox-option-description">{option.description}</span> : null}
            </div>
          )) : <div className="atlas-combobox-empty" role="status">{noResultsText}</div>}
        </div>
      ) : null}
      {error ? <p id={errorId} className="atlas-field-error">{error}</p> : null}
    </div>
  );
});
