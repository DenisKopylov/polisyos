import * as React from 'react';
import { cx } from '../../utils/cx';
import { joinIds, useAtlasId } from '../../utils/ids';

export interface DateFieldProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: React.ReactNode;
  description?: React.ReactNode;
  error?: React.ReactNode;
  formatHint?: React.ReactNode;
}

export const DateField = React.forwardRef<HTMLInputElement, DateFieldProps>(function DateField(
  { label, description, error, formatHint = 'Use YYYY-MM-DD.', id, className, disabled, readOnly, required, value, defaultValue, autoComplete, ...props },
  ref,
) {
  const fieldId = useAtlasId(id, 'atlas-date');
  const descriptionId = description ? `${fieldId}-description` : undefined;
  const hintId = formatHint ? `${fieldId}-format` : undefined;
  const errorId = error ? `${fieldId}-error` : undefined;
  return (
    <div className={cx('atlas-field atlas-date-field', className)} data-atlas-component="DateField" data-state={disabled ? 'disabled' : error ? 'invalid' : value !== undefined || defaultValue !== undefined ? 'filled' : 'empty'} data-required={required || undefined}>
      <label className="atlas-field-label" htmlFor={fieldId}>{label}{required ? ' *' : null}</label>
      {description ? <p id={descriptionId} className="atlas-field-description">{description}</p> : null}
      {formatHint ? <p id={hintId} className="atlas-field-description">{formatHint}</p> : null}
      <input
        ref={ref}
        id={fieldId}
        className="atlas-field-control"
        type="date"
        required={required}
        disabled={disabled}
        readOnly={readOnly}
        value={value}
        defaultValue={defaultValue}
        autoComplete={autoComplete}
        aria-required={required || undefined}
        aria-invalid={Boolean(error) || undefined}
        aria-describedby={joinIds(descriptionId, hintId, errorId)}
        {...props}
      />
      {error ? <p id={errorId} className="atlas-field-error">{error}</p> : null}
    </div>
  );
});
