import * as React from 'react';
import { cx } from '../../utils/cx';
import { joinIds, useAtlasId } from '../../utils/ids';

export interface DateRangeFieldProps extends React.FieldsetHTMLAttributes<HTMLFieldSetElement> {
  legend: React.ReactNode;
  description?: React.ReactNode;
  error?: React.ReactNode;
  startLabel?: React.ReactNode;
  endLabel?: React.ReactNode;
  startName?: string;
  endName?: string;
  startValue?: string;
  endValue?: string;
  defaultStartValue?: string;
  defaultEndValue?: string;
  onStartChange?: (value: string) => void;
  onEndChange?: (value: string) => void;
  required?: boolean;
}

export const DateRangeField = React.forwardRef<HTMLFieldSetElement, DateRangeFieldProps>(function DateRangeField(
  { legend, description, error, startLabel = 'Start date', endLabel = 'End date', startName, endName, startValue, endValue, defaultStartValue, defaultEndValue, onStartChange, onEndChange, required, id, className, disabled, ...props },
  ref,
) {
  const groupId = useAtlasId(id, 'atlas-date-range');
  const descriptionId = description ? `${groupId}-description` : undefined;
  const errorId = error ? `${groupId}-error` : undefined;
  const hasValue = Boolean(startValue ?? defaultStartValue) || Boolean(endValue ?? defaultEndValue);
  return (
    <fieldset
      ref={ref}
      id={groupId}
      className={cx('atlas-date-range-field', className)}
      data-atlas-component="DateRangeField"
      data-state={disabled ? 'disabled' : error ? 'invalid' : hasValue ? 'filled' : 'empty'}
      data-required={required || undefined}
      aria-describedby={joinIds(descriptionId, errorId)}
      disabled={disabled}
      {...props}
    >
      <legend className="atlas-field-group-legend">{legend}{required ? ' *' : null}</legend>
      {description ? <p id={descriptionId} className="atlas-field-description">{description}</p> : null}
      <div className="atlas-date-range-grid">
        <label className="atlas-field" htmlFor={`${groupId}-start`}>
          <span className="atlas-field-label">{startLabel}</span>
          <input
            id={`${groupId}-start`}
            className="atlas-field-control"
            type="date"
            name={startName}
            value={startValue}
            defaultValue={defaultStartValue}
            required={required}
            aria-invalid={Boolean(error) || undefined}
            aria-describedby={joinIds(descriptionId, errorId)}
            onChange={(event) => onStartChange?.((event.currentTarget as HTMLInputElement).value)}
          />
        </label>
        <label className="atlas-field" htmlFor={`${groupId}-end`}>
          <span className="atlas-field-label">{endLabel}</span>
          <input
            id={`${groupId}-end`}
            className="atlas-field-control"
            type="date"
            name={endName}
            value={endValue}
            defaultValue={defaultEndValue}
            required={required}
            aria-invalid={Boolean(error) || undefined}
            aria-describedby={joinIds(descriptionId, errorId)}
            onChange={(event) => onEndChange?.((event.currentTarget as HTMLInputElement).value)}
          />
        </label>
      </div>
      {error ? <p id={errorId} className="atlas-field-error">{error}</p> : null}
    </fieldset>
  );
});
