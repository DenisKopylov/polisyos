import * as React from 'react';
import { cx } from '../../utils/cx';
import { joinIds, useAtlasId } from '../../utils/ids';

export interface FileUploadProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: React.ReactNode;
  description?: React.ReactNode;
  error?: React.ReactNode;
  dropInstruction?: React.ReactNode;
}

export const FileUpload = React.forwardRef<HTMLInputElement, FileUploadProps>(function FileUpload(
  { label, description, error, dropInstruction = 'Choose a file or drag it here when supported by your browser.', id, className, disabled, required, accept, multiple, ...props },
  ref,
) {
  const fieldId = useAtlasId(id, 'atlas-file');
  const descriptionId = description ? `${fieldId}-description` : undefined;
  const instructionId = dropInstruction ? `${fieldId}-instruction` : undefined;
  const errorId = error ? `${fieldId}-error` : undefined;
  return (
    <div className={cx('atlas-field atlas-file-upload', className)} data-atlas-component="FileUpload" data-state={disabled ? 'disabled' : error ? 'invalid' : 'empty'} data-required={required || undefined}>
      <label className="atlas-field-label" htmlFor={fieldId}>{label}{required ? ' *' : null}</label>
      {description ? <p id={descriptionId} className="atlas-field-description">{description}</p> : null}
      <div className="atlas-file-dropzone">
        <input
          ref={ref}
          id={fieldId}
          className="atlas-file-control"
          type="file"
          required={required}
          disabled={disabled}
          accept={accept}
          multiple={multiple}
          aria-required={required || undefined}
          aria-invalid={Boolean(error) || undefined}
          aria-describedby={joinIds(descriptionId, instructionId, errorId)}
          {...props}
        />
        {dropInstruction ? <p id={instructionId} className="atlas-file-instruction">{dropInstruction}</p> : null}
      </div>
      {error ? <p id={errorId} className="atlas-field-error">{error}</p> : null}
    </div>
  );
});
