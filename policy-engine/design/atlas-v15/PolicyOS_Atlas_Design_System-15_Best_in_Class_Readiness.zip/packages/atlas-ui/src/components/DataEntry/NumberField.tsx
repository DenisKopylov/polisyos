import * as React from 'react';
import { cx } from '../../utils/cx';
import { joinIds, useAtlasId } from '../../utils/ids';

export interface NumberFieldProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: React.ReactNode;
  description?: React.ReactNode;
  error?: React.ReactNode;
  prefix?: React.ReactNode;
  suffix?: React.ReactNode;
  incrementLabel?: string;
  decrementLabel?: string;
  showSteppers?: boolean;
}

export const NumberField = React.forwardRef<HTMLInputElement, NumberFieldProps>(function NumberField(
  { label, description, error, prefix, suffix, incrementLabel = 'Increase value', decrementLabel = 'Decrease value', showSteppers = true, id, className, disabled, readOnly, required, value, defaultValue, ...props },
  ref,
) {
  const localRef = React.useRef<HTMLInputElement | null>(null);
  const fieldId = useAtlasId(id, 'atlas-number');
  const descriptionId = description ? `${fieldId}-description` : undefined;
  const errorId = error ? `${fieldId}-error` : undefined;
  function setInputRef(node: HTMLInputElement | null) {
    localRef.current = node;
    if (typeof ref === 'function') ref(node);
    else if (ref) ref.current = node;
  }
  function step(direction: 1 | -1) {
    const input = localRef.current;
    if (!input) return;
    if (direction > 0) input.stepUp(); else input.stepDown();
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }
  return (
    <div className={cx('atlas-field atlas-number-field', className)} data-atlas-component="NumberField" data-state={disabled ? 'disabled' : error ? 'invalid' : readOnly ? 'readonly' : value !== undefined || defaultValue !== undefined ? 'filled' : 'empty'} data-required={required || undefined}>
      <label className="atlas-field-label" htmlFor={fieldId}>{label}{required ? ' *' : null}</label>
      {description ? <p id={descriptionId} className="atlas-field-description">{description}</p> : null}
      <div className="atlas-input-shell" data-adornment={prefix || suffix || showSteppers ? 'mixed' : 'none'}>
        {prefix ? <span className="atlas-input-prefix">{prefix}</span> : null}
        <input
          ref={setInputRef}
          id={fieldId}
          className="atlas-field-control atlas-input-shell-control"
          type="number"
          required={required}
          disabled={disabled}
          readOnly={readOnly}
          value={value}
          defaultValue={defaultValue}
          aria-required={required || undefined}
          aria-invalid={Boolean(error) || undefined}
          aria-describedby={joinIds(descriptionId, errorId)}
          {...props}
        />
        {suffix ? <span className="atlas-input-suffix">{suffix}</span> : null}
        {showSteppers ? <button className="atlas-input-action" type="button" disabled={disabled || readOnly} aria-label={decrementLabel} onClick={() => step(-1)}>−</button> : null}
        {showSteppers ? <button className="atlas-input-action" type="button" disabled={disabled || readOnly} aria-label={incrementLabel} onClick={() => step(1)}>+</button> : null}
      </div>
      {error ? <p id={errorId} className="atlas-field-error">{error}</p> : null}
    </div>
  );
});
