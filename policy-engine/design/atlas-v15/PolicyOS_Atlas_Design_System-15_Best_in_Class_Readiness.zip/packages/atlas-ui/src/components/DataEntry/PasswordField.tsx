import * as React from 'react';
import { cx } from '../../utils/cx';
import { joinIds, useAtlasId } from '../../utils/ids';

export interface PasswordFieldProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: React.ReactNode;
  description?: React.ReactNode;
  error?: React.ReactNode;
  revealLabel?: string;
  concealLabel?: string;
}

export const PasswordField = React.forwardRef<HTMLInputElement, PasswordFieldProps>(function PasswordField(
  { label, description, error, revealLabel = 'Show password', concealLabel = 'Hide password', id, className, disabled, required, value, defaultValue, autoComplete = 'current-password', ...props },
  ref,
) {
  const [revealed, setRevealed] = React.useState(false);
  const fieldId = useAtlasId(id, 'atlas-password');
  const descriptionId = description ? `${fieldId}-description` : undefined;
  const errorId = error ? `${fieldId}-error` : undefined;
  return (
    <div className={cx('atlas-field atlas-password-field', className)} data-atlas-component="PasswordField" data-state={disabled ? 'disabled' : error ? 'invalid' : revealed ? 'revealed' : 'concealed'} data-required={required || undefined}>
      <label className="atlas-field-label" htmlFor={fieldId}>{label}{required ? ' *' : null}</label>
      {description ? <p id={descriptionId} className="atlas-field-description">{description}</p> : null}
      <div className="atlas-input-shell" data-adornment="action">
        <input
          ref={ref}
          id={fieldId}
          className="atlas-field-control atlas-input-shell-control"
          type={revealed ? 'text' : 'password'}
          required={required}
          disabled={disabled}
          value={value}
          defaultValue={defaultValue}
          autoComplete={autoComplete}
          aria-required={required || undefined}
          aria-invalid={Boolean(error) || undefined}
          aria-describedby={joinIds(descriptionId, errorId)}
          {...props}
        />
        <button className="atlas-input-action" type="button" disabled={disabled} aria-pressed={revealed} aria-label={revealed ? concealLabel : revealLabel} onClick={() => setRevealed((next) => !next)}>{revealed ? 'Hide' : 'Show'}</button>
      </div>
      {error ? <p id={errorId} className="atlas-field-error">{error}</p> : null}
    </div>
  );
});
