import * as React from 'react';
import { cx } from '../../utils/cx';
import { joinIds, useAtlasId } from '../../utils/ids';

export interface RadioOption {
  label: React.ReactNode;
  value: string;
  description?: React.ReactNode;
  disabled?: boolean;
}

export interface RadioGroupProps extends Omit<React.FieldsetHTMLAttributes<HTMLFieldSetElement>, 'onChange'> {
  legend: React.ReactNode;
  description?: React.ReactNode;
  error?: React.ReactNode;
  name?: string;
  options: RadioOption[];
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
  required?: boolean;
  layout?: 'stack' | 'inline' | 'grid';
}

export const RadioGroup = React.forwardRef<HTMLFieldSetElement, RadioGroupProps>(function RadioGroup(
  { legend, description, error, name, options, value, defaultValue, onValueChange, required, layout = 'stack', id, className, disabled, ...props },
  ref,
) {
  const groupId = useAtlasId(id, 'atlas-radio-group');
  const groupName = name ?? groupId;
  const descriptionId = description ? `${groupId}-description` : undefined;
  const errorId = error ? `${groupId}-error` : undefined;
  const selected = value ?? defaultValue;
  return (
    <fieldset
      ref={ref}
      id={groupId}
      className={cx('atlas-choice-group', className)}
      data-atlas-component="RadioGroup"
      data-state={disabled ? 'disabled' : error ? 'invalid' : selected ? 'selected' : 'empty'}
      data-layout={layout}
      data-required={required || undefined}
      aria-describedby={joinIds(descriptionId, errorId)}
      disabled={disabled}
      {...props}
    >
      <legend className="atlas-field-group-legend">{legend}{required ? ' *' : null}</legend>
      {description ? <p id={descriptionId} className="atlas-field-description">{description}</p> : null}
      <div className="atlas-choice-list">
        {options.map((option) => {
          const optionId = `${groupId}-${option.value}`;
          const optionDescriptionId = option.description ? `${optionId}-description` : undefined;
          return (
            <label key={option.value} className="atlas-choice" htmlFor={optionId} data-state={selected === option.value ? 'checked' : 'unchecked'}>
              <input
                id={optionId}
                className="atlas-radio-control"
                type="radio"
                name={groupName}
                value={option.value}
                checked={value !== undefined ? value === option.value : undefined}
                defaultChecked={value === undefined && defaultValue === option.value ? true : undefined}
                disabled={option.disabled}
                required={required}
                aria-invalid={Boolean(error) || undefined}
                aria-describedby={optionDescriptionId}
                onChange={() => onValueChange?.(option.value)}
              />
              <span className="atlas-choice-copy">
                <span className="atlas-choice-label">{option.label}</span>
                {option.description ? <span id={optionDescriptionId} className="atlas-choice-description">{option.description}</span> : null}
              </span>
            </label>
          );
        })}
      </div>
      {error ? <p id={errorId} className="atlas-field-error">{error}</p> : null}
    </fieldset>
  );
});
