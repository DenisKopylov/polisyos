import * as React from 'react';
import { cx } from '../../utils/cx';
import { joinIds, useAtlasId } from '../../utils/ids';

export interface RangeFieldProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: React.ReactNode;
  description?: React.ReactNode;
  error?: React.ReactNode;
  minLabel?: React.ReactNode;
  maxLabel?: React.ReactNode;
  output?: React.ReactNode;
}

export const RangeField = React.forwardRef<HTMLInputElement, RangeFieldProps>(function RangeField(
  { label, description, error, minLabel, maxLabel, output, id, className, disabled, required, value, defaultValue, min, max, ...props },
  ref,
) {
  const fieldId = useAtlasId(id, 'atlas-range');
  const descriptionId = description ? `${fieldId}-description` : undefined;
  const errorId = error ? `${fieldId}-error` : undefined;
  const outputId = output ? `${fieldId}-output` : undefined;
  return (
    <div className={cx('atlas-field atlas-range-field', className)} data-atlas-component="RangeField" data-state={disabled ? 'disabled' : error ? 'invalid' : 'default'} data-required={required || undefined}>
      <div className="atlas-range-header">
        <label className="atlas-field-label" htmlFor={fieldId}>{label}{required ? ' *' : null}</label>
        {output ? <output id={outputId} className="atlas-range-output" htmlFor={fieldId}>{output}</output> : null}
      </div>
      {description ? <p id={descriptionId} className="atlas-field-description">{description}</p> : null}
      <input
        ref={ref}
        id={fieldId}
        className="atlas-range-control"
        type="range"
        min={min}
        max={max}
        required={required}
        disabled={disabled}
        value={value}
        defaultValue={defaultValue}
        aria-required={required || undefined}
        aria-invalid={Boolean(error) || undefined}
        aria-describedby={joinIds(descriptionId, outputId, errorId)}
        {...props}
      />
      {minLabel || maxLabel ? <div className="atlas-range-scale"><span>{minLabel ?? min}</span><span>{maxLabel ?? max}</span></div> : null}
      {error ? <p id={errorId} className="atlas-field-error">{error}</p> : null}
    </div>
  );
});
