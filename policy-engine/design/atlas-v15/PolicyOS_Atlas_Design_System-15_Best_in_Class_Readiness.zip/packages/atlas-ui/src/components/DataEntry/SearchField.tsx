import * as React from 'react';
import { cx } from '../../utils/cx';
import { joinIds, useAtlasId } from '../../utils/ids';

export interface SearchFieldProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: React.ReactNode;
  description?: React.ReactNode;
  error?: React.ReactNode;
  clearLabel?: string;
  submitLabel?: string;
  onClear?: () => void;
}

export const SearchField = React.forwardRef<HTMLInputElement, SearchFieldProps>(function SearchField(
  { label, description, error, clearLabel = 'Clear search', submitLabel = 'Search', onClear, id, className, disabled, value, defaultValue, required, ...props },
  ref,
) {
  const fieldId = useAtlasId(id, 'atlas-search');
  const descriptionId = description ? `${fieldId}-description` : undefined;
  const errorId = error ? `${fieldId}-error` : undefined;
  const filled = value !== undefined || defaultValue !== undefined;
  return (
    <div className={cx('atlas-field atlas-search-field', className)} data-atlas-component="SearchField" data-state={disabled ? 'disabled' : error ? 'invalid' : filled ? 'filled' : 'empty'} data-required={required || undefined}>
      <label className="atlas-field-label" htmlFor={fieldId}>{label}{required ? ' *' : null}</label>
      {description ? <p id={descriptionId} className="atlas-field-description">{description}</p> : null}
      <div className="atlas-input-shell" data-adornment="both">
        <span className="atlas-input-prefix" aria-hidden="true">⌕</span>
        <input
          ref={ref}
          id={fieldId}
          className="atlas-field-control atlas-input-shell-control"
          type="search"
          required={required}
          disabled={disabled}
          value={value}
          defaultValue={defaultValue}
          aria-required={required || undefined}
          aria-invalid={Boolean(error) || undefined}
          aria-describedby={joinIds(descriptionId, errorId)}
          {...props}
        />
        {onClear ? <button className="atlas-input-action" type="button" onClick={onClear} disabled={disabled} aria-label={clearLabel}>×</button> : null}
        <button className="atlas-input-action" type="submit" disabled={disabled} aria-label={submitLabel}>↵</button>
      </div>
      {error ? <p id={errorId} className="atlas-field-error">{error}</p> : null}
    </div>
  );
});
