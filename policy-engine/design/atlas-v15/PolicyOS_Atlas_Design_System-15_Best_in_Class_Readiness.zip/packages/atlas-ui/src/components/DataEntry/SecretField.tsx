import * as React from 'react';
import { cx } from '../../utils/cx';
import { joinIds, useAtlasId } from '../../utils/ids';

export interface SecretFieldProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: React.ReactNode;
  description?: React.ReactNode;
  error?: React.ReactNode;
  revealLabel?: string;
  concealLabel?: string;
  copyLabel?: string;
  onCopySecret?: () => void;
}

export const SecretField = React.forwardRef<HTMLInputElement, SecretFieldProps>(function SecretField(
  { label, description, error, revealLabel = 'Reveal secret', concealLabel = 'Conceal secret', copyLabel = 'Copy secret', onCopySecret, id, className, disabled, readOnly = true, required, value, defaultValue, autoComplete = 'off', ...props },
  ref,
) {
  const [revealed, setRevealed] = React.useState(false);
  const fieldId = useAtlasId(id, 'atlas-secret');
  const descriptionId = description ? `${fieldId}-description` : undefined;
  const errorId = error ? `${fieldId}-error` : undefined;
  return (
    <div className={cx('atlas-field atlas-secret-field', className)} data-atlas-component="SecretField" data-state={disabled ? 'disabled' : error ? 'invalid' : revealed ? 'revealed' : 'redacted'} data-required={required || undefined}>
      <label className="atlas-field-label" htmlFor={fieldId}>{label}{required ? ' *' : null}</label>
      {description ? <p id={descriptionId} className="atlas-field-description">{description}</p> : null}
      <div className="atlas-input-shell" data-adornment="actions">
        <input
          ref={ref}
          id={fieldId}
          className="atlas-field-control atlas-input-shell-control atlas-secret-control"
          type={revealed ? 'text' : 'password'}
          required={required}
          disabled={disabled}
          readOnly={readOnly}
          value={value}
          defaultValue={defaultValue}
          autoComplete={autoComplete}
          spellCheck={false}
          aria-required={required || undefined}
          aria-invalid={Boolean(error) || undefined}
          aria-describedby={joinIds(descriptionId, errorId)}
          {...props}
        />
        <button className="atlas-input-action" type="button" disabled={disabled} aria-pressed={revealed} aria-label={revealed ? concealLabel : revealLabel} onClick={() => setRevealed((next) => !next)}>{revealed ? 'Conceal' : 'Reveal'}</button>
        {onCopySecret ? <button className="atlas-input-action" type="button" disabled={disabled} aria-label={copyLabel} onClick={onCopySecret}>Copy</button> : null}
      </div>
      {error ? <p id={errorId} className="atlas-field-error">{error}</p> : null}
    </div>
  );
});
