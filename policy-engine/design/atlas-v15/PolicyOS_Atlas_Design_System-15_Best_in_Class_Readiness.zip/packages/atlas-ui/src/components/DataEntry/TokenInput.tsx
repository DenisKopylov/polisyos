import * as React from 'react';
import { cx } from '../../utils/cx';
import { joinIds, useAtlasId } from '../../utils/ids';

export interface TokenInputToken {
  id: string;
  label: React.ReactNode;
  disabled?: boolean;
}

export interface TokenInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: React.ReactNode;
  description?: React.ReactNode;
  error?: React.ReactNode;
  tokens?: TokenInputToken[];
  removeLabel?: (token: TokenInputToken) => string;
  onRemoveToken?: (token: TokenInputToken) => void;
}

export const TokenInput = React.forwardRef<HTMLInputElement, TokenInputProps>(function TokenInput(
  { label, description, error, tokens = [], removeLabel = (token) => `Remove ${String(token.label)}`, onRemoveToken, id, className, disabled, required, placeholder, ...props },
  ref,
) {
  const fieldId = useAtlasId(id, 'atlas-token-input');
  const descriptionId = description ? `${fieldId}-description` : undefined;
  const errorId = error ? `${fieldId}-error` : undefined;
  return (
    <div className={cx('atlas-field atlas-token-input-field', className)} data-atlas-component="TokenInput" data-state={disabled ? 'disabled' : error ? 'invalid' : tokens.length > 0 ? 'filled' : 'empty'} data-required={required || undefined}>
      <label className="atlas-field-label" htmlFor={fieldId}>{label}{required ? ' *' : null}</label>
      {description ? <p id={descriptionId} className="atlas-field-description">{description}</p> : null}
      <div className="atlas-token-input-shell" data-disabled={disabled || undefined}>
        {tokens.length > 0 ? (
          <ul className="atlas-token-list" aria-label="Selected values">
            {tokens.map((token) => (
              <li key={token.id} className="atlas-token" data-disabled={token.disabled || undefined}>
                <span>{token.label}</span>
                {onRemoveToken && !token.disabled ? <button type="button" className="atlas-token-remove" aria-label={removeLabel(token)} onClick={() => onRemoveToken(token)}>×</button> : null}
              </li>
            ))}
          </ul>
        ) : null}
        <input
          ref={ref}
          id={fieldId}
          className="atlas-token-input-control"
          type="text"
          disabled={disabled}
          required={required && tokens.length === 0 ? true : undefined}
          placeholder={placeholder}
          aria-required={required || undefined}
          aria-invalid={Boolean(error) || undefined}
          aria-describedby={joinIds(descriptionId, errorId)}
          {...props}
        />
      </div>
      {error ? <p id={errorId} className="atlas-field-error">{error}</p> : null}
    </div>
  );
});
