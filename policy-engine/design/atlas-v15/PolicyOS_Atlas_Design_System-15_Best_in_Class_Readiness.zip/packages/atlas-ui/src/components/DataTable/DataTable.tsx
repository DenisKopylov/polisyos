import type * as React from 'react';
import { cx } from '../../utils/cx';

export interface DataTableColumn<Row> {
  key: string;
  header: React.ReactNode;
  cell: (row: Row) => React.ReactNode;
  align?: 'start' | 'end';
  mobileLabel?: string;
  priority?: 'primary' | 'secondary' | 'tertiary';
}

export interface DataTableProps<Row> extends React.HTMLAttributes<HTMLDivElement> {
  caption: string;
  columns: Array<DataTableColumn<Row>>;
  rows: Row[];
  getRowKey: (row: Row, index: number) => string;
  emptyMessage?: React.ReactNode;
  responsiveMode?: 'scroll' | 'cards';
  density?: 'comfortable' | 'compact' | 'condensed';
}

function labelFor<Row>(column: DataTableColumn<Row>): string | undefined {
  if (column.mobileLabel) return column.mobileLabel;
  return typeof column.header === 'string' ? column.header : undefined;
}

export function DataTable<Row>({
  caption,
  columns,
  rows,
  getRowKey,
  emptyMessage = 'No rows',
  responsiveMode = 'scroll',
  density = 'comfortable',
  className,
  ...props
}: DataTableProps<Row>) {
  const hasRows = rows.length > 0;
  return (
    <div
      className={cx('atlas-data-table-wrap', className)}
      data-atlas-component="DataTable"
      data-state={hasRows ? 'with-rows' : 'empty'}
      data-responsive-mode={responsiveMode}
      data-density={density}
      tabIndex={0}
      role="region"
      aria-label={caption}
      {...props}
    >
      <table className="atlas-data-table">
        <caption>{caption}</caption>
        <thead>
          <tr>
            {columns.map((column) => (
              <th key={column.key} scope="col" data-align={column.align} data-priority={column.priority}>{column.header}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {!hasRows ? (
            <tr data-state="empty"><td colSpan={columns.length}>{emptyMessage}</td></tr>
          ) : rows.map((row, index) => (
            <tr key={getRowKey(row, index)} data-state="row">
              {columns.map((column) => (
                <td
                  key={column.key}
                  data-align={column.align}
                  data-label={labelFor(column)}
                  data-priority={column.priority}
                >
                  {column.cell(row)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
