
import type * as React from 'react';
import { useAtlasId } from '../../utils/ids';
import { cx } from '../../utils/cx';
import { extent, scale } from './chartUtils';
import type { ChartPoint } from './types';
export type BarChartDatum = ChartPoint;

export interface BarChartProps extends React.HTMLAttributes<HTMLDivElement> {
  title: string;
  summary: string;
  data: ChartPoint[];
  width?: number;
  height?: number;
  xLabel?: string;
  yLabel?: string;
}

export function BarChart({ title, summary, data, width = 720, height = 360, xLabel, yLabel, className, id, ...props }: BarChartProps) {
  const rootId = useAtlasId(id, 'atlas-bar-chart');
  const titleId = `${rootId}-title`;
  const descId = `${rootId}-desc`;
  const padding = { left: 56, right: 24, top: 24, bottom: 58 };
  const domain = extent(data.map((point) => point.value).concat(0), 0, 1);
  const plotWidth = width - padding.left - padding.right;
  const plotHeight = height - padding.top - padding.bottom;
  const slot = plotWidth / Math.max(data.length, 1);
  const barWidth = Math.max(slot * 0.58, 8);
  return (
    <div className={cx('atlas-bar-chart', className)} data-atlas-component="BarChart" data-state={data.length ? 'with-data' : 'empty'} {...props}>
      <svg className="atlas-chart-svg" viewBox={`0 0 ${width} ${height}`} role="img" aria-labelledby={`${titleId} ${descId}`} focusable="false">
        <title id={titleId}>{title}</title>
        <desc id={descId}>{summary}</desc>
        <line className="atlas-chart-grid-line" x1={padding.left} y1={padding.top} x2={padding.left} y2={padding.top + plotHeight} />
        <line className="atlas-chart-grid-line" x1={padding.left} y1={padding.top + plotHeight} x2={width - padding.right} y2={padding.top + plotHeight} />
        {yLabel ? <text className="atlas-chart-axis-label" x={padding.left} y={14}>{yLabel}</text> : null}
        {xLabel ? <text className="atlas-chart-axis-label" x={width - padding.right} y={height - 10} textAnchor="end">{xLabel}</text> : null}
        {data.map((point, index) => {
          const barHeight = Math.abs(scale(point.value, domain, [0, plotHeight]) - scale(0, domain, [0, plotHeight]));
          const x = padding.left + slot * index + (slot - barWidth) / 2;
          const y = padding.top + plotHeight - barHeight;
          return (
            <g key={point.label} className="atlas-bar-chart__bar-group" aria-label={`${point.label}: ${point.value}`}>
              <rect className="atlas-chart-bar" data-series-index={index % 6} x={x} y={y} width={barWidth} height={barHeight} rx="8" />
              <text className="atlas-chart-axis-label atlas-chart-axis-label--category" x={x + barWidth / 2} y={height - 30} textAnchor="middle">{point.label}</text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}
