
import type * as React from 'react';
import { useAtlasId } from '../../utils/ids';
import { cx } from '../../utils/cx';
import type { CausalGraphEdge, CausalGraphNode } from './types';

export interface CausalGraphProps extends React.HTMLAttributes<HTMLDivElement> {
  title: string;
  summary: string;
  nodes: CausalGraphNode[];
  edges: CausalGraphEdge[];
  width?: number;
  height?: number;
}

export function CausalGraph({ title, summary, nodes, edges, width = 720, height = 380, className, id, ...props }: CausalGraphProps) {
  const rootId = useAtlasId(id, 'atlas-causal-graph');
  const titleId = `${rootId}-title`;
  const descId = `${rootId}-desc`;
  const byId = new Map(nodes.map((node) => [node.id, node]));
  return (
    <div className={cx('atlas-causal-graph', className)} data-atlas-component="CausalGraph" data-state={nodes.length ? 'with-nodes' : 'empty'} {...props}>
      <svg className="atlas-chart-svg" viewBox={`0 0 ${width} ${height}`} role="img" aria-labelledby={`${titleId} ${descId}`} focusable="false">
        <title id={titleId}>{title}</title>
        <desc id={descId}>{summary}</desc>
        <g className="atlas-causal-graph__edges" aria-hidden="true">
          {edges.map((edge, index) => {
            const from = byId.get(edge.from);
            const to = byId.get(edge.to);
            if (!from || !to) return null;
            return <line key={`${edge.from}-${edge.to}-${index}`} className="atlas-causal-graph__edge" data-strength={edge.strength || 'observed'} x1={from.x} y1={from.y} x2={to.x} y2={to.y} />;
          })}
        </g>
        <g className="atlas-causal-graph__nodes" role="list" aria-label="Causal assumptions">
          {nodes.map((node) => (
            <g key={node.id} className="atlas-causal-graph__node" data-status={node.status || 'observed'} role="listitem" tabIndex={0} aria-label={`${node.label}. ${node.description || node.status || 'observed'}`}>
              <circle className="atlas-causal-graph__node-circle" cx={node.x} cy={node.y} r="30" />
              <text className="atlas-causal-graph__node-label" x={node.x} y={node.y + 4} textAnchor="middle">{node.label}</text>
            </g>
          ))}
        </g>
      </svg>
    </div>
  );
}
