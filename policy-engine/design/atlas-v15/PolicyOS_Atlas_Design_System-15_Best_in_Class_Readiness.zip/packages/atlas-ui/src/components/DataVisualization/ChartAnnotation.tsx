import type * as React from 'react';
import { cx } from '../../utils/cx';

export interface ChartAnnotationProps extends React.HTMLAttributes<HTMLElement> {
  tone?: 'info' | 'success' | 'warning' | 'danger' | 'neutral';
  marker?: React.ReactNode;
  title?: React.ReactNode;
}

export function ChartAnnotation({ tone = 'info', marker, title, children, className, ...props }: ChartAnnotationProps) {
  return (
    <aside
      className={cx('atlas-chart-annotation', className)}
      data-atlas-component="ChartAnnotation"
      data-state={tone}
      data-tone={tone}
      {...props}
    >
      {marker ? <span className="atlas-chart-annotation__marker" aria-hidden="true">{marker}</span> : null}
      <span className="atlas-chart-annotation__content">
        {title ? <strong className="atlas-chart-annotation__title">{title}</strong> : null}
        <span className="atlas-chart-annotation__body">{children}</span>
      </span>
    </aside>
  );
}
