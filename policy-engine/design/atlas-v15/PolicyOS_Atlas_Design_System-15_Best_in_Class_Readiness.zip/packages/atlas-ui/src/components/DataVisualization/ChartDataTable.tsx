
import type * as React from 'react';
import { cx } from '../../utils/cx';
import type { ChartDataColumn } from './types';

export interface ChartDataTableProps<Row extends Record<string, React.ReactNode> = Record<string, React.ReactNode>> extends React.HTMLAttributes<HTMLDivElement> {
  caption: React.ReactNode;
  columns: ChartDataColumn<Row>[];
  rows: Row[];
  density?: 'comfortable' | 'compact' | 'condensed';
}

export function ChartDataTable<Row extends Record<string, React.ReactNode>>({ caption, columns, rows, density = 'compact', className, ...props }: ChartDataTableProps<Row>) {
  return (
    <div className={cx('atlas-chart-data-table-wrap', className)} data-atlas-component="ChartDataTable" data-state={rows.length ? 'with-rows' : 'empty'} data-density={density} {...props}>
      <table className="atlas-chart-data-table">
        <caption>{caption}</caption>
        <thead>
          <tr>
            {columns.map((column) => <th key={column.key} scope="col" data-align={column.align || 'start'}>{column.header}</th>)}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, rowIndex) => (
            <tr key={rowIndex}>
              {columns.map((column) => {
                const content = row[column.key];
                return column.rowHeader
                  ? <th key={column.key} scope="row" data-align={column.align || 'start'}>{content}</th>
                  : <td key={column.key} data-align={column.align || 'start'}>{content}</td>;
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
