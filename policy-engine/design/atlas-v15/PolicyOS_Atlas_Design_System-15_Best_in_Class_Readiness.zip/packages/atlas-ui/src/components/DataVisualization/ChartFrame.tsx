
import type * as React from 'react';
import { useAtlasId, joinIds } from '../../utils/ids';
import { cx } from '../../utils/cx';

export type ChartFrameDensity = 'comfortable' | 'compact' | 'condensed';
export type ChartFrameStatus = 'default' | 'loading' | 'empty' | 'warning' | 'danger' | 'success';
export type ChartFrameState = 'default' | 'summary-only' | 'with-data-table' | 'loading' | 'empty' | 'interactive' | 'error';

export interface ChartFrameProps extends React.HTMLAttributes<HTMLElement> {
  title: React.ReactNode;
  summary: React.ReactNode;
  eyebrow?: React.ReactNode;
  description?: React.ReactNode;
  caption?: React.ReactNode;
  source?: React.ReactNode;
  actions?: React.ReactNode;
  dataTable?: React.ReactNode;
  loading?: boolean;
  empty?: boolean;
  density?: ChartFrameDensity;
  status?: ChartFrameStatus;
}

export function ChartFrame({ title, summary, eyebrow, description, caption, source, actions, dataTable, loading = false, empty = false, density = 'comfortable', className, children, id, ...props }: ChartFrameProps) {
  const frameId = useAtlasId(id, 'atlas-chart-frame');
  const titleId = `${frameId}-title`;
  const summaryId = `${frameId}-summary`;
  const descriptionId = description ? `${frameId}-description` : undefined;
  const captionId = caption || source ? `${frameId}-caption` : undefined;
  const describedBy = joinIds(summaryId, descriptionId, captionId);
  const state = loading ? 'loading' : empty ? 'empty' : dataTable ? 'with-data-table' : 'summary-only';
  return (
    <figure
      id={frameId}
      className={cx('atlas-chart-frame', className)}
      data-atlas-component="ChartFrame"
      data-state={state}
      data-density={density}
      data-status={status}
      aria-labelledby={titleId}
      aria-describedby={describedBy}
      aria-busy={loading || undefined}
      {...props}
    >
      <figcaption className="atlas-chart-frame__header">
        <div className="atlas-chart-frame__copy">
          {eyebrow ? <p className="atlas-chart-frame__eyebrow">{eyebrow}</p> : null}
          <h3 className="atlas-chart-frame__title" id={titleId}>{title}</h3>
          <p className="atlas-chart-frame__summary" id={summaryId}>{summary}</p>
          {description ? <p className="atlas-chart-frame__description" id={descriptionId}>{description}</p> : null}
        </div>
        {actions ? <div className="atlas-chart-frame__actions">{actions}</div> : null}
      </figcaption>
      <div className="atlas-chart-frame__plot" role="group" aria-describedby={describedBy}>
        {children}
      </div>
      {dataTable ? <div className="atlas-chart-frame__data">{dataTable}</div> : null}
      {(caption || source) ? (
        <p className="atlas-chart-frame__caption" id={captionId}>
          {caption}{caption && source ? ' · ' : null}{source}
        </p>
      ) : null}
    </figure>
  );
}
