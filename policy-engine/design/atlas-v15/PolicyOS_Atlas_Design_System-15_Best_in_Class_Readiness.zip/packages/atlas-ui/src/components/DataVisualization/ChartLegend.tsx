
import type * as React from 'react';
import { cx } from '../../utils/cx';
import type { ChartLegendItem } from './types';
export type { ChartLegendItem } from './types';

export interface ChartLegendProps extends React.HTMLAttributes<HTMLUListElement> {
  items: ChartLegendItem[];
  label?: string;
  orientation?: 'horizontal' | 'vertical';
}

export function ChartLegend({ items, label = 'Chart legend', orientation = 'horizontal', className, ...props }: ChartLegendProps) {
  return (
    <ul
      className={cx('atlas-chart-legend', className)}
      data-atlas-component="ChartLegend"
      data-state={items.length ? 'with-items' : 'empty'}
      data-orientation={orientation}
      aria-label={label}
      {...props}
    >
      {items.map((item, index) => (
        <li key={item.id} className="atlas-chart-legend__item" data-tone={item.tone || `series-${(index % 6) + 1}`} data-shape={item.shape || 'circle'}>
          <span className="atlas-chart-legend__marker" aria-hidden="true" />
          <span className="atlas-chart-legend__label">{item.label}</span>
          {item.value ? <span className="atlas-chart-legend__value">{item.value}</span> : null}
          {item.description ? <span className="atlas-chart-legend__description">{item.description}</span> : null}
        </li>
      ))}
    </ul>
  );
}
