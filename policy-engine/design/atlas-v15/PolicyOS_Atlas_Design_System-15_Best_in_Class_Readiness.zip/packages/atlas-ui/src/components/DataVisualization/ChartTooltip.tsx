
import type * as React from 'react';
import { cx } from '../../utils/cx';

export interface ChartTooltipProps extends React.HTMLAttributes<HTMLDivElement> {
  title: React.ReactNode;
  value?: React.ReactNode;
  description?: React.ReactNode;
  open?: boolean;
  live?: boolean;
}

export function ChartTooltip({ title, value, description, open = true, live = false, className, ...props }: ChartTooltipProps) {
  return (
    <div
      className={cx('atlas-chart-tooltip', className)}
      data-atlas-component="ChartTooltip"
      data-state={open ? 'open' : 'closed'}
      role="tooltip"
      aria-live={live ? 'polite' : undefined}
      hidden={!open}
      {...props}
    >
      <strong className="atlas-chart-tooltip__title">{title}</strong>
      {value ? <span className="atlas-chart-tooltip__value">{value}</span> : null}
      {description ? <span className="atlas-chart-tooltip__description">{description}</span> : null}
    </div>
  );
}
