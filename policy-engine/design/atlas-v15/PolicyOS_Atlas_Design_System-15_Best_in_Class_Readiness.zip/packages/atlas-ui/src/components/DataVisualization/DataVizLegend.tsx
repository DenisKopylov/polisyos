import type * as React from 'react';
import { cx } from '../../utils/cx';

export interface DataVizLegendItem {
  id: string;
  label: React.ReactNode;
  description?: React.ReactNode;
  tone?: 'series-1' | 'series-2' | 'series-3' | 'series-4' | 'series-5' | 'positive' | 'warning' | 'negative' | 'neutral';
  pattern?: 'solid' | 'dash' | 'dot' | 'band';
}

export interface DataVizLegendProps extends React.HTMLAttributes<HTMLDivElement> {
  label?: string;
  items: DataVizLegendItem[];
  direction?: 'row' | 'column';
}

export function DataVizLegend({ label = 'Chart legend', items, direction = 'row', className, ...props }: DataVizLegendProps) {
  return (
    <div className={cx('atlas-viz-legend', className)} data-atlas-component="DataVizLegend" data-state={items.length ? 'with-items' : 'empty'} data-direction={direction} role="list" aria-label={label} {...props}>
      {items.map((item) => (
        <div key={item.id} className="atlas-viz-legend-item" role="listitem" data-tone={item.tone ?? 'series-1'} data-pattern={item.pattern ?? 'solid'}>
          <span className="atlas-viz-legend-swatch" aria-hidden="true" />
          <span className="atlas-viz-legend-copy">
            <span className="atlas-viz-legend-label">{item.label}</span>
            {item.description ? <span className="atlas-viz-legend-description">{item.description}</span> : null}
          </span>
        </div>
      ))}
    </div>
  );
}
