import type * as React from 'react';
import { cx } from '../../utils/cx';

export interface DataVizTableColumn<Row> {
  key: string;
  header: React.ReactNode;
  cell: (row: Row) => React.ReactNode;
  align?: 'start' | 'end';
  scope?: 'row' | 'col';
}

export interface DataVizTableProps<Row> extends React.HTMLAttributes<HTMLDivElement> {
  caption: React.ReactNode;
  columns: Array<DataVizTableColumn<Row>>;
  rows: Row[];
  getRowKey: (row: Row, index: number) => string;
  note?: React.ReactNode;
  density?: 'comfortable' | 'compact' | 'condensed';
}

export function DataVizTable<Row>({ caption, columns, rows, getRowKey, note, density = 'comfortable', className, ...props }: DataVizTableProps<Row>) {
  return (
    <div
      className={cx('atlas-dataviz-table', className)}
      data-atlas-component="DataVizTable"
      data-state={rows.length ? 'with-rows' : 'empty'}
      data-density={density}
      role="region"
      aria-label={typeof caption === 'string' ? caption : 'Chart data table'}
      tabIndex={0}
      {...props}
    >
      <table>
        <caption>{caption}</caption>
        <thead>
          <tr>{columns.map((column) => <th key={column.key} scope="col" data-align={column.align}>{column.header}</th>)}</tr>
        </thead>
        <tbody>
          {rows.map((row, index) => (
            <tr key={getRowKey(row, index)}>
              {columns.map((column, columnIndex) => {
                const Tag = columnIndex === 0 && column.scope === 'row' ? 'th' : 'td';
                return <Tag key={column.key} scope={Tag === 'th' ? 'row' : undefined} data-align={column.align}>{column.cell(row)}</Tag>;
              })}
            </tr>
          ))}
        </tbody>
      </table>
      {note ? <p className="atlas-dataviz-table__note">{note}</p> : null}
    </div>
  );
}
