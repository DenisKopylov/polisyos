
import type * as React from 'react';
import { useAtlasId } from '../../utils/ids';
import { cx } from '../../utils/cx';
import { extent, scale } from './chartUtils';

export interface HeatmapDatum {
  row: string;
  column: string;
  value: number;
  label?: string;
}

export interface HeatmapProps extends React.HTMLAttributes<HTMLDivElement> {
  title: string;
  summary: string;
  data: HeatmapDatum[];
  rows?: string[];
  columns?: string[];
  cellSize?: number;
}

export function Heatmap({ title, summary, data, rows, columns, cellSize = 48, className, id, ...props }: HeatmapProps) {
  const rootId = useAtlasId(id, 'atlas-heatmap');
  const titleId = `${rootId}-title`;
  const descId = `${rootId}-desc`;
  const rowLabels = rows || Array.from(new Set(data.map((item) => item.row)));
  const columnLabels = columns || Array.from(new Set(data.map((item) => item.column)));
  const [min, max] = extent(data.map((item) => item.value), 0, 1);
  const width = Math.max(columnLabels.length * cellSize + 120, 240);
  const height = Math.max(rowLabels.length * cellSize + 80, 180);
  return (
    <div className={cx('atlas-heatmap', className)} data-atlas-component="Heatmap" data-state={data.length ? 'with-cells' : 'empty'} {...props}>
      <svg className="atlas-chart-svg" viewBox={`0 0 ${width} ${height}`} role="img" aria-labelledby={`${titleId} ${descId}`} focusable="false">
        <title id={titleId}>{title}</title>
        <desc id={descId}>{summary}</desc>
        {columnLabels.map((column, index) => <text key={column} className="atlas-chart-axis-label" x={96 + index * cellSize + cellSize / 2} y="24" textAnchor="middle">{column}</text>)}
        {rowLabels.map((row, rowIndex) => <text key={row} className="atlas-chart-axis-label" x="84" y={56 + rowIndex * cellSize + cellSize / 2} textAnchor="end">{row}</text>)}
        {data.map((item) => {
          const columnIndex = columnLabels.indexOf(item.column);
          const rowIndex = rowLabels.indexOf(item.row);
          const level = Math.max(0, Math.min(4, Math.round(scale(item.value, [min, max], [0, 4]))));
          return <rect key={`${item.row}-${item.column}`} className="atlas-heatmap__cell" data-level={level} x={96 + columnIndex * cellSize} y={40 + rowIndex * cellSize} width={cellSize - 4} height={cellSize - 4} rx="8" aria-label={item.label || `${item.row} ${item.column}: ${item.value}`} />;
        })}
      </svg>
    </div>
  );
}
