
import type * as React from 'react';
import { useAtlasId } from '../../utils/ids';
import { cx } from '../../utils/cx';
import { extent, pathFromPoints, pointX, scale } from './chartUtils';
import type { ChartPoint, ChartSeries } from './types';
export type LineChartDatum = ChartPoint;
export type LineChartSeries = ChartSeries;

export interface LineChartProps extends React.HTMLAttributes<HTMLDivElement> {
  title: string;
  summary: string;
  series: ChartSeries[];
  width?: number;
  height?: number;
  xLabel?: string;
  yLabel?: string;
}

export function LineChart({ title, summary, series, width = 720, height = 360, xLabel, yLabel, className, id, ...props }: LineChartProps) {
  const rootId = useAtlasId(id, 'atlas-line-chart');
  const titleId = `${rootId}-title`;
  const descId = `${rootId}-desc`;
  const padding = { left: 56, right: 24, top: 24, bottom: 48 };
  const allPoints = series.flatMap((item) => item.data);
  const xDomain = extent(allPoints.map((point, index) => pointX(point, index)), 0, Math.max(allPoints.length - 1, 1));
  const yValues = allPoints.flatMap((point) => [point.low ?? point.value, point.high ?? point.value, point.value]);
  const yDomain = extent(yValues.concat(0), 0, 1);
  const plot = { x0: padding.left, x1: width - padding.right, y0: padding.top, y1: height - padding.bottom };
  const state = series.length ? 'with-series' : 'empty';
  return (
    <div className={cx('atlas-line-chart', className)} data-atlas-component="LineChart" data-state={state} {...props}>
      <svg className="atlas-chart-svg" viewBox={`0 0 ${width} ${height}`} role="img" aria-labelledby={`${titleId} ${descId}`} focusable="false">
        <title id={titleId}>{title}</title>
        <desc id={descId}>{summary}</desc>
        <line className="atlas-chart-grid-line" x1={plot.x0} y1={plot.y0} x2={plot.x0} y2={plot.y1} />
        <line className="atlas-chart-grid-line" x1={plot.x0} y1={plot.y1} x2={plot.x1} y2={plot.y1} />
        {yLabel ? <text className="atlas-chart-axis-label" x={plot.x0} y={14}>{yLabel}</text> : null}
        {xLabel ? <text className="atlas-chart-axis-label" x={plot.x1} y={height - 10} textAnchor="end">{xLabel}</text> : null}
        {series.map((item, seriesIndex) => {
          const points = item.data.map((point, index) => ({
            x: scale(pointX(point, index), xDomain, [plot.x0, plot.x1]),
            y: scale(point.value, yDomain, [plot.y1, plot.y0]),
          }));
          return (
            <g key={item.id} className="atlas-line-chart__series-group" data-series-index={seriesIndex % 6} data-dashed={item.dashed || undefined} aria-label={item.label}>
              <path className="atlas-chart-series atlas-line-chart__series" d={pathFromPoints(points)} />
              {points.map((point, index) => <circle key={index} className="atlas-chart-point" cx={point.x} cy={point.y} r="4" />)}
            </g>
          );
        })}
      </svg>
    </div>
  );
}
