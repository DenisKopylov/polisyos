import type * as React from 'react';
import { cx } from '../../utils/cx';
import { ChartFrame } from './ChartFrame';

export interface ProvenanceNode {
  id: string;
  label: React.ReactNode;
  meta?: React.ReactNode;
  status?: 'current' | 'stale' | 'blocked' | 'verified';
}

export interface ProvenanceEdge {
  from: string;
  to: string;
  label?: React.ReactNode;
}

export interface ProvenanceGraphProps extends React.HTMLAttributes<HTMLElement> {
  title: React.ReactNode;
  summary: React.ReactNode;
  nodes: ProvenanceNode[];
  edges: ProvenanceEdge[];
  description?: React.ReactNode;
  dataTable?: React.ReactNode;
}

export function ProvenanceGraph({ title, summary, description, nodes, edges, dataTable, className, ...props }: ProvenanceGraphProps) {
  return (
    <ChartFrame title={title} description={description} summary={summary} dataTable={dataTable} empty={!nodes.length} className={cx('atlas-provenance-frame', className)} {...props}>
      <div className="atlas-provenance-graph" data-atlas-component="ProvenanceGraph" data-state={nodes.length ? 'ready' : 'empty'} role="img" aria-label={typeof title === 'string' ? title : 'Provenance graph'}>
        <ol className="atlas-provenance-nodes">
          {nodes.map((node) => (
            <li key={node.id} className="atlas-provenance-node" data-status={node.status || 'current'}>
              <span className="atlas-provenance-node-label">{node.label}</span>
              {node.meta ? <span className="atlas-provenance-node-meta">{node.meta}</span> : null}
            </li>
          ))}
        </ol>
        <ul className="atlas-provenance-edges" aria-label="Provenance relationships">
          {edges.map((edge, index) => <li key={`${edge.from}-${edge.to}-${index}`}>{edge.from} to {edge.to}{edge.label ? <>: {edge.label}</> : null}</li>)}
        </ul>
      </div>
    </ChartFrame>
  );
}
