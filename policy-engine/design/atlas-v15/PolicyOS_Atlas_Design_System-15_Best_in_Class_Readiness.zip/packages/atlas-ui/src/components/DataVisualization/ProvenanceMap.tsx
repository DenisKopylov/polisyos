
import type * as React from 'react';
import { cx } from '../../utils/cx';
import type { ProvenanceStage } from './types';

export interface ProvenanceMapProps extends React.HTMLAttributes<HTMLElement> {
  title?: React.ReactNode;
  stages: ProvenanceStage[];
  orientation?: 'vertical' | 'horizontal';
}

export function ProvenanceMap({ title = 'Evidence provenance', stages, orientation = 'vertical', className, ...props }: ProvenanceMapProps) {
  return (
    <section className={cx('atlas-provenance-map', className)} data-atlas-component="ProvenanceMap" data-state={stages.length ? 'with-stages' : 'empty'} data-orientation={orientation} aria-label={String(title)} {...props}>
      <h4 className="atlas-provenance-map__title">{title}</h4>
      <ol className="atlas-provenance-map__list">
        {stages.map((stage) => (
          <li key={stage.id} className="atlas-provenance-map__stage" data-status={stage.status || 'complete'}>
            <span className="atlas-provenance-map__node" aria-hidden="true" />
            <div className="atlas-provenance-map__copy">
              <strong>{stage.label}</strong>
              {stage.meta ? <span>{stage.meta}</span> : null}
              {stage.detail ? <p>{stage.detail}</p> : null}
            </div>
          </li>
        ))}
      </ol>
    </section>
  );
}
