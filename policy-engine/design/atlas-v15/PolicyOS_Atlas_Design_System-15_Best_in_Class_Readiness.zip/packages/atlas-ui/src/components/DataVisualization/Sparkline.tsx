
import type * as React from 'react';
import { useAtlasId } from '../../utils/ids';
import { cx } from '../../utils/cx';
import { extent, pathFromPoints, scale } from './chartUtils';
import type { ChartPoint } from './types';
export type SparklinePoint = ChartPoint;

export interface SparklineProps extends React.HTMLAttributes<HTMLDivElement> {
  data: ChartPoint[];
  title: string;
  summary: string;
  width?: number;
  height?: number;
  tone?: 'series-1' | 'series-2' | 'series-3' | 'series-4' | 'series-5' | 'series-6';
}

export function Sparkline({ data, title, summary, width = 180, height = 48, tone = 'series-1', className, id, ...props }: SparklineProps) {
  const rootId = useAtlasId(id, 'atlas-sparkline');
  const titleId = `${rootId}-title`;
  const descId = `${rootId}-desc`;
  const values = data.map((point) => point.value);
  const domain = extent(values, 0, 1);
  const xMax = Math.max(data.length - 1, 1);
  const points = data.map((point, index) => ({ x: scale(index, [0, xMax], [4, width - 4]), y: scale(point.value, domain, [height - 4, 4]) }));
  return (
    <div className={cx('atlas-sparkline', className)} data-atlas-component="Sparkline" data-state={data.length ? 'with-data' : 'empty'} data-tone={tone} {...props}>
      <svg className="atlas-chart-svg atlas-sparkline__svg" viewBox={`0 0 ${width} ${height}`} role="img" aria-labelledby={`${titleId} ${descId}`} focusable="false">
        <title id={titleId}>{title}</title>
        <desc id={descId}>{summary}</desc>
        <path className="atlas-sparkline__line" d={pathFromPoints(points)} />
      </svg>
    </div>
  );
}
