
import type * as React from 'react';
import { useAtlasId } from '../../utils/ids';
import { cx } from '../../utils/cx';
import { extent, pathFromPoints, pointX, polygonFromPoints, scale } from './chartUtils';
import type { ChartPoint } from './types';
export type UncertaintyPoint = ChartPoint;
export type UncertaintyDatum = ChartPoint;

export interface UncertaintyBandProps extends React.HTMLAttributes<HTMLDivElement> {
  title: string;
  summary: string;
  data: ChartPoint[];
  width?: number;
  height?: number;
  intervalLabel?: string;
}

export function UncertaintyBand({ title, summary, data, width = 720, height = 360, intervalLabel = 'Interval bounds', className, id, ...props }: UncertaintyBandProps) {
  const rootId = useAtlasId(id, 'atlas-uncertainty-band');
  const titleId = `${rootId}-title`;
  const descId = `${rootId}-desc`;
  const padding = { left: 56, right: 24, top: 28, bottom: 48 };
  const xDomain = extent(data.map((point, index) => pointX(point, index)), 0, Math.max(data.length - 1, 1));
  const yDomain = extent(data.flatMap((point) => [point.low ?? point.value, point.high ?? point.value, point.value]).concat(0), 0, 1);
  const plot = { x0: padding.left, x1: width - padding.right, y0: padding.top, y1: height - padding.bottom };
  const mid = data.map((point, index) => ({ x: scale(pointX(point, index), xDomain, [plot.x0, plot.x1]), y: scale(point.value, yDomain, [plot.y1, plot.y0]) }));
  const high = data.map((point, index) => ({ x: scale(pointX(point, index), xDomain, [plot.x0, plot.x1]), y: scale(point.high ?? point.value, yDomain, [plot.y1, plot.y0]) }));
  const low = data.map((point, index) => ({ x: scale(pointX(point, index), xDomain, [plot.x0, plot.x1]), y: scale(point.low ?? point.value, yDomain, [plot.y1, plot.y0]) })).reverse();
  return (
    <div className={cx('atlas-uncertainty-band', className)} data-atlas-component="UncertaintyBand" data-state={data.length ? 'with-interval' : 'empty'} {...props}>
      <svg className="atlas-chart-svg" viewBox={`0 0 ${width} ${height}`} role="img" aria-labelledby={`${titleId} ${descId}`} focusable="false">
        <title id={titleId}>{title}</title>
        <desc id={descId}>{summary}. {intervalLabel}.</desc>
        <line className="atlas-chart-grid-line" x1={plot.x0} y1={plot.y1} x2={plot.x1} y2={plot.y1} />
        <polygon className="atlas-uncertainty-band__area" points={polygonFromPoints(high.concat(low))} />
        <path className="atlas-chart-series atlas-uncertainty-band__midline" d={pathFromPoints(mid)} />
      </svg>
    </div>
  );
}
