
import type { ChartPoint } from './types';

export function finite(value: number | undefined, fallback = 0): number {
  return typeof value === 'number' && Number.isFinite(value) ? value : fallback;
}

export function extent(values: number[], fallbackMin = 0, fallbackMax = 1): [number, number] {
  const clean = values.filter((value) => Number.isFinite(value));
  if (!clean.length) return [fallbackMin, fallbackMax];
  let min = Math.min(...clean);
  let max = Math.max(...clean);
  if (min === max) {
    min = Math.min(0, min - 1);
    max = max + 1;
  }
  return [min, max];
}

export function scale(value: number, domain: [number, number], range: [number, number]): number {
  const [d0, d1] = domain;
  const [r0, r1] = range;
  const denominator = d1 - d0 || 1;
  return r0 + ((value - d0) / denominator) * (r1 - r0);
}

export function rounded(value: number): number {
  return Math.round(value * 100) / 100;
}

export function pathFromPoints(points: Array<{ x: number; y: number }>): string {
  return points.map((point, index) => `${index === 0 ? 'M' : 'L'} ${rounded(point.x)} ${rounded(point.y)}`).join(' ');
}

export function polygonFromPoints(points: Array<{ x: number; y: number }>): string {
  return points.map((point) => `${rounded(point.x)},${rounded(point.y)}`).join(' ');
}

export function chartDescription(title: string, summary?: string): string {
  return summary ? `${title}. ${summary}` : title;
}

export function pointX(point: ChartPoint, index: number): number {
  return finite(point.x, index);
}
