export function clamp(value: number, min = 0, max = 100): number {
  if (!Number.isFinite(value)) return min;
  return Math.min(max, Math.max(min, value));
}

export function percent(value: number, max = 100): string {
  const denominator = Number.isFinite(max) && max > 0 ? max : 100;
  return `${clamp((value / denominator) * 100)}%`;
}

export function points(values: number[], width = 100, height = 40): string {
  if (values.length === 0) return '';
  if (values.length === 1) return `0 ${height / 2} ${width} ${height / 2}`;
  const min = Math.min(...values);
  const max = Math.max(...values);
  const span = max - min || 1;
  return values.map((value, index) => {
    const x = (index / (values.length - 1)) * width;
    const y = height - ((value - min) / span) * height;
    return `${Number(x.toFixed(2))} ${Number(y.toFixed(2))}`;
  }).join(' ');
}

export function toneAttr(tone: string | undefined): string {
  return tone || 'teal';
}
