
import type * as React from 'react';

export type ChartTone = 'series-1' | 'series-2' | 'series-3' | 'series-4' | 'series-5' | 'series-6' | 'neutral' | 'warning' | 'danger' | 'success';
export type ChartMarkerShape = 'circle' | 'square' | 'triangle' | 'dash' | 'dot';

export interface ChartPoint {
  label: string;
  value: number;
  x?: number;
  low?: number;
  high?: number;
  description?: string;
}

export interface ChartSeries {
  id: string;
  label: string;
  data: ChartPoint[];
  tone?: ChartTone;
  dashed?: boolean;
}

export interface ChartLegendItem {
  id: string;
  label: React.ReactNode;
  value?: React.ReactNode;
  tone?: ChartTone;
  shape?: ChartMarkerShape;
  description?: React.ReactNode;
}

export interface ChartDataColumn<Row extends Record<string, React.ReactNode> = Record<string, React.ReactNode>> {
  key: keyof Row & string;
  header: React.ReactNode;
  align?: 'start' | 'end' | 'center';
  rowHeader?: boolean;
}

export interface CausalGraphNode {
  id: string;
  label: string;
  x: number;
  y: number;
  status?: 'observed' | 'assumption' | 'confounder' | 'review';
  description?: string;
}

export interface CausalGraphEdge {
  from: string;
  to: string;
  label?: string;
  strength?: 'assumed' | 'observed' | 'weak';
}

export interface ProvenanceStage {
  id: string;
  label: string;
  meta?: React.ReactNode;
  status?: 'complete' | 'review' | 'stale' | 'failed';
  detail?: React.ReactNode;
}
