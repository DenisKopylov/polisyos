import * as React from 'react';
import { cx } from '../../utils/cx';
import { useAtlasId } from '../../utils/ids';
import { Button } from '../Button/Button';

export interface DialogProps extends React.HTMLAttributes<HTMLDivElement> {
  open: boolean;
  title: React.ReactNode;
  description?: React.ReactNode;
  onClose: () => void;
  actions?: React.ReactNode;
  closeLabel?: string;
}

const FOCUSABLE_SELECTOR = [
  'a[href]',
  'area[href]',
  'button:not([disabled])',
  'input:not([disabled]):not([type="hidden"])',
  'select:not([disabled])',
  'textarea:not([disabled])',
  'iframe',
  'object',
  'embed',
  '[contenteditable="true"]',
  '[tabindex]:not([tabindex="-1"])',
].join(',');

function getFocusable(container: HTMLElement): HTMLElement[] {
  return Array.from(container.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR)).filter((element) => {
    return !element.hasAttribute('disabled') && element.getAttribute('aria-hidden') !== 'true';
  });
}

export function Dialog({ open, title, description, onClose, actions, closeLabel = 'Close dialog', id, className, children, ...props }: DialogProps) {
  const dialogId = useAtlasId(id, 'atlas-dialog');
  const titleId = `${dialogId}-title`;
  const descriptionId = description ? `${dialogId}-description` : undefined;
  const panelRef = React.useRef<HTMLDivElement>(null);
  const closeRef = React.useRef<HTMLButtonElement>(null);
  const previousFocusRef = React.useRef<HTMLElement | null>(null);

  React.useEffect(() => {
    if (!open) return undefined;
    previousFocusRef.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const frame = window.requestAnimationFrame(() => closeRef.current?.focus());

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        onClose();
        return;
      }
      if (event.key !== 'Tab') return;
      const panel = panelRef.current;
      if (!panel) return;
      const focusable = getFocusable(panel);
      if (!focusable.length) {
        event.preventDefault();
        panel.focus();
        return;
      }
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };

    document.addEventListener('keydown', onKeyDown);
    return () => {
      window.cancelAnimationFrame(frame);
      document.removeEventListener('keydown', onKeyDown);
      previousFocusRef.current?.focus?.();
      previousFocusRef.current = null;
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="atlas-dialog-backdrop" data-atlas-component="DialogBackdrop" data-state="open" onClick={onClose}>
      <div
        ref={panelRef}
        id={dialogId}
        className={cx('atlas-dialog-panel', className)}
        data-atlas-component="Dialog"
        data-state="open"
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={descriptionId}
        tabIndex={-1}
        onClick={(event) => event.stopPropagation()}
        {...props}
      >
        <header className="atlas-dialog-header">
          <div>
            <h2 id={titleId} className="atlas-dialog-title">{title}</h2>
            {description ? <p id={descriptionId} className="atlas-panel-description">{description}</p> : null}
          </div>
          <Button ref={closeRef} variant="quiet" size="icon" aria-label={closeLabel} onClick={onClose}>×</Button>
        </header>
        {children}
        {actions ? <footer>{actions}</footer> : null}
      </div>
    </div>
  );
}
