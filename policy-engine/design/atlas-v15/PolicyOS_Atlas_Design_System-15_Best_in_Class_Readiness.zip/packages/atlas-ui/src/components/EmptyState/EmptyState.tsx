import type * as React from 'react';
import { cx } from '../../utils/cx';

export interface EmptyStateProps extends React.HTMLAttributes<HTMLElement> {
  title: React.ReactNode;
  description?: React.ReactNode;
  action?: React.ReactNode;
  icon?: React.ReactNode;
  state?: 'empty' | 'permission-denied' | 'filtered-out' | 'not-found' | 'offline';
}

export function EmptyState({ title, description, action, icon, state = 'empty', className, ...props }: EmptyStateProps) {
  return (
    <section className={cx('atlas-empty-state', className)} data-atlas-component="EmptyState" data-state={state} {...props}>
      {icon ? <div className="atlas-empty-icon" aria-hidden="true">{icon}</div> : null}
      <h2 className="atlas-empty-title">{title}</h2>
      {description ? <p className="atlas-empty-description">{description}</p> : null}
      {action ? <div>{action}</div> : null}
    </section>
  );
}
