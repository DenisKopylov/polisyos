import * as React from 'react';
import { cx } from '../../utils/cx';
import { joinIds, useAtlasId } from '../../utils/ids';

function assignRef<T>(ref: React.Ref<T>, value: T | null) {
  if (typeof ref === 'function') ref(value);
  else if (ref && typeof ref === 'object') ref.current = value;
}

export interface CheckboxProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'type'> {
  label: React.ReactNode;
  description?: React.ReactNode;
  error?: React.ReactNode;
  indeterminate?: boolean;
}

export const Checkbox = React.forwardRef<HTMLInputElement, CheckboxProps>(function Checkbox(
  { label, description, error, id, className, required, checked, defaultChecked, disabled, indeterminate = false, ...props },
  ref,
) {
  const controlId = useAtlasId(id, 'atlas-checkbox');
  const descriptionId = description ? `${controlId}-description` : undefined;
  const errorId = error ? `${controlId}-error` : undefined;
  const internalRef = React.useRef<HTMLInputElement>(null);
  const setControlRef = React.useMemo(() => (node: HTMLInputElement | null) => {
    internalRef.current = node;
    if (node) node.indeterminate = Boolean(indeterminate);
    assignRef(ref, node);
  }, [ref, indeterminate]);
  React.useEffect(() => {
    if (internalRef.current) internalRef.current.indeterminate = Boolean(indeterminate);
  }, [indeterminate]);
  const state = disabled ? 'disabled' : error ? 'invalid' : indeterminate ? 'indeterminate' : checked || defaultChecked ? 'checked' : 'unchecked';
  return (
    <div className={cx('atlas-checkbox', className)} data-atlas-component="Checkbox" data-state={state} data-required={required || undefined}>
      <input
        {...props}
        ref={setControlRef}
        id={controlId}
        type="checkbox"
        className="atlas-checkbox-control"
        required={required}
        disabled={disabled}
        checked={checked}
        defaultChecked={defaultChecked}
        aria-required={required || undefined}
        aria-invalid={Boolean(error) || undefined}
        aria-checked={indeterminate ? 'mixed' : undefined}
        aria-describedby={joinIds(descriptionId, errorId)}
      />
      <div>
        <label className="atlas-checkbox-label" htmlFor={controlId}>{label}{required ? ' *' : null}</label>
        {description ? <p id={descriptionId} className="atlas-field-description">{description}</p> : null}
        {error ? <p id={errorId} className="atlas-field-error">{error}</p> : null}
      </div>
    </div>
  );
});
