import * as React from 'react';
import { cx } from '../../utils/cx';
import { joinIds, useAtlasId } from '../../utils/ids';

export interface SelectOption {
  label: string;
  value: string;
  disabled?: boolean;
}

export interface SelectFieldProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label: React.ReactNode;
  description?: React.ReactNode;
  error?: React.ReactNode;
  options: SelectOption[];
  placeholder?: string;
  controlClassName?: string;
}

export const SelectField = React.forwardRef<HTMLSelectElement, SelectFieldProps>(function SelectField(
  { label, description, error, options, placeholder, id, className, controlClassName, required, disabled, value, defaultValue, ...props },
  ref,
) {
  const fieldId = useAtlasId(id, 'atlas-select');
  const descriptionId = description ? `${fieldId}-description` : undefined;
  const errorId = error ? `${fieldId}-error` : undefined;
  const state = disabled ? 'disabled' : error ? 'invalid' : value !== undefined || defaultValue !== undefined ? 'selected' : 'placeholder';
  return (
    <div className={cx('atlas-field', className)} data-atlas-component="SelectField" data-state={state} data-required={required || undefined}>
      <label className="atlas-field-label" htmlFor={fieldId}>{label}{required ? ' *' : null}</label>
      {description ? <p id={descriptionId} className="atlas-field-description">{description}</p> : null}
      <select
        ref={ref}
        id={fieldId}
        className={cx('atlas-field-control', controlClassName)}
        required={required}
        disabled={disabled}
        value={value}
        defaultValue={defaultValue}
        aria-required={required || undefined}
        aria-invalid={Boolean(error) || undefined}
        aria-describedby={joinIds(descriptionId, errorId)}
        {...props}
      >
        {placeholder ? <option value="" disabled>{placeholder}</option> : null}
        {options.map((option) => (
          <option key={option.value} value={option.value} disabled={option.disabled}>{option.label}</option>
        ))}
      </select>
      {error ? <p id={errorId} className="atlas-field-error">{error}</p> : null}
    </div>
  );
});
