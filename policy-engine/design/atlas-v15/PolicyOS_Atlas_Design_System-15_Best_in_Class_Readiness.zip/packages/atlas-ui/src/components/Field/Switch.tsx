import * as React from 'react';
import { cx } from '../../utils/cx';
import { joinIds, useAtlasId } from '../../utils/ids';

export interface SwitchProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'type'> {
  label: React.ReactNode;
  description?: React.ReactNode;
}

export const Switch = React.forwardRef<HTMLInputElement, SwitchProps>(function Switch(
  { label, description, id, className, checked, defaultChecked, disabled, ...props },
  ref,
) {
  const controlId = useAtlasId(id, 'atlas-switch');
  const descriptionId = description ? `${controlId}-description` : undefined;
  const state = disabled ? 'disabled' : checked || defaultChecked ? 'on' : 'off';
  return (
    <div className={cx('atlas-switch', className)} data-atlas-component="Switch" data-state={state}>
      <input
        ref={ref}
        id={controlId}
        type="checkbox"
        role="switch"
        className="atlas-switch-control"
        checked={checked}
        defaultChecked={defaultChecked}
        disabled={disabled}
        aria-describedby={joinIds(descriptionId)}
        {...props}
      />
      <div>
        <label className="atlas-switch-label" htmlFor={controlId}>{label}</label>
        {description ? <p id={descriptionId} className="atlas-field-description">{description}</p> : null}
      </div>
    </div>
  );
});
