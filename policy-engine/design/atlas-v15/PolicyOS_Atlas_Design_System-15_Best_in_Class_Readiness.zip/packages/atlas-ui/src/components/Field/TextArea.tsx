import * as React from 'react';
import { cx } from '../../utils/cx';
import { joinIds, useAtlasId } from '../../utils/ids';

function fieldState(disabled?: boolean, readOnly?: boolean, error?: React.ReactNode, value?: string | number, defaultValue?: string | number): string {
  if (disabled) return 'disabled';
  if (readOnly) return 'readonly';
  if (error) return 'invalid';
  if (value !== undefined || defaultValue !== undefined) return 'filled';
  return 'empty';
}

export interface TextAreaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label: React.ReactNode;
  description?: React.ReactNode;
  error?: React.ReactNode;
  controlClassName?: string;
}

export const TextArea = React.forwardRef<HTMLTextAreaElement, TextAreaProps>(function TextArea(
  { label, description, error, id, className, controlClassName, required, disabled, readOnly, value, defaultValue, rows = 4, ...props },
  ref,
) {
  const fieldId = useAtlasId(id, 'atlas-textarea');
  const descriptionId = description ? `${fieldId}-description` : undefined;
  const errorId = error ? `${fieldId}-error` : undefined;
  return (
    <div className={cx('atlas-field', className)} data-atlas-component="TextArea" data-state={fieldState(disabled, readOnly, error, value, defaultValue)} data-required={required || undefined}>
      <label className="atlas-field-label" htmlFor={fieldId}>{label}{required ? ' *' : null}</label>
      {description ? <p id={descriptionId} className="atlas-field-description">{description}</p> : null}
      <textarea
        ref={ref}
        id={fieldId}
        rows={rows}
        className={cx('atlas-field-control', controlClassName)}
        required={required}
        disabled={disabled}
        readOnly={readOnly}
        value={value}
        defaultValue={defaultValue}
        aria-required={required || undefined}
        aria-invalid={Boolean(error) || undefined}
        aria-describedby={joinIds(descriptionId, errorId)}
        {...props}
      />
      {error ? <p id={errorId} className="atlas-field-error">{error}</p> : null}
    </div>
  );
});
