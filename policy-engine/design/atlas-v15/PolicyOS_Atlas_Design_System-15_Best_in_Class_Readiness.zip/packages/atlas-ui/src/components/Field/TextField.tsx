import * as React from 'react';
import { cx } from '../../utils/cx';
import { joinIds, useAtlasId } from '../../utils/ids';

function fieldState(disabled?: boolean, readOnly?: boolean, error?: React.ReactNode, value?: string | number, defaultValue?: string | number): string {
  if (disabled) return 'disabled';
  if (readOnly) return 'readonly';
  if (error) return 'invalid';
  if (value !== undefined || defaultValue !== undefined) return 'filled';
  return 'empty';
}

export interface TextFieldProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: React.ReactNode;
  description?: React.ReactNode;
  error?: React.ReactNode;
  controlClassName?: string;
}

export const TextField = React.forwardRef<HTMLInputElement, TextFieldProps>(function TextField(
  { label, description, error, id, className, controlClassName, required, disabled, readOnly, value, defaultValue, ...props },
  ref,
) {
  const fieldId = useAtlasId(id, 'atlas-field');
  const descriptionId = description ? `${fieldId}-description` : undefined;
  const errorId = error ? `${fieldId}-error` : undefined;
  return (
    <div className={cx('atlas-field', className)} data-atlas-component="TextField" data-state={fieldState(disabled, readOnly, error, value, defaultValue)} data-required={required || undefined}>
      <label className="atlas-field-label" htmlFor={fieldId}>{label}{required ? ' *' : null}</label>
      {description ? <p id={descriptionId} className="atlas-field-description">{description}</p> : null}
      <input
        ref={ref}
        id={fieldId}
        className={cx('atlas-field-control', controlClassName)}
        required={required}
        disabled={disabled}
        readOnly={readOnly}
        value={value}
        defaultValue={defaultValue}
        aria-required={required || undefined}
        aria-invalid={Boolean(error) || undefined}
        aria-describedby={joinIds(descriptionId, errorId)}
        {...props}
      />
      {error ? <p id={errorId} className="atlas-field-error">{error}</p> : null}
    </div>
  );
});
