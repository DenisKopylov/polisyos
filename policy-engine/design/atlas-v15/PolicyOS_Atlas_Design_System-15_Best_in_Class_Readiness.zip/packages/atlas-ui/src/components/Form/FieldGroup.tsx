import * as React from 'react';
import { cx } from '../../utils/cx';
import { joinIds, useAtlasId } from '../../utils/ids';

export interface FieldGroupProps extends React.FieldsetHTMLAttributes<HTMLFieldSetElement> {
  legend: React.ReactNode;
  description?: React.ReactNode;
  error?: React.ReactNode;
  required?: boolean;
  layout?: 'stack' | 'grid' | 'inline';
}

export const FieldGroup = React.forwardRef<HTMLFieldSetElement, FieldGroupProps>(function FieldGroup(
  { legend, description, error, required, layout = 'stack', id, className, children, disabled, ...props },
  ref,
) {
  const groupId = useAtlasId(id, 'atlas-field-group');
  const descriptionId = description ? `${groupId}-description` : undefined;
  const errorId = error ? `${groupId}-error` : undefined;
  return (
    <fieldset
      ref={ref}
      id={groupId}
      className={cx('atlas-field-group', className)}
      data-atlas-component="FieldGroup"
      data-state={disabled ? 'disabled' : error ? 'invalid' : 'default'}
      data-layout={layout}
      data-required={required || undefined}
      aria-describedby={joinIds(descriptionId, errorId)}
      disabled={disabled}
      {...props}
    >
      <legend className="atlas-field-group-legend">{legend}{required ? ' *' : null}</legend>
      {description ? <p id={descriptionId} className="atlas-field-description">{description}</p> : null}
      <div className="atlas-field-group-content">{children}</div>
      {error ? <p id={errorId} className="atlas-field-error">{error}</p> : null}
    </fieldset>
  );
});
