import * as React from 'react';
import { cx } from '../../utils/cx';
import { joinIds, useAtlasId } from '../../utils/ids';

export interface FormProps extends React.FormHTMLAttributes<HTMLFormElement> {
  title?: React.ReactNode;
  description?: React.ReactNode;
  errorSummary?: React.ReactNode;
  actions?: React.ReactNode;
}

export const Form = React.forwardRef<HTMLFormElement, FormProps>(function Form(
  { title, description, errorSummary, actions, id, className, children, noValidate = true, ...props },
  ref,
) {
  const formId = useAtlasId(id, 'atlas-form');
  const titleId = title ? `${formId}-title` : undefined;
  const descriptionId = description ? `${formId}-description` : undefined;
  return (
    <form
      ref={ref}
      id={formId}
      className={cx('atlas-form', className)}
      data-atlas-component="Form"
      data-state={errorSummary ? 'invalid' : 'default'}
      aria-labelledby={titleId}
      aria-describedby={joinIds(descriptionId)}
      noValidate={noValidate}
      {...props}
    >
      {title || description ? (
        <header className="atlas-form-header">
          {title ? <h2 id={titleId} className="atlas-form-title">{title}</h2> : null}
          {description ? <p id={descriptionId} className="atlas-form-description">{description}</p> : null}
        </header>
      ) : null}
      {errorSummary}
      <div className="atlas-form-body">{children}</div>
      {actions ? <div className="atlas-form-actions">{actions}</div> : null}
    </form>
  );
});
