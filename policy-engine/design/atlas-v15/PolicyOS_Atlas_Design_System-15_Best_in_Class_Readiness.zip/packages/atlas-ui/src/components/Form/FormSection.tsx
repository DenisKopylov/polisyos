import * as React from 'react';
import { cx } from '../../utils/cx';
import { joinIds, useAtlasId } from '../../utils/ids';

export interface FormSectionProps extends React.HTMLAttributes<HTMLElement> {
  title: React.ReactNode;
  description?: React.ReactNode;
  aside?: React.ReactNode;
}

export const FormSection = React.forwardRef<HTMLElement, FormSectionProps>(function FormSection(
  { title, description, aside, id, className, children, ...props },
  ref,
) {
  const sectionId = useAtlasId(id, 'atlas-form-section');
  const titleId = `${sectionId}-title`;
  const descriptionId = description ? `${sectionId}-description` : undefined;
  return (
    <section
      ref={ref}
      id={sectionId}
      className={cx('atlas-form-section', className)}
      data-atlas-component="FormSection"
      data-state="default"
      aria-labelledby={titleId}
      aria-describedby={joinIds(descriptionId)}
      {...props}
    >
      <div className="atlas-form-section-copy">
        <h3 id={titleId} className="atlas-form-section-title">{title}</h3>
        {description ? <p id={descriptionId} className="atlas-form-section-description">{description}</p> : null}
        {aside ? <div className="atlas-form-section-aside">{aside}</div> : null}
      </div>
      <div className="atlas-form-section-fields">{children}</div>
    </section>
  );
});
