import * as React from 'react';
import { cx } from '../../utils/cx';
import { useAtlasId } from '../../utils/ids';

export interface ValidationSummaryItem {
  id: string;
  label: string;
  message: React.ReactNode;
  href?: string;
}

export interface ValidationSummaryProps extends React.HTMLAttributes<HTMLElement> {
  title?: React.ReactNode;
  description?: React.ReactNode;
  items: ValidationSummaryItem[];
}

export const ValidationSummary = React.forwardRef<HTMLElement, ValidationSummaryProps>(function ValidationSummary(
  { title = 'There is a problem', description, items, id, className, ...props },
  ref,
) {
  const summaryId = useAtlasId(id, 'atlas-validation-summary');
  const titleId = `${summaryId}-title`;
  return (
    <section
      ref={ref}
      id={summaryId}
      className={cx('atlas-validation-summary', className)}
      data-atlas-component="ValidationSummary"
      data-state={items.length > 0 ? 'invalid' : 'empty'}
      role="alert"
      aria-labelledby={titleId}
      tabIndex={-1}
      {...props}
    >
      <h2 id={titleId} className="atlas-validation-summary-title">{title}</h2>
      {description ? <p className="atlas-validation-summary-description">{description}</p> : null}
      {items.length > 0 ? (
        <ul className="atlas-validation-summary-list">
          {items.map((item) => (
            <li key={item.id}>
              <a className="atlas-validation-summary-link" href={item.href ?? `#${item.id}`}>
                <strong>{item.label}:</strong> {item.message}
              </a>
            </li>
          ))}
        </ul>
      ) : null}
    </section>
  );
});
