import type * as React from 'react';
import { cx } from '../../utils/cx';
import { useAtlasId } from '../../utils/ids';
import { Badge } from '../Badge/Badge';

export type GovernanceGateStatus = 'pass' | 'review' | 'blocked';

const statusTone: Record<GovernanceGateStatus, 'success' | 'warning' | 'danger'> = {
  pass: 'success',
  review: 'warning',
  blocked: 'danger',
};

export interface GovernanceGateProps extends React.HTMLAttributes<HTMLElement> {
  title: React.ReactNode;
  status: GovernanceGateStatus;
  description?: React.ReactNode;
  evidenceCount?: number;
  action?: React.ReactNode;
}

export function GovernanceGate({ title, status, description, evidenceCount, action, id, className, ...props }: GovernanceGateProps) {
  const gateId = useAtlasId(id, 'atlas-governance-gate');
  const titleId = `${gateId}-title`;
  const descriptionId = description ? `${gateId}-description` : undefined;
  return (
    <section
      {...props}
      id={gateId}
      className={cx('atlas-governance-gate', className)}
      data-atlas-component="GovernanceGate"
      data-state={status}
      aria-labelledby={titleId}
      aria-describedby={descriptionId}
      data-status={status}
    >
      <header className="atlas-governance-header">
        <div>
          <h3 id={titleId} className="atlas-governance-title">{title}</h3>
          {description ? <p id={descriptionId} className="atlas-governance-description">{description}</p> : null}
          {typeof evidenceCount === 'number' ? <p className="atlas-run-meta">{evidenceCount} evidence items linked</p> : null}
        </div>
        <Badge tone={statusTone[status]} status>{status}</Badge>
      </header>
      {action ? <div>{action}</div> : null}
    </section>
  );
}
