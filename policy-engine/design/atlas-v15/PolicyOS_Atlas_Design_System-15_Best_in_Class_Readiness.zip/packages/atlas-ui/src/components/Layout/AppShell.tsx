import type * as React from 'react';
import { cx } from '../../utils/cx';

export interface AppShellProps extends React.HTMLAttributes<HTMLDivElement> {
  sidebar: React.ReactNode;
  topbar?: React.ReactNode;
  children: React.ReactNode;
  sidebarOpen?: boolean;
  onSidebarOpenChange?: (open: boolean) => void;
  sidebarId?: string;
  sidebarLabel?: string;
  contentLabel?: string;
  framed?: boolean;
}

export function AppShell({
  sidebar,
  topbar,
  children,
  sidebarOpen = false,
  onSidebarOpenChange,
  sidebarId = 'atlas-app-shell-sidebar',
  sidebarLabel = 'Primary navigation',
  contentLabel = 'Main content',
  framed = true,
  className,
  ...props
}: AppShellProps) {
  return (
    <div
      className={cx('atlas-app-shell', className)}
      data-atlas-component="AppShell"
      data-sidebar-open={sidebarOpen ? 'true' : 'false'}
      data-framed={framed ? 'true' : 'false'}
      {...props}
    >
      <button
        type="button"
        className="atlas-app-shell__scrim"
        aria-label="Close navigation"
        hidden={!sidebarOpen}
        onClick={() => onSidebarOpenChange?.(false)}
      />
      <aside id={sidebarId} className="atlas-app-shell__sidebar" aria-label={sidebarLabel}>
        {sidebar}
      </aside>
      <div className="atlas-app-shell__body">
        {topbar}
        <main className="atlas-app-shell__main" aria-label={contentLabel}>
          {children}
        </main>
      </div>
    </div>
  );
}
