import type * as React from 'react';
import { cx } from '../../utils/cx';

export interface ClusterProps extends React.HTMLAttributes<HTMLDivElement> {
  gap?: string;
  justify?: 'start' | 'center' | 'end' | 'between';
  align?: 'start' | 'center' | 'end' | 'stretch';
}

export function Cluster({ gap, justify = 'start', align = 'center', className, style, children, ...props }: ClusterProps) {
  const vars = { ...(style || {}), ...(gap ? { '--atlas-cluster-gap': gap } : {}) } as React.CSSProperties;
  return (
    <div
      className={cx('atlas-cluster', className)}
      style={vars}
      data-atlas-component="Cluster"
      data-justify={justify}
      data-align={align}
      {...props}
    >
      {children}
    </div>
  );
}
