import type * as React from 'react';
import { cx } from '../../utils/cx';

export interface ResponsiveGridProps extends React.HTMLAttributes<HTMLDivElement> {
  minItemWidth?: string;
  gap?: string;
  columns?: number;
  dense?: boolean;
}

export function ResponsiveGrid({ minItemWidth, gap, columns, dense = false, className, style, children, ...props }: ResponsiveGridProps) {
  const vars = {
    ...(style || {}),
    ...(minItemWidth ? { '--atlas-grid-min': minItemWidth } : {}),
    ...(gap ? { '--atlas-grid-gap': gap } : {}),
    ...(columns ? { '--atlas-grid-max-columns': String(columns) } : {}),
  } as React.CSSProperties;
  return (
    <div
      className={cx('atlas-responsive-grid', className)}
      style={vars}
      data-atlas-component="ResponsiveGrid"
      data-state={dense ? 'dense' : 'default'}
      data-dense={dense ? 'true' : undefined}
      {...props}
    >
      {children}
    </div>
  );
}
