import type * as React from 'react';
import { cx } from '../../utils/cx';

export interface ScrollAreaProps extends React.HTMLAttributes<HTMLDivElement> {
  label: string;
  maxBlockSize?: string;
}

export function ScrollArea({ label, maxBlockSize, className, style, children, ...props }: ScrollAreaProps) {
  const vars = { ...(style || {}), ...(maxBlockSize ? { '--atlas-scroll-area-max': maxBlockSize } : {}) } as React.CSSProperties;
  return (
    <div
      className={cx('atlas-scroll-area', className)}
      style={vars}
      data-atlas-component="ScrollArea"
      data-state="scrollable"
      role="region"
      aria-label={label}
      tabIndex={0}
      {...props}
    >
      {children}
    </div>
  );
}
