import type * as React from 'react';
import { cx } from '../../utils/cx';

export interface SidebarNavItem {
  id: string;
  label: React.ReactNode;
  href?: string;
  icon?: React.ReactNode;
  meta?: React.ReactNode;
  disabled?: boolean;
}

export interface SidebarNavProps extends React.HTMLAttributes<HTMLElement> {
  label?: string;
  items: SidebarNavItem[];
  activeId?: string;
  onNavigate?: (id: string) => void;
  collapsed?: boolean;
}

export function SidebarNav({ label = 'Primary navigation', items, activeId, onNavigate, collapsed = false, className, ...props }: SidebarNavProps) {
  return (
    <nav
      className={cx('atlas-sidebar-nav', className)}
      aria-label={label}
      data-atlas-component="SidebarNav"
      data-state={collapsed ? 'collapsed' : 'expanded'}
      {...props}
    >
      {items.map((item) => {
        const active = item.id === activeId;
        const content = (
          <>
            {item.icon ? <span className="atlas-sidebar-nav__icon" aria-hidden="true">{item.icon}</span> : null}
            <span className="atlas-sidebar-nav__label">{item.label}</span>
            {item.meta ? <span className="atlas-sidebar-nav__meta">{item.meta}</span> : null}
          </>
        );
        if (item.href && !item.disabled) {
          return <a key={item.id} className="atlas-sidebar-nav__item" href={item.href} aria-current={active ? 'page' : undefined} data-state={active ? 'active' : 'default'}>{content}</a>;
        }
        return (
          <button
            key={item.id}
            type="button"
            className="atlas-sidebar-nav__item"
            aria-current={active ? 'page' : undefined}
            disabled={item.disabled}
            data-state={item.disabled ? 'disabled' : active ? 'active' : 'default'}
            onClick={() => onNavigate?.(item.id)}
          >
            {content}
          </button>
        );
      })}
    </nav>
  );
}
