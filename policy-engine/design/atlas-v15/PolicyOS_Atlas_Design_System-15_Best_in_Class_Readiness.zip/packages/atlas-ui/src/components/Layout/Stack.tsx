import type * as React from 'react';
import { cx } from '../../utils/cx';

export interface StackProps extends React.HTMLAttributes<HTMLDivElement> {
  gap?: string;
  align?: 'stretch' | 'start' | 'center' | 'end';
}

export function Stack({ gap, align = 'stretch', className, style, children, ...props }: StackProps) {
  const vars = { ...(style || {}), ...(gap ? { '--atlas-stack-gap': gap } : {}) } as React.CSSProperties;
  return (
    <div
      className={cx('atlas-stack', className)}
      style={vars}
      data-atlas-component="Stack"
      data-align={align}
      {...props}
    >
      {children}
    </div>
  );
}
