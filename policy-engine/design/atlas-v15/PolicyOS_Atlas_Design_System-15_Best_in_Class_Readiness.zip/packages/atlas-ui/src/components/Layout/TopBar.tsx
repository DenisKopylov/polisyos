import type * as React from 'react';
import { cx } from '../../utils/cx';

export interface TopBarProps extends React.HTMLAttributes<HTMLElement> {
  title: React.ReactNode;
  eyebrow?: React.ReactNode;
  actions?: React.ReactNode;
  onMenuClick?: () => void;
  menuButtonLabel?: string;
  menuControls?: string;
  menuExpanded?: boolean;
}

export function TopBar({ title, eyebrow, actions, onMenuClick, menuButtonLabel = 'Open navigation', menuControls, menuExpanded = false, className, ...props }: TopBarProps) {
  return (
    <header className={cx('atlas-topbar', className)} data-atlas-component="TopBar" data-state={actions ? 'with-actions' : 'default'} {...props}>
      {onMenuClick ? (
        <button
          type="button"
          className="atlas-topbar__menu"
          aria-label={menuButtonLabel}
          aria-controls={menuControls}
          aria-expanded={menuExpanded ? 'true' : 'false'}
          onClick={onMenuClick}
        >
          <span aria-hidden="true">☰</span>
        </button>
      ) : null}
      <div className="atlas-topbar__copy">
        {eyebrow ? <p className="atlas-topbar__eyebrow">{eyebrow}</p> : null}
        <p className="atlas-topbar__title">{title}</p>
      </div>
      {actions ? <div className="atlas-topbar__actions">{actions}</div> : null}
    </header>
  );
}
