import type * as React from 'react';
import { cx } from '../../utils/cx';

export interface MetricCardProps extends React.HTMLAttributes<HTMLElement> {
  label: string;
  value: React.ReactNode;
  hint?: React.ReactNode;
  badge?: React.ReactNode;
}

export function MetricCard({ label, value, hint, badge, className, ...props }: MetricCardProps) {
  const state = badge ? 'with-badge' : 'default';
  return (
    <section
      className={cx('atlas-metric-card', className)}
      data-atlas-component="MetricCard"
      data-state={state}
      data-has-badge={Boolean(badge) || undefined}
      aria-label={`${label}: ${String(value)}${hint ? `. ${String(hint)}` : ''}`}
      {...props}
    >
      <div className="atlas-run-card-header">
        <span className="atlas-metric-label">{label}</span>
        {badge}
      </div>
      <strong className="atlas-metric-value">{value}</strong>
      {hint ? <p className="atlas-metric-hint">{hint}</p> : null}
    </section>
  );
}
