import * as React from 'react';
import { cx } from '../../utils/cx';
import { useAtlasId } from '../../utils/ids';

export interface PanelProps extends React.HTMLAttributes<HTMLElement> {
  title?: React.ReactNode;
  eyebrow?: React.ReactNode;
  description?: React.ReactNode;
  actions?: React.ReactNode;
  hero?: boolean;
  headingLevel?: 2 | 3 | 4;
}

export const Panel = React.forwardRef<HTMLElement, PanelProps>(function Panel(
  { title, eyebrow, description, actions, hero = false, headingLevel = 2, id, className, children, ...props },
  ref,
) {
  const panelId = useAtlasId(id, 'atlas-panel');
  const titleId = title ? `${panelId}-title` : undefined;
  const Heading = (`h${headingLevel}`) as 'h2';
  return (
    <section
      ref={ref}
      id={panelId}
      className={cx('atlas-panel', className)}
      data-atlas-component="Panel"
      data-hero={hero ? 'true' : 'false'}
      data-state={hero ? 'hero' : actions ? 'with-actions' : 'default'}
      aria-labelledby={titleId}
      {...props}
    >
      {(title || eyebrow || description || actions) ? (
        <header className="atlas-panel-header">
          <div>
            {eyebrow ? <p className="atlas-eyebrow">{eyebrow}</p> : null}
            {title ? <Heading id={titleId} className="atlas-panel-title">{title}</Heading> : null}
            {description ? <p className="atlas-panel-description">{description}</p> : null}
          </div>
          {actions ? <div>{actions}</div> : null}
        </header>
      ) : null}
      {children}
    </section>
  );
});
