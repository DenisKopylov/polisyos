import * as React from 'react';
import { cx } from '../../utils/cx';
import type { Density } from '../../types';

export interface DashboardShellProps extends React.HTMLAttributes<HTMLDivElement> {
  rail: React.ReactNode;
  topBar?: React.ReactNode;
  navOpen?: boolean;
  onNavDismiss?: () => void;
  mainId?: string;
  mainLabel?: string;
  density?: Density;
  children?: React.ReactNode;
}

export const DashboardShell = React.forwardRef<HTMLDivElement, DashboardShellProps>(function DashboardShell(
  { rail, topBar, navOpen = false, onNavDismiss, mainId = 'main-content', mainLabel = 'Dashboard workspace', density, className, children, ...props },
  ref,
) {
  return (
    <div
      ref={ref}
      className={cx('atlas-dashboard-frame', className)}
      data-atlas-component="DashboardShell"
      data-state={navOpen ? 'nav-open' : 'default'}
      data-density={density}
      {...props}
    >
      <div className="atlas-dashboard-shell" data-nav-open={navOpen ? 'true' : 'false'}>
        {topBar}
        {onNavDismiss ? (
          <button
            type="button"
            className="atlas-dashboard-backdrop"
            aria-label="Close navigation"
            onClick={onNavDismiss}
          />
        ) : null}
        <div className="atlas-dashboard-grid">
          {rail}
          <main id={mainId} className="atlas-dashboard-main" tabIndex={-1} aria-label={mainLabel}>
            {children}
          </main>
        </div>
      </div>
    </div>
  );
});
