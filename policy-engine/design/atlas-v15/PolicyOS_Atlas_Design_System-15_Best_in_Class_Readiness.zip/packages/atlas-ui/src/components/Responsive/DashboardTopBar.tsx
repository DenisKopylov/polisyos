import * as React from 'react';
import { cx } from '../../utils/cx';

export interface DashboardTopBarProps extends React.HTMLAttributes<HTMLElement> {
  title: React.ReactNode;
  eyebrow?: React.ReactNode;
  actions?: React.ReactNode;
  menuButton?: React.ReactNode;
}

export function DashboardTopBar({ title, eyebrow, actions, menuButton, className, ...props }: DashboardTopBarProps) {
  return (
    <header className={cx('atlas-dashboard-topbar', className)} data-atlas-component="DashboardTopBar" data-state={menuButton ? 'menu-available' : 'default'} {...props}>
      <div className="atlas-dashboard-topbar__start">
        {menuButton}
        <div className="atlas-dashboard-topbar__copy">
          {eyebrow ? <p className="atlas-eyebrow">{eyebrow}</p> : null}
          <h1 className="atlas-dashboard-topbar__title">{title}</h1>
        </div>
      </div>
      {actions ? <div className="atlas-dashboard-topbar__actions">{actions}</div> : null}
    </header>
  );
}
