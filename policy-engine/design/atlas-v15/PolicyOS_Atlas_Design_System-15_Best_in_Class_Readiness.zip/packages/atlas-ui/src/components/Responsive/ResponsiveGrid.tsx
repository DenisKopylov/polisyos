import * as React from 'react';
import { cx } from '../../utils/cx';

export type ResponsiveGridVariant = 'auto' | 'hero' | 'metrics' | 'charts' | 'cards';

export interface ResponsiveGridProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: ResponsiveGridVariant;
  minItemWidth?: string;
  gap?: string;
}

export function ResponsiveGrid({ variant = 'auto', minItemWidth, gap, className, style, children, ...props }: ResponsiveGridProps) {
  const customStyle: React.CSSProperties = {
    ...style,
    '--atlas-responsive-grid-min': minItemWidth,
    '--atlas-responsive-grid-custom-gap': gap,
  };
  return (
    <div
      className={cx('atlas-responsive-grid', className)}
      data-atlas-component="ResponsiveGrid"
      data-layout={variant}
      data-state="auto-fit"
      style={customStyle}
      {...props}
    >
      {children}
    </div>
  );
}
