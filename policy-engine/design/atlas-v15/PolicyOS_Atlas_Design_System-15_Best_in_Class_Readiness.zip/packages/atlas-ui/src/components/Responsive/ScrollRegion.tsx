import * as React from 'react';
import { cx } from '../../utils/cx';

export type ScrollRegionAxis = 'x' | 'y' | 'both';

export interface ScrollRegionProps extends React.HTMLAttributes<HTMLDivElement> {
  axis?: ScrollRegionAxis;
  label?: string;
  focusable?: boolean;
}

export function ScrollRegion({ axis = 'x', label, focusable = true, className, children, ...props }: ScrollRegionProps) {
  return (
    <div
      className={cx('atlas-scroll-region', className)}
      data-atlas-component="ScrollRegion"
      data-axis={axis}
      data-state="overflow-ready"
      role={label ? 'region' : props.role}
      aria-label={label ?? props['aria-label']}
      tabIndex={focusable ? 0 : props.tabIndex}
      {...props}
    >
      {children}
    </div>
  );
}
