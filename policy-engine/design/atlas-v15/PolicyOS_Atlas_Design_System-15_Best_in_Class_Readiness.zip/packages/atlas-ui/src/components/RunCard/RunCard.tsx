import * as React from 'react';
import { cx } from '../../utils/cx';
import type { AtlasStatus } from '../../types';
import { Badge } from '../Badge/Badge';

const statusTone: Record<AtlasStatus, 'success' | 'warning' | 'danger' | 'neutral' | 'info'> = {
  success: 'success',
  failed: 'danger',
  blocked: 'danger',
  running: 'warning',
  pending: 'neutral',
  draft: 'neutral',
  review: 'info',
};

export interface RunCardProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  runId: string;
  status: AtlasStatus;
  duration: string;
  artifacts: number;
  summary?: React.ReactNode;
}

export const RunCard = React.forwardRef<HTMLButtonElement, RunCardProps>(function RunCard(
  { runId, status, duration, artifacts, summary, disabled, className, ...props },
  ref,
) {
  return (
    <button
      ref={ref}
      type="button"
      className={cx('atlas-run-card atlas-card-button', className)}
      data-atlas-component="RunCard"
      data-status={status}
      data-state={disabled ? 'disabled' : status}
      disabled={disabled}
      aria-label={`Open run ${runId}. Status ${status}. Duration ${duration}. ${artifacts} artifacts.`}
      {...props}
    >
      <span className="atlas-run-card-header">
        <span>
          <strong className="atlas-card-title">{runId}</strong>
          <span className="atlas-run-meta">{duration} · {artifacts} artifacts</span>
        </span>
        <Badge tone={statusTone[status]}>{status}</Badge>
      </span>
      {summary ? <span className="atlas-card-description">{summary}</span> : null}
    </button>
  );
});
