import type * as React from 'react';
import { cx } from '../../utils/cx';

export interface SkeletonProps extends React.HTMLAttributes<HTMLSpanElement> {
  label?: string;
}

export function Skeleton({ label = 'Loading content', className, ...props }: SkeletonProps) {
  return <span className={cx('atlas-skeleton', className)} data-atlas-component="Skeleton" data-state="loading" role="status" aria-live="polite" aria-label={label} {...props} />;
}
