import * as React from 'react';
import { cx } from '../../utils/cx';
import { useAtlasId } from '../../utils/ids';

export interface TabItem {
  id: string;
  label: React.ReactNode;
  panel: React.ReactNode;
  disabled?: boolean;
}

export interface TabsProps extends React.HTMLAttributes<HTMLDivElement> {
  items: TabItem[];
  defaultValue?: string;
  value?: string;
  onValueChange?: (value: string) => void;
  label: string;
}

export function Tabs({ items, defaultValue, value, onValueChange, label, id, className, ...props }: TabsProps) {
  const rootId = useAtlasId(id, 'atlas-tabs');
  const firstEnabled = items.find((item) => !item.disabled)?.id ?? items[0]?.id ?? '';
  const [internalValue, setInternalValue] = React.useState(defaultValue ?? firstEnabled);
  const activeValue = value ?? internalValue;

  const setValue = (next: string, moveFocus = false) => {
    if (value === undefined) setInternalValue(next);
    onValueChange?.(next);
    if (moveFocus && typeof document !== 'undefined') {
      window.requestAnimationFrame?.(() => {
        document.getElementById(`${rootId}-tab-${next}`)?.focus();
      });
    }
  };

  const onKeyDown: React.KeyboardEventHandler<HTMLDivElement> = (event) => {
    const enabled = items.filter((item) => !item.disabled);
    const currentIndex = enabled.findIndex((item) => item.id === activeValue);
    if (currentIndex < 0 || enabled.length === 0) return;
    let nextIndex = currentIndex;
    if (event.key === 'ArrowRight') nextIndex = (currentIndex + 1) % enabled.length;
    else if (event.key === 'ArrowLeft') nextIndex = (currentIndex - 1 + enabled.length) % enabled.length;
    else if (event.key === 'Home') nextIndex = 0;
    else if (event.key === 'End') nextIndex = enabled.length - 1;
    else return;
    event.preventDefault();
    setValue(enabled[nextIndex].id, true);
  };

  return (
    <div className={cx('atlas-tabs', className)} data-atlas-component="Tabs" data-state="ready" id={rootId} {...props}>
      <div className="atlas-tabs-list" role="tablist" aria-label={label} onKeyDown={onKeyDown}>
        {items.map((item) => {
          const selected = item.id === activeValue;
          return (
            <button
              key={item.id}
              type="button"
              className="atlas-tab"
              id={`${rootId}-tab-${item.id}`}
              role="tab"
              data-state={item.disabled ? 'disabled' : selected ? 'selected' : 'default'}
              aria-selected={selected}
              aria-controls={`${rootId}-panel-${item.id}`}
              tabIndex={selected ? 0 : -1}
              disabled={item.disabled}
              onClick={() => setValue(item.id)}
            >
              {item.label}
            </button>
          );
        })}
      </div>
      {items.map((item) => {
        const selected = item.id === activeValue;
        return (
          <section
            key={item.id}
            id={`${rootId}-panel-${item.id}`}
            role="tabpanel"
            aria-labelledby={`${rootId}-tab-${item.id}`}
            data-state={selected ? 'selected' : 'hidden'}
            hidden={!selected}
            tabIndex={0}
          >
            {selected ? item.panel : null}
          </section>
        );
      })}
    </div>
  );
}
