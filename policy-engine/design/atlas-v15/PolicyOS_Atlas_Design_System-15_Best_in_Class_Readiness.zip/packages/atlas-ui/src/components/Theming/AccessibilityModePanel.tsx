import * as React from 'react';
import { cx } from '../../utils/cx';
import { joinIds, useAtlasId } from '../../utils/ids';
import type { Density } from '../../types';
import type { AtlasContrastMode, AtlasMotionMode, AtlasTextScale, AtlasThemeMode, AtlasThemeSettings, AtlasTransparencyMode } from './ThemeProvider';

export interface AccessibilityModePanelProps extends Omit<React.FieldsetHTMLAttributes<HTMLFieldSetElement>, 'onChange'> {
  settings?: AtlasThemeSettings;
  onSettingsChange?: (settings: AtlasThemeSettings) => void;
  legend?: React.ReactNode;
  description?: React.ReactNode;
}

const DEFAULTS: Required<AtlasThemeSettings> = {
  theme: 'auto',
  contrast: 'auto',
  motion: 'auto',
  transparency: 'auto',
  density: 'comfortable',
  textScale: 'standard',
  colorSafe: false,
};

export const AccessibilityModePanel = React.forwardRef<HTMLFieldSetElement, AccessibilityModePanelProps>(function AccessibilityModePanel(
  { settings, onSettingsChange, legend = 'Accessibility modes', description = 'Tune the interface across contrast, motion, transparency, density, text scale and color-safe encodings.', id, className, disabled, ...props },
  ref,
) {
  const panelId = useAtlasId(id, 'atlas-a11y-mode-panel');
  const descriptionId = description ? `${panelId}-description` : undefined;
  const current: Required<AtlasThemeSettings> = { ...DEFAULTS, ...settings };

  function update(next: Partial<AtlasThemeSettings>) {
    onSettingsChange?.({ ...current, ...next });
  }

  return (
    <fieldset
      ref={ref}
      id={panelId}
      className={cx('atlas-a11y-mode-panel', className)}
      data-atlas-component="AccessibilityModePanel"
      data-state={disabled ? 'disabled' : 'default'}
      aria-describedby={joinIds(descriptionId)}
      disabled={disabled}
      {...props}
    >
      <legend className="atlas-a11y-mode-panel__legend">{legend}</legend>
      {description ? <p id={descriptionId} className="atlas-a11y-mode-panel__description">{description}</p> : null}
      <div className="atlas-a11y-mode-panel__grid">
        <label className="atlas-a11y-mode-panel__field">
          <span>Theme</span>
          <select value={current.theme} onChange={(event) => update({ theme: event.currentTarget.value as AtlasThemeMode })}>
            <option value="auto">Auto</option>
            <option value="light">Light</option>
            <option value="dark">Dark</option>
            <option value="high-contrast">High contrast</option>
          </select>
        </label>
        <label className="atlas-a11y-mode-panel__field">
          <span>Contrast</span>
          <select value={current.contrast} onChange={(event) => update({ contrast: event.currentTarget.value as AtlasContrastMode })}>
            <option value="auto">Auto</option>
            <option value="standard">Standard</option>
            <option value="more">More</option>
            <option value="high">High</option>
          </select>
        </label>
        <label className="atlas-a11y-mode-panel__field">
          <span>Motion</span>
          <select value={current.motion} onChange={(event) => update({ motion: event.currentTarget.value as AtlasMotionMode })}>
            <option value="auto">Auto</option>
            <option value="no-preference">No preference</option>
            <option value="reduced">Reduced</option>
          </select>
        </label>
        <label className="atlas-a11y-mode-panel__field">
          <span>Transparency</span>
          <select value={current.transparency} onChange={(event) => update({ transparency: event.currentTarget.value as AtlasTransparencyMode })}>
            <option value="auto">Auto</option>
            <option value="no-preference">No preference</option>
            <option value="reduced">Reduced</option>
          </select>
        </label>
        <label className="atlas-a11y-mode-panel__field">
          <span>Density</span>
          <select value={current.density} onChange={(event) => update({ density: event.currentTarget.value as Density })}>
            <option value="comfortable">Comfortable</option>
            <option value="compact">Compact</option>
            <option value="condensed">Condensed</option>
          </select>
        </label>
        <label className="atlas-a11y-mode-panel__field">
          <span>Text scale</span>
          <select value={current.textScale} onChange={(event) => update({ textScale: event.currentTarget.value as AtlasTextScale })}>
            <option value="standard">Standard</option>
            <option value="large">Large</option>
          </select>
        </label>
        <label className="atlas-a11y-mode-panel__check">
          <input type="checkbox" checked={current.colorSafe} onChange={(event) => update({ colorSafe: event.currentTarget.checked })} />
          <span>Color-safe status and chart palette</span>
        </label>
      </div>
    </fieldset>
  );
});
