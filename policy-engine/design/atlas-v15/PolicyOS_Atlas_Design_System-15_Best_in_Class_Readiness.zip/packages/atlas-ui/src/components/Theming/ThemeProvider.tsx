import * as React from 'react';
import { cx } from '../../utils/cx';
import type { Density } from '../../types';

export type AtlasThemeMode = 'auto' | 'light' | 'dark' | 'high-contrast';
export type AtlasContrastMode = 'auto' | 'standard' | 'more' | 'high';
export type AtlasMotionMode = 'auto' | 'no-preference' | 'reduced';
export type AtlasTransparencyMode = 'auto' | 'no-preference' | 'reduced';
export type AtlasTextScale = 'standard' | 'large';

export interface AtlasThemeSettings {
  theme?: AtlasThemeMode;
  contrast?: AtlasContrastMode;
  motion?: AtlasMotionMode;
  transparency?: AtlasTransparencyMode;
  density?: Density;
  textScale?: AtlasTextScale;
  colorSafe?: boolean;
}

export interface ThemeProviderProps extends React.HTMLAttributes<HTMLDivElement>, AtlasThemeSettings {
  applyToRoot?: boolean;
  root?: HTMLElement | null;
  persist?: boolean;
  storageKey?: string;
}

const DEFAULT_STORAGE_KEY = 'atlas.theme.settings';

export function resolveAtlasThemeAttributes(settings: AtlasThemeSettings): Record<string, string | undefined> {
  const theme = settings.theme ?? 'auto';
  const contrast = settings.contrast ?? 'auto';
  const motion = settings.motion ?? 'auto';
  const transparency = settings.transparency ?? 'auto';
  const density = settings.density ?? 'comfortable';
  const textScale = settings.textScale ?? 'standard';
  const colorSafe = settings.colorSafe === true;

  return {
    'data-atlas-theme': theme,
    'data-theme': theme === 'light' || theme === 'dark' || theme === 'high-contrast' ? theme : undefined,
    'data-atlas-contrast': contrast,
    'data-contrast': contrast === 'more' || contrast === 'high' ? 'more' : undefined,
    'data-atlas-motion': motion,
    'data-motion': motion === 'reduced' ? 'reduced' : undefined,
    'data-atlas-transparency': transparency,
    'data-transparency': transparency === 'reduced' ? 'reduced' : undefined,
    'data-atlas-density': density,
    'data-density': density,
    'data-atlas-text-scale': textScale,
    'data-text-scale': textScale === 'large' ? 'large' : undefined,
    'data-atlas-color-safe': colorSafe ? 'true' : undefined,
    'data-color-safe': colorSafe ? 'true' : undefined,
  };
}

export function applyAtlasThemeAttributes(target: HTMLElement, settings: AtlasThemeSettings): () => void {
  const attrs = resolveAtlasThemeAttributes(settings);
  const previous = new Map<string, string | null>();
  Object.keys(attrs).forEach((name) => previous.set(name, target.getAttribute(name)));
  Object.entries(attrs).forEach(([name, value]) => {
    if (value === undefined) target.removeAttribute(name);
    else target.setAttribute(name, value);
  });
  return () => {
    previous.forEach((value, name) => {
      if (value === null) target.removeAttribute(name);
      else target.setAttribute(name, value);
    });
  };
}

export const ThemeProvider = React.forwardRef<HTMLDivElement, ThemeProviderProps>(function ThemeProvider(
  {
    theme = 'auto',
    contrast = 'auto',
    motion = 'auto',
    transparency = 'auto',
    density = 'comfortable',
    textScale = 'standard',
    colorSafe = false,
    applyToRoot = true,
    root,
    persist = false,
    storageKey = DEFAULT_STORAGE_KEY,
    className,
    children,
    ...props
  },
  ref,
) {
  const settings = React.useMemo<AtlasThemeSettings>(() => ({ theme, contrast, motion, transparency, density, textScale, colorSafe }), [theme, contrast, motion, transparency, density, textScale, colorSafe]);

  React.useEffect(() => {
    if (!applyToRoot) return undefined;
    const target = root ?? (typeof document !== 'undefined' ? document.documentElement : null);
    if (!target) return undefined;
    const restore = applyAtlasThemeAttributes(target, settings);
    if (persist && typeof window !== 'undefined') {
      try { window.localStorage.setItem(storageKey, JSON.stringify(settings)); } catch { /* storage may be unavailable */ }
    }
    return restore;
  }, [applyToRoot, root, settings, persist, storageKey]);

  const attrs = resolveAtlasThemeAttributes(settings);
  return (
    <div
      ref={ref}
      className={cx('atlas-theme-provider', className)}
      data-atlas-component="ThemeProvider"
      data-state={theme}
      data-contrast={contrast}
      data-motion={motion}
      data-transparency={transparency}
      data-density={density}
      data-text-scale={textScale}
      data-color-safe={colorSafe ? 'true' : 'false'}
      {...attrs}
      {...props}
    >
      {children}
    </div>
  );
});
