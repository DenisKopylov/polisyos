import * as React from 'react';
import { cx } from '../../utils/cx';
import type { AtlasThemeMode } from './ThemeProvider';

export interface ThemeToggleProps extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, 'value' | 'onChange'> {
  value?: AtlasThemeMode;
  defaultValue?: AtlasThemeMode;
  options?: AtlasThemeMode[];
  onValueChange?: (value: AtlasThemeMode) => void;
  labels?: Partial<Record<AtlasThemeMode, string>>;
}

const DEFAULT_OPTIONS: AtlasThemeMode[] = ['auto', 'light', 'dark', 'high-contrast'];
const DEFAULT_LABELS: Record<AtlasThemeMode, string> = {
  auto: 'Auto',
  light: 'Light',
  dark: 'Dark',
  'high-contrast': 'High contrast',
};

export const ThemeToggle = React.forwardRef<HTMLButtonElement, ThemeToggleProps>(function ThemeToggle(
  { value, defaultValue = 'auto', options = DEFAULT_OPTIONS, onValueChange, labels, className, disabled, type = 'button', ...props },
  ref,
) {
  const [internalValue, setInternalValue] = React.useState<AtlasThemeMode>(defaultValue);
  const current = value ?? internalValue;
  const mergedLabels = { ...DEFAULT_LABELS, ...labels };
  const index = Math.max(0, options.indexOf(current));
  const next = options[(index + 1) % options.length] ?? 'auto';

  function activate() {
    if (disabled) return;
    if (value === undefined) setInternalValue(next);
    onValueChange?.(next);
  }

  return (
    <button
      ref={ref}
      type={type}
      className={cx('atlas-theme-toggle', className)}
      data-atlas-component="ThemeToggle"
      data-state={disabled ? 'disabled' : current}
      data-theme-value={current}
      disabled={disabled}
      aria-label={`Theme: ${mergedLabels[current]}. Activate to switch to ${mergedLabels[next]}.`}
      onClick={activate}
      {...props}
    >
      <span className="atlas-theme-toggle__indicator" aria-hidden="true" />
      <span className="atlas-theme-toggle__label">{mergedLabels[current]}</span>
    </button>
  );
});
