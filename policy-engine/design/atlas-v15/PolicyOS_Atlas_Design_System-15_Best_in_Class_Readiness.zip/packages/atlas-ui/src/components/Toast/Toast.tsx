import type * as React from 'react';
import { cx } from '../../utils/cx';
import type { AtlasTone } from '../../types';

export interface ToastProps extends React.HTMLAttributes<HTMLDivElement> {
  tone?: Exclude<AtlasTone, 'neutral'>;
  title: React.ReactNode;
  message?: React.ReactNode;
  action?: React.ReactNode;
}

export function Toast({ tone = 'info', title, message, action, className, ...props }: ToastProps) {
  const role = tone === 'danger' ? 'alert' : 'status';
  return (
    <div
      className={cx('atlas-toast', className)}
      data-atlas-component="Toast"
      data-tone={tone}
      data-state={action ? 'with-action' : tone}
      role={role}
      aria-live={tone === 'danger' ? 'assertive' : 'polite'}
      {...props}
    >
      <div className="atlas-toast-header">
        <div>
          <p className="atlas-toast-title">{title}</p>
          {message ? <p className="atlas-toast-message">{message}</p> : null}
        </div>
        {action}
      </div>
    </div>
  );
}
