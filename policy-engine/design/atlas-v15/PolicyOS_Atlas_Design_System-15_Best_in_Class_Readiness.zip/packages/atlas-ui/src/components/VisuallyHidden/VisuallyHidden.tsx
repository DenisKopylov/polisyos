import type * as React from 'react';
import { cx } from '../../utils/cx';

export interface VisuallyHiddenProps extends React.HTMLAttributes<HTMLSpanElement> {}

export function VisuallyHidden({ className, ...props }: VisuallyHiddenProps) {
  return <span className={cx('atlas-visually-hidden', className)} {...props} />;
}
