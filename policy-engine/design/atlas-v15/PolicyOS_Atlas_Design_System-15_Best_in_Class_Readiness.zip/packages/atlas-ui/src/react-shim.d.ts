declare namespace React {
  type Key = string | number;
  type ReactNode = any;
  type ReactElement = any;
  type CSSProperties = Record<string, string | number | undefined | null>;
  type Ref<T> = ((instance: T | null) => void) | { current: T | null } | null;
  interface Attributes { key?: Key; }
  interface RefAttributes<T> { ref?: Ref<T>; }
  interface ForwardRefExoticComponent<P> { (props: P): ReactElement | null; displayName?: string; }
  function forwardRef<T, P = {}>(render: (props: P, ref: Ref<T>) => ReactElement | null): ForwardRefExoticComponent<P & RefAttributes<T>>;
  function useId(): string;
  function useEffect(effect: () => void | (() => void), deps?: unknown[]): void;
  function useMemo<T>(factory: () => T, deps: unknown[]): T;
  function useRef<T>(initialValue: T | null): { current: T | null };
  function useState<S>(initialState: S | (() => S)): [S, (next: S | ((previous: S) => S)) => void];
  interface SyntheticEvent<T = Element> { currentTarget: T; target: EventTarget; preventDefault(): void; stopPropagation(): void; }
  interface FocusEvent<T = Element> extends SyntheticEvent<T> {}
  interface KeyboardEvent<T = Element> extends SyntheticEvent<T> { key: string; shiftKey: boolean; }
  interface MouseEvent<T = Element> extends SyntheticEvent<T> {}
  type EventHandler<E> = (event: E) => void;
  type FocusEventHandler<T = Element> = EventHandler<FocusEvent<T>>;
  type KeyboardEventHandler<T = Element> = EventHandler<KeyboardEvent<T>>;
  type MouseEventHandler<T = Element> = EventHandler<MouseEvent<T>>;
  type ChangeEvent<T = Element> = SyntheticEvent<T>;
  type ChangeEventHandler<T = Element> = EventHandler<ChangeEvent<T>>;
  interface DOMAttributes<T> { children?: ReactNode; onClick?: MouseEventHandler<T>; onKeyDown?: KeyboardEventHandler<T>; onKeyUp?: KeyboardEventHandler<T>; onChange?: ChangeEventHandler<T>; onInput?: ChangeEventHandler<T>; onBlur?: FocusEventHandler<T>; onFocus?: FocusEventHandler<T>; }
  interface AriaAttributes {
    'aria-activedescendant'?: string; 'aria-atomic'?: boolean | 'false' | 'true'; 'aria-busy'?: boolean | 'false' | 'true'; 'aria-controls'?: string; 'aria-current'?: boolean | 'false' | 'true' | 'page' | 'step' | 'location' | 'date' | 'time'; 'aria-describedby'?: string; 'aria-disabled'?: boolean | 'false' | 'true'; 'aria-expanded'?: boolean | 'false' | 'true'; 'aria-haspopup'?: boolean | 'false' | 'true' | 'menu' | 'listbox' | 'tree' | 'grid' | 'dialog'; 'aria-hidden'?: boolean | 'false' | 'true'; 'aria-invalid'?: boolean | 'false' | 'true' | 'grammar' | 'spelling'; 'aria-label'?: string; 'aria-labelledby'?: string; 'aria-autocomplete'?: 'none' | 'inline' | 'list' | 'both'; 'aria-live'?: 'off' | 'assertive' | 'polite'; 'aria-modal'?: boolean | 'false' | 'true'; 'aria-pressed'?: boolean | 'false' | 'true' | 'mixed'; 'aria-required'?: boolean | 'false' | 'true'; 'aria-selected'?: boolean | 'false' | 'true'; 'aria-valuemin'?: number | string; 'aria-valuemax'?: number | string; 'aria-valuenow'?: number | string; 'aria-valuetext'?: string; 'aria-orientation'?: 'horizontal' | 'vertical';
  }
  interface HTMLAttributes<T> extends DOMAttributes<T>, AriaAttributes { id?: string; key?: Key; ref?: Ref<T>; className?: string; style?: CSSProperties; title?: string; role?: string; tabIndex?: number; hidden?: boolean; inert?: string; lang?: string; dir?: 'ltr' | 'rtl' | 'auto'; spellCheck?: boolean; 'data-atlas-component'?: string; [key: `data-${string}`]: string | number | boolean | undefined; }
  interface ButtonHTMLAttributes<T> extends HTMLAttributes<T> { autoFocus?: boolean; disabled?: boolean; form?: string; name?: string; type?: 'button' | 'submit' | 'reset'; value?: string | number; }
  interface InputHTMLAttributes<T> extends HTMLAttributes<T> { accept?: string; autoComplete?: string; checked?: boolean; defaultChecked?: boolean; defaultValue?: string | number; disabled?: boolean; inputMode?: string; list?: string; max?: string | number; maxLength?: number; min?: string | number; minLength?: number; multiple?: boolean; name?: string; pattern?: string; placeholder?: string; readOnly?: boolean; required?: boolean; step?: string | number; type?: string; value?: string | number; }
  interface SelectHTMLAttributes<T> extends HTMLAttributes<T> { disabled?: boolean; name?: string; required?: boolean; value?: string | number; defaultValue?: string | number; multiple?: boolean; }
  interface TextareaHTMLAttributes<T> extends InputHTMLAttributes<T> { rows?: number; }
  interface TableHTMLAttributes<T> extends HTMLAttributes<T> {}
  interface FormHTMLAttributes<T> extends HTMLAttributes<T> { action?: string; method?: string; noValidate?: boolean; name?: string; }
  interface FieldsetHTMLAttributes<T> extends HTMLAttributes<T> { disabled?: boolean; form?: string; name?: string; }
  interface AnchorHTMLAttributes<T> extends HTMLAttributes<T> { href?: string; target?: string; rel?: string; }
  interface OutputHTMLAttributes<T> extends HTMLAttributes<T> { htmlFor?: string; name?: string; }

  interface SVGAttributes<T> extends HTMLAttributes<T> { viewBox?: string; width?: string | number; height?: string | number; fill?: string; stroke?: string; strokeWidth?: string | number; strokeLinecap?: string; strokeLinejoin?: string; vectorEffect?: string; focusable?: string; x?: string | number; y?: string | number; x1?: string | number; y1?: string | number; x2?: string | number; y2?: string | number; cx?: string | number; cy?: string | number; r?: string | number; d?: string; points?: string; preserveAspectRatio?: string; role?: string; rx?: string | number; ry?: string | number; textAnchor?: string; dominantBaseline?: string; }
  interface SVGProps<T> extends HTMLAttributes<T> { [key: string]: any; }
  interface TdHTMLAttributes<T> extends HTMLAttributes<T> { colSpan?: number; }
  interface DialogHTMLAttributes<T> extends HTMLAttributes<T> { open?: boolean; }
}
declare module 'react' { export = React; }
declare module 'react/jsx-runtime' { export const jsx: any; export const jsxs: any; export const Fragment: any; }
declare namespace JSX {
  type Element = any;
  interface IntrinsicAttributes extends React.Attributes { ref?: any; }
  interface IntrinsicElements {
    button: React.ButtonHTMLAttributes<HTMLButtonElement>; span: React.HTMLAttributes<HTMLSpanElement>; div: React.HTMLAttributes<HTMLDivElement>; aside: React.HTMLAttributes<HTMLElement>; section: React.HTMLAttributes<HTMLElement>; article: React.HTMLAttributes<HTMLElement>; header: React.HTMLAttributes<HTMLElement>; footer: React.HTMLAttributes<HTMLElement>; figure: React.HTMLAttributes<HTMLElement>; figcaption: React.HTMLAttributes<HTMLElement>; details: React.HTMLAttributes<HTMLElement>; summary: React.HTMLAttributes<HTMLElement>; main: React.HTMLAttributes<HTMLElement>; nav: React.HTMLAttributes<HTMLElement>; p: React.HTMLAttributes<HTMLParagraphElement>; small: React.HTMLAttributes<HTMLElement>; strong: React.HTMLAttributes<HTMLElement>; time: React.HTMLAttributes<HTMLElement> & { dateTime?: string }; dl: React.HTMLAttributes<HTMLDListElement>; dt: React.HTMLAttributes<HTMLElement>; dd: React.HTMLAttributes<HTMLElement>; mark: React.HTMLAttributes<HTMLElement>; strong: React.HTMLAttributes<HTMLElement>; em: React.HTMLAttributes<HTMLElement>; h1: React.HTMLAttributes<HTMLHeadingElement>; h2: React.HTMLAttributes<HTMLHeadingElement>; h3: React.HTMLAttributes<HTMLHeadingElement>; h4: React.HTMLAttributes<HTMLHeadingElement>; label: React.HTMLAttributes<HTMLLabelElement> & { htmlFor?: string }; input: React.InputHTMLAttributes<HTMLInputElement>; textarea: React.TextareaHTMLAttributes<HTMLTextAreaElement>; select: React.SelectHTMLAttributes<HTMLSelectElement>; option: React.HTMLAttributes<HTMLOptionElement> & { value?: string | number; disabled?: boolean }; fieldset: React.FieldsetHTMLAttributes<HTMLFieldSetElement>; legend: React.HTMLAttributes<HTMLLegendElement>; table: React.TableHTMLAttributes<HTMLTableElement>; caption: React.HTMLAttributes<HTMLTableCaptionElement>; thead: React.HTMLAttributes<HTMLTableSectionElement>; tbody: React.HTMLAttributes<HTMLTableSectionElement>; tr: React.HTMLAttributes<HTMLTableRowElement>; th: React.TdHTMLAttributes<HTMLTableCellElement> & { scope?: string }; td: React.TdHTMLAttributes<HTMLTableCellElement>; dialog: React.DialogHTMLAttributes<HTMLDialogElement>; form: React.FormHTMLAttributes<HTMLFormElement>; svg: React.SVGProps<SVGSVGElement>; title: React.SVGProps<SVGTitleElement>; desc: React.SVGProps<SVGDescElement>; g: React.SVGProps<SVGGElement>; line: React.SVGProps<SVGLineElement>; polyline: React.SVGProps<SVGPolylineElement>; polygon: React.SVGProps<SVGPolygonElement>; rect: React.SVGProps<SVGRectElement>; path: React.SVGProps<SVGPathElement>; circle: React.SVGProps<SVGCircleElement>; text: React.SVGProps<SVGTextElement>; a: React.AnchorHTMLAttributes<HTMLAnchorElement>; ul: React.HTMLAttributes<HTMLUListElement>; ol: React.HTMLAttributes<HTMLOListElement>; li: React.HTMLAttributes<HTMLLIElement>; output: React.OutputHTMLAttributes<HTMLOutputElement>; datalist: React.HTMLAttributes<HTMLDataListElement>; optgroup: React.HTMLAttributes<HTMLOptGroupElement> & { label?: string; disabled?: boolean };
  }
}
