import type * as React from 'react';

export type AtlasSize = 'sm' | 'md' | 'lg';
export type AtlasTone = 'neutral' | 'info' | 'success' | 'warning' | 'danger';
export type AtlasStatus = 'success' | 'failed' | 'blocked' | 'running' | 'pending' | 'draft' | 'review';
export type Density = 'comfortable' | 'compact' | 'condensed';

export interface AtlasBaseProps {
  className?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
  id?: string;
}

export interface AtlasComponentContract {
  name: string;
  status: 'stable' | 'beta' | 'experimental' | 'deprecated';
  package: '@policyos/atlas-ui';
  source: string;
  docs: string;
  tokens: string[];
  states: string[];
  accessibility: string[];
  owner: string;
}
