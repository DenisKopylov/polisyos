export type ClassValue = string | number | false | null | undefined | Record<string, boolean | undefined | null>;

export function cx(...values: ClassValue[]): string {
  const out: string[] = [];
  for (const value of values) {
    if (!value) continue;
    if (typeof value === 'string' || typeof value === 'number') {
      out.push(String(value));
      continue;
    }
    for (const [name, enabled] of Object.entries(value)) {
      if (enabled) out.push(name);
    }
  }
  return out.join(' ');
}
