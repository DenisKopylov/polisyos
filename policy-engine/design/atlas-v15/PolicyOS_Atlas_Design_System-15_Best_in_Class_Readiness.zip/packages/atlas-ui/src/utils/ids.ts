import * as React from 'react';

export function useAtlasId(explicitId: string | undefined, prefix: string): string {
  const reactId = React.useId();
  return explicitId ?? `${prefix}-${reactId.replace(/:/g, '')}`;
}

export function joinIds(...ids: Array<string | undefined | false | null>): string | undefined {
  const value = ids.filter(Boolean).join(' ');
  return value.length > 0 ? value : undefined;
}
