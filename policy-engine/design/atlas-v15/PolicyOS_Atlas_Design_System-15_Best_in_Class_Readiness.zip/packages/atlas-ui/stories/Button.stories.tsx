import type { Meta, StoryObj } from '@storybook/react';
import { Button } from '../src';

const meta: Meta<typeof Button> = {
  title: 'Atlas UI/Button',
  component: Button,
  parameters: {
    a11y: { config: { rules: [{ id: 'color-contrast', enabled: true }] } },
    docs: { description: { component: 'Action primitive with token-backed variants and loading/disabled states.' } }
  },
  args: { children: 'Open packet', variant: 'primary' }
};

export default meta;
type Story = StoryObj<typeof Button>;

export const Primary: Story = {};
export const Loading: Story = { args: { loading: true, children: 'Submitting' } };
export const Danger: Story = { args: { variant: 'danger', children: 'Revoke access' } };
