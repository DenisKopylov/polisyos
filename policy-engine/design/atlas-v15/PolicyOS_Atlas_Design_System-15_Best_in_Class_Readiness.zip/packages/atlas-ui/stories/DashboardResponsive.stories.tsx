import type { Meta, StoryObj } from '@storybook/react';
import { Badge, Button, DashboardGrid, DashboardMain, DashboardShell, DashboardSidebar, DashboardTopBar, MetricCard, Panel, ResponsiveDataRegion, DataTable } from '../src';

type Row = { run: string; status: string; p95: string; reviewer: string };
const rows: Row[] = [
  { run: 'fiscal_reform_q2_001', status: 'review', p95: '4.2m', reviewer: 'O. Verbytska' },
  { run: 'benefit_cliff_scan', status: 'pass', p95: '2.8m', reviewer: 'L. Marsh' },
  { run: 'transport_subsidy', status: 'blocked', p95: '7.6m', reviewer: 'A. Kovalenko' },
];

function DashboardResponsiveExample() {
  const sidebar = (
    <DashboardSidebar
      mode="docked"
      activeItemId="runs"
      brand={<strong>Atlas</strong>}
      status={<Badge tone="success">Nominal</Badge>}
      footer={<small>v13 responsive contract</small>}
      items={[
        { id: 'runs', label: 'Runs', icon: '▲' },
        { id: 'evidence', label: 'Evidence', icon: '⊡' },
        { id: 'governance', label: 'Governance', icon: '⊘' },
      ]}
    />
  );
  const topbar = <DashboardTopBar title="Command Center" subtitle="Responsive shell, density and data-region behavior" actions={<Button variant="primary">Compose</Button>} />;
  return (
    <DashboardShell sidebar={sidebar} topbar={topbar} sidebarMode="auto">
      <DashboardMain title="Command Center" description="Operator dashboard that collapses from docked nav to rail to drawer without losing landmarks or actions.">
        <DashboardGrid variant="metrics">
          <MetricCard label="Active runs" value="7" hint="2 need review" />
          <MetricCard label="Blocked" value="2" hint="Gate evidence missing" />
          <MetricCard label="Freshness" value="91%" hint="SLO within budget" />
        </DashboardGrid>
        <DashboardGrid variant="content-sidebar">
          <Panel title="Review queue">
            <ResponsiveDataRegion caption="Run latency table" summary="Scrollable on narrow viewports; print mode expands without clipping." labelledBy="run-latency-table">
              <DataTable<Row>
                caption="Simulation runs"
                rows={rows}
                getRowKey={(row) => row.run}
                columns={[
                  { key: 'run', header: 'Run', cell: (row) => row.run },
                  { key: 'status', header: 'Status', cell: (row) => row.status },
                  { key: 'p95', header: 'P95', align: 'end', cell: (row) => row.p95 },
                  { key: 'reviewer', header: 'Reviewer', cell: (row) => row.reviewer },
                ]}
              />
            </ResponsiveDataRegion>
          </Panel>
          <Panel title="Decision packet">
            <p>Side content stacks under the primary region below the tablet breakpoint.</p>
          </Panel>
        </DashboardGrid>
      </DashboardMain>
    </DashboardShell>
  );
}

const meta: Meta<typeof DashboardResponsiveExample> = {
  title: 'Atlas UI/Dashboard responsive',
  component: DashboardResponsiveExample,
  parameters: { docs: { description: { component: 'Responsive dashboard shell primitives for docked, rail, drawer, data-dense and print/export contexts.' } } }
};
export default meta;
type Story = StoryObj<typeof DashboardResponsiveExample>;
export const Default: Story = {};
