import type { Meta, StoryObj } from '@storybook/react';
import {
  Button,
  CharacterCount,
  CheckboxGroup,
  Combobox,
  DateField,
  DateRangeField,
  FieldGroup,
  FileUpload,
  Form,
  FormSection,
  NumberField,
  PasswordField,
  RadioGroup,
  RangeField,
  SearchField,
  SecretField,
  TextArea,
  TextField,
  TokenInput,
  ValidationSummary,
} from '../src';

function DataEntryExample() {
  return (
    <Form
      title="Configure governance review"
      description="A production form showing the Atlas v12 forms and data-entry coverage."
      errorSummary={
        <ValidationSummary
          items={[
            { id: 'review-deadline', label: 'Review deadline', message: 'Enter a date after today.' },
            { id: 'evidence-upload', label: 'Evidence attachment', message: 'Upload a CSV or PDF under the configured size limit.' },
          ]}
        />
      }
      actions={<><Button variant="ghost">Save draft</Button><Button variant="primary">Submit review</Button></>}
    >
      <FormSection title="Evidence intake" description="Use explicit constraints so reviewers understand what can be parsed and audited.">
        <SearchField label="Search evidence sources" description="Find datasets, packets or prior runs." placeholder="Dataset, packet or run id" />
        <Combobox
          label="Primary source"
          description="Single-select controlled source."
          options={[
            { label: 'Administrative registry', value: 'registry', description: 'High provenance score' },
            { label: 'Survey panel', value: 'survey', description: 'Requires freshness review' },
            { label: 'Manual upload', value: 'manual', description: 'Reviewer-owned source' },
          ]}
          placeholder="Choose source"
        />
        <FileUpload id="evidence-upload" label="Evidence attachment" description="Accepted formats: CSV, JSON or PDF." accept=".csv,.json,.pdf" />
      </FormSection>

      <FormSection title="Policy parameters" description="Bounded values expose units, ranges and validation before submit.">
        <NumberField label="Minimum confidence" description="Threshold for automatic gate pass." suffix="%" min={0} max={100} defaultValue={85} />
        <RangeField label="Risk tolerance" description="Adjust sensitivity for review routing." min={0} max={10} defaultValue={4} output="4 / 10" />
        <DateField id="review-deadline" label="Review deadline" description="Used for escalation and reminders." />
        <DateRangeField legend="Evidence validity window" description="The period covered by the input evidence." />
      </FormSection>

      <FormSection title="Reviewer choices" description="Grouped controls use native fieldsets and legends.">
        <RadioGroup
          legend="Review route"
          options={[
            { label: 'Auto-approve when gates pass', value: 'auto' },
            { label: 'Require human review', value: 'human', description: 'Recommended for high-impact domains' },
            { label: 'Block until waiver', value: 'block' },
          ]}
        />
        <CheckboxGroup
          legend="Required assurances"
          options={[
            { label: 'Freshness checked', value: 'freshness' },
            { label: 'Provenance attached', value: 'provenance' },
            { label: 'Fairness audit reviewed', value: 'fairness' },
          ]}
          defaultValues={['freshness']}
        />
        <FieldGroup legend="Jurisdictions" description="Tokenized values stay visible and removable.">
          <TokenInput
            label="Selected jurisdictions"
            tokens={[{ id: 'ua', label: 'Ukraine' }, { id: 'eu', label: 'EU' }]}
            placeholder="Add jurisdiction"
          />
        </FieldGroup>
      </FormSection>

      <FormSection title="Secrets and rationale" description="Sensitive data is redacted by default and long text announces limits politely.">
        <PasswordField label="Reviewer password" description="Required for protected signing actions." />
        <SecretField label="Policy signing key" description="Stored securely; reveal only when needed." defaultValue="atlas_live_••••••••" />
        <TextField label="Packet title" defaultValue="Transportability review" />
        <TextArea label="Decision rationale" defaultValue="Evidence supports conditional approval." maxLength={280} />
        <CharacterCount value="Evidence supports conditional approval." maxLength={280} />
      </FormSection>
    </Form>
  );
}

const meta: Meta<typeof DataEntryExample> = {
  title: 'Atlas UI/Data Entry',
  component: DataEntryExample,
  parameters: {
    a11y: { config: { rules: [{ id: 'color-contrast', enabled: true }] } },
    docs: { description: { component: 'Atlas v12 form and data-entry components with validation, grouped choices, secrets, files and bounded values.' } }
  }
};

export default meta;
type Story = StoryObj<typeof DataEntryExample>;
export const BestInClassForm: Story = {};
