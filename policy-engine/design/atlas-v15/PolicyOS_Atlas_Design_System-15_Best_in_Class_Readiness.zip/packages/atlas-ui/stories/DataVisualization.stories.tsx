
import type { Meta, StoryObj } from '@storybook/react';
import { BarChart, CausalGraph, ChartAnnotation, ChartDataTable, ChartFrame, ChartLegend, ChartTooltip, DataVizTable, Heatmap, LineChart, ProvenanceGraph, ProvenanceMap, Sparkline, UncertaintyBand } from '../src';

const meta: Meta = {
  title: 'Atlas/Data visualization',
  parameters: { layout: 'padded', a11y: { test: 'error' } },
};
export default meta;

type Story = StoryObj;

const trend = [
  { label: 'Jan', value: 42 },
  { label: 'Feb', value: 48 },
  { label: 'Mar', value: 51 },
  { label: 'Apr', value: 57 },
];

const uncertainty = [
  { label: 'Q1', value: 42, low: 34, high: 50 },
  { label: 'Q2', value: 46, low: 36, high: 55 },
  { label: 'Q3', value: 50, low: 39, high: 61 },
  { label: 'Q4', value: 55, low: 42, high: 68 },
];

export const DecisionChartFrame: Story = {
  render: () => (
    <ChartFrame
      title="Scenario impact"
      eyebrow="PolicyOS evidence"
      summary="The intervention trend improves across the review window, but the uncertainty band remains decision-relevant."
      source="Synthetic demo data"
      dataTable={
        <ChartDataTable
          caption="Scenario values"
          columns={[{ key: 'period', header: 'Period', rowHeader: true }, { key: 'value', header: 'Value', align: 'end' }]}
          rows={trend.map((item) => ({ period: item.label, value: item.value }))}
        />
      }
    >
      <ChartLegend items={[{ id: 'impact', label: 'Impact', tone: 'series-1' }, { id: 'baseline', label: 'Baseline', tone: 'series-2', shape: 'dash' }]} />
      <LineChart title="Scenario impact trend" summary="Trend line rises from January to April." series={[{ id: 'impact', label: 'Impact', data: trend }, { id: 'baseline', label: 'Baseline', dashed: true, data: trend.map((item) => ({ ...item, value: item.value - 8 })) }]} />
    </ChartFrame>
  ),
};

export const BarAndSparkline: Story = {
  render: () => (
    <ChartFrame title="Regional comparison" summary="Region B has the highest measured policy impact." source="Synthetic demo data">
      <BarChart title="Regional impact bars" summary="Region B is highest, followed by Region C and Region A." data={[{ label: 'A', value: 38 }, { label: 'B', value: 61 }, { label: 'C', value: 52 }]} />
      <Sparkline title="Regional trend sparkline" summary="Compact trend rises over four periods." data={trend} />
    </ChartFrame>
  ),
};

export const UncertaintyAndHeatmap: Story = {
  render: () => (
    <ChartFrame title="Confidence review" summary="The midpoint increases, while interval width stays large enough to require review." source="Synthetic demo data">
      <UncertaintyBand title="Impact uncertainty" summary="Low and high interval bounds surround the midpoint." data={uncertainty} />
      <Heatmap title="Fairness heatmap" summary="The matrix highlights slices that need reviewer attention." data={[{ row: 'North', column: 'A', value: 0.2 }, { row: 'North', column: 'B', value: 0.7 }, { row: 'South', column: 'A', value: 0.4 }, { row: 'South', column: 'B', value: 0.9 }]} />
    </ChartFrame>
  ),
};

export const CausalAndProvenance: Story = {
  render: () => (
    <ChartFrame title="Evidence explanation" summary="Observed inputs feed an assumption that is still under reviewer scrutiny." source="Synthetic demo data">
      <CausalGraph
        title="Causal graph"
        summary="Program exposure influences uptake, which influences outcome; confounding is under review."
        nodes={[{ id: 'exposure', label: 'Exposure', x: 110, y: 120 }, { id: 'uptake', label: 'Uptake', x: 330, y: 120, status: 'assumption' }, { id: 'outcome', label: 'Outcome', x: 560, y: 120 }, { id: 'context', label: 'Context', x: 330, y: 250, status: 'confounder' }]}
        edges={[{ from: 'exposure', to: 'uptake' }, { from: 'uptake', to: 'outcome' }, { from: 'context', to: 'uptake', strength: 'assumed' }, { from: 'context', to: 'outcome', strength: 'weak' }]}
      />
      <ProvenanceMap stages={[{ id: 'source', label: 'Source extract', meta: 'June dataset', status: 'complete' }, { id: 'transform', label: 'Normalization', meta: 'PolicyOS pipeline', status: 'complete' }, { id: 'review', label: 'Reviewer sign-off', meta: 'Pending', status: 'review' }]} />
      <ChartTooltip title="Reviewer note" value="Pending" description="Tooltip content is duplicated in the provenance stage." />
    </ChartFrame>
  ),
};


export const AnnotationAndDataTable: Story = {
  render: () => (
    <ChartFrame
      title="Decision annotation and accessible data"
      summary="Annotations explain outliers and the table repeats chart values for assistive technology, export and audit review."
      source="Synthetic demo data"
      dataTable={
        <DataVizTable
          caption="Scenario impact values"
          columns={[
            { key: 'label', header: 'Period', scope: 'row', cell: (row: { label: string; value: number }) => row.label },
            { key: 'value', header: 'Impact', align: 'end', cell: (row: { label: string; value: number }) => row.value },
          ]}
          rows={trend}
          getRowKey={(row) => row.label}
          note="This is the canonical data table equivalent for the chart."
        />
      }
    >
      <ChartAnnotation tone="warning" marker="!" title="Review assumption">
        April's impact remains sensitive to evidence freshness and should not be interpreted by color alone.
      </ChartAnnotation>
      <ChartTooltip title="April" value="57" description="Highest value in the current review window." />
      <ProvenanceGraph
        title="ProvenanceGraph audit trail"
        summary="Source extract leads to normalization, model run and reviewer sign-off."
        nodes={[
          { id: 'extract', label: 'Source extract', meta: 'Verified', status: 'verified' },
          { id: 'normalize', label: 'Normalization', meta: 'Pipeline v14', status: 'verified' },
          { id: 'review', label: 'Reviewer sign-off', meta: 'Pending', status: 'current' },
        ]}
        edges={[
          { from: 'extract', to: 'normalize', label: 'schema mapped' },
          { from: 'normalize', to: 'review', label: 'decision packet generated' },
        ]}
      />
    </ChartFrame>
  ),
};
