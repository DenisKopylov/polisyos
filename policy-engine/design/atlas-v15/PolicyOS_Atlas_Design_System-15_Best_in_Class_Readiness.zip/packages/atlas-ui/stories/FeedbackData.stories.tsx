import type { Meta, StoryObj } from '@storybook/react';
import { Button, DataTable, EmptyState, Skeleton, Toast } from '../src';

type Row = { source: string; status: string; age: string };
const rows: Row[] = [
  { source: 'Household panel', status: 'verified', age: '2d' },
  { source: 'Transport registry', status: 'review', age: '6d' },
];

function FeedbackDataExample() {
  return (
    <div style={{ display: 'grid', gap: 'var(--space-4)', maxWidth: 760 }}>
      <Toast tone="warning" title="Evidence freshness degraded" message="Two sources need reviewer confirmation." action={<Button variant="ghost">Review</Button>} />
      <EmptyState title="No packets queued" description="Decision packets appear here after simulation runs complete." action={<Button variant="primary">Compose scenario</Button>} />
      <Skeleton style={{ inlineSize: '100%', blockSize: 'var(--space-8)' }} />
      <DataTable<Row>
        caption="Evidence sources"
        rows={rows}
        getRowKey={(row) => row.source}
        columns={[
          { key: 'source', header: 'Source', cell: (row) => row.source },
          { key: 'status', header: 'Status', cell: (row) => row.status },
          { key: 'age', header: 'Age', align: 'end', cell: (row) => row.age },
        ]}
      />
    </div>
  );
}

const meta: Meta<typeof FeedbackDataExample> = {
  title: 'Atlas UI/Feedback and data',
  component: FeedbackDataExample,
  parameters: { docs: { description: { component: 'Feedback, loading, empty and tabular data patterns.' } } }
};
export default meta;
type Story = StoryObj<typeof FeedbackDataExample>;
export const Default: Story = {};
