import type { Meta, StoryObj } from '@storybook/react';
import { Checkbox, Form, FormSection, SelectField, Switch, TextArea, TextField, ValidationSummary } from '../src';

function FormExample() {
  return (
    <Form title="Policy setup" description="v12 Form, FormSection and ValidationSummary wrap core fields." errorSummary={<ValidationSummary items={[]} />} style={{ maxWidth: 720 }}>
      <FormSection title="Core fields" description="Foundational text, select and boolean controls.">
      <TextField label="Policy title" description="Use the human-readable governance name." placeholder="Housing transportability review" />
      <TextArea label="Decision rationale" description="Summarize assumptions and evidence constraints." />
      <SelectField label="Region" options={[{ label: 'Kyiv', value: 'kyiv' }, { label: 'Lviv', value: 'lviv' }]} placeholder="Select region" />
      <Checkbox label="Evidence sources verified" description="Required before publishing a packet." />
      <Switch label="Notify reviewers" description="Sends a status update when the run completes." />
      </FormSection>
    </Form>
  );
}

const meta: Meta<typeof FormExample> = { title: 'Atlas UI/Forms', component: FormExample };
export default meta;
type Story = StoryObj<typeof FormExample>;
export const Default: Story = {};
