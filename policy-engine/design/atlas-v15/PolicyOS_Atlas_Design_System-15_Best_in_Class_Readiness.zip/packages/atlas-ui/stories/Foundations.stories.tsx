import type { Meta, StoryObj } from '@storybook/react';
import { Badge, Card, CardButton, MetricCard, Panel, RunCard } from '../src';

function FoundationsExample() {
  return (
    <div style={{ display: 'grid', gap: 'var(--space-4)', maxWidth: 720 }}>
      <Panel eyebrow="Library" title="Decision overview" description="Panel with token-backed surface, border and heading treatment.">
        <Badge tone="success">OK</Badge>
      </Panel>
      <Card title="Evidence bundle" description="Static card for grouped content." action={<Badge tone="info">18 sources</Badge>} />
      <CardButton title="Open synthesis" description="Interactive card uses native button semantics." selected />
      <MetricCard label="Confidence" value="87%" hint="Calibrated against 42 prior decisions." />
      <RunCard runId="RUN-1042" status="running" duration="02:14" artifacts={9} />
    </div>
  );
}

const meta: Meta<typeof FoundationsExample> = {
  title: 'Atlas UI/Foundations',
  component: FoundationsExample,
  parameters: { docs: { description: { component: 'Foundational display primitives and dashboard card patterns.' } } }
};
export default meta;
type Story = StoryObj<typeof FoundationsExample>;
export const Default: Story = {};
