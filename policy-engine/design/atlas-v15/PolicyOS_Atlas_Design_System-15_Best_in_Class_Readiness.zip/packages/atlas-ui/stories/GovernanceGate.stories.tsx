import type { Meta, StoryObj } from '@storybook/react';
import { Button, GovernanceGate } from '../src';

const meta: Meta<typeof GovernanceGate> = {
  title: 'Atlas UI/PolicyOS/GovernanceGate',
  component: GovernanceGate,
  args: {
    title: 'Transportability review',
    status: 'review',
    evidenceCount: 18,
    description: 'Two cohorts require reviewer sign-off before this packet can be published.',
    action: <Button variant="primary">Open gate</Button>
  }
};
export default meta;
type Story = StoryObj<typeof GovernanceGate>;
export const Review: Story = {};
export const Pass: Story = { args: { status: 'pass' } };
export const Blocked: Story = { args: { status: 'blocked' } };
