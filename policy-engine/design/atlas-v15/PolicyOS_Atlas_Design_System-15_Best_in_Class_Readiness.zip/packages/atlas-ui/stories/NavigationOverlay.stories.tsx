import * as React from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Button, Dialog, Tabs } from '../src';

function NavigationOverlayExample() {
  const [open, setOpen] = React.useState(false);
  return (
    <div style={{ display: 'grid', gap: 'var(--space-4)', maxWidth: 720 }}>
      <Tabs
        label="Decision packet sections"
        items={[
          { id: 'summary', label: 'Summary', panel: <p>Decision narrative and approval state.</p> },
          { id: 'evidence', label: 'Evidence', panel: <p>Source lineage and freshness status.</p> },
          { id: 'audit', label: 'Audit', panel: <p>Reviewer activity and governance log.</p> },
        ]}
      />
      <Button variant="primary" onClick={() => setOpen(true)}>Open dialog</Button>
      <Dialog open={open} onClose={() => setOpen(false)} title="Publish packet" description="Confirm reviewer sign-off before publishing.">
        <p>This dialog traps keyboard focus, supports Escape dismiss and returns focus to the trigger.</p>
        <Button variant="danger">Publish</Button>
      </Dialog>
    </div>
  );
}

const meta: Meta<typeof NavigationOverlayExample> = {
  title: 'Atlas UI/Navigation and overlays',
  component: NavigationOverlayExample,
  parameters: { docs: { description: { component: 'Composite keyboard and overlay patterns.' } } }
};
export default meta;
type Story = StoryObj<typeof NavigationOverlayExample>;
export const Default: Story = {};
