import type { Meta, StoryObj } from '@storybook/react';
import { Badge, Button, DashboardShell, DashboardSidebar, DashboardTopBar, MetricCard, Panel, ResponsiveGrid, RunCard, ScrollRegion, DataTable } from '../src';

const navItems = [
  { id: 'command', label: 'Command Center', icon: 'CC' },
  { id: 'composer', label: 'Scenario Composer', icon: 'SC' },
  { id: 'evidence', label: 'Evidence Fabric', icon: 'EF', badge: <Badge tone="info">18</Badge> },
];

const rows = [
  { id: 'RUN-1042', status: 'running', confidence: '87%' },
  { id: 'RUN-1043', status: 'review', confidence: '74%' },
];

function ResponsiveDashboardExample() {
  return (
    <DashboardShell
      sidebarOpen={false}
      topBar={<DashboardTopBar title="Command Center" subtitle="Responsive workspace shell" onMenuClick={() => undefined} menuControls="story-nav" actions={<Button size="sm">Export</Button>} />}
      sidebar={<DashboardSidebar id="story-nav" header={<strong>Atlas</strong>} items={navItems} activeId="command" footer={<small>v13 responsive</small>} />}
      mainLabel="Command Center"
    >
      <ResponsiveGrid minColumn="sm" gap="md">
        <MetricCard label="Active runs" value="7" hint="2 blocked" />
        <MetricCard label="Evidence" value="18" hint="Freshness within SLA" />
        <MetricCard label="Confidence" value="87%" hint="Calibrated" />
      </ResponsiveGrid>
      <Panel title="Workspace reflow" description="Cards use container-aware grids and the shell switches from drawer to rail to expanded sidebar.">
        <ResponsiveGrid minColumn="md" gap="lg">
          <RunCard runId="RUN-1042" status="running" duration="02:14" artifacts={9} />
          <ScrollRegion label="Recent run status table">
            <DataTable
              caption="Recent runs"
              responsiveMode="cards"
              columns={[
                { key: 'id', header: 'Run', cell: (row) => row.id },
                { key: 'status', header: 'Status', cell: (row) => row.status },
                { key: 'confidence', header: 'Confidence', cell: (row) => row.confidence },
              ]}
              rows={rows}
              getRowKey={(row) => row.id}
            />
          </ScrollRegion>
        </ResponsiveGrid>
      </Panel>
    </DashboardShell>
  );
}

const meta: Meta<typeof ResponsiveDashboardExample> = {
  title: 'Atlas UI/Responsive Dashboard',
  component: ResponsiveDashboardExample,
  parameters: { docs: { description: { component: 'Responsive dashboard shell, sidebar/topbar behavior, container-aware grids, scroll regions and mobile table cards.' } } }
};

export default meta;
type Story = StoryObj<typeof ResponsiveDashboardExample>;
export const Default: Story = {};
