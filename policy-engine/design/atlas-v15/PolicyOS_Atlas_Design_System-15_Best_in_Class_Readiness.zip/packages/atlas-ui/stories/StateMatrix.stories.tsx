import type { Meta, StoryObj } from '@storybook/react';
import { Badge, Button, Card, CardButton, CharacterCount, Checkbox, CheckboxGroup, Combobox, DataTable, DateField, DateRangeField, Dialog, EmptyState, FieldGroup, FileUpload, Form, FormSection, GovernanceGate, MetricCard, NumberField, Panel, PasswordField, RadioGroup, RangeField, RunCard, SearchField, SecretField, SelectField, Skeleton, Switch, Tabs, TextArea, TextField, Toast, TokenInput, ValidationSummary } from '../src';

type Row = { source: string; status: string; confidence: string };
const rows: Row[] = [
  { source: 'Household panel', status: 'verified', confidence: '91%' },
  { source: 'Transport registry', status: 'review', confidence: '74%' },
];

function StateBlock({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <Panel title={title} headingLevel={3}>
      <div style={{ display: 'grid', gap: 'var(--space-3)' }}>{children}</div>
    </Panel>
  );
}

function StateMatrixExample() {
  return (
    <div style={{ display: 'grid', gap: 'var(--space-5)', maxWidth: 1040 }}>
      <StateBlock title="Button states">
        <div style={{ display: 'flex', gap: 'var(--space-3)', flexWrap: 'wrap' }}>
          <Button variant="primary">Default</Button>
          <Button variant="primary" loading>Loading</Button>
          <Button variant="danger">Danger</Button>
          <Button disabled>Disabled</Button>
        </div>
      </StateBlock>

      <StateBlock title="Status states">
        <div style={{ display: 'flex', gap: 'var(--space-3)', flexWrap: 'wrap' }}>
          <Badge tone="neutral">neutral</Badge>
          <Badge tone="info">info</Badge>
          <Badge tone="success">success</Badge>
          <Badge tone="warning">warning</Badge>
          <Badge tone="danger">danger</Badge>
        </div>
        <RunCard runId="RUN-1042" status="running" duration="02:14" artifacts={9} />
        <GovernanceGate title="Transportability review" status="blocked" evidenceCount={18} description="Two evidence sources are stale." action={<Button variant="danger">Open blocker</Button>} />
      </StateBlock>

      <StateBlock title="Card and metric states">
        <Card title="Static evidence bundle" description="Grouped content without action." action={<Badge tone="info">18 sources</Badge>} />
        <CardButton title="Selected synthesis" description="Interactive selection state uses aria-pressed." selected />
        <MetricCard label="Confidence" value="87%" hint="Calibrated against prior packets." badge={<Badge tone="success">ok</Badge>} />
      </StateBlock>

      <StateBlock title="Form states">
        <TextField label="Policy title" description="Visible in audit logs." placeholder="Housing review" />
        <TextField label="Decision id" value="POL-2026-042" readOnly />
        <TextField label="Required title" error="Title is required." required />
        <TextArea label="Rationale" defaultValue="Evidence is sufficient for review." />
        <SelectField label="Region" placeholder="Select region" options={[{ label: 'Kyiv', value: 'kyiv' }, { label: 'Lviv', value: 'lviv' }]} />
        <Checkbox label="Evidence verified" description="Required before publishing." indeterminate />
        <Switch label="Notify reviewers" description="Sends a status update when the run completes." defaultChecked />
      </StateBlock>


      <StateBlock title="V12 data-entry states">
        <Form title="Stateful form" errorSummary={<ValidationSummary items={[]} />}>
          <FormSection title="Structured entry" description="FormSection keeps reading order and responsive behavior stable.">
            <SearchField label="Search sources" />
            <Combobox label="Source" options={[{ label: 'Registry', value: 'registry' }, { label: 'Survey panel', value: 'survey' }]} />
            <RadioGroup legend="Route" options={[{ label: 'Review', value: 'review' }, { label: 'Block', value: 'block' }]} />
            <CheckboxGroup legend="Assurances" options={[{ label: 'Freshness', value: 'freshness' }, { label: 'Provenance', value: 'provenance' }]} defaultValues={['freshness']} />
            <FieldGroup legend="Tokenized values"><TokenInput label="Jurisdictions" tokens={[{ id: 'ua', label: 'Ukraine' }]} /></FieldGroup>
            <NumberField label="Confidence" suffix="%" defaultValue={85} />
            <RangeField label="Risk tolerance" min={0} max={10} defaultValue={4} output="4" />
            <DateField label="Deadline" />
            <DateRangeField legend="Validity window" />
            <FileUpload label="Evidence upload" />
            <PasswordField label="Password" />
            <SecretField label="Signing key" defaultValue="atlas_live_redacted" />
            <CharacterCount value="state matrix" maxLength={80} />
          </FormSection>
        </Form>
      </StateBlock>

      <StateBlock title="Navigation and overlay states">
        <Tabs label="Decision sections" items={[{ id: 'summary', label: 'Summary', panel: <p>Summary panel</p> }, { id: 'evidence', label: 'Evidence', panel: <p>Evidence panel</p> }, { id: 'audit', label: 'Audit', panel: <p>Audit panel</p>, disabled: true }]} />
        <Dialog open title="Publish packet" description="Static open story for state review." onClose={() => undefined} actions={<Button variant="danger">Publish</Button>}>
          <p>Open, labelled, modal and focus-trap states are documented in the matrix.</p>
        </Dialog>
      </StateBlock>

      <StateBlock title="Feedback and data states">
        <Toast tone="warning" title="Evidence freshness degraded" message="Two sources need reviewer confirmation." action={<Button variant="ghost">Review</Button>} />
        <EmptyState state="filtered-out" title="No sources match filters" description="Adjust filters or reset the query." action={<Button variant="primary">Reset filters</Button>} />
        <Skeleton style={{ inlineSize: '100%', blockSize: 'var(--space-8)' }} />
        <DataTable<Row>
          caption="Evidence sources"
          rows={rows}
          getRowKey={(row) => row.source}
          columns={[
            { key: 'source', header: 'Source', cell: (row) => row.source },
            { key: 'status', header: 'Status', cell: (row) => row.status },
            { key: 'confidence', header: 'Confidence', align: 'end', cell: (row) => row.confidence },
          ]}
        />
      </StateBlock>
    </div>
  );
}

const meta: Meta<typeof StateMatrixExample> = {
  title: 'Atlas UI/State matrix',
  component: StateMatrixExample,
  parameters: {
    docs: { description: { component: 'Canonical v12 state coverage story across the production component set.' } },
    a11y: { test: 'error' }
  }
};
export default meta;
type Story = StoryObj<typeof StateMatrixExample>;
export const Matrix: Story = {};
