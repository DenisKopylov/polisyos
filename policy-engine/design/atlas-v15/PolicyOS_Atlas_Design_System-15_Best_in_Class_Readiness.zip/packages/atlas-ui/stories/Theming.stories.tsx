import * as React from 'react';
import { AccessibilityModePanel, Button, Panel, ThemeProvider, ThemeToggle } from '../src';

export default { title: 'Atlas/Theming accessibility modes' };

export function ThemingModes() {
  const [theme, setTheme] = React.useState<'auto' | 'light' | 'dark' | 'high-contrast'>('auto');
  const [settings, setSettings] = React.useState({ theme: 'auto' as const, contrast: 'auto' as const, motion: 'auto' as const, transparency: 'auto' as const, density: 'comfortable' as const, textScale: 'standard' as const, colorSafe: true });
  return (
    <ThemeProvider {...settings} theme={theme} applyToRoot={false}>
      <Panel title="ThemeProvider" eyebrow="Accessibility modes" description="ThemeToggle and AccessibilityModePanel exercise the v15 mode contract.">
        <ThemeToggle value={theme} onValueChange={setTheme} />
        <AccessibilityModePanel settings={settings} onSettingsChange={setSettings} />
        <Button variant="primary">Decision-ready action</Button>
      </Panel>
    </ThemeProvider>
  );
}
