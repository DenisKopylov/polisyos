import * as React from 'react';
import { describe, expect, it } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { Button, Checkbox, SelectField, Tabs, TextField } from '../src';

describe('@policyos/atlas-ui component contracts', () => {
  it('Button defaults to native button semantics and exposes loading state', () => {
    render(<Button loading>Submit packet</Button>);
    const button = screen.getByRole('button', { name: /loading submit packet/i });
    expect(button).toBeDisabled();
    expect(button).toHaveAttribute('aria-busy', 'true');
  });

  it('TextField wires label, description and error message to the input', () => {
    render(<TextField label="Policy title" description="Visible in audit logs" error="Title is required" required />);
    const input = screen.getByLabelText(/policy title/i);
    expect(input).toHaveAttribute('aria-invalid', 'true');
    expect(input.getAttribute('aria-describedby')).toContain('description');
    expect(input.getAttribute('aria-describedby')).toContain('error');
  });

  it('Checkbox remains a native checkbox with associated label', async () => {
    const user = userEvent.setup();
    render(<Checkbox label="Evidence verified" />);
    const checkbox = screen.getByRole('checkbox', { name: /evidence verified/i });
    await user.click(screen.getByText(/evidence verified/i));
    expect(checkbox).toBeChecked();
  });

  it('SelectField renders semantic options', () => {
    render(<SelectField label="Region" options={[{ label: 'Kyiv', value: 'kyiv' }, { label: 'Lviv', value: 'lviv' }]} />);
    expect(screen.getByRole('combobox', { name: /region/i })).toBeInTheDocument();
    expect(screen.getByRole('option', { name: 'Kyiv' })).toHaveValue('kyiv');
  });

  it('Tabs support arrow-key roving selection', async () => {
    const user = userEvent.setup();
    render(
      <Tabs
        label="Decision packet sections"
        items={[
          { id: 'summary', label: 'Summary', panel: <p>Summary panel</p> },
          { id: 'evidence', label: 'Evidence', panel: <p>Evidence panel</p> },
        ]}
      />,
    );
    const summary = screen.getByRole('tab', { name: 'Summary' });
    summary.focus();
    await user.keyboard('{ArrowRight}');
    expect(screen.getByRole('tab', { name: 'Evidence' })).toHaveAttribute('aria-selected', 'true');
  });
});
