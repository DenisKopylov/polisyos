import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import {
  CharacterCount,
  CheckboxGroup,
  Combobox,
  DateField,
  FileUpload,
  Form,
  NumberField,
  PasswordField,
  RadioGroup,
  SearchField,
  SecretField,
  TokenInput,
  ValidationSummary,
} from '../src';

describe('Atlas v12 data-entry contracts', () => {
  it('connects validation summary links to field ids', () => {
    render(<Form errorSummary={<ValidationSummary items={[{ id: 'title', label: 'Title', message: 'Enter a title.' }]} />}><SearchField id="title" label="Title" /></Form>);
    expect(screen.getByRole('alert')).toHaveTextContent('Enter a title.');
    expect(screen.getByRole('link', { name: /title/i })).toHaveAttribute('href', '#title');
  });

  it('uses native grouped controls', async () => {
    const user = userEvent.setup();
    render(<RadioGroup legend="Route" options={[{ label: 'Review', value: 'review' }, { label: 'Block', value: 'block' }]} />);
    await user.click(screen.getByLabelText('Review'));
    expect(screen.getByLabelText('Review')).toBeChecked();
  });

  it('supports reveal toggles for sensitive fields', async () => {
    const user = userEvent.setup();
    render(<><PasswordField label="Password" /><SecretField label="API key" defaultValue="secret" /></>);
    await user.click(screen.getByRole('button', { name: /show password/i }));
    expect(screen.getByLabelText('Password')).toHaveAttribute('type', 'text');
    await user.click(screen.getByRole('button', { name: /reveal secret/i }));
    expect(screen.getByLabelText('API key')).toHaveAttribute('type', 'text');
  });

  it('renders bounded value and intake controls with labels', () => {
    render(<><NumberField label="Confidence" suffix="%" /><DateField label="Deadline" /><FileUpload label="Evidence" /><CharacterCount value="abc" maxLength={10} /></>);
    expect(screen.getByLabelText('Confidence')).toHaveAttribute('type', 'number');
    expect(screen.getByLabelText('Deadline')).toHaveAttribute('type', 'date');
    expect(screen.getByLabelText('Evidence')).toHaveAttribute('type', 'file');
    expect(screen.getByText('7 characters remaining')).toBeInTheDocument();
  });

  it('keeps token input removals labelled and combobox keyboard-ready', async () => {
    const user = userEvent.setup();
    const removed: string[] = [];
    render(<><TokenInput label="Jurisdictions" tokens={[{ id: 'ua', label: 'Ukraine' }]} onRemoveToken={(token) => removed.push(token.id)} /><Combobox label="Source" options={[{ label: 'Registry', value: 'registry' }]} /></>);
    await user.click(screen.getByRole('button', { name: /remove ukraine/i }));
    expect(removed).toEqual(['ua']);
    expect(screen.getByRole('combobox', { name: 'Source' })).toHaveAttribute('aria-autocomplete', 'list');
  });

  it('renders checkbox group native options', () => {
    render(<CheckboxGroup legend="Assurances" options={[{ label: 'Freshness', value: 'freshness' }]} />);
    expect(screen.getByLabelText('Freshness')).toHaveAttribute('type', 'checkbox');
  });
});
