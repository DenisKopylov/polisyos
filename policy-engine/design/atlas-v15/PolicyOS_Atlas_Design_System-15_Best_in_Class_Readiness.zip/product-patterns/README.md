# PolicyOS product-flow patterns

Components prevent visual drift; product-flow patterns prevent workflow drift. These contracts define canonical Atlas flows for PolicyOS experiences.

## Included flows

| Flow | File |
|---|---|
| Evidence intake | `evidence-intake.md` |
| Decision packet review | `decision-packet-review.md` |
| Failure triage | `failure-triage.md` |
| Audit export | `audit-export.md` |
| Dispute/appeal | `dispute-appeal.md` |
| Long-running jobs | `long-running-jobs.md` |
| Permission request | `permission-request.md` |

