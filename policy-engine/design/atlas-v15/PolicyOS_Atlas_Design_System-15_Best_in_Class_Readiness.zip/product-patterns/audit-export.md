# Audit export pattern

## Flow stages

1. Select export scope.
2. Preview included evidence and redactions.
3. Confirm format and recipients/storage.
4. Generate export with progress.
5. Show success/failure with file metadata.
6. Record audit event.

## Required export metadata

- export ID;
- actor;
- generation timestamp/timezone;
- source set;
- decision packet ID;
- redaction policy;
- evidence freshness;
- checksum/signature when available.

## Required states

- preparing;
- generating;
- partially generated;
- failed;
- completed;
- expired/unavailable;
- redacted.

