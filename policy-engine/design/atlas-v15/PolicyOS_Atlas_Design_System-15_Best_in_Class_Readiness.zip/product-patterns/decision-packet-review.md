# Decision packet review pattern

## Flow stages

1. Packet summary.
2. Evidence overview and freshness status.
3. Risk/governance checks.
4. Conflicts and uncertainty.
5. Reviewer comments/questions.
6. Approval, rejection, escalation or request changes.
7. Audit trail update.

## Required sections

| Section | Content |
|---|---|
| Summary | Decision object, status, owner and due date |
| Evidence | Source count, freshness, provenance and missing items |
| Governance | Required checks, pass/warn/block states |
| Risk | Known uncertainty, conflicts and high-impact factors |
| Action | Clear CTAs with consequence copy |
| Audit | Who/what/when/why after final action |

## Required components/patterns

- GovernanceGate;
- Badge/status language;
- DataTable/DataVizTable for evidence;
- ValidationSummary or review-blocker summary;
- Dialog/AlertDialog for irreversible decisions later;
- Audit trail pattern.

