# Dispute and appeal pattern

## Flow stages

1. Start dispute from decision/audit entry.
2. Select reason and affected evidence.
3. Add new evidence or comments.
4. Route to reviewer/owner.
5. Track status and due date.
6. Resolve, uphold or reopen.
7. Update audit trail.

## Required states

- draft;
- submitted;
- under review;
- needs evidence;
- resolved;
- rejected;
- reopened;
- overdue.

## Required UX rules

- Preserve original decision context.
- Distinguish new evidence from existing evidence.
- Show reviewer identity/role.
- Require resolution reason.
- Make status changes audit-visible.

