# Evidence intake pattern

## Flow stages

1. Select source or upload file.
2. Validate type, size, permission and encryption state.
3. Parse/import with progress and cancel/retry.
4. Show extracted evidence summary.
5. Identify missing, stale or conflicting fields.
6. Confirm provenance and source metadata.
7. Attach to decision packet or route for review.

## Required states

- empty;
- uploading/importing;
- parsing;
- partial success;
- validation error;
- permission error;
- stale source;
- duplicate evidence;
- imported with warnings;
- imported successfully.

## Required metadata

- source system;
- actor;
- timestamp/timezone;
- file/source identifier;
- freshness;
- provenance;
- redaction/sensitivity;
- parsing confidence when applicable.

