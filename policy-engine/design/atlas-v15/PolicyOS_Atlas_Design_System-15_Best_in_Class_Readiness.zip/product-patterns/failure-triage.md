# Failure triage pattern

## Severity levels

| Severity | Meaning | UI behavior |
|---|---|---|
| Info | No action required | Inline note/status |
| Warning | Action can continue with risk | Warning status and detail |
| Blocker | Action cannot continue | Blocker summary and recovery path |
| Critical | Security/compliance/system risk | Escalation and audit event |

## Required copy

- What failed.
- Why it matters.
- What is affected.
- Whether work is saved.
- What the user can do next.
- Where to escalate.

## Required evidence

- timestamp;
- run/source ID;
- affected connector/system;
- retry status;
- audit trail link when relevant.

