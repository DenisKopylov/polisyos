# Long-running jobs pattern

## Required states

| State | Required UI |
|---|---|
| Queued | Position/expectation if available |
| Running | Progress or indeterminate state, current step |
| Paused | Reason and resume/cancel path |
| Canceling | Clear pending state |
| Canceled | Who/what canceled and whether partial output exists |
| Failed | Cause, retry and support path |
| Completed | Result summary and next action |
| Stale | Last update and refresh path |

## Accessibility requirements

- Live updates use governed live-region behavior.
- Do not announce noisy progress too frequently.
- Provide persistent status text, not only animation.
- Reduced-motion mode removes non-essential animation.
- Users can recover after navigation/refresh.

