# Permission request pattern

## Flow stages

1. User encounters restricted data/action.
2. UI explains boundary without leaking restricted content.
3. User requests access or selects alternate path.
4. Request is routed to owner/role.
5. Status is visible: pending, approved, denied, expired.
6. Audit trail records request and decision.

## Required copy

- What is blocked.
- Why it is blocked at a safe level of detail.
- Who can grant access or where request goes.
- Expected next step.
- Alternative path when available.

## Required states

- no access;
- request available;
- request pending;
- request approved;
- request denied;
- access expired;
- partial access.

