#!/usr/bin/env python3
"""Atlas token contrast audit.

This lightweight checker validates the color pairs that are most likely to
ship as text/control colors. It is intentionally dependency-free so it can run
in CI, design review, or procurement packaging without a build step.
"""
from __future__ import annotations

import datetime as _dt
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Tuple

ROOT = Path(__file__).resolve().parents[1]


def _hex_to_rgb(value: str) -> Tuple[float, float, float]:
    value = value.strip().lstrip("#")
    if len(value) == 3:
        value = "".join(ch * 2 for ch in value)
    if len(value) != 6:
        raise ValueError(f"Unsupported hex color: {value!r}")
    return tuple(int(value[i : i + 2], 16) / 255 for i in (0, 2, 4))  # type: ignore[return-value]


def _linear(channel: float) -> float:
    return channel / 12.92 if channel <= 0.04045 else ((channel + 0.055) / 1.055) ** 2.4


def luminance(hex_color: str) -> float:
    r, g, b = (_linear(c) for c in _hex_to_rgb(hex_color))
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def contrast(foreground: str, background: str) -> float:
    l1, l2 = luminance(foreground), luminance(background)
    hi, lo = max(l1, l2), min(l1, l2)
    return (hi + 0.05) / (lo + 0.05)


@dataclass(frozen=True)
class Pair:
    name: str
    fg: str
    bg: str
    intended_use: str
    min_ratio: float
    notes: str = ""


def status(pair: Pair) -> str:
    ratio = contrast(pair.fg, pair.bg)
    return "PASS" if ratio >= pair.min_ratio else "RESTRICT"


PAIRS: Iterable[Pair] = [
    Pair("primary text on paper", "#17191d", "#fbf8f2", "normal text", 4.5),
    Pair("secondary slate text on paper", "#40515f", "#fbf8f2", "normal text", 4.5),
    Pair("muted graphite on sand", "#40515f", "#f4efe6", "normal text", 4.5),
    Pair("teal semantic text on paper", "#115e57", "#fbf8f2", "normal text", 4.5),
    Pair("ember semantic text on paper", "#92391d", "#fbf8f2", "normal text", 4.5),
    Pair("gold semantic text on paper", "#6c5111", "#fbf8f2", "normal text", 4.5),
    Pair("primary button text on start", "#fff9f1", "#115e57", "button text", 4.5),
    Pair("primary button text on end", "#fff9f1", "#0f635d", "button text", 4.5),
    Pair("dark sidebar text", "#fff9f0", "#17191d", "normal text", 4.5),
    Pair("dark theme primary text", "#eef5ff", "#16202b", "normal text", 4.5),
    Pair("dark theme slate text", "#a1b3c8", "#16202b", "normal text", 4.5),
    Pair("dark theme teal text", "#5fd3ca", "#16202b", "normal text", 4.5),
    Pair("vibrant teal on paper", "#1c8b82", "#fbf8f2", "decorative/chart or large text only", 4.5, "Use semantic teal for normal text."),
    Pair("vibrant ember on paper", "#cb5a2e", "#fbf8f2", "decorative/chart or large text only", 4.5, "Use semantic ember for normal text."),
    Pair("vibrant gold on paper", "#b58b2b", "#fbf8f2", "decorative/chart or large text only", 4.5, "Use semantic gold for normal text."),
]


def make_markdown() -> str:
    now = _dt.datetime.now(_dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    rows = []
    for pair in PAIRS:
        ratio = contrast(pair.fg, pair.bg)
        rows.append(
            f"| {pair.name} | `{pair.fg}` | `{pair.bg}` | {pair.intended_use} | {ratio:.2f}:1 | {pair.min_ratio:.1f}:1 | {status(pair)} | {pair.notes} |"
        )
    restricted = [pair for pair in PAIRS if status(pair) != "PASS"]
    return "\n".join(
        [
            "# Atlas Contrast Audit",
            "",
            f"Generated: `{now}`",
            "",
            "This audit covers high-risk token pairs used for text and controls. It does not replace a full screenshot-based audit of every component state.",
            "",
            "| Pair | Foreground | Background | Intended use | Ratio | Required | Status | Notes |",
            "|---|---:|---:|---|---:|---:|---|---|",
            *rows,
            "",
            "## Interpretation",
            "",
            "- `PASS` means the pair meets the listed threshold for the stated use.",
            "- `RESTRICT` means the pair must not be used for normal body/UI text at that size. It can remain valid for charts, decoration, icons, fills, or large text where separately verified.",
            "- Primary action contrast now passes against both ends of the button gradient.",
            "",
            f"Restricted pairs: {len(restricted)}",
            "",
            "## JSON summary",
            "",
            "```json",
            json.dumps(
                [
                    {
                        "name": p.name,
                        "foreground": p.fg,
                        "background": p.bg,
                        "ratio": round(contrast(p.fg, p.bg), 2),
                        "required": p.min_ratio,
                        "status": status(p),
                        "intended_use": p.intended_use,
                    }
                    for p in PAIRS
                ],
                indent=2,
            ),
            "```",
            "",
        ]
    )


def main() -> int:
    print(make_markdown())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
