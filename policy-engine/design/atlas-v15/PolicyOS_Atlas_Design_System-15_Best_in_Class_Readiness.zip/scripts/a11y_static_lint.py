#!/usr/bin/env python3
"""Static accessibility heuristics for the Atlas design-system package.

This is not a replacement for a browser/assistive-technology audit. It catches
regressions that previously existed in the prototype: pointer-only divs,
buttons without explicit type, missing dashboard landmarks, duplicate nav ids,
and unlabelled auth/checkout controls.
"""
from __future__ import annotations

import datetime as _dt
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List

ROOT = Path(__file__).resolve().parents[1]


@dataclass
class Finding:
    severity: str
    file: str
    line: int
    check: str
    detail: str


def line_for(text: str, index: int) -> int:
    return text.count("\n", 0, index) + 1


def files() -> Iterable[Path]:
    for base in [ROOT / "ui_kits" / "dashboard", ROOT / "landing", ROOT / "preview"]:
        if base.exists():
            yield from base.rglob("*.jsx")
            yield from base.rglob("*.html")


def has_attr(tag: str, name: str) -> bool:
    return re.search(rf"\b{name}\s*=", tag) is not None


def check_clickables(path: Path, text: str) -> List[Finding]:
    findings: List[Finding] = []
    allowed = {"button", "a", "input", "select", "textarea", "summary"}

    # SVG <g> nodes can be interactive when they expose keyboard semantics.
    for match in re.finditer(r"<g\b", text):
        chunk = text[match.start() : match.start() + 800]
        if "onClick" not in chunk:
            continue
        required = ["role", "tabIndex", "onKeyDown", "aria-label"]
        missing = [attr for attr in required if attr not in chunk]
        if missing:
            findings.append(Finding("blocker", str(path.relative_to(ROOT)), line_for(text, match.start()), "interactive-svg-node", f"SVG <g> with onClick missing {', '.join(missing)}"))

    # Lowercase HTML elements with onClick need native semantics or explicit keyboard handling.
    # Uppercase React components are checked at their implementation boundary.
    for match in re.finditer(r"<([a-z][\w.]*)\b(?=[^>]*\bonClick\s*=)[^>]*>", text):
        tag = match.group(1)
        tag_lower = tag.lower()
        full_tag = match.group(0)
        if tag_lower in allowed or tag_lower == "g":
            continue
        if 'role="presentation"' in full_tag or "role='presentation'" in full_tag:
            continue
        if 'role="dialog"' in full_tag or "role='dialog'" in full_tag:
            continue
        if "stopPropagation" in full_tag and "onClick" in full_tag:
            continue
        has_keyboard_contract = ("role=" in full_tag and "tabIndex" in full_tag and "onKeyDown" in full_tag)
        if has_keyboard_contract:
            continue
        findings.append(Finding("blocker", str(path.relative_to(ROOT)), line_for(text, match.start()), "non-semantic-clickable", f"<{tag}> has onClick; use button/a/InteractiveCard or full keyboard semantics."))
    return findings


def check_button_type(path: Path, text: str) -> List[Finding]:
    findings: List[Finding] = []
    for match in re.finditer(r"<button\b([^>]*)>", text):
        tag = match.group(0)
        if not has_attr(tag, "type"):
            findings.append(Finding("warning", str(path.relative_to(ROOT)), line_for(text, match.start()), "button-type", "Button has no explicit type."))
    return findings


def check_sidebar_ids() -> List[Finding]:
    path = ROOT / "ui_kits" / "dashboard" / "Sidebar.jsx"
    if not path.exists():
        return [Finding("blocker", "ui_kits/dashboard/Sidebar.jsx", 1, "missing-sidebar", "Sidebar.jsx not found.")]
    text = path.read_text()
    ids = re.findall(r"id:\s*'([^']+)'", text)
    findings: List[Finding] = []
    seen = set()
    for nav_id in ids:
        if nav_id in seen:
            findings.append(Finding("blocker", str(path.relative_to(ROOT)), 1, "duplicate-route-id", f"Duplicate sidebar route id: {nav_id}"))
        seen.add(nav_id)
    return findings


def check_dashboard_landmarks() -> List[Finding]:
    path = ROOT / "ui_kits" / "dashboard" / "index.html"
    findings: List[Finding] = []
    if not path.exists():
        return [Finding("blocker", "ui_kits/dashboard/index.html", 1, "missing-dashboard", "Dashboard index not found.")]
    text = path.read_text()
    checks = [
        ("skip-link", "class=\"skip-link\""),
        ("main-landmark", "<main"),
        ("shared-token-css", "../../colors_and_type.css"),
        ("screen-title-update", "document.title"),
    ]
    for check, needle in checks:
        if needle not in text:
            findings.append(Finding("blocker", str(path.relative_to(ROOT)), 1, check, f"Missing {needle}"))
    return findings


def check_auth_labels() -> List[Finding]:
    path = ROOT / "landing" / "auth.html"
    findings: List[Finding] = []
    if not path.exists():
        return findings
    text = path.read_text()
    # All visible labels should use an explicit for attribute after this pass.
    for match in re.finditer(r"<label\b([^>]*)>", text):
        tag = match.group(0)
        if "class=\"sr-only\"" in tag:
            if not has_attr(tag, "for"):
                findings.append(Finding("warning", str(path.relative_to(ROOT)), line_for(text, match.start()), "sr-label-for", "Screen-reader-only label has no for attribute."))
        elif not has_attr(tag, "for"):
            findings.append(Finding("warning", str(path.relative_to(ROOT)), line_for(text, match.start()), "label-for", "Visible label has no explicit for attribute."))
    # Inputs inside auth should have ids unless they are hidden in future.
    for match in re.finditer(r"<input\b([^>]*)>", text):
        tag = match.group(0)
        if "type=\"hidden\"" in tag:
            continue
        if not has_attr(tag, "id"):
            findings.append(Finding("warning", str(path.relative_to(ROOT)), line_for(text, match.start()), "input-id", "Input has no id for label association."))
    return findings


def run() -> List[Finding]:
    findings: List[Finding] = []
    for path in files():
        text = path.read_text(errors="ignore")
        findings.extend(check_clickables(path, text))
        findings.extend(check_button_type(path, text))
    findings.extend(check_sidebar_ids())
    findings.extend(check_dashboard_landmarks())
    findings.extend(check_auth_labels())
    return findings


def markdown(findings: List[Finding]) -> str:
    now = _dt.datetime.now(_dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    blockers = [f for f in findings if f.severity == "blocker"]
    warnings = [f for f in findings if f.severity == "warning"]
    lines = [
        "# Atlas Static Accessibility Lint",
        "",
        f"Generated: `{now}`",
        "",
        "This heuristic scan catches common accessibility regressions in the static prototype package. It should be paired with browser-level axe/Playwright checks and manual assistive-technology testing.",
        "",
        f"- Blockers: **{len(blockers)}**",
        f"- Warnings: **{len(warnings)}**",
        "",
    ]
    if findings:
        lines.extend([
            "| Severity | File | Line | Check | Detail |",
            "|---|---|---:|---|---|",
        ])
        for f in findings:
            detail = f.detail.replace("|", "\\|")
            lines.append(f"| {f.severity} | `{f.file}` | {f.line} | `{f.check}` | {detail} |")
    else:
        lines.append("No findings for the configured static heuristics.")
    lines.append("")
    return "\n".join(lines)


def main() -> int:
    findings = run()
    report = markdown(findings)
    out = ROOT / "accessibility" / "audit-results.md"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(report, encoding="utf-8")
    print(report)
    return 1 if any(f.severity == "blocker" for f in findings) else 0


if __name__ == "__main__":
    raise SystemExit(main())
