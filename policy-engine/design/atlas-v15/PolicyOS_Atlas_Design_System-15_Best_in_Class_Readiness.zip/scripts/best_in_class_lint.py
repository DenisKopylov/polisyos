#!/usr/bin/env python3
"""Archive-only best-in-class readiness lint."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / "dist" / "verification" / "best-in-class-readiness-report.md"

REQUIRED_FILES = [
    "BEST_IN_CLASS_READINESS.md",
    "best-in-class/README.md",
    "best-in-class/readiness-matrix.md",
    "best-in-class/readiness-scorecard.json",
    "best-in-class/evidence-index.md",
    "best-in-class/browser-and-at-evidence-plan.md",
    "best-in-class/anti-patterns.md",
    "best-in-class/archive-hardening-checklist.md",
    "governance/README.md",
    "governance/RACI.md",
    "governance/RFC_TEMPLATE.md",
    "governance/ADR_TEMPLATE.md",
    "governance/deprecation-policy.md",
    "governance/release-governance.md",
    "governance/adoption-metrics.md",
    "governance/exception-register.md",
    "governance/component-health.schema.json",
    "governance/component-health.json",
    "governance/component-health.md",
    "internationalization/README.md",
    "internationalization/translation-contract.md",
    "internationalization/rtl-bidi.md",
    "internationalization/string-expansion.md",
    "internationalization/locale-formatting.md",
    "internationalization/i18n-test-matrix.md",
    "figma/README.md",
    "figma/component-parity.md",
    "figma/component-parity-index.md",
    "figma/variant-parity-contract.md",
    "figma/token-sync-runbook.md",
    "figma/design-qa-checklist.md",
    "content-design/README.md",
    "content-design/voice-and-tone.md",
    "content-design/terminology.md",
    "content-design/error-taxonomy.md",
    "content-design/microcopy-patterns.md",
    "content-design/trust-copy.md",
    "security-privacy-ux/README.md",
    "security-privacy-ux/sensitive-data-display.md",
    "security-privacy-ux/permission-states.md",
    "security-privacy-ux/redaction-export.md",
    "security-privacy-ux/audit-trail.md",
    "security-privacy-ux/destructive-actions.md",
    "product-patterns/README.md",
    "product-patterns/evidence-intake.md",
    "product-patterns/decision-packet-review.md",
    "product-patterns/failure-triage.md",
    "product-patterns/audit-export.md",
    "product-patterns/dispute-appeal.md",
    "product-patterns/long-running-jobs.md",
    "product-patterns/permission-request.md",
]

REQUIRED_SCORECARD_AREAS = {
    "release-consistency",
    "governance",
    "component-health",
    "accessibility-evidence",
    "internationalization",
    "figma-parity",
    "content-design",
    "security-privacy-ux",
    "product-flow-patterns",
    "runtime-browser-evidence",
}


def main() -> int:
    rows: list[tuple[str, bool, str]] = []
    for rel in REQUIRED_FILES:
        path = ROOT / rel
        ok = path.exists() and path.stat().st_size > 0
        rows.append((rel, ok, "present" if ok else "missing/empty"))

    scorecard_path = ROOT / "best-in-class" / "readiness-scorecard.json"
    if scorecard_path.exists():
        try:
            data = json.loads(scorecard_path.read_text(encoding="utf-8"))
            areas = {item.get("area") for item in data.get("areas", [])}
            missing = sorted(REQUIRED_SCORECARD_AREAS - areas)
            rows.append(("scorecard required areas", not missing, "missing: " + ", ".join(missing) if missing else "complete"))
        except Exception as exc:
            rows.append(("scorecard required areas", False, f"invalid json: {exc}"))
    else:
        rows.append(("scorecard required areas", False, "missing scorecard"))

    health_path = ROOT / "governance" / "component-health.json"
    manifest_path = ROOT / "component-library" / "component-manifest.json"
    if health_path.exists() and manifest_path.exists():
        health = json.loads(health_path.read_text(encoding="utf-8"))
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        rows.append((
            "component health count matches manifest",
            len(health.get("components", [])) == len(manifest.get("components", [])),
            f"{len(health.get('components', []))}/{len(manifest.get('components', []))}",
        ))

    ok = all(r[1] for r in rows)
    now = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    lines = ["# Atlas best-in-class readiness report", "", f"Generated: `{now}`", "", "| Check | Result | Evidence |", "|---|---|---|"]
    for label, passed, evidence in rows:
        lines.append(f"| `{label}` | **{'PASS' if passed else 'FAIL'}** | {evidence} |")
    lines.extend(["", f"Overall result: **{'PASS' if ok else 'FAIL'}**", ""])
    REPORT.write_text("\n".join(lines), encoding="utf-8")
    print("\n".join(lines))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
