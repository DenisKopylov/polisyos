#!/usr/bin/env python3
"""Compatibility wrapper for the Atlas token pipeline.

Canonical implementation: scripts/token_build.py.
"""
from pathlib import Path
import runpy

ROOT = Path(__file__).resolve().parents[1]
runpy.run_path(str(ROOT / 'scripts' / 'token_build.py'), run_name='__main__')
