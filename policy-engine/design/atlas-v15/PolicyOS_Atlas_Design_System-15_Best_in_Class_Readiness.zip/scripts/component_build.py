#!/usr/bin/env python3
"""Build Atlas component library artifacts.

This is intentionally dependency-light. It uses the checked-in TypeScript compiler
available in the environment and does not install packages.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PKG = ROOT / 'packages' / 'atlas-ui'
PKG_DIST = PKG / 'dist'
ROOT_DIST = ROOT / 'dist' / 'atlas-ui'


def run(cmd: list[str], cwd: Path = ROOT) -> None:
    print('+ ' + ' '.join(cmd))
    subprocess.run(cmd, cwd=cwd, check=True)


def copytree(src: Path, dst: Path) -> None:
    if dst.exists():
        shutil.rmtree(dst, ignore_errors=True)
    shutil.copytree(src, dst, dirs_exist_ok=True)


def main() -> int:
    if not PKG.exists():
        print('packages/atlas-ui is missing', file=sys.stderr)
        return 1
    if PKG_DIST.exists():
        shutil.rmtree(PKG_DIST, ignore_errors=True)
    run(['tsc', '-p', 'packages/atlas-ui/tsconfig.json'])
    shutil.copy2(PKG / 'src' / 'atlas-ui.css', PKG_DIST / 'atlas-ui.css')
    shutil.copy2(PKG / 'component-manifest.json', PKG_DIST / 'component-manifest.json')
    for name in ['README.md', 'CHANGELOG.md', 'MIGRATION.md', 'package.json', 'state-matrix.json', 'state-taxonomy.json', 'component-state-matrix.json', 'responsive-contract.json', 'dashboard-responsive.json', 'data-visualization.json', 'data-viz.json', 'data-viz-manifest.json', 'chart-grammar.json', 'data-viz-grammar.json', 'theme-manifest.json', 'theme-modes.json', 'theming-contract.json']:
        src = PKG / name
        if src.exists():
            shutil.copy2(src, PKG_DIST / name)
    package_json = json.loads((PKG / 'package.json').read_text(encoding='utf-8'))
    dist_package = {
        'name': package_json['name'],
        'version': package_json['version'],
        'type': 'module',
        'private': package_json.get('private', True),
        'main': './esm/index.js',
        'module': './esm/index.js',
        'types': './esm/index.d.ts',
        'exports': package_json['exports'],
        'peerDependencies': package_json['peerDependencies'],
        'sideEffects': package_json['sideEffects'],
        'stateMatrix': './state-matrix.json',
        'stateTaxonomy': './state-taxonomy.json',
        'componentStateMatrix': './component-state-matrix.json',
        'responsiveContract': './responsive-contract.json',
        'dashboardResponsive': './dashboard-responsive.json',
        'dataVisualization': './data-visualization.json',
        'dataViz': './data-viz.json',
        'chartGrammar': './chart-grammar.json',
        'theming': './theme-manifest.json',
        'themeModes': './theme-modes.json',
        'builtAt': datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00', 'Z'),
    }
    (PKG_DIST / 'package.json').write_text(json.dumps(dist_package, indent=2) + '\n', encoding='utf-8')
    copytree(PKG_DIST, ROOT_DIST)
    print(f'Built Atlas UI package into {ROOT_DIST.relative_to(ROOT)}')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
