#!/usr/bin/env python3
"""Generate Atlas component health artifacts from the component manifest."""
from __future__ import annotations

import json
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "component-library" / "component-manifest.json"
OUT_JSON = ROOT / "governance" / "component-health.json"
OUT_MD = ROOT / "governance" / "component-health.md"


def health_for(component: dict) -> tuple[str, list[str]]:
    risks: list[str] = []
    status = component.get("status", "unknown")
    if status != "stable":
        risks.append(f"maturity is {status}")
    if not component.get("docs"):
        risks.append("missing docs link")
    if not component.get("story"):
        risks.append("missing story link")
    if not component.get("owner"):
        risks.append("missing owner")
    if component.get("stateCoverage", {}).get("stateCount", 0) < 7:
        risks.append("low state coverage")
    if status == "stable" and not risks:
        return "ready", []
    if len(risks) <= 2:
        return "watch", risks
    return "needs-review", risks


def main() -> int:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    release = manifest.get("version", "unknown")
    rows = []
    for c in manifest.get("components", []):
        health, risks = health_for(c)
        rows.append({
            "name": c.get("name"),
            "status": c.get("status", "unknown"),
            "owner": c.get("owner", ""),
            "docs": c.get("docs", ""),
            "story": c.get("story", ""),
            "stateCount": c.get("stateCoverage", {}).get("stateCount", 0),
            "health": health,
            "risks": risks,
            "nextReview": "2026-07-31" if health != "ready" else "2026-09-30",
        })

    OUT_JSON.parent.mkdir(parents=True, exist_ok=True)
    OUT_JSON.write_text(json.dumps({
        "schemaVersion": "1.0.0",
        "release": release,
        "generatedAt": date.today().isoformat(),
        "components": rows,
    }, indent=2) + "\n", encoding="utf-8")

    counts: dict[str, int] = {}
    for r in rows:
        counts[r["health"]] = counts.get(r["health"], 0) + 1

    lines = [
        "# Atlas component health",
        "",
        f"Release: `{release}`",
        f"Components: **{len(rows)}**",
        "",
        "| Health | Count |",
        "|---|---|",
    ]
    for key in ["ready", "watch", "needs-review"]:
        lines.append(f"| {key} | {counts.get(key, 0)} |")
    lines.extend(["", "| Component | Status | States | Health | Risks | Owner |", "|---|---|---:|---|---|---|"])
    for r in rows:
        risk = ", ".join(r["risks"]) if r["risks"] else "none"
        lines.append(f"| {r['name']} | {r['status']} | {r['stateCount']} | {r['health']} | {risk} | {r['owner']} |")

    OUT_MD.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Generated {OUT_JSON.relative_to(ROOT)} and {OUT_MD.relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
