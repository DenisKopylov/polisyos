#!/usr/bin/env python3
"""Static quality gate for the Atlas component library."""
from __future__ import annotations

import json
import re
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / 'component-library' / 'component-manifest.json'
REPORT = ROOT / 'component-library' / 'component-library-audit.md'
DIST_REPORT = ROOT / 'dist' / 'atlas-ui' / 'component-library-audit.md'
SRC_INDEX = ROOT / 'packages' / 'atlas-ui' / 'src' / 'index.ts'
CSS = ROOT / 'packages' / 'atlas-ui' / 'src' / 'atlas-ui.css'
DIST = ROOT / 'dist' / 'atlas-ui'
HEX_RE = re.compile(r'#[0-9a-fA-F]{3,8}\b')
RGB_RE = re.compile(r'\b(?:rgba?|hsla?)\(([^)]*)\)')

REQUIRED_COMPONENTS = {'Button','Badge','Panel','Card','MetricCard','RunCard','TextField','TextArea','SelectField','Checkbox','Switch','Tabs','Dialog','Toast','EmptyState','Skeleton','DataTable','GovernanceGate','Form','FormSection','FieldGroup','ValidationSummary','RadioGroup','CheckboxGroup','SearchField','PasswordField','SecretField','NumberField','RangeField','DateField','DateRangeField','FileUpload','TokenInput','Combobox','CharacterCount','DashboardShell','DashboardTopBar','ResponsiveGrid','ScrollRegion','ChartFrame','ChartLegend','ChartTooltip','Sparkline','BarChart','LineChart','Heatmap','UncertaintyBand','ProvenanceGraph','ChartDataTable','CausalGraph','ProvenanceMap','ChartAnnotation','DataVizTable','ThemeProvider','ThemeToggle','AccessibilityModePanel'}
REQUIRED_FIELDS = {'name','status','package','source','docs','story','tokens','states','accessibility','owner','stateMatrix','stateMatrixId','stateContract'}
VALID_STATUS = {'experimental','beta','stable','deprecated'}

@dataclass
class Finding:
    severity: str
    subject: str
    message: str


def rel(path: Path) -> str:
    return str(path.relative_to(ROOT)).replace('\\', '/')


def text(path: Path) -> str:
    return path.read_text(encoding='utf-8', errors='ignore')


def scan_visual_values(paths: Iterable[Path]) -> list[Finding]:
    findings: list[Finding] = []
    for path in paths:
      if not path.exists():
        continue
      for number, line in enumerate(text(path).splitlines(), start=1):
        if 'http://' in line or 'https://' in line:
            continue
        for match in HEX_RE.finditer(line):
            findings.append(Finding('blocker', rel(path), f'raw hex color `{match.group(0)}` on line {number}'))
        for match in RGB_RE.finditer(line):
            value = match.group(0)
            if 'var(' not in value:
                findings.append(Finding('blocker', rel(path), f'raw functional color `{value}` on line {number}'))
    return findings


def main() -> int:
    findings: list[Finding] = []
    if not MANIFEST.exists():
        findings.append(Finding('blocker','manifest','component manifest is missing'))
        data = {'components': []}
    else:
        data = json.loads(text(MANIFEST))
    components = data.get('components', [])
    names = {c.get('name') for c in components}
    missing = sorted(REQUIRED_COMPONENTS - names)
    extra = sorted(names - REQUIRED_COMPONENTS)
    for name in missing:
        findings.append(Finding('blocker', name, 'required component missing from manifest'))
    for name in extra:
        findings.append(Finding('warning', name or 'unknown', 'manifest has a component outside the required v15 set'))

    index_text = text(SRC_INDEX) if SRC_INDEX.exists() else ''
    source_paths: list[Path] = [CSS]
    for item in components:
        subject = str(item.get('name', 'unknown'))
        missing_fields = REQUIRED_FIELDS - set(item.keys())
        for field in sorted(missing_fields):
            findings.append(Finding('blocker', subject, f'missing manifest field `{field}`'))
        if item.get('status') not in VALID_STATUS:
            findings.append(Finding('blocker', subject, f'invalid maturity status `{item.get("status")}`'))
        for list_field in ['tokens','states','accessibility']:
            if not isinstance(item.get(list_field), list) or len(item.get(list_field, [])) < 2:
                findings.append(Finding('blocker', subject, f'`{list_field}` must contain at least two entries'))
        src = ROOT / str(item.get('source',''))
        doc = ROOT / str(item.get('docs',''))
        story = ROOT / str(item.get('story',''))
        state_matrix = ROOT / str(item.get('stateMatrix',''))
        if not state_matrix.exists():
            findings.append(Finding('blocker', subject, f'state matrix docs missing: `{item.get("stateMatrix")}`'))
        if not src.exists():
            findings.append(Finding('blocker', subject, f'source file missing: `{item.get("source")}`'))
        else:
            source_paths.append(src)
        if not doc.exists():
            findings.append(Finding('blocker', subject, f'docs file missing: `{item.get("docs")}`'))
        else:
            doc_text = text(doc)
            for heading in ['## Usage','## Style','## Code contract','## Accessibility','## State matrix','## Content guidance']:
                if heading not in doc_text:
                    findings.append(Finding('blocker', subject, f'docs missing heading `{heading}`'))
        if not story.exists():
            findings.append(Finding('blocker', subject, f'story file missing: `{item.get("story")}`'))
        elif subject not in text(story):
            findings.append(Finding('blocker', subject, f'story `{item.get("story")}` does not reference `{subject}`'))

        if subject not in index_text:
            findings.append(Finding('blocker', subject, 'not exported from packages/atlas-ui/src/index.ts'))

    findings.extend(scan_visual_values(source_paths))

    required_dist = [
        DIST / 'esm' / 'index.js',
        DIST / 'esm' / 'index.d.ts',
        DIST / 'atlas-ui.css',
        DIST / 'component-manifest.json',
        DIST / 'package.json',
    ]
    for path in required_dist:
        if not path.exists():
            findings.append(Finding('blocker', rel(path), 'build artifact missing; run scripts/component_build.py'))

    blockers = [f for f in findings if f.severity == 'blocker']
    warnings = [f for f in findings if f.severity == 'warning']
    now = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00','Z')
    lines = [
        '# Atlas Component Library Audit',
        '',
        f'Generated: `{now}`',
        '',
        '## Gate summary',
        '',
        f'- Components in manifest: **{len(components)}**',
        f'- Required v15 components: **{len(REQUIRED_COMPONENTS)}**',
        '- Story coverage required: **yes**',
        f'- Blockers: **{len(blockers)}**',
        f'- Warnings: **{len(warnings)}**',
        '',
        '## Findings',
        '',
        '| Severity | Subject | Message |',
        '|---|---|---|',
    ]
    if findings:
        for finding in findings:
            lines.append(f'| `{finding.severity}` | `{finding.subject}` | {finding.message} |')
    else:
        lines.append('| — | — | No findings. |')
    lines.extend(['', '## Components', '', '| Component | Status | Docs | Source |', '|---|---|---|---|'])
    for item in components:
        lines.append(f'| {item.get("name")} | `{item.get("status")}` | `{item.get("docs")}` | `{item.get("source")}` |')
    lines.append('')
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text('\n'.join(lines), encoding='utf-8')
    if DIST.exists():
        DIST_REPORT.parent.mkdir(parents=True, exist_ok=True)
        DIST_REPORT.write_text('\n'.join(lines), encoding='utf-8')
    print('\n'.join(lines))
    return 1 if blockers else 0

if __name__ == '__main__':
    raise SystemExit(main())
