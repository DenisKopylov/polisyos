#!/usr/bin/env python3
"""Static release gate for Atlas dashboard responsive model."""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / 'dashboard-responsive' / 'responsive-manifest.json'
REPORT = ROOT / 'dashboard-responsive' / 'audit-results.md'
RESPONSIVE_REPORT = ROOT / 'dashboard-responsive' / 'responsive-audit.md'
COMPONENT_REPORT = ROOT / 'component-library' / 'dashboard-responsive' / 'dashboard-responsive-audit.md'
DIST_REPORT = ROOT / 'dist' / 'verification' / 'dashboard-responsive-audit.md'
DIST_RESPONSIVE_REPORT = ROOT / 'dist' / 'verification' / 'responsive-audit.md'
CONTRACT = ROOT / 'dashboard-responsive' / 'responsive-contract.json'

REQUIRED_WINDOW_CLASSES = {'compact', 'medium', 'expanded', 'large', 'extra-large'}
REQUIRED_DOCS = [
    'dashboard-responsive/README.md',
    'dashboard-responsive/breakpoints-and-layout.md',
    'dashboard-responsive/shell-behavior.md',
    'dashboard-responsive/data-density-and-tables.md',
    'dashboard-responsive/print-export.md',
    'dashboard-responsive/testing-contract.md',
    'component-library/dashboard-responsive/README.md',
    'component-library/dashboard-responsive/shell-behavior.md',
    'component-library/dashboard-responsive/data-density.md',
    'component-library/dashboard-responsive/print-and-export.md',
    'component-library/dashboard-responsive/operator-wall.md',
]
REQUIRED_SOURCE = [
    'ui_kits/dashboard/index.html',
    'ui_kits/dashboard/Sidebar.jsx',
    'ui_kits/dashboard/dashboard-responsive.css',
    'packages/atlas-ui/src/atlas-ui.css',
    'packages/atlas-ui/src/components/DataTable/DataTable.tsx',
    'packages/atlas-ui/stories/DashboardResponsive.stories.tsx',
    'packages/atlas-ui/stories/ResponsiveDashboard.stories.tsx',
    'packages/atlas-ui/src/dashboard-responsive-contracts.ts',
]
REQUIRED_MIRRORS = [
    'packages/atlas-ui/dashboard-responsive.json',
    'dist/dashboard-responsive/responsive-manifest.json',
]
REQUIRED_TOKEN_VARS = {
    '--atlas-dashboard-max-width',
    '--atlas-dashboard-nav-width',
    '--atlas-dashboard-nav-rail-width',
    '--atlas-dashboard-nav-drawer-width',
    '--atlas-dashboard-bottom-nav-height',
    '--atlas-dashboard-overlay-surface',
    '--atlas-dashboard-overlay-backdrop',
    '--atlas-responsive-grid-min-column',
    '--atlas-dashboard-data-region-min-block',
    '--target-min',
}

@dataclass
class Finding:
    severity: str
    subject: str
    message: str


def rel(path: Path) -> str:
    return str(path.relative_to(ROOT)).replace('\\', '/')


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding='utf-8', errors='ignore')


def generated_token_vars() -> set[str]:
    p = ROOT / 'tokens' / 'generated' / 'atlas.tokens.css'
    if not p.exists():
        return set()
    return set(re.findall(r'--[a-z0-9-]+(?=\s*:)', p.read_text(encoding='utf-8', errors='ignore')))


def has_all(text: str, snippets: list[str]) -> bool:
    return all(snippet in text for snippet in snippets)


def main() -> int:
    findings: list[Finding] = []
    for item in REQUIRED_DOCS + REQUIRED_SOURCE:
        if not (ROOT / item).exists():
            findings.append(Finding('blocker', item, 'required responsive artifact missing'))
    for item in REQUIRED_MIRRORS:
        if not (ROOT / item).exists():
            findings.append(Finding('blocker', item, 'responsive generated mirror missing; run scripts/dashboard_responsive_build.py'))

    manifest = {}
    if CONTRACT.exists():
        contract = json.loads(CONTRACT.read_text(encoding='utf-8'))
    else:
        contract = {}
        findings.append(Finding('blocker', rel(CONTRACT), 'canonical responsive contract missing'))

    if MANIFEST.exists():
        manifest = json.loads(MANIFEST.read_text(encoding='utf-8'))
        ids = {item.get('id') for item in manifest.get('windowClasses', [])}
        missing_ids = sorted(REQUIRED_WINDOW_CLASSES - ids)
        extra_ids = sorted(ids - REQUIRED_WINDOW_CLASSES)
        for item in missing_ids:
            findings.append(Finding('blocker', 'windowClasses', f'missing `{item}` window class'))
        for item in extra_ids:
            findings.append(Finding('warning', 'windowClasses', f'unexpected `{item}` window class'))
        for item in manifest.get('windowClasses', []):
            if len(item.get('acceptance', [])) < 3:
                findings.append(Finding('blocker', item.get('id', 'windowClass'), 'window class must define at least three acceptance criteria'))
        if len(manifest.get('layoutPatterns', [])) < 5:
            findings.append(Finding('blocker', 'layoutPatterns', 'responsive manifest must define at least five layout patterns'))
    else:
        findings.append(Finding('blocker', rel(MANIFEST), 'canonical responsive manifest missing'))

    if all((ROOT / item).exists() for item in REQUIRED_MIRRORS) and MANIFEST.exists():
        canonical = json.loads(MANIFEST.read_text(encoding='utf-8'))
        for item in REQUIRED_MIRRORS:
            mirror = json.loads((ROOT / item).read_text(encoding='utf-8'))
            normalized = dict(mirror)
            normalized.pop('generatedAt', None)
            if normalized != canonical:
                findings.append(Finding('blocker', item, 'generated mirror differs from canonical manifest except generatedAt'))

    idx = read('ui_kits/dashboard/index.html') if (ROOT / 'ui_kits/dashboard/index.html').exists() else ''
    sidebar = read('ui_kits/dashboard/Sidebar.jsx') if (ROOT / 'ui_kits/dashboard/Sidebar.jsx').exists() else ''
    standalone_css = read('ui_kits/dashboard/dashboard-responsive.css') if (ROOT / 'ui_kits/dashboard/dashboard-responsive.css').exists() else ''
    package_css = read('packages/atlas-ui/src/atlas-ui.css') if (ROOT / 'packages/atlas-ui/src/atlas-ui.css').exists() else ''
    data_table = read('packages/atlas-ui/src/components/DataTable/DataTable.tsx') if (ROOT / 'packages/atlas-ui/src/components/DataTable/DataTable.tsx').exists() else ''
    story = read('packages/atlas-ui/stories/ResponsiveDashboard.stories.tsx') if (ROOT / 'packages/atlas-ui/stories/ResponsiveDashboard.stories.tsx').exists() else ''

    checks = [
        ('index-links-css', has_all(idx, ['../../packages/atlas-ui/src/atlas-ui.css', 'dashboard-responsive.css'])),
        ('index-window-class-runtime', has_all(idx, ['ATLAS_WINDOW_CLASSES', 'useWindowClass', 'data-atlas-window-class'])),
        ('index-drawer-a11y', has_all(idx, ['ariaControls="atlas-dashboard-drawer"', 'ariaExpanded={navOpen', "event.key === 'Escape'", 'body.dataset.atlasNavOpen'])),
        ('index-bottom-nav', has_all(idx, ['MobileBottomNav', 'atlas-mobile-bottom-nav', 'DASHBOARD_QUICK_NAV'])),
        ('index-no-scale-shell', 'transform: scale' not in idx and "gridTemplateColumns:'252px" not in idx),
        ('sidebar-native-buttons', has_all(sidebar, ['type="button"', 'aria-current', 'aria-label={`${item.label}', 'title={item.label}'])),
        ('sidebar-drawer-contract', has_all(sidebar, ['data-open', 'aria-hidden', 'inert=', 'onClose?.()'])),
        ('standalone-css-breakpoints', has_all(standalone_css, ['@media (max-width: 1279px)', '@media (max-width: 904px)', '@media (max-width: 767px)', '@media (max-width: 479px)'])),
        ('standalone-css-bottom-nav', has_all(standalone_css, ['.atlas-mobile-bottom-nav', '--atlas-dashboard-bottom-nav-height', 'env(safe-area-inset-bottom)'])),
        ('package-shell-css', has_all(package_css, ['.atlas-dashboard-shell', '.atlas-dashboard-layout', '.atlas-dashboard-drawer', '.atlas-dashboard-backdrop', '.atlas-responsive-grid'])),
        ('package-data-region-css', has_all(package_css, ['.atlas-adaptive-data-region', '.atlas-adaptive-data-region-scroll', '.atlas-scroll-region'])),
        ('datatable-responsive-api', has_all(data_table, ['responsiveMode', 'data-label', 'role="region"', 'priority?', 'data-responsive-mode'])),
        ('storybook-responsive-story', has_all(story, ['DashboardShell', 'ResponsiveGrid', 'ScrollRegion', 'DataTable'])),
    ]
    for subject, ok in checks:
        if not ok:
            findings.append(Finding('blocker', subject, 'responsive contract check failed'))

    token_vars = generated_token_vars()
    missing_tokens = sorted(REQUIRED_TOKEN_VARS - token_vars)
    for var in missing_tokens:
        findings.append(Finding('blocker', 'tokens', f'missing generated token `{var}`'))

    for doc in REQUIRED_DOCS:
        p = ROOT / doc
        if p.exists() and len(p.read_text(encoding='utf-8', errors='ignore').strip()) < 400:
            findings.append(Finding('warning', doc, 'responsive guidance is too short for release evidence'))

    window_count = len(manifest.get('windowClasses', [])) if isinstance(manifest, dict) else 0
    breakpoint_count = len(contract.get('breakpoints', [])) if isinstance(contract, dict) else 0
    shell_mode_count = len(contract.get('shellModes', [])) if isinstance(contract, dict) else 0
    layout_count = len(manifest.get('layoutPatterns', [])) if isinstance(manifest, dict) else 0
    acceptance_count = sum(len(item.get('acceptance', [])) for item in manifest.get('windowClasses', [])) if isinstance(manifest, dict) else 0
    blockers = [f for f in findings if f.severity == 'blocker']
    warnings = [f for f in findings if f.severity == 'warning']
    now = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00', 'Z')
    lines = [
        '# Atlas Dashboard Responsive Audit', '',
        f'Generated: `{now}`', '',
        '## Gate summary', '',
        f'- Window classes: **{window_count}**',
        f'- Required window classes: **{len(REQUIRED_WINDOW_CLASSES)}**',
        f'- Breakpoints: **{breakpoint_count}**',
        f'- Shell modes: **{shell_mode_count}**',
        f'- Layout patterns: **{layout_count}**',
        f'- Responsive tokens checked: **{len(REQUIRED_TOKEN_VARS)}**',
        f'- Acceptance criteria: **{acceptance_count}**',
        '- Navigation modes covered: **expanded rail / icon rail / modal drawer / compact bottom nav**',
        '- Data behavior covered: **wrapping grid / named local scroll / stacked table cards**',
        f'- Blockers: **{len(blockers)}**',
        f'- Warnings: **{len(warnings)}**', '',
        '## Findings', '',
        '| Severity | Subject | Message |', '|---|---|---|',
    ]
    if findings:
        for finding in findings:
            lines.append(f'| `{finding.severity}` | `{finding.subject}` | {finding.message} |')
    else:
        lines.append('| — | — | No findings. |')
    lines += [
        '', '## Evidence', '',
        '- `dashboard-responsive/responsive-manifest.json` defines canonical window classes, layout patterns and acceptance criteria.',
        '- `packages/atlas-ui/src/atlas-ui.css` provides token-only shell, drawer, rail, grid, pane and scroll-region behavior.',
        '- `ui_kits/dashboard/index.html` consumes the class-based shell, sticky topbar, controlled drawer and compact bottom navigation.',
        '- `ui_kits/dashboard/Sidebar.jsx` uses native buttons with persistent accessible names in full rail, icon rail and drawer modes.',
        '- `DataTable` exposes scroll and card reflow modes for dense policy data.', '',
    ]
    for report in [REPORT, RESPONSIVE_REPORT, COMPONENT_REPORT, DIST_REPORT, DIST_RESPONSIVE_REPORT]:
        report.parent.mkdir(parents=True, exist_ok=True)
        report.write_text('\n'.join(lines), encoding='utf-8')
    print('\n'.join(lines))
    return 1 if blockers else 0


if __name__ == '__main__':
    raise SystemExit(main())
