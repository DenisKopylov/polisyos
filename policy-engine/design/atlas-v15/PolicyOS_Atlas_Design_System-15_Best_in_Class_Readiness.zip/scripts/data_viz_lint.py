#!/usr/bin/env python3
"""Release gate for Atlas data-visualization grammar and components."""
from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / 'data-visualization' / 'data-viz-manifest.json'
GRAMMAR = ROOT / 'data-visualization' / 'chart-grammar.json'
COMPONENT_MANIFEST = ROOT / 'component-library' / 'component-manifest.json'
CSS = ROOT / 'tokens' / 'generated' / 'atlas.tokens.css'
REPORT = ROOT / 'data-visualization' / 'audit-results.md'
DIST_REPORT = ROOT / 'dist' / 'data-visualization' / 'audit-results.md'

REQUIRED_COMPONENTS = {
    'ChartFrame', 'ChartLegend', 'ChartTooltip', 'Sparkline', 'LineChart', 'BarChart',
    'UncertaintyBand', 'Heatmap', 'ProvenanceGraph', 'ChartDataTable', 'CausalGraph',
    'ProvenanceMap', 'ChartAnnotation', 'DataVizTable',
}
REQUIRED_CHART_TYPES = {'line','sparkline','bar','stacked-bar','distribution','uncertainty-band','heatmap','causal-dag','provenance-lineage','waterfall','timeline','gantt','funnel','sankey','scatter','map'}
REQUIRED_DOCS = [
    'README.md', 'chart-grammar.json', 'chart-selection.md', 'visual-encoding.md',
    'palettes-and-patterns.md', 'accessibility-contract.md',
    'uncertainty-and-confidence.md', 'interaction-contract.md',
    'exported-data-table.md', 'testing-contract.md', 'policyos-patterns.md',
]
REQUIRED_TOKENS = [
    '--atlas-viz-canvas-surface', '--atlas-viz-axis', '--atlas-viz-grid',
    '--atlas-viz-series-1', '--atlas-viz-series-2', '--atlas-viz-ci-80',
    '--atlas-viz-tooltip-surface', '--atlas-viz-node-border',
]
MIRRORS = [
    ROOT / 'packages' / 'atlas-ui' / 'data-visualization.json',
    ROOT / 'packages' / 'atlas-ui' / 'data-viz.json',
    ROOT / 'packages' / 'atlas-ui' / 'data-viz-manifest.json',
    ROOT / 'dist' / 'data-visualization' / 'data-viz-manifest.json',
    ROOT / 'dist' / 'data-visualization' / 'data-viz.json',
    ROOT / 'dist' / 'atlas-ui' / 'data-visualization.json',
    ROOT / 'dist' / 'atlas-ui' / 'data-viz.json',
]


@dataclass
class Finding:
    severity: str
    subject: str
    message: str


def rel(path: Path) -> str:
    return str(path.relative_to(ROOT)).replace('\\', '/')


def load(path: Path) -> Any:
    return json.loads(path.read_text(encoding='utf-8'))


def main() -> int:
    findings: list[Finding] = []

    for doc in REQUIRED_DOCS:
        path = ROOT / 'data-visualization' / doc
        if not path.exists():
            findings.append(Finding('blocker', doc, 'required data-viz documentation missing'))

    if not MANIFEST.exists():
        findings.append(Finding('blocker', rel(MANIFEST), 'data-viz manifest missing'))
        manifest = {'components': [], 'chartTypes': [], 'requiredEvidence': {}}
    else:
        manifest = load(MANIFEST)

    if not GRAMMAR.exists():
        findings.append(Finding('blocker', rel(GRAMMAR), 'chart grammar missing'))
        grammar = {'markTypes': [], 'encodingChannels': {}}
    else:
        grammar = load(GRAMMAR)

    chart_ids = {item.get('id') for item in manifest.get('chartTypes', [])}
    for cid in sorted(REQUIRED_CHART_TYPES - chart_ids):
        findings.append(Finding('blocker', cid, 'required chart type missing from data-viz manifest'))
    for item in manifest.get('chartTypes', []):
        subject = item.get('id', 'unknown')
        if item.get('colorOnlyAllowed') is not False:
            findings.append(Finding('blocker', subject, 'colorOnlyAllowed must be false'))
        if item.get('textSummaryRequired') is not True:
            findings.append(Finding('blocker', subject, 'textSummaryRequired must be true'))
        if item.get('dataTableRequired') is not True:
            findings.append(Finding('blocker', subject, 'dataTableRequired must be true'))
        if not item.get('primaryComponent'):
            findings.append(Finding('blocker', subject, 'primaryComponent missing'))

    required = manifest.get('requiredEvidence', {})
    for field in ['textSummaryRequired', 'dataTableEquivalentRequired', 'sourceRequired', 'noColorAlone']:
        if required.get(field) is not True:
            findings.append(Finding('blocker', 'requiredEvidence', f'{field} must be true'))

    if len(grammar.get('markTypes', [])) < 8:
        findings.append(Finding('blocker', 'chart-grammar', 'markTypes must cover at least eight visualization primitives'))
    if len(grammar.get('encodingChannels', {}).get('primary', [])) < 4:
        findings.append(Finding('blocker', 'chart-grammar', 'primary encoding channels too thin'))

    manifest_components = set(manifest.get('components', []))
    for name in sorted(REQUIRED_COMPONENTS - manifest_components):
        findings.append(Finding('blocker', name, 'required component missing from data-viz manifest'))

    if COMPONENT_MANIFEST.exists():
        component_manifest = load(COMPONENT_MANIFEST)
        by_name = {item.get('name'): item for item in component_manifest.get('components', [])}
    else:
        by_name = {}
        findings.append(Finding('blocker', rel(COMPONENT_MANIFEST), 'component manifest missing'))

    for name in sorted(REQUIRED_COMPONENTS):
        item = by_name.get(name)
        if not item:
            findings.append(Finding('blocker', name, 'component not present in component manifest'))
            continue
        for field in ['source', 'docs', 'story', 'dataVizContract', 'stateMatrix']:
            if field not in item:
                findings.append(Finding('blocker', name, f'component manifest missing {field}'))
        for path_field in ['source', 'docs', 'story']:
            path = ROOT / str(item.get(path_field, ''))
            if not path.exists():
                findings.append(Finding('blocker', name, f'{path_field} file missing: {item.get(path_field)}'))
        if len(item.get('accessibility', [])) < 3:
            findings.append(Finding('blocker', name, 'accessibility contract too thin'))
        if len(item.get('tokens', [])) < 2:
            findings.append(Finding('blocker', name, 'token contract too thin'))

    css_text = CSS.read_text(encoding='utf-8', errors='ignore') if CSS.exists() else ''
    for token in REQUIRED_TOKENS:
        if token not in css_text:
            findings.append(Finding('blocker', token, 'required data-viz token missing from generated CSS'))

    canonical = load(MANIFEST) if MANIFEST.exists() else None
    for mirror in MIRRORS:
        if not mirror.exists():
            findings.append(Finding('blocker', rel(mirror), 'generated data-viz mirror missing; run scripts/data_viz_build.py'))
        elif canonical is not None and load(mirror) != canonical:
            findings.append(Finding('blocker', rel(mirror), 'mirror differs from canonical manifest'))

    blockers = [f for f in findings if f.severity == 'blocker']
    warnings = [f for f in findings if f.severity == 'warning']
    now = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00', 'Z')
    lines = [
        '# Atlas Data Visualization Audit',
        '',
        f'Generated: `{now}`',
        '',
        '## Gate summary',
        '',
        f'- Chart types: **{len(chart_ids)}**',
        f'- Required chart types: **{len(REQUIRED_CHART_TYPES)}**',
        f'- Data-viz components: **{len(manifest_components)}**',
        f'- Required data-viz components: **{len(REQUIRED_COMPONENTS)}**',
        f'- Required tokens checked: **{len(REQUIRED_TOKENS)}**',
        f'- Blockers: **{len(blockers)}**',
        f'- Warnings: **{len(warnings)}**',
        '',
        '## Findings',
        '',
        '| Severity | Subject | Message |',
        '|---|---|---|',
    ]
    if findings:
        for f in findings:
            lines.append(f'| `{f.severity}` | `{f.subject}` | {f.message} |')
    else:
        lines.append('| — | — | No findings. |')

    lines.extend([
        '',
        '## Chart type coverage',
        '',
        '| Chart type | Primary component | Summary | Data table | Color-only |',
        '|---|---|---|---|---|',
    ])
    for item in manifest.get('chartTypes', []):
        lines.append(f"| `{item.get('id')}` | `{item.get('primaryComponent')}` | {item.get('textSummaryRequired')} | {item.get('dataTableRequired')} | {item.get('colorOnlyAllowed')} |")
    lines.append('')
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text('\n'.join(lines), encoding='utf-8')
    DIST_REPORT.parent.mkdir(parents=True, exist_ok=True)
    DIST_REPORT.write_text('\n'.join(lines), encoding='utf-8')
    print('\n'.join(lines))
    return 1 if blockers else 0


if __name__ == '__main__':
    raise SystemExit(main())
