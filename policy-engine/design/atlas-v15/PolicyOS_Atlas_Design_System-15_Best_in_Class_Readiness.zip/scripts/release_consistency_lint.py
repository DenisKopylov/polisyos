#!/usr/bin/env python3
"""Archive-level release metadata consistency lint for Atlas."""
from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / "dist" / "verification" / "release-consistency-report.md"

JSON_VERSION_PATHS = [
    ("root package", "package.json"),
    ("atlas ui package", "packages/atlas-ui/package.json"),
    ("atlas ui dist package", "packages/atlas-ui/dist/package.json"),
    ("component manifest", "component-library/component-manifest.json"),
    ("atlas ui component manifest", "packages/atlas-ui/component-manifest.json"),
    ("dist atlas ui component manifest", "dist/atlas-ui/component-manifest.json"),
    ("theme manifest", "theming/theme-manifest.json"),
    ("theme modes", "theming/theme-modes.json"),
    ("dist theme manifest", "dist/theming/theme-manifest.json"),
    ("dist theme modes", "dist/theming/theme-modes.json"),
]

README_RELEASE_RE = re.compile(r"## Current release\s+`([^`]+)`", re.MULTILINE)


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def get_version(data: dict) -> str | None:
    if isinstance(data.get("version"), str):
        return data["version"]
    ext = data.get("$extensions")
    if isinstance(ext, dict):
        atlas = ext.get("atlas")
        if isinstance(atlas, dict) and isinstance(atlas.get("version"), str):
            return atlas["version"]
    return None


def main() -> int:
    package = load_json(ROOT / "package.json")
    expected = package["version"]
    rows: list[tuple[str, bool, str]] = []

    for label, rel in JSON_VERSION_PATHS:
        path = ROOT / rel
        if not path.exists():
            rows.append((label, False, f"missing: {rel}"))
            continue
        version = get_version(load_json(path))
        rows.append((label, version == expected, version or "no version field"))

    readme = (ROOT / "README.md").read_text(encoding="utf-8", errors="ignore")
    match = README_RELEASE_RE.search(readme)
    rows.append(("root README current release", bool(match and match.group(1) == expected), match.group(1) if match else "not found"))

    summary = ROOT / "dist" / "verification" / "full-verify-summary.md"
    if summary.exists():
        text = summary.read_text(encoding="utf-8", errors="ignore")
        rows.append(("full verify summary current release wording", "v15" in text and "v14 full verification" not in text, "v15" if "v15" in text else "missing v15"))
    else:
        rows.append(("full verify summary current release wording", False, "missing"))

    for token_path in sorted((ROOT / "tokens" / "source").glob("*.tokens.json")):
        data = load_json(token_path)
        version = get_version(data)
        rows.append((f"token source {token_path.name}", version == expected, version or "no version field"))

    ok = all(row[1] for row in rows)
    now = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "# Atlas release consistency report",
        "",
        f"Generated: `{now}`",
        f"Expected release: `{expected}`",
        "",
        "| Check | Result | Observed |",
        "|---|---|---|",
    ]
    for label, passed, observed in rows:
        lines.append(f"| {label} | **{'PASS' if passed else 'FAIL'}** | `{observed}` |")
    lines.extend(["", f"Overall result: **{'PASS' if ok else 'FAIL'}**", ""])
    REPORT.write_text("\n".join(lines), encoding="utf-8")
    print("\n".join(lines))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
