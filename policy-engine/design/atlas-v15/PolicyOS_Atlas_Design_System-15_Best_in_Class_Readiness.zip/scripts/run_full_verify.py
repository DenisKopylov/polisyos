#!/usr/bin/env python3
"""Run the Atlas release gate chain with compact console output and full logs."""
from __future__ import annotations

import argparse
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LOG = ROOT / 'dist' / 'verification' / 'full-verify.log'

COMMANDS: list[tuple[str, list[str]]] = [
    ('tokens:build', ['python3', 'scripts/token_build.py']),
    ('tokens:schema', ['python3', 'scripts/token_schema_lint.py']),
    ('tokens:static', ['python3', 'scripts/token_static_lint.py']),
    ('tokens:aggregate', ['python3', 'scripts/token_lint.py']),
    ('dashboard:responsive:build', ['python3', 'scripts/dashboard_responsive_build.py']),
    ('dashboard:responsive:lint', ['python3', 'scripts/dashboard_responsive_lint.py']),
    ('data-viz:build', ['python3', 'scripts/data_viz_build.py']),
    ('theming:build', ['python3', 'scripts/theming_build.py']),
    ('states:build', ['python3', 'scripts/state_matrix_build.py']),
    ('components:build', ['python3', 'scripts/component_build.py']),
    ('data-viz:lint', ['python3', 'scripts/data_viz_lint.py']),
    ('theming:lint', ['python3', 'scripts/theming_lint.py']),
    ('components:lint', ['python3', 'scripts/component_lint.py']),
    ('states:lint', ['python3', 'scripts/state_matrix_lint.py']),
    ('a11y:contrast', ['python3', 'scripts/a11y_contrast_audit.py']),
    ('a11y:static', ['python3', 'scripts/a11y_static_lint.py']),
    ('verify:evidence', ['python3', 'scripts/verify.py']),
]


def tail(path: Path, lines: int = 80) -> str:
    if not path.exists():
        return ''
    return '\n'.join(path.read_text(encoding='utf-8', errors='ignore').splitlines()[-lines:])


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--verbose', action='store_true', help='stream command output to stdout')
    args = parser.parse_args()
    LOG.parent.mkdir(parents=True, exist_ok=True)
    now = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00', 'Z')
    lines = [f'# Atlas full verification log', f'Generated: {now}', '']
    LOG.write_text('\n'.join(lines), encoding='utf-8')
    for label, cmd in COMMANDS:
        if args.verbose:
            result = subprocess.run(cmd, cwd=ROOT)
            output = ''
        else:
            result = subprocess.run(cmd, cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True)
            output = result.stderr or ''
        status = 'PASS' if result.returncode == 0 else 'FAIL'
        with LOG.open('a', encoding='utf-8') as log:
            log.write(f'| {label} | {status} | {" ".join(cmd)} |\n')
            if output:
                log.write('\n```text\n' + output[-4000:] + '\n```\n')
        print(f'{label}: {status}', flush=True)
        if result.returncode != 0:
            print(tail(LOG), flush=True)
            print(f'Full log: {LOG.relative_to(ROOT)}', flush=True)
            return result.returncode
    print(f'Full verification: PASS ({len(COMMANDS)} gates)', flush=True)
    print(f'Full log: {LOG.relative_to(ROOT)}', flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
