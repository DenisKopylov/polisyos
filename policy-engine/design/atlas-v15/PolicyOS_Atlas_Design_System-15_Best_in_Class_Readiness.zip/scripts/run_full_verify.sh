#!/usr/bin/env bash
set -euo pipefail
LOG="dist/verification/full-verify.log"
mkdir -p "$(dirname "$LOG")"
printf '# Atlas full verification log\nGenerated: %s\n\nThis log stores the tail of each gate output. Full evidence is written to each gate report.\n\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "$LOG"
run_gate() {
  label="$1"
  shift
  tmp="$(mktemp)"
  printf '\n================================================================================\n$ %s\n# %s\n' "$*" "$label" >> "$LOG"
  if "$@" > "$tmp" 2>&1; then
    tail -n 120 "$tmp" >> "$LOG"
    printf '\n# exit=0\n' >> "$LOG"
    printf '%s: PASS\n' "$label"
    rm -f "$tmp"
    sleep 0.2
  else
    status="$?"
    cat "$tmp" >> "$LOG"
    printf '\n# exit=%s\n' "$status" >> "$LOG"
    cat "$tmp"
    rm -f "$tmp"
    return "$status"
  fi
}
run_gate tokens:build python3 scripts/token_build.py
run_gate tokens:schema python3 scripts/token_schema_lint.py
run_gate tokens:static python3 scripts/token_static_lint.py --quiet
run_gate tokens:aggregate python3 scripts/token_lint.py
run_gate data-viz:build python3 scripts/data_viz_build.py
run_gate theming:build python3 scripts/theming_build.py
run_gate dashboard:responsive:build python3 scripts/dashboard_responsive_build.py
run_gate states:build python3 scripts/state_matrix_build.py
run_gate components:build python3 scripts/component_build.py
run_gate data-viz:lint python3 scripts/data_viz_lint.py
run_gate theming:lint python3 scripts/theming_lint.py
run_gate dashboard:responsive:lint python3 scripts/dashboard_responsive_lint.py
run_gate components:lint python3 scripts/component_lint.py
run_gate states:lint python3 scripts/state_matrix_lint.py
run_gate a11y:contrast python3 scripts/a11y_contrast_audit.py
run_gate a11y:static python3 scripts/a11y_static_lint.py
run_gate verify:evidence python3 scripts/verify.py
printf 'Full verification: PASS (17 gates)\nFull log: %s\n' "$LOG"
