#!/usr/bin/env python3
"""Build generated Atlas component state-matrix artifacts from canonical v12 source."""
from __future__ import annotations
import json
from datetime import datetime, timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
CANONICAL=ROOT/'component-library/state-matrix/component-state-matrix.json'
TAXONOMY=ROOT/'component-library/state-matrix/state-taxonomy.json'
MANIFEST=ROOT/'component-library/component-manifest.json'
PKG=ROOT/'packages/atlas-ui'
DIST=ROOT/'dist/atlas-ui'

def load(p): return json.loads(p.read_text(encoding='utf-8'))
def save(p,d): p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def table(rows,headers):
    out=['| '+' | '.join(headers)+' |','|'+'|'.join(['---']*len(headers))+'|']
    for r in rows: out.append('| '+' | '.join(r)+' |')
    return '\n'.join(out)

def main():
    matrix=load(CANONICAL); taxonomy=load(TAXONOMY); manifest=load(MANIFEST)
    now=datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00','Z')
    matrix['generatedAt']=now; taxonomy['generatedAt']=now
    by_name=matrix['components']
    for item in manifest['components']:
        comp=by_name[item['name']]
        item['states']=[s['id'] for s in comp['supportedStates']]
        item['stateMatrix']=comp['stateMatrixDocs']
        item['stateMatrixId']=comp['id']
        item['stateContract']='component-library/state-matrix/component-state-matrix.json'
        item['stateCoverage']={'stateCount':len(comp['supportedStates']),'groups':sorted(set(s['kind'] for s in comp['supportedStates'])),'runtimeAttribute':'data-state'}
    save(MANIFEST,manifest); save(PKG/'component-manifest.json',manifest)
    save(CANONICAL,matrix); save(TAXONOMY,taxonomy); save(PKG/'state-matrix.json',matrix); save(PKG/'component-state-matrix.json',matrix); save(PKG/'state-taxonomy.json',taxonomy)
    save(DIST/'component-manifest.json',manifest); save(DIST/'state-matrix.json',matrix); save(DIST/'component-state-matrix.json',matrix); save(DIST/'state-taxonomy.json',taxonomy)
    rows=[]
    for name,comp in sorted(by_name.items()): rows.append([name,str(len(comp['supportedStates'])),str(sum(1 for s in comp['supportedStates'] if s['priority']=='P0')),str(len(comp['rejectedStates'])),comp['stateMatrixDocs']])
    (ROOT/'component-library/state-matrix-build.md').write_text('# Atlas state matrix build evidence\n\nGenerated: `'+now+'`\n\n'+table(rows,['Component','States','P0','Rejected','Docs'])+'\n',encoding='utf-8')
    names={name:[s['id'] for s in comp['supportedStates']] for name,comp in by_name.items()}
    (PKG/'src/state-contracts.ts').write_text("// Generated state contract names. Source: component-library/state-matrix/component-state-matrix.json\n"+f"export const atlasStateContractVersion = '{matrix['version']}';\n\nexport const atlasComponentStateNames = {json.dumps(names,indent=2,ensure_ascii=False)} as const;\n\nexport type AtlasStatefulComponentName = keyof typeof atlasComponentStateNames;\n",encoding='utf-8')
    print(f"Built state matrix for {len(by_name)} components and {sum(len(c['supportedStates']) for c in by_name.values())} states.")
    return 0
if __name__=='__main__': raise SystemExit(main())
