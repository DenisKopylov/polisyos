#!/usr/bin/env python3
"""Release gate for Atlas v15 component state matrices."""
from __future__ import annotations

import json
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
MATRIX = ROOT / 'component-library' / 'state-matrix' / 'component-state-matrix.json'
TAXONOMY = ROOT / 'component-library' / 'state-matrix' / 'state-taxonomy.json'
MANIFEST = ROOT / 'component-library' / 'component-manifest.json'
PKG_MATRIX = ROOT / 'packages' / 'atlas-ui' / 'state-matrix.json'
PKG_TAXONOMY = ROOT / 'packages' / 'atlas-ui' / 'state-taxonomy.json'
DIST_MATRIX = ROOT / 'dist' / 'atlas-ui' / 'state-matrix.json'
REPORT = ROOT / 'component-library' / 'state-matrix-audit.md'
DIST_REPORT = ROOT / 'dist' / 'atlas-ui' / 'state-matrix-audit.md'
REQUIRED_COMPONENTS = {'Button','Badge','Panel','Card','MetricCard','RunCard','TextField','TextArea','SelectField','Checkbox','Switch','Tabs','Dialog','Toast','EmptyState','Skeleton','DataTable','GovernanceGate','Form','FormSection','FieldGroup','ValidationSummary','RadioGroup','CheckboxGroup','SearchField','PasswordField','SecretField','NumberField','RangeField','DateField','DateRangeField','FileUpload','TokenInput','Combobox','CharacterCount','DashboardShell','DashboardTopBar','ResponsiveGrid','ScrollRegion','ChartFrame','ChartLegend','ChartTooltip','Sparkline','BarChart','LineChart','Heatmap','UncertaintyBand','ProvenanceGraph','ChartDataTable','CausalGraph','ProvenanceMap','ChartAnnotation','DataVizTable','ThemeProvider','ThemeToggle','AccessibilityModePanel'}
REQUIRED_STATE_FIELDS = {'id','label','kind','trigger','visual','semantics','tokens','keyboard','combinations','acceptance','priority','test'}
REQUIRED_COMPONENT_FIELDS = {'id','name','slug','version','source','docs','stateMatrixDocs','anatomy','supportedStates','rejectedStates','combinationRules','testCoverage','accessibilityNotes','modeCoverage'}

@dataclass
class Finding:
    severity: str
    subject: str
    message: str


def rel(path: Path) -> str:
    return str(path.relative_to(ROOT)).replace('\\', '/')


def load(path: Path) -> Any:
    return json.loads(path.read_text(encoding='utf-8'))


def check_state(component: str, state: dict[str, Any], findings: list[Finding]) -> None:
    missing = REQUIRED_STATE_FIELDS - set(state.keys())
    for field in sorted(missing):
        findings.append(Finding('blocker', component, f'state `{state.get("id", "unknown")}` missing `{field}`'))
    if state.get('priority') not in {'P0','P1','P2'}:
        findings.append(Finding('blocker', component, f'state `{state.get("id")}` has invalid priority `{state.get("priority")}`'))
    for field in ['trigger','visual','semantics','keyboard','test']:
        if not str(state.get(field, '')).strip():
            findings.append(Finding('blocker', component, f'state `{state.get("id")}` has empty `{field}`'))
    if not isinstance(state.get('acceptance'), list) or len(state.get('acceptance', [])) < 2:
        findings.append(Finding('blocker', component, f'state `{state.get("id")}` must have at least two acceptance criteria'))


def main() -> int:
    findings: list[Finding] = []
    for path in [MATRIX, TAXONOMY, MANIFEST, PKG_MATRIX, PKG_TAXONOMY]:
        if not path.exists():
            findings.append(Finding('blocker', rel(path), 'required artifact is missing'))
    if findings:
        components = {}
        taxonomy = {'requiredFieldsPerState': []}
        manifest = {'components': []}
    else:
        matrix = load(MATRIX)
        taxonomy = load(TAXONOMY)
        manifest = load(MANIFEST)
        package_matrix = load(PKG_MATRIX)
        package_taxonomy = load(PKG_TAXONOMY)
        if matrix != package_matrix:
            findings.append(Finding('blocker', rel(PKG_MATRIX), 'package state-matrix mirror differs from component-library source'))
        if taxonomy != package_taxonomy:
            findings.append(Finding('blocker', rel(PKG_TAXONOMY), 'package state-taxonomy mirror differs from component-library source'))
        components = matrix.get('components', {})

    component_names = set(components.keys())
    for name in sorted(REQUIRED_COMPONENTS - component_names):
        findings.append(Finding('blocker', name, 'required component missing from state matrix'))
    for name in sorted(component_names - REQUIRED_COMPONENTS):
        findings.append(Finding('warning', name, 'state matrix includes non-required component'))

    manifest_by_name = {item.get('name'): item for item in manifest.get('components', [])}
    for name in REQUIRED_COMPONENTS:
        if name not in manifest_by_name:
            findings.append(Finding('blocker', name, 'required component missing from manifest'))
            continue
        item = manifest_by_name[name]
        for field in ['stateMatrix','stateMatrixId','stateContract']:
            if field not in item:
                findings.append(Finding('blocker', name, f'manifest missing `{field}`'))

    total_states = 0
    total_rejected = 0
    total_backlog = 0
    for name, component in sorted(components.items()):
        missing = REQUIRED_COMPONENT_FIELDS - set(component.keys())
        for field in sorted(missing):
            findings.append(Finding('blocker', name, f'component matrix missing `{field}`'))
        states = component.get('supportedStates', [])
        rejected = component.get('rejectedStates', [])
        total_states += len(states)
        total_rejected += len(rejected)
        total_backlog += len([s for s in states if s.get('kind') == 'backlog'])
        if len(states) < 5:
            findings.append(Finding('blocker', name, 'must define at least five supported states'))
        if len([s for s in states if s.get('priority') == 'P0']) < 3:
            findings.append(Finding('blocker', name, 'must define at least three P0 states'))
        if not rejected:
            findings.append(Finding('blocker', name, 'must explicitly reject at least one non-applicable state'))
        ids = [s.get('id') for s in states]
        duplicates = {sid for sid in ids if ids.count(sid) > 1}
        for sid in sorted(duplicates):
            findings.append(Finding('blocker', name, f'duplicate state id `{sid}`'))
        for state in states:
            check_state(name, state, findings)
        for mode in ['high-contrast', 'density']:
            if mode not in component.get('modeCoverage', []) and not any(s.get('id') == mode for s in states):
                findings.append(Finding('blocker', name, f'missing `{mode}` mode coverage'))
        for path_field in ['source','docs','stateMatrixDocs']:
            path = ROOT / str(component.get(path_field, ''))
            if not path.exists():
                findings.append(Finding('blocker', name, f'{path_field} file missing: `{component.get(path_field)}`'))
        manifest_item = manifest_by_name.get(name, {})
        if manifest_item.get('stateMatrixId') != component.get('id'):
            findings.append(Finding('blocker', name, 'manifest stateMatrixId does not match component matrix id'))
        if manifest_item.get('stateMatrix') != component.get('stateMatrixDocs'):
            findings.append(Finding('blocker', name, 'manifest stateMatrix path does not match component matrix docs'))
        doc_path = ROOT / str(component.get('docs', ''))
        if doc_path.exists():
            doc_text = doc_path.read_text(encoding='utf-8', errors='ignore')
            if component.get('stateMatrixDocs') not in doc_text:
                findings.append(Finding('blocker', name, 'component docs do not link canonical state matrix docs'))
        state_doc = ROOT / str(component.get('stateMatrixDocs', ''))
        if state_doc.exists():
            state_doc_text = state_doc.read_text(encoding='utf-8', errors='ignore')
            for heading in ['## Supported states', '## Explicitly rejected states', '## Combination and precedence rules', '## Test coverage contract']:
                if heading not in state_doc_text:
                    findings.append(Finding('blocker', name, f'state docs missing `{heading}`'))

    for field in REQUIRED_STATE_FIELDS:
        if field not in set(taxonomy.get('requiredFieldsPerState', [])):
            findings.append(Finding('blocker', 'taxonomy', f'taxonomy requiredFieldsPerState missing `{field}`'))

    if DIST_MATRIX.exists():
        try:
            if load(DIST_MATRIX) != load(PKG_MATRIX):
                findings.append(Finding('blocker', rel(DIST_MATRIX), 'dist state-matrix does not match package source'))
        except Exception as exc:
            findings.append(Finding('blocker', rel(DIST_MATRIX), f'could not read dist state-matrix: {exc}'))
    else:
        findings.append(Finding('blocker', rel(DIST_MATRIX), 'dist state-matrix is missing; run scripts/component_build.py'))

    blockers = [f for f in findings if f.severity == 'blocker']
    warnings = [f for f in findings if f.severity == 'warning']
    now = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00','Z')
    lines = [
        '# Atlas State Matrix Audit', '',
        f'Generated: `{now}`', '',
        '## Gate summary', '',
        f'- Components in matrix: **{len(component_names)}**',
        f'- Required v15 components: **{len(REQUIRED_COMPONENTS)}**',
        f'- Supported states: **{total_states}**',
        f'- Explicitly rejected states: **{total_rejected}**',
        f'- Backlog states tracked: **{total_backlog}**',
        f'- Blockers: **{len(blockers)}**',
        f'- Warnings: **{len(warnings)}**', '',
        '## Findings', '',
        '| Severity | Subject | Message |', '|---|---|---|'
    ]
    if findings:
        for finding in findings:
            lines.append(f'| `{finding.severity}` | `{finding.subject}` | {finding.message} |')
    else:
        lines.append('| — | — | No findings. |')
    lines.extend(['', '## Component coverage', '', '| Component | Supported states | P0 | Rejected | Backlog |', '|---|---:|---:|---:|---:|'])
    for name, component in sorted(components.items()):
        states = component.get('supportedStates', [])
        lines.append(f'| {name} | {len(states)} | {len([s for s in states if s.get("priority") == "P0"])} | {len(component.get("rejectedStates", []))} | {len([s for s in states if s.get("kind") == "backlog"])} |')
    lines.append('')
    REPORT.write_text('\n'.join(lines), encoding='utf-8')
    DIST_REPORT.parent.mkdir(parents=True, exist_ok=True)
    DIST_REPORT.write_text('\n'.join(lines), encoding='utf-8')
    print('\n'.join(lines))
    return 1 if blockers else 0

if __name__ == '__main__':
    raise SystemExit(main())
