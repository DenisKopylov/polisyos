#!/usr/bin/env python3
"""Release gate for Atlas theming and accessibility modes."""
from __future__ import annotations
import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / 'theming' / 'theme-manifest.json'
MODES = ROOT / 'theming' / 'theme-modes.json'
CSS = ROOT / 'tokens' / 'generated' / 'atlas.tokens.css'
PKG = ROOT / 'packages' / 'atlas-ui'
DIST_THEME = ROOT / 'dist' / 'theming'
DIST_UI = ROOT / 'dist' / 'atlas-ui'
REPORT = ROOT / 'theming' / 'audit-results.md'
DIST_REPORT = ROOT / 'dist' / 'theming' / 'audit-results.md'
REQUIRED_MODES = {'light','dark','auto-dark','high-contrast','prefers-contrast','forced-colors','reduced-motion','prefers-reduced-motion','reduced-transparency','prefers-reduced-transparency','large-text','color-safe','comfortable-density','compact-density','condensed-density','print'}
REQUIRED_COMPONENTS = {'ThemeProvider','ThemeToggle','AccessibilityModePanel'}
REQUIRED_DOCS = ['README.md','mode-resolution.md','accessibility-modes.md','contrast-and-forced-colors.md','motion-transparency.md','color-safe-and-large-text.md','implementation-contract.md','testing-contract.md','migration-checklist.md']
REQUIRED_TOKENS = ['--atlas-theme-transition-duration','--atlas-theme-mode-surface','--atlas-theme-mode-border','--atlas-theme-toggle-surface','--atlas-theme-toggle-indicator','--atlas-text-scale-root','--atlas-color-safe-status-success-shape','--motion-reduced-duration','--atlas-viz-series-1']
REQUIRED_MEDIA = ['@media (forced-colors: active)','@media (prefers-reduced-motion: reduce)','@media (prefers-reduced-transparency: reduce)','@media (prefers-color-scheme: dark)','@media print']
@dataclass
class Finding:
    severity: str
    subject: str
    message: str

def rel(p: Path) -> str:
    return str(p.relative_to(ROOT)).replace('\\','/')
def load(p): return json.loads(p.read_text(encoding='utf-8'))

def main() -> int:
    findings: list[Finding] = []
    for doc in REQUIRED_DOCS:
        if not (ROOT / 'theming' / doc).exists():
            findings.append(Finding('blocker', doc, 'required theming documentation missing'))
    if not MANIFEST.exists():
        findings.append(Finding('blocker', rel(MANIFEST), 'theme manifest missing'))
        manifest = {'modes': [], 'requiredTokens': [], 'requiredComponents': [], 'attributes': {}}
    else:
        manifest = load(MANIFEST)
    if not MODES.exists():
        findings.append(Finding('blocker', rel(MODES), 'theme modes mirror missing'))
        modes = {'modes': []}
    else:
        modes = load(MODES)
    mode_ids = {item.get('id') for item in manifest.get('modes', [])}
    for mid in sorted(REQUIRED_MODES - mode_ids):
        findings.append(Finding('blocker', mid, 'required mode missing from manifest'))
    for item in manifest.get('modes', []):
        subject = item.get('id', 'unknown')
        for field in ['id','axis','selector','userControl','tokens']:
            if field not in item:
                findings.append(Finding('blocker', subject, f'mode missing {field}'))
        token_path = item.get('tokens')
        if token_path and token_path != 'source defaults' and not (ROOT / token_path).exists():
            findings.append(Finding('blocker', subject, f'token file missing: {token_path}'))
    for axis in ['color-scheme','contrast','motion','transparency','text-scale','color-vision','density','output']:
        if not any(item.get('axis') == axis for item in manifest.get('modes', [])):
            findings.append(Finding('blocker', axis, 'mode axis has no coverage'))
    for attr in ['theme','contrast','motion','transparency','density','textScale','colorSafe']:
        if attr not in manifest.get('attributes', {}):
            findings.append(Finding('blocker', attr, 'required runtime attribute missing'))
    for comp in REQUIRED_COMPONENTS:
        if comp not in set(manifest.get('requiredComponents', [])):
            findings.append(Finding('blocker', comp, 'required theming component missing from manifest'))
    css = CSS.read_text(encoding='utf-8', errors='ignore') if CSS.exists() else ''
    ui_css = (PKG / 'src' / 'atlas-ui.css').read_text(encoding='utf-8', errors='ignore') if (PKG / 'src' / 'atlas-ui.css').exists() else ''
    for token in REQUIRED_TOKENS:
        if token not in css:
            findings.append(Finding('blocker', token, 'required generated token missing'))
    for media in REQUIRED_MEDIA:
        if media not in css and media not in ui_css:
            findings.append(Finding('blocker', media, 'required media mode CSS missing'))
    component_manifest = load(ROOT / 'component-library' / 'component-manifest.json') if (ROOT / 'component-library' / 'component-manifest.json').exists() else {'components': []}
    by_name = {item.get('name'): item for item in component_manifest.get('components', [])}
    for comp in REQUIRED_COMPONENTS:
        item = by_name.get(comp)
        if not item:
            findings.append(Finding('blocker', comp, 'theming component missing from component manifest'))
            continue
        if item.get('themingContract') != 'theming/theme-manifest.json':
            findings.append(Finding('blocker', comp, 'component manifest missing themingContract link'))
        for path_field in ['source','docs','story','stateMatrix']:
            if not (ROOT / str(item.get(path_field, ''))).exists():
                findings.append(Finding('blocker', comp, f'{path_field} missing: {item.get(path_field)}'))
    canonical = manifest
    for mirror in [PKG / 'theme-manifest.json', DIST_THEME / 'theme-manifest.json', DIST_UI / 'theme-manifest.json']:
        if not mirror.exists():
            findings.append(Finding('blocker', rel(mirror), 'theme manifest mirror missing; run scripts/theming_build.py'))
        elif load(mirror) != canonical:
            findings.append(Finding('blocker', rel(mirror), 'theme manifest mirror differs from canonical'))
    for mirror in [PKG / 'theme-modes.json', DIST_THEME / 'theme-modes.json', DIST_UI / 'theme-modes.json']:
        if not mirror.exists():
            findings.append(Finding('blocker', rel(mirror), 'theme modes mirror missing; run scripts/theming_build.py'))
    pkg_json = json.loads((PKG / 'package.json').read_text(encoding='utf-8'))
    for export in ['./theming','./theme-manifest','./theme-modes','./theme-contracts']:
        if export not in pkg_json.get('exports', {}):
            findings.append(Finding('blocker', export, 'package export missing'))
    blockers = [f for f in findings if f.severity == 'blocker']
    warnings = [f for f in findings if f.severity == 'warning']
    now = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00','Z')
    lines = ['# Atlas Theming Accessibility Modes Audit','',f'Generated: `{now}`','', '## Gate summary','', f'- Modes: **{len(mode_ids)}**', f'- Required modes: **{len(REQUIRED_MODES)}**', f'- Runtime attributes: **{len(manifest.get("attributes", {}))}**', f'- Required theming components: **{len(REQUIRED_COMPONENTS)}**', f'- Required tokens checked: **{len(REQUIRED_TOKENS)}**', f'- Blockers: **{len(blockers)}**', f'- Warnings: **{len(warnings)}**', '', '## Findings','', '| Severity | Subject | Message |','|---|---|---|']
    if findings:
        for f in findings:
            lines.append(f'| `{f.severity}` | `{f.subject}` | {f.message} |')
    else:
        lines.append('| — | — | No findings. |')
    lines.extend(['', '## Mode coverage', '', '| Mode | Axis | Media | Tokens |','|---|---|---|---|'])
    for item in manifest.get('modes', []):
        lines.append(f"| `{item.get('id')}` | `{item.get('axis')}` | `{item.get('media') or 'manual'}` | `{item.get('tokens')}` |")
    lines.append('')
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text('\n'.join(lines), encoding='utf-8')
    DIST_REPORT.parent.mkdir(parents=True, exist_ok=True)
    DIST_REPORT.write_text('\n'.join(lines), encoding='utf-8')
    print('\n'.join(lines))
    return 1 if blockers else 0
if __name__ == '__main__':
    raise SystemExit(main())
