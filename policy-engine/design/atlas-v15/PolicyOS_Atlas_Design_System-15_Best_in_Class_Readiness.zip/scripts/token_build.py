#!/usr/bin/env python3
"""Build Atlas design-token outputs.

Source of truth:
  tokens/source/*.tokens.json
  tokens/modes/*.tokens.json

Generated outputs:
  tokens/generated/atlas.tokens.css
  tokens/generated/atlas.tokens.ts
  tokens/generated/atlas.tailwind.cjs
  tokens/generated/atlas.figma.tokens.json
  tokens/generated/token-manifest.json
  tokens/generated/token-audit.md
  dist/tokens/* mirror for consumers
  colors_and_type.css and landing/colors_and_type.css token blocks
"""
from __future__ import annotations

import datetime as dt
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

ROOT = Path(__file__).resolve().parents[1]
SRC_DIR = ROOT / 'tokens' / 'source'
MODE_DIR = ROOT / 'tokens' / 'modes'
GEN_DIR = ROOT / 'tokens' / 'generated'
DIST_DIR = ROOT / 'dist' / 'tokens'
ALIAS_RE = re.compile(r'\{([^{}]+)\}')

SOURCE_ORDER = ['primitive.tokens.json', 'semantic.tokens.json', 'component.tokens.json']

HEADER = '''/**
 * PolicyOS Atlas Design System
 * colors_and_type.css
 *
 * Generated token region is built from tokens/source/*.tokens.json and
 * tokens/modes/*.tokens.json. Do not hand-edit CSS custom properties here;
 * change source tokens and run scripts/token_build.py.
 *
 * Usage:
 *   <link rel="stylesheet" href="colors_and_type.css">
 *   @import url('./colors_and_type.css');
 */

@import url('https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=IBM+Plex+Mono:wght@400;500;600&family=Instrument+Serif:ital@1&display=swap');
'''

UTILITY_AND_TYPE_CSS = r'''

/* ─────────────────────────────────────────────────────
   MOTION AND ACCESSIBILITY UTILITIES
   ───────────────────────────────────────────────────── */
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: var(--motion-reduced-duration) !important;
    transition-duration: var(--motion-reduced-duration) !important;
  }
}

.sr-only {
  position: absolute !important;
  width: 1px !important;
  height: 1px !important;
  padding: 0 !important;
  margin: -1px !important;
  overflow: hidden !important;
  clip: rect(0, 0, 0, 0) !important;
  white-space: nowrap !important;
  border: 0 !important;
}

.skip-link {
  position: fixed;
  top: 12px;
  left: 12px;
  z-index: 10000;
  transform: translateY(-150%);
  padding: 10px 14px;
  border-radius: var(--radius-sm);
  background: var(--ink);
  color: var(--paper);
  font-weight: 800;
  text-decoration: none;
  box-shadow: var(--shadow-md);
}
.skip-link:focus,
.skip-link:focus-visible { transform: translateY(0); }

:where(a, button, input, select, textarea, summary, [tabindex]:not([tabindex="-1"])):focus { outline: none; }
:where(a, button, input, select, textarea, summary, [tabindex]:not([tabindex="-1"])):focus-visible {
  outline: var(--focus-outline-width) solid var(--focus-ring);
  outline-offset: var(--focus-outline-offset);
  box-shadow: 0 0 0 calc(var(--focus-outline-width) + 2px) var(--focus-ring-outer);
}

:where(button, [role="button"], a, input, select, textarea) {
  -webkit-tap-highlight-color: transparent;
}
:where(button, [role="button"], a[href]) { touch-action: manipulation; }

.atlas-click-target {
  appearance: none;
  -webkit-appearance: none;
  border: 0;
  width: 100%;
  min-height: var(--target-min);
  text-align: left;
  font: inherit;
  color: inherit;
}

.atlas-click-target[aria-pressed="true"] { cursor: default; }
.atlas-click-target:disabled,
.atlas-click-target[aria-disabled="true"] {
  cursor: not-allowed;
  opacity: 0.58;
}

@media (forced-colors: active) {
  * { forced-color-adjust: auto; }
  :where(a, button, input, select, textarea, summary, [tabindex]:not([tabindex="-1"])):focus-visible {
    outline: 3px solid Highlight;
    outline-offset: 3px;
    box-shadow: none;
  }
  .skip-link {
    background: ButtonFace;
    color: ButtonText;
    border: 1px solid ButtonText;
  }
}

/* ─────────────────────────────────────────────────────
   SEMANTIC TYPOGRAPHY CLASSES
   ───────────────────────────────────────────────────── */
body {
  font-family: var(--font-sans);
  font-size: var(--text-base);
  line-height: var(--leading-normal);
  color: var(--ink);
}

.t-display {
  font-family: var(--font-sans);
  font-size: var(--text-display);
  font-weight: 800;
  line-height: var(--leading-none);
  letter-spacing: var(--tracking-tight);
}

.t-h1 {
  font-family: var(--font-sans);
  font-size: var(--text-4xl);
  font-weight: 800;
  line-height: var(--leading-tight);
  letter-spacing: var(--tracking-tight);
}

.t-h2 {
  font-family: var(--font-sans);
  font-size: var(--text-3xl);
  font-weight: 800;
  line-height: var(--leading-tight);
  letter-spacing: var(--tracking-tight);
}

.t-h3 {
  font-family: var(--font-sans);
  font-size: var(--text-2xl);
  font-weight: 700;
  line-height: var(--leading-snug);
  letter-spacing: var(--tracking-snug);
}

.t-h4 {
  font-family: var(--font-sans);
  font-size: var(--text-xl);
  font-weight: 700;
  line-height: var(--leading-snug);
}

.t-body {
  font-family: var(--font-sans);
  font-size: var(--text-base);
  font-weight: 400;
  line-height: var(--leading-normal);
}

.t-small {
  font-family: var(--font-sans);
  font-size: var(--text-sm);
  line-height: var(--leading-normal);
  color: var(--slate);
}

.t-eyebrow {
  font-family: var(--font-mono);
  font-size: var(--text-xs);
  font-weight: 600;
  letter-spacing: var(--tracking-widest);
  text-transform: uppercase;
  color: var(--slate);
}

.t-mono {
  font-family: var(--font-mono);
  font-size: var(--text-xs);
  letter-spacing: var(--tracking-wider);
  color: var(--slate);
}

.t-metric {
  font-family: var(--font-sans);
  font-size: var(--text-4xl);
  font-weight: 800;
  letter-spacing: var(--tracking-tight);
  line-height: var(--leading-none);
}

.t-metric-md {
  font-family: var(--font-sans);
  font-size: var(--text-2xl);
  font-weight: 700;
  letter-spacing: var(--tracking-snug);
}

.t-prose {
  font-family: var(--font-sans);
  font-size: 17px;
  line-height: 1.65;
  max-width: 68ch;
  color: var(--ink);
}

.t-citation {
  font-family: var(--font-serif);
  font-style: italic;
  font-size: var(--text-lg);
  line-height: 1.7;
  color: color-mix(in srgb, var(--ink) 85%, transparent);
  border-left: 2px solid var(--gold-vibrant);
  padding-left: 1.5ch;
}
'''

@dataclass(frozen=True)
class Token:
    path: str
    value: Any
    typ: str
    css_var: str | None
    description: str | None
    source: str
    selector: str = ':root'
    media: str | None = None


def load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding='utf-8'))


def walk_tokens(obj: Dict[str, Any], source: str, path: Tuple[str, ...] = (), selector=':root', media=None) -> Iterable[Token]:
    if isinstance(obj, dict) and '$value' in obj:
        ext = obj.get('$extensions', {}).get('atlas', {}) if isinstance(obj.get('$extensions'), dict) else {}
        yield Token(
            path='.'.join(path),
            value=obj.get('$value'),
            typ=obj.get('$type', 'unknown'),
            css_var=ext.get('cssVar'),
            description=obj.get('$description'),
            source=source,
            selector=selector,
            media=media,
        )
        return
    for key, value in obj.items():
        if key.startswith('$'):
            continue
        if isinstance(value, dict):
            yield from walk_tokens(value, source, (*path, key), selector, media)


def load_source_tokens() -> List[Token]:
    tokens: List[Token] = []
    paths = [SRC_DIR / name for name in SOURCE_ORDER]
    paths += sorted(p for p in SRC_DIR.glob('*.tokens.json') if p.name not in SOURCE_ORDER)
    for p in paths:
        if not p.exists():
            continue
        tokens.extend(walk_tokens(load_json(p), str(p.relative_to(ROOT))))
    return tokens


def load_mode_tokens() -> List[Token]:
    tokens: List[Token] = []
    for p in sorted(MODE_DIR.glob('*.tokens.json')):
        doc = load_json(p)
        atlas = doc.get('$extensions', {}).get('atlas', {})
        selector = atlas.get('selector', ':root')
        media = atlas.get('media')
        tokens.extend(walk_tokens(doc, str(p.relative_to(ROOT)), selector=selector, media=media))
    return tokens


def token_maps(tokens: List[Token]) -> Tuple[Dict[str, Token], Dict[str, Token]]:
    by_path: Dict[str, Token] = {}
    by_css: Dict[str, Token] = {}
    for token in tokens:
        by_path[token.path] = token
        if token.css_var:
            by_css[token.css_var] = token
    return by_path, by_css


def resolve_raw(value: Any, by_path: Dict[str, Token], seen: Tuple[str, ...] = ()) -> Any:
    if not isinstance(value, str):
        return value

    def repl(match: re.Match[str]) -> str:
        ref = match.group(1)
        if ref in seen:
            raise ValueError(f'Circular token reference: {" -> ".join((*seen, ref))}')
        if ref not in by_path:
            raise KeyError(f'Unresolved token reference: {ref}')
        ref_token = by_path[ref]
        return str(resolve_raw(ref_token.value, by_path, (*seen, ref)))

    return ALIAS_RE.sub(repl, value)


def css_value(value: Any, by_path: Dict[str, Token]) -> str:
    if not isinstance(value, str):
        return str(value)

    def repl(match: re.Match[str]) -> str:
        ref = match.group(1)
        token = by_path.get(ref)
        if token is None:
            raise KeyError(f'Unresolved token reference: {ref}')
        if token.css_var:
            return f'var(--{token.css_var})'
        return str(resolve_raw(token.value, by_path, (ref,)))

    return ALIAS_RE.sub(repl, value)


def declarations(tokens: List[Token], by_path: Dict[str, Token]) -> List[Tuple[str, str, Token]]:
    out = []
    seen: set[Tuple[str | None, str, str]] = set()
    for token in tokens:
        if not token.css_var:
            continue
        key = (token.media, token.selector, token.css_var)
        if key in seen:
            # Same selector+var duplicate is almost always an authoring bug.
            raise ValueError(f'Duplicate CSS variable --{token.css_var} in {token.selector} ({token.source})')
        seen.add(key)
        out.append((token.css_var, css_value(token.value, by_path), token))
    return out


def block(selector: str, decls: List[Tuple[str, str, Token]]) -> str:
    lines = [f'{selector} {{']
    for name, value, token in decls:
        lines.append(f'  --{name}: {value};')
    lines.append('}')
    return '\n'.join(lines)


def css(tokens: List[Token], by_path: Dict[str, Token]) -> str:
    root_decls = declarations([t for t in tokens if t.media is None and t.selector == ':root'], by_path)
    mode_tokens = [t for t in tokens if not (t.media is None and t.selector == ':root')]

    lines = [
        '/* ─────────────────────────────────────────────────────',
        '   GENERATED DESIGN TOKENS',
        '   Source: tokens/source/*.tokens.json + tokens/modes/*.tokens.json',
        '   Regenerate: python3 scripts/token_build.py',
        '   ───────────────────────────────────────────────────── */',
        block(':root', root_decls),
    ]

    # Group modes by media+selector in source order.
    groups: Dict[Tuple[str | None, str], List[Tuple[str, str, Token]]] = {}
    for item in declarations(mode_tokens, by_path):
        _, _, token = item
        groups.setdefault((token.media, token.selector), []).append(item)
    for (media, selector), decls in groups.items():
        rendered = block(selector, decls)
        if media:
            lines.append(f'@media {media} {{\n' + indent(rendered, 2) + '\n}')
        else:
            lines.append(rendered)
    return '\n\n'.join(lines) + '\n'


def indent(text: str, spaces: int) -> str:
    prefix = ' ' * spaces
    return '\n'.join(prefix + line if line else line for line in text.splitlines())


def js_string(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False)


def write_ts(root_tokens: List[Token], mode_tokens: List[Token], by_path: Dict[str, Token]) -> str:
    css_vars = {t.css_var: {'path': t.path, 'type': t.typ, 'value': css_value(t.value, by_path), 'source': t.source} for t in root_tokens if t.css_var}
    resolved = {t.css_var: {'path': t.path, 'type': t.typ, 'value': resolve_raw(t.value, by_path), 'source': t.source} for t in root_tokens if t.css_var}
    modes = {}
    for token in mode_tokens:
        if not token.css_var:
            continue
        modes.setdefault(token.source, {'selector': token.selector, 'media': token.media, 'tokens': {}})
        modes[token.source]['tokens'][token.css_var] = css_value(token.value, by_path)
    return f'''/* Auto-generated by scripts/token_build.py. Do not edit. */
export const atlasCssVars = {js_string(css_vars)} as const;

export const atlasResolvedTokens = {js_string(resolved)} as const;

export const atlasModes = {js_string(modes)} as const;

export type AtlasTokenName = keyof typeof atlasCssVars;
export type AtlasCssVar = `--${{AtlasTokenName}}`;

export function token(name: AtlasTokenName): `var(--${{AtlasTokenName}})` {{
  return `var(--${{name}})` as `var(--${{AtlasTokenName}})`;
}}
'''


def write_tailwind(root_tokens: List[Token]) -> str:
    groups = {
        'colors': ['color'],
        'spacing': ['dimension'],
        'borderRadius': ['dimension'],
        'boxShadow': ['shadow'],
        'fontFamily': ['fontFamily'],
        'fontSize': ['dimension'],
        'transitionDuration': ['duration'],
    }
    # Curated Tailwind mapping to avoid shoving every dimension into spacing.
    colors = {t.css_var: f'var(--{t.css_var})' for t in root_tokens if t.css_var and t.typ == 'color'}
    spacing = {t.css_var.replace('space-', ''): f'var(--{t.css_var})' for t in root_tokens if t.css_var and t.css_var.startswith('space-')}
    radius = {t.css_var.replace('radius-', ''): f'var(--{t.css_var})' for t in root_tokens if t.css_var and t.css_var.startswith('radius-')}
    shadows = {t.css_var.replace('shadow-', ''): f'var(--{t.css_var})' for t in root_tokens if t.css_var and t.css_var.startswith('shadow-')}
    font = {t.css_var.replace('font-', ''): [f'var(--{t.css_var})'] for t in root_tokens if t.css_var and t.css_var.startswith('font-')}
    font_size = {t.css_var.replace('text-', ''): f'var(--{t.css_var})' for t in root_tokens if t.css_var and t.css_var.startswith('text-')}
    durations = {t.css_var.replace('motion-', ''): f'var(--{t.css_var})' for t in root_tokens if t.css_var and t.css_var.startswith('motion-')}
    data = {
        'theme': {'extend': {
            'colors': colors,
            'spacing': spacing,
            'borderRadius': radius,
            'boxShadow': shadows,
            'fontFamily': font,
            'fontSize': font_size,
            'transitionDuration': durations,
        }}
    }
    return '/* Auto-generated by scripts/token_build.py. Do not edit. */\nmodule.exports = ' + json.dumps(data, indent=2, ensure_ascii=False) + ';\n'


def write_figma(root_tokens: List[Token], mode_tokens: List[Token], by_path: Dict[str, Token]) -> Dict[str, Any]:
    # DTCG-preserving handoff with resolved values and mode metadata for Figma Variables/Tokens Studio import.
    figma: Dict[str, Any] = {
        '$schema': 'https://www.designtokens.org/tr/2025.10/format/',
        '$description': 'Generated Atlas token handoff for Figma Variables/Tokens Studio import.',
        '$extensions': {'atlas': {'generatedBy': 'scripts/token_build.py', 'format': 'dtcg-resolved'}}
    }
    for token in root_tokens:
        if not token.css_var:
            continue
        cursor = figma
        for part in token.path.split('.'):
            cursor = cursor.setdefault(part, {})
        cursor.update({'$type': token.typ, '$value': resolve_raw(token.value, by_path), '$extensions': {'atlas': {'cssVar': token.css_var, 'source': token.source}}})
    modes: Dict[str, Any] = {}
    for token in mode_tokens:
        if not token.css_var:
            continue
        key = token.source.replace('tokens/modes/', '').replace('.tokens.json', '')
        modes.setdefault(key, {'$extensions': {'atlas': {'selector': token.selector, 'media': token.media}}, 'tokens': {}})
        modes[key]['tokens'][token.css_var] = {'$type': token.typ, '$value': resolve_raw(token.value, by_path)}
    figma['$extensions']['atlas']['modes'] = modes
    return figma


def write_manifest(root_tokens: List[Token], mode_tokens: List[Token], by_path: Dict[str, Token]) -> Dict[str, Any]:
    aliases = []
    for token in root_tokens + mode_tokens:
        if isinstance(token.value, str):
            for ref in ALIAS_RE.findall(token.value):
                aliases.append({'from': token.path, 'to': ref, 'source': token.source})
    css_var_count = len([t for t in root_tokens if t.css_var])
    mode_var_count = len([t for t in mode_tokens if t.css_var])
    return {
        'generatedAt': dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat().replace('+00:00','Z'),
        'sourceFiles': [str(p.relative_to(ROOT)) for p in sorted(SRC_DIR.glob('*.tokens.json')) + sorted(MODE_DIR.glob('*.tokens.json'))],
        'rootTokenCount': len(root_tokens),
        'rootCssVarCount': css_var_count,
        'modeTokenCount': len(mode_tokens),
        'modeCssVarCount': mode_var_count,
        'aliasCount': len(aliases),
        'aliases': aliases,
        'generatedFiles': [
            'tokens/generated/atlas.tokens.css',
            'tokens/generated/atlas.tokens.ts',
            'tokens/generated/atlas.tailwind.cjs',
            'tokens/generated/atlas.figma.tokens.json',
            'tokens/generated/token-manifest.json',
            'tokens/generated/token-audit.md',
            'tokens/generated/token-schema-lint.md',
            'tokens/generated/token-static-lint.md',
            'tokens/generated/token-lint-results.md',
            'colors_and_type.css',
            'landing/colors_and_type.css',
            'dist/tokens/*'
        ]
    }


def write_audit(manifest: Dict[str, Any], root_tokens: List[Token], mode_tokens: List[Token]) -> str:
    layers: Dict[str, int] = {}
    for t in root_tokens:
        layer = t.path.split('.')[0]
        layers[layer] = layers.get(layer, 0) + 1
    mode_sources: Dict[str, int] = {}
    for t in mode_tokens:
        mode_sources[t.source] = mode_sources.get(t.source, 0) + 1
    lines = [
        '# Atlas token pipeline audit',
        '',
        f'Generated: `{manifest["generatedAt"]}`',
        '',
        '## Summary',
        '',
        f'- Root tokens: **{manifest["rootTokenCount"]}**',
        f'- Exported root CSS variables: **{manifest["rootCssVarCount"]}**',
        f'- Mode override tokens: **{manifest["modeTokenCount"]}**',
        f'- Exported mode CSS variables: **{manifest["modeCssVarCount"]}**',
        f'- Alias references: **{manifest["aliasCount"]}**',
        '',
        '## Layers',
        '',
    ]
    for layer, count in sorted(layers.items()):
        lines.append(f'- `{layer}`: {count}')
    lines.extend(['', '## Modes', ''])
    for source, count in sorted(mode_sources.items()):
        lines.append(f'- `{source}`: {count}')
    lines.extend(['', '## Contract', '', '- Primitive tokens are the brand/raw design decisions.', '- Semantic tokens are the default product API.', '- Component tokens bind stable components to semantic tokens.', '- Mode files override exported CSS variables only through `tokens/modes/*.tokens.json`.', '- Generated files should not be hand-edited.'])
    return '\n'.join(lines) + '\n'


def main() -> None:
    GEN_DIR.mkdir(parents=True, exist_ok=True)
    DIST_DIR.mkdir(parents=True, exist_ok=True)

    root_tokens = load_source_tokens()
    mode_tokens = load_mode_tokens()
    by_path, _ = token_maps(root_tokens)

    # Validate aliases before writing.
    for token in root_tokens + mode_tokens:
        if isinstance(token.value, str):
            for ref in ALIAS_RE.findall(token.value):
                if ref not in by_path:
                    raise KeyError(f'{token.path} references missing token {ref}')
            resolve_raw(token.value, by_path, (token.path,))

    css_text = css(root_tokens + mode_tokens, by_path)
    (GEN_DIR / 'atlas.tokens.css').write_text(css_text, encoding='utf-8')
    (GEN_DIR / 'atlas.tokens.ts').write_text(write_ts(root_tokens, mode_tokens, by_path), encoding='utf-8')
    (GEN_DIR / 'atlas.tailwind.cjs').write_text(write_tailwind(root_tokens), encoding='utf-8')
    (GEN_DIR / 'atlas.figma.tokens.json').write_text(json.dumps(write_figma(root_tokens, mode_tokens, by_path), indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    manifest = write_manifest(root_tokens, mode_tokens, by_path)
    (GEN_DIR / 'token-manifest.json').write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    (GEN_DIR / 'token-audit.md').write_text(write_audit(manifest, root_tokens, mode_tokens), encoding='utf-8')

    # Consumer dist mirror.
    for p in GEN_DIR.iterdir():
        if p.is_file():
            (DIST_DIR / p.name).write_text(p.read_text(encoding='utf-8'), encoding='utf-8')

    full_css = HEADER + '\n' + css_text + UTILITY_AND_TYPE_CSS
    (ROOT / 'colors_and_type.css').write_text(full_css, encoding='utf-8')
    (ROOT / 'landing' / 'colors_and_type.css').write_text(full_css, encoding='utf-8')

    print(f'Generated {manifest["rootCssVarCount"]} root vars and {manifest["modeCssVarCount"]} mode vars.')


if __name__ == '__main__':
    main()
