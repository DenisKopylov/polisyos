#!/usr/bin/env python3
"""Aggregate Atlas token gate evidence.

Run `token_schema_lint.py` and `token_static_lint.py` before this script. Keeping the
heavy static scan outside the aggregator avoids duplicate high-memory scans in
sandboxed CI while preserving a single human-readable token-lint report.
"""
from __future__ import annotations
import datetime as dt
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
GEN = ROOT / 'tokens' / 'generated'
DIST = ROOT / 'dist' / 'tokens'

SCHEMA = GEN / 'token-schema-lint.md'
STATIC = GEN / 'token-static-lint.md'


def read(path: Path) -> str:
    return path.read_text(encoding='utf-8', errors='ignore') if path.exists() else ''


def status_from_report(text: str, kind: str) -> tuple[bool, str]:
    if not text:
        return False, 'missing report'
    if kind == 'schema':
        return ('Blockers: **0**' in text or 'Blockers: **0**' in text), 'report present'
    if kind == 'static':
        core_ok = 'Core design-system files: **0** findings' in text
        total = re.search(r'Total findings: \*\*(\d+)\*\*', text)
        baseline = re.search(r'Baseline total: \*\*(\d+)\*\*', text)
        total_ok = True
        if total and baseline:
            total_ok = int(total.group(1)) <= int(baseline.group(1))
        return core_ok and total_ok, 'report present'
    return False, 'unknown check'


def main() -> int:
    schema_text = read(SCHEMA)
    static_text = read(STATIC)
    schema_ok, schema_note = status_from_report(schema_text, 'schema')
    static_ok, static_note = status_from_report(static_text, 'static')
    checks = [('schema', schema_ok, schema_note, schema_text), ('static-drift', static_ok, static_note, static_text)]
    now = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat().replace('+00:00','Z')
    lines = ['# Atlas token lint results', '', f'Generated: `{now}`', '', '## Gate summary', '']
    for name, ok, note, _ in checks:
        lines.append(f'- `{name}`: **{"PASS" if ok else "FAIL"}** ({note})')
    lines += ['', '## Check output', '']
    for name, ok, note, out in checks:
        lines += [f'### {name}', '', f'Status: `{"PASS" if ok else "FAIL"}`', '', '```text', out.strip() or note, '```', '']
    text = '\n'.join(lines)
    GEN.mkdir(parents=True, exist_ok=True)
    DIST.mkdir(parents=True, exist_ok=True)
    (GEN / 'token-lint-results.md').write_text(text + '\n', encoding='utf-8')
    (DIST / 'token-lint-results.md').write_text(text + '\n', encoding='utf-8')
    print('# Atlas token lint results')
    for name, ok, note, _ in checks:
        print(f'- {name}: {"PASS" if ok else "FAIL"} ({note})')
    print(f'Full report: {(GEN / 'token-lint-results.md').relative_to(ROOT)}')
    return 0 if schema_ok and static_ok else 1


if __name__ == '__main__':
    raise SystemExit(main())
