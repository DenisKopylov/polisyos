#!/usr/bin/env python3
"""Schema/alias lint for Atlas source design tokens."""
from __future__ import annotations
import datetime as dt
import json
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

ROOT = Path(__file__).resolve().parents[1]
SRC_DIR = ROOT / 'tokens' / 'source'
MODE_DIR = ROOT / 'tokens' / 'modes'
GEN_DIR = ROOT / 'tokens' / 'generated'
DIST_DIR = ROOT / 'dist' / 'tokens'
ALIAS_RE = re.compile(r'\{([^{}]+)\}')

@dataclass
class Finding:
    severity: str
    file: str
    check: str
    detail: str


def rel(p: Path) -> str:
    return str(p.relative_to(ROOT)).replace('\\','/')


def load(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding='utf-8'))


def walk(obj: Any, path: Tuple[str, ...] = ()) -> Iterable[Tuple[str, Dict[str, Any]]]:
    if isinstance(obj, dict) and '$value' in obj:
        yield '.'.join(path), obj
        return
    if isinstance(obj, dict):
        for key, value in obj.items():
            if key.startswith('$'):
                continue
            yield from walk(value, (*path, key))


def css_var(token: Dict[str, Any]) -> str | None:
    ext = token.get('$extensions')
    if not isinstance(ext, dict):
        return None
    atlas = ext.get('atlas')
    if not isinstance(atlas, dict):
        return None
    return atlas.get('cssVar')


def resolve(value: Any, source_tokens: Dict[str, Dict[str, Any]], seen: Tuple[str, ...]) -> str:
    if not isinstance(value, str):
        return str(value)
    def repl(m: re.Match[str]) -> str:
        ref = m.group(1)
        if ref not in source_tokens:
            raise KeyError(ref)
        if ref in seen:
            raise RuntimeError('circular reference: ' + ' -> '.join((*seen, ref)))
        return resolve(source_tokens[ref]['$value'], source_tokens, (*seen, ref))
    return ALIAS_RE.sub(repl, value)


def render(findings: List[Finding], counts: Dict[str, int]) -> str:
    now = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat().replace('+00:00','Z')
    blockers = [f for f in findings if f.severity == 'blocker']
    lines = [
        '# Atlas token schema lint', '', f'Generated: `{now}`', '',
        '## Summary', '',
        f'- Source tokens: **{counts.get("source",0)}**',
        f'- Mode tokens: **{counts.get("mode",0)}**',
        f'- Exported CSS variables: **{counts.get("css",0)}**',
        f'- Blockers: **{len(blockers)}**',
        f'- Total findings: **{len(findings)}**', '',
    ]
    if findings:
        lines += ['## Findings', '', '| Severity | File | Check | Detail |', '|---|---|---|---|']
        for f in findings:
            lines.append(f'| {f.severity} | `{f.file}` | `{f.check}` | {f.detail.replace("|", "\\|")} |')
    else:
        lines += ['## Findings', '', 'No schema, alias, export or artifact blockers found.']
    return '\n'.join(lines) + '\n'


def main() -> int:
    findings: List[Finding] = []
    source_tokens: Dict[str, Dict[str, Any]] = {}
    css_exports: Dict[Tuple[str | None, str, str], str] = {}
    counts = {'source': 0, 'mode': 0, 'css': 0}
    files = sorted(SRC_DIR.glob('*.tokens.json')) + sorted(MODE_DIR.glob('*.tokens.json'))
    for path in files:
        try:
            doc = load(path)
        except Exception as exc:
            findings.append(Finding('blocker', rel(path), 'json-parse', str(exc)))
            continue
        atlas = doc.get('$extensions', {}).get('atlas', {}) if isinstance(doc.get('$extensions'), dict) else {}
        selector = atlas.get('selector', ':root')
        media = atlas.get('media')
        for tpath, token in walk(doc):
            is_source = path.is_relative_to(SRC_DIR)
            counts['source' if is_source else 'mode'] += 1
            if '$type' not in token:
                findings.append(Finding('blocker', rel(path), 'missing-type', f'`{tpath}` is missing `$type`.'))
            if '$value' not in token:
                findings.append(Finding('blocker', rel(path), 'missing-value', f'`{tpath}` is missing `$value`.'))
            if is_source:
                if tpath in source_tokens:
                    findings.append(Finding('blocker', rel(path), 'duplicate-token-path', f'`{tpath}` is defined more than once.'))
                source_tokens[tpath] = token
            css = css_var(token)
            if css:
                counts['css'] += 1
                key = (media, selector, css)
                if key in css_exports:
                    findings.append(Finding('blocker', rel(path), 'duplicate-css-var', f'`--{css}` duplicates `{css_exports[key]}` in selector `{selector}`.'))
                css_exports[key] = rel(path)
    # Aliases may point only at source tokens; mode files override raw exported values.
    for path in files:
        try:
            doc = load(path)
        except Exception:
            continue
        for tpath, token in walk(doc):
            value = token.get('$value')
            if not isinstance(value, str):
                continue
            for ref in ALIAS_RE.findall(value):
                if ref not in source_tokens:
                    findings.append(Finding('blocker', rel(path), 'unresolved-alias', f'`{tpath}` references missing `{ref}`.'))
            try:
                resolve(value, source_tokens, (tpath,))
            except Exception as exc:
                findings.append(Finding('blocker', rel(path), 'alias-resolution', f'`{tpath}`: {exc}'))
    # Generated artifacts and dist mirrors.
    required = ['atlas.tokens.css','atlas.tokens.ts','atlas.tailwind.cjs','atlas.figma.tokens.json','token-manifest.json','token-audit.md']
    for name in required:
        gen = GEN_DIR / name
        dist = DIST_DIR / name
        if not gen.exists():
            findings.append(Finding('blocker', rel(gen), 'missing-generated', 'Generated artifact is missing.'))
        elif not dist.exists():
            findings.append(Finding('blocker', rel(dist), 'missing-dist', 'Dist mirror is missing.'))
        elif gen.read_text(encoding='utf-8') != dist.read_text(encoding='utf-8'):
            findings.append(Finding('blocker', rel(dist), 'stale-dist', f'Dist mirror differs from `{rel(gen)}`.'))
    text = render(findings, counts)
    (GEN_DIR / 'token-schema-lint.md').write_text(text, encoding='utf-8')
    (DIST_DIR / 'token-schema-lint.md').write_text(text, encoding='utf-8')
    print(text)
    return 1 if any(f.severity == 'blocker' for f in findings) else 0

if __name__ == '__main__':
    raise SystemExit(main())
