#!/usr/bin/env python3
"""Atlas token static lint.

Default mode enforces two best-in-class constraints:
1. Core design-system entrypoints must not introduce raw visual values.
2. Legacy/prototype raw-value debt must not exceed the checked-in baseline.

Use `--strict` once the migration is complete to fail on every hard-coded color.
Use `--update-baseline` to refresh `tokens/hardcoded-baseline.json` intentionally.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List

ROOT = Path(__file__).resolve().parents[1]
BASELINE = ROOT / 'tokens' / 'hardcoded-baseline.json'
REPORT = ROOT / 'tokens' / 'generated' / 'token-static-lint.md'
DIST_REPORT = ROOT / 'dist' / 'tokens' / 'token-static-lint.md'

HEX_RE = re.compile(r'#[0-9a-fA-F]{3,8}\b')
RGB_RE = re.compile(r'\b(?:rgba?|hsla?)\(([^)]*)\)')

INCLUDE_EXT = {'.jsx', '.tsx', '.js', '.ts', '.html', '.css'}
EXCLUDED_PARTS = {
    'assets', 'fonts', 'node_modules', '.git', '__pycache__',
}
EXCLUDED_EXACT = {
    'colors_and_type.css',
    'landing/colors_and_type.css',
    'tokens/generated/atlas.tokens.css',
    'tokens/generated/atlas.tokens.ts',
    'tokens/generated/atlas.tailwind.cjs',
    'tokens/generated/atlas.figma.tokens.json',
    'tokens/generated/token-manifest.json',
    'tokens/generated/token-audit.md',
    'tokens/generated/token-static-lint.md',
    'packages/atlas-ui/dist/atlas-ui.css',
    'packages/atlas-ui/dist/index.js',
    'packages/atlas-ui/dist/index.cjs',
    'packages/atlas-ui/dist/index.d.ts',
    'packages/atlas-ui/dist/component-manifest.json',
    'packages/atlas-ui/dist/tokens/atlas.tokens.css',
    'tokens/foundation-layer.css',
    'tokens/templates/colors_and_type.template.css',
    'dist/tokens/atlas.tokens.css',
    'dist/tokens/atlas.tokens.ts',
    'dist/tokens/atlas.tailwind.cjs',
    'dist/tokens/atlas.figma.tokens.json',
    'dist/tokens/token-manifest.json',
    'dist/tokens/token-audit.md',
}
CORE_FILES = {
    'ui_kits/dashboard/index.html',
    *[str(path.relative_to(ROOT)).replace('\\', '/') for path in (ROOT / 'ui_kits' / 'dashboard').glob('*.jsx')],
    *[str(path.relative_to(ROOT)).replace('\\', '/') for path in (ROOT / 'ui_kits' / 'dashboard').glob('*.css')],
    *[str(path.relative_to(ROOT)).replace('\\', '/') for path in (ROOT / 'packages' / 'atlas-ui' / 'src').rglob('*') if path.suffix in {'.ts', '.tsx', '.css'}],
    'packages/atlas-ui/.storybook/main.ts',
    'packages/atlas-ui/.storybook/preview.ts',
}

@dataclass(frozen=True)
class Finding:
    file: str
    line: int
    kind: str
    value: str
    core: bool


def rel(path: Path) -> str:
    return str(path.relative_to(ROOT)).replace('\\', '/')


def should_scan(path: Path) -> bool:
    r = rel(path)
    if path.suffix not in INCLUDE_EXT:
        return False
    if r in EXCLUDED_EXACT:
        return False
    parts = set(path.relative_to(ROOT).parts)
    if parts & EXCLUDED_PARTS:
        return False
    if r.startswith('tokens/source/') or r.startswith('tokens/modes/') or r.startswith('tokens/aliases/'):
        return False
    if r.startswith('packages/atlas-ui/dist/') or r.startswith('dist/atlas-ui/'):
        return False
    if r.startswith('tokens/generated/') or r.startswith('dist/tokens/'):
        return False
    return True


def files() -> Iterable[Path]:
    for path in ROOT.rglob('*'):
        if path.is_file() and should_scan(path):
            yield path


def scan_file(path: Path) -> List[Finding]:
    findings: List[Finding] = []
    r = rel(path)
    core = r in CORE_FILES
    for n, line in enumerate(path.read_text(encoding='utf-8', errors='ignore').splitlines(), start=1):
        # Skip URL fragments and integrity hashes; this lint is visual-value focused.
        if 'sha384-' in line or 'http://' in line or 'https://' in line:
            continue
        for match in HEX_RE.finditer(line):
            findings.append(Finding(r, n, 'raw-hex-color', match.group(0), core))
        for match in RGB_RE.finditer(line):
            value = match.group(0)
            if 'var(' in value:
                continue
            findings.append(Finding(r, n, 'raw-functional-color', value, core))
    return findings


def scan() -> List[Finding]:
    out: List[Finding] = []
    for path in files():
        out.extend(scan_file(path))
    return out


def load_baseline() -> Dict[str, int]:
    if not BASELINE.exists():
        return {'total': 10**9, 'core': 0}
    data = json.loads(BASELINE.read_text(encoding='utf-8'))
    return {'total': int(data.get('total', 10**9)), 'core': int(data.get('core', 0))}


def write_baseline(findings: List[Finding]) -> None:
    by_file: Dict[str, int] = {}
    for f in findings:
        by_file[f.file] = by_file.get(f.file, 0) + 1
    payload = {
        'generatedAt': dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat().replace('+00:00', 'Z'),
        'description': 'Baseline for legacy raw color/value debt. Core design-system files must remain zero; total should only go down.',
        'total': len(findings),
        'core': len([f for f in findings if f.core]),
        'byFile': dict(sorted(by_file.items(), key=lambda item: (-item[1], item[0]))),
    }
    BASELINE.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def markdown(findings: List[Finding], baseline: Dict[str, int]) -> str:
    now = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat().replace('+00:00', 'Z')
    core = [f for f in findings if f.core]
    legacy = [f for f in findings if not f.core]
    by_file: Dict[str, int] = {}
    for f in findings:
        by_file[f.file] = by_file.get(f.file, 0) + 1
    top = sorted(by_file.items(), key=lambda item: (-item[1], item[0]))[:25]
    examples = findings[:80]
    lines = [
        '# Atlas Token Static Lint',
        '',
        f'Generated: `{now}`',
        '',
        'This report catches hard-coded visual values outside the token source. It is intentionally conservative: `rgba(var(--token-rgb), alpha)` is allowed, while raw `#hex` and raw `rgba(...)` are treated as migration debt.',
        '',
        '## Gate summary',
        '',
        f'- Core design-system files: **{len(core)}** findings',
        f'- Legacy/prototype findings: **{len(legacy)}**',
        f'- Total findings: **{len(findings)}**',
        f'- Baseline total: **{baseline.get("total", 0)}**',
        '',
        'Core files covered by the zero-debt gate:',
        '',
        *[f'- `{name}`' for name in sorted(CORE_FILES)],
        '',
        '## Top files by remaining migration debt',
        '',
        '| File | Findings |',
        '|---|---:|',
    ]
    for file, count in top:
        lines.append(f'| `{file}` | {count} |')
    if not top:
        lines.append('| — | 0 |')
    lines.extend(['', '## Examples', '', '| File | Line | Type | Value |', '|---|---:|---|---|'])
    for f in examples:
        lines.append(f'| `{f.file}` | {f.line} | `{f.kind}` | `{f.value}` |')
    if not examples:
        lines.append('| — | — | — | — |')
    lines.extend(['', '## Interpretation', '', '- Default gate fails when core files contain raw values or when total legacy debt exceeds the checked-in baseline.', '- `--strict` fails on any finding and should become the release gate once dashboard/landing migration is complete.', '- `--update-baseline` is an intentional governance action; include a migration note when using it.', ''])
    return '\n'.join(lines)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--strict', action='store_true', help='Fail if any hard-coded visual value remains.')
    parser.add_argument('--update-baseline', action='store_true', help='Write current finding counts to tokens/hardcoded-baseline.json.')
    parser.add_argument('--quiet', action='store_true', help='Write reports without printing the full markdown body.')
    args = parser.parse_args()

    findings = scan()
    if args.update_baseline:
        write_baseline(findings)
    baseline = load_baseline()
    text = markdown(findings, baseline)
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(text, encoding='utf-8')
    DIST_REPORT.parent.mkdir(parents=True, exist_ok=True)
    DIST_REPORT.write_text(text, encoding='utf-8')
    if args.quiet:
        core_count = len([f for f in findings if f.core])
        print(f'Atlas Token Static Lint: core={core_count} total={len(findings)} baseline={baseline.get("total")}')
    else:
        print(text)

    core_count = len([f for f in findings if f.core])
    if args.strict and findings:
        return 1
    if core_count > baseline.get('core', 0):
        return 1
    if len(findings) > baseline.get('total', 10**9):
        return 1
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
