#!/usr/bin/env python3
"""Fast release verification for generated Atlas design-system artifacts."""
from __future__ import annotations
import re
from datetime import datetime, timezone
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / 'dist' / 'verification'
REPORT = OUT_DIR / 'verification-report.md'
LOG = OUT_DIR / 'verify.log'
EXPECTED_COMPONENTS = 56
CHECKS: list[tuple[str, str, list[str]]] = [
    ('tokens:schema', 'tokens/generated/token-schema-lint.md', [r'- Blockers: \*\*0\*\*', r'- Total findings: \*\*0\*\*']),
    ('tokens:static', 'tokens/generated/token-static-lint.md', [r'- Core design-system files: \*\*0\*\* findings', r'- Baseline total: \*\*1933\*\*']),
    ('tokens:aggregate', 'tokens/generated/token-lint-results.md', [r'- `schema`: \*\*PASS\*\*', r'- `static-drift`: \*\*PASS\*\*']),
    ('data-viz:lint', 'data-visualization/audit-results.md', [r'- Required chart types: \*\*16\*\*', r'- Required data-viz components: \*\*14\*\*', r'- Blockers: \*\*0\*\*', r'- Warnings: \*\*0\*\*']),
    ('theming:lint', 'theming/audit-results.md', [r'- Required modes: \*\*16\*\*', r'- Required theming components: \*\*3\*\*', r'- Blockers: \*\*0\*\*', r'- Warnings: \*\*0\*\*']),
    ('responsive:lint', 'dashboard-responsive/audit-results.md', [r'- Window classes: \*\*5\*\*', r'- Required window classes: \*\*5\*\*', r'- Blockers: \*\*0\*\*', r'- Warnings: \*\*0\*\*']),
    ('components:lint', 'component-library/component-library-audit.md', [rf'- Components in manifest: \*\*{EXPECTED_COMPONENTS}\*\*', rf'- Required v15 components: \*\*{EXPECTED_COMPONENTS}\*\*', r'- Blockers: \*\*0\*\*', r'- Warnings: \*\*0\*\*']),
    ('states:lint', 'component-library/state-matrix-audit.md', [rf'- Components in matrix: \*\*{EXPECTED_COMPONENTS}\*\*', rf'- Required v15 components: \*\*{EXPECTED_COMPONENTS}\*\*', r'- Blockers: \*\*0\*\*', r'- Warnings: \*\*0\*\*']),
    ('a11y:contrast', 'accessibility/contrast-audit.md', [r'Restricted pairs: 3', r'Primary action contrast now passes']),
    ('a11y:static', 'accessibility/audit-results.md', [r'- Blockers: \*\*0\*\*', r'- Warnings: \*\*0\*\*']),
]
ARTIFACTS = [
    'tokens/generated/atlas.tokens.css','dist/tokens/atlas.tokens.css','dist/atlas-ui/esm/index.js','dist/atlas-ui/esm/index.d.ts','dist/atlas-ui/atlas-ui.css','dist/atlas-ui/component-manifest.json','dist/atlas-ui/state-matrix.json','dist/atlas-ui/state-taxonomy.json','dist/atlas-ui/component-state-matrix.json','packages/atlas-ui/dashboard-responsive.json','dist/dashboard-responsive/responsive-manifest.json','dist/atlas-ui/dashboard-responsive.json','dashboard-responsive/audit-results.md','dist/verification/dashboard-responsive-audit.md','data-visualization/data-viz-manifest.json','data-visualization/audit-results.md','packages/atlas-ui/data-visualization.json','packages/atlas-ui/data-viz.json','dist/data-visualization/data-viz-manifest.json','dist/data-visualization/data-viz.json','dist/atlas-ui/data-visualization.json','dist/atlas-ui/data-viz.json','dist/atlas-ui/chart-grammar.json','packages/atlas-ui/chart-grammar.json','theming/theme-manifest.json','theming/theme-modes.json','theming/audit-results.md','packages/atlas-ui/theme-manifest.json','packages/atlas-ui/theme-modes.json','dist/theming/theme-manifest.json','dist/theming/theme-modes.json','dist/atlas-ui/theme-manifest.json','dist/atlas-ui/theme-modes.json'
]
def exists(path: str) -> bool: return (ROOT / path).exists()
def matches(path: str, patterns: list[str]) -> tuple[bool, list[str]]:
    p = ROOT / path
    if not p.exists(): return False, [f'missing evidence file: {path}']
    text = p.read_text(encoding='utf-8', errors='ignore')
    missing = [pattern for pattern in patterns if not re.search(pattern, text, flags=re.MULTILINE)]
    return len(missing) == 0, missing

def main() -> int:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    rows: list[tuple[str, bool, str]] = []
    log_lines: list[str] = []
    for artifact in ARTIFACTS:
        ok = exists(artifact); rows.append((f'artifact:{artifact}', ok, 'present' if ok else 'missing'))
        if not ok: log_lines.append(f'Missing artifact: {artifact}')
    for label, file_path, patterns in CHECKS:
        ok, missing = matches(file_path, patterns); rows.append((label, ok, file_path if ok else '; '.join(missing)))
        if missing: log_lines.append(f'{label}: {missing}')
    now = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00','Z')
    lines = ['# Atlas v15 verification report','',f'Generated: `{now}`','', 'This report verifies the generated evidence files and distributable artifacts for the v15 theming accessibility modes release.','', '| Gate | Result | Evidence |','|---|---|---|']
    for label, ok, evidence in rows:
        lines.append(f'| `{label}` | **{"PASS" if ok else "FAIL"}** | `{evidence}` |')
    lines.extend(['','## Manual full gate commands','','Run these evidence checks after modifying source files:','','```bash','npm run tokens:build','npm run tokens:lint','npm run data-viz:build','npm run data-viz:lint','npm run theming:build','npm run theming:lint','npm run dashboard:responsive:build','npm run dashboard:responsive:lint','npm run states:build','npm run states:lint','npm run components:build','npm run components:lint','npm run a11y:contrast','npm run a11y:lint','npm run verify','```',''])
    REPORT.write_text('\n'.join(lines), encoding='utf-8')
    LOG.write_text('\n'.join(log_lines) if log_lines else 'All generated evidence checks passed.\n', encoding='utf-8')
    print('\n'.join(lines))
    return 0 if all(ok for _, ok, _ in rows) else 1
if __name__ == '__main__': raise SystemExit(main())
