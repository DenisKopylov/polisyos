# Security and privacy UX contracts

Atlas is used in governance and evidence workflows, so security/privacy behavior must be visible, understandable and auditable.

## Files

- `sensitive-data-display.md`
- `permission-states.md`
- `redaction-export.md`
- `audit-trail.md`
- `destructive-actions.md`
- `data-residency.md`

