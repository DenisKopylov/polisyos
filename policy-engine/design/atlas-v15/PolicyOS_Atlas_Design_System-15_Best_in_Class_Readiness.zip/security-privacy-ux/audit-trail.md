# Audit trail UX

## Required fields

| Field | Requirement |
|---|---|
| Actor | Human or system identity |
| Action | Verb/object, not vague event text |
| Time | Local time, timezone and UTC in detail/export |
| Source | System/evidence source where relevant |
| Reason | Required for approvals, overrides and destructive actions |
| Before/after | Required when material state changes |
| Redaction | Mark hidden/suppressed fields |
| Integrity | Show immutable/signed status when available |

## Interaction rules

- Audit entries must be readable without color reliance.
- Filters must not hide critical security events by default.
- Copy/export actions must preserve timestamps and IDs.
- Long audit text must be expandable, not destructively truncated.

