# Data residency UX

## Required labels

- Region or residency boundary when policy-relevant.
- Transfer warning when evidence crosses boundary.
- Retention policy or link for exported artifacts.
- Source system and connector for imported evidence.

## Rules

- Do not hide residency warnings in tooltips only.
- Exports must include residency/redaction metadata when policy-relevant.
- Permission and residency messages must not disclose restricted data.

