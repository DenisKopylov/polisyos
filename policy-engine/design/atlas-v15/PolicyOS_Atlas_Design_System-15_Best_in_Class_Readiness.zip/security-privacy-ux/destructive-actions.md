# Destructive actions

## Required confirmation content

- Object name.
- Scope of deletion/change.
- Whether action is reversible.
- Affected users/systems.
- Audit impact.
- Required permission/approval.

## Confirmation strength

| Risk | Pattern |
|---|---|
| Low | Inline confirmation or undo |
| Medium | Dialog with clear consequence |
| High | Typed confirmation or second approver |
| Critical | Separate approval workflow and audit reason |

## Rules

- Default focus should not land on destructive action for high-risk dialogs.
- Use specific button text: "Delete draft packet", not "Confirm".
- Require reason when governance or audit policy needs it.

