# Permission states

## Required states

| State | User message |
|---|---|
| No access | Explain boundary and request path |
| Pending access | Show request status and owner if available |
| Partial access | Explain which data/actions are unavailable |
| Expired access | Explain expiration and renewal path |
| Elevated action required | Explain role or approval required |

## Rules

- Do not use disabled controls without explaining why.
- Do not imply data exists when disclosure itself is sensitive.
- Use request-access CTA when product policy allows it.
- Permission errors must not leak restricted details.

