# Redaction and export contract

Exports are durable artifacts. Redaction must be explicit and auditable.

## Export metadata

Every audit/export packet should include:

- generated timestamp;
- timezone;
- actor/system;
- source set;
- redaction policy/version;
- fields redacted or suppressed;
- evidence freshness status;
- checksum/signature if available.

## Redaction UI requirements

- Show redaction preview before export when possible.
- Mark redacted fields in the exported artifact.
- Do not silently omit critical context.
- Preserve enough metadata to explain why content is missing.

