# Sensitive data display

## Display states

| State | Required behavior |
|---|---|
| Masked | Default for secrets, tokens, credentials and high-risk identifiers |
| Revealed | Explicit user action, temporary, logged when required |
| Copied | Explicit action, success feedback, audit event for high-risk values |
| Expired | Auto-remask after timeout or navigation |
| Redacted | Removed from export/output and marked as redacted |

## Rules

- Do not reveal sensitive values on hover alone.
- Do not copy sensitive values without visible user action.
- Use `SecretField` or a governed sensitive-data pattern.
- Redaction status must survive export and print.
- Screenshots/exports must honor redaction policy.

