# Accessibility modes

## High contrast

High contrast increases boundaries, focus indicators, chart strokes and data-grid affordances.

## Forced colors

Forced colors uses `Canvas`, `CanvasText`, `ButtonFace`, `ButtonText`, `Highlight`, `LinkText`, `Field` and `FieldText` system colors.

## Reduced motion

Reduced motion makes durations effectively immediate and removes non-essential transform feedback while preserving state change feedback.

## Reduced transparency

Reduced transparency removes glass, backdrop filters and low-alpha surfaces from panels, drawers, dialogs and chart frames.

## Large text

Large text increases base typography and control height without changing document order.

## Color-safe

Color-safe mode switches status and chart palettes away from red/green-only encoding and requires visible labels, shapes or patterns.
