# Atlas Theming Accessibility Modes Audit

Generated: `2026-06-09T17:33:09Z`

## Gate summary

- Modes: **16**
- Required modes: **16**
- Runtime attributes: **9**
- Required theming components: **3**
- Required tokens checked: **9**
- Blockers: **0**
- Warnings: **0**

## Findings

| Severity | Subject | Message |
|---|---|---|
| — | — | No findings. |

## Mode coverage

| Mode | Axis | Media | Tokens |
|---|---|---|---|
| `light` | `color-scheme` | `manual` | `source defaults` |
| `dark` | `color-scheme` | `manual` | `tokens/modes/dark.tokens.json` |
| `auto-dark` | `color-scheme` | `(prefers-color-scheme: dark)` | `tokens/modes/prefers-color-scheme-dark.tokens.json` |
| `high-contrast` | `contrast` | `manual` | `tokens/modes/high-contrast.tokens.json` |
| `prefers-contrast` | `contrast` | `(prefers-contrast: more)` | `tokens/modes/prefers-contrast.tokens.json` |
| `forced-colors` | `contrast` | `(forced-colors: active)` | `tokens/modes/forced-colors.tokens.json` |
| `reduced-motion` | `motion` | `manual` | `tokens/modes/reduced-motion.tokens.json` |
| `prefers-reduced-motion` | `motion` | `(prefers-reduced-motion: reduce)` | `tokens/modes/prefers-reduced-motion.tokens.json` |
| `reduced-transparency` | `transparency` | `manual` | `tokens/modes/reduced-transparency-manual.tokens.json` |
| `prefers-reduced-transparency` | `transparency` | `(prefers-reduced-transparency: reduce)` | `tokens/modes/reduced-transparency.tokens.json` |
| `large-text` | `text-scale` | `manual` | `tokens/modes/large-text.tokens.json` |
| `color-safe` | `color-vision` | `manual` | `tokens/modes/color-safe.tokens.json` |
| `comfortable-density` | `density` | `manual` | `tokens/modes/comfortable-density.tokens.json` |
| `compact-density` | `density` | `manual` | `tokens/modes/compact-density.tokens.json` |
| `condensed-density` | `density` | `manual` | `tokens/modes/condensed-density.tokens.json` |
| `print` | `output` | `print` | `tokens/modes/print.tokens.json` |
