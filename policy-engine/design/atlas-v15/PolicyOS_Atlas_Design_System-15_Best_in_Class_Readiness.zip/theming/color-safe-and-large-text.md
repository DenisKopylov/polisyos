# Color-safe and large-text contract

Color-safe mode changes palette and adds non-color status affordances. It does not rename statuses or change data semantics.

Large text mode increases base type and controls while preserving responsive reflow and keyboard order.
