# Contrast and forced-colors contract

Atlas treats contrast as a separate axis from light/dark. `prefers-contrast: more` thickens borders and focus outlines. `forced-colors: active` switches to system color keywords and avoids custom shadows and low-alpha surfaces.

Do not set `forced-color-adjust: none` unless the component pairs every foreground/background with system colors and has a manual accessibility rationale.
