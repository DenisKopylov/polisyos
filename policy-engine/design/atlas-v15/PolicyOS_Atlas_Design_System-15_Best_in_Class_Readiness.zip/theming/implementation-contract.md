# Implementation contract

Use `ThemeProvider` at the app root. It writes Atlas data attributes to `document.documentElement` and renders a local wrapper for scoped previews.

```tsx
<ThemeProvider theme="auto" density="comfortable" motion="auto" colorSafe>
  <App />
</ThemeProvider>
```

Use `ThemeToggle` for a compact color-scheme switch. Use `AccessibilityModePanel` for full review/demo surfaces.
