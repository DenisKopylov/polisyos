# Theming migration checklist

- Replace ad-hoc `data-theme` writes with `ThemeProvider` or `applyAtlasThemeAttributes`.
- Keep `data-theme` only as compatibility output; write `data-atlas-theme` in new code.
- Do not use raw colors in component source for mode-specific styling.
- Do not use opacity-only disabled states in high-contrast or forced-colors mode.
- Use labels, patterns or shapes for status meaning in color-safe mode.
- Test at 200 percent zoom and 320 CSS px reflow before stable release.
