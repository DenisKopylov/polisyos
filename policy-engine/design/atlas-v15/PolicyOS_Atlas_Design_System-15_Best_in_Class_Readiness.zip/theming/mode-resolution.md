# Mode resolution

Atlas resolves modes by axis, not by one monolithic theme string. A user can run dark + color-safe + reduced-motion + large-text at the same time.

## Order

Forced-colors is highest priority because the user agent is enforcing a limited palette chosen by the user. Atlas uses system color keywords instead of overriding that palette. Explicit high-contrast follows. Explicit light/dark beats automatic `prefers-color-scheme`. Output media such as print remove decorative glass and shadows after color tokens are resolved.

## Runtime attributes

`ThemeProvider` applies both Atlas attributes and legacy compatibility attributes. New product code should read/write Atlas attributes only.
