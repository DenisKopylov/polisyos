# Motion and transparency contract

Motion is reduced by tokens and by CSS media queries. Reduced motion must not remove focus indicators, loading labels or state announcements.

Reduced transparency replaces glass and blur with opaque surfaces. This improves readability for users who struggle with translucent layers.
