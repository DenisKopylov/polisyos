# Theming testing contract

## Static gates

- `scripts/theming_lint.py` verifies manifest, docs, required mode tokens, mirrors and package exports.
- `scripts/token_schema_lint.py` verifies mode aliases and CSS-variable generation.
- `scripts/component_lint.py` verifies theming components are documented, exported and token-only.

## Browser gates backlog

- Playwright matrix: light, dark, high-contrast, forced-colors emulation, reduced-motion, reduced-transparency, large-text, color-safe and print.
- Storybook visual regression: ThemeProvider, ThemeToggle, AccessibilityModePanel and representative data-viz/form/dashboard surfaces.
- Manual AT pass: Windows High Contrast, macOS/iOS Reduce Transparency, Reduce Motion, browser zoom and 320 CSS px reflow.
