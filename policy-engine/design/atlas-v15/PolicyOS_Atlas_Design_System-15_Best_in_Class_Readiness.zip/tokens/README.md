# Atlas Token Pipeline

Atlas v9 treats design tokens as infrastructure. The token source is DTCG-style JSON, generated artifacts are committed, and the dashboard shell is guarded against hard-coded visual-value drift.

## Architecture

| Layer | Files | Purpose | Consumption rule |
|---|---|---|---|
| Primitive | `tokens/source/primitive.tokens.json` | Raw brand and system decisions: palette, RGB channels, spacing, radii, shadows, typography, focus and target sizes. | Token authors only. Product UI should not bind directly unless a semantic token is missing. |
| Semantic | `tokens/source/semantic.tokens.json` | Product meaning: text, signal, status, severity, governance, chart, confidence, button aliases. | Default API for product surfaces. |
| Component | `tokens/source/component.tokens.json` | Component contracts: buttons, badges, panels, metrics, run cards, rail/sidebar. | Preferred API for reusable components. |
| Mode | `tokens/modes/*.tokens.json` | Dark, high-contrast, prefers-contrast, reduced-transparency and density overrides. | Build-time overlays that emit selector/media-scoped CSS variables. |
| Generated | `tokens/generated/*`, `dist/tokens/*` | CSS, TypeScript, Tailwind, Figma handoff, manifest and audits. | Never edit manually. Regenerate from source. |

## Commands

```bash
python3 scripts/token_build.py
python3 scripts/token_lint.py
python3 scripts/a11y_contrast_audit.py > accessibility/contrast-audit.md
python3 scripts/a11y_static_lint.py > accessibility/audit-results.md
```

`python3 scripts/build_tokens.py` remains available as a compatibility wrapper around `scripts/token_build.py`.

## Generated outputs

| Output | Purpose |
|---|---|
| `tokens/generated/atlas.tokens.css` | CSS custom properties for base tokens and mode selectors. |
| `colors_and_type.css` / `landing/colors_and_type.css` | Generated token declarations plus the accessibility/type utility layer. |
| `tokens/generated/atlas.tokens.ts` | TypeScript token constants, mode map and `token(name)` helper. |
| `tokens/generated/atlas.tailwind.cjs` | Tailwind `theme.extend` bridge using CSS variables. |
| `tokens/generated/atlas.figma.tokens.json` | DTCG-preserving handoff for Figma Variables / Tokens Studio style workflows. |
| `tokens/generated/token-manifest.json` | Source files, counts, aliases and generated artifact list. |
| `tokens/generated/token-audit.md` | Build health summary. |
| `tokens/generated/token-schema-lint.md` | Schema, alias and generated-artifact validation report. |
| `tokens/generated/token-static-lint.md` | Hard-coded visual value migration report. |
| `tokens/generated/token-lint-results.md` | Aggregated token gate report. |
| `tokens/hardcoded-baseline.json` | Current allowed legacy debt; core files must stay at zero and total debt must not increase. |
| `dist/tokens/*` | Consumer mirror of generated artifacts. |

## Authoring rules

1. Add new raw colors, dimensions, shadows and font decisions only in `tokens/source/primitive.tokens.json` or an explicit mode override.
2. Add product meaning in `tokens/source/semantic.tokens.json` before using it in screens.
3. Add component-specific variables in `tokens/source/component.tokens.json` for stable primitives.
4. Do not hand-edit `colors_and_type.css`, `landing/colors_and_type.css`, `tokens/generated/*`, or `dist/tokens/*`.
5. Preserve legacy variable names until the landing/preview migration is complete.
6. A token change that changes meaning, contrast, density or mode behavior requires a note in `TOKEN_PIPELINE_DELTA.md`.

## CI gates

A release-quality check should run:

```bash
npm run verify
```

Equivalent dependency-free commands:

```bash
python3 scripts/token_build.py
python3 scripts/token_lint.py
python3 scripts/a11y_contrast_audit.py > accessibility/contrast-audit.md
python3 scripts/a11y_static_lint.py > accessibility/audit-results.md
```

The current gate status is:

- Token build: **188** root CSS variables, **102** mode override variables.
- Token lint: schema gate **0 blockers / 0 findings**; static drift gate **0** core findings and **1,933** historical landing/preview findings tracked by baseline.
- Accessibility static lint: **0** blockers / **0** warnings.
- Contrast audit: semantic text/control pairs pass; vibrant chart colors remain restricted for normal text.

## Migration policy

New code must not add raw `#hex`, raw `rgb(...)`, raw `rgba(...)`, raw `hsl(...)`, or raw `hsla(...)` values outside token source files. `scripts/token_lint.py` runs schema validation first and then static drift validation. The default token lint allows the existing static landing/preview baseline but fails when the baseline grows. `--strict` is reserved for the future state where the full package is token-clean.

## Data visualization tokens

`tokens/source/data-viz.tokens.json` defines chart frame, plot, axis, grid, series, uncertainty, semantic mark and interaction tokens. Dark, high-contrast and prefers-contrast overrides are emitted through existing mode files.
