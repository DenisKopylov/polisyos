# Atlas token pipeline audit

Generated: `2026-06-09T18:11:00Z`

## Summary

- Root tokens: **711**
- Exported root CSS variables: **643**
- Mode override tokens: **514**
- Exported mode CSS variables: **505**
- Alias references: **258**

## Layers

- `component`: 367
- `dataViz`: 52
- `primitive`: 158
- `responsive`: 29
- `semantic`: 74
- `theme`: 31

## Modes

- `tokens/modes/color-safe.tokens.json`: 20
- `tokens/modes/comfortable-density.tokens.json`: 15
- `tokens/modes/compact-density.tokens.json`: 18
- `tokens/modes/condensed-density.tokens.json`: 18
- `tokens/modes/dark.tokens.json`: 97
- `tokens/modes/forced-colors.tokens.json`: 39
- `tokens/modes/high-contrast.tokens.json`: 129
- `tokens/modes/large-text.tokens.json`: 10
- `tokens/modes/prefers-color-scheme-dark.tokens.json`: 97
- `tokens/modes/prefers-contrast.tokens.json`: 19
- `tokens/modes/prefers-reduced-motion.tokens.json`: 8
- `tokens/modes/print.tokens.json`: 18
- `tokens/modes/reduced-motion.tokens.json`: 8
- `tokens/modes/reduced-transparency-dark.tokens.json`: 6
- `tokens/modes/reduced-transparency-manual.tokens.json`: 6
- `tokens/modes/reduced-transparency.tokens.json`: 6

## Contract

- Primitive tokens are the brand/raw design decisions.
- Semantic tokens are the default product API.
- Component tokens bind stable components to semantic tokens.
- Mode files override exported CSS variables only through `tokens/modes/*.tokens.json`.
- Generated files should not be hand-edited.
