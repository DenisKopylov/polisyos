# Atlas token lint results

Generated: `2026-06-09T18:18:52Z`

## Gate summary

- `schema`: **PASS** (report present)
- `static-drift`: **PASS** (report present)

## Check output

### schema

Status: `PASS`

```text
# Atlas token schema lint

Generated: `2026-06-09T18:18:48Z`

## Summary

- Source tokens: **711**
- Mode tokens: **514**
- Exported CSS variables: **1148**
- Blockers: **0**
- Total findings: **0**

## Findings

No schema, alias, export or artifact blockers found.
```

### static-drift

Status: `PASS`

```text
# Atlas Token Static Lint

Generated: `2026-06-09T18:18:50Z`

This report catches hard-coded visual values outside the token source. It is intentionally conservative: `rgba(var(--token-rgb), alpha)` is allowed, while raw `#hex` and raw `rgba(...)` are treated as migration debt.

## Gate summary

- Core design-system files: **0** findings
- Legacy/prototype findings: **1933**
- Total findings: **1933**
- Baseline total: **1933**

Core files covered by the zero-debt gate:

- `packages/atlas-ui/.storybook/main.ts`
- `packages/atlas-ui/.storybook/preview.ts`
- `packages/atlas-ui/src/atlas-ui.css`
- `packages/atlas-ui/src/components/Badge/Badge.tsx`
- `packages/atlas-ui/src/components/Button/Button.tsx`
- `packages/atlas-ui/src/components/Card/Card.tsx`
- `packages/atlas-ui/src/components/Dashboard/DashboardGrid.tsx`
- `packages/atlas-ui/src/components/Dashboard/DashboardMain.tsx`
- `packages/atlas-ui/src/components/Dashboard/DashboardShell.tsx`
- `packages/atlas-ui/src/components/Dashboard/DashboardSidebar.tsx`
- `packages/atlas-ui/src/components/Dashboard/DashboardTopBar.tsx`
- `packages/atlas-ui/src/components/Dashboard/ResponsiveDataRegion.tsx`
- `packages/atlas-ui/src/components/DashboardLayout/AdaptiveDataRegion.tsx`
- `packages/atlas-ui/src/components/DashboardLayout/DashboardMain.tsx`
- `packages/atlas-ui/src/components/DashboardLayout/DashboardShell.tsx`
- `packages/atlas-ui/src/components/DashboardLayout/DashboardSidebar.tsx`
- `packages/atlas-ui/src/components/DashboardLayout/ResponsiveGrid.tsx`
- `packages/atlas-ui/src/components/DashboardLayout/index.ts`
- `packages/atlas-ui/src/components/DashboardShell/DashboardShell.tsx`
- `packages/atlas-ui/src/components/DashboardShell/DashboardSidebar.tsx`
- `packages/atlas-ui/src/components/DashboardShell/DashboardTopBar.tsx`
- `packages/atlas-ui/src/components/DashboardShell/ResponsiveGrid.tsx`
- `packages/atlas-ui/src/components/DataEntry/CharacterCount.tsx`
- `packages/atlas-ui/src/components/DataEntry/CheckboxGroup.tsx`
- `packages/atlas-ui/src/components/DataEntry/Combobox.tsx`
- `packages/atlas-ui/src/components/DataEntry/DateField.tsx`
- `packages/atlas-ui/src/components/DataEntry/DateRangeField.tsx`
- `packages/atlas-ui/src/components/DataEntry/FileUpload.tsx`
- `packages/atlas-ui/src/components/DataEntry/NumberField.tsx`
- `packages/atlas-ui/src/components/DataEntry/PasswordField.tsx`
- `packages/atlas-ui/src/components/DataEntry/RadioGroup.tsx`
- `packages/atlas-ui/src/components/DataEntry/RangeField.tsx`
- `packages/atlas-ui/src/components/DataEntry/SearchField.tsx`
- `packages/atlas-ui/src/components/DataEntry/SecretField.tsx`
- `packages/atlas-ui/src/components/DataEntry/TokenInput.tsx`
- `packages/atlas-ui/src/components/DataTable/DataTable.tsx`
- `packages/atlas-ui/src/components/DataVisualization/BarChart.tsx`
- `packages/atlas-ui/src/components/DataVisualization/CausalGraph.tsx`
- `packages/atlas-ui/src/components/DataVisualization/ChartAnnotation.tsx`
- `packages/atlas-ui/src/components/DataVisualization/ChartDataTable.tsx`
- `packages/atlas-ui/src/components/DataVisualization/ChartFrame.tsx`
- `packages/atlas-ui/src/components/DataVisualization/ChartLegend.tsx`
- `packages/atlas-ui/src/components/DataVisualization/ChartTooltip.tsx`
- `packages/atlas-ui/src/components/DataVisualization/DataVizLegend.tsx`
- `packages/atlas-ui/src/components/DataVisualization/DataVizTable.tsx`
- `packages/atlas-ui/src/components/DataVisualization/Heatmap.tsx`
- `packages/atlas-ui/src/components/DataVisualization/LineChart.tsx`
- `packages/atlas-ui/src/components/DataVisualization/ProvenanceGraph.tsx`
- `packages/atlas-ui/src/components/DataVisualization/ProvenanceMap.tsx`
- `packages/atlas-ui/src/components/DataVisualization/Sparkline.tsx`
- `packages/atlas-ui/src/components/DataVisualization/UncertaintyBand.tsx`
- `packages/atlas-ui/src/components/DataVisualization/chartUtils.ts`
- `packages/atlas-ui/src/components/DataVisualization/index.ts`
- `packages/atlas-ui/src/components/DataVisualization/scales.ts`
- `packages/atlas-ui/src/components/DataVisualization/types.ts`
- `packages/atlas-ui/src/components/Dialog/Dialog.tsx`
- `packages/atlas-ui/src/components/EmptyState/EmptyState.tsx`
- `packages/atlas-ui/src/components/Field/Checkbox.tsx`
- `packages/atlas-ui/src/components/Field/SelectField.tsx`
- `packages/atlas-ui/src/components/Field/Switch.tsx`
- `packages/atlas-ui/src/components/Field/TextArea.tsx`
- `packages/atlas-ui/src/components/Field/TextField.tsx`
- `packages/atlas-ui/src/components/Form/FieldGroup.tsx`
- `packages/atlas-ui/src/components/Form/Form.tsx`
- `packages/atlas-ui/src/components/Form/FormSection.tsx`
- `packages/atlas-ui/src/components/Form/ValidationSummary.tsx`
- `packages/atlas-ui/src/components/GovernanceGate/GovernanceGate.tsx`
- `packages/atlas-ui/src/components/Layout/AppShell.tsx`
- `packages/atlas-ui/src/components/Layout/Cluster.tsx`
- `packages/atlas-ui/src/components/Layout/ResponsiveGrid.tsx`
- `packages/atlas-ui/src/components/Layout/ScrollArea.tsx`
- `packages/atlas-ui/src/components/Layout/SidebarNav.tsx`
- `packages/atlas-ui/src/components/Layout/Stack.tsx`
- `packages/atlas-ui/src/components/Layout/TopBar.tsx`
- `packages/atlas-ui/src/components/MetricCard/MetricCard.tsx`
- `packages/atlas-ui/src/components/Panel/Panel.tsx`
- `packages/atlas-ui/src/components/Responsive/DashboardShell.tsx`
- `packages/atlas-ui/src/components/Responsive/DashboardTopBar.tsx`
- `packages/atlas-ui/src/components/Responsive/ResponsiveGrid.tsx`
- `packages/atlas-ui/src/components/Responsive/ScrollRegion.tsx`
- `packages/atlas-ui/src/components/RunCard/RunCard.tsx`
- `packages/atlas-ui/src/components/Skeleton/Skeleton.tsx`
- `packages/atlas-ui/src/components/Tabs/Tabs.tsx`
- `packages/atlas-ui/src/components/Theming/AccessibilityModePanel.tsx`
- `packages/atlas-ui/src/components/Theming/ThemeProvider.tsx`
- `packages/atlas-ui/src/components/Theming/ThemeToggle.tsx`
- `packages/atlas-ui/src/components/Theming/index.ts`
- `packages/atlas-ui/src/components/Toast/Toast.tsx`
- `packages/atlas-ui/src/components/VisuallyHidden/VisuallyHidden.tsx`
- `packages/atlas-ui/src/dashboard-responsive-contracts.ts`
- `packages/atlas-ui/src/data-visualization-contracts.ts`
- `packages/atlas-ui/src/data-viz-contracts.ts`
- `packages/atlas-ui/src/index.ts`
- `packages/atlas-ui/src/react-shim.d.ts`
- `packages/atlas-ui/src/state-contracts.ts`
- `packages/atlas-ui/src/theme-contracts.ts`
- `packages/atlas-ui/src/types.ts`
- `packages/atlas-ui/src/utils/cx.ts`
- `packages/atlas-ui/src/utils/ids.ts`
- `ui_kits/dashboard/ArgumentMap.jsx`
- `ui_kits/dashboard/CapacityPlanner.jsx`
- `ui_kits/dashboard/CausalAtlas.jsx`
- `ui_kits/dashboard/CohortTimeTraveler.jsx`
- `ui_kits/dashboard/Components.jsx`
- `ui_kits/dashboard/Composer.jsx`
- `ui_kits/dashboard/ConnectorCards.jsx`
- `ui_kits/dashboard/CounterfactualExplorer.jsx`
- `ui_kits/dashboard/Dashboard.jsx`
- `ui_kits/dashboard/DisputeLedger.jsx`
- `ui_kits/dashboard/EmbargoManager.jsx`
- `ui_kits/dashboard/EvidenceFabric.jsx`
- `ui_kits/dashboard/EvidenceSynthesis.jsx`
- `ui_kits/dashboard/FailureTriage.jsx`
- `ui_kits/dashboard/FairnessAudit.jsx`
- `ui_kits/dashboard/FreshnessBraid.jsx`
- `ui_kits/dashboard/IdentifiabilitySurface.jsx`
- `ui_kits/dashboard/LineageGravityMap.jsx`
- `ui_kits/dashboard/LiveRunMonitor.jsx`
- `ui_kits/dashboard/OpsAuditTrail.jsx`
- `ui_kits/dashboard/ProfileDriftNarrative.jsx`
- `ui_kits/dashboard/ProvenanceCertificate.jsx`
- `ui_kits/dashboard/QualityBudget.jsx`
- `ui_kits/dashboard/ReasoningChain.jsx`
- `ui_kits/dashboard/RunChoreography.jsx`
- `ui_kits/dashboard/RunDetail.jsx`
- `ui_kits/dashboard/SchemaMigration.jsx`
- `ui_kits/dashboard/SensitivityRotor.jsx`
- `ui_kits/dashboard/Sidebar.jsx`
- `ui_kits/dashboard/StakeholderLens.jsx`
- `ui_kits/dashboard/StressTestTheatre.jsx`
- `ui_kits/dashboard/UncertaintyDecomposer.jsx`
- `ui_kits/dashboard/dashboard-responsive.css`
- `ui_kits/dashboard/index.html`

## Top files by remaining migration debt

| File | Findings |
|---|---:|
| `landing/docs.html` | 172 |
| `landing/onboarding.html` | 153 |
| `landing/components.html` | 147 |
| `landing/empty-states.html` | 121 |
| `landing/decision-packet.html` | 116 |
| `landing/index.html` | 110 |
| `landing/pricing.html` | 98 |
| `landing/states.html` | 98 |
| `landing/mobile.html` | 88 |
| `landing/auth.html` | 74 |
| `landing/calculator.html` | 73 |
| `landing/changelog.html` | 72 |
| `landing/status.html` | 70 |
| `landing/api.html` | 63 |
| `landing/case-study.html` | 61 |
| `landing/trust.html` | 61 |
| `landing/ios-frame.jsx` | 58 |
| `landing/design-canvas.jsx` | 48 |
| `landing/emails.html` | 46 |
| `preview/uncertainty.html` | 39 |
| `landing/error-pages.css` | 37 |
| `preview/colors-base.html` | 35 |
| `preview/cards.html` | 14 |
| `preview/colors-semantic.html` | 14 |
| `landing/offline.html` | 12 |

## Examples

| File | Line | Type | Value |
|---|---:|---|---|
| `landing/404.html` | 12 | `raw-hex-color` | `#fbf8f2` |
| `landing/404.html` | 13 | `raw-hex-color` | `#16202b` |
| `landing/404.html` | 40 | `raw-hex-color` | `#FBF8F2` |
| `landing/404.html` | 41 | `raw-hex-color` | `#FBF8F2` |
| `landing/404.html` | 42 | `raw-hex-color` | `#B58B2B` |
| `landing/500.html` | 12 | `raw-hex-color` | `#fbf8f2` |
| `landing/500.html` | 13 | `raw-hex-color` | `#16202b` |
| `landing/500.html` | 40 | `raw-hex-color` | `#FBF8F2` |
| `landing/500.html` | 41 | `raw-hex-color` | `#FBF8F2` |
| `landing/500.html` | 42 | `raw-hex-color` | `#B58B2B` |
| `landing/api.html` | 12 | `raw-hex-color` | `#fbf8f2` |
| `landing/api.html` | 13 | `raw-hex-color` | `#16202b` |
| `landing/api.html` | 51 | `raw-hex-color` | `#f4ecde` |
| `landing/api.html` | 51 | `raw-hex-color` | `#efe7d8` |
| `landing/api.html` | 59 | `raw-functional-color` | `rgba(28,139,130,0.22)` |
| `landing/api.html` | 68 | `raw-functional-color` | `rgba(255,255,255,0.92)` |
| `landing/api.html` | 68 | `raw-functional-color` | `rgba(247,242,234,0.84)` |
| `landing/api.html` | 108 | `raw-functional-color` | `rgba(23,25,29,0.06)` |
| `landing/api.html` | 109 | `raw-hex-color` | `#fff9f0` |
| `landing/api.html` | 122 | `raw-functional-color` | `rgba(255,255,255,0.7)` |
| `landing/api.html` | 129 | `raw-hex-color` | `#fff` |
| `landing/api.html` | 142 | `raw-functional-color` | `rgba(23,25,29,0.08)` |
| `landing/api.html` | 157 | `raw-functional-color` | `rgba(17,94,87,0.18)` |
| `landing/api.html` | 166 | `raw-functional-color` | `rgba(28,139,130,0.18)` |
| `landing/api.html` | 191 | `raw-functional-color` | `rgba(23,25,29,0.15)` |
| `landing/api.html` | 209 | `raw-functional-color` | `rgba(23,25,29,0.05)` |
| `landing/api.html` | 228 | `raw-functional-color` | `rgba(23,25,29,0.04)` |
| `landing/api.html` | 231 | `raw-functional-color` | `rgba(28,139,130,0.08)` |
| `landing/api.html` | 313 | `raw-functional-color` | `rgba(23,25,29,0.4)` |
| `landing/api.html` | 329 | `raw-functional-color` | `rgba(255,255,255,0.55)` |
| `landing/api.html` | 350 | `raw-hex-color` | `#2557a7` |
| `landing/api.html` | 350 | `raw-functional-color` | `rgba(37,87,167,0.14)` |
| `landing/api.html` | 366 | `raw-functional-color` | `rgba(23,25,29,0.05)` |
| `landing/api.html` | 376 | `raw-functional-color` | `rgba(17,94,87,0.3)` |
| `landing/api.html` | 386 | `raw-functional-color` | `rgba(255,255,255,0.45)` |
| `landing/api.html` | 396 | `raw-functional-color` | `rgba(28,139,130,0.3)` |
| `landing/api.html` | 396 | `raw-functional-color` | `rgba(28,139,130,0.05)` |
| `landing/api.html` | 398 | `raw-functional-color` | `rgba(108,81,17,0.32)` |
| `landing/api.html` | 398 | `raw-functional-color` | `rgba(108,81,17,0.05)` |
| `landing/api.html` | 400 | `raw-functional-color` | `rgba(146,57,29,0.32)` |
| `landing/api.html` | 400 | `raw-functional-color` | `rgba(146,57,29,0.04)` |
| `landing/api.html` | 489 | `raw-functional-color` | `rgba(23,25,29,0.05)` |
| `landing/api.html` | 512 | `raw-functional-color` | `rgba(255,255,255,0.55)` |
| `landing/api.html` | 518 | `raw-functional-color` | `rgba(23,25,29,0.04)` |
| `landing/api.html` | 559 | `raw-functional-color` | `rgba(216,226,239,0.18)` |
| `landing/api.html` | 562 | `raw-hex-color` | `#15171a` |
| `landing/api.html` | 565 | `raw-functional-color` | `rgba(0,0,0,0.4)` |
| `landing/api.html` | 566 | `raw-functional-color` | `rgba(24,28,31,0.16)` |
| `landing/api.html` | 570 | `raw-functional-color` | `rgba(255,255,255,0.06)` |
| `landing/api.html` | 571 | `raw-functional-color` | `rgba(255,255,255,0.03)` |
| `landing/api.html` | 580 | `raw-functional-color` | `rgba(245,240,230,0.6)` |
| `landing/api.html` | 602 | `raw-functional-color` | `rgba(245,240,230,0.55)` |
| `landing/api.html` | 607 | `raw-hex-color` | `#fbf8f2` |
| `landing/api.html` | 609 | `raw-functional-color` | `rgba(255,255,255,0.10)` |
| `landing/api.html` | 610 | `raw-hex-color` | `#fbf8f2` |
| `landing/api.html` | 615 | `raw-functional-color` | `rgba(245,240,230,0.55)` |
| `landing/api.html` | 625 | `raw-hex-color` | `#fbf8f2` |
| `landing/api.html` | 625 | `raw-functional-color` | `rgba(255,255,255,0.06)` |
| `landing/api.html` | 631 | `raw-hex-color` | `#e6e0d3` |
| `landing/api.html` | 644 | `raw-hex-color` | `#5fd3ca` |
| `landing/api.html` | 645 | `raw-hex-color` | `#d2b362` |
| `landing/api.html` | 646 | `raw-hex-color` | `#ffaf85` |
| `landing/api.html` | 647 | `raw-hex-color` | `#9bbcd9` |
| `landing/api.html` | 648 | `raw-hex-color` | `#d2b362` |
| `landing/api.html` | 649 | `raw-hex-color` | `#ff936b` |
| `landing/api.html` | 650 | `raw-hex-color` | `#ff936b` |
| `landing/api.html` | 651 | `raw-functional-color` | `rgba(245,240,230,0.4)` |
| `landing/api.html` | 658 | `raw-functional-color` | `rgba(245,240,230,0.6)` |
| `landing/api.html` | 662 | `raw-functional-color` | `rgba(255,255,255,0.06)` |
| `landing/api.html` | 716 | `raw-hex-color` | `#FBF8F2` |
| `landing/api.html` | 717 | `raw-hex-color` | `#FBF8F2` |
| `landing/api.html` | 718 | `raw-hex-color` | `#B58B2B` |
| `landing/api.html` | 1321 | `raw-functional-color` | `rgba(23,25,29,0.04)` |
| `landing/auth.html` | 11 | `raw-hex-color` | `#efe9dc` |
| `landing/auth.html` | 20 | `raw-functional-color` | `rgba(28,139,130,0.14)` |
| `landing/auth.html` | 21 | `raw-functional-color` | `rgba(203,90,46,0.10)` |
| `landing/auth.html` | 22 | `raw-hex-color` | `#efe9dc` |
| `landing/auth.html` | 22 | `raw-hex-color` | `#f6f2ea` |
| `landing/auth.html` | 22 | `raw-hex-color` | `#efe7da` |
| `landing/auth.html` | 47 | `raw-functional-color` | `rgba(28,139,130,0.22)` |

## Interpretation

- Default gate fails when core files contain raw values or when total legacy debt exceeds the checked-in baseline.
- `--strict` fails on any finding and should become the release gate once dashboard/landing migration is complete.
- `--update-baseline` is an intentional governance action; include a migration note when using it.
```

