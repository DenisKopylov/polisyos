# Atlas token contract

## Stable consumption API

Stable product code should consume tokens in this order:

1. `--atlas-*` component tokens for shared primitives.
2. Semantic tokens such as `--text`, `--muted`, `--success`, `--danger`, `--chart-primary`, `--color-confidence-high`.
3. Primitive tokens only when a new semantic/component token has not been accepted yet.

## Naming rules

- Primitive variables keep short legacy-compatible names where they already exist: `--paper`, `--ink`, `--teal`, `--space-4`.
- Component variables are prefixed with `--atlas-`: `--atlas-button-primary-bg`, `--atlas-panel-border`.
- RGB channel variables end in `-rgb` and are used only for alpha composition: `rgba(var(--ink-rgb), 0.08)`.
- Mode files override exported CSS variables; they do not create separate component implementations.

## Mode contract

| Mode | Trigger | Purpose |
|---|---|---|
| Dark | `[data-theme="dark"]` | Low-light operator work |
| High contrast | `[data-theme="high-contrast"]`, `[data-contrast="more"]` | Manual accessibility mode |
| More contrast | `@media (prefers-contrast: more)` | User OS/browser preference |
| Reduced transparency | `@media (prefers-reduced-transparency: reduce)` | Removes glass/frosted surfaces |
| Comfortable density | `[data-density="comfortable"]` | Default touch/mouse balance |
| Compact density | `[data-density="compact"]` | Denser desktop workflows while preserving 36px compact targets |
| Condensed density | `[data-density="condensed"]` | Experimental data-dense mode; requires accessibility review before product release |

## Change control

Token changes require a note in `TOKEN_PIPELINE_DELTA.md` and a regenerated manifest. Breaking changes include removing a CSS variable, changing a component token's intended role, or changing a mode selector.
