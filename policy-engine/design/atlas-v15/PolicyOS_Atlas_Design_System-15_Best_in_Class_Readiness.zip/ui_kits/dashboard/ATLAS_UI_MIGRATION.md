# Dashboard prototype to Atlas UI migration

The dashboard kit remains a static prototype surface. The canonical component library now lives in `packages/atlas-ui`.

## Canonical replacements

| Prototype primitive | Library replacement |
|---|---|
| `Components.jsx` Button | `@policyos/atlas-ui` Button |
| `Components.jsx` Badge | `@policyos/atlas-ui` Badge |
| `Components.jsx` Panel | `@policyos/atlas-ui` Panel |
| `InteractiveCard` bridge | `@policyos/atlas-ui` InteractiveCard |
| metric tiles | `@policyos/atlas-ui` MetricCard |
| gate rows | `@policyos/atlas-ui` GovernanceGate |
| evidence cards | `@policyos/atlas-ui` EvidenceSourceCard |

## Rule

New product code should not add primitives to the prototype kit. Add or extend library components with stories, tests, docs, token use and registry maturity instead.
