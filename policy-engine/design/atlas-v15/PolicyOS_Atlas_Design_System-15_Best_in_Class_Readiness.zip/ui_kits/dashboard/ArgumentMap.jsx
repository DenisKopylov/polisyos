// ArgumentMap.jsx — E1
// Toulmin argument structure: Claim → Grounds → Warrant → Backing → Rebuttal → Qualifier
// Exports: ArgumentMapScreen

const ARGUMENTS = [
  {
    id:'ARG-001',
    claim:{ text:'Fiscal Reform Policy reduces poverty rate by 4.3pp', confidence:0.79, status:'supported' },
    grounds:[
      { id:'G1', text:'ATE estimate: β = −0.043 (95% CI −0.067 to −0.019)', strength:'strong', source:'Fiscal Reform Model v3.4' },
      { id:'G2', text:'Back-door adjustment on {prior_trend, gdp_growth} eliminates confounding', strength:'strong', source:'Causal Atlas A1' },
      { id:'G3', text:'Employment rate increased 0.41pp concurrently (mediator pathway confirmed)', strength:'moderate', source:'Employment Registry data' },
    ],
    warrant:{ text:'If a policy intervention causes the identified causal pathway to operate, and confounders are blocked, then the ATE is an unbiased estimator of the policy effect.', type:'causal' },
    backing:{ text:'Pearl (2009) do-calculus; Hernán & Robins (2020) Chapter 3; Imbens & Rubin (2015) potential outcomes framework.', sources:3 },
    rebuttal:{ text:'Unless unmeasured confounders exist with association > E-value 3.8 with both exposure and outcome simultaneously.', evalue:3.8, mitigated:false },
    qualifier:{ text:'Probably true under current identification assumptions', level:'probable' },
  },
  {
    id:'ARG-002',
    claim:{ text:'Policy effect is equitable across income quartiles', confidence:0.41, status:'challenged' },
    grounds:[
      { id:'G1', text:'Approval rate Q1: 34.1% vs Q4: 59.3% — a 25.2pp gap', strength:'strong', source:'Fairness Audit C3' },
      { id:'G2', text:'Disparate impact ratio 0.76 below regulatory threshold of 0.80', strength:'strong', source:'Fairness Audit C3' },
    ],
    warrant:{ text:'If approval rates differ substantially across protected groups, the policy is not distributionally equitable by the 4/5ths rule.', type:'normative' },
    backing:{ text:'EEOC Uniform Guidelines (1978); EU AI Act Art. 10; Feldman et al. (2015) disparate impact removal.', sources:3 },
    rebuttal:{ text:'Income quartile differences may reflect legitimate eligibility criteria, not discriminatory proxies. Feature recalibration applied (DSP-2024-041).', evalue:null, mitigated:true },
    qualifier:{ text:'Contested — under active review', level:'contested' },
  },
  {
    id:'ARG-003',
    claim:{ text:'Model confidence is reliable for decision-making', confidence:0.71, status:'partial' },
    grounds:[
      { id:'G1', text:'Mean confidence 0.791 under standard dataset; calibration AUC 0.841', strength:'strong', source:'Stress-Test Theatre A5' },
      { id:'G2', text:'Under adversarial perturbation, mean confidence drops to 0.549', strength:'strong', source:'Stress-Test Theatre A5 Act III' },
      { id:'G3', text:'p10 confidence 0.181 under adversarial conditions — extreme uncertainty tail', strength:'moderate', source:'A5 Scene 3b' },
    ],
    warrant:{ text:'If confidence is well-calibrated under expected conditions but degrades under adversarial inputs, then it is conditionally reliable.', type:'empirical' },
    backing:{ text:'Guo et al. (2017) calibration; DeGroot & Fienberg (1983) proper scoring rules; NIST AI RMF 2.0.', sources:3 },
    rebuttal:{ text:'Calibration evaluated on in-distribution data only. OOD calibration not formally tested.', evalue:null, mitigated:false },
    qualifier:{ text:'Conditionally reliable — with caveats', level:'conditional' },
  },
];

const QUAL_CFG = {
  probable:    { color:'var(--teal)', bg:'rgba(var(--teal-rgb), 0.11)',   label:'Probably true'          },
  contested:   { color:'var(--ember)', bg:'rgba(var(--ember-rgb), 0.11)',  label:'Contested'              },
  conditional: { color:'var(--gold-vibrant)', bg:'rgba(var(--gold-vibrant-rgb), 0.11)', label:'Conditionally reliable' },
};

const STATUS_CFG = {
  supported: { color:'var(--teal)', badge:'ok',      label:'Supported'  },
  challenged: { color:'var(--ember)', badge:'fail',   label:'Challenged' },
  partial:    { color:'var(--gold-vibrant)', badge:'warn',   label:'Partial'    },
};

const WARRANT_ICON = { causal:'⟿', normative:'⚖', empirical:'◆' };

const STRENGTH_CFG = {
  strong:   { color:'var(--teal)', w:3 },
  moderate: { color:'var(--gold-vibrant)', w:2 },
  weak:     { color:'var(--ember)', w:1 },
};

function ConfidenceArc({ value, size=60 }) {
  const r = size/2 - 6, cx = size/2, cy = size/2;
  const angle = value * 270; // 0-270 degrees sweep
  const startAngle = 135; // start bottom-left
  function pt(deg) {
    const rad = deg * Math.PI / 180;
    return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) };
  }
  const s = pt(startAngle);
  const endDeg = startAngle + angle;
  const e = pt(endDeg);
  const large = angle > 180 ? 1 : 0;
  const color = value >= 0.7 ? 'var(--teal)' : value >= 0.5 ? 'var(--gold-vibrant)' : 'var(--ember)';
  return (
    <svg width={size} height={size} style={{ display:'block' }}>
      <path d={`M ${pt(135).x} ${pt(135).y} A ${r} ${r} 0 1 1 ${pt(135+270).x} ${pt(135+270).y}`}
        fill="none" stroke="rgba(var(--ink-rgb), 0.1)" strokeWidth={5} strokeLinecap="round" />
      {angle > 0 && (
        <path d={`M ${s.x} ${s.y} A ${r} ${r} 0 ${large} 1 ${e.x} ${e.y}`}
          fill="none" stroke={color} strokeWidth={5} strokeLinecap="round" />
      )}
      <text x={cx} y={cy+5} textAnchor="middle" fontSize={12} fontWeight={800}
        fontFamily='"Manrope",sans-serif' fill={color}>{(value*100).toFixed(0)}</text>
    </svg>
  );
}

function ToulminCard({ arg, selected, onSelect }) {
  const isSel = selected === arg.id;
  const qcfg  = QUAL_CFG[arg.qualifier.level];
  const scfg  = STATUS_CFG[arg.claim.status];

  return (
    <InteractiveCard
      onClick={() => onSelect(isSel ? null : arg.id)}
      selected={isSel}
      ariaLabel={`Toggle argument ${arg.id}. ${arg.claim.text}. Status ${scfg.label}.`}
      style={{
        borderRadius:20, overflow:'hidden', cursor:'pointer',
        border:`1.5px solid ${isSel ? scfg.color : 'rgba(var(--ink-rgb), 0.08)'}`,
        background:'rgba(var(--white-rgb), 0.6)',
        boxShadow: isSel ? `0 0 0 2px ${scfg.color}30` : 'none',
        transition:'all 160ms',
      }}>

      {/* Claim header */}
      <div style={{ padding:'14px 16px', background: isSel ? scfg.color+'18' : 'rgba(var(--white-rgb), 0.4)',
        borderBottom:'1px solid rgba(var(--ink-rgb), 0.07)' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', gap:10 }}>
          <div style={{ flex:1 }}>
            <div style={{ display:'flex', gap:7, alignItems:'center', marginBottom:5 }}>
              <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, fontWeight:700, color:'rgba(var(--slate-rgb), 0.6)', letterSpacing:'0.08em' }}>CLAIM · {arg.id}</span>
              <Badge kind={scfg.badge}>{scfg.label}</Badge>
            </div>
            <p style={{ margin:0, fontSize:14, fontWeight:800, color:'var(--ink)', lineHeight:1.4, letterSpacing:'-0.02em' }}>{arg.claim.text}</p>
          </div>
          <ConfidenceArc value={arg.claim.confidence} size={56} />
        </div>
      </div>

      {/* Grounds */}
      <div style={{ padding:'12px 16px', borderBottom:'1px solid rgba(var(--ink-rgb), 0.06)' }}>
        <div style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.5)', letterSpacing:'0.1em', marginBottom:8 }}>GROUNDS</div>
        {arg.grounds.map(g => {
          const sc = STRENGTH_CFG[g.strength];
          return (
            <div key={g.id} style={{ display:'flex', gap:8, marginBottom:6, alignItems:'flex-start' }}>
              <div style={{ width:sc.w*2, height:sc.w*2, borderRadius:'50%', background:sc.color, flexShrink:0, marginTop:5 }} />
              <div>
                <p style={{ margin:0, fontSize:12, color:'var(--ink)', lineHeight:1.45 }}>{g.text}</p>
                <span style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.5)' }}>{g.source}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Warrant + Qualifier row */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', borderBottom:'1px solid rgba(var(--ink-rgb), 0.06)' }}>
        <div style={{ padding:'10px 14px', borderRight:'1px solid rgba(var(--ink-rgb), 0.06)' }}>
          <div style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.5)', letterSpacing:'0.1em', marginBottom:5 }}>
            {WARRANT_ICON[arg.warrant.type]} WARRANT ({arg.warrant.type})
          </div>
          <p style={{ margin:0, fontSize:11, color:'var(--slate)', lineHeight:1.5 }}>{arg.warrant.text}</p>
        </div>
        <div style={{ padding:'10px 14px' }}>
          <div style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.5)', letterSpacing:'0.1em', marginBottom:5 }}>QUALIFIER</div>
          <div style={{ display:'inline-flex', alignItems:'center', gap:6, padding:'4px 10px', borderRadius:999, background:qcfg.bg }}>
            <div style={{ width:6, height:6, borderRadius:'50%', background:qcfg.color }} />
            <span style={{ fontSize:11, fontWeight:700, color:qcfg.color }}>{qcfg.label}</span>
          </div>
        </div>
      </div>

      {/* Rebuttal */}
      <div style={{ padding:'10px 14px', background: arg.rebuttal.mitigated ? 'rgba(var(--teal-rgb), 0.05)' : 'rgba(var(--ember-rgb), 0.05)',
        borderBottom:'1px solid rgba(var(--ink-rgb), 0.06)' }}>
        <div style={{ display:'flex', gap:8, alignItems:'flex-start' }}>
          <span style={{ fontSize:12, color: arg.rebuttal.mitigated ? 'var(--teal)':'var(--ember)', flexShrink:0 }}>
            {arg.rebuttal.mitigated ? '✓':'⚠'}
          </span>
          <div>
            <div style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.5)', letterSpacing:'0.1em', marginBottom:3 }}>
              REBUTTAL {arg.rebuttal.mitigated ? '(MITIGATED)':'(OPEN)'}
            </div>
            <p style={{ margin:0, fontSize:11, color: arg.rebuttal.mitigated ? 'var(--teal)':'var(--ember)', lineHeight:1.5 }}>{arg.rebuttal.text}</p>
            {arg.rebuttal.evalue && (
              <div style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, color:'rgba(var(--slate-rgb), 0.6)', marginTop:3 }}>
                E-value threshold: {arg.rebuttal.evalue}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Backing */}
      <div style={{ padding:'9px 14px' }}>
        <div style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.5)', letterSpacing:'0.1em', marginBottom:4 }}>BACKING ({arg.backing.sources} sources)</div>
        <p style={{ margin:0, fontSize:11, color:'rgba(var(--slate-rgb), 0.7)', lineHeight:1.5, fontStyle:'italic' }}>{arg.backing.text}</p>
      </div>
    </InteractiveCard>
  );
}

function ArgumentMapScreen() {
  const [selected, setSelected] = React.useState(null);
  const [filter,   setFilter]   = React.useState('all');

  const visible = filter === 'all' ? ARGUMENTS : ARGUMENTS.filter(a => a.claim.status === filter);

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:14, height:'100%' }}>

      <div style={{ display:'flex', alignItems:'center', gap:10 }}>
        <Eyebrow>E1 · Argument Map (Toulmin)</Eyebrow>
        <div style={{ flex:1 }} />
        {['all','supported','partial','challenged'].map(f => {
          const cfg = f !== 'all' ? STATUS_CFG[f] : null;
          return (
            <button type="button" key={f} onClick={() => setFilter(f)}
              style={{ padding:'4px 11px', borderRadius:999, border:'none', cursor:'pointer',
                fontFamily:'"IBM Plex Mono",monospace', fontSize:9, fontWeight:700, letterSpacing:'0.06em',
                background: filter===f ? (cfg ? cfg.color+'1a':'rgba(var(--ink-rgb), 0.09)') : 'rgba(var(--white-rgb), 0.65)',
                color: filter===f ? (cfg?.color||'var(--ink)') : 'rgba(var(--slate-rgb), 0.65)',
                boxShadow: filter===f ? `0 0 0 1px ${cfg?.color||'rgba(var(--ink-rgb), 0.18)'}` : '0 0 0 1px rgba(var(--ink-rgb), 0.08)' }}>
              {f.toUpperCase()}
            </button>
          );
        })}
      </div>

      <div style={{ flex:1, overflowY:'auto', display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(440px,1fr))', gap:16, alignContent:'start' }}>
        {visible.map(arg => (
          <ToulminCard key={arg.id} arg={arg} selected={selected} onSelect={setSelected} />
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { ArgumentMapScreen });
