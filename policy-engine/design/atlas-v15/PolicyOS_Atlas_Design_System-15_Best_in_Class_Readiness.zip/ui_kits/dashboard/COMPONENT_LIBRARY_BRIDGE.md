# Dashboard prototype bridge

The dashboard kit is still included for visual exploration and static demos. Its global `Components.jsx` primitives are now considered a compatibility shim.

Production code should import from:

```tsx
import { Button, Badge, Panel, MetricCard, RunCard } from '@policyos/atlas-ui';
```

Bridge rules:

- Do not add new global primitives to `Components.jsx`.
- New product screens must use `packages/atlas-ui` components.
- Existing dashboard screens can migrate incrementally.
- Any behavior bug fixed in the shim should also be reflected in `packages/atlas-ui` or documented as prototype-only.
