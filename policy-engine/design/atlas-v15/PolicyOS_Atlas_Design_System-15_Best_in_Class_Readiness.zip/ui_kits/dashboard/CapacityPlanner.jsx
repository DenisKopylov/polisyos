// CapacityPlanner.jsx — D4
// Resource allocation, cost projection, what-if scenario sliders
// Exports: CapacityPlannerScreen

const BASE_CONFIG = {
  workers: 8,
  batchSize: 500,
  memoryGb: 1.5,
  timeoutS: 30,
  parallelWaves: 2,
};

const COST_PER = {
  workerHour: 0.048,   // $ per worker-hour
  memoryGbHour: 0.006, // $ per GB-hour
  storageGb: 0.023,    // $ per GB-month
};

function calcMetrics(cfg) {
  const { workers, batchSize, memoryGb, timeoutS, parallelWaves } = cfg;
  const totalRecords = 42180;
  const baseLatencyMs = 148;

  // Throughput: more workers + larger batch → more throughput, but diminishing returns
  const effectiveThroughput = Math.min(workers * 85 * (batchSize / 500) * 0.9, 3200);
  const runtimeMin = (totalRecords / effectiveThroughput / 60) / parallelWaves;
  const p99LatencyMs = baseLatencyMs * (500 / batchSize) * (1.5 / memoryGb) * 1.2;
  const oomRisk = memoryGb < 1.8 ? (1.8 - memoryGb) / 0.8 : 0;
  const timeoutRisk = timeoutS < p99LatencyMs / 1000 ? 1 - timeoutS / (p99LatencyMs / 1000) : 0;

  const workerCost = workers * (runtimeMin / 60) * COST_PER.workerHour;
  const memoryCost = workers * memoryGb * (runtimeMin / 60) * COST_PER.memoryGbHour;
  const totalCost  = workerCost + memoryCost + 0.12; // 0.12 fixed overhead

  return { effectiveThroughput, runtimeMin, p99LatencyMs, oomRisk, timeoutRisk, totalCost, workerCost, memoryCost };
}

const SCENARIOS = [
  { id:'current',   label:'Current',      cfg:{ workers:8,  batchSize:500, memoryGb:1.5, timeoutS:30, parallelWaves:2 } },
  { id:'optimised', label:'Optimised',    cfg:{ workers:12, batchSize:300, memoryGb:2.5, timeoutS:45, parallelWaves:3 } },
  { id:'minimal',   label:'Min cost',     cfg:{ workers:4,  batchSize:800, memoryGb:1.5, timeoutS:30, parallelWaves:1 } },
  { id:'maxspeed',  label:'Max speed',    cfg:{ workers:24, batchSize:200, memoryGb:4.0, timeoutS:60, parallelWaves:4 } },
];

function RiskBar({ value, label }) {
  const color = value < 0.2 ? 'var(--teal)' : value < 0.5 ? 'var(--gold-vibrant)' : 'var(--ember)';
  return (
    <div style={{ marginBottom:10 }}>
      <div style={{ display:'flex', justifyContent:'space-between', marginBottom:4 }}>
        <span style={{ fontSize:11, color:'var(--slate)' }}>{label}</span>
        <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, fontWeight:700, color }}>
          {(value * 100).toFixed(0)}%
        </span>
      </div>
      <div style={{ height:6, borderRadius:999, background:'rgba(var(--ink-rgb), 0.08)', overflow:'hidden' }}>
        <div style={{ height:'100%', borderRadius:999, background:color, width:`${(value*100).toFixed(0)}%`, transition:'width 300ms' }} />
      </div>
    </div>
  );
}

function SliderRow({ label, value, min, max, step, unit, onChange, formatVal }) {
  return (
    <div style={{ marginBottom:14 }}>
      <div style={{ display:'flex', justifyContent:'space-between', marginBottom:5 }}>
        <span style={{ fontSize:12, color:'var(--ink)', fontWeight:600 }}>{label}</span>
        <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:12, fontWeight:700, color:'var(--teal)' }}>
          {formatVal ? formatVal(value) : `${value}${unit}`}
        </span>
      </div>
      <input type="range" min={min} max={max} step={step} value={value}
        onChange={e => onChange(Number(e.target.value))}
        style={{ width:'100%', accentColor:'var(--teal-vibrant)' }} />
      <div style={{ display:'flex', justifyContent:'space-between', marginTop:2 }}>
        <span style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.4)' }}>{min}{unit}</span>
        <span style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.4)' }}>{max}{unit}</span>
      </div>
    </div>
  );
}

function CapacityPlannerScreen() {
  const [cfg, setCfg] = React.useState({ ...BASE_CONFIG });
  const [compareScenario, setCompare] = React.useState(null);

  const m = React.useMemo(() => calcMetrics(cfg), [cfg]);
  const compareM = React.useMemo(() => compareScenario ? calcMetrics(SCENARIOS.find(s=>s.id===compareScenario).cfg) : null, [compareScenario]);

  function set(key) { return val => setCfg(c => ({ ...c, [key]: val })); }
  function applyScenario(id) {
    const sc = SCENARIOS.find(s => s.id === id);
    if (sc) setCfg({ ...sc.cfg });
  }

  function delta(val, ref, lowerBetter) {
    const d = val - ref;
    const color = d === 0 ? 'var(--slate)' : (d < 0) === lowerBetter ? 'var(--teal)' : 'var(--ember)';
    const sign = d > 0 ? '+' : '';
    return <span style={{ color, fontFamily:'"IBM Plex Mono",monospace', fontSize:10, fontWeight:700, marginLeft:6 }}>{sign}{typeof val === 'number' && val < 100 ? d.toFixed(1) : Math.round(d)}</span>;
  }

  return (
    <div style={{ display:'flex', gap:20, height:'100%' }}>

      {/* Config panel */}
      <Panel style={{ width:280, flexShrink:0 }}>
        <PanelHeader eyebrow="D4 · Capacity Planner" title="Configuration" />

        <Eyebrow style={{ marginBottom:10 }}>Preset scenarios</Eyebrow>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:6, marginBottom:18 }}>
          {SCENARIOS.map(sc => (
            <button type="button" key={sc.id} onClick={() => applyScenario(sc.id)}
              style={{ padding:'6px 8px', borderRadius:10, border:'1px solid rgba(var(--ink-rgb), 0.1)',
                background:'rgba(var(--white-rgb), 0.65)', cursor:'pointer',
                fontFamily:'Manrope,sans-serif', fontSize:11, fontWeight:600, color:'var(--ink)',
                transition:'all 130ms' }}>
              {sc.label}
            </button>
          ))}
        </div>

        <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', marginBottom:18 }} />

        <SliderRow label="Workers" value={cfg.workers} min={2} max={32} step={2} unit="" onChange={set('workers')} />
        <SliderRow label="Batch size" value={cfg.batchSize} min={50} max={2000} step={50} unit=" rec" onChange={set('batchSize')} />
        <SliderRow label="Memory / worker" value={cfg.memoryGb} min={0.5} max={8} step={0.5} unit=" GB" onChange={set('memoryGb')}
          formatVal={v => `${v.toFixed(1)} GB`} />
        <SliderRow label="Timeout" value={cfg.timeoutS} min={10} max={120} step={5} unit="s" onChange={set('timeoutS')} />
        <SliderRow label="Parallel waves" value={cfg.parallelWaves} min={1} max={6} step={1} unit="" onChange={set('parallelWaves')} />

        <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', margin:'4px 0 14px' }} />
        <Eyebrow style={{ marginBottom:8 }}>Compare against</Eyebrow>
        <select value={compareScenario || ''} onChange={e => setCompare(e.target.value || null)}
          style={{ width:'100%', padding:'7px 10px', borderRadius:10, border:'1px solid rgba(var(--ink-rgb), 0.1)',
            fontFamily:'Manrope,sans-serif', fontSize:12, background:'rgba(var(--white-rgb), 0.7)', color:'var(--ink)' }}>
          <option value="">— none —</option>
          {SCENARIOS.map(sc => <option key={sc.id} value={sc.id}>{sc.label}</option>)}
        </select>
      </Panel>

      {/* Metrics + projection */}
      <div style={{ flex:1, minWidth:0, display:'flex', flexDirection:'column', gap:14 }}>

        {/* Headline metrics */}
        <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12 }}>
          {[
            { label:'Runtime',     val:m.runtimeMin.toFixed(1), unit:'min', ref:compareM?.runtimeMin, lower:true  },
            { label:'Throughput',  val:Math.round(m.effectiveThroughput), unit:'rec/s', ref:compareM?.effectiveThroughput, lower:false },
            { label:'p99 latency', val:Math.round(m.p99LatencyMs), unit:'ms', ref:compareM?.p99LatencyMs, lower:true  },
            { label:'Total cost',  val:`$${m.totalCost.toFixed(2)}`, unit:'', ref:compareM?.totalCost, lower:true   },
          ].map(card => (
            <div key={card.label} style={{ padding:'14px 16px', borderRadius:18,
              background:'rgba(var(--white-rgb), 0.6)', border:'1px solid rgba(var(--ink-rgb), 0.08)' }}>
              <div style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.65)', letterSpacing:'0.1em', marginBottom:6 }}>{card.label.toUpperCase()}</div>
              <div style={{ display:'flex', alignItems:'baseline', gap:0 }}>
                <span style={{ fontSize:24, fontWeight:800, letterSpacing:'-0.04em', color:'var(--ink)' }}>{card.val}</span>
                <span style={{ fontSize:11, color:'rgba(var(--slate-rgb), 0.6)', marginLeft:3 }}>{card.unit}</span>
              </div>
              {compareM && card.ref !== undefined && (
                <div style={{ marginTop:4, fontSize:10, color:'rgba(var(--slate-rgb), 0.6)' }}>
                  vs {typeof card.ref === 'number' && card.ref < 10 ? card.ref.toFixed(2) : Math.round(card.ref)}{card.unit}
                  {delta(typeof card.val === 'string' ? m.totalCost : parseFloat(card.val), card.ref, card.lower)}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Risk panel */}
        <Panel>
          <PanelHeader eyebrow="Risk indicators" title="Configuration risks" />
          <RiskBar value={m.oomRisk} label="OOM risk (memory below safe threshold)" />
          <RiskBar value={m.timeoutRisk} label="Timeout risk (p99 > timeout setting)" />
          <RiskBar value={Math.min(cfg.batchSize / 2000, 1) * 0.4} label="Batch contention risk (large batch size)" />

          {m.oomRisk > 0.5 && (
            <div style={{ marginTop:10, padding:'9px 12px', borderRadius:11,
              background:'rgba(var(--ember-rgb), 0.08)', border:'1px solid rgba(var(--ember-rgb), 0.2)' }}>
              <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, fontWeight:700, color:'var(--ember)' }}>
                ⚠ Memory {cfg.memoryGb.toFixed(1)}GB may cause OOM — ERR-2024-0091 root cause. Recommend ≥ 2.0GB.
              </span>
            </div>
          )}
          {m.timeoutRisk > 0.3 && (
            <div style={{ marginTop:8, padding:'9px 12px', borderRadius:11,
              background:'rgba(var(--gold-vibrant-rgb), 0.08)', border:'1px solid rgba(var(--gold-vibrant-rgb), 0.2)' }}>
              <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, fontWeight:700, color:'var(--gold-vibrant)' }}>
                ⚠ Timeout {cfg.timeoutS}s may be breached at p99 {Math.round(m.p99LatencyMs)}ms. Consider increasing timeout.
              </span>
            </div>
          )}
        </Panel>

        {/* Cost breakdown */}
        <Panel style={{ flex:1 }}>
          <PanelHeader eyebrow="Cost projection" title={`$${m.totalCost.toFixed(2)} per run`} />
          {[
            { label:'Worker compute',  cost:m.workerCost,  color:'var(--teal)'  },
            { label:'Memory (all workers)', cost:m.memoryCost, color:'var(--chart-secondary)' },
            { label:'Fixed overhead',  cost:0.12,           color:'var(--slate)'  },
          ].map(row => (
            <div key={row.label} style={{ marginBottom:10 }}>
              <div style={{ display:'flex', justifyContent:'space-between', marginBottom:4 }}>
                <span style={{ fontSize:12, color:'var(--slate)' }}>{row.label}</span>
                <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:12, fontWeight:700, color:row.color }}>
                  ${row.cost.toFixed(3)}
                </span>
              </div>
              <div style={{ height:5, borderRadius:999, background:'rgba(var(--ink-rgb), 0.07)', overflow:'hidden' }}>
                <div style={{ height:'100%', borderRadius:999, background:row.color,
                  width:`${(row.cost/m.totalCost*100).toFixed(0)}%`, transition:'width 300ms' }} />
              </div>
            </div>
          ))}
          <div style={{ marginTop:10, padding:'9px 12px', borderRadius:11,
            background:'rgba(var(--teal-rgb), 0.07)', border:'1px solid rgba(var(--teal-rgb), 0.18)' }}>
            <span style={{ fontSize:11, color:'var(--teal)' }}>
              At this configuration: <strong>{Math.round(m.runtimeMin)}min runtime</strong> · <strong>{Math.round(m.effectiveThroughput)} rec/s</strong> · <strong>${(m.totalCost * 90).toFixed(0)}/quarter</strong> (quarterly estimate)
            </span>
          </div>
        </Panel>
      </div>
    </div>
  );
}

Object.assign(window, { CapacityPlannerScreen });
