// CausalAtlas.jsx — A1: Causal Atlas
// DAG-as-primary-interface: editable, identifiability-aware, adversarial-mode, bitemporal
// Exports: CausalAtlasScreen

// ─── Constants ───────────────────────────────────────────────────────────────
const NW = 142, NH = 58, NR = 12;

const NODE_CFG = {
  cause:      { label:'Cause',       fill:'rgba(var(--teal-rgb), 0.13)',  stroke:'rgba(var(--teal-rgb), 0.50)',   text:'var(--teal)' },
  mediator:   { label:'Mediator',    fill:'rgba(var(--gold-rgb), 0.12)', stroke:'rgba(var(--gold-rgb), 0.48)', text:'var(--gold)' },
  confounder: { label:'Confounder',  fill:'rgba(var(--slate-rgb), 0.09)',  stroke:'rgba(var(--slate-rgb), 0.36)',  text:'var(--slate)' },
  effect:     { label:'Effect',      fill:'rgba(var(--ember-rgb), 0.12)', stroke:'rgba(var(--ember-rgb), 0.48)', text:'var(--ember)' },
  instrument: { label:'Instrument',  fill:'rgba(var(--blue-rgb), 0.11)', stroke:'rgba(var(--blue-rgb), 0.42)', text:'var(--chart-secondary)' },
};

const ID_CFG = {
  backdoor:  { short:'BACK-DOOR',   label:'Back-door adjustment',      color:'var(--teal)', mkr:'am-teal' },
  frontdoor: { short:'FRONT-DOOR',  label:'Front-door criterion',      color:'var(--gold-vibrant)', mkr:'am-gold' },
  iv:        { short:'IV',          label:'Instrumental Variable',     color:'var(--chart-secondary)', mkr:'am-blue' },
  rdd:       { short:'RDD',         label:'Regression Discontinuity',  color:'var(--teal)', mkr:'am-teal' },
  did:       { short:'DiD',         label:'Difference-in-Differences', color:'var(--teal)', mkr:'am-teal' },
};

const ID_DESC = {
  backdoor:  'Condition on {prior_trend, gdp_growth} to close all back-door paths. E[Y|do(X)] = Σz P(Y|X,z)·P(z)',
  frontdoor: 'Effect flows through observed mediators; confounders need not be measured. E[Y|do(X)] = Σm P(m|x) Σx\' P(y|m,x\')P(x\')',
  iv:        'Exploit exogenous variation in Budget Cycle IV. Wald: β_IV = Cov(Y,Z)/Cov(X,Z) under exclusion restriction.',
  rdd:       'Compare outcomes at the threshold boundary. Local randomisation assumed near cutoff.',
  did:       'Parallel trends: ATT = Δ(treated) − Δ(control) across policy period.',
};

const VERSIONS = [
  { label:'v3.4 · 2024-Q3', ts:'valid_at 2024-09-30T00:00:00Z' },
  { label:'v3.3 · 2024-Q2', ts:'valid_at 2024-06-30T00:00:00Z' },
  { label:'v3.2 · 2024-Q1', ts:'valid_at 2024-03-31T00:00:00Z' },
];

// Each node has: line1, line2, type, x, y (top-left corner)
const INIT_NODES = [
  { id:'prior_trend', line1:'Pre-existing', line2:'Trends',     type:'confounder', x: 42,  y: 42  },
  { id:'gdp_growth',  line1:'GDP',          line2:'Growth',     type:'confounder', x: 42,  y: 196 },
  { id:'instrument',  line1:'Budget',       line2:'Cycle IV',   type:'instrument', x: 42,  y: 366 },
  { id:'policy',      line1:'Fiscal Reform',line2:'Policy',     type:'cause',      x:330,  y: 202 },
  { id:'employment',  line1:'Employment',   line2:'Rate',       type:'mediator',   x:572,  y: 96  },
  { id:'spending',    line1:'Consumer',     line2:'Spending',   type:'mediator',   x:572,  y: 300 },
  { id:'poverty',     line1:'Poverty',      line2:'Rate',       type:'effect',     x:822,  y: 165 },
  { id:'tax_rev',     line1:'Tax',          line2:'Revenue',    type:'effect',     x:822,  y: 355 },
];

const EDGES = [
  { id:'e1',  from:'prior_trend', to:'policy',     isBackdoor:true,  strategy:null        },
  { id:'e2',  from:'prior_trend', to:'poverty',    isBackdoor:true,  strategy:null        },
  { id:'e3',  from:'gdp_growth',  to:'policy',     isBackdoor:true,  strategy:null        },
  { id:'e4',  from:'gdp_growth',  to:'spending',   isBackdoor:true,  strategy:null        },
  { id:'e5',  from:'instrument',  to:'policy',     isBackdoor:false, strategy:'iv'        },
  { id:'e6',  from:'policy',      to:'employment', isBackdoor:false, strategy:'frontdoor' },
  { id:'e7',  from:'policy',      to:'spending',   isBackdoor:false, strategy:'frontdoor' },
  { id:'e8',  from:'policy',      to:'poverty',    isBackdoor:false, strategy:'backdoor'  },
  { id:'e9',  from:'policy',      to:'tax_rev',    isBackdoor:false, strategy:'backdoor'  },
  { id:'e10', from:'employment',  to:'poverty',    isBackdoor:false, strategy:'frontdoor' },
  { id:'e11', from:'spending',    to:'poverty',    isBackdoor:false, strategy:'frontdoor' },
  { id:'e12', from:'spending',    to:'tax_rev',    isBackdoor:false, strategy:'frontdoor' },
];

const BADGE_KINDS = { cause:'ok', effect:'fail', confounder:'neutral', mediator:'warn', instrument:'info' };

// ─── Geometry ────────────────────────────────────────────────────────────────
function center(n) { return { cx: n.x + NW / 2, cy: n.y + NH / 2 }; }

function borderPt(n, tx, ty) {
  const { cx, cy } = center(n);
  const dx = tx - cx, dy = ty - cy;
  if (Math.abs(dx) < 0.01 && Math.abs(dy) < 0.01) return { x: cx, y: cy };
  const hw = NW / 2 + 1.5, hh = NH / 2 + 1.5;
  if (Math.abs(dx) * hh >= Math.abs(dy) * hw) {
    const sx = dx > 0 ? hw : -hw;
    return { x: cx + sx, y: cy + dy * sx / dx };
  }
  const sy = dy > 0 ? hh : -hh;
  return { x: cx + dx * sy / dy, y: cy + sy };
}

function makePath(src, tgt) {
  const sc = center(src), tc = center(tgt);
  const p1 = borderPt(src, tc.cx, tc.cy);
  const p2 = borderPt(tgt, sc.cx, sc.cy);
  const mx = (p1.x + p2.x) / 2;
  return `M ${p1.x.toFixed(1)} ${p1.y.toFixed(1)} C ${mx.toFixed(1)} ${p1.y.toFixed(1)}, ${mx.toFixed(1)} ${p2.y.toFixed(1)}, ${p2.x.toFixed(1)} ${p2.y.toFixed(1)}`;
}

// ─── Component ───────────────────────────────────────────────────────────────
function CausalAtlasScreen() {
  const [nodes, setNodes]               = React.useState(INIT_NODES);
  const [adversarial, setAdversarial]   = React.useState(false);
  const [versionIdx, setVersionIdx]     = React.useState(0);
  const [hovEdge, setHovEdge]           = React.useState(null);  // { edge, svgX, svgY }
  const [selNodeId, setSelNodeId]       = React.useState(null);
  const [editMode, setEditMode]         = React.useState(false);
  const [addingEdge, setAddingEdge]     = React.useState(null); // nodeId of pending edge source

  const dragRef = React.useRef(null);
  const svgRef  = React.useRef(null);

  const nodeMap = React.useMemo(() => Object.fromEntries(nodes.map(n => [n.id, n])), [nodes]);
  const selNode  = selNodeId ? nodeMap[selNodeId] : null;
  const selEdges = selNodeId ? EDGES.filter(e => e.from === selNodeId || e.to === selNodeId) : [];

  const VBW = 1020, VBH = 492;

  // ─ Pointer → SVG coordinate
  function toSVG(clientX, clientY) {
    if (!svgRef.current) return { x: 0, y: 0 };
    const r = svgRef.current.getBoundingClientRect();
    return {
      x: (clientX - r.left) / r.width  * VBW,
      y: (clientY - r.top)  / r.height * VBH,
    };
  }

  // ─ Drag
  function onNodePointerDown(e, nodeId) {
    e.stopPropagation();
    const { x, y } = toSVG(e.clientX, e.clientY);
    const n = nodeMap[nodeId];
    dragRef.current = { nodeId, startX: x, startY: y, origX: n.x, origY: n.y };
  }

  function onSVGPointerMove(e) {
    if (!dragRef.current) return;
    const { nodeId, startX, startY, origX, origY } = dragRef.current;
    const { x, y } = toSVG(e.clientX, e.clientY);
    setNodes(prev => prev.map(n =>
      n.id === nodeId ? { ...n, x: Math.max(0, origX + x - startX), y: Math.max(0, origY + y - startY) } : n
    ));
  }

  function onSVGPointerUp() { dragRef.current = null; }

  // ─ Edge hover
  function onEdgeEnter(e, edge) {
    const { x, y } = toSVG(e.clientX, e.clientY);
    setHovEdge({ edge, svgX: x, svgY: y });
  }
  function onEdgeMove(e) {
    if (!hovEdge) return;
    const { x, y } = toSVG(e.clientX, e.clientY);
    setHovEdge(prev => prev ? { ...prev, svgX: x, svgY: y } : null);
  }
  function onEdgeLeave() { setHovEdge(null); }

  // ─ Edge visual
  function edgeStroke(edge) {
    if (adversarial && edge.isBackdoor) return 'var(--ember-vibrant)';
    if (edge.isBackdoor) return 'rgba(var(--slate-rgb), 0.28)';
    return ID_CFG[edge.strategy]?.color || 'rgba(var(--slate-rgb), 0.4)';
  }
  function edgeOpacity(edge) {
    if (adversarial) return edge.isBackdoor ? 1 : 0.32;
    return hovEdge?.edge.id === edge.id ? 1 : 0.62;
  }
  function edgeMarker(edge) {
    if (adversarial && edge.isBackdoor) return 'url(#am-ember)';
    if (edge.isBackdoor) return 'url(#am-slate)';
    return `url(#${ID_CFG[edge.strategy]?.mkr || 'am-slate'})`;
  }

  const backdoorCount = EDGES.filter(e => e.isBackdoor).length;

  return (
    <div style={{ display:'flex', gap:20, height:'100%', minHeight:560 }}>

      {/* ── Canvas column ─────────────────────────────────────── */}
      <div style={{ flex:1, minWidth:0, display:'flex', flexDirection:'column', gap:12 }}>

        {/* Toolbar */}
        <div style={{ display:'flex', alignItems:'center', gap:8, flexWrap:'wrap' }}>
          <Eyebrow>A1 · Causal Atlas</Eyebrow>
          <span style={{ width:1, height:14, background:'rgba(var(--ink-rgb), 0.12)', display:'inline-block', margin:'0 2px' }} />
          <span style={{ fontSize:11, color:'rgba(var(--ink-rgb), 0.42)', fontFamily:'"IBM Plex Mono",monospace' }}>
            Fiscal Reform Evaluation · {nodes.length} nodes · {EDGES.length} edges
          </span>
          <div style={{ flex:1 }} />

          {/* Bitemporal cursor */}
          <div style={{ display:'flex', alignItems:'center', gap:5, padding:'4px 10px 4px 10px', borderRadius:999, border:'1px solid rgba(var(--ink-rgb), 0.1)', background:'rgba(var(--white-rgb), 0.65)' }}>
            <span style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.8)', letterSpacing:'0.1em', textTransform:'uppercase' }}>valid_at</span>
            <select
              value={versionIdx}
              onChange={e => setVersionIdx(Number(e.target.value))}
              style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, border:'none', background:'transparent', color:'var(--teal)', fontWeight:700, cursor:'pointer', outline:'none' }}
            >
              {VERSIONS.map((v, i) => <option key={i} value={i}>{v.label}</option>)}
            </select>
          </div>

          {/* Adversarial toggle */}
          <button type="button"
            onClick={() => setAdversarial(a => !a)}
            style={{
              display:'flex', alignItems:'center', gap:7,
              padding:'6px 13px', borderRadius:999, border:'none', cursor:'pointer',
              fontFamily:'"IBM Plex Mono",monospace', fontSize:10, fontWeight:700, letterSpacing:'0.07em',
              background: adversarial ? 'rgba(var(--ember-rgb), 0.13)' : 'rgba(var(--white-rgb), 0.65)',
              color: adversarial ? 'var(--ember)' : 'rgba(var(--slate-rgb), 0.8)',
              boxShadow: adversarial ? '0 0 0 1px rgba(var(--ember-rgb), 0.38)' : '0 0 0 1px rgba(var(--ink-rgb), 0.1)',
              transition:'all 160ms',
            }}
          >
            <span style={{ width:6, height:6, borderRadius:'50%', flexShrink:0, background: adversarial ? 'var(--ember-vibrant)' : 'currentColor', transition:'background 160ms' }} />
            ADVERSARIAL
          </button>

          {/* Edit DAG */}
          <Button variant={editMode ? 'primary' : 'ghost'} size="sm" onClick={() => setEditMode(m => !m)}>
            {editMode ? '✓ Done' : 'Edit DAG'}
          </Button>
        </div>

        {/* SVG canvas */}
        <Panel style={{ padding:0, overflow:'hidden', flex:1, position:'relative', minHeight:400 }}>
          <svg
            ref={svgRef}
            width="100%" viewBox={`0 0 ${VBW} ${VBH}`}
            style={{ display:'block', userSelect:'none' }}
            onPointerMove={e => { onSVGPointerMove(e); onEdgeMove(e); }}
            onPointerUp={onSVGPointerUp}
            onPointerLeave={onSVGPointerUp}
          >
            <defs>
              {/* Arrow markers */}
              {[
                { id:'am-teal',  fill:'rgba(var(--teal-rgb), 0.9)'    },
                { id:'am-gold',  fill:'rgba(var(--gold-vibrant-rgb), 0.9)'  },
                { id:'am-blue',  fill:'rgba(var(--blue-rgb), 0.9)'   },
                { id:'am-slate', fill:'rgba(var(--slate-rgb), 0.42)'   },
                { id:'am-ember', fill:'var(--ember-vibrant)'               },
              ].map(m => (
                <marker key={m.id} id={m.id} markerWidth="9" markerHeight="9" refX="7.5" refY="4.5" orient="auto">
                  <path d="M0,0.5 L0,8.5 L9,4.5 z" fill={m.fill} />
                </marker>
              ))}
              {/* Blur filter for adversarial glow */}
              <filter id="adv-blur" x="-60%" y="-80%" width="220%" height="260%">
                <feGaussianBlur stdDeviation="4.5" />
              </filter>
              {/* Dot grid */}
              <pattern id="dot-grid" width="30" height="30" patternUnits="userSpaceOnUse">
                <circle cx="15" cy="15" r="1" fill="rgba(var(--ink-rgb), 0.065)" />
              </pattern>
            </defs>

            {/* Background */}
            <rect width={VBW} height={VBH} fill="url(#dot-grid)" />

            {/* Layer labels */}
            {[
              { label:'Confounders & Instruments', x: 42 + NW/2,       y: 16 },
              { label:'Treatment',                 x: 330 + NW/2,      y: 16 },
              { label:'Mediators',                 x: 572 + NW/2,      y: 16 },
              { label:'Outcomes',                  x: 822 + NW/2,      y: 16 },
            ].map(lyr => (
              <text key={lyr.label} x={lyr.x} y={lyr.y} textAnchor="middle"
                fontSize={9} fontFamily='"IBM Plex Mono",monospace' fontWeight={600}
                letterSpacing={1.2} fill="rgba(var(--ink-rgb), 0.28)" style={{ textTransform:'uppercase' }}>
                {lyr.label.toUpperCase()}
              </text>
            ))}

            {/* Edges */}
            {EDGES.map(edge => {
              const src = nodeMap[edge.from], tgt = nodeMap[edge.to];
              if (!src || !tgt) return null;
              const d = makePath(src, tgt);
              const isAdv = adversarial && edge.isBackdoor;
              const isHov = hovEdge?.edge.id === edge.id;

              return (
                <g key={edge.id} opacity={edgeOpacity(edge)} style={{ transition:'opacity 180ms' }}>
                  {/* Glow layer for adversarial */}
                  {isAdv && (
                    <path d={d} stroke="rgba(var(--ember-vibrant-rgb), 0.45)" strokeWidth={9}
                      fill="none" filter="url(#adv-blur)" />
                  )}
                  {/* Main path */}
                  <path
                    d={d}
                    stroke={edgeStroke(edge)}
                    strokeWidth={isHov ? 2.6 : (edge.isBackdoor ? 1.3 : 1.9)}
                    strokeDasharray={edge.isBackdoor ? '6 4' : 'none'}
                    fill="none"
                    markerEnd={edgeMarker(edge)}
                    style={{ transition:'stroke-width 140ms' }}
                  />
                  {/* Invisible fat hit area */}
                  <path
                    d={d}
                    stroke="transparent"
                    strokeWidth={18}
                    fill="none"
                    style={{ cursor:'crosshair' }}
                    onPointerEnter={e => onEdgeEnter(e, edge)}
                    onPointerLeave={onEdgeLeave}
                  />
                </g>
              );
            })}

            {/* Nodes */}
            {nodes.map(node => {
              const cfg = NODE_CFG[node.type];
              const isSel = selNodeId === node.id;
              const isDraggable = !addingEdge;
              return (
                <g
                  key={node.id}
                  transform={`translate(${node.x},${node.y})`}
                  role="button"
                  tabIndex={0}
                  focusable="true"
                  aria-label={`Select DAG node ${node.label}. Type ${cfg.label}.`}
                  style={{ cursor: isDraggable ? 'grab' : 'crosshair' }}
                  onPointerDown={e => isDraggable && onNodePointerDown(e, node.id)}
                  onClick={() => !dragRef.current && setSelNodeId(s => s === node.id ? null : node.id)}
                  onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setSelNodeId(s => s === node.id ? null : node.id); } }}
                >
                  {/* Selection halo */}
                  {isSel && (
                    <rect x={-5} y={-5} width={NW+10} height={NH+10} rx={NR+5}
                      fill="none" stroke={cfg.stroke} strokeWidth={2} opacity={0.5} />
                  )}
                  {/* Body */}
                  <rect width={NW} height={NH} rx={NR}
                    fill={cfg.fill} stroke={cfg.stroke} strokeWidth={1.5}
                    style={{ transition:'fill 160ms, stroke 160ms' }} />
                  {/* Node type chip */}
                  <text x={10} y={15}
                    fontSize={8} fontWeight={700}
                    fontFamily='"IBM Plex Mono",monospace'
                    letterSpacing={1.3} fill={cfg.text} opacity={0.6}>
                    {node.type.toUpperCase()}
                  </text>
                  {/* Main label */}
                  <text x={NW/2} y={32}
                    textAnchor="middle"
                    fontSize={12.5} fontWeight={700}
                    fontFamily='"Manrope",sans-serif'
                    letterSpacing={-0.3} fill={cfg.text}>
                    {node.line1}
                  </text>
                  {/* Sub-label */}
                  <text x={NW/2} y={47}
                    textAnchor="middle"
                    fontSize={11} fontWeight={500}
                    fontFamily='"Manrope",sans-serif'
                    fill={cfg.text} opacity={0.75}>
                    {node.line2}
                  </text>
                </g>
              );
            })}

            {/* Edge tooltip */}
            {hovEdge && (() => {
              const { edge, svgX, svgY } = hovEdge;
              const tooltipW = 248, tooltipH = 86;
              const tx = Math.min(svgX + 16, VBW - tooltipW - 8);
              const ty = Math.max(svgY - tooltipH - 8, 8);
              const isBackdoor = edge.isBackdoor && !edge.strategy;
              const idcfg = edge.strategy ? ID_CFG[edge.strategy] : null;
              const accentColor = isBackdoor ? 'var(--ember)' : (idcfg?.color || 'var(--slate)');
              const chipLabel   = isBackdoor ? 'BACK-DOOR PATH' : (idcfg?.short || 'UNIDENTIFIED');
              const nameLabel   = isBackdoor ? 'Unblocked confounding route' : (idcfg?.label || '');
              const descLabel   = isBackdoor
                ? 'Adjust for confounders to close this path'
                : (edge.strategy ? ID_DESC[edge.strategy]?.slice(0, 56) + '…' : '');
              const routeLabel  = `${edge.from.replace(/_/g,' ')} → ${edge.to.replace(/_/g,' ')}`;

              return (
                <g style={{ pointerEvents:'none' }}>
                  <rect x={tx} y={ty} width={tooltipW} height={tooltipH} rx={12}
                    fill="rgba(var(--paper-rgb), 0.97)"
                    stroke="rgba(var(--ink-rgb), 0.09)" strokeWidth={1}
                    filter="drop-shadow(0 8px 20px rgba(var(--ink-rgb), 0.14))" />
                  {/* Accent left bar */}
                  <rect x={tx} y={ty+12} width={3} height={tooltipH-24} rx={2} fill={accentColor} opacity={0.7} />
                  {/* Content */}
                  <text x={tx+14} y={ty+21}
                    fontSize={8.5} fontWeight={700}
                    fontFamily='"IBM Plex Mono",monospace'
                    letterSpacing={1.2} fill={accentColor}>
                    {chipLabel}
                  </text>
                  <text x={tx+14} y={ty+38}
                    fontSize={12.5} fontWeight={700}
                    fontFamily='"Manrope",sans-serif' fill="var(--ink)">
                    {nameLabel}
                  </text>
                  <text x={tx+14} y={ty+54}
                    fontSize={10.5} fontFamily='"Manrope",sans-serif' fill="var(--slate)">
                    {descLabel}
                  </text>
                  <text x={tx+14} y={ty+70}
                    fontSize={9.5} fontFamily='"IBM Plex Mono",monospace'
                    fill="rgba(var(--slate-rgb), 0.6)">
                    {routeLabel}
                  </text>
                </g>
              );
            })()}
          </svg>
        </Panel>

        {/* Legend row */}
        <div style={{ display:'flex', alignItems:'center', gap:18, flexWrap:'wrap', padding:'0 2px' }}>
          <div style={{ display:'flex', alignItems:'center', gap:8 }}>
            <svg width={28} height={10}>
              <line x1={0} y1={5} x2={28} y2={5} stroke="rgba(var(--slate-rgb), 0.35)" strokeWidth={1.5} strokeDasharray="5 3" />
            </svg>
            <span style={{ fontSize:11, color:'rgba(var(--slate-rgb), 0.8)', fontFamily:'"IBM Plex Mono",monospace' }}>BACK-DOOR</span>
          </div>
          {Object.entries(ID_CFG).map(([key, cfg]) => (
            <div key={key} style={{ display:'flex', alignItems:'center', gap:8 }}>
              <svg width={28} height={10}>
                <line x1={0} y1={5} x2={28} y2={5} stroke={cfg.color} strokeWidth={1.9} />
              </svg>
              <span style={{ fontSize:11, color:'rgba(var(--slate-rgb), 0.8)', fontFamily:'"IBM Plex Mono",monospace' }}>{cfg.short}</span>
            </div>
          ))}
          <div style={{ flex:1 }} />
          {adversarial && (
            <div style={{
              display:'flex', alignItems:'center', gap:8,
              padding:'6px 12px', borderRadius:999,
              background:'rgba(var(--ember-rgb), 0.09)', border:'1px solid rgba(var(--ember-rgb), 0.22)',
            }}>
              <span style={{ width:6, height:6, borderRadius:'50%', background:'var(--ember-vibrant)', flexShrink:0 }} />
              <span style={{ fontSize:10, fontFamily:'"IBM Plex Mono",monospace', color:'var(--ember)', fontWeight:700, letterSpacing:'0.06em' }}>ADVERSARIAL</span>
              <span style={{ fontSize:11, color:'var(--ember)' }}>
                {backdoorCount} unlocked back-door paths — confounding bias unmitigated
              </span>
            </div>
          )}
        </div>
      </div>

      {/* ── Inspector ─────────────────────────────────────────── */}
      <div style={{ width:274, flexShrink:0, display:'flex', flexDirection:'column', gap:12 }}>
        <Panel style={{ flex:1 }}>
          <PanelHeader
            eyebrow="Inspector"
            title={selNode ? `${selNode.line1} ${selNode.line2}` : 'DAG Overview'}
          />

          {!selNode ? (
            // Overview mode
            <div>
              {/* Node type breakdown */}
              {Object.entries(NODE_CFG).map(([type, cfg]) => {
                const count = nodes.filter(n => n.type === type).length;
                if (!count) return null;
                return (
                  <div key={type} style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:8 }}>
                    <div style={{ display:'flex', alignItems:'center', gap:9 }}>
                      <div style={{ width:10, height:10, borderRadius:3, background:cfg.fill, border:`1.5px solid ${cfg.stroke}`, flexShrink:0 }} />
                      <span style={{ fontSize:12, color:cfg.text, fontWeight:600 }}>{cfg.label}</span>
                    </div>
                    <span style={{ fontSize:11, fontFamily:'"IBM Plex Mono",monospace', color:'var(--slate)' }}>{count}</span>
                  </div>
                );
              })}

              <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', margin:'14px 0' }} />
              <Eyebrow style={{ marginBottom:10 }}>Identification paths</Eyebrow>

              {Object.entries(ID_CFG).map(([key, cfg]) => {
                const count = EDGES.filter(e => e.strategy === key).length;
                if (!count) return null;
                return (
                  <div key={key} style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:7 }}>
                    <span style={{ fontSize:10, fontFamily:'"IBM Plex Mono",monospace', fontWeight:700, color:cfg.color, letterSpacing:'0.06em' }}>{cfg.short}</span>
                    <span style={{ fontSize:11, color:'var(--slate)' }}>{count} edge{count !== 1 ? 's' : ''}</span>
                  </div>
                );
              })}
              <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:7 }}>
                <span style={{ fontSize:10, fontFamily:'"IBM Plex Mono",monospace', fontWeight:700, color:'var(--ember)', letterSpacing:'0.06em' }}>BACK-DOOR</span>
                <span style={{ fontSize:11, color:'var(--slate)' }}>{backdoorCount} paths</span>
              </div>

              <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', margin:'14px 0' }} />
              <Eyebrow style={{ marginBottom:8 }}>Temporal cursor</Eyebrow>
              <div style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, color:'var(--teal)', fontWeight:700 }}>{VERSIONS[versionIdx].label}</div>
              <div style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9.5, color:'rgba(var(--slate-rgb), 0.8)', marginTop:3 }}>{VERSIONS[versionIdx].ts}</div>

              <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', margin:'14px 0' }} />
              <p style={{ fontSize:12, color:'var(--slate)', lineHeight:1.6, margin:0 }}>
                Click a node to inspect its role. Hover any edge for the identification strategy.
                Drag nodes to rearrange.
              </p>
            </div>
          ) : (
            // Node detail mode
            <div>
              <div style={{ marginBottom:14 }}>
                <Badge kind={BADGE_KINDS[selNode.type] || 'neutral'}>{selNode.type}</Badge>
              </div>

              <Eyebrow style={{ marginBottom:10 }}>Connected edges</Eyebrow>
              {selEdges.length === 0 && (
                <p style={{ fontSize:12, color:'var(--slate)', margin:0 }}>No edges.</p>
              )}
              {selEdges.map(e => {
                const isOut = e.from === selNodeId;
                const otherId = isOut ? e.to : e.from;
                const otherNode = nodeMap[otherId];
                const idcfg = e.strategy ? ID_CFG[e.strategy] : null;
                return (
                  <div key={e.id} style={{
                    padding:'9px 12px', borderRadius:12, marginBottom:7,
                    background:'rgba(var(--white-rgb), 0.54)', border:'1px solid rgba(var(--ink-rgb), 0.07)',
                  }}>
                    <div style={{ display:'flex', alignItems:'center', gap:7, marginBottom:4 }}>
                      <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:12, color:'rgba(var(--slate-rgb), 0.7)' }}>{isOut ? '→' : '←'}</span>
                      <span style={{ fontSize:12, fontWeight:700, color:'var(--ink)' }}>
                        {otherNode ? `${otherNode.line1} ${otherNode.line2}` : otherId.replace(/_/g,' ')}
                      </span>
                    </div>
                    {e.isBackdoor && !e.strategy ? (
                      <span style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:'var(--ember)', fontWeight:700, letterSpacing:'0.07em' }}>
                        BACK-DOOR PATH
                      </span>
                    ) : idcfg ? (
                      <span style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:idcfg.color, fontWeight:700, letterSpacing:'0.07em' }}>
                        {idcfg.short}
                      </span>
                    ) : null}
                  </div>
                );
              })}

              {selEdges.some(e => e.strategy) && (
                <>
                  <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', margin:'14px 0' }} />
                  <Eyebrow style={{ marginBottom:8 }}>Identification note</Eyebrow>
                  {selEdges.filter(e => e.strategy).slice(0,1).map(e => (
                    <p key={e.id} style={{ fontSize:11, color:'var(--slate)', lineHeight:1.6, margin:0 }}>
                      {ID_DESC[e.strategy]}
                    </p>
                  ))}
                </>
              )}

              <button type="button"
                onClick={() => setSelNodeId(null)}
                style={{ marginTop:14, fontSize:11, color:'rgba(var(--slate-rgb), 0.7)', background:'none', border:'none', cursor:'pointer', padding:0, fontFamily:'Manrope,sans-serif' }}
              >
                ← Overview
              </button>
            </div>
          )}
        </Panel>

        {/* Identifiability status card */}
        <Panel>
          <Eyebrow style={{ marginBottom:10 }}>Identifiability status</Eyebrow>
          {[
            { label:'Point-identified',    count: EDGES.filter(e => e.strategy).length, color:'var(--teal)', bg:'rgba(var(--teal-rgb), 0.12)' },
            { label:'Back-door (open)',     count: backdoorCount,                         color:'var(--ember)', bg:'rgba(var(--ember-rgb), 0.1)'  },
            { label:'Untraced',            count: 0,                                     color:'var(--gold)', bg:'rgba(var(--gold-rgb), 0.1)'  },
          ].map(row => (
            <div key={row.label} style={{ display:'flex', alignItems:'center', gap:10, marginBottom:8 }}>
              <div style={{ flex:1, height:5, borderRadius:999, background:'rgba(var(--ink-rgb), 0.06)', overflow:'hidden' }}>
                <div style={{
                  height:'100%', borderRadius:999, background:row.color,
                  width:`${(row.count / EDGES.length * 100).toFixed(0)}%`,
                  transition:'width 400ms ease',
                }} />
              </div>
              <span style={{ fontSize:10, fontFamily:'"IBM Plex Mono",monospace', color:row.color, fontWeight:700, minWidth:16, textAlign:'right' }}>{row.count}</span>
              <span style={{ fontSize:10, color:'rgba(var(--slate-rgb), 0.8)', minWidth:110 }}>{row.label}</span>
            </div>
          ))}
        </Panel>
      </div>
    </div>
  );
}

Object.assign(window, { CausalAtlasScreen });
