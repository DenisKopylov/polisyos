// CohortTimeTraveler.jsx — A4
// Filter-builder cohort + time scrub + Sankey state flow + policy overlay
// Exports: CohortTimeTravelerScreen

const POLICY_VERSIONS = [
  { label:'v3.4 · 2024-Q3', ts:'2024-09-30', passRate:0.48, color:'var(--teal)' },
  { label:'v3.3 · 2024-Q2', ts:'2024-06-30', passRate:0.44, color:'var(--gold)' },
  { label:'v3.2 · 2024-Q1', ts:'2024-03-31', passRate:0.38, color:'var(--ember)' },
];

const TIME_POINTS = ['Q1 2023','Q2 2023','Q3 2023','Q4 2023','Q1 2024'];

// Base flows (all cohort, unfiltered)
// Each entry: fromCol, fromState, toCol, toState, fraction_of_root
const BASE_FLOW = [
  { from:[0,'eligible'], to:[1,'applied'],    frac:0.62 },
  { from:[0,'eligible'], to:[1,'not_applied'],frac:0.38 },
  { from:[1,'applied'],  to:[2,'approved'],   frac:0.48 },
  { from:[1,'applied'],  to:[2,'rejected'],   frac:0.14 },
  { from:[1,'not_applied'],to:[2,'exit'],     frac:0.38 },
  { from:[2,'approved'], to:[3,'enrolled'],   frac:0.46 },
  { from:[2,'approved'], to:[3,'withdrew'],   frac:0.02 },
  { from:[2,'rejected'], to:[3,'exit'],       frac:0.14 },
  { from:[3,'enrolled'], to:[4,'completed'],  frac:0.39 },
  { from:[3,'enrolled'], to:[4,'dropped'],    frac:0.07 },
  { from:[3,'withdrew'], to:[4,'exit'],       frac:0.02 },
];

// Node colour mapping
const STATE_CFG = {
  eligible:    { color:'var(--teal)', label:'Eligible'     },
  applied:     { color:'var(--teal-vibrant)', label:'Applied'      },
  not_applied: { color:'rgba(var(--slate-rgb), 0.5)', label:'Not Applied' },
  approved:    { color:'var(--teal)', label:'Approved'     },
  rejected:    { color:'var(--ember)', label:'Rejected'     },
  enrolled:    { color:'var(--teal-vibrant)', label:'Enrolled'     },
  withdrew:    { color:'var(--gold-vibrant)', label:'Withdrew'     },
  completed:   { color:'var(--teal)', label:'Completed'    },
  dropped:     { color:'var(--ember-vibrant)', label:'Dropped'      },
  exit:        { color:'rgba(var(--slate-rgb), 0.22)', label:'Exit' },
};

// Sankey layout: column x positions and node y/height layout
const COL_X  = [32, 172, 312, 452, 592];
const COL_W  = 96;
const SVG_H  = 350;
const MARGIN = 18;

function computeLayout(root) {
  // root = total cohort size
  // Returns { nodes: {key: {x,y,h,frac}}, flows: [{d, color, opacity}] }
  const nodes = {};
  function nodeKey(col, state) { return `${col}_${state}`; }
  function addNode(col, state, frac) {
    const k = nodeKey(col, state);
    if (!nodes[k]) nodes[k] = { col, state, frac: 0 };
    nodes[k].frac += frac;
  }
  // Seed root
  addNode(0, 'eligible', 1.0);
  BASE_FLOW.forEach(f => {
    addNode(f.to[0], f.to[1], f.frac);
  });

  // Layout: assign y positions within each column
  const colStates = {};
  Object.entries(nodes).forEach(([k, n]) => {
    if (!colStates[n.col]) colStates[n.col] = [];
    colStates[n.col].push({ k, state: n.state, frac: n.frac });
  });

  const usableH = SVG_H - MARGIN * 2;
  Object.entries(colStates).forEach(([col, items]) => {
    const totalFrac = items.reduce((s, i) => s + i.frac, 0);
    // Sort: primary states first, exit last
    items.sort((a, b) => (a.state === 'exit' ? 1 : b.state === 'exit' ? -1 : b.frac - a.frac));
    let yOff = MARGIN;
    items.forEach(item => {
      const h = Math.max(6, (item.frac / Math.max(totalFrac, 1)) * usableH);
      nodes[item.k].x = COL_X[Number(col)];
      nodes[item.k].y = yOff;
      nodes[item.k].h = h;
      yOff += h + 6;
    });
  });

  // Build flows (bezier filled paths)
  const flows = BASE_FLOW.map(f => {
    const srcKey = nodeKey(f.from[0], f.from[1]);
    const tgtKey = nodeKey(f.to[0],  f.to[1]);
    const src = nodes[srcKey], tgt = nodes[tgtKey];
    if (!src || !tgt) return null;
    const srcH = src.h * (f.frac / src.frac);
    const tgtH = tgt.h;
    const x1 = src.x + COL_W, y1 = src.y;
    const x2 = tgt.x,        y2 = tgt.y;
    const mx  = (x1 + x2) / 2;
    const d = `M ${x1} ${y1} C ${mx} ${y1}, ${mx} ${y2}, ${x2} ${y2} L ${x2} ${y2+tgtH} C ${mx} ${y2+tgtH}, ${mx} ${y1+srcH}, ${x1} ${y1+srcH} Z`;
    const cfg = STATE_CFG[f.to[1]] || STATE_CFG.exit;
    return { d, color: cfg.color, key:`${srcKey}-${tgtKey}`, frac:f.frac };
  }).filter(Boolean);

  return { nodes, flows };
}

function CohortTimeTravelerScreen() {
  const [ageRange,     setAgeRange]     = React.useState([18, 65]);
  const [region,       setRegion]       = React.useState('all');
  const [incomeQ,      setIncomeQ]      = React.useState('all');
  const [policyVer,    setPolicyVer]    = React.useState(0);
  const [showOverlay,  setShowOverlay]  = React.useState(true);
  const [hovState,     setHovState]     = React.useState(null);
  const [timeIdx,      setTimeIdx]      = React.useState(4);

  // Cohort size multiplier based on filters
  const cohortMult = React.useMemo(() => {
    let m = 1.0;
    const ageSpan = ageRange[1] - ageRange[0];
    m *= ageSpan / 47; // base 18-65 = 47 years
    if (region !== 'all') m *= 0.42;
    if (incomeQ !== 'all') m *= 0.25;
    return Math.max(0.02, m);
  }, [ageRange, region, incomeQ]);

  const baseTotal = 10000;
  const cohortSize = Math.round(baseTotal * cohortMult);

  const { nodes, flows } = React.useMemo(() => computeLayout(cohortSize), [cohortSize]);
  const pver = POLICY_VERSIONS[policyVer];

  // Show flows up to current timeIdx
  const visibleCols = timeIdx + 1; // columns 0..timeIdx

  const completeN = Math.round(cohortSize * 0.39 * cohortMult);
  const approvalRate = pver.passRate;

  return (
    <div style={{ display:'flex', gap:20, height:'100%' }}>

      {/* Filter panel */}
      <div style={{ width:224, flexShrink:0, display:'flex', flexDirection:'column', gap:12 }}>
        <Panel style={{ flex:1 }}>
          <PanelHeader eyebrow="A4 · Cohort" title="Filter" />

          <Eyebrow style={{ marginBottom:8 }}>Age range</Eyebrow>
          <div style={{ display:'flex', gap:8, marginBottom:4 }}>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:10, color:'var(--slate)', marginBottom:3 }}>Min</div>
              <input type="range" min={18} max={64} value={ageRange[0]}
                onChange={e => setAgeRange([+e.target.value, ageRange[1]])}
                style={{ width:'100%' }} />
              <div style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, color:'var(--teal)', fontWeight:700 }}>{ageRange[0]}</div>
            </div>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:10, color:'var(--slate)', marginBottom:3 }}>Max</div>
              <input type="range" min={ageRange[0]+1} max={65} value={ageRange[1]}
                onChange={e => setAgeRange([ageRange[0], +e.target.value])}
                style={{ width:'100%' }} />
              <div style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, color:'var(--teal)', fontWeight:700 }}>{ageRange[1]}</div>
            </div>
          </div>

          <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', margin:'14px 0' }} />
          <Eyebrow style={{ marginBottom:8 }}>Region</Eyebrow>
          {['all','urban','rural','mixed'].map(r => (
            <label key={r} style={{ display:'flex', alignItems:'center', gap:8, marginBottom:6, cursor:'pointer' }}>
              <input type="radio" name="region" value={r} checked={region===r} onChange={() => setRegion(r)} />
              <span style={{ fontSize:12, color:'var(--ink)', textTransform:'capitalize' }}>{r === 'all' ? 'All regions' : r}</span>
            </label>
          ))}

          <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', margin:'14px 0' }} />
          <Eyebrow style={{ marginBottom:8 }}>Income quartile</Eyebrow>
          {['all','Q1','Q2','Q3','Q4'].map(q => (
            <label key={q} style={{ display:'flex', alignItems:'center', gap:8, marginBottom:6, cursor:'pointer' }}>
              <input type="radio" name="income" value={q} checked={incomeQ===q} onChange={() => setIncomeQ(q)} />
              <span style={{ fontSize:12, color:'var(--ink)' }}>{q === 'all' ? 'All quartiles' : q}</span>
            </label>
          ))}

          <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', margin:'14px 0' }} />
          <div style={{ padding:'10px 12px', borderRadius:12, background:'rgba(var(--teal-rgb), 0.09)', border:'1px solid rgba(var(--teal-rgb), 0.2)' }}>
            <div style={{ fontSize:10, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--teal-rgb), 0.8)', marginBottom:4 }}>COHORT SIZE</div>
            <div style={{ fontSize:22, fontWeight:800, color:'var(--teal)', letterSpacing:'-0.04em' }}>
              {cohortSize.toLocaleString()}
            </div>
          </div>
        </Panel>
      </div>

      {/* Sankey + timeline */}
      <div style={{ flex:1, minWidth:0, display:'flex', flexDirection:'column', gap:12 }}>

        {/* Toolbar */}
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <Eyebrow>State flow · {TIME_POINTS[timeIdx]}</Eyebrow>
          <div style={{ flex:1 }} />
          <label style={{ display:'flex', alignItems:'center', gap:6, fontSize:12, color:'var(--slate)', cursor:'pointer' }}>
            <input type="checkbox" checked={showOverlay} onChange={e => setShowOverlay(e.target.checked)} />
            Policy overlay
          </label>
          <select value={policyVer} onChange={e => setPolicyVer(+e.target.value)}
            style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, border:'1px solid rgba(var(--ink-rgb), 0.1)', borderRadius:8, padding:'4px 8px', background:'rgba(var(--white-rgb), 0.7)', color:pver.color, fontWeight:700 }}>
            {POLICY_VERSIONS.map((v,i) => <option key={i} value={i}>{v.label}</option>)}
          </select>
        </div>

        {/* Sankey canvas */}
        <Panel style={{ padding:0, overflow:'hidden', flex:1, minHeight:300 }}>
          <svg width="100%" viewBox={`0 0 ${COL_X[4]+COL_W+32} ${SVG_H}`} style={{ display:'block' }}>
            {/* Column time labels */}
            {TIME_POINTS.map((tp, i) => (
              <text key={tp} x={COL_X[i] + COL_W/2} y={14}
                textAnchor="middle" fontSize={9}
                fontFamily='"IBM Plex Mono",monospace'
                fontWeight={i === timeIdx ? 700 : 400}
                fill={i === timeIdx ? 'var(--teal)' : 'rgba(var(--ink-rgb), 0.32)'}
                letterSpacing={0.8}>{tp.toUpperCase()}</text>
            ))}

            {/* Flows */}
            {flows.map(f => {
              const srcCol = parseInt(Object.entries(nodes).find(([k,n]) => n.state === f.key?.split('-')[0]?.split('_')[1])?.col || 0);
              return (
                <path key={f.key} d={f.d}
                  fill={f.color}
                  opacity={0.18}
                  stroke="none"
                  style={{ transition:'opacity 200ms' }} />
              );
            })}

            {/* Nodes */}
            {Object.entries(nodes).map(([key, node]) => {
              const cfg = STATE_CFG[node.state] || STATE_CFG.exit;
              const isExit = node.state === 'exit';
              if (node.col >= visibleCols) return null;
              const pct = (node.frac / cohortSize * 100);

              return (
                <g key={key}
                  onMouseEnter={() => setHovState(key)}
                  onMouseLeave={() => setHovState(null)}
                  style={{ cursor:'pointer' }}>
                  <rect
                    x={node.x} y={node.y}
                    width={COL_W} height={Math.max(node.h, 6)}
                    rx={6}
                    fill={cfg.color}
                    opacity={isExit ? 0.2 : (hovState === key ? 0.9 : 0.7)}
                    style={{ transition:'opacity 140ms' }}
                  />
                  {/* Label */}
                  {node.h > 18 && !isExit && (
                    <text x={node.x + COL_W/2} y={node.y + node.h/2 + 4}
                      textAnchor="middle" fontSize={10} fontWeight={700}
                      fontFamily='"Manrope",sans-serif' fill="white" opacity={0.95}>
                      {cfg.label}
                    </text>
                  )}
                  {node.h > 30 && !isExit && (
                    <text x={node.x + COL_W/2} y={node.y + node.h/2 + 16}
                      textAnchor="middle" fontSize={8.5}
                      fontFamily='"IBM Plex Mono",monospace' fill="rgba(var(--white-rgb), 0.8)">
                      {Math.round(node.frac).toLocaleString()}
                    </text>
                  )}
                  {/* Policy overlay */}
                  {showOverlay && node.state === 'completed' && (
                    <rect x={node.x} y={node.y} width={COL_W}
                      height={Math.max(node.h * (pver.passRate / 0.39), 4)}
                      rx={6} fill={pver.color} opacity={0.35} />
                  )}
                </g>
              );
            })}

            {/* Timeline cursor */}
            {timeIdx < TIME_POINTS.length - 1 && (
              <line
                x1={COL_X[timeIdx] + COL_W + 6} y1={MARGIN}
                x2={COL_X[timeIdx] + COL_W + 6} y2={SVG_H - MARGIN}
                stroke="var(--teal-vibrant)" strokeWidth={1.5} strokeDasharray="4 3" opacity={0.6} />
            )}
          </svg>
        </Panel>

        {/* Timeline scrubber */}
        <Panel style={{ padding:'14px 18px' }}>
          <div style={{ display:'flex', alignItems:'center', gap:14 }}>
            <Eyebrow style={{ flexShrink:0 }}>Scrub timeline</Eyebrow>
            <input type="range" min={0} max={4} value={timeIdx}
              onChange={e => setTimeIdx(+e.target.value)}
              style={{ flex:1 }} />
            <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, color:'var(--teal)', fontWeight:700, flexShrink:0 }}>
              {TIME_POINTS[timeIdx]}
            </span>
          </div>
        </Panel>
      </div>

      {/* Stats panel */}
      <div style={{ width:220, flexShrink:0, display:'flex', flexDirection:'column', gap:12 }}>
        <Panel>
          <Eyebrow style={{ marginBottom:10 }}>Cohort outcomes</Eyebrow>
          {[
            { label:'Applied',   n: Math.round(cohortSize*0.62), color:'var(--teal-vibrant)' },
            { label:'Approved',  n: Math.round(cohortSize*0.48), color:'var(--teal)' },
            { label:'Enrolled',  n: Math.round(cohortSize*0.46), color:'var(--teal-vibrant)' },
            { label:'Completed', n: Math.round(cohortSize*0.39), color:'var(--teal)' },
            { label:'Dropped',   n: Math.round(cohortSize*0.07), color:'var(--ember-vibrant)' },
          ].map(row => (
            <div key={row.label} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8 }}>
              <span style={{ fontSize:12, color:'var(--slate)' }}>{row.label}</span>
              <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:12, fontWeight:700, color:row.color }}>
                {row.n.toLocaleString()}
              </span>
            </div>
          ))}
        </Panel>

        {showOverlay && (
          <Panel style={{ background:'rgba(var(--teal-rgb), 0.07)', border:'1px solid rgba(var(--teal-rgb), 0.18)' }}>
            <Eyebrow style={{ marginBottom:8, color:'rgba(var(--teal-rgb), 0.8)' }}>Policy overlay · {pver.label}</Eyebrow>
            <div style={{ fontSize:22, fontWeight:800, color:pver.color, letterSpacing:'-0.04em', marginBottom:4 }}>
              {(pver.passRate * 100).toFixed(0)}%
            </div>
            <div style={{ fontSize:11, color:'rgba(var(--teal-rgb), 0.8)', lineHeight:1.5 }}>
              pass rate — {Math.round(cohortSize * pver.passRate).toLocaleString()} of this cohort would have passed under {pver.label}
            </div>
            <div style={{ height:1, background:'rgba(var(--teal-rgb), 0.15)', margin:'10px 0' }} />
            <div style={{ fontSize:11, color:'var(--slate)' }}>
              Δ vs current:{' '}
              <strong style={{ color: pver.passRate >= 0.48 ? 'var(--teal)':'var(--ember)' }}>
                {pver.passRate >= 0.48 ? '+':''}{((pver.passRate - 0.48)*100).toFixed(0)}pp
              </strong>
            </div>
          </Panel>
        )}
      </div>
    </div>
  );
}

Object.assign(window, { CohortTimeTravelerScreen });
