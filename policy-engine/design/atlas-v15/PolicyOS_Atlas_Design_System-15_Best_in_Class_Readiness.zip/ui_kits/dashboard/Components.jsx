// Atlas dashboard compatibility bridge.
// Product apps should import from packages/atlas-ui. The standalone HTML
// prototype still needs globals, so these wrappers mirror the v10 component API
// and consume packages/atlas-ui/src/atlas-ui.css plus dashboard-responsive.css.

function cx(...classes) {
  return classes.filter(Boolean).join(' ');
}

function VisuallyHidden({ children }) {
  return <span className="sr-only">{children}</span>;
}

function useResponsiveMedia(query) {
  const [matches, setMatches] = React.useState(() => typeof window !== 'undefined' && window.matchMedia ? window.matchMedia(query).matches : false);
  React.useEffect(() => {
    if (!window.matchMedia) return;
    const media = window.matchMedia(query);
    const onChange = () => setMatches(media.matches);
    onChange();
    media.addEventListener ? media.addEventListener('change', onChange) : media.addListener(onChange);
    return () => media.removeEventListener ? media.removeEventListener('change', onChange) : media.removeListener(onChange);
  }, [query]);
  return matches;
}

function Badge({ kind = 'neutral', children, className, ariaLabel, ...props }) {
  return <span className={cx('atlas-badge', `atlas-badge--${kind}`, className)} aria-label={ariaLabel} {...props}>{children}</span>;
}

function Button({
  variant='ghost',
  size='md',
  children,
  onClick,
  className,
  type='button',
  disabled=false,
  loading=false,
  ariaLabel,
  ariaPressed,
  ariaControls,
  ariaExpanded,
  title,
  iconStart,
  iconEnd,
  style,
  ...props
}) {
  return (
    <button
      type={type}
      className={cx('atlas-button', `atlas-button--${variant}`, size !== 'md' && `atlas-button--${size}`, className)}
      disabled={disabled || loading}
      aria-busy={loading ? 'true' : undefined}
      aria-label={ariaLabel}
      aria-pressed={ariaPressed}
      aria-controls={ariaControls}
      aria-expanded={ariaExpanded}
      title={title}
      onClick={onClick}
      style={style}
      data-variant={variant}
      data-size={size}
      {...props}
    >
      {loading ? <span className="atlas-button__spinner" aria-hidden="true" /> : iconStart}
      {loading ? <VisuallyHidden>Loading</VisuallyHidden> : null}
      {children}
      {!loading ? iconEnd : null}
    </button>
  );
}

function InteractiveCard({
  children,
  onClick,
  selected=false,
  ariaLabel,
  ariaControls,
  className,
  disabled=false,
  style,
  ...props
}) {
  return (
    <button
      type="button"
      className={cx('atlas-interactive-card', className)}
      aria-pressed={selected ? 'true' : 'false'}
      data-selected={selected ? 'true' : undefined}
      aria-label={ariaLabel}
      aria-controls={ariaControls}
      disabled={disabled}
      onClick={onClick}
      style={style}
      {...props}
    >
      {children}
    </button>
  );
}

function Panel({ children, hero, ariaLabel, ariaLabelledby, role, className, style, ...props }) {
  return (
    <section
      role={role}
      aria-label={ariaLabel}
      aria-labelledby={ariaLabelledby}
      className={cx('atlas-panel', hero && 'atlas-panel--hero', className)}
      data-hero={hero ? 'true' : undefined}
      style={style}
      {...props}
    >
      {children}
    </section>
  );
}

function PanelHeader({ eyebrow, title, children, id }) {
  return (
    <div className="atlas-panel__header">
      <div>
        {eyebrow && <p className="atlas-panel__eyebrow">{eyebrow}</p>}
        {title && <h2 id={id} className="atlas-panel__title">{title}</h2>}
      </div>
      {children && <div className="atlas-panel__actions">{children}</div>}
    </div>
  );
}

function MetricCard({ label, value, hint, badge }) {
  return (
    <section className="atlas-metric-card" aria-label={`${label}: ${value}${hint ? `. ${hint}` : ''}`}>
      <div className="atlas-metric-card__top">
        <span className="atlas-metric-card__label">{label}</span>
        {badge}
      </div>
      <strong className="atlas-metric-card__value">{value}</strong>
      {hint && <p className="atlas-metric-card__hint">{hint}</p>}
    </section>
  );
}

function RunCard({ runId, status, duration, artifacts, onClick }) {
  const kindMap = { success:'ok', failed:'fail', blocked:'fail', running:'warn', pending:'neutral', draft:'neutral' };
  const kind = kindMap[status] || 'neutral';
  return (
    <InteractiveCard onClick={onClick} ariaLabel={`Open run ${runId}. Status ${status}. Duration ${duration}. ${artifacts} artifacts.`}>
      <div className="atlas-run-card__header">
        <p className="atlas-run-card__id" style={{fontFamily:'var(--font-mono)', letterSpacing:'var(--tracking-wide)'}}>{runId}</p>
        <Badge kind={kind}>{status}</Badge>
      </div>
      <p className="atlas-run-card__meta">{duration} · {artifacts} artifacts</p>
    </InteractiveCard>
  );
}

function Eyebrow({ children }) {
  return <p className="atlas-panel__eyebrow">{children}</p>;
}


function ResponsiveGrid({ children, className, style, ...props }) {
  return <div className={cx('atlas-responsive-grid', className)} style={style} {...props}>{children}</div>;
}

function ResponsiveSplit({ children, className, style, ...props }) {
  return <div className={cx('atlas-responsive-split', className)} style={style} {...props}>{children}</div>;
}

function ResponsiveScroller({ children, className, ariaLabel, style, ...props }) {
  return <div className={cx('atlas-responsive-scroller', className)} aria-label={ariaLabel} tabIndex="0" style={style} {...props}>{children}</div>;
}

Object.assign(window, { Badge, Button, Panel, PanelHeader, MetricCard, RunCard, Eyebrow, InteractiveCard, VisuallyHidden, useResponsiveMedia, ResponsiveGrid, ResponsiveSplit, ResponsiveScroller });
