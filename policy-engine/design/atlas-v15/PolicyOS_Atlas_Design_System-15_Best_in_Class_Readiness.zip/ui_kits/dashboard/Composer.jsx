// Composer.jsx — Scenario Composer screen

function ComposerScreen({ onLaunch }) {
  const [step, setStep] = React.useState(0);
  const steps = ['Problem Frame', 'Interventions', 'Constraints', 'Launch'];

  const interventions = [
    { name:'VAT Rate Adjustment', tag:'Fiscal', featured:true, effect:'+2.3% GDP', conf:'High' },
    { name:'Employment Subsidy',  tag:'Labour',  featured:false, effect:'+1.1% Employment', conf:'Medium' },
    { name:'Carbon Levy',         tag:'Energy',  featured:false, effect:'-4.2% Emissions', conf:'High' },
  ];

  return (
    <div style={{display:'grid', gap:18}}>
      {/* Topbar */}
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap', gap:12}}>
        <div>
          <Eyebrow style={{marginBottom:6}}>Scenario Composer</Eyebrow>
          <h1 style={{margin:0, fontSize:30, fontWeight:800, letterSpacing:'-0.04em', lineHeight:1.05}}>Design Intervention</h1>
          <p style={{margin:'6px 0 0', fontSize:14, color:'rgba(var(--ink-rgb), 0.65)'}}>Build a policy scenario with evidence-grounded interventions and governance constraints.</p>
        </div>
        <div style={{display:'flex', gap:8}}>
          <Button variant="ghost">Save Draft</Button>
          <Button variant="primary" onClick={onLaunch}>Launch Run →</Button>
        </div>
      </div>

      {/* Steps */}
      <div style={{display:'flex', gap:8, flexWrap:'wrap'}}>
        {steps.map((s,i) => (
          <button type="button" key={s} onClick={() => setStep(i)} style={{
            padding:'9px 14px', borderRadius:999,
            background: step===i ? 'linear-gradient(135deg,var(--graphite),var(--ink))' : 'rgba(var(--white-rgb), 0.55)',
            border:`1px solid ${step===i ? 'transparent' : 'rgba(var(--ink-rgb), 0.08)'}`,
            color: step===i ? 'var(--warm-white)' : 'var(--ink)',
            fontSize:13, fontWeight:700, cursor:'pointer', fontFamily:'Manrope, sans-serif',
          }}>{i+1}. {s}</button>
        ))}
      </div>

      {/* Main grid */}
      <div style={{display:'grid', gridTemplateColumns:'minmax(0,1.35fr) minmax(300px,0.8fr)', gap:18}}>
        <div style={{display:'grid', gap:14}}>

          {/* Prompt box */}
          <div style={{
            padding:'20px 22px', borderRadius:24,
            background:'linear-gradient(145deg,rgba(var(--teal-vibrant-rgb), 0.12),rgba(var(--gold-vibrant-rgb), 0.1)), rgba(var(--white-rgb), 0.62)',
            border:'1px solid rgba(var(--ink-rgb), 0.08)',
          }}>
            <Eyebrow style={{marginBottom:8}}>Problem Statement</Eyebrow>
            <p style={{margin:0, fontSize:20, lineHeight:1.35, letterSpacing:'-0.02em', color:'var(--ink)', fontWeight:600}}>
              Reduce household energy poverty in Kharkiv Oblast by 12% within 18 months without increasing deficit beyond 0.5% GDP.
            </p>
          </div>

          {/* Interventions */}
          <div>
            <Eyebrow style={{marginBottom:10}}>Available Interventions</Eyebrow>
            <div style={{display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12}}>
              {interventions.map(iv => (
                <div key={iv.name} style={{
                  padding:'16px 18px', borderRadius:20,
                  border:'1px solid rgba(var(--ink-rgb), 0.07)',
                  background: iv.featured
                    ? 'linear-gradient(180deg,rgba(var(--teal-vibrant-rgb), 0.14),rgba(var(--teal-vibrant-rgb), 0.06)), rgba(var(--white-rgb), 0.74)'
                    : 'rgba(var(--white-rgb), 0.56)',
                }}>
                  <div style={{display:'flex', alignItems:'center', gap:6, marginBottom:8}}>
                    <img src="../../assets/glyphs/intervention.svg" width={14} height={14} />
                    <span style={{fontFamily:'"IBM Plex Mono",monospace', fontSize:9, textTransform:'uppercase', letterSpacing:'0.1em', color:'rgba(var(--ink-rgb), 0.56)', background:'rgba(var(--ink-rgb), 0.07)', padding:'3px 6px', borderRadius:6}}>{iv.tag}</span>
                  </div>
                  <strong style={{display:'block', fontSize:14, fontWeight:700, lineHeight:1.25, marginBottom:8}}>{iv.name}</strong>
                  <div style={{display:'flex', justifyContent:'space-between'}}>
                    <span style={{fontSize:12, color:'var(--teal-vibrant)', fontWeight:700}}>{iv.effect}</span>
                    <Badge kind={iv.conf==='High'?'ok':'warn'} style={{fontSize:9, padding:'3px 7px'}}>{iv.conf}</Badge>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Constraints */}
          <Panel>
            <PanelHeader eyebrow="Constraints" title="Policy Guardrails" />
            <div style={{display:'grid', gap:8}}>
              {[
                { label:'Deficit ceiling',      val:'≤ 0.5% GDP',     ok:true  },
                { label:'Employment floor',     val:'≥ 68% rate',     ok:true  },
                { label:'Evidence threshold',   val:'CI 80% required', ok:false },
                { label:'Governance approval',  val:'Cabinet sign-off', ok:true  },
              ].map(c => (
                <div key={c.label} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'10px 14px',borderRadius:14,background:'rgba(var(--white-rgb), 0.56)',border:'1px solid rgba(var(--ink-rgb), 0.06)'}}>
                  <span style={{fontSize:13, fontWeight:600}}>{c.label}</span>
                  <div style={{display:'flex', gap:8, alignItems:'center'}}>
                    <span style={{fontFamily:'"IBM Plex Mono",monospace', fontSize:11, color:'rgba(var(--ink-rgb), 0.65)'}}>{c.val}</span>
                    <Badge kind={c.ok?'ok':'fail'} style={{fontSize:9,padding:'3px 7px'}}>{c.ok?'✓ Set':'! Missing'}</Badge>
                  </div>
                </div>
              ))}
            </div>
          </Panel>
        </div>

        {/* Sidebar context rail */}
        <div style={{
          padding:'26px 22px', borderRadius:22,
          background:'linear-gradient(180deg,rgba(var(--graphite-rgb), 0.97),rgba(var(--shell-dark-rgb), 0.96))',
          color:'var(--rail-fg)', display:'flex', flexDirection:'column', gap:20,
        }}>
          <div>
            <p style={{margin:'0 0 6px',fontFamily:'"IBM Plex Mono",monospace',fontSize:10,letterSpacing:'0.12em',textTransform:'uppercase',color:'rgba(var(--rail-fg-rgb), 0.55)'}}>Readiness Score</p>
            <div style={{
              width:120, height:120, borderRadius:'50%', margin:'8px 0',
              background:'radial-gradient(circle, rgba(var(--shell-dark-rgb), 1) 52%, transparent 53%), conic-gradient(from 240deg, var(--teal-vibrant) 0deg, var(--teal-vibrant) 252deg, rgba(var(--white-rgb), 0.12) 252deg)',
              display:'grid', placeItems:'center', color:'var(--warm-white)', fontSize:32, fontWeight:800,
            }}>70</div>
          </div>
          {[
            { label:'Domain',      val:'Energy / Fiscal' },
            { label:'Evidence',    val:'14 bundles linked' },
            { label:'Model',       val:'JAX Foundry v2.4' },
            { label:'Est. Duration', val:'18–24s' },
          ].map(s => (
            <div key={s.label} style={{paddingBottom:12, borderBottom:'1px solid rgba(var(--white-rgb), 0.1)'}}>
              <span style={{display:'block', fontSize:10, fontFamily:'"IBM Plex Mono",monospace', letterSpacing:'0.08em', textTransform:'uppercase', color:'rgba(var(--rail-fg-rgb), 0.52)', marginBottom:4}}>{s.label}</span>
              <strong style={{fontSize:16, display:'block'}}>{s.val}</strong>
            </div>
          ))}
          <Button variant="primary" style={{marginTop:'auto', justifyContent:'center', width:'100%'}} onClick={onLaunch}>
            Launch Run →
          </Button>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { ComposerScreen });
