// ConnectorCards.jsx — B2
// Connector character cards: latency fingerprint, cost, error budget, retry profile
// Exports: ConnectorCardsScreen

const CONNECTORS = [
  {
    id:'pg_fiscal', name:'Fiscal DB', protocol:'PostgreSQL', type:'database',
    p50:12, p95:48, costPer:'$0.003/req', errorBudget:94.2, lastGreen:'2 min ago',
    retryProfile:'Exp. backoff · 3× · jitter',
    pulls: [11,14,12,18,13,11,47,12], // recent p50 latencies ms
    status:'ok', domain:'fiscal',
    desc:'Primary fiscal records store. Batch pull every 2h via read replica.',
  },
  {
    id:'rest_employ', name:'Employment Registry', protocol:'REST/HTTPS', type:'api',
    p50:124, p95:891, costPer:'$0.021/req', errorBudget:87.3, lastGreen:'4 hr ago',
    retryProfile:'Linear · 2× · timeout 30s',
    pulls: [118,131,124,890,127,119,125,134],
    status:'warn', domain:'employment',
    desc:'National employment registry. Daily SFTP overnight, REST for lookups.',
  },
  {
    id:'grpc_gdp', name:'GDP Tracker', protocol:'gRPC', type:'stream',
    p50:8, p95:22, costPer:'$0.001/req', errorBudget:99.1, lastGreen:'30 sec ago',
    retryProfile:'Exp. backoff · 5× · circuit breaker',
    pulls: [7,8,8,9,8,7,22,8],
    status:'ok', domain:'economic',
    desc:'Real-time GDP indicator stream. 6h refresh cycle via gRPC streaming.',
  },
  {
    id:'sftp_tax', name:'Tax Records', protocol:'SFTP', type:'batch',
    p50:3200, p95:12400, costPer:'$0.004/pull', errorBudget:71.4, lastGreen:'3 days ago',
    retryProfile:'Manual retry · no auto-recovery',
    pulls: [3100,3400,3200,12200,3300,3100,3250,3180],
    status:'fail', domain:'fiscal',
    desc:'Weekly batch from tax authority. 3-day lag; SLA breached this cycle.',
  },
  {
    id:'kafka_iv', name:'Budget Cycle IV', protocol:'Kafka', type:'stream',
    p50:4, p95:11, costPer:'$0.0001/msg', errorBudget:99.8, lastGreen:'1 min ago',
    retryProfile:'At-least-once · DLQ · 10×',
    pulls: [4,3,4,4,5,4,3,11],
    status:'ok', domain:'fiscal',
    desc:'Kafka topic for budget cycle events. ~30min consumer lag under normal load.',
  },
  {
    id:'jdbc_hr', name:'Legacy HR System', protocol:'JDBC', type:'database',
    p50:240, p95:2100, costPer:'$0.008/req', errorBudget:55.2, lastGreen:'7 days ago',
    retryProfile:'No retry · manual escalation',
    pulls: [235,248,2050,241,238,244,240,2100],
    status:'fail', domain:'hr',
    desc:'Legacy HR database. Unreliable; scheduled for deprecation in Q1 2025.',
  },
];

const CONN_STATUS = {
  ok:   { color:'var(--teal)', bg:'rgba(var(--teal-rgb), 0.10)',  border:'rgba(var(--teal-rgb), 0.25)',  badge:'ok'      },
  warn: { color:'var(--gold-vibrant)', bg:'rgba(var(--gold-vibrant-rgb), 0.10)', border:'rgba(var(--gold-vibrant-rgb), 0.28)', badge:'warn'  },
  fail: { color:'var(--ember)', bg:'rgba(var(--ember-rgb), 0.10)', border:'rgba(var(--ember-rgb), 0.25)', badge:'fail'   },
};

const TYPE_ICON = { database:'⬟', api:'◇', stream:'◎', batch:'▪' };

function Sparkline({ values, color, h=28, w=80 }) {
  if (!values || values.length < 2) return null;
  const min = Math.min(...values), max = Math.max(...values);
  const range = max - min || 1;
  const pts = values.map((v, i) => {
    const x = (i / (values.length - 1)) * w;
    const y = h - ((v - min) / range) * (h - 4) - 2;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(' ');
  // Detect spikes
  const mean = values.reduce((s, v) => s + v, 0) / values.length;
  const spikeColor = max > mean * 3 ? 'var(--ember-vibrant)' : color;
  return (
    <svg width={w} height={h} style={{ display:'block' }}>
      <polyline points={pts} fill="none" stroke={color} strokeWidth={1.5}
        strokeLinejoin="round" strokeLinecap="round" />
      {values.map((v, i) => {
        if (v < mean * 2.5) return null;
        const x = (i / (values.length - 1)) * w;
        const y = h - ((v - min) / range) * (h - 4) - 2;
        return <circle key={i} cx={x} cy={y} r={3} fill={spikeColor} />;
      })}
    </svg>
  );
}

function BudgetGauge({ pct, color }) {
  const angle = (pct / 100) * 180;
  const r = 22, cx = 30, cy = 28;
  // Half-circle arc, bottom half
  function pt(deg) {
    const rad = (180 - deg) * Math.PI / 180;
    return { x: cx + r * Math.cos(rad), y: cy - r * Math.sin(rad) };
  }
  const start = pt(0), end = pt(180);
  const filled = pt(angle);
  const large = angle > 90 ? 1 : 0;
  return (
    <svg width={60} height={32} style={{ display:'block' }}>
      {/* Track */}
      <path d={`M ${start.x} ${start.y} A ${r} ${r} 0 1 1 ${end.x} ${end.y}`}
        fill="none" stroke="rgba(var(--ink-rgb), 0.1)" strokeWidth={5} strokeLinecap="round" />
      {/* Fill */}
      {pct > 0 && (
        <path d={`M ${start.x} ${start.y} A ${r} ${r} 0 ${large} 1 ${filled.x} ${filled.y}`}
          fill="none" stroke={color} strokeWidth={5} strokeLinecap="round" />
      )}
      {/* Label */}
      <text x={cx} y={cy+2} textAnchor="middle" fontSize={9}
        fontFamily='"IBM Plex Mono",monospace' fontWeight={700} fill={color}>
        {pct.toFixed(0)}%
      </text>
    </svg>
  );
}

function ConnectorCard({ conn, selected, onSelect }) {
  const cfg = CONN_STATUS[conn.status];
  const isSel = selected === conn.id;

  function fmtLatency(ms) {
    return ms >= 1000 ? `${(ms/1000).toFixed(1)}s` : `${ms}ms`;
  }

  return (
    <InteractiveCard
      onClick={() => onSelect(isSel ? null : conn.id)}
      selected={isSel}
      ariaLabel={`Toggle connector ${conn.name}. Status ${conn.status}. Protocol ${conn.protocol}.`}
      style={{
        padding:'16px', borderRadius:18, cursor:'pointer',
        background: isSel ? cfg.bg : 'rgba(var(--white-rgb), 0.56)',
        border: `1.5px solid ${isSel ? cfg.color : 'rgba(var(--ink-rgb), 0.08)'}`,
        boxShadow: isSel ? `0 0 0 2px ${cfg.border}` : 'none',
        transition:'all 160ms',
      }}
    >
      {/* Header */}
      <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:10 }}>
        <div>
          <div style={{ display:'flex', alignItems:'center', gap:7, marginBottom:3 }}>
            <span style={{ fontSize:13, color:cfg.color, opacity:0.8 }}>{TYPE_ICON[conn.type]}</span>
            <span style={{ fontSize:13, fontWeight:800, color:'var(--ink)', letterSpacing:'-0.02em' }}>{conn.name}</span>
          </div>
          <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:'rgba(var(--slate-rgb), 0.65)', letterSpacing:'0.08em' }}>
            {conn.protocol.toUpperCase()}
          </span>
        </div>
        <Badge kind={cfg.badge}>{conn.status}</Badge>
      </div>

      {/* Latency fingerprint */}
      <div style={{ marginBottom:10 }}>
        <div style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.6)', marginBottom:4, letterSpacing:'0.08em' }}>
          LATENCY FINGERPRINT (last 8 pulls)
        </div>
        <Sparkline values={conn.pulls} color={cfg.color} />
      </div>

      {/* Key metrics */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, marginBottom:10 }}>
        <div>
          <div style={{ fontSize:8, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.6)', letterSpacing:'0.08em', marginBottom:2 }}>P50 / P95</div>
          <div style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, fontWeight:700, color:cfg.color }}>
            {fmtLatency(conn.p50)} / {fmtLatency(conn.p95)}
          </div>
        </div>
        <div>
          <div style={{ fontSize:8, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.6)', letterSpacing:'0.08em', marginBottom:2 }}>COST</div>
          <div style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, fontWeight:700, color:'var(--ink)' }}>
            {conn.costPer}
          </div>
        </div>
      </div>

      {/* Error budget + last green */}
      <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:8 }}>
        <BudgetGauge pct={conn.errorBudget} color={cfg.color} />
        <div>
          <div style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.6)', letterSpacing:'0.06em', marginBottom:2 }}>ERROR BUDGET</div>
          <div style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, fontWeight:700, color:cfg.color }}>{conn.errorBudget}% remaining</div>
          <div style={{ fontSize:10, color:'rgba(var(--slate-rgb), 0.7)', marginTop:2 }}>
            Last green: <strong>{conn.lastGreen}</strong>
          </div>
        </div>
      </div>

      {/* Retry profile */}
      <div style={{
        padding:'6px 9px', borderRadius:8,
        background:'rgba(var(--ink-rgb), 0.04)', border:'1px solid rgba(var(--ink-rgb), 0.07)',
        fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:'rgba(var(--slate-rgb), 0.75)',
        letterSpacing:'0.04em',
      }}>
        ↺ {conn.retryProfile}
      </div>

      {/* Expanded description */}
      {isSel && (
        <div style={{ marginTop:10, paddingTop:10, borderTop:'1px solid rgba(var(--ink-rgb), 0.08)', fontSize:11, color:'var(--slate)', lineHeight:1.55 }}>
          {conn.desc}
        </div>
      )}
    </InteractiveCard>
  );
}

function ConnectorCardsScreen() {
  const [selected, setSelected] = React.useState(null);
  const [filter,   setFilter]   = React.useState('all');

  const filtered = filter === 'all' ? CONNECTORS : CONNECTORS.filter(c => c.status === filter);
  const counts = { ok:0, warn:0, fail:0 };
  CONNECTORS.forEach(c => counts[c.status]++);

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:14, height:'100%' }}>

      {/* Toolbar */}
      <div style={{ display:'flex', alignItems:'center', gap:8 }}>
        <Eyebrow>B2 · Connector Character Cards</Eyebrow>
        <div style={{ flex:1 }} />
        {['all','ok','warn','fail'].map(f => (
          <button type="button" key={f} onClick={() => setFilter(f)}
            style={{
              padding:'4px 11px', borderRadius:999, border:'none', cursor:'pointer',
              fontFamily:'"IBM Plex Mono",monospace', fontSize:9, fontWeight:700, letterSpacing:'0.08em',
              background: filter === f
                ? (f==='ok'?'rgba(var(--teal-rgb), 0.15)':f==='warn'?'rgba(var(--gold-vibrant-rgb), 0.15)':f==='fail'?'rgba(var(--ember-rgb), 0.13)':'rgba(var(--ink-rgb), 0.08)')
                : 'rgba(var(--white-rgb), 0.6)',
              color: f==='ok'?'var(--teal)':f==='warn'?'var(--gold-vibrant)':f==='fail'?'var(--ember)':'var(--slate)',
              boxShadow: filter === f ? '0 0 0 1px rgba(var(--ink-rgb), 0.12)' : 'none',
            }}>
            {f === 'all' ? `ALL (${CONNECTORS.length})` : `${f.toUpperCase()} (${counts[f]})`}
          </button>
        ))}
      </div>

      {/* Card grid */}
      <div style={{ flex:1, overflowY:'auto' }}>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(290px,1fr))', gap:14 }}>
          {filtered.map(conn => (
            <ConnectorCard key={conn.id} conn={conn} selected={selected} onSelect={setSelected} />
          ))}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { ConnectorCardsScreen });
