// CounterfactualExplorer.jsx — E4
// What-if: flip one feature at a time and see the decision boundary move
// Exports: CounterfactualExplorerScreen

const BASE_APPLICANT = {
  income_quartile: 1,          // Q1=1..Q4=4
  employment_months: 14,
  municipality_type: 'urban',
  age: 34,
  household_size: 3,
  prior_benefit: false,
  gdp_growth_region: 2.1,      // %
  fiscal_year: 2024,
};

const FEATURE_META = {
  income_quartile:    { label:'Income quartile',       type:'select', options:[1,2,3,4], display:v=>`Q${v}`,      shap:-0.11, impact:'high'   },
  employment_months:  { label:'Employment (months)',   type:'slider', min:0, max:60,    display:v=>`${v}mo`,      shap:+0.18, impact:'high'   },
  municipality_type:  { label:'Region type',           type:'select', options:['urban','peri-urban','rural','remote'], display:v=>v, shap:+0.07, impact:'medium' },
  age:                { label:'Age',                   type:'slider', min:18, max:65,   display:v=>`${v}`,        shap:+0.04, impact:'medium' },
  household_size:     { label:'Household size',        type:'slider', min:1, max:8,     display:v=>`${v}`,        shap:+0.03, impact:'low'    },
  prior_benefit:      { label:'Prior benefit history', type:'toggle',                   display:v=>v?'Yes':'No',  shap:-0.02, impact:'low'    },
  gdp_growth_region:  { label:'Regional GDP growth',   type:'slider', min:-2, max:8, step:0.1, display:v=>`${v.toFixed(1)}%`, shap:+0.02, impact:'low' },
};

// Logistic-ish scoring function (purely illustrative, consistent with story)
function score(feat) {
  let s = 0.52; // base
  s += (feat.income_quartile - 1) * 0.085;
  s += Math.min(feat.employment_months / 60, 1) * 0.16;
  s += { urban:0.04, 'peri-urban':0.02, rural:-0.02, remote:-0.06 }[feat.municipality_type] || 0;
  s += (feat.age < 30 ? -0.02 : feat.age > 55 ? -0.03 : 0.01);
  s += (feat.household_size - 3) * 0.008;
  s += feat.prior_benefit ? -0.04 : 0.01;
  s += (feat.gdp_growth_region - 2) * 0.008;
  return Math.max(0.05, Math.min(0.98, s));
}

const THRESHOLD = 0.60;

function FeatureSlider({ feat, meta, value, onChange }) {
  if (meta.type === 'slider') {
    return (
      <div style={{ flex:1 }}>
        <input type="range" min={meta.min} max={meta.max} step={meta.step||1} value={value}
          onChange={e => onChange(meta.step ? parseFloat(e.target.value) : parseInt(e.target.value))}
          style={{ width:'100%', accentColor:'var(--teal-vibrant)' }} />
        <div style={{ display:'flex', justifyContent:'space-between' }}>
          <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:8, color:'rgba(var(--slate-rgb), 0.4)' }}>{meta.min}</span>
          <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:8, color:'rgba(var(--slate-rgb), 0.4)' }}>{meta.max}</span>
        </div>
      </div>
    );
  }
  if (meta.type === 'select') {
    return (
      <select value={value} onChange={e => {
        const v = meta.options[0] === 1 ? parseInt(e.target.value) : e.target.value;
        onChange(v);
      }}
        style={{ fontFamily:'Manrope,sans-serif', fontSize:12, border:'1px solid rgba(var(--ink-rgb), 0.1)',
          borderRadius:8, padding:'4px 8px', background:'rgba(var(--white-rgb), 0.7)', color:'var(--ink)', flex:1 }}>
        {meta.options.map(o => <option key={o} value={o}>{meta.display(o)}</option>)}
      </select>
    );
  }
  if (meta.type === 'toggle') {
    return (
      <button type="button" onClick={() => onChange(!value)}
        style={{ padding:'5px 12px', borderRadius:999, border:`1px solid ${value?'rgba(var(--teal-rgb), 0.4)':'rgba(var(--ink-rgb), 0.1)'}`,
          background: value ? 'rgba(var(--teal-rgb), 0.12)':'rgba(var(--white-rgb), 0.65)',
          color: value ? 'var(--teal)':'var(--slate)', cursor:'pointer',
          fontFamily:'Manrope,sans-serif', fontSize:12, fontWeight:600 }}>
        {value ? 'Yes':'No'}
      </button>
    );
  }
  return null;
}

function CounterfactualExplorerScreen() {
  const [feat, setFeat]           = React.useState({ ...BASE_APPLICANT });
  const [flipped, setFlipped]     = React.useState({});

  const baseScore = score(BASE_APPLICANT);
  const curScore  = score(feat);
  const baseDecision = baseScore >= THRESHOLD;
  const curDecision  = curScore  >= THRESHOLD;
  const flipped_decision = baseDecision !== curDecision;

  function resetFeat(key) {
    setFeat(f => ({ ...f, [key]: BASE_APPLICANT[key] }));
    setFlipped(f => { const n={...f}; delete n[key]; return n; });
  }
  function updateFeat(key, val) {
    setFeat(f => ({ ...f, [key]: val }));
    if (val !== BASE_APPLICANT[key]) {
      setFlipped(f => ({ ...f, [key]: val }));
    } else {
      setFlipped(f => { const n={...f}; delete n[key]; return n; });
    }
  }
  function resetAll() { setFeat({ ...BASE_APPLICANT }); setFlipped({}); }

  const margin = curScore - THRESHOLD;
  const marginColor = curDecision ? 'var(--teal)' : 'var(--ember)';

  // Counterfactual: find minimal single-feature flip to change decision
  const cfSuggestions = Object.entries(FEATURE_META)
    .map(([key, meta]) => {
      if (!curDecision) {
        // suggest increasing to flip to approve
        if (meta.type === 'slider') {
          const target = meta.max;
          const testFeat = { ...feat, [key]: target };
          if (score(testFeat) >= THRESHOLD) return { key, meta, fromVal:feat[key], toVal:target, newScore:score(testFeat) };
        }
        if (meta.type === 'select' && meta.options[0] === 1) {
          for (const opt of [2,3,4]) {
            const testFeat = { ...feat, [key]: opt };
            if (score(testFeat) >= THRESHOLD) return { key, meta, fromVal:feat[key], toVal:opt, newScore:score(testFeat) };
          }
        }
      }
      return null;
    })
    .filter(Boolean)
    .slice(0, 3);

  return (
    <div style={{ display:'flex', gap:20, height:'100%' }}>

      {/* Feature editor */}
      <Panel style={{ width:300, flexShrink:0 }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:16 }}>
          <PanelHeader eyebrow="E4 · Counterfactual Explorer" title="Edit features" />
          <Button variant="ghost" size="sm" onClick={resetAll}>Reset</Button>
        </div>

        {Object.entries(FEATURE_META).map(([key, meta]) => {
          const isChanged = feat[key] !== BASE_APPLICANT[key];
          const impColor = meta.impact === 'high' ? 'var(--ember)' : meta.impact === 'medium' ? 'var(--gold-vibrant)' : 'var(--slate)';
          return (
            <div key={key} style={{ marginBottom:14, padding:'10px 12px', borderRadius:13,
              background: isChanged ? 'rgba(var(--teal-vibrant-rgb), 0.07)' : 'transparent',
              border:`1px solid ${isChanged ? 'rgba(var(--teal-vibrant-rgb), 0.22)':'transparent'}`,
              transition:'all 140ms' }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:6 }}>
                <div style={{ display:'flex', gap:7, alignItems:'center' }}>
                  <span style={{ fontSize:12, fontWeight:600, color:'var(--ink)' }}>{meta.label}</span>
                  <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:8, fontWeight:700, color:impColor, letterSpacing:'0.06em' }}>{meta.impact.toUpperCase()}</span>
                </div>
                <div style={{ display:'flex', gap:8, alignItems:'center' }}>
                  <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:12, fontWeight:700, color: isChanged ? 'var(--teal-vibrant)':'rgba(var(--slate-rgb), 0.7)' }}>
                    {meta.display(feat[key])}
                  </span>
                  {isChanged && (
                    <button type="button" onClick={() => resetFeat(key)}
                      style={{ fontSize:10, color:'rgba(var(--slate-rgb), 0.5)', background:'none', border:'none', cursor:'pointer', padding:0 }}>↩</button>
                  )}
                </div>
              </div>
              <div style={{ display:'flex', gap:8, alignItems:'center' }}>
                <FeatureSlider feat={feat} meta={meta} value={feat[key]} onChange={v => updateFeat(key, v)} />
              </div>
              {isChanged && (
                <div style={{ fontSize:10, color:'rgba(var(--slate-rgb), 0.55)', marginTop:4, fontFamily:'"IBM Plex Mono",monospace' }}>
                  was: {meta.display(BASE_APPLICANT[key])}
                </div>
              )}
            </div>
          );
        })}
      </Panel>

      {/* Decision meter + counterfactuals */}
      <div style={{ flex:1, display:'flex', flexDirection:'column', gap:14 }}>

        {/* Decision comparison */}
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:14 }}>
          {/* Original */}
          <Panel style={{ background:'rgba(var(--white-rgb), 0.56)' }}>
            <Eyebrow style={{ marginBottom:8 }}>Original applicant</Eyebrow>
            <div style={{ display:'flex', alignItems:'center', gap:14 }}>
              <div>
                <div style={{ fontSize:32, fontWeight:800, letterSpacing:'-0.04em', color: baseDecision ? 'var(--teal)':'var(--ember)' }}>
                  {(baseScore*100).toFixed(1)}%
                </div>
                <div style={{ fontSize:11, color:'rgba(var(--slate-rgb), 0.7)' }}>confidence</div>
              </div>
              <Badge kind={baseDecision?'ok':'fail'}>{baseDecision ? 'APPROVED':'REJECTED'}</Badge>
            </div>
            <div style={{ height:6, borderRadius:999, background:'rgba(var(--ink-rgb), 0.08)', overflow:'hidden', marginTop:10, position:'relative' }}>
              <div style={{ height:'100%', borderRadius:999, background: baseDecision?'var(--teal-vibrant)':'var(--ember-vibrant)', width:`${(baseScore*100).toFixed(0)}%` }} />
              <div style={{ position:'absolute', top:0, bottom:0, width:2, left:`${THRESHOLD*100}%`, background:'rgba(var(--ink-rgb), 0.4)', borderRadius:1 }} />
            </div>
          </Panel>

          {/* Counterfactual */}
          <Panel style={{ background: flipped_decision
            ? (curDecision ? 'rgba(var(--teal-rgb), 0.10)':'rgba(var(--ember-rgb), 0.10)')
            : 'rgba(var(--white-rgb), 0.56)' }}>
            <Eyebrow style={{ marginBottom:8 }}>Counterfactual</Eyebrow>
            <div style={{ display:'flex', alignItems:'center', gap:14 }}>
              <div>
                <div style={{ fontSize:32, fontWeight:800, letterSpacing:'-0.04em', color: curDecision ? 'var(--teal)':'var(--ember)' }}>
                  {(curScore*100).toFixed(1)}%
                </div>
                <div style={{ fontSize:11, color:'rgba(var(--slate-rgb), 0.7)' }}>confidence</div>
              </div>
              <div style={{ display:'flex', flexDirection:'column', gap:5 }}>
                <Badge kind={curDecision?'ok':'fail'}>{curDecision ? 'APPROVED':'REJECTED'}</Badge>
                {flipped_decision && <Badge kind={curDecision?'ok':'fail'}>DECISION FLIPPED</Badge>}
              </div>
            </div>
            <div style={{ height:6, borderRadius:999, background:'rgba(var(--ink-rgb), 0.08)', overflow:'hidden', marginTop:10, position:'relative' }}>
              <div style={{ height:'100%', borderRadius:999, background: curDecision?'var(--teal-vibrant)':'var(--ember-vibrant)', width:`${(curScore*100).toFixed(0)}%`, transition:'width 300ms' }} />
              <div style={{ position:'absolute', top:0, bottom:0, width:2, left:`${THRESHOLD*100}%`, background:'rgba(var(--ink-rgb), 0.4)', borderRadius:1 }} />
            </div>
            <div style={{ display:'flex', justifyContent:'space-between', marginTop:4 }}>
              <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:'rgba(var(--slate-rgb), 0.5)' }}>threshold {(THRESHOLD*100).toFixed(0)}%</span>
              <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, fontWeight:700, color:marginColor }}>
                {margin >= 0 ? '+':''}{(margin*100).toFixed(1)}pp margin
              </span>
            </div>
          </Panel>
        </div>

        {/* Changed features */}
        {Object.keys(flipped).length > 0 && (
          <Panel>
            <Eyebrow style={{ marginBottom:10 }}>Feature changes</Eyebrow>
            <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(200px,1fr))', gap:8 }}>
              {Object.entries(flipped).map(([key, val]) => {
                const meta = FEATURE_META[key];
                const shapSign = meta.shap > 0 ? '+' : '';
                return (
                  <div key={key} style={{ padding:'9px 12px', borderRadius:12,
                    background:'rgba(var(--teal-vibrant-rgb), 0.08)', border:'1px solid rgba(var(--teal-vibrant-rgb), 0.2)' }}>
                    <div style={{ fontSize:10, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.6)', marginBottom:3 }}>{meta.label}</div>
                    <div style={{ display:'flex', justifyContent:'space-between' }}>
                      <div>
                        <span style={{ fontSize:11, color:'rgba(var(--slate-rgb), 0.5)', textDecoration:'line-through' }}>{meta.display(BASE_APPLICANT[key])}</span>
                        <span style={{ fontSize:13, fontWeight:700, color:'var(--teal-vibrant)', marginLeft:8 }}>→ {meta.display(val)}</span>
                      </div>
                      <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, color:'rgba(var(--slate-rgb), 0.55)' }}>SHAP {shapSign}{meta.shap.toFixed(2)}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </Panel>
        )}

        {/* Minimal counterfactual suggestions */}
        {!curDecision && cfSuggestions.length > 0 && (
          <Panel style={{ background:'rgba(var(--teal-rgb), 0.06)', border:'1px solid rgba(var(--teal-rgb), 0.2)' }}>
            <Eyebrow style={{ marginBottom:10, color:'rgba(var(--teal-rgb), 0.8)' }}>Minimal counterfactuals to approve</Eyebrow>
            {cfSuggestions.map(cf => (
              <div key={cf.key} style={{ display:'flex', justifyContent:'space-between', alignItems:'center',
                padding:'8px 12px', borderRadius:11, marginBottom:7, background:'rgba(var(--white-rgb), 0.55)', border:'1px solid rgba(var(--teal-rgb), 0.15)' }}>
                <div>
                  <span style={{ fontSize:12, fontWeight:600, color:'var(--teal)' }}>{cf.meta.label}</span>
                  <span style={{ fontSize:11, color:'rgba(var(--slate-rgb), 0.7)', marginLeft:10 }}>
                    {cf.meta.display(cf.fromVal)} → {cf.meta.display(cf.toVal)}
                  </span>
                </div>
                <div style={{ display:'flex', gap:10, alignItems:'center' }}>
                  <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, fontWeight:700, color:'var(--teal)' }}>
                    {(cf.newScore*100).toFixed(1)}%
                  </span>
                  <button type="button" onClick={() => updateFeat(cf.key, cf.toVal)}
                    style={{ padding:'4px 10px', borderRadius:999, border:'1px solid rgba(var(--teal-rgb), 0.3)',
                      background:'rgba(var(--teal-rgb), 0.12)', color:'var(--teal)', cursor:'pointer',
                      fontFamily:'Manrope,sans-serif', fontSize:11, fontWeight:700 }}>
                    Apply
                  </button>
                </div>
              </div>
            ))}
          </Panel>
        )}
      </div>
    </div>
  );
}

Object.assign(window, { CounterfactualExplorerScreen });
