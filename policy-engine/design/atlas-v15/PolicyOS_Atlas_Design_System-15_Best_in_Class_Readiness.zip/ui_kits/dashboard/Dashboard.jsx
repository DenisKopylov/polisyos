// Dashboard.jsx — Command Center screen

function MiniBar({ value, max, color='var(--teal-vibrant)' }) {
  return (
    <div style={{height:8,borderRadius:999,background:'rgba(var(--ink-rgb), 0.07)',overflow:'hidden'}}>
      <div style={{height:'100%',width:`${Math.round((value/max)*100)}%`,background:color,borderRadius:'inherit',transition:'width 0.4s ease'}} />
    </div>
  );
}

function ChartBar({ label, value, max, color='var(--teal-vibrant)' }) {
  const pct = Math.round((value / max) * 100);
  return (
    <div style={{display:'flex',alignItems:'center',gap:10}}>
      <span style={{fontSize:12,color:'rgba(var(--ink-rgb), 0.65)',width:120,flexShrink:0,fontWeight:600}}>{label}</span>
      <div style={{flex:1,height:14,borderRadius:999,background:'rgba(var(--teal-vibrant-rgb), 0.1)',overflow:'hidden'}}>
        <div style={{height:'100%',width:`${pct}%`,background:color,borderRadius:'inherit'}} />
      </div>
      <span style={{fontSize:12,fontFamily:'"IBM Plex Mono",monospace',color:'rgba(var(--ink-rgb), 0.65)',width:32,textAlign:'right'}}>{value}</span>
    </div>
  );
}

function DashboardScreen({ onSelectRun }) {
  const runs = [
    { runId:'fiscal_reform_q2_001', status:'running',  duration:'12.3s',  artifacts:38 },
    { runId:'transport_subsidy_003', status:'blocked',  duration:'8.1s',   artifacts:21 },
    { runId:'housing_policy_v4',    status:'success',  duration:'24.7s',  artifacts:64 },
    { runId:'energy_transition_007', status:'pending',  duration:'—',      artifacts:0  },
  ];

  const sources = [
    { label:'World Bank',   value:1842, color:'var(--teal-vibrant)' },
    { label:'Ukrstat',      value:1203, color:'var(--teal-vibrant)' },
    { label:'IMF Fiscal',   value:984,  color:'var(--gold-vibrant)' },
    { label:'OECD Policy',  value:672,  color:'var(--teal-vibrant)' },
    { label:'Cabinet Docs', value:441,  color:'var(--ember-vibrant)' },
    { label:'NBU Data',     value:318,  color:'var(--teal-vibrant)' },
  ];

  return (
    <div className="atlas-dashboard-stack">

      {/* Hero + Queue */}
      <div className="atlas-dashboard-hero-grid">
        <Panel hero>
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'flex-start', gap:16, flexWrap:'wrap', marginBottom:16}}>
            <div>
              <Eyebrow style={{marginBottom:6}}>Command Center</Eyebrow>
              <h1 style={{margin:0, fontSize:36, fontWeight:800, lineHeight:1.05, letterSpacing:'-0.04em'}}>Atlas Control Room</h1>
              <p style={{margin:'8px 0 0', fontSize:14, color:'rgba(var(--ink-rgb), 0.68)', lineHeight:1.6, maxWidth:520}}>
                AI-driven policy simulation engine. 7 active runs across fiscal, transport, and energy domains.
              </p>
            </div>
            <div style={{display:'flex', gap:8, flexWrap:'wrap', alignItems:'center'}}>
              <Badge kind="ok">● System OK</Badge>
              <Badge kind="info">↗ Live</Badge>
              <Badge kind="warn">◷ 2 Stale</Badge>
            </div>
          </div>
          <div style={{background:'rgba(var(--white-rgb), 0.56)', border:'1px solid rgba(var(--ink-rgb), 0.07)', borderRadius:18, padding:'16px 18px'}}>
            <p style={{margin:'0 0 12px', fontSize:13, color:'rgba(var(--ink-rgb), 0.65)', lineHeight:1.6}}>
              3 decision packets await review. Evidence freshness declining on 2 IMF sources. All governance passes nominal.
            </p>
            <div className="atlas-dashboard-mini-grid">
              {[
                {label:'Active Runs',   val:'7'},
                {label:'Decision Queue', val:'3'},
                {label:'Avg Duration',  val:'18.4s'},
              ].map(m => (
                <div key={m.label}>
                  <span style={{fontSize:10,textTransform:'uppercase',letterSpacing:'0.08em',color:'rgba(var(--ink-rgb), 0.56)'}}>{m.label}</span>
                  <strong style={{display:'block',fontSize:24,fontWeight:800,letterSpacing:'-0.04em',marginTop:4}}>{m.val}</strong>
                </div>
              ))}
            </div>
          </div>
        </Panel>

        <Panel style={{display:'flex', flexDirection:'column', gap:14}}>
          <PanelHeader eyebrow="Operator Queue" title="Action Queue" />
          <div style={{display:'grid', gap:8}}>
            {runs.map(r => (
              <RunCard key={r.runId} {...r} onClick={() => onSelectRun(r.runId)} />
            ))}
          </div>
          <Button variant="ghost" style={{marginTop:'auto', width:'100%', justifyContent:'center'}}>View all runs →</Button>
        </Panel>
      </div>

      {/* Metrics strip */}
      <div className="atlas-dashboard-kpi-grid">
        <MetricCard label="Active Runs"    value="7"   hint="3 in governance review" badge={<Badge kind="warn">Active</Badge>} />
        <MetricCard label="Blocked"        value="2"   hint="require immediate attention" color="var(--ember)" badge={<Badge kind="fail">Blocked</Badge>} />
        <MetricCard label="Success Rate"   value="91%" hint="of 48 runs this week" />
        <MetricCard label="Evidence Docs"  value="1.2k" hint="added in last run" />
      </div>

      {/* Charts row */}
      <div className="atlas-dashboard-chart-grid">
        <Panel>
          <PanelHeader eyebrow="Data Coverage" title="Source Coverage" />
          <div style={{display:'grid', gap:10}}>
            {sources.map(s => <ChartBar key={s.label} label={s.label} value={s.value} max={2000} color={s.color} />)}
          </div>
        </Panel>

        <Panel>
          <PanelHeader eyebrow="Governance" title="Pass/Fail" />
          <div style={{display:'grid', gap:10, marginTop:4}}>
            {[
              {label:'WCAG Audit',      status:'ok',   note:'Passed'},
              {label:'Evidence Gate',   status:'ok',   note:'Passed'},
              {label:'Causal ID Check', status:'ok',   note:'Passed'},
              {label:'IMF Transport',   status:'warn',  note:'Under review'},
              {label:'GDPR Scope',      status:'fail',  note:'Blocked'},
            ].map(g => (
              <div key={g.label} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'10px 0',borderTop:'1px solid rgba(var(--ink-rgb), 0.08)'}}>
                <div style={{display:'flex',alignItems:'center',gap:8}}>
                  <img src={`../../assets/glyphs/${g.status==='ok'?'governance-pass':g.status==='warn'?'freshness':'blocker'}.svg`}
                    width={14} height={14} style={{opacity:0.7}}/>
                  <span style={{fontSize:13,fontWeight:600}}>{g.label}</span>
                </div>
                <Badge kind={g.status}>{g.note}</Badge>
              </div>
            ))}
          </div>
        </Panel>
      </div>
    </div>
  );
}

Object.assign(window, { DashboardScreen });
