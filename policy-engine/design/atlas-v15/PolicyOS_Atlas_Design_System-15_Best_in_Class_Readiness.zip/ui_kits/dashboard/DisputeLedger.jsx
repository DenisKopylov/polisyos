// DisputeLedger.jsx — C1
// Challenge/response timeline: immutable log of disputes against policy decisions
// Exports: DisputeLedgerScreen

const DISPUTES = [
  {
    id:'DSP-2024-041', decision:'D-Q3-001', status:'resolved', severity:'high',
    opened:'2024-09-02', closed:'2024-09-18', duration:'16 days',
    challenger:'Ministry of Finance', respondent:'Policy Engine',
    grounds:'Outcome Fairness',
    summary:'Disbursement approval rates for Q1-income cohort 34% below Q4-cohort. Ministry contends model applies unlawful proxy discrimination via income_quartile feature.',
    timeline:[
      { date:'2024-09-02', actor:'Ministry of Finance', type:'challenge', text:'Formal dispute filed. Requests explanation of income-stratified approval disparity.' },
      { date:'2024-09-05', actor:'Policy Engine',       type:'response', text:'Acknowledged. Causal audit initiated. Preliminary E-value 1.4 — borderline.' },
      { date:'2024-09-10', actor:'Independent Auditor', type:'finding',  text:'Disparate impact confirmed: CATE ratio 1.34 (Q1 vs Q4). Marginal SHAP contribution of income_quartile: 0.18.' },
      { date:'2024-09-14', actor:'Policy Engine',       type:'action',   text:'Feature weight of income_quartile reduced by 40%. Re-run on Q2 2024 cohort commissioned.' },
      { date:'2024-09-18', actor:'Ministry of Finance', type:'close',    text:'Dispute closed. Resolution accepted pending next quarterly audit.' },
    ],
    resolution:'Feature recalibration applied. Monitoring dashboard active.',
  },
  {
    id:'DSP-2024-038', decision:'D-Q3-002', status:'open', severity:'medium',
    opened:'2024-09-21', closed:null, duration:'ongoing',
    challenger:'Regional Gov. Kyiv', respondent:'Policy Engine',
    grounds:'Data Completeness',
    summary:'Kyiv region records show 6.2% missing employment_status values since batch update on Sep 20. 842 decisions affected. Regional government requests re-adjudication.',
    timeline:[
      { date:'2024-09-21', actor:'Regional Gov. Kyiv', type:'challenge', text:'Formal dispute filed. References ETL regression identified in drift report B5.' },
      { date:'2024-09-23', actor:'Policy Engine',      type:'response',  text:'Root cause confirmed: Employment Registry SFTP job failed silently on Sep 19. Patch deployed Sep 22.' },
      { date:'2024-09-25', actor:'Policy Engine',      type:'action',    text:'Re-adjudication queued for 842 affected records. Expected completion: Oct 3.' },
    ],
    resolution:null,
  },
  {
    id:'DSP-2024-029', decision:'RUN-fiscal-001', status:'rejected', severity:'low',
    opened:'2024-08-14', closed:'2024-08-22', duration:'8 days',
    challenger:'Civil Society Observer', respondent:'Policy Engine',
    grounds:'Model Transparency',
    summary:'Request for full SHAP attribution on all Q2 disbursement decisions. Policy Engine invoked commercial confidentiality on third-party model components.',
    timeline:[
      { date:'2024-08-14', actor:'Civil Society Observer', type:'challenge', text:'Requests SHAP attributions for all 42,180 Q2 decisions under Access to Information Act.' },
      { date:'2024-08-17', actor:'Policy Engine',          type:'response',  text:'Partial disclosure provided: aggregate SHAP summary statistics, top-5 features by cohort.' },
      { date:'2024-08-20', actor:'Civil Society Observer', type:'challenge', text:'Partial disclosure insufficient. Full individual-level explanations requested.' },
      { date:'2024-08-22', actor:'Legal Review Board',     type:'close',     text:'Dispute rejected. Individual SHAP values constitute proprietary inference outputs. Aggregate disclosure sufficient under current regulation.' },
    ],
    resolution:'Partial SHAP disclosure accepted. Regulatory guidance under review.',
  },
];

const DISP_STATUS = {
  open:     { color:'var(--gold-vibrant)', bg:'rgba(var(--gold-vibrant-rgb), 0.12)', border:'rgba(var(--gold-vibrant-rgb), 0.32)', badge:'warn',    label:'Open'     },
  resolved: { color:'var(--teal)', bg:'rgba(var(--teal-rgb), 0.11)',   border:'rgba(var(--teal-rgb), 0.28)',   badge:'ok',      label:'Resolved' },
  rejected: { color:'var(--slate)', bg:'rgba(var(--slate-rgb), 0.09)',   border:'rgba(var(--slate-rgb), 0.22)',   badge:'neutral', label:'Rejected' },
};

const SEV_CFG = {
  high:   { color:'var(--ember)', label:'High'   },
  medium: { color:'var(--gold-vibrant)', label:'Medium' },
  low:    { color:'var(--slate)', label:'Low'    },
};

const EVENT_TYPE = {
  challenge: { symbol:'!', color:'var(--ember)', bg:'rgba(var(--ember-rgb), 0.12)', label:'Challenge' },
  response:  { symbol:'↩', color:'var(--teal)', bg:'rgba(var(--teal-rgb), 0.10)',  label:'Response'  },
  finding:   { symbol:'◆', color:'var(--chart-secondary)', bg:'rgba(var(--blue-rgb), 0.11)', label:'Finding'   },
  action:    { symbol:'⚙', color:'var(--gold)', bg:'rgba(var(--gold-rgb), 0.11)', label:'Action'    },
  close:     { symbol:'✓', color:'var(--teal)', bg:'rgba(var(--teal-rgb), 0.12)',  label:'Closed'    },
};

function DisputeLedgerScreen() {
  const [selId, setSelId]     = React.useState('DSP-2024-041');
  const [filter, setFilter]   = React.useState('all');

  const visible = filter === 'all' ? DISPUTES : DISPUTES.filter(d => d.status === filter);
  const sel     = DISPUTES.find(d => d.id === selId);

  return (
    <div style={{ display:'flex', gap:20, height:'100%' }}>

      {/* Dispute list */}
      <div style={{ width:260, flexShrink:0, display:'flex', flexDirection:'column', gap:10 }}>
        <Eyebrow>C1 · Dispute Ledger</Eyebrow>

        {/* Filter */}
        <div style={{ display:'flex', gap:6 }}>
          {['all','open','resolved','rejected'].map(f => (
            <button type="button" key={f} onClick={() => setFilter(f)}
              style={{
                flex:1, padding:'4px 0', borderRadius:999, border:'none', cursor:'pointer',
                fontFamily:'"IBM Plex Mono",monospace', fontSize:9, fontWeight:700, letterSpacing:'0.06em',
                background: filter===f ? 'rgba(var(--ink-rgb), 0.1)':'rgba(var(--white-rgb), 0.6)',
                color: filter===f ? 'var(--ink)':'rgba(var(--slate-rgb), 0.7)',
              }}>
              {f.toUpperCase()}
            </button>
          ))}
        </div>

        {visible.map(d => {
          const cfg = DISP_STATUS[d.status];
          const sev = SEV_CFG[d.severity];
          const isSel = selId === d.id;
          return (
            <InteractiveCard key={d.id} onClick={() => setSelId(d.id)} selected={isSel}
              ariaLabel={`Open dispute ${d.id}. ${d.grounds}. Status ${cfg.label}. Severity ${d.severity}.`}
              style={{
                padding:'12px 14px', borderRadius:16, cursor:'pointer',
                background: isSel ? cfg.bg : 'rgba(var(--white-rgb), 0.56)',
                border:`1.5px solid ${isSel ? cfg.color : 'rgba(var(--ink-rgb), 0.08)'}`,
                transition:'all 150ms',
              }}>
              <div style={{ display:'flex', justifyContent:'space-between', marginBottom:4 }}>
                <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, fontWeight:700, color:'rgba(var(--slate-rgb), 0.6)', letterSpacing:'0.06em' }}>{d.id}</span>
                <Badge kind={cfg.badge}>{cfg.label}</Badge>
              </div>
              <div style={{ fontSize:12, fontWeight:700, color:'var(--ink)', lineHeight:1.35, marginBottom:4 }}>{d.grounds}</div>
              <div style={{ fontSize:11, color:'var(--slate)', lineHeight:1.4 }}>{d.challenger} vs {d.respondent}</div>
              <div style={{ display:'flex', justifyContent:'space-between', marginTop:6 }}>
                <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:'rgba(var(--slate-rgb), 0.55)' }}>{d.opened}</span>
                <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, fontWeight:700, color:sev.color }}>{d.severity.toUpperCase()}</span>
              </div>
            </InteractiveCard>
          );
        })}
      </div>

      {/* Timeline + detail */}
      {sel && (() => {
        const cfg = DISP_STATUS[sel.status];
        return (
          <div style={{ flex:1, minWidth:0, display:'flex', flexDirection:'column', gap:12 }}>

            {/* Header */}
            <Panel style={{ padding:'16px 20px' }}>
              <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', gap:14 }}>
                <div>
                  <div style={{ display:'flex', gap:8, alignItems:'center', marginBottom:6 }}>
                    <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, fontWeight:700, color:'rgba(var(--slate-rgb), 0.7)', letterSpacing:'0.08em' }}>{sel.id}</span>
                    <Badge kind={cfg.badge}>{cfg.label}</Badge>
                    <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, fontWeight:700, color:SEV_CFG[sel.severity].color }}>{sel.severity.toUpperCase()} SEVERITY</span>
                  </div>
                  <h3 style={{ margin:0, fontSize:20, fontWeight:800, letterSpacing:'-0.03em' }}>{sel.grounds}</h3>
                  <p style={{ margin:'5px 0 0', fontSize:13, color:'var(--slate)', lineHeight:1.55 }}>{sel.summary}</p>
                </div>
                <div style={{ flexShrink:0, display:'flex', flexDirection:'column', gap:6, alignItems:'flex-end' }}>
                  <div style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, color:'rgba(var(--slate-rgb), 0.6)' }}>Opened {sel.opened}</div>
                  {sel.closed && <div style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, color:'rgba(var(--slate-rgb), 0.6)' }}>Closed {sel.closed}</div>}
                  <div style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, fontWeight:700, color:cfg.color }}>{sel.duration}</div>
                </div>
              </div>
              <div style={{ display:'flex', gap:14, marginTop:12, paddingTop:12, borderTop:'1px solid rgba(var(--ink-rgb), 0.08)' }}>
                <div><span style={{ fontSize:10, color:'rgba(var(--slate-rgb), 0.6)' }}>Challenger · </span><strong style={{ fontSize:12, color:'var(--ink)' }}>{sel.challenger}</strong></div>
                <div><span style={{ fontSize:10, color:'rgba(var(--slate-rgb), 0.6)' }}>Respondent · </span><strong style={{ fontSize:12, color:'var(--ink)' }}>{sel.respondent}</strong></div>
                <div><span style={{ fontSize:10, color:'rgba(var(--slate-rgb), 0.6)' }}>Decision · </span><span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, fontWeight:700, color:'var(--teal)' }}>{sel.decision}</span></div>
              </div>
            </Panel>

            {/* Immutable timeline */}
            <Panel style={{ flex:1, padding:'16px 20px' }}>
              <Eyebrow style={{ marginBottom:16 }}>Immutable event log</Eyebrow>

              {sel.timeline.map((ev, i) => {
                const ecfg = EVENT_TYPE[ev.type];
                const isLast = i === sel.timeline.length - 1;
                return (
                  <div key={i} style={{ display:'flex', gap:14, marginBottom: isLast ? 0 : 22 }}>
                    {/* Timeline spine */}
                    <div style={{ display:'flex', flexDirection:'column', alignItems:'center', width:32, flexShrink:0 }}>
                      <div style={{
                        width:28, height:28, borderRadius:'50%', flexShrink:0,
                        background:ecfg.bg, border:`1.5px solid ${ecfg.color}`,
                        display:'flex', alignItems:'center', justifyContent:'center',
                        fontSize:13, color:ecfg.color, fontWeight:800,
                      }}>{ecfg.symbol}</div>
                      {!isLast && (
                        <div style={{ flex:1, width:1.5, background:'rgba(var(--ink-rgb), 0.1)', marginTop:4 }} />
                      )}
                    </div>
                    {/* Content */}
                    <div style={{ flex:1, paddingBottom: isLast ? 0 : 4 }}>
                      <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:4 }}>
                        <span style={{ fontSize:10, fontFamily:'"IBM Plex Mono",monospace', fontWeight:700, color:ecfg.color, letterSpacing:'0.06em' }}>{ecfg.label.toUpperCase()}</span>
                        <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, color:'rgba(var(--slate-rgb), 0.55)' }}>{ev.date}</span>
                        <span style={{ fontSize:11, fontWeight:600, color:'var(--ink)' }}>· {ev.actor}</span>
                      </div>
                      <p style={{ margin:0, fontSize:13, color:'var(--slate)', lineHeight:1.6 }}>{ev.text}</p>
                    </div>
                  </div>
                );
              })}

              {/* Resolution */}
              {sel.resolution && (
                <div style={{ marginTop:20, padding:'12px 16px', borderRadius:14,
                  background:'rgba(var(--teal-rgb), 0.09)', border:'1px solid rgba(var(--teal-rgb), 0.22)' }}>
                  <Eyebrow style={{ marginBottom:6, color:'rgba(var(--teal-rgb), 0.8)' }}>Resolution</Eyebrow>
                  <p style={{ margin:0, fontSize:13, color:'var(--teal)', lineHeight:1.55 }}>{sel.resolution}</p>
                </div>
              )}
            </Panel>
          </div>
        );
      })()}
    </div>
  );
}

Object.assign(window, { DisputeLedgerScreen });
