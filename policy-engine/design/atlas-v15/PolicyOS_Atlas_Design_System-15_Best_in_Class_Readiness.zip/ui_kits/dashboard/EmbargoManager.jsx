// EmbargoManager.jsx — C4
// Time-locked data & jurisdictional restrictions: countdown, lift authority, override log
// Exports: EmbargoManagerScreen

const NOW = new Date('2024-10-01T08:00:00Z');

function parseDate(s) { return new Date(s); }
function hoursUntil(d) { return (parseDate(d) - NOW) / 36e5; }
function daysUntil(d)  { return hoursUntil(d) / 24; }
function expired(d)    { return hoursUntil(d) <= 0; }
function fmtCountdown(d) {
  const h = hoursUntil(d);
  if (h <= 0) return 'LIFTED';
  if (h < 1)  return `${Math.round(h*60)}m remaining`;
  if (h < 24) return `${h.toFixed(1)}h remaining`;
  return `${daysUntil(d).toFixed(1)}d remaining`;
}

const EMBARGOES = [
  {
    id:'EMB-001', name:'Q3 2024 Fiscal Dataset',
    type:'temporal', status:'active',
    liftAt:'2024-10-15T00:00:00Z',
    authority:'Chief Data Officer',
    jurisdiction:null,
    scope:'READ on fiscal_reform_dataset v3.4 — Q3 snapshot',
    reason:'Mandatory 14-day post-collection validation window before downstream use.',
    overrides:[],
    affected:['Run fiscal_001', 'Run fiscal_002', 'Decision D-Q3-001'],
    accessLog:[
      { actor:'Policy Engine', attempted:'2024-10-01T07:42:00Z', outcome:'DENIED' },
      { actor:'Auditor service', attempted:'2024-10-01T06:18:00Z', outcome:'DENIED' },
    ],
  },
  {
    id:'EMB-002', name:'Income Data — Kherson Region',
    type:'jurisdictional', status:'active',
    liftAt:null,
    authority:'Legal Compliance Office',
    jurisdiction:'UA-65 (Kherson Oblast)',
    scope:'All fields derived from income_quartile where municipality_id IN (UA-65-*)',
    reason:'Temporary legal hold pending regional data sovereignty review under Law 3477-IX.',
    overrides:[
      { actor:'Vasyl Petrenko', role:'Data Governance Lead', date:'2024-09-28', note:'Single read granted for audit purposes. Expires 24h.', expired:true },
    ],
    affected:['Cohort analysis — Kherson sub-region', 'Run fiscal_002 (partial)'],
    accessLog:[
      { actor:'Cohort service', attempted:'2024-09-30T14:00:00Z', outcome:'DENIED' },
      { actor:'Vasyl Petrenko (override)', attempted:'2024-09-28T09:00:00Z', outcome:'GRANTED (expired)' },
    ],
  },
  {
    id:'EMB-003', name:'Tax Records Batch — Oct 2024',
    type:'temporal', status:'lifted',
    liftAt:'2024-09-30T18:00:00Z',
    authority:'Data Steward',
    jurisdiction:null,
    scope:'READ on tax_records where batch_date = 2024-10',
    reason:'Standard 48h quality validation window.',
    overrides:[],
    affected:['Run tax_001'],
    accessLog:[
      { actor:'Policy Engine', attempted:'2024-09-30T18:02:00Z', outcome:'GRANTED' },
    ],
  },
];

const TYPE_CFG = {
  temporal:       { icon:'◷', color:'var(--chart-secondary)', bg:'rgba(var(--blue-rgb), 0.10)', label:'Temporal'       },
  jurisdictional: { icon:'⬟', color:'var(--ember)', bg:'rgba(var(--ember-rgb), 0.10)', label:'Jurisdictional' },
};

const STATUS_CFG = {
  active: { color:'var(--ember)', bg:'rgba(var(--ember-rgb), 0.11)', border:'rgba(var(--ember-rgb), 0.30)', badge:'fail',    label:'Active'  },
  lifted: { color:'var(--teal)', bg:'rgba(var(--teal-rgb), 0.10)',  border:'rgba(var(--teal-rgb), 0.25)',  badge:'ok',      label:'Lifted'  },
};

function Countdown({ liftAt }) {
  if (!liftAt) return <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:12, color:'var(--ember)', fontWeight:700 }}>Indefinite</span>;
  const h = hoursUntil(liftAt);
  const isExpired = h <= 0;
  const color = isExpired ? 'var(--teal)' : h < 24 ? 'var(--ember)' : 'var(--gold-vibrant)';
  return (
    <div style={{ display:'flex', flexDirection:'column', gap:2 }}>
      <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:16, fontWeight:800, color, letterSpacing:'-0.02em' }}>
        {fmtCountdown(liftAt)}
      </span>
      <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:'rgba(var(--slate-rgb), 0.55)' }}>
        {isExpired ? 'Lifted at' : 'Lifts at'} {liftAt.slice(0,16).replace('T',' ')} UTC
      </span>
    </div>
  );
}

function EmbargoManagerScreen() {
  const [selId, setSelId]         = React.useState('EMB-001');
  const [showOverride, setShowOv] = React.useState(false);
  const [overrideNote, setOvNote] = React.useState('');

  const sel = EMBARGOES.find(e => e.id === selId);
  const tcfg = sel ? TYPE_CFG[sel.type] : null;
  const scfg = sel ? STATUS_CFG[sel.status] : null;

  return (
    <div style={{ display:'flex', gap:20, height:'100%' }}>

      {/* Embargo list */}
      <div style={{ width:260, flexShrink:0, display:'flex', flexDirection:'column', gap:10 }}>
        <Eyebrow>C4 · Embargo Manager</Eyebrow>

        {EMBARGOES.map(e => {
          const tc = TYPE_CFG[e.type];
          const sc = STATUS_CFG[e.status];
          const isSel = selId === e.id;
          return (
            <InteractiveCard key={e.id} onClick={() => setSelId(e.id)} selected={isSel}
              ariaLabel={`Open embargo ${e.id}. ${e.name}. Status ${sc.label}.`}
              style={{ padding:'12px 14px', borderRadius:16, cursor:'pointer',
                background: isSel ? sc.bg : 'rgba(var(--white-rgb), 0.56)',
                border:`1.5px solid ${isSel ? sc.color : 'rgba(var(--ink-rgb), 0.08)'}`,
                transition:'all 140ms' }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:5 }}>
                <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                  <span style={{ fontSize:13, color:tc.color }}>{tc.icon}</span>
                  <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, fontWeight:700, color:'rgba(var(--slate-rgb), 0.6)', letterSpacing:'0.06em' }}>{e.id}</span>
                </div>
                <Badge kind={sc.badge}>{sc.label}</Badge>
              </div>
              <div style={{ fontSize:12, fontWeight:700, color:'var(--ink)', marginBottom:4, lineHeight:1.3 }}>{e.name}</div>
              <div style={{ fontSize:11, color:tc.color, fontFamily:'"IBM Plex Mono",monospace', fontWeight:600 }}>{tc.label}</div>
              {e.liftAt && e.status === 'active' && (
                <div style={{ fontSize:10, fontFamily:'"IBM Plex Mono",monospace', color:'var(--ember)', marginTop:4, fontWeight:700 }}>
                  {fmtCountdown(e.liftAt)}
                </div>
              )}
            </InteractiveCard>
          );
        })}
      </div>

      {/* Detail */}
      {sel && (
        <div style={{ flex:1, display:'flex', flexDirection:'column', gap:12 }}>

          {/* Header */}
          <Panel style={{ padding:'16px 20px', background: scfg.bg }}>
            <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', gap:12 }}>
              <div>
                <div style={{ display:'flex', gap:8, alignItems:'center', marginBottom:6 }}>
                  <span style={{ fontSize:14, color:tcfg.color }}>{tcfg.icon}</span>
                  <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, fontWeight:700, color:'rgba(var(--slate-rgb), 0.7)', letterSpacing:'0.08em' }}>{sel.id}</span>
                  <Badge kind={scfg.badge}>{scfg.label}</Badge>
                  <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, fontWeight:700, color:tcfg.color, letterSpacing:'0.06em' }}>{tcfg.label.toUpperCase()}</span>
                </div>
                <h3 style={{ margin:0, fontSize:20, fontWeight:800, letterSpacing:'-0.03em', marginBottom:4 }}>{sel.name}</h3>
                <p style={{ margin:0, fontSize:13, color:'var(--slate)', lineHeight:1.55 }}>{sel.reason}</p>
              </div>
              {/* Countdown */}
              <div style={{ flexShrink:0, padding:'10px 14px', borderRadius:14, background:'rgba(var(--white-rgb), 0.55)', border:'1px solid rgba(var(--ink-rgb), 0.08)', minWidth:160 }}>
                <div style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.6)', marginBottom:6 }}>EMBARGO STATUS</div>
                <Countdown liftAt={sel.liftAt} />
                <div style={{ marginTop:8, fontSize:11, color:'var(--slate)' }}>Authority: <strong>{sel.authority}</strong></div>
              </div>
            </div>
          </Panel>

          {/* Scope + jurisdiction */}
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
            <Panel>
              <Eyebrow style={{ marginBottom:8 }}>Scope</Eyebrow>
              <p style={{ margin:0, fontFamily:'"IBM Plex Mono",monospace', fontSize:11, color:'var(--teal)', lineHeight:1.6 }}>{sel.scope}</p>
            </Panel>
            <Panel>
              <Eyebrow style={{ marginBottom:8 }}>{sel.jurisdiction ? 'Jurisdiction' : 'Affected outputs'}</Eyebrow>
              {sel.jurisdiction ? (
                <p style={{ margin:0, fontSize:13, fontWeight:700, color:'var(--ember)' }}>{sel.jurisdiction}</p>
              ) : (
                <div style={{ display:'flex', flexDirection:'column', gap:4 }}>
                  {sel.affected.map((a, i) => (
                    <span key={i} style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, color:'var(--slate)' }}>{a}</span>
                  ))}
                </div>
              )}
            </Panel>
          </div>

          {/* Override log */}
          <Panel>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:12 }}>
              <Eyebrow>Override log ({sel.overrides.length})</Eyebrow>
              {sel.status === 'active' && (
                <Button variant="danger" size="sm" onClick={() => setShowOv(v => !v)}>
                  + Request override
                </Button>
              )}
            </div>

            {sel.overrides.length === 0 && !showOverride && (
              <p style={{ margin:0, fontSize:12, color:'rgba(var(--slate-rgb), 0.6)', fontStyle:'italic' }}>No overrides on record.</p>
            )}

            {sel.overrides.map((ov, i) => (
              <div key={i} style={{ padding:'10px 13px', borderRadius:12, marginBottom:8,
                background: ov.expired ? 'rgba(var(--slate-rgb), 0.06)':'rgba(var(--ember-rgb), 0.08)',
                border:`1px solid ${ov.expired ? 'rgba(var(--slate-rgb), 0.15)':'rgba(var(--ember-rgb), 0.2)'}` }}>
                <div style={{ display:'flex', justifyContent:'space-between', marginBottom:4 }}>
                  <span style={{ fontSize:12, fontWeight:700, color:'var(--ink)' }}>{ov.actor}</span>
                  <Badge kind={ov.expired ? 'neutral':'fail'}>{ov.expired ? 'EXPIRED':'ACTIVE'}</Badge>
                </div>
                <div style={{ fontSize:11, color:'rgba(var(--slate-rgb), 0.7)', marginBottom:2 }}>{ov.role} · {ov.date}</div>
                <div style={{ fontSize:11, color:'var(--slate)' }}>{ov.note}</div>
              </div>
            ))}

            {/* Override request form */}
            {showOverride && (
              <div style={{ padding:'14px', borderRadius:14, background:'rgba(var(--ember-rgb), 0.07)', border:'1px solid rgba(var(--ember-rgb), 0.22)', marginTop:8 }}>
                <Eyebrow style={{ marginBottom:8, color:'rgba(var(--ember-rgb), 0.8)' }}>Override request</Eyebrow>
                <textarea
                  value={overrideNote}
                  onChange={e => setOvNote(e.target.value)}
                  placeholder="Provide justification for override access…"
                  style={{ width:'100%', height:72, padding:'8px 10px', borderRadius:10,
                    border:'1px solid rgba(var(--ember-rgb), 0.3)', background:'rgba(var(--white-rgb), 0.7)',
                    fontFamily:'Manrope,sans-serif', fontSize:12, resize:'vertical', outline:'none' }}
                />
                <div style={{ display:'flex', gap:8, marginTop:8 }}>
                  <Button variant="danger" size="sm" onClick={() => { setShowOv(false); setOvNote(''); }}>
                    Submit request
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => setShowOv(false)}>Cancel</Button>
                </div>
              </div>
            )}
          </Panel>

          {/* Access log */}
          <Panel>
            <Eyebrow style={{ marginBottom:10 }}>Access attempt log</Eyebrow>
            {sel.accessLog.map((log, i) => (
              <div key={i} style={{ display:'flex', alignItems:'center', gap:12, padding:'8px 10px',
                borderRadius:10, marginBottom:6,
                background: log.outcome.startsWith('GRANTED') ? 'rgba(var(--teal-rgb), 0.07)' : 'rgba(var(--ember-rgb), 0.07)',
                border:`1px solid ${log.outcome.startsWith('GRANTED') ? 'rgba(var(--teal-rgb), 0.18)':'rgba(var(--ember-rgb), 0.18)'}` }}>
                <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, fontWeight:700,
                  color: log.outcome.startsWith('GRANTED') ? 'var(--teal)':'var(--ember)', flexShrink:0 }}>
                  {log.outcome.startsWith('GRANTED') ? '✓':'✗'}
                </span>
                <span style={{ fontSize:11, color:'var(--ink)', fontWeight:600, flex:1 }}>{log.actor}</span>
                <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:'rgba(var(--slate-rgb), 0.55)' }}>
                  {log.attempted.slice(0,16).replace('T',' ')}
                </span>
                <Badge kind={log.outcome.startsWith('GRANTED')?'ok':'fail'}>
                  {log.outcome.split(' ')[0]}
                </Badge>
              </div>
            ))}
          </Panel>
        </div>
      )}
    </div>
  );
}

Object.assign(window, { EmbargoManagerScreen });
