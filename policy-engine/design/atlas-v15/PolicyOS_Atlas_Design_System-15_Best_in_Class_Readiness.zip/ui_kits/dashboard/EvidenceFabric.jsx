// EvidenceFabric.jsx — Evidence Fabric screen

function SourceNode({ label, kind, count, freshness, color }) {
  const kindColor = { live:'var(--teal-vibrant)', stale:'var(--gold-vibrant)', failed:'var(--ember-vibrant)', pending:'var(--slate)' };
  return (
    <div style={{
      padding:'14px 16px', borderRadius:18,
      border:`1px solid rgba(var(--ink-rgb), 0.08)`,
      background:'rgba(var(--white-rgb), 0.58)',
      boxShadow:'inset 0 1px 0 rgba(var(--white-rgb), 0.55)',
      display:'grid', gap:8,
    }}>
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'flex-start'}}>
        <div style={{display:'flex', alignItems:'center', gap:8}}>
          <div style={{width:8, height:8, borderRadius:'50%', background: kindColor[freshness] || 'var(--slate)', flexShrink:0}} />
          <span style={{fontSize:13, fontWeight:700}}>{label}</span>
        </div>
        <Badge kind={freshness==='live'?'ok':freshness==='stale'?'warn':freshness==='failed'?'fail':'neutral'} style={{fontSize:9,padding:'3px 7px'}}>{freshness}</Badge>
      </div>
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <span style={{fontFamily:'"IBM Plex Mono",monospace', fontSize:10, color:'rgba(var(--ink-rgb), 0.55)', textTransform:'uppercase', letterSpacing:'0.08em'}}>{kind}</span>
        <span style={{fontFamily:'"IBM Plex Mono",monospace', fontSize:11, fontWeight:600, color:'rgba(var(--ink-rgb), 0.7)'}}>{count} docs</span>
      </div>
    </div>
  );
}

function ProvenanceChain({ steps }) {
  return (
    <div style={{display:'flex', alignItems:'center', gap:0, flexWrap:'wrap'}}>
      {steps.map((s, i) => (
        <React.Fragment key={i}>
          <div style={{
            padding:'6px 10px', borderRadius:10,
            background: i === steps.length-1 ? 'rgba(var(--teal-vibrant-rgb), 0.12)' : 'rgba(var(--white-rgb), 0.6)',
            border:'1px solid rgba(var(--ink-rgb), 0.08)',
            fontSize:11, fontFamily:'"IBM Plex Mono",monospace',
            color: i === steps.length-1 ? 'var(--teal)' : 'rgba(var(--ink-rgb), 0.65)',
            fontWeight: i === steps.length-1 ? 700 : 400,
          }}>{s}</div>
          {i < steps.length-1 && (
            <svg width="20" height="12" viewBox="0 0 24 24" fill="none" stroke="rgba(var(--ink-rgb), 0.25)" strokeWidth="1.5" strokeLinecap="round"><path d="M3 12 C 6 7, 9 17, 12 12 S 18 7, 21 12"/><path d="M17.5 9.5 L21 12 L17.5 14.5"/></svg>
          )}
        </React.Fragment>
      ))}
    </div>
  );
}

function EvidenceFabricScreen() {
  const [activeSource, setActiveSource] = React.useState('world-bank');

  const sources = [
    { id:'world-bank',  label:'World Bank Open Data',  kind:'REST API',    count:'1,842', freshness:'live'   },
    { id:'ukrstat',     label:'Ukrstat DASU',           kind:'CSV Upload',  count:'1,203', freshness:'live'   },
    { id:'imf',         label:'IMF Fiscal Monitor',     kind:'REST API',    count:'984',   freshness:'stale'  },
    { id:'oecd',        label:'OECD Policy Library',    kind:'RSS/Scrape',  count:'672',   freshness:'live'   },
    { id:'cabinet',     label:'Cabinet Docs (UA)',      kind:'Manual Feed', count:'441',   freshness:'stale'  },
    { id:'nbu',         label:'NBU Statistical Data',   kind:'REST API',    count:'318',   freshness:'live'   },
  ];

  const bundles = [
    { id:'eb_001', label:'Fiscal Transmission Q2',    sources:3, conf:0.87, status:'verified'  },
    { id:'eb_002', label:'Employment Baseline 2024',  sources:2, conf:0.74, status:'verified'  },
    { id:'eb_003', label:'Energy Poverty Survey',     sources:4, conf:0.61, status:'pending'   },
    { id:'eb_004', label:'Housing Price Index',       sources:2, conf:0.82, status:'verified'  },
  ];

  const promotions = [
    { metric:'fiscal.vat_multiplier',  connector:'world-bank', conf:0.91, status:'pending' },
    { metric:'labour.employment_rate', connector:'ukrstat',    conf:0.78, status:'pending' },
    { metric:'energy.poverty_index',   connector:'cabinet',    conf:0.55, status:'review'  },
  ];

  return (
    <div style={{display:'grid', gap:18}}>
      {/* Topbar */}
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'flex-start', flexWrap:'wrap', gap:12}}>
        <div>
          <Eyebrow style={{marginBottom:6}}>Evidence Fabric</Eyebrow>
          <h1 style={{margin:0, fontSize:30, fontWeight:800, letterSpacing:'-0.04em', lineHeight:1.05}}>Data & Provenance</h1>
          <p style={{margin:'6px 0 0', fontSize:14, color:'rgba(var(--ink-rgb), 0.65)'}}>
            Unified source registry, evidence bundles, and promotion candidates.
          </p>
        </div>
        <div style={{display:'flex', gap:8}}>
          <Button variant="ghost">Import Source</Button>
          <Button variant="primary">Promote to Canon</Button>
        </div>
      </div>

      {/* Metrics */}
      <div style={{display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:14}}>
        <MetricCard label="Active Sources"   value="6"    hint="4 live · 2 stale" badge={<Badge kind="ok">Live</Badge>} />
        <MetricCard label="Evidence Bundles" value="14"   hint="11 verified · 3 pending" />
        <MetricCard label="Total Docs"       value="5.5k" hint="indexed last run" />
        <MetricCard label="Promotions"       value="3"    hint="awaiting review" badge={<Badge kind="warn">Review</Badge>} />
      </div>

      {/* Main 3-col grid */}
      <div style={{display:'grid', gridTemplateColumns:'1.1fr 1fr 0.85fr', gap:18}}>

        {/* Source registry */}
        <Panel>
          <PanelHeader eyebrow="Source Registry" title="Connectors">
            <Badge kind="ok">6 sources</Badge>
          </PanelHeader>
          <div style={{display:'grid', gap:8}}>
            {sources.map(s => (
              <InteractiveCard
                key={s.id}
                onClick={() => setActiveSource(s.id)}
                selected={activeSource === s.id}
                ariaLabel={`Select source ${s.label}. ${s.count} documents. Freshness ${s.freshness}.`}
                style={{cursor:'pointer', padding:0, borderRadius:18}}
              >
                <SourceNode {...s} />
              </InteractiveCard>
            ))}
          </div>
        </Panel>

        {/* Evidence bundles */}
        <Panel>
          <PanelHeader eyebrow="Evidence Bundles" title="Bundles" />
          <div style={{display:'grid', gap:10}}>
            {bundles.map(b => (
              <div key={b.id} style={{
                padding:'14px 16px', borderRadius:16,
                background:'rgba(var(--white-rgb), 0.56)',
                border:'1px solid rgba(var(--ink-rgb), 0.07)',
              }}>
                <div style={{display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:8}}>
                  <div>
                    <div style={{display:'flex', alignItems:'center', gap:6, marginBottom:4}}>
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 4 L20 20 L4 20 Z"/></svg>
                      <span style={{fontSize:12, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--ink-rgb), 0.45)', letterSpacing:'0.06em'}}>{b.id}</span>
                    </div>
                    <strong style={{fontSize:13, fontWeight:700}}>{b.label}</strong>
                  </div>
                  <Badge kind={b.status==='verified'?'ok':'warn'} style={{fontSize:9,padding:'3px 7px'}}>{b.status}</Badge>
                </div>
                <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
                  <span style={{fontSize:11, color:'rgba(var(--ink-rgb), 0.55)'}}>{b.sources} sources linked</span>
                  <div style={{display:'flex', alignItems:'center', gap:6}}>
                    <div style={{width:48, height:4, borderRadius:999, background:'rgba(var(--ink-rgb), 0.08)', overflow:'hidden'}}>
                      <div style={{height:'100%', width:`${Math.round(b.conf*100)}%`, background: b.conf > 0.8 ? 'var(--teal-vibrant)' : b.conf > 0.65 ? 'var(--gold-vibrant)' : 'var(--ember-vibrant)', borderRadius:'inherit'}} />
                    </div>
                    <span style={{fontFamily:'"IBM Plex Mono",monospace', fontSize:10, color:'rgba(var(--ink-rgb), 0.55)'}}>{Math.round(b.conf*100)}%</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Provenance chain */}
          <div style={{marginTop:16, padding:'14px', borderRadius:14, background:'rgba(var(--ink-rgb), 0.03)', border:'1px solid rgba(var(--ink-rgb), 0.06)'}}>
            <Eyebrow style={{marginBottom:8}}>Provenance chain · eb_001</Eyebrow>
            <ProvenanceChain steps={['world-bank', 'fabric.ingest', 'ir.norm', 'bundle.eb_001']} />
          </div>
        </Panel>

        {/* Promotion candidates */}
        <div style={{display:'grid', gap:18, alignContent:'start'}}>
          <Panel>
            <PanelHeader eyebrow="Promotions" title="Candidates" />
            <div style={{display:'grid', gap:8}}>
              {promotions.map(p => (
                <div key={p.metric} style={{padding:'12px 14px', borderRadius:14, background:'rgba(var(--white-rgb), 0.56)', border:'1px solid rgba(var(--ink-rgb), 0.07)'}}>
                  <div style={{display:'flex', justifyContent:'space-between', alignItems:'flex-start', gap:8}}>
                    <div>
                      <span style={{fontFamily:'"IBM Plex Mono",monospace', fontSize:10, color:'rgba(var(--ink-rgb), 0.45)', letterSpacing:'0.06em'}}>{p.connector}</span>
                      <p style={{margin:'3px 0 0', fontSize:12, fontWeight:700}}>{p.metric}</p>
                    </div>
                    <Badge kind={p.status==='pending'?'warn':'info'} style={{fontSize:9,padding:'3px 6px'}}>{p.status}</Badge>
                  </div>
                  <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginTop:8}}>
                    <span style={{fontSize:10, color:'rgba(var(--ink-rgb), 0.5)'}}>Confidence</span>
                    <span style={{fontFamily:'"IBM Plex Mono",monospace', fontSize:11, fontWeight:700, color: p.conf>0.8?'var(--teal)':p.conf>0.65?'var(--gold)':'var(--ember)'}}>{Math.round(p.conf*100)}%</span>
                  </div>
                </div>
              ))}
            </div>
            <Button variant="ghost" style={{width:'100%', justifyContent:'center', marginTop:10}}>Review all →</Button>
          </Panel>

          <Panel style={{background:'linear-gradient(180deg,rgba(var(--graphite-rgb), 0.96),rgba(var(--shell-dark-rgb), 0.97))', border:'1px solid rgba(var(--white-rgb), 0.08)', color:'var(--rail-fg)'}}>
            <p style={{fontFamily:'"IBM Plex Mono",monospace', fontSize:9, letterSpacing:'0.12em', textTransform:'uppercase', color:'rgba(var(--rail-fg-rgb), 0.5)', marginBottom:10}}>Data Freshness</p>
            <div style={{display:'grid', gap:8}}>
              {[
                { label:'World Bank', age:'2h ago',  ok:true  },
                { label:'Ukrstat',    age:'4h ago',  ok:true  },
                { label:'IMF',        age:'8d ago',  ok:false },
                { label:'Cabinet',    age:'3d ago',  ok:false },
              ].map(f => (
                <div key={f.label} style={{display:'flex', justifyContent:'space-between', alignItems:'center', padding:'8px 0', borderTop:'1px solid rgba(var(--white-rgb), 0.08)'}}>
                  <span style={{fontSize:12, color:'rgba(var(--rail-fg-rgb), 0.75)'}}>{f.label}</span>
                  <span style={{fontFamily:'"IBM Plex Mono",monospace', fontSize:10, color: f.ok ? 'rgba(var(--teal-rgb), 0.9)' : 'rgba(var(--ember-rgb), 0.9)'}}>{f.age}</span>
                </div>
              ))}
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { EvidenceFabricScreen });
