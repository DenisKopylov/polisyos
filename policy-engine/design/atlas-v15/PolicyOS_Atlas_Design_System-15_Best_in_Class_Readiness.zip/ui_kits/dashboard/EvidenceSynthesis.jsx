// EvidenceSynthesis.jsx — E5
// Weight-of-evidence display: forest plot, study cards, meta-analytic summary
// Exports: EvidenceSynthesisScreen

const STUDIES = [
  {
    id:'S1', citation:'Kovalenko et al. (2022)', type:'rct', label:'UA Fiscal Pilot RCT',
    n:4200, outcome:'poverty_rate', estimand:'ATE',
    estimate:-0.038, ci95:[-0.061,-0.015], weight:0.22,
    quality:'high', blinded:true, preregistered:true,
    note:'Well-powered RCT in Ukrainian fiscal context. Gold standard evidence.',
  },
  {
    id:'S2', citation:'Bondar & Sydorenko (2021)', type:'did', label:'DiD — 2018 Reform',
    n:18400, outcome:'poverty_rate', estimand:'ATT',
    estimate:-0.051, ci95:[-0.078,-0.024], weight:0.19,
    quality:'high', blinded:false, preregistered:false,
    note:'Difference-in-differences on 2018 predecessor policy. Parallel trends validated.',
  },
  {
    id:'S3', citation:'Petrenko et al. (2023)', type:'iv', label:'IV — Budget Cycle',
    n:31200, outcome:'poverty_rate', estimand:'LATE',
    estimate:-0.029, ci95:[-0.048,-0.010], weight:0.17,
    quality:'medium', blinded:false, preregistered:true,
    note:'Instrumental variable using budget cycle timing. LATE for compliers only.',
  },
  {
    id:'S4', citation:'World Bank (2022)', type:'meta', label:'WB Meta-Analysis',
    n:142000, outcome:'poverty_rate', estimand:'ATE',
    estimate:-0.044, ci95:[-0.059,-0.029], weight:0.28,
    quality:'high', blinded:false, preregistered:false,
    note:'Multi-country meta-analysis including 14 comparable fiscal transfer programmes.',
  },
  {
    id:'S5', citation:'IMF Working Paper (2023)', type:'obs', label:'IMF Observational',
    n:8900, outcome:'poverty_rate', estimand:'ATE',
    estimate:-0.019, ci95:[-0.044, 0.006], weight:0.08,
    quality:'low', blinded:false, preregistered:false,
    note:'Observational study. CI crosses zero — null result not excluded. Lower weight.',
  },
  {
    id:'S6', citation:'Shevchenko & Melnyk (2024)', type:'rdd', label:'RDD — Eligibility Threshold',
    n:3600, outcome:'poverty_rate', estimand:'LATE',
    estimate:-0.041, ci95:[-0.072,-0.010], weight:0.06,
    quality:'medium', blinded:false, preregistered:true,
    note:'Regression discontinuity at income eligibility cutoff. Local effect only.',
  },
];

const META = {
  estimate:-0.043, ci95:[-0.056,-0.030], ci80:[-0.050,-0.036],
  heterogeneity:{ i2:0.24, tau2:0.000082, q:6.56, q_p:0.255 },
  n_studies:6, n_total:208300,
};

const STUDY_TYPE = {
  rct:  { label:'RCT',          color:'var(--teal)', icon:'◆' },
  did:  { label:'DiD',          color:'var(--teal-vibrant)', icon:'◎' },
  iv:   { label:'IV',           color:'var(--chart-secondary)', icon:'◈' },
  meta: { label:'Meta-analysis',color:'var(--gold)', icon:'▪' },
  obs:  { label:'Observational',color:'var(--ember)', icon:'○' },
  rdd:  { label:'RDD',          color:'var(--gold-vibrant)', icon:'◇' },
};

const QUALITY_CFG = {
  high:   { badge:'ok',      color:'var(--teal)' },
  medium: { badge:'warn',    color:'var(--gold-vibrant)' },
  low:    { badge:'fail',    color:'var(--ember)' },
};

// Forest plot geometry
const FP_W = 320, FP_X_MIN = -0.12, FP_X_MAX = 0.03;
function toFP(val) { return ((val - FP_X_MIN) / (FP_X_MAX - FP_X_MIN) * FP_W); }
const ZERO_X = toFP(0);

function StudyRow({ study, selected, onSelect, yOffset }) {
  const tc   = STUDY_TYPE[study.type];
  const isSel = selected === study.id;
  const ciW  = toFP(study.ci95[1]) - toFP(study.ci95[0]);
  const cx   = toFP(study.estimate);
  const boxH = study.weight * 22;

  return (
    <g role="button" tabIndex={0} focusable="true" aria-label={`Toggle study ${study.citation}. Estimate ${study.estimate.toFixed(3)}.`}
      onClick={() => onSelect(isSel ? null : study.id)}
      onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onSelect(isSel ? null : study.id); } }}
      style={{ cursor:'pointer' }}>
      {/* Row highlight */}
      {isSel && <rect x={-8} y={yOffset - 14} width={FP_W + 16} height={28} rx={8} fill={tc.color} opacity={0.08} />}
      {/* CI line */}
      <line x1={toFP(study.ci95[0])} y1={yOffset} x2={toFP(study.ci95[1])} y2={yOffset}
        stroke={tc.color} strokeWidth={isSel ? 2:1.5} opacity={0.7} />
      {/* CI endcaps */}
      <line x1={toFP(study.ci95[0])} y1={yOffset-4} x2={toFP(study.ci95[0])} y2={yOffset+4} stroke={tc.color} strokeWidth={1.5} opacity={0.5} />
      <line x1={toFP(study.ci95[1])} y1={yOffset-4} x2={toFP(study.ci95[1])} y2={yOffset+4} stroke={tc.color} strokeWidth={1.5} opacity={0.5} />
      {/* Point estimate box (size = weight) */}
      <rect x={cx - boxH/2} y={yOffset - boxH/2} width={boxH} height={boxH}
        fill={tc.color} opacity={0.85} rx={2} />
    </g>
  );
}

function EvidenceSynthesisScreen() {
  const [selId,   setSelId]   = React.useState(null);
  const [typeFilter, setTF]   = React.useState('all');

  const visible = typeFilter === 'all' ? STUDIES : STUDIES.filter(s => s.type === typeFilter);
  const sel = selId ? STUDIES.find(s => s.id === selId) : null;

  const FP_H = (visible.length + 1.5) * 32 + 40;
  const ROW_H = 32;

  return (
    <div style={{ display:'flex', gap:20, height:'100%' }}>

      {/* Forest plot + table */}
      <div style={{ flex:1, minWidth:0, display:'flex', flexDirection:'column', gap:14 }}>

        {/* Toolbar */}
        <div style={{ display:'flex', alignItems:'center', gap:8, flexWrap:'wrap' }}>
          <Eyebrow>E5 · Evidence Synthesis</Eyebrow>
          <div style={{ flex:1 }} />
          {['all','rct','did','iv','meta','obs','rdd'].map(f => {
            const tc = STUDY_TYPE[f];
            return (
              <button type="button" key={f} onClick={() => setTF(f)}
                style={{ padding:'4px 9px', borderRadius:999, border:'none', cursor:'pointer',
                  fontFamily:'"IBM Plex Mono",monospace', fontSize:9, fontWeight:700, letterSpacing:'0.06em',
                  background: typeFilter===f ? (tc?tc.color+'1a':'rgba(var(--ink-rgb), 0.09)') : 'rgba(var(--white-rgb), 0.65)',
                  color: typeFilter===f ? (tc?.color||'var(--ink)') : 'rgba(var(--slate-rgb), 0.65)',
                  boxShadow: typeFilter===f ? `0 0 0 1px ${tc?.color||'rgba(var(--ink-rgb), 0.18)'}` : '0 0 0 1px rgba(var(--ink-rgb), 0.08)' }}>
                {f === 'all' ? 'ALL' : (STUDY_TYPE[f]?.label || f).toUpperCase()}
              </button>
            );
          })}
        </div>

        <div style={{ flex:1, display:'flex', gap:0, minHeight:0 }}>
          {/* Study table */}
          <div style={{ width:290, flexShrink:0, overflowY:'auto', paddingRight:14 }}>
            <div style={{ display:'grid', gridTemplateColumns:'1fr auto', gap:8, padding:'8px 0', borderBottom:'1px solid rgba(var(--ink-rgb), 0.08)', marginBottom:6 }}>
              <span style={{ fontSize:8, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.4)', letterSpacing:'0.1em' }}>STUDY</span>
              <span style={{ fontSize:8, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.4)', letterSpacing:'0.1em' }}>WEIGHT</span>
            </div>
            {visible.map(study => {
              const tc   = STUDY_TYPE[study.type];
              const isSel = selId === study.id;
              return (
                <InteractiveCard key={study.id} onClick={() => setSelId(s => s===study.id?null:study.id)} selected={isSel}
                  ariaLabel={`Toggle study ${study.citation}. Estimate ${study.estimate.toFixed(3)}.`}
                  style={{ display:'flex', justifyContent:'space-between', alignItems:'center',
                    padding:'8px 10px', borderRadius:11, marginBottom:5, cursor:'pointer',
                    background: isSel ? tc.color+'14' : 'rgba(var(--white-rgb), 0.52)',
                    border:`1.5px solid ${isSel ? tc.color : 'rgba(var(--ink-rgb), 0.07)'}`,
                    transition:'all 130ms' }}>
                  <div>
                    <div style={{ display:'flex', gap:6, alignItems:'center', marginBottom:2 }}>
                      <span style={{ fontSize:11, color:tc.color }}>{tc.icon}</span>
                      <span style={{ fontSize:11, fontWeight:700, color:'var(--ink)' }}>{study.citation}</span>
                    </div>
                    <div style={{ display:'flex', gap:8, alignItems:'center' }}>
                      <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, fontWeight:700, color:tc.color }}>
                        {study.estimate.toFixed(3)}
                      </span>
                      <span style={{ fontSize:9, color:'rgba(var(--slate-rgb), 0.5)', fontFamily:'"IBM Plex Mono",monospace' }}>
                        [{study.ci95[0].toFixed(3)}, {study.ci95[1].toFixed(3)}]
                      </span>
                    </div>
                  </div>
                  <div style={{ textAlign:'right' }}>
                    <div style={{ fontSize:12, fontWeight:800, color:tc.color }}>{(study.weight*100).toFixed(0)}%</div>
                    <Badge kind={QUALITY_CFG[study.quality].badge}>{study.quality}</Badge>
                  </div>
                </InteractiveCard>
              );
            })}
          </div>

          {/* Forest plot SVG */}
          <Panel style={{ flex:1, padding:'14px 18px', overflow:'auto' }}>
            <Eyebrow style={{ marginBottom:12 }}>Forest plot · outcome: poverty_rate reduction</Eyebrow>
            <svg width="100%" viewBox={`0 0 ${FP_W+40} ${FP_H}`} style={{ display:'block', overflow:'visible' }}>
              {/* Axis */}
              <line x1={0} y1={FP_H-30} x2={FP_W} y2={FP_H-30} stroke="rgba(var(--ink-rgb), 0.15)" strokeWidth={1} />
              {/* Zero line */}
              <line x1={ZERO_X} y1={20} x2={ZERO_X} y2={FP_H-30} stroke="rgba(var(--ember-rgb), 0.5)" strokeWidth={1} strokeDasharray="4 3" />
              {/* Tick labels */}
              {[-0.10,-0.08,-0.06,-0.04,-0.02,0.00].map(v => (
                <g key={v}>
                  <line x1={toFP(v)} y1={FP_H-34} x2={toFP(v)} y2={FP_H-26} stroke="rgba(var(--ink-rgb), 0.2)" strokeWidth={1} />
                  <text x={toFP(v)} y={FP_H-16} textAnchor="middle" fontSize={8}
                    fontFamily='"IBM Plex Mono",monospace' fill="rgba(var(--slate-rgb), 0.55)">{v.toFixed(2)}</text>
                </g>
              ))}
              {/* Study rows */}
              {visible.map((study, i) => (
                <StudyRow key={study.id} study={study} selected={selId} onSelect={setSelId} yOffset={30 + i * ROW_H} />
              ))}
              {/* Meta-analytic diamond */}
              {(() => {
                const cy   = 30 + visible.length * ROW_H + 18;
                const cx   = toFP(META.estimate);
                const ci95l = toFP(META.ci95[0]);
                const ci95r = toFP(META.ci95[1]);
                const dh = 10;
                return (
                  <g>
                    <line x1={0} y1={cy - 8} x2={FP_W} y2={cy - 8} stroke="rgba(var(--ink-rgb), 0.1)" strokeWidth={1} />
                    <polygon
                      points={`${ci95l},${cy} ${cx},${cy-dh} ${ci95r},${cy} ${cx},${cy+dh}`}
                      fill="var(--ink)" opacity={0.82}
                    />
                    {/* CI 80% */}
                    <polygon
                      points={`${toFP(META.ci80[0])},${cy} ${cx},${cy-dh*0.6} ${toFP(META.ci80[1])},${cy} ${cx},${cy+dh*0.6}`}
                      fill="rgba(var(--ink-rgb), 0.2)" stroke="none"
                    />
                    <text x={cx} y={cy+dh+12} textAnchor="middle" fontSize={9}
                      fontFamily='"IBM Plex Mono",monospace' fontWeight={700} fill="var(--ink)">
                      POOLED: {META.estimate.toFixed(3)} [{META.ci95[0].toFixed(3)}, {META.ci95[1].toFixed(3)}]
                    </text>
                  </g>
                );
              })()}
            </svg>
          </Panel>
        </div>
      </div>

      {/* Inspector */}
      <div style={{ width:252, flexShrink:0, display:'flex', flexDirection:'column', gap:12 }}>
        <Panel style={{ flex:1 }}>
          <PanelHeader eyebrow="Study detail" title={sel ? sel.citation : 'Meta-analysis'} />

          {!sel ? (
            <div>
              <Eyebrow style={{ marginBottom:10 }}>Pooled estimate</Eyebrow>
              <div style={{ fontSize:28, fontWeight:800, letterSpacing:'-0.04em', color:'var(--ink)' }}>{META.estimate.toFixed(3)}</div>
              <div style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, color:'rgba(var(--slate-rgb), 0.7)', marginTop:3 }}>
                95% CI [{META.ci95[0].toFixed(3)}, {META.ci95[1].toFixed(3)}]
              </div>
              <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', margin:'14px 0' }} />
              <Eyebrow style={{ marginBottom:10 }}>Heterogeneity</Eyebrow>
              {[
                { label:'I²',    val:`${(META.heterogeneity.i2*100).toFixed(0)}%`, hint:'Low heterogeneity (< 25%)' },
                { label:'τ²',    val:META.heterogeneity.tau2.toFixed(6) },
                { label:'Q',     val:META.heterogeneity.q.toFixed(2) },
                { label:'Q p',   val:META.heterogeneity.q_p.toFixed(3), hint:'p > 0.05 — no significant heterogeneity' },
                { label:'Studies',val:META.n_studies },
                { label:'N total',val:META.n_total.toLocaleString() },
              ].map(r => (
                <div key={r.label} style={{ marginBottom:8 }}>
                  <div style={{ display:'flex', justifyContent:'space-between' }}>
                    <span style={{ fontSize:11, color:'rgba(var(--slate-rgb), 0.7)' }}>{r.label}</span>
                    <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, fontWeight:700, color:'var(--ink)' }}>{r.val}</span>
                  </div>
                  {r.hint && <div style={{ fontSize:9, color:'var(--teal)', marginTop:1 }}>{r.hint}</div>}
                </div>
              ))}
              <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', margin:'14px 0' }} />
              <p style={{ fontSize:12, color:'var(--slate)', lineHeight:1.6, margin:0 }}>
                Click any study row or forest plot point to inspect design, quality, and notes.
              </p>
            </div>
          ) : (
            <div>
              <div style={{ marginBottom:12, display:'flex', gap:7 }}>
                <Badge kind={QUALITY_CFG[sel.quality].badge}>{sel.quality} quality</Badge>
                <Badge kind="neutral">{STUDY_TYPE[sel.type].label}</Badge>
              </div>
              {[
                { label:'Estimand',  val:sel.estimand },
                { label:'N',         val:sel.n.toLocaleString() },
                { label:'Estimate',  val:sel.estimate.toFixed(3) },
                { label:'95% CI',    val:`[${sel.ci95[0].toFixed(3)}, ${sel.ci95[1].toFixed(3)}]` },
                { label:'Weight',    val:`${(sel.weight*100).toFixed(0)}%` },
                { label:'Blinded',   val:sel.blinded ? 'Yes':'No' },
                { label:'Pre-reg.',  val:sel.preregistered ? 'Yes':'No' },
              ].map(r => (
                <div key={r.label} style={{ marginBottom:9 }}>
                  <div style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.5)', marginBottom:2 }}>{r.label.toUpperCase()}</div>
                  <div style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:12, fontWeight:700, color:'var(--ink)' }}>{r.val}</div>
                </div>
              ))}
              <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', margin:'12px 0' }} />
              <Eyebrow style={{ marginBottom:6 }}>Notes</Eyebrow>
              <p style={{ margin:0, fontSize:12, color:'var(--slate)', lineHeight:1.6 }}>{sel.note}</p>
              <button type="button" onClick={() => setSelId(null)} style={{ marginTop:12, fontSize:11, color:'rgba(var(--slate-rgb), 0.7)', background:'none', border:'none', cursor:'pointer', padding:0 }}>← Meta-analysis</button>
            </div>
          )}
        </Panel>
      </div>
    </div>
  );
}

Object.assign(window, { EvidenceSynthesisScreen });
