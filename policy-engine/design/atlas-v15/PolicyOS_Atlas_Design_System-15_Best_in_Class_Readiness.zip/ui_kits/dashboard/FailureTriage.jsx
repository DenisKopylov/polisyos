// FailureTriage.jsx — D3
// Error classification, retry queue, root cause assignment, escalation
// Exports: FailureTriageScreen

const FAILURES = [
  {
    id:'ERR-2024-0091', run:'fiscal_reform_q2_001', partition:'W4 P4-2',
    type:'timeout', severity:'high', status:'retrying',
    ts:'2024-09-30T09:41:33Z', retries:2, maxRetries:3,
    message:'Worker-5: inference timeout after 30s. Model serving endpoint unresponsive.',
    rootCause:'Model serving pod OOM-killed (1.8GB heap vs 1.5GB limit). Kubernetes restart loop.',
    action:'Retry with reduced batch size (500 → 200 records). Pod memory limit raised to 2.5GB.',
    assignee:'SRE On-call · Andriy Bondar',
    eta:'09:58',
  },
  {
    id:'ERR-2024-0090', run:'fiscal_reform_q2_001', partition:'W4 P4-2',
    type:'backpressure', severity:'medium', status:'resolved',
    ts:'2024-09-30T09:41:35Z', retries:1, maxRetries:3,
    message:'Retry queue depth 142 exceeded threshold 100. Backpressure signalled.',
    rootCause:'Downstream from ERR-0091. Queue drain delayed by worker restart.',
    action:'Queue drained after worker recovery. No further action.',
    assignee:'Auto-resolved',
    eta:null,
  },
  {
    id:'ERR-2024-0089', run:'fiscal_reform_q2_001', partition:'W4 P4-1 pre-fetch',
    type:'embargo', severity:'medium', status:'escalated',
    ts:'2024-09-30T09:42:22Z', retries:0, maxRetries:0,
    message:'Pre-fetch for Shard C aborted: EMB-001 embargo active. READ access denied.',
    rootCause:'Embargo EMB-001 not accounted for in wave dependency planner. Missing embargo check step.',
    action:'Shard C queued pending embargo lift (2024-10-15). Dependency planner patch scheduled.',
    assignee:'Data Governance · Olena Kovalenko',
    eta:'2024-10-15',
  },
  {
    id:'ERR-2024-0088', run:'fiscal_reform_q2_001', partition:'W2 P2-3',
    type:'data_quality', severity:'low', status:'resolved',
    ts:'2024-09-30T09:00:12Z', retries:0, maxRetries:0,
    message:'200 records dropped during cross-source join: no matching citizen_id in Employment Registry.',
    rootCause:'Employment Registry SFTP delivered partial batch (36h lag vs expected 24h).',
    action:'Records flagged for manual review. Run continued with 41,980 records.',
    assignee:'Data Steward · Ivan Sydorenko',
    eta:null,
  },
];

const ERR_TYPE = {
  timeout:      { color:'var(--ember)', bg:'rgba(var(--ember-rgb), 0.10)', label:'Timeout',      icon:'⏱' },
  backpressure: { color:'var(--gold-vibrant)', bg:'rgba(var(--gold-vibrant-rgb), 0.10)', label:'Backpressure', icon:'⊳' },
  embargo:      { color:'var(--chart-secondary)', bg:'rgba(var(--blue-rgb), 0.10)', label:'Embargo',       icon:'⊘' },
  data_quality: { color:'var(--gold)', bg:'rgba(var(--gold-rgb), 0.10)', label:'Data Quality',  icon:'◈' },
};

const ERR_STATUS = {
  retrying:  { color:'var(--gold-vibrant)', bg:'rgba(var(--gold-vibrant-rgb), 0.10)', border:'rgba(var(--gold-vibrant-rgb), 0.3)', badge:'warn',    label:'Retrying'  },
  resolved:  { color:'var(--teal)', bg:'rgba(var(--teal-rgb), 0.10)',   border:'rgba(var(--teal-rgb), 0.25)',  badge:'ok',      label:'Resolved'  },
  escalated: { color:'var(--ember)', bg:'rgba(var(--ember-rgb), 0.10)',  border:'rgba(var(--ember-rgb), 0.28)', badge:'fail',    label:'Escalated' },
  open:      { color:'var(--ember)', bg:'rgba(var(--ember-rgb), 0.10)',  border:'rgba(var(--ember-rgb), 0.28)', badge:'fail',    label:'Open'      },
};

const SEV_COLOR = { high:'var(--ember)', medium:'var(--gold-vibrant)', low:'var(--slate)' };

function RetryBar({ retries, maxRetries }) {
  if (maxRetries === 0) return <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, color:'rgba(var(--slate-rgb), 0.5)' }}>No retry</span>;
  return (
    <div style={{ display:'flex', alignItems:'center', gap:8 }}>
      <div style={{ display:'flex', gap:3 }}>
        {Array.from({ length: maxRetries }).map((_, i) => (
          <div key={i} style={{ width:12, height:12, borderRadius:3,
            background: i < retries ? 'var(--gold-vibrant)' : 'rgba(var(--ink-rgb), 0.08)',
            border:`1px solid ${i < retries ? 'rgba(var(--gold-vibrant-rgb), 0.4)':'rgba(var(--ink-rgb), 0.1)'}` }} />
        ))}
      </div>
      <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, color:'rgba(var(--slate-rgb), 0.65)' }}>
        {retries}/{maxRetries}
      </span>
    </div>
  );
}

function FailureTriageScreen() {
  const [selId,   setSelId]   = React.useState('ERR-2024-0091');
  const [filter,  setFilter]  = React.useState('all');

  const visible = filter === 'all' ? FAILURES : FAILURES.filter(f => f.status === filter || f.severity === filter);
  const sel = FAILURES.find(f => f.id === selId);

  const openCount = FAILURES.filter(f => f.status === 'retrying' || f.status === 'escalated').length;

  return (
    <div style={{ display:'flex', gap:20, height:'100%' }}>

      {/* Error queue */}
      <div style={{ width:270, flexShrink:0, display:'flex', flexDirection:'column', gap:10 }}>
        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          <Eyebrow>D3 · Failure Triage</Eyebrow>
          {openCount > 0 && <Badge kind="fail">{openCount} open</Badge>}
        </div>

        {/* Filters */}
        <div style={{ display:'flex', gap:5, flexWrap:'wrap' }}>
          {['all','retrying','escalated','resolved'].map(f => (
            <button type="button" key={f} onClick={() => setFilter(f)}
              style={{ padding:'3px 9px', borderRadius:999, border:'none', cursor:'pointer',
                fontFamily:'"IBM Plex Mono",monospace', fontSize:9, fontWeight:700, letterSpacing:'0.06em',
                background: filter===f ? 'rgba(var(--ink-rgb), 0.1)':'rgba(var(--white-rgb), 0.65)',
                color: filter===f ? 'var(--ink)':'rgba(var(--slate-rgb), 0.65)',
                boxShadow: filter===f ? '0 0 0 1px rgba(var(--ink-rgb), 0.18)':'0 0 0 1px rgba(var(--ink-rgb), 0.08)' }}>
              {f.toUpperCase()}
            </button>
          ))}
        </div>

        {visible.map(err => {
          const tc  = ERR_TYPE[err.type];
          const sc  = ERR_STATUS[err.status];
          const isSel = selId === err.id;
          return (
            <InteractiveCard key={err.id} onClick={() => setSelId(err.id)} selected={isSel}
              ariaLabel={`Open failure ${err.id}. ${tc.label}. Severity ${err.severity}. Status ${sc.label}.`}
              style={{ padding:'11px 13px', borderRadius:16, cursor:'pointer',
                background: isSel ? sc.bg : 'rgba(var(--white-rgb), 0.56)',
                border:`1.5px solid ${isSel ? sc.color : 'rgba(var(--ink-rgb), 0.08)'}`,
                transition:'all 140ms' }}>
              <div style={{ display:'flex', justifyContent:'space-between', marginBottom:5 }}>
                <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, fontWeight:700, color:'rgba(var(--slate-rgb), 0.6)', letterSpacing:'0.06em' }}>{err.id}</span>
                <Badge kind={sc.badge}>{sc.label}</Badge>
              </div>
              <div style={{ display:'flex', alignItems:'center', gap:6, marginBottom:4 }}>
                <span style={{ fontSize:12, color:tc.color }}>{tc.icon}</span>
                <span style={{ fontSize:12, fontWeight:700, color:tc.color }}>{tc.label}</span>
                <span style={{ fontSize:10, fontFamily:'"IBM Plex Mono",monospace', color:SEV_COLOR[err.severity], fontWeight:700, marginLeft:'auto' }}>{err.severity.toUpperCase()}</span>
              </div>
              <div style={{ fontSize:11, color:'var(--slate)', lineHeight:1.4, marginBottom:4 }}>{err.partition}</div>
              <RetryBar retries={err.retries} maxRetries={err.maxRetries} />
            </InteractiveCard>
          );
        })}
      </div>

      {/* Detail */}
      {sel && (() => {
        const tc = ERR_TYPE[sel.type];
        const sc = ERR_STATUS[sel.status];
        return (
          <div style={{ flex:1, display:'flex', flexDirection:'column', gap:12 }}>

            <Panel style={{ padding:'16px 20px', background:sc.bg }}>
              <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', gap:12 }}>
                <div>
                  <div style={{ display:'flex', gap:8, alignItems:'center', marginBottom:6 }}>
                    <span style={{ fontSize:14, color:tc.color }}>{tc.icon}</span>
                    <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, fontWeight:700, color:'rgba(var(--slate-rgb), 0.7)', letterSpacing:'0.08em' }}>{sel.id}</span>
                    <Badge kind={sc.badge}>{sc.label}</Badge>
                    <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, fontWeight:700, color:SEV_COLOR[sel.severity] }}>{sel.severity.toUpperCase()}</span>
                  </div>
                  <h3 style={{ margin:0, fontSize:19, fontWeight:800, letterSpacing:'-0.03em', marginBottom:4 }}>{tc.label} · {sel.partition}</h3>
                  <p style={{ margin:0, fontFamily:'"IBM Plex Mono",monospace', fontSize:11, color:'rgba(var(--slate-rgb), 0.7)', lineHeight:1.6 }}>{sel.message}</p>
                </div>
                <div style={{ flexShrink:0, textAlign:'right' }}>
                  <div style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, color:'rgba(var(--slate-rgb), 0.55)' }}>
                    {sel.ts.slice(0,16).replace('T',' ')}
                  </div>
                  {sel.eta && (
                    <div style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, fontWeight:700, color:sc.color, marginTop:4 }}>
                      ETA {sel.eta}
                    </div>
                  )}
                </div>
              </div>
            </Panel>

            {/* Root cause */}
            <Panel>
              <Eyebrow style={{ marginBottom:8 }}>Root cause analysis</Eyebrow>
              <p style={{ margin:0, fontSize:13, color:'var(--ink)', lineHeight:1.65 }}>{sel.rootCause}</p>
            </Panel>

            {/* Action taken */}
            <Panel style={{ background:'rgba(var(--teal-rgb), 0.07)', border:'1px solid rgba(var(--teal-rgb), 0.2)' }}>
              <Eyebrow style={{ marginBottom:8, color:'rgba(var(--teal-rgb), 0.8)' }}>Action taken / planned</Eyebrow>
              <p style={{ margin:0, fontSize:13, color:'var(--teal)', lineHeight:1.65 }}>{sel.action}</p>
            </Panel>

            {/* Retry + assignee */}
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
              <Panel>
                <Eyebrow style={{ marginBottom:8 }}>Retry status</Eyebrow>
                <RetryBar retries={sel.retries} maxRetries={sel.maxRetries} />
                <div style={{ marginTop:8, fontFamily:'"IBM Plex Mono",monospace', fontSize:10, color:'rgba(var(--slate-rgb), 0.6)' }}>
                  {sel.maxRetries === 0 ? 'Non-retryable error type' : `${sel.maxRetries - sel.retries} attempt${sel.maxRetries - sel.retries !== 1?'s':''} remaining`}
                </div>
              </Panel>
              <Panel>
                <Eyebrow style={{ marginBottom:8 }}>Assignee</Eyebrow>
                <p style={{ margin:0, fontSize:13, fontWeight:600, color:'var(--ink)', lineHeight:1.5 }}>{sel.assignee}</p>
              </Panel>
            </div>

            {/* Run context */}
            <Panel>
              <Eyebrow style={{ marginBottom:8 }}>Run context</Eyebrow>
              <div style={{ display:'flex', gap:14 }}>
                <div>
                  <div style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.55)', marginBottom:2 }}>RUN</div>
                  <div style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, fontWeight:700, color:'var(--teal)' }}>{sel.run}</div>
                </div>
                <div>
                  <div style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.55)', marginBottom:2 }}>PARTITION</div>
                  <div style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, fontWeight:700, color:'var(--slate)' }}>{sel.partition}</div>
                </div>
              </div>
            </Panel>
          </div>
        );
      })()}
    </div>
  );
}

Object.assign(window, { FailureTriageScreen });
