// FairnessAudit.jsx — C3
// Disparate impact, demographic parity, equalised odds — across protected attributes
// Exports: FairnessAuditScreen

const PROTECTED_ATTRS = ['income_quartile','region_type','age_group','gender'];

const FAIRNESS_DATA = {
  income_quartile: {
    groups:['Q1','Q2','Q3','Q4'],
    approval:[0.341, 0.448, 0.521, 0.593],
    positive_pred:[0.342, 0.449, 0.523, 0.591],
    fpr:[0.091, 0.078, 0.063, 0.044],
    fnr:[0.148, 0.112, 0.088, 0.064],
    di: 0.76,
    dp_gap: 0.252,
    eo_gap: 0.084,
    di_pass: false,
    note:'Income_quartile is a protected attribute under fiscal fairness policy. DI 0.76 < threshold 0.80 — flagged. Feature recalibration applied (DSP-2024-041).',
  },
  region_type: {
    groups:['Urban','Peri-urban','Rural','Remote'],
    approval:[0.512, 0.489, 0.461, 0.438],
    positive_pred:[0.514, 0.491, 0.463, 0.440],
    fpr:[0.067, 0.071, 0.082, 0.094],
    fnr:[0.094, 0.099, 0.108, 0.118],
    di: 0.855,
    dp_gap: 0.074,
    eo_gap: 0.024,
    di_pass: true,
    note:'Region type shows mild urban/rural gradient. DI 0.855 > threshold. EO gap within tolerance. Monitor for cumulative drift.',
  },
  age_group: {
    groups:['18–30','31–45','46–60','60+'],
    approval:[0.468, 0.502, 0.491, 0.442],
    positive_pred:[0.471, 0.504, 0.493, 0.444],
    fpr:[0.088, 0.071, 0.075, 0.097],
    fnr:[0.102, 0.089, 0.092, 0.114],
    di: 0.877,
    dp_gap: 0.062,
    eo_gap: 0.026,
    di_pass: true,
    note:'Age 60+ shows slightly lower approval and higher FPR. DI 0.877 passes. FPR gap 0.026 within tolerance.',
  },
  gender: {
    groups:['Female','Male','Non-binary','Undisclosed'],
    approval:[0.488, 0.478, 0.491, 0.462],
    positive_pred:[0.490, 0.480, 0.493, 0.464],
    fpr:[0.074, 0.078, 0.071, 0.088],
    fnr:[0.098, 0.102, 0.094, 0.112],
    di: 0.941,
    dp_gap: 0.029,
    eo_gap: 0.018,
    di_pass: true,
    note:'Gender parity near-perfect. DI 0.941. Undisclosed cohort shows slightly elevated FNR — small n, interpret cautiously.',
  },
};

const METRIC_DEFS = {
  di:     { label:'Disparate Impact', threshold:'≥ 0.80', formula:'min(PR_g) / max(PR_g)', higherBetter:true  },
  dp_gap: { label:'Demographic Parity Gap', threshold:'≤ 0.10', formula:'max(PR) − min(PR)',  higherBetter:false },
  eo_gap: { label:'Equalised Odds Gap', threshold:'≤ 0.05', formula:'max(|FPR_i − FPR_j|)',  higherBetter:false },
};

function MetricStatus(val, metricId) {
  if (metricId === 'di')     return val >= 0.80 ? 'ok' : 'fail';
  if (metricId === 'dp_gap') return val <= 0.10 ? 'ok' : val <= 0.15 ? 'warn' : 'fail';
  if (metricId === 'eo_gap') return val <= 0.05 ? 'ok' : val <= 0.08 ? 'warn' : 'fail';
  return 'neutral';
}

const STATUS_COLOR = { ok:'var(--teal)', warn:'var(--gold-vibrant)', fail:'var(--ember)', neutral:'var(--slate)' };
const STATUS_BG    = { ok:'rgba(var(--teal-rgb), 0.1)', warn:'rgba(var(--gold-vibrant-rgb), 0.1)', fail:'rgba(var(--ember-rgb), 0.1)', neutral:'rgba(var(--slate-rgb), 0.07)' };

function GroupBar({ groups, values, color }) {
  const max = Math.max(...values);
  return (
    <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
      {groups.map((g, i) => (
        <div key={g} style={{ display:'flex', alignItems:'center', gap:10 }}>
          <span style={{ fontSize:10, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.7)', width:80, flexShrink:0 }}>{g}</span>
          <div style={{ flex:1, height:14, borderRadius:999, background:'rgba(var(--ink-rgb), 0.07)', overflow:'hidden' }}>
            <div style={{ height:'100%', borderRadius:999, background:color, width:`${(values[i]/max*100).toFixed(1)}%`, transition:'width 400ms' }} />
          </div>
          <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, fontWeight:700, color, width:40, textAlign:'right' }}>
            {(values[i]*100).toFixed(1)}%
          </span>
        </div>
      ))}
    </div>
  );
}

function FairnessAuditScreen() {
  const [attr,     setAttr]     = React.useState('income_quartile');
  const [metric,   setMetric]   = React.useState('approval');
  const [hovMetric,setHovMetric]= React.useState(null);

  const data = FAIRNESS_DATA[attr];
  const metricValues = { approval: data.approval, positive_pred: data.positive_pred, fpr: data.fpr, fnr: data.fnr };
  const displayValues = metricValues[metric];
  const barColor = metric === 'fpr' || metric === 'fnr' ? 'var(--ember-vibrant)' : 'var(--teal-vibrant)';

  return (
    <div style={{ display:'flex', gap:20, height:'100%' }}>

      {/* Main panel */}
      <div style={{ flex:1, minWidth:0, display:'flex', flexDirection:'column', gap:12 }}>

        {/* Toolbar */}
        <div style={{ display:'flex', alignItems:'center', gap:10, flexWrap:'wrap' }}>
          <Eyebrow>C3 · Fairness Audit</Eyebrow>
          <div style={{ flex:1 }} />
          <span style={{ fontSize:11, color:'rgba(var(--slate-rgb), 0.6)' }}>Attribute</span>
          {PROTECTED_ATTRS.map(a => (
            <button type="button" key={a} onClick={() => setAttr(a)}
              style={{ padding:'4px 10px', borderRadius:999, border:'none', cursor:'pointer',
                fontFamily:'"IBM Plex Mono",monospace', fontSize:10, fontWeight:700, letterSpacing:'0.06em',
                background: attr===a ? 'rgba(var(--ink-rgb), 0.09)':'rgba(var(--white-rgb), 0.6)',
                color: attr===a ? 'var(--ink)':'rgba(var(--slate-rgb), 0.65)',
                boxShadow: attr===a ? '0 0 0 1px rgba(var(--ink-rgb), 0.2)':'0 0 0 1px rgba(var(--ink-rgb), 0.08)' }}>
              {a}
            </button>
          ))}
        </div>

        {/* Headline metrics */}
        <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12 }}>
          {Object.entries(METRIC_DEFS).map(([key, def]) => {
            const val = data[key];
            const st = MetricStatus(val, key);
            const col = STATUS_COLOR[st];
            const isHov = hovMetric === key;
            return (
              <div key={key}
                onMouseEnter={() => setHovMetric(key)}
                onMouseLeave={() => setHovMetric(null)}
                style={{ padding:'14px 16px', borderRadius:18, cursor:'default',
                  background: st === 'ok' ? 'rgba(var(--white-rgb), 0.56)' : STATUS_BG[st],
                  border:`1.5px solid ${isHov ? col : (st==='ok' ? 'rgba(var(--ink-rgb), 0.08)' : col+'66')}`,
                  transition:'all 150ms' }}>
                <div style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', letterSpacing:'0.1em',
                  color:'rgba(var(--slate-rgb), 0.6)', marginBottom:6 }}>{def.label.toUpperCase()}</div>
                <div style={{ fontSize:28, fontWeight:800, letterSpacing:'-0.04em', color:col, marginBottom:3 }}>
                  {key === 'di' ? val.toFixed(3) : val.toFixed(3)}
                </div>
                <div style={{ fontSize:10, color:'rgba(var(--slate-rgb), 0.7)', marginBottom:4 }}>threshold {def.threshold}</div>
                <Badge kind={st==='ok'?'ok':st==='warn'?'warn':'fail'}>{st === 'ok' ? 'PASS' : st === 'warn' ? 'WARN' : 'FAIL'}</Badge>
                {isHov && (
                  <div style={{ marginTop:8, fontFamily:'"IBM Plex Mono",monospace', fontSize:10, color:'rgba(var(--slate-rgb), 0.7)' }}>
                    {def.formula}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Group breakdown */}
        <Panel style={{ flex:1 }}>
          <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:14 }}>
            <Eyebrow>Group breakdown · {attr}</Eyebrow>
            <div style={{ flex:1 }} />
            {[
              { id:'approval', label:'Approval Rate' },
              { id:'fpr',      label:'FPR' },
              { id:'fnr',      label:'FNR' },
            ].map(m => (
              <button type="button" key={m.id} onClick={() => setMetric(m.id)}
                style={{ padding:'4px 10px', borderRadius:999, border:'none', cursor:'pointer',
                  fontFamily:'"IBM Plex Mono",monospace', fontSize:9, fontWeight:700,
                  background: metric===m.id ? 'rgba(var(--ink-rgb), 0.09)':'rgba(var(--white-rgb), 0.6)',
                  color: metric===m.id ? 'var(--ink)':'rgba(var(--slate-rgb), 0.6)',
                  boxShadow:'0 0 0 1px rgba(var(--ink-rgb), 0.08)' }}>
                {m.label}
              </button>
            ))}
          </div>
          <GroupBar groups={data.groups} values={displayValues} color={barColor} />

          <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', margin:'16px 0' }} />
          <div style={{ fontSize:12, color:'var(--slate)', lineHeight:1.6, fontStyle:'italic' }}>
            {data.note}
          </div>
        </Panel>
      </div>

      {/* Attribute summary */}
      <div style={{ width:248, flexShrink:0 }}>
        <Panel style={{ height:'100%' }}>
          <PanelHeader eyebrow="Attribute summary" title="All attributes" />
          {PROTECTED_ATTRS.map(a => {
            const d = FAIRNESS_DATA[a];
            const diSt = MetricStatus(d.di, 'di');
            const dpSt = MetricStatus(d.dp_gap, 'dp_gap');
            const eoSt = MetricStatus(d.eo_gap, 'eo_gap');
            const worst = [diSt,dpSt,eoSt].includes('fail') ? 'fail' : [diSt,dpSt,eoSt].includes('warn') ? 'warn' : 'ok';
            const isSel = attr === a;
            return (
              <InteractiveCard key={a} onClick={() => setAttr(a)} selected={isSel}
                ariaLabel={`Select protected attribute ${a}. Overall status ${worst}.`}
                style={{ padding:'10px 12px', borderRadius:13, marginBottom:8, cursor:'pointer',
                  background: isSel ? STATUS_BG[worst] : 'rgba(var(--white-rgb), 0.52)',
                  border:`1.5px solid ${isSel ? STATUS_COLOR[worst] : 'rgba(var(--ink-rgb), 0.07)'}`,
                  transition:'all 140ms' }}>
                <div style={{ display:'flex', justifyContent:'space-between', marginBottom:5 }}>
                  <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, fontWeight:700, color:STATUS_COLOR[worst] }}>{a}</span>
                  <Badge kind={worst==='ok'?'ok':worst==='warn'?'warn':'fail'}>{worst==='ok'?'PASS':'FLAG'}</Badge>
                </div>
                <div style={{ display:'flex', gap:12 }}>
                  {[['DI', d.di, 'di'],['DP', d.dp_gap,'dp_gap'],['EO', d.eo_gap,'eo_gap']].map(([lbl, val, mid]) => {
                    const s = MetricStatus(val, mid);
                    return (
                      <div key={lbl}>
                        <div style={{ fontSize:8, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.55)' }}>{lbl}</div>
                        <div style={{ fontSize:11, fontWeight:700, color:STATUS_COLOR[s] }}>{val.toFixed(2)}</div>
                      </div>
                    );
                  })}
                </div>
              </InteractiveCard>
            );
          })}
          <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', margin:'14px 0' }} />
          <p style={{ fontSize:11, color:'var(--slate)', lineHeight:1.6, margin:0 }}>
            Thresholds: DI ≥ 0.80 · DP gap ≤ 0.10 · EO gap ≤ 0.05. Quarterly review cycle.
          </p>
        </Panel>
      </div>
    </div>
  );
}

Object.assign(window, { FairnessAuditScreen });
