// FreshnessBraid.jsx — B1
// Multi-strand braid: each source = strand, thickness = volume, color = lag-vs-SLA
// Governing lag = slowest upstream. Exports: FreshnessBraidScreen

const BRAID_SOURCES = [
  { id:'fiscal',   label:'Fiscal DB',            icon:'▪', vol:9, lagH:2,   slaH:4,  desc:'Batch pull every 2h' },
  { id:'budget_iv',label:'Budget Cycle IV',       icon:'◇', vol:2, lagH:0.5, slaH:2,  desc:'Kafka stream, ~30min lag' },
  { id:'employ',   label:'Employment Registry',   icon:'▪', vol:5, lagH:36,  slaH:24, desc:'Daily SFTP, overnight run' },
  { id:'gdp',      label:'GDP Tracker',           icon:'○', vol:3, lagH:6,   slaH:12, desc:'REST pull every 6h' },
  { id:'tax',      label:'Tax Records',           icon:'▪', vol:8, lagH:72,  slaH:48, desc:'Weekly batch, 3-day lag' },
];

function lagStatus(lagH, slaH) {
  const r = lagH / slaH;
  if (r <= 0.6) return 'ok';
  if (r <= 1.0) return 'warn';
  return 'fail';
}

const BRAID_STATUS = {
  ok:   { stroke:'var(--teal-vibrant)', fill:'rgba(var(--teal-vibrant-rgb), 0.15)', label:'Within SLA',   badge:'ok'   },
  warn: { stroke:'var(--gold-vibrant)', fill:'rgba(var(--gold-vibrant-rgb), 0.15)', label:'Near SLA',     badge:'warn' },
  fail: { stroke:'var(--ember-vibrant)', fill:'rgba(var(--ember-vibrant-rgb), 0.15)',  label:'SLA breached', badge:'fail' },
};

function volToW(vol) { return 5 + vol * 1.6; }

function lagLabel(h) {
  if (h < 1) return `${Math.round(h*60)}m`;
  if (h < 24) return `${h}h`;
  return `${(h/24).toFixed(1)}d`;
}

function bezierPath(x1, y1, x2, y2) {
  const mx = (x1 + x2) / 2;
  return `M ${x1} ${y1} C ${mx} ${y1} ${mx} ${y2} ${x2} ${y2}`;
}

function JoinBadge({ x, y, govSource, status }) {
  const cfg = BRAID_STATUS[status];
  const w = 130, h = 36, rx = 8;
  return (
    <g>
      <circle cx={x} cy={y} r={10} fill={cfg.stroke} opacity={0.9} />
      <circle cx={x} cy={y} r={6}  fill="white" opacity={0.9} />
      <rect x={x+14} y={y-h/2} width={w} height={h} rx={rx}
        fill="rgba(var(--paper-rgb), 0.96)" stroke={cfg.stroke} strokeWidth={1.5}
        style={{ filter:'drop-shadow(0 4px 10px rgba(var(--ink-rgb), 0.12))' }} />
      <text x={x+21} y={y-6}
        fontSize={8} fontFamily='"IBM Plex Mono",monospace' fontWeight={700}
        letterSpacing={1} fill={cfg.stroke}>
        GOVERNING LAG
      </text>
      <text x={x+21} y={y+8}
        fontSize={11} fontFamily='"Manrope",sans-serif' fontWeight={700} fill="var(--ink)">
        {lagLabel(govSource.lagH)} · {govSource.label}
      </text>
    </g>
  );
}

function Tooltip({ src, x, y }) {
  if (!src) return null;
  const status = lagStatus(src.lagH, src.slaH);
  const cfg = BRAID_STATUS[status];
  const w = 180, h = 72;
  const tx = Math.min(x + 12, 860 - w - 8);
  const ty = Math.max(y - h - 8, 8);
  return (
    <g style={{ pointerEvents:'none' }}>
      <rect x={tx} y={ty} width={w} height={h} rx={10}
        fill="rgba(var(--paper-rgb), 0.97)" stroke="rgba(var(--ink-rgb), 0.1)" strokeWidth={1}
        style={{ filter:'drop-shadow(0 6px 14px rgba(var(--ink-rgb), 0.14))' }} />
      <rect x={tx} y={ty+10} width={3} height={h-20} rx={1.5} fill={cfg.stroke} opacity={0.7} />
      <text x={tx+11} y={ty+22} fontSize={9} fontWeight={700}
        fontFamily='"IBM Plex Mono",monospace' fill={cfg.stroke} letterSpacing={1}>
        {cfg.label.toUpperCase()}
      </text>
      <text x={tx+11} y={ty+38} fontSize={12} fontWeight={700}
        fontFamily='"Manrope",sans-serif' fill="var(--ink)">{src.label}</text>
      <text x={tx+11} y={ty+52} fontSize={10}
        fontFamily='"Manrope",sans-serif' fill="var(--slate)">
        lag {lagLabel(src.lagH)} · SLA {lagLabel(src.slaH)} · {src.desc}
      </text>
      <text x={tx+11} y={ty+64} fontSize={9}
        fontFamily='"IBM Plex Mono",monospace' fill="rgba(var(--slate-rgb), 0.6)">
        vol ×{src.vol} · ratio {(src.lagH/src.slaH).toFixed(2)}
      </text>
    </g>
  );
}

function FreshnessBraidScreen() {
  const [hovSrc, setHovSrc]     = React.useState(null);
  const [hovPos, setHovPos]     = React.useState({ x:0, y:0 });
  const svgRef                  = React.useRef(null);

  function toSVG(e) {
    const r = svgRef.current?.getBoundingClientRect();
    if (!r) return { x:0, y:0 };
    return { x:(e.clientX-r.left)/r.width*860, y:(e.clientY-r.top)/r.height*510 };
  }

  // Layout
  const VBW = 860, VBH = 510;
  const SRC_X = 40;
  // Group A: fiscal (y=72) + budget_iv (y=162) → JA (x=310, y=108)
  // Group B: employ (y=260) + gdp (y=350) → JB (x=310, y=298)
  // Standalone: tax (y=455) → OUT
  // OUT (x=590, y=270): JA + JB + tax
  // END (x=810, y=270)
  const SY = { fiscal:72, budget_iv:162, employ:258, gdp:348, tax:452 };
  const JA = { x:310, y:108 };
  const JB = { x:310, y:298 };
  const OUT = { x:590, y:270 };

  // Compute statuses
  const statuses = Object.fromEntries(
    BRAID_SOURCES.map(s => [s.id, lagStatus(s.lagH, s.slaH)])
  );
  const fiscalSrc    = BRAID_SOURCES.find(s => s.id === 'fiscal');
  const budgetSrc    = BRAID_SOURCES.find(s => s.id === 'budget_iv');
  const employSrc    = BRAID_SOURCES.find(s => s.id === 'employ');
  const gdpSrc       = BRAID_SOURCES.find(s => s.id === 'gdp');
  const taxSrc       = BRAID_SOURCES.find(s => s.id === 'tax');

  const govJA  = fiscalSrc.lagH >= budgetSrc.lagH ? fiscalSrc : budgetSrc;
  const govJB  = employSrc.lagH >= gdpSrc.lagH    ? employSrc : gdpSrc;
  const govOUT = [govJA, govJB, taxSrc].reduce((m,s) => s.lagH>m.lagH?s:m);
  const statusJA  = lagStatus(govJA.lagH,  govJA.slaH);
  const statusJB  = lagStatus(govJB.lagH,  govJB.slaH);
  const statusOUT = lagStatus(govOUT.lagH, govOUT.slaH);

  function strand(srcId, x2, y2) {
    const src  = BRAID_SOURCES.find(s => s.id === srcId);
    const st   = statuses[srcId];
    const cfg  = BRAID_STATUS[st];
    const w    = volToW(src.vol);
    const y1   = SY[srcId];
    const d    = bezierPath(SRC_X + w/2, y1, x2, y2);
    return (
      <g key={srcId}>
        <path d={d} fill="none" stroke={cfg.stroke} strokeWidth={w}
          strokeLinecap="round" opacity={0.72}
          style={{ cursor:'pointer', transition:'opacity 140ms' }}
          onMouseEnter={e => { setHovSrc(src); const p=toSVG(e); setHovPos(p); }}
          onMouseLeave={() => setHovSrc(null)}
        />
      </g>
    );
  }

  function joinStrand(x1, y1, x2, y2, status, vol) {
    const cfg = BRAID_STATUS[status];
    const w   = volToW(vol);
    const d   = bezierPath(x1, y1, x2, y2);
    return (
      <path d={d} fill="none" stroke={cfg.stroke} strokeWidth={w}
        strokeLinecap="round" opacity={0.78} />
    );
  }

  const outW = volToW(BRAID_SOURCES.reduce((s,src)=>s+src.vol, 0)/3);

  return (
    <div style={{ display:'flex', gap:20, height:'100%' }}>
      <div style={{ flex:1, minWidth:0, display:'flex', flexDirection:'column', gap:12 }}>

        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          <Eyebrow>B1 · Freshness Braid</Eyebrow>
          <div style={{ flex:1 }} />
          {Object.entries(BRAID_STATUS).map(([key, cfg]) => (
            <div key={key} style={{ display:'flex', alignItems:'center', gap:5, padding:'3px 9px', borderRadius:999, background:cfg.fill, border:`1px solid ${cfg.stroke}30` }}>
              <div style={{ width:6, height:6, borderRadius:'50%', background:cfg.stroke }} />
              <span style={{ fontSize:10, fontFamily:'"IBM Plex Mono",monospace', color:cfg.stroke, fontWeight:700 }}>{cfg.label}</span>
            </div>
          ))}
        </div>

        <Panel style={{ padding:0, flex:1, overflow:'hidden', minHeight:380 }}>
          <svg ref={svgRef} width="100%" viewBox={`0 0 ${VBW} ${VBH}`}
            style={{ display:'block', userSelect:'none' }}>
            <defs>
              <pattern id="braid-grid" width="30" height="30" patternUnits="userSpaceOnUse">
                <circle cx="15" cy="15" r="0.8" fill="rgba(var(--ink-rgb), 0.06)" />
              </pattern>
            </defs>
            <rect width={VBW} height={VBH} fill="url(#braid-grid)" />

            {/* Source labels */}
            {BRAID_SOURCES.map(src => {
              const st  = statuses[src.id];
              const cfg = BRAID_STATUS[st];
              const y   = SY[src.id];
              const w   = volToW(src.vol);
              return (
                <g key={src.id}>
                  {/* Volume pip */}
                  <rect x={SRC_X - 4} y={y - w/2} width={4} height={w} rx={2} fill={cfg.stroke} opacity={0.6} />
                  <text x={SRC_X - 10} y={y + 4} textAnchor="end"
                    fontSize={10} fontFamily='"Manrope",sans-serif' fontWeight={600} fill={cfg.stroke}>
                    {src.label}
                  </text>
                  <text x={SRC_X - 10} y={y + 16} textAnchor="end"
                    fontSize={8.5} fontFamily='"IBM Plex Mono",monospace' fill="rgba(var(--slate-rgb), 0.65)">
                    {lagLabel(src.lagH)} / SLA {lagLabel(src.slaH)}
                  </text>
                </g>
              );
            })}

            {/* Strands: sources → first joins */}
            {strand('fiscal',    JA.x, JA.y)}
            {strand('budget_iv', JA.x, JA.y)}
            {strand('employ',    JB.x, JB.y)}
            {strand('gdp',       JB.x, JB.y)}
            {strand('tax',       OUT.x, OUT.y)}

            {/* Strands: joins → output */}
            {joinStrand(JA.x, JA.y, OUT.x, OUT.y, statusJA,  govJA.vol  + 2)}
            {joinStrand(JB.x, JB.y, OUT.x, OUT.y, statusJB,  govJB.vol  + 3)}

            {/* Output strand */}
            <path d={`M ${OUT.x} ${OUT.y} L 810 ${OUT.y}`}
              fill="none" stroke={BRAID_STATUS[statusOUT].stroke}
              strokeWidth={outW} strokeLinecap="round" opacity={0.85} />

            {/* Join node A */}
            <JoinBadge x={JA.x} y={JA.y} govSource={govJA} status={statusJA} />

            {/* Join node B */}
            <JoinBadge x={JB.x} y={JB.y} govSource={govJB} status={statusJB} />

            {/* Output node */}
            <circle cx={OUT.x} cy={OUT.y} r={14}
              fill={BRAID_STATUS[statusOUT].stroke} opacity={0.9} />
            <circle cx={OUT.x} cy={OUT.y} r={8} fill="white" opacity={0.9} />

            {/* Output label */}
            <rect x={OUT.x+18} y={OUT.y-26} width={192} height={52} rx={10}
              fill="rgba(var(--paper-rgb), 0.97)"
              stroke={BRAID_STATUS[statusOUT].stroke} strokeWidth={1.5}
              style={{ filter:'drop-shadow(0 4px 12px rgba(var(--ink-rgb), 0.14))' }} />
            <text x={OUT.x+28} y={OUT.y-10}
              fontSize={8} fontFamily='"IBM Plex Mono",monospace' fontWeight={700}
              letterSpacing={1} fill={BRAID_STATUS[statusOUT].stroke}>
              GOVERNING LAG — DERIVED FACT
            </text>
            <text x={OUT.x+28} y={OUT.y+6}
              fontSize={12} fontFamily='"Manrope",sans-serif' fontWeight={800} fill="var(--ink)">
              {lagLabel(govOUT.lagH)} · {govOUT.label}
            </text>
            <text x={OUT.x+28} y={OUT.y+20}
              fontSize={9.5} fontFamily='"Manrope",sans-serif' fill="var(--ember)">
              SLA breached — 1.5× over limit
            </text>

            {/* Tooltip */}
            {hovSrc && <Tooltip src={hovSrc} x={hovPos.x} y={hovPos.y} />}
          </svg>
        </Panel>
      </div>

      {/* Source table */}
      <div style={{ width:256, flexShrink:0 }}>
        <Panel style={{ height:'100%' }}>
          <PanelHeader eyebrow="Sources" title="Freshness table" />
          {BRAID_SOURCES.map(src => {
            const st  = lagStatus(src.lagH, src.slaH);
            const cfg = BRAID_STATUS[st];
            const pct = Math.min(src.lagH / src.slaH, 2);
            return (
              <div key={src.id} style={{ marginBottom:14, paddingBottom:14, borderBottom:'1px solid rgba(var(--ink-rgb), 0.07)' }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:4 }}>
                  <span style={{ fontSize:12, fontWeight:700, color:'var(--ink)' }}>{src.label}</span>
                  <Badge kind={cfg.badge}>{st}</Badge>
                </div>
                <div style={{ height:5, borderRadius:999, background:'rgba(var(--ink-rgb), 0.08)', overflow:'hidden', marginBottom:4 }}>
                  <div style={{ height:'100%', borderRadius:999, background:cfg.stroke, width:`${Math.min(pct*50,100)}%`, transition:'width 300ms' }} />
                </div>
                <div style={{ display:'flex', justifyContent:'space-between' }}>
                  <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:cfg.stroke, fontWeight:700 }}>
                    lag {lagLabel(src.lagH)}
                  </span>
                  <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:'rgba(var(--slate-rgb), 0.6)' }}>
                    SLA {lagLabel(src.slaH)}
                  </span>
                </div>
                <div style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:'rgba(var(--slate-rgb), 0.55)', marginTop:2 }}>
                  vol ×{src.vol} · {src.desc}
                </div>
              </div>
            );
          })}
        </Panel>
      </div>
    </div>
  );
}

Object.assign(window, { FreshnessBraidScreen });
