// IdentifiabilitySurface.jsx — A2
// Identifiability landscape: every model parameter as a coloured cell
// Exports: IdentifiabilitySurfaceScreen

const A2_STATUS = {
  identified: { label:'Point-identified', short:'POINT-ID', color:'var(--teal)', bg:'rgba(var(--teal-rgb), 0.15)',  border:'rgba(var(--teal-rgb), 0.40)',  badge:'ok'      },
  partial:    { label:'Partially-identified', short:'PARTIAL', color:'var(--gold-vibrant)', bg:'rgba(var(--gold-vibrant-rgb), 0.14)', border:'rgba(var(--gold-vibrant-rgb), 0.40)', badge:'warn'  },
  set:        { label:'Set-identified',    short:'SET-ID',   color:'var(--ember)', bg:'rgba(var(--ember-rgb), 0.13)', border:'rgba(var(--ember-rgb), 0.38)', badge:'fail'    },
  untraced:   { label:'Unidentified',      short:'NONE',     color:'var(--slate)', bg:'rgba(var(--slate-rgb), 0.08)',  border:'rgba(var(--slate-rgb), 0.26)',  badge:'neutral' },
};

const A2_GROUPS = [
  { name:'Direct Effects', params:[
    { id:'p1', name:'β Policy→Poverty',     status:'identified', ev:3.8, bounds:null,              strategy:'Back-door adjustment', needs:null },
    { id:'p2', name:'β Policy→Tax Revenue', status:'identified', ev:4.2, bounds:null,              strategy:'Back-door adjustment', needs:null },
    { id:'p3', name:'β Policy→Employment',  status:'identified', ev:2.9, bounds:null,              strategy:'Front-door criterion', needs:null },
    { id:'p4', name:'β Policy→Spending',    status:'identified', ev:2.7, bounds:null,              strategy:'Front-door criterion', needs:null },
  ]},
  { name:'Mediation', params:[
    { id:'p5', name:'β Employment→Poverty', status:'identified', ev:3.1, bounds:null,              strategy:'Front-door criterion', needs:null },
    { id:'p6', name:'β Spending→Poverty',   status:'identified', ev:2.4, bounds:null,              strategy:'Front-door criterion', needs:null },
    { id:'p7', name:'β Spending→Tax Rev',   status:'identified', ev:3.6, bounds:null,              strategy:'Front-door criterion', needs:null },
    { id:'p8', name:'Indirect via Empl.',   status:'partial',    ev:1.9, bounds:'[−0.12, −0.08]', strategy:'Manski bounds',        needs:'Monotone treatment response assumption required' },
  ]},
  { name:'Heterogeneous Effects', params:[
    { id:'p9',  name:'CATE · Urban cohort', status:'partial',  ev:1.6, bounds:'[−0.08, −0.03]', strategy:'Manski bounds', needs:'Region-level panel data with urban stratification' },
    { id:'p10', name:'CATE · Rural cohort', status:'partial',  ev:1.4, bounds:'[−0.06, 0.01]',  strategy:'Manski bounds', needs:'Rural-specific instrumental variable' },
    { id:'p11', name:'CATE · Q1 Income',    status:'set',      ev:1.2, bounds:'[−0.15, 0.02]',  strategy:'Robins bounds', needs:'Income-stratified RCT or sharp RDD at income threshold' },
    { id:'p12', name:'CATE · Q4 Income',    status:'set',      ev:1.1, bounds:'[−0.04, 0.08]',  strategy:'Robins bounds', needs:'Income-stratified RCT or DiD' },
    { id:'p13', name:'CATE · Age < 35',     status:'set',      ev:1.3, bounds:'[−0.12, 0.04]',  strategy:'Robins bounds', needs:'Age-cohort IV or DiD by cohort entry year' },
    { id:'p14', name:'LATE (IV compliers)', status:'partial',  ev:1.8, bounds:'[−0.10, −0.04]', strategy:'IV / LATE',     needs:'Strong first stage F>10 under monotonicity assumption' },
  ]},
  { name:'Long-run & Dynamic', params:[
    { id:'p15', name:'ATE (3-year horizon)',  status:'set',      ev:1.1, bounds:'[−0.20, 0.05]',  strategy:'Robins bounds', needs:'3-year follow-up panel; synthetic control validation' },
    { id:'p16', name:'ATE (5-year horizon)',  status:'untraced', ev:null, bounds:null,             strategy:null,            needs:'5-year longitudinal dataset does not yet exist' },
    { id:'p17', name:'Dynamic treatment eff', status:'set',      ev:1.0, bounds:'[−0.18, 0.10]',  strategy:'Robins bounds', needs:'Sequential treatment randomisation or LMTP estimator' },
    { id:'p18', name:'Policy persistence',    status:'untraced', ev:null, bounds:null,             strategy:null,            needs:'No valid identification strategy under current data plan' },
  ]},
  { name:'Spillover & Equilibrium', params:[
    { id:'p19', name:'Geographic spillover',   status:'untraced', ev:null, bounds:null,            strategy:null,            needs:'Spatial IV or geographic discontinuity design' },
    { id:'p20', name:'Network spillover',      status:'untraced', ev:null, bounds:null,            strategy:null,            needs:'Peer-randomised experiment with network data' },
    { id:'p21', name:'General equil. effect',  status:'untraced', ev:null, bounds:null,            strategy:null,            needs:'Structural GE model with equilibrium closure' },
    { id:'p22', name:'Peer effects',           status:'set',      ev:1.0, bounds:'[−0.30, 0.30]', strategy:'Manski bounds', needs:'Network-randomised experiment or excludable network IV' },
  ]},
];

const A2_WIZARD = {
  untraced: [
    'Add this parameter to the data collection plan',
    'Commission a targeted RCT or quasi-experiment',
    'Engage a methodologist for identification design',
  ],
  set: [
    'Widen the identification strategy (relax assumptions)',
    'Collect additional data to tighten the bounds',
    'Run a sensitivity analysis over the bounds interval',
  ],
  partial: [
    'Verify assumption holds in this context',
    'Collect auxiliary data to promote to point-identified',
    'Report bounds alongside point estimate',
  ],
};

function IdentifiabilitySurfaceScreen() {
  const [filter, setFilter]     = React.useState('all');
  const [selected, setSelected] = React.useState(null); // param object

  const allParams = React.useMemo(() => A2_GROUPS.flatMap(g => g.params), []);
  const counts = React.useMemo(() => {
    const c = { identified:0, partial:0, set:0, untraced:0 };
    allParams.forEach(p => { c[p.status]++; });
    return c;
  }, [allParams]);

  const filteredGroups = React.useMemo(() =>
    A2_GROUPS.map(g => ({
      ...g,
      params: g.params.filter(p => filter === 'all' || p.status === filter),
    })).filter(g => g.params.length > 0),
  [filter]);

  const sel = selected ? A2_STATUS[selected.status] : null;

  return (
    <div style={{ display:'flex', gap:20, height:'100%' }}>

      {/* Main surface */}
      <div style={{ flex:1, minWidth:0, display:'flex', flexDirection:'column', gap:14 }}>

        {/* Header */}
        <div style={{ display:'flex', alignItems:'center', gap:8, flexWrap:'wrap' }}>
          <Eyebrow>A2 · Identifiability Surface</Eyebrow>
          <div style={{ flex:1 }} />
          {/* Summary chips */}
          {Object.entries(A2_STATUS).map(([key, cfg]) => (
            <button key={key} type="button" aria-pressed={filter === key ? 'true' : 'false'} style={{
              display:'flex', alignItems:'center', gap:5,
              minHeight:'var(--target-min-compact)', padding:'4px 10px', borderRadius:999, cursor:'pointer',
              background: filter === key ? cfg.bg : 'rgba(var(--white-rgb), 0.55)',
              border: `1px solid ${filter === key ? cfg.border : 'rgba(var(--ink-rgb), 0.09)'}`,
              transition:'all 140ms',
            }} onClick={() => setFilter(f => f === key ? 'all' : key)}>
              <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, fontWeight:700, letterSpacing:'0.08em', color:cfg.color }}>{cfg.short}</span>
              <span style={{ fontSize:11, fontFamily:'"IBM Plex Mono",monospace', color:cfg.color, fontWeight:600 }}>{counts[key]}</span>
            </button>
          ))}
          <button type="button"
            onClick={() => setFilter('all')}
            style={{ padding:'4px 10px', borderRadius:999, fontSize:11, border:'1px solid rgba(var(--ink-rgb), 0.09)', background: filter==='all' ? 'rgba(var(--ink-rgb), 0.06)':'rgba(var(--white-rgb), 0.55)', color:'var(--slate)', cursor:'pointer', fontFamily:'"IBM Plex Mono",monospace', letterSpacing:'0.06em' }}
          >ALL</button>
        </div>

        {/* Parameter grid */}
        <div style={{ flex:1, overflowY:'auto' }}>
          {filteredGroups.map(group => (
            <div key={group.name} style={{ marginBottom:20 }}>
              <Eyebrow style={{ marginBottom:8, color:'rgba(var(--ink-rgb), 0.38)' }}>{group.name}</Eyebrow>
              <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(186px,1fr))', gap:8 }}>
                {group.params.map(param => {
                  const cfg = A2_STATUS[param.status];
                  const isSel = selected?.id === param.id;
                  return (
                    <InteractiveCard
                      key={param.id}
                      onClick={() => setSelected(s => s?.id === param.id ? null : param)}
                      selected={isSel}
                      ariaLabel={`Toggle parameter ${param.name}. Status ${cfg.label}.`}
                      style={{
                        padding:'12px 14px', borderRadius:14, cursor:'pointer',
                        background: cfg.bg,
                        border: `1.5px solid ${isSel ? cfg.color : cfg.border}`,
                        boxShadow: isSel ? `0 0 0 2px ${cfg.border}` : 'none',
                        transition:'border-color 140ms, box-shadow 140ms',
                      }}
                    >
                      {/* Status chip */}
                      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:6 }}>
                        <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:8, fontWeight:700, letterSpacing:'0.1em', color:cfg.color }}>{cfg.short}</span>
                        {param.ev !== null && (
                          <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:cfg.color, opacity:0.75 }}>E={param.ev}</span>
                        )}
                      </div>
                      {/* Name */}
                      <div style={{ fontSize:12, fontWeight:700, color:'var(--ink)', lineHeight:1.35, marginBottom:4 }}>{param.name}</div>
                      {/* Bounds */}
                      {param.bounds && (
                        <div style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, color:cfg.color, marginTop:2 }}>{param.bounds}</div>
                      )}
                      {param.status === 'untraced' && (
                        <div style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:'rgba(var(--slate-rgb), 0.5)', marginTop:2 }}>no bounds available</div>
                      )}
                    </InteractiveCard>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Inspector + Wizard */}
      <div style={{ width:272, flexShrink:0, display:'flex', flexDirection:'column', gap:12 }}>

        <Panel style={{ flex:1 }}>
          <PanelHeader
            eyebrow="Parameter detail"
            title={selected ? selected.name : 'Select a parameter'}
          />

          {!selected ? (
            <div>
              {/* Legend */}
              {Object.entries(A2_STATUS).map(([key, cfg]) => (
                <div key={key} style={{ display:'flex', alignItems:'center', gap:10, marginBottom:10 }}>
                  <div style={{ width:14, height:14, borderRadius:4, background:cfg.bg, border:`1.5px solid ${cfg.border}`, flexShrink:0 }} />
                  <div>
                    <div style={{ fontSize:12, fontWeight:600, color:cfg.color }}>{cfg.label}</div>
                    <div style={{ fontSize:10, color:'rgba(var(--slate-rgb), 0.7)', fontFamily:'"IBM Plex Mono",monospace' }}>{counts[key]} params</div>
                  </div>
                </div>
              ))}
              <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', margin:'14px 0' }} />
              <p style={{ fontSize:12, color:'var(--slate)', lineHeight:1.6, margin:0 }}>
                Click any cell to inspect bounds, identification strategy, and the wizard for closing the gap.
              </p>
            </div>
          ) : (
            <div>
              <div style={{ marginBottom:14 }}>
                <Badge kind={sel.badge}>{sel.label}</Badge>
              </div>

              {/* E-value */}
              {selected.ev !== null && (
                <>
                  <Eyebrow style={{ marginBottom:6 }}>E-value</Eyebrow>
                  <div style={{ display:'flex', alignItems:'baseline', gap:8, marginBottom:14 }}>
                    <span style={{ fontSize:28, fontWeight:800, letterSpacing:'-0.04em', color:sel.color }}>{selected.ev}</span>
                    <span style={{ fontSize:11, color:'rgba(var(--slate-rgb), 0.7)' }}>min. bias to explain away</span>
                  </div>
                </>
              )}

              {/* Bounds */}
              {selected.bounds && (
                <>
                  <Eyebrow style={{ marginBottom:6 }}>Manski / Robins Bounds</Eyebrow>
                  <div style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:14, fontWeight:700, color:sel.color, marginBottom:14 }}>{selected.bounds}</div>
                </>
              )}

              {/* Strategy */}
              {selected.strategy && (
                <>
                  <Eyebrow style={{ marginBottom:6 }}>Current strategy</Eyebrow>
                  <div style={{ fontSize:13, fontWeight:600, color:'var(--ink)', marginBottom:14 }}>{selected.strategy}</div>
                </>
              )}

              {/* Wizard */}
              {(selected.status === 'set' || selected.status === 'partial' || selected.status === 'untraced') && (
                <>
                  <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', margin:'14px 0' }} />
                  <Eyebrow style={{ marginBottom:8 }}>What would identify this?</Eyebrow>
                  <div style={{
                    padding:'10px 12px', borderRadius:12, marginBottom:10,
                    background:'rgba(var(--white-rgb), 0.55)', border:'1px solid rgba(var(--ink-rgb), 0.08)',
                  }}>
                    <p style={{ fontSize:12, color:'var(--ink)', lineHeight:1.6, margin:0, fontWeight:500 }}>
                      {selected.needs}
                    </p>
                  </div>
                  {A2_WIZARD[selected.status].map((step, i) => (
                    <div key={i} style={{ display:'flex', gap:8, marginBottom:6, alignItems:'flex-start' }}>
                      <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:sel.color, fontWeight:700, marginTop:2, flexShrink:0 }}>{i+1}.</span>
                      <span style={{ fontSize:11, color:'var(--slate)', lineHeight:1.5 }}>{step}</span>
                    </div>
                  ))}
                </>
              )}

              <button type="button" onClick={() => setSelected(null)} style={{ marginTop:12, fontSize:11, color:'rgba(var(--slate-rgb), 0.7)', background:'none', border:'none', cursor:'pointer', padding:0 }}>
                ← All parameters
              </button>
            </div>
          )}
        </Panel>

        {/* Coverage summary bar */}
        <Panel>
          <Eyebrow style={{ marginBottom:10 }}>Coverage</Eyebrow>
          {Object.entries(A2_STATUS).map(([key, cfg]) => (
            <div key={key} style={{ display:'flex', alignItems:'center', gap:8, marginBottom:7 }}>
              <div style={{ flex:1, height:5, borderRadius:999, background:'rgba(var(--ink-rgb), 0.07)', overflow:'hidden' }}>
                <div style={{ height:'100%', borderRadius:999, background:cfg.color, width:`${(counts[key]/allParams.length*100).toFixed(0)}%`, transition:'width 400ms' }} />
              </div>
              <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:cfg.color, fontWeight:700, minWidth:18, textAlign:'right' }}>{counts[key]}</span>
              <span style={{ fontSize:10, color:'rgba(var(--slate-rgb), 0.75)', minWidth:100 }}>{cfg.label}</span>
            </div>
          ))}
        </Panel>
      </div>
    </div>
  );
}

Object.assign(window, { IdentifiabilitySurfaceScreen });
