// LineageGravityMap.jsx — B6
// Force-directed lineage graph: heavier nodes = more downstream dependencies
// Hover → "how many decision packets go dark if this source degrades"
// Exports: LineageGravityScreen

const LG_NODES = [
  // Raw sources
  { id:'fiscal_db',   label:'Fiscal DB',         layer:0, y:80,  deps:12, type:'source',  status:'ok'   },
  { id:'employ_reg',  label:'Employment Reg.',    layer:0, y:195, deps:8,  type:'source',  status:'warn' },
  { id:'gdp_track',   label:'GDP Tracker',        layer:0, y:295, deps:5,  type:'source',  status:'ok'   },
  { id:'tax_records', label:'Tax Records',        layer:0, y:400, deps:14, type:'source',  status:'fail' },
  { id:'budget_iv',   label:'Budget Cycle IV',    layer:0, y:490, deps:4,  type:'source',  status:'ok'   },
  // Derived datasets
  { id:'econ_ds',     label:'Economic Dataset',   layer:1, y:195, deps:9,  type:'dataset', status:'warn' },
  { id:'policy_ctx',  label:'Policy Context',     layer:1, y:370, deps:7,  type:'dataset', status:'ok'   },
  // Model cards
  { id:'fiscal_model',label:'Fiscal Reform Model',layer:2, y:220, deps:6,  type:'model',   status:'ok'   },
  { id:'poverty_mdl', label:'Poverty Model',      layer:2, y:390, deps:3,  type:'model',   status:'ok'   },
  // Policy documents
  { id:'fiscal_pol',  label:'Fiscal Reform Policy',layer:3,y:240, deps:5,  type:'policy',  status:'ok'   },
  { id:'tax_pol',     label:'Tax Revenue Policy', layer:3, y:400, deps:2,  type:'policy',  status:'ok'   },
  // Decisions/runs
  { id:'dec_001',     label:'Decision D-Q3-001',  layer:4, y:155, deps:0,  type:'decision',status:'ok'   },
  { id:'dec_002',     label:'Decision D-Q3-002',  layer:4, y:255, deps:0,  type:'decision',status:'ok'   },
  { id:'run_001',     label:'Run fiscal_001',      layer:4, y:355, deps:0,  type:'run',     status:'ok'   },
  { id:'run_002',     label:'Run fiscal_002',      layer:4, y:455, deps:0,  type:'run',     status:'ok'   },
];

const LG_EDGES = [
  { from:'fiscal_db',   to:'econ_ds'    },
  { from:'employ_reg',  to:'econ_ds'    },
  { from:'gdp_track',   to:'econ_ds'    },
  { from:'tax_records', to:'econ_ds'    },
  { from:'fiscal_db',   to:'policy_ctx' },
  { from:'budget_iv',   to:'policy_ctx' },
  { from:'econ_ds',     to:'fiscal_model'},
  { from:'econ_ds',     to:'poverty_mdl' },
  { from:'policy_ctx',  to:'fiscal_model'},
  { from:'fiscal_model',to:'fiscal_pol'  },
  { from:'poverty_mdl', to:'fiscal_pol'  },
  { from:'poverty_mdl', to:'tax_pol'     },
  { from:'fiscal_pol',  to:'dec_001'     },
  { from:'fiscal_pol',  to:'dec_002'     },
  { from:'fiscal_pol',  to:'run_001'     },
  { from:'tax_pol',     to:'run_002'     },
];

const NODE_TYPE_CFG = {
  source:  { color:'var(--chart-secondary)', fill:'rgba(var(--blue-rgb), 0.12)',  label:'Source'   },
  dataset: { color:'var(--teal)', fill:'rgba(var(--teal-rgb), 0.12)',   label:'Dataset'  },
  model:   { color:'var(--gold)', fill:'rgba(var(--gold-rgb), 0.12)',  label:'Model'    },
  policy:  { color:'var(--slate)', fill:'rgba(var(--slate-rgb), 0.10)',   label:'Policy'   },
  decision:{ color:'var(--teal)', fill:'rgba(var(--teal-rgb), 0.12)',   label:'Decision' },
  run:     { color:'var(--teal-vibrant)', fill:'rgba(var(--teal-vibrant-rgb), 0.10)', label:'Run'      },
};

const STATUS_CFG = {
  ok:   { stroke:'rgba(var(--teal-rgb), 0.5)',   glow:null },
  warn: { stroke:'rgba(var(--gold-vibrant-rgb), 0.7)', glow:'rgba(var(--gold-vibrant-rgb), 0.25)' },
  fail: { stroke:'rgba(var(--ember-vibrant-rgb), 0.8)',  glow:'rgba(var(--ember-vibrant-rgb), 0.3)'   },
};

// Layer x positions in SVG viewBox (0 0 940 560)
const LAYER_X = [60, 220, 400, 590, 770];
const NODE_R_BASE = 6, NODE_R_SCALE = 1.8; // radius = base + deps * scale
function nodeR(deps) { return Math.min(NODE_R_BASE + deps * NODE_R_SCALE, 34); }

// Downstream count: how many leaves (decisions/runs) depend on this node
const DOWNSTREAM_COUNTS = {
  fiscal_db:    4, employ_reg: 4, gdp_track: 4, tax_records: 4, budget_iv: 4,
  econ_ds:      4, policy_ctx: 4,
  fiscal_model: 3, poverty_mdl: 1,
  fiscal_pol:   3, tax_pol: 1,
  dec_001:0, dec_002:0, run_001:0, run_002:0,
};

// Refined: simulate realistic downstream
const DARK_IF_DEGRADED = {
  fiscal_db:    { decisions:4, runs:3, total:7 },
  employ_reg:   { decisions:4, runs:3, total:7 },
  gdp_track:    { decisions:4, runs:3, total:7 },
  tax_records:  { decisions:4, runs:4, total:8 },
  budget_iv:    { decisions:3, runs:2, total:5 },
  econ_ds:      { decisions:4, runs:3, total:7 },
  policy_ctx:   { decisions:4, runs:2, total:6 },
  fiscal_model: { decisions:3, runs:1, total:4 },
  poverty_mdl:  { decisions:1, runs:1, total:2 },
  fiscal_pol:   { decisions:2, runs:1, total:3 },
  tax_pol:      { decisions:0, runs:1, total:1 },
};

function nodePos(node) {
  return { x: LAYER_X[node.layer], y: node.y };
}

function LineageGravityScreen() {
  const [hovNode,    setHovNode]    = React.useState(null);
  const [selNode,    setSelNode]    = React.useState(null);
  const [showLabels, setShowLabels] = React.useState(true);
  const svgRef                     = React.useRef(null);
  const [hovPos,     setHovPos]     = React.useState({ x:0, y:0 });

  const nodeMap = React.useMemo(() => Object.fromEntries(LG_NODES.map(n => [n.id, n])), []);
  const selNodeObj = selNode ? nodeMap[selNode] : null;
  const hovNodeObj = hovNode ? nodeMap[hovNode] : null;

  // Highlight: when a node is selected/hovered, dim unrelated edges/nodes
  function isRelated(nodeId) {
    if (!selNode && !hovNode) return true;
    const focus = selNode || hovNode;
    if (nodeId === focus) return true;
    return LG_EDGES.some(e => (e.from === focus && e.to === nodeId) || (e.to === focus && e.from === nodeId));
  }

  function isEdgeRelated(edge) {
    if (!selNode && !hovNode) return false; // no highlight
    const focus = selNode || hovNode;
    return edge.from === focus || edge.to === focus;
  }

  const VBW = 940, VBH = 565;

  function toSVG(e) {
    const r = svgRef.current?.getBoundingClientRect();
    if (!r) return { x:0, y:0 };
    return { x:(e.clientX-r.left)/r.width*VBW, y:(e.clientY-r.top)/r.height*VBH };
  }

  return (
    <div style={{ display:'flex', gap:20, height:'100%' }}>

      {/* Canvas */}
      <div style={{ flex:1, minWidth:0, display:'flex', flexDirection:'column', gap:12 }}>

        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          <Eyebrow>B6 · Lineage Gravity Map</Eyebrow>
          <div style={{ flex:1 }} />
          <label style={{ display:'flex', alignItems:'center', gap:6, fontSize:12, color:'var(--slate)', cursor:'pointer' }}>
            <input type="checkbox" checked={showLabels} onChange={e => setShowLabels(e.target.checked)} />
            Labels
          </label>
          {selNode && (
            <Button variant="ghost" size="sm" onClick={() => setSelNode(null)}>Clear selection</Button>
          )}
        </div>

        <Panel style={{ padding:0, flex:1, overflow:'hidden', minHeight:380 }}>
          <svg ref={svgRef} width="100%" viewBox={`0 0 ${VBW} ${VBH}`}
            style={{ display:'block', userSelect:'none' }}
            onMouseMove={e => setHovPos(toSVG(e))}>

            <defs>
              <pattern id="lg-dots" width="28" height="28" patternUnits="userSpaceOnUse">
                <circle cx="14" cy="14" r="0.9" fill="rgba(var(--ink-rgb), 0.065)" />
              </pattern>
              <filter id="fail-glow" x="-60%" y="-60%" width="220%" height="220%">
                <feGaussianBlur stdDeviation="5" result="blur"/>
                <feComposite in="SourceGraphic" in2="blur" operator="over"/>
              </filter>
            </defs>
            <rect width={VBW} height={VBH} fill="url(#lg-dots)" />

            {/* Layer labels */}
            {[['Sources',0],['Datasets',1],['Models',2],['Policies',3],['Decisions',4]].map(([lbl,i]) => (
              <text key={lbl} x={LAYER_X[i]} y={22} textAnchor="middle"
                fontSize={9} fontFamily='"IBM Plex Mono",monospace' fontWeight={600}
                fill="rgba(var(--ink-rgb), 0.3)" letterSpacing={1.2}>
                {lbl.toUpperCase()}
              </text>
            ))}

            {/* Edges */}
            {LG_EDGES.map((edge, i) => {
              const src = nodeMap[edge.from], tgt = nodeMap[edge.to];
              if (!src || !tgt) return null;
              const sp = nodePos(src), tp = nodePos(tgt);
              const r1 = nodeR(src.deps), r2 = nodeR(tgt.deps);
              const mx = (sp.x + r1 + tp.x - r2) / 2;
              const isHighlit = isEdgeRelated(edge);
              const isAny = !selNode && !hovNode;
              return (
                <path key={i}
                  d={`M ${sp.x+r1} ${sp.y} C ${mx} ${sp.y} ${mx} ${tp.y} ${tp.x-r2} ${tp.y}`}
                  fill="none"
                  stroke={isHighlit ? 'var(--teal-vibrant)' : 'rgba(var(--slate-rgb), 0.22)'}
                  strokeWidth={isHighlit ? 1.8 : 1.2}
                  opacity={isAny ? 0.55 : isHighlit ? 1 : 0.18}
                  style={{ transition:'opacity 180ms, stroke 180ms' }}
                />
              );
            })}

            {/* Nodes */}
            {LG_NODES.map(node => {
              const p = nodePos(node);
              const r = nodeR(node.deps);
              const tcfg = NODE_TYPE_CFG[node.type];
              const scfg = STATUS_CFG[node.status];
              const isHov = hovNode === node.id;
              const isSel = selNode === node.id;
              const rel = isRelated(node.id);
              const dark = DARK_IF_DEGRADED[node.id];

              return (
                <g key={node.id}
                  role="button"
                  tabIndex={0}
                  focusable="true"
                  aria-label={`Select lineage node ${node.label}. Status ${scfg.label}.`}
                  style={{ cursor:'pointer' }}
                  onMouseEnter={() => setHovNode(node.id)}
                  onMouseLeave={() => setHovNode(null)}
                  onClick={() => setSelNode(s => s === node.id ? null : node.id)}
                  onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setSelNode(s => s === node.id ? null : node.id); } }}
                  opacity={rel ? 1 : 0.25}
                >
                  {/* Fail glow */}
                  {node.status === 'fail' && (
                    <circle cx={p.x} cy={p.y} r={r+8} fill="rgba(var(--ember-vibrant-rgb), 0.22)" filter="url(#fail-glow)" />
                  )}
                  {node.status === 'warn' && (
                    <circle cx={p.x} cy={p.y} r={r+6} fill="rgba(var(--gold-vibrant-rgb), 0.18)" />
                  )}
                  {/* Hover/select ring */}
                  {(isHov || isSel) && (
                    <circle cx={p.x} cy={p.y} r={r+5} fill="none"
                      stroke={tcfg.color} strokeWidth={2} opacity={0.5} />
                  )}
                  {/* Body */}
                  <circle cx={p.x} cy={p.y} r={r}
                    fill={tcfg.fill}
                    stroke={node.status !== 'ok' ? scfg.stroke : tcfg.color}
                    strokeWidth={node.status !== 'ok' ? 2.5 : 1.5}
                    style={{ transition:'r 300ms' }}
                  />
                  {/* Node type glyph */}
                  {r > 14 && (
                    <text x={p.x} y={p.y+1} textAnchor="middle" dominantBaseline="middle"
                      fontSize={r > 22 ? 11 : 9} fontFamily='"IBM Plex Mono",monospace'
                      fontWeight={700} fill={tcfg.color} opacity={0.8}>
                      {node.deps || ''}
                    </text>
                  )}
                  {/* Label */}
                  {showLabels && (
                    <text x={p.x} y={p.y + r + 12} textAnchor="middle"
                      fontSize={9} fontFamily='"Manrope",sans-serif' fontWeight={600}
                      fill={isSel || isHov ? tcfg.color : 'rgba(var(--ink-rgb), 0.55)'}
                      style={{ transition:'fill 160ms' }}>
                      {node.label.length > 16 ? node.label.slice(0,15)+'…' : node.label}
                    </text>
                  )}
                </g>
              );
            })}

            {/* Hover tooltip */}
            {hovNodeObj && (() => {
              const p = nodePos(hovNodeObj);
              const dark = DARK_IF_DEGRADED[hovNodeObj.id];
              const tx = Math.min(p.x + nodeR(hovNodeObj.deps) + 12, VBW - 220);
              const ty = Math.max(p.y - 50, 8);
              if (!dark || dark.total === 0) return null;
              return (
                <g style={{ pointerEvents:'none' }}>
                  <rect x={tx} y={ty} width={210} height={76} rx={10}
                    fill="rgba(var(--paper-rgb), 0.97)" stroke="rgba(var(--ink-rgb), 0.1)" strokeWidth={1}
                    style={{ filter:'drop-shadow(0 6px 14px rgba(var(--ink-rgb), 0.14))' }} />
                  <rect x={tx} y={ty+10} width={3} height={56} rx={1.5}
                    fill={hovNodeObj.status==='fail'?'var(--ember-vibrant)':hovNodeObj.status==='warn'?'var(--gold-vibrant)':'var(--teal-vibrant)'} />
                  <text x={tx+11} y={ty+22} fontSize={9} fontWeight={700}
                    fontFamily='"IBM Plex Mono",monospace' letterSpacing={1}
                    fill="rgba(var(--slate-rgb), 0.7)">IF THIS DEGRADES</text>
                  <text x={tx+11} y={ty+40} fontSize={14} fontWeight={800}
                    fontFamily='"Manrope",sans-serif' fill="var(--ember)">
                    {dark.total} outputs go dark
                  </text>
                  <text x={tx+11} y={ty+58} fontSize={10}
                    fontFamily='"Manrope",sans-serif' fill="var(--slate)">
                    {dark.decisions} decisions · {dark.runs} runs
                  </text>
                  <text x={tx+11} y={ty+70} fontSize={9}
                    fontFamily='"IBM Plex Mono",monospace' fill="rgba(var(--slate-rgb), 0.55)">
                    {NODE_TYPE_CFG[hovNodeObj.type].label} · deps {hovNodeObj.deps}
                  </text>
                </g>
              );
            })()}
          </svg>
        </Panel>
      </div>

      {/* Inspector */}
      <div style={{ width:252, flexShrink:0, display:'flex', flexDirection:'column', gap:12 }}>
        <Panel style={{ flex:1 }}>
          <PanelHeader eyebrow="Gravity Inspector" title={selNodeObj ? selNodeObj.label : 'Node detail'} />

          {!selNodeObj ? (
            <div>
              <Eyebrow style={{ marginBottom:10 }}>Node types</Eyebrow>
              {Object.entries(NODE_TYPE_CFG).map(([key, cfg]) => {
                const count = LG_NODES.filter(n => n.type === key).length;
                if (!count) return null;
                return (
                  <div key={key} style={{ display:'flex', alignItems:'center', gap:8, marginBottom:8 }}>
                    <div style={{ width:12, height:12, borderRadius:'50%', background:cfg.fill, border:`1.5px solid ${cfg.color}`, flexShrink:0 }} />
                    <span style={{ fontSize:12, color:cfg.color, fontWeight:600 }}>{cfg.label}</span>
                    <span style={{ marginLeft:'auto', fontFamily:'"IBM Plex Mono",monospace', fontSize:10, color:'var(--slate)' }}>{count}</span>
                  </div>
                );
              })}
              <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', margin:'14px 0' }} />
              <Eyebrow style={{ marginBottom:8 }}>Critical nodes</Eyebrow>
              {LG_NODES.filter(n => DARK_IF_DEGRADED[n.id]?.total >= 5).sort((a,b)=>(DARK_IF_DEGRADED[b.id]?.total||0)-(DARK_IF_DEGRADED[a.id]?.total||0)).map(n => {
                const dark = DARK_IF_DEGRADED[n.id];
                const cfg = NODE_TYPE_CFG[n.type];
                return (
                  <div key={n.id} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:7 }}>
                    <span style={{ fontSize:11, color:'var(--ink)', fontWeight:600 }}>{n.label}</span>
                    <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, color:'var(--ember)', fontWeight:700 }}>{dark.total}↓</span>
                  </div>
                );
              })}
              <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', margin:'14px 0' }} />
              <p style={{ fontSize:12, color:'var(--slate)', lineHeight:1.6, margin:0 }}>
                Node size = downstream dependencies. Hover to see impact. Click to highlight lineage.
              </p>
            </div>
          ) : (
            <div>
              <div style={{ marginBottom:14, display:'flex', gap:8 }}>
                <Badge kind={STATUS_CFG[selNodeObj.status] ? (selNodeObj.status==='ok'?'ok':selNodeObj.status==='warn'?'warn':'fail') : 'neutral'}>
                  {selNodeObj.status}
                </Badge>
                <Badge kind="neutral">{NODE_TYPE_CFG[selNodeObj.type].label}</Badge>
              </div>

              {DARK_IF_DEGRADED[selNodeObj.id]?.total > 0 && (
                <>
                  <Eyebrow style={{ marginBottom:6 }}>Impact if degraded</Eyebrow>
                  <div style={{ fontSize:28, fontWeight:800, letterSpacing:'-0.04em', color:'var(--ember)', marginBottom:4 }}>
                    {DARK_IF_DEGRADED[selNodeObj.id].total} outputs
                  </div>
                  <div style={{ fontSize:12, color:'var(--slate)', marginBottom:14 }}>
                    {DARK_IF_DEGRADED[selNodeObj.id].decisions} decisions · {DARK_IF_DEGRADED[selNodeObj.id].runs} runs go dark
                  </div>
                </>
              )}

              <Eyebrow style={{ marginBottom:8 }}>Connected to</Eyebrow>
              {LG_EDGES.filter(e => e.from === selNodeObj.id || e.to === selNodeObj.id).map((edge, i) => {
                const otherId = edge.from === selNodeObj.id ? edge.to : edge.from;
                const other = nodeMap[otherId];
                const isOut = edge.from === selNodeObj.id;
                if (!other) return null;
                const cfg = NODE_TYPE_CFG[other.type];
                return (
                  <InteractiveCard key={i} ariaLabel={`Select connected node ${other.label}`} style={{ display:'flex', alignItems:'center', gap:7, padding:'7px 10px', borderRadius:10, marginBottom:5,
                    background:'rgba(var(--white-rgb), 0.54)', border:'1px solid rgba(var(--ink-rgb), 0.07)', cursor:'pointer' }}
                    onClick={() => setSelNode(otherId)}>
                    <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, color:'rgba(var(--slate-rgb), 0.6)' }}>{isOut ? '→':'←'}</span>
                    <span style={{ fontSize:11, fontWeight:600, color:cfg.color }}>{other.label}</span>
                  </InteractiveCard>
                );
              })}
              <button type="button" onClick={() => setSelNode(null)} style={{ marginTop:12, fontSize:11, color:'rgba(var(--slate-rgb), 0.7)', background:'none', border:'none', cursor:'pointer', padding:0 }}>
                ← All nodes
              </button>
            </div>
          )}
        </Panel>
      </div>
    </div>
  );
}

Object.assign(window, { LineageGravityScreen });
