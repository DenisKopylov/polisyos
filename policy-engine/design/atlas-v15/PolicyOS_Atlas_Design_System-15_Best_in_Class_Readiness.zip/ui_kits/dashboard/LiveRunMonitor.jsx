// LiveRunMonitor.jsx — D2
// Real-time run progress: throughput chart, latency heatmap, live log tail
// Exports: LiveRunMonitorScreen

// Simulated time-series data (60 ticks = 60 seconds)
function genSeries(base, noise, spike) {
  return Array.from({ length: 60 }, (_, i) => {
    const s = spike && (i === 22 || i === 23) ? base * 3.2 : 0;
    return Math.max(0, base + (Math.random() - 0.5) * noise + s);
  });
}

const THROUGHPUT = genSeries(680, 120, true);  // records/sec
const LATENCY_P50 = genSeries(148, 30, false);
const LATENCY_P99 = genSeries(480, 120, true);
const ERROR_RATE  = genSeries(0.4, 0.3, true);

// Heatmap: 12 rows (workers) × 20 cols (time windows)
const HEATMAP = Array.from({ length: 12 }, (_, row) =>
  Array.from({ length: 20 }, (_, col) => {
    if (col < 8)  return Math.random() * 0.3 + 0.1;   // early: warm-up
    if (col < 12) return Math.random() * 0.4 + 0.55;  // mid: hot
    if (row === 4 && col >= 14 && col <= 16) return 1.0; // spike on worker 5
    return Math.random() * 0.5 + 0.3;
  })
);

const LOG_ENTRIES = [
  { t:'09:41:02', level:'INFO',  msg:'W4 P4-1 complete. 14,000 records inferred. p50=141ms p99=412ms.' },
  { t:'09:41:08', level:'INFO',  msg:'W4 P4-2 started. Shard B 14,000–28,000. Worker pool: 8 threads.' },
  { t:'09:41:33', level:'WARN',  msg:'Worker-5 latency spike detected: p99=1,840ms. Circuit breaker armed.' },
  { t:'09:41:35', level:'WARN',  msg:'Retry queue depth: 142. Backpressure active on Shard B.' },
  { t:'09:41:48', level:'INFO',  msg:'Circuit breaker released. Worker-5 recovered. Latency normalising.' },
  { t:'09:42:01', level:'INFO',  msg:'Throughput: 672 rec/s. ETA Shard B complete: +14m.' },
  { t:'09:42:10', level:'INFO',  msg:'Embargo check: fiscal_reform_dataset EMB-001 — ACTIVE. Read access denied for Shard C pre-fetch.' },
  { t:'09:42:22', level:'ERROR', msg:'Shard C pre-fetch aborted: EMB-001 embargo active until 2024-10-15.' },
  { t:'09:42:28', level:'INFO',  msg:'Shard C queued pending W4 P4-2 completion and embargo lift.' },
];

const LOG_COLORS = { INFO:'var(--teal)', WARN:'var(--gold-vibrant)', ERROR:'var(--ember)' };

function MiniChart({ data, color, h=48, label, unit, latest, alertThreshold }) {
  const min = Math.min(...data), max = Math.max(...data), range = max - min || 1;
  const w = 180;
  const pts = data.map((v, i) => ({
    x: (i / (data.length - 1)) * w,
    y: h - ((v - min) / range) * (h - 6) - 3,
  }));
  const polyStr = pts.map(p => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ');
  const areaD = `M ${pts[0].x} ${h} L ${pts.map(p=>`${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' L ')} L ${pts[pts.length-1].x} ${h} Z`;
  const isAlert = alertThreshold && latest > alertThreshold;

  return (
    <div style={{ padding:'12px 14px', borderRadius:16,
      background: isAlert ? 'rgba(var(--ember-rgb), 0.08)':'rgba(var(--white-rgb), 0.56)',
      border:`1.5px solid ${isAlert ? 'rgba(var(--ember-rgb), 0.3)':'rgba(var(--ink-rgb), 0.08)'}`,
      transition:'all 200ms' }}>
      <div style={{ display:'flex', justifyContent:'space-between', marginBottom:6 }}>
        <span style={{ fontSize:10, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.65)', letterSpacing:'0.06em' }}>{label.toUpperCase()}</span>
        <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:12, fontWeight:700, color: isAlert ? 'var(--ember)':color }}>
          {typeof latest === 'number' ? latest.toFixed(latest < 10 ? 1 : 0) : latest} {unit}
        </span>
      </div>
      <svg width={w} height={h} style={{ display:'block' }}>
        <path d={areaD} fill={color} opacity={0.08} />
        <polyline points={polyStr} fill="none" stroke={color} strokeWidth={1.6} strokeLinejoin="round" strokeLinecap="round" />
        {isAlert && (
          <line x1={pts[pts.length-1].x} y1={0} x2={pts[pts.length-1].x} y2={h}
            stroke="var(--ember-vibrant)" strokeWidth={1} strokeDasharray="3 2" opacity={0.5} />
        )}
      </svg>
    </div>
  );
}

function HeatmapCell({ value }) {
  const color = value < 0.4
    ? `rgba(var(--teal-rgb), ${0.1 + value * 0.6})`
    : value < 0.75
    ? `rgba(var(--gold-vibrant-rgb), ${0.2 + (value - 0.4) * 0.9})`
    : `rgba(var(--ember-vibrant-rgb), ${0.3 + (value - 0.75) * 2.4})`;
  return (
    <div style={{ width:'100%', paddingBottom:'100%', position:'relative', borderRadius:3 }}>
      <div style={{ position:'absolute', inset:1, borderRadius:3, background:color, transition:'background 200ms' }} />
    </div>
  );
}

function LiveRunMonitorScreen() {
  const [tick, setTick]       = React.useState(59);
  const [paused, setPaused]   = React.useState(false);
  const [logFilter, setLF]    = React.useState('ALL');

  // Simulate live ticking
  React.useEffect(() => {
    if (paused) return;
    const id = setInterval(() => {
      setTick(t => (t + 1) % 60);
    }, 800);
    return () => clearInterval(id);
  }, [paused]);

  const window20 = THROUGHPUT.slice(Math.max(0, tick - 19), tick + 1);
  const latestTP  = THROUGHPUT[tick];
  const latestP50 = LATENCY_P50[tick];
  const latestP99 = LATENCY_P99[tick];
  const latestER  = ERROR_RATE[tick];

  const visibleLogs = logFilter === 'ALL' ? LOG_ENTRIES : LOG_ENTRIES.filter(l => l.level === logFilter);

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:14, height:'100%' }}>

      {/* Toolbar */}
      <div style={{ display:'flex', alignItems:'center', gap:10 }}>
        <Eyebrow>D2 · Live Run Monitor</Eyebrow>
        <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, color:'rgba(var(--slate-rgb), 0.6)' }}>fiscal_reform_q2_001 · W4 P4-2</span>
        <div style={{ flex:1 }} />
        <div style={{ display:'flex', alignItems:'center', gap:6, padding:'4px 10px', borderRadius:999,
          background:'rgba(var(--gold-vibrant-rgb), 0.12)', border:'1px solid rgba(var(--gold-vibrant-rgb), 0.3)' }}>
          <div style={{ width:6, height:6, borderRadius:'50%', background:'var(--gold-vibrant)',
            animation: paused ? 'none':'pulse 1s ease-in-out infinite' }} />
          <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, fontWeight:700, color:'var(--gold-vibrant)' }}>
            {paused ? 'PAUSED':'LIVE'}
          </span>
        </div>
        <Button variant="ghost" size="sm" onClick={() => setPaused(p => !p)}>
          {paused ? '▶ Resume':'⏸ Pause'}
        </Button>
      </div>

      {/* Metric charts */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12 }}>
        <MiniChart data={THROUGHPUT} color="var(--teal-vibrant)" label="Throughput" unit="rec/s" latest={latestTP} />
        <MiniChart data={LATENCY_P50} color="var(--chart-secondary)" label="Latency p50" unit="ms" latest={latestP50} />
        <MiniChart data={LATENCY_P99} color="var(--gold-vibrant)" label="Latency p99" unit="ms" latest={latestP99} alertThreshold={1000} />
        <MiniChart data={ERROR_RATE} color="var(--ember-vibrant)" label="Error rate" unit="%" latest={latestER} alertThreshold={2} />
      </div>

      <div style={{ flex:1, display:'flex', gap:14, minHeight:0 }}>
        {/* Worker latency heatmap */}
        <Panel style={{ flex:1 }}>
          <PanelHeader eyebrow="Worker latency heatmap" title="12 workers × 20 time windows" />
          <div style={{ display:'flex', gap:4, marginBottom:8, alignItems:'center' }}>
            {['Low','Mid','High'].map((l,i) => (
              <React.Fragment key={l}>
                <div style={{ width:12, height:12, borderRadius:3, flexShrink:0,
                  background: i===0?'rgba(var(--teal-rgb), 0.4)':i===1?'rgba(var(--gold-vibrant-rgb), 0.5)':'rgba(var(--ember-vibrant-rgb), 0.7)' }} />
                <span style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.6)', marginRight:8 }}>{l}</span>
              </React.Fragment>
            ))}
          </div>
          <div style={{ display:'grid', gridTemplateRows:`repeat(12,1fr)`, gap:3, flex:1 }}>
            {HEATMAP.map((row, ri) => (
              <div key={ri} style={{ display:'grid', gridTemplateColumns:'repeat(20,1fr)', gap:3, alignItems:'center' }}>
                <div style={{ gridColumn:'1/2', fontSize:8, fontFamily:'"IBM Plex Mono",monospace',
                  color:'rgba(var(--slate-rgb), 0.4)', textAlign:'right', paddingRight:4, gridRow:1 }}>
                  W{ri+1}
                </div>
                {row.map((val, ci) => (
                  <div key={ci} style={{ gridColumn:`${ci+2}/${ci+3}` }}>
                    <HeatmapCell value={val} />
                  </div>
                ))}
              </div>
            ))}
          </div>
          <div style={{ display:'flex', justifyContent:'space-between', marginTop:8 }}>
            <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:8, color:'rgba(var(--slate-rgb), 0.4)' }}>08:00</span>
            <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:8, color:'rgba(var(--ember-vibrant-rgb), 0.7)', fontWeight:700 }}>▶ NOW</span>
            <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:8, color:'rgba(var(--slate-rgb), 0.4)' }}>10:00</span>
          </div>
        </Panel>

        {/* Log tail */}
        <Panel style={{ width:340, flexShrink:0, display:'flex', flexDirection:'column' }}>
          <div style={{ display:'flex', alignItems:'center', gap:6, marginBottom:12 }}>
            <Eyebrow>Log tail</Eyebrow>
            <div style={{ flex:1 }} />
            {['ALL','INFO','WARN','ERROR'].map(f => (
              <button type="button" key={f} onClick={() => setLF(f)}
                style={{ padding:'2px 7px', borderRadius:999, border:'none', cursor:'pointer',
                  fontFamily:'"IBM Plex Mono",monospace', fontSize:8, fontWeight:700,
                  background: logFilter===f ? (f==='ERROR'?'rgba(var(--ember-rgb), 0.15)':f==='WARN'?'rgba(var(--gold-vibrant-rgb), 0.15)':'rgba(var(--ink-rgb), 0.1)'):'rgba(var(--white-rgb), 0.6)',
                  color: f==='ERROR'?'var(--ember)':f==='WARN'?'var(--gold-vibrant)':f==='INFO'?'var(--teal)':'var(--slate)' }}>
                {f}
              </button>
            ))}
          </div>
          <div style={{ flex:1, overflowY:'auto', display:'flex', flexDirection:'column', gap:6 }}>
            {visibleLogs.map((log, i) => (
              <div key={i} style={{ padding:'7px 10px', borderRadius:10,
                background: log.level==='ERROR'?'rgba(var(--ember-rgb), 0.07)':log.level==='WARN'?'rgba(var(--gold-vibrant-rgb), 0.07)':'rgba(var(--white-rgb), 0.5)',
                border:`1px solid ${log.level==='ERROR'?'rgba(var(--ember-rgb), 0.18)':log.level==='WARN'?'rgba(var(--gold-vibrant-rgb), 0.18)':'rgba(var(--ink-rgb), 0.07)'}` }}>
                <div style={{ display:'flex', gap:8, marginBottom:3 }}>
                  <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:'rgba(var(--slate-rgb), 0.5)' }}>{log.t}</span>
                  <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, fontWeight:700, color:LOG_COLORS[log.level] }}>{log.level}</span>
                </div>
                <p style={{ margin:0, fontSize:11, color:'var(--ink)', lineHeight:1.5, fontFamily:'"IBM Plex Mono",monospace' }}>{log.msg}</p>
              </div>
            ))}
          </div>
        </Panel>
      </div>

      <style>{`@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.3} }`}</style>
    </div>
  );
}

Object.assign(window, { LiveRunMonitorScreen });
