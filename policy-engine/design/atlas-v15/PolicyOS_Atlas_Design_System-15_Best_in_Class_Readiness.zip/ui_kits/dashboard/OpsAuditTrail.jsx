// OpsAuditTrail.jsx — D5
// Immutable chronological ops log: every system action, human action, override, config change
// Exports: OpsAuditTrailScreen

const AUDIT_EVENTS = [
  { id:'AUD-001', ts:'2024-09-30T08:00:02Z', actor:'Policy Engine · Scheduler',  type:'system',   action:'Run initiated',          detail:'fiscal_reform_q2_001 · config v2.1 · wave plan 5 waves / 13 partitions', run:'fiscal_reform_q2_001' },
  { id:'AUD-002', ts:'2024-09-30T08:00:04Z', actor:'Data Steward Automation',     type:'system',   action:'Embargo check performed', detail:'EMB-001 (fiscal_reform_dataset): ACTIVE — downstream write blocked', run:'fiscal_reform_q2_001' },
  { id:'AUD-003', ts:'2024-09-30T08:00:12Z', actor:'Policy Engine · Ingestion',   type:'system',   action:'W1 P1-1 started',         detail:'Fiscal DB pull initiated. Schema v2.1 expected.', run:'fiscal_reform_q2_001' },
  { id:'AUD-004', ts:'2024-09-30T08:18:44Z', actor:'Policy Engine · Ingestion',   type:'system',   action:'W1 P1-1 complete',        detail:'42,180 records pulled. Completeness 99.4%.', run:'fiscal_reform_q2_001' },
  { id:'AUD-005', ts:'2024-09-30T08:19:01Z', actor:'Policy Engine · Ingestion',   type:'system',   action:'W1 P1-2 started',         detail:'Employment Registry SFTP pull. 36h lag acknowledged.', run:'fiscal_reform_q2_001' },
  { id:'AUD-006', ts:'2024-09-30T08:34:08Z', actor:'Policy Engine · Ingestion',   type:'system',   action:'W1 P1-2 complete',        detail:'42,042 records. Completeness 94.7% (missing 2,138 employment_status).', run:'fiscal_reform_q2_001' },
  { id:'AUD-007', ts:'2024-09-30T08:35:00Z', actor:'Policy Engine · Validation',  type:'system',   action:'W2 started',              detail:'Schema validation, completeness check, cross-source join.', run:'fiscal_reform_q2_001' },
  { id:'AUD-008', ts:'2024-09-30T09:00:14Z', actor:'Policy Engine · Validation',  type:'system',   action:'W2 complete',             detail:'41,980 records joined. 200 dropped (no matching citizen_id).', run:'fiscal_reform_q2_001' },
  { id:'AUD-009', ts:'2024-09-30T09:00:18Z', actor:'Ivan Sydorenko',              type:'human',    action:'Manual QA sign-off',      detail:'Accepted 200-record drop. Flagged for manual review post-run. Signed: Ivan Sydorenko (Data Steward).', run:'fiscal_reform_q2_001' },
  { id:'AUD-010', ts:'2024-09-30T09:41:33Z', actor:'Kubernetes · Pod Monitor',    type:'system',   action:'OOM event detected',      detail:'Worker-5 OOM-killed. Memory 1.8GB > limit 1.5GB. ERR-2024-0091 raised.', run:'fiscal_reform_q2_001' },
  { id:'AUD-011', ts:'2024-09-30T09:41:38Z', actor:'SRE On-call · Andriy Bondar', type:'human',    action:'Config change applied',   detail:'Worker memory limit raised: 1.5GB → 2.5GB. Batch size reduced: 500 → 200. Approved by Andriy Bondar.', run:'fiscal_reform_q2_001' },
  { id:'AUD-012', ts:'2024-09-30T09:41:48Z', actor:'Policy Engine · Scheduler',   type:'system',   action:'Circuit breaker released', detail:'Worker-5 recovered. Retry queue drained (142 items). ERR-2024-0090 resolved.', run:'fiscal_reform_q2_001' },
  { id:'AUD-013', ts:'2024-09-30T09:42:22Z', actor:'Policy Engine · Ingestion',   type:'system',   action:'Embargo access denied',   detail:'Shard C pre-fetch blocked: EMB-001 active. ERR-2024-0089 raised. Escalated to Data Governance.', run:'fiscal_reform_q2_001' },
  { id:'AUD-014', ts:'2024-09-30T09:42:28Z', actor:'Olena Kovalenko',             type:'human',    action:'Escalation acknowledged', detail:'EMB-001 embargo will not be lifted. Shard C queued pending 2024-10-15 lift. Dependency planner patch scheduled.', run:'fiscal_reform_q2_001' },
  { id:'AUD-015', ts:'2024-09-30T14:22:00Z', actor:'Policy Engine · Runtime',     type:'system',   action:'Run complete (partial)',   detail:'W4 P4-1 done. P4-2 in progress. P4-3 queued (embargo). W5 blocked.', run:'fiscal_reform_q2_001' },
  { id:'AUD-016', ts:'2024-10-01T08:05:00Z', actor:'Mykola Shevchenko',           type:'human',    action:'Caseworker sign-off',     detail:'Decision D-Q3-001 reviewed and countersigned. Applicant C-2024-18440. Amount ₴18,400 approved.', run:'fiscal_reform_q2_001' },
  { id:'AUD-017', ts:'2024-10-01T08:06:14Z', actor:'Policy Engine · Dispatch',    type:'system',   action:'Decision dispatched',     detail:'D-Q3-001 dispatched to citizen portal. Provenance cert leaf signed: a8f3c2e1…', run:'fiscal_reform_q2_001' },
];

const ACTOR_TYPE = {
  system: { color:'var(--chart-secondary)', bg:'rgba(var(--blue-rgb), 0.10)', icon:'⚙', label:'System' },
  human:  { color:'var(--teal)', bg:'rgba(var(--teal-rgb), 0.10)',  icon:'○', label:'Human'  },
};

const ACTION_PALETTE = {
  'Run initiated':           'var(--teal)',
  'OOM event detected':      'var(--ember)',
  'Config change applied':   'var(--gold-vibrant)',
  'Embargo access denied':   'var(--ember)',
  'Manual QA sign-off':      'var(--teal)',
  'Escalation acknowledged': 'var(--gold-vibrant)',
  'Caseworker sign-off':     'var(--teal)',
};

function OpsAuditTrailScreen() {
  const [search,   setSearch]   = React.useState('');
  const [typeFilter, setTF]     = React.useState('all');
  const [selId,    setSelId]    = React.useState(null);

  const visible = AUDIT_EVENTS.filter(e => {
    const matchType = typeFilter === 'all' || e.type === typeFilter;
    const matchSearch = !search || e.action.toLowerCase().includes(search.toLowerCase())
      || e.actor.toLowerCase().includes(search.toLowerCase())
      || e.detail.toLowerCase().includes(search.toLowerCase());
    return matchType && matchSearch;
  });

  const sel = selId ? AUDIT_EVENTS.find(e => e.id === selId) : null;

  return (
    <div style={{ display:'flex', gap:20, height:'100%' }}>

      {/* Log list */}
      <div style={{ flex:1, minWidth:0, display:'flex', flexDirection:'column', gap:12 }}>

        {/* Header + filters */}
        <div style={{ display:'flex', alignItems:'center', gap:10, flexWrap:'wrap' }}>
          <Eyebrow>D5 · Ops Audit Trail</Eyebrow>
          <div style={{ flex:1 }} />
          <input
            value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Search events…"
            style={{ padding:'6px 12px', borderRadius:999, border:'1px solid rgba(var(--ink-rgb), 0.1)',
              fontFamily:'Manrope,sans-serif', fontSize:12, background:'rgba(var(--white-rgb), 0.7)',
              color:'var(--ink)', outline:'none', width:200 }}
          />
          {['all','system','human'].map(f => (
            <button type="button" key={f} onClick={() => setTF(f)}
              style={{ padding:'4px 10px', borderRadius:999, border:'none', cursor:'pointer',
                fontFamily:'"IBM Plex Mono",monospace', fontSize:9, fontWeight:700,
                background: typeFilter===f ? 'rgba(var(--ink-rgb), 0.1)':'rgba(var(--white-rgb), 0.65)',
                color: typeFilter===f ? 'var(--ink)':'rgba(var(--slate-rgb), 0.65)',
                boxShadow: typeFilter===f ? '0 0 0 1px rgba(var(--ink-rgb), 0.18)':'0 0 0 1px rgba(var(--ink-rgb), 0.08)' }}>
              {f.toUpperCase()}
            </button>
          ))}
        </div>

        {/* Log entries */}
        <Panel style={{ flex:1, padding:'14px 0', overflow:'auto' }}>
          {/* Column header */}
          <div style={{ display:'grid', gridTemplateColumns:'130px 80px 180px 1fr', gap:12, padding:'0 18px 8px',
            borderBottom:'1px solid rgba(var(--ink-rgb), 0.08)', marginBottom:6 }}>
            {['Timestamp','Type','Actor','Action & Detail'].map(h => (
              <span key={h} style={{ fontSize:8, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.45)', letterSpacing:'0.1em' }}>{h.toUpperCase()}</span>
            ))}
          </div>

          {visible.map((ev, i) => {
            const at = ACTOR_TYPE[ev.type];
            const isSel = selId === ev.id;
            const acColor = ACTION_PALETTE[ev.action] || 'var(--slate)';

            return (
              <InteractiveCard key={ev.id}
                onClick={() => setSelId(s => s===ev.id ? null : ev.id)}
                selected={isSel}
                ariaLabel={`Toggle audit event ${ev.id}. ${ev.action}. Actor ${ev.actor}.`}
                style={{
                  display:'grid', gridTemplateColumns:'130px 80px 180px 1fr', gap:12,
                  padding:'8px 18px', cursor:'pointer', alignItems:'flex-start',
                  background: isSel ? 'rgba(var(--white-rgb), 0.55)' : 'transparent',
                  borderLeft: `3px solid ${isSel ? acColor : 'transparent'}`,
                  transition:'background 130ms',
                }}>
                {/* Timestamp */}
                <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, color:'rgba(var(--slate-rgb), 0.55)', whiteSpace:'nowrap' }}>
                  {ev.ts.slice(5,16).replace('T',' ')}
                </span>
                {/* Type */}
                <div style={{ display:'flex', alignItems:'center', gap:5 }}>
                  <span style={{ fontSize:11, color:at.color }}>{at.icon}</span>
                  <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, fontWeight:700, color:at.color }}>{at.label.toUpperCase()}</span>
                </div>
                {/* Actor */}
                <span style={{ fontSize:11, fontWeight:600, color:'var(--ink)', lineHeight:1.35 }}>{ev.actor}</span>
                {/* Action */}
                <div>
                  <div style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, fontWeight:700, color:acColor, marginBottom:2 }}>{ev.action}</div>
                  <div style={{ fontSize:11, color:'rgba(var(--slate-rgb), 0.75)', lineHeight:1.45 }}>{ev.detail}</div>
                </div>
              </InteractiveCard>
            );
          })}
        </Panel>
      </div>

      {/* Detail + stats */}
      <div style={{ width:252, flexShrink:0, display:'flex', flexDirection:'column', gap:12 }}>
        <Panel style={{ flex:1 }}>
          <PanelHeader eyebrow="Event detail" title={sel ? sel.action : 'Select event'} />

          {!sel ? (
            <div>
              <div style={{ marginBottom:14 }}>
                {Object.entries(ACTOR_TYPE).map(([key, cfg]) => {
                  const count = AUDIT_EVENTS.filter(e => e.type === key).length;
                  return (
                    <div key={key} style={{ display:'flex', alignItems:'center', gap:8, marginBottom:8 }}>
                      <span style={{ fontSize:13, color:cfg.color }}>{cfg.icon}</span>
                      <span style={{ fontSize:12, fontWeight:600, color:cfg.color }}>{cfg.label} events</span>
                      <span style={{ marginLeft:'auto', fontFamily:'"IBM Plex Mono",monospace', fontSize:11, color:'var(--slate)' }}>{count}</span>
                    </div>
                  );
                })}
              </div>
              <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', margin:'14px 0' }} />
              <Eyebrow style={{ marginBottom:8 }}>Notable events</Eyebrow>
              {AUDIT_EVENTS.filter(e => ACTION_PALETTE[e.action]).map(e => {
                const col = ACTION_PALETTE[e.action];
                return (
                  <InteractiveCard key={e.id} onClick={() => setSelId(e.id)}
                    ariaLabel={`Open audit event ${e.id}. ${e.action}.`}
                    style={{ padding:'7px 9px', borderRadius:10, marginBottom:5,
                    background:'rgba(var(--white-rgb), 0.55)', border:`1px solid rgba(var(--ink-rgb), 0.07)`, cursor:'pointer' }}>
                    <div style={{ fontSize:10, fontFamily:'"IBM Plex Mono",monospace', fontWeight:700, color:col, marginBottom:2 }}>{e.action}</div>
                    <div style={{ fontSize:10, color:'rgba(var(--slate-rgb), 0.6)' }}>{e.ts.slice(5,16).replace('T',' ')} · {e.actor.split(' · ')[0]}</div>
                  </InteractiveCard>
                );
              })}
            </div>
          ) : (
            <div>
              <div style={{ marginBottom:12 }}>
                <Badge kind={sel.type === 'human' ? 'ok':'info'}>{sel.type}</Badge>
              </div>
              {[
                { label:'Event ID', val:sel.id },
                { label:'Timestamp', val:sel.ts.replace('T',' ').slice(0,19)+' UTC' },
                { label:'Actor', val:sel.actor },
                { label:'Run', val:sel.run },
              ].map(r => (
                <div key={r.label} style={{ marginBottom:10 }}>
                  <div style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.55)', marginBottom:2 }}>{r.label.toUpperCase()}</div>
                  <div style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, fontWeight:600, color:'var(--ink)', lineHeight:1.4 }}>{r.val}</div>
                </div>
              ))}
              <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', margin:'12px 0' }} />
              <Eyebrow style={{ marginBottom:6 }}>Detail</Eyebrow>
              <p style={{ margin:0, fontSize:12, color:'var(--slate)', lineHeight:1.6 }}>{sel.detail}</p>
              <button type="button" onClick={() => setSelId(null)} style={{ marginTop:14, fontSize:11, color:'rgba(var(--slate-rgb), 0.7)', background:'none', border:'none', cursor:'pointer', padding:0 }}>
                ← All events
              </button>
            </div>
          )}
        </Panel>

        {/* Run stats */}
        <Panel>
          <Eyebrow style={{ marginBottom:8 }}>Run · fiscal_reform_q2_001</Eyebrow>
          {[
            { label:'Total events',  val:AUDIT_EVENTS.length },
            { label:'Human actions', val:AUDIT_EVENTS.filter(e=>e.type==='human').length },
            { label:'System events', val:AUDIT_EVENTS.filter(e=>e.type==='system').length },
            { label:'Errors raised', val:3, color:'var(--ember)' },
          ].map(r => (
            <div key={r.label} style={{ display:'flex', justifyContent:'space-between', marginBottom:7 }}>
              <span style={{ fontSize:12, color:'var(--slate)' }}>{r.label}</span>
              <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:12, fontWeight:700, color:r.color||'var(--ink)' }}>{r.val}</span>
            </div>
          ))}
        </Panel>
      </div>
    </div>
  );
}

Object.assign(window, { OpsAuditTrailScreen });
