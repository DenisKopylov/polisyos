// ProfileDriftNarrative.jsx — B5
// Drift as text narrative with embedded micro-vizzes and citation-grade hover
// Exports: ProfileDriftNarrativeScreen

const DRIFT_EVENTS = [
  {
    id:'latency', field:'p99_latency',
    before:41, after:78, unit:'ms', delta:'+90.2%',
    test:'KS-test: p < 0.001', severity:'high',
    sparkline:[38,40,41,42,41,43,58,71,78],
    desc:'Query latency has nearly doubled. Likely cause: index fragmentation on municipality_id following schema v1.2 rename.',
    rawStats:{ n:42180, ks_stat:0.218, ks_p:0.00034, shapiro_p:0.0012 },
  },
  {
    id:'region_levels', field:'region',
    before:142, after:138, unit:'levels', delta:'−4',
    test:'χ² test: p = 0.003', severity:'medium',
    distribution:{ lost:['municipality_2021_Q4','municipality_2021_Q5','municipality_2021_Q6','municipality_2021_Q7'], gained:[] },
    desc:'Four municipality codes absent since the NUTS-3 boundary revision. Downstream models using region as a feature will encounter unseen categories.',
    rawStats:{ n:42180, chi2_stat:14.2, chi2_p:0.0028, n_lost:4 },
  },
  {
    id:'income', field:'mean_income',
    before:42340, after:38710, unit:'UAH', delta:'−8.6%',
    test:'Welch t-test: p < 0.001', severity:'medium',
    sparkline:[42100,42300,42340,42200,41800,40500,39200,38710],
    desc:'Mean income drop reflects revised eligibility window (Q3 2023 → Q3 2024). Cohort selection criterion changed upstream. Likely intended; confirm with policy team.',
    rawStats:{ n:42180, t_stat:-12.4, t_p:0.00001, effect_d:0.31 },
  },
  {
    id:'completeness', field:'employment_status',
    before:98.2, after:94.7, unit:'%', delta:'−3.5pp',
    test:'Fisher exact: p < 0.001', severity:'high',
    sparkline:[98.1,98.2,98.0,97.8,97.2,96.1,95.3,94.7],
    desc:'Employment status completeness fell 3.5pp. Missing values correlate with records from the Kyiv region (r = 0.41). Possible upstream ETL regression.',
    rawStats:{ n_missing:1476, n_total:42180, region_corr:0.41, fisher_p:0.00002 },
  },
  {
    id:'skewness', field:'amount',
    before:0.82, after:2.14, unit:'', delta:'+1.32',
    test:'Jarque-Bera: p < 0.001', severity:'low',
    sparkline:[0.79,0.82,0.85,0.91,1.10,1.48,1.87,2.14],
    desc:'Distribution of disbursement amounts is markedly more right-skewed. A small cluster of large outliers (>500k UAH) appeared in the latest batch. Review for data entry errors.',
    rawStats:{ n_outliers:38, threshold:500000, jb_stat:88.4, jb_p:0.00001 },
  },
];

const SEV_CFG = {
  high:   { color:'var(--ember)', bg:'rgba(var(--ember-rgb), 0.10)', border:'rgba(var(--ember-rgb), 0.28)', badge:'fail'   },
  medium: { color:'var(--gold-vibrant)', bg:'rgba(var(--gold-vibrant-rgb), 0.10)', border:'rgba(var(--gold-vibrant-rgb), 0.28)', badge:'warn' },
  low:    { color:'var(--slate)', bg:'rgba(var(--slate-rgb), 0.08)',   border:'rgba(var(--slate-rgb), 0.22)',   badge:'neutral'},
};

function InlineSparkline({ values, color }) {
  if (!values || values.length < 2) return null;
  const min = Math.min(...values), max = Math.max(...values), range = max - min || 1;
  const w = 52, h = 18;
  const pts = values.map((v, i) => `${(i/(values.length-1)*w).toFixed(1)},${(h-(v-min)/range*(h-4)-2).toFixed(1)}`).join(' ');
  return (
    <svg width={w} height={h} style={{ display:'inline-block', verticalAlign:'middle', margin:'0 3px' }}>
      <polyline points={pts} fill="none" stroke={color} strokeWidth={1.5} strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  );
}

function InlineDist({ lost, color }) {
  const n = lost.length, total = 10;
  return (
    <span style={{ display:'inline-flex', alignItems:'center', gap:2, margin:'0 3px', verticalAlign:'middle' }}>
      {Array.from({length:total}).map((_, i) => (
        <span key={i} style={{ display:'inline-block', width:5, height:14, borderRadius:2,
          background: i < (total-n) ? color : 'var(--ember-vibrant)', opacity: i < (total-n) ? 0.7 : 0.9 }} />
      ))}
    </span>
  );
}

function StatHover({ children, stat, color }) {
  const [show, setShow] = React.useState(false);
  const ref = React.useRef(null);
  return (
    <span style={{ position:'relative', display:'inline-block' }}
      onMouseEnter={() => setShow(true)} onMouseLeave={() => setShow(false)} ref={ref}>
      <span style={{
        color, fontWeight:700, borderBottom:`1.5px dotted ${color}`,
        cursor:'help', padding:'0 1px',
      }}>
        {children}
      </span>
      {show && (
        <span style={{
          position:'absolute', bottom:'calc(100% + 6px)', left:'50%', transform:'translateX(-50%)',
          background:'rgba(var(--shell-dark-rgb), 0.96)', color:'var(--ink)', borderRadius:8,
          padding:'6px 10px', fontSize:10, fontFamily:'"IBM Plex Mono",monospace',
          whiteSpace:'nowrap', zIndex:100, lineHeight:1.7,
          boxShadow:'0 6px 18px rgba(var(--black-rgb), 0.25)',
          pointerEvents:'none',
        }}>
          {typeof stat === 'object'
            ? Object.entries(stat).map(([k,v]) => `${k}: ${v}`).join('\n').split('\n').map((line,i) => (
                <span key={i} style={{ display:'block' }}>{line}</span>
              ))
            : stat}
        </span>
      )}
    </span>
  );
}

function NarrativeBlock({ event, isSelected, onSelect }) {
  const cfg = SEV_CFG[event.severity];
  const isSel = isSelected;

  function renderNarrative() {
    const color = cfg.color;
    // Craft narrative differently per event type
    if (event.id === 'latency') return (
      <span>
        <strong style={{ color:'var(--ink)' }}>p99 latency</strong> increased from{' '}
        <StatHover stat={event.rawStats} color={color}>{event.before}ms</StatHover> to{' '}
        <StatHover stat={event.rawStats} color={color}>{event.after}ms</StatHover>
        {' '}<InlineSparkline values={event.sparkline} color={color} />{' '}
        (<strong style={{ color }}>{event.delta}</strong>). {event.test}.{' '}
        {event.desc}
      </span>
    );
    if (event.id === 'region_levels') return (
      <span>
        The <strong style={{ color:'var(--ink)' }}>region</strong> column lost{' '}
        <StatHover stat={event.rawStats} color={color}>4 categorical levels</StatHover>
        {' '}<InlineDist lost={event.distribution.lost} color={color} />{' '}
        ({event.distribution.lost.slice(0,2).join(', ')}…). {event.test}.{' '}
        {event.desc}
      </span>
    );
    if (event.id === 'income') return (
      <span>
        <strong style={{ color:'var(--ink)' }}>mean_income</strong> dropped from{' '}
        <StatHover stat={event.rawStats} color={color}>{event.before.toLocaleString()} UAH</StatHover> to{' '}
        <StatHover stat={event.rawStats} color={color}>{event.after.toLocaleString()} UAH</StatHover>
        {' '}<InlineSparkline values={event.sparkline} color={color} />{' '}
        (<strong style={{ color }}>{event.delta}</strong>). {event.test}.{' '}
        {event.desc}
      </span>
    );
    if (event.id === 'completeness') return (
      <span>
        <strong style={{ color:'var(--ink)' }}>employment_status</strong> completeness fell from{' '}
        <StatHover stat={event.rawStats} color={color}>{event.before}%</StatHover> to{' '}
        <StatHover stat={event.rawStats} color={color}>{event.after}%</StatHover>
        {' '}<InlineSparkline values={event.sparkline} color={color} />{' '}
        (<strong style={{ color }}>{event.delta}</strong>). {event.test}.{' '}
        {event.desc}
      </span>
    );
    if (event.id === 'skewness') return (
      <span>
        <strong style={{ color:'var(--ink)' }}>amount</strong> skewness rose from{' '}
        <StatHover stat={event.rawStats} color={color}>{event.before}</StatHover> to{' '}
        <StatHover stat={event.rawStats} color={color}>{event.after}</StatHover>
        {' '}<InlineSparkline values={event.sparkline} color={color} />{' '}
        (<strong style={{ color }}>{event.delta}</strong>). {event.test}.{' '}
        {event.desc}
      </span>
    );
    return null;
  }

  return (
    <InteractiveCard onClick={() => onSelect(isSel ? null : event.id)} selected={isSel}
      ariaLabel={`Toggle drift event ${event.field}. Severity ${event.severity}.`}
      style={{
        padding:'16px 18px', borderRadius:16, marginBottom:10, cursor:'pointer',
        background: isSel ? cfg.bg : 'rgba(var(--white-rgb), 0.58)',
        border: `1.5px solid ${isSel ? cfg.color : 'rgba(var(--ink-rgb), 0.08)'}`,
        borderLeft: `4px solid ${cfg.color}`,
        transition:'all 160ms',
      }}>
      <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:8 }}>
        <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, fontWeight:700,
          letterSpacing:'0.1em', color:cfg.color }}>{event.field.toUpperCase()}</span>
        <Badge kind={cfg.badge}>{event.severity}</Badge>
        <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:'rgba(var(--slate-rgb), 0.55)', marginLeft:'auto' }}>
          {event.test.split(':')[0]}
        </span>
      </div>
      <p style={{ margin:0, fontSize:13.5, lineHeight:1.75, color:'var(--ink)', fontFamily:'"Manrope",sans-serif' }}>
        {renderNarrative()}
      </p>
    </InteractiveCard>
  );
}

function ProfileDriftNarrativeScreen() {
  const [selected, setSelected]   = React.useState(null);
  const [threshold, setThreshold] = React.useState('medium');

  const THRESH_ORDER = { high:0, medium:1, low:2 };
  const visible = DRIFT_EVENTS.filter(e => THRESH_ORDER[e.severity] <= THRESH_ORDER[threshold]);

  return (
    <div style={{ display:'flex', gap:20, height:'100%' }}>

      <div style={{ flex:1, minWidth:0, display:'flex', flexDirection:'column', gap:14 }}>

        {/* Header */}
        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          <Eyebrow>B5 · Profile Drift Narrative</Eyebrow>
          <div style={{ flex:1 }} />
          <span style={{ fontSize:11, color:'rgba(var(--slate-rgb), 0.6)', fontFamily:'"IBM Plex Mono",monospace' }}>SHOW SEVERITY</span>
          {['high','medium','low'].map(s => {
            const cfg = SEV_CFG[s];
            const active = THRESH_ORDER[threshold] >= THRESH_ORDER[s];
            return (
              <button type="button" key={s} onClick={() => setThreshold(s)}
                style={{ padding:'4px 10px', borderRadius:999, border:'none', cursor:'pointer',
                  fontFamily:'"IBM Plex Mono",monospace', fontSize:9, fontWeight:700, letterSpacing:'0.08em',
                  background: active ? cfg.bg : 'rgba(var(--white-rgb), 0.6)',
                  color: active ? cfg.color : 'rgba(var(--slate-rgb), 0.5)',
                  boxShadow: active ? `0 0 0 1px ${cfg.border}` : '0 0 0 1px rgba(var(--ink-rgb), 0.09)' }}>
                {s.toUpperCase()}
              </button>
            );
          })}
        </div>

        {/* Narrative header */}
        <Panel style={{ padding:'14px 18px' }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
            <div>
              <h3 style={{ margin:0, fontSize:18, fontWeight:800, letterSpacing:'-0.03em' }}>
                fiscal_reform_dataset
              </h3>
              <p style={{ margin:'4px 0 0', fontSize:12, color:'var(--slate)' }}>
                Profile shift detected · compared to snapshot{' '}
                <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontWeight:700, color:'var(--teal)' }}>2024-09-01T00:00:00Z</span>
              </p>
            </div>
            <div style={{ display:'flex', gap:8 }}>
              {['high','medium','low'].map(s => {
                const n = DRIFT_EVENTS.filter(e => e.severity===s).length;
                const cfg = SEV_CFG[s];
                return (
                  <div key={s} style={{ textAlign:'center', padding:'6px 10px', borderRadius:10, background:cfg.bg, border:`1px solid ${cfg.border}` }}>
                    <div style={{ fontSize:18, fontWeight:800, color:cfg.color }}>{n}</div>
                    <div style={{ fontSize:8, fontFamily:'"IBM Plex Mono",monospace', color:cfg.color, letterSpacing:'0.08em' }}>{s.toUpperCase()}</div>
                  </div>
                );
              })}
            </div>
          </div>
        </Panel>

        {/* Narrative blocks */}
        <div style={{ flex:1, overflowY:'auto' }}>
          <p style={{ fontSize:11, color:'rgba(var(--slate-rgb), 0.6)', fontFamily:'"IBM Plex Mono",monospace', letterSpacing:'0.04em', margin:'0 0 10px' }}>
            HOVER OVER NUMBERS FOR RAW STATISTICS · CLICK TO FOCUS
          </p>
          {visible.map(event => (
            <NarrativeBlock
              key={event.id}
              event={event}
              isSelected={selected === event.id}
              onSelect={setSelected}
            />
          ))}
        </div>
      </div>

      {/* Side panel */}
      <div style={{ width:248, flexShrink:0 }}>
        <Panel style={{ height:'100%' }}>
          <PanelHeader eyebrow="Drift summary" title="All columns" />
          {DRIFT_EVENTS.map(e => {
            const cfg = SEV_CFG[e.severity];
            const isSel = selected === e.id;
            return (
              <InteractiveCard key={e.id} onClick={() => setSelected(s => s===e.id?null:e.id)} selected={isSel}
                ariaLabel={`Toggle drift summary ${e.field}. Severity ${e.severity}.`}
                style={{ padding:'9px 11px', borderRadius:12, marginBottom:7, cursor:'pointer',
                  background: isSel ? cfg.bg : 'rgba(var(--white-rgb), 0.52)',
                  border:`1.5px solid ${isSel ? cfg.color : 'rgba(var(--ink-rgb), 0.07)'}`,
                  transition:'all 140ms' }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:3 }}>
                  <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, fontWeight:700, color:cfg.color }}>{e.field}</span>
                  <Badge kind={cfg.badge}>{e.severity}</Badge>
                </div>
                <div style={{ fontSize:11, color:'var(--ink)', fontWeight:600 }}>Δ {e.delta}</div>
                <div style={{ fontSize:10, color:'rgba(var(--slate-rgb), 0.6)', marginTop:2 }}>{e.test}</div>
              </InteractiveCard>
            );
          })}

          <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', margin:'14px 0' }} />
          <Eyebrow style={{ marginBottom:8 }}>Detection method</Eyebrow>
          <p style={{ fontSize:11, color:'var(--slate)', lineHeight:1.6, margin:0 }}>
            KS-test for distributional shifts · Welch t-test for means · Fisher exact for completeness · Jarque-Bera for normality. All p-values Bonferroni-corrected.
          </p>
        </Panel>
      </div>
    </div>
  );
}

Object.assign(window, { ProfileDriftNarrativeScreen });
