// ProvenanceCertificate.jsx — C5
// Cryptographic attestation chain: SHA-256 hash tree, signatories, validation state
// Exports: ProvenanceCertificateScreen

const CERT_CHAIN = [
  {
    id:'cert-raw-fiscal',
    level:0,
    label:'Raw Source Attestation',
    entity:'Fiscal DB',
    hash:'sha256:4f3ca8d1e2b7f091c6a5d38e9f2b4c17',
    signedBy:'Data Steward · Olena Kovalenko',
    signedAt:'2024-09-01T02:14:00Z',
    algorithm:'SHA-256 / RSA-4096',
    status:'valid',
    fields:{ 'Source':'fiscal_db@v3.4', 'Record count':'42,180', 'Schema version':'v2.1', 'Batch date':'2024-09-01' },
  },
  {
    id:'cert-raw-employ',
    level:0,
    label:'Raw Source Attestation',
    entity:'Employment Registry',
    hash:'sha256:9c2e7b4f1a8d630e5f1c9a2b7e3d8f40',
    signedBy:'Data Steward · Ivan Sydorenko',
    signedAt:'2024-09-01T03:08:00Z',
    algorithm:'SHA-256 / RSA-4096',
    status:'valid',
    fields:{ 'Source':'employ_registry@daily', 'Record count':'42,042', 'Lag':'36h', 'Completeness':'94.7%' },
  },
  {
    id:'cert-dataset',
    level:1,
    label:'Derived Dataset Certificate',
    entity:'Economic Dataset v3.4',
    hash:'sha256:b1d5f8c3a2e94f07b6c1e8a3d2f57c90',
    signedBy:'Data Engineering · Automation (verified by Olena Kovalenko)',
    signedAt:'2024-09-01T06:30:00Z',
    algorithm:'SHA-256 / Merkle root of [cert-raw-fiscal, cert-raw-employ]',
    status:'valid',
    fields:{ 'Parent hashes':'4f3ca8d1…, 9c2e7b4f…', 'Join key':'citizen_id', 'Rows retained':'41,980 (missing 200)' },
  },
  {
    id:'cert-model',
    level:2,
    label:'Model Card Certificate',
    entity:'Fiscal Reform Model v3.4',
    hash:'sha256:e7a1c4b8f23d90e5a1b8c4d7f2e3a901',
    signedBy:'ML Engineering · Automated CI (signed by Andriy Bondar)',
    signedAt:'2024-09-01T10:44:00Z',
    algorithm:'SHA-256 / model weights + dataset cert hash',
    status:'valid',
    fields:{ 'Training dataset cert':'b1d5f8c3…', 'Model version':'v3.4.1', 'Validation AUC':'0.841', 'Framework':'XGBoost 2.0.3' },
  },
  {
    id:'cert-run',
    level:3,
    label:'Run Provenance Certificate',
    entity:'Run fiscal_reform_q2_001',
    hash:'sha256:3c9f2d7e1b4a80c5f7d2e9a1b3c8f420',
    signedBy:'Policy Engine · Runtime (countersigned by Chief Data Officer)',
    signedAt:'2024-09-30T14:22:00Z',
    algorithm:'SHA-256 / model cert + input snapshot + config hash',
    status:'valid',
    fields:{ 'Model cert':'e7a1c4b8…', 'Input snapshot hash':'d8f1c3…', 'Config version':'run_config_v2.1', 'Decision count':'20,337 approved / 21,843 rejected' },
  },
  {
    id:'cert-decision',
    level:4,
    label:'Decision Leaf Certificate',
    entity:'Decision D-Q3-001',
    hash:'sha256:a8f3c2e1d7b4f09c5e2a8d3f1c7b4e82',
    signedBy:'Policy Engine · Runtime + Caseworker signoff (Mykola Shevchenko)',
    signedAt:'2024-10-01T08:05:00Z',
    algorithm:'SHA-256 / run cert + applicant_id + decision params',
    status:'valid',
    fields:{ 'Run cert':'3c9f2d7e…', 'Applicant ID':'C-2024-18440 (hashed)', 'Outcome':'APPROVED', 'Amount':'₴18,400', 'Caseworker':'M.Shevchenko' },
  },
];

const LEVEL_LABELS = ['Source','Dataset','Model','Run','Decision'];
const LEVEL_COLORS = ['var(--chart-secondary)','var(--teal)','var(--gold)','var(--slate)','var(--teal)'];
function levelSurface(color, alpha) {
  if (color === 'var(--chart-secondary)') return `rgba(var(--blue-rgb), ${alpha})`;
  if (color === 'var(--gold)') return `rgba(var(--gold-rgb), ${alpha})`;
  if (color === 'var(--slate)') return `rgba(var(--slate-rgb), ${alpha})`;
  return `rgba(var(--teal-rgb), ${alpha})`;
}

const STATUS_CFG = {
  valid:   { color:'var(--teal)', bg:'rgba(var(--teal-rgb), 0.11)', border:'rgba(var(--teal-rgb), 0.28)', badge:'ok',      label:'Valid'    },
  invalid: { color:'var(--ember)', bg:'rgba(var(--ember-rgb), 0.11)', border:'rgba(var(--ember-rgb), 0.28)', badge:'fail',  label:'Invalid'  },
  pending: { color:'var(--gold-vibrant)', bg:'rgba(var(--gold-vibrant-rgb), 0.11)', border:'rgba(var(--gold-vibrant-rgb), 0.28)', badge:'warn',label:'Pending'  },
};

function HashChip({ hash, color }) {
  const [copied, setCopied] = React.useState(false);
  function copy() {
    navigator.clipboard?.writeText(hash).catch(()=>{});
    setCopied(true);
    setTimeout(() => setCopied(false), 1200);
  }
  return (
    <div style={{ display:'flex', alignItems:'center', gap:8 }}>
      <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, color, letterSpacing:'0.02em' }}>
        {hash.slice(0,24)}…
      </span>
      <button type="button" onClick={copy}
        style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, padding:'2px 7px', borderRadius:6,
          background:'rgba(var(--white-rgb), 0.65)', border:'1px solid rgba(var(--ink-rgb), 0.1)',
          color: copied ? 'var(--teal)':'rgba(var(--slate-rgb), 0.7)', cursor:'pointer', fontWeight:700 }}>
        {copied ? '✓ Copied':'Copy'}
      </button>
    </div>
  );
}

function ProvenanceCertificateScreen() {
  const [selId, setSelId] = React.useState('cert-decision');

  const sel    = CERT_CHAIN.find(c => c.id === selId);
  const scfg   = sel ? STATUS_CFG[sel.status] : null;
  const lColor = sel ? LEVEL_COLORS[sel.level] : 'var(--slate)';

  // Group by level for tree display
  const byLevel = React.useMemo(() => {
    const out = {};
    CERT_CHAIN.forEach(c => { if (!out[c.level]) out[c.level] = []; out[c.level].push(c); });
    return out;
  }, []);

  return (
    <div style={{ display:'flex', gap:20, height:'100%' }}>

      {/* Attestation tree */}
      <div style={{ width:260, flexShrink:0, display:'flex', flexDirection:'column', gap:6 }}>
        <Eyebrow style={{ marginBottom:4 }}>C5 · Provenance Certificate</Eyebrow>

        {Object.entries(byLevel).map(([level, certs]) => (
          <div key={level}>
            <div style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.4)',
              letterSpacing:'0.1em', marginBottom:5, marginTop: +level > 0 ? 8 : 0 }}>
              L{level} · {LEVEL_LABELS[+level].toUpperCase()}
            </div>
            {+level > 0 && (
              <div style={{ width:1.5, height:10, background:'rgba(var(--slate-rgb), 0.2)', marginLeft:16, marginBottom:4 }} />
            )}
            {certs.map(cert => {
              const isSel = selId === cert.id;
              const col = LEVEL_COLORS[cert.level];
              return (
                <InteractiveCard key={cert.id} onClick={() => setSelId(cert.id)} selected={isSel}
                  ariaLabel={`Open provenance certificate ${cert.entity}. Level ${cert.level}.`}
                  style={{ padding:'9px 12px', borderRadius:13, cursor:'pointer', marginBottom:4,
                    background: isSel ? levelSurface(col, '0.10') : 'rgba(var(--white-rgb), 0.56)',
                    border:`1.5px solid ${isSel ? col : 'rgba(var(--ink-rgb), 0.08)'}`,
                    transition:'all 140ms' }}>
                  <div style={{ display:'flex', justifyContent:'space-between', marginBottom:3 }}>
                    <span style={{ fontSize:10, fontFamily:'"IBM Plex Mono",monospace', fontWeight:700, color:col }}>{cert.entity}</span>
                    <Badge kind="ok">✓</Badge>
                  </div>
                  <div style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:'rgba(var(--slate-rgb), 0.55)', letterSpacing:'0.02em' }}>
                    {cert.hash.slice(7, 19)}…
                  </div>
                </InteractiveCard>
              );
            })}
          </div>
        ))}

        {/* Chain validity */}
        <div style={{ marginTop:12, padding:'10px 13px', borderRadius:13,
          background:'rgba(var(--teal-rgb), 0.10)', border:'1px solid rgba(var(--teal-rgb), 0.25)' }}>
          <div style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--teal-rgb), 0.8)', marginBottom:4, letterSpacing:'0.1em' }}>CHAIN INTEGRITY</div>
          <div style={{ fontSize:14, fontWeight:800, color:'var(--teal)' }}>✓ All {CERT_CHAIN.length} certs valid</div>
          <div style={{ fontSize:10, color:'rgba(var(--teal-rgb), 0.7)', marginTop:2 }}>Merkle root verified</div>
        </div>
      </div>

      {/* Cert detail */}
      {sel && (
        <div style={{ flex:1, display:'flex', flexDirection:'column', gap:12 }}>

          <Panel style={{ padding:'16px 20px', background: scfg.bg }}>
            <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', gap:12 }}>
              <div>
                <div style={{ display:'flex', gap:8, alignItems:'center', marginBottom:6 }}>
                  <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, fontWeight:700,
                    color:lColor, letterSpacing:'0.1em' }}>L{sel.level} · {LEVEL_LABELS[sel.level].toUpperCase()}</span>
                  <Badge kind={scfg.badge}>{scfg.label}</Badge>
                </div>
                <h3 style={{ margin:0, fontSize:20, fontWeight:800, letterSpacing:'-0.03em', marginBottom:4 }}>{sel.entity}</h3>
                <p style={{ margin:0, fontSize:12, color:'rgba(var(--slate-rgb), 0.7)', fontStyle:'italic' }}>{sel.label}</p>
              </div>
              <div style={{ flexShrink:0, fontFamily:'"IBM Plex Mono",monospace', fontSize:10, color:'rgba(var(--slate-rgb), 0.55)', textAlign:'right' }}>
                {sel.signedAt.slice(0,16).replace('T',' ')} UTC
              </div>
            </div>
          </Panel>

          {/* Hash */}
          <Panel>
            <Eyebrow style={{ marginBottom:8 }}>Certificate hash</Eyebrow>
            <HashChip hash={sel.hash} color={lColor} />
            <div style={{ marginTop:8, fontFamily:'"IBM Plex Mono",monospace', fontSize:10, color:'rgba(var(--slate-rgb), 0.6)' }}>
              Algorithm: {sel.algorithm}
            </div>
          </Panel>

          {/* Signatory */}
          <Panel>
            <Eyebrow style={{ marginBottom:8 }}>Signatory</Eyebrow>
            <p style={{ margin:0, fontSize:13, fontWeight:600, color:'var(--ink)', lineHeight:1.55 }}>{sel.signedBy}</p>
          </Panel>

          {/* Fields */}
          <Panel style={{ flex:1 }}>
            <Eyebrow style={{ marginBottom:12 }}>Attested fields</Eyebrow>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8 }}>
              {Object.entries(sel.fields).map(([k, v]) => (
                <div key={k} style={{ padding:'9px 12px', borderRadius:12,
                  background:'rgba(var(--white-rgb), 0.54)', border:'1px solid rgba(var(--ink-rgb), 0.07)' }}>
                  <div style={{ fontSize:8, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.55)', letterSpacing:'0.1em', marginBottom:3 }}>{k.toUpperCase()}</div>
                  <div style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, fontWeight:700, color:lColor, lineHeight:1.4 }}>{v}</div>
                </div>
              ))}
            </div>

            {/* Hash chain visualisation */}
            <div style={{ marginTop:16 }}>
              <Eyebrow style={{ marginBottom:10 }}>Hash chain ancestry</Eyebrow>
              <div style={{ display:'flex', alignItems:'center', gap:6, flexWrap:'wrap' }}>
                {CERT_CHAIN.filter(c => c.level <= sel.level).map((c, i) => {
                  const col = LEVEL_COLORS[c.level];
                  const isCur = c.id === sel.id;
                  return (
                    <React.Fragment key={c.id}>
                      <button
                        type="button"
                        aria-pressed={isCur ? 'true' : 'false'}
                        aria-label={`Open ancestry certificate ${c.hash.slice(7,15)}`}
                        onClick={() => setSelId(c.id)}
                        style={{ padding:'4px 9px', borderRadius:8, cursor:'pointer',
                          background: isCur ? levelSurface(col, '0.15') : 'rgba(var(--white-rgb), 0.55)',
                          border:`1.5px solid ${isCur ? col:'rgba(var(--ink-rgb), 0.1)'}`,
                          fontFamily:'"IBM Plex Mono",monospace', fontSize:9, fontWeight:700, color:col }}>
                        {c.hash.slice(7,15)}…
                      </button>
                      {i < CERT_CHAIN.filter(c2=>c2.level<=sel.level).length-1 && (
                        <span style={{ color:'rgba(var(--slate-rgb), 0.35)', fontSize:12 }}>→</span>
                      )}
                    </React.Fragment>
                  );
                })}
              </div>
            </div>
          </Panel>
        </div>
      )}
    </div>
  );
}

Object.assign(window, { ProvenanceCertificateScreen });
