// QualityBudget.jsx — B4
// SRE-style error budget dashboard: completeness/consistency/accuracy/timeliness
// Exports: QualityBudgetScreen

const QB_DIMENSIONS = [
  {
    id:'completeness', label:'Completeness', icon:'◈',
    budget:1.0, spent:0.68, burnRate:0.21, unit:'%',
    q3baseline:0.41, q2baseline:0.28,
    spentBy:[
      { source:'Tax Records SFTP',  pct:0.38, date:'2024-09-14' },
      { source:'Employment Registry',pct:0.18, date:'2024-09-22' },
      { source:'Fiscal DB (replica)',pct:0.12, date:'2024-09-28' },
    ],
    sparkline:[0.12,0.14,0.18,0.22,0.28,0.38,0.52,0.68],
    color:'var(--teal)', status:'ok',
    forecastWeeks:1.5,
  },
  {
    id:'consistency', label:'Consistency', icon:'◎',
    budget:2.0, spent:0.31, burnRate:0.08, unit:'%',
    q3baseline:0.22, q2baseline:0.19,
    spentBy:[
      { source:'Schema migration v1.2', pct:0.18, date:'2024-08-11' },
      { source:'GDP Tracker drift',      pct:0.13, date:'2024-09-05' },
    ],
    sparkline:[0.08,0.10,0.13,0.18,0.22,0.25,0.28,0.31],
    color:'var(--teal)', status:'ok',
    forecastWeeks:21,
  },
  {
    id:'accuracy', label:'Accuracy', icon:'◆',
    budget:0.5, spent:0.44, burnRate:0.19, unit:'%',
    q3baseline:0.21, q2baseline:0.14,
    spentBy:[
      { source:'amount FLOAT→DECIMAL migration', pct:0.21, date:'2024-09-01' },
      { source:'income_quartile imputation',      pct:0.15, date:'2024-09-18' },
      { source:'Rounding accumulation',           pct:0.08, date:'2024-09-25' },
    ],
    sparkline:[0.10,0.14,0.18,0.24,0.30,0.36,0.40,0.44],
    color:'var(--ember)', status:'critical',
    forecastWeeks:0.3,
  },
  {
    id:'timeliness', label:'Timeliness', icon:'◷',
    budget:5.0, spent:2.80, burnRate:0.62, unit:'%',
    q3baseline:1.40, q2baseline:0.95,
    spentBy:[
      { source:'Tax Records SLA breach (3d)', pct:1.80, date:'2024-09-14' },
      { source:'Employment Registry overnight delay', pct:0.80, date:'2024-09-20' },
      { source:'GDP Tracker retry storm',     pct:0.20, date:'2024-09-27' },
    ],
    sparkline:[0.60,0.82,1.10,1.40,1.80,2.20,2.55,2.80],
    color:'var(--gold-vibrant)', status:'warn',
    forecastWeeks:3.6,
  },
];

const QB_STATUS = {
  ok:       { label:'On track',   color:'var(--teal)', bg:'rgba(var(--teal-rgb), 0.1)',   border:'rgba(var(--teal-rgb), 0.25)',  badge:'ok'     },
  warn:     { label:'At risk',    color:'var(--gold-vibrant)', bg:'rgba(var(--gold-vibrant-rgb), 0.1)', border:'rgba(var(--gold-vibrant-rgb), 0.28)', badge:'warn' },
  critical: { label:'Critical',   color:'var(--ember)', bg:'rgba(var(--ember-rgb), 0.1)', border:'rgba(var(--ember-rgb), 0.25)', badge:'fail'   },
};

const WEEKS = ['W-7','W-6','W-5','W-4','W-3','W-2','W-1','Now'];

function BurnSparkline({ values, budget, color, w=180, h=52 }) {
  if (!values || values.length < 2) return null;
  const maxVal = budget;
  const pts = values.map((v, i) => ({
    x: (i / (values.length - 1)) * w,
    y: h - (v / maxVal) * (h - 8) - 4,
  }));
  const poly = pts.map(p => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ');
  // Area fill
  const areaD = `M ${pts[0].x} ${h} L ${pts.map(p=>`${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' L ')} L ${pts[pts.length-1].x} ${h} Z`;
  // Budget limit line
  const limitY = h - (1.0) * (h - 8) - 4; // at 100% = budget exhausted
  return (
    <svg width={w} height={h} style={{ display:'block', overflow:'visible' }}>
      {/* Budget limit */}
      <line x1={0} y1={4} x2={w} y2={4} stroke="rgba(var(--ember-rgb), 0.35)" strokeWidth={1} strokeDasharray="4 3" />
      {/* Area */}
      <path d={areaD} fill={color} opacity={0.1} />
      {/* Line */}
      <polyline points={poly} fill="none" stroke={color} strokeWidth={1.8}
        strokeLinejoin="round" strokeLinecap="round" />
      {/* Current dot */}
      <circle cx={pts[pts.length-1].x} cy={pts[pts.length-1].y} r={3} fill={color} />
    </svg>
  );
}

function GaugeDial({ pct, color, size=80 }) {
  const r = size/2 - 8, cx = size/2, cy = size/2 + 4;
  function pt(deg) {
    const rad = (180 - deg) * Math.PI / 180;
    return { x: cx + r * Math.cos(rad), y: cy - r * Math.sin(rad) };
  }
  const angle = Math.min(pct, 100) * 1.8; // 0-100% → 0-180°
  const s = pt(0), e = pt(angle);
  const large = angle > 90 ? 1 : 0;
  const critColor = pct >= 90 ? 'var(--ember-vibrant)' : pct >= 70 ? 'var(--gold-vibrant)' : color;
  return (
    <svg width={size} height={size/2 + 10} style={{ display:'block', overflow:'visible' }}>
      <path d={`M ${pt(0).x} ${pt(0).y} A ${r} ${r} 0 1 1 ${pt(180).x} ${pt(180).y}`}
        fill="none" stroke="rgba(var(--ink-rgb), 0.08)" strokeWidth={7} strokeLinecap="round" />
      {pct > 0 && (
        <path d={`M ${s.x} ${s.y} A ${r} ${r} 0 ${large} 1 ${e.x} ${e.y}`}
          fill="none" stroke={critColor} strokeWidth={7} strokeLinecap="round" />
      )}
    </svg>
  );
}

function QualityBudgetScreen() {
  const [selected, setSelected] = React.useState(null);
  const [quarter,  setQuarter]  = React.useState('Q3');

  const selDim = selected ? QB_DIMENSIONS.find(d => d.id === selected) : null;

  return (
    <div style={{ display:'flex', gap:20, height:'100%' }}>

      {/* Main grid */}
      <div style={{ flex:1, minWidth:0, display:'flex', flexDirection:'column', gap:12 }}>

        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          <Eyebrow>B4 · Quality Budget Dashboard</Eyebrow>
          <div style={{ flex:1 }} />
          <span style={{ fontSize:11, color:'rgba(var(--slate-rgb), 0.6)', fontFamily:'"IBM Plex Mono",monospace' }}>QUARTERLY BASELINE</span>
          {['Q2','Q3'].map(q => (
            <button type="button" key={q} onClick={() => setQuarter(q)}
              style={{ padding:'3px 10px', borderRadius:999, border:'none', cursor:'pointer',
                fontFamily:'"IBM Plex Mono",monospace', fontSize:10, fontWeight:700,
                background: quarter===q ? 'rgba(var(--teal-rgb), 0.13)':'rgba(var(--white-rgb), 0.6)',
                color: quarter===q ? 'var(--teal)':'var(--slate)',
                boxShadow: quarter===q ? '0 0 0 1px rgba(var(--teal-rgb), 0.3)':'0 0 0 1px rgba(var(--ink-rgb), 0.1)' }}>
              {q} 2024
            </button>
          ))}
        </div>

        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:14, flex:1 }}>
          {QB_DIMENSIONS.map(dim => {
            const cfg = QB_STATUS[dim.status];
            const usedPct = (dim.spent / dim.budget) * 100;
            const isSel = selected === dim.id;
            const baseline = quarter === 'Q3' ? dim.q3baseline : dim.q2baseline;
            const delta = dim.spent - baseline;
            return (
              <InteractiveCard key={dim.id} onClick={() => setSelected(s => s===dim.id?null:dim.id)} selected={isSel}
                ariaLabel={`Toggle quality budget ${dim.label}. ${cfg.label}.`}
                style={{
                  padding:'18px', borderRadius:20, cursor:'pointer',
                  background: isSel ? cfg.bg : 'rgba(var(--white-rgb), 0.6)',
                  border: `1.5px solid ${isSel ? cfg.color : 'rgba(var(--ink-rgb), 0.08)'}`,
                  boxShadow: isSel ? `0 0 0 2px ${cfg.border}` : 'none',
                  display:'flex', flexDirection:'column', gap:10,
                  transition:'all 160ms',
                }}>

                {/* Header */}
                <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
                  <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                    <span style={{ fontSize:14, color:cfg.color }}>{dim.icon}</span>
                    <span style={{ fontSize:15, fontWeight:800, color:'var(--ink)' }}>{dim.label}</span>
                  </div>
                  <Badge kind={cfg.badge}>{cfg.label}</Badge>
                </div>

                {/* Gauge + burn */}
                <div style={{ display:'flex', alignItems:'center', gap:12 }}>
                  <GaugeDial pct={usedPct} color={dim.color} size={80} />
                  <div>
                    <div style={{ fontSize:24, fontWeight:800, letterSpacing:'-0.04em', color:dim.color }}>
                      {usedPct.toFixed(0)}%
                    </div>
                    <div style={{ fontSize:10, color:'rgba(var(--slate-rgb), 0.7)', fontFamily:'"IBM Plex Mono",monospace' }}>
                      {dim.spent.toFixed(2)} / {dim.budget.toFixed(1)}% budget used
                    </div>
                    <div style={{ fontSize:11, color:cfg.color, fontWeight:700, marginTop:2 }}>
                      Burn {dim.burnRate.toFixed(2)}%/wk
                      {dim.forecastWeeks < 4 && <span style={{ color:'var(--ember)' }}> · {dim.forecastWeeks.toFixed(1)}w to exhaustion</span>}
                    </div>
                  </div>
                </div>

                {/* Sparkline */}
                <div>
                  <div style={{ display:'flex', justifyContent:'space-between', marginBottom:3 }}>
                    {WEEKS.map(w => (
                      <span key={w} style={{ fontSize:8, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.4)' }}>{w}</span>
                    ))}
                  </div>
                  <BurnSparkline values={dim.sparkline} budget={dim.budget} color={dim.color} />
                </div>

                {/* vs baseline */}
                <div style={{ display:'flex', justifyContent:'space-between', padding:'6px 10px', borderRadius:10, background:'rgba(var(--ink-rgb), 0.04)', border:'1px solid rgba(var(--ink-rgb), 0.07)' }}>
                  <span style={{ fontSize:10, color:'rgba(var(--slate-rgb), 0.7)' }}>vs {quarter} baseline</span>
                  <span style={{ fontSize:11, fontFamily:'"IBM Plex Mono",monospace', fontWeight:700, color:delta>0?'var(--ember)':'var(--teal)' }}>
                    {delta > 0 ? '+':''}{delta.toFixed(2)}%
                  </span>
                </div>
              </InteractiveCard>
            );
          })}
        </div>
      </div>

      {/* Detail panel */}
      <div style={{ width:256, flexShrink:0 }}>
        <Panel style={{ height:'100%' }}>
          <PanelHeader eyebrow="Budget spent by" title={selDim ? selDim.label : 'Select dimension'} />

          {!selDim ? (
            <p style={{ fontSize:12, color:'var(--slate)', lineHeight:1.6, margin:0 }}>
              Click any dimension card to see which source spent the error budget and when.
            </p>
          ) : (
            <div>
              <div style={{ marginBottom:14 }}>
                <Badge kind={QB_STATUS[selDim.status].badge}>{QB_STATUS[selDim.status].label}</Badge>
              </div>

              <Eyebrow style={{ marginBottom:10 }}>Budget spend attribution</Eyebrow>
              {selDim.spentBy.map((s, i) => (
                <div key={i} style={{ padding:'9px 11px', borderRadius:12, marginBottom:7, background:'rgba(var(--white-rgb), 0.54)', border:'1px solid rgba(var(--ink-rgb), 0.07)' }}>
                  <div style={{ fontSize:11, fontWeight:700, color:'var(--ink)', marginBottom:3 }}>{s.source}</div>
                  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                    <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, color:selDim.color, fontWeight:700 }}>{s.pct.toFixed(2)}%</span>
                    <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:'rgba(var(--slate-rgb), 0.55)' }}>{s.date}</span>
                  </div>
                  <div style={{ height:3, borderRadius:999, background:'rgba(var(--ink-rgb), 0.07)', marginTop:5, overflow:'hidden' }}>
                    <div style={{ height:'100%', borderRadius:999, background:selDim.color, width:`${(s.pct/selDim.budget*100).toFixed(0)}%` }} />
                  </div>
                </div>
              ))}

              <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', margin:'14px 0' }} />
              <Eyebrow style={{ marginBottom:6 }}>Forecast</Eyebrow>
              <div style={{ fontSize:22, fontWeight:800, letterSpacing:'-0.04em',
                color: selDim.forecastWeeks < 2 ? 'var(--ember)' : selDim.forecastWeeks < 6 ? 'var(--gold-vibrant)' : 'var(--teal)' }}>
                {selDim.forecastWeeks >= 20 ? '20+ weeks' : `${selDim.forecastWeeks.toFixed(1)} weeks`}
              </div>
              <div style={{ fontSize:11, color:'rgba(var(--slate-rgb), 0.7)', marginTop:2 }}>until budget exhaustion at current burn rate</div>
            </div>
          )}
        </Panel>
      </div>
    </div>
  );
}

Object.assign(window, { QualityBudgetScreen });
