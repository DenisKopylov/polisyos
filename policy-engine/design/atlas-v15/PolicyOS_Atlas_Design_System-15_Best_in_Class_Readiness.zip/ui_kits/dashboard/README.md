# PolicyOS Atlas UI Kit — Runtime Dashboard

High-fidelity interactive prototype of the Atlas Control Room dashboard. This pass upgrades the dashboard kit from a visual prototype toward a production accessibility baseline.

## What's included

- `index.html` — full interactive prototype with accessible shell landmarks, skip link, screen-title updates, and focus routing.
- `Components.jsx` — shared primitives: `Button`, `Badge`, `Panel`, `PanelHeader`, `MetricCard`, `RunCard`, `InteractiveCard`, `VisuallyHidden`.
- `Sidebar.jsx` — graphite rail with native button navigation, `aria-current`, unique route IDs, and Atlas glyph radicals only.
- Screen modules for command, composer, decision workspace, evidence, synthesis, provenance, fairness, triage, lineage, disputes, quality, drift, and governance workflows.

## Accessibility baseline

The dashboard follows the package-level accessibility contract in `../../accessibility/README.md`.

Implemented in this pass:

1. Shared token CSS is loaded through `../../colors_and_type.css`.
2. The app shell includes a skip link and named `main` landmark.
3. Sidebar navigation uses native buttons and exposes current screen with `aria-current="page"`.
4. Duplicate `evidence` route IDs were split into `evidence_fabric` and `evidence_synthesis`.
5. Clickable run/evidence/governance cards use `InteractiveCard`, a native button-backed primitive.
6. SVG graph nodes expose `role="button"`, `tabIndex={0}`, `focusable="true"`, `aria-label`, and Enter/Space keyboard activation.
7. Expand/collapse patterns use `aria-expanded` and `aria-controls`.
8. All dashboard buttons declare `type="button"` unless future form submit behavior requires otherwise.


## Token pipeline baseline

The dashboard kit now consumes the package token pipeline instead of hard-coded colors. Shared primitives bind to component tokens such as `--atlas-button-*`, `--atlas-badge-*`, `--atlas-panel-*`, `--atlas-metric-*`, and `--atlas-rail-*`. Screen modules use semantic tokens or RGB channel tokens like `rgba(var(--ink-rgb), 0.08)` for alpha composition.

Run the token gates from the package root:

```bash
python3 scripts/token_build.py
python3 scripts/token_lint.py
```

`token_lint.py` blocks hard-coded `#hex`, raw `rgb()` and non-token `rgba()` values in `ui_kits/dashboard/*.jsx`.

## Accessibility acceptance gates

Before promoting this kit to production, run:

```bash
python3 ../../scripts/a11y_contrast_audit.py
python3 ../../scripts/a11y_static_lint.py
```

Generated evidence lives in:

- `../../accessibility/contrast-audit.md`
- `../../accessibility/audit-results.md`

## Current screens

The prototype includes the original core screens plus expanded governance surfaces:

- Command Center
- Scenario Composer
- Decision Workspace
- Evidence Fabric
- Evidence Synthesis
- Causal Atlas
- Counterfactual Explorer
- Identifiability Surface
- Sensitivity Rotor
- Quality Budget
- Fairness Audit
- Stress Test Theatre
- Provenance Certificate
- Lineage Gravity Map
- Reasoning Chain
- Run Choreography
- Live Run Monitor
- Failure Triage
- Dispute Ledger
- Embargo Manager
- Schema Migration
- Capacity Planner
- Profile Drift Narrative
- Stakeholder Lens
- Ops Audit Trail

## Design width

The prototype is optimized for desktop operator use at 1440px+, but the accessibility layer no longer assumes mouse-only interaction. Responsive behavior, compact density, and mobile data-table alternatives remain separate roadmap items.

## Usage

Open `index.html` in a browser. Navigate with the sidebar buttons or the tweak panel. Keyboard users can use the skip link to jump directly to the active screen.


## Component-library bridge

As of v10, this folder is a compatibility preview shell. Production surfaces should import typed components from `packages/atlas-ui` / `@policyos/atlas-ui` instead of adding new primitives to `Components.jsx`.

Migration map:

- `Button` -> `@policyos/atlas-ui/Button`
- `Badge` -> `@policyos/atlas-ui/Badge`
- `Panel` -> `@policyos/atlas-ui/Panel` or `Card`
- `InteractiveCard` -> native button/link composition with `Card`, or domain components such as `RunCard`
- ad-hoc forms -> `TextField`, `TextArea`, `Select`, `Checkbox`, `Switch`
- governance/evidence cards -> `GovernanceGate`, `EvidenceCard`, `RunCard`


## Component-library relationship

`ui_kits/dashboard/Components.jsx` is now a compatibility bundle for the no-build dashboard prototype. The canonical implementation path is `packages/atlas-ui`, which provides typed React components, Storybook stories, tests, contracts, registry metadata, and token-bound CSS. Product code should migrate component by component using `packages/atlas-ui/docs/migration-guide.md`.
