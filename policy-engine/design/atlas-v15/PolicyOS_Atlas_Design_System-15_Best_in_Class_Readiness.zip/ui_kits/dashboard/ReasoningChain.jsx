// ReasoningChain.jsx — E2
// Step-by-step inference trace: each step shows input → operation → output → confidence delta
// Exports: ReasoningChainScreen

const CHAIN_STEPS = [
  {
    id:'S1', label:'Input ingestion',
    type:'data',
    input:'citizen_id C-2024-18440, application_date 2024-09-28',
    operation:'Retrieve record from fiscal_reform_dataset v3.4',
    output:'42 feature values loaded. Completeness 100%. Schema v2.1 validated.',
    confidence:null, confidenceDelta:null,
    duration:'12ms', status:'ok',
    detail:'Record retrieved from Fiscal DB read replica. income_quartile=Q1, municipality_id=UA-10-4, employment_status=EMPLOYED (14mo).',
  },
  {
    id:'S2', label:'Eligibility pre-filter',
    type:'rule',
    input:'Feature vector (42 dimensions)',
    operation:'Apply hard eligibility rules: age ∈ [18,65], region NOT embargoed, not duplicate',
    output:'ELIGIBLE — all 3 hard rules passed',
    confidence:1.0, confidenceDelta:0,
    duration:'3ms', status:'ok',
    detail:'Age: 34 ✓. Region UA-10-4 not in embargo list ✓. Deduplication hash: unique ✓.',
  },
  {
    id:'S3', label:'Feature engineering',
    type:'transform',
    input:'Raw 42-dim vector',
    operation:'Normalise income_quartile (ordinal → [0,1]); compute employment_duration_z; impute 0 missing values',
    output:'Processed 38-dim feature vector (4 raw features dropped as collinear)',
    confidence:null, confidenceDelta:null,
    duration:'8ms', status:'ok',
    detail:'income_quartile encoded as 0.0 (Q1 = lowest). employment_duration_z = −0.41 (below mean). No imputation required.',
  },
  {
    id:'S4', label:'Model inference',
    type:'model',
    input:'38-dim normalised vector',
    operation:'XGBoost fiscal_model_v3.4 predict_proba()',
    output:'P(approve) = 0.791, P(reject) = 0.209',
    confidence:0.791, confidenceDelta:0,
    duration:'141ms', status:'ok',
    detail:'Model version 3.4.1. Decision threshold 0.60. Raw log-odds: 1.327. Ensemble of 400 trees.',
  },
  {
    id:'S5', label:'SHAP attribution',
    type:'explain',
    input:'Model output + input vector',
    operation:'TreeSHAP attribution (exact, not approximate)',
    output:'Top features: employment_duration_z (+0.18), income_quartile (−0.11), municipality_id (+0.07)',
    confidence:0.791, confidenceDelta:0,
    duration:'28ms', status:'ok',
    detail:'SHAP sum: 0.791 (matches model output). income_quartile negative contribution flags fairness review. employment_duration positive.',
  },
  {
    id:'S6', label:'Fairness gate',
    type:'gate',
    input:'SHAP values + protected attribute list',
    operation:'Check income_quartile SHAP contribution against fairness threshold (|SHAP| < 0.15)',
    output:'WARN: income_quartile SHAP = −0.11. Below threshold but flagged for audit log.',
    confidence:0.791, confidenceDelta:0,
    duration:'2ms', status:'warn',
    detail:'Threshold 0.15 not breached (−0.11 < 0.15). Decision proceeds. Fairness flag appended to audit record AUD-009.',
  },
  {
    id:'S7', label:'Confidence calibration',
    type:'calibrate',
    input:'Raw P(approve) = 0.791',
    operation:'Apply Platt scaling calibration (trained on held-out Q2 data)',
    output:'Calibrated confidence = 0.784',
    confidence:0.784, confidenceDelta:-0.007,
    duration:'1ms', status:'ok',
    detail:'Platt scaling coefficients: a=1.082, b=−0.041. Calibration reduces overconfidence from base model.',
  },
  {
    id:'S8', label:'Decision adjudication',
    type:'decision',
    input:'Calibrated confidence 0.784 > threshold 0.60',
    operation:'Apply decision rule: APPROVE if P(approve) ≥ 0.60',
    output:'DECISION: APPROVED. Amount: ₴18,400. Tier: T1 Full Benefit.',
    confidence:0.784, confidenceDelta:0,
    duration:'1ms', status:'ok',
    detail:'Margin above threshold: +0.184. Caseworker review required (T1 decisions). Dispatched to caseworker queue.',
  },
];

const STEP_TYPE = {
  data:      { icon:'▪', color:'var(--chart-secondary)', label:'Data'       },
  rule:      { icon:'≡', color:'var(--gold)', label:'Rule'       },
  transform: { icon:'~', color:'var(--slate)', label:'Transform'  },
  model:     { icon:'◆', color:'var(--teal)', label:'Model'      },
  explain:   { icon:'◈', color:'var(--teal-vibrant)', label:'Explain'    },
  gate:      { icon:'⊘', color:'var(--gold-vibrant)', label:'Gate'       },
  calibrate: { icon:'◎', color:'var(--teal)', label:'Calibrate'  },
  decision:  { icon:'✓', color:'var(--teal)', label:'Decision'   },
};

const STEP_STATUS = {
  ok:   { color:'var(--teal)', badge:'ok'   },
  warn: { color:'var(--gold-vibrant)', badge:'warn' },
  fail: { color:'var(--ember)', badge:'fail' },
};

function ConfidencePip({ value, delta }) {
  if (value === null) return <div style={{ width:48 }} />;
  const color = value >= 0.7 ? 'var(--teal)' : value >= 0.5 ? 'var(--gold-vibrant)' : 'var(--ember)';
  return (
    <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:2, width:48, flexShrink:0 }}>
      <div style={{ fontSize:13, fontWeight:800, color, letterSpacing:'-0.02em' }}>{(value*100).toFixed(0)}</div>
      <div style={{ fontSize:8, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.5)' }}>conf%</div>
      {delta !== null && delta !== 0 && (
        <div style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', fontWeight:700, color: delta > 0 ? 'var(--teal)':'var(--ember)' }}>
          {delta > 0 ? '+':''}{(delta*100).toFixed(1)}
        </div>
      )}
    </div>
  );
}

function ReasoningChainScreen() {
  const [selStep, setSelStep] = React.useState(null);
  const [collapsed, setCollapsed] = React.useState(new Set());

  function toggleCollapse(id) {
    setCollapsed(s => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });
  }

  const sel = selStep ? CHAIN_STEPS.find(s => s.id === selStep) : null;
  const totalDur = CHAIN_STEPS.reduce((s, st) => s + parseInt(st.duration), 0);

  return (
    <div style={{ display:'flex', gap:20, height:'100%' }}>

      {/* Chain */}
      <div style={{ flex:1, minWidth:0, display:'flex', flexDirection:'column', gap:10 }}>

        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <Eyebrow>E2 · Reasoning Chain</Eyebrow>
          <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, color:'rgba(var(--slate-rgb), 0.55)' }}>Decision D-Q3-001 · Applicant C-2024-18440</span>
          <div style={{ flex:1 }} />
          <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, color:'var(--teal)', fontWeight:700 }}>
            {totalDur}ms total
          </span>
          <Badge kind="ok">APPROVED</Badge>
        </div>

        <div style={{ flex:1, overflowY:'auto', display:'flex', flexDirection:'column', gap:0 }}>
          {CHAIN_STEPS.map((step, idx) => {
            const tc    = STEP_TYPE[step.type];
            const sc    = STEP_STATUS[step.status];
            const isSel = selStep === step.id;
            const isCol = collapsed.has(step.id);
            const isLast = idx === CHAIN_STEPS.length - 1;

            return (
              <div key={step.id} style={{ display:'flex', gap:12 }}>
                {/* Spine */}
                <div style={{ display:'flex', flexDirection:'column', alignItems:'center', width:36, flexShrink:0 }}>
                  <button type="button" aria-pressed={isSel ? 'true' : 'false'} aria-label={`Toggle reasoning step ${step.id}: ${step.label}`} style={{
                    width:32, height:32, borderRadius:'50%', flexShrink:0,
                    background: isSel ? tc.color+'22' : 'rgba(var(--white-rgb), 0.65)',
                    border:`2px solid ${isSel ? tc.color : 'rgba(var(--ink-rgb), 0.12)'}`,
                    display:'flex', alignItems:'center', justifyContent:'center',
                    fontSize:14, color:tc.color, fontWeight:800, cursor:'pointer',
                    transition:'all 140ms',
                  }} onClick={() => setSelStep(s => s===step.id ? null : step.id)}>
                    {tc.icon}
                  </button>
                  {!isLast && (
                    <div style={{ flex:1, width:2, background:'rgba(var(--ink-rgb), 0.1)', minHeight:16, marginTop:2 }} />
                  )}
                </div>

                {/* Card */}
                <div style={{ flex:1, paddingBottom:10 }}>
                  <div
                    style={{
                      borderRadius:16, overflow:'hidden',
                      background: isSel ? tc.color+'0f' : 'rgba(var(--white-rgb), 0.56)',
                      border:`1.5px solid ${isSel ? tc.color : 'rgba(var(--ink-rgb), 0.08)'}`,
                      transition:'all 140ms',
                    }}>
                    {/* Header row */}
                    <button type="button" aria-expanded={!isCol} aria-controls={`reasoning-step-${step.id}`} style={{ display:'flex', alignItems:'center', gap:10, padding:'10px 14px', cursor:'pointer', width:'100%', textAlign:'left', background:'transparent', border:'none', font:'inherit' }}
                      onClick={() => toggleCollapse(step.id)}>
                      <div style={{ flex:1 }}>
                        <div style={{ display:'flex', gap:7, alignItems:'center', marginBottom:3 }}>
                          <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, fontWeight:700, color:tc.color, letterSpacing:'0.08em' }}>
                            {step.id} · {tc.label.toUpperCase()}
                          </span>
                          {step.status !== 'ok' && <Badge kind={sc.badge}>{step.status}</Badge>}
                          <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:'rgba(var(--slate-rgb), 0.45)', marginLeft:'auto' }}>{step.duration}</span>
                        </div>
                        <span style={{ fontSize:13, fontWeight:700, color:'var(--ink)' }}>{step.label}</span>
                      </div>
                      <ConfidencePip value={step.confidence} delta={step.confidenceDelta} />
                      <span style={{ fontSize:11, color:'rgba(var(--slate-rgb), 0.4)' }}>{isCol ? '▸':'▾'}</span>
                    </button>

                    {/* Body */}
                    {!isCol && (
                      <div id={`reasoning-step-${step.id}`} style={{ padding:'0 14px 12px', borderTop:'1px solid rgba(var(--ink-rgb), 0.06)' }}>
                        <div style={{ display:'grid', gridTemplateColumns:'72px 1fr', gap:'4px 10px', marginTop:10 }}>
                          {[['INPUT', step.input],['OPERATION', step.operation],['OUTPUT', step.output]].map(([lbl, val]) => (
                            <React.Fragment key={lbl}>
                              <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:8, color:'rgba(var(--slate-rgb), 0.45)', letterSpacing:'0.1em', paddingTop:2 }}>{lbl}</span>
                              <span style={{ fontSize:12, color:'var(--ink)', lineHeight:1.5, fontWeight: lbl==='OUTPUT'?600:400,
                                color: lbl==='OUTPUT' ? (step.status==='warn'?'var(--gold-vibrant)':step.status==='fail'?'var(--ember)':'var(--teal)') : 'var(--ink)' }}>
                                {val}
                              </span>
                            </React.Fragment>
                          ))}
                        </div>
                        {isSel && (
                          <div style={{ marginTop:10, padding:'9px 12px', borderRadius:10,
                            background:'rgba(var(--white-rgb), 0.55)', border:'1px solid rgba(var(--ink-rgb), 0.07)' }}>
                            <div style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.5)', letterSpacing:'0.08em', marginBottom:4 }}>TECHNICAL DETAIL</div>
                            <p style={{ margin:0, fontSize:11, color:'var(--slate)', lineHeight:1.6, fontFamily:'"IBM Plex Mono",monospace' }}>{step.detail}</p>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Summary panel */}
      <div style={{ width:240, flexShrink:0 }}>
        <Panel style={{ height:'100%' }}>
          <PanelHeader eyebrow="Chain summary" title="8 steps" />

          {Object.entries(STEP_TYPE).map(([key, cfg]) => {
            const count = CHAIN_STEPS.filter(s => s.type === key).length;
            if (!count) return null;
            return (
              <div key={key} style={{ display:'flex', alignItems:'center', gap:8, marginBottom:7 }}>
                <span style={{ fontSize:12, color:cfg.color, width:16 }}>{cfg.icon}</span>
                <span style={{ fontSize:12, color:cfg.color, fontWeight:600 }}>{cfg.label}</span>
                <span style={{ marginLeft:'auto', fontFamily:'"IBM Plex Mono",monospace', fontSize:10, color:'rgba(var(--slate-rgb), 0.55)' }}>{count}</span>
              </div>
            );
          })}

          <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', margin:'14px 0' }} />
          <Eyebrow style={{ marginBottom:10 }}>Confidence trace</Eyebrow>
          {CHAIN_STEPS.filter(s => s.confidence !== null).map(s => {
            const color = s.confidence >= 0.7 ? 'var(--teal)' : s.confidence >= 0.5 ? 'var(--gold-vibrant)' : 'var(--ember)';
            return (
              <InteractiveCard key={s.id} selected={selStep === s.id} ariaLabel={`Select confidence trace step ${s.id}`} style={{ display:'flex', alignItems:'center', gap:8, marginBottom:7, cursor:'pointer', padding:0 }}
                onClick={() => setSelStep(s.id)}>
                <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:'rgba(var(--slate-rgb), 0.5)', width:20 }}>{s.id}</span>
                <div style={{ flex:1, height:4, borderRadius:999, background:'rgba(var(--ink-rgb), 0.07)', overflow:'hidden' }}>
                  <div style={{ height:'100%', borderRadius:999, background:color, width:`${(s.confidence*100).toFixed(0)}%` }} />
                </div>
                <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, fontWeight:700, color, minWidth:28 }}>
                  {(s.confidence*100).toFixed(0)}%
                </span>
              </InteractiveCard>
            );
          })}

          <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', margin:'14px 0' }} />
          <Eyebrow style={{ marginBottom:8 }}>Duration breakdown</Eyebrow>
          {CHAIN_STEPS.map(s => {
            const tc = STEP_TYPE[s.type];
            const dur = parseInt(s.duration);
            return (
              <div key={s.id} style={{ display:'flex', alignItems:'center', gap:8, marginBottom:5 }}>
                <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:'rgba(var(--slate-rgb), 0.45)', width:20 }}>{s.id}</span>
                <div style={{ flex:1, height:4, borderRadius:999, background:'rgba(var(--ink-rgb), 0.06)', overflow:'hidden' }}>
                  <div style={{ height:'100%', borderRadius:999, background:tc.color, width:`${(dur/totalDur*100).toFixed(0)}%` }} />
                </div>
                <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:'rgba(var(--slate-rgb), 0.55)', minWidth:30, textAlign:'right' }}>{s.duration}</span>
              </div>
            );
          })}
        </Panel>
      </div>
    </div>
  );
}

Object.assign(window, { ReasoningChainScreen });
