// RunChoreography.jsx — D1
// Partition/wave scheduler: dependency DAG, wave batching, partition status grid
// Exports: RunChoreographyScreen

const WAVES = [
  {
    id:'W1', label:'Wave 1 · Data Ingestion', status:'complete', started:'08:00', ended:'08:34',
    partitions:[
      { id:'P1-1', label:'Fiscal DB pull',      status:'complete', dur:'18m', records:42180 },
      { id:'P1-2', label:'Employment SFTP',      status:'complete', dur:'34m', records:42042 },
      { id:'P1-3', label:'GDP REST pull',        status:'complete', dur:'6m',  records:3200  },
      { id:'P1-4', label:'Budget IV Kafka',      status:'complete', dur:'2m',  records:8840  },
    ],
  },
  {
    id:'W2', label:'Wave 2 · Validation & Join', status:'complete', started:'08:35', ended:'09:02',
    partitions:[
      { id:'P2-1', label:'Schema validation',    status:'complete', dur:'8m',  records:42180 },
      { id:'P2-2', label:'Completeness check',   status:'complete', dur:'5m',  records:42180 },
      { id:'P2-3', label:'Cross-source join',    status:'complete', dur:'14m', records:41980 },
    ],
  },
  {
    id:'W3', label:'Wave 3 · Feature Engineering', status:'complete', started:'09:03', ended:'09:41',
    partitions:[
      { id:'P3-1', label:'Income quartile calc', status:'complete', dur:'9m',  records:41980 },
      { id:'P3-2', label:'Lag imputation',       status:'complete', dur:'22m', records:41980 },
      { id:'P3-3', label:'Normalisation',        status:'complete', dur:'7m',  records:41980 },
    ],
  },
  {
    id:'W4', label:'Wave 4 · Model Inference', status:'running', started:'09:42', ended:null,
    partitions:[
      { id:'P4-1', label:'Shard A (0–14k)',      status:'complete', dur:'11m', records:14000 },
      { id:'P4-2', label:'Shard B (14k–28k)',    status:'running',  dur:'—',   records:14000 },
      { id:'P4-3', label:'Shard C (28k–42k)',    status:'queued',   dur:'—',   records:13980 },
    ],
  },
  {
    id:'W5', label:'Wave 5 · Decision & Dispatch', status:'blocked', started:null, ended:null,
    partitions:[
      { id:'P5-1', label:'Decision adjudication',status:'blocked',  dur:'—',   records:0 },
      { id:'P5-2', label:'Caseworker dispatch',  status:'blocked',  dur:'—',   records:0 },
      { id:'P5-3', label:'Audit log write',      status:'blocked',  dur:'—',   records:0 },
    ],
  },
];

const DEP_EDGES = [
  { from:'W1', to:'W2' }, { from:'W2', to:'W3' }, { from:'W3', to:'W4' }, { from:'W4', to:'W5' },
];

const WAVE_STATUS = {
  complete: { color:'var(--teal)', bg:'rgba(var(--teal-rgb), 0.12)',   border:'rgba(var(--teal-rgb), 0.28)',   badge:'ok',      icon:'✓' },
  running:  { color:'var(--gold-vibrant)', bg:'rgba(var(--gold-vibrant-rgb), 0.12)', border:'rgba(var(--gold-vibrant-rgb), 0.30)', badge:'warn',    icon:'▶' },
  blocked:  { color:'var(--ember)', bg:'rgba(var(--ember-rgb), 0.10)',  border:'rgba(var(--ember-rgb), 0.28)',  badge:'fail',    icon:'⊘' },
  queued:   { color:'var(--slate)', bg:'rgba(var(--slate-rgb), 0.08)',   border:'rgba(var(--slate-rgb), 0.20)',   badge:'neutral', icon:'○' },
};

function PartitionCell({ part, selected, onSelect }) {
  const st  = WAVE_STATUS[part.status];
  const isSel = selected === part.id;
  return (
    <InteractiveCard onClick={() => onSelect(isSel ? null : part.id)} selected={isSel}
      ariaLabel={`Toggle partition ${part.label}. Status ${part.status}.`}
      style={{
        padding:'9px 11px', borderRadius:12, cursor:'pointer',
        background: isSel ? st.bg : 'rgba(var(--white-rgb), 0.52)',
        border:`1.5px solid ${isSel ? st.color : 'rgba(var(--ink-rgb), 0.08)'}`,
        transition:'all 140ms',
      }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:4 }}>
        <span style={{ fontSize:11, fontWeight:700, color:'var(--ink)' }}>{part.label}</span>
        <span style={{ fontSize:13, color:st.color }}>{st.icon}</span>
      </div>
      <div style={{ display:'flex', gap:10 }}>
        <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:st.color, fontWeight:700 }}>{part.status.toUpperCase()}</span>
        <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:'rgba(var(--slate-rgb), 0.55)' }}>{part.dur}</span>
        {part.records > 0 && (
          <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:'rgba(var(--slate-rgb), 0.55)' }}>{part.records.toLocaleString()} rec</span>
        )}
      </div>
    </InteractiveCard>
  );
}

// Mini Gantt bar
function GanttBar({ wave, totalMinutes = 120, startMinute = 0 }) {
  const parse = t => { if (!t) return null; const [h,m] = t.split(':').map(Number); return (h-8)*60+m; };
  const s = parse(wave.started), e = parse(wave.ended);
  const now = 60; // "now" = 09:00 = 60 min after 08:00
  const barStart = s !== null ? s / totalMinutes * 100 : null;
  const barEnd   = e !== null ? e / totalMinutes * 100 : (s !== null ? now / totalMinutes * 100 : null);
  const cfg = WAVE_STATUS[wave.status];
  if (barStart === null) return <div style={{ height:12, borderRadius:999, background:'rgba(var(--ink-rgb), 0.06)' }} />;
  return (
    <div style={{ position:'relative', height:12, borderRadius:999, background:'rgba(var(--ink-rgb), 0.06)', overflow:'hidden' }}>
      <div style={{
        position:'absolute', top:0, bottom:0,
        left:`${barStart}%`, width:`${Math.max(barEnd - barStart, 1)}%`,
        background:cfg.color, opacity:wave.status==='running'?0.7:0.85, borderRadius:999,
      }} />
      {/* Now marker */}
      <div style={{ position:'absolute', top:0, bottom:0, width:1.5, left:`${now/totalMinutes*100}%`, background:'rgba(var(--ember-vibrant-rgb), 0.7)' }} />
    </div>
  );
}

function RunChoreographyScreen() {
  const [selPart, setSelPart] = React.useState(null);
  const [selWave, setSelWave] = React.useState(null);

  const selPartObj = selPart ? WAVES.flatMap(w=>w.partitions).find(p=>p.id===selPart) : null;
  const selWaveObj = selWave ? WAVES.find(w=>w.id===selWave) : null;

  const totalPartitions = WAVES.flatMap(w=>w.partitions).length;
  const donePartitions  = WAVES.flatMap(w=>w.partitions).filter(p=>p.status==='complete').length;

  return (
    <div style={{ display:'flex', gap:20, height:'100%' }}>
      <div style={{ flex:1, minWidth:0, display:'flex', flexDirection:'column', gap:12 }}>

        {/* Header */}
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <Eyebrow>D1 · Run Choreography</Eyebrow>
          <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, color:'rgba(var(--slate-rgb), 0.6)' }}>
            fiscal_reform_q2_001 · Wave {WAVES.findIndex(w=>w.status==='running')+1}/{WAVES.length}
          </span>
          <div style={{ flex:1 }} />
          <Badge kind="warn">RUNNING · W4</Badge>
        </div>

        {/* Gantt */}
        <Panel style={{ padding:'14px 18px' }}>
          <div style={{ display:'flex', justifyContent:'space-between', marginBottom:10 }}>
            <Eyebrow>Timeline · 08:00 → 10:00</Eyebrow>
            <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:'rgba(var(--ember-vibrant-rgb), 0.8)', fontWeight:700 }}>▶ NOW 09:00</span>
          </div>
          <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
            {WAVES.map(w => {
              const cfg = WAVE_STATUS[w.status];
              return (
                <div key={w.id} style={{ display:'flex', alignItems:'center', gap:10 }}>
                  <span style={{ fontSize:10, fontWeight:700, color:cfg.color, width:24, flexShrink:0 }}>{w.id}</span>
                  <div style={{ flex:1 }}>
                    <GanttBar wave={w} />
                  </div>
                  <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:'rgba(var(--slate-rgb), 0.55)', width:80, textAlign:'right', flexShrink:0 }}>
                    {w.started || '—'} → {w.ended || '…'}
                  </span>
                </div>
              );
            })}
          </div>
          {/* Overall progress */}
          <div style={{ marginTop:12, height:5, borderRadius:999, background:'rgba(var(--ink-rgb), 0.08)', overflow:'hidden' }}>
            <div style={{ height:'100%', background:'var(--teal-vibrant)', borderRadius:999, width:`${(donePartitions/totalPartitions*100).toFixed(0)}%`, transition:'width 400ms' }} />
          </div>
          <div style={{ display:'flex', justifyContent:'space-between', marginTop:4 }}>
            <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:'rgba(var(--slate-rgb), 0.55)' }}>
              {donePartitions}/{totalPartitions} partitions complete
            </span>
            <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:'var(--teal)', fontWeight:700 }}>
              {(donePartitions/totalPartitions*100).toFixed(0)}%
            </span>
          </div>
        </Panel>

        {/* Wave + partition grid */}
        <div style={{ flex:1, overflowY:'auto', display:'flex', flexDirection:'column', gap:12 }}>
          {WAVES.map(w => {
            const cfg = WAVE_STATUS[w.status];
            return (
              <div key={w.id}>
                <InteractiveCard onClick={() => setSelWave(s => s===w.id ? null : w.id)} selected={selWave === w.id}
                  ariaLabel={`Toggle wave ${w.label}. Status ${w.status}.`}
                  style={{ display:'flex', alignItems:'center', gap:10, marginBottom:8, cursor:'pointer', padding:0 }}>
                  <div style={{ width:24, height:24, borderRadius:'50%', background:cfg.bg, border:`1.5px solid ${cfg.color}`,
                    display:'flex', alignItems:'center', justifyContent:'center', fontSize:11, color:cfg.color, fontWeight:800, flexShrink:0 }}>
                    {cfg.icon}
                  </div>
                  <span style={{ fontSize:13, fontWeight:800, color:'var(--ink)' }}>{w.label}</span>
                  <Badge kind={cfg.badge}>{w.status}</Badge>
                  {w.started && <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:'rgba(var(--slate-rgb), 0.5)' }}>{w.started}{w.ended ? ` → ${w.ended}`:''}</span>}
                </InteractiveCard>
                <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(220px,1fr))', gap:8, marginLeft:34 }}>
                  {w.partitions.map(p => (
                    <PartitionCell key={p.id} part={p} selected={selPart} onSelect={setSelPart} />
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Inspector */}
      <div style={{ width:252, flexShrink:0 }}>
        <Panel style={{ height:'100%' }}>
          <PanelHeader eyebrow="Inspector" title={selPartObj ? selPartObj.label : selWaveObj ? selWaveObj.label : 'Run overview'} />

          {!selPartObj && !selWaveObj ? (
            <div>
              {Object.entries(WAVE_STATUS).map(([key, cfg]) => {
                const n = WAVES.flatMap(w=>w.partitions).filter(p=>p.status===key).length;
                if (!n) return null;
                return (
                  <div key={key} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
                    <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                      <span style={{ color:cfg.color, fontSize:13 }}>{cfg.icon}</span>
                      <span style={{ fontSize:12, fontWeight:600, color:cfg.color }}>{key}</span>
                    </div>
                    <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, color:'var(--slate)' }}>{n} partitions</span>
                  </div>
                );
              })}
              <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', margin:'14px 0' }} />
              <Eyebrow style={{ marginBottom:8 }}>Total records processed</Eyebrow>
              <div style={{ fontSize:28, fontWeight:800, letterSpacing:'-0.04em', color:'var(--teal)' }}>
                {WAVES.flatMap(w=>w.partitions).filter(p=>p.status==='complete').reduce((s,p)=>s+p.records,0).toLocaleString()}
              </div>
              <div style={{ fontSize:10, color:'rgba(var(--slate-rgb), 0.6)', marginTop:2, fontFamily:'"IBM Plex Mono",monospace' }}>of 42,180 total</div>
              <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', margin:'14px 0' }} />
              <p style={{ fontSize:12, color:'var(--slate)', lineHeight:1.6, margin:0 }}>
                Wave 4 inference running. Shards B and C pending. Wave 5 blocked on W4 completion.
              </p>
            </div>
          ) : selPartObj ? (
            <div>
              <Badge kind={WAVE_STATUS[selPartObj.status].badge}>{selPartObj.status}</Badge>
              <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', margin:'14px 0' }} />
              {[
                { label:'Partition ID', val:selPartObj.id },
                { label:'Duration',     val:selPartObj.dur },
                { label:'Records',      val:selPartObj.records > 0 ? selPartObj.records.toLocaleString() : '—' },
              ].map(r => (
                <div key={r.label} style={{ marginBottom:10 }}>
                  <div style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.6)', marginBottom:2 }}>{r.label.toUpperCase()}</div>
                  <div style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:12, fontWeight:700, color:'var(--ink)' }}>{r.val}</div>
                </div>
              ))}
              <button type="button" onClick={() => setSelPart(null)} style={{ marginTop:12, fontSize:11, color:'rgba(var(--slate-rgb), 0.7)', background:'none', border:'none', cursor:'pointer', padding:0 }}>← Overview</button>
            </div>
          ) : null}
        </Panel>
      </div>
    </div>
  );
}

Object.assign(window, { RunChoreographyScreen });
