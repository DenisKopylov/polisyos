// RunDetail.jsx — Decision Workspace screen

function GovItem({ glyph, label, status, note }) {
  const kind = status === 'pass' ? 'ok' : status === 'review' ? 'warn' : 'fail';
  return (
    <div style={{display:'flex', alignItems:'center', justifyContent:'space-between', gap:12, padding:'12px 0', borderTop:'1px solid rgba(var(--ink-rgb), 0.08)'}}>
      <div style={{display:'flex', alignItems:'center', gap:10}}>
        <img src={`../../assets/glyphs/${glyph}.svg`} width={14} height={14} style={{opacity:0.75}} />
        <span style={{fontSize:13, fontWeight:600}}>{label}</span>
      </div>
      <div style={{display:'flex', flexDirection:'column', alignItems:'flex-end', gap:3}}>
        <Badge kind={kind}>{status}</Badge>
        {note && <span style={{fontSize:10, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--ink-rgb), 0.52)'}}>{note}</span>}
      </div>
    </div>
  );
}

function ImpactBar({ label, pct, color='var(--teal-vibrant)', dir=1 }) {
  return (
    <div style={{display:'grid', gridTemplateColumns:'110px 1fr 52px', alignItems:'center', gap:10}}>
      <span style={{fontSize:12, color:'rgba(var(--ink-rgb), 0.72)', fontWeight:600}}>{label}</span>
      <div style={{height:16, borderRadius:999, background:`rgba(var(--teal-vibrant-rgb), 0.08)`, overflow:'hidden', position:'relative'}}>
        <div style={{
          position:'absolute', height:'100%',
          left: dir > 0 ? '50%' : `${50 - pct/2}%`,
          width:`${pct/2}%`,
          background:color, borderRadius:'inherit',
        }} />
        <div style={{position:'absolute', top:'50%', left:'50%', width:1, height:'100%', background:'rgba(var(--ink-rgb), 0.15)', transform:'translateY(-50%)'}} />
      </div>
      <span style={{fontSize:12, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--ink-rgb), 0.65)', textAlign:'right'}}>
        {dir>0?'+':''}{pct}%
      </span>
    </div>
  );
}

function RunDetailScreen({ runId = 'fiscal_reform_q2_001' }) {
  const [activeTab, setActiveTab] = React.useState('narrative');
  const tabs = ['narrative', 'impact', 'evidence', 'governance'];

  return (
    <div style={{display:'grid', gap:18}}>
      {/* Topbar */}
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'flex-start', flexWrap:'wrap', gap:12}}>
        <div>
          <div style={{display:'inline-flex', alignItems:'center', gap:8, padding:'5px 10px 5px 5px', border:'1px solid rgba(var(--ink-rgb), 0.08)', borderRadius:999, background:'rgba(var(--white-rgb), 0.62)', marginBottom:8}}>
            <img src="../../assets/glyphs/intervention.svg" width={16} height={16} />
            <span style={{fontFamily:'"IBM Plex Mono",monospace', fontSize:10, letterSpacing:'0.08em', textTransform:'uppercase', color:'rgba(var(--ink-rgb), 0.65)'}}>Run · Decision Workspace</span>
          </div>
          <h1 style={{margin:0, fontSize:28, fontWeight:800, letterSpacing:'-0.04em', lineHeight:1.05}}>{runId}</h1>
          <p style={{margin:'6px 0 0', fontSize:14, color:'rgba(var(--ink-rgb), 0.65)'}}>Fiscal reform · Q2 2026 · Completed 14.2s · 38 artifacts</p>
        </div>
        <div style={{display:'flex', gap:8, alignItems:'center'}}>
          <Badge kind="ok">● Completed</Badge>
          <Button variant="ghost">Export PDF</Button>
          <Button variant="dark">Approve Decision</Button>
        </div>
      </div>

      {/* Tabs */}
      <div style={{display:'flex', gap:8, borderBottom:'1px solid rgba(var(--ink-rgb), 0.1)', paddingBottom:0}}>
        {tabs.map(t => (
          <button type="button" key={t} onClick={() => setActiveTab(t)} style={{
            padding:'10px 14px', background:'transparent', border:'none', cursor:'pointer',
            fontFamily:'Manrope, sans-serif', fontSize:13, fontWeight:700,
            color: activeTab===t ? 'var(--ink)' : 'rgba(var(--ink-rgb), 0.52)',
            borderBottom: activeTab===t ? '2px solid var(--teal-vibrant)' : '2px solid transparent',
            textTransform:'capitalize',
          }}>{t}</button>
        ))}
      </div>

      {/* Content grid */}
      <div style={{display:'grid', gridTemplateColumns:'minmax(320px,0.9fr) minmax(0,1.2fr) minmax(280px,0.8fr)', gap:18}}>

        {/* Narrative */}
        <Panel style={{display:'flex', flexDirection:'column', gap:14}}>
          <PanelHeader eyebrow="Decision Narrative" title="Rationale" />
          <div style={{display:'grid', gap:10}}>
            <div style={{padding:'12px 14px', borderRadius:16, background:'rgba(var(--teal-vibrant-rgb), 0.08)', border:'1px solid rgba(var(--teal-vibrant-rgb), 0.15)'}}>
              <p style={{margin:0, fontSize:13, lineHeight:1.65, color:'rgba(var(--ink-rgb), 0.78)'}}>
                The VAT adjustment scenario shows a <strong>+2.3% GDP effect</strong> with 80% CI [1.8, 2.9]. Evidence quality is high across all primary sources.
              </p>
            </div>
            <div style={{padding:'12px 14px', borderRadius:16, background:'rgba(var(--gold-vibrant-rgb), 0.08)', border:'1px solid rgba(var(--gold-vibrant-rgb), 0.15)'}}>
              <p style={{margin:0, fontSize:13, lineHeight:1.65, color:'rgba(var(--ink-rgb), 0.78)'}}>
                <strong>Transport assumption flagged:</strong> External validity from OECD to UA context requires generalization pass. Confidence reduced to Medium for employment sub-effects.
              </p>
            </div>
            <ul style={{margin:0, padding:'0 0 0 18px', display:'grid', gap:8}}>
              {['Fiscal transmission confirmed via bootstrap (n=1000)', 'Household survey 2024-Q4 used as baseline', 'Counterfactual: no-intervention trend extrapolated'].map(item => (
                <li key={item} style={{fontSize:13, color:'rgba(var(--ink-rgb), 0.72)', lineHeight:1.55}}>{item}</li>
              ))}
            </ul>
          </div>
          <div style={{marginTop:'auto'}}>
            <p style={{fontFamily:'"IBM Plex Mono",monospace', fontSize:9, letterSpacing:'0.1em', textTransform:'uppercase', color:'rgba(var(--ink-rgb), 0.45)', marginBottom:8}}>Provenance</p>
            <div style={{display:'flex', flexWrap:'wrap', gap:6}}>
              {['World Bank ⟿', 'Ukrstat ⟿', 'IMF ⟿', 'Cabinet Docs ⟿'].map(s => (
                <span key={s} style={{fontFamily:'"IBM Plex Mono",monospace', fontSize:10, color:'rgba(var(--ink-rgb), 0.55)', background:'rgba(var(--ink-rgb), 0.05)', padding:'4px 8px', borderRadius:8}}>{s}</span>
              ))}
            </div>
          </div>
        </Panel>

        {/* Impact */}
        <Panel>
          <PanelHeader eyebrow="Distribution Impact" title="Quintile Effects" />
          <div style={{display:'grid', gap:12, marginBottom:16}}>
            {[
              { label:'Q1 (lowest)',  pct:8.2,  color:'var(--teal-vibrant)', dir:1 },
              { label:'Q2',          pct:5.1,  color:'var(--teal-vibrant)', dir:1 },
              { label:'Q3 (median)', pct:3.4,  color:'var(--teal-vibrant)', dir:1 },
              { label:'Q4',          pct:1.8,  color:'var(--gold-vibrant)', dir:1 },
              { label:'Q5 (highest)',pct:2.1,  color:'var(--ember-vibrant)', dir:-1 },
            ].map(b => <ImpactBar key={b.label} {...b} />)}
          </div>
          <div style={{background:'rgba(var(--white-rgb), 0.56)', border:'1px solid rgba(var(--ink-rgb), 0.07)', borderRadius:16, padding:'12px 14px', marginTop:8}}>
            <p style={{fontFamily:'"IBM Plex Mono",monospace', fontSize:9, letterSpacing:'0.1em', textTransform:'uppercase', color:'rgba(var(--ink-rgb), 0.5)', marginBottom:8}}>Uncertainty Band · CI 80%</p>
            <div style={{display:'flex', gap:6}}>
              <div style={{height:10, flex:1, borderRadius:999, background:'rgba(var(--teal-vibrant-rgb), 0.25)'}} />
              <div style={{height:10, flex:2, borderRadius:999, background:'rgba(var(--teal-vibrant-rgb), 0.15)'}} />
              <div style={{height:10, flex:3, borderRadius:999, background:'rgba(var(--teal-vibrant-rgb), 0.06)'}} />
            </div>
            <div style={{display:'flex', justifyContent:'space-between', marginTop:4}}>
              <span style={{fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:'rgba(var(--ink-rgb), 0.45)'}}>CI 50%</span>
              <span style={{fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:'rgba(var(--ink-rgb), 0.45)'}}>CI 80%</span>
              <span style={{fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:'rgba(var(--ink-rgb), 0.45)'}}>CI 95%</span>
            </div>
          </div>
        </Panel>

        {/* Governance */}
        <div style={{display:'grid', gap:18, alignContent:'start'}}>
          <Panel>
            <PanelHeader eyebrow="Governance" title="Pass Registry" />
            <div>
              <GovItem glyph="governance-pass" label="Evidence Gate"   status="pass"   note="CI≥80% verified" />
              <GovItem glyph="governance-pass" label="Causal ID"       status="pass"   note="Identified set confirmed" />
              <GovItem glyph="freshness"        label="Data Freshness"  status="review" note="IMF feed 8d stale" />
              <GovItem glyph="transport"        label="Transportability" status="pass"  note="UA context scored" />
              <GovItem glyph="blocker"          label="GDPR Scope"     status="fail"   note="PII flagged in Q5" />
            </div>
          </Panel>
          <Panel>
            <PanelHeader eyebrow="Timeline" title="Run History" />
            <div style={{display:'grid', gap:0}}>
              {[
                { time:'09:41', event:'Run completed'},
                { time:'09:40', event:'Governance passes run'},
                { time:'09:38', event:'JAX execution started'},
                { time:'09:37', event:'Compiled — 12 plans'},
              ].map((e,i) => (
                <div key={i} style={{display:'grid', gridTemplateColumns:'52px 1fr', gap:12, padding:'10px 0', borderTop: i>0 ? '1px solid rgba(var(--ink-rgb), 0.08)' : 'none'}}>
                  <span style={{fontFamily:'"IBM Plex Mono",monospace', fontSize:11, color:'rgba(var(--ink-rgb), 0.45)'}}>{e.time}</span>
                  <span style={{fontSize:13, color:'rgba(var(--ink-rgb), 0.72)'}}>{e.event}</span>
                </div>
              ))}
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { RunDetailScreen });
