// SchemaMigration.jsx — B3
// Schema migration storyboard: versions as chapters, diff + downstream impact, replay
// Exports: SchemaMigrationScreen

const SCHEMA_VERSIONS = [
  {
    id:'v1.0', label:'v1.0', date:'2023-01-15', title:'Initial schema',
    desc:'Base fact table for fiscal policy evaluation. Six foundational columns.',
    runCount:0, downstreamRuns:0,
    changes:[
      { op:'init', col:'id',               dtype:'INTEGER',      note:'NOT NULL, PRIMARY KEY' },
      { op:'init', col:'policy_id',         dtype:'VARCHAR(64)',  note:'NOT NULL, FK policies' },
      { op:'init', col:'region_code',       dtype:'VARCHAR(16)',  note:'ISO 3166-2 region code' },
      { op:'init', col:'amount',            dtype:'FLOAT',        note:'Disbursement amount' },
      { op:'init', col:'legacy_id',         dtype:'INTEGER',      note:'Legacy system reference' },
      { op:'init', col:'recorded_at',       dtype:'TIMESTAMPTZ',  note:'NOT NULL' },
    ],
  },
  {
    id:'v1.1', label:'v1.1', date:'2023-03-28', title:'Add income quartile',
    desc:'Added income_quartile to enable heterogeneous effect analysis.',
    runCount:847, downstreamRuns:12,
    changes:[
      { op:'unchanged', col:'id',           dtype:'INTEGER',      note:'' },
      { op:'unchanged', col:'policy_id',    dtype:'VARCHAR(64)',  note:'' },
      { op:'unchanged', col:'region_code',  dtype:'VARCHAR(16)',  note:'' },
      { op:'unchanged', col:'amount',       dtype:'FLOAT',        note:'' },
      { op:'add', col:'income_quartile',    dtype:'SMALLINT',     note:'1–4, nullable' },
      { op:'unchanged', col:'legacy_id',    dtype:'INTEGER',      note:'' },
      { op:'unchanged', col:'recorded_at',  dtype:'TIMESTAMPTZ',  note:'' },
    ],
  },
  {
    id:'v1.2', label:'v1.2', date:'2023-07-11', title:'Rename region column',
    desc:'region_code renamed to municipality_id for NUTS-3 alignment. Breaking change for 3 downstream consumers.',
    runCount:1204, downstreamRuns:31,
    changes:[
      { op:'unchanged', col:'id',              dtype:'INTEGER',     note:'' },
      { op:'unchanged', col:'policy_id',       dtype:'VARCHAR(64)', note:'' },
      { op:'rename',    col:'municipality_id', dtype:'VARCHAR(24)', note:'was: region_code (VARCHAR 16)' },
      { op:'unchanged', col:'amount',          dtype:'FLOAT',       note:'' },
      { op:'unchanged', col:'income_quartile', dtype:'SMALLINT',    note:'' },
      { op:'unchanged', col:'legacy_id',       dtype:'INTEGER',     note:'' },
      { op:'unchanged', col:'recorded_at',     dtype:'TIMESTAMPTZ', note:'' },
    ],
  },
  {
    id:'v2.0', label:'v2.0', date:'2023-11-05', title:'Partition key + soft-deprecate legacy_id',
    desc:'Added fiscal_year partition key for query performance. legacy_id marked SOFT DEPRECATED — still readable.',
    runCount:2891, downstreamRuns:58,
    changes:[
      { op:'unchanged', col:'id',              dtype:'INTEGER',     note:'' },
      { op:'unchanged', col:'policy_id',       dtype:'VARCHAR(64)', note:'' },
      { op:'unchanged', col:'municipality_id', dtype:'VARCHAR(24)', note:'' },
      { op:'unchanged', col:'amount',          dtype:'FLOAT',       note:'' },
      { op:'unchanged', col:'income_quartile', dtype:'SMALLINT',    note:'' },
      { op:'add',       col:'fiscal_year',     dtype:'DATE',        note:'PARTITION KEY · NOT NULL' },
      { op:'deprecate', col:'legacy_id',       dtype:'INTEGER',     note:'SOFT DEPRECATED — reads still work' },
      { op:'unchanged', col:'recorded_at',     dtype:'TIMESTAMPTZ', note:'' },
    ],
  },
  {
    id:'v2.1', label:'v2.1', date:'2024-02-20', title:'Precision fix on amount',
    desc:'Changed amount from FLOAT to DECIMAL(14,2) to eliminate rounding errors in fiscal calculations.',
    runCount:1547, downstreamRuns:44,
    changes:[
      { op:'unchanged', col:'id',              dtype:'INTEGER',        note:'' },
      { op:'unchanged', col:'policy_id',       dtype:'VARCHAR(64)',    note:'' },
      { op:'unchanged', col:'municipality_id', dtype:'VARCHAR(24)',    note:'' },
      { op:'modify',    col:'amount',          dtype:'DECIMAL(14,2)',  note:'was: FLOAT — precision fix' },
      { op:'unchanged', col:'income_quartile', dtype:'SMALLINT',       note:'' },
      { op:'unchanged', col:'fiscal_year',     dtype:'DATE',           note:'' },
      { op:'deprecate', col:'legacy_id',       dtype:'INTEGER',        note:'SOFT DEPRECATED' },
      { op:'unchanged', col:'recorded_at',     dtype:'TIMESTAMPTZ',    note:'' },
    ],
  },
  {
    id:'v3.0', label:'v3.0', date:'2024-09-01', title:'Remove legacy_id (hard migration)',
    desc:'legacy_id column permanently removed. 23 downstream runs on v2.x must be re-processed.',
    runCount:3102, downstreamRuns:0,
    changes:[
      { op:'unchanged', col:'id',              dtype:'INTEGER',       note:'' },
      { op:'unchanged', col:'policy_id',       dtype:'VARCHAR(64)',   note:'' },
      { op:'unchanged', col:'municipality_id', dtype:'VARCHAR(24)',   note:'' },
      { op:'unchanged', col:'amount',          dtype:'DECIMAL(14,2)', note:'' },
      { op:'unchanged', col:'income_quartile', dtype:'SMALLINT',      note:'' },
      { op:'unchanged', col:'fiscal_year',     dtype:'DATE',          note:'' },
      { op:'remove',    col:'legacy_id',       dtype:'INTEGER',       note:'REMOVED — 23 runs require reprocessing' },
      { op:'unchanged', col:'recorded_at',     dtype:'TIMESTAMPTZ',   note:'' },
    ],
  },
];

const OP_CFG = {
  init:      { symbol:'◆', color:'var(--teal)', bg:'rgba(var(--teal-rgb), 0.11)',  label:'INIT'     },
  add:       { symbol:'+', color:'var(--teal)', bg:'rgba(var(--teal-rgb), 0.11)',  label:'ADD'      },
  rename:    { symbol:'~', color:'var(--gold-vibrant)', bg:'rgba(var(--gold-vibrant-rgb), 0.12)',label:'RENAME'   },
  modify:    { symbol:'~', color:'var(--gold-vibrant)', bg:'rgba(var(--gold-vibrant-rgb), 0.12)',label:'MODIFY'   },
  deprecate: { symbol:'⚠', color:'var(--gold-vibrant)', bg:'rgba(var(--gold-vibrant-rgb), 0.12)',label:'DEPREC.'  },
  remove:    { symbol:'−', color:'var(--ember)', bg:'rgba(var(--ember-rgb), 0.12)', label:'REMOVE'   },
  unchanged: { symbol:'=', color:'rgba(var(--slate-rgb), 0.45)', bg:'transparent', label:''       },
};

function SchemaMigrationScreen() {
  const [selectedIdx, setSelectedIdx] = React.useState(0);
  const [replaying,   setReplaying]   = React.useState(false);
  const replayRef                     = React.useRef(null);

  const version = SCHEMA_VERSIONS[selectedIdx];

  function startReplay() {
    setReplaying(true);
    setSelectedIdx(0);
    let i = 0;
    replayRef.current = setInterval(() => {
      i++;
      if (i >= SCHEMA_VERSIONS.length) {
        clearInterval(replayRef.current);
        setReplaying(false);
      } else {
        setSelectedIdx(i);
      }
    }, 900);
  }

  React.useEffect(() => () => clearInterval(replayRef.current), []);

  const totalRuns = SCHEMA_VERSIONS.reduce((s, v) => s + v.runCount, 0);

  return (
    <div style={{ display:'flex', gap:20, height:'100%' }}>

      {/* Chapter list */}
      <div style={{ width:200, flexShrink:0, display:'flex', flexDirection:'column', gap:8 }}>
        <Eyebrow style={{ marginBottom:4 }}>B3 · Migration Storyboard</Eyebrow>

        {SCHEMA_VERSIONS.map((v, idx) => {
          const isSel = selectedIdx === idx;
          const hasChanges = v.changes.some(c => c.op !== 'unchanged' && c.op !== 'init');
          const hasDanger  = v.changes.some(c => c.op === 'remove');
          const hasWarn    = v.changes.some(c => c.op === 'deprecate' || c.op === 'rename' || c.op === 'modify');
          const chColor = hasDanger ? 'var(--ember)' : hasWarn ? 'var(--gold-vibrant)' : 'var(--teal)';
          const chBg    = hasDanger ? 'rgba(var(--ember-rgb), 0.1)' : hasWarn ? 'rgba(var(--gold-vibrant-rgb), 0.1)' : 'rgba(var(--teal-rgb), 0.1)';

          return (
            <InteractiveCard key={v.id} onClick={() => setSelectedIdx(idx)} selected={isSel}
              ariaLabel={`Select schema version ${v.label}. ${v.title}.`}
              style={{
                padding:'10px 12px', borderRadius:13, cursor:'pointer',
                background: isSel ? chBg : 'rgba(var(--white-rgb), 0.5)',
                border: `1.5px solid ${isSel ? chColor : 'rgba(var(--ink-rgb), 0.08)'}`,
                transition:'all 140ms',
              }}>
              <div style={{ display:'flex', justifyContent:'space-between', marginBottom:3 }}>
                <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, fontWeight:700, color:isSel ? chColor:'var(--slate)' }}>{v.label}</span>
                <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:8, color:'rgba(var(--slate-rgb), 0.55)' }}>{v.date.slice(0,7)}</span>
              </div>
              <div style={{ fontSize:11, fontWeight:600, color:'var(--ink)', lineHeight:1.3 }}>{v.title}</div>
              {v.runCount > 0 && (
                <div style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:8, color:'rgba(var(--slate-rgb), 0.55)', marginTop:3 }}>
                  {v.runCount.toLocaleString()} runs on this version
                </div>
              )}
            </InteractiveCard>
          );
        })}

        {/* Replay */}
        <Button
          variant={replaying ? 'danger' : 'ghost'} size="sm"
          onClick={() => replaying ? (clearInterval(replayRef.current), setReplaying(false)) : startReplay()}
          style={{ marginTop:8 }}
        >
          {replaying ? '■ Stop' : '▶ Replay'}
        </Button>

        {/* Progress */}
        {replaying && (
          <div style={{ height:4, borderRadius:999, background:'rgba(var(--ink-rgb), 0.08)', overflow:'hidden' }}>
            <div style={{ height:'100%', background:'var(--teal-vibrant)', borderRadius:999,
              width:`${((selectedIdx+1)/SCHEMA_VERSIONS.length*100).toFixed(0)}%`,
              transition:'width 400ms' }} />
          </div>
        )}
      </div>

      {/* Diff view */}
      <div style={{ flex:1, minWidth:0, display:'flex', flexDirection:'column', gap:12 }}>

        <Panel style={{ padding:'14px 18px' }}>
          <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between' }}>
            <div>
              <div style={{ display:'flex', gap:8, alignItems:'center', marginBottom:4 }}>
                <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, fontWeight:700, color:'var(--slate)', letterSpacing:'0.08em' }}>
                  {version.label} · {version.date}
                </span>
              </div>
              <h3 style={{ margin:0, fontSize:20, fontWeight:800, letterSpacing:'-0.03em' }}>{version.title}</h3>
              <p style={{ margin:'4px 0 0', fontSize:13, color:'var(--slate)', lineHeight:1.5 }}>{version.desc}</p>
            </div>
            {version.runCount > 0 && (
              <div style={{ textAlign:'center', padding:'8px 14px', borderRadius:14, background:'rgba(var(--white-rgb), 0.55)', border:'1px solid rgba(var(--ink-rgb), 0.08)', flexShrink:0 }}>
                <div style={{ fontSize:22, fontWeight:800, letterSpacing:'-0.04em', color:'var(--ink)' }}>{version.runCount.toLocaleString()}</div>
                <div style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.7)' }}>RUNS ON THIS VERSION</div>
              </div>
            )}
          </div>
        </Panel>

        {/* Diff table */}
        <Panel style={{ flex:1, padding:'14px 0', overflow:'auto' }}>
          <div style={{ padding:'0 18px', marginBottom:12 }}>
            <Eyebrow>Schema diff</Eyebrow>
          </div>
          <div style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:12 }}>
            {version.changes.map((ch, i) => {
              const cfg = OP_CFG[ch.op];
              if (ch.op === 'unchanged') {
                return (
                  <div key={i} style={{ display:'flex', gap:0, padding:'6px 18px', opacity:0.45 }}>
                    <span style={{ width:20, color:'var(--slate)', flexShrink:0 }}>=</span>
                    <span style={{ width:200, color:'var(--slate)' }}>{ch.col}</span>
                    <span style={{ width:160, color:'var(--slate)' }}>{ch.dtype}</span>
                    <span style={{ color:'rgba(var(--slate-rgb), 0.5)', fontSize:11 }}>{ch.note}</span>
                  </div>
                );
              }
              return (
                <div key={i} style={{
                  display:'flex', gap:0, padding:'7px 18px',
                  background: cfg.bg,
                  borderLeft: `3px solid ${cfg.color}`,
                  marginBottom:2,
                }}>
                  <span style={{ width:20, color:cfg.color, fontWeight:700, flexShrink:0 }}>{cfg.symbol}</span>
                  <span style={{ width:200, color:cfg.color, fontWeight:700 }}>{ch.col}</span>
                  <span style={{ width:160, color:cfg.color }}>{ch.dtype}</span>
                  <span style={{ color: ch.op==='remove'?'var(--ember)':ch.op==='deprecate'?'var(--gold-vibrant)':'rgba(var(--slate-rgb), 0.8)', fontSize:11 }}>
                    {ch.note}
                  </span>
                </div>
              );
            })}
          </div>

          {/* Impact note */}
          {version.downstreamRuns > 0 && (
            <div style={{ margin:'16px 18px 0', padding:'10px 14px', borderRadius:12,
              background:'rgba(var(--ember-rgb), 0.08)', border:'1px solid rgba(var(--ember-rgb), 0.2)' }}>
              <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, fontWeight:700, color:'var(--ember)', letterSpacing:'0.06em' }}>DOWNSTREAM IMPACT</span>
              <p style={{ margin:'4px 0 0', fontSize:12, color:'var(--ember)', lineHeight:1.5 }}>
                {version.downstreamRuns} downstream runs depended on the previous schema version and require migration or re-processing.
              </p>
            </div>
          )}
        </Panel>
      </div>

      {/* Stats panel */}
      <div style={{ width:200, flexShrink:0 }}>
        <Panel style={{ height:'100%' }}>
          <Eyebrow style={{ marginBottom:10 }}>Change legend</Eyebrow>
          {Object.entries(OP_CFG).filter(([k]) => k !== 'unchanged').map(([key, cfg]) => (
            <div key={key} style={{ display:'flex', alignItems:'center', gap:8, marginBottom:8 }}>
              <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:12, color:cfg.color, fontWeight:700, width:16 }}>{cfg.symbol}</span>
              <span style={{ fontSize:11, color:cfg.color, fontWeight:600 }}>{cfg.label}</span>
            </div>
          ))}
          <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', margin:'14px 0' }} />
          <Eyebrow style={{ marginBottom:8 }}>Cumulative runs</Eyebrow>
          <div style={{ fontSize:24, fontWeight:800, letterSpacing:'-0.04em', color:'var(--teal)' }}>
            {totalRuns.toLocaleString()}
          </div>
          <div style={{ fontSize:10, color:'rgba(var(--slate-rgb), 0.7)', marginTop:2 }}>across {SCHEMA_VERSIONS.length} schema versions</div>
          <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', margin:'14px 0' }} />
          <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
            {SCHEMA_VERSIONS.map((v, i) => (
              <div key={v.id} style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color: i===selectedIdx?'var(--teal)':'rgba(var(--slate-rgb), 0.5)', fontWeight: i===selectedIdx?700:400 }}>{v.label}</span>
                <div style={{ flex:1, height:3, borderRadius:999, background:'rgba(var(--ink-rgb), 0.07)', margin:'0 8px', overflow:'hidden' }}>
                  <div style={{ height:'100%', background: i===selectedIdx?'var(--teal-vibrant)':'rgba(var(--slate-rgb), 0.3)', borderRadius:999,
                    width:`${(v.runCount/Math.max(...SCHEMA_VERSIONS.map(v=>v.runCount))*100).toFixed(0)}%` }} />
                </div>
                <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, color:'rgba(var(--slate-rgb), 0.55)' }}>{v.runCount>0?v.runCount.toLocaleString():'—'}</span>
              </div>
            ))}
          </div>
        </Panel>
      </div>
    </div>
  );
}

Object.assign(window, { SchemaMigrationScreen });
