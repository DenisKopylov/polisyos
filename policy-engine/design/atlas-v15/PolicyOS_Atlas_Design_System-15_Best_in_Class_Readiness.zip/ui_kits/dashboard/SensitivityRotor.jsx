// SensitivityRotor.jsx — A3
// Global E-value "steering wheel": rotate to tighten, watch findings extinguish
// Exports: SensitivityRotorScreen

const A3_CLAIMS = [
  { id:'c1', text:'Fiscal policy reduces poverty rate',           detail:'β = −0.043 (95% CI −0.067 to −0.019)',       ev:3.8, decision:true  },
  { id:'c2', text:'Employment effect is positive',               detail:'β = 0.41 (95% CI 0.28 to 0.54)',              ev:2.9, decision:true  },
  { id:'c3', text:'Tax revenue increases significantly',         detail:'β = 0.18 (95% CI 0.11 to 0.25)',              ev:4.2, decision:true  },
  { id:'c4', text:'Spending mediates 62% of effect',            detail:'Mediation ratio 0.62 (bootstrap 0.48–0.76)',   ev:1.8, decision:true  },
  { id:'c5', text:'Effect persists beyond 3 years',             detail:'Decay −0.008/yr (p = 0.12, ns)',               ev:1.4, decision:false },
  { id:'c6', text:'Stronger effect in low-income cohort',       detail:'CATE ratio 1.34 vs Q4 (p = 0.03)',            ev:2.1, decision:true  },
  { id:'c7', text:'No adverse geographic spillovers',           detail:'Spillover coeff 0.002 (ns)',                   ev:1.2, decision:false },
  { id:'c8', text:'IV first stage is strong (F = 24.3)',        detail:'Cragg-Donald F = 24.3 (threshold 10)',         ev:8.1, decision:false },
  { id:'c9', text:'Confounder bias bounded below ATE',          detail:'Bias bound 0.81× ATE (E-value 2.6)',           ev:2.6, decision:true  },
];

const EV_MIN = 1.0, EV_MAX = 5.5;
// Arc geometry (math coords, Y-up convention → SVG uses cy - R*sin(θ))
const ARC_START = 220, ARC_SWEEP = 260; // degrees

function arcPt(angleDeg, cx, cy, R) {
  const r = angleDeg * Math.PI / 180;
  return { x: cx + R * Math.cos(r), y: cy - R * Math.sin(r) };
}

function evToT(ev) { return Math.max(0, Math.min(1, (ev - EV_MIN) / (EV_MAX - EV_MIN))); }
function tToEv(t)  { return EV_MIN + t * (EV_MAX - EV_MIN); }
function tToAngle(t) { return ARC_START - t * ARC_SWEEP; } // decreasing angle = clockwise on screen

function arcPath(t, cx, cy, R) {
  const startPt  = arcPt(ARC_START, cx, cy, R);
  const thumbAng = tToAngle(t);
  const endPt    = arcPt(thumbAng, cx, cy, R);
  const span     = ARC_START - thumbAng; // always positive going clockwise
  if (span < 0.5) return `M ${startPt.x} ${startPt.y}`; // too short, skip
  const large = span > 180 ? 1 : 0;
  return `M ${startPt.x.toFixed(2)} ${startPt.y.toFixed(2)} A ${R} ${R} 0 ${large} 1 ${endPt.x.toFixed(2)} ${endPt.y.toFixed(2)}`;
}

function fullTrackPath(cx, cy, R) {
  const s = arcPt(ARC_START, cx, cy, R);
  const e = arcPt(ARC_START - ARC_SWEEP, cx, cy, R);
  return `M ${s.x.toFixed(2)} ${s.y.toFixed(2)} A ${R} ${R} 0 1 1 ${e.x.toFixed(2)} ${e.y.toFixed(2)}`;
}

function SensitivityRotorScreen() {
  const [ev, setEv]             = React.useState(1.8);
  const [dragging, setDragging] = React.useState(false);
  const svgRef                  = React.useRef(null);

  // Derived
  const t         = evToT(ev);
  const thumbAng  = tToAngle(t);
  const surviving = A3_CLAIMS.filter(c => c.ev >= ev);
  const decisionSurviving = surviving.filter(c => c.decision);
  const totalDecision = A3_CLAIMS.filter(c => c.decision).length;

  // Dial geometry
  const CX = 180, CY = 175, R_OUTER = 130, R_INNER = 88, R_THUMB = 145;
  const thumbPt = arcPt(thumbAng, CX, CY, R_THUMB);

  function getAngleFromMouse(e) {
    if (!svgRef.current) return null;
    const rect = svgRef.current.getBoundingClientRect();
    const VBW = 360, VBH = 340;
    const mx = (e.clientX - rect.left) / rect.width  * VBW - CX;
    const my = -((e.clientY - rect.top)  / rect.height * VBH - CY); // flip Y
    return Math.atan2(my, mx) * 180 / Math.PI;
  }

  function angleToEv(angleDeg) {
    // clamp to arc range [ARC_START - ARC_SWEEP, ARC_START]
    let a = angleDeg;
    // normalize to arc: t = (ARC_START - a) / ARC_SWEEP
    let tVal = (ARC_START - a) / ARC_SWEEP;
    tVal = Math.max(0, Math.min(1, tVal));
    return tToEv(tVal);
  }

  function onSVGPointerDown(e) {
    e.preventDefault();
    setDragging(true);
    const angle = getAngleFromMouse(e);
    if (angle !== null) {
      const newEv = angleToEv(angle);
      if (newEv >= EV_MIN && newEv <= EV_MAX) setEv(newEv);
    }
  }

  function onSVGPointerMove(e) {
    if (!dragging) return;
    const angle = getAngleFromMouse(e);
    if (angle !== null) {
      // Clamp to valid arc region
      const tVal = Math.max(0, Math.min(1, (ARC_START - angle) / ARC_SWEEP));
      setEv(tToEv(tVal));
    }
  }

  function onSVGPointerUp() { setDragging(false); }

  // Tick marks
  const ticks = [1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0, 5.5];

  return (
    <div style={{ display:'flex', gap:20, height:'100%' }}>

      {/* Rotor panel */}
      <Panel style={{ width:390, flexShrink:0, display:'flex', flexDirection:'column', alignItems:'center' }}>
        <PanelHeader eyebrow="A3 · Sensitivity Rotor" title="E-value threshold" />

        <svg
          ref={svgRef}
          viewBox="0 0 360 340"
          style={{ width:'100%', maxWidth:360, cursor: dragging ? 'grabbing':'grab', touchAction:'none', userSelect:'none' }}
          onPointerDown={onSVGPointerDown}
          onPointerMove={onSVGPointerMove}
          onPointerUp={onSVGPointerUp}
          onPointerLeave={onSVGPointerUp}
        >
          <defs>
            <filter id="rotor-glow" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="6" result="blur"/>
              <feComposite in="SourceGraphic" in2="blur" operator="over"/>
            </filter>
            <radialGradient id="rg-center" cx="50%" cy="50%" r="50%">
              <stop offset="0%"   stopColor="rgba(var(--white-rgb), 0.12)" />
              <stop offset="100%" stopColor="rgba(var(--teal-rgb), 0.06)"   />
            </radialGradient>
          </defs>

          {/* Background fill */}
          <circle cx={CX} cy={CY} r={R_OUTER} fill="url(#rg-center)" stroke="none" />

          {/* Track (full arc) */}
          <path d={fullTrackPath(CX, CY, R_OUTER)}
            fill="none" stroke="rgba(var(--ink-rgb), 0.1)" strokeWidth={10}
            strokeLinecap="round" />

          {/* Active arc glow */}
          <path d={arcPath(t, CX, CY, R_OUTER)}
            fill="none" stroke="rgba(var(--teal-vibrant-rgb), 0.25)" strokeWidth={18}
            strokeLinecap="round" filter="url(#rotor-glow)" />

          {/* Active arc */}
          <path d={arcPath(t, CX, CY, R_OUTER)}
            fill="none" stroke="var(--teal-vibrant)" strokeWidth={10}
            strokeLinecap="round" />

          {/* Danger zone arc — where claims extinguish */}
          {t > 0 && (
            <path d={arcPath(evToT(Math.min(ev, EV_MAX)), CX, CY, R_OUTER - 0)}
              fill="none" stroke="rgba(var(--ember-vibrant-rgb), 0.0)" strokeWidth={10} strokeLinecap="round" />
          )}

          {/* Tick marks */}
          {ticks.map(tickEv => {
            const tTick = evToT(tickEv);
            const ang   = tToAngle(tTick);
            const p1 = arcPt(ang, CX, CY, R_OUTER + 6);
            const p2 = arcPt(ang, CX, CY, R_OUTER + 16);
            const lbl = arcPt(ang, CX, CY, R_OUTER + 28);
            const isAlive = tickEv >= ev;
            return (
              <g key={tickEv}>
                <line x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y}
                  stroke={isAlive ? 'rgba(var(--slate-rgb), 0.5)' : 'rgba(var(--ember-vibrant-rgb), 0.6)'}
                  strokeWidth={tickEv % 1 === 0 ? 2 : 1} />
                {tickEv % 1 === 0 && (
                  <text x={lbl.x} y={lbl.y + 4} textAnchor="middle"
                    fontSize={10} fontFamily='"IBM Plex Mono",monospace'
                    fill={isAlive ? 'rgba(var(--slate-rgb), 0.7)' : 'rgba(var(--ember-vibrant-rgb), 0.8)'}
                    fontWeight={600}>{tickEv.toFixed(1)}</text>
                )}
              </g>
            );
          })}

          {/* Threshold indicator lines for each claim */}
          {A3_CLAIMS.map(c => {
            const tClaim = evToT(c.ev);
            const ang    = tToAngle(tClaim);
            const p1     = arcPt(ang, CX, CY, R_INNER);
            const p2     = arcPt(ang, CX, CY, R_OUTER);
            const alive  = c.ev >= ev;
            return (
              <line key={c.id} x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y}
                stroke={alive ? 'rgba(var(--teal-rgb), 0.7)' : 'rgba(var(--ember-vibrant-rgb), 0.4)'}
                strokeWidth={c.decision ? 1.5 : 1}
                strokeDasharray={c.decision ? 'none' : '3 3'} />
            );
          })}

          {/* Inner disc */}
          <circle cx={CX} cy={CY} r={R_INNER}
            fill="rgba(var(--paper-rgb), 0.85)" stroke="rgba(var(--ink-rgb), 0.08)" strokeWidth={1} />

          {/* Center readout */}
          <text x={CX} y={CY - 18} textAnchor="middle"
            fontSize={9} fontFamily='"IBM Plex Mono",monospace'
            letterSpacing={1.5} fill="rgba(var(--slate-rgb), 0.6)" fontWeight={700}>
            E-VALUE
          </text>
          <text x={CX} y={CY + 20} textAnchor="middle"
            fontSize={38} fontFamily='"Manrope",sans-serif'
            fontWeight={800} letterSpacing="-0.04em"
            fill={ev <= 1.5 ? 'var(--teal)' : ev <= 2.5 ? 'var(--gold-vibrant)' : 'var(--ember)'}>
            {ev.toFixed(1)}
          </text>
          <text x={CX} y={CY + 40} textAnchor="middle"
            fontSize={11} fontFamily='"Manrope",sans-serif'
            fill="rgba(var(--slate-rgb), 0.75)">
            threshold
          </text>

          {/* Thumb */}
          <circle cx={thumbPt.x} cy={thumbPt.y} r={11}
            fill="var(--teal-vibrant)" stroke="rgba(var(--white-rgb), 0.9)" strokeWidth={2.5}
            style={{ filter:'drop-shadow(0 2px 6px rgba(var(--teal-vibrant-rgb), 0.4))' }} />
          <circle cx={thumbPt.x} cy={thumbPt.y} r={4}
            fill="white" opacity={0.9} />
        </svg>

        {/* Live summary */}
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, width:'100%', marginTop:4 }}>
          <div style={{ textAlign:'center', padding:'10px 12px', borderRadius:14, background:'rgba(var(--teal-rgb), 0.1)', border:'1px solid rgba(var(--teal-rgb), 0.2)' }}>
            <div style={{ fontSize:24, fontWeight:800, color:'var(--teal)', letterSpacing:'-0.04em' }}>{surviving.length}</div>
            <div style={{ fontSize:10, color:'rgba(var(--teal-rgb), 0.8)', fontFamily:'"IBM Plex Mono",monospace', letterSpacing:'0.06em' }}>SURVIVING</div>
          </div>
          <div style={{ textAlign:'center', padding:'10px 12px', borderRadius:14, background:'rgba(var(--ember-rgb), 0.09)', border:'1px solid rgba(var(--ember-rgb), 0.2)' }}>
            <div style={{ fontSize:24, fontWeight:800, color:'var(--ember)', letterSpacing:'-0.04em' }}>{A3_CLAIMS.length - surviving.length}</div>
            <div style={{ fontSize:10, color:'rgba(var(--ember-rgb), 0.8)', fontFamily:'"IBM Plex Mono",monospace', letterSpacing:'0.06em' }}>EXTINGUISHED</div>
          </div>
        </div>

        <div style={{ marginTop:10, padding:'8px 12px', borderRadius:10, background:'rgba(var(--white-rgb), 0.5)', border:'1px solid rgba(var(--ink-rgb), 0.08)', width:'100%' }}>
          <span style={{ fontSize:11, color:'var(--slate)', lineHeight:1.5 }}>
            <strong style={{ color: decisionSurviving.length < totalDecision ? 'var(--ember)' : 'var(--teal)' }}>
              {decisionSurviving.length}/{totalDecision}
            </strong> decision-bearing findings survive at E ≥ {ev.toFixed(1)}
          </span>
        </div>
      </Panel>

      {/* Claims list */}
      <div style={{ flex:1, minWidth:0, display:'flex', flexDirection:'column', gap:10 }}>
        <Eyebrow style={{ marginBottom:4 }}>Decision-bearing findings</Eyebrow>
        {A3_CLAIMS.map(claim => {
          const alive   = claim.ev >= ev;
          const margin  = claim.ev - ev;
          const tClaim  = evToT(claim.ev);
          return (
            <div key={claim.id} style={{
              padding:'12px 16px', borderRadius:16,
              background: alive ? 'rgba(var(--white-rgb), 0.6)' : 'rgba(var(--ember-rgb), 0.07)',
              border: `1.5px solid ${alive ? 'rgba(var(--ink-rgb), 0.09)' : 'rgba(var(--ember-rgb), 0.25)'}`,
              opacity: alive ? 1 : 0.6,
              transition:'all 200ms ease',
            }}>
              <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', gap:10, marginBottom:6 }}>
                <div style={{ flex:1 }}>
                  <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:3 }}>
                    {claim.decision && (
                      <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:8, fontWeight:700, letterSpacing:'0.08em',
                        color: alive ? 'var(--teal)':'var(--ember)',
                        background: alive ? 'rgba(var(--teal-rgb), 0.1)':'rgba(var(--ember-rgb), 0.1)',
                        padding:'2px 6px', borderRadius:999 }}>DECISION</span>
                    )}
                    <span style={{ fontSize:13, fontWeight:700, color: alive ? 'var(--ink)':'rgba(var(--ink-rgb), 0.45)',
                      textDecoration: alive ? 'none':'line-through', transition:'color 200ms' }}>
                      {claim.text}
                    </span>
                  </div>
                  <div style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, color:'rgba(var(--slate-rgb), 0.7)' }}>
                    {claim.detail}
                  </div>
                </div>
                {/* E-value badge */}
                <div style={{ textAlign:'center', flexShrink:0 }}>
                  <div style={{ fontSize:18, fontWeight:800, letterSpacing:'-0.04em',
                    color: alive ? 'var(--teal)':'var(--ember)', transition:'color 200ms' }}>
                    {claim.ev.toFixed(1)}
                  </div>
                  <div style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.6)' }}>E-VALUE</div>
                </div>
              </div>
              {/* E-value bar */}
              <div style={{ height:4, borderRadius:999, background:'rgba(var(--ink-rgb), 0.08)', overflow:'hidden' }}>
                <div style={{
                  height:'100%', borderRadius:999,
                  background: alive ? 'var(--teal-vibrant)':'var(--ember-vibrant)',
                  width:`${(tClaim * 100).toFixed(1)}%`,
                  position:'relative', transition:'background 200ms, width 200ms',
                }}>
                  {/* Threshold marker */}
                  <div style={{
                    position:'absolute', right:0, top:-2, width:2, height:8,
                    background: alive ? 'var(--teal)':'var(--ember)', borderRadius:1,
                  }} />
                </div>
              </div>
              <div style={{ display:'flex', justifyContent:'space-between', marginTop:3 }}>
                <span style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.5)' }}>
                  E=1.0
                </span>
                <span style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace',
                  color: alive ? 'rgba(var(--teal-rgb), 0.7)':'rgba(var(--ember-rgb), 0.7)' }}>
                  {alive ? `+${margin.toFixed(1)} margin` : `−${Math.abs(margin).toFixed(1)} below threshold`}
                </span>
                <span style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.5)' }}>
                  E=5.5
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

Object.assign(window, { SensitivityRotorScreen });
