// Sidebar.jsx — Atlas responsive sidebar rail
// Exports: Sidebar, ATLAS_DASHBOARD_NAV_ITEMS
// Accessibility: native nav buttons, unique route ids, aria-current, radical-only glyph anchors.

const ATLAS_DASHBOARD_NAV_ITEMS = [
  { id: 'dashboard',          label: 'Command Center',      anchor: '⊙' },
  { id: 'composer',           label: 'Scenario Composer',   anchor: '≔' },
  { id: 'decision',           label: 'Decision Workspace',  anchor: '⟿' },
  { id: 'evidence_fabric',    label: 'Evidence Fabric',     anchor: '▲' },
  { id: 'causal',             label: 'Causal Atlas',        anchor: '⟿' },
  { id: 'identifi',           label: 'Identifiability',     anchor: '≔' },
  { id: 'rotor',              label: 'Sensitivity Rotor',   anchor: '⋌' },
  { id: 'cohort',             label: 'Cohort Traveler',     anchor: '⇄' },
  { id: 'theatre',            label: 'Stress-Test Theatre', anchor: '⊘' },
  { id: 'freshness',          label: 'Freshness Braid',     anchor: '◷' },
  { id: 'connectors',         label: 'Connector Cards',     anchor: '▲' },
  { id: 'schema',             label: 'Schema Storyboard',   anchor: '⟳' },
  { id: 'quality',            label: 'Quality Budget',      anchor: '⊡' },
  { id: 'drift',              label: 'Profile Drift',       anchor: '◷' },
  { id: 'lineage',            label: 'Lineage Gravity',     anchor: '⟿' },
  { id: 'disputes',           label: 'Dispute Ledger',      anchor: '⊘' },
  { id: 'lens',               label: 'Stakeholder Lens',    anchor: '⇄' },
  { id: 'fairness',           label: 'Fairness Audit',      anchor: '⊡' },
  { id: 'embargo',            label: 'Embargo Manager',     anchor: '⊘' },
  { id: 'provenance',         label: 'Provenance Cert.',    anchor: '⟿' },
  { id: 'choreography',       label: 'Run Choreography',    anchor: '⟳' },
  { id: 'livemonitor',        label: 'Live Run Monitor',    anchor: '◷' },
  { id: 'triage',             label: 'Failure Triage',      anchor: '⊘' },
  { id: 'capacity',           label: 'Capacity Planner',    anchor: '⊙' },
  { id: 'opsaudit',           label: 'Ops Audit Trail',     anchor: '⟿' },
  { id: 'argmap',             label: 'Argument Map',        anchor: '▲' },
  { id: 'reasoning',          label: 'Reasoning Chain',     anchor: '≔' },
  { id: 'uncertainty',        label: 'Uncertainty Decomp.', anchor: '⋌' },
  { id: 'counterfact',        label: 'Counterfactual',      anchor: '⋌' },
  { id: 'evidence_synthesis', label: 'Evidence Synthesis',  anchor: '▲' },
];

function Sidebar({ activeScreen, onNavigate, labelledBy, id = 'atlas-dashboard-navigation', modal = false, open = true, onClose }) {
  const hiddenWhenClosed = modal && !open;
  return (
    <aside
      id={id}
      className="atlas-dashboard-rail"
      data-modal={modal ? 'true' : undefined}
      data-open={open ? 'true' : 'false'}
      aria-hidden={hiddenWhenClosed ? 'true' : undefined}
      inert={hiddenWhenClosed ? '' : undefined}
      aria-label="Atlas product navigation"
      aria-labelledby={labelledBy}
    >
      <div className="atlas-dashboard-brand">
        <div className="atlas-dashboard-brand__row">
          <img src="../../assets/logo-mark-inverse.svg" width={28} height={28} alt="Atlas mark" />
          <img className="atlas-dashboard-brand__wordmark" src="../../assets/logo-atlas-inverse.svg" width={90} height={18} alt="Atlas" />
        </div>
        <p className="atlas-dashboard-brand__note">Policy Simulation Engine</p>
      </div>

      <nav className="atlas-dashboard-nav" aria-label="Primary screens">
        {ATLAS_DASHBOARD_NAV_ITEMS.map(item => {
          const active = activeScreen === item.id;
          return (
            <button
              key={item.id}
              type="button"
              className="atlas-dashboard-nav-link"
              aria-current={active ? 'page' : undefined}
              aria-label={`${item.label}${active ? ', current screen' : ''}`}
              title={item.label}
              onClick={() => { onNavigate?.(item.id); onClose?.(); }}
            >
              <span aria-hidden="true" className="atlas-dashboard-nav-icon">{item.anchor}</span>
              <span className="atlas-dashboard-nav-label">{item.label}</span>
            </button>
          );
        })}
      </nav>

      <section className="atlas-dashboard-status-card" aria-label="System status: all systems nominal. Seven active runs, two blocked.">
        <p className="atlas-dashboard-status-card__eyebrow">System Status</p>
        <div className="atlas-dashboard-status-card__row">
          <span aria-hidden="true" className="atlas-dashboard-status-card__dot" />
          <span className="atlas-dashboard-status-card__value">All systems nominal</span>
        </div>
        <div className="atlas-dashboard-status-card__meta">
          <span>7 active runs</span>
          <span>2 blocked</span>
        </div>
      </section>

      <div className="atlas-dashboard-version" style={{ marginTop:'auto', paddingTop:'var(--space-5)' }}>
        <p className="atlas-dashboard-status-card__eyebrow">v2.4.1 · staging</p>
      </div>
    </aside>
  );
}

Object.assign(window, { Sidebar, ATLAS_DASHBOARD_NAV_ITEMS });
