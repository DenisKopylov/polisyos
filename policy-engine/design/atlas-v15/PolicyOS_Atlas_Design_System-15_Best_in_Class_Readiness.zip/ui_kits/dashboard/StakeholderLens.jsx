// StakeholderLens.jsx — C2
// Same decision packet seen through different stakeholder lenses
// Exports: StakeholderLensScreen

const LENSES = [
  {
    id:'citizen',
    label:'Citizen',
    icon:'○',
    desc:'Plain-language explanation for the individual whose case was decided.',
    color:'var(--teal)',
    bg:'rgba(var(--teal-rgb), 0.10)',
    fields:[
      { label:'Decision', value:'Your application has been approved.', mono:false, prominent:true },
      { label:'Amount',   value:'₴ 18,400 / month', mono:false, prominent:true },
      { label:'Why',      value:'Your income, household size, and employment history qualified you under the Fiscal Reform 2024 programme.', mono:false },
      { label:'Duration', value:'12 months from October 2024', mono:false },
      { label:'Next step',value:'You will receive payment to your registered bank account by 15 Oct 2024.', mono:false },
      { label:'Appeal by',value:'30 October 2024', mono:false },
    ],
    caveats:null,
  },
  {
    id:'caseworker',
    label:'Caseworker',
    icon:'◈',
    desc:'Structured decision summary with eligibility check results and override log.',
    color:'var(--chart-secondary)',
    bg:'rgba(var(--blue-rgb), 0.10)',
    fields:[
      { label:'Decision ID',       value:'D-Q3-001',          mono:true,  prominent:false },
      { label:'Outcome',           value:'APPROVED',           mono:true,  prominent:true, color:'var(--teal)' },
      { label:'Approval tier',     value:'T1 — Full benefit',  mono:false, prominent:false },
      { label:'Eligibility checks',value:'PASS 7/7',           mono:true,  prominent:false },
      { label:'Income check',      value:'PASS — ₴ 38,710 < threshold ₴ 48,000', mono:false },
      { label:'Employment check',  value:'PASS — employed 14+ months', mono:false },
      { label:'Override log',      value:'No overrides applied', mono:true  },
      { label:'Case worker sign-off', value:'Required before Oct 10 2024', mono:false },
    ],
    caveats:'Income data from Employment Registry (36h lag). Re-verify if application date is within lag window.',
  },
  {
    id:'auditor',
    label:'Auditor',
    icon:'◆',
    desc:'Full model attribution, SHAP values, fairness metrics, and provenance hash.',
    color:'var(--gold)',
    bg:'rgba(var(--gold-rgb), 0.10)',
    fields:[
      { label:'Run ID',            value:'fiscal_reform_q2_001',  mono:true },
      { label:'Model version',     value:'fiscal_model_v3.4',     mono:true },
      { label:'Schema version',    value:'v2.1',                  mono:true },
      { label:'Governing lag',     value:'72h (Tax Records)',      mono:true, warn:true },
      { label:'Top SHAP feature',  value:'income_quartile (0.18)', mono:true },
      { label:'Confidence',        value:'0.791',                  mono:true },
      { label:'Fairness — DI',     value:'0.76 (threshold 0.80)', mono:true, warn:true },
      { label:'E-value',           value:'3.8 (min. confounding)', mono:true },
      { label:'Provenance hash',   value:'sha256:4f3c…a8d1',      mono:true },
    ],
    caveats:'Disparate impact 0.76 is below the 0.80 threshold. Flagged for fairness review. Decision stands pending review.',
  },
  {
    id:'regulator',
    label:'Regulator',
    icon:'⬟',
    desc:'EU AI Act compliance view: risk tier, transparency obligations, human oversight log.',
    color:'var(--ember)',
    bg:'rgba(var(--ember-rgb), 0.10)',
    fields:[
      { label:'Risk classification', value:'HIGH RISK — Art. 6 Annex III', mono:true, warn:true },
      { label:'Transparency req.',   value:'COMPLIANT — explanation provided', mono:false },
      { label:'Human oversight',     value:'REQUIRED — caseworker sign-off logged', mono:false },
      { label:'Training data reg.',  value:'DOCUMENTED — Data Card v3.4', mono:false },
      { label:'Fairness monitoring', value:'ACTIVE — quarterly audit cycle', mono:false },
      { label:'Accuracy logging',    value:'COMPLIANT — prediction log retained 7yr', mono:false },
      { label:'Incident log',        value:'DSP-2024-041 (resolved 2024-09-18)', mono:true },
      { label:'Next audit date',     value:'2025-01-15', mono:true },
    ],
    caveats:'Fairness flag DSP-2024-041 must appear in regulator report per Art. 26(5).',
  },
  {
    id:'policy_maker',
    label:'Policy Maker',
    icon:'◎',
    desc:'Aggregate outcome statistics and causal attribution for policy evaluation.',
    color:'var(--teal)',
    bg:'rgba(var(--teal-rgb), 0.08)',
    fields:[
      { label:'Cohort approved',   value:'20,337 / 42,180 (48.2%)', mono:false, prominent:true },
      { label:'Avg. benefit',      value:'₴ 17,840 / month',        mono:false, prominent:true },
      { label:'ATE on poverty',    value:'−0.043 pp (E-val 3.8)',   mono:true  },
      { label:'ATE on employment', value:'+0.41 pp (E-val 2.9)',    mono:true  },
      { label:'Fiscal cost',       value:'₴ 4.82B / quarter',       mono:false },
      { label:'Cost per poverty pp', value:'₴ 112M / pp reduction', mono:false },
      { label:'Scenario',          value:'v3.4 · 2024-Q3',          mono:true  },
    ],
    caveats:'ATE estimates from back-door adjustment. Sensitivity to unmeasured confounders at E=3.8.',
  },
];

const DECISION_HEADER = {
  id:'D-Q3-001', run:'fiscal_reform_q2_001', date:'2024-09-30',
  applicant:'Citizen #C-2024-18440', amount:'₴ 18,400', outcome:'APPROVED',
};

function LensField({ field }) {
  const warn = field.warn;
  const color = field.color || (warn ? 'var(--ember)' : field.mono ? 'var(--slate)' : 'var(--ink)');
  return (
    <div style={{ display:'flex', flexDirection:'column', gap:2, padding:'9px 12px',
      borderRadius:12, marginBottom:7,
      background: warn ? 'rgba(var(--ember-rgb), 0.07)' : 'rgba(var(--white-rgb), 0.5)',
      border:`1px solid ${warn ? 'rgba(var(--ember-rgb), 0.2)' : 'rgba(var(--ink-rgb), 0.07)'}` }}>
      <span style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', letterSpacing:'0.1em',
        color:'rgba(var(--slate-rgb), 0.6)', textTransform:'uppercase' }}>{field.label}</span>
      <span style={{
        fontSize: field.prominent ? 16 : (field.mono ? 12 : 13),
        fontWeight: field.prominent ? 800 : (field.mono ? 500 : 600),
        fontFamily: field.mono ? '"IBM Plex Mono",monospace' : '"Manrope",sans-serif',
        color, letterSpacing: field.prominent ? '-0.03em' : field.mono ? '0.02em' : 'normal',
        lineHeight:1.4,
      }}>{field.value}</span>
    </div>
  );
}

function StakeholderLensScreen() {
  const [activeLens, setActiveLens] = React.useState('citizen');
  const lens = LENSES.find(l => l.id === activeLens);

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:14, height:'100%' }}>

      {/* Decision packet header */}
      <Panel style={{ padding:'14px 20px' }}>
        <div style={{ display:'flex', alignItems:'center', gap:20 }}>
          <div>
            <Eyebrow style={{ marginBottom:3 }}>C2 · Stakeholder Lens Switcher</Eyebrow>
            <div style={{ display:'flex', alignItems:'center', gap:10 }}>
              <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:13, fontWeight:700, color:'var(--teal)' }}>{DECISION_HEADER.id}</span>
              <Badge kind="ok">APPROVED</Badge>
              <span style={{ fontSize:13, color:'var(--slate)' }}>{DECISION_HEADER.applicant}</span>
            </div>
          </div>
          <div style={{ flex:1 }} />
          <div style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, color:'rgba(var(--slate-rgb), 0.6)' }}>
            Run <strong style={{ color:'var(--teal)' }}>{DECISION_HEADER.run}</strong> · {DECISION_HEADER.date}
          </div>
        </div>
      </Panel>

      {/* Lens switcher tabs */}
      <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
        {LENSES.map(l => (
          <button type="button" key={l.id} onClick={() => setActiveLens(l.id)}
            style={{
              display:'flex', alignItems:'center', gap:8,
              padding:'9px 16px', borderRadius:999, border:'none', cursor:'pointer',
              background: activeLens === l.id ? l.bg : 'rgba(var(--white-rgb), 0.6)',
              boxShadow: activeLens === l.id ? `0 0 0 1.5px ${l.color}` : '0 0 0 1px rgba(var(--ink-rgb), 0.1)',
              transition:'all 160ms',
            }}>
            <span style={{ fontSize:13, color:l.color }}>{l.icon}</span>
            <span style={{ fontSize:12, fontWeight:700, color: activeLens===l.id ? l.color : 'var(--slate)' }}>{l.label}</span>
          </button>
        ))}
      </div>

      {/* Lens content */}
      <div style={{ flex:1, display:'flex', gap:16 }}>

        {/* Fields */}
        <Panel style={{ flex:1, background: lens.bg }}>
          <PanelHeader eyebrow={`Lens — ${lens.label}`} title={lens.desc} />
          <div style={{ columns: 2, columnGap:14 }}>
            {lens.fields.map((f, i) => (
              <div key={i} style={{ breakInside:'avoid', marginBottom:0 }}>
                <LensField field={f} />
              </div>
            ))}
          </div>
          {lens.caveats && (
            <div style={{ marginTop:14, padding:'10px 14px', borderRadius:12,
              background:'rgba(var(--ember-rgb), 0.08)', border:'1px solid rgba(var(--ember-rgb), 0.2)' }}>
              <span style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', fontWeight:700, color:'var(--ember)', letterSpacing:'0.08em' }}>⚠ CAVEAT</span>
              <p style={{ margin:'4px 0 0', fontSize:12, color:'var(--ember)', lineHeight:1.55 }}>{lens.caveats}</p>
            </div>
          )}
        </Panel>

        {/* Lens key */}
        <div style={{ width:220, flexShrink:0 }}>
          <Panel style={{ height:'100%' }}>
            <Eyebrow style={{ marginBottom:12 }}>All lenses</Eyebrow>
            {LENSES.map(l => (
              <InteractiveCard key={l.id} onClick={() => setActiveLens(l.id)} selected={activeLens===l.id}
                ariaLabel={`Select stakeholder lens ${l.label}.`}
                style={{ padding:'10px 12px', borderRadius:13, marginBottom:8, cursor:'pointer',
                  background: activeLens===l.id ? l.bg : 'rgba(var(--white-rgb), 0.5)',
                  border:`1.5px solid ${activeLens===l.id ? l.color : 'rgba(var(--ink-rgb), 0.07)'}`,
                  transition:'all 140ms' }}>
                <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:3 }}>
                  <span style={{ fontSize:13, color:l.color }}>{l.icon}</span>
                  <span style={{ fontSize:12, fontWeight:700, color: activeLens===l.id ? l.color : 'var(--ink)' }}>{l.label}</span>
                </div>
                <p style={{ margin:0, fontSize:10, color:'rgba(var(--slate-rgb), 0.7)', lineHeight:1.45 }}>{l.desc}</p>
              </InteractiveCard>
            ))}
          </Panel>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { StakeholderLensScreen });
