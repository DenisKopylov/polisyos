// StressTestTheatre.jsx — A5
// Scene-based stress testing: Act I baseline → Act II adversarial → Act III failure
// Exports: StressTestTheatreScreen

const ACTS = [
  {
    id:'act1', label:'Act I', subtitle:'Baseline',
    color:'var(--teal)', bg:'rgba(var(--teal-rgb), 0.10)', border:'rgba(var(--teal-rgb), 0.28)',
    scenes:[
      {
        id:'s1a', label:'Scene 1', title:'Standard dataset',
        desc:'Well-labelled, complete records with expected distributional properties.',
        dataset:{ size:42180, completeness:0.994, ood:0.02, label_noise:0.0 },
        reaction:{ approve_rate:0.483, confidence_mean:0.791, p10:0.621, p90:0.934, latency_ms:148 },
        status:'pass',
        diff:{ approve:0, confidence:0, latency:0 },
      },
      {
        id:'s1b', label:'Scene 2', title:'Minor class imbalance',
        desc:'Outcome class split 72/28 vs baseline 58/42. Minor distributional skew.',
        dataset:{ size:42180, completeness:0.991, ood:0.06, label_noise:0.0 },
        reaction:{ approve_rate:0.501, confidence_mean:0.774, p10:0.608, p90:0.921, latency_ms:152 },
        status:'pass',
        diff:{ approve:+0.018, confidence:-0.017, latency:+4 },
      },
    ],
  },
  {
    id:'act2', label:'Act II', subtitle:'Adversarial',
    color:'var(--gold-vibrant)', bg:'rgba(var(--gold-vibrant-rgb), 0.10)', border:'rgba(var(--gold-vibrant-rgb), 0.28)',
    scenes:[
      {
        id:'s2a', label:'Scene 1', title:'Out-of-distribution inputs',
        desc:'18% of records drawn from a shifted distribution (different region, fiscal year).',
        dataset:{ size:42180, completeness:0.978, ood:0.18, label_noise:0.0 },
        reaction:{ approve_rate:0.529, confidence_mean:0.712, p10:0.498, p90:0.911, latency_ms:201 },
        status:'warn',
        diff:{ approve:+0.046, confidence:-0.079, latency:+53 },
      },
      {
        id:'s2b', label:'Scene 2', title:'Label noise (5%)',
        desc:'5% of training labels randomly flipped. Tests robustness of learned representations.',
        dataset:{ size:42180, completeness:0.989, ood:0.05, label_noise:0.05 },
        reaction:{ approve_rate:0.471, confidence_mean:0.668, p10:0.431, p90:0.879, latency_ms:156 },
        status:'warn',
        diff:{ approve:-0.012, confidence:-0.123, latency:+8 },
      },
    ],
  },
  {
    id:'act3', label:'Act III', subtitle:'Failure',
    color:'var(--ember)', bg:'rgba(var(--ember-rgb), 0.10)', border:'rgba(var(--ember-rgb), 0.28)',
    scenes:[
      {
        id:'s3a', label:'Scene 1', title:'Catastrophic corruption (30% NaN)',
        desc:'30% of feature values replaced with NaN via simulated upstream ETL failure.',
        dataset:{ size:42180, completeness:0.699, ood:0.31, label_noise:0.0 },
        reaction:{ approve_rate:0.612, confidence_mean:0.501, p10:0.218, p90:0.941, latency_ms:389 },
        status:'fail',
        diff:{ approve:+0.129, confidence:-0.290, latency:+241 },
      },
      {
        id:'s3b', label:'Scene 2', title:'Adversarial perturbation',
        desc:'Targeted gradient-based feature perturbations to flip borderline decisions.',
        dataset:{ size:42180, completeness:0.993, ood:0.42, label_noise:0.0 },
        reaction:{ approve_rate:0.538, confidence_mean:0.549, p10:0.181, p90:0.961, latency_ms:312 },
        status:'fail',
        diff:{ approve:+0.055, confidence:-0.242, latency:+164 },
      },
    ],
  },
];

const STATUS_CFG = {
  pass: { label:'PASS', color:'var(--teal)', bg:'rgba(var(--teal-rgb), 0.12)', badge:'ok'      },
  warn: { label:'WARN', color:'var(--gold-vibrant)', bg:'rgba(var(--gold-vibrant-rgb), 0.13)', badge:'warn'  },
  fail: { label:'FAIL', color:'var(--ember)', bg:'rgba(var(--ember-rgb), 0.12)', badge:'fail'   },
};

function diffColor(val, higherIsBetter) {
  if (val === 0) return 'var(--slate)';
  const positive = val > 0;
  return (positive === higherIsBetter) ? 'var(--teal)' : 'var(--ember)';
}

function diffLabel(val, pct) {
  const sign = val > 0 ? '+' : '';
  return pct ? `${sign}${(val*100).toFixed(1)}pp` : `${sign}${val.toFixed(0)}ms`;
}

function MiniBar({ value, max=1, color, h=5 }) {
  return (
    <div style={{ height:h, borderRadius:999, background:'rgba(var(--ink-rgb), 0.08)', overflow:'hidden', marginTop:3 }}>
      <div style={{ height:'100%', borderRadius:999, background:color, width:`${(value/max*100).toFixed(1)}%`, transition:'width 300ms' }} />
    </div>
  );
}

function ConfidenceDist({ scene }) {
  // Simplified histogram-like display using p10, mean, p90 on a bar
  const { p10, confidence_mean, p90 } = scene.reaction;
  return (
    <div style={{ position:'relative', height:28, background:'rgba(var(--ink-rgb), 0.05)', borderRadius:8, overflow:'hidden' }}>
      {/* CI band p10-p90 */}
      <div style={{
        position:'absolute', top:0, bottom:0,
        left:`${p10*100}%`, right:`${(1-p90)*100}%`,
        background:'rgba(var(--teal-vibrant-rgb), 0.18)', borderRadius:4,
      }} />
      {/* Mean line */}
      <div style={{
        position:'absolute', top:4, bottom:4, width:2,
        left:`${confidence_mean*100}%`, marginLeft:-1,
        background:'var(--teal-vibrant)', borderRadius:1,
      }} />
      {/* Labels */}
      <span style={{ position:'absolute', left:`${p10*100}%`, bottom:2, fontSize:8, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.7)', transform:'translateX(-50%)' }}>p10</span>
      <span style={{ position:'absolute', left:`${confidence_mean*100}%`, top:2, fontSize:8, fontFamily:'"IBM Plex Mono",monospace', color:'var(--teal)', transform:'translateX(-50%)' }}>μ</span>
      <span style={{ position:'absolute', left:`${p90*100}%`, bottom:2, fontSize:8, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.7)', transform:'translateX(-50%)' }}>p90</span>
    </div>
  );
}

function StressTestTheatreScreen() {
  const [selScene, setSelScene] = React.useState(ACTS[0].scenes[0]);
  const selAct = ACTS.find(a => a.scenes.some(s => s.id === selScene.id));
  const scfg = STATUS_CFG[selScene.status];
  const baseline = ACTS[0].scenes[0];

  return (
    <div style={{ display:'flex', gap:20, height:'100%' }}>

      {/* Scene list — the "programme" */}
      <div style={{ width:220, flexShrink:0, display:'flex', flexDirection:'column', gap:8 }}>
        <Eyebrow style={{ marginBottom:4 }}>A5 · Stress-Test Theatre</Eyebrow>
        {ACTS.map(act => (
          <div key={act.id}>
            {/* Act header */}
            <div style={{ display:'flex', alignItems:'center', gap:8, padding:'7px 10px', borderRadius:10, marginBottom:5,
              background:act.bg, border:`1px solid ${act.border}` }}>
              <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, fontWeight:700, letterSpacing:'0.1em', color:act.color }}>{act.label.toUpperCase()}</span>
              <span style={{ fontSize:11, fontWeight:600, color:act.color }}>{act.subtitle}</span>
              {/* Mini status dots */}
              <div style={{ marginLeft:'auto', display:'flex', gap:4 }}>
                {act.scenes.map(s => (
                  <div key={s.id} style={{ width:7, height:7, borderRadius:'50%', background:STATUS_CFG[s.status].color, opacity:0.8 }} />
                ))}
              </div>
            </div>
            {/* Scenes */}
            {act.scenes.map(scene => {
              const isSel = selScene.id === scene.id;
              const scfgS = STATUS_CFG[scene.status];
              return (
                <InteractiveCard key={scene.id}
                  onClick={() => setSelScene(scene)}
                  selected={isSel}
                  ariaLabel={`Select scene ${scene.title}. Status ${scfgS.label}.`}
                  style={{
                    padding:'9px 12px', borderRadius:12, marginBottom:5, cursor:'pointer',
                    background: isSel ? 'rgba(var(--white-rgb), 0.75)' : 'rgba(var(--white-rgb), 0.4)',
                    border: `1.5px solid ${isSel ? act.color : 'rgba(var(--ink-rgb), 0.08)'}`,
                    transition:'all 140ms',
                  }}>
                  <div style={{ display:'flex', alignItems:'center', gap:6, marginBottom:3 }}>
                    <span style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:scfgS.color, fontWeight:700 }}>{scene.label}</span>
                    <span style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:scfgS.color, fontWeight:700,
                      background:scfgS.bg, padding:'1px 5px', borderRadius:999 }}>{scfgS.label}</span>
                  </div>
                  <div style={{ fontSize:11, fontWeight:600, color:'var(--ink)', lineHeight:1.35 }}>{scene.title}</div>
                </InteractiveCard>
              );
            })}
          </div>
        ))}
      </div>

      {/* Stage — main scene view */}
      <div style={{ flex:1, minWidth:0, display:'flex', flexDirection:'column', gap:12 }}>

        {/* Scene header */}
        <Panel style={{ padding:'14px 18px', background:`${selAct.bg}` }}>
          <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between' }}>
            <div>
              <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:4 }}>
                <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:9, fontWeight:700, letterSpacing:'0.1em', color:selAct.color }}>{selAct.label.toUpperCase()} · {selScene.label.toUpperCase()}</span>
                <Badge kind={scfg.badge}>{scfg.label}</Badge>
              </div>
              <h3 style={{ margin:0, fontSize:20, fontWeight:800, letterSpacing:'-0.03em', color:'var(--ink)' }}>{selScene.title}</h3>
              <p style={{ margin:'4px 0 0', fontSize:13, color:'var(--slate)', lineHeight:1.5 }}>{selScene.desc}</p>
            </div>
          </div>
        </Panel>

        {/* Dataset stats */}
        <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:10 }}>
          {[
            { label:'Records',    value:selScene.dataset.size.toLocaleString(), color:'var(--ink)' },
            { label:'Completeness', value:`${(selScene.dataset.completeness*100).toFixed(1)}%`, color: selScene.dataset.completeness > 0.95 ? 'var(--teal)' : 'var(--ember)' },
            { label:'OOD Score',  value:selScene.dataset.ood.toFixed(2), color: selScene.dataset.ood < 0.1 ? 'var(--teal)' : selScene.dataset.ood < 0.25 ? 'var(--gold-vibrant)' : 'var(--ember)' },
            { label:'Label Noise',value:`${(selScene.dataset.label_noise*100).toFixed(0)}%`, color: selScene.dataset.label_noise === 0 ? 'var(--teal)' : 'var(--ember)' },
          ].map(m => (
            <div key={m.label} style={{ padding:'12px 14px', borderRadius:16, background:'rgba(var(--white-rgb), 0.56)', border:'1px solid rgba(var(--ink-rgb), 0.08)' }}>
              <div style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', letterSpacing:'0.1em', color:'rgba(var(--slate-rgb), 0.7)', marginBottom:4 }}>{m.label.toUpperCase()}</div>
              <div style={{ fontSize:22, fontWeight:800, letterSpacing:'-0.04em', color:m.color }}>{m.value}</div>
              <MiniBar value={m.label==='Completeness'?selScene.dataset.completeness:m.label==='OOD Score'?selScene.dataset.ood:m.label==='Label Noise'?selScene.dataset.label_noise:1} color={m.color} />
            </div>
          ))}
        </div>

        {/* Policy reaction */}
        <Panel>
          <PanelHeader eyebrow="Policy reaction" title="Output distribution" />
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:18 }}>
            <div>
              <Eyebrow style={{ marginBottom:8 }}>Approval rate</Eyebrow>
              <div style={{ fontSize:32, fontWeight:800, letterSpacing:'-0.04em', color:selAct.color }}>
                {(selScene.reaction.approve_rate*100).toFixed(1)}%
              </div>
              <MiniBar value={selScene.reaction.approve_rate} color={selAct.color} h={6} />
              <div style={{ fontSize:11, color:diffColor(selScene.diff.approve, false), marginTop:4, fontFamily:'"IBM Plex Mono",monospace', fontWeight:700 }}>
                {selScene.diff.approve === 0 ? 'baseline' : diffLabel(selScene.diff.approve, true) + ' vs baseline'}
              </div>
            </div>
            <div>
              <Eyebrow style={{ marginBottom:8 }}>Mean confidence</Eyebrow>
              <div style={{ fontSize:32, fontWeight:800, letterSpacing:'-0.04em', color: selScene.reaction.confidence_mean > 0.7 ? 'var(--teal)' : selScene.reaction.confidence_mean > 0.55 ? 'var(--gold-vibrant)' : 'var(--ember)' }}>
                {selScene.reaction.confidence_mean.toFixed(3)}
              </div>
              <MiniBar value={selScene.reaction.confidence_mean} color={selScene.reaction.confidence_mean > 0.7 ? 'var(--teal-vibrant)':'var(--ember-vibrant)'} h={6} />
              <div style={{ fontSize:11, color:diffColor(selScene.diff.confidence, true), marginTop:4, fontFamily:'"IBM Plex Mono",monospace', fontWeight:700 }}>
                {selScene.diff.confidence === 0 ? 'baseline' : diffLabel(selScene.diff.confidence, true) + ' vs baseline'}
              </div>
            </div>
          </div>

          <div style={{ marginTop:16 }}>
            <Eyebrow style={{ marginBottom:8 }}>Confidence distribution (p10 / μ / p90)</Eyebrow>
            <ConfidenceDist scene={selScene} />
            <div style={{ display:'flex', justifyContent:'space-between', marginTop:4 }}>
              <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, color:'var(--slate)' }}>p10: {selScene.reaction.p10.toFixed(3)}</span>
              <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, color:'var(--teal)', fontWeight:700 }}>μ: {selScene.reaction.confidence_mean.toFixed(3)}</span>
              <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, color:'var(--slate)' }}>p90: {selScene.reaction.p90.toFixed(3)}</span>
            </div>
          </div>

          <div style={{ marginTop:14, padding:'10px 14px', borderRadius:12, background:'rgba(var(--white-rgb), 0.5)', border:'1px solid rgba(var(--ink-rgb), 0.08)', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
            <span style={{ fontSize:12, color:'var(--slate)' }}>Inference latency</span>
            <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:14, fontWeight:700, color: selScene.reaction.latency_ms < 200 ? 'var(--teal)' : selScene.reaction.latency_ms < 300 ? 'var(--gold-vibrant)' : 'var(--ember)' }}>
              {selScene.reaction.latency_ms} ms
              <span style={{ fontSize:10, fontWeight:400, color:diffColor(selScene.diff.latency, false), marginLeft:8 }}>
                {selScene.diff.latency === 0 ? '(baseline)' : diffLabel(selScene.diff.latency, false)}
              </span>
            </span>
          </div>
        </Panel>
      </div>

      {/* Diff panel */}
      <div style={{ width:236, flexShrink:0, display:'flex', flexDirection:'column', gap:12 }}>
        <Panel style={{ flex:1 }}>
          <PanelHeader eyebrow="Diff vs baseline" title="Δ Indicators" />

          {[
            { label:'Approval rate',    val:selScene.diff.approve,    pct:true,  higher_ok:false },
            { label:'Mean confidence',  val:selScene.diff.confidence, pct:true,  higher_ok:true  },
            { label:'Inference latency',val:selScene.diff.latency,    pct:false, higher_ok:false },
          ].map(row => {
            const isNeutral = row.val === 0;
            const isGood    = row.val === 0 || (row.val > 0) === row.higher_ok;
            const col       = isNeutral ? 'var(--slate)' : isGood ? 'var(--teal)' : 'var(--ember)';
            return (
              <div key={row.label} style={{ padding:'11px 12px', borderRadius:13, marginBottom:8,
                background: isNeutral ? 'rgba(var(--slate-rgb), 0.06)' : isGood ? 'rgba(var(--teal-rgb), 0.08)' : 'rgba(var(--ember-rgb), 0.08)',
                border:`1px solid ${isNeutral ? 'rgba(var(--slate-rgb), 0.15)' : isGood ? 'rgba(var(--teal-rgb), 0.2)' : 'rgba(var(--ember-rgb), 0.2)'}` }}>
                <div style={{ fontSize:10, color:'rgba(var(--slate-rgb), 0.7)', marginBottom:5 }}>{row.label}</div>
                <div style={{ fontSize:22, fontWeight:800, letterSpacing:'-0.04em', color:col }}>
                  {isNeutral ? '—' : diffLabel(row.val, row.pct)}
                </div>
              </div>
            );
          })}

          <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', margin:'14px 0' }} />
          <Eyebrow style={{ marginBottom:10 }}>All scenes</Eyebrow>
          {ACTS.flatMap(a => a.scenes).map(s => {
            const sact = ACTS.find(a => a.scenes.includes(s));
            const sc = STATUS_CFG[s.status];
            const isSel = s.id === selScene.id;
            return (
              <InteractiveCard key={s.id} onClick={() => setSelScene(s)} selected={isSel}
                ariaLabel={`Select stress-test scene ${s.title}. Status ${sc.label}.`}
                style={{ display:'flex', alignItems:'center', gap:8, padding:'6px 8px', borderRadius:9, marginBottom:4,
                  background: isSel ? 'rgba(var(--white-rgb), 0.7)' : 'transparent',
                  cursor:'pointer', transition:'background 140ms' }}>
                <div style={{ width:7, height:7, borderRadius:'50%', background:sc.color, flexShrink:0 }} />
                <span style={{ fontSize:11, color:'var(--ink)', flex:1, fontWeight: isSel ? 700 : 400 }}>{s.title}</span>
                <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:8, color:sc.color, fontWeight:700 }}>{sc.label}</span>
              </InteractiveCard>
            );
          })}
        </Panel>
      </div>
    </div>
  );
}

Object.assign(window, { StressTestTheatreScreen });
