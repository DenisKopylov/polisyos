// UncertaintyDecomposer.jsx — E3
// Epistemic (model) vs aleatoric (data) uncertainty decomposition
// Exports: UncertaintyDecomposerScreen

const DECOMP_DATA = [
  { label:'Fiscal Reform Policy (overall)', epistemic:0.084, aleatoric:0.127, total:0.211, n:42180, group:'policy' },
  { label:'Q1 Income cohort',               epistemic:0.142, aleatoric:0.168, total:0.310, n:10545, group:'income' },
  { label:'Q2 Income cohort',               epistemic:0.091, aleatoric:0.134, total:0.225, n:10545, group:'income' },
  { label:'Q3 Income cohort',               epistemic:0.071, aleatoric:0.118, total:0.189, n:10545, group:'income' },
  { label:'Q4 Income cohort',               epistemic:0.058, aleatoric:0.098, total:0.156, n:10545, group:'income' },
  { label:'Urban region',                   epistemic:0.062, aleatoric:0.109, total:0.171, n:18280, group:'region' },
  { label:'Rural region',                   epistemic:0.118, aleatoric:0.151, total:0.269, n:9840,  group:'region' },
  { label:'Remote region',                  epistemic:0.198, aleatoric:0.172, total:0.370, n:2210,  group:'region' },
  { label:'Age 18–30',                      epistemic:0.109, aleatoric:0.144, total:0.253, n:8620,  group:'age'    },
  { label:'Age 31–45',                      epistemic:0.072, aleatoric:0.118, total:0.190, n:14880, group:'age'    },
  { label:'Age 46–60',                      epistemic:0.081, aleatoric:0.122, total:0.203, n:12940, group:'age'    },
  { label:'Age 60+',                        epistemic:0.138, aleatoric:0.159, total:0.297, n:5740,  group:'age'    },
];

const GROUP_LABELS = { policy:'Overall', income:'By income quartile', region:'By region', age:'By age group' };

const UNC_DESC = {
  epistemic:'Model uncertainty — reducible with more data or a better model. High epistemic uncertainty means the model has not seen enough examples like this.',
  aleatoric:'Data uncertainty — irreducible noise inherent in the outcome. High aleatoric uncertainty means the outcome is genuinely hard to predict even with perfect data.',
};

function UncBar({ epistemic, aleatoric, total, maxTotal=0.4 }) {
  const eW = (epistemic / maxTotal * 100).toFixed(1);
  const aW = (aleatoric / maxTotal * 100).toFixed(1);
  return (
    <div style={{ height:14, borderRadius:999, background:'rgba(var(--ink-rgb), 0.07)', overflow:'hidden', display:'flex' }}>
      <div style={{ width:`${eW}%`, background:'var(--chart-secondary)', borderRadius:'999px 0 0 999px', opacity:0.75 }} />
      <div style={{ width:`${aW}%`, background:'var(--ember-vibrant)', opacity:0.65 }} />
    </div>
  );
}

function UncertaintyDecomposerScreen() {
  const [selected, setSelected] = React.useState(null);
  const [groupFilter, setGF]    = React.useState('all');
  const [sortBy, setSortBy]     = React.useState('total');

  const groups = ['all', ...Object.keys(GROUP_LABELS)];
  const data   = DECOMP_DATA
    .filter(d => groupFilter === 'all' || d.group === groupFilter)
    .sort((a, b) => b[sortBy] - a[sortBy]);

  const maxTotal = Math.max(...data.map(d => d.total));
  const sel = selected ? DECOMP_DATA.find(d => d.label === selected) : null;

  return (
    <div style={{ display:'flex', gap:20, height:'100%' }}>

      {/* Main panel */}
      <div style={{ flex:1, minWidth:0, display:'flex', flexDirection:'column', gap:12 }}>

        {/* Toolbar */}
        <div style={{ display:'flex', alignItems:'center', gap:8, flexWrap:'wrap' }}>
          <Eyebrow>E3 · Uncertainty Decomposition</Eyebrow>
          <div style={{ flex:1 }} />
          <span style={{ fontSize:11, color:'rgba(var(--slate-rgb), 0.6)' }}>Group</span>
          {groups.map(g => (
            <button type="button" key={g} onClick={() => setGF(g)}
              style={{ padding:'4px 10px', borderRadius:999, border:'none', cursor:'pointer',
                fontFamily:'"IBM Plex Mono",monospace', fontSize:9, fontWeight:700, letterSpacing:'0.06em',
                background: groupFilter===g ? 'rgba(var(--ink-rgb), 0.09)':'rgba(var(--white-rgb), 0.65)',
                color: groupFilter===g ? 'var(--ink)':'rgba(var(--slate-rgb), 0.65)',
                boxShadow: groupFilter===g ? '0 0 0 1px rgba(var(--ink-rgb), 0.18)':'0 0 0 1px rgba(var(--ink-rgb), 0.08)' }}>
              {g === 'all' ? 'ALL' : GROUP_LABELS[g].toUpperCase().slice(0,6)}
            </button>
          ))}
          <span style={{ fontSize:11, color:'rgba(var(--slate-rgb), 0.6)' }}>Sort</span>
          {['total','epistemic','aleatoric'].map(s => (
            <button type="button" key={s} onClick={() => setSortBy(s)}
              style={{ padding:'4px 10px', borderRadius:999, border:'none', cursor:'pointer',
                fontFamily:'"IBM Plex Mono",monospace', fontSize:9, fontWeight:700, letterSpacing:'0.06em',
                background: sortBy===s ? 'rgba(var(--ink-rgb), 0.09)':'rgba(var(--white-rgb), 0.65)',
                color: sortBy===s ? 'var(--ink)':'rgba(var(--slate-rgb), 0.65)',
                boxShadow: sortBy===s ? '0 0 0 1px rgba(var(--ink-rgb), 0.18)':'0 0 0 1px rgba(var(--ink-rgb), 0.08)' }}>
              {s.toUpperCase()}
            </button>
          ))}
        </div>

        {/* Legend */}
        <div style={{ display:'flex', gap:18, padding:'0 2px' }}>
          {[['var(--chart-secondary)','Epistemic (model) uncertainty'],['var(--ember-vibrant)','Aleatoric (data) uncertainty']].map(([c,l]) => (
            <div key={l} style={{ display:'flex', alignItems:'center', gap:7 }}>
              <div style={{ width:18, height:5, borderRadius:999, background:c, opacity:0.75 }} />
              <span style={{ fontSize:11, color:'rgba(var(--slate-rgb), 0.75)' }}>{l}</span>
            </div>
          ))}
          <span style={{ fontSize:10, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.45)', marginLeft:8 }}>bar width = proportion of max total ({maxTotal.toFixed(2)})</span>
        </div>

        {/* Table */}
        <Panel style={{ flex:1, padding:'14px 0', overflow:'auto' }}>
          <div style={{ display:'grid', gridTemplateColumns:'220px 1fr 70px 70px 70px 80px', gap:10, padding:'0 18px 8px',
            borderBottom:'1px solid rgba(var(--ink-rgb), 0.08)', marginBottom:4 }}>
            {['Cohort / group','Decomposition','Epist.','Aleat.','Total','n'].map(h => (
              <span key={h} style={{ fontSize:8, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.4)', letterSpacing:'0.1em' }}>{h.toUpperCase()}</span>
            ))}
          </div>

          {data.map(row => {
            const isSel = selected === row.label;
            const uncLevel = row.total > 0.30 ? 'high' : row.total > 0.20 ? 'medium' : 'low';
            const uncColor = uncLevel === 'high' ? 'var(--ember)' : uncLevel === 'medium' ? 'var(--gold-vibrant)' : 'var(--teal)';
            return (
              <InteractiveCard key={row.label}
                onClick={() => setSelected(s => s===row.label ? null : row.label)}
                selected={isSel}
                ariaLabel={`Toggle uncertainty row ${row.label}. Total uncertainty ${row.total.toFixed(3)}.`}
                style={{
                  display:'grid', gridTemplateColumns:'220px 1fr 70px 70px 70px 80px', gap:10,
                  padding:'9px 18px', cursor:'pointer', alignItems:'center',
                  background: isSel ? 'rgba(var(--white-rgb), 0.6)':'transparent',
                  borderLeft:`3px solid ${isSel ? uncColor:'transparent'}`,
                  transition:'background 130ms',
                }}>
                <span style={{ fontSize:12, fontWeight:600, color:'var(--ink)' }}>{row.label}</span>
                <div style={{ minWidth:0 }}>
                  <UncBar epistemic={row.epistemic} aleatoric={row.aleatoric} total={row.total} maxTotal={maxTotal} />
                </div>
                <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, fontWeight:700, color:'var(--chart-secondary)' }}>{row.epistemic.toFixed(3)}</span>
                <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, fontWeight:700, color:'var(--ember-vibrant)' }}>{row.aleatoric.toFixed(3)}</span>
                <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:11, fontWeight:800, color:uncColor }}>{row.total.toFixed(3)}</span>
                <span style={{ fontFamily:'"IBM Plex Mono",monospace', fontSize:10, color:'rgba(var(--slate-rgb), 0.6)' }}>{row.n.toLocaleString()}</span>
              </InteractiveCard>
            );
          })}
        </Panel>
      </div>

      {/* Inspector */}
      <div style={{ width:252, flexShrink:0, display:'flex', flexDirection:'column', gap:12 }}>
        <Panel style={{ flex:1 }}>
          <PanelHeader eyebrow="Uncertainty detail" title={sel ? sel.label : 'Select a row'} />

          {!sel ? (
            <div>
              <p style={{ fontSize:12, color:'var(--slate)', lineHeight:1.6, margin:'0 0 16px' }}>
                Click any row to decompose its uncertainty into epistemic (reducible) and aleatoric (irreducible) components.
              </p>
              <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', marginBottom:14 }} />
              {Object.entries(UNC_DESC).map(([key, desc]) => (
                <div key={key} style={{ marginBottom:12, padding:'10px 12px', borderRadius:12,
                  background: key==='epistemic'?'rgba(var(--blue-rgb), 0.07)':'rgba(var(--ember-vibrant-rgb), 0.07)',
                  border:`1px solid ${key==='epistemic'?'rgba(var(--blue-rgb), 0.18)':'rgba(var(--ember-vibrant-rgb), 0.18)'}` }}>
                  <div style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', fontWeight:700,
                    color:key==='epistemic'?'var(--chart-secondary)':'var(--ember-vibrant)', letterSpacing:'0.08em', marginBottom:5 }}>
                    {key.toUpperCase()}
                  </div>
                  <p style={{ margin:0, fontSize:11, lineHeight:1.6, color: key==='epistemic'?'var(--chart-secondary)':'var(--ember-vibrant)' }}>{desc}</p>
                </div>
              ))}
            </div>
          ) : (
            <div>
              <div style={{ marginBottom:16 }}>
                {/* Pie-like decomposition */}
                <div style={{ height:10, borderRadius:999, background:'rgba(var(--ink-rgb), 0.08)', overflow:'hidden', display:'flex', marginBottom:8 }}>
                  <div style={{ width:`${(sel.epistemic/sel.total*100).toFixed(0)}%`, background:'var(--chart-secondary)', opacity:0.75 }} />
                  <div style={{ flex:1, background:'var(--ember-vibrant)', opacity:0.65 }} />
                </div>
                <div style={{ display:'flex', justifyContent:'space-between' }}>
                  <span style={{ fontSize:10, color:'var(--chart-secondary)' }}>Epistemic {(sel.epistemic/sel.total*100).toFixed(0)}%</span>
                  <span style={{ fontSize:10, color:'var(--ember-vibrant)' }}>Aleatoric {(sel.aleatoric/sel.total*100).toFixed(0)}%</span>
                </div>
              </div>

              {[
                { label:'Total uncertainty',  val:sel.total,      color: sel.total > 0.30 ? 'var(--ember)' : sel.total > 0.20 ? 'var(--gold-vibrant)':'var(--teal)' },
                { label:'Epistemic (model)',   val:sel.epistemic,  color:'var(--chart-secondary)' },
                { label:'Aleatoric (data)',    val:sel.aleatoric,  color:'var(--ember-vibrant)' },
                { label:'Cohort size',         val:sel.n.toLocaleString(), color:'var(--slate)', raw:true },
              ].map(r => (
                <div key={r.label} style={{ marginBottom:12 }}>
                  <div style={{ fontSize:9, fontFamily:'"IBM Plex Mono",monospace', color:'rgba(var(--slate-rgb), 0.55)', marginBottom:3 }}>{r.label.toUpperCase()}</div>
                  <div style={{ fontSize:22, fontWeight:800, letterSpacing:'-0.04em', color:r.color }}>
                    {r.raw ? r.val : r.val.toFixed(3)}
                  </div>
                </div>
              ))}

              <div style={{ height:1, background:'rgba(var(--ink-rgb), 0.08)', margin:'14px 0' }} />
              <Eyebrow style={{ marginBottom:8 }}>Interpretation</Eyebrow>
              <p style={{ margin:0, fontSize:12, color:'var(--slate)', lineHeight:1.6 }}>
                {sel.epistemic > sel.aleatoric
                  ? `Model uncertainty dominates. Collecting more labelled data for this cohort would reduce total uncertainty by up to ${(sel.epistemic*100).toFixed(0)}%.`
                  : `Data uncertainty dominates. The outcome is inherently noisy for this cohort. Additional data collection will have limited benefit.`}
              </p>
              <button type="button" onClick={() => setSelected(null)} style={{ marginTop:12, fontSize:11, color:'rgba(var(--slate-rgb), 0.7)', background:'none', border:'none', cursor:'pointer', padding:0 }}>← All cohorts</button>
            </div>
          )}
        </Panel>
      </div>
    </div>
  );
}

Object.assign(window, { UncertaintyDecomposerScreen });
