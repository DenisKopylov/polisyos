# Перепроверка на текущем HEAD

Этот архив не читает и не меняет рабочий репозиторий. Он связывает audit f1541ed155f278689be48a8c7ac56c3e200210f7 и E02 v3 baseline 20d9009be21097bfbdc38a546a15cc60213b8ace. Нельзя переносить их старые статусы в текущую ветку.

1. Получить у исполнителя lane 01: HEAD/tree, merged package IDs, работающие write leases, patch hashes, selected runtime/profile, точные выполненные TEST/REQ/bindings, известные UNRUN и DA.
2. Сравнить owner paths каждой запланированной карточки с исходными normalized_source_references; номера строк использовать только как исторический locator.
3. Проверить, не закрывает ли уже merged E02 patch исходный counterexample. Если закрывает, добавлять evidence, не повторный fix.
4. Если поменялся contract/consumer, пересмотреть placement и oracle прежде, чем редактировать.
5. Запускать поддерживаемый профиль из актуального проекта, точные scoped tests, installed origin/real OPA/PostgreSQL/corpus только где нужны выбранному claim. Не придумывать pytest selectors: получить их из actual collection manifest.
6. Зафиксировать actual execution, positive/negative controls, skip reasons и artifact binding. UNRUN/absence не PASS, source probe не installed/deployed qualification.
7. Внести статус в форму сдачи. Закрыть только конкретный finding/claim; invalidated downstream bindings перечислить отдельно с причиной.

Допустимые исходы: ALREADY_FIXED_WITH_EVIDENCE, CONFIRMED_REPAIR_NEEDED, CONTRACT_DECISION_REQUIRED, QUALIFICATION_REQUIRED, RISK_ACCEPTED_BY_OWNER, NOT_REPRODUCED_WITH_LIMITS, OUT_OF_SELECTED_PROFILE, BLOCKED_SPECIFIC_STEP, UNRUN. Этот документ никого не уполномочивает принимать риск или менять product authority.
