# После lane 12, отдельные owner-задачи

Статус: предварительный план, не свидетельство реализации. Основных карточек: 31. Сначала получить фактический отчёт исполнителя и сверить HEAD. Один implementation lane активен; corrective window приостанавливает затронутую работу, а не запускает параллельный lane.

## Порядок работы
1. Проверить текущую ветку/HEAD, незавершённые patches, write leases и источник evidence.
2. Для каждого пункта выбрать: уже закрыт; подтвердился; изменился контракт; не воспроизведён; UNRUN; требует решения. Сохранить причину и ссылку.
3. Выполнить только согласованный bounded patch или квалификацию у существующего owner.
4. Приложить точный oracle, контроли и affected-evidence map. Не ставить PASS по наличию файла/skip/fixture.
5. Обновить статус DA только в указанной части, не переносить весь TEST/REQ.

## Состав
- NC-01: Общий tag вызывает квадратичное число сравнений ID
- NC-02: Неизменённые contracts повторно строят документы и vectors
- NC-03: Малый top k не ограничивает полный поиск и materialization
- NS-02: Страница результата повторно читает и проверяет все overlay targets
- SG-01: История jobs и запросы run сканируют общие retained tables
- SG-02: Page limit и watermark не ограничивают SQL работу outbox
- SG-03: Открытие migrated store повторяет census и backfill
- SG-04: Стоимость LIMIT 1 зависит от planner и распределения истории
- ST-01: Каждое изменение owner сохраняет полное поколение истории
- ST-02: Точный тёплый lookup читает всё поколение ownership
- FE-01: Поздний refresh возвращает старую сессию после смены или clear
- FE-04: Поздний ответ прежнего API origin перезаписывает новое состояние
- DA-01: Application ownership находится под HTTP transport
- DA-02: Поверхность read API также предоставляет build операции
- DA-03: Физически разделённые модули снова соединяют mutable namespace
- GR-04: Обход affected nodes всё ещё материализует полный target vector
- SG-PG-01: PostgreSQL schema не содержит три secondary index из SQLite
- ST-03: Quota wrapper дважды сканирует CAS под mutation lock
- AB-03: Legacy LangGraph adapter и base dependencies требуют решения
- AB-04: Декларативный asset scaffold отличается от реальной batch orchestration
- AB-KEEP: Сохранить существующее повторное использование с отдельными владельцами
- DA-04: Название Orchestrator скрывает роль presentation owner
- LIB-03: Шесть weighted quantile функций реализуют три разных estimand
- LIB-04: Сохранить выбранный AUC contract и отказ для одного класса
- NR-02: Shadow metric projection теряет полный вложенный путь
- NR-03: Повторно использовать полный artifact view identity key
- NR-04: Повторно использовать Core entry point enumeration
- NR-05: Объединить эквивалентные leaf formatters causal importance
- NR-06: LRU delete удаляет None но сообщает отсутствие
- UI-01: Clerk activity не принадлежит конкретному поколению conversation
- UI-02: История run не различает ошибку и пустой текущий список

## NC-01 · Общий tag вызывает квадратичное число сравнений ID

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R7.1; механизм: NC-01.
- Основное окно: **AFTER-12**. Вторичные checkpoints: Ранее при доказанном ресурсоёмком actual catalogue path; R6.2 current generation и R14.1 request semantics должны сохраниться; После patch адресно повторить affected acquisition/selection и frozen artifact evidence.
- Владелец механизма: Существующий индекс и поиск Fabric catalogue.
- Владелец интеграционной приёмки: Один координатор E02 и существующий владелец указанного механизма; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: Прямой пакет оставшегося E02 не установлен. Дополнение: ADDON::NC-01 (не официальный E02 ID).
- Основание: Доказана квадратичная работа при общем tag, но не SLA или дефект selection. Оптимизацию разумно отделить от текущих semantic repairs.
- Первый rebind checkpoint: AFTER-12. Режим: Условная оптимизация после корректности.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Устранить квадратичный membership/dedup при сохранении alias и tag semantics; не менять admission и ranking policy.

Граница patch: Оптимизировать существующий index/search, сохранив admission и ambiguity; не менять semantics ради ANN.

### Условия и зависимости
Gate: **Условная оптимизация после корректности**. Перенести в более раннее corrective window только при измеренном блокировании текущего workload/ресурсного бюджета; не по одному synthetic N.

Нет дополнительных.

Исходные зависимости: [{"package": "R14.1", "relation": "semantic_acceptance_before_optimization"}, {"package": "R6.2", "relation": "generation_contract_when_reusing_unchanged"}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R6.2", "to": "R7.1", "kind": "incremental_precondition", "reason": "Content-correct generation before unchanged-document reuse."}
- {"from": "R14.1", "to": "R7.1", "kind": "semantic_acceptance", "reason": "Top-k/ANN must preserve ambiguity and request meaning before optimizing ranking."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Shared tag and duplicate/case-normalized alias semantics unchanged; N=100000 no quadratic comparison curve.

Дополнение для выбранного пути:
**Предлагаемая работа**
Устранить квадратичный membership/dedup при сохранении alias и tag semantics; не менять admission и ranking policy.

**Различающие проверки**
- Shared tag и отсутствие tag; duplicate/case-normalized aliases; возрастающий N и явный счёт ID comparisons; результат и порядок равны эталону.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Что сохранить**
Не скрывать ambiguity и не сливать самостоятельные SourceContract/DataForge catalogue owners.

Пакетная граница: Равные selections/refusals, shared alias/removal/real-query workload; content-correct generation и request fidelity квалифицированы.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/39.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high_bounded; уверенность распределения: Источник и контракт прочитаны; размещение предложено аналитически; актуальный HEAD, reachability и выполненные проверки не подтверждены..
- Ограничения: No production latency/SLA breach; large search corpus excludes shared aliases.
- Примечания к распределению: Нет дополнительных.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## NC-02 · Неизменённые contracts повторно строят документы и vectors

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R7.1; механизм: NC-02.
- Основное окно: **AFTER-12**. Вторичные checkpoints: R6.2/FG-02,GR-03 как инвариант freshness; R14.1 при затрагивании query→selection; DA-08 только по реально изменившимся consumers.
- Владелец механизма: Существующие semantic index/search и RetrievalService owners.
- Владелец интеграционной приёмки: Один координатор E02 и существующий владелец указанного механизма; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: DFK-02 (LANE-08). Дополнение: ADDON::NC-02 (не официальный E02 ID).
- Основание: Exact-file overlap retrieval/service.py с DFK-02 из LANE-08. В текущем аудите это лишние повторные builds, а не основание повторить весь ingest lane.
- Первый rebind checkpoint: AFTER-12. Режим: Условная оптимизация после generation correctness.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Переиспользовать неизменённые документы/vectors по точному content/profile binding; не считать same-count/same-size неизменностью.

Граница patch: Оптимизировать существующий index/search, сохранив admission и ambiguity; не менять semantics ради ANN.

### Условия и зависимости
Gate: **Условная оптимизация после generation correctness**. Раннее окно только если actual repeated refresh сдерживает обещанный consumer; сначала сохранить content-correct generation и add/remove semantics.

Нет дополнительных.

Исходные зависимости: [{"package": "R14.1", "relation": "semantic_acceptance_before_optimization"}, {"package": "R6.2", "relation": "generation_contract_when_reusing_unchanged"}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R6.2", "to": "R7.1", "kind": "incremental_precondition", "reason": "Content-correct generation before unchanged-document reuse."}
- {"from": "R14.1", "to": "R7.1", "kind": "semantic_acceptance", "reason": "Top-k/ANN must preserve ambiguity and request meaning before optimizing ranking."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Mutation/add/removal and identical profile/binding refresh controls; coherent snapshot publication; one rebuild for one changed item.

Дополнение для выбранного пути:
**Предлагаемая работа**
Переиспользовать неизменённые документы/vectors по точному content/profile binding; не считать same-count/same-size неизменностью.

**Различающие проверки**
- Unchanged generation; одно изменение; add/removal; profile/binding change; coherent publication; один изменённый item вызывает один нужный rebuild.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Что сохранить**
Повторная currentness/admission проверка и отказ для неполного delta остаются.

Пакетная граница: Равные selections/refusals, shared alias/removal/real-query workload; content-correct generation и request fidelity квалифицированы.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/40.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high_bounded; уверенность распределения: Источник и контракт прочитаны; размещение предложено аналитически; актуальный HEAD, reachability и выполненные проверки не подтверждены..
- Ограничения: One sample per build/refresh size; no HTTP approval/e2e/concurrency/persistence/profile enrichment.
- Примечания к распределению: Нет дополнительных.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## NC-03 · Малый top k не ограничивает полный поиск и materialization

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R7.1; механизм: NC-03.
- Основное окно: **AFTER-12**. Вторичные checkpoints: R14.1 semantic fidelity; R6.2 content generations; Не связывать автоматически с E02 OPT/Search lane только по слову search.
- Владелец механизма: Существующие MetricSearcher/FastLane и semantic catalogue owners.
- Владелец интеграционной приёмки: Один координатор E02 и существующий владелец указанного механизма; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: Прямой пакет оставшегося E02 не установлен. Дополнение: ADDON::NC-03 (не официальный E02 ID).
- Основание: Полный проход при малом top-k измерен на fixtures. ANN, exact lookup и результат selection требуют разных решений; это не разрешение менять смысл поиска ради скорости.
- Первый rebind checkpoint: AFTER-12. Режим: Условная оптимизация с явно выбранной recall policy.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Отдельно устранить full-registry materialization exact path и квалифицировать ranking/ANN предложение; recall policy назвать до измерения.

Граница patch: Оптимизировать существующий index/search, сохранив admission и ambiguity; не менять semantics ради ANN.

### Условия и зависимости
Gate: **Условная оптимизация с явно выбранной recall policy**. Раньше только при доказанной workload необходимости; исправленный R14.1 ambiguity/occurrence contract является preservation prerequisite.

Нет дополнительных.

Исходные зависимости: [{"package": "R14.1", "relation": "semantic_acceptance_before_optimization"}, {"package": "R6.2", "relation": "generation_contract_when_reusing_unchanged"}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R6.2", "to": "R7.1", "kind": "incremental_precondition", "reason": "Content-correct generation before unchanged-document reuse."}
- {"from": "R14.1", "to": "R7.1", "kind": "semantic_acceptance", "reason": "Top-k/ANN must preserve ambiguity and request meaning before optimizing ranking."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Result/score/tie/route/ambiguity equivalence or declared ANN recall policy; no full registry materialization for exact path.

Дополнение для выбранного пути:
**Предлагаемая работа**
Отдельно устранить full-registry materialization exact path и квалифицировать ranking/ANN предложение; recall policy назвать до измерения.

**Различающие проверки**
- Результат/score/ties/route/ambiguity до и после; exact и non-exact; shared matches; explicit top-k; измерение полного document/materialization denominator.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Что сохранить**
Не обрезать known ambiguity и не переименовывать приблизительный поиск в exact.

Пакетная граница: Равные selections/refusals, shared alias/removal/real-query workload; content-correct generation и request fidelity квалифицированы.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/41.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high_bounded; уверенность распределения: Источник и контракт прочитаны; размещение предложено аналитически; актуальный HEAD, reachability и выполненные проверки не подтверждены..
- Ограничения: Synthetic fixed tokens, no production distribution; standalone SourceContract catalog separate; DataForge HNSW not measured.
- Примечания к распределению: Нет дополнительных.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## NS-02 · Страница результата повторно читает и проверяет все overlay targets

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R7.2; механизм: NS-02.
- Основное окно: **AFTER-12**. Вторичные checkpoints: R6.5/NS-01 generation correctness; STATE-02 при затрагивании target/ack semantics; Актуальный I01 reader лишь при установленном использовании overlay.
- Владелец механизма: Существующий run projection reader и decision-validity overlay owners.
- Владелец интеграционной приёмки: Один координатор E02 и существующий владелец указанного механизма; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: Прямой пакет оставшегося E02 не установлен. Дополнение: ADDON::NS-02 (не официальный E02 ID).
- Основание: Request-scoped reuse уменьшает R×T чтения, но не должен кэшировать currentness между запросами. Это отдельный путь от outbox исправления STATE-02.
- Первый rebind checkpoint: AFTER-12. Режим: Оптимизация после согласованного readset.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Один согласованный overlay readset на request с точной областью жизни; не делать глобальный cache по ID.

Граница patch: Request-consistent общий read snapshot, не глобальный TTL trust cache.

### Условия и зависимости
Gate: **Оптимизация после согласованного readset**. Перенести раньше только при actual list/readback bottleneck; R6.5/NS-01 coherent generation и полная validity basis должны быть сохранены.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R6.5", "to": "R7.2", "kind": "consistency_contract", "reason": "Request-local reuse must consume coherent complete run generation."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Real admitted single growing batch and exact/list/batch consumers with source change, corruption, pending removal/restart.

Дополнение для выбранного пути:
**Предлагаемая работа**
Один согласованный overlay readset на request с точной областью жизни; не делать глобальный cache по ID.

**Различающие проверки**
- Один настоящий admitted growing batch; exact/list/batch consumers; source change, corruption, pending removal, restart и pagination; равные outcomes и счёт bytes/parses.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Что сохранить**
Foreign/stale/tampered inputs отказывают; page size не выдаётся за bounded total work.

Пакетная граница: Один generation/readset на request с теми же stale/foreign/tamper и pagination outcomes.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/42.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high selected-method cost; admitted population reachability source-only; уверенность распределения: Источник и контракт прочитаны; размещение предложено аналитически; актуальный HEAD, reachability и выполненные проверки не подтверждены..
- Ограничения: - R excludes trace-only/no-packet rows.
- ArtifactRef/outer cache/caller fixture; full projection CAS/admission unrun.
- Bytes are application reads, not physical storage traffic.
- Примечания к распределению: Нет дополнительных.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## SG-01 · История jobs и запросы run сканируют общие retained tables

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R7.4; механизм: SG-01.
- Основное окно: **AFTER-12**. Вторичные checkpoints: DST-01 перед PostgreSQL acceptance; DUR-02 preservation при shared file edits; Не превращать schema parity в proof всех query plans.
- Владелец механизма: Существующие SQLite/PostgreSQL control-plane schema и query owners.
- Владелец интеграционной приёмки: Один координатор E02 и существующий владелец указанного механизма; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: DUR-02 (LANE-06). Дополнение: ADDON::SG-01 (не официальный E02 ID).
- Основание: Точный общий control_plane_store.py с DUR-02; индексы и parity относятся к стоимости SQL, не требуют повторной разработки lease/fence lifecycle.
- Первый rebind checkpoint: AFTER-12. Режим: Условная performance/backend qualification.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Добавить/квалифицировать targeted indexes и миграции для exact run/job queries на реальном retained denominator; не ждать compaction или directory moves.

Граница patch: Index-only candidates не требуют compaction/sharding; сохранить cardinality и ambiguity.

### Условия и зависимости
Gate: **Условная performance/backend qualification**. Раннее окно при измеренном нарушении выбранного latency/capacity envelope. Отсутствие трёх PostgreSQL индексов не доказывает functional failure; реальные планы обоих backends обязательны.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

Дополнение для выбранного пути:
**Предлагаемая работа**
Добавить/квалифицировать targeted indexes и миграции для exact run/job queries на реальном retained denominator; не ждать compaction или directory moves.

**Различающие проверки**
- SQLite и PostgreSQL EXPLAIN/plans до/после; действительная migrated DB; создание duplicates всё ещё отказывает; ambiguity нескольких completed runs не выбирается произвольно; restart/readback.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Что сохранить**
Транзакционные scopes, uniqueness, run/tenant isolation и fence behavior остаются.

Пакетная граница: Plans и миграции на обоих backends; дубликаты creation и неоднозначный completed run по-прежнему отвергаются.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/44.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high_local; уверенность распределения: Источник и контракт прочитаны; размещение предложено аналитически; актуальный HEAD, reachability и выполненные проверки не подтверждены..
- Ограничения: see primary report; bounded evidence does not establish operational incidence
- Примечания к распределению: Нет дополнительных.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## SG-02 · Page limit и watermark не ограничивают SQL работу outbox

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R7.5; механизм: SG-02.
- Основное окно: **AFTER-12**. Вторичные checkpoints: STATE-02 если меняется application/ack boundary; DST-01 PostgreSQL profile; DUR-02 exact shared file owner.
- Владелец механизма: Существующий control-plane outbox SQL reader/delivery owner.
- Владелец интеграционной приёмки: Один координатор E02 и существующий владелец указанного механизма; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: DUR-02 (LANE-06). Дополнение: ADDON::SG-02 (не официальный E02 ID).
- Основание: Page limit/frozen watermark не гарантируют bounded SQL work; correctness outbox/STATE-02 — отдельное обязательство.
- Первый rebind checkpoint: AFTER-12. Режим: Performance correction с сохранением delivery semantics.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Оптимизировать actual query/lease path отдельно от invalidation owner и acknowledgement repair.

Граница patch: Outbox, lease и versioned migration — отдельные patches одного transaction owner.

### Условия и зависимости
Gate: **Performance correction с сохранением delivery semantics**. Раннее окно только если выбранная outbox нагрузка препятствует приёмке; не менять watermark/retry ради быстрых synthetic numbers.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

Дополнение для выбранного пути:
**Предлагаемая работа**
Оптимизировать actual query/lease path отдельно от invalidation owner и acknowledgement repair.

**Различающие проверки**
- Real SQLite/PostgreSQL query plans; backlog/retained history; frozen watermark, retries, fairness, duplicates и drain outcomes одинаковы; total examined rows учтён.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Что сохранить**
Incomplete targets не получают final ack; оптимизация не закрывает STATE-02 автоматически.

Пакетная граница: Frozen watermark/retries/fairness сохраняются; completed history после ANALYZE учитывается; constructor work отдельно от per-request.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/45.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high_local; уверенность распределения: Источник и контракт прочитаны; размещение предложено аналитически; актуальный HEAD, reachability и выполненные проверки не подтверждены..
- Ограничения: see primary report; bounded evidence does not establish operational incidence
- Примечания к распределению: Нет дополнительных.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## SG-03 · Открытие migrated store повторяет census и backfill

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R7.5; механизм: SG-03.
- Основное окно: **AFTER-12**. Вторичные checkpoints: DUR-02 shared store writer; Final installed profile при изменившейся schema/migration; Не смешивать с SG-01 index-only patch.
- Владелец механизма: Существующий control-plane schema migration/startup owner.
- Владелец интеграционной приёмки: Один координатор E02 и существующий владелец указанного механизма; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: DUR-02 (LANE-06). Дополнение: ADDON::SG-03 (не официальный E02 ID).
- Основание: Повторный census/backfill уже migrated store — startup cost, отличный от per-request query cost.
- Первый rebind checkpoint: AFTER-12. Режим: Оптимизация migration/startup.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Избежать повторного полного backfill после доказанной миграции; сохранить возможность корректного обновления partial/old state.

Граница patch: Outbox, lease и versioned migration — отдельные patches одного transaction owner.

### Условия и зависимости
Gate: **Оптимизация migration/startup**. Раньше только при measured restart/startup requirement; отсутствие аварии не заменяет миграционные negative controls.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

Дополнение для выбранного пути:
**Предлагаемая работа**
Избежать повторного полного backfill после доказанной миграции; сохранить возможность корректного обновления partial/old state.

**Различающие проверки**
- Fresh/old/partial/already-migrated DB; crash/restart; repeated constructor; corrupted/missing migration metadata; exact unchanged final rows и separate startup counters.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Что сохранить**
Незавершённая миграция не маскируется cached done bit.

Пакетная граница: Frozen watermark/retries/fairness сохраняются; completed history после ANALYZE учитывается; constructor work отдельно от per-request.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/46.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high_local_mechanism; уверенность распределения: Источник и контракт прочитаны; размещение предложено аналитически; актуальный HEAD, reachability и выполненные проверки не подтверждены..
- Ограничения: see primary report; bounded evidence does not establish operational incidence
- Примечания к распределению: Нет дополнительных.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## SG-04 · Стоимость LIMIT 1 зависит от planner и распределения истории

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R7.5; механизм: SG-04.
- Основное окно: **AFTER-12**. Вторичные checkpoints: DST-01 PostgreSQL qualification; DUR-02 lifecycle preservation.
- Владелец механизма: Существующий delivery candidate/lease SQL owner.
- Владелец интеграционной приёмки: Один координатор E02 и существующий владелец указанного механизма; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: DUR-02 (LANE-06). Дополнение: ADDON::SG-04 (не официальный E02 ID).
- Основание: LIMIT 1 не гарантирует bounded candidate work; результат зависит от distribution и ANALYZE. Не делать вывод по одному no-statistics плану.
- Первый rebind checkpoint: AFTER-12. Режим: Performance correction с проверкой planner distributions.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Проверить подходящие query/index изменения на фиксированном active backlog при растущей completed history и на обратном распределении.

Граница patch: Outbox, lease и versioned migration — отдельные patches одного transaction owner.

### Условия и зависимости
Gate: **Performance correction с проверкой planner distributions**. Раньше только при actual lease scheduler envelope; сначала native profile/данные выбранного backend.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

Дополнение для выбранного пути:
**Предлагаемая работа**
Проверить подходящие query/index изменения на фиксированном active backlog при растущей completed history и на обратном распределении.

**Различающие проверки**
- До/после ANALYZE; active и completed denominators отдельно; LIMIT1 outcomes/fairness/lease fence; retry/concurrent takers; real backend plans.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Что сохранить**
Не ослаблять fairness/current lease predicates ради apparent O(1).

Пакетная граница: Frozen watermark/retries/fairness сохраняются; completed history после ANALYZE учитывается; constructor work отдельно от per-request.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/47.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high_local_select_only; уверенность распределения: Источник и контракт прочитаны; размещение предложено аналитически; актуальный HEAD, reachability и выполненные проверки не подтверждены..
- Ограничения: see primary report; bounded evidence does not establish operational incidence
- Примечания к распределению: Нет дополнительных.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## ST-01 · Каждое изменение owner сохраняет полное поколение истории

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R7.6; механизм: ST-01.
- Основное окно: **AFTER-12**. Вторичные checkpoints: STATE-01/selected finalization preservation; R11.3 checkpoint closure при affected path; CAS-01 source lease; final artifact refresh.
- Владелец механизма: Существующий Core ownership history/storage owner.
- Владелец интеграционной приёмки: Один координатор E02 и существующий владелец указанного механизма; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: CAS-01 (LANE-06). Дополнение: ADDON::ST-01 (не официальный E02 ID).
- Основание: Полные поколения сознательно сохраняют custody history. Compaction — изменение storage/history contract, не быстрый косметический fix.
- Первый rebind checkpoint: AFTER-12. Режим: Оптимизация storage после сохранения history proof.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Выбрать отдельный compaction/index/history retention contract; квалифицировать producer→publication→restart→historical proof.

Граница patch: Сначала read-transaction reuse; отдельное позднее решение retained representation/compaction. RR-01 уже внутри ST-02.

### Условия и зависимости
Gate: **Оптимизация storage после сохранения history proof**. Раньше только при измеренном disk/storage envelope для реального CAS; не удалять историю для уменьшения synthetic bytes.

Нет дополнительных.

Исходные зависимости: [{"package": "R1.1", "relation": "preserve_selected_finalization_contract"}, {"package": "R11.3", "relation": "preserve_checkpoint_lineage_contract"}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Native real CAS default/blob/view/lineage claims, storage budgets, restart/crash, duplicates, corruption and retained historical proof.

Дополнение для выбранного пути:
**Предлагаемая работа**
Выбрать отдельный compaction/index/history retention contract; квалифицировать producer→publication→restart→historical proof.

**Различающие проверки**
- Native default/blob/view/lineage CAS; bounded storage budgets; duplicate owner additions; crash/corruption/restart; retained historical proof и currentness.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Что сохранить**
Исторический proof не становится current permit; revocation/corruption не исчезают.

Пакетная граница: Same-size/mtime corruption и other writer/currentness отказывают; history proof/readback и crash recovery сохраняются после изменения storage.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/48.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high mechanism; production rate unknown; уверенность распределения: Источник и контракт прочитаны; размещение предложено аналитически; актуальный HEAD, reachability и выполненные проверки не подтверждены..
- Ограничения: No CAS blob/manifest writes or full publication transaction. Deliberate custody history design, no data-loss/SLA incident demonstrated.
- Примечания к распределению: Нет дополнительных.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## ST-02 · Точный тёплый lookup читает всё поколение ownership

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R7.6; механизм: ST-02.
- Основное окно: **AFTER-12**. Вторичные checkpoints: STATE-01 exact finalize/currentness preservation; R11.3 fresh checkpoint claims; DA-08 только affected consumer bindings.
- Владелец механизма: Существующий Core ownership exact reader и request-local read context.
- Владелец интеграционной приёмки: Один координатор E02 и существующий владелец указанного механизма; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: CAS-01 (LANE-06), CAS-02 (LANE-06), CAS-03 (LANE-06), ING-02 (LANE-08). Дополнение: ADDON::ST-02 (не официальный E02 ID).
- Основание: Повторное полное чтение при warm lookup можно уменьшать узким request-scoped reuse; это независимо от большого compaction ST-01.
- Первый rebind checkpoint: AFTER-12. Режим: Условная request-local performance correction.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Выделить reuse в пределах одного согласованного запроса/поколения; не пропускать external writer changes или same-size/mtime corruption.

Граница patch: Сначала read-transaction reuse; отдельное позднее решение retained representation/compaction. RR-01 уже внутри ST-02.

### Условия и зависимости
Gate: **Условная request-local performance correction**. Раннее bounded окно допустимо при реальном bottleneck, если immutable request readset и corruption/currentness controls заранее определены; не ждать ST-01.

Нет дополнительных.

Исходные зависимости: [{"package": "R1.1", "relation": "preserve_selected_finalization_contract"}, {"package": "R11.3", "relation": "preserve_checkpoint_lineage_contract"}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Real CAS call graph byte counters; corruption, concurrency, pending transactions, owner/profile/cell/lineage and revocation controls.

Дополнение для выбранного пути:
**Предлагаемая работа**
Выделить reuse в пределах одного согласованного запроса/поколения; не пропускать external writer changes или same-size/mtime corruption.

**Различающие проверки**
- Real CAS call graph counters; corruption при тех же size/mtime; competing writer; pending transaction; tenant/cell/profile/lineage/revocation; restart; равные selected refs.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Что сохранить**
Не заменять verification глобальным trust cache; RR-01 дополнительное evidence этой же карточки, не второй finding.

Пакетная граница: Same-size/mtime corruption и other writer/currentness отказывают; history proof/readback и crash recovery сохраняются после изменения storage.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/49.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high measured byte/heap cost; уверенность распределения: Источник и контракт прочитаны; размещение предложено аналитически; актуальный HEAD, reachability и выполненные проверки не подтверждены..
- Ограничения: One legitimate bulk-seeded generation, synthetic claims, no artifact manifests or full API. Bytes are application reads, not physical disk traffic. Heap is incremental Python allocation, not total RSS/leak.
- Примечания к распределению: Нет дополнительных.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## FE-01 · Поздний refresh возвращает старую сессию после смены или clear

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R8.1; механизм: FE-01.
- Основное окно: **AFTER-12**. Вторичные checkpoints: DA-08: только затронутые фактически выбранные paths.
- Владелец механизма: Runtime dashboard authSession owner.
- Владелец интеграционной приёмки: Owner actual dashboard session UI. Именной исполнитель ещё не назначен.
- E02: Прямой пакет оставшегося E02 не установлен. Дополнение: ADDON::FE-01 (не официальный E02 ID).
- Основание: Асинхронная сессия имеет свой generation owner вне оставшихся numerical E02 packages. Это самостоятельный frontend repair с немедленным переносом вперёд при actual dashboard acceptance.
- Первый rebind checkpoint: AFTER-12. Режим: PULL_FORWARD_IF_SELECTED_CONSUMER.
- Если условие не активно: Остаётся AFTER-12 только если этот UI не участвует в обещанной E02/поставочной приёмке
- Граница связи: Самостоятельное ADDON исходного owner. Указанные E02 packages, если есть, только возможные selected-consumer context; существующий TEST не считается покрытием нового finding.

### Предлагаемое действие
Один session generation owner: invalidate pending refresh при clear/new token; terminal error/rejection обязан выводить состояние из refreshing.

Граница patch: Auth/origin/Clerk — три местных owners. Generation fence не исправляет fetch-rejection transition автоматически.

### Условия и зависимости
Gate: **PULL_FORWARD_IF_SELECTED_CONSUMER**. До приёмки/поставки dashboard session refresh path; не объявлять server authorization bypass и не блокировать независимый backend proof.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

Дополнение для выбранного пути:
- Refresh A→clear; A→install B; старые success/rejection после новой generation.
- Проверить реальный browser/session integration, retry/reconnect; допустимый current refresh работает, поздний callback ничего не публикует.
- Не добавлять второй auth owner; не сохранять реальные credentials в evidence.

Пакетная граница: Каждый result/error/event path сравнивает контекст; error/empty/current различимы; UI не объявляет physical stop/backend authority.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/50.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high for exact module body; UI account-transition reachability partial; уверенность распределения: medium_document_grounded_current_route_unverified.
- Ограничения: Injected logger/Vite config/window/document/fetch, Node24 type stripping; no real account/token/provider.
- Примечания к распределению: Нет дополнительных.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## FE-04 · Поздний ответ прежнего API origin перезаписывает новое состояние

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R8.1; механизм: FE-04.
- Основное окно: **AFTER-12**. Вторичные checkpoints: DA-08: только затронутые фактически выбранные paths.
- Владелец механизма: Runtime reference-shell selected origin/client owner.
- Владелец интеграционной приёмки: Owner reference-shell consumer; HYG-04 сохраняет actual app, CLI-01 лишь wire companion. Именной исполнитель ещё не назначен.
- E02: HYG-04 (LANE-12), CLI-01 (LANE-12). Дополнение: ADDON::FE-04 (не официальный E02 ID).
- Основание: Поздний ответ origin A перезаписывает UI после выбора B; CLI wire generation не исправляет mutable state lifecycle. HYG-04 app preservation не является доказательством закрытия.
- Первый rebind checkpoint: AFTER-12. Режим: PULL_FORWARD_IF_SELECTED_CONSUMER.
- Если условие не активно: AFTER-12 самостоятельный frontend window, если reference-shell не участвует в текущей поставочной claim
- Граница связи: Самостоятельное ADDON исходного owner. Указанные E02 packages, если есть, только возможные selected-consumer context; существующий TEST не считается покрытием нового finding.

### Предлагаемое действие
Один selected-client/request generation fence применять ко всем asynchronous publication paths. Abort экономит ресурс, но не заменяет identity check.

Граница patch: Auth/origin/Clerk — три местных owners. Generation fence не исправляет fetch-rejection transition автоматически.

### Условия и зависимости
Gate: **PULL_FORWARD_IF_SELECTED_CONSUMER**. До приёмки reference-shell multiple-origin list/timeline/debug/artifact flow, если этот UI выбран; отдельные native client tests продолжаются.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

Дополнение для выбранного пути:
- Задержанный A, выбранный и отрисованный B, затем поздний A: состояние остаётся B.
- Согласовать list/timeline/debug/artifact, stale failures и reset; настоящий browser+generated client integration.

Пакетная граница: Каждый result/error/event path сравнивает контекст; error/empty/current различимы; UI не объявляет physical stop/backend authority.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/53.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high for async handler behavior; уверенность распределения: medium_document_grounded_current_route_unverified.
- Ограничения: Actual app body/client with synthetic fetch and DOM writes, not browser.
- Примечания к распределению: Нет дополнительных.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## DA-01 · Application ownership находится под HTTP transport

- Тип: Архитектура и повторное использование. Работа: architecture_or_reuse_decision_not_automatic_refactor.
- Remediation unit: R9.3; механизм: DA-01.
- Основное окно: **AFTER-12**. Вторичные checkpoints: Earlier affected path if live reconciliation demonstrates dependency; Re-freeze artifact after any later source patch.
- Владелец механизма: Существующие Runtime/DataForge/Scientist/Foundry package и public-surface owners.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: HYG-02 (LANE-12), DFK-01 (LANE-12), HYG-04 (LANE-12). Дополнение: ADDON::DA-01 (не официальный E02 ID).
- Основание: По умолчанию post-E02 structural/design decision; применимые preservation guards действуют уже сейчас. Архитектурное наблюдение не является общей блокировкой defect acceptance.
- Первый rebind checkpoint: AFTER-12. Режим: CONTRACT_OR_OPTIONAL_REFACTOR_DECISION.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
До необязательных физических переносов определить application/read-build/presentation ownership и public contract. Отделить behavior fix от directory move. Если E02 уже затрагивает поверхность, применить identity/import/lifecycle preservation без расширения scope.

Граница patch: Четыре независимых owner-specific изменения. Сначала finite exports/maps, затем только обоснованные moves.

### Условия и зависимости
Gate: **CONTRACT_OR_OPTIONAL_REFACTOR_DECISION**. Блокировка возникает только из доказанного конфликта текущего контракта либо запланированного несовместимого move. Глубина каталогов, naming или census сами по себе не создают blocker.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R11.2", "to": "R9.3", "kind": "path_identity_migration", "reason": "If relocating versioned kernels, update qualified binding/history rather than silently re-resolve."}
- {"from": "R11.1", "to": "R9.3", "kind": "path_identity_migration", "reason": "Class module/qualname contributes identity; finite aliases do not excuse stale registry identity."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Finite imports/FQN, one transaction owner, unchanged refusal and lifecycle.

Дополнение для выбранного пути:
**Предлагаемая работа**
До необязательных физических переносов определить application/read-build/presentation ownership и public contract. Отделить behavior fix от directory move. Если E02 уже затрагивает поверхность, применить identity/import/lifecycle preservation без расширения scope.

**E02 context, не автоматическое покрытие**
- E02-I12-A
- DA-05

**Исходная приёмка**
Finite imports/FQN, one transaction owner, unchanged refusal and lifecycle.

**Что сохранить**
Сохранить canonical class/FQN identity, lazy imports, historical receipts, installed resources, одного mutable/transaction owner и legitimate facades. Не выводить 147 eager cycles, скрытые writes каждого read, dead code или разрешение на удаление.

Пакетная граница: Canonical object identity, lazy imports, installed resources, __file__ roots, qualnames и historical receipts после migration проверены.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/57.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: Selected source census, unresolved parsers; no runtime failure.
- Примечания к распределению: Do not infer 147 eager cycles, hidden writes on every read, dead code or permission to delete. HYG/DFK references are preservation contexts, not a blanket mandate to perform these moves.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## DA-02 · Поверхность read API также предоставляет build операции

- Тип: Архитектура и повторное использование. Работа: architecture_or_reuse_decision_not_automatic_refactor.
- Remediation unit: R9.3; механизм: DA-02.
- Основное окно: **AFTER-12**. Вторичные checkpoints: Earlier affected path if live reconciliation demonstrates dependency; Re-freeze artifact after any later source patch.
- Владелец механизма: Существующие Runtime/DataForge/Scientist/Foundry package и public-surface owners.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: HYG-02 (LANE-12), DFK-01 (LANE-12), HYG-04 (LANE-12). Дополнение: ADDON::DA-02 (не официальный E02 ID).
- Основание: По умолчанию post-E02 structural/design decision; применимые preservation guards действуют уже сейчас. Архитектурное наблюдение не является общей блокировкой defect acceptance.
- Первый rebind checkpoint: AFTER-12. Режим: CONTRACT_OR_OPTIONAL_REFACTOR_DECISION.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
До необязательных физических переносов определить application/read-build/presentation ownership и public contract. Отделить behavior fix от directory move. Если E02 уже затрагивает поверхность, применить identity/import/lifecycle preservation без расширения scope.

Граница patch: Четыре независимых owner-specific изменения. Сначала finite exports/maps, затем только обоснованные moves.

### Условия и зависимости
Gate: **CONTRACT_OR_OPTIONAL_REFACTOR_DECISION**. Блокировка возникает только из доказанного конфликта текущего контракта либо запланированного несовместимого move. Глубина каталогов, naming или census сами по себе не создают blocker.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R11.2", "to": "R9.3", "kind": "path_identity_migration", "reason": "If relocating versioned kernels, update qualified binding/history rather than silently re-resolve."}
- {"from": "R11.1", "to": "R9.3", "kind": "path_identity_migration", "reason": "Class module/qualname contributes identity; finite aliases do not excuse stale registry identity."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Filesystem mutation/removal controls, read-only consumers, import compatibility.

Дополнение для выбранного пути:
**Предлагаемая работа**
До необязательных физических переносов определить application/read-build/presentation ownership и public contract. Отделить behavior fix от directory move. Если E02 уже затрагивает поверхность, применить identity/import/lifecycle preservation без расширения scope.

**E02 context, не автоматическое покрытие**
- E02-I12-A
- DA-05

**Исходная приёмка**
Filesystem mutation/removal controls, read-only consumers, import compatibility.

**Что сохранить**
Сохранить canonical class/FQN identity, lazy imports, historical receipts, installed resources, одного mutable/transaction owner и legitimate facades. Не выводить 147 eager cycles, скрытые writes каждого read, dead code или разрешение на удаление.

Пакетная граница: Canonical object identity, lazy imports, installed resources, __file__ roots, qualnames и historical receipts после migration проверены.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/58.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: Not hidden side effect accusation or proof every read writes.
- Примечания к распределению: Do not infer 147 eager cycles, hidden writes on every read, dead code or permission to delete. HYG/DFK references are preservation contexts, not a blanket mandate to perform these moves.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## DA-03 · Физически разделённые модули снова соединяют mutable namespace

- Тип: Архитектура и повторное использование. Работа: architecture_or_reuse_decision_not_automatic_refactor.
- Remediation unit: R9.3; механизм: DA-03.
- Основное окно: **AFTER-12**. Вторичные checkpoints: Earlier affected path if live reconciliation demonstrates dependency; Re-freeze artifact after any later source patch.
- Владелец механизма: Существующие Runtime/DataForge/Scientist/Foundry package и public-surface owners.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: HYG-02 (LANE-12), DFK-01 (LANE-12), HYG-04 (LANE-12). Дополнение: ADDON::DA-03 (не официальный E02 ID).
- Основание: По умолчанию post-E02 structural/design decision; применимые preservation guards действуют уже сейчас. Архитектурное наблюдение не является общей блокировкой defect acceptance.
- Первый rebind checkpoint: AFTER-12. Режим: CONTRACT_OR_OPTIONAL_REFACTOR_DECISION.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
До необязательных физических переносов определить application/read-build/presentation ownership и public contract. Отделить behavior fix от directory move. Если E02 уже затрагивает поверхность, применить identity/import/lifecycle preservation без расширения scope.

Граница patch: Четыре независимых owner-specific изменения. Сначала finite exports/maps, затем только обоснованные moves.

### Условия и зависимости
Gate: **CONTRACT_OR_OPTIONAL_REFACTOR_DECISION**. Блокировка возникает только из доказанного конфликта текущего контракта либо запланированного несовместимого move. Глубина каталогов, naming или census сами по себе не создают blocker.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R11.2", "to": "R9.3", "kind": "path_identity_migration", "reason": "If relocating versioned kernels, update qualified binding/history rather than silently re-resolve."}
- {"from": "R11.1", "to": "R9.3", "kind": "path_identity_migration", "reason": "Class module/qualname contributes identity; finite aliases do not excuse stale registry identity."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Fresh import permutations, object/class/FQN identity, legacy aliases and installed surfaces.

Дополнение для выбранного пути:
**Предлагаемая работа**
До необязательных физических переносов определить application/read-build/presentation ownership и public contract. Отделить behavior fix от directory move. Если E02 уже затрагивает поверхность, применить identity/import/lifecycle preservation без расширения scope.

**E02 context, не автоматическое покрытие**
- E02-I12-A
- DA-05

**Исходная приёмка**
Fresh import permutations, object/class/FQN identity, legacy aliases and installed surfaces.

**Что сохранить**
Сохранить canonical class/FQN identity, lazy imports, historical receipts, installed resources, одного mutable/transaction owner и legitimate facades. Не выводить 147 eager cycles, скрытые writes каждого read, dead code или разрешение на удаление.

Пакетная граница: Canonical object identity, lazy imports, installed resources, __file__ roots, qualnames и historical receipts после migration проверены.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/59.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: No particular installed failure; preserve useful facades rather than flatten.
- Примечания к распределению: Do not infer 147 eager cycles, hidden writes on every read, dead code or permission to delete. HYG/DFK references are preservation contexts, not a blanket mandate to perform these moves.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## GR-04 · Обход affected nodes всё ещё материализует полный target vector

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R7.7; механизм: GR-04.
- Основное окно: **AFTER-12**. Вторичные checkpoints: R6.3 GR-01/02; R6.2 GR-03 content freshness; Final actual consumer only when activated.
- Владелец механизма: Существующий Runtime epoch graph/generation resolver.
- Владелец интеграционной приёмки: Один координатор E02 и существующий владелец указанного механизма; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: Прямой пакет оставшегося E02 не установлен. Дополнение: ADDON::GR-04 (не официальный E02 ID).
- Основание: Affected traversal всё ещё строит полный target vector. До ускорения нужны correctness GR-01/02/03 и exact selected-view/profile semantics.
- Первый rebind checkpoint: AFTER-12. Режим: Performance после графовой корректности.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Квалифицировать delta/affected cone materialization с полным учётом hash/vector work, не обещать O(affected) по одному traversal count.

Граница patch: Current full resolver остаётся oracle; identity/topology корректность раньше ускорения.

### Условия и зависимости
Gate: **Performance после графовой корректности**. Раньше только при измеренном актуальном cascade bottleneck; optional optimization не блокирует независимый работающий consumer.

Нет дополнительных.

Исходные зависимости: [{"package": "R6.3", "relation": "hard_semantic_prerequisite"}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R6.3", "to": "R7.7", "kind": "hard_semantic_precondition", "reason": "Correct selected-view keys and traversal before cone optimization."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

Дополнение для выбранного пути:
**Предлагаемая работа**
Квалифицировать delta/affected cone materialization с полным учётом hash/vector work, не обещать O(affected) по одному traversal count.

**Различающие проверки**
- Delta/add/remove; profiles/topology; bounded traversal; equivalence full vector; cycles могут затрагивать весь graph; actual materialization/hash denominator.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Что сохранить**
Historical/corrupt/missing checks и точный selected-view denominator остаются.

Пакетная граница: Delta/removal/profile/topology equivalence и полная стоимость materialization/hash измерены; O(affected) без этого не заявлять.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/66.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high; уверенность распределения: Источник и контракт прочитаны; размещение предложено аналитически; актуальный HEAD, reachability и выполненные проверки не подтверждены..
- Ограничения: see primary report; bounded evidence does not establish operational incidence
- Примечания к распределению: Нет дополнительных.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## SG-PG-01 · PostgreSQL schema не содержит три secondary index из SQLite

- Тип: Пробел квалификации. Работа: qualification_not_automatic_code_fix.
- Remediation unit: R7.4; механизм: SG-PG-01.
- Основное окно: **AFTER-12**. Вторичные checkpoints: DST-01 перед PostgreSQL acceptance; DUR-02 preservation при shared file edits; Не превращать schema parity в proof всех query plans.
- Владелец механизма: Существующие SQLite/PostgreSQL control-plane schema и query owners.
- Владелец интеграционной приёмки: Один координатор E02 и существующий владелец указанного механизма; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: DUR-02 (LANE-06). Дополнение: ADDON::SG-PG-01 (не официальный E02 ID).
- Основание: Точный общий control_plane_store.py с DUR-02; индексы и parity относятся к стоимости SQL, не требуют повторной разработки lease/fence lifecycle.
- Первый rebind checkpoint: AFTER-12. Режим: Условная performance/backend qualification.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Добавить/квалифицировать targeted indexes и миграции для exact run/job queries на реальном retained denominator; не ждать compaction или directory moves.

Граница patch: Index-only candidates не требуют compaction/sharding; сохранить cardinality и ambiguity.

### Условия и зависимости
Gate: **Условная performance/backend qualification**. Раннее окно при измеренном нарушении выбранного latency/capacity envelope. Отсутствие трёх PostgreSQL индексов не доказывает functional failure; реальные планы обоих backends обязательны.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

Дополнение для выбранного пути:
**Предлагаемая работа**
Добавить/квалифицировать targeted indexes и миграции для exact run/job queries на реальном retained denominator; не ждать compaction или directory moves.

**Различающие проверки**
- SQLite и PostgreSQL EXPLAIN/plans до/после; действительная migrated DB; создание duplicates всё ещё отказывает; ambiguity нескольких completed runs не выбирается произвольно; restart/readback.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Что сохранить**
Транзакционные scopes, uniqueness, run/tenant isolation и fence behavior остаются.

Пакетная граница: Plans и миграции на обоих backends; дубликаты creation и неоднозначный completed run по-прежнему отвергаются.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/68.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high_source_only; уверенность распределения: Источник и контракт прочитаны; размещение предложено аналитически; актуальный HEAD, reachability и выполненные проверки не подтверждены..
- Ограничения: see primary report; bounded evidence does not establish operational incidence
- Примечания к распределению: Нет дополнительных.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## ST-03 · Quota wrapper дважды сканирует CAS под mutation lock

- Тип: Риск или устойчивость. Работа: risk_qualification_then_bounded_repair_if_supported.
- Remediation unit: R7.8; механизм: ST-03.
- Основное окно: **AFTER-12**. Вторичные checkpoints: R0/DST выбранное окружение; Не наследовать обязательство CAS-01 лишь по слову CAS.
- Владелец механизма: Существующий compatibility tenant CAS quota wrapper.
- Владелец интеграционной приёмки: Один координатор E02 и существующий владелец указанного механизма; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: Прямой пакет оставшегося E02 не установлен. Дополнение: ADDON::ST-03 (не официальный E02 ID).
- Основание: Двойной scan под lock — ограниченный риск/стоимость; literal product callers кроме resolver/re-export не найдены. Нельзя объявить весь CAS quota path сломанным.
- Первый rebind checkpoint: AFTER-12. Режим: Квалификация выбранного wrapper до оптимизации.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Проверить actual native mutation/quota/reconciliation contract, затем решать incremental accounting вместо полного scan.

Граница patch: Сначала подтвердить настоящий consumer, потом incremental accounting в том же owner.

### Условия и зависимости
Gate: **Квалификация выбранного wrapper до оптимизации**. Раннее окно только при подтверждённом использовании wrapper и реальном quota/concurrency requirement; иначе квалифицировать отдельно после E02.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Native multi-process wrappers, duplicate/import/view/signature members, warn/block/failure/restart and external-change reconciliation; independent metadata/control-state budget.

Дополнение для выбранного пути:
**Предлагаемая работа**
Проверить actual native mutation/quota/reconciliation contract, затем решать incremental accounting вместо полного scan.

**Различающие проверки**
- Multiprocess real writes; duplicate/import/view/signature entries; warn/block/failure/restart; external changes; overflow; metadata/control-state budget отдельно.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Что сохранить**
Не отключать census без корректной замены; ownership history явно не входит в документированный byte quota.

Пакетная граница: Concurrent native writes/reconciliation/overflow/quota controls с ограниченным repair scan; не отключать census без замены.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/69.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high wrapper mechanism; live product reachability unestablished; уверенность распределения: Источник и контракт прочитаны; размещение предложено аналитически; актуальный HEAD, reachability и выполненные проверки не подтверждены..
- Ограничения: Compatibility wrapper, no direct product callers found beyond resolver/re-export. Constructor/quota enforcer/CAS writer fixtures, not native put/quotas/overflow or deployed concurrency. Ownership history explicitly excluded from documented byte quota.
- Примечания к распределению: Нет дополнительных.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## AB-03 · Legacy LangGraph adapter и base dependencies требуют решения

- Тип: Архитектура и повторное использование. Работа: architecture_or_reuse_decision_not_automatic_refactor.
- Remediation unit: R9.4; механизм: AB-03.
- Основное окно: **AFTER-12**. Вторичные checkpoints: Earlier affected path if live reconciliation demonstrates dependency; Re-freeze artifact after any later source patch.
- Владелец механизма: Существующие legacy public-surface/dependency и DataForge asset/batch owners.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: Прямой пакет оставшегося E02 не установлен. Дополнение: ADDON::AB-03 (не официальный E02 ID).
- Основание: По умолчанию bounded retirement/contract decision после E02. Возможный behavioral risk активного пути рассматривается отдельно от необязательной архитектурной очистки.
- Первый rebind checkpoint: AFTER-12. Режим: CONTRACT_OR_OPTIONAL_REFACTOR_DECISION.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Установить actual supported/external/dynamic consumers и определить stream-step/full-run либо declared-versus-real batch contract. Удалять только доказанно ненужную compatibility surface по migration/exit criteria.

Граница patch: LangGraph optional/deprecation и metadata asset policy — отдельные решения.

### Условия и зависимости
Gate: **CONTRACT_OR_OPTIONAL_REFACTOR_DECISION**. Если текущий E02 действительно вызывает repeated-effects path или зависит от несовместимой scaffold semantics, перенести узкую correction раньше. В остальных случаях не блокировать E02 этой очисткой.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: supported graph stream modes; single-step versus full-run contract; repeated invocation; minimal/runtime cold import without legacy stack; downstream deprecation

Дополнение для выбранного пути:
**Предлагаемая работа**
Установить actual supported/external/dynamic consumers и определить stream-step/full-run либо declared-versus-real batch contract. Удалять только доказанно ненужную compatibility surface по migration/exit criteria.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Исходная приёмка**
- supported graph stream modes
- single-step versus full-run contract
- repeated invocation
- minimal/runtime cold import without legacy stack
- downstream deprecation

**Что сохранить**
Сохранить receipt-bound real batch orchestration, resume semantics, public exports и minimal/runtime import guarantees. Symbol census не разрешает удалять legacy dependencies; locked LangGraph integration не квалифицирован.

Пакетная граница: Consumer/public API census, installed compatibility и существующий receipt-bound batch сохраняются; нет удаления лишь по grep.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/70.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: Real locked LangGraph integration, external users, dependency removal savings
- Примечания к распределению: No permission to uninstall legacy dependencies merely from symbol census; real locked LangGraph integration was not qualified.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## AB-04 · Декларативный asset scaffold отличается от реальной batch orchestration

- Тип: Архитектура и повторное использование. Работа: architecture_or_reuse_decision_not_automatic_refactor.
- Remediation unit: R9.4; механизм: AB-04.
- Основное окно: **AFTER-12**. Вторичные checkpoints: Earlier affected path if live reconciliation demonstrates dependency; Re-freeze artifact after any later source patch.
- Владелец механизма: Существующие legacy public-surface/dependency и DataForge asset/batch owners.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: Прямой пакет оставшегося E02 не установлен. Дополнение: ADDON::AB-04 (не официальный E02 ID).
- Основание: По умолчанию bounded retirement/contract decision после E02. Возможный behavioral risk активного пути рассматривается отдельно от необязательной архитектурной очистки.
- Первый rebind checkpoint: AFTER-12. Режим: CONTRACT_OR_OPTIONAL_REFACTOR_DECISION.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Установить actual supported/external/dynamic consumers и определить stream-step/full-run либо declared-versus-real batch contract. Удалять только доказанно ненужную compatibility surface по migration/exit criteria.

Граница patch: LangGraph optional/deprecation и metadata asset policy — отдельные решения.

### Условия и зависимости
Gate: **CONTRACT_OR_OPTIONAL_REFACTOR_DECISION**. Если текущий E02 действительно вызывает repeated-effects path или зависит от несовместимой scaffold semantics, перенести узкую correction раньше. В остальных случаях не блокировать E02 этой очисткой.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: declared versus actual stage mapping; missing/extra declaration; shared-writer receipts; resume modified input/output; public export compatibility

Дополнение для выбранного пути:
**Предлагаемая работа**
Установить actual supported/external/dynamic consumers и определить stream-step/full-run либо declared-versus-real batch contract. Удалять только доказанно ненужную compatibility surface по migration/exit criteria.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Исходная приёмка**
- declared versus actual stage mapping
- missing/extra declaration
- shared-writer receipts
- resume modified input/output
- public export compatibility

**Что сохранить**
Сохранить receipt-bound real batch orchestration, resume semantics, public exports и minimal/runtime import guarantees. Symbol census не разрешает удалять legacy dependencies; locked LangGraph integration не квалифицирован.

Пакетная граница: Consumer/public API census, installed compatibility и существующий receipt-bound batch сохраняются; нет удаления лишь по grep.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/71.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: External users, all dynamic calls, native migration equivalence
- Примечания к распределению: No permission to uninstall legacy dependencies merely from symbol census; real locked LangGraph integration was not qualified.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## AB-KEEP · Сохранить существующее повторное использование с отдельными владельцами

- Тип: Архитектура и повторное использование. Работа: architecture_or_reuse_decision_not_automatic_refactor.
- Remediation unit: R9.7; механизм: AB-KEEP.
- Основное окно: **AFTER-12**. Вторичные checkpoints: Earlier affected path if live reconciliation demonstrates dependency; Re-freeze artifact after any later source patch.
- Владелец механизма: Существующие domain owners, использующие GenericRegistry/BaseRegistry, LinearPipeline и SimpleLoopEngine.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: Прямой пакет оставшегося E02 не установлен. Дополнение: ADDON::AB-KEEP (не официальный E02 ID).
- Основание: Положительное существующее reuse следует сохранять сейчас. Это неоднородный набор safeguards, не mandatory remediation и не единый DDM пакет.
- Первый rebind checkpoint: AFTER-12. Режим: NON_DEFECT_PRESERVATION.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Сохранить полезное reuse GenericRegistry/BaseRegistry, LinearPipeline и SimpleLoopEngine с отдельными domain owners. Нового обязательного patch нет; проверять preservation только для реально затронутого consumer.

Граница patch: Ledger сохранения/решений, не обязательная кодовая переделка.

### Условия и зависимости
Gate: **NON_DEFECT_PRESERVATION**. Не blocker и не самостоятельное требование переписывать код. При изменении конкретного adopting consumer его preservation становится частью того patch.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: typed domain admission; public FQN identity; lifecycle/version semantics; actual N6 partial outcome custody

Дополнение для выбранного пути:
**Предлагаемая работа**
Сохранить полезное reuse GenericRegistry/BaseRegistry, LinearPipeline и SimpleLoopEngine с отдельными domain owners. Нового обязательного patch нет; проверять preservation только для реально затронутого consumer.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Исходная приёмка**
- typed domain admission
- public FQN identity
- lifecycle/version semantics
- actual N6 partial outcome custody

**Что сохранить**
Сохранить typed domain admission, canonical public FQN identity, lifecycle/version semantics и фактическую N6 partial-result custody. GenericRegistry indexer/hook exception safety остаётся prerequisite перед расширением reuse; этот pass его не переквалифицирует.

Пакетная граница: Owner выбирает estimand при необходимости; AUC refusal/dependency contract и domain registry/pipeline policy сохранены.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/72.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: Full native consumer execution; GenericRegistry exception-safety prerequisite remains from earlier audit
- Примечания к распределению: Неоднородный набор положительного reuse. Нет общей привязки к DDM, AUC, ML dependencies или numerical performance; whole workflows/semantic registries не заменяются generic primitives.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## DA-04 · Название Orchestrator скрывает роль presentation owner

- Тип: Архитектура и повторное использование. Работа: architecture_or_reuse_decision_not_automatic_refactor.
- Remediation unit: R9.3; механизм: DA-04.
- Основное окно: **AFTER-12**. Вторичные checkpoints: Earlier affected path if live reconciliation demonstrates dependency; Re-freeze artifact after any later source patch.
- Владелец механизма: Существующие Runtime/DataForge/Scientist/Foundry package и public-surface owners.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: HYG-02 (LANE-12), DFK-01 (LANE-12), HYG-04 (LANE-12). Дополнение: ADDON::DA-04 (не официальный E02 ID).
- Основание: По умолчанию post-E02 structural/design decision; применимые preservation guards действуют уже сейчас. Архитектурное наблюдение не является общей блокировкой defect acceptance.
- Первый rebind checkpoint: AFTER-12. Режим: CONTRACT_OR_OPTIONAL_REFACTOR_DECISION.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
До необязательных физических переносов определить application/read-build/presentation ownership и public contract. Отделить behavior fix от directory move. Если E02 уже затрагивает поверхность, применить identity/import/lifecycle preservation без расширения scope.

Граница patch: Четыре независимых owner-specific изменения. Сначала finite exports/maps, затем только обоснованные moves.

### Условия и зависимости
Gate: **CONTRACT_OR_OPTIONAL_REFACTOR_DECISION**. Блокировка возникает только из доказанного конфликта текущего контракта либо запланированного несовместимого move. Глубина каталогов, naming или census сами по себе не создают blocker.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R11.2", "to": "R9.3", "kind": "path_identity_migration", "reason": "If relocating versioned kernels, update qualified binding/history rather than silently re-resolve."}
- {"from": "R11.1", "to": "R9.3", "kind": "path_identity_migration", "reason": "Class module/qualname contributes identity; finite aliases do not excuse stale registry identity."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Actual launcher navigation and public import stability.

Дополнение для выбранного пути:
**Предлагаемая работа**
До необязательных физических переносов определить application/read-build/presentation ownership и public contract. Отделить behavior fix от directory move. Если E02 уже затрагивает поверхность, применить identity/import/lifecycle preservation без расширения scope.

**E02 context, не автоматическое покрытие**
- E02-I12-A
- DA-05

**Исходная приёмка**
Actual launcher navigation and public import stability.

**Что сохранить**
Сохранить canonical class/FQN identity, lazy imports, historical receipts, installed resources, одного mutable/transaction owner и legitimate facades. Не выводить 147 eager cycles, скрытые writes каждого read, dead code или разрешение на удаление.

Пакетная граница: Canonical object identity, lazy imports, installed resources, __file__ roots, qualnames и historical receipts после migration проверены.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/73.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: Not dead code, outage or permission for deletion.
- Примечания к распределению: Do not infer 147 eager cycles, hidden writes on every read, dead code or permission to delete. HYG/DFK references are preservation contexts, not a blanket mandate to perform these moves.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## LIB-03 · Шесть weighted quantile функций реализуют три разных estimand

- Тип: Архитектура и повторное использование. Работа: architecture_or_reuse_decision_not_automatic_refactor.
- Remediation unit: R9.7; механизм: LIB-03.
- Основное окно: **AFTER-12**. Вторичные checkpoints: Earlier affected path if live reconciliation demonstrates dependency; Re-freeze artifact after any later source patch.
- Владелец механизма: Отдельные numerical domain owners weighted-quantile estimands.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: Прямой пакет оставшегося E02 не установлен. Дополнение: ADDON::LIB-03 (не официальный E02 ID).
- Основание: Необязательный reuse после E02 либо отдельное решение numerical owner. Три разных estimand не являются шестью одинаковыми дефектами.
- Первый rebind checkpoint: AFTER-12. Режим: CONTRACT_OR_OPTIONAL_REFACTOR_DECISION.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Сохранить три различимых quantile contracts. Объединять только семантически эквивалентные kernels после выбора owner, native DTO/guard/precision/golden tests и доказательства практической пользы.

Граница patch: Ledger сохранения/решений, не обязательная кодовая переделка.

### Условия и зависимости
Gate: **CONTRACT_OR_OPTIONAL_REFACTOR_DECISION**. Конкретному caller может раньше понадобиться адресное policy decision. Широкая дедупликация не является prerequisite E02.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: 500 bounded finite-positive cases plus nine named boundaries, real conformal wrapper; additionally native importer/DTO/precision/golden threshold tests and declared policy for zeros/nonfinite/q clamp.

Дополнение для выбранного пути:
**Предлагаемая работа**
Сохранить три различимых quantile contracts. Объединять только семантически эквивалентные kernels после выбора owner, native DTO/guard/precision/golden tests и доказательства практической пользы.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Исходная приёмка**
500 bounded finite-positive cases plus nine named boundaries, real conformal wrapper; additionally native importer/DTO/precision/golden threshold tests and declared policy for zeros/nonfinite/q clamp.

**Что сохранить**
Сохранить conformal correction/ESS, zero/nonfinite/q-range semantics, prior import isolation и domain ownership. Шесть функций не являются whole-repo census; один NumPy API не заменяет все определения.

Пакетная граница: Owner выбирает estimand при необходимости; AUC refusal/dependency contract и domain registry/pipeline policy сохранены.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/74.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: Whole estimators, native imports, all weighted-quantile consumers/census.
- Примечания к распределению: Six inspected functions are not a whole-repo census; one NumPy weighted API cannot replace all definitions.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## LIB-04 · Сохранить выбранный AUC contract и отказ для одного класса

- Тип: Архитектура и повторное использование. Работа: architecture_or_reuse_decision_not_automatic_refactor.
- Remediation unit: R9.7; механизм: LIB-04.
- Основное окно: **AFTER-12**. Вторичные checkpoints: Earlier affected path if live reconciliation demonstrates dependency; Re-freeze artifact after any later source patch.
- Владелец механизма: Существующий DDM realized-performance AUC/metric owner.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: DDM-02 (LANE-11). Дополнение: ADDON::LIB-04 (не официальный E02 ID).
- Основание: Сохранить сейчас; обязательного remediation нет. Возможна отдельная performance работа после E02, если настоящий workload оправдает её.
- Первый rebind checkpoint: AFTER-12. Режим: NON_DEFECT_PRESERVATION.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Оставить действующий AUC contract и one-class refusal. Альтернативный kernel рассматривать только после измерения настоящего workload с заранее заданным latency/error benefit; не навязывать новую ML dependency.

Граница patch: Ledger сохранения/решений, не обязательная кодовая переделка.

### Условия и зависимости
Gate: **NON_DEFECT_PRESERVATION**. Не blocker. Если другой patch затрагивает этот путь, соответствующие preservation controls входят в его приёмку.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Real DDM workload demonstrates benefit; predeclared acceptance such as >=2x kernel improvement at actual window sizes without extra cold latency, matching ties/errors and no swallowed undefined estimate. Native metric-to-event/registry flow must preserve refusal.

Дополнение для выбранного пути:
**Предлагаемая работа**
Оставить действующий AUC contract и one-class refusal. Альтернативный kernel рассматривать только после измерения настоящего workload с заранее заданным latency/error benefit; не навязывать новую ML dependency.

**E02 context, не автоматическое покрытие**
- E02-I11-B

**Исходная приёмка**
Real DDM workload demonstrates benefit; predeclared acceptance such as >=2x kernel improvement at actual window sizes without extra cold latency, matching ties/errors and no swallowed undefined estimate. Native metric-to-event/registry flow must preserve refusal.

**Что сохранить**
Сохранить one-class refusal, typed domain admission и candidate/authority separation. Равенство AUC point estimates не квалифицирует confidence interval, monitor, budget, registry или field performance.

Пакетная граница: Owner выбирает estimand при необходимости; AUC refusal/dependency contract и domain registry/pipeline policy сохранены.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/75.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: Native monitor event/budget/registry flow and deployment-scale performance.
- Примечания к распределению: AUC point-estimate equivalence does not qualify CI, monitor, budget, registry or field performance. E02-I11-B association applies to the DDM LIB-04 path, not every AB-KEEP owner.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## NR-02 · Shadow metric projection теряет полный вложенный путь

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R9.6; механизм: NR-02.
- Основное окно: **AFTER-12**. Вторичные checkpoints: DA-02 read/build boundary preservation при touched public API; Не назначать автоматически E02 DFI/UDF owner без actual caller.
- Владелец механизма: Существующие DataForge academic/catalog/legal/Ukraine shadow compare owners.
- Владелец интеграционной приёмки: Один координатор E02 и существующий владелец указанного механизма; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: Прямой пакет оставшегося E02 не установлен. Дополнение: ADDON::NR-02 (не официальный E02 ID).
- Основание: Информационная path-collision ошибка показана на трёх typed compare surfaces. Это не доказанный admission/publication gate; low-scope correction не требует нового общего DataForge framework.
- Первый rebind checkpoint: AFTER-12. Режим: Conditional correctness: earlier только при использовании affected shadow report.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Выбрать tuple/escaped path grammar, сохранить domain projection/DTO и versioned serialized diff. Missing→zero, int precision и nonfinite policy решать явно.

Граница patch: NR-02 repair у DataForge отдельно от NR-05 consolidation у Foundry; kernels/RNG не объединять.

### Условия и зависимости
Gate: **Conditional correctness: earlier только при использовании affected shadow report**. Перед честной приёмкой nested metric-diff consumer, если он активен; иначе отдельный post-E02 patch.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native real loaders and typed compares; path escaping/tuple paths; insertion order; missing/zero/nonfinite/int precision

Дополнение для выбранного пути:
**Предлагаемая работа**
Выбрать tuple/escaped path grammar, сохранить domain projection/DTO и versioned serialized diff. Missing→zero, int precision и nonfinite policy решать явно.

**Различающие проверки**
- Native typed compare и real persisted loaders; dotted vs nested collision в обоих insertion orders; missing/zero; 2^53 boundary; bool/list/nonfinite; independent artifact/readiness changes.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Что сохранить**
Ukraine table_counts не принимает nested witness; не распространять его на четыре domains. Artifact checksum может отдельно показать change.

Пакетная граница: Escaped/tuple paths, missing/zero/nonfinite/precision, threshold/ties и actual typed compare/results проверены.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/76.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high for bounded witness; native and production qualification unrun; уверенность распределения: Источник и контракт прочитаны; размещение предложено аналитически; актуальный HEAD, reachability и выполненные проверки не подтверждены..
- Ограничения: see primary report; bounded evidence does not establish operational incidence
- Примечания к распределению: Нет дополнительных.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## NR-03 · Повторно использовать полный artifact view identity key

- Тип: Архитектура и повторное использование. Работа: architecture_or_reuse_decision_not_automatic_refactor.
- Remediation unit: R9.5; механизм: NR-03.
- Основное окно: **AFTER-12**. Вторичные checkpoints: Preserve при LANE-10 uncertainty changes; I12-A installed compatibility если move принят.
- Владелец механизма: Core artifact_ref_identity_key и отдельные Foundry calibration/execution/uncertainty consumers.
- Владелец интеграционной приёмки: Один координатор E02 и существующий владелец указанного механизма; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: UQS-01 (LANE-10). Дополнение: ADDON::NR-03 (не официальный E02 ID).
- Основание: Положительный reuse candidate, не defect. Exact overlap с UQS-01 по uncertainty/aggregator.py не делает консолидацию обязательной для E02.
- Первый rebind checkpoint: AFTER-12. Режим: Необязательный reuse; preservation при соседнем patch.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Переиспользовать только полный four-field key через type-safe seam; при необходимости сохранить локальные wrappers/FQN.

Граница patch: Четыре независимых leaf contracts; NR-03/04 reuse candidates, не новые дефекты.

### Условия и зависимости
Gate: **Необязательный reuse; preservation при соседнем patch**. Не blocker. Ранее допустим только маленький согласованный patch, если он действительно упрощает уже нужное изменение без смешения типов.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: actual Core/IR typed refs; typecheck/import checks; selected-view dedup and profile tamper controls

Дополнение для выбранного пути:
**Предлагаемая работа**
Переиспользовать только полный four-field key через type-safe seam; при необходимости сохранить локальные wrappers/FQN.

**Различающие проверки**
- Native Core/IR refs; typecheck/import policy; artifact/kind/media/profile differences; absent profile; tampered selected manifest; repeated-view dedup.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Что сохранить**
Identity key не authority/nominal DTO conversion; не сокращать до digest и не добавлять Core→IR обратный import.

Пакетная граница: Structured long-graph report; full-view identity; discovery errors/order; nullable sentinel semantics; actual adopting consumers.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/77.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high for bounded witness; native and production qualification unrun; уверенность распределения: Источник и контракт прочитаны; размещение предложено аналитически; актуальный HEAD, reachability и выполненные проверки не подтверждены..
- Ограничения: see primary report; bounded evidence does not establish operational incidence
- Примечания к распределению: Нет дополнительных.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## NR-04 · Повторно использовать Core entry point enumeration

- Тип: Архитектура и повторное использование. Работа: architecture_or_reuse_decision_not_automatic_refactor.
- Remediation unit: R9.5; механизм: NR-04.
- Основное окно: **AFTER-12**. Вторичные checkpoints: LANE-04 plugin changes только при установленном общем consumer; I12-A installed metadata qualification если adopted.
- Владелец механизма: Существующий Core entry-point enumeration и Foundry MethodDiscovery.
- Владелец интеграционной приёмки: Один координатор E02 и существующий владелец указанного механизма; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: Прямой пакет оставшегося E02 не установлен. Дополнение: ADDON::NR-04 (не официальный E02 ID).
- Основание: Положительный narrow reuse, не defect. Foundry domain plugin discovery уже использует Core, но не надо считать его тем же MethodDiscovery owner.
- Первый rebind checkpoint: AFTER-12. Режим: Необязательный maintenance reuse.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Тонкий forwarding enumeration seam с прежним order/error envelope; domain plugin coercion и per-entry processing оставить.

Граница patch: Четыре независимых leaf contracts; NR-03/04 reuse candidates, не новые дефекты.

### Условия и зависимости
Gate: **Необязательный maintenance reuse**. Не blocker. При затрагивании discovery в E02 использовать существующие controls, не запускать новый framework проект.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native installed metadata discovery; cold import and monkeypatch seams; real plugin error path

Дополнение для выбранного пути:
**Предлагаемая работа**
Тонкий forwarding enumeration seam с прежним order/error envelope; domain plugin coercion и per-entry processing оставить.

**Различающие проверки**
- Реальные stdlib EntryPoint; five provider modes; enumeration failure; native installed metadata/load error; cold import/monkeypatch seams.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Что сохранить**
Arbitrary metadata-shaped impostors не объявлять эквивалентными; propagated enumeration failure не глотать.

Пакетная граница: Structured long-graph report; full-view identity; discovery errors/order; nullable sentinel semantics; actual adopting consumers.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/78.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high for bounded witness; native and production qualification unrun; уверенность распределения: Источник и контракт прочитаны; размещение предложено аналитически; актуальный HEAD, reachability и выполненные проверки не подтверждены..
- Ограничения: see primary report; bounded evidence does not establish operational incidence
- Примечания к распределению: Нет дополнительных.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## NR-05 · Объединить эквивалентные leaf formatters causal importance

- Тип: Архитектура и повторное использование. Работа: architecture_or_reuse_decision_not_automatic_refactor.
- Remediation unit: R9.6; механизм: NR-05.
- Основное окно: **AFTER-12**. Вторичные checkpoints: LANE-05 causal owners если реально затронуты; Final artifact refresh при принятом move.
- Владелец механизма: Три локальных causal feature-importance formatter owners.
- Владелец интеграционной приёмки: Один координатор E02 и существующий владелец указанного механизма; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: Прямой пакет оставшегося E02 не установлен. Дополнение: ADDON::NR-05 (не официальный E02 ID).
- Основание: Совпали leaf projections, не estimators. Необязательная консолидация после завершения содержательных numerical repairs.
- Первый rebind checkpoint: AFTER-12. Режим: Необязательный local reuse.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Объединить только formatter при доказанной выгоде и совместимости; statistical effect-sensitivity, RNG и homogeneous suppression сохранить у callers.

Граница patch: NR-02 repair у DataForge отдельно от NR-05 consolidation у Foundry; kernels/RNG не объединять.

### Условия и зависимости
Gate: **Необязательный local reuse**. Не blocker; лишь preservation при текущем изменении actual causal caller.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native method/result DTO outputs with threshold, ties, provider errors and unchanged RNG ownership

Дополнение для выбранного пути:
**Предлагаемая работа**
Объединить только formatter при доказанной выгоде и совместимости; statistical effect-sensitivity, RNG и homogeneous suppression сохранить у callers.

**Различающие проверки**
- Native method/result DTO; threshold/nextafter/ties; invalid/nonfinite arrays; provider errors; method labels; неизменный RNG ownership.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Что сохранить**
Predictive permutation_importance не drop-in causal effect-sensitivity; full estimator ветки не объединять.

Пакетная граница: Escaped/tuple paths, missing/zero/nonfinite/precision, threshold/ties и actual typed compare/results проверены.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/79.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high for bounded witness; native and production qualification unrun; уверенность распределения: Источник и контракт прочитаны; размещение предложено аналитически; актуальный HEAD, reachability и выполненные проверки не подтверждены..
- Ограничения: see primary report; bounded evidence does not establish operational incidence
- Примечания к распределению: Нет дополнительных.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## NR-06 · LRU delete удаляет None но сообщает отсутствие

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R9.5; механизм: NR-06.
- Основное окно: **AFTER-12**. Вторичные checkpoints: Ранее при новом R9/Core cache adoption; Не назначать STA-02/NodeResultCache blocker без реального delete consumer.
- Владелец механизма: Core LRUCache presence/delete contract.
- Владелец интеграционной приёмки: Один координатор E02 и существующий владелец указанного механизма; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: Прямой пакет оставшегося E02 не установлен. Дополнение: ADDON::NR-06 (не официальный E02 ID).
- Основание: Локальный nullable delete defect подтверждён; maintained NodeResultCache хранит ArtifactRef и использует pop, поэтому текущий E02 cache incident не установлен.
- Первый rebind checkpoint: AFTER-12. Режим: Prerequisite до нового nullable LRU reuse.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Sentinel-based presence semantics и bounded native regression; отдельное решение об adoption.

Граница patch: Четыре независимых leaf contracts; NR-03/04 reuse candidates, не новые дефекты.

### Условия и зависимости
Gate: **Prerequisite до нового nullable LRU reuse**. Исправить до расширения reuse на nullable values либо если найден реальный consumer delete(None). Иначе не блокирует existing nonnullable/pop path.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: sentinel-based presence regression under supported profile; real adopting consumers

Дополнение для выбранного пути:
**Предлагаемая работа**
Sentinel-based presence semantics и bounded native regression; отдельное решение об adoption.

**Различающие проверки**
- Stored None/False/0/empty list/dict; absent key; actual adopting consumer; capacity/order/stats и failures сохранены.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Что сохранить**
Generic LRU не принимает authority, generation, reader pins, physical I/O tokens или single-flight owners.

Пакетная граница: Structured long-graph report; full-view identity; discovery errors/order; nullable sentinel semantics; actual adopting consumers.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/80.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high for bounded witness; native and production qualification unrun; уверенность распределения: Источник и контракт прочитаны; размещение предложено аналитически; актуальный HEAD, reachability и выполненные проверки не подтверждены..
- Ограничения: see primary report; bounded evidence does not establish operational incidence
- Примечания к распределению: Нет дополнительных.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## UI-01 · Clerk activity не принадлежит конкретному поколению conversation

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R8.1; механизм: UI-01.
- Основное окно: **AFTER-12**. Вторичные checkpoints: DA-08: только затронутые фактически выбранные paths.
- Владелец механизма: Runtime dashboard Clerk conversation/state owner.
- Владелец интеграционной приёмки: Owner actual Clerk browser conversation. Именной исполнитель ещё не назначен.
- E02: Прямой пакет оставшегося E02 не установлен. Дополнение: ADDON::UI-01 (не официальный E02 ID).
- Основание: Pending launch и SSE callbacks не привязаны к generation conversation. Это отдельная UI ownership задача; backend run/custody gates не заменяют её.
- Первый rebind checkpoint: AFTER-12. Режим: PULL_FORWARD_IF_SELECTED_CONSUMER.
- Если условие не активно: AFTER-12 только если Clerk UI не является действующим consumer выбранной E02 claim
- Граница связи: Самостоятельное ADDON исходного owner. Указанные E02 packages, если есть, только возможные selected-consumer context; существующий TEST не считается покрытием нового finding.

### Предлагаемое действие
Привязать launch success/failure и SSE terminal publication к conversation generation/identity; stale callback не меняет новую pending работу.

Граница patch: Auth/origin/Clerk — три местных owners. Generation fence не исправляет fetch-rejection transition автоматически.

### Условия и зависимости
Gate: **PULL_FORWARD_IF_SELECTED_CONSUMER**. До приёмки активного Clerk reset/new-session/launch/SSE consumer; backend launch correctness отдельно.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Browser reset/newSession/navigation/unmount/reconnect, stale success/failure и old-terminal/new-pending; persistence refusal.

Дополнение для выбранного пути:
- Browser reset/newSession/navigation/unmount/reconnect; stale success/failure после нового launch.
- Old terminal SSE во время нового pending launch не сбрасывает streaming; persistence после reset не восстанавливает старый runId.
- Сохранить существующие identity layout gate и scoped envelopes.

Пакетная граница: Каждый result/error/event path сравнивает контекст; error/empty/current различимы; UI не объявляет physical stop/backend authority.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/96.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high for source hook mechanism; native lifecycle unrun; уверенность распределения: medium_document_grounded_current_route_unverified.
- Ограничения: Source action bodies с заменёнными ports, не native React/Zustand/browser; identity layout gate и scoped envelope существуют.
- Примечания к распределению: Нет дополнительных.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## UI-02 · История run не различает ошибку и пустой текущий список

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R8.1; механизм: UI-02.
- Основное окно: **AFTER-12**. Вторичные checkpoints: DA-08: только затронутые фактически выбранные paths.
- Владелец механизма: Runtime dashboard ClerkHistoryList/React Query owner.
- Владелец интеграционной приёмки: Owner actual Clerk history UI. Именной исполнитель ещё не назначен.
- E02: Прямой пакет оставшегося E02 не установлен. Дополнение: ADDON::UI-02 (не официальный E02 ID).
- Основание: Локально история не различает error/empty/current, хотя global incidents уже существуют. Это UI outcome contract, а не полностью скрытый сбой всего приложения.
- Первый rebind checkpoint: AFTER-12. Режим: PULL_FORWARD_IF_SELECTED_CONSUMER.
- Если условие не активно: AFTER-12 самостоятельный UI repair, если этот consumer не выбран раньше
- Граница связи: Самостоятельное ADDON исходного owner. Указанные E02 packages, если есть, только возможные selected-consumer context; существующий TEST не считается покрытием нового finding.

### Предлагаемое действие
В существующем owner представить loading/error/empty/current; учитывать stale data + error и имеющиеся global incidents, без нового notification framework.

Граница patch: Auth/origin/Clerk — три местных owners. Generation fence не исправляет fetch-rejection transition автоматически.

### Условия и зависимости
Gate: **PULL_FORWARD_IF_SELECTED_CONSUMER**. До приёмки выбранного history UI contract. Не приписывать cross-account leakage или отсутствие глобальной диагностики.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Actual React Query transitions, stale data + error, 401/403/network и empty success.

Дополнение для выбранного пути:
- Actual React Query loading→success-empty/current/error и stale data+error.
- 401 ведёт к login, 403/network/5xx сохраняют существующие global incidents; local state показывает нужный outcome без удаления полезного stale context.

Пакетная граница: Каждый result/error/event path сравнивает контекст; error/empty/current различимы; UI не объявляет physical stop/backend authority.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/97.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high source branch; actual query transition unrun; уверенность распределения: medium_document_grounded_current_route_unverified.
- Ограничения: Global incidents покрывают network status=0, 403/5xx; 401 ведёт к login. Не whole-app silent error или cross-account leakage.
- Примечания к распределению: Нет дополнительных.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

