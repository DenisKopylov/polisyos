# Серийные corrective windows

Статус: предварительный план, не свидетельство реализации. Основных карточек: 60. Сначала получить фактический отчёт исполнителя и сверить HEAD. Один implementation lane активен; corrective window приостанавливает затронутую работу, а не запускает параллельный lane.

## Порядок работы
1. Проверить текущую ветку/HEAD, незавершённые patches, write leases и источник evidence.
2. Для каждого пункта выбрать: уже закрыт; подтвердился; изменился контракт; не воспроизведён; UNRUN; требует решения. Сохранить причину и ссылку.
3. Выполнить только согласованный bounded patch или квалификацию у существующего owner.
4. Приложить точный oracle, контроли и affected-evidence map. Не ставить PASS по наличию файла/skip/fixture.
5. Обновить статус DA только в указанной части, не переносить весь TEST/REQ.

## Состав
- AUTH-01: Словарь серверных разрешений расходится с canonical Rego
- AUTH-02: Проверяемый набор policy отличается от поставляемого chart
- STR-01: Пять долей зеркального покрытия ниже порога
- TC-01: Nightly wrapper вычисляет неверный корень продукта
- TC-03: Тестовая lane не обеспечивает заявленную зависимость OPA
- TC-04: Маркеры и selectors не совпадают с объявлениями benchmark
- TC-05: Timing oracle допускает успешную проверку при нулевой работе
- STATE-01: Восстановление finalize теряет выбранный workflow receipt
- STATE-02: Исходящий HTE outbox подтверждает неполную invalidation
- BUD-01: Повторная отмена преждевременно снимает владельца учёта расхода
- LIF-01: Отмена и ошибка после response пропускают локальный cleanup
- LIF-02: Worker сообщает stopped до завершения drain
- LIF-03: Завершение maintenance после stop допускает новый dispatch
- LIF-04: Кеш готового ответа не создаёт durable reservation
- CS-01: Jacobian запроса заменяет feedback diagnostic без смысловой связи
- LIB-01: CDF и Wasserstein теряют support распределения и grid
- scholar::RC-01: Объявленные правила зависимости не определяют число независимых evidence
- AUTH-03: Клиент OPA принимает truthy значения вместо строгого boolean
- publication-authority::PA-01: Private publication draft не проходит собственный строгий round trip
- FG-01: Проверка free grow принимает строковую ссылку вместо найденного метода
- FG-02: Cache и snapshot identity не различают изменения корпуса
- GR-01: Epoch graph объединяет разные manifest profiles
- GR-02: Ограниченный DFS теряет более короткий достижимый путь
- GR-03: Changed set не замечает изменение содержимого при прежнем profile
- NC-04a: Явно пустые bindings сохраняют прежние search enrichment
- NC-04b: Лимит одного результата скрывает известную неоднозначность
- FE-03: Alias попадает в HTML sink вместо буквального текста
- FE-06: Проверка authority parity не сравнивает state и owner surface
- AB-01: Fabric дублирует mutable DAG ownership и расходится при исключении
- AB-02: Sync и async повторяют политики preflight и finalization
- NR-01: Рекурсивная проверка provenance падает на глубоком DAG
- STR-02: Hidden edge checker зависит от формы import
- STR-03: Teardown test helper видит только одну import identity
- TC-06: Истечение quarantine не становится обязательным gate
- CS-02: Чтение sidecar не связывает child с parent в URL
- SA-01: Неоднозначная проекция schema ID в путь перезаписывает другую схему
- SA-02: Generic inference не означает governed schema admission
- SA-03: GeoJSON принимает неверную структуру а properties заменяют feature ID
- RR-02: Checkpoint не связывает state с base и полным dependency closure
- RR-03: Export и restore hook теряют tenant cell и enforcement CAS
- GE-01: Ошибка Git diff превращается в пустой набор изменений docs
- GE-02: Import subgate игнорирует переданный candidate root
- GE-03: Один README закрывает обязательства нескольких facade paths
- GE-C01: Default timing test проверяет только наличие baseline
- AR-01: REST transport теряет запрет retry и limits подключения
- AR-02: Validator отдельной страницы объявляется версией полного набора
- AR-03: Ошибки rate metadata и исчерпания retry выходят за FetchError boundary
- UI-03: Запрет API imports из features не обеспечен checker
- policy-assembly::PA-01: Сохранённый plan теряет versioned executable identity
- policy-assembly::PA-02: Typed threshold теряет исполнимое представление при lowering
- custody::RC-01: Историческое exact acceptance не проходит current state rebuilder
- DST-01: Реальная проверка PostgreSQL остаётся необязательной в CI
- DST-02: Standard Integration не объявляет inputs выбранных real corpus tests
- CR-01: Calibration adapter обходит существующие Gaussian representability guards
- CR-02: Push forward принимает tolerance за SD и повышает статус bounds
- REL-01: Свежие release jobs не получают обязательный generated snapshot
- REL-02: Release tag не связан с checkout и build source SHA
- REL-03: Evaluator принимает отсутствующий или неверный scan result за отсутствие findings
- semantic-matching::F1: Решение поиска об ambiguity и threshold теряется перед выбором плана
- semantic-matching::F2: Alias теряет связь occurrence запроса со scope выбранной метрики

## AUTH-01 · Словарь серверных разрешений расходится с canonical Rego

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R5.1; механизм: AUTH-01.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: Before actual affected release/deployment; LANE-12 only if its selected build or client path relies on this contract; DA-06 bound build evidence as relevant.
- Владелец механизма: Существующие Runtime permissions/Rego/build/deployment policy owners.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: Прямой пакет оставшегося E02 не установлен. Дополнение: ADDON::AUTH-01 (не официальный E02 ID).
- Основание: Отдельное policy/deployment corrective window до поставки затронутых grants/chart. Это условие выбранного выпуска или развёртывания, не автоматическая блокировка всей E02.
- Первый rebind checkpoint: CORRECTIVE. Режим: CONDITIONAL_RELEASE_OR_DEPLOYMENT_GATE.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Согласовать server permission vocabulary и canonical policy, отрендерить настоящий chart, связать canonical/rendered/served bytes. Выполнить real OPA mixed-grant matrix и foreign tenant/cell/attempt negatives.

Граница patch: Canonical producer, deploy projection и Runtime adapter сохраняют отдельных owners с единой parity приёмкой.

### Условия и зависимости
Gate: **CONDITIONAL_RELEASE_OR_DEPLOYMENT_GATE**. Закрыть до развёртывания затронутых новых grants или опоры на соответствующий shipped chart/policy path. Независимая code-only работа E02 может продолжаться.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R5.1", "to": "R13.1", "kind": "release_acceptance", "reason": "Shipped release acceptance includes exact canonical/rendered/served policy parity."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Actual OPA canonical and shipped bundle matrix: mixed grants launch/read/cancel and exact SQL slot; foreign tenant/cell/stale attempt negatives.

Дополнение для выбранного пути:
**Предлагаемая работа**
Согласовать server permission vocabulary и canonical policy, отрендерить настоящий chart, связать canonical/rendered/served bytes. Выполнить real OPA mixed-grant matrix и foreign tenant/cell/attempt negatives.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Исходная приёмка**
Actual OPA canonical and shipped bundle matrix: mixed grants launch/read/cancel and exact SQL slot; foreign tenant/cell/stale attempt negatives.

**Что сохранить**
Сохранить deployment-only permissions, role boundaries и независимые Python resource/ownership checks. Identity client factory не удостоверяет remote policy bytes; chart workload/mount и live endpoint не считать квалифицированными.

Пакетная граница: Реальный OPA, exact rendered/served bytes, mixed grants и foreign tenant/cell/attempt negatives; allow только bool.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/0.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: P1 before deploying these grants; source-derived fail-closed mismatch, actual OPA exit77 UNRUN, no live denial incident.
- Примечания к распределению: No chart workload/mount or live endpoint bytes were qualified. This is not a demonstrated public auth bypass.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## AUTH-02 · Проверяемый набор policy отличается от поставляемого chart

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R5.1; механизм: AUTH-02.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: Before actual affected release/deployment; LANE-12 only if its selected build or client path relies on this contract; DA-06 bound build evidence as relevant.
- Владелец механизма: Существующие Runtime permissions/Rego/build/deployment policy owners.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: Прямой пакет оставшегося E02 не установлен. Дополнение: ADDON::AUTH-02 (не официальный E02 ID).
- Основание: Отдельное policy/deployment corrective window до поставки затронутых grants/chart. Это условие выбранного выпуска или развёртывания, не автоматическая блокировка всей E02.
- Первый rebind checkpoint: CORRECTIVE. Режим: CONDITIONAL_RELEASE_OR_DEPLOYMENT_GATE.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Согласовать server permission vocabulary и canonical policy, отрендерить настоящий chart, связать canonical/rendered/served bytes. Выполнить real OPA mixed-grant matrix и foreign tenant/cell/attempt negatives.

Граница patch: Canonical producer, deploy projection и Runtime adapter сохраняют отдельных owners с единой parity приёмкой.

### Условия и зависимости
Gate: **CONDITIONAL_RELEASE_OR_DEPLOYMENT_GATE**. Закрыть до развёртывания затронутых новых grants или опоры на соответствующий shipped chart/policy path. Независимая code-only работа E02 может продолжаться.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R5.1", "to": "R13.1", "kind": "release_acceptance", "reason": "Shipped release acceptance includes exact canonical/rendered/served policy parity."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Canonical/rendered/served hash and real OPA behavior parity; canonical AUTH-01 fixed too; preserve full Python resource/ownership gates.

Дополнение для выбранного пути:
**Предлагаемая работа**
Согласовать server permission vocabulary и canonical policy, отрендерить настоящий chart, связать canonical/rendered/served bytes. Выполнить real OPA mixed-grant matrix и foreign tenant/cell/attempt negatives.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Исходная приёмка**
Canonical/rendered/served hash and real OPA behavior parity; canonical AUTH-01 fixed too; preserve full Python resource/ownership gates.

**Что сохранить**
Сохранить deployment-only permissions, role boundaries и независимые Python resource/ownership checks. Identity client factory не удостоверяет remote policy bytes; chart workload/mount и live endpoint не считать квалифицированными.

Пакетная граница: Реальный OPA, exact rendered/served bytes, mixed grants и foreign tenant/cell/attempt negatives; allow только bool.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/1.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: Chart has no workload/mount; rendered/live endpoint bytes unknown. P1 release prerequisite, not proven HTTP bypass. Exact chart source locator is resolved by source receipts.
- Примечания к распределению: No chart workload/mount or live endpoint bytes were qualified. This is not a demonstrated public auth bypass.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## STR-01 · Пять долей зеркального покрытия ниже порога

- Тип: Пробел квалификации. Работа: qualification_not_automatic_code_fix.
- Remediation unit: R0.3; механизм: STR-01.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: Before first current reliance on affected gate/profile; LANE-12 frozen source/artifact if changed; DA-08 impact-based final refresh.
- Владелец механизма: Существующие test ratchet и behavioral qualification owners.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: HYG-04 (LANE-12). Дополнение: ADDON::STR-01 (не официальный E02 ID).
- Основание: Квалификация при первом использовании, до финальной приёмки, опирающейся на этот gate. Квалификация покрытия, а не 494 новых дефекта. Указанные E02 packets являются потребляющими контекстами, не автоматически новыми implementation owners.
- Первый rebind checkpoint: CORRECTIVE. Режим: QUALIFICATION_BEFORE_RELYING_ON_GATE.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Записать фактически выбранное и выполненное поведение, добавить property-removal controls. Решение о ratchet baseline сделать прозрачным; не добавлять пустые mirror files ради процента.

Граница patch: Selection/oracle/quarantine — отдельные подзадачи; mirror gaps не чинить placeholder tests.

### Условия и зависимости
Gate: **QUALIFICATION_BEFORE_RELYING_ON_GATE**. Блокируется только приёмка, использующая затронутый gate/profile. Если он не участвует в текущих claims, более широкое исправление можно назначить отдельно.

Нет дополнительных.

Исходные зависимости: []

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Native CLI and actual selected tests; property-removal controls.

Дополнение для выбранного пути:
**Предлагаемая работа**
Записать фактически выбранное и выполненное поведение, добавить property-removal controls. Решение о ratchet baseline сделать прозрачным; не добавлять пустые mirror files ради процента.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Исходная приёмка**
Native CLI and actual selected tests; property-removal controls.

**Что сохранить**
Сохранить рабочие проверки и legitimate facades; записать exact commands, collected manifest и discriminator изменённого свойства. Не выдавать qualification gaps, риск пустого registry или mirror ratio за production incident.

Пакетная граница: Сохранён точный collected/executed manifest; no-work/removal regression отказывает; expiry policy явна.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/5.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: 494 matched source modules are not tests or defects; no native CLI.
- Примечания к распределению: Do not postpone a false-PASS checker until after using it; do not call qualification gaps, empty-registry risks or mirror ratios production defects.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## TC-01 · Nightly wrapper вычисляет неверный корень продукта

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R0.2; механизм: TC-01.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: Before first current reliance on affected gate/profile; LANE-12 frozen source/artifact if changed; DA-08 impact-based final refresh.
- Владелец механизма: Существующий nightly benchmark wrapper и release-summary owner.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: HYG-04 (LANE-12). Дополнение: ADDON::TC-01 (не официальный E02 ID).
- Основание: Квалификация при первом использовании, до финальной приёмки, опирающейся на этот gate. Корень nightly wrapper и настоящая summary-команда. Указанные E02 packets являются потребляющими контекстами, не автоматически новыми implementation owners.
- Первый rebind checkpoint: CORRECTIVE. Режим: QUALIFICATION_BEFORE_RELYING_ON_GATE.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Выполнить wrapper с фактическим summary path и проверить failure propagation; тяжёлый benchmark квалифицировать отдельно.

Граница patch: Разные checker owners и разные причины; общей новой надстройки не требуется.

### Условия и зависимости
Gate: **QUALIFICATION_BEFORE_RELYING_ON_GATE**. Блокируется только приёмка, использующая затронутый gate/profile. Если он не участвует в текущих claims, более широкое исправление можно назначить отдельно.

Нет дополнительных.

Исходные зависимости: []

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Native wrapper with actual summary path; benchmark отдельно.

Дополнение для выбранного пути:
**Предлагаемая работа**
Выполнить wrapper с фактическим summary path и проверить failure propagation; тяжёлый benchmark квалифицировать отдельно.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Исходная приёмка**
Native wrapper with actual summary path; benchmark отдельно.

**Что сохранить**
Сохранить рабочие проверки и legitimate facades; записать exact commands, collected manifest и discriminator изменённого свойства. Не выдавать qualification gaps, риск пустого registry или mirror ratio за production incident.

Пакетная граница: Неверный root/diff и пропущенная obligation различаются отрицательными контролями; допустимые facade imports сохранены.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/6.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: No hosted run or real heavy benchmark executed.
- Примечания к распределению: Do not postpone a false-PASS checker until after using it; do not call qualification gaps, empty-registry risks or mirror ratios production defects.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## TC-03 · Тестовая lane не обеспечивает заявленную зависимость OPA

- Тип: Пробел квалификации. Работа: qualification_not_automatic_code_fix.
- Remediation unit: R0.1; механизм: TC-03.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: Before first current reliance on affected gate/profile; LANE-12 frozen source/artifact if changed; DA-08 impact-based final refresh.
- Владелец механизма: Существующие environment/CI lane owners и OPA parity owner.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: CLI-01 (LANE-12). Дополнение: ADDON::TC-03 (не официальный E02 ID).
- Основание: Независимое условие среды до actual OPA parity; при необходимости связано с policy release window. Это не новый E02 пакет и не передача всех auth обязанностей CLI-01.
- Первый rebind checkpoint: CORRECTIVE. Режим: QUALIFICATION_BEFORE_RELYING_ON_GATE.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Обеспечить либо установить наличие выбранной pinned OPA версии в фактической lane. Записать executable version и canonical/shipped behavior; не подменять authorization permissive stub.

Граница patch: Environment/bootstrap, installed lane и PostgreSQL/corpus — отдельные изменения с общей приёмкой воспроизводимого профиля.

### Условия и зависимости
Gate: **QUALIFICATION_BEFORE_RELYING_ON_GATE**. При отсутствии OPA блокируются только claims, требующие его настоящего поведения. До утверждения, что CI не имеет OPA, проверить фактическую hosted image.

Нет дополнительных.

Исходные зависимости: []

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Native lane OPA version plus canonical/shipped behavior; no permissive stub.

Дополнение для выбранного пути:
**Предлагаемая работа**
Обеспечить либо установить наличие выбранной pinned OPA версии в фактической lane. Записать executable version и canonical/shipped behavior; не подменять authorization permissive stub.

**E02 context, не автоматическое покрытие**
- REQ-CLI-01-05
- TEST-CLI-01-05
- E02-I12-B

**Исходная приёмка**
Native lane OPA version plus canonical/shipped behavior; no permissive stub.

**Что сохранить**
Сохранить Python resource/ownership/currentness checks и fail-closed transport. CLI-01 refs обозначают возможный actual-service контекст, не полное владение инфраструктурой auth.

Пакетная граница: На поддерживаемом профиле действительно выполнены нужные consumers; missing backend/input явно unqualified или отказ, не PASS.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/8.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: Hosted image inventory unknown; not a fresh hosted failure.
- Примечания к распределению: CLI refs are potential affected actual-service acceptance, not evidence that CLI-01 owns all auth infrastructure.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## TC-04 · Маркеры и selectors не совпадают с объявлениями benchmark

- Тип: Пробел квалификации. Работа: qualification_not_automatic_code_fix.
- Remediation unit: R0.3; механизм: TC-04.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: Before first current reliance on affected gate/profile; LANE-12 frozen source/artifact if changed; DA-08 impact-based final refresh.
- Владелец механизма: Существующие benchmark collection/selector owners.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: HYG-04 (LANE-12). Дополнение: ADDON::TC-04 (не официальный E02 ID).
- Основание: Квалификация при первом использовании, до финальной приёмки, опирающейся на этот gate. Точный manifest сбора benchmark cases. Указанные E02 packets являются потребляющими контекстами, не автоматически новыми implementation owners.
- Первый rebind checkpoint: CORRECTIVE. Режим: QUALIFICATION_BEFORE_RELYING_ON_GATE.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Выполнить native collect-only для действительных selectors и class conventions; перечислить selected/skipped cases и провести representative execution.

Граница patch: Selection/oracle/quarantine — отдельные подзадачи; mirror gaps не чинить placeholder tests.

### Условия и зависимости
Gate: **QUALIFICATION_BEFORE_RELYING_ON_GATE**. Блокируется только приёмка, использующая затронутый gate/profile. Если он не участвует в текущих claims, более широкое исправление можно назначить отдельно.

Нет дополнительных.

Исходные зависимости: []

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Native collect-only and selected/skipped manifest plus representative execution.

Дополнение для выбранного пути:
**Предлагаемая работа**
Выполнить native collect-only для действительных selectors и class conventions; перечислить selected/skipped cases и провести representative execution.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Исходная приёмка**
Native collect-only and selected/skipped manifest plus representative execution.

**Что сохранить**
Сохранить рабочие проверки и legitimate facades; записать exact commands, collected manifest и discriminator изменённого свойства. Не выдавать qualification gaps, риск пустого registry или mirror ratio за production incident.

Пакетная граница: Сохранён точный collected/executed manifest; no-work/removal regression отказывает; expiry policy явна.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/9.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: Definitions are not parametrized case count; other equivalent tests not ruled out.
- Примечания к распределению: Do not postpone a false-PASS checker until after using it; do not call qualification gaps, empty-registry risks or mirror ratios production defects.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## TC-05 · Timing oracle допускает успешную проверку при нулевой работе

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R0.3; механизм: TC-05.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: Before first current reliance on affected gate/profile; LANE-12 frozen source/artifact if changed; DA-08 impact-based final refresh.
- Владелец механизма: Существующий benchmark result/timing oracle owner.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: HYG-04 (LANE-12). Дополнение: ADDON::TC-05 (не официальный E02 ID).
- Основание: Квалификация при первом использовании, до финальной приёмки, опирающейся на этот gate. Различение полезной работы и быстрого отказа. Указанные E02 packets являются потребляющими контекстами, не автоматически новыми implementation owners.
- Первый rebind checkpoint: CORRECTIVE. Режим: QUALIFICATION_BEFORE_RELYING_ON_GATE.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Always-raising/zero-success mutation должна провалить проверку; настоящий successful result должен проходить до интерпретации timing.

Граница patch: Selection/oracle/quarantine — отдельные подзадачи; mirror gaps не чинить placeholder tests.

### Условия и зависимости
Gate: **QUALIFICATION_BEFORE_RELYING_ON_GATE**. Блокируется только приёмка, использующая затронутый gate/profile. Если он не участвует в текущих claims, более широкое исправление можно назначить отдельно.

Нет дополнительных.

Исходные зависимости: []

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Always-raising negative must fail, real result positive must pass.

Дополнение для выбранного пути:
**Предлагаемая работа**
Always-raising/zero-success mutation должна провалить проверку; настоящий successful result должен проходить до интерпретации timing.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Исходная приёмка**
Always-raising negative must fail, real result positive must pass.

**Что сохранить**
Сохранить рабочие проверки и legitimate facades; записать exact commands, collected manifest и discriminator изменённого свойства. Не выдавать qualification gaps, риск пустого registry или mirror ratio за production incident.

Пакетная граница: Сохранён точный collected/executed manifest; no-work/removal regression отказывает; expiry policy явна.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/10.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: Synthetic timing driver, not speed measurement or entire suite verdict.
- Примечания к распределению: Do not postpone a false-PASS checker until after using it; do not call qualification gaps, empty-registry risks or mirror ratios production defects.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## STATE-01 · Восстановление finalize теряет выбранный workflow receipt

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R1.1; механизм: STATE-01.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-01; {"stage": "LANE-06", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: Core RunContext finalize journal and recovery; paths: core/run/context.py:1178-1186,1402-1499,3130-3278, runtime/http/services/adapters/core_run.py:225-322, runtime/http/services/control/run_lifecycle.py:14287-14389, core/run/context.py:1178-1186,1402-1416,1420-1499,3172-3278, runtime/http/services/adapters/core_run.py:294-303,620-629, scientist/orchestration/engine/executor.py:2560-2641; owner lanes: LANE-06.
- Владелец интеграционной приёмки: LANE-01 / CYC-02: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: CYC-02 (LANE-01), CYC-03 (LANE-01), RES-03 (LANE-06), RES-01 (LANE-06). Дополнение: ADDON::STATE-01 (не официальный E02 ID).
- Основание: Selected finalize receipt должен пережить terminal/restart, иначе ordinary persisted result/continuation не тот же принятый объект. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-01 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-01. Режим: corrective_window_before_fresh_readback.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. New supplemental contract is due at this integration phase in its declared selected scope; current HEAD may already satisfy it, to be evidenced rather than reimplemented.

### Предлагаемое действие
Сохранять выбранный workflow receipt в существующем durable finalize journal; fresh reader восстанавливает именно зафиксированный выбор, включая retry/recovery. Не подменять exact selection пересчётом или последним доступным receipt.

Граница patch: Core finalizer/journal; не выбирать receipt по порядку или количеству outputs.

### Условия и зависимости
Gate: **due_contract_gate**. Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.

- Existing core/run finalize journal + runtime adapter owner; при общей mutation source L06 окно не параллельно активному lane. Затем DA-01 affected partial route.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R1.1", "to": "R9.2", "kind": "shared_acceptance", "reason": "Shared finalization output must preserve exact journal selection."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Preserve exact selected transition in durable journal/recovery; native full producer and authenticated endpoint tests remain required. Strict consumers must not guess selection from outputs.

Дополнение для выбранного пути:
- Preserve exact selected transition in durable journal/recovery; native full producer and authenticated endpoint tests remain required. Strict consumers must not guess selection from outputs.
- После каждого durable cut и restart выбран тот же final state либо честный отказ; sync/async producers проверены.
- Real sync/async selected workflow, kill at each durable cut, reopened Runtime selects exact same state/ref. Legacy/mismatching request адресно отказаны, не заменены соседним workflow.

Пакетная граница: После каждого durable cut и restart выбран тот же final state либо честный отказ; sync/async producers проверены.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/11.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high_direct_scoped_CAS_SIGKILL_fresh_reader; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: Python 3.12 compatibility, synthetic upstream registry/workflow/state JSON, full sync/async engine and HTTP authorization not executed.
- Примечания к распределению: - Activation: Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.
- Otherwise: None
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - Fresh real scoped CAS/SIGKILL/strict reader strengthens earlier fixture result; missing selected workflow ref causes refusal/None. Non-workflow and post-terminal recovery work. No authority bypass; no native full sync/async producer or HTTP.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## STATE-02 · Исходящий HTE outbox подтверждает неполную invalidation

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R1.2; механизм: STATE-02.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-01; {"stage": "LANE-06", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: Scientist decision validity owner plus existing Runtime outbox adapter; paths: scientist/validation/decision_validity.py:343-365,489-516,1806-1840,1950-1993, runtime/http/services/control/run_lifecycle.py:13992-14095,15393-15474, scientist/nodes/builtins/decide/decision_packet/basis_sections.py:246-262; owner lanes: LANE-06.
- Владелец интеграционной приёмки: LANE-01 / CYC-03: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: CYC-03 (LANE-01), CYC-02 (LANE-01), FUN-01 (LANE-02), FUN-03 (LANE-02). Дополнение: ADDON::STATE-02 (не официальный E02 ID).
- Основание: Неоднозначное received/applied/ack invalidation подрывает current occurrence и fresh gate; не тот же state owner, что STATE-01. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-01 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-01. Режим: supplemental_currentness_owner_before_consumer.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. New supplemental contract is due at this integration phase in its declared selected scope; current HEAD may already satisfy it, to be evidenced rather than reimplemented.

### Предлагаемое действие
Связать outbox event, полный denominator targets и устойчивое подтверждение применения у каждого target. Published/ack допустим лишь после выполненной invalidation всех требуемых targets; retry идемпотентен. Одного переноса dedupe недостаточно.

Граница patch: Scientist validity владеет event/target progress, Runtime ack потребляет полный итог; это не новый глобальный transaction service.

### Условия и зависимости
Gate: **due_contract_gate**. Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.

- Закрепить event content/target denominator, durable apply/ack; R7 SQL/read optimizations не предшествуют этому контракту. Owner decision_validity/run_lifecycle один.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

Дополнение для выбранного пути:
- native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report
- Content-bound event и полный target denominator; crash/retry не теряет targets и не дублирует transitions; incomplete не получает final ack.
- Crash after each target; fresh retry applies remaining exactly once; originating outbox ack только после durable complete outcome. Force recompute не скрывает missing event.

Пакетная граница: Content-bound event и полный target denominator; crash/retry не теряет targets и не дублирует transitions; incomplete не получает final ack.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/12.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: Synthetic schema-valid HTE selection refs, minimal generic packet payloads, extracted Runtime methods, Python3.12 compatibility adapters; no public policy claim/full HTE numerical producer/authenticated HTTP.
- Примечания к распределению: - Activation: Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.
- Otherwise: None
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - Before sticky write: lost event persists after TTL/force and origin SQL ack. After sticky write: recompute can recover STALE but missing transition receipt remains. New event key can restore state. Minimal packet ACTIVE cannot be assumed for full HTE producer; typed incomplete basis yields WARNING. Notification published is not governed public signature.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## BUD-01 · Повторная отмена преждевременно снимает владельца учёта расхода

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R2.2; механизм: BUD-01.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-01; {"stage": "LANE-06", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}; {"stage": "LANE-09", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: Existing direct execution observer/budget ledger; paths: core/llm/traced_client.py:1125-1150, core/llm/traced_client.py:1152-1237, scientist/orchestration/engine/budget_middleware.py:361-370, scientist/orchestration/engine/budget_ledger.py:2360-2395; owner lanes: LANE-06, LANE-09.
- Владелец интеграционной приёмки: LANE-01 / CYC-04: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: CYC-04 (LANE-01), CYC-05 (LANE-01), RUN-01 (LANE-06), DUR-01 (LANE-06), LLM-01 (LANE-09), LLM-02 (LANE-09). Дополнение: ADDON::BUD-01 (не официальный E02 ID).
- Основание: N5/fallback exploration не может обещать корректный resource admission, если physical provider result теряет accounting owner при cancellation. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-01 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-01. Режим: corrective_window_before_resource_claim.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. New supplemental contract is due at this integration phase in its declared selected scope; current HEAD may already satisfy it, to be evidenced rather than reimplemented.

### Предлагаемое действие
Сохранить producer-owned observer до установления физического результата/расхода; повторная logical cancel не снимает единственного settlement owner. Разделить stop request, cancellation, resource release и terminal accounting.

Граница patch: Existing producer observer и budget ledger; cached positive sibling не считать уже готовым repair.

### Условия и зависимости
Gate: **due_contract_gate**. Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.

- Direct Core producer lifetime и budget ledger/middleware чинит существующий owner. Cached positive control не готовый drop-in fix. Shared R9.2 refactor позднее.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R2.2", "to": "R9.2", "kind": "lifecycle_guard", "reason": "Refactoring async/sync cannot retire physical accounting owner."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

Дополнение для выбранного пути:
- native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report
- Late response/lost ack после повторной отмены даёт один charge или явный unknown; reservation не снимается раньше reconciliation.
- Repeated cancel + late response + readback даёт ровно один известный charge либо честный unknown; нет преждевременного release/admission. Проверить public/sync и async lifetime отдельно.

Пакетная граница: Late response/lost ack после повторной отмены даёт один charge или явный unknown; reservation не снимается раньше reconciliation.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/13.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high in direct client branch; production occurrence unknown; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: see primary report; bounded evidence does not establish operational incidence
- Примечания к распределению: - Activation: Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.
- Otherwise: None
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## LIF-01 · Отмена и ошибка после response пропускают локальный cleanup

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R2.1; механизм: LIF-01.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-01; {"stage": "LANE-06", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: Runtime middleware/control worker lifecycle; paths: runtime/http/mutation_policy.py:250-282,387-637; owner lanes: LANE-06.
- Владелец интеграционной приёмки: LANE-01 / CYC-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: CYC-01 (LANE-01), CYC-04 (LANE-01), CYC-05 (LANE-01), RUN-01 (LANE-06), RUN-03 (LANE-06), DUR-02 (LANE-06). Дополнение: ADDON::LIF-01 (не официальный E02 ID).
- Основание: Ordinary HTTP/worker cancellation/stop входит в реальную served способность. ASGI local cleanup и worker dispatch/drain разные owners, не новый общий lifecycle framework. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-01 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-01. Режим: supplemental_runtime_lifecycle_repair.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. New supplemental contract is due at this integration phase in its declared selected scope; current HEAD may already satisfy it, to be evidenced rather than reimplemented.

### Предлагаемое действие
Единый локальный ownership scope освобождает slots на всех exits; unknown mutation outcome сохраняет durable domain reconcile, а не разрешение повторить effect.

Граница patch: ASGI slot cleanup и worker lifecycle — разные patches; одна интеграционная матрица shutdown.

### Условия и зависимости
Gate: **due_contract_gate**. Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.

- Сначала exact operation/slot/handler lifetime; нельзя назвать stopped живой fenced dependency. Последовательное окно прежнего owner при source overlap.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Locked ASGI cancellation before headers, body/decode/persist/audit; exact slot release, no unsafe effect retry; actual generic routes and separate NL/predictive owners.

Дополнение для выбранного пути:
- Locked ASGI cancellation before headers, body/decode/persist/audit; exact slot release, no unsafe effect retry; actual generic routes and separate NL/predictive owners.
- Повторная отмена не держит slots; после stop не возникает новый dispatch; active handler не объявлен физически завершённым.
- Cancelled POST/live-open освобождает owned slots; stop до/во время blocked maintenance запрещает новый dispatch; running work drain/status/physical finish различены; known effect accounting сохранён.

Пакетная граница: Повторная отмена не держит slots; после stop не возникает новый dispatch; active handler не объявлен физически завершённым.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/15.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: Off-lock Starlette/AnyIO; task cancellation не TCP disconnect; synthetic routes; default domain effect не выполнялся.
- Примечания к распределению: - Activation: Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.
- Otherwise: None
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## LIF-02 · Worker сообщает stopped до завершения drain

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R2.1; механизм: LIF-02.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-01; {"stage": "LANE-06", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: Runtime middleware/control worker lifecycle; paths: runtime/http/services/control_worker.py:134-143,216-333, runtime/http/container.py:970-995, runtime/http/services/control/run_lifecycle.py:9271-9289; owner lanes: LANE-06.
- Владелец интеграционной приёмки: LANE-01 / CYC-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: CYC-01 (LANE-01), CYC-04 (LANE-01), CYC-05 (LANE-01), RUN-01 (LANE-06), RUN-03 (LANE-06), DUR-02 (LANE-06). Дополнение: ADDON::LIF-02 (не официальный E02 ID).
- Основание: Ordinary HTTP/worker cancellation/stop входит в реальную served способность. ASGI local cleanup и worker dispatch/drain разные owners, не новый общий lifecycle framework. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-01 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-01. Режим: supplemental_runtime_lifecycle_repair.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. New supplemental contract is due at this integration phase in its declared selected scope; current HEAD may already satisfy it, to be evidenced rather than reimplemented.

### Предлагаемое действие
Разделить stop-admission, drain, authority revoke и physical occupancy в существующих owners; truthful draining/unknown outcome.

Граница patch: ASGI slot cleanup и worker lifecycle — разные patches; одна интеграционная матрица shutdown.

### Условия и зависимости
Gate: **due_contract_gate**. Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.

- Сначала exact operation/slot/handler lifetime; нельзя назвать stopped живой fenced dependency. Последовательное окно прежнего owner при source overlap.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Production-shaped owned/borrowed guards, handler and already-started dependency; late physical outcome retained; stale owner effects denied.

Дополнение для выбранного пути:
- Production-shaped owned/borrowed guards, handler and already-started dependency; late physical outcome retained; stale owner effects denied.
- Повторная отмена не держит slots; после stop не возникает новый dispatch; active handler не объявлен физически завершённым.
- Cancelled POST/live-open освобождает owned slots; stop до/во время blocked maintenance запрещает новый dispatch; running work drain/status/physical finish различены; known effect accounting сохранён.

Пакетная граница: Повторная отмена не держит slots; после stop не возникает новый dispatch; active handler не объявлен физически завершённым.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/16.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: Raw-store late insert не переносится на default guarded runtime; production double execution, cancellation authority и budget settlement не доказаны.
- Примечания к распределению: - Activation: Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.
- Otherwise: None
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## LIF-03 · Завершение maintenance после stop допускает новый dispatch

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R2.1; механизм: LIF-03.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-01; {"stage": "LANE-06", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: Runtime middleware/control worker lifecycle; paths: runtime/http/services/control_worker.py:179-189, runtime/http/services/control/run_lifecycle.py:7577-7583; owner lanes: LANE-06.
- Владелец интеграционной приёмки: LANE-01 / CYC-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: CYC-01 (LANE-01), CYC-04 (LANE-01), CYC-05 (LANE-01), RUN-01 (LANE-06), RUN-03 (LANE-06), DUR-02 (LANE-06). Дополнение: ADDON::LIF-03 (не официальный E02 ID).
- Основание: Ordinary HTTP/worker cancellation/stop входит в реальную served способность. ASGI local cleanup и worker dispatch/drain разные owners, не новый общий lifecycle framework. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-01 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-01. Режим: supplemental_runtime_lifecycle_repair.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. New supplemental contract is due at this integration phase in its declared selected scope; current HEAD may already satisfy it, to be evidenced rather than reimplemented.

### Предлагаемое действие
Повторная admission/stop проверка на lifecycle boundary; корректно обработать уже leased job без потери ownership.

Граница patch: ASGI slot cleanup и worker lifecycle — разные patches; одна интеграционная матрица shutdown.

### Условия и зависимости
Gate: **due_contract_gate**. Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.

- Сначала exact operation/slot/handler lifetime; нельзя назвать stopped живой fenced dependency. Последовательное окно прежнего owner при source overlap.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Barriers during maintenance, before/after lease, before invocation; separate default closed guard case.

Дополнение для выбранного пути:
- Barriers during maintenance, before/after lease, before invocation; separate default closed guard case.
- Повторная отмена не держит slots; после stop не возникает новый dispatch; active handler не объявлен физически завершённым.
- Cancelled POST/live-open освобождает owned slots; stop до/во время blocked maintenance запрещает новый dispatch; running work drain/status/physical finish различены; known effect accounting сохранён.

Пакетная граница: Повторная отмена не держит slots; после stop не возникает новый dispatch; active handler не объявлен физически завершённым.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/17.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: Synthetic maintenance/job; exact default closed-guard interleaving не выполнен.
- Примечания к распределению: - Activation: Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.
- Otherwise: None
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## LIF-04 · Кеш готового ответа не создаёт durable reservation

- Тип: Решение по контракту. Работа: contract_decision_before_any_code.
- Remediation unit: R2.4; механизм: LIF-04.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-01; {"stage": "LANE-06", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: Runtime idempotency admission owner; paths: runtime/http/mutation_policy.py:241-347,685-709; owner lanes: LANE-06.
- Владелец интеграционной приёмки: LANE-01 / CYC-04: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: CYC-04 (LANE-01), CYC-05 (LANE-01). Дополнение: ADDON::LIF-04 (не официальный E02 ID).
- Основание: В текущем owner есть response cache, а durable reservation promise требует другого подтверждённого контракта. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-01 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-01. Режим: contract_decision_not_automatic_reservation_build.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. New supplemental contract is due at this integration phase in its declared selected scope; current HEAD may already satisfy it, to be evidenced rather than reimplemented.

### Предлагаемое действие
Явно определить per-route replay guarantee; reuse existing durable domain owner там, где требуется at-most-once admission.

Граница patch: Сначала решение о продуктовой гарантии; не строить reservation subsystem для не обещанного свойства.

### Условия и зависимости
Gate: **due_contract_gate**. Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.

- До resource claim выбрать response-cache-only versus actual global reservation. Только явное второе решение разрешает дополнительную реализацию.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Two real generic endpoint workers, same/different payload, failure before/after domain effect, reopen and late completion.

Дополнение для выбранного пути:
- Two real generic endpoint workers, same/different payload, failure before/after domain effect, reopen and late completion.
- Документирована response-cache-only либо выбранная reservation гарантия; требуемая семантика проверена на crash/concurrent retry.
- Repeated/restarted concurrent calls тестируют только заявленную гарантию; remaining allocation не выдаётся за per-call reservation. Отдельно сохранить correct cached response behavior.

Пакетная граница: Документирована response-cache-only либо выбранная reservation гарантия; требуемая семантика проверена на crash/concurrent retry.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/18.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: Class is documented response cache; no actual duplicate production job or NL/predictive bypass. P1 prerequisite only if global at-most-once guarantee is intended.
- Примечания к распределению: - Activation: Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.
- Otherwise: None
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## CS-01 · Jacobian запроса заменяет feedback diagnostic без смысловой связи

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R4.1; механизм: CS-01.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-01; {"stage": "LANE-04", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: Foundry solved-state/analysis owner; Runtime request/route adapter; paths: ; owner lanes: LANE-04.
- Владелец интеграционной приёмки: LANE-01 / CYC-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: CYC-01 (LANE-01), SIM-01 (LANE-01), CYC-02 (LANE-01). Дополнение: ADDON::CS-01 (не официальный E02 ID).
- Основание: Runtime Analysis/Foundry attractor feedback is a separate producer/consumer chain; only selected N5/sidecar use makes it part of L01 acceptance. IR attach production caller not found. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-01 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-01. Режим: conditional_feedback_analysis_sidecar_window.
- Если условие не активно: after_12_standalone_analysis_repair
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. primary_stage is first integration/rebind checkpoint; implementation is due there only under activation_condition. If not active, preserve finding open and route according to otherwise_route; absence of reachability proof is not PASS.

### Предлагаемое действие
Связать feedback diagnostic с фактическим результатом, выбранной lineage/state и смыслом diagnostic; request Jacobian без семантической связи не заменяет научное evidence. Реализовать bounded join у существующих Runtime/Foundry/IR owners только для выбранного analysis пути.

Граница patch: CS-01 — diagnostic/solve join; CS-02 — отдельное API relationship решение. Не простое сравнение URL и logical ID.

### Условия и зависимости
Gate: **conditional_profile_gate**. Selected L01 capability actually uses feedback/attractor analysis or nested sidecar API. Do not treat availability as scientific/public authority.

- CS-01 semantic diagnostic join before reuse; CS-02 canonical parent-child API relation decision. No eigenvalue logic in HTTP, no strings-only URL fix.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

Дополнение для выбранного пути:
- native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report
- Foreign same-dimension diagnostic, profile/state/order/trace mismatch отвергаются; explicit reanalysis имеет новую provenance; parent route контракт честный.
- Own/omitted/foreign same-dimension Jacobian, actual trace/state/order/profile relation and full lineage survive fresh read. Own/other/malformed parent and child profile/type/tenant preserve auth; parent logical ID not blindly compared to CAS URL.

Пакетная граница: Foreign same-dimension diagnostic, profile/state/order/trace mismatch отвергаются; explicit reanalysis имеет новую provenance; parent route контракт честный.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/24.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: high_source_owner_medium_schedule_conditional.
- Ограничения: see primary report; bounded evidence does not establish operational incidence
- Примечания к распределению: - Activation: Selected L01 capability actually uses feedback/attractor analysis or nested sidecar API. Do not treat availability as scientific/public authority.
- Otherwise: after_12_standalone_analysis_repair
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - Same-dimension foreign diagnostic suffices, so dimension check alone insufficient. Actual used diagnostic ref absent from output lineage; producer own diagnostic ref is bare, not selected-profile exact. Explicit reanalysis may be valid only with typed relation/provenance. IR attach has no discovered production caller.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## LIB-01 · CDF и Wasserstein теряют support распределения и grid

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R4.4; механизм: LIB-01.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-02; {"stage": "LANE-04", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: PolicyOS owns payload meaning, support/tail policy, units, validation and versioned metric contract. SciPy owns sample/support W1 kernel.; paths: ; owner lanes: LANE-04.
- Владелец интеграционной приёмки: LANE-02 / OPT-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: OPT-01 (LANE-02), OPT-04 (LANE-02), FUN-02 (LANE-02), PLG-02 (LANE-04), PLG-03 (LANE-04). Дополнение: ADDON::LIB-01 (не официальный E02 ID).
- Основание: Confirmed World distribution metric can contaminate selected evaluation/ranking only if that actual evaluator is selected. Not a generic FRC/PCL metric. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-02 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-02. Режим: conditional_world_evaluator_corrective.
- Если условие не активно: after_12_standalone_World_repair
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. primary_stage is first integration/rebind checkpoint; implementation is due there only under activation_condition. If not active, preserve finding open and route according to otherwise_route; absence of reachability proof is not PASS.

### Предлагаемое действие
Явно определить представление support/mass/CDF и grid, затем исправить вычисление CDF/Wasserstein у существующего World evaluator. Проверять математический объект и неравномерную сетку до выбора библиотеки; подмена реализации без representation contract недостаточна.

Граница patch: Representation adapter прежде библиотеки; historical metric version сохраняется.

### Условия и зависимости
Gate: **conditional_profile_gate**. Selected E02 search/evaluation profile actually consumes distributional.cdf.wasserstein from World.evaluate. This activation is not established by audit.

- First typed support/samples/CDF-grid representation and versioned metric; then library adapter. Corrective L04 World owner before dependent OPT/FUN qualification if reached.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Producer/evaluator translation and same-grid dimensional controls must pass or reject explicitly; tests on raw unequal sample sizes; missing/descending/nonfinite grid and invalid CDF; output metric version + native World.evaluate and serialized EvaluationRun.

Дополнение для выбранного пути:
- Producer/evaluator translation and same-grid dimensional controls must pass or reject explicitly; tests on raw unequal sample sizes; missing/descending/nonfinite grid and invalid CDF; output metric version + native World.evaluate and serialized EvaluationRun.
- Sample/support/CDF-grid cases, spacing/tails/units и unequal cardinality проходят independent oracle и actual World roundtrip.
- Same and different grid spacing, affine unit scaling, unequal sample sizes, tail/invalid-CDF controls on actual World.evaluate→EvaluationRun JSON. Reevaluate affected baseline/champion values under new metric version; do not relabel old results.

Пакетная граница: Sample/support/CDF-grid cases, spacing/tails/units и unequal cardinality проходят independent oracle и actual World roundtrip.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/25.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: high_source_owner_medium_schedule_conditional.
- Ограничения: Native 3.14 imports, actual World.evaluate, persistence and downstream authority.
- Примечания к распределению: - Activation: Selected E02 search/evaluation profile actually consumes distributional.cdf.wasserstein from World.evaluate. This activation is not established by audit.
- Otherwise: after_12_standalone_World_repair
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## scholar::RC-01 · Объявленные правила зависимости не определяют число независимых evidence

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R4.3; механизм: scholar::RC-01.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-01; {"stage": "LANE-09", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: Scholar evidence independence/scorecard owner; paths: scholar_requirement/_impl/compiler.py:64-88,112-164,350-410,495-510, scholar/_impl/evidence.py:1169-1230,1359-1397,1462-1587,1679-1731, scholar/search/jobs.py:224-354,377-411, runtime/quality/scholar_academic_evidence.py:60-112; owner lanes: LANE-09.
- Владелец интеграционной приёмки: LANE-01 / ACQ-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: ACQ-01 (LANE-01), CYC-01 (LANE-01), SCL-01 (LANE-09), SCL-03 (LANE-09). Дополнение: ADDON::scholar::RC-01 (не официальный E02 ID).
- Основание: Research source effective support должен учитывать выбранную independence policy до использования его evidence; SCL byte provenance и scientific independence разные обязанности. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-01 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-01. Режим: conditional_scholar_evidence_owner_corrective.
- Если условие не активно: before_affected_evidence_claim_or_after_12
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. primary_stage is first integration/rebind checkpoint; implementation is due there only under activation_condition. If not active, preserve finding open and route according to otherwise_route; absence of reachability proof is not PASS.

### Предлагаемое действие
Reuse existing evidence relation/cluster owner with claim-scoped typed policy adapter; execute or explicitly reject every declared collapse rule; preserve source verifier and method/authority owners.

Граница patch: Не считать любую общность авторов/институтов универсальной научной зависимостью.

### Условия и зависимости
Gate: **conditional_profile_gate**. Chosen L01 source acquisition/grounding actually consumes Scholar support affected by selected dependence policy.

- Не считать общих авторов всегда зависимыми. Existing Scholar requirement/evidence/job owners сохраняют declared clustering/weights policy; не сливать с predictive/DDM calibration.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

Дополнение для выбранного пути:
- native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report
- Declared rules реально влияют на support через job/CAS/fresh reader; matched clusters и weights различаются.
- Actual job→CAS→fresh support consumer, matched independence clusters/weights, removal controls и declared-policy counterfactual. Preserve exact raw bytes и source provenance.

Пакетная граница: Declared rules реально влияют на support через job/CAS/fresh reader; matched clusters и weights различаются.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/27.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high bounded mechanism and local persisted path; operational authority consequence not established; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: - Synthetic scientific claims and metadata, no empirical paper-quality admission.
- Actual job uses recorded-bundle service, no live providers or ScholarDeepSearchService.
- Python 3.12 compatibility loader and namespace overrides, not native 3.14.
- Only selected scorecard gate bodies, not full scorecard authority/admission.
- Shared authors/institutions are not universal scientific proof of dependence; finding is declared policy consumption gap.
- Zero-weight probe uses independent singleton studies, not a matched cluster; only diagnostic plus direct static absence of field reads. Independent matched control is separate review evidence.
- Примечания к распределению: - Activation: Chosen L01 source acquisition/grounding actually consumes Scholar support affected by selected dependence policy.
- Otherwise: before_affected_evidence_claim_or_after_12
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - Five declared relation dimensions and effective_support_per_cluster not consumed. Shared authors/institutions not universal empirical dependence. Matched same-study reviewer cluster weight1 and0 both count1 removes singleton-rule-activation ambiguity. Genuine source/Scientist verifier rejects invented span.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## AUTH-03 · Клиент OPA принимает truthy значения вместо строгого boolean

- Тип: Риск или устойчивость. Работа: risk_qualification_then_bounded_repair_if_supported.
- Remediation unit: R5.1; механизм: AUTH-03.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: Before actual affected release/deployment; LANE-12 only if its selected build or client path relies on this contract; DA-06 bound build evidence as relevant.
- Владелец механизма: Существующие OPA transport/client и deployment-security owners.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: Прямой пакет оставшегося E02 не установлен. Дополнение: ADDON::AUTH-03 (не официальный E02 ID).
- Основание: Robustness подокно вместе с AUTH-01/02. Условный malformed-response риск, не установленный exploit.
- Первый rebind checkpoint: CORRECTIVE. Режим: CONDITIONAL_RELEASE_OR_DEPLOYMENT_GATE.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Принимать allow только как точный boolean true. На actual transport проверить true/false, строки false/deny, array, numeric, missing/null/timeout и правильные policy cases.

Граница patch: Canonical producer, deploy projection и Runtime adapter сохраняют отдельных owners с единой parity приёмкой.

### Условия и зависимости
Gate: **CONDITIONAL_RELEASE_OR_DEPLOYMENT_GATE**. Закрыть до приёмки malformed-response robustness выбранного OPA transport. Boolean поведение canonical Rego само по себе не доказывает внешнюю эксплуатируемость.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R5.1", "to": "R13.1", "kind": "release_acceptance", "reason": "Shipped release acceptance includes exact canonical/rendered/served policy parity."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Actual transport malformed-response controls plus true/false policy cases; preserve fail-closed transport.

Дополнение для выбранного пути:
**Предлагаемая работа**
Принимать allow только как точный boolean true. На actual transport проверить true/false, строки false/deny, array, numeric, missing/null/timeout и правильные policy cases.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Исходная приёмка**
Actual transport malformed-response controls plus true/false policy cases; preserve fail-closed transport.

**Что сохранить**
Сохранить fail-closed transport и legitimate canonical allow/deny. Caller-controlled malformed response и authentication bypass аудитом не установлены.

Пакетная граница: Реальный OPA, exact rendered/served bytes, mixed grants и foreign tenant/cell/attempt negatives; allow только bool.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/29.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: Canonical/chart Rego returns boolean; no caller-controlled response type, authentication bypass or external exploit established.
- Примечания к распределению: No caller-controlled malformed response or bypass was established.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## publication-authority::PA-01 · Private publication draft не проходит собственный строгий round trip

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R5.2; механизм: publication-authority::PA-01.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: DA-08: только затронутые фактически выбранные paths.
- Владелец механизма: Существующий governed publication artifact/codec owner; Core canonical profile owner.
- Владелец интеграционной приёмки: Owner конкретного publication preparation/reopen consumer, координатор E02 только при выбранном пути. Именной исполнитель ещё не назначен.
- E02: Прямой пакет оставшегося E02 не установлен. Дополнение: ADDON::publication-authority::PA-01 (не официальный E02 ID).
- Основание: Private governed draft writer и strict persisted reader расходятся. Оставшиеся CYC candidate/conditional paths не доказывают необходимости public publication; отдельный provider window только если этот путь выбран.
- Первый rebind checkpoint: CORRECTIVE. Режим: AFFECTED_CONSUMER_ONLY.
- Если условие не активно: AFTER-12 либо перед первым actual publication-preparation claim, если E02 маршрут этот owner не использует
- Граница связи: Самостоятельное ADDON исходного owner. Указанные E02 packages, если есть, только возможные selected-consumer context; существующий TEST не считается покрытием нового finding.

### Предлагаемое действие
Согласовать versioned draft codec и canon declaration между writer/readers; проверить tagged datetime в raw public_document/JsonValue. Одна добавленная метка canon недостаточна. Не назначать issuer и не обходить mandate/root custody.

Граница patch: Publication codec repair не назначает реального issuer и не заменяет institutional authority.

### Условия и зависимости
Gate: **AFFECTED_CONSUMER_ONLY**. До claim о повторном prepare/fresh reopen private draft или publication preparation по этому owner. Не блокирует независимый conditional N5/N8 без public authority.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

Дополнение для выбранного пути:
- Первый prepare, точный повтор, новый owner/процесс и untouched CAS read используют одни и те же bytes/contract.
- Контроль: canon absent отказывает; корректная декларация без исправления tagged datetime всё ещё различается. Допустимый raw JsonValue проходит strict roundtrip.
- Сохранить genuineness roots, mandates, institutional appointment и fail-closed отказ; Python3.14 native qualification отдельно.

Пакетная граница: Prepare/repeat/fresh read roundtrip работает; missing/foreign profile и недопустимая authority по-прежнему отвергаются.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/30.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high mechanism, native and operational qualification pending; уверенность распределения: medium_document_grounded_current_route_unverified.
- Ограничения: - Python 3.12 with recorded syntax/TypeVar compatibility adapters, not native 3.14.
- Synthetic initialization policy, root issuer/verifier and institutional mandate; no deployed institutional authority.
- Default production owner is unappointed and publication root custody unavailable independently of this defect.
- No new SYS root-cause family counted pending broader grouping.
- Примечания к распределению: Нет дополнительных.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## FG-01 · Проверка free grow принимает строковую ссылку вместо найденного метода

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R6.1; механизм: FG-01.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-01; {"stage": "LANE-08", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: Existing free-growth evidence/report owner; paths: ; owner lanes: LANE-08, LANE-01.
- Владелец интеграционной приёмки: LANE-01 / CYC-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: CYC-01 (LANE-01), REQ-01 (LANE-01), ACQ-01 (LANE-01), SEL-01 (LANE-01). Дополнение: ADDON::FG-01 (не официальный E02 ID).
- Основание: Readiness/G1/G2 proof обязан разрешать настоящий executable и content generation, если используется для free-grow claim. Не доказан production HTTP cache incident. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-01 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-01. Режим: conditional_freegrow_readiness_corrective.
- Если условие не активно: before_freegrow_claim_or_after_12
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. primary_stage is first integration/rebind checkpoint; implementation is due there only under activation_condition. If not active, preserve finding open and route according to otherwise_route; absence of reachability proof is not PASS.

### Предлагаемое действие
Проверять успешное разрешение реального executable и его admitted contract вместо truthy строковой ссылки. Readiness включает фактически найденный callable/метод в выбранном registry; unknown и несовместимый target остаются отказом.

Граница patch: Existing free-growth report/registry consumer, без нового discovery framework.

### Условия и зависимости
Gate: **conditional_profile_gate**. Lane01 заявляет free-grow capability или использует affected G1/G2 proving-ground/readiness input. Без этой activation не превращать probe в blanket HTTP blocker.

- FG-01 report/registry resolved, не непустой ref; FG-02 каноническая corpus generation/alias/index identity. GR-03 тот же mechanism family, отдельный owner patch.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

Дополнение для выбранного пути:
- native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report
- Removal registry/report ломает premise; resolved candidate не становится scientific authority.
- Missing report/registry не даёт executable discovery. Warm same-count replacement/add/remove меняет relevant generation; fresh/reset agreement; historical pinned replay не переаттестовывается.

Пакетная граница: Removal registry/report ломает premise; resolved candidate не становится scientific authority.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/31.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high_local_mechanism; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: Source-extracted report/reducer, real temp JSON, synthetic SKG edge and unrelated recall/quality; no full G2 or authority pass claim.
- Примечания к распределению: - Activation: Lane01 заявляет free-grow capability или использует affected G1/G2 proving-ground/readiness input. Без этой activation не превращать probe в blanket HTTP blocker.
- Otherwise: before_freegrow_claim_or_after_12
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## FG-02 · Cache и snapshot identity не различают изменения корпуса

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R6.2; механизм: FG-02.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-01; {"stage": "LANE-08", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: Existing corpus snapshot reader and capability compiler owners; paths: ; owner lanes: LANE-08, LANE-01.
- Владелец интеграционной приёмки: LANE-01 / CYC-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: CYC-01 (LANE-01), REQ-01 (LANE-01), ACQ-01 (LANE-01), SEL-01 (LANE-01). Дополнение: ADDON::FG-02 (не официальный E02 ID).
- Основание: Readiness/G1/G2 proof обязан разрешать настоящий executable и content generation, если используется для free-grow claim. Не доказан production HTTP cache incident. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-01 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-01. Режим: conditional_freegrow_readiness_corrective.
- Если условие не активно: before_freegrow_claim_or_after_12
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. primary_stage is first integration/rebind checkpoint; implementation is due there only under activation_condition. If not active, preserve finding open and route according to otherwise_route; absence of reachability proof is not PASS.

### Предлагаемое действие
Привязать cache/snapshot generation к содержимому выбранного корпуса, а не только имени/profile. Любой влияющий content drift меняет identity или явно invalidates dependent cache; no-op refresh остаётся стабильным. Согласовать общий механизм с GR-03 без второго независимого fix.

Граница patch: Два owner-specific repairs — corpus reader и compiler; общий контракт inputs, не новый общий mutable cache.

### Условия и зависимости
Gate: **conditional_profile_gate**. Lane01 заявляет free-grow capability или использует affected G1/G2 proving-ground/readiness input. Без этой activation не превращать probe в blanket HTTP blocker.

- FG-01 report/registry resolved, не непустой ref; FG-02 каноническая corpus generation/alias/index identity. GR-03 тот же mechanism family, отдельный owner patch.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R6.2", "to": "R7.1", "kind": "incremental_precondition", "reason": "Content-correct generation before unchanged-document reuse."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

Дополнение для выбранного пути:
- native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report
- Same-size/same-count changes и removals обнаруживаются; incomplete delta даёт full rebuild/refusal.
- Missing report/registry не даёт executable discovery. Warm same-count replacement/add/remove меняет relevant generation; fresh/reset agreement; historical pinned replay не переаттестовывается.

Пакетная граница: Same-size/same-count changes и removals обнаруживаются; incomplete delta даёт full rebuild/refusal.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/32.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high_mechanism_medium_operational_impact; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: Warm same-root/query proving-ground reader; synthetic catalog collaborators, no native DuckDB; new process/explicit reset differs.
- Примечания к распределению: - Activation: Lane01 заявляет free-grow capability или использует affected G1/G2 proving-ground/readiness input. Без этой activation не превращать probe в blanket HTTP blocker.
- Otherwise: before_freegrow_claim_or_after_12
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## GR-01 · Epoch graph объединяет разные manifest profiles

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R6.3; механизм: GR-01.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-01; {"stage": "LANE-06", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}; {"stage": "LANE-08", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: Core artifact graph and existing Runtime epoch graph owner; paths: runtime/quality/epoch_validity_cascade.py:743-851, core/artifacts/manifest.py:301-316, runtime/quality/epoch_transition_inputs.py:405-442; owner lanes: LANE-06, LANE-08.
- Владелец интеграционной приёмки: LANE-01 / CYC-03: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: CYC-03 (LANE-01), CYC-02 (LANE-01), ACQ-01 (LANE-01). Дополнение: ADDON::GR-01 (не официальный E02 ID).
- Основание: Epoch validity graph/profile/content propagation — источник currentness для selected basis. Это НЕ causal GRF-01/02/03 из LANE-05. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-01 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-01. Режим: conditional_epoch_cas_corrective.
- Если условие не активно: before_first_affected_currentness_claim
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. primary_stage is first integration/rebind checkpoint; implementation is due there only under activation_condition. If not active, preserve finding open and route according to otherwise_route; absence of reachability proof is not PASS.

### Предлагаемое действие
Reuse complete canonical ArtifactRef identity across all graph/event/owner/receipt keys; preserve historical contract compatibility.

Граница patch: Это два механизма: identity key у epoch owner и traversal у Core. Не объединять их одним изменением DFS.

### Условия и зависимости
Gate: **conditional_profile_gate**. Affected epoch-validity/CAS lineage path реально участвует в currentness/invalidation chosen L01 profile.

- Profile identity, shortest-depth traversal и content generation имеют независимые oracles. GR-04 performance only after preservation. Separate owners; один graph/cascade writer.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R6.3", "to": "R7.7", "kind": "hard_semantic_precondition", "reason": "Correct selected-view keys and traversal before cone optimization."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

Дополнение для выбранного пути:
- native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report
- Profiles/receipt denominators различаются; shortest reachable bounded path не зависит от input order; historical/corrupt/missing controls сохранены.
- Distinct manifest profiles не сливаются; permutation/reordered DFS не меняет bounded reachable set; same-count changed content виден. Exact persisted denominator и fresh currentness consumer проверяются отдельно.

Пакетная граница: Profiles/receipt denominators различаются; shortest reachable bounded path не зависит от input order; historical/corrupt/missing controls сохранены.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/33.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high at selected algorithm; operational impact bounded; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: see primary report; bounded evidence does not establish operational incidence
- Примечания к распределению: - Activation: Affected epoch-validity/CAS lineage path реально участвует в currentness/invalidation chosen L01 profile.
- Otherwise: before_first_affected_currentness_claim
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - Canonical producer is epoch_manifest→issuance_basis; canonical target refs preserve profiles and may refuse receipt/duplicate edge before transition. Valid persisted admitted profile-collision denominator causing wrong transition not shown.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## GR-02 · Ограниченный DFS теряет более короткий достижимый путь

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R6.3; механизм: GR-02.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-01; {"stage": "LANE-06", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}; {"stage": "LANE-08", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: Core artifact graph and existing Runtime epoch graph owner; paths: core/artifacts/graph.py:133-187, runtime/http/services/lineage.py:146; owner lanes: LANE-06, LANE-08.
- Владелец интеграционной приёмки: LANE-01 / CYC-03: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: CYC-03 (LANE-01), CYC-02 (LANE-01), ACQ-01 (LANE-01). Дополнение: ADDON::GR-02 (не официальный E02 ID).
- Основание: Epoch validity graph/profile/content propagation — источник currentness для selected basis. Это НЕ causal GRF-01/02/03 из LANE-05. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-01 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-01. Режим: conditional_epoch_cas_corrective.
- Если условие не активно: before_first_affected_currentness_claim
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. primary_stage is first integration/rebind checkpoint; implementation is due there only under activation_condition. If not active, preserve finding open and route according to otherwise_route; absence of reachability proof is not PASS.

### Предлагаемое действие
Shortest-depth BFS or depth-improving re-expansion; retain exact profile, integrity and error semantics.

Граница patch: Это два механизма: identity key у epoch owner и traversal у Core. Не объединять их одним изменением DFS.

### Условия и зависимости
Gate: **conditional_profile_gate**. Affected epoch-validity/CAS lineage path реально участвует в currentness/invalidation chosen L01 profile.

- Profile identity, shortest-depth traversal и content generation имеют независимые oracles. GR-04 performance only after preservation. Separate owners; один graph/cascade writer.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R6.3", "to": "R7.7", "kind": "hard_semantic_precondition", "reason": "Correct selected-view keys and traversal before cone optimization."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

Дополнение для выбранного пути:
- native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report
- Profiles/receipt denominators различаются; shortest reachable bounded path не зависит от input order; historical/corrupt/missing controls сохранены.
- Distinct manifest profiles не сливаются; permutation/reordered DFS не меняет bounded reachable set; same-count changed content виден. Exact persisted denominator и fresh currentness consumer проверяются отдельно.

Пакетная граница: Profiles/receipt denominators различаются; shortest reachable bounded path не зависит от input order; historical/corrupt/missing controls сохранены.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/34.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: see primary report; bounded evidence does not establish operational incidence
- Примечания к распределению: - Activation: Affected epoch-validity/CAS lineage path реально участвует в currentness/invalidation chosen L01 profile.
- Otherwise: before_first_affected_currentness_claim
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - Order-dependent false incompleteness retained; shortest-distance depth semantics are not explicit. Consumers may refuse incomplete; no false-green acceptance or security exploit established.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## GR-03 · Changed set не замечает изменение содержимого при прежнем profile

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R6.2; механизм: FG-02.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-01; {"stage": "LANE-06", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}; {"stage": "LANE-08", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: Existing corpus snapshot reader and capability compiler owners; paths: runtime/quality/capability_index_compiler.py:225-238, runtime/quality/capability_index_compiler.py:3120-3146, runtime/quality/capability_index_compiler.py:3354-3401; owner lanes: LANE-06, LANE-08.
- Владелец интеграционной приёмки: LANE-01 / CYC-03: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: CYC-03 (LANE-01), CYC-02 (LANE-01), ACQ-01 (LANE-01). Дополнение: ADDON::GR-03 (не официальный E02 ID).
- Основание: Epoch validity graph/profile/content propagation — источник currentness для selected basis. Это НЕ causal GRF-01/02/03 из LANE-05. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-01 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-01. Режим: conditional_epoch_cas_corrective.
- Если условие не активно: before_first_affected_currentness_claim
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. primary_stage is first integration/rebind checkpoint; implementation is due there only under activation_condition. If not active, preserve finding open and route according to otherwise_route; absence of reachability proof is not PASS.

### Предлагаемое действие
Bind complete content/generation and relevant compiler/config identity; missing trustworthy delta triggers full rebuild/refusal.

Граница patch: Два owner-specific repairs — corpus reader и compiler; общий контракт inputs, не новый общий mutable cache.

### Условия и зависимости
Gate: **conditional_profile_gate**. Affected epoch-validity/CAS lineage path реально участвует в currentness/invalidation chosen L01 profile.

- Profile identity, shortest-depth traversal и content generation имеют независимые oracles. GR-04 performance only after preservation. Separate owners; один graph/cascade writer.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R6.2", "to": "R7.1", "kind": "incremental_precondition", "reason": "Content-correct generation before unchanged-document reuse."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

Дополнение для выбранного пути:
- native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report
- Same-size/same-count changes и removals обнаруживаются; incomplete delta даёт full rebuild/refusal.
- Distinct manifest profiles не сливаются; permutation/reordered DFS не меняет bounded reachable set; same-count changed content виден. Exact persisted denominator и fresh currentness consumer проверяются отдельно.

Пакетная граница: Same-size/same-count changes и removals обнаруживаются; incomplete delta даёт full rebuild/refusal.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/35.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high for projection; native DB impact unrun; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: see primary report; bounded evidence does not establish operational incidence
- Примечания к распределению: - Activation: Affected epoch-validity/CAS lineage path реально участвует в currentness/invalidation chosen L01 profile.
- Otherwise: before_first_affected_currentness_claim
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## NC-04a · Явно пустые bindings сохраняют прежние search enrichment

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R6.4; механизм: NC-04a.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-01; {"stage": "LANE-08", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: fabric.catalog.MetricSearcher; paths: fabric/catalog/search.py:127-140; owner lanes: LANE-08.
- Владелец интеграционной приёмки: LANE-01 / ACQ-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: ACQ-01 (LANE-01), CYC-03 (LANE-01). Дополнение: ADDON::NC-04a (не официальный E02 ID).
- Основание: Explicit empty bindings должны очищать enrichment до повторного source resolution; generation correctness раньше ranking optimization. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-01 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-01. Режим: conditional_catalog_corrective.
- Если условие не активно: first_catalog_refresh_consumer_or_after_12
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. primary_stage is first integration/rebind checkpoint; implementation is due there only under activation_condition. If not active, preserve finding open and route according to otherwise_route; absence of reachability proof is not PASS.

### Предлагаемое действие
Distinguish None from empty list.

Граница patch: Search refresh owner; отсутствие аргумента и явное пустое множество различаются.

### Условия и зависимости
Gate: **conditional_profile_gate**. Selected acquisition использует обновляемый Fabric binding catalog.

- При actual Fabric refresh пути owner search.py исправляется один раз совместно с NC-04b при раздельных tests, не в двух lane patches.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Omitted preserves; empty clears; nonempty replaces; fresh-instance query/fingerprint equivalence.

Дополнение для выбранного пути:
- Omitted preserves; empty clears; nonempty replaces; fresh-instance query/fingerprint equivalence.
- Cold/warm/fresh результаты и fingerprint совпадают после удаления всех bindings.
- Populate→empty refresh→fresh/warm search/fingerprint дают одинаково пустую enrichment basis; nonempty positive preserved.

Пакетная граница: Cold/warm/fresh результаты и fingerprint совпадают после удаления всех bindings.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/36.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high_bounded; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: No unsafe fetch/auth bypass established; runtime registry removal flow not executed.
- Примечания к распределению: - Activation: Selected acquisition использует обновляемый Fabric binding catalog.
- Otherwise: first_catalog_refresh_consumer_or_after_12
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## NC-04b · Лимит одного результата скрывает известную неоднозначность

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R14.1; механизм: NC-04b.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-01; {"stage": "LANE-08", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: fabric.catalog.MetricSearcher; paths: fabric/catalog/search.py:258-260, fabric/catalog/search.py:376-407, fabric/catalog/search.py:443-468; owner lanes: LANE-08, LANE-01.
- Владелец интеграционной приёмки: LANE-01 / ACQ-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: ACQ-01 (LANE-01), REQ-01 (LANE-01), CYC-03 (LANE-01). Дополнение: ADDON::NC-04b (не официальный E02 ID).
- Основание: Dataset search decision/alias occurrence должен дойти до exact acquisition plan. Это не method ranking SEL-01 и не один дефект с EC/DC. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-01 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-01. Режим: supplemental_source_owner_before_consumer.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. New supplemental contract is due at this integration phase in its declared selected scope; current HEAD may already satisfy it, to be evidenced rather than reimplemented.

### Предлагаемое действие
Calculate uncertainty on sufficient contender set before presentation truncation or disallow incompatible configuration.

Граница patch: CP23 F1 и F2 и NC-04b — отдельные fixes одного search-decision contract. Не единый compiler со scopes IR; не запрет всех unknown candidates.

### Условия и зависимости
Gate: **due_contract_gate**. Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.

- R14.1 прежде R7.1 ANN/ranking optimization. Fabric search/resolver/service/executor owner сериализован; после изменения plan повторить affected I01-B.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R14.1", "to": "R7.1", "kind": "semantic_acceptance", "reason": "Top-k/ANN must preserve ambiguity and request meaning before optimizing ranking."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Same ambiguity across1/5; ties/near-threshold/unique/empty controls.

Дополнение для выбранного пути:
- Same ambiguity across1/5; ties/near-threshold/unique/empty controls.
- Canonical/alias, explicit unit/population, repeated scoped requests, ambiguity/top-k/threshold и fallback equivalence через реальный NL→persisted consumer; strict capture fallback=false сохранён.
- Ambiguous/low-score не превращается в executable primary/fallback. Canonical и alias запросы имеют одинаковый substantive scope outcome, repeated occurrences не сливаются. Limit1 и limit5 не меняют известную неоднозначность.

Пакетная граница: Canonical/alias, explicit unit/population, repeated scoped requests, ambiguity/top-k/threshold и fallback equivalence через реальный NL→persisted consumer; strict capture fallback=false сохранён.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/37.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high_bounded; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: Default MetricSearcher5/FastLane12 unaffected by this specific configuration; production caller with1 not established.
- Примечания к распределению: - Activation: Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.
- Otherwise: None
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - max_results=1 configured path hides ambiguity; defaults 5/12 unaffected and live caller setting1 not found.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## FE-03 · Alias попадает в HTML sink вместо буквального текста

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R8.2; механизм: FE-03.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: DA-08 and affected final artifact only.
- Владелец механизма: Существующий reference-shell rendering owner.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: HYG-04 (LANE-12), CLI-01 (LANE-12). Дополнение: ADDON::FE-03 (не официальный E02 ID).
- Основание: Независимое frontend correctness окно до приёмки или поставки affected reference shell. HYG-04 сохраняет этот consumer, но простая preservation не покрывает новый rendering discriminator.
- Первый rebind checkpoint: CORRECTIVE. Режим: AFFECTED_CONSUMER_CORRECTNESS.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Отображать alias буквальным текстом через существующего view owner. Проверить adversarial literal aliases в настоящем browser и соответствующем shell route. Не удалять shell и не переписывать весь client.

Граница patch: Два независимых небольших изменения, не общий root cause.

### Условия и зависимости
Gate: **AFFECTED_CONSUMER_CORRECTNESS**. Закрыть до утверждения безопасности и квалификации затронутого shell display. Само по себе не блокирует headless numerical E02 claims.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

Дополнение для выбранного пути:
**Предлагаемая работа**
Отображать alias буквальным текстом через существующего view owner. Проверить adversarial literal aliases в настоящем browser и соответствующем shell route. Не удалять shell и не переписывать весь client.

**E02 context, не автоматическое покрытие**
- REQ-HYG-04-04
- TEST-HYG-04-04

**Исходная приёмка**
native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

**Что сохранить**
Сохранить полезные shell diagnostics, public DTO meaning и границу generated client. В аудите наблюдался synthetic DOM sink; Chromium был заблокирован до загрузки страницы.

Пакетная граница: Exact binary bytes сохраняются; текст отображается буквально; native browser/client integration проверены.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/52.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high for injection sink; browser execution UNRUN; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: Synthetic DOM records; Chromium launch blocked before page load.
- Примечания к распределению: Only synthetic DOM sink behavior was observed; Chromium was blocked before page load. Existing E02 refs identify consumer context, not full pre-existing security coverage.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## FE-06 · Проверка authority parity не сравнивает state и owner surface

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R8.3; механизм: FE-06.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: Before first current reliance on affected gate/profile; LANE-12 frozen source/artifact if changed; DA-08 impact-based final refresh.
- Владелец механизма: Существующий authority MACHINE-twin/presentation parity checker owner.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: Прямой пакет оставшегося E02 не установлен. Дополнение: ADDON::FE-06 (не официальный E02 ID).
- Основание: Независимое окно проверки authority presentation до использования parity evidence. Новый discriminator относится к отображению, не к выдаче backend authority.
- Первый rebind checkpoint: CORRECTIVE. Режим: QUALIFICATION_BEFORE_RELYING_ON_GATE.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Проверять state и owner surface наряду с reasons. Mutations refused→supplied и owner change должны проваливаться через actual MACHINE-twin/DOM consumer.

Граница patch: Test-only defect не считать уже работающим authority bypass.

### Условия и зависимости
Gate: **QUALIFICATION_BEFORE_RELYING_ON_GATE**. Закрыть до приёмки authority presentation по этому checker. Backend-only claim не зависит от него автоматически.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

Дополнение для выбранного пути:
**Предлагаемая работа**
Проверять state и owner surface наряду с reasons. Mutations refused→supplied и owner change должны проваливаться через actual MACHINE-twin/DOM consumer.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Исходная приёмка**
native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

**Что сохранить**
Сохранить существующие одиннадцать backend refusals и все backend authority checks. Type-erased source/synthetic DOM не доказывают реальный UI/backend bypass.

Пакетная граница: Refused→supplied и owner change разрушают parity; реальные backend refusals сохраняются.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/54.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: Type-erased source with synthetic DOM reader; actual backend currently supplies eleven refusals.
- Примечания к распределению: Type-erased source/synthetic DOM evidence does not prove actual UI/backend bypass.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## AB-01 · Fabric дублирует mutable DAG ownership и расходится при исключении

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R9.1; механизм: AB-01.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-01; {"stage": "LANE-08", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: Existing Fabric transform wrapper/Core DAG; paths: ; owner lanes: LANE-08.
- Владелец интеграционной приёмки: LANE-01 / ACQ-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: ACQ-01 (LANE-01), CYC-03 (LANE-01). Дополнение: ADDON::AB-01 (не официальный E02 ID).
- Основание: Actual Fabric DAG branch/fork callback exception can affect selected ingestion/acquisition graph; source owner remains Fabric mutable DAG, not Scientist controller. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-01 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-01. Режим: conditional_fabric_dag_corrective.
- Если условие не активно: after_12_standalone_DAG_repair
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. primary_stage is first integration/rebind checkpoint; implementation is due there only under activation_condition. If not active, preserve finding open and route according to otherwise_route; absence of reachability proof is not PASS.

### Предлагаемое действие
Extend existing failure-lifetime contract, then consolidate builder ownership only

Граница patch: Убрать второй mutable owner, не domain execution/validation/lineage.

### Условия и зависимости
Gate: **conditional_profile_gate**. Selected source acquisition invokes affected Fabric DAG builder; other pipelines do not inherit blocker solely from domain name.

- Before applying source changes determine actual affected DAG builder route. Fix local exception safety before optional shared abstraction; no dual mutable tail.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: success/failure at zero, one, multiple additions; nested branches/fork; continued builder; auto_chain and explicit deps; real noncommutative transform outputs

Дополнение для выбранного пути:
- ['success/failure at zero, one, multiple additions', 'nested branches/fork', 'continued builder', 'auto_chain and explicit deps', 'real noncommutative transform outputs']
- Callback failure после 0/1/2 stages, nested branch/fork и реальный noncommutative DataFrame не меняют обещанный порядок.
- Caught callback failure/nested branch/fork preserve tail/order; partial-stage and DataFrame policies unchanged; actual affected acquisition chain exhibits correct effect sequence.

Пакетная граница: Callback failure после 0/1/2 stages, nested branch/fork и реальный noncommutative DataFrame не меняют обещанный порядок.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/55.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: medium_schedule_reachability_required.
- Ограничения: Native imports, DataFrame outcomes, real consumer recovery frequency
- Примечания к распределению: - Activation: Selected source acquisition invokes affected Fabric DAG builder; other pipelines do not inherit blocker solely from domain name.
- Otherwise: after_12_standalone_DAG_repair
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## AB-02 · Sync и async повторяют политики preflight и finalization

- Тип: Риск или устойчивость. Работа: risk_qualification_then_bounded_repair_if_supported.
- Remediation unit: R9.2; механизм: AB-02.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: R1.1 STATE-01 shared acceptance selected final state; R2.2 BUD-01 preservation physical ownership; LANE-01 actual producer→fresh reader если использует affected backend.
- Владелец механизма: Существующие Scientist memory/preflight/finalization owners и sync/async I/O adapters.
- Владелец интеграционной приёмки: Один координатор E02 и существующий владелец указанного механизма; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: STA-01 (LANE-06), RUN-03 (LANE-06), EXE-01 (LANE-06), EXE-02 (LANE-06). Дополнение: ADDON::AB-02 (не официальный E02 ID).
- Основание: Оба backend реально доступны через default launcher, включая async max_parallelism=1. Policy parity важна для текущего consumer, но вся selected sidecar асимметрия не доказана на default workflow.
- Первый rebind checkpoint: CORRECTIVE. Режим: Адресная qualification/parity до claims affected execution profile.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Сверить общую memory preparation и typed finalization plan у существующих owners; сохранить разные I/O lifetime/cancel/deadline. Не объединять целиком executors.

Граница patch: Общими становятся domain operations/output plan; I/O lifetime, cancellation и parallel merge остаются явными.

### Условия и зависимости
Gate: **Адресная qualification/parity до claims affected execution profile**. До объявления одинакового serious/memory/finalization contract у реально активированных sync/async путей. Candidate-only path или неподдержанный selected workflow не превращать в blanket blocker.

Нет дополнительных.

Исходные зависимости: [{"package": "R1.1", "relation": "shared_finalization_acceptance"}, {"package": "R2.2", "relation": "preserve_settlement_if_execution_paths_change"}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R1.1", "to": "R9.2", "kind": "shared_acceptance", "reason": "Shared finalization output must preserve exact journal selection."}
- {"from": "R2.2", "to": "R9.2", "kind": "lifecycle_guard", "reason": "Refactoring async/sync cannot retire physical accounting owner."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native paired serial execution; serious/candidate profiles; memory positive/negative/cross-tenant; selected/nonselected sidecar flag; fresh CAS finalization closure; deadline and cancellation before/after I/O

Дополнение для выбранного пути:
**Предлагаемая работа**
Сверить общую memory preparation и typed finalization plan у существующих owners; сохранить разные I/O lifetime/cancel/deadline. Не объединять целиком executors.

**Различающие проверки**
- Native paired serial runs; candidate/serious profiles; memory absent/present/malformed/cross-tenant; selected/nonselected workflow и sidecar flag; fresh CAS; cancel/deadline до/после I/O; current invocation/budget unknown.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Что сохранить**
scientist_default не входит в selected Research DAG set; отсутствие sidecar на default не доказывает regression. Physical reader pins и unknown effect остаются.

Пакетная граница: Native serious/candidate memory и selected sidecar parity; actual fresh CAS/finalization; physical unknown и reader pins сохранены.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/56.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: Источник и контракт прочитаны; размещение предложено аналитически; актуальный HEAD, reachability и выполненные проверки не подтверждены..
- Ограничения: Full policy bypass, deployed incident, selected-workflow async sidecar regression
- Примечания к распределению: Нет дополнительных.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## NR-01 · Рекурсивная проверка provenance падает на глубоком DAG

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R9.5; механизм: NR-01.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: AFTER-12 если verifier не активирован в текущих acceptance; Final installed artifact при изменении shipped verifier.
- Владелец механизма: Core AuditPackageVerifier и audit CLI.
- Владелец интеграционной приёмки: Один координатор E02 и существующий владелец указанного механизма; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: Прямой пакет оставшегося E02 не установлен. Дополнение: ADDON::NR-01 (не официальный E02 ID).
- Основание: Узкий availability/report defect доказан на 1200-edge DAG. Это не самостоятельный E02 graph/causal rewrite.
- Первый rebind checkpoint: CORRECTIVE. Режим: Correctness gate только для заявленного audit verifier profile.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Сохранить boolean cycle facade и заменить рекурсивный обход подходящим iterative/stdlibrary механизмом; сохранить структурированный report.

Граница patch: Четыре независимых leaf contracts; NR-03/04 reuse candidates, не новые дефекты.

### Условия и зависимости
Gate: **Correctness gate только для заявленного audit verifier profile**. До принятия больших audit packages, если такой verifier используется в E02 acceptance/release chain. Иначе bounded correction можно поставить после 12 без блокирования иных claims.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Python3.14 actual imports and CLI/archive; preserve bounds, error and resource policy

Дополнение для выбранного пути:
**Предлагаемая работа**
Сохранить boolean cycle facade и заменить рекурсивный обход подходящим iterative/stdlibrary механизмом; сохранить структурированный report.

**Различающие проверки**
- Actual Python3.14 imports/CLI/archive; empty/duplicate/self-loop/disconnected/long DAG/long cycle; report code/output/exit; resource limits отдельно.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Что сохранить**
Не превращать boolean cycle adapter в SCC/causal ordering framework; signatures/CAS policy не считать проверенными этой пробой.

Пакетная граница: Structured long-graph report; full-view identity; discovery errors/order; nullable sentinel semantics; actual adopting consumers.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/60.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high for bounded witness; native and production qualification unrun; уверенность распределения: Источник и контракт прочитаны; размещение предложено аналитически; актуальный HEAD, reachability и выполненные проверки не подтверждены..
- Ограничения: see primary report; bounded evidence does not establish operational incidence
- Примечания к распределению: Нет дополнительных.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## STR-02 · Hidden edge checker зависит от формы import

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R0.2; механизм: STR-02.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: Before first current reliance on affected gate/profile; LANE-12 frozen source/artifact if changed; DA-08 impact-based final refresh.
- Владелец механизма: Существующий hidden-import checker owner.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: HYG-02 (LANE-12), DFK-01 (LANE-12). Дополнение: ADDON::STR-02 (не официальный E02 ID).
- Основание: Квалификация при первом использовании, до финальной приёмки, опирающейся на этот gate. Эквивалентность синтаксических форм import. Указанные E02 packets являются потребляющими контекстами, не автоматически новыми implementation owners.
- Первый rebind checkpoint: CORRECTIVE. Режим: QUALIFICATION_BEFORE_RELYING_ON_GATE.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Проверить direct/from-import forms как эквивалентные; legitimate __all__ facades должны сохраняться, 79 controls не считать нарушениями.

Граница patch: Разные checker owners и разные причины; общей новой надстройки не требуется.

### Условия и зависимости
Gate: **QUALIFICATION_BEFORE_RELYING_ON_GATE**. Блокируется только приёмка, использующая затронутый gate/profile. Если он не участвует в текущих claims, более широкое исправление можно назначить отдельно.

Нет дополнительных.

Исходные зависимости: []

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Equivalent import syntax positives/negatives and legitimate facade controls.

Дополнение для выбранного пути:
**Предлагаемая работа**
Проверить direct/from-import forms как эквивалентные; legitimate __all__ facades должны сохраняться, 79 controls не считать нарушениями.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Исходная приёмка**
Equivalent import syntax positives/negatives and legitimate facade controls.

**Что сохранить**
Сохранить рабочие проверки и legitimate facades; записать exact commands, collected manifest и discriminator изменённого свойства. Не выдавать qualification gaps, риск пустого registry или mirror ratio за production incident.

Пакетная граница: Неверный root/diff и пропущенная obligation различаются отрицательными контролями; допустимые facade imports сохранены.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/61.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: Synthetic escape of one checker, not CI bypass or 79 violations.
- Примечания к распределению: Do not postpone a false-PASS checker until after using it; do not call qualification gaps, empty-registry risks or mirror ratios production defects.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## STR-03 · Teardown test helper видит только одну import identity

- Тип: Риск или устойчивость. Работа: risk_qualification_then_bounded_repair_if_supported.
- Remediation unit: R0.4; механизм: STR-03.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: Before first current reliance on affected gate/profile; LANE-12 frozen source/artifact if changed; DA-08 impact-based final refresh.
- Владелец механизма: Существующий общий runtime test helper и teardown owner.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: CLI-01 (LANE-12). Дополнение: ADDON::STR-03 (не официальный E02 ID).
- Основание: Квалификация при первом использовании, до финальной приёмки, опирающейся на этот gate. Единая identity fixture при двух import spellings. Указанные E02 packets являются потребляющими контекстами, не автоматически новыми implementation owners.
- Первый rebind checkpoint: CORRECTIVE. Режим: QUALIFICATION_BEFORE_RELYING_ON_GATE.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Проверить оба написания imports и их порядок, включая failed setup. Registries должны согласоваться; explicit idempotent close остаётся.

Граница patch: Нужна одна canonical fixture identity; фактическая suite leak не доказана.

### Условия и зависимости
Gate: **QUALIFICATION_BEFORE_RELYING_ON_GATE**. Блокируется только приёмка, использующая затронутый gate/profile. Если он не участвует в текущих claims, более широкое исправление можно назначить отдельно.

Нет дополнительных.

Исходные зависимости: []

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Both import orders/aliases and failed setup; genuine env cleanup.

Дополнение для выбранного пути:
**Предлагаемая работа**
Проверить оба написания imports и их порядок, включая failed setup. Registries должны согласоваться; explicit idempotent close остаётся.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Исходная приёмка**
Both import orders/aliases and failed setup; genuine env cleanup.

**Что сохранить**
Сохранить рабочие проверки и legitimate facades; записать exact commands, collected manifest и discriminator изменённого свойства. Не выдавать qualification gaps, риск пустого registry или mirror ratio за production incident.

Пакетная граница: Оба spelling и исключения закрывают те же ресурсы; explicit idempotent close остаётся.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/62.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: Selected long-name callers close environments explicitly; suite leak unestablished.
- Примечания к распределению: Do not postpone a false-PASS checker until after using it; do not call qualification gaps, empty-registry risks or mirror ratios production defects.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## TC-06 · Истечение quarantine не становится обязательным gate

- Тип: Риск или устойчивость. Работа: risk_qualification_then_bounded_repair_if_supported.
- Remediation unit: R0.3; механизм: TC-06.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: Before first current reliance on affected gate/profile; LANE-12 frozen source/artifact if changed; DA-08 impact-based final refresh.
- Владелец механизма: Существующий quarantine policy/hook owner.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: HYG-04 (LANE-12). Дополнение: ADDON::TC-06 (не официальный E02 ID).
- Основание: Квалификация при первом использовании, до финальной приёмки, опирающейся на этот gate. Явная политика истечения quarantine. Указанные E02 packets являются потребляющими контекстами, не автоматически новыми implementation owners.
- Первый rebind checkpoint: CORRECTIVE. Режим: QUALIFICATION_BEFORE_RELYING_ON_GATE.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Определить expiry semantics и проверить expired/valid/unknown entries в actual lane. Текущий registry пуст: действующий скрытый тест не установлен.

Граница patch: Selection/oracle/quarantine — отдельные подзадачи; mirror gaps не чинить placeholder tests.

### Условия и зависимости
Gate: **QUALIFICATION_BEFORE_RELYING_ON_GATE**. Блокируется только приёмка, использующая затронутый gate/profile. Если он не участвует в текущих claims, более широкое исправление можно назначить отдельно.

Нет дополнительных.

Исходные зависимости: []

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Expired/valid/unknown entries; actual lane check.

Дополнение для выбранного пути:
**Предлагаемая работа**
Определить expiry semantics и проверить expired/valid/unknown entries в actual lane. Текущий registry пуст: действующий скрытый тест не установлен.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Исходная приёмка**
Expired/valid/unknown entries; actual lane check.

**Что сохранить**
Сохранить рабочие проверки и legitimate facades; записать exact commands, collected manifest и discriminator изменённого свойства. Не выдавать qualification gaps, риск пустого registry или mirror ratio за production incident.

Пакетная граница: Сохранён точный collected/executed manifest; no-work/removal regression отказывает; expiry policy явна.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/63.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: No current test hidden by registry; no active de-gating incident.
- Примечания к распределению: Do not postpone a false-PASS checker until after using it; do not call qualification gaps, empty-registry risks or mirror ratios production defects.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## CS-02 · Чтение sidecar не связывает child с parent в URL

- Тип: Решение по контракту. Работа: contract_decision_before_any_code.
- Remediation unit: R4.1; механизм: CS-02.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-01; {"stage": "LANE-04", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: Foundry solved-state/analysis owner; Runtime request/route adapter; paths: ; owner lanes: LANE-04.
- Владелец интеграционной приёмки: LANE-01 / CYC-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: CYC-01 (LANE-01), SIM-01 (LANE-01), CYC-02 (LANE-01). Дополнение: ADDON::CS-02 (не официальный E02 ID).
- Основание: Runtime Analysis/Foundry attractor feedback is a separate producer/consumer chain; only selected N5/sidecar use makes it part of L01 acceptance. IR attach production caller not found. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-01 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-01. Режим: conditional_feedback_analysis_sidecar_window.
- Если условие не активно: after_12_standalone_analysis_repair
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. primary_stage is first integration/rebind checkpoint; implementation is due there only under activation_condition. If not active, preserve finding open and route according to otherwise_route; absence of reachability proof is not PASS.

### Предлагаемое действие
Принять отдельное явное решение endpoint contract: обозначает ли parent URL обязательную custody/association child или независимый exact lookup. Если обещана связь, проверять фактический parent-child relation и scope; не добавлять механическое URL equality без согласованной semantics. Сохранить fail-closed controls.

Граница patch: CS-01 — diagnostic/solve join; CS-02 — отдельное API relationship решение. Не простое сравнение URL и logical ID.

### Условия и зависимости
Gate: **conditional_profile_gate**. Selected L01 capability actually uses feedback/attractor analysis or nested sidecar API. Do not treat availability as scientific/public authority.

- CS-01 semantic diagnostic join before reuse; CS-02 canonical parent-child API relation decision. No eigenvalue logic in HTTP, no strings-only URL fix.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

Дополнение для выбранного пути:
- native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report
- Foreign same-dimension diagnostic, profile/state/order/trace mismatch отвергаются; explicit reanalysis имеет новую provenance; parent route контракт честный.
- Own/omitted/foreign same-dimension Jacobian, actual trace/state/order/profile relation and full lineage survive fresh read. Own/other/malformed parent and child profile/type/tenant preserve auth; parent logical ID not blindly compared to CAS URL.

Пакетная граница: Foreign same-dimension diagnostic, profile/state/order/trace mismatch отвергаются; explicit reanalysis имеет новую provenance; parent route контракт честный.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/65.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: high_source_owner_medium_schedule_conditional.
- Ограничения: see primary report; bounded evidence does not establish operational incidence
- Примечания к распределению: - Activation: Selected L01 capability actually uses feedback/attractor analysis or nested sidecar API. Do not treat availability as scientific/public authority.
- Otherwise: after_12_standalone_analysis_repair
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - Retain P3 API ambiguity: parent is audit/request context; shipped tests use different ID namespaces and detached nullable-parent sidecars exist. No evidence audit metadata is accepted as verified custody. Do not add naive parent string equality.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## SA-01 · Неоднозначная проекция schema ID в путь перезаписывает другую схему

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R10.1; механизм: SA-01.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-01; {"stage": "LANE-08", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: existing source owner named by primary report; paths: fabric/connectors/contracts/registry.py:355-362,425-438; owner lanes: LANE-08.
- Владелец интеграционной приёмки: LANE-01 / ACQ-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: ACQ-01 (LANE-01), CYC-03 (LANE-01), ING-01 (LANE-08), ING-02 (LANE-08), NET-01 (LANE-08), NET-02 (LANE-08). Дополнение: ADDON::SA-01 (не официальный E02 ID).
- Основание: Selected acquisition не может опираться на schema collision, inferred admission или неверный aggregate REST version. Connector/ingest owners исходного L08 сохраняются. GeoJSON только при выбранном provider. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-01 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-01. Режим: conditional_connector_corrective_window.
- Если условие не активно: before_affected_provider_claim_or_after_12
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. primary_stage is first integration/rebind checkpoint; implementation is due there only under activation_condition. If not active, preserve finding open and route according to otherwise_route; absence of reachability proof is not PASS.

### Предлагаемое действие
Инъективное кодирование identity с conflict detection и migration.

Граница patch: SA-01 collision repair; SA-02 boundary decision. Их нельзя назвать одним validation bypass.

### Условия и зависимости
Gate: **conditional_profile_gate**. Actual selected source/provider invokes affected registry, middleware, GeoJSON or REST path; each row requires its own activation evidence.

- Finite actual provider/profile census до consumer. Последовательное corrective окно L08 для найденного affected path; не обязательный ремонт всех providers для одного E02 case.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Два colliding IDs в обоих порядках, разные версии и noncollision; fresh process и migration/readback.

Дополнение для выбранного пути:
- Два colliding IDs в обоих порядках, разные версии и noncollision; fresh process и migration/readback.
- Collision/reopen сохраняют оба IDs; missing/matching/breaking contracts имеют явный candidate/admission outcome.
- SA-01 injective id/version + reopen/collision. SA-02 explicit candidate versus governed missing contract. SA-03 structural geometry/properties ID. AR-01 retry veto/budget. AR-02 aggregate all-pages version. AR-03 typed failure+resource cleanup+later-good batch. Actual two-source persistence/refresh where selected.

Пакетная граница: Collision/reopen сохраняют оба IDs; missing/matching/breaking contracts имеют явный candidate/admission outcome.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/81.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: Нет обнаруженного direct first-party runtime constructor; alias/dynamic/external reach не исключён.
- Примечания к распределению: - Activation: Actual selected source/provider invokes affected registry, middleware, GeoJSON or REST path; each row requires its own activation evidence.
- Otherwise: before_affected_provider_claim_or_after_12
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - Нет обнаруженного direct first-party runtime constructor; alias/dynamic/external reach не исключён.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## SA-02 · Generic inference не означает governed schema admission

- Тип: Решение по контракту. Работа: contract_decision_before_any_code.
- Remediation unit: R10.1; механизм: SA-02.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-01; {"stage": "LANE-08", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: existing source owner named by primary report; paths: fabric/connectors/contracts/validation_middleware.py:176-210, contracts/_inference_engine.py:199-205, _registry_lifecycle.py:1120-1156; owner lanes: LANE-08.
- Владелец интеграционной приёмки: LANE-01 / ACQ-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: ACQ-01 (LANE-01), CYC-03 (LANE-01), ING-01 (LANE-08), ING-02 (LANE-08), NET-01 (LANE-08), NET-02 (LANE-08). Дополнение: ADDON::SA-02 (не официальный E02 ID).
- Основание: Selected acquisition не может опираться на schema collision, inferred admission или неверный aggregate REST version. Connector/ingest owners исходного L08 сохраняются. GeoJSON только при выбранном provider. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-01 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-01. Режим: conditional_connector_corrective_window.
- Если условие не активно: before_affected_provider_claim_or_after_12
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. primary_stage is first integration/rebind checkpoint; implementation is due there only under activation_condition. If not active, preserve finding open and route according to otherwise_route; absence of reachability proof is not PASS.

### Предлагаемое действие
Явно назначить missing-contract policy для candidate и protected acquisition, использовать существующего contract owner.

Граница patch: SA-01 collision repair; SA-02 boundary decision. Их нельзя назвать одним validation bypass.

### Условия и зависимости
Gate: **conditional_profile_gate**. Actual selected source/provider invokes affected registry, middleware, GeoJSON or REST path; each row requires its own activation evidence.

- Finite actual provider/profile census до consumer. Последовательное corrective окно L08 для найденного affected path; не обязательный ремонт всех providers для одного E02 case.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Missing/valid/invalid contract на actual admitted caller; не ломать version/approval guards.

Дополнение для выбранного пути:
- Missing/valid/invalid contract на actual admitted caller; не ломать version/approval guards.
- Collision/reopen сохраняют оба IDs; missing/matching/breaking contracts имеют явный candidate/admission outcome.
- SA-01 injective id/version + reopen/collision. SA-02 explicit candidate versus governed missing contract. SA-03 structural geometry/properties ID. AR-01 retry veto/budget. AR-02 aggregate all-pages version. AR-03 typed failure+resource cleanup+later-good batch. Actual two-source persistence/refresh where selected.

Пакетная граница: Collision/reopen сохраняют оба IDs; missing/matching/breaking contracts имеют явный candidate/admission outcome.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/82.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: Это граница политики, не универсальная ошибка validation и не authority bypass; full bootstrap не выполнен.
- Примечания к распределению: - Activation: Actual selected source/provider invokes affected registry, middleware, GeoJSON or REST path; each row requires its own activation evidence.
- Otherwise: before_affected_provider_claim_or_after_12
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - Это граница политики, не универсальная ошибка validation и не authority bypass; full bootstrap не выполнен.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## SA-03 · GeoJSON принимает неверную структуру а properties заменяют feature ID

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R10.2; механизм: SA-03.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-01; {"stage": "LANE-08", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: existing source owner named by primary report; paths: fabric/connectors/sources/geojson.py:135-155,211-225; owner lanes: LANE-08.
- Владелец интеграционной приёмки: LANE-01 / ACQ-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: ACQ-01 (LANE-01), CYC-03 (LANE-01), ING-01 (LANE-08), ING-02 (LANE-08), NET-01 (LANE-08), NET-02 (LANE-08). Дополнение: ADDON::SA-03 (не официальный E02 ID).
- Основание: Selected acquisition не может опираться на schema collision, inferred admission или неверный aggregate REST version. Connector/ingest owners исходного L08 сохраняются. GeoJSON только при выбранном provider. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-01 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-01. Режим: conditional_connector_corrective_window.
- Если условие не активно: before_affected_provider_claim_or_after_12
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. primary_stage is first integration/rebind checkpoint; implementation is due there only under activation_condition. If not active, preserve finding open and route according to otherwise_route; absence of reachability proof is not PASS.

### Предлагаемое действие
Валидировать protocol semantics и зарезервировать structural fields до SILVER/spatial flags.

Граница patch: Приоритет зависит от того, используется ли adapter как validator; native downstream ещё не квалифицирован.

### Условия и зависимости
Gate: **conditional_profile_gate**. Actual selected source/provider invokes affected registry, middleware, GeoJSON or REST path; each row requires its own activation evidence.

- Finite actual provider/profile census до consumer. Последовательное corrective окно L08 для найденного affected path; не обязательный ремонт всех providers для одного E02 case.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Geometry/type/coordinate corpus, reserved-field collision, protected downstream admission и legitimate controls.

Дополнение для выбранного пути:
- Geometry/type/coordinate corpus, reserved-field collision, protected downstream admission и legitimate controls.
- Adversarial geometry/properties corpus, protected identity и фактический consumer работают по заявленной роли.
- SA-01 injective id/version + reopen/collision. SA-02 explicit candidate versus governed missing contract. SA-03 structural geometry/properties ID. AR-01 retry veto/budget. AR-02 aggregate all-pages version. AR-03 typed failure+resource cleanup+later-good batch. Actual two-source persistence/refresh where selected.

Пакетная граница: Adversarial geometry/properties corpus, protected identity и фактический consumer работают по заявленной роли.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/83.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: P2 условен на использование adapter как валидатора GeoJSON; author replay воспроизведён, независимый exhaustive corpus и downstream admission отсутствуют.
- Примечания к распределению: - Activation: Actual selected source/provider invokes affected registry, middleware, GeoJSON or REST path; each row requires its own activation evidence.
- Otherwise: before_affected_provider_claim_or_after_12
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - P2 условен на использование adapter как валидатора GeoJSON; author replay воспроизведён, независимый exhaustive corpus и downstream admission отсутствуют.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## RR-02 · Checkpoint не связывает state с base и полным dependency closure

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R11.3; механизм: RR-02.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-01; {"stage": "LANE-06", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: team-scientist / orchestration.engine.checkpoint; paths: scientist/orchestration/engine/checkpoint.py:913-917,2089-2141,2192-2246,2607-2717; owner lanes: LANE-06.
- Владелец интеграционной приёмки: LANE-01 / CYC-03: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: CYC-03 (LANE-01), CYC-02 (LANE-01), RES-01 (LANE-06), RES-02 (LANE-06), RES-03 (LANE-06). Дополнение: ADDON::RR-02 (не официальный E02 ID).
- Основание: Ранний checkpoint owner должен восстановить exact base/dependencies и tenant/cell/enforcement перед заявленным continuation. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-01 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-01. Режим: conditional_corrective_window_before_resume.
- Если условие не активно: before_first_affected_resume_claim
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. primary_stage is first integration/rebind checkpoint; implementation is due there only under activation_condition. If not active, preserve finding open and route according to otherwise_route; absence of reachability proof is not PASS.

### Предлагаемое действие
Связать state с exact base; run/origin/sequence/depth continuity, selected lineage edges и reader bound.

Граница patch: Два checkpoint/factory subchanges. Mismatched pair в probe подана явно, spontaneous normal-hook ошибка не доказана.

### Условия и зависимости
Gate: **conditional_profile_gate**. Заявляется restore/continuation через затронутый hook/checkpoint backend; для прямого non-resume candidate не искусственный prerequisite.

- Проверить actual chosen checkpoint route; при reachability последовательное L06 repair окно. Native fresh-resume evidence не наследовать от старого CAS fixture.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Отдельно закрыть state/ref binding, ancestor continuity, manifest closure и reader depth; fresh reader, foreign scope и missing/corrupt base.

Дополнение для выбранного пути:
- Отдельно закрыть state/ref binding, ancestor continuity, manifest closure и reader depth; fresh reader, foreign scope и missing/corrupt base.
- Base materialization/lineage, exact scope/enforcement после restart, missing/corrupt/foreign refusals и real worker path.
- RR-02: injected base mismatch не принимается; manifest inputs полны. RR-03: ordinary hook export/restore сохраняет scoped CAS custody и следующий checkpoint читается тем же scoped reader. Foreign/missing/corrupt negatives.

Пакетная граница: Base materialization/lineage, exact scope/enforcement после restart, missing/corrupt/foreign refusals и real worker path.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/87.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high_local_producer_reader; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: Mismatched producer inputs введены явно; normal hook не доказан самопроизвольно нарушающим пару. Graph честно обходит manifest.inputs, а materializer после missing base отказывает.
- Примечания к распределению: - Activation: Заявляется restore/continuation через затронутый hook/checkpoint backend; для прямого non-resume candidate не искусственный prerequisite.
- Otherwise: before_first_affected_resume_claim
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - Mismatched producer inputs введены явно; normal hook не доказан самопроизвольно нарушающим пару. Graph честно обходит manifest.inputs, а materializer после missing base отказывает.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## RR-03 · Export и restore hook теряют tenant cell и enforcement CAS

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R11.3; механизм: RR-03.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-01; {"stage": "LANE-06", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: team-scientist / orchestration.engine.checkpoint with existing team-core factory; paths: scientist/orchestration/engine/checkpoint.py:1444-1545, core/artifacts/backends/config.py:51-72, scientist/orchestration/engine/runner/_activity_worker.py:455-543; owner lanes: LANE-06.
- Владелец интеграционной приёмки: LANE-01 / CYC-03: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: CYC-03 (LANE-01), CYC-02 (LANE-01), RES-01 (LANE-06), RES-02 (LANE-06), RES-03 (LANE-06). Дополнение: ADDON::RR-03 (не официальный E02 ID).
- Основание: Ранний checkpoint owner должен восстановить exact base/dependencies и tenant/cell/enforcement перед заявленным continuation. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-01 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-01. Режим: conditional_corrective_window_before_resume.
- Если условие не активно: before_first_affected_resume_claim
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. primary_stage is first integration/rebind checkpoint; implementation is due there only under activation_condition. If not active, preserve finding open and route according to otherwise_route; absence of reachability proof is not PASS.

### Предлагаемое действие
Передать exact admitted scope/enforcement через существующий artifact factory.

Граница patch: Два checkpoint/factory subchanges. Mismatched pair в probe подана явно, spontaneous normal-hook ошибка не доказана.

### Условия и зависимости
Gate: **conditional_profile_gate**. Заявляется restore/continuation через затронутый hook/checkpoint backend; для прямого non-resume candidate не искусственный prerequisite.

- Проверить actual chosen checkpoint route; при reachability последовательное L06 repair окно. Native fresh-resume evidence не наследовать от старого CAS fixture.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Untouched metadata fresh restore, original scoped reader, foreign metadata refusal, real worker и nonfilesystem policy.

Дополнение для выбранного пути:
- Untouched metadata fresh restore, original scoped reader, foreign metadata refusal, real worker и nonfilesystem policy.
- Base materialization/lineage, exact scope/enforcement после restart, missing/corrupt/foreign refusals и real worker path.
- RR-02: injected base mismatch не принимается; manifest inputs полны. RR-03: ordinary hook export/restore сохраняет scoped CAS custody и следующий checkpoint читается тем же scoped reader. Foreign/missing/corrupt negatives.

Пакетная граница: Base materialization/lineage, exact scope/enforcement после restart, missing/corrupt/foreign refusals и real worker path.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/88.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high_actual_hook_chain; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: Foreign metadata reconciliation сохраняет refusal; не показаны foreign read, full Ray/Temporal resume или HTTP bypass.
- Примечания к распределению: - Activation: Заявляется restore/continuation через затронутый hook/checkpoint backend; для прямого non-resume candidate не искусственный prerequisite.
- Otherwise: before_first_affected_resume_claim
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - Foreign metadata reconciliation сохраняет refusal; не показаны foreign read, full Ray/Temporal resume или HTTP bypass.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## GE-01 · Ошибка Git diff превращается в пустой набор изменений docs

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R0.2; механизм: GE-01.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: Before first current reliance on affected gate/profile; LANE-12 frozen source/artifact if changed; DA-08 impact-based final refresh.
- Владелец механизма: Существующий docs gate и его actual caller.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: HYG-04 (LANE-12). Дополнение: ADDON::GE-01 (не официальный E02 ID).
- Основание: Квалификация при первом использовании, до финальной приёмки, опирающейся на этот gate. Ошибка Git diff не равна отсутствию изменений. Указанные E02 packets являются потребляющими контекстами, не автоматически новыми implementation owners.
- Первый rebind checkpoint: CORRECTIVE. Режим: QUALIFICATION_BEFORE_RELYING_ON_GATE.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Invalid/missing/zero Git base должен давать явную ошибку, а не успешный пустой diff. Проверить actual caller вместе с valid-base obligations.

Граница patch: Разные checker owners и разные причины; общей новой надстройки не требуется.

### Условия и зависимости
Gate: **QUALIFICATION_BEFORE_RELYING_ON_GATE**. Блокируется только приёмка, использующая затронутый gate/profile. Если он не участвует в текущих claims, более широкое исправление можно назначить отдельно.

Нет дополнительных.

Исходные зависимости: []

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Valid/invalid/zero base через actual caller, обязательные docs changes и supported CLI.

Дополнение для выбранного пути:
**Предлагаемая работа**
Invalid/missing/zero Git base должен давать явную ошибку, а не успешный пустой diff. Проверить actual caller вместе с valid-base obligations.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Исходная приёмка**
Valid/invalid/zero base через actual caller, обязательные docs changes и supported CLI.

**Что сохранить**
Сохранить рабочие проверки и legitimate facades; записать exact commands, collected manifest и discriminator изменённого свойства. Не выдавать qualification gaps, риск пустого registry или mirror ratio за production incident.

Пакетная граница: Неверный root/diff и пропущенная obligation различаются отрицательными контролями; допустимые facade imports сохранены.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/89.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high_bounded; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: Локальная caller failure semantics; hosted bypass и green остальных jobs не установлены.
- Примечания к распределению: Do not postpone a false-PASS checker until after using it; do not call qualification gaps, empty-registry risks or mirror ratios production defects.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## GE-02 · Import subgate игнорирует переданный candidate root

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R0.2; механизм: GE-02.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: Before first current reliance on affected gate/profile; LANE-12 frozen source/artifact if changed; DA-08 impact-based final refresh.
- Владелец механизма: Существующий architecture import subgate owner.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: HYG-02 (LANE-12), DFK-01 (LANE-12). Дополнение: ADDON::GE-02 (не официальный E02 ID).
- Основание: Квалификация при первом использовании, до финальной приёмки, опирающейся на этот gate. Передача candidate root во вложенные проверки. Указанные E02 packets являются потребляющими контекстами, не автоматически новыми implementation owners.
- Первый rebind checkpoint: CORRECTIVE. Режим: QUALIFICATION_BEFORE_RELYING_ON_GATE.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Передать candidate root в реальные import subgates: дефект только в candidate root обязан обнаруживаться; сохранить same-root positive/negative controls.

Граница patch: Разные checker owners и разные причины; общей новой надстройки не требуется.

### Условия и зависимости
Gate: **QUALIFICATION_BEFORE_RELYING_ON_GATE**. Блокируется только приёмка, использующая затронутый gate/profile. Если он не участвует в текущих claims, более широкое исправление можно назначить отдельно.

Нет дополнительных.

Исходные зависимости: []

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Разные checker/candidate roots, отказ дефекта только в candidate и same-root positive/negative controls.

Дополнение для выбранного пути:
**Предлагаемая работа**
Передать candidate root в реальные import subgates: дефект только в candidate root обязан обнаруживаться; сохранить same-root positive/negative controls.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Исходная приёмка**
Разные checker/candidate roots, отказ дефекта только в candidate и same-root positive/negative controls.

**Что сохранить**
Сохранить рабочие проверки и legitimate facades; записать exact commands, collected manifest и discriminator изменённого свойства. Не выдавать qualification gaps, риск пустого registry или mirror ratio за production incident.

Пакетная граница: Неверный root/diff и пропущенная obligation различаются отрицательными контролями; допустимые facade imports сохранены.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/90.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high_for_shim_wrapper_mechanism; dynamic/cycle_source_traced; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: Same-root guard работает; full aggregate green и native dynamic/cycle replay не доказаны.
- Примечания к распределению: Do not postpone a false-PASS checker until after using it; do not call qualification gaps, empty-registry risks or mirror ratios production defects.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## GE-03 · Один README закрывает обязательства нескольких facade paths

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R0.2; механизм: GE-03.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: Before first current reliance on affected gate/profile; LANE-12 frozen source/artifact if changed; DA-08 impact-based final refresh.
- Владелец механизма: Существующий docs obligation planner owner.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: HYG-02 (LANE-12), DFK-01 (LANE-12), HYG-04 (LANE-12). Дополнение: ADDON::GE-03 (не официальный E02 ID).
- Основание: Квалификация при первом использовании, до финальной приёмки, опирающейся на этот gate. Отдельное документальное обязательство каждого изменённого facade. Указанные E02 packets являются потребляющими контекстами, не автоматически новыми implementation owners.
- Первый rebind checkpoint: CORRECTIVE. Режим: QUALIFICATION_BEFORE_RELYING_ON_GATE.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Проверить два facade changes с одним и двумя matching README, отдельно impact-note control. Один README не снимает все обязанности.

Граница patch: Разные checker owners и разные причины; общей новой надстройки не требуется.

### Условия и зависимости
Gate: **QUALIFICATION_BEFORE_RELYING_ON_GATE**. Блокируется только приёмка, использующая затронутый gate/profile. Если он не участвует в текущих claims, более широкое исправление можно назначить отдельно.

Нет дополнительных.

Исходные зависимости: []

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Два facade changes и один/два соответствующих README с отдельным impact-note control.

Дополнение для выбранного пути:
**Предлагаемая работа**
Проверить два facade changes с одним и двумя matching README, отдельно impact-note control. Один README не снимает все обязанности.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Исходная приёмка**
Два facade changes и один/два соответствующих README с отдельным impact-note control.

**Что сохранить**
Сохранить рабочие проверки и legitimate facades; записать exact commands, collected manifest и discriminator изменённого свойства. Не выдавать qualification gaps, риск пустого registry или mirror ratio за production incident.

Пакетная граница: Неверный root/diff и пропущенная obligation различаются отрицательными контролями; допустимые facade imports сохранены.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/91.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high_for_existential_planner_semantics; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: Existential planner weakness, не доказанная semantic staleness или обход всех docs checks.
- Примечания к распределению: Do not postpone a false-PASS checker until after using it; do not call qualification gaps, empty-registry risks or mirror ratios production defects.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## GE-C01 · Default timing test проверяет только наличие baseline

- Тип: Пробел квалификации. Работа: qualification_not_automatic_code_fix.
- Remediation unit: R0.3; механизм: GE-C01.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: Before first current reliance on affected gate/profile; LANE-12 frozen source/artifact if changed; DA-08 impact-based final refresh.
- Владелец механизма: Существующий live import-timing qualification owner.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: HYG-04 (LANE-12). Дополнение: ADDON::GE-C01 (не официальный E02 ID).
- Основание: Квалификация при первом использовании, до финальной приёмки, опирающейся на этот gate. Измеряемый timing gate вместо наличия baseline файла. Указанные E02 packets являются потребляющими контекстами, не автоматически новыми implementation owners.
- Первый rebind checkpoint: CORRECTIVE. Режим: QUALIFICATION_BEFORE_RELYING_ON_GATE.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Явно выбрать supported-runtime timing lane и доказать regression/removal negative. Наличие baseline-файла не считается измеренной latency.

Граница patch: Selection/oracle/quarantine — отдельные подзадачи; mirror gaps не чинить placeholder tests.

### Условия и зависимости
Gate: **QUALIFICATION_BEFORE_RELYING_ON_GATE**. Блокируется только приёмка, использующая затронутый gate/profile. Если он не участвует в текущих claims, более широкое исправление можно назначить отдельно.

Нет дополнительных.

Исходные зависимости: []

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Supported runtime, declared selected lane и fail-on-regression/removal controls; provenance измерения.

Дополнение для выбранного пути:
**Предлагаемая работа**
Явно выбрать supported-runtime timing lane и доказать regression/removal negative. Наличие baseline-файла не считается измеренной latency.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Исходная приёмка**
Supported runtime, declared selected lane и fail-on-regression/removal controls; provenance измерения.

**Что сохранить**
Сохранить рабочие проверки и legitimate facades; записать exact commands, collected manifest и discriminator изменённого свойства. Не выдавать qualification gaps, риск пустого registry или mirror ratio за production incident.

Пакетная граница: Сохранён точный collected/executed manifest; no-work/removal regression отказывает; expiry policy явна.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/92.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high_for_default_control_and_named_literal_declarations; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: Coverage gap, не измеренная latency regression и не утверждение об отсутствии opt-in в hosted environment.
- Примечания к распределению: Do not postpone a false-PASS checker until after using it; do not call qualification gaps, empty-registry risks or mirror ratios production defects.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## AR-01 · REST transport теряет запрет retry и limits подключения

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R10.3; механизм: AR-01.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-01; {"stage": "LANE-08", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: existing source owner named by primary report; paths: fabric/connectors/reference/rest_json.py:470-477,628-638, core/resilience/retry.py:103-117,227-244; owner lanes: LANE-08.
- Владелец интеграционной приёмки: LANE-01 / ACQ-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: ACQ-01 (LANE-01), CYC-03 (LANE-01), ING-01 (LANE-08), ING-02 (LANE-08), NET-01 (LANE-08), NET-02 (LANE-08). Дополнение: ADDON::AR-01 (не официальный E02 ID).
- Основание: Selected acquisition не может опираться на schema collision, inferred admission или неверный aggregate REST version. Connector/ingest owners исходного L08 сохраняются. GeoJSON только при выбранном provider. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-01 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-01. Режим: conditional_connector_corrective_window.
- Если условие не активно: before_affected_provider_claim_or_after_12
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. primary_stage is first integration/rebind checkpoint; implementation is due there only under activation_condition. If not active, preserve finding open and route according to otherwise_route; absence of reachability proof is not PASS.

### Предлагаемое действие
Сохранить request retry veto и budget при page request через existing retry owner.

Граница patch: Три subcontracts одного REST adapter; shared retry owner уже существует.

### Условия и зависимости
Gate: **conditional_profile_gate**. Actual selected source/provider invokes affected registry, middleware, GeoJSON or REST path; each row requires its own activation evidence.

- Finite actual provider/profile census до consumer. Последовательное corrective окно L08 для найденного affected path; не обязательный ремонт всех providers для одного E02 case.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Veto на первой/следующей странице, budgets 1 и large, cancellation, actual pool/registry caller.

Дополнение для выбранного пути:
- Veto на первой/следующей странице, budgets 1 и large, cancellation, actual pool/registry caller.
- Реальный two-source batch, повторные страницы, версия aggregate content, malformed 429/exhausted retry и cleanup/continuation проверены.
- SA-01 injective id/version + reopen/collision. SA-02 explicit candidate versus governed missing contract. SA-03 structural geometry/properties ID. AR-01 retry veto/budget. AR-02 aggregate all-pages version. AR-03 typed failure+resource cleanup+later-good batch. Actual two-source persistence/refresh where selected.

Пакетная граница: Реальный two-source batch, повторные страницы, версия aggregate content, malformed 429/exhausted retry и cleanup/continuation проверены.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/93.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high for bounded adapter path; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: Не показаны live provider или повтор write/mutation; native registry не выполнен.
- Примечания к распределению: - Activation: Actual selected source/provider invokes affected registry, middleware, GeoJSON or REST path; each row requires its own activation evidence.
- Otherwise: before_affected_provider_claim_or_after_12
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - Не показаны live provider или повтор write/mutation; native registry не выполнен.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## AR-02 · Validator отдельной страницы объявляется версией полного набора

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R10.3; механизм: AR-02.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-01; {"stage": "LANE-08", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: existing source owner named by primary report; paths: fabric/connectors/reference/rest_json.py:482-498,552-580,598-626, ir/connectors/__init__.py:117-139; owner lanes: LANE-08.
- Владелец интеграционной приёмки: LANE-01 / ACQ-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: ACQ-01 (LANE-01), CYC-03 (LANE-01), ING-01 (LANE-08), ING-02 (LANE-08), NET-01 (LANE-08), NET-02 (LANE-08). Дополнение: ADDON::AR-02 (не официальный E02 ID).
- Основание: Selected acquisition не может опираться на schema collision, inferred admission или неверный aggregate REST version. Connector/ingest owners исходного L08 сохраняются. GeoJSON только при выбранном provider. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-01 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-01. Режим: conditional_connector_corrective_window.
- Если условие не активно: before_affected_provider_claim_or_after_12
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. primary_stage is first integration/rebind checkpoint; implementation is due there only under activation_condition. If not active, preserve finding open and route according to otherwise_route; absence of reachability proof is not PASS.

### Предлагаемое действие
Aggregate version должна покрывать каждую data page либо использовать content identity/fail-closed unknown.

Граница patch: Три subcontracts одного REST adapter; shared retry owner уже существует.

### Условия и зависимости
Gate: **conditional_profile_gate**. Actual selected source/provider invokes affected registry, middleware, GeoJSON or REST path; each row requires its own activation evidence.

- Finite actual provider/profile census до consumer. Последовательное corrective окно L08 для найденного affected path; не обязательный ремонт всех providers для одного E02 case.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Отсутствующий/terminal-only ETag и Last-Modified, changed page, actual REST refresh/CAS consumer.

Дополнение для выбранного пути:
- Отсутствующий/terminal-only ETag и Last-Modified, changed page, actual REST refresh/CAS consumer.
- Реальный two-source batch, повторные страницы, версия aggregate content, malformed 429/exhausted retry и cleanup/continuation проверены.
- SA-01 injective id/version + reopen/collision. SA-02 explicit candidate versus governed missing contract. SA-03 structural geometry/properties ID. AR-01 retry veto/budget. AR-02 aggregate all-pages version. AR-03 typed failure+resource cleanup+later-good batch. Actual two-source persistence/refresh where selected.

Пакетная граница: Реальный two-source batch, повторные страницы, версия aggregate content, malformed 429/exhausted retry и cleanup/continuation проверены.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/94.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high for declared multi-page counterexample; production consumer reach unqualified; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: Fresh DTO reader читает audit JSON, не product CAS/cache. Единственный обнаруженный production is_newer_than caller — file_tabular; REST refresh effect не доказан.
- Примечания к распределению: - Activation: Actual selected source/provider invokes affected registry, middleware, GeoJSON or REST path; each row requires its own activation evidence.
- Otherwise: before_affected_provider_claim_or_after_12
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - Fresh DTO reader читает audit JSON, не product CAS/cache. Единственный обнаруженный production is_newer_than caller — file_tabular; REST refresh effect не доказан.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## AR-03 · Ошибки rate metadata и исчерпания retry выходят за FetchError boundary

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R10.3; механизм: AR-03.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-01; {"stage": "LANE-08", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: existing source owner named by primary report; paths: fabric/connectors/reference/rest_json.py:664-677, fabric/ingestion/ingestion.py:771-821,1333-1355, fabric/data_plane/modes.py:954-968; owner lanes: LANE-08.
- Владелец интеграционной приёмки: LANE-01 / ACQ-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: ACQ-01 (LANE-01), CYC-03 (LANE-01), ING-01 (LANE-08), ING-02 (LANE-08), NET-01 (LANE-08), NET-02 (LANE-08). Дополнение: ADDON::AR-03 (не официальный E02 ID).
- Основание: Selected acquisition не может опираться на schema collision, inferred admission или неверный aggregate REST version. Connector/ingest owners исходного L08 сохраняются. GeoJSON только при выбранном provider. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-01 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-01. Режим: conditional_connector_corrective_window.
- Если условие не активно: before_affected_provider_claim_or_after_12
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. primary_stage is first integration/rebind checkpoint; implementation is due there only under activation_condition. If not active, preserve finding open and route according to otherwise_route; absence of reachability proof is not PASS.

### Предлагаемое действие
Согласовать typed provider/error boundary с caller continuation, не поглощать cancellation.

Граница patch: Три subcontracts одного REST adapter; shared retry owner уже существует.

### Условия и зависимости
Gate: **conditional_profile_gate**. Actual selected source/provider invokes affected registry, middleware, GeoJSON or REST path; each row requires its own activation evidence.

- Finite actual provider/profile census до consumer. Последовательное corrective окно L08 для найденного affected path; не обязательный ремонт всех providers для одного E02 case.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Реальный two-source batch: продолжение только разрешённых fetch failures; handles, cancellation, storage/replay.

Дополнение для выбранного пути:
- Реальный two-source batch: продолжение только разрешённых fetch failures; handles, cancellation, storage/replay.
- Реальный two-source batch, повторные страницы, версия aggregate content, malformed 429/exhausted retry и cleanup/continuation проверены.
- SA-01 injective id/version + reopen/collision. SA-02 explicit candidate versus governed missing contract. SA-03 structural geometry/properties ID. AR-01 retry veto/budget. AR-02 aggregate all-pages version. AR-03 typed failure+resource cleanup+later-good batch. Actual two-source persistence/refresh where selected.

Пакетная граница: Реальный two-source batch, повторные страницы, версия aggregate content, malformed 429/exhausted retry и cleanup/continuation проверены.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/95.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high for exception types/bridge; full batch source-traced; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: Четыре handles освобождены; 403/cancellation fail closed. Full two-source batch/record-replay не исполнен.
- Примечания к распределению: - Activation: Actual selected source/provider invokes affected registry, middleware, GeoJSON or REST path; each row requires its own activation evidence.
- Otherwise: before_affected_provider_claim_or_after_12
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - Четыре handles освобождены; 403/cancellation fail closed. Full two-source batch/record-replay не исполнен.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## UI-03 · Запрет API imports из features не обеспечен checker

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R8.4; механизм: UI-03.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: Before first current reliance on affected gate/profile; LANE-12 frozen source/artifact if changed; DA-08 impact-based final refresh.
- Владелец механизма: Существующий dashboard architecture/import policy checker owner.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: Прямой пакет оставшегося E02 не установлен. Дополнение: ADDON::UI-03 (не официальный E02 ID).
- Основание: Независимое dashboard architecture окно до приёмки этой boundary. Это другой checker, чем runtime-api-client architecture gate.
- Первый rebind checkpoint: CORRECTIVE. Режим: QUALIFICATION_BEFORE_RELYING_ON_GATE.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
На native full scan реальные forbidden API→features imports должны отвергаться, а разрешённые finite facades и прежние cross-feature controls проходить.

Граница patch: Existing AST checker на установленном TS/Node22 профиле; без нового architecture framework.

### Условия и зависимости
Gate: **QUALIFICATION_BEFORE_RELYING_ON_GATE**. Закрыть до утверждения, что dashboard API→features boundary обеспечивается проверкой. Не все E02 lanes зависят от dashboard.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Real imports и allowed alternatives через native full scan, preserve existing cross-feature refusal.

Дополнение для выбранного пути:
**Предлагаемая работа**
На native full scan реальные forbidden API→features imports должны отвергаться, а разрешённые finite facades и прежние cross-feature controls проходить.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Исходная приёмка**
Real imports и allowed alternatives через native full scan, preserve existing cross-feature refusal.

**Что сохранить**
Не смешивать одноимённые check-architecture.mjs разных packages и не запрещать корректные facade exports. Полный audit checker не дошёл до AST scan из-за missing TypeScript.

Пакетная граница: Реальные запрещённые imports отвергаются, разрешённые finite facade exports остаются.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/98.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high exact policy function plus source controls; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: Полный architecture checker блокирован missing TypeScript до AST scan; private cross-feature import уже отвергается.
- Примечания к распределению: Full audit checker was blocked by missing TypeScript before AST scan; selected policy function gap was shown.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## policy-assembly::PA-01 · Сохранённый plan теряет versioned executable identity

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R11.2; механизм: policy-assembly::PA-01.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-01; {"stage": "LANE-04", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: existing source owner named by primary report; paths: ; owner lanes: LANE-04.
- Владелец интеграционной приёмки: LANE-01 / CYC-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: CYC-01 (LANE-01), SIM-01 (LANE-01), CMP-01 (LANE-04), CMP-02 (LANE-04), CMP-03 (LANE-04), RES-04 (LANE-04). Дополнение: ADDON::policy-assembly::PA-01 (не официальный E02 ID).
- Основание: Compiler/lowering и persisted recipe являются ранними L04 owners. L01 не должен закреплять downstream result на незакреплённой version или неисполняемом typed threshold. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-01 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-01. Режим: conditional_corrective_window_before_selected_execution.
- Если условие не активно: first_actual_affected_consumer_or_after_12
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. primary_stage is first integration/rebind checkpoint; implementation is due there only under activation_condition. If not active, preserve finding open and route according to otherwise_route; absence of reachability proof is not PASS.

### Предлагаемое действие
Сохранить exact selected method/kernel identity и dependency closure в plan; не re-resolve mutable type projection.

Граница patch: Отдельный owner contract, без cache и mismatched supplier; UniversalRegistry не требуется.

### Условия и зависимости
Gate: **conditional_profile_gate**. Selected L01 profile действительно потребляет affected policy-assembly compiled/lowered plan. Иначе лишь current owner characterization, без blanket блокировки всего L01.

- При фактическом использовании affected executable plan открыть последовательное corrective окно L04; затем вернуть только affected I04/I01 и checkpoint evidence. MA repair отдельно.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R11.2", "to": "R9.3", "kind": "path_identity_migration", "reason": "If relocating versioned kernels, update qualified binding/history rather than silently re-resolve."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Все registration orders, namespaces, unrelated growth, fresh process и genuine full executor; changed imported kernel must distinguish.

Дополнение для выбранного пути:
- Все registration orders, namespaces, unrelated growth, fresh process и genuine full executor; changed imported kernel must distinguish.
- Старый selected plan после v1/v2/v10/unrelated growth имеет тот же kernel либо typed refusal при несовместимости code/profile/fidelity.
- PA-01: старый selected plan сохраняет kernel после eager v1/v2/v10 и unrelated growth. PA-02: money/rate/count/duration compile→persist→fresh evaluator сохраняют type/unit/time semantics; mismatch отказывает до effects.

Пакетная граница: Старый selected plan после v1/v2/v10/unrelated growth имеет тот же kernel либо typed refusal при несовместимости code/profile/fidelity.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/100.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high_for_registry_compile_constructor_seam; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: Distinct от MA cache/lazy mismatch: здесь eager consistent FQNs. Нет full graph/JAX/scientific/publication qualification; class-source capture не связывает imported kernel closure и не является proved blocking gate.
- Примечания к распределению: - Activation: Selected L01 profile действительно потребляет affected policy-assembly compiled/lowered plan. Иначе лишь current owner characterization, без blanket блокировки всего L01.
- Otherwise: first_actual_affected_consumer_or_after_12
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - Distinct от MA cache/lazy mismatch: здесь eager consistent FQNs. Нет full graph/JAX/scientific/publication qualification; class-source capture не связывает imported kernel closure и не является proved blocking gate.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## policy-assembly::PA-02 · Typed threshold теряет исполнимое представление при lowering

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R11.4; механизм: policy-assembly::PA-02.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-01; {"stage": "LANE-04", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: existing source owner named by primary report; paths: ; owner lanes: LANE-04.
- Владелец интеграционной приёмки: LANE-01 / CYC-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: CYC-01 (LANE-01), SIM-01 (LANE-01), CMP-01 (LANE-04), CMP-02 (LANE-04), CMP-03 (LANE-04), RES-04 (LANE-04). Дополнение: ADDON::policy-assembly::PA-02 (не официальный E02 ID).
- Основание: Compiler/lowering и persisted recipe являются ранними L04 owners. L01 не должен закреплять downstream result на незакреплённой version или неисполняемом typed threshold. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-01 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-01. Режим: conditional_corrective_window_before_selected_execution.
- Если условие не активно: first_actual_affected_consumer_or_after_12
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. primary_stage is first integration/rebind checkpoint; implementation is due there only under activation_condition. If not active, preserve finding open and route according to otherwise_route; absence of reachability proof is not PASS.

### Предлагаемое действие
Typed executable threshold codec через lowering/persistence/evaluator без ослабления unit checks.

Граница patch: Versioned IR/compiler/runtime codec с unit/time семантикой; не вынимать произвольное поле value.

### Условия и зависимости
Gate: **conditional_profile_gate**. Selected L01 profile действительно потребляет affected policy-assembly compiled/lowered plan. Иначе лишь current owner characterization, без blanket блокировки всего L01.

- При фактическом использовании affected executable plan открыть последовательное corrective окно L04; затем вернуть только affected I04/I01 и checkpoint evidence. MA repair отдельно.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: USD fresh compile/evaluate pass и violation, EUR mismatch refusal; остальные units с полным compiler/executor envelope.

Дополнение для выбранного пути:
- USD fresh compile/evaluate pass и violation, EUR mismatch refusal; остальные units с полным compiler/executor envelope.
- Каждый wrapper compile→persist→fresh evaluator; mismatching units/time/currency отказывают.
- PA-01: старый selected plan сохраняет kernel после eager v1/v2/v10 и unrelated growth. PA-02: money/rate/count/duration compile→persist→fresh evaluator сохраняют type/unit/time semantics; mismatch отказывает до effects.

Пакетная граница: Каждый wrapper compile→persist→fresh evaluator; mismatching units/time/currency отказывают.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/101.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: Fail-closed runtime failure, не false approval. Rate/Count/Duration только lowerer/evaluator differential, не полный unit-aware roundtrip.
- Примечания к распределению: - Activation: Selected L01 profile действительно потребляет affected policy-assembly compiled/lowered plan. Иначе лишь current owner characterization, без blanket блокировки всего L01.
- Otherwise: first_actual_affected_consumer_or_after_12
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - Fail-closed runtime failure, не false approval. Rate/Count/Duration только lowerer/evaluator differential, не полный unit-aware roundtrip.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## custody::RC-01 · Историческое exact acceptance не проходит current state rebuilder

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R5.3; механизм: custody::RC-01.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: DA-08: только затронутые фактически выбранные paths.
- Владелец механизма: Существующие chronology custody service и Core verifier.
- Владелец интеграционной приёмки: Owner exact historical reader; CYC-03 только при фактическом подключении custody history. Именной исполнитель ещё не назначен.
- E02: CYC-03 (LANE-01). Дополнение: ADDON::custody::RC-01 (не официальный E02 ID).
- Основание: Исторический exact receipt проходит generic verifier, но current-state rebuilder его отвергает после lineage advancement. Это отдельный history-availability owner, не дефект разрешения current authority.
- Первый rebind checkpoint: CORRECTIVE. Режим: AFFECTED_CONSUMER_ONLY.
- Если условие не активно: AFTER-12 как bounded history repair, если обещанный E02 путь не использует service
- Граница связи: Самостоятельное ADDON исходного owner. Указанные E02 packages, если есть, только возможные selected-consumer context; существующий TEST не считается покрытием нового finding.

### Предлагаемое действие
Разделить historical reconstruction intent и current-state admission в существующих service/verifier. Историческое чтение не должно выдавать право на новое применение.

Граница patch: Разделить intent исторического чтения и live authorization, не менять существующие права.

### Условия и зависимости
Gate: **AFFECTED_CONSUMER_ONLY**. До приёмки конкретного exact historical reopen, если CYC/history route обещает и реально использует этот service; текущий валидный receipt и независимые N5/N8 paths не блокируются.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Три sequential acceptances, historical/current exact query, fresh/archived reopen; poisoned append/signature/query/revoked issuer negatives; native service/API contract.

Дополнение для выбранного пути:
- Три последовательных acceptance, current и historical exact query; fresh/archived reopen.
- Poisoned append/signature/query/revoked issuer negatives; тот же native service/API, не только generic verifier.
- Документировать фактический public historical SLA либо его отсутствие; не заявлять authority bypass.

Пакетная граница: Историческое чтение при допустимом intent работает; current/revoked/foreign authority guards остаются.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/102.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high bounded mechanism; native profile unverified; уверенность распределения: medium_document_grounded_current_route_unverified.
- Ограничения: Historical intent явен в core verifier; отдельный public endpoint historical SLA не установлен. Это bounded integration/history availability mismatch, не authority bypass; synthetic issuer/native inputs.
- Примечания к распределению: Нет дополнительных.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## DST-01 · Реальная проверка PostgreSQL остаётся необязательной в CI

- Тип: Пробел квалификации. Работа: qualification_not_automatic_code_fix.
- Remediation unit: R0.1; механизм: DST-01.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: Before first current reliance on affected gate/profile; LANE-12 frozen source/artifact if changed; DA-08 impact-based final refresh.
- Владелец механизма: Существующие PostgreSQL lane, SQL concurrency/readback/cancel test owners.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: RUN-01 (LANE-06), DUR-02 (LANE-06), CLI-01 (LANE-12). Дополнение: ADDON::DST-01 (не официальный E02 ID).
- Основание: Отдельное backend qualification corrective window до SQL claims. Его нельзя целиком отложить до LANE-12; это precondition реальной базы, а не доказанная неисправность всех backends.
- Первый rebind checkpoint: CORRECTIVE. Режим: QUALIFICATION_BEFORE_RELYING_ON_GATE.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Объявить выбранную PostgreSQL lane, настоящий DSN/isolated schema и обязательный flag. Собрать и выполнить selected concurrency/readback/cancel cases. Удаление DSN/setup/flag не должно превращаться в молчаливый PASS.

Граница patch: Environment/bootstrap, installed lane и PostgreSQL/corpus — отдельные изменения с общей приёмкой воспроизводимого профиля.

### Условия и зависимости
Gate: **QUALIFICATION_BEFORE_RELYING_ON_GATE**. Блокируются только PostgreSQL-dependent claims. Уже имеющийся C57 gate и отдельно проверенные backends сохраняют свою область доказательств.

Нет дополнительных.

Исходные зависимости: []

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Actual native collection, SQL concurrency/readback/cancel, missing DSN/setup/flag removal controls и hosted receipts.

Дополнение для выбранного пути:
**Предлагаемая работа**
Объявить выбранную PostgreSQL lane, настоящий DSN/isolated schema и обязательный flag. Собрать и выполнить selected concurrency/readback/cancel cases. Удаление DSN/setup/flag не должно превращаться в молчаливый PASS.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Исходная приёмка**
Actual native collection, SQL concurrency/readback/cancel, missing DSN/setup/flag removal controls и hosted receipts.

**Что сохранить**
Не заменять реальный SQL fixture и не утверждать, что всякая backend error становится skip. Связь с E02 consumers сначала проверить на actual path.

Пакетная граница: На поддерживаемом профиле действительно выполнены нужные consumers; missing backend/input явно unqualified или отказ, не PASS.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/105.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see bounded author/review; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: Не всякая backend error превращается в skip. Изолированная schema fixture существует. 52 source-defined bodies прочитаны, не collected/executed; hosted result неизвестен.
- Примечания к распределению: Listed E02 packets are possible consumers, not verified current dependency or new hard predecessors.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## DST-02 · Standard Integration не объявляет inputs выбранных real corpus tests

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R0.1; механизм: DST-02.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: Before first current reliance on affected gate/profile; LANE-12 frozen source/artifact if changed; DA-08 impact-based final refresh.
- Владелец механизма: Существующие real-corpus provisioning, Standard Integration и substrate builder owners.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: CYC-01 (LANE-01), ACQ-01 (LANE-01). Дополнение: ADDON::DST-02 (не официальный E02 ID).
- Основание: Независимая квалификация inputs до затронутых Standard Integration/corpus claims. Привязка к CYC/ACQ является проверяемой гипотезой о consumer, не готовым test binding.
- Первый rebind checkpoint: CORRECTIVE. Режим: QUALIFICATION_BEFORE_RELYING_ON_GATE.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Объявить pinned corpus bytes и provisioning, выполнить настоящий builder и selected cases. Добавить отдельный removal control для каждого обязательного файла. Зафиксировать, какой профиль фактически потребляет этот corpus.

Граница patch: Environment/bootstrap, installed lane и PostgreSQL/corpus — отдельные изменения с общей приёмкой воспроизводимого профиля.

### Условия и зависимости
Gate: **QUALIFICATION_BEFORE_RELYING_ON_GATE**. Блокируются claims, которым необходимы выбранные real corpus cases, а не вся реализация E02.

Нет дополнительных.

Исходные зависимости: []

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Pinned bytes/provisioning, actual builder and selected cases, each required-file removal и missing-input refusal.

Дополнение для выбранного пути:
**Предлагаемая работа**
Объявить pinned corpus bytes и provisioning, выполнить настоящий builder и selected cases. Добавить отдельный removal control для каждого обязательного файла. Зафиксировать, какой профиль фактически потребляет этот corpus.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Исходная приёмка**
Pinned bytes/provisioning, actual builder and selected cases, each required-file removal и missing-input refusal.

**Что сохранить**
Отсутствующий input должен оставаться явным отказом. Проверка существования файла не заменяет проверку содержимого; native builder/hosted execution не приписывать аудиту.

Пакетная граница: На поддерживаемом профиле действительно выполнены нужные consumers; missing backend/input явно unqualified или отказ, не PASS.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/106.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see bounded author/review; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: Existence-only positive не валидирует corpus; native builder/hosted job не выполнялись, более ранние setup failures возможны.
- Примечания к распределению: No hosted job or native builder was executed in the audit. Packet association is a proposed consumer check, not proven exact test binding.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## CR-01 · Calibration adapter обходит существующие Gaussian representability guards

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R12.3; механизм: CR-01.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-03; {"stage": "LANE-10", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: foundry.calibration.uncertainty_adapter; paths: policy-engine/src/polisyos/foundry/calibration/uncertainty_adapter.py:305-354, policy-engine/src/polisyos/ir/analytics/uncertainty.py:546-568,1415-1437; owner lanes: LANE-10.
- Владелец интеграционной приёмки: LANE-03 / FRC-02: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: FRC-02 (LANE-03), BKT-01 (LANE-03), BKT-02 (LANE-03), CAL-06 (LANE-10), UQP-01 (LANE-10), UQP-02 (LANE-10), UQP-03 (LANE-10). Дополнение: ADDON::CR-01 (не официальный E02 ID).
- Основание: Gaussian carrier и push-forward принадлежат L10/IR numerical owners; L03 получает только корректный interval/law producer. Если affected path уже выбран в L01, перенести окно перед его первым claim. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-03 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-03. Режим: conditional_numeric_corrective_before_interval_claim.
- Если условие не активно: public_helper_repair_after_12_if_no_earlier_consumer
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. primary_stage is first integration/rebind checkpoint; implementation is due there only under activation_condition. If not active, preserve finding open and route according to otherwise_route; absence of reachability proof is not PASS.

### Предлагаемое действие
Reuse/extend existing Gaussian owner с carrier/covariance/refusal semantics.

Граница patch: Reuse existing guard требует carrier extension; не arbitrary precision и не automatic promotion.

### Условия и зависимости
Gate: **conditional_profile_gate**. Chosen L03 (or earlier L01) forecast/uncertainty profile invokes affected Gaussian adapter/helper. For CR-02 absence of known caller is not proof of universal activation.

- Не floor sigma tolerance; не повышать heuristic range до deterministic bounds. Исправление adapter и публичного helper — раздельно; CR-02 actual literal caller не установлен.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Scale/representation covariance, large center/tiny spread и fresh envelope/report reads; carrier consistency, preserved candidate trust refusal.

Дополнение для выбранного пути:
- Scale/representation covariance, large center/tiny spread и fresh envelope/report reads; carrier consistency, preserved candidate trust refusal.
- Linear/constant/unit-scale/absorption controls, consistent carrier и fresh gate=false; actual live callers отдельно.
- CR-01 representable spread либо typed refusal, unit scaling and persistence. CR-02 linear 1e13x std1, not10; heuristic bounds retain role. Native selected persisted consumer; public helper contract tested even if runtime activation remains unproven.

Пакетная граница: Linear/constant/unit-scale/absorption controls, consistent carrier и fresh gate=false; actual live callers отдельно.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/107.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see bounded author/review; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: Candidate numerical correctness only. Helper не переносит carrier без расширения; DECIMAL_EXACT не arbitrary precision. Heuristic gate=false сохранён.
- Примечания к распределению: - Activation: Chosen L03 (or earlier L01) forecast/uncertainty profile invokes affected Gaussian adapter/helper. For CR-02 absence of known caller is not proof of universal activation.
- Otherwise: public_helper_repair_after_12_if_no_earlier_consumer
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - Candidate numerical correctness only. Helper не переносит carrier без расширения; DECIMAL_EXACT не arbitrary precision. Heuristic gate=false сохранён.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## CR-02 · Push forward принимает tolerance за SD и повышает статус bounds

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R12.3; механизм: CR-02.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-03; {"stage": "LANE-10", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: ir.analytics.uncertainty; paths: policy-engine/src/polisyos/ir/analytics/uncertainty.py:1141-1154,1776-1812; owner lanes: LANE-10.
- Владелец интеграционной приёмки: LANE-03 / FRC-02: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: FRC-02 (LANE-03), BKT-01 (LANE-03), BKT-02 (LANE-03), CAL-06 (LANE-10), UQP-01 (LANE-10), UQP-02 (LANE-10), UQP-03 (LANE-10). Дополнение: ADDON::CR-02 (не официальный E02 ID).
- Основание: Gaussian carrier и push-forward принадлежат L10/IR numerical owners; L03 получает только корректный interval/law producer. Если affected path уже выбран в L01, перенести окно перед его первым claim. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-03 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-03. Режим: conditional_numeric_corrective_before_interval_claim.
- Если условие не активно: public_helper_repair_after_12_if_no_earlier_consumer
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. primary_stage is first integration/rebind checkpoint; implementation is due there only under activation_condition. If not active, preserve finding open and route according to otherwise_route; absence of reachability proof is not PASS.

### Предлагаемое действие
Разделить numerical tolerance и статистический scale; не повышать heuristic support до deterministic без proof.

Граница patch: Reuse existing guard требует carrier extension; не arbitrary precision и не automatic promotion.

### Условия и зависимости
Gate: **conditional_profile_gate**. Chosen L03 (or earlier L01) forecast/uncertainty profile invokes affected Gaussian adapter/helper. For CR-02 absence of known caller is not proof of universal activation.

- Не floor sigma tolerance; не повышать heuristic range до deterministic bounds. Исправление adapter и публичного helper — раздельно; CR-02 actual literal caller не установлен.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Linear/constant maps, scale covariance, tolerance 0/default и semantic-kind persistence; actual caller если найден.

Дополнение для выбранного пути:
- Linear/constant maps, scale covariance, tolerance 0/default и semantic-kind persistence; actual caller если найден.
- Linear/constant/unit-scale/absorption controls, consistent carrier и fresh gate=false; actual live callers отдельно.
- CR-01 representable spread либо typed refusal, unit scaling and persistence. CR-02 linear 1e13x std1, not10; heuristic bounds retain role. Native selected persisted consumer; public helper contract tested even if runtime activation remains unproven.

Пакетная граница: Linear/constant/unit-scale/absorption controls, consistent carrier и fresh gate=false; actual live callers отдельно.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/108.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see bounded author/review; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: P3 exported API only; literal product caller не найден, dynamic/external не исключены. gate=false и trust refusal сохранены; один API finding с двумя связанными аспектами.
- Примечания к распределению: - Activation: Chosen L03 (or earlier L01) forecast/uncertainty profile invokes affected Gaussian adapter/helper. For CR-02 absence of known caller is not proof of universal activation.
- Otherwise: public_helper_repair_after_12_if_no_earlier_consumer
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - P3 exported API only; literal product caller не найден, dynamic/external не исключены. gate=false и trust refusal сохранены; один API finding с двумя связанными аспектами.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## REL-01 · Свежие release jobs не получают обязательный generated snapshot

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R13.1; механизм: REL-01.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: Before actual affected release/deployment; LANE-12 only if its selected build or client path relies on this contract; DA-06 bound build evidence as relevant.
- Владелец механизма: Существующие release workflow/build/version/provenance owners.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: HYG-04 (LANE-12), DFK-01 (LANE-12), CYC-05 (LANE-01). Дополнение: ADDON::REL-01 (не официальный E02 ID).
- Основание: Release qualification после source fixes и до actual publication. Владелец отдельный от обычной I12 installed acceptance; immutable source/artifact basis нужно согласовать, а не заменить одним тестом.
- Первый rebind checkpoint: CORRECTIVE. Режим: CONDITIONAL_RELEASE_OR_DEPLOYMENT_GATE.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Связать exact source/tag/build/shipped object и передавать обязательный generated snapshot между fresh prepare/build/notes jobs. Проверить schema всех выбранных fragments, missing-artifact controls и разные SHA при одинаковой version для manual dispatch.

Граница patch: Две причины одной release chain: REL-01 repair открывает путь REL-02, поэтому release acceptance общая.

### Условия и зависимости
Gate: **CONDITIONAL_RELEASE_OR_DEPLOYMENT_GATE**. Блокирует настоящий release через затронутый workflow. Если I12 использует его для собственного artifact evidence, исправить до этого evidence; иначе software acceptance остаётся отдельно от release readiness.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R5.1", "to": "R13.1", "kind": "release_acceptance", "reason": "Shipped release acceptance includes exact canonical/rendered/served policy parity."}
- {"from": "R13.2", "to": "R13.1", "kind": "release_acceptance", "reason": "Actual report and scanner result bind to actual shipped-object SBOM."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Fresh prepare/build/notes consumers, 548-fragment census/removal oracle, job artifact digest и version/tag consistency.

Дополнение для выбранного пути:
**Предлагаемая работа**
Связать exact source/tag/build/shipped object и передавать обязательный generated snapshot между fresh prepare/build/notes jobs. Проверить schema всех выбранных fragments, missing-artifact controls и разные SHA при одинаковой version для manual dispatch.

**E02 context, не автоматическое покрытие**
- E02-I12-A
- DA-06
- DA-08

**Исходная приёмка**
Fresh prepare/build/notes consumers, 548-fragment census/removal oracle, job artifact digest и version/tag consistency.

**Что сохранить**
Сохранить frozen-source builds, exact artifact digests и provenance. CYC-05 получает связанное build evidence через существующего issuer, не второй registry. Не заявлять состоявшийся exploit/publication или checkout latest main.

Пакетная граница: Schema-valid fragments, exact snapshot transfer, tag/source/build/shipped/SBOM binding на fresh hosted jobs; privileged exploit не предполагается.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/109.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: High — release-blocking operational priority, не exploit. Fragment schema-invalid, не syntax-invalid TOML. Hosted release/shipped artifact не выполнены.
- Примечания к распределению: REL-01 is an operational release blocker; REL-02 is privileged release integrity risk. No observed publication/exploit or claim checkout uses latest main.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## REL-02 · Release tag не связан с checkout и build source SHA

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R13.1; механизм: REL-02.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: Before actual affected release/deployment; LANE-12 only if its selected build or client path relies on this contract; DA-06 bound build evidence as relevant.
- Владелец механизма: Существующие release workflow/build/version/provenance owners.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: HYG-04 (LANE-12), DFK-01 (LANE-12), CYC-05 (LANE-01). Дополнение: ADDON::REL-02 (не официальный E02 ID).
- Основание: Release qualification после source fixes и до actual publication. Владелец отдельный от обычной I12 installed acceptance; immutable source/artifact basis нужно согласовать, а не заменить одним тестом.
- Первый rebind checkpoint: CORRECTIVE. Режим: CONDITIONAL_RELEASE_OR_DEPLOYMENT_GATE.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Связать exact source/tag/build/shipped object и передавать обязательный generated snapshot между fresh prepare/build/notes jobs. Проверить schema всех выбранных fragments, missing-artifact controls и разные SHA при одинаковой version для manual dispatch.

Граница patch: Две причины одной release chain: REL-01 repair открывает путь REL-02, поэтому release acceptance общая.

### Условия и зависимости
Gate: **CONDITIONAL_RELEASE_OR_DEPLOYMENT_GATE**. Блокирует настоящий release через затронутый workflow. Если I12 использует его для собственного artifact evidence, исправить до этого evidence; иначе software acceptance остаётся отдельно от release readiness.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R5.1", "to": "R13.1", "kind": "release_acceptance", "reason": "Shipped release acceptance includes exact canonical/rendered/served policy parity."}
- {"from": "R13.2", "to": "R13.1", "kind": "release_acceptance", "reason": "Actual report and scanner result bind to actual shipped-object SBOM."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Automatic tag push и manual dispatch, matching/mismatching SHA при одинаковой version, approvals и attestation subject on actual immutable object.

Дополнение для выбранного пути:
**Предлагаемая работа**
Связать exact source/tag/build/shipped object и передавать обязательный generated snapshot между fresh prepare/build/notes jobs. Проверить schema всех выбранных fragments, missing-artifact controls и разные SHA при одинаковой version для manual dispatch.

**E02 context, не автоматическое покрытие**
- E02-I12-A
- DA-06
- DA-08

**Исходная приёмка**
Automatic tag push и manual dispatch, matching/mismatching SHA при одинаковой version, approvals и attestation subject on actual immutable object.

**Что сохранить**
Сохранить frozen-source builds, exact artifact digests и provenance. CYC-05 получает связанное build evidence через существующего issuer, не второй registry. Не заявлять состоявшийся exploit/publication или checkout latest main.

Пакетная граница: Schema-valid fragments, exact snapshot transfer, tag/source/build/shipped/SBOM binding на fresh hosted jobs; privileged exploit не предполагается.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/110.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: High — privileged release integrity priority. Default checkout привязан к event ref/SHA, не latest main; low-privilege actor/approval bypass/wrong publication не установлены. REL-01 блокирует fresh prepare.
- Примечания к распределению: REL-01 is an operational release blocker; REL-02 is privileged release integrity risk. No observed publication/exploit or claim checkout uses latest main.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## REL-03 · Evaluator принимает отсутствующий или неверный scan result за отсутствие findings

- Тип: Риск или устойчивость. Работа: risk_qualification_then_bounded_repair_if_supported.
- Remediation unit: R13.2; механизм: REL-03.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: Before actual affected release/deployment; LANE-12 only if its selected build or client path relies on this contract; DA-06 bound build evidence as relevant.
- Владелец механизма: Существующий release vulnerability evaluator и scanner-result contract owner.
- Владелец интеграционной приёмки: Существующий domain/tool owner через единого координатора E02; конкретный действующий исполнитель не установлен. Именной исполнитель ещё не назначен.
- E02: Прямой пакет оставшегося E02 не установлен. Дополнение: ADDON::REL-03 (не официальный E02 ID).
- Основание: То же release qualification окно, отдельный контракт scanner result. Это robustness/policy decision, а не доказанный Grype success-path exploit.
- Первый rebind checkpoint: CORRECTIVE. Режим: CONDITIONAL_RELEASE_OR_DEPLOYMENT_GATE.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Проверить типизированный scanner JSON, pinned scanner/SBOM/database, upstream valid empty/Critical, malformed-success outputs, exceptions и nonzero caller failure.

Граница patch: Typed report schema и actual scanner/SBOM binding; malformed-success от реального scanner ещё не доказан.

### Условия и зависимости
Gate: **CONDITIONAL_RELEASE_OR_DEPLOYMENT_GATE**. Закрыть до заявления о fail-closed vulnerability evaluation выбранного scanner contract. Решить существенную Unknown severity policy явно, не предполагать обязательный блок по Unknown.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R13.2", "to": "R13.1", "kind": "release_acceptance", "reason": "Actual report and scanner result bind to actual shipped-object SBOM."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Actual pinned scanner/SBOM/database, malformed-success reachability, upstream empty/Critical, invalid JSON/types, exceptions и scanner failure.

Дополнение для выбранного пути:
**Предлагаемая работа**
Проверить типизированный scanner JSON, pinned scanner/SBOM/database, upstream valid empty/Critical, malformed-success outputs, exceptions и nonzero caller failure.

**E02 context, не автоматическое покрытие**
Нет дополнительных.

**Исходная приёмка**
Actual pinned scanner/SBOM/database, malformed-success reachability, upstream empty/Critical, invalid JSON/types, exceptions и scanner failure.

**Что сохранить**
Real Critical уже блокирует выпуск, nonzero scanner уже останавливает caller. Сохранить эти guards и exact SBOM/source binding; достижимость successful malformed output реального scanner не установлена.

Пакетная граница: Pinned scanner, nonzero failure, valid empty, real Critical и malformed reports; Unknown severity policy решена явно.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/111.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: Medium robustness only. Upstream Grype model создаёт array matches; successful malformed output реального scanner не доказан. Unknown rank=0 — явная policy; fix nesting влияет лишь на summary.
- Примечания к распределению: Upstream Grype ordinarily creates matches array; audit did not establish real successful malformed output reachability.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## semantic-matching::F1 · Решение поиска об ambiguity и threshold теряется перед выбором плана

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R14.1; механизм: semantic-matching::F1.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-01; {"stage": "LANE-08", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: Existing Fabric MetricSearcher/FastLane/RetrievalService; paths: fabric/catalog/resolver_fast_lane.py:141-178,319-335, fabric/retrieval/service.py:730-872, fabric/retrieval/executor.py:249-308,493-525; owner lanes: LANE-08, LANE-01.
- Владелец интеграционной приёмки: LANE-01 / ACQ-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: ACQ-01 (LANE-01), REQ-01 (LANE-01), CYC-03 (LANE-01). Дополнение: ADDON::semantic-matching::F1 (не официальный E02 ID).
- Основание: Dataset search decision/alias occurrence должен дойти до exact acquisition plan. Это не method ranking SEL-01 и не один дефект с EC/DC. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-01 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-01. Режим: supplemental_source_owner_before_consumer.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. New supplemental contract is due at this integration phase in its declared selected scope; current HEAD may already satisfy it, to be evidenced rather than reimplemented.

### Предлагаемое действие
Не смешивать unresolved alternatives с selected execution. Сохранить decision до выбора плана; fallback требует equivalence или допустимого conversion, а не только rank.

Граница patch: CP23 F1 и F2 и NC-04b — отдельные fixes одного search-decision contract. Не единый compiler со scopes IR; не запрет всех unknown candidates.

### Условия и зависимости
Gate: **due_contract_gate**. Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.

- R14.1 прежде R7.1 ANN/ranking optimization. Fabric search/resolver/service/executor owner сериализован; после изменения plan повторить affected I01-B.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R14.1", "to": "R7.1", "kind": "semantic_acceptance", "reason": "Top-k/ANN must preserve ambiguity and request meaning before optimizing ranking."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Проверить неоднозначные и точные запросы, low confidence, эквивалентные и несовместимые fallback, конечный лимит и allow_fallback=False. Затем реальный registry/catalog → ordinary NL → persisted result → downstream admission.

Дополнение для выбранного пути:
- Проверить неоднозначные и точные запросы, low confidence, эквивалентные и несовместимые fallback, конечный лимит и allow_fallback=False. Затем реальный registry/catalog → ordinary NL → persisted result → downstream admission.
- Canonical/alias, explicit unit/population, repeated scoped requests, ambiguity/top-k/threshold и fallback equivalence через реальный NL→persisted consumer; strict capture fallback=false сохранён.
- Ambiguous/low-score не превращается в executable primary/fallback. Canonical и alias запросы имеют одинаковый substantive scope outcome, repeated occurrences не сливаются. Limit1 и limit5 не меняют известную неоднозначность.

Пакетная граница: Canonical/alias, explicit unit/population, repeated scoped requests, ambiguity/top-k/threshold и fallback equivalence через реальный NL→persisted consumer; strict capture fallback=false сохранён.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/112.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high bounded independent differential controls; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: Нативная полная NL/CAS цепь не выполнена. Preview I/O — fixtures. Strict persisted capture отдельно запрещает fallback; history смены метрики сохраняется. Public authority bypass не установлен.
- Примечания к распределению: - Activation: Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.
- Otherwise: None
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - Нативная полная NL/CAS цепь не выполнена. Preview I/O — fixtures. Strict persisted capture отдельно запрещает fallback; history смены метрики сохраняется. Public authority bypass не установлен.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## semantic-matching::F2 · Alias теряет связь occurrence запроса со scope выбранной метрики

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R14.1; механизм: semantic-matching::F2.
- Основное окно: **CORRECTIVE**. Вторичные checkpoints: LANE-01; {"stage": "LANE-08", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: Existing Fabric MetricSearcher/FastLane/RetrievalService; paths: fabric/catalog/resolver_fast_lane.py:141-178,319-335, fabric/retrieval/service.py:730-872, fabric/retrieval/executor.py:249-308,493-525; owner lanes: LANE-08, LANE-01.
- Владелец интеграционной приёмки: LANE-01 / ACQ-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: ACQ-01 (LANE-01), REQ-01 (LANE-01), CYC-03 (LANE-01). Дополнение: ADDON::semantic-matching::F2 (не официальный E02 ID).
- Основание: Dataset search decision/alias occurrence должен дойти до exact acquisition plan. Это не method ranking SEL-01 и не один дефект с EC/DC. Основное исполнение относится к отдельному bounded окну исходного owner; LANE-01 обозначает первый rebind/affected consumer checkpoint, а не массовый перенос source fixes в этот lane.
- Первый rebind checkpoint: LANE-01. Режим: supplemental_source_owner_before_consumer.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. New supplemental contract is due at this integration phase in its declared selected scope; current HEAD may already satisfy it, to be evidenced rather than reimplemented.

### Предлагаемое действие
Пронести occurrence ID и canonical relation через candidate/primary/fallback. Scope lookup должен использовать эту связь, а не равенство строк metric_id.

Граница patch: CP23 F1 и F2 и NC-04b — отдельные fixes одного search-decision contract. Не единый compiler со scopes IR; не запрет всех unknown candidates.

### Условия и зависимости
Gate: **due_contract_gate**. Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.

- R14.1 прежде R7.1 ANN/ranking optimization. Fabric search/resolver/service/executor owner сериализован; после изменения plan повторить affected I01-B.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R14.1", "to": "R7.1", "kind": "semantic_acceptance", "reason": "Top-k/ANN must preserve ambiguity and request meaning before optimizing ranking."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Alias и canonical для same/disjoint/partial scopes должны иметь согласованный смысловой outcome. Сохранить различия повторных occurrences и допустимый unknown candidate. Проверить catalog refusal и fallback scope, затем native catalog/persistence.

Дополнение для выбранного пути:
- Alias и canonical для same/disjoint/partial scopes должны иметь согласованный смысловой outcome. Сохранить различия повторных occurrences и допустимый unknown candidate. Проверить catalog refusal и fallback scope, затем native catalog/persistence.
- Canonical/alias, explicit unit/population, repeated scoped requests, ambiguity/top-k/threshold и fallback equivalence через реальный NL→persisted consumer; strict capture fallback=false сохранён.
- Ambiguous/low-score не превращается в executable primary/fallback. Canonical и alias запросы имеют одинаковый substantive scope outcome, repeated occurrences не сливаются. Limit1 и limit5 не меняют известную неоднозначность.

Пакетная граница: Canonical/alias, explicit unit/population, repeated scoped requests, ambiguity/top-k/threshold и fallback equivalence через реальный NL→persisted consumer; strict capture fallback=false сохранён.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/113.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high bounded independent differential controls; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: Unknown candidate и конфликтующие duplicate needs по контракту могут сохраняться с предупреждением. Здесь дефект — потеря известной связи; не требуется запрет всех unknown. Scientific/publication bypass не установлен.
- Примечания к распределению: - Activation: Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.
- Otherwise: None
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - Unknown candidate и конфликтующие duplicate needs по контракту могут сохраняться с предупреждением. Здесь дефект — потеря известной связи; не требуется запрет всех unknown. Scientific/publication bypass не установлен.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

