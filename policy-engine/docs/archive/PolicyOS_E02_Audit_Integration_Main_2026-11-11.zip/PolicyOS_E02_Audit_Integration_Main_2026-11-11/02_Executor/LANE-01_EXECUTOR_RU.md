# Текущий lane 01, предварительное включение

Статус: предварительный план, не свидетельство реализации. Основных карточек: 13. Сначала получить фактический отчёт исполнителя и сверить HEAD. Один implementation lane активен; corrective window приостанавливает затронутую работу, а не запускает параллельный lane.

## Порядок работы
1. Проверить текущую ветку/HEAD, незавершённые patches, write leases и источник evidence.
2. Для каждого пункта выбрать: уже закрыт; подтвердился; изменился контракт; не воспроизведён; UNRUN; требует решения. Сохранить причину и ссылку.
3. Выполнить только согласованный bounded patch или квалификацию у существующего owner.
4. Приложить точный oracle, контроли и affected-evidence map. Не ставить PASS по наличию файла/skip/fixture.
5. Обновить статус DA только в указанной части, не переносить весь TEST/REQ.

## Состав
- NS-03: Лимит декодирования становится границей видимости каталога
- FLOW-01: Владельцы N5 capture и observer удерживают payload
- DC-01: Составная grammar теряет независимые обязательства компонентов
- DC-02: Grammar усиливает четыре режима идентификации до point identified
- EC-01: Compiler заменяет scope каждого claim последним общим facet
- EC-02: Явный method facet не доходит до causal preconditions
- FG-03: Ранний NL normalizer не получает расширенный registry
- RD-01: Recomputed axes не сверяют декларации с доступными фактами occurrence
- NS-01: Конкурентный refresh публикует несогласованные cache и fingerprints
- PG-01: Legacy binding сохраняет overlap и частичный scope по документации
- MA-01: Registry cache теряет semantic metadata и использует lossy codec
- MA-02: Lazy dispatch не сверяет заявленный и загруженный executable
- MA-03: Cache не восстанавливает вложенный dotted qualname

## NS-03 · Лимит декодирования становится границей видимости каталога

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R6.5; механизм: NS-03.
- Основное окно: **LANE-01**. Вторичные checkpoints: нет дополнительных.
- Владелец механизма: RunIndexService; paths: runtime/http/services/run_index.py:302-350, runtime/http/services/adapters/core_run.py:316-450; owner lanes: LANE-01.
- Владелец интеграционной приёмки: LANE-01 / CYC-03: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: CYC-03 (LANE-01), CYC-02 (LANE-01). Дополнение: ADDON::NS-03 (не официальный E02 ID).
- Основание: CYC-03 требует действительный HTTP/export/UI current occurrence и complete history; run_index publication race/cap меняют доступный consumer denominator. Это не тот же owner, что SearchService CTL.
- Первый rebind checkpoint: LANE-01. Режим: in_lane_actual_history_surface_extension.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. New supplemental contract is due at this integration phase in its declared selected scope; current HEAD may already satisfy it, to be evidenced rather than reimplemented.

### Предлагаемое действие
Separate full run identity catalogue/exact lookup from bounded decoded cache.

Граница patch: Race и completeness — независимые subchanges одного read-model owner; display limit отдельно от decision population.

### Условия и зависимости
Gate: **due_contract_gate**. Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.

- Separate race/cap fixes с одним Runtime run read-model owner. NS-02 performance не prerequisite; CYC05 controls truth of stop отдельно.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R6.5", "to": "R7.2", "kind": "consistency_contract", "reason": "Request-local reuse must consume coherent complete run generation."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Native >cap test with CAS manifests, complete owner map, tenant guards and stable pagination.

Дополнение для выбранного пути:
- Native >cap test with CAS manifests, complete owner map, tenant guards and stable pagination.
- Concurrent refresh согласован; последняя retained run доступна независимо от presentation page/cap.
- Concurrent refresh publishes coherent rows/fingerprints; complete run population не display page/cap; retained last occurrence остаётся discoverable. Fresh consumer sees same selected history.

Пакетная граница: Concurrent refresh согласован; последняя retained run доступна независимо от presentation page/cap.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/2.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high bounded trace-only evidence; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: - No actual CAS manifest or artifact permission test.
- No-journal finalization fixture; selected DTO dependency annotations are fixtures.
- Примечания к распределению: - Activation: Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.
- Otherwise: None
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## FLOW-01 · Владельцы N5 capture и observer удерживают payload

- Тип: Риск или устойчивость. Работа: risk_qualification_then_bounded_repair_if_supported.
- Remediation unit: R2.3; механизм: FLOW-01.
- Основное окно: **LANE-01**. Вторичные checkpoints: нет дополнительных.
- Владелец механизма: Existing N5 capture/observer owner; paths: runtime/quality/n5_execution_basis.py:1129-1161; owner lanes: LANE-01.
- Владелец интеграционной приёмки: LANE-01 / CYC-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: CYC-01 (LANE-01), CYC-05 (LANE-01). Дополнение: ADDON::FLOW-01 (не официальный E02 ID).
- Основание: Exact N5 execution capture/token и completed observer принадлежат текущей L01 numerical path; bounded retention исправлять без разрушения живой authority.
- Первый rebind checkpoint: LANE-01. Режим: in_lane_lifetime_extension.
- Если условие не активно: Сохранить независимый candidate computation; qualifying lifetime/risk work может остаться отдельным bounded owner window без обязательного refactor.
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. New supplemental contract is due at this integration phase in its declared selected scope; current HEAD may already satisfy it, to be evidenced rather than reimplemented.

### Предлагаемое действие
Определить issuer release/disposal и revocation lifetime без ослабления fresh-session/current implementation/lease guards.

Граница patch: Disposal отдельно от authority; не объявлять retention доказанным production RSS leak.

### Условия и зависимости
Gate: **LIFETIME_RISK_QUALIFICATION_NOT_CANDIDATE_BLOCK**. Только конкретный lifetime/resource claim либо подтверждённая проблема текущего пути. Обычное использование N5 само по себе не блокируется до disposal refactor; bounded retained objects не доказывают production RSS/leak.

- До любого изменения lifetime проверить genuine issue/seal/revoke controls и ownership accounting observer. Object retention не является publication authority; не закрывать observer до physical settlement.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Genuine producer positive seal, release/GC/error-after-seal, historical/live/fresh-process and terminal revoke/PA2 acceptance.

Дополнение для выбранного пути:
- Genuine producer positive seal, release/GC/error-after-seal, historical/live/fresh-process and terminal revoke/PA2 acceptance.
- Genuine issuance/seal/live use/revoke/PA2 и bounded disposal проверены, historical proof не становится permit.
- Genuine issuance/seal/live use/revoke/PA2/disposal controls; payload освобождается после окончания owner lifetime, но historical read остаётся валидным.

Пакетная граница: Genuine issuance/seal/live use/revoke/PA2 и bounded disposal проверены, historical proof не становится permit.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/14.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: No production RSS, universal leak or native successful seal/revoke E2E; object retention is not publication authority.
- Примечания к распределению: - Только конкретный lifetime/resource claim либо подтверждённая проблема текущего пути. Обычное использование N5 само по себе не блокируется до disposal refactor; bounded retained objects не доказывают production RSS/leak.
- Сохранить независимый candidate computation; qualifying lifetime/risk work может остаться отдельным bounded owner window без обязательного refactor.
- Native issued/revoked E2E и production RSS не установлены источником.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## DC-01 · Составная grammar теряет независимые обязательства компонентов

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R3.1; механизм: COMPONENT-OBLIGATION-PROJECTION.
- Основное окно: **LANE-01**. Вторичные checkpoints: нет дополнительных.
- Владелец механизма: Existing grammar/decomposition/data/method compiler owners, coordinated semantic contract; paths: policy_grammar/_impl/normalizer.py:38-97, policy_grammar/_impl/facets.py:198-356, obligation_graph/_impl/compiler.py:307-350; owner lanes: LANE-01.
- Владелец интеграционной приёмки: LANE-01 / REQ-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: REQ-01 (LANE-01), CYC-01 (LANE-01), ACQ-01 (LANE-01), CYC-05 (LANE-01). Дополнение: ADDON::DC-01 (не официальный E02 ID).
- Основание: Прямое сохранение semantic input/полного compiler denominator до N7 и leaf N4/N5. FG-03 — отдельный NL registry bridge, не тот же механизм, что DC/EC.
- Первый rebind checkpoint: LANE-01. Режим: in_lane_contract_extension.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. New supplemental contract is due at this integration phase in its declared selected scope; current HEAD may already satisfy it, to be evidenced rather than reimplemented.

### Предлагаемое действие
Keep component-scoped semantic bindings through existing owners, or refuse composition outside the supported envelope; do not only widen scalar fields.

Граница patch: Grammar, decomposition/data и method consumers — отдельные writer units, общий end-to-end semantic contract. Универсальный union law не доказан.

### Условия и зависимости
Gate: **due_contract_gate**. Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.

- Сначала согласовать normalization/decomposition/requirement owner contracts, затем ACQ→CYC03. One writer per normalizer/compiler; не допускать raw specs bypass.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R3.1", "to": "R4.2", "kind": "integrated_science_acceptance", "reason": "Component scope must reach occurrence/measurement relation; local work can be parallel."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

Дополнение для выбранного пути:
- native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report
- Положительная additive fixture, explicit declarations, permutation/removal и mixed modes сохраняют claim-bound scopes до реального resolver/consumer.
- Plural components, reversed order, distinct scopes и identification modes проходят ordinary input→compiled refs→resolver→fresh consumer. Для FG-03 новый admitted metric проходит ранний strict NL gate; unknown всё ещё отказывает.

Пакетная граница: Положительная additive fixture, explicit declarations, permutation/removal и mixed modes сохраняют claim-bound scopes до реального resolver/consumer.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/19.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high_mechanism_medium_end_to_end; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: - No actual whole scenario/capability resolver execution
- No final admitted/published claim
- Independent explicit constructs or critics may compensate
- Synthetic concept refs, source-extracted modules and unmatched native profile
- Примечания к распределению: - Activation: Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.
- Otherwise: None
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - Seven graph-derived constructs missing only without compensating explicit declarations; three dropped seed candidates, not every possible obligation. No universal union law for all compositions.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## DC-02 · Grammar усиливает четыре режима идентификации до point identified

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R3.1; механизм: DC-02.
- Основное окно: **LANE-01**. Вторичные checkpoints: нет дополнительных.
- Владелец механизма: Existing grammar/decomposition/data/method compiler owners, coordinated semantic contract; paths: ir/governance/policy_spec.py:106, policy_grammar/_impl/normalizer.py:74-75, policy_grammar/_impl/facets.py:290-295; owner lanes: LANE-01.
- Владелец интеграционной приёмки: LANE-01 / REQ-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: REQ-01 (LANE-01), CYC-01 (LANE-01), ACQ-01 (LANE-01), CYC-05 (LANE-01). Дополнение: ADDON::DC-02 (не официальный E02 ID).
- Основание: Прямое сохранение semantic input/полного compiler denominator до N7 и leaf N4/N5. FG-03 — отдельный NL registry bridge, не тот же механизм, что DC/EC.
- Первый rebind checkpoint: LANE-01. Режим: in_lane_contract_extension.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. New supplemental contract is due at this integration phase in its declared selected scope; current HEAD may already satisfy it, to be evidenced rather than reimplemented.

### Предлагаемое действие
Use existing IdentificationMode semantics without strengthening, retain per-component needs or typed conflict.

Граница patch: Grammar, decomposition/data и method consumers — отдельные writer units, общий end-to-end semantic contract. Универсальный union law не доказан.

### Условия и зависимости
Gate: **due_contract_gate**. Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.

- Сначала согласовать normalization/decomposition/requirement owner contracts, затем ACQ→CYC03. One writer per normalizer/compiler; не допускать raw specs bypass.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R3.1", "to": "R4.2", "kind": "integrated_science_acceptance", "reason": "Component scope must reach occurrence/measurement relation; local work can be parallel."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

Дополнение для выбранного пути:
- native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report
- Положительная additive fixture, explicit declarations, permutation/removal и mixed modes сохраняют claim-bound scopes до реального resolver/consumer.
- Plural components, reversed order, distinct scopes и identification modes проходят ordinary input→compiled refs→resolver→fresh consumer. Для FG-03 новый admitted metric проходит ранний strict NL gate; unknown всё ещё отказывает.

Пакетная граница: Положительная additive fixture, explicit declarations, permutation/removal и mixed modes сохраняют claim-bound scopes до реального resolver/consumer.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/20.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high_source_mechanism_medium_consumer_impact; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: - PolicySpec-shaped collaborator is synthetic, native IR validation unrun
- Final selector can independently preserve explicit constraints
- No estimator execution or publication established
- Примечания к распределению: - Activation: Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.
- Otherwise: None
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - Four enum values map to point at grammar seam; rollout/mixed sequential can override. No actual selected point estimator; native PolicySpec path not qualified.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## EC-01 · Compiler заменяет scope каждого claim последним общим facet

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R3.1; механизм: CLAIM-SCOPE-QUERY-PROJECTION.
- Основное окно: **LANE-01**. Вторичные checkpoints: нет дополнительных.
- Владелец механизма: Existing grammar/decomposition/data/method compiler owners, coordinated semantic contract; paths: data_requirement/compiler.py:415-439,1257-1274,1608-1645,2268-2294; owner lanes: LANE-01.
- Владелец интеграционной приёмки: LANE-01 / REQ-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: REQ-01 (LANE-01), CYC-01 (LANE-01), ACQ-01 (LANE-01), CYC-05 (LANE-01). Дополнение: ADDON::EC-01 (не официальный E02 ID).
- Основание: Прямое сохранение semantic input/полного compiler denominator до N7 и leaf N4/N5. FG-03 — отдельный NL registry bridge, не тот же механизм, что DC/EC.
- Первый rebind checkpoint: LANE-01. Режим: in_lane_contract_extension.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. New supplemental contract is due at this integration phase in its declared selected scope; current HEAD may already satisfy it, to be evidenced rather than reimplemented.

### Предлагаемое действие
Preserve claim/component and semantic scope in query/spec identity or refuse unsupported composition; resolve claim scope from linked facets rather than global last-row wins.

Граница patch: Grammar, decomposition/data и method consumers — отдельные writer units, общий end-to-end semantic contract. Универсальный union law не доказан.

### Условия и зависимости
Gate: **due_contract_gate**. Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.

- Сначала согласовать normalization/decomposition/requirement owner contracts, затем ACQ→CYC03. One writer per normalizer/compiler; не допускать raw specs bypass.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R3.1", "to": "R4.2", "kind": "integrated_science_acceptance", "reason": "Component scope must reach occurrence/measurement relation; local work can be parallel."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

Дополнение для выбранного пути:
- native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report
- Положительная additive fixture, explicit declarations, permutation/removal и mixed modes сохраняют claim-bound scopes до реального resolver/consumer.
- Plural components, reversed order, distinct scopes и identification modes проходят ordinary input→compiled refs→resolver→fresh consumer. Для FG-03 новый admitted metric проходит ранний strict NL gate; unknown всё ещё отказывает.

Пакетная граница: Положительная additive fixture, explicit declarations, permutation/removal и mixed modes сохраняют claim-bound scopes до реального resolver/consumer.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/21.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high_mechanism_medium_operational_impact; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: Native typed PolicySpec, production resolver, persisted/scientific/protected output unrun.
- Примечания к распределению: - Activation: Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.
- Otherwise: None
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - Independent hybrid interleaving gives population B/geography A/time B. Queries precomputed globally and specs reuse last-by-type facets are both repair points. Normal production producer of multi-scope generic ledger not shown.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## EC-02 · Явный method facet не доходит до causal preconditions

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R3.1; механизм: EC-02.
- Основное окно: **LANE-01**. Вторичные checkpoints: нет дополнительных.
- Владелец механизма: Existing grammar/decomposition/data/method compiler owners, coordinated semantic contract; paths: scientist/policy_design/claim_decomposition.py:195-263,448-482,539-561; method_requirement/_impl/compiler.py:255-316; owner lanes: LANE-01.
- Владелец интеграционной приёмки: LANE-01 / REQ-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: REQ-01 (LANE-01), CYC-01 (LANE-01), ACQ-01 (LANE-01), CYC-05 (LANE-01). Дополнение: ADDON::EC-02 (не официальный E02 ID).
- Основание: Прямое сохранение semantic input/полного compiler denominator до N7 и leaf N4/N5. FG-03 — отдельный NL registry bridge, не тот же механизм, что DC/EC.
- Первый rebind checkpoint: LANE-01. Режим: in_lane_contract_extension.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. New supplemental contract is due at this integration phase in its declared selected scope; current HEAD may already satisfy it, to be evidenced rather than reimplemented.

### Предлагаемое действие
Carry explicit scoped identification restrictions into claim preconditions with provenance, or refuse incompatibility; do not rely on facet mention alone.

Граница patch: Grammar, decomposition/data и method consumers — отдельные writer units, общий end-to-end semantic contract. Универсальный union law не доказан.

### Условия и зависимости
Gate: **due_contract_gate**. Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.

- Сначала согласовать normalization/decomposition/requirement owner contracts, затем ACQ→CYC03. One writer per normalizer/compiler; не допускать raw specs bypass.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R3.1", "to": "R4.2", "kind": "integrated_science_acceptance", "reason": "Component scope must reach occurrence/measurement relation; local work can be parallel."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

Дополнение для выбранного пути:
- native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report
- Положительная additive fixture, explicit declarations, permutation/removal и mixed modes сохраняют claim-bound scopes до реального resolver/consumer.
- Plural components, reversed order, distinct scopes и identification modes проходят ordinary input→compiled refs→resolver→fresh consumer. Для FG-03 новый admitted metric проходит ранний strict NL gate; unknown всё ещё отказывает.

Пакетная граница: Положительная additive fixture, explicit declarations, permutation/removal и mixed modes сохраняют claim-bound scopes до реального resolver/consumer.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/22.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high_local_no_estimator_impact_demonstrated; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: No actual point estimator execution, unsupported policy deployment or publication demonstrated.
- Примечания к распределению: - Activation: Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.
- Otherwise: None
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - context_only is not a blanket method requirement ban: typed precondition on context_only yields bounds. Loss is missing semantic binding. Bounds/partial are strongest discriminators; not every proxy/interference dimension must be non-point.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## FG-03 · Ранний NL normalizer не получает расширенный registry

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R3.2; механизм: FG-03.
- Основное окно: **LANE-01**. Вторичные checkpoints: нет дополнительных.
- Владелец механизма: Existing serious-NL normalizer/registry wiring; paths: ; owner lanes: LANE-01.
- Владелец интеграционной приёмки: LANE-01 / REQ-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: REQ-01 (LANE-01), CYC-01 (LANE-01), ACQ-01 (LANE-01), CYC-05 (LANE-01). Дополнение: ADDON::FG-03 (не официальный E02 ID).
- Основание: Прямое сохранение semantic input/полного compiler denominator до N7 и leaf N4/N5. FG-03 — отдельный NL registry bridge, не тот же механизм, что DC/EC.
- Первый rebind checkpoint: LANE-01. Режим: in_lane_contract_extension.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. New supplemental contract is due at this integration phase in its declared selected scope; current HEAD may already satisfy it, to be evidenced rather than reimplemented.

### Предлагаемое действие
Передавать тот же расширенный admitted registry в ранний strict NL normalizer и downstream resolver/compiler; новая допустимая metric проходит обычный early gate, неизвестная по-прежнему явно отклоняется. Не создавать параллельный registry.

Граница patch: Нужна проводка существующей registry; unknown/meaning guards не ослаблять.

### Условия и зависимости
Gate: **due_contract_gate**. Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.

- Сначала согласовать normalization/decomposition/requirement owner contracts, затем ACQ→CYC03. One writer per normalizer/compiler; не допускать raw specs bypass.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

Дополнение для выбранного пути:
- native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report
- Новые typed IDs проходят раннюю нормализацию на actual path; неизвестные значения не получают смысл автоматически.
- Plural components, reversed order, distinct scopes и identification modes проходят ordinary input→compiled refs→resolver→fresh consumer. Для FG-03 новый admitted metric проходит ранний strict NL gate; unknown всё ещё отказывает.

Пакетная граница: Новые typed IDs проходят раннюю нормализацию на actual path; неизвестные значения не получают смысл автоматически.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/23.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high_source_bridge_medium_product_reach; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: Actual strict canonicalizer helper, two new typed synthetic metric IDs; not full valid corpus-to-HTTP e2e. Do not weaken unknown/meaning guards.
- Примечания к распределению: - Activation: Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.
- Otherwise: None
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## RD-01 · Recomputed axes не сверяют декларации с доступными фактами occurrence

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R4.2; механизм: RD-01.
- Основное окно: **LANE-01**. Вторичные checkpoints: {"stage": "LANE-07", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: Existing measurement/registry dataflow owner; paths: core/contracts/variable_binding.py:987-1049, core/contracts/variable_binding.py:1151-1193; owner lanes: LANE-07, LANE-01.
- Владелец интеграционной приёмки: LANE-01 / ACQ-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: ACQ-01 (LANE-01), SIM-02 (LANE-01), FRC-02 (LANE-03), EMP-01 (LANE-03). Дополнение: ADDON::RD-01 (не официальный E02 ID).
- Основание: Multirow/new-source acquisition уже требует declared units/time/population/aggregation; recomputed axes нельзя присвоить из декларации без source facts.
- Первый rebind checkpoint: LANE-01. Режим: semantic_relation_before_consumer.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. New supplemental contract is due at this integration phase in its declared selected scope; current HEAD may already satisfy it, to be evidenced rather than reimplemented.

### Предлагаемое действие
At the existing semantic owner, bind each mechanically claimed recomputed axis to selected occurrence/source/port facts or an explicit typed transformation/composition rule. Do not treat two equal declarations as independent reconciliation.

Граница patch: Закон composition задаёт существующий measurement owner; нельзя механически заменить sum на mean.

### Условия и зависимости
Gate: **due_contract_gate**. Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.

- R3.1 component scope прежде RD relation; RD law прежде related R12 normative consumption. Не менять sum на mean универсально.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R3.1", "to": "R4.2", "kind": "integrated_science_acceptance", "reason": "Component scope must reach occurrence/measurement relation; local work can be parallel."}
- {"from": "R4.2", "to": "R12.1", "kind": "integrated_governance_acceptance", "reason": "Numerical/normative input semantics before whole current governance claim."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: 2 and 6 sum/mean discriminator, source/port population cross-join, correct identity and supported composition controls, exact persisted refs and fresh consumer replay; preserve candidate and authority separation.

Дополнение для выбранного пути:
- 2 and 6 sum/mean discriminator, source/port population cross-join, correct identity and supported composition controls, exact persisted refs and fresh consumer replay; preserve candidate and authority separation.
- Реальные source facts, transformations, population/unit/time и verifier provenance связываются либо остаются not_established.
- Mean/sum и population fixture diverge under independent oracle; actual source rows/port scope согласованы с transformation, persisted relation и fresh reader. Wrong relation refuses only affected claim.

Пакетная граница: Реальные source facts, transformations, population/unit/time и verifier provenance связываются либо остаются not_established.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/28.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high for behavior; operational reach partial; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: - No native persisted admission or complete physical/publication bypass.
- Raw aggregation versus representation aggregation may need a compositional meaning law, not unconditional literal equality.
- External empirical truth remains explicitly unestablished.
- Примечания к распределению: - Activation: Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.
- Otherwise: None
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - Retain missing occurrence→representation cross-join. sum=8 with mean declarations does not prove intended value=4 without a composition law. Source/port scope guards do exist. recomputed_axes includes compared axes even on refusal; actual consumers inspect full status.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## NS-01 · Конкурентный refresh публикует несогласованные cache и fingerprints

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R6.5; механизм: NS-01.
- Основное окно: **LANE-01**. Вторичные checkpoints: нет дополнительных.
- Владелец механизма: RunIndexService; paths: runtime/http/services/run_index.py:95-118, runtime/http/services/run_index.py:302-338, runtime/http/dependencies.py:136-140,207-214, runtime/http/routes/runs.py:6557-6636; owner lanes: LANE-01.
- Владелец интеграционной приёмки: LANE-01 / CYC-03: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: CYC-03 (LANE-01), CYC-02 (LANE-01). Дополнение: ADDON::NS-01 (не официальный E02 ID).
- Основание: CYC-03 требует действительный HTTP/export/UI current occurrence и complete history; run_index publication race/cap меняют доступный consumer denominator. Это не тот же owner, что SearchService CTL.
- Первый rebind checkpoint: LANE-01. Режим: in_lane_actual_history_surface_extension.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. New supplemental contract is due at this integration phase in its declared selected scope; current HEAD may already satisfy it, to be evidenced rather than reimplemented.

### Предлагаемое действие
Serialize instance refresh or publish coherent immutable generation with stale-leader protection.

Граница patch: Race и completeness — независимые subchanges одного read-model owner; display limit отдельно от decision population.

### Условия и зависимости
Gate: **due_contract_gate**. Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.

- Separate race/cap fixes с одним Runtime run read-model owner. NS-02 performance не prerequisite; CYC05 controls truth of stop отдельно.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R6.5", "to": "R7.2", "kind": "consistency_contract", "reason": "Request-local reuse must consume coherent complete run generation."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Native shared-service/HTTP interleaving with append, deletion, force/TTL, failed/cancelled leader and owner-map coherence.

Дополнение для выбранного пути:
- Native shared-service/HTTP interleaving with append, deletion, force/TTL, failed/cancelled leader and owner-map coherence.
- Concurrent refresh согласован; последняя retained run доступна независимо от presentation page/cap.
- Concurrent refresh publishes coherent rows/fingerprints; complete run population не display page/cap; retained last occurrence остаётся discoverable. Fresh consumer sees same selected history.

Пакетная граница: Concurrent refresh согласован; последняя retained run доступна независимо от presentation page/cap.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/38.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high mechanism, unmeasured deployed likelihood; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: - Method-return barrier expands scheduling window; not measured race probability.
- No cross-tenant leak or permanent unrecoverability demonstrated.
- Примечания к распределению: - Activation: Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.
- Otherwise: None
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - Race schedule not frequency; serial/fresh instance/subsequent mutation recover. No permanent staleness or cross-tenant exploit.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## PG-01 · Legacy binding сохраняет overlap и частичный scope по документации

- Тип: Решение по контракту. Работа: contract_decision_before_any_code.
- Remediation unit: R3.3; механизм: PG-01.
- Основное окно: **LANE-01**. Вторичные checkpoints: нет дополнительных.
- Владелец механизма: Existing capability binding/authority owners; paths: runtime/quality/capability_resolver.py:802-853,978-1085, runtime/quality/capability_authority.py:761-915,1050-1063, data_requirement/_impl/models.py:232-302; owner lanes: LANE-01.
- Владелец интеграционной приёмки: LANE-01 / REQ-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: REQ-01 (LANE-01), ACQ-01 (LANE-01). Дополнение: ADDON::PG-01 (не официальный E02 ID).
- Основание: Legacy overlap/partial scope документирован; новый строгий scope нельзя ввести молча и объявить старый artifact неверным.
- Первый rebind checkpoint: LANE-01. Режим: bounded_legacy_contract_decision.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. New supplemental contract is due at this integration phase in its declared selected scope; current HEAD may already satisfy it, to be evidenced rather than reimplemented.

### Предлагаемое действие
Canonical scope compatibility with matched/mismatch/unknown/unsupported; authority refuses or limits incomplete/unknown support while candidate discovery may carry explicit unknowns. Keep content and source-admission boundaries.

Граница patch: Контрактное решение, не установленная новая регрессия.

### Условия и зависимости
Gate: **due_contract_gate**. Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.

- Owner выбирает versioned legacy-readable versus new strict discovery policy до нового admission. Это не автоматический defect fix.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

Дополнение для выбранного пути:
- native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report
- Версионно определено, что legacy selected_exact доказывает; миграция не повышает authority молча.
- Legacy controls остаются в historical роли; current strict claim требует соответствующего scope; отсутствие full entailment не усиливается до authority и не ломает независимый candidate.

Пакетная граница: Версионно определено, что legacy selected_exact доказывает; миграция не повышает authority молча.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/64.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high_local_mechanism; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: - Synthetic owner assertions
- Source-body execution, not package import
- Native N7 CAS bridge traced not run
- No scientific/source/production admission
- No publication bypass established
- selected_exact is a legacy evidence-mode status, not a proof of full temporal entailment
- Примечания к распределению: - Activation: Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.
- Otherwise: None
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - README explicitly preserves legacy claim-evidence interpretation. selected_exact is not full temporal entailment. Candidate world-slot join refuses partial interval, removed fetch and profile mutation. No new regression; signed-owner/DS9 admission separate.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## MA-01 · Registry cache теряет semantic metadata и использует lossy codec

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R11.1; механизм: MA-01.
- Основное окно: **LANE-01**. Вторичные checkpoints: {"stage": "LANE-04", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: foundry.methods.selection.cache + selection.registry; paths: policy-engine/src/polisyos/foundry/methods/selection/cache.py:155-305,374-518, policy-engine/src/polisyos/foundry/methods/base.py:487-510,724-765,942-975, policy-engine/src/polisyos/foundry/methods/catalog/snapshot.py:117-178; owner lanes: LANE-01, LANE-04.
- Владелец интеграционной приёмки: LANE-01 / SEL-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: SEL-01 (LANE-01), SIM-01 (LANE-01), CYC-01 (LANE-01). Дополнение: ADDON::MA-01 (не официальный E02 ID).
- Основание: Actual selected method и persisted semantics должны совпадать с loaded executable. Кеш/registry относятся к существующим Foundry owners; composer companion может потребовать окно прежнего L04.
- Первый rebind checkpoint: LANE-01. Режим: in_lane_selection_plus_conditional_corrective.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. New supplemental contract is due at this integration phase in its declared selected scope; current HEAD may already satisfy it, to be evidenced rather than reimplemented.

### Предлагаемое действие
Versioned semantic snapshot отдельно от stable ABI; metadata/source/profile binding, legitimate overlays сохранить.

Граница patch: Три узких patches у MethodRegistry/cache/dispatcher. Не лечит независимую eager mechanism projection.

### Условия и зависимости
Gate: **due_contract_gate**. Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.

- MA cache/codec, lazy binding и dotted qualname — отдельные changes. Не принимать numerical output/reuse при несовпадении declared/loaded identity.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R11.1", "to": "R9.3", "kind": "path_identity_migration", "reason": "Class module/qualname contributes identity; finite aliases do not excuse stale registry identity."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Fresh SQLite read после metadata/signature drift, complete bounds/contracts roundtrip, actual cache caller и strict execution controls.

Дополнение для выбранного пути:
- Fresh SQLite read после metadata/signature drift, complete bounds/contracts roundtrip, actual cache caller и strict execution controls.
- Metadata-only drift, wrong loaded identity, nested qualname и свежий persisted reader различаются; strict component guards сохранены.
- Metadata-only drift инвалидирует cache; semantic fields roundtrip; A-declared/B-loaded отказ до effects; nested qualname после fresh restore действительно runnable. Preserve strict selector и full intake.

Пакетная граница: Metadata-only drift, wrong loaded identity, nested qualname и свежий persisted reader различаются; strict component guards сохранены.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/84.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high_bounded_execution; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: Candidate consistency, не обход executable decorators/strict contracts; application cache consumer не найден literal census.
- Примечания к распределению: - Activation: Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.
- Otherwise: None
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - Candidate consistency, не обход executable decorators/strict contracts; application cache consumer не найден literal census.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## MA-02 · Lazy dispatch не сверяет заявленный и загруженный executable

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R11.1; механизм: MA-02.
- Основное окно: **LANE-01**. Вторичные checkpoints: {"stage": "LANE-04", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: foundry.methods.selection.registry + candidate snapshot + backends.dispatch; paths: policy-engine/src/polisyos/foundry/methods/selection/registry.py:788-809, policy-engine/src/polisyos/foundry/methods/catalog/snapshot.py:117-178, policy-engine/src/polisyos/foundry/methods/backends/dispatch.py:550-630,790-818, policy-engine/src/polisyos/foundry/methods/components/composer.py:532-565; owner lanes: LANE-01, LANE-04.
- Владелец интеграционной приёмки: LANE-01 / SEL-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: SEL-01 (LANE-01), SIM-01 (LANE-01), CYC-01 (LANE-01). Дополнение: ADDON::MA-02 (не официальный E02 ID).
- Основание: Actual selected method и persisted semantics должны совпадать с loaded executable. Кеш/registry относятся к существующим Foundry owners; composer companion может потребовать окно прежнего L04.
- Первый rebind checkpoint: LANE-01. Режим: in_lane_selection_plus_conditional_corrective.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. New supplemental contract is due at this integration phase in its declared selected scope; current HEAD may already satisfy it, to be evidenced rather than reimplemented.

### Предлагаемое действие
Canonical load reconciliation и явный admitted executable contract; intentional aliases декларировать.

Граница patch: Три узких patches у MethodRegistry/cache/dispatcher. Не лечит независимую eager mechanism projection.

### Условия и зависимости
Gate: **due_contract_gate**. Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.

- MA cache/codec, lazy binding и dotted qualname — отдельные changes. Не принимать numerical output/reuse при несовпадении declared/loaded identity.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R11.1", "to": "R9.3", "kind": "path_identity_migration", "reason": "Class module/qualname contributes identity; finite aliases do not excuse stale registry identity."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Wrong FQN/class/signature, legitimate aliases, strict positive and negative paths и persisted history attribution.

Дополнение для выбранного пути:
- Wrong FQN/class/signature, legitimate aliases, strict positive and negative paths и persisted history attribution.
- Metadata-only drift, wrong loaded identity, nested qualname и свежий persisted reader различаются; strict component guards сохранены.
- Metadata-only drift инвалидирует cache; semantic fields roundtrip; A-declared/B-loaded отказ до effects; nested qualname после fresh restore действительно runnable. Preserve strict selector и full intake.

Пакетная граница: Metadata-only drift, wrong loaded identity, nested qualname и свежий persisted reader различаются; strict component guards сохранены.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/85.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high_bounded_execution; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: Условие: inconsistent supplier/stale mapping; component bridge, typed selector и compiled chain имеют более строгие guards. Не все admission gates обходятся.
- Примечания к распределению: - Activation: Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.
- Otherwise: None
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - Условие: inconsistent supplier/stale mapping; component bridge, typed selector и compiled chain имеют более строгие guards. Не все admission gates обходятся.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## MA-03 · Cache не восстанавливает вложенный dotted qualname

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R11.1; механизм: MA-03.
- Основное окно: **LANE-01**. Вторичные checkpoints: {"stage": "LANE-04", "purpose": "Sequential affected owner corrective window when actual path/source changes require it; revalidate only dependent proof."}.
- Владелец механизма: foundry.methods.selection.cache; paths: policy-engine/src/polisyos/foundry/methods/selection/registry.py:286-300,538-548, policy-engine/src/polisyos/foundry/methods/selection/cache.py:243-257; owner lanes: LANE-01, LANE-04.
- Владелец интеграционной приёмки: LANE-01 / SEL-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: SEL-01 (LANE-01), SIM-01 (LANE-01), CYC-01 (LANE-01). Дополнение: ADDON::MA-03 (не официальный E02 ID).
- Основание: Actual selected method и persisted semantics должны совпадать с loaded executable. Кеш/registry относятся к существующим Foundry owners; composer companion может потребовать окно прежнего L04.
- Первый rebind checkpoint: LANE-01. Режим: in_lane_selection_plus_conditional_corrective.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. New supplemental contract is due at this integration phase in its declared selected scope; current HEAD may already satisfy it, to be evidenced rather than reimplemented.

### Предлагаемое действие
Общий малый qualified-target resolver либо upfront unsupported-target refusal.

Граница patch: Три узких patches у MethodRegistry/cache/dispatcher. Не лечит независимую eager mechanism projection.

### Условия и зависимости
Gate: **due_contract_gate**. Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.

- MA cache/codec, lazy binding и dotted qualname — отдельные changes. Не принимать numerical output/reuse при несовпадении declared/loaded identity.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R11.1", "to": "R9.3", "kind": "path_identity_migration", "reason": "Class module/qualname contributes identity; finite aliases do not excuse stale registry identity."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Flat/nested module classes, rejected locals и fresh-process load/execute; различить restored и admitted.

Дополнение для выбранного пути:
- Flat/nested module classes, rejected locals и fresh-process load/execute; различить restored и admitted.
- Metadata-only drift, wrong loaded identity, nested qualname и свежий persisted reader различаются; strict component guards сохранены.
- Metadata-only drift инвалидирует cache; semantic fields roundtrip; A-declared/B-loaded отказ до effects; nested qualname после fresh restore действительно runnable. Preserve strict selector и full intake.

Пакетная граница: Metadata-only drift, wrong loaded identity, nested qualname и свежий persisted reader различаются; strict component guards сохранены.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/86.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high_bounded_execution; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: Локальный persistence defect, не arbitrary import exploit; native/default bootstrap не квалифицирован.
- Примечания к распределению: - Activation: Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.
- Otherwise: None
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - Локальный persistence defect, не arbitrary import exploit; native/default bootstrap не квалифицирован.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.


## Исходный порядок внутри lane

Не менять без actual write-set/contract reconciliation. Это порядок E02, не доказательство текущей готовности.

- 01-A: REQ-01 → CYC-01 → ACQ-01 → CYC-03 → CYC-04 → CYC-05 → CYC-02. Compiler denominator→served context→acquisition→new basis/reuse→fallback→decomposition/readiness bridge→fresh conditional projection
- 01-B: SIM-01 → SIM-02 → SIM-03. Request preflight→resolved writes/cause→statistics/joint comparator
- 01-C: SEL-01. Advisor/intake/opaque identity/receipt

Cross-track gates (исходные, context-only):
[
  {
    "before": [
      "REQ-01"
    ],
    "after": [
      "ACQ-01"
    ],
    "reason": "Compiler-owned normalizer before LA046 closure"
  },
  {
    "before": [
      "ACQ-01"
    ],
    "after": [
      "CYC-03"
    ],
    "reason": "Actual new source/admission before changed-basis continuation"
  },
  {
    "before": [
      "SIM-03"
    ],
    "after": [
      "CYC-02"
    ],
    "reason": "Actual numerical result/identity before fresh conditional readback"
  },
  {
    "before": [
      "CYC-05",
      "SIM-03"
    ],
    "after": [
      "CYC-02"
    ],
    "reason": "Authored compound relation and actual contrast jointly qualified; no duplicated composition owner"
  }
]
