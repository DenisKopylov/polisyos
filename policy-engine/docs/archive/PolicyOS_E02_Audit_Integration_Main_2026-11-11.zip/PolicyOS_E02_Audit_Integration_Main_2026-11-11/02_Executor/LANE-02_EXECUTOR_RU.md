# Будущий lane 02

Статус: предварительный план, не свидетельство реализации. Основных карточек: 3. Сначала получить фактический отчёт исполнителя и сверить HEAD. Один implementation lane активен; corrective window приостанавливает затронутую работу, а не запускает параллельный lane.

## Порядок работы
1. Проверить текущую ветку/HEAD, незавершённые patches, write leases и источник evidence.
2. Для каждого пункта выбрать: уже закрыт; подтвердился; изменился контракт; не воспроизведён; UNRUN; требует решения. Сохранить причину и ссылку.
3. Выполнить только согласованный bounded patch или квалификацию у существующего owner.
4. Приложить точный oracle, контроли и affected-evidence map. Не ставить PASS по наличию файла/skip/fixture.
5. Обновить статус DA только в указанной части, не переносить весь TEST/REQ.

## Состав
- NS-04: История наблюдений вызывает повторное обучение на растущем префиксе
- NS-05: Durable JSONL не восстанавливает process global историю автоматически
- DP-01: Нулевые веса и слагаемые меняют нормативный выбор

## NS-04 · История наблюдений вызывает повторное обучение на растущем префиксе

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R7.3; механизм: NS-04.
- Основное окно: **LANE-02**. Вторичные checkpoints: нет дополнительных.
- Владелец механизма: PredictiveVOIScheduler and SelectionHistoryStore/RuntimePredictor; paths: scientist/methods/search/voi_scheduler.py:1127-1128,1175-1206,1430-1452, foundry/methods/selection/history.py:313-389; owner lanes: LANE-02.
- Владелец интеграционной приёмки: LANE-02 / OPT-03: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: OPT-03 (LANE-02), TRN-01 (LANE-02), TRN-03 (LANE-02), CTL-02 (LANE-02), SRV-03 (LANE-02). Дополнение: ADDON::NS-04 (не официальный E02 ID).
- Основание: LANE-02 служит удобным first-rebind checkpoint с history owner. Подтверждены H fits и H(H+1)/2 record visits; оптимизация не обязательна для всего lane и не является исправлением доказанной научной некорректности.
- Первый rebind checkpoint: LANE-02. Режим: history_contract_and_bounded_performance.
- Если условие не активно: AFTER-12: optional bounded optimization при отсутствии выбранного resource/changed-contract условия. NS-05 остаётся отдельным restart contract decision.
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. primary_stage is first integration/rebind checkpoint; implementation is due there only under activation_condition. If not active, preserve finding open and route according to otherwise_route; absence of reachability proof is not PASS.

### Предлагаемое действие
Revision-aware fitted predictor reuse and final fit after bulk replay where intermediate consumers do not require fits.

Граница patch: NS-05 не объявлять data loss; сначала restoration policy, затем algorithmic reuse.

### Условия и зависимости
Gate: **CONDITIONAL_RESOURCE_OR_CHANGED_HISTORY_CONTRACT**. Только доказанное нарушение выбранного workload/resource envelope или необходимость для конкретного изменяемого history contract. Сам факт вызова history.py не является blocker E02; научная некорректность и p95 regression не установлены.

- Корректность и выбранный contract learning history должны сохраняться при оптимизации. NS-05 требует отдельного owner decision только если continuity обещана; это не обязательный парный restart fix.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Full supported scheduler, prediction/selection equivalence, new-event invalidation, empty/failed/per-method/backend controls.

Дополнение для выбранного пути:
- Full supported scheduler, prediction/selection equivalence, new-event invalidation, empty/failed/per-method/backend controls.
- Исторические decisions/replay совпадают в выбранном контракте; состояние алгоритма и версия явны.
- Cold/restarted/warm accepted rows and actual fitted decisions согласованы declared scope; history cap/quota не меняет corpus; state/RNG preserved. Public local history-only contract may be valid limitation, not data-loss diagnosis.

Пакетная граница: Исторические decisions/replay совпадают в выбранном контракте; состояние алгоритма и версия явны.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/43.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high operation count; no product capacity claim; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: - Synthetic observations; full scheduler/from_snapshot unrun.
- No scientific correctness or p95 assertion.
- Примечания к распределению: - Не превращать сам actual consumer history.py в обязательный gate.
- Только доказанное нарушение выбранного workload/resource envelope или необходимость для конкретного изменяемого history contract. Сам факт вызова history.py не является blocker E02; научная некорректность и p95 regression не установлены.
- AFTER-12: optional bounded optimization при отсутствии выбранного resource/changed-contract условия. NS-05 остаётся отдельным restart contract decision.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## NS-05 · Durable JSONL не восстанавливает process global историю автоматически

- Тип: Решение по контракту. Работа: contract_decision_before_any_code.
- Remediation unit: R7.3; механизм: NS-05.
- Основное окно: **LANE-02**. Вторичные checkpoints: нет дополнительных.
- Владелец механизма: SelectionHistoryStore global-state initialization; paths: foundry/methods/selection/history.py:199-229,501-519, foundry/methods/selection/README.md:44-58, foundry/methods/selection/advisor.py:3878-3890, foundry/methods/backends/dispatch.py:1112-1122; owner lanes: LANE-02.
- Владелец интеграционной приёмки: LANE-02 / OPT-03: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: OPT-03 (LANE-02), TRN-01 (LANE-02), TRN-03 (LANE-02), CTL-02 (LANE-02), SRV-03 (LANE-02). Дополнение: ADDON::NS-05 (не официальный E02 ID).
- Основание: History.jsonl/process-global learning lifecycle пересекается с selected history/restart claims, но выборочный Foundry selection-history owner не автоматически тот же GP strategy owner.
- Первый rebind checkpoint: LANE-02. Режим: history_contract_and_bounded_performance.
- Если условие не активно: after_12_performance_or_explicit_process_local_nonclaim
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. primary_stage is first integration/rebind checkpoint; implementation is due there only under activation_condition. If not active, preserve finding open and route according to otherwise_route; absence of reachability proof is not PASS.

### Предлагаемое действие
Decide/document startup replay and retention policy; use existing import once if continuity is required.

Граница patch: NS-05 не объявлять data loss; сначала restoration policy, затем algorithmic reuse.

### Условия и зависимости
Gate: **conditional_profile_gate**. Actual selected search/selection path consumes affected voi_scheduler/selection/history.py. If different history owner, preserve separate scope and do not fabricate dependency.

- NS-05 explicit restart semantics before claiming restored history; NS-04 optimize only same decisions/state/source scope with measured actual workload. Do not silently retrain historical identity.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Supported process restart with real consumers, torn log/corruption and concurrent writer cases.

Дополнение для выбранного пути:
- Supported process restart with real consumers, torn log/corruption and concurrent writer cases.
- Исторические decisions/replay совпадают в выбранном контракте; состояние алгоритма и версия явны.
- Cold/restarted/warm accepted rows and actual fitted decisions согласованы declared scope; history cap/quota не меняет corpus; state/RNG preserved. Public local history-only contract may be valid limitation, not data-loss diagnosis.

Пакетная граница: Исторические decisions/replay совпадают в выбранном контракте; состояние алгоритма и версия явны.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/67.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high behavior; defect status unresolved; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: - Not called data loss or proven contract violation.
- Full module imported under isolated name, not installed package.
- Примечания к распределению: - Activation: Actual selected search/selection path consumes affected voi_scheduler/selection/history.py. If different history owner, preserve separate scope and do not fabricate dependency.
- Otherwise: after_12_performance_or_explicit_process_local_nonclaim
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## DP-01 · Нулевые веса и слагаемые меняют нормативный выбор

- Тип: Решение по контракту. Работа: contract_decision_before_any_code.
- Remediation unit: R12.1; механизм: DP-01.
- Основное окно: **LANE-02**. Вторичные checkpoints: нет дополнительных.
- Владелец механизма: existing source owner named by primary report; paths: policy-engine/src/polisyos/scientist/nodes/builtins/governance/normative_arbitration_calculations.py:283-350,500-578; owner lanes: LANE-02.
- Владелец интеграционной приёмки: LANE-02 / FUN-03: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: FUN-03 (LANE-02), OPT-04 (LANE-02). Дополнение: ADDON::DP-01 (не официальный E02 ID).
- Основание: Normative weight law belongs to existing governance calculation owner, not generic search comparator. Integration at FUN03 only if selected promotion actually consumes this result.
- Первый rebind checkpoint: LANE-02. Режим: conditional_normative_owner_before_protected_promotion.
- Если условие не активно: after_12_normative_repair_or_before_first_actual_normative_claim
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. primary_stage is first integration/rebind checkpoint; implementation is due there only under activation_condition. If not active, preserve finding open and route according to otherwise_route; absence of reachability proof is not PASS.

### Предлагаемое действие
Явно определить multi-term weight composition и уважать explicit zero отдельно от missing.

Граница patch: Небольшой zero-default repair отдельно от owner decision о нормативной агрегации.

### Условия и зависимости
Gate: **conditional_profile_gate**. Selected protected L6/decision path consumes affected normative_arbitration_calculations output. No such use means no blanket block of candidate search.

- Owner must decide multi-term normalization separately from arithmetic zero-default fix; source/representation law first. Do not make corrected weights an authorization issuer.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R4.2", "to": "R12.1", "kind": "integrated_governance_acceptance", "reason": "Numerical/normative input semantics before whole current governance claim."}
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Zero/missing/small-positive, decomposition/invariance cases после решения контракта; actual normative→governance chain.

Дополнение для выбранного пути:
- Zero/missing/small-positive, decomposition/invariance cases после решения контракта; actual normative→governance chain.
- Zero/addition controls проверяются по выбранному закону; helper approve не становится final governance authority.
- Explicit zero preserved; zero-coefficient additions tested under declared normative law; persisted actual consumer and protected permit/revoke gate. Compare accepted objective basis and do not rewrite historical choices.

Пакетная граница: Zero/addition controls проверяются по выбранному закону; helper approve не становится final governance authority.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/99.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high for bounded executed path; уверенность распределения: high_mechanism_conditional_consumer.
- Ограничения: P2 — repair/contract clarification, не security severity. Multi-term semantics схемой не определены; изменение суммы weights не доказывает нормативное намерение. Helper approve не final authority.
- Примечания к распределению: - Activation: Selected protected L6/decision path consumes affected normative_arbitration_calculations output. No such use means no blanket block of candidate search.
- Otherwise: after_12_normative_repair_or_before_first_actual_normative_claim
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - P2 — repair/contract clarification, не security severity. Multi-term semantics схемой не определены; изменение суммы weights не доказывает нормативное намерение. Helper approve не final authority.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.


## Исходный порядок внутри lane

Не менять без actual write-set/contract reconciliation. Это порядок E02, не доказательство текущей готовности.

- 02-A: OPT-01 → OPT-02 → CTL-02 → OPT-03 → OPT-04. Coordinate source→effective action→portable restore→conditioned GP→champion
- 02-B: CTL-01 → SRV-01 → CTL-03 → STP-01 → SRV-03. Run generation→atomic tell→cost/counts→stop→actual runner closure
- 02-C: TRN-03 → TRN-01 → TRN-02. Aware-time/context→numerical history admission→exact-ref discovery
- 02-D: FUN-01 → FUN-02 → FUN-03. Fresh attempt/re-gating→fidelity/aggregate→current knowledge and protected promotion

Cross-track gates (исходные, context-only):
[
  {
    "before": [
      "OPT-01"
    ],
    "after": [
      "CTL-01",
      "CTL-03",
      "STP-01"
    ],
    "reason": "Objective/source coordinate basis before scientific-best/counter/meaningful plateau acceptance"
  },
  {
    "before": [
      "SRV-01"
    ],
    "after": [
      "OPT-02"
    ],
    "reason": "One atomic tell owner; effective action must not invent second pending registry"
  },
  {
    "before": [
      "OPT-02"
    ],
    "after": [
      "TRN-01"
    ],
    "reason": "Canonical parameters and executed identity before target history admission"
  },
  {
    "before": [
      "TRN-01",
      "TRN-02",
      "CTL-02"
    ],
    "after": [
      "OPT-03"
    ],
    "reason": "Compatible source history and atomic base restore before fitted GP qualification"
  },
  {
    "before": [
      "CTL-02",
      "OPT-02",
      "STP-01"
    ],
    "after": [
      "SRV-03"
    ],
    "reason": "Actual resume/runner uses completed shared contracts"
  },
  {
    "before": [
      "SRV-03"
    ],
    "after": [
      "OPT-04"
    ],
    "reason": "Shared runtime.py merge lease, then champion native evidence"
  },
  {
    "before": [
      "CTL-03"
    ],
    "after": [
      "FUN-01"
    ],
    "reason": "Resource admission contract before bounded continuation"
  },
  {
    "before": [
      "TRN-03"
    ],
    "after": [
      "FUN-03"
    ],
    "reason": "Shared effective lesson/time projection"
  }
]
