# Будущий lane 03

Статус: предварительный план, не свидетельство реализации. Основных карточек: 2. Сначала получить фактический отчёт исполнителя и сверить HEAD. Один implementation lane активен; corrective window приостанавливает затронутую работу, а не запускает параллельный lane.

## Порядок работы
1. Проверить текущую ветку/HEAD, незавершённые patches, write leases и источник evidence.
2. Для каждого пункта выбрать: уже закрыт; подтвердился; изменился контракт; не воспроизведён; UNRUN; требует решения. Сохранить причину и ссылку.
3. Выполнить только согласованный bounded patch или квалификацию у существующего owner.
4. Приложить точный oracle, контроли и affected-evidence map. Не ставить PASS по наличию файла/skip/fixture.
5. Обновить статус DA только в указанной части, не переносить весь TEST/REQ.

## Состав
- SI-01: ENCE пропускает bins с нулевым или малым spread
- SI-02: Unconditional p value подаётся как conditional coverage

## SI-01 · ENCE пропускает bins с нулевым или малым spread

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R12.2; механизм: SI-01.
- Основное окно: **LANE-03**. Вторичные checkpoints: нет дополнительных.
- Владелец механизма: existing source owner named by primary report; paths: calibration/diagnostics/continuous.py:385-410, calibration/diagnostics/continuous.py:142-161; owner lanes: LANE-03.
- Владелец интеграционной приёмки: LANE-03 / PCL-01: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: PCL-01 (LANE-03), FRC-02 (LANE-03), FRC-01 (LANE-03). Дополнение: ADDON::SI-01 (не официальный E02 ID).
- Основание: ENCE canonical continuous report — прямой владелец PCL-01; existing preserved ENCE assertion требует нового независимого scale/degeneracy discriminator.
- Первый rebind checkpoint: LANE-03. Режим: in_lane_numeric_diagnostic_extension.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. New supplemental contract is due at this integration phase in its declared selected scope; current HEAD may already satisfy it, to be evidenced rather than reimplemented.

### Предлагаемое действие
Typed degeneracy/availability или явная scale-invariant denominator policy; versioned replay semantics.

Граница patch: Два независимых numerical owners и oracle, а не одна проблема precision.

### Условия и зависимости
Gate: **due_contract_gate**. Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.

- Repair numerical owner, затем typed/JSON receipt и source-bound fresh consumer; old report identity не изменять задним числом.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Positive-scale covariance, zero/mixed bins, calibrated controls и fresh persisted numerical reader.

Дополнение для выбранного пути:
- Positive-scale covariance, zero/mixed bins, calibrated controls и fresh persisted numerical reader.
- Unit scaling/degenerate ENCE и joint CC convention проходят independent oracle и fresh consumer; empirical FPR/production qualification отдельно.
- Positive scale preserves dimensionless ENCE; zero spread/nonzero error не zero-success. Declared degenerate policy + finite cases, actual persisted report и sidecar cannot upgrade.

Пакетная граница: Unit scaling/degenerate ENCE и joint CC convention проходят independent oracle и fresh consumer; empirical FPR/production qualification отдельно.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/103.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high bounded producer, selected-profile CAS and fresh numerical reader; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: Zero denominator математически undefined: review не навязывает finite/infinite замену. Coverage/PIT остаются; validation blocked/unverified; production bypass не доказан.
- Примечания к распределению: - Activation: Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.
- Otherwise: None
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - Zero denominator математически undefined: review не навязывает finite/infinite замену. Coverage/PIT остаются; validation blocked/unverified; production bypass не доказан.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## SI-02 · Unconditional p value подаётся как conditional coverage

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R12.2; механизм: SI-02.
- Основное окно: **LANE-03**. Вторичные checkpoints: нет дополнительных.
- Владелец механизма: existing source owner named by primary report; paths: foundry/methods/catalog/econometrics/advanced.py:368-412, foundry/methods/catalog/econometrics/advanced.py:543-606, foundry/methods/catalog/econometrics/advanced.py:800-926, ir/analytics/forecasting_uncertainty.py:523-676; owner lanes: LANE-03.
- Владелец интеграционной приёмки: LANE-03 / FRC-02: Coordinator принимает supplemental repair существующего owner и affected consumer evidence; не авторизует параллельного второго writer. Именной исполнитель ещё не назначен.
- E02: FRC-02 (LANE-03), FRC-01 (LANE-03), BKT-02 (LANE-03), BKT-03 (LANE-03). Дополнение: ADDON::SI-02 (не официальный E02 ID).
- Основание: Conditional coverage требует своей joint statistic/convention; unconditional df1 p не годится как тот же persisted diagnostic.
- Первый rebind checkpoint: LANE-03. Режим: in_lane_forecast_diagnostic_extension.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Это существующие spec locators и предлагаемые дополнительные discriminators. Старый TEST не считается автоматически покрывающим новую finding; новые adjunct tests имеют собственное evidence и closure. Все вновь предложенные прогоны NOT_RUN. New supplemental contract is due at this integration phase in its declared selected scope; current HEAD may already satisfy it, to be evidenced rather than reimplemented.

### Предлагаемое действие
Разделить named UC/IND/CC statistics, null/df/assumptions и передать правильный CC в existing consumers.

Граница patch: Два независимых numerical owners и oracle, а не одна проблема precision.

### Условия и зависимости
Gate: **due_contract_gate**. Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.

- Согласовать selected coverage test definition до summary/trust/packet. Existing point/conditional diagnostics и scientific independence claims сохраняются раздельно.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Обе documented conditioning conventions, cluster/even/undercoverage, persisted forecast projections и wrong-population refusal; actual fitted path отдельно.

Дополнение для выбранного пути:
- Обе documented conditioning conventions, cluster/even/undercoverage, persisted forecast projections и wrong-population refusal; actual fitted path отдельно.
- Unit scaling/degenerate ENCE и joint CC convention проходят independent oracle и fresh consumer; empirical FPR/production qualification отдельно.
- Independent joint df2 controls против unconditional df1, positive no-rejection, tails/dependence conventions, report→IR→fresh scope-consistent status. No empirical FPR claim from synthetic rejection.

Пакетная граница: Unit scaling/degenerate ENCE и joint CC convention проходят independent oracle и fresh consumer; empirical FPR/production qualification отдельно.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/104.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high bounded summary -> typed forecast bundle -> CAS fresh reader -> contract-only projection; уверенность распределения: high_contract_overlap_current_reachability_unverified.
- Ограничения: Конвенции conditioning чуть различаются численно. Chi-square asymptotic; synthetic sequence не empirical FPR. contract_only, production_value_eligible=false; no fitted GARCH/admission.
- Примечания к распределению: - Activation: Применяется к выбранному actual producer→consumer пути; final write-set и source owner перепроверяются на актуальном HEAD.
- Otherwise: None
- At primary_stage entry, rebind current owner/path/profile and classify due-now, already-satisfied, conditional-not-active, or blocked. No edit is authorized by this research file.
- Сохранённые ограничения review: - Конвенции conditioning чуть различаются численно. Chi-square asymptotic; synthetic sequence не empirical FPR. contract_only, production_value_eligible=false; no fitted GARCH/admission.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.


## Исходный порядок внутри lane

Не менять без actual write-set/contract reconciliation. Это порядок E02, не доказательство текущей готовности.

- 03-A: EMP-01 → FRC-01 → PCL-01 → FRC-02. Scope/value boundary→summary→continuous report→real empirical relation bridge
- 03-B: BKT-01 → BKT-02 → BKT-03. As-of trajectory→evaluation/range/completeness→fresh packet
- 03-C: BKT-04. CV/bootstrap selected caller and sampling unit

Cross-track gates (исходные, context-only):
[
  {
    "before": [
      "FRC-02"
    ],
    "after": [
      "BKT-03"
    ],
    "reason": "Final forecast/uncertainty semantics before shared report claim; local BKT numeric repairs may proceed earlier"
  }
]
