# Будущий lane 12

Статус: предварительный план, не свидетельство реализации. Основных карточек: 4. Сначала получить фактический отчёт исполнителя и сверить HEAD. Один implementation lane активен; corrective window приостанавливает затронутую работу, а не запускает параллельный lane.

## Порядок работы
1. Проверить текущую ветку/HEAD, незавершённые patches, write leases и источник evidence.
2. Для каждого пункта выбрать: уже закрыт; подтвердился; изменился контракт; не воспроизведён; UNRUN; требует решения. Сохранить причину и ссылку.
3. Выполнить только согласованный bounded patch или квалификацию у существующего owner.
4. Приложить точный oracle, контроли и affected-evidence map. Не ставить PASS по наличию файла/skip/fixture.
5. Обновить статус DA только в указанной части, не переносить весь TEST/REQ.

## Состав
- FE-05: Архитектурная проверка клиента устарела и читает строки как imports
- NATIVE-01: Bootstrap запускает doctor без контекста package
- TC-02: Проверки установленного пакета попадают в checkout lane
- FE-02: Generated client пытается разобрать binary content как JSON

## FE-05 · Архитектурная проверка клиента устарела и читает строки как imports

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R0.2; механизм: FE-05.
- Основное окно: **LANE-12**. Вторичные checkpoints: Before first current reliance on affected gate/profile; LANE-12 frozen source/artifact if changed; DA-08 impact-based final refresh.
- Владелец механизма: Существующий package architecture checker; интеграция у CLI-01.
- Владелец интеграционной приёмки: Владелец CLI-01 с единственным writer generator/checker. Именной исполнитель ещё не назначен.
- E02: CLI-01 (LANE-12). Дополнение: ADDON::FE-05 (не официальный E02 ID).
- Основание: LANE-12/CLI-01, либо более ранняя квалификация используемого gate. Механизм тесно совпадает с уже заданным C127-R02 AST repair, поэтому необходима сверка, а не второй checker.
- Первый rebind checkpoint: LANE-12. Режим: QUALIFICATION_BEFORE_RELYING_ON_GATE.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Сверить новый finding с уже выполненным AST-based repair. Разрешённые generator files проходят; строки/templates/comments не считаются imports; настоящие forbidden import/export/dynamic load дают отказ. Если exact mechanism уже устранён, оформить доказанный no-change disposition.

Граница patch: Разные checker owners и разные причины; общей новой надстройки не требуется.

### Условия и зависимости
Gate: **QUALIFICATION_BEFORE_RELYING_ON_GATE**. Закрыть до использования checker для приёмки client changes. Если он мешает текущей проверке, разрешено отдельное более раннее последовательное окно квалификации.

Нет дополнительных.

Исходные зависимости: []

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

Дополнение для выбранного пути:
**Предлагаемая работа**
Сверить новый finding с уже выполненным AST-based repair. Разрешённые generator files проходят; строки/templates/comments не считаются imports; настоящие forbidden import/export/dynamic load дают отказ. Если exact mechanism уже устранён, оформить доказанный no-change disposition.

**E02 context, не автоматическое покрытие**
- REQ-CLI-01-02
- TEST-CLI-01-02
- TEST-CLI-01-03
- E02-I12-B

**Исходная приёмка**
native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

**Что сохранить**
Сохранить запрет committed raw/extra files и точную разрешённую public surface; не давать широкое allowlist исключение.

Пакетная граница: Неверный root/diff и пропущенная obligation различаются отрицательными контролями; допустимые facade imports сохранены.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/3.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: Node24 builtin-only execution.
- Примечания к распределению: A live no-change disposition may be valid if E02 already fixed this exact mechanism and controls prove it.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## NATIVE-01 · Bootstrap запускает doctor без контекста package

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R0.1; механизм: NATIVE-01.
- Основное окно: **LANE-12**. Вторичные checkpoints: Before first current reliance on affected gate/profile; LANE-12 frozen source/artifact if changed; DA-08 impact-based final refresh.
- Владелец механизма: Существующий bootstrap/doctor owner; интеграция у HYG-04.
- Владелец интеграционной приёмки: Владелец HYG-04 совместно с bootstrap/doctor owner. Именной исполнитель ещё не назначен.
- E02: HYG-04 (LANE-12). Дополнение: ADDON::NATIVE-01 (не официальный E02 ID).
- Основание: Квалификация при первом использовании bootstrap; исправление включить в HYG-04 до LANE-12 freeze. Подтверждено точное пересечение bootstrap.py.
- Первый rebind checkpoint: LANE-12. Режим: QUALIFICATION_BEFORE_RELYING_ON_GATE.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Использовать корректный package/module способ запуска doctor. Проверить настоящую форму команды для четырёх объявленных profiles; вызовы installer только записывать в тесте, не исполнять.

Граница patch: Environment/bootstrap, installed lane и PostgreSQL/corpus — отдельные изменения с общей приёмкой воспроизводимого профиля.

### Условия и зависимости
Gate: **QUALIFICATION_BEFORE_RELYING_ON_GATE**. Закрыть до опоры на bootstrap/doctor qualification. Это не доказательство hosted CI failure: checked-in CI использовал skip-doctor.

Нет дополнительных.

Исходные зависимости: []

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Python3.14 command-form controls and actual caller without install side effects.

Дополнение для выбранного пути:
**Предлагаемая работа**
Использовать корректный package/module способ запуска doctor. Проверить настоящую форму команды для четырёх объявленных profiles; вызовы installer только записывать в тесте, не исполнять.

**E02 context, не автоматическое покрытие**
- REQ-HYG-04-02
- TEST-HYG-04-02
- E02-I12-A

**Исходная приёмка**
Python3.14 command-form controls and actual caller without install side effects.

**Что сохранить**
Сохранить early JAX defaults, explicit environment overrides и supported profile commands; command-form tests не должны устанавливать зависимости.

Пакетная граница: На поддерживаемом профиле действительно выполнены нужные consumers; missing backend/input явно unqualified или отказ, не PASS.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/4.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: Namespace shim under Python3.12; CI setup explicitly skip-doctor, no hosted CI failure asserted.
- Примечания к распределению: 
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## TC-02 · Проверки установленного пакета попадают в checkout lane

- Тип: Пробел квалификации. Работа: qualification_not_automatic_code_fix.
- Remediation unit: R0.1; механизм: TC-02.
- Основное окно: **LANE-12**. Вторичные checkpoints: Before first current reliance on affected gate/profile; LANE-12 frozen source/artifact if changed; DA-08 impact-based final refresh.
- Владелец механизма: Существующие владельцы installed worker tests и координатор package-origin evidence.
- Владелец интеграционной приёмки: Координатор DFK-01 installed-artifact evidence и фактический worker-test owner. Именной исполнитель ещё не назначен.
- E02: DFK-01 (LANE-12), HYG-02 (LANE-12), HYG-04 (LANE-12). Дополнение: ADDON::TC-02 (не официальный E02 ID).
- Основание: Selection/origin qualification нужна до соответствующего PASS; окончательное installed evidence предоставляется LANE-12. Это общее обязательство origin, не доказанный дефект исходников HYG.
- Первый rebind checkpoint: LANE-12. Режим: QUALIFICATION_BEFORE_RELYING_ON_GATE.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Разделить checkout и installed worker tests, сохранить collected/selected/skipped manifest. Выполнить installed consumers вне checkout ancestry на связанных wheel → sdist → rebuilt wheel артефактах.

Граница patch: Environment/bootstrap, installed lane и PostgreSQL/corpus — отдельные изменения с общей приёмкой воспроизводимого профиля.

### Условия и зависимости
Gate: **QUALIFICATION_BEFORE_RELYING_ON_GATE**. Любой installed-profile PASS блокируется без настоящего artifact/origin evidence. Независимые source tests могут продолжаться с явно более узким claim.

Нет дополнительных.

Исходные зависимости: []

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: Actual collected/selected manifest, isolated installed imports and bounded supplied inputs.

Дополнение для выбранного пути:
**Предлагаемая работа**
Разделить checkout и installed worker tests, сохранить collected/selected/skipped manifest. Выполнить installed consumers вне checkout ancestry на связанных wheel → sdist → rebuilt wheel артефактах.

**E02 context, не автоматическое покрытие**
- REQ-DFK-01-04
- TEST-DFK-01-03
- TEST-HYG-02-04
- E02-I12-A
- DA-05
- DA-08

**Исходная приёмка**
Actual collected/selected manifest, isolated installed imports and bounded supplied inputs.

**Что сохранить**
Отсутствующая artifact/origin binding остаётся NOT_RUN/BLOCKED, не PASS. Сохранить настоящие package resources и canonical identity.

Пакетная граница: На поддерживаемом профиле действительно выполнены нужные consumers; missing backend/input явно unqualified или отказ, не PASS.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/7.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: see qualified primary report; no production frequency inferred; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: Synthetic origin assertion; native collection and installed profile unrun.
- Примечания к распределению: 
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.

## FE-02 · Generated client пытается разобрать binary content как JSON

- Тип: Зафиксированный механизм. Работа: repair_candidate_after_HEAD_recheck.
- Remediation unit: R8.2; механизм: FE-02.
- Основное окно: **LANE-12**. Вторичные checkpoints: DA-08 and affected final artifact only.
- Владелец механизма: Существующие runtime client generator и public transport owners.
- Владелец интеграционной приёмки: Владелец CLI-01 с единственным writer generator/checker. Именной исполнитель ещё не назначен.
- E02: CLI-01 (LANE-12). Дополнение: ADDON::FE-02 (не официальный E02 ID).
- Основание: LANE-12/CLI-01 до frozen generation: точное пересечение generate_runtime_client.py и уже предусмотренное обязательство сохранять binary transport.
- Первый rebind checkpoint: LANE-12. Режим: AFFECTED_CONSUMER_CORRECTNESS.
- Если условие не активно: Сохранить bounded план; фактическую приёмку и очередь определить после HEAD reconciliation.
- Граница связи: Связь является предлагаемым распределением аудита. Это не новая официальная E02 requirement и не доказательство, что finding уже исправлен данным package.

### Предлагаемое действие
Расширить выбор media type/decoder в generator и проверить actual artifact-content route: объявленные binary/CSV bytes должны без изменения доходить до public generated API. Перегенерировать единую canonical family, не исправлять generated output вручную. Проверить полный двусторонний маршрут к настоящему Runtime.

Граница patch: Два независимых небольших изменения, не общий root cause.

### Условия и зависимости
Gate: **AFFECTED_CONSUMER_CORRECTNESS**. Закрыть до I12-B acceptance binary/download surface и любого выпуска, заявляющего её работоспособность.

Нет дополнительных.

Исходные зависимости: [{"package": "R0.1", "relation": "Только supported-profile приёмка; локальная разработка может идти параллельно."}]

Межпакетные отношения (типизированные, не blanket gates):
- {"from": "R0.1", "to": "ALL", "kind": "qualification_not_development_block", "reason": "Required supported-profile acceptance, not ban on bounded development."}

Продолжается: Незатронутые assertions и профили продолжаются; справочная связь с package не создаёт blanket blocker.

Pull-forward: Если finding затрагивает активный обещанный consumer/claim/profile, выполнить HEAD reconciliation и открыть bounded corrective window до приёмки именно этого claim; не переносить неисправность формально до after12.

### Приёмка
Исходный oracle: native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

Дополнение для выбранного пути:
**Предлагаемая работа**
Расширить выбор media type/decoder в generator и проверить actual artifact-content route: объявленные binary/CSV bytes должны без изменения доходить до public generated API. Перегенерировать единую canonical family, не исправлять generated output вручную. Проверить полный двусторонний маршрут к настоящему Runtime.

**E02 context, не автоматическое покрытие**
- REQ-CLI-01-04
- REQ-CLI-01-05
- TEST-CLI-01-04
- TEST-CLI-01-05
- E02-I12-B

**Исходная приёмка**
native producer → persisted selected owner → fresh consumer; include the named positive/failure discriminators in primary report

**Что сохранить**
Сохранить JSON/error/header/auth/currentness semantics, точные arrayBuffer bytes, safe wire names и private raw handoff.

Пакетная граница: Exact binary bytes сохраняются; текст отображается буквально; native browser/client integration проверены.

### Evidence и актуальность
- Точный HEAD/tree и профиль исполнения; адрес/хеш итогового patch и затронутые owner/consumer paths.
- До/после oracle или доказательство уже выполненного fix на текущем HEAD; отрицательные и положительные контроли по исходной карточке.
- Actual collected/executed manifest, выбранные inputs и explicit UNRUN/SKIP/BLOCKED; отсутствие запуска не PASS.
- Проверка сохранённых safeguards и список именно устаревших dependent evidence.

- Исходная карточка: [05_Sources/Remediation/REGISTRY.json](../05_Sources/Remediation/REGISTRY.json) /findings/51.
- Исходный commit: f1541ed155f278689be48a8c7ac56c3e200210f7.
- Доверие к исходному evidence: high; уверенность распределения: DOCUMENT_VERIFIED; PLACEMENT_INFERRED; LIVE_HEAD_AND_ROUTE_UNVERIFIED.
- Ограничения: Synthetic Response, not HTTP/CAS/backend acceptance.
- Примечания к распределению: Audit used synthetic Response. Native bidirectional generated-client→actual Runtime→same-client response is still required.
- Сохранённые ограничения review: Нет дополнительных.
- HEAD обязательно перепроверить, текущий статус: **UNKNOWN**.
- Сопоставить исходные owner paths и oracle с текущим HEAD; найти изменения после f1541ed, не использовать номера строк как текущие.
- Получить отчёт исполнителя текущего lane 01, фактические merges, write leases, доступный профиль и статусы DA-01…DA-08.
- Повторить bounded failing/control witness только на выбранном затронутом пути. Если уже закрыто, приложить evidence и снять из очереди; если источник/контракт изменился, сначала изменить решение.


## Исходный порядок внутри lane

Не менять без actual write-set/contract reconciliation. Это порядок E02, не доказательство текущей готовности.

- 12-A: DFK-01 → HYG-02 → HYG-04. Schema/alias census→actual facade migration→bootstrap/benchmark/docs compatibility
- 12-B: CLI-01. OpenAPI private raw→canonical generated client→actual Runtime

Cross-track gates (исходные, context-only):
[]
