# Вход в corrective windows

Это индекс условных окон, а не новая обязательная стадия из 60 fixes перед01. Вначале выбрать **конкретный gate/consumer/release claim**, затем фильтровать индекс. Ни один список ниже не означает «сначала закрыть всё».

1. До первого reliance на повреждённый qualification gate выполнить только относящийся qualification/reconciliation.
2. До active consumer claim проверить именно его source owner; если контракт отсутствует, блокируется конкретный шаг, не весь suffix.
3. До actual release/deploy применить policy/release условия для выбранного поставляемого объекта. Build/installed PASS не заменяет release gate.
4. Если consumer/claim не выбран, сохранить явный fallback/after12 и pull-forward trigger. Это не риск-акцепт.

Один implementation window активен. При corrective patch текущий lane приостанавливает затронутую работу и возвращается после bounded acceptance. Все карточки с решением, точным oracle и ограничениями находятся в [полном файле](../02_Executor/CORRECTIVE_EXECUTOR_RU.md); фильтруемый индекс рядом.

## QUALIFICATION

STR-01, TC-01, TC-03, TC-04, TC-05, STR-02, STR-03, TC-06, GE-01, GE-02, GE-03, GE-C01, DST-01, DST-02.

## FOUNDATION_CUSTODY

STATE-01, STATE-02, BUD-01, LIF-01, LIF-02, LIF-03, LIF-04, publication-authority::PA-01, AB-02, NR-01, RR-02, RR-03, custody::RC-01.

## DOMAIN_SELECTED_PATH

CS-01, LIB-01, scholar::RC-01, FG-01, FG-02, GR-01, GR-02, GR-03, NC-04a, NC-04b, AB-01, CS-02, SA-01, SA-02, SA-03, AR-01, AR-02, AR-03, policy-assembly::PA-01, policy-assembly::PA-02, CR-01, CR-02, semantic-matching::F1, semantic-matching::F2.

## FRONTEND

FE-03, FE-06, UI-03.

## POLICY_RELEASE

AUTH-01, AUTH-02, AUTH-03, REL-01, REL-02, REL-03.

## Раннее qualification при primary lane12

NATIVE-01, TC-02 и FE-05 ведутся у lane12 owners, но если соответствующий bootstrap/origin/architecture gate нужен раньше, он квалифицируется **до первой опоры на него**. Это те же карточки, не дополнительный счёт или второй patch. FE-02 закрывается у canonical generator/wire owner до final generation/actual binary route acceptance.
