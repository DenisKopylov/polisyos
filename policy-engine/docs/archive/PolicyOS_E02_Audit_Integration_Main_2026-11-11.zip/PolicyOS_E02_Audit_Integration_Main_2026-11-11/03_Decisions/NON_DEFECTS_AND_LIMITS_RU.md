# Что не превращать в автоматическую задачу на код

- Q7: недостаточная квалификация не доказывает продуктовый сбой. Нужны actual inputs/runtime/origin/collection, а не новый placeholder test.
- R7: bounded риск не равен инциденту или доказанной эксплуатационной частоте. Сначала подтвердить selected wiring и owner decision.
- D6: контрактное решение принимается существующим owner; без решения нельзя незаметно ужесточать совместимость или обещать новую гарантию.
- A12: архитектура/reuse не дают разрешения на массовый перенос, удаление или объединение различных estimands. LIB-04 и AB-KEEP прежде всего preserve; отдельный обязательный fix не назначается.
- CP23::GRANULARITY: подтверждён лишь plan emission monthly→annual-labelled, не fetched annual data и не authority effect. Проверять как companion limitation у R14/selected scope. Не добавлять 115-ю CP карточку.
- DDM repeated selected reads: стоимость currentness control; physical I/O, latency, capacity, SLA не измерены. Не считать третьим DDM defect.
- Observations и rejected signals сохранены полностью в NON_FINDING_REGISTER.json. Они ограничивают interpretation; нового исполнения не требуют сами по себе.

Если активный consumer зависит от спорного контракта, эскалировать точное решение/квалификацию. После решения возможен bounded patch; «after12» не заменяет decision и не означает принятие риска.
