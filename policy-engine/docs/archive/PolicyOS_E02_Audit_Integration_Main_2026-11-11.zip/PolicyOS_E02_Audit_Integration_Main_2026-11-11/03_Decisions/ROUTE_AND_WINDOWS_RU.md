# Условная очередь и corrective windows

## Исходная очередь
E02 v3: 06 → 08 → 07 → 04 → 10 → 05 → 09 → 01 → 03 → 02 → 11 → 12. Эта запись нужна для provenance и ownership; она не означает перезапуск предшествующих lanes. Для текущего задания рабочий suffix: 01 → 03 → 02 → 11 → 12, после сверки фактического статуса.

## Три разных ограничения
- **Implementation dependency:** отсутствует или несовместим необходимый producer/consumer contract. Блокируется этот implementation step, нельзя «реализовать против будущего mock» и назвать всё deferred acceptance.
- **Acceptance dependency:** локальная реализация и её независимые assertions возможны, но реальный поздний consumer ещё недоступен. Откладывается только конкретный переход/claim из DA.
- **Change-impact recheck:** старый путь может оставаться квалифицированным. После конкретного изменения обновляется затронутый evidence; ссылка на другой lane не требует повторять всё.

## Когда открывать corrective window
1. На actual HEAD воспроизведён finding или доказана изменённая contract boundary.
2. Указан действующий consumer/claim/profile, которому это мешает.
3. Указаны исходный владелец, минимум изменяемых файлов, write lease, before/after oracle.
4. Определены downstream evidence, которые потеряют актуальность.

На время bounded patch приостановить затронутый implementation lane; не стартовать второй lane параллельно. После приёмки вернуться в suffix с обновлённым evidence. Если условие не сработало, не считать наличие карточки само по себе blocker.

## Семейства окон
- **QUALIFICATION:** bootstrap, selectors, actual root/diff/import, no-work oracle, real OPA/PostgreSQL/corpus. До первого reliance на соответствующий PASS; не ждут12, если нужны раньше.
- **FOUNDATION/CUSTODY:** runtime cleanup, finalization, receipt, checkpoint, artifact scope, publication codec. Только при выбранном реальном consumer или затронутой E02 приёмке. Owner остаётся в исходном lane.
- **POLICY/RELEASE:** canonical/shipped/served policy, tag/source snapshot, scanner report. До фактического выпуска затронутого профиля, отдельно от build/installed acceptance.
- **DOMAIN/ADAPTER:** schema, REST, method registry, World metrics, feedback sidecar. Активируются по actual selected route; самостоятельные additions не объявлять официальными E02 пакетами.
- **FRONTEND:** generations, rendering, architecture/parity. Свой UI owner; реальная route/claims связь определяет срочность.

## Late acceptance без расширения
- DA-01: только поздняя RES-03→CMP/CYC partial-result transition. Не весь RES-03 и не universal RES04 gate.
- DA-02: выбранный source/Parquet/CAS→Foundry consumer. Не откладывать независимые byte/readback tests.
- DA-03/04: final calibration consumption после соответствующих objective/calibrator changes. Локальные controls остаются раньше.
- DA-05: один shared final noneditable artifact/origin receipt. API/GRF/DDM local-only obligations сохраняются и не приобретают фиктивного binding coverage.
- DA-06: CYC-05 остаётся единственным readiness bridge; lane12 только производит настоящие build/census/client artifacts. Без appointed issuer нет самоизданного authority.
- DA-07: только фактически изменённые выбранные EMP/FRC/summary consumers после03. Независимый qualified N5/N8 не блокируется автоматически.
- DA-08: после12 impact-based final selected paths/holdout и stale evidence; один shared run не превращается в независимые повторения.

Полные исходные scope, REQ/TEST subsets и binding IDs находятся в E02_DEFERRED_ACCEPTANCE_UNCHANGED.json. Любой новый invalidated binding добавляется с owner/reason/profile.

## Границы имён
AUDIT::STR-01 и E02::STR-01 различны. AUDIT::DA-01…04 не равны E02 deferred DA-01…08. scholar::RC-01 и custody::RC-01, publication-authority::PA-01 и policy-assembly::PA-01 сохраняются раздельно. FG-02/GR-03 делят один механизм; RR-01 как alias ST-02 не добавляет строку. ADDON::<finding ID> лишь навигационный ID этого дополнения, не официальный E02 requirement.
