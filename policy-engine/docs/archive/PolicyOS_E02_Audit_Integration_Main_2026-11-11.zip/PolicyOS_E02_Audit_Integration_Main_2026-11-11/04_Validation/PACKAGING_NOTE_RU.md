# Упаковка для ограничения 20 MiB

Содержание и распределение116 карточек неизменны относительно semantic review. Основной ZIP использует самостоятельный scoped source snapshot, описанный в SNAPSHOT_SCOPE.json. Полный E02 v3 включён. Все reports/raw results cumulative evidence включены, кроме трёх больших baseline inventories. Полные original source ZIP доступны отдельными самостоятельными файлами.

Root manifest и validator относятся именно к основному ZIP. Исторические исходные manifests не переписаны и не выдаются за полный состав main; validator разрешает лишь одно явно зарегистрированное отсутствие cumulative ZIP и отдельно проверяет каждый извлечённый evidence файл.
