#!/usr/bin/env python3
"""Read-only integrity and coverage checks for this plan. No product/repo operations."""
from pathlib import Path
import csv,json,hashlib,collections,sys,re,zipfile
ROOT=Path(__file__).resolve().parents[1]
def load(p):return json.loads((ROOT/p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checks=[]
def check(name,ok,detail=None):checks.append({'check':name,'status':'PASS' if ok else 'FAIL','detail':detail})
r=load('01_Registry/ALL_FINDINGS.json');rows=r['findings'];src=load('05_Sources/Remediation/REGISTRY.json');ddm=load('05_Sources/Remediation/SUPPLEMENT_DDM.json');e02=load('05_Sources/E02_v3/04_Трассировка/Индекс.json');pkgs=load('05_Sources/Remediation/PACKAGE_MAP.json')
expected={v['id']:v for v in src['findings']};expected_ddm={v['id']:v for v in ddm['findings']};byid={v['id']:v for v in rows}
check('116_unique_rows',len(rows)==len(byid)==116,len(rows))
cp=[x for x in rows if x['record_scope']=='CP01_23'];ds=[x for x in rows if x['record_scope']=='SUPPLEMENT_DDM']
check('CP114_exact_coverage',len(cp)==114 and {x['id'] for x in cp}==set(expected))
check('CP113_mechanisms',len({x['mechanism_key'] for x in cp})==113)
check('DDM2_separate_exact',len(ds)==2 and {x['id'] for x in ds}==set(expected_ddm))
check('categories_M82_Q7_R7_D6_A12',dict(collections.Counter(x['category'] for x in cp))=={'M':82,'Q':7,'R':7,'D':6,'A':12})
check('original_records_preserved_exact',all(x['retained_original_record']==(expected|expected_ddm)[x['id']] for x in rows))
check('58_CP_units_plus_2_DDM',len({x['remediation_package'] for x in cp})==58 and len({x['remediation_package'] for x in ds})==2)
check('source_package_membership',all(x['remediation_package']==expected[x['id']]['package'] for x in cp))
stages={'LANE-01','LANE-03','LANE-02','LANE-11','LANE-12','CORRECTIVE','AFTER-12'}
check('one_valid_primary_per_row',all(x['primary_stage'] in stages for x in rows))
required=['source_owner','integration_owner','placement_reason_ru','proposed_action_ru','gate_condition_ru','acceptance_inherited','mandatory_evidence','source_record_file','source_record_pointer','mapping_confidence','HEAD_recheck_steps','integration_addon_id','first_rebind_checkpoint','pull_forward_condition_ru']
check('required_fields_populated',all(x.get(k) not in (None,'',[]) for x in rows for k in required),{'fields':required})
check('no_actual_HEAD_or_implementation_claim',all(x['current_HEAD_recheck_required'] is True and x['implementation_status_current']=='UNKNOWN_AWAITING_EXECUTOR_REPORT' and x['current_HEAD_status']=='NOT_INSPECTED_FOR_THIS_PLAN' for x in rows))
check('one_lane_conditional_metadata',r['implementation_active_lanes_max']==1 and r['route_is_conditional'] is True and r['route_suffix']==['LANE-01','LANE-03','LANE-02','LANE-11','LANE-12'])
check('no_code_or_product_tests',r['product_code_changed'] is False and r['product_probes_run'] is False and all(x['code_change_authorized_by_plan'] is False for x in rows))
ep={p['packet_id']:p for p in e02['packets']};bad=[]
for x in rows:
 for p in x['e02_packages']:
  if p['package'] not in ep:bad.append([x['id'],p['package']]);continue
  v=ep[p['package']]
  if p['lane']!=v['lane'] or p['requirement_ids']!=v['requirement_ids'] or p['test_ids']!=v['test_ids']:bad.append([x['id'],p['package'],'context mismatch'])
  if not (ROOT/p['spec_path']).is_file() or not (ROOT/p['trace_path']).is_file():bad.append([x['id'],p['package'],'missing file'])
check('all_E02_package_contexts_real',not bad,bad)
# Existing tests referenced in mapper context are not invented.
reqs={t for p in ep.values() for t in p['requirement_ids']};tests={t for p in ep.values() for t in p['test_ids']};badrefs=[]
for x in rows:
 txt=json.dumps([x.get('source_E02_test_context'),x['acceptance_proposed']],ensure_ascii=False)
 for ref in set(re.findall(r'(?:REQ|TEST)-[A-Z]+-\d{2}-\d{2}',txt)):
  if ref not in reqs|tests:badrefs.append([x['id'],ref])
check('mapper_REQ_TEST_refs_exist',not badrefs,badrefs)
# Canonical source pointer identifies retained exact record.
badptr=[]
for x in rows:
 obj=load(x['source_record_file'])
 try:
  for part in x['source_record_pointer'].strip('/').split('/'):obj=obj[int(part)] if isinstance(obj,list) else obj[part]
  if obj!=x['retained_original_record']:badptr.append(x['id'])
 except (KeyError,ValueError,IndexError):badptr.append(x['id'])
check('all_source_pointers_resolve',not badptr,badptr)
with (ROOT/'01_Registry/ALL_FINDINGS.csv').open(encoding='utf-8-sig',newline='') as f:csvrows=list(csv.DictReader(f))
check('CSV_JSON_exact_row_set',len(csvrows)==116 and {x['id'] for x in csvrows}==set(byid))
check('CSV_primary_owner_gate_consistency',all(c[k]==str(byid[c['id']][k]) for c in csvrows for k in ['primary_stage','source_owner','integration_owner','gate_type','gate_condition_ru']))
check('no_auto_code_for_nondefects',all(x['work_kind'] not in ['repair_candidate_after_HEAD_recheck'] for x in cp if x['category']!='M'))
check('ADDON_namespace_unique',len({x['integration_addon_id'] for x in rows})==116 and all(x['id_namespace']=='AUDIT_FINDING' for x in rows))
check('non_findings_not_added_to_rows','CP23::GRANULARITY' not in byid and load('03_Decisions/NON_FINDING_REGISTER.json')['cp23_limits']==src['hypotheses_and_limits'])
check('DA_unchanged',load('03_Decisions/E02_DEFERRED_ACCEPTANCE_UNCHANGED.json')==load('05_Sources/E02_v3/09_Исполнение/План_исполнения.json')['deferred_acceptance'])
deps=load('03_Decisions/CROSS_PACKAGE_DEPENDENCIES.json')
check('typed_edges_non_edges_retained',deps['cross_package_edges']==pkgs['cross_package_edges'] and deps['critical_non_edges']==pkgs['critical_non_edges'])
check('source_edge_refs_valid',all(e['from'] in {p['id'] for p in pkgs['packages']} and (e['to']=='ALL' or e['to'] in {p['id'] for p in pkgs['packages']}) for e in deps['cross_package_edges']))
check('LIB02_not_L03_not_raw_quantile_blocker',byid['LIB-02']['primary_stage']=='LANE-11' and 'raw' in json.dumps(byid['LIB-02']['acceptance_proposed']).lower())
check('DDM_ID_preaggregation_four_producers','four' in json.dumps(byid['DDM-ID-01']['acceptance_proposed']).lower() or 'четыр' in json.dumps(byid['DDM-ID-01']['acceptance_proposed'],ensure_ascii=False).lower())
check('DDM_NUM_derived_overflow_and_roundtrip',all(t in json.dumps(byid['DDM-NUM-01']['acceptance_proposed']).lower() for t in ['overflow','json']))
check('AB_KEEP_no_AUC_requirement','auc' not in json.dumps(byid['AB-KEEP']['acceptance_proposed']).lower())
check('final_mandatory_closure_not_optional','Полный E02 PASS запрещён' in (ROOT/'02_Executor/FINAL_AFTER12_ACCEPTANCE_RU.md').read_text())
# Each row rendered once in its primary executor file.
render_missing=[]
for x in rows:
 path=ROOT/'02_Executor'/f'{x["primary_stage"]}_EXECUTOR_RU.md'
 if not path.is_file() or ('## '+x['id']+' ·') not in path.read_text():render_missing.append(x['id'])
check('all_executor_cards_rendered',not render_missing,render_missing)
# Validate only this addendum's links; source snapshots are historical untouched documents.
badlinks=[]
for p in [ROOT/'НАЧАТЬ_ЗДЕСЬ.md']+list((ROOT/'00_Guide').glob('*.md'))+list((ROOT/'01_Registry').glob('*.md'))+list((ROOT/'02_Executor').glob('*.md'))+list((ROOT/'03_Decisions').glob('*.md')):
 for ref in re.findall(r'\[[^\]]*\]\(([^)]+)\)',p.read_text()):
  if ref.startswith(('http:','https:','#','mailto:')):continue
  target=(p.parent/ref.split('#')[0]).resolve()
  if not target.exists():badlinks.append([str(p.relative_to(ROOT)),ref])
check('addendum_local_links',not badlinks,badlinks)
# Exact included source validation with one explicitly external cumulative archive.
scope=load('05_Sources/SNAPSHOT_SCOPE.json')
allowed_missing={a['path']:a for a in scope['omitted_from_Remediation']}
for folder in ['05_Sources/Remediation','05_Sources/E02_v3']:
 base=ROOT/folder;manifest=base/'SHA256SUMS.txt';bad=[];n=0;omitted_seen=[]
 for line in manifest.read_text().splitlines():
  if not line.strip():continue
  h,rel=line.split(None,1);rel=rel.strip().lstrip('*');q=base/rel;n+=1
  if folder.endswith('/Remediation') and rel in allowed_missing:
   if q.exists() or h!=allowed_missing[rel]['sha256']:bad.append(rel+' unexpected omission/hash')
   omitted_seen.append(rel);continue
  if not q.is_file() or sha(q)!=h:bad.append(rel)
 if folder.endswith('/Remediation') and set(omitted_seen)!=set(allowed_missing):bad.append('omission declaration mismatch')
 check('exact_included_source_SHA256_'+folder,not bad,{'checked_original_entries':n,'declared_external_omissions':omitted_seen,'bad':bad})
excerpt=load('05_Sources/CP01-22_EVIDENCE_MANIFEST.json');bad=[]
for e in excerpt['files']:
 q=ROOT/'05_Sources/CP01-22_Evidence_Text'/e['relative_path']
 if not q.is_file() or sha(q)!=e['sha256']:bad.append(e['relative_path'])
expected_omissions={'baseline/snapshot_files_sha256.json','baseline/tree_manifest.json','baseline/git_tree.txt'}
check('self_contained_CP01_22_evidence_excerpt',not bad and {e['relative_path'] for e in excerpt['excluded_inventory_files']}==expected_omissions,{'included_files':len(excerpt['files']),'explicit_omissions':sorted(expected_omissions),'bad':bad})
sources=load('05_Sources/SOURCE_MANIFEST.json')
check('external_sources_declared_not_required_for_main_validation',len(sources)==3 and all(s['included_in_main_zip'] is False and s['bytes']<20*1024*1024 and len(s['sha256'])==64 for s in sources))
manifest=ROOT/'SHA256SUMS.txt'
if manifest.exists():
 bad=[];n=0
 for line in manifest.read_text().splitlines():
  h,rel=line.split(None,1);q=ROOT/rel.strip().lstrip('*');n+=1
  if not q.is_file() or sha(q)!=h:bad.append(rel)
 check('delivered_manifest_hashes',not bad,{'checked':n,'bad':bad})
else:check('delivered_manifest_hashes',False,'MISSING_ROOT_MANIFEST: complete delivery cannot be verified')
report={'status':'PASS_ARTIFACT_COVERAGE_AND_INTEGRITY_ONLY' if all(c['status']=='PASS' for c in checks) else 'FAIL','scope':'Static plan/source integrity; no actual HEAD inspection, product tests or native acceptance.','counts':{'CP_cards':len(cp),'CP_mechanisms':len({x['mechanism_key'] for x in cp}),'DDM_separate':len(ds),'total_rows':len(rows),'primary_stages':dict(collections.Counter(x['primary_stage'] for x in rows))},'checks':checks}
print(json.dumps(report,ensure_ascii=False,indent=2));sys.exit(0 if report['status'].startswith('PASS') else 1)
