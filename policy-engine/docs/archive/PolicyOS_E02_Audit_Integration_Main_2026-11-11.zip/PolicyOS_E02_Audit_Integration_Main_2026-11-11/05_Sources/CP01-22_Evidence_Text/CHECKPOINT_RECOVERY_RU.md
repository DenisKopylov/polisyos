# PolicyOS: восстановленный checkpoint глубокого аудита

**10 ноября 2026. Статус: частично проверено. Это продолжение аудита, не заключение о готовности продукта.**

Проверяемая база: `f1541ed155f278689be48a8c7ac56c3e200210f7`, tree `29890b967236a8f07e2b0f92a0133ee36883ac49`. Прежний итоговый архив сохранён отдельно. Новые результаты уточняют его семейства SYS, а не увеличивают механически число независимых дефектов.

## Что удалось восстановить и довести

Сохранились baseline, probes и результаты по ownership, reuse и начальной scaling-серии. Последний scaling-запуск оборвался внутри проверочного сценария; structure не дошёл до отчёта из-за непарсируемого файла. Свежая проверка восстановила обе ветви. Продуктовый код, tests/config репозитория, E02 и реальные задания не изменялись и не запускались.

Результатами checkpoint считаются файлы в `checkpoint_recovery/`, перечисленные ниже. Старые ошибки и несовпадения не удалены.

### 1. Worker shutdown: состояние записи опережает остановку потока

**Подтверждён механизм, SYS-05; не подтверждён внешний ущерб.** На настоящем `ControlWorker`, реальных потоках и SQLite in-memory вызов `stop(timeout=.01)` вернулся при ещё работающем обработчике. Запись worker уже стала `stopped`, но interrupt-флаг остался неустановленным. Следующий heartbeat обновил lease и вернул запись в `running`; проверка текущего владельца job прошла. После завершения обработчика поток остановился, а запись осталась `idle` с действующей lease. Контроль с незанятым worker корректно завершился в `stopped`.

Источники: `control_worker.py:132–142, 216–333`; `ControlRunService.close`, `control/run_lifecycle.py:9271–9289`, после `stop()` закрывает принадлежащие ему ресурсы. Следовательно, успешный возврат `stop()` сам по себе не гарантирует завершения активного обработчика. Закрытие живого server, реальная доменная запись после shutdown и повреждение данных **не воспроизводились**. Lease selection, materialization job и handler синтетические; default timeout 2 секунды в этом опыте не измерялся.

Доказательство: [ownership_results.json](checkpoint_recovery/ownership_results.json). Следующий acceptance: длительный handler через настоящий service/container shutdown, согласованный drain/interrupt/fence и проверка отсутствия обращений к закрытым ресурсам.

### 2. Run index: полный каталог, стоимость TTL-hit и работа до фильтра

**Подтверждены bounded механизмы, SYS-07.**

- На 10 001 синтетических run-каталогах и default cap 10 000 последний существующий run отсутствует в exact lookup, tenant list и построенном owner-map. Это расширение прежнего AUD-001, а не новый независимый баг. Адаптеры run и регистрация artifact owners заменены простыми fixtures; реальные artifact permissions не проверялись.
- Для 100 / 1 000 / 5 000 validity-файлов по 1 024 байта пять cache-hit обращений прочитали соответственно 500 / 5 000 / 25 000 файлов. TTL не ограничивает эту работу: generation hash вычисляется до возврата cache-hit. Изменение содержимого той же длины действительно инвалидирует generation, поэтому просто убрать hashing без замены freshness-контракта нельзя.
- `list_runs` применяет current-validity projection до tenant/page filtering. При 100/500 записей и синтетических pending-наборах были измерены N×P чтения. **P=10/100 не доказано достижимым в штатном admission:** код также содержит `batch_pending`-ограничение. Проба устанавливает стоимость этих методов на таких inputs, не прогноз роста production pending-store. Часть runs без decision packet не требует projection.
- Четыре специально синхронизированных холодных вызова одного метода сделали четыре rebuild. Это отсутствие coalescing на данном method seam, не HTTP load test и не доказанная гонка содержимого.

Доказательство: [scaling_results_v2.json](checkpoint_recovery/scaling_results_v2.json), секция `validity_and_run_index`. Следующий acceptance: настоящий loader/tenant endpoint, достигнутый persisted corpus, параллельные запросы через HTTP, отдельные гарантии полного каталога и bounded cache.

### 3. Долгоживущие owners: retention измерен, production leak не объявлен

**Уточнены SYS-05, SYS-08, SYS-11.**

- Rate limiter сохранил 1 000 / 10 000 / 50 000 raw-path buckets после смены тестового времени и повторного обращения к одному пути. Tracemalloc для 50 000 buckets показал около 14,0 MB retained Python allocations. Нормализованные live paths дали один key; active-stream key удалился после release. Это не production RSS и не проверка всех buckets фоновой очисткой.
- Синтетические issued-record graphs удерживали 8 / 32 / 128 payloads по 64 KiB; после удаления тестового owner все payloads освобождались. 1 000 object-token references также удерживались и освобождались контрольным clear. Это установление сильного владельца и роста, не успешный N5 seal и не рекомендация просто чистить custody-state.
- `SelectionHistoryStore` с 1 000 / 10 000 / 50 000 records удерживал примерно 1,8 / 17,7 / 88,6 MB Python allocations. Getter без явно заданного predictor при каждом вызове создавал новый fitted predictor. Явное injection переиспользовало объект; `clear()` освобождал records. Persistence была отключена. Caller использует getter только при включённом runtime selection и отличающемся fallback, поэтому вывод не относится ко всем dispatch-вызовам.

Доказательство: соответствующие секции [scaling_results_v2.json](checkpoint_recovery/scaling_results_v2.json). Эти серии показывают владельцев и зависимость работы от объёма, но не устанавливают production p95, throughput, disk I/O, допустимую RAM или научную корректность.

### 4. Reuse: номинальная идентичность и численная семантика важнее похожего кода

**SYS-02 / прежний AUD-004:** exact-source replay подтвердил отдельные `LessonApplicability`/event-типы в `contracts.py` и `failure_lessons.py`. Свои значения принимаются, перекрёстные model instances отклоняются; явный dump/validate проходит. Публичный package экспортирует canonical contracts и отдельно facade. Это причина согласовать owner/адаптер, но не доказательство отказа реального downstream consumer. Pydantic здесь 2.13.4, вне repo-bound `>=2.12.5,<2.13`; native/locked replay остаётся необходимым.

**SYS-08:** 256 finite-сравнений каждого из двух local logsumexp kernels со SciPy дали расхождения не более 1,5×10⁻¹⁴. Это не drop-in equivalence: на infinity/empty inputs результаты/ошибки различаются. Известный factor-graph caller запрещает infinite inputs, поэтому такой kernel witness не объявлен доступным дефектом этого caller.

Для настоящего тела Ljung–Box метода один сохранённый набор из 30 конечных residuals дал p=0,0517748 со SciPy и p=0,0489166 при намеренно отключённом provider, то есть разные решения при α=0,05. Подтверждена зависимость решения от fallback policy. Это не оценка статистической ошибки на популяции и не доказательство ошибочной production-рекомендации; отсутствие SciPy внедрено только в namespace пробы.

Доказательства: [memory_identity_exact_results.json](checkpoint_recovery/memory_identity_exact_results.json), [numeric_adapter_results.json](checkpoint_recovery/numeric_adapter_results.json). Следующие проверки: поддерживаемый dependency profile, реальные consumers и явный contract допустимости approximate fallback.

### 5. Structure: конкретные import нарушения и предел mirror-проверок

**SYS-12, source-level подтверждение.** Из полного выбранного множества 75 shared helper `.py` (без `__init__.py`) 74 разобраны Python 3.12. Найдены **13 запрещённых reverse-import edges в 7 helpers**. Точный список file/line/module сохранён. `architecture/tests/ratchets.toml` запрещает эти test-layer imports, а настоящий report код считает наличие таких edges regression. Это прямое свидетельство нарушения контракта на разобранной части, **не результат запущенного native gate**. Один helper с Python 3.14 exception syntax остаётся unparsed, поэтому 13 нельзя выдавать за полный repo-total.

В выбранном каталоге 374 `tests/unit/*/mirror_contracts/test_*.py` файла; 372 используют static helper. Контроли показали: helper принимает функцию, одну assignment и один import, отклоняет docstring-only модуль. Он проверяет непустую структуру, как заявлено в его контракте, а не сохранность поведения. Эти файлы нельзя считать доказательством semantic coverage; при этом проверка не устанавливает отсутствие других поведенческих tests.

Доказательство: [structure_probes.json](checkpoint_recovery/structure_probes.json). Следующий шаг: родной Python 3.14 ratchet/pytest, уточнение consumers конкретных helpers и отдельный denominator semantic tests.

## Исправления измерительного инструмента и provenance

1. Исходная scaling-проба считала `_cache_built_at=0` заведомо холодным при TTL=3600. На runtime с uptime меньше часа это cache hit. В recovery fixture установлено `-inf`; продуктовый `refresh` не изменён. Затем обнаружен пропущенный `typing.Any` в namespace source extraction. Он добавлен в fixture. Все assertions сохранены; итоговый [probe_scaling_recovery_v2.py](checkpoint_recovery/probe_scaling_recovery_v2.py) завершился с exit 0. Предыдущие failures сохранены и не считаются product failures.
2. Structure-проба в найденной на диске версии уже исключала unparsed helper и явно записывала ошибку. Запущена эта версия с новым output directory. Неполный denominator не скрыт.
3. Все **39 архивных выборочных source-копий имеют ровно один лишний завершающий LF** относительно canonical snapshot. Они не byte-exact. Это полностью классифицировано в [COPY_PROVENANCE.json](checkpoint_recovery/COPY_PROVENANCE.json); копии не переписывались. Memory первоначально использовал такую копию, затем повторён на canonical bytes с тем же результатом. Остальные финальные probes читают canonical snapshot.
4. [SOURCE_VALIDATION_FINAL.json](checkpoint_recovery/SOURCE_VALIDATION_FINAL.json) сверяет hashes **471 уникального source-path**, использованного проверками/чтением, с закреплённым manifest; это не semantic review всех 29 934 файлов. Git status snapshot чистый. Начальная строгая проверка, обнаружившая отличия копий, также сохранена.

## Что не закрыто

- Python 3.14, locked Pydantic/providers, полные native suites/CI/typecheck и installed/distributed surface не проверены. Локальный профиль: Python 3.12.14, Pydantic 2.13.4, NumPy 2.3.5, SciPy 1.17.0.
- Нет full application, real registry revocation, live DB/RLS, deployed security/isolation, numerical production jobs, N5/E02 или нагрузочного эксперимента. Метод-level concurrency и tracemalloc нельзя повышать до таких claims.
- Remote main в этом recovery не перечитывался. Последняя сохранённая фиксация baseline относится к 2026-11-10 19:15:23 UTC; выводы привязаны к commit, а не к обещанию актуальности будущего HEAD.
- Полный source snapshot не является частью компактного checkpoint ZIP. Для повторения probes нужен соответствующий canonical checkout; manifest и конкретные source hashes сохранены. Известные старые findings не объявлены исправленными.

**Следующий разумный этап:** supported-profile replay worker shutdown, complete run lookup и native ratchet; затем реальные consumers memory/numerical fallback и достижимые scaling-сценарии. Рекомендации не применялись. Общая проверка системы остаётся открытой.
