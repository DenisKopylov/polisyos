# Где искать первичные доказательства: ZIP01–22

Полные checkpoint-пакеты остаются отдельными вложениями в Space. Найдите нужное точное имя ниже или используйте ранее доставленное вложение. Идентификатор Space является референсом, а не публичной ссылкой скачивания.

Чтобы проверить одну карточку: найдите её ID в едином отчёте или REGISTRY.json → evidence_sources.checkpoint/directory → нужный ZIP → REPORT_RU.md и raw results/probes соответствующей темы. Ограничения независимой проверки читайте вместе с авторским отчётом.

В текущем обзоре сохранены только необходимые копии связанного контекста, а не все первичные данные. [Машинные референсы и SHA-256](CHECKPOINT_REFERENCES.json).

## ZIP01

`PolicyOS_Deep_Audit_Checkpoint01_2026-11-10_f1541ed.zip`

Space ID: `libfile_5c81396a36748191b1143614fd676a91`. Размер: 4,852,295 bytes.
SHA-256: `adc07cea75dfd43eca5e2c6973f64383ac32cd5526bded58b42052b5b87dde50`.

Историческая базовая контрольная точка; её исходный состав сохранён в архиве.

## ZIP02

`PolicyOS_Deep_Audit_Checkpoint02_2026-11-10_f1541ed.zip`

Space ID: `libfile_2ccc431458508191bb6ee10cf73db271`. Размер: 5,292,425 bytes.
SHA-256: `e24220356e817e8cd4b1a389328b8e6a386cd20a047e400709eae0b2850390c7`.

Темы: `next_lifecycle`, `next_reuse`, `next_scaling`, `next_structure`.

## ZIP03

`PolicyOS_Deep_Audit_Checkpoint03_2026-11-10_f1541ed.zip`

Space ID: `libfile_3d539ac60d088191aa47732aa7da6d3b`. Размер: 4,593,078 bytes.
SHA-256: `e08f6676dc753a5ec19b163f8c502801d85b82e82720039ce7e9e56605992062`.

Темы: `next_auth`, `next_catalog_scale`, `next_freegrow`, `next_native`.

## ZIP04

`PolicyOS_Deep_Audit_Checkpoint04_2026-11-10_f1541ed.zip`

Space ID: `libfile_b23e508405d48191874aacc9f72e2efd`. Размер: 4,823,729 bytes.
SHA-256: `596f191ffbeb8349f894e35b8e66a5cddf4de9b97bc84fa34ff24f3afc7ac696`.

Темы: `next_library`, `next_review_state`, `next_state_owners`, `next_test_confidence`.

## ZIP05

`PolicyOS_Deep_Audit_Checkpoint05_2026-11-10_f1541ed.zip`

Space ID: `libfile_5c57165ab354819196a504f5a0c8728f`. Размер: 5,707,930 bytes.
SHA-256: `78bc1c7cc06569f55297c3ceffe6e33f98220561e0a565a5d822ec1b0d5382af`.

Темы: `next_directory_architecture`, `next_domain_composition`, `next_review_domain`, `next_review_storage`, `next_storage_scale`.

## ZIP06

`PolicyOS_Deep_Audit_Checkpoint06_2026-11-10_f1541ed.zip`

Space ID: `libfile_a5f920a9153081919d44a9a858f7b55a`. Размер: 5,261,729 bytes.
SHA-256: `486f56e7dcc4f6f34912e76505ca80636c3276087bf92562d833d750853a2449`.

Темы: `next_abstraction`, `next_budget_authority`, `next_coverage_status`, `next_graph_refresh`, `next_review_graph`.

## ZIP07

`PolicyOS_Deep_Audit_Checkpoint07_2026-11-10_f1541ed.zip`

Space ID: `libfile_b21fec7eba2c8191947e161e9aca6273`. Размер: 5,013,145 bytes.
SHA-256: `33e8decc6bb1c0e7f244c5d1c21e0805dca6169dfb87b3ee73995a33796c558d`.

Темы: `next_delivery_chain`, `next_evidence_composition`, `next_frontend_contracts`, `next_review_delivery`, `next_review_evidence`, `next_review_frontend`.

## ZIP08

`PolicyOS_Deep_Audit_Checkpoint08_2026-11-10_f1541ed.zip`

Space ID: `libfile_04684b85a6f081918022755035e3c831`. Размер: 7,777,414 bytes.
SHA-256: `2e555f6ab81440498a9c9bdf3fc44e4a21d51a3ff5b4c0df0db52b26808c12ba`.

Темы: `next_finalize_chain`, `next_n5_revoke`, `next_persisted_growth`, `next_review_finalize`, `next_review_growth`.

## ZIP09

`PolicyOS_Deep_Audit_Checkpoint09_2026-11-10_f1541ed.zip`

Space ID: `libfile_8ae0e7e18f988191a4e4ebb3477a5e93`. Размер: 4,615,361 bytes.
SHA-256: `092a539bb39c0d5de4435816425b21cbec67f1a596c420a6ad07b5a51c941d13`.

Темы: `next_publication_authority`, `next_registry_dataflow`, `next_review_publication_dataflow`.

## ZIP10

`PolicyOS_Deep_Audit_Checkpoint10_2026-11-10_f1541ed.zip`

Space ID: `libfile_64b2d2d02724819192a04edc94a19902`. Размер: 4,863,735 bytes.
SHA-256: `75376e09c588a590312e3512a13bab9cd9463d92a02e74da083e5dbcb7d5828f`.

Темы: `next_cross_service`, `next_review_cross_service`, `next_review_sql`, `next_sql_growth`.

## ZIP11

`PolicyOS_Deep_Audit_Checkpoint11_2026-11-10_f1541ed.zip`

Space ID: `libfile_3258670126188191acdede05d6792beb`. Размер: 4,819,796 bytes.
SHA-256: `e4b9b1348688ee7605da1f26b82aeca5421601285a73ebedae51ddc4e260dac5`.

Темы: `next_research_chain`, `next_review_research`.

## ZIP12

`PolicyOS_Deep_Audit_Checkpoint12_2026-11-10_f1541ed.zip`

Space ID: `libfile_3196825da12c8191ba6361e5b8962adf`. Размер: 7,191,144 bytes.
SHA-256: `cf1ca5ffc137b27eeb0f3a87855ecfae29074e71e9c350e0338076541482c319`.

Темы: `next_review_synthesis`, `next_source_adapters`.

## ZIP13

`PolicyOS_Deep_Audit_Checkpoint13_2026-11-11_f1541ed.zip`

Space ID: `libfile_e73c2aba5ed08191ab2d38515bbe2de6`. Размер: 8,130,818 bytes.
SHA-256: `fcf7049d724d00017920e34c39cc5c422448f0a65102d700372f1243f84a5dc3`.

Темы: `next_method_admission`, `next_review_method_replay`, `next_run_replay`.

## ZIP14

`PolicyOS_Deep_Audit_Checkpoint14_2026-11-11_f1541ed.zip`

Space ID: `libfile_8e4ea51795bc8191b278443aa6649fbb`. Размер: 4,856,730 bytes.
SHA-256: `97783bddd7147507abd07ab34c6cb4de952f575c5d41f14c68bb7d08c841ed67`.

Темы: `next_guard_enforcement`, `next_method_execution`, `next_review_guard_method`.

## ZIP15

`PolicyOS_Deep_Audit_Checkpoint15_2026-11-11_f1541ed.zip`

Space ID: `libfile_c7db1e4ffa68819185f696db5d1f08d8`. Размер: 4,592,193 bytes.
SHA-256: `5505e0eaf6f02cc1d90103544bf64d16bafbc7702c8a605f729c8b3157cfa863`.

Темы: `next_adapter_resilience`, `next_review_adapters_ui`, `next_ui_ownership`.

## ZIP16

`PolicyOS_Deep_Audit_Checkpoint16_2026-11-11_f1541ed.zip`

Space ID: `libfile_0c69fc8b7e448191b86c585d0ce417fb`. Размер: 4,875,173 bytes.
SHA-256: `6259554d8f8a5da360c51e3f0d11006c04477aa3c3aa84df737336113d2f7b1f`.

Темы: `next_decision_path`, `next_review_decision_custody`, `next_tenant_custody`.

## ZIP17

`PolicyOS_Deep_Audit_Checkpoint17_2026-11-11_f1541ed.zip`

Space ID: `libfile_7edb79aa82bc81918a8afc8686c664f7`. Размер: 6,603,447 bytes.
SHA-256: `beb3cc05081dc84d8819189275bb1d94eea19af6d789c051be724fd6da392ad8`.

Темы: `next_coverage_16`, `next_policy_assembly`, `next_review_policy_assembly`.

## ZIP18

`PolicyOS_Deep_Audit_Checkpoint18_2026-11-11_f1541ed.zip`

Space ID: `libfile_b649403300e88191a7ac2f69ca04ac19`. Размер: 5,717,075 bytes.
SHA-256: `90ddbedc3748b2c31c0c70538fd7c92ed92ee8fe4ad837621241896c827252a2`.

Темы: `next_execution_owner`, `next_governance_handoff`, `next_review_governance_execution`.

## ZIP19

`PolicyOS_Deep_Audit_Checkpoint19_2026-11-11_f1541ed.zip`

Space ID: `libfile_b5cf50adcf20819195043823a8d68cc3`. Размер: 4,589,868 bytes.
SHA-256: `e9e83edd0fa9dffce2562364ec76860be760115e4685ae1a676a1006838c8bcb`.

Темы: `next_remaining_custody`, `next_review_custody_history`.

## ZIP20

`PolicyOS_Deep_Audit_Checkpoint20_2026-11-11_f1541ed.zip`

Space ID: `libfile_d847af73bdc08191bafe0edad60f2727`. Размер: 5,300,896 bytes.
SHA-256: `3581da332e80a74b88ca4b5902305c3f1ea249db2b50a2e0140a57f51ed015bb`.

Темы: `next_review_scientific_integrity`, `next_scientific_integrity`.

## ZIP21

`PolicyOS_Deep_Audit_Checkpoint21_2026-11-11_f1541ed.zip`

Space ID: `libfile_9f2d663b017c81919d92082ae43aa9d7`. Размер: 5,199,422 bytes.
SHA-256: `af77dfa52c0fc32754ab5e497dfef8781a3328368224df29d0496eaf6beccd14`.

Темы: `next_calibration_reuse`, `next_data_service_tests`, `next_review_data_calibration`.

## ZIP22

`PolicyOS_Deep_Audit_Checkpoint22_2026-11-11_f1541ed.zip`

Space ID: `libfile_be2394d0c01081919137bfc754a1a5a1`. Размер: 4,602,359 bytes.
SHA-256: `6f540b9e92b4567202305a7506051c31f40ab12095df174061d962336953a8d8`.

Темы: `next_release_integrity`, `next_review_release`.
