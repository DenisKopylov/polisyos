#!/usr/bin/env python3
"""Read-only source-extracted scaling probes; synthetic isolated collaborators.
Run: python probe_scaling.py --source ../source --output results.json
No product imports, services, E02 execution, or source writes.
"""
from __future__ import annotations
import argparse, ast, collections, contextlib, dataclasses, gc, hashlib, json, math, os, pathlib, platform, statistics, sys, tempfile, threading, time, tracemalloc, types, uuid, weakref
from concurrent.futures import ThreadPoolExecutor
from typing import Any

P=argparse.ArgumentParser();P.add_argument('--source',type=pathlib.Path,required=True);P.add_argument('--output',type=pathlib.Path,required=True);ARGS=P.parse_args()
ROOT=ARGS.source.resolve()/'policy-engine/src/polisyos'
SOURCES={};EXTRACTS=[]
def load(path,names,env=None):
    raw=(ROOT/path).read_bytes(); tree=ast.parse(raw)
    SOURCES[path]=hashlib.sha256(raw).hexdigest()
    body=[]
    for node in tree.body:
        if isinstance(node,(ast.FunctionDef,ast.ClassDef)) and node.name in names:
            body.append(node);EXTRACTS.append({'path':path,'definition':node.name,'start':node.lineno,'end':node.end_lineno})
    assert {x.name for x in body}==set(names),(path,names)
    module=types.ModuleType('scaling_'+str(len(EXTRACTS)));sys.modules[module.__name__]=module
    module.__dict__.update(env or {})
    exec(compile(ast.fix_missing_locations(ast.Module(body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0)]+body,type_ignores=[])),str(ROOT/path),'exec'),module.__dict__)
    return module.__dict__
def method(path,owner,name,env=None):
    raw=(ROOT/path).read_bytes();tree=ast.parse(raw);SOURCES[path]=hashlib.sha256(raw).hexdigest()
    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==owner)
    node=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name==name)
    assert not node.decorator_list,(owner,name,'decorators must remain explicit')
    EXTRACTS.append({'path':path,'definition':owner+'.'+name,'start':node.lineno,'end':node.end_lineno})
    ns=dict(env or {});exec(compile(ast.fix_missing_locations(ast.Module(body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0),node],type_ignores=[])),str(ROOT/path),'exec'),ns)
    return ns[name]
def timed(fn,repeats=5):
    times=[]
    for _ in range(repeats):
        start=time.perf_counter();fn();times.append((time.perf_counter()-start)*1000)
    return {'median_ms':statistics.median(times),'min_ms':min(times),'max_ms':max(times),'samples_ms':times}

def limiter_churn():
    ns=load('runtime/http/mutation_policy.py',['RuntimeRateLimiter','_is_live_stream_path'],{'threading':threading,'_now_seconds':lambda:1.0})
    rows=[]
    for n in (1000,10000,50000):
        gc.collect();tracemalloc.start();base=tracemalloc.get_traced_memory()[0]
        r=ns['RuntimeRateLimiter']();t=time.perf_counter()
        for i in range(n):r.check_request(tenant_id='A',method='POST',path=f'/api/v1/control/jobs/job-{i}/cancel')
        elapsed=(time.perf_counter()-t)*1000;after=tracemalloc.get_traced_memory()[0]
        ns['_now_seconds']=lambda:1000000.0
        r.check_request(tenant_id='A',method='POST',path='/api/v1/control/jobs/job-0/cancel')
        gc.collect();idle=tracemalloc.get_traced_memory()[0]
        assert len(r._request_windows)==n
        rows.append({'paths':n,'retained_buckets_after_idle':len(r._request_windows),'traced_live_bytes':after-base,'traced_idle_bytes':idle-base,'write_loop_ms':elapsed})
        del r;gc.collect();tracemalloc.stop();ns['_now_seconds']=lambda:1.0
    # Control: normalized live paths remain a single key and release removes active key.
    r=ns['RuntimeRateLimiter'](live_limit=1001)
    for i in range(1000):r.check_request(tenant_id='A',method='GET',path=f'/api/v1/runs/{i}/live')
    assert len(r._request_windows)==1
    r.acquire_live_stream(tenant_id='A',path='/api/v1/runs/x/live');r.release_live_stream(tenant_id='A',path='/api/v1/runs/x/live')
    assert not r._active_live_streams
    return {'measurements':rows,'normalized_live_path_keys':len(r._request_windows),'active_keys_after_release':len(r._active_live_streams),'limit':'No OTel SDK; traces cover limiter objects, not production RSS. Only the synthetic revisited bucket ages timestamps.'}


def witness_retention():
    ns=load('runtime/quality/n5_execution_basis.py',['_ExecutedCode','_IssuedExecution','_ControllerExecutionObserver','_token'],{'dataclass':dataclasses.dataclass,'sys':sys,'types':types,'threading':threading,'uuid4':uuid.uuid4,'_OBJECTS':{},'_ISSUED':{},'_LOCK':threading.RLock()})
    work=types.ModuleType('scaling_payload');work.__dict__['weakref']=weakref
    exec('class Payload: pass\ndef run(size):\n    value = Payload()\n    value.data = bytearray(size)\n    return weakref.ref(value)\n',work.__dict__)
    # Execute publish from a function to avoid one frame-local variable keeping latest alive.
    def publish(i,size):
        observer=ns['_ControllerExecutionObserver']()
        with observer:ref=work.run(size)
        capture=types.SimpleNamespace(_observer=observer,_codes=observer.codes)
        ns['_ISSUED'][str(i)]=ns['_IssuedExecution'](witness=None,capture=capture)
        return ref
    rows=[]
    for n in (8,32,128):
        ns['_ISSUED'].clear();gc.collect();tracemalloc.start();base=tracemalloc.get_traced_memory()[0]
        refs=[publish(i,65536) for i in range(n)];gc.collect();held=tracemalloc.get_traced_memory()[0]-base
        alive=sum(x() is not None for x in refs);assert alive==n
        ns['_ISSUED'].clear();gc.collect();released=tracemalloc.get_traced_memory()[0]-base;after=sum(x() is not None for x in refs);assert after==0
        rows.append({'synthetic_issued_records':n,'payload_bytes_each':65536,'alive_with_owner':alive,'alive_after_owner_release':after,'traced_held_bytes':held,'traced_after_release_bytes':released});tracemalloc.stop()
    refs=[]
    for _ in range(1000):
        obj=work.Payload();refs.append(weakref.ref(obj));ns['_token'](obj)
    del obj;gc.collect();alive=sum(x() is not None for x in refs);assert alive==1000
    ns['_OBJECTS'].clear();gc.collect();after=sum(x() is not None for x in refs);assert after==0
    return {'measurements':rows,'distinct_token_objects':1000,'token_objects_held':alive,'token_objects_after_test_only_release':after,'limit':'Synthetic issued-record graph, not successful product seal or native N5. Clear is a test control, not a recommended product fix.'}


def validity_and_run_index():
    path='runtime/http/services/run_index.py'
    refresh=method(path,'RunIndexService','refresh',{'time':time})
    generation=method('scientist/validation/decision_validity.py','_DecisionValidityStateStore','current_projection_generation_ref',{'hashlib':hashlib})
    counts=collections.Counter()
    class CountingPath(type(pathlib.Path())):
        def read_bytes(self):
            data=super().read_bytes();counts['reads']+=1;counts['bytes']+=len(data);return data
    rows=[]
    with tempfile.TemporaryDirectory(prefix='policyos-validity-') as tmp:
        root=pathlib.Path(tmp)
        for n in (100,1000,5000):
            base=CountingPath(root/str(n));state=types.SimpleNamespace(_base=base)
            fields=('_packets','_epoch_pending','_epoch_receipts','_epoch_reconciliation_admissions')
            for field in fields:
                folder=base/field;folder.mkdir(parents=True);setattr(state,field,folder)
            for i in range(n):(getattr(state,fields[i%4])/f'{i:06}.json').write_bytes(b'{' + b' '*1022 + b'}')
            old=generation(state)
            service=types.SimpleNamespace(_decision_validity_service=types.SimpleNamespace(current_projection_generation_ref=lambda:generation(state)),_cache_decision_validity_generation_ref=old,_cache_built_at=time.monotonic(),_refresh_ttl_seconds=3600,_record_cache_staleness=lambda *a:None,_record_cache_event=lambda **kw:None,_refresh_index_incremental=lambda:(_ for _ in ()).throw(AssertionError('Unexpected rebuild')))
            counts.clear();t=timed(lambda:refresh(service))
            assert counts['reads']==5*n
            rows.append({'validity_files':n,'bytes_each':1024,'ttl_hits':5,'full_reads':counts['reads'],'bytes_read':counts['bytes'],**t})
            # Same-length byte change must invalidate, even with the TTL still active.
            (base/'_packets/000000.json').write_bytes(b'['+b' '*1022+b']');assert generation(state)!=old
    # Full catalogue default-cap boundary and alphabetical selection.
    helpers=load(path,['_iter_run_dirs','_parse_cursor','_as_utc','_run_sort_key'],{'UTC':__import__('datetime').UTC})
    rebuild=method(path,'RunIndexService','_refresh_index_incremental',{'_iter_run_dirs':helpers['_iter_run_dirs'],'_fingerprint_run_dir':lambda p:(1,1),'_register_artifact_tenants':lambda m,r:m.update({r.run_id:r.summary.tenant_id})})
    lookup=method(path,'RunIndexService','get_run')
    listing=method(path,'RunIndexService','list_runs',{**helpers,'CursorPage':lambda **kw:types.SimpleNamespace(**kw)})
    with tempfile.TemporaryDirectory(prefix='policyos-runs-') as tmp:
        root=pathlib.Path(tmp)
        for i in range(10001):(root/f'run-{i:05}').mkdir()
        def adapt(p):
            summary=types.SimpleNamespace(run_id=p.name,tenant_id='B' if p.name=='run-10000' else 'A',started_at=None,status='completed',source_kind='core_run')
            return types.SimpleNamespace(run_id=p.name,summary=summary,sort_mtime_ns=0)
        service=types.SimpleNamespace(_core_runs_root=root,_max_cached_runs=10000,_cache={},_dir_fingerprints={},_record_cache_event=lambda **kw:None,_adapt_core_run=adapt,_with_current_validity=lambda r:r,refresh=lambda:None)
        t=time.perf_counter();service._cache,service._artifact_tenants=rebuild(service);elapsed=(time.perf_counter()-t)*1000
        missed=False
        try:lookup(service,'run-10000')
        except KeyError:missed=True
        items,page=listing(service,tenant_id='B',limit=1)
        assert missed and page.total==0 and 'run-10000' not in service._artifact_tenants
        cap={'directories':10001,'default_cap':10000,'indexed':len(service._cache),'omitted_exists':(root/'run-10000').exists(),'omitted_exact_lookup_keyerror':missed,'omitted_tenant_list_total':page.total,'omitted_artifact_owner':True,'build_ms_synthetic_adapters':elapsed,'first':min(service._cache),'last':max(service._cache)}
    # Projection work precedes tenant/page filtering. Actual pending loop and enumeration,
    # synthetic evaluation/typed record loader (the latter still reads each real file).
    pending_path='scientist/validation/decision_validity.py'
    list_pending=method(pending_path,'_DecisionValidityStateStore','list_epoch_pending',{'EpochValidityPendingBatch':object})
    overlay=method(pending_path,'DecisionValidityService','_overlay_epoch_pending')
    amplification=[]
    with tempfile.TemporaryDirectory(prefix='policyos-pending-') as tmp:
        root=pathlib.Path(tmp)
        for n,p in ((100,10),(500,10),(500,100)):
            folder=root/f'{n}-{p}';folder.mkdir()
            for i in range(p):(folder/f'{i}.json').write_text('{}')
            counter=collections.Counter()
            def parse(path,typ):
                json.loads(path.read_text());counter['pending_file_loads']+=1
                return types.SimpleNamespace(targets=(types.SimpleNamespace(packet_ref='unrelated'),))
            state=types.SimpleNamespace(_epoch_pending=folder,_load_model_strict=parse)
            state.list_epoch_pending=lambda:list_pending(state)
            svc=types.SimpleNamespace(_state=state)
            def project(rec):
                counter['projections']+=1;overlay(svc,types.SimpleNamespace(decision_packet_ref=rec.run_id));return rec
            cache={str(i):types.SimpleNamespace(run_id=str(i),summary=types.SimpleNamespace(run_id=str(i),tenant_id='B' if i==0 else 'A',started_at=None,status='completed',source_kind='core_run'),sort_mtime_ns=0) for i in range(n)}
            service=types.SimpleNamespace(_cache=cache,_with_current_validity=project,refresh=lambda:None)
            start=time.perf_counter();items,page=listing(service,tenant_id='B',limit=1);elapsed=(time.perf_counter()-start)*1000
            assert len(items)==1 and counter['projections']==n and counter['pending_file_loads']==n*p
            amplification.append({'cached_runs':n,'pending_files':p,'requested_page_size':1,'matching_tenant_runs':1,**counter,'elapsed_ms':elapsed})
    # Force aligned independent callers at a cold refresh. All reach rebuild.
    barrier=threading.Barrier(4);calls=collections.Counter();lock=threading.Lock()
    def build():
        with lock:calls['rebuilds']+=1
        barrier.wait(timeout=5);return {},{}
    service=types.SimpleNamespace(_decision_validity_service=types.SimpleNamespace(current_projection_generation_ref=lambda:'fixed'),_cache_decision_validity_generation_ref='fixed',_cache_built_at=float("-inf"),_refresh_ttl_seconds=3600,_record_cache_staleness=lambda *a:None,_record_cache_event=lambda **kw:None,_record_cache_rebuild=lambda **kw:None,_refresh_index_incremental=build)
    with ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(lambda _:refresh(service),range(4)))
    assert calls['rebuilds']==4
    return {'ttl_series':rows,'same_length_content_change_invalidates':True,'default_capacity':cap,'pre_filter_pending_amplification':amplification,'concurrent_cold_refresh':{'callers':4,'rebuilds':calls['rebuilds']},'limit':'Exact methods with dummy run adapters and typed-model loader fixture. Cold refresh concurrency is method-level, not an HTTP scheduler reproduction.'}


def history_growth():
    import numpy as np
    import pydantic
    import logging
    env={'Any':Any,'np':np,'BaseModel':pydantic.BaseModel,'ConfigDict':pydantic.ConfigDict,'Field':pydantic.Field,'dataclass':dataclasses.dataclass,'threading':threading,'defaultdict':collections.defaultdict,'deque':collections.deque,'Path':pathlib.Path,'time':time,'math':math,'_MIN_FIT_RECORDS':5,'_MIN_METHOD_RESIDUAL_RECORDS':3,'_log':logging.getLogger('audit')}
    ns=load('foundry/methods/selection/history.py',['MethodExecutionRecord','SelectionHistoryPersistenceIssue','SelectionHistoryStore','RuntimePredictor','fit_runtime_predictor_from_history'],env)
    Store=ns['SelectionHistoryStore'];Record=ns['MethodExecutionRecord'];rows=[]
    getter=method('foundry/methods/backends/dispatch.py','MethodDispatcher','_get_runtime_predictor',ns)
    for n in (1000,10000,50000):
        gc.collect();tracemalloc.start();base=tracemalloc.get_traced_memory()[0]
        store=Store()
        for i in range(n):store.record(Record(method_fqn=f'method-{i%20}',timestamp=i,latency_ms=10+i%100,success=True,data_characteristics={'n_obs':100+i%1000,'n_features':1+i%10,'backend':'numpy'}))
        gc.collect();held=tracemalloc.get_traced_memory()[0]-base;tracemalloc.stop()
        service=types.SimpleNamespace(_runtime_predictor=None,_runtime_history=store)
        t=timed(lambda:getter(service),3)
        predictor=getter(service);assert predictor.is_fitted
        first=getter(service);second=getter(service);assert first is not second
        service._runtime_predictor=first;assert getter(service) is first
        refs=[weakref.ref(r) for r in store.all_records()];store.clear();gc.collect();assert all(r() is None for r in refs)
        rows.append({'records':n,'method_fqns':20,'traced_retained_bytes':held,'fit_each_call_ms':t,'same_history_new_predictor_each_call':True,'explicit_injection_reuses_instance':True,'clear_releases_all_records':True})
    return {'measurements':rows,'numpy':np.__version__,'pydantic':pydantic.__version__,'limit':'Actual record/store/predictor classes and exact dispatcher getter. Synthetic history, persistence disabled, numerical product jobs not run. Dispatcher calls getter only when runtime selection has a distinct fallback.'}

def main():
    result={'python':sys.version,'platform':platform.platform(),'scope':'Unchanged selected definitions, synthetic collaborators; no application load test or supported Python 3.14 qualification.','limiter_churn':limiter_churn(),'witness_retention':witness_retention(),'validity_and_run_index':validity_and_run_index(),'history_growth':history_growth()}
    result['sources']=SOURCES;result['extracted_definitions']=EXTRACTS
    ARGS.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
