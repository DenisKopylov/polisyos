# PolicyOS: крупные абстракции, параллельные реализации и владельцы поведения

**Bounded pass завершён; общий verdict — Partial.** Read-only baseline `f1541ed155f278689be48a8c7ac56c3e200210f7`, 10 ноября 2026. Это продолжение SYS-01/02/03, а не полный semantic audit 2 895 модулей и не выполненный рефакторинг. Исходники, tests, config, lock и внешние системы не менялись.

## Что делать в первую очередь

1. **Убрать повторное владение состоянием builder в Fabric.** `TransformPipeline` уже использует Core DAG, но заново реализует tail/branch/fork. Exact execution показало отличающийся failure contract: после исключения callback Core восстанавливает прежний tail, Fabric оставляет tail частичной ветки. При двух добавленных stages меняется также порядок компиляции следующей операции. Это конкретный, небольшой вход в консолидацию, а не повод строить новый pipeline framework.
2. **Согласовать общий контракт двух Scientist executors.** Sync/async — не только разные schedulers. Они повторно реализуют большие участки preflight и finalization; memory preparation и optional research-DAG projection сейчас не одинаковы. Для устранения дрейфа нужны existing domain owners и parity tests, а не перенос всего execution в Core DAG или LangGraph.
3. **Вывести legacy LangGraph bridge из обязательного runtime профиля, если совместимость это позволяет.** Во всём named Python source найден единственный прямой import `langgraph`, внутри legacy adapter; `langchain` imports не найдены. При этом обе библиотеки являются base dependencies. Внутренний production caller `LangGraphEngine` не найден. Это сильный кандидат на deprecation/optional dependency, но не доказательство отсутствия внешних клиентов.
4. **Не достраивать незадействованный asset framework без потребителя.** DataForge asset declarations, stage metadata и реальные batch pipelines — разные поверхности. `plan_asset_specs`, decorator и `MaterializationContext` не образуют исполняемый materialization engine. Сначала обозначить metadata/planning contract и решить судьбу малых неиспользуемых exports; не заменять ими content-bound batch orchestration.
5. **Сохранить состоявшееся переиспользование.** Governance уже делегирует Core LinearPipeline; registries уже опираются на GenericRegistry/BaseRegistry; SimpleLoopEngine реально исполняет N6 generation organs. Их одинаковые имена или тонкие фасады не доказывают ненужность.

Решения и acceptance matrix: `decisions.json`. Результаты probes: `results.json`. Полный именованный literal census: `symbol_census.json`. Source provenance: `source_validation.json` и `source_excerpts.json`.

## 1. Граница проверки

Прочитаны `AGENTS.md`, contributor contract, `next_directory_architecture`, `next_reuse`, `next_library` и предыдущий final synthesis/duplication inventory. Ранее установленные проблемы namespace aggregation, Runtime placement и DataForge read/build boundary здесь не посчитаны ещё раз.

Полный literal scan выполнен по трём отдельным знаменателям:

- `policy-engine/src/polisyos/**/*.py`: **2 895 файлов**;
- `policy-engine/tests/**/*.py`: **3 752 файла**;
- `policy-engine/tools/**/*.py`: **525 файлов**.

Каждый файл назван и сверён по SHA-256 с baseline manifest. Это census указанных символов, не полный resolved call graph. Он не включает `.pyi`, документы, notebooks, внешние plugins, generated runtime imports и downstream users. Отсутствие буквального упоминания не является доказательством отсутствия alias/dynamic/external use. В tests/tools counts нет заявления, что эти suites запускались.

Выполнены три bounded execution probes в Python **3.12.14**:

- Core/Fabric builder comparison через неизменённые definitions, реальные Core graphlib compilation и простые payloads;
- точный LangGraph adapter `step` против SimpleLoop `step` с synthetic stream provider;
- точные полные `_execute_admitted` methods обоих Scientist executors до intentional first-persistence sentinel, с явными dependency doubles.

Native product profile Python 3.14, installed package imports, полный CAS/run path, настоящий LangGraph, DataFrame transformations, pytest и production workload **UNRUN**. Source AST bodies не переписаны под другой синтаксис; выбранные тела разбираются на 3.12. Ни stubbed dependency, ни prefix reachability не выдаются за проверку её настоящей политики.

## 2. AB-01: частичная делегация DAG оставляет второго владельца mutable builder state

**Приоритет P2; локальная correctness/maintenance находка.** Высокая уверенность в воспроизведённом механизме; downstream incident и частота failure-recovery не установлены. Связь: SYS-02/03.

### Реальный состав подсистемы

`fabric/connectors/transform/pipeline.py:270–552 TransformPipeline`:

- хранит собственные `_stages`, `_tail`, `_auto_chain`, `_compiled`;
- создаёт `CoreDagPipeline(auto_chain=False)` (`285`);
- отдельно проверяет duplicate/dependencies, создаёт `TransformStage`, меняет tail (`292–337`);
- отдельно исполняет branch/fork/join (`344–386`);
- при `compile` получает порядок от Core и преобразует его в domain `CompiledPipeline` (`525–542`).

`core/pipeline/dag.py:70–213 DagPipeline` уже владеет stage store, dependencies, `_tail`, auto-chain, branch/fork/join и graphlib ordering. Это **одна Fabric подсистема с повторной реализацией части builder**, а не два полностью независимых transformation engines.

Реальный внешний вход: `fabric/ingestion/ingestion.py:425–458` выбирает allowlisted/trusted transform pipeline; identity provider создаёт настоящий TransformPipeline. Domain execution (`pipeline.py:575–672`) дополнительно обеспечивает validation, copy/row-growth policy, warnings, lineage, schema и telemetry. Эти обязанности не принадлежат Core DAG и должны остаться в Fabric. Выбранный штатный identity provider сам branch не вызывает; конкретный maintained consumer, который ловит branch failure и продолжает builder, не установлен.

### Отличающийся failure contract

Core `branch:153–168` восстанавливает `_tail` в `finally`. Fabric `branch:344–364` восстанавливает его только после успешного callback. Собственный docstring Fabric обещает временно заменить tail и затем восстановить original.

Probe использует root → callback добавляет 0, 1 либо 2 stages → callback succeeds/fails → caller после catch добавляет `after`:

- Успех с 1 и 2 stages: оба builders создают одинаковые dependencies/order.
- Исключение до добавления stage: различия нет.
- Исключение после 1 stage: Core `after.depends_on=[root]`, Fabric `[branch]`. Порядок в этом простом случае одинаков, поэтому только он не доказывал бы изменение transform results.
- Исключение после 2 stages: Core order `root, branch, after, branch_2`; Fabric `root, branch, branch_2, after`. Получено уже изменение executable order, не только внутреннего поля.

Оба сохраняют добавленные до исключения stages. Probe **не требует transactional rollback** и не утверждает, что Core откатывает частичную ветку. Проверена именно временная подмена branch tail. DataFrame effects не исполнялись.

### Migration и стоп-условия

1. Узкий безопасный repair: гарантировать восстановление tail на исключении; сохранение partial stages/exception object не менять молча.
2. Затем убрать повторное владение auto-chain/tail/branch у Fabric: делегировать существующему Core builder через callback adapter, сохранив domain TransformStage, fluent return `self`, stage names и TransformError mapping.
3. Не заменять одну строку на `self._graph.branch(...)`, пока Fabric `add_stage` всё ещё читает собственный `_tail`: это создаст ещё более неоднозначный split state.
4. Не делегировать Core actual DataFrame validation/lineage/row-growth semantics и не добавлять новый general pipeline class.

Acceptance: success/failure до и после добавления; nested branches; fork sibling failure; explicit depends_on и auto_chain=False; continued builder after caught error; cache invalidation после добавления; duplicate/missing error identity; compiled order и реальный некоммутативный DataFrame control. Ранее существующий `tests/unit/fabric/connectors/test_transform_pipeline.py` проверяет обычный порядок и execution; этот аудит его не запускал и не заявляет полного coverage census.

## 3. AB-02: два execution policies внутри Scientist, а не только два способа планирования

**Приоритет P2; подтверждённый contract drift / риск сопровождения, не доказанный authority bypass.** Source confidence high; full behavioral equivalence unresolved. Связь: SYS-01/02, возможный companion к SYS-05.

`engine/executor.py` содержит 2 698 строк, `async_executor.py` — 3 485. Эти **6 183 строки не названы 6 183 дублирующимися строками**. Async уже переиспользует DTOs и helpers из sync (`async_executor.py:63–96`), а retry, checkpoints, state branching/merge, idempotency и finalization models вынесены в existing modules. Полностью независимыми engines они не являются.

### Два фактических пути

1. `scientist/api.run_experiment` → workflow selection → `workflows/builder.run_default_workflow:939–1091` → при обычном local режиме `WorkflowExecutor.execute`.
2. Тот же default launcher при `budget_middleware` либо `capture_workflow_execution_admission` создаёт `LocalWorkflowRunner(max_parallelism=1)` → `runner/local_runner.py:53–100 execute_workflow` → `AsyncWorkflowExecutor.execute`.

Следовательно, parity по policy важна и для последовательного исполнения с parallelism=1. Это не только экспериментальная параллельность. Source route проверен; весь launcher и public HTTP path не запускались.

### Две конкретные асимметрии

**Preflight.** Sync `_execute_admitted:1237–1248` после input binding и required-binds вызывает `_ensure_memory_authority_for_serious_output`. Owner method `1121–1198` для research/governed/production выбирает/валидирует memory authority record, сохраняет его в state и emits event до выполнения nodes. Async `_execute_admitted:393–470` делает свой timeout/checkpoint budget, input binding и required-binds, но эту preparation не вызывает. Полный named source census находит вызов выбранного helper только в sync owner.

Exact-method prefix probe дошёл до первой `_persist_workflow_spec`:

- sync: input bind → required-binds → memory-authority seam → snapshot → persistence sentinel;
- async: required-binds → snapshot → persistence sentinel (snapshot input в fixture отсутствует, поэтому условный bind не требуется).

Это проверяет только последовательность calls. Memory policy заменена наблюдаемым seam; реальный admission, nodes, persisted record, event, public output и иные gates не исполнялись. **Нельзя делать вывод «async публикует неавторизованные claims».** Но ожидание, что scheduler backend не меняет подготовку evidence contract, не следует считать выполненным без отдельной проверки.

**Finalization.** Sync `2535–2605` при включённом flag для selected workflow строит и persist Research DAG, включает ref в final state и finalization output map. Async `1083–1127` формирует workflow-report-only output map и соответствующего sidecar hook не содержит. Selected set в `methods/research_dag/projections.py:31–37`: policy_design, policy_verified, causal_full. **scientist_default в него не входит**. Поэтому budget→async default path не является доказательством потери sidecar; это отдельная область parity для callers, которые реально допускают selected workflow через async backend. Такой end-to-end caller/fixture здесь не квалифицирован.

### Цель без нового framework

- В existing memory owner выделить общую preparation operation, сохраняющую domain record semantics; вызывать её до первой substantive state publication во всех поддерживаемых профилях либо явно отказать неподдерживаемому профилю.
- В existing `engine/finalization.py` согласовать общий typed plan выбранных final-state outputs. Sync/async сохраняют собственные I/O adapters и deadline/publication guards. Решение о research sidecar принадлежит Scientist, не generic scheduler.
- Не объединять whole execution loops вслепую: async владеет physical reader pins, cancellation, deadlines, parallel merge, atomic tier checkpoint и неизвестным outcome уже начатого I/O. Sync-only common helper нельзя считать безопасным async adapter только потому, что результат одинакового типа.
- Не подменять program admission, invocation settlement или budget ownership Core Pipeline, LangGraph, Temporal/Ray protocol. Эти controls относятся к domain execution authority.

Acceptance matrix должна сравнивать **обещанные одинаковые policies**, а отличия фиксировать явно: native typed state; memory absent/present/malformed/cross-tenant; serious и candidate profiles; zero/one/multiple nodes; enabled/disabled sidecar в selected/nonselected workflow; actual fresh CAS reopen; final state/report/finalization closure; cancelled/expired before и after I/O; current invocation and budget unknown; deterministic serial run на обоих backends. Existing sync tests `test_engine_executor_v0.py:342+` и `test_research_dag_workflow_producer.py:61+` дают пригодные starting fixtures, но здесь не запускались.

## 4. AB-03: legacy engine adapter и обязательный библиотечный стек

**Приоритет P3; сильный cleanup/dependency кандидат.** Не production incident, не automatic deletion permission. Связь: SYS-01/03.

`workflows/engine_base.py` определяет legacy protocol `run/step/current_phase/current_node/reset`. `engine_langgraph.py:12–94` — тонкий bridge поверх supplied compiled graph. Default legacy builder уже удалён: `from_existing_workflow` и factory без callback явно отказывают. Public lazy `workflows/__init__.py` продолжает экспортировать классы.

Полный Python census:

- `LangGraphEngine`: source hits только в owner и lazy facade; tests и tools hits отсутствуют.
- прямой `langgraph` import: 1 source file, `engine_langgraph.py:7`;
- `langchain`: буквальные Python source/tests/tools hits отсутствуют.

При этом `pyproject.toml:41–43` включает **обе** зависимости в base install. Lock: langchain 1.2.0 зависит от langgraph; langgraph 1.0.5 тянет core/checkpoint/prebuilt/sdk. Удаление одной direct строки `langgraph` не уберёт его, пока base langchain остаётся. Полный эксклюзивный dependency closure, экономия disk/RSS и install latency не измерены; не обещать removal savings из этого списка.

### Protocol называет разные действия одинаково

SimpleLoop `step` вызывает одну node и продвигает index. LangGraph adapter `step:35–59` материализует **весь** `list(graph.stream(state))`, берёт последний event и накладывает только его node state на исходный state. Он не хранит stream cursor.

С synthetic graph, который emits `{a:{a:1}}`, затем `{pack_decision:{b:2}}`, точный adapter:

- первый step исполняет оба provider effects, возвращает `{b:2}`, terminal=True;
- второй step снова вызывает оба effects;
- SimpleLoop после первого step исполняет одну node, возвращает `{a:1}`, terminal=False.

Это local adapter semantics, **не выполненный LangGraph integration test**. Допустимые stream modes/configurations реальной locked библиотеки не проверены. Но общий protocol сам по себе не делает реализации взаимозаменяемыми и не является основанием перенаправить governed execution на bridge.

### Решение

Определить нужность legacy API по downstream/import-contract сведениям. Если поддержка нужна, оставить thin compatibility bridge в явно optional legacy profile и назвать full-stream semantics честно; не называть его single-step interchangeable runner. Если не нужна, провести deprecation через существующий public-surface/shim contract и только затем убрать exports/dependencies. Сначала installed import и supported LangGraph version test, затем clean minimal/runtime environment test без этих packages. Не устанавливать ещё один orchestration package ради удаления adapter.

## 5. AB-04: DataForge asset layer — metadata scaffold, не второй production executor

**Приоритет P3; архитектурная ясность, не функциональный outage.** Связь: SYS-01/02.

Selected surface:

- `kernel/pipeline/assets.py`: AssetKey/AssetSpec/AssetGroup;
- `materialize.py:22–69`: context, definition и decorator, который только прикрепляет `__data_forge_asset__` к callable;
- `materialize.py:72–96`: dependency order planner;
- domain `assets.py`, academic `batch_assets.py`, catalog `source_modules.py`: static / source-specific metadata projections;
- root/read_api exports для этих contracts.

По полному named Python census `plan_asset_specs` в source встречается в implementation и двух facade files, а real calls находятся в tests. `MaterializationContext` — definition/exports плюс availability test; `__data_forge_asset__` — assignment и один test assertion. Не найден first-party source consumer, который открывает attached materializer и выполняет его. Это не глобальное доказательство dead code.

**Рабочий Catalog producer путь другой:** `run_dataset_pipeline:1352` → `_run_dataset_pipeline_with_profile_snapshot:1364–1560` → explicit harvest/normalize/merge/graph/core-sources/embed/benchmark/QC/publish operations. Он владеет content receipts, source-profile snapshot, resume checks и telemetry. Особенно load-bearing `1486–1500`: graph receipts откладываются до завершения нескольких writers одного DuckDB artifact. Dependency-only asset planner этот контракт не выражает и не заменяет.

Metadata surfaces не бесполезны автоматически: Catalog source module spec строит source stages, globs, schema IDs и asset keys из canonical registry view; это возможная audit/planning projection. Нельзя назвать весь `kernel.pipeline` неиспользуемым: рядом находятся реально shared manifest helpers, а имена совпадают с namespace этих contracts.

### Решение

1. Сохранить useful typed metadata и обозначить её metadata-only/candidate planning статус. Derive projections from existing canonical configuration там, где это уже возможно; не поддерживать вручную второй независимый список executable stages.
2. Для decorator/context/export без найденного consumer: выбрать deprecation/freeze либо конкретный пользовательский сценарий. Не достраивать scheduler, executor и new asset registry только ради обоснования существующих типов.
3. Если planner нужен только tests/readout, держать простым; recursive/topological kernel не оправдывает новую инфраструктуру. Замена на Core DAG/graphlib должна отдельно сохранить order, duplicate-key, missing-dependency и cycle error contracts; они не квалифицированы как drop-in в этом pass.
4. Если когда-нибудь actual batch будет driven by declarations, это отдельная migration существующего batch owner: receipts, shared-file writers, snapshot commit, source selection и resume refusal должны быть частью executable contract, а не внешними checklist assertions.

Acceptance: inventory поддерживаемых exported APIs и downstream consumers; schemas/asset identity unchanged; declared-to-actual stage mapping с negative missing/extra stage; shared DuckDB writer order и deferred receipts; resume after modified input/output; native domain pipeline→manifest→read-api path. Не считать presence decorator успешным materialization.

## 6. Что не следует консолидировать по имени

### Registries: storage уже общее, semantic owners разные

`MethodRegistry` → `_MethodEntryStore(BaseRegistry)` (`selection/registry.py:327–348,423,549`) → `GenericRegistry`. ComponentRegistry также наследует BaseRegistry; NodeRegistry также наследует BaseRegistry, но поверх storage проверяет node kind/capability и conflict между версиями. Bootstrap NodeRegistry использует ComponentRegistry как discovery staging, а затем domain admission (`engine/registry.py:139+`).

Поэтому нет основания создавать ещё UniversalRegistry или заменять Foundry MethodRegistry целиком ComponentRegistry. Foundry сохраняет method signature/slots, lazy factories, lifecycle, scope и version policy; Scientist — admissible Node contract. Двойной registry объект на discovery path не значит два authoritative catalogs. Core indexer/hook exception safety из прежнего SYS-03 остаётся prerequisite перед расширением reuse; этот pass его не переквалифицирует.

### Pipelines: полезные адаптеры остаются

- `scientist/governance/pipeline.py:103,121–154`: LinearPipeline уже отвечает за stage selection/iteration; domain owner добавляет pass cost order, issue severity, blockers и trace. Это настоящее reuse, не лишний универсальный validation framework.
- Fabric reuse: оставить domain transformation execution; AB-01 касается именно второго mutable builder owner.
- Scientist: Core DAG/LinearPipeline не выражают run leases, admission, checkpoint lineage, unknown provider outcome, typed writes и finalization custody. Замена whole executor на них уменьшит код ценой потери контракта.
- `SimpleLoopEngine` не мёртвый legacy слой. N6 `generation_cycle.py:11363–11371` задаёт generate→ground→joint_value→revise; `_run_cycle:13130` await-ит `run_async`, а controller сохраняет typed partial failure и source custody. Его docstring tests/prototypes не описывает все текущие consumers. Исполнительный цикл мал и переиспользуем; превращать его в полномасштабный Scientist workflow engine не нужно.

### Папки не равны подсистемам

Runtime HTTP/control, Quality orchestration и DataForge read/build placement уже разобраны в `next_directory_architecture`. Тонкие lazy aliases/IR-owned layout/CaseInspectionService не требуют новых owners. Packet/API namespace broadcasts нуждаются в explicit export contracts, но это не ещё один engine. Настоящая экономия здесь достигается устранением повторного состояния и согласованием domain policy, а не плоским деревом или сокращением числа классов.

## 7. Порядок работы и доказательства завершения

1. **Fabric branch lifetime**: маленький correctness repair + mirrored tests; затем единственный builder owner при сохранении public facade.
2. **Scientist backend parity**: native matrix и owner decision об обязательных policies. Только затем shared preflight/finalization operations; schedules/I/O lifetime пока отдельно.
3. **Legacy dependency boundary**: downstream compatibility + installed import; optionalize/deprecate только с verified package profile.
4. **DataForge declarations**: freeze новые абстракции, clarify projection role, удалить только confirmed unused public layers через существующую migration процедуру.

Ни одно решение не требует нового registry/cache/orchestration framework. Порядок `wire-existing → extend-existing → consolidate-existing → build-new` здесь даёт меньший риск, чем единовременная унификация.

Команда replay: `PYTHONDONTWRITEBYTECODE=1 python policyos_deep_audit/next_abstraction/probe_abstraction.py`. Финальный exit 0, stderr пуст. Исходный запуск остановился на неверном имени audit module для stdlib dataclass; это ошибка измерителя, не продукта. Исправлен только instrumentation namespace, сохранены `instrument_initial.*`; затем выполнен полный replay с дополнительными branch controls.

Source validation привязана к immutable baseline. Hash census не означает semantic verification всех файлов. Known unsupported/unrun areas: native Python 3.14, public facade imports, lock-installed LangGraph, full paired executors, actual DataFrame branch-failure consumer, external API consumers, production workloads и dependency-removal savings.

Pattern pass: P27/P31 — canonical owner вместо нового framework и второго mutable state; P33 — success/failure и 0/1/2 stage variants; P35 — три named full denominators; P38 — class name/Protocol/AST overlap не заменяет behavior equivalence. Declared asset graph и generic runner не становятся evidence/custody authority из-за своего названия.
