# PolicyOS: устойчивость REST-адаптера и границы версий

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Исходники read-only. Это новый путь после `next_source_adapters`: production `RestJsonConnector` → полный `GenericRESTConnector.fetch` → реальные shared retry/circuit/rate owners → bounded response reader / PII scan → typed `FetchResult` → настоящий ingestion `_sync_fetch`. Сеть и внешние эффекты запрещены и не использовались.

**Итог: PARTIAL; три bounded finding.** Исполнены 35 сценариев REST transport/fetch/health и прямой контроль core retry, затем три ошибки через настоящий sync bridge. HTTP session/response и registry acquisition/release синтетические; тела fetch, retry, byte reader, PII scanner, DTO и sync bridge исходные. Native import не проходит в доступном Python 3.12; полный batch/CAS/workspace не выполнен. Поэтому это не qualification production endpoints и не publication bypass.

## Главные результаты

### AR-01. Request-level запрет retry и connection retry budget теряются перед page transport

**P2 / medium, высокая уверенность для выбранного adapter path.**

- `FetchRequest(retryable=False)` + `ConnectionConfig(max_retries=1, retry_delay_seconds=0.01)` + scripted 503→200: fetch успешно возвращает данные после **двух GET**, с рассчитанной паузой 1.0 s.
- Пять 503 при том же connection budget: **пять GET**, `RetryExhaustedError(attempts=5)`, паузы **1, 2, 4, 8 s**, суммарно 15 s. Паузы записаны и заменены instant sleep: это вычисленный envelope, не измеренная задержка сети.
- Различающий контроль: настоящий `core.resilience.RetryPolicy.execute`, которому передан тот же `FetchRequest(retryable=False)`, делает **одну** попытку.
- Нормальные 400/401/403/404/422 и cancellation не повторяются. Повтор transient GET сам по себе нормален; дефект именно в утрате явного veto и конфигурации.

Механизм: `reference/rest_json.py:470–477` передаёт внутреннему page callable только handle/session/url/params/headers, не `request`; `628–638` фиксирует `with_retry(max_attempts=5, base_delay=1.0)`. Shared owner `core/resilience/retry.py:103–117,227–244` умеет уважать request veto, но внутренний вызов уже его не содержит. Config knobs существуют в `base.py:297–308` и заполняются из profile (`profiles/resolver.py:17–42`). Не требуется спор, значит ли max_retries «повторы» или «все попытки»: значение 1 не объясняет пять попыток.

Reach: это не только reference example. `sources/rest_json.py:24–76` наследует всю реализацию без override, а `components.py:101–151` включает её в builtin loader. Ingestion переносит manifest.retryable в настоящий `FetchRequest` (`ingestion.py:1293–1303`). Optional outer registry resilience не отменяет retries, уже выполненные внутри page helper; builtin metadata сама не задаёт outer policy. Полный registry/pool/bootstrap не запускался.

Практический ущерб: caller не может надёжно ограничить число обращений/ожидание/квоту выбранного REST source. **Дублирование write/mutation не установлено:** выбранный adapter делает GET; платежей, POST, мутаций или реальных provider calls здесь не было. Следующий owner-level acceptance должен передавать явный per-invocation attempt policy до нижней transport границы, а не добавлять ещё один decorator снаружи.

### AR-02. Validator одной страницы превращается в версию всего объединённого результата

**P2 / medium, высокая уверенность в поведении; reach до production refresh не установлен.**

Две data-bearing страницы и пустая terminal page. Первая возвращает ETag (либо Last-Modified), вторая не содержит validator. В повторном fetch первая неизменна, строка второй меняется с id=2 на id=3.

- `content_hash` полного полученного потока меняется.
- Итоговый ETag/value либо timestamp/value остаётся от первой страницы.
- Настоящий `DataVersion.is_newer_than` возвращает **false** при изменившихся raw bytes.
- При Last-Modified `source_updated_at` также остаётся первой датой, хотя для второй страницы время не установлено.
- Сериализация полного `FetchResult` в audit-owned JSON и перечитывание отдельным процессом сохраняют результат. Это **не CAS persistence**.
- Важный контроль: два разных явно заданных ETag или Last-Modified корректно переключают результат на CONTENT_HASH. Полное отсутствие validators тоже корректно использует CONTENT_HASH.

Механизм: `reference/rest_json.py:482–498` сравнивает только присутствующие headers; отсутствие не делает агрегатный validator неполным. `552–580,598–626` выбирает его для всего `FetchResult`. `ir/connectors/__init__.py:117–139` для одинакового ETag/timestamp не сравнивает content_hash.

Инвариант: HTTP representation validator относится к selected representation; multi-page aggregate требует отдельного подтверждённого правила scope. Provider может специально гарантировать dataset-wide watermark на первой странице, но такой договор должен быть явным. Generic adapter не может переносить это предположение на любой endpoint. Не следует объявлять все ETag «небезопасными» или заставлять сравнивать произвольные page ETag как одну dataset revision.

Направление: по умолчанию aggregate content hash; иная стратегия только при typed provider contract, который устанавливает область validator для всего результата. Сохранить точные page witnesses и явно неизвестные freshness роли. Не менять глобально `DataVersion` без анализа callers. В census прямых `.is_newer_than` REST refresh consumer не обнаружен: поэтому **не заявляем доказанную потерю cache invalidation, данных или защищённой authority**.

### AR-03. Transient exhaustion и malformed rate-limit metadata не сохраняют fetch-error boundary

**P2 / medium, высокая уверенность для exception propagation; полный batch outcome source-traced.**

- 429 + корректный `Retry-After=2`, `X-RateLimit-Remaining=0`: одна повторная попытка, успешный результат, запланированная пауза 2 s.
- 429 + `X-RateLimit-Remaining=unknown`: после первой попытки **ValueError**, не `RateLimitError`/`FetchError`; retry не происходит.
- Причина: `reference/rest_json.py:664–673` сначала безопасно ловит invalid integer, но `676` повторно вызывает незащищённый `int(...)` при создании `RateLimitError`.
- Пять 503: **RetryExhaustedError**, исходный `FetchError` сохранён в `original_error`, но внешний exception им не является.
- Настоящие `ingestion._sync_fetch` и native `common.async_tools.run_coro_sync` пропускают эти два типа без нормализации. Контроль 404 возвращает `FetchError`. Во всех трёх сценариях acquisition/release synthetic registry выполнены **ровно один раз**, включая ошибки.
- Реальный batch caller ловит только `FetchError` в режиме `continue_on_fetch_error` (`ingestion.py:1333–1355`); orchestrated incremental mode включает этот флаг (`data_plane/modes.py:954–968`). Для этих типов handler не подходит. **Сам batch с реальными storage/cache/record-replay admission не запускался**, поэтому operational reach этой ветки не объявляется закрытым.

Направление: нормализовать boundary ошибки в одном adapter/ingestion owner, сохранив исходный cause/status/attempt count и не превращая programming/security/admission failures в «можно продолжать». Один shared `safe_int` уже есть в `sources/http_common.py`; duplicate parse нужно убрать, а не изобретать новый error stack. Core `RetryExhaustedError` может оставаться generic: typed translation принадлежит boundary.

## Что действительно отказывает

В `results.json` сохранены исходные requests, точное число GET, ошибки, delays и typed results.

- 400, 401, 403, 404, 422: один GET, без retry.
- Cancellation: одна попытка, `CancelledError` не превращён в success/retry.
- Invalid JSON, missing data path и non-object row: отказ без возврата частичных данных.
- HTTP byte ceiling, JSON ceiling, огромный declared Content-Length, max_rows, max_pages: отказ. Declared-length контроль срабатывает до чтения; chunked reader действительно исполняется, response.read не заменён готовым accepted object.
- Повтор cursor: отказ на второй странице.
- Успешная первая страница, затем 404: итоговый `FetchResult` не возвращён.
- Реальный secret/PII scanner блокирует synthetic email в body; scanner не подменён success-stub.
- Retry-After=inf: отказ как FetchError, не бесконечное ожидание.

Небольшие observations, не дополнительные findings: health check возвращает `healthy=False` после одного 503/timeout, поскольку его тело преобразует ошибки в status до decorators. Успешный retry не заполняет `FetchResult.resilience` и failed-attempt bytes не входят в success bytes_transferred: это граница observability, не доказательство нарушения квоты. Per-page bounds не равны общему byte/time budget всего multi-page fetch; крупный memory/throughput benchmark не запускался.

## Callers, versions и supported versus unqualified

1. **Public facade:** `architecture/public_surface/contract.toml:249–268` классифицирует `polisyos.fabric` как public_stable и перечисляет connectors entrypoint. Это не обещание native readiness каждого provider profile.
2. **Extension ABI:** `architecture/extension_points.toml:118–140` задаёт group `polisyos.fabric_connectors`, contract_version=1.0, semver-major, builtin loader и installed-provider verifier. Сам реестр в этом snapshot помечен contract_only. Entry-point wheel/origin verifier в данной среде не запускался.
3. **Production adapter:** RestJsonConnector явно production wrapper, builtin registration source-traced. Имя `reference` у родителя не делает исполняемое тело автоматически experimental.
4. **Profile:** настоящий SourceProfile + resolver исполнены для `open_meteo`; profile fingerprint создан штатно. Profile docstring прямо говорит, что это declarative source description, не hard execution guarantee. Profile URL/headers присутствуют, live API/schema/auth не проверялись.
5. **SourceContract/replay:** source-platform перечисляет rest.json.generic, batch_atomic, open_meteo и replay fixture. Fixture имеет synthetic `rows:[{source_contract_id:...}]`, а профиль требует data path `hourly`. При подаче именно его body настоящему fetch получается FetchError. Это **не доказательство дефекта live Open-Meteo API**: normalized fixture не обязан быть raw transport replay. Но его наличие не квалифицирует реальную profile→HTTP→row adapter цепочку. Source-platform также явно отмечает, что inventory counts не доказывают readiness.
6. **Governed schema contract:** builtin `_contracts/__init__.py` не включает REST schema contract. Fetch пишет schema_version=1.0.0. Это crosswalk к SA-02, не повторно посчитанный finding.
7. **Workspace authority:** `runtime/quality/adapter_contracts.py:386–389,505–543` явно включает rest.json в WORKSPACE_FAIL_CLOSED_CONNECTORS, а execution-ready набор ограничен WorldBank aliases. Этот защитный барьер не запускался в probe, но точный source branch сохранён. Ни successful direct fetch, ни production metadata не доказывают workspace execution admission.
8. **Catalog:** normalizer/knowledge/read_api умеют объявить rest.json distribution/parser support; это discovery/description, а не доказательство, что provider transport или scientific binding выполнились.

Четыре независимых identity roles нельзя смешивать: plugin ABI version, connector metadata version, schema_version и DataVersion. SourceProfile fingerprint и raw content_hash добавляют content binding, но не сами устанавливают schema compatibility или область provider watermark.

## Reuse и стандартные библиотеки

**Wire-existing → extend-existing, без нового universal adapter.**

- Retry уже централизован в `core.resilience.retry`; Fabric retry модуль re-export. Он верно уважает veto при наличии request. Добавление Tenacity или нового per-adapter retry loop не лечит потерю request и создаёт ещё одну competing policy.
- Circuit breaker, token bucket и bounded resource registry уже shared owners, с locks/leases/cancellation. Они реально присутствуют в выполненной REST цепочке. Не заменять их простым глобальным dict/semaphore и не считать наш одиночный сценарий concurrency qualification.
- REST и HTTPConnectorBase используют общий `http_limits.read_bounded_response_body`, настоящий PII scan и typed result. Это удачное reuse. REST отдельно реализует retry composition, auth, header parsing и version aggregation; consolidating ниже уровня pagination возможно, но нельзя потерять REST CIMultiDict, cursor guards, headers, raw witnesses или observer hooks.
- `HTTPConnectorBase._retry_policy` уже читает connection knobs, а `_resilient_request_json` не принимает FetchRequest: sibling boundary следует проверить, прежде чем переносить REST на этот superclass. В текущем пакете это source-traced, не sibling execution.
- `aiohttp` уже declared runtime dependency; `multidict.CIMultiDict` сохраняет case-insensitive HTTP headers. `email.utils.parsedate_to_datetime`, `datetime`, `hashlib`, `json` и существующий canon owner достаточны для parsing/hash glue. `urllib3.Retry` относится к другой transport модели и не решает async cancellation, domain error contracts или aggregation scope. Не предлагается dependency migration без отличающихся acceptance tests.
- Domain semantics (page aggregation, schema/version, retry veto, authority admission, raw provenance) не передавать generic HTTP library. Малый canonical helper для полного aggregate validator или typed exception translation уместнее новой системы.

## Проверки и доказательства

- `PYTHONDONTWRITEBYTECODE=1 python next_adapter_resilience/probe_resilience.py`: exit 0, 35 transport/fetch/health/profile cases + core veto control, реальные source definitions через явные import bridges.
- `... probe_resilience.py --read`: exit 0, fresh-process DTO/version check.
- `... probe_callers.py`: exit 0, 3 sync bridge cases; actual native run_coro_sync, synthetic registry/session.
- Native `from polisyos.fabric.connectors.sources.rest_json import RestJsonConnector`: exit 1, Python 3.12 TypeVar(default=...) не поддерживается в `ir/kernel/units.py:24`. Supported baseline Python 3.14/Node22 не воспроизведён; Pydantic 2.13.4 вне repo baseline, packages не устанавливались.
- OpenTelemetry отсутствует; no-op tracing/metric collaborators явно заданы в audit harness. Initial missing-package failure сохранён. Вторичная ошибка harness `ConnectionHandle.id` исправлена на counter object identity; исходный failed output сохранён. Эти ошибки не посчитаны product findings.
- Socket audit hook отказывает connect/bind/getaddrinfo; network events пусты. Реальные HTTP sessions, DNS, auth credentials и endpoints не использовались.
- `SOURCE_VALIDATION.json` связывает использованные source/test/docs bytes с точным HEAD; `INPUT_MANIFEST.json` пинит prior artifacts и reused bootstrap; `caller_census.json` фиксирует полный ограниченный lexical denominator, не выдаёт search hits за runtime calls.

Не выполнены native pytest/CI, actual aiohttp wire/compression/redirect, concurrency/circuit recovery qualification, installed wheel, registry/pool lifecycle, actual CAS/DuckDB/cache persistence, record/replay admission, live endpoint schema, GraphQL mutations/POST retries, numeric/scientific validity, signatures, publication или capacity/SLA benchmark.

## Следующий bounded acceptance

1. Supported Python 3.14: native RestJsonConnector через production registry и exact profile. Case retryable=False с 503/429, connection max_retries=1, partial page failure и cancellation. Счётчик transport attempts обязателен.
2. Два data-bearing page witnesses с разным scope validator, включая missing metadata; producer→real cache/CAS→fresh consumer. Проверить, что content changes не выдаются за unchanged aggregate.
3. Batch из двух источников с `continue_on_fetch_error`: 404, exhausted503 и malformed429 должны дать заранее определённый typed outcome; admission/security error должен остаться terminal. Повторить при record/replay safeguards, не ослабляя их.
4. Actual provider-shaped replay для выбранного profile, а не проверка присутствия URL/headers. До этого supported facade, production adapter label, inventory/replay declaration и execution-ready статус остаются разными плоскостями.
