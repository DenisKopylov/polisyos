# PolicyOS: authorization, deployment и реальные владельцы изоляции

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`, tree `29890b967236a8f07e2b0f92a0133ee36883ac49`. Дата: 10 ноября 2026, UTC. Продолжение checkpoint01 и `next_lifecycle`. **Частичная проверка, без изменения продукта, production-доступа и запуска внешних операций.**

## Что добавлено к прежнему аудиту

1. **Новый конкретный разрыв canonical policy:** Python имеет 38 permissions, canonical Rego только 34. Отсутствуют `jobs.cancel` и три `sources.registered_sql.*`. Они действительно принадлежат действующим protected routes и deployment grants. Это не только прежний chart-local drift.
2. **Область отказа шире новых операций:** canonical Rego требует известности всех permissions principal. Добавление `jobs.cancel` к grant с `runs.launch`/`runs.view` нарушает необходимое условие и для launch, и для service-read. Это source-proven fail-closed разрыв интеграции. OPA engine/HTTP deployment не запускались.
3. **Подтверждён response-type gap:** настоящий `OPAClient.check` превращает `{"allow":"false"}` и `{"allow":[false]}` в ALLOW. Boolean false, отсутствующее поле и timeout дают DENY. Штатные прочитанные Rego modules возвращают boolean, поэтому это не доказанный обход пользователем, а отказ строгости на policy-response boundary.
4. **Подтверждены независимые защиты:** artifact route отвергает чужого/неизвестного owner; CAS owner predicates учитывают полные tenant, cell и manifest profile; cancellation scope отзывает authority после выхода, включая ранее скопированный ContextVar. Эти контроли не подменяют полный authenticated API/CAS/DB тест.
5. **Уточнены ownership planes:** HTTP tenant context, world-table PostgreSQL RLS, control-plane SQL admission и CAS ownership index являются разными механизмами. Миграция world RLS не является доказательством изоляции `control_jobs`, а Kubernetes namespace не заменяет tenant/cell guards.

Новый vocabulary drift относится к прежнему **SYS-10 / AUD-025**; chart inventory не считается новым независимым finding. Namespace-топология уточняет **SYS-09 / AUD-024**, а не доказывает произошедшую утечку. Локальные метки AUTH ниже служат указателями разделов, не новой независимой системой дефектов.

## Профиль доказательства

`probe_authorization_boundaries.py` выполнен, **exit 0**. Полный результат: `authorization_boundary_results.json`; stdout/stderr и exit сохранены. Это exact source-extracted definitions с явно синтетическими query/cache/metrics, request/index, nominal proof и DB recorder. Тела исполняемых решений не исправлялись. Нативные package imports, supported Python 3.14 и locked suite не заявляются.

Среда: Python 3.12.14. Нет OPA, Helm, psql, pytest, psycopg и DuckDB в обнаруженном профиле. Ничего не устанавливалось. `replay_policy_profiles.py` подготовил 8 одинаковых входов для canonical/chart profiles и завершился **exit 77, UNRUN**, поскольку OPA отсутствует. `policy_profile_results.json` не содержит измеренных policy decisions. Source-derived ожидания нельзя использовать как OPA PASS.

Продуктовое дерево read-only. Нет сетевых запросов, внешних providers, migrations, публикаций, E02/N5 jobs или чтения production state. Все новые файлы находятся в этом каталоге. `SOURCE_VALIDATION.json` сверяет конкретный readset с baseline manifest, не заявляет semantic review всего репозитория.

## AUTH-01: canonical permission projection отстаёт от реального сервера

**Приоритет P1 перед deployment с cancellation/registered SQL; высокая уверенность в расхождении, без заявления production incident.**

### Точная цепочка

- `runtime/http/permissions.py:16–56`: closed enum содержит 38 значений. Четыре новых permissions выделены как deployment-only в `tests/unit/runtime/http/test_runtime_permission_vocabulary.py:54–67`; их отсутствие в ordinary role grants **намеренно**, не отдельный дефект.
- `routes/control.py:151–159, 605–661`: `jobs.cancel` требуется для POST `/api/v1/control/jobs/{job_id}/cancel`; есть отдельный rollout flag и повторная проверка proof.
- `services/registered_sql_service.py:55–85`, `routes/registered_sql.py:92–209`: register/admit/withdraw имеют три точных permissions и resource classes. `DeploymentSecurityConfig._validate_unique_principals`, `deployment_security.py:281–300`, требует exact source-service grant для каждого SQL slot.
- `authorization.py:654–705`: managed deployment principal получает exact configured permissions, а не объединение с обычной ролью. Сначала Python проверяет required permission.
- `authz_middleware.py:125–199, 202–329`: projection передаёт весь canonical-sorted principal grant и authorization source; action envelope дополнительно несёт permission, resource class и binding authority.
- `ops/policy/policies/action_permission.rego:17–52` содержит 34 значения; четыре указанных permissions отсутствуют. Их resource contracts также отсутствуют.
- `action_permission.rego:204–209` требует `every permission ... in permission_vocabulary`. Это условие входит в action allow и service-read allow (`:231–240, 298–309`). Поэтому проблема не ограничена запросом неизвестного action.
- Middleware вызывает `_evaluate_opa(..., fail_closed=action_guarded)` (`authz_middleware.py:984–995`); deny для protected action останавливает запрос до handler. Это правильный fail-closed outcome при несовместимом pack, не повод обходить gate.

### Воспроизводимый discriminator

Исполнен исходный Python enum; exact literal Rego vocabulary извлечён без замены policy engine собственной моделью:

| Вход | Необходимое условие all-members-known |
|---|---|
| `runs.launch`, `runs.view` | true |
| Те же permissions + `jobs.cancel` | false |
| `sources.registered_sql.register` | false |

Разность ровно четыре значения. Добавление именно этой разности к временному множеству восстанавливает set equality. Это контроль измерителя, **не внесённое исправление** и не достаточная починка policy: нужны также exact resource contracts.

### Почему зелёный тест отдельного consumer недостаточен

`test_runtime_rego_authorization_parity.py:57–60, 143–152` смотрит только `ops/policy/policies`, требует `len(server_permissions) == 34` и равенство множеств. На этой базе count predicate ложно независимо от OPA. Сам pytest-тест здесь не запускался; это не свидетельство свежего hosted CI failure.

`test_control_job_cancellation_conflict.py:33–43` строит настоящий HTTP/store сценарий с `_AllowOPA()`. Его работа полезна для stale attempt/SQL conflict, но не проверяет совместимость новых grants с настоящим Rego. Совмещать эти две оси необходимо, заменять одну другой нельзя.

**Рекомендация:** сохранить deployment-only модель, обновить projection от того же server vocabulary и route binding contract; квалифицировать canonical и реально поставляемый pack одним behavioral suite. Не давать jobs.cancel обычной admin/service роли только ради устранения отказа.

**Acceptance:** один principal с `[runs.launch,runs.view,jobs.cancel]`: настоящий OPA допускает разрешённые launch/read/cancel при остальных guards, отказывает foreign tenant/cell/stale attempt/неразрешённому action; SQL slot проходит register/admit/withdraw только с exact grant и selected inputs. Removal любого permission/resource mapping вызывает красный тест. Native suite, current hosted gate и deployment replay остаются отдельными результатами.

## AUTH-02: factory attestation и shipped policy защищают разные объекты

Прежний факт подтверждён: canonical production modules 8, chart-local 7; отсутствует `action_permission.rego`, отличается `decision.rego`. Остальные шесть общих modules byte-equal. Хеши сохранены в JSON.

`templates/configmap-opa-policies.yaml:10–20` сначала выбирает `.Files.Glob "policies/*.rego"`; `Values.opa.policies` используется только если chart-local набор пуст. Обычная передача custom values поэтому не заменяет имеющийся pack. `README.md:41–45` признаёт canonical source и ручную синхронизацию перед release.

**Важное ограничение:** этот chart создаёт isolation primitives и ConfigMap. В его templates нет workload/OPA container/volume mount. Наличие ConfigMap не доказывает, какие bytes реально обслуживает OPA endpoint. Helm render и live endpoint не проверены.

`DeploymentOPAClient` (`deployment_security.py:453–497`) отключает decision cache и делает запрос через request-local session. Factory fingerprint (`:905–993`) включает URL/path/timeouts/cache identity; component registry повторно сверяет точные Python instances. Это реальные защиты от локальной recomposition, но **не attestation фактических Rego bytes на удалённом endpoint**.

`tools/devx/workspace/lint_full.py:134–160` выполняет strict syntax checks для Rego scope, а behavioral `opa test --fail-on-empty` только для canonical directory. `test_runtime_rego_authorization_parity.py` также фиксирует canonical directory. Синтаксическая корректность двух packs не устанавливает одинаковое решение.

Подготовленные, но ещё не исполненные OPA discriminators: viewer POST artifact batch, service GET run, service launch, тот же principal с cancel grant, cancel и registered SQL, foreign-tenant control. Source-reading predicts некоторые **ложные отказы** chart pack для допустимых canonical actions. Policy-only allow в старом pack не следует называть HTTP bypass: Python permission, sealed ownership, rollout, step-up и domain gates сохраняются.

**Направление:** один canonical producer policy pack, deterministic packaging и content identity для точного deployed bundle; проверять rendered ConfigMap и actual endpoint отдельно. Нельзя просто синхронизировать chart с нынешним canonical и объявить готовность: AUTH-01 остаётся.

## AUTH-03: неboolean allow становится разрешением

**Приоритет P2 hardening policy-response contract; высокая уверенность в механизме, ограниченная внешняя достижимость.**

`core/security/authz.py:311` использует `bool(payload.get("allow", False))`. `_query_opa` проверяет лишь, что `result` является dict (`:357–361`). Deployment subclass наследует `check` и также проверяет только dict shape (`deployment_security.py:480–497`).

Точное тело `check` исполнялось с синтетическим ответом query, без сети:

| `result.allow` | Измеренный outcome |
|---|---|
| true | ALLOW |
| false, null, отсутствует | DENY |
| `"false"`, `"deny"`, `[false]`, 1 | ALLOW |
| synthetic TimeoutError до ответа | DENY + OPA_UNREACHABLE |

Это нарушает описанную fail-closed shape semantics при неboolean decision. Но прочитанные canonical/chart policy definitions дают boolean. Не найден путь, позволяющий HTTP-клиенту самому задать response type, обойти attested URL или заменить Python collaborator. Поэтому из опыта **не следует remote exploit, обход authentication или обход Python ownership**. Текущая policy drift сама по себе не создаёт строковый `allow`.

**Направление:** strict boolean admission, явная typed contract ошибка для остальных значений; по возможности проверка всей response schema до выдачи `AuthzResult`. Native negative cases через настоящий OPA transport с malformed response; положительные boolean decisions сохранить. Trust-level policy bytes и parsing являются соседними, но разными checks.

## Реальные end-to-end границы и положительные контроли

### 1. Отмена job: Python → policy → control SQL

1. Verified JWT/access scope и current deployment principal grant.
2. Exact route permission `jobs.cancel`; binding читает job + immutable creation envelope и сверяет tenant/cell (`resource_binding.py:1164–1205`), связывает job ID, cell и cancellation body (`:1218–1241`).
3. Frozen action envelope → OPA. Здесь canonical drift блокирует новый permission.
4. Если внешняя policy корректна, handler требует exact `BoundActionPermissionVerification`, rollout flag, повторный `_authorize`; входит в `cancellation_request_scope`.
5. `ControlRunService.cancel_job`, `run_lifecycle.py:12748–12799`, сверяет exact job/body binding и передаёт proof, не произвольный tenant string.
6. `ControlPlaneStore.cancel_job:7161–7300+`: current request authority, exact type/permission, bound body, job/cell selectors; `_job_transaction(commit_admission=...)`; lock той же job row; повторное reconciliation creation envelope; expected owner/attempt, terminal retry identity; authority снова проверяется при commit.
7. Durable cancellation означает fencing publication, а не физический stop. Уже проверенные в `next_lifecycle` SQL lease/late-work controls не запускались заново.

**Новый bounded control:** `cancellation_request_scope` разрешает только exact proof; другой, хотя равный по полям экземпляр, не считается current authority. После exit current proof недействителен и в заранее скопированном ContextVar, поскольку общий Event очищен. Повторное использование consumed request отклоняется. Это exact gate body с synthetic nominal proof, **не** полный JWT/API/store cancellation replay.

### 2. Registered SQL: Python → policy → source owner → selected CAS contracts → connector

Route permission и request-composite binding предшествуют producer. `require_registered_sql_request` (`registered_sql_service.py:311–376`) сверяет live identity/slot, требует runtime ambient ownership, читает выбранные view/use/request refs из CAS в exact tenant/cell, проверяет provider/connector и повторяет identity после потенциально долгого I/O.

`RegisteredSQLLiveGrantVerifier.witness/verify` (`registered_sql_live_grant.py:153–365`) связывает served sealed proof, bearer hash, body bytes, verified claims, owner pin, slot/command, operation/event/predecessor; network-capable JWT verification происходит до source-owner transaction, commit fence проверяет уже созданный witness без сети/CAS. Это не произвольный caller-provided callback.

`routes/registered_sql.py:109–181` использует installed ConnectorRegistry, DefaultFabricPort и RegisteredSQLProducer; source act может коммититься независимо от дальнейшей отмены job. Это явно задокументированная отдельная authority, не повод повторять внешнее acquisition при unknown outcome. Реальные connector query/admission, DB и CAS publication здесь **UNRUN**.

### 3. Artifact read/batch: Python → policy → run owner → CAS owner/profile → bytes

`build_runtime_api_context` (`dependencies.py:100–145`) использует ambient ownership wrapper для route store, но отдельный base store для RunIndex. Это осознанно разные reader roles.

Artifact batch имеет `ARTIFACTS_BATCH_READ` и owned batch binding. Все проверенные artifact routes (`routes/artifacts.py`) дополнительно вызывают `enforce_artifact_tenant_access` до inspector. Guard (`dependencies.py:469–505`) устанавливает tenant из RunIndex, не из URL или payload.

Измерено: same tenant проходит; foreign tenant → `artifact_tenant_mismatch`; unknown owner → `artifact_tenant_unscoped`; только explicit `allow_unscoped_artifacts=True` пропускает неизвестного на **этом** уровне. Это не отключает следующий CAS owner guard и не доказывает чтение чужих bytes. Прежний bounded-index omission ведёт здесь к отказу/недоступности, не автоматически к утечке.

`FileSystemCAS` (`core/artifacts/store.py:1734–1861`) разрешает ambient tenant/cell и обращается к persisted ownership index. `_record_matches_owner` и `_record_matches_view_owner` (`ownership.py:575–601`) сравнивают tenant, полный cell и exact manifest profile; view claim не заменяет ambient artifact owner. Все перечисленные predicates имеют пройденные positive/foreign controls. Подпись ownership generation, filesystem races, whole CAS IO и public-read closure не воспроизводились этим probe.

### 4. DB: world RLS не является control-plane tenant owner

- `CellRouterMiddleware` (`cell_router_middleware.py:177–188`) устанавливает `tenant_scope(None, ...)`. Это ContextVars, **не автоматическая установка PostgreSQL session variable**.
- `core/security/db_backend.py:117–151` предлагает отдельный `PostgresBackend`: transaction owner, запрет tenant scope вне transaction, SET LOCAL/RESET, commit/rollback. Синтетический cursor подтвердил порядок и отказ вне transaction. Он **не проверил SQL-синтаксис драйвера, RLS либо pooled connection**.
- `ops/migrations/db/003_rls_enable.sql` включает ENABLE + FORCE RLS и USING + WITH CHECK для 16 именованных world/public tables. `004_roles_grants.sql` создаёт app role и не выдаёт SUPERUSER/BYPASSRLS. Однако существующие privilege bits реального role неизвестны; комментарий не доказывает их отсутствие.
- `fabric/world/query.py:486–504` отвергает backend без действительного advertised tenant-scope capability при tenant row policy; DuckDB snapshot не объявляется безопасным RLS backend. Query layer также компилирует row filters. `DuckDBStorageAdapter` является другой implementation: configured tenant column + scope stack; отсутствие configured column не следует считать PostgreSQL RLS.
- `ControlPlaneStore._postgres_cursor:10218–10233` напрямую открывает psycopg connection, не использует Core PostgresBackend. Его `control_jobs` schema (`:9515–9541`) не входит в перечисленные 16 RLS tables и хранит scope через creation evidence, а не dedicated tenant column. Tenant authorization здесь обеспечивается bound API/domain checks и exact transaction admission. Отсутствие world RLS на этой таблице само по себе не объявляется bypass.
- `test_rls_isolation.py` требует psycopg и `POLISYOS_TEST_PG_DSN`; отсутствие DSN даёт skip. `test_runtime_postgres_linearizability.py` проверяет другой storage contract и отдельный профиль. Ни один тест не запускался с живой БД.

**Следующий distinguishing acceptance:** actual limited app role, actual backend connection/transaction, foreign read/write, no-scope, scope switch, rollback, session reuse; отдельно control-plane foreign tenant/cell и commit admission. Не подменять эти tests наличием migration script или mock cursor.

## Cell namespace: условное topology-последствие, не новый exploit

Прежняя trunc8 collision не переизмерялась как новый finding. Дополнительно прослежены consumers: Helm fullname и namespace берут одинаковые первые 8 символов; `networkpolicy.yaml` разрешает internal traffic через `podSelector: {}` без cell label; RBAC Role/Binding namespace-local, default service-account name общий; labels сохраняют полный cell ID, но сами не являются enforcement.

**Если** два разных cell реально совместят в одном вычисленном namespace и workloads будут запущены там, этот namespace-wide allow не разделит их по полному ID. Но вторую Helm installation могут остановить ownership/resource collisions, chart не содержит workloads, mounts/token policy и live routing неизвестны. `automountServiceAccountToken: false`, default deny ingress/egress, restricted namespace labels и Python/CAS full-cell checks являются сохранёнными защитами.

Нельзя из trunc8 получить вывод «tenant B читает secrets A». Для этого потребовались бы actual installation/permissions/workload/credential conditions, которые не проверялись. Исправление должно сохранять full identity и existing-resource migration contract, не расширять RBAC и не отключать guards.

## Приоритетная последовательность без переписывания системы

1. До включения новых grants устранить server↔canonical projection gap с full contract tests. Исправление не выполнялось.
2. Связать canonical producer с shipped/rendered policy bytes; один набор behavioral cases должен исполняться для canonical, chart output и actual endpoint по отдельности.
3. Сделать policy response строго boolean и сохранить независимые Python/domain/CAS отказные gates.
4. Провести supported-profile targeted API/OPA/CAS и actual non-superuser DB qualification. Не начинать live acquisition или миграции в рамках этого аудита.
5. Namespace naming/migration остаётся отдельным уже известным решением, а не доводом заменить tenant guards одним deployment label.

## Повторение

Из корня рабочей области:

```sh
python3 policyos_deep_audit/next_auth/probe_authorization_boundaries.py
python3 policyos_deep_audit/next_auth/replay_policy_profiles.py
python3 policyos_deep_audit/next_auth/validate_evidence.py
```

Вторая команда требует уже установленный OPA и пока даёт 77/UNRUN. Она не разворачивает приложение и не обращается к endpoint. Для native tests необходимы supported Python/locks и изолированный разрешённый DB profile; выбор или создание такого профиля не выполнены. Deployment isolation, full authenticated endpoint behavior, engine-evaluated Rego, Helm render и current live authorization остаются **UNRUN**.
