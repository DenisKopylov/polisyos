# PolicyOS: budget unknown, late completion и N5 witness custody

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Дата: 10 ноября 2026. Source read-only. Статус: **PARTIAL**. Новое подтверждённое наблюдение: **BUD-01 / P2**, дополнение lifecycle ownership, не обход SQL authority и не доказанный перерасход.

## Главный результат

1. **Повторная cancellation direct LLM waiter теряет наблюдаемый поздний settlement.** В настоящих `TracedLLMClient.ainvoke()` и `generate()` первая отмена удерживает provider task и его live handle до известного результата; вторая отмена записывает terminal unknown и снимает live handle, пока provider ещё работает. После фактического возврата response с известной fixture-стоимостью 0.25 ledger остаётся unknown. Последующий attributed вызов того же run отказывает **до dispatch**, а known settlement того же event конфликтует с terminal unknown. Это консервативная блокировка и потеря accounting outcome, **не бесплатное повторное выполнение**.
2. **Реальный FileBudgetLedger переживает проверенные process-death и lost-ack границы.** Pending compute reservation остаётся занятым; смерть до публикации settlement оставляет reserved; после публикации оставляет settled. Reopen + exact settlement retry дважды дают единственное списание 0.4 и reserved=0. Unknown compute нельзя освободить legacy release.
3. **Разные budgets нельзя объединять.** N5 использует физические invocation units и `ProducerBudgetObserver`, а не priced `reserve_compute`. В полном текстовом census Python src имена reserve_compute/settle_compute/mark_compute_unknown встречаются только в budget_ledger.py. N5 явно отказывает `hard_total_usd` и `explicit_null`; mode `metered_paid_producers_and_bounded_candidate` не обещает денежную цену физического N5.
4. **N5 live witness не является автономным разрешением.** Его память process-local; source показывает отдельные content/live reconciliation и terminal native/SQL/PA2 fences. Публичный release/revoke lifecycle issued registry в просмотренном owner не найден. Полный actual N5 seal → revoke → retention test **не выполнен**: import упирается в Python3.14 syntax недоступного native profile. Нет доказательства, что удержанный witness позволяет публикацию после revocation. A5 нельзя объявлять закрытым.

## 1. BUD-01: second cancellation retires accounting owner before physical completion

**Severity P2, confidence high для direct client branch.** Локации: `core/llm/traced_client.py:1125–1150`, `:970–1005`, `:1152–1237`; `scientist/orchestration/engine/budget_middleware.py:361–370`; `budget_ledger.py:2360–2395`.

Реальный путь: public `ainvoke`/`generate` → durable begin → `_await_direct_provider` → `asyncio.create_task(provider)` и shield. Обработчик первой CancelledError выполняет второй shield. Повторная cancellation прерывает этот второй await, попадает в `except BaseException`, вызывает `_settle_unknown_provider_event`, затем выходит. `_persist_producer_event` в finally удаляет event из `_producer_intents_by_event` и вызывает `_finish_scoped_producer_attempt`. Не установлен отдельный completion callback, который довёл бы **этот direct provider task** до известного settlement независимо от дальнейших отмен waiter.

`budget_authority_results.json`, четыре варианта:

- ainvoke / 1 cancellation: waiter ещё жив, provider не завершён, live_handles=1, row=pending; после release: committed 0.25, original attempt=1, live_handles=0. Reopened observer допускает дальнейшую работу.
- generate / 1 cancellation: тот же результат.
- ainvoke / 2 cancellations: waiter done, provider ещё не завершён, live_handles=0, row=unknown. После provider.finished: amount=null, spent={}, row всё ещё unknown.
- generate / 2 cancellations: тот же результат.
- В обоих double-cancel вариантах actual reopened `ProducerBudgetObserver.admit` → `control_nl_budget_producer_event_not_settled`; следующий public attributed LLM call → `BudgetLedgerSettlementOutcomeUnknownError`, next_provider_calls=0. Попытка записать уже известный результат тем же event через real middleware → `producer event retry conflicts with prior outcome`.

**Что именно доказано:** обычные imports, неизменённые modules и constructors, настоящий asyncio cancellation и filesystem ledger, real GatewayLLMResponse/Usage schemas, middleware/observer, public client entrypoints. Provider offline fixture ждёт Event и возвращает типизированную response с синтетической стоимостью 0.25. Нет paid external call, HTTP disconnect, deployed workload, реального worker lease takeover или production cash loss. Run binding и control_job_attempt здесь test inputs, не результат authenticated admission.

**Reachability:** factory.py:467–495 оборачивает provider в CachingLLMClient только при положительных cache_maxsize и cache_ttl_s; direct branch остаётся предусмотренным configuration path. Эта проверка не утверждает, что default deployed cache отключён. Cached sibling имеет отдельный owner task и done callbacks (`prompt_cache.py:868–909`), но его executable control не запустился из-за native syntax dependency; не переносить BUD-01 на все cached paths.

**Repair direction:** существующий physical producer task должен владеть provider+settlement целиком, а waiters лишь ожидать его shielded completion. Retire live handle после физического исхода/settlement, а не после отказа waiter. Сохранить run/attempt attribution durable begin. Отмена caller не выдаёт разрешения на новый provider и не должна превращать известный поздний ответ в необратимый unknown. Не чинить удалением unknown rows или безусловным release. Если нужен operator reconcile уже сохранённого terminal unknown, он должен отдельно привязать authoritative cost evidence, а не переписать факт как обычный conflicting retry.

**Acceptance:** declared Python3.14/locked environment, direct ainvoke/generate и cached/uncached sibling; cancel 0/1/2/3 раза до/после begin и response, scope exit/lease takeover, process death до/после settlement. Наблюдаемый provider response сохраняет exact event, request, original attempt и единственное charge; отменённый caller не получает publication authority. Unknown external outcome остаётся fail-closed, новая работа не запускается слепо.

## 2. Budget custody matrix: actual producer → owner → consumer

### A. LLM spend, не physical N5 USD

- Factory `scientist/orchestration/llm/factory.py:165–200, 325–425, 467–525`: in current gateway scope admission проверяется до/после begin; bounded begin executor отделён от ledger settlement. Runtime scope/SQL fence в данной проверке source-traced, не исполнялся.
- `TracedLLMClient._begin_provider_event:686–787` вызывает actual BudgetMiddleware admission. Durable begin предшествует provider invocation.
- `BudgetMiddleware.begin_producer_event_safe:372–434` использует run binding/attempt и local live registry. `FileBudgetLedger._begin_producer_event:2173–2280` допускает соседний pending только при **реальной local liveness и том же attempt**. Unknown или orphan pending отказывает.
- `BudgetMiddleware.settle_producer_event_safe:436–498` намеренно допускает late accounting после scope exit, но берёт binding и attempt из durable begin, а не из нового ambient context.
- `ProducerBudgetObserver.observe:1010–1136` переоткрывает ledger, проверяет owner/run/event/receipt, требует committed и известный cost origin. `admit:1138–1155` отказывает при unknown positive-cap spend; computed sum не является новым денежным reservation.

**Проверено:** begin с directory sync failure не выдаёт нормального ack; видимый pending row не читается как подтверждённый outcome пока sync продолжает падать. После восстановления sync row остаётся pending. Delay settlement attempt1 внутри scope attempt2 сохраняет attempt1. Это accounting continuity, а не permission для поздней публикации результата.

### B. Identified compute reservations: самостоятельный ledger API

- `budget_ledger.py:1423–1639`: reservation имеет event_id/request_digest, reserved/unknown/settled; unknown сохраняет floor; settle атомарно снимает reservation и записывает receipt/spend; exact retry идемпотентен, конфликтующий amount отказан.
- `_persist_snapshot:2798–2855`: temp file write/fsync → replace → directory fsync, при uncertainty сохраняется identity; `_file_lock:2577–2667` обрабатывает ошибки после publication как unknown.
- Complete textual identifier census покрывает все `.py` под `policy-engine/src`, denominator hash и matching lines сохранены. Найдены только definitions/references внутри budget_ledger.py. Это сильное ограничение на integration claim, не доказательство невозможности динамического getattr/внешнего consumer.

**Проверено actual FileBudgetLedger:** unknown reserved 0.75, next reservation rejected, legacy release rejected; write-then-lost-ack → reopened settled; retry amount0.4 дважды → total0.4; changed amount0.5 → conflict. Три отдельные spawned process exits: after reservation exit31, before settlement publication exit32, after publication exit33. Первые два reopen reserved0.75/spent0, третий settled/spent0.4/reserved0. Exact settlement retry converges без двойного списания. Это application crash boundaries, не power-cut/fsync hardware guarantee.

### C. N5 invocation units: consumed attempts, не monetary reserve

- `joint_simulation_horizon.py:_require_nl_physical_budget_scope:1944–2022` проверяет issued NL scope, selected quota, exact owner/run and rejects hard_total_usd/explicit_null с `n5_physical_usd_reservation_not_established`.
- `_run_cached_replicates` делает current budget admit, separate invocation reservation и повторный scope check непосредственно перед operation. После выполнения `finish_invocation` записывает completed/failed. Finish error отражается как outcome_unknown и сохранённый physical observation, без выдачи ещё одного permit (`:2112–2232`). BaseException/process death здесь могут оставить reserved; это не автоматически свободная capacity.
- `ProducerBudgetObserver.reserve_invocation:906–934` использует `(record, created)` owner result; existing ID всегда отказывает `n5_invocation_already_issued`.
- `budget_ledger.finish_invocation:1951+` сохраняет использованную единицу при completed/failed/unknown; terminal unknown нельзя обычным retry переименовать в completed.

**Проверено на настоящем observer/middleware/ledger:** allocation total3/protected1, unknown standard unit + completed standard unit исчерпывают standard2; повтор ID отказан; third standard call отказан. Unknown→completed через обычный finish отказывает, обе единицы остаются accounted. Настоящий N5 numerical producer и scope issuer не выполнялись. Это положительная quota guarantee, не defect из-за отсутствия refund.

## 3. N5 witness lifetime и authority: что установлено и что остаётся открытым

Source chain:

1. `generation_cycle.py:6314–6335`: actual candidate V5 port открывает `observe_candidate_n5_execution_input`, запускает controller и связывает result через `bind_n5_execution_implementation`.
2. `joint_simulation_horizon.py:4558+`: controller создаёт N5ImplementationCapture для выбранного implementation.
3. `n5_execution_basis.py:612–708`: capture удерживает method/controller/request/admission, observed codes/frames; inner `__exit__` намеренно не останавливает outer observer. `_ControllerExecutionObserver.__exit__:505–513` снимает profiler, не чистит historical capture.
4. `seal:1085–1094` кладёт **только established** witness в process-global `_ISSUED`. `_token:321–331` намеренно удерживает object, чтобы id не переиспользовался. В этом owner нет публичного release/revoke/close или expiry issued entries. Это подтверждает lifecycle gap предыдущего retention аудита, но не означает, что clear безопасен: reader использует record как живой provenance.
5. `reconcile_live_n5_implementation:1129–1161`: проверяет process session, recomputed provenance, exact issued record, input/result binding и заново recomputes loaded implementation. `read_n5_execution_implementation_witness:1164–1192` проверяет historical content отдельно; он не даёт current permit.
6. `acquisition_evaluation.py:1424–1446,1699–1715` явно выбирает historical read либо live reconciliation. Retention/terminal publication требует другой live authority: `acquisition_evaluation_dispatch.py:390–475,539–597,868–875` проверяет actual execution identity/lease, current action head, occurrence and PA2; `run_lifecycle.py:5385–5410,6005–6022` требует этот owner fence перед terminal write. Generic N5 completion имеет дополнительную currentness projection, блокирующую устаревший observation (`generation_cycle.py:6599–6627`).

**Не доказано:** N5 revoke producer, актуальное cancellation API → terminal denied end-to-end, настоящая positive seal и последующая смена implementation/lease, cross-process retention recovery, bounded registry release при сохранённой исторической читаемости. Actual import N5/cached sibling blocked `core/artifacts/store.py:2155` Python3.14 except syntax под Python3.12. Не использовалась синтетическая вставка `_ISSUED` как замена producer seal; не объявляется broken authorization из одного живого memory object.

**Предлагаемый acceptance A5:** native actual candidate input → genuine N5 seal → persisted result → actual currentness/authority revoke → retained-result consumer; historical reading remains allowed, fresh retention/terminal publication denied. Затем lifecycle disposal после отсутствия permitted live consumers, token non-recycling и declared process restart fallback. Clear всех registries без такого контракта не является исправлением.

## 4. Evidence и ограничения

- `probe_budget_authority.py`: final exit0. Реальные imports, без stubs/extracted/rewritten product bodies. Synthetic costs/provider/scope and deliberate persistence failures are explicitly bounded.
- `budget_authority_results.json`, stdout/stderr/exitcode: all final observations. Initial successful result сохранён в `initial_run`; final run повторяет distinguishing cases.
- `inspect_source.py` / `SOURCE_VALIDATION.json`: pinned HEAD, каждый imported/cited source file сверяется с commit bytes, complete Python src identifier census, result counters. `SOURCE_EXCERPTS.txt` содержит точные deciding ranges.
- `ledger_tests.*`: попытка native pytest suites завершилась **до tests**, `No module named pytest`; не считать tests passed/failed. Зависимости не устанавливались.
- `cache_import_attempt.*`: cached sibling import не прошёл из-за Python profile. `process_start_timeout.*`: промежуточный instrument run имел слишком короткий 15s process startup bound; parent cleanup породил последующий child FileNotFound. Это исправлено в **измерителе** на bounded120s с cleanup после прекращения child; final run passed. Это не product crash failure. `validation_early_attempt.stderr.txt`: validation была запущена до обновления result schema, исправлено повтором после final run, не product failure.
- No source edits, deployments, real providers, external effects, migrations, full pytest/lint, Python3.14/locked qualification, SQL/N5 end-to-end run. Date/cost/job identities in test records are fixtures, not customer facts.

**Следующий приоритет:** native repeated-cancellation regression и полноценный N5 revoke consumer witness. Не ослаблять unknown/duplicate/SQL guards ради cleanup или «успешного» retry.
