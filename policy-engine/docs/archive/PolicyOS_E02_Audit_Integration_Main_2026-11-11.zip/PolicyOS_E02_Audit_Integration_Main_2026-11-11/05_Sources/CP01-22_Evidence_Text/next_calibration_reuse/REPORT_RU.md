# PolicyOS: повторное использование Gaussian uncertainty и единицы calibration

**Статус: PARTIAL.** Read-only срез `f1541ed155f278689be48a8c7ac56c3e200210f7`. Продолжение W01/S07 и W07/S08 после SI-01/02: другой producer, другой численный механизм и typed consumer. ENCE, LRuc/LRcc и bootstrap RNG повторно не исследуются. Product source, tests, configs и Git не изменены. External effects отсутствуют.

## Результат

- **CR-01, P2 numerical correctness:** существующий Hessian/Laplace adapter теряет ненулевую ширину и std при конструировании envelope, хотя общий Gaussian helper уже умеет удерживать такую ширину или явно отказывать. Ошибочный envelope сохраняется штатными report/envelope writers и читается новым процессом. Это дефект кандидатной научной информации, не доказанный допуск policy.
- **CR-02, P3 exported-API correctness:** скалярный IR `push_forward_envelope` независимо от CR-01 использует абсолютный numeric tolerance как нижнюю границу стандартного отклонения. Линейная смена единиц превращает ожидаемый std=1 в std=10. Тот же branch меняет heuristic Gaussian range на `deterministic_bounds`; конечный диапазон Gaussian не становится детерминированной границей. Literal census не нашёл call site этого API в product source, поэтому operational effect не установлен.
- **Положительный результат:** 36 bounded Decimal-oracles для JΣJᵀ, 8 scale/representation fixtures, 16 guard cases. 9 reports и 28 envelopes прочитаны отдельным процессом. Во всех 28 сохранён `gate_eligible=false`, actual `envelope_meets_trust_policy` отказывает. Valid-hash попытка поставить heuristic `gate_eligible=true` отвергается настоящим owner reader.

## 1. Выполненная цепь и её честная граница

Исполнены полные модули `foundry.calibration.report`, `foundry.calibration.uncertainty_adapter`, `foundry.uncertainty.protocol` и `ir.analytics.uncertainty`, их настоящие typed validators, Core/IR selected-profile writers/readers и FileSystemCAS:

`synthetic CalibrationReport2.0 + coordinate projection → envelopes_from_calibration → put_calibration_report / persist_uncertainty_envelope → new-process source report regeneration / load_uncertainty_envelope → explicit scalar IR consumer / trust predicate`.

Исходные covariance/std являются synthetic inputs. `Calibrator.run`, Hessian estimation, simulation, actual measurement-source admission, native Scientist propagation node и полный governance/protected action **UNRUN**. Source trace подтверждает настоящий producer call в `calibrator.py:3926–3930` и чтение embedded envelope в `propagate_uncertainty.py:779–799`; это не исполнение этих orchestration edges. Более строгий response-basis reader отдельно сверяет envelope digests и parameter/unit identities (`1188–1242` и далее); он не исполнялся.

Runtime Python3.12, прежний in-memory syntax/TypeVar loader и namespace facades. Обычный import report остановился на отсутствии JAX в transitive `identifiability → execution_basis`. Вместо fake JAX применён **точный AST DTO-only facade** для трёх исходных classes `IdentifiabilityStatus`, `ParamIdentifiability`, `IdentifiabilityReport`. Их тела не изменены; identifiability computations не исполнялись. Все исследуемые formulas, validators, branches, persistence и reader bodies остались исходными. Это не native3.14, normal package import, installed wheel или штатный pytest.

## 2. CR-01: защищённый Gaussian constructor не переиспользован

Owner: `foundry/calibration/uncertainty_adapter.py:305–354`. Adapter вычисляет μ±zσ, затем напрямую строит `UncertaintyEnvelope` без numeric policy. IR defaults округляют point, bounds и parametric payload до 12 знаков (`uncertainty.py:546–568,1415–1437`), но не metadata.

Контрпример с version2.0 и настоящей projection:

- μ=0, σ=10⁻¹³, covariance=10⁻²⁶, J=[1]. Ненулевая ожидаемая ширина 3.919927969080108×10⁻¹³.
- Получаются interval=[0,0] и `distribution_payload.parameters.std=0`; metadata сохраняет `std=10⁻¹³`, `covariance_row=[10⁻²⁶]`.
- При σ=1 получаются корректные ненулевые range и carrier. Это та же модель при смене единиц на 10¹³; исходная дисперсия и арифметика представимы, underflow отсутствует.
- μ=3×10⁻¹³, σ=10⁻¹³ также стирает point/spread. Fixture σ=3×10⁻¹³ показывает промежуточную несогласованность: ненулевая округлённая ширина, но carrier std=0.
- Независимый, не round12 пример: μ=10¹⁶, σ=.01. В binary64 оба bounds поглощаются большим point, width=0, при этом carrier std=.01. Это должно быть явной потерей представимости, а не молчаливым zero-width.

Положительный sibling control: **существующий** `gaussian_uncertainty_envelope` (`protocol.py:155–183`) выбирает `DECIMAL_EXACT` для первого случая и отказывает в последнем: `binary64 cannot represent the nonzero Gaussian interval`. Обычный σ=1 и настоящий σ=0 не блокируются. У helper также есть запрет выдавать Gaussian quantile как deterministic bound.

Для обоих legacy1.0 и version2.0 adapter получены одинаковые numerical outcomes; persistence проверялся именно для version2.0, сохраняющего typed null `confidence_level`. Девять version2 reports с config input edge и 28 standalone envelopes пережили настоящий CAS и fresh read. Report regeneration воспроизвела точные embedded envelopes. Корректный hash/replay не обнаруживает детерминированную потерю при построении.

Риск ограничен текущими данными: результаты heuristic, `gate_eligible=false`. Синтетический test не показывает production issuance или статистическую пригодность Hessian approximation.

## 3. CR-02: numeric tolerance используется как статистический scale

В `ir/analytics/uncertainty.py:1141–1154` `_std_from_envelope` заменяет σ на `max(σ,absolute_tolerance)`. В delta branch `1776–1812` затем снова применяет этот tolerance к выходному std. Константа описывает численную canonicalization policy; она не имеет declared physical unit conversion и не является noise model.

Различающий control отделяет дефект от CR-01:

- Вход построен с `DECIMAL_EXACT`, μ=0, σ=10⁻¹³, ненулевым точным range и carrier. Upstream round12 отсутствует.
- При map f(x)=10¹³x независимая линейная формула даёт σ_out=|10¹³|×10⁻¹³=1.
- При default absolute_tolerance=10⁻¹² source выдаёт σ_out=10, interval=[−20,20].
- Тот же exact input с tolerance=0 даёт σ_out=1 и [−2,2]. Вход с σ=1 в конечных единицах и identity map также даёт σ=1. Таким образом, одной правки CR-01 недостаточно для scalar API.

Отдельная семантика того же branch: когда вход имеет `confidence_level=None`, Gaussian heuristic range превращается в `deterministic_bounds`, `is_heuristic_ci=false`. На корректном входе μ=0, σ=1, identity map получаются [−2,2]. Для N(0,1) вероятность вне этого диапазона по независимой `erfc(2/√2)` равна 0.04550026389635844; модель не имеет ограниченного support. Это математический discriminator семантики, а не empirical coverage estimate. `gate_eligible` остаётся false, поэтому actual trust predicate продолжает отказывать.

**Предел finding:** `CALLER_CENSUS.json` содержит literal references по всем `src/polisyos/**/*.py`. Для `push_forward_envelope(` и `compress_envelope(` найдены definitions, не operational callers. Aliases/dynamic calls не исключены данным поиском. Выполненный downstream edge является прямым вызовом exported IR API из audit, а не обнаруженным native orchestration route. Поэтому priority P3 и никакого operational/protected bypass.

## 4. Что действительно работает

36 covariance cases используют разные положительно определённые 2×2 исходные матрицы и 3×2 J с tied/summed/negative coefficients. Независимый oracle суммирует произведения в Decimal precision60; все source covariance rows совпали. Interval widths при нормальном масштабе согласованы с независимым SciPy ndtri(.975). Это проверка алгебры и binding, не идентифицируемости модели.

Guards различают: отсутствие uncertainty/parameter/projection; negative legacy std; nonfinite std/point; negative projected variance и неправильную shape; coordinate/field mismatch; nonfinite J; invalid confidence; missing config lineage edge. Heuristic promotion отвергается как constructor, так и reader для заново записанных valid-hash bytes. Gaussian helper явно отказывает deterministic semantics. Дополнительный eligible statistical contract показывает, что trust predicate не константно false; этот положительный контроль не является source-admitted authority.

Particle compression исполнена как дополнительный downstream diagnostic. Она использует `model_copy`, поэтому вновь созданные particles canonicalize при owner read. Fresh equality сравнивается с typed canonical representation; unrounded interim particles не объявляются byte-exact persisted draws. Этот штатный precision effect отдельно раскрыт, не возведён в новый finding.

## 5. Архитектурные решения о reuse

1. **Extend/wire existing Gaussian owner.** Не добавлять новый универсальный numerical/authority framework. Свести duplicated interval representability checks к `foundry.uncertainty.protocol.gaussian_uncertainty_envelope` и использовать их из calibration adapter. Текущий helper не переносит typed `ParametricFitCarrier`, поэтому слепая замена потеряет закон. Нужны закон, metadata/covariance и bounds под одной numeric policy. Сохранить более строгий отказ calibration adapter для negative std: общий helper сейчас clamp-to-zero.
2. **Keep domain ownership.** Calibration сохраняет coordinate order/JΣJᵀ, identifiability, Hessian assumptions и heuristic/noneligible status. IR хранит typed carrier, numeric/wire policy и semantic lattice. Эти функции нельзя отдавать библиотеке Gaussian quantile.
3. **Extend existing scalar IR consumer.** Numerical tolerance не должна молча становиться statistical SD. Если нужен resolution/noise floor, он должен быть явным unit-bound domain contract. Heuristic range после approximation должен оставаться heuristic, пока отдельное доказательство не устанавливает deterministic support.
4. **Retain NumPy и stdlib NormalDist.** Все 36 bounded matrix oracles прошли. SciPy использован только независимым quantile oracle; новая library dependency не исправит ownership/units. `next_library` уже отделил estimator semantics от kernel reuse; данный срез подтверждает ту же архитектурную границу другим фактическим путём.
5. **Version changed replay semantics.** Не пересчитывать старые artifact identities по новой политике незаметно. Отличать original saved diagnostic от исправленного newly produced envelope. Сохранить selected-profile custody и fail-closed eligibility.

## 6. Воспроизведение, ошибки инструмента и остаток

Команды из этого каталога: `python probe.py`, `python replay.py`, `python build_evidence.py`, `python validate_evidence.py`, `python seal_evidence.py`. Использованы `PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1`. Полные stdout/stderr/exitcodes сохранены.

Неуспешные audit attempts не удалены: initial normal import подтвердил missing JAX; первый producer был остановлен отсутствующим explicit ref import в инструменте; второй слишком строго сравнил pre-canonical compression particles с persisted value. Исправлены только audit import/assertion, без изменения product. После correction полный producer и fresh reader прошли.

UNRUN: supported Python3.14/JAX/native imports, real fit/Hessian and units registry, genuine measurement/source relation, complete Scientist node/dispatcher/governance, optional JAX covariance consumers, all scientific population/stationarity validity, deployed effects. Reuse recommendation требует focused sibling tests в `analytical`, `delta`, `aggregator`; их похожие quantile constructors сейчас source-traced, не квалифицированы этим probe. Общее закрытие W01/S07/W07/S08 не заявлено.
