# PolicyOS: рост каталога до 200 000 показателей

**10 ноября 2026; read-only; commit `f1541ed155f278689be48a8c7ac56c3e200210f7`.**

## Результат

Проверен отдельный от run-index путь: Fabric metric-level catalog → FastLane → retrieval. Два исполняемых измерителя завершились, `exitcode.txt=0`, `controls.exitcode.txt=0`. На **200 000 реально валидированных DataContract** подтверждены неограниченные размером ответа scan и rebuild. Добавлены semantic controls, необходимые, чтобы оптимизация не превратила неоднозначность в уверенный выбор и не сохраняла удалённые bindings.

Главные выводы:

1. **Общий tag/alias делает построение reverse alias index квадратичным.** Один shared tag даёт N(N−1)/2 сравнений ID. Это выполняется заново и при refresh.
2. **Refresh не переиспользует неизменившиеся semantic documents.** При `changed=[]` построены все 200 000 документов заново. Один approved promotion также обновляет весь индекс, а не только изменившийся metric.
3. **top-1/top-5 не ограничивают работу поиска.** Non-exact query на 200 000 contracts делает 200 000 cosine и 600 000 fuzzy-alias scores. Существующий FastLane exact path также материализует полный список registry IDs до проверки membership.
4. **Есть два semantic edge defects:** явно переданное `bindings=[]` сохраняет старое enrichment; `max_results=1` может выключить disambiguation при сотнях одинаково точных matches.

Это **не** оценка production capacity, SLA, supported-profile qualification или общий вывод обо всех каталогах. У DataForge уже есть иной DuckDB/HNSW owner; его performance здесь не измерен. Не запускались HTTP, providers, acquisition, approval admission, публикация, E02 или численные jobs. Исходники не изменялись.

## Покрытие и границы

| Поверхность | Реальное исполнение | Граница |
|---|---|---|
| DataContract, MetricBinding, SourceBinding | Реальные определения/validators и тела selected methods | Imports адаптированы через AST; baseline Python 3.14 не доступен |
| MetricSearcher, SemanticCatalogIndex | Реальные constructor/search/refresh/fingerprint/vector/body на 1k/10k/100k/200k | Synthetic metadata; profile-free bindings; не native import |
| RetrievalService._promote_binding → registry.upsert → FastLane.refresh → MetricSearcher | Реальный selected promotion body и реальные nested bodies, пять promotions для каждого N | `__new__` initialization seam; false optional persistence flag; нет HTTP/approval state machine |
| FastLane._resolve_metric_candidates exact route | Реальный method + SourceBindingRegistry.list_metric_ids до 200k keys | Cache-seeded registry keys; не проверка fetch/admissibility bindings |
| SemanticDatasetCatalog.search/stale | Реальный класс и DTO, до 100k entries | Cache-seeded entries, не валидированные SourceContracts; source route найден как public/test API, не доказан production consumer |
| DataForge DatasetCatalogStore/DatasetCatalogGraph | Source comparison и существующий HNSW boundary | DuckDB отсутствует; DB/HNSW/generation admission/SQL plans не запускались |

`MetricSearcher` вызывается из `FastLaneResolver.__init__` (`fabric/catalog/resolver_fast_lane.py:87–107`), который создаётся `RetrievalService.__init__` (`fabric/retrieval/service.py:391–423`). Retrieval `search_catalog` вызывает FastLane (`service.py:1412–1424`). Promotion chain: `runtime/http/routes/control.py:1101–1127` → `runtime/http/services/control/run_lifecycle.py:17207–17218` → `RetrievalService.approve_promotion:1450–1468` → `_promote_binding:1606–1624`. Это source reachability, не HTTP execution evidence.

## NC-01. Общий alias вызывает квадратичную регистрацию

**Статус:** new_mechanism в catalog-growth, не повтор SYS-07/AUD-001 про run-directory cap. Confidence high для selected mechanism; severity medium как growth risk, без установленного production outage.

`fabric/catalog/search.py:142–159` создаёт posting list на alias. Для каждого metric проверяется `metric_id not in list`, затем append. Нормализованные общие tags тоже входят в этот индекс. Для списка размера p с уникальными ID суммарно требуется p(p−1)/2 equality checks. При фиксированном числе полей общая цена зависит от распределения posting sizes, а не только от N: shared alias даёт O(N²), полностью непересекающиеся aliases этого механизма не имеют.

| N | Общий tag: реальные ID equality calls | Без общего tag |
|---:|---:|---:|
| 500 | 124 750 | 0 |
| 1 000 | 499 500 | 0 |
| 2 000 | 1 999 000 | 0 |

Equality counters используют subclass str с сохранённым hash и unchanged equality результатом. Это instrumentation, не timing normal strings. Отдельная серия на настоящих Pydantic DataContract/обычных str выполняет только actual `_build_alias_index`: медианы 3 повторов для 10 000 contracts: **0,810 s** с common tag против **0,059 s** без него. Ровно один дополнительный alias key и одинаковый остальной корпус.

При 100 000 unique IDs в одном posting list формула даёт **4 999 950 000** сравнений. Это **арифметическая проекция из тела алгоритма**, не исполненный 100k shared-tag benchmark и не прогноз latency. Большая search-серия сознательно использует непересекающиеся aliases, чтобы не смешивать механизмы.

**Направление:** существующий MetricSearcher владеет alias postings; использовать hash-based membership или строить postings без повторного linear duplicate check при сохранении duplicate/normalization semantics и детерминированного порядка. Не заменять каталог hard cap. Acceptance: repeated/case-normalized aliases, общий tag, несколько одинаковых input IDs, public search order и ambiguity; counters при 100k shared-tag corpus не квадратичны. Нет нужды вводить новый generic registry framework.

## NC-02. «Changed IDs» не означает incremental materialization

**Статус:** new_mechanism, с тематической связью к repeated immutable work SYS-07, но другой owner. Confidence high, severity medium для роста/repeated promotion. Это не неправильная numerical модель и не SYS-08 VOI finding.

`SemanticCatalogIndex.refresh` (`fabric/catalog/semantic.py:458–484`) использует fingerprint только для `changed.append`. `_build_document` вызывается всегда. Новый timestamp, vector, token tuple, metadata и object создаются даже при равном fingerprint. `MetricSearcher.refresh_semantic_index` ещё и полностью пересобирает alias index (`search.py:127–140`).

| N contracts | Build: local seconds | Unchanged refresh: local seconds | Fingerprints / document builds / vectorize при refresh | changed |
|---:|---:|---:|---:|---:|
| 1 000 | 0,112 | 0,194 | 1 000 / 1 000 / 1 000 | 0 |
| 10 000 | 0,992 | 1,605 | 10 000 / 10 000 / 10 000 | 0 |
| 100 000 | 9,615 | 9,302 | 100 000 / 100 000 / 100 000 | 0 |
| 200 000 | 22,516 | 21,631 | 200 000 / 200 000 / 200 000 | 0 |

Build/refresh здесь по **одному sample** на size, не latency distribution. Для unchanged entry сохранены vector/fingerprint, но object заменён. One-change control: один changed ID, N rebuilds. Addition: один новый ID, 1001 rebuild. Removal: удалённый document действительно исчезает, хотя его ID не входит в returned changed list. Последнее не объявлено самостоятельным defect без определения consumer contract списка.

Реальный `_promote_binding` вызывает `SourceBindingRegistry.upsert` и `refresh_search_index` после каждого candidate. Пять synthetic accepted-body calls дали 500/2500/5000 document builds при N=100/500/1000. В registry добавлено пять bindings; persist не происходил. На fixed N общая работа H promotions включает H·N document builds и H повторных alias rebuild. Если common posting растёт как N, alias component может быть H·N². **Не утверждаем**, что production выполняет unbounded automatic approvals: здесь только допустимое тело одной approved operation. `upsert` также сканирует, сортирует и пересобирает registry (`source_bindings.py:209–232`).

**Направление:** сначала переиспользовать существующий document при равном fingerprint, затем revision/delta-aware обновление owner. Это не отменяет стоимость N fingerprint scans без достоверной changed-set authority. Сохранить contract/binding/profile invalidation, removal, metadata source and timestamp semantics; определить, timestamp означает materialization time или freshness check. Batch refresh после группы operations допустим только с явной атомарной publication/visibility семантикой, не как невидимая задержка одного approved update. Acceptance: unchanged object/vector reuse; one update/add/remove только соответствующий rebuild; same public ranks/fingerprints; concurrent readers не получают mixed generation; failed refresh не публикует частичное состояние.

## NC-03. Малый ответ не ограничивает query work

**Статус:** new_mechanism/growth limitation, confidence high на selected path, severity medium для масштабирования. Linear scan сам по себе не correctness defect и может быть разумным для малого «Small deterministic vector index», как назван класс. На большом corpus доказана цена, не достигнутый SLA breach.

`semantic.py:486–517` считает dense cosine размерности96 для каждого document, затем token intersection, создаёт все прошедшие matches и сортирует их до slicing. `search.py:294–332` на пути без early return считает fuzzy similarity для каждого unique alias и строит/сортирует все подходящие lexical results. Оценка включает N·D, размеры token sets, A aliases, posting traversal и M log M сортировку; просто назвать весь запрос O(N) было бы недостаточно.

| N | Cosine calls | Fuzzy alias scores | Semantic match objects на «witness output» | Returned | Median seconds, 3 queries |
|---:|---:|---:|---:|---:|---:|
| 1 000 | 1 000 | 3 000 | 1 000 | 5 | 0,0225 |
| 10 000 | 10 000 | 30 000 | 10 000 | 5 | 0,2642 |
| 100 000 | 100 000 | 300 000 | 100 000 | 5 | 1,6185 |
| 200 000 | 200 000 | 600 000 | 200 000 | 5 | 3,8181 |

Corpus: unique metric/display/last-segment aliases; descriptions содержат `witness output statistic`. Для no-match `zzzzmissing` те же scan counters, ноль results; на200k median2,7001s. С limit1 counters остаются теми же. Это fixed synthetic metadata, instrumented local process, без HTTP/DB/provider. Не переносить эти секунды на пользователей, production percentile, concurrent throughput или generic multilingual relevance.

**Уникальный exact alias** действительно пропускает scans: одна binding construction и ответ1 на всех N. Но **общий exact alias** не пропускает semantic/fuzzy. Для1000 common-tag matches:1000 cosine,3001 fuzzy scores и **2000 binding constructions** (exact + lexical) до return5. Параметр top-k здесь не bound на работу и allocation.

**FastLane exact caveat:** `_resolve_metric_candidates` (`resolver_fast_lane.py:269–319`) сначала выполняет `query in registry.list_metric_ids()`. Этот метод возвращает `sorted(self._by_metric)` (`source_bindings.py:138–140`). Реальный caller control возвращает один exact candidate, но materializes1000/10000/100000/200000 IDs. Полная sort имеет worst-case O(B log B), на уже упорядоченном synthetic input Timsort дешевле; list membership до последнего ID линейна. Следовательно O(1) lookup внутреннего MetricSearcher нельзя обещать для полного FastLane path. Измеренные milliseconds не подменяют counter и не доказывают bottleneck этого route.

**Sibling public dataset catalog:** `SemanticDatasetCatalog.list_entries` сортирует весь cache (`discovery.py:302–303`), search (`:369–457`) считает cosine даже при exact source-contract ID. Cache-seeded100k actual Entry DTO:100k cosine,100001 exact-score calls и return1; local median1,0046s. Stale default exclusion и explicit allow_stale controls сохранены. Эти данные не означают, что100k валидированных SourceContracts реально admitted или что этот public/test API обслуживает все production dataset searches. Shared vector fixture здесь исключает memory estimate.

**Направление:** использовать точный dictionary membership у существующего registry; inverted lexical postings и заранее normalized tokens; bounded top-k ranking с сохранением deterministic tie-break/ambiguity; candidate generation отделить от final evidence-backed re-ranking. Внешний ANN backend не является обязательным первым шагом. Существующий DataForge HNSW owner можно исследовать для reuse только с metric-level adapter и явными semantics. Acceptance: одинаковые results/ranks/route/reasons/ambiguity на ties, missing/empty, stale/revoked, multilingual и near-threshold corpus; exact route не materializes весь registry; quantify recall/fallback if ANN introduced.

## NC-04. Freshness и ambiguity нельзя потерять при оптимизации

### Явное удаление bindings не очищает enrichment

**Confirmed selected-method correctness defect; low-to-medium severity; high confidence.**

`search.py:137`: `list(bindings or self._bindings)` смешивает «argument не передан» и «передан пустой список». В control один реальный SourceBinding с connector `audit_connector` и alias `quasarwitness`; refresh(..., bindings=[]) возвращает changed=[], сохраняет binding count1, старые connector/alias в document и прежний fingerprint. Прямой `SemanticCatalogIndex.refresh([contract], [])` удаляет connector/alias, сообщает metric changed; новый MetricSearcher без bindings даёт тот же очищенный fingerprint. Значит, отличие локализовано в wrapper, не объясняется content hash или inability index to delete.

**Не доказано:** выполнение удалённого connector, auth bypass, cross-tenant access, успешный unsafe fetch. FastLane формирует concrete candidates через отдельное актуальное `bindings_for_metric`, поэтому stale enrichment не тождественно stale fetch permission. Public refresh boundary явно воспроизведён; runtime удаление последнего binding не воспроизводилось (у registry нет публичного remove в просмотренном owner).

Минимальное направление: отличать None от explicit empty; acceptance omitted argument сохраняет существующие, empty очищает, nonempty replaces; compare metadata/fingerprints/query results with fresh instance. Сохранить current binding validation.

### max_results=1 скрывает известную неоднозначность

**Confirmed configured-path correctness defect; medium severity на таком configuration; default path не объявляется сломанным.**

`search.py:258–260` slicing выполняется до `_needs_disambiguation`. При100 и1000 contracts с одним общим exact alias все confidence=1.0. `max_results=5`: needs_disambiguation=True. **Тот же corpus/query с max_results=1: False**, выбран первый metric по tie-break. `resolve` доверяет этому флагу (`search.py:443–468`), реальный resolve control возвращает первый binding при1 и ValueError при5. Default MetricSearcher5 и FastLane12 не равны этой конфигурации; production caller с1 не установлен.

Минимальное направление: вычислять ambiguity по достаточному contender set до display truncation либо запретить incompatible max_results. Не «лечить» performance снижением k до1. Acceptance одинаковый ambiguity verdict для1/5 при одинаковом полном contender set; ties, near threshold, unique exact and empty controls. Важно сохранить две независимые цели: bounded response и честную неопределённость.

## Почему это не «все каталоги PolicyOS линейные»

`data_forge/domains/catalog/knowledge/store.py:637–661` использует HNSW `knn_query`; `search.py:781–855` комбинирует его с text candidates, query lock, read session и generation-bound query embedding. Text fallback SQL содержит concat/lower/LIKE и LIMIT после scoring (`store.py:664–730`), однако query plan и native runtime здесь **не измерены**. Read-session guards и embedding generation admission имеют собственную freshness цену. Нельзя приписать всему API скорость ANN без этих остальных шагов, но и нельзя объявить отсутствие indexed search во всём продукте.

Решение reuse: **extend existing**, не второй общий catalog service. Metric contracts, source-contract discovery и dataset knowledge имеют разные ID/evidence/permission/epoch contracts. Сначала fix local posting membership и unchanged reuse. Затем оценить совместимость существующего индексного owner, сохраняя checks и bounded fallback. HNSW не доказывает true semantic understanding: нынешний Fabric `hashing-bow-v1` детерминированный96-dimensional token hashing с явными synonyms, не обученная causal model. Ranking candidate не устанавливает grounded/admissible metric binding или права на acquisition.

## Reproducibility и qualification

```
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 \
python policyos_deep_audit/next_catalog_scale/probe_catalog_scale.py \
  --source policyos_deep_audit/source \
  --output policyos_deep_audit/next_catalog_scale/results.json

PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 \
python policyos_deep_audit/next_catalog_scale/probe_catalog_controls.py \
  --source policyos_deep_audit/source \
  --output policyos_deep_audit/next_catalog_scale/controls_results.json
```

- Python3.12.14, Pydantic2.13.4; supported baseline Python3.14, Pydantic constraint `>=2.12.5,<2.13`. Native/locked/installed не квалифицированы.
- Ordinary `MetricSearcher` import сохранён в `normal_import.*`: TypeVar(default=...) в `ir/kernel/units.py` не поддерживается Python3.12. Это tooling blocker, не продуктовый failure. DuckDB отсутствует.
- Пробы исполняют неизменённые выбранные source AST bodies. Удалены absolute product и relative imports, globals поданы явно. Реальные DataContract и SourceBinding validators, MetricBinding hash path через actual common hashing, numeric and unit helper bodies сохранены. Logger заменён stdlib; profile provider и atomic writer заменены fail-on-call; все bindings profile-free.
- Первый bootstrap измерителя упал из-за неинжектированного SourceBindingRegistry default argument. `instrument_v1.stderr.txt` и `instrument_v1.exitcode.txt` сохранены. Исправлен только audit harness; это не product failure. Финальные оба exits0.
- Большой probe требует примерно3GiB process high-water RSS на этом synthetic workload. `process_maxrss_kib_cumulative` при200k=3 088 484KiB. Это cumulative process peak, включает подготовку inputs, старые/новые generations во время rebuild, allocator и earlier series; **не per-index retained-memory, не leak и не production sizing**. Повторная серия не memory-stability soak.
- Fixed sample order, shared executor/background work и filesystem cache не изолированы. Queries имеют3 samples, build/unchanged refresh1. Counters являются главным evidence; wall times только локальная иллюстрация. Не нужны provider budgets, network, production state или source writes.
- Полные counts, samples, extraction spans/hashes находятся в JSON. SOURCE_VALIDATION.json сверяет examined paths с pinned complete baseline; это не semantic coverage всего repo. Независимое REVIEW_RU.md проверяет инструмент/источник/выводы, но не повторяет дорогой benchmark и не заменяет native acceptance.

## Минимальная очередь дальнейших изменений, не выполненная здесь

1. Semantic regressions: explicit-empty binding replacement; ambiguity independent of output truncation. Закрепить реальные sibling consumers.
2. Убрать list-membership quadratic work и full-list exact lookup, сохранить deterministic order/duplicates.
3. Incremental materialization в existing SemanticCatalogIndex; сохранить content/profile invalidation и coherent publication.
4. Candidate-bounded query paths с measured recall/equivalence; проверить existing HNSW owner перед новым backend.
5. Supported Python3.14/locked end-to-end promotion/search; HTTP concurrency, true SourceContract admission and DataForge generation checks. Отдельно production workload/capacity profile, если нужен SLA verdict.

Все изменения здесь **proposed**, maintainer risk acceptance и fix implementation отсутствуют. Source/producer identity changes должны соблюдать E02 interlock, но текущий read-only scope ничего не квалифицирует и не закрывает в E02.
