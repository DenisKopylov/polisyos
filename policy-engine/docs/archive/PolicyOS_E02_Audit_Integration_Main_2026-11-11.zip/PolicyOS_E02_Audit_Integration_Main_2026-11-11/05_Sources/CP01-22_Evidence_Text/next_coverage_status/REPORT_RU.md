# PolicyOS: состояние глубокого аудита после checkpoint05

**Аудит продолжается. Ни одного общего PASS, процента завершённости или подтверждения production readiness этот статус не даёт.** База: `f1541ed155f278689be48a8c7ac56c3e200210f7`, tree `29890b967236a8f07e2b0f92a0133ee36883ac49`. Продуктовые исходники, tests/config, E02, реальные данные и deployment не изменялись этим проходом.

## 1. Короткий вывод

Checkpoint05 существенно углубил конкретные механизмы. Уже есть не только карты файлов, но consumer traces, реальные неизменённые тела решений, синхронизированные race/fault controls, persisted SQLite/JSONL/trace/ownership IO, различающие отрицательные примеры и независимые проверки STATE, domain и storage. Повторять их ради нового числа файлов или ещё большей synthetic серии не нужно.

Однако **главный оставшийся слой — реальные соединения между уже проверенными частями**: полный admission и физический outcome, настоящий CAS/restart и конечный читатель, scoped requirement до method/data consumer, persisted registry до исполнимого ресурса, test lane до установленного объекта, backend до клиента/UI. Большинство исполняемых новых проверок остаётся `bounded_probe` в Python 3.12 с explicit seams, а не `native_targeted` в требуемом Python 3.14/locks. Frozen export, source hash, завершённый тематический отчёт и exit 0 измерителя не закрывают это различие.

В порядке ожидаемой новой evidence:

1. **N5 witness/revocation и unknown budget/physical settlement.** Здесь после lifecycle исследования остаётся отдельный существенный пробел A5–A6; callback timeout уже показан, а действительный владелец reservation и безопасного повторения ещё не квалифицирован.
2. **STATE recovery/fanout до actual persisted consumer.** Независимый review усилил STATE-02 до настоящего packet application, но полный HTE originating ack/CAS/currentness ещё не исполнялся. STATE-01 требует real CAS и selected workflow reader после restart, а не ещё один helper replay.
3. **Scoped domain composition и free-grow цепочка.** DC-01 относится к семи отсутствующим graph-derived constructs без explicit declarations. DC-02 не доказывает выбор point estimator; downstream `context_only` создаёт отдельный ещё не замкнутый мост. Два новых registry IDs в памяти не заменяют persisted discover→execute→admit/refuse.
4. **Поддерживаемый профиль, OPA, CI selection и installed distribution.** Это общая enabling-ветка и важный самостоятельный объект аудита. OPA parity особенно важна до deployment новых permissions; реальный policy engine пока не запускался. Пробел native в изученном cloud не доказывает, что подходящей среды нет на всех разрешённых компьютерах.
5. **Backend→generated client→UI.** Эта обязательная цепочка почти не получила нового глубокого прохода. Старые TS/JS AST не являются compiler resolution, build или проверкой unknown/stale/retry semantics.
6. **Реальный CAS/search workload, reuse и структура.** Необходимо установить multiplicity и реальные consumers прежде оптимизации/переносов. Finite exports и logical owners полезнее массового flattening. Это следует делать параллельно по мере готовности dependencies, а не вместо custody/correctness цепочек.

## 2. Что является источником этого статуса

Прочитаны план A–F, все **19** тематических `REPORT_RU.md`/`REVIEW_RU.md`, существовавших к checkpoint05 в перечисленных `next_*`, coverage/surface/reuse/migration карты и README/status checkpoint05. Точный список и SHA-256 — `INPUT_MANIFEST.json`. Параллельно появляющиеся более поздние отчёты не включаются молча в этот срез; их нужно явно добавить следующим delta.

Это **сверка evidence и scope, не новый runtime replay**. Числа и verdict ниже происходят из указанных reports/results/reviews. Ни один дорогостоящий benchmark, pytest или product probe здесь не повторялся. Новый контроль проверяет идентичность входных отчётов, полноту 48 plan IDs/25 roots/8 обязательных цепочек, ссылки и отсутствие циклов в proposed dependencies; он не является независимой перепроверкой всех продуктовых находок. `git status` контролирует tracked edits, но не заменяет полный повтор SHA census.

Иерархия трактовки: независимый review с конкретным counterexample/уточнением ограничивает сильную формулировку первичного отчёта; оригинальное evidence сохраняется. Различаются `indexed_only`, `source_traced`, `bounded_probe`, `native_targeted`, `installed_integration`, `deployed_observation`. Последние три уровня свежими `next_*` результатами не установлены. `PARTIAL` относится к названному scope, не к качеству каждого файла.

## 3. Что уже проверено и чем

Компактный реестр всех 19 отчётов — `EVIDENCE_REGISTER.json`. Здесь намеренно названы и положительные гарантии, и ограничения. Local IDs LIF/NS/FG/NC/AUTH/STATE/LIB/DA/DC/ST/TC нельзя складывать с 12 SYS-семействами и 26 AUD как количество независимых дефектов.
### [next_lifecycle](../next_lifecycle/REPORT_RU.md)

- **Уровень:** bounded_probe + source_traced.
- **Метод:** 5 probes; exact worker/SQL/guards; real Starlette ASGI+HTTPX; synchronized processes and SQLite crash/lease controls.
- **Поддержанный вывод:** Cleanup loses generic pending/live slots on request cancellation; stopped can precede drain; maintenance-stop dispatch window; generic replay is not durable admission. SQL stale-owner/commit fences work.
- **Остаток:** Python/ASGI off lock; synthetic constructors/handlers; default closed guard rejects new calls. No real generic endpoint domain chain, current N5/budget settlement or PostgreSQL.
### [next_scaling](../next_scaling/REPORT_RU.md)

- **Уровень:** bounded_probe + source_traced.
- **Метод:** Trace-only disk corpora 100/1000/10001; deterministic refresh barriers; single schema-valid pending batch; real JSONL IO and process restart; VOI fits counters.
- **Поддержанный вывод:** Mixed record/fingerprint publication; omitted runs beyond cache cap; R×T validity work; full-history repeated fitting. JSONL persists, auto replay absent by observed contract.
- **Остаток:** No full packet/CAS admission or shared HTTP race; no production timing/RSS/soak; no learning-continuity defect without startup contract.
### [next_scaling/REVIEW_RU.md](../next_scaling/REVIEW_RU.md)

- **Уровень:** independent source/instrument review.
- **Метод:** Read final source/instrument/results, no costly benchmark rerun.
- **Поддержанный вывод:** Confirms NS-01 and NS-02, corrects R denominator, rejects permanent staleness/cross-tenant exploit claims.
- **Остаток:** Other series not independently reviewed in full; no native replay.
### [next_reuse](../next_reuse/REPORT_RU.md)

- **Уровень:** bounded_probe + source_traced.
- **Метод:** Exact verifier and CLI, typed shadow comparisons, four-field ref identity, stdlib EntryPoint modes, causal formatter cases and nullable LRU.
- **Поддержанный вывод:** graphlib/entry-point/identity narrow reuse; path loss in shadow metrics; retain domain distinctions. Reconciles 41 earlier family decisions.
- **Остаток:** Not semantic re-review of all 41 or all raw clones; memory nominal identity, producer-spine/extraction, full provider and JAX acceptance remain open.
### [next_structure](../next_structure/REPORT_RU.md)

- **Уровень:** indexed_only + selected bounded_probe/source_traced.
- **Метод:** Named 2895 source/3752 test denominator; exact hidden-edge/reporter/teardown controls; selected semantic tests read.
- **Поддержанный вывод:** Five ratchet floor regressions; filename ratios are not behavior; helper identity cleanup gap; 79 candidate child imports are legitimate facade exports.
- **Остаток:** 36 source+3 test AST unresolved under 3.12; no native CLI/pytest, whole suite leak, frontend or wheel. 494 source matches is not test/defect count.
### [next_auth](../next_auth/REPORT_RU.md)

- **Уровень:** bounded_probe + source_traced.
- **Метод:** Python/Rego vocabulary comparison; exact OPA response decoder, request-scope revocation, artifact owner and DB recorder controls.
- **Поддержанный вывод:** 38 versus 34 permissions; nonboolean allow truthiness; canonical/chart object divergence; distinct API/CAS/SQL/RLS ownership planes.
- **Остаток:** OPA replay exit77 UNRUN; no actual engine, Helm, authenticated API/CAS/DB chain or deployed isolation; no remote exploit established.
### [next_freegrow](../next_freegrow/REPORT_RU.md)

- **Уровень:** bounded_probe + source_traced.
- **Метод:** Six selected surfaces; report corruption, cache/generation, two synthetic metrics, unit meaning and write-conflict controls.
- **Поддержанный вывод:** G2 nonempty ref is insufficient readiness; G1 cache/hash missing content identity; serious NL lacks expanded registry bridge. Candidate/execution/authority remain distinct.
- **Остаток:** Not a complete surface census; no two newly persisted resources through actual discover→execute→admit/refuse chain, native DuckDB or closed-case replay.
### [next_catalog_scale](../next_catalog_scale/REPORT_RU.md)

- **Уровень:** bounded_probe + source_traced.
- **Метод:** Real extracted DTO/method bodies up to 200000 contracts; count instrumentation; promotion/search/empty-binding/ambiguity/staleness controls.
- **Поддержанный вывод:** Alias posting distribution can cause quadratic comparisons; unchanged refresh rebuilds all; output limit does not bound work; explicit empty binding and top1 ambiguity defects.
- **Остаток:** No native HTTP/approval/source admission, DuckDB/HNSW performance, concurrency, profile enrichment or production capacity; current binding guard is separate from enrichment.
### [next_catalog_scale/REVIEW_RU.md](../next_catalog_scale/REVIEW_RU.md)

- **Уровень:** independent source/instrument review.
- **Метод:** Source/results/hashes and final bounded controls reviewed; large benchmark not rerun.
- **Поддержанный вывод:** Confirms mechanisms and real resolve difference k=1 vs k=5; limits exact and HNSW claims.
- **Остаток:** No independent production or native measurement.
### [next_native](../next_native/REPORT_RU.md)

- **Уровень:** profile discovery + bounded_probe.
- **Метод:** Offline no-download interpreter discovery; frozen profile exports and wheel-tag model; exact script/module doctor command-shape control.
- **Поддержанный вывод:** Current cloud lacks discovered Python3.14/lock; bootstrap doctor package-context fault; minimal/runtime modeled wheels present; research has sdist-only entries.
- **Остаток:** No install, lock freshness, import/ABI success, native suite. Connected Mac was listed but not inspected; local blocker is not proof all authorized environments blocked.
### [next_state_owners](../next_state_owners/REPORT_RU.md)

- **Уровень:** bounded_probe + source_traced.
- **Метод:** Finalize fault steps with actual models/trace IO; SQL intent races and process death; generic validity dedupe/reopen/SQL notification seam.
- **Поддержанный вывод:** STATE-01 selected workflow edge missing after recovery; STATE-02 dedupe precedes fanout; domain SQL intent/outbox rollback positive controls.
- **Остаток:** Actual CAS/constructors and application portions substituted; no full sync/async engine, HTE originating ack, hard-kill state suite or native HTTP/Postgres.
### [next_review_state/REVIEW_RU.md](../next_review_state/REVIEW_RU.md)

- **Уровень:** independent bounded replay + source_traced.
- **Метод:** Copied probes rerun; new real packet-state/application/evaluation/transition controls, TTL and changed-payload discriminators.
- **Поддержанный вывод:** STATE-01 exact retry still loses selection; STATE-02 before-write loss survives TTL, after-write stale can recompute; projection TTL is not automatic recovery.
- **Остаток:** CAS payload/storage and epoch overlay still fixtures; no native HTE/HTTP, full publication or independent-process packet restart. SQL race suite not independently rerun.
### [next_library](../next_library/REPORT_RU.md)

- **Уровень:** bounded differential/properties + source_traced.
- **Метод:** W1 producer/evaluator with grid controls; 100-seed bootstrap; 500 quantile cases; 150 AUC cases; actual locked profile metadata and cold imports.
- **Поддержанный вывод:** W1 coordinate loss and LCG degeneration; strata block loss independent of RNG; three quantile definitions; AUC point estimate often should remain.
- **Остаток:** No full World.evaluate/persisted result, real calibration certificate, arch execution, native locked call/CI/adoption or interval validity; current SciPy differs from lock.
### [next_test_confidence](../next_test_confidence/REPORT_RU.md)

- **Уровень:** indexed_only + source_traced + bounded_probe.
- **Метод:** All 3752 test paths; 23 CI files/12 workflows; 20 observations incl unchanged shell, target validator, origin assertions, missing OPA, swallowed exception.
- **Поддержанный вывод:** Nightly path error; installed tests conflict with checkout lane; OPA provisioning gap; benchmark routing/collection/oracle gaps; meaningful semantic tests do exist.
- **Остаток:** No pytest collection/actual selected/skips/hosted runs; quality of authored test is not its fresh successful execution; population provider sometimes synthetic.
### [next_directory_architecture](../next_directory_architecture/REPORT_RU.md)

- **Уровень:** indexed_only + selected bounded_probe/source_traced.
- **Метод:** All 2895 source hashes/depth; selected four-zone paths; 3 filesystem/namespace/delegation controls.
- **Поддержанный вывод:** Runtime application under HTTP; DataForge build in read API; namespace merges are physical splits; useful facades preserved. Migration sketches only.
- **Остаток:** 1297 selected-zone census is not 1297 semantic reviews; 36 parse gaps; no native export manifest/import order, installed migration or refactor.
### [next_domain_composition](../next_domain_composition/REPORT_RU.md)

- **Уровень:** bounded_probe + source_traced.
- **Метод:** Healthcare/credit/joint grammar→rule→graph selectors; method modes; rule extensibility and legal/method refusal controls.
- **Поддержанный вывод:** Lossy projection yields hybrid facets and reduced graph-derived constructs; explicit mode weakened at grammar seam.
- **Остаток:** Read only with next_review_domain corrections; not full scenario resolver, actual method selection consequence, new rule admission, authority or scientific validity.
### [next_review_domain](../next_review_domain/REPORT_RU.md)

- **Уровень:** independent bounded replay + source_traced.
- **Метод:** Byte-identical original replay; true 77-rule catalog; constant domain labels, true reverse text, default budget, explicit declarations and downstream classifier.
- **Поддержанный вывод:** DC-01 persists as 3 rules/7 graph constructs absent without declarations; explicit declarations compensate; all modes→context_only downstream, rollout overrides mode.
- **Остаток:** Actual typed multi-intervention native input, scoped claim→requirement→selector/persisted consumer remains open. No estimator/authority bypass established.
### [next_storage_scale](../next_storage_scale/REPORT_RU.md)

- **Уровень:** bounded subsystem execution + source_traced.
- **Метод:** Real ownership modules/codecs/locks/atomic IO; 50/200/800 claim generations, 1k/10k/50k warm lookups; quota wrapper fixture controls.
- **Поддержанный вывод:** Retained full snapshots Θ(sum B_i), quadratic fixed-claim bytes; warm cache still reads/hashes B; quota wrapper two censuses.
- **Остаток:** Not full CAS transaction/workload, native module import, concurrent processes/power loss or production capacity; ST-03 live callers not found.
### [next_review_storage](../next_review_storage/REPORT_RU.md)

- **Уровень:** independent bounded replay + source_traced.
- **Метод:** All original payload/source hashes checked; small 8/16/32 series, corruption/freshness controls and real exposure-helper/index seam.
- **Поддержанный вывод:** Operational human-decision exposure invokes full history for scope; distinct claim versus artifact denominator; warm blob checks can read generation twice.
- **Остаток:** Large series not rerun; actual sink/store/HTTP path not executed; quota wrapper remains conditional, synthetic small files are not valid artifact population.
## 4. Существенные уточнения, которые нельзя потерять

- **Lifecycle:** raw-store late effect нельзя переносить на default guarded service: закрытый guard отказал новым calls. Уже начавшаяся физическая операция может завершиться позже. Generic response cache не описывает durable Predictive/NL intent; его SQL owner выдержал выбранные race/rollback controls.
- **STATE-02:** сбой до sticky packet write может оставить потерянный event даже после TTL. Если sticky write успел, recompute может вернуть STALE; это не универсальный вечный ACTIVE. RunIndex projection сам не даёт автоматическое TTL-восстановление. Runtime notification ещё не означает опубликованный authoritative claim.
- **Domain:** три rules/семь constructs теряются в данном positive-additive fixture, а не при любой законной композиции. Explicit declarations компенсируют construct list, proposals нет; автоматическая компенсация не доказана. Method facet loss не равен actual estimator execution. Rollout способен заменить любой mode на sequential. Полный scope binding остаётся открытым.
- **Storage:** N — distinct claim updates, не artifacts/runs. Один artifact может давать несколько generations; некоторые unscoped writes не дают их вовсе. Operational exposure действительно обращается к history evidence, но весь HTTP path не исполнен. ST-03 условен до подтверждения wrapper wiring; tiny files не являются валидной популяцией CAS artifacts.
- **Scaling:** измеренные application bytes не равны physical disk IO, `tracemalloc` не равен RSS, elapsed time нескольких synthetic runs не даёт production p95/SLA. Alias quadratic growth зависит от posting distribution. Наличие другого HNSW owner не означает, что весь API ANN-быстрый; обратное также неверно.
- **Tests:** в проекте есть настоящие persisted/removal/corruption tests. Их source quality нельзя обнулить слабым mirror ratchet, но нельзя и считать свежим execution PASS. 494 — filename source matches; 32 benchmark definitions — исходные definitions, не runtime parametrized cases.
- **Authority:** compiled, search rank, valid signature, byte availability и helper equality не создают current authority. Существующие source/method/legal refusal guards должны сохраняться. NATIVE-01/CI/config failures не дают права обходить guards ради green.

## 5. Остаток по направлениям плана

Полный поэлементный статус **48** заданий находится в `PLAN_STATUS.json`; неизменённые unchecked boxes исходного плана сами по себе не являются актуальной оценкой прогресса.

| Направление | Реальный достигнутый уровень | Что не закрыто |
|---|---|---|
| A. Ownership | Worker/request/SQL, три persistent flows, selected authority и review packet application | N5 release/revoke, budget settlement, whole actual recovery/admission, полный owner/private-state denominator |
| B. Scaling | Сильные named counters/formulas, несколько размеров, selected races/IO/heap и controls | Real CAS/admitted workload multiplicity, concurrent graph, actual long-lived release/soak; capacity budgets не заданы |
| C. Reuse | Выбранные contract matrices и differential candidates; 41 прежних decisions reconciled | Locked memory identity, producer-spine/extraction seams, provider numerical policy/JAX, remaining priority families |
| D. Structure/tests/docs | Full source/test census и selected semantic source reviews/bounded gate controls; 4-zone owner proposals | Native collection, finite exports/runtime imports, frontend, full docs/generated/shipped closure, actual wheel/sdist |
| E. Free-grow | Шесть поверхностей, data-only local additions, readiness/cache/taxonomy/semantic controls | Complete surface map и две persisted actual zero-code chains, actual adapters/conformance/consumers, historical closed-case replay |
| F. Integration | Несколько важных source chains и bounded cross-owner joins | Восемь обязательных цепочек всё ещё PARTIAL/UNRUN; native/installed/API/UI/release object identity не замкнуты |

Это не значит «всё осталось с нуля»: многие корневые механизмы уже достаточно доказаны для remediation decision. Но пользователь просил продолжать глубоко, поэтому остановиться сейчас на переупаковке findings было бы преждевременно.

## 6. Все 25 product roots и не-source поверхности

`ROOT_COVERAGE.json` переносит **именованный** denominator из `next_structure`, не пересчитывает LOC. 2 895 source `.py` = 25 roots плюс один root initializer. Python 3.12 не разобрал 36 source и 3 из 3 752 test files; это совместимый с 3.14 syntax, не silent zero coverage и не product syntax failure. Source-extracted spans из такого файла могут быть проверены локально, но это не делает весь файл native-parsed.

Статус ниже относится только к свежему углублению `next_*`; прежний аудит остаётся входом. `indexed_only_in_next_pass` не утверждает, что root никогда не анализировался. Ни одна строка не означает semantic review каждого файла root.

| Root | Свежая глубина | Точный срез |
|---|---|---|
| `berl` | indexed_only_in_next_pass | Named syntax/import inventory and selected test/ratchet references only; no dedicated fresh semantic owner-to-consumer drill-down established by these next reports. Prior audit findings are retained, not requalified. |
| `calibration` | indexed_only_in_next_pass | Named syntax/import inventory and selected test/ratchet references only; no dedicated fresh semantic owner-to-consumer drill-down established by these next reports. Prior audit findings are retained, not requalified. |
| `common` | bounded_dependency_only | Canonical codec/atomic IO loaded in storage; utility dependency is not full common owner audit. |
| `core` | selected_bounded_probe | SQL-independent CAS ownership, run finalize/recovery, audit verifier/CLI, cache/ref identity, authz response. |
| `corpus` | indexed_only_in_next_pass | Named syntax/import inventory and selected test/ratchet references only; no dedicated fresh semantic owner-to-consumer drill-down established by these next reports. Prior audit findings are retained, not requalified. |
| `data_forge` | selected_bounded_probe | Catalog source/candidate traces, shadow comparisons, read/build/cache ownership; actual DuckDB native integration unrun. |
| `data_requirement` | selected_bounded_probe | Actual construct selectors and compile_obligation_basis owner with injected dependencies, not full persisted resolver. |
| `ddm` | selected_bounded_probe | Sampling helpers and AUC point/interval wrapper; calibration/publication full chain unrun. |
| `evidence` | indexed_only_in_next_pass | Named syntax/import inventory and selected test/ratchet references only; no dedicated fresh semantic owner-to-consumer drill-down established by these next reports. Prior audit findings are retained, not requalified. |
| `fabric` | selected_bounded_probe | Metric/catalog/search/promotion bodies and conditional quota wrapper; HNSW real DB and connectors unrun. |
| `foundry` | selected_bounded_probe | Method selection, refs/entrypoints, VOI/history, W1/quantiles; no full scientific/JAX/installed acceptance. |
| `ir` | selected_bounded_probe | Metric taxonomy/meaning/units, typed records and mode contracts; full PolicySpec native input unrun. |
| `legal_requirement` | selected_bounded_probe | Two domains legal requirements; not legal source admissibility/authority. |
| `lex` | selected_source_traced | Qualified claim/source relation and authority refusal reviewed; full Lex execution not performed. |
| `method_requirement` | selected_bounded_probe | Requirement compiler/selector cases, claim-method transfer remains open. |
| `obligation_graph` | selected_bounded_probe | Exact matcher/budget/frontier/growth controls; no new governed-rule admission. |
| `obligation_rules` | selected_bounded_probe | Real 77-rule catalog source builder/hash in review; finite seed coverage not domain completeness. |
| `participation_requirement` | integration_reference_only | Referenced by workspace requirement chain; no dedicated fresh semantic/behavior pass identified. |
| `pdc` | indexed_only_in_next_pass | Named syntax/import inventory and selected test/ratchet references only; no dedicated fresh semantic owner-to-consumer drill-down established by these next reports. Prior audit findings are retained, not requalified. |
| `policy_grammar` | selected_bounded_probe | Normalization/facets/modes, native PolicySpec/scoped consumer join unrun. |
| `runtime` | selected_bounded_probe | Lifecycle/request/SQL/index/auth/capabilities and many source joins, not whole application native acceptance. |
| `schemas` | indexed_only_in_next_pass | Named syntax/import inventory and selected test/ratchet references only; no dedicated fresh semantic owner-to-consumer drill-down established by these next reports. Prior audit findings are retained, not requalified. |
| `scholar` | indexed_only_in_next_pass | Named syntax/import inventory and selected test/ratchet references only; no dedicated fresh semantic owner-to-consumer drill-down established by these next reports. Prior audit findings are retained, not requalified. |
| `scholar_requirement` | indexed_only_in_next_pass | Named syntax/import inventory and selected test/ratchet references only; no dedicated fresh semantic owner-to-consumer drill-down established by these next reports. Prior audit findings are retained, not requalified. |
| `scientist` | selected_bounded_probe | Finalize producer trace, validity packet owner, VOI and packet/export boundaries; engine/full publication not run. |

Не-source поверхности:

- **tests: named_inventory + selected_source/bounded_controls.** 3752 .py, 3749 parsed; no native collection/execution manifest. Следующий пакет: WP-07.
- **tools/CI: selected_source/bounded_controls.** 23 CI files/12 root workflows, 20 observations; literal target existence is not execution. Следующий пакет: WP-07.
- **architecture/contracts: selected_source/bounded_controls.** Import direction/narrowing/test ratchets/4-zone owners; dynamic graph/export identity incomplete. Следующий пакет: WP-10.
- **frontend/apps/packages: UNRUN_FRESH.** Earlier 1340 TS/JS syntax AST retained; no compiler resolution/typecheck/client/UI current pass. Следующий пакет: WP-08.
- **docs: selected_source_only.** Active CONTRIBUTING/TESTING/quality/PV/custody/README discrepancies; no full current lifecycle/freshness classification. Следующий пакет: WP-10.
- **generated/evidence families: PARTIAL_INHERITED.** Earlier registry/count corrections retained; no fresh directory-aware outputs→shipped reconciliation. Следующий пакет: WP-10.
- **release/ops/deployment: source/bounded_only.** OPA vocab/packs and namespace paths; engine/Helm/Terraform/canary actual object attribution unrun. Следующий пакет: WP-07,WP-10.
- **installed distribution: UNRUN.** Frozen exports/wheel tags and installed-test source are not actual wheel/sdist build/import evidence. Следующий пакет: WP-07.
- **live DB/providers/production: OUT_OF_SCOPE_OR_SEPARATELY_AUTHORIZED.** Synthetic SQLite only; PostgreSQL/RLS actual backend not qualified. E02, live acquisition, deployments and migrations not performed. Следующий пакет: Explicit separate safe profile/scope only.

## 7. Приоритетные work packages с новой evidence

Подробная машинная программа — `WORK_PACKAGES.json`. Это **работы по дальнейшему аудиту**, не незапрошенный план реализации исправлений. Priority здесь означает порядок исследования, а не новую severity finding. Условия остановки требуют достаточного результата/контрпримера или точного blocker, а не исправленного продукта. `native_phase` dependency не запрещает начать source/caller trace сейчас.
### WP-00. Открыть поддерживаемый профиль

**Порядок:** first_parallel. **Зависимости:** нет. **План:** F3, F7, D3, D6.

Проверить существующие разрешённые среды, точный checkout/lock, Python 3.14.x, uv 0.9.21, необходимые extras; отдельно OPA, Node22 и DB/backend capabilities. Использовать уже установленное, не скрывать install/sync внутри audit.

**Что добавит:** Новый результат — actual normal imports и возможность targeted tests вместо AST namespace seams; либо точный blocker конкретной команды/среды, а не blanket отсутствие native.

**Различающие проверки:** Источник SHA/lock/dependency manifest; direct import; safe doctor --list-surfaces script/module; actual --collect-only выбранных suites. Missing dependency/tooling отдельно от product failure.

**Окончание исследования:** Каждому следующему пакету назначен рабочий профиль либо конкретный невосполнимый в текущем разрешении blocker. Не требуется полный research install и не нужен full suite ради косметического green.

**Ограничения:** Local BLOCKED подтверждён только для уже изученного cloud. Connected Mac в источнике не обследован. Новая установка, доступы или DB создание оцениваются отдельно; E02/provider/jobs не запускаются.
### WP-01. Связать физическое завершение и authority

**Порядок:** first_parallel. **Зависимости:** WP-00:native_phase. **План:** A1, A5, A6, A7, B4, F2, F4.

Довести N5 issuance→capture→seal→consumer→release/revoke и unknown budget/timeout до одного реального owner trace. Проследить reservation, permit/witness и late-result settlement через terminal/reopen.

**Что добавит:** Самый существенный ещё не закрытый ownership вопрос: сохраняются ли физическая занятость и unknown outcome после логического timeout, кто вправе разрешить повтор, как old/copy/foreign witness теряет current authority при сохранённом историческом receipt.

**Различающие проверки:** До native можно закончить caller/owner/state matrix и safe body controls. Затем bounded actual imports без физических N5 jobs: event/barrier operation, completion/timeout/revoke/restart, old/copy/foreign witness, capture graph GC после разрешённого release. Сравнить terminal status, reservation, authority и historical read отдельно.

**Окончание исследования:** Определён consumer и точное допустимое/недопустимое повторение; observed нарушения либо подтверждённые guards с negative control; оставшиеся native/physical ограничения названы. Дефект не обязан быть исправлен для окончания исследования.

**Ограничения:** Запрещено запускать E02/N5 numerical jobs, настоящий provider effect или очищать реальные ledgers. Если невозможно исполнить реальный issuance без таких эффектов, сохранить точный blocker и source trace, не выдавать fixture за authority.
### WP-02. Довести recovery до конечного читателя

**Порядок:** first_parallel. **Зависимости:** WP-00:native_phase. **План:** A1, A3, A4, A7, F1, F2, F4.

STATE-01: real FileSystemCAS + sync/async producer→journal→terminal→Runtime reader. STATE-02: actual dependent packets/CAS + Runtime HTE outbox→generic fanout→notification→originating ack; sibling mark_packet_trigger.

**Что добавит:** Снимет наиболее важные оставшиеся substitutions и определит реальный downstream outcome: потерянный selected workflow ref, незавершённый target denominator и возможность преждевременного ack. Не повторит уже доказанный toy dedupe.

**Различающие проверки:** Fault до/после каждого durable step, до/после sticky packet write, between targets, evaluation/notification failure; independent-process restart/kill; post-TTL read; same-key changed payload; target-set drift; legacy journal; multiple workflow outputs. Positive non-workflow и SEMANTIC_EPOCH guards сохранить.

**Окончание исследования:** Каждый high-impact claim привязан к real persisted consumer либо опровергнут/сужен. Есть actual ack/public surface result и exact target denominator. Не требуется получить PASS исправленного продукта.

**Ограничения:** Не переносить SQL atomicity на CAS. Никаких production outbox replay/repair, PG migrations или физической повторной работы. Полнота public claims отдельно от candidate HTE.
### WP-03. Замкнуть HTTP lifecycle и intent

**Порядок:** next. **Зависимости:** WP-00:native_phase. **План:** A2, A3, A4, B2, B5, F1, F2.

Locked middleware/container и реальные generic route/domain consumers; сравнить generic response replay с NL/Predictive durable admission. Добавить shared RunIndex HTTP concurrent refresh и N>cap с настоящими manifests/owner-map.

**Что добавит:** Перенесёт LIF-01/02/03/04 и NS-01/03 из seams на реальное application composition и установит, какой route действительно требует durable reservation. Закроет недоказанное использование generic cache для effect.

**Различающие проверки:** Cancellation до headers/при body/decode/persist; disconnect отдельно от task cancellation; maintenance/lease/invocation barriers; borrowed/owned guards; death до/после domain effect; same/different payload; failed leader; exact/list/batch/full tenant guards.

**Окончание исследования:** Ни общий exactly-once, ни physical stop не заявлены по HTTP response. Для выбранных routes известны terminal/recovery owner и реальные отказные/положительные результаты; stale generation/omission проверены без синтетической смены tenant.

**Ограничения:** Нужны native ASGI/locked dependencies. Все stores/tmp локальны; не использовать реальные provider/jobs. Полный PostgreSQL профиль отдельный, SQLite результат на него не переносится.
### WP-04. Проследить scoped композицию требований

**Порядок:** first_parallel. **Зависимости:** WP-00:native_phase. **План:** E3, E4, E6, F1, F2, F4.

Typed multi-intervention PolicySpec→grammar→complete obligation candidate/bundle/frontier/deferred sets→component-scoped claim ledger→full resolver inputs/specs→method requirement/selector.

**Что добавит:** Проверит важное новое звено после domain review: explicit identification mode может теряться не только при scalar emission, но и при context_only decomposition. Проверит сохранение population/time/geography/instrument вместо одного union strings.

**Различающие проверки:** Два независимых компонента отдельно/вместе, reversal, same-domain label, default budget; explicit declarations vs proposals; все 6 modes с/без rollout, смешанные modes; удалить компонент/scope/source proof; typed conflict/unsupported допустим. Проверять full resolver, а не только graph helper.

**Окончание исследования:** Установлено, на каком реальном consumer ограничение теряется/сохраняется или даётся typed refusal; конечное требование и его scoped data selection прослежены. Union ожидается только для выбранного positive-additive случая, не закон для любой композиции.

**Ограничения:** Нет клинической/финансовой/scientific validation, live acquisition или estimator jobs. Case compiled не даёт authority; explicit declarations не доказывают автоматическую компенсацию.
### WP-05. Проверить zero-code цепочку ресурсов

**Порядок:** first_parallel. **Зависимости:** WP-00:native_phase, WP-04:scope_contract. **План:** E1, E2, E3, E4, E5, E6, E7, A7, F1.

Завершить surface map; выбрать минимум два действительно разных корректных ресурсных входа, добавить только admitted synthetic data/registration вне source и провести persisted discover→existing adapter read/invoke→admit/refuse→served consumer→reopen.

**Что добавит:** Заменит in-memory rule/metric extension и readiness booleans фактической проверкой Rule12. Соединит G1 content identity, G2 actual method registry и serious NL early taxonomy, не добавляя new hardcoded ID.

**Различающие проверки:** Unchanged product hashes; two independent resources; unknown/wrong type/meaning/conformance; stale index/add/remove/same-row-count replacement; source/alias/HNSW generation where used; revoke/reopen; new corpus не меняет historical closed-case replay. Если expected adapter/gate отсутствует — точный missing bridge, не успешная заглушка.

**Окончание исследования:** По выбранным surface доказано discoverable/executable/admitted authority раздельно либо доказано отсутствие конкретного звена. Остальные agents/tools/claims/pickers явно перечислены со статусом, без обещания универсального роста.

**Ограничения:** Native DuckDB/index dependencies может не быть. Изменять только audit-local синтетические данные; реальные источники/сетевые providers/new credentials не нужны. Persisted rule admission не подменять предложенным статусом.
### WP-06. Измерить реальные storage и search joins

**Порядок:** next. **Зависимости:** WP-00:native_phase, WP-02:validity_contract, WP-05:resource_contract. **План:** B1, B2, B3, B4, B5, B6, B7, F2.

На bounded реальном FileSystemCAS посчитать default/view/blob/lineage claim multiplicity и total byte reads полного operational exposure/read graph; actual admitted pending batch; persisted catalog/approved promotion/hot refresh. ST-03 сначала только reachability decision.

**Что добавит:** Получится workload denominator, которого сейчас нет: claims на реальную операцию, Q integrity checks на request, actual target denominator и query/provider costs. Это полезнее повтора 200k catalog или 50k synthetic claims.

**Различающие проверки:** 3 bounded sizes, counters прежде timing, cold/warm/current/changed, concurrent instances, read/write/crash publish, same-size/same-mtime corruption, missing ancestor, exact profile/cell, failed refresh, empty bindings и known ambiguity. HNSW recall/SQL plan только при реальном владельце/профиле.

**Окончание исследования:** Capacity hypotheses привязаны к реальному graph, защитам freshness/ownership и именованному workload; условные поверхности отмечены. Optimization design может сравнивать no-change, existing snapshot reuse и narrow change без product patch.

**Ограничения:** Не удалять history, не выключать hash/tenant guards, не обещать SLA. Production p95/throughput/RSS/soak остаются OUT_OF_SCOPE без отдельной задачи. Quota synthetic members не валидные artifacts.
### WP-07. Квалифицировать OPA CI и поставку

**Порядок:** next. **Зависимости:** WP-00. **План:** D3, D5, D6, D9, F3, F5.

Actual OPA decisions canonical и chart/rendered pack; server route/resource parity. Python3.14 actual test collection/lane selection, installed-only isolation; wheel и rebuilt sdist contents/import origins/resources. Отдельно safe doctor/nightly path controls.

**Что добавит:** Получится связь requirement→test→selected executable lane→shipped object; устранит ложный переход от source теста/uv export к native qualification. Установит actual policy behavior вместо set-условия и OPA stub.

**Различающие проверки:** 38 permissions/4 missing grants, foreign tenant/cell/stale attempt, strict malformed response transport; rendered exact pack hash; actual collected/selected/skipped manifest; isolated fresh installed reader/removal test без запуска E02 worker jobs; compare wheel/sdist selectors и package data.

**Окончание исследования:** Каждый выбранный claim имеет настоящий engine/gate/installed-origin результат или exact blocker. Известный failure сохраняется как finding, не правится ради общего green. Hosted run отдельный источник, не обязательное создание CI dispatch.

**Ограничения:** No dependency installation/CI dispatch/deployment автоматически. OPA/Helm нужны существующие или отдельно разрешённые. Installed E02 profile может требовать запрещённую numerical работу; тогда выполнять только безопасные artifact/import checks и явно ограничить acceptance.
### WP-08. Проверить backend client UI контракт

**Порядок:** next. **Зависимости:** WP-00:Node22, WP-07:API_contract. **План:** D2, E1, E2, F1, F4, F6.

Выбрать high-impact UI workflows по найденным backend нарушениям: pending/unknown cancellation, incomplete/stale catalogue, capability availability. Проследить API schema→generated client→UI state и повтор действия.

**Что добавит:** Это практически не углублённая обязательная плоскость плана: прежние 1340 syntax AST не являются resolution/build/behavior и не показывают, как пользователь видит unknown/stale/partial.

**Различающие проверки:** Node22 frozen links/typecheck/build, relevant generated-client drift, loading/error/stale/unknown/partial/no-authority cases; UI не должна превращать failure в success или предлагать опасный повтор. Pickers принимают новые ресурсы только в заданной posture; fixed app chrome не объявлять allowlist дефектом.

**Окончание исследования:** Selected API→UI chains имеют реальные type/behavior/removal controls и явную provenance. Неисследованные apps/packages названы, UI build не выдан за runtime browser/deployed pass.

**Ограничения:** Browser/live deploy отдельный результат. Не изменять frontend source и не подключать реальный backend со side effects. Сначала source/contract trace, затем разрешённый local profile.
### WP-09. Квалифицировать reuse через владельцев

**Порядок:** next. **Зависимости:** WP-00:native_phase. **План:** C1, C2, C3, C4, C5, C6, C7, C8, C9.

Приоритет — nominal memory contracts/producer-spine/extraction и provider-dependent scientific decisions; затем World W1 result serialization, bootstrap/calibration entrypoints, quantile caller policy, low-risk graphlib/entry-point/ref identity.

**Что добавит:** Снимет реальные adoption risks: FQN/class identity, optional dependencies, threshold/NaN/missingness, historical bytes/seed identity; отделит полезный kernel от owner решения. Новые clone counts ничего не добавят.

**Различающие проверки:** Locked normal imports, nested DTO producer/consumer, reverse/fresh import orders, exception restoration/overlap monkeypatch seams; current permitted numeric envelope, provider present/absent, full result/ref/version and error outcomes. JAX PRNG/pytree/JIT/vmap/gradient только если рассматривается конкретная замена, иначе retain/insufficient_evidence.

**Окончание исследования:** У каждого приоритетного кандидата canonical owner/retain rationale, actual consumers, migration risks и discriminator. Не требуется adjudicate все raw groups или заменять любой self-written kernel.

**Ограничения:** Без тяжёлого training/solver/E02, новых dependency installs и product substitution. Library differential в audit namespace не равен adoption; отсутствие живого consumer снижает priority (например bootstrap public helpers).
### WP-10. Связать структуру docs и release identity

**Порядок:** later_parallel. **Зависимости:** WP-00:native_exports, WP-07:distribution, WP-01:ownership_contract. **План:** A8, D1, D7, D8, D9, D10, F4, F5.

Actual finite export/object manifests для packet/control/causal facades; private-state access и owner graph; active docs→machine consumers→directory-aware generated outputs→wheel/frontend/ops shipped objects. Cell identity render и canary object attribution отделить от deployment.

**Что добавит:** Превратит migration sketch в проверяемый change envelope и выявит ещё скрытые document/generated/release dependencies, не обещая, что перенос файлов чинит lifecycle.

**Различающие проверки:** Fresh import permutations, class/FQN/pickle/legacy alias equality, source-root derivation and expected-consumer code identities; failure gates still fail; allowed exports vs arbitrary dir; rendered Helm/Terraform name/collision and foreign process on canary port в безопасной локальной fixture.

**Окончание исследования:** Предложены только минимальные границы с сохранением одного transaction/resource owner; active references и immutable historical evidence отделены. Ни bulk flatten/delete, ни CI edits не выполнены.

**Ограничения:** Полная deploy/migration не нужна и не разрешена этим scope. Docs/generated denominator не приравнивать к tracked files; installed payload требует фактической сборки из WP-07.
### WP-11. Закрыть пробелы и свести доказательства

**Порядок:** continuous_then_final. **Зависимости:** WP-01, WP-02, WP-03, WP-04, WP-05, WP-06, WP-07, WP-08, WP-09, WP-10. **План:** A1, D1, E1, F1, F7.

Для roots без fresh semantic next-pass выполнить риск-ориентированный owner/entrypoint/consumer trace; затем дедуплицировать SYS/AUD/local IDs, включить reviews/counterevidence, провести независимые discriminators ключевых новых claims, проверить финальную упаковку.

**Что добавит:** Не даст спрятать berl/corpus/evidence/pdc/schemas/scholar/requirement siblings за общей AST картой и не позволит посчитать одно нарушение несколько раз. Сynthesis превратится в конкретную программу изменений и честные остатки.

**Различающие проверки:** У каждого selected root/port: contract→producer→persistence→consumer→failure gate либо точный OUT_OF_SCOPE; depth выбирается по custody/correctness reachability, не LOC. Независимый review новых high-impact mechanisms; receipts/source hashes, missing links, historical attribution и pin-specific delta.

**Окончание исследования:** Все критерии раздела 9 плана выполнены на согласованном scope либо имеют точный неперекрываемый blocker; final packet self-contained по выбранному evidence. Нельзя закрыть только из-за наличия текста/таблицы; audit completion ≠ remediation/release/E02.

**Ограничения:** Не требуется доказать отсутствие ошибок во всех файлах. Не переносить pin на fresh main без delta; final all-source unchanged verification выполнить отдельно, а не считать git status достаточным hash census.
## 8. Dependency order и разумная параллельность

1. **Сейчас, параллельно:** WP-00 ищет/квалифицирует уже доступную supported среду. WP-01, WP-02, WP-04 начинают недостающие owner/caller joins и bounded controls без тяжёлых jobs. WP-05 делает complete surface map и выбор двух actual persisted resource flows. WP-08 начинает source API/client/UI trace. Это полезная работа, даже если native пока блокирован.
2. **Как только доступен нужный профиль:** WP-02 actual CAS/fault/reopen; WP-03 locked ASGI/domain/RunIndex; WP-04 typed scoped compiler chain; WP-05 native persisted discover/adapter controls. WP-07 OPA идёт сразу при доступности engine, не ждёт всего рефакторинга: canonical permission mismatch связан с действующими protected routes.
3. **После определения реальных contracts:** WP-06 измеряет causal workload graph, а не новый произвольный scale. WP-09 квалифицирует priority reuse candidates; независимый safe graphlib/identity test не обязан ждать полного lifecycle. WP-07 actual distribution и WP-08 generated-client/UI phase связываются одним API/schema pin.
4. **После native export/distribution и ownership facts:** WP-10 проверяет proposed finite boundaries, docs/generated/release identity. Не начинать переносы source в рамках этого аудита. Logical contracts можно уточнять раньше, но migration acceptance нельзя заявлять заранее.
5. **Постоянно и в конце:** WP-11 ведёт дедупликацию/остатки. Final synthesis только после содержательных цепочек, независимого review существенных новых claims и проверки пакета. Новая сильная finding не порождает бесконечный review-of-review: один независимый discriminator и ясная граница достаточно.

Dependencies в JSON — частичный порядок; phase suffix означает, что source work можно выполнять до его достижения. Нативная среда — общий enabling шаг, а не предлог прекратить всё чтение. Нельзя удваивать большой benchmark, пока уже существует пригодный artifact.

## 9. Что не стоит делать следующим

- Не пересчитывать все files/LOC/clone clusters и не выводить процент готовности из 29 934 tracked paths, 2 895 Python modules, 19 отчётов или числа findings.
- Не запускать второй 200k catalog/50k claim workload без новой гипотезы, альтернативного owner или discriminating correctness control.
- Не принимать directory migration за исправление shutdown/transaction/authority, не flatten-ить дерево и не складывать domain logic в общий `utils`.
- Не расширять LRU/global cache/TTL shortcuts до доказанной invalidation/ownership семантики; не удалять generations/custody history ради performance.
- Не ставить полный research stack или запускать full pytest/E02/provider jobs автоматически ради формального native green. Нужен минимальный профиль под выбранную проверку и отдельная оценка side effects.
- Не выдавать copied historical receipts, frozen exports, source tests, source hashes или чистый git status за current installed/deployed acceptance.
- Не бесконечно плодить локальные finding IDs на каждом symptom/consumer; новые root mechanisms и deepening existing должны различаться.

## 10. Критерии окончания аудита

**Сейчас они не выполнены в совокупности.** Окончание допустимо, когда выполняются именно критерии раздела 9 плана, с такими практическими проверками:

1. Все A–F имеют содержательный outcome; каждый оставшийся blocker называет точную команду/среду/данные/нехватку разрешения, объясняет влияние и не подменяет доступную независимую работу. Лишь отсутствие Python3.14 в одном cloud не является доказанным неперекрываемым blocker.
2. Все 25 roots и основные не-source поверхности имеют явную глубину и exclusions. Для слабо рассмотренных приоритетных owners выполнен risk-based entrypoint→consumer trace либо обосновано исключение; наличие generic status row не закрывает semantic обязательство само по себе.
3. Priority ownership/scaling/reuse claims достигли реального consumer и имеют distinguishing positive/negative/failure controls. Чем сильнее consequence, тем меньше незакрытых substitutions на решающем пути. Нативные ограничения сохраняются отдельно, не исчезают после независимого bounded review.
4. По выбранным free-grow surfaces показан actual zero-code discover→execute→admit/refuse путь, freshness/recall и historical replay, либо доказан точный отсутствующий bridge. Неудачный продуктовый путь тоже завершённая проверка, если denominator и причина установлены; его нельзя назвать успешной capability.
5. Requirement→producer→persisted consumer→test→gate→shipped object согласованы для выбранных high-impact цепочек. Written test и реально исполненный native test не смешиваются. Frontend chain нельзя закрыть syntax inventory.
6. SYS/AUD/новые local IDs дедуплицированы; independent reviews, guards, rejected overclaims и несогласия включены. Не требуется квота новых defects и не требуется доказать отсутствие любых ошибок.
7. Native/installed/deployed статусы и неисполненные commands явны. Production load/scientific validation/live deployment могут оставаться явно вне agreed scope; не нужно исполнять запрещённую физическую работу для окончания документационного scope. Но нельзя задним числом исключить неудобный mandatory join лишь для слова «готово».
8. Существуют единый findings register, reuse decisions, rejected signals, coverage/flows, proposed work/remediation sequence, independent review и самодостаточный проверенный пакет с нужными выбранными evidence bytes. Hash недоступного старого artifact не заменяет его доступность.
9. Source identity/read-only статус проверены финально; новая remote версия, если читается, проходит отдельный bounded delta. Оставшиеся findings могут быть неисправленными: завершение аудита не значит завершение remediation, закрытие E02, одобрение риска или разрешение выпуска.

**Следующий содержательный checkpoint должен принести результаты этих joins, а не только ещё одну сводку текущих отчётов.** Этот status artifact нужен, чтобы направить продолжение и не потерять реальный остаток.

## 11. Артефакты и проверка этого status-пакета

- `EVIDENCE_REGISTER.json`: все 19 reports/reviews, метод и граница.
- `PLAN_STATUS.json`: все 48 A–F items; никаких file-based процентов.
- `FLOW_STATUS.json`: 8 обязательных integration chains и их remaining joins.
- `ROOT_COVERAGE.json`: 25 roots + отдельные non-source surfaces.
- `WORK_PACKAGES.json`: 12 packages, зависимости, новая evidence и research stop conditions.
- `INPUT_MANIFEST.json`: исходные документы и SHA-256 на момент составления.
- `VALIDATION.json`: полнота связей, inputs unchanged и pinned tracked-source status; это проверка данного сводного артефакта, не повтор product probes.
- `ARTIFACT_MANIFEST.json`, `SHA256SUMS.txt`: integrity набора.

Повтор сборки: `python policyos_deep_audit/next_coverage_status/build_status.py`. Он пишет только эту audit-папку, читает существующие reports/metadata и git identity/status. Product tests, installs, providers, deployment и remote refs не вызываются. Для передачи вне workspace необходимо включить указанные исходные отчёты/evidence или проверенные ссылки на предыдущие checkpoint packages; один этот статус не является самодостаточным runtime reproducer.
