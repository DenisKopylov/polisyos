# PolicyOS: сквозной Analysis API и custody научных sidecars

База `f1541ed155f278689be48a8c7ac56c3e200210f7`, source read-only. Это отдельный проход после checkpoint09: Runtime Analysis API → Foundry feedback/attractor projection → actual filesystem CAS → fresh Runtime reader → IR ABM sidecar. Предыдущие STATE, publication и registry findings не пересчитываются.

**Итог: PARTIAL.** Два новых интерфейсных дефекта и три ограниченных observations. Действительно исполнялись DTOs, численные helpers, Runtime service, Foundry producers/readers, FileSystemCAS, IR attach/read и fresh subprocess. Поддерживаемый Python 3.14, authenticated ASGI, физический solver, deployed tenant policy, Scientist claim issuance и production occurrence не квалифицированы. `available` и `numerically_supported` не равны научной истине или разрешению публикации.

## 1. Главный результат: CS-01, Jacobian другого solve меняет persisted stability

**P2, высокая уверенность в локальном cross-service механизме.** Existing evidence owner уже хранит нужное отношение, но потребитель его не использует.

- Foundry `_persist_feedback_jacobian`, `execute/api.py:2869–2914`, сохраняет численный diagnostic с lineage на конкретный feedback trace.
- `_persist_feedback_result:3062–3165` сохраняет `FeedbackSolveResult.jacobian_diagnostics_ref` и соответствующий manifest input `artifact.feedback_jacobian_diagnostics_ref`.
- Runtime `services/attractors.py:57–74` читает feedback, но выбирает diagnostic только из независимого request field. При отсутствии field берётся `None`, при наличии читается выбранный caller ref. Нет сравнения с ref в feedback, его trace, dimension или выбранным solution.
- Foundry `build_feedback_attractor_analysis_result:510–572` передаёт diagnostic в `_fixed_point_attractor_from_state:1205–1240`. Последний берёт `spectral_radius` и строит `local_class`, не устанавливая связь со state. `_local_class_from_spectral_radius:1241–1258` при 0.5 возвращает `asymptotically_stable`, при 2.0 — `unstable`.
- `persist_attractor_analysis_result:651–688` заново выбирает точные upstream profiles; `_result_input_refs:1279–1297` включает model/simulation/exec-plan/feedback, но не использованный явный diagnostic. Его значения остаются inline в output; его exact artifact/profile/trace identity потеряна.

### Различающий эксперимент

`results.json#/results/CS_01_jacobian_source_join`, основной probe exit 0:

1. Synthetic audit-owned fixed point x=0, размерность 1. Настоящий `summarize_jacobian([[2]])` и неизменённые producer bodies записали собственный diagnostic и feedback с точным отношением между ними. Физический solver не запускался.
2. Без request diagnostic API service сохранил `local_class=unknown`, хотя feedback содержит собственный ref.
3. С собственным ref сохранил `unstable`.
4. С diagnostic **другого trace**, radius=0.5, сохранил `asymptotically_stable`. Это воспроизведено и при той же размерности 1, и при заведомо несовместимой размерности 2. Одна проверка dimension не закрывает механизм.
5. Во всех случаях сохраняется один logical `analysis_id`, но CAS payload identities различны. Это не коллизия content-addressed storage. Логический ID здесь не полный identity научной конфигурации.
6. Выходной manifest не содержит ref использованного чужого diagnostic. Fresh process перечитал actual CAS, получил stable/diagnostic dimension=2. Это не только transient Python object.

Refusal controls работают: missing diagnostic, отсутствующий selected profile, invalid trajectory combination и dimension=0 отвергаются. Тем самым проблема не в том, что CAS принимает любые байты: пропущен **join между двумя валидными артефактами**.

### Дальше по evidence bridge

Настоящий neutral `build_abm_result_from_simulation` оставляет `bifurcation_report.status=not_available`, даже если ему передан analysis ref. Это правильное разделение reference presence и admitted availability.

Настоящий `attach_abm_bifurcation_report_ref`, `foundry/analysis/attractors.py:691–757`, разрешает simulation и analysis, проверяет exact simulation ID/profile в payload и единственный совпадающий manifest input, затем сохраняет IR ABM report со status `available`. Persisted неверно связанный Jacobian проходит этот **иной** guard. Fresh IR reader сохраняет `available`. Другой simulation и удалённый simulation lineage отвергаются.

Это не заявленный обход scientific/institutional approval. Этот attach подтверждает availability и selected simulation relation, не заново устанавливает происхождение Jacobian. Полный literal census нашёл определение/export attach и tests, но не production caller; Runtime AnalysisService этот attach не вызывает. Нельзя рисовать автоматический production путь API → public policy signature. Downstream Scientist/publication authority этого артефакта не установлен.

### Направление ремонта и acceptance

Сохранить Foundry producer как владельца solved-state/diagnostic relation. Runtime должен использовать сохранённый ref; явный override требует exact relation или отдельного типизированного reanalysis contract. Проверить selected profile, trace/solution/variable order/dimension и state point, сохранять exact использованный ref в output/manifest. Не копировать eigenvalue logic в HTTP layer и не ослаблять canonical readers.

Acceptance: actual supported HTTP+CAS path; own ref, omitted ref, different trace same dimension, foreign profile, wrong dimension/order/state, missing/corrupt diagnostic; fresh reopen и downstream consumer. Нормальный собственный unstable diagnostic должен оставаться unstable. Override нельзя разрешать лишь по равенству radius/числу dimensions. Institutional authority требуется отдельным приёмочным испытанием.

## 2. CS-02: nested GET не устанавливает parent–sidecar relation

**P2, bounded API relationship correctness; не data-access exploit.** `routes/analysis.py:213–241,249–277` принимает `analysis_id`, но парсит, authorizes и читает только basin/branch ID. Parent записывается только в audit metadata. Sidecar DTO содержит свой `analysis_id`; сравнения нет. `AttractorAnalysisService.load_basin_map/load_continuation_branch` получает только child ArtifactID, поэтому тоже не может установить parent relation.

`interfaces_results.json#/results/CS_02_parent_is_audit_only`:

- Настоящие service/CAS producers создали analysis A, другой analysis B, basin A и branch A.
- Неизменённые route bodies вернули sidecar A при parent=artifact A, artifact B и `not-an-artifact-id`.
- Во всех шести случаях guard seam наблюдал только child ID; audit metadata получила переданный, в том числе неверный, parent.
- Malformed child отвергается до чтения. Actual typed sidecar reads/profile selection работают.

Route decorators, ASGI dependencies и tenant guard заменены явно наблюдаемыми hooks. Поэтому это доказательство отсутствующего relationship check **после входа в route body**, не утверждение, что посторонний tenant может прочитать child. Shared tenant enforcement нельзя удалять или считать проверенным этим probe.

Дополнительная неоднозначность: URL top-level GET использует CAS artifact ID, тогда как payload `analysis_id` является derived logical ID. Они различны даже на корректном generated result. Простое сравнение URL string с sidecar.analysis_id не является достаточным исправлением: нужно прочитать и разрешить parent, определить canonical relation, затем проверить child content/lineage. Либо сделать endpoint честно независимым lookup без фиктивного parent, сохранив compatibility contract.

Acceptance: own/other/missing/malformed parent, same logical ID different analysis configuration/profile, child wrong type/profile и foreign tenant; общий ownership guard остаётся, audit фиксирует проверенную relation. Authenticated route tests нужны отдельно.

## 3. Какие owners уже существуют и что действительно повторяется

1. **Runtime** отвечает за API/auth scope, выбор входа, persistence orchestration и response. Это не scientific verifier. `dependencies.py:175` создаёт service с тем же artifact store. Сам service уже делегирует classifiers и persistence Foundry, не является второй полной scientific subsystem.
2. **Foundry feedback** владеет solve/state, Jacobian, его diagnostic и trace. Здесь уже есть необходимый root relation. **Foundry analysis** владеет проекцией в обобщённый attractor DTO, coarse stability classification и ensemble grouping. Согласовать границу важнее создания нового общего science service.
3. **Core CAS** владеет exact bytes/profile/schema/lineage, не смысловой принадлежностью diagnostic к state. Все эти guarantees надо сохранить.
4. **IR** владеет нейтральной переносимой evidence representation; neutral mapper не выпускает availability, CAS attach делает более сильное, но узкое утверждение. Слить их в один convenience converter было бы регрессией.
5. **Повтор finite-difference kernel.** `foundry/analysis/attractors.py:193–215` и `foundry/feedback/jacobian.py:32–53` повторяют forward-difference columns. Actual probe получил побитово одинаковые matrices на одном nonlinear 2D map при одинаковых steps. Analysis делает baseline+2 calls, Feedback с предоставленным baseline — только 2. Analysis поддерживает rectangular output и `theta`, Feedback исходит из square map и prepared domain steps. Это конкретный кандидат на узкое reuse arithmetic, **не доказательство взаимозаменяемости whole functions**. Step policy, shape/finite checks, cached-baseline semantics, exceptions и stability thresholds должны остаться явными. Не переносить весь solver в Runtime/Core DAG.
6. **Typed readers уже переиспользованы:** `_load_typed_analysis_artifact` общий для трёх artifacts. Повторять schema gate в каждом endpoint не нужно. Main result producer возвращает exact selected profile, sidecar producers возвращают bare ID; readback заново выбирает profile и прошёл. Само различие не объявлено PA-01 или broken reader.

## 4. Дополнительные bounded observations

- **CS-O1, modes/capability semantics.** `/lyapunov` принудительно выставляет `analysis_modes`, но service ни разу не читает modes. Exact route+service для одного nonperiodic trajectory дали тот же candidate result, что `/attractors`, и exponent=None. Actual `largest_lyapunov_exponent` существует, но требует step-map; request его не связывает. Это не выполненный Lyapunov estimate. Не обещать capability по имени endpoint; нужно явно документировать/request/response unsupported/degraded mode либо проводку к estimator. Текущий response не заявляет вычисленное числовое значение.
- **CS-O2, identity scope.** `_feedback_analysis_id` hash включает feedback payload, но не independently supplied diagnostic; `_analysis_id` включает trajectory/variables/parameter, но не все controls. CAS ID сохраняет разные outputs. Найденная logical identity не должна автоматически служить evidence/configuration dedupe key. Production consumer, ошибочно использующий её так, не установлен.
- **CS-O3, periodic-orbit quotient.** В exact multi-start service две последовательности `[0,1]` и `[1,0]` одного period-2 orbit дали **два** attractors с measure 0.5/0.5. `_cluster_key:1026–1057` включает ordered terminal orbit без cyclic normalization. Positive control с двумя одинаковыми fixed points дал один attractor. Это дополнительный bounded scientific aggregation defect candidate, не проведённая scientific validation или global solver audit. Нужен отдельный acceptance: фазовые сдвиги одного orbit объединяются, действительно разные cycles не объединяются, multi-dimensional symmetry/rotation policy задаётся явно. Не смешивать это с CS-01 или publication authority.

## 5. Доказательства, повторение и ограничения

Из `next_cross_service`:

- `PYTHONDONTWRITEBYTECODE=1 python probe_cross_service.py`: exit 0, real local CAS, own/foreign/omitted source controls, IR bridge и subprocess reopen.
- `PYTHONDONTWRITEBYTECODE=1 python probe_interfaces.py`: exit 0, exact route bodies с auth/audit seams, actual service/CAS, numerical kernel parity и phase control.
- `python build_evidence.py`: source/census/hash validation.

Audit reuses frozen `../next_publication_authority/compat_loader.py`; его hash включён в validation. Loader только в памяти адаптирует Python 3.14 multi-except syntax и TypeVar import для Python 3.12, обходит перечисленные package facades. Реальные implementation bodies не заменены success mocks. Все rewrites/imported modules/extracted spans записаны. Это **compatibility-backed**, не native qualification.

Обычный import без adapter повторно отказал на `core/artifacts/store.py:2155` из-за Python 3.12. Зависимости не устанавливались. Первые две ошибки main probe были ошибками audit fixture schema version SimulationResult: 1.0 unsupported, затем manifest/payload mismatch. Они сохранены в `probe_initial*.stderr.txt`, исправлены только fixtures на согласованный 1.4 и не объявлены product findings.

`evidence/` содержит actual payload/manifest четырёх synthetic результатов, не копию CAS tree. `SOURCE_VALIDATION.json` сверяет все imported/extracted/cited файлы с pin manifest; `caller_census.json` содержит полный named Python source denominator и literal hits выбранных символов. Это не resolved dynamic call graph и не отсутствие external users. Source/tests/config, реальные ledgers/data, deployment и внешние services не изменялись. Full pytest, lint, installed delivery, auth/tenant isolation, physical execution и complete public claim lifecycle остаются UNRUN.
