# PolicyOS: единый промежуточный реестр checkpoint01–22

**PARTIAL. Аудит продолжается. Исправления не внедрены. Это не native/release qualification, не завершение E02 и не разрешение публикации.**

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`, tree `29890b967236a8f07e2b0f92a0133ee36883ac49`. Remote HEAD заново не проверялся. Сохранены исходный checkout, все первичные отчёты/evidence и прежняя `next_cumulative_synthesis` (01–11). Новая сводка не изменяет исторические IDs внутри raw records.

## 1. Итог среза

- **112 карточек / 111 групп механизмов**: 81 прежняя карточка + 31 новых для cumulative registry. RR-01 углубляет ST-02 и второй раз не считается. Это смесь defects, qualification gaps, risks, boundary/contract decisions и reuse, не число инцидентов или подтверждённых security vulnerabilities.
- Положительные защиты собраны отдельно в [SAFEGUARDS.json](SAFEGUARDS.json). ME-O1, DP-O1, GH-O1 и EO/tenant results отделены от findings в [OBSERVATIONS.json](OBSERVATIONS.json). Никакой положительный sibling path не объявлен исправлением старого дефекта.
- Review имеет приоритет над широкой author prose: retained source/raw records сохранены, accepted summary и ограничения читаются вместе. Новый общий реестр прошёл [выборочную независимую проверку](../next_review_cumulative_22/REPORT_RU.md) 16 карточек плюс integrity/count/navigation. Это не семантическая переаттестация всех 112 карточек. Пять поправок уточняют namespace и ссылки, не scope/severity; pre-correction bytes сохранены.

## 2. Что делать сначала

1. **Квалифицировать среду и обязательность проверок (R0).** Python3.14/locked dependencies, actual OPA, Node22/browser, installed origins; обязательные PostgreSQL/input lanes. Hash PASS и Python3.12/Node24 controls этого не заменяют.
2. **Перед выпуском закрыть release и policy prerequisites (R13/R5).** Immutable generated snapshot и schema-valid fragments; exact tag/source/shipped-object identity; report/SBOM binding; canonical/rendered/served policy parity. REL high означает operational/privileged integrity priority, не доказанный exploit.
3. **Durable correctness раньше оптимизации (R1/R2/R11).** Exact selected finalization и per-target invalidation ack; physical settlement отдельно от logical cancel; scope-preserving checkpoint restore, state/base/lineage и executable pin. Не освобождать reservations ради timeout green.
4. **Смысл и численные контракты (R3/R4/R12).** Component scope/mode, declared dependence/composition, normative weights, ENCE degeneracy, correct CC statistic, Gaussian precision/support. Не превращать candidate GREEN/approve в authority.
5. **Actual consumers и затем growth/reuse (R10/R8/R6/R7/R9).** REST batch/refresh, browser generation, admitted zero-code path, workload denominators, owner-preserving reuse. Existing helper не заменяет carrier/semantic acceptance.

Зависимости roadmap относятся к integrated acceptance; независимые локальные исправления могут идти параллельно. Даты/стоимость/CVSS не назначены. Унаследованные P1 subpriorities SYS-03/04 и незакрытые SYS-09/10 сохранены.

## 3. Уникальные IDs и дедупликация

- **publication-authority::PA-01**: прежний fail-closed private-draft codec. **policy-assembly::PA-01/02**: executable identity и typed threshold lowering. Это разные owners и acceptance.
- **scholar::RC-01**: declared independence/effective support. **custody::RC-01**: exact historical receipt versus service reconstruction. Raw RC-01 в первичных файлах не переименованы.
- RR-01 включён в ST-02. MA cache/lazy mismatch не сливается с consistent eager policy assembly. CR/SI сохраняют разные numerical contracts. DP-01 — один scoped composition issue; GH-O1 остаётся observation.
- [FINDING_NAMESPACES.json](FINDING_NAMESPACES.json) и [PRIOR_CROSSWALK.json](PRIOR_CROSSWALK.json) сохраняют старые SYS/AUD связи без нового глобального defect count.

## 4. Доказательства и ограничения

Indexed/source-traced, bounded probe, real persisted owners с compatibility loader, native targeted, installed integration и deployed observations — разные уровни. Synthesis не запускал product probes, tests, benchmarks, installs или исправления. Все source hashes — byte provenance, не semantic coverage. Python3.12/Pydantic2.13.4 и Node24 не равны supported Python3.14/Pydantic<2.13/Node22.

Особенно важно: CP16 review не повторял product, tenant temporary SQLite/CAS не сохранены; CP13 review не повторял дорогую 32-attempt волну; CP12 SA-03 — replay author harness; CP22 scanner заменён в caller controls, upstream golden и model проверены отдельно. Native/authenticated/full-engine/production/empirical authority ограничения остаются в каждой карточке.

## 5. Полный реестр по remediation packages

### R0. Квалифицировать поддерживаемый профиль и test lanes

Existing Python3.14/Node22/uv locks; selected collect/execute manifest; actual OPA; isolated installed origin. Tooling repairs are future work, no installs/source edits here.

**Acceptance:** Exact environment and command provenance, native positive/removal/failure controls, wheel/sdist object identities. Availability blocker applies only inspected cloud.

- **FE-05 [P2; finding]** — Runtime client architecture check is stale and parses fixture strings as imports
  Unchanged script exit 1: two real generator files not allowlisted; regex additionally sees template/fixture import strings.
  Ограничение: Node24 builtin-only execution.
  Источник: [CP07, next_frontend_contracts](../next_frontend_contracts/REPORT_RU.md).

- **NATIVE-01 [P2; finding]** — Bootstrap вызывает doctor без package context
  Exact bootstrap file-mode command gives relative-import error; existing module-mode verify/ci_parity commands list surfaces.
  Ограничение: Namespace shim under Python3.12; CI setup explicitly skip-doctor, no hosted CI failure asserted.
  Источник: [CP03, next_native](../next_native/REPORT_RU.md).

- **STR-01 [P2; qualification_gap]** — Пять package mirror ratios ниже floor
  Exact package report gives floor_regression for data_forge/foundry/ir/runtime/scientist; file-presence ratios do not establish behavioral coverage.
  Ограничение: 494 matched source modules are not tests or defects; no native CLI.
  Источник: [CP02, next_structure](../next_structure/REPORT_RU.md).

- **TC-01 [P2; finding]** — Nightly wrapper вычисляет неверный product root
  Unchanged wrapper after stubbed heavy uv call invokes missing tools/benchmarks/build_release_summary.py; real Python exit2.
  Ограничение: No hosted run or real heavy benchmark executed.
  Источник: [CP04, next_test_confidence](../next_test_confidence/REPORT_RU.md).

- **TC-02 [P2; qualification_gap]** — Installed-only tests направлены в checkout lane
  Three installed worker tests selected by Fast PR demand site-packages origin while conftest prepends checkout; historical isolated launcher is not current CI wiring.
  Ограничение: Synthetic origin assertion; native collection and installed profile unrun.
  Источник: [CP04, next_test_confidence](../next_test_confidence/REPORT_RU.md).

- **TC-03 [P2; qualification_gap]** — OPA test dependency не provisioned в checked-in lane
  Real parity test fails when opa binary missing; HTTP root selected but checked-in root setup does not provision OPA.
  Ограничение: Hosted image inventory unknown; not a fresh hosted failure.
  Источник: [CP04, next_test_confidence](../next_test_confidence/REPORT_RU.md).

- **TC-04 [P2; qualification_gap]** — Benchmark marker/path/class selection расходится
  32 of 52 explicit benchmark definitions outside four main selectors; 12 of these in Benchmark* classes without configured collection convention.
  Ограничение: Definitions are not parametrized case count; other equivalent tests not ruled out.
  Источник: [CP04, next_test_confidence](../next_test_confidence/REPORT_RU.md).

- **TC-05 [P2; finding]** — Benchmark timing oracle пропускает нулевую работу
  Exact benchmark method passes for 6 successful effects and for 6 always-raising attempts with zero effects.
  Ограничение: Synthetic timing driver, not speed measurement or entire suite verdict.
  Источник: [CP04, next_test_confidence](../next_test_confidence/REPORT_RU.md).

- **STR-02 [P3; checker_gap]** — Hidden-edge checker зависит от формы import
  Direct fabric.world.store found; from fabric.world import store missed. All 79 real selected parent→child candidates were legitimate __all__ exports.
  Ограничение: Synthetic escape of one checker, not CI bypass or 79 violations.
  Источник: [CP02, next_structure](../next_structure/REPORT_RU.md).

- **STR-03 [P3; latent_risk]** — Test helper teardown смотрит одну import identity
  _helpers.runtime_http and tests._helpers.runtime_http keep separate registries; teardown reads first only.
  Ограничение: Selected long-name callers close environments explicitly; suite leak unestablished.
  Источник: [CP02, next_structure](../next_structure/REPORT_RU.md).

- **TC-06 [P3; latent_risk]** — Quarantine expiry не становится обязательным gate
  Synthetic expired entry still skipped; current registry empty.
  Ограничение: No current test hidden by registry; no active de-gating incident.
  Источник: [CP04, next_test_confidence](../next_test_confidence/REPORT_RU.md).

- **GE-01 [P2; finding]** — Git diff failure admitted as empty docs change set
  Direct docs gate превращает Git diff failure в пустой change set: valid base отказывает по obligation, missing/zero base возвращает 0.
  Ограничение: Локальная caller failure semantics; hosted bypass и green остальных jobs не установлены.
  Источник: [CP14, next_guard_enforcement](../next_guard_enforcement/REPORT_RU.md).
  Review: [next_review_guard_method](../next_review_guard_method/REPORT_RU.md).

- **GE-02 [P2; finding]** — Import subgate ignores supplied candidate root
  Alternate candidate root не доходит до import subgates; shim проверяет checker root, пропуская defect только в candidate root.
  Ограничение: Same-root guard работает; full aggregate green и native dynamic/cycle replay не доказаны.
  Источник: [CP14, next_guard_enforcement](../next_guard_enforcement/REPORT_RU.md).
  Review: [next_review_guard_method](../next_review_guard_method/REPORT_RU.md).

- **GE-03 [P3; finding]** — One README discharges multiple facade path obligations
  Один matching README снимает obligations нескольких изменённых facades.
  Ограничение: Existential planner weakness, не доказанная semantic staleness или обход всех docs checks.
  Источник: [CP14, next_guard_enforcement](../next_guard_enforcement/REPORT_RU.md).
  Review: [next_review_guard_method](../next_review_guard_method/REPORT_RU.md).

- **GE-C01 [coverage_gap; qualification_gap]** — Default import timing test verifies baseline existence only
  Default import-timing test проверяет наличие baseline; live predicate различает synthetic 2× regression. Literal opt-in отсутствует в именованных workflow/action surfaces.
  Ограничение: Coverage gap, не измеренная latency regression и не утверждение об отсутствии opt-in в hosted environment.
  Источник: [CP14, next_guard_enforcement](../next_guard_enforcement/REPORT_RU.md).
  Review: [next_review_guard_method](../next_review_guard_method/REPORT_RU.md).

- **DST-01 [P2; qualification_gap]** — Real PostgreSQL acceptance is optional in checked-in CI
  Real PostgreSQL tests могут skip в missing/caught setup branches; checked-in lane не задаёт DSNs и обязательный DS9 flag; отдельный C57 gate остаётся.
  Ограничение: Не всякая backend error превращается в skip. Изолированная schema fixture существует. 52 source-defined bodies прочитаны, не collected/executed; hosted result неизвестен.
  Источник: [CP21, next_data_service_tests](../next_data_service_tests/REPORT_RU.md).
  Review: [next_review_data_calibration](../next_review_data_calibration/REPORT_RU.md).

- **DST-02 [P2; ci_input_contract_defect]** — Standard Integration selects real-corpus data service tests without declaring their inputs
  Standard Integration выбирает corpus tests с ignored production_data, не объявляя provisioning в checked-in workflow; missing path guard отказывает.
  Ограничение: Existence-only positive не валидирует corpus; native builder/hosted job не выполнялись, более ранние setup failures возможны.
  Источник: [CP21, next_data_service_tests](../next_data_service_tests/REPORT_RU.md).
  Review: [next_review_data_calibration](../next_review_data_calibration/REPORT_RU.md).

### R1. Восстановить durable selected finalization и event application

Core finalize journal stores exact selected receipt. Scientist validity owner stores content-bound received/pending/applied and idempotent per-target receipts; origin ack waits complete owner result.

**Acceptance:** Actual sync/async producer, full builder HTE targets, durable-step kills/failures, fresh readers/API, legacy journal, changed payload/target drift; no guessed selection or dedupe-only ack.

- **STATE-01 [P2; finding]** — Finalize recovery loses selected workflow transition across real CAS/process restart
  Verified terminal run can lose the explicit selected workflow receipt; Runtime cannot select final experiment state. Availability/currentness evidence loss, not authority bypass.
  Ограничение: Python 3.12 compatibility, synthetic upstream registry/workflow/state JSON, full sync/async engine and HTTP authorization not executed.
  Источник: [CP08, next_finalize_chain](../next_finalize_chain/REPORT_RU.md).
  Review: [next_review_state](../next_review_state/REVIEW_RU.md), [next_review_finalize](../next_review_finalize/REVIEW_RU.md).

- **STATE-02 [P2; finding]** — Originating HTE outbox acknowledges incomplete generic invalidation
  Real SQL completion source/outbox and actual CAS validity owner; fresh-process retry writes event_published notification and marks originating row published while one or both target evaluations remain ACTIVE. Force recompute does not recover events missing from sticky state.
  Ограничение: Synthetic schema-valid HTE selection refs, minimal generic packet payloads, extracted Runtime methods, Python3.12 compatibility adapters; no public policy claim/full HTE numerical producer/authenticated HTTP.
  Источник: [CP07, next_delivery_chain](../next_delivery_chain/REPORT_RU.md).
  Review: [next_review_state](../next_review_state/REVIEW_RU.md), [next_review_delivery](../next_review_delivery/REVIEW_RU.md).

### R2. Замкнуть logical cancellation и physical settlement

Keep generic replay distinct from domain reservation; truthful drain and no new dispatch. Retain producer-owned accounting observer through repeated cancellation until physical outcome. N5 disposal independent of authority.

**Acceptance:** Actual generic routes, direct/cached LLM branches, multiple cancels, late known/unknown response, restart/lease/PA2; physical execution and accounting settlement tracked separately.

- **BUD-01 [P2; finding]** — Repeated cancellation retires direct producer accounting ownership before physical completion; known late response remains terminal unknown and blocks same-run admission.
  Repeated cancellation retires direct producer accounting ownership before physical completion; known late response remains terminal unknown and blocks same-run admission.
  Ограничение: see primary report; bounded evidence does not establish operational incidence
  Источник: [CP06, next_budget_authority](../next_budget_authority/REPORT_RU.md).

- **FLOW-01 [P2; lifetime_risk]** — N5 capture/observer lifetime удерживает payload ownership
  _token retains 16/16 objects; completed observer retains 4/4 frame locals until observer owners deleted. Successful seal retains capture by source; positive issued registry not manufactured.
  Ограничение: No production RSS, universal leak or native successful seal/revoke E2E; object retention is not publication authority.
  Источник: [CP08, next_n5_revoke](../next_n5_revoke/REPORT_RU.md).

- **LIF-01 [P2; finding]** — Cancellation и ошибки после response теряют локальный cleanup
  Exact ASGI stack: cancelled POST retains pending, retry 409; four cancelled live-open retain slots, fifth 429. Ordinary Exception and managed iterator cancellation release their state.
  Ограничение: Off-lock Starlette/AnyIO; task cancellation не TCP disconnect; synthetic routes; default domain effect не выполнялся.
  Источник: [CP02, next_lifecycle](../next_lifecycle/REPORT_RU.md).

- **LIF-02 [P2; finding]** — Worker stop объявляет stopped до drain
  ControlRunService.close/container shutdown return after timeout with live handler. Default closed guard refuses new SQL calls; already running dependency can complete under still-current fence.
  Ограничение: Raw-store late insert не переносится на default guarded runtime; production double execution, cancellation authority и budget settlement не доказаны.
  Источник: [CP02, next_lifecycle](../next_lifecycle/REPORT_RU.md).

- **LIF-03 [P2; finding]** — Stop во время maintenance допускает последующий dispatch
  After stop returns while maintenance is blocked, released callback leases pending job and starts handler with stop flag set.
  Ограничение: Synthetic maintenance/job; exact default closed-guard interleaving не выполнен.
  Источник: [CP02, next_lifecycle](../next_lifecycle/REPORT_RU.md).

- **LIF-04 [P2; contract_gap]** — Completed-response cache не обеспечивает durable reservation
  Two processes sharing directory accept same key with same or different payload; after death before complete retry is started. Atomic response replacement is not effect admission.
  Ограничение: Class is documented response cache; no actual duplicate production job or NL/predictive bypass. P1 prerequisite only if global at-most-once guarantee is intended.
  Источник: [CP02, next_lifecycle](../next_lifecycle/REPORT_RU.md).

### R3. Сохранить component scopes и identification restrictions

Existing grammar/decomposition/compiler owners retain component-linked scopes and mode constraints, or typed refusal. Legacy scope contract must be explicitly decided, not silently upgraded.

**Acceptance:** Native multi-intervention PolicySpec, separate/joint/reversed/interleaved cases; complete obligations and claim-bound query/specs; actual persisted resolver and method consumer, no-source/no-method negatives.

- **DC-01 [P2; finding]** — Composite grammar silently drops independent domain obligations and required constructs
  Two domain cases and joint all compiled; joint drops 3 seed obligation candidates and 7 required constructs. Reverse text order and default frontier budget reproduce loss. Stacked facet rows instead produce order-dependent rule matching.
  Ограничение: No actual whole scenario/capability resolver execution No final admitted/published claim Independent explicit constructs or critics may compensate Synthetic concept refs, source-extracted modules and unmatched native profile
  Источник: [CP05, next_domain_composition](../next_domain_composition/REPORT_RU.md).
  Review: [next_review_domain](../next_review_domain/REPORT_RU.md).

- **DC-02 [P2; finding]** — Grammar strengthens four explicit IdentificationMode values to point_identified
  real enum values survive normalizer then four map to point_identified, compiled. Point/sequential preserved. Explicit downstream claim partial_identification remains bounds.
  Ограничение: PolicySpec-shaped collaborator is synthetic, native IR validation unrun Final selector can independently preserve explicit constraints No estimator execution or publication established
  Источник: [CP05, next_domain_composition](../next_domain_composition/REPORT_RU.md).
  Review: [next_review_domain](../next_review_domain/REPORT_RU.md).

- **EC-01 [P2; finding]** — Claim-bound scope collapses to globally last facet in data compiler
  Two independent claims requiring the same construct for distinct scopes produce one global resolver query and two specs both using the last component scope; reverse order reverses both scopes despite unchanged claim facet_refs.
  Ограничение: Native typed PolicySpec, production resolver, persisted/scientific/protected output unrun.
  Источник: [CP07, next_evidence_composition](../next_evidence_composition/REPORT_RU.md).
  Review: [next_review_evidence](../next_review_evidence/REPORT_RU.md).

- **EC-02 [P2; finding]** — Explicit method facet is not bound into causal method preconditions
  For all six explicit method facet values, method facet becomes context_only while two linked causal claims produce point requirements. Explicit attached partial_identification precondition instead produces bounds.
  Ограничение: No actual point estimator execution, unsupported policy deployment or publication demonstrated.
  Источник: [CP07, next_evidence_composition](../next_evidence_composition/REPORT_RU.md).
  Review: [next_review_evidence](../next_review_evidence/REPORT_RU.md).

- **FG-03 [P2; finding]** — Early serious NL normalization не принимает расширенный registry
  Early serious-NL canonicalizer does not receive extended registry containing two new typed metric IDs; full valid corpus→HTTP path unrun, unknown/meaning guards must stay.
  Ограничение: Actual strict canonicalizer helper, two new typed synthetic metric IDs; not full valid corpus-to-HTTP e2e. Do not weaken unknown/meaning guards.
  Источник: [CP03, next_freegrow](../next_freegrow/REPORT_RU.md).

- **PG-01 [P3; documented_legacy_residual_risk]** — Documented legacy binding retains overlap/partial-scope semantics while candidate discovery is stricter
  Documented legacy binding retains overlap/partial-scope semantics while candidate discovery is stricter
  Ограничение: Synthetic owner assertions Source-body execution, not package import Native N7 CAS bridge traced not run No scientific/source/production admission No publication bypass established selected_exact is a legacy evidence-mode status, not a proof of full temporal entailment
  Источник: [CP08, next_persisted_growth](../next_persisted_growth/REPORT_RU.md).
  Review: [next_review_growth](../next_review_growth/REPORT_RU.md).

### R4. Связать scientific declarations с фактическими inputs

Typed occurrence/representation composition law; policy-aware existing evidence independence owner; exact Jacobian state/profile/provenance; explicit estimands, grid/seed/algorithm identities.

**Acceptance:** Admitted source→selected persistence→fresh Runtime/Foundry/Scientist consumer; correct transformations and property-removal negatives; full numerical/report roundtrips without asserting authority from candidate pass.

- **CS-01 [P2; finding]** — Independent request Jacobian overrides feedback-owned diagnostic without a semantic join
  Independent request Jacobian overrides feedback-owned diagnostic without a semantic join
  Ограничение: see primary report; bounded evidence does not establish operational incidence
  Источник: [CP10, next_cross_service](../next_cross_service/REPORT_RU.md).
  Review: [next_review_cross_service](../next_review_cross_service/REPORT_RU.md).

- **LIB-01 [P2; finding]** — CDF/Wasserstein теряет distribution support и grid
  CDF grids are ignored; CDF ordinates treated as samples. Unequal-sample helper also differs from exact empirical W1.
  Ограничение: Native 3.14 imports, actual World.evaluate, persistence and downstream authority.
  Источник: [CP04, next_library](../next_library/REPORT_RU.md).

- **LIB-02 [P2; finding]** — Bootstrap RNG вырождается; strata wrapper отдельно теряет блоки
  LCG modulo low bits produces deterministic alternating samples and zero empirical bootstrap mean variance; stratified wrapper samples only first element of each chosen block.
  Ограничение: arch execution, calibration/registry end-to-end and production false-positive effects.
  Источник: [CP04, next_library](../next_library/REPORT_RU.md).

- **scholar::RC-01 [P2; finding]** — Declared Scholar dependence collapse rules do not govern effective support count
  Five extra declared relation-dimension controls retain effective=2/pass in the author fixtures; same-dataset actual job/CAS and fresh reader preserve this. Independent matched same-study cluster gives effective=1/blocked for both weights 1 and 0, confirming weight non-consumption rather than universal threshold pass.
  Ограничение: Synthetic scientific claims and metadata, no empirical paper-quality admission. Actual job uses recorded-bundle service, no live providers or ScholarDeepSearchService. Python 3.12 compatibility loader and namespace overrides, not native 3.14. Only selected scorecard gate bodies, not full scorecard authority/admission. Shared authors/institutions are not universal scientific proof of dependence; finding is declared policy consumption gap. Zero-weight probe uses independent singleton studies, not a matched cluster; only diagnostic plus direct static absence of field reads. Independent matched control is separate review evidence.
  Источник: [CP11, next_research_chain](../next_research_chain/REPORT_RU.md).
  Review: [next_review_research](../next_review_research/REPORT_RU.md).

- **RD-01 [P2; finding]** — Recomputed measurement axes compare declarations without reconciling mechanically available occurrence facts
  Real source projection/replay produces sum(2,6)=8. Both representations declare mean and AGGREGATION is required, yet candidate/recomputed. Both representation populations may disagree with actual source/port scope while POPULATION_REF remains in recomputed_axes.
  Ограничение: No native persisted admission or complete physical/publication bypass. Raw aggregation versus representation aggregation may need a compositional meaning law, not unconditional literal equality. External empirical truth remains explicitly unestablished.
  Источник: [CP09, next_registry_dataflow](../next_registry_dataflow/REPORT_RU.md).
  Review: [next_review_publication_dataflow](../next_review_publication_dataflow/REPORT_RU.md).

- **CS-02 [P3; api_contract_debt]** — Nested sidecar GET ignores parent identity and records caller association in audit metadata
  Nested GET ignores parent for child read; detached nullable sidecars and differing logical/content/profile namespaces make required parent relationship ambiguous. Narrow P3 contract debt, not verified audit poisoning.
  Ограничение: see primary report; bounded evidence does not establish operational incidence
  Источник: [CP10, next_cross_service](../next_cross_service/REPORT_RU.md).
  Review: [next_review_cross_service](../next_review_cross_service/REPORT_RU.md).

### R5. Согласовать policy и publication object identity

Canonical vocabulary/resource/policy pack; strict response schema; compatible publication draft codec preserving raw nested JSON and exact profile/bytes.

**Acceptance:** Engine-evaluated canonical/rendered/served decisions and native private prepare/reopen; genuine root/mandate/currentness/signature chain separately. No relaxed readers or implicit new authority.

- **AUTH-01 [P1-conditional; finding]** — Server permission vocabulary и canonical Rego расходятся
  38 server permissions versus 34 Rego values; jobs.cancel and three registered_sql permissions missing. all-members-known predicate also rejects known actions for principal carrying new grants.
  Ограничение: P1 before deploying these grants; source-derived fail-closed mismatch, actual OPA exit77 UNRUN, no live denial incident.
  Источник: [CP03, next_auth](../next_auth/REPORT_RU.md).

- **AUTH-02 [P1-conditional; finding]** — Проверяемый policy pack не равен chart-shipped pack
  Canonical modules 8, chart 7; action_permission absent, decision differs. Chart local files override values fallback; client factory identity does not attest remote policy bytes.
  Ограничение: Chart has no workload/mount; rendered/live endpoint bytes unknown. P1 release prerequisite, not proven HTTP bypass. Exact chart source locator is resolved by source receipts.
  Источник: [CP03, next_auth](../next_auth/REPORT_RU.md).

- **AUTH-03 [P2; hardening_gap]** — OPA allow принимает truthy неboolean значения
  Exact check admits string false, deny, [false], 1; boolean false/null/absence/timeout deny.
  Ограничение: Canonical/chart Rego returns boolean; no caller-controlled response type, authentication bypass or external exploit established.
  Источник: [CP03, next_auth](../next_auth/REPORT_RU.md).

- **publication-authority::PA-01 [P2; finding]** — Governed publication private draft fails its own strict persisted round-trip
  Real private draft first prepare succeeds in memory; repeat and fresh owner read refuse missing canon. Counterfactual profile declaration exposes tagged datetime/raw JsonValue incompatibility; public issue not reached.
  Ограничение: Python 3.12 with recorded syntax/TypeVar compatibility adapters, not native 3.14. Synthetic initialization policy, root issuer/verifier and institutional mandate; no deployed institutional authority. Default production owner is unappointed and publication root custody unavailable independently of this defect. No new SYS root-cause family counted pending broader grouping.
  Источник: [CP09, next_publication_authority](../next_publication_authority/REPORT_RU.md).
  Review: [next_review_publication_dataflow](../next_review_publication_dataflow/REPORT_RU.md).

- **custody::RC-01 [P2 correctness/history availability, not security severity; finding]** — Historical exact acceptance cannot traverse current-state custody rebuilder
  После продвижения lineage exact historical receipt проходит generic verifier, но production-configured custody service отвергает его; newest current receipt проходит.
  Ограничение: Historical intent явен в core verifier; отдельный public endpoint historical SLA не установлен. Это bounded integration/history availability mismatch, не authority bypass; synthetic issuer/native inputs.
  Источник: [CP19, next_remaining_custody](../next_remaining_custody/REPORT_RU.md).
  Review: [next_review_custody_history](../next_review_custody_history/REPORT_RU.md).

### R6. Сделать discovery и refresh полными и согласованными

Complete catalog separate from bounded decode cache; generation-bound publication; full ArtifactRef identity; actual discovered method rather than nonempty reference; uncertainty before truncation.

**Acceptance:** Real >cap owner-protected exact/list access; refresh barriers; persisted add/remove/same-count mutation/reopen; new typed resources discover→execute→admit/refuse; selected-profile graph cases.

- **NS-03 [P1-conditional; finding]** — Default cap is still the observable catalogue boundary with real trace parsing
  10,001 real trace directories, 10,000 indexed. Last run absent exact/tenant list until retained slot freed. Warm forced refresh avoids parsing but still scans/fingerprints.
  Ограничение: No actual CAS manifest or artifact permission test. No-journal finalization fixture; selected DTO dependency annotations are fixtures.
  Источник: [CP02, next_scaling](../next_scaling/REPORT_RU.md).

- **FG-01 [P2; finding]** — G2 free-growth premise принимает строку вместо обнаруженного метода
  G2 premise accepts a nonempty method ref string even after report/registry failure, rather than establishing a discovered executable method; no complete G2 conformance or authority pass.
  Ограничение: Source-extracted report/reducer, real temp JSON, synthetic SKG edge and unrelated recall/quality; no full G2 or authority pass claim.
  Источник: [CP03, next_freegrow](../next_freegrow/REPORT_RU.md).

- **FG-02 [P2; finding]** — G1 cache и snapshot identity не различают изменения корпуса
  Warm same-root/query cache and snapshot identity do not distinguish selected corpus changes; fresh process/reset differs. GR-03 deepens missing content/generation identity in changed-set.
  Ограничение: Warm same-root/query proving-ground reader; synthetic catalog collaborators, no native DuckDB; new process/explicit reset differs.
  Источник: [CP03, next_freegrow](../next_freegrow/REPORT_RU.md).

- **GR-01 [P2; finding]** — Epoch graph collapses selected manifest profiles
  Profile-A event reaches Profile-B branch; two target profiles collapse to one order-selected row.
  Ограничение: see primary report; bounded evidence does not establish operational incidence
  Источник: [CP06, next_graph_refresh](../next_graph_refresh/REPORT_RU.md).
  Review: [next_review_graph](../next_review_graph/REPORT_RU.md).

- **GR-02 [P2; finding]** — CAS bounded DFS loses shorter reachable path
  Same graph and depth budget yields skipped shared node/no leaf when long path visited first, versus present shared and leaf under input reorder.
  Ограничение: see primary report; bounded evidence does not establish operational incidence
  Источник: [CP06, next_graph_refresh](../next_graph_refresh/REPORT_RU.md).
  Review: [next_review_graph](../next_review_graph/REPORT_RU.md).

- **GR-03 [P2; finding]** — Incremental changed-set misses same-profile content mutation
  Different same-size fixture bytes and synthetic values preserve schema/count fingerprint and changed_input_count=0.
  Ограничение: see primary report; bounded evidence does not establish operational incidence
  Источник: [CP06, next_graph_refresh](../next_graph_refresh/REPORT_RU.md).

- **NC-04a [P2; finding]** — Explicit empty bindings retain prior search enrichment
  refresh(contracts,bindings=[]) retains connector and alias with unchanged fingerprint; direct index empty refresh and fresh searcher remove both.
  Ограничение: No unsafe fetch/auth bypass established; runtime registry removal flow not executed.
  Источник: [CP03, next_catalog_scale](../next_catalog_scale/REPORT_RU.md).
  Review: [next_catalog_scale](../next_catalog_scale/REVIEW_RU.md).

- **NC-04b [P2; finding]** — max_results=1 converts known exact ambiguity into successful resolve
  100 and1000 shared exact matches:limit1 gives false disambiguation and returns first binding;limit5 gives true and resolve ValueError.
  Ограничение: Default MetricSearcher5/FastLane12 unaffected by this specific configuration; production caller with1 not established.
  Источник: [CP03, next_catalog_scale](../next_catalog_scale/REPORT_RU.md).
  Review: [next_catalog_scale](../next_catalog_scale/REVIEW_RU.md).

- **NS-01 [P2; finding]** — Concurrent refresh publishes mismatched cache and fingerprints
  5/5 same-tenant append-only schedules preserve stale cached mtime and list ordering through force refresh, while fresh instance is current.
  Ограничение: Method-return barrier expands scheduling window; not measured race probability. No cross-tenant leak or permanent unrecoverability demonstrated.
  Источник: [CP02, next_scaling](../next_scaling/REPORT_RU.md).
  Review: [next_scaling](../next_scaling/REVIEW_RU.md).

### R7. Оптимизировать подтверждённые growth costs без ослабления guards

First actual workload multiplicity and planner statistics; existing validated snapshots/indexes and revision-aware reuse. Preserve full historical proof, scope, corruption detection, ordering and retry denominator.

**Acceptance:** Native bounded before/after counters + equality; real CAS claims/query costs, SQL distributions/ANALYZE, migration/write/rollback/concurrency and PG separately. No production SLA inferred from synthetic sizes.

- **NC-01 [P2; finding]** — Shared alias posting construction has quadratic equality work
  N=500/1000/2000 gives 124750/499500/1999000 ID comparisons for one shared tag, zero without it.
  Ограничение: No production latency/SLA breach; large search corpus excludes shared aliases.
  Источник: [CP03, next_catalog_scale](../next_catalog_scale/REPORT_RU.md).
  Review: [next_catalog_scale](../next_catalog_scale/REVIEW_RU.md).

- **NC-02 [P2; finding]** — Unchanged semantic refresh and promotion rebuild every document
  At200000 unchanged contracts:changed=[] and200000 fingerprints/builds/vectorizations. Five promotion-body calls atN1000 produce5000 document builds.
  Ограничение: One sample per build/refresh size; no HTTP approval/e2e/concurrency/persistence/profile enrichment.
  Источник: [CP03, next_catalog_scale](../next_catalog_scale/REPORT_RU.md).
  Review: [next_catalog_scale](../next_catalog_scale/REVIEW_RU.md).

- **NC-03 [P2; finding]** — Search output limit does not bound scans or ranking work
  At200000 contracts top1/top5 non-exact query performs200000 cosine+600000 alias scores. FastLane exact materializes200000 IDs. Shared exact atN1000 constructs2000 bindings.
  Ограничение: Synthetic fixed tokens, no production distribution; standalone SourceContract catalog separate; DataForge HNSW not measured.
  Источник: [CP03, next_catalog_scale](../next_catalog_scale/REPORT_RU.md).
  Review: [next_catalog_scale](../next_catalog_scale/REVIEW_RU.md).

- **NS-02 [P2; finding]** — Single pending batch is reparsed for each projection-bearing cached run
  R overlay-bearing rows times T targets yields R*T parsing/validation; with R=T=800 one list reads 92,144,000 JSON bytes despite page size 1.
  Ограничение: R excludes trace-only/no-packet rows. ArtifactRef/outer cache/caller fixture; full projection CAS/admission unrun. Bytes are application reads, not physical storage traffic.
  Источник: [CP02, next_scaling](../next_scaling/REPORT_RU.md).
  Review: [next_scaling](../next_scaling/REVIEW_RU.md).

- **NS-04 [P2; finding]** — VOI incremental history and replay repeat full-history fits
  H=50/200/800 accepted observations cause H fits and 1,275/20,100/320,400 record visits, H(H+1)/2.
  Ограничение: Synthetic observations; full scheduler/from_snapshot unrun. No scientific correctness or p95 assertion.
  Источник: [CP02, next_scaling](../next_scaling/REPORT_RU.md).

- **SG-01 [P2; finding]** — Unindexed job history and run-scoped job queries scan shared retained tables
  Unindexed job history and run-scoped job queries scan shared retained tables
  Ограничение: see primary report; bounded evidence does not establish operational incidence
  Источник: [CP10, next_sql_growth](../next_sql_growth/REPORT_RU.md).
  Review: [next_review_sql](../next_review_sql/REPORT_RU.md).

- **SG-02 [P2; finding]** — Outbox page limit and frozen watermark do not bound SQL work
  Outbox page limit and frozen watermark do not bound SQL work
  Ограничение: see primary report; bounded evidence does not establish operational incidence
  Источник: [CP10, next_sql_growth](../next_sql_growth/REPORT_RU.md).
  Review: [next_review_sql](../next_review_sql/REPORT_RU.md).

- **SG-03 [P2; finding]** — Already migrated store repeats intent scope census and Search delivery backfill
  Already migrated store repeats intent scope census and Search delivery backfill
  Ограничение: see primary report; bounded evidence does not establish operational incidence
  Источник: [CP10, next_sql_growth](../next_sql_growth/REPORT_RU.md).
  Review: [next_review_sql](../next_review_sql/REPORT_RU.md).

- **SG-04 [P2; finding]** — Lease candidate LIMIT 1 cost depends on planner and can include completed history
  LIMIT1 candidate work depends on planner/distribution: no-statistics fixture enumerates active backlog; independent ANALYZE at fixed active10 scans growing completed history too.
  Ограничение: see primary report; bounded evidence does not establish operational incidence
  Источник: [CP10, next_sql_growth](../next_sql_growth/REPORT_RU.md).
  Review: [next_review_sql](../next_review_sql/REPORT_RU.md).

- **ST-01 [P2; finding]** — Ownership generations retain full snapshots for each new claim
  800 actual record_owner additions retain 800 generations: 74492731 bytes total, 185001 active. Diagnostic evidence reads 801 generation files and 74677732 generation bytes.
  Ограничение: No CAS blob/manifest writes or full publication transaction. Deliberate custody history design, no data-loss/SLA incident demonstrated.
  Источник: [CP05, next_storage_scale](../next_storage_scale/REPORT_RU.md).
  Review: [next_review_storage](../next_review_storage/REPORT_RU.md).

- **ST-02 [P2; finding]** — Warm exact ownership lookup re-reads and hashes the full active generation
  50000 synthetic claims/100 tenants: each warm exact lookup reads 10050932 generation bytes plus203 pointer bytes, zero generation parses. Incremental warm heap peak10058835 bytes. CP13 RR-01 adds actual run-history composition: three reads per invocation, full retained history; request-local memo lowers 192→64 loads in immutable fixture only.
  Ограничение: One legitimate bulk-seeded generation, synthetic claims, no artifact manifests or full API. Bytes are application reads, not physical disk traffic. Heap is incremental Python allocation, not total RSS/leak.
  Источник: [CP05, next_storage_scale](../next_storage_scale/REPORT_RU.md).
  Review: [next_review_storage](../next_review_storage/REPORT_RU.md), [next_review_method_replay](../next_review_method_replay/REPORT_RU.md).

- **GR-04 [P3; measured_optimization_boundary]** — Affected traversal still rematerializes complete target vector
  5000-node leaf event builds 4999 rows. Thirty-five fixed-graph append-event cone experiments equal full vectors; cycles legitimately affect whole graph.
  Ограничение: see primary report; bounded evidence does not establish operational incidence
  Источник: [CP06, next_graph_refresh](../next_graph_refresh/REPORT_RU.md).

- **NS-05 [P3; contract_decision_pending]** — Durable JSONL does not automatically restore process-global selection history
  Two real processes same configured path: first writes seven records and fits; second has zero in memory/unfitted predictor, all seven JSONL rows intact.
  Ограничение: Not called data loss or proven contract violation. Full module imported under isolated name, not installed package.
  Источник: [CP02, next_scaling](../next_scaling/REPORT_RU.md).

- **SG-PG-01 [P3; qualification_gap]** — PostgreSQL schema owner omits three SQLite secondary indexes
  PostgreSQL schema owner omits three SQLite secondary indexes
  Ограничение: see primary report; bounded evidence does not establish operational incidence
  Источник: [CP10, next_sql_growth](../next_sql_growth/REPORT_RU.md).
  Review: [next_review_sql](../next_review_sql/REPORT_RU.md).

- **ST-03 [P3; conditional_scaling_risk]** — Tenant quota wrapper scans every CAS member twice under mutation lock
  50000 synthetic32-byte files: no-op mutation traverses170522 entries and performs170528 lstat calls; actual wrapper elapsed2.457s in local fixture.
  Ограничение: Compatibility wrapper, no direct product callers found beyond resolver/re-export. Constructor/quota enforcer/CAS writer fixtures, not native put/quotas/overflow or deployed concurrency. Ownership history explicitly excluded from documented byte quota.
  Источник: [CP05, next_storage_scale](../next_storage_scale/REPORT_RU.md).
  Review: [next_review_storage](../next_review_storage/REPORT_RU.md).

### R8. Исправить выбранные frontend state и wire contracts

Single auth/origin generation owners; binary schema-generator agreement; textContent instead of HTML interpolation; semantic parity assertions cover all carried fields.

**Acceptance:** Node22 typecheck/build, genuine browser/DOM and actual backend caller/refresh profile; stale success/failure, binary/error/304 and markup negatives; no server bypass claim from client state.

- **FE-01 [P2; finding]** — Auth refresh has no generation fence and no rejected-fetch state transition
  Late token A refresh after clear or token B installation publishes authenticated A. Fetch rejection leaves status refreshing.
  Ограничение: Injected logger/Vite config/window/document/fetch, Node24 type stripping; no real account/token/provider.
  Источник: [CP07, next_frontend_contracts](../next_frontend_contracts/REPORT_RU.md).
  Review: [next_review_frontend](../next_review_frontend/REPORT_RU.md).

- **FE-02 [P2; finding]** — Generated raw artifact download parses successful bytes as JSON
  Actual downloadArtifactContent rejects CSV bytes with SyntaxError. Same client explicit arrayBuffer mode returns exact bytes. Generator prefers the schema default application/json over declared binary.
  Ограничение: Synthetic Response, not HTTP/CAS/backend acceptance.
  Источник: [CP07, next_frontend_contracts](../next_frontend_contracts/REPORT_RU.md).
  Review: [next_review_frontend](../next_review_frontend/REPORT_RU.md).

- **FE-03 [P2; finding]** — Reference shell interpolates API node alias into innerHTML
  Exact app.js creates an img/onerror attribute in the HTML sink from node alias instead of showing literal text.
  Ограничение: Synthetic DOM records; Chromium launch blocked before page load.
  Источник: [CP07, next_frontend_contracts](../next_frontend_contracts/REPORT_RU.md).

- **FE-04 [P2; finding]** — Reference shell late results overwrite a newly selected API origin
  After choosing origin B and rendering its run list, late origin A response replaces it while selected base URL remains B. Catalog proof alone checks state.client identity.
  Ограничение: Actual app body/client with synthetic fetch and DOM writes, not browser.
  Источник: [CP07, next_frontend_contracts](../next_frontend_contracts/REPORT_RU.md).

- **FE-06 [P2; test_oracle_defect]** — Authority MACHINE-twin parity ignores state and owner surface
  Exact checker returns passed=true after refused→supplied or owner_surface change; changed reason correctly fails.
  Ограничение: Type-erased source with synthetic DOM reader; actual backend currently supplies eleven refusals.
  Источник: [CP07, next_frontend_contracts](../next_frontend_contracts/REPORT_RU.md).
  Review: [next_review_frontend](../next_review_frontend/REPORT_RU.md).

- **UI-01 [P2; finding]** — Clerk activity lacks conversation-generation ownership
  Поздний launch acceptance после reset восстанавливает старый runId; old terminal SSE во время нового pending launch сбрасывает новый streaming state.
  Ограничение: Source action bodies с заменёнными ports, не native React/Zustand/browser; identity layout gate и scoped envelope существуют.
  Источник: [CP15, next_ui_ownership](../next_ui_ownership/REPORT_RU.md).
  Review: [next_review_adapters_ui](../next_review_adapters_ui/REPORT_RU.md).

- **UI-02 [P3; finding]** — Clerk run history does not distinguish error from empty/current list
  Clerk history локально не различает error, empty и current list.
  Ограничение: Global incidents покрывают network status=0, 403/5xx; 401 ведёт к login. Не whole-app silent error или cross-account leakage.
  Источник: [CP15, next_ui_ownership](../next_ui_ownership/REPORT_RU.md).
  Review: [next_review_adapters_ui](../next_review_adapters_ui/REPORT_RU.md).

- **UI-03 [P3; finding]** — Declared API-to-feature prohibition lacks enforcement
  Authoring contract запрещает API→features, но выбранная policy function пропускает два реальных imports.
  Ограничение: Полный architecture checker блокирован missing TypeScript до AST scan; private cross-feature import уже отвергается.
  Источник: [CP15, next_ui_ownership](../next_ui_ownership/REPORT_RU.md).
  Review: [next_review_adapters_ui](../next_review_adapters_ui/REPORT_RU.md).

### R9. Консолидировать только квалифицированные owners и primitives

Failure-safe DAG tail ownership; explicit sync/async policy matrix; finite facades and read/build boundaries. Reuse graphlib/Core identity/entry points/local formatter, retain distinct estimands and domain admission.

**Acceptance:** Actual typed imports/FQN/object identities, import permutations and installed clients; failure/exception/recovery, optional-dependency policy and historical bytes/seeds preserved; no universal framework.

- **AB-01 [P2; finding]** — Fabric transform builder duplicates Core DAG mutable ownership
  Exact unchanged Core and Fabric definitions produce different dependency/order after branch callback raises after adding stages
  Ограничение: Native imports, DataFrame outcomes, real consumer recovery frequency
  Источник: [CP06, next_abstraction](../next_abstraction/REPORT_RU.md).

- **AB-02 [P2; policy_parity_risk]** — Scientist sync and async repeated preflight/finalization policies
  Two live builder routes; exact prefix replay invokes memory preparation only in sync; source-only selected research sidecar asymmetry
  Ограничение: Full policy bypass, deployed incident, selected-workflow async sidecar regression
  Источник: [CP06, next_abstraction](../next_abstraction/REPORT_RU.md).

- **DA-01 [P2; architecture_debt]** — Application ownership расположено под HTTP transport
  147 quality→HTTP import statements from 26 selected modules: 31 TYPE_CHECKING,107 function-local,9 module-level; not 147 eager cycles.
  Ограничение: Selected source census, unresolved parsers; no runtime failure.
  Источник: [CP05, next_directory_architecture](../next_directory_architecture/REPORT_RU.md).

- **DA-02 [P2; architecture_debt]** — DataForge read_api также exposes build operations
  Machine boundary calls API read-only while producer is reachable; README already documents not uniformly read-only.
  Ограничение: Not hidden side effect accusation or proof every read writes.
  Источник: [CP05, next_directory_architecture](../next_directory_architecture/REPORT_RU.md).

- **DA-03 [P2; architecture_debt]** — Physical splits снова объединяют mutable namespace
  Scientist packet and Foundry facade backfill make split modules identity-sensitive, not independent abstractions.
  Ограничение: No particular installed failure; preserve useful facades rather than flatten.
  Источник: [CP05, next_directory_architecture](../next_directory_architecture/REPORT_RU.md).

- **NR-01 [P2; finding]** — Provenance cycle verifier зависит от recursion depth
  Core provenance verifier recursion on 1200-edge DAG raises RecursionError, CLI2 without report; graphlib boolean adapter preserves normal DAG/cycle results and structured long-graph outcome.
  Ограничение: see primary report; bounded evidence does not establish operational incidence
  Источник: [CP02, next_reuse](../next_reuse/REPORT_RU.md).

- **AB-03 [P3; legacy_compatibility_debt]** — Legacy LangGraph public adapter and base dependencies
  Complete named Python census; langchain/langgraph both base declarations; synthetic provider demonstrates full-stream step and repeated effects
  Ограничение: Real locked LangGraph integration, external users, dependency removal savings
  Источник: [CP06, next_abstraction](../next_abstraction/REPORT_RU.md).

- **AB-04 [P3; reuse_decision]** — DataForge declarative asset scaffold versus actual batch orchestration
  Full named Python symbol census; inspected real catalog batch path is explicit and receipt-bound, not driven by asset decorator/planner
  Ограничение: External users, all dynamic calls, native migration equivalence
  Источник: [CP06, next_abstraction](../next_abstraction/REPORT_RU.md).

- **AB-KEEP [P3; reuse_decision]** — Existing owner-preserving reuse
  Inspected source chains reuse existing storage/iteration while domain owners retain semantic admission
  Ограничение: Full native consumer execution; GenericRegistry exception-safety prerequisite remains from earlier audit
  Источник: [CP06, next_abstraction](../next_abstraction/REPORT_RU.md).

- **DA-04 [P3; architecture_observation]** — Orchestrator name обозначает presentation owner
  DecisionCard/lazy exports do not execute workflows; helper is useful, name obscures launcher.
  Ограничение: Not dead code, outage or permission for deletion.
  Источник: [CP05, next_directory_architecture](../next_directory_architecture/REPORT_RU.md).

- **LIB-03 [P3; reuse_decision]** — Weighted quantiles имеют три разных estimands
  Six weighted-quantile functions represent three estimands: midpoint interpolation, cumulative interpolation, inverse step CDF. Consolidate only after explicit method/policy choice.
  Ограничение: Whole estimators, native imports, all weighted-quantile consumers/census.
  Источник: [CP04, next_library](../next_library/REPORT_RU.md).

- **LIB-04 [P3; reuse_decision]** — Сохранить выбранный AUC contract и refusal
  150 finite/tied AUC controls agree with sklearn/rank adapter; preserve one-class refusal rather than new NaN and optional ML dependency. No defect asserted.
  Ограничение: Native monitor event/budget/registry flow and deployment-scale performance.
  Источник: [CP04, next_library](../next_library/REPORT_RU.md).

- **NR-02 [P3; finding]** — Shadow metric projection теряет полный путь
  Three typed DataForge shadow compares flatten dotted/nested metric keys onto same path and lose a changed metric; Ukraine typed counts do not admit that nested witness.
  Ограничение: see primary report; bounded evidence does not establish operational incidence
  Источник: [CP02, next_reuse](../next_reuse/REPORT_RU.md).

- **NR-03 [P3; reuse_decision]** — Reuse полного artifact-view identity key
  Four full artifact-view identity helpers agree on artifact ID, kind, media and manifest profile; existing Core primitive is reuse candidate, not authority/nominal DTO replacement.
  Ограничение: see primary report; bounded evidence does not establish operational incidence
  Источник: [CP02, next_reuse](../next_reuse/REPORT_RU.md).

- **NR-04 [P3; reuse_decision]** — Reuse Core entry-point enumeration
  Existing Core entry-point enumeration agrees for real stdlib EntryPoint inputs across five selected modes, preserving ordering and error envelope; arbitrary impostors are not equivalent.
  Ограничение: see primary report; bounded evidence does not establish operational incidence
  Источник: [CP02, next_reuse](../next_reuse/REPORT_RU.md).

- **NR-05 [P3; reuse_decision]** — Consolidate causal importance formatter
  Three causal feature-importance leaf formatters agree across seven boundary cases; estimator sensitivity, RNG and homogeneous-effect policy remain different owners.
  Ограничение: see primary report; bounded evidence does not establish operational incidence
  Источник: [CP02, next_reuse](../next_reuse/REPORT_RU.md).

- **NR-06 [P3; finding]** — LRU nullable presence contract перед reuse
  LRU.delete removes stored None but returns false; other falsy values return true. Maintained NodeResultCache uses ArtifactRef and pop, so live nullable-delete incident not shown.
  Ограничение: see primary report; bounded evidence does not establish operational incidence
  Источник: [CP02, next_reuse](../next_reuse/REPORT_RU.md).

### R10. Согласовать source contracts и REST continuation

Existing contract, version и retry owners; candidate admission отдельно от protected acquisition.

**Acceptance:** Actual two-source pool→fetch→CAS/replay→fresh refresh; preserve cancellation, matching contract and resource release.

- **SA-01 [P2; finding]** — Non-injective schema-id filesystem projection overwrites a different registered schema
  Два валидных schema IDs с одинаковой projection и version перезаписывают один filesystem JSON; fresh subprocess сохраняет только последнего writer.
  Ограничение: Нет обнаруженного direct first-party runtime constructor; alias/dynamic/external reach не исключён.
  Источник: [CP12, next_source_adapters](../next_source_adapters/REPORT_RU.md).
  Review: [next_review_synthesis](../next_review_synthesis/REPORT_RU.md).

- **SA-02 [boundary; integration_boundary]** — Generic source inference is not automatic governed schema admission
  Strict proxy пропускает отсутствующий contract; matching valid проходит, matching invalid и breaking change без approval отказывают. Generic inference не выдаёт governed admission.
  Ограничение: Это граница политики, не универсальная ошибка validation и не authority bypass; full bootstrap не выполнен.
  Источник: [CP12, next_source_adapters](../next_source_adapters/REPORT_RU.md).
  Review: [next_review_synthesis](../next_review_synthesis/REPORT_RU.md).

- **SA-03 [P2_if_relied_on_as_geojson_validation; finding]** — GeoJSON parser accepts invalid structural/geometric content and properties can replace feature_id
  GeoJSON adapter принимает invalid structural/geometric content; properties может заменить feature_id.
  Ограничение: P2 условен на использование adapter как валидатора GeoJSON; author replay воспроизведён, независимый exhaustive corpus и downstream admission отсутствуют.
  Источник: [CP12, next_source_adapters](../next_source_adapters/REPORT_RU.md).
  Review: [next_review_synthesis](../next_review_synthesis/REPORT_RU.md).

- **AR-01 [P2 / medium; finding]** — REST page transport loses request retry veto and connection retry limits
  REST page transport теряет request.retryable=False и connection retry budget; scripted responses вызывают лишние GET. Shared owner соблюдает veto, когда получает request.
  Ограничение: Не показаны live provider или повтор write/mutation; native registry не выполнен.
  Источник: [CP15, next_adapter_resilience](../next_adapter_resilience/REPORT_RU.md).
  Review: [next_review_adapters_ui](../next_review_adapters_ui/REPORT_RU.md).

- **AR-02 [P2 / medium; finding]** — Partial page validator is promoted to aggregate DataVersion
  Validator одной страницы становится версией всего агрегата: bytes/content_hash меняются, но version comparison остаётся unchanged.
  Ограничение: Fresh DTO reader читает audit JSON, не product CAS/cache. Единственный обнаруженный production is_newer_than caller — file_tabular; REST refresh effect не доказан.
  Источник: [CP15, next_adapter_resilience](../next_adapter_resilience/REPORT_RU.md).
  Review: [next_review_adapters_ui](../next_review_adapters_ui/REPORT_RU.md).

- **AR-03 [P2 / medium; finding]** — Rate metadata parse and retry exhaustion escape FetchError continuation boundary
  Malformed 429 metadata и exhausted 503 выходят через реальный sync bridge как ValueError/RetryExhaustedError, вне FetchError continuation boundary.
  Ограничение: Четыре handles освобождены; 403/cancellation fail closed. Full two-source batch/record-replay не исполнен.
  Источник: [CP15, next_adapter_resilience](../next_adapter_resilience/REPORT_RU.md).
  Review: [next_review_adapters_ui](../next_review_adapters_ui/REPORT_RU.md).

### R11. Закрепить executable и checkpoint identity

Versioned semantic codec, exact executable selection, state/base/lineage и scoped factory; не создавать новый registry/CAS.

**Acceptance:** Fresh persistent consumer после drift/restore; full strict execution positives и negative exact-identity controls.

- **MA-01 [P2; finding]** — Registry cache omits semantic metadata from validity and uses lossy ABI projections as persistence codec
  Metadata-only drift при прежней signature оставляет cached candidate runnable; semantic bounds/contracts теряются в persistence при прежних digest.
  Ограничение: Candidate consistency, не обход executable decorators/strict contracts; application cache consumer не найден literal census.
  Источник: [CP13, next_method_admission](../next_method_admission/REPORT_RU.md).
  Review: [next_review_method_replay](../next_review_method_replay/REPORT_RU.md).

- **MA-02 [P2; finding]** — Generic lazy registry/candidate dispatcher does not reconcile declared and loaded executable identity
  Generic lazy registry может объявить A, загрузить и исполнить B, приписав history A. Независимый NumPy control отличает +9 от −3.
  Ограничение: Условие: inconsistent supplier/stale mapping; component bridge, typed selector и compiled chain имеют более строгие guards. Не все admission gates обходятся.
  Источник: [CP13, next_method_admission](../next_method_admission/REPORT_RU.md).
  Review: [next_review_method_replay](../next_review_method_replay/REPORT_RU.md).

- **MA-03 [P3; finding]** — Registry cache restores nested qualname as an unresolvable single attribute
  Module-level nested class counted restored, но одношаговый getattr не разрешает dotted qualname; flat peer работает.
  Ограничение: Локальный persistence defect, не arbitrary import exploit; native/default bootstrap не квалифицирован.
  Источник: [CP13, next_method_admission](../next_method_admission/REPORT_RU.md).
  Review: [next_review_method_replay](../next_review_method_replay/REPORT_RU.md).

- **RR-02 [P2_conditional_on_mismatched_producer_inputs; finding]** — Incremental checkpoint state/base pairing and dependency closure are not independently established
  Принятый previous-state/base mismatch даёт materialized state, отличный от submitted state; required base отсутствует в manifest.inputs.
  Ограничение: Mismatched producer inputs введены явно; normal hook не доказан самопроизвольно нарушающим пару. Graph честно обходит manifest.inputs, а materializer после missing base отказывает.
  Источник: [CP13, next_run_replay](../next_run_replay/REPORT_RU.md).
  Review: [next_review_method_replay](../next_review_method_replay/REPORT_RU.md).

- **RR-03 [P2; finding]** — Checkpoint hook export/restore loses filesystem CAS custody configuration
  Обычный hook export/restore теряет tenant/cell/enforcement в CAS factory; следующий checkpoint отвергается исходным scoped reader.
  Ограничение: Foreign metadata reconciliation сохраняет refusal; не показаны foreign read, full Ray/Temporal resume или HTTP bypass.
  Источник: [CP13, next_run_replay](../next_run_replay/REPORT_RU.md).
  Review: [next_review_method_replay](../next_review_method_replay/REPORT_RU.md).

- **policy-assembly::PA-01 [P2; finding]** — Runtime mechanism projection drops versioned executable identity
  Persisted plan не фиксирует выбранную versioned executable identity: согласованный новый FQN того же type меняет kernel старого selected plan; lexical projection выбирает v2 перед v10.
  Ограничение: Distinct от MA cache/lazy mismatch: здесь eager consistent FQNs. Нет full graph/JAX/scientific/publication qualification; class-source capture не связывает imported kernel closure и не является proved blocking gate.
  Источник: [CP17, next_policy_assembly](../next_policy_assembly/REPORT_RU.md).
  Review: [next_review_policy_assembly](../next_review_policy_assembly/REPORT_RU.md).

- **policy-assembly::PA-02 [P2; finding]** — Typed constraint threshold loses executable representation in lowering
  MoneyValue проходит linker/compile, lowering сохраняет wrapper как dict в Any, fresh actual evaluator отказывает nonnumeric.
  Ограничение: Fail-closed runtime failure, не false approval. Rate/Count/Duration только lowerer/evaluator differential, не полный unit-aware roundtrip.
  Источник: [CP17, next_policy_assembly](../next_policy_assembly/REPORT_RU.md).
  Review: [next_review_policy_assembly](../next_review_policy_assembly/REPORT_RU.md).

### R12. Исправить численные и нормативные контракты

Разделить scale/tolerance/statistics/support semantics, определить weight contract и сохранить typed unavailable/candidate authority.

**Acceptance:** Independent numerical oracles, scale covariance, unit/degenerate cases, persistence/replay и complete protected consumer отдельно.

- **DP-01 [P2; contract_clarification_and_correctness]** — Zero-weight and zero-contribution terms alter normative welfare choice
  Явный welfare_weight=0 превращается в 1. Zero-coefficient additions сохраняют utilities, но меняют сумму weights и local normative outcome.
  Ограничение: P2 — repair/contract clarification, не security severity. Multi-term semantics схемой не определены; изменение суммы weights не доказывает нормативное намерение. Helper approve не final authority.
  Источник: [CP16, next_decision_path](../next_decision_path/REPORT_RU.md).
  Review: [next_review_decision_custody](../next_review_decision_custody/REPORT_RU.md).

- **SI-01 [P2 numerical diagnostic correctness, not security severity; finding]** — Continuous ENCE silently omits zero/small-spread bins and reports zero error
  Dimensionless ENCE меняется 1→0 при общем положительном scale 10⁻¹³; zero spread/nonzero error также выдаёт 0, replay сохраняет поведение.
  Ограничение: Zero denominator математически undefined: review не навязывает finite/infinite замену. Coverage/PIT остаются; validation blocked/unverified; production bypass не доказан.
  Источник: [CP20, next_scientific_integrity](../next_scientific_integrity/REPORT_RU.md).
  Review: [next_review_scientific_integrity](../next_review_scientific_integrity/REPORT_RU.md).

- **SI-02 [P2 numerical and local uncertainty-decision correctness, not security severity; finding]** — Unconditional coverage p-value is delivered as conditional coverage and changes horizon eligibility
  Unconditional df1 p-value передаётся как conditional coverage; source local horizon GREEN, обе независимые joint df2 conventions дают p<.05 и RED.
  Ограничение: Конвенции conditioning чуть различаются численно. Chi-square asymptotic; synthetic sequence не empirical FPR. contract_only, production_value_eligible=false; no fitted GARCH/admission.
  Источник: [CP20, next_scientific_integrity](../next_scientific_integrity/REPORT_RU.md).
  Review: [next_review_scientific_integrity](../next_review_scientific_integrity/REPORT_RU.md).

- **CR-01 [P2; finding]** — Calibration adapter bypasses existing Gaussian representability guards
  Calibration adapter теряет ненулевой Gaussian spread при canonicalization/binary64 absorption; existing Gaussian helper сохраняет представимый диапазон или отказывает.
  Ограничение: Candidate numerical correctness only. Helper не переносит carrier без расширения; DECIMAL_EXACT не arbitrary precision. Heuristic gate=false сохранён.
  Источник: [CP21, next_calibration_reuse](../next_calibration_reuse/REPORT_RU.md).
  Review: [next_review_data_calibration](../next_review_data_calibration/REPORT_RU.md).

- **CR-02 [P3; finding]** — Scalar push-forward uses absolute numeric tolerance as SD and upgrades Gaussian heuristic range to deterministic bounds
  Scalar push-forward использует numeric tolerance как SD floor: linear 10¹³x даёт std=10 вместо 1; Gaussian heuristic range становится deterministic bounds.
  Ограничение: P3 exported API only; literal product caller не найден, dynamic/external не исключены. gate=false и trust refusal сохранены; один API finding с двумя связанными аспектами.
  Источник: [CP21, next_calibration_reuse](../next_calibration_reuse/REPORT_RU.md).
  Review: [next_review_data_calibration](../next_review_data_calibration/REPORT_RU.md).

### R13. Замкнуть release provenance и report schema

Immutable generated release snapshot → validated fragments → exact tag/source SHA → SBOM/report/shipped artifact.

**Acceptance:** Fresh hosted jobs with immutable byte transfer and actual pinned scanner; no release from local fixture success.

- **REL-01 [high; finding]** — Required generated release snapshot is not delivered to fresh CI jobs
  Fresh release jobs не получают обязательный generated snapshot. Staging всех 548 TOML проходит, notes renderer падает на одном fragment без top-level type/summary; 547 без него render успешно.
  Ограничение: High — release-blocking operational priority, не exploit. Fragment schema-invalid, не syntax-invalid TOML. Hosted release/shipped artifact не выполнены.
  Источник: [CP22, next_release_integrity](../next_release_integrity/REPORT_RU.md).
  Review: [next_review_release](../next_review_release/REPORT_RU.md).

- **REL-02 [high; finding]** — Dispatch release tag is not bound to checkout/build source commit
  Manual dispatch tag не сверяется с source commit; local two-commit Git fixture с одинаковой package version проходит resolver/checker при разных SHA.
  Ограничение: High — privileged release integrity priority. Default checkout привязан к event ref/SHA, не latest main; low-privilege actor/approval bypass/wrong publication не установлены. REL-01 блокирует fresh prepare.
  Источник: [CP22, next_release_integrity](../next_release_integrity/REPORT_RU.md).
  Review: [next_review_release](../next_review_release/REPORT_RU.md).

- **REL-03 [medium; evaluator_robustness_gap]** — Vulnerability evaluator accepts missing or malformed scan results as no findings
  Evaluator принимает missing/некоторые wrong-type matches как отсутствие findings; real upstream Critical golden блокируется, modeled nonzero scanner останавливает caller.
  Ограничение: Medium robustness only. Upstream Grype model создаёт array matches; successful malformed output реального scanner не доказан. Unknown rank=0 — явная policy; fix nesting влияет лишь на summary.
  Источник: [CP22, next_release_integrity](../next_release_integrity/REPORT_RU.md).
  Review: [next_review_release](../next_review_release/REPORT_RU.md).

## 6. Положительные защиты, которые нельзя потерять

- **G01. SQL lease/current-owner/commit fences.** Five synchronized lease races, stale-owner refusal, lease expiry before commit and process-death rollback. Domain intents/outbox atomic rollback also observed. Граница: SQLite selected owners; not PostgreSQL/distributed or all writers.
- **G02. Closed runtime guards stop new calls.** Default-shaped shutdown closes store guard and denies new effects; already-running operations require separate settlement. Граница: Not physical thread termination.
- **G03. Exact finalize and validity refusals.** Non-workflow/post-terminal recovery works; foreign/malformed journal refused. Malformed queued payload, wrong source attempt, changed HTE payload, corrupt dedupe and generic SEMANTIC_EPOCH refused. Граница: Does not repair lost selection or missing per-target event.
- **G04. Budget unknown is fail-closed.** Same-run admission stays blocked by terminal unknown; native budget observer/ledger owners distinguish callback and physical completion. Граница: No overspend bypass; late known outcome reconciliation is unresolved in direct repeated-cancel branch.
- **G05. N5 historical content is not live permit.** Fresh process historical read allowed, live reuse refused; self-consistent unissued marker refused; current SQL lease re-read rejects old owner after takeover. Граница: Positive genuine seal/revoke/PA2 terminal commit unrun.
- **G06. Artifact ownership/profile/integrity retained.** Tenant/cell/profile checks, same-size/same-mtime corruption refusal, detached row copies and cross-instance current generation visible. Граница: Exact source/owner controls, not full authenticated API isolation.
- **G07. Candidate status is not evidence authority.** Missing source/method gates, satisfied-method→limit, candidate-only scope/rights checks, fresh persisted descriptor tamper refusal. Граница: Compiler established or selected_exact does not imply admitted scientific support.
- **G08. Publication owners fail closed.** Unappointed root, eligibility/currentness and custody/signer/mandate constraints remain. Private draft roundtrip fails before public issuance. Граница: Synthetic owner fixture does not provide real institutional authority.
- **G09. Scientific source and selected ref guards.** Wrong profiles/missing diagnostics and wrong simulation/missing lineage refused; invented Scholar span rejected by actual source/Scientist verifier. Граница: Report/job complete or IR available is not scientific/institutional acceptance.
- **G10. Existing meaningful tests and reuse boundaries.** Persisted corruption/removal tests exist; 19 real Node package tests ran under Node24. AUC selected finite/tie behavior agrees, quantile estimands intentionally differ, facades often legitimate. Граница: Authored tests are not fresh native PASS; Node24 not Node22; no universal replace-all libraries conclusion.
- **G11. Matching contract and schema admission guards.** Matching invalid schema, same-version and unapproved breaking changes refuse; noncollision and distinct versions retain both IDs. Граница: Missing-contract pass is a candidate/protected-boundary policy question; not full bootstrap.
- **G12. Strict method binding and checkpoint refusals.** Typed selector detects actual callable mismatch; signature drift invalidates cache. Foreign checkpoint scope, corrupt oldest invocation and missing base refuse. Граница: Does not repair lower lazy registry/cache codec or state/base pairing; shared loader and no full worker.
- **G13. Actual numerical DiD and source replay.** Standard/Staggered DiD match independent synthetic-panel numerical contrasts; coherent stored-report tampering refuses. Failure envelope drives uncertainty=1 and ConfidencePass blocker. Граница: Candidate scientific computations, not true empirical identification or protected authority.
- **G14. Adapter resource and UI boundary controls.** Handles release, cancellation/403 refuse; identity layout gate/scoped envelope exist. Global incidents include network status0,403/5xx and401 redirect. Граница: No native React/browser or real provider/batch proof; local history ambiguity remains.
- **G15. Persisted tenant/cell/profile custody.** Full ControlWorker, FileSystemCAS and SQLite preserve live-lease/creation scope across fresh reopen; foreign tenant, full cell, selected profile and input edge refuse. Граница: Reviewer did not rerun product; raw temporary tenant fixtures were deleted. No full authenticated Runtime/HTTP or exploit pass.
- **G16. Assembly linker/conflict/evaluator controls.** Duplicate FQN, amount bounds, kind/binding, unsupported fidelity, missing kernel/slot and nonfinite state refuse; Decimal pass/violation and EUR/USD refusal distinguish. Граница: Unknown parameter warns rather than refuses; identity capture not a proved blocking gate; no full execution graph.
- **G17. Governance availability is not authority.** Nine vectors roundtrip but source-bound search score stays not_established; EvaluationSafety rejects foreign verified DTO; legal owner refuses required authority; v1 reports do not become current by CAS roundtrip. Граница: Whole current source→science→normative→legal→governance positive chain not executed.
- **G18. Cached physical settlement survives waiter loss.** One physical call yields one charge; takeover preserves old-attempt spending while blocking stale publication/reuse; lost acknowledgement reconciles by readback. Unknown provider/physical-owner cancellation blocks admission. Граница: Positive sibling cached path, not BUD-01 direct-client fix. Manual guard wiring; no public cancel, sync timeout/loop closure, disk crash or external physical-stop proof.
- **G19. Exact custody current-positive and tamper refusals.** Current receipts pass direct/service; wrong query, poisoned append, corrupt signature, missing retained entry, bad selector/predecessor/reconciliation/role/revoked issuer refuse. Граница: Synthetic institution/issuer; historical service mismatch survives; no holder/retention positive or public authority.
- **G20. Scientific replay and nonproduction qualification.** Fresh continuous/forecast reads and nine valid-hash perturbation refusals retained; wrong population refuses. Continuous validation remains blocked/unverified and forecast projection explicitly contract-only. Граница: Local horizon may still turn GREEN under SI-02; no whole-product scientific safety claim.
- **G21. Calibration Gaussian guards and trust refusal.** Existing helper preserves representable small intervals or refuses absorption; independent linear/constant-map controls and 28 fresh candidate envelope reads retain gate=false; heuristic promotion refuses. Граница: Helper needs carrier extension; no arbitrary precision or complete forgery/authority safety claim.
- **G22. Existing data-service test bodies and isolated fixture.** Real isolated-schema fixture and meaningful concurrency/readback tests exist; required-input removal refuses. Граница: Source-defined tests and bounded setup controls are not actual collection, PostgreSQL execution or hosted CI PASS.
- **G23. Release fail-closed controls.** Missing/empty snapshot/version mismatch fail; 547 valid fragments render. Event ref/SHA checkout pinning exists; real upstream Critical golden and nonzero modeled scanner block. Граница: No actual scanner/hosted release. Unknown severity remains explicit rank0 policy; invalid report robustness is not scanner bypass proof.

## 7. Что остаётся в аудите

Подробная карта [OPEN_WORK.json](OPEN_WORK.json) сохраняет все 11 source-level, 5 native и 5 production gaps из coverage16 и добавляет прогресс checkpoint17–22. Наличие карточек не закрывает исходные цепочки. Имена W01–W09 относятся к [research work packages](../next_coverage_16/WORK_PACKAGES.json); R0–R13 — к remediation roadmap этой сводки.

- Whole current source→method→ObjectiveStack→legal→governance positive chain; stale selector falsifier и decision contract.
- Appointed signed public claim population/current reader, custody holder/retention positives, genuine N5 issuance→revoke→PA2 terminal commit.
- Full authenticated Runtime/cancel/resume, actual direct-client repeated cancellation and sync timeout/loop shutdown.
- Actual two-source REST batch/CAS/refresh и genuinely admitted zero-code resources до served consumer.
- Native pinned profile, real PostgreSQL, OPA, browser/Node22, installed distributions, actual Grype/SBOM и fresh hosted immutable release.
- Broader unqualified roots/model promotion/monitoring, real workload denominators/concurrency/migrations. Проведённые calibration slices больше не indexed-only, но весь scientific domain не квалифицирован.

## 8. Навигация и целостность

- [REGISTRY.json](REGISTRY.json) и [FINDINGS.json](FINDINGS.json) идентичны: accepted summaries, exact raw records/pointers, review restrictions, owner/repair/acceptance.
- [NAVIGATION.json](NAVIGATION.json): checkpoint→thematic/review→IDs; [ROADMAP.json](ROADMAP.json): future changes/dependencies; [REUSE_DECISIONS.json](REUSE_DECISIONS.json): bounded reuse.
- [INPUT_MANIFEST.json](INPUT_MANIFEST.json): замороженные входы; [REFERENCE_VALIDATION.json](REFERENCE_VALIDATION.json): pointers/hashes; [SOURCE_VALIDATION.json](SOURCE_VALIDATION.json): все baseline-listed source bytes; [VALIDATION.json](VALIDATION.json): synthesis integrity only.
- [REVIEW_APPLICATION.json](REVIEW_APPLICATION.json): что действительно reviewed и что лишь inherited; [REJECTED_SIGNALS.json](REJECTED_SIGNALS.json): исключённые расширения выводов.
- [Прежняя сводка 01–11](../next_cumulative_synthesis/REPORT_RU.md) остаётся исторической и не переписана. Для упаковки нужны sibling evidence directories из INPUT_MANIFEST; одни эти ссылки не делают архив self-contained.

**Статус остаётся PARTIAL. Сводка завершена как навигационный deliverable, но системный аудит, исправления и приёмка продукта не завершены.**
