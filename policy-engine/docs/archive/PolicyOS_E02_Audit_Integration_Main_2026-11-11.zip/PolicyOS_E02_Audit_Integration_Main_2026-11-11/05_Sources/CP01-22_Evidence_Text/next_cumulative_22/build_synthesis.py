#!/usr/bin/env python3
"""Read-only evidence synthesis. Writes only its own new output directory."""
from pathlib import Path
import collections, copy, datetime, hashlib, json, re

OUT = Path(__file__).resolve().parent
BASE = OUT.parent
WORK = BASE.parent
OLD = BASE / 'next_cumulative_synthesis'
COMMIT = 'f1541ed155f278689be48a8c7ac56c3e200210f7'
TREE = '29890b967236a8f07e2b0f92a0133ee36883ac49'
NOW = datetime.datetime.now(datetime.timezone.utc).isoformat()

def read(p):
    return json.loads(Path(p).read_text())

def digest(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()

def write(name, obj):
    (OUT / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')

def ptr(obj, pointer):
    if not pointer or pointer == '#': return obj
    pointer = pointer.removeprefix('#')
    assert pointer.startswith('/'), pointer
    for part in pointer.split('/')[1:]:
        part = part.replace('~1','/').replace('~0','~')
        obj = obj[int(part)] if isinstance(obj,list) else obj[part]
    return obj

def binding(path, pointer=None):
    p = BASE / path
    result = {'path': path, 'bytes': p.stat().st_size, 'sha256': digest(p)}
    if pointer is not None:
        value = ptr(read(p), pointer)
        result['json_pointer'] = pointer
        result['selected_value_sha256'] = hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    return result

OLD_REGISTRY = read(OLD/'REGISTRY.json')
OLD_NAV = read(OLD/'NAVIGATION.json')
NEW_DIRS = {
 12: ['next_source_adapters','next_review_synthesis'],
 13: ['next_method_admission','next_run_replay','next_review_method_replay'],
 14: ['next_guard_enforcement','next_method_execution','next_review_guard_method'],
 15: ['next_adapter_resilience','next_ui_ownership','next_review_adapters_ui'],
 16: ['next_decision_path','next_tenant_custody','next_review_decision_custody'],
 17: ['next_policy_assembly','next_coverage_16','next_review_policy_assembly'],
 18: ['next_governance_handoff','next_execution_owner','next_review_governance_execution'],
 19: ['next_remaining_custody','next_review_custody_history'],
 20: ['next_scientific_integrity','next_review_scientific_integrity'],
 21: ['next_data_service_tests','next_calibration_reuse','next_review_data_calibration'],
 22: ['next_release_integrity','next_review_release'],
}
DIR_CP = {e['directory']:e['checkpoint'] for e in OLD_NAV['entries']}
DIR_CP.update({d:cp for cp,ds in NEW_DIRS.items() for d in ds})
INPUT_DIRS = sorted(set(DIR_CP) | {'next_cumulative_synthesis','baseline','reuse','ownership','scaling','structure','checkpoint_recovery'})
SYN_REVIEW = BASE/'next_review_cumulative_22'
if (SYN_REVIEW/'REPORT_RU.md').is_file() and (SYN_REVIEW/'REVIEW_DECISIONS.json').is_file():
    INPUT_DIRS.append('next_review_cumulative_22')
INPUT_FILES = []
for d in INPUT_DIRS:
    for p in sorted((BASE/d).rglob('*')):
        if p.is_file() and not any(x in p.parts for x in ['__pycache__','uv_cache','.git']):
            INPUT_FILES.append({'path':str(p.relative_to(BASE)), 'bytes':p.stat().st_size, 'sha256':digest(p)})
for n in ['PLAN_RU.md','FINDINGS.json','SYS_FINDINGS.json','AUDIT_PLAN.json']:
    p=BASE/'plan'/n
    if p.is_file(): INPUT_FILES.append(binding(str(p.relative_to(BASE))))
write('INPUT_MANIFEST.json', {'generated_at_utc':NOW,'status':'frozen_readset','checkpoint_scope':[1,22], 'path_base':'policyos_deep_audit', 'semantic_review_of_every_byte':False, 'files':INPUT_FILES})

# Local primary records remain exact and are not renamed. Namespaces are view identities.
RENAME = {'PA-01':'publication-authority::PA-01','RC-01':'scholar::RC-01'}
findings = copy.deepcopy(OLD_REGISTRY['findings'])
for f in findings:
    previous=f['id']
    f['id']=RENAME.get(previous,previous)
    f['mechanism_key']=RENAME.get(f['mechanism_key'],f['mechanism_key'])
    f['inherited_from']={'path':'next_cumulative_synthesis/REGISTRY.json','json_pointer':f"/findings/{next(i for i,x in enumerate(OLD_REGISTRY['findings']) if x['id']==previous)}",'sha256':digest(OLD/'REGISTRY.json'),'old_display_id':previous}
    if previous in RENAME:
        f['aliases']=[f['id']]
        f['local_aliases']=[{'directory':f['evidence_sources'][0]['directory'],'id':previous}]
    f['synthesis_22_change']='namespace_only' if previous in RENAME else 'inherited_without_semantic_change'

REVIEW_INFO = {
 'next_source_adapters':('next_review_synthesis','REVIEW_DECISIONS.json','source review, independent collision/matching controls; SA-03 author replay only'),
 'next_method_admission':('next_review_method_replay','REVIEW_DISPOSITION.json','new finite fixtures and processes; shared compatibility loader'),
 'next_run_replay':('next_review_method_replay','REVIEW_DISPOSITION.json','new checkpoint/history controls; expensive 32-attempt wave not rerun'),
 'next_guard_enforcement':('next_review_guard_method','REVIEW_DISPOSITION.json','independent bounded controls; no hosted/native gate'),
 'next_adapter_resilience':('next_review_adapters_ui','REVIEW.json','independent adapter/bridge controls; no live providers/CAS batch'),
 'next_ui_ownership':('next_review_adapters_ui','REVIEW.json','exact source action bodies under Node24 with ports; no React/browser'),
 'next_decision_path':('next_review_decision_custody','REVIEW_DECISIONS.json','source/evidence/hash review and independent arithmetic; no product rerun'),
 'next_policy_assembly':('next_review_policy_assembly','REVIEW_DISPOSITION.json','independent compile/CAS/constructor and evaluator; no full numerical graph'),
 'next_remaining_custody':('next_review_custody_history','REVIEW_DISPOSITION.json','independent three-acceptance chain, fresh process and extraction reopen'),
 'next_scientific_integrity':('next_review_scientific_integrity','FINDINGS.json','independent numerical oracles and fresh persisted reads; compatibility execution'),
 'next_data_service_tests':('next_review_data_calibration','REVIEW_DECISIONS.json','source wiring and bounded setup/input controls; no real PostgreSQL or hosted CI'),
 'next_calibration_reuse':('next_review_data_calibration','REVIEW_DECISIONS.json','new precision/scale controls and fresh envelope reads; original report revalidation'),
 'next_release_integrity':('next_review_release','FINDINGS.json','actual local CLIs/Git fixtures and upstream golden JSON; scanner substituted in caller controls'),
}

def primary_records(directory):
    data=read(BASE/directory/'FINDINGS.json')
    if isinstance(data,list): return [(f'/{i}',x) for i,x in enumerate(data)]
    key='local_findings' if 'local_findings' in data else 'findings'
    return [(f'/{key}/{i}',x) for i,x in enumerate(data[key])]

def evidence_source(d,pointer,raw):
    return {'directory':d,'checkpoint':DIR_CP[d],'report':d+'/REPORT_RU.md','record_path':d+'/FINDINGS.json','json_pointer':pointer,
      'report_sha256':digest(BASE/d/'REPORT_RU.md'),'deciding_evidence_original':raw.get('evidence',[]),
      'source_validation_receipts':[str(p.relative_to(BASE)) for p in sorted((BASE/d).glob('*VALIDATION*.json')) if 'SOURCE' in p.name.upper()],
      'artifact_manifests':[str(p.relative_to(BASE)) for p in sorted((BASE/d).glob('*MANIFEST.json'))],
      'primary_record_binding':binding(d+'/FINDINGS.json',pointer)}

def review(d,local_id):
    rd,rfile,mode=REVIEW_INFO[d]
    data=read(BASE/rd/rfile)
    selections=[]
    def walk(x,p=''):
        if isinstance(x,dict):
            if x.get('id')==local_id or x.get('local_id')==local_id or x.get('target')==local_id or x.get('finding_id') in [local_id,'custody::'+local_id]:
                selections.append((p,x)); return
            for k,v in x.items(): walk(v,p+'/'+k.replace('~','~0').replace('/','~1'))
        elif isinstance(x,list):
            for i,v in enumerate(x):walk(v,p+'/'+str(i))
    walk(data)
    if not selections and isinstance(data,dict) and local_id in data: selections=[('/'+local_id,data[local_id])]
    if not selections: selections=[('',data)]
    return {'report':rd+'/REPORT_RU.md','mode':mode,'machine_decisions':[rd+'/'+rfile], 'bindings':[binding(rd+'/'+rfile,p) for p,x in selections], 'qualified_review_records':[x for p,x in selections]}

# Accepted wording is deliberately narrower than primary titles where review requires it.
# Each tuple is (accepted summary, mandatory limit, repair, acceptance, package, optional kind).
CARDS = {
'SA-01':('Два валидных schema IDs с одинаковой projection и version перезаписывают один filesystem JSON; fresh subprocess сохраняет только последнего writer.', 'Нет обнаруженного direct first-party runtime constructor; alias/dynamic/external reach не исключён.', 'Инъективное кодирование identity с conflict detection и migration.', 'Два colliding IDs в обоих порядках, разные версии и noncollision; fresh process и migration/readback.', 'R10'),
'SA-02':('Strict proxy пропускает отсутствующий contract; matching valid проходит, matching invalid и breaking change без approval отказывают. Generic inference не выдаёт governed admission.', 'Это граница политики, не универсальная ошибка validation и не authority bypass; full bootstrap не выполнен.', 'Явно назначить missing-contract policy для candidate и protected acquisition, использовать существующего contract owner.', 'Missing/valid/invalid contract на actual admitted caller; не ломать version/approval guards.', 'R10','integration_boundary'),
'SA-03':('GeoJSON adapter принимает invalid structural/geometric content; properties может заменить feature_id.', 'P2 условен на использование adapter как валидатора GeoJSON; author replay воспроизведён, независимый exhaustive corpus и downstream admission отсутствуют.', 'Валидировать protocol semantics и зарезервировать structural fields до SILVER/spatial flags.', 'Geometry/type/coordinate corpus, reserved-field collision, protected downstream admission и legitimate controls.', 'R10'),
'MA-01':('Metadata-only drift при прежней signature оставляет cached candidate runnable; semantic bounds/contracts теряются в persistence при прежних digest.', 'Candidate consistency, не обход executable decorators/strict contracts; application cache consumer не найден literal census.', 'Versioned semantic snapshot отдельно от stable ABI; metadata/source/profile binding, legitimate overlays сохранить.', 'Fresh SQLite read после metadata/signature drift, complete bounds/contracts roundtrip, actual cache caller и strict execution controls.', 'R11'),
'MA-02':('Generic lazy registry может объявить A, загрузить и исполнить B, приписав history A. Независимый NumPy control отличает +9 от −3.', 'Условие: inconsistent supplier/stale mapping; component bridge, typed selector и compiled chain имеют более строгие guards. Не все admission gates обходятся.', 'Canonical load reconciliation и явный admitted executable contract; intentional aliases декларировать.', 'Wrong FQN/class/signature, legitimate aliases, strict positive and negative paths и persisted history attribution.', 'R11'),
'MA-03':('Module-level nested class counted restored, но одношаговый getattr не разрешает dotted qualname; flat peer работает.', 'Локальный persistence defect, не arbitrary import exploit; native/default bootstrap не квалифицирован.', 'Общий малый qualified-target resolver либо upfront unsupported-target refusal.', 'Flat/nested module classes, rejected locals и fresh-process load/execute; различить restored и admitted.', 'R11'),
'RR-02':('Принятый previous-state/base mismatch даёт materialized state, отличный от submitted state; required base отсутствует в manifest.inputs.', 'Mismatched producer inputs введены явно; normal hook не доказан самопроизвольно нарушающим пару. Graph честно обходит manifest.inputs, а materializer после missing base отказывает.', 'Связать state с exact base; run/origin/sequence/depth continuity, selected lineage edges и reader bound.', 'Отдельно закрыть state/ref binding, ancestor continuity, manifest closure и reader depth; fresh reader, foreign scope и missing/corrupt base.', 'R11'),
'RR-03':('Обычный hook export/restore теряет tenant/cell/enforcement в CAS factory; следующий checkpoint отвергается исходным scoped reader.', 'Foreign metadata reconciliation сохраняет refusal; не показаны foreign read, full Ray/Temporal resume или HTTP bypass.', 'Передать exact admitted scope/enforcement через существующий artifact factory.', 'Untouched metadata fresh restore, original scoped reader, foreign metadata refusal, real worker и nonfilesystem policy.', 'R11'),
'GE-01':('Direct docs gate превращает Git diff failure в пустой change set: valid base отказывает по obligation, missing/zero base возвращает 0.', 'Локальная caller failure semantics; hosted bypass и green остальных jobs не установлены.', 'Reuse строгого Git owner; unknown diff возвращать failure/UNRUN, не empty success.', 'Valid/invalid/zero base через actual caller, обязательные docs changes и supported CLI.', 'R0'),
'GE-02':('Alternate candidate root не доходит до import subgates; shim проверяет checker root, пропуская defect только в candidate root.', 'Same-root guard работает; full aggregate green и native dynamic/cycle replay не доказаны.', 'Immutable candidate-root context через existing subgate owners.', 'Разные checker/candidate roots, отказ дефекта только в candidate и same-root positive/negative controls.', 'R0'),
'GE-03':('Один matching README снимает obligations нескольких изменённых facades.', 'Existential planner weakness, не доказанная semantic staleness или обход всех docs checks.', 'Per-facade unmatched set либо честно задокументированная coarse policy.', 'Два facade changes и один/два соответствующих README с отдельным impact-note control.', 'R0'),
'GE-C01':('Default import-timing test проверяет наличие baseline; live predicate различает synthetic 2× regression. Literal opt-in отсутствует в именованных workflow/action surfaces.', 'Coverage gap, не измеренная latency regression и не утверждение об отсутствии opt-in в hosted environment.', 'Явный live lane и отдельный статус existence versus measurement.', 'Supported runtime, declared selected lane и fail-on-regression/removal controls; provenance измерения.', 'R0','qualification_gap'),
'AR-01':('REST page transport теряет request.retryable=False и connection retry budget; scripted responses вызывают лишние GET. Shared owner соблюдает veto, когда получает request.', 'Не показаны live provider или повтор write/mutation; native registry не выполнен.', 'Сохранить request retry veto и budget при page request через existing retry owner.', 'Veto на первой/следующей странице, budgets 1 и large, cancellation, actual pool/registry caller.', 'R10'),
'AR-02':('Validator одной страницы становится версией всего агрегата: bytes/content_hash меняются, но version comparison остаётся unchanged.', 'Fresh DTO reader читает audit JSON, не product CAS/cache. Единственный обнаруженный production is_newer_than caller — file_tabular; REST refresh effect не доказан.', 'Aggregate version должна покрывать каждую data page либо использовать content identity/fail-closed unknown.', 'Отсутствующий/terminal-only ETag и Last-Modified, changed page, actual REST refresh/CAS consumer.', 'R10'),
'AR-03':('Malformed 429 metadata и exhausted 503 выходят через реальный sync bridge как ValueError/RetryExhaustedError, вне FetchError continuation boundary.', 'Четыре handles освобождены; 403/cancellation fail closed. Full two-source batch/record-replay не исполнен.', 'Согласовать typed provider/error boundary с caller continuation, не поглощать cancellation.', 'Реальный two-source batch: продолжение только разрешённых fetch failures; handles, cancellation, storage/replay.', 'R10'),
'UI-01':('Поздний launch acceptance после reset восстанавливает старый runId; old terminal SSE во время нового pending launch сбрасывает новый streaming state.', 'Source action bodies с заменёнными ports, не native React/Zustand/browser; identity layout gate и scoped envelope существуют.', 'Conversation generation/identity owner для pending launch и SSE callbacks.', 'Browser reset/newSession/navigation/unmount/reconnect, stale success/failure и old-terminal/new-pending; persistence refusal.', 'R8'),
'UI-02':('Clerk history локально не различает error, empty и current list.', 'Global incidents покрывают network status=0, 403/5xx; 401 ведёт к login. Не whole-app silent error или cross-account leakage.', 'Локальные loading/error/empty/current состояния поверх existing global incidents.', 'Actual React Query transitions, stale data + error, 401/403/network и empty success.', 'R8'),
'UI-03':('Authoring contract запрещает API→features, но выбранная policy function пропускает два реальных imports.', 'Полный architecture checker блокирован missing TypeScript до AST scan; private cross-feature import уже отвергается.', 'Добавить направленное правило к existing architecture owner.', 'Real imports и allowed alternatives через native full scan, preserve existing cross-feature refusal.', 'R8'),
'DP-01':('Явный welfare_weight=0 превращается в 1. Zero-coefficient additions сохраняют utilities, но меняют сумму weights и local normative outcome.', 'P2 — repair/contract clarification, не security severity. Multi-term semantics схемой не определены; изменение суммы weights не доказывает нормативное намерение. Helper approve не final authority.', 'Явно определить multi-term weight composition и уважать explicit zero отдельно от missing.', 'Zero/missing/small-positive, decomposition/invariance cases после решения контракта; actual normative→governance chain.', 'R12','contract_clarification_and_correctness'),
'policy-assembly::PA-01':('Persisted plan не фиксирует выбранную versioned executable identity: согласованный новый FQN того же type меняет kernel старого selected plan; lexical projection выбирает v2 перед v10.', 'Distinct от MA cache/lazy mismatch: здесь eager consistent FQNs. Нет full graph/JAX/scientific/publication qualification; class-source capture не связывает imported kernel closure и не является proved blocking gate.', 'Сохранить exact selected method/kernel identity и dependency closure в plan; не re-resolve mutable type projection.', 'Все registration orders, namespaces, unrelated growth, fresh process и genuine full executor; changed imported kernel must distinguish.', 'R11'),
'policy-assembly::PA-02':('MoneyValue проходит linker/compile, lowering сохраняет wrapper как dict в Any, fresh actual evaluator отказывает nonnumeric.', 'Fail-closed runtime failure, не false approval. Rate/Count/Duration только lowerer/evaluator differential, не полный unit-aware roundtrip.', 'Typed executable threshold codec через lowering/persistence/evaluator без ослабления unit checks.', 'USD fresh compile/evaluate pass и violation, EUR mismatch refusal; остальные units с полным compiler/executor envelope.', 'R11'),
'custody::RC-01':('После продвижения lineage exact historical receipt проходит generic verifier, но production-configured custody service отвергает его; newest current receipt проходит.', 'Historical intent явен в core verifier; отдельный public endpoint historical SLA не установлен. Это bounded integration/history availability mismatch, не authority bypass; synthetic issuer/native inputs.', 'Развести exact historical reconstruction и current-state admission в existing custody owners.', 'Три sequential acceptances, historical/current exact query, fresh/archived reopen; poisoned append/signature/query/revoked issuer negatives; native service/API contract.', 'R5'),
'SI-01':('Dimensionless ENCE меняется 1→0 при общем положительном scale 10⁻¹³; zero spread/nonzero error также выдаёт 0, replay сохраняет поведение.', 'Zero denominator математически undefined: review не навязывает finite/infinite замену. Coverage/PIT остаются; validation blocked/unverified; production bypass не доказан.', 'Typed degeneracy/availability или явная scale-invariant denominator policy; versioned replay semantics.', 'Positive-scale covariance, zero/mixed bins, calibrated controls и fresh persisted numerical reader.', 'R12'),
'SI-02':('Unconditional df1 p-value передаётся как conditional coverage; source local horizon GREEN, обе независимые joint df2 conventions дают p<.05 и RED.', 'Конвенции conditioning чуть различаются численно. Chi-square asymptotic; synthetic sequence не empirical FPR. contract_only, production_value_eligible=false; no fitted GARCH/admission.', 'Разделить named UC/IND/CC statistics, null/df/assumptions и передать правильный CC в existing consumers.', 'Обе documented conditioning conventions, cluster/even/undercoverage, persisted forecast projections и wrong-population refusal; actual fitted path отдельно.', 'R12'),
'DST-01':('Real PostgreSQL tests могут skip в missing/caught setup branches; checked-in lane не задаёт DSNs и обязательный DS9 flag; отдельный C57 gate остаётся.', 'Не всякая backend error превращается в skip. Изолированная schema fixture существует. 52 source-defined bodies прочитаны, не collected/executed; hosted result неизвестен.', 'Disposable PostgreSQL service/profile и mandatory expected-node/zero-skip qualification; consolidate isolation.', 'Actual native collection, SQL concurrency/readback/cancel, missing DSN/setup/flag removal controls и hosted receipts.', 'R0','qualification_gap'),
'DST-02':('Standard Integration выбирает corpus tests с ignored production_data, не объявляя provisioning в checked-in workflow; missing path guard отказывает.', 'Existence-only positive не валидирует corpus; native builder/hosted job не выполнялись, более ранние setup failures возможны.', 'Hermetic semantic real-store fixture плюс отдельный pinned-corpus qualification lane.', 'Pinned bytes/provisioning, actual builder and selected cases, each required-file removal и missing-input refusal.', 'R0','ci_input_contract_defect'),
'CR-01':('Calibration adapter теряет ненулевой Gaussian spread при canonicalization/binary64 absorption; existing Gaussian helper сохраняет представимый диапазон или отказывает.', 'Candidate numerical correctness only. Helper не переносит carrier без расширения; DECIMAL_EXACT не arbitrary precision. Heuristic gate=false сохранён.', 'Reuse/extend existing Gaussian owner с carrier/covariance/refusal semantics.', 'Scale/representation covariance, large center/tiny spread и fresh envelope/report reads; carrier consistency, preserved candidate trust refusal.', 'R12'),
'CR-02':('Scalar push-forward использует numeric tolerance как SD floor: linear 10¹³x даёт std=10 вместо 1; Gaussian heuristic range становится deterministic bounds.', 'P3 exported API only; literal product caller не найден, dynamic/external не исключены. gate=false и trust refusal сохранены; один API finding с двумя связанными аспектами.', 'Разделить numerical tolerance и статистический scale; не повышать heuristic support до deterministic без proof.', 'Linear/constant maps, scale covariance, tolerance 0/default и semantic-kind persistence; actual caller если найден.', 'R12'),
'REL-01':('Fresh release jobs не получают обязательный generated snapshot. Staging всех 548 TOML проходит, notes renderer падает на одном fragment без top-level type/summary; 547 без него render успешно.', 'High — release-blocking operational priority, не exploit. Fragment schema-invalid, не syntax-invalid TOML. Hosted release/shipped artifact не выполнены.', 'Создать immutable selected snapshot, валидировать schema corpus, передавать exact bytes всем release jobs.', 'Fresh prepare/build/notes consumers, 548-fragment census/removal oracle, job artifact digest и version/tag consistency.', 'R13'),
'REL-02':('Manual dispatch tag не сверяется с source commit; local two-commit Git fixture с одинаковой package version проходит resolver/checker при разных SHA.', 'High — privileged release integrity priority. Default checkout привязан к event ref/SHA, не latest main; low-privilege actor/approval bypass/wrong publication не установлены. REL-01 блокирует fresh prepare.', 'Exact tag/source SHA binding; безопасная input handling через existing release owner, preserve event pinning.', 'Automatic tag push и manual dispatch, matching/mismatching SHA при одинаковой version, approvals и attestation subject on actual immutable object.', 'R13'),
'REL-03':('Evaluator принимает missing/некоторые wrong-type matches как отсутствие findings; real upstream Critical golden блокируется, modeled nonzero scanner останавливает caller.', 'Medium robustness only. Upstream Grype model создаёт array matches; successful malformed output реального scanner не доказан. Unknown rank=0 — явная policy; fix nesting влияет лишь на summary.', 'Валидировать report schema/identity и bind к exact SBOM; Unknown policy решить отдельно.', 'Actual pinned scanner/SBOM/database, malformed-success reachability, upstream empty/Critical, invalid JSON/types, exceptions и scanner failure.', 'R13','evaluator_robustness_gap'),
}

for d in REVIEW_INFO:
    for pointer,raw in primary_records(d):
        local_id=raw['id']
        if local_id=='DP-O1': continue
        if local_id=='RR-01':
            f=next(x for x in findings if x['id']=='ST-02')
            f['aliases'].append('RR-01')
            f['local_aliases']=[{'directory':d,'id':'RR-01'}]
            f['evidence_sources'].append(evidence_source(d,pointer,raw))
            f['source_locators'].extend(raw['source'])
            f['raw_records'].append({'path':d+'/FINDINGS.json','pointer':pointer,'record_kind':'exact_parsed_primary_JSON','record':raw})
            f['independent_reviews'].append(review(d,local_id))
            f['review_constraints'].append('RR-01 deepens ST-02: 32 attempts produce 192 invocation loads and 336411374 bytes returned by Path.read_bytes; not physical disk I/O/SLA. Reviewer independently confirmed 2/3-attempt multiplicity, not full cost wave. Memo is a discriminator, not concurrent/mutation-safe repair.')
            f['accepted_summary']+=' CP13 RR-01 adds actual run-history composition: three reads per invocation, full retained history; request-local memo lowers 192→64 loads in immutable fixture only.'
            f['synthesis_22_change']='deepened_same_family_RR-01_merged'
            continue
        fid=('policy-assembly::'+local_id if d=='next_policy_assembly' else 'custody::'+local_id if d=='next_remaining_custody' else local_id)
        summary,limits,direction,acceptance,package,*kind=CARDS[fid]
        sources=raw.get('source',raw.get('sources',raw.get('locations',raw.get('location',raw.get('source_ranges',[])))))
        if isinstance(sources,str): sources=[s.strip() for s in sources.split(';')]
        f={'id':fid,'mechanism_key':fid,'aliases':[fid],'local_aliases':[{'directory':d,'id':local_id}],
          'kind':kind[0] if kind else 'finding','priority':raw.get('priority',raw.get('severity','not_separately_rated')),
          'priority_basis':'Primary priority retained; review qualifications control interpretation. Not CVSS, incident probability or proof of exploitation.',
          'title':raw['title'],'accepted_summary':summary,'severity_original':raw.get('severity',raw.get('priority','not_separately_rated')),
          'confidence':raw.get('confidence','see bounded author/review'),'decision_status':'proposed; no fixes or risk acceptance',
          'evidence_level':'source_traced + bounded execution; exact independent mode in review',
          'native_supported_profile':'UNRUN','installed_integration':'UNRUN','deployed_observation':'UNRUN',
          'production_incident_established':False,'authority_bypass_established':False,
          'owner':raw.get('owner','existing source owner named by primary report'),
          'direction':direction,'acceptance':acceptance,'limitations':limits,'source_locators':sources,
          'evidence_sources':[evidence_source(d,pointer,raw)],
          'raw_records':[{'path':d+'/FINDINGS.json','pointer':pointer,'record_kind':'exact_parsed_primary_JSON','record':raw}],
          'independent_reviews':[review(d,local_id)],'review_constraints':[limits],
          'prior_relations':[],'remediation_package':package,'synthesis_22_change':'new_to_cumulative_not_new_global_SYS_family'}
        if fid.startswith('REL-'): f['evidence_level']='source_traced + actual local standalone CLI/Git or golden JSON; hosted/scanner substitution limits in review'
        if fid=='DP-01': f['evidence_level']='author bounded persisted consumer; reviewer independent arithmetic/source only, no product rerun'
        if fid=='custody::RC-01':
            f['evidence_sources'][0]['supplementary_deciding_bindings']=[
                binding('next_remaining_custody/results.json','/cases'),
                binding('next_remaining_custody/fresh.stdout.json'),
                binding('next_review_custody_history/independent_results.json','/rows'),
                binding('next_review_custody_history/fresh.stdout.json'),
                binding('next_review_custody_history/archive_reopen.stdout.json')]
        findings.append(f)

assert len({x['id'] for x in findings})==len(findings)
assert set(CARDS)=={x['id'] for x in findings if x['synthesis_22_change']=='new_to_cumulative_not_new_global_SYS_family'}

# Source path normalization is a byte binding, not new semantic review.
source_manifest=read(BASE/'baseline/snapshot_files_sha256.json')
SOURCE_EXPECTED={x['path']:x for x in source_manifest}
source_results=[]
for x in source_manifest:
    p=BASE/'source'/x['path']
    actual=digest(p) if p.is_file() else None
    if actual != x['sha256']:
        source_results.append({'path':x['path'],'expected':x['sha256'],'actual':actual})
write('SOURCE_VALIDATION.json',{'source_commit':COMMIT,'source_tree':TREE,'status':'PASS' if not source_results else 'FAIL','full_baseline_file_count':len(source_manifest),'all_baseline_bytes_match':not source_results,'mismatches':source_results,'unexpected_untracked_files_checked':False,'remote_HEAD_rechecked':False,'semantic_coverage_claim':False,'baseline_manifest':binding('baseline/snapshot_files_sha256.json'),'note':'Rehash of all baseline-listed files, not a scan/execution or remote freshness assertion.'})

unresolved_locators=[]
for f in findings:
    refs=copy.deepcopy(f.get('normalized_source_references',[]))
    source_locator_parts=[part.strip() for loc in f.get('source_locators',[]) if isinstance(loc,str) for part in loc.split(';')]
    for original in source_locator_parts:
            if any(r.get('original')==original for r in refs):continue
            if not isinstance(original,str): continue
            m=re.match(r'^([^:]+)(?::([\d,\-– ]+))?',original)
            if not m: continue
            rawpath=m.group(1).strip().removeprefix('source/')
            candidates=[rawpath,'policy-engine/'+rawpath,'policy-engine/src/polisyos/'+rawpath]
            selected=next((p for p in candidates if p in SOURCE_EXPECTED),None)
            if selected is None:
                suffix_matches=[p for p in SOURCE_EXPECTED if p.endswith('/'+rawpath)]
                if len(suffix_matches)==1:selected=suffix_matches[0]
            if selected:
                refs.append({'original':original,'path':selected,'line_spans':m.group(2),'sha256':SOURCE_EXPECTED[selected]['sha256'],'precision':'file_bytes_verified_locator_inherited_not_semantically_rereviewed'})
            else: unresolved_locators.append({'finding':f['id'],'locator':original})
    for ref in refs:
        if ref.get('path') is None:
            unresolved_locators.append({'finding':f['id'],'locator':ref.get('original'),'classification':'inherited_thematic_reference_not_a_file_binding'})
    f['normalized_source_references']=refs

registry=copy.deepcopy(OLD_REGISTRY)
registry.update({'schema_version':'policyos-cumulative-synthesis-v2','generated_at_utc':NOW,'checkpoint_scope':list(range(1,23)),
 'audit_status':'PARTIAL','source_commit':COMMIT,'source_tree':TREE,'audit_complete':False,'fixes_implemented':False,
 'new_SYS_family_count_assigned':0,'global_defect_count_recomputed':False,'findings':findings,
 'native_note':'No product probe/test rerun in this synthesis. Full baseline byte rehash is integrity only; Python3.12 compatibility, Pydantic2.13.4 and Node24 do not qualify Python3.14/locked Pydantic<2.13/Node22.'})
groups=collections.defaultdict(list)
for f in findings: groups[f['mechanism_key']].append(f['id'])
registry['mechanism_groups']=[{'mechanism_key':k,'member_ids':v} for k,v in sorted(groups.items())]
registry['count_metadata']={'registry_entries':len(findings),'mechanism_groups':len(groups),'inherited_entries':81,'new_cumulative_cards':len(CARDS),'merged_existing_family_witnesses':['RR-01 -> ST-02'],'kinds':dict(collections.Counter(f['kind'] for f in findings)),'primary_and_review_directories':len(DIR_CP),'counts_are_not_incidents_or_security_defects':True,'observations_and_safeguards_counted_separately':True}
write('REGISTRY.json',registry);write('FINDINGS.json',registry)

# Observations are explicitly excluded from remediation finding counts.
observations=[]
for d in ['next_method_execution','next_governance_handoff','next_execution_owner']:
    raw=read(BASE/d/'FINDINGS.json')
    for i,x in enumerate(raw['observations']):
        observations.append({'id':x['id'],'checkpoint':DIR_CP[d],'classification':x.get('classification',x.get('kind',x.get('type','bounded_observation'))),'raw_record':x,'record_binding':binding(d+'/FINDINGS.json',f'/observations/{i}'),'report':d+'/REPORT_RU.md','new_confirmed_finding':False})
raw=read(BASE/'next_decision_path/FINDINGS.json')[1]
observations.append({'id':'DP-O1','checkpoint':16,'classification':'scoped_observation','raw_record':raw,'record_binding':binding('next_decision_path/FINDINGS.json','/1'),'report':'next_decision_path/REPORT_RU.md','new_confirmed_finding':False})
observations.append({'id':'TCUST-POS','checkpoint':16,'classification':'bounded_positive_custody','raw_record':read(BASE/'next_tenant_custody/FINDINGS.json'),'record_binding':binding('next_tenant_custody/FINDINGS.json'),'report':'next_tenant_custody/REPORT_RU.md','new_confirmed_finding':False})
write('OBSERVATIONS.json',{'audit_status':'PARTIAL','new_confirmed_defects_from_these_observations':0,'items':observations,'qualification':'ME-O1/GH-O1/DP-O1 are bounded consumer observations, not publication bypass or newly counted defects. EO/tenant results are positive selected paths, not repairs to BUD-01/RR-03.'})

safe=copy.deepcopy(read(OLD/'SAFEGUARDS.json'))
SAFE_NEW=[
('G11','Matching contract and schema admission guards','Matching invalid schema, same-version and unapproved breaking changes refuse; noncollision and distinct versions retain both IDs.','next_review_synthesis','Missing-contract pass is a candidate/protected-boundary policy question; not full bootstrap.'),
('G12','Strict method binding and checkpoint refusals','Typed selector detects actual callable mismatch; signature drift invalidates cache. Foreign checkpoint scope, corrupt oldest invocation and missing base refuse.','next_review_method_replay','Does not repair lower lazy registry/cache codec or state/base pairing; shared loader and no full worker.'),
('G13','Actual numerical DiD and source replay','Standard/Staggered DiD match independent synthetic-panel numerical contrasts; coherent stored-report tampering refuses. Failure envelope drives uncertainty=1 and ConfidencePass blocker.','next_review_guard_method','Candidate scientific computations, not true empirical identification or protected authority.'),
('G14','Adapter resource and UI boundary controls','Handles release, cancellation/403 refuse; identity layout gate/scoped envelope exist. Global incidents include network status0,403/5xx and401 redirect.','next_review_adapters_ui','No native React/browser or real provider/batch proof; local history ambiguity remains.'),
('G15','Persisted tenant/cell/profile custody','Full ControlWorker, FileSystemCAS and SQLite preserve live-lease/creation scope across fresh reopen; foreign tenant, full cell, selected profile and input edge refuse.','next_review_decision_custody','Reviewer did not rerun product; raw temporary tenant fixtures were deleted. No full authenticated Runtime/HTTP or exploit pass.'),
('G16','Assembly linker/conflict/evaluator controls','Duplicate FQN, amount bounds, kind/binding, unsupported fidelity, missing kernel/slot and nonfinite state refuse; Decimal pass/violation and EUR/USD refusal distinguish.','next_review_policy_assembly','Unknown parameter warns rather than refuses; identity capture not a proved blocking gate; no full execution graph.'),
('G17','Governance availability is not authority','Nine vectors roundtrip but source-bound search score stays not_established; EvaluationSafety rejects foreign verified DTO; legal owner refuses required authority; v1 reports do not become current by CAS roundtrip.','next_review_governance_execution','Whole current source→science→normative→legal→governance positive chain not executed.'),
('G18','Cached physical settlement survives waiter loss','One physical call yields one charge; takeover preserves old-attempt spending while blocking stale publication/reuse; lost acknowledgement reconciles by readback. Unknown provider/physical-owner cancellation blocks admission.','next_review_governance_execution','Positive sibling cached path, not BUD-01 direct-client fix. Manual guard wiring; no public cancel, sync timeout/loop closure, disk crash or external physical-stop proof.'),
('G19','Exact custody current-positive and tamper refusals','Current receipts pass direct/service; wrong query, poisoned append, corrupt signature, missing retained entry, bad selector/predecessor/reconciliation/role/revoked issuer refuse.','next_review_custody_history','Synthetic institution/issuer; historical service mismatch survives; no holder/retention positive or public authority.'),
('G20','Scientific replay and nonproduction qualification','Fresh continuous/forecast reads and nine valid-hash perturbation refusals retained; wrong population refuses. Continuous validation remains blocked/unverified and forecast projection explicitly contract-only.','next_review_scientific_integrity','Local horizon may still turn GREEN under SI-02; no whole-product scientific safety claim.'),
('G21','Calibration Gaussian guards and trust refusal','Existing helper preserves representable small intervals or refuses absorption; independent linear/constant-map controls and 28 fresh candidate envelope reads retain gate=false; heuristic promotion refuses.','next_review_data_calibration','Helper needs carrier extension; no arbitrary precision or complete forgery/authority safety claim.'),
('G22','Existing data-service test bodies and isolated fixture','Real isolated-schema fixture and meaningful concurrency/readback tests exist; required-input removal refuses.','next_review_data_calibration','Source-defined tests and bounded setup controls are not actual collection, PostgreSQL execution or hosted CI PASS.'),
('G23','Release fail-closed controls','Missing/empty snapshot/version mismatch fail; 547 valid fragments render. Event ref/SHA checkout pinning exists; real upstream Critical golden and nonzero modeled scanner block.','next_review_release','No actual scanner/hosted release. Unknown severity remains explicit rank0 policy; invalid report robustness is not scanner bypass proof.'),
]
for id,title,observed,rd,limits in SAFE_NEW:
    safe.append({'id':id,'title':title,'observed':observed,'evidence':[rd+'/REPORT_RU.md'],'limits':limits,'binding':binding(rd+'/REPORT_RU.md')})
write('SAFEGUARDS.json',safe)

namespace={'source_records_renamed':False,'global_defect_count_recomputed':False,'aliases':[
 {'directory':'next_publication_authority','local_id':'PA-01','canonical_id':'publication-authority::PA-01'},
 {'directory':'next_policy_assembly','local_id':'PA-01','canonical_id':'policy-assembly::PA-01'},
 {'directory':'next_policy_assembly','local_id':'PA-02','canonical_id':'policy-assembly::PA-02'},
 {'directory':'next_research_chain','local_id':'RC-01','canonical_id':'scholar::RC-01'},
 {'directory':'next_remaining_custody','local_id':'RC-01','canonical_id':'custody::RC-01'}],
 'merge':[{'directory':'next_run_replay','local_id':'RR-01','canonical_id':'ST-02','why':'Run-history composition deepens same storage ownership read-cost family; not an independent defect.'}],
 'kept_distinct':[
  'MA-01 stale semantic cache; MA-02 inconsistent lazy supplier; policy-assembly::PA-01 consistent eager registry projection loses executable pin. Different repair seams.',
  'CR-01 Gaussian serialization/representation, CR-02 scalar API tolerance/support, SI-01 ENCE denominator, SI-02 coverage-statistic meaning are distinct owners/contracts.',
  'DP-01 utility-weight arithmetic/contract question differs from GH-O1 stale-result join observation; latter not a new finding.',
  'UI-01 Clerk conversation generation differs from FE-01 auth transport generation; neither proves account leakage.',
  'RR-02 keeps state/base pairing and manifest/depth obligations in one local checkpoint contract, with separate acceptance tests.',
  'REL-01 missing snapshot and schema-invalid fragment are one provisioning/producer-consumer repair programme; no extra high family.',
  'REL-02 adjacent shell input marker and REL-03 fix-summary/Unknown notes are not new high findings.'
 ]}
write('FINDING_NAMESPACES.json',namespace)
write('PRIOR_CROSSWALK.json',{'historical_sys_aud_crosswalk':binding('next_cumulative_synthesis/PRIOR_CROSSWALK.json'),'historical_crosswalk_preserved':read(OLD/'PRIOR_CROSSWALK.json'),'current_aliases':namespace,'new_SYS_families_assigned':0})

road=copy.deepcopy(read(OLD/'ROADMAP.json'))
for x in road['packages']:
    x['targets']=[RENAME.get(z,z) for z in x['targets']]
additional=[
 ('R10','Согласовать source contracts и REST continuation',['R0'], 'Existing contract, version и retry owners; candidate admission отдельно от protected acquisition.', 'Actual two-source pool→fetch→CAS/replay→fresh refresh; preserve cancellation, matching contract and resource release.'),
 ('R11','Закрепить executable и checkpoint identity',['R0'], 'Versioned semantic codec, exact executable selection, state/base/lineage и scoped factory; не создавать новый registry/CAS.', 'Fresh persistent consumer после drift/restore; full strict execution positives и negative exact-identity controls.'),
 ('R12','Исправить численные и нормативные контракты',['R0','R3'], 'Разделить scale/tolerance/statistics/support semantics, определить weight contract и сохранить typed unavailable/candidate authority.', 'Independent numerical oracles, scale covariance, unit/degenerate cases, persistence/replay и complete protected consumer отдельно.'),
 ('R13','Замкнуть release provenance и report schema',['R0'], 'Immutable generated release snapshot → validated fragments → exact tag/source SHA → SBOM/report/shipped artifact.', 'Fresh hosted jobs with immutable byte transfer and actual pinned scanner; no release from local fixture success.'),
]
for id,title,deps,direction,acceptance in additional:
    road['packages'].append({'id':id,'title':title,'dependencies':deps,'targets':[],'direction':direction,'acceptance':acceptance})
for p in road['packages']:
    p['targets']=[f['id'] for f in findings if f['remediation_package']==p['id']]
road.update({'status':'PROPOSED_NOT_IMPLEMENTED','audit_status':'PARTIAL','priority_order':['R0','R13','R5','R1','R2','R11','R3','R4','R12','R10','R8','R6','R7','R9'],
 'ordering_note':'R0 enables integrated acceptance. Before any intended release R13/R5 become prerequisites. R1/R2 durable correctness and preserved settlement remain early. Independent source fixes can proceed in parallel; dependencies refer to integrated acceptance, not permission to start.',
 'not_estimates':['No dates, cost, incident probability, CVSS or production SLA assigned.','Positive EO cached controls do not close BUD-01.','REL high is operational/privileged-integrity priority, not established exploitation.'],
 'inherited_subpriorities':'SYS-03 local lock lifetime and SYS-04 independence admission retain prior P1 subpriorities; SYS-09 naming and SYS-10 canary/shipped-object identity are not closed by adjacent controls.'})
write('ROADMAP.json',road)

gaps=copy.deepcopy(read(BASE/'next_coverage_16/GAPS.json'))
updates={
 'S01':'CP18 adds full ObjectiveStack/vector and individual governance joins, preserving not_established scores/legal/safety refusals. GH-O1/ME-O1/DP-O1 remain bounded observations; whole current positive chain still OPEN.',
 'S02':'CP18 cached physical owner now has five author and three additional reviewer cases including readback/unknown. BUD-01 direct path, public cancel, sync timeout/loop closure, genuine N5 seal/revoke/PA2 remain OPEN.',
 'S03':'CP19 exact custody current/historical join has independent persisted evidence; historical mismatch is custody::RC-01. Actual appointed signed public population and current public revalidation remain OPEN.',
 'S05':'CP17 consistent eager synthetic resources prove plan identity drift, not genuinely admitted zero-code end-to-end growth. Native discovery→execute→protected consumer remains OPEN.',
 'S07':'CP20–21 continuous calibration, coverage statistics and Gaussian adapter/exported API have bounded producer/consumer/numerical coverage. Do not label those inspected portions indexed-only. Broader BERL/corpus/schemas/DDM/world/model promotion and monitoring remain OPEN.',
 'S08':'CP21 supplies bounded Gaussian reuse direction with carrier/precision caveats. Native DTO/import/optional-provider/parity remaining work unchanged.',
 'S09':'CP21 proves gaps in mandatory PostgreSQL test provisioning, not SQL concurrency itself. Workload denominators, PostgreSQL/planners/migrations remain OPEN.',
 'S11':'CP22 release workflow, local generated corpus, tag/source mismatch and evaluator schema are bounded qualified. Hosted release, actual scanner/SBOM/attestation/shipped object still OPEN; REL-01/02/03 need remediation.',
 'N03':'CP21–22 checked-in test/release wiring deepened; actual OPA/hosted workflows remain UNRUN.',
 'P04':'CP22 exact source-tag and generated report contracts checked locally. Real release protections, signatures, attestations, migrations and publish absent.',
}
for category in ['source_level','native','production']:
    for item in gaps[category]:
        if item['id']=='S03':
            item['already_established']=item['already_established'].replace('PA-01','publication-authority::PA-01')
        item['status_at_checkpoint22']='OPEN_WITH_BOUNDED_PROGRESS' if item['id'] in updates else 'OPEN_RETAINED'
        if item['id'] in updates:item['checkpoint17_22_delta']=updates[item['id']]
gaps.update({'audit_status':'PARTIAL','audit_complete':False,'source':'next_coverage_16/GAPS.json','checkpoint_scope':[1,22],
 'historical_work_packages':binding('next_coverage_16/WORK_PACKAGES.json'),
 'work_package_namespace_note':'W01–W09 in next_work refer to research packages in coverage16/WORK_PACKAGES.json; R0–R13 refer to remediation packages in this synthesis ROADMAP.json.',
 'synthesis_completion_delta':{'criterion':'C05','status':'CURRENT_REGISTRY_UPDATED_THROUGH22','limit':'This deliverable completes the registry update, not overall audit/release. No fresh independent review of all 112 normalized cards.'},
 'next_deciding_work':['Native pinned environment/test manifest and real OPA/Node22/installed origins.','Current whole source→science→objective→legal→governance positive chain; stale selector falsifier.','Genuine publication/custody holder-retention/N5 issuance/revoke and authenticated cancellation/terminal flow.','Actual source adapter batch and two admitted zero-code resources through persisted served consumers.','Actual PostgreSQL and release scanner/hosted immutable object qualification.'],
 'completed_by_synthesis_only':['Checkpoint01–22 registry/navigation and namespace resolution','RR-01 deduplication into ST-02','Byte/pointer validation of selected cumulative inputs and full baseline-listed source'],
 'coverage_count_warning':'No percent complete; source file/hash counts are not semantic coverage or test execution counts.'})
write('OPEN_WORK.json',gaps)
write('COMPLETION_CRITERIA.json',{'historical_criteria':read(BASE/'next_coverage_16/COMPLETION_CRITERIA.json'),'current_delta':gaps['synthesis_completion_delta'],'audit_complete':False,'release_qualified':False})

reuse_sources=['next_cumulative_synthesis/REUSE_DECISIONS.json']+[d+'/REUSE_DECISIONS.json' for dirs in NEW_DIRS.values() for d in dirs if (BASE/d/'REUSE_DECISIONS.json').is_file()]
write('REUSE_DECISIONS.json',{'status':'PROPOSED_NOT_IMPLEMENTED','items':[{'binding':binding(p),'decisions':read(BASE/p)} for p in reuse_sources],
 'direction':'Prefer existing semantic codec, qualified resolver, scoped factory, retry/version owner, Gaussian construction and release pipeline. No universal new registry/CAS/framework; preserve candidate/authority, numerical/carrier and generation boundaries.'})
write('REJECTED_SIGNALS.json',{'historical':read(OLD/'REJECTED_SIGNALS.json'),'new_exclusions':[
 'No new security exploit or production incident established by checkpoint12–22.',
 'No count for ME-O1/GH-O1/DP-O1 or positive EO/tenant outcomes as new defects.',
 'No physical disk I/O/SLA claim from RR-01 Path.read_bytes counters.',
 'No universal docs/CI bypass from selected GE subgate controls.',
 'No whole-app silent error from UI-02; global network/API incidents exist.',
 'No proof DP-01 zero-term additions preserve total declared weights.',
 'No full free-grow/scientific/authority acceptance from successful registry/compile/CAS.',
 'No fixed finite/infinite policy imposed for ENCE zero denominator.',
 'No empirical false-positive rate from constructive SI-02 sequence or equality between likelihood conditioning conventions.',
 'No native pytest count from source test bodies or direct invocations.',
 'No arbitrary precision/carrier-complete repair attributed to existing Gaussian helper.',
 'No syntax-invalid TOML claim for REL-01 schema-invalid fragment.',
 'No latest-main checkout or low-privilege/approval-bypass assertion for REL-02.',
 'No actual scanner bypass from malformed JSON when real Grype success output reachability unproven.',
 'No declaration that full source byte match equals full semantic review.'
]})

nav=[]
historical_selected_ids={RENAME.get(x['id'],x['id']) for x in read(BASE/'next_review_synthesis/SELECTED_CARDS.json')}
observation_reviews={'next_method_execution':'next_review_guard_method','next_governance_handoff':'next_review_governance_execution','next_execution_owner':'next_review_governance_execution','next_decision_path':'next_review_decision_custody','next_tenant_custody':'next_review_decision_custody'}
for d,cp in sorted(DIR_CP.items(),key=lambda z:(z[1],z[0])):
    reports=[str(p.relative_to(BASE)) for p in sorted((BASE/d).glob('*RU.md')) if p.name in ['REPORT_RU.md','REVIEW_RU.md']]
    nav.append({'checkpoint':cp,'directory':d,'role':'independent_review' if d.startswith('next_review_') else 'coverage_ledger' if 'coverage' in d else 'primary',
      'reports':[binding(p) for p in reports],
      'registry_ids':[f['id'] for f in findings if any(s['directory']==d for s in f['evidence_sources']) or any(r['report'].startswith(d+'/') for r in f.get('independent_reviews',[])) or (d=='next_review_synthesis' and f['id'] in historical_selected_ids)],
      'observation_ids':[o['id'] for o in observations if o['report'].startswith(d+'/') or observation_reviews.get(o['report'].split('/')[0])==d]})
selected_review=({'report':binding('next_review_cumulative_22/REPORT_RU.md'),'decisions':binding('next_review_cumulative_22/REVIEW_DECISIONS.json'),'scope':'16 selected current cards plus integrity/count/namespace/navigation checks; not all112 semantic review; pre-correction bytes retained','reviewed_snapshot_map':'reviewed_snapshot/SNAPSHOT_MAP.json'} if (SYN_REVIEW/'REVIEW_DECISIONS.json').is_file() else None)
write('NAVIGATION.json',{'checkpoint_scope':[1,22],'audit_status':'PARTIAL','path_base':'policyos_deep_audit','entries':nav,
 'checkpoint01':OLD_NAV.get('checkpoint01'),'historical_synthesis':binding('next_cumulative_synthesis/REPORT_RU.md'),
 'reading_order':['README_RU.md','REPORT_RU.md','ROADMAP.json','REGISTRY.json','SAFEGUARDS.json','OBSERVATIONS.json','OPEN_WORK.json','VALIDATION.json'],
 'namespace_map':'FINDING_NAMESPACES.json','input_snapshot':'INPUT_MANIFEST.json','selected_synthesis_review':selected_review})
write('REVIEW_APPLICATION.json',{'audit_status':'PARTIAL','all_cards_independently_semantically_reviewed':False,'selected_synthesis_review':selected_review,
 'historical_selected_review':binding('next_cumulative_synthesis/REVIEW_APPLICATION.json'),'historical_review_scope':'16 selected cards through11; not all81 or current112',
 'policy':'Primary records and all older reports remain unchanged. Current normalized summaries apply each checkpoint review limitation; raw primary records embedded exact.',
 'new_card_reviews':[{'id':f['id'],'review':f['independent_reviews']} for f in findings if f['synthesis_22_change']=='new_to_cumulative_not_new_global_SYS_family'],
 'merged_family':'RR-01 under ST-02','identity_map':'FINDING_NAMESPACES.json',
 'current_view_corrections':['Qualify publication-authority::PA-01 in OPEN_WORK S03.','Add RR-01 source references to ST-02 without changing raw records.','Add custody::RC-01 deciding results/fresh/archive read bindings.','Link inherited W work packages and distinguish them from R remediation packages.','Populate reverse review-to-finding/observation navigation.'],
 'finding_priorities_or_scopes_changed':False})

# Build a readable report, not merely a JSON dump.
lines=[
 '# PolicyOS: единый промежуточный реестр checkpoint01–22',
 '',
 '**PARTIAL. Аудит продолжается. Исправления не внедрены. Это не native/release qualification, не завершение E02 и не разрешение публикации.**',
 '',
 f'База: `{COMMIT}`, tree `{TREE}`. Remote HEAD заново не проверялся. Сохранены исходный checkout, все первичные отчёты/evidence и прежняя `next_cumulative_synthesis` (01–11). Новая сводка не изменяет исторические IDs внутри raw records.',
 '',
 '## 1. Итог среза',
 '',
 f'- **{len(findings)} карточек / {len(groups)} групп механизмов**: 81 прежняя карточка + {len(CARDS)} новых для cumulative registry. RR-01 углубляет ST-02 и второй раз не считается. Это смесь defects, qualification gaps, risks, boundary/contract decisions и reuse, не число инцидентов или подтверждённых security vulnerabilities.',
 '- Положительные защиты собраны отдельно в [SAFEGUARDS.json](SAFEGUARDS.json). ME-O1, DP-O1, GH-O1 и EO/tenant results отделены от findings в [OBSERVATIONS.json](OBSERVATIONS.json). Никакой положительный sibling path не объявлен исправлением старого дефекта.',
 '- Review имеет приоритет над широкой author prose: retained source/raw records сохранены, accepted summary и ограничения читаются вместе. Новый общий реестр прошёл [выборочную независимую проверку](../next_review_cumulative_22/REPORT_RU.md) 16 карточек плюс integrity/count/navigation. Это не семантическая переаттестация всех 112 карточек. Пять поправок уточняют namespace и ссылки, не scope/severity; pre-correction bytes сохранены.',
 '',
 '## 2. Что делать сначала',
 '',
 '1. **Квалифицировать среду и обязательность проверок (R0).** Python3.14/locked dependencies, actual OPA, Node22/browser, installed origins; обязательные PostgreSQL/input lanes. Hash PASS и Python3.12/Node24 controls этого не заменяют.',
 '2. **Перед выпуском закрыть release и policy prerequisites (R13/R5).** Immutable generated snapshot и schema-valid fragments; exact tag/source/shipped-object identity; report/SBOM binding; canonical/rendered/served policy parity. REL high означает operational/privileged integrity priority, не доказанный exploit.',
 '3. **Durable correctness раньше оптимизации (R1/R2/R11).** Exact selected finalization и per-target invalidation ack; physical settlement отдельно от logical cancel; scope-preserving checkpoint restore, state/base/lineage и executable pin. Не освобождать reservations ради timeout green.',
 '4. **Смысл и численные контракты (R3/R4/R12).** Component scope/mode, declared dependence/composition, normative weights, ENCE degeneracy, correct CC statistic, Gaussian precision/support. Не превращать candidate GREEN/approve в authority.',
 '5. **Actual consumers и затем growth/reuse (R10/R8/R6/R7/R9).** REST batch/refresh, browser generation, admitted zero-code path, workload denominators, owner-preserving reuse. Existing helper не заменяет carrier/semantic acceptance.',
 '',
 'Зависимости roadmap относятся к integrated acceptance; независимые локальные исправления могут идти параллельно. Даты/стоимость/CVSS не назначены. Унаследованные P1 subpriorities SYS-03/04 и незакрытые SYS-09/10 сохранены.',
 '',
 '## 3. Уникальные IDs и дедупликация',
 '',
 '- **publication-authority::PA-01**: прежний fail-closed private-draft codec. **policy-assembly::PA-01/02**: executable identity и typed threshold lowering. Это разные owners и acceptance.',
 '- **scholar::RC-01**: declared independence/effective support. **custody::RC-01**: exact historical receipt versus service reconstruction. Raw RC-01 в первичных файлах не переименованы.',
 '- RR-01 включён в ST-02. MA cache/lazy mismatch не сливается с consistent eager policy assembly. CR/SI сохраняют разные numerical contracts. DP-01 — один scoped composition issue; GH-O1 остаётся observation.',
 '- [FINDING_NAMESPACES.json](FINDING_NAMESPACES.json) и [PRIOR_CROSSWALK.json](PRIOR_CROSSWALK.json) сохраняют старые SYS/AUD связи без нового глобального defect count.',
 '',
 '## 4. Доказательства и ограничения',
 '',
 'Indexed/source-traced, bounded probe, real persisted owners с compatibility loader, native targeted, installed integration и deployed observations — разные уровни. Synthesis не запускал product probes, tests, benchmarks, installs или исправления. Все source hashes — byte provenance, не semantic coverage. Python3.12/Pydantic2.13.4 и Node24 не равны supported Python3.14/Pydantic<2.13/Node22.',
 '',
 'Особенно важно: CP16 review не повторял product, tenant temporary SQLite/CAS не сохранены; CP13 review не повторял дорогую 32-attempt волну; CP12 SA-03 — replay author harness; CP22 scanner заменён в caller controls, upstream golden и model проверены отдельно. Native/authenticated/full-engine/production/empirical authority ограничения остаются в каждой карточке.',
 '',
 '## 5. Полный реестр по remediation packages',
 ''
]
for package in road['packages']:
    lines += [f"### {package['id']}. {package['title']}", '',package['direction'],'',f"**Acceptance:** {package['acceptance']}",'']
    for f in findings:
        if f['remediation_package']!=package['id']:continue
        ev=f['evidence_sources'][0];rv=f.get('independent_reviews',[])
        limits=f.get('limitations','See primary/review')
        if isinstance(limits,list): limits=' '.join(str(z) for z in limits)
        lines += [f"- **{f['id']} [{f['priority']}; {f['kind']}]** — {f['title']}",f"  {f['accepted_summary']}",f"  Ограничение: {limits}",f"  Источник: [CP{ev['checkpoint']:02d}, {ev['directory']}](../{ev['report']})." ]
        if rv: lines.append('  Review: '+', '.join(f"[{r['report'].split('/')[0]}](../{r['report']})" for r in rv)+'.')
        lines.append('')
lines += ['## 6. Положительные защиты, которые нельзя потерять','']
for s in safe:
    lines += [f"- **{s['id']}. {s['title']}.** {s['observed']} Граница: {s['limits']}"]
lines += ['', '## 7. Что остаётся в аудите', '',
 'Подробная карта [OPEN_WORK.json](OPEN_WORK.json) сохраняет все 11 source-level, 5 native и 5 production gaps из coverage16 и добавляет прогресс checkpoint17–22. Наличие карточек не закрывает исходные цепочки. Имена W01–W09 относятся к [research work packages](../next_coverage_16/WORK_PACKAGES.json); R0–R13 — к remediation roadmap этой сводки.', '',
 '- Whole current source→method→ObjectiveStack→legal→governance positive chain; stale selector falsifier и decision contract.',
 '- Appointed signed public claim population/current reader, custody holder/retention positives, genuine N5 issuance→revoke→PA2 terminal commit.',
 '- Full authenticated Runtime/cancel/resume, actual direct-client repeated cancellation and sync timeout/loop shutdown.',
 '- Actual two-source REST batch/CAS/refresh и genuinely admitted zero-code resources до served consumer.',
 '- Native pinned profile, real PostgreSQL, OPA, browser/Node22, installed distributions, actual Grype/SBOM и fresh hosted immutable release.',
 '- Broader unqualified roots/model promotion/monitoring, real workload denominators/concurrency/migrations. Проведённые calibration slices больше не indexed-only, но весь scientific domain не квалифицирован.', '',
 '## 8. Навигация и целостность', '',
 '- [REGISTRY.json](REGISTRY.json) и [FINDINGS.json](FINDINGS.json) идентичны: accepted summaries, exact raw records/pointers, review restrictions, owner/repair/acceptance.',
 '- [NAVIGATION.json](NAVIGATION.json): checkpoint→thematic/review→IDs; [ROADMAP.json](ROADMAP.json): future changes/dependencies; [REUSE_DECISIONS.json](REUSE_DECISIONS.json): bounded reuse.',
 '- [INPUT_MANIFEST.json](INPUT_MANIFEST.json): замороженные входы; [REFERENCE_VALIDATION.json](REFERENCE_VALIDATION.json): pointers/hashes; [SOURCE_VALIDATION.json](SOURCE_VALIDATION.json): все baseline-listed source bytes; [VALIDATION.json](VALIDATION.json): synthesis integrity only.',
 '- [REVIEW_APPLICATION.json](REVIEW_APPLICATION.json): что действительно reviewed и что лишь inherited; [REJECTED_SIGNALS.json](REJECTED_SIGNALS.json): исключённые расширения выводов.',
 '- [Прежняя сводка 01–11](../next_cumulative_synthesis/REPORT_RU.md) остаётся исторической и не переписана. Для упаковки нужны sibling evidence directories из INPUT_MANIFEST; одни эти ссылки не делают архив self-contained.', '',
 '**Статус остаётся PARTIAL. Сводка завершена как навигационный deliverable, но системный аудит, исправления и приёмка продукта не завершены.**','']
(OUT/'REPORT_RU.md').write_text('\n'.join(lines))
(OUT/'README_RU.md').write_text(f'''# PolicyOS: сводка checkpoint01–22\n\n**PARTIAL. Аудит продолжается; продукт не исправлен и не допущен к выпуску.**\n\nНачните с [единого отчёта](REPORT_RU.md): приоритеты, все {len(findings)} карточек, положительные защиты и оставшаяся работа.\n\n- [Roadmap](ROADMAP.json) — порядок будущих исправлений и acceptance.\n- [Машинный реестр](REGISTRY.json) — evidence/pointers/review ограничения.\n- [Checkpoint-навигация](NAVIGATION.json), [namespace PA/RC](FINDING_NAMESPACES.json), [остаток аудита](OPEN_WORK.json).\n- [Проверка целостности](VALIDATION.json), [source bytes](SOURCE_VALIDATION.json), [контрольные суммы](SHA256SUMS.txt).\n\n81 прежняя карточка + {len(CARDS)} новых для cumulative registry = {len(findings)} записей / {len(groups)} групп; это не число инцидентов или security vulnerabilities. RR-01 входит в ST-02. Observations и safeguards считаются отдельно. База `{COMMIT}`.\n\nСтарая [сводка 01–11](../next_cumulative_synthesis/REPORT_RU.md), source и все прежние evidence сохранены. Эта папка ссылается на sibling evidence: для отдельной доставки требуется их packaging/reference closure, а не только копирование этой папки.\n''')

# Verify exact primary selections, review selections, source hashes and all declared links.
checks=[];errors=[];text_labels=[]

def resolve_deciding_refs(f,es):
    raw_refs=es.get('deciding_evidence_original',[])
    if isinstance(raw_refs,str):raw_refs=[raw_refs]
    if not isinstance(raw_refs,list):return
    d=es['directory']
    for val in raw_refs:
        if not isinstance(val,str):continue
        # Preserve raw author syntax, normalize only unambiguous filename/pointer forms.
        for value in val.split(';'):
            value=value.strip()
            m=re.match(r'^([A-Za-z0-9_./-]+\.(?:jsonl|geojson|json))(.*)$',value)
            if not m:
                if value:text_labels.append({'finding':f['id'],'directory':d,'label':value,'resolution':'scenario_or_prose_label_not_an_RFC6901_pointer'})
                continue
            filename,suffix=m.groups();p=BASE/d/filename
            if not p.is_file():
                errors.append({'finding':f['id'],'error':'missing_deciding_file','path':d+'/'+filename});continue
            normalized=None
            if suffix.startswith('#/'):normalized=suffix[1:]
            elif suffix.startswith('/'):normalized=suffix
            elif suffix.startswith(':') and filename.endswith('.json'):normalized='/'+suffix[1:]
            if normalized is not None:
                try:bb=binding(d+'/'+filename,normalized)
                except (KeyError,ValueError,TypeError,IndexError,AssertionError) as e:
                    errors.append({'finding':f['id'],'error':'deciding_pointer_invalid','original':value,'detail':str(e)});continue
            else:
                bb=binding(d+'/'+filename)
                if suffix:text_labels.append({'finding':f['id'],'directory':d,'label':suffix,'resolution':'retained_line_or_scenario_label_not_JSON_pointer','file':filename})
            checks.append({'finding':f['id'],'kind':'deciding_evidence','original':value,'binding':bb})

for f in findings:
    for r in f['raw_records']:
        if r.get('pointer') is not None:
            try:
                actual=ptr(read(BASE/r['path']),r['pointer'])
                ok=actual==r['record']
                checks.append({'finding':f['id'],'kind':'raw_primary_pointer','binding':binding(r['path'],r['pointer']),'exact_record':ok})
                if not ok:errors.append({'finding':f['id'],'path':r['path'],'pointer':r['pointer'],'error':'record_mismatch'})
            except Exception as e: errors.append({'finding':f['id'],'path':r['path'],'error':repr(e)})
        else:
            checks.append({'finding':f['id'],'kind':'report_only_summary','binding':binding(r['path']),'exact_record':None})
    for es in f['evidence_sources']:
        if digest(BASE/es['report']) != es['report_sha256']:errors.append({'finding':f['id'],'error':'report_hash_changed','path':es['report']})
        for dc in es.get('deciding_files_resolved',[]):
            pp=BASE/dc['path']
            if not pp.is_file() or digest(pp)!=dc['sha256']:errors.append({'finding':f['id'],'error':'deciding_evidence_changed','path':dc['path']})
        if es.get('json_pointer') is not None:
            checks.append({'finding':f['id'],'kind':'primary_selection','binding':binding(es['record_path'],es['json_pointer'])})
        for bb in es.get('supplementary_deciding_bindings',[]):
            if binding(bb['path'],bb.get('json_pointer'))!=bb:
                errors.append({'finding':f['id'],'error':'supplementary_deciding_binding_changed','path':bb['path']})
            checks.append({'finding':f['id'],'kind':'supplementary_deciding_evidence','binding':bb})
        if es['directory'] in REVIEW_INFO:
            resolve_deciding_refs(f,es)
    for rv in f.get('independent_reviews',[]):
        checks.append({'finding':f['id'],'kind':'review_report','binding':binding(rv['report'])})
        for p in rv.get('machine_decisions',[]):checks.append({'finding':f['id'],'kind':'review_decisions','binding':binding(p)})
        for bb in rv.get('bindings',[]):
            ok=binding(bb['path'],bb.get('json_pointer'))==bb
            if not ok:errors.append({'finding':f['id'],'error':'review_binding_changed','path':bb['path']})
    for sr in f.get('normalized_source_references',[]):
        if sr.get('path') is None:continue
        if sr['path'] not in SOURCE_EXPECTED or sr['sha256']!=SOURCE_EXPECTED[sr['path']]['sha256']:
            errors.append({'finding':f['id'],'error':'source_binding_mismatch','source':sr})
links=[]
for name in ['REPORT_RU.md','README_RU.md']:
    for link in re.findall(r'\]\(([^)]+)\)',(OUT/name).read_text()):
        if '://' in link:continue
        p=OUT/link.split('#')[0]
        if not p.exists():errors.append({'error':'missing_markdown_link','document':name,'link':link})
        links.append({'document':name,'target':link,'exists':p.exists()})
# Validation files will exist below; they are forward references, not missing evidence.
future={'VALIDATION.json','REFERENCE_VALIDATION.json','SHA256SUMS.txt'}
errors=[e for e in errors if not(e.get('error')=='missing_markdown_link' and e['link'] in future)]
for x in links:
    if x['target'] in future:x['exists']='generated_by_this_build'
changed=[]
for x in INPUT_FILES:
    p=BASE/x['path']
    if not p.is_file() or digest(p)!=x['sha256']:changed.append(x['path'])
write('REFERENCE_VALIDATION.json',{'status':'PASS' if not errors else 'FAIL','errors':errors,'checks':checks,'markdown_links':links,'unresolved_source_locator_text':unresolved_locators,'unresolved_locator_note':'Raw textual locator kept; exact primary/review/source-validation files remain linked. No invented source path.','nonpointer_evidence_labels':text_labels,'primary_records_semantically_reviewed_by_this_validation':False})
inherited_ok=all(next(f for f in findings if f['id']==RENAME.get(old['id'],old['id']))['raw_records'][:len(old['raw_records'])]==old['raw_records'] for old in OLD_REGISTRY['findings'])
package_ids={p['id'] for p in road['packages']}
def visit(n,trail):
    assert n not in trail, (n,trail)
    for dep in next(p for p in road['packages'] if p['id']==n)['dependencies']:visit(dep,trail+[n])
for n in package_ids:visit(n,[])
validation={'generated_at_utc':NOW,'status':'PASS_FOR_SYNTHESIS_INTEGRITY_ONLY' if not(errors or changed or source_results) else 'FAIL','audit_status':'PARTIAL','audit_complete':False,'product_acceptance':False,'runtime_reexecution':False,'all_cards_independently_semantically_reviewed':False,'selected_synthesis_review':selected_review,'source_commit':COMMIT,'source_tree':TREE,
 'registry_entries':len(findings),'mechanism_groups':len(groups),'new_cumulative_cards':len(CARDS),'global_defect_or_incident_count':None,'observation_records':len(observations),'safeguard_records':len(safe),
 'input_files_checked_unchanged':len(INPUT_FILES),'changed_inputs':changed,'full_source_baseline_files_rehashed':len(source_manifest),'source_mismatches':source_results,
 'prior_synthesis_and_primary_inputs_unchanged':not changed,'all_81_inherited_raw_record_arrays_preserved':inherited_ok,'registry_aliases_unique':True,'dependency_graph_acyclic':True,'all_cards_assigned_existing_package':all(f['remediation_package'] in package_ids for f in findings),
 'raw_JSON_pointer_checks':sum(c['kind']=='raw_primary_pointer' for c in checks),'reference_validation_errors':errors,'unresolved_inherited_text_locators':len(unresolved_locators),'reference_validation':'REFERENCE_VALIDATION.json','source_validation':'SOURCE_VALIDATION.json',
 'limitations':['Checks certify local bytes/pointers, not native execution, external recipient access, remote freshness or deployed exploit.','Historical and checkpoint reviews are not re-attestation of this new synthesis.','No source/evidence report was edited. Delivery packaging/access validation remains parent deliverable.']}
write('VALIDATION.json',validation)
manifest=[{'path':str(p.relative_to(OUT)),'bytes':p.stat().st_size,'sha256':digest(p)} for p in sorted(OUT.rglob('*')) if p.is_file() and p.name not in ['MANIFEST.json','SHA256SUMS.txt'] and '__pycache__' not in p.parts]
write('MANIFEST.json',{'status':'PARTIAL_FROZEN_SYNTHESIS','audit_complete':False,'source_commit':COMMIT,'checkpoint_scope':[1,22],'files':manifest})
all_files=[p for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.txt' and '__pycache__' not in p.parts]
(OUT/'SHA256SUMS.txt').write_text(''.join(f'{digest(p)}  {p.relative_to(OUT)}\n' for p in all_files))
print(json.dumps({k:validation[k] for k in ['status','registry_entries','mechanism_groups','new_cumulative_cards','input_files_checked_unchanged','changed_inputs','full_source_baseline_files_rehashed','reference_validation_errors','unresolved_inherited_text_locators']},ensure_ascii=False,indent=2))
if validation['status']=='FAIL':raise SystemExit(1)
