#!/usr/bin/env python3
"""Verify package and optionally local source/input closure, without writing."""
from pathlib import Path
import argparse, hashlib, json, sys

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent

def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def read(p):return json.loads(p.read_text())

def selected(obj,pointer):
    if not pointer:return obj
    for key in pointer.removeprefix('#').split('/')[1:]:
        key=key.replace('~1','/').replace('~0','~')
        obj=obj[int(key)] if isinstance(obj,list) else obj[key]
    return obj

ap=argparse.ArgumentParser()
ap.add_argument('--check-inputs',action='store_true',help='Require all sibling evidence/input files and validate JSON pointers')
ap.add_argument('--check-source',action='store_true',help='Rehash every baseline-listed source file; requires source checkout')
args=ap.parse_args()
fail=[];counts={'package_files':0,'input_files':0,'reference_bindings':0,'source_files':0}
for row in read(ROOT/'MANIFEST.json')['files']:
    p=ROOT/row['path'];counts['package_files']+=1
    if not p.is_file() or p.stat().st_size!=row['bytes'] or digest(p)!=row['sha256']:fail.append({'kind':'manifest','path':row['path']})
for line in (ROOT/'SHA256SUMS.txt').read_text().splitlines():
    h,name=line.split('  ',1);p=ROOT/name
    if not p.is_file() or digest(p)!=h:fail.append({'kind':'checksum','path':name})
r=read(ROOT/'REGISTRY.json')
if read(ROOT/'FINDINGS.json')!=r:fail.append({'kind':'registry_copies'})
if r['audit_status']!='PARTIAL' or r['audit_complete'] or r['fixes_implemented']:fail.append({'kind':'status'})
ids=[f['id'] for f in r['findings']]
if len(ids)!=len(set(ids)):fail.append({'kind':'duplicate_id'})
if args.check_inputs:
    for row in read(ROOT/'INPUT_MANIFEST.json')['files']:
        counts['input_files']+=1;p=BASE/row['path']
        if not p.is_file() or p.stat().st_size!=row['bytes'] or digest(p)!=row['sha256']:fail.append({'kind':'input','path':row['path']})
    for row in read(ROOT/'REFERENCE_VALIDATION.json')['checks']:
        bb=row['binding'];p=BASE/bb['path'];counts['reference_bindings']+=1
        if not p.is_file() or digest(p)!=bb['sha256']:
            fail.append({'kind':'reference','path':bb['path']});continue
        if 'json_pointer' in bb:
            try:
                value=selected(read(p),bb['json_pointer'])
                h=hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
                if h!=bb['selected_value_sha256']:fail.append({'kind':'pointer_value','path':bb['path'],'pointer':bb['json_pointer']})
            except Exception as e:fail.append({'kind':'pointer','path':bb['path'],'detail':repr(e)})
if args.check_source:
    for row in read(BASE/'baseline/snapshot_files_sha256.json'):
        counts['source_files']+=1;p=BASE/'source'/row['path']
        if not p.is_file() or digest(p)!=row['sha256']:fail.append({'kind':'source','path':row['path']})
out={'status':'PASS_INTEGRITY_ONLY' if not fail else 'FAIL','audit_status':'PARTIAL','counts':counts,'input_closure_checked':args.check_inputs,'source_bytes_checked':args.check_source,'native_or_product_acceptance':False,'failures':fail}
print(json.dumps(out,ensure_ascii=False,indent=2))
sys.exit(bool(fail))
