# PolicyOS: промежуточная сводка глубокого аудита, checkpoint01–11

**PARTIAL. Аудит продолжается. Это навигация, приоритеты и квалифицированный реестр, не завершение аудита, не выполненные исправления, не production readiness и не разрешение E02/release.**

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`, tree `29890b967236a8f07e2b0f92a0133ee36883ac49`. Срез объединяет только checkpoint01–11. Исходный план и все первичные отчёты/evidence сохранены без правки. Новые параллельные `next_*` вне этого списка не подмешаны.

## 1. Что делать сначала

1. **До deployment новых grants:** согласовать server vocabulary, canonical и реально поставляемый OPA pack (AUTH-01/02), затем actual engine и endpoint identity. 38≠34 доказано исходниками; реальный OPA всё ещё UNRUN. Не чинить отказ расширением обычных ролей или выключением gate.
2. **Сначала durable correctness:** STATE-01 и STATE-02 имеют самые сильные новые persisted-owner доказательства: real CAS/SQLite, process death, fresh readers и independent controls. Первый теряет exact selected workflow receipt и отказывает; второй может подтвердить origin outbox до полного применения invalidation. Это по-прежнему P2 и не publication bypass.
3. **Отделить logical stop от physical end:** LIF/BUD/FLOW нельзя лечить освобождением всех reservations при timeout. Сохранить unknown outcome, текущую lease/fence и producer-owned settlement, исправляя cleanup и truthful drain отдельно.
4. **Сохранить смысл до оптимизации:** DC/EC требуют двух уровней scope/mode binding, RC-01 исполнения заявленных independence rules, RD-01 typed cross-join и composition law, CS-01 exact diagnostic relation/provenance. Candidate/pass/current/available не равны scientific или institutional authority.
5. **Параллельная enabling-ветка:** supported native profile, реальный OPA, test selection, installed origins, browser/Node22. Frozen exports, hash PASS и Node24 tests не закрывают это. Исправления библиотек/индексов и файловые moves остаются отдельной будущей работой.

P1 здесь условный release/correctness prerequisite, а не оценка exploit severity. В inherited SYS-03 локальная lock lifetime и SYS-04 independence admission также остаются ранее заявленными P1 subpriorities; новый срез их не перепроверил и не понизил. SYS-09 naming и SYS-10 canary/shipped-object identity не закрыты соседними новыми controls.

## 2. Как читать реестр

- [FINDINGS.json](FINDINGS.json) / [REGISTRY.json](REGISTRY.json): одинаковый machine registry со source locators, первичными записями, независимыми review, ограничениями, owner/remediation/acceptance и dependency package.
- [NAVIGATION.json](NAVIGATION.json): точное распределение по checkpoint и отчётам; [PRIOR_CROSSWALK.json](PRIOR_CROSSWALK.json): исходные 12 SYS-тем и их AUD/source IDs без повторного счёта.
- [ROADMAP.json](ROADMAP.json): последовательность будущих изменений и acceptance; [SAFEGUARDS.json](SAFEGUARDS.json), [OPEN_WORK.json](OPEN_WORK.json), [REJECTED_SIGNALS.json](REJECTED_SIGNALS.json), [REUSE_DECISIONS.json](REUSE_DECISIONS.json).
- [INPUT_MANIFEST.json](INPUT_MANIFEST.json) фиксирует прочитанный срез. [VALIDATION.json](VALIDATION.json) проверяет только целостность/ссылки/реестр, не продукт. Полный source checkout не копируется.

Каждая запись — конкретный контракт ремонта/квалификации. `kind` отделяет defect, risk, documented legacy, checker/qualification gap и reuse decision. Их число не является количеством новых дефектов или инцидентов. Сходная тема SYS не означает одинаковый root cause.

**Дедупликация:** STATE-01 объединяет ранний state, real finalize и два review; STATE-02 объединяет state, DELIVERY-01/02 и reviews. RST и RQ-SQL — уточнения старых ST/SG, не новые findings. LIF-02/03 относятся к одному lifecycle owner, но premature terminal status и missing stop recheck оставлены разными causal seams. FG-02/GR-03 — углубление content/generation freshness. DC-02/EC-02 связаны одной цепочкой mode-binding, но не слиты: upstream projection и downstream precondition binding требуют разных изменений. DC-01 и EC-01 тоже не слиты: сохранение grammar components не исправляет глобальную scope/query identity downstream. PA-01 — один round-trip contract с двумя последовательными codec failures. LIB-02 явно сохраняет отдельно RNG и strata-block defects внутри одной sampling acceptance программы.

**Evidence tiers:** `indexed_only` ≠ `source_traced` ≠ `bounded_probe` ≠ compatibility-assisted real persisted owners ≠ `native_targeted` ≠ `installed_integration` ≠ deployed. Реальный fresh process/CAS усиливает вывод, но не устраняет loader seams. Здесь ни один новый product/probe не запускался.

Сводка прошла [независимый выборочный review](../next_review_synthesis/REPORT_RU.md) 16 критических карточек. По нему уточнены только standalone title SG-04 и summary RC-01; severity и исходные raw records не менялись. [REVIEW_APPLICATION.json](REVIEW_APPLICATION.json) связывает прежние проверенные bytes с этими двумя поправками. Frozen reviewer receipts относятся к предыдущему snapshot и сохранены без изменений. Это не семантическая перепроверка всех 81 карточки. Отдельный source-adapter pass reviewer не включён в checkpoint01–11 реестр.

## 3. Обязательные сужения независимых review

- **STATE-01:** Fresh real scoped CAS/SIGKILL/strict reader strengthens earlier fixture result; missing selected workflow ref causes refusal/None. Non-workflow and post-terminal recovery work. No authority bypass; no native full sync/async producer or HTTP.
- **STATE-02:** Before sticky write: lost event persists after TTL/force and origin SQL ack. After sticky write: recompute can recover STALE but missing transition receipt remains. New event key can restore state. Minimal packet ACTIVE cannot be assumed for full HTE producer; typed incomplete basis yields WARNING. Notification published is not governed public signature.
- **EC-01:** Independent hybrid interleaving gives population B/geography A/time B. Queries precomputed globally and specs reuse last-by-type facets are both repair points. Normal production producer of multi-scope generic ledger not shown.
- **EC-02:** context_only is not a blanket method requirement ban: typed precondition on context_only yields bounds. Loss is missing semantic binding. Bounds/partial are strongest discriminators; not every proxy/interference dimension must be non-point.
- **PG-01:** README explicitly preserves legacy claim-evidence interpretation. selected_exact is not full temporal entailment. Candidate world-slot join refuses partial interval, removed fetch and profile mutation. No new regression; signed-owner/DS9 admission separate.
- **PA-01:** One writer/reader contract with two sequential failures: omitted canon, then counterfactual 0.2.0 recursive datetime vs raw JsonValue. put_bytes→put_json alone insufficient. Default root unappointed; no successful issuance/publication.
- **RD-01:** Retain missing occurrence→representation cross-join. sum=8 with mean declarations does not prove intended value=4 without a composition law. Source/port scope guards do exist. recomputed_axes includes compared axes even on refusal; actual consumers inspect full status.
- **CS-01:** Same-dimension foreign diagnostic suffices, so dimension check alone insufficient. Actual used diagnostic ref absent from output lineage; producer own diagnostic ref is bare, not selected-profile exact. Explicit reanalysis may be valid only with typed relation/provenance. IR attach has no discovered production caller.
- **CS-02:** Retain P3 API ambiguity: parent is audit/request context; shipped tests use different ID namespaces and detached nullable-parent sidecars exist. No evidence audit metadata is accepted as verified custody. Do not add naive parent string equality.
- **SG-04:** REQUIRED CORRECTION: active-only denominator applies to no-statistics MULTI-INDEX OR fixture, not query invariant. Independent SQLite3.53.1 after ANALYZE scans 100/1000/10000 total jobs at fixed 5 pending+5 running: 551/5051/50051 VM callbacks. Completed history can participate.
- **RC-01:** Five declared relation dimensions and effective_support_per_cluster not consumed. Shared authors/institutions not universal empirical dependence. Matched same-study reviewer cluster weight1 and0 both count1 removes singleton-rule-activation ambiguity. Genuine source/Scientist verifier rejects invented span.
- **FE-01:** clear/set have no discovered UI invocation; failure/rejection not permanent deadlock because subsequent refresh recovers. Exact module transport replay shown, real logout/account-switch or server auth bypass unrun.
- **FE-06:** Only test callers found; actual backend produces refusals. State-only/owner-only mutations missed, coherent supplied record changes reason/code and is caught. Not production authority gate or public export bypass.
- **GR-01:** Canonical producer is epoch_manifest→issuance_basis; canonical target refs preserve profiles and may refuse receipt/duplicate edge before transition. Valid persisted admitted profile-collision denominator causing wrong transition not shown.
- **GR-02:** Order-dependent false incompleteness retained; shortest-distance depth semantics are not explicit. Consumers may refuse incomplete; no false-green acceptance or security exploit established.

Независимость неодинакова: graph и publication/dataflow review — новое source/evidence reasoning без runtime replay; catalog/scaling review не повторял дорогие серии. SQL имеет независимо извлечённый AST/SQL probe. Остальные named reviews добавляют bounded replay/controls, часто используя тот же compatibility loader. Это не full native independence.

## 4. Приоритизированные карточки

### R0. Квалифицировать поддерживаемый профиль и test lanes

Dependencies для integrated acceptance: нет. Existing Python3.14/Node22/uv locks; selected collect/execute manifest; actual OPA; isolated installed origin. Tooling repairs are future work, no installs/source edits here.

- **NATIVE-01 [P2; finding]: Bootstrap вызывает doctor без package context.** Exact bootstrap file-mode command gives relative-import error; existing module-mode verify/ci_parity commands list surfaces.
  Доказательства: [тематический отчёт](../next_native/REPORT_RU.md); bootstrap_doctor_results.json. Ограничение: Namespace shim under Python3.12; CI setup explicitly skip-doctor, no hosted CI failure asserted.
- **TC-01 [P2; finding]: Nightly wrapper вычисляет неверный product root.** Unchanged wrapper after stubbed heavy uv call invokes missing tools/benchmarks/build_release_summary.py; real Python exit2.
  Доказательства: [тематический отчёт](../next_test_confidence/REPORT_RU.md); offline_probe_results.json. Ограничение: No hosted run or real heavy benchmark executed.
- **TC-02 [P2; qualification_gap]: Installed-only tests направлены в checkout lane.** Three installed worker tests selected by Fast PR demand site-packages origin while conftest prepends checkout; historical isolated launcher is not current CI wiring.
  Доказательства: [тематический отчёт](../next_test_confidence/REPORT_RU.md); offline_probe_results.json. Ограничение: Synthetic origin assertion; native collection and installed profile unrun.
- **TC-03 [P2; qualification_gap]: OPA test dependency не provisioned в checked-in lane.** Real parity test fails when opa binary missing; HTTP root selected but checked-in root setup does not provision OPA.
  Доказательства: [тематический отчёт](../next_test_confidence/REPORT_RU.md); offline_probe_results.json. Ограничение: Hosted image inventory unknown; not a fresh hosted failure.
- **TC-04 [P2; qualification_gap]: Benchmark marker/path/class selection расходится.** 32 of 52 explicit benchmark definitions outside four main selectors; 12 of these in Benchmark* classes without configured collection convention.
  Доказательства: [тематический отчёт](../next_test_confidence/REPORT_RU.md); offline_probe_results.json. Ограничение: Definitions are not parametrized case count; other equivalent tests not ruled out.
- **TC-05 [P2; finding]: Benchmark timing oracle пропускает нулевую работу.** Exact benchmark method passes for 6 successful effects and for 6 always-raising attempts with zero effects.
  Доказательства: [тематический отчёт](../next_test_confidence/REPORT_RU.md); offline_probe_results.json. Ограничение: Synthetic timing driver, not speed measurement or entire suite verdict.
- **TC-06 [P3; latent_risk]: Quarantine expiry не становится обязательным gate.** Synthetic expired entry still skipped; current registry empty.
  Доказательства: [тематический отчёт](../next_test_confidence/REPORT_RU.md); offline_probe_results.json. Ограничение: No current test hidden by registry; no active de-gating incident.
- **STR-01 [P2; qualification_gap]: Пять package mirror ratios ниже floor.** Exact package report gives floor_regression for data_forge/foundry/ir/runtime/scientist; file-presence ratios do not establish behavioral coverage.
  Доказательства: [тематический отчёт](../next_structure/REPORT_RU.md); structure_depth_results.json. Ограничение: 494 matched source modules are not tests or defects; no native CLI.
- **STR-02 [P3; checker_gap]: Hidden-edge checker зависит от формы import.** Direct fabric.world.store found; from fabric.world import store missed. All 79 real selected parent→child candidates were legitimate __all__ exports.
  Доказательства: [тематический отчёт](../next_structure/REPORT_RU.md); structure_depth_results.json. Ограничение: Synthetic escape of one checker, not CI bypass or 79 violations.
- **STR-03 [P3; latent_risk]: Test helper teardown смотрит одну import identity.** _helpers.runtime_http and tests._helpers.runtime_http keep separate registries; teardown reads first only.
  Доказательства: [тематический отчёт](../next_structure/REPORT_RU.md); structure_depth_results.json. Ограничение: Selected long-name callers close environments explicitly; suite leak unestablished.
- **FE-05 [P2; finding]: Runtime client architecture check is stale and parses fixture strings as imports.** Unchanged script exit 1: two real generator files not allowlisted; regex additionally sees template/fixture import strings.
  Доказательства: [тематический отчёт](../next_frontend_contracts/REPORT_RU.md); client_architecture.stderr.txt. Ограничение: Node24 builtin-only execution.

**Acceptance пакета:** Exact environment and command provenance, native positive/removal/failure controls, wheel/sdist object identities. Availability blocker applies only inspected cloud.

### R1. Восстановить durable selected finalization и event application

Dependencies для integrated acceptance: R0. Core finalize journal stores exact selected receipt. Scientist validity owner stores content-bound received/pending/applied and idempotent per-target receipts; origin ack waits complete owner result.

- **STATE-01 [P2; finding]: Finalize recovery loses selected workflow transition across real CAS/process restart.** Verified terminal run can lose the explicit selected workflow receipt; Runtime cannot select final experiment state. Availability/currentness evidence loss, not authority bypass.
  Доказательства: [тематический отчёт](../next_finalize_chain/REPORT_RU.md); scoped_results.json. Ограничение: Python 3.12 compatibility, synthetic upstream registry/workflow/state JSON, full sync/async engine and HTTP authorization not executed.
  Review: [next_review_state](../next_review_state/REVIEW_RU.md), [next_review_finalize](../next_review_finalize/REVIEW_RU.md).
- **STATE-02 [P2; finding]: Originating HTE outbox acknowledges incomplete generic invalidation.** Real SQL completion source/outbox and actual CAS validity owner; fresh-process retry writes event_published notification and marks originating row published while one or both target evaluations remain ACTIVE. Force recompute does not recover events missing from sticky state.
  Доказательства: [тематический отчёт](../next_delivery_chain/REPORT_RU.md); results.json:before_second_packet,crash_after_dedupe. Ограничение: Synthetic schema-valid HTE selection refs, minimal generic packet payloads, extracted Runtime methods, Python3.12 compatibility adapters; no public policy claim/full HTE numerical producer/authenticated HTTP.
  Review: [next_review_state](../next_review_state/REVIEW_RU.md), [next_review_delivery](../next_review_delivery/REVIEW_RU.md).

**Acceptance пакета:** Actual sync/async producer, full builder HTE targets, durable-step kills/failures, fresh readers/API, legacy journal, changed payload/target drift; no guessed selection or dedupe-only ack.

### R2. Замкнуть logical cancellation и physical settlement

Dependencies для integrated acceptance: R0. Keep generic replay distinct from domain reservation; truthful drain and no new dispatch. Retain producer-owned accounting observer through repeated cancellation until physical outcome. N5 disposal independent of authority.

- **LIF-01 [P2; finding]: Cancellation и ошибки после response теряют локальный cleanup.** Exact ASGI stack: cancelled POST retains pending, retry 409; four cancelled live-open retain slots, fifth 429. Ordinary Exception and managed iterator cancellation release their state.
  Доказательства: [тематический отчёт](../next_lifecycle/REPORT_RU.md); mutation_lifecycle_results.json; mutation_asgi_results.json. Ограничение: Off-lock Starlette/AnyIO; task cancellation не TCP disconnect; synthetic routes; default domain effect не выполнялся.
- **LIF-02 [P2; finding]: Worker stop объявляет stopped до drain.** ControlRunService.close/container shutdown return after timeout with live handler. Default closed guard refuses new SQL calls; already running dependency can complete under still-current fence.
  Доказательства: [тематический отчёт](../next_lifecycle/REPORT_RU.md); worker_lifecycle_results.json; guarded_shutdown_results.json. Ограничение: Raw-store late insert не переносится на default guarded runtime; production double execution, cancellation authority и budget settlement не доказаны.
- **LIF-03 [P2; finding]: Stop во время maintenance допускает последующий dispatch.** After stop returns while maintenance is blocked, released callback leases pending job and starts handler with stop flag set.
  Доказательства: [тематический отчёт](../next_lifecycle/REPORT_RU.md); worker_lifecycle_results.json. Ограничение: Synthetic maintenance/job; exact default closed-guard interleaving не выполнен.
- **LIF-04 [P2; contract_gap]: Completed-response cache не обеспечивает durable reservation.** Two processes sharing directory accept same key with same or different payload; after death before complete retry is started. Atomic response replacement is not effect admission.
  Доказательства: [тематический отчёт](../next_lifecycle/REPORT_RU.md); mutation_lifecycle_results.json. Ограничение: Class is documented response cache; no actual duplicate production job or NL/predictive bypass. P1 prerequisite only if global at-most-once guarantee is intended.
- **BUD-01 [P2; finding]: Repeated cancellation retires direct producer accounting ownership before physical completion; known late response remains terminal unknown and blocks same-run admission..** Repeated cancellation retires direct producer accounting ownership before physical completion; known late response remains terminal unknown and blocks same-run admission.
  Доказательства: [тематический отчёт](../next_budget_authority/REPORT_RU.md); budget_authority_results.json cancellation: ainvoke/generate × one/two cancellations; real imports/public clients/ledger/observer; synthetic provider/cost. Ограничение: see primary report; bounded evidence does not establish operational incidence
- **FLOW-01 [P2; lifetime_risk]: N5 capture/observer lifetime удерживает payload ownership.** _token retains 16/16 objects; completed observer retains 4/4 frame locals until observer owners deleted. Successful seal retains capture by source; positive issued registry not manufactured.
  Доказательства: [тематический отчёт](../next_n5_revoke/REPORT_RU.md); n5_probe_results.json; probe_n5_revoke.py. Ограничение: No production RSS, universal leak or native successful seal/revoke E2E; object retention is not publication authority.

**Acceptance пакета:** Actual generic routes, direct/cached LLM branches, multiple cancels, late known/unknown response, restart/lease/PA2; physical execution and accounting settlement tracked separately.

### R3. Сохранить component scopes и identification restrictions

Dependencies для integrated acceptance: R0. Existing grammar/decomposition/compiler owners retain component-linked scopes and mode constraints, or typed refusal. Legacy scope contract must be explicitly decided, not silently upgraded.

- **DC-01 [P2; finding]: Composite grammar silently drops independent domain obligations and required constructs.** Two domain cases and joint all compiled; joint drops 3 seed obligation candidates and 7 required constructs. Reverse text order and default frontier budget reproduce loss. Stacked facet rows instead produce order-dependent rule matching.
  Доказательства: [тематический отчёт](../next_domain_composition/REPORT_RU.md); primary report source/result references. Ограничение: No actual whole scenario/capability resolver execution; No final admitted/published claim; Independent explicit constructs or critics may compensate; Synthetic concept refs, source-extracted modules and unmatched native profile
  Review: [next_review_domain](../next_review_domain/REPORT_RU.md).
- **DC-02 [P2; finding]: Grammar strengthens four explicit IdentificationMode values to point_identified.** real enum values survive normalizer then four map to point_identified, compiled. Point/sequential preserved. Explicit downstream claim partial_identification remains bounds.
  Доказательства: [тематический отчёт](../next_domain_composition/REPORT_RU.md); primary report source/result references. Ограничение: PolicySpec-shaped collaborator is synthetic, native IR validation unrun; Final selector can independently preserve explicit constraints; No estimator execution or publication established
  Review: [next_review_domain](../next_review_domain/REPORT_RU.md).
- **EC-01 [P2; finding]: Claim-bound scope collapses to globally last facet in data compiler.** Two independent claims requiring the same construct for distinct scopes produce one global resolver query and two specs both using the last component scope; reverse order reverses both scopes despite unchanged claim facet_refs.
  Доказательства: [тематический отчёт](../next_evidence_composition/REPORT_RU.md); primary report source/result references. Ограничение: Native typed PolicySpec, production resolver, persisted/scientific/protected output unrun.
  Review: [next_review_evidence](../next_review_evidence/REPORT_RU.md).
- **EC-02 [P2; finding]: Explicit method facet is not bound into causal method preconditions.** For all six explicit method facet values, method facet becomes context_only while two linked causal claims produce point requirements. Explicit attached partial_identification precondition instead produces bounds.
  Доказательства: [тематический отчёт](../next_evidence_composition/REPORT_RU.md); primary report source/result references. Ограничение: No actual point estimator execution, unsupported policy deployment or publication demonstrated.
  Review: [next_review_evidence](../next_review_evidence/REPORT_RU.md).
- **FG-03 [P2; finding]: Early serious NL normalization не принимает расширенный registry.** Early serious-NL canonicalizer does not receive extended registry containing two new typed metric IDs; full valid corpus→HTTP path unrun, unknown/meaning guards must stay.
  Доказательства: [тематический отчёт](../next_freegrow/REPORT_RU.md); results.json#/taxonomy. Ограничение: Actual strict canonicalizer helper, two new typed synthetic metric IDs; not full valid corpus-to-HTTP e2e. Do not weaken unknown/meaning guards.
- **PG-01 [P3; documented_legacy_residual_risk]: Documented legacy binding retains overlap/partial-scope semantics while candidate discovery is stricter.** Documented legacy binding retains overlap/partial-scope semantics while candidate discovery is stricter
  Доказательства: [тематический отчёт](../next_persisted_growth/REPORT_RU.md); results.json; fresh_negative_reader.json; probe_persisted_growth.py; source_excerpts.json. Ограничение: Synthetic owner assertions; Source-body execution, not package import; Native N7 CAS bridge traced not run; No scientific/source/production admission; No publication bypass established; selected_exact is a legacy evidence-mode status, not a proof of full temporal entailment
  Review: [next_review_growth](../next_review_growth/REPORT_RU.md).

**Acceptance пакета:** Native multi-intervention PolicySpec, separate/joint/reversed/interleaved cases; complete obligations and claim-bound query/specs; actual persisted resolver and method consumer, no-source/no-method negatives.

### R4. Связать scientific declarations с фактическими inputs

Dependencies для integrated acceptance: R0, R3. Typed occurrence/representation composition law; policy-aware existing evidence independence owner; exact Jacobian state/profile/provenance; explicit estimands, grid/seed/algorithm identities.

- **RD-01 [P2; finding]: Recomputed measurement axes compare declarations without reconciling mechanically available occurrence facts.** Real source projection/replay produces sum(2,6)=8. Both representations declare mean and AGGREGATION is required, yet candidate/recomputed. Both representation populations may disagree with actual source/port scope while POPULATION_REF remains in recomputed_axes.
  Доказательства: [тематический отчёт](../next_registry_dataflow/REPORT_RU.md); results.json#/aggregation_join; results.json#/population_equal_declaration; fresh_reader.stdout.json#/cases/aggregation_mislabel; fresh_reader.stdout.json#/cases/population_mislabel. Ограничение: No native persisted admission or complete physical/publication bypass.; Raw aggregation versus representation aggregation may need a compositional meaning law, not unconditional literal equality.; External empirical truth remains explicitly unestablished.
  Review: [next_review_publication_dataflow](../next_review_publication_dataflow/REPORT_RU.md).
- **RC-01 [P2; finding]: Declared Scholar dependence collapse rules do not govern effective support count.** Five extra declared relation-dimension controls retain effective=2/pass in the author fixtures; same-dataset actual job/CAS and fresh reader preserve this. Independent matched same-study cluster gives effective=1/blocked for both weights 1 and 0, confirming weight non-consumption rather than universal threshold pass.
  Доказательства: [тематический отчёт](../next_research_chain/REPORT_RU.md); primary report source/result references. Ограничение: Synthetic scientific claims and metadata, no empirical paper-quality admission.; Actual job uses recorded-bundle service, no live providers or ScholarDeepSearchService.; Python 3.12 compatibility loader and namespace overrides, not native 3.14.; Only selected scorecard gate bodies, not full scorecard authority/admission.; Shared authors/institutions are not universal scientific proof of dependence; finding is declared policy consumption gap.; Zero-weight probe uses independent singleton studies, not a matched cluster; only diagnostic plus direct static absence of field reads. Independent matched control is separate review evidence.
  Review: [next_review_research](../next_review_research/REPORT_RU.md).
- **CS-01 [P2; finding]: Independent request Jacobian overrides feedback-owned diagnostic without a semantic join.** Independent request Jacobian overrides feedback-owned diagnostic without a semantic join
  Доказательства: [тематический отчёт](../next_cross_service/REPORT_RU.md); results.json#/results/CS_01_jacobian_source_join. Ограничение: see primary report; bounded evidence does not establish operational incidence
  Review: [next_review_cross_service](../next_review_cross_service/REPORT_RU.md).
- **CS-02 [P3; api_contract_debt]: Nested sidecar GET ignores parent identity and records caller association in audit metadata.** Nested GET ignores parent for child read; detached nullable sidecars and differing logical/content/profile namespaces make required parent relationship ambiguous. Narrow P3 contract debt, not verified audit poisoning.
  Доказательства: [тематический отчёт](../next_cross_service/REPORT_RU.md); interfaces_results.json#/results/CS_02_parent_is_audit_only. Ограничение: see primary report; bounded evidence does not establish operational incidence
  Review: [next_review_cross_service](../next_review_cross_service/REPORT_RU.md).
- **LIB-01 [P2; finding]: CDF/Wasserstein теряет distribution support и grid.** CDF grids are ignored; CDF ordinates treated as samples. Unequal-sample helper also differs from exact empirical W1.
  Доказательства: [тематический отчёт](../next_library/REPORT_RU.md); results.json#cdf_wasserstein. Ограничение: Native 3.14 imports, actual World.evaluate, persistence and downstream authority.
- **LIB-02 [P2; finding]: Bootstrap RNG вырождается; strata wrapper отдельно теряет блоки.** LCG modulo low bits produces deterministic alternating samples and zero empirical bootstrap mean variance; stratified wrapper samples only first element of each chosen block.
  Доказательства: [тематический отчёт](../next_library/REPORT_RU.md); results.json#moving_block_bootstrap. Ограничение: arch execution, calibration/registry end-to-end and production false-positive effects.

**Acceptance пакета:** Admitted source→selected persistence→fresh Runtime/Foundry/Scientist consumer; correct transformations and property-removal negatives; full numerical/report roundtrips without asserting authority from candidate pass.

### R5. Согласовать policy и publication object identity

Dependencies для integrated acceptance: R0. Canonical vocabulary/resource/policy pack; strict response schema; compatible publication draft codec preserving raw nested JSON and exact profile/bytes.

- **AUTH-01 [P1-conditional; finding]: Server permission vocabulary и canonical Rego расходятся.** 38 server permissions versus 34 Rego values; jobs.cancel and three registered_sql permissions missing. all-members-known predicate also rejects known actions for principal carrying new grants.
  Доказательства: [тематический отчёт](../next_auth/REPORT_RU.md); authorization_boundary_results.json; policy_profile_results.json. Ограничение: P1 before deploying these grants; source-derived fail-closed mismatch, actual OPA exit77 UNRUN, no live denial incident.
- **AUTH-02 [P1-conditional; finding]: Проверяемый policy pack не равен chart-shipped pack.** Canonical modules 8, chart 7; action_permission absent, decision differs. Chart local files override values fallback; client factory identity does not attest remote policy bytes.
  Доказательства: [тематический отчёт](../next_auth/REPORT_RU.md); authorization_boundary_results.json. Ограничение: Chart has no workload/mount; rendered/live endpoint bytes unknown. P1 release prerequisite, not proven HTTP bypass. Exact chart source locator is resolved by source receipts.
- **AUTH-03 [P2; hardening_gap]: OPA allow принимает truthy неboolean значения.** Exact check admits string false, deny, [false], 1; boolean false/null/absence/timeout deny.
  Доказательства: [тематический отчёт](../next_auth/REPORT_RU.md); authorization_boundary_results.json. Ограничение: Canonical/chart Rego returns boolean; no caller-controlled response type, authentication bypass or external exploit established.
- **PA-01 [P2; finding]: Governed publication private draft fails its own strict persisted round-trip.** Real private draft first prepare succeeds in memory; repeat and fresh owner read refuse missing canon. Counterfactual profile declaration exposes tagged datetime/raw JsonValue incompatibility; public issue not reached.
  Доказательства: [тематический отчёт](../next_publication_authority/REPORT_RU.md); Actual CAS and full owner: first prepare returns valid private draft with canon=null; exact repeat and fresh-process owner reopen refuse canon_profile_absent, wrapped publication_preparation_invalid. Synthetic signed-mandate issue fails before signing a public record.. Ограничение: Python 3.12 with recorded syntax/TypeVar compatibility adapters, not native 3.14.; Synthetic initialization policy, root issuer/verifier and institutional mandate; no deployed institutional authority.; Default production owner is unappointed and publication root custody unavailable independently of this defect.; No new SYS root-cause family counted pending broader grouping.
  Review: [next_review_publication_dataflow](../next_review_publication_dataflow/REPORT_RU.md).

**Acceptance пакета:** Engine-evaluated canonical/rendered/served decisions and native private prepare/reopen; genuine root/mandate/currentness/signature chain separately. No relaxed readers or implicit new authority.

### R6. Сделать discovery и refresh полными и согласованными

Dependencies для integrated acceptance: R0, R3. Complete catalog separate from bounded decode cache; generation-bound publication; full ArtifactRef identity; actual discovered method rather than nonempty reference; uncertainty before truncation.

- **NS-01 [P2; finding]: Concurrent refresh publishes mismatched cache and fingerprints.** 5/5 same-tenant append-only schedules preserve stale cached mtime and list ordering through force refresh, while fresh instance is current.
  Доказательства: [тематический отчёт](../next_scaling/REPORT_RU.md); results.json; probe_next_scaling.py; SOURCE_EXCERPTS.txt; SOURCE_VALIDATION.json. Ограничение: Method-return barrier expands scheduling window; not measured race probability.; No cross-tenant leak or permanent unrecoverability demonstrated.
  Review: [next_scaling](../next_scaling/REVIEW_RU.md).
- **NS-03 [P1-conditional; finding]: Default cap is still the observable catalogue boundary with real trace parsing.** 10,001 real trace directories, 10,000 indexed. Last run absent exact/tenant list until retained slot freed. Warm forced refresh avoids parsing but still scans/fingerprints.
  Доказательства: [тематический отчёт](../next_scaling/REPORT_RU.md); results.json; probe_next_scaling.py; SOURCE_EXCERPTS.txt; SOURCE_VALIDATION.json. Ограничение: No actual CAS manifest or artifact permission test.; No-journal finalization fixture; selected DTO dependency annotations are fixtures.
- **FG-01 [P2; finding]: G2 free-growth premise принимает строку вместо обнаруженного метода.** G2 premise accepts a nonempty method ref string even after report/registry failure, rather than establishing a discovered executable method; no complete G2 conformance or authority pass.
  Доказательства: [тематический отчёт](../next_freegrow/REPORT_RU.md); results.json#/g2_declaration_proxy. Ограничение: Source-extracted report/reducer, real temp JSON, synthetic SKG edge and unrelated recall/quality; no full G2 or authority pass claim.
- **FG-02 [P2; finding]: G1 cache и snapshot identity не различают изменения корпуса.** Warm same-root/query cache and snapshot identity do not distinguish selected corpus changes; fresh process/reset differs. GR-03 deepens missing content/generation identity in changed-set.
  Доказательства: [тематический отчёт](../next_freegrow/REPORT_RU.md); results.json#/g1_cache. Ограничение: Warm same-root/query proving-ground reader; synthetic catalog collaborators, no native DuckDB; new process/explicit reset differs.
- **GR-03 [P2; finding]: Incremental changed-set misses same-profile content mutation.** Different same-size fixture bytes and synthetic values preserve schema/count fingerprint and changed_input_count=0.
  Доказательства: [тематический отчёт](../next_graph_refresh/REPORT_RU.md); results.json#/capability_fingerprint. Ограничение: see primary report; bounded evidence does not establish operational incidence
- **NC-04a [P2; finding]: Explicit empty bindings retain prior search enrichment.** refresh(contracts,bindings=[]) retains connector and alias with unchanged fingerprint; direct index empty refresh and fresh searcher remove both.
  Доказательства: [тематический отчёт](../next_catalog_scale/REPORT_RU.md); primary report source/result references. Ограничение: No unsafe fetch/auth bypass established; runtime registry removal flow not executed.
  Review: [next_catalog_scale](../next_catalog_scale/REVIEW_RU.md).
- **NC-04b [P2; finding]: max_results=1 converts known exact ambiguity into successful resolve.** 100 and1000 shared exact matches:limit1 gives false disambiguation and returns first binding;limit5 gives true and resolve ValueError.
  Доказательства: [тематический отчёт](../next_catalog_scale/REPORT_RU.md); primary report source/result references. Ограничение: Default MetricSearcher5/FastLane12 unaffected by this specific configuration; production caller with1 not established.
  Review: [next_catalog_scale](../next_catalog_scale/REVIEW_RU.md).
- **GR-01 [P2; finding]: Epoch graph collapses selected manifest profiles.** Profile-A event reaches Profile-B branch; two target profiles collapse to one order-selected row.
  Доказательства: [тематический отчёт](../next_graph_refresh/REPORT_RU.md); results.json#/profile_alias. Ограничение: see primary report; bounded evidence does not establish operational incidence
  Review: [next_review_graph](../next_review_graph/REPORT_RU.md).
- **GR-02 [P2; finding]: CAS bounded DFS loses shorter reachable path.** Same graph and depth budget yields skipped shared node/no leaf when long path visited first, versus present shared and leaf under input reorder.
  Доказательства: [тематический отчёт](../next_graph_refresh/REPORT_RU.md); results.json#/lineage_depth_order. Ограничение: see primary report; bounded evidence does not establish operational incidence
  Review: [next_review_graph](../next_review_graph/REPORT_RU.md).

**Acceptance пакета:** Real >cap owner-protected exact/list access; refresh barriers; persisted add/remove/same-count mutation/reopen; new typed resources discover→execute→admit/refuse; selected-profile graph cases.

### R7. Оптимизировать подтверждённые growth costs без ослабления guards

Dependencies для integrated acceptance: R0, R1, R6. First actual workload multiplicity and planner statistics; existing validated snapshots/indexes and revision-aware reuse. Preserve full historical proof, scope, corruption detection, ordering and retry denominator.

- **NS-02 [P2; finding]: Single pending batch is reparsed for each projection-bearing cached run.** R overlay-bearing rows times T targets yields R*T parsing/validation; with R=T=800 one list reads 92,144,000 JSON bytes despite page size 1.
  Доказательства: [тематический отчёт](../next_scaling/REPORT_RU.md); results.json; probe_next_scaling.py; SOURCE_EXCERPTS.txt; SOURCE_VALIDATION.json. Ограничение: R excludes trace-only/no-packet rows.; ArtifactRef/outer cache/caller fixture; full projection CAS/admission unrun.; Bytes are application reads, not physical storage traffic.
  Review: [next_scaling](../next_scaling/REVIEW_RU.md).
- **NS-04 [P2; finding]: VOI incremental history and replay repeat full-history fits.** H=50/200/800 accepted observations cause H fits and 1,275/20,100/320,400 record visits, H(H+1)/2.
  Доказательства: [тематический отчёт](../next_scaling/REPORT_RU.md); results.json; probe_next_scaling.py; SOURCE_EXCERPTS.txt; SOURCE_VALIDATION.json. Ограничение: Synthetic observations; full scheduler/from_snapshot unrun.; No scientific correctness or p95 assertion.
- **NS-05 [P3; contract_decision_pending]: Durable JSONL does not automatically restore process-global selection history.** Two real processes same configured path: first writes seven records and fits; second has zero in memory/unfitted predictor, all seven JSONL rows intact.
  Доказательства: [тематический отчёт](../next_scaling/REPORT_RU.md); results.json; probe_next_scaling.py; SOURCE_EXCERPTS.txt; SOURCE_VALIDATION.json. Ограничение: Not called data loss or proven contract violation.; Full module imported under isolated name, not installed package.
- **NC-01 [P2; finding]: Shared alias posting construction has quadratic equality work.** N=500/1000/2000 gives 124750/499500/1999000 ID comparisons for one shared tag, zero without it.
  Доказательства: [тематический отчёт](../next_catalog_scale/REPORT_RU.md); primary report source/result references. Ограничение: No production latency/SLA breach; large search corpus excludes shared aliases.
  Review: [next_catalog_scale](../next_catalog_scale/REVIEW_RU.md).
- **NC-02 [P2; finding]: Unchanged semantic refresh and promotion rebuild every document.** At200000 unchanged contracts:changed=[] and200000 fingerprints/builds/vectorizations. Five promotion-body calls atN1000 produce5000 document builds.
  Доказательства: [тематический отчёт](../next_catalog_scale/REPORT_RU.md); primary report source/result references. Ограничение: One sample per build/refresh size; no HTTP approval/e2e/concurrency/persistence/profile enrichment.
  Review: [next_catalog_scale](../next_catalog_scale/REVIEW_RU.md).
- **NC-03 [P2; finding]: Search output limit does not bound scans or ranking work.** At200000 contracts top1/top5 non-exact query performs200000 cosine+600000 alias scores. FastLane exact materializes200000 IDs. Shared exact atN1000 constructs2000 bindings.
  Доказательства: [тематический отчёт](../next_catalog_scale/REPORT_RU.md); primary report source/result references. Ограничение: Synthetic fixed tokens, no production distribution; standalone SourceContract catalog separate; DataForge HNSW not measured.
  Review: [next_catalog_scale](../next_catalog_scale/REVIEW_RU.md).
- **ST-01 [P2; finding]: Ownership generations retain full snapshots for each new claim.** 800 actual record_owner additions retain 800 generations: 74492731 bytes total, 185001 active. Diagnostic evidence reads 801 generation files and 74677732 generation bytes.
  Доказательства: [тематический отчёт](../next_storage_scale/REPORT_RU.md); primary report source/result references. Ограничение: No CAS blob/manifest writes or full publication transaction. Deliberate custody history design, no data-loss/SLA incident demonstrated.
  Review: [next_review_storage](../next_review_storage/REPORT_RU.md).
- **ST-02 [P2; finding]: Warm exact ownership lookup re-reads and hashes the full active generation.** 50000 synthetic claims/100 tenants: each warm exact lookup reads 10050932 generation bytes plus203 pointer bytes, zero generation parses. Incremental warm heap peak10058835 bytes.
  Доказательства: [тематический отчёт](../next_storage_scale/REPORT_RU.md); primary report source/result references. Ограничение: One legitimate bulk-seeded generation, synthetic claims, no artifact manifests or full API. Bytes are application reads, not physical disk traffic. Heap is incremental Python allocation, not total RSS/leak.
  Review: [next_review_storage](../next_review_storage/REPORT_RU.md).
- **ST-03 [P3; conditional_scaling_risk]: Tenant quota wrapper scans every CAS member twice under mutation lock.** 50000 synthetic32-byte files: no-op mutation traverses170522 entries and performs170528 lstat calls; actual wrapper elapsed2.457s in local fixture.
  Доказательства: [тематический отчёт](../next_storage_scale/REPORT_RU.md); primary report source/result references. Ограничение: Compatibility wrapper, no direct product callers found beyond resolver/re-export. Constructor/quota enforcer/CAS writer fixtures, not native put/quotas/overflow or deployed concurrency. Ownership history explicitly excluded from documented byte quota.
  Review: [next_review_storage](../next_review_storage/REPORT_RU.md).
- **SG-01 [P2; finding]: Unindexed job history and run-scoped job queries scan shared retained tables.** Unindexed job history and run-scoped job queries scan shared retained tables
  Доказательства: [тематический отчёт](../next_sql_growth/REPORT_RU.md); results.json:event_trials; results.json:job_trials; queries.json; DDL_COMPARISON.json. Ограничение: see primary report; bounded evidence does not establish operational incidence
  Review: [next_review_sql](../next_review_sql/REPORT_RU.md).
- **SG-02 [P2; finding]: Outbox page limit and frozen watermark do not bound SQL work.** Outbox page limit and frozen watermark do not bound SQL work
  Доказательства: [тематический отчёт](../next_sql_growth/REPORT_RU.md); results.json:outbox_trials; queries.json. Ограничение: see primary report; bounded evidence does not establish operational incidence
  Review: [next_review_sql](../next_review_sql/REPORT_RU.md).
- **SG-03 [P2; finding]: Already migrated store repeats intent scope census and Search delivery backfill.** Already migrated store repeats intent scope census and Search delivery backfill
  Доказательства: [тематический отчёт](../next_sql_growth/REPORT_RU.md); results.json:operation_trials; results.json:outbox_trials; SQL_CENSUS.json. Ограничение: see primary report; bounded evidence does not establish operational incidence
  Review: [next_review_sql](../next_review_sql/REPORT_RU.md).
- **SG-04 [P2; finding]: Lease candidate LIMIT 1 cost depends on planner and can include completed history.** LIMIT1 candidate work depends on planner/distribution: no-statistics fixture enumerates active backlog; independent ANALYZE at fixed active10 scans growing completed history too.
  Доказательства: [тематический отчёт](../next_sql_growth/REPORT_RU.md); results.json:lease_trials; queries.json:_lease_next_sqlite. Ограничение: see primary report; bounded evidence does not establish operational incidence
  Review: [next_review_sql](../next_review_sql/REPORT_RU.md).
- **SG-PG-01 [P3; qualification_gap]: PostgreSQL schema owner omits three SQLite secondary indexes.** PostgreSQL schema owner omits three SQLite secondary indexes
  Доказательства: [тематический отчёт](../next_sql_growth/REPORT_RU.md); DDL_COMPARISON.json; SQL_CENSUS.json. Ограничение: see primary report; bounded evidence does not establish operational incidence
  Review: [next_review_sql](../next_review_sql/REPORT_RU.md).
- **GR-04 [P3; measured_optimization_boundary]: Affected traversal still rematerializes complete target vector.** 5000-node leaf event builds 4999 rows. Thirty-five fixed-graph append-event cone experiments equal full vectors; cycles legitimately affect whole graph.
  Доказательства: [тематический отчёт](../next_graph_refresh/REPORT_RU.md); results.json#/full_resolver_scale; results.json#/event_append_prototype; results.json#/topology_change_controls. Ограничение: see primary report; bounded evidence does not establish operational incidence

**Acceptance пакета:** Native bounded before/after counters + equality; real CAS claims/query costs, SQL distributions/ANALYZE, migration/write/rollback/concurrency and PG separately. No production SLA inferred from synthetic sizes.

### R8. Исправить выбранные frontend state и wire contracts

Dependencies для integrated acceptance: R0. Single auth/origin generation owners; binary schema-generator agreement; textContent instead of HTML interpolation; semantic parity assertions cover all carried fields.

- **FE-01 [P2; finding]: Auth refresh has no generation fence and no rejected-fetch state transition.** Late token A refresh after clear or token B installation publishes authenticated A. Fetch rejection leaves status refreshing.
  Доказательства: [тематический отчёт](../next_frontend_contracts/REPORT_RU.md); boundary_probe_results.json. Ограничение: Injected logger/Vite config/window/document/fetch, Node24 type stripping; no real account/token/provider.
  Review: [next_review_frontend](../next_review_frontend/REPORT_RU.md).
- **FE-02 [P2; finding]: Generated raw artifact download parses successful bytes as JSON.** Actual downloadArtifactContent rejects CSV bytes with SyntaxError. Same client explicit arrayBuffer mode returns exact bytes. Generator prefers the schema default application/json over declared binary.
  Доказательства: [тематический отчёт](../next_frontend_contracts/REPORT_RU.md); boundary_probe_results.json; generator_modes.json. Ограничение: Synthetic Response, not HTTP/CAS/backend acceptance.
  Review: [next_review_frontend](../next_review_frontend/REPORT_RU.md).
- **FE-03 [P2; finding]: Reference shell interpolates API node alias into innerHTML.** Exact app.js creates an img/onerror attribute in the HTML sink from node alias instead of showing literal text.
  Доказательства: [тематический отчёт](../next_frontend_contracts/REPORT_RU.md); reference_source_results.json. Ограничение: Synthetic DOM records; Chromium launch blocked before page load.
- **FE-04 [P2; finding]: Reference shell late results overwrite a newly selected API origin.** After choosing origin B and rendering its run list, late origin A response replaces it while selected base URL remains B. Catalog proof alone checks state.client identity.
  Доказательства: [тематический отчёт](../next_frontend_contracts/REPORT_RU.md); reference_source_results.json. Ограничение: Actual app body/client with synthetic fetch and DOM writes, not browser.
- **FE-06 [P2; test_oracle_defect]: Authority MACHINE-twin parity ignores state and owner surface.** Exact checker returns passed=true after refused→supplied or owner_surface change; changed reason correctly fails.
  Доказательства: [тематический отчёт](../next_frontend_contracts/REPORT_RU.md); twin_parity_results.json. Ограничение: Type-erased source with synthetic DOM reader; actual backend currently supplies eleven refusals.
  Review: [next_review_frontend](../next_review_frontend/REPORT_RU.md).

**Acceptance пакета:** Node22 typecheck/build, genuine browser/DOM and actual backend caller/refresh profile; stale success/failure, binary/error/304 and markup negatives; no server bypass claim from client state.

### R9. Консолидировать только квалифицированные owners и primitives

Dependencies для integrated acceptance: R0, R2, R3. Failure-safe DAG tail ownership; explicit sync/async policy matrix; finite facades and read/build boundaries. Reuse graphlib/Core identity/entry points/local formatter, retain distinct estimands and domain admission.

- **AB-01 [P2; finding]: Fabric transform builder duplicates Core DAG mutable ownership.** Exact unchanged Core and Fabric definitions produce different dependency/order after branch callback raises after adding stages
  Доказательства: [тематический отчёт](../next_abstraction/REPORT_RU.md); primary report source/result references. Ограничение: Native imports, DataFrame outcomes, real consumer recovery frequency
- **AB-02 [P2; policy_parity_risk]: Scientist sync and async repeated preflight/finalization policies.** Two live builder routes; exact prefix replay invokes memory preparation only in sync; source-only selected research sidecar asymmetry
  Доказательства: [тематический отчёт](../next_abstraction/REPORT_RU.md); primary report source/result references. Ограничение: Full policy bypass, deployed incident, selected-workflow async sidecar regression
- **AB-03 [P3; legacy_compatibility_debt]: Legacy LangGraph public adapter and base dependencies.** Complete named Python census; langchain/langgraph both base declarations; synthetic provider demonstrates full-stream step and repeated effects
  Доказательства: [тематический отчёт](../next_abstraction/REPORT_RU.md); primary report source/result references. Ограничение: Real locked LangGraph integration, external users, dependency removal savings
- **AB-04 [P3; reuse_decision]: DataForge declarative asset scaffold versus actual batch orchestration.** Full named Python symbol census; inspected real catalog batch path is explicit and receipt-bound, not driven by asset decorator/planner
  Доказательства: [тематический отчёт](../next_abstraction/REPORT_RU.md); primary report source/result references. Ограничение: External users, all dynamic calls, native migration equivalence
- **AB-KEEP [P3; reuse_decision]: Existing owner-preserving reuse.** Inspected source chains reuse existing storage/iteration while domain owners retain semantic admission
  Доказательства: [тематический отчёт](../next_abstraction/REPORT_RU.md); primary report source/result references. Ограничение: Full native consumer execution; GenericRegistry exception-safety prerequisite remains from earlier audit
- **DA-01 [P2; architecture_debt]: Application ownership расположено под HTTP transport.** 147 quality→HTTP import statements from 26 selected modules: 31 TYPE_CHECKING,107 function-local,9 module-level; not 147 eager cycles.
  Доказательства: [тематический отчёт](../next_directory_architecture/REPORT_RU.md); boundary_probe_results.json. Ограничение: Selected source census, unresolved parsers; no runtime failure.
- **DA-02 [P2; architecture_debt]: DataForge read_api также exposes build operations.** Machine boundary calls API read-only while producer is reachable; README already documents not uniformly read-only.
  Доказательства: [тематический отчёт](../next_directory_architecture/REPORT_RU.md); boundary_probe_results.json. Ограничение: Not hidden side effect accusation or proof every read writes.
- **DA-03 [P2; architecture_debt]: Physical splits снова объединяют mutable namespace.** Scientist packet and Foundry facade backfill make split modules identity-sensitive, not independent abstractions.
  Доказательства: [тематический отчёт](../next_directory_architecture/REPORT_RU.md); boundary_probe_results.json. Ограничение: No particular installed failure; preserve useful facades rather than flatten.
- **DA-04 [P3; architecture_observation]: Orchestrator name обозначает presentation owner.** DecisionCard/lazy exports do not execute workflows; helper is useful, name obscures launcher.
  Доказательства: [тематический отчёт](../next_directory_architecture/REPORT_RU.md); boundary_probe_results.json. Ограничение: Not dead code, outage or permission for deletion.
- **NR-01 [P2; finding]: Provenance cycle verifier зависит от recursion depth.** Core provenance verifier recursion on 1200-edge DAG raises RecursionError, CLI2 without report; graphlib boolean adapter preserves normal DAG/cycle results and structured long-graph outcome.
  Доказательства: [тематический отчёт](../next_reuse/REPORT_RU.md); results.json#/results/provenance_public_verify. Ограничение: see primary report; bounded evidence does not establish operational incidence
- **NR-02 [P3; finding]: Shadow metric projection теряет полный путь.** Three typed DataForge shadow compares flatten dotted/nested metric keys onto same path and lose a changed metric; Ukraine typed counts do not admit that nested witness.
  Доказательства: [тематический отчёт](../next_reuse/REPORT_RU.md); results.json#/results/shadow_metric_diff. Ограничение: see primary report; bounded evidence does not establish operational incidence
- **NR-03 [P3; reuse_decision]: Reuse полного artifact-view identity key.** Four full artifact-view identity helpers agree on artifact ID, kind, media and manifest profile; existing Core primitive is reuse candidate, not authority/nominal DTO replacement.
  Доказательства: [тематический отчёт](../next_reuse/REPORT_RU.md); results.json#/results/artifact_view_identity. Ограничение: see primary report; bounded evidence does not establish operational incidence
- **NR-04 [P3; reuse_decision]: Reuse Core entry-point enumeration.** Existing Core entry-point enumeration agrees for real stdlib EntryPoint inputs across five selected modes, preserving ordering and error envelope; arbitrary impostors are not equivalent.
  Доказательства: [тематический отчёт](../next_reuse/REPORT_RU.md); results.json#/results/entry_point_reuse. Ограничение: see primary report; bounded evidence does not establish operational incidence
- **NR-05 [P3; reuse_decision]: Consolidate causal importance formatter.** Three causal feature-importance leaf formatters agree across seven boundary cases; estimator sensitivity, RNG and homogeneous-effect policy remain different owners.
  Доказательства: [тематический отчёт](../next_reuse/REPORT_RU.md); results.json#/results/feature_importance_projection. Ограничение: see primary report; bounded evidence does not establish operational incidence
- **NR-06 [P3; finding]: LRU nullable presence contract перед reuse.** LRU.delete removes stored None but returns false; other falsy values return true. Maintained NodeResultCache uses ArtifactRef and pop, so live nullable-delete incident not shown.
  Доказательства: [тематический отчёт](../next_reuse/REPORT_RU.md); results.json#/results/lru_reuse_prerequisite. Ограничение: see primary report; bounded evidence does not establish operational incidence
- **LIB-03 [P3; reuse_decision]: Weighted quantiles имеют три разных estimands.** Six weighted-quantile functions represent three estimands: midpoint interpolation, cumulative interpolation, inverse step CDF. Consolidate only after explicit method/policy choice.
  Доказательства: [тематический отчёт](../next_library/REPORT_RU.md); results.json#weighted_quantile. Ограничение: Whole estimators, native imports, all weighted-quantile consumers/census.
- **LIB-04 [P3; reuse_decision]: Сохранить выбранный AUC contract и refusal.** 150 finite/tied AUC controls agree with sklearn/rank adapter; preserve one-class refusal rather than new NaN and optional ML dependency. No defect asserted.
  Доказательства: [тематический отчёт](../next_library/REPORT_RU.md); results.json#roc_auc. Ограничение: Native monitor event/budget/registry flow and deployment-scale performance.

**Acceptance пакета:** Actual typed imports/FQN/object identities, import permutations and installed clients; failure/exception/recovery, optional-dependency policy and historical bytes/seeds preserved; no universal framework.

## 5. Сохранить действующие safeguards

- **G01. SQL lease/current-owner/commit fences:** Five synchronized lease races, stale-owner refusal, lease expiry before commit and process-death rollback. Domain intents/outbox atomic rollback also observed. Граница: SQLite selected owners; not PostgreSQL/distributed or all writers.
  Evidence: [next_lifecycle/sql_process_recovery_results.json](../next_lifecycle/sql_process_recovery_results.json), [next_state_owners/intent_transaction_results.json](../next_state_owners/intent_transaction_results.json).
- **G02. Closed runtime guards stop new calls:** Default-shaped shutdown closes store guard and denies new effects; already-running operations require separate settlement. Граница: Not physical thread termination.
  Evidence: [next_lifecycle/guarded_shutdown_results.json](../next_lifecycle/guarded_shutdown_results.json).
- **G03. Exact finalize and validity refusals:** Non-workflow/post-terminal recovery works; foreign/malformed journal refused. Malformed queued payload, wrong source attempt, changed HTE payload, corrupt dedupe and generic SEMANTIC_EPOCH refused. Граница: Does not repair lost selection or missing per-target event.
  Evidence: [next_review_finalize/REVIEW_RU.md](../next_review_finalize/REVIEW_RU.md), [next_review_delivery/REVIEW_RU.md](../next_review_delivery/REVIEW_RU.md).
- **G04. Budget unknown is fail-closed:** Same-run admission stays blocked by terminal unknown; native budget observer/ledger owners distinguish callback and physical completion. Граница: No overspend bypass; late known outcome reconciliation is unresolved in direct repeated-cancel branch.
  Evidence: [next_budget_authority/REPORT_RU.md](../next_budget_authority/REPORT_RU.md).
- **G05. N5 historical content is not live permit:** Fresh process historical read allowed, live reuse refused; self-consistent unissued marker refused; current SQL lease re-read rejects old owner after takeover. Граница: Positive genuine seal/revoke/PA2 terminal commit unrun.
  Evidence: [next_n5_revoke/REPORT_RU.md](../next_n5_revoke/REPORT_RU.md).
- **G06. Artifact ownership/profile/integrity retained:** Tenant/cell/profile checks, same-size/same-mtime corruption refusal, detached row copies and cross-instance current generation visible. Граница: Exact source/owner controls, not full authenticated API isolation.
  Evidence: [next_auth/authorization_boundary_results.json](../next_auth/authorization_boundary_results.json), [next_storage_scale/controls_results.json](../next_storage_scale/controls_results.json), [next_review_storage/REPORT_RU.md](../next_review_storage/REPORT_RU.md).
- **G07. Candidate status is not evidence authority:** Missing source/method gates, satisfied-method→limit, candidate-only scope/rights checks, fresh persisted descriptor tamper refusal. Граница: Compiler established or selected_exact does not imply admitted scientific support.
  Evidence: [next_review_domain/REPORT_RU.md](../next_review_domain/REPORT_RU.md), [next_review_evidence/REPORT_RU.md](../next_review_evidence/REPORT_RU.md), [next_review_growth/REPORT_RU.md](../next_review_growth/REPORT_RU.md).
- **G08. Publication owners fail closed:** Unappointed root, eligibility/currentness and custody/signer/mandate constraints remain. Private draft roundtrip fails before public issuance. Граница: Synthetic owner fixture does not provide real institutional authority.
  Evidence: [next_publication_authority/REPORT_RU.md](../next_publication_authority/REPORT_RU.md), [next_review_publication_dataflow/REPORT_RU.md](../next_review_publication_dataflow/REPORT_RU.md).
- **G09. Scientific source and selected ref guards:** Wrong profiles/missing diagnostics and wrong simulation/missing lineage refused; invented Scholar span rejected by actual source/Scientist verifier. Граница: Report/job complete or IR available is not scientific/institutional acceptance.
  Evidence: [next_review_cross_service/REPORT_RU.md](../next_review_cross_service/REPORT_RU.md), [next_review_research/REPORT_RU.md](../next_review_research/REPORT_RU.md).
- **G10. Existing meaningful tests and reuse boundaries:** Persisted corruption/removal tests exist; 19 real Node package tests ran under Node24. AUC selected finite/tie behavior agrees, quantile estimands intentionally differ, facades often legitimate. Граница: Authored tests are not fresh native PASS; Node24 not Node22; no universal replace-all libraries conclusion.
  Evidence: [next_test_confidence/contract_matrix.json](../next_test_confidence/contract_matrix.json), [next_review_frontend/REVIEW.json](../next_review_frontend/REVIEW.json), [next_library/decisions.json](../next_library/decisions.json), [next_structure/REPORT_RU.md](../next_structure/REPORT_RU.md).

Эти controls не отменяют findings. Они запрещают «ремонт» путём ослабления проверок, потери исторических доказательств, превращения unknown в success или candidate в authority.

## 6. Навигация checkpoint01–11

Checkpoint01: [план](../plan/PLAN_RU.md), [baseline](../baseline/BASELINE_RU.md), [recovery](../CHECKPOINT_RECOVERY_RU.md), прежний архив и [SYS/AUD crosswalk](PRIOR_CROSSWALK.json). Это первоначальная база и preliminary recovery, не новые native results.

### Checkpoint02

- [next_lifecycle/REPORT_RU.md](../next_lifecycle/REPORT_RU.md)
- [next_scaling/REPORT_RU.md](../next_scaling/REPORT_RU.md), [next_scaling/REVIEW_RU.md](../next_scaling/REVIEW_RU.md)
- [next_reuse/REPORT_RU.md](../next_reuse/REPORT_RU.md)
- [next_structure/REPORT_RU.md](../next_structure/REPORT_RU.md)

### Checkpoint03

- [next_freegrow/REPORT_RU.md](../next_freegrow/REPORT_RU.md)
- [next_auth/REPORT_RU.md](../next_auth/REPORT_RU.md)
- [next_native/REPORT_RU.md](../next_native/REPORT_RU.md)
- [next_catalog_scale/REPORT_RU.md](../next_catalog_scale/REPORT_RU.md), [next_catalog_scale/REVIEW_RU.md](../next_catalog_scale/REVIEW_RU.md)

### Checkpoint04

- [next_state_owners/REPORT_RU.md](../next_state_owners/REPORT_RU.md)
- [next_library/REPORT_RU.md](../next_library/REPORT_RU.md)
- [next_test_confidence/REPORT_RU.md](../next_test_confidence/REPORT_RU.md)
- [next_review_state/REVIEW_RU.md](../next_review_state/REVIEW_RU.md)

### Checkpoint05

- [next_directory_architecture/REPORT_RU.md](../next_directory_architecture/REPORT_RU.md)
- [next_domain_composition/REPORT_RU.md](../next_domain_composition/REPORT_RU.md)
- [next_storage_scale/REPORT_RU.md](../next_storage_scale/REPORT_RU.md)
- [next_review_storage/REPORT_RU.md](../next_review_storage/REPORT_RU.md)
- [next_review_domain/REPORT_RU.md](../next_review_domain/REPORT_RU.md)

### Checkpoint06

- [next_coverage_status/REPORT_RU.md](../next_coverage_status/REPORT_RU.md)
- [next_abstraction/REPORT_RU.md](../next_abstraction/REPORT_RU.md)
- [next_graph_refresh/REPORT_RU.md](../next_graph_refresh/REPORT_RU.md)
- [next_budget_authority/REPORT_RU.md](../next_budget_authority/REPORT_RU.md)
- [next_review_graph/REPORT_RU.md](../next_review_graph/REPORT_RU.md)

### Checkpoint07

- [next_delivery_chain/REPORT_RU.md](../next_delivery_chain/REPORT_RU.md)
- [next_evidence_composition/REPORT_RU.md](../next_evidence_composition/REPORT_RU.md)
- [next_frontend_contracts/REPORT_RU.md](../next_frontend_contracts/REPORT_RU.md)
- [next_review_evidence/REPORT_RU.md](../next_review_evidence/REPORT_RU.md)
- [next_review_delivery/REVIEW_RU.md](../next_review_delivery/REVIEW_RU.md)
- [next_review_frontend/REPORT_RU.md](../next_review_frontend/REPORT_RU.md)

### Checkpoint08

- [next_persisted_growth/REPORT_RU.md](../next_persisted_growth/REPORT_RU.md)
- [next_review_growth/REPORT_RU.md](../next_review_growth/REPORT_RU.md)
- [next_finalize_chain/REPORT_RU.md](../next_finalize_chain/REPORT_RU.md)
- [next_review_finalize/REVIEW_RU.md](../next_review_finalize/REVIEW_RU.md)
- [next_n5_revoke/REPORT_RU.md](../next_n5_revoke/REPORT_RU.md)

### Checkpoint09

- [next_publication_authority/REPORT_RU.md](../next_publication_authority/REPORT_RU.md)
- [next_registry_dataflow/REPORT_RU.md](../next_registry_dataflow/REPORT_RU.md)
- [next_review_publication_dataflow/REPORT_RU.md](../next_review_publication_dataflow/REPORT_RU.md)

### Checkpoint10

- [next_cross_service/REPORT_RU.md](../next_cross_service/REPORT_RU.md)
- [next_review_cross_service/REPORT_RU.md](../next_review_cross_service/REPORT_RU.md)
- [next_sql_growth/REPORT_RU.md](../next_sql_growth/REPORT_RU.md)
- [next_review_sql/REPORT_RU.md](../next_review_sql/REPORT_RU.md)

### Checkpoint11

- [next_research_chain/REPORT_RU.md](../next_research_chain/REPORT_RU.md)
- [next_review_research/REPORT_RU.md](../next_review_research/REPORT_RU.md)

## 7. Остаток плана и честные denominators

Исходный [PLAN_RU.md](../plan/PLAN_RU.md) не переписан задним числом. [Coverage status](../next_coverage_status/REPORT_RU.md) относится строго к checkpoint05 (19 отчётов), а не к этому срезу. Он содержит 48 plan IDs, 25 current roots, 8 обязательных цепочек. Текущая сводка добавляет later evidence, но не объявляет все строки этих карт заново проверенными.

Baseline: 29 934 tracked файла; current Python source denominator 2 895 `.py`, tests 3 752 `.py`. Исторические 8 555 Python/pyi, 1 340 TS/JS AST, 475 exact/592 normalized clone groups и 41 family disposition имеют разные scope. Поддерживаемый профиль ещё нужен для unresolved 3.14 syntax. Ни один из этих counts не является процентом semantic coverage, успешных тестов или готовности.

- **OPEN-01 (first_enabler):** Supported Python3.14/Node22/locks, actual OPA, selected native collection/execution, installed wheel/sdist origin and shipped policy object. Статус: UNRUN/BLOCKED in inspected profile; no assertion all environments unavailable.
- **OPEN-02 (first_correctness):** Full genuine producer→real persisted owner→fresh authenticated consumer for STATE-01/02; actual HTE basis, exact selection and complete target denominator. Статус: Owner/CAS/crash/ack layer deepened; native/full-engine/HTTP still partial.
- **OPEN-03 (first_correctness):** Genuine N5 positive seal→revoke→PA2→terminal commit, release/GC and repeated cancel direct/cached physical settlement; generic route admission matrix. Статус: Negative controls and lease bridge executed; full positive chain unrun.
- **OPEN-04 (first_semantics):** Native typed multi-intervention PolicySpec, scoped claim/data query/spec, actual resolver and method consumer; decide legacy scope contract. Статус: Strong local DC/EC discrimination; production producer scope and final selected method not established.
- **OPEN-05 (first_semantics):** Actual metadata author and admitted source→numeric occurrence→representation→Foundry input; Scholar policy adapter and genuine source gate; actual attractor diagnostic relation. Статус: Local persisted selected paths partly executed; native/physical/scientific/authority closure missing.
- **OPEN-06 (conditional_release):** Canonical/rendered/served policy parity, appointed publication/private draft codec and real mandate signature/currentness; full cell naming/Helm/Terraform/canary identity. Статус: Failure mechanisms plus fail-closed guards, not release qualification.
- **OPEN-07 (growth_correctness):** At least two genuinely admitted zero-code resources through persisted discovery→existing adapter execute→admit/refuse→served consumer/reopen, including stale/remove/same-count change. Статус: In-memory extension and selected persisted candidate path do not establish universal free-grow.
- **OPEN-08 (cost_after_contract):** Actual CAS claim/query multiplicity, request/transaction reads, SQL planner/distribution and migration controls, PG separately, history retention contract. Статус: Synthetic operation/byte/VM growth established; production workloads/SLA unmeasured.
- **OPEN-09 (targeted_UI):** Native Node22 typecheck/build, real browser and actual auth/backend/query/IDB paths; callers and security trust boundary for HTML sink. Статус: Module/script probes and Node24 suite, not deployed UI or XSS exploit.
- **OPEN-10 (owner_preserving_reuse):** Native nominal DTO identity/producer-spine/extraction and optional-provider numerical semantics; finite exports/FQN migration and sync/async preparation/finalization. Статус: Selected decisions only; all raw clone clusters not semantically adjudicated.
- **OPEN-11 (continuous_scope):** Fresh risk-based semantic trace for every still-uncovered root/port; update 48-plan/25-root/8-chain ledger, active docs/machine consumers and currentness; whole-source final hash check and self-contained packaging. Статус: Checkpoint05 ROOT/PLAN maps historical; current report is delta, not a new complete semantic census.

Не требуется бессмысленно повторять большой benchmark или все прежние maps. Следующее evidence должно закрывать точный отсутствующий producer/owner/consumer link либо опровергать сильную трактовку. Dependency DAG не запрещает параллельную source/design работу; он описывает условия окончательной integrated acceptance.

## 8. Правила будущего ZIP

1. Включить этот каталог и выбранные referenced тематические материалы byte-exact либо сопровождающие checkpoint ZIP01–11. Хэш без доступного файла не заменяет evidence.
2. Пути в report предполагают sibling `next_*`. Если ZIP navigation-only, явно приложить прежние архивы/receipt index; не выдавать локальные пути за публично доступные ссылки.
3. Пин исходников неизменен. Внешние GitHub ссылки на исходники должны использовать этот commit и проверенные source receipts; доступ к private repo нужен отдельно. Полный checkout, `.git`, caches и ненужные state corpora не копировать по умолчанию.
4. Сохранить raw failed attempts, fixture/adaptor descriptions и review corrections. Не переписывать исходные FINDINGS ради согласования сводки.
5. Перед финальной передачей проверить выбранные source bytes/full-baseline requirement, комплектность evidence, относительные ссылки и SHA256SUMS. Текущий validation не объявляет будущую упаковку проверенной.

**Итог:** подтверждённые локальные механизмы и ограниченные owner chains дают конкретную программу ремонта. Полный глубокий аудит, native/installed/deployed acceptance, научная/институциональная authority и remediation остаются открытыми.
