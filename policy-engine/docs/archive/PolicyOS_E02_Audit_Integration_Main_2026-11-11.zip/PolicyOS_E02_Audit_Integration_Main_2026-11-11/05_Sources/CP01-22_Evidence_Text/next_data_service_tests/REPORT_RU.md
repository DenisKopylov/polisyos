# CP20: data services, реальные stores и обязательность integration proof

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Read-only source. Этот срез дополняет `next_test_confidence`, `next_source_adapters`, `next_adapter_resilience`, `next_sql_growth`; не повторяет их дефекты. Дата: 2026-11-11 UTC.

## Итог

Нашлись **два новых разрыва между содержательными tests и воспроизводимой CI-проверкой**:

1. **DST-01, P2 qualification gap:** написанные real-PostgreSQL proofs не являются обязательными в checked-in CI. Восемь linearizability tests делают skip без DSN, драйвера или при ошибке connection/schema provisioning, если не установлен существующий mandatory flag. Ещё три cancellation definitions, пять статических параметризованных случаев, используют другой DSN и отдельный unconditional skipif. Ни один DSN и mandatory flag не назначены в 23 checked-in `.github` files. Standard Runtime HTTP выбирает эти файлы, но «выбран» не означает «проверен на PostgreSQL».
2. **DST-02, P2 reproducibility defect:** Standard Integration выбирает production-data tests без provisioning требуемого corpus. Восьми из девяти tests `test_data_state_substrate.py` нужны локальные production_data inputs. Эти данные ignored, не входят в полный pinned tracked snapshot и не materialize в объявленном workflow/setup. Exact path guard на pinned tree выдаёт `production_data_path_missing`. У tests есть полезные semantic assertions, но они не становятся hermetic integration только от размещения в integration directory.

Ни один вывод не является свежим результатом hosted CI, PostgreSQL, S3 или deployment. Никаких product edits, установки dependencies, внешних соединений, dispatch, миграций или cleanup реальных БД не выполнено. Общий аудит продолжается.

## 1. Какие owners действительно участвуют

Это не одна взаимозаменяемая «data service»:

- `core.artifacts`: content-addressed bytes, manifests и selected profiles; filesystem/S3/cache backends. Именно этот owner должен обеспечивать идентичность readback, а не SQL row count.
- `fabric.data_plane` + `fabric.ingestion`: source progress, chunks/windows, dedupe horizon, cursor/checkpoint и recovery поверх CAS. Source delivery guarantees отдельны от локальной durability.
- `fabric.storage.StoragePort`: simulation storage port; DuckDB adapter и тестовый memory adapter. Он не заменяет runtime authority store. В actual conflict consumers DuckDB adapter разворачивается обратно в SimulationDB, поэтому структурный protocol check не доказывает backend-neutral end-to-end behavior.
- `runtime.http.services.ControlPlaneStore`: relational heads, reservations, job lifecycle, outbox и optimistic revisions. PostgreSQL race semantics не следуют из SQLite run или CAS correctness.
- `runtime.quality.data_state_substrate`: DuckDB/Parquet/catalog inputs → persisted DataSnapshot + Data Forge binding → WorldModelRecord → Foundry compile/execute. Реальные source inputs, calibration regime и binding являются частью контракта запуска tests.

Подробная producer/consumer матрица с positives, negatives, substitutions и CI reach сохранена в `CONTRACT_MATRIX.json`. Не предлагается общий новый storage abstraction или перенос authority в cache. Сначала нужно соединить существующие тесты, provisioning и deciding gate.

## 2. DST-01: PostgreSQL tests хорошие, но их выполнение optional

### Реальный путь в написанных tests

`tests/unit/runtime/http/test_runtime_postgres_linearizability.py`:

- `:295–354`: два runtime app, два PostgreSQL store, общий scenario revision, barrier перед конкурирующими mutations; ожидаются один HTTP 200 и один 409; обе головы равны manifest hash победителя.
- `:357–406`: после удачного POST реальная SQL UPDATE портит authoritative head; следующий POST должен дать 503 `scenario_head_content_mismatch` **до OPA**. Это полезный независимый corrupt-input discriminator.
- `:409–475`: winner сохраняется через API; отдельно пишется unheaded CAS candidate с другим content identity; fresh app GET должен выбрать SQL head, не новый случайный CAS artifact.
- `:143–292`: separate connections и barrier проверяют one-use step-up и reservation CAS, включая generation 2 после recovery.
- `:478–541`: создаётся prior PostgreSQL schema, выполняется migration, unknown selected profile остаётся None, reopen сохраняет legacy head. Не выдумывать profile при migration.
- `:544–end`: concurrent acquisition frontier CAS: один winner/один typed conflict, одинаковый readback через оба stores и reopened store; loser head отсутствует; actual SQL versions содержат ровно revisions 1 и 2; stale revision/ref отдельно отвергаются.

Эти tests используют реальный SQL, но OPA/auth fixtures synthetic. Даже их успешный PostgreSQL run не был бы proof внешнего identity provider, actual OPA policy или deployed serving state.

`test_control_cancel_postgres.py` дополняет producer→store→verified-record путь: cancellation/progress/completion races, retry reconciliation, фактически наблюдаемый `pg_stat_activity.wait_event_type = 'Lock'`, а не просто sleep-based совпадение. Stale loser не должен менять terminal state. Этот тестовый корпус стоит сохранить.

### Что происходит в absence path

Fixture `postgres_dsn:45–87` уже содержит правильный enforce mode: `POLISYOS_DS9_REQUIRE_PG=1`. Exact-body probe проверил шесть combinations:

| Условие | Без mandatory flag | С mandatory flag |
|---|---|---|
| DSN отсутствует | skip | fail |
| psycopg отсутствует | skip | fail |
| connection/schema setup error | skip | fail |

`pytest.skip/fail` заменены только различающими sentinel exceptions; импорт драйвера/connection failure synthetic, ни одна сеть не открывалась. Fixture body не переписан. Эта проба доказывает control flow, **не PostgreSQL availability или race correctness**.

Cancellation module `:23–24` независимо делает `skipif(not _DSN)` для `POLISYOS_TEST_C57_DISPOSABLE_PG_DSN`; DS9 flag на него не влияет. Два exact assignment controls подтверждают этот switch. Просто добавить только DS9 flag недостаточно, чтобы требовать оба корпуса.

`ci.yml:16–42` запускает HTTP root с runtime profile. `pyproject.toml:136–142` помещает psycopg в `multi-tenant`, не в runtime; bootstrap `_common.py:57–62` даёт runtime = lint + test + runtime. В checked-in `.github/**` отсутствуют оба DSN, DS9 flag, `multi-tenant` и PostgreSQL provisioning. Присутствие пакета в lockfile не является его установкой в выбранный profile.

Нативные executions не восстановлены из факта наличия тестов. Все 3 752 `.py` под tests перечислены для literal named-DSN census; только два вышеназванных файла используют эти DSN. Это не глобальное доказательство отсутствия иных PostgreSQL tests с другими именами или внешней автоматизации.

### Почему summary не закрывает этот gap

На synthetic JUnit с 13 skipped cases unchanged `report_test_economics.py` успешно сообщает **Total skipped: 13**, exit 0. Это ожидаемое поведение report-only инструмента, а не его самостоятельный bug. Для Python 3.12 пришлось обойти только `tools.lib.__init__`, чей импорт fs.py содержит Python 3.14 syntax; report и leaf imports.py исполнены без изменения. Исходная native import failure сохранена отдельно.

Точный Standard gate shell принимает synthetic all-success job statuses и отвергает failure. Он не получает PostgreSQL test verdicts отдельно. Вместе source wiring и bounded controls показывают отсутствие required receipt, **но не воспроизводят целиком зелёный hosted workflow**. В workflow могут быть другие failures, например уже известный TC-03 OPA provisioning gap.

### Исправление и deciding gate

- Добавить к существующей CI system dedicated disposable PostgreSQL service/version, health check, `multi-tenant` dependencies и существующий DS9 mandatory flag. Явно исполнять оба корпуса с JUnit.
- Нельзя направлять cancellation tests на общий dev/prod DB: они требуют dedicated disposable database и не используют DS20 fixture schema isolation. Переиспользовать один per-test/schema fixture owner или задавать строго отдельную disposable DB; проверить xdist/concurrent-job isolation перед parallelization.
- Проверять expected node IDs/parameter cases, backend identity и **zero environment-blocked skips** для required lane. Отсутствие report/driver/DSN/health должно ломать deciding gate; обычные developer runs могут сохранить opt-in skip.
- Negative CI controls: удалить DSN, убрать psycopg, остановить service, удалить один required test из collection. Каждый случай обязан дать fail, не green и не отчёт с нулём executions.
- После этого прогнать existing one-winner, stale-generation, corruption, fresh-app, rollback/loser-artifact и legacy migration cases на supported Python 3.14. Требование «13» здесь относится к текущим 8 + (2+1+2) source-declared cases; native collected denominator надо записать и проверять, а не считать статическую арифметику collection evidence.

## 3. DST-02: настоящая data integration зависит от невыданных inputs

`tests/integration/runtime_quality/test_data_state_substrate.py` содержит девять definitions. Первый registry-discovery test строит fixture registry и не требует corpus. Остальные восемь используют defaults rooted в `REPO_ROOT / production_data`, без opt-in marker или отдельного fixture provision.

Наиболее реалистичный producer-consumer example: `test_real_l4_data_state_builds_populated_world_model_record_and_executes_sim` (`:398–441`) вызывает настоящий builder, пишет CAS-backed world/model/binding records, затем `compile_foundry` и `execute_foundry`. Он проверяет >8 000 000 input rows, sample=128, populated agents/income и non-null simulation result. Остальные tests проверяют content stability/different slice, reuse exact registry без rebuilding, proxy-vs-point widths, stratification, unavailable variable/empty slice и unregistered family. Это существенно сильнее DTO/marker tests.

Но producer сначала требует six existing files: L1 dataset_catalog.duckdb; agent registry, firm fundamentals и budget flows parquet; corrected firm panels и household cells parquet. Exact default resolver и `_require_paths:5131–5146` исполнены на неизменённом snapshot с отсутствующим active serving source. Все шесть путей отсутствуют; первый refusal = `production_data_path_missing`. Положительный existence-only control с шестью scratch files проходит этот guard. Файлы намеренно не содержат валидные данные: **это только проверка predicates, не fake successful materialization**.

Полный snapshot не sparse: baseline зафиксировал 29 934 tracked files, ни submodules, ни symlinks. `/production_data/` excluded `policy-engine/.gitignore:20`; tracked tree не содержит этого каталога. Чтение `.github` и actual bootstrap path не нашло input download/mount/materialization или selection такого corpus. Standard Integration `ci.yml:240–268` использует ordinary ubuntu runner + checkout + runtime setup, затем integration marker с HTTP exclusion. Нет quarantine для выбранного файла. Fresh hosted runner contents не inspected; следовательно вывод точный: **checked-in job не объявляет необходимого input contract**, не «доказан сегодняшний красный CI run».

### Исправление и deciding gate

- Разделить purpose, не подменять real test fake fixture незаметно. Hermetic small DuckDB/Parquet corpus должен упражнять тот же producer, CAS persistence, selected consumer и negatives в обычном PR.
- Existing large real-corpus qualification вынести в явную required-for-that-claim lane с pinned input manifest/hashes, physical readable paths, calibrated registry identity и provenance. Нельзя утверждать 8-million-row qualification на маленькой fixture.
- Reuse существующих source-owner split-root и workspace confinement helpers. Input read-only, outputs в caller-owned directory. Не копировать production corpus в каждый worker и не делать blanket skip как «исправление».
- Data gate до pytest: manifest/version readable, обязательные files, expected schemas, admission of selected corpus. Missing/wrong-hash/malformed/empty inputs должны ломать требуемую qualification с различимым кодом; ранее admitted valid corpus должен пройти producer→CAS→fresh consumer.
- Сохранить positive/negative oracles: same input same identity, changed slice changed identity, pinned registry no rebuild, proxy width не превращается в point, no variable/no family refusal. Добавить fresh-process selected readback и removal of exact bound profile/source witness; не использовать только count >0.

## 4. Реальные bounded storage tests уже есть: что переиспользовать

- `test_streaming_crash_resume_native.py`: 41 synthetic JSONL rows, SIGKILL после committed row 19, reopen и exact windows/chunk contributors; independent expected window oracle. Removal test с отключённым operator restore обязан сломать recovery oracle. Это meaningful local filesystem/CAS+process proof в написанном test, не external connector delivery guarantee.
- `test_source_progress_processes.py`: два OS processes, exact injected UTC 86 399/86 400 seconds, independent dedupe horizon readback. Это семантика часов, не реально прошедшие сутки или soak SLA.
- `test_storage_port.py`: настоящий DuckDB transaction rollback и memory rollback/query; `test_duckdb_storage_access_control.py`: no-scope refusal и actual two-tenant row filtering. Полезные minimum contracts, но не доказательство взаимозаменяемости всех consumers или PostgreSQL isolation.
- `test_s3_store.py`: fake S3 client, при этом хорошие distinguishing controls: tampered bytes, malformed profile before I/O, missing object vs missing bucket, ambiguous 404 bucket verification, permission/transport error identity, selected-profile mismatch. Fake client моделирует IfNoneMatch semantics, но не проверяет actual provider conditional writes, network failure или cross-process namespace persistence.
- `test_redis_lock.py`: mocked Redis, heartbeat disabled. Проверяет owner token перед Lua request, acquire/release/error behavior. Он не исполняет Lua на Redis и не квалифицирует TTL/heartbeat/expired-holder races. Release workflow явно запускает этот файл; это не live Redis acceptance.

Для S3/Redis в этом срезе **не установлено отсутствие любого real-provider test во всём репозитории**. Это qualification boundary именно названных тестов и checked-in CI declarations. Не создаётся отдельный defect count за каждый mock.

## 5. Evidence и ограничения

- `probe_data_services.py`: 6 PG branch controls + 2 cancellation marker controls + 2 existence controls + compatibility-assisted JUnit summary + 2 exact aggregate shell controls. Final exit 0. Оригинальная report import failure сохранена, не скрыта.
- `TEST_INVENTORY.json`: 9 подробно прочитанных файлов, 52 source-defined tests, parametrization не развёрнута. Их product bodies **не запускались**.
- `CENSUS.json`: 3 752 named test files, 23 named `.github` files; literal searches и явные unresolved boundaries. Это не coverage percentage и не pytest collection.
- `SOURCE_VALIDATION.json`, `source_excerpts.json`, `INPUT_MANIFEST.json`, `SHA256SUMS.txt`: pinned bytes, loci, prior crosswalk и проверка поставленного evidence.
- Host Python 3.12, нет pytest/psycopg/duckdb. Supported native Python 3.14 tests, installed package, real PostgreSQL/S3/Redis, large data corpus, HTTP+actual OPA и deployed observation **UNRUN**.

Предпочтение ремонта: **wire existing tests and fixture owners → extend explicit backend/input gate → consolidate only duplicate fixtures**. Новый data-service framework или общий «универсальный тест» без real consumer proof здесь не нужен.
