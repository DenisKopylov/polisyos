# Policy alternatives → constraints → normative choice

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`, read-only. Продолжение checkpoint15, выбран прежде не исполнявшийся normative arbitration workflow. **Итог PARTIAL: один подтверждённый semantic finding DP-01; native/full-engine/authority acceptance не выполнены.**

## Результат сразу

**DP-01 (P2, high confidence для выполненного consumer): содержательно нулевые utility terms меняют социальный вес и выбранную альтернативу; явный нулевой вес заменяется единицей.** Реальные typed inputs → `RunNormativeArbitrationNode.execute` → настоящий CAS/IR owner → новый процесс → `NormativeArbitrationPass` воспроизводят оба эффекта. Неизменные индивидуальные utilities `workers=+1`, `owners=−2` сначала дают weighted welfare `−1 / baseline`; добавление workers двух terms с `coefficient=0` даёт `+1 / proposal`, поскольку вес workers растёт с 1 до 3. Реальный helper последующего governance меняет промежуточный verdict с `needs_revision` на `approve`.

Ни `proposal`, ни `complete`, ни это промежуточное `approve` не устанавливают causal identification, законность, institutional authority или publication. Проверенные hard-right/budget blockers сохраняются; `reject` и `human_gate` не перезаписываются. Missing uncertainty и missing budget сохраняют `partial`; проверенный Phase2 tail их блокирует. Полный защищённый путь не запускался.

## 1. Что действительно выполнено

`probe_decision.py` исполняет настоящий node, не арифметическую копию:

1. Строгие `ProblemFrame`, `NormativeFrame`, `StakeholderUtilityTerm`, `StakeholderRightSpec`, `ConstraintSpec`, `TrinityBundle`, `Metrics`, `ExperimentState`.
2. Настоящие `build_default_registry_bundle`, `RunContext.start`, `ExecutionContext`, `FileSystemCAS`. Trinity и metrics сохраняются с их настоящими kind/media/schema metadata и читаются самим node.
3. В node исполняются binding resolution, utility aggregation, rights/hard constraints, четыре политики, dissent, completeness, typed result construction, persistence и state branching. Выходные CAS refs и inputs сохранены в `retained.json` и `results.json`.
4. `probe_reader.py` в отдельном процессе заново читает persisted results и вызывает настоящий `NormativeArbitrationPass`. Затем исполняет неизменённые целые governance helper functions, извлечённые из source: persisted loading, verdict composition и Phase2 tail. **Это не полный RunGovernanceNode, все judges или engine attempt admission.**
5. `probe_legal_boundary.py` дополнительно сравнивает actual arbitration node при отсутствующем, blocker-bearing и malformed legal report. LegalReport fixture синтетический; реальный закон или внешняя институциональная оценка не предоставлялись.

Метрики и группы намеренно синтетические. `PolicySpec` имеет пустой список interventions, а ModelSpec содержит placeholder data ref, который этот node не использует. Это допустимый typed вход для арифметического differential, но не grounded causal policy или executed simulation. Из предыдущего method-execution среза не импортировалась научная оценка как будто она уже authority.

## 2. DP-01: нулевой вклад меняет решение

**Locations:** `scientist/nodes/builtins/governance/normative_arbitration_calculations.py:283–350,500–578`; контракт `ir/governance/problem_frame.py:246–255`.

`_compute_stakeholder_utilities` отдельно суммирует коэффициентные utility contributions и отдельно суммирует `term.welfare_weight`. Затем `_policy_evaluation_summary` перемножает оба итоговых числа. Получается `(Σ utility_term) × (Σ term_weight)`, а не композиция независимых weighted contributions. Даже term с нулевым coefficient добавляет вес ко всем остальным contributions того же stakeholder.

Различающие cases из `results.json#/cases`:

- `ordinary_negative`: workers utility 1, weight 1; owners utility −2, weight 1. Weighted delta −1, `baseline`.
- `zero_effect_term_added`: ещё два workers terms `coefficient=0, welfare_weight=1`. Индивидуальные utilities не меняются; workers weight становится 3. Delta +1, `proposal`. Model `complete`, warnings пусты.
- `zero_effect_term_reversed`: перестановка terms/bindings даёт тот же результат. Это не last-row-order defect.
- `split_equivalent_term`: замена одного unit coefficient на три Decimal thirds сохраняет вычисленную utility 1, но даёт weight 3 / `proposal`. Основное доказательство не зависит от округления thirds: zero-coefficient control точный.
- `zero_weight`: workers utility +3 при **явном** welfare_weight 0; owners −2. Producer сохраняет effective workers weight 1, delta +1 / `proposal`.
- `tiny_positive_weight`: тот же input с weight 0.000001 сохраняет 0.000001 и даёт delta −1.999997 / `baseline`. Нулевой вес не проходит ожидаемый предельный/нейтральный контроль.

Причина второго случая: local weight начинается с 1, а accumulator подставляется только при `>0`. NonNegativeDecimal явно допускает 0. Это не только недостающая валидация отрицательных чисел.

**Реальный downstream impact в исследованной границе:** сохранённые результаты без mutation прочитаны новым процессом; NormativeArbitrationPass сообщает обычный dissent либо rejection, но не замечает arithmetic inconsistency. Извлечённый `_resolve_governance_verdict` на настоящих output/issue rows выдаёт `needs_revision` для baseline и `approve` для нулевых additions. `lexicographic_rights` также использует тот же weighted delta после отсутствия hard violations. Max-min/Pareto сохраняют independent utility semantics и демонстрируют dissent, а не исправляют default selection.

**Минимальное направление:** исправлять существующего utility aggregation owner. Явно определить, является ли weight свойством терма или stakeholder. В первом случае применять его к соответствующему term, во втором хранить/разрешать один согласованный stakeholder weight, не суммировать его за число terms. Сохранять явный ноль; не заменять его default. Нулевой coefficient не должен менять вклад остальных terms. Не удалять hard rights/constraints для stakeholders с нулевым welfare weight.

Acceptance: zero-coefficient addition, equivalent term splitting, zero/tiny/positive weights, term order, несколько binding_refs, разнонаправленные contributions, сохранение rights и hard constraints, node→CAS→fresh consumer→governance verdict. Это один arithmetic/semantic-composition finding с двумя discriminators, не две новые SYS-семьи и не повтор уже проверенного Scholar support-weight consumer.

## 3. Constraints, uncertainty и conflict resolution

17 actual-node cases; 16 persisted results, один explicit governed refusal. Все deciding assertions прошли.

- `rights_block`: negative worker impact и hard right `delta>=0`. Lexicographic policy выбирает baseline; normative pass даёт blocker; governance helper даёт reject.
- `budget_block` / `budget_equal_threshold`: 11 при cap 10 блокируется; ровно 10 проходит. Weighted policy может иметь другой preference, но hard audit/consumer остаётся отдельным blocker.
- `budget_missing`: absent metric сохраняет `unevaluated`, warning и `partial`. Lexicographic candidate всё ещё proposal; intermediate governance helper approve. Phase2 tail отказывает по incomplete model/warnings. Это явно отмеченный advisory limitation, не установленный fail-open protected action.
- `uncertainty_missing`: обязательный right с channel `uncertainty_ci_width_ratio`, но отсутствует simulation result ref. Реальный no-ref branch выдаёт `simulation_result_ref_missing`, отсутствующее значение и unevaluated right, result partial. Phase2 tail блокирует. Успешная source-bound uncertainty admission и numerical CI producer здесь **UNRUN**.
- `metrics_missing`: нет значений для utility bindings; warnings и partial, selected indeterminate; governance needs_revision.
- `governed_missing_frame`: actual node возвращает fail и ERROR_INVALID_STATE, не включает legacy synthesis.
- `tie_epsilon_at` / `tie_epsilon_over`: fixed threshold `1e-9` даёт indeterminate на границе и proposal чуть выше. Это подтверждение фактического numerical tie contract, не scientific uncertainty calibration.
- Во всех fresh-reader cases synthetic independent ComplianceIssue BLOCKER сохраняет reject; уже заданные reject/human_gate не превращаются в approve.

В `reader_results.json` некоторые complete results проходят **только выбранный Phase2 helper** при synthetic judge payload с `composite_decision=promote` и шестью именами. Этот fixture не является запуском judges или выдачей authority. Полный run_governance содержит дополнительные currentness, claim projection, invocation и protected-action boundaries.

## 4. Законность и причинная связность: предел сделанного

Реальная workflow проводка существует: `default.py`, `policy_design.py`, `policy_verified.py`, `causal_full.py` содержат normative node и последующий governance. В `policy_verified.py:155–175` нормативный шаг зависит от legal_check, uncertainty propagation, distributional analysis и causal evaluation.

Однако scheduling dependency не равна semantic verification. Actual normative node вызывает `_load_legal_report` (`run_normative_arbitration.py:213`), но не использует возвращённое содержимое. Его own audit оценивает declared rights/metrics constraints, не подтверждает legal claim/source relation. В legal differential:

- missing report, persisted legal blocker и malformed report дают один выбор proposal/complete;
- legal ref записывается в provenance и manifest inputs даже при parse failure;
- malformed report вызывает настоящий degraded-path log, но не normative warnings.

Это **DP-O1, scoped observation**, не новый confirmed legality bypass: `NormativeArbitrationResult` прямо говорит, что не предоставляет institutional/legal authority; Lex legal-authority owner имеет отдельные claim/source, jurisdiction и temporal требования. Ref в provenance нельзя повышать до «legal evidence verified». Полный Lex/governance pipeline и final/public decision не запускались, поэтому нельзя ни заявить обход, ни зачесть покрытие законности целиком.

Аналогично `simulation_metric` читает persisted `Metrics` как численный input; этот node не доказывает, что значение является `P(Y|do(X))` или истинной causal delta. Baseline в данном comparison contract устанавливается равным 0. Пробы используют synthetic deltas, поэтому не объявляют zero baseline ошибкой для произвольных level metrics. Необходимый следующий integrated acceptance: genuine admitted causal/distributional source, lawful claim-level evidence, exact policy/estimand/time/units bindings, альтернативы с несовместимыми scopes и отказ при удалении каждого binding.

## 5. Переиспользование и тестовая уверенность

Существующие owners полезны и не требуют нового параллельного subsystem:

- IR `NormativeFrame` и persisted `NormativeArbitrationResult` сохраняют typed vocabulary и mixed audit statuses. Исправление арифметики должно жить рядом с `_compute_stakeholder_utilities`, а не в новом ranker/report rewriter.
- `NormativeArbitrationPass`, ordinary governance composition, Phase2 tail и независимые Lex/causal authority boundaries следует сохранить раздельно. Warning/selection нельзя превращать в универсальное admission свидетельство.
- `core/evaluation/mcda_robustness.py` уже предоставляет dependency-light многокритериальную ranking/weight-uncertainty библиотеку. Её normalized criterion weights и stakeholder meta_weights не являются готовым drop-in для rights-based normative aggregation: различаются unit/axis/weight semantics, laws и purpose. Повторное использование допустимо после typed adapter и invariance tests; переносить legacy normativity в эту библиотеку ради DRY не следует. MCDA execution в этом срезе не проводился.

Selected test census сохраняет полные имена четырёх релевантных test files и их test functions, не процент покрытия репозитория. Существующие tests проверяют обычные weighted utilities, rights, mixed unevaluated statuses, schema refusal, persisted pass и governance integration. В выбранных tests не найден distinguishing zero-weight/zero-coefficient composition control. **Исходные pytest bodies не запускались**; pytest отсутствует. Выполнены отдельные audit scripts с independent metamorphic assertions, а не заявлен green suite.

## 6. Native и воспроизводимость

Native import на Python 3.12 останавливается на разрешённом для project Python3.14 multi-except syntax в `core/artifacts/store.py:2155`. Это tooling mismatch, не failure поддерживаемого product profile. Existing compatibility loader адаптирует только multi-except syntax и TypeVar default; `typing.get_protocol_members` берётся из typing_extensions. Точные hashes/rewrites сохранены.

Полный compatibility import затем останавливается на missing JAX через `uncertainty_source_projection`. Для actual normative node исполняется целый calculation module без этого одного import. Символ `load_science_simulation_result_uncertainty_admission` остаётся **unbound**, success stub отсутствует; проверен только реальный no-simulation-ref branch. Native Python3.14/dependency-locked и successful uncertainty admission остаются UNRUN.

Harness ошибки сохранены отдельно: float threshold вместо Decimal, повтор `RunContext.start` с существующим lifecycle ID и unresolved forward annotation в extracted Pydantic classes. Исправлены только audit scripts; production bytes не менялись. Итоговые `probe`, `reader`, `legal`, validation exit=0. Исходники сверены с pinned Git objects; артефакты и manifest содержат command/evidence boundaries.
