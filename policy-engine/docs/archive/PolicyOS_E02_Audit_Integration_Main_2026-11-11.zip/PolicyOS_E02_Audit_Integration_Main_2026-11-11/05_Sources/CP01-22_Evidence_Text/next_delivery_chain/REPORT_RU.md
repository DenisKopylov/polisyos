# WP-02: generic invalidation через реальные CAS и originating HTE outbox

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Read-only аудит, 10 ноября 2026. Это **усиление STATE-02**, а не ещё один независимый дефект. Исследуемый delivery invariant нарушен; native/full-engine qualification остаётся **PARTIAL**.

## Результат

Прежний source-only вывод об originating acknowledgement теперь воспроизведён исполняемым локальным маршрутом: настоящий SQL `complete_job` сохраняет завершение и HTE outbox, настоящий generic Scientist owner пишет в FileSystemCAS, настоящий Runtime delivery consumer затем подтверждает исходный outbox, хотя часть зависимых packets не получила invalidation.

- **Ошибка до второго packet-state write:** первый target STALE, второй ACTIVE. Первый delivery оставляет outbox pending. Новый Python process открывает ту же SQLite/CAS пару, повторяет actual reconciliation, записывает notification с `{stale: 1, active: 1}` и ставит originating outbox `published`. Принудительный настоящий recompute второго packet тоже оставляет ACTIVE: sticky event отсутствует, replay подавлен dedupe.
- **Процесс завершён сразу после durable dedupe:** `os._exit(73)` без исполнения `finally`. Новый процесс получает оба targets ACTIVE, notification `{active: 2}`, originating outbox `published`. Принудительное вычисление не восстанавливает потерянный event. Это локальный fault injection, не наблюдавшийся production incident.
- **Sibling `mark_packet_trigger`:** тот же порядок dedupe-before-apply воспроизведён с настоящим CAS. Ошибка до packet write, новая owner instance, exact retry и force recompute оставляют ACTIVE без sticky trigger. Sibling restart здесь в том же процессе, в отличие от основного HTE маршрута.

Основной probe выполнил 10 сценариев × 3 свежих процесса. В crash-сценарии первый процесс ожидаемо завершился с 73; остальные 29 фаз завершились с 0. Все evaluation refs повторно прочитаны через реальный CAS и проходят `FileSystemCAS.verify`. Target denominator ограничен двумя явно зарегистрированными packet refs на сценарий, это не перепись production dependencies.

## Что стало реальным, а что ещё нет

**Без подмены bodies и persistence:**

- Полные модули `FileSystemCAS`, `DecisionValidityService`, `_DecisionValidityStateStore`, `ControlPlaneStore`, их constructors, CAS layout/manifests/blob/hash reads, filesystem owner lock и атомарные JSON writes, SQLite schema/transactions.
- `create_job → lease_next_job → complete_job`, immutable terminal source event, typed selection validation, originating HTE outbox insertion. SQL job не создаётся прямым INSERT.
- Полный `register_decision_packet → _register_dependencies → _persist_evaluation`, реальный CAS baseline и packet payload; generic `record_dependency_event`, `_apply_event_to_packet`, computation, sticky events, lifecycle jobs и transitions.
- Выбранные неизменённые тела Runtime: owner-derived request, stable dedupe/event ID, bounded reconciliation, queued JSON wire validation, generic publication/notification и originating ack. Настоящие request/response DTOs и `_build_api_meta`.
- Каждый main fault/retry/force запускается отдельным Python subprocess. Процесс открывает owners заново; передача Python object state между фазами отсутствует.

**Явные границы:**

1. **Python 3.14 недоступен:** `python3.14` не найден, source `.venv/bin/python` отсутствует, baseline требует 3.14. Обычный import на имеющемся 3.12.14 завершился SyntaxError в `core/artifacts/store.py:2155`. `native_import.*` и `ENVIRONMENT.json` сохраняют точный blocker. Install/sync/network не выполнялись.
2. Audit loader компилирует source **только в памяти**: добавляет скобки к новому multi-except syntax и использует установленный `typing_extensions.TypeVar` для поддержки `default=`. Записаны все 15 адаптаций загруженных 158 source modules. Runtime extraction отдельно нормализует новое multi-except syntax. Eager initializers некоторых верхних packages заменены namespace packages, в том числе `runtime.quality`, чтобы не импортировать отсутствующий DuckDB и unrelated subsystems. Это не normal imports, не установленный package и не locked/native pass.
3. Численный HTE producer не запускается. Typed `DirectMethodExecutionSelection` построен **неизменёнными constructors из существующего repository test fixture**. Его HTE outcome/anchor/input refs синтетические и не разрешаются в CAS. SQL owner действительно принимает и сохраняет этот контракт, но это не доказательство полного provenance HTE результата.
4. Packet payloads содержат реальные `DecisionValidityEnvelope` и `DecisionValidityEvaluation`, записаны как `scientist.decision_packet`, зарегистрированы настоящим owner. Полный DecisionPacketBuilder, owner-selected completed-HTE association и publication authority не вызваны. Это generic ECONOMETRIC_EVIDENCE targets с HTE dependency key, не две реально опубликованные policy signatures.
5. `ControlPlaneService` целиком не конструируется: извлечены только выбранные Runtime методы с настоящими collaborators. HTTP/authenticated route, external notifications, RunIndex endpoint, PostgreSQL, hard power loss и distributed deployment не проверены.

## Матрица различающих результатов

`results.json` хранит initial/first/retry/force state, packet/evaluation refs, transitions, exact originating row и SQL notification payloads.

| Fault point / control | После fresh-process retry | После force | Originating ack |
|---|---|---|---|
| Normal | STALE / STALE, по одному transition | STALE / STALE | published, 1 notification |
| До второго sticky packet write | STALE / ACTIVE, transitions 1 / 0 | STALE / ACTIVE | **published**, partial notification |
| После второго sticky packet write | STALE / ACTIVE, transitions 1 / 0 | STALE / STALE, transitions всё ещё 1 / 0 | **published** до force |
| До второго CAS evaluation put | STALE / ACTIVE, sticky второго уже сохранён | STALE / STALE, transition второго не восстановлен | **published** до force |
| Process exit после dedupe | ACTIVE / ACTIVE, transitions 0 / 0 | ACTIVE / ACTIVE | **published**, active notification |
| До dedupe write | STALE / STALE | STALE / STALE | published после полного replay |
| Перед notification enqueue | STALE / STALE, без новых transitions | STALE / STALE | published, 1 notification |
| Перед originating ack | STALE / STALE, прежняя notification reused | STALE / STALE | published, 1 notification |
| Malformed queued payload | ACTIVE / ACTIVE | ACTIVE / ACTIVE | pending, payload_invalid |
| Source attempt mismatch | ACTIVE / ACTIVE | ACTIVE / ACTIVE | pending, source_not_established |

Force намеренно сильнее простого ожидания TTL: заставляет текущий owner прочитать packet и пересчитать evaluation. Оно не превращает отсутствующий sticky event в имеющийся. Если sticky state уже записан, именно force восстанавливает STALE; это важный контрпример универсальному утверждению «каждый partial failure навсегда сохраняет ACTIVE». Projection до force реально читает старый CAS evaluation. Автоматический вызов force/TTL scheduler не доказан.

`probe_sibling_controls.py`, exit 0, дополнительно:

- Generic SEMANTIC_EPOCH отказывает `semantic_epoch_dependency_requires_owner_batch` до записи dedupe; его batch protocol не опровергнут.
- Malformed durable dedupe вызывает owner-state-corrupt, сохраняет originating pending и не создаёт notification.
- Неизменённая существующая test function `test_completed_hte_validity_page_is_topic_scoped_and_freezes_arrivals` пройдена на реальной SQL schema: 30 HTE rows, 260 посторонних, late arrival не входит в frozen page. Это прямой вызов test function, не pytest collection/lane.

## Почему это тот же STATE-02

`scientist/validation/decision_validity.py:1950–1993` сохраняет dedupe до fanout и при повторе только вызывает `ensure_evaluation`. Lock не откатывает files. `_apply_event_to_packet:2041–2110` отдельно сохраняет sticky state, CAS evaluation и transition. `mark_packet_trigger:1995–2027` имеет тот же ранний dedupe.

`runtime/http/services/control/run_lifecycle.py:13881–13966` корректно пересобирает request из exact SQL source и selected typed contract; `14036–14095` строго проверяет queued payload. Эти защиты не проверяют completeness Scientist fanout. `15429–15474` принимает возвращённые evaluations и пишет SQL notification, после чего `14082–14088` подтверждает originating delivery. Неполное применение event не является exception при dedupe replay, поэтому guards корректно подтверждают транспортную identity и всё же пропускают неполное dependent state.

Новая сила evidence: ack уже не только source-supported, CAS уже не fixture, packet-state/application/computation уже не extracted частичная имитация, restart не same-process reopen. Остаток: native runtime и реальный HTE/full-packet producer остаются неквалифицированными. Не нужно повышать severity на основании двух синтетических targets или считать notification внешней публикацией policy claim.

## Направление исправления и следующий falsifier

Сохранить одного существующего Scientist owner. Generic event должен иметь received/pending/applied state, content binding, устойчивый target denominator и idempotent target application. Пока fanout не завершён, current projection должна не позволять считать затронутый target current; originating ack должен зависеть от полного durable результата. Один перенос dedupe в конец не закрывает partial replay, changed-payload same-key, target drift и duplicate transitions.

Следующий acceptance запуск: штатный 3.14/locked профиль, реальный bounded HTE selected-source/packet builder, те же durable failure points и CAS corruption controls, свежий process, RunIndex/API reader. Добавить same-key changed payload и target-set drift, не принимая fixture-selected HTE refs за verified source. STATE-01 этим пакетом не исследован. WP-02 целиком не закрыт.

## Воспроизведение и сохранность

Из этой папки: `PYTHONDONTWRITEBYTECODE=1 python probe_delivery_chain.py`, затем `PYTHONDONTWRITEBYTECODE=1 python probe_sibling_controls.py`, затем `python validate_evidence.py`.

Результаты test assertions проходят, но это **успешное воспроизведение дефекта**, не green product acceptance. Fault stderr намеренно содержит исключения. `attempt01–04.stderr.txt` сохраняют исправленные ошибки построения harness (missing pytest/helper, неверный execution-profile token, лишний mark_running после lease), они не являются product findings. Production source не изменялся; pin-bound source hashes проверены отдельно. Только временные локальные CAS/SQLite; никаких repair/replay реальных outbox, provider jobs, коммитов или deployment.
