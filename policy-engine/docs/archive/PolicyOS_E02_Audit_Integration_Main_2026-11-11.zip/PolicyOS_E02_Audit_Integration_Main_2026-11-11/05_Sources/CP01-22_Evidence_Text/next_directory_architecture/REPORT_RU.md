# PolicyOS: расположение функций, глубина каталогов и реальные границы

**Статус: bounded pass завершён, общий verdict — Partial.** Read-only source `f1541ed155f278689be48a8c7ac56c3e200210f7`, 10 ноября 2026. Это углубление **SYS-01**, с конкретной целевой организацией четырёх зон, а не новый список production defects и не выполненный рефакторинг. Предыдущие `synthesis/REPORT_RU.md`, `next_structure` и `next_test_confidence` сохраняют свои ограничения.

## Главное

1. **Проблема не в максимальной глубине дерева.** Среди всех 2 895 Python source modules максимум — пять директорий ниже `polisyos/`, таких файлов 50. У Foundry `methods/catalog/causal` действительно выражает семейство вычислений. Массовое «сплющивание» дерева потеряет контекст и не уберёт связанность.
2. **Первое место для структурного улучшения — Runtime.** Durable jobs, worker lifecycle, SQL transactions и outbox находятся в `http/services`; `quality` содержит application orchestration и вызывает тот же HTTP subtree. Это один механизм с неудобно проведённой границей, не несколько независимых сервисов.
3. **Второе — DataForge read API.** Некоторые exports лишь лениво направляют к владельцу, но `read_api/catalog.py` сам строит graphs, размещает cache и публикует filesystem directory. Название и машинное описание «read-only» не соответствуют всем операциям. README уже честно признаёт часть этого различия.
4. **Деление на файлы иногда сохраняет общий namespace.** Scientist packet API и Runtime control API агрегируют private/imported symbols через `dir()`/`globals().update`; Foundry ID facade делает похожее. Такая папка — физический split, а не новая изолированная abstraction boundary. Нельзя считать каждый helper новым публичным API.
5. **Сохранять полезные тонкие слои.** Lazy root facades, IR-owned layout aliases и `CaseInspectionService` имеют ясную совместимую роль. Последний передаёт exact response/query единственному run-paper owner; удалять его только за малый размер бессмысленно.

Ни count, ни глубина, ни LOC здесь не использованы как критерий дефекта. Приоритеты ниже определяются путями исполнения, состоянием и ценой изменения.

## 1. Охват и метод

Именованный census взят из pinned baseline, свежие bytes всех 2 895 `.py` сверены SHA-256. Обычный Python 3.12 AST разобрал 2 859, оставил **36 unresolved** из-за project Python 3.14 syntax; исходники не переводились и не редактировались. Counts directory/depth используют весь manifest, import counts только разобранную часть. `directory_inventory.json` содержит полный знаменатель, `parse_errors.json` — все исключения.

| Семантически выбранная зона | Census `.py` | AST parsed | Где сосредоточено |
|---|---:|---:|---|
| Runtime целиком | 370 | 354 | `quality` 221 всего / 187 непосредственно; `http` 142 |
| Scientist orchestration + nodes | 226 | 225 | engine 69; nodes 107; decision_packet 11 |
| Foundry methods | 408 | 407 | catalog 288; causal directory 119 непосредственных файлов |
| DataForge целиком | 293 | 285 | domains 236; read_api 11 |

Это **1 297 файлов census**, а не 1 297 semantic reviews. Глубокий разбор ограничен следующими call paths, source excerpts и тремя execution controls. Общая пятиуровневая глубина не включает фиксированный префикс `policy-engine/src/polisyos`; tests, frontend, tools, docs не включены в Python-source counts.

Native application, полный import graph с динамическим связыванием, pytest, wheel/sdist и hosted CI в этом раунде **UNRUN**. Проверены source-level wiring и exact выбранные bodies с явно подставленными dependencies. Старые PASS не перенесены на этот раунд.

## 2. Runtime: application owner под транспортным именем

### Исполнение и состояние

Прослеживаемая цепочка:

`http/app.py` → `http/container.py` → `routes/control.py:327–359 launch_run` → `ControlPlaneService.launch_workflow_run` → durable store/worker → выбранная pipeline.

`ControlPlaneService` объявлен в `http/services/control/run_lifecycle.py:7084` и наследует десять mixins: admission, attempt publication, diagnostics, NL admission/execution/publication, workspace transitions, capabilities, Lex/NL pipelines. Конструктор принимает реальные stores, registry, validity/issuance owners и runtime contexts. При embedded backend он создаёт `ControlWorker` и запускает thread (`7572–7583`). `close()` останавливает worker и закрывает принадлежащие сервису ресурсы (`9271–9294`). Это application lifecycle, не HTTP serialization.

`http/services/control_plane_store.py` владеет SQL job/lease/outbox и human-decision fencing. Например, `HumanDecisionRecoveryFence.reconcile_orphan` выполняет условный SQL UPDATE по полной reservation identity. Это не следует разносить по нескольким независимым repositories только ради числа строк: транзакционный owner должен остаться один.

Напротив, `routes/control.py` связывает permissions, authenticated resource, idempotency, request context и HTTP errors. Это настоящий transport/admission adapter и его границу следует сохранить.

### DA-01: файловая граница не совпадает с направлением зависимости

**P2 architecture debt; высокая уверенность в исходниках, production failure не установлен.** В разобранной части `runtime/quality` найдены **147 import statements к `runtime.http` из 26 source modules**: 31 TYPE_CHECKING, 107 function-local и 9 module-level. Все statements с path/line сохранены. Не назвать их 147 eager cycles, не назвать 26 полным denominator при unresolved modules.

Конкретные load-bearing направления:

- `quality/acquisition_evaluation_dispatch.py:19` использует store records из `http/services/control_plane_store`;
- `quality/agent_action_authority.py:26–32` использует idempotency, permissions и role из HTTP;
- `quality/promotion_safety.py:15` импортирует `RuntimeDependencyError` из `http/errors`, а этот файл одновременно сериализует RFC7807 и пытается импортировать FastAPI;
- container и control lifecycle в обратную сторону создают quality authority/custody services.

Это не нарушение межкорневой matrix: оба конца внутри Runtime. Но перенос одного «quality validator» в другой consumer требует знать HTTP application internals. Naming `quality` не показывает, где pure validation, где orchestration, где persisted ownership.

Сопутствующее точное несоответствие карты: `architecture/packages/runtime.toml:20–25 implementation_roots` перечисляет `extensions` и `http`, но не `quality`, хотя Runtime README объявляет его владельцем большого набора функций. Не доказано, что какой-либо gate вследствие этого реально исключил файлы; исправление карты нужно независимо от решения о перемещении.

### Осторожная цель

Первый физический кандидат — **`runtime/control/`**: existing service, store, worker, registry providers, admission/publication helpers. `http/routes`, middleware, dependencies, response/error mapping остаются в HTTP. Это сокращает нынешний путь `runtime/http/services/control/` на два сегмента, но главная цель — сделать application owner доступным без транспортного размещения.

Не переносить все `quality/*` единым коммитом. Сначала зафиксировать logical owners в существующем README/contract:

- acquisition planning/execution/admission — возможный `runtime/acquisition/`;
- epoch/signature/validity lifecycle — возможный `runtime/custody/`;
- pure checks и closeout readers остаются quality до доказанной выгоды перемещения.

Эти две дополнительные папки — **вторая стадия предложения**, не новые обязательные подсистемы. Не создавать ещё `application/domain/infrastructure/interfaces` над каждым файлом. Первыми переносим узкие contracts/errors с exact aliases, затем service cluster. Существующий composition root остаётся единственным owner ресурсов.

**Нельзя потерять при миграции:** SQL atomicity и outbox transaction, borrowed/owned store distinction, shutdown ordering, tenant scope, fail-closed authority. Существующие lifecycle дефекты из `next_lifecycle` перемещение само по себе не исправляет.

## 3. DataForge: граница read/build полезнее уменьшения глубины

### Исполнение и доступность

`domains/{academic,catalog,legal,ukraine}` имеет содержательный смысл: source-specific acquisition/normalization, contracts и materialization. `kernel` содержит reusable snapshot/pipeline primitives. Эти уровни следует сохранить, а не сливать `domains/legal/batch` с runtime Lex.

`read_api/surface_routes.py` задаёт конечные module routes; `_lazy.py` возвращает canonical export. Это поддерживает lazy dependency boundary и object identity. Но facade не означает read-only operation:

- `read_api.legal.run_batch_pipeline` направляет в `domains.legal.batch.pipeline`;
- `read_api.academic.run_edge_synthesize` направляет в academic batch;
- root `read_api.finalize_snapshot` направляет в kernel snapshot;
- **`read_api/catalog.py:778–1284` сам содержит** cache root/key/publication, большую fixture dataset specification и два graph builders.

Реальный first-party путь: `runtime/http/services/control_registry_providers.py:322–325 _default_gy_catalog_graph` → `read_api.catalog.build_slice0_fixture_catalog_graph` → domain `graph_builder.build_graph` → `catalog.duckdb` → returned DatasetCatalogGraph. Это подтверждает callable route; не означает, что production serving всегда выбирает fixture. Explicit source selection и candidate/authority ограничения остаются отдельными controls.

### DA-02: producer расположен внутри интерфейса чтения

**P2 ownership/interface debt; source + bounded filesystem witness.** Machine contract `architecture/packages/data_forge.toml` описывает read-only runtime API, но разрешает runtime только `read_api`, через который доступны перечисленные producer operations. README уже прямо пишет, что поверхность не uniformly read-only. Исправлять нужно несогласованный контракт/placement, а не обвинять README в скрытии.

DA-P02 исполнил неизменённое тело `_cached_catalog_graph_root` с audit-local root и callback, записывающим marker вместо DuckDB: cold call создал/published directory; warm call вернул тот же root без повторного build. Это реальный filesystem effect выбранного body, **не** native graph acceptance. Существующее cache reuse следует сохранить, не заменять новым temp tree на каждое чтение.

### Осторожная цель

1. Перенести implementation graph materialization в существующий domain owner, например `domains/catalog/batch/materialize.py`; records для bounded fixture держать рядом с owner, пока она нужна runtime candidate contract, а не объявлять автоматически test-only.
2. Оставить `read_api/catalog.py` тонким маршрутизатором readers/types и временными exact compatibility aliases. Не копировать class definitions, registry/cache state или whole module globals.
3. Выбрать явную командную поверхность **`data_forge.build_api`** либо документированный build-capable domain facade. Это **изменение public/import contract**, поэтому одновременно обновить allowed runtime submodules и существующие consumers. Нельзя тихо переключить Runtime на private `domains` ради обхода read boundary.
4. `read_api` после migration должен иметь проверяемое свойство: импорт не грузит optional producer stack; операции, заявленные readers, не запускают materialization. Provider metadata/source provenance всё равно не превращаются в authority.

Не механически убирать cache writes из всякого reader: derived cache может быть допустимым контрактом. Здесь важнее явное имя операции и owner; `build_*` честно называется build, несмотря на parent `read_api`.

## 4. Scientist: execution, presentation и packet split

### Реальный launcher не `orchestrator`

`scientist/api.py:318–359 run_experiment` выбирает workflow и передаёт context в `orchestration/workflows/builder.py`. Builder собирает registries, CAS context, checkpoint hook и run lock; вызывает `engine.executor.WorkflowExecutor.execute` (например, `builder.py:845–858`). `nodes/builtins` регистрирует `BuildDecisionPacketNode`; builder packet создаёт/persisted result с claims/governance/epoch obligations.

Смысл границ `orchestration/engine`, `workflows`, `llm`, `memory`, `kernel` различен. Это не пять одинаковых Orchestrator abstractions. `engine/runner` отдельно даёт execution backend. Глубина сама по себе не оправдывает слияние workflow specs, budget ledger и packet projections.

### DA-03: split API снова сливает namespace

**P2 maintenance/compatibility risk; exact mechanism control, конкретный installed failure не установлен.**

`nodes/builtins/decide/build_decision_packet.py` является compatibility facade. Он импортирует `decision_packet.api`, копирует `__all__` и все его значения. API (`api.py:15–33`) формирует names через `dir()` четырёх модулей и исключает только double-dunder names. Поэтому single-underscore helpers и imported symbols попадают в `__all__`; одноимённые значения разрешаются порядком `_MODULES`.

Это не отделило responsibilities от старого module namespace. Например, `builder.py:54–116` импортирует множество section builders через `enrichment`, а `enrichment.py:40–98` импортирует их из actual section owners. Получился дополнительный re-export hop: leaf section → enrichment → builder → API → compatibility facade. Функциональный owner может оставаться один, но его поиск и monkeypatch expectations усложняются.

DA-P01 выполнил точную assembly-логику API с четырьмя synthetic provider modules. Получены: private export, imported-name export, last-module-wins collision, assignment в facade не меняет provider globals. Это **механизм**, не доказательство фактического collision bug или неработающего текущего теста в native environment.

Похожий narrow mechanism виден в Runtime `control/api.py:14–26`: там отсекаются module objects, но не single-underscore/imported non-module names. Следовательно, не следует выдавать сформированный `__all__` за тщательно отобранный public contract.

### DA-04: название presentation owner вводит в заблуждение

**P3 discoverability debt.** `orchestration/orchestrator` содержит только lazy exports и `decision_card.py`. README прямо говорит: не исполняет workflows и не изменяет run state. `DecisionCard.from_packet` строит presentation readout. Искать управление выполнением по этому имени неудобно, но сам rendering helper полезен и не объявлен dead code.

Цель: `scientist/publishing/decision_card.py`, то есть существующий publishing owner, **с явной маркировкой non-authoritative projection**. Не смешивать такую карточку с governed publication approval. Сначала можно улучшить navigation/README без перемещения, затем сохранить старые aliases и проверить сериализацию. Не создавать двадцатый first-level root ради переименования: machine contract уже задаёт canonical roots cap 19.

### Цель для decision packet

Оставить semantic path `nodes/builtins/decide/decision_packet/`; 11 файлов на пятом уровне не свидетельствуют об избыточности. Сделать package facade finite (`BuildDecisionPacketNode` и реально поддерживаемые contracts), пусть builder импортирует leaf owners напрямую. Compatibility file сохраняет только **измеренный используемый** legacy набор с собственным sunset; не удалять private exports вслепую. Native fresh-import permutation, object identity и existing patch seams должны быть проверены до сокращения.

## 5. Foundry: удержать доменные уровни, устранить namespace backfill

### Реальный смысл дерева

`methods/catalog/<family>` — authored method implementations. `selection` владеет registry/version resolution, `components` — component bridge/composition, `backends/dispatch.py` — выбор и invocation backend, `extensions` — component discovery/bootstrap. Это реальные разные обязанности.

Путь регистрации: `extensions.registry.bootstrap_foundry_method_registry` → `extensions.discovery.build_foundry_method_components_index` → `_builtin_loader.builtin_foundry_method_components` → family `_registry_boot` → canonical MethodRegistry bridge. Loader явно конструирует строку `polisyos.foundry.methods.catalog.{family}._registry_boot`. Поэтому перенос `catalog` или переименование family меняет dispatch contract, а не только вид дерева. File presence само по себе не равняется registration; отдельные выводы free-grow не дублируются здесь.

`MethodDispatcher` использует Core `BackendDispatcher`, runner lock и actual selected backend; directory placement отделяет backend orchestration от scientific method. Не переносить causal/econometric kernels в общий `utils`.

### Где физический split не стал самостоятельной abstraction

- `catalog/causal/id_engine/{__init__,api}.py` копирует namespaces core/transport/counterfactual, включая private bindings; потом `__init__` также даёт finite explicit aliases для потребителей.
- `catalog/causal/causal_engine/api.py` собирает класс из пяти mixins и **обратно присваивает** `CausalEngine` в globals artifacts/discovery/identification (`api.py:201–203`). `discovery.py:75–77` копирует `_artifacts.__all__` в свой globals.

Это единый CausalEngine, физически разделённый по файлам, с порядком инициализации и shared helper namespace. Называть каждый mixin независимым сервисом неверно. Но вывод «слить всё обратно» также не следует: размер тела и разные темы оправдывают physical split.

Цель: сохранить `catalog/causal/causal_engine/` и class public identity, заменить broad namespace backfill на explicit leaf imports и узкий typed shared context/helper contract. Не заводить отдельные stores/caches для каждого mixin. ID-engine package оставить finite compatibility aliases к существующим owners; reusable algorithms остаются в family. Native import ordering и identification/evidence controls обязательны, прежде чем убирать backfills.

### Полезная совместимость, которую сохраняем

`methods/layout.py` и `methods/compiler/layout.py` напрямую re-export IR-owned SlotLayout helpers. Они не создают вторую реализацию или class. Их малая величина — причина считать их дешёвым compatibility bridge, не дефектом. Удаление допустимо только после отдельно подтверждённого consumer/pickle population и lifecycle решения.

## 6. Предлагаемая структура и порядок перехода

Это **target sketch**, не одобренное изменение архитектуры и не инструкция переместить всё разом. Каждый шаг имеет один existing writer/owner, без нового framework.

```text
polisyos/runtime/
  control/                 # first candidate: durable service/store/worker cluster
  http/                    # routes, ASGI composition, middleware, transport mapping
    services/              # transport-specific projections/adapters only after migration
  quality/                 # existing checks/readers, staged extraction rather than bulk move
  acquisition/             # later, only once explicit owner/ports are qualified
  custody/                 # later, only once epoch/signature owner is isolated
polisyos/data_forge/
  domains/catalog/batch/materialize.py   # graph builder/cache/fixture materialization owner
  read_api/                # finite readers/types + temporary named aliases
  build_api.py             # proposed explicit command facade; requires contract update
  kernel/                  # unchanged common snapshot/pipeline infrastructure
polisyos/scientist/
  orchestration/{engine,workflows,llm,memory,kernel}/  # preserved roles
  publishing/decision_card.py          # non-authoritative presentation candidate
  nodes/builtins/decide/decision_packet/             # preserved leaf owners
polisyos/foundry/
  methods/{selection,components,backends,catalog}/    # preserved roles
  extensions/                                      # canonical discovery/registration
```

**Stage 0: boundary without moves.** Correct Runtime implementation-root map and DataForge read/build description; document finite canonical entries; record actual exported symbol/object manifests on supported Python. This reduces ambiguity before risking imports.

**Stage 1: namespace cleanup.** Stop uncontrolled export growth while retaining current allowed legacy names. Point first-party consumers to explicit owners. Keep type identity, dependency laziness and patch seams. Never add blanket dynamic re-export merely to make old tests green.

**Stage 2: narrow placement changes.** Move DataForge graph builder implementation behind compatibility aliases; move presentation card only if discoverability benefit warrants it; separate Runtime transport-neutral errors/contracts. No new behaviour in the same move.

**Stage 3: Runtime owner cluster.** Relocate service/store/worker together, preserving one transactional/resource owner. Only after that evaluate acquisition/custody extraction. Physical split alone is not separation; migration acceptance must include lifecycle and transaction negatives.

### Load-bearing migration risks

- `ControlPlaneService.__init__` derives default source root using `Path(__file__).resolve().parents[6]` (`run_lifecycle.py:7212`). A shallower path without changing this derivation silently selects another input root. Prefer explicit composition root with a tested fallback, not mechanically decrementing integers everywhere.
- `foundry/extensions/registry.py:161–173` hashes registry snapshot including `import_module` and `import_qualname`. A class move changes execution identity even if method names/signatures are unchanged.
- `_builtin_loader` uses literal family import routes. Installed wheel resources and generated stubs are separate acceptance surfaces.
- Runtime epoch issuance binds code/consumer identities. `container.py:857` has an exact expected-consumer string; source/owner identities are data, not only imports. Updating path strings must not bless old evidence under new code.
- Pydantic/Enum/dataclass identity, pickles, OpenAPI schema names, stored discriminators and old artifact schemas need explicit compatibility. Re-exports preserve a canonical class object; duplicate definitions do not. Historical evidence should remain interpretable, not rewritten to make new paths look old.
- Existing tests/topology/mirror paths and public/import policies are migration companions. `next_structure` already shows filename ratios are not semantic coverage; adding mirror placeholders is not acceptance.

## 7. Что должно опровергать неверную миграцию

| Change | Useful acceptance and negative control | Existing owner |
|---|---|---|
| Runtime control relocation | Same route permissions/resource sealing, durable lease/outbox effects, borrowed-resource close, blocked late publication; remove/fail store publication and require refusal | runtime HTTP/control suites; `next_lifecycle`, `next_test_confidence` maps |
| DataForge graph implementation move | Same graph records/digest/search/fetch, cold/warm cache behaviour, failure/partial-publication recovery, no producer stack on read-facade import | `tests/unit/data_forge/read_api/test_catalog_graph_builders.py`, runtime catalog source selection suites |
| Finite packet/control facade | Old intended names resolve same objects; importing one leaf cannot require facade backfill; intentionally conflicting test symbol must not silently change canonical binding | existing packet/build/import contract tests, native fresh interpreter |
| CausalEngine cleanup | Same selected graph/query proof reader, unchanged shared store/context; corrupt source/receipt still refused; native import permutations | Foundry causal/installed suites |
| Decision-card move | Same projection bytes/values and class identity through legacy path; no authority gain from rendering or package name | `tests/unit/scientist/orchestrator_v2/test_compatibility_contracts.py` |

Это acceptance proposal, не результаты исполнения этих suites. DA-P03 отдельно проверил exact `CaseInspectionService.get` с synthetic owner: один call, тот же query и response object. Он показывает полезность делегирующего adapter, но не закрывает real run-paper availability.

## 8. Evidence, reproducibility, limits

- `directory_inventory.json`, `directory_summary.json`, `import_edges.json`, `parse_errors.json`: named full source census и bounded syntax edges.
- `source_excerpts.json`: exact path/lines/SHA-256 для решающих исходников и тестов.
- `SOURCE_VALIDATION.json`: свежая SHA-256 сверка 2 895 source paths; дополнительные cited docs/tests сверены в excerpt evidence.
- `boundary_probe_results.json`, `probe_boundaries.py`: три точных bounded controls, substitutions явно описаны.
- `migration_matrix.json`: proposed owners, сохраняемые contracts, acceptance, статус `proposed_not_implemented`.
- `inspect_directories.py`: повтор census без записи в source.

Начальная попытка parse всего `read_api/catalog.py` для probe упёрлась в Python 3.14 exception syntax на строке 1386. `probe_initial_failure.txt` сохраняет ошибку измерителя. Повтор извлёк **точные bytes выбранного совместимого body**, не переводил unsupported source и не представлялся native import.

Повтор из workspace: `PYTHONDONTWRITEBYTECODE=1 python policyos_deep_audit/next_directory_architecture/inspect_directories.py`, затем аналогично `probe_boundaries.py`. Temporary marker output остаётся внутри этого audit directory. Snapshot status до/после — clean; source bytes совпадают с baseline. Отсутствие обнаруженного runtime failure здесь не является PASS всей архитектуры.

**Рекомендация:** сначала конечные interface contracts и правильные owners, затем точечные перемещения. Никакого массового flattening, сокращения числа файлов ради KPI или выноса domain logic в общий Core/common.
