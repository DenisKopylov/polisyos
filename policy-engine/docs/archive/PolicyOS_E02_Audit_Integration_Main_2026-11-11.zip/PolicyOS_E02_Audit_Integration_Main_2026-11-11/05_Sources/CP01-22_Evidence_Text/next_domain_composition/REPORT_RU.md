# PolicyOS: domain → grammar → obligations → requirements

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`, read-only snapshot. Продолжение `next_freegrow` и пунктов E3–E6/F1/F4 плана. **Выборочный bounded audit, не native integration и не scientific validation.** Исходники не менялись.

## Результат

1. **Подтверждён semantic loss до evidence denominator.** Реальный W6.A compiler принимает отдельно две независимые области: вакцинационную услугу для сельских детей и кредитную поддержку MSME. Их составной intent также получает `compiled`, но один общий набор facets становится гибридом: `service + credit_registry + concessional_credit + msmes + rural + equity_harm`. Три реальные seed-rule obligations исчезают, а реальный selector DataRequirementCompiler получает на семь required constructs меньше, чем объединение отдельных задач. Контроль повторён с обратным порядком текста и с обычным budget=8; это не следствие frontier budget.
2. **Соседний semantic-loss discriminator:** нормализатор сохраняет все шесть существующих `IdentificationMode`, но grammar `_method_need` сохраняет только sequential; partially/proxy/interference/bounds превращаются в `point_identified` со статусом `compiled`. Поздний method compiler способен сохранить явную bounds-предпосылку, поэтому проблема не в отсутствии типового словаря.
3. **Универсальные механизмы действительно есть.** Один и тот же obligation compiler принимает два новых synthetic rule ID без правки исходников; proposed, wrong-facet и LLM negative controls не получают blocking frontier. Legal requirement compiler сохраняет разные популяции, инструменты и компетентные органы двух областей. Method selector при отсутствии методов даёт `missing/fail` для обеих.
4. **Authority не доказана и не должна выводиться из compiled.** Runtime constraint consumer сохраняет `constraint_source_authority_verification_missing`; даже удовлетворённый method selection становится `limit`, а не признанием научной валидности. Lex отдельно не допускает claim-level legal authority без квалифицированной claim/source relation. Обнаруженное уменьшение denominator не является доказанным обходом этих gates, публикацией или исполнимостью новой политики.

Один корневой класс: **lossy semantic projection перед компиляцией требований**. `DC-01` и `DC-02` ниже являются различающими проявлениями, а не двумя новыми SYS-семействами. В прежнем архиве SYS-02 касался canonical contract owners/semantic consistency, SYS-04 — authority/evidence boundary; эти результаты добавляют новый конкретный механизм в близкой тематике, не повторяют clone count и не утверждают новый инцидент.

## 1. Полная изученная цепочка и границы владельцев

- **Domain contract:** `ir/governance/problem_frame.py:49–69`, `ProblemDomain` — routing vocabulary; CUSTOM предусмотрен намеренно. Отсутствие отдельного enum для каждой научной дисциплины не является дефектом. Сценарный adapter (`data_requirement/compiler.py:2829–2879`) различает resolved/unresolved/not_supplied, хранит исходную декларацию и не обещает semantic support неизвестному домену.
- **Grammar input:** `policy_grammar/_impl/schema.py:22–74` принимает text/ProblemFrame/PolicySpec, последний содержит множество interventions. `normalizer.py:38–97` объединяет их сведения в один token stream и коллекции mode/population/region. По этому пути нет atom/component identity в emitted facet set.
- **Facet producer:** `facets.py:77–195,198–356`, типы `core/contracts/runtime.py:584–616`. Каждый case получает ровно один instrument, delivery, funding, population, geography, risk и method_need. Определение domain в нормализованном объекте не участвует в этих selectors.
- **Compilation authority:** `authority.py:23–51`, `consumer.py:14–88`. Missing refs и невыводимые facets блокируются, LLM остаётся candidate_unverified. Обычный профиль полномочен для compilation_facets, а не data/method/legal/publication. Наличие synthetic concept strings в успешном тесте доказывает typed compilation, не grounding.
- **W6.A → W6.B/W6.C:** `data_requirement/compiler.py:573–618` связывает существующих owners; blocked/candidate case не компилирует graph. Scenario path `620–710` использует те же facets и graph, затем claim decomposition и per-claim data compiler. `obligation_rules/catalog.py` производит governed seed specs, `obligation_graph/_impl/compiler.py:217–350` сопоставляет их фактическим facets.
- **Requirement denominator:** `data_requirement/compiler.py:418–433,1608–1685` берёт required constructs из graph frontier и явных объявлений, отдельно от candidate proposals. `430–498` связывает resolver outcomes с data families/specs. В probe выполнен настоящий `_required_constructs_from_obligation_graph`, но не полный capability resolver, acquisition или numerical consumer. Явные declarations могут вернуть недостающие constructs; тест намеренно проверяет автоматическое derivation без ручного ремонта.
- **Публично используемые orchestration consumers:** `runtime/quality/scenario_evidence_contract.py:169–205` и `generation_cycle.py:14027–14060` вызывают compiler. `runtime/quality/workspace/foundry_consumption.py:1245–1475` сохраняет basis, grammar, catalog, graph, claim ledger, participation и method preflight; проверяет complete bundle/frontier/deferred population. Он не восстанавливает obligations, которых вообще не было в graph.
- **Method contract → consumer:** `method_requirement/_impl/compiler.py:29–140,304–317` и `foundry/methods/selection/requirements.py:15–98,102–197`. Compilation задаёт необходимые допущения, uncertainty, lineage и limitations; отсутствие подходящих методов приводит к `missing/fail`. Method metadata selection не равно действительному execution/conformance.
- **Legal contract → consumer:** `legal_requirement/_impl/compiler.py:39–188`; Lex `lex/normpack/legal_authority.py:155–179,408–444,531–643`. Requirements определяют jurisdiction/time/instrument/actor. Lex владеет admissibility и в текущем source явно добавляет `claim_source_relation_verification` как missing. Нельзя превратить удачный requirement model в legal authority.

Полный first-party textual caller census для выбранных entrypoint names сохранён в `caller_census.json`. Это census текстовых ссылок в current src `.py`, не dynamic call graph и не отсутствие неизвестных consumers.

## 2. DC-01: композиция теряет обязательства обеих областей

**Severity: medium. Confidence: high для механизма, medium для конечного operational impact. Evidence: bounded_probe + source_traced consumers.**

Входы прямо записаны в probe:

- Healthcare: `Provide vaccination service for rural children in 2026 with budget funding and coverage monitoring.`
- Fiscal: `Create concessional credit for MSMEs in national regions in 2026, with a partial guarantee, budget appropriation, and credit registry.`
- Joint: конкатенация обоих statements без удаления слов или обязательств; domain=CUSTOM. Перестановка statements проверена отдельно.

У отдельных cases корректно выделяются разные instrument/delivery/population/risk. У joint результат `compiled` без blocker, но priority ordered keyword selectors выбирают service из первого компонента, credit registry/funding/MSMEs из второго и rural/equity из первого. Это не композиция scoped facets, а их несогласованная склейка.

Настоящий seed-rule matcher перестаёт выдавать:

- `obligation.data.vertical_credit_program_registry`;
- `obligation.data.vertical_service_delivery_registry`;
- `obligation.fiscal.contingent_liability_portfolio_risk`.

Соответствующие rules существуют в `obligation_rules/catalog.py:1245–1266,1510–1540`; disappearance возникает до ledger/frontier, а не как declared deferred/limited obligation. Downstream selector теряет `credit_program_enrollment`, `program_participation_rate`, `fiscal_burden_per_beneficiary`, `risk_score`, `public_service_payment`, `service_quality_indicator`, `provider_network_capacity`. Joint сохраняет только `firm_survival`, `credit_access`, `employment_count`. Перечень относится к этому fixture, не ко всем требованиям PolicyOS.

Для изоляции первым прогоном все три complexity budgets подняты до 1000. Повтор с реальным scenario limit `max_frontier_items=8` даёт тот же construct result и явно сохраняет deferred ledgers. Следовательно, увеличение budget не чинит эту потерю.

**Sibling control:** простое объединение уже полученных facet rows также недостаточно. `_structured_pattern_matches:313` создаёт `{facet_type: value}`, поэтому последняя строка данного типа побеждает. `health_then_credit` и `credit_then_health` дают разные obligations. `data_requirement/compiler.py:2273` аналогично выбирает один scope facet per type. Поэтому минимальное исправление не сводится к tuple вместо scalar.

**Последствие:** проверяемая полнота requirement denominator может быть полной относительно уже неполной модели; missing evidence для исчезнувшего требования не будет отдельной missing obligation. Это существеннее числа facets. Не установлено, что дальнейшие independent critics/explicit constructs/authority gates не остановят весь проект.

**Направление:** сохранить component/atom→facet→claim→requirement binding в существующих owners. Если current grammar умеет только single-component envelope, смешанный input должен давать typed unsupported-composition/limitation, а не silent compiled hybrid. Scope-aware matcher обязан проверять связанный набор facets одного компонента, а не произвольный Cartesian набор и не last-row-wins. Различающая acceptance: независимые элементы + их union, перестановка, разные scopes/epochs, конфликт и отсутствие одного evidence witness. Union обязателен для независимых сохраняемых требований; при конфликте допустим явный compositional refusal, но не исчезновение.

## 3. DC-02: ограничение identification становится более сильным методом

`ir/governance/policy_spec.py:106` допускает полный enum IdentificationMode. Normalizer сохраняет переданный enum (`normalizer.py:74–75,94`), но `_method_need` (`facets.py:290–295`) выбирает sequential при его наличии/keyword, иначе всегда point_identified.

Проверенные реальные enum значения:

- point_identified → point_identified;
- sequential → sequential;
- partially_identified, bounds_only, proxy_identified, interference_aware → point_identified.

Все cases имеют status=compiled. Для этого seam использован synthetic PolicySpec-shaped collaborator с реальным enum; реальная Pydantic InterventionSpec в штатном Python не импортировалась. Source поле подтверждает допустимость перечисленных enum inputs, но full typed PolicySpec acceptance остаётся UNRUN.

Поздний MethodValidityRequirementCompiler на явном claim precondition partial_identification выпускает bounds requirement и selector без метода отказывает. Это положительный контроль: дальнейший owner умеет не-point ограничения. Не установлено, что grammar method facet автоматически определяет final method requirement для каждого claim. Claim decomposition (`claim_decomposition.py:539–564,616+`) имеет собственную классификацию и может считать method facet context-only; поэтому вывод ограничен неверным emitted facet и риском утраты explicit input semantics, а не фактом выполнения point estimator.

**Направление:** использовать существующий enum без strengthening. Для несовместимых modes сохранить scoped needs/weakest boundary либо typed refusal. Проверить все существующие mode values, несколько interventions, текстовый rollout рядом с explicit bounds и мост до реального selector. Не лечить добавлением частных keywords для очередной предметной области.

Дополнительный discriminator той же lexical projection: отрицание `Do not provide vaccination ...` создаёт те же facets, что положительный statement. Это не самостоятельный authority finding. Parser классифицирует topic/tokens, но не является семантически надёжным пониманием произвольного intent. Проект должен либо явно ограничить входной envelope, либо сохранять ambiguity/negation.

## 4. Что два домена действительно подтверждают

**Техническая общность, положительные controls:**

- Оба input используют один compiler, без веток по domain. Даже замена domain=HEALTHCARE на FISCAL при том же тексте даёт одинаковый compiled payload. Это ожидаемо для routing vocabulary, но опровергает трактовку domain tag как доказанной subject-model validity.
- Два ранее неизвестных ID `audit.new.health` и `audit.new.credit`, переданные как typed governed rule data, обнаруживаются match/filter механизмом и входят в frontier без изменения продукта. Proposed status и несоответствующие facets дают zero candidates. Это **in-memory rule extensibility**, не runtime typed-index search, не admission нового governed rule и не full Rule-12 acceptance.
- LLM candidate с завышенным mandatory hint и true flags остаётся видимым candidate, но не входит в frontier; отказ `source_ceiling_candidate_not_blocking` сохранён.
- Отсутствующие concept refs и невыводимый intent блокируются. LLM grammar не удовлетворяет data authority.
- Legal requirements обеих областей сохраняют разные population, instrument, actor и одинаково явное time/jurisdiction context. Это precision требования к Lex, не доказательство действительности законов или компетенции synthetic actor.
- Method compiler выдаёт point/bounds обязательства на разных claim inputs, а настоящий selector без методов даёт missing/fail в обоих случаях.

**Предметная валидность не подтверждена:** отсутствуют реальные vaccination epidemiology/SCM, epidemiological interference tests, credit additionality identification, bank selection model, population transportability, live data/source admission, empirical calibration, expert/legal review. Прогон на разных labels и совпадение enum не отвечает ни на один из этих вопросов.

## 5. Evidence/authority и identity

Обязательная сильная граница действует независимо от найденного grammar loss:

- `foundry_consumption.py:1253` явно добавляет missing source authority после разрешения source bytes. Разрешение bytes не объявляется institutional standing.
- `:1430–1457` проверяет method status population; satisfied превращается в constraint `limit` с сообщением о missing independent method-validity evidence, missing — в `block`.
- Lex `:425–444` сохраняет отсутствие квалифицированной claim/source relation даже при наличии norm fields. Полный Lex execution здесь не запускался.
- Compiled case id (`compiler.py:103–115`) зависит от intent_id/profile/spine refs, не от текста. Один intent_id с другим текстом получает тот же case_id и другой payload. Это **наблюдение, не новая finding об immutable overwrite**: grammar CAS writer (`artifacts.py:23–61`) отдельно адресует полные canonical bytes; historical conflict/reopen не проверен. Использовать case_id как content digest нельзя, но доказательства такого downstream misuse в этом срезе нет.

## 6. Воспроизводимость, корректировки измерителя и остаточные проверки

Команда: `PYTHONDONTWRITEBYTECODE=1 python policyos_deep_audit/next_domain_composition/probe_domain_composition.py`. Финальный exit=0; stdout и empty stderr сохранены. Python 3.12.14, Pydantic 2.13.4, не поддерживаемый locked Python 3.14/Pydantic 2.12.5. `next_native/REPORT_RU.md` уже установил отсутствие штатного интерпретатора/lock в данном workspace; здесь повторный bootstrap/install не выполнялся.

Source-extracted modules используют настоящие Pydantic contracts/selector bodies и source line numbers. Исключения явно записаны в `results.json`: импорты dependencies инжектированы, необслуживаемые optional IR/artifact type annotations заменены Any; identification input collaborator synthetic; seed rule specs настоящие, но hash descriptor синтезирован без governance receipt. Runtime contracts читаются только до TemporalRef, чтобы не парсить поздний несвязанный Python 3.14 except syntax; hash проверяется для полного файла. Это не native_targeted.

Первые попытки измерителя: parser остановился на позднем Python-3.14 syntax; затем был исправлен namespace injection для Pydantic. Tracebacks сохранены отдельно. Ещё одна предварительная assertion ошибочно ожидала status=blocked от selector, который по контракту выдаёт missing/fail; ожидание исправлено после чтения owner. Это ошибки измерителя/неподдерживаемой среды, не product test failures. Исходники не правились.

**Остаётся UNRUN:** supported native imports и tests; настоящий `compile_for_scenario`/N7 whole-flow с persisted capability index; CAS persist/reopen chain; installed/API/UI; scientific/clinical/financial validity; independent conformance/promotion/publication; weakest-boundary closure полной композиции и immutable closed-case replay. Исторический main не объявляется текущим main.

Следующий bounded acceptance: два typed multi-intervention PolicySpecs в штатной среде → grammar → complete obligation graph → claim ledger → requirement queries → real consumer; сравнить отдельные и составной cases, затем потерять/подменить scope/method-mode/свидетельство. Весь путь обязан сохранить ограничение или явно отказаться. Нельзя считать этот отчёт закрытием E1–E7/F1–F7.

Повторный запуск дал побайтно одинаковый `results.json` (`REPLAY_VALIDATION.json`). Один subprocess: 0.65 s elapsed, около 40 MiB max RSS по `resource.RUSAGE_CHILDREN`; это профиль измерителя, не производительность продукта. `/usr/bin/time` отсутствовал, поэтому измерение сделано штатным Python resource API, без установки пакетов. Source validation: 36 названных файлов совпали с baseline SHA-256, Git tree clean; caller census прочёл все 2 895 current src Python paths и сохранил 52 текстовых совпадения выбранных symbols.
