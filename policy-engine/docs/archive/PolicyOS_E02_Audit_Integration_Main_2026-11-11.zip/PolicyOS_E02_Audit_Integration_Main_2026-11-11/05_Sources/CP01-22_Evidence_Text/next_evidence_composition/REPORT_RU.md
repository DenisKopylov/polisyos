# Scoped domain → claim → data/method requirements

**База:** `f1541ed155f278689be48a8c7ac56c3e200210f7`, read-only. Продолжение checkpoint06 / WP-04. **Итог: PARTIAL, два source-backed semantic findings, без доказанного authority bypass.** Исходники, tests, lockfiles и данные продукта не менялись; реальные providers, scientific jobs, E02/N5 и публикация не запускались.

## Краткий результат

1. **EC-01: claim-bound scope теряется уже внутри полного DataRequirementCompiler.** Два независимых claims требуют один construct для разных population/geography/time. По отдельности scopes сохраняются. Вместе отправляется только один resolver query; два конечных DataRequirementSpec получают scope последнего компонента. При обратном порядке оба получают другой scope. Claim A сохраняет собственные facet_refs, но получает scope B. Повторено с реальными strict ClaimRecord DTO, не только mapping input.
2. **DC-01 доведён до реального вызова resolver port.** Выполнены полные source bodies compile_for_scenario → grammar → actual seed catalog/graph → typed ClaimLedger → compile_for_claim_ledger. Те же семь отсутствующих constructs не доходят до вызовов resolver. Это сильнее прежнего helper-only результата, но всё ещё source extraction с явно подставленным port, не native registry/integration.
3. **EC-02: даже исправленный upstream method facet не связывает ограничение с causal requirement.** Реальный ClaimDecompositionCompiler принимает bounds_only / partially_identified и остальные известные modes, но выделяет method facet в context_only; causal claims остаются без этого ограничения. Реальный MethodValidityRequirementCompiler выдаёт point. Прямое явное partial_identification precondition на самом claim даёт bounds. Таким образом, одного исправления scalar grammar недостаточно.
4. **Положительные границы сохранены.** Catalog projection отказывает generic scope без named profile; discovery query/index mismatch, отсутствие обязательного resolver и конфликт profile population отклоняются. Все method controls без методов дают missing/fail. Существующий runtime после verified computation всё равно выставляет limit, не method-validity authority.

EC-01/02 — уточнения класса lossy semantic projection, смежного с DC-01/02 и SYS-02/SYS-04, а не две новые независимо посчитанные SYS-семьи. Нельзя складывать число наблюдаемых симптомов с числом root-cause families.

## 1. Что именно исполнено

`probe_evidence_composition.py` использует сохранённый source-loader предыдущего среза, затем загружает целиком настоящие neutral capability DTO, data requirement models/compiler, claim models/decomposition, method models/compiler/selector и Fabric projection adapter. Product imports удалены при исполнении AST; определения методов и predicates не переписываются. Удалённые imports и SHA-256 каждого файла перечислены в source_evidence.json.

- Python 3.12.14, Pydantic 2.13.4.
- **Полностью исполнены bodies** compile_for_claim_ledger и compile_for_scenario, включая нормализацию входов, сбор constructs, создание реальных typed queries, resolver-port calls, spec construction, input hash и basis report.
- RecordingResolver записывает запросы и возвращает заведомо blocked binding с synthetic unresolved index. Он не ищет реальную capability и не предоставляет source truth. Сам production RequirementToCapabilityResolver **не исполнен**.
- Для scenario path dynamic import adapter подключён к настоящему source-extracted compile_claim_decomposition. Seed catalog builder/hash и сохранённый governed family map настоящие, default frontier budget=8. Отдельные fake rule patterns не подставлялись.
- ClaimRecord/ClaimLedger/MethodValidityRequirementSpec/DataRequirementSpec/RequirementToCapabilityQuery — реальные Pydantic definitions. ArtifactRef и неиспользуемые dependencies PolicySpec/ProblemFrame остаются Any в loader. **Typed multi-intervention PolicySpec не исполнен.**
- DataNeed заменён Any только для неисполненной ветки: проверенные projection cases отказывают до создания DataNeed.

Два последовательных запуска exit=0; results.json byte-identical. Первая/вторая неудачи инструмента (неверное имя receipt key и selector function) сохранены отдельно; production predicates не менялись. Native import отдельно exit=1: текущий Python не понимает Python 3.14 syntax `except FileNotFoundError, ValueError, ArtifactOwnershipError` в core/artifacts/store.py:2155. Это **environment blocker**, не падение продукта на поддерживаемом профиле.

## 2. EC-01: одно global scope вместо claim-scoped queries/specs

**Severity: medium semantic correctness. Confidence: high для выполненного owner, medium для operational impact.**

Контроль намеренно использует один и тот же осмысленный construct `firm_survival`: его требуется установить отдельно для rural_microfirms / region_A / 2026 и urban_msmes / region_B / 2027. Это независимый additive случай, не закон union для любых конфликтующих политик. Facet IDs уникальны, каждый claim явно ссылается только на свои три scope facets. Source family map синтетический и объявлен как таковой.

Результаты:

- A отдельно: один query population=rural_microfirms, geography=region_A; spec time=2026.
- B отдельно: один query population=urban_msmes, geography=region_B; spec time=2027.
- A+B: один query для B; **оба specs** population=urban_msmes / region_B / 2027.
- B+A: один query для A; **оба specs** population=rural_microfirms / region_A / 2026.
- Удаление claim B при сохранении его facets не возвращает scope A. Strict typed claims дают тот же результат.
- Неизвестный facet_ref публичного mapping claim приводит к fallback на все facets, а не typed refusal. Это дополнительный симптом той же области, не отдельная новая finding family. В отличие от него, upstream typed ClaimDecompositionInput неизвестный obligation facet_ref отклоняет.

**Точный механизм:**

- data_requirement/compiler.py:415–439 вычисляет единый scope до прохода по claims.
- :1608–1645 объединяет и dedupe'ит required_constructs как strings, без claim/scope key; :1443–1474 строит один query на construct.
- :471–489 применяет общий family set ко всем decision-bearing claims.
- :1257–1274 выбирает claim facets, но затем начинает с dict(facet_index) и update'ит уже существующие ключи. Update значения не перемещает позицию ключа в dict. Поэтому :2273 last-facet-per-type по-прежнему выбирает глобально последний scope, независимо от claim.facet_refs.
- :2253–2265 при пустом/неразрешимом наборе facet_refs возвращает все facets; :2336–2344 dedupe по (claim_id, family), не semantic scope.

**Почему это не просто недостаток количества facets:** input уже содержит оба правильно размеченных набора и claim bindings. Даже counterfactual исправление grammar, сохраняющее несколько facet rows, не чинит consumer. Требование на разные populations не становится одним требованием лишь потому, что имя construct одинаково.

**Ограничения:** прямой публичный compile_for_claim_ledger поддерживает этот input shape и воспроизведение выполнено. Найденные source callers в продукте вызывают этот метод из compile_for_scenario/fallback внутри самого compiler; scenario producer пока создаёт single-envelope facets. Не доказано, что штатный runtime сегодня производит именно такой двухкомпонентный ledger. Это наблюдаемый дефект generic scoped contract/extensibility, не установленный production incident.

**Counterevidence:** без resolver result basis=not_established. `require_capability_index=True` без resolver отказывает. Возвращённый blocked binding в synthetic case может дать basis=established, поскольку basis означает наличие вычисленного requirement basis, а не успешное evidence admission; blocked metadata и authority_boundary сохранены. Не трактовать established как authority. Query time_window без явного profile остаётся null/null намеренно; это положительная защита от выдуманного интервала, а не finding.

**Минимальное направление:** existing compiler owner должен связывать `(claim/component, construct, population, geography, time-role/interval)` с query и spec, либо явно отказать unsupported multi-scope input. Claim refs должны определять scope; отсутствующий/неизвестный binding не должен незаметно расширяться до всех components. Acceptance: same construct / different scope отдельно и вместе, permutation, удаление одного компонента, invalid facet ref, scoped resolver response и явный conflict/unsupported result. Не требуется отдельный compiler для каждого домена.

## 3. DC-01: усиление доказательства до queries и конечных specs

Здесь использованы прежние healthcare vaccination и fiscal MSME credit statements без изменения слов, все domain tags=custom, затем concatenation и reversal. Выполнен существующий scenario method body с настоящими grammar, seed graph, claim decomposition и data compiler.

- Healthcare: 3 resolver queries, 20 claims, 0 specs, requirement basis not_established.
- Credit: 7 queries, 20 claims, 18 specs, basis not_established.
- Joint и reversal: 3 queries, 20 claims, 9 specs, basis not_established.

20 claims во всех случаях не означает одинаковый/полный смысл. Количество specs зависит от реального legacy family map: healthcare constructs в используемом сохранённом map не отображены, поэтому ноль specs не означает отсутствие requirements, которые сохраняются как unresolved queries. Это не утверждение, что медицинская политика валидна или что такой input должен получить authority.

Из additive union реальных query constructs joint теряет те же семь:
`credit_program_enrollment`, `fiscal_burden_per_beneficiary`, `program_participation_rate`, `provider_network_capacity`, `public_service_payment`, `risk_score`, `service_quality_indicator`.

Это снимает прежний пробел «выполнен только _required_constructs_from_obligation_graph»: потеря подтверждена на фактических resolver-port calls полного compiler body. Она **не** снимает пробелы production resolver/index, native imports, live acquisition/admission и final consumer/publication.

## 4. EC-02: mode facet не становится claim-bound method precondition

**Severity: medium semantic compilation. Confidence: high локально; runtime consequence не установлен.**

Проверяется downstream seam отдельно от DC-02. В typed ClaimDecompositionInput передан causal effect facet, методический facet с каждым из шести известных modes и causal obligation, который **явно ссылается на оба facets**. Это counterfactual «upstream mode уже сохранён правильно», а не подмена результатов реального grammar.

Для всех шести modes:

- три claims: effect causal, method context_only и obligation causal;
- два method requirements, оба identification_class=point;
- method facet сохраняется только как текст context-only claim, без method_need_preconditions;
- causal claims сохраняют IDs/ref связи, но method compiler не разрешает method facet по ref и не получает его semantic value;
- selection без методов даёт missing/fail для обоих requirements.

**Механизм:** claim_decomposition.py:195–219,539–561 классифицирует method facet через lexical family matcher, где эти значения попадают в context_only. :242–263 сохраняет obligation facet refs, но не читает их значения для method needs. :448–482 выводит method needs из claim family/type и строит metadata только с source_label. method_requirement/compiler.py:255–301 читает сам claim, его text/metadata/preconditions, но не разрешает внешний facet; :304–316 default=POINT.

Для bounds_only и partially_identified это потеря явно заданного non-point ограничения. Само значение point ещё не доказывает ошибочность proxy/interference/sequential: эти режимы могут иметь point estimands, и их научное соответствие здесь не устанавливалось. Они служат controls отсутствия семантической связи, а не шестью отдельными finding cases.

**Положительный discriminator:** то же causal claim с явным attached `partial_identification` precondition даёт BOUNDS и source_precondition_refs=['audit:bounds']. Словарь и следующий owner способны представлять ограничение. Ошибка композиции не должна чиниться ещё одним keyword в grammar.

Это расширяет DC-02: прежде подтверждался только неверный emitted scalar и context_only classification; теперь выполнена полная связь typed decomposition→typed method requirements→real selector. **Не доказано**, что bounds-only запрос прошёл к point estimator или был опубликован. Native PolicySpec path и observation routing не запускались; отдельные observation readiness gates могут правильно учитывать identification_mode.

**Минимальное направление:** существующие owners должны переносить explicit mode/ограничения в связанные claim preconditions, сохранять source refs и показывать unsupported/conflict для несовместимых scoped needs. Проверить point/partial/bounds/proxy/interference/sequential, mixed components, explicit precondition versus contextual mention и removal of mode witness. Нельзя приписывать arbitrary context-only упоминанию научную authority.

## 5. Реальные callers, consumers и fail-closed boundaries

Полный **textual name-reference census** выбранных entrypoints по текущему src/**/*.py сохранён в caller_census.json. Это не dynamic call graph и не доказательство отсутствия косвенных вызовов.

- Public DataRequirementCompiler экспортирован data_requirement/__init__.py:57–60,110. normalize_scenario_evidence_contract (`runtime/quality/scenario_evidence_contract.py:197–205`) вызывает compile_for_scenario и проецирует specs/families. generation_cycle.py:14028–14060 инжектирует capability resolver, затем вызывает тот же scenario compiler и сохраняет report. Это настоящие runtime consumers, не tests-only функции.
- compile_for_claim_ledger вызывается самим compiler на :699 и :734. Runtime не найден как прямой producer двухкомпонентного claim input EC-01; остаётся reachability limitation, а не скрытый E2E claim.
- Workspace foundry_consumption.py:1254–1264 использует compile_obligation_basis с ProblemFrame. :1324–1354 строит/сохраняет ClaimDecompositionInput и ledger; :1396–1424 вызывает методический compiler и selector. Он явно проверяет полный method status population (:1426–1440), а satisfied становится **limit**, missing — **block** (:1441–1457). :1251–1253 сохраняет missing source authority после чтения bytes.
- Scientist methods/requirements.py:21–43 предоставляет workflow bridge. Наличие этого bridge само по себе не равно orchestration execution. Foundry selector также реально вызывается producer_pipeline.py:2076–2083 и foundry/validation/method_quality.py:2256. Producer pipeline декларирует boundary_continuity, не domain truth/publication (:1999–2017).
- Fabric Catalog projection (`fabric/catalog/data_requirement_adapter.py:64–75`) исполнялся на полученных generic specs и во всех трёх controls отказал scope_profile_not_established. Его реальные runtime callers — acquisition_planner.py:1989 и data_forge_binding.py:2285. Profile/query/index mismatch defenses проверены отдельно; не утверждается, что этот Catalog gate защищает все независимые Fabric binding APIs.
- Источники model invariants поддерживают guard: ClaimRecord запрещает publishable unsupported high-stakes claim без evidence (`claims/models.py:486–519`); реальные decomposed claims здесь unsupported/draft, LLM cases context-only/blocked. Это structural guard, не доказательство external evidence truth.

## 6. Проверки и границы результата

- `PYTHONDONTWRITEBYTECODE=1 python policyos_deep_audit/next_evidence_composition/probe_evidence_composition.py`: exit 0. Две повторные executions с идентичным results.json.
- Native import command, stdout/stderr и exitcode сохранены отдельно. BLOCKED_ENVIRONMENT для данного Python; dependency install или попыток обходить это ограничение не было.
- Все source-extracted файлы сверены с pinned baseline. Дополнительные source traces, tests и governed JSON приведены в SOURCE_VALIDATION.json/source_excerpts.json. `git status --short` source checkout пустой.
- `validate_evidence.py` повторяет проверку baseline, решающих result predicates и replay identity, не запускает real provider или source modification.

**Не закрыто:** native typed multi-intervention PolicySpec; whole supported package flow; настоящий RequirementToCapabilityResolver с двумя persisted independent capability scopes; Fabric/World ingestion, actual estimator contract/conformance, persist/reopen claim custody, end-to-end protected/public output. Epidemiological/financial/causal validity, real populations/transportability и scientific calibration не проверялись и не выводятся из enum/compiled/status.

**Статус WP-04:** существенно углублён, но не completed qualification. Исследовательский результат достаточен для точной формулировки двух downstream mechanisms и falsifiers; осталось перенести тот же discriminator на поддерживаемый профиль и реальный resolver/persisted consumers. Никакие remediation изменения не сделаны.
