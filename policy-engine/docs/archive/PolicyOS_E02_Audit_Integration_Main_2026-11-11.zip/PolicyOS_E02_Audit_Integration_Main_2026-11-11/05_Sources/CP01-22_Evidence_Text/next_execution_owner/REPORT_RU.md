# Execution ownership: worker, physical cache task и fresh settlement

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Checkpoint17 / W03. Статус **PARTIAL; whole authenticated NL/N5 chain не закрыта**. Source read-only, внешних provider calls, платежей, публикаций, deployment и изменения проекта нет.

## Результат

Новый независимый дефект не установлен. Проверен ранее не исполненный join: **настоящий ControlWorker → SQL attempt/admission → cached TracedLLMClient → отдельный physical producer task → durable budget ledger → свежие SQL/ledger/CAS readers**. Это пять bounded cases с реальными owners, но синтетическими creation principal, handler и offline provider. Whole NL orchestration не заменена этим результатом.

1. Два waiters одной cached операции вызывают provider один раз. Ledger содержит один reported расход 0.25 и отдельное zero-cost reuse событие, оба относятся к исходной attempt1. SQL job завершён; новый процесс читает тот же result artifact и typed job response.
2. Renewal той же lease разрешён. После отмены обоих waiters physical cache owner ещё жив, ledger pending, live handle=1. После offline ответа он сохраняет committed 0.25 и освобождает handle. Повторные `cancel()` уже завершившихся waiters возвращают false: это **не две доставленные отмены одного waiter**, как в BUD-01.
3. После takeover SQL attempt2 старый physical task сохраняет known settlement с attribution attempt1. Owner waiter может получить физический response, но follower reuse emission, новая reuse попытка и старый `complete_job` отвергаются. Это различие между сохранением факта расхода и полномочием публиковать job result, а не обход fencing.
4. Lost acknowledgement после фактической записи settlement корректно восстанавливается readback: один reported расход, committed ledger, никаких повторных physical calls. Соседний provider exception остаётся unknown, job переводится в failed настоящим store, следующий fresh budget admission отказывает.
5. Fresh-process reader действительно открывает сохранённые SQLite, ledger и CAS. Raw fixtures сохранены в этом пакете, в отличие от удалённых temp SQL/CAS в старом tenant probe. Historical bytes не становятся current authorization.

Прежний direct-client **BUD-01 не опровергнут и не исправлен**. Он относится к `_await_direct_provider`; положительный результат здесь принадлежит отдельному cache-owned task. Строгая NL factory включает `require_reuse_authorization=True`; без допустимого snapshot/prepared-call binding она выбирает другой uncached путь. Нельзя автоматически распространять этот PASS на любой NL вызов.

## 1. Новый bounded путь и его границы

`probe_execution_owner.py` исполняет целые canonical `ControlPlaneStore`, `ControlWorker`, `FileSystemCAS`, `TracedLLMClient`, `CachingLLMClient`, `CacheSettlementSession`, prepared request, `BudgetMiddleware`, `FileBudgetLedger`, `ProducerBudgetObserver` и typed Gateway response. SQL schema, transactions, lease/fencing, cache producer task, durable begin/settlement/readback, response codec не переписывались.

Creation envelope собран двумя неизменёнными serializer definitions из `ControlPlaneService`. Principal/roles заданы audit fixture; это **не доказательство authenticated launch**. Worker получает реальную job через `lease_next_job`, устанавливает настоящие fence и interrupt, затем audit handler вызывает `current_execution_job_admission`. Run binding строится из этой admission, не из incoming dispatch hints. Cache guard использует настоящие `require_current_job_execution_owner` и `verify_llm_producer_admission(expected=admission)`.

Handler и provider специально малы. Provider ждёт asyncio Event и возвращает типизированный текст `offline arithmetic: 2 + 3 = 5` со synthetic reported cost 0.25; это не запуск научной модели и не проверка арифметического engine. Tracer/metrics являются no-op collaborators. Handler удерживает event loop до конца physical owner; поведение shutdown/закрытия loop этим не квалифицировано. Реальный `run_coro_sync` и Runtime ThreadPool/GuardedDependencyProxy в этом срезе **не выполнялись**.

Normal/lost-ack handler сохраняет ответ в настоящий CAS как `audit.execution_owner.result`, затем вызывает настоящее `complete_job`. Это **audit artifact**, не `N4CandidateProposalRecordV3`, N5 result, Core terminal manifest или публичная scientific authority. Fresh `ControlJobRecord.to_response()` выполнен; весь HTTP `get_job_status` с normative/current-cost projection не запускался. Cancelled-waiter и takeover fixtures остаются `running`: намеренный stop audit tail, не product lifecycle finding.

В takeover fault injection независимое соединение sqlite3 меняет только expiry audit-owned job, затем второй настоящий ControlPlaneStore выдаёт attempt2. Source clock/lease predicates не monkeypatch-ятся. В lost-ack case только persistence IO обёрнуто write-then-raise; readback/ledger/traced predicates настоящие. Это controlled I/O uncertainty, не физическая потеря диска/процесса.

## 2. Пять различающих outcomes

- **normal:** два успешных waiters, один provider, один reported 0.25 + один reuse 0, SQL completed, fresh CAS content равен writer, fresh budget spent=0.25.
- **renew_all_waiters_cancelled:** renewal=true, strict owner check проходит; перед release оба waiters done, physical task not done, live handle=1, ledger pending. После release live=0, ledger committed 0.25, оба waiters CancelledError. Job running потому что audit не публикует cancelled waiters.
- **takeover:** replacement worker/attempt2; reported 0.25 остаётся attempt1. Owner response доступен как физический факт. Follower получает JobExecutionInterrupted; old SQL complete получает ControlJobLeaseLostError; fresh reuse вызов не добавляет provider calls. Свежая SQL показывает running attempt2, не completed attempt1.
- **lost_settlement_ack:** write-then-raise выполнен один раз; response и zero-cost follower reconciliation проходят, ledger spent 0.25. Новый процесс видит committed события и SQL completed. Это не retry физической работы.
- **provider_failure:** один вызов с ValueError; оба waiters получают тот же failure class. Событие unknown без amount, настоящая SQL failure publication, fresh ProducerBudgetObserver отказывает `control_nl_budget_producer_event_not_settled`.

Все final assertions проходят; probe и fresh reader exit 0, stderr пусты. Ни один exit 0 не является native/release qualification.

## 3. Actual NL → model → N5 → final reader: карта владельцев

Пути относительно `policy-engine/src/polisyos/`; точные spans сохранены в `SOURCE_EXCERPTS.json` и `OWNER_MATRIX.json`.

**Authenticated intake и durable owner.** `runtime/http/routes/control.py:460–507` требует exact BoundActionPermissionVerification и передаёт bytes body/query, principal и idempotency key в launch. `run_lifecycle.py:14920–15177` заново получает SQL admission, очищает ambient context, сверяет payload/capability/intent перед dispatch. Новые probes не вызывают этот authentication producer. Прежний tenant pass подтвердил следующий scope→CAS кусок, но остановился до capability/domain execution.

**Compile/model scope.** `job_nl_admission.py:800–860` связывает real run/job/tenant/full cell/profile/attempt с settlement owner. `job_nl_execution.py:467–628` требует established authenticated scope, producer binding и уже начатый Core context; создаёт current admission callback, producer intent persistence/readback и `_gateway_cache_reuse_scope`. Factory `scientist/orchestration/llm/factory.py:77–200,342–404` закрывает новые admission tickets на scope exit, перепроверяет current admission до/после операции, выбирает строгий cache authorization. Это дополнительные production guards, **не исполненные целиком нашим ручным guard wiring**.

**Physical cached owner.** `prompt_cache.py:850–980,1229–1339` создаёт отдельную owner task, shielded waiter, затем follower re-admission. `_produce` владеет durable begin/settlement/final cleanup; `traced_client.py:1152–1246` читает известный outcome обратно при неопределённом acknowledgement. `budget_middleware.py:436–495` сохраняет binding/attempt из durable begin даже после выхода ambient scope. Это исполненные mechanisms; source-only production composition не смешана с ними.

**Sync/async boundary.** `common/async_tools/__init__.py:785–846` создаёт fresh loop, переносит ContextVars при дополнительном shared worker, при выходе отменяет pending tasks и ждёт gather. Наш probe ждёт cache owner до shutdown, поэтому не доказывает, что owner переживает закрытие loop, hard crash или timeout общего worker. Прежний LIF guard/physical-thread distinction сохраняется.

**N5 financial classification, не execution permit.** `job_attempt_publication.py:1185–1288` выдаёт sealed VerifiedNLJobBudgetScope только после replay request/event/capability/actor/intent и live worker. `run_lifecycle.py:8166–8250` требует exact ControlPlaneService, вновь читает payload/capability/current admission и сравнивает immutable scope identity. `cycle_substrate.py:1181–1261` seal включает full identity + owner object, а currentness переоткрывает owner. Нельзя честно заменить этот producer bare DTO или ручным `_issuer`/`_ISSUED`.

**N5 physical dispatch.** `joint_simulation_horizon.py:1944–2315` различает:
- scope отсутствует: unscoped lower-level path;
- выданный legacy omitted budget field: сохраняется legacy contract без нового physical USD reservation;
- explicit null/hard_total_usd: отказ `n5_physical_usd_reservation_not_established`;
- explicit metered candidate: current issued scope, тот же settlement owner, run/job/tenant/full cell/profile, cap и selected finite quota обязательны.

Затем current spend admission → invocation reserve → повтор scope check → actual numerical operation → completed/failed quota settlement → post-work currentness. Failed settlement даёт outcome_unknown, сохраняет physical observation и при известном completed value переносит его как audit evidence. Post-work lost scope не стирает факт work, но выдаёт `_PhysicalWorkInterruptedError` прежде advance. Exception, BaseException/process death и `reserved` нельзя смешивать: BaseException не ловится локальным `except Exception`, reservation может остаться consumed/pending. Цена N5 в USD не устанавливается количеством invocation units.

**N5 implementation evidence и authority.** `n5_execution_basis.py:993–1198` seal/reconcile связывает observed code/input/result, process session и issuer-held capture. Historical reader и live retention намеренно разные. `acquisition_evaluation_dispatch.py:390–495` дополнительно требует current execution lease/head/phase и live PA2. `run_lifecycle.py:5394–5410,6004–6018,6263–6284` и terminal frontier owner повторяют fence/PA2 у commit tail. Ни новый cache result, ни successful numeric result не заменяет эти authority owners.

**Generic N5 late success.** `generation_cycle.py:6555–6640` переоткрывает exact N5 input/candidate binding; currentness failure превращает joint_simulated в simulation_blocked и убирает usable obligation ref. Это source-traced sibling, не новый runtime proof.

**Terminal/public fresh read.** `job_nl_publication.py:37–255` сохраняет compiled/normative/Core evidence, вновь получает current admission и сверяет persisted owner projection до completion. `run_lifecycle.py:12600–12744` fresh candidate proposal costs перестраивает из historical completed scope, exact Core output, N4V3 identity/attempt, durable ledger и полного producer intent set. Cached progress hints удаляются; отсутствие joins даёт not_established. Наш readback не создаёт этот source: он подтверждает raw SQL/ledger/CAS, не served N4 projection.

## 4. Cancellation — отдельный контракт

`routes/control.py:605–660` требует rollout flag, exact current action proof и cancellation_request_scope. `run_lifecycle.py:12747–12788` ограничивает proof ровно job/full cell. `control_plane_store.py:7162–7344` повторно проверяет authenticated scope, request body, operation_id, expected worker/attempt, serializes на той же job row и связывает event/outbox. Identical retry проходит только по полностью verified persisted receipt; changed identity/terminal/old attempt conflict. Current cancellation authority перепроверяется в commit admission.

Persisted receipt честно сообщает `disposition=publication_fenced`, `physical_stop_status=not_established`. Это не контракт «provider физически остановился». Async waiter cancellation в нашем probe **не является вызовом public cancel_job API**. Никаких permission proofs для теста не подделано. E02 saturated cancellation/retry + late N5 terminal остаются native acceptance.

## 5. Что теперь закрыто и что нет

Улучшена execution-owned settlement граница прежних BUD-01/LIF/tenant reports: cached physical owner плюс actual worker lease и fresh persisted reader. BUD-01 не надо объединять с этой positive sibling; COST evidence не даёт publication permission. MA-01/02 и PA-01/02 касаются другой executable identity/codec границы; cached LLM result и SQL attempt не пинят mechanism kernel FQN/version и не восстанавливают потерянные constraints. Их findings не снимаются.

W03 остаётся открытым: genuine authenticated launch → guarded SQL/CAS hop → full NL compiler → actual N5 seal → PA2 revoke → terminal CAS/SQL → served fresh reader не исполнялся. Native Python3.14/locked профиль, JAX/whole numerical engine, OPA/JWT, snapshot cache reuse authorization и whole Core terminal chain не квалифицированы. Старые native import failures не переиграны; текущее исследование сознательно ограничилось доступным compatibility profile по указанию координатора. Нельзя приписывать native отсутствие всем разрешённым компьютерам.

Следующий meaningful acceptance: native served fixture с настоящим scope issuer и finite offline NCM (существующие test_n5_physical_budget_scope / test_n5_invocation_quota), затем revoke actual SQL/PA2/current implementation, same result historical read остаётся доступен, current retention/terminal publication отказывают. Добавить настоящий run_coro_sync timeout/loop close вместе с физическим late settlement и actual cancel endpoint повтором; не очередной искусственный `_ISSUED` marker и не ещё одна standalone stale-lease проверка.

## 6. Provenance и ошибки instrument

Python3.12.14 / Pydantic2.13.4; inherited compatibility loader меняет только Python3.14 multi-except syntax и TypeVar import, обходит выбранные eager package facades namespace shells. Полные original file hashes/rewrites перечислены. Два serializer definitions извлечены без изменения тела. Предикаты owners не заменены.

Сохранены ранние ошибки audit: первый expiry fault пытался идти через fenced `_execute` и был корректно откатан transaction admission; independent sqlite3 fault введён только в audit temp DB. Второй lost-ack wrapper ошибочно не возвращал результат original persistence после первой ошибки; это дало NoneType и pending reuse. Исправлен только wrapper, итог повторён на новых roots. Этот pending outcome **не product finding**. Третий successful предварительный run сохранён отдельно; финальный добавил настоящий verify_llm_producer_admission и заново исполнил все пять cases на новых roots.

`retained/` содержит финальные offline SQL/ledger/CAS. `attempt01_retained`, `attempt02_retained`, `attempt03_retained` — не deciding evidence. `results.json`/`reader.stdout.json` — deciding outcomes. `SOURCE_VALIDATION.json` связывает все импортированные и выбранные source bytes с pinned Git. `VALIDATION.json`, `MANIFEST.json`, `SHA256SUMS.txt` проверяют evidence, не production readiness. Selected authored-test census только source-read; pytest bodies не запускались.
