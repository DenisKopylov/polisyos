# STATE-01: journal → реальный CAS → SIGKILL → новые readers

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Продолжение checkpoint07 / WP-02; исследован только STATE-01. Исходный snapshot read-only, production и рабочий проект не менялись. Все процессы, CAS, журналы, повреждения и сигналы принадлежат этому изолированному исследованию.

## Результат

**STATE-01 / P2 подтверждён на настоящем tenant-enforced FileSystemCAS, полном RunContext и независимых процессах.** После SIGKILL между durable finalize journal и terminal append recovery создаёт проверенный terminal RunManifest, но не восстанавливает выбранный `scientist.workflow_state_finalization` input. Core reader признаёт корректную terminal run, Runtime terminal reader возвращает `workflow_finalization_ref=None`, а реальный control-job consumer не может выбрать final experiment state и возвращает None.

Это loss of availability / workflow currentness evidence, не authority bypass. Recovery не угадывает transition даже при одном подходящем output. Нет доказательства production incident, неверной policy publication или общего отказа любого recovery.

**Существенное усиление evidence:** прежние RunContext constructor, CAS, selected-profile verification, owner snapshot, strict trace intake fixtures сняты. Реальные CAS bytes/profile, owner claims, cross-process locks, fsynced trace и журнал, Core и Runtime reader выполняются. Остаются Python 3.12 compatibility, синтетические producer payloads и извлечение узкого Runtime control method. Native Python 3.14 / full sync+async engine / HTTP acceptance остаётся PARTIAL.

## Что именно выполнялось

- Полный `FileSystemCAS` constructor и owner/transaction implementation. Основная квалификация использует явные `tenant_id`, `cell_id`, `ownership_enforced=True`; каждый процесс создаёт новый store.
- Полные `RunContext.start`, `update_manifest(control_job_id=...)`, `add_output`, `finalize`; реальные selected owner snapshots, trace writes, finalize lease и journal. Не конструируется fake RunContext.
- Настоящий строгий `WorkflowStateFinalization.create`, его CAS selected profile и linkage через `add_output`.
- Реальный `SIGKILL`, а не catchable exception или только `os._exit`, в отдельных producer-процессах. Marker фиксирует точку и PID перед сигналом; exitcode равен -9. Python finally не исполняется.
- Отдельные процессы before-reader, `recover_pending_run_finalize`, after-reader. Выполняются полный `read_terminal_run`, полный `load_terminal_core_run_source`, настоящий `_terminal_experiment_state_ref_for_control_job` с настоящими bounded CAS reads, actual DTOs и protocol narrowing helpers.
- Ещё четыре одновременно запущенных процесса recovery: один выполняет recovery, трое возвращают None; terminal fact ровно один. Это ограниченный положительный flock/idempotency control, не стресс-тест всех interleavings.
- Публичный `load_core_run` отдельно запускает recovery сам. Его status `ok` не означает, что выбранный workflow transition восстановлен.

## Матрица решающих границ

Основные результаты находятся в `scoped_results.json`, то есть на согласованном tenant-enforced CAS.

| Точка | Recovery / Core read | Workflow selection / control consumer |
|---|---|---|
| Normal | PASS, manifest verified | Сохраняется exact ref, возвращается final state |
| После durable journal, до manifest CAS | PASS, manifest verified | Selection потерян, final state None |
| После journal при двух workflow outputs | PASS | Ни один output не угадывается, selection None |
| Core-only finalize без selected workflow | PASS | None ожидаем и не является дефектом |
| После полного CAS put, до owner-record | PASS | Selection потерян |
| После owner-record, до terminal append | PASS | Selection потерян |
| Непосредственно перед terminal append | PASS | Selection потерян |
| После fsynced terminal append, до journal clear | PASS | Exact selection и final state сохранены |
| Внутри CAS publication: blob уже опубликован, manifest/view ещё нет | Реальный CAS transaction recovery PASS | Finalize recovery затем теряет selection |
| Persistent injected CAS exception, затем новый recovery без fault | PASS | Selection потерян; повтор с ещё активной инъекцией не считается exact-retry доказательством |

Внутренний CAS fault поставлен после настоящего `_publish_transaction_member` для RunManifest blob. Подмена не пишет успешный CAS результат: живой CAS успевает сохранить pending transaction и blob, процесс убивается, следующий owner сам выполняет восстановление. Это не power-loss qualification и не все CAS fault points.

### Положительные и отказные контроли

В `results.json` и `supplement_results.json`:

- Normal и normal с двумя workflow outputs выбирают именно supplied ref; ошибку нельзя объяснить тем, что reader вообще не умеет workflow selection.
- Kill до journal: `recover_pending_run_finalize` корректно не выдумывает terminal факт. Отдельный публичный `RunContext.resume` восстанавливает incomplete owner, затем `finalize` сохраняет selection и Runtime final state.
- Kill после terminal append и после journal clear сохраняет selection. Повторный recovery не дописывает второй terminal event.
- Foreign-owner journal, malformed journal, duplicate terminal, повреждённые RunManifest CAS blob и selected manifest profile отвергаются. Journal сохраняется, trace и journal bytes не переписываются, control consumer не выдаёт final state.
- Partial-terminal fixture: harness записывает половину terminal JSON line, fsync, затем SIGKILL. Recovery fail-closed (`run_finalize_trace_owner_not_established`) и сохраняет journal. Это явно **synthetic short-write fixture**, не наблюдённый torn write ядра/диска.
- Четыре concurrent recoverers дают ровно один terminal fact, но без missing workflow edge. Locking не чинит содержимое journal.
- `load_core_run` после journal-boundary crash возвращает status `ok`; строгий workflow consumer всё равно возвращает None. После terminal-boundary crash этот же autoload path сохраняет final state.
- Отдельный `probe_public_retry_once.py`: первый публичный `RunContext.finalize` получает однократный I/O fault; fault снимается; второй публичный finalize сам восстанавливает journal и получает `run_finalize_workflow_finalization_not_established`. Это уже не private `_finalize_locked` fixture из предыдущего исследования.

## Важный профильный discriminator: не создавать ложный новый finding

Первый, exploratory прогон использовал `FileSystemCAS(root)` со stock default `ownership_enforced=False` при tenant-aware RunContext. После отдельного `record_artifact_owner` retry CAS write получил `artifact_transaction_owner_generation_or_bytes_unverified`. Причина этого профиля видна в `ownership.py`: unscoped transaction с `owner=None` требует отсутствия tenant claims. Его нельзя смешивать с реальной tenant-scoped квалификацией и нельзя объявлять новым production defect.

Полный повтор соответствующих boundaries с настоящим `FileSystemCAS(..., tenant_id=..., cell_id=..., ownership_enforced=True)` устраняет CAS refusal и снова подтверждает исходный missing-selection STATE-01. Runtime constructor source дополнительно показывает штатный `with_ambient_ownership_enforcement_if_supported` (`run_lifecycle.py:7298–7308`). Извлечённый control consumer здесь не выдаётся за весь constructor/guarded-store lifecycle.

Оба результата сохранены, неудобный первоначальный red не удалён и не назван inherited. Профильная развилка полезна: реальный CAS сам по себе ещё не означает правильную квалификацию owner configuration.

## Причина и canonical owners

1. `core/run/context.py:1178–1186`: журнал версии 1.0 содержит только schema_version и RunManifest. Выбранный workflow transition отдельным полем не хранится. Наличие одного или нескольких outputs не эквивалентно выбору.
2. `context.py:3172–3278`: normal finalize знает supplied selected ref и пишет его в `RUN_FINALIZED.refs.inputs`.
3. `context.py:1402–1416,1420–1499`: recovery из journal вызывает `_append_run_finalized_event`, где есть manifest output, но нет selected workflow input. При уже существующем terminal событии исходный selected ref сохраняется.
4. `context.py:1642–1732`: Core terminal owner reader валидирует CAS/profile/owner/trace и возвращает фактические terminal inputs; восстановление отсутствующего input не является его задачей.
5. `runtime/http/services/adapters/core_run.py:225–313`: строгий Runtime adapter признаёт workflow selection только из одного terminal input, связанного с ровно одним manifest output. `load_core_run:316–322` предварительно запускает recovery.
6. `runtime/http/services/control/run_lifecycle.py:14287–14389`: consumer требует этот selected ref и проверяет bounded CAS receipt/selected final state. При потере edge возвращает None. Его алгоритм исполнялся, HTTP authorization и полный service constructor нет.
7. Sync executor (`executor.py:2560–2641`) и async executor (`async_executor.py:~1090–1160`) оба передают exact selected finalization ref в общий Core finalizer. Эта reachability проверена по source; оба full workflow producer не исполнялись.

**Исправлять existing Core journal/recovery owner.** Сохранять exact selected workflow ref вместе с journal request, его selected profile и owner/output binding; восстанавливать тот же terminal edge. Нужны fail-closed совместимость legacy journals и конфликты повторного request. Не ослаблять readers и не выводить selection из количества/порядка outputs. Отдельный parallel recovery subsystem не нужен.

## Границы fixture / compatibility / native

- Доступен Python 3.12.14, не поддерживаемый repo Python 3.14. Native импорт без adapter зафиксирован exit 1: `except TypeError, ValueError` syntax. Никакие зависимости не устанавливались, locked env не подменялся утверждением о native acceptance.
- Loader компилирует source modules целиком, добавляя скобки к Python 3.14 multi-except и импортируя TypeVar из установленного typing_extensions для `default=`. Package facade bootstrap для явно перечисленных namespace packages пропускается. Все изменения только in-memory, полный список в `LOADER_BOUNDARY.json`.
- Runtime control reader и три helper functions извлечены из исходного AST. Остальные Core/CAS/trace/manifest/adapters импортированы полностью. Нет fixture CAS verify, no-op owner registration, synthetic strict trace iterator или заранее заданного consumer результата.
- Registry bundle, workflow spec, prior/final ExperimentState являются синтетическими CAS JSON payloads. Полный registry compiler, ExperimentState model production, numerical/research provider, `WorkflowExecutor`/`AsyncWorkflowExecutor`, ControlPlaneStore job construction/lease и HTTP authorization не запускались. Настоящий typed finalization receipt и его refs присутствуют в CAS; сам upstream workflow ими не был выполнен.
- Tenant/cell/control-job identity в синтетическом RunContext установлена настоящим owner API. Это проверяет source-selected control reader, но не полноту аутентифицированного external route.
- `SIGKILL` проверяет процессный restart, не потерю питания/дискового cache, distributed storage, PostgreSQL или network failure. Нет нового заявления про exactly-once весь продукт.

## Evidence, команды и воспроизведение

Суммарно 34 scenario cases: 20 exploratory stock-CAS, 10 явных scoped-CAS, 3 autoload/resume controls, 1 transient public-retry control. Это **не 34 native/full-engine tests**. Решающий owner/profile вывод берётся из scoped-CAS wave.

- `PYTHONDONTWRITEBYTECODE=1 python probe_finalize_chain.py`: первоначальная wave остановилась после 18 cases на ошибке harness signature в setup corrupt-profile case. Исходные script bytes сохранены как `probe_finalize_chain.initial.py`, exit 1 и traceback сохранены. Произошёл неправильный вызов `_manifest_path_for_ref`, ещё до изменения файла. Исправлен только вызов в audit harness; `finish_initial_matrix.py` закончил cases 19–20, exit 0. Production source не менялся. Текущий основной script содержит однострочную коррекцию.
- `PYTHONDONTWRITEBYTECODE=1 python probe_scoped_cas.py`: полная scoped matrix, exit 0.
- `PYTHONDONTWRITEBYTECODE=1 python probe_supplement.py`: public resume / autoload controls, exit 0.
- `PYTHONDONTWRITEBYTECODE=1 python probe_public_retry_once.py`: restored transient-fault public retry, exit 0.
- `PYTHONDONTWRITEBYTECODE=1 python validate_evidence.py`: проверяет отличающие assertions, source hashes против pinned Git commit, clean snapshot, точные denominators и compatibility boundary. Его PASS означает согласованность evidence о дефекте, не готовность продукта.

Для нового запуска скопировать только audit scripts в **новую пустую sibling-папку под тем же audit root**, сохранив `../source`; outputs намеренно не перезаписываются. Запускать четыре актуальных probe scripts, затем validation. `finish_initial_matrix.py` нужен только для документированного первоначального прерывания и не требуется, если исправленный основной script прошёл целиком. CAS/trace snapshots сохранены под `local_state/` и `scoped_state/`; они могут читаться без повторения crash wave.

## Статус acceptance и следующий falsifier

- Выбранный recovery defect, real CAS, owner snapshots, process death, fresh strict readers и отрицательные каскадные контроли: **FAIL продукта / подтверждён механизм**.
- Native locked Python 3.14, full sync/async producer и полный authenticated HTTP route: **PARTIAL / UNRUN**.
- Production incident, frequency/latency, power-loss integrity и published-policy consequence: **не установлены**.
- Следующая закрывающая проверка: в supported native profile выполнить оба настоящих workflow producer и те же boundary deaths, затем проверить exact selected ref/final state через реальный route. Для будущего ремонта добавить legacy journal и conflicting selected ref cases, не заменяя их output-guessing.
