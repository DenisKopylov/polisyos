# Free-grow, смысл показателей и композиция: углублённый срез

**База:** `f1541ed155f278689be48a8c7ac56c3e200210f7`, 10 ноября 2026, UTC. **Статус: PARTIAL**, не qualification продукта. Исходный проект не изменялся. Все пути ниже относительно `policy-engine/`, если не указано иное. Проверялось исполнение настоящих source definitions в ограниченном окружении, а не только тексты tests. Результат не означает native import, full workflow, реальную загрузку каталога, N5 или публикацию.

## Главные результаты

1. **FG-01: free-growth premise G2 проверяет наличие непустого method_ref, не регистрацию/обнаружение метода.** При фиксированном найденном SKG edge строка `this is not a registered method` и JSON-число `12345` дали `status=pass`, `free_growth_fixture_count=2`. Локальная acceptance-функция приняла оба отчёта. Пустая строка дала fail. Это дефект измерения одного readiness premise, не доказательство прохода всей G2 conformance или утечки publication authority.
2. **FG-02: G1 удерживает поиск по `(repo_root, construct)` без generation в ключе; названный corpus snapshot hash привязан к числу строк, не содержимому.** Source-extracted контроль вернул прежний no-hit после появления synthetic catalog по тому же пути. После контрольного сброса cache данные перечитались. Два различных synthetic состояния с одинаковым row count получили одинаковый reported snapshot hash. Реальный DuckDB/production corpus не запускался.
3. **FG-03: default serious NL path ограничивает metric IDs встроенной taxonomy.** Два новых metric IDs были отвергнуты default canonicalizer и приняты тем же механизмом при явной передаче расширенного MetricRegistry. Изученный runtime caller такой registry не передаёт. Это конкретная недостающая связь между растущим ресурсом и ранней нормализацией запроса, а не основание отключить проверку неизвестных метрик.
4. **Положительные границы:** metric meaning и unit identity не сводятся к числу/label; generic direct-output law fail-closed. Композиция атомов действительно проверяет конфликтующие присваивания до producer и строит individual/pairwise/joint scopes. В проверенных controls замены denominator/population/time/quantity-role и несовместимые записи не прошли.

Доказательства: `results.json`, `probe_freegrow.py`, `probe_stdout.log`, `SOURCE_VALIDATION.json`, `source_evidence.json`, `surfaces.json`. `FG-*` — локальные IDs этого среза, не новые независимо посчитанные SYS-семейства.

## 1. Реальная цепочка declaration → discovery → execution/authority

### C02 runtime capability search

- HTTP producer surface: `src/polisyos/runtime/http/routes/control.py:1022–1068`, POST `/capabilities/search` и GET `/data/catalog/search`.
- Composition owner: `runtime/http/container.py:944–959` связывает `CapabilityDiscoveryService` с providers, operation registry, conformance verifier и policy/approval resolvers.
- `runtime/http/services/control/capability_discovery.py:35–74` создаёт composer. Provider payload повторно типизируется и сверяется с kind/request (`77–110`).
- `runtime/quality/capability_discovery.py:2889–2943` считает **discovery**, **execution**, **authority** отдельно. Discovery rank/metadata не является разрешением исполнять.
- `runtime/quality/capability_resolver.py:187–371`: отсутствие operation registry, неизвестная operation, неверный bound receipt, отсутствие/истечение/отказ conformance и выключенный policy дают отдельные неисполняемые состояния. Только после этих проверок возвращается `executable`.
- Default `resolve_control_registry_providers` (`runtime/http/services/control_registry_providers.py:98–223`) создаёт discovery providers, но live-operation registry/conformance verifier остаются переданными dependencies с default None. `341–352` подключает method search к persisted index, а не компилирует его в HTTP request. Это **не** доказательство default end-to-end execution нового ресурса.

**Оценка:** есть реальная HTTP orchestration и разделение постур. Подтверждение zero-code executable/admitted роста через действительный provider и persist/reopen остаётся **UNRUN**. Перечень resource kinds не объявлен дефектом: это typed ports, не список допустимых method IDs.

### DCAT metric discovery

- `data_forge/domains/catalog/knowledge/types.py:409–426`: `MetricBindingMatch` хранит metric/dataset/distribution/connector/profile IDs, confidence, filters, tier. Это locator/binding candidate, в нём нет quantity/population/unit meaning contract.
- `.../knowledge/store.py:787–858, 861–960`: SQL читает `ds_metric_bindings`, есть exact/alias/lexical поиск, tier filtering и bounded ranking. Новые строки не требуют отдельной ветки по metric ID. Этот факт исходного кода не равен выполненному native data-mutation тесту.
- `runtime/quality/proving_ground/substrate_grounding_search.py:1879–2077`: G1 вызывает настоящие `DatasetCatalogStore`/`DatasetCatalogGraph.search_metric_bindings`, объединяет кандидатов и закрывает readers.
- `1137–1250`: отдельный temp DCAT mutation report маркирует `temp_store_bounded_surrogate`, candidate-only и запрещённые authority purposes. Он не должен выдаваться за production admission.
- `1121–1134`: обычный G1 free-growth report может иметь pass при найденных metric IDs и `free_growth_fixture_count=0`. Поэтому один этот report не доказывает добавление нового ресурса. Это отличается от отдельного mutation path.

## 2. FG-01: G2 report проходит на несуществующем method ref

**Механизм:** `runtime/quality/proving_ground/causal_forecast_search.py:1554–1610` ищет один SKG edge SQL-запросом, затем читает `tests/fixtures/layer3/g2/free_growth_method_registry.json` и берёт первый `str(method_ref).strip()`. Никакого обращения к реальному Foundry registry, callable, ABI или conformance в этой функции нет. JSON fixture в snapshot содержит лишь `method://fixture.synthetic-causal-forecast`.

**Consumer:** `:2191–2229` использует `status=pass` и count≥2 как free-growth/mechanism-generality premise; `tools/quality/validation/check_policy_design_case_layer3_g2_readiness.py:568–571` также проверяет pass. Два элемента разных видов (один edge и одна строка) здесь не доказывают два независимых корректных входа одного механизма. Bundle producer вызывает этот report (`:1706`) и включает его в результат (`:1849`).

**Control:** реальный source report/reducer + реальные temporary JSON bytes; SQL edge и соседние recall/quality predicates специально синтетические. Для непустой неверной строки и wrong-type числа: pass/count=2, local acceptance issues=[]; для пустой строки: fail/count=1 и две issues. Значит решающий predicate является string presence, а не discovery зарегистрированного метода. Отдельный native SQL test не нужен для установления именно этой разницы, но нужен для end-to-end acceptance.

**Severity:** medium, high confidence на локальном measurement gap. **Класс:** P29/P37/P38, deepened_existing SYS-04 (не новый authority incident). Полная G2 readiness не запускалась, и другие gates могут отказать. Нельзя утверждать, что несуществующий метод реально исполняется или получает authority.

**Минимальное направление:** связывать report с actual registry search receipt и execution/conformance evidence в требуемой постуре; denominator generality строить по реально выполненным различным inputs. Сохранить candidate/authority separation. Acceptance: несуществующий и wrong-type method refs должны опровергать заявленную readiness, а два новых правильных ресурса должны пройти один и тот же существующий механизм без новой ветки.

## 3. FG-02: G1 cache и content identity

**Source:** `substrate_grounding_search.py:1879–1898` — `@lru_cache(maxsize=32)` по строке root и construct. Cache hit происходит до `_query_expansion_for_construct`, row count и чтения каталога. В выбранном source/tools census нет вызова cache_clear этого cache. `:2229–2236` хеширует только `{corpus_ref, corpus_path, row_count}`.

**Достижимость:** `build_layer3_g1_bundle:621–679` → search/recall/free-growth producers; реальный CLI validator `tools/quality/validation/check_policy_design_case_layer3_g1_readiness.py:114–133` строит этот bundle. Это proving-ground/readiness путь, не установленный production HTTP cache defect. One-shot process с новым root или новый process не обязан проявлять stale hit; для долгоживущего одинакового root/query эффект воспроизведён.

**Control:** первый вызов при отсутствующем temp file дал no-hit/0; файл появился, synthetic catalog generation стал 1, но второй вызов вернул тот же object и не вызвал expansion/count/store. Контрольный clear дал dataset1/1. Затем synthetic содержимое и возвращаемый dataset сменились, count остался 1: оба reported snapshot hashes одинаковы, тогда как file SHA-256 и candidate IDs различны. Внутри source cache/measurement исполнялся настоящий код; DuckDB и expansion заменены, что явно записано в `results.json`.

**Severity:** medium, high confidence для механизма, medium для operational impact. **Класс:** deepened_existing SYS-03/SYS-04, без механического удвоения на cache и receipt symptoms. Неполная identity допускает неразличимые состояния в provenance, но это не hash collision криптографической функции и не доказанная ложная публикация.

**Минимальное направление:** reuse канонической content/generation identity каталога и alias/index dependencies, связывать с cache key/refresh lifecycle. Не удалять freshness-проверку ради ускорения. Acceptance: addition/removal/same-row-count replacement после warm read; новый reader и тот же process; отдельно source и alias/HNSW changes; historical pinned replay должен сохранить прежнюю identity.

## 4. FG-03: расширенный metric registry не подключён к early serious NL canonicalization

**Source:** `ir/kernel/metrics.py:165–229,311–377,394–452,473+` строит default taxonomy из code-owned defaults/aliases/production/benchmark maps, но принимает явный MetricRegistry. `runtime/http/services/control/nl_pipeline.py:3893–3895` создаёт taxonomy без registry; `4245–4317` рекурсивно нормализует context/plan/stop criteria/constraints/expected outputs и останавливает serious workflow на `unknown_production_metric`.

**Control:** `audit_water_loss_rate` и `audit_school_access_rate` добавлены только в synthetic MetricRegistry. Default taxonomy отвергла оба в strict режиме, expanded taxonomy приняла. Known alias `gross_domestic_product` → `gdp`; неизвестный ID в expanded taxonomy всё равно отказан. Candidate/non-strict canonicalization пропускает неизвестный ID, это не authority grant. В локальной default taxonomy 42 entries; это count конкретно собранного значения, не census всех показателей PolicyOS.

**Оценка:** high confidence в source-traced early gate/bridge gap, medium severity относительно Rule 12. Это не доказательство, что любой новый корректный corpus resource достигает этого caller; полный data registration → HTTP workflow эксперимент **UNRUN**. Сам governance/semantic admission gate необходим. Нельзя просто добавлять очередной hardcoded alias или делать fail_unknown=False для serious режима.

**Минимальное направление:** передавать в early normalization content-bound taxonomy/registry текущего admitted resource scope через существующий owner и сохранять typed refusal для непрошедших meaning/conformance ресурсов. Если finite metric set сознательно является ограничением product envelope, показывать это явно вместо всеобщего free-grow claim.

## 5. Смысл показателей и units: что действительно проверяется

- `ir/kernel/method_metrics.py:43–83` отделяет quantity kind/role, population, axes, denominator, time role, producer contract и output path от numeric value.
- Exact Ex-Ante law (`469–546`) допускается для точного method/version и строго определённого semantic shape. `607–672` разрешает exact value identity только этому смыслу; для ratio/percent существует отдельно ограниченный rational conversion contract.
- `675–708` generic direct-output всегда возвращает unavailable/`registered_method_metric_law_missing`. Размер scalar и caller-declared meaning не становятся наблюдением.
- Runtime consumer `scientist/nodes/builtins/decide/policy_runtime_method_metrics.py:3190–3305` читает content-bound registry/units/graph artifacts и manifest edges; сверяет objective→metric, registry semantics и full target unit. Это не tests-only enforcement.
- Semantic spine (`runtime/quality/semantic_binding.py:3493–3561`) отдельно сверяет concept, jurisdiction, unit, period и geography refs. Наличие match refs само по себе не установлено здесь как научная истинность соответствия.

**Controls:** exact Ex-Ante semantic/unit shape даёт identity. Изменение population, denominator, time role, quantity role, scale или target label даёт unsupported. Ratio→percent adapter существует, но после generic direct-output unavailable converted result тоже unavailable: conversion не повышает недоказанное значение. Это scoped positive safety evidence, не универсальная unit algebra и не scientific validation Ex-Ante.

## 6. Композиция политик: concrete preflight и предел higher orders

`runtime/quality/joint_simulation_horizon.py:3730–3739` проверяет composition до выбора runnable engine. `5384–5400` направляет selected engine в соответствующее binding решение; `5555–5584` объединяет идентичные typed writes и отвергает совпавшие/перекрывающиеся targets. `5587–5613,5665–5683` сначала разрешают реальные paths (включая отрицательные list indices), затем проверяют конфликт. Это исключает простую arrival-order/last-write-wins семантику на проверенном seam.

**Controls:** одинаковые int→int writes и независимые slots приняты; разные значения, int/float, bool/int, parent/child overlap отклонены в обоих порядках. `rates.-1` и `rates.1` одного двухэлементного list правильно столкнулись. Cross-type refusal здесь консервативен и не объявлен багом.

`5372–5381` строит individual + все pairs + all-joint; реальные runs используют это в `2341–2361`. `1002–1077` проверяет полноту typed trajectory scopes/horizon/outcomes; removal joint создаёт missing issue. Для 3 атомов complete set имеет 7 scopes и checked orders [1,2,3]; удаление joint даёт [1,2]. Для 4 атомов complete set имеет 11 scopes и checked orders [1,2], а не обещание всех third/fourth-order subsets (`958–984`). Это честно ограничивает утверждение, хотя all-joint trajectory существует.

**Не проверено:** настоящий coupling authority gate с persisted witness, numerical engine/SCM, semantic independence атомов, legal/resource-policy conflicts, higher-order causality, currentness after restart и итоговый weakest-boundary publication. Pure conflict controls не доказывают все эти свойства.

## 7. Qualification и следующий шаг

Команда: `python policyos_deep_audit/next_freegrow/probe_freegrow.py`; финальный exit=0. Python 3.12.14, Pydantic 2.13.4, NumPy 2.3.5. Supported baseline репозитория Python 3.14; Pydantic вне bound `<2.13`; DuckDB отсутствует. Native product imports/full suites/installed API/UI/deployment не выполнялись, dependencies не устанавливались. Source-extracted modules используют настоящий KernelModel и unit classes; `typing_extensions.TypeVar` адаптирует доступность TypeVar default на 3.12, relative dependencies собраны явно. Это **bounded_probe**, не native_targeted.

Первая попытка instrument упала из-за неинжектированного `hashlib` в G1 namespace; сохранён `probe_stderr_initial.log`. Измеритель исправлен, product не менялся. AST nodes затем компилировались с исходными line numbers. Старый traceback с укороченными offsets не следует использовать как product locator.

Следующий acceptance: готовая supported/locked среда + temp DuckDB/read API, два разных новые metrics/methods через actual owners, ошибочные semantics и conformance, warm refresh и одинаковое количество строк при mutation, полный runtime consumer и persist/reopen. Нельзя на основании данного среза закрыть E1–E7/F1–F7 или все capability surfaces. Frontend pickers, unknown plugin installation, claims free-grow и immutable closed-case replay остаются отдельными **UNRUN**. Исторический audit и эти локальные probes не утверждают актуальность remote main после времени baseline.
