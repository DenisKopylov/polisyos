# PolicyOS: backend → generated client → UI, freshness и test confidence

**База:** `f1541ed155f278689be48a8c7ac56c3e200210f7`. Продолжение checkpoint06/WP-08. Target read-only; audit outputs отдельно. Дата: 2026-11-10 UTC.

## Короткий результат

Проверена не только TS-структура: прослежены восемь конкретных цепочек, исполнены реальные dependency-free generated-client tests и bounded source controls. В этом проходе подтверждены шесть узких механизмов. Ни один не выдан за доказанный production incident.

1. **FE-01:** поздний auth refresh может вернуть старый токен после очистки/замены сессии; rejected fetch оставляет `refreshing`.
2. **FE-02:** действующий generated `downloadArtifactContent` парсит raw bytes как JSON. CSV response даёт `SyntaxError`; тот же transport с `arrayBuffer` возвращает точные bytes.
3. **FE-03:** reference shell вставляет API node alias в `innerHTML` без экранирования. HTML sink подтверждён; выполнение в браузере не подтверждено.
4. **FE-04:** в reference shell поздний ответ от прежнего API origin заменяет результаты нового origin. Catalog proof защищён client-identity guard, остальные handlers нет.
5. **FE-05:** настоящий runtime-api-client architecture check падает на устаревшем file allowlist и regex, считающем fixture/template строки настоящими imports.
6. **FE-06:** настоящий MACHINE-twin parity checker пропускает смену `state=refused` на `supplied` и смену `owner_surface`. Изменённый reason он корректно отклоняет.

**Положительная evidence:** 19/19 actual generated-client transport tests и 2/2 reference proof tests прошли на доступном Node 24. В полном type-erased recovery module stable idempotency key переживает новый repository instance и перестановку полей, changed unresolved intent отклоняется, другой tenant не читает запись, unknown scope не пишет в port, release требует точных body/key. Это in-memory port, не browser IDB.

**Verdict:** PARTIAL для всей API→UI цепочки; FAIL для перечисленных bounded свойств/локального architecture check. Node 22/frozen toolchain, dashboard TypeScript/Vitest/build, живой backend и browser acceptance не получены. Audit task не превращает эти UNRUN в PASS.

## 1. Реальная схема producers и consumers

Canonical API source: backend DTO/routes → `export_runtime_openapi` → `schemas/runtime_api_v1.openapi.json`. Здесь не исполнен текущий runtime export: Python 3.14/locked backend отсутствует, как установлено `next_native`.

Две generated type families используют один `packages/runtime-api-client/scripts/generate-openapi-types.mjs`:

- `packages/runtime-api-client/types.ts`;
- dashboard `src/api/types.ts`, дополнительно форматируемый Prettier.

После удаления только trivia и явно перечисленных formatting separators обе snapshots содержат одинаковые **105 986 tokens**. Это опровергает перенос старого комментария в `useRunAuthorityValues.ts` о «1504 lines stale» на текущие bytes. Это **не** TypeScript compiler resolution, semantic type equivalence proof, успешная регенерация или соответствие сегодняшнему backend export.

В runtime есть не два взаимоисключающих мира, а действующая смешанная схема:

- основной dashboard transport: `openapi-fetch` + local generated types + `authAwareRuntimeFetch`;
- пять production constructor sites dashboard используют package `RuntimeApiClient`: authority values, acquisition routes, confidence-ledger risk spend, depth-N cycle board, epoch staleness;
- reference shell непосредственно импортирует canonical JS client;
- Atlas UI берёт owner DTO types из package, но не должен приобретать право выполнять API/domain actions.

Generated class не обещает все OpenAPI operations: stdlib generator имеет явный POST operation selector; NL launch использует `openapi-fetch`. При проверке точного generator `_extract_operations` получили 109 выбранных operations. Оба объявленных binary-success paths перечислены в `generator_modes.json`: human-decision evidence правильно получает `array_buffer`, artifact download ошибочно `json`.

В архитектуре уже есть output-family owner, temporary output root и drift guard. Не нужен третий API generator. Native generation требует Python3.14 `.venv`, Node22 и frozen dependency links. Здесь они не подменялись случайными установленными пакетами.

## 2. FE-01: сессия не отбрасывает устаревший refresh

**P2, высокая уверенность в механизме; реальный account-switch path не доказан.**

`authSession.ts:134–234` публикует результат `performRefresh` без generation/epoch проверки. `clearAuthSession` и `setAuthAccessToken` (`:248–263`) меняют только state, не отзывают текущую promise. `.finally` (`:270–272`) очищает reference, но не выполняет failure state transition.

Полный source module исполнен после Node24 TypeScript stripping. Заменены только logger import, Vite env, browser-origin/CSRF fixture и fetch. Тела решений не переписывались:

| Контроль | Результат |
|---|---|
| Обычный успешный refresh | `authenticated`, fixture token A |
| Pending refresh → clear → поздний A | `expired/null` становится `authenticated/A` |
| Pending refresh → установить B → поздний A | B заменяется на A |
| Fetch бросает network TypeError | promise rejected, state остаётся `refreshing` |

Существующие `authSession.test.ts` проверяют concurrent single-flight и однократный 401 replay, но не эти interleavings. Эти хорошие свойства следует сохранить.

Связность с UI: AuthSessionProvider экспортирует clear/set/refresh; RuntimeApiProvider при `expired` переводит к login. Однако external/dedicated login обычно делает полный navigation и сбрасывает JS realm. В прочитанном production UI не найден текущий caller explicit `clearSession`/`setAccessToken` помимо provider exposure. Поэтому не заявляется воспроизводимый UI logout bypass, cross-tenant access или обход серверной authorization. Network rejection на обычном automatic refresh, напротив, достигается через настоящий transport path.

Соседний residual: `queryClient` singleton, `authMe/runs/capabilities` и многие query keys без tenant/session epoch; общего auth-change cancel/clear owner не найдено. FeatureFlag cache и local non-authority persistence отдельно scoped. Этот source risk требует in-document identity-transition test и не оформлен ещё одной доказанной утечкой.

**Минимальное направление:** один session generation owner, suppression поздней publication и replay после reset/switch, settlement rejected fetch/JSON errors. Нужны delayed-positive, clear/switch, rejected/malformed refresh и current-user cache tests в настоящем React/query lifecycle. Не менять серверные permission gates ради UI recovery.

## 3. FE-02: raw download теряется между schema и generated client

**P2, высокая уверенность; defect package contract, не доказанный dashboard outage.**

`routes/artifacts.py:1347–1461` возвращает raw `Response(content=payload, media_type=manifest.media_type)` после ownership, manifest/profile и admission guards. OpenAPI success содержит одновременно пустой `application/json` schema и `application/octet-stream` binary declaration.

`generate_runtime_client.py:264–295` выбирает `application/json` раньше binary. Точный stdlib module import под Python3.12 дал для download `response_mode=json, response_type=unknown`. Это нормальный import этого standalone генератора, не всего product runtime.

Canonical `downloadArtifactContent` (`canonicalRuntimeApiClient.js:113–118`) не передаёт `arrayBuffer`; общая `request` вызывает `response.json()`. Actual ESM import класса с synthetic CSV Response воспроизводит `SyntaxError`. Positive discriminator: тот же исходный client/request, те же bytes, explicit `arrayBuffer` сохраняет точные bytes.

Ни в dashboard production source, ни в reference shell не найден вызов этого конкретного download method. Shell использует content preview; backend actual byte/CAS admission здесь не исполнялись. Для JSON артефакта parse может пройти, но raw-byte API всё равно не гарантирует точную byte representation после object decoding.

**Направление:** исправить canonical OpenAPI representation и generator mode selection; регенерировать обе families. Не делать private per-consumer decoder patch. Regression должен включать text/CSV или binary bytes, правильный MIME/Accept, denied response и отдельно conditional 304 behavior. Не объявлять это полным HTTP test до native backend запуска.

## 4. FE-03 / FE-04: diagnostics shell остаётся незащищённым consumer

Reference shell README честно называет его узким diagnostics UI, не product dashboard. Его scope нельзя автоматически перенести на React UI.

### FE-03: API data → HTML

`app.js:138–192` строит runs, timeline rows и node graph через template interpolation + `innerHTML`. `RunNodeRecord.alias` (`core/contracts/runtime.py:8420–8438`) имеет тип string; consumer не экранирует его как текст.

Exact complete `app.js` body исполнен с настоящим generated client и proof helper, но synthetic DOM write recorder/fetch. Вставленный alias `<img ... onerror=...>` доходит до HTML sink как markup. Plain `safe-node` положительный контроль проходит. Никакой event handler в настоящем браузере не исполнялся, никакой payload в реальный backend не загружался.

Локальный Chromium probe был подготовлен с localhost source serving, synthetic API route interception и запретом внешних requests. Он **не стартовал**: Chromium SIGABRT, `socket() failed: Operation not permitted`, до загрузки страницы. Retry/permission обход не предпринимались. `reference_browser.stderr.txt` сохраняет реальную границу. Это UNRUN browser layer, не failed application test.

**P2.** Установлен injection sink; exploit reachability, реальный authenticated producer path и последствия не измерены. Использовать DOM textContent/createElement, уже безопасный `setJson` сохранить. Нужен supported browser test на literal text и harmless injection sentinel.

### FE-04: старый API origin заменяет новый

Catalog proof `renderGovernedProjectionCatalogProof` (`:94–108`) корректно сверяет `state.client !== client`. В list/timeline/debug/artifact handlers (`:206–284`) такой проверки нет.

Discriminator на exact app body: pending request к A → connect B → запрос B завершён и отрисован → приходит A. Selected base остаётся B, runs table становится `late-origin-A`. Это async publication/state attribution defect, не серверная tenant-isolation failure. Synthetic DOM не проверяет layout/browser event semantics, но сохраняет исходный async control flow и реальный transport class.

**P2.** Распространить существующий selected-client generation guard и отдельный latest-request identity для same-origin repeated loads. AbortController может экономить ресурсы, но один abort не заменяет suppression позднего completion.

## 5. FE-05: architecture gate не соответствует текущему package

**P2, реальный command exit 1 на неизменённых sources.**

`node packages/runtime-api-client/scripts/check-architecture.mjs` из package cwd сообщает:

- не allowlisted `scripts/generate-openapi-types.mjs` и его test;
- canonicalizer импортирует актуальные `node:util`/`typescript`, отсутствующие в expected list;
- regex также «находит» `${COMPONENTS_MODULE}`, `./remote.js`, `./types.js` и escaped pattern из тестовых/template strings.

Это не вопрос missing dependencies: скрипт использует только Node builtin fs/path и был действительно исполнен. Node24 не выдаётся за supported Node22 profile, но наблюдение regex/file list непосредственно связано с source.

Declared local `lint-full` использует `frontend_npm_runs` для архитектурных scripts. Root Standard workflow непосредственно вызывает dashboard architecture check, не package script; nested architecture/generated probes имеют свой scope. Поэтому здесь не заявляется свежий hosted CI failure этого конкретного script.

**Направление:** обновить finite surface inventory, использовать уже имеющийся TS AST import traversal вместо regex по произвольным string bytes. Positive true-import и negative literal-fixture controls обязательны. Простое расширение regex allowlist шаблонными строками не чинит измеритель.

## 6. FE-06: parity сравнивает не все semantic fields

**P2, высокая уверенность в false-green oracle; не доказан divergent public artifact.**

`authorityValueTwin.ts:69–125` считывает DOM `state` и `owner_surface`, но `passed` зависит только от ID membership/order, reason и refusal_code.

Полный source module исполнен после type erasure с минимальным synthetic DOM attribute reader:

- unchanged member: PASS;
- тот же member, `refused → supplied`: **PASS**;
- тот же member, другой `owner_surface`: **PASS**;
- изменённый reason: FAIL, правильный negative control.

Существующие tests проверяют drop/invent/order/reason/code и отсутствие aggregates, но не state/owner corruption. Это реальные полезные tests, а не «все assertions фиктивны».

Серверный producer сейчас отдаёт полный unique inventory из **11 typed refusals**, а не вычисленные supplied authority values. Readiness/scientific panels прямо показывают Unavailable и server reasons, не выдумывают score. Потому checker defect не означает, что текущий продукт уже опубликовал supplied verdict. Hook сохраняет producer partition; malformed/currentness/tenant transitions требуют отдельных tests.

**Направление:** расширить существующий comparator на все передаваемые meaning-bearing поля и добавить независимые corruptions. Envelope run/surface/schema identity надо проверять на соответствующей границе отдельно, не выводить из совпавшего row count.

## 7. Что уже хорошо в выбранных пользовательских цепочках

Полная path/test/guard матрица: `FLOW_MATRIX.json`.

### NL launch → durable recovery

Composer и clerk получают established tenant/cell/user из Authz. `useLaunchNlRun` сначала вызывает recovery claim, затем отправляет exact stable `Idempotency-Key`; различает attempt header и явный `not_created`. `useControlPreAdmissionRecovery` не освобождает request key от простого отсутствия server row. Repository сохраняет digest/opaque key, не body/token, сверяет owner binding/history/sequence.

Новый bounded full-module probe (`launch_recovery_results.json`) подтверждает stable key при новом instance и перестановке JSON fields, changed-intent refusal, tenant partition, unknown-scope no-write и exact no-attempt release. Port in-memory, WebCrypto настоящий Node24. Default IDB import заменён throwing sentinel и не вызывался. Persisted browser restart/cross-tab atomicity, provider completion и end-to-end server evidence этим не доказаны.

Written tests дополнительно разбирают unavailable producer observation, malformed history, foreign owner/run/job, terminal states и exact event extension. Их existence отдельно от свежего успешного native исполнения.

### Capability search → candidate/frontier → UI/MACHINE

`useCapabilitySearch` использует generic owner search request, strict response schema, captured raw bytes и index-version server epoch. Evidence panel отображает candidate/discovery/execution/authority отдельно, incompleteness reasons и index freshness, умеет отдавать exact captured MACHINE bytes. Error при retained data подавляет packet, а не превращается в live complete result.

Fixed app chrome и surface icons не объявляются resource allowlist. Generic capability results действительно рендерятся из owner payload. CommandPalette sibling берёт `.data` без такого же error suppression, но только ведёт на evidence route, не исполняет capability. Это weaker stale-navigation posture, не самостоятельное доказательство authority bypass.

Существующий real free-growth test отключает MSW и требует owner-generated capability ID. Но он `describe.skip` без `DS10_CAPABILITY_BASE_URL` и `DS10_CAPABILITY_GENERATED_ID`. Эти variables не настроены в checked root workflows/tools/dashboard scripts. Ordinary green Vitest/coverage не доказывает real owner-index → UI growth. Hosted environments и historical invocations здесь не проверялись.

### Epoch/acquisition → fresh authority and replay

Package client bridges сохраняют raw response bytes. Epoch consumer проверяет request run ID/replay semantic hash и согласованность parsed generated response с captured bytes. Governed query `never_cache_authority` запрещает initial/placeholder authority, ставит stale/gc zero и убирает query при paused/refetch-error. Acquisition flow перед execute re-fetch-ит и сравнивает exact route, проверяет same-case receipt/job и ограничивает duplicate execution.

Эти controls следует переиспользовать по их purpose, не заменять универсальным permissive cache. Source review не выдаётся за actual React/Query observer или backend accepted execution.

### Cancellation → public response → нынешний UI

Schema и generated class сохраняют `cancellation_disposition=publication_fenced` и `physical_stop_status=not_established`. Actual transport tests проверяют exact request и denied response. Dashboard `useControlJobStatus` polling прекращается вне pending/running; отдельного dashboard cancel action и специального display physical-stop field не найдено.

Это явный **не замкнутый UI consumer**, не утверждение, что «Cancel успешно остановил process». Permission `jobs.cancel` намеренно deployment-only; не следует добавлять его обычным ролям ради UI completeness. Backend Rego mismatch уже принадлежит `next_auth`, а не новому FE defect.

## 8. Structure, reuse и test/CI denominator

**Пять workspace manifests** по актуальному `pnpm-workspace.yaml`: dashboard, reference shell, runtime-api-client, atlas-ui, cli. Декларативный `frontend_workspaces.toml` перечисляет четыре без atlas-ui; это map lag для дальнейшего owner consistency review, не доказанная build exclusion: pnpm wildcard всё равно включает package.

- Atlas UI уже владеет базовыми Button/Card/Badge/Command, virtual list/table, JsonPreview, DetailLayout/FilterPanel. Dashboard shared UI содержит domain presentation/adapters, а не обязательные клонированные copies этих primitives.
- `sharedUiArchitecture.test.ts` содержит реальные corrupt import/export/dynamic-import controls и разрешает app-owned adapter к typed presentation props. Такие границы ценнее общего flatten/`utils` refactor.
- Повторённые origin resolution, `Request` adaptation и `clone().arrayBuffer()` в package-client bridges подходят для маленького общего transport helper. Feature-owned admission/hash/replay/cache decisions должны остаться у своих owners.
- Auth refresh, QueryClient и identity-scoped persisted state нельзя механически склеивать: у них разные lifetimes и authorization semantics. Нужна явная session epoch propagation.
- Переключение всех consumers на один client допустимо только после parity headers, errors, binary modes, AbortSignal, generated method coverage и raw-byte retention. Нынешний class даёт generic Error, dashboard adapter даёт typed RuntimeApiRequestError; простая замена меняет retries/error UX.

Root Standard CI содержит отдельные dashboard quality/a11y, Storybook, contract drift/build, smoke и unit coverage jobs. Coverage job отделён от red predecessor checks и включает browser-mode confidence-ledger tests. Это положительный execution design, но здесь не исполненный CI.

Численный `coverage-scope.json` охватывает selected hooks/features/layout/shared UI, **не** authSession/authz/providers или package-local suites. Эти tests могут быть исполнены Vitest, хотя их implementation files не входят в coverage denominator. Поэтому процент coverage не описывает весь frontend.

Workspace recursive `test` и `test:smoke` существуют. Root workflows не вызывают прямо все package test scripts; transitive Python/native probes не объявляются автоматически эквивалентными всем package tests. Native collection, full suite execution и generated freshness остались UNRUN. CLI проверен только по manifest/styleguide scope; полное CLI/Atlas behavior, visual/a11y/responsive и все dashboard surfaces вне semantic depth этого прохода.

## 9. Исполнение, точные blockers, integrity

| Проверка | Статус |
|---|---|
| Actual `runtimeApiClient.test.mjs` | 19 PASS, Node24 |
| Actual `governedProjectionProof.test.mjs` | 2 PASS, Node24 |
| Runtime client architecture | FAIL exit 1, FE-05 |
| Reference-shell architecture | PASS exit 0, узкий файловый/import scope |
| Boundary auth/download probe | exit 0, observed negative cases подтверждены |
| Source reference-shell sink/race probe | exit 0, synthetic DOM, не browser |
| Authority twin parity probe | exit 0, false-green mutations подтверждены |
| Launch recovery module probe | exit 0, positive/negative controls, in-memory port |
| Actual standalone generator response selector | выполнен Python3.12/stdlib, binary mode mismatch |
| Chromium browser attempt | BLOCKED/UNRUN: launch SIGABRT socket permission, до page load |
| Node22 frozen links, tsc/Vitest/build/generation | UNRUN: отсутствует supported installation; ничего не установлено |
| Native runtime/server/OPA/live deployment | UNRUN, прежние границы `next_native` сохранены |

`SOURCE_VALIDATION.json`: **1 556** existing baseline paths под apps/packages/.github и selected backend/schema/tools имеют прежние SHA-256, git status clean. Это integrity denominator, не число semantic-reviewed или fully-tested files. Не пересчитывался общий «процент готовности».

Никаких source/lock edits, installs, commits, CI dispatch, real provider operations или production data access. Browser attempt создавал лишь временный local process/profile, завершился до приложения. Новые файлы только в `next_frontend_contracts`.

## 10. Следующий bounded acceptance

1. В уже имеющемся разрешённом Node22/frozen workspace выполнить actual auth deferred-completion tests, generated raw-byte tests, semantic twin corruptions и existing relevant Vitest. Не прятать dependency installation внутри аудита.
2. Node22 package architecture gate и TS AST controls; затем current backend OpenAPI export и native generated-family output comparison. Lexical snapshots comparison это не заменяет.
3. React/query integration: same QueryClient session/tenant change, retained data + 403/offline, older navigation/repeated requests, NL uncertain outcome/remount. Настоящий IDB/cross-tab отличается от Map fixture.
4. Actual capability owner server + newly generated resource + generic UI + exact MACHINE export, с обоими DS10 variables и явным результатом live test. Отдельно incomplete/stale frontier и unavailable owner.
5. Browser shell text/injection and origin-switch controls в разрешённом профиле. Не обходить заблокированную Chromium process boundary. Product dashboard UI/full a11y отдельно.
6. Cancellation UI wiring лишь если этот scope требуется продуктом: сохранить publication fencing отдельно от physical-stop unknown, не делать unsafe retry/new launch и не ослаблять deployment permission model.

Артефакты: `FINDINGS.json`, `FLOW_MATRIX.json`, `GENERATED_CHAIN.json`, `REUSE_DECISIONS.json`, `COVERAGE_AND_LIMITS.json`, source excerpts, actual command logs, bounded probes/results и manifests. Этот targeted pass завершён как частичная квалификация; полный аудит и remediation не объявлены завершёнными.
