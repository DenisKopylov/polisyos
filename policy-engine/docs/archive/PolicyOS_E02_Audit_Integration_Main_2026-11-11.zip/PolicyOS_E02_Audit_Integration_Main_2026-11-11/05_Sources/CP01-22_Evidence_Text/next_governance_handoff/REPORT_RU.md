# Scientific decision → normative → governance: реальные границы передачи

База `f1541ed155f278689be48a8c7ac56c3e200210f7`, read-only. Продолжение W01 из `next_coverage_16`; использованы сохранённые результаты `next_method_execution`, `next_decision_path`, `next_policy_assembly`, `next_publication_authority` и их review. **Итог PARTIAL. Новых подтверждённых defect IDs не присвоено.** Вместо повторения DiD/нулевых весов выполнены новые consumer joins, полный ObjectiveStack, реальные отрицательные safety/Legal controls и fresh-reader.

## Результат сразу

1. **ME-O1 уточнён полным ObjectiveStack.** Реальный сохранённый `assumption_failed` с point=50 даёт `feasible=false`, blockers `statistical_constraint` и `transport_constraint`. Оба прежних успешных DiD reports тоже остаются не допущенными по этим constraints при собственном fallback envelope. Это не научное опровержение оценок: numerical estimation и admissibility различаются.
2. **feasible не означает selectable.** Явно синтетический низкий Search uncertainty DTO может сделать failed report `feasible=true`, даже без governance report или с `human_gate`. Но все девять vectors имеют `score_assessment=not_established`; после реального CAS и нового процесса `legacy_scalar_proxy_for_search()` возвращает `(None, not_established)`, `runtime_score_available_for_search=false`. Counterfactual низкое uncertainty не выдано за настоящее admission.
3. **GH-O1: actual нормативный consumer не сверяет provenance с текущими inputs.** Один и тот же сохранённый positive result продолжает давать промежуточный `approve`, если заменить текущие metrics на retained negative metrics либо Trinity+metrics на right/budget-blocked case. Когда выбирается соответствующий свежим inputs сохранённый result, outcomes становятся `needs_revision`/`reject`. Это новый bounded source-currentness witness; **не выполненный full-engine bypass и не publication**.
4. **Production evaluation safety не пропускает голые labels.** Одиннадцать whole-predicate controls отвергают отсутствие context/WMR, foreign owner/population, изменённые metrics/WMR, незаявленный governance input, consumer-asserted provenance и чужой «verified» receipt. Exact typed fixture доходит до verifier, но не проходит без настоящего Runtime-owned issuance.
5. **Legal positive chain ограничена самим pin.** Полный Lex authority builder сохраняет `legal_source_relation_verification_not_established` даже при полных синтетических norm/competence facets и asserted receipt. Eight required-authority cases не выбирают норму. `out_of_scope` control не требует authority и не создаёт её. Current legal source-relation owner прямо не имеет positive issuance path.
6. **Persisted governance verdict не становится current только от правильного ABI.** approve/reject/human_gate v1 reports читаются owner reader и проходят CAS integrity, но actual currentness resolver возвращает `governance_report_source_unbound`. Foreign selected ref даёт stale. Это не повтор прежнего publication private-draft defect.

## 1. Это не одна линейная цепочка

W01 нужно разделить по существующим consumers, а не рисовать artificial full end-to-end:

- Scientific `run_causal_evaluation` производит causal report/envelope. Предыдущая wave реально исполнила kernels и сохраняла reports; job/engine admission там не исполнялись.
- `resolve_policy_runtime_request` читает candidate, causal/distributional reports, search uncertainty и **current** governance report. Production backend сначала вызывает evaluation safety, затем metric projection и ObjectiveStack. Это policy search/evaluation path.
- Normative workflow получает **Trinity, Metrics, SimulationResult, distributional и LegalReport**. Его declared `state_reads` не содержит causal report или PolicyEvaluationVector. Causal node является scheduling dependency в `policy_verified_workflow_spec`, но это не доказывает передачу causal report в normative utility formula.
- `RunGovernanceNode` выполняет runtime passes, normative verdict composition, claim projection и применимый Phase2 tail. Полный report получает engine invocation binding, если node действительно вызван engine; direct calls остаются v1 candidate reports.
- Publication и operational approval имеют собственных owners. Default unappointed claim root, institutional mandate и publication custody из предыдущего среза не были заменены или переиграны.

В этой wave **не проводили point=50 через искусственно соединённый normative workflow** и не называли harness-created Metrics научным симуляционным producer. Objective bundle metrics заданы instrument как численный discriminant; causal report взят через настоящий persisted reader, но causal идентификация fixture не получена.

## 2. Actual ObjectiveStack и выбор

`probe_handoff.py` импортирует весь `scientist/policy_design/objectives.py`, включая ObjectiveStack, PolicyEvaluationVector и source score predicates. Выполняются настоящие typed candidate/Trinity/budget contracts. Retained causal refs читаются из `next_method_execution/cas` и `status_cas`; исходные численные methods не запускаются заново.

Девять cases:

- genuine failure, standard success и staggered success с собственным uncertainty fallback: statistical+transport violations;
- consumer-asserted uncertainty=.1 по всем типам + approve: feasible;
- тот же DTO без governance: feasible;
- тот же DTO с reject: compliance violation + `governance:verdict_reject`;
- тот же DTO с explicit BLOCKER: compliance violation + конкретный blocker code;
- human_gate не трактуется ObjectiveStack как reject;
- отсутствие budget envelope даёт ratio=0 и не блокирует этот extractor.

Последние три свойства **не установлены как authority defects**. Это finite mathematical extractor с отдельным source-score contract. Readable scalar property существует, но actual source-bound search API отказывает во всех cases. Полные search funnel/Pareto/training consumers здесь не запускались; их source-bound callsites перечислены отдельно.

Budget control использует USD allocation9 / envelope10, near_binding. Typed candidate allocation11 отказывается ещё до ObjectiveStack. Мы не выдаём это за полную feasibility многоресурсного бюджета: смешанные валюты, periods, jurisdiction, actual fiscal stock→deficit, оптимизация joint allocations не исполнялись. PA-02 wrapper codec из policy assembly не повторяется и не снимается.

Vectors сохранены через реальный `FileSystemCAS.put_json`, с контрактом source writer: schema1.2 без method_metric_observations, `CanonSpec(forbid_floats=False, exclude_none=False)`, selected profile. Это **harness вызов Core writer с source-shaped metadata**, не whole `persist_policy_evaluation_vector_to_store_impl`/completed work packet. Canonical strict typed reader выполняется; новый процесс читает те же refs и проверяет integrity и невозможность search score admission.

Первый instrument неверно использовал default exclude_none=True и schema1.3, отчего обязательные nullable поля dataclass исчезли и Core reader отказал. Actual source writer явно использует exclude_none=False; после исправления только instrument roundtrip проходит. Поэтому этот отказ **не product finding**. Начальный log сохранён. Отдельная ошибка instrument с property `constraint_statuses` тоже исправлена, не приписана продукту.

## 3. GH-O1: сохранённый normative result и текущий source расходятся

Provenance настоящего producer содержит IDs Trinity, metrics, simulation, distributional, legal и uncertainty refs. Manifest также сохраняет input edges. Эти refs существуют и доступны: это не fabricated JSON-only result.

Новый probe в отдельном процессе использует ранее сохранённые ordinary/rights/budget cases. Ни zero coefficients, ни zero weights не участвуют. Actual `NormativeArbitrationPass` и полные unchanged функции `_resolve_governance_verdict`, `_load_normative_arbitration_result`, `_apply_normative_verdict`, `_normative_selects_revision` читают result из настоящего CAS.

- Current positive inputs + matching positive result → approve.
- Current negative metrics + прежний positive result → metrics provenance mismatch, но тот же approve.
- Matching negative result → needs_revision.
- Current right-blocked Trinity/metrics + прежний positive result → mismatch, но approve.
- Matching right-blocked result → reject.
- Current budget-blocked Trinity/metrics + прежний positive result → mismatch, но approve.
- Matching budget-blocked result → reject.

Source объясняет наблюдение: `NormativeArbitrationPass._resolve_result` валидирует result DTO через generic artifact resolver, затем проверяет только audits/completeness/dissent/selection внутри result. `_load_normative_arbitration_result` не сравнивает source refs. В actual `_run_governance_checks` pass context вообще не передаёт `inputs`/`reports_index`; он передаёт artifacts и params. Более широкий `GovernanceReport` currentness защищает собственную invocation/current read projection, но это **не пересчёт relation между выбранным normative result и его собственными producer inputs**.

Почему observation, а не новый confirmed bypass: прямой consumer test намеренно сохраняет старый result selector при изменении current source. Actual engine state transition, execution plan/scheduling, полная pipeline и final current report issuance при таком изменении не выполнялись. Другие passes могут дать независимый blocker. Нельзя переносить intermediate approve на публикацию. Existing source_currentness owner остаётся правильным кандидатом для переиспользования; следующая проверка должна воспроизвести такую смену через настоящий engine, а затем выполнить remove-one-input controls до final consumer.

## 4. EvaluationSafety: exact binding и чужой receipt

`probe_safety.py` исполняет целиком unchanged `_production_policy_evaluation_safety_blockers_impl` с настоящими PDC DTO/hash/receipt predicates. Использованы целые typed fixture constructors из repository tests, а не fake success callback. Они создают **синтетический**, не реально институционально admitted WMR/intake/context. Native whole backend не запускался.

Контекст связывает actual input hash set и уникальные identities с provenance; candidate ID/hash, population hash, WMR ID/hash/schema, evaluator owner, aware time, rule version, mode и recomputed attempt class также load-bearing. Изменение одного input при сохранении контекста блокируется. Добавление `GovernanceReport(approve)` без нового bound input тоже блокируется. Exact fixture без verifier получает `verifier_unresolved`, то есть проходит более ранние проверки. Source test `_ForeignPositiveVerifier` возвращает **обычный публичный** verified DTO; настоящий `evaluation_safety_consumer_admission_is_verified` его отклоняет с `consumer_admission_blocked`.

Private mint/token не вызывались и не подменялись. Genuine verifier получает свежий challenge и должен вернуть producer-owned receipt, exact context hash/nonce/consumer identity; его Runtime path выполняет свои authority/currentness checks. Это safety для **попытки evaluation**, не автоматическое доказательство causal validity, legality of recommendation или publication.

## 5. Legal authority и uncertainty: точные незакрытые links

### Legal

`probe_legal.py` исполняет полный Lex `build_legal_authority_report` и его настоящего legal source-relation owner. Полные norm fields — repository synthetic contract fixtures, не утверждения о действующем праве Украины.

Cases: complete candidate, no candidate, foreign jurisdiction, missing source provenance, expired window, wrong competent actor, LLM candidate и произвольные asserted receipt/verified поля. Все required-authority cases дают fail и пустые selected_norm_refs. Противоположный out_of_scope case не требует legal authority и не создаёт norm selection. `require_legal_source_relation_verification()` выдаёт настоящий typed refusal.

В pin `data_forge/domains/legal/source_relation.py` допускает только `verification_missing/search_candidate`. Exact quote не доказывает полную SPO relation. Lex `_evaluate_norm_for_segment` добавляет этот blocker до competence checks. Runtime `claim_registry` отдельно очищает selected norm/authority refs и сохраняет candidate+blocker при relation_required; это source-traced, не выполненный весь runtime registry. Следовательно, отсутствие использования LegalReport в normative calculation (DP-O1) нельзя считать доказательством успешной legal authority. **Positive required-legal admission в этом pin недоступна через current owner; нельзя сымитировать её appointment.**

### Uncertainty

Existing ConfidencePass causal-purpose refusal сохраняется; source прямо указывает отсутствие accepted identification verifier с current source/graph/estimand/target. Новая wave не повторяет его прежние численные controls.

Science uncertainty bridge имеет hardwired SimulationResult owner и PropagationReport1.1/1.2/1.3 readers; он вызывает IR admission с selected simulation ref + metric subject, не принимает внешний generic validator. Source read failure возвращает `source_owner_validation_refused`. Normative uncertainty channel вызывает именно этот bridge, переносит limitation в warning и unevaluated audit. Успешная simulation/calibration/propagation/admission chain, draw ledger и trusted receipt здесь **UNRUN** из-за отсутствующего native/JAX profile и genuine producer inputs. Низкий Search DTO из section2 не заменяет этот bridge.

## 6. Governance report custody и publication boundary

Actual owner reader принимает все три v1 verdicts, но currentness resolver не допускает их как current: binding отсутствует. Foreign selector отказывается раньше на selected-ref identity. Fresh reader повторяет source_unbound после чтения CAS.

Source-traced v2 path требует exact successful registered RunGovernance attempt, output ref/profile, run, workflow/input basis, source basis ID и current projection полного declared readset. Prefix/schema/manifest сами этого не доказывают. `policy_runtime_artifacts._load_governance_report_impl` обращается к **load_current_governance_report**, а не просто DTO parser.

Полный RunGovernanceNode, все dynamic passes, engine attempt issuance, current v2 positive report, six judges, N5/physical action, appointed claim root и PUBLIC publication остаются UNRUN. Срез не опровергает и не повторяет fail-closed publication owner findings. `approve`, `complete`, `feasible`, `promotable_source` и `supported` остаются разными states с разными consumers.

## 7. Reuse и следующий falsifier

- Extend existing normative producer/currentness contract, не новый registry: selected-profile refs + declared producer read projection; consumer сравнивает текущие Trinity/metrics/distributional/simulation/legal bindings или получает typed stale/not_established. Исторический результат должен оставаться читаемым.
- Сохранить ObjectiveStack и source-score admission раздельно. Не заменять failed point нулём и не превращать `feasible` в scientific validity. Carry report.status/refusal в diagnostics согласно purpose.
- Сохранить EvaluationSafety immediate revalidation и private producer receipt. Не применять чужой verified DTO или test mint как workaround.
- Legal requirement/competence и source-relation owner разные contracts. Реальный independent relation verifier должен быть собственным квалифицированным owner, а не «разрешить complete norm» в Lex.
- W01 следующий deciding run: genuine supported engine → scientific/propagation producers → normative → governance → current consumer; current source swap/removal по одному binding, затем independent legal/causal refusal. Если current pin не имеет positive authority owner, корректный результат — точный refusal, не full qualification.

## 8. Test/evidence scope

Native Python3.14 и locked dependency profile не обнаружены в доступной среде по W00; **native UNRUN**. Не повторялся уже известный native3.12 syntax failure. Compatibility адаптер меняет только multi-except/TypeVar syntax и использует typing_extensions; namespace facade skip не квалифицирует facade. Search uncertainty импортируется как две полные canonical DTO classes без source admission functions. Normative no-simulation-ref branch наследует прежний explicit unbound simulation-admission symbol. Exact modules/extractions/hashes записаны.

Executed: 9 full ObjectiveStack cases, strict candidate budget refusal, 7 new persisted normative joins, 11 safety predicate controls, 8 required Lex cases + out-of-scope/typed refusal, 3 governance owner/currentness cases + foreign selection, fresh-process CAS reader. Repository pytest bodies не запускались; test census — выбранный именованный набор, не repository coverage. No source edits, dependencies installs, live providers, external effects, fake appointed authority или publication.
