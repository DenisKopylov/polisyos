# Графы зависимостей и affected-cone refresh

**База:** `f1541ed155f278689be48a8c7ac56c3e200210f7`, 10 ноября 2026 UTC. **Статус: PARTIAL / bounded_probe.** Product source не изменён. Нет native/installed qualification, live CAS/DB или подписания transitions. Все product paths ниже относительно `policy-engine/`.

## Результат

1. **GR-01, medium/high confidence:** epoch cascade использует неполную identity без `manifest_profile_sha256`. На двух профилях одинакового artifact ID событие в ветви A распространяется и в независимую ветвь B. Два target profiles схлопываются в одну строку, её выбранный profile меняется при перестановке edges. Core уже имеет подходящий полный identity helper.
2. **GR-02, medium/high confidence:** CAS lineage DFS помечает узел expanded до проверки глубины. Если длинная ветвь первой достигает общего узла за `max_depth`, короткая допустимая ветвь больше его не раскрывает. Меняется не только depth, но наличие потомка и `is_complete`. Это лишняя неполнота/отказ, не доказанный false-green.
3. **GR-03, deepened_existing:** release-time capability incremental compiler решает «изменений нет» по schema/count metadata и размеру DB/Parquet, а не semantic content. Source-extracted контроль разных байтов и synthetic row values того же размера/схемы/count дал ноль changed input labels. Это другой operational owner, чем FG-02 readiness cache, но тот же класс неполной generation identity; не следует считать ещё одной независимой SYS-семьёй.
4. **GR-04, измеренная граница масштабирования:** propagation действительно ограничен достижимыми descendants, однако полный epoch resolver каждый раз строит adjacency и все target rows. Изменение одного листа на 5 000 узлах строит 4 999 строк. Offline cone-кандидат совпал с полным typed vector в 35 cases на пяти топологиях, но полный merge/sort/hash всё ещё стоит от размера snapshot. Ускорение всего продукта не установлено.

Положительно: 15 topology controls и 50 seeded random graph controls совпали с независимым fixed-point oracle; cycle не зацикливается. Advisory без owner остаётся `review_required`, а не автоматически `invalidate`. Wrong purpose/foreign target/duplicate edge/event identity conflict и owner conflict сохраняют отказ или contested. Никакой finding не доказывает обход signing, publication или независимого owner evidence.

## 1. Это разные графы с разными contracts

| Owner | Значение ребра и identity | Обновление / actual consumer | Этот срез |
|---|---|---|---|
| Core `artifacts/graph.py` | Результат → upstream manifest input; node = blob + selected profile | Lineage HTTP service `runtime/http/services/lineage.py:146`; replay `scientist/replay/deterministic.py:832,876`; audit assembler `core/audit/_assembler_core.py:272`; streaming lineage `fabric/data_plane/streaming.py:3410` | Actual traversal, real ArtifactID/ArtifactRef/InputRef, synthetic store |
| Runtime `epoch_validity_cascade.py` | Source certificate → dependent target, отдельно authority purpose | `epoch_transition_inputs.py:517` и transition producer `epoch_validity_cascade.py:1338` | Actual DTO validators/resolve body, synthetic JSON-only canonical collaborator |
| Runtime `capability_index_compiler.py` | Coarse L1–L7 input-group dependency closure | Release compiler `compile_capability_index:199–390`; CLI/build path, не online graph engine | Actual fingerprint, changed-label, closure и merge bodies; synthetic DB metadata adapter |
| `obligation_graph/_impl/compiler.py` | Candidate ledger → bundles → bounded frontier | Existing full compiler `:75–166`; semantic loss уже в `next_domain_composition` | Source-only seam, не повтор domain findings |

CAS edges направлены против epoch invalidation edges. Mechanical reuse одной adjacency без reversal и binding недопустим. Obligation «graph» в этом entrypoint является ledger/frontier, а не произвольным DAG с incremental scheduler. Coarse L4/L5/L6 closure не является general transitive engine. Это scoped owner map, не утверждение, что других графов в PolicyOS нет.

Полный текстовый caller census по всем current `src/polisyos/**/*.py` сохраняется отдельно. Imports/definitions/exports включены; это не dynamic call graph и не статистика реально исполнявшихся production routes.

## 2. GR-01: profile теряется до обхода affected cone

**Source:** `runtime/quality/epoch_validity_cascade.py:743–744`, использование `:521–529,751,782–851`; canonical owner `core/artifacts/manifest.py:301–316`.

`ArtifactRef` несёт profile. `artifact_ref_identity_key` возвращает `(artifact ID, kind, media type, profile)`, а private cascade helper только первые три поля. Graph hash содержит полные edges, однако ключи вычисления используют более слабую identity. Хеширование полного payload не восстанавливает потерянное различение в алгоритме.

**Witness A:** два разных выбранных профиля одного blob, edges A→child-A и B→child-B, одинаковый purpose. Событие имеет exact target ref A. Actual resolver выдаёт `review_required` и child-A, и child-B. Профиль B не является потомком A в exact view graph. Independent canonical identity helper различает A/B.

**Witness B:** два различных upstream nodes ведут к target-A и target-B одного blob. Graph DTO принимает обе edges, но vector содержит одну target row. Forward order выбирает B, reverse order A. Это не просто разный digest из-за перестановки сериализованного edge tuple: содержимое selected target profile тоже меняется.

**Reachability:** current epoch input collector использует тот же helper при membership/advisory collection (`epoch_transition_inputs.py:405–442`), receipts используют его для target/certificate denominators (`epoch_validity_cascade.py:963–990`), а реальный transition producer вызывает resolver. Проверен алгоритм, не полный persisted bridge, signer или publication. Если конкретный runtime inventory запрещает несколько manifest views одного blob, operational exposure будет уже, но такого ограничения нет в проверенном Graph DTO. Даже при намеренной blob-wide invalidation это должно быть явным типом scope, а не молчаливой утратой exact view.

**Направление:** wire existing `artifact_ref_identity_key` во всей цепочке node/target/event/owner keys и sibling receipts, либо формально определить/проверять отдельную blob-wide identity и запретить mixed selected views там, где она нужна. Не менять только DFS. Обновление hash/key contract требует совместимости с историческими receipts, а не молчаливого переписывания истории. Acceptance: same bytes/different profiles/different upstreams, порядок edges, event at A, owner at B, foreign event profile, historical replay и полные denominators.

## 3. GR-02: bounded CAS traversal зависит от порядка inputs

**Source:** `core/artifacts/graph.py:133–187`: LIFO stack, проверка `node_key in expanded`, затем `expanded.add`, затем depth limit. Node depth тоже берётся из первого посещения.

Fixture edges: root→shared, root→a, a→b, b→shared, shared→leaf. `max_depth=2`.

- Long route посещается первым: shared появляется на depth=3 как `skipped_max_depth`, leaf отсутствует, `is_complete=False`.
- После перестановки только двух root inputs short route посещается первым: shared present на depth=1, leaf present на depth=2, `is_complete=True`.

Source actual traversal, synthetic manifests с настоящими typed input IDs; не native FileSystemCAS. Long graph с root→shared в допустимом budget обязан иметь возможность раскрыть shared→leaf. Это least-depth reachability invariant, не пожелание об эстетике сортировки.

**Последствие:** lineage/replay/audit может сообщить неполноту и потерять доступный bounded subgraph вследствие порядка сериализации inputs. В данном witness функция fail-closed; unsafe acceptance не найден. Root inputs действительно ordered, но достижимость в depth budget не должна исчезать от эквивалентной перестановки.

**Направление:** shortest-depth BFS либо повторное раскрытие при найденном меньшем depth, с корректным обновлением статуса/depth и без повторного дорогостоящего verify для immutable exact view. Одного перемещения `expanded.add` ниже depth check недостаточно для всех более коротких повторных путей, если узел сначала раскрыт на допустимой, но большей глубине и его потомки уже пропущены. Acceptance обязан включать этот sibling variant, diamond, cycle, profile split, missing/corrupt manifests, depth boundary и node/timeout budgets.

**Положительная стоимость:** на 100/1 000/5 000 nodes, chain/star/diamond/cycle actual traversal делал ровно N calls каждого `has/get_manifest/verify`. Graph traversal bookkeeping O(V+E), без рекурсии; synthetic verify constant-cost. В реальном CAS добавляются стоимость чтения/декодирования manifest и integrity bytes, max-depth/max-nodes/timeouts. Эти секунды не характеризуют реальный storage или default `max_nodes=10000` capacity.

## 4. GR-03: incomplete changed-set authority

**Source:** `capability_index_compiler.py:1193–1230,3354–3401,3120–3146`, reuse branch `:225–238`, unchanged output copy `:3050–3117`.

DuckDB fingerprint = file size + hash table names/column names/row counts. Parquet fingerprint = size + row count/group count/field names. Значения строки, типы/semantics полей и содержимое row groups не входят в logical digest этих helpers. Schema/count hashes могут быть полезным быстрым profile, но не свидетельствуют, что compiler inputs не изменились.

В тесте actual `_fingerprint_path` и `_duckdb_schema_count_digest` вызывают synthetic metadata reader. Перезапись локальных fixture bytes A×32→B×32 и synthetic row value old→new при той же schema/count даёт идентичный fingerprint. `_incremental_state` выдаёт `changed_input_count=0`, что по actual dispatcher выбирает `reuse_previous_outputs`. Нативная транзакция DuckDB/Parquet **UNRUN**. По исходнику L1 loader использует title/metric/quality/license и другие values (`:1296–1444`), поэтому метаданные не покрывают полный readset loader.

Это не криптографическая коллизия, а различающиеся данные вне хешируемой проекции. Это углубление FG-02 класса на release compiler, не повтор его lru-cache эксперимента. Не объявляем full/incremental mismatch нативного release выполненным: сравнение здесь заканчивается actual invalidation decision плюс source trace downstream reuse.

**Coarse closure positive:** L1/L2/L3/L7 обновляют свою группу; изменение любой L4/L5/L6 перестраивает все три. Это явная консервативная группа; её fine-grained necessity не измерялась. Изменённый incremental path всё равно dedupes полный capability set, строит conflicts/white-space и переписывает output DB/projections. Ускорение отдельных loaders не означает O(affected) всего release.

**Дополнительный bounded edge case, без отдельного severity finding:** `_capability_input_groups:1160–1170` присваивает absent metadata `()`, затем считает tuple Sequence и возвращает empty set; fallback к `source_assets.source_layer` недостижим для absent/empty groups. Synthetic previous L1 capability с `{}` сохраняется после L1 removal, с explicit groups удаляется. Current built-in producers просмотренного compiler добавляют metadata; legacy/external reachability не доказана. DTO `EvidenceCapability.metadata` допускает default `{}`. Минимальный тест в поддерживаемой среде должен использовать настоящий DTO/previous DB, не shape-only collaborator.

**Направление:** reuse existing admitted generation/content digest владельца входных данных, либо content-correct digest readset плюс schema/compiler/config version. Invalid generation, missing receipt или неподтверждённая delta должны означать conservative full rebuild/refusal, не unchanged. Проверять removal, same-count update, type/rights/quality change, generation replacement, missing/unknown input group. Нельзя снимать freshness gates ради скорости.

## 5. Full против incremental: точность отдельно от стоимости

`resolve_owner_target_dispositions` каждый раз:

1. Сканирует E edges для target dictionary, purpose nodes и adjacency.
2. Для каждого advisory выполняет DFS в его purpose; reachable closure включает cycles с visited set.
3. Собирает event/owner incidence для targets.
4. Сортирует T target keys и event/owner keys, создаёт T rows и serializes/hash полного vector, включая его validation.

Оценка: O(E + Σevent(Vcone+Econe) + T log T + сортировки incidences + serialized output bytes), память O(V+E+T+incidences). Если H событий затрагивают все T targets, сам output содержит H×T refs. В таком случае «O(delta)» без изменения output contract невозможно. Для leaf event при фиксированном graph всё равно сохраняется линейная часть E/T.

Counters (изменяется ровно один leaf; chain и star):

| V | E | Affected targets | Actual row builds | Identity calls |
|---:|---:|---:|---:|---:|
| 100 | 99 | 1 | 99 | 398 |
| 1 000 | 999 | 1 | 999 | 3 998 |
| 5 000 | 4 999 | 1 | 4 999 | 19 998 |

Локальные timings, три samples каждого full case, сохранены в `results.json`; использовать medians вместе с сырыми samples, не production percentile. Hash collaborator и synthetic inputs раскрыты. Измерения не включают validation полного graph constructor, persistence, signer, HTTP или DB; это выбранный resolver, не SLA системы.

### Offline cone-кандидат

Кандидат строит generation-specific forward/reverse index один раз, на append-one-event выделяет reachable targets, вызывает **настоящий** resolver для выбранных incoming edges, переиспользует unchanged rows, затем собирает и валидирует полный vector с исходным denominator. Product source не менялся.

35 cases: chain/star/diamond/disconnected/cycle, V=100 и 1 000 с event в начале/середине/конце, V=5 000 с event на последнем node. Полное равенство typed vector, включая output hash в раскрытом JSON-only profile, сохранено. Для leaf star recomputed rows=1 вместо 99/999/4999; для cycle event задевает все V, экономии row work нет. Root fan-out тоже должен менять весь cone.

**Не объявляется production optimization:** baseline/index build не включён в delta timing; row-map copy, final sort и full hash остаются. В одном local 5k leaf sample candidate даже не дал выигрыша end-to-end; сравнивать одно candidate sample с full median как speedup нельзя. Здесь доказана semantic feasibility ограниченного reuse, а не ускорение и не general incremental API. Prior history, owner edits, concurrent generation publish и exact profile aliases не покрыты кандидатом.

### Негативы topology change

Independent fixed-point selector controls показывают:

- На add edge `2→4` old-only cone не содержит новый target 4.
- На remove edge `1→2` new-only cone теряет ранее зависимый target 2; требуется explicit tombstone, если target вообще исчез из denominator.
- При purpose change `1→2` из decision_validity в claim_lifecycle target остаётся, но old incidence нужно убрать. New-only cone его не обновит.

Union old/new cones покрывает эти конкретные witnesses, но не является доказанным полным general algorithm. Любой incremental owner должен также учитывать event removal/correction, changed owner evidence, source identity/profile, authority-purpose routing, topology version, negative/missing dependencies и cross-generation reads. Cache key одного changed node недостаточен.

## 6. Что уже можно reuse, а что нельзя объединять

**Wire/extend existing:** canonical ArtifactRef identity; epoch resolver как slow/full reference; owner generation receipts вместо count proxy; Core traversal с корректной shortest-depth семантикой. Maintain forward и reverse indices рядом с тем владельцем, который публикует graph generation, а не второй общий stateful graph service.

**Не предлагать:** новый universal graph framework, общий глобальный cache, hard cap вместо полного denominator, объявление unchanged по empty changed IDs без complete snapshot authority, перенос mutable default profile в historical edge. CAS lineage, obligation frontier и epoch authority не должны разделять один тип node только из-за слова graph.

Минимальный дальнейший acceptance packet:

- Поддерживаемые Python 3.14 + locked dependencies, native imports и актуальные mirrored tests.
- Current FileSystemCAS со selected profiles: две lineage views одного blob; persist/reopen; короткий/длинный shared path; пропажа/коррупция/перестановка.
- Actual epoch inventory→adjudication→resolver→transition consumer, mixed owner histories, exact graph/vector equality full vs incremental для add/remove/replace/retarget/purpose/profile changes.
- Native temporary DuckDB/Parquet same-count/same-size value mutations, deletion и compiler/config version changes; full vs incremental сравнивать по logical capabilities/conflicts/white-space/rights/freshness и denominator, не по output mode/timestamp.
- Fault tests: interruption before publication, old generation completion after new, two readers, missing delta, unresolved source, stale negative lookup. При ошибке refresh не публикует mixed generation.
- Измерять отдельно graph index build, identity/fingerprint scans, affected traversal, semantic row derivation, full serialization/signing, DB writes, reader latency и память. На dense SCC affected cone законно равен всему графу.

## 7. Evidence и ограничения

Commands: `PYTHONDONTWRITEBYTECODE=1 python policyos_deep_audit/next_graph_refresh/probe_graph_refresh.py`; затем `validate_evidence.py`. Probe финальный exit=0, stderr пуст; semantic replay равен после исключения только timing fields. В репозитории tests не добавлялись/не менялись; audit harness живёт отдельно от readonly source.

Python 3.12.14/Pydantic 2.13.4 вместо supported 3.14/locked bound, DuckDB/PyArrow отсутствуют. Новые зависимости не устанавливались. AST selected source сохраняет original line numbers и hashes полного файла. Первый parser run столкнулся с unrelated Python-3.14 multiple-except syntax ниже выбранного cascade seam; сохранён `initial_parser.stderr.txt`, extraction ограничен до следующего unrelated класса. Это tooling outcome, не product test failure.

`results.json` раскрывает synthetic collaborators, observed counters, все inputs/seed и limits. Текущая `REPLAY_VALIDATION.json` хранит elapsed/max RSS subprocess инструмента, не product memory footprint. No native codec conformance: `_semantic_hash` source body настоящий, но его canonical JSON collaborator ограничен fixtures и не утверждает equivalence production signed bytes.

UNRUN: supported native/full suite, installed/API/UI, actual DB/CAS storage latency, full release output equivalence, real signer/admission/publication, concurrency/recovery, scientific validity SCM и changed-world claims. Tests-source inspection подтверждает existing descendant/sibling/purpose/history controls, но не их запуск в этом срезе. Scope не дублирует `next_catalog_scale` vector-index rebuild и `next_domain_composition` facet loss.

Source qualification: 17 named executed/reviewed files совпали с baseline SHA-256; tracked Git status пуст, HEAD точный. Census denominator: все 2 895 current src Python files, 859 текстовых совпадений пяти выбранных symbols (большая часть общего identity helper, не число graph callers). Статус каждой существующей test function выбранных трёх файлов — source_read_not_run, см. `existing_test_inventory.json`.
