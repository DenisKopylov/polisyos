# PolicyOS: enforcement архитектурных guardrails после checkpoint13

**Итог: partial qualification.** База `f1541ed155f278689be48a8c7ac56c3e200210f7`, 11 ноября 2026. Найдены два новых подтверждённых механизма некорректной квалификации, одно узкое ослабление README obligation и одна явно отделённая незамкнутая live-проверка. Это не PASS архитектуры, не результат native CI и не исправление продукта.

## Главное

1. **GE-01, P2:** direct docs gate считает неуспешное Git-вычисление diff пустым набором изменений и завершается успешно. При тех же source bytes настоящая scratch Git-history даёт exit 1 с валидным base и exit 0 с отсутствующим base/нулевым SHA. Более новый docs-review Git owner эту ошибку корректно отвергает, но Fast PR вызывает direct gate.
2. **GE-02, P2:** root кандидата не передаётся трём import subgates. Проверка shim реально читает root загруженного checker, а не переданный `repo_root`. Пять controls различают same-root, плохой кандидат при хорошем checker-root, обратный случай и корректное rebinding. Это подтверждённый subgate routing defect; green всего aggregate не установлен.
3. **GE-03, P3:** README path obligation имеет семантику «хотя бы один README из списка», даже когда изменены несколько facade. Один Fabric README снимает obligation также для изменённого IR facade. Это слабость per-facade changed-path coverage, не доказательство устаревшей документации или обхода других generator checks.
4. **GE-C01, coverage gap, не performance finding:** live import-time predicate существует и различает 2× regression, но обычный test без opt-in лишь проверяет наличие baseline. В полном именованном наборе 12 root workflow YAML и 3 local action YAML нет literal opt-in. Registry command с opt-in существует. Hosted env/внешние действия и actual latency не исследованы.

## Граница этого прохода

Не повторяются прежние hidden-import spelling gap, filename mirror ratios, shared-helper topology/identity, contributor marker drift, nightly wrapper path, bootstrap doctor, OPA/installed-only/performance selection findings. Они остаются в `next_structure`, `next_test_confidence`, `next_native`, `next_directory_architecture`.

Выбраны четыре obligations:

- различать не прочитанный change set и действительно пустой;
- привязывать imports/shims/cycle verdict к выбранному source root;
- проверять README obligation по каждому затронутому facade либо явному impact note;
- отличать наличие команды/baseline/test function от фактического live measurement.

Репозиторий требует для measurement tools фактические inputs, named unresolved boundaries и distinguishing negative controls (`docs/how-to/author-measurement-instruments.md:8–29,45–56`). Поэтому новая таблица PASS по числу файлов/gates здесь не создаётся.

## GE-01: Git failure превращается в пустой docs diff

**Уверенность:** высокая для конкретного механизма и direct main; полный supported CLI/hosted CI не запускался.

`check_docs_gate.py:279–296` ловит `CalledProcessError` и возвращает `None`. `_resolve_diff_base` при неуспешном merge-base всё же возвращает исходный base. В `load_changed_paths:344–354` результат следующего неуспешного diff преобразуется в пустую строку. `_untracked_paths:300–311` также преобразует Git failure в пустой set. `main:650–670` видит ноль commands/findings и возвращает 0.

### Реальный caller-control

`probe_docs_gate.py` исполняет **весь неизменённый module** и его настоящий `main`, используя настоящие Git subprocesses и два локальных fixture commits. Изменён только синтетический путь `src/polisyos/scientist/orchestration/workflows/replay.py`. Он требует docs evidence, но не запускает тяжёлых generated child commands.

| Input | Discovered paths | Outcome |
|---|---:|---|
| valid `HEAD~1` → `HEAD` | 1 | exit 1, `scientist_docs` |
| отсутствующий base | 0 | exit 0, «no docs-sensitive D6 rules» |
| all-zero base SHA | 0 | exit 0, тот же текст |
| valid `HEAD` → `HEAD` | 0 | exit 0, корректный empty control |
| каталог вне Git repository | 0 | exit 0, неверно квалифицированное отсутствие |

Это не гипотетический return-value mock: Git действительно возвращает ошибку. Единственная import substitution — namespace `tools.lib` вместо его `__init__`, поскольку тот импортирует неподдерживаемый в локальном Python 3.12 файл fs; точные `tools.lib.imports` и `check_docs_gate` исполняются целиком. Нет подмены Git или docs predicates.

### Exposure и полезный существующий owner

Fast PR `.github/workflows/abi.yml:209–221` вызывает direct gate с pull-request base SHA или `github.event.before`. Checkout использует fetch-depth 0, что снижает обычный shallow-ref риск, но не исправляет семантику invalid/unavailable ref. Здесь **не утверждается**, что текущий hosted workflow получил такой SHA или что все остальные jobs пропустят изменение.

`docs_review_git._git_bytes/_resolve_commit` (`45–90`) уже содержит нужное различение. На том же настоящем fixture валидный ref разрешён, отсутствующий отвергнут с `ReviewError`. `documentation-verification.md` честно указывает, что discovery нового review tool не добавляет CI dispatch. Это не дополнительный неизвестный orchestrator.

**Минимальный ремонт:** использовать этот existing Git owner или одинаковую fail-closed семантику в direct gate; не превращать error в `set()`. Вывод должен сохранять requested/resolved refs, полный selected path set и причину UNRUN. Для intentionally new-branch zero base нужна явная политика сравнения, а не молчаливое отсутствие. Проверить valid-empty, invalid base/head, отсутствующий Git root и ошибку diff через реальный caller.

## GE-02: candidate root смешивается с root checker

**Уверенность:** высокая по source wiring и exact subgate replay; aggregate/CLI acceptance остаётся UNRUN.

Цепочка:

1. `check_package_import_gates.run_cli:188–204` принимает `--repo-root`; `build_report:128–149` передаёт root в `architecture_report_only_contracts.build_report(..., report="phase6-1")`.
2. `architecture_report_surface.py:567–583` вызывает dynamic/import-cycle/shim validators с этим root.
3. `architecture_import_graph.py:149–185` принимает root, но вызывает `decomposition_preflight.validate_dynamic_imports()`, `validate_import_cycles()` и `validate_reexport_shim_shapes()` **без root**. `_preflight_errors` использует его лишь как неиспользуемый аргумент. `_import_cycles_summary:207–223` смешивает lazy registry count из candidate root и findings из другого root.
4. `decomposition_preflight.py:32–42` фиксирует roots при import по своему `__file__`. Shim validator `18512–18539` строит пути от этого global root.

### Distinguishing controls, не whole-gate PASS

`probe_root_binding.py` исполняет точные bodies wrapper, `_preflight_errors`, shim validator и path helper с двумя synthetic roots A и B. Каждый root имеет собственный shim registry и файл. Parser seam заменён на `ast.parse(read_bytes)` только для valid synthetic syntax; failure-handling Python 3.14 parser здесь не тестируется.

| Loaded checker root | Requested root | Defect | Shim findings / actual read |
|---|---|---|---|
| A | A | нет | 0 / A |
| A | A | star import в A | 1 / A |
| A | B | star import только в B | **0 / A** |
| A | B | star import только в A | **1 / A**, although B is clean |
| B | B | star import в B | 1 / B |

Оригинальное запрещённое свойство сохраняется: star import выявляется при правильной привязке. Counterexample находится только вне реально прочитанного root, и actual read SHA это фиксирует. Нет доказательства, что **весь** `check-package-import-gates` вернёт 0: иные findings могут остановить aggregate. Dynamic/cycle повтор здесь source-traced, а не отдельный native replay.

**Exposure:** штатный CI запускает checker из того же checkout, поэтому этот control не доказывает проблему обычного same-root CI. Риск относится к advertised `--repo-root`, candidate/overlay qualification и программным callers с другим root. Clean tool tree может скрыть candidate shim defect; stale tool tree может дать ложный candidate red.

**Минимальный ремонт:** передавать immutable root/context через существующих owners. Root должен связывать registry, source enumeration, logical paths и output. Не чинить concurrent callers временным изменением process globals. Если alternate-root support пока не гарантируется, отказать при несовпадении явно. Acceptance: exact CLI на двух roots, negative только в кандидате, reverse control, missing/unreadable candidate и same-root baseline.

## GE-03: несколько facade, один README

**Уверенность:** высокая для planner result; per-facade interpretation следует из его формулировки «matching package README». Priority низкая, не authority defect.

`_facade_readmes` правильно перечисляет matching README для всех changed facade. Но `build_gate_plan:619–635` затем проверяет `not _has_changed(changed_paths, (*expected_readmes, IMPACT_NOTE))`, то есть **existential any**.

Пять plan controls (`docs_gate_results.json`):

- один facade без README: finding;
- два facade без README: finding;
- два facade + только Fabric README: нет `readme_freshness`;
- оба matching README: нет finding;
- явный общий impact note: нет finding, разрешённый fallback.

Остальные planned commands сохранены, включая schema/public-surface/docstrings. Они не исполнялись. Из результата нельзя делать whole-gate bypass. `guardrails._check_readmes:6826–6864` независимо проверяет существование README, freshness marker и Where to Start; не связывает каждый changed facade с update его README. Даже исправленный all-quantifier доказывал бы лишь paths, не смысл новой документации.

**Минимальный ремонт:** при отсутствии общего impact note вычислять `missing_readmes = expected - changed`; сообщать все unmatched facade. Сохранить существующий impact-note escape как явно заявленный договор, не требовать бессмысленных дат/косметических правок для зелёного KPI. Если задумана групповая политика «любой README», назвать её честно и перестать объявлять matching coverage.

## GE-C01: live import-time gate не равен успешному baseline test

Это **coverage/interpretation gap**, не доказанная регрессия и не повтор старого benchmark-selector finding.

`architecture/gates/structure_remediation.toml:192–201` и index объявляют `import_time_regression_gate` fail_closed с командой, которая устанавливает `POLISYOS_RUN_IMPORT_TIME_GATE=1`. Test `1678–1690` вне этого opt-in лишь проверяет `baseline.exists()`. `validate_import_time_regression:18542–18561` по умолчанию `live=False` возвращает пустой список; `run_all_gates` сохраняет такой default. Live mode измеряет три samples и сравнивает medians с двумя baseline значениями.

Exact-body controls с synthetic timing producer, возвращающим 2× baseline:

- predicate `live=False`: 0 findings, producer не вызван;
- predicate `live=True`: 2 regression findings, producer вызван;
- actual test body без env: returned, producer не вызван;
- actual test body с env `1`: assertion failed на обеих regressions.

Это подтверждает полезный существующий predicate и отсутствие live property в default test, **не actual performance**. Базовый test имеет самостоятельную baseline-existence задачу; его не следует объявлять пустышкой.

### Именованная source routing map

Полный root workflow denominator сверён с pinned baseline: **12 YAML files**, дополнительно все **3 local composite actions**. Прочитаны whole bytes и сохранены SHA (`workflow_surface.json`). Case-insensitive literal search не находит `POLISYOS_RUN_IMPORT_TIME_GATE`/`--live-import-time` ни в одном. Это доказывает отсутствие этих declarations в заданных файлах, не произвольную runtime reachability и не hosted env.

- Fast PR minimal quality job: прямой lint policy + fail-closed package/import gate, затем ordinary pytest.
- Fast PR docs profile: direct docs-gate + самостоятельные freshness/lifecycle/build/docstring checks. Не новый `check-docs-review --run-independent`.
- Standard PR runtime frontend-contract job: guardrails check; это отдельный generated/public contract слой.
- `workspace ci-parity` действительно вызывает `workspace verify --backend-only`, который содержит package-import gate. Нельзя объявлять local gate missing только потому, что поиск в самом ci_parity не находит название команды.
- Local package-import pre-commit hook селективен. Изменение `architecture_import_graph.py`, `decomposition_preflight.py` или `architecture/shims.toml` само по себе не входит в его `files` pattern. Это ограничение данного hook, не доказательство полного hook/CI bypass: существуют always-run companions, Fast PR gate unconditional.
- Index/taxonomy test проверяет наличие gate IDs и непустых command strings, а не их запуск. Непустая команда — registry integrity, не live enforcement receipt.

**Что улучшить без ложного показателя:** объявить отдельный supported live profile с artifact для фактического checker/source/lock/platform, командой и measured result; отдельно показывать baseline-existence и not-run live status. Не добавлять timing во все unit tests без калибровки: текущие wall-time baseline без platform/profile fields не являются универсальным порогом на любом runner. Не перегенерировать baseline автоматически после red.

## Priorities и acceptance

1. GE-01: точечный fail-closed repair Git selection, используя existing reader; native invalid-ref controls до любых тяжёлых child jobs.
2. GE-02: explicit checker/candidate binding, затем full CLI two-root controls. Не сводить исправление к locator `__file__`: нужны actual compiled bytes/readset.
3. GE-03: либо per-facade missing set, либо честно документированная coarse policy; никаких метрик semantic freshness по filenames.
4. GE-C01: квалифицированный opt-in live lane и отчёт `UNRUN` вне него; отдельно preserve cheap baseline existence test.

Предлагаемые изменения не внесены. Все native Python 3.14/locked, hosted workflow, generated docs, full pytest и installed profile acceptance остаются **UNRUN**. Причина supported native blocker уже установлена в `next_native`, повторной установки и попыток обхода не было.

## Evidence и воспроизводимость

- `docs_gate_results.json`, `probe_docs_gate.py`: actual direct main + real Git, пять Git и пять plan controls.
- `root_binding_results.json`, `probe_root_binding.py`: пять two-root shim controls, compiled fragment hashes и фактические parser reads.
- `profile_controls.json`, `probe_profile_controls.py`: timing predicate/test и existing Git owner controls.
- `workflow_surface.json`: полный именованный workflow/action declaration denominator с hash и literal search limits.
- `source_excerpts.json`, `SOURCE_VALIDATION.json`: решающие source spans; **51 selected file** совпал с pinned baseline. Это readset validation, не semantic coverage всех repository files.
- `CONTRACT_MATRIX.json`, `FINDINGS.json`: disposition, actual/required evidence и residual falsifiers.

Повтор: `PYTHONDONTWRITEBYTECODE=1 python policyos_deep_audit/next_guard_enforcement/probe_docs_gate.py`, затем `probe_root_binding.py`, `probe_profile_controls.py`, `write_evidence.py`.

Первая попытка root probe остановилась на ошибке нашего extractor: decorator считался отдельным block. Она сохранена в `root_probe_initial_harness_failure.txt`; исправлена только граница extraction, canonical bytes не переписаны. Native unsupported syntax не переводилась в другой синтаксис. Это harness failure, не product defect.

Product HEAD неизменён, `git status --porcelain` пуст. Fixtures, временные Git commits и новые outputs лежат только в `next_guard_enforcement`. Никаких source/test/config edits, установок, remote actions или generator sync не было. Этот bounded проход завершён; весь глубокий аудит и remediation не завершены.
