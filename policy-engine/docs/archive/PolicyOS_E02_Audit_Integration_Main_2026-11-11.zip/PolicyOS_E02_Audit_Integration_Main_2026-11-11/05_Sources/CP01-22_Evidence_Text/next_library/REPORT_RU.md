# PolicyOS: дополнительный аудит библиотек и численных контрактов

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Read-only snapshot, 10 ноября 2026. Четыре **новые выбранные семьи** относительно `next_reuse`; это не полный проход по всем алгоритмам системы. Решения предложены, исходники не изменены, adoption не утверждён. Два локальных дефекта воспроизведены, два решения ограничивают механическую унификацию.

## Результат

1. **LIB-01, P2: CDF-оценка теряет координату распределения.** Реальный producer для `arange(100)` и `arange(100)+100` отдаёт одинаковые CDF ordinates на разных grids. Exact evaluator сообщает `wasserstein=0`, тогда как W1 исходных выборок равен 100. Это нельзя починить одной заменой helper на SciPy: он получит неверный вид данных и тоже вернёт 0.
2. **LIB-02, P2: самописный bootstrap RNG имеет вырожденный контроль.** Из 100 потоков длины 20, block=1, source `[0,1]` получаются только две чередующиеся последовательности. Средние всех потоков равны 0.5, bootstrap variance равна 0 при эталонном IID значении 0.0125. Stdlib/NumPy устраняют этот конкретный дефект, но не отдельную потерю блоков в strata wrapper.
3. **LIB-03, P3: шесть weighted-quantile функций представляют три разных определения квантили.** Для `[0,10]`, weights `[1,3]`, q=.5 результат равен 7.5, 3.333… или 10. NumPy заменяет только step-CDF kernel с сохранением policy; общий одноимённый helper без выбора метода опасен.
4. **LIB-04, P3: AUC уже корректен на выбранном бинарном contract.** 150 finite/tied controls совпали со sklearn и SciPy rank adapter до <1e-14. sklearn меняет one-class refusal на NaN и добавляет optional dependency в runtime. Здесь замена по числу строк не оправдана; SciPy rank kernel остаётся условным performance-кандидатом.

Свод машинных решений: [decisions.json](decisions.json). Полные числа, случаи и source spans: [results.json](results.json), [source_excerpts.json](source_excerpts.json). Подтверждённые внешние API: [library_sources.json](library_sources.json).

## LIB-01. W1: библиотека подходит для вычисления, но не чинит неправильный контракт

**Source/consumer.** `foundry/agent_sim/world/targets/distributional.py:10–50` создаёт CDF как `grid` плюс `values=F(grid)`. `evaluators/metrics.py:66–70` передаёт только ordinates в `_wasserstein_1d:11–20`, который сортирует их как выборку. `world.py:280–357` вызывает evaluator и складывает число под `distributional.cdf.wasserstein` в `EvaluationRun`; diagnostic hook повторяет его. Dispatch и typed result source просмотрены; сам World.evaluate, materialization и сериализация не запускались.

**Доказательства.** Exact producer/evaluator дают 0 для сдвига на 100. Изменение ordinates на +.01 обнаруживается, то есть это не пустой/неисполняющийся metric path. Дополнительный контроль снимает неоднозначность «prediction обязан быть на truth grid»: на **одном общем grid** `[0,d]` CDF точек 0 и d имеют ordinates `[1,1]` и `[0,1]`. При d=1 и d=100 evaluator одинаково возвращает .5, хотя их W1 равен соответственно 1 и 100. Размерность и spacing полностью потеряны. Невалидная обратная последовательность ordinates также может дать 0, поскольку сортировка скрывает монотонность.

Отдельно raw-sample helper на `[0,10]` против `[0,0,10]` даёт 2.777777…, SciPy даёт 1.666666…. Для равных cardinality control совпадает. Это уточнение той же семьи, не дополнительный incident count.

**Кандидат и решение.** [SciPy W1](https://docs.scipy.org/doc/scipy-1.16.0/reference/generated/scipy.stats.wasserstein_distance.html) принимает samples/support и masses, а не CDF ordinates. Сначала закрепить typed distinction: samples, support+masses, либо CDF-on-grid с явными интерполяцией, хвостами, единицами и пределом ошибки. Семь внутренних CDF points не содержат всю исходную эмпирическую меру: нельзя обещать exact sample W1 из них. Для sample/support adapter использовать SciPy; для grid-only contract выбрать и назвать допустимую приближённую метрику или отказаться, когда хвосты/сетка не установлены. Просто переименовать нынешний показатель в W1 нельзя.

**Ownership/compatibility.** Scientific meaning, validation, metric version и interpretation исторических результатов остаются у World owner. Замена чисел может затронуть benchmark thresholds и content hashes; tolerance-equivalence не равна byte-identical replay. Доказан неверный evaluation surface, не обход authority или опубликованный production инцидент.

**Acceptance.** Native Python 3.14 producer→World.evaluate→EvaluationRun JSON; same/different grid, affine units, unequal sample sizes, invalid CDF, nonfinite/empty inputs, omitted tails и результат/отказ с версией метода. Не переносить отбор модели или право публикации в библиотеку расстояний.

## LIB-02. Bootstrap: заменить RNG, не объявлять всё статистическое основание исправленным

**Source.** `ddm/calibration/calibrate.py:185–264,443–453`. `_DeterministicRng` есть LCG modulo 2^31 с нечётными multiplier и increment; при `randrange(2)` младший бит строго чередуется. Это алгебраическое свойство, а не случайный плохой seed.

На source `[0,1]`, block=1, stream_length=20, n_streams=100, seeds 0…99:
- Product LCG: 2 уникальных потока, variance(mean)=0, transition rate=1.
- Audit-only `random.Random` seam: 99 уникальных потоков, variance(mean)=0.01030909, transition rate=0.4863.
- Audit-only NumPy Generator seam: 100 уникальных потоков, variance(mean)=0.01265934, transition rate=0.4984.

Оба контроля воспроизводимы. Близость одного bounded sample к .0125 не является статистической сертификацией генератора или FP calibration. Исходный код не менялся: в isolated namespace менялся только класс RNG.

**Второй seam той же семьи.** `stratified_bootstrap_stationary_streams` на каждом offset заново вызывает moving bootstrap с `sample_size=1`. При source `[0,1,2,3,4]`, block=3 выбирается только первый элемент блока, поэтому support результатов `[0,1,2]`, а 3/4 не появляются. Свойство сохранилось с обоими зрелыми RNG. Получение целых блоков и порядок strata требуют отдельного решения owner; swap RNG этого не решает.

**Reachability.** Полный literal scan 2895 `*.py` в `policy-engine/src/polisyos` сохранён в [bootstrap_symbol_census.json](bootstrap_symbol_census.json): выбранные bootstrap имена обнаружены в owner и facade export. Это не доказательство отсутствия alias/dynamic/external calls. `calibrate_detector` потребляет уже готовые streams, сам эти функции не вызывает. Поэтому доказанный дефект public sampling helpers не объявлен реально выданным ложным calibration certificate. Ближайшие retained tests проверяют reproducibility/length и availability; они не запускались.

**Библиотеки/решение.** [random.Random](https://docs.python.org/3.14/library/random.html) даёт узкий stdlib заменитель uniform start-selection без новой зависимости. NumPy Generator уже доступен в профилях, удобен для векторизации и выделенного состояния. Для полной research реализации доступен declared `arch==8.0.0` с [MovingBlockBootstrap](https://bashtage.github.io/arch/bootstrap/generated/arch.bootstrap.MovingBlockBootstrap.html), но он здесь не установлен и не исполнен. Его length/data-shape/API и поведение block>data ещё нуждаются в adapter tests. [arch различает](https://bashtage.github.io/arch/bootstrap/timeseries-bootstraps.html) moving/circular/stationary методы и предупреждает о неравномерном включении краёв в moving blocks. Переход между ними меняет модель зависимости и не является косметическим reuse.

**Ownership/compatibility.** DDM сохраняет stationarity declaration, block/strata schedule, admissibility, calibration binding, seed и report provenance. Переход от LCG меняет последовательность при прежнем seed. Нужна версия sampling algorithm и сохранённый путь исторического replay, не тихая перезапись прошлых результатов. [NumPy stream compatibility](https://numpy.org/doc/2.3/reference/random/compatibility.html) зависит также от generator/build/environment/call sequence. При выдаче новой calibrated версии прежний seed сам по себе недостаточен.

**Acceptance.** Power-of-two supports, contiguous block preservation, multiple seeds/strata, endpoint inclusion policy, arbitrary output length, oversized block, deterministic replay и new/legacy algorithm identity. Статистический тест вариации с заранее объявленными допусками, затем настоящая calibration/registry chain. Не превращать random package в owner доказательства false-positive guarantees.

## LIB-03. Weighted quantiles: переиспользовать метод, не имя

Выбраны 6 functions: microsim `calibration:126–134`, `dynamic_validation:166–176`, `inverse:447–462`; Bayesian `protocols:388–416`, `prior_sensitivity:1658–1684`; ML `uncertainty:64–83` и реальный `WeightedConformalQuantile:95–130`. Это выбранный набор, не census всех quantile implementations.

- Midpoint-CDF interpolation: microsim calibration/dynamic, результат 7.5 в основном control. При zero total calibration возвращает 0, dynamic уходит к unweighted NumPy и возвращает 5.
- Cumulative-CDF interpolation: Bayesian protocols/prior, результат 3.333…. Совпадение проверено, но prior helper специально избегает импорта posterior protocols; консолидация не должна вернуть тяжёлый import edge.
- Step inverse-CDF: inverse/conformal, результат 10. [NumPy 2.3 quantile](https://numpy.org/doc/2.3/reference/generated/numpy.quantile.html) с weights поддерживает именно `method="inverted_cdf"`, не остальные weighted определения.

**Проверка:** 500 finite-positive cases с разными n, q и seed: обе step functions совпали с NumPy; пары midpoint и Bayesian совпали внутри своих estimand. Девять named controls показывают различие zero/nonfinite/negative mass, empty/q-range и q=0 с нулевым весом минимума. В последнем conformal helper возвращает 0, NumPy 10. В реальном conformal wrapper уровень положительный, этот helper control не объявлен production coverage defect. Exact typed conformal wrapper на admissible fixture при audit NumPy substitution сохранил результат и ESS; конечная коррекция и ESS не заменялись.

**Решение:** отдельные именованные контракты; NumPy step-kernel только за прежними guards, filtering, shape и error policy. Generic NumPy на zero-total может вернуть значение с warning, где domain обязан отказать. Не менять missing-value policy ради совпадения. Для midpoint/interpolated kernels существующие np.sort/interp уже являются библиотечными операциями; новое statsmodels/pandas API не показало выигрыша и не нужно. `inverse` helper не имеет найденного direct call в своём модуле; production adoption по нему не заявлен.

**Acceptance.** Native calls через domain DTOs, finite/missing/zero weight policy, cumulative rounding boundaries, repeated ties и q endpoints; row-order invariance там, где она обещана. Сохранить conformal finite-sample correction и ESS. Решение о том, какой estimand нужен экономическому/байесовскому потребителю, принадлежит owner, не «универсальному quantile helper».

## LIB-04. ROC-AUC: сохранить refusal и не тянуть ML-профиль без причины

`ddm/detectors/realized_performance_monitor.py:197–221` уже реализует O(n log n) rank-AUC с average tie ranks, не квадратичный перебор. `_binary_metric:146–183` вызывает его и добавляет `_bounded_interval`; public monitor затем использует current/interval для budget event. Выполнен exact `_binary_metric` с настоящими извлечёнными Pydantic records, не полный monitor.

150 finite binary controls, включая ties, совпали со [sklearn 1.8 ROC-AUC](https://scikit-learn.org/1.8/modules/generated/sklearn.metrics.roc_auc_score.html) и [SciPy average rankdata](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.rankdata.html). На one-class records исходник даёт ValueError, непосредственная sklearn substitution в actual `_binary_metric` возвращает `(NaN, (0,1))` с warning. Это совместимость, которую adapter обязан сохранить. Helper-only NaN input тоже различается, но DTO probability NaN отвергает, поэтому он не назван admissible production bug.

Медианы трёх тёплых запусков на list inputs, ms, порядок custom / sklearn / SciPy rank adapter:
- n=1,000: 0.523 / 1.407 / 0.263.
- n=10,000: 5.761 / 4.702 / 2.022.
- n=100,000: 70.756 / 43.857 / 22.325.

Это bounded CPU measurements без workload/host qualification. Ранговый SciPy adapter быстрее в выбранных больших cases, но пока несовместим по malformed-length exception. scipy candidate надо завершить guards, а не копировать экспериментальный wrapper в source. Сохранить default; рассмотреть библиотечный kernel только если реальные размеры окон/частота покажут полезный выигрыш с cold cost. Подходящий заранее объявленный gate: ≥2x на фактическом window workload при сохранении error/latency contract. Текущие measurements этого production решения не принимают.

Статистическая корректность AUC CI не установлена совпадением point estimate. sklearn не автоматически исправляет confidence interval, delayed-label dependence или budget semantics. Нужны native point→interval→event→registry negative tests, включая undefined/single-class refusal.

## Зависимости и измеренная цена

Source-pinned `uv.lock` и уже сохранённые `next_native/export_*` показали:
- NumPy 2.3.5, SciPy 1.16.3, pandas 2.3.3 присутствуют в minimal/runtime/research exports.
- scikit-learn 1.8.0, joblib, threadpoolctl отсутствуют в minimal/runtime и присутствуют в research. Добавлять sklearn в DDM по умолчанию означает расширение runtime closure.
- arch 8.0.0 и statsmodels 0.14.6 входят в analytics/research, а не runtime. По lock новый closure поверх runtime включает arch, statsmodels, patsy; numpy/pandas/scipy/packaging там уже есть. arch/statsmodels в audit environment отсутствуют, их качество выполнения не заявлено.

«Уже входит транзитивно» не означает правильную прямую dependency declaration для нового import. Owner должен сделать профильный контракт явным. Никакие install/sync не выполнялись.

Cold subprocess imports, median of 3; VmRSS — текущая resident memory процесса, **не incremental product RSS**:
- `interpreter_baseline`: 0.0000 s, 7.53 MiB RSS.
- `import random`: 0.0019 s, 7.81 MiB RSS.
- `import numpy`: 0.0908 s, 19.19 MiB RSS.
- `from scipy.stats import rankdata, wasserstein_distance`: 1.0541 s, 75.34 MiB RSS.
- `from sklearn.metrics import roc_auc_score`: 1.2107 s, 113.11 MiB RSS.

Stdlib random не добавляет distributions. NumPy/SciPy могут уже быть warm в research worker, тогда эти cold числа неприменимы; в новом runtime process импорт не бесплатен. Первый проход использовал ru_maxrss и показал одинаковый inherited high-water mark во всех subprocess; он **не считается memory evidence**, сохранён в `initial_run`. Instrument исправлен на `/proc/self/status:VmRSS`. Отдельная стартовая ad-hoc проба остановилась на отсутствующем AST lineno; это ошибка инструмента, не PolicyOS.

## Воспроизведение и пределы

Команда: `PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python policyos_deep_audit/next_library/probe_libraries.py`. Exit 0, [stdout](probe.stdout.json), [stderr](probe.stderr.txt). Затем `python policyos_deep_audit/next_library/validate_evidence.py`: exit 0; 26 named source paths совпали с baseline, Git tracked source clean. Эти hashes доказывают источник, не semantic coverage всех строк.

Выполнение: Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0, sklearn 1.8.0, Pydantic 2.13.4. Требуемый product profile: Python 3.14, lock SciPy 1.16.3 и Pydantic 2.12.5. **Native imports, full pytest, arch adapter, deployed consumers и production outcomes UNRUN.** Exact AST bodies извлекались без изменения тела; imports/launch отсутствуют, `_EPS` соответствует source. Audit adapters вводились только в изолированных namespaces. Это не patch и не квалификация системы.

Pattern pass: P27/P31 запрещают новый универсальный numeric/authority owner; P33 требует вариации, а не одного удачного witness; P38 здесь особенно важен для подмены расстояния по outcome axis расстоянием по CDF ordinates; P35 ограничивает census конкретным путём и типом файла. Маленькие готовые алгоритмы полезны, но не поглощают custody, epistemic contract или domain decisions.
