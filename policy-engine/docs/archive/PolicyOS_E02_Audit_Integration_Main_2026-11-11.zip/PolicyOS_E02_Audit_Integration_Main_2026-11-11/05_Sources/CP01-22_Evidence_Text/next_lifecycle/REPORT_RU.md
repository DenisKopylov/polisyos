# PolicyOS: lifecycle, cancellation и cross-process после checkpoint01

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`, tree `29890b967236a8f07e2b0f92a0133ee36883ac49`. Дата: 10 ноября 2026. Статус: **частично проверено**. Продукт не изменялся. Это продолжение SYS-05/SYS-06, а не пять новых независимых системных дефектов.

## Главный результат

1. **Новый подтверждённый cleanup-разрыв:** отмена request task до получения ответа оставляет generic idempotency key в `pending`, а live-stream slot занятым. Повтор POST получает 409; после четырёх отменённых live-open пятый получает 429. Повторено через настоящий Starlette ASGI middleware stack и HTTPX, не только прямым вызовом метода. При этом обычный Exception и отмена уже начатого stream обрабатываются корректно.
2. **Shutdown не равен drain:** при штатном timeout 2 секунды настоящий `ControlRunService.close()` и тело `RuntimeServiceContainer.shutdown()` могут завершиться с `stopped`, когда handler ещё жив. Но guard закрытого owned store действительно отклоняет новые вызовы. Нельзя переносить позднюю запись raw-store пробы на default guarded composition.
3. **Stop имеет отдельное окно до dispatch:** если stop завершился во время maintenance callback, после выхода из callback worker ещё арендует pending job и запускает handler. Это отличимо от уже начатой долгой работы.
4. **Cross-process response cache не становится reservation:** два отдельных процесса с одним каталогом и одним key принимают разные payloads как `started`; второе завершение заменяет первый replay. После смерти до `complete()` повтор снова принимается. Это расширение SYS-06, не доказанное двойное исполнение доменной операции.
5. **Существенные защиты работают:** SQLite lease имеет одного победителя в пяти синхронизированных гонках; после takeover старый процесс не может renew, пройти current-owner check или записать fenced SQL effect. Истечение lease перед commit откатывает эффект. Смерть процесса внутри транзакции откатывает и lease, и effect.

## Среда и границы доказательства

- Python 3.12.14, SQLite 3.53.1; ASGI: Starlette 1.6.0, AnyIO 4.14.2, HTTPX 0.28.1.
- Репозиторий требует Python `>=3.14,<3.15`; `uv.lock` закрепляет Starlette 0.52.1, AnyIO 4.12.0, HTTPX 0.28.1. **Locked/native qualification не выполнена.** Новые зависимости не устанавливались.
- Все измерители и синтетические состояния находятся в `next_lifecycle`; временные SQLite/filesystem directories создаются здесь и удаляются после опыта. Внешних effects, E02/N5 jobs, production DB или provider calls нет.
- SQL/worker/guard/container методы исполняются из canonical snapshot. Исходные тела не исправляются. Конструктор минимального store, схема, materializer job и domain handler синтетические. Event/outbox wrapper и domain admission не воспроизводятся.
- Mutation module компилируется с неизменными телами, кроме двух исключённых imports: JSON serializer заменён stdlib JSON, `problem_response` минимальным JSONResponse. Они не определяют allocation/cleanup/reservation decisions. Для guard используется всегда допускающий breaker fixture, а sanitizer error text заменён identity adapter. Это не проверка breaker.
- ASGI-опыт отменяет request task, а не воспроизводит TCP disconnect или политику конкретного Uvicorn deployment. Не всякое отключение клиента автоматически отменяет task, поэтому частота production-проявления не установлена.

## LIF-01: cleanup request ownership не охватывает cancellation и post-response errors

**Приоритет P2, высокая уверенность в механизме.** Связано с SYS-05 и SYS-06; live retention здесь тот же cleanup-механизм, не отдельный дефект счётчика SYS-11.

Источники: `runtime/http/mutation_policy.py:250–282, 387–577, 579–637`.

Порядок: generic `begin()` добавляет key в process-local `_pending`; live acquisition увеличивает active slot; `dispatch()` оборачивает только `await call_next(request)` в `except Exception`. `asyncio.CancelledError` наследует BaseException и не входит в эту ветку. После возврата response захват body, gzip/JSON decoding и `complete()` вообще находятся вне этого cleanup-обработчика.

Наблюдения в `mutation_lifecycle_results.json`:

- Отмена до headers: pending=1; повтор того же POST →409 `idempotency_request_in_progress`.
- Отмена во время body capture: pending=1.
- `JSONDecodeError` после response: pending=1.
- Обычный ValueError из `call_next`: pending=0, положительный контроль.
- Четыре отменённых live-open: active=4; пятый →429 `live_stream_limit_exceeded`.
- Отмена внутри уже запущенного managed iterator: active=0, его `finally` работает.
- NL и predictive paths не выделяют generic pending; повтор synthetic call возвращает 200. Это **контроль обхода generic cache**, не квалификация их собственных durable owners.

`mutation_asgi_results.json` повторяет два основных результата через actual middleware stack: маршрут POST был вызван ровно один раз, следующий HTTP request получил 409; live-route вызван четыре раза, следующий request получил 429 без нового вызова маршрута. Эти отказы дают наблюдаемый downstream outcome на тестовом HTTP boundary.

Состояния не имеют automatic expiry в данном owner. Из этого следует удержание до удаления process-local owner/явного освобождения; длительный production soak не проводился.

**Направление исправления:** единый ownership scope должен различать локальный stream slot, in-flight token и durable unknown outcome. Локальные slots должны освобождаться при cancellation и всех ошибках. Нельзя механически делать `fail()` для любой отмены, разрешая повтор effect, который мог уже состояться. Для mutation после неизвестного outcome нужен доменный reconcile, а не утверждение «ничего не выполнено».

**Acceptance:** locked ASGI test с cancellation до/после response и при чтении body; error в decode/persistence/audit; для live все exits возвращают ровно свой slot, для mutation late/unknown outcome не превращается в повторное выполнение. Проверять соседние generic paths, NL/predictive отдельно.

## LIF-02: shutdown фиксирует terminal status до физического завершения

**Приоритет P2, высокая уверенность в state/lifecycle расхождении.** Уточнение SYS-05.

Trace:

- `app.py:310–327` → lifespan finally → `RuntimeServiceContainer.shutdown()`.
- `container.py:970–995` → close resources → service.close → lifecycle `stopped`, если не было исключения.
- `control/run_lifecycle.py:9271–9289` → `worker.stop()` → retrieval close → owned stores close.
- `control_worker.py:134–143` → `_stop.set()` → join(timeout=2.0) → release worker row, без проверки `is_alive()` и без собственного установления interrupt.lost.
- `control_worker.py:216–333` → отдельный heartbeat живёт до завершения handler; финальный heartbeat пытается поставить `idle`.

### Raw-store discriminator

`worker_lifecycle_results.json` показывает: close вернулся за ~2.015 s, worker alive=true, signal_lost=false, worker row=`stopped`, job=`running`. После этого strict current-owner check прошла и **реальная SQL transaction admission** допустила запись синтетического effect. После handler row стала `idle`.

В этой raw-store fixture ownership flags заданы вручную; она не воспроизводит штатный конструктор с guard. Вызов `start()` до завершения прежнего thread оставил тот же thread и установленный stop flag; restart после drain создал работающий loop. Это подтверждает, что `start` во время незавершённого stop не отменяет shutdown. Синтетический handler намеренно не делал domain completion, поэтому оставшийся `job=running` не заявляется отдельным defect.

### Default-shaped guarded composition: ограничение вывода

В штатном конструкторе service `run_lifecycle.py:7337–7350` owned store оборачивается `guard_runtime_control_store`; `GuardedDependencyProxy.close()` закрывает guard. Raw `ControlPlaneStore.close():10249–10251` сам по себе no-op.

`guarded_shutdown_results.json` исполняет настоящий container shutdown, service close, worker, proxy и blocking guard с default control guard timeout 1.5 s. Через ~2.005 s:

- container=`stopped`, worker alive=true, guard closed=true;
- worker interrupt ещё false;
- следующая strict current-owner check → `JobExecutionInterrupted`;
- новый guarded SQL call → dependency unavailable;
- effect rows=0; финальный worker row остаётся `stopped`, поскольку idle heartbeat тоже не проходит closed guard.

**Итог:** readiness/lifecycle status действительно опережает drain, но утверждение «в стандартном runtime после shutdown разрешена новая запись» этой проверкой опровергнуто. Поведение raw injected owner зависит от владельца и его close-контракта.

### Уже запущенный dependency не остановлен closed guard

Отдельный контролируемый опыт с timeout=.1 s: blocking operation уже вошла в executor; caller получил timeout; guard.close вернулся, operation ещё не завершилась. После barrier release она выполнила fenced SQL insert при ещё действующем lease. Новый вызов через закрытый guard был отклонён.

Это ожидаемое ограничение `Future.cancel()` для уже работающего thread и `executor.shutdown(wait=False, cancel_futures=True)`, а не доказательство SQL fencing bypass. Оно требует хранить физическую занятость и unknown effect отдельно от логического timeout. Budget reservation/reconciliation и реальные provider effects в этом опыте не проверены.

**Acceptance:** production-shaped container shutdown с долгим handler и уже стартовавшим dependency, явный draining/timeout outcome, отсутствие новых dispatch, truthful status, trace физического конца. Не заменять guard/fence безусловным прерыванием Python thread или преждевременным budget release.

## LIF-03: stop во время maintenance не закрывает последующий dispatch

**Приоритет P2, высокая уверенность на worker seam.** Тот же SYS-05, не самостоятельное семейство.

`control_worker.py:179–189` проверяет `_stop` только в начале iteration, затем выполняет maintenance и без повторной проверки вызывает dispatch.

Детерминированный interleaving (`worker_lifecycle_results.json`):

1. Maintenance callback вошёл и стоит на event.
2. `stop(timeout=.01)` завершился; job всё ещё pending, handler ещё не вызван, worker row stopped.
3. Callback отпущен; настоящий SQLite lease выдал attempt=1.
4. Handler начал работу с `_stop.is_set() == True`; затем loop завершился.

Стандартный service действительно передаёт maintenance callback (`run_lifecycle.py:7577–7583`). Но в probe callback и job synthetic; поведение default closed guard на этом точном interleaving отдельно не выполнялось. Если service одновременно закрывает proxy, тот может отказать при новом lease. Самостоятельный `worker.stop()` не даёт обещания «после возврата не начнётся ни одного handler».

**Acceptance:** barriers в maintenance, перед/после lease и перед invocation. Отдельные contracts: stop принимать новую работу, отказаться от уже leased job, drain текущую физическую работу, снять authority. `stopped` нельзя использовать как общий proxy всех четырёх свойств.

## LIF-04: response replay cache остаётся process-local admission

**Приоритет P2, высокая уверенность; продолжение SYS-06.** Источники: `mutation_policy.py:241–347`, составление services `:685–709`.

`mutation_lifecycle_results.json`:

- Два **spawned процесса**, независимые экземпляры store, общий временный каталог, same tenant/method/path/key. Process A с hash A и process B с hash B оба возвращают started, прежде чем кто-либо сделал complete.
- Отдельная серия с одинаковым SHA-256 payload в обоих процессах также дала started/started; после обоих complete reopen корректно replay. Хеши обеих серий являются настоящими SHA-256 от fixture bytes.
- Последовательные real atomic writes A→B оставляют replay B. Reopen(A) даёт mismatch, reopen(B) даёт replay B.
- Same-instance контроль возвращает started→pending. До завершения payload mismatch в этом owner не различается от identical pending.
- Процесс сохранил синтетический effect-file, но умер с exit17 до complete. Reopen снова даёт started; тестовый retry добавляет второй effect. После complete reopen даёт replay.

Усиление по сравнению с checkpoint: не две Python references одного процесса, а общий filesystem между независимыми процессами и настоящее прекращение процесса. Atomic replace защищает целостность response JSON, но не связывает effect и reservation транзакцией.

**Не установлено:** два production jobs с одной idempotency identity, обход NL/predictive durable ownership, реальный внешний ущерб. Класс прямо описан как cache завершённых responses; его нельзя продавать как durable exactly-once contract. Нужна маршрутная матрица, где generic cache лишь удобство, а где есть требование общей reservation.

**Acceptance:** два real generic endpoint workers с domain admission; same/different payload, отказ/смерть до и после effect/persist, reopen, late completion, terminal replay. Reuse существующего durable domain owner предпочтительнее нового глобального cache-lock.

## Положительные cross-process и recovery controls

`sql_process_recovery_results.json` сохраняет все пять lease race repeats, без выбора лучшего:

- Два процесса одновременно пытаются lease одного pending job: каждый раз ровно один winner, attempt=1. Winners меняются, значит опыт не свёлся к одному всегда первому процессу.
- Старый process A сохраняет bound handler context и физически остаётся жив. После controlled expiry process B получает attempt=2 и пишет свой effect. A получает renew=false, owner-check rejected, fenced SQL rejected; в DB ровно один effect.
- Lease истекает внутри уже открытой transaction перед commit: `control job lease expired during publication`; effect rows=0.
- Процесс умирает с exit18 внутри outer transaction после lease и insert. Reopen видит pending, attempt0 и effect rows0; повторный lease получает attempt1.
- Terminal-state injection (`cancelled`) не останавливает thread сама по себе, но следующая строгая continuation check отказывает, effect rows0. Это тест revocation consumer, **не вызов настоящего cancellation authorization/API**.

Источник защиты: actual `_job_transaction` BEGIN IMMEDIATE, `_bound_transaction_admission`, `_validate_transaction_admission`, exact generation/owner/expiry predicate. Controlled `_utc_now` позволяет не ждать wall-clock lease и делает переходы воспроизводимыми. PostgreSQL, event/outbox atomicity, schema migrations, реальный cancellation proof и все потенциальные unbound writers этим не квалифицированы.

## Reuse и owner disposition

- Сохранить distinction local mutex, durable SQL transaction и cooperative interrupt: они решают разные задачи.
- SQL transaction/fence owner является положительным reusable mechanism; не переносить reservation в process-local replay cache.
- Worker owns dispatch/drain, service owns resource close, container owns public lifecycle. Привязать truthful terminal переход к подтверждённому исходу этих owners, а не дробить `close()` на дополнительные facade-файлы.
- Cancellation cleanup должен быть общим scope, но release локальной ёмкости и снятие domain authority не обязаны происходить одновременно.
- Уже начавшийся thread нельзя объявлять физически stopped по timeout или после `shutdown(wait=False)`. Не удалять witness/budget/lease facts для имитации завершения.

## Проверенные tests и остаток программы

Прочитаны `test_runtime_api_write_path_hardening.py`, `services/test_control_worker.py`, `test_resilience_guards.py`. Видимый shutdown test проверяет завершение worker без контролируемого long-running handler; guard tests содержат cancellation/late-future/context controls. Это выборочный trace, **не доказательство отсутствия других тестов во всём репозитории**. Native pytest/CI не запускались.

A1–A4 плана продвинуты на worker, request/token, SQL fence и generic replay. A5 (N5 witness release/revoke), A6 (budget unknown reconciliation), A7 (evidence promotion), A8 (cross-owner private-access census) остаются открыты. Нельзя объявлять весь ownership workstream завершённым.

Следующие приоритеты: locked Python3.14 replay ASGI cleanup и guarded container; затем настоящие generic route/domain consumers и cancellation admission; отдельно physical completion/budget settlement. Исправления в этот аудит не входят.

## Воспроизведение и артефакты

Из workspace:

```sh
PYTHONDONTWRITEBYTECODE=1 python policyos_deep_audit/next_lifecycle/probe_worker_lifecycle.py
PYTHONDONTWRITEBYTECODE=1 python policyos_deep_audit/next_lifecycle/probe_mutation_lifecycle.py
PYTHONDONTWRITEBYTECODE=1 python policyos_deep_audit/next_lifecycle/probe_sql_process_recovery.py
PYTHONDONTWRITEBYTECODE=1 python policyos_deep_audit/next_lifecycle/probe_mutation_asgi.py
PYTHONDONTWRITEBYTECODE=1 python policyos_deep_audit/next_lifecycle/probe_guarded_shutdown.py
```

Все пять завершились с exit0, assertions сохранены. Mutation probe дополнена повтором same-payload и настоящими SHA-256 inputs; первая успешно завершённая версия и её выводы сохранены в `initial_run`, итоговая версия находится на верхнем уровне каталога. stdout/stderr/exitcode сохранены отдельно, source hashes и definition ranges встроены в JSON. `owner_matrix.json` показывает состояние owners; `SOURCE_VALIDATION.json` сверяет использованные файлы с baseline manifest, не заменяя semantic coverage или native gates.
