# Method admission: registry → cache → selection → execution

**Статус: PARTIAL.** База `f1541ed155f278689be48a8c7ac56c3e200210f7`, исходный checkout read-only. Новый срез после checkpoint12. Исполнены настоящие Foundry registry/cache/bridge/catalog/ranking/NumPy dispatcher definitions на конечных audit-only method classes. Это не native Python 3.14, не научная квалификация реального estimator, не полный default bootstrap, не production deployment и не выход к публикационной authority.

## Результат сразу

1. **MA-01, P2: persistent method cache не сохраняет и не проверяет полную семантику registry.** После fresh-process reopen metadata-only изменение required dependencies и declared side-effect profile не меняет `is_cache_valid(live_registry)`. Восстановленный catalog считает метод runnable и ranker оставляет его; свежая регистрация того же текущего класса исключает его из runnable candidates. Дополнительно cache codec теряет slot bounds и MethodContracts при неизменных ABI/metadata digests. Это новая конкретная Foundry-cache ветвь, не повтор G1 row-count cache.
2. **MA-02, P2: generic lazy-load boundary может связать объявление A с callable B.** Реальный registry возвращает B по FQN A, candidate catalog/ranker рекламирует A, а generic NumPy dispatcher выполняет B и записывает successful history за A. Для `x=5` positive A возвращает 7, wrong-FQN B возвращает -6. **Существующие более строгие маршруты этот случай отвергают:** component bridge, input-contract selector, compiled-chain signature guard. Нельзя обобщать finding до обхода всех Method admission/authority gates.
3. **MA-03, P3: persisted import target не восстанавливает module-level nested classes.** `Nested.Resource` корректно зарегистрирован и записан, `restore_into` сообщает 2 восстановленные записи, но загрузка этой записи падает на одношаговом `getattr(module, "Nested.Resource")`. Плоский класс из той же таблицы восстанавливается и исполняется. Это функциональная неполнота persistence extension point.
4. **Сохранённые guards:** schema mismatch отвергается, refresh удаляет старые cache rows, неперсистируемый lazy target пропускается, connection lifecycle/thread controls проходят, content mutation после registry report отвергается, governed discovery не принимает восстановленный preexisting membership как новый admitted catalog. Семь исходных cache test bodies прошли напрямую, не через native pytest.

Основные данные: `read_baseline.json`, `read_metadata.json`, `read_signature.json`, `codec_results.json`, `bridge_metadata.json`, `authored_tests.json`; validation и source binding ниже.

## 1. Проверенный путь и его реальная достижимость

Публичные методы `MethodRegistry.register/register_lazy`, `RegistryPersistenceLayer.snapshot_from/restore_into/is_cache_valid`, `bootstrap_foundry_method_registry(components_index=...)`, `build_method_catalog_snapshot(registry=..., registry_report=...)`, `rank_method_catalog_entries`, `MethodDispatcher.dispatch` вызваны из audit scripts без переписывания product predicates. SQLite cache записан в `registry.sqlite`, закрыт, открыт новым процессом. Исходные классы импортируются из отдельного fixture module, а не подменяются внутри product namespace. Supplier profile изменяется только между процессами через `AUDIT_METHOD_PROFILE`.

`fixture_methods.py` объявляет конечные NumPy методы с настоящими MethodSignature/MethodMetadata/SlotSpec. Это synthetic resource admission test, не выполнение опубликованного научного метода. Значение `artifact_emission` в negative fixture является декларацией, реальных внешних effects нет. Отсутствующая dependency `audit-absent-provider-package` намеренно не устанавливалась.

Для candidate snapshot используется настоящий bootstrap report от публичного finite `ComponentRegistry` input. При уже восстановленной registry он честно записывает preexisting membership. Ни report, ни manifest не подделываются. Этот путь разрешён для candidate catalog, но **не является bound discovery**. Отдельный строгий вызов с `require_bound_discovery=True` отказывается.

Полный literal census охватывает 2 895 `.py` под `src/polisyos`; он не нашёл application consumer `RegistryPersistenceLayer` вне его owner/facade. Поэтому утверждение ограничено реально исполняемым публичным cache API и его documented use, а не утверждением, что текущий HTTP production startup использует SQLite cache. Каталог и нижний dispatcher имеют реальные внешние callers; найденные строки перечислены в `caller_census.json`. Это symbol census, а не доказательство семантики каждого caller.

## 2. MA-01: lookup/cache identity и semantic identity разошлись

### 2.1 Metadata-only profile change

Writer baseline сохраняет `audit.method.finite@1.0.0`: required deps пусты, side effects `none`. Новый process читает тот же SQLite и импортирует класс с тем же FQN и той же signature, но его metadata уже требует отсутствующий provider и объявляет `artifact_emission`.

Результат `read_metadata.json`:

- `cache_valid_no_registry=true`, `cache_valid_live=true`;
- signature digest совпадает, metadata digest текущего класса отличается от восстановленного;
- cached catalog: runnable=true, deps=[], side_effect_profile=none, method находится в ranked candidates;
- fresh catalog: runnable=false, missing_dependency:audit-absent-provider-package, side_effect_profile=artifact_emission, ranked candidates=[];
- actual NumPy dispatch выполняется с cached declaration. Это не свидетельствует о доступности отсутствующего provider: synthetic arithmetic специально не импортирует provider;
- текущий component bridge после restore считает тот же FQN duplicate, сохраняет старую metadata и выдаёт report без errors. First-wins duplicate policy сам по себе не дефект; важно, что повторный discovery не является автоматическим ремонтом этой cache incoherence.

Механизм: `selection/cache.py:155–213` хранит metadata JSON, но catalog hash строит только по signature; `:270–305,374–391` сравнивает live signature hashes и не сравнивает metadata/import target. `restore_into:225–267` принимает кеш по schema check, не по current imports. `registry._load_entry:788–809` сохраняет factory result без reconciliation. `catalog/snapshot.py:117–178,202–241` читает runtime class для posture, но dependencies/side effects/truthfulness metadata берёт из registry entry. В итоге одна candidate row смешивает две версии источника.

**Контроль:** изменение самой signature (LOW→HIGH fidelity при том же FQN) даёт `is_cache_valid(live_registry)=false`. Это реальный сохранённый guard, а не «cache вообще ничего не проверяет». `is_cache_valid()` без registry возвращает true даже при signature drift, что прямо соответствует его узкому schema-only docstring. Finding не основан только на этом documented default. Intro/cache comments обещают более сильную проверку live hashes при restore, которой actual restore не делает; также комментарий про XOR не соответствует фактическому sorted SHA256. Это документационный drift, не отдельный counted finding.

### 2.2 Snapshot codec использует ABI projection как полное содержимое

`SlotSpec._stable_dict` намеренно не включает bounds, `MethodMetadata._stable_dict` не включает MethodContracts. `cache._signature_payload/_metadata_payload` используют эти проекции как serialization codec; reader не восстанавливает потерянные поля.

`codec_results.json` выполняет реальный roundtrip в `bounded.sqlite` без изменения fixture между write/read:

- original slot bounds `(0,1)` → restored `(None,None)`;
- ABI digest остаётся равным, `cache_valid_live=true`;
- существующий `_signature_matches` корректно различает actual class и restored signature;
- `check_slot_compatibility(original_output, target_bounds=(10,20))` содержит warning о непересекающихся bounds, а проверка restored slot не содержит этого warning;
- original metadata MethodContracts → restored None, metadata digest равен;
- actual imported class остаётся оригинальным. Поэтому **не доказано отключение decorators/strict execution contracts**: callable может сохранять собственный guard. Это подтверждённая потеря persisted declaration и диагностического сигнала, не claim о прошедшем запрещённом scientific output.

### Следствие и минимальный owner repair

`selection` владеет lookup, registry snapshot и cache. Он должен хранить versioned complete semantic payload отдельно от intentionally stable ABI key. Shared binding должен включать signature fields, composition bounds, execution-relevant metadata и import/source/profile identity; это не повод менять старый compilation ABI digest молча. Cache validity нельзя выводить из same-FQN+ABI count/hash. Metadata overlay от component bridge легитимно добавляет tags/domains, поэтому простое `entry.metadata == cls.metadata` тоже неверное решение: нужно связать original method metadata и admitted overlay отдельно.

## 3. MA-02: discrepancy между generic catalog и stricter method selector

`register_lazy(A.signature, A.metadata, factory=lambda: B)` допустим типам API. `.get(A.fqn)` вызывает factory и кеширует B без проверки, query/list/get_signature продолжают отдавать A.

В `read_baseline.json` public candidate catalog и ranker оставляют A runnable. Generic dispatcher получает результат `.get(A)` вместе с зарегистрированной signature A; настоящий NumpyRunner вызывает B.pure_step. Result y=-6 против baseline y=7. `history` содержит `method_fqn=A`, `success=true`. Нет mock runner и нет переписывания результата. `MethodComposer.add(A)` использует B.signature и возвращает node с FQN B, то есть candidate identity может измениться до compiled-chain freeze.

**Границы:**

- Это lower-level public API contract hole при несогласованном lazy supplier или stale persisted mapping. Обычный component bridge сначала материализует class, проверяет method protocol и equality component_id==signature.fqn, затем замыкает этот же class. В `bridge_metadata.json` два согласованных ресурса зарегистрированы, mismatched component не добавлен.
- `select_method_for_input_contract` проверяет actual FQN и stable digest до ranking. Реальный вызов baseline выделил `ValueError:actual_callable_signature_mismatch` и `input_contract_method_member_unreadable`. При этом весь default bootstrap дополнительно был incomplete из-за отсутствия DuckDB. Поэтому не утверждается успешный native selector positive; конкретный mismatch negative действительно исполнен, он не заменён только bootstrap error.
- Actual compiled chain после замены registry class отказал `MethodContractError: Selected method signature differs from the compiled chain`. Positive полного heterogeneous chain остановился на отсутствующем JAX в текущем environment. Это **partial chain evidence**, не полный e2e pass.
- Scientist `policy_runtime_method_metrics.py:3442–3460` также source-traced проверяет class/registry FQN, version и ABI и отказывает `current_method_class_and_registry_signature_disagree`. Этот authority consumer здесь не запускался.
- Governed catalog отказал `catalog_registry_preexisting_membership_not_admitted`; metadata replacement после report отказал `catalog_registry_admission_content_mismatch`.

Ремонт класса ошибки: canonical registry load reconciliation и общее typed admitted-method binding, затем consume этого binding в candidate snapshot/ranking и dispatcher. Reuse существующий `_signature_binding/_signature_matches` для ABI+bounds и component admission semantics; не плодить третий локальный hash validator в каждом caller. Lower dispatcher сам по себе не обязан выдавать scientific authority, но не должен незаметно приписывать успешное исполнение чужому advertised identity. Для intentional adapter/alias требуется явный контракт, не silent FQN substitution.

## 4. MA-03: named nested target после перезапуска

Registry eager registration сохраняет `method_class.__module__` и `__qualname__`. `persistable_import_target` считает пару `fixture_methods`, `Nested.Resource` пригодной для persistence. Snapshot writer сохраняет строку, restore регистрирует lazy factory и увеличивает restored count. Первый `.get()` использует один `getattr(m, cls)` и падает `AttributeError`.

Nested class находится на module level и доступен `fixture_methods.Nested.Resource`; это не неперсистируемое `<locals>` замыкание. В той же БД обычный `Resource` корректно восстанавливается и исполняется. Существующий Foundry owner resolver в `components/value_evidence.py:378–403` уже обходит qualname по segments и успешно находит тот же nested class в контрольном вызове.

Решение: маленький общий resolver import target на existing stdlib/importlib с явно допустимыми segments и typed failure, переиспользуемый persistence и output-owner binding, либо явное upfront refusal таких class targets. Не импортировать весь value evidence subsystem ради трёх строк и не внедрять новый plugin framework. `restore_into` должен отличать registered lazy rows от реально resolvable/validated entries; пропущенный объект не может считаться проверенной method capability.

## 5. Tests, guards и evidence limits

Все семь definitions из `tests/unit/foundry/methods/test_cache.py` выполнены без изменения их bodies/helpers. Удалены только import pytest и fixture wrapper; reset делается instrument между вызовами. Passed: eager+lazy roundtrip, value-output capability identity, old schema refusal, stale-row refresh, nonpersistable lazy skip, connection close, bounded concurrent open/close/invalidate/restore. Это **direct authored-test replay, не pytest/conftest/native CI**. Начальная попытка остановилась на missing pytest и сохранена.

Эти тесты полезны: они действительно работают с SQLite и registry, а не только маркерами. Но они не различают full semantic roundtrip от ABI-only projection, не меняют metadata при прежней signature и используют flat qualnames. Registry lazy tests проверяют deferred/once/thread behavior, но не несовпадающую factory identity. Существующий `test_selected_implementation_cache.py` уже специально проверяет bounds вне ABI и execution signature mismatch; его механизм следует переиспользовать, а не объявлять guards отсутствующими. Этот более широкий suite не запускался.

`test_census.json` даёт именованный denominator пяти выбранных test-файлов и authored definitions. Это не процент repo coverage и не count parametrized cases.

Не измерялись production latency, cache hot-start scaling, actual extension entry-points wheel/source provenance, concurrent live metadata change, full default resource denominator, causal estimator accuracy, calibration certificates, equivalence signatures, DDM ModelRegistry promotion, full restricted-executable authority, publication или revoked-custody replay. DDM model registry source частично просмотрен, но новые claims о его gates не делаются.

## 6. 3.12 против supported 3.14

Native import `MethodRegistry` на Python 3.12.14 воспроизводимо падает на Python 3.14 multi-except syntax в `ir/analytics/uncertainty.py`. Python 3.14 supported suite здесь не выполнялся, зависимости не устанавливались.

Финальный bounded loader:

- превращает только multi-except syntax в эквивалентную для 3.12 parenthesized form;
- заменяет импорт TypeVar на typing_extensions для default-support;
- берёт get_protocol_members из typing_extensions;
- применяет namespace-only skips inherited compatibility harness, восстанавливает real Core facade;
- пропускает eager causal и compiler facades для выбранных leaf modules. Когда реальному JaxRunner нужен MethodCompiler, lazily исполняет original compiler module; настоящий missing-JAX ModuleNotFoundError обрабатывается штатным Core dispatcher как unavailable. Predicate backend availability не заменён;
- не monkeypatch-ит registry/load/cache/hash/catalog/rank/dispatch predicates.

Промежуточный эксперимент с injected JaxRunner исключён из окончательного доказательства: registered handler обходил availability check. Финальные outputs содержат строку `actual runners and availability predicates`; итог повторён без такой инъекции. Initial import failures, summary asdict error и неверный fixture semver range сохранены и не записаны как product findings. Semver control исправлен на поддержанный `>=3.5.0,<4.0.0`.

NumPy dispatcher в audit environment дополнительно пишет warning о неуспешной dispatch metric recording (`TypeError`). Numerical result и actual selection-history record получены; observability integration не квалифицирована. В импортированном profile отсутствуют JAX, DuckDB и pytest. `environment.json`, `loader_*.json` перечисляют версии, source hashes и точные in-memory adaptations.

## 7. Architecture/reuse decisions и следующие acceptance

- **Extend existing selection cache/registry owner:** separate durable content schema, full semantic identity и compilation ABI. Не создавать новый ModelRegistry рядом с Foundry.
- **Wire existing admission guards:** component metadata validator, signature+bounds binding, catalog report binding и strict discovery provenance уже существуют. Общий контракт не должен смешивать candidate discoverability, executable readiness, calibration, source verification и scientific authority.
- **Reuse small qualified-import resolver:** importlib/stdlib и существующая проверенная segment resolution semantics. SQLite и общий BaseRegistry остаются подходящими; смена storage/library сама не исправит identity relation.
- **Не интегрировать Scholar/DDM как одну authority:** Foundry owns executable method identity and backend compatibility; Scholar owns literature support; DDM model readiness binds deployed model/calibration identities. Совпадение имени метода или successful arithmetic не заменяет ни одно из этих доказательств.

Acceptance после repair: metadata-only dependency/truthfulness/side-effect/profile changes; same-FQN signature changes; different same-count membership; exact bounds/contracts roundtrip; flat/nested/local/missing import targets; component overlays; duplicate policy; atomic snapshot/load under mutation; unknown/mismatched supplier refusal before execution/history; preserved legitimate alias if declared; real required-dependency profiles; cached/fresh candidate ranking parity; full governed producer→persisted discovery→selector→compiled/NumPy executor→fresh consumer under native Python 3.14. Минимум две truly admitted resources нужны для закрытия свободного роста; наши finite caller-supplied components без bound manifest этот product criterion ещё не закрывают.

`SOURCE_VALIDATION.json` связывает просмотренные и импортированные source bytes с commit. `VALIDATION.json` проверяет согласованность доказательств, не product readiness. Все выводы локальные `MA-*`, глобальная дедупликация остаётся задачей cumulative synthesis. Source не исправлялся, внешние effects/deployments отсутствуют.
