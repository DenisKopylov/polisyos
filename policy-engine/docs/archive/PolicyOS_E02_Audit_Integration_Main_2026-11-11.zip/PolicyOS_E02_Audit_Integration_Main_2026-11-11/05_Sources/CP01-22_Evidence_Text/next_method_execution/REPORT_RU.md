# Actual scientific method execution → persisted result → candidate authority

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Исходный checkout read-only. **Итог: PARTIAL; новых подтверждённых дефектов не заявлено.** Этот срез закрывает выбранный численный пробел предыдущего `next_method_admission`: исполняются настоящие built-in научные методы, а не audit arithmetic classes. Он не заменяет native qualification, actual job/engine admission или independent scientific identification.

## Результат сразу

- Настоящие `StandardDifferenceInDifferences` и `StaggeredDifferenceInDifferences` проходят real registry → finite catalog/rank → NumPy dispatcher → declared output slots → typed report/envelope → real CAS → fresh-process reader. Standard ATT = 3.000000000000005 при oracle 3. Staggered `theta_sel` = 26/3 при неодинаковых долях cohorts и числе post periods; это не cell-weighted 86/11.
- Независимый standard mean-change oracle совпал на 30 случайных finite panels и 30 их перестановках. Unit-cluster CR0 SE = 0.2788866755113603 при независимом group-change oracle 0.2788866755113584. Для staggered finite-difference derivatives 15 unit weights дали SE 1.2053123154895355 против 1.2053123154509697; независимо воспроизведённые Mammen interval/p-value совпали в объявленном допуске. Это функциональная проверка, **не доказательство coverage или causal identification**.
- Actual Scientist consumer function bodies отвергают offered-only report mutation, согласованную persistent подмену report+envelope+aliases, изменение source и alias. Обе реальные оценки после сохранения и нового процесса остаются `gate_eligible=False`; actual causal branch ConfidencePass возвращает BLOCKER даже при нулевом gate-ratio threshold, ложных proof labels и переименовании source в `ensemble`.
- **ME-O1, bounded observation:** настоящий staggered refusal (`assumption_failed`, degenerate unit influence, point=50) преобразуется локальным metric builder в policy_value=50, employment=30, welfare/net_social_welfare/gdp_change=43, без notes о failure. Однако canonical failure envelope и objective fallback дают statistical uncertainty=1; ConfidencePass блокирует. Полный production evaluator/ObjectiveStack не выполнялся. Поэтому статусная потеря отмечена для owner review, но **не названа подтверждённым authority bypass, доступным ranking exploit или новым defect-count**.

Данные: `results.json`, `reader_results.json`, `oracle_results.json`, `status_results.json`, `objective_guard_results.json`. Реальные CAS bytes находятся в `cas/` и `status_cas/`.

## 1. Выполненный путь и граница selection

Foundry registry регистрирует два настоящих исходных класса. `bootstrap_foundry_method_registry` получает явный пустой ComponentRegistry и flags `include_builtins=False/include_entry_points=False/include_dev_scan=False`; actual report связывает finite registered set с snapshot. `build_method_catalog_snapshot` и `rank_method_catalog_entries` выполняются без замены predicates. Затем каждый известный requested FQN разрешается через registry и передаётся actual dispatcher.

Это **finite candidate ranking и explicit FQN resolution**, не вся установленная method denominator и не `select_method_for_input_contract` с default discovery. Выбор между standard и staggered не выводится из научных данных автоматически; fixture явно задаёт задачу. Candidate-selection DTO в `selection/advisor.py:464–545` правильно отделяет candidate_search_only от method-validity/output semantics. MA-01/02/03 не воспроизводятся и не считаются новыми.

Typed PanelObservationalData и численные kernels исполняются целиком через compatibility loader. Данные являются маленькими deterministic synthetic DGP, а не настоящими наблюдениями, статьями или институционально принятыми sources. При persistence используются настоящие CausalEffectReport и UncertaintyEnvelope owners. Panel source/result storage реальны, но их artifact kinds `audit.synthetic_panel`/`audit.method_result` явно audit-owned.

Source `run_causal_evaluation.py:480–579` соединяет actual job и guards. **Сам `_run_primary_causal_job`, `run_job`, job evidence producer, EvaluationSafety admission и whole node/engine не выполнялись.** В их месте только harness orchestration вызывает настоящие dispatcher/persist/read owners; container результата для extracted guard представляет SimpleNamespace, не полный JobResult. Нельзя назвать это native/full actual job end-to-end.

## 2. Численные инварианты

### Standard DiD

Фиксированный oracle ATT=3 строится из baseline роста и mean-zero heterogeneous effects; при 12 units × 6 periods настоящий regression producer возвращает 3.000000000000005. Дополнительные 30 panels с разными n, periods, noise и перестановками сравниваются с независимым group mean change contrast. Достоверность parallel trends не устанавливается: report явно сохраняет `parallel_trends_identified=False`.

Actual unit-cluster covariance проходит на unique unit identities. Независимый CR0 oracle использует суммы квадратов центрированных unit changes, делённые на squared group sizes, и совпадает с regression covariance. Repeated cluster labels, missing unit IDs, unsupported covariance HAC и confidence_level=1 дают typed input_invalid. Повторяющиеся cluster labels не объявляются недостающей универсальной clustered implementation: этот профиль прямо ограничен unit clusters.

### Staggered DiD

Собственный fixture: 3 units первого cohort (start 2), 6 второго (start 4), 6 never-treated; 7 periods. Mean effects первого cohort 2,3,4,5,6 и второго 10,11,12. Взвешивание средних cohorts по selected participation даёт `(3×4 + 6×11)/9 = 26/3`; взвешивание каждого cell по числу treated дало бы 86/11. Producer различает эти targets.

Independent functional повторно вычисляет weighted treated/control change means и estimated cohort shares. Центральная finite difference с epsilon 1e-5 по 15 unit masses даёт influence-based SE. Отдельно строится seeded Mammen law (199 draws, seed19), из неё interval и p=0.005. Relative tolerance 2e-9. Bootstrap draw-generation алгоритм сохраняет одну unit-shared draw across cells. Это не независимый statistical coverage experiment и не доказательство качества NumPy RNG.

Отсутствие timing, недостаточные bootstrap draws, неизвестная control group и неполный eligible-period set дают input_invalid. Реальный degenerate-influence fixture даёт assumption_failed вместо узкого confidence interval. Данные/параметры не «исправлялись» ради success.

## 3. Result relation и owner guards

Неизменённые тела `_reconcile_selected_causal_output`, `_verify_selected_did_diagnostics` и `_verify_selected_did_target` извлечены из source AST. First two исполнены на обоих методах; target helper извлечён, но отдельно не вызывался. Staggered target всё равно входит в whole numerical report replay и producer output. Все product numerical, CAS и report functions, вызываемые guard, настоящие.

Для обоих methods:

1. Baseline persisted/offered/source replay passes.
2. Изменение только offered point при неизменном CAS report отвергается.
3. Согласованная подмена point+100, shifted CI и всех aliases, сохранённая в настоящем CAS, отвергается numerical replay.
4. Та же согласованная подмена проходит вызов **peer-only** helper без source/spec. Это корректно характеризует два контракта helper; actual selected DiD source caller передаёт source/spec. Не finding о bypass.
5. Изменение одного current source outcome отвергается и replay, и diagnostic binding.
6. Неверный historical `result` alias при правильном `report` отвергается.

Report→envelope conserves candidate band. Producer-supplied `identification_verified`, `gate_eligible`, `proof_status`, `verifier_role` не меняют projection. ConfidencePass causal-purpose branch также не доверяет source label, threshold или только status слова. Reopened original reports в новом процессе совпадают побайтно в JSON-normalized semantics и имеют один ожидаемый blocker `CONFIDENCE_GATE_ELIGIBILITY_LOW`.

Для обеих успешных оценок claim projection сохраняет `readiness_level=research_artifact` и `publishability=internal_only`. `support_status=supported` с actual artifact ref не доказывает causal identification или publication. Не выдаём это за уязвимость только по слову supported.

## 4. ME-O1: loss of failure status в локальной metric projection

Producer: `did.py:983–1002` сохраняет point, но отказывает inference при нулевой unit influence. На homogeneous effect50 получено реальное `assumption_failed`, без CI. Report сохранён и перечитан canonical owner.

Consumer: `policy_runtime_metrics.py:102–197` использует всякий присутствующий point без проверки report.status. Invoked helpers `:198–267,323–370` выводят дополнительные metrics. Для failure получены policy_value/ate=50, employment=30, welfare/net_social_welfare/gdp_change=43, source_components=[causal_effect_report], notes=[]. Missing report даёт zero baseline и note. Success-labelled control даёт те же point-derived numbers плюс CI width. Этот control явно сконструирован из failure для различения behavior, он не scientific success witness.

Здесь выполнен весь metric builder со всеми вызываемыми helpers; synthetic collaborator `candidate` содержит только пустой budget_allocation. Он не настоящая PolicyCandidateSchema. Search uncertainty classes извлечены целиком из source, чтобы проверить branch identity без импортирования whole Foundry execution; None case не вызывает их constructors. Fiscal alias constants взяты точно из исходного owner, не заменены пустым набором.

**Почему не повышаем до нового defect:** actual objective `_resolve_uncertainties(None, failed_report)` использует canonical failure envelope и возвращает statistical/structural/transport/measurement/model=1, optimization=.5. Source-traced ObjectiveStack имеет statistical constraint threshold .5 (`objectives.py:1211–1228`). ConfidencePass также возвращает blocker; Failure claim имеет `support_status=contested`, `publishability=review_required`, `readiness_level=research_artifact`, сохраняет refusal и counterevidence. Численный point может быть полезен как exploratory candidate при честно сохранённой uncertainty. Не установлено, что потребитель действительно теряет все эти guards, допускает такой result к выбору или публикует эффект.

`ProductionPolicyEvaluationBackend.evaluate` (`policy_runtime_support.py:829–959`) source-traced вызывает safety admission, metric projection, ObjectiveStack и отдельные currentness/source bindings. Наличие `promotable_source` по присутствию объектов требует дальнейшего join review, но здесь не объявляется issuance/promotion result. Full production evaluator, typed candidate, authenticated current owner, whole ObjectiveStack и public publication UNRUN.

**Owner-preserving направление:** Scientist metric owner может явно переносить estimate status/refusal в returned metadata/notes и ограничивать reuse point согласно purpose. Нельзя молча заменять every refusal point нулём: это тоже численное утверждение. Foundry statistical owner сохраняет inference contract; IR сохраняет candidate-only envelope; governance/claim owners сохраняют admissibility. Не требуется новый parallel status registry.

## 5. Tests и native честность

Selected test census охватывает 7 поимённо перечисленных files в `test_census.json`. Прочитаны actual tests с known-DGP, hand-calculated target/finite differences, diagnostic corruption, authority relabel и persisted fresh consumer, а не только constructor/assert-marker. **Исходные pytest bodies не запускались**, и их counts не используются как показатель качества или процента repository coverage. Наши scripts выполняют отдельные independent assertions.

Native Python3.12 import reproduces SyntaxError в `ir/analytics/uncertainty.py:287`; supported baseline repo Python3.14. Compatibility loader делает только equivalent parenthesized multi-except, TypeVar default compatibility и get_protocol_members import, плюс перечисленные namespace facade skips. Точные source hashes/rewrite records сохранены. Реальные NumPy 2.3.5/Pydantic 2.13.4 выполнялись, locked/native profile не квалифицирован.

Полный ConfidencePass import дополнительно остановился на missing JAX через `uncertainty_source_projection` → calibration execution_basis. Для bounded causal-only branch выполняется целый AST module **без одного import** `load_science_simulation_result_uncertainty_admission`; этот symbol остаётся unbound. Не создан success stub; paths simulation admission не выполняются и не заявляются pass. Claims projection и causal/CAS owners импортированы реально через loader.

Status helper import `scientist.methods.search.uncertainty` остановился на missing chex; извлечены только две unchanged Search DTO class definitions для negative isinstance(None) branch. Вспомогательные instrument errors сохранены: reader первоначально передал dict вместо typed envelope ref; затем получил extra LOAD_FAILED до исправления аргумента. Prefix AST extraction исправила parsing 3.14 syntax вне выбранных classes. Это ошибки harness, не findings.

Dispatcher пишет `foundry_method_dispatch_metric_record_failed(TypeError)`: numerical and in-memory history outputs получены, observability qualification отсутствует. В первом execution run default global history пытался писать вне workspace и получил OSError; запись не прошла. Остальные scripts используют явный `POLISYOS_FOUNDRY_STATE_HOME` внутри audit folder. Это не product authority outcome; repeated initial stderr не скрыт.

## 6. Reuse и оставшаяся работа

- **Keep/wire existing:** maintained dedicated DiD methods, declared ports, NumPy/SciPy linear algebra primitives, IR persistence, exact source replay и ConfidencePass. Замена всей estimator chain библиотекой не показана полезной; стандартная covariance и staggered target требуют разных scientific contracts.
- **Do not conflate owners:** registry/rank executable readiness ≠ scientific validity; numerical replay consistency ≠ independent estimator validation; Scholar literature support ≠ empirical causal identification; CAS content identity ≠ appointment/publication authority.
- MA cache/class-identity findings, RC dependence rules и LIB numerical reuse остаются самостоятельными mechanisms. Этот пакет не добавляет дубликаты или новый SYS family.
- Следующий genuine closure: supported Python3.14+locked profile; полная установленная discovery denominator; настоящие input/admission/JobSpec/MethodBackend evidence writers и full node; свежий current-source consumer без AST seams; source-bound objective/selection/publication chain и independent statistical coverage tests. Empirical assumptions, реальная идентификация и deployment не установлены.

Commands: задавать `PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 POLISYOS_AUDIT_CHAIN_ENABLED=0` и absolute `POLISYOS_FOUNDRY_STATE_HOME=<audit>/history`; последовательно запускать `probe_execution.py`, `probe_reader.py`, `probe_oracles.py`, `probe_status.py`, `probe_objective_guard.py`, затем `validate_evidence.py`. Script dependencies: `next_method_admission/probe_import.py`, `next_publication_authority/compat_loader.py`, pinned source. Initial files сохранены только как instrument history. Source не изменялся; installs/deploy/network calls не выполнялись.
