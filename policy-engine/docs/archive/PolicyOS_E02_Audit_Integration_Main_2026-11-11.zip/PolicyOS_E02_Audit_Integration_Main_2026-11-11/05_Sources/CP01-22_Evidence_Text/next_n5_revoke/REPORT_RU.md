# PolicyOS: N5 seal, fresh reader и revoke ownership

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Статус: **PARTIAL, A5 остаётся открыт**. Продолжение `next_budget_authority` и прежних FLOW-01/FLOW-02, не новая независимая группа дефектов. Исходники, тесты, настройки и зависимости проекта не изменялись.

## Главный результат

1. **Новый bounded мост до фактической lease.** Неизменённые `CandidateExperimentReuseTerminalOwner._require_executing` и terminal fence соединены с настоящими методами SQLite lease/admission. Сохранённые Python owner и ContextVar пропускают действительную lease и её renewal, но после expiry/takeover вторым SQL owner отказывают до occurrence IO. Это усиливает защитную границу: память старого witness/owner не является полномочием на publication. Полный genuine N5 → revoke → PA2 → terminal SQL commit ещё не запускался.
2. **Fresh reader и полномочия теперь разведены исполняемыми контролями.** Полный неизменённый N5 owner и реальные receipt/hash/reference определения проверяют сохранённый JSON в отдельном процессе. Историческое чтение проходит; live retention отказывает по другой process session. Даже самосогласованный marker с текущей session отказывает, если его не выдал producer. `_ISSUED` во всём probe остаётся пустым: положительный issued record не подделывался.
3. **Есть различающий hash-control.** Добавление `runtime_metrics` проходит реальную старую GY receipt, поскольку это исключённое поле, но exact N5 witness reader отвергает изменённый result. Это две разные проверки, а не два одинаковых хеша.
4. **FLOW-01 сохраняется с прежними ограничениями.** `_token` удерживает 16 из 16 synthetic объектов после GC. Завершённый observer удерживает 4 из 4 frame-local payloads; после удаления observer owners все четыре собираются. Это ownership, не измерение production RSS и не доказательство, что каждый failed capture течёт навсегда. Успешный seal продолжает сохранять capture в `_ISSUED` по исходнику; actual successful native seal здесь не воспроизведён.
5. **Native blocker не снят.** Свежий offline/no-download `uv python find ... 3.14` exit 2. Обычный import N5 exit 1 на Python 3.14-синтаксисе `core/artifacts/store.py:2155` в текущем Python 3.12.14. Ничего не устанавливалось; отсутствие native профиля здесь не доказывает отсутствие подходящего профиля на других разрешённых компьютерах.

## 1. Что именно выполнялось

`probe_n5_revoke.py`:

- Полный файл `runtime/quality/n5_execution_basis.py` исполнен без изменения байтов. Package shells обходят только цепочки `__init__`, которые сейчас не импортируются в этом профиле. Это **не ordinary native import**.
- `ArtifactID` исполнен целиком; `ArtifactRef`, identity helper, GY content hash и его helpers, N5 proof-receipt model/builder/verifier взяты точными contiguous definitions из snapshot. Никакая ветвь seal/read/reconcile не заменена permissive mock.
- Представление result/trajectory и неполный capture являются явно synthetic fixtures. Они не утверждают CAS ownership, действительный numerical outcome или исходный authenticated admission. Возможность historical read fixture не означает возможность записать этот fixture через product source owner.
- Имеется отдельный subprocess fresh-reader. Это реальный новый Python process/session, но чтение fixture JSON, не production CAS recovery.

`probe_terminal_fence.py`:

- Неизменённый dataclass `CandidateExperimentReuseTerminalOwner`, его методы и контекст terminal fence, exact reference/model equality helpers.
- Неизменённые `ControlJobRecord`, `ControlJobExecutionScope`, `ControlJobExecutionAdmission`, `current_execution_job_admission`, sink running-admission check. SQL lease/fence/transaction методы переиспользуют существующий exact-source loader из `next_lifecycle/probe_support.py`, без повторения большого process-race benchmark.
- Настоящий temporary SQLite, две store instances и реальный expiry/takeover; clock контролируется. Job materializer, creation-envelope evidence, phase/head DTO, CAS read и occurrence owner являются fixtures. PA2, весь sink.persist_terminal и final SQL frontier не исполняются.
- `effect_rows=0` не выдаётся за проверенный terminal transaction: этот probe тестирует admission gate, а terminal write не пытался делать.

Оба финальных probe, fresh subprocess и source validation завершились exit 0. Ни один из этих exit 0 не закрывает native acceptance.

## 2. Writer и negative controls

### Неполный producer не создаёт permit

Неизменённый `seal` вызван на incomplete capture fixture с настоящим завершившимся observer и observed entry, но без canonical controller/prepared owner. `_current_implementation` остаётся настоящим и отказывает; `read_joint_simulation_configuration` также настоящий и отказывает. Получен witness:

- `predicate_provenance=not_established`;
- причины `n5_selected_controller_not_canonical`, `n5_consumed_configuration_not_established`;
- `_ISSUED` по-прежнему пустой;
- exact same-result seal идемпотентен;
- смена result → `n5_execution_capture_result_relabelled`;
- смена input kind → `n5_execution_capture_input_relabelled`.

Это отрицательный writer control. Он не заменяет genuine positive producer seal. Реальный constructor/issuer `observe_candidate_n5_execution_input` в этом сценарии не вызывается.

### Читатели различают content и permission

Самосогласованный JSON marker построен только как adversarial input. Historical reader намеренно не доказывает producer issuance; его docstring требует сначала выбрать execution/result через source repository. На этом bounded входе:

| Контроль | Результат |
|---|---|
| Same-session marker без issued capture | `n5_execution_witness_not_producer_observed` |
| Историческое чтение той же fixture | Проходит content/input/trajectory joins |
| Fresh-process historical read | Проходит, session действительно другая |
| Fresh-process live reconcile | `n5_prior_live_implementation_not_established` |
| Смена только manifest profile input | `n5_execution_witness_input_mismatch` |
| Изменённый result со старой receipt | `receipt_content_mismatch` |
| Изменённый result с пересобранной receipt | `n5_execution_witness_result_mismatch` |
| DTO trajectories расходятся с content payload | `n5_execution_witness_trajectories_mismatch` |
| Изменён witness, receipt пересобрана | `n5_implementation_witness_content_mismatch` |
| Новое поле runtime_metrics, старая receipt | Receipt проходит; exact witness всё равно отказывает |
| Purpose=promotion / scope=cross_process / provenance=consumer_asserted | Типизированный schema reject |

Не трактовать historical read как authenticate/re-admit. Он нужен, чтобы старые документы оставались читаемыми без текущего live permit. И fresh GET, и worker-independent cheap retention требуют разных доказательств.

## 3. Revoke состоит из отдельных owner boundaries

### A. Implementation currentness

`n5_execution_basis.py:1129–1161` проверяет receipt, process session, recomputed predicate, issuer registry, полную input identity, исходные result bytes и заново вычисленную implementation. `:798–823` проверяет реальные loaded source/entry bindings до вызова selector; `:907–938` переоткрывает выбранный input и заново строит request. Поэтому старый content hash сам по себе недостаточен.

Эти полные positive live branches остаются **source-traced**, кроме перечисленных отрицательных ветвей. Нативные изменения callable/registry/loaded code/selected CAS producer в этом проходе не исполнялись. Авторский integration test `tests/integration/runtime_quality/test_n5_implementation_witness.py` содержит genuine served positive + input/callable/owner falsifiers; наличие теста не означает его успешный запуск в текущей среде.

### B. Execution authority

`acquisition_evaluation_dispatch.py:390–449` сначала получает admission через sink, затем сравнивает execution identity, job kind/state/payload, tenant/cell, exact action generation/head/profile и persisted executing phase. Sink `run_lifecycle.py:4962–4984` требует текущую authenticated established admission. `ControlPlaneStore.current_execution_job_admission:2174–2198` открывает текущую lease заново; saved admission не заменяет этот вызов.

Новый executable bridge:

1. Lease old-owner / attempt 1 и matching executing scope проходят.
2. Renewal той же lease проходит. Истечение не является частью immutable identity сравнения, однако SQL currentness проверяется заново.
3. Подмена head/profile отказывает `candidate_experiment_reuse_terminal_predecessor_changed`.
4. Изменение persisted executing phase отказывает `candidate_experiment_reuse_executing_artifact_changed`.
5. Refusal occurrence-owner fixture распространяется наружу, не проглатывается.
6. После expiry вторая store получает lease new-owner / attempt 2. Старый Python owner и его ContextVar ещё живы. Повторный terminal fence отказывает `control job lease is not current for job-probe` **до следующего occurrence read**.
7. Без terminal scope и после context exit → `candidate_experiment_reuse_terminal_fence_not_established`.

Это реальный stale SQL owner discriminator на потребителе N5 retention, но не проверка public cancel API и не новая транзакционная гарантия для всех writers.

### C. PA2 и окончательная публикация

`_require_live_pa2:451–495` требует фактический installed worker/provider, переоткрывает saved PA2 decision, проверяет subject и повторно выполняет bound-effect validation, а затем снова проверяет execution owner. Source показывает вызовы перед reuse dispatch и в terminal persistence.

`run_lifecycle.py:5394–5410` не пускает TerminalReceiptV2 без terminal fence. `:6004–6018` повторяет fence + live PA2 перед сохранением; `:6263–6284` строит frontier CAS через owner replay. `candidate_experiment_reuse_terminal_frontier_cas:624–684` повторно связывает history/current basis/budget и заканчивает ещё одним fence + PA2 перед возвратом CAS expectation.

**Не исполнено:** реальный permission revoke/provider response, change-of-subject, final CAS/event/frontier commit, rollback между PA2 и SQL, lost-ack recovery. Отсюда нельзя выводить общий PASS или отсутствие TOCTOU во всех external authority providers.

### D. Generic N5 sibling

`generation_cycle.py:6599–6627` не просто сохраняет successful physical outcome: currentness failure добавляет authority blocker, меняет status на `simulation_blocked` и не сохраняет usable obligation ref. Этот sibling в данном проходе только source-traced. Он не заменяется гарантиями candidate-experiment retention.

## 4. Memory lifetime: уточнение FLOW-01, не новый дефект

Полный textual census всех 2 895 `.py` под product src повторно фиксирует 53 references к N5 owner/read/bind identifiers; в самом owner всего 6 упоминаний `_OBJECTS`/`_ISSUED`: declaration, insertion/get. Public issuer-owned release/revoke/expiry API там нет. Это точный textual denominator, не доказательство отсутствия произвольного динамического обращения извне.

Memory probe изолирован от issuance:

- 16 synthetic payload objects по 1 MiB переданы реальному `_token`. Повтор того же object возвращает тот же token; 16 distinct objects дают 16 distinct tokens. После удаления внешних references и GC все 16 живы благодаря registry.
- Четыре actual observers наблюдают функцию с локальным payload. После exit profiler снят, completed=True, payloads ещё живы. После удаления observer owners и GC все четыре собраны.
- В `_ISSUED` ничего не вставлялось и ничего не удалялось. Удержание **успешного** capture глобальной issued map здесь по-прежнему установлено source chain, а не новым genuine-positive измерением.

Старый FLOW-01 подтверждается как lifecycle debt; уровень operational consequence не повышается. Нельзя чинить это blanket `_OBJECTS.clear()`, `_ISSUED.clear()` или `frame.clear()` без issuer-owned disposal contract: live reconciliation действительно читает globals/builtins/closure locals, а token не должен переиспользоваться для другого объекта. Native acceptance должен определить, кто и когда отказывается от права live retention и когда можно освободить dependencies при сохранённой historical читаемости.

## 5. Evidence, ошибки измерителя и следующий обязательный шаг

- `n5_probe_results.json`, `terminal_fence_results.json`, stdout/stderr/exitcode и `persisted_fixture.json`: воспроизводимые bounded controls.
- `SOURCE_VALIDATION.json`: 13 исполненных/цитированных source и test files byte-equal pinned commit; полный textual source denominator и refs; архивные inputs FLOW-01/FLOW-02 сверены отдельными hashes.
- `SOURCE_EXCERPTS.txt`: deciding source ranges. `OWNER_MATRIX.json`: scope/result/residual по слоям. `FINDINGS.json`: no new independent defect, два уточнения прежних FLOW.
- `probe_initial_loader.stderr.txt` и `terminal_initial_loader.stderr.txt`: первоначально whole-module AST parser не смог разобрать посторонний Python 3.14 except в confidence_ledger/run_lifecycle. Измеритель изменён на exact contiguous definition extraction. Продуктовый синтаксис не переписывался.
- `probe_initial_fixture.stderr.txt`: ранняя synthetic configuration была dict вместо native prepared model; seal закономерно упёрся в content mismatch representation. Эта непригодная fixture заменена настоящим refusing configuration reader. Не считать лог новым product regression и не скрывать его за final green.
- No software installation, source/test/config changes, deployment, provider calls, live user data, migration, full pytest/lint or production memory benchmark.

**Остаточный falsifier A5:** в поддерживаемом Python 3.14 и locked runtime получить genuine candidate V5 → NCM → positive seal → persisted selected result; сохранить этот exact result и issued owner; затем действительным owner/API отозвать lease/action/PA2 по очереди. Historical source-selected read остаётся доступным; новый live retention/terminal publish отказывает на правильном owner. Проверить смену процесса, implementation/input mutation, ошибку после seal, повторный terminal retry и cleanup после окончания permitted consumers. Отдельно подтвердить, что ordinary renewal не ошибочно отзывается. Удаление `_ISSUED` вручную не является этой проверкой.
