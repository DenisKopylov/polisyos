"""Bounded exact-source N5 owner tests. No positive issued witness is fabricated.
Whole N5 module, real selected receipt/hash/model definitions; synthetic DTO/source
surroundings and incomplete capture fixture are explicitly not native execution.
"""
from __future__ import annotations
import ast,contextlib,contextvars,dataclasses,gc,hashlib,importlib.util,json,pathlib,subprocess,sys,types,typing,weakref
from copy import deepcopy
from collections.abc import Mapping,Sequence
import numpy as np
import pydantic
from pydantic import BaseModel,ConfigDict,Field,field_serializer,field_validator
sys.dont_write_bytecode=True
ROOT=pathlib.Path(__file__).resolve().parent
SOURCE=ROOT.parent/'source';SRC=SOURCE/'policy-engine/src/polisyos';READS={}
BASIS=SRC/'runtime/quality/n5_execution_basis.py';HORIZON=SRC/'runtime/quality/joint_simulation_horizon.py';DISPATCH=SRC/'runtime/quality/acquisition_evaluation_dispatch.py';MANIFEST=SRC/'core/artifacts/manifest.py';GY=SRC/'pdc/_impl/gy_waist.py';LEDGER=SRC/'runtime/quality/confidence_ledger.py'
def mod(name,**kw):
 m=types.ModuleType(name);m.__dict__.update(kw);sys.modules[name]=m;return m

def source_parts(path,names,ns,parent=None):
 raw=path.read_text()
 try:tree=ast.parse(raw)
 except SyntaxError:
  # Only the exact requested standalone exception class is needed from this
  # 3.14 module. Parse its unchanged contiguous bytes, not a rewritten module.
  assert path==LEDGER and names==['ConfidenceLedgerError'] and parent is None
  lines=raw.splitlines();start=next(i for i,l in enumerate(lines) if l=='class ConfidenceLedgerError(ValueError):');end=next(i for i in range(start+1,len(lines)) if lines[i].startswith('class '))
  part='\n'.join(lines[start:end]);exec(compile('from __future__ import annotations\n'+part,str(path)+'#ConfidenceLedgerError','exec'),ns)
  READS[str(path.relative_to(SOURCE))]={'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'definitions':{'ConfidenceLedgerError':[start+1,end]}}
  return
 nodes=tree.body
 if parent:nodes=next(n for n in nodes if isinstance(n,ast.ClassDef) and n.name==parent).body
 for name in names:
  found=[]
  for n in nodes:
   if getattr(n,'name',None)==name:found.append(n)
   elif isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets):found.append(n)
  assert len(found)==1,(path,name)
  n=found[0];start=min([n.lineno]+[d.lineno for d in getattr(n,'decorator_list',[])]);end=n.end_lineno
  part='\n'.join(raw.splitlines()[start-1:end])
  if parent:part='\n'.join(x[4:] if x.startswith('    ') else x for x in part.splitlines())
  READS.setdefault(str(path.relative_to(SOURCE)),{'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'definitions':{}})['definitions'][(parent+'.' if parent else '')+name]=[start,end]
  exec(compile('from __future__ import annotations\n'+part,str(path)+'#'+name,'exec'),ns)

def whole(path,name):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m)
 READS[str(path.relative_to(SOURCE))]={'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'whole_module_unchanged':True};return m

def setup():
 # Package shells avoid unsupported unrelated package __init__ chains. Product bytes unchanged.
 for name in ['polisyos','polisyos.core','polisyos.core.artifacts','polisyos.runtime','polisyos.runtime.quality','polisyos.foundry','polisyos.foundry.methods','polisyos.foundry.methods.selection']:
  m=mod(name);m.__path__=[]
  if '.' in name:
   p,_,c=name.rpartition('.');setattr(sys.modules[p],c,m)
 ids=whole(SRC/'core/artifacts/ids.py','polisyos.core.artifacts.ids')
 art=sys.modules['polisyos.core.artifacts'];art.__dict__.update(BaseModel=BaseModel,ConfigDict=ConfigDict,Field=Field,field_validator=field_validator,field_serializer=field_serializer,ArtifactID=ids.ArtifactID)
 source_parts(MANIFEST,['_is_manifest_profile_sha256','ArtifactRef','artifact_ref_identity_key'],art.__dict__)
 b=whole(BASIS,'polisyos.runtime.quality.n5_execution_basis')
 g=mod('probe_gy',hashlib=hashlib,json=json)
 source_parts(GY,['GY_CONTENT_HASH_EXCLUDED_FIELDS','_GY_CONTENT_HASH_EXCLUDED_SOURCE_RULES','_GY_CONTENT_HASH_EXCLUDED_EXACT_FIELDS','_GY_CONTENT_HASH_EXCLUDED_SUFFIXES','is_gy_content_hash_excluded_field','strip_gy_volatile_fields','_GyContentHashStreamFallbackError','_legacy_gy_content_hash','_gy_content_hash_plain_json','_iter_gy_content_hash_json','gy_content_hash'],g.__dict__)
 h=mod('polisyos.runtime.quality.joint_simulation_horizon',BaseModel=BaseModel,ConfigDict=ConfigDict,Field=Field,Literal=typing.Literal,Mapping=Mapping,Sequence=Sequence,np=np,gy_content_hash=g.gy_content_hash,SimulationCalibrationStatus=typing.Literal['content_bound_run_receipt','unsupported_coupling_gated','no_run'])
 source_parts(HORIZON,['JOINT_SIMULATION_HORIZON_V1_SCHEMA_VERSION','JOINT_SIMULATION_HORIZON_STATE_CONSUMPTION_SCHEMA_VERSION','JOINT_SIMULATION_HORIZON_REPLICATION_UNCERTAINTY_SCHEMA_VERSION','JOINT_SIMULATION_HORIZON_PAIRED_INTERACTION_UNCERTAINTY_SCHEMA_VERSION','JOINT_SIMULATION_HORIZON_NUMERIC_TOLERANCE_SCHEMA_VERSION','JOINT_SIMULATION_HORIZON_SCHEMA_VERSION','_JOINT_SIMULATION_HORIZON_SCHEMA_VERSIONS','ProofReceiptError','_StrictModel','SimulationProofReceipt','_json_ready','_contains_negative_zero','_trajectory_count','build_content_bound_simulation_receipt','verify_simulation_receipt'],h.__dict__)
 return b,h,art

class FakeTrajectory:
 def __init__(self,data):self.data=data
 def model_dump(self,**kw):return deepcopy(self.data)
class ResultFixture:
 """Only representation/DTO boundary. Product receipt and witness validators are real."""
 def __init__(self,h,payload,receipt=None):
  self.payload=deepcopy(payload);self.diagnostics=self.payload['diagnostics'];self.trajectories=[FakeTrajectory(t) for t in self.payload['trajectories']]
  self.receipt=receipt or h.build_content_bound_simulation_receipt(engine_kind='offline-fixture',payload=self.payload,diagnostics=self.diagnostics)
 def content_bound_payload(self):return deepcopy(self.payload)

def refusal(fn):
 try:fn()
 except (ValueError,TypeError,RuntimeError) as e:return {'refused':True,'type':type(e).__name__,'reason':str(e)}
 raise AssertionError('expected refusal')

def witness_fixture(b,art,payload,session=None,provenance='recomputed'):
 ref=art.ArtifactRef(artifact_id='sha256:'+'a'*64,kind='fixture_n5_input',media_type='application/json',manifest_profile_sha256='sha256:'+'b'*64)
 raw=dict(schema_version='N5ExecutionImplementationWitness@1.0',authority_purpose='candidate_evaluation_retention_only',comparison_scope='same_live_process_loaded_implementation',process_session=session or b._SESSION,input_ref_identity=list(art.artifact_ref_identity_key(ref)),request_content_hash=b.exact_n5_content_hash({}),result_without_witness_hash=b.exact_n5_content_hash(payload),trajectory_hash=b.exact_n5_content_hash(payload['trajectories']),implementation={'fixture':'not a producer witness'},consumed_configuration_values={},predicate_provenance=provenance,reason_codes=[] if provenance=='recomputed' else ['fixture_unobserved'])
 raw['content_hash']=b.exact_n5_content_hash(raw)
 return ref,raw

def read_controls(b,h,art):
 payload={'schema_version':h.JOINT_SIMULATION_HORIZON_SCHEMA_VERSION,'trajectories':[{'outcome':0.5}], 'diagnostics':{'fixture':True}}
 ref,raw=witness_fixture(b,art,payload);bound=deepcopy(payload);bound['diagnostics'][b._DIAGNOSTIC_KEY]=raw
 result=ResultFixture(h,bound);out={}
 out['historical_self_consistent_marker_reads']=b.read_n5_execution_implementation_witness(result,input_ref=ref).content_hash==raw['content_hash']
 out['same_session_unissued_marker']=refusal(lambda:b.reconcile_live_n5_implementation(result,input_ref=ref))
 for field,value in [('authority_purpose','promotion'),('comparison_scope','cross_process'),('predicate_provenance','consumer_asserted')]:
  altered=deepcopy(raw);altered[field]=value;altered.pop('content_hash');altered['content_hash']=b.exact_n5_content_hash(altered)
  out[field+'_expansion']=refusal(lambda:b.N5ExecutionImplementationWitness.model_validate(altered))
 changed_ref=ref.model_copy(update={'manifest_profile_sha256':'sha256:'+'c'*64})
 out['profile_swap']=refusal(lambda:b.read_n5_execution_implementation_witness(result,input_ref=changed_ref))
 corrupted=deepcopy(bound);corrupted['trajectories'][0]['outcome']=0.75
 out['body_changed_old_receipt']=refusal(lambda:b.read_n5_execution_implementation_witness(ResultFixture(h,corrupted,receipt=result.receipt),input_ref=ref))
 out['body_changed_rebuilt_receipt']=refusal(lambda:b.read_n5_execution_implementation_witness(ResultFixture(h,corrupted),input_ref=ref))
 volatile=deepcopy(bound);volatile['runtime_metrics']={'fixture_changed':True};volatile_result=ResultFixture(h,volatile,receipt=result.receipt)
 h.verify_simulation_receipt(volatile_result.receipt,volatile_result.content_bound_payload());out['gy_volatile_change_receipt_still_passes']=True
 out['gy_volatile_change_exact_witness_refuses']=refusal(lambda:b.read_n5_execution_implementation_witness(volatile_result,input_ref=ref))
 badtraj=ResultFixture(h,bound);badtraj.trajectories=[FakeTrajectory({'outcome':0.8})]
 out['dto_payload_trajectory_split']=refusal(lambda:b.read_n5_execution_implementation_witness(badtraj,input_ref=ref))
 neg=deepcopy(bound);neg['diagnostics'][b._DIAGNOSTIC_KEY]['consumed_configuration_values']=None
 out['witness_content_changed_rebuilt_receipt']=refusal(lambda:b.read_n5_execution_implementation_witness(ResultFixture(h,neg),input_ref=ref))
 (ROOT/'persisted_fixture.json').write_text(json.dumps({'ref':ref.model_dump(mode='json'),'payload':bound},indent=2)+'\n')
 c=subprocess.run([sys.executable,str(pathlib.Path(__file__).resolve()),'fresh-reader'],capture_output=True,text=True,timeout=45)
 (ROOT/'fresh_reader.stdout.json').write_text(c.stdout);(ROOT/'fresh_reader.stderr.txt').write_text(c.stderr);(ROOT/'fresh_reader.exitcode.txt').write_text(str(c.returncode)+'\n');assert c.returncode==0,c.stderr
 out['fresh_process']=json.loads(c.stdout);assert out['fresh_process']['new_session']
 assert not b._ISSUED
 return out

def failed_seal(b,h,art):
 # Incomplete capture fixture cannot impersonate a canonical controller. No replacement
 # of seal, _current_implementation, read, reconcile or registry insertion.
 conf=mod('polisyos.runtime.quality.confidence_ledger',_LOADED_EXECUTION_OBSERVATION_SEAL=None,capture_execution_source_bindings=lambda *a,**k:(_ for _ in ()).throw(AssertionError('must not reach source attestation')))
 source_parts(LEDGER,['ConfidenceLedgerError'],conf.__dict__);sys.modules['polisyos.runtime.quality'].confidence_ledger=conf
 mod('polisyos.foundry.methods.selection.registry',MethodRegistry=object)
 class CanonicalControllerFixture:pass
 h.JointSimulationHorizonController=CanonicalControllerFixture
 source_parts(HORIZON,['read_joint_simulation_configuration'],h.__dict__)
 cap=object.__new__(b.N5ImplementationCapture)
 ref=art.ArtifactRef(artifact_id='sha256:'+'a'*64,kind='fixture_n5_input',media_type='application/json')
 cap._admission=types.SimpleNamespace(input_ref=ref);cap._sealed=None;cap._reasons=[];cap._controller=object();cap._initial=None;cap._configuration_start=None;cap._request={};cap._request_bytes=b.exact_n5_content_bytes({});cap.request_hash=b.exact_n5_content_hash({})
 cap._entry=entry_fixture;cap.method=object;cap._native_calls={}
 obs=b._ControllerExecutionObserver();cap._observer=obs;cap._codes=obs.codes
 with obs:entry_fixture()
 result=ResultFixture(h,{'schema_version':h.JOINT_SIMULATION_HORIZON_SCHEMA_VERSION,'trajectories':[{'outcome':0.5}],'diagnostics':{'fixture':True}})
 cap.bind_trajectories(result.trajectories)
 w=cap.seal(input_ref=ref,result=result)
 assert w.predicate_provenance=='not_established' and 'n5_selected_controller_not_canonical' in w.reason_codes and not b._ISSUED
 same=cap.seal(input_ref=ref,result=result) is w
 altered=ResultFixture(h,{**result.payload,'trajectories':[{'outcome':0.75}]})
 out={'provenance':w.predicate_provenance,'reason_codes':w.reason_codes,'issued_count':len(b._ISSUED),'same_result_idempotent':same,'changed_result':refusal(lambda:cap.seal(input_ref=ref,result=altered)),'relabel_input':refusal(lambda:cap.seal(input_ref=ref.model_copy(update={'kind':'other'}),result=result))}
 return out

def entry_fixture():return 1
class Payload:
 def __init__(self):self.data=bytearray(1024*1024)
def observed_payload():
 payload=Payload();return weakref.ref(payload)
def memory_controls(b):
 tokens=[];refs=[];start=len(b._OBJECTS)
 for _ in range(16):
  value=Payload();refs.append(weakref.ref(value));tok=b._token(value);assert b._token(value)==tok;tokens.append(tok)
 del value;gc.collect()
 token_alive=sum(r() is not None for r in refs)
 observers=[];frame_refs=[]
 for _ in range(4):
  obs=b._ControllerExecutionObserver()
  with obs:frame_refs.append(observed_payload())
  assert obs.completed and not obs.active
  observers.append(obs)
 del obs;gc.collect();while_observers=sum(r() is not None for r in frame_refs)
 observers.clear();gc.collect();after_dispose=sum(r() is not None for r in frame_refs)
 assert token_alive==16 and while_observers==4 and after_dispose==0
 assert len(tokens)==len(set(tokens))
 return {'token_insertions':len(b._OBJECTS)-start,'unique_tokens':len(set(tokens)),'same_identity_reused_token':True,'token_payloads_live_after_gc':token_alive,'synthetic_payload_bytes_each':1024*1024,'observer_payloads_live_after_exit':while_observers,'observer_payloads_live_after_drop_and_gc':after_dispose,'note':'Count/object reachability only. Not production RSS or workload scale. No registry clear/revoke action.'}

def main():
 b,h,art=setup()
 if len(sys.argv)>1:
  data=json.loads((ROOT/'persisted_fixture.json').read_text());ref=art.ArtifactRef.model_validate(data['ref']);result=ResultFixture(h,data['payload']);w=b.read_n5_execution_implementation_witness(result,input_ref=ref)
  print(json.dumps({'historical_read':True,'new_session':w.process_session!=b._SESSION,'issued_count':len(b._ISSUED),'live_read':refusal(lambda:b.reconcile_live_n5_implementation(result,input_ref=ref))},indent=2));return
 result={'environment':{'python':sys.version,'pydantic':pydantic.__version__,'numpy':np.__version__},'classification':'bounded_exact_source_not_native','scope_limits':['No genuine candidate V5 source admission, NCM execution, positive producer seal, CAS source repository, SQL lease or PA2 gateway executed.','Package shells bypass package init only. N5 full bytes and listed definitions unchanged.','Representation DTO and incomplete capture fixtures are synthetic. No insertion into _ISSUED or replacement of its deciding methods.'],'read_controls':read_controls(b,h,art),'failed_seal':failed_seal(b,h,art),'memory':memory_controls(b),'positive_issued_count':len(b._ISSUED),'source_readset':READS}
 (ROOT/'n5_probe_results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
