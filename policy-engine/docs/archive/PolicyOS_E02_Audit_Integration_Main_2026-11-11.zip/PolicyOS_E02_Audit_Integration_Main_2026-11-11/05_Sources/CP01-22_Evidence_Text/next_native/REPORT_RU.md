# PolicyOS: штатный Python/locked profile и границы запуска

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Целевой snapshot read-only. Этот проход завершён как **partial qualification**, а не как native acceptance или завершение глубокого аудита.

## Короткий результат

1. **Штатное выполнение в текущем cloud workspace заблокировано средой.** Offline/no-download поиск не нашёл Python 3.14; доступны Python 3.12.14 и 3.13.5. Нужный lock не установлен. Это не отказ продукта и не провал его тестов.
2. **Найден отдельный дефект contributor bootstrap:** его завершающий doctor запускается как файл, хотя doctor использует относительный импорт пакета. Точный command-shape replay на исходных doctor/helper bytes падает; соседние module-mode callers проходят тот же ограниченный контроль. Полный bootstrap и Python 3.14 не запускались.
3. **Все четыре lock profile читаются offline.** Frozen export прошёл для minimal/docs/runtime/research. Для minimal/runtime в проверенных Linux x86_64 и modeled macOS14 arm64 lock содержит подходящие wheel tags для всех выбранных registry requirements. Это не доказательство скачиваемости, установки, importability или freshness lock.
4. **Research не является wheels-only профилем:** четыре выбранных пакета имеют в этом lock только sdist. В modeled macOS docs также нет подходящего wheel для watchdog. Это сведения для безопасного планирования, не новые product bugs.

## 1. Проверенная среда и точные blockers

Declared contract: `.python-version` = 3.14; `pyproject.toml:9` требует `>=3.14,<3.15`; lock требует `==3.14.*`; CONTRIBUTING и `_common.py:53–62` задают Python 3.14, Node 22, uv 0.9.21 и четыре профиля. Composite CI action также задаёт Python 3.14 и uv 0.9.21.

Наблюдение в текущей среде:

| Проверка | Наблюдение |
|---|---|
| `uv python find --no-project --offline --no-python-downloads 3.14` | exit 2: interpreter not found in virtual environments, managed installations or search path |
| `uv python list --only-installed --offline` | Python 3.12.14 и 3.13.5; exit 0 |
| `uv --version` | 0.13.6, не canonical 0.9.21 |
| `node --version` | v24.22.1, не contributor 22.x |
| `python -m pytest --version` | exit 1: No module named pytest |
| Package metadata | policy-engine, pytest, Ruff, JAX/JAXlib, DuckDB, PyArrow, LangGraph не установлены в текущем Python 3.12; Pydantic 2.13.4 / pydantic-core 2.46.4 против lock 2.12.5 / 2.41.5 |
| Native doctor import, Python 3.12 и 3.13 | Оба exit 1 на `tools/lib/fs.py:884`: поддерживаемый проектом Python 3.14 exception syntax |

Команда doctor была ограничена `--skip-playwright --skip-lockfile-checks --skip-contract-checks`, чтобы не запускать установки/контрактные subprocess. До проверок она не дошла. Эти два tracebacks нельзя считать нарушением supported runtime: использованы неподдерживаемые Python.

Первый uv discovery остановился на readonly default cache `/home/agent/.cache/uv`. Повтор с явно выделенным output cache в `next_native/uv_cache` и прежними `--offline --no-python-downloads` завершил поиск и подтвердил отсутствие 3.14. Это смена места временных файлов, не установка интерпретатора. Никакое разрешение на скачивание, install или bypass не запрашивалось и не обходилось. Неопределённых внешних эффектов нет.

`environment_management.list` дополнительно показал connected MacBook-Air-Denis.local и connected cloud computer. На Mac не переключались, его интерпретатор, checkout и lock не исследованы. Следовательно, вывод ограничен текущим cloud workspace, а не всеми компьютерами пользователя. Desktop не объявлен offline.

Первичные результаты: `preflight_results.json`, `preflight_*.stdout.txt`, `preflight_*.stderr.txt`, `native_preflight.txt`, `native_find_requalified.txt`, `runtime_discovery.txt`.

## 2. NATIVE-01: неверный package context при bootstrap doctor

**Priority:** средний contributor tooling defect. **Confidence:** высокая для структуры caller/import; native end-to-end остаётся незакрытым.

- `tools/devx/workspace/bootstrap.py:121–125` строит `[sys.executable, "tools/devx/workspace/doctor.py"]`.
- `bootstrap.py:167–177` добавляет эту команду в обычный default путь, если не задан `--skip-doctor`, и исполняет её.
- `doctor.py:18–22` сначала находит repo imports, затем исполняет `from ._common import (...)`. У script-mode main нет package context; добавление sys.path этого не исправляет.
- Существующие `verify.py:86–95` и `ci_parity.py:63–71` используют корректный `-m tools.devx.workspace.doctor`.
- `tests/repo_quality/tools/test_workspace_phase3.py:27–46` подменяет `run_command`, проверяет labels и не исполняет завершающий subprocess. Это объясняет конкретную непроверенную границу, а не доказывает отсутствие всех других тестов.
- `.github/actions/setup-policy-engine-python/action.yml:43–50` явно передаёт `--skip-doctor`. Находка не означает падение этого CI action.

**Проверка:** `probe_bootstrap_doctor.py` компилирует неизменённое `_doctor_command` из каждого caller, затем воспроизводит file-mode/module-mode через runpy в отдельных процессах с `--list-surfaces`. Doctor, `_common`, `tools.lib.imports` исполняются из настоящего read-only snapshot. Единственная явно указанная dependency shim: namespace `tools.lib` обходит его `__init__`, иначе Python 3.12 раньше остановится на 3.14 syntax в fs. Никакие doctor predicate/function bodies не заменяются. Это не full installed import и не supported-profile тест.

Результаты:

- bootstrap command form: exit 1, `ImportError: attempted relative import with no known parent package`, doctor.py:22;
- verify module form: exit 0, выведены 8 optional surface names;
- ci_parity module form: exit 0, те же surface names.

**Последствие:** после дорогостоящих default bootstrap шагов финальная квалификация может остановиться на упаковке команды, не выполнив проверки. Это не authority bypass: false PASS не установлен, поскольку subprocess failure прерывает flow.

**Минимальное направление исправления:** использовать уже имеющуюся module command form, а не новый bootstrap framework. Добавить safe subprocess test для doctor `--list-surfaces`, который различает script/module invocation; label-only test сохраняет отдельную задачу. Исходники не исправлялись.

**Residual acceptance:** в настоящем Python 3.14/locked environment выполнить прямой file-mode `python tools/devx/workspace/doctor.py --list-surfaces` и module-mode `python -m tools.devx.workspace.doctor --list-surfaces`, затем test действительного caller без повторной установки окружения и других bootstrap эффектов.

Evidence: `bootstrap_doctor_results.json`, `bootstrap_probe_stdout.txt`, `bootstrap_probe_stderr.txt`, `probe_bootstrap_doctor.py`.

## 3. Frozen profiles: что удалось проверить без установки

Для каждого профиля использован настоящий `uv export --project <snapshot>/policy-engine --frozen --offline --no-python-downloads --no-hashes --no-header --no-annotate --no-emit-project` с теми extras, которые задаёт `UV_SYNC_PROFILES`. uv 0.13.6 не считается эквивалентом canonical uv 0.9.21. Export не устанавливает зависимости и с `--frozen` не доказывает согласованность текущего manifest с lock. Все четыре stderr пусты, exit 0.

Default dev group сохранена, как при обычном `uv sync`; из-за неё даже docs export содержит pytest/runtime-http prerequisites. Не предполагалось, что словесное «lint + docs» означает отсутствие остальных base/dev dependencies.

| Профиль | Export lines | Linux selected registry requirements | Modeled macOS14 arm64 selected registry requirements |
|---|---:|---:|---:|
| minimal | 173 | 170 | 170 |
| docs | 191 | 189 | 189 |
| runtime | 174 | 171 | 171 |
| research | 256 | 253 | 235 |

Каждый профиль дополнительно содержит один локальный vendored odfpy wheel. Export lines включают platform-conditional строки, поэтому не равны выбранным package counts. Полные именованные выбранные множества и найденные wheel filenames содержатся в `profile_results.json`.

`inspect_native_profiles.py` применяет PEP 508 markers для Python 3.14 и сравнивает wheel tags из lock с CPython 3.14 standard ABI, не free-threaded. Linux target использует платформенные tags текущего x86_64/glibc 2.41; macOS14 arm64 задан явно как модель, а не взят с компьютера пользователя.

- minimal/runtime: для всех выбранных registry requirements есть хотя бы один подходящий wheel tag на обоих modeled targets;
- docs: Linux без wheel gaps; macOS target не имеет подходящего wheel для watchdog 6.0.0, sdist в lock присутствует;
- research: autograd-gamma 0.5.0, hnswlib 0.8.0, osqp 1.1.0 и ruptures 1.1.10 имеют ноль wheels в lock и присутствующий sdist на обоих targets. Это не равнозначно невозможности сборки и не означает, что каждый пакет требует native compiler.

Вендорный `odfpy-1.4.1-py2.py3-none-any.whl` существует, zip integrity check прошёл; SHA-256 `1d1c3ea36a422d3c5cd4c2457ea0e0be59841d6c26d28bd3d5e43f060565d11b` совпал с README. Внутри 62 entries, 34 `odf/*.py`. Upstream sdist здесь не скачивался, утверждение README о source equality заново не квалифицировано.

**Не подтверждено:** доступность registries сегодня, download hash внешних wheels, install/build success, binary import/ABI, CPU/backend/accelerator compatibility, canonical uv behavior, lock freshness, runtime behavior. Успех frozen export нельзя подменять этими утверждениями.

## 4. Контроль границ и следующий безопасный шаг

Не запускались bootstrap/sync/install, solver/training jobs, acquisition, production APIs/DB, полный pytest, Ruff/mypy, native runtime HTTP, installed wheel, generated contracts, remote refs или deployment. Все новые файлы лежат в `next_native`; исходники и lock не редактировались.

Полный `doctor` также не является заведомо чистым read-only listing: `_check_lockfiles` вызывает `uv lock --check` и `pnpm install --frozen-lockfile --lockfile-only --ignore-scripts`; `_check_generated_contracts` вызывает `uv run ...`. Поэтому без штатного окружения в этом аудите выбраны skip-флаги и отдельный `--list-surfaces`, а не автоматический запуск всей команды.

Следующая квалификация:

1. Проверить уже существующее Python 3.14/uv 0.9.21 окружение на выбранном компьютере и bind его к точному source/lock SHA. Подключённый Mac является возможным путём, но его состояние неизвестно. Если окружение нужно устанавливать, вынести это в отдельное разрешённое действие; не маскировать install под audit.
2. Для direct imports и targeted tests использовать установленный `.venv/bin/python`, исключив неявный `uv run` sync. Квалифицировать Pydantic 2.12.5/core 2.41.5 и выбранные extras.
3. Сначала выполнить безопасные doctor command-form controls и выбранные существующие contract/unit tests по findings других направлений. Runtime HTTP test fixtures должны писать только во внешние временные каталоги. Full app/production effects не нужны для начальной квалификации.
4. Затем запустить действительно затронутые native gates и installed distribution tests на том же source pin. Их статус сейчас **UNRUN/BLOCKED**, не green.

`SOURCE_VALIDATION.json` привязывает выбранные 24 source/config/test files, подтверждающие выводы, к baseline hashes. Это verification readset данного прохода, не semantic coverage всех 29 934 tracked файлов. `git status --short` snapshot после проверок пуст. Новая перепись репозитория не создавалась.
