# PolicyOS: persisted free-grow и точная семантика binding

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Source read-only. Продолжение `next_freegrow`, `next_domain_composition`, `next_evidence_composition`; scope WP-05 и owner joins из `next_coverage_status`.

**Итог: PARTIAL.** Выполнен source-bounded путь с настоящими source bodies, локальным filesystem persistence и отдельным процессом чтения. Это не native package qualification, не DuckDB release build, не source admission и не scientific validation.

## Главный результат

1. **Новая явно объявленная сфера проходит доступную data-driven цепочку без ветки в продукте:** aquatic thermal exposure → JSON governed rows → реальный `RequirementToCapabilityResolver` и authority composer → реальный `DataRequirementCompiler` → immutable V2 JSON writer → fresh subprocess parser/audit surface → реальный Fabric candidate projection. Новые construct и family внесены только в audit fixtures, исходники не менялись.
2. **PG-01: сохранённая legacy scope semantics слабее sibling candidate discovery.** При требовании периода, лишь частично покрытого источником, resolver выдаёт `selected_exact`, `admissible`, `satisfies_claim_evidence=true`; sibling discovery для той же строки и того же запроса выдаёт `no_match / time_window_not_covered`. Inverted/malformed interval и jurisdiction mismatch также различаются. Полный compiler report сохраняет оба результата одновременно; immutable writer и fresh process reader расхождение статусов не устраняют.
3. **Scope unsupported/unknown не всегда становится явным отказом authority binding.** Незнакомые ключи population filter игнорируются; неизвестная population/time, отсутствие sample size при заявленном floor, пустые source assets и withdrawn lifecycle в выбранном resolver seam не предотвращают selected_exact. Это диагностические границы того же metadata selection пути, не восемь новых independently counted incidents.
4. **Положительные guards остаются существенными.** Wrong construct, известные wrong population/geography/entity, полностью непересекающееся время, wrong schema, явно малый sample, candidate-only evidence, запрет rights и явный blocked authority отвергаются. Descriptor tamper, duplicate JSON key, неизвестная report schema и collision с чужими bytes в output path также отвергаются. Fabric выдаёт только `candidate_only / authority_status=not_established`, даже когда stored binding selected_exact. Publication/closeout bypass не установлен.

## 1. Что действительно выполнено

Новая synthetic сфера: температурная нагрузка водной экосистемы.

- Construct: `aquatic_thermal_exposure`.
- Legacy family projection: `aquatic_temperature_observations`.
- Entity: `river_reach`; population: `coldwater_fish_habitat`; geography/jurisdiction: `audit_watershed`.
- Source interval: 2026-01-01…2026-12-31. Positive query: 2026-03-01…2026-06-30.
- Все observation/quality/rights/authority/lineage поля являются явно synthetic owner assertions. Ни один настоящий датчик, измерение, лаборатория, закон или empirical construct validation не проверялся.

Probe исполняет неизменённые тела owners в audit namespaces с реальными Pydantic DTOs. Product imports исключены, зависимости связаны с теми же source bodies; единственный поздний import bridge writer подключает настоящий `write_bytes_once` к настоящему `AtomicFileWriter`. Это не mock storage: JSON bytes действительно записаны, fsync/hard-link write-once path выполнен, второй Python process заново читает registry/report с диска. Но способ загрузки source definitions не эквивалентен импортированному/установленному продукту.

`core/contracts/control.py` содержит несовместимый с Python 3.12 синтаксис вне нужного DTO. Его `DataNeed` загружен как точный неизменённый class block, без соседнего кода. Предшествующий grammar prelude содержит исторические `Any` для неиспользуемых здесь `ArtifactRef`, `ProblemFrame`, `PolicySpec`; **ни один такой объект не используется как доказательство persistence или scientific execution**. Действующий report writer использует реальный filesystem owner, не `Any`.

Время финального bounded probe и RSS записаны в `results.json.profile`; прогон порядка 1–2 секунд и 40 MB, без providers/network/training/solver/jobs.

## 2. Owners и реальная runtime связь

Все source пути ниже относительно `policy-engine/src/polisyos/`; точные excerpts и SHA-256 в `source_excerpts.json` / `SOURCE_VALIDATION.json`.

### Declaration и registry

- `core/contracts/capability_resolution.py:77–133` задаёт `RequirementToCapabilityQuery`: construct, entity/population/geography/time, posture/purpose, modality/evidence/schema/sample constraints. Construct не закрыт enum предметных областей.
- `runtime/quality/capability_index.py:62–95,364–441` содержит strict `CapabilityScope` и `EvidenceCapability`. Новая строка допускается как данные; наличие нового ID само по себе не доказывает observational meaning.
- `runtime/quality/capability_resolver.py:432–448` реально читает JSON по `architecture/policy_design_case/layer2_s3_governed_capability_rows.json`, преобразует source row в DTO и создаёт resolver. Probe даёт этому owner **audit-only root**, не изменяет настоящий governed файл. Запись fixture выполнена harness, не штатным producer/admission инструментом.
- Этот reader не оторван от runtime: `generation_cycle.py:14117–14155` предпочитает injected owner port, затем разрешённые runtime dependencies, затем при наличии repo root вызывает `governed_fixture`. Новый файл по настоящему product root не создавался.

### Typed binding и candidate discovery

- `capability_resolver.py:514–557` вычисляет binding; `559–632` отдельно вычисляет candidate descriptors. Это **соседние результаты**, а не chain, в котором успешный discovery даёт право исполнить или подтверждает binding.
- `capability_authority.py:761–915` применяет факторы и выдаёт binding status и `satisfies_claim_evidence`. Input fields остаются supplied metadata; здесь нет вызова измерителя, научного verifier или реального registry operation.
- Не смешивать этот legacy composer с **C02 `CapabilityDiscoveryAuthorityResolver`** (`capability_authority.py:579–720`): admitted_authority там требует независимо проверенный owner-signed binding, content/purpose/consumer/audience match и DS9 currentness. Этот более сильный authority owner SOURCE_TRACED, не выполнен и не обойдён нашим selected_exact.
- `data_requirement/compiler.py:418–498,1510–1590` вызывает оба порта и сохраняет snapshot/query/discovery. `data_requirement/_impl/models.py:232–302` проверяет query, construct, requirement и index identity, но не отменяет selected binding, если sibling discovery no_match. Это не новая независимая finding, а путь сохранения PG-01.

### Сохранение и fresh reader

Выполненный JSON path:

- `data_requirement/compiler.py:1089–1215`: strict parse, V2 file по SHA-256 точных bytes, сохранение unchanged original bytes, conflict refusal.
- `core/artifacts/__init__.py:303–326` → `_atomic_write.py:61–137`: фактический write-once filesystem owner.
- Fresh subprocess заново загружает source definitions, открывает registry и сохранённый JSON, делает typed parse и `data_requirement_compilation_audit_surface`. Positive и partial-time reports проверены в разных процессах, данные сверены полностью, а не только по статусу.

**Реальный N7 CAS path существует, но здесь SOURCE_TRACED / UNRUN:**

- `generation_cycle.py:13558–13586` вызывает `persist_and_verify_data_requirement_compilation_report`; при отсутствии store отказывает `n7_compiler_report_persistence_unavailable`.
- `acquisition_planner.py:7056–7190` требует typed report, run/scenario/input binding, selected manifest profile, digest и readback equality. `7193–7215` явно ограничивает этот факт representation/custody, не producer authenticity/source authority.
- `generation_cycle.py:14390–14415` заново читает persisted report и сравнивает specs/resolutions; `16350–16375` проверяет replay относительно ожидаемого report.
- В probe этот CAS bridge **не заменён fake CAS и не объявлен выполненным**. Public JSON writer не является исполненным N7 path; это отдельный доступный canonical persistence owner. Обнаружение runtime bridge устраняет подозрение «реального persisted consumer нет», но не закрывает его native execution.

### Release-time DuckDB path

`capability_index_compiler.py:203–337` → `write_capability_index_duckdb:2579+` → manifest/logical digest; `capability_discovery.py:1616–1710` заново читает persisted release, проверяет digest, release ref, compiler version/mode и типизирует rows. Этот путь не исполнялся: DuckDB отсутствует. `RequirementToCapabilityResolver.from_duckdb:470–512` читает resolver slice напрямую; не следует приписывать ему проверки manifest loader. Ни один из этих методов не исполнялся через SQLite-суррогат.

## 3. PG-01: legacy exact binding сохраняет overlap semantics

**Residual risk: medium; evidence confidence: high для local mechanism и сохранённого report. Это documented legacy semantics, не доказанная regression или authority bypass.**

Независимый review нашёл важное нормативное ограничение: `data_requirement/README.md:217–223` прямо сохраняет исходную интерпретацию existing claim-evidence resolution и historical bytes, одновременно усиливая candidate coverage. Следовательно, различие двух postures намеренно не устранено новой candidate версией. `selected_exact` классифицирует выбранный evidence mode после legacy predicates и не следует трактовать как доказательство полного temporal entailment. Локальный ID PG-01 фиксирует значимую границу/остаточный риск, **не добавляет новый подтверждённый product defect только из-за асимметрии**.

Positive исходный source interval покрывает весь query. Он получает selected_exact и candidate descriptor. Контроль меняет **только query interval** на 2026-06-01…2027-12-31:

- Authority resolver: `selected_exact`, `authority_envelope_result=admissible`, `satisfies_claim_evidence=true`.
- Candidate discovery: `no_match`; hard rejection `time_window_not_covered`.
- Compiler: `state=binding_returned`, selected binding без blocked reasons и sibling no_match в одной `capability_requirement_resolution`.
- Requirement basis остаётся `established/recomputed`, потому что это наличие producer-owned basis, **не доказательство claim support**. Сам DTO прямо определяет этот смысл (`models.py:305–324`). Пустой registry также может дать established basis с явным blocked binding; это корректное различение requirement и найденного evidence.
- V2 report сохраняется и fresh reader возвращает то же расхождение статусов. Это не только in-memory marker test.

Причина: `_candidate_rejection:802–853` вызывает `_time_window_matches:1051–1066`, который проверяет строковыми сравнениями только отсутствие полного разрыва. Он не требует полного покрытия и не валидирует календарь/порядок интервала. Sibling `_source_discovery_scope:978–1030` использует `candidate_source_time_coverage` (`core/contracts/capability_resolution.py:136–183`), который валидирует ISO dates, inverted interval, overlap и полное покрытие. Фактор `_time_scope_factor:1050–1063` в authority composer читает freshness label, а не query interval, поэтому не исправляет mismatch.

Отдельные discriminators:

- Inverted query 2026-08-01…2026-07-01: selected_exact против `requirement_time_window_inverted`.
- Malformed query 2026-06-XX…2026-07-XX: selected_exact против `requirement_time_window_invalid`.
- Source geography совпадает, source jurisdiction иной: selected_exact против `jurisdiction_mismatch`.
- Полностью outside query 2027-01-01…2027-12-31: binding blocked и discovery no_match. Значит проверка времени есть, но означает overlap, а не требуемое полное покрытие.

**Guard/counterevidence:** Fabric projection (`data_requirement_adapter.py:395–448`) не потребляет selected_exact как доказательство готового источника. Для обоих reports получен `candidate_only`, `authority_status=not_established`, candidate discovery требует native admission. Partial-time path сохраняет `candidate_source_discovery_no_match`. N7 CAS/custody guards и последующие source/method gates не исполнялись; утверждать их обход нельзя.

**Existing tests:** `tests/unit/runtime/quality/test_capability_resolver.py:825–857` уже проверяет jurisdiction/full known interval у candidate discovery и лишь равенство `resolve` до/после вызова discovery. `861–910` проверяет malformed/inverted candidate coverage. Это полезные guards, но не assertion о корректном authority status на том же input. Эти pytest tests читались, не запускались нативно.

**Направление дальнейшей qualification, если требуется полное scoped support для legacy authority:** один canonical scope-compatibility owner с явными `matched / mismatch / unknown / unsupported`. Candidate path может сохранить unknown с limitation; authority binding не должен превращать unsupported/unknown/incomplete coverage в exact. Нельзя просто «назначить discovery authority» или ослабить его refusal. Acceptance: полное покрытие/partial/disjoint/invalid/inverted/jurisdiction, затем тот же compiler→persist→fresh reader→реальный N7 replay при доступной supported среде.

## 4. Точная matching semantics и unsupported boundaries

Наблюдения ниже относятся к `RequirementToCapabilityResolver`, не ко всем semantic owners PolicyOS:

- **Construct:** `_bare_construct` убирает `construct:` и нормализует case/hyphen/space; затем exact normalized string equality. Нет поиска синонимов, causal quantity identity, единиц или transportability.
- **Geography:** normalized equality либо capability `global`/`multi_context`. Это не географическая containment/ontology проверка.
- **Entity:** equality либо пересечение `_or_` alternatives; query `construct`/`unspecified` действует как wildcard.
- **Population:** читаются только `type`, `population`, `target_population`, `population_type`, `segment`, `segments`, `groups`; values сравниваются по нормализованным names и малой таблице firm/region aliases. Несколько values означают OR. Unknown source population возвращает match.
- **Unsupported population predicate:** `{"water_temperature_c_lt":12}` не попадает ни в один известный key. Authority binding остаётся selected_exact. Candidate discovery добавляет `requirement_population_not_established`; если рядом есть распознанный `type`, этот unknown-marker исчезает, хотя дополнительный threshold всё равно не проверяется. Это не поддержка arbitrary filter expressions.
- **Time:** authority overlap сравнивает strings; candidate calendar parser отдельно требует known coverage. Unknown source interval остаётся selected_exact; candidate несёт `source_time_coverage_not_established`.
- **Required modalities:** overlap с набором, не all-of. **Evidence modes:** exact/categories; simulation/candidate запрещены default query.
- **Schema:** явное несовпадение required schema блокируется. **Sample:** 400 при требовании 500 блокируется, но отсутствующий `sample_size` при floor 100 не блокируется (`capability_authority.py:1364–1371`).
- **Source assets:** пустой список не останавливает binding при остальных высоких assertions, но candidate discovery даёт `source_assets_missing`.
- **Lifecycle:** `withdrawn` при остальной неизменённой строке не меняет selected_exact в этом resolver. Соседняя index-discovery freshness projection учитывает withdrawn/deprecated (`capability_index_compiler.py:984–996`), поэтому нельзя распространять finding на все discovery surfaces.
- **Negative authority:** candidate_unverified, rights.claim_evidence_use_allowed=false и явный blocked governed_pilot envelope отказывают, несмотря на высокие остальные scores.

Это supporting residuals общей проблемы «metadata eligibility не гарантирует точную scoped support». Они не доказывают, что canonical producer выдаёт подобные rows в production, что они проходят release/admission, или что внешняя политика опубликована. Семантика названной новой сферы не возникает от добавления её labels.

## 5. Zero-code growth: что прошло, что требует явного data bridge

1. Reader открывает новый ID и construct из реальных synthetic JSON bytes, strict DTO успешно построен.
2. Resolver находит exact scope и накапливает reason/limitations; кандидат descriptor содержит полный row и digest.
3. Compiler сохраняет declared construct и новую family через переданный `ScenarioFamilyConstructRow`. Это data-driven addition, без новой Python ветки.
4. **Без family alias** compiler сохраняет resolution, но выдаёт 0 specs и `basis=not_established / governed_capability_resolution_incomplete`. Следовательно, одна строка capability недостаточна для проверенного legacy-family consumer пути. Family row тоже должен быть producer-governed data. Это явный dependency, не замаскированный generic fallback.
5. **Без optional resolver:** 0 specs и not_established. **require_capability_index=true:** missing resolver вызывает FileNotFoundError.
6. **Пустой registry:** сохраняются requirement и `blocked_construct_not_observed`. Наличие requirement не подменяется успешным evidence.
7. **Новая domain declaration** `aquatic_ecosystem_thermal_policy` превращается в CUSTOM с `status=unresolved`, исходным declared input и запретом использования как `domain_semantic_support`. Это корректный typed unsupported vocabulary result. Выполнен explicit claim/construct path, не arbitrary natural-language grammar понимание водных экосистем.
8. Fabric projection на positive path формирует DataNeed, но сохраняет `candidate_catalog_fetch_binding_not_established`: fixture не имеет настоящего connector/dataset/profile binding. Существование source descriptor не является executable source selection. Network fetch не производился.

**Итог по free-grow:** локальная persisted extensibility и typed refusal подтверждены; zero-code natural-language→live discovery→execution→admission новой сферы **не подтверждён**. До него остаются native index producer/readback, admission новых governed rows, actual connector/fetch binding, source-quality/quantity/unit semantics, реальный model/method execution и authority gates.

## 6. Output identity и fresh read

Проверенные различия identity:

- `binding_id` имеет форму `binding:{capability_id}`. Он одинаков для другого query и для изменённого row с тем же capability ID. `capability_index_ref` в governed JSON reader также остаётся supplied locator. Их нельзя трактовать как content digest или полную query identity.
- Candidate `content_digest` меняется при изменении row; замена population внутри descriptor без нового digest отвергается `candidate_source_descriptor_digest_mismatch`.
- Старый resolver хранит свой loaded snapshot. Новый resolver видит новый row по тому же path/ref. Это snapshot instance, не доказанный auto-refresh контракт и не ранее найденный G1 cache defect.
- У двух compilation reports с одним run/claim/requirement IDs, но разным interval, различаются `input_content_hash`, exact bytes и SHA-256 filenames. Оба файла сосуществуют, historical result не перезаписан.
- Повторная запись unchanged bytes возвращает тот же путь. Файл с другими bytes под ожидаемым content filename вызывает `data_requirement_report_content_conflict`.
- Duplicate `run_id` JSON key и unsupported schema отвергаются. Original bytes сохраняются при read/write без изменения payload.
- Fresh positive reader и fresh partial-time reader сверяют полный report. Claim-level mismatch не исчезает от корректного byte identity; custody не чинит semantic eligibility.

Логические IDs, row content digest, input hash и persisted payload digest имеют разные роли. Само совпадение logical IDs здесь не объявлено дефектом: downstream payload/query содержат различающий контекст, V2 persistence различает содержимое. Consumer, который использует один binding_id как authority key, этим probe не установлен.

## 7. Что не запускалось и почему

- Native import реального `polisyos.runtime.quality.capability_resolver` предпринят: exit 1, Python 3.12 не разбирает `core/artifacts/store.py:2155` (`except FileNotFoundError, ValueError, ArtifactOwnershipError:`). Поддерживаемая база проекта Python 3.14. Это environment outcome, не product regression.
- Native pytest, wheel/installed surface, DuckDB build/manifest loader, actual N7 CAS persist/replay, HTTP provider, live registry/conformance, catalog fetch/admission, numerical output и scientific validity: UNRUN.
- Никаких dependency installs, source edits, commits, deployment, production-data mutations, внешних сообщений или provider requests.
- Read-only validation сверяет named source files с исходным pinned SHA-256 census и HEAD/status. Это не новое полное audit всех файлов; parent final census остаётся отдельной обязанностью.
- `next_persisted_growth` закрывает конкретный доступный persisted JSON/fresh-reader join, но не весь WP-05 и не весь аудит.

## 8. Независимый review и дополнительные guards

`next_review_growth/INDEPENDENT_RESULTS.json` независимо воспроизводит 18 scope cases и пять world-slot joins. На ещё одном construct `review_salinity_exposure` полноценные synthetic fetch metadata дают один routing join. Partial interval сохраняет selected_exact, но discovery=no_match и join=0. Удаление fetch binding и mutation scope-profile также дают join=0. Candidate-unverified может иметь routing join=1, но binding blocked и candidate.satisfies_claim_evidence=false: это путь подготовки acquisition, не admission.

Source guard: `data_requirement/compiler.py:977–1075` требует candidates_returned, complete binding/query/profile, исходный scope, declared source asset/fetch metadata и neutral coverage predicate. Reviewer подтвердил реальный N7 CAS owner trace и не объявляет его native execution. Эти controls находятся в отдельном review пакете; их provenance не смешивается с авторским probe.

## 9. Доказательства и воспроизведение

- `probe_persisted_growth.py`, `results.json`, `summary.json`, stdout/stderr/exitcode.
- `inputs/registry/.../layer2_s3_governed_capability_rows.json`, `inputs/query.json`: synthetic inputs.
- Активные content-addressed paths перечислены в `results.json.identity.report1/report2`, absent-resource path в `compilation_controls.absent_resource_path`. Другие content files в этой audit-папке принадлежат сохранённым ранним iterations harness и не используются как final evidence.
- `fresh_reader.json`, `fresh_negative_reader.json`: полный output отдельных reader processes.
- `source_evidence.json`, `source_excerpts.json`, `caller_census.json`, `SOURCE_VALIDATION.json`.
- `native.stderr.txt`: exact native blocker. `probe.initial/second/third.stderr.txt`: сохранённые harness setup failures; они не объявлены product defects. Final probe stderr пуст.
- `FINDINGS.json`, `flow_matrix.json`, `MANIFEST.json`, `SHA256SUMS.txt`.

Из корня audit: `PYTHONDONTWRITEBYTECODE=1 python next_persisted_growth/probe_persisted_growth.py`; затем `PYTHONDONTWRITEBYTECODE=1 python next_persisted_growth/validate_evidence.py`. Пишется только audit namespace. Не считать эти команды native pytest.
