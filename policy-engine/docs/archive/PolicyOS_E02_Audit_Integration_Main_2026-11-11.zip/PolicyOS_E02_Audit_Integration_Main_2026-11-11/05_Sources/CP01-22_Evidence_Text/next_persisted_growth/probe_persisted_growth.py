"""Read-only product-source audit. Real source bodies, real local JSON/write-once I/O.
Not native package imports, DuckDB persistence, source admission or scientific validation.
"""
from __future__ import annotations
import ast, hashlib, json, sys, types, platform, subprocess, time, resource
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=OUT.parent/'source'
SRC=ROOT/'policy-engine/src/polisyos'
predecessor=OUT.parent/'next_domain_composition/probe_domain_composition.py'
prelude=predecessor.read_text().split('# Use exact seed specs')[0]
prelude=prelude.replace("OUT=Path(__file__).resolve().parent\nROOT=OUT.parent/'source'",f"OUT=Path({str(OUT)!r})\nROOT=Path({str(ROOT)!r})")
base={'__file__':str(predecessor),'__name__':'audit_persisted_prelude'}
exec(compile(prelude,str(predecessor),'exec'),base)
load,namespace,e,r,g=(base[k] for k in ['load','namespace','e','r','g'])
EVIDENCE=base['EVIDENCE']
def public(ns): return {k:v for k,v in ns.items() if not k.startswith('_')}
def select(rel,predicate):
    tree=ast.parse((SRC/rel).read_text())
    names=[]
    for n in tree.body:
        if not predicate(n): continue
        if isinstance(n,(ast.FunctionDef,ast.ClassDef,ast.AsyncFunctionDef)):names.append(n.name)
        elif isinstance(n,ast.Assign):names.extend(t.id for t in n.targets if isinstance(t,ast.Name))
        elif isinstance(n,ast.AnnAssign) and isinstance(n.target,ast.Name):names.append(n.target.id)
        elif isinstance(n,ast.TypeAlias):names.append(n.name.id)
    return set(names)
cap=namespace('audit_persisted_neutral');load('core/contracts/capability_resolution.py',cap)
idx=namespace('audit_persisted_index');idx.update(public(cap));idx.update(public(e));idx.update({k:v for k,v in vars(__import__('typing')).items() if not k.startswith('__')})
idx.update({k:v for k,v in vars(__import__('pydantic')).items() if not k.startswith('_')})
idx.update({'datetime':__import__('datetime').datetime,'date':__import__('datetime').date,'UTC':__import__('datetime').UTC})
rel='runtime/quality/capability_index.py'
load(rel,idx,select(rel,lambda n:n.lineno<514 or (isinstance(n,ast.FunctionDef) and n.name in {'_required_text','_optional_text','_text_tuple','_government_data_involved'})))
for v in tuple(idx.values()):
    if isinstance(v,type) and issubclass(v,idx['BaseModel']) and v is not idx['BaseModel']:v.model_rebuild(_types_namespace=idx)
ind=namespace('audit_persisted_independence');load('runtime/quality/evidence_independence.py',ind)
auth=namespace('audit_persisted_authority');auth.update(public(idx));auth.update(public(ind));auth['hashlib']=hashlib
rel='runtime/quality/capability_authority.py'
load(rel,auth,select(rel,lambda n:isinstance(n,(ast.Assign,ast.AnnAssign)) or (isinstance(n,ast.ClassDef) and n.name in {'CapabilityAuthorityError','CapabilityAuthorityFactor','CapabilityBindingResult'}) or (isinstance(n,ast.FunctionDef) and n.lineno>=761)))
res=namespace('audit_persisted_resolver');res.update(public(idx));res.update(public(cap));res['core_contracts']=types.SimpleNamespace(**public(cap));res['_AuthorityCapabilityBindingResult']=auth['CapabilityBindingResult'];res['compose_capability_authority']=auth['compose_capability_authority'];res.update({'json':json,'hashlib':hashlib,'Path':Path,'CapabilityBindingResult':auth['CapabilityBindingResult']})
rel='runtime/quality/capability_resolver.py'
load(rel,res,select(rel,lambda n:isinstance(n,(ast.Assign,ast.AnnAssign)) or (isinstance(n,ast.ClassDef) and n.name in {'_CandidateEvaluation','RequirementToCapabilityResolver'}) or (isinstance(n,ast.FunctionDef) and n.lineno>=759)))
dm=namespace('audit_persisted_data_models');dm.update(public(cap));load('data_requirement/_impl/models.py',dm)
d=namespace('audit_persisted_data_compiler');d.update(public(dm));d.update(public(e));d.update(public(g));d.update(public(r));d.update(public(cap));d['contracts']=types.SimpleNamespace(**{**public(e),**public(cap)});load('data_requirement/compiler.py',d)
atomic=namespace('audit_persisted_atomic');load('core/artifacts/_atomic_write.py',atomic)
facade=namespace('audit_persisted_facade');facade['_AtomicFileWriter']=atomic['AtomicFileWriter'];load('core/artifacts/__init__.py',facade,{'write_bytes_once'})
# The only import bridge supplies the actual source facade backed by actual source AtomicFileWriter.
bridge=types.ModuleType('polisyos.core.artifacts');bridge.write_bytes_once=facade['write_bytes_once'];sys.modules['polisyos.core.artifacts']=bridge

if len(sys.argv)>1 and sys.argv[1]=='--reader':
    root=Path(sys.argv[2]); reportpath=Path(sys.argv[3]); query=json.loads(Path(sys.argv[4]).read_text())
    resolver=res['RequirementToCapabilityResolver'].governed_fixture(root)
    report=d['parse_data_requirement_compilation_report'](reportpath.read_bytes())
    print(json.dumps({'binding':resolver.resolve(query).model_dump(mode='json'),'discovery':resolver.discover_sources(query).model_dump(mode='json'),'report':report.model_dump(mode='json'),'audit_surface':d['data_requirement_compilation_audit_surface'](report),'raw_sha256':hashlib.sha256(reportpath.read_bytes()).hexdigest(),'source_hashes':{x['path']:x['sha256'] for x in EVIDENCE}},sort_keys=True));sys.exit(0)

started=time.perf_counter()
inputs=OUT/'inputs';inputs.mkdir(exist_ok=True)
registryroot=inputs/'registry'
registrypath=registryroot/res['GOVERNED_CAPABILITY_ROWS_PATH'];registrypath.parent.mkdir(parents=True,exist_ok=True)
CONST='aquatic_thermal_exposure';FAMILY='aquatic_temperature_observations';CAP='capability:audit:aquatic-thermal-exposure'
row={
 'capability_id':CAP,'construct':CONST,'modality':['fabric_data'],'evidence_mode':'observed',
 'concept_spine_refs':['audit:concept:aquatic-thermal-exposure'],
 'scope':{'geography':'audit_watershed','entity_scope':'river_reach','population':'coldwater_fish_habitat','jurisdiction':'audit_watershed','schema_regime':'audit_aquatic_v1','time_start':'2026-01-01','time_end':'2026-12-31'},
 'identification_mode':'point_identified','trust_tier':'authoritative_high_coverage',
 'quality_score':{'composite':0.95,'breakdown':{'construct_validity':0.95}},
 'source_assets':[{'ref':'audit:synthetic-temperature-observations','source_layer':'audit','asset_type':'json','role':'declared_measurement','row_count':400}],
 'authority_envelope':{'research':'admissible','governed_pilot':'admissible','production':'admissible','authoritative_for':['claim_evidence'],'authority_basis':['audit synthetic owner assertions, not independently admitted']},
 'rights_envelope':{'access_class':'public','claim_evidence_use_allowed':True},
 'freshness_envelope':{'freshness_class':'fresh','last_updated':'2026-11-10','observed_through':'2026-12-31','source_release_ref':'audit:aquatic:v1'},
 'lineage_refs':['audit:synthetic-observations:v1'],'metadata':{'sample_size':400},
 'limitations':['Synthetic fixture: no real measurement or scientific validity established.']}
family={'scenario_family':FAMILY,'construct':CONST,'producer_ref':'audit:synthetic-family-owner'}
registry={'capability_index_ref':'audit:capability-release:v1','capabilities':[row],'failure_modes':[],'conflicts':[],'acquisition_strategies':[],'scenario_family_construct_rows':[family]}
registrypath.write_text(json.dumps(registry,indent=2)+'\n')
resolver=res['RequirementToCapabilityResolver'].governed_fixture(registryroot)
query={'requirement_id':'audit:thermal-requirement','construct':CONST,'entity_scope':'river_reach','population_filter':{'type':'coldwater_fish_habitat'},'geography':'audit_watershed','time_window':{'start':'2026-03-01','end':'2026-06-30'},'authority_level':'governed_pilot','claim_use':'claim_evidence_closeout','required_schema_regime':'audit_aquatic_v1','min_sample_size':100}
(inputs/'query.json').write_text(json.dumps(query,indent=2)+'\n')
def evaluate(name,q=None,change=None):
    q=query if q is None else q
    candidate=json.loads(json.dumps(row))
    if change:change(candidate)
    port=resolver if change is None else res['RequirementToCapabilityResolver'](capabilities=[res['_capability_payload_from_json'](candidate)],capability_index_ref=registry['capability_index_ref'])
    binding=port.resolve(q);discovery=port.discover_sources(q)
    return {'binding':binding.model_dump(mode='json'),'discovery':discovery.model_dump(mode='json')}
controls={'positive':evaluate('positive')}
for name,patch in {
'unknown_construct':{'construct':'aquatic_salinity_exposure'},'wrong_geography':{'geography':'other_watershed'},'wrong_entity':{'entity_scope':'forest_plot'},'wrong_population':{'population_filter':{'type':'forest_birds'}},
'outside_time':{'time_window':{'start':'2027-01-01','end':'2027-12-31'}},'partial_time_overlap':{'time_window':{'start':'2026-06-01','end':'2027-12-31'}},'inverted_time':{'time_window':{'start':'2026-08-01','end':'2026-07-01'}},'malformed_time':{'time_window':{'start':'2026-06-XX','end':'2026-07-XX'}},
'unsupported_population_predicate':{'population_filter':{'water_temperature_c_lt':12}},'different_supported_predicate_value':{'population_filter':{'type':'coldwater_fish_habitat','water_temperature_c_lt':30}},
'wrong_schema':{'required_schema_regime':'other_schema'},'sample_below_floor':{'min_sample_size':500}}.items():controls[name]=evaluate(name,{**query,**patch})
changes={
 'candidate_only':lambda c:c.update(evidence_mode='candidate_unverified',trust_tier='candidate_unverified'),
 'rights_blocked':lambda c:c['rights_envelope'].update(claim_evidence_use_allowed=False),
 'production_blocked':lambda c:c['authority_envelope'].update(governed_pilot='blocked_unverified'),
 'population_unknown':lambda c:c['scope'].update(population=None),
 'time_unknown':lambda c:c['scope'].update(time_start=None,time_end=None),
 'jurisdiction_mismatch':lambda c:c['scope'].update(jurisdiction='other_jurisdiction'),
 'sample_unknown':lambda c:c['metadata'].pop('sample_size'),
 'source_assets_missing':lambda c:c.update(source_assets=[]),
 'lifecycle_withdrawn':lambda c:c.update(capability_lifecycle={'state':'withdrawn','rule_version_ref':'audit:lifecycle'})}
for name,change in changes.items():controls[name]=evaluate(name,change=change)
assert controls['positive']['binding']['status']=='selected_exact'
assert controls['positive']['discovery']['state']=='candidates_returned'
assert all(controls[x]['binding']['status'].startswith('blocked_') for x in ['unknown_construct','wrong_geography','wrong_entity','wrong_population','outside_time','wrong_schema','sample_below_floor','candidate_only','rights_blocked','production_blocked'])
assert controls['partial_time_overlap']['binding']['status']=='selected_exact'
assert controls['partial_time_overlap']['discovery']['state']=='no_match'
# Compile a real claim requirement through the source-backed resolver, with explicit named scope.
fs=[{'facet_id':'audit:'+k,'facet_type':k,'value':v,'concept_ref':'audit:concept','authority_profile':'audit:profile'} for k,v in [('population_predicate','coldwater_fish_habitat'),('geography_predicate','audit_watershed'),('time_predicate','2026')]]
claim={'claim_id':'audit:aquatic-claim','claim_type':'causal','claim_family':'causal','claim_use':'claim_evidence_closeout','text':'Thermal exposure in aquatic habitat, synthetic audit claim only.','facet_refs':[x['facet_id'] for x in fs],'obligation_refs':['audit:obligation'],'concept_spine_refs':['audit:concept:aquatic-thermal-exposure'],'authority_profile_refs':['audit:profile'],'source_attribution':['audit:source'],'metadata':{'required_constructs':[CONST]}}
profile=d['_scenario_scope_profile']({'scope_profile':{'profile_id':'audit:aquatic-profile','population':'coldwater_fish_habitat','jurisdiction':'audit_watershed','entity_scope':'river_reach','time_role':'observation_time','granularity':'daily','time_start':'2026-03-01','time_end':'2026-06-30','required_constructs':[CONST]}})
compiler=d['DataRequirementCompiler'](capability_resolver=resolver,require_capability_index=True,scenario_family_construct_rows=[family])
report=compiler.compile_for_claim_ledger(run_id='audit:aquatic:run',claim_ledger={'claims':[claim]},facet_snapshots=fs,scope_profile=profile)
reports=OUT/'persisted_results'
path=d['write_data_requirement_compilation_report'](report,reports)
again=d['write_data_requirement_compilation_report'](path.read_bytes(),reports)
assert again==path
fresh=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--reader',str(registryroot),str(path),str(inputs/'query.json')],capture_output=True,text=True,check=False)
(OUT/'fresh_reader.stderr.txt').write_text(fresh.stderr)
assert fresh.returncode==0, fresh.stderr
fresh_payload=json.loads(fresh.stdout);(OUT/'fresh_reader.json').write_text(json.dumps(fresh_payload,indent=2)+'\n')
assert fresh_payload['report']==report.model_dump(mode='json')
assert fresh_payload['binding']==controls['positive']['binding']
# Fresh process, typed report and data audit projection preserve the new family/construct.
assert fresh_payload['audit_surface']['summary']['required_data_families']==[FAMILY]
# Persist after changing interval; same logical run/requirement IDs need not be content addresses.
profile2=d['_scenario_scope_profile']({'scope_profile':{'profile_id':'audit:aquatic-profile','population':'coldwater_fish_habitat','jurisdiction':'audit_watershed','entity_scope':'river_reach','time_role':'observation_time','granularity':'daily','time_start':'2026-06-01','time_end':'2027-12-31','required_constructs':[CONST]}})
report2=compiler.compile_for_claim_ledger(run_id='audit:aquatic:run',claim_ledger={'claims':[claim]},facet_snapshots=fs,scope_profile=profile2)
path2=d['write_data_requirement_compilation_report'](report2,reports)
assert path2!=path
roundtrip=d['parse_data_requirement_compilation_report'](path2.read_bytes())
assert roundtrip.model_dump(mode='json')==report2.model_dump(mode='json')
# Same fresh reader also preserves the selected/no-match contradiction after persistence.
fresh_negative=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--reader',str(registryroot),str(path2),str(inputs/'query.json')],capture_output=True,text=True,check=False)
(OUT/'fresh_negative_reader.stderr.txt').write_text(fresh_negative.stderr)
assert fresh_negative.returncode==0,fresh_negative.stderr
fresh_negative_payload=json.loads(fresh_negative.stdout)
(OUT/'fresh_negative_reader.json').write_text(json.dumps(fresh_negative_payload,indent=2)+'\n')
neg_resolution=fresh_negative_payload['report']['capability_requirement_resolutions'][0]
assert neg_resolution['binding']['status']=='selected_exact'
assert neg_resolution['candidate_discovery']['state']=='no_match'
# New domain vocabulary stays unresolved, while an explicitly declared construct is preserved.
domain=d['_problem_domain_for_scenario']({'domain':'aquatic_ecosystem_thermal_policy'}).metadata()
assert domain['status']=='unresolved' and 'domain_semantic_support' in domain['may_not_use_for']
no_alias=d['DataRequirementCompiler'](capability_resolver=resolver,require_capability_index=True,scenario_family_construct_rows=[]).compile_for_claim_ledger(run_id='audit:no-alias',claim_ledger={'claims':[claim]},facet_snapshots=fs,scope_profile=profile)
missing_resolver=d['DataRequirementCompiler'](scenario_family_construct_rows=[family]).compile_for_claim_ledger(run_id='audit:no-resolver',claim_ledger={'claims':[claim]},facet_snapshots=fs,scope_profile=profile)
try:
    d['DataRequirementCompiler'](require_capability_index=True,scenario_family_construct_rows=[family]).compile_for_claim_ledger(run_id='audit:required-resolver',claim_ledger={'claims':[claim]},facet_snapshots=fs,scope_profile=profile)
    raise AssertionError('missing required resolver accepted')
except FileNotFoundError as exc:required_resolver_refusal=str(exc)
negative_report=d['DataRequirementCompiler'](capability_resolver=res['RequirementToCapabilityResolver'](capabilities=[],capability_index_ref='audit:empty-registry'),scenario_family_construct_rows=[family]).compile_for_claim_ledger(run_id='audit:absent-resource',claim_ledger={'claims':[claim]},facet_snapshots=fs,scope_profile=profile)
negative_path=d['write_data_requirement_compilation_report'](negative_report,reports)
assert d['parse_data_requirement_compilation_report'](negative_path.read_bytes()).capability_requirement_resolutions[0].binding.status=='blocked_construct_not_observed'
compilation_controls={'domain_declaration':domain,'no_family_alias':no_alias.model_dump(mode='json'),'missing_optional_resolver':missing_resolver.model_dump(mode='json'),'missing_required_resolver':required_resolver_refusal,'absent_resource_report':negative_report.model_dump(mode='json'),'absent_resource_path':str(negative_path.relative_to(OUT))}
# Canonical Fabric consumer projection runs with the real DataNeed DTO, never a fetch.
adapter=namespace('audit_persisted_catalog_adapter');adapter.update(public(dm));adapter.update(public(e))
controlpath=SRC/'core/contracts/control.py'
controltext=controlpath.read_text();segment='class DataNeed('+controltext.split('class DataNeed(',1)[1].split('\nclass MetricCandidate(',1)[0]
exec(compile('from __future__ import annotations\n'+segment,str(controlpath),'exec'),adapter)
EVIDENCE.append({'path':str(controlpath.relative_to(ROOT)),'sha256':hashlib.sha256(controlpath.read_bytes()).hexdigest(),'definitions':[['DataNeed',1216,1229]],'omitted_imports':['Exact isolated DataNeed class; unrelated Python 3.14 syntax excluded; actual Pydantic dependencies supplied.']})
load('fabric/catalog/data_requirement_adapter.py',adapter)
projections={}
for name,rpt in [('positive',report),('partial_time',report2),('absent_resource',negative_report)]:
    spec=rpt.specs[0].model_dump(mode='json')
    spec['capability_requirement_resolutions']=[v.model_dump(mode='json') for v in rpt.capability_requirement_resolutions]
    needs,receipt=adapter['project_data_requirement_to_catalog_needs'](compiled_requirement_spec=spec)
    projections[name]={'needs':[v.model_dump(mode='json') for v in needs],'receipt':receipt}
    assert receipt['authority_status']=='not_established'
# Content identity checks in discovery and result persistence.
candidate=controls['positive']['discovery']['candidates'][0]
tampered=json.loads(json.dumps(candidate));tampered['descriptor']['scope']['population']='other'
try:cap['CapabilitySourceCandidate'].model_validate(tampered);raise AssertionError('tamper accepted')
except ValueError as exc:tamper=str(exc)
json_payload=path.read_bytes().decode();duplicate=json_payload.replace('"run_id": "audit:aquatic:run"','"run_id": "audit:aquatic:run", "run_id": "changed"')
try:d['parse_data_requirement_compilation_report'](duplicate);raise AssertionError('duplicate accepted')
except ValueError as exc:dup=str(exc)
try:d['parse_data_requirement_compilation_report']({'schema_version':'unsupported'});raise AssertionError('schema accepted')
except ValueError as exc:unsupported=str(exc)
conflict_dir=OUT/'conflict_control';conflict_dir.mkdir(exist_ok=True)
(conflict_dir/path.name).write_bytes(b'wrong bytes\n')
try:d['write_data_requirement_compilation_report'](report,conflict_dir);raise AssertionError('conflict accepted')
except ValueError as exc:conflict=str(exc)
# Same persisted registry release locator and capability ID can identify changed row bytes.
changed_registry=json.loads(json.dumps(registry));changed_registry['capabilities'][0]['quality_score']['composite']=0.91
registrypath.write_text(json.dumps(changed_registry,indent=2)+'\n')
new_resolver=res['RequirementToCapabilityResolver'].governed_fixture(registryroot)
new_binding=new_resolver.resolve(query);new_discovery=new_resolver.discover_sources(query)
identity={'same_release_ref_after_changed_row':resolver.capability_index_ref==new_resolver.capability_index_ref,'same_binding_id_after_changed_row':controls['positive']['binding']['binding_id']==new_binding.binding_id,'same_binding_id_different_query':controls['positive']['binding']['binding_id']==controls['partial_time_overlap']['binding']['binding_id'],'new_candidate_digest_changes':candidate['content_digest']!=new_discovery.candidates[0].content_digest,'old_reader_remains_snapshot':resolver.discover_sources(query).candidates[0].content_digest==candidate['content_digest'],'fresh_reader_observes_changed_row':new_discovery.candidates[0].descriptor['quality_score']['composite']==0.91,'distinct_report_paths_for_changed_interval':path.name!=path2.name,'report1':str(path.relative_to(OUT)),'report2':str(path2.relative_to(OUT)),'report1_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'report2_sha256':hashlib.sha256(path2.read_bytes()).hexdigest(),'same_requirement_id_different_interval':report.specs[0].requirement_id==report2.specs[0].requirement_id,'changed_input_content_hash':report.input_content_hash!=report2.input_content_hash,'fresh_negative_report_preserves_contradiction':True,'descriptor_tamper_refusal':tamper,'duplicate_json_key_refusal':dup,'unsupported_report_schema_refusal':unsupported,'existing_wrong_bytes_refusal':conflict}
registrypath.write_text(json.dumps(registry,indent=2)+'\n')
results={'method':'source_body_execution_with_actual_filesystem_persistence_and_fresh_process_reader','python':sys.version,'source_pin':'f1541ed155f278689be48a8c7ac56c3e200210f7','controls':controls,'catalog_projections':projections,'compilation_controls':compilation_controls,'compiled_report':report.model_dump(mode='json'),'partial_time_report':report2.model_dump(mode='json'),'identity':identity,'fresh_process_exit':fresh.returncode,'limits':['No native package imports','No DuckDB or full index compiler','Synthetic owner assertions are not independent evidence','No source admission, actual measurement, model execution, scientific validation, publication, HTTP, deployment or production effects'],'profile':{'elapsed_seconds':time.perf_counter()-started,'max_rss_kb':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}}
(OUT/'results.json').write_text(json.dumps(results,indent=2,default=str)+'\n')
(OUT/'source_evidence.json').write_text(json.dumps(EVIDENCE,indent=2)+'\n')
summary={name:{'binding_status':v['binding']['status'],'satisfies_claim_evidence':v['binding']['satisfies_claim_evidence'],'discovery':v['discovery']['state'],'candidate_limitations':[x['limitations'] for x in v['discovery']['candidates']],'rejections':[x['rejection_reason'] for x in v['discovery']['rejected_candidates']]} for name,v in controls.items()}
(OUT/'summary.json').write_text(json.dumps({'controls':summary,'identity':identity,'fresh_process_exit':fresh.returncode,'profile':results['profile']},indent=2)+'\n')
print(json.dumps({'controls':summary,'identity':identity,'fresh_process_exit':fresh.returncode,'profile':results['profile']},indent=2))
