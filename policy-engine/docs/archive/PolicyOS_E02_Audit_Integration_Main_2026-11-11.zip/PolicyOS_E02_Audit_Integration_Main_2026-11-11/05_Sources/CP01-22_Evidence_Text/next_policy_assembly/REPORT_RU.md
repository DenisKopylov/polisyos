# PolicyOS: сборка исполнимых механизмов и ограничений

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`, read-only snapshot, 11 ноября 2026 UTC. **Итог: PARTIAL.** Два подтверждённых разрыва на выбранной границе. Это не native qualification, не scientific validation, не admission нового causal effect model и не доказательство publication/authority bypass. Исходники не изменялись.

## Результат

1. **PA-01, P2: versioned registry identity теряется при выборе runtime mechanism.** Два новых synthetic механизма проходят настоящий public Trinity compiler, linker, conflict checker и CAS persistence. Добавление другого, согласованного eager method с новым FQN, но тем же runtime type, меняет kernel старого сохранённого plan. Для неизменённого payload delta становится −20 вместо −2. Повторная компиляция возвращает тот же LoweredIR и ExecPlan ref, включая выбранный manifest profile. Новый процесс воспроизводит различие. При версиях 2.0.0 и 10.0.0 descriptor выбирает 2.0.0, тогда как explicit MethodRegistry LATEST выбирает 10.0.0. Причина: lexical FQN order + last-write-wins по mechanism_type, без объявленного collision/version policy и без замороженной runtime identity в lowering.
2. **PA-02, P2: typed constraint value не проходит compiler→runtime codec.** MoneyValue(10 USD) проходит настоящий unit-aware linker и public compile. В сохранённом LoweredConstraint expected становится dict; реальный evaluator отвергает его как non-numeric. Decimal10 работает и различает pass/violation; EUR при USD registry отвергается linker. Существующие Money/Rate/Count/Duration objects напрямую поддерживаются evaluator, но все четыре теряют исполнимую форму после actual lowering. Для Rate/Count/Duration здесь показан lowerer/evaluator seam, не full per-unit compiler profile.
3. **Сохранённые guards существенны.** Неизвестный executable type, неверные bounds, несовместимый binding kind и неподдерживаемая compile fidelity отвергаются. Согласованная сумма двух механизмов сохраняет обоих участников, перестановка не меняет выбранную semantics. Реальный conflict checker блокирует multiple writers под ERROR rule. Missing slot, nonfinite float state и hard constraint violation дают отказ. Это не «система вообще не проверяет состав».

`PA-*` — локальные IDs. MA-01/02 про persisted method cache и mismatched lazy supplier здесь не повторяются: cache не используется, классы регистрируются eager, FQN/signature каждого согласованы, override=False. DC-01 про lexical grammar loss и DP-01 про welfare aggregation тоже не воспроизводятся. Глобальная дедупликация остаётся за cumulative synthesis.

## 1. Что именно исполнялось

`probe_assembly.py` использует настоящие:

- MethodRegistry и встроенный bootstrap family `mechanism`;
- MechanismTypeRegistry, ConstraintRegistry, SlotRegistry, MergeRuleRegistry и typed TrinityBundle;
- build_registry_bundle + FileSystemCAS;
- public `foundry.compile.api.compile` → `compile_trinity` → `link_trinity` → `lower_trinity` → `build_program_graph` → CompileTimeConflictChecker → persistence;
- runtime `get_mechanism_descriptor` и `create_mechanism_from_spec` на прочитанных сохранённых payloads.

Kernel classes в `fixture_mechanisms.py` синтетические, маленькие и не выдают scientific status: credit emits −amount, service emits −2×amount, credit-v2 emits −10×amount. Их `emit_patches` вызывается непосредственно instrument после настоящего constructor. Они не воспроизводят экономику кредита или оказания услуг; названия обозначают лишь различимые ресурсы. Никаких внешних действий/транзакций нет.

**Полный `execute_program_graph`, JAX kernels, mask execution, merge_state, state snapshot producer, public execution-source admission, N5, causal coupling, calibration, uncertainty, legal authority, alternative ranking и publication здесь UNRUN.** Поэтому выполненная цепочка до kernel constructor отделена от source-traced actual executor callsite. Нельзя называть этот результат whole scientific end-to-end.

В отличие от прежнего pure-helper free-growth probe, здесь два новых ресурса действительно входят в typed registry bundle и в public compiler без product edits. Но это caller-provided finite resources: installed extension discovery, source/build provenance и governed admission не квалифицированы. «Ресурс описан и может быть сконструирован» не равно «модель эффектов подтверждена».

## 2. Реальные связи и owners

Все пути ниже относительно `policy-engine/src/polisyos/`.

- `foundry/methods/selection/registry.py:494–555` сохраняет точный FQN eager класса; `:921–933` выдаёт sorted-by-FQN inventory. Explicit default resolution требует version, а LATEST использует semver owner.
- `foundry/methods/catalog/mechanism/runtime_registry.py:254–294` проходит этот inventory и создаёт descriptors. Полезно, что executable view действительно опирается на canonical MethodRegistry, а не на ещё один вручную поддерживаемый перечень. Но dict key — только runtime_mechanism_type.
- `foundry/compile/_lowering.py:194–236,249–296` проверяет type support и fidelity, сохраняет mechanism_id, params, schedule, selector, slots и selected_fidelity. Method FQN, version, kernel path/build identity в этих artifacts не попадают.
- `foundry/compile/_graph.py:38–88` создаёт `op/apply_mechanism` с mechanism_type, params_ref и fidelity. Method-specific path `:169–205` отдельно проверяет version/backend/slots. Это разные planes, а не доказательство наличия pin у mechanisms.
- `foundry/execute/_internal/graph/__init__.py:3911–3960` на исполнении читает тот payload и вызывает `create_mechanism_from_spec` с type и selected_fidelity. Constructor заново берёт глобальный descriptor. `:472–502` обрабатывает identity только nodes kind=method и пропускает op/apply_mechanism. Изученный механизм не получает эти более строгие method guards автоматически.
- `foundry/compile/_lowering.py:388–435` соединяет ProblemFrame constraints с registry scope и превращает typed value через model_dump. `core/contracts/foundry.py:1282–1302` объявляет expected как Any.
- Runtime `graph:3129–3149` передаёт именно сохранённые lowered constraints в `foundry/validation/constraints_engine.py:49–91`. Его `_coerce_number:215–240` понимает typed wrappers, не их JSON dicts.

`caller_census.json` перечисляет все 2 895 `.py` под src/polisyos и literal case-insensitive hits. Это не dynamic call graph. `source_excerpts.json` и `selected_callsites.json` связывают прочитанные определения и действительные call expressions; external/reflection consumers остаются невыясненными.

## 3. PA-01: growth подменяет смысл старой сборки

**Уверенность: высокая для registry/compile/CAS/constructor seam; дальнейшее operational влияние не измерено.**

Baseline содержит audit.assembly.credit@1.0.0 и audit.assembly.service@1.0.0. Оба объявляют разные runtime types, typed amount bounds, одинаково явные slot reads/writes и одну supported fidelity `fluid`. Компилятор успешен с default strict flags. Не используем mismatched factory, stale metadata cache, class mutation или незаявленный parameter. Финальные deciding inputs и outputs имеют return_selected_profile=True; равны не только content IDs, но и selected plan refs. Предварительный default-ref control оставлен отдельно и не заменяет этот повтор.

Далее добавляется CreditV2 с FQN audit.assembly.credit@2.0.0, тем же runtime type и другим importable kernel. Exact duplicate FQN по-прежнему отвергается; новая version допустима canonical registry.

Наблюдение:

- Старый payload amount=2, selected_fidelity=fluid остаётся тем же CAS объектом.
- До добавления v2 constructor выбирает CreditKernel; patch delta=−2.
- После добавления v2 constructor выбирает CreditV2Kernel; delta=−20.
- Service amount=3 остаётся delta=−6 и сохраняет descriptor/payload. Рост unrelated resource не маскирует изменение.
- Recompile после v2 даёт равные lowered objects и тот же exec_plan_ref: изменение executable выбора не становится новым input identity плана.
- Fresh processes baseline/v2 прочитывают одни и те же policy/registry/lowered/graph/plan refs и воспроизводят разные kernels/deltas (`reader_baseline.json`, `reader_v2.json`).

Это defect сохранения выбранной executable semantics, не утверждение, что intent всегда требует «самую новую» модель. Напротив, отсутствие policy и silent replacement — проблема. При 1/2/10 словарная projection выбирает 2.0.0; обычный `reg.get(base, policy=LATEST)` выбирает 10.0.0. Добавленный z.audit.credit@0.0.1 перекрывает оба из-за namespace order. Registration order не является причиной: list_all уже сортирует FQN.

### Fidelity discriminator

При fresh reader v2_hard новый descriptor поддерживает только hard, а старый payload по-прежнему fluid. `create_mechanism_from_spec` создаёт kernel с fluid; result содержит runtime_fidelity_supported=false. Отдельный `resolve_runtime_fidelity` для hard-only descriptor корректно отказывает на fluid. То есть guard существует в compile path, но constructor его не повторяет при динамической повторной resolution.

Это дополнительный discriminator той же потери выбранного binding, не третья самостоятельная SYS-семья. Реальные built-ins сейчас могут поддерживать все fidelity; показана API extension boundary с корректно типизированной декларацией, не incident в deployed built-in kernel.

### Минимальное направление ремонта

Расширить существующий descriptor/binding owner, а не вводить новую ModelRegistry:

1. Сделать type→method selection явным: unique mapping либо versioned selection policy с typed ambiguity/refusal. Не выбирать namespace или version лексикографией.
2. Сохранять выбранный admitted binding в lowering/plan: method FQN/version, kernel target и scoped source/build identity, supported fidelity и relevant runtime declaration. URI/class name сами не доказывают source identity.
3. Исполнитель должен consume/reconcile этот binding, а не заново выбирать глобальное значение type. Constructor обязан проверить переданный fidelity против выбранного descriptor.
4. Отделить execution identity от empirical validity, causal assumptions, calibration и authority. Hash класса wrapper не покрывает импортированный kernel, helper dependencies и runtime profile автоматически.

Acceptance: два разных types, две versions одного type, 2/10, namespace collision, explicit alias policy, precompiled reopen, supported-fidelity drift, kernel source drift, unchanged unrelated resource, exact mismatch refusal до patches, native full graph execute and current source admission. Это reuse существующих registry/version/compiler owners, не замена их новым framework.

## 4. PA-02: успешная компиляция не означает executable constraint codec

**Уверенность: высокая. Приоритет P2 для надёжности typed execution; fail-closed runtime error, не false approval.**

MoneyValue(amount=10,currency=USD) является допустимым documented ConstraintSpec.value. Unit-aware linker правильно проверяет USD registry. Public compile возвращает ok=true и trinity_coverage_audit:ok, без warning о неисполняемом threshold. LoweredIR сохраняет:

    expected = {amount: "10", currency: "USD", nominal_year: null}

`LoweredConstraint.expected: Any` не восстанавливает MoneyValue при read. `_coerce_number` возвращает None для dict, и check_constraints выдаёт ValueError «has non-numeric value». То же после нового процесса (`constraint_reader.json`).

Противоположные controls:

- Decimal10 с actual20 → ok=true, hard_fail=false.
- Decimal10 с actual5 → ok=false, hard_fail=true.
- MoneyValue EUR с USD registry → compile ok=false, link_failed, прежде lowering.
- Money/Rate/Count/Duration напрямую в LoweredConstraint → evaluator действительно сравнивает числовое значение.
- Те же четыре wrapper values после настоящего `_lower_constraints` → non-numeric refusal.
- Missing slot и float Infinity → explicit errors.

USD full compiler→CAS→reader→evaluator выполнен. Для остальных wrappers direct lowerer/evaluator controls используют scalar state как codec witness и не утверждают корректность их currency/unit/time/population scope. В частности, Duration day→step не обязан быть тождественным преобразованием. Не следует «чинить» проблему безусловным вытаскиванием любого поля value.

Направление: versioned lowered-threshold codec у существующих compiler/IR owners. Сохранить исходный тип, units/base/time identity и явное числовое представление после необходимого admissible conversion, либо восстановить typed union на runtime boundary. Статический unit mismatch guard сохранить. Добавить настоящие compile/persist/reopen/evaluate controls для каждого допустимого wrapper, matching/mismatching units, percent/ratio, nominal year и calendar duration. `_json_value` и `_coerce_number` не должны независимо определять несовместимые halves одного execution contract.

## 5. Positive guards и scope композиции

`compile_controls.json` содержит реальные варианты тех же typed inputs:

- Joint, reordered joint и обе single alternatives компилируются; joint сохраняет два independent mechanism entries. Это реальное plural assembly, не один flattened grammar facet.
- Amount ниже bound, kind/binding mismatch, unsupported fidelity и IR-declared type без kernel не компилируются.
- Изменённый ERROR merge registry получает отказ linker; отдельно actual CompileTimeConflictChecker на неизменённом joint graph различает SUM и ERROR и выдаёт multiple_writers blocker. Отказ whole compiler в этом control нельзя приписывать более позднему checker.
- Same FQN duplicate отвергается MethodRegistry. Same runtime type под другим FQN этим guard не охвачен.
- Неизвестный parameter вызывает warning и compile ok=true, а не ошибку. Это явный current contract linker (`_trinity_params:214–228`), поэтому первоначальное audit expectation «обязательно compile fail» исправлено и не записано как product finding. Runtime parameter validator строже. Этот warning не зачтён как verified executable parameter.

Механизм direct effects, slot algebra и aggregate bound не заменяют effect model P(Y|do(X)). Built-in `RUNTIME_MECHANISM_METHOD_AUTHORITY_SCOPE` прямо не считает runtime method достаточным для causal effect estimation, uncertainty, transportability, distributional evidence и objective tradeoffs. Ранее исследованные joint-simulation/authority guards не переиграны и не опровергнуты этим срезом.

Policy alternatives здесь — два отдельных typed PolicySpec и их joint composition. Поиск лучшего варианта, cross-policy welfare ordering, scarce resource allocation, interaction/SCM validation и jurisdiction-level override semantics не выполнялись. Functional modularity двух synthetic resources подтверждена ограниченно; универсальность предметных моделей не выведена из их наличия.

## 6. Среда, тесты и доказательства

Native import Python3.12.14 останавливается на Python3.14 multi-except syntax в artifacts/store.py. Supported Python3.14 и locked dependencies здесь не запускались. Начальные full compatibility imports последовательно раскрыли missing chex/JAX; ошибки сохранены.

Final loader использует прежний точный compatibility transformer: только multi-except syntax и TypeVar default, get_protocol_members из typing_extensions. Namespace-only skip eager validation facade не исполняет unrelated world closure. CompileTimeConflictChecker получает точный исходный MergeConflictKind enum, извлечённый AST из JAX-heavy merge_engine; его predicates не подменяются. Constraint engine исполняется целиком с настоящим get_state_path; три NumPy/Decimal helper definitions извлечены неизменёнными из canonical JAX-heavy numeric module. JAX merge engine и numerical graph executor не синтезируются и остаются недоступны.

Все loader rewrites/extractions, hashes и selected module sets сохранены. Full compiler, linker, conflict checker, registry, CAS, constructor и constraint predicates не monkeypatch-ятся. Synthetic collaborators ограничены audit kernels, deterministic inputs и SimpleNamespace scalar state для evaluator.

Начальные audit ошибки сохранены: неправильный DType import, неверное предположение о state_path government.balance вместо government_balance, неподдержанный unversioned EXACT lookup, неверное имя merge_rule_id в fixture и ожидание error вместо documented warning. Исправлялся только instrument; финальные typed controls повторены. Первые неудачные прогоны не записаны как product failures.

`test_census.json` содержит шесть конкретных test files и их definitions. В них есть реальные runtime kernels, original family checks, bounds и constraint aggregation checks. Закрытие добавления второго FQN с тем же runtime type после compile и typed-wrapper compile→fresh evaluator roundtrip существующими tests здесь не установлено; утверждение об отсутствии таких tests во всём репозитории не делается. **Pytest bodies не запускались.** Это не repo coverage percentage и не green suite. Исполнены отдельные audit scripts с deciding assertions и mixed-outcome controls.

`SOURCE_VALIDATION.json` проверяет bytes просмотренных/исполненных source против pinned Git objects. `VALIDATION.json` проверяет artifact/result consistency, а не product readiness. Ни deployed behavior, ни внешнее изменение, ни publication authority не заявляются.
