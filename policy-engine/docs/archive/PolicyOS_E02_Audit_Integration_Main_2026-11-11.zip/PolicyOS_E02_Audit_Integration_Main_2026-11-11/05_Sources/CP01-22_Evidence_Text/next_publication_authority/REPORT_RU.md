# Evidence → claims → publication/approval: реальные owners и границы

База `f1541ed155f278689be48a8c7ac56c3e200210f7`, read-only, продолжение checkpoint08. Итог **PARTIAL**. Подтверждён один локальный fail-closed writer/reader defect PA-01; **authority bypass, успешная PUBLIC-публикация и scientific validity не установлены**. Новых SYS-семейств не посчитано.

## Результат

- **PA-01:** настоящий GovernedPublicRecordOwner возвращает первый private draft, который его собственный строгий reader не может прочитать повторно. CAS integrity проходит, но manifest не содержит canon profile. Повтор prepare, fresh-process reopen и синтетически назначенный issue отказывают с `canon_profile_absent` → `publication_preparation_invalid`. Публичные indexes остаются пустыми.
- Более точный control показывает, что **одного добавления canonical profile недостаточно**: Core `put_json` записывает байт-в-байт тот же draft с объявленным profile, после чего decoder восстанавливает вложенный tagged timestamp публичного документа как Python datetime. `_PrivateDraft.public_document: dict[str, JsonValue]` его отклоняет. Прямой raw JSON DTO read проходит. Это несовместимость codec/profile/model round-trip, не разрешение ослабить verifier.
- **Default production Claim owner явно unappointed.** Candidate labels `supported`, `publishable` и summary `publication_ready=true` не выдают current root. Отдельный production-root publication guard также закрыт по умолчанию. В этом pin нет production setter для его test-only marker.
- Действительный current claim snapshot со статусами draft/internal_only/review_required/blocked не становится public candidate. Точные mandate digest/scope/ledger/key/time несоответствия отвергаются самим binding predicate. Полный signature/closure путь после PA-01 не выполнен.

## 1. Исполненная цепочка и границы инструмента

`probe_publication_authority.py` исполняет полные исходные bodies FileSystemCAS, `_RepositoryClaimLedgerOwner`, head/root/retained receipt readers, ClaimLedger DTOs и GovernedPublicRecordOwner. Root initialization сохраняет ledger, fixture packet, preparation, denominator, root/verifier receipt и current pointer через реальные owners. Snapshot читается через `resolve_current_for_packet`, historical source повторно проверяется. Первый draft persist и последующий reader не заменены.

**Явно синтетические зависимости:** repository test helpers `_FixturePolicyResolver`, `_FixtureRootIssuer`, `_FixtureIssuanceVerifier`; их начальная policy/provenance не являются настоящим institutional authority. Packet имеет тестовую schema, не full DecisionPacketBuilder. Ed25519 keys и mandate используются исключительно внутри удаляемого temp CAS. Mandate signing реально вызван, но public record signing и mandate signature verification в issue не достигаются из-за PA-01. Никаких live providers, deployment, внешних публикаций, credentials или product writes.

Python 3.14 отсутствует. Native import под 3.12.14 останавливается на новом multi-except syntax `core/artifacts/store.py:2155`. Использован audit-only in-memory loader предыдущего среза: скобки multi-except и TypeVar из typing_extensions; все изменения перечислены в results.json. Eager верхние package initializers заменены namespace packages. Fixture modules загружены без pytest import/decorators; fixture import DecisionReadiness направлен на тот же canonical enum, который source re-export импортирует. Bodies fixture helpers и product owners не исправлялись. Это **не native import, не pytest lane, не locked-profile pass**. Ошибки первых двух import attempts: отсутствующие pytest и chex, не product regressions.

Полный probe выполнен дважды, assertions проходят. Draft handles и event times случайны, поэтому byte-identical outputs между запусками не ожидаются. Решающие outcomes совпадают. Повторный prepare отдельно исполнен новым Python процессом на той же временной CAS/head/index паре; новый процесс снова получает настоящий PacketBoundClaimLedgerSnapshot и тот же отказ. Retained `evidence/first_prepare.*` содержит actual draft/ref/manifest, без секретов; полный источник результата воспроизводится скриптом.

## 2. PA-01: private draft нельзя прочитать собственным reader

**Уверенность:** высокая в локальном механизме; native qualification и operational frequency не установлены. **Последствие:** availability/replay correctness на настроенном publication path, не ложная положительная authority.

Source:
- `scientist/governance/continuous/governed_public_record.py:466–474`: `_put` вызывает put_bytes для `_bytes(value)` и передаёт kind/media/schema, но не canonical declaration.
- `:476–493`: `_read` вызывает `validate_core_model_json_artifact` до schema/canonical-bytes checks.
- `:1145–1173`: первый prepare записывает private draft и кеширует его ref; последующий prepare обязательно проходит `_read`.
- `core/artifacts/canonical_profile.py:2520–2545`: строгий typed reader требует объявленный profile. Отсутствие profile законно отвергается; целостность blob его не заменяет.

Результат полного owner:
1. Первый prepare успешен, private draft имеет один actual current claim, `store.verify(ref).ok=true`, manifest canon=null, issued population пустая.
2. Второй prepare возвращает `publication_preparation_invalid`, cause=`canon_profile_absent`.
3. Fresh process: real current snapshot восстановлен, тот же prepare refusal. Это не stale Python object и не потеря claim head.
4. Fixture routine сначала готовит точные bytes для внешнего mandate, подписывает synthetic mandate, затем issue снова вызывает prepare и получает тот же отказ до public record. Публичный locator не выдан.

**Counterfactual, не remediation:** `probe_profile_control.py` переносит actual draft в другой temp CAS через существующий Core put_json с `CanonSpec(forbid_floats=False)`. Bytes совпадают с исходным draft, profile теперь declared. `_read` проходит profile gate, но Core decoder превращает `public_document.ledger.events[0].occurred_at={"_type":"datetime",...}` в datetime, запрещённый JsonValue. Raw `_PrivateDraft.model_validate_json` тех же bytes принимает модель. Это дополнительный discriminator несовместимости raw JSON projection и восстанавливающего codec. В source `:361–372` явно требуется сохранить raw JSON codec исходного ledger. Нельзя считать замену put_bytes на put_json достаточным исправлением.

Нужен единый существующий writer/reader contract, сохраняющий raw public-document semantics, объявляющий верный codec и exact manifest identity. Acceptance: prepare→persist→repeat→fresh-process read; first/second issue; mandate exact-byte binding; nested tagged values; schema/profile drift и corruption negatives; никакого удаления strict profile gate. Такой же `_put` используется для других publication subjects, но отдельные их runtime failures не заявлены как измеренные.

## 3. От evidence labels до настоящего Claim owner

`claims/projections.py:483–535` присваивает supported при непустом evidence_refs и contested при counterevidence. Затем readiness нормализует publishability. Это projection уже предоставленных Scientist outputs, не evidence resolver. Полный `project_decision_packet_claims` в свежем probe:
- без ref: factual/forecast claims unsupported;
- с заведомо неразрешимым ArtifactRef: оба supported/publishable;
- в обоих случаях настоящий `build_default_claim_ledger_owner` сохраняет candidate, но `prepare_initial_ledger` возвращает `claim_root_issuance_not_established`.

Поэтому маркеры supported/publishable не доказывают source admission, scientific support или permission. Это boundary observation, **не новый подтверждённый exploit**. Реальный packet bridge `decision_packet/enrichment.py:189–274` сохраняет candidate summary вместе с `claim_ledger_status=not_established` и кодом ограничения, когда default owner либо feature gate не даёт root. Builder `:590–630` дополнительно отказывает, если prepared root не финализируется.

В отдельном current-owner fixture causal claim с отсутствующим evidence blob всё же допускается к private prepare. Это важно для честной интерпретации: fixture root issuer/verifier принимает synthetic policy, не проверяющую научное содержание evidence. Реальный owner доказывает целостность/custody принятого ledger, а профиль PUBLIC прямо запрещает трактовку как policy performance. **Нельзя выдавать этот опыт за обход настоящей institutional admission**, которую fixture заменяет. Для следующей квалификации нужна настоящая назначенная policy/verifier с claim-bound source resolution и отдельным removal control, а не добавление фальшивой authority в тест.

`publication_ready` summary означает отсутствие blocked/review-required; draft/internal-only тоже могут дать true. Выполнены реальные root initialization и export для пяти статусов. Все snapshots current; PUBLIC visibility true только для publishable. Для остальных prepare отказывает на historical public eligibility (`historical_source_admission_not_established`). Таким образом, summary не является финальным public gate, и переименование boolean не заменяет проверки owner.

## 4. Authority/approval и provenance: кто действительно решает

- `head_index.py:4532–4535` строит UnappointedClaimLedgerOwner. Runtime container `:620–646`, control service `:7497–7503`, workspace/workflow/backtesting используют этот default; explicit injected override допускается и не исследован как deployment. Default даёт candidate persistence, но ни current root, ни historical authority. Полный textual census сохранён, это не dynamic call graph.
- GovernedPublicRecordOwner `_prepare` требует exact PacketBoundClaimLedgerSnapshot, совпадающие decision/packet, historical replay и wholly public/current/not-pending view (`:1107–1190`). `_validate_draft` заново читает root/verifier/ledger и пересчитывает полный injective transform (`:1208–1233`). Это не реконструкция смысла потерянного выше по цепочке.
- Production root custody gate (`:449,658–664`) default false и требует owned read capability; main probe достигает его на свежем cache и получает `public_read_root_custody_not_established`. Наличие publisher key не снимает этот guard.
- На отдельных свежих fixtures следующий guard даёт `publication_signer_not_configured`; configured signer без mandate даёт `publication_mandate_not_configured`. Никаких indexes.
- Mandate должен связывать exact document digest, packet, ledger, owner scope, issuer/key, version/profile и interval (`:1235–1259`). Прямой bounded вызов этого неизменённого predicate принимает исходный typed input и отвергает пять подмен. Это **не полная signature admission**, потому что нормальный issue блокируется раньше на PA-01.
- Source `_signed:553–595` дополнительно проверяет exact detached signature/manifest bytes, отдельную trusted issuer-purpose pair и revoked key; `_issue:1335–1340` перечитывает current source после mandate verification. Эти участки прослежены, но успешный полный вызов в данном срезе **UNRUN**.
- HTTP route `public_decisions.py:42–54,156–244`: PLATFORM_ADMIN action binding, actual owned run/tenant check, запрет body, packet declared-profile read, server-selected owner, public readback до возврата locator. Authenticated HTTP не запускался. Native missing toolchain и ранее выявленные auth-projection вопросы не закрыты source trace.
- Report-only signature отделена от governed publication. DTO `PublicDecisionVerificationDimensions` оставляет все семь dimensions not_established. Governed branch может подтвердить только issuance и projection faithfulness; current_authority/public evidence obtainability/history/durability остаются not_established (`governed_public_record_contracts.py:220–231`). Это не universal proof of policy truth.
- ProductionApproval имеет отдельного HumanDecision owner: exact signed scorecard/basis/record, tenant/run/time/reservation joins (`human_decisions.py:1994–2178`). V2 operational read/issuance owner-format guard `:2285–2360` явно fail-closed с `DS9-APPROVAL-OWNER-BINDING-REQUIRES-V3` на распознанных formats. Этот seam проверен **только source trace**, не полный approval flow. Утверждение «publishable автоматически approved» не поддержано.

## 5. Последствия EC-01/EC-02 и STATE-02 без преувеличения

EC-01/02 сохраняются: scope/method semantic binding теряется до downstream evidence consumption. Faithful projection может честно сохранить ошибочно скомпилированный ledger и не способна восстановить удалённый исходный смысл. Hash/custody proof отвечает «это именно принятые bytes», не «bounds и population правильно поняты». Нужен native multi-component producer→resolver/method→claim-source admission witness с реальными owners, а не только строгий финальный DTO.

Но этот срез **не показал** перевод ошибочного requirement в опубликованную или operationally approved claim. Default unappointed owner, eligibility, institutional mandate, root custody и текущий PA-01 стоят отдельными барьерами. Их нельзя убрать в harness и затем назвать synthetic success production bypass. PA-01 сам является дефектом доступности, а не надёжной заменой рассчитанного authority guard.

STATE-02 originating outbox `published` обозначает принятую внутреннюю notification delivery. Это не запись GovernedPublicRecord и не доказательство PUBLIC policy signature. Generic HTE fixtures предыдущего среза не имели полного appointed claim/publication source. Потеря invalidation остаётся подтверждённой для тех packet targets; дальнейшая claim/public-signature reachability открыта.

## 6. Повторение и статус

Из этой папки:
- `PYTHONDONTWRITEBYTECODE=1 python probe_publication_authority.py`
- `PYTHONDONTWRITEBYTECODE=1 python probe_claim_projection.py`
- `PYTHONDONTWRITEBYTECODE=1 python probe_profile_control.py`
- `python build_source_evidence.py && python validate_evidence.py`

Probe assertions pass означает точное воспроизведение отказа и controls, **не green product publication acceptance**. Основной raw draft/profile evidence сохранён, source hashes сверены с pin. Реальные scientific source acquisition, native Python 3.14, estimator conformance, actual institutional appointment, full cryptographic issue/reopen и public/approval HTTP остаются UNRUN/PARTIAL. Product remediation не выполнялась.
