# PolicyOS: selected variable semantics и value transfer

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Source read-only. Продолжение после checkpoint08; не повторяет legacy time-overlap binding из PG-01, стоимость Fabric search из NC, cache из FG-02 или profile collapse из GR-01.

**Итог: PARTIAL.** Найден новый незамкнутый semantic join. Исполнены настоящие тела producer, replay, predicate, units и одного lineage reader; сделаны JSON persist/reopen в новом процессе. Это не native Catalog/Foundry, не фактический CAS/DuckDB admission и не publication bypass.

## Главный результат

**RD-01, medium: `recomputed_axes` подтверждает совпадение двух representation declarations, не всегда связывая их с mechanically available occurrence facts.**

- Настоящий `derive_canonical_observations` применил `sum` к 2 и 6. Настоящий `replay_scoped_measurement_occurrence` повторно получил `canonical_value="8.0"`, `aggregation_method="sum"` из тех же raw bytes.
- В обоих selected representations записано `aggregation="mean"`. Профиль явно требует `AGGREGATION`, но `evaluate_scoped_correspondence_basis` возвращает `candidate`, `semantic_correspondence="recomputed"` и включает aggregation в recomputed axes. Независимое арифметическое значение среднего этих двух чисел равно 4.
- Аналогичный cross-join: обе representations объявляют `population:other`, тогда как replayed occurrence и model-port scope имеют `population:test`. При required `POPULATION_REF` статус также candidate/recomputed.
- Полностью новые process/DTO reads после записи JSON сохраняют оба результата. Это устраняет объяснение исключительно stale in-memory объекта, но не заменяет настоящий CAS test.
- Контроли существенны: несовпадающие mean/sum между source и target representations отвергаются. Source/port population, geography, jurisdiction, interval, time-role и fiscal-year mismatch отвергаются. Version, selected profile, definition revision, evidence ref и value tamper тоже отвергаются.

Механизм: `core/contracts/variable_binding.py:987–1049` сверяет ряд source/occurrence/ref/scope/unit полей; `1151–1193` сравнивает оси только source representation ↔ target representation. Для aggregation и population нет соответствующего representation ↔ occurrence/source/port reconciliation. Это не полное отсутствие semantics guards, а пропущенное ребро между двумя уже строгими контрактами.

**Важное ограничение интерпретации:** source-row aggregation и measurement aggregation могут в общем случае описывать разные уровни обработки. Исправление не должно слепо требовать равенства любых строк `identity`/`mean`/`sum`. Нужна явно типизированная, проверяемая композиция или разрешённое соответствие. В данном различающем примере такой закон не предъявлен, а predicate всё равно сообщает recomputed aggregation. Как минимум, нельзя выдавать проверку двух деклараций за независимое установление их соответствия фактической строке.

Доказательства: `results.json#/aggregation_join`, `#/population_equal_declaration`, `fresh_reader.stdout.json`. Confidence высокий для поведения выбранного механизма, operational reach ограничен.

## Активный producer → consumer путь

1. `variable_alignment.score_variable_pair` формирует поисковые scores. Одинаковое имя сохраняет lexical score при несовместимых units, однако это ranking candidate, не перевод значения и не разрешение исполнять. Нельзя объявлять такой search score scientific equivalence.
2. `overlay.build_metric_field_binding:3971–4032` использует реальный confidence calibrator, строит content-bound field binding; DTO повторно проверяет binding hash. В probe использована новая audit-owned synthetic registration, не запись production registry.
3. `overlay.derive_canonical_observations:4213–4381` реально читает raw JSON, применяет выбранный operator и агрегирование, формирует row ID, provenance и version. `_validate_observations:4393–4437` реально исполняется.
4. `core/contracts/variable_binding.py:700–907` независимо перечитывает/нормализует raw bytes, проверяет source watermark и selected observation ID, воспроизводит value и scope. Это не переданный произвольный canonical value.
5. Catalog `measurement_binding.assess_measurement_to_model_candidate:80–245` source-traced: reread activated projection → exact receipt/passport/source/model refs → occurrence persistence/readback → shared correspondence predicate → persisted basis. Полный Catalog owner не запускался.
6. Runtime `data_state_substrate:970–1038,1120–1226` source-traced: получает Catalog candidate, перечитывает occurrence/basis и raw, проверяет lineage, повторно вызывает тот же predicate. Наличие второго вызова того же predicate само по себе не закрывает RD-01.
7. Foundry `bindings:2622–2657,2700–2815` source-traced: проверяет source-owner chain, replay и тот же predicate; затем payload value должен равняться occurrence value, а encoding выбирается моделью. Полный physical invocation не запускался.

`caller_census.json` содержит полный literal census для пяти выбранных имён по всем `.py` в `src/polisyos`. Declarations/imports/exports явно отделены от утверждения, что каждая строка является вызовом. Полная карта всех variable registries из этого не следует.

## Units, time, version и provenance: что прошло и что отказало

**Реальные fixed-unit producer и replay:**

- 20 km → 20000 m, multiplier 1000.
- 20 percent → 0.2 ratio, multiplier 0.01.
- m → s, affine degC → K, USD → EUR без rate, population-unit conversion и произвольный dimensionless transform отвергнуты.
- Исполнялись actual Unit parser, определения units, content-pinned definition-basis проверка и `_resolve_fixed_unit_transform`. Подмена success-функцией не использовалась.

Это положительный результат для конкретного finite operator, не доказательство, что любые units или значения одного смыслового класса взаимозаменяемы. Percent→ratio в synthetic fixture проверяет conversion; экономическая/эмпирическая интерпретация показателя не установлена.

**Исполняемые отрицательные контроли:** fiscal/unknown scope keys/fractional year/competing survey year/противоречащий declared unit отвергаются replay. Field value, dataset version, definition revision, selected profile и evidence ref остаются load-bearing.

**Lineage reader:** настоящее тело Foundry `_load_scoped_correspondence` принимает complete exact inputs и отвергает removal, reorder и profile tamper. Store и CAS artifact validator здесь явные synthetic collaborators. Это доказывает решающий guard, но не настоящую CAS проверку bytes/ownership/signature.

**RD-O3, честная граница free-grow:** Foundry `_verify_scoped_measurement:2766–2767` явно отказывает при `source.unit_transform != "identity"` с `foundry_input_bindings_fixed_unit_verifier_not_established`. Поэтому успешные Catalog/replay km→m и percent→ratio не означают executable admission такого преобразования. Эта Foundry ветка source-traced, не полная executed pipeline.

## Другие observations, не дополнительные authority incidents

**RD-O1: scale depends on selected profile.** При required `SCALE_TO_UNIT` source scale 1 vs target 100 отвергается. Если удалить эту ось из profile, mismatch даёт candidate без отдельной scale limitation. Если обе декларации имеют 100, они равны между собой и проходят даже при occurrence, уже выраженном в canonical unit. В полном `src/polisyos/*.py` употребления scale_to_unit ограничены самим contract owner. Это подтверждённая configured граница и вопрос load-bearing numeric contract; не объявляем любую optional ось самостоятельным дефектом.

**RD-O2: raw → canonical теряет точность до model encoding.** Истинные producer и independent replay оба делают `float(raw_value)`:

- integer 9007199254740992 сохраняется;
- integer 9007199254740993 становится 9007199254740992.0, ошибка −1;
- numeric string 1e−1000 становится 0.0;
- occurrence `raw_values` уже содержит округлённую строку, а correspondence остаётся candidate.

Это не утверждение, что binary64 запрещён или что нужна неограниченная Decimal precision. Это доказанная общая precision boundary двух механизмов: replay обнаруживает tamper, но повторяет ту же quantization. Selected model fixture имеет max_absolute_error=0, однако source-to-model tolerance на полном physical пути не проверен. Нужно отдельно выбрать допустимый raw→canonical loss contract и тестировать его вместе с downstream encoding; один raw replay не доказывает отсутствие численного смещения.

## Стоимость выбранного raw replay

Отдельный `probe_replay_cost.py` измеряет **число строк одного selected raw JSON**, а не число catalog indicators. Это новое звено после поиска, не повтор benchmark 200k MetricSearcher.

Для N=100, 1000, 10000 и Q=1,5 каждый вызов выбранной occurrence читает/нормализует все N значений. Итог Q×N raw row reads; пять запросов к 10000-row объекту дают 50000. Выбор first vs last меняет число вычисляемых row-ID hashes, но не полный raw scan. Сохранены counters и три untraced времени для каждой конфигурации.

Foundry вызывает verification отдельно для каждого manifest measurement (`bindings:2622–2625`, raw replay `2768–2773`); реальный multimeasurement invocation, actual CAS byte reads/cache и production p95 не измерены. Нельзя экстраполировать эти N на «100000 показателей = 100000 таких blobs».

Контроль с invalid unrelated row показывает, почему нельзя просто прекратить проверку после нахождения нужной строки: нынешний invariant отвергает некорректные исходные данные до selection. Возможное направление: переиспользовать owner-qualified parsed/grouped state, привязанный к exact raw content, binding/operator/unit-law/aggregation/version, сохранив full validation и provenance. Оптимизация не реализована.

## Проверки, границы и следующие acceptance

Команды:

- `python next_registry_dataflow/probe_registry_dataflow.py`: exit 0.
- `python next_registry_dataflow/replay_persisted_cases.py`: exit 0; fresh subprocess reader exit 0.
- `python next_registry_dataflow/probe_replay_cost.py`: отдельный raw log/exitcode.
- `python next_registry_dataflow/write_evidence.py`: exit 0, 19 used/excerpted source/test files совпадают с исходным SHA-256 census f1541ed.
- Native import `polisyos.core.contracts.variable_binding`: failed. Python 3.12.14 не парсит Python 3.14 exception syntax в `core/artifacts/store.py:2155`. Pydantic 2.13.4 вне repo bound; dependencies не устанавливались.

Две ранние ошибки измерителя сохранены: обрезанный AST segment; затем integer proxy_penalty=0 вместо float 0.0 изменял hash before/after DTO normalization. Первый segment исправлен, fixture передаёт объявленный float; source не менялся. Этот вторичный int/float edge не превращён в дополнительный finding.

Не выполнены full native suites, actual DuckDB/current authority, real CAS persistence/reopen, полный Foundry execution, scientific validity, signatures/publication, native UI/API integration или новое 100000+ capacity qualification. JSON sidecars не выдаются за product persistence.

Следующий ограниченный acceptance: настоящий admitted source + selected CAS representation/profile + Runtime/Foundry consumer для sum/mean и population cross-join; правильные единицы и полный scope должны остаться положительными. Добавить source-to-model loss budget и fixed-unit consumer refusal/control. Повторный поиск старых scale/cache проблем не заменит эти joins.
