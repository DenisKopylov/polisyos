# PolicyOS: release integrity и граница deployment/observability

**База:** `f1541ed155f278689be48a8c7ac56c3e200210f7`, неизменённый snapshot. Проверено 2026-11-11 UTC. Scope: действующий GitHub release path, от tag/dispatch и fragment snapshot до packaging, canary, signing, attestation и GitHub publication. Это продолжение аудита, не повтор `next_auth`, `next_native` или `next_test_confidence`.

## Главный результат

Release readiness **не подтверждена**. Найдены три отдельные проблемы:

1. **REL-01, высокая:** fresh checkout не получает обязательный versioned fragment snapshot. Точный штатный validator для текущего `v0.1.0` завершается exit 1 до сборки. Producer существует, но пишет ignored output, а workflow не создаёт и не переносит его.
2. **REL-02, высокая, латентная:** manual dispatch принимает release tag отдельно от source ref, но ни prepare, ни build checkout не привязаны к этому tag. Совпадение строк package version не доказывает совпадения source commit. В изолированном Git fixture tag A и dispatch HEAD B различались, а настоящие resolver и version validator вернули exit 0. Текущий REL-01 блокирует достижение поздних стадий в fresh checkout; REL-02 нельзя объявлять уже случившимся неправильным release.
3. **REL-03, средняя:** vulnerability gate принимает отсутствующий/неверно типизированный `matches` за отсутствие уязвимостей. Настоящий CLI возвращает exit 0 для `{}`, errors-only JSON и `{"matches": {}}`. Корректный High finding и expired exception блокируются.

Положительные controls сохранены. В workflow есть реальная цепочка зависимостей до публикации, least-privilege job permissions, SHA-pinned Actions, SBOM/scanner, keyless signatures и attestation jobs. Это не равнозначно доказанному successful run, корректной доставке signed subjects или production promotion.

**Observability:** источник имеет реальные instrument → recording-rule → SLO bindings и передачу exporter degradation в `/ready`. Но release canary проверяет три health response, а не production configuration, scrape, alert firing или SLO window. Свежий exact-body replay подтверждает отказ на `degraded`; `disabled`, `unknown`, `initializing` и отсутствие health evidence сами по себе не мешают canary success predicate. Это ограничение доказательной силы dev smoke, не доказанный обход production authorization.

## 1. Что действительно исполнено

`probe_release_integrity.py` выполнил **38 именованных observations**. В это число входят технические операции построения изолированного Git fixture, а не 38 product tests. Исходники не исправлялись.

- Настоящие standalone `check_release_version.py`, `stage_release_snapshot.py`, `evaluate_vuln_report.py`, без изменения их тел и без подмены parser/evaluation.
- Настоящий shell `Resolve release tag` с заданным event context.
- Настоящий shell `Enforce release immutability` с безвредным `gh` stand-in, возвращающим только exit code. GitHub не вызывался.
- Exact AST bodies `ready`, его трёх helpers и canary `_probe`. Сняты только route decorators; container/metrics/HTTP responses переданы in-memory. Это не import всей app и не live HTTP test.
- Чтение полного job/checkout/run denominator одного `.github/workflows/release.yml`, сохранённого в `release_execution_map.json`.
- 47 named source paths совпали SHA-256 с baseline manifest. Tracked Git status пуст. Hash readset не означает semantic acceptance каждого файла целиком.

Текущий interpreter Python 3.12.14. Эти standalone stdlib CLIs исполнимы здесь, но поддерживаемый product baseline остаётся Python 3.14. Не запускались uv sync/build, pip install, pytest suite, OPA, scanners, signing, publication, cloud/Helm operations или production API. Native blockers уже описаны в `next_native` и не пересчитаны как новые defects.

## 2. REL-01: ignored release input не доставляется в CI

**Priority:** высокая, release blocker. **Confidence:** высокая. Owner: release workflow / release-fragment lifecycle.

### Source → consequence

- `.github/workflows/release.yml:30–62`: prepare делает checkout, resolve tag, remote immutability lookup и напрямую запускает version validator.
- `tools/ops_runners/release/check_release_version.py:18–30,53–59`: default root `policy-engine/_build/release-fragments`; версия должна содержать хотя бы один `.toml`.
- `tools/ops_runners/release/stage_release_snapshot.py:18,42–63`: existing producer пишет versioned snapshot в этот generated root.
- `policy-engine/.gitignore:10`: `_build/` ignored. `git ls-files policy-engine/_build/release-fragments` вернул пустое множество.
- `docs/how-to/release-policy.md`, Release Prep / Release Path Lifecycle: staging до signed tag требуется, но snapshot прямо назван generated/archive output, ignored Git.
- Полный release workflow не содержит staging, скачивания snapshot или передачи его bytes между jobs. `fragments_dir` в job output есть, но строка absolute path не переносит файлы на другой runner.

Fresh checkout при совпадающих Python/frontend versions `0.1.0`:

`python check_release_version.py --tag v0.1.0` → exit 1, `Release fragment snapshot is missing for 0.1.0 ...`.

Controls: существующий producer staging из одной явно synthetic curated TOML fixture во внешний output directory → exit 0; validator с этим root → exit 0. Неверная версия и пустой version directory → exit 1. Значит речь не о неспособности запустить инструмент и не об ослабленном validator, а об отсутствующей передаче input.

**Направление исправления, не выполнено:** использовать существующий producer и детерминированно выбирать source fragments на pinned ref, затем доставлять один content-bound snapshot всем потребителям. Либо явно продвигать reviewed immutable input в разрешённый committed source path. Не помещать новые release sources под `_build` и не обходить missing-input gate.

**Residual acceptance:** isolated fresh checkout на supported runner → producer → upload/download той же версии → prepare/notes/compatibility consumers. Контроль удаления snapshot должен блокировать; разные snapshot digests между jobs должны блокировать.

## 3. REL-02: input tag и build source не связаны

**Priority:** высокая для release integrity; латентна при текущем REL-01. **Confidence:** высокая для wiring и validator boundary, GitHub run не исполнялся.

- `release.yml:7–12,33–48`: dispatch input `tag` становится output tag, независимо от ref, выбранного при dispatch.
- `release.yml:30–31,75–76` и остальные checkout steps: нет `with.ref`, нет resolved commit output.
- `check_release_version.py:35–69`: сравниваются только строковые версии Python/frontend и наличие fragments. Нет Git tag resolution, comparison с HEAD или verification signed tag.
- `release.yml:359–416`: подпись и provenance прикрепляются к фактически собранным bytes. Они не доказывают равенство requested tag SHA и source SHA без такой проверки.
- `release.yml:457–468`: GitHub release создаётся по `RELEASE_TAG`. Нет explicit `--verify-tag` / target SHA reconciliation. Мы не полагаемся на поведение GitHub при несуществующем tag: finding уже достаточен для существующего tag с другим commit.

**Reproduction:** локальный synthetic Git repo содержит два реальных commits. `v0.1.0` указывает на A; selected dispatch HEAD B содержит изменённый `payload.txt`. Resolver при `GITHUB_EVENT_NAME=workflow_dispatch`, `INPUT_TAG=v0.1.0`, `GITHUB_SHA=B` возвращает tag. Настоящий checker на pinned `0.1.0` package metadata и staged fixture returns 0. Outputs содержат version/fragments/count, но не commit. Полные SHA в `probe_results.json`, observation `dispatch_source_binding`.

Это не утверждение, что `payload.txt` является product bug. Он только создаёт независимый witness «ref отличается при неизменной версии». Product source здесь не модифицирован. Для обычного tag-push event выбранный ref естественно совпадает с trigger tag; finding относится именно к dispatch ветви и отсутствующей общей reconciliation.

**Последствие:** после исправления REL-01 release может быть подписан и опубликован под верным названием версии, но собран из другого выбранного ref. Честная attestation build source сама по себе не исправляет consumer expectation о source tag.

**Направление исправления:** resolve/verify existing release tag один раз, bind immutable commit output; checkout именно его во всех source-consuming jobs; сравнить его с provenance subject/run source и metadata. Проверять signed-tag policy в реальном release path, а не считать checked-in branch ruleset доказательством применения. Negative control: тот же version, другой source SHA.

## 4. REL-03: отсутствие scan evidence превращается в PASS

**Priority:** средняя. **Confidence:** высокая, настоящий CLI. Owner: vulnerability policy evaluator.

`evaluate_vuln_report.py:41–57` использует `payload.get("matches", [])` без проверки типа, schema/descriptor/source. `:73–75` классифицирует неизвестную severity как rank 0. `main` возвращает success при пустом blockers list. Реальный release caller находится в `release.yml:227–236`.

| Controlled input | Exit | Значение |
|---|---:|---|
| High vulnerability, без exception | 1 | Правильный blocker |
| High + expired exception | 1 | Правильный blocker |
| High + valid future exception | 0 | Предусмотренное разрешение |
| `matches: []` | 0 | Пустой результат |
| `{}` | 0 | Нет evidence, но PASS |
| `errors` без `matches` | 0 | Нет scan results, но PASS |
| `matches: {}` | 0 | Неверный тип, но PASS |
| match без vulnerability / unrecognized severity | 0 | Неизвестные данные не блокируют |
| `matches: null` / invalid JSON | 1 | Ошибка parsing, не PASS |

Полный malformed-input shape control важен: finding не означает, что любой scanner failure обходится. В workflow Grype failure как nonzero command блокирует job до evaluator. Мы не наблюдали, что закреплённый Grype сегодня производит errors-only JSON с exit 0. Подтверждено, что evaluator не отличает valid zero findings от отсутствующего evidence и не bind scan source к текущему SBOM.

**Направление исправления:** требовать поддерживаемую report schema, list `matches`, typed mandatory fields, scanner/source identity и связь с текущим SBOM; отдельно выразить `no_findings`, `incomplete` и `invalid_report`. Не лечить только три показанных JSON формы. Unknown severity должна иметь явную policy, а не незаметно наследовать rank «negligible». Повторить controls через реальный release evaluator caller.

## 5. Реальные safeguards и их пределы

### Что уже правильно провязано

- Все внешние `uses` в scoped release workflow pinned полным commit SHA. Top-level token read-only; write scopes выделены signing/attestation/publish jobs.
- Build/notes зависят от operability gate. Canary зависит от build и supply-chain gate. Sign зависит от canary. Publish зависит от prepare, operability, notes, canary, sign, attest и supply-chain; `if: always()` находится у evidence uploads, не у publication.
- SHA256SUMS создаётся рядом с Python distributions и dashboard bundle; `sign-artifacts` подписывает каждый файл release-assets, включая manifest, а signatures/certificates скачиваются publish job.
- Provenance action отдельно принимает release assets и supply-chain evidence как subjects.
- Explicit vulnerability/exception controls действительно различают некоторые плохие inputs, а не всегда возвращают PASS.
- Version/fragment validator fail-closed на missing/empty snapshot и version mismatch.

### Чего эти controls не доказывают

- Нет fresh wheel/sdist bytes, dependency installation manifest, real scanner output, certificate, signature/attestation или downloaded release subject в данном pass. **Artifact cryptographic verification UNRUN**, а не «всё подписано и проверено».
- В scoped workflow нет явного consumer-side `sha256sum -c`, `cosign verify-blob` или attestation verification перед использованием; Actions transfer и подписывающая стадия являются отдельными средствами доверия. Это source observation, не доказательство tampering.
- `tools/quality/ci/install_supply_chain_tools.sh:38–57` получает versioned Syft/Grype/Cosign с официальных GitHub URLs, но не проверяет pinned digest/signature скачанных executables. Downloads здесь не выполнялись. Это дополнительный supply-chain hardening gap, не наблюдение компрометации.
- Immutability preflight: exact shell при `gh view` exit 0 возвращает 1, при 1 или 4 возвращает 0. Поэтому отсутствующий release и auth/transport failure не различаются. Однако последующий `gh release create` и duplicate-release semantics не были обойдены или исполнены; overwrite не доказан.
- `release-production` / `release-canary` environment names объявлены, но реальные required reviewers, secrets, GitHub rulesets и tag protection не проверены. `main.yml` сам обозначает enforcement как `active-when-applied`.
- `ops/release/deployment-topology.toml` и `promotion-gates.toml` честно имеют `status="contract_only"`. Manual SLO/migration reviews не превращаются в deployment evidence от проверки существования paths. Этот GitHub workflow публикует assets; не выполняет rollout шести declared deployment units.

## 6. Configuration parity и observability

### Package / environment

Source version Python/frontend совпадает. Build использует canonical setup Python 3.14 / uv 0.9.21 runtime profile. Wheel canary создаёт отдельный venv и делает `pip install policy-engine[runtime-http] @ file://...` (`release.yml:289–304`): это полезная установленная boundary, но зависимости resolve через pip без lock constraints. Значит locked build environment и installed canary environment не считаются автоматически идентичными.

Следующие `uv run pytest tests/unit/runtime/http` и benchmark smoke (`:313–320`) снова используют checkout environment. Их существование не доказывает, что тот же suite прошёл на установленном wheel. Это release-path qualification limit, не повтор finding о CI selectors из `next_test_confidence`.

`run_release_canary.py:84–85` создаёт временный CAS и app без явного deployment security/config bundle. Scoped workflow не задаёт `POLISYOS_EXECUTION_PROFILE`; resolver default `dev` (`execution_policy.py:172–179`). Неизвестные внешние environment injections не предполагались. Dev smoke не является доказательством production parity. Production authorization controls из `next_auth` заново не оспаривались.

### Instrument → observable surface

Прослежена выбранная runtime API линия:

1. `app.py:624–641` передаёт route/method/status/duration в metrics recorder.
2. `metrics_parts.py:955–980` увеличивает requests, пишет duration, errors для status ≥400; сохраняет env attributes.
3. `_metrics_registry_base.py:1047–1061` создаёт соответствующие counters/histogram.
4. `slo_recording_rules.yml:123–138` строит service 5xx error ratio и p95 latency; zero-traffic условие не подставляет фиктивный denominator. `slo/runtime.yaml` ссылается именно на эти recording rules.
5. Health routes получают exporter health; `/ready` становится degraded при явно degraded exporter. Existing test `test_ready_endpoint_reports_observability_degradation` это проверяет, но native pytest в этом pass не запускался.

Эта линия source-consistent. Мы не делаем вывода «вся observability согласована» по одной линии.

### Свежие oracle controls

Exact-body readiness → canary replay с одинаковыми HTTP health fields:

- exporter `ok`: canary success predicate true;
- exporter `degraded`: `/ready` = degraded, canary predicate false;
- exporter `disabled`, `unknown`, `initializing` или `{}`: `/ready` = ready, canary predicate true.

Источник действительно имеет disabled mode при `POLISYOS_OTEL_ENABLED=false` (`_metrics_registry_base.py:243–253`). Но запуск всей app с этой переменной не выполнялся. Replay показывает только семантику двух существующих consumers. Снятые decorators и in-memory dependencies раскрыты в raw observations.

Canary не делает `/metrics` scrape, не проверяет нарастание series, trace receipt, Prometheus rules/alerts или dashboard query result. `prometheus.yml` указывает development scrape target `host.docker.internal:9464`; это local baseline, не production endpoint. Конкретная production telemetry/alert acceptance остаётся **NOT ESTABLISHED**. Disabled telemetry может быть допустима для dev, поэтому отдельный production security defect из такого smoke здесь не объявляется.

## 7. Следующая bounded квалификация

1. Исправить delivery versioned release input и bind requested tag к immutable source SHA; затем один clean supported-runner replay до unsigned assets без публикации.
2. Закрыть invalid-scan false PASS и выполнить реальные valid/invalid reports через существующий CLI. Не ослаблять High/expired-exception controls.
3. На тех же artifacts выполнить checksum/signature/provenance verification, source tag reconciliation, installed wheel и rebuilt-sdist smoke. Сохранить точные subject digests и resolved dependency manifest.
4. Для отдельного production candidate определить единственный config bundle и deployment unit, выполнить bounded telemetry emission → scrape → rule → alert discriminator. Negative: telemetry unavailable/disabled. Не требовать такого поведения от разрешённого dev mode, но не засчитывать dev smoke как production readiness.
5. Проверить фактическое GitHub environment/ruleset application и release run provenance отдельно, только при разрешённом read access. Ни cloud deployment, ни publication для этих первых checks не нужны.

**Deliverables:** report, machine-readable findings/matrix, full scoped workflow execution map, reproducible probe, raw stdout/stderr/exit, source validation и checksums. Весь глубокий аудит и remediation не объявляются завершёнными.
