# Остаточная custody: историческая epoch acceptance цепь

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`, source read-only. Срез W02, итог **PARTIAL**. Выбран отдельный ранее не пройденный join: внешний подписанный acceptance → CAS evidence → file-backed lineage → deployment-selected exchange → custody service → persisted audit observation. Не повторяет tenant/auth, N5 или public-record issuance.

## Основной результат

**RC-01, P2 correctness/history availability, высокая уверенность в локальном механизме:** после корректного второго acceptance общий verifier продолжает подтверждать первый receipt как `historical_for_exact_query`, но `EpochAnchorCustodyService` отклоняет тот же первый запрос с `anchor_query_or_lineage_mismatch`. Текущий второй запрос подтверждается. Отдельный свежий процесс на тех же CAS/lineage/config воспроизводит оба результата.

Это **ложный отказ при историческом replay**, а не authority bypass, утечка или доказанный отказ публичного reader. В source найден прямой operational consumer `audit_epoch_custody`; runtime container устанавливает provider, но дополнительного вызова его evaluation methods из HTTP/claim issuance в просмотренном полном `src/polisyos/runtime/**/*.py` нет. Поэтому нельзя переносить finding на реальную публикацию, claim revalidation или production incidence.

## 1. Реальная цепь и synthetic границы

Исполнены неизменённые bodies:

1. `AppointedAnchorFixture` из существующего test helper создаёт **синтетический institutional producer** и synthetic native qualification inputs. Это не настоящий назначенный production owner. Fixture использует реальную canonical serialization, Ed25519 signing, CAS и verifier. Её in-memory lineage заменена настоящим `FileAnchorAcceptanceLineageRepository`, без изменения самого source/helper.
2. Два разных ref-only `AnchorAcceptanceRequest` проходят helper producer, который читает реальные CAS bytes, сверяет full-prefix, qualification и predecessor. Подписанные receipts и wrapper DTO сохраняются через существующий Core CAS.
3. Настоящий `build_epoch_deployment` получает exact receipt selectors и test public-key file, role-specific trust и file-lineage root. `composition_scope` выбирает настоящий no-argument production provider. Никаких изменений private `_OWNERS`, `_ISSUED`, marker или product gates.
4. `EpochEvidenceExchange` заново читает appointment/signature/trust bytes, затем exact receipt для request. Service повторно собирает evidence и вызывает настоящий crypto/lineage verifier.
5. Первый current acceptance подтверждён. После второго acceptance тот же первый receipt подтверждён напрямую общим verifier, но отвергнут service. Новый current acceptance подтверждён обоими.
6. `audit_epoch_custody` действительно сохраняет старый request, вызывает production provider, сохраняет его rejected result и перечитывает receipt. `authority_scope=custody_provider_invocation_only`, `request_reference_verification=not_established` сохранены. Этот audit receipt ничего не повышает в authority.

Positive holder/retention в этом срезе **не исполнялся**: holder appointments намеренно отсутствуют, потому что исследуется acceptance/history join. Поэтому aggregate status при правильном acceptance остаётся `limited`, а не `verified`. Это сохранённое разделение двух независимых ролей.

## 2. RC-01: где теряется исторический смысл

- `core/security/anchor_lineage.py:211–287,313–327`: writer под file lock сравнивает exact head, сохраняет immutable entry, transaction, новый head и exact append receipt. Исторические entries остаются в ordered lineage.
- `core/security/chronology_anchor.py:930–979`: verifier находит позицию requested acceptance в полной lineage и вычисляет исторический state из prefix до неё. `:1040–1092` проверяет append receipt против этого исторического state и возвращает `current` либо `historical_for_exact_query`. Старое доказательство не становится разрешением для нового query.
- `runtime/quality/chronology_custody.py:329–385`: rebuilder читает current lineage и строит candidate append с `resulting_head_refs=state_statement.current_record_refs` и `resulting_state_content_hash=state.state_content_hash`. После второго acceptance это уже другое состояние, поэтому ни `appended`, ни `idempotent` reconstruction не совпадает с подписанным первым append-ref/hash.
- `:432–437`: `ValueError` rebuilder превращается в `anchor_query_or_lineage_mismatch` **до вызова** verifier. Исторически корректные bytes до него не доходят.
- `epoch_evidence_exchange.py:373–412`: реальный exchange связывает запрос с bundle, native reconciliation, purpose, predecessor и полным domain. В опыте старый запрос не переименован в новый: exact original request остаётся тем же. Отказ возникает позже, не из-за ошибочного selector.

### Различающие контроли

| Сценарий | Измеренный outcome |
|---|---|
| Первый receipt, lineage из одного entry, production-configured service | acceptance verified/current; aggregate limited |
| Второй корректный receipt после первого | acceptance verified/current |
| Первый receipt после второго, direct exact verifier | verified/historical_for_exact_query |
| Тот же первый receipt/query после второго, production service | rejected/anchor_query_or_lineage_mismatch |
| Первый receipt с query второго | direct verifier rejects anchor_query_or_lineage_mismatch |
| Повреждены только signed statement blob bytes | direct verifier rejects anchor_signature_unverified |
| Свежий процесс, старый и текущий запрос | тот же rejected/verified differential |
| Реальный persisted audit для старого запроса | rejected; exact readback equal |

**Направление, без исправления продукта:** дать service owner-resolved exact historical append evidence либо восстанавливать его из соответствующего immutable lineage prefix с теми же hash/query/predecessor checks. Сохранить различие historical evidence и current authority, не ослаблять verifier и не подменять старый query текущим.

**Acceptance:** два последовательных реальных owner acts, затем оба query через общий verifier и production service; fresh-process reopen; old-query success строго с historical label, wrong/later query и corrupt bytes rejected; current request сохраняет current. Если service намеренно ограничен current-only, нужен явный типизированный current-only контракт и отдельный доступный historical consumer, а не отрицание корректной истории общим mismatch. Native supported-profile воспроизведение ещё требуется.

## 3. Сохранённые authority guards

Измеренные service controls:

- Default no-deployment provider → обе роли `not_established`; это честная граница, не finding.
- Changed reconciliation ref или full scope → acceptance `not_established`.
- Два одинаковых configured receipt selectors → ambiguous selection, `not_established`.
- Revoked signer key в новом current deployment config → appointment/acceptance `not_established`.
- Trusted key с одной holder role вместо acceptance role → acceptance `not_established`.

Source `epoch_evidence_exchange.py:172–231` проверяет exact signed appointment и независимую verification record, pinned trust snapshot и роль. `:233–304` допускает ровно одно matching appointment и повторно сверяет его при выдаче collaborator. `epoch_deployment.py:254–282` строит role-specific strict-identity verifier и применяет revocation. Probe не доказывает автоматическую hot-revocation уже собранного старого deployment: новая конфигурация передавалась новому owner; snapshot semantics старого owner не названы bypass.

## 4. Consumer reach и непокрытые роли

- `runtime/http/container.py:705,765–768`: provider создаётся на assembly и заменяется под выбранным deployment при installation. Source trace, HTTP не запускался.
- `runtime/quality/epoch_custody_audit.py:77–120`: реальный producer/consumer persisted observation полностью исполнен. CLI `main` не запускался отдельно; его exit 0 по контракту означает завершённую запись observation, не положительную custody.
- `core/contracts/chronology.py:2882`: результат явно имеет историческую позицию. Existing `test_chronology_anchor.py:816–852` проверяет old exact query лишь напрямую через verifier. Existing custody tests проверяют current acceptance и stale predecessor, но не тот же historical receipt после продвижения lineage через production-configured service. Эти pytest suites **не запускались**.
- Acceptance/holder appointments не создаются production factory автоматически. Подписанные внешние acts поступают как configured evidence; это integrate boundary. Наш synthetic issuer не доказывает реальную институциональную независимость.
- Writer-independent holder, retention/readback challenges, full-prefix denominator completeness, native epoch policy owner и world/model→claim cascade здесь не закрыты. Peer-review и general identity-key lifecycle также не объявляются покрытыми.

## 5. Среда и точность измерителя

`ENVIRONMENT.json`: выбранный shell Python 3.12.14; project requires `>=3.14,<3.15`; `python3.14` не найден в PATH. Pydantic 2.13.4 **вне** declared `>=2.12.5,<2.13`, cryptography 50.0.0, typing_extensions 4.16.0, pytest отсутствует. Это локальная проверка выбранной среды, не утверждение об отсутствии подходящих профилей на других компьютерах.

Один native import даёт SyntaxError на `core/artifacts/store.py:2155` (Python 3.14 multi-except syntax). В optional groups `test` задаёт pytest/runtime-http, `runtime` не добавляет pytest; base dependencies уже содержат cryptography. Нет оснований устанавливать всю optional `security` группу ради этого bounded test. Установки/обновления не выполнялись.

Compatibility loader исполнил 71 исходный product module; 15 адаптаций перечислены в `results.json`: multi-except parentheses, TypeVar и get_protocol_members из typing_extensions. Eager верхние package initializers заменены namespace packages; Core facade **сохранён настоящим**. Production business bodies не заменялись. Test helper импортирован целиком, без pytest decorators/conftest. Первый compatibility import отказал на отсутствующем typing.get_protocol_members; traceback сохранён; следующий import прошёл с объявленным adapter.

Это **не native import, не locked-profile pass, не pytest run, не release qualification**. Даже exit 0 здесь подтверждает только перечисленные bounded assertions. Внешние сервисы, deploy, публикация, credentials и source writes не выполнялись.

## Повторение

Из workspace root:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 policyos_deep_audit/next_remaining_custody/probe_remaining_custody.py
python3 policyos_deep_audit/next_remaining_custody/validate_evidence.py
```

Probe заново создаёт временные CAS и file lineage, исполняет fresh child, сохраняет deciding outcomes и public synthetic fixture graph. Private keys не сохраняются. Source hashes и artifacts проверяются отдельно. Full source or installed/native pass из этого результата не следует.
