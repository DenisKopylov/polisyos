# Scholar: research requirements → независимость источников → persisted job → Runtime boundary

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`, source read-only. **Итог: PARTIAL.** Новый узкий научно-семантический дефект RC-01 подтверждён через реальные typed contracts, producer, raw CAS verification, persisted job/report/checkpoint и повторное чтение в новом процессе. Не установлены native qualification, научная истинность исследования, source institutional admission или publication/approval bypass. Новых SYS-семейств не добавлено.

## Краткий результат

1. **RC-01: объявленные Scholar collapse rules не управляют подсчётом независимой поддержки.** Настоящий compiler для production causal claim требует две независимые линии и выдаёт шесть правил: underlying study, dataset, authors, institutions, citation network, replication lineage. Две записи одного study корректно дают effective=1 и blocked. При разных study IDs, но одинаковом dataset, author pool, institution, citation network или replication lineage, каждый отдельный контроль даёт effective=2 и report/boundary pass. Диагностический control с `effective_support_per_cluster=0` тоже не изменяет результат; его ограничение описано ниже.
2. **Результат переживает реальное сохранение.** DeepResearchJobManager с явно synthetic service, возвращающим сохранённый fixture bundle, исполняет submit/wait, пишет academic report и checkpoint настоящим CAS, сохраняет status index. Новый процесс заново открывает jobs и CAS: shared dataset остаётся completed/pass/2; same study остаётся completed/blocked/1. Completion означает окончание работы, а не закрытие evidence requirement.
3. **Положительные защиты реальные.** One-source, same-study, stale-within-report-but-outside-requirement, low publication tier и insufficient citation depth блокируются. Raw pages сохраняются через настоящий UrlFetchCache, а exact source/span binding проходит для всех metadata-only perturbations. Scientist verifier отвергает выдуманную цитату и отсутствие CAS. Эти guards нельзя заменять простым status label.
4. **Есть существующая крупная подсистема для переиспользования.** Реальный `evidence.portfolio.effective_independence_graph` исполняет same-study collapse, joint snapshot/preprocessing/identification collapse и отдельный учёт counterevidence. Он не является готовой drop-in заменой Scholar policy: его правила и входной evidence-line contract отличаются. Нужен owner-level join, а не ещё один локальный счётчик или библиотека «для научной достоверности».

## 1. Что исполнено и что подставлено

**Исполнены полные определения модулей/owners:** ScholarSupportRequirementCompiler/Spec; SourceMetadata/SourceSnippet/ClaimSupportLink/WebEvidenceBundle; Scholar academic evidence producer и normalizer; Runtime boundary builder; FileSystemCAS, UrlFetchCache и source-binding verifier; Scientist `verify_web_evidence_bundle`; DeepResearchJobManager normal submit/wait/persist/reopen path; existing effective-independence graph producer/validator.

Scorecard `_scholar_academic_evidence_gates`, `_gate`, `_serious_canary` и объявленная константа serious kinds выполнены как неизменённые AST bodies. **Весь scorecard/normalization/admission не запускался.** Actual producer callers и PDC projection прослежены в source; они не превращаются в executed end-to-end по наличию import.

**Synthetic inputs:** три крошечные HTML страницы, их научные утверждения, study/dataset/author/publication/citation metadata, provider trace и requirement claim. Они не выдают себя за настоящие публикации. Из этих bytes настоящий extractor получает snippets; cache реально сохраняет raw payloads; verifier перечитывает bytes/manifests и проверяет exact spans. Metadata independence научно не выводится из HTML автоматически. Для jobs единственный collaborator `RecordedBundleService` возвращает typed bundle без сети, LLM, ScholarDeepSearchService, provider/fetch scheduling и research exhaustion. Сам job owner и persistence не подменены.

**Среда:** Python 3.12.14, Pydantic 2.13.4; repo baseline Python 3.14. Использован прежний audit-only compatibility loader: скобки для 3.14 multi-except и TypeVar из typing_extensions; исходные predicates не изменены. Loader сохраняет module hashes и точные rewrites. Прежние namespace package stubs перечислены в loader. Здесь восстановлен реальный Core lazy facade; Scholar search eager facade заменён namespace для избежания отсутствующего optional OpenTelemetry. В Scientist probe также пропущены methods/search package initializers; source-binding facade symbol ссылается на **тот же настоящий validator**, не success stub. Это не native import qualification.

Native import отдельно завершился exit=1 на `core/artifacts/store.py:2155`, неподдерживаемый 3.12 multi-except syntax. Это environment blocker, не ошибка продукта на заявленном Python 3.14. Optional packages не устанавливались; source/tests/lockfiles не изменялись.

## 2. RC-01: правила зависимости присутствуют, но не исполняются

**Severity: medium semantic correctness / evidence-strength overstatement. Confidence: high для выбранного owner и persisted route; operational/public authority consequence не установлен.**

### Действующий нормативный contract

Accepted ADR-0160 `docs/adr/0160-evidence-portfolio-independence-multiverse-synthesis.md:42–49` требует effective independent count вместо raw count и collapse при shared lineage/corpus/author-institution/preprocessing/assumptions/identification/equivalent method. Active implementation plan `POLICYOS_UNIVERSAL_POLICY_DESIGN_CASE_IMPLEMENTATION_PLAN.md:1926–1932` прямо требует, чтобы Scholar adapter **consumed** typed spec вместе с dependent-corpus rules. Это не только возможное будущее поле DTO. При этом W8.F того же плана (`:2048–2055`) различает hard-collapse и graded dependence: перенос правил должен сохранять эту разницу, а не объявлять любое shared institution полным научным тождеством.

### Различающий fixture

Production causal claim: «Credit guarantees improve MSME survival». Настоящий compiler выдаёт peer_reviewed, recency 730 days, replication=2, independence breadth=2, citation depth=2 и все шесть collapse rules. Независимый fixture содержит два study IDs, разные raw HTML hashes, две точные цитаты и достаточные publication/recency/depth fields. Он даёт pass и effective=2.

Для каждого теста изменён только исследуемый dependence field у двух sources:

| Case | Exact raw/span check | Effective | Report / Runtime boundary |
|---|---|---:|---|
| Разные studies и независимые metadata | pass | 2 | pass / pass |
| Один underlying study | pass | 1 | blocked / blocked |
| Разные studies, один dataset | pass | 2 | pass / pass |
| Разные studies, один author pool | pass | 2 | pass / pass |
| Разные studies, одна institution | pass | 2 | pass / pass |
| Разные studies, общая citation network | pass | 2 | pass / pass |
| Разные studies, общая replication lineage | pass | 2 | pass / pass |
| Все rules требуют effective per cluster=0 | pass | 2 | pass / pass |

Это **нарушение собственного typed policy contract**, а не утверждение, что любые две статьи одного университета научно всегда тождественны. Выбор hard/graded зависимости может быть спорным. Но если конкретный requirement объявляет такое правило, consumer должен его исполнить, явно отказать unsupported rule или сохранить limitation; молчаливое игнорирование не является научной интерпретацией.

Zero-control в исходном probe меняет rules на независимых singleton studies, а не на matched dependent cluster. Поэтому он один не доказывает точную zero semantics для уже схлопнутой группы; прямое отсутствие чтения поля подтверждается source census. Основные контрпримеры RC-01 — matched shared-dimension cases.

### Механизм

- `scholar_requirement/_impl/compiler.py:64–88,112–164,350–410,495–510`: строгие DTO, effective_support_per_cluster 0..1 и шесть default rules.
- `scholar/_impl/evidence.py:171–205`: producer сохраняет dataset/author/institution/citation/replication metadata в selected sources. Следовательно, нужные факты не отсутствуют на входе.
- `:1169–1202`: family tag определяется underlying_study_id, иначе raw content hash, иначе source identity; duplicate flag делает один lookup base tag.
- `:1462–1484`: effective count — число `_source_dependence_key` среди source IDs claim. Requirement collapse rules функция не получает.
- `:1720–1731`: ключ — study ID / family tag / source ID; пяти дополнительных измерений здесь нет.
- `:1359–1395`: dependence records сначала группируются по тому же ключу, effective count устанавливается 1 на группу. Только **после группировки** `_collapse_reasons_for_sources` (`:1679–1700`) смотрит dataset/authors/etc как объяснения внутри уже существующей группы. Оно не создаёт недостающих edges между разными study IDs.
- `:1487–1587`: producer сравнивает полученный count с required replication/breadth, добавляет tier/recency/depth blockers.
- `:874–999`: reader проверяет collapse того же study/tag и согласованность некоторых counts, но не исполняет declared collapse rules.

Полный literal census 2 895 source `.py`: слова `dependent_corpus_collapse_rules` / `effective_support_per_cluster` встречаются в definition/construction у requirement compiler, а не в consumer calculus. Это именованный поиск конкретных symbols, не семантическая проверка всех файлов.

### Персистентный путь и ближайший consumer

`probe_jobs.py` вызывает настоящий public submit/wait; четыре случаях проходят actual job bodies (`jobs.py:224–354`). `_persist_scholar_academic_evidence_async:377–411` повторно валидирует bundle, вызывает тот же producer и пишет `scholar.academic_evidence` с настоящими schema/producer metadata и Core CanonSpec. Actual checkpoint и status index также сохранены. Reopen owner в том же процессе и затем новый процесс (`probe_readers.py`) подтверждают:

- independent → job completed, report/boundary pass, effective=2;
- same study → job completed, report/boundary blocked, effective=1;
- shared dataset → job completed, report/boundary pass, effective=2;
- invented quote → job completed/report pass, но source verifier fail; см. границы ниже.

Новый процесс читает report через настоящий `load_core_json_artifact`, а не простой json.loads. JSON-normalized report соответствует исходному. Сохранённые refs/raw blobs/manifests доступны в evidence/. Это реальная локальная CAS persistence, не только audit sidecar JSON. Не запускались production institution, deployed identity, HTTP/frontend, full claim custody, public signing или actual provider acquisition.

Три real scorecard gate bodies дают pass shared-dataset, fail same-study/one-source. Полный scorecard и его independent authority/admission gates не исполнены. PDC `policy_design_case.py:2828–2867` source-traced прикрепляет boundary к residual spine boundaries.

## 3. Чего результаты не позволяют заключить

### RC-B01: job completion, report validity и source truth различны

`completed` у blocked same-study job — нормальная граница: задача закончилась с дефицитом. Это не finding. Нельзя считать эти слова доказательством закрытия requirements или global knowledge exhaustion.

Report-only normalizer, boundary и выбранный scorecard gate не вызывают raw/span validator. Поэтому structurally valid bundle с выдуманным snippet даёт report/boundary pass, даже после actual job persistence. **Настоящий Scholar source-binding validator и Scientist verifier эту цитату отвергают** (`span_text_mismatch:n0`); отсутствие CAS даёт `source_cas_unavailable`. Scholar `api.enrich_topic:66–105` также содержит source verification before hydration. Обнаружена разница contracts, не отсутствие source verification в продукте и не доказанный путь к подписи. Существующий authority envelope прямо исключает method_validity, source_family_satisfaction и closeout_pass.

Из данных не следует, что `verify_web_evidence_bundle(passed=True)` устанавливает независимость экспериментов: и same-study, и shared-dataset проходят именно byte/span/link integrity. Это правильное ограничение verifier, а не ещё один дефект.

### RC-B02: normalizer не является независимым recomputation oracle

У same-study report в audit-only mapping удалены blockers и count изменён на 99; runtime boundary вернул pass. Normalizer проверяет структуру/dependence records, но не пересчитывает requirement status/count из source facts. Не изменялись retained CAS или авторизованный продуктовый объект. Это характеризует reader contract; не объявляется отдельной auth vulnerability. Исправлять следует authenticated producer+recomputation seam, а не бессмысленно добавлять одинаковую shallow validator обёртку на каждом consumer.

### Сохранённые отрицательные controls

- One source / same study → replication+independence blockers.
- Page age 1000 days при requirement 730, default report maximum 1095 → именно requirement recency blocker.
- Working paper вместо peer-reviewed → publication tier blocker.
- Нет citation refs → citation depth blocker.
- Invalid snippet → source-binding и Scientist verifier reject.
- Нет CAS → Scientist verifier reject.
- Исходный participation test с requirement сохраняет context-only firewall.

Ни один контроль не проверяет реальную peer review, причинную идентификацию, transportability или scientific reproducibility. Это отдельные owners, не выводимые из URL, hash или количества refs.

## 4. Подлинность tests

Именованный selected denominator: четыре test-файла, 33 authored `test_` definitions, а не runtime parametrized cases и не весь репозиторий. `test_census.json` сохраняет paths, lines, assertion counts. Count assertions не считается качеством test.

Шесть неизменённых исходных test bodies выполнены напрямую с original helper `sha`, настоящими compiler/DTO/producer/normalizer; все pass:

- compiler emits serious claim spec;
- compiler participation downgrade;
- dependent corpus (same underlying study) blocks;
- claim source satisfies full requirements;
- deficits are claim-bound;
- participation firewall with requirement.

**Это bounded direct replay, не native pytest collection, conftest/markers/fixtures/CI execution.** Не следует писать «6 native tests passed».

Существующий dependent-corpus test (`test_scholar_academic_evidence.py:690–820`) является содержательным negative test: проверяет actual producer count, blockers и collapse reason. Однако его sources совпадают по underlying_study_id и content_sha256. Он не различает «исполняются все шесть rules» и «работает только study key». Compiler test отдельно утверждает наличие шести typed rules, но не соединяет их с downstream behavior. Наши per-dimension perturbations закрывают этот конкретный oracle gap. Аналогично source-binding test file содержит настоящие retained-byte, wrong span, missing CAS и wrong-manifest controls; их наличие нельзя обнулить слабостью другого теста. Здесь выполнены собственные source controls, а не весь исходный source-binding suite.

`sha(char)` в test helper повторяет произвольную строку 64 раза, а некоторые fixtures передают длинный token. Такие CAS-like placeholders годятся для shape/unit tests, но не доказывают реальную custody или разрешимость ref. Новый probe использует настоящий CAS для raw страниц/report/checkpoints.

Первые ошибки инструмента сохранены: пропущенный обязательный FetchResult.final_url; отсутствовавший fixture function в isolated authored-test loader; skipped eager facade требовал reexport настоящего validator. Исправлялись только audit scripts/import plumbing, не product predicates. Первое raw json read обнаружило Core tagged floats, поэтому equality не прошла; corrected reader использует штатный canonical decoder, сохраняет первоначальный output и получает equality=true. Это ошибка измерителя, не новый finding продукта.

## 5. Реальные registries/owners и переиспользование крупных подсистем

### 5.1 Не создавать четвёртый evidence counter

Уже существуют три разных contracts:

1. Scholar requirement DTO + academic report: literature-specific hard-collapse rules и deficits.
2. Runtime `evidence_independence.build_evidence_independence_map`: portfolio line validation, method equivalence/consensus grouping и точная signature из claim/strand/method/source/corpus/author/preprocessing/assumptions/identification/failure-mode dimensions.
3. `evidence.portfolio.effective_independence_graph`: pairwise hard edges, transitive clusters, separate support/counter/context mass, feature-flagged graded dependence и scarcity.

Реальный третий owner выполнен с original repository fixture helpers, без Scholar adapter:
- one study, разные остальные dimensions → support count 1;
- different studies, same snapshot+preprocessing+identification → 1;
- independent versions всех этих inputs → 2;
- support и counterevidence того же study → support=1, counter=1, не positive mass=2.

**Решение: extend/consolidate existing owner с явным contract adapter.** Не направлять Scholar в Runtime quality в обход слоёв. В существующем neutral `evidence` owner можно разместить agreed dependence relations и rule evaluation, сохранив Scholar requirements и Runtime portfolio adapters. Формальная эквивалентность нынешних трёх алгоритмов не установлена: Runtime exact-signature grouping и graph relation union дают разные semantics; graph по одному dataset не обязан делать Scholar hard collapse. Graph нормализует свой evidence-line contract и не является полной scientific admission проверки. Миграция должна выбрать policy, сохранить raw counts, polarity, claim/scope и rule version, а не просто вызвать более длинную функцию.

### 5.2 Wire existing source verification, не дублировать extraction

Exact source resolver уже владеет selected ArtifactRef/manifest profile/raw hash/extractor/snippet offsets; Scientist verifier его переиспользует. Academic report/job path должен явно отражать свой уровень доказанности и принимать/сохранять content-bound verification result, если такой уровень нужен его consumer. Не выводить `source verified` из report PASS и не писать вторую HTML extraction/quote checker implementation. Preserve no-CAS, selected nondefault manifest, unknown-profile, stale source and changed-extractor controls. Writer/read profile changes должны быть versioned и tested отдельно.

### 5.3 Method registry и scientific equivalence остаются у Foundry

Source trace показывает Runtime `_MethodCollapseIndex` (`evidence_independence.py:455–550`) union-ит method IDs из consensus/equivalence reports. Foundry имеет собственные typed estimand/covariance/refusal contracts (`methods/components/consensus.py`), cross-backend certificate resolver (`methods/equivalence/resolver.py`) и signature-aware verifier (`verify.py:378–389,470–481`). InMemoryEquivalenceCertificateRegistry прямо обозначен local/phase-0, latest matching method/backend entry, а не глобальный admitted scientific registry. В этом срезе **не исполнялись** consensus computation, certificate signature verification, calibration/MethodRegistry или Runtime map с реальными Foundry outputs. Не смешивать literature independence, numerical backend equivalence и причинную валидность метода. Для reuse следует потреблять owner-qualified evidence, не копировать перечень method IDs в новый Scholar authority registry.

### 5.4 Почему NetworkX не является готовым исправлением

NetworkX может заменить graph connected-components/union kernel, но не определяет, когда shared authors/data/citations означают hard или graded dependence. В pinned exports networkx 3.6.1 присутствует только в research; runtime/minimal содержат types-networkx, а не сам пакет. В audit environment networkx отсутствует. Поэтому это **defer**, не рекомендация добавить тяжёлую зависимость ради нескольких union/find строк. Сначала shared semantic owner и workload bound; затем при реальной сложности graph workload измерять library alternative. Никаких differential/scale benchmark NetworkX здесь не выполнялось. Existing graph положительно проверен и полезен независимо от third-party выбора.

## 6. Минимальные архитектурные acceptance

1. Нормализованный typed dependency edge / cluster basis связывает claim, source IDs, relation kind, exact supporting refs, rule ID/version и статус установления. Unknown dependence не становится независимостью из-за другого content hash.
2. Interpreter принимает все declared rules и effective_support_per_cluster, либо отказывает unsupported policy. Same study, each shared dimension, zero weight и contradictory rules имеют различающие outcomes.
3. Transitive A–B–C relations, permutation, duplicate, источник с двумя claim memberships, shared dataset but governed graded-not-hard policy, opposite polarity и отсутствующий metadata field проверяются отдельно. Нынешний срез **не выполнял** все эти future cases.
4. Actual job persistence → canonical reopen → boundary/scorecard сохраняет тот же recomputed count, rule/profile identity и limitations. Completed/blocked остаются разными полями.
5. Source/content verification и methodological validity приходят от своих existing owners. Замена компонента не вправе повышать authority только за счёт pass labels.
6. Native 3.14 supported profile, full report admission/scorecard, actual fixture-managed retrieval→claim ledger→consumer и selected installed imports закрывают остаток. Native runtime scientific jobs и публикация не подменяются совместимым loader.

## 7. Артефакты и остаток

`results.json` + `cases.json`: typed fixtures и 13 cases. `job_results.json`, `reader_results.json`: actual persisted manager и fresh-process reopen. `scientist_results.json`: независимый source/link verifier. `reuse_results.json`: four full existing graph controls. `authored_tests.json`: шесть direct test replays. `SOURCE_VALIDATION.json`, `source_excerpts.json`, `caller_census.json`, `test_census.json`: source binding и именованные denominators. `OWNER_MATRIX.json`, `FINDINGS.json`, `REUSE_DECISIONS.json`: компактные decisions. `VALIDATION.json` и SHA256SUMS фиксируют пакет.

Не выполнены live web/providers, external paper-quality verification, licensed source admission, DuckDB SKG, causal estimation, actual scientific method registry/certificate path, complete replay orchestration, native suite, full authorizing scorecard, signatures/publication или production scaling. Это новое substantive звено Scholar/evidence, не повтор EC scope loss, PA draft codec или W1/bootstrap findings.
