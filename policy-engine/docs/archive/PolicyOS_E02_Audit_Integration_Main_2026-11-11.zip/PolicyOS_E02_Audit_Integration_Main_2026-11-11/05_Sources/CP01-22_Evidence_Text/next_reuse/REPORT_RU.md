# PolicyOS: reuse после checkpoint01

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`, 10 ноября 2026. Read-only source. Это завершённый выбранный проход, не завершение направления C и не native qualification. Решения ниже предложены, не реализованы и не приняты maintainer.

## Что изменилось в выводах

1. **Boolean cycle: прежний library-кандидат доведён до consumer и CLI.** Не только отдельный DFS, но exact тело `AuditPackageVerifier.verify` на локальном JSON-пакете с цепочкой 1 200 рёбер выбрасывает `RecursionError`. Exact CLI обрабатывает её как exit 2 без структурированного отчёта. Замена только `_has_cycle` в namespace пробы на `graphlib.TopologicalSorter` сохраняет короткие controls, завершает длинный DAG и даёт `PROV_CYCLE_DETECTED` для длинного цикла. Это углубление прежнего решения, не новый дефект по числу callers.
2. **Новая выбранная семья: shadow metric projection.** В academic/catalog/legal допустимые typed metric maps с ключами `a.b` и `a: {b: ...}` теряют один из путей при flattening. Изменение первого значения 1→9 при неизменном втором 2 даёт пустой `metric_deltas` и `has_changes=False`. Обычное 1→2 обнаруживается. Для Ukraine такой nested input не допускает его `table_counts` DTO, поэтому этот witness не переносится на него. У всех четырёх сравнение чисел 2^53 и 2^53+1 теряет разницу после float conversion, но такие реальные counts не установлены. Это точность сравнительного отчёта, не bypass публикации/authority.
3. **Положительный новый кандидат: complete artifact-view identity.** Четыре функции возвращают одну и ту же четверку artifact ID / kind / media / manifest profile. Реальный execution-edge comparator отвергает изменение любого поля, включая профиль при том же digest. Canonical Core helper уже используется соседними Foundry owners. Переиспользовать можно только вычисление ключа, не nominal refs, resolver или admission.
4. **Маленькие положительные кандидаты квалифицированы границами.** Foundry entry-point enumeration совпадает с existing Core на реальных stdlib `EntryPoint` values и всех пяти выбранных provider modes, включая propagated enumeration failure. Exact `discover` сохраняет порядок и per-entry error envelope при подстановке Core enumeration. Три feature-importance projection copies совпали на семи boundary cases, но estimator/effect-sensitivity policy не становится общей с supervised sklearn importance.
5. **Prerequisite Core LRU сохранён.** Повторно подтверждено: stored `None` удаляется, но `delete` сообщает false. `False`, `0`, пустые list/dict сообщают true. Найденный maintained production consumer `NodeResultCache` хранит `ArtifactRef` и удаляет через `pop`, не `delete`: доказанного текущего инцидента нет.

Все числовые результаты, exact source hashes и spans: [results.json](results.json). Свод решений: [decisions.json](decisions.json). Полный перечень 41 прежнего family decision и статус свежей проверки: [prior_family_reconciliation.json](prior_family_reconciliation.json). Это сверка прежнего списка, **не повторный semantic review всех 41 семей и не adjudication всех raw clone groups**.

## 1. Boolean cycle → stdlib graphlib

**Связь:** прежнее `boolean_audit_cycle`, SYS-03. Приоритет P2; medium availability/report-completion consequence, высокая уверенность в локальном механизме. Не security incident.

**Trace:** public Core export → `AuditPackageVerifier.verify` (`core/audit/verifier.py:53–98`) → `_verify_provenance` (`519–620`) → `_has_cycle` (`962–981`). CLI `_cmd_audit_verify` (`core/components/_cli_audit.py:76–109`) ловит exception и возвращает 2 до JSON/Markdown output.

**Проверка:** выполнены exact class/model definitions, все стадии verify оставлены настоящими. На диске созданы index, checksums и `provenance/prov.json`, полный entity closure; CAS manifests и signatures отсутствуют. Default permissive signature/SLSA policy даёт warnings, не failure. Для fixture hashing использован stdlib SHA256, а не product import `streaming_hash`. Тар-распаковка, криптография, CAS models, assembler и deployed CLI не исполнялись.

- DAG 8 edges: original и graphlib дают provenance PASS, CLI 0 и JSON.
- Cycle 9 edges: оба дают FAIL / `PROV_CYCLE_DETECTED`, CLI 1 и JSON.
- DAG 1 200 edges: original `RecursionError`, CLI 2 без JSON; graphlib PASS / CLI 0.
- Cycle 1 201 edges: original `RecursionError`, CLI 2; graphlib structured FAIL / CLI 1.

Результат относится к Python recursion limit 1 000 в измеренной среде. Размер допустимого реального экспортированного корпуса, default assembler max depth и frequency не установлены. Вход verifier не ограничивается этим exporter fixture, но факт реального большого production archive не заявлен.

**Решение:** `reuse_existing`: сохранить `_has_cycle` boolean facade, использовать stdlib graphlib. Не нужен NetworkX, новый graph framework или зависимость от Core pipeline domain. Направление ребра для обнаружения цикла не меняет boolean property; не выдавать этот adapter за SCC partition или tier ordering.

**Acceptance:** Python 3.14 installed imports и реальный CLI с bounded архивом; empty/duplicate/self-loop/disconnected/long DAG/long cycle, сохранение report code и policy. Resource limits для недоверенного package отдельны от устранения recursion. Stop: не расширять к causal graph/registry SCC.

## 2. Shadow metric diff: общая потеря пути, разные domain projections

**Связь:** новая выбранная семья в SYS-02, не четыре дефекта. Приоритет P3, low severity для доказанного информационного surface; high confidence для typed compare witness, production impact не установлен.

Raw exact groups 80 (`_metric_deltas`) и 116 (`_flatten_numbers`): четыре `data_forge/domains/{academic,catalog,legal,ukraine}/shadow.py`. В каждом реальный `compare_*_shadow_bundles` возвращает domain-specific `*ShadowDiff`; его `has_changes` использует `metric_deltas` вместе с artifact/source/readiness изменениями. Public `data_forge.read_api.*` и domain facades экспортируют эти compare APIs. В ограниченном поиске maintained source не найден вызов comparison, принимающий publication/authority решение. Это не доказательство отсутствия внешних/dynamic consumers.

Механизм: `_flatten_numbers` объединяет path segments через `.`, записывает в dict с overwrite, игнорирует bool/list/text и превращает int в float. `_metric_deltas` имеет zero-default для отсутствующего ключа. Ближайшие положительные tests проверяют обычные metrics и artifacts; они не выполнялись и не считаются полной картой coverage.

**Контрпример, 3 domain compare bodies:** baseline `{'a.b': 1, 'a': {'b': 2}}`, candidate `{'a.b': 9, 'a': {'b': 2}}`, одинаковые readiness и пустые artifacts. Оба flatten maps содержат один `benchmark.a.b=2`; diff пуст. Pydantic models принимают inputs в измеренном профиле. Actual persisted pipeline outputs с такими keys не найдены и loaders не исполнялись. В настоящем bundle изменившийся artifact checksum может независимо сделать `has_changes=True`; это не исправляет потерянный metric delta, но ограничивает claim о полностью скрытом изменении.

**Различия сохраняются:** academic читает benchmark+QC; catalog table counts+benchmark+source counts; legal table counts+quality+benchmark и cache markers; Ukraine table counts+source records. Поэтому одинаковая внешняя `_metric_deltas` не означает одинаковый bundle contract. Ukraine nested collision не проходит его typed table-count input, и такой witness в результатах отсутствует.

Другие characterization, не отдельные находки: missing→0 даёт no-change; NaN/inf policy не нормализуется helper; большие целые 2^53→2^53+1 округляются одинаково. Zero-default может быть намеренной compatibility policy, поэтому не объявлен нарушением без owner decision. Большие counts не признаны production bug.

**Решение:** `extract_primitive`, только после выбора contract: общий numeric path/difference kernel внутри DataForge, domain metric selection и public DTO оставить у owners. Ключи сравнивать как tuples либо явно escape segments; если меняется serialized dot-key grammar, нужен совместимый/versioned projection. Не внедрять pandas/DeepDiff только ради этих 10 строк: их list/bool/missing/type/precision semantics другие, а эта проверка не оценивает новую dependency.

**Acceptance:** native typed compare + persisted loader fixtures; conflict keys с обратным insertion order; missing versus zero; integer boundary; nonfinite; bool/list handling; artifact hash и readiness independent controls. Stop: общие domain readiness DTO/authority checks не объединять.

## 3. Полная artifact-view identity: reuse вычисления, не authority

**Связь:** новый выбранный positive reuse candidate, SYS-02/03. Приоритет P3, дефект не заявлен. Raw exact group 86 содержит 4 source members и 1 test member; проверены 4 source members, test helper не объявлен production clone.

- `core/artifacts/manifest.py:303–317` → public `artifact_ref_identity_key`.
- `foundry/calibration/calibrator.py:937–944`, caller calibration source plan/graph comparison `1406–1408`.
- `foundry/execute/api.py:529–537`, actual `_require_execution_edge_ref:540–559`; более широкий input-basis admission также использует этот key.
- `foundry/uncertainty/aggregator.py:500–509`, actual deduplication in `aggregate_persisted_envelope_views:642–686`, **после** selected manifest/content reads и context reconciliation.

Для base и пяти variants все функции дали равные keys; каждый variant отличим. Exact execution-edge comparator с fixture selected-edge resolver пропускает только полное совпадение и отклоняет остальные пять. Digest-only negative control не различает profile. Это проверка comparator, не реального resolver/manifest verifier.

**Решение:** `reuse_existing` условно. Core owner уже экспортирован и потребляется `foundry/execute/model_input_requirements.py`, `foundry/data_plane/bindings.py`, calibration uncertainty adapter и compiler. Core helper аннотирован Core `ArtifactRef`; execution/aggregation также принимают IR `UncertaintyEnvelopeRef`. Runtime attribute equality в пробе на lightweight fixtures не доказывает static type compatibility или nominal admission. При консолидации сохранить local wrappers/FQNs при необходимости и определить узкий type-safe field interface без Core→IR reverse import. Не приводить ref через строковый digest, не делать JSON dump/validate скрытым authority adapter.

**Acceptance:** locked Core и IR refs через настоящие imports, mypy/import policy, profile absent/present/different, kind/media differences, selected manifest tampering и repeated-view dedup. Сохранить все четыре fields, ordering и current admission; не переименовывать authority decision в identity helper.

## 4. Entry-point enumeration: existing Core подходит для правильного input contract

**Связь:** прежнее `entry_point_enumeration`, SYS-03; P3 maintenance, дефект не заявлен.

`MethodDiscovery.add_entry_points:648–650` создаёт `EntryPointSource`; `discover:277–301` получает `_get_entry_points:303–314`, затем процессит каждого entry отдельно. Existing Core `list_entry_points:112–130` имеет тот же `(name,value)` order и compatibility fallback. Foundry domain-plugin discovery уже использует Core helper (`foundry/plugins/discovery.py:134–159`), то есть нижний owner принят другим local consumer.

Проверены modern direct, legacy select, legacy dict, enumeration RuntimeError и direct None. Настоящие stdlib EntryPoint objects не загружают plugins: callback processing синтетический. Выходы `q:a,q:b`, один `q:z` failure и DiscoveryError fields совпали до/после Core substitution. Enumeration failure остаётся propagated, не превращается в per-entry success.

**Не полностью одинаковы:** Core сортирует `str(getattr(...))`, Foundry читает raw `ep.name/ep.value`. У metadata-shaped impostors с `None`/integer names Core даёт порядок, Foundry TypeError. Это не стандартные EntryPoint values. Не выдавать их equality за весь Any envelope и не устранять Foundry per-entry exception policy.

**Решение:** `reuse_existing` через тонкий `_get_entry_points` forwarding seam, с cold import и monkeypatch seam controls. Base group и plugin coercion остаются у Foundry. Не нужен stevedore/pluggy для общей enumeration. Installed metadata and real plugin load/error test остаются UNRUN.

## 5. Feature-importance projection: три exact leaf copies

**Связь:** уточнение прежней `causal_effect_sensitivity`, новый поднабор raw exact group 34; SYS-08. P3; correctness defect не заявлен.

`_feature_importances_from_array`: `cate:152–179`, `meta_learners:63–90`, `advanced_designs:42–69`. Семь cases: empty, signed scores, NaN/±inf, equal magnitudes, ровно threshold/nextafter above, 2-D flatten. Все три совпали; исходный массив не изменён.

Контракт: абсолютный score, не normalization; nan/inf→0; sum(abs)≤1e-10→empty; NumPy argsort с неустановленной дополнительной tie policy; fallback имена xN; method и metadata shape сохранены. `cate:413` и `meta_learners:608` получают arrays из effect-sensitivity перестановок, с разными caller seeds и constraints. `advanced_designs:780/986` получает shared nuisance tau-fit importance и отдельно suppresses homogeneous CATE. Слияние вычислительных веток не следует из formatter equality.

**Решение:** `consolidate` local causal formatter, при необходимости сохранив facades. Existing NumPy уже делает kernels; новой библиотеки не надо. `sklearn.inspection.permutation_importance` является predictive-score degradation с y/scorer, тогда как здесь effect(X) sensitivity. Не drop-in; полные estimator fits и supervised alternative не запускались.

**Acceptance:** native caller/result DTO characterization, exact threshold/tie behavior, failures/invalid arrays, saved method labels; RNG and homogeneous suppression остаются local. Улучшение статистического смысла не подменять косметическим переносом.

## 6. LRU prerequisite: исправить контракт перед расширением reuse

**Связь:** прежнее `tmle_timeline_lru_storage`, SYS-03; reconfirmed, не новый root mechanism.

Exact `LRUCache.delete` (`core/cache/lru.py:73–76`) использует `pop(key,None) is not None` вопреки собственному docstring и Cache protocol. Пять nullable/falsy controls подтверждают различие presence и value. Реальный inspected consumer `NodeResultCache` (`scientist/orchestration/engine/idempotency.py:401,494–500`) содержит typed ArtifactRef index и вызывает `pop`, а также отдельно управляет live I/O tokens, provider lane и verified keys. Нельзя переносить эти authority/lifecycle обязанности в generic LRU.

Решение прежнее: qualify sentinel-based presence contract, затем заимствовать resident storage там, где подходят capacity/order/stats. Нет оснований заменить compilation generation/single-flight, persisted clocks или controlled issuance generic cachetools/functools. Native nullable consumer test и adoption decision остаются открыты.

## Воспроизведение, provenance и границы

Команда: `PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 python policyos_deep_audit/next_reuse/probe_reuse.py`. Финальный exit 0; [stdout](probe_stdout.txt), [stderr](probe_stderr.txt), [execution.json](execution.json). Два stderr warning про entry point являются заданным negative control.

Первый запуск завершил assertions и записал results, но stdout serializer не обработал намеренный infinity characterization. Это **ошибка измерителя**, не продукта. Исправлен только stdout sanitization; предыдущий traceback сохранён в [probe_stderr_v1_instrument_error.txt](probe_stderr_v1_instrument_error.txt), весь probe запущен повторно.

Фактическая среда: Python 3.12.14, NumPy 2.3.5, Pydantic 2.13.4. Repo baseline Python 3.14; Pydantic bound <2.13. Поэтому typed replay не заменяет locked acceptance. AST определения взяты из canonical snapshot без изменения syntax; dependency imports заменены audit namespaces и явно описанными fixtures. Извлечённые классы/функции не равны installed/full-application coverage.

[Source validation](source_validation.json) сверяет использованные source paths с pinned baseline manifest; [source excerpts](source_excerpts.json) сохраняют deciding fragments для проверки. Для полного повторения нужен canonical checkout того SHA: source tree не дублируется в этом компактном наборе. Full source scan не объявлен semantic audit; raw source/test groups не суммируются с normalized groups.

Не выполнялись product fixes, source/tests/config changes, pip/uv installs, remote refs, E02, acquisition, DB, solver/training jobs, full suites, installed distribution, production workload. Находки о допустимых input fixtures не повышены до deployed incidents. Native profile, actual persisted corpora, full consumer chains и остальные задачи C3/C4/C7/C8 остаются открытыми.
