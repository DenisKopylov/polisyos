# Независимый red-team CS-01 и CS-02

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Source read-only. Проверены producer/consumer reachability, actual CAS lineage, альтернативные договорённости и отрицательные контроли. Два исходных probes повторены в изолированном каталоге; третий, независимый probe проверяет logical parent, detached sidecar и прекращение route body после отказа guard seam.

**Итог: PARTIAL. CS-01 сохраняется как P2, но с уточнённой областью scientific binding/provenance. CS-02 подтверждён как поведение; рекомендован P3/API contract debt, пока не закреплено обязательное значение parent. Ни native qualification, ни security/tenant/publication bypass не доказаны. Новых SYS-семейств нет.**

## CS-01: что подтверждено

1. `AttractorAnalysisService.analyze_attractors` (`runtime/http/services/attractors.py:57–74`) загружает feedback и независимо переданный request diagnostic. Он не использует `feedback.jacobian_diagnostics_ref`, не сравнивает источники и не передаёт diagnostic ref в output. Отсутствие request diagnostic даёт `unknown`: это консервативная деградация, не самостоятельный fail-open и не доказательство обязательности fallback.
2. `FeedbackJacobianDiagnostics` прямо описан как diagnostics near the solved fixed point (`core/contracts/foundry.py:1775–1793`). Реальный solver вычисляет summary на `chosen.solution` (`foundry/feedback/fixed_point.py:95–142`), execute связывает его с trace и feedback (`foundry/execute/api.py:2115–2142,2869–2914,3062–3165`). Это production producer, не только тестовый DTO. В повторённом эксперименте исполнялись неизменённые persistence bodies, но **solver outcomes синтетические**, physical map/solver не запускались.
3. Преобразователь берёт variables/final_state именно из feedback (`foundry/analysis/attractors.py:510–572`), а `local_class` вычисляет из переданного diagnostic radius (`:1205–1258`) без relation check. Два разных valid diagnostics дают `unstable` и `asymptotically_stable` на одном persisted feedback. Foreign trace проверен как при той же dimension=1, так и при dimension=2 против projected dimension=1. Простая проверка dimension не закрывает witness той же размерности.
4. `persist_attractor_analysis_result` выбирает profiles upstream refs, но входной diagnostic не входит ни в поля result, ни в `_result_input_refs` (`:651–688,1279–1297`). Inline numeric summary сохраняется, однако выбранная reference/profile/trace relationship explicit diagnostic отсутствует. Ссылка feedback ведёт к **собственному** diagnostic, не к использованному foreign. Fresh process повторно прочитал persisted stable/dimension=2: это не только in-memory object.

### Точные ограничения lineage

Формулировка «producer уже хранит полностью exact relation» слишком сильна. `_persist_feedback_jacobian` возвращает `FeedbackJacobianDiagnosticsRef(artifact_id=...)` без `manifest_profile_sha256` (`execute/api.py:2914`); feedback сохраняет именно такой bare ref и bare manifest input. В probe trace refs selected, а diagnostic refs bare. На существующем default profile readers действительно работают и invalid selected profile отвергается, но **producer не сохраняет явный selected profile diagnostic**. Repair должен установить точный ref/profile, а не только сравнить два artifact_id.

В полном execute final feedback state на successful branch вновь извлекается из final executed state (`execute/api.py:2374–2408`), тогда как Jacobian вычислялся на chosen solver solution. Данный review не доказывает численную эквивалентность этих точек во всех режимах. Own ref является owner-declared relation, не самостоятельным доказательством научной истины.

CAS content identities результата различаются. Общий logical analysis_id не является collision или overwrite CAS. Наличие `numerically_supported` связано с converged flag, не с независимым proof of Jacobian relation. `available` у IR bridge означает точную доступность analysis для выбранной simulation, а не institutional acceptance.

### Альтернативные договорённости

- **Явный reanalysis override.** Дополнительный diagnostic может быть намеренно вычислен другим методом/при других parameters. Тогда равенство artifact_id или trace не должно механически блокировать все overrides. Но нужны typed relation к выбранному состоянию/координатам, причина reanalysis/допущения и сохранение реально использованного ref. Текущий DTO такой договорённости не выражает; output silently выглядит как lift данного feedback.
- **Reduced/subspace Jacobian.** Разные dimensions могут быть допустимы при определённой projection. В этом feedback path projection формируется из всех `final_state.variable_ids`; отдельное mapping/reduction diagnostic не передаётся. Поэтому witness dimension=2/1 показывает undeclared mismatch, а не общий запрет разной размерности в научных системах.
- **Trusted caller.** Даже если caller обязан давать правильные refs, отсутствие explicit provenance и relation остаётся scientific-custody debt. Это не устанавливает lower-trust attacker, доступ к чужим данным или нарушение authz.

### Reachability и компенсирующие guards

Runtime app включает analysis router (`app.py:466–467`), context создаёт настоящий `AttractorAnalysisService` (`dependencies.py:175`), POST имеет ANALYSIS_EXECUTE dependency (`routes/analysis.py:55–69,91–103`). Статический путь до service установлен, authenticated ASGI динамически не выполнялся.

Повторены реальные CAS/DTO refusals: missing diagnostic, wrong selected profile, conflicting trajectories, dimension=0. Все отказали. Neutral ABM mapper оставляет `not_available`. Отдельный `attach_abm_bifurcation_report_ref` проверяет selected simulation ID/profile и ровно один соответствующий manifest input, отвергает different simulation/missing lineage; foreign-Jacobian analysis удовлетворяет этому **другому** predicate и даёт `available`. Полный переиспользованный literal census 2,895 `.py` файлов `src/polisyos` содержит только definition/export attach, не production caller. Это не автоматическая цепь Runtime API→ABM→Scientist/public signature. Dynamic dispatch и внешние consumers census не закрывает.

## CS-02: поведение подтверждено, семантику не переобъявлять

В обеих nested GET route bodies (`runtime/http/routes/analysis.py:213–277`) `analysis_id` попадает только в audit metadata. Parsing, tenant check и load относятся к child. Foreign, correct и malformed parent возвращают один child. Повтор исходного probe: шесть успешных cases; независимые cases дополнительно показали, что **совпадающий и несовпадающий logical parent** также не различаются. Сам relationship check отсутствует при любом из двух толкований ID.

Однако важны контраргументы:

- Shipped typed-GET test использует для branch URL parent `analysis_selected_profile`, не CAS ID (`tests/unit/runtime/http/test_attractor_analysis_typed_get.py:44–60,108–121`). Для basin тест использует CAS analysis artifact ID. Поэтому обязательный `_parse_artifact_id(parent)` не следует из текущего контракта и сломает существующий положительный случай.
- `BasinMap.analysis_id` и `ContinuationBranch.analysis_id` nullable (`core/contracts/foundry.py:2296–2350`). Standalone POST persistence не требует существующего parent. Независимый probe создал branch с `analysis_id=None`; он читается под произвольным parent. Это поддержанная detached representation, не само по себе повреждение данных.
- Generated logical analysis_id отличается от artifact_id analysis. Простое сравнение URL parent со sidecar.analysis_id не исправляет basin path, используемый shipped test. Решение должно определить canonical namespace и relationship, либо явно документировать parent как decorative/request context и предложить global child route.
- `record_data_access_audit` сохраняет endpoint/request context и **child resource_id** (`dependencies.py:295–360`). Нет evidence, что metadata.analysis_id принимается как verified custody association. Нельзя называть это audit poisoning, forged authority или подменой доказанного owner relation. Оно может быть честным логом того, какой URL запросил caller.

**Рекомендация:** retain narrow CS-02 как P3 consistency/contract debt. Если обещание API означает «получить sidecar, принадлежащий этому parent», отсутствие check является correctness defect. Если parent официально non-binding context, технический witness остаётся фактом, но более сильная defect claim снимается; нужно убрать двусмысленность surface. P2 data-access/security severity не обоснована.

### Guards CS-02

Malformed child отвергается. Typed CAS readers проверяют actual kind/schema/profile. Реальный `enforce_artifact_tenant_access` требует scope, отказывает unscoped при disabled opt-in и чужому tenant (`dependencies.py:469–509`). Probe заменяет его observer seam и **не проверяет реальную tenant isolation**. Независимый refusal seam в обеих routes бросает PermissionError до load/audit, route body его не поглощает. Это control-flow evidence, не auth integration qualification. Default unscoped refusal также ограничивает доступность новых standalone sidecars без run ownership, если deployment не включает opt-in.

## Acceptance и владельцы

CS-01: Foundry feedback/analysis остаётся владельцем relation, Runtime оркестрирует выбранные refs. Разрешить только owner-bound source либо явный reanalysis contract с state/variables/order/dimension/projection/parameters, и сохранять selected diagnostic ref в payload/lineage. Omitted diagnostic может законно давать unknown или использовать owner ref после явного определения API. Tests: own ref; omitted; foreign same dimension; mismatch dimension/order/state; supported reanalysis positive; missing/corrupt/ambiguous profile; fresh process; actual supported HTTP path. Не дублировать eigenvalue implementation в HTTP.

CS-02: сначала выбрать parent namespace и detached sidecar semantics. Затем matching parent positive, foreign logical/CAS parents negative или explicitly contextual behavior, nullable-parent case, missing parent, unrelated tenant guard, fresh CAS and supported ASGI. Не вводить строковое равенство между logical и content IDs.

**Specification:** CS-01 FAIL для сохранения фактически использованного scientific input relation; same-solve check зависит от зафиксированного reanalysis contract. CS-02 PARTIAL: фактическое игнорирование parent доказано, нормативное relation обещание требует решения. **Engineering verification:** PARTIAL, потому что Python 3.12 compatibility execution, не поддерживаемый native 3.14/locked profile.

## Evidence и freeze

`results.json`, `interfaces_results.json` содержат fresh replay исходных probes; `alternatives_results.json` — независимые controls. `evidence/` содержит actual CAS payload/manifests. Replays используют тот же pinned compatibility loader: in-memory syntax/TypeVar adaptations и namespace stubs; production source bytes не меняются. Source spans extraction исключает unrelated solver/bootstrap и route decorators. Main replay поэтому независим по запуску и анализу, **не по конструкции исходного измерителя**.

`SOURCE_VALIDATION.json` проверяет все loaded/extracted/cited source files против pinned baseline; `INPUT_MANIFEST.json` и `CENSUS_VALIDATION.json` фиксируют и проверяют оригинальные evidence/census без повторного source inventory. `REVIEW_DECISIONS.json` содержит допустимые итоговые формулировки. Все три probes exit 0, validation exit 0. Full/native/authenticated ASGI/security checks UNRUN. SHA256SUMS исключает себя и FREEZE.json; FREEZE.json закрепляет digest списка.
