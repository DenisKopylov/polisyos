# Независимая проверка historical custody

**Итог: PARTIAL_ACCEPT_WITH_SEMANTIC_QUALIFICATION.** `custody::RC-01` подтверждён собственным воспроизведением как локальный отказ исторического exact-query replay. Приоритет **P2 correctness/history availability**, не security severity. `RC-01` здесь относится только к `next_remaining_custody`; не смешивать с одноимённым scholar finding.

Source pin: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Production source и входной срез не изменялись. 442 именованных source files совпали с Git blobs этого pin; в них 370 файлов полного runtime Python census. Все 32 файла входного среза и его 79 source bindings неизменны.

## Что подтверждено независимо

Собственный `probe_independent.py` не импортирует исходный probe и не использует его результаты как oracle. Общий с исходным срезом элемент инфраструктуры: предварительно прочитанный compatibility loader. Synthetic institutional producer взят из закреплённого test helper. Production CAS, подписи, file-backed lineage, deployment factory, exchange, service, verifier и audit consumer исполняют исходные bodies.

Созданы **три** последовательных acceptance. Каждый при создании подтверждается service как `verified/current`. После третьего:

- Первый и второй receipt: exact verifier возвращает `VerifiedAnchorAcceptance/historical_for_exact_query`; production-configured service возвращает `rejected/anchor_query_or_lineage_mismatch`.
- Третий: verifier и service возвращают `verified/current`. Aggregate service outcome только `limited`, потому что holder не назначен.
- Exchange по каждому исходному request возвращает именно его receipt. Старые запросы не переименованы в текущий и не потеряли selector.
- 9 immutable файлов lineage (3 record, 3 transaction, 3 append receipt) не изменились после следующих append.
- Exact append bytes независимо перечитаны из persisted lineage receipts, связаны raw/semantic hashes с подписанным acceptance receipt и побайтово совпали с append, восстановленным из соответствующего ordered prefix.
- Rebuilder на первом и втором receipt выбрасывает `ValueError` до verifier; на третьем возвращает exact stored append bytes.
- Fresh process заново открывает public CAS, lineage и deployment. Direct historical positives и service refusals повторяются. Второй fresh process повторил результат **после распаковки поставляемого `public_fixture.tar.gz`**, а не из утерянного временного каталога.
- Реальный `audit_epoch_custody` сохранил и перечитал отказ для первого exact request. `authority_scope=custody_provider_invocation_only` и `request_reference_verification=not_established` остались неизменными.

## Причина и исторический смысл

`chronology_anchor.py:930–979,1040–1092` вычисляет historical state из `records[:position+1]`, требует exact requested query, retained entry, predecessor, hash и signed evidence, затем возвращает `current` либо `historical_for_exact_query`. Контракт `chronology.py:2882` прямо содержит обе позиции. Existing test `test_chronology_anchor.py:816–852` прямо требует, чтобы старый anchor проходил собственный query и не проходил более поздний.

В `chronology_custody.py:329–385` rebuilt append использует **нынешние** `current_record_refs` и `state_content_hash`. После продвижения lineage оба значения отличаются от подписанного append первого/второго receipt. Наши отдельные head-only и state-only substitutions тоже перестают совпадать с persisted receipt для обоих historical запросов; для current совпадение сохраняется. Обработка `ValueError` в `:432–437` выдаёт общий mismatch до crypto/lineage verifier.

**Семантическая оговорка:** historical intent прямо доказан для общего verifier и его typed result. Service protocol (`chronology.py:3200–3207`) не формулирует отдельное обещание historical SLA, но и не объявляет current-only ограничение. Service передаёт исходный request в exact receipt exchange, допускающий matching historical receipt, затем теряет исторический смысл при reconstruction. Поэтому доказан integration mismatch/availability defect, а не нарушение явно описанного публичного historical endpoint. Если owner намеренно ограничивает сервис current-only, это нужно выразить типизированным контрактом и доступным historical consumer, а не делать вывод о неверности сохранённой истории.

## Различающие controls

У всех трёх receipts:

- Чужой exact query отклонён `anchor_query_or_lineage_mismatch`.
- Подмена append state hash отклонена `anchor_query_or_lineage_mismatch`.
- Повреждённый signed statement blob отклонён `anchor_signature_unverified`.
- Удаление проверяемого historical entry из diagnostic lineage отклонено для первого и второго receipt. Этот adverse double использован только напрямую у verifier; production service не заменялся.

Service negatives: only-current selector, duplicate old selector, revoked issuer, wrong issuer role, foreign reconciliation, wrong predecessor, relabel-old-as-current дают `not_established`. Default provider без deployment оставляет обе роли `not_established`. Эти случаи не названы findings.

## Native wiring и пределы authority

Полный census 370 `src/polisyos/runtime/**/*.py` сохранён через `SOURCE_BINDINGS.json`; результаты поиска всех имён provider и обоих evaluation методов с internal aliases: `REACHABILITY.json`.

- `runtime/http/container.py:705,765–768` создаёт provider и повторно собирает его внутри выбранного deployment scope. Это source wiring, **не исполненный HTTP consumer**.
- `runtime/quality/epoch_custody_audit.py:104–105` содержит прямой operational evaluation call. Эта функция исполнена с реальными persistence/readback. Отдельный CLI `main` не запускался.
- Иных direct named calls evaluation methods в этом runtime census не найдено. Это текстовый, scoped census, не доказательство отсутствия любых динамических aliases или потребителей вне runtime.
- Не установлены live institutional appointment/independence, publication, claim revalidation, authority promotion, data leak, production incident, scientific correctness или complete native denominator.
- Holder/retention positive, external holder challenges, epoch policy owner и world/model-to-claim cascade не покрыты. Absent holder не превращён в положительную custody.
- Revocation проверена новым deployment owner. Никаких выводов о live hot-revocation ранее созданного owner.

## Среда и достоверность

Выбран Python 3.12.14; проект требует `>=3.14,<3.15`. Python 3.14 не найден в PATH. Pydantic 2.13.4 не соответствует declared `<2.13`; pytest отсутствует. Собственный native import завершился `SyntaxError` в `core/artifacts/store.py:2155`. Это environment blocker, не product finding.

Compatibility execution: **71 source module, 15 задокументированных адаптаций** (multi-except parentheses, `TypeVar`/`get_protocol_members` из typing_extensions), eager верхние initializers заменены namespace packages. Real Core facade сохранён. Не native/installed import, не locked-profile validation, не pytest, не release qualification. Ничего не устанавливалось; production source не исправлялся.

Первый запуск собственного probe остановился из-за ошибки reviewer harness: `AnchorAcceptanceLineageState` не экспортирован Core facade. Исправлен только импорт audit script на canonical `contracts.chronology`; traceback, exit 1 и hash первого script сохранены в `attempt01.*`. Повторный запуск exit 0; fresh и archive-reopen exit 0. Это не скрытый product failure и не заявление о broad pass.

## Что принимать и что остаётся

Принимать `custody::RC-01` только в указанном bounded смысле. Нового finding и security/authority эскалации не требуется. Исходный срез в основном честно ограничивает выводы; формулировку про намерение history у service следует читать с оговоркой выше.

Направление ремонта: resolve exact persisted append evidence у canonical owner либо reconstruct из immutable prefix с прежними query/predecessor/hash/signature checks. Не подменять historical query текущим и не ослаблять verifier.

Acceptance для будущего ремонта: оба historical exact queries и current через production-configured service; historical/current label сохранены, wrong/later query и corrupt/missing evidence rejected, fresh reopen из persisted bytes; отдельно native supported-profile run. Fix здесь не реализован.

## Повторение и freeze

Из корня `policyos_deep_audit`:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 next_review_custody_history/probe_independent.py
python3 next_review_custody_history/validate_review.py
```

Первый command регенерирует audit output и отменяет прежнюю freeze identity. Для read-only проверки поставки используйте только второй command. Для отдельного persisted replay распакуйте `public_fixture.tar.gz` во временный каталог и вызовите `probe_independent.py --reopen /temporary/path/public`; root paths rebased из этого каталога, private key не нужен.

`MANIFEST.json` связывает все review files кроме себя и `SHA256SUMS.txt`; `SHA256SUMS.txt` дополнительно связывает MANIFEST. `FREEZE.json` не повышает bounded evidence до native или global audit completion.
