# Независимая проверка data-service tests и calibration reuse

**Вердикт: PARTIAL.** Проверены `next_data_service_tests` и `next_calibration_reuse` на неизменённом `f1541ed155f278689be48a8c7ac56c3e200210f7`. DST-01, DST-02, CR-01 и CR-02 сохраняются в ограниченном виде. Новых defect families не добавлено. Product source, tests, configuration, исходные evidence lanes и external systems не изменены.

## Что меняет независимая проверка

1. **CR-01, P2: подтверждена потеря candidate numerical information, не обход authority.** Новые десять scale controls воспроизводят нулевую ширину/нулевой carrier при ненулевой представимой дисперсии, промежуточное расхождение carrier и interval, корректный обычный масштаб и истинный zero. Отдельно подтверждено binary64 absorption.
2. **CR-02, P3: подтверждён API-only дефект размерностей и семантики.** Семь новых линейных/constant-map controls отделяют входной std floor от выходного. Невязка сохраняется без upstream rounding. Нет установленного product caller или operational incident.
3. **DST-01, P2: сохранён checked-in qualification gap.** Source selection и fixture branches подтверждены, включая успешный modeled lifecycle и counterevidence: не все ошибки backend превращаются в skip. Hosted CI не запускался и не наблюдался.
4. **DST-02, P2: сохранён undeclared corpus input contract.** Exact marker inference подтверждает selection; исполнены реальный default ContextVar/accessor, path resolver и шесть independent single-file removal controls. Ни materialization, ни simulation не запускались.
5. **Уточнён dependency-profile limit.** Здесь Python 3.12 и Pydantic 2.13.4; pinned project требует Python >=3.14,<3.15, Pydantic >=2.12.5,<2.13 и pydantic-core==2.41.5. Поэтому даже успешные typed-reader controls не являются supported-profile pass. Точные версии находятся в `ENVIRONMENT.json`.

## CR-01: precision и reuse

Actual adapter прямо создаёт `UncertaintyEnvelope` после μ±zσ, не передавая numeric policy (`uncertainty_adapter.py:305–354`). IR default `FLOAT_ROUND_12` canonicalizes point, bounds и carrier parameters, но не `metadata.std` или covariance row (`uncertainty.py:546–568,1415–1437`).

Свежие controls:

- σ=10⁻¹⁵, 10⁻¹³ и 2×10⁻¹³ при μ=0 дают adapter width=0 и carrier std=0; covariance σ² и metadata остаются ненулевыми. Это не float underflow.
- σ=3×10⁻¹³ даёт width=2×10⁻¹², carrier std=0, metadata std=3×10⁻¹³. Поэтому «не дать ширине обнулиться» недостаточно для согласованного закона.
- σ=5.1×10⁻¹³ даёт carrier std=10⁻¹²; обычные σ=1 и 1000 сохраняют ненулевой согласованный масштаб в пределах заявленной round12 precision. Истинный σ=0 остаётся нулём. Не вся погрешность округления объявляется отдельным defect.
- μ=10¹⁶, σ=.01 даёт width=0 при carrier std=.01. Sibling helper явно отказывает: `binary64 cannot represent the nonzero Gaussian interval`.

**Counterevidence и граница reuse:** существующий `gaussian_uncertainty_envelope` удерживает ненулевую ширину на малом масштабе, выбирая `DECIMAL_EXACT`, но не создаёт `ParametricFitCarrier` вообще. При σ=3×10⁻¹³ он сохраняет round12 mode, потому что bounds ещё окружают point. Механическая замена adapter на helper не сохраняет закон и не закрывает intermediate carrier inconsistency. Следует расширить существующий owner общей проверкой carrier/interval/point representability и затем подключить adapter, сохраняя covariance, provenance и более строгий negative-std refusal.

`DECIMAL_EXACT` в этом коде означает «не округлять данное finite float», а не произвольную Decimal precision. Он не восстанавливает уже поглощённые binary64 bounds; helper правильно отказывает в таком случае.

## CR-02: tolerance не является unit-bound stochastic noise

Для affine map y=a·x математически σ_y=|a|σ_x. Exact-input controls не используют round12, а source branch вычисляет:

`max(|a| × max(σ_x, ε), ε)`.

Один ε берётся из входной numeric canonicalization policy. В первом max его сравнивают со std в единицах x, во втором с std в единицах y. Типизированного преобразования единиц или заявленного независимого output noise здесь нет.

- σ_x=10⁻¹³, a=10¹³: expected σ_y=1; ε=10⁻¹² даёт 10; ε=0 даёт 1.
- Эквивалентный вход σ=1 и identity map даёт 1. Это различает единицы представления.
- σ_x=1, a=10⁻¹³: expected σ_y=10⁻¹³; default ε даёт 10⁻¹²; ε=0 возвращает 10⁻¹³. Это отдельно выделяет **выходной** floor.
- Constant map a=0: exact output std=0; default ε даёт 10⁻¹²; ε=0 даёт 0. Вводимый floor не является propagated uncertainty этого map.

У этих линейных функций finite-difference derivative не вносит существенного alternative explanation; исходная формула и независимый linear oracle различают именно floor. Нелинейные maps, их derivative stability и нелокальная approximation validity не квалифицированы.

Все семь outputs переименовывают heuristic range в `deterministic_bounds` с `is_heuristic_ci=false`. Для identity N(0,1) source выдаёт [−2,2], вне которого математическая вероятность 0.04550026389635844. Это опровержение deterministic support claim, не empirical coverage study. Для constant map σ=0 детерминированная граница, наоборот, была бы уместной; нельзя обобщать semantic defect на любой map.

Полный literal census `src/polisyos/**/*.py` находит имя scalar API только в owning module: definition, stage-name metadata и export; вызовов не найдено. Это не исключает aliases, dynamic dispatch, внешних users или native consumers другой API. CR-02 остаётся P3 API-only, не production pipeline finding.

## Guard не исправляет численный дефект, но ограничивает его последствия

Свежий процесс прочёл все 28 retained standalone envelopes настоящим owner reader и сохранил `gate_eligible=false`; actual `envelope_meets_trust_policy` отказал во всех случаях. Вновь проверен valid-hash artifact, в котором только heuristic gate flag изменён на true: source DTO validation отказала. Positive eligible statistical envelope принимается тем же trust predicate, поэтому отрицательный результат не объясняется константно-false stub.

Установлен только конкретный guard: heuristic+gate=true и propagation сохранённого false. Это **не** полная проверка authenticity, всех способов forgery, genuine measurement admission, protection dispatcher или signed publication. Сам trust predicate проверяет eligibility и optional confidence threshold, а не реальность измерений. Никакого authority bypass эти controls не демонстрируют.

Retained 9 report replays и 36 covariance oracles исходной lane прошли read-only evidence validator; новые controls не повторяют Hessian estimation или Calibrator.run. Отдельно свежим reader проверены 28 envelopes, не выполнен новый full report regeneration run.

## DST-01: selection, fixture gate и hosted boundary

Source Standard Runtime HTTP запускает `tests/unit/runtime/http -m "not quarantine"`. Exact `_infer_primary_marker` возвращает `integration` и для обоих PG файлов, и для corpus file. Это не мешает HTTP job: его фильтр исключает только quarantine. Standard Integration исключает HTTP subtree, поэтому не является запасным PG lane.

Точная fixture DS9 требует `POLISYOS_DS9_REQUIRE_PG`, равный строке `1` после strip. Новые controls отличают `"1"`/`" 1 "` от `""`, `"0"`, `"true"`; whitespace-only DSN считается отсутствующим. Первая группа даёт fail, вторая skip. C57 по-прежнему делает собственный module skip при отсутствии своего DSN даже с DS9=1.

**Counterevidence:** существующая DS9 fixture уже умеет isolated schema и cleanup, сохраняет прежние PostgreSQL options при добавлении search_path. Новый полностью modeled success path доходит до yield и DROP SCHEMA. Unexpected setup exception и ошибка cleanup после yield распространяются наружу, а не превращаются в skip. Поэтому retained finding следует читать как «named missing-driver/DSN и caught connection/schema setup failures могут skip в optional mode», а не «все SQL failures игнорируются». Modeled driver не открывал sockets и не проверял SQL semantics.

Checked-in census всех 23 `.github` files не содержит двух test DSNs, DS9 flag, production_data или multi-tenant. Рекурсивное раскрытие внутренних extras для runtime profile даёт lint, test, runtime, runtime-http, observability, structured-logging; явного psycopg requirement среди них нет. Это **не** доказательство отсутствия любого transitive wheel или внешнего runner injection. Reference на psycopg в lockfile также не доказывает его установку выбранным profile.

Source inventory подтверждает 8 DS9 definitions и 3 C57 definitions, со статической параметризацией 2+1+2. Число 13 является source-declared case estimate, не свежим pytest collected denominator. Native collection, actual database versions/locks/races и successful hosted job UNRUN. Synthetic all-skipped JUnit и aggregate gate исходной lane подтверждают только report/gate control flow; их нельзя выдавать за green hosted CI.

## DST-02: actual path contract и tests

В `test_data_state_substrate.py` девять source definitions. Первый discovery test использует fixture registry. Другие восемь читают default production_data/registry/corpus, часть прямо вызывает материальный builder и Foundry compile/execute. Quarantine registry их не исключает. Source-level command/marker path выбирает файл; нельзя гарантировать, что hosted pytest дойдёт до bodies при unrelated collection/setup failure.

В новых controls исполнен default `_ACTIVE_CATALOG_SOURCE` ContextVar и настоящий `current_catalog_serving_source`, а не заменённый lambda accessor. Default=None; actual resolver получает шесть отсутствующих input paths и guard отказывает `production_data_path_missing`. Полный tracked tree не содержит production_data. В dedicated scratch положительный existence-only набор проходит guard; удаление каждого из шести файлов по отдельности даёт тот же typed missing-input refusal с точным именем path.

Scratch files намеренно не являются DuckDB/Parquet corpus. Никакой schema/cardinality/validity/simulation pass из их наличия не следует. L1/L5 registry и runtime source override также не квалифицированы actual data execution. Guard должен остаться fail-closed; blanket skip не закрывает gap. Ремонт: hermetic small real-store semantic lane плюс явно обеспеченная pinned-corpus qualification lane, без подмены 8-million-row claim маленькой fixture.

## Проверки, freeze и остаток

- `probe_review.py`: 10 precision cases, 7 unit/constant-map controls, 28 retained envelope reads; 5 DS9 flag cases, modeled successful fixture, unexpected/cleanup propagation, 2 C57 controls, 6 one-file removals и 4 taxonomy controls. Exit 0.
- Исходные read-only validators: calibration `validate_evidence.py --frozen` и data `verify_package.py`, оба exit 0. Выводы сохранены здесь, исходные lanes не перезаписаны.
- `INPUT_MANIFEST.json` привязывает все bytes двух входных lanes и executed external compatibility helper. `SOURCE_VALIDATION.json` сверяет exact source files с immutable Git tree. `CENSUS.json` содержит полные названные denominators. `SHA256SUMS.txt` покрывает все non-cache review files кроме себя и `FREEZE.json`; freeze связывает checksum file.
- Совместимость ограничена прежним in-memory syntax/TypeVar loader, namespace facades и exact identifiability DTO-only facade. Для AST extraction registry masking generic signatures применяется только для парсинга; выбранные тела, ContextVar, формулы и условия не изменены. Никаких fake numerical kernels или подмены gate predicate.

UNRUN: native Python 3.14 и locked dependency profile; штатный pytest/installed package; real PostgreSQL, S3 и Redis; DuckDB/Parquet corpus и >8m rows; real fit/Hessian/measurement authority; full Scientist/governance/protected action; hosted CI и deployment. Source review и bounded controls достаточны для указанных локальных findings, недостаточны для global readiness или завершения общего аудита.
