# Независимый review decision path и tenant custody

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Проверены `next_decision_path` и `next_tenant_custody`. Source и оба входных каталога не менялись. Review не запускал product code, native imports или исходные probes повторно: новые выполненные проверки относятся к bytes, provenance и независимому арифметическому пересчёту сохранённых входов.

## Решение сразу

- **DP-01: принять наблюдаемое поведение и bounded downstream effect; уточнить математическое основание semantic finding.** Нулевой явный welfare weight действительно превращается в 1; добавление двух нулевых utility contributions с положительными welfare weights меняет welfare −1 → +1, `baseline` → `proposal`, а извлечённый governance helper `needs_revision` → `approve`. Это не ошибка пересказа или арифметическая копия, выдаваемая за node: входы и результаты связаны с retained CAS bytes и настоящим source owner.
- **Оговорка существенна:** схема не определяет, является `welfare_weight` множителем отдельного term, единым stakeholder weight или независимой аддитивной массой социальной приоритетности. Zero-coefficient addition и splitting сохраняют utility, но **не сохраняют сумму заданных weights**. Поэтому поведенческая достоверность высокая; окончательная нормативная интерпретация формулы требует явного контракта. P2 можно сохранять как приоритет исправления/прояснения composition contract, не как независимо доказанный security severity или publication bypass.
- **Tenant custody: принять положительные bounded controls, без нового defect ID и без exploit claim.** Действительно применены full `ControlWorker`, SQLite owner и ambient-enforced filesystem CAS. Но полный `ControlPlaneService`, guarded dependency hop, authenticated admission и computation/terminal tail не исполнены.
- **Общий результат PARTIAL.** Source-backed evidence review проходит; native Python 3.14/locked environment, public authority и deployed isolation не квалифицированы.

## 1. DP-01: что установлено независимо

Source: `policy-engine/src/polisyos/scientist/nodes/builtins/governance/normative_arbitration_calculations.py:287–349,501–578`.

Для stakeholder s действующая формула:

`U_s = Σ_t sign(t) × coefficient(t) × Σ_binding value(binding)`

`W_s = Σ_t welfare_weight(t), если сумма > 0, иначе 1`

`social_delta = Σ_s U_s × W_s`.

Для исследованного `simulation_metric` resolver возвращает raw metric (`:128–134`); поле binding.weight не применяется. `welfare_weight` одного term поэтому умножает также utility других terms того же stakeholder. Explicit zero не сохраняется, когда сумма weights равна нулю. Число terms само по себе не является математическим параметром utility, но становится скрытым множителем при default weight 1 на каждом term.

Из hash-checked retained Trinity/Metrics JSON независимо пересчитаны восемь cases. `MATHEMATICAL_REVIEW.json` хранит и текущую формулу, и **условную** term-local альтернативу, не выдавая последнюю за подтверждённое авторское намерение:

| Case | Текущий результат | Term-local weighted sum, если это намерение |
|---|---|---|
| ordinary_negative | −1 / baseline | −1 |
| zero_effect_term_added | +1 / proposal | −1 |
| zero_effect_term_reversed | +1 / proposal | −1 |
| zero_weight | +1 / proposal | −2 |
| tiny_positive_weight | −1.999997 / baseline | −1.999997 |

У `ordinary_negative` и `zero_effect_term_added` individual utilities одинаковы: workers +1, owners −2. Меняется workers W=1→3. Перестановка terms не меняет результат. Сохранённый результат совпадает с журналом actual node, а selected option совпадает с fresh-reader output. Это не Pydantic coercion нулевого веса: в input canonical decimal остаётся `0`, замена на 1 происходит в aggregation owner.

### Контрпример к слишком сильной формулировке

Если добавить term с `coefficient=0` **и** `welfare_weight=0`, U и Σw останутся прежними; текущая формула не изменит −1. Это независимый математический контрпример, не новый product run. Если weights задуманы именно как независимая аддитивная entitlement mass, добавление положительной массы может быть осмысленным изменением социального выбора даже при нулевом utility term. Но такого контракта в проверенной schema/docstring и выбранных tests не найдено. Отсутствие документации не доказывает противоположное намерение.

Аналогично `split_equivalent_term` делит coefficient на три части, сохраняя weight 1 на каждой части; он меняет Σw в три раза. Decimal thirds также сохраняют utility лишь приблизительно при точной десятичной арифметике. Основной контрпример на двух zero-coefficient terms точный и от thirds не зависит.

**Самый сильный discriminator:** legal zero input `welfare_weight=0` даёт effective 1, а сколь угодно малое положительное значение сохраняется. `NonNegativeDecimal` допускает ноль, но нет описанного sentinel rule «0 означает default». Здесь ожидаемая обычная weight semantics нарушается наиболее прямо. Если авторы действительно хотят такой sentinel, его надо назвать и типизировать отдельно, а не молча использовать ноль одновременно как число и default.

### Что говорят существующие tests

`tests/unit/scientist/nodes/builtins/governance/test_normative_arbitration_calculations.py:87–102,198–207` проверяет по одному term на stakeholder с weights 1 и 3. Он совместим и с term-local multiplication, и с stakeholder multiplication, и с sum-weights законом. Поэтому он не разрешает спор о multiple-term semantics. Остальные три файла selected census полезны для ordinary selection, rights, persistence, schema rejection и governance, но не задают zero-weight/splitting law. Это выбранный тестовый набор, не полный тестовый denominator репозитория; pytest не исполнялся.

**Минимальный next step:** существующий owner должен явно определить axis/meaning weight. Затем добавить zero/tiny/positive weights, multiple binding refs, opposed contributions, weight-preserving term decomposition, term order и rights preservation. Не переносить арбитраж в MCDA без typed semantic adapter и не подменять welfare correction отказом от hard-right checks.

## 2. Governance effect не равен authority

`RunNormativeArbitrationNode` и `NormativeArbitrationPass` действительно исполнялись в compatibility profile. Reader использует целые определения `_resolve_governance_verdict`, `_apply_normative_verdict` и выбранного Phase2 verifier из pinned source. Это более сильное свидетельство, чем арифметический unit helper, но слабее полного `RunGovernanceNode` и protected attempt.

- `run_governance.py:667–726`: `proposal` может сменить промежуточный verdict на approve. При `reject`/`human_gate` precedence сохраняется; independent BLOCKER возвращает reject. Эти controls повторяются во всех 16 reader cases.
- Rights и budget violations отказывают. Budget на точной границе проходит. Missing metric / uncertainty остаются `partial`; выбранный Phase2 helper блокирует budget_missing и uncertainty_missing.
- Phase2 helper получает **synthetic** `composite_decision=promote` и шесть имён judges. Judges не запускались, их имена не свидетельствуют о валидном judgement.
- `run_governance.py:729–797` содержит отдельные claim-projection и applicable Phase2 boundaries; их наличие source-traced, а не доказательство полного закрытия любых обходов.
- `NormativeArbitrationResult` прямо говорит (`ir/analytics/normative_arbitration.py:192–200`), что record не предоставляет legal/institutional authority.

DP-O1 оставить scoped observation: нормативный node загружает legal report, но не использует результат для выбора. Malformed/blocker/missing legal reports не меняют показанную selection. Это не доказанный law bypass: независимый Lex/claim-level authority chain не исполнен. CAS input edge или provenance ref не означают, что юридическое содержание было принято как доказательство.

Synthetic policy имеет пустые interventions и нулевой placeholder source ref; численные metrics поданы как deltas. Это подходит для bounded composition differential, но не доказывает causal effect, grounded policy, admissibility baseline для любых level metrics или институциональную законность.

## 3. Tenant custody: реальные owners и честный seam

Проверенная цепь: synthetic creation scope → реальный serializer → `ControlPlaneStore.create_job` → SQLite event/outbox → свежий consumer process → весь `ControlWorker.dispatch_once` → live-lease admission → извлечённый `_process_control_job` → scope installer → enforced CAS payload read → sanitizer.

Положительные controls поддержаны source и логом:

1. Чужой ambient tenant/cell/AccessScope очищен; identity берётся из live lease и immutable creation envelope. Поддельный dispatch snapshot не заменяет payload pointer (`run_lifecycle.py:14920–14948`).
2. Payload чужого tenant, другого **полного** cell с совпадающим префиксом и claimed payload без scope не читаются.
3. Same blob / different selected manifest profiles действительно различаются. A-owned selected input write проходит, foreign selected input write отказывает. Это не только проверка blob hash.
4. Event/outbox mismatch и stable payload pointer drift дают production admission failure до payload-reader seam. Эти два jobs получают `failed`.
5. Unknown legacy scope не «восстанавливается» из ambient context; unclaimed payload до исследуемого boundary допускается с вычищенными caller identity claims.
6. Default filesystem Runtime factory добавляет enforcer (`dependencies.py:115–134`, `run_lifecycle.py:7294–7313`). Raw config-only factory removal-control без enforcer читает foreign profile: это причинный negative control, не tenant exploit.

### Ограничения, которые нельзя потерять при упаковке

- `Runtime._process_control_job_admitted` в probe является специально написанным reader/sanitizer seam. Он ловит исключение и только записывает observation. Production `_process_control_job_admitted` имеет иной полный error tail (`run_lifecycle.py:15146–15156`). Поэтому восемь fixtures остаются `running` и это **не** найденный lifecycle bug; success dispatch означает выполнение handler, а не successful workflow.
- Реальный `ControlWorker` стартует heartbeat thread, но быстрые cases не доказывают хотя бы один lease-renew pulse, lease loss/takeover или работающую долгую concurrency. Worker object реален; все его состояния не покрыты.
- Creator PID 9 и consumer PID 11 различны. Все десять cases проходят через **один** новый consumer process и отдельные roots, не через десять независимых restarts. Это reopen persisted owners, не crash recovery, process kill, multi-request overlap или second restart after writes.
- Fixture scope создан напрямую: `actor_authenticated=True` и роли сами по себе не являются authentication evidence. SQL mutation сделана только в audit fixture. External attacker control этого SQL не установлен.
- Variables `guarded`/`guarded_sql` в harness являются direct owners; Runtime `GuardedDependencyProxy`/ThreadPool hop не исполнялся. Missing `opentelemetry` и native Python mismatch честно сохранены; raw/enforced CAS не равно full guarded Runtime.
- Core CAS enforcer здесь действительно включён. Нельзя из seam limitation сделать обратное ложное утверждение, будто вся custody проверялась на mocks.
- Temporary SQL/CAS roots tenant-probe удалены после run. Сохранились full JSON observations, creator/consumer code, source bindings и stdout, но не исходные SQLite DB. Их повторный forensic read невозможен без rerun. Это слабее retained decision CAS; receipt/hash не заменяет отсутствующие bytes.

Это усиливает прежние положительные контроли `next_auth`/G06 и поясняет RR-03. Не создаёт новую уязвимость и не закрывает STATE-01/STATE-02, namespace migration, served-pack drift, remote backends или API-security acceptance.

## 4. Evidence hygiene и next acceptance

`verify_review.py` не исполняет и не импортирует продукт. Он проверяет все записи обоих input manifests, дополнительно binds все фактические input files, сверяет объединённый source readset с pinned Git blobs, пересчитывает arithmetic по canonical retained CAS inputs и сопоставляет fresh-reader/worker outputs. Self-manifest exclusions и не включённые в upstream manifest validation logs перечислены явно в `INPUT_BINDINGS.json`; они тоже включены в complete review input binding.

Первый запуск independent validator остановился на canonical float envelope (`{"_type":"float","repr":...}`), который reviewer decoder не разворачивал. Исправлен только reviewer decoder; исходная ошибка сохранена в `attempt01.*`. Это harness issue, не product corruption. Второй запуск выявил ошибочное предположение reviewer, что binding.weight уже умножается на metric. Source и retained `binding_zero` показали обратное: binding zero оставляет workers utility +3. Reviewer oracle исправлен под фактический resolver, ошибка сохранена в `attempt02.*`. Это дополнительное наблюдение о непрояснённом binding-weight contract, не новый defect ID и не часть доказательства welfare-weight fallback.

Следующие acceptance должны быть раздельными:

- **Arithmetic contract:** утверждённая weight semantics + distinguishing invariants на том же node → persisted consumer → governance composition.
- **Authority:** admitted causal/uncertainty/legal evidence и настоящий judges/protected attempt/claim publication; remove-one-binding controls.
- **Custody:** supported Python 3.14 + locked dependencies, authenticated route-generated scope, real Runtime guarded CAS/SQL hop, actual worker handoff; затем lease replacement, payload corruption, concurrent context reuse и terminal failure/success.

Никаких source fixes, внешних записей, установки packages, native pass или нового exploit в этом review нет.

## 5. Итоговая проверка и freeze

Final reviewer validation: **775 checks PASS**, 263 unique source files совпадают с pinned Git; bound 277 input files, включая complete trees обоих срезов и exact external `next_publication_authority/compat_loader.py`. В upstream manifests проверены 231 decision artifact и 32 custody artifacts; supplemental receipts дополнительно связаны полным review input inventory. Это counts evidence integrity, а не количество независимых semantic tests.

Команда из корня audit: `PYTHONDONTWRITEBYTECODE=1 python next_review_decision_custody/verify_review.py`. Final exit 0, stderr пуст. `FREEZE.json`, `MANIFEST.json` и `SHA256SUMS.txt` фиксируют review. После freeze reviewer не изменяет этот каталог и оба input trees. Повторный validator пишет только свои outputs; при повторном использовании freeze сначала нужно признать новую ревизию evidence, а не молча менять архив.
