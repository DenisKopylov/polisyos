# Независимая проверка persisted delivery chain / STATE-02

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Объект: `next_delivery_chain`, сопоставленный с prior `next_review_state`. Исходники и исходный пакет автора не изменялись.

## Вердикт

**STATE-02 принят, P2, высокая уверенность в локальном persisted-owner механизме.** Это усиление прежнего finding, а не два новых дефекта. Воспроизведение подтверждает premature acknowledgement originating HTE outbox после неполного generic invalidation. Соседний `mark_packet_trigger` разделяет тот же порядок dedupe-before-apply.

**Delivery invariant: FAIL. Native/full-engine/public-signature acceptance: PARTIAL.** Нельзя переименовать результат в штатный end-to-end HTE или опубликованную ложную policy signature. Модель угроз здесь fault/recovery correctness, не доказанный внешний security exploit.

На свежем independent SIGKILL control (-9), выполненном **после настоящей атомарной записи dedupe** и до fanout, новый процесс успешно подтвердил originating outbox при ACTIVE/ACTIVE и отсутствии обоих lifecycle events. Owner lock был отпущен ядром при гибели процесса; повтор действительно выполнился. Истечение TTL и последующий reconcile не восстановили потерянное событие. Новый логический event с другим ключом восстановил STALE/STALE: это потеря применённости конкретного события, а не необратимо испорченный CAS.

## Что проверено заново

1. Прочитаны исходные owners, их wiring, packet producer basis, CAS/SQLite операции, исходные probes и prior STATE-02 review.
2. Три авторских executable harness файла скопированы байт-в-байт в review-папку. Выполнен полный replay: **10 сценариев, 30 отдельных subprocess phases**. Один ожидаемый `os._exit(73)`; остальные 29 фаз успешны. Повторены четыре sibling/control сценария, включая существующую frozen-topic-page test function.
3. Дописан только внешний review harness `probe_review_controls.py`: **семь независимых controls**, в том числе реальный SIGKILL и fresh-process retry. Production code, repository tests, configuration и lockfiles не менялись.
4. Исходные bytes загруженных модулей/извлечённых функций и дополнительно просмотренные исходники сверены с pinned Git blobs. Исходный авторский artifact manifest проверен отдельно. Точные количества и SHA находятся в `REVIEW_VALIDATION.json`.
5. Штатный import повторён отдельно: установлен Python 3.12.14, Python 3.14 и source `.venv` отсутствуют. Import падает SyntaxError на `core/artifacts/store.py:2155`. Никакой установки или обращения к сети.

## Новая сила evidence относительно prior STATE-02

В prior review CAS evaluation storage и packet payload source были fixtures; acknowledgement originating HTE outbox был source-supported. В текущем пакете:

- `ControlPlaneStore` создан целиком на настоящей локальной SQLite schema. `create_job → lease_next_job → complete_job` выполняются настоящими методами, с реальным completion event и транзакционным outbox insertion. Обычный originating event не установлен прямым SQL INSERT.
- `FileSystemCAS`, `DecisionValidityService` и `_DecisionValidityStateStore` созданы целиком. Настоящие `register_decision_packet`, dependency registration, packet JSON, CAS baseline/evaluations, hash verification, file locking и atomic writes.
- Runtime `publish_decision_validity_event`, source request reconstruction, bounded reconciliation, queued-payload validation и `mark_outbox_published` реально исполнены. Runtime методы извлечены из pinned source, не переписаны как имитация.
- Основной fault/retry/force действительно открывает одну пару файловой CAS/SQLite из разных процессов. Результат не держится на surviving Python object state.

Это закрывает прежний runtime proof gap для самого ack в **compatibility-assisted persisted-owner chain**, но не для полной producer/HTTP/public-claim цепи.

## Fixture/seam, которые нельзя скрывать

1. **Loader не native.** In-memory multi-except parentheses и backported `TypeVar` сохраняют наблюдаемую локальную семантику, но package eager initializers заменены namespaces. Отсутствующие сторонние подсистемы не импортируются. Обычная constructor wiring всего `ControlPlaneService` и locked dependencies не квалифицированы.
2. **Runtime methods extracted.** Важно, что по наблюдаемой HTE legacy-event ветви они используют настоящие DTO и owners. Ветви monitor intake, full HTTP/auth и другие constructor collaborators не исполнялись. Извлечение не доказывает интеграцию всего приложения.
3. **HTE producer synthetic.** Schema-valid `DirectMethodExecutionSelection` создан неизменёнными конструкторами test fixture. Его HTE result/anchor/input refs не произведены и не разрешены в CAS. Поэтому принятие completion owner доказывает delivery boundary, но не происхождение научного результата.
4. **Targets generic/minimal.** Packet payload имеет настоящий envelope/baseline и настоящий CAS artifact, но не полный builder-produced DecisionPacket и не проверенную selected HTE association. Значение ACTIVE задано baseline, а при recompute у minimal payload нет typed completed-HTE basis для дополнительной проверки.

Последний пункт проверен различающим control: добавление синтетического typed HTE summary и неполной `completed_hte_*` basis приводит через настоящий `ensure_evaluation(force=True)` к **WARNING** с `completed_hte_dependency_basis_not_established`. Это показывает, что omitted producer metadata способно изменить точный конечный статус. Значит, `ACTIVE/ACTIVE` нельзя автоматически переносить на реальный опубликованный HTE packet. Вместе с тем пропавшие sticky/lifecycle events, ранний durable dedupe и преждевременный origin ack не становятся корректными от такого WARNING. Исправные полные producer inputs здесь не проверены.

Реальный builder регистрирует тот же `hte_completed_source_run:` dependency (`basis_sections.py:246–264`), а owner проверяет typed source association/refs (`decision_validity.py:2490–2615`). Это source-supported связь с продуктом, не завершённое producer e2e доказательство.

## Различающие результаты

| Сценарий | Retry / force | Оценка |
|---|---|---|
| Normal | STALE/STALE; один transition каждому | Позитивный control |
| Ошибка перед sticky write второго target | STALE/ACTIVE; force тоже STALE/ACTIVE; origin published | Подтверждён missing application |
| Ошибка после sticky write | Retry STALE/ACTIVE; force STALE/STALE, второй transition отсутствует | Существенный recovery контрпример |
| Ошибка перед CAS evaluation put второго | Аналогично post-sticky; force восстанавливает STALE | Нельзя говорить о любой permanent ACTIVE |
| `os._exit(73)` сразу после dedupe | ACTIVE/ACTIVE и после force; origin published | Авторский cross-process crash повторён |
| Independent `SIGKILL` после dedupe | Другой PID retry, ACTIVE/ACTIVE, notification active:2, origin published | Более сильный independent-process control |
| До dedupe | Retry STALE/STALE | Полный replay сохраняется до marker |
| Перед notification enqueue | Повтор заканчивает notification/ack, без новых transitions | Поздний failure recoverable |
| Перед originating ack | Notification reused, одна запись | Stable event/key работают |
| Malformed queued payload | Pending, payload_invalid, без notification | Строгий DTO guard работает |
| Source attempt mismatch | Pending, source_not_established | Exact SQL source fence работает |
| Валидный JSON с изменённым reason | Pending, payload_owner_mismatch, dedupe не создан | HTE payload binding работает |
| Corrupt dedupe JSON | Pending, без notification | Owner corruption fail-closed |
| SEMANTIC_EPOCH через generic route | Отказ до dedupe | Отдельный batch protocol не опровергнут |
| Direct `mark_packet_trigger` pre-write failure | Новая instance + force остаются ACTIVE, нет sticky | Тот же sibling mechanism; не cross-process тест |

Дополнительные review controls:

- **TTL и повторный reconcile после ack:** projection и recompute остаются ACTIVE/ACTIVE; reconcile возвращает 0, поскольку origin уже published. Истечение времени само по себе не возвращает потерянный event.
- **New key rescue:** настоящий generic event с новым ключом даёт STALE/STALE. Не следует говорить «исправление невозможно» или «любое будущее событие потеряно».
- **Changed payload / same key:** generic owner не отказывает, сохраняет первый event ID и возвращает прежние evaluations. Это повторяет prior finding о необходимости content binding. HTE outbox защищён отдельным exact-payload guard, поэтому arbitrary HTE payload injection отсюда не следует.
- **Live target drift:** после durable dedupe-only state третий target зарегистрирован настоящим owner. Retry сканирует текущие три targets и объявляет affected_packets:3 при ACTIVE/ACTIVE/ACTIVE, без events. Это показывает отсутствие frozen application denominator в generic owner; не доказывает, что любая поздняя регистрация по продуктовой temporal policy обязана получать старый event. В control dedupe-only state устанавливается реальным owner методом напрямую, отдельно от SIGKILL проверки.

## Root cause и существующие защиты

`scientist/validation/decision_validity.py:1950–1993`: generic event ID сохраняется в dedupe до fanout. Повтор не проверяет application receipt и не replay-ит event, а вызывает `ensure_evaluation` для текущего dependency index. `1995–2027`: `mark_packet_trigger` повторяет тот же протокол.

`2041–2110`: sticky/lifecycle state, evaluation CAS/state и transition записываются разными операциями. `_owner_transactional` берёт process/file locks (`490–517`), но не откатывает files. Atomic rename/fsync (`577–597`) защищает целостность **одной** записи, не атомарность нескольких packets и SQL ack.

`ensure_evaluation:1807–1840` берёт cached CAS evaluation в пределах TTL; после TTL/force вычисляет из payload + sticky state. Если event до packet write не дошёл, пересчитывать его не из чего. `read_current_projection:1842–1851` сам по себе TTL не проверяет.

Runtime `run_lifecycle.py:13883–13966` корректно строит request из completion owner, `14034–14095` корректно проверяет queued request. Но ни DTO, ни источник не свидетельствуют о completed fanout. `15393–15473` строит notification из полученных evaluations, после чего `14082–14088` помечает origin published. ACTIVE результат на dedupe retry не вызывает exception, ack становится успешным.

Строгий SQL source/queued-payload binding, CAS byte validity, semantic-epoch refusal и поздние retry protections действительно существуют. Они не заменяют durable per-target application completeness. Отдельный epoch pending overlay нельзя автоматически переносить на generic branch.

## Реальные последствия и неустановленные последствия

**Прямо наблюдалось:** после одного локального failure исходное invalidation событие не попало в часть зарегистрированных targets; cached/current owner projections и CAS evaluations сохранились в ACTIVE; SQL notification корректно описала active targets как affected; исходный pending row стал published и перестал выбираться для retry. В post-sticky сценариях STALE восстанавливается compute, но transition receipt второго target не восстановился.

**Обоснованный риск:** generic invalidation может перестать быть eventually applied после crash/retry; downstream читатель старой owner projection может продолжить видеть прежнюю текущесть. Это P2 consistency/recovery проблема, достаточно важная для исправления canonical owner.

**Не доказано:** неверная реальная опубликованная policy signature, bypass publication gate/authorization, конкретный production incident, remote exploit, число затронутых production targets, PostgreSQL/distributed correctness, power-loss durability, полная RunIndex/API projection, полный штатный HTE producer. Notification здесь запись локального SQL outbox, не внешняя доставка пользователю.

## Минимальное направление исправления / acceptance

Сохранить один canonical Scientist owner. Нужны durable received/pending/applied state, content binding, устойчивый target denominator и idempotent per-target replay. Generic projection должна учитывать незавершённое применение, а originating ack зависеть от завершённого durable результата. Просто перенести dedupe write в конец недостаточно: partial replay, transition duplication, changed payload и target drift остаются.

Закрывать finding следует штатным Python 3.14/locked запуском с реальным bounded selected HTE source и builder-produced targets, теми же failure points, fresh process, owner reader и конечным RunIndex/API consumer. Добавить CAS corruption controls и двустороннюю проверку origin/notification state; full publication claim проверять только с настоящим authority chain. Пройдённые controls не являются product acceptance.

## Воспроизведение

Из этой папки:

- `PYTHONDONTWRITEBYTECODE=1 python probe_delivery_chain.py`
- `PYTHONDONTWRITEBYTECODE=1 python probe_sibling_controls.py`
- `PYTHONDONTWRITEBYTECODE=1 python probe_review_controls.py`
- `python validate_review.py`

Сохранены stdout/stderr и exit codes; fault stderr ожидаем. Первая попытка review control использовала default CAS canonical profile для HTE floats и корректно получила `CanonViolation: float forbidden in canonical JSON`. Затем для этого единственного synthetic packet применён тот же `CanonSpec(forbid_floats=False)`, что у реального builder (`builder.py:586`). Исходный error сохранён в `review_controls.attempt01.*`; это harness setup error, не product finding. Рабочие CAS/SQLite были временными и удалены после запуска; executable probes и полные deciding outputs сохранены. Source, исходный audit evidence и внешние системы не менялись.
