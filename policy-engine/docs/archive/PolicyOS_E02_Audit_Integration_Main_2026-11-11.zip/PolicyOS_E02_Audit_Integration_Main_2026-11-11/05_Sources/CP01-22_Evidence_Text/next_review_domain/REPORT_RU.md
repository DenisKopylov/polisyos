# Независимая перепроверка domain composition

**База:** `f1541ed155f278689be48a8c7ac56c3e200210f7`. Проверены выводы `next_domain_composition`; исходники и чужие артефакты не изменялись. Это независимая проверка интерпретации, exact-source tracing и новые различающие контроли. Базовый source-extraction loader повторно использован, поэтому совпадение replay не считается независимой native реализацией измерителя.

## Решение

**DC-01 сохраняется как medium semantic compilation defect с высокой уверенностью в механизме.** Два независимых положительных statements действительно превращаются в один несовместимый набор facets; до candidate ledger теряются три реально существующих seed rules. В graph-derived части входа resolver исчезают семь constructs. Исполняемый контроль с настоящим `build_seed_obligation_rule_catalog()` и `logic_hash_for_rule()` воспроизводит потерю, исключая synthetic rule wrapper как объяснение.

**DC-02 сохраняется, но строго как loss of explicit identification semantics в emitted grammar facet.** Нельзя превращать его в доказанный выбор неправильного estimator, отсутствие readiness checks, повышение scientific authority или публикацию. Новая проверка делает эту границу конкретнее: все шесть значений `method_need` реальный downstream claim-family classifier относит к `context_only` и не назначает им method preconditions. Следовательно, одной коррекции `_method_need` недостаточно для доказанного переноса исходного ограничения до method requirement.

**Обход authority gates не установлен.** Проверенный owner `compile_obligation_basis` отказывается создавать graph для `candidate_unverified` и `blocked`; runtime и Lex независимо сохраняют missing authority. Уверенность в конечном operational impact обоих проявлений остается ограниченной. Это не два новых security/SYS семейства и не evidence of clinical/financial validity.

## 1. Что усилено и что нужно скорректировать

1. Оригинальный `results.json` воспроизведён побайтно. Затем новые эксперименты использовали реальный каталог из **77 rules**, а не hand-built adapter rows с synthetic version/hash. Результат DC-01 не изменился.
2. В исходном probe одиночные cases имели разные domain labels, joint — CUSTOM. Новые контроли держат label постоянным: HEALTHCARE для всех, FISCAL для всех, CUSTOM для всех. Во всех трех группах исчезают те же **3 rules / 7 constructs**. Проблема не вызвана выбором CUSTOM.
3. Новый reverse-text контроль передает обратный порядок и grammar, и obligation graph. В исходном probe graph для joint_reverse получал обычный порядок текста. Для текущих substring predicates это не меняло результат, но новый контроль снимает неточность постановки.
4. «Семь потерянных требований DataRequirementCompiler» следует писать **«семь отсутствующих graph-derived constructs без явных declarations»**. Реальный `_construct_resolution_inputs` объединяет graph constructs, explicit profile declarations и declarations внутри facet/claim records. Контроль подтверждает: явное добавление семи constructs восстанавливает весь набор из десяти; добавление тех же строк только как candidate proposals не восстанавливает required denominator.
5. Формулировку «point/sequential сохраняются» нужно ограничить исходным fixture. `point_identified + rollout` дает `sequential`; все четыре не-point/non-sequential режима с rollout тоже дают `sequential`. Это не универсальное сохранение point и не только default-to-point bug: ограничение замещается приоритетным scalar mode без typed conflict.
6. Текстовый census подтверждает потенциальный public API путь, а не production execution. В `src/polisyos` найденные реальные constructor sites подают text либо ProblemFrame, а не PolicySpec. Прямой typed PolicySpec вход предусмотрен API и проверяется существующим unit test только для SEQUENTIAL; идентифицированная потеря остальных explicit modes не доказана на штатном runtime caller.
7. Наличие observation guard не следует называть сохранением исходного InterventionSpec mode. `IdentificationModeRouter.route_record` читает режим **ObservationRecord**, а не данное поле policy intervention. Это независимый носитель/контур, который может ограничивать исполнение; его успешное взаимодействие с этим case не проверено.

## 2. DC-01: причинный контроль, а не совпадение counts

Источник информации: `policy_grammar/_impl/normalizer.py:38–97` складывает text, ProblemFrame и все interventions в один token stream; информация о component identity не переходит в один `UniversalPolicyFacets` (`core/contracts/runtime.py:584–616`). Selectors в `facets.py:198–356` последовательно выбирают по одному instrument, channel, funding, risk, population и geography. Это classification по приоритетным token matches, а не composition algebra.

В конкретном positive-additive fixture joint сохраняет service от healthcare, credit_registry/concessional_credit/MSMEs от fiscal и rural/equity_harm от healthcare. Составная программа не отменяет ни одно из двух действий. Ожидание сохранения требований именно здесь разумно и согласуется с multi-intervention контрактом (`PolicySpec`, `policy_spec.py:209–247`) и repository North Star. **Не заявляется закон, что union обязателен для любой композиции**: общие меры, отмена, override или изменение scope могут законно менять obligations. В данном тексте таких отношений нет; unsupported/conflict limitation также не выдана.

Exact rule matching происходит до ledger: `obligation_graph/_impl/compiler.py:110–137,217–350`. Поэтому потерянные rules не являются deferred entries, suppressed candidates или последствиями budget sorting. Оригинальные high-budget и budget=8 результаты воспроизведены; оба сохраняют потерю. Дополнительно настоящий catalog проверен с ровно штатным ComplexityBudget(max_frontier_items=8), без увеличения других лимитов: те же семь constructs отсутствуют, все frontier counts равны 8, deferred entries сохранены.

Потеря:
- `obligation.data.vertical_credit_program_registry`;
- `obligation.data.vertical_service_delivery_registry`;
- `obligation.fiscal.contingent_liability_portfolio_risk`.

Новые counterfactual input controls на **том же native source matcher**:
- Изменить только joint instrument на credit: возвращается ровно credit registry rule; новые constructs — credit_program_enrollment и program_participation_rate.
- Изменить только delivery на public_service: возвращается ровно service registry rule; новые constructs — public_service_payment, service_quality_indicator, provider_network_capacity.
- Изменить instrument на credit и risk на budget_feasibility: возвращаются credit registry и contingent liability rules; дополнительно возвращаются fiscal_burden_per_beneficiary и risk_score.

Это экспериментальные изменения входных facets, не production patch и не предлагаемое исправление: переключение одного общего scalar все еще теряет другую часть программы. Stacked-facet контроль из исходного отчета корректен как **предупреждение против наивного ремонта**: structured matcher строит last-wins dict по facet_type (`:313`), а data scope selector делает похожую проекцию (`data_requirement/compiler.py:2273`). Он не доказывает существование штатного caller, который уже складывает scoped facets таким образом.

После projection нужен не только восстановленный общий union strings: component population/geography/time/instrument bindings должны остаться корректными. Иначе даже полный construct list может быть запрошен для чужой популяции. Новая проверка не закрывает этот scoped end-to-end критерий.

## 3. Denominator и реальные consumers

`_required_constructs_from_obligation_graph` (`data_requirement/compiler.py:1648–1685`) читает blocking frontier metadata. Без явных additions joint возвращает firm_survival, credit_access, employment_count; union отдельных cases содержит десять constructs.

Но конечный required input set задает `_construct_resolution_inputs` (`:1608–1645`), вызываемый настоящим `compile_for_claim_ledger` (`:418–433`). Новые execution controls на exact helper bodies:
- baseline: 3 required constructs;
- те же 7 строк как candidate proposals: по-прежнему 3 required;
- те же 7 как declared_constructs: 10 required;
- те же 7 как explicit claim required_constructs: 10 required.

Это подтвержденная compensating возможность, а не доказательство автоматической компенсации. Textual discovery может предложить credit_program_enrollment, но proposals сознательно не становятся resolver authority. Произвольный explicit construct list также не доказывает grounding/scientific validity.

Статический достижимый путь DC-01:
- `DataRequirementCompiler.compile_for_scenario:620–710` принимает text, компилирует grammar, настоящий seed catalog и graph, затем claim ledger и `compile_for_claim_ledger`.
- `runtime/quality/scenario_evidence_contract.py:169–205` и `generation_cycle.py:14027–14060` вызывают этот scenario compiler.
- `compile_obligation_basis:573–618` вызывается `runtime/quality/workspace/foundry_consumption.py:1254+`, используя ProblemFrame.

В этих helper owners нет обнаруженного восстановления отсутствующих rules путем component decomposition. Это не означает отсутствия любых независимых critics/declarations во всей системе. **Full scenario resolver, persisted capability index, actual query/spec output и final consumer execution не запускались.**

## 4. DC-02 и downstream weakening гипотеза

`InterventionSpec.identification_mode` допускает весь `IdentificationMode` (`policy_spec.py:106`; `ir/observation/contracts.py:77–96`). Normalizer собирает значения (`normalizer.py:75–76,93`), но `_method_need` (`facets.py:288–293`) проверяет только SEQUENTIAL и rollout-like tokens; иначе возвращает POINT_IDENTIFIED. Отдельный `UniversalPolicyMethodNeedFacet` сам использует полный enum (`runtime.py:552–556`), поэтому технического запрета на сохранение bounds/proxy/etc нет.

Новый прямой контроль создает настоящий `NormalizedPolicyIntent`, без PolicySpec-shaped collaborator, и вызывает exact `_method_need`:
- point → point, sequential → sequential при отсутствии rollout token;
- partially/bounds/proxy/interference → point;
- любой из шести modes + rollout → sequential;
- bounds + sequential → sequential;
- proxy + interference → point.

Этим снята зависимость локального selector вывода от synthetic PolicySpec validation, но **не** закрыт полный native PolicySpec acceptance. Input mode здесь реально присутствует в normalized contract, а затем теряется.

Exact downstream controls: `scientist/policy_design/claim_decomposition.py:539–564,602–645` для каждого method_need enum дает `context_only`, factual, context-only use, пустые method needs. `MethodValidityRequirementCompiler` работает с самостоятельными claim needs/tokens (`method_requirement/_impl/compiler.py:29–140,304–317`), а не просто присваивает method facet final estimator class. Исходный положительный контроль partial_identification → bounds остается корректным.

Следовательно, **исправление одного scalar emission может оставить дополнительный разрыв передачи ограничения**. Для принятия решения о ремонте нужен тест: исходный explicit mode → component-scoped claim → MethodValidityRequirementSpec → настоящий selector; удаление/замена explicit mode должно менять требование или давать typed отказ. Этот review не объявляет такой разрыв новым независимым SYS finding и не утверждает конечное unsafe execution.

Дополнительная контрдоказательная граница: observation measurement router (`ir/observation/measurement.py:515–593`) обрабатывает explicit mode из observation record, а blueprint release (`scientist/governance/blueprint_release.py:725–733`) имеет отдельное снижение tier для bounds/proxy. Наличие таких механизмов опровергает широкую формулировку «система везде превращает ограничения в point», но не лечит потерю конкретного grammar input.

## 5. Authority: проверенное и непроверенное

Новый контроль exact `DataRequirementCompiler.compile_obligation_basis` с реальным catalog builder:
- deterministic valid input: compiled, graph существует;
- LLM input: candidate_unverified, graph отсутствует;
- unclassified input: blocked, graph отсутствует.

Этот тест исполняет source method с инжектированными зависимостями, не весь класс/package. Исходный guard/default profile контроль верен: default authoritative_for только compilation_facets (`runtime.py:434–448`); authority slot checker отказывает data/method/legal purpose без allowance (`consumer.py:74–88`). При этом helper `require_compiled_universal_policy_design_case` сам проверяет blocked/no facets, **но не** candidate_unverified. Утверждать, что каждый низкоуровневый helper блокирует candidate, нельзя. Проверенный runtime owner делает отдельный правильный status guard (`compiler.py:596`); обхода реального owner не показано.

Статически подтверждены сохраненные barriers:
- `foundry_consumption.py:1251–1253`: прочтение source bytes не устраняет missing source authority;
- `:1430–1457`: missing method → block; satisfied selection → limit, не scientific validity;
- `lex/normpack/legal_authority.py:425–444`: missing qualified claim/source relation сохраняется независимо от заполненных norm fields.

Это конкретные guards на найденных путях, не общее доказательство безопасности всех consumers. Legal rule requirements, in-memory rule extensibility, candidate visibility и IDs остаются техническими свойствами; admission новых rules, source standing, scientific justification и publication не были проверены.

## 6. Evidence и ограничения исполнения

Команды:
- `PYTHONDONTWRITEBYTECODE=1 python policyos_deep_audit/next_review_domain/review_probe.py`: финальный exit 0; результаты в `review_results.json`, stdout в `review.stdout.json`.
- Native import `from polisyos.policy_grammar import PolicyGrammarCompiler` с PYTHONPATH на source: exit 1, Python 3.12 останавливается на поддерживаемом проектом Python-3.14 except syntax в `core/artifacts/store.py:2155`. Это environment incompatibility, не product test failure. Полный trace сохранен в `native.stderr.txt`.
- Первая попытка нового измерителя упала из-за неинжектированного `_stable_json_bytes`. Добавлен точный helper из source; product code не менялся. Исходный traceback сохранен в `review.initial.stderr.txt`; не скрыт как продуктовый отказ.

Python/Pydantic профиль по replay: 3.12.14 / 2.13.4, не contributor lock. Original imports заменены namespace dependencies, ряд optional IR типов — Any, canonical refs synthetic. Exact selector, matcher, catalog builder/hash, owner method и denominator bodies исполнялись без изменения. 23 исполнявшихся source paths сопоставлены с baseline SHA-256; дополнительные статически проверенные source/test files перечислены в `source_validation.json`. Git HEAD соответствует f1541ed, tree чистый. Все predecessor files имеют прежние hashes.

Существующий `tests/unit/policy_grammar/test_universal_policy_grammar_compiler.py` содержит три раздельных текста и один typed PolicySpec с SEQUENTIAL. Он дает полезное описание supported API, но прочитан, **не запущен**; проверка не объявляет отсутствие других тестов во всем репозитории. Native tests, installed/API/UI, CAS reopen, clinical/financial validation, source admission, method execution и publication остаются UNRUN.

## Acceptance следующего шага

В поддерживаемой locked среде сравнить отдельные и combined typed multi-intervention PolicySpecs: grammar → complete candidate/bundle/frontier/deferred sets → scoped claim ledger → full construct resolver inputs/specs → actual consumer. Сохранить компонентные population/time/geography bindings. Добавить semantic removal controls для одного компонента, явного identification mode, source proof и scope. Допускать явное unsupported/conflict limitation; не принимать молчаливый hybrid compiled output за завершенную композицию.

**Итоговая оценка:** bounded semantic findings подтверждены с уточнениями; full native/operational acceptance — PARTIAL, не PASS.
