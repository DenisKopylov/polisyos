# Независимый review EC-01 / EC-02

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Область: frozen `next_evidence_composition`, точные consumers и модели. Итог: **PARTIAL; оба локальных semantic findings сохраняются. Production exploitation, source admission, scientific validity и authority bypass не установлены.** Новых SYS-семейств: 0. Production source и repository tests не менялись.

## Результат раньше деталей

- **EC-01 подтверждён** новым reviewer-authored control с настоящими strict ClaimRecord и ClaimLedger. Разные facet IDs/refs не помогают: scopes обоих claims становятся scope последнего набора. Interleaving даёт ещё более точный discriminator: population B + geography A + time B, то есть комбинацию, которой нет ни у A, ни у B. Это дефект claim-bound semantic compilation, не доказательство применения неверных данных к опубликованной политике.
- **EC-02 подтверждён с уточнением причины.** У двух независимо связанных causal obligations сохраняются разные method facet refs, но значение ограничения не становится method precondition. Method compiler выдаёт четыре point requirements. Настоящий typed MethodNeedPrecondition `partial_identification` даёт bounds. **Сам context_only не является запретом на method requirements:** при том же explicit precondition даже context-only claim создаёт bounds requirement. Корень: потеря semantic binding, а не один лишь family label.
- **Native whole-PolicySpec path не проверен.** Повторный native import на Python 3.12.14 останавливается на Python 3.14 syntax в `core/artifacts/store.py:2155`. Поддерживаемый Python 3.14 не найден в PATH. DTO и compilers исполнялись через явно ограниченный source loader, не через штатные imports. Полная typed ClaimLedger/ClaimDecompositionInput модель не равна native PolicySpec → persisted consumer E2E.

## 1. Независимость и deciding checks

Author подтвердил freeze до reviewer replay. Сохранён AUTHOR_FREEZE.json. Исходный probe скопирован без изменения байтов в reviewer directory; его fresh replay exit=0, results.json byte-identical с frozen author result. Затем отдельный reviewer-authored `probe_independent.py` использовал только frozen setup точных source definitions и свои входы/проверки.

Пять критериев RUBRIC.json: source identity; scope preservation; typed context/method semantics; runtime gates/authority; fresh discriminating controls. Первые четыре установлены на указанной глубине. Полная production/runtime qualification отсутствует, поэтому общий итог не PASS.

Два первых reviewer запуска отказали на обязательных полях тестового входа: ClaimRecord требует support_status/publishability/readiness_level, MethodNeedPrecondition требует reason. Ошибки сохранены; исправлены только reviewer inputs, продуктовые validators не менялись. Финальный independent run exit=0.

## 2. EC-01: подтверждён, operational reach ограничен

**Root:** `data_requirement/compiler.py:415–439,1257–1274,1443–1474,1608–1645,2249–2294`.

Вход: два strict claims с одинаковым explicit required construct `firm_survival` и разными triples population/geography/time. Mapping family и refusing resolver синтетические. Resolver возвращает blocked, не действительную capability.

Наблюдения:

1. `A_then_B`: один query; оба specs получают urban_msmes / region_B / 2027.
2. `B_then_A`: один query; оба specs получают rural_microfirms / region_A / 2026.
3. `hybrid_interleaving`: один query; оба specs получают urban_msmes / region_A / 2027.
4. `only_A_scope`: scope A сохранён. `only_A_claim_global_AB`: при удалении B claim, но сохранении B facets A получает B scope.
5. `_facets_for_claim(A)` правильно выбирает только A; `_scope_from_facets(selected_A)` правильно даёт A. Но `dict(global_index).update(selected_A)` не переставляет существующие ключи. Следующий last-by-type comprehension снова выбирает глобально последний facet каждого типа.
6. Explicit named scope profile переопределяет population и jurisdiction, а query time window использует explicit interval. Это рабочий положительный control, но он выражает один общий профиль, не сохраняет разные claim scopes; spec geography/time остаются B в данном примере. Это не самостоятельное утверждение, что общий профиль должен уступать claim facets.

Механизм имеет два разных места потери: queries вычислены до цикла claims и dedupe constructs игнорирует scope; spec construction повторно использует global scope index. Исправить только dict.update или только query count недостаточно. Привязка query/spec к полному semantic key либо явный отказ от unsupported composition нужна существующему owner.

**Достижимость:** публичный compile_for_claim_ledger принимает этот input и выполнен целиком. Strict ClaimRecord/ClaimLedger не отвергают distinct scopes. Но реальный UniversalPolicyFacets (`core/contracts/runtime.py:582–613`) имеет по одному scalar facet каждого типа. `compile_for_scenario` (`compiler.py:617–708`) создаёт один envelope; найденные direct source callers compile_for_claim_ledger находятся внутри compiler. Штатный producer двух независимых scope triples пока не показан. Параметры reviewer scope здесь разрешены generic Mapping API, а не выдаются за controlled W6.A scalar vocabulary.

**Counterevidence:** Catalog projection без profile отказывает; query/index mismatches и обязательный отсутствующий resolver отклоняются; missing result остаётся not_established. Наличие blocked binding может позволить compiled requirement basis=established, но это не successful source admission. Не считать basis, draft claim, synthetic refs или typed acceptance authority.

**Disposition:** retain, medium semantic correctness, high mechanism confidence; operational impact not established. Security vulnerability/exploit не подтверждены.

## 3. EC-02: точная связь context и method

**Root:** `scientist/policy_design/claim_decomposition.py:195–263,448–482,539–561`; `method_requirement/_impl/compiler.py:213–233,255–316`.

Reviewer input: настоящий ClaimDecompositionInput с двумя компонентами. У A method_need=bounds_only; у B method_need=point_identified. Каждый causal obligation явно ссылается только на свои effect/method facets. Полный decomposition создаёт strict ClaimLedger с четырьмя causal claims и двумя context-only method claims.

- Causal claims несут precondition `causal_identification`; даже causal obligation с facet_refs=[effect:A, method:A] не получает `partial_identification` либо иной equivalent restriction.
- Method compiler читает текст, family/type/use, metadata и method_need_preconditions самого claim. Он не получает facet store и не разыменовывает facet_refs. Разные refs сохраняются как provenance, а не как исполняемое semantic binding.
- Bounds value остаётся в тексте самостоятельного context-only claim. У него нет method preconditions, поэтому именно этот claim не создаёт requirement.
- Четыре полученных requirements имеют class=point. Указание bounds в description causal obligation меняет лишь его requirement на bounds, не effect claim. Это lexical control, не корректная remediation.
- Прямой **strict typed** precondition c reason, claim_id, method_need=partial_identification и facet_refs=[method:A] даёт bounds. Такое же precondition на context-only claim тоже даёт requirement класса bounds. `_claim_requires_method_requirement` проверяет наличие method needs раньше family/type.
- Empty candidate methods дают missing/fail; invalid obligation facet_ref отвергается реальным ClaimDecompositionInput.

**Что значит «в полной модели»:** исходники реального PolicySpec/InterventionSpec допускают отдельное identification_mode у каждого intervention; validators сохраняют IDs и связи, но не переводят mode в claim preconditions. normalise_intent собирает modes в tuple, а W6.A `_method_need` сохраняет только sequential, иначе point. Это предыдущий DC-02 seam. EC-02 reviewer input намеренно counterfactual: correct typed method facets уже доступны downstream. Он показывает, что одного ремонта upstream scalar недостаточно. Он **не** доказывает, что native PolicySpec(bounds_only) на сегодня достигает EC-02 с сохранённым bounds facet, либо что runtime выбирает/исполняет point estimator.

**Не переобобщать:** proxy_identified, interference_aware, sequential и MethodIdentificationClass используют разные измерения контракта; они не обязаны все быть non-point. Самый сильный discriminator здесь bounds_only / partially_identified против point, плюс потеря привязанных mode constraints. Arbitrary context mention нельзя автоматически повышать до нормативного ограничения для всех claims.

## 4. Runtime consumers и сохранённые границы

`runtime/quality/workspace/foundry_consumption.py` действительно строит typed decomposition (:1324–1354), persist ledger, вызывает methods compiler (:1396) и selector (:1421). Этот producer использует ProblemFrame, не PolicySpec, и не даёт explicit per-obligation facet refs: decomposition fallback включает весь envelope. Поэтому это доказательство реального consumer seam, но не producer witness для mixed PolicySpec modes.

- После разрешения bytes источник всё равно имеет `constraint_source_authority_verification_missing` (:1251–1253).
- Отсутствие frontier не подменяется fabricated obligation (:1321–1323).
- Полный набор requirement statuses сверяется (:1426–1440).
- `missing` → block, `satisfied` → limit с явной непроверенной independent method validity (:1441–1457).
- `IdentificationModeRouter` является отдельным observation owner; его existence не доказывает ни защиты всех claim paths, ни обхода observation checks. В этом review routing не исполнялся.
- Frozen author selector controls и fresh independent empty selection показывают fail при отсутствии методов. Это не доказательство отказа для любого malformed supplied candidate и не замена реального execution evidence.

## 5. Что осталось до operational qualification

1. Поддерживаемый Python 3.14 и native imports без source extraction.
2. Реальный typed multi-intervention PolicySpec → grammar/decomposition, включая scopes, modes и точную ссылочную связь. Сравнить current lossy path с counterfactual downstream contract, не смешивая их.
3. Два persisted capability scopes одного construct через настоящий resolver, затем actual consumer admission с полной provenance.
4. Strict method need перенос и реальный методический consumer с independent validity evidence; проверить, какие отдельные observation/authority gates блокируют ошибку.
5. Persist/reopen и публикация/protected output только при отдельной проверке этих границ. Текущие результаты не позволяют утверждать их достижение.

Remediation здесь не выполнялась. Required acceptance controls: отдельные/совместные components, permutation и interleaving, удаление только claim и компонента, invalid references, declared common profile против independent scopes, bounds/partial mode bindings, explicit precondition versus unrelated context, no-source/no-method negatives.

Полные результаты: INDEPENDENT_RESULTS.json, replay results.json, SOURCE_EVIDENCE.json, REVIEW.json. Источник авторского результата: ../next_evidence_composition/REPORT_RU.md; freeze fingerprints сохранены отдельно.
