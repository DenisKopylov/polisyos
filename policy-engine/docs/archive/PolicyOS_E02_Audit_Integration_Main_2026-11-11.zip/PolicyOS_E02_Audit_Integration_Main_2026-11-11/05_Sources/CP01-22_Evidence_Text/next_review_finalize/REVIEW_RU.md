# Независимая проверка STATE-01: bounded finalize chain

## Вердикт

**STATE-01 / P2 подтверждается.** На snapshot `f1541ed155f278689be48a8c7ac56c3e200210f7` durable finalize journal не сохраняет выбранный workflow transition. После настоящего SIGKILL до terminal append recovery публикует проверенный RunManifest, но теряет exact selected input. Строгий Runtime consumer возвращает `None` вместо final ExperimentState **ref**. Это потеря доступности/currentness evidence, не authority bypass и не доказательство неверной публикации политики.

**Evidence review: PASS в заявленном узком профиле. Product recovery: FAIL. Native Python 3.14 / full sync+async workflow / authenticated HTTP: PARTIAL, не исполнены.** Новый finding ID не добавлен. Исходники, tests, зависимости и рабочий проект не изменены. Audit harness и данные созданы только в этой review-папке.

## Независимо выполнено

`PYTHONDONTWRITEBYTECODE=1 python next_review_finalize/probe_review_finalize.py` повторяет десять ограниченных случаев в новых audit-owned каталогах; exit 0, все 46 новых assertions выполнены. Это не повтор всей исходной wave и не десять native integration tests. Повторно используется проверенный compatibility loader и upstream fixture из `next_finalize_chain`; самостоятельный reviewer определяет матрицу, ожидания, assertions, consumer identity controls и source binding.

1. **Scoped normal:** exact selected receipt и final-state ref возвращаются. Consumer не является constant-None fixture.
2. **Scoped multi_after_journal:** настоящий SIGKILL, две workflow receipts в manifest outputs, новый recovery, новые Core/Runtime readers. Core manifest проверен, selection и final-state ref отсутствуют. Нельзя угадать переход по наличию receipt в outputs.
3. **Scoped after_terminal:** SIGKILL после terminal append. Recovery сохраняет exact selection и final-state ref. Дефект зависит от границы persistence, а не от любого restart.
4. **Scoped inside_cas:** kill после настоящего CAS blob publication. Новый CAS восстанавливает transaction, Core finalize recovery завершается, но workflow selection теряется. Fault hook вызывает настоящий `_publish_transaction_member` прежде, чем убить процесс; успешный CAS result не фабрикуется. Первый fresh CAS создаёт before-reader, поэтому CAS transaction replay относится к этому reopen; последующий `recover_pending_run_finalize` завершает run journal, а не обязательно первым восстанавливает CAS transaction.
5. **Scoped foreign_journal:** recovery отвергает owner mismatch, сохраняет journal и trace bytes, consumer не выдаёт final-state ref.
6. **Scoped duplicate_terminal:** отказ без переписывания journal/trace; ambiguity не принимается за terminal authority.
7. **Scoped corrupt_terminal_profile:** повреждён настоящий selected RunManifest profile; recovery отвергает его, consumer не выдаёт final-state ref.
8. **Scoped after_owner:** реальная tenant-enforced CAS recovery проходит, но selection теряется.
9. **Unscoped after_owner:** те же boundary и tenant-aware RunContext со stock unscoped CAS приводят к `artifact_transaction_owner_generation_or_bytes_unverified`. Это отдельный профиль, не новый доказанный production defect.
10. **Scoped one-shot public retry:** первый публичный `RunContext.finalize` получает I/O fault, fault полностью снят, второй публичный finalize выдаёт `run_finalize_workflow_finalization_not_established`. Core manifest при этом уже восстановлен, final-state ref не выбирается.

В первых девяти случаях before-reader, recovery и after-reader имеют разные PID. Во всех crash cases наблюдается exit `-9` и fsynced SIGKILL marker. Вызов consumer с неверным job или tenant отдельно возвращает `None`, включая positive normal case. Fault injection направлена исключительно на процессы и файлы данного audit.

## Source → наблюдение

- `core/run/context.py:1178–1186`: `_write_finalize_journal` сохраняет только schema version и RunManifest. Selected workflow ref не отдельный request field.
- `context.py:1402–1499`: recovery append формирует `TraceRefs(outputs=[run_ref])`, без выбранного workflow input. Если terminal event уже существует, он проверяется и сохраняется.
- `context.py:3172–3278`: normal finalize получает exact selected ref, требует selected profile и owner-output linkage, а затем записывает его в terminal inputs. Recovery retry отдельно требует ожидаемый ref, которого восстановленный terminal event уже не содержит.
- `runtime/http/services/adapters/core_run.py:225–322`: selected receipt берётся только из одного explicit terminal input при exact binding к одному manifest output. `load_core_run` сам запускает recovery, поэтому его `ok` не доказывает восстановленный workflow selection.
- `runtime/http/services/control/run_lifecycle.py:14287–14382`: настоящий узкий consumer проверяет run/job/tenant/cell, bounded typed receipt, selected profile и final-state ref membership. Отсутствующий selected receipt приводит к `None`.
- `scientist/orchestration/engine/executor.py:2635–2638` и `async_executor.py:1156–1159`: оба настоящих producer передают selected finalization ref в общий Core finalizer. Это source reachability, не execution обоих engines.

**Точность формулировки:** consumer возвращает final ExperimentState **ref**, а не вычисляет и не валидирует семантику ExperimentState payload. Сам payload здесь synthetic. Проверенный WorkflowStateFinalization receipt и exact output membership нельзя повышать до полной достоверности final ExperimentState.

## Проверенные контрмеры и остаточная причина

Strict CAS/profile/owner checks, strict trace intake, cross-process finalize lease и exact selected-ref consumer реально выполняются. Они ограничивают повреждение: неверная identity, дублирование terminal и повреждённый selected profile отвергаются. Положительный normal и after-terminal controls показывают исправный selection reader. Ни один из этих guards не может восстановить факт выбора, не попавший в журнал.

Исходные results дополнительно сохраняют normal с двумя outputs, core-only finalize, before-journal public resume, after-clear, malformed journal, corrupted manifest blob, synthetic half-line, autoload reader и четыре concurrent recoverers. Их artifacts, assertions и source hashes повторно проверены; все эти случаи не переисполнялись reviewer. Four-process result подтверждает один terminal append в данной попытке, не exhaustiveness interleavings. Half-line создаётся самим harness и не является наблюдением дискового torn write.

## Unscoped discriminator

В `core/artifacts/ownership.py:1005–1013` transaction с `owner=None` требует отсутствия tenant claims. После tenant owner-record unscoped write/recovery не проходит эту проверку. Scoped CAS использует явные tenant/cell и `ownership_enforced=True` и проходит ту же boundary, оставляя исходный missing-selection STATE-01. Runtime constructor source (`run_lifecycle.py:7298–7308`) включает ambient ownership enforcement в штатном создании store.

Следствие: нельзя объявлять первоначальный exploratory unscoped red новым runtime CAS defect или прятать его под названием inherited. Оба результата сохранены и воспроизведены. Извлечённый consumer не квалифицирует весь Runtime constructor, его guarded wrapper или injected-store configurations.

## Fixture и environment seams

- Runtime Python 3.12.14, не repo baseline Python 3.14. Сохранён исходный native-import failure; native acceptance отсутствует. Зависимости не устанавливались.
- Loader компилирует целые исполняемые Core/CAS/trace/adapter modules после parenthesization Python 3.14 comma-except и TypeVar backport. Десять package facades bootstrap пропущены. Исходная loader map содержит 136 loaded modules, 21 запись compatibility rewrite и пять extracted definitions; hashes сравниваются с source commit.
- Из `ControlPlaneService` извлечены actual consumer и bounded-reader method, плюс три helper functions. Full constructor, job store/lease, aggregate-budget route, authenticated HTTP request не исполнены. Synthetic `RuntimeRead` задаёт только CAS и runs root.
- Registry/workflow spec/prior/final state payloads synthetic, но CAS, owner snapshots, RunContext lifecycle, strict receipt DTO, profile validation, journal, trace, leases и consumer algorithm не заменены положительными fixtures.
- SIGKILL доказывает process death/reopen, не потерю питания, disk-cache persistence, PostgreSQL/distributed/network semantics или product-wide exactly-once.
- Однократная retry-инъекция снята перед повтором. Исходный persistent-fault same-writer retry отдельно не считается доказательством восстановления после снятия fault.

## Ремонт и закрывающий falsifier

Canonical owner: существующий Core finalize journal/recovery, не Runtime fallback и не новый recovery subsystem. Следует durable хранить exact selected workflow ref с selected profile и owner/output binding, восстановить тот же terminal input и сверять конфликтующие повторные requests. Reader не должен угадывать receipt по порядку/числу outputs. Legacy journals без selected field требуют явно fail-closed/backward-compatible политики, не fabricated selection.

Для product closeout нужны supported locked Python 3.14, оба настоящих sync/async workflow producer, boundary deaths, exact selected ref/final-state ref через настоящий authenticated consumer route, а также legacy journal и conflicting selected-ref cases. Исправление production в этом review не выполнялось.

## Артефакты и воспроизведение

- `review_results.json`: новые cases и deciding assertions; `review_state/`: actual CAS/trace/journal/config bytes.
- `probe_review_finalize.py`: bounded replay, зависит только от sibling `next_finalize_chain` harness/loader и sibling `source`. Он требует пустые целевые state каталоги и не перезаписывает уже существующие результаты.
- `validate_review.py`, `REVIEW_VALIDATION.json`: повторная проверка 2241 исходного artifact, 141 source file против `f1541ed`, чистоты snapshot и новых результатов. PASS здесь означает согласованность evidence, не исправность продукта.
- `ARTIFACT_MANIFEST.json` и `SHA256SUMS.txt`: delivery whitelist и content integrity. Исходная wave хранится в `../next_finalize_chain` и не дублируется.

В review нет нового самостоятельного defect ID, native/full-workflow PASS или заявления о production incident.
