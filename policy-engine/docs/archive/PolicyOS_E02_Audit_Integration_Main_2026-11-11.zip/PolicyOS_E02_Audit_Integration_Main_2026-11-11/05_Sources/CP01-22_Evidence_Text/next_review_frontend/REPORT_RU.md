# Независимая проверка FE-01, FE-02 и FE-06

Источник: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Проверены три findings из `next_frontend_contracts`, без изменения production source. Итог: **все три механизма подтверждены, границы влияния существенно уточнены**. Это review существующих findings, не три новых дефекта сверх FE-01/02/06.

## Главное для итогового аудита

1. **FE-01: подтверждён дефект состояния refresh и отсутствие session-generation fence.** Реальный exported transport в контролируемом испытании после явного clear вновь устанавливает старый refresh token и повторяет запрос с ним. Но в текущем frontend не найден UI caller для clear/set: это не доказательство выполненного logout/account switch в браузере и не серверный auth bypass. Ветка rejected refresh достижима через подключённый transport при настроенном refresh URL. По умолчанию URL пуст.
2. **FE-02: подтверждён дефект generated operation.** Успешные CSV и бинарные ответы в `downloadArtifactContent` разбираются как JSON и отвергаются. Прямых frontend callers этой операции не найдено. Нельзя описывать результат как уже наблюдавшийся сбой dashboard download или всей клиентской библиотеки.
3. **FE-06: подтверждён неполный parity oracle, но он сейчас вызывается только тестом.** State/owner corruption даёт ложный PASS. Это дефект проверки контракта, а не доказанный runtime admission bypass или опубликованный расходящийся MACHINE packet.

Исходные P2 можно сохранить как приоритет исправления этих конкретных контрактов. P2 не означает доказанную эксплуатацию, browser failure или текущую утечку между аккаунтами. FE-06 надо относить к test-confidence / semantic parity, а не к подтверждённой ошибке публикации authority.

## FE-01: реальные callers и различающие контрпримеры

**Primary source:** `apps/runtime-dashboard/src/app/auth/authSession.ts:134–234,248–312`.

`refreshPromise` дедуплицирует запросы, но явное изменение session не меняет generation и не отменяет публикацию результата старого refresh. `finally` очищает promise slot, а не session status. Исключения из `fetch` и `response.json()` не имеют перехода состояния.

Независимая проверка полного исходного модуля показала:

- `authAwareRuntimeFetch`: initial 401 → pending refresh → `clearAuthSession` → refresh со старым token. Token снова опубликован, затем actual exported wrapper отправил в synthetic fetch replay с `Bearer old-session-refresh`.
- Pending refresh → `setAuthAccessToken(new-session)` → поздний HTTP 401. Старый refresh стёр новый token и установил `expired`. Это та же ошибка отсутствующего generation fence, не отдельный finding.
- Network rejection и malformed JSON оставили `status=refreshing` и `lastError=null`.
- **Контрпример к permanent deadlock:** после каждого rejection следующий refresh успешно установил authenticated state. Promise slot освобождается.
- **Контрпримеры к утверждению «любой failure зависает»:** unconfigured URL, HTTP 401 и JSON без access token корректно вернули `null` и `expired`.
- Single-flight control сохранил один fetch для двух concurrent refresh requests.

**Reachability:** `src/api/client.ts:8–10` передаёт `authAwareRuntimeFetch` в `openapi-fetch`; package-client bridges также используют его. `RuntimeApiProvider.tsx:126–131` реагирует на `expired`. Но `clearAuthSession`/`setAuthAccessToken` лишь экспортируются через `AuthSessionProvider.tsx:33–38`; имена `clearSession`/`setAccessToken` больше нигде в scanned code не встречаются. Единственный внешний `useAuthSession` caller, RuntimeApiProvider, читает status, не изменяет token. Поэтому clear/set race доказан на публичном модульном API, а пользовательский UI logout/account-switch path не установлен.

`VITE_AUTH_REFRESH_URL` в source по умолчанию пуст (`authSession.ts:9`); тесты его подставляют. Конфигурация реального развёртывания не проверялась. При отсутствии URL refresh не запускает сеть и переходит в `expired`.

**Что чинить:** общий generation owner для всех session изменений и обеих веток refresh completion, плюс отказ от replay со старой generation. Rejected fetch/parse обязан завершать state; это не требует объявлять каждую сетевую ошибку окончательным logout. Нужны отдельные tests clear/replace, late success/late failure, rejection/recovery. Протокол провайдера и политика revocation требуют собственной проверки.

## FE-02: raw artifact operation и граница schema/generator

**Primary source:**

- `src/polisyos/runtime/http/routes/artifacts.py:1347–1471`: raw bytes response после tenant/profile/admission checks.
- `schemas/runtime_api_v1.openapi.json`, `GET /api/v1/artifacts/{artifact_id}/download`, response 200: одновременно `application/json` с пустой schema и `application/octet-stream` с binary schema.
- `tools/ops_runners/runtime/generate_runtime_client.py:265–295`: явный приоритет `application/json`.
- `packages/runtime-api-client/canonicalRuntimeApiClient.js:11–44,113–118` и TS `:2230–2238`: operation не задаёт binary mode; defaults to JSON и возвращает `Promise<unknown>` в TS.

Независимо импортирован actual generated JS, без переписывания его кода:

- CSV и произвольные binary bytes получили `SyntaxError`.
- Те же bytes через explicit `arrayBuffer` mode вернулись byte-for-byte.
- **Контрпример к «все downloads падают»:** валидный JSON artifact разобран успешно. Он возвращается объектом, а не исходными raw bytes с сохранёнными пробелами/порядком.
- HTTP 403 и 304 получили обычный HTTP error до JSON parsing. Ошибка success parser не доказывает bypass refused status. Поддержка conditional cache этим не подтверждена.
- Реальная sibling operation `getRunHumanDecisionEvidenceContent` вернула exact binary bytes, поскольку её generated call задаёт `arrayBuffer`. Это не общий запрет binary mode в клиенте.

Exact generator исполнен под Python 3.12. Четыре controls: unchanged mixed schema → JSON; только binary → ArrayBuffer; только JSON → JSON; обратный порядок content entries → всё ещё JSON. Значит дело в явном выборе representation, а не в случайном порядке ключей.

**Callers:** identifier census нашёл `downloadArtifactContent` только в двух generated definitions. Отдельный поиск `/download|download_artifact_content` в dashboard src, кроме generated types, пуст. API operation существует как доступный метод package, но живой пользовательский download path не показан. Backend test `test_api_maturity.py:90–101` описывает exact attachment bytes, однако он только прочитан, не исполнен в этом review.

**Что чинить:** сначала честное canonical описание raw endpoint, затем regeneration. Не стоит автоматически менять глобальный generator на «всегда предпочитай binary»: другие endpoints могут действительно поддерживать несколько negotiated representations. Нужен exact-byte operation-level regression test, включая корректные errors. Текущее испытание не доказывает принятие fixture реальным CAS/OPA/HTTP сервером.

## FE-06: parity oracle, а не закрытая export chain

**Primary source:** `apps/runtime-dashboard/src/features/runs/export/authorityValueTwin.ts:19–50,67–125`.

Checker читает DOM `owner_surface` и `state`, но сравнивает только ID membership/order, refusal code и reason. Independent two-member fixture:

- unchanged → PASS;
- state-only `refused → supplied` → **PASS**;
- owner-only `owner-a → owner-b` → **PASS**;
- changed code, changed reason, drop и reordered members → FAIL.

**Важный контрпример:** согласованная смена на supplied member, с `refusal_code=null`, `owner_surface=null` и reason из metric id, правильно получает FAIL по уже сравниваемым полям. State-only corruption из первоначального probe не является payload, который текущий typed backend и неизменённый `toMember` сами должны выдать. Это допустимый corruption test для oracle с `state: string`, но не доказательство production перехода отказа в supplied authority. Изменение владельца внутри refused/owned_by_another_surface остаётся самостоятельным значимым несовпадением.

**Callers:** и builder, и checker встречаются только в своём модуле и `authorityValueTwin.test.tsx`. Production export invocation или использование checker как release/runtime gate в scanned code отсутствует. Поэтому «checker допускает расхождение» верно; «публикуемый MACHINE packet уже прошёл этот gate с ложным authority» не установлено.

`PublicSectorReadinessPanel.tsx:12–22` и ScientificDepthPanel выводят `data-owner-surface`, `data-state`, `data-refusal-code` и detail. Их hook `useRunAuthorityValues.ts:31–48` нормализует реальный discriminated union. Backend `services/authority_values.py:112–150,284–305` сейчас строит только refusals; supplied variant определён для будущего использования. Корректность текущих refusal producers этим finding не опровергнута.

**Что чинить:** дополнить существующий semantic comparator полями state/owner, добавить независимые corruption controls. Envelope identity run/surface/schema проверяется на соответствующей границе отдельно. Если требуется фактически поставляемый MACHINE twin, production consumer/export chain надо сначала явно замкнуть; наличие builder и теста не равно поставке этой capability.

## Доказательства и границы исполнения

- `INDEPENDENT_RESULTS.json`: 22 observations, assertions прошли. **Зелёный probe означает воспроизведение ожидаемых дефектов и controls, а не зелёный продукт.** Auth/twin используют полные модули после Node24 type erasure. Auth logger/Vite configuration/window/document/fetch подставлены. Twin DOM reader synthetic, без React render.
- `transport.stdout.txt`: existing actual `runtimeApiClient.test.mjs`, 19/19 на Node v24.22.1. Это полезный транспортный suite, но он не тестирует FE-02 download operation и не заменяет supported Node22 run.
- `GENERATOR_CONTROLS.json`: четыре in-memory counterfactuals exact generator под Python 3.12.14. Не full schema export и не regeneration.
- `CALLER_CENSUS.json`: exact identifier search по 4760 code files в apps/packages/src/tools. Occurrences вручную классифицированы. Это не AST call graph, не поиск внешних consumers и не разрешение произвольных dynamic property lookups.
- `SOURCE_VALIDATION.json`: 23 deciding source files совпадают с exact Git commit. Это source integrity, не coverage всего репозитория.
- `ENVIRONMENT.json`: отсутствуют workspace/dashboard node_modules. Native Node22 Vitest, typecheck/build, реальный browser, FastAPI/CAS/provider и hosted CI в review **UNRUN**. Исходные tests являются jsdom/component tests, а не автоматически browser acceptance. Никакие dependencies не устанавливались и production source не менялся.

Следующий deciding run: supported Node22 + frozen workspace deps, реальные Vitest corruption tests и controlled auth integration; для FE-02 backend-served bytes через generated method; для FE-06 фактический production export consumer, если он требуется контрактом. До этих проверок результат остаётся подтверждением bounded mechanisms с явно незамкнутыми end-to-end границами.
