# Независимый review: governance handoff и execution owner

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`, source read-only. Проверены frozen `next_governance_handoff` и `next_execution_owner`, их source bindings, instruments и реальные consumers. **Принят bounded evidence; W01 и W03 остаются PARTIAL. Новых defect IDs нет, прежние findings не снимаются.**

## Решение

- **GH-O1 подтверждён как observation о локальном source-currentness join.** Семь исходных cases заново дают прежние результаты. Независимые обратные controls показывают, что verdict следует выбранному persisted normative result, а не текущим Trinity/metrics: negative result при positive inputs даёт `needs_revision`, rights/budget result при positive inputs даёт `reject`. Это не unconditional approve и не исполненный engine/publication bypass.
- **Guards действительно различают математику и authority.** Все девять свежих vectors проходят strict CAS roundtrip, но source-bound search score остаётся `not_established`. Одиннадцать исходных safety refusals и шесть новых removal/input/provenance controls проходят. Ни один успешный independent Runtime admission receipt не выпускался.
- **Legal limitation установлена точно.** Восемь required-authority fixtures отказывают. Out-of-scope case не создаёт authority. Source relation owner в этом pin имеет только candidate-only disposition и безусловный typed refusal; “полные facets” не заменяют независимого relation verifier.
- **Cached physical settlement подтверждён в конечном наборе случаев.** Пять исходных сценариев повторены на новых SQL/ledger/CAS roots; ещё три independent controls различают expiry без takeover, отмену первого waiter и отмену самого physical owner task. Новый процесс прочитал все восемь fixtures.
- **Cancellation и stale execution не смешаны с потерей факта расхода.** Старый owner может сохранить known charge/получить физический response, но stale follower и SQL completion отказывают. Отмена physical task оставляет `unknown` и блокирует fresh budget admission. Ни это, ни waiter cancellation не являются проверкой public cancel endpoint или гарантией остановки внешнего provider.

Specification verdict: **PARTIAL** относительно полной source→normative→governance и authenticated NL→N5→terminal цепочек. Engineering-quality verdict: **PASS только для выполненных bounded controls и согласованности evidence**, не release/native/product PASS.

## 1. Независимость и воспроизводимость

До запуска проверены все записи обоих manifests и SHA256SUMS: 149 governance и 235 execution файлов, без расхождений. После работы входные bytes и manifests проверены повторно. `SOURCE_VALIDATION.json` повторно сравнивает union двух source readsets и новых imported/inspected files с Git pin. Это именованный readset, не census всего репозитория.

`review_execution.py` импортирует неизменённый исходный instrument как helper и повторяет пять cases; три новых сценария написаны отдельно. `review_governance.py` повторяет целые audit scripts с единственным AST изменением: output `ROOT` направлен в review каталог. Product predicate bodies не изменены. Затем выполняются новые обратные/removal controls. `REPLAY_TRANSFORMS.json` содержит точные хеши и это изменение. Повтор старого instrument сам по себе не объявлен независимой проверкой его предпосылок.

Все источники сохранены read-only. Не устанавливались зависимости, не вызывались живые providers, не создавались permissions/issuer marks и не редактировался product. Профиль Python 3.12.14 с документированными in-memory compatibility адаптациями не равен поддерживаемому Python 3.14/locked profile. Facade skips, DTO extractions и whole helper extraction сохранены в loader records.

## 2. Что именно показывает governance join

`NormativeArbitrationPass` проверяет содержание выбранного result: rights, hard constraints, completeness, dissent и selected option. `_resolve_result` использует generic artifact reader. Сверки `result.provenance` с current Trinity/metrics в этом consumer нет. `_run_governance_checks` передаёт artifacts и params, но не inputs/reports_index. Независимые controls используют именно такую форму pass context.

Дополнительные controls:

1. Positive current source + old negative result → `needs_revision`.
2. Positive current source + old right-blocked result → `reject`.
3. Positive current source + old budget-blocked result → `reject`.
4. Удаление selected result → `NORMATIVE_RESULT_MISSING` WARNING; локальный resolver сохраняет входной `approve`.
5. Входные `reject` и `human_gate` сохраняются даже при positive result.

Removal case показывает optional/advisory локальную семантику. Это не новый ID и не утверждение, что полный RunGovernance или publication допускает отсутствие нормативного доказательства. Внешние dynamic passes, claim projection, Phase2 tail и последующие owners не исполнены.

`report_currentness.py` решает другой вопрос: exact selected report должен быть выходом успешного зарегистрированного engine invocation; требуются run/profile/input basis и текущая полная declared state projection. Три source-unbound v1 reports заново читаются как исторические bytes, но получают `not_established`; foreign selection получает `stale`. Этот guard не равен транзитивной сверке provenance внутри выбранного normative result. Если stale result был уже выбран во время нового governance invocation, совпадение входного readset само по себе не доказывает semantic source relation. Достижимость такого полного перехода и итоговый current consumer здесь **не установлены**.

Causal scheduling dependency также не доказывает, что causal report участвует в normative utility formula. Declared reads нормативного узла относятся к Trinity, Metrics, SimulationResult, distributional, Legal и uncertainty refs. Harness-projected metrics из causal point estimate не выданы за genuine scientific simulator producer.

## 3. Guards и отсутствие full positive admission

Девять ObjectiveStack cases повторены через полные canonical классы и настоящий CAS. Реальный failed causal report с собственным fallback uncertainty остаётся infeasible; asserted low uncertainty может сделать математический vector feasible. Все девять source-score consumers после fresh-process read отказывают. Поэтому результат не снимает прежние scientific/metric findings и не доказывает selectable/current policy.

Шесть новых safety controls: удаление provenance, дублирование input ref, изменение candidate, изменение metrics при foreign positive verifier, `institutionally_supplied` и `not_established` predicate provenance. Каждый даёт `execution_context_binding_mismatch`. Для изменённых metrics foreign verifier ни разу не вызывается. Исходный exact typed fixture без verifier доходит до `verifier_unresolved`, а чужой asserted positive receipt даёт `consumer_admission_blocked`. Следовательно, отказ не объясняется только отсутствующим ранним полем; receipt gate действительно reached, но успешный Runtime issuer не подменён.

Legal builder и source owner повторены без asserted positive bypass. `current_legal_source_relation_disposition()` возвращает `search_candidate`, а `require_legal_source_relation_verification()` всегда выдаёт typed refusal. Это намеренный текущий fail-closed boundary, а не разрешение заменить verifier boolean-меткой. Successful simulation/propagation uncertainty, causal identification, Legal relation issuance и полный engine-owned v2 governance остаются непроверенными. Невозможность positive Legal authority в этом pin обозначена отдельно от инструментальной недоступности native профиля.

## 4. Worker, lease и physical settlement

Свежие исходные пять cases сохраняют различия:

- normal: один offline provider call, reported 0.25 + reuse 0, SQL completed, настоящий CAS result и fresh read;
- renewal + оба waiters cancelled: owner task остаётся alive до release, затем committed 0.25 и live handles=0;
- takeover: SQL attempt2; original charge остаётся attempt1; stale follower, reuse и old completion отказывают;
- lost settlement acknowledgement: write-then-raise после записи → reconciliation/readback, один charge и один physical call;
- provider failure: unknown amount, failed job, fresh budget admission отказывает.

Новые различающие cases:

- **Expiry без replacement.** Меняется только expiry в audit-owned SQLite через независимое соединение. Attempt остаётся 1. `verify_llm_producer_admission` и `complete_job` отказывают `ControlJobLeaseLostError`; follower получает `JobExecutionInterrupted`. Физический response/charge 0.25 сохраняются, budget observation остаётся известным. Таким образом, guard проверяет саму живую lease, а не только изменение номера attempt.
- **Отмена первого waiter.** Первый получает `CancelledError`, второй ещё ждёт, отдельный owner task остаётся alive с live handle=1. После release follower получает результат, ledger содержит reported 0.25 + reuse 0; cleanup завершён.
- **Отмена самого physical owner task.** Это явная fault injection во внутреннюю asyncio task, не public API. Оба waiters получают `CancelledError`, offline coroutine не достигает synthetic finish, ledger сохраняет unknown amount, live handles/inflight очищены. Fresh observer отказывает `control_nl_budget_producer_event_not_settled`. Внешняя физическая остановка отсюда не следует.

Во всех трёх cases дополнительные wrong-worker и wrong-attempt completion controls отвергаются ещё до ожидаемой transition. Все восемь final SQL/ledger fixtures перечитаны в отдельном процессе; known charges сохраняют attempt1. Три новых audit handlers намеренно не публикуют terminal success, поэтому их `running` state не записан как lifecycle defect.

## 5. Нельзя расширять этот PASS

Execution instrument вручную соединяет настоящие worker/SQL guards с cached client, использует synthetic authenticated scope и offline provider. Он не вызывает настоящий authentication issuer, strict factory snapshot/reuse authorization, NL compiler, Core intent set, N5 budget/implementation seal или PA2/frontier terminal authority. Audit CAS result и `ControlJobRecord.to_response()` не являются served N4/current-cost projection.

`run_coro_sync` при закрытии fresh loop отменяет pending tasks. Исходный и новый probes удерживают loop до окончания owner task; direct owner-task cancel control различает исход, но не является запуском настоящего timeout/shutdown path. Поэтому прежний direct-client BUD-01 не опровергнут, а “cache survives any cancellation/crash” не заявляется.

Public cancellation source требует exact current permission proof, rollout, full job/cell/body/operation identity и commit-time recheck. Receipt означает `publication_fenced`, physical stop не установлен. Реальный endpoint, identical retry, changed-request conflict и поздний N5 commit в этой проверке **UNRUN**. Поддельного permission proof не создавалось.

N5 source-traced reserve→physical work→settle→post-currentness и final readers не повышены до executed evidence. Known physical work не заменяет current execution/implementation/PA2 authority; historical read не равен live retention. MA/PA/BUD/LIF findings остаются в прежнем scope.

## 6. Deliverable и следующий deciding run

Результаты: `execution_results.json`, `execution_reader.stdout.json`, `results.json`, `governance_independent_results.json`, `safety_results.json`, `legal_results.json`, `reader_results.json`. Новые raw fixtures лежат в `retained/` и `cas/`. Commands и ограничения отражены в `TEST_SCOPE.json`, binding в `INPUT_BINDINGS.json`, решение в `REVIEW_DISPOSITION.json`.

Выполнены два instruments и их subprocess readers; exit codes 0, deciding stderr пуст. Repository pytest, native backend, live APIs и end-to-end release qualification не запускались. `VALIDATION.json=PASS` означает consistency и соответствие указанным observations, не product readiness.

Следующий значимый falsifier остаётся прежним: genuine supported engine/source producer→normative→current governance consumer с отдельной source swap/removal, либо authenticated NL→strict cache admission→N5 implementation/PA2→terminal→served fresh reader. Требуется реальный issuer и проверка его отсутствия/revocation, не новый DTO/маркер “verified”. Пока genuine owner не существует или не выполнен, честный результат — exact fail-closed limitation, а не full-chain PASS.
