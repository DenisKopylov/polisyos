# Независимая проверка GR-01 и GR-02

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Объект: два finding из `next_graph_refresh/FINDINGS.json`. Статус: **PARTIAL, independent static review**. Подтверждены оба локальных механизма, но не production incident, exploit или обход authority. Новых finding/SYS-семейств не добавлено. Исходники, тесты и чужие результаты не изменены.

## Решение

- **GR-01: сохранить, medium; механизм подтверждён, operational exposure не установлен.** Profile отсутствует во внутренних ключах epoch graph. Уточнение: найденный canonical producer строит только `epoch_manifest → issuance_basis`, а не произвольный граф сертификатов. Его full-profile target denominator может остановить profile collision отказом ещё до transition.
- **GR-02: сохранить, medium; механизм подтверждён, ограниченный false-incomplete результат.** First-visit DFS без улучшения глубины теряет допустимое более короткое раскрытие. `max_depth` публично задан как depth cap, но обещание shortest-distance semantics явно не написано. Поэтому наиболее точная формулировка: зависимость доступного bounded subgraph и completeness от порядка manifest inputs, а не нарушение отдельно документированного shortest-path API.
- **Спецификация:** FAIL для различения selected views в GR-01; PARTIAL для полноты нормативной формулировки depth contract в GR-02. **Engineering quality:** FAIL для двух показанных механизмов, PARTIAL для всей consumer chain.
- **Native/runtime verification:** UNRUN в этом независимом review. Прежние bounded probes прочитаны как предоставленные результаты, не выданы за новый запуск.

## 1. Направления и identity

CAS lineage (`core/artifacts/graph.py:241–253`) идёт от результата к его upstream inputs. Epoch invalidation (`runtime/quality/epoch_validity_cascade.py:787–820`) идёт от source к зависимому target. Реальный producer (`epoch_certificate_issuance.py:1033–1038`) подтверждает направление: semantic epoch invalidates issuance basis. Использовать одну adjacency без явного преобразования смысла нельзя.

Core canonical identity (`core/artifacts/manifest.py:303–317`) явно содержит artifact ID, kind, media type, selected profile. Epoch helper (`epoch_validity_cascade.py:743–744`) содержит только первые три. CAS traversal при profile-preserving reads использует `(ID, profile)`, поскольку kind/media извлекаются из выбранного manifest; это не тот же дефект identity. Совпадение blob ID не доказывает совпадение выбранных manifest views.

Source tests подтверждают, что разница profiles не искусственна: `test_bounded_core_json_artifact.py:380–405` создаёт одни bytes/ID с разными profile settings; `test_manifest_lineage_input_normalization.py:25–50` требует различать selected и default refs. Эти тесты просмотрены, не запускались.

## 2. GR-01: что именно доказано

Рассматриваем A и B с одинаковыми ID/kind/media, разными profiles; одинаковый authority purpose.

1. **Source collision:** edges `A→child-A`, `B→child-B` с разными child IDs принимаются graph duplicate guard. Ключи A/B совпадают, adjacency объединяет детей. Advisory с exact target A достигает обоих. Без owner обе строки будут `review_required`, не `invalidate` (`:880–883`).
2. **Target collision:** edges `upstream-1→A`, `upstream-2→B` принимаются, поскольку upstream IDs различны. Target dictionary `:781–783` оставляет одну строку; Python dict overwrite выбирает последний profile. Перестановка edges меняет surviving target, а не только сериализованный hash.
3. **Scope:** `scope="instance"` не лечит target collision, но отключает propagation к детям. Различный purpose сохраняет разделение adjacency. Различный kind/media/ID устраняет эту конкретную коллизию. Если у каждого тройного ключа один profile, этот witness отсутствует.
4. **Duplicate guard не универсальная защита:** если обе endpoints отличаются только profiles, `:519–529` сочтёт две exact-view edges дублем и откажет. Исходные witnesses специально используют различающиеся opposite endpoints, поэтому этот guard их не опровергает.
5. **Hashes не лечат projection:** full edge payload хешируется (`:530–532`), но последующий resolver использует потерявший profile ключ. Целостность bytes не делает ошибочную семантику ключа правильной.

### Consumers и существенное ограничение исходного finding

Три production call sites resolver: `epoch_transition_inputs.py:517`, `epoch_validity_cascade.py:1338`, `epoch_transition_origin.py:293`. Последний повторно вычисляет vector при origin verification; повторение того же алгоритма проверяет согласованность, но не независимую exact-view семантику.

В current source найден **один direct constructor call** production `EpochDependencyEdge`: `epoch_certificate_issuance.py:1033`. Он перечисляет owner-admitted issuance index, фильтрует previous epoch/purpose, создаёт epoch→basis edges. Сам этот owner уже использует canonical full-profile identity (`:71–88,1039–1064`). Это не доказательство, что произвольная topology из probe достижима через него.

Более того, owner возвращает все full-profile `target_refs` (`:1063`), а `EpochDependencyDenominatorReceipt` сравнивает их с targets, схлопнутыми helper (`epoch_validity_cascade.py:973–976`). Если два target profiles прошли edge constructor, honest complete receipt с обоими profiles откажет по denominator mismatch. При одном source и двух profile-only target siblings возможен ещё более ранний duplicate-edge отказ. Duplicate certificate triples тоже отвергаются (`:977–983`). Таким образом, synthetic target-loss vector не следует выдавать за доказанный silently incomplete canonical transition.

`CanonicalEpochPerturbationAdjudicationProvider` использует слабый ключ для membership/events (`epoch_transition_inputs.py:404–442`), но actual monitor advisory target берётся из `decision_packet_ref` (`epoch_validity_cascade.py:586–595`), тогда как найденный canonical graph состоит из epoch/basis refs. Наличие соответствующих real persisted refs в graph не показано. Это дополнительная причина не превращать graph-DTO witness в доказанный production event path.

Положительные защиты:

- Wrong purpose и foreign target отказывают; reached set завершает cycles; appeal только instance (`:547–551,805–825`).
- Advisory severity не создаёт owner authority; mixed owner actions дают contested (`:833–881`).
- Actual adjudication требует native basis, отказывает при unresolved native-change carrier и независимо перечитывает owner evidence (`epoch_transition_inputs.py:457–514`).
- Default NoEpochTransitionSigningAuthority возвращает not-established ещё до graph processing (`epoch_validity_cascade.py:1312–1318`). Signer/readback/origin gates не обойдены данным review.

**Граница вывода:** defect exact-view identity подтверждён в reusable resolver/DTO chain. Реальный producer с двумя профилями одного triple, admission такого denominator, owner response и public/signing consequence остаются UNRUN/unproven. Это correctness/availability finding, не подтверждённая security vulnerability.

## 3. GR-02: depth contract и контрпримеры

Source: `core/artifacts/graph.py:133–184`. LIFO pop выбирает последний input первым. Node хранит depth первого посещения (`:153–160`); expanded проверяется/пишется до depth cap (`:178–184`). Позднее более короткое посещение не обновляет depth/status и не раскрывает inputs заново. Cap inclusive: depth == max_depth разрешён, depth > max_depth пропускается.

Предоставленный witness: `r→s`, `r→a`, `a→b`, `b→s`, `s→leaf`, cap=2. При root inputs [s,a] порядок pop: r@0, a@1, b@2, s@3 (skipped, expanded), s@1 (early continue). Leaf не обнаружен. При [a,s]: s@1 и leaf@2 раскрываются до длинной ветви; граф complete. Это следует непосредственно из source и совпадает с предоставленным bounded result. Сам review код продукта не исполнял.

Статический sibling counterexample против неполного исправления: `r→s`, `r→a`, `a→s`, `s→leaf`, cap=2, long-first. s сначала успешно раскрыт на depth=2, leaf пропущен на 3; затем s@1 не переоткрывается. Перенос `expanded.add` ниже depth check не исправляет этот вариант. Нужен shortest-depth traversal или re-expansion при улучшении глубины, с корректным обновлением статуса/depth.

Контрслучаи и границы:

- При единственном пути к каждому узлу first-visit poisoning отсутствует.
- Short-first уже работает. Достаточно большой cap для всех relevant acyclic paths устраняет этот false-incomplete witness, но не делает сохранённый depth кратчайшим.
- `max_depth+1` placeholder сам по себе не ошибка: это способ обозначить усечение. Ошибка witness в том, что тот же exact node доступен разрешённым коротким путём и остаётся пропущенным.
- Никакая проверка integrity не отключена: missing/defaultless-profile/corrupt случаи сохраняют non-present status (`:186–240`). Разные profiles остаются разными nodes (`:259–261`).
- max_nodes вызывает ValueError, timeout отмечает incomplete; cycles останавливает expanded. Изменение алгоритма обязано сохранить эти бюджеты и selected-profile отказ, а не обходить их.

Документация HTTP (`docs/reference/api/artifacts.md:259–267`) говорит только optional depth cap 1..256. Service описывает bounded upstream graph (`lineage.py:80–85`). Явного shortest-path определения в просмотренных источниках нет. Однако порядок edges не меняет relation reachability. Даже альтернативная трактовка «если существует слишком длинный путь, узел должен быть skipped» не объясняет short-first complete результат. Сильная engineering претензия сохраняется; документированный нормативный контракт нужно уточнить при ремонте.

### Реальные consumer последствия

1. **HTTP:** route `routes/artifacts.py:860–905` принимает cap и проходит tenant/profile gates; `artifact_inspector.py:1159–1197` передаёт selected root в `LineageService`; `lineage.py:146–190,229–240` передаёт cap в resolver, переносит skipped в missing IDs и is_complete=False. Это wiring, не выполненный HTTP request. Profileless service roots отдельно дают limitation, поэтому core short-first complete нельзя автоматически приравнять к API complete без selected profiles.
2. **Audit export:** `_assembler_core.py:272–281` вызывает resolver и поднимает `IncompleteAuditError`. Возможен лишний отказ, не тихий complete export.
3. **Streaming:** `streaming.py:3410–3414` требует exact profiles/integrity и отказывает при incomplete. Default cap=200; small witness подтверждает общий алгоритм, но не конкретный production stream глубже 200.
4. **Replay:** `deterministic.py:832,876` использует resolver; later missing classification (`:904–943`) различает INCOMPLETE и RECOVERABLE по critical roles. Нельзя заявлять, что всякая depth omission обязательно полностью блокирует replay; результат зависит от роли. Дополнительный subgraph path иногда может добавить доступные refs, поэтому full replay outcome не доказан одним core witness.

## 4. Проверка test evidence и минимальный следующий acceptance

Existing core test file проверяет ordinary chain, missing, corrupted, timeout, root metadata, отказ unprofiled child. В нём нет long/short shared-node bounded witness. Epoch tests проверяют wrong kind/purpose, event/owner transport order и sibling другого purpose. Они не доказывают profile separation одного triple: их «sibling» guard основан на purpose, а transport-order тест переставляет events/owners, не mixed-profile graph targets.

Требуемый acceptance без расширения architecture:

- GR-01: native persisted two-view CAS fixtures; Graph DTO, complete receipt и actual canonical inventory различать по статусу. Проверить source/target/event/owner profile substitutions, same-purpose siblings, edge order, historical receipt compatibility. Переиспользовать canonical identity и явный sort key для optional profile (существует у issuance owner); слепое `sorted()` над None/str может добавить TypeError.
- GR-02: native FileSystemCAS и public selected-root lineage; оба long-first witnesses, exact cap boundary, cycles, missing/corrupted/defaultless profiles, timeout/node budgets. Проверить audit refusal и replay classification по ролям.
- Не заменять неизменяемые historical views текущим default, не выдавать candidate review за authority, не добавлять отдельный универсальный graph service.

## 5. Evidence qualification

`SOURCE_EVIDENCE.json` содержит line-bounded excerpts, SHA-256 каждого reviewed file и сравнение с exact Git blob. `CALLER_CENSUS.json` сохраняет полный текстовый search выбранных symbols по current src Python files, не dynamic coverage. `INPUT_EVIDENCE.json` фиксирует прочитанные finding/probe results и hashes без изменения исходного пакета. `REVIEW.json` содержит machine-readable решения, traceability и unresolved facts.

Запущены только read-only source searches/reads и script metadata/hash verification, не product tests/builds/PoCs. Source HEAD и tracked status проверены. Нет dependency install, native CAS replay, signer, live HTTP, production data или benchmark. Совпадение двух reviews не считается дополнительным runtime доказательством.
