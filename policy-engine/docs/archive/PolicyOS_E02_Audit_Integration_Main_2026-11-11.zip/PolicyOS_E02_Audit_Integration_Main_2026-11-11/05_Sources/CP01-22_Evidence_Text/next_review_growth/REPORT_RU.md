# Независимая проверка persisted growth

## Итог

**Результат author-прохода воспроизводится на ограниченной поверхности.** Новый явно заданный construct и family alias проходят persisted JSON registry → исходный resolver/compiler → immutable JSON report → новый процесс чтения. Это не подтверждение универсального научного саморазвития, native production E2E или допуска источника как доказательства.

**Расхождение scope реально, но authority bypass не установлен.** Legacy binding может вернуть `selected_exact` и `satisfies_claim_evidence=true`, тогда как candidate discovery для того же запроса возвращает `no_match`. Более строгий candidate guard не меняет старый binding. Downstream routing и Fabric не превращают этот результат в независимо допущенную authority.

Pin: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Проверены 39 source-файлов: SHA-256 и Git blob IDs совпадают с baseline; tracked status пуст. Производственный код, repository tests и зависимости не изменялись.

## 1. Что воспроизведено

`replay_probe.py` является неизменённой копией авторского harness, исполненной в отдельном `next_review_growth`, без записи в author-пакет. Controls, projections, compilation controls, оба отчёта, identity, ограничения и fresh-process exit совпадают с автором; отличаются только timing/runtime-профиль.

- Новый `aquatic_thermal_exposure` и `aquatic_temperature_observations` прочитаны из реального JSON файла.
- Compiler пишет content-addressed report и повторно использует те же bytes; fresh process читает полный typed report и audit projection.
- Изменение interval меняет report content hash и filename, хотя logical requirement ID сохраняется.
- Изменённая registry row может сохранить release locator и binding ID; descriptor digest меняется. Это различие logical locator и content identity, а не доказанный CAS collision.
- Report parser отказывает при duplicate JSON keys, неизвестной schema и конфликте уже существующих bytes; candidate DTO отказывает при несовпадающем digest.
- Native import отдельно повторён: exit 1 на `core/artifacts/store.py:2155`, Python 3.14 exception syntax под доступным Python 3.12. Это ограничение окружения, не воспроизведённый дефект поддерживаемого runtime.

## 2. Interval: selected_exact против no_match

Фактические владельцы:

1. `runtime/quality/capability_resolver.py:803–858,1051–1066`: legacy selection использует `_time_window_matches`, сравнивает строки на отсутствие пересечения. Полное покрытие и валидность ISO calendar interval здесь не проверяются.
2. `core/contracts/capability_resolution.py:63–75`: `RequirementTimeWindow` нормализует optional text, но сам по себе не запрещает invalid/inverted dates.
3. `runtime/quality/capability_authority.py:761–914,1050–1062`: composer получает capability, posture, claim use, schema/sample criteria; original query interval туда не передаётся. `time_scope` выводится из freshness label, а не из покрытия запроса.
4. `core/contracts/capability_resolution.py:142–184` и resolver `:987–1030`: candidate discovery парсит даты, запрещает malformed/inverted intervals, требует покрытия известных границ и сохраняет неизвестные как limitations.

Независимые controls подтверждают:
- Полностью покрытый, равный границам и последний однодневный interval дают selected/candidate.
- День за пределами source interval блокируется в обоих контурах.
- Left/right overlap и interval вокруг всего source: binding `selected_exact`, discovery `no_match/time_window_not_covered`.
- Inverted query и 30 февраля: binding `selected_exact`, discovery `no_match` с соответствующим calendar refusal.
- Unknown bounds допускают candidate с явным unknown; это не доказательство покрытия.
- Foreign jurisdiction также может оставить binding selected при отказе discovery.

**Необходимо сохранить историческую оговорку:** `data_requirement/README.md:217–223` прямо описывает, что candidate v1.2 получает строгую calendar-проверку, а существующая claim-evidence resolution и historical bytes сохраняют прежнюю интерпретацию. Repository test `tests/unit/runtime/quality/test_capability_resolver.py:833–860` отдельно проверяет неизменность `resolve()` после candidate discovery. Test здесь прочитан, не запущен native.

В persisted negative report сохраняются `binding.status=selected_exact`, `authority_envelope_result=admissible` и `candidate_discovery.state=no_match`. Boolean `satisfies_claim_evidence` принадлежит полному resolver result; `CapabilityBindingSnapshot` в отчёте этого поля не переносит. Нельзя описывать report так, словно весь исходный authority result сериализован целиком.

## 3. Scope конструктов и synthetic data

Положительный результат опирается на синтетическую row, где уже заявлены observed mode, высокая quality, fresh state, допустимые rights и authority. `governed_fixture` читает и типизирует эти данные; этот probe не проверяет подпись владельца, реальную measurement validity, release/currentness или семантическое соответствие construct данным.

- Exact construct и явная family mapping расширяются данными без правки source.
- Независимо проверен второй construct `review_salinity_exposure` с новым family name, чтобы не свести результат к одному aquatic имени.
- Unknown construct, wrong entity/geography/population, явный outside interval, schema mismatch, sample below floor, candidate-only mode, rights/authority block имеют различающие controls.
- Population matching является ограниченным сопоставлением ключей `type/population/target_population/population_type/segment/segments/groups`, а не интерпретатором произвольных predicates. Неизвестный единственный predicate даёт candidate limitation; дополнительный неизвестный predicate рядом с допустимым `type` не доказывается и может не получить отдельной limitation.
- Lifecycle withdrawn, отсутствующий sample size/source assets и некоторые unknown scope поля могут сохранить legacy selected result. Это наблюдения указанного resolver, не утверждение, что все независимые admission/production guards пройдены.
- Новый domain label остаётся unresolved. Нет доказательства нового causal model, научной method validity или domain support.

## 4. Downstream guards и точный persistence owner

**Исполнено source-body с actual DTOs:**

- Compiler `data_requirement/compiler.py:1508–1584` перепроверяет wire discovery, original query и index identity, но не согласует автоматически selected binding с `no_match`.
- `compiled_requirements_for_world_slot`, compiler `:921–1075`, требует соответствия spec/query/profile/index, source asset metadata и calendar coverage. С полным synthetic fetch metadata положительный join=1; partial interval даёт join=0 при сохранённом legacy selected; удаление fetch binding и mutation scope-profile также дают join=0.
- Candidate-unverified source может дать routing join=1, одновременно с blocked binding и `candidate_discovery.satisfies_claim_evidence=false`. Это допустимая candidate маршрутизация, не promotion.
- Три попытки изменить candidate carrier: включить `satisfies_claim_evidence`, убрать `requires_native_source_admission` или изменить descriptor без digest, отвергнуты DTO validation.
- Fabric `fabric/catalog/data_requirement_adapter.py:391–447`: `disposition=candidate_only`, `authority_status=not_established`; budget/availability тоже не установлены. Mapping в DataNeed остаётся и для partial/absent-resource cases, но не означает успешный fetch, наличие данных или admissibility. Unrepresented requirement fields сохранены.
- Исполненный файловый owner: `write_data_requirement_compilation_report`, compiler `:1163–1214`, через actual `write_bytes_once`/`AtomicFileWriter`.

**Только source-traced, не исполнено native:**

- Runtime имеет реальный CAS bridge: `runtime/quality/generation_cycle.py:13567` вызывает `persist_and_verify_data_requirement_compilation_report`; owner `runtime/quality/acquisition_planner.py:7056–7215` проверяет typed report, subject/input binding, manifest/write profile, digest и readback equality. Нельзя считать bridge отсутствующим; нельзя приравнивать его проверку к выполненному JSON writer probe.
- `CapabilityDiscoveryAuthorityResolver`, `runtime/quality/capability_authority.py:579–718`, требует independently verified owner binding и production approval currentness. Этот класс исключён из извлечённого composer-среза harness. `selected_exact` из `compose_capability_authority` не доказывает `admitted_authority` этого другого owner.
- Projection guard и purpose blockers существуют; текущий review не доказывает полный caller path до публикации или отсутствие любого возможного authority bypass.

## 5. Вердикт и что осталось

- Проверка ограниченных авторских observations: **PASS, с уточнённой интерпретацией**.
- Полнота native/production интеграции и научного роста: **PARTIAL / NOT ESTABLISHED**.
- Native import: **ENVIRONMENT BLOCKED**, не зелёный тест.
- 18 независимых scope controls, 5 world-slot controls и 3 candidate-carrier corruption controls: **PASS** в source-body профиле.
- Authority exploit, real observation, scientific validation, full index compiler/DuckDB, fetch, CAS runtime execution, HTTP, deployment, publication и полный pytest suite: **не установлены / не запускались**.

Рекомендация по дальнейшей проверке: в поддерживаемом Python 3.14 выполнить native цепочку на подтверждённом governed source с independently admitted evidence; отдельно определить, должен ли legacy `selected_exact` означать полное покрытие query, и проверить совместимость historical readers. Не менять candidate guard ради совпадения статусов и не повышать authority синтетических данных.

Это review уточняет existing persisted-growth observations, а не добавляет их повторно как новые независимые defects. Точный frozen author inventory и review manifest представлены рядом.
