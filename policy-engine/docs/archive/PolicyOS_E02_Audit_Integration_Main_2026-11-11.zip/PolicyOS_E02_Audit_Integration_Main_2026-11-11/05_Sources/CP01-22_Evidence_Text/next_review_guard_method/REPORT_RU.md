# Independent review: guards и scientific execution

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Объекты: `next_guard_enforcement` и `next_method_execution`. Итог **PARTIAL_WITH_CONFIRMED_LOCAL_FINDINGS**. Содержательные GE-01/02/03 dispositions сохранены; GE-C01 остаётся coverage gap, ME-O1 остаётся bounded observation. Новых product defects этот review не добавляет. Product source не изменён.

## Результаты

1. **GE-01 подтверждён на direct caller.** Независимая Git history и весь неизменённый `check_docs_gate.main` дали exit 1 на valid changed base, 0 на valid empty и ошибочно 0 на missing base, zero SHA, missing head и non-Git root. После отрицательных случаев возврат к валидному base снова дал exit 1. Existing `docs_review_git` различает валидный ref и missing/zero ref, последние отвергает. Это fail-open selection semantics, не доказанный hosted/whole-CI bypass.
2. **GE-02 подтверждён для alternate-root shim subgate.** Свои два roots и exact wrapper/validator bodies вновь дали findings `[0,1,0,1,1]` для clean, same-root defect, candidate-only defect, checker-only defect, correct rebinding. Дополнительный nonexistent requested root также дал 0, потому что читался существующий checker-root. Actual parser paths и SHA сохранены. Для normal same-checkout CI этот split отсутствует. Full aggregate CLI, native dynamic/cycle collectors не выполнялись.
3. **GE-03 подтверждён на planner-level.** Два facade без README дают obligation; только Fabric README **или только IR README** снимают её для обоих. Полный набор и impact note также снимают obligation. Это existential path predicate, не установленная semantic staleness и не обход remaining generator checks.
4. **GE-C01 ограничен правильно.** Независимый exact timing predicate с synthetic 2× baseline не вызывает producer при default live=False, а при live=True даёт две regressions. Actual latency не измерена. Проверена source routing: checked-in workflow declarations и selective pre-commit не равны hosted runtime receipt; 12 workflows/3 actions из owner census не представляются полной runtime reachability.
5. **Численные утверждения method slice выдержали новые controls.** Ещё 20 Standard panels с другими seeds, размерами и treatment times совпали с independent mean-change contrast и CR0 group-change SE; permutation+constant shift сохранили point/SE. Новый Staggered fixture с 4/5 treated cohorts, 7 controls и 8 periods дал theta_sel=11/6, а не cell-weighted 47/22. Independent unit-mass derivatives на epsilon 1e-4, 1e-5, 1e-6 совпали с SE 0.5865331738454049. Seeded Mammen interval и p-value совпали. Point/SE масштабируются вдвое при scaling+unit permutation. Finite-seed bootstrap CI не объявляется permutation invariant.
6. **Selected guards сохранены.** Реально вызван `_verify_selected_did_target`, который ранее был только извлечён owner harness: baseline проходит, corrupted estimand и eligible-period contract отвергаются. Diagnostic baseline проходит. Coherent persisted forged peers отвергаются source replay, но проходят peer-only helper без source/spec, что соответствует двум разным контрактам. Source без request, request без source и missing historical alias отвергаются.
7. **Candidate boundary сохраняется.** Persisted result перечитан свежим процессом. Reports совпали; envelope gate_eligible=False. На новом wider-CI fixture ConfidencePass возвращает **оба** blocker: `CONFIDENCE_GATE_ELIGIBILITY_LOW` и `CONFIDENCE_CI_RATIO_EXCEEDED`; при producer relabel candidate gate тоже остаётся. Success claims остаются research_artifact/internal_only. Это конкретные causal-only consumer guards, не полный production guarantee.
8. **ME-O1 воспроизведён, но не повышен до defect.** Byte-identical owner status/objective harness повторён с отдельными review CAS/output roots: genuine assumption_failed point=50 остаётся policy_value=50 без status notes; uncertainty fallback statistical=1, ConfidencePass blocker. Failure claim имеет **contested / review_required / research_artifact**, counterevidence и refusal status. Full typed evaluator, ObjectiveStack, selection и publication не выполнены.

## Исправление audit evidence

В owner `FINDINGS.json` поле ME-O1 preserved_guard ошибочно переносило success-метку `internal_only` на failure claim. Raw evidence уже содержал правильный `review_required`; основной report failure paragraph не утверждал internal_only. Owner исправил эту текстовую метку, уточнил success/failure scope основного report и добавил validator assertions для contested/review_required/research_artifact, counterevidence и blocked reasons; checksums пересвязаны. Final `INPUT_BINDINGS.json` фиксирует исправленные bytes. Это correction отчёта, не remediation продукта и не новый finding.

Также original GE Git fixture в доставке без `.git` не является готовой повторной Git history: in-place `probe_docs_gate.py` может сначала принять already-present source в baseline, затем упасть на existing directory. Нужен новый output/clean fixture. Наш guard harness для восстановления отсутствующей `.git` явно staging-ит только baseline file и допускает existing source directory. Freeze не включает `.git`; источник доказательства actual first run сохранён в result/log, не обещается byte-identical Git commit timestamp.

## Rubric и evidence matrix

- [x] Отрицательный Git результат различён с настоящим пустым change set: реальный subprocess и восстановленный positive control. GE-01 survives.
- [x] Проверен read root, а не только label/requested argument: actual parser path/hash и reverse control. GE-02 survives с alternate-root scope.
- [x] Численный expected result не взят из producer helper: независимые contrasts, CR0 sums, reweighting functional, отличный scalar target и finite-B law. Данные остаются synthetic.
- [x] Guards проверены различающими mutations/removals; replay consistency отделена от independent method validity и authority.
- [x] Source и input bytes сверены; supported/native/hosted/whole-job omissions названы явно. Это integrity qualification, не product PASS.

| ID | Root control | Вход → наблюдаемый sink | Диспозиция | Ограничение |
|---|---|---|---|---|
| GE-01 | check_docs_gate.py:279–354,650–670 | unavailable ref → empty path plan → main exit0 | reportable, high bounded, P2 | no hosted execution/whole-CI bypass |
| GE-02 | architecture_import_graph.py:149–223 | requested candidate root → global checker-root shim scan | reportable, high bounded, P2 | full aggregate/native dynamic/cycle UNRUN |
| GE-03 | check_docs_gate.py:619–635 | two facade paths + one matching README → no obligation | reportable planner weakness, P3 | per-facade intent; no semantic text freshness |
| GE-C01 | decomposition_preflight.py:18542–18561 | default live=False → no timing call | coverage gap | no actual latency or hosted env conclusion |
| ME-O1 | policy_runtime_metrics.py:102–197 | failed report point → local policy metrics | observation only | objective uncertainty/authority guards remain; full consequence unproven |

## Guard trace и production граница

Source `_run_primary_causal_job` (`run_causal_evaluation.py:480–579`) binds observational ref to request, calls run_job, reloads bound data, applies diagnostics to current and bound inputs, applies staggered target, then reconciles persisted/offered peers with source/spec. Review traced this real ordering; **не исполнил весь function**. Our selected guards use unchanged source bodies and real numerical/CAS/report dependencies but SimpleNamespace job/context/request collaborators. Full JobResult, admission, evidence producers, full node and engine remain UNRUN.

Production evaluator trace (`policy_runtime_support.py:829–959`, `objectives.py:1182–1238,1664–1695`) supplies counterevidence to an alleged ranking/authority bypass. Exact `_resolve_uncertainties(None, failed_report)` is executed, full ObjectiveStack constraint application is source-traced only. It would be incorrect either to promise production safety from this fixture or to report a publication exploit from a locally surviving point.

Original scientific tests were read, including selected-participation functional/finite-B controls and actual-job diagnostic tests. They are useful intended tests; neither their presence nor the selected file/definition count is runtime acceptance. Authored pytest and independent statistical coverage experiment remain UNRUN.

## Environment и instrument honesty

- Python 3.12, actual NumPy/Pydantic installed locally; repo contributor baseline Python3.14. Existing compatibility loader rewrites and namespace skips retained and hash-bound. No installs, native-profile repair, source/test/config edits, remote calls or deployment.
- Docs gate whole module uses namespace-only tools.lib initializer skip. Shim/timing replay compiles exact source fragments; shim parser is ast.parse of valid synthetic syntax, not native failure semantics.
- Method guards use selected AST bodies. Causal ConfidencePass uses existing harness module minus one simulation-source import; missing symbol remains unbound. Simulation-source admission cannot be claimed.
- Initial fresh-reader assertion mistakenly assumed the single blocker of the old fixture. New wider-CI fixture correctly returned an extra CI_RATIO blocker. Assertion now checks exact previously persisted issue list plus required candidate blocker; diagnostic failure logs preserved.
- A second reviewer assertion assumed internal_only for failure claims; raw projection showed contested/review_required. Assertion now verifies those exact refusal facts and nonempty counterevidence. Logs preserved, owner evidence wording corrected. Neither failed assertion was a product bug or discarded adverse outcome.
- Initial manifest validator также ошибочно запрещал literal internal_only даже в явном success-only уточнении corrected owner text; заменён точным assertion обоих scoped clauses. Initial validation log сохранён.
- Dispatcher `foundry_method_dispatch_metric_record_failed(TypeError)` and an enum serialization warning are retained. They do not cancel numerical controls but observability is not qualified.

## Files и повтор

`guards_results.json`, `methods_results.json`, `reopen_status_results.json`, `status_results.json`, `objective_guard_results.json` содержат deciding outputs. `review_guards.py`, `review_methods.py`, `review_reopen_status.py` содержат commands. Own CAS bytes included; owner source/results remain unchanged except the requested audit wording correction.

Для нового исполнения использовать отдельный sibling output directory under audit root, копируя scripts и сохраняя доступ к pinned `../source`, `../next_method_execution`, `../next_method_admission`, `../next_publication_authority`. Последовательно:

1. `PYTHONDONTWRITEBYTECODE=1 python review_guards.py`
2. `PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 POLISYOS_AUDIT_CHAIN_ENABLED=0 python review_methods.py`
3. Та же environment → `python review_reopen_status.py`.

Каждый script сам привязывает mutable history к review directory. `validate_review.py` предназначен для current audit layout и final manifest generation, не заменяет execution. При сохранении frozen evidence не перезаписывать его новыми runs.

`INPUT_BINDINGS.json`, `SOURCE_VALIDATION.json`, `ENVIRONMENT.json`, `VALIDATION.json`, `MANIFEST.json`, `SHA256SUMS.txt` фиксируют final bytes и границы. `.git` и cache directories исключены из whitelist. **Frozen review завершён; общий audit и remediation не завершены.**
