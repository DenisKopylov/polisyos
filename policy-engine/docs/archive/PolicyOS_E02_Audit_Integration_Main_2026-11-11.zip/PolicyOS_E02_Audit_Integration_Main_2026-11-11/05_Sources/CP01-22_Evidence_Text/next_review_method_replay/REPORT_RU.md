# Независимая проверка method admission и run replay

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Проверены замороженные `next_method_admission` и `next_run_replay`; product source и исходные owner fixtures не изменялись. Все новые записи и fault controls находятся в этой папке.

**Вывод: существенные локальные находки подтверждены. Исправлений severity/достижимости в итоговых owner reports не требуется. Общая готовность продукта остаётся PARTIAL, native/release acceptance отсутствует.**

Собственные проверки воспроизвели metadata-only cache drift, потерю bounds/contracts, nested target failure, wrong-callable execution с неверной атрибуцией history, previous-state/base mismatch, неполный manifest lineage и потерю CAS ownership configuration при обычном hook restore. Отрицательные контроли сохраняются: строгий method selector отвергает mismatch; checkpoint scope reconciliation отвергает чужой tenant; повреждение старой invocation записи и отсутствие base честно блокируют replay. Это не обход всех admission/custody gates.

## 1. Метод и степень независимости

- Прочитаны реальный source, fixtures, loader, deciding scripts, outputs и границы claims обоих владельцев. Согласованы freeze notifications; после freeze owners не редактировались reviewer.
- `probe_methods_independent.py`: собственный fixture module, новый SQLite, отдельные writer/read processes, значения и method identities отличаются от owner. Использованы настоящие registry/cache/catalog/ranker/dispatcher/selector; общий compatibility import harness переиспользован, не выдан за native execution.
- `probe_checkpoint_independent.py`: новый scoped CAS, новые states, прямой producer/materializer; новые normal hook export/restore и factory-scope countercontrol. Никаких fake CAS success.
- `probe_history_independent.py`: новый RunContext, три real started/completed pairs; instrumentation считает реальные вызовы, затем вызывает исходные функции. Старый blob повреждается только в reviewer fixture и восстанавливается в `finally`.
- Проверена целостность всех файлов из замороженных owner checksums и manifest, а source union сверяется с pinned Git blob identities. Это binding входов, не утверждение, что каждый импортированный модуль семантически reviewed.

Источник собственного исполнения: Python 3.12.14, не supported 3.14. In-memory adaptation multi-except/TypeVar, namespace skips и compiler lazy facade задокументированы владельцами и в `*_loader*.json`. Registry, cache, catalog, ranker, dispatcher, checkpoint, ownership и history predicates не заменялись. Scope-factory intervention применяется только в явно помеченном countercontrol. `POLISYOS_AUDIT_CHAIN_ENABLED=0`; основной RunContext trace работает. В method stderr сохранены warnings `foundry_method_dispatch_metric_record_failed error_type='TypeError'`; observability integration не квалифицирована.

## 2. MA-01: cache semantics подтверждены, но scope finding ограничен

**Verdict: подтвердить P2 candidate-consistency finding.** Evidence: `methods_read_metadata.json`, `methods_read_signature.json`, `methods_read_baseline.json`.

Независимый baseline writer сохраняет три метода. Metadata reader импортирует тот же FQN/signature, но с отсутствующей required dependency и `artifact_emission`. Настоящий `is_cache_valid(live_registry)` возвращает true. Cached entry остаётся runnable с effects=none и находится в ranking; текущая fresh entry нерunnable, missing-dependency, ranking пуст. Callable действительно загружен из нового process profile. Это проверяет metadata omission, а не всего лишь schema-only default.

Контрпример к завышению: при signature fidelity drift live validation возвращает false. No-argument `is_cache_valid()` по собственному API лишь проверяет schema; его true не самостоятельный security defect. `cache.py:270–305,374–391` и `catalog/snapshot.py:117–178` соответствуют наблюдениям.

Собственный codec: output bounds `(2,4)` превращаются в `(None,None)`, ABI digest одинаков. Проверка совместимости с target bounds `(50,60)` теряет warning о непересечении. `_signature_matches` всё же возвращает false для complete binding. MethodContracts пропадают, но настоящий class остаётся исходным. **Не установлен обход executable decorators/strict contracts.** Persistable-subset disclaimer не делает потерю composition diagnostics невидимой, однако не позволяет обещать, что cache является полным execution contract. Исправление должно разделить versioned semantic payload и stable compilation ABI, сохранить легитимные component overlays.

Owner census не нашёл application consumer persistent cache. Независимый literal scan подтверждает отсутствие `RegistryPersistenceLayer` вне owner/facade в `src/polisyos`; динамический/внешний caller этим не исключён. Public finite cache→catalog path реально исполняется. Production startup, published authority и реальная научная точность не доказаны.

## 3. MA-02 и MA-03: lower boundary допускает mismatch, stricter routes не сломаны

**MA-02: подтвердить P2 lower-boundary inconsistency.** Собственный normal Add для x=6 возвращает 9. Lazy registration под Add FQN возвращает Subtract class; настоящий NumPy dispatcher выдаёт −3 и записывает success за Add. Это конкретный numeric/history oracle, а не сравнение двух hashes.

Сохранённый контрконтроль `select_method_for_input_contract` реально записывает `actual_callable_signature_mismatch` и `input_contract_method_member_unreadable`. Default bootstrap дополнительно incomplete из-за DuckDB. Нельзя этот negative превратить в successful full selector positive. Governed catalog отказывается от preexisting membership. Owner bridge wrong-FQN и compiled-chain negative outputs соответствуют source; positive heterogeneous chain blocked на JAX. Scientist metrics guard просмотрен в source, не исполнен.

`registry.py:788–809` не reconciles factory return; catalog использует entry declaration и actual class вместе; низкий dispatcher принимает явно поданные class/signature. Ошибка условна на inconsistent supplier/stale mapping, не normal admitted component production path. Reuse canonical full binding + typed admitted identity разумнее, чем новые per-caller hashes. Aliases должны быть explicit.

**MA-03: подтвердить P3 persistence defect.** Собственный module-level `Container.Inner` записан и counted restored, но lazy get даёт AttributeError. Flat Add из той же БД загружается и исполняется. Это не `<locals>` closure и не arbitrary-import exploit. `getattr(module, qualname)` не проходит сегменты. Малый shared qualified-target resolver либо upfront unsupported-target refusal достаточен; новый plugin subsystem не нужен.

## 4. RR-02: независимый state oracle и manifest closure

**Verdict: сохранить P2 conditional on mismatched producer inputs.** Собственный old base содержит stable=10. Переданный previous state и новый intended state содержат stable=20, меняется только tick. Writer принимает pair, CAS integrity true, materializer возвращает stable=10. Normal pair roundtrip точен. Evidence: `checkpoint_independent.json#/mismatch`.

Это не hash corruption. `create_checkpoint:2089–2101` вычисляет delta по caller-supplied previous_state и связывает его с независимо supplied previous ref. Normal hook обновляет state/ref вместе; reviewer не доказал самопроизвольное нарушение normal in-process flow, production incident или wrong published policy. Owner direct hook reproduction расширяет доказательство API, но также явно вводит mismatched initial pair.

Manifest lineage имеет отдельный observable consequence: normal incremental checkpoint имеет `inputs=[]`. Реальный generic graph до и после удаления required base: nodes=1, edges=0, complete=true. Materializer после удаления отказывает `CheckpointCorruptedError: ... blob missing`; bytes восстановлены, state снова верен. Это ошибка checkpoint producer dependency contract, **не ложь graph owner о своём manifest.inputs traversal**. Production GC deletion не установлена.

RR-02 допустимо оставить одним локальным umbrella finding у checkpoint owner, но repair acceptance должен отдельно закрывать: previous-state/ref binding; ancestor run/origin/sequence/depth continuity; explicit selected manifest edges; независимый reader depth bound. Один fix state digest не исправит graph closure, а одни inputs не свяжут state bytes. Не создавать четыре новых глобальных defect count без дедупликации.

Owner foreign-run/workflow и understated-depth controls подтверждены scripts/source/result binding, reviewer не повторял длинную цепочку. Truthful writer policy делает full на 7/14; retention может превышать target max из-за live dependencies. GC trim local index не означает удаление/ограничение CAS bytes.

## 5. RR-03: ordinary restore действительно теряет custody configuration

**Verdict: подтвердить P2 availability/lifecycle finding, без authority-bypass escalation.** Evidence: `checkpoint_independent.json#/hook_normal_restore` и `#/hook_scoped_factory`.

В независимом hook scenario metadata не менялась, что проверено digest до/после. Исходный CAS constructed только с tenant/cell без принудительного enforcement override. Restore меняет `tenant=independent-review` на None, enforcement=true на false. Producer возвращает следующий checkpoint ref, исходный scoped reader его отвергает `ArtifactOwnershipError`.

При передаче тех же admitted tenant/cell через уже существующий factory API restore сохраняет enforcement и exact desired params читаются. Это ограниченный causality discriminator, не product patch и не разрешение доверять arbitrary metadata scope. Отдельный контроль изменяет metadata tenant на foreign: реальный restore отказывает `CheckpointScopeMismatchError`. Сам scope reconciliation не отсутствует; потеря происходит ниже, при constructor `build_artifact_store(store_config)` (`checkpoint.py:1523–1545`), хотя factory принимает tenant/cell (`config.py:51–72`).

Source `_activity_worker.py:455–462,514–543` действительно связывает runtime restore с merge/checkpoint. Реальный worker/Ray/Temporal execution не запускался. Full resume в owner controls остановился на missing DuckDB. Никакого успешного чужого tenant read, HTTP auth bypass или published policy не показано.

## 6. RR-01: стоимость реальна в измеренном слое

**Verdict: medium capacity risk, composition witness углубляет ST-02, не новая независимая storage family.** Независимая серия H=2/H=3 дала 12/18 invocation loads; каждый из 4/6 unique invocation records загружен ровно три раза. Fresh CAS object читает все 3 attempts. Повреждение oldest basis немедленно отказывает `run_invocation_record_cas_invalid`, после exact bytes restore снова 3 attempts. Evidence: `history_independent.json`.

Owner 32-attempt results и counters сверены: 192 invocation loads, 895 verify, 2 047 manifest reads; суммарно 336 411 374 bytes через instrumented Path.read_bytes. **Это bytes, возвращённые Python API при повторных чтениях.** Не измерены physical media IO/page-cache misses, disk latency, cloud cost, production throughput, p95 или SLA. Wall time включает instrumentation и конкурирующую нагрузку. Увеличение H в синтетическом owner run не показывает количество reader calls в actual workflow.

Memo source действительно кеширует `_load_run_invocation_record` по selected ref/profile и run-manifest context и сокращает real loads 192→64. Equality digest включает basis/outcome/ref semantics. Но cache живёт через measurement и дополнительную equality read, внутри immutable fixture; corruption control начинает новую cache invocation. **Это не proof безопасного request/process cache при mutation/revocation внутри read.** Owner warning точен. Сохранять full integrity controls и generation/scope fences обязательно; удаление старой истории ради цифры green не допустимо. Reviewer не повторял полный 32-case cost wave и не объявляет prototype исправлением.

## 7. Итоговые оси и дальнейший acceptance

**Specification/evidence reporting:** локальные statements, evidence classes и limitations у owners согласованы; независимые distinguishing controls подтверждают ключевые нарушения. Дополнительных обязательных corrections нет.

**Engineering/product:** обнаруженные candidate/persistence/replay invariants нарушаются на указанных API. Общий verdict PARTIAL_WITH_LOCAL_FINDINGS; native 3.14, installed backends, true admitted discovery, strict execution positive, distributed worker, production incidence, scientific authority и publication остаются unqualified.

Существующие механизмы следует расширить: Foundry semantic codec/admitted method binding; checkpoint state/base/lineage contract; scoped artifact factory; validated read context у Core. Не нужны параллельный registry, новый CAS или замена SQLite. Последующий repair должен закрыть положительные и отрицательные counterparts на supported runtime, а не только текущие synthetic numbers.

Reproduction: сначала writer, затем три fresh readers по `REVIEW_PROFILE=baseline|metadata|signature`; checkpoint/history scripts запускаются по одному. Требуются sibling `source`, `next_method_admission/probe_import.py`, `next_publication_authority/compat_loader.py`, `next_run_replay/compat_loader.py`. Для повторного запуска новых CAS fixtures используйте новую sibling review directory; scripts отказывают при существующих state/history. Не удалять архив evidence ради rerun. `verify_review.py` только читает owner inputs/source и пишет review validation. Точные команды, hashes и checks в `VALIDATION.json`, `INPUT_BINDINGS.json`, `SOURCE_VALIDATION.json`.
