# Независимый review: сборка исполнимой policy

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Объект: `next_policy_assembly`. Проверка выполнена 11 ноября 2026 UTC. **Итог продукта: PARTIAL; качество доказательств данного review: PASS_BOUNDED_REVIEW, 54/54 проверок согласованности.** Число проверок не является покрытием продукта. Production source и исходные findings не изменены.

## Решение

- **policy-assembly::PA-01, P2: подтверждён в исходных границах.** Независимые fixtures, новый CAS и настоящий public compiler воспроизводят потерю выбранной executable identity. Изменение допустимого inventory меняет kernel старого сохранённого plan. Semver, порядок регистрации, namespace collision и fidelity drift отделены противоположными controls.
- **policy-assembly::PA-02, P2: подтверждён в исходных границах.** Money USD проходит unit-aware public compile, после CAS reopen превращается в dict threshold и отвергается настоящим evaluator. Это отказ исполнения допустимого typed input, не ложное разрешение ограничения.
- **Новых глобальных findings: 0.** Дополнительные controls углубляют эти два локальных механизма, не создают новые SYS-семьи. MA-01/02, lexical loss и welfare arithmetic повторно не считаются.
- **Scientific/authority qualification не установлена.** Native Python 3.14, полный numerical graph, source admission этого результата и publication не запускались.

Уточнение к чтению исходного отчёта: `_resolve_planned_method_identities` является сборщиком идентичности/ограничений, а не доказанным blocking admission gate. При несовпадении method version он возвращает limitation, а не выбрасывает отказ наружу. Вывод «op nodes не получают этот capture» подтверждён; вывод «соседняя method ветка тем самым гарантированно блокирует исполнение» здесь не делается.

## 1. Независимость и сохранность

Review не переисполняет producer assertions как своё доказательство. `probe_independent.py` создаёт другие методы `review.assembly.debit/service`, другие параметры, отдельный typed TrinityBundle и собственный `cas/`. Использованы реальные compiler, linker, registry, lowerer, graph builder, conflict checker, CAS, constructor и constraints evaluator. Синтетические kernels отличаются только конечным коэффициентом, без экономического или институционального смысла.

Повторно использована только задокументированная import plumbing из `next_policy_assembly/probe_import.py`, `constraint_import.py` и `next_publication_authority/compat_loader.py`. Её хеши и фактические импортированные модули сохранены. Она адаптирует Python 3.14 syntax/TypeVar к доступному Python 3.12, пропускает eager facades и извлекает неизменённые enum/numeric definitions из JAX-heavy владельцев. Решающие selection/compiler/evaluator predicates не подменялись.

`SOURCE_VALIDATION.json`: 202 реально импортированных, извлечённых или семантически прочитанных source/test/instruction files совпадают с pinned Git blobs. `INPUT_REVALIDATION.json`: все 645 ранее зафиксированных файлов исходного audit bundle остались byte-identical. Это квалификация проверенных inputs, не утверждение о семантическом review всех 202 файлов. Полный исходный text-search census 2 895 `.py` переиспользован как неизменённый inventory; он не назван dynamic call graph.

## 2. PA-01: identity, semver и стабильность

Новый fixture строит два mechanism types: `review_debit` и `review_service`, amount=7, выбранная fidelity=fluid. Реальный public compile возвращает selected profiles для policy, registry и ExecPlan. Baseline kernels выдают −7 и −21.

Проверки в `independent_results.json`:

1. Добавление unrelated method с отдельным runtime type не меняет ни один constructor result.
2. Добавление согласованного eager FQN `review.assembly.debit@2.0.0`, без override, меняет debit delta на −49; service остаётся −21 с тем же descriptor/payload.
3. Повторная компиляция того же TrinityBundle возвращает равные LoweredIR, ProgramGraph и **тот же полный selected ExecPlan ref**, не только content digest.
4. Все шесть порядков регистрации версий 1/2/10 выбирают descriptor `@2.0.0`; canonical explicit `ResolutionPolicy.LATEST` во всех шести выбирает `@10.0.0`. Это lexical last-write-wins projection, не случайность insertion order и не требование всегда выбирать newest.
5. Новый namespace `zz.review.debit@0.0.1` молча перекрывает тот же runtime type.
6. Duplicate exact FQN по-прежнему отвергается. Этот guard не решает many-FQN→one-type collision.
7. При hard-only v2 старый fluid payload успешно создаёт kernel с неподдерживаемой fidelity. Отдельные настоящий resolver и public compile с явным surrogate_fluid эту комбинацию отвергают.

Четыре отдельных процесса `probe_fresh_reader.py` читают один и тот же сохранённый selected plan и lowered refs. Baseline возвращает −7, v2/hard возвращают −49, unrelated service во всех случаях −21. Это fresh-process consumer evidence, а не только сравнение mutable объектов одного процесса.

### Kernel stability discriminator

Четвёртый reader сохраняет тот же FQN, descriptor и wrapper source, но меняет **только alias в синтетическом fixture module**, на который указывает importable kernel path. Он также возвращает −49 вместо −7. Файлы product/fixture не меняются. Этот control показывает, почему строка module:symbol и hash wrapper class не являются hash исполняемого kernel/dependency closure. Он не доказывает deployment exploit или отсутствие внешних build attestation guards.

`probe_identity_boundary.py` исполняет точную extracted definition `_resolve_planned_method_identities` с настоящими imported constants. У реального compiled graph все шесть узлов имеют kind=op, и capture возвращает пустые identities. Противоположный typed method control захватывает FQN/ABI/class digest; wrong method version даёт limitation. После изменения synthetic kernel alias class digest не меняется и честно имеет scope=`class_source_only`. Эта граница не должна превращаться в обещание полного build identity.

Причина в source: `runtime_registry.py:254–294` использует словарь по runtime type поверх sorted FQNs; `_lowering.py:194–296` сохраняет параметры/fidelity, но не выбранный method/kernel binding; `_graph.py:38–88` создаёт op/apply_mechanism. Consumer `graph/__init__.py:3911–3978` повторно вызывает тот же constructor по type. Выбор механизма действительно достигает используемого executor callsite по source; сам numerical executor не запущен.

## 3. PA-02: typed threshold roundtrip

В новом public compiler fixture MoneyValue(10 USD) принят против USD constraint registry. При чтении LoweredIR `expected` имеет форму `{amount: "10", currency: "USD", nominal_year: null}`. Полный constraints evaluator отказывает с `ValueError: ... has non-numeric value` как при actual=5, так и при actual=20. Все четыре fresh readers подтверждают тот же отказ после persisted reopen.

Противоположные controls:

- Decimal10 при actual20 проходит, при actual5 даёт hard_fail=true.
- Money EUR против USD registry отклоняется linker/compile до runtime.
- Money, Rate(percent), Count, Duration непосредственно как typed expected работают; после actual `_lower_constraints` все четыре дают non-numeric refusal. Rate control использует 20% и actual0.3, а не сравнение несогласованных процентных величин.
- Unknown slot, infinite actual и boolean expected отвергаются.

Source связывает границы без предположений: `_lower_constraints:414` вызывает `_json_value`; `LoweredConstraint.expected` объявлен Any; `_coerce_number:215–240` понимает wrappers, но не dict. `graph:3129–3149` передаёт именно persisted lowered constraints в этот evaluator.

Для Money выполнен полный выбранный compile→CAS→fresh evaluator seam. Для Rate/Count/Duration выполнен lowerer/evaluator seam, не per-unit public compiler acceptance и не физически корректная конверсия calendar duration. Вынимать произвольное поле value/amount без type/unit/base/time contract было бы неправильным ремонтом.

PA-02 нельзя описывать как «constraint silently approved». Source trace дополнительно показывает ValueError в classified failures, fatal severity, default FAIL_CLOSED, abort и public failure envelope. Но весь error-envelope путь здесь не исполнялся. Иные direct graph strictness modes не квалифицированы.

## 4. Реальные guards и пределы композиции

`countercontrols.json` независимо подтверждает joint assembly двух механизмов, отдельные single alternatives и одинаковые constructor outputs после перестановки interventions/bindings. Amount bounds, kind/binding mismatch, unsupported compile fidelity и объявленный в IR type без kernel отвергаются. Реальный conflict checker различает SUM от ERROR multiple writers.

Unknown parameter не является compile error: получено ok=true с `link_warning:unknown_param`, после чего реальный constructor отказывает. Этот warning не засчитан как успешная verification параметра и не добавлен отдельным finding: producer уже явно ограничивал этот случай.

Это ограниченная функциональная композиция двух synthetic resources. Не проверялись causal interaction, joint SCM simulation, welfare ordering, alternative ranking, resource scarcity, jurisdiction overrides, uncertainty/calibration, transportability и stability прогнозируемых эффектов. Runtime patch не доказывает `P(Y|do(X))`.

## 5. Stability kernel и execution authority

Для минимального устойчивого execution contract на этой границе нужны:

- явный unique либо versioned type→method выбор с отказом при неразрешённой ambiguity;
- сохранённый immutable binding выбранного method/kernel и относящегося к нему build/runtime profile;
- проверка consumer на совпадение сохранённого binding и supported fidelity до patches;
- единый versioned codec thresholds, сохраняющий units/base/time semantics;
- неизменные unrelated resources и противоположные отказные controls;
- отдельная квалификация scientific validity и institutional authority.

Ремонт следует делать у существующих owners MethodRegistry/runtime descriptor/compiler IR и constraints codec. Не требуется новая параллельная ModelRegistry. Binding source/build identity должен иметь честно объявленную область: wrapper-only source hash не включает imported kernel, helpers или environment автоматически.

Native execution/source admission остаются самостоятельными acceptance gates. Public execute перед graph читает state/input bindings и registry, а admission результата сверяет selected profiles и provenance edges. Review не вызывает эти пути с настоящим produced state/simulation result. Наличие compiled plan, selected CAS manifest и executable kernel не является допуском результата к научному или публичному authority.

Built-in `RUNTIME_MECHANISM_METHOD_AUTHORITY_SCOPE` явно не удовлетворяет method obligations causal estimation, assumptions, uncertainty, distributional evidence и objective tradeoffs. Review не опровергает эти ограничения, не показывает publication/approval bypass и не утверждает безопасность опубликованной рекомендации.

## 6. Среда и reproducibility

Команды выполнялись из данного каталога с `PYTHONDONTWRITEBYTECODE=1`:

- `python probe_independent.py`: PASS, новая registry/compile/CAS/constructor и typed constraints цепочка.
- `python probe_fresh_reader.py baseline|v2|hard|kernel_drift`: четыре отдельных PASS.
- `python probe_identity_boundary.py`: PASS для exact extracted leaf и противоположных method controls.
- `python probe_countercontrols.py`: PASS для composition/guards/numeric discriminators.
- `python build_review_evidence.py`: PASS, 202 source files и 645 неизменённых primary artifacts.
- `python validate_review.py`: PASS_BOUNDED_REVIEW, 54/54.
- Native import public compiler: отказ Python3.12 на Python3.14 multi-except syntax в store.py. Это environment limitation, не новый product failure.

Python 3.14 и JAX/chex/pytest отсутствуют в используемом профиле; зависимости не устанавливались. Pytest bodies не выполнялись. Четыре named test files осмотрены: наличие constructor/Decimal tests и mocked lowering guards не заменяет adversarial roundtrips; отсутствие подходящих tests во всём репозитории не утверждается.

Сохранены первоначальные instrument outcomes: serializer warning от synthetic model_copy исправлен typed validation; leaf extraction первоначально не передал canonical constant; один unknown-parameter fixture первоначально не передал artifact schema. Исправлены только review scripts. Первые logs retained, product failures из них не выводятся.

## 7. Scoped IDs без переписывания истории

Исходный `next_policy_assembly/FINDINGS.json` оставлен с PA-01/PA-02. Для cumulative synthesis используется:

- `policy-assembly::PA-01` → next_policy_assembly / PA-01;
- `policy-assembly::PA-02` → next_policy_assembly / PA-02;
- `publication-authority::PA-01` → next_publication_authority / PA-01.

Последний описывает иной private-draft canonical roundtrip и не был заново квалифицирован данным review. Scoped alias устраняет коллизию ссылки, но не является новой finding и не решает глобальную root-cause дедупликацию. `SCOPED_FINDING_IDS.json` хранит точные source bindings.
