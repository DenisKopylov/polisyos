# Независимая проверка publication authority и registry dataflow

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Проверены PA-01 и RD-01, их исходные измерители, сохранённые результаты, первичные source bodies, ближайшие producers/consumers и существенные контрмеры. Source и исходные audit-каталоги не изменялись.

**Итог: PARTIAL. PA-01 сохраняется как локальная fail-closed несовместимость writer/reader. RD-01 сохраняется как незамкнутый semantic join, но aggregation-часть требует более узкой формулировки. Ни scientific error на реальных данных, ни authority/publication bypass, ни native qualification не установлены. Новых SYS-семейств нет.**

Этот review независим по чтению и интерпретации, но не является новым runtime replay: изучены сохранённые execution evidence; новые product/probe executions не запускались. Свежая проверка 21 source-файла против Git pin, 106 файлов исходных evidence, retained draft digest и constructor/marker census завершилась успешно. Все 21 файла совпадают с pin, tracked source чист.

## 1. PA-01: две разные несовместимости одного round-trip

**Первая причина подтверждается непосредственно source и retained bytes.** `GovernedPublicRecordOwner._put` (`governed_public_record.py:466–474`) записывает `_bytes(value)` через `put_bytes`, задавая kind/media/schema без `canon`. Retained draft SHA-256 совпадает с actual ref; исходный manifest не объявляет canon. `_read` (`:476–493`) вызывает строгий `validate_core_model_json_artifact`, а тот требует declared profile (`canonical_profile.py:2517–2540`). CAS integrity не заменяет canonical declaration. Первый prepare ещё пользуется in-memory DTO, повторный prepare читает сохранённый ref (`:1145–1173`). Поэтому сохранённые результаты первого успеха и повторного/fresh-process отказа `canon_profile_absent` согласуются с реальным control flow.

**Вторая причина независима от первой, но показана counterfactual control, а не штатной publication.** `_PrivateDraft.public_document` имеет тип `dict[str, JsonValue]` (`:207–214`). `_source_leaves` намеренно сохраняет raw codec исходного ledger, включая tagged timestamps (`:370–372`). Retained JSON действительно содержит `public_document.ledger.events[0].occurred_at={"_type":"datetime","iso_utc":...}`. Запись тех же bytes через штатный `put_json` с Core canon 0.2.0 объявляет профиль; recursive decoder восстанавливает datetime (`common/canonical.py:970–1009`). Typed reader затем отклоняет этот Python-объект как не-JsonValue. Сохранённый `profile_control.json` подтверждает: raw bytes совпали, raw `_PrivateDraft.model_validate_json` прошёл, declared-profile read дал `invalid-json-value`.

Не следует писать «два независимых production incidents» или «достаточно заменить put_bytes на put_json». Это два последовательных дефекта совместимости одного контракта. Проверенный counterfactual использует конкретный Core profile 0.2.0; он не доказывает, что никакой корректный профиль/кодек не возможен. Нужен согласованный writer/reader, сохраняющий raw nested document, exact bytes/digest и selected manifest identity. Нельзя удалить strict profile gate ради зелёного теста.

`_issue` повторно читает draft даже при первом prepare (`:1290–1307`), но до этого имеет независимые guards. Поэтому наличие первой успешной private preparation не означает, что подписанный public record выпущен. Для других payloads, которые пишутся тем же `_put`, есть статический sibling-risk, но их отдельные runtime failures этим review не установлены.

### Источник полномочий и нативность PA

Исходный probe использовал реальные FileSystemCAS, `_RepositoryClaimLedgerOwner`, head/root readers и GovernedPublicRecordOwner. Но appointment обеспечивали repository `_FixturePolicyResolver`, `_FixtureRootIssuer`, `_FixtureIssuanceVerifier` и synthetic mandate; packet schema также тестовая. Наличие этих настоящих product bodies не превращает fixture authority в институциональную.

Дополнительные ограничения:
- Python 3.12.14 вместо supported 3.14, Pydantic 2.13.4 вне repo bound; compatibility rewrites multi-except/TypeVar и namespace-package bridges записаны в исходном evidence. Это не native import и не pytest/locked-profile lane.
- Production default `build_default_claim_ledger_owner` возвращает `UnappointedClaimLedgerOwner` (`head_index.py:4532–4535`). Candidate persistence и labels не создают current root.
- Publication deployment-root marker default false (`:447–449`), а `_require_public_read_root_custody` fail-closed (`:658–664`). Literal census всех 2895 Python source files обнаружил только инициализацию false и чтение этого marker, не production setter. Census не является доказательством отсутствия любых внешних injection/configuration paths.
- Current snapshot, exact packet/run, historical replay, public eligibility и unchanged source перечитываются (`:1107–1189`, `:1335–1340`). Signer, mandate, trust epoch, issuer/purpose, revoked-key и exact mandate binding отдельны от статуса publishable.
- Сохранённые негативы mandate digest/scope/ledger/key/time выполнены прямым вызовом predicate. Полная signature admission после PA-01 не достигнута. Проверка этих негативов не равна успешному issue.

**Сохраняемый impact:** configured private draft нельзя повторно открыть; предусмотренная подготовка перед mandate/issuance не завершается в данном ограниченном контуре. Это availability/replay correctness, не выданная ложная authority. Native частота, deployed impact и successful publication остаются UNRUN.

## 2. RD-01: что точно доказано, а что пока не следует

### Три уровня aggregation

1. **Смысл raw значений.** Provider/definition определяет, являются ли 2 и 6 отдельными измерениями, частичными взвешенными вкладами или уже агрегированными величинами. Исходный fixture использует общее описание «A measured scalar used by the selected model port», а не научное определение арифметического среднего двух наблюдений.
2. **Raw-row ingestion operator.** `derive_canonical_observations` группирует строки по country/year/survey_year/wave/condition_json и применяет `registration.field_binding.aggregation_method` (`overlay.py:4303–4324`). Replay независимо повторяет этот finite operator (`variable_binding.py:811–827`). Для выбранного fixture sum(2,6)=8, и occurrence хранит aggregation_method=sum. Это действительный producer, не заранее подставленное значение 8.
3. **Measurement representation.** `VariableRepresentation.aggregation` является axis представления величины вместе с grain/time_support/population (`:407–456`). Ни DTO, ни просмотренная спецификация не устанавливают универсальный закон «representation aggregation обязана буквально равняться raw-row ingestion operator». Сумма частичных взвешенных вкладов может законно представлять среднее; identity ingestion может переносить уже готовое provider mean. Это логические контрпримеры, не выполненные product positives.

Следовательно, **фраза «система должна получить 4, но получила 8» не доказана без определения raw values и relation/composition law**. Сравнение 8 и арифметического 4 различает операции, но само по себе не устанавливает intended measurement. Нельзя чинить все случаи безусловным равенством строк aggregation.

При этом механический пробел реален: `_compare_axes` сравнивает только source и target representation declarations (`:1151–1193`); `evaluate_scoped_correspondence_basis` связывает occurrence с source/refs/scope/unit, но не representation aggregation с operator/occurrence (`:971–1030`). Поэтому две mean declarations дают candidate/recomputed рядом с sum occurrence, без явной typed composition или отдельного неизвестного статуса для этого cross-join. **Сохранять RD-01 следует как отсутствие доказанного representation↔occurrence semantic binding; конкретная numerical misbinding остаётся needs-review.**

Важное уточнение output semantics: `recomputed_axes` заполняется именами сравнивавшихся required axes даже когда значения не равны (`:1181–1183`), и сохраняется также в refused result (`:1032–1038`). Само наличие aggregation в tuple не значит «aggregation verified». Значимы все поля: `status`, `semantic_correspondence`, `refusal_codes` и limitations. Runtime проверяет candidate и recomputed вместе (`data_state_substrate.py:1008–1018`); Foundry проверяет candidate (`bindings.py:2809–2814`). Нельзя трактовать один список как самостоятельный authority receipt.

### Population cross-join

Две representation populations `population:other` могут совпасть между собой, тогда как occurrence.source_scope и port.scope оба `population:test`. Required axis проверяется только между declarations. Это более прямой внутренний inconsistency witness, чем 8 vs 4: поля population_ref существуют по обе стороны, но отсутствует reconciliation между ними. Однако если допускаются wider measurement population и scoped subset, понадобится явный relation rule, а не произвольная одинаковость всех scopes. Полная спецификация сама требует relation-specific scope rules (§3.4).

Реальные scope protections сохраняются: occurrence.scope обязан равняться basis.scope; port.scope обязан равняться basis.scope; pre-acquisition owner сравнивает registry source_measure_scope.population с model scope (`acquisition_authority.py:3117–3121`). Эти guards не сравнивают representation.population_ref с ними. Они опровергают формулировку «population вообще не проверяется», но не закрывают выбранный declaration↔scope cross-join.

## 3. Реальный producer, путь потребления и компенсации RD

**Что реально произведено исходным probe:** content-bound field binding, canonical observation и independent raw replay. **Что synthetic:** registration/passport wrappers, exact refs, source/target definitions, representations, model port/profile, initial evidence locators. Source/target representation DTOs взяты из тестового fixture и затем изменены прибором. Это не доказательство штатного production writer, который уже создал неверное metadata.

Literal census `VariableRepresentation(` по всем `.py` в `src/polisyos` обнаружил только определение класса. Это не означает отсутствия deserialization/general CAS writers. Реальный production read path найден: registry entry содержит selected representation ref; acquisition authority перечитывает CAS representation/definition/evidence, проверяет manifest lineage, selected definition и canonical unit (`:1723–1788`), затем source/target axes и source scope (`:1790–1807`). Runtime routing переносит descriptor ref в `AcquiredObservationSemanticInputRequest` (`model_input_routing.py:586–605`). Источник правильности и полномочий первоначального representation author этим review не установлен.

Catalog assessment (`measurement_binding.py:118–205`) перечитывает active admitted source, exact passport/receipt, selected model interface, definition evidence; материализует и сохраняет occurrence, затем вызывает общий predicate. Runtime повторяет выбранные refs/replay/lineage. Foundry снова проверяет source-owner chain, rereads raw bytes, повторяет predicate и сверяет downstream значение. Три вызова одного predicate не создают отсутствующее semantic ребро, но их наличие также не доказывает, что synthetic case прошёл весь путь.

Существенные контрмеры:
- raw replay rejects value tamper, wrong source watermark/row identity;
- exact refs/profile/revision/evidence и source→port scope остаются load-bearing;
- source/target mean≠sum refused;
- required/optional неизвестность не wildcard; ratio/rate требует numerator и denominator axes;
- candidate explicitly сохраняет external_empirical_origin_not_established и source_currentness_not_established;
- Foundry отказывает fixed_multiplicative до replay (`:2766–2767`). Успешные unit conversions в producer/replay не являются complete Foundry execution.

RD-O1 (optional scale) и RD-O2 (binary64 quantization) остаются observations, не отдельными подтверждёнными authority incidents. Нужен source-to-model numerical tolerance contract. Q×N raw-row normalization из сохранённых измерений нельзя переводить в число catalog indicators или production p95.

## 4. Что принять дальше

PA: native prepare→persist→repeat→fresh-process; configured first/second issue; raw tagged nested values; exact bytes/digest/manifest; negative schema/profile/corruption; genuine appointed authority отдельно от test fixtures. Сначала согласовать codec contract, не ослаблять reader.

RD: закрепить meaning of aggregation/population на обоих уровнях и admissible relation/composition; затем настоящий metadata producer + selected CAS refs + admitted source + Runtime/Foundry consumer. Обязательные positives: identity с already-aggregated measurement и поддерживаемая composition. Negatives: ошибочная same-level sum/mean, неверная population, removal именно property-bearing bridge при неизменных IDs. Сохранять candidate/authority separation.

**Specification:** PA — FAIL для private persisted round-trip; RD — PARTIAL, отсутствие cross-join подтверждено, универсальное expected-equality правило не установлено. **Engineering quality:** PARTIAL в обоих случаях из-за native/operational gaps. Security triage отдельно помечена needs_review: поддерживаемый lower-trust attacker→authority boundary не доказан; это не отменяет локальный engineering defect PA.

## 5. Артефакты и freeze

`REVIEW_DECISIONS.json` содержит используемые формулировки и ограничения. `SOURCE_EXCERPTS.json` даёт первичные строки; `SOURCE_VALIDATION.json` — fresh pin verification; `INPUT_MANIFEST.json` — SHA-256 всех 106 файлов двух исходных audit-каталогов. `PRODUCER_CENSUS.json` имеет явный знаменатель и ограничения. `verify_review_inputs.py` выполняет только metadata/JSON/source checks, не импортирует product или старые audit helpers. Команда завершилась exit 0; full/native tests и новое execution reproduction UNRUN. Итоговый `SHA256SUMS.txt` исключает сам себя и `FREEZE.json`; `FREEZE.json` закрепляет digest этого списка.
