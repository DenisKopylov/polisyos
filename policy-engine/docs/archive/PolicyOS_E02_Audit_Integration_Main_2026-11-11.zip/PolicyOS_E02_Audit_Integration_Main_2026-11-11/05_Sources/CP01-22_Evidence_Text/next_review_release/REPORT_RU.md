# Независимая проверка release integrity

**Вердикт: PARTIAL для ширины проверки; FAIL для подтверждённых локальных release-контрактов. Release readiness не установлена.** Проверены REL-01/02/03 из `next_release_integrity` на неизменённом `f1541ed155f278689be48a8c7ac56c3e200210f7`. Три findings сохраняются с уточнёнными границами. Новых defect families в итоговый счёт не добавлено. Source, source tests, исходная evidence lane и внешние системы не изменены.

## Что изменилось после независимой проверки

1. **REL-01: high как приоритет release blocker подтверждён.** Fresh snapshot не содержит обязательный generated input, а workflow его не производит и не переносит. Дополнительно обнаружено, что механическое staging всех текущих fragments недостаточно: producer копирует 548 TOML, checker принимает, но notes renderer падает на единственном fragment без `type` и `summary`. Initial failed run сохранён, контроль удаления ровно этого fragment даёт успешный renderer.
2. **REL-02: high относится к целостности выпуска при ошибочном privileged dispatch.** Проверены точный pinned checkout source и два настоящих Git commits с реальными package metadata внутри обоих commits. При разных tag SHA и selected source SHA resolver и checker проходят. Это не внешняя unauthenticated атака, не доказанный обход environment approval и не наблюдавшийся неправильный опубликованный release.
3. **REL-03: medium остаётся bounded evaluator robustness finding.** Настоящий evaluator принимает missing/wrong-type `matches`. Но Grype v0.99.1 штатно объявляет `matches` и создаёт пустой array для нулевого результата. Настоящие upstream golden JSON различаются evaluator корректно: empty проходит, Critical блокируется. Не установлено, что реальный Grype успешно выдаёт malformed JSON.
4. **Нельзя расширять REL-03 на любую неизвестную severity.** У Grype поле severity опционально; evaluator явно задаёт rank unknown=0. Это policy decision, которое стоит пересмотреть отдельно, а не автоматически доказанное повреждение report schema.
5. **Два соседних замечания не повышены до новых high findings:** unsafe shell interpolation dispatch tag до version validation и чтение fix versions не из того уровня Grype JSON. Первое подтверждено только безопасным local marker, второе влияет на remediation summary, но не отменяет Critical/High block.

## Метод и рубрика

Пять критериев из `VALIDATION_PLAN.md`: provenance; data provisioning; Git/source/input binding; настоящий scanner format и caller; калибровка последствий и counterevidence.

- [x] Source/input provenance проверена до и после; 593 named source paths совпадают с baseline. Это readset, не semantic acceptance каждого файла.
- [x] Полный scoped workflow denominator: 9 release jobs, 7 checkout steps, все declared upload/download steps; census всех 23 tracked `.github` файлов.
- [x] Выполнены product CLIs без переписывания тел, exact shell blocks, disposable Git fixture и различающие отрицательные/положительные controls.
- [x] Реальный Grype model и upstream presenter golden JSON проверены по upstream `v0.99.1`, commit `6e1807dd7130c9eff23c1bad19a96cc6afef33aa`; golden bytes подтверждены Git blob OIDs.
- [ ] Supported/native/hosted release qualification не выполнена. Здесь Python 3.12.14, нет pytest, Grype и Syft. Dependencies не устанавливались. Поддерживаемый baseline Python 3.14/uv 0.9.21 не квалифицирован.

Финальный probe содержит **60 именованных observations**, включая 9 технических Git fixture operations и 6 provenance checks. Это не 60 product tests. Из них 21 отдельный vulnerability CLI control и три shell caller controls с явно подставленным scanner. Initial run exit 1 не спрятан: он выявил notes failure, а не общий отказ инструментария. Final diagnostic run exit 0 означает совпадение наблюдений с ожидаемыми pass/refusal outcomes, не зелёный release.

## REL-01: snapshot provisioning и настоящее содержание

**Disposition:** confirmed_bounded. **Приоритет:** high release blocker. **Confidence:** high для checked-in path; hosted outcome не наблюдался.

`.github/workflows/release.yml:30–62` выполняет checkout, resolve, immutability preflight и прямой validator. До проверки нет staging, cache/download или другого producer. `check_release_version.py:18–30,53–59` требует versioned directory с TOML под ignored `_build/release-fragments`. `git ls-files` для этого path пуст, `git check-ignore` подтверждает правило. Real command с `--tag v0.1.0` завершается exit 1: missing snapshot. Это остаётся верно при совпадающих package version strings.

`fragments_dir` job output в workflow является строкой absolute path. Он не переносит bytes в независимые notes/operability runners. Полный transfer census не содержит передачи snapshot. Наличие staging в operator instructions не доставляет ignored local files через Git tag.

### Новая различающая проверка producer → checker → notes

- В committed `release-fragments/unreleased` **548 `*.toml`**, не 552: последнее число было бы количеством всех directory entries.
- Настоящий `stage_release_snapshot.py` с default source и внешним `--release-root` копирует все 548; все copied bytes совпадают. Версионный checker проходит. Это доказывает работоспособный существующий producer, не пригодность полного текущего набора для конкретного выпуска.
- Настоящий `build_release_notes.py` с теми же четырьмя required curated sections падает `KeyError: 'type'` в `:98`.
- Named offender: `policy-engine/release-fragments/unreleased/2026-10-23-e02-static-unit-bridge.toml:1–5`. Его top-level keys: `title`, `category`, `changes`; `summary` находится внутри `[[changes]]`, `type` отсутствует.
- При удалении **только этого файла из disposable staged directory** renderer обрабатывает остальные 547 успешно. Product source не менялся.
- Один настоящий curated fragment `2026-04-03-phase-7-closeout.toml`: stage 0, notes 0. Он же плюс offending fragment: stage 0, notes 1. Это локализует отсутствие per-fragment renderer-schema validation у producer: `stage_release_snapshot.py:38–41` проверяет наличие fragments и aggregate curated sections.

Первый unexpected failure и версия probe, ожидавшая notes success, сохранены в `initial_run/`. Diagnostic rerun не является retry-until-green: source/input corpus остались прежними, а отказ был объяснён и сохранён.

**Remediation direction:** подключить существующий producer с явным pinned selection, валидировать каждый fragment через реальный notes contract, content-bind один snapshot и передать bytes каждому consumer. Не обходить missing-input gate и не считать простой staging всего unreleased corpus готовым исправлением. Regression acceptance должна покрыть default checkout, invalid fragment, missing transfer и различающиеся digests между jobs.

## REL-02: requested tag не равен checked-out source

**Disposition:** confirmed_wiring_latent. **Приоритет:** high release-integrity concern, не установленная high-severity privilege escalation. **Confidence:** high для wiring/local controls.

Все 7 checkout steps не задают `with.ref`. В exact [checkout implementation](https://github.com/actions/checkout/blob/11bd71901bbe5b1630ceea73d27597364c9af683/src/input-helper.ts#L59-L71) при отсутствии ref используются event ref и event SHA. Это **не** означает, что каждый job произвольно берёт latest main: default checkout уже привязан к event SHA. Недостающая связь именно между event/source SHA и независимо введённым release tag.

В [GitHub workflow dispatch UI/API](https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow) selected ref и inputs задаются отдельно; ручной запуск требует repository write access. Поэтому actor boundary здесь privileged release operator, не публичный автор PR.

Свежий fixture:

- Actual `pyproject.toml` и dashboard `package.json` committed в A и B; их версии равны 0.1.0. В B изменён только independent `payload.txt`.
- Настоящий lightweight tag `v0.1.0` указывает на A, dispatch context указывает на B.
- Exact resolver и actual version CLI на **metadata в текущем fixture checkout**, с существующим fragment snapshot, возвращают 0. SHA и outputs находятся в `GIT_BINDING.json`.
- Control на checkout A также проходит. Для tag-push exact resolver берёт `GITHUB_REF_NAME` и игнорирует конфликтующий dispatch input. Пустой manual tag отвергается.

Version checker не проверяет наличие/подпись Git tag и не сравнивает его commit с HEAD. Fixture lightweight tag не делает version predicate сильнее. Checked-in ruleset содержит signed-tag policy, но его наличие и `active-when-applied` не доказывают реальные GitHub settings.

**Counterevidence:** automatic tag-push naturally binds event to triggering tag; source SHA не является floating latest ref. Job dependency chain и environment names остаются. REL-01 блокирует прохождение fresh prepare; исправление только REL-01 делает latent REL-02 достижимым дальше. Cryptographic attestation может честно назвать source B, но само по себе не гарантирует ожидание пользователя «release v0.1.0 собран из tag A».

### Input trust: соседний exact-shell контроль

`Resolve release tag` передаёт input через env и не исполняет command-substitution text. Затем `release.yml:55–56,62` вставляет step output прямо в shell source. Безвредный marker control показывает: до rendered immutability shell marker отсутствует, после есть; fake `gh` получает обычный `v0.1.0` argument. Выполнены только локальный `printf`, shell и status-recording `gh` stand-in, без credentials или сети.

Это требует ранней строгой проверки tag format и env-based передачи на всех shell boundaries. Но проверка **не** устанавливает lower-privilege-to-token boundary: dispatcher уже privileged, prepare token read-only, внешние permissions не исследованы. Отдельного high exploitation claim или REL-04 нет.

**Remediation direction:** один раз разрешить и проверить существующий signed tag, bind immutable SHA, использовать его во всех source consumers и сверять publication/provenance. Одновременно определить доверенный workflow definition ref и реальное environment/tag protection, иначе source pinning не доказывает доверие самому workflow. Negative case: same package versions, different tag/source SHA.

## REL-03: invalid report и правильные scanner counterexamples

**Disposition:** confirmed_bounded. **Приоритет:** medium parser/quality-gate robustness. **Confidence:** high для CLI, неизвестно для возникновения malformed output от pinned Grype.

`evaluate_vuln_report.py:41–57` делает `payload.get("matches", [])` без проверки list/identity. Empty map и empty string дают zero iterations, затем exit 0. Свежие controls подтверждают `{}`, errors-only object, `matches:{}`, `matches:""` → 0. `matches:null`, nonempty object, null list member, null/list root и invalid JSON → 1. Таким образом, не любой invalid JSON или scanner failure превращается в PASS.

### Настоящий Grype v0.99.1 contract

Primary sources сохранены в `external/`:

- [Document](https://github.com/anchore/grype/blob/6e1807dd7130c9eff23c1bad19a96cc6afef33aa/grype/presenter/models/document.go#L14-L39) объявляет `matches` без `omitempty` и создаёт non-null empty slice. Errors-only object не является установленным successful Document output.
- [Presenter](https://github.com/anchore/grype/blob/6e1807dd7130c9eff23c1bad19a96cc6afef33aa/grype/presenter/json/presenter.go) сериализует Document. В этом формате нет обязательного `schemaVersion`: нельзя устранять finding введением требования к полю, которого producer не обещает.
- Два byte-verified [upstream golden fixtures](https://github.com/anchore/grype/tree/6e1807dd7130c9eff23c1bad19a96cc6afef33aa/grype/presenter/json/test-fixtures/snapshot): zero findings → actual evaluator 0; Low+Critical → 1. Это upstream test snapshots, не fresh scan PolicyOS artifacts; descriptor version `[not provided]` отражает test fixture.
- [VulnerabilityMetadata](https://github.com/anchore/grype/blob/6e1807dd7130c9eff23c1bad19a96cc6afef33aa/grype/presenter/models/vulnerability_metadata.go#L9-L20) допускает omitted severity. Unknown/omitted severity и arbitrary malformed severity нельзя смешивать. Unknown=0 установлен явно в PolicyOS policy map; отдельный policy decision не подменён доказательством schema corruption.

### Реальный caller, смоделированный scanner

Точные `Generate vulnerability report` и `Enforce vulnerability policy` shell bodies из release workflow исполнены последовательно с `bash -e`; заменены только local output paths и binary location. Scanner stand-in печатает заданные bytes и возвращает заданный статус:

- scanner exit 2 с `{}` → shell exit 2, evaluator summary не появляется;
- scanner exit 0 с `{}` → evaluator 0, summary появляется;
- scanner exit 0 с upstream Critical JSON → evaluator 1.

Это подтверждает, что nonzero scanner не обходит job, и локализует permissive evaluator. **Не доказано**, что настоящий Grype выдаёт `{}` с exit 0. Не запускались scanner/database/network и нет fresh SBOM/report для PolicyOS assets. `frontend-nightly.yml:211–215` имеет sibling caller той же функции; отдельный hosted nightly результат не заявляется.

Future valid exception для конкретных ID/package проходит; expired exception блокируется. Эти разрешённые exception paths не являются bypass.

### Настоящая вложенность fix и граница вывода

Grype хранит fix versions в `match.vulnerability.fix.versions`, а evaluator читает `match.fix` (`:47`). Контроль на real fixture с единственной явно обозначенной мутацией Low→High блокируется, но summary показывает `n/a`, хотя upstream fix versions есть. Это достоверная потеря remediation information, **не** пропуск blocking vulnerability. Замечание сохранено внутри review, без новой defect family.

**Remediation direction:** typed parser по поддерживаемому producer contract, distinction invalid/incomplete/valid-zero, явная unknown-severity policy и проверяемая связь report с текущим SBOM. Проверить настоящую вложенность fields. Подтвердить через реальный installed scanner и caller; нельзя называть malformed-stub control реальным scanner bypass.

## Working safeguards и scope high

- Missing/empty snapshot и version mismatch отказывают, genuine staged curated input проходит.
- Existing-release preflight блокирует gh exit 0. Lookup auth-error exit 4 пропускается, но это не доказательство overwrite: publication и duplicate-release behavior не исполнялись.
- Pinned Actions, ограниченные job permissions, declared canary/production environments, цепочка build → scanner → canary → signing → publish остаются реальными source controls. Attestation выполняется отдельным job после build/scanner; publication ждёт нужные jobs.
- Root gate failure защищает от выпуска, но создаёт operational blockage; **REL-01 high не означает unauthorized publication**.
- **REL-02 high** допустим как release-integrity remediation priority из-за возможного mislabeled signed artifact после устранения preconditions. Exploit severity нельзя выводить без actor/permissions/settings и полного path.
- **REL-03 medium** относится к доверенному scanner-report boundary с invalid data handling; compromised Grype binary не является независимым доказательством этого finding, потому что такая compromise уже даёт существенно более широкое управление job.

Этот review не повторяет observability/canary assertions из исходной lane. Там exact-body predicate controls не являются actual HTTP/installed-wheel run. Checked-in `contract_only` deployment descriptions не доказывают rollout. Никакого hosted run status, published release status или production promotion здесь не получено.

## Closure и freeze

| ID | Root control | Disposition | Сохраняется | Неустановленная граница |
|---|---|---|---|---|
| REL-01 | release.yml:30–62; checker:18–30,53–59 | confirmed_bounded | Да | Real CI input delivery; exact selected snapshot and all downstream gates |
| REL-02 | release.yml:30–48,75–76; checker:35–69 | confirmed_wiring_latent | Да | Privileged hosted dispatch, real protection/approval and publication |
| REL-03 | evaluator:41–57,73–75 | confirmed_bounded | Да | Pinned scanner malformed-success reachability and real artifact/SBOM binding |

`INPUT_MANIFEST.json` связывает все исходные lane files. `SOURCE_VALIDATION.json`, `STAGED_FRAGMENT_CENSUS.json`, `CENSUS.json` задают named denominators. `initial_run/` сохраняет первый red; `probe_results.json` содержит полный final log и substitutions. `external/PROVENANCE.json` и `STORAGE_VALIDATION.json` связывают upstream sources/golden bytes. Read-only `verify_package.py` проверяет input/source/artifact hashes, ожидаемые outcomes, сохранённый initial red и freeze.

**UNRUN:** supported Python 3.14/locked dependencies; full pytest/build/wheel install; actual Syft/Grype and current DB; hosted Actions and real environment/tag settings; signatures/attestation verification; publication/downloaded release subjects; live canary, production rollout, scrape/alert/SLO behavior. Freeze относится только к retained review artifact, не к product release acceptance.
