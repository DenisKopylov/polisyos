# Независимая проверка Scholar research chain

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Проверены frozen probes/results `next_research_chain`, первичный source, нормативные основания, реальные ближайшие producers/consumers и альтернативные объяснения. Production source не изменялся.

**Итог: PARTIAL для полного product chain. RC-01 подтверждён как локальный semantic correctness defect: объявленные Scholar collapse rules не исполняются в подсчёте effective support. Medium severity, высокая уверенность в данном owner и сохранённом job/report пути. Scientific validity на реальных публикациях, native qualification и authority/publication bypass не установлены. Нового SYS-семейства review не добавляет.**

Это не только повторное чтение чужого отчёта. Независимо исполнены неизменённые авторские producer/job/reader/Scientist/test-body probes в отдельном output root. Все пять команд завершились exit 0. Результаты 13 producer cases, четырёх job/CAS/reopen случаев, выбранных reader gates, Scientist verification и шести исходных test bodies совпадают. Дополнительно исполнен различающий контроль zero-weight на реально совпавшем study cluster; он усиливает исходное доказательство.

## 1. Требование действительно относится к этому owner

Основание состоит из трёх уровней, а не из желаемой архитектуры reviewer:

- Accepted `docs/adr/0160-evidence-portfolio-independence-multiverse-synthesis.md:42–46` требует измерять effective independence и collapse для общих primary-source lineage, corpus ancestry, author/institution pool и других common failure modes. Это portfolio-level принцип, не законченная формула научной зависимости.
- Active `docs/plans/active/POLICYOS_UNIVERSAL_POLICY_DESIGN_CASE_IMPLEMENTATION_PLAN.md:1926–1932` прямо относит к W7.D типизированные dependent-corpus rules и Scholar adapter, который **consumes the spec** и выпускает support/conflict/independence refs с collapse reasons. `:1982` запрещает Scholar publication без independence refs против spec увеличивать поддержку.
- `src/polisyos/scholar_requirement/_impl/compiler.py:64–88,112–164,350–410,495–510` уже выпускает строгий contract: шесть collapse dimensions и `effective_support_per_cluster` в диапазоне 0..1. Это не произвольные extra metadata. Поля приходят в реально исполняемый producer вместе с остальными требованиями.

Поэтому альтернатива «rules пока всего лишь комментарий, который необязательно читать» не снимает finding. Наличие plan/ADR само по себе не доказывает deployment readiness или внешнюю legal obligation; здесь оно устанавливает собственный product requirement. Последующие W8.F правила (`:2048–2055`) различают hard и partial collapse. Они не дают права reviewer объявить любые статьи одного университета научно тождественными и не оправдывают молчаливое игнорирование конкретного declared rule.

## 2. Механизм и воспроизведение RC-01

Все source paths ниже относительно `policy-engine/`.

1. `scholar/_impl/evidence.py:171–205` сохраняет study, dataset, author, institution, citation-network и replication metadata. В проверенных synthetic inputs факты зависимости не потеряны до подсчёта.
2. `:1169–1202` получает source-family tag из underlying study, иначе raw content hash, иначе source identity; duplicate marker делает lookup исходного tag.
3. `:1462–1484` считает число различных `_source_dependence_key` на claim. Эта функция не принимает requirement rules. `:1720–1731` рассматривает study/family/source identity, но не остальные пять dimensions.
4. `:1359–1395` создаёт dependence records по тому же ключу и назначает группе effective=1. `_collapse_reasons_for_sources` (`:1679–1700`) смотрит другие dimensions **после** группировки, поэтому это объяснения уже созданного cluster, а не mechanism построения недостающих dependency edges.
5. `:1487–1587` сравнивает полученный count с replication/breadth, а также реально проверяет tier/recency/depth. Reader `:874–999` защищает same-study/tag collapse и часть согласованности records, но не исполняет declared rules.

Свежий replay даёт:

| Изменение при прочих равных | Effective support | Report / boundary |
|---|---:|---|
| Независимые study IDs и metadata | 2 | pass / pass |
| Один underlying study | 1 | blocked / blocked |
| Разные studies, общий dataset | 2 | pass / pass |
| Разные studies, общий author pool | 2 | pass / pass |
| Разные studies, общая institution | 2 | pass / pass |
| Разные studies, общая citation network | 2 | pass / pass |
| Разные studies, общая replication lineage | 2 | pass / pass |

Во всех этих metadata-only случаях настоящий raw/span verifier проходит. Это устанавливает сохранность цитат, а не истинность metadata и не научную независимость экспериментов.

**Уточнение к исходному zero-case.** Авторский `zero_effective_per_cluster` использует разные study IDs. Можно возразить, что для singleton никакое правило ещё не сработало. Независимый `check_zero_matched_cluster.py` снимает эту неопределённость: использует два source одного study, то есть реально сформированный matched cluster с raw=2. При weight=1 получено effective=1; при weight=0 также effective=1, включая dependence record и observed blocker count. Обе версии report blocked при required=2. Различающий вывод касается игнорирования веса, а не нового pass/bypass. См. `ZERO_MATCHED_CLUSTER.json`, exit 0.

Прямой source trace и полный именованный literal census согласуются: `dependent_corpus_collapse_rules` и `effective_support_per_cluster` встречаются в определении/конструировании requirement, не в consumer calculus. Census не подменяет semantic review всего репозитория и не исключает любое динамическое обращение к serialization. Здесь отсутствие wiring подтверждено конкретными executed functions.

## 3. Что доказано настоящими jobs и CAS

В независимом replay работает реальный `DeepResearchJobManager.submit` → `wait` → report/checkpoint write → status index → manager reopen. Использован настоящий FileSystemCAS, UrlFetchCache и canonical `load_core_json_artifact`. Единственный service collaborator возвращает заранее созданный typed bundle; live ScholarDeepSearchService/provider acquisition не выполняется.

В отдельном процессе reader повторно открывает сохранённые jobs:

- independent: completed, report pass, boundary pass, effective=2;
- same study: completed, report blocked, boundary blocked, effective=1;
- shared dataset: completed, report pass, boundary pass, effective=2;
- invented span: completed, report pass, boundary pass, но raw/source binding fail.

Это подтверждает, что semantic результат не исчезает при реальном локальном сохранении и ближайшем чтении. **Completed означает окончание работы, не выполнение requirement.** Same-study completed/blocked — корректное различие, не ошибка.

Изначальные и повторные CAS digests различаются: `SearchQueryTrace.searched_at` по умолчанию берёт текущее время. Сравнение всех producer fixtures/reports в `cases.json` после исключения **только** этого timestamp совпало; остальные semantic outputs совпадают без нормализации. Каждый запуск разрешает и проверяет собственные CAS bytes. Это честный semantic replay, не byte-identical claim между разными поисковыми timestamps. Сохранённый `results.json` всё ещё содержит `report_identical=false` от сырого `json.loads` над Core-tagged floats; настоящий canonical loader в `reader_results.json` даёт equality=true. Это различие представлений измерителя, не потеря данных CAS.

Структурный boundary содержит ссылки из report, включая synthetic locator в прямом producer case. Наличие слов `producer_authority`, CAS-like ref или `pass` не доказывает внешнее admission/custody. Реальный CAS record подтверждает наличие и целостность именно записанного payload; он не исправляет неверный semantic count. В полном job сохранены реальные refs, но whole authorization/publication chain всё равно не исполнялся.

## 4. Положительные guards и пределы интерпретации

Свежий replay сохраняет существенные контрмеры:

- One source и same study дают replication+independence blockers.
- Age=1000 при requirement 730 даёт requirement recency blocker, хотя report default freshness ceiling 1095 ещё не нарушен.
- Working-paper вместо peer-reviewed даёт publication tier blocker.
- Пустые citation refs дают depth blocker.
- Source verifier повторно извлекает текст из retained raw CAS/manifests и отвергает invented span.
- Scientist `verify_web_evidence_bundle` использует тот же настоящий source-binding owner и отвергает invented span и отсутствующий CAS. Он не обещает semantic independence, поэтому pass для same-study не является его дефектом.
- `scholar/api.py:66–105` содержит fail-closed source verification перед hydration в enrich route. Это source-traced компенсация, не исполненный здесь full enrich path.
- Исходные participation requirement/firewall test bodies проходят, сохраняют context-only downgrade.

Авторский report-only removal control (удалить blockers и изменить count на 99) действительно показывает, что normalizer не является independent recomputation oracle. Он не доказывает право противника заменить authoritative product artifact: исследован audit mapping, не принятая custody record. Повторять этот результат как auth vulnerability нельзя.

Scorecard проверен лишь неизменёнными AST bodies `_scholar_academic_evidence_gates`, `_gate`, `_serious_canary` с настоящей declared serious-kind constant. Весь scorecard, остальные admission gates, PDC closeout, public issuance и institutional authorization не запускались. Наблюдение invented-span report pass показывает различие contracts и возможную потребность в content-bound verification join, но не отсутствие проверки цитат во всём продукте.

Ни quality_score, ни publication_tier, ни source hash в synthetic fixture не доказывают peer review, causal identification, transportability или истинность текста. Synthetic known metadata — контролируемое условие воспроизведения typed consumer defect, не найденный инцидент реального исследования.

## 5. Альтернативы, reuse и качество тестов

**Научная политика.** Общий author/institution может обосновывать частичную корреляцию, а не hard collapse. Replication lineage может быть тем, что нужно для независимой репликации, а не причиной её обнуления. Finding следует называть «declared rules не управляют count», а не «все эти пары научно обязаны считаться одной». Исправление требует явной policy семантики, включая unsupported/deferred rule, вместо hard-coded слепого collapse на любое совпадение.

**Существующие owners.** `evidence.portfolio.effective_independence_graph` действительно содержит hard edges/transitive clustering, graded calculus, отдельную polarity mass и scarcity. Его первичный код и четыре сохранённых upstream execution controls изучены; в этом review graph повторно не запускался. Наличие этого owner опровергает тезис «системе нужно написать весь механизм независимости с нуля». Но его evidence-line contract и relation semantics не совпадают со Scholar DTO. Вызов графа без явного adapter/policy agreement не является готовым исправлением. Runtime method equivalence и causal method validity — другие owners, не доказанные Scholar source counts.

**Тесты.** Шесть исходных complete test bodies переисполнены без изменения их predicates, но через isolated AST/direct calls. Это не pytest collection, не conftest и не CI/native pass. Selected denominator из четырёх файлов содержит 33 authored definitions; это не весь test corpus. Existing dependent-corpus test содержит одинаковый study/content hash и meaningful negative assertions, однако не различает полноценный interpreter шести rules и узкий study-key механизм. Компиляторный test проверяет наличие rules, но не their consumption. Новый matched zero контроль дополнительно закрывает один oracle ambiguity исходного probe.

**Среда.** Python 3.12.14 вместо поддерживаемого 3.14; audit-only compatibility loader меняет multi-except syntax и импорт TypeVar, пропускает ряд eager package initializers; настоящие selected bodies/DTO/validators исполняются. Native import failure сохранён upstream, это неподдерживаемая syntax на 3.12, не доказанный defect продукта на 3.14. Dependencies не устанавливались, production source/tests/lockfiles не менялись.

## 6. Verdict и минимальное продолжение

- **Specification: FAIL** для исполнения declared collapse rules в Scholar owner.
- **Engineering/product chain: PARTIAL.** Реальные producer, job, persistence и ближайшие reader результаты доказаны в compatibility environment; complete native/provider/authority chain не установлен.
- **Security authority bypass: NOT ESTABLISHED.** Не установлены lower-trust actor, поддерживаемый путь изменения authoritative evidence и прохождение независимых admission/custody gates.

Минимальная repair direction: единый owner оценки dependency relation/policy, явный Scholar adapter, сохранение rule ID/version, claim/scope/polarity и raw/effective counts. Любое rule должно исполняться либо давать explicit unsupported/limitation. Требуются distinguishing same-study и each-dimension cases, matched zero, transitive/permutation/duplicate/partial-policy cases и actual persistence→canonical reopen→consumer. Existing source-binding/Scientist owner следует переиспользовать, не заменять report pass и не дублировать extractor. Native 3.14 и полный authorizing route остаются отдельными acceptance gates.

## 7. Evidence trail

`RUBRIC.md` фиксирует критерии до replay. `replay_existing.py` исполняет неизменённые upstream probes в `replay/`; пять stdout/stderr/exitcode комплектов сохранены. `ZERO_MATCHED_CLUSTER.json` и отдельный probe дают усиленный falsifier. `REPLAY_COMPARISON.json` фиксирует точное сравнение и единственный timestamp delta. `SOURCE_VALIDATION.json` независимо сверяет 265 исходных/нормативных файлов с pin; все совпадают, семантический review не заявлен для всех imported dependencies. `INPUT_MANIFEST.json` фиксирует прочитанные frozen evidence. `REVIEW_DECISIONS.json` сохраняет dispositions. `SHA256SUMS.txt` и `FREEZE.json` фиксируют этот review.
