# Независимый review SI-01/02: научная семантика и локальные решения

**Итог: PARTIAL_ACCEPT_WITH_SEMANTIC_QUALIFICATION.** Оба finding сохранены как P2 correctness в bounded numerical/consumer контуре. Новые SYS families не добавлены; глобальный аудит остаётся PARTIAL. Production approval bypass не доказан. Исходники продукта и исходный frozen scientific пакет не изменены.

## Решение по SI-01

**Принят с уточнением нулевого знаменателя.** Формула нормированной ошибки при нулевом spread математически undefined. Нельзя объявить единственным правильным результатом infinity: допустимы явная недоступность, typed degenerate status или обоснованная опубликованная политика. Finding состоит в молчаливом превращении ошибочных/исключённых bins в ENCE=0 и подтверждается без использования нулевого знаменателя.

Независимые controls вызвали полный public evaluate_continuous, штатный persist и replay reader:

- Семь одинаково устроенных positive-spread fixtures: SD=s, RMSE=2s, для s=10⁻¹⁵, 10⁻¹³, 5×10⁻¹³, 2×10⁻¹², 10⁻⁹, 1, 1000. Теоретическая ENCE=1 для каждого. В первых трёх source возвращает 0, в остальных 1 с обычной float precision. Это не underflow: величины и их квадраты представимы.
- Mixed all-finite fixture: 10 rows с SD=10⁻¹³, RMSE=2×10⁻¹³ и 90 rows с SD=RMSE=1. Все 10 bins имеют положительные знаменатели; независимая средняя по bins равна 0.1. Source возвращает 0. Умножение всех samples/outcomes на 10¹³ возвращает 0.1. Смена единиц меняет число включённых bins.
- SD=RMSE=1 даёт ENCE=0, корректный положительный контроль.
- SD=0 при residual=0 и residual=1 даёт одинаковый ENCE=0. В reviewer oracle оба нулевых знаменателя обозначены undefined, без придуманного конечного ожидаемого значения.

Все 12 ENCE cases прошли persistence и отдельный replay. Continuous source firewall сохранён: receipt=unverified, validation=blocked/fail. Coverage и PIT не объявляются исчезнувшими. ENCE-only production gate не установлен.

Источник механизма: calibration/diagnostics/continuous.py:385–410. Absolute epsilon исключает bins, а пустой список ошибок превращается в 0. Ремонт должен идти у существующего owner: явная семантика denominator/degeneracy, масштабно-инвариантная политика, учёт исключённых rows/bins и versioned replay. Замена библиотеки без определения семантики недостаточна.

## Решение по SI-02

**Принят с уточнением likelihood conditioning и asymptotic интерпретации.** Независимый oracle использует Decimal precision=70, целочисленные transition counts и 0·log(0)=0 для нулевых counts. P-values вычисляются напрямую через erfc для χ²₁ и exp(−LR/2) для χ²₂, без вызова source p-value helper и без SciPy CDF.

На конструктивной последовательности n=500, misses=35, transitions=434/30/30/5:

- LRuc по всем 500 rows = 3.7650760075099505, p_uc = 0.05233347958680584.
- LRind по 499 transitions = 2.447146542519009, p_ind = 0.11773872539416025.
- Стандартная сумма LRuc+LRind = 6.21222255002896, χ²₂ p_cc = 0.04477473385912595.
- Альтернативный согласованный likelihood, условный на первую observation: прямой Markov-vs-fixed-Bernoulli LRcc = 6.254928093153489, χ²₂ p_cc = 0.04382880424514138. Независимо проверено равенство direct LRcc = transition-based LRuc + LRind.

Таким образом, выбор включения первой observation немного меняет p, но не опровергает counterexample: оба отдельных source p>.05, оба joint p<.05. Не следует обещать одну универсальную точную finite-sample p-value без объявления convention.

Полный исходный summary передаёт p_uc как conditional_pvalue. Полный неизменённый bundle builder передаёт его в conditional_coverage_pvalue_by_horizon, оставляет GREEN/gate_eligible=true и receipt asymptotic. Подстановка каждого из двух независимо вычисленных joint p на том же входном boundary даёт RED/gate_eligible=false, fallback conformal и receipt unverified. Это controlled input substitution, не monkeypatch и не изменение продукта.

Восемь forecast cases включают конструктивный example, обращение его порядка, nominal evenly spaced и clustered 25 misses, undercoverage, all-covered, all-missed и short-sample. Положительный nominal-even контроль остаётся GREEN; clustered, undercoverage, degenerate и short-sample source controls дают RED. Endpoint/degenerate calculations здесь проверяют арифметику и branch, а не устанавливают применимость asymptotic χ² approximation на границе параметров.

Fresh reader загрузил 24 новых persisted forecasting variants. Каждый projected uncertainty сохраняет соответствующую локальную eligibility, но все 24 NativeValueEstimandBinding имеют authority_scope=contract_only_nonproduction и production_value_eligible=false. Все 24 population mismatches отвергнуты. Continuous reports в этих цепях остаются blocked/fail. Это не допуск production policy, не causal certification и не bypass protected action.

Источники: foundry/methods/catalog/econometrics/advanced.py:368–412, 547–605, 800–926; ir/analytics/forecasting_uncertainty.py:523–675. Ремонт у текущего owner: отдельно типизировать UC/IND/CC statistic, df, null, conditioning и предпосылки; правильно доставлять conditional statistic во все текущие consumers; версионировать legacy semantics.

## Проверка исходных доказательств и custody

- Все 252 файла исходного next_scientific_integrity/SHA256SUMS.txt совпали до и после review. Дополнительно связан сам checksum file и используемый compat_loader.py.
- Все 325 реально импортированных source files совпали SHA-256 с их точными Git blob bytes в f1541ed155f278689be48a8c7ac56c3e200210f7.
- Новый отдельный reader воспроизвёл прежние 12 continuous reports и 4 forecast bundles с полным DTO equality. Все прежние девять valid-hash mutations вновь отвергнуты actual reader.
- Для собственных controls отдельно прочитаны 20 continuous artifacts (12 ENCE и 8 forecast summaries), 24 forecasting variants и проверены 24 projection bindings.
- Review probes, результаты, source/input bindings, audit-error notes и freeze доступны рядом. Новые product/test/config edits, commits, installs или network actions не выполнялись.

Первый reviewer producer остановился на слишком строгом сравнении raw float с JSON representation, округлённым IR до 12 знаков. Исправлена только audit assertion (abs tolerance 10⁻¹¹); исходные ошибка/exitcode сохранены. Один standalone binding command имел ошибочный относительный путь; итоговый build_bindings.py использует resolved absolute root и успешно сверяет Git blobs. Эти два случая не классифицируются как дефекты продукта. Повторные checks выполнены после исправлений, без скрытого удаления failed results.

## Границы и повтор проверки

Runtime Python 3.12.14 с прежним in-memory Python 3.14 syntax/TypeVar adapter и namespace facades. Реальные исследуемые functions, formulas, branch predicates, writers/readers не заменялись. NumPy/SciPy/Pydantic профиль сохранён в ENVIRONMENT.json. Это не native Python 3.14, normal package import, installed wheel, pytest/conftest или полный suite. pytest и arch в среде отсутствуют; новых установок не было.

Остаются UNRUN/BLOCKED: native supported profile, actual fitted GARCH/dispatcher, полный production source admission и защищённый consumer, реальная calibration population/currentness/stationarity. Синтетический различающий fixture не является экспериментальной оценкой false-positive rate.

Команды: python review_controls.py producer; python review_controls.py replay; python build_bindings.py; python validate_evidence.py; python seal_evidence.py. Все успешные exitcodes и полный stdout/stderr сохранены. После freeze безопасно запускать только read-only `python validate_evidence.py --frozen`, направляя output вне этого каталога. Он проверяет результаты, исходные inputs, source hashes и полный artifact checksum denominator. Без --frozen VALIDATION.json фиксирует pre-freeze проверку; финальная проверка freeze выполняется отдельно, чтобы не создавать self-referential checksum.
