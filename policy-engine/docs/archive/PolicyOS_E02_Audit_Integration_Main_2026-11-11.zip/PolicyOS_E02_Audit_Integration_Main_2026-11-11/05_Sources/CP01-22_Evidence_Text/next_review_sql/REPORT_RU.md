# Независимая проверка SQL growth

Target: `next_sql_growth` для исходников `f1541ed155f278689be48a8c7ac56c3e200210f7`.

## Вердикт

**Partial / подтверждено с одной обязательной поправкой границ SG-04.** SG-01, SG-02 и SG-03 подтверждены независимыми небольшими SQL-пробами и чтением вызывающего кода. Отсутствие двух полезных secondary indexes подтверждено. Нет оснований объявлять весь SQL линейным, нарушенным tenant isolation, потерю данных, production SLA failure или доказанную PostgreSQL деградацию.

**RQ-SQL-01, medium, высокая уверенность: SG-04 нельзя ограничивать active backlog при любом плане.** В исходном отчёте сказано, что completed jobs не входят в denominator. Это верно для приведённого `MULTI-INDEX OR` без статистики, но не является свойством самого запроса. На той же полной SQLite schema, exact candidate SELECT и фиксированных **5 pending + 5 running с действующими leases**:

| Всего jobs | Completed | Без ANALYZE, VM | После ANALYZE, VM |
|---:|---:|---:|---:|
| 100 | 90 | 116 | 551 |
| 1 000 | 990 | 116 | 5 051 |
| 10 000 | 9 990 | 116 | 50 051 |

После ANALYZE SQLite **3.53.1** выбирает `SCAN control_jobs` + временную сортировку, результат остаётся тем же. Размер active backlog не меняется, а работа растёт вместе с completed history. В этой сборке нет `ENABLE_STAT4`; compile options и `sqlite_stat1` сохранены. Это конкретный контрпример, а не утверждение о всех сборках SQLite и production statistics.

**Необходимая формулировка:** «В no-statistics MULTI-INDEX OR fixtures denominator равен pending/running backlog; при других статистике и распределении возможен full scan общего control_jobs. Production denominator надо квалифицировать по фактическому плану». Поправка относится к пункту 4 вводного резюме и §5 `next_sql_growth/REPORT_RU.md`. Она усиливает capacity caveat, но не обосновывает incident или security severity.

## Что независимо подтверждено

### SG-01: history и run lookup

Использована полная реальная SQLite schema через неизменённые выбранные методы, извлечённые независимо из pinned AST. Исходный probe не импортировался. Тексты SQL сравнены побайтно с `next_sql_growth/queries.json`.

- 128 / 1 024 / 4 096 events, по 8 на job: creation первого job требует 411 / 3 099 / 12 315 progress callbacks interval=1. Неуникальный `(job_id,event_id)` даёт 54 на всех трёх размерах. История и latest-running того же job также перестают зависеть от чужих jobs.
- 128 / 1 024 / 4 096 jobs: latest-by-run 456 / 3 144 / 12 360 → **78** после `(run_id)`; unique-completed 712 / 5 192 / 20 552 → **80**. Результаты before/after совпали.
- Различие чисел с основным отчётом объясняется независимым corpus: 8, а не 10 событий на job. Большой авторский 300k corpus повторно не запускался.
- На jobs после добавления run index временная сортировка остаётся. Индекс ограничивает чужие runs, но не стоимость большого одного run. Creation query всё ещё читает историю своего job, а не получает гарантированный O(1).
- `control_job_events` имеет только event_id PK, а `control_jobs` не имеет run_id index в двух schema owners. Отсутствие event_type secondary index не означает, что обязательно нужны оба варианта одновременно. `(job_id,event_id)` был counterfactual, а не утверждённый production DDL. В SQLite INTEGER PRIMARY KEY является rowid; альтернативный меньший `(job_id)` также заслуживает отдельного explain/size сравнения. В PostgreSQL такое предположение о включённом rowid неприменимо.

Reachability проверена по настоящим caller bodies, не только grep:

- `control_plane_store.py:2038–2132`: creation-envelope reconciliation вызывает уникальный creation reader, сверяет immutable event с outbox и выводит trusted scope.
- `:2134–2172`, `:2174–2196`: historical scope и current worker admission используют этот owner.
- `:2003–2036`: running proof читает latest running source внутри transaction.
- `run_lifecycle.py:12812,12905`, `resource_binding.py:2330`, `owned_attempt_anchor.py:2888–2889` связывают run lookup с runtime ownership/proof consumers.

Это reachable persisted proof mechanism, но число SQL вызовов на реальный HTTP request / worker transaction, admitted producer path и p95 не измерялись.

### SG-02: outbox и statistics

Независимый corpus: 2 048 rows, только два topic, поддерживаемых настоящим delivery-order owner. Во всех вариантах запрошена первая pending page с LIMIT 1:

| Распределение | До ANALYZE | После ANALYZE | Topic/state index + ANALYZE |
|---|---:|---:|---:|
| Все нужного topic | 41 014 | 52 | 54 |
| Нужный topic только в хвосте | 10 309 | 16 428 | 16 430 |
| Другой topic опубликован, нужный pending в хвосте | 75 | 16 428 | 16 430 |

Подтверждено: количество возвращённых rows и watermark не ограничивают число просмотренных candidates. Blanket `(topic,state,created_at,event_id)` не исправляет все планы. Контрпример остаётся после ANALYZE. High cursor возвращает нужный хвост, пустой frozen interval возвращает ноль; это static SQL controls, не concurrent-arrival acceptance.

Reachability: `run_lifecycle.py:7699–7740` и `:13991–14040` реально выполняют одну страницу по 25, удерживают watermark между страницами, а после завершения цикла сбрасывают cursor. Failed delivery остаётся pending и снова рассматривается в следующем цикле. Нельзя ускорять запрос фильтром, который теряет retryable rows, или переопределять frozen bound. Source comment «Search-only sequence» шире фактической истины: `control_plane_store.py:7885–7901` добавляет оба выбранных topic. Исходная финальная mixed fixture правильно учитывает это.

### SG-03: startup и положительный контроль

На 100 / 1 000 intents scope census требует **1 917 / 19 017** VM, exact tenant/scope PK lookup = **40 / 40**. Два последовательных вызова настоящего schema method дают два invalid-scope COUNT даже на уже актуальной БД. Неверный scope_id отклонён настоящим schema method с `runtime_operation_scope_migration_has_unclassified_rows`.

Это constructor/startup work, не цена каждого steady-state intent lookup. Нельзя просто убрать validation. Source-level PostgreSQL сходство не превращено в measured PostgreSQL стоимость. Literal retention census исходного отчёта ограничен указанными .py/.sql; он не исключает внешние DBA jobs, dynamic SQL или иные operators. Оговорка основного отчёта корректна.

## Проверка write/constraints у предложенных индексов

В двух независимых небольших БД, с кандидатами и без, проверены одинаковые изменения. Кандидаты добавлены как **неуникальные** индексы и не заменяют существующие unique/PK constraints:

1. INSERT и UPDATE jobs/events/outbox/intents; несколько jobs одного run разрешены.
2. Duplicate job PK, event PK, outbox `(topic,event_key)`, intent scoped PK отвергнуты одинаково.
3. CHECK: completed intent без result/event, pending без owner, refused без reason отвергнуты одинаково.
4. Два outbox rows с NULL event_key остаются разрешены, как требует существующий partial unique index.
5. Duplicate creation row не запрещена новым индексом, но настоящий creation reader по-прежнему отказывает `control_job_created_event_count_not_one`. Проверку cardinality нельзя заменять LIMIT 1.
6. Два completed jobs одного run/kind остаются двумя SQL rows при LIMIT 2. Guard `control_job_completion_ambiguous` подтверждён чтением source; полный `_row_to_record`/native reader для этого случая не исполнялся.
7. Retry attempt/error update, published transition и корректное completion intent выполняются; rollback откатывает append.
8. Повтор schema initialization сохраняет три candidate indexes; table DDL не меняется. `PRAGMA integrity_check` = ok, `foreign_key_check` пуст.
9. Полное конечное состояние пяти target tables совпало побайтно по SHA-256: `f7242b100db7b2320408adb149fd956ed46ffb2aa5c43979aac89cd94454567f`.

**Вывод ограниченный:** в этих SQL smoke controls индексами не сломаны writes и constraints. Это не гарантия безрегрессионного patch. Каждый индекс требует дополнительных B-tree pages и работы INSERT/UPDATE/DELETE; влияние на write throughput, lock duration, WAL/disk, index build/rebuild, disk-full и crash recovery здесь не измерялось. Production migration на большой существующей БД не выполнена. Конкурентные readers/writers и admitted transaction owner не воспроизводились. Изменение плана может менять выбор при недоопределённых ORDER BY ties; tie semantics требуют явного контракта, а не общего обещания равенства hash по этим fixtures.

## PostgreSQL и scope риска

Независимое AST извлечение CREATE INDEX подтвердило отсутствие в PostgreSQL schema owner трёх SQLite names:

- `idx_control_jobs_state_created_at`;
- `idx_control_jobs_pipeline_id`;
- `idx_runtime_operation_intents_run_state`.

Оба backend сохраняют собственные PK/UNIQUE. Известная deployed DB не inspected, поэтому нельзя исключать внешние дополнительные indexes. SQLite rowid/INTEGER PRIMARY KEY и PostgreSQL BIGSERIAL/B-tree различаются; planner, statistics, MVCC, locking и syntax migration тоже различны. `_lease_next_postgres:9033–9070` выполняет candidate CTE с `FOR UPDATE SKIP LOCKED` и UPDATE, а не SQLite SELECT + serialized writer transaction. Одноимённые SQL shapes не означают равной стоимости.

`_postgres_cursor:10219–10234` открывает соединение для внешнего context; активные lanes в `_fetchone/_fetchall` переиспользуют cursor. Формулировка «каждый SQL = новое соединение» была бы неверна; исходный отчёт её не использует.

Нет оснований трактовать отсутствие tenant column у control job/event/outbox owner как isolation bypass. Trusted scope извлекается из creation-envelope proof; отдельный RLS adapter или world migrations не индексируют автоматически эти таблицы. Proof safety, authority и HTTP isolation этим review не квалифицированы заново.

## Приёмка и ограничения

- Независимые команды: `PYTHONDONTWRITEBYTECODE=1 python next_review_sql/independent_probe.py` и `.../validate_sources.py`. stdout/stderr/exit codes сохранены. Только временные synthetic БД и audit namespace; source и product tests не изменены.
- Максимальный отдельный corpus 10k jobs; дорогие 100k/300k wave и полный pytest не повторялись.
- Interval=1 progress handler считается на заранее подготовленном и прогретом statement отдельно от EXPLAIN. Это SQLite VM callback metric, не physical rows, disk I/O, CPU cycles или latency SLA. Никаких меж-backend коэффициентов из него не выводим.
- Source target pinned, 14 named source files заново сверены с baseline, Git status пуст. Это выбранный readset, не новый полный semantic census.
- Native service import/pytest, Python 3.14, installed wheel, HTTP, PostgreSQL, multi-worker contention **UNRUN**. Авторский native stderr действительно показывает Python 3.12 SyntaxError на поддерживаемом более новом синтаксисе `core/artifacts/store.py:2155`; это environment limitation, не доказательство product defect.
- Для production кандидата нужны отдельные migration/reopen/rollback/concurrency acceptance, реальные distributions и актуальная statistics policy, preservation cardinality/ties/lease fairness/attempt increment, PostgreSQL `EXPLAIN (ANALYZE, BUFFERS)` на disposable DB. Уменьшение CPU нельзя оплачивать ослаблением proof/idempotency semantics или незаявленным удалением history.

Итог: read-index direction обосновано, SQL capacity risk реален на воспроизводимых fixtures. Основной отчёт пригоден после явного исправления SG-04 denominator; никакой готовый или безопасный для production patch этим не аттестован.
