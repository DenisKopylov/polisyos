# Независимая проверка STATE-01 / STATE-02

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`. 10 ноября 2026. Проверяемые findings: `next_state_owners/FINDINGS.json` и `REPORT_RU.md`. Production source и файлы авторского исследования не менялись.

## Вердикт

**Оба P2 принимаются как подтверждённые дефекты исследованных механизмов. Native / full-engine / HTTP / production acceptance остаётся PARTIAL, не PASS.** Ложноположительного объяснения, устраняющего любой из двух механизмов, не найдено. Доказательства не устанавливают наблюдавшийся production incident, общий отказ всех recovery paths или обход publication authority.

- **STATE-01:** подтверждена потеря selected workflow edge при recovery между durable finalize journal и terminal event. Это отказ последующего строгого чтения, не повышение полномочий. Дополнительно воспроизведён немедленный exact retry: он сам выполняет recovery и затем отказывает. Core finalization без workflow selection служит положительным контрпримером и восстанавливается нормально.
- **STATE-02:** подтверждён durable dedupe перед завершением fanout. Дополнительно проверены настоящие packet-state serialization, application, evaluation computation и transition methods. Потеря события не сводится только к заданному в авторском probe поведению `_apply_event_to_packet`. При сбое до записи второго packet его статус остаётся ACTIVE и после истечения TTL. Но если sticky event уже записан, TTL/recompute может восстановить STALE. Эти два случая нельзя смешивать.

## Что проверено заново

1. Независимо прочитаны journal/recovery/finalization, sync и async workflow producers, terminal reader и control-job consumer.
2. Независимо прочитаны generic DecisionValidity owner, дедупликация, packet application, forced/cached evaluation, HTE source request и outbox acknowledgement, Runtime notification, RunIndex projection.
3. Авторские `probe_finalize_recovery.py` и `probe_validity_delivery.py` скопированы без изменения байтов в эту папку и повторены: оба exit 0. Все исходные positive/negative controls повторились.
4. Добавлен собственный `probe_review_discriminators.py`: exit 0. Он расширяет набор различающих случаев, но не подменяет native acceptance.
5. `validate_review.py` связывает выполненные source spans, source files и copied probe bytes с указанным commit; полный результат в `REVIEW_VALIDATION.json`. Git snapshot остаётся clean.

Исследование SQL intent races STATE-flow B здесь **не было отдельным предметом повторной квалификации**. `probe_intent_transactions.py` скопирован только как необходимая библиотека настоящих SQL methods для validity probe; его main/races/crash suite не запускались повторно.

## STATE-01: границы подтверждения

### Независимая цепочка

- `core/run/context.py:1178–1186`: journal содержит schema version и RunManifest, но не отдельный selected workflow ref.
- `context.py:3268–3274`: normal finalization записывает workflow ref в `RUN_FINALIZED.refs.inputs`.
- `context.py:1402–1416,1420–1499`: восстановление создаёт terminal fact только с manifest output. Когда terminal fact уже существует, recovery сохраняет его.
- `runtime/http/services/adapters/core_run.py:294–303,620–629`: один подходящий manifest output сам по себе не выбирает workflow transition; отсутствие terminal input приводит к отказу строгого workflow reader.
- `runtime/http/services/control/run_lifecycle.py:14287–14353`: final-state consumer control job также не угадывает selection и возвращает None.
- `scientist/orchestration/engine/executor.py:2560–2641` и `async_executor.py:1156–1160`: оба producer передают явный selected ref в тот же Core finalizer. Это source-supported reachability, не выполненный full workflow.

### Различающие результаты

- До manifest CAS write, после него и перед terminal append: в journal output имеется workflow ref, после recovery selected input отсутствует, exact retry отказывает.
- Ошибка после terminal append: сохранён правильный selected ref. Следовательно, утверждение «любая ошибка finalize теряет workflow selection» ложно.
- Прямой exact retry после ошибки до manifest write, без отдельного вызова recovery: тот же `run_finalize_workflow_finalization_not_established`. Caller retry не исправляет неполный journal.
- Non-workflow finalization с `workflow_finalization_ref=None`: recovery успешен. Уязвимость доступности ограничена потребителями, которым требуется явный выбранный workflow transition.
- Foreign journal owner, malformed journal, duplicate terminal: авторские отказы воспроизведены. Нельзя описывать finding как authority bypass или unsafe acceptance чужого workflow.

### Ограничения

RunContext constructor, CAS bytes/profile/ownership verification и часть trace intake остаются fixtures. Наличие строгой проверки selected CAS profile может изменить некоторые error paths, но не добавляет недостающий selected input в journal. Не исследованы hard kill, power loss, partial terminal-line append, реальные CAS failures, полный sync/async executor и HTTP reader. Multi-output ambiguity не исполнялась отдельным новым control; её нельзя объявлять пройденной.

Направление ремонта автора верно: расширить существующий journal выбранным exact ref и его binding, а не ослаблять reader или выводить selection из output kind.

## STATE-02: границы подтверждения и существенный контрпример

### Независимая цепочка

- `scientist/validation/decision_validity.py:1950–1993`: durable dedupe предшествует сбору/обработке packet targets. Повторный ключ идёт в `ensure_evaluation`, а не в event application.
- `decision_validity.py:343–365,489–516`: запись отдельного файла атомарна; owner transaction сериализует доступ, но не откатывает уже заменённые файлы.
- `decision_validity.py:2041–2110`: настоящий `_apply_event_to_packet` сначала сохраняет sticky triggers и lifecycle event, затем пересчитывает evaluation и фиксирует transition. Это объясняет разные последствия сбоя до и после packet-state write.
- `decision_validity.py:1806–1851`: cached evaluation может быть возвращена без применения события. `read_current_projection` сам TTL не проверяет; при имеющемся evaluation он возвращает сохранённую проекцию с epoch overlay.
- `runtime/http/services/run_index.py:215–222`: RunIndex действительно вызывает этот projection reader. Это source-supported downstream surface, не выполненный endpoint.
- `runtime/http/services/control/run_lifecycle.py:15429–15474`: generic publication пишет SQL notification после возвращения Scientist evaluations, без проверки полного применения requested event.
- `run_lifecycle.py:14082–14088`: HTE outbox отмечается published после успешного вызова этой публикации. Полный HTE producer/delivery здесь не исполнялся.

### Независимые дополнительные probes

Использованы настоящие `_DecisionPacketState`, packet file IO, `_apply_event_to_packet`, `_compute_evaluation`, `_record_transition`, event/trigger/evaluation schemas. Только CAS evaluation storage, packet payload source и отсутствие epoch overlay остаются ограниченными fixtures. Payload представляет generic ECONOMETRIC_EVIDENCE, а не полноценный owner-selected HTE packet.

- **Сбой до записи packet B:** A успевает стать STALE; B остаётся ACTIVE, без sticky trigger/lifecycle event. Reopen + cached retry даёт `[stale, active]`. После искусственного устаревания timestamp за TTL, повтор с настоящим computation также даёт `[stale, active]`. У нового compute нет утраченного event, который dedupe запретил повторно применить.
- **Сбой после durable packet B write, до forced evaluation:** cached retry также даёт `[stale, active]`, однако sticky event уже есть. После TTL настоящий compute даёт `[stale, stale]`. Это опровергает универсальное утверждение, что любой partial failure навсегда оставляет ACTIVE. При этом transition B не восстановлен этим повтором: count остаётся 0 в данном probe.
- **Projection после истёкшего timestamp:** `read_current_projection` возвращает сохранённый ACTIVE в обоих случаях. Поэтому один только elapsed TTL не равен гарантированному автоматическому восстановлению.
- **Тот же dedupe с другим event ID/status/reason:** generic owner принимает повтор без ошибки, возвращает старые STALE evaluations и оставляет старый event ID. Это дополнительное подтверждение необходимости payload binding в acceptance, а не самостоятельное доказательство exploit через HTE: HTE request пересчитывается из owner state и не принимает произвольный caller payload.

### Что исключено и что не доказано

- При ошибке до сохранения dedupe обычный retry применяет оба targets: авторский negative control повторился.
- SEMANTIC_EPOCH generic intake отказывает до dedupe: его отдельный all-target pending batch path не опровергнут.
- Без failures normal duplicate не создаёт второго notification; обычная idempotency работает.
- Наличие runtime notification не само по себе означает публикацию policy claim. HTE basis явно candidate-grade; мост до конкретной externally published signature этим исследованием не проверен.
- Не установлены частота, реальный recovery latency, полный набор generic sources, полнота dependent packet denominator или все consumers.
- No native CAS, installed package imports, HTTP authorization, full HTE originating outbox acknowledgement, process-kill restart или PostgreSQL qualification. Reopen выполнялся через новую service instance в том же процессе.

Ремонт должен сохранить owner и строгие границы; required state различает received/pending/applied и допускает idempotent target replay. Простое перемещение dedupe в конец не доказывает корректность partial replay, collisions, target set drift и downstream acknowledgement.

## Качество исходного evidence и acceptance

Авторский отчёт корректно отделяет fixture observations от source-supported downstream, прямо называет unrun surfaces и сохраняет SEMANTIC_EPOCH как контрпример. Его два finding не следует отклонять из-за harness extraction, но нельзя переименовывать их статус в native/e2e confirmed.

Просмотренные существующие unit tests покрывают normal event dedupe и atomic dedupe-file failure, а finalize tests покрывают terminal/journal compatibility. Это не доказательство отсутствия regression test во всём репозитории: выполнен целевой просмотр, не полный test census. Полный pytest не запускался.

Для закрытия нужен native Python 3.14 / locked profile с реальными CAS и packets, independent-process restart/kill на durable boundaries и проверка конечного consumer. STATE-01 требует сохранения exact selected ref. STATE-02 требует полного replayable fanout и запрета преждевременного originating ack; добавить partial sticky-write, post-TTL read, changed-payload same-key и sibling `mark_packet_trigger` (последний здесь source-only).

## Воспроизведение

Из этой папки, с неизменённым `../source`:

- `PYTHONDONTWRITEBYTECODE=1 python probe_finalize_recovery.py`
- `PYTHONDONTWRITEBYTECODE=1 python probe_validity_delivery.py`
- `PYTHONDONTWRITEBYTECODE=1 python probe_review_discriminators.py`
- `python validate_review.py`

`probe_review_discriminators.py` импортирует два исходных probes и потому повторяет их в собственном isolated workspace перед дополнительными случаями; latest result JSON относится к этому повтору. Первые отдельные stdout сохранены отдельно. Ожидаемое warning про malformed journal относится к negative control, не к tooling failure. Новые зависимости не устанавливались, production code не исправлялся.

Первичный isolated validity rerun сохранён в `validity_rerun.stdout.json` (23330 bytes). `validity_delivery_results.json` (30807 bytes) перезаписан повторным запуском при импорте в discriminator; он имеет общий накопленный readset/extracts и новые runtime timestamps. Эти два output **не byte-identical**. Byte-exact проверка относится к копиям исходных probe scripts, а не к их динамическим JSON outputs.
