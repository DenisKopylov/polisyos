# Независимая проверка next_storage_scale

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Проверены отчёт, измеритель, JSON-результаты, source binding и реальные вызывающие участки. Production source не менялся. Большие серии 800/50 000 не повторялись.

## Вердикт

**ST-01 и ST-02 подтверждены как source-qualified storage scaling risks. ST-03 подтверждён только как условный риск compatibility wrapper.** Ошибок в исходных byte/count результатах, которые опровергали бы эти три механизма, не найдено. Это не production benchmark, SLA failure, quota bypass или release acceptance.

Есть одно содержательное дополнение к reachability: **полный history scan достигается не только из debug/canary.** Его вызывает operational human-decision exposure path даже для получения одного `cell_id`. Эту связь необходимо включить в итоговый анализ. Ещё два уточнения предотвращают некорректную экстраполяцию: число claims не равно числу artifacts, а синтетические quota members не представляют полноценные CAS artifacts.

## 1. Operational history scan: недостающий consumer trace

Исходный отчёт верно измерил `ArtifactOwnershipIndex.evidence()`, но описывал измерение преимущественно как diagnostic evidence. Фактические consumers шире. Пути относительно `policy-engine/src/polisyos`:

1. `runtime/http/access_audit.py:894–917`, `_selected_exposure_owner_cell_id`, вызывает `ownership_evidence(tenant_id=None, cell_id=None)` и использует только `tenant_id` и `cell_id`.
2. Этот helper вызывают `prepare_human_decision_exposure_event:1078–1081` и `prepare_human_decision_exposure_event_through_sink:1111–1114` до записи authority receipt.
3. `runtime/http/services/human_decisions.py:1482–1508` вызывает тот же helper при `_persist_exposure_session`. Дополнительный consumer `:2285–2305` проверяет V2 approval owner format через тот же evidence API.
4. Sink `runtime/http/services/control/run_lifecycle.py:6854–6868` получает и прямо вызывает `self._artifact_store.ownership_evidence`.
5. Stock `core/artifacts/store.py:1676–1691` разрешает tenant/cell и вызывает `self._ownership_index.evidence`.
6. `core/artifacts/ownership.py:1840–1866,1947–1979` проходит все parent generations до genesis либо legacy capture. Lean token этим consumer не выбран.

Кроме того, `runtime/http/routes/runs.py:6772–6776` запрашивает ownership evidence на production approval path. Это source-reachable branches при соответствующих request/service prerequisites, **не утверждение о фактической частоте на production** и не исполненный native HTTP сценарий.

Малый composition control исполнил неизменённый helper и настоящий `index.evidence()` через явный scope adapter. При трёх generations для получения одного `cell_id` прочитаны **4 generation files / 6 076 bytes**: текущая generation для snapshot и все три для history. Это проверка helper/index seam, без полного store/sink/HTTP. Она исключает объяснение «helper автоматически использует только lean token».

Направление для проверки владельцем: при operational scope/format query определить узкую content-bound проекцию, не вычисляющую ненужную полную историю. Нельзя молча заменить evidence там, где исторический статус действительно load-bearing. Приоритет ST-01 остаётся medium scaling risk; новый trace расширяет reachability, но не устанавливает breach бюджетов.

## 2. Reachability ownership/index и точный denominator

- Runtime `dependencies.py:115–127` строит store через `build_artifact_store`, затем применяет ambient ownership view и blocking guard. `core/artifacts/backends/config.py:66–72` для filesystem создаёт именно `FileSystemCAS`. В `store.py:1079–1091` это настоящий shared-root ownership index/coordinator. `for_tenant:1620–1632` и ambient view `:1634–1648` сохраняют общий index.
- Reads действительно вызывают owner predicates: `store.py:1757–1860,2199–2217`; lineage loop `:1962–1975` проверяет blob и manifest по каждому входу. Enforced scope является существенной предпосылкой; raw unscoped store может пропустить эти checks.
- `store.py:3606–3617` при `owner=None` создаёт пустой набор claims. Для нового tenant-owned artifact `will_create_default=True` даёт default owner плюс exact view; `_record_transaction_claims:3163–3198` публикует их отдельными index calls. Поэтому обычный новый owned artifact может породить **две** полноразмерные generations, а unscoped artifact вообще не обязан породить ownership generation. Повтор, альтернативный view и blob-only reader меняют multiplicity.
- Самостоятельный контроль: **один artifact, три distinct claims → три generations**. Он использует настоящий index, не полный CAS publisher. Эта величина не превращена в production коэффициент.
- При warm blob lookup default owner использовал один generation read (**1 716 bytes**), blob-only owner и неверная cell использовали два (**3 432 bytes**). Причина: `ownership.py:1342–1346` сначала проверяет default ownership, затем blob-readers. Это дополнение к ST-02: число high-level запросов не равно числу полных generation scans.

Следовательно, формулы исходного отчёта корректны именно по distinct admitted claim updates и serialized bytes `B_i`. Нельзя подписывать ось N как «записи CAS», «runs» или «blobs» без дополнительного real workload trace.

## 3. Проверка роста и альтернативных объяснений

### ST-01

`record_owner:1215–1272` загружает snapshot и публикует полный payload. `_write_payload:2307–2396` сохраняет полный generation JSON и parent hash. Old generations не удаляются этим путём; поиск по `src/polisyos` и `tools` не нашёл ownership compaction/deletion path. Поиск не исключает внешнее обслуживание или deployment-specific процессы.

Свежие bounded controls:

| Distinct claims | Generations | Active bytes | Retained bytes |
|---:|---:|---:|---:|
| 8 | 8 | 2 873 | 16 363 |
| 16 | 16 | 4 745 | 47 771 |
| 32 | 32 | 8 489 | 155 515 |

В этой отдельной fixture `B_i = 1001 + 234*i` (первая generation меньше на 69 bytes). Сумма всех реально сохранённых files равна сумме размеров каждой опубликованной generation. Это независимое подтверждение полного snapshot retention, без переноса коэффициента 230 из первоначальной fixture. Exact duplicate owner с другим writer не добавляет generation.

Три исходные точки 50/200/800 перепроверены арифметически: указанная автором формула точно даёт сохранённые totals. Её CPU-оговорка корректна: сортировка, codecs, locks и fsync не позволяют называть wall time строго квадратичным на основании этих трёх samples. Историческая полнота является намеренным контрактом, поэтому «просто удалить старые файлы» не обосновано.

Повторён исходный bounded control из `probe_storage_controls.py`: другой instance виден; wrong profile/cell denied; missing ancestor даёт `pre_v3_history_unresolved` при неизменном current token; restore возвращает `no_pre_v3_pair`. Все assertions прошли.

### ST-02

`_load_generation_snapshot:2106–2159` читает и hash-checks generation до сравнения cache key. Свежие controls 8/16/32 подтвердили полный `B` byte read при сохранении того же decoded cache object. Поэтому объяснение «это только cold decode» отвергнуто. Parsed cache работает, но не ограничивает byte scan и raw buffer.

Исходный 50 000-claim payload создан прямым `_write_payload`, а не 50 000 publications. Это допустимый mechanism isolation, прямо раскрытый в отчёте. Нельзя выдавать его за native artifact population либо учитывающий типичные default/view/blob/closure proportions. Application read bytes не равны physical disk IO; incremental tracemalloc peak не равен RSS или утечке. Эти ограничения в исходном отчёте сформулированы правильно.

### ST-03

Точный поиск `TenantScopedCAS|resolve_cas_store` по production `src` и `tools` обнаружил только definition, resolver и re-export. Runtime binding выше не использует wrapper. Иные импорты модуля для `TenantSidecarScope` не доказывают quota wrapper reachability. External callers/dynamic composition остаются неизвестны.

Неизменённый wrapper выполняет `_directory_size` до и после успешного входа в underlying writer, под tenant-root RLock/flock (`tenant_cas.py:263–289`). Малый контроль с 12 пустыми synthetic members подтвердил 2 scans и на no-op, и на writer exception, а также очистку callback. Дополнительные 13 CAS bytes меняют census на 13; 100 bytes ownership control state не меняют его. Это не quota-limit или full writer тест.

**Оговорка для итоговой формулировки:** 50 000 отдельных 32-byte файлов без manifests не доказывают существование 50 000 валидных CAS artifacts при quota usage 1,6 MB. Реальный writer публикует обязательные manifest members; они увеличивают и byte total, и entry count. Утверждение «byte quota не ограничивает E» следует понимать как отсутствие отдельного явного count/metadata budget в census, особенно для произвольного filesystem state, а не как доказанную неограниченную генерацию валидных artifacts при фиксированном byte limit. Пустые synthetic files в нашем контроле тоже не являются valid-artifact admission доказательством.

Measured 2,457 s нельзя сравнивать с Runtime timeout и объявлять breach: quota wrapper не включён в показанный Runtime graph, fixture не native, profile и machine отличаются. Приоритет ST-03 должен оставаться conditional до установления реального wiring/workload.

## 4. Источники, команды и ограничения

- **22 файла** первоначального artifact manifest перепроверены по bytes и SHA-256, все совпали.
- **17 source/test/doc файлов** первоначального readset перепроверены напрямую против `git show f1541ed:<path>` и actual source bytes, все совпали. Дополнительные operational consumer files также связаны с commit в `SOURCE_VALIDATION.json` этого review.
- `PYTHONDONTWRITEBYTECODE=1 python policyos_deep_audit/next_storage_scale/probe_storage_controls.py --source policyos_deep_audit/source --output policyos_deep_audit/next_review_storage/replayed_controls.json`: exit 0, stderr пуст.
- `PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python policyos_deep_audit/next_review_storage/review_controls.py`: exit 0, stderr пуст. Новый probe и outputs сохранены в этом каталоге. Он проверяет original manifest, source bytes, arithmetic, small ownership cases и quota wrapper seam.
- Использован Python 3.12.14, а поддерживаемый repository baseline — Python 3.14. Ownership загружен полными исходными implementation modules с обходом только eager package initializers. Quota исполняет AST-selected неизменённые bodies с fixture constructor/writer/quota state. Operational helper исполняется неизменённым телом через scope adapter. Эти способы **не квалифицируют native imports/backend/HTTP**.
- Native product tests, production throughput, process contention, crash/power-loss и quotas warn/block не запускались. Никаких исправлений, dependency installs, commits или source writes нет. Git HEAD прежний; заключительный `git status --porcelain` пуст.

Specification verdict: **partial** относительно full native/product validation. Engineering-review verdict: **механизмы подтверждены; дополнить operational consumer trace ST-01 и сохранить ограничения denominator/representativeness**. Нового подтверждённого security defect или data-loss incident этот review не устанавливает.
