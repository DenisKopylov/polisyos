# Независимая проверка cumulative synthesis и source adapters

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Объекты: `next_cumulative_synthesis` (checkpoint01–11) и отдельно `next_source_adapters`. Исходники и оба первичных пакета не исправлялись.

## Вердикт

**PARTIAL, пригодно как квалифицированная промежуточная сводка, с двумя небольшими поправками к самостоятельным полям карточек.** На выбранных критических findings не обнаружено повышения severity вопреки review, двойного счёта STATE/DELIVERY, выдачи candidate/pass за authority или неподтверждённой оценки production cost/SLA. Это не независимая повторная проверка всех 81 карточки и не product acceptance.

**SA-01 подтверждён независимо на реальном файловом owner и отдельном процессе.** Потеря возникает у двух валидных schema IDs при совпадении файловой проекции **и версии**; последний writer остаётся на диске. В этом census нет прямого first-party runtime construction, поэтому это P2 дефект доступного persistence owner, а не доказанная потеря production registry.

**Registered contracts действительно работают.** Strict proxy без contract пропускает результат; зарегистрированный matching contract принимает корректные данные и отклоняет удаление обязательного поля. Авторские guards same-version hash conflict и breaking evolution без approval воспроизведены. Следовательно SA-02 нельзя сокращать до «валидации/эволюции нет».

## 1. Исправления формулировок

Поправки находятся в [REVIEW_CORRECTIONS.json](REVIEW_CORRECTIONS.json). Они не добавляют product findings, не меняют приоритеты и не требуют переписывать первичные raw records.

1. **SG-04: уточнить нормализованный title.** Сейчас title говорит только `enumerates active pending/running candidates`, хотя accepted_summary и обязательный review constraint уже правильно учитывают ANALYZE/full scan. Для отдельно отображаемой карточки лучше: `Lease candidate LIMIT 1 cost depends on planner and can include completed history`. Числа 551/5051/50051 сверены с сохранённым independent SQL result: fixed 5 pending + 5 running, total 100/1000/10000, после ANALYZE. Это VM callbacks, не latency и не оценка production throughput.
2. **RC-01: сузить accepted_summary.** Фраза `Each distinguishing control retains effective=2 and report/boundary pass` переносит только авторский набор controls. Более сильный matched-cluster review имеет count=1 и blocked при весах 1 и 0. В полном отчёте это уже раскрыто, но standalone summary должен различать эти случаи: пять дополнительных relation dimensions сохраняют 2/pass в авторских fixtures; matched same-study cluster игнорирует zero weight и остаётся 1/blocked. Дефект consumption declared policy сохраняется; нельзя говорить, что все controls прошли threshold.

Обе оговорки уже присутствуют в review_constraints/разделе 3 сводки. Поэтому это синхронизация нормализованного headline/summary с собственной квалификацией, а не опровержение результата или причина повышать severity.

## 2. Выборочная семантическая проверка

Выбраны 16 карточек по риску приоритизации, dedup и потери существенных review caveats. [SELECTED_CARDS.json](SELECTED_CARDS.json) сохраняет проверенные нормализованные поля.

| Карточки | Что перепроверено | Решение и граница |
|---|---|---|
| AUTH-01 | Независимое извлечение RuntimePermission и canonical Rego set; исходные условия all-members-known | 38 против 34, четыре отсутствующих grants подтверждены. P1-conditional допустим как prerequisite, не exploit severity. OPA engine UNRUN. |
| STATE-01 | Real-scoped-CAS review checks, normal/crash/post-terminal controls, source-selected refs | P2; потеря selected receipt даёт refusal/None. Не authority bypass. Здесь crash wave заново не запускалась. |
| STATE-02 | Delivery review, original ack/invalidation result, minimal versus typed HTE basis | P2, прежний STATE-02; DELIVERY-01/02 не отдельные новые incidents. ACTIVE относится к минимальному fixture, full typed incomplete basis может WARNING. Notification published не public signature. |
| PA-01 | Реальные retained first/repeat/fresh results, profile counterfactual и `_put`/`_read`/prepare/issue source | Один round-trip contract: missing canon, затем несовместимость nested datetime/raw JsonValue. Смена writer call сама по себе недостаточна. Нет successful issuance. |
| RD-01 | Review decision и aggregation/population evidence | Сохраняется missing cross-join. Число 4 как правильный model value не установлено. `recomputed_axes` не заменяет full status. |
| RC-01 | Producer count source, original controls и ZERO_MATCHED_CLUSTER | P2/medium остаётся; matched zero-weight result 1/blocked, source gate отдельно. Поправка summary описана выше. |
| CS-01/02 | Machine review decisions и их перенос в registry | CS-01 P2 с relation/provenance caveat. CS-02 правильно понижен до P3 API contract debt; raw P2 сохранён как история, не действующая оценка. |
| PG-01 | Legacy classification и independent review constraints | P3 documented legacy residual risk, не новая regression; selected_exact не полное temporal entailment. |
| SG-04 | Exact preserved SQL measurements и corrected scope | P2 capacity risk, не SLA failure. Full scan completed history возможен; title следует обновить. |
| DC-01/EC-01, DC-02/EC-02 | Разделение producer projection и downstream scope/mode binding, review caveats | Не сливать различные repair seams. Это не утверждение о production multi-scope producer или реально выбранном point estimator. |
| FG-02/GR-03 | Общий mechanism_key и различающиеся cache/changed-set witnesses | Две строки в одной группе, а не две независимые root-cause семьи. |

STATE, PA, RD, CS, PG, DC/EC и SG здесь проверены чтением источников/retained evidence и review, а не новым полным runtime replay. Не следует прибавлять ещё один уровень runtime independence к уже существующим доказательствам.

## 3. Dedup, приоритеты и оценки

- Registry содержит **81 запись и 80 mechanism groups**. Пересчёт из фактических полей совпал. Это не число incidents: в нём есть qualification gaps, reuse decisions, legacy risks и architecture debt.
- STATE-02 включает aliases DELIVERY-01/02; STATE-01 объединяет несколько evidence sources и reviews. PA-01 остаётся одним contract repair. FG-02/GR-03 используют общий mechanism key. SQL review correction RQ-SQL не добавлена новым product finding.
- DC/EC сохраняют отдельные upstream/downstream repairs. Сходство темы не достаточное основание удалить один из них. Аналогично разные lifecycle seams не превращены автоматически в один дефект.
- В приоритетах выбранных cards соблюдены review: STATE-01/02 P2, CS-02 P3, PG-01 legacy/P3; P1 в AUTH условный release/correctness prerequisite, не CVSS. Нет оснований поднимать SA-01 до security/production-loss severity без реального consumer.
- Native/installed/deployed acceptance не заявлена выполненной. Предложенный roadmap не содержит измеренных сроков/стоимости внедрения или обещаний speedup. Synthetic VM counts, rows, source/test file counts не превращены в semantic coverage percentage или SLA.
- Полные текущие `.py` denominators проверены: **2 895** under `source/policy-engine/src`, **3 752** under `source/policy-engine/tests`. Исторические AST/clone counts и полный 29 934-file baseline не пересчитывались заново; они остаются inherited, не новым semantic census.
- `next_source_adapters` явно исключён из checkpoint01–11 synthesis. SA не следует молча добавлять к 81/80 без нового среза и обновления навигации.

## 4. Независимые SA controls

[ADAPTER_BOUNDARIES.json](ADAPTER_BOUNDARIES.json) и [independent_reader.stdout.json](independent_reader.stdout.json) содержат новые controls. Они исполняют неизменённые source bodies через проверенный общий import loader; fixture design и assertions независимы. Нет mock filesystem, DataSchema, registry, parser или contract validator. Это всё ещё compatibility/source-body execution, не native package acceptance.

В отличие от исходного `model_copy`, каждый новый schema payload прошёл **DataSchema.model_validate**. Перед restart используется также публичный `registry.get`, не только private map.

| Порядок/случай | В памяти до restart | Fresh subprocess |
|---|---|---|
| `review.a_b` затем `review_a.b`, оба 1.0.0 | Оба доступны | Только `review_a.b` |
| Обратный порядок, оба 1.0.0 | Оба доступны | Только `review.a_b` |
| `review.alpha` и `review.beta`, оба 1.0.0 | Оба доступны | Оба доступны |
| Collision IDs, версии 1.0.0 и 2.0.0 | Оба доступны | Оба доступны |

Причина в `registry.py:354–361,419–439`: logical conflict check keyed by исходный schema ID/version, а filesystem использует `schema_id.replace('.', '_')/version.json`. Atomic write сохраняет целостный **последний** файл, не уникальность identity. Существующий hash/version conflict guard не ловит collision двух разных logical IDs.

Сфера утверждения: локальный metadata registry и конкретная пара валидных IDs; не CAS payload store, не DataForge DuckDB catalog и не registered SQL source admission. Поведение unregister при shared directory, concurrent writers, migration и platform variants здесь не исполнялось. Сохранять оба IDs при разных версиях в этой проверке не означает безопасность всех операций с shared directory.

Direct lexical census по всем названным src/tests `.py` совпал с авторским: class definition и четыре instantiations в трёх test functions, **нет direct runtime construction**. [CALLER_CENSUS.json](CALLER_CENSUS.json) не исключает aliases/dynamic imports и внешних consumers.

Новый independent contract control: strict без contract → 2 строки; после регистрации matching valid contract → 2 строки; удаление required `value` → настоящий `SchemaError`. Runtime wrapper source также возвращает bare connector при отсутствии contracts; полный bootstrap не запускался. В полном авторском replay подтверждены same-version conflict и оба breaking-contract refusal. SA-03 invalid GeoJSON/property overwrite воспроизведён только авторским harness, без нового независимого protocol corpus; downstream admission остаётся UNRUN.

## 5. Целостность, команды и границы

[INTEGRITY_VALIDATION.json](INTEGRITY_VALIDATION.json) фиксирует независимую проверку:

- 4 259 перечисленных synthesis inputs перечитаны и совпадают по размеру/SHA-256.
- Все 62 embedded primary JSON records с pointers совпадают с первичными записями.
- 28 различных primary report hash links совпадают; все перечисленные independent review paths существуют.
- 197 локальных Markdown file links в двух reports существуют. Это проверка доступности файлов в текущем дереве, не remote access и не полнота будущего ZIP.
- FINDINGS/REGISTRY и REPORT_RU/report попарно byte-exact. Checksum manifests обоих первичных пакетов совпадают.
- Выбранные source locators и все тела/native imports adapter replay сверены с pinned Git blobs; точный named readset в [SOURCE_VALIDATION.json](SOURCE_VALIDATION.json). Tracked source status clean. Не выполнен новый hash всего source checkout.

Команды и результаты:

1. `python3 next_review_synthesis/replay_adapters.py` и `... --read`: exit 0/0, full copied author harness и fresh reader, stdout/stderr сохранены. Дополнительно выполнен isolated replay через import того же harness в отдельный output directory; это повторимость, не новый независимый механизм.
2. `PYTHONDONTWRITEBYTECODE=1 python3 next_review_synthesis/check_adapter_boundaries.py`: exit 0; independent subprocess exit 0, four identity cases и valid/invalid/missing-contract controls.
3. `PYTHONDONTWRITEBYTECODE=1 python3 next_review_synthesis/verify_synthesis.py`: exit 0. Первые две попытки имели ошибки самого checker: optional machine_decisions считался обязательным и permission-set locator не совпал с actual source. stderr сохранены, проверки поправлены без изменений продукта/первичных evidence.

Python 3.12 compatibility profile сохраняется. Native Python 3.14/pytest, OPA engine, полный ConnectorRegistry bootstrap, Parquet/CAS ingestion, DataForge admission, providers, authenticated HTTP и authority/publication остаются **UNRUN**. Не выполнялись installs, external mutations, commits или product fixes. Freeze относится только к этому review и его ограниченному вердикту.
