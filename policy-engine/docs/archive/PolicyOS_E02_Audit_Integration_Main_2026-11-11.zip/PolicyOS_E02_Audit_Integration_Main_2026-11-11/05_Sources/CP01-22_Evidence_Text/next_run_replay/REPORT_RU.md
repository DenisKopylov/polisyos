# Run replay, checkpoints и retained history после checkpoint12

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`, исходный snapshot read-only. Новый срез не повторяет finalize journal, delivery dedupe или bounded-DFS defect из прежних исследований. Все CAS, runs, изменения bytes и fault controls находятся только в `next_run_replay`.

## Главные результаты

1. **RR-01, capacity risk:** один свежий Core invocation-history read повторно загружает каждую запись три раза и проверяет весь owner snapshot chain. На 32 завершённых attempts он делает 192 invocation-record loads, 895 CAS verifies и 2 047 manifest reads. Trace имеет 30 574 bytes, но инструментированные `Path.read_bytes` возвращают суммарно **336 411 374 bytes**. Это измерение логических повторных чтений в полном реальном CAS, не физический disk I/O, не production SLA. Здесь новый composition witness для уже известной стоимости CAS owner checks (ST-02), а не второй независимый CAS defect.
2. **RR-02, P2 на checkpoint producer/reader boundary:** предыдущие state bytes, selected base ref, chain metadata и manifest lineage не сведены в один проверенный контракт. Реальные `create_checkpoint` и `CASCheckpointHook.on_node_complete` могут сохранить checkpoint, который после reopen возвращает не переданный state при рассогласованной паре previous_state/base_ref. CAS/profile integrity при этом PASS. Тот же owner не записывает base в manifest.inputs: реальный generic dependency graph остаётся complete=True после удаления необходимого base blob, хотя materializer честно отказывает.
3. **RR-03, P2 availability на scope-preserving restore:** обычный, не испорченный hook export→restore теряет scope конфигурации CAS. Следующий checkpoint успешно возвращается producer, но исходный tenant-enforced reader отвергает его ownership. У существующего factory уже есть tenant/cell API; audit-only передача этих аргументов устранила выбранный отказ.

Ни одна находка не означает доказанный production incident, неправильную опубликованную policy или полный authority bypass. Full public resume был вызван, но остановился на отсутствующем `duckdb`; outcome не подменён успешным stub. Native Python 3.14, настоящий distributed worker, HTTP и numerical execution не квалифицированы.

## 1. RR-01: полная история на каждый запрос

**Owner:** `team-core`, `core/run/context.py`. Caller/semantic consumers: `team-scientist`.

`_read_runtime_invocation_attempts` сначала вызывает `_read_run_owner_records` (`1526–1590`), который читает весь trace и выполняет `_run_owner_snapshot_chain` (`1073–1171`). Каждый snapshot проверяет свой invocation tail (`762–850`), а переход отдельно загружает новый tail (`1140–1151`). Затем `_run_invocation_attempt_chain` (`382–449`) повторно проходит всю linked history. В выбранной серии H завершённых attempts дают 2H записей, 2H+1 snapshots, **6H record loads**. Проверки exact profile, tenant context, content bytes и linked refs не являются пустыми обёртками: `_load_run_invocation_record` (`650–729`) реально выполняет CAS verification и lineage/profile checks.

Настоящие consumers повторно запрашивают это доказательство: `producer_currentness.py:75–100`, `_invocation_settlement.py:411–436`, `retry.py:2555–2580,3990–4015`, `checkpoint.py:1738,3053,3165`, `component_identity.py:388`; Core `start_child` также читает историю (`context.py:2125`). Это source-reachability, не измерение количества обращений реального workflow.

| Завершённых attempts | Owner snapshots | Invocation loads | CAS verify | Path.read_bytes bytes | Median seconds, 3 samples |
|---:|---:|---:|---:|---:|---:|
| 1 | 3 | 6 | 27 | 808 446 | 0.158 |
| 4 | 9 | 24 | 111 | 7 010 922 | 0.297 |
| 16 | 33 | 96 | 447 | 88 124 910 | 1.413 |
| 32 | 65 | 192 | 895 | 336 411 374 | 2.814 |

Исполнялись полный `RunContext.start`, настоящие engine-owned start/complete writers, fsynced trace и tenant-enforced `FileSystemCAS`. Workflow, registry и state payloads являются явно синтетическими минимальными JSON inputs, output list пуст. Полный node/retry dispatcher не запускался. Fresh-process/fresh-store reopening также возвращает все 32 completed attempts. Задержки включают instrumentation и фоновые работы; нет cold-cache isolation, throughput/RSS/soak измерений или экстраполяции SLA.

### Integrity и контрмера

Отдельный процесс изменяет только audit-owned файлы и после каждого контроля восстанавливает точные исходные bytes. Отказ подтверждён для старейшего invocation blob, его selected manifest profile, первого owner blob, пропущенного middle owner event, cross-tenant trace row и torn trailing JSON. После восстановления reader снова получает 32 attempts. Следовательно, удалять старую историю или заменять её последним JSON без proof contract нельзя.

Request-local memo prototype в harness, без изменения source, сохраняет полную выбранную ref identity и контекст manifest в key. На 32 attempts: **64 реальных record loads вместо 192**, 385 verifies вместо 895; read_bytes **149 015 546 вместо 336 411 374**. Canonical returned bases/outcomes/refs имеют тот же semantic digest. Новая независимая read после повреждения старого blob отказывает; после восстановления проходит.

Это **cost discriminator, не готовое исправление**. Он не квалифицирован для corruption/revocation или смены owner generation внутри одной read; повторная read из того же экспериментального cache использована только для equality на неизменном fixture. Нельзя превращать его в process-wide LRU. Сам memo не устраняет стоимость growing ownership index. Правильное направление: existing owner-scoped validated read context, обработка уже проверенного tail без трёх повторных загрузок, явные generation/scope fences; отдельно retained-history/compaction contract. Сначала сохранить отрицательные контроли и semantics всех callers, затем измерять реальный граф запросов.

## 2. RR-02: сохранённый checkpoint не доказывает восстановленный state

**Owner:** `team-scientist`, `scientist/orchestration/engine/checkpoint.py`.

### Независимый oracle: submitted state == materialized state

В normal control previous_state соответствует selected base, и reopen возвращает ровно submitted state. В отрицательном case из той же схемы:

- CAS base содержит `params.unchanged = original`.
- supplied previous_state содержит `params.unchanged = intended`.
- новый state тоже содержит `unchanged = intended`, но изменён `step`.
- producer строит delta только для step; reopen применяет его к CAS base и возвращает `unchanged = original`.

Фабрика и полный публичный `CASCheckpointHook.on_node_complete` воспроизводят это на real scoped CAS. `resolve_latest_checkpoint` успешно проверяет head/CAS/profile, возвращает неправильный относительно submitted state результат. Это не corrupted-hash bypass: bytes совпадают со своим content ID, но семантическая связь пары не проверяется. Рассогласование pair в эксперименте внесено явно в synthetic input; normal in-process hook сохраняет предыдущие ref/state/depth вместе (`989–997`). Частота или реальное возникновение такого рассогласования не установлены.

В source `create_checkpoint` (`2089–2101`) и async sibling (`2192–2204`) доверяют previous_state/ref/depth; `CASCheckpointHook.__init__` (`913–917`) принимает их отдельно. Runtime metadata export/restore также переносит их отдельно (`1421–1427,1500–1505,1539–1541`). `materialize_checkpoint_state` (`2607–2662`) проверяет CAS, cycle и tenant/cell, но не проверяет run/workflow/sequence/chain-depth continuity между ancestor и child и не знает ожидаемый полный state digest. Same-scope foreign-run/wf-b ancestor sequence 77 под child run-a/wf-a sequence 1 проходит selected materialization. Это crafted malformed lineage, не свидетельство чужого tenant доступа.

### Manifest dependency closure

Оба checkpoint writers передают kind/media/schema, но не inputs (`2128–2141`, async `2231–2246`). Base ref хранится только внутри JSON. Настоящий `resolve_dependency_graph(..., preserve_manifest_profiles=True)` видит root 1 / edges 0 / complete=True. После временного удаления base blob результат graph **не меняется**; `materialize_checkpoint_state` в той же среде отказывает `blob missing`. Blob затем восстановлен и state снова читается.

Core graph здесь выполняет свой контракт обхода manifest.inputs; чинить нужно checkpoint producer, а не заставлять generic graph угадывать все JSON refs. Не доказано, что production CAS GC уже удаляет такой base или что publication использует этот graph как checkpoint replay admission.

### Действующие контрмеры и limits

- Штатные truthful depth arguments дают full checkpoint на шагах 7 и 14 после глубины 6. Серия из 18 writes правильно materializes state.
- GC с max_checkpoints=3 сохраняет bases retained increments; history достигает 10 entries, затем сокращается. Это dependency-aware retention, не обещание hard cap ровно 3.
- GC только сокращает local history, не удаляет CAS blobs. Нельзя по нему заявлять bounded CAS retention.
- С ложным previous_chain_depth=0 public writer выдаёт depth 1 на каждом шаге; consumer проходит 10 реальных chain members. Более длинный stack/DoS не запускался. Cap является writer convention, не independent consumer bound.
- Повреждение base blob отказывает; восстановление возвращает normal state.

**Направление:** existing checkpoint owner должен разрешать selected base, связать previous-state identity с его материализованными bytes или устойчивым digest, проверять same run/origin workflow/sequence/depth, явно записывать selected dependency edges. Reader должен иметь независимый предел и typed refusal; будущий ремонт не может ослабить scope/profile/corruption controls. Counterexample для acceptance: mismatch пары, foreign run/workflow/sequence, недостоверная depth, missing base при generic lineage, sync/async и metadata restore. Не выдвигается универсальная замена checkpoint subsystem.

## 3. RR-03: hook restore сохраняет tenant в metadata, но не в CAS constructor

Untouched `export_runtime_metadata` → `restore_checkpoint_hook_from_runtime_metadata` → `on_node_complete` исполнялся без испорченных входов. Первый hook был создан с tenant-enforced CAS. Restore проверяет tenant/cell metadata, но вызывает `build_artifact_store(store_config)` без этих аргументов (`checkpoint.py:1523–1545`). Factory поддерживает explicit scope (`core/artifacts/backends/config.py:51–72`), но не сохраняет его в сериализованном config.

Следующий write возвращает checkpoint ref. Изначальный scoped reader отказывает `ArtifactOwnershipError: payload is not readable ... for read_raw_manifest`. Control со scoped direct hook читает его checkpoint успешно. Audit-only wrapper передаёт существующему factory tenant_id/cell_id; тот же restore owner и untouched data теперь дают readable checkpoint и верный state. Это проверяет причинную роль factory scope без фиктивного CAS success.

`runner/_activity_worker.py:455–462,514–543` действительно восстанавливает этот hook и передаёт его merge/checkpoint producer. Full worker/Ray/Temporal execution не запускался: это source-traced reachability плюс actual hook chain, не distributed qualification. В отрицательном mismatched metadata exploratory run этот ownership refusal **маскировал** state-binding issue; поэтому wrong-state через remote restored scope не утверждается.

**Направление:** передавать exact admitted scope через существующий factory и сохранить enforcement semantics. Для non-filesystem backend не угадывать поддержку: factory сейчас явно отказывает explicit scope. Acceptance требует native worker roundtrip, immutable selected base access, foreign scope rejection, missing scope refusal и same owner after restart. Scope grant не должен возникать из одного untrusted metadata поля.

## Что реально было и не было выполнено

- Полные Core context/CAS/manifest/trace и Scientist checkpoint/hook modules, без AST extraction, constructor stubs, no-op verification или fake reader results.
- Python **3.12.14**, source требует **3.14**. Reused audit loader только in-memory переписывает unparenthesized multi-except и TypeVar default import; ряд eager package facades не выполняется. Точные hashes/rewrite список в LOADER_BOUNDARY files. Native import без adapter отказывает SyntaxError.
- `POLISYOS_AUDIT_CHAIN_ENABLED=0`: optional parallel audit sink не измерялся; настоящий Core trace и owner chain работают. Tenant/cell enforced на основных CAS.
- Public `resume_from_checkpoint` вызван для обоих direct hook controls и вернул ModuleNotFoundError `duckdb` при import builder. Это **BLOCKED before resume behavior**, не failing product checkpoint. Зависимости не устанавливались, import не обходился stub.
- Существующие выбранные unit tests прочитаны, но native pytest не запускался: core phase0 RunContext и Scientist checkpoint (normal incremental, cross-tenant base, metadata roundtrip, invalid history). Нет полного test coverage denominator.
- Нет production files/data, HTTP, published policy, external services, power-loss, concurrent writers, native benchmark или rollout.
- Git snapshot **shallow=true, rev-list count=1**. `git log -- <owner>` показывает только snapshot commit. Commit introduction/regression age/blame/historical before-after **not established**; source не выдаётся за историю развития. Версии RunOwnerSnapshot 1.0.1/1.0.2 и checkpoint 1.3/1.4 являются поддерживаемыми codec branches, не corpus proof.

## Команды, честность ошибок и воспроизведение

Запускать с `PYTHONDONTWRITEBYTECODE=1 POLISYOS_AUDIT_CHAIN_ENABLED=0 python <script>`. Main history: `probe_history.py`; свежие controls: `probe_history_controls.py`; cost discriminator: `probe_read_memo.py`; checkpoint: `probe_checkpoint.py`; scope/hook: `probe_checkpoint_hook.py`; dependency closure: `probe_checkpoint_lineage.py`. Затем `validate_evidence.py`.

Начальные harness ошибки сохранены, не названы product defects: неверная сигнатура tenant_scope; попытка model_dump у dataclass AccessScope после всех четырёх завершённых growth points; write_checkpoint_head вместо update_checkpoint_head и отсутствие writer_pid/hostname; недопустимый дефис WorkflowSpec id. Исходные script revisions и stderr retained. History growth wave не перезапускалась ради green: `results.partial.json` содержит все 4 points / 12 samples, отдельный fresh-process controls script завершил reopening и `results.json`. Первый corrected hook attempt затем действительно обнаружил ownership refusal, и он сохранён как продуктовый discriminator, а не удалён.

Для нового воспроизведения скопировать только актуальные scripts + compat_loader в новую пустую sibling-папку, сохранив `../source`. Scripts отказывают при существующих state folders. Controls и memo запускать последовательно: они временно меняют один history fixture. Checkpoint/hook используют отдельные root paths. Lineage script ожидает `checkpoint_state_v3` от актуального checkpoint script. Native missing dependencies останутся honest blockers. Продуктовый source не меняется.

`validate_evidence.py` сверяет deciding assertions, source hashes с pinned Git, source clean state, input provenance, artifact hashes и границы исполнения. Его PASS означает целостность audit evidence о локальных дефектах/границах, **не release PASS**.
