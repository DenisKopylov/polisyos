# PolicyOS: следующий scaling/lifetime срез после checkpoint01

**10 ноября 2026; read-only; commit `f1541ed155f278689be48a8c7ac56c3e200210f7`.**

## Главный результат

Подтверждён дополнительный concurrency-механизм семейства SYS-07: `RunIndexService` может сохранить старые records вместе с новыми fingerprints. После такого interleaving даже `refresh(force=True)` считает stale record неизменившимся. Это не просто дублирование работы. Отдельно уточнена стоимость validity overlay: квадратичная зависимость возможна уже с **одним** pending batch, если вместе растут число runs и число targets этого batch. Несколько одновременно admitted batches для этого не нужны.

Новый срез также подтверждает прежнее ограничение каталога на реальных disk traces и настоящем parser/adapter body, измеряет warm incremental refresh, реальный JSONL append/replay и повторное обучение predictor при пополнении/восстановлении VOI history. Исправлений продукта нет. Итог ниже не является native qualification, production capacity estimate или разрешением release.

## 1. NS-01: cache и fingerprints публикуются разными поколениями

**Классификация:** `new_mechanism` внутри SYS-07, связанное с прежним no-coalescing. Уверенность в механизме высокая; уровень `bounded_probe` + `source_traced`. Предварительная severity: medium, приоритет проверки/исправления высокий среди caching-изменений. Ущерб production не измерен.

Инвариант: snapshot record, fingerprint, owner-map и cache metadata должны описывать одно опубликованное поколение. `force` обязан пересмотреть реально изменившийся источник, а не подтверждать несогласованную пару.

Точная последовательность:

1. A выполняет настоящий `_refresh_index_incremental` для старого trace. Внутри него `_dir_fingerprints` уже заменён; возврат A приостановлен до присваивания cache в `refresh`.
2. В test-only каталоге к trace дописывается обычный non-lifecycle event; tenant остаётся A. Время файла выставлено явно для детерминированного порядка.
3. B выполняет refresh целиком и публикует новые fingerprints и новые records.
4. A продолжает и перезаписывает `_cache`/`_artifact_tenants` старым результатом. `_dir_fingerprints` остаются от B.
5. Следующий `force=True` видит новый fingerprint и matching stored fingerprint, поэтому повторно использует старый cached record без чтения trace.

**Наблюдение:** во всех 5 same-tenant append-only повторах старый список был `run-1, run-0`, свежий independent instance показывал `run-0, run-1`. Forced refresh разобрал **0 trace records**. Cached mtime оставался старым при новом fingerprint mtime. В дополнительном варианте с намеренной синтетической сменой tenant старая summary также удерживалась; этот вариант не нужен для вывода и **не доказывает межтенантную утечку**. Serial control вернул новую запись; ещё одно изменение trace заставило старый instance перечитать его.

Источник: `runtime/http/services/run_index.py:95–118, 304–338`, особенно публикация `_dir_fingerprints` в конце rebuild и отдельное присваивание cache в refresh. Runtime dependency создаёт один `RunIndexService` в application-scoped context: `dependencies.py:136–140, 207–214`; container возвращает тот же context. Sync routes `/runs` и `/runs/batch` вызывают его методы (`routes/runs.py:6557–6636`). Это source reachability общей службы, **не исполненный конкурентный HTTP-тест**. В эксперименте scheduling window расширено Event-барьером на method-return seam; не оценена его естественная вероятность.

**Минимальное направление:** existing `RunIndexService` должен владеть согласованной публикацией. Варианты: сериализовать refresh на instance либо строить immutable generation целиком и атомарно публиковать record/fingerprint/owner-map bundle с проверкой актуальности. Один только TTL, capacity tweak или lock вокруг присваивания cache недостаточен. Не требуется глобальный framework. Сохранить freshness, validity overlay, tenant guards и полный catalogue contract.

**Acceptance:** тот же append-only сценарий через настоящий service и HTTP concurrency на Python 3.14; старый leader не может заменить более новое поколение. Повторить failed/cancelled leader, TTL/force, независимые instances, deletion и owner-map. Ни stale projection, ни заблокированный навсегда waiter не допускаются. До этого finding не объявляется native accepted.

## 2. NS-02: один pending batch даёт N × T повторного чтения/validation

**Классификация:** `deepened_existing`, SYS-07; прежний спорный multi-pending сценарий не используется для вывода о допустимом growth. Уверенность в стоимости selected methods высокая; полная admission reachability остаётся source-level. Severity medium для потенциальной стоимости чтения; production availability failure не установлен.

`EpochValidityPendingBatch.targets` имеет `min_length=1`, но не `max_length`. Admission проверяет единственность активного batch через `batch_pending`, затем копирует полный verifier target denominator в один pending artifact. Ограничение числа batches поэтому не ограничивает число targets одного batch. Источники: `core/contracts/decision_validity.py:792–862`; `scientist/validation/decision_validity.py:1001–1029, 1077–1098`.

Проба использует **реальные** target/batch Pydantic definitions, их prefix-validator, strict JSON loader, pending enumeration, overlay и list method. В каждом corpus ровно один schema-valid JSON batch; CAS/reference authority заменена fixture и не проверялась. В cache N записей, только одна принадлежит запрошенному tenant; requested page size = 1. Каждая запись имеет evaluation, и overlay выполняется до tenant/page filtering.

| N runs | T targets одного batch | Размер batch | JSON bytes прочитано за один list | Повторно validated target rows за list |
|---:|---:|---:|---:|---:|
| 50 | 50 | 7 980 | 399 000 | 2 500 |
| 200 | 200 | 29 380 | 5 876 000 | 40 000 |
| 800 | 800 | 115 180 | 92 144 000 | 640 000 |

На каждый point выполнены 3 list calls; полные times/min/max и counters сохранены. Bytes и число JSON reads измерены непосредственно; число target validations получается из `reads × targets` для реально загруженных полных batch models. В общем случае R означает только число cached records, которым нужна validity projection: механизм даёт O(R × T) parse/validation work и R × S(T) прочитанных JSON bytes. Здесь R=T=N, поэтому это O(N²). Run без decision packet в настоящем `_with_current_validity` возвращается раньше и не входит в R. Конечные timings сами по себе не являются доказательством асимптотики. `any(...)` может прекращать membership scan раньше, но полный JSON/model parse к этому моменту уже выполнен.

Exact overlay прочитал один batch, а не N. Unrelated packet остался active и тем же evaluation object; targeted packet стал stale. Удаление pending file убрало overlay. Empty targets и неверный applied prefix отвергнуты настоящим validator. Эти guards показывают, почему просто убрать overlay небезопасно.

**Ограничения:** snapshot cache и persisted batch синтетические; verifier, authenticated admission, CAS signature и lifecycle packet writes не запускались. Не утверждается, что реальная система уже накопила 800 таких targets. `ArtifactRef` fixture не является валидным production evidence. Проба заменяет `_with_current_validity` адаптером, вызывающим настоящий overlay; полный packet/evaluation/CAS read не выполнен. Local bytes read не равны physical disk I/O: page cache мог обслуживать чтения. Наличие schema-valid body не доказывает успешный full admission.

**Направление:** existing Decision Validity owner может предоставлять request-consistent projection snapshot/packet lookup, переиспользуемый для одного list/batch read; нужно сохранить invalidation и restart-safe pending semantics. Без отдельного доказательства нельзя переиспользовать stale global cache. Сначала отсеивать tenant допустимо только при сохранении authoritative tenant/authorization contract; сортировка/фильтры по validity всё равно требуют правильной projection. Acceptance: admitted single batch с растущим target denominator, removal/recovery/corruption controls, exact/list/batch consumers, unchanged и changed owner generations.

## 3. NS-03: реальный trace loader подтверждает bounded catalogue; warm refresh не бесплатен

**Классификация:** `reconfirmed/deepened_existing`, SYS-07 / AUD-001. Не новый независимый дефект.

Corpus: 100 / 1 000 / 10 001 directories; каждый содержит disk `trace.jsonl` с настоящим schema-valid `RUN_STARTED` и non-terminal fact. Выполнены unchanged trace parser, adapter, summary/index definitions. Ранее adapter был целиком fixture. Теперь заменён только finalize-recovery collaborator: он проверяет, что synthetic каталог не содержит journal, и не делает recovery. CAS manifests, decision packets и artifact-owner permissions не входят в этот workload. Несколько неиспользованных DTO annotations и ArtifactRef остаются fixtures.

- Default cap 10 000: последний реально существующий run из 10 001 не находится exact lookup и отсутствует в tenant list. Его trace не разбирается. При удалении trace первого retained run освободившийся slot принимает ранее пропущенный run.
- Удалённый retained run исчезает. Изменение trace одного retained run вызывает **одну adaptation и 2 parsed records**, а не перепарсинг всего corpus.
- Для unchanged warm **forced** refresh parser вызовов нет, но filesystem enumeration/fingerprinting остаются. За 3 вызова измерено 903 / 9 003 / 90 006 `Path.stat` calls. При N≤cap это `3 × (3N+1)` для данных fixtures. Это Python stat invocations, не измерение disk syscalls/IOPS.
- Cold parse counts: 100 / 1 000 / 10 000. Все input sizes, times, counters и deletion/change controls находятся в `results.json`.

Warm forced refresh выбран для измерения incremental scan отдельно от TTL-hit. Decision Validity generation здесь constant/no-packets fixture; прежний full validity hashing на каждом TTL hit остаётся отдельным подтверждённым механизмом checkpoint01, а не измеренной частью этой серии.

**Направление:** отделить полный directory/catalogue denominator от bounded decoded-object cache. Existing direct-child derivation/strict run source helper можно рассмотреть как building block, но он имеет другой terminal/authorization contract и не является готовой drop-in заменой для всех list/live/debug потребителей. Увеличить cap означает только отложить omission. При сохранении текущего решения нужно явно документировать ограничение, не выдавая bounded total за полный.

## 4. NS-04: VOI history заново fit при каждом принятом observation и replay

**Классификация:** `deepened_existing`, SYS-08. Подтверждён cost mechanism, не ошибочность статистической модели.

Настоящий `PredictiveVOIScheduler._record_runtime_history` после каждого observation с objective создаёт execution record и вызывает настоящий `RuntimePredictor.fit` на полной текущей истории. В `from_snapshot` он вызывается в цикле по observations. В selected method/body probe получены:

| Принятые observations H | Полных fit calls | Просмотренных records суммарно |
|---:|---:|---:|
| 50 | 50 | 1 275 |
| 200 | 200 | 20 100 |
| 800 | 800 | 320 400 |

Counters получены instrumentation `all_records` вокруг настоящего store/fit. Формула `H(H+1)/2` следует из тела метода и подтверждена каждой серией. Выполнены 3 повтора; missing-objective control не увеличил store и не вызвал fit. Наблюдения synthetic, не результат реального Scientist scoring/admission. Full scheduler и `from_snapshot` не импортировались/не исполнялись; replay loop traced в `voi_scheduler.py:1175–1206`, запись в `1430–1452`, producer call в `1127–1128`.

Соседний dispatcher getter из checkpoint01 также строит новый predictor при каждом qualifying read, но caller guard важен: runtime selection должен быть включён и fallback отличаться от declared backend (`dispatch.py:1034–1062, 1112–1122`). Это не стоимость каждого dispatch безусловно.

**Направление:** existing history/predictor owner, revision-aware reuse на read и один final fit при bulk replay, если сохраняется семантика промежуточных потребителей. Не подменять историческую evidence произвольным rolling window. Acceptance: final prediction equality на одном полном corpus, новый event invalidates, failed/empty history и per-method/backend residuals сохранены, output selection decisions сравнимы на supported dependencies.

## 5. NS-05: persistent JSONL и process history имеют разные lifetimes

**Классификация:** подтверждённое поведение / `deepened_existing`, SYS-08; **не объявляется отдельным доказанным correctness bug** без решения о startup replay contract.

В отличие от source-extraction остальных probes, `history.py` загружен целиком с диска через isolated module name. Внутри только stdlib, NumPy и Pydantic; глобальный state root установлен в test-only temp directory.

- 100 / 1 000 / 5 000 records реально appended в JSONL; размеры 52 390 / 524 990 / 2 632 990 bytes. Import с `clear_existing=True` трижды даёт N records и тот же fitted prediction. Исходные JSONL bytes/hash не меняются от replay.
- Обычный повторный append-oriented import даёт 2N, как документировано. `clear()` очищает память, не файл. Это controls, а не дефект дублирования по умолчанию.
- Два настоящих отдельных Python-процесса использовали **один и тот же** configured state path. Первый записал 7 records и fitted predictor; во втором global getter вернул 0 in-memory records, predictor не fitted, на диске сохранились все 7 строк.

`get_global_selection_history` создаёт store с auto-persist, но не вызывает import (`history.py:501–510`). `advisor._resolve_evidence_sources` и dispatcher getter используют текущий process store; при 0 records evidence/predictor отсутствуют. README называет JSONL durable user state и отдельно описывает явный migration import; он не обещает автоматическое восстановление same-path store. Нельзя переводить это наблюдение в «данные потеряны»: файл цел и explicit replay работает. Но persistent output сам по себе не обеспечивает межпроцессное learning continuity, и это стоит решить явно.

**Направление:** владелец должен определить startup/replay policy, retention и crash/corruption поведение. Если нужна автоматическая continuity, использовать existing import owner один раз при startup, не на каждом getter; предусмотреть torn trailing line и concurrent writers. Эта работа не выполнена и не предложена как безусловный drop-in fix.

## Среда, reproducibility и ограничения

- Python 3.12.14, NumPy 2.3.5, Pydantic 2.13.4. Repo baseline Python 3.14; Pydantic profile также вне `>=2.12.5,<2.13`. Поэтому ни одна строка здесь не получает `native_targeted` или `installed_integration`.
- `normal_import.*` сохраняет обычную попытку import `RunIndexService`: она остановилась на Python 3.14 exception syntax в `core/artifacts/store.py:2155`. Это tooling blocker, не product failure. Полный import runtime не заявляется.
- Первая версия измерителя тоже остановилась при AST parse всего `core/contracts/runtime.py` на unrelated Python 3.14 syntax. Failure сохранён в `instrument_v1.*`. Финальный extractor парсит только исходные выбранные undecorated top-level spans этого файла, не переписывая syntax остального source. `parse_fallbacks` и hashes/span locators сохранены. Остальные выбранные modules парсятся полностью, затем исполняются только перечисленные definitions.
- Синтетические disk fixtures создаются в `tempfile.TemporaryDirectory` и удаляются только владельцем; исходный checkout не меняется. Threads bounded by Event timeouts; BLAS/OMP threads ограничены одним. Нет E02, provider calls, приложений, live DB, native deployment, production requests или численных product jobs.
- Cold times измерены по одному cold corpus на size; повторные warm/list/replay/VOI серии имеют 3 samples. Не выдавать один cold timing за distribution. Порядок series фиксирован, отдельного controlled performance lab нет; фоновые задачи и filesystem cache не исключены.
- Новые memory/RSS/soak измерения здесь не снимались. Retention/limiter/witness weakref controls остаются результатами checkpoint01, а не незаметно повторёнными tests.
- Скрипт продолжает сохранять completed sections после каждой серии. `exitcode.txt = 0` означает завершение этого probe и его controls, **не общий PASS продукта**.

Команда из workspace root:

```sh
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 \
python policyos_deep_audit/next_scaling/probe_next_scaling.py \
  --source policyos_deep_audit/source \
  --output policyos_deep_audit/next_scaling/results.json
```

Основные evidence: `results.json`, `probe_next_scaling.py`, `stdout.txt`, `stderr.txt`, `exitcode.txt`; дополнительные `SOURCE_VALIDATION.json`, `SOURCE_EXCERPTS.txt`, `FINDINGS.json`, `REVIEW_RU.md` и `SHA256SUMS.txt`. `initial_completed_results.json` сохраняет завершённый ранний run до добавления same-tenant append-only race discriminator. Выводы и численные серии в этом отчёте относятся к финальному `results.json`.

## Следующий acceptance, без расширения scope

1. В supported profile подтвердить coherent run-index generation на shared service/HTTP, затем проверить release/exception/cancellation.
2. Прогнать реальный admitted single pending batch и реальные packet consumers. Сохранить complete target denominator и fail-closed stale reaction; измерить parsed bytes отдельно от physical I/O.
3. Сделать полный catalogue lookup/list test N>cap с manifests/owner-map и tenant guards, не только trace-only rows.
4. Зафиксировать learning continuity/replay contract и проверить prediction-preserving bulk replay/revision reuse.

Минимальная программа использует существующих owners. Она не разрешает менять исходники и не закрывает оставшиеся направления общего аудита.
