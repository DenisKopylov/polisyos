# Независимая проверка scaling witness

Отдельный reviewer прочитал исходники и финальный probe/results, не получая задания воспроизвести заранее желаемый вывод. Повторный benchmark и правки source не выполнялись. Это независимый source/instrument review, не отдельный native replay.

## Подтверждено

- `_dir_fingerprints` публикуется внутри `_refresh_index_incremental`, cache публикуется отдельно в `refresh`. Между ними существует исследованное окно. Поздний возврат A оставляет старые records при новых fingerprints B.
- `force=True` отменяет TTL shortcut, но не incremental reuse. Matching fingerprint сохраняет старый record, пока fingerprint не изменится. Новый instance, ещё одно изменение trace или eviction/re-entry могут восстановить состояние. Слово «навсегда» недопустимо.
- Same-tenant append-only controls действительно показывают stale sort order и не зависят от изменения owner/tenant. `_run_sort_key` использует сохранённый mtime.
- Runtime context общий для приложения, `/runs` sync handler использует его. Source поддерживает возможность concurrent callers; полный HTTP execution в этом профиле не проверялся. Оба refresh могут войти без force при пустом/expired cache.
- Single pending batch cost: R × T model parsing/validation и R × S(T) прочитанных bytes, где R только записи с projection. В workload R=T=N. 3 списка для N=800 дали 2 400 reads, 276 432 000 bytes; 1 920 000 target instances вычислено из полного validated document, а не отдельного validator callback counter.

## Принятые уточнения

1. В отчёте общая формула заменена с N на R для projection-bearing records. Trace-only runs без decision packet не включаются в R.
2. Прямо указано, что pending probe подменяет `_with_current_validity` адаптером к настоящему overlay и не выполняет полный CAS projection read.
3. Event wrapper сознательно увеличивает publication gap; частота production race не оценивалась.
4. Не заявлены cross-tenant exploit, permanent unrecoverability, физический disk traffic, Python 3.14/native/installed acceptance.

Замечаний, опровергающих два механизма, reviewer не обнаружил. Остальные series и документ не прошли отдельный полный независимый review; их локальные assertions и source/hash validation не следует подменять этим review.
