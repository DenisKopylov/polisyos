#!/usr/bin/env python3
"""Pinned, read-only scaling/lifetime probes. Artifacts and fixtures stay outside source.

Uses unchanged AST definitions, except counting wrappers and explicit non-exercised
dependency fixtures. Full history.py is imported from source in a private module.
This is NOT Python 3.14/native package/HTTP/deployed qualification.
"""
from __future__ import annotations
import argparse, ast, collections, dataclasses, enum, gc, hashlib, importlib.util
import json, logging, os, pathlib, platform, re, statistics, subprocess, sys, tempfile
import threading, time, types
from concurrent.futures import ThreadPoolExecutor
from datetime import UTC, datetime
from typing import Any, Literal, cast
import numpy as np
import pydantic
from pydantic import BaseModel, ConfigDict, Field, model_validator, ValidationError

P=argparse.ArgumentParser();P.add_argument('--source',type=pathlib.Path,required=True);P.add_argument('--output',type=pathlib.Path,required=True);A=P.parse_args()
ROOT=A.source.resolve()/'policy-engine/src/polisyos'; SOURCES={}; EXTRACTS=[]; FALLBACKS=[]

def load(path,names,env=None):
    raw=(ROOT/path).read_bytes();SOURCES[path]=hashlib.sha256(raw).hexdigest()
    try:
        tree=ast.parse(raw)
        selected=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names]
    except SyntaxError as exc:
        # Python 3.14 syntax elsewhere in a module must not be silently rewritten.
        # Parse only original selected top-level, undecorated source spans.
        lines=raw.decode().splitlines(keepends=True);selected=[]
        for i,line in enumerate(lines):
            match=re.match(r'^(?:class|def) (\w+)\b',line)
            if match and match.group(1) in names:
                assert not (i>0 and lines[i-1].startswith('@'))
                end=next((j for j in range(i+1,len(lines)) if lines[j].strip() and not lines[j][0].isspace() and not lines[j].startswith('#')),len(lines))
                node=ast.parse(''.join(lines[i:end])).body[0];ast.increment_lineno(node,i);selected.append(node)
        FALLBACKS.append(dict(path=path,parse_error=str(exc),fallback='Unmodified selected top-level definition spans; no surrounding module rewrite'))
    assert {n.name for n in selected}==set(names),(path,names)
    for n in selected: EXTRACTS.append(dict(path=path,definition=n.name,start=n.lineno,end=n.end_lineno))
    mod=types.ModuleType('audit_extract_'+str(len(EXTRACTS)));sys.modules[mod.__name__]=mod
    mod.__dict__.update(env or {})
    exec(compile(ast.fix_missing_locations(ast.Module(body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0)]+selected,type_ignores=[])),str(ROOT/path),'exec'),mod.__dict__)
    return mod.__dict__

def method(path,owner,name,env):
    raw=(ROOT/path).read_bytes();SOURCES[path]=hashlib.sha256(raw).hexdigest();tree=ast.parse(raw)
    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==owner)
    n=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name==name)
    assert all(isinstance(x,ast.Name) and x.id=='staticmethod' for x in n.decorator_list)
    EXTRACTS.append(dict(path=path,definition=owner+'.'+name,start=n.lineno,end=n.end_lineno))
    ns=dict(env);exec(compile(ast.fix_missing_locations(ast.Module(body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0),n],type_ignores=[])),str(ROOT/path),'exec'),ns)
    value=ns[name];return value.__func__ if isinstance(value,staticmethod) else value

def measured(fn,repeats=3):
    times=[]
    for _ in range(repeats):
        t=time.perf_counter();fn();times.append((time.perf_counter()-t)*1000)
    return dict(samples_ms=times,median_ms=statistics.median(times),min_ms=min(times),max_ms=max(times))

class ArtifactRefFixture(BaseModel):
    """Only a stand-in for unused ref validation; no CAS authority is claimed."""
    artifact_id:str;kind:str='fixture';media_type:str='application/json'

BASE=dict(BaseModel=BaseModel,ConfigDict=ConfigDict,Field=Field,model_validator=model_validator,
          Any=Any,Literal=Literal,datetime=datetime,UTC=UTC,Enum=enum.Enum,StrEnum=enum.StrEnum,
          dataclass=dataclasses.dataclass,ArtifactRef=ArtifactRefFixture,Digest=str)
contracts=load('core/contracts/decision_validity.py',['_utc_now','DecisionValidityStatus','EpochValidityBatchTarget','EpochValidityPendingBatch','DecisionValidityEvaluation'],{**BASE,'DecisionTriggerRecord':dict})
trace=load('core/trace/record.py',['utc_now','RunTerminality','TraceRefs','TraceRecord'],BASE)
unexercised_details=('RunOperatorDiagnostic','PolicyDesignCaseProjection','RunCandidateSimulationProjection',
 'RunFailedCandidateSimulationProjection','RunGenericCycleSimulationProjection',
 'MethodExecutionProducerDiagnostic','DirectMethodExecutionRunProjection','RunConditionalTransportCandidateProjection')
dtos=load('core/contracts/runtime.py',['CursorPage','RunRecordV1','RunSummary','RunDetails'],
    {**BASE,**{k:dict for k in unexercised_details},'SourceKind':Literal['core_run'],
     'RunTerminality':trace['RunTerminality'],'DecisionValidityStatus':contracts['DecisionValidityStatus']})

COUNTS=collections.Counter()
class CountPath(type(pathlib.Path())):
    def stat(self,*a,**kw):
        COUNTS['stat_calls']+=1
        return super().stat(*a,**kw)
    def read_text(self,*a,**kw):
        value=super().read_text(*a,**kw);COUNTS['text_reads']+=1;COUNTS['text_bytes']+=len(value.encode());return value

def no_recovery(store,run_dir):
    # Synthetic fixtures explicitly contain no pending finalize journal.
    assert not (run_dir/'.finalize-journal.json').exists()
    COUNTS['no_journal_recovery_calls']+=1

adapter=load('runtime/http/services/adapters/core_run.py',[
 'CoreRunAdapterResult','load_core_run','_admit_run_terminality','_iter_trace_lines','_parse_trace_record'],
 {**BASE,**trace,'recover_pending_run_finalize':no_recovery,'logger':logging.getLogger('probe'),
  '_RUN_MANIFEST_KIND':'core.run_manifest'})
orig_parse=adapter['_parse_trace_record']
def count_parse(line):
    COUNTS['trace_records_parsed']+=1;COUNTS['trace_bytes_parsed']+=len(line.encode());return orig_parse(line)
adapter['_parse_trace_record']=count_parse

class ValidityNoPacket:
    def __init__(self,store):pass
    def current_projection_generation_ref(self):return 'constant:no-decision-packets'
    def get_evaluation(self,*a,**kw):raise AssertionError('No decision packet in trace-only corpus')

idx=load('runtime/http/services/run_index.py',[
 'IndexedRunRecord','_RunDirFingerprint','RunIndexService','_core_result_to_indexed','_parse_cursor',
 '_iter_run_dirs','_fingerprint_run_dir','_trace_mtime_ns','_as_utc','_run_sort_key','_register_artifact_tenants'],
 {**BASE,**dtos,'time':time,'load_core_run':adapter['load_core_run'],'DecisionValidityService':ValidityNoPacket})
Service=idx['RunIndexService']

def write_run(root,name,tenant='A',extra=0):
    d=root/name;d.mkdir(exist_ok=True)
    record={'run_id':name,'phase':'core','event':'RUN_STARTED','tenant_id':tenant,
            'ts':'2026-11-10T00:00:00Z','run_terminality':'non_terminal'}
    lines=[json.dumps(record,separators=(',',':'))]
    for i in range(extra):lines.append(json.dumps({**record,'phase':'test','event':'TICK','run_terminality':None,'metrics':{'tick':i}},separators=(',',':')))
    (d/'trace.jsonl').write_text('\n'.join(lines)+'\n');return d

def catalogue_series():
    out=[]
    with tempfile.TemporaryDirectory(prefix='policyos-next-catalogue-') as tmp:
        for n in (100,1000,10001):
            root=CountPath(tmp)/str(n);root.mkdir()
            for i in range(n):write_run(root,f'run-{i:05}',tenant='B' if i==n-1 else 'A')
            svc=Service(store=None,core_runs_root=root)
            COUNTS.clear();t=time.perf_counter();svc.refresh(force=True)
            cold=dict(COUNTS);cold['elapsed_ms']=(time.perf_counter()-t)*1000
            COUNTS.clear();warm=measured(lambda:svc.refresh(force=True));warm.update(COUNTS)
            assert warm.get('trace_records_parsed',0)==0
            target=f'run-{n-1:05}'
            try:found=svc.get_run(target).run_id==target
            except KeyError:found=False
            found_list,page=svc.list_runs(tenant_id='B',limit=1)
            assert found==(n<=10000) and page.total==(1 if found else 0)
            # Changing a retained trace invalidates just that record.
            write_run(root,'run-00000',tenant='C',extra=1)
            COUNTS.clear();svc.refresh(force=True);changed=dict(COUNTS)
            assert svc.get_run('run-00000').summary.tenant_id=='C'
            # Removing one retained trace frees a slot; an omitted record re-enters.
            (root/'run-00000'/'trace.jsonl').unlink();svc.refresh(force=True)
            assert svc.get_run(target).summary.tenant_id=='B'
            try:svc.get_run('run-00000');raise AssertionError('deleted run retained')
            except KeyError:pass
            out.append(dict(directories=n,default_cap=10000,indexed_before_deletion=min(n,10000),
                cold=cold,warm_force_3_calls=warm,changed_one_trace=changed,
                requested_tenant_B_count_before_deletion=page.total,exact_found_before_deletion=found,
                deleted_run_removed=True,omitted_or_last_run_found_after_slot_freed=True))
    return dict(measurements=out,limit='Real disk traces, real trace validator, unchanged adapter/index/summary DTO bodies. No manifest/CAS/decision packets; finalize recovery replaced by an assertion that no journal exists. Some unused DTO annotations and ArtifactRef are fixtures. Normal package import and HTTP not exercised.')

def concurrent_publication():
    rows=[]
    for repetition in range(5):
        with tempfile.TemporaryDirectory(prefix='policyos-next-race-') as tmp:
            root=CountPath(tmp);write_run(root,'run-0',tenant='A')
            svc=Service(store=None,core_runs_root=root);ready=threading.Event();release=threading.Event()
            original=svc._refresh_index_incremental
            def delayed_return():
                result=original()
                if threading.current_thread().name.startswith('late-old'):
                    ready.set();assert release.wait(10)
                return result
            svc._refresh_index_incremental=delayed_return
            with ThreadPoolExecutor(max_workers=1,thread_name_prefix='late-old') as pool:
                future=pool.submit(svc.refresh,force=True);assert ready.wait(10)
                write_run(root,'run-0',tenant='B',extra=1)
                svc.refresh(force=True)
                assert svc._cache['run-0'].summary.tenant_id=='B'
                release.set();future.result(timeout=10)
            after_late=svc._cache['run-0'].summary.tenant_id
            actual_fp=idx['_fingerprint_run_dir'](root/'run-0')
            fingerprint_matches=svc._dir_fingerprints[root/'run-0']==actual_fp
            COUNTS.clear();svc.refresh(force=True)
            after_force=svc._cache['run-0'].summary.tenant_id;reads=COUNTS.get('trace_records_parsed',0)
            assert after_late=='A' and after_force=='A' and fingerprint_matches and reads==0
            independent=Service(store=None,core_runs_root=root);independent.refresh(force=True)
            assert independent.get_run('run-0').summary.tenant_id=='B'
            # One more genuine trace change re-adapts the old entry.
            write_run(root,'run-0',tenant='B',extra=2);svc.refresh(force=True)
            assert svc.get_run('run-0').summary.tenant_id=='B'
            rows.append(dict(repetition=repetition,late_cache_tenant=after_late,
                fingerprints_match_new_file=fingerprint_matches,tenant_after_forced_refresh=after_force,
                trace_records_parsed_on_forced_refresh=reads,independent_instance_tenant='B',
                subsequent_file_change_recovers=True))
    # Serial control with the same pair of source generations.
    with tempfile.TemporaryDirectory(prefix='policyos-next-serial-') as tmp:
        root=CountPath(tmp);write_run(root,'run-0',tenant='A');svc=Service(store=None,core_runs_root=root)
        svc.refresh(force=True);write_run(root,'run-0',tenant='B',extra=1);svc.refresh(force=True)
        assert svc.get_run('run-0').summary.tenant_id=='B'
    # Same owner, ordinary append-only growth: no tenant mutation is needed.
    ordering=[]
    for repetition in range(5):
        with tempfile.TemporaryDirectory(prefix='policyos-next-order-race-') as tmp:
            root=CountPath(tmp)
            for name in ('run-0','run-1'):write_run(root,name,tenant='A')
            old_ns=1804896001000000000;mid_ns=old_ns+1000000000;new_ns=mid_ns+1000000000
            os.utime(root/'run-0'/'trace.jsonl',ns=(old_ns,old_ns));os.utime(root/'run-1'/'trace.jsonl',ns=(mid_ns,mid_ns))
            svc=Service(store=None,core_runs_root=root);ready=threading.Event();release=threading.Event();original=svc._refresh_index_incremental
            def pause_old():
                result=original()
                if threading.current_thread().name.startswith('late-old'):
                    ready.set();assert release.wait(10)
                return result
            svc._refresh_index_incremental=pause_old
            with ThreadPoolExecutor(max_workers=1,thread_name_prefix='late-old') as pool:
                future=pool.submit(svc.refresh,force=True);assert ready.wait(10)
                with (root/'run-0'/'trace.jsonl').open('a') as f:
                    f.write(json.dumps({'run_id':'run-0','phase':'test','event':'TICK','tenant_id':'A','ts':'2026-11-10T00:00:00Z'})+'\n')
                os.utime(root/'run-0'/'trace.jsonl',ns=(new_ns,new_ns))
                svc.refresh(force=True)
                assert svc._cache['run-0'].sort_mtime_ns==new_ns
                release.set();future.result(timeout=10)
            COUNTS.clear();svc.refresh(force=True)
            parsed=COUNTS.get('trace_records_parsed',0)
            order=[s.run_id for s in svc.list_runs(tenant_id='A')[0]]
            independent=Service(store=None,core_runs_root=root);independent.refresh(force=True)
            correct=[s.run_id for s in independent.list_runs(tenant_id='A')[0]]
            assert order==['run-1','run-0'] and correct==['run-0','run-1'] and parsed==0
            assert svc._cache['run-0'].sort_mtime_ns==old_ns and svc._dir_fingerprints[root/'run-0'].trace_mtime_ns==new_ns
            ordering.append(dict(repetition=repetition,all_tenants='A',trace_change='append-only non-lifecycle event',
                forced_refresh_parsed_records=parsed,persistently_stale_order=order,fresh_instance_order=correct,
                cached_mtime_ns=old_ns,fingerprint_mtime_ns=new_ns))
    return dict(reproductions=rows,same_tenant_append_only_order_reproductions=ordering,serial_control_tenant='B',
        limit='Deterministic scheduling at the return of the unchanged rebuild method. Actual threads and trace/index bodies, but not HTTP or production scheduling. The tenant mutation is a visible snapshot discriminator, not a demonstrated cross-tenant exploit. Cache/fingerprint generations become mismatched and force refresh cannot heal an unchanged trace.')

def pending_batch_series():
    path='scientist/validation/decision_validity.py'
    env={**BASE,**contracts,'json':json,'cast':cast,'_DECISION_VALIDITY_JSON_LOAD_ERRORS':(OSError,ValueError,json.JSONDecodeError),
         '_DECISION_VALIDITY_MODEL_ERRORS':(TypeError,ValueError,ValidationError)}
    helpers=load(path,['_max_status','_dedupe_strings','_is_review_required_status','_recommended_action'],env)
    strict=method(path,'_DecisionValidityStateStore','_load_model_strict',env)
    pending=method(path,'_DecisionValidityStateStore','list_epoch_pending',env)
    overlay=method(path,'DecisionValidityService','_overlay_epoch_pending',helpers)
    Batch=contracts['EpochValidityPendingBatch'];Target=contracts['EpochValidityBatchTarget'];Status=contracts['DecisionValidityStatus'];Eval=contracts['DecisionValidityEvaluation']
    ref=ArtifactRefFixture(artifact_id='sha256:'+'a'*64);rows=[]
    with tempfile.TemporaryDirectory(prefix='policyos-next-pending-') as tmp:
        for n in (50,200,800):
            folder=CountPath(tmp)/str(n);folder.mkdir()
            batch=Batch(batch_id='one-batch',transition_artifact_ref=ref,transition_content_hash='sha256:'+'b'*64,
                requested_query_context_ref='sha256:'+'c'*64,verifier_provenance_ref=ref,
                dependency_denominator_ref='sha256:'+'d'*64,adjudication_denominator_ref='sha256:'+'e'*64,
                targets=tuple(Target(packet_ref=f'packet-{i:05}',decision_lineage_key=f'lineage-{i}',dependency_key='same-dependency',status=Status.STALE,reason='epoch-change') for i in range(n)))
            file=folder/'batch.json';file.write_text(batch.model_dump_json());size=file.stat().st_size
            # Strict real JSON load and real target/batch models; no synthetic parser.
            state=types.SimpleNamespace(_epoch_pending=folder,_load_model_strict=strict)
            state.list_epoch_pending=lambda:pending(state)
            owner=types.SimpleNamespace(_state=state)
            evaluations=[Eval(decision_packet_ref=f'packet-{i:05}',decision_lineage_key=f'lineage-{i}',status=Status.ACTIVE) for i in range(n)]
            records={str(i):types.SimpleNamespace(run_id=str(i),summary=types.SimpleNamespace(run_id=str(i),tenant_id='B' if i==0 else 'A',started_at=None,status='unknown',source_kind='core_run'),sort_mtime_ns=0) for i in range(n)}
            svc=types.SimpleNamespace(_cache=records,refresh=lambda:None)
            def project(rec):
                ev=overlay(owner,evaluations[int(rec.run_id)])
                assert ev.status==Status.STALE
                COUNTS['overlays']+=1;return rec
            svc._with_current_validity=project
            COUNTS.clear();times=measured(lambda:Service.list_runs(svc,tenant_id='B',limit=1),3)
            expected_reads=3*n;assert COUNTS['text_reads']==expected_reads
            assert COUNTS['text_bytes']==expected_reads*size
            full_counts=dict(COUNTS)
            COUNTS.clear();exact=overlay(owner,evaluations[-1]);exact_counts=dict(COUNTS);assert exact.status==Status.STALE
            unrelated=Eval(decision_packet_ref='unrelated',decision_lineage_key='other',status=Status.ACTIVE)
            assert overlay(owner,unrelated) is unrelated
            file.unlink();assert overlay(owner,evaluations[0]) is evaluations[0]
            # Model negative controls: zero targets and invalid applied prefix refuse.
            bad=batch.model_dump(mode='json');bad['targets']=[]
            try:Batch.model_validate(bad);raise AssertionError('empty targets accepted')
            except ValidationError:pass
            bad=batch.model_dump(mode='json');bad['applied_packet_refs']=['unknown']
            try:Batch.model_validate(bad);raise AssertionError('bad applied prefix accepted')
            except ValidationError:pass
            rows.append(dict(cached_runs=n,pending_batches=1,targets_in_single_batch=n,
                pending_json_bytes=size,requested_tenant_runs=1,requested_page_size=1,
                three_list_calls={**times,**full_counts},one_exact_projection=exact_counts,
                target_rows_revalidated_three_lists=3*n*n,
                targeted_overlay_stale=True,unrelated_not_staled=True,removal_clears_overlay=True,
                empty_targets_refused=True,wrong_applied_prefix_refused=True))
    return dict(measurements=rows,limit='Single persisted pending batch is schema-valid; target count has no schema maximum and admission copies the verifier complete denominator. Admission verifier, CAS authenticity and full application were NOT run. ArtifactRef is a fixture; target/batch validators, strict loader and overlay/list bodies are real. Counters measure complete JSON bytes read and schema target rows revalidated, not production disk I/O or latency.')

def import_history():
    path=ROOT/'foundry/methods/selection/history.py';SOURCES['foundry/methods/selection/history.py']=hashlib.sha256(path.read_bytes()).hexdigest()
    spec=importlib.util.spec_from_file_location('audit_history_full_source',path);mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod);return mod

def history_series():
    h=import_history();rows=[]
    with tempfile.TemporaryDirectory(prefix='policyos-next-history-') as tmp:
        for n in (100,1000,5000):
            path=pathlib.Path(tmp)/f'{n}.jsonl';store=h.SelectionHistoryStore(persist_path=path,auto_persist=True)
            t=time.perf_counter()
            for i in range(n):store.record(h.MethodExecutionRecord(method_fqn=f'method-{i%5}',timestamp=i,latency_ms=10+i%30,success=True,data_characteristics={'n_obs':100+i,'n_features':1+i%7}))
            elapsed=(time.perf_counter()-t)*1000;before=hashlib.sha256(path.read_bytes()).hexdigest();replay=h.SelectionHistoryStore(persist_path=path)
            assert len(replay)==0
            times=measured(lambda:replay.import_jsonl(clear_existing=True),3);assert len(replay)==n
            assert path.read_bytes().count(b'\n')==n and before==hashlib.sha256(path.read_bytes()).hexdigest()
            a=h.fit_runtime_predictor_from_history(store);b=h.fit_runtime_predictor_from_history(replay)
            pa=a.predict_ms('method-0',150,3);pb=b.predict_ms('method-0',150,3);assert abs(pa-pb)<1e-10
            replay.import_jsonl();assert len(replay)==2*n
            replay.clear();assert len(replay)==0 and path.read_bytes().count(b'\n')==n
            rows.append(dict(records=n,jsonl_bytes=path.stat().st_size,append_elapsed_ms=elapsed,
                fresh_store_count_before_explicit_import=0,clear_existing_replay=times,
                replay_prediction_matches=True,repeat_append_import_count=2*n,
                memory_clear_preserves_persisted_rows=n))
        # Genuine two-process lifetime of the full unchanged source module, pinned state root.
        state_root=pathlib.Path(tmp)/'global';script='''import importlib.util,sys,json\np=sys.argv[1]\ns=importlib.util.spec_from_file_location("audit_history_child",p)\nm=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m)\nh=m.get_global_selection_history()\nbefore=len(h)\nif sys.argv[2]=="write":\n for i in range(7):h.record(m.MethodExecutionRecord(method_fqn="probe",timestamp=i,latency_ms=10,success=True,data_characteristics={"n_obs":100+i}))\npredictor=m.fit_runtime_predictor_from_history(h)\nprint(json.dumps({"before":before,"after":len(h),"fitted":predictor.is_fitted,"persisted_rows":h.persist_path.read_bytes().count(b"\\n")}))\n'''
        env={**os.environ,'POLISYOS_FOUNDRY_STATE_HOME':str(state_root),'PYTHONDONTWRITEBYTECODE':'1'}
        children=[]
        for mode in ('write','read'):
            p=subprocess.run([sys.executable,'-c',script,str(ROOT/'foundry/methods/selection/history.py'),mode],env=env,text=True,capture_output=True,check=True)
            children.append(json.loads(p.stdout))
        assert children[0]['after']==7 and children[0]['fitted'] and children[1]['after']==0 and children[1]['persisted_rows']==7 and not children[1]['fitted']
    # The actual VOI recording method fits on every accepted observation, not only at read.
    path='scientist/methods/search/voi_scheduler.py'
    raw=(ROOT/path).read_bytes();tree=ast.parse(raw)
    owner=next(n.name for n in tree.body if isinstance(n,ast.ClassDef) and any(isinstance(m,ast.FunctionDef) and m.name=='_record_runtime_history' for m in n.body))
    record=method(path,owner,'_record_runtime_history',dict(MethodExecutionRecord=h.MethodExecutionRecord))
    fits=[]
    class CountingHistory(h.SelectionHistoryStore):
        def __init__(self):super().__init__();self.read_records=0;self.calls=0
        def all_records(self):
            records=super().all_records();self.read_records+=len(records);self.calls+=1;return records
    for n in (50,200,800):
        samples=[];last=None
        for _ in range(3):
            store=CountingHistory();svc=types.SimpleNamespace(_runtime_history=store,_runtime_predictor=h.RuntimePredictor(),_observations=[])
            t=time.perf_counter()
            for i in range(n):
                obs=types.SimpleNamespace(actual_objective_value=.5,features={'stage_level':i%4,'uncertainty_prior':.2},stage_level=i%4,metadata={'timestamp':i},duration_seconds=.01+i%10*.001,timeout_occurred=False)
                record(svc,obs)
            samples.append((time.perf_counter()-t)*1000)
            assert store.read_records==n*(n+1)//2 and store.calls==n
            before=len(store);obs.actual_objective_value=None;record(svc,obs);assert len(store)==before and store.calls==n
            last=store
        fits.append(dict(observations=n,full_history_fits=last.calls,records_visited_by_fits=last.read_records,
                         samples_ms=samples,median_ms=statistics.median(samples),missing_objective_not_recorded=True))
    return dict(persistence_series=rows,two_process_global_history=children,voi_refit_series=fits,
        limit='Full unchanged history.py import under an isolated name and real JSONL I/O. Source-extracted VOI method with synthetic observations. Python 3.12/Pydantic outside repository bounds; no method execution, native Scientist scheduler or scientific workload. Lack of implicit replay is an observed default behavior, not established data loss: JSONL stays intact and explicit import works.')

def main():
    result=dict(commit='f1541ed155f278689be48a8c7ac56c3e200210f7',python=sys.version,platform=platform.platform(),numpy=np.__version__,pydantic=pydantic.__version__,
        source_root=str(ROOT),command=sys.argv,scope='Read-only source. Temporary synthetic disk data, no real jobs or provider calls. Results are bounded probes, not supported native or installed qualification.')
    for name,fn in [('catalogue',catalogue_series),('concurrent_publication',concurrent_publication),('single_pending_batch',pending_batch_series),('history',history_series)]:
        result[name]=fn();result['source_sha256']=SOURCES;result['extracted_definitions']=EXTRACTS;result['parse_fallbacks']=FALLBACKS
        A.output.write_text(json.dumps(result,indent=2)+'\n');print('completed',name,flush=True)
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
