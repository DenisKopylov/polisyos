# PolicyOS: научная целостность continuous calibration и coverage delivery

**Статус: PARTIAL.** Read-only source `f1541ed155f278689be48a8c7ac56c3e200210f7`. Новый срез W01/S07: top-level `calibration`, его реальный persisted replay, Foundry interval summary и forecasting uncertainty consumer. Не повторяет LIB-01/W1, LIB-02/bootstrap RNG, MA/ME DiD или RC-01 independence. Исходники продукта не изменены.

## Результат

1. **SI-01, P2 numerical correctness:** ENCE становится нулём при нулевом predictive spread и ненулевой ошибке. Та же метрика меняется с 1 на 0 от общего масштабирования outcomes/samples на 10⁻¹³, хотя она безразмерна. Ошибочное значение проходит actual producer, selected-profile CAS и полный numerical replay. Это дефект диагностического числа, не доказанный governance bypass.
2. **SI-02, P2 numerical/consumer correctness:** значение, названное `conditional_coverage_pvalue`, является p-value только unconditional coverage. Конструктивный пример с 500 rows и 35 misses даёт настоящий joint conditional-coverage p=.0447747, но продукт передаёт p=.0523335. Вместе с independence p=.117739 это оставляет actual forecast horizon GREEN/gate_eligible=true. Подстановка правильного joint p в тот же unchanged bundle builder делает RED/gate_eligible=false. Полный fitted GARCH и production admission не исполнялись.
3. **Сильный положительный результат:** continuous coverage/bootstrap arithmetic совпадает с независимыми indicator/count oracles, сохранение удерживает ordered pairs и selected profiles, девять valid-hash perturbations отвергаются. Хороший численный результат остаётся `unverified` и `blocked` из-за отсутствия measurement-source assurance. Этот firewall не обнуляется двумя численными дефектами.

## 1. Проверенная цепочка и границы

Выполнены полные исходные модули, не извлечённые численные functions: public `evaluate_continuous` → `persist_continuous_evaluation` → FileSystemCAS → `load_continuous_evaluation` → `CalibrationDiagnosticsReport.to_truthfulness_receipt` / `to_validation_report`. Отдельно выполнен полный `_summarize_interval_diagnostics` с настоящим store и `_build_nonstationary_uncertainty_bundle`; typed bundle записан через штатный `persist_forecasting_uncertainty_bundle`.

Это Python 3.12 с существующим audit loader, in-memory адаптацией Python 3.14 multi-except/TypeVar и namespace facades. Ни одна исследуемая формула, branch predicate, writer или reader не заменялась. Это не native Python 3.14, не установленный wheel и не штатный pytest/conftest. NumPy 2.3.5, SciPy 1.17.0, Pydantic 2.13.4; arch/statsmodels/pytest отсутствуют. Зависимости не устанавливались.

Фактически сгенерированные числа и интервалы являются synthetic audit inputs. Их воспроизводимость не устанавливает causal identification, real source licensing/currentness, temporal stationarity, calibration population completeness, scientific external validity или institution authority. Snapshot store не является production deployment.

## 2. SI-01: ENCE теряет ошибку в вырожденных и маломасштабных bins

`calibration/diagnostics/continuous.py:385–410` вычисляет predictive std и residual, делит rows на десять bins, затем **пропускает** bin при `mean_std <= 1e-12`. Если все bins пропущены, возвращается `0.0`. Обёртка `evaluate_continuous:142–161` сохраняет число как `metrics.ence`, не добавляя degenerate-spread warning.

Во всех различающих fixtures 100 одинаково устроенных rows, 20 draws на row, draws `[−σ,+σ]×10`, prediction mean=0 и outcome=r. Нет неоднозначности weighted quantiles, grouping или bin means: каждый bin имеет SD=σ и RMSE=|r|.

- σ=1, r=1: ENCE=0, положительный контроль.
- σ=1, r=2: ENCE=1, правильный failure control.
- σ=10⁻¹⁰, r=1: ENCE≈9,999,999,999, сигнал сохраняется выше epsilon.
- σ=10⁻¹³, r=1: ENCE=0 вместо огромной нормированной ошибки.
- σ=0, r=1 и r=10⁶: ENCE=0. Отказ/undefined/явная degenerate limitation были бы честными вариантами, ноль скрывает различие.
- Масштабирование σ=1,r=2 на 10⁻¹³ сохраняет теоретическую нормированную ошибку 1, но product ENCE становится 0.
- σ=0,r=0 также даёт 0. Этот частный точно угаданный degenerate case не оправдывает ноль при ненулевой ошибке.

Для positive spread независимый oracle — |σ−|r||/σ. Для нулевого знаменателя oracle намеренно не выдаёт конечное число; тест не требует записывать infinity в JSON. Размерностный invariant не зависит от выбора конкретной конвенции при нуле.

**Последствие и ограничения.** Неверная ENCE воспроизводится после настоящей persistence, поэтому hash/recompute подтверждает именно неверный алгоритм. Interval coverage при confident-wrong samples остаётся плохой, PIT также не теряется; truthfulness receipt остаётся unverified, validation adapter blocked. Не доказано, что ENCE является standalone production gate или единственным доступным diagnostic. Selected retained test `test_evaluate_continuous_with_predictive_samples_emits_pit_and_ence` проверяет наличие ENCE, а не независимое значение или zero-spread/scale invariant.

**Направление ремонта:** у existing continuous owner различить exact degenerate prediction и wrong/undefined normalized error; вернуть typed unavailable/degenerate status либо оговорённую масштабно-инвариантную политику. Не превращать маленькую дисперсию в отсутствие ошибки. Сохранять число skipped bins/rows, denominator policy, versioned replay и исходные input bindings. Library swap не решает смысл нулевого знаменателя.

## 3. SI-02: unconditional p-value доставляется как conditional coverage

`foundry/methods/catalog/econometrics/advanced.py:368–412` вычисляет LRuc для общей доли misses и сразу сохраняет χ²₁ tail в переменную `conditional`. Далее правильно вычисляет отдельный LRind по transition counts, но не складывает два statistics. Стандартный Christoffersen conditional-coverage statistic равен LRcc=LRuc+LRind и сравнивается с χ²₂. Для df=2 tail также независимо равен exp(−LRcc/2).

Это не лишь имя private helper. `_summarize_interval_diagnostics:543–606` возвращает поле `conditional_pvalue`; `_build_nonstationary_uncertainty_bundle:820–926` переносит его в `conditional_coverage_pvalue_by_horizon` и вызывает `_volatility_diagnostic_state:800–817`. State становится RED при любом переданном p<.05. Typed `VolatilityCoverageSummary` также называет поле conditional coverage. Полный GARCH source trace дополнительно показывает те же поля в method output, но actual model fitting здесь не выполнен.

### Конструктивный отличающийся outcome

Последовательность: 30 runs, перед каждым 15 covered rows; первые пять runs имеют по два misses, остальные 25 по одному; затем ещё 15 covered rows. Всего n=500, misses=35, transitions n00/n01/n10/n11=434/30/30/5. Outcomes i, covered intervals `[i−.25,i+.25]`, missed intervals `[i+1,i+2]`. Это конструктивный counterexample, не estimate научной частоты ошибок и не эмпирический significance claim о реальной популяции.

- LRuc=3.765076007509947 → p_uc=.05233347958680612.
- LRind=2.4471465425189933 → p_ind=.11773872539416111.
- LRcc=6.21222255002894 → p_cc=.04477473385912638.
- Actual source summary → bundle: GREEN, parametric allowed, gate_eligible=true, truthfulness tier asymptotic.
- Audit-only oracle substitution of p_cc at the same bundle boundary: RED, conformal fallback, gate_eligible=false, unverified. Product code не изменялся.

Независимый oracle считает integer transitions и Bernoulli log-likelihoods с точной 0·log(0)=0 конвенцией, затем SciPy chi-square tails. Separate matched-count controls (25 clustered misses и 25 evenly spaced misses) показывают: p_uc=1 одинаков, но independence/conditional evidence существенно меняется. Undercoverage control даёт RED. Это не тест, который только переименовал константу в oracle.

**Граница authority:** GREEN и native gate eligibility принадлежат forecast contract. `NativeValueEstimandBinding` явно caller-constructible, `authority_scope=contract_only_nonproduction`, `production_value_eligible=false`. Поэтому результат не объявляется выдачей production policy, causal approval или обходом protected action. Сам continuous calibration report в этой цепи по-прежнему blocked/unverified. Отдельные guards не исправляют неверное conditional число и локальную horizon decision.

**Направление ремонта:** existing owner должен возвращать отдельно unconditional/independence/conditional statistics и p-values с именованными null/df/assumptions. Использовать LRcc и df2 в conditional field; сохранить оба диагностических компонента. Затем проверить typed bundle, horizon fallback, native projection и consumer admission на том же fixture. Пересчитать versioned historical diagnostics или явно различать legacy semantics. scipy.stats.chi2 может заменить CDF kernel, но не выберет правильный test statistic/estimand за owner.

## 4. Что положительно установлено

- 60 finite randomized fixtures независимо проверены integer indicator sums, без вызова product curve как expected value.
- Perfect nominal coverages .50/.80/.95 при n=100 дают ECE=0. Seeded bootstrap (199 repetitions, seed17, confidence .90) сравнивается с независимым resampling binary hit matrix; coverage и ECE/MCE/RMSCE intervals совпали до 1e−14. Это проверка реализации declared resampling plan, не доказательство IID/exchangeability реальных данных.
- Actual persisted zero-coverage, incomplete-level и empty-level cases сохраняют разные statuses и реальные denominators. Empty не становится zero-error positive.
- Missing seed, nonfinite outcomes, reversed bounds, misaligned pairs и replay pair-budget overflow отвергаются до успешного сохранения.
- Девять новых valid-hash audit artifacts отвергаются reader: coverage, ECE, ENCE, n_obs, gate authority, changed outcome, reversed pair order, sibling selected profile with mismatched edge и independently expected selected profile. Исходные CAS objects не переписывались.
- Sibling profile с согласованными payload/edge без внешнего expected ref принимается. Это правильная граница: recomputation доказывает выбранные inputs, не внешний выбор provenance. С expected ref он отвергается.

Новый отдельный процесс с fresh FileSystemCAS прочитал **12 continuous reports и 4 forecasting bundles** с полным совпадением JSON-normalized DTO; все девять мутаций снова отвергнуты. Native value projection сохраняет локальную eligibility, одновременно явно оставляя `production_value_eligible=false`; mismatched population не проектируется.

Шесть неизменённых authored test bodies выполнены напрямую в семи invocations: PIT/ENCE presence, small-sample downgrade, seeded bootstrap/persistence, caller-mutation isolation, Foundry persisted summary при 95 и 0 hits и candidate summary без store. Все семь pass. Применены настоящие исходные helper и CAS, но decorators, pytest collection/conftest/fixture machinery не исполнялись. Это **не семь native pytest passes**. Именованный selected test denominator сохранён отдельно; coverage-контроли здесь содержательны, тогда как ENCE-presence assertion не различает правильную и нулевую метрику.

Первый запуск audit script остановился на NameError: wildcard import не переносит underscore helper. Исправлен только explicit audit import; исходный stderr сохранён. Во время fresh reader наблюдалась задержка среды, но процесс завершился без повторного запуска и без изменения source. Это не product failure.

Простой repeatability test не способен обнаружить SI-01 или SI-02: deterministic wrong formula повторяется безошибочно. Нужны независимая научная формула и различающий consumer outcome, а не ещё одна wrapper-проверка hash или same JSON.

## 5. Остаток и acceptance

1. Native Python 3.14/frozen supported profile, normal imports и selected pytest with real conftest; installed package route отдельно. Compatibility pass не превращать в native qualification.
2. Actual source-owned model estimation (`arch`, regime/holdout choices) → complete method output → persisted uncertainty/source admission → governing consumer. Здесь были настоящие interval producer/summary/bundle functions на synthetic measured pairs, не fitted model.
3. Independent calibration population/currentness/issuer relation; complete governance judges/protected publication. Их отсутствие является честной границей, не автоматически новым defect count.
4. ENCE нулевая дисперсия, малый масштаб, общий перевод units, mixed skipped/unskipped bins и persisted replay across algorithm versions.
5. LRuc/LRind/LRcc oracles, matched count/order, individual-pass/joint-fail, degenerate transition support и statistical assumptions; separate conditional/unconditional API labels и horizon decisions.

`results.json`, `retained.json`, `reader_results.json`, `source_excerpts.json`, `caller_census.json`, `test_census.json`, `FINDINGS.json`, `FLOW_MATRIX.json`, `VALIDATION.json` и `SHA256SUMS.txt` образуют evidence пакет. Текущий отчёт должен читаться вместе с результатом final validation; source inventory и test counts не равны semantic qualification.
