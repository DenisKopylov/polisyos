# PolicyOS: source adapters, schema admission и free-grow

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Source read-only. Продолжение `next_persisted_growth`, `next_registry_dataflow`, `next_directory_architecture`. Это аудит **входа внешнего источника**, не повтор их результатов о capability selection, scientific grounding или публикации.

**Итог: PARTIAL.** Два разных действующих production adapter bodies, `FileTabularConnector` и `GeoJSONConnector`, выполнены на локальных synthetic CSV/GeoJSON. Выполнены настоящие schema inference, content hashes, typed results, schema registry, contract validation и filesystem schema persistence с fresh-process чтением. Native package, полный ingestion/CAS и DataForge DuckDB admission не выполнены.

## Главные результаты

1. **SA-01, подтверждённый дефект persistence, P2 / высокая уверенность.** `FileBackedSchemaRegistry._schema_dir()` заменяет точки подчёркиваниями. Два допустимых ID `audit.a_b` и `audit_a.b` попадают в `audit_a_b/1.0.0.json`. В памяти живут оба schema; на диске один перезаписывает другой; отдельный Python process находит только `audit_a.b`. Уточнение reach: полный прямой lexical поиск по `src/**/*.py` и `tests/**/*.py` не нашёл product construction этого класса, только definition и тесты. Это доказанный дефект доступного persistence owner, **не доказанная потеря production registry**.
2. **SA-02, подтверждённая граница admission, не новый publication bypass.** Новый источник и новые столбцы проходят существующий generic adapter без новой ветки в коде. Но schema inference каждый раз создаёт `1.0.0`, а shape change не вызывает schema registration/evolution. Даже `ContractValidatingProxy(mode="strict")` возвращает результат, если подходящий contract отсутствует. С matching contract удаление столбца корректно отвергается. В registry runtime default mode `warn`, а wrapper не устанавливается для connector без contracts. Следовательно «connector зарегистрирован» и «schema валидирована» не эквивалентны.
3. **SA-03, подтверждённая граница GeoJSON parser / medium impact.** Adapter принимает объект с `type=NotACollection`, feature `type=NotAFeature` и Point coordinates `["bad"]`, возвращает SILVER, completeness=1 и spatial_metadata_present. `properties.feature_id` также затирает собственный Feature.id в выходной строке. Геометрия сериализована, но не проверена. Это не доказательство, что такой input проходит последующее authority admission.
4. **Повторное использование уже существенно.** Обе семьи делят typed base/result, bounded local read, hash/version, schema inference и общий registry/middleware/ingestion. `ObjectStorageConnector` дополнительно наследует FileTabular целиком, расширяя metadata/schemes. Новый universal adapter superclass вместо этого не нужен. Небольшой повтор остаётся в schema projection и result/lineage assembly; главное недостающее соединение находится **между inference и governed contract**, а не в числе похожих методов.

## 1. Что именно исполнено

Harness `probe_adapters.py` загружает неизменённые top-level source definitions в audit namespaces, удаляя только product/relative imports и связывая их с реальными source owners. Для файловых connector используется полный исходный class body. File и GeoJSON имеют **раздельные namespaces**, поэтому одноимённые typed-state keys не склеены. IR `UnitRef` загружен как точный class block без соседнего несовместимого `TypeVar(default=...)`. Native core canonicalization, logging, errors и GenericRegistry импортированы непосредственно из source.

Нет mock filesystem, pandas parser, DataSchema, FetchResult, DataVersion, ContractRegistry, validator или atomic writer. DataForge registry/evolution исполнены в отдельном namespace с собственным SchemaVersion; одноимённые Fabric и DataForge классы не смешаны. Неиспользуемые product services не замещались фиктивными положительными verifier результатами.

Среда: Python 3.12.14, pandas 2.2.3, Pydantic 2.13.4. Native import отказал в `ir/kernel/units.py:24` с `TypeError: 'default' is an invalid keyword argument for typevar()`. Pytest, DuckDB и PyArrow не установлены; ничего не устанавливалось. Native suite не объявляется красной из-за продукта: здесь несовместимая среда.

Executed outcomes:

- CSV `reach_id,value` → две строки 2,6; typed result; schema fields; raw bytes SHA-256 совпадает с независимым hashlib.
- GeoJSON FeatureCollection → одна строка; сохранены CRS EPSG:3857, geometry и content hash.
- Новый source `novel.csv`, dataset `new_ecology`, field `phytoplankton_density` → fetch/schema без изменения source code.
- CSV меняется на `reach_id,temperature`: hash/schema shape меняются, schema ID и version `1.0.0` остаются прежними.
- Явная регистрация изменённого shape под старой версией в Fabric registry отказывает. Новая версия 2.0.0 записывается и читается в другом процессе вместе с 1.0.0.
- Strict middleware без contract пропускает; с contract на старое поле `value` даёт настоящий `SchemaError`.
- Breaking contract 2.0.0 без `allow_breaking` отвергается; с `allow_breaking=True`, но без approvals, тоже отвергается (`ContractGovernanceError`). Этот положительный guard нельзя стирать тезисом «эволюции нет».
- Локальный `../` path отвергается при fetch; MaxBytes=1 отвергает CSV. Validation config alone не делает фактического чтения.
- DataForge schema register принимает 1.1.0 с изменением number→string, но его **отдельный** evolution evaluator помечает incompatible, а assertion отказывает. `compat_mode=FULL` в registry не является автоматическим вызовом evaluator.
- DataForge `CatalogSourceRegistryEntry` и `to_module_spec()` принимают новый source/connector. Unknown family также может быть объявлена как строка. Enrichment+publish_blocking правильно отвергается. Это проверка declaration, не выполненный harvest/admission.

## 2. Цепочка нового источника и её владельцы

Все пути далее относительно `policy-engine/src/polisyos/`. Точные строки и SHA-256 находятся в `source_excerpts.json` и `SOURCE_VALIDATION.json`.

| Этап | Реальный owner / связь | Что доказано |
|---|---|---|
| Transport registration | `fabric/connectors/components.py:85–150`; `_registry_lifecycle.py:456–534,781–905` | Builtin classes → component index/bridge → registry. Registration проверяет protocol, owner ID, config; identity включает connector metadata version. SOURCE_TRACED, не выполнен полный bootstrap. |
| Source endpoint / profile | `_registry_lifecycle.py:536–565`; `profiles/*`; `ConnectionConfig` | Source profile family → default connection config. Новый endpoint existing family не требует нового parser; новый protocol требует implementation и регистрации. В probe explicit ConnectionConfig, без profile default на example.com. |
| Fetch / raw identity | `sources/_file_common.py:129–184,242–273`; adapters | Реальное локальное чтение, byte limit, pandas/JSON parse, content hash и timestamp strategy. Raw source version не равна schema version. EXECUTED. |
| Schema discovery | `_inference_engine.py:164–220`; adapters | Inferred fields + fixed version 1.0.0. Не автоматически persisted/governed. EXECUTED. |
| Schema/contract admission | `contracts/registry.py:153–207`; `contract_registry.py:127–182`; `validation_middleware.py:176–210` | Schema same-version hash conflict, contract evolution/approval checks, fetch validation. Нужны explicit registration/contract. EXECUTED, плюс runtime wrapper SOURCE_TRACED. |
| Row canonicalization | `fabric/ingestion/ingestion.py:1290–1395` | Fetch → source_result sink → transform pipeline → PII stage → sanitation/quarantine. Это другой owner, не часть adapter.fetch. SOURCE_TRACED. |
| Payload persistence | `ingestion.py:1410–1530`; cache serializer `55–122` | Result → cache/CAS artifact ref; DataFrame path использует Parquet. Payload не записан этим route: нет PyArrow/полного runtime. SOURCE_TRACED / UNRUN. |
| Provenance и bundle | `ingestion.py:1546–1637` | Activities с connector/dataset/schema/raw-version/hash → provenance graph → evidence bundle → persisted_result_sink только после persistence. Поля lineage на DataFrame сами по себе не этот persisted proof. SOURCE_TRACED. |
| Orchestration bridge | `fabric/data_plane/orchestrator.py:580–650`, `modes.py:870–975` | Реальный bridge вызывает ingestion, передаёт persisted_result_sink. Нельзя назвать весь путь disconnected. SOURCE_TRACED / UNRUN. |
| DataForge catalog declaration | `data_forge/domains/catalog/registry.py:28–140`, `source_modules.py:49–174` | Source registry row → module → raw/normalized/observations/readiness asset contracts. Entry/module EXECUTED; asset pipeline execution не выполнен. |
| DataForge harvest/normalize | `catalog/batch/harvester.py:1241–1349`, `normalizer.py:1250–1345` | Существуют provider/family dispatch branches. Unknown family harvest даёт warning и rows=[], normalizer fallback CKAN. «Family string accepted» не означает реализованный transport/normalizer. SOURCE_TRACED. |
| DataForge canonical observation / admission | `catalog/knowledge/overlay.py:2048–2106,4213–4365` | Registration/field binding/passport → derive canonical observations → transactional overlay. Эти bytes/meaning joins существенно сильнее generic schema inference. Covered separately by next_registry_dataflow; здесь не переисполнялись и не объявлены прошедшими. |
| Schema persistence | `contracts/registry.py:334–445`; `fabric/io/atomic.py` | Настоящий atomic JSON write, реальный fresh-process reload; здесь SA-01. Это schema metadata store, не CAS result store и не DatasetCatalog DuckDB. EXECUTED. |

## 3. Что значит free-grow в этом участке

**Работает как data-driven reuse:** новый локальный CSV с новым dataset ID/column names проходит существующий files adapter, получает raw content identity и inferred schema. DataForge declaration также допускает новый source с existing connector. Не требуется редактировать enum предметных сфер.

**Не замыкается автоматически:** transport component registration → per-dataset schema contract → governed semantic field binding → catalog ingestion/overlay. Новая строка registry не производит эти свидетельства. Builtin schema contracts в `sources/_contracts/__init__.py:18–24` собраны для WorldBank/WVS/Eurostat/UKONS/SDMX; files и geojson там нет. Это не запрет на user-provided contracts: probe добавил такой contract и показал его enforcement.

**Новый protocol/family:** Fabric позволяет зарегистрировать новый connector implementation через component extension; DataForge batch при этом содержит свой family/provider dispatch. Добавление `family=files` в DataForge entry не добавляет соответствующую ветку harvester. Следует сохранять различие generic retrieval, catalog harvesting и empirical observation conversion, а не притворяться одной универсальной регистрацией.

**Семантические assumptions:** inference распознало synthetic `temperature` 12/14 как `percentage` по эвристике числового диапазона. Это не scientific measurement binding. Предыдущие findings `next_registry_dataflow` сохраняют силу; текущий успех fetch не отменяет их и не доказывает новую научную сферу end-to-end.

## 4. Два adapters: общее и различия

| Обязанность | FileTabular | GeoJSON | Оценка reuse |
|---|---|---|---|
| Configuration/handle/result contracts | BaseConnector, ConnectionConfig/Handle, FetchResult | Те же owners | Реальное общее ядро, сохранять |
| Read bounds/path/hash/version | `_file_common` | `_file_common` | Нет нужды повторять transport или hash |
| Parsing | CSV/JSONL/Parquet/Excel через pandas | Feature properties + geometry JSON + CRS | Содержательное различие protocol, не duplication smell |
| Inference | `schema_dict_from_dataframe` → `infer_schema` | `infer_schema` + свой dict fields | Небольшой повтор schema projection; хороший кандидат на shared projection с extras |
| Lineage | source_location, format, raw content hash | source_location/hash плюс spatial metadata | Нужен один envelope owner и typed family extras; не стирать CRS/geometry |
| Stateful metadata | schema + version cache per dataset | schema cache per dataset | Разные нужды: у File есть freshness check, у GeoJSON такой capability нет |
| Page behavior | head(page_size), has_more=True, no token | page_size не применяет | Не выдавать общую гарантию resumable/pagination. File completeness остаётся 1.0 при 1/2 rows; это диагностическая metadata граница, не доказанное authority принятие |
| Semantic validation | Типы inference, не contract auto-admission | То же + нет GeoJSON structural/geometric checks | Общее место для opt-in strict contract, отдельные protocol tests |
| Post-fetch transform/CAS/evidence | Общая ingestion pipeline | Та же pipeline | Не копировать downstream machinery в каждый adapter |

Дополнительный control чтением: `ObjectStorageConnector(FileTabularConnector)` уже сохраняет весь fetch workflow и расширяет provider/bucket/object metadata. Это хорошее inheritance reuse, не надо заменять его ещё одним engine/registry.

## 5. Distinguishing tests и пробелы

Существующие tests прочитаны, **не выполнены**; список функций и SHA в `existing_test_inventory.json`.

- `sources/test_connector_family_expansion.py` проверяет family/profile/registry согласованность, CSV row count/schema id/format и GeoJSON CRS/lineage. Эти tests доказывают основные примеры, но не invalid GeoJSON shape, property identity collision, changed shape across fetch или fresh-process multiple-ID persistence.
- `test_schema_system.py:1246–1300`: persistence одной schema в новом instance, unregister и cleanup orphan tmp. Нет различающих двух валидных ID с совпадающей filesystem projection. Новый harness делает именно этот control и отдельный subprocess.
- `test_contract_system.py:196–395`: exact-over-wildcard resolution, version bumps, breaking approval, strict/warn, version drift, future timestamps, cache bound. Существующее enforcement содержательно. Новый probe отличается новым generic source без matching contract, затем добавляет contract и получает отказ.
- `contracts/test_validation_middleware.py`: revision invalidates cached contract/modes; это отдельное важное свойство, не повтор нашей проверки.
- `data_forge/test_phase7_schema_quality_observability.py:136+`: explicit evolution rules for breaking changes. Новый probe показывает разницу register и explicit evolution, а не утверждает, будто evaluator отсутствует.

Самые полезные следующие regression tests: (1) два collision IDs + fresh process, (2) missing contract policy в strict authority acquisition, (3) GeoJSON wrong root/feature/coordinates + reserved-column conflict, (4) drift version/schema hash across adapter fetch и cache boundary, (5) полный supported-environment ingestion → persisted_result_sink → overlay consumption со schema contract, включая tamper/removal controls. Они здесь не добавлены в source.

## 6. Исправление направления, без изменений кода

- SA-01: injective filesystem encoding schema_id (или digest-based directory плюс explicit identity), detection conflict до overwrite и before/after restart tests. Для migration учесть существующие underscore paths; нельзя просто переименовать без read compatibility.
- SA-02: сделать политику отсутствующего contract явной на boundary: candidate/inference может продолжать с объявленным not-established; protected acquisition должен требовать matching content-bound contract. Подключать existing registry/evolution owners, не создавать четвёртый schema registry.
- SA-03: explicit GeoJSON validation, ошибки координат/geometry types и policy конфликтов reserved fields до SILVER/provenance emission. Spatial extras сохранить.
- Сначала wire-existing: единый schema projection helper и переход от raw adapter result к typed contract validation receipt. Domain-specific measurement binding и quarantine оставить у текущих владельцев.

## 7. Доказательность и границы

76 source/test/native-loaded files сверены побайтово с Git HEAD; все совпали. `git status --porcelain -uno` пуст. Новых dependencies, writes в source, внешних calls, cloud storage, providers, баз пользователя, solver/training/jobs не было.

`probe.exitcode.txt=0`, `fresh_reader.exitcode.txt=0`, `evidence.exitcode.txt=0`. В archive сохранены initial harness errors: missing selected ArtifactID constant, serializing AST alias name; один промежуточный result содержал wrong SchemaError class из общей audit namespace. Это ошибка измерителя, исправлена точной привязкой connector SchemaError, а не production defect. Final known-contract control даёт настоящий SchemaError.

Сводные ограничения в `LIMITS.json`. Результат нельзя пересказать как «все connectors проверены», «production source admission завершён», «new scientific domain accepted», «CAS replay доказан» или «authority/publication bypass найден».
