# PolicyOS: SQL control-plane growth после checkpoint09

Pinned source: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Read-only source. Локальная среда: Python 3.12.14, SQLite 3.53.1. Все изменения находятся в audit namespace; данные SQLite синтетические и временные.

## Главный результат

1. **SG-01, подтверждённый механизм:** чтение creation/history одного job сканирует общий `control_job_events`; lookup одного run сканирует `control_jobs` либо все completed jobs. Индексы job_id/event_type у event log и run_id у jobs отсутствуют. Реальный SQL на 300 000 events: один creation result, **900 031 VM instructions**; test-only индекс `(job_id,event_id)` даёт **64** при том же результате. На 100 000 jobs latest-by-run: **300 072 → 78** instructions после test-only `(run_id)`.
2. **SG-02, квалифицированный capacity risk:** bounded outbox page и frozen watermark не гарантируют bounded SQL work. План зависит от распределения topics/states и статистики. После `ANALYZE` page1 при всех 100k нужных rows становится дешёвой, но редкий topic в хвосте требует около **800k** instructions. Индекс topic/state сам по себе не даёт надёжного исправления paging.
3. **SG-03, подтверждённый startup mechanism:** каждый constructor вновь запускает полный scope census intents и Search outbox backfill, включая уже мигрированную БД. На 100k intents census = **1 900 017** instructions. Это стоимость **инициализации store**, не каждого запроса.
4. **SG-04, bounded SQLite finding:** lease candidate `LIMIT 1` использует `MULTI-INDEX OR` и temporary ordering. На 100k pending jobs = **1 200 021** instructions; 100k running с ещё действующими leases и нулевым результатом = **700 017**. Denominator здесь active backlog, не все исторические jobs.
5. **Положительный контроль:** exact operation-intent lookup использует весь составной PK, включая tenant/cell/actor/purpose/scope. Для 1k/10k/100k intents из 100 tenants: **40** instructions и одна запись; другой tenant: **22** и пусто. Это не «весь SQL линейный».

Severity SG-01/02/04: medium engineering capacity risk. SG-03: low-to-medium startup capacity risk. Высокая уверенность в измеренных локальных механизмах; production latency/SLA breach, starvation, потеря данных, cross-tenant disclosure и PostgreSQL performance не установлены. Это отдельный SQL owner, не повтор `next_scaling`, `next_storage_scale` или `next_catalog_scale`.

## 1. Что действительно исполнялось

`probe_sql_growth.py` берёт исходный AST и исполняет **неизменённые выбранные методы** `ControlPlaneStore`: constructor, весь SQLite schema/migration owner и connection manager, exact operation SQL builders, dynamic outbox-list query builder, creation-event reader. Product imports и остальной service graph не подменяются обещанием native execution: они **не выполнялись**.

В остальных trials SQL literals извлечены непосредственно из конкретных методов и выполняются настоящим `sqlite3` против полной реальной SQLite schema. Synthetic rows вставлены напрямую, минуя production producers, DTO/admission, CAS и HTTP. Это schema/query benchmark, **не успешные admitted jobs или deliveries**. Outbox mixed fixtures используют только два topic, допущенных реальным delivery-order owner: `control.search.hte_completed` и `control.decision_validity.hte_source_update`. Распределение их объёмов и соотношение с production workload не установлены.

Для каждого запроса сохранены params в воспроизводимом script, `EXPLAIN QUERY PLAN`, число returned rows, SHA-256 полного результата, пять warm timing samples и **точный счёт SQLite VM instructions** через progress handler interval=1. Счётчик исполняется отдельно от timing. VM instructions не равны rows visited, physical disk I/O или server CPU cycles. Повторное чтение прогрето OS/SQLite caches. Milliseconds служат иллюстрацией на этом host, а не обещанием ёмкости. Temporary databases удалены их владельцем; production DB не открывалась.

## 2. SG-01: mandatory proof lookup оплачивает общий event log

### История job

`control_plane_store.py:9103–9109,9547–9555` создаёт event table только с event_id PK. В SQLite index inventory отсутствует secondary index этой таблицы; PostgreSQL schema owner также его не объявляет.

Запросы `get_job_created_event_payload:5625–5646`, `_get_job_created_source_event_record:5648–5668`, `_latest_control_job_lifecycle_event_record:5670–5699`, terminal reader:5701–5727, `list_job_state_transitions:6213–6235` выбирают по job_id, иногда event_type, с порядком event_id. На каждой fixture queried старый job имеет лишь **10 events**, а общий event log растёт:

| All events | Creation rows | VM instructions | Warm median, ms | После `(job_id,event_id)` |
|---:|---:|---:|---:|---:|
| 1 000 | 1 | 3 031 | 0,037 | 64 |
| 10 000 | 1 | 30 031 | 0,355 | 64 |
| 100 000 | 1 | 300 031 | 6,227 | 64 |
| 300 000 | 1 | 900 031 | 22,979 | 64 |

EQP меняется с `SCAN control_job_events` на `SEARCH ... (job_id=?)`. Missing creation также проходит весь log. Latest running event старого job = 900 031 instructions; latest event **самого нового** job = 61 даже без индекса. Значит happy-path benchmark только свежего job скрывает age-dependent scan. `LIMIT 1` не является доказательством постоянной стоимости, но и нельзя говорить, что каждый newest lookup всегда читает всё.

Это load-bearing owner, не случайный debug query: `current_execution_job_admission:2174–2196` вызывает creation-envelope reconciliation:2038–2132; historical scope:2134–2172 использует тот же predicate. Running proof:2003–2036 и terminal/publication flows обращаются к event records. Runtime callers перечислены в `SQL_CENSUS.json`; например `job_scope_admission.py:535`, `run_lifecycle.py:12057–12076`, acquisition/owned-attempt readers.

**Нельзя оптимизировать отменой проверки.** Reader намеренно требует ровно один creation event; добавление второй synthetic creation приводит к `control_job_created_event_count_not_one` в настоящем выбранном методе. Не менять запрос на `LIMIT 1` и не объявлять duplicate допустимым. Использованный test-only **неуникальный** index сохраняет все rows, порядок и result hash. Для job с собственной большой историей работа всё ещё растёт с его history length; этот индекс устраняет именно влияние **чужих jobs**, не вводит retention policy.

### Jobs по run

`get_latest_job_by_run:4715–4750` фильтрует run_id и сортирует по finished/null/created. `get_unique_completed_job_by_run_and_kind:4752–4796` выбирает LIMIT 2 для обнаружения ambiguity. SQLite имеет state/created и pipeline indexes, но не run_id:

- 100k jobs, latest(run-0): 300 072 instructions, median 8,63 ms; после test-only `(run_id)` 78, 0,011 ms.
- 100k completed jobs, unique(run-0,kind): 500 072, 14,97 ms; после индекса 80, 0,010 ms.
- Missing run: 300 012 → 15.
- Exact job_id = 44 и pipeline_id = 46 на всех размерах. Это полезные уже существующие indexed paths.

В test-only after-index plan остаётся temporary ordering, но только внутри selected run. Если один run имеет много jobs, понадобится отдельная qualification composite/expression index и exact tie semantics. LIMIT 2 и ambiguous refusal нельзя убирать. Source callers включают `resource_binding.py:2330`, `owned_attempt_anchor.py:2888–2889` и `run_lifecycle.py:12812,12905`.

**Минимальное направление:** расширить indexes существующего store, не создавать независимый authority cache. Сначала реальные distribution/explain fixtures и migration parity; затем production supported-profile benchmark с теми же outputs, duplicate/missing/cancelled/historical controls. Ни один production index здесь не создан.

## 3. SG-02: outbox cursor ограничивает результат и эпоху, но не SQL work

`list_outbox_events:7926–7958` default pending использует `(state,created_at)` и возвращает первую строку за 28 instructions на 100k rows. Exact keyed outbox lookup обслуживает unique `(topic,event_key) WHERE event_key IS NOT NULL`; 26 instructions на 1k/10k/100k rows; этот key нельзя подменять row order.

Отдельный `state=None` mode теряет ведущий state predicate: 100k rows, return1, 600 032 instructions + temp sort. Это optional unfiltered mode, не default pending path.

Реальный maintenance: `run_lifecycle.py:7699–7740` и `13991–14040` использует frozen monotonic watermark и страницы по 25. SQL `list_pending_outbox_topic_delivery_page:5947–5993` соединяет delivery sequence с outbox и фильтрует topic/state; generic и Search-specific variants имеют ту же форму. Page limit ограничивает **output**, watermark прекращает погоню за новыми arrivals, но ни один из них не задаёт индекс, упорядоченный одновременно по topic/state/sequence.

Для 100k rows, requested page1:

| Fixture | Без ANALYZE | После ANALYZE | После topic/state index + ANALYZE |
|---|---:|---:|---:|
| Все pending, Search только последняя row | 500 069 | 800 044 | 800 046 |
| Другой topic published, Search pending в хвосте | 75 | 800 044 | 800 046 |
| Все Search pending | 2 000 054 | 52 | 54 |

Числа = VM instructions, не rows. Без статистики optimizer часто выбирает state index и temp B-tree; со статистикой начинает с sequence range и проверяет outbox по PK. Второй план прекрасен при плотном нужном topic, но проходит длинный нерелевантный prefix при редком topic. Этот **обратный контроль** исключает вывод «всегда full scan» и показывает, почему один blanket index не является готовым patch. No-statistics и analyzed варианты используют один и тот же corpus и семантически одинаковый результат.

Watermark `MAX(sequence_id) JOIN ... WHERE topic`: 100k mixed rows = 300 019 instructions, все Search = 900 013. Test-only `(topic,state,created_at,event_id)` снижает rare-topic watermark до 22, но all-Search watermark остаётся 800 014. Поэтому page optimization не закрывает цену начала retry cycle. Source list ограничивает backlog retry и сохраняет failed rows pending; эта failure/retry semantics не должна исчезнуть ради скорости.

**Направление:** квалифицировать query и indexes вместе для плотного/редкого topic, published prefix, failed rows, high cursor, frozen upper bound и concurrent arrivals. Если требуется indexed topic/state/sequence projection, расширять **тот же** transactional delivery-order owner и проверять atomic visibility, publication state, dedupe и replay. Не вводить второй eventual-consistent authority store. Result hashes before/after равны; production correctness нового дизайна этим не доказана.

## 4. SG-03: повторная migration validation и retained state

Constructor:1914–1945 всегда вызывает schema owner. SQLite:9350–9513 выполняет `BEGIN IMMEDIATE`, Search delivery backfill, legacy scope UPDATE, полный invalid-scope COUNT, PK inspection и conditional migration. Уже мигрированная БД проходит это вновь. PostgreSQL owner:9850–9938 также выполняет scope backfill/census/constraint work; его время и locks не измерены.

- Intents 1k/10k/100k, правильные scope: **19 017 / 190 017 / 1 900 017** instructions на COUNT, result=0 invalid rows. Это full table scan.
- Три повторных вызова настоящего SQLite schema method на 100k intents дают десятки milliseconds каждый; отдельные времена и traces сохранены. Это startup, не steady-state exact intent lookup.
- Повторный startup на 100k уже существующих Search deliveries: около **68,9 ms**; число delivery rows остаётся 100k. `INSERT OR IGNORE` всё же сдвигает SQLite AUTOINCREMENT high-water с 100k до 200k. Это нормальная семантика ignored AUTOINCREMENT insert и **не доказательство duplicate events/overflow**; упомянуто как наблюдаемый non-no-op повторного backfill.
- Corrupt synthetic scope_id, несовместимый с run_id, отвергнут настоящим schema method: `runtime_operation_scope_migration_has_unclassified_rows`. Проверка полезна, и нельзя просто убрать её для зелёного benchmark.

Литеральный census всех **2 902 .py/.sql** файлов под `policy-engine/src` и `policy-engine/ops` не нашёл `DELETE FROM`/`TRUNCATE` для четырёх target tables: jobs, job_events, outbox_events, operation_intents. Это не доказательство отсутствия внешнего DBA retention, dynamic SQL или archive operator. В самом owner expiring cleanup существует для **step-up replays** (`:2440,2447`), но не для названных четырёх таблиц. Table/topic growth здесь нельзя приравнивать к количеству runs: progress events, attempts, retries и consumers меняют множитель.

Retention не сводится к «удалить published outbox». Creation/terminal history и outbox copies служат reconciliation, historical scope и immutable completion proofs, а completed/refused intents сохраняют idempotency outcomes. Нужен явный срок и archive/readback contract у **существующего** owner; удаление может уничтожить proof и разрешить повторную операцию. Рекомендуемый первый шаг: versioned migrations с явно проверяемым durable completion/checkpoint, не повтор каждого исторического backfill при старте; corruption/admission contract должен остаться определённым и проверяемым. Это design direction, не выполненное изменение и не разрешение отключить fail-closed checks.

## 5. SG-04: lease selection имеет active-backlog denominator

`_lease_next_sqlite:8993–9031` выбирает earliest created из pending OR expired running и только затем обновляет job. В реальном schema plan использует state/created дважды, объединяет кандидатов и сортирует. В probe исполняется **только точный SELECT**, не concurrent claim/lease write:

- Pending 1k/10k/100k, return1: 12 021 / 120 021 / 1 200 021 instructions.
- Running unexpired 1k/10k/100k, return0: 7 017 / 70 017 / 700 017.

Completed jobs не входят в два state index scans, поэтому нельзя назвать это ростом со всей retained history. Не измерены lease race, starvation, fairness, worker contention и throughput. Source `_sqlite_mutation_connection` входит в `_job_transaction`, использующий `BEGIN IMMEDIATE`; следовательно время candidate select находится в mutation transaction. Это source-level lock-duration implication, не измеренный outage.

PostgreSQL sibling:9033–9070 использует `FOR UPDATE SKIP LOCKED`, отдельный concurrency contract. Перенос SQLite plan/serialisation на PostgreSQL некорректен. Query rewrite должен сохранять earliest selection, reclaim cutoff, race protection и attempt increment; benchmark только sorted static SELECT этого не гарантирует.

## 6. Tenant-scoped invariants и PostgreSQL границы

`runtime_operation_intents` PK = purpose, tenant_id, cell_id, actor_subject_sha256, scope_kind, scope_id, intent_id. Exact select:8307–8319 использует **все** поля, поэтому tenant predicates здесь selective/index-compatible. 100 synthetic tenants сохраняют 40 instructions lookup при 100k rows. Другой tenant возвращает пусто; это SQL scope control, не проверка всей HTTP authorization системы.

Настоящая SQLite schema отвергла:

- completed intent без result/event;
- pending intent без owner token;
- refused intent без reason;
- duplicate keyed outbox event.

Control jobs/outbox/event-log не имеют tenant column в этом schema owner. Их trusted job scope восстанавливается через creation envelope, а не отдельный tenant SQL prefix. Поэтому denominator этих запросов общий для данного DB; увеличивать количество tenants в одной DB может увеличить конкурирующий объём. **Отсутствие tenant column само по себе не доказывает isolation bypass**; route auth/policy и production topology этим срезом не пересматриваются. `core/security/db_backend.py` RLS adapter и ops world migrations относятся к другим tables/owners; нельзя объявлять их implicit indexes/RLS для control-plane table.

`DDL_COMPARISON.json` выявляет точное source-level расхождение: PostgreSQL schema owner не создаёт SQLite indexes `idx_control_jobs_state_created_at`, `idx_control_jobs_pipeline_id`, `idx_runtime_operation_intents_run_state`. PK/unique constraints остаются; известный внешний deployed schema не inspected. Это дополнительный **qualification gap**, не native PostgreSQL benchmark и не утверждение, что PostgreSQL обязан применять такой же plan. Точного run_id или job-events secondary index в обоих owners не обнаружено.

PostgreSQL `_postgres_cursor:10219–10234` создаёт новое psycopg connection на отдельный внешний context. Внутри активной transaction `_fetchone/_fetchall` переиспользуют cursor lane, поэтому «каждый SQL всегда новый connection» неверно. Pooling/connection latency и remote DB RTT здесь не измерялись.

## 7. Следующий acceptance

1. Supported Python 3.14 native service path: real creation/worker lease/admission/completion/history с N jobs, K events/job, long-lived job и 100+ tenant distributions. Измерять SQL calls/VM-equivalent work, connection overhead, transaction duration и p95 отдельно.
2. Index-only candidate migrations в existing owner для job/event/run reads; одинаковые results и duplicate/ambiguous/missing refusal; старые DB/reopen/concurrent readers и оба backend schemas.
3. PostgreSQL real `EXPLAIN (ANALYZE, BUFFERS)` на disposable DB, статистика, exact schemas, SKIP LOCKED с несколькими workers, migrations и rollbacks. Никаких extrapolated SQLite milliseconds.
4. Outbox dense/sparse topic, pending/published/retry ratios, low/high cursor, empty page и frozen watermark. Изменения не должны пропускать retryable rows или продлевать cycle вслед за arrivals.
5. Versioned migration/retention proposal только вместе с durable proof/idempotency/archive contract. Без этого не удалять history и не отключать invalid-scope census молча.

## 8. Provenance и ограничения

- Native import попытка сделана и сохранена: Python 3.12 не разбирает `core/artifacts/store.py:2155`, где используется supported Python 3.14 syntax. Это environment outcome, не новый product defect. Native pytest, HTTP, full producer/consumer chain, PostgreSQL, network/provider и installed wheel **UNRUN**.
- Публичные product files не менялись; все 14 named readset files совпадают с pinned SHA-256 baseline, HEAD совпадает, Git status пуст. Complete parent census остаётся отдельным доказательством; этот readset не объявлен full-repository semantic audit.
- Основной final corpus: `results.json`, `queries.json`, `probe_sql_growth.py`, stdout/stderr/exitcode. `selected_methods.py.txt` фиксирует именно выполненные unchanged bodies. `SOURCE_VALIDATION.json`, `DDL_COMPARISON.json`, `SQL_CENSUS.json`, `CENSUS_DENOMINATOR.txt`, `SOURCE_EXCERPTS.txt` и `validate_evidence.py` фиксируют источники.
- `preliminary_*` сохранены лишь как ранний harness run: тогда другие delivery-order rows были условными progress topic, не текущими selected-topic fixtures; счётчик был approximate. **Они не являются evidence для final conclusions.** Final run исправляет topic fixture и использует exact VM counts + ANALYZE controls.
- Воспроизведение из audit root: `PYTHONDONTWRITEBYTECODE=1 python next_sql_growth/probe_sql_growth.py`, затем `PYTHONDONTWRITEBYTECODE=1 python next_sql_growth/validate_evidence.py`. Это isolated SQL mechanism probes, не native pytest acceptance.

Итог: найден конкретный путь снижения лишней общей работы **без ослабления authority invariants**, но весь SQL control plane не квалифицирован под production scale и никакой product patch не выполнен.
