# PolicyOS: владельцы состояния и recovery на трёх границах

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Дата: 10 ноября 2026. Read-only аудит. Статус: **частично квалифицировано**. Это три выбранных сквозных потока, не полная перепись всех persistent stores и не production acceptance.

## Главное

1. **STATE-01, новый recovery-разрыв:** при ошибке после durable finalize journal, но до terminal trace, Core recovery публикует `RUN_FINALIZED` без выбранного workflow-finalization input. Manifest сохраняет этот ref в outputs, однако Runtime сознательно не выводит selection из одного лишь наличия output. В трёх fault points восстановленный terminal имеет `workflow_finalization_ref=None`; точный повтор `finalize` отказывает. Если terminal fact уже записан до сбоя, recovery сохраняет правильный ref. Это не обход authority, а потеря восстановимости/доступности доказанного workflow result.
2. **STATE-02, новый dedupe/fanout-разрыв:** generic DecisionValidity записывает durable dedupe до применения события ко всем зависимым packets. Его `owner_transaction` обеспечивает file lock, но не rollback. Ошибка перед первым либо вторым packet переживает reopen; повтор не вызывает применение события, читает cached evaluations, а Runtime успешно записывает notification в SQL. Отдельный SEMANTIC_EPOCH batch path не затронут этим доказательством.
3. **Durable SQL ownership работает в проверенном срезе:** четыре межпроцессные гонки дают одного owner; изменённый body конфликтует; SQL intent, diagnostic и outbox откатываются вместе при несовпавшем callback event ID и смерти процесса внутри transaction. Повтор завершения не вызывает producer, unknown outcome не превращается в автоматический новый owner. Это важное ограничение прежнего SYS-06/LIF-04: generic response cache не является владельцем Predictive Calibration/NL intent.

Ни один синтетический fault injection ниже не объявляется наблюдавшимся production failure. Уверенность высока в исследованных механизмах и source wiring; native Python 3.14, locked imports, реальный CAS и full HTTP/engine qualification остаются открытыми.

## 1. Карта владельцев и источников истины

### Поток A: Scientist workflow → Core finalization → Runtime terminal reader

- **Producer:** `scientist/orchestration/engine/executor.py:2560–2641` сохраняет final state/report и `WorkflowStateFinalization` с selected profile; добавляет refs в outputs; передаёт именно `workflow_finalization_ref` в Core. Соседний async producer: `async_executor.py:1156–1160`.
- **Immutable bytes:** CAS владеет содержимым и selected manifest profile. Наличие blob или output ref не делает его выбранным terminal workflow transition.
- **Core ownership:** `core/run/context.py:3172–3278`. Mutable RunManifest, finalize journal, exclusive run lease и terminal trace имеют разные роли. Journal сохраняет request-to-finish, CAS содержит manifest, `RUN_FINALIZED.refs.inputs` выбирает workflow transition, `refs.outputs` выбирает run manifest. RunManifest.outputs содержит артефакты, но не заменяет terminal selection.
- **Recovery:** `context.py:1420–1499` сверяет journal/run/tenant/cell с trace, учитывает существующий terminal fact, проверяет manifest и завершает pending journal. `load_core_run` в Runtime запускает recovery перед чтением (`adapters/core_run.py:315–324`); audit assembler также является recovery caller (`core/audit/_assembler_core.py:186`).
- **Consumers:** `load_terminal_core_run_source` (`adapters/core_run.py:223–313`) выбирает workflow ref только из единственного terminal input, при правильном kind/media/profile и ровно одном соответствующем manifest output. Строгий workflow reader отказывает при отсутствии selection (`:620–629`). `_terminal_experiment_state_ref_for_control_job` (`control/run_lifecycle.py:14287–14353`) также возвращает отказ/отсутствие, а не угадывает final state.
- **Atomicity:** нет одной SQL transaction над CAS, journal и trace. Надёжность должна обеспечиваться replayable write-ahead journal и неизменяемыми terminal facts. Process/file mutex не заменяет полноту journal.

### Поток B: Predictive Calibration POST → durable SQL intent → CAS association → diagnostic event

- **Entry:** `routes/runs.py:7650–7734`: feature/scope/permission gates, actual run-bound source, authenticated actor; known intent conflicts становятся 409. Generic middleware выделяет этот путь как operation-owned (`mutation_policy.py:105–126`).
- **Unique owner:** `run_operation_idempotency.py:95–164` и `control_plane_store.py:8010–8074`. Primary identity: purpose, tenant, полный cell, authenticated actor digest, typed run/route scope и caller intent. Body digest не входит в unique key: иной body должен конфликтовать, а не создавать ещё одну операцию. Generated candidate run ID в NL route сохраняется как provenance первой записи.
- **Independent CAS phase:** `predictive_calibration.py:564–845` делает preflight, отмечает `owner_started`, исполняет owner, сохраняет report/evidence/association с selected refs. CAS публикация не является частью SQL rollback.
- **Atomic SQL publication:** `complete_runtime_operation_intent` (`control_plane_store.py:8076–8148`) вызывает callback и переводит intent в completed в одной canonical `_job_transaction`. Callback должен вернуть exact event ID. `_append_association_event` (`predictive_calibration.py:1507–1561`) через event log добавляет diagnostic event в тот же store. Factory действительно передаёт один `_control_store` в `RuntimeDiagnosticEventLog` (`run_lifecycle.py:7385–7392`); `_operation_intent_store` проверяет этот owner (`predictive_calibration.py:1127–1145`).
- **Recovery/replay:** событие и association повторно открываются и связываются с run/job/scope/request/full selected ref (`predictive_calibration.py:1164+`, `_claim_result_matches:1148–1161`). Completed row сама по себе не доказывает доступность/валидность CAS. `except BaseException` (`:878–903`) записывает refused до начала producer либо recovery_required после него. Критическая смерть процесса может оставить pending: показано, что restart не превращает его в новое исполнение. Operator reconciliation полного такого pending здесь не квалифицирован.
- **Atomicity boundary:** transaction охватывает SQL, а не external provider, численные jobs и CAS. Оставшийся blob после rollback не равен опубликованному результату. Именно поэтому нельзя безусловно очищать intent и повторять expensive/external producer при cancellation.

### Поток C: completed HTE → SQL outbox → Scientist DecisionValidity → SQL notification

- **Source:** `_complete_job_in_transaction` (`control_plane_store.py:7016–7104`) сохраняет job completion source event и отдельный outbox `control.decision_validity.hte_source_update` в одной SQL transaction.
- **Owner-derived request:** Runtime (`run_lifecycle.py:13881–13966`) заново согласует job state, exact completion event/attempt и typed selection. Stable dedupe/event ID выводятся из этого source, не из caller-supplied mutable summary.
- **Dependency consumer:** `decision_packet/basis_sections.py:246–262` регистрирует `hte_completed_source_run:<run>` как ECONOMETRIC_EVIDENCE; эта поверхность реально идёт через generic invalidation, не SEMANTIC_EPOCH.
- **Delivery:** `run_lifecycle.py:13992–14095` использует bounded frozen watermark, повторно сверяет source и queued payload, вызывает `publish_decision_validity_event`, затем помечает originating outbox published. Exception оставляет pending и failure reason.
- **Scientist state:** `_DecisionValidityStateStore` (`decision_validity.py:277–365`) хранит packet/dependency/lineage/dedupe JSON под local CAS root. Каждый файл пишется атомарно, owner lock общий для процессов (`:489–516`), но общей rollback-транзакции по файлам нет.
- **Result publication:** Runtime `publish_decision_validity_event` (`run_lifecycle.py:15393–15474`) сначала вызывает Scientist, затем пишет SQL notification `control.decision_validity.event_published`. Это другой state owner и отдельный commit, а не одна атомарная операция с Scientist files.

## 2. STATE-01: workflow-selection edge не переживает pending-finalize recovery

**Приоритет: P2. Уверенность: высокая в source/seam механизме; production occurrence не установлена. Новый механизм, не повтор shutdown/cancellation LIF-01–03.**

`_write_finalize_journal` (`context.py:1178–1186`) сохраняет только schema_version и RunManifest. Нормальный `_finalize_locked` добавляет выбранный transition в terminal.inputs (`:3268–3274`). Recovery вызывает `_append_run_finalized_event`, который создаёт `TraceRefs(outputs=[run_ref])` без inputs (`:1402–1416`). Выбранный transition нельзя безопасно восстановить простым поиском по outputs: это другая семантика и там потенциально несколько подходящих refs.

### Различающие проверки

`finalize_recovery_results.json`, exit 0:

- Нормальное завершение: selected workflow ref присутствует у actual terminal reader.
- Injected OSError перед CAS manifest write, после него и перед terminal append: во всех трёх journal содержит workflow ref в outputs; recovery завершается, удаляет journal, actual terminal reader возвращает `workflow_finalization_ref=None`; exact finalize retry → `run_finalize_workflow_finalization_not_established`.
- Сбой после terminal append, до journal clear: recovery не делает дополнительный CAS put, не меняет trace и сохраняет workflow ref.
- Foreign journal owner, malformed journal и duplicate terminal: отказ до нового CAS write/trace append, journal сохраняется.

Применены настоящие ArtifactID/ArtifactRef, RunManifest/TraceRecord schemas, AtomicFileWriter, JsonlTraceSink и неизменённые bodies finalization/recovery/terminal selection. RunContext initialization, CAS bytes/profile/owner validator и некоторые intake helpers являются fixtures. Тест доказывает потерю selection edge между этими bodies, а не полноценный filesystem CAS security failure. Hard process kill/power-loss и full workflow engine этим probe не запускались.

**Направление ремонта:** расширить существующий Core finalize journal так, чтобы он содержал exact выбранный transition ref вместе с run request; проверять его owner/output/profile binding и передавать тот же edge при recovery. Не ослаблять Runtime reader и не выводить authority из наличия похожего output. Старые journals без selection должны иметь явную ограниченную recovery policy.

**Acceptance:** штатный Python/locked environment, реальный FileSystemCAS и sync/async workflow producers; kill/exception после каждого durable step; reopen через Runtime и audit reader; exact selected ref сохраняется и повтор idempotent. Негативные случаи: foreign owner, изменённый profile при том же artifact ID, несколько candidate finalization outputs, конфликтующий retry и legacy journal. Завершение проверки только после downstream workflow/terminal-state consumer, а не после `run_terminality=terminal`.

## 3. STATE-02: durable dedupe может опередить обработку invalidation

**Приоритет: P2; повышенный приоритет custody-repair. Уверенность: высокая в generic delivery механизме; масштаб и эффект на опубликованные claims не установлены. Новый механизм, не повтор NS-02 pending-overlay cost.**

`record_dependency_event` (`decision_validity.py:1950–1993`): сначала `save_dedupe_event_id`, затем fanout `_apply_event_to_packet`. При существующем dedupe выполняется только `ensure_evaluation`, без повторного применения event. Аналогичный порядок есть у `mark_packet_trigger:1995–2027` (source-only sibling, отдельно не исполнялся). `owner_transaction` освобождает lock в finally, но не откатывает уже заменённые JSON files. Поэтому название transaction не даёт all-or-nothing.

### Cross-boundary результат

`validity_delivery_results.json`, exit 0, два синтетических packet targets с изначальным ACTIVE и реальным generic ECONOMETRIC_EVIDENCE dependency index:

- Без сбоя: оба targets получают STALE, повтор не применяет event ещё раз, одна SQL notification.
- Ошибка до первого packet: dedupe сохранён, originating Runtime call падает до notification. После нового service instance retry вызывает `_apply_event_to_packet` **0 раз**, actual `ensure_evaluation` использует cache branch; Runtime получает `{active: 2}` и сохраняет notification, хотя request.status=STALE.
- Ошибка на втором packet: после reopen та же retry-ветвь возвращает `{stale: 1, active: 1}` и сохраняет notification; второй target не был обработан.
- Ошибка до dedupe write: повтор обрабатывает оба targets, оба STALE. Это исключает трактовку «любая ошибка обязательно теряет event».
- SEMANTIC_EPOCH dependency: generic intake отказывает `semantic_epoch_dependency_requires_owner_batch`, dedupe не пишется. Отдельный epoch pending-freeze path и его crash tests не объявляются сломанными.

В probe настоящие schemas, file locks, atomic dedupe IO, `record_dependency_event`, cached branch `ensure_evaluation`, Runtime publication wrapper и SQL outbox. Применение события к packet, хранение evaluations вместо настоящего CAS и API response являются fixtures. Поэтому ACTIVE здесь является наблюдением заданной fixture, а не заявлением о реально опубликованном PolicyOS claim. Однако отсутствие повторного application и ранний dedupe непосредственно следуют из настоящего owner code. TTL/независимая будущая переоценка могут обнаружить отдельные изменения; это не доказательство replay утраченного event.

По source wiring HTE delivery после успешного такого повторного `publish_decision_validity_event` может пометить originating outbox published (`run_lifecycle.py:14082–14088`). Полный HTE sender/producer/authenticated route не исполнялся, поэтому это **source-supported последствие**, не наблюдавшийся end-to-end ack.

**Направление ремонта:** в существующем DecisionValidity owner различить received/pending/applied и удерживать полный target denominator до completion. Не переносить authority в SQL notification. Один лишь перенос dedupe в конец оставляет partial-application/replay и event-collision вопросы; нужны idempotent target application, fail-closed pending overlay и restart reconciliation. Сначала использовать имеющийся epoch batching опыт как reference, не смешивая его authority contracts с generic events и не создавая новый sovereign state subsystem.

**Acceptance:** actual packets, real CAS и Runtime HTE outbox; ошибки до/после dedupe, между targets, при packet JSON replace, CAS evaluation write и notification enqueue; restart independent process; потерянные targets остаются non-current до применения, originating delivery не подтверждается раньше полного outcome. Повтор exact event не дублирует transitions/jobs, different payload with same dedupe нельзя принять без проверки; corrupt state и semantic-epoch generic bypass закрыты. Generic `mark_packet_trigger` включить в sibling regression.

## 4. Положительные SQL guarantees и ограничения

`intent_transaction_results.json`, exit 0:

- 4 синхронизированные гонки двух процессов: для same body один owner и один pending; для different body один owner и один body_conflict.
- Tenant, full cell, actor digest, purpose и run независимы. NL route scope не создаёт второго owner при новом generated candidate run ID; возвращает provenance первого.
- Неправильный owner token не вызывает publish callback.
- Callback с неправильным event ID: actual diagnostic+outbox SQL writers откатываются, intent остаётся pending.
- Успех и reopen: completed, один diagnostic и один outbox; exact completion replay не вызывает callback.
- Повторный ack не увеличивает attempt второй раз; поздняя failure запись не возвращает published в pending.
- Смерть отдельного процесса внутри публикационной transaction: diagnostic/outbox delta=0, reopened claim=pending. Отдельный synthetic blob сохраняется: он специально демонстрирует отсутствие общей SQL/filesystem transaction, а не повреждение настоящего CAS.
- recovery_required переживает reopen и запрещает completion/автореповтор тем же старым token.

Использованы canonical SQLite DDL и unchanged store methods/models. Constructor минимальный, domain callback синтетический. В нём outbox вставлен как discriminator SQL atomicity; **не утверждается, что Predictive Calibration публикует этот synthetic outbox topic**. No active job fence в этом probe: предыдущий `next_lifecycle` отдельно исследовал job lease fencing. PostgreSQL, store migrations и eventual operator recovery UNRUN.

## 5. Что сохранить и что не объединять

- Сохранить единый SQL intent owner для Predictive/NL и exact body conflict. Не заменять его generic process-local HTTP cache.
- Сохранить strict terminal input selection и exact manifest profile. Исправлять producer/recovery journal, а не читателя.
- Сохранить distinction transaction, serialized owner lock, immutable blob и cached projection. У них разные гарантии.
- Сохранить SemanticEpoch full-target pending freeze как отдельный положительный механизм. Generic dedupe не получил его crash guarantee автоматически.
- Не считать outbox delivery mark доказательством downstream completeness, если downstream receipt может означать только ранее увиденный dedupe.
- Не расширять прежние CAS-owner predicate tests до заявления о целостности всех CAS writes. Здесь actual CAS implementation не квалифицирован.

## 6. Проверки и воспроизведение

Из `next_state_owners`:

- `python probe_finalize_recovery.py`
- `python probe_intent_transactions.py`
- `python probe_validity_delivery.py`
- `python validate_evidence.py`

Python 3.12.14 / Pydantic 2.13.4 / SQLite 3.53.1, а не declared 3.14/locked profile. Новые зависимости не установлены. Полные pytest, lint, installed imports, APIs, Postgres и native CAS не запускались. Отдельные первичные ошибки development самого измерителя (multiline definition extraction и отсутствующая constant в namespace) исправлены в audit scripts; они не считаются product failures. Финальные три probes повторены после последней правки loader.

`SOURCE_VALIDATION.json` проверяет HEAD, каждый процитированный source file against commit bytes, все извлечённые spans и результаты. `OWNER_MATRIX.json` задаёт coverage по трём flows; `FINDINGS.json` содержит два новых механизма и условия acceptance. Исходники не изменены. Исправления, миграции, destructive recovery, provider calls и публикация результатов третьим лицам не выполнялись.
