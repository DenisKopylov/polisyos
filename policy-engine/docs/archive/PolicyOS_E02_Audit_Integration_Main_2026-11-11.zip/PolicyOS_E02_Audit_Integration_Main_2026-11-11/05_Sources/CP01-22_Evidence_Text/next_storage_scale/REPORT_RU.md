# PolicyOS: рост CAS storage, ownership index и quota census

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Source read-only. Этот срез дополняет `next_scaling` и `next_catalog_scale`: не повторяет run-index cap/race, validity overlay, VOI fitting или semantic catalog rebuild. **Новые измерения относятся к конкретным локальным storage owners, не к production capacity, SLA или release acceptance. Исправлений продукта нет.**

## Главный результат

1. **ST-01: полноразмерная история ownership generations растёт квадратично** при последовательном добавлении новых claims постоянного размера. Настоящие `record_owner`, codecs, locks и durable atomic IO оставили после 800 claims 800 поколений на **74 492 731 байт**, хотя активное поколение занимает **185 001 байт**. Diagnostic `evidence()` прочитал 74,678 MB и занял 10,939 s на этой локальной fixture.
2. **ST-02: warm exact ownership lookup не означает bounded byte work.** При 50 000 claims, распределённых по 100 synthetic tenants в одном shared root, каждый `owners_for(one_id)` прочитал и захешировал всё активное поколение на **10 050 932 байта**. Декодированный cache действительно используется: повторного `_parse_generation` нет. Отдельный heap probe показал около 10,06 MB временных Python allocations даже для warm lookup; cold decode peak около 101,22 MB.
3. **ST-03: compatibility TenantScopedCAS делает два полных filesystem census под tenant mutation lock**, в том числе для underlying no-op или исключения. При 50 000 файлов по 32 байта получены **170 522 directory entries и 170 528 lstat calls** за один no-op wrapper write. Это не production endpoint: обычные product callers данного wrapper, кроме resolver/export, не обнаружены в source; production wiring не установлено.

Это engineering capacity risks, а не продемонстрированная утрата данных, нарушение tenant isolation, breach latency budget или дефект обязательного fail-closed поведения. Наоборот, выполненные negative controls подтверждают, почему простое отключение checks/census/retention небезопасно.

## 1. Реальный dataflow и область действия

Ссылки ниже относительно `policy-engine/src/polisyos/`.

- `core/artifacts/store.py:3162–3199`: FileSystemCAS transaction claims вызывают `record_owner`, `record_blob_reader` и `record_view_owner` на существующем `ArtifactOwnershipIndex`. Один artifact может иметь несколько owner/view claims; число физических blobs не равно числу index updates. В этом измерении исполняется public `record_owner`, но **полная FileSystemCAS publication transaction не запускается**.
- `core/artifacts/ownership.py:1215–1272,1474–1540,2307–2396`: новый claim публикует полное содержимое ownership index в immutable generation и заменяет небольшой current pointer. Родительское поколение остаётся связано по SHA-256. Payload включает все artifacts, blob readers и public-read closures данного root. Shared root означает общую величину этого denominator для разных tenants/cells.
- `store.py:1759–1861,1960–1976,2202–2217`: blob, default owner и exact manifest-view reads требуют соответствующих owner checks; входные lineage roles также проверяются. Проверки нельзя свести к «blob уже известен» и потерять profile/cell/role semantics.
- `ownership.py:1590–1614,1984–2024,2106–2159`: точечный lookup использует immutable decoded cache, но cache hit проверяется **после чтения и hashing текущего generation file**. Малый результат не ограничивает bytes read.
- `ownership.py:1803–1903,1947–1979`: diagnostic evidence проходит весь retained parent chain, заново разбирая и проверяя поколения. Отдельный lean `_current_generation_token` не делает эту историю. `store.py:5507–5532` специально выбирает lean token для stock index; нельзя приписывать history scan каждому CAS inventory/read.
- `fabric/storage/tenant_cas.py:233–309,408–431`: compatibility namespace/quota wrapper измеряет весь `artifacts/sha256` в constructor и до/после каждой mutation. Его обычный shared-root FileSystemCAS owner plane и tenant-local quota plane различны. Нельзя переносить измеренный tenant census на все CAS reads или на все Runtime requests.

Документация `docs/reference/operations/cas-storage.md:94–112` прямо называет TenantScopedCAS compatibility wrapper, описывает root lock, exact absent-member admission и исключение operational control state из byte measure. В `src/polisyos` найдены определение, resolver и re-export, но не прямые product call sites; это ограниченный source lookup, не доказательство отсутствия динамического/external использования.

## 2. ST-01: полный snapshot на claim и retained history

**Severity:** medium scaling risk. **Confidence:** высокая для механизма и ограниченных измерений; частота и рабочая ёмкость production не измерены.

Изолированные synthetic roots; одна новая уникальная ArtifactID и один tenant owner на шаг. Исполняются неизменённые полные модули ownership/ArtifactID/atomic IO/canonical codec; нет подмены serializer, hasher, filesystem, flock, fsync или generation parser. Готовых blobs/manifests нет, поэтому это **ownership-subsystem workload, не full CAS write benchmark**.

| Claims N | Generations | Active generation bytes | Все retained generations bytes | Последовательные record_owner, s | evidence(), s |
|---:|---:|---:|---:|---:|---:|
| 50 | 50 | 12 501 | 343 231 | 0,669 | 0,123 |
| 200 | 200 | 47 001 | 4 823 131 | 4,449 | 1,169 |
| 800 | 800 | 185 001 | 74 492 731 | 23,764 | 10,939 |

Здесь exact observed byte model: `B_i = 1001 + 230*i`, кроме первого поколения, которое меньше на 69 bytes из-за null parent; сумма равна `1001*N + 230*N*(N+1)/2 - 69`. Это формула **данной fixture** с фиксированными строками, не прогноз производственных байтов. При четырёхкратном увеличении N от 200 до 800 retained bytes выросли в 15,445 раза.

Общая сложность:

- B_i обозначает полный serialized index на шаге i; retained generation storage и generation-write byte work равны Θ(Σ B_i). При одном новом claim фиксированного размера на шаг B_i=Θ(i), сумма Θ(N²).
- Один update имеет как минимум Θ(B_i) validation/serialization/hash/copy work; сортировки добавляют стоимость, зависящую от числа artifact keys и распределения claims. Нельзя объявить весь CPU update строго линейным или всю последовательность строго Θ(N²) по времени: dict/record sorting имеет O(A log A) / O(K log K) worst-case, реальные предыдущие записи уже упорядочены, присутствуют codecs/fsync/locks.
- Mutable snapshot detaching и serialization временно требуют память, пропорциональную текущему payload; не нужно держать всю историю в RAM.
- `evidence()` выполняет Θ(Σ B_i) read/hash/parse по parent chain до genesis/legacy capture, плюс current snapshot work. Для 800 generations счётчик дал **801 generation reads, 74 677 732 generation bytes и 800 parses**: текущее поколение читается один раз для snapshot и ещё раз при history walk.
- Число N здесь означает distinct admitted claim updates, а не runs, tenants или bytes blobs. Dedupe, несколько claims на blob, imports и legacy paths меняют связь этих величин. Их production multiplicity не измерялась.

Контроли:

- Повтор уже существующего owner claim не создаёт нового поколения, current pointer не меняется. При этом существующее payload читается/декодируется после предыдущего invalidation и проверяется; exact retry не равен бесплатному вызову.
- Отдельный `controls_results.json`: другой живой index instance публикует claim, первый видит новое поколение. Exact profile/cell mismatch отвергнут.
- Из трёх поколений временно убран один ancestor **только внутри generated fixture**. Current token и current lookup остались доступны, но evidence сменилось с `no_pre_v3_pair` на `pre_v3_history_unresolved`; восстановление ancestor восстановило статус. Следовательно, «удалять старые JSON» не является бесплатной оптимизацией custody history.

**Минимальное направление:** расширять существующий ownership owner, не заводить второй inconsistent index. Сначала определить retained-history/compaction contract: доказуемые checkpoints, content-bound deltas либо authenticated persistent structure с сохранением current lookup и полной provenance. Batch нескольких claims в одну атомарную generation может уменьшить число snapshots, но должен соблюдать existing publication/recovery и exact-view admission, не делать claims видимыми раньше артефакта.

**Acceptance:** supported-profile real CAS writes, default/blob/view claims и input lineage; growth по числу claims, tenants/cells, views и runs; byte/heap/latency budgets отдельно; restart/crash в каждом publication step; duplicate retry; сохранение historical evidence после разрешённой compaction, corruption/missing history fail-closed статус. Никакая compaction здесь не реализована.

## 3. ST-02: decoded cache экономит parser, но не размер reads

Каждый size создаёт **одну** schema-valid generation через настоящий `_write_payload`: это изолирует current-size cost от накопления поколений. N unique IDs распределены round-robin по 100 tenants; queried ID имеет один owner. Это controlled synthetic ownership payload, не артефакты, полученные реальным scientific pipeline.

| Claims | Generation bytes | Cold owners_for, s | Warm median, s (5 samples) | Incremental cold heap peak | Incremental warm heap peak |
|---:|---:|---:|---:|---:|---:|
| 1 000 | 201 932 | 0,0229 | 0,000413 | 1 977 063 B | 209 275 B |
| 10 000 | 2 010 932 | 0,2256 | 0,002166 | 19 797 462 B | 2 018 835 B |
| 50 000 | 10 050 932 | 2,1846 | 0,014623 | 101 221 843 B | 10 058 835 B |

Каждый warm sample читает ровно два файла: pointer 203 bytes и generation B bytes. `_parse_generation` больше не вызывается, cache object сохраняется; lookup не thaw-ит весь index. `generation_token` имеет те же B+203 bytes, но не parent scan. Это **исправный parse cache с линейным integrity read**, а не ложное утверждение «cache отсутствует».

Сложность exact warm lookup: Θ(B + k), где B — bytes всего текущего generation file, k — число возвращаемых rows для artifact (copy + predicate при соответствующем consumer). Temporary raw bytes Θ(B); retained decoded snapshot Θ(total claims). Q независимых checks на неизменённом index читают Q*(B+203) application bytes в этой fixture. Физический диск может обслуживаться page cache; количество byte reads не равно физическому storage traffic. Не выводим Q для целого production request без отдельного trace.

`tracemalloc` измерен отдельными вызовами, вне timed/counter samples. Cold traced retained allocations для 50k = **26 978 170 bytes**, warm retained delta = **1 100 bytes**. Это incremental Python heap, не total RSS, не native allocations, не memory leak и не per-tenant quota. Уже существовавшие imports/fixtures/предыдущая cache-reference не входят в traced baseline; cumulative process RSS 251 636 KiB включает их и earlier series. Поэтому нельзя считать 101 MB полным пределом deployment или суммировать эти значения с RSS.

Контроли: возвращённые row dicts можно менять без изменения cache; смена generation видна внутри и между instances. После same-length изменения tenant bytes в generation и восстановления прежнего mtime прогретый index отвергает файл: `ownership_index_generation_invalid`. Возврат точных original bytes восстанавливает чтение. Это и есть важный контракт: нельзя заменить read/hash на stat-cache и тем самым потерять content-bound tamper detection.

Существующие `test_cas_owner_snapshot_query.py` проверяют отсутствие whole-index thaw на повторных lineage roles, а также corruption/freshness. Это полезная уже реализованная оптимизация; отсутствие full reparse не доказывает bounded I/O. Тесты прочитаны, не запущены: pytest/native FileSystemCAS unavailable в этом окружении.

**Направление:** квалифицировать существующий owner для request/transaction-consistent validated snapshot с явной ревокацией/refresh fence или authenticated indexed structure, а не удалять tenant/cell/profile/role checks. Сначала отдельно измерить суммарные byte checks реального read/write graph. Acceptance обязательно включает same-size/same-mtime corruption, другой writer, pending transactions, every lineage role, exact selected views, revocation и stale leader. Generic LRU не решает этот контракт.

## 4. ST-03: file-count cost quota wrapper не ограничен byte quota

Настоящие `_directory_size`, `_storage_mutation`, `put_bytes`, `_TenantQuotaAdmission` выполнены как unchanged selected source bodies. Fixture заменяет **конструктор, underlying CAS writer и quota-enforcer state**, поэтому это измерение wrapper/census механизма, не записи реального artifact и не тест quota exceeded. Реальные local files, directory traversal, lstat, tenant RLock/flock и `finally` исполняются.

Layout: одна 32-byte `.blob` на synthetic hash ID, два hash-prefix directory levels. Это path shape настоящего CAS, но файлы не прошли CAS admission и не содержат manifests. Время создания input files исключено.

| Files | Учтённые bytes | Один census entries | No-op wrapper entries (2 scans) | No-op lstat | No-op wrapper time, s |
|---:|---:|---:|---:|---:|---:|
| 1 000 | 32 000 | 2 248 | 4 496 | 4 502 | 0,068 |
| 10 000 | 320 000 | 19 534 | 39 068 | 39 074 | 0,592 |
| 50 000 | 1 600 000 | 85 261 | 170 522 | 170 528 | 2,457 |

E = все materialized files + traversed subdirectories внутри `artifacts/sha256`. Census Θ(E), mutation wrapper делает 2E entries и `2E+6` lstat calls в данном инструменте. Byte quota сама по себе не ограничивает E: много маленьких members могут стоить дорого даже при малом storage byte total. P mutations на неизменённой популяции: Θ(P*E) census work, дополнительно actual writer и quota admission. Растущая популяция даёт Θ(Σ E_i). Это не оценка времени parallel deployment; lock contention/load не запускались.

Census выполняется внутри одного tenant-root mutation lock, поэтому wrapper writers данного root последовательно платят эту цену. Roots других tenants имеют свои locks; **global serialization всех tenants не доказана и не следует из кода**.

Контроли:

- При underlying exception `finally` повторно сверяет usage и сбрасывает admission callback; counts такие же 2 scans.
- Existing exact member имеет нулевой delta; два одинаковых absent planned members дают один delta 4 bytes.
- Existing same-size wrong content, unsafe path и census symlink отвергаются настоящими admission/census predicates.
- Добавленные 100 000 bytes под `artifacts/ownership` не изменили quota measure. Это документированный scope, не quota-bypass defect. Но ST-01 generations живут именно там: capacity planning должно учитывать control-state storage независимо от artifact-byte quota.

**Направление:** при доказанном production использовании wrapper сделать crash-safe incremental accounting в том же owner с generation-bound reconciliations и bounded repair scan. Нельзя просто убрать входной scan: он согласует независимые instances/processes и точный absent-member admission. Acceptance: native store concurrent wrappers/processes, existing/new/duplicate/view/signature/import members, quota warn/block, overflow и failed publication, external change/restart reconciliation; bounded census/metadata policy отдельно от bytes. Сначала подтвердить live workload/wiring, затем выбирать приоритет.

## 5. Воспроизводимость, ограничения и source binding

Команды:

```
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 \
python policyos_deep_audit/next_storage_scale/probe_storage_scale.py \
  --source policyos_deep_audit/source \
  --output policyos_deep_audit/next_storage_scale/results.json
PYTHONDONTWRITEBYTECODE=1 python policyos_deep_audit/next_storage_scale/probe_storage_controls.py \
  --source policyos_deep_audit/source \
  --output policyos_deep_audit/next_storage_scale/controls_results.json
```

- Python 3.12.14 / Pydantic 2.13.4 вместо supported Python 3.14 / locked Pydantic <2.13. Standard package import остановился в `store.py:2155` на допустимом для 3.14 exception syntax; traceback сохранён в `normal_import.*`. Это средовой blocker, не product regression.
- Для ownership bypass сделан только для eager package initializers пяти namespaces; все девять реально загруженных implementation/dependency modules сохранены по SHA-256 в results. Реальные canonical codec и integrity validation **не заменены JSON fixture serializer**. Полный ArtifactStore/import/package/native профиль всё равно не квалифицирован.
- Первая версия измерителя успела выполнить все ownership series, затем упала на создании AST future-import node без lineno. Это ошибка **audit harness**, а не source. `instrument_v1.*`, `initial_ownership_results.json`, `ownership.stdout.txt` сохранены. Исправлено только `ast.fix_missing_locations`; финальный запуск `--resume-ownership` сохранил уже законченные ownership samples и выполнил quota series. Полный воспроизводящий command выше не требует resume.
- Final `results.completed=true`, `controls_results.completed=true`, exits 0, stderr пусты. Все IO/heap counters и samples доступны в JSON. Отдельные expected corrupt-input refusals являются controls, не неуспешным завершением.
- Append/seed/cold/heap/quota sizes имеют по одному sample; warm query 5. Синтетические ключи/tenants, один процесс, фиксированный порядок, shared cloud executor, warm filesystem cache. Нет HTTP concurrency, S3/GCS, admission through actual producers, production distribution, power-loss test, complete pytest/lint или p95/SLA verdict. Timings иллюстративны; deciding evidence — byte/operation counts и истинные branches.
- Generated workload directories удалены после выполнения; ничего не удалялось из source или user data. Скрипты воспроизводят workloads; retention/claims/raw byte totals сохранены без сотен дублирующих MB snapshots.
- `SOURCE_VALIDATION.json` сверяет использованные source/test/doc files с ранее pinned complete census; это readset данного прохода, не новая перепись и не semantic coverage всего repo. Source tree оставлен read-only, HEAD прежний, `git status --porcelain` пуст.

Статус: **partial source-qualified storage scale audit**. Design decisions, remediations и native acceptance только предложены. E02 interlock/maintainer risk acceptance этим read-only измерением не закрываются.
