# PolicyOS: структура, тесты и исполняемые правила после checkpoint01

**Результат: частично проверено.** База `f1541ed155f278689be48a8c7ac56c3e200210f7`; 10 ноября 2026. Это углубление SYS-01/SYS-12, а не новый общий PASS, не исправления и не независимый список всех дефектов. Product source, test/config репозитория и E02 не изменялись.

## Главные результаты

1. **Пять текущих package mirror ratios ниже действующего floor.** Неизменённое тело настоящего `_build_package_report`, выполненное на canonical путях и committed baseline, возвращает `floor_regression` для data_forge, foundry, ir, runtime и scientist. Это дополнительные конкретные основания для test ratchet, наряду с ранее установленными 13 reverse imports в shared helpers. Полный native CLI не выполнен.
2. **Не каждый недорисованный import edge является нарушением.** Все 79 выбранных `public parent → child module` случаев, выглядевших подозрительно при сравнении с public module paths, являются явными `__all__` exports. Их нельзя превращать в 79 нарушений. Одновременно synthetic control реального hidden-edge consumer показывает чувствительность к записи: прямой `fabric.world.store` обнаружен, `from fabric.world import store` не обнаружен. Это ограничение одного статического механизма, не подтверждённый обход всего CI.
3. **Mirror ratios измеряют наличие имён файлов.** В 13 объявленных package ratchets 494 source modules получают loose match только благодаря именам файлов в `mirror_contracts`. Один такой basename может сопоставиться нескольким source modules. Изолированный `test_module.py` с единственной assignment и без теста получает 100% strict/loose presence. Это не означает отсутствие содержательных тестов: рядом найдены реальные receipt-removal, ledger-corruption, narrowing и baseline-integrity controls.
4. **В shared test cleanup есть зависимость от import identity.** Файл helper импортируют как `_helpers.runtime_http` и `tests._helpers.runtime_http`, а общий teardown читает только первое имя. На точных cleanup/hook bodies две module-local registry обслуживаются несимметрично. Однако выбранные long-name consumers явно закрывают свои env; реальная утечка приложения или suite здесь не установлена.
5. **Активная contributor-документация расходится с исполнением.** Она указывает pyproject как registry markers и отсутствие `slow`, хотя действующий `pytest.ini` регистрирует `slow`, `quarantine` и taxonomy. Import-table запрещает Foundry → Fabric и разрешает Scientist → Runtime, тогда как действующая direction matrix задаёт обратное для этих двух примеров. Исключения должны проверяться отдельно.

## 1. Что действительно защищают import guards

### Разные графы отвечают на разные вопросы

`lint_imports.ImportCollector.visit_ImportFrom` (`lint_imports.py:190–209`) сохраняет base module и отдельно imported names. Это достаточно для root direction, а `narrowed_import_is_allowed` (`878–893`) специально раскрывает имена, когда parent сам не попал в разрешённый narrowing. Повторённый mixed control `from polisyos.data_forge import read_api, kernel` отклоняется. Существующие tests `test_lint_imports_phase3.py:237–276` действительно различают allowed, disallowed и mixed outcomes; это хороший механизм, а не проверка маркера.

Но `_collect_hidden_import_edges` (`architecture_import_graph.py:525–575`) принимает решение по `target_module`, не используя `imported_names`. В bounded replay настоящего collector и consumer при изолированном import input:

- `from polisyos.fabric.world import write_world_snapshot`: 0 hidden edges, ожидаемый public control;
- `from polisyos.fabric.world import store`: 0 hidden edges;
- `from polisyos.fabric.world.store import create_world_snapshot`: 1 hidden edge.

`store` не является объявленным `__all__` экспортом world facade, но child module существует и используется самим facade. Результат показывает spelling gap статического deep-import consumer. Он не доказывает, что такая строка присутствует в текущем приложении, что native combined gate её пропустит, или что возник runtime failure. Полные policy/exception/CLI эффекты в этой пробе не воспроизводились; isolated exception service возвращает пустой набор.

### 79 реальных кандидатов оправданы facade-контрактами

На разобранной части 2 895 source `.py` найдено 398 cross-root `from parent import existing_child` candidates. Это статические source-known module candidates, а не результаты runtime import resolution. Из них 79 имеют public parent и child path, который сам не входит в public entrypoint list. Все 79 имен явно присутствуют в `__all__` parent:

- common: serialization 19, logger 13, async_tools 7, timestamps 4;
- core: run 16, errors 9, discovery 1;
- core.contracts: epoch 9, chronology 1.

Следовательно, физическую зависимость от implementation child полезно показывать в графе, но отказать разрешённому facade API только из-за этой зависимости было бы ошибкой. `common.__getattr__` и Core facade сохраняют deliberate lazy-loading boundary. Нет основания переносить эти helpers или запрещать их consumers ради красивого DAG.

Отдельный `decomposition_preflight.collect_import_graph` раскрывает child candidates, ведёт source snapshot completeness, разделяет full AST и module-initialization views и оставляет unestablished dispatch явным. Его Scientist/Foundry selector соответствует принятому ADR-0145. Он не превращается от этого в полный repository runtime graph. Нельзя переносить blind spot одного collector на другой без проверки.

## 2. Реальная сила и границы test ratchets

В `ratchets.toml` объявлены **13 package ratchets**, а не все 25 product roots. Повторён именно `_build_package_report` с текущими source/unit/property roots и baseline inventory:

| Package | Current loose | Active floor | Result |
|---|---:|---:|---|
| data_forge | 0.6115 | 0.6123 | floor_regression |
| foundry | 0.7088 | 0.7176 | floor_regression |
| ir | 0.5978 | 0.6012 | floor_regression |
| runtime | 0.6927 | 0.7152 | floor_regression |
| scientist | 0.7054 | 0.7099 | floor_regression |

Остальные восемь не объявлены поведением «прошедшими»: этот результат относится только к данному presence metric. Полные записи strict/property/baseline fields сохранены в `structure_depth_results.json`. Текущий Standard PR workflow запускает reporter с `--fail-on-regression`; настоящий `main` проверяет floor/strict/property/helper regression. Это source-traced gate wiring, не hosted CI result. Inherited attribution не устанавливалась.

### 494 — modules, не тесты и не дефекты

В hypothetical пересчёте исключены только `mirror_contracts` filenames из loose matcher, без удаления или изменения файлов. Потеря loose source matches: berl 8; core 43; data_forge 38; ddm 9; fabric 88; foundry 134; ir 68; runtime 44; scholar 7; scientist 55. common/calibration/lex: 0. Итого **494**. Strict mapping не менялся; это не оценка semantic coverage.

Настоящий package reporter не читает test body для этой метрики. Synthetic `test_module.py` с `placeholder = None` и без `test_*` function даёт strict=loose=1.0. Сам mirror helper из checkpoint тоже обещает только definition/assignment/import-bearing structure. Поэтому нельзя использовать ни наличие файла, ни ratio, ни его зелёный static helper как замену негативному поведенческому тесту.

Положительная сторона: baseline values валидируются, включая обязательность и допустимость count/ratio. Первоначальная наша fixture забыла `source_module_count_baseline`; настоящий метод отказал с `ValueError`. Fixture дополнена обязательными полями, failure сохранён в `structure_depth_fixture_failure.log`. Это ошибка измерителя, не product failure и не основание ослаблять gate.

## 3. Shared helpers: direction, import identity и cleanup

Ранее подтверждённые 13 forbidden edges в 7 из 74 разобранных helpers остаются source-level нарушением declared contract. Уточнён execution context: **2 top-level imports**, оба в `observational_source_runtime.py`, и **11 function-local imports**. Они не должны все трактоваться как eager startup cycle.

Concrete path: `runtime_http.build_runtime_api_env_with_fixture_catalog` → функции из `test_catalog_profile_http` и `test_substrate_registry` → test-owned published catalog/registry. Это усиливает зависимость общей fixture инфраструктуры от конкретных test modules. Переименование или изменение их imports может ломать много consumers, а shared helper больше не является нижним слоем. Но import-order crash, автоматический запуск импортированных tests или contamination в production здесь не воспроизведены.

Есть отдельная module-identity граница:

- локальный HTTP conftest импортирует `_helpers.runtime_http`;
- например, `observational_source_runtime` и `test_catalog_profile_http._build_api_env` используют `tests._helpers.runtime_http`;
- helper создаёт `_RUNTIME_API_ENVS` как module-local list и регистрирует только дополнительный alias `polisyos_tests_runtime_http_conftest`;
- корневой `pytest_runtest_teardown` (`tests/conftest.py:285–291`) смотрит только `_helpers.runtime_http`.

В exact-body replay после hook короткое имя закрыло synthetic resource один раз и очистило свой registry; длинное имя оставило свой resource/registry нетронутыми. Явный `close_runtime_api_env` длинного имени, вызванный дважды, закрыл resource один раз и очистил registry. Это подтверждает механизм несимметричного fallback cleanup, не существующую утечку: выбранные реальные consumers используют `try/finally`, а fixture wrapper закрывает env самостоятельно. Требуется native dual-import/exception-path test, прежде чем объявлять фактическую suite resource leak.

Хорошие свойства cleanup сохранять: resource publication до потенциального registration failure, `except BaseException` с cleanup, nested `finally` для client/service/catalog и idempotent close. Исправление должно согласовать canonical helper identity/owner, а не удалять эти защитные ветви.

## 4. Выбранные semantic tests и связь с CI

Полная матрица — `test_obligations.json`. Это **source review выбранных tests**, а не их успешный runtime replay.

- **Catalog freshness:** `test_catalog_profile_http_selects_published_plan_through_fresh_reader` создаёт published fixture, обращается к настоящему route, проверяет другой reader object и совпавший database path, затем удаляет `stage_state.json`, создаёт ещё один reader и требует пустых fetch plans с stale/not-established reason. Это значимый producer/persisted-consumer/removal discriminator, хотя inputs остаются синтетическими.
- **Cost projection:** `test_fresh_job_cost_projection_refuses_ledger_drift` проходит ordinary POST/dispatch, меняет persisted ledger в трёх вариантах missing/changed/foreign_attempt, требует `not_established` без events, восстанавливает bytes и проверяет возвращение прежних events. Локальный deterministic profile не равен real provider validation, но тест проверяет property, а не имя статуса само по себе.
- **Worker lifecycle:** выбранный renewal test действительно наблюдает продление lease пока handler работает. Два shutdown tests проверяют подавление store-unavailable release/logging, один сам выставляет `_stop`. Эти три tests не проверяют, что `stop(timeout)` дождался физического handler, и потому не опровергают checkpoint shutdown witness. Отсутствие других lifecycle tests из этого не выводится.
- **Import narrowing и baseline integrity:** real authored controls включают mixed inputs, неверный parent/submodule, отсутствующий governance disposition, invalid baselines. Это полезные существующие owners для расширения, новый framework не нужен.

`tests/conftest._infer_primary_marker` помечает `tests/unit/runtime/http` как integration. Fast PR явно исключает этот root; Standard PR отдельно запускает его и отдельно integration cohort с исключённым HTTP root. Значит, absence из Fast lane сама по себе не coverage hole. `tests/quarantine.toml` в этом pin не содержит ни одной case entry. Hosted run, skips из-за optional dependencies и supported collection не установлены.

## 5. Документация против исполнения

Подтверждён narrow drift в действующем `CONTRIBUTING.md`, а не во всём docs:

- markers/slow: ориентиром исполнения являются `pytest.ini` и `tests/conftest.py`;
- direction matrix: canonical owner `architecture/imports/policy.toml` плюс package narrowing и exceptions, а не устаревшая prose table;
- необходимость semantic tests прописана отдельно от filename ratchet. Не следует делать отчёт о semantic coverage из mirror threshold.

В `documentation_disposition.json` отделены active guidance, machine contract, accepted ADR и неперепроверенные historical/distribution surfaces. Source/generated/docs lifecycle и wheel/sdist selectors не перестроены в этом раунде: прежние bounds остаются, свежего installed-wheel или distribution total нет. Никакие docs не удалялись и не переносились.

## 6. Охват, воспроизводимость, ограничения

- Именованный AST denominator: **2 895 current source `.py` + 3 752 tests `.py` = 6 647**. Независимая сверка с tracked manifest совпала точно. `.pyi`, frontend, tools и docs не выданы за часть этого denominator.
- Python 3.12 разобрал 2 859 source + 3 749 tests. **36 source + 3 tests остались unresolved** из-за поддерживаемого проектом Python 3.14 syntax. Ошибки перечислены, не замолчаны и не превращены в пустые inputs.
- `coverage.json` перечисляет все 25 source roots (root initializer учтён отдельно) с реальным уровнем проверки: syntax/import candidates не являются semantic review каждого файла.
- Прямой import настоящего `lint_imports` остановился в `tools/lib/fs.py:884` на Python 3.14 exception syntax. `native_import_attempt.log` сохраняет traceback/exit 1. Это tooling/profile boundary; native CLI/pytest не запускались через изменённую копию source.
- Probes исполняют точные выбранные AST bodies с изолированными namespace/input seams. Они не равны normal module import, всей CLI, full pytest или live application. Substitution описана в коде и результатах.
- `SOURCE_VALIDATION.json`: **6 662 уникальных прочитанных path** совпали и с receipt, и с baseline SHA-256. Это не rehash всего repo и не semantic verification 29 934 файлов.
- `source_excerpts.json` содержит доступные компактные exact excerpts с path/line/source hash. Полный повтор probes требует canonical checkout данного commit; один hash не заменяет его bytes.
- При финальной проверке coverage-row count выявлена ошибка нашего группировщика: root `polisyos/__init__.py` был ошибочно назван двадцать шестым package root. Он перенесён в отдельное поле, знаменатель 2 895 не изменился.
- В раннем progress-сообщении сумма mirror contributions ошибочно названа 594; исправлена на **494**. Пофамильный JSON был корректен; report и итоговая арифметика согласованы.

Для повторения из workspace: `PYTHONDONTWRITEBYTECODE=1 python policyos_deep_audit/next_structure/inspect_imports.py`, затем `probe_structure_depth.py`, затем `write_deliverable.py` по тому же пути. Все outputs остаются вне read-only source. Первый inventory создаёт полный denominator, второй выполняет bounded controls, третий формирует manifest-qualified evidence. Native supported-profile gate остаётся отдельным acceptance.

## 7. Ограниченные следующие изменения, не выполненные здесь

1. Сначала existing quality owner разбирает пять floor regressions и 13 reverse imports. Добавлять placeholder tests только ради ratio недопустимо; границы подпираются реальными изменившимися obligations.
2. Поднять test-specific fixture factories из concrete test modules в существующий shared helper owner; выбрать одно module identity и проверить cleanup при обеих формах импорта/исключении. Сохранить explicit close.
3. Для deep-import checks добавить source-resolved child/facade-export distinction и synthetic spelling controls, сохранив 79 разрешённых facade usages. Не считать любые child dependencies нарушениями.
4. Исправить narrow CONTRIBUTING drift или заменить таблицу ссылкой/генерацией от canonical policy. Не переписывать historical evidence.
5. Выполнить native Python 3.14/locked tests и gate, затем выбранный whole-app shutdown. До этого не объявлять поддерживаемый профиль или suite green.

**Завершён этот targeted structure pass; вся программа глубокого аудита, native acceptance и implementation remediation остаются отдельными задачами.**
