# Durable worker scope → CAS custody после restart

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`. Read-only архитектурный аудит. Новый срез продолжает `next_auth`, `next_state_owners`, `next_delivery_chain`, не повторяя delivery dedupe, checkpoint restore или namespace collision.

## Результат

**На выбранном пути новый дефект изоляции или exploit не установлен.** Исполнены 10 worker/queue cases и 9 CAS/config controls. Реальные SQLite/CAS данные созданы одним процессом; другой свежий Python process заново открыл owners и выполнил все cases последовательно в независимых fixture roots. Assertions и source-binding validation проходят. Это **PARTIAL bounded integration**, не native/API/security release pass.

Новая сила доказательства относительно `next_auth`: не только extracted owner predicates. Работают целые `FileSystemCAS`, `ControlPlaneStore`, `ControlWorker`, canonical SQLite schema, manifest/blob/ownership-generation persistence и реальные typed reads/writes. Runtime orchestration остаётся ограниченной извлечёнными методами и явно описанной точкой остановки.

1. **Durable identity:** чужие ambient tenant/cell и `AccessScope`, поддельные progress owner hints и даже подменённый dispatch snapshot не заменили scope из live SQL lease и immutable creation envelope.
2. **Full identity:** foreign tenant, другой полный cell с теми же первыми восемью символами и чужой selected manifest profile на общем blob получили отказ. Same content ID не выдаёт ownership чужого manifest view. Typed input edge на чужой profile также не допускает derivative write.
3. **Unknown не превращён в concrete:** legacy event без scope очищает tenant/cell/AccessScope. Tenant-claimed payload не читается. Unclaimed candidate payload допускается только до исследуемой payload boundary, с удалёнными caller owner claims. Полная candidate execution/publication в этом probe отсутствует.
4. **Configuration не является custody:** намеренно убранный ambient enforcer в removal-control позволяет raw CAS прочитать чужой selected profile. Штатный Runtime filesystem composition явно добавляет enforcer; его config-only обход в контрольной fixture не объявляется уязвимостью. Это объясняет, почему восстановление storage config и восстановление admissible execution scope должны проверяться раздельно, как уже показал RR-03.

## Прослеженный actual path

- `core/artifacts/backends/config.py:51–72,138–150`: `build_artifact_store` создаёт filesystem backend; explicit tenant/cell для других backends отказывает до import/network. Ambient ownership устанавливает отдельная factory capability.
- `runtime/http/dependencies.py:115–136` и `services/control/run_lifecycle.py:7293–7314`: default filesystem Runtime composition применяет `with_ambient_ownership_enforcement_if_supported`, затем Runtime guard. Read-only context отдельно сохраняет base store для server-owned index. Наличие raw owner не означает, что его отдают tenant route.
- `run_lifecycle.py:9535–9575`: реальные `_execution_scope_payload` и `_job_created_event_payload` строят полный creation envelope. В probe они вызваны; authenticated route, permission proof, capability discovery и pre-admission producer не вызваны.
- `control_plane_store.py:4269–4562`: настоящий `create_job` атомарно сохраняет job, creation event, progress и creation outbox. Constructor/schema не подменены. `lease_next_job` вызывается настоящим worker.
- `control_worker.py:281–295`: SQL execution fence и `clear_tenant_context` установлены до handler; heartbeat thread и worker diagnostic writes действуют. Lease ownership снова читается actual SQL owner.
- `control_plane_store.py:2038–2132,2174–2196,2226–2246`: current lease, unique event, exact event/outbox, stable job fields и actor subject определяют admission. Progress, dispatch snapshot и current manifest pointer не восстанавливают отсутствующий scope.
- `run_lifecycle.py:14920–14948`: `_process_control_job` игнорирует dispatch snapshot, очищает ambient identity, получает current admission и устанавливает только его scope. Admission errors дают настоящий `fail_job` до входа в payload-reader seam.
- `job_scope_admission.py:740–799`: `_install_execution_scope` очищает также `AccessScope`; `_payload_for_execution_scope` сверяет outer owner/run identity, убирает caller runtime identity и nested owner claims, сохраняя обычные candidate params.
- `job_scope_admission.py:543–565`: `_load_payload_ref` сверяет selected manifest kind/media, CAS integrity и object JSON; затем actual CAS ownership guards разрешают только допустимые bytes/profile.
- `core/artifacts/store.py:1734–1859,1876–1882,1962–1975`: tenant, полный cell, selected manifest view и typed input edge проходят разные owner checks. Нельзя заменить их одним blob hash.

## Различающие controls

| Case | Прямое наблюдение |
|---|---|
| Normal + чужой ambient `AccessScope` | Прочитан A payload. Внутри tenant A/full cell A, AccessScope отсутствует. После dispatch исходный внешний context восстановлен. |
| Поддельный dispatch snapshot (`run_id`, `payload_ref`) | Выбран прежний exact SQL job/payload; malformed dispatch pointer не читается. |
| CAS payload owned by tenant B | `ArtifactOwnershipError` на `read_raw_manifest`, JSON payload не возвращён. |
| CAS payload owned by same tenant / `12345678-cell-b` вместо `12345678-cell-a` | Тот же отказ, несмотря на общий 8-character prefix. Это CAS control, не Helm installation test. |
| A-owned payload объявляет tenant B | CAS read проходит, последующий payload-scope predicate отказывает `control_job_payload_owner_scope_mismatch`. |
| Legacy unknown scope + claimed payload | Scope остаётся `not_established`; нет tenant/cell/AccessScope; claimed read отказывает. |
| Legacy unknown scope + unclaimed payload | Payload read разрешён; outer/nested tenant, cell, runtime identity удалены. Candidate computation и authority не проверены. |
| Wrong artifact kind | `ArtifactIntegrityError`, mismatch reference/selected manifest. |
| Creation event / outbox tenant drift | Настоящий job → `failed`, `control_job_created_event_outbox_mismatch`; payload reader не вызван. |
| Mutable job payload pointer drift | Настоящий job → `failed`, `control_job_created_stable_field_mismatch`; payload reader не вызван. |

CAS/profile controls используют **одинаковые реальные JSON bytes**, один artifact ID и два manifest profiles, созданных разными tenant scopes:

- A читает A profile; B читает B profile.
- A не читает B profile на том же blob.
- Неверный полный cell и отсутствие scope отказывают.
- Derivative write с A selected input проходит; с B selected input отказывает `write input manifest:audit.source`.
- Config-only raw factory reconstruction без enforcer читает B profile. Это намеренный removal-control, свидетельствующий о причинной роли enforcement, не default Runtime path.
- Explicit tenant/cell при `backend=s3` отвергнут существующей factory до создания remote client. Настоящие S3/GCS не запускались.

## Что этот probe не подменяет

**Bounded seam:** полный `ControlPlaneService` не конструируется. Извлечены неизменённые `_process_control_job`, scope installer, payload reader/sanitizer, creation-envelope builders и `_make_artifact_ref`. Вместо всего `_process_control_job_admitted` harness выполняет только реальную последовательность generic payload read → scope sanitizer и сохраняет результат. Capability admission, workflow execution, numerical methods, domain failure publication и terminal completion после этого отсутствуют. Поэтому отказ на payload boundary оставляет fixture job `running`: это эффект намеренно обрезанного audit tail, не найденный lifecycle defect. Только два SQL admission failures действительно прошли production `fail_job` и стали `failed`.

**Restart:** creator и consumer имеют разные PID, Python object state не передавался. Все десять случаев читаются одним новым consumer process, каждый со своей SQLite/CAS root. Не было hard crash, lease takeover, concurrent multi-tenant requests или второго restart после consumer writes. Previous delivery fault matrix не переисполнена.

**Native profile:** Python 3.12.14 / Pydantic 2.13.4, а baseline требует Python 3.14 / locked dependencies. Native import воспроизводимо остановился на `core/artifacts/store.py:2155`, новом multi-except syntax. Audit loader делает in-memory multi-except и TypeVar compatibility adaptations, не меняя product bytes. 157 setup modules / 160 consumer modules, 14 setup rewrites / 16 consumer rewrites; все оригинальные hashes сохранены. Несколько eager package facades заменены namespace packages. Это не installed import qualification.

**Runtime guard boundary:** попытка полного import `runtime/http/resilience.py` остановилась на отсутствующем `opentelemetry`. Это сохранённый средовой blocker; его не заменили fake tracer/circuit breaker. Итоговая executable chain использует реальные direct CAS/SQL owners и весь `ControlWorker`, но **не GuardedDependencyProxy/ThreadPool dependency hop**. Сохранение ContextVars на этом дополнительном hop здесь только source-traced, не новый исполняемый результат. HTTP/JWT/OPA, PostgreSQL/RLS, remote backends, full typed route admission и public claim отсутствуют.

**Authorization origin:** creation scope в fixture намеренно синтетический, построенный настоящим serializer. Probe показывает custody уже записанной scope identity, а не доказательство, что внешний caller мог её законно получить или изменить. Fault writes касаются только audit-owned temporary DB. Получить SQL/filesystem admin mutation через tenant API не пытались и не утверждаем.

## Архитектурное решение и остаток

Сохранять существующих owners: Runtime creation/admission отвечает за persisted principal+job identity, worker переносит только admitted scope, Core CAS отвечает за content/profile/input custody. Не заменять эту цепочку namespace labels, ContextVars без admission или serialized storage config. Generic raw CAS допустим как внутренний capability, но его нельзя считать tenant-safe только потому, что root тот же.

Новый самостоятельный defect ID не вводится. Материал усиливает положительные контроли из `next_auth` и G06 и конкретизирует configuration boundary прежнего RR-03; STATE-01/STATE-02, policy vocabulary/served-pack drift и namespace migration остаются без изменения статуса.

Следующий acceptance: supported 3.14/locked deployment composition с настоящими guarded CAS/SQL, authenticated route-generated scope и actual worker handoff; тот же foreign tenant/full cell/profile/legacy matrix; then lease replacement, queued payload corruption и multi-request context reuse. Native computation/terminal publication должно оставаться отдельным шагом, не скрытым за payload PASS.

## Воспроизведение и provenance

Из workspace:

`PYTHONDONTWRITEBYTECODE=1 POLISYOS_AUDIT_CHAIN_ENABLED=0 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python policyos_deep_audit/next_tenant_custody/probe_tenant_custody.py`

Затем `python policyos_deep_audit/next_tenant_custody/validate_evidence.py`.

Final probe и fresh-process exits 0; stderr пусты. Native/Runtime-guard imports имеют честные nonzero outcomes. Начальные harness ошибки сохранены: eager facade dependency, отсутствие `FileSystemCAS.close`, две диагностические остановки/переорганизация import wave. Они не являются product findings. Один ранний запуск изменялся при подготовке consumer; он не используется как deciding evidence. Финальный script заморожен перед запуском, SHA-256 перепроверен после него. Повторный полный запуск использует только новые temporary fixtures; они удалены по завершении. Source/production state/deployment не менялись, зависимости не устанавливались.
