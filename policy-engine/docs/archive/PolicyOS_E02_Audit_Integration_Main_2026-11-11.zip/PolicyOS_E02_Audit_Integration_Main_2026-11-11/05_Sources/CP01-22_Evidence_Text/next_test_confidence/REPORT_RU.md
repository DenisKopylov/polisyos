# PolicyOS: достоверность tests, CI execution и design alignment

**База:** `f1541ed155f278689be48a8c7ac56c3e200210f7`. Read-only snapshot, продолжение `next_structure`. Дата проверки: 2026-11-10 UTC.

## Короткий вывод

У проекта есть сильные поведенческие тесты с реальными persisted effects, fresh readers, corruption/removal controls и восстановлением. Поэтому считать suite набором пустых mirror checks неверно. Но наличие этих tests ещё не означает, что текущие CI lanes могут их исполнить или что они доказывают production closure.

Новые существенные находки:

1. **TC-01, высокая:** nightly benchmark wrapper вычисляет неверный product root и после первого benchmark вызывает отсутствующий summary script. На неизменённом wrapper, с безопасной подменой только тяжёлого `uv` запуска, реальный Python завершился exit 2.
2. **TC-02, высокая:** три installed-profile tests попадают в обычный Fast PR checkout suite, хотя требуют импортов исключительно из installed site-packages и отдельного synthetic/native окружения. Их специальный isolated launcher существует в историческом evidence, но в действующей root CI wiring отсутствует.
3. **TC-03, высокая для воспроизводимости:** Runtime HTTP lane требует настоящий `opa`, а checked-in workflows/composite setup его не provision. Отсутствующий binary намеренно вызывает `pytest.fail`, не skip. Наличие OPA на реальном hosted runner не проверено, поэтому это подтверждённый provisioning gap, не объявленный свежий CI failure.
4. **TC-04, средняя:** из 52 явно benchmark-marked source definitions 32 не выбираются четырьмя главными Python PR selectors. Внутри этих 32 ещё 12 методов находятся в `Benchmark*` classes, не соответствующих default pytest class convention. Оставшиеся 20 обычных definitions также находятся вне Standard performance root.
5. **TC-05, средняя:** выбранный chain performance oracle пропускает выполнение, которое каждый раз бросает exception. Он измеряет время проглоченной ошибки, а не успешную работу. Это отдельный дефект assertion, не только вопрос collection.

**Verdict:** инженерная confidence в текущем CI routing частичная, readiness не подтверждена. Native Python 3.14 pytest, OPA и полный installed-profile acceptance здесь не выполнялись. Найденные configuration/measurement defects не позволяют выдать зелёный verdict. Это не доказательство дефекта всех production подсистем.

## 1. Что исполнилось и что осталось source review

- Полный именованный denominator: **3 752 tracked `policy-engine/tests/**/*.py`**. Python 3.12 разобрал 3 749; три файла с Python 3.14 exception syntax перечислены в `test_selection_inventory.json` и не считались пустыми.
- Census считает source-defined functions/methods и явные `pytest.mark` attributes. Он не является `pytest --collect-only`, не разворачивает parametrization и не считает runtime skips, динамические plugins или coverage процентов.
- Полностью прочитаны **23 файла `.github/**`**; `ci_execution_map.json` сохраняет triggers, `needs`, conditions, setup и run commands всех 12 root workflows.
- Выполнены **20 bounded observations**: 12 запусков точного aggregate shell, unchanged nightly shell с `uv`-stub, две origin assertions, missing-OPA branch, два benchmark exception controls, expired-quarantine hook, настоящий stdlib CI target gate.
- Настоящий `.github/scripts/check_declared_test_targets.py` прошёл: **23 CI files, 116 уникальных literal Python test-file references, missing=0**. Он сам обещает только существование paths. Его green не доказывает collection, dependencies, выполнение или assertions.
- Fresh environment check: Python 3.12.14, `pytest` не установлен. Базовый продукт требует Python 3.14. Никаких dependency installs, source edits, network/provider calls, git commits или CI dispatch не было.

`offline_probe_results.json` для каждой пробы указывает substitution и границу вывода. Exact-body AST execution не назван обычным import настоящего модуля или full pytest run.

## 2. CI не замыкается одним числом tests

### TC-01: Nightly benchmark path после перемещения wrapper

`tools/quality/validation/run_benchmark_contours.sh:5–7` вычисляет `REPO_ROOT` как `${SCRIPT_DIR}/../..`. Для текущего расположения это `policy-engine/tools`, не `policy-engine`. Следовательно, `BENCH_ROOT` становится `policy-engine/tools/benchmarks`.

Workflow `frontend-nightly.yml:89–93` действительно вызывает этот wrapper. В offline replay `uv` только напечатал cwd/argv и вернул 0; benchmark computation не запускалась. Следующий реальный Python получил отсутствующий `policy-engine/tools/benchmarks/build_release_summary.py` и завершился exit 2. Настоящий entrypoint есть в `policy-engine/benchmarks/build_release_summary.py`.

Это causal witness ошибки адреса, независимо от результата первого реального benchmark. Он не доказывает, что hosted workflow в действительности дошёл до этой строки: раньше могут отказать setup или benchmark. Минимальное направление ремонта: исправить существующий root owner и добавить wrapper smoke с контролем реального derived path, не создавать ещё один launcher.

### TC-02: обычная коллекция против installed-only acceptance

`test_installed_worker_profile.py` имеет три обычных top-level `test_*`, без opt-in marker/skip. `_site():56–59` требует `bridge.__file__` внутри `sys.prefix/lib/python3.14/site-packages`.

Но `tests/conftest.py:27–34` вставляет checkout `src` первым в `sys.path`; Fast PR (`abi.yml:129–132,185–186`) использует minimal profile и обычный `pytest -m "not integration and not benchmark"`. Три tests классифицируются unit и этим фильтром не исключены. Nested Foundry conftests не предоставляют installed-only isolation и не исключают файл. Extra inputs `E02_DOWHY_FIXTURE_PATH`, `E02_GCM_FIXTURE_PATH`, `E02_PROFILE_EXPECTED_JSON`, `E02_TEST_DOWHY_WORKER_PYTHON` также не заданы root workflow.

Точный `_site` body отклонил synthetic checkout origin и принял synthetic installed origin. Это подтверждает различающее условие, **не native test failure**. При стандартном source import origin эти tests не могут установить обещанное installed acceptance. Если collection остановится раньше, они вообще не будут достигнуты.

В C13 execution prompt и историческом `launch_installed.py` правильная отдельная схема уже существует: copied test carriers, isolated interpreter, конкретные worker/fixture paths. Следует состыковать её с действующей lane и явно разделить checkout tests и installed acceptance. Простое добавление skip без отдельной обязательной lane замаскирует отсутствие acceptance.

### TC-03: real OPA tests без объявленного provisioning

`test_runtime_rego_authorization_parity.py:67–75` вызывает `shutil.which("opa")` и при отсутствии делает `pytest.fail`. Это правильный fail-closed контроль: не подменять real policy engine успешной mock parity.

Standard HTTP `ci.yml:20–42` запускает весь HTTP root. Его composite action поднимает Python/uv/profile; root `.github/**` не содержит установки/проверки OPA. `setup-runtime-dashboard` тоже не объявляет OPA. Offline missing-binary branch дал именно failure sentinel с reproduction command. Реальный hosted image inventory не прочитан, поэтому не утверждается, что OPA там фактически отсутствует. Но runner image не должен служить скрытым нефиксированным supply contract. Нужны pinned OPA provisioning и version/check/test evidence в этой lane.

### TC-04: benchmark tests теряются между taxonomy и path selectors

Четыре главные Python selectors:

- Fast PR: `not integration and not benchmark`, HTTP root исключён;
- Standard HTTP: весь `tests/unit/runtime/http`, `not quarantine`;
- Standard Integration: `integration and not quarantine`, HTTP root исключён;
- Standard Performance: **только `tests/performance`**, `performance and not quarantine`.

`_infer_primary_marker` корректно делает benchmark → performance, но path restriction последней lane не расширяется от marker. Во всём разобранном tests `.py` множестве найдено 52 явно benchmark-marked definitions в десяти файлах. 20 расположены под `tests/performance`, **32 вне всех четырёх selectors**:

| Файл | Definitions | Default class convention подходит |
|---|---:|---:|
| unit/foundry/benchmarks/test_chain_perf.py | 3 | 0 |
| unit/foundry/benchmarks/test_demographic_consistency_perf.py | 1 | 0 |
| unit/foundry/benchmarks/test_method_perf.py | 8 | 0 |
| unit/foundry/benchmarks/test_registry_perf.py | 6 | 6 |
| unit/foundry/benchmarks/test_ws5_jax_perf.py | 3 | 3 |
| unit/foundry/benchmarks/test_foundry_release_gate.py | 4 | 4 |
| unit/foundry/benchmarks/test_compositional_causality_benchmark.py | 5 | 5 |
| unit/ir/test_phase3_benchmarks.py | 2 | 2 |

12 методов объявлены в `Benchmark*`, не `Test*`. В tests/config не найдено class-convention override или custom collector, который собирал бы эти classes. Это source/config finding; native collection не исполнена. Counts не являются количеством parametrized cases.

Secondary root workflows не называют эти восемь файлов/их root. Nightly `benchmarks run-all` исполняет отдельную benchmark registry, а `workspace benchmark-surfaces` только Ruff/format/shell/YAML hygiene. Ни один из этих механизмов нельзя автоматически считать исполнением именно перечисленных pytest definitions. Нельзя утверждать отсутствие иной эквивалентной продуктовой проверки: такая equivalence здесь не доказана.

### TC-05: green timing при нулевых эффектах

В `test_chain_perf.py:51–80` sync и async execution обёрнуты в `except Exception: pass`; dispatcher делает аналогично. Exact sync method replay с synthetic benchmark driver:

- successful implementation: 6 attempts, 6 effects, assertion passes;
- always-raising implementation: 6 attempts, **0 effects**, assertion passes.

Timing driver намеренно задаёт малое время; это не performance measurement, а доказательство того, что assertion не различает успешную работу и быстрое исключение. Порог времени должен дополняться независимым success/result oracle; exceptions должны оставаться видимыми. Нужны оба ремонта: collection/routing и смысл assertion.

## 3. Какие сквозные contracts действительно поддержаны tests

Матрица с точными test names и ограничениями: `contract_matrix.json`. Здесь различаются **качество написанного теста** и **его свежий успешный запуск**; второе не установлено.

### A. Public verification: HTTP → ownership → redacted projection → CAS signature → anonymous read

`test_owned_run_packet_is_redacted_issued_and_publicly_verified` проходит настоящий issuance route и публичный read. Проверяет `projection_only`, `public_redacted_projection`, `promoted_record=None`, все authority dimensions `not_established`, cache-control. Затем повреждает реальную persisted signature sidecar и требует invalid/no public document. Есть separate foreign-run/client-document refusal и changed-source-bytes refusal. Соседний pending-signature test прерывает публикацию и проверяет, что protected surface блокируется, а unrelated candidate data остаётся читаемой.

Это значимые corruption/effect controls, не просто DTO construction. Но `_AllowOPA` и synthetic identity fixtures означают, что такой HTTP test **не доказывает real OPA decision parity**. Её проверяет отдельный suite из TC-03.

Alignment: ratified `PV-K01–03` прямо разделяют authenticity и current authority. Tests здесь корректно **не** выдают валидную подпись за governed policy recommendation.

### B. Custody: signed report inventory не равен governed published population

Unit tests в `test_published_signature_custody.py` действительно издают/проверяют signed reports. Настоящий пустой issuance slot и настоящий signed inventory без governed binding остаются `not_established`; corruption меняет reason и authentication при сохранении негативного authority outcome. Missing population не может стать watched через подстановку marker/status/count. Lifecycle publisher в негативных controls бросит ошибку при любом запрещённом вызове.

Integration `test_every_public_signature_is_watched_for_staleness` использует synthetic `StaticPublicSignaturePopulationProvider`, persisted claim ledger/decision packet, SQLite service и проверяет lifecycle/outbox evidence. Unappointed provider даёт nonreceipt без all_clear. Это проверяет advisory bridge при заданной population, **не** доказывает complete production population denominator, sovereign appointment или scheduled lifelong custody. Имя test с «every» нельзя расширять за его synthetic input.

Alignment: signature rule является product obligation; текущие nonreceipt tests честно соблюдают candidate/authority boundary. Они не свидетельствуют, что вся эта обязательная будущая capability уже закрыта.

### C. Authorization: server action/resource sealing и real Rego decisions

Parity suite проверяет canonical permission vocabulary, live guarded router resource contracts, exact sealed OPA input, mutation mismatch, principal/operation/resource decision matrix и actual handler effect counter. Это сильнее проверки «в enum есть название».

Audience-denial suite отдельно поднимает authenticated principals без нужных permissions и вызывает reviewer/expert operations напрямую. Проверяется 403 и отсутствие OPA call при раннем permission denial. Но module docstring честно называет это **proxy** до final PUBLIC/REVIEWER/EXPERT/MACHINE mapping. Финальная audience bridge не установлена этими tests. Оба HTTP suites source-selected Standard lane; real reachability остаётся зависимой от profile/OPA setup.

### D. Saturated compute: cancellation publication, не физический stop

`test_authenticated_cancellation_advances_while_compute_is_saturated` запускает отдельный process с реально занятыми worker/queue, проверяет renewal, durable cancellation event/outbox exactly once, fresh HTTP readback, late progress/manifest/terminal refusal. В oracle **явно требуется `physical_stop_status=not_established`**, `publication_fenced`. Это полезное честное покрытие durable cancellation при saturation, но оно не опровергает shutdown witness предыдущего `next_lifecycle`.

Соседний service-capacity suite имеет настоящий removal control: routing control operations к saturated compute обязан сломать тот же persisted-renewal oracle. В C96 toggle removal передаётся environment; штатная root workflow его не задаёт. Поэтому default C96 run и самостоятельный forced-removal rerun следует хранить как разные evidence, а не предполагать, что CI автоматически делает оба.

### E. Epoch owner propagation и tenant custody

`test_epoch_issuance_composition.py` покрывает propagation exact concrete owner через runtime container/control service в legacy launch. Сам `run_experiment` заменён capture function: downstream scientist execution этим case не исполнена. Отдельный provenance test использует настоящий CAS ownership, проверяет отказ cross-tenant read и возможность current tenant verifier provenance; inventory test разделяет issuance sets между tenants.

Это сильная composition/isolation проверка при bounded fixture, не полная production epoch issuance/cascade authority. Нельзя объединять отдельные positive objects в якобы непрерывный e2e pipeline без отдельного запуска.

### F. Installed method/report/fresh reader contract

Installed suite проверяет public helper identity/pickle, настоящий subprocess worker, persisted report/evidence, независимый OLS point estimate, fresh isolated reader и removal/restoration `worker.py`. Это хороший native/package falsifier по замыслу. Однако именно required execution profile и fixture materialization делают TC-02 существенным: обычный checkout run не является заменой этому тесту. Исторические recipe/receipts не перенесены как свежий PASS данного pin.

## 4. Aggregate gates и quarantine: полезные контроли плюс ограниченные риски

Точные shell bodies Fast/Standard прогнаны по шести состояниям каждый:

- все success → exit 0;
- failure/cancelled в общем results → exit 1;
- schema-snapshots (Fast) или frontend-unit-coverage (Standard) skipped/missing → exit 1;
- иной skipped при protected success → exit 0.

Значит, checks специально защищают две named measurements. Общая агрегация не требует success каждого dependency. Но **не доказан текущий достижимый all-green bypass**: обычный predecessor failure присутствует в `needs` и ловится общим failure check, а некоторые Fast jobs намеренно skipped на push. Это bounded hardening observation, не новый подтверждённый production exploit. Existing `test_schema_snapshot_workflow.py` уже прогоняет exact shell негативными cases; такой owner следует расширять по реальному риску, не заменять string-match tests.

Quarantine registry в данном pin пуст. В exact hook synthetic expired entry с датой 2000-01-01 всё равно получает skip. `_load_quarantine_entries`/header умеют перечислять expiration; economics report её показывает; Playwright validator проверяет tags/selector correspondence, но не истечение. Поэтому policy «temporary until re-entry» пока не подкреплена обязательным expiry gate. Это **TC-06, низкая, latent**: сейчас ни один реальный test не скрыт этой registry, и active de-gating defect не заявляется.

## 5. Documentation alignment

- `tests/TESTING_POLICY.md` верно называет `pytest.ini`, taxonomy и benchmark→performance. Его dedicated command `pytest -m performance` шире действующего Standard root restriction. CI naming нельзя читать как «все performance tests». Это implementation/policy routing gap.
- `CONTRIBUTING.md` marker registry/slow drift уже установлен в `next_structure`, здесь не выдаётся за новую находку. Актуальны `pytest.ini`/root conftest, не устаревшая таблица.
- `docs/reference/quality-gates.md` корректно отличает checked-in workflow role от GitHub-side enablement/run evidence. Этот аудит следует тому же ограничению. Ни live ruleset application, ни branch protection, ни remote CI result здесь не проверены.
- PV ratification прямо запрещает использовать design record как capability claim. Public verification/custody tests с nonreceipt этому соответствуют; сам документ не восполняет missing governed population producer.
- C13 execution prompt верно требует isolated installed interpreter, fixture hashes и explicitly unestablished environments. Именно ordinary root CI collection конфликтует с этой необходимой схемой. Исторические handoffs не являются дополнительным текущим workflow.
- P33/P38 требуют distinguishing property controls, P35 полного denominator, P41 доказанной provenance reds. Здесь benchmark exception negative и shell path witness являются controls, census именован, attribution «inherited» не сделана: pre-change исторического replay не было.

## 6. Рекомендуемые bounded исправления, не выполнены

1. Исправить derived root у существующего nightly wrapper; добавить path/control smoke, затем один actual nightly lane run на pinned окружении.
2. Отделить installed-only tests explicit selector/lane; materialize четыре declared inputs и выполнить isolated wheel/rebuilt-sdist reader/removal controls. Сохранить сам сильный oracle, не ослаблять `_site`.
3. Provision pinned OPA в runtime-http lane; выполнить реальную Rego matrix и control с отсутствующим/некорректным engine.
4. Согласовать performance selectors с taxonomy, сначала подтвердить `--collect-only` denominator и исправить Benchmark* class discovery. Существующие performance owners предпочтительнее нового test framework.
5. Убрать swallowed errors из performance oracles, проверять actual outputs/effects до timing assertion; добавить always-failing discriminator.
6. На поддерживаемом Python 3.14 и locked deps получить actual collected/selected/skipped/failed manifests по lanes. До этого отсутствие локального native результата не заменять counts или historical logs.

## 7. Артефакты и воспроизводимость

- `REPORT_RU.md`: этот вывод.
- `contract_matrix.json`: requirement → конкретный test → observation/control → lane → предел.
- `ci_execution_map.json`: полный source execution map root CI.
- `test_selection_inventory.json`: полный tests `.py` denominator, unresolved syntax files и все 52 explicit benchmark definitions.
- `offline_probe_results.json`: все 20 observations с stdout/stderr и substitution.
- `source_excerpts.json`: exact решающие excerpts, path/line/SHA-256.
- `SOURCE_VALIDATION.json`: каждый прочитанный и использованный path сверяется с pin baseline; это не semantic acceptance всех этих files.
- `probe_test_confidence.py`, `write_evidence.py`: повтор offline probes и сбор evidence. Source остаётся неизменным.

Повтор: `PYTHONDONTWRITEBYTECODE=1 python policyos_deep_audit/next_test_confidence/probe_test_confidence.py`, затем `write_evidence.py`. Summary outputs/temporary directories находятся только в `next_test_confidence`. `git status --porcelain` после probes пуст.

**Этот bounded pass завершён. Весь глубокий аудит, production readiness и remediation не объявлены завершёнными.**
