# PolicyOS: Clerk workflow, UI state ownership и reuse boundaries

База: `f1541ed155f278689be48a8c7ac56c3e200210f7`, 2026-11-11 UTC. Source read-only. Продолжение checkpoint14; новые outputs только в `next_ui_ownership`. Это целевой архитектурный/поведенческий проход, не повтор FE-01…FE-06 и не утверждение о готовности всего frontend.

## Главное

1. **UI-01, P2:** жизненный цикл Clerk launch/stream не принадлежит конкретной conversation/identity generation. Поздний accepted result после reset создаёт старую subscription и возвращает old currentRunId. SSE error разблокирует UI, оставляя поток открытым; terminal event старого потока во время нового launch сбрасывает streaming нового. Полное тело actual hook исполнено под Node24 с явно перечисленными seam fixtures.
2. **UI-02, P3:** Clerk history смешивает failed/empty состояния и не маркирует retained data при refetch error. Соседний analyst list уже использует существующий `AsyncSection`/`ApiErrorAlert`. Global 403/500 incident banner частично смягчает проблему; это не доказанная утечка и не утверждение, что ошибок нигде не видно.
3. **UI-03, P3:** объявленный `api → no features` boundary не проверяется custom checker, dependency-cruiser или включёнными ESLint boundary rules. Два production imports действительно пересекают его, один runtime, один type-only. Точный policy function пропускает оба; negative controls других правил отклоняются. Full architecture command не дошёл до scan: отсутствует `typescript`, это environment blocker, не production-red.

**Verdict:** PARTIAL для workflow; воспроизведён bounded failure UI-01, source/decision-level подтверждены UI-02/03. Node22, React/Vitest, native EventSource/browser, реальный сервер и CI **UNRUN**. Нельзя описывать Node24 probe как прохождение authored tests.

## 1. Выбранный workflow и его реальные владельцы

Основной consumer существует: `app/routes/ModeAwareHome.tsx` динамически импортирует `ClerkChatPage` через `features/clerk/routes.public`; `ModeAwareRunsList` аналогично подключает `ClerkHistoryList`. Это не dead component или reference shell.

Цепочка:

- **Identity:** `AuthzProvider → ClerkChatPage.settledIdentity → IdentityBoundChat → hydrateChatStoreForIdentity`. Page делает keyed remount и hydration до показа ChatContainer. Unknown/error identity не отображает chat. Это полезная уже реализованная защита.
- **Launch:** `ChatContainer → useClerkNlRun → composer/public buildNaturalLanguageLaunchRequest → api/hooks/useLaunchNlRun → openapi-fetch/generated types → POST /api/v1/control/runs/nl`. Recovery scope содержит tenant/cell/user; stable key ownership остаётся в уже существующем recovery repository. Этот механизм не переоценивался и не предлагается заменить.
- **Live:** `useClerkNlRun → app/realtime/SseRealtimeTransport → new EventSource(..., withCredentials:true) → GET /runs/{run_id}/live`. Это другой transport, не generated class и не `authAwareRuntimeFetch`.
- **Producer:** `runs.py:7819–7863` проверяет tenant access и регистрирует data access; `:6408–6440` строит `RunDetailSnapshot`; `channel_contracts.py:62–88` задаёт versioned strict payload. Route намеренно `include_in_schema=False`. Следовательно, отсутствие этой операции/DTO в generated OpenAPI client не является само по себе drift defect.
- **Local presentation/history:** singleton `useChatStore` хранит live messages, currentRunId/isStreaming и отдельные saved sessions. `ConversationHistorySearch` вызывает load/new/delete. `ExportConversation` создаёт local Blob из текущих messages, не публикует файл на сервер.
- **Server history:** `ClerkHistoryList → useRuns → GET /api/v1/runs → runsListSchema`. Это server list, а не local conversation search. Их одинаковое бытовое название «history» не повод объединять различную persistence/authorization семантику.

Directory census содержит **1160 code files** под dashboard/src и **33 code files в Clerk, из них 10 test files**. Это полный файловый denominator указанного поддерева, не 1160 полностью проверенных файлов. SOURCE_VALIDATION сверяет **63 deciding files** с exact Git bytes; все совпадают. OWNER Clerk/runs/artifacts указывает team-frontend; API authoring contract называет team-runtime backup.

## 2. UI-01: initial identity binding не отзывает старую async работу

Primary: `features/clerk/hooks/useClerkNlRun.ts:33,37–47,64–125,140–144`.

Hook хранит одну `sseRef`, но не регистрирует `useEffect` cleanup, не захватывает conversation generation, не проверяет актуальность scope после `await mutateAsync`. Store callbacks работают с глобальным состоянием, а не с принадлежащей конкретной беседе сессией. Только message update привязан к systemMsgId; изменения `isStreaming/currentRunId` глобальные.

Реальные state transitions проходят мимо этого владельца:

- `useChatStore.ts:436–445` loadSession сбрасывает streaming/runId;
- `:498–507` newSession после successful autosave делает то же;
- `:523–545` identity hydration очищает live state;
- `ConversationHistorySearch` не получает busy/disabled guard для load/new; ChatContainer оставляет history доступной во время live run.

### Исполненные различающие случаи

`CLERK_LIFECYCLE_RESULTS.json`:

- **Positive:** accepted → novel status с null finished_at не завершает run; настоящий непустой finished_at завершает presentation и закрывает subscription. Rejected launch и transport rejection не фабрикуют run lifecycle.
- **Late acceptance:** после controlled reset, пока launch pending, messages/currentRunId очищены. Поздний accepted ставит old runId и открывает SSE, при пустых messages и isStreaming=false.
- **Open-stream interleaving:** accepted A → SSE error A оставляет subscription открытой, currentRunId=A, isStreaming=false → submit B ставит true → terminal snapshot A до acceptance B сбрасывает state → accepted B выставляет currentRunId=B, но streaming остаётся false. A event приходит **до close**, не используется сомнительное предположение о событии уже закрытого EventSource.
- **Residual:** сообщение с другим run_id принимается как состояние subscribed run, потому что hook читает только status/finished_at. Actual backend привязан к route run, поэтому это contract-validation gap, не доказательство server misrouting.

Reachability уточнение: новый launch B должен быть разрешён admission recovery и online policy. Пока старый intent unresolved, changed body корректно блокируется (`controlPreAdmissionRecovery.ts:649–704`). Но valid producer-attested admitted observation освобождает idempotencyKey (`:556–575,882–900`) до завершения самого анализа, поэтому этот guard не является lifecycle fence всех live callbacks. Probe подставляет successful B и не проверяет реальный admission/server.

Probe исполняет полный source hook после удаления только imports и TypeScript erasure. React hooks, auth/profile/launch/form functions, minimal store port и SSE port подставлены. **Actual Zustand persistence, React lifecycle/unmount, browser reconnection и backend здесь не исполнены.** Отсутствие cleanup подтверждено чтением полного hook; последствие unmount в браузере остаётся отдельной проверкой.

### Impact и граница privacy

Пользователь может увидеть пустую новую conversation со старым activeRunId, потерять progress indication для нового анализа или оставить ненужный live connection после ухода. Error не означает server cancellation; recovery/idempotency не отменяют UI ownership bug и не разрешают безопасный новый execution автоматически.

Initial tenant/user hydration защищена и не опровергнута. В probe старые тексты не воскресли: update отсутствующего systemMsgId ничего не добавляет. Нет доказательства cross-tenant disclosure, backend auth bypass, повторного фактического исполнения или production incident. Реальная серверная authz при новом stream open по-прежнему применима.

**Bounded repair:** feature-local launch/conversation generation или scoped activity token, retirement на load/new/delete-active/identity change/unmount; проверки перед publication accepted/error и каждого callback; закрывать именно захваченную subscription. Разделить состояние подключения и состояние analysis. При потере транспорта оставлять honest unknown/degraded и существующий recovery path, не объявлять задачу finished и не посылать cancellation. Не переносить launch state в новый глобальный framework.

## 3. UI-02: reuse error-state owner отсутствует в Clerk list

Primary: `ClerkHistoryList.tsx:8–20,36–60`, `api/hooks/useRuns.ts:28–80`.

В list проверяется только isLoading. Затем `data?.runs ?? []`: initial error идёт в welcome/empty branch, retained success data + isError идёт в обычный список. Нет local error/retry/staleness presentation. Source expression probe различает initial error, retained-data error и empty success; первые/последние дают одну empty branch. Это source-decision evidence, **не реальный React Query transition**.

Ограничение вывода: `createRuntimeApiError` эмитит события 401/403/5xx, RuntimeApiProvider перенаправляет 401 и показывает incident для 403/5xx. Поэтому нельзя писать «403 полностью скрыт». Fetch rejection и validation failure не обязательно проходят этот event path. Global banner не заменяет local состояние списка и не убирает retained rows.

Существующий reusable owner уже есть: `packages/atlas-ui/src/primitives/AsyncSection.tsx` проверяет error до empty/children; analyst `RunsListPage.tsx:659–670` использует его с `shared/ui/ApiErrorAlert`. Нужен такой же локальный error boundary/adapter, не второй bespoke list-state reducer. Для offline/retained data требуется явная продуктовая политика: показывать historical с label или скрывать, особенно после denied read. Не объявлять любую кешированную run summary «authority» и не расширять finding до недоказанной утечки аккаунтов.

Отдельный residual, не новый defect: Clerk показывает `limit:20` и не использует next_cursor. Нужно назвать это recent list либо подключить уже существующий pagination contract, если требуется полный archive. В этом проходе completeness requirement для этой lite surface не установлен.

## 4. UI-03: owner rules и enforcement расходятся

`src/api/AUTHORING.md` запрещает API code зависеть от features. В production найдены:

1. `src/api/validators.ts:11 → features/runs/domain/runExecutionHte` (runtime import), а этот helper импортирует artifacts domain private helper.
2. `src/api/hooks/useBureaucraticRender.ts:12 → features/artifacts/bureaucratic/ast/bureaucratic-document-ast` (type-only).

Точный `validateImport` в `scripts/check-architecture.mjs:176–246` не имеет правила api→features. Policy-only probe вернул null для обоих. `.dependency-cruiser.mjs` такого запрета не содержит; ESLint `boundaries/element-types`, `no-private`, `no-unknown` выключены (`:105–109`). Это ограниченный пробел enforcement, не доказательство полного ложного PASS architecture command.

Counterexamples: shared→features и app-state→provider отвергаются; public clerk→composer/index разрешён по делу. Actual `ChatContainer.tsx:17` импортирует `runs/components/ControlPreAdmissionRecoveryNotice` напрямую, и policy правильно возвращает `feature-no-cross-feature-internals`. Не нужно создавать ещё одно правило там, где уже существует корректное.

**Bounded repair:**

- Если run HTE parser действительно wire validator, перенести минимальную чистую parsing часть в существующую API/domain границу и оставить view-model mapping внутри feature. Если это display adapter, validator не должен её импортировать. Не менять его semantic assertions ради directory cleanliness.
- Для `BureaucraticGenre` использовать canonical API/shared type owner и type re-export при необходимости, без дублирования enum.
- `ControlPreAdmissionRecoveryNotice` экспортировать через runs public barrel либо передавать уже owned component через composition. Не перемещать feature-aware recovery UI в universal atlas-ui.
- Дополнить существующий custom/dependency policy точным api→features запретом; negative control должен упасть на runtime и type-only imports, а разрешённый API→shared/generated оставаться green. Никакого нового architecture framework или ещё одного реестра.

Native `node scripts/check-architecture.mjs --format=json` под Node24 завершился exit1 на отсутствующем `typescript` **до scan**. Ни этот blocker, ни старый README о нарушениях не доказывают результат сегодняшнего полного gate.

## 5. Reuse и generated-boundary решения

- Сохранить `@polisyos/atlas-ui` для Button/Card/Badge/AsyncSection, local shared для RuntimeApiError presentation и AuthoredText, Clerk для conversation UI/state. Shared primitives не должны знать launch permissions, tenant scope или API routes.
- Сохранить общий composer request builder и recovery repository. Не строить второй launch/idempotency механизм для Clerk и не лечить races очисткой server records.
- Сохранить `app/realtime` transport. `useRunLiveUpdates` уже делает subscription cleanup и проверяет parsed.runId. Reuse этого pattern полезен, но сам hook нельзя просто вызвать в Clerk: он инвалидирует query caches и не ведёт conversation state.
- Один effect-free event decoder рядом с existing realtime owner может разделяться consumers. Сейчас `parseRunsLiveEvent` живёт в app/providers и не переносит finished_at/версию/run_terminality как complete typed channel. Если его расширять/перемещать, сохранить необходимые поля и sibling consumers; не обещать, что нынешний parser уже решает всё.
- SSE намеренно вне OpenAPI; проверить его отдельную versioned wire boundary, а не объявлять generated clients виновником UI-01. Для cookie/Bearer auth profiles требуется native acceptance: EventSource использует credentials, не общий fetch-refresh wrapper. Deployment failure в этом проходе не доказан.
- Local session codec имеет строгий allowlist, tenant/user envelope, fixed 24h issuance TTL, максимум 50 persisted sessions и rollback storage failure. `runStatus`, verdict и live progressive поля исключены; producer finished_at сохраняется. Это positive source evidence. Не объединять conversation local storage с React Query server cache и не трактовать local bytes как authority.
- ExportConversation локален: здесь не обнаружена автоматическая внешняя отправка. Экспортирует candidate structured content текущей беседы, это не authority/MACHINE proof из FE-06; browser download correctness и full field parity не исполнены.

## 6. Tests: что уже есть и чего они не доказывают

В Clerk 10 colocated test files. Полный список и literal titles в DIRECTORY_CENSUS.

- `useChatStore.test.ts`: identity isolation, strict envelope/TTL, forbidden fields, failed save/delete rollback, cap50, hostile storage/getters. Valuable retention tests; live hook не запускается.
- `ClerkChatPage.test.tsx`: binding before hydration, tenant/user changes, hostile getters. **ChatContainer mocked**, значит реальный pending launch/SSE не пересекает tested boundary.
- `useClerkNlRun.test.tsx`: principal scope, launch rejection, unknown status, whitespace finished_at. Launch/SSE mocked, нет lifecycle generation/unmount/reconnect/history-transition cases.
- `ChatContainer.test.tsx`: основная orchestration/hooks/history/export mocked, это shell presentation test.
- `ClerkRunStatusSurfaces.test.tsx`: neutral unknown statuses и stable-selector refusal для summary. Нет ClerkHistoryList initial error/retained error.
- Existing Playwright control-quality/failure/resilience journeys проверяют `run_id:null + controlJobId` diagnostics ветку. Visual Clerk test проверяет shell. Они не закрывают accepted run → SSE → active conversation replacement chain. Browser tests не запускались.

Следующий bounded acceptance: один supported Node22/frozen workspace, настоящий renderHook+Zustand и controlled EventSource. Cases: late success/failure после identity/history/unmount; live error→reconnect; old terminal during new pending launch; active history delete; two concurrent submits; missing/invalid/mismatched event identity; retained history+403/network/parse failure; preserve existing envelope/idempotency controls. После этого отдельный real backend SSE test для version/auth profile и browser navigation/Back/Forward. Не запускать весь frontend backend suite вместо этих различающих сценариев.

## 7. Исполнение и integrity

- `probe_clerk_lifecycle.mjs`: exit0, 6 observations: 3 positive controls, 2 reproduced defect cases, 1 residual corruption case. Green probe означает ожидаемый defect/controls reproduced, не green product.
- `probe_ownership_boundaries.mjs`: exit0, 6 policy pairs и 3 query-state selection cases. Exact functions/expression, не AST/compiler/React execution.
- Native dashboard architecture: exit1 **BLOCKED** missing typescript. Node22/Vitest/typecheck/build/full lint/dependency-cruiser/browser/server: **UNRUN**.
- Первое исполнение нашего probe остановилось до product test из-за неверного ожидаемого числа import declarations (9 вместо 10). Исправлен только audit harness assertion; исходный failure сохранён.
- 63 selected files совпадают с commit; initial `git status --porcelain` пуст. Никаких source/lock edits, installs, commits, network API mutations, production data access или browser запуска.

Полезные файлы: FINDINGS.json, FLOW_AND_TEST_MATRIX.json, OWNERSHIP_REUSE.json, DIRECTORY_CENSUS.json, SOURCE_EXCERPTS.json, SOURCE_VALIDATION.json, оба probes/results, raw execution logs и SHA256SUMS. Findings scoped; unresolved whole-system/cross-browser readiness не переименована в завершённый аудит.
