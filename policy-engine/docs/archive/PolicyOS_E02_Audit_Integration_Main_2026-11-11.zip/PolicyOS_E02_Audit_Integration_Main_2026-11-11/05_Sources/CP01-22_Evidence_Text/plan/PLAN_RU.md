# PolicyOS: план углублённого системного аудита

**Дата:** 10 ноября 2026 года, UTC.  
**Статус:** план дальнейшей проверки; первоначальная фиксация базы завершена, тематические исследования начаты. Это не итоговый отчёт, не план уже выполненных исправлений и не подтверждение готовности продукта к выпуску.  
**Режим:** read-only для продуктового кода, рабочих данных, E02, deployment и удалённых refs. Новые измерители, синтетические данные и отчёты располагаются вне исходного дерева.

## 1. Цель и ожидаемый результат

Углубить прежний аудит там, где машинная карта и локальные контрпримеры ещё не дают ответа о реальном владельце операции, долгоживущем поведении, возможности безопасного переиспользования и качестве защиты контрактов. Приоритеты:

1. **Ownership:** кто владеет состоянием, физической работой, транзакцией, доказательством и их завершением; где ответственность только переименована или разнесена по файлам.
2. **Scaling:** как растёт стоимость чтения, поиска, повторного вычисления, удержания памяти и координации при увеличении корпуса, истории, числа tenants и времени жизни процесса.
3. **Reuse:** какие существующие owners и библиотеки можно использовать повторно без потери семантики, identity, recovery и authority; какие совпадения следует намеренно сохранить.
4. **Структура, тесты и документация:** какие границы действительно защищены, что проверяют тесты, какие документы являются актуальным контрактом или машинным входом, что попадает в поставку.
5. **Free-grow:** становится ли корректно добавленный ресурс обнаружимым и исполнимым без правки кода и не подменяется ли это ручным перечнем или декларацией readiness.
6. **Интеграция:** существует ли полная цепочка от typed contract и producer до persisted evidence, consumer, проверки и публичной поверхности; где isolated helper result не подтверждает эту цепочку.

Результат должен дать не ещё один общий framework и не рейтинг по LOC, а небольшой ранжированный набор доказанных корневых механизмов, ограничения применимости, решения по переиспользованию и проверяемую программу дальнейших изменений. Исполнение этой программы не входит в данный аудит.

## 2. Зафиксированная база и наследуемые результаты

### 2.1 Идентичность

- Репозиторий: `https://github.com/DenisKopylov/polisyos`.
- Commit: `f1541ed155f278689be48a8c7ac56c3e200210f7`.
- Git tree: `29890b967236a8f07e2b0f92a0133ee36883ac49`.
- Исходный архив: `PolicyOS_System_Audit_Final_2026-11-10_f1541ed.zip`.
- Распакованный прежний аудит: `/workspace/scratch/91929078ca31/policyos_audit_gap_review/extracted/PolicyOS_System_Audit_Final_2026-11-10_f1541ed`.
- Read-only snapshot: `/workspace/scratch/91929078ca31/policyos_deep_audit/source`.
- Рабочая область новых результатов: `/workspace/scratch/91929078ca31/policyos_deep_audit`.
- Контрольное чтение remote началось **2026-11-10 19:15:23 UTC**, полная материализация дерева завершена **19:17:15 UTC**. По сохранённому сравнению main совпадал с прежней базой: 0 новых коммитов и 0 изменённых файлов. Это наблюдение на указанное время, не утверждение о текущем состоянии main в будущем.

`baseline/BASELINE_RU.md`, `baseline/provenance.json`, `baseline/tree_manifest.json` и `baseline/snapshot_files_sha256.json` являются первичными материалами для идентичности нового исследования. Все 29 934 tracked файла материализованы и проверены; у snapshot сняты write bits. История shallow, поэтому из неё нельзя честно выводить долгосрочный churn/co-change. Локальные незакоммиченные изменения пользователя, ignored caches, живые ledgers и процессы в этот snapshot не входят.

### 2.2 Что не нужно делать заново

Прежний архив уже содержит полный tracked census, Python/TS syntax inventory, карту выбранных границ, 41 решение по семействам повторов и 12 семейств SYS-01…SYS-12. Они используются как вход, а не пересоздаются ради новых чисел.

- Прежние 26 AUD IDs и 12 SYS-семейств не являются двумя независимыми списками дефектов.
- Прежний Python denominator: 8 555 `.py/.pyi`, 8 537 квалифицированных parses и 18 unresolved исторических fragments. Все 2 895 current `.py` и 5 `.pyi` учтены соответствующим слоем.
- Прежние 1 340 TS/JS syntax AST, включая 733 TSX, не заменяют compiler resolution, typecheck, linking, build или UI semantics.
- Прежние 475 exact и 592 normalized clone groups не были полностью семантически adjudicated. 41 family disposition не следует выдавать за разбор каждого raw-кластера.
- Прежняя boundary-карта 214 nodes / 240 typed edges и 50 overlapping units не является универсальным call/runtime graph.
- Метаданные E02 и исторический PASS не подтверждают живое состояние задачи или действительность права повторить физическую работу.

Следующий проход должен увеличивать **глубину доказательства**, а не автоматически повторять существующую перепись. При изменении SHA проводится явный delta-проход по затронутым механизмам и consumers; результаты разных баз не смешиваются.

### 2.3 Состояние начатых исследований

На момент подготовки плана присутствуют следующие промежуточные материалы. Это входы для проверки, не принятые окончательные finding IDs:

| Материал | Что уже наблюдалось | Следующее необходимое подтверждение |
|---|---|---|
| `ownership/evidence/worker_shutdown_results.json` | В точечном replay реальный `ControlWorker.stop()` возвращается при живом handler thread; worker row меняет состояние и последующий heartbeat возвращает его в running. Idle negative control останавливается. | Проверить production callers и обещание shutdown, различить worker-row lease и job lease, проследить fence/admission/late completion. Не объявлять из этого доказанный double execution. |
| `scaling/initial_results.json` | При синтетическом churn сохраняются 1k/10k/50k limiter buckets; issued-record graph удерживает payload до освобождения owner. | Доказать lifecycle и достижимость из обслуживаемого пути, повторить серии и cleanup controls. Это не production RSS и не доказательство leak при любом сценарии. |
| `reuse/memory_identity_results.json` | При source extraction на Pydantic 2.13.4 одноимённые nominal DTO из двух модулей различаются; cross-model validation отказывает, dict bridge проходит. | Воспроизвести на locked/native profile и настоящих imports/callers. Совпадение wire payload не означает identity; текущий probe не запускал реальную revocation. |
| `reuse/numeric_adapter_results.json` | Конечные logsumexp примеры близки библиотечным; infinity/empty semantics отличаются. Для одного Ljung–Box witness provider fallback меняет решение относительно 0.05. | Проверить разрешённый input envelope, optional-provider policy и consumer. Не превращать запрещённый upstream input в admitted product defect и не объявлять полную заменяемость kernels. |
| `structure/probe_structure.py` и `structure/evidence/structure_probes.log` | Подготовлен точечный анализ helper topology и mirror-contract tests; сохранённая ранняя попытка завершилась ошибкой измерителя при unresolved parse. | Исправить/квалифицировать только внешний измеритель, явно учесть unresolved файлы и получить новый выход. Старый traceback не является падением native product gate. |
| `scaling/probe_scaling.py` | Подготовлены дополнительные серии для run index, validity и history/predictor. | До появления проверенного результата и exit status не считать серии выполненными; пустой stdout не означает PASS. |

Финальный отчёт обязан ссылаться на принятую версию каждого результата и сохранять существенные исправления трактовки. Фактический статус может обновляться в тематическом отчёте без переписывания исходного evidence.

## 3. Общие правила и границы

### 3.1 Что входит

- Все 25 current product roots получают явный статус глубины проверки; приоритетный semantic drill-down сосредоточен на перечисленных ниже потоках.
- Отдельные знаменатели для `src`, `tools`, `tests`, frontend/apps/packages, архитектурных контрактов, документации, generated/evidence families, release/ops и installed distribution.
- Static source tracing, чтение тестов и contracts, bounded synthetic probes, differential/property/fault controls, локальные временные файлы и процессы без продуктовых side effects.
- Выборочная native/locked qualification, если доступна подходящая среда и проверка не запускает реальные E02, внешние оплачиваемые providers или изменяющие deployed state операции.

### 3.2 Что не входит без отдельного решения

- Исправление продукта, перемещение файлов, обновление зависимостей, commits/push/PR, изменение CI или принятых architecture baselines.
- Запуск или продолжение E02/N5 numerical jobs, live acquisition, внешние provider calls, публикация claims, изменение CAS/ledgers, реальные cluster/DB migrations.
- Массовое удаление исторической документации или evidence, «очистка» active данных и сброс жизненного цикла через `clear()`.
- Обещание полного scientific validation, production capacity, penetration-test результата или отсутствия ошибок во всём репозитории.

При неизвестном исходе физической операции повтор запрещён до reconciliation. Старое разрешение, label, fixture или записанный lease не подменяют актуальную authority.

### 3.3 Стандарт доказательств

У каждой проверки фиксируются commit, source hashes, точные definitions/line spans, входы/seed, версия среды и библиотек, команда, exit code, результат, ограничения и отличающий negative control. Source-extracted function, synthetic collaborator и реальный product import отмечаются раздельно.

Ступени уверенности:

1. `indexed_only`: учтён файл/edge, семантика не установлена.
2. `source_traced`: прочитан producer и consumer, прослежены состояния и ошибки.
3. `bounded_probe`: локальный контрпример или подтверждение при явно ограниченном профиле.
4. `native_targeted`: выбранный путь проверен на поддерживаемых версиях/locks.
5. `installed_integration`: проверен установленный пакет и сквозной consumer.
6. `deployed_observation`: отдельное наблюдение реальной среды, если оно разрешено и получено; не выводится из предыдущих ступеней.

Эти статусы отражают разные измерения и не должны сворачиваться в единый «coverage %». Кроме них обязательны `UNRUN`, `BLOCKED`, `REJECTED` и `OUT_OF_SCOPE` с причиной. Severity и confidence хранятся отдельно.

### 3.4 Канонические правила продукта

В начале каждого механизма читать относящиеся разделы `AGENTS.md`, `policy-engine/CONTRIBUTING.md`, identity/custody boundary, failure-pattern register и существующий owner contract. Использовать последовательность **wire-existing → extend-existing → consolidate-existing → build-new**.

Ownership классифицируется по одной плоскости: external institutional act → evidence emission → receipt/verification/admission → реакция на scoped claim → public projection. Решение `own / integrate / observe / out_of_scope` не выводится из расположения файла. Не создавать новый sovereign subsystem для функции, которая должна входить через typed integration contract.

Для claims сохраняются статус, scope, provenance, schema/rule version, time roles, content binding и verifier provenance. Unknown в candidate band допустим как объявленное ограничение; он не должен незаметно становиться authority. Не оптимизировать freshness или custody ценой удаления fence.

## 4. Рабочие направления

### A. Ownership и жизненный цикл

**Основной вопрос:** у каждого перехода состояния и side effect есть один действительный owner с правом выдачи, проверкой действительности, терминальным переходом и восстановлением?

**Первичные входы:**

- `src/polisyos/runtime/http/services/control_plane_store.py`, `control_worker.py`, `run_index.py`;
- `src/polisyos/runtime/http/mutation_policy.py`;
- `src/polisyos/common/job_execution_interrupt.py`;
- `src/polisyos/runtime/quality/n5_execution_basis.py`, `semantic_binding.py`, `evidence_independence.py`;
- `src/polisyos/scientist/orchestration/orchestrator`, `workflows`, `engine/runner` и `scientist/validation/decision_validity.py`;
- прежние SYS-01, SYS-04, SYS-05, SYS-06 и связанные flow/validation материалы.

**Задачи:**

- [ ] A1. Построить owner-matrix для worker, job, request intent, lease/fence, budget reservation, witness/token, transaction/outbox, claim/epoch и публичного статуса. Для каждой строки указать создателя, владельца mutable state, acquire/renew/release, persistence, consumers и аварийный путь.
- [ ] A2. Проследить `ControlWorker`: start → lease → handler → heartbeat → stop/timeout/cancel → late completion → restart. Отдельно проверить «не принимать новую работу», «прервать текущую», «дождаться физического завершения» и «освободить ownership»: это разные обещания.
- [ ] A3. Проверить последовательности двух workers, истёкшего lease и старого owner; что реально отвергает stale mutation, когда остаётся физическая работа и кто её reconcile. Применить barriers/events вместо зависимости от случайных sleep.
- [ ] A4. Разделить generic mutation response replay, in-flight exclusion и durable domain admission. Проверить same key/same payload, same key/different payload, два процесса, сбой до/после persist и reopen. Не переносить вывод по generic layer на NL/predictive без отдельного trace.
- [ ] A5. Для N5 проследить issuance → capture → seal/read → consumer → release/revoke. Разделить retained Python object, current execution authority и historical receipt. Проверить old witness после terminal, копию/foreign witness, late result и восстановление без повторной физической работы.
- [ ] A6. Для unknown budget/timeout установить различие логического ответа и физической занятости; кто удерживает reservation, когда разрешён release и какое доказательство завершения необходимо.
- [ ] A7. Для evidence admission проследить, что проверяется до вычисления, где declaration может быть принята за verified evidence, какие конкурирующие promotion gates сохраняют защиту. Проверить positive, foreign, stale, empty, synthetic и post-hoc inputs без stub критического gate.
- [ ] A8. Для крупных файлов предложить только границы, сохраняющие transaction owner: pure projection/codec/scorecard против координации и эффекта. Сосчитать cross-owner private-state access до предложения split; перемещение строк само по себе не улучшение.

**Артефакты:** `ownership/REPORT_RU.md`, `ownership/owner_matrix.json`, `ownership/lifecycle_traces.json`, компактные probes и evidence. Если действующий отчёт уже содержит нужную таблицу, не создавать её копию.

**Готовность:** у каждого приоритетного lifecycle есть traced terminal и failure/recovery путь, определён реальный consumer, рассмотрено альтернативное объяснение, указан безопасный целевой owner и distinguishing regression. Неизвестное состояние не превращено в `stopped`, `released` или «можно повторить» без основания.

### B. Scaling и долгоживущие процессы

**Основной вопрос:** какие операции зависят от полного корпуса/истории/срока жизни процесса и какой contract ограничивает рост?

**Первичные входы:** `runtime/http/services/run_index.py`, `scientist/validation/decision_validity.py`, `runtime/http/mutation_policy.py`, `runtime/quality/n5_execution_basis.py`, `foundry/methods/selection/history.py`, `foundry/methods/backends/dispatch.py`; SYS-05, SYS-07, SYS-08, SYS-11.

**Матрица измерений:**

| Механизм | Растущая величина | Обязательный observable | Контроль корректности |
|---|---|---|---|
| Run catalogue/cache | corpus N, cache cap C, tenants T, page size P | reads/parses/hashes, найденные IDs, complete totals | Exact lookup N>C; tenant isolation; stable paging; deleted/changed run |
| Validity projection | файлов N, pending entries K, размер записи | file reads/bytes/hash work на TTL hit/miss и exact/list read | Изменение одного source действительно invalidates; unrelated tenant не пропускает нужную проверку |
| History/predictor | history H, methods/backends B, calls R | append/replay/fits, repeated full-history traversals | Новый history event обновляет predictor; отсутствие изменений не меняет семантику |
| Limiter/metrics | distinct routes/keys K, tenants T, idle time | retained buckets/labels, active resources, aggregate gauge | Освобождение active stream; interleaved tenants; route normalization |
| Witness/capture | issued records W, payload size S, owner lifetime | live weakrefs, retained graph, release/revoke behavior | Historical read остаётся допустимым, current authority не воскресает |
| Concurrent refresh | callers Q, process/instance count | refresh coalescing, duplicate I/O, lock wait | Ошибка leader/cancel/stale publication; независимость instance и shared-state |

**Задачи:**

- [ ] B1. Использовать не менее трёх увеличивающихся размеров в пределах безопасного локального бюджета; исходные 1k/10k/50k limiter points сохранять как одну серию, не как production нагрузку.
- [ ] B2. Развести cold/warm cache, TTL hit/miss, unchanged/changed corpus и isolated/shared/concurrent caller. Сначала снять counters, затем локальное время и память. Записывать повторы и разброс, не выбирать лучший прогон.
- [ ] B3. Для каждой предполагаемой O(N), O(N²) или unbounded зависимости дать механизм и проверку серии. Конечная серия сама по себе не доказывает асимптотику; число calls не является измерением latency.
- [ ] B4. Снять retention после idle, completion, explicit owner release и GC. `tracemalloc`, Python object count и RSS различаются. Synthetic payload и настоящий capture graph описывать отдельно.
- [ ] B5. Проверить complete catalogue отдельно от bounded object cache. Любая оптимизация exact lookup должна сохранять полный denominator, tenant/authorization scope и freshness.
- [ ] B6. Для candidate optimization сравнить минимум «ничего не менять», «reuse existing index/cache», «узкое изменение invalidation/ownership». Не предлагать глобальный cache, скрывающий staleness или unknown outcomes.
- [ ] B7. Вывести capacity hypotheses и условия дальнейшего load test. Production p95/p99, throughput, RSS и долгосрочный soak остаются `UNRUN`, пока реально не измерены в подходящем профиле.

**Артефакты:** `scaling/REPORT_RU.md`, machine-readable measurement series, точные input profiles и команды. Предварительные результаты сохраняются, но summary строится только по завершённым и проверенным сериям.

**Готовность:** каждая performance recommendation привязана к измеряемой стоимости, формуле роста/границе, correctness guard и контролю invalidation/release. Ускорение в процентах не заявляется без сопоставимого baseline.

### C. Reuse, контрактные повторы и библиотеки

**Основной вопрос:** что именно одинаково: текст, алгоритм, решение домена, публичный тип или гарантия эффекта?

**Первичные входы:** прежние `synthesis/DUPLICATION_DECISIONS.json`, `duplication/combined_ast_clones.json`, callers из source; `core/contracts/producer_spine.py`, `runtime/quality/semantic_binding.py`, `scientist/orchestration/memory/contracts.py`, `failure_lessons.py`, Core registry/cache/discovery, DataForge extraction owners, statistical/graph helpers.

**Порядок проверки:**

1. Existing internal owner и уже установленная stdlib/library.
2. Совместимость контрактов на реально используемых inputs и negatives.
3. Тонкий adapter, если он сохраняет различие доменных решений.
4. Новая зависимость только при доказанной необходимости, с licence/platform/version/maintenance/import-cost оценкой.

**Задачи:**

- [ ] C1. Свести 41 прежнее family decision с raw-кластерами и current consumers; дополнить разбор приоритетных ещё не рассмотренных groups. Для exact/normalized пересечений не удваивать denominator.
- [ ] C2. У каждой выбранной семьи заполнить contract matrix: inputs/envelope, output/type/FQN, bytes/digest, ordering/errors, mutable state, concurrency, freshness, persistence/recovery, authority purpose и optional-provider policy.
- [ ] C3. Проверить nominal memory contracts на реальном import path: один ли объект класса/export, что принимает nested validation, кто производит и читает events; отделить wire compatibility от Python identity. Characterization на другом Pydantic не заменяет locked acceptance.
- [ ] C4. Проверить producer-spine и extraction tables: различия normalization/grammar/blockers/refs и facade/leaf import order. Не объединять одинаковый AST, если helper semantics расходятся. Проверить monkeypatch seam, exception restoration и overlap.
- [ ] C5. Квалифицировать маленькие положительные кандидаты: Foundry enumeration → Core; boolean cycle test → `graphlib`; общие immutable tables; narrow solver-status adapter. Сохранить сортировку, unknown predecessor/cycle errors, raw backend status и optional imports.
- [ ] C6. Проверить prerequisites shared primitives: SemVer precedence/build metadata, nullable presence в LRU, exception-safe local lock и complete writes, registry hook/indexer failures. Не распространять ещё неквалифицированную primitive на новых consumers.
- [ ] C7. Для statistical kernels сравнить threshold inclusivity, family denominator, missingness, NaN/inf/empty, dtype/shape и provider fallback. Ljung–Box witness требует отдельного решения о допустимой approximation; близость чисел не гарантирует одинакового decision.
- [ ] C8. Для JAX/rollout ограничить рекомендацию без native PRNG/pytree/shape/dtype/JIT/vmap/gradient контроля. Не считать forward equality доказательством замены. Compile и steady state измерять раздельно, если такие проверки вообще выполняются.
- [ ] C9. Явно оставить разные механизмы, когда различаются distributed lease и local lock, SCC и boolean cycle, canonical identity bytes и fast JSON, authority admission и расчёт, physical retry и decorator retry.

**Допустимые решения:** `reuse_existing`, `consolidate`, `extract_primitive`, `share_contract`, `retain_intentionally`, `insufficient_evidence`. Старое disposition сохраняется или меняется с причиной; предложение не считается решением maintainers.

**Артефакты:** `reuse/REPORT_RU.md`, `reuse/decisions.json`, contract/differential evidence, список rejected candidates. Не выносить весь повторяющийся код в Core/common ради статистики.

**Готовность:** для каждой углублённо проверенной семьи названы canonical owner либо причина сохранения разделения, реальные consumers, migration risks и acceptance discriminator. Библиотечная замена не рекомендована как drop-in при известных semantic отличиях.

### D. Структура репозитория, тесты и документация

**Основной вопрос:** текущая организация уменьшает связанность и доказывает полезные свойства или только удовлетворяет счётчикам/форме?

**Первичные входы:** `architecture/imports/{policy,exceptions,dynamic,lazy}.toml`, `architecture/public_surface/contract.toml`, `architecture/packages`, `architecture/tests/{topology,ratchets}.toml`, `tools/quality/testing/report_test_ratchets.py`, `tests/_helpers`, `tests/unit/*/mirror_contracts`, `architecture/generated_artifacts.toml`, `mkdocs.yml`, packaging manifests и `.github/workflows`; SYS-01 и SYS-12.

**Задачи:**

- [ ] D1. Развести physical layout, public facade, dependency direction и настоящий side-effect owner. Найти boundary exceptions, private-state access и смешанные responsibilities; не считать каждый SCC дефектом.
- [ ] D2. Уточнить frontend/tooling edges: syntax imports, compiler-resolved imports, dynamic loading/entrypoints, generated clients и runtime/subprocess contracts. Неразрешённые связи сохранять явно, type-only/lazy edges не смешивать с обязательной runtime загрузкой.
- [ ] D3. Проверить test topology и reverse imports helpers с полным именованным denominator. Parse failures не исключать молча. Отдельно проверить поведение собственного измерителя на unsupported syntax.
- [ ] D4. Разделить mirror/schema/smoke/marker checks и semantic behavior tests. Для выбранного обязательства выполнить removal/corruption control в отдельном временном input, не меняя source: исчезновение реального поведения должно опровергать именно заявленное свойство.
- [ ] D5. Проверить, где mock/stub подменяет producer, verifier, admission gate или persisted consumer. Наличие test file, assert и зелёный fixture не равно end-to-end доказательству. Не выводить отсутствие semantic tests только из слабости одного mirror helper.
- [ ] D6. Проверить test selectors, skip/xfail, collection, mutation targets, reported thresholds и фактическую CI команду. Исторический лог отделить от актуального hosted result; inherited failure утверждать только после exact replay прежних полных inputs.
- [ ] D7. Классифицировать docs: действующий контракт, generated reference, операционный runbook, immutable historical evidence, draft/proposal, superseded. Для active docs найти owner/source-of-truth, machine consumers, links и условие freshness.
- [ ] D8. Проверить generated registry на уровне directory-aware outputs и реально поставляемых файлов. Raw membership, directory expansion и generated total имеют разные знаменатели; предыдущие коррекции counts сохраняются.
- [ ] D9. Проверить wheel/sdist/front-end release payload по настоящим selectors, imports и entrypoints. Intended-wheel inventory не равно собранному wheel. Не исключать tools/evidence/doc file из поставки без проверки потребителей.
- [ ] D10. Предложить ограниченные изменения: один актуальный workflow/status, канонические owners и references, узкий suppression ratchet, явный lifecycle архивных материалов. Не выполнять bulk deletion или новый governance framework.

**Артефакты:** `structure/REPORT_RU.md`, `structure/coverage.json`, `structure/test_obligations.json`, docs/distribution disposition и минимальные gate controls.

**Готовность:** отчёт показывает не только число файлов/тестов, но связь requirement → producer/consumer → test → gate → shipped object. Unresolved tooling failure отдельно от product failure. Предложения по структуре имеют измеримый эффект и сохраняют active references.

### E. Free-grow и открытая обнаружимость

**Основной вопрос:** корректно добавленный ресурс расширяет capability через существующие typed indexes/adapters без правки кода, а неправильный не получает authority?

**Нормативная база:** правило 12 в `docs/system-design-decisions/universal-policy-design-system-vision-and-organizing-rules.md`, capability reality bar, custody boundary и `policyos-atlas-surface-constitution-and-frontend-vision.md`. Начальные входы: `runtime/quality/proving_ground/pre_adapter_grounding_inventory.py`, `runtime/quality/intervention_substrate.py`, `runtime/http/services/governed_projections.py`, `governed_projection_validation_worker.py`, Layer3 reports/fixtures и найденные реальные registry/search producers/consumers.

**Три состояния проверяются отдельно:**

- `discoverable`: запись видна typed index и выдаётся поиском;
- `executable`: реальный adapter позволяет прочитать/вызвать ресурс;
- `admitted authority`: conformance и evidence разрешают конкретное authority purpose.

Первые два состояния не дают третье автоматически. Governed vocabulary, schemas, statuses, ports и rule versions не являются запрещёнными capability-enumerations.

**Задачи:**

- [ ] E1. Составить census открытых capability surfaces: datasets/sources, methods, agents/tools, claims, intervention/construct/variable resources и frontend pickers. Для каждой указать index, producer, search query/ranking, adapter, consumer и authority gate.
- [ ] E2. Найти hand-maintained allowlists, switch/enum ветки, static picker menus и fallback inventories, реально ограничивающие обнаружение/исполнение. Отдельно классифицировать fixed app chrome и нормативные vocabularies, чтобы не объявить их дефектами.
- [ ] E3. На выбранных независимых типах ресурсов добавить только синтетические данные/регистрационную запись в отдельную тестовую область. Доказать unchanged product hashes, обнаружение ранее неизвестного ID и использование существующим consumer. Новая ветка кода/fixture-specific route недопустима как доказательство zero-code growth.
- [ ] E4. Проверить mechanism-generality минимум на двух различных корректных inputs, а также на неизвестном/неправильно typed/не прошедшем conformance ресурсе. Безопасный отказ должен сохранять limitation, а не превращать её в successful authority.
- [ ] E5. Применить fresh/stale index, alias variation, corpus growth, ограниченный search budget и known-groundable seeds. Разделить domain ceiling и search ceiling; no-hit не доказывает отсутствие ground.
- [ ] E6. Проследить происхождение free-growth report: declared booleans/fixture count → фактический producer → content-bound evidence → независимая validation → served projection. Проверить подмену, удаление или устаревание evidence и настоящий consumer refusal.
- [ ] E7. Проверить, не изменяет ли новый corpus/index исторический closed-case replay. Историческое влияние не должно незаметно становиться current evidence.

**Артефакты:** `free_growth/REPORT_RU.md`, `free_growth/surfaces.json`, mutation/negative-control evidence и explicit coverage gaps. Название каталога может быть согласовано с финальным manifest, но free-grow нельзя растворять в общей clone-статистике.

**Готовность:** по каждому выбранному surface есть проверенный путь discover → execute → admit/refuse, zero-code discriminator, freshness/recall контроль и понятная граница неохваченного. Одних readiness fields и конструкторов для принятия недостаточно.

### F. Сквозная интеграция и квалификация

**Основной вопрос:** вывод из отдельного слоя остаётся верным на границе между компонентами, после persistence/restart и в реально поставляемом профиле?

**Обязательные цепочки:**

1. Runtime request → durable admission → worker/Scientist → Foundry → terminal/persist → fresh reader/API.
2. Data requirement → acquisition/source meaning → semantic binding → numerical consumption → evidence/claim.
3. Evidence admission → candidate/authority transition → publication/currentness → stale/revalidation reaction.
4. Registry/search → discovery → adapter/provider choice → fallback → attribution/status → consumer.
5. Artifact/schema/canonical bytes → persistence → reopened/installed consumer → public DTO/client.
6. Cell identity → Python naming → Helm/Terraform rendered name → ownership reference; реальная migration отдельно.
7. Canonical OPA/fixtures → shipped package → canary-owned startup → проверяемый service/instance → release evidence.
8. Backend/API → generated frontend client → UI state; loading/error/stale/unknown/partial results и возможность повторного действия.

**Задачи:**

- [ ] F1. Для каждой цепочки построить trace с typed boundary, producer, persisted artifact/event, bridge, consumer, verifier и user/API/audit surface; отсутствие звена назвать явно.
- [ ] F2. Проверить happy path, один существенный failure/recovery path, альтернативный consumer/backend и reopen/restart, когда контракт это предполагает.
- [ ] F3. Перенести сильные bounded witnesses на native/locked profile и реальные imports по приоритету, без неявного запуска приложения или реальной научной нагрузки. Необходимые optional dependencies и профиль фиксировать заранее.
- [ ] F4. Проверить full identity и scope: tenant/cell/run/claim/epoch/purpose, schema/version, clocks и status lattice. UUID-name collision не равен доказанной межтенантной утечке; source collision требует своего downstream trace.
- [ ] F5. У release evidence проверить принадлежность объекту: foreign service на порту не должен подтверждать canary, проверенный OPA bundle должен совпадать с shipped, fixture denominator должен быть единым, installed-origin должен быть установлен отдельно.
- [ ] F6. Для frontend не выдавать syntax AST за TypeScript build. При доступной среде использовать Node 22 и frozen links; выполнить выбранные typecheck/client/UI contracts. Live browser/deployment, если не выполнены, оставить отдельным `UNRUN`.
- [ ] F7. Для каждого blocker описать точную проверку, среду/данные/разрешение, которых не хватает, и какие выводы остаются допустимыми. Отсутствие native среды не блокирует source analysis, но ограничивает acceptance.

**Артефакты:** `integration/REPORT_RU.md`, `integration/flow_matrix.json`, profile/command/results и source-qualified native/installed evidence при наличии.

**Готовность:** все важные находки имеют consumer reachability и границу применимости. Нельзя объявлять продукт квалифицированным только потому, что завершён документированный scope аудита.

## 5. Порядок выполнения и зависимости

### Этап 0. База и восстановление контекста

- [x] Прочитать прежний финальный архив и зафиксировать тот же current snapshot.
- [x] Сохранить commit/tree, полный file denominator и source hashes.
- [x] Создать этот план продолжения с явными ограничениями.
- [ ] Проверить, что все промежуточные результаты связаны с этим SHA; исправить неверные locators в отчётах, не переписывая исходное evidence.

### Этап 1. Параллельное углубление A–D

Ownership, scaling, reuse и structure допускаются параллельно по read-only source. Один ответственный ведёт каждый итоговый тематический артефакт. Общая область результата не должна иметь конкурирующих writers. До долгого повторного запуска сначала проверяется, нет ли уже пригодного результата.

- [ ] Закончить initial probes, квалифицировать измерители и явно отметить неисполненные серии.
- [ ] Передать первые существенные результаты с ограничениями, не ожидая полного финала.
- [ ] Свести пересечения: N5 retention относится одновременно к ownership/scaling, но остаётся одним корневым механизмом; nominal DTO split не считать отдельно по каждому consumer.

### Этап 2. Free-grow и integration joins

E и F начинаются после получения нужных maps/callers, а не после формального завершения всех A–D. Free-grow и integration имеют собственные acceptance и не закрываются автоматически успехом соседнего направления.

- [ ] Выполнить selected zero-code/data-mutation и real-consumer controls.
- [ ] Уточнить приоритет native replays по последствиям, reachability и неопределённости.
- [ ] Углубить siblings при повторном однотипном escape вместо добавления ещё одного локального правила.

### Этап 3. Независимая проверка и сводный вывод

- [ ] Независимо перепроверить самые существенные выводы: source/input identity, counterexample, consumer, отрицательный контроль, severity и альтернативное объяснение.
- [ ] Проверить новые strong claims отдельно от инструментов, которые их породили; не требовать бесконечной цепочки «верификации верификатора».
- [ ] Сверить новые результаты с 12 SYS-семействами, 26 AUD IDs и rejected signals. Статусы: `new_mechanism`, `deepened_existing`, `reconfirmed`, `rejected`, `superseded`, `unverified`.
- [ ] При необходимости прочитать fresh remote identity и сделать bounded delta затронутых файлов. Зафиксировать время наблюдения; не переносить все conclusions на новый SHA без проверки.
- [ ] Выпустить итоговый приоритетный реестр и программу изменений; числовой квоты на новые дефекты нет.

Независимый небольшой gauge/library/distribution анализ не обязан ждать миграции lifecycle. Но объединение owners или removal проверок не рекомендуется без соответствующего contract/failure acceptance.

## 6. Среда, измерения и безопасность исполнения

Поддерживаемый baseline из CONTRIBUTING: **Python 3.14.x, Node 22.x, uv 0.9.21** и существующие locks. В текущих bounded probes фактически использованы Python 3.12.14 и отдельные иные версии зависимостей. Это должно оставаться в каждой карточке применимости.

Перед новой исполняемой проверкой:

1. Прочитать target, imports, fixtures, CLI options и side effects.
2. Убедиться, что external network/provider, database write, acquisition и E02 не запускаются транзитивно.
3. Направить pycache/temp/output вне source; не снимать read-only ради удобства.
4. Назвать CPU/RAM/disk/time профиль. Не запускать неизвестную дорогую численную нагрузку параллельно.
5. Использовать bounded input, seeds, graceful stop и cleanup только созданных audit ресурсов.
6. Сохранить реальную команду, версии, stdout/stderr, exit code и ограничения.

Native-команды берутся из существующей project CLI/help и запускаются только по затронутому scope. Примеры предусмотренных проектом проверок: `.venv/bin/python -m ruff`, `corepack pnpm`, architecture guardrails и runtime API contract. `verify --backend-only` и `ci-parity --skip-browser` не запускаются автоматически за каждый probe. Приведение списка команд в плане не означает их выполнения.

В read-only аудите не требуется устанавливать новый полный environment ради косметического PASS. Tooling error, несовместимая syntax и отсутствующая dependency фиксируются отдельно от product failure. Synthetic SQLite не доказывает live PostgreSQL/RLS concurrency; source extraction не доказывает installed import; локальная память не доказывает production capacity.

## 7. Формат находки и решения

Каждая опубликованная существенная карточка содержит:

- ID и связь с прежним SYS/AUD/семейством; новый механизм или углубление старого;
- violated invariant и точный ожидаемый contract;
- baseline SHA, source paths/line spans и hashes;
- реальный entry point → producer → consumer, affected siblings и blast radius;
- наблюдение, входы/команду/среду, negative control и source trace;
- подтверждённые последствия отдельно от гипотез и production impact, который не установлен;
- severity, confidence и evidence level как отдельные поля;
- альтернативные объяснения и rejected overclaims;
- preferred existing owner, минимальный вариант изменения, альтернативу «сохранить»;
- сохраняемые public/FQN/bytes/state/authority guarantees и migration risks;
- acceptance discriminator, следующий необходимый replay и stop condition;
- E02/source-identity/authority interlock, если реально затрагивается;
- decision status: предложение или фактическое решение владельца с источником.

Аудитор не принимает риск за maintainer. `defer/accept` без решения владельца остаётся `proposed`; неизвестное поведение не становится принятым риском.

Приоритет устанавливается последствиями для correctness/custody, реальной достижимостью, широтой/частотой воздействия, уверенностью и стоимостью устранения. Большой файл, SCC, raw clone count, неизмеренный latency и название похожего коммита сами по себе не дают высокий priority.

## 8. Итоговые артефакты и checkpoints

### 8.1 Первый checkpoint

План, baseline, сохранённые preliminary probes и честный статус. Не выдавать его за завершённый глубокий аудит. В README перечислить готовые и ещё не выполненные части, limitations и следующий шаг.

### 8.2 Содержательные checkpoints

По мере завершения направлений выпускать компактный самодостаточный пакет с тематическими отчётами, проверенными inputs/results и отличиями от предыдущего. Не откладывать передачу полезного результата до native qualification всех остальных областей.

### 8.3 Финальный пакет

Минимальный состав:

- `README_RU.md`: короткий результат, ключевые действия, ограничения и навигация.
- `plan/PLAN_RU.md`: этот текущий план с существенными обновлениями статуса.
- `baseline/BASELINE_RU.md` и provenance/file manifests.
- Тематические отчёты A–F и воспроизводимые компактные evidence.
- `synthesis/REPORT_RU.md`: общий вывод и последовательность дальнейших изменений.
- `synthesis/FINDINGS.json`: дедуплицированный реестр с источниками и acceptance.
- `synthesis/COVERAGE_RU.md` и `coverage.json`: denominators, уровни проверки, exclusions, unresolved, blocked и UNRUN.
- `synthesis/REUSE_DECISIONS.json`: обновлённые решения по исследованным семьям.
- `synthesis/ROADMAP.json`: отдельные будущие work packages с prerequisites, рисками, проверками и stop conditions.
- `synthesis/REJECTED_SIGNALS.json`: существенные отклонённые трактовки.
- `validation/REVIEW_RU.md`: результаты независимой проверки и остаточные разногласия.
- Общий `MANIFEST.json` и SHA-256 checksums.

Нужные ранее существовавшие доказательства должны быть доступны в переданном пакете как выбранные файлы/компактные выдержки либо явно сопровождаться исходным архивом. Хэш недоступного файла не является доступом к evidence. Не копировать весь checkout, credentials, env dumps, caches и избыточные raw datasets. Ссылки на код фиксируются на проверенном commit; относительные ссылки в ZIP проверяются.

Не создавать отдельный новый отчёт на каждый технический шаг. Сводные counts должны восстанавливаться из именованного полного denominator, а результат выбранной выборки оставаться выборкой.

## 9. Критерий завершения

Углублённый аудит завершён, когда:

- [ ] У каждого из шести направлений есть содержательный результат либо точный неперекрываемый blocker с объяснением влияния.
- [ ] Все 25 current product roots и основные не-source поверхности имеют явный coverage status; полная перепись не выдана за сплошную semantic verification.
- [ ] Приоритетные ownership/scaling/reuse выводы проверены на реальном consumer path и имеют distinguishing controls.
- [ ] Free-grow проверен как zero-code capability chain, а не только как vocabulary/readiness field; недоказанные поверхности перечислены.
- [ ] Тесты, документация, generated evidence и shipped objects связаны с теми свойствами, которые ими заявлены.
- [ ] Старые и новые механизмы сведены без двойного счёта; ложные сильные трактовки исключены.
- [ ] Native/installed/deployed ограничения, неисполненные команды и tooling failures не скрыты за общим PASS.
- [ ] Программа дальнейших изменений использует существующих owners, не требует лишнего framework и не выполняет незапрошенные исправления.
- [ ] Source bytes/статус не изменились; итоговый пакет проверен, воспроизводим и передан.

**Завершение аудита означает выполнение этого доказательного scope. Оно не означает исправление находок, закрытие E02, квалификацию всей системы или разрешение на production release.**
