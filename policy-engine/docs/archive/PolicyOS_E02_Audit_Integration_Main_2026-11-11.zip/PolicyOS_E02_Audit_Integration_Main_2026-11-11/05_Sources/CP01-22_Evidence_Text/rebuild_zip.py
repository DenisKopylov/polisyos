#!/usr/bin/env python3
"""Create deterministic ZIP from a verified extracted package."""
import argparse,json,zipfile,sys
from pathlib import Path
sys.dont_write_bytecode=True
from verify_package import verify
root=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('output',type=Path);args=ap.parse_args()
assert not args.output.resolve().is_relative_to(root), 'Write archive outside the package'
result=verify(root);assert result['status']=='PASS_INTEGRITY_ONLY',result
with zipfile.ZipFile(args.output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(root.rglob('*')):
  if p.is_file():
   info=zipfile.ZipInfo(root.name+'/'+str(p.relative_to(root)),date_time=(2026,11,11,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.create_system=3;info.external_attr=0o100644<<16
   z.writestr(info,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
print(args.output)
