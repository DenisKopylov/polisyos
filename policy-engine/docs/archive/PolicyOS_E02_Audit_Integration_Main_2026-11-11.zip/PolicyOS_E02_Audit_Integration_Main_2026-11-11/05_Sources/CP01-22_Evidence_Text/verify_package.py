#!/usr/bin/env python3
"""Read-only portable integrity verifier. Does not execute product code."""
import argparse, hashlib, json, re, sys
from pathlib import Path, PurePosixPath
from urllib.parse import unquote, urlsplit
from html.parser import HTMLParser

def sha(data): return hashlib.sha256(data).hexdigest()
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def selected(obj, pointer):
    if not pointer: return obj
    assert pointer.startswith('/') or pointer.startswith('#/'), pointer
    for key in pointer.removeprefix('#').split('/')[1:]:
        key=key.replace('~1','/').replace('~0','~')
        obj=obj[int(key)] if isinstance(obj,list) else obj[key]
    return obj
def safe(n):
    p=PurePosixPath(n)
    return bool(n) and not p.is_absolute() and '..' not in p.parts and '\\' not in n and '\n' not in n and '\r' not in n and str(p)==n
def links(p):
    s=p.read_text(encoding='utf-8')
    if p.suffix=='.md': return re.findall(r'!?\[[^\]]*\]\(([^)]+)\)',re.sub(r'```.*?```','',s,flags=re.S))
    if p.suffix=='.html':
        class Parser(HTMLParser):
            targets=[]
            def handle_starttag(self,tag,attrs):
                if tag in ('a','img','link','script'):
                    for k,v in attrs:
                        if k in ('href','src'): self.targets.append(v)
        parser=Parser(); parser.targets=[];parser.feed(s);return parser.targets
    return []

def verify(root):
    fail=[];counts={'manifest_files':0,'local_links':0,'html_anchor_links':0,'reference_bindings':0,'json_pointers':0,'cards':0,'roadmap_packages':0}
    manifest=read(root/'MANIFEST.json'); rows=manifest['files']; names=[x['path'] for x in rows]
    if len(names)!=len(set(names)): fail.append('duplicate manifest path')
    for row in rows:
        n=row['path'];p=root/n;counts['manifest_files']+=1
        if not safe(n) or not p.is_file() or p.is_symlink() or not p.resolve().is_relative_to(root.resolve()):fail.append('unsafe/missing: '+n);continue
        b=p.read_bytes()
        if len(b)!=row['bytes'] or sha(b)!=row['sha256']:fail.append('hash/size: '+n)
    actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
    expected=set(names)|{'MANIFEST.json','SHA256SUMS.txt'}
    if actual!=expected:fail.append({'file_set':{'missing':sorted(expected-actual),'extra':sorted(actual-expected)}})
    sr={}
    for line in (root/'SHA256SUMS.txt').read_text().splitlines():
        h,n=line.split('  ',1)
        if not safe(n) or n in sr:fail.append('unsafe/duplicate checksum: '+n);continue
        sr[n]=h;p=root/n
        if not p.is_file() or sha(p.read_bytes())!=h:fail.append('checksum: '+n)
    if set(sr)!=expected-{'SHA256SUMS.txt'}:fail.append('checksum coverage')
    for n in sorted(actual):
        p=root/n
        for target in links(p):
            u=urlsplit(target.split(' "',1)[0].strip('<>'))
            if u.scheme:
                if u.scheme not in ('https','http'):fail.append(['link scheme',n,target])
                continue
            if u.netloc:fail.append(['protocol-relative link',n,target]);continue
            q=(p.parent/unquote(u.path)).resolve() if u.path else p.resolve()
            if u.path:
                counts['local_links']+=1
                if not q.is_relative_to(root.resolve()) or not q.is_file():fail.append(['missing link',n,target]);continue
            if u.fragment and q.suffix=='.html':
                counts['html_anchor_links']+=1
                class Anchors(HTMLParser):
                    ids=set()
                    def handle_starttag(self,tag,attrs):
                        for k,v in attrs:
                            if k=='id':self.ids.add(v)
                parser=Anchors();parser.ids=set();parser.feed(q.read_text(encoding='utf-8'))
                if unquote(u.fragment) not in parser.ids:fail.append(['missing HTML anchor',n,target])
    for row in read(root/'next_cumulative_22/REFERENCE_VALIDATION.json')['checks']:
        b=row['binding'];n=b['path'];p=root/n;counts['reference_bindings']+=1
        if not safe(n) or not p.is_file() or sha(p.read_bytes())!=b['sha256']:fail.append(['binding',n]);continue
        if 'bytes' in b and p.stat().st_size!=b['bytes']:fail.append(['binding size',n])
        if 'json_pointer' in b:
            counts['json_pointers']+=1
            try:
                v=selected(read(p),b['json_pointer']);h=sha(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
                if h!=b['selected_value_sha256']:fail.append(['pointer hash',n,b['json_pointer']])
            except Exception as e:fail.append(['pointer',n,repr(e)])
    r=read(root/'next_cumulative_22/REGISTRY.json');cards=r['findings'];ids=[x['id'] for x in cards];counts['cards']=len(ids)
    if r!=read(root/'next_cumulative_22/FINDINGS.json'):fail.append('registry copies differ')
    if len(ids)!=112 or len(ids)!=len(set(ids)) or len(r['mechanism_groups'])!=111:fail.append('count/ids')
    if r['audit_status']!='PARTIAL' or r['audit_complete'] or r['fixes_implemented']:fail.append('status')
    for n in ['publication-authority::PA-01','policy-assembly::PA-01','policy-assembly::PA-02','scholar::RC-01','custody::RC-01']:
        if n not in ids:fail.append('missing namespace '+n)
    road=read(root/'next_cumulative_22/ROADMAP.json');packages=road['packages'];counts['roadmap_packages']=len(packages)
    targets=[x for p in packages for x in p['targets']]
    if len(packages)!=14 or sorted(targets)!=sorted(ids):fail.append('roadmap assignment')
    graph={p['id']:p['dependencies'] for p in packages};active=set();done=set()
    def visit(n):
        if n in active:raise ValueError('cycle')
        if n in done:return
        active.add(n)
        for d in graph[n]:visit(d)
        active.remove(n);done.add(n)
    try:
        for n in graph:visit(n)
    except Exception as e:fail.append(['roadmap graph',repr(e)])
    checkpoints=read(root/'CHECKPOINT_REFERENCES.json')['checkpoints']
    if [x['checkpoint'] for x in checkpoints]!=list(range(1,23)):fail.append('checkpoint index')
    if any(x['included_in_this_archive'] for x in checkpoints):fail.append('old ZIP included')
    return {'status':'PASS_INTEGRITY_ONLY' if not fail else 'FAIL','audit_status':'PARTIAL','audit_complete':False,'product_acceptance':False,'counts':counts,'failures':fail,'scope':'Archive bytes, local links, 403 cumulative bindings, JSON pointer values, IDs and roadmap. Not all historical raw evidence, source checkout, semantic/native/product acceptance or remote download verification.'}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);args=ap.parse_args()
    try:out=verify(args.root)
    except Exception as e:out={'status':'FAIL','error':repr(e)}
    print(json.dumps(out,ensure_ascii=False,indent=2));sys.exit(out['status']!='PASS_INTEGRITY_ONLY')
