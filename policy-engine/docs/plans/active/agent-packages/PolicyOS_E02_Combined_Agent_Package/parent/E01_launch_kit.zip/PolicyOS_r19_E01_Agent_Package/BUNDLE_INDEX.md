# Карта 84 рабочих пакетов

Для выдачи готовой работы используйте отдельные packets, не перечитывайте общий источник всеми агентами. Полные правила — EXECUTION_GUIDE.md.

## Индекс 84 пакетов B-ремонта

Все B-ID назначены одному primary owner; cross-boundary references не дублируют ответственность.

| Пакет | Находки | Предшественники | Класс | Окно |
|---|---|---|---|---|
| [CYC-01 — Штатный вход и связанные контексты N4/N5](bundles/CYC-01.md) | B01, B02, B03 | — | L | K1 |
| [SIM-01 — Полный выбор движка и верная история fallback](bundles/SIM-01.md) | B06, B07 | — | L | K1 |
| [SIM-02 — Выходы, конфликты атомов и покрытие траекторий](bundles/SIM-02.md) | B18, B20, B22 | — | L | K1 |
| [SIM-03 — Контрасты, реплики, SMM и экономия одинаковых расчётов](bundles/SIM-03.md) | B19, B21, B23, B25, B26 | SIM-02 | N | K1 |
| [CYC-02 — Читаемый численный результат и положительный условный N8](bundles/CYC-02.md) | B04, B05, B08 | CYC-01, SIM-01, SIM-02, SIM-03 | N | K1 |
| [CYC-03 — Идентичность содержательной второй итерации](bundles/CYC-03.md) | B09, B27, B28 | CYC-01 | L | K1 |
| [CYC-04 — Альтернативы, исследовательский бюджет и acquisition→re-entry](bundles/CYC-04.md) | B10, B11, B12 | CYC-03 | L | K1 |
| [CYC-05 — Правдивые лимиты, завершение и структурная проверка](bundles/CYC-05.md) | B15, B29, B30 | CYC-02, CYC-03 | L | K1 |
| [EMP-01 — Смысл эмпирических входов, времени и ValueOuterSet](bundles/EMP-01.md) | B16, B31, B32, B33 | CYC-01 | L | K1 |
| [SCL-01 — Поиск после пустого допустимого ответа](bundles/SCL-01.md) | B17 | — | L | K2 |
| [SEL-01 — Singleton, eligibility и неизменные требования выбора](bundles/SEL-01.md) | B34, B35, B36 | — | L | K1 |
| [CMP-01 — Импорт, effective DAG и единый payload исполнителей](bundles/CMP-01.md) | B42, B43, B44 | — | L | K1 |
| [CMP-02 — Однозначные slots и ordering по occurrence](bundles/CMP-02.md) | B45, B46 | CMP-01 | L | K1 |
| [CMP-03 — Полное и семантически одинаковое ручное/автоматическое связывание](bundles/CMP-03.md) | B47, B48 | CMP-02 | L | K1 |
| [JIT-01 — Правильный warm kernel, single-flight и дешёвая подготовка](bundles/JIT-01.md) | B49, B50, B53 | — | N | K1 |
| [FIT-01 — Nuisance fit-core, актуальная диагностика и ограниченные folds](bundles/FIT-01.md) | B54, B56 | — | N | K4 |
| [STA-01 — Изоляция ветвей и точные эффекты replay](bundles/STA-01.md) | B57, B58, B59 | — | L | K2 |
| [STA-02 — Точная версия входа и пригодность готового bundle](bundles/STA-02.md) | B60, B61, B62 | STA-01 | L | K2 |
| [EXE-01 — Допуск cache read, неблокирующий I/O и fail-fast](bundles/EXE-01.md) | B51, B52, B55 | STA-01, RUN-01 | L | K2 |
| [RES-01 — Повторный resume, достаточный state и дешёвый индекс](bundles/RES-01.md) | B63, B70, B71 | STA-02, RES-02 | L | K2 |
| [RES-02 — Единый завершённый frontier и атомарный tier checkpoint](bundles/RES-02.md) | B72, B73 | STA-01 | L | K2 |
| [RES-03 — Сохранение частичного результата через последующий отказ](bundles/RES-03.md) | B13 | CYC-02, CMP-01 | L | K2 |
| [EXE-02 — Готовность зависимостей вместо лишнего tier-ожидания](bundles/EXE-02.md) | B77 | RES-02, RES-01 | L | K2 |
| [RUN-01 — Deadline, contextvars и безопасные sync/async-мосты](bundles/RUN-01.md) | B14, B40, B69, B95 | — | L | K2 |
| [RUN-02 — Доставка результата через процессную границу](bundles/RUN-02.md) | B24 | RUN-01 | N | K2 |
| [RUN-03 — Одна retry-политика и чистый baseline каждой попытки](bundles/RUN-03.md) | B39, B96 | STA-01, RUN-01 | L | K2 |
| [DUR-01 — Аварийно-устойчивый бюджетный snapshot](bundles/DUR-01.md) | B37 | — | L | K2 |
| [DUR-02 — Поколение worker и безопасный backend handover](bundles/DUR-02.md) | B38, B78 | RUN-03, RES-02 | L | K2 |
| [RES-04 — Точный Foundry checkpoint и неизменяемые sidecars](bundles/RES-04.md) | B74, B75, B76 | CMP-02 | N | K2 |
| [STP-01 — Актуальный convergence-сигнал и плато около нуля](bundles/STP-01.md) | B41, B122 | — | L | K3 |
| [LLM-01 — Корректная обёртка, необязательная телеметрия и цена reuse](bundles/LLM-01.md) | B64, B65, B66 | — | L | K2 |
| [LLM-02 — Разрешённый immutable reuse и single-flight](bundles/LLM-02.md) | B67, B68 | LLM-01 | L | K2 |
| [ING-01 — Инкрементальный запрос, committed cursor и replay](bundles/ING-01.md) | B79, B80, B88 | — | L | K2 |
| [ING-02 — Непрерывное окно, позиция и полная lineage](bundles/ING-02.md) | B81, B82, B85 | ING-01, NET-01 | L | K2 |
| [ING-03 — Ограниченный stream-state без смены выборки](bundles/ING-03.md) | B83, B84, B86 | ING-02 | L | K2 |
| [NET-01 — Владение соединением от acquire до cleanup](bundles/NET-01.md) | B87, B89, B90 | — | L | K2 |
| [NET-02 — Редкий rate, поколения circuit и невыбрасываемая защита](bundles/NET-02.md) | B91, B92, B93 | — | L | K2 |
| [WIRE-01 — Версионированный transport допустимых типов state](bundles/WIRE-01.md) | B94 | — | L | K2 |
| [DOE-01 — Ограниченная генерация и только объявленные раунды](bundles/DOE-01.md) | B97, B98, B99 | — | L | K3 |
| [DOE-02 — Один дизайн распределений и локальные RNG](bundles/DOE-02.md) | B100, B101 | DOE-01 | N | K3 |
| [DOE-03 — Целые блоки, failure-policy, PCA и шкала Morris](bundles/DOE-03.md) | B102, B103, B104, B105 | DOE-02 | N | K3 |
| [STR-01 — Направление stress-поиска и независимые от top-k счётчики](bundles/STR-01.md) | B106, B107 | — | L | K3 |
| [OPT-01 — Метрика, полная координата и строгий Pareto](bundles/OPT-01.md) | B108, B109, B110, B111 | — | L | K3 |
| [OPT-02 — Настоящий SearchSpace и координаты фактического исполнения](bundles/OPT-02.md) | B112, B113, B127 | OPT-01 | L | K3 |
| [OPT-03 — Рабочий warm-start и сохранённое GP-состояние](bundles/OPT-03.md) | B114, B115 | OPT-02 | N | K3 |
| [OPT-04 — Привязанный champion и compare-and-publish](bundles/OPT-04.md) | B116, B117 | OPT-01, OPT-02 | L | K3 |
| [CTL-01 — Изолированный запуск, остановка и typed-result](bundles/CTL-01.md) | B118, B119, B120, B121, B123 | OPT-01 | L | K3 |
| [CTL-02 — Содержательные даты и воспроизводимый RNG/checkpoint](bundles/CTL-02.md) | B124, B125, B126 | OPT-02 | L | K3 |
| [TRN-01 — Численный transfer без фиктивного benchmark](bundles/TRN-01.md) | B128, B130, B131, B132 | OPT-02 | L | K3 |
| [TRN-02 — Точные snapshot-refs и атомарное поколение vector memory](bundles/TRN-02.md) | B129, B133, B134 | — | N | K3 |
| [TRN-03 — Контекст переноса, фильтры lessons и время подтверждения](bundles/TRN-03.md) | B135, B136, B137 | — | L | K3 |
| [FED-01 — Grain, cell lineage, внутренние имена и CONSENSUS](bundles/FED-01.md) | B138, B140, B141, B145 | — | L | K2 |
| [FED-02 — Устойчивый bounded audit, typed-empty и один indexing](bundles/FED-02.md) | B139, B142, B143, B144 | FED-01 | L | K2 |
| [OBS-01 — Календарные периоды и потоковый fallback без повторного префикса](bundles/OBS-01.md) | B146, B147 | — | L | K2 |
| [CAS-01 — First-writer, честная ref и bounded lock ownership](bundles/CAS-01.md) | B150, B151, B153 | — | L | K2 |
| [CAS-02 — Сначала проверенный transfer, затем публикация inventory](bundles/CAS-02.md) | B148, B149 | CAS-01 | L | K2 |
| [CAS-03 — Одна проверка bytes и bounded batch verification](bundles/CAS-03.md) | B152, B154, B155 | CAS-01 | L | K2 |
| [FUN-01 — Версионный ticket и одинаковое full/split продолжение](bundles/FUN-01.md) | B156, B158, B159 | CTL-01 | L | K3 |
| [FUN-02 — Изоляция reduced-config и правдивый результат воронки](bundles/FUN-02.md) | B157, B160, B162, B165 | FUN-01 | L | K3 |
| [FUN-03 — Текущее знание, calibration routing и pre-commit ограничение](bundles/FUN-03.md) | B161, B163, B164 | FUN-02 | L | K3 |
| [BKT-01 — Фактический historical view, тип прогноза и реплики](bundles/BKT-01.md) | B166, B169, B170 | — | L | K3 |
| [BKT-02 — Полнота сравнения, nominal coverage и micro/macro](bundles/BKT-02.md) | B167, B168, B171 | BKT-01 | L | K3 |
| [BKT-03 — Описательное смещение и честный статистический backend](bundles/BKT-03.md) | B172, B173 | BKT-02 | L | K3 |
| [BKT-04 — Только выбранные CV-разбиения и разрешённая bootstrap-статистика](bundles/BKT-04.md) | B174, B175 | — | L | K3 |
| [CAL-01 — Наблюдения, календарная ось и заполнение без фиктивной опоры](bundles/CAL-01.md) | B176, B177, B178 | — | N | K4 |
| [CAL-02 — Один effective loss: оси, два уровня весов и masked scale](bundles/CAL-02.md) | B179, B180, B181, B182 | CAL-01 | N | K4 |
| [CAL-03 — Несколько стартов: span lifecycle и пригодность выбора](bundles/CAL-03.md) | B183, B195 | CAL-02 | N | K4 |
| [CAL-04 — Последний итерат, единый финальный forward и Hessian reuse](bundles/CAL-04.md) | B184, B196, B203 | CAL-03 | N | K4 |
| [CAL-05 — Неактивный механизм не вычисляется как активный](bundles/CAL-05.md) | B185 | — | N | K4 |
| [CAL-06 — Tied-параметры и неизменный масштаб условного закона](bundles/CAL-06.md) | B197, B198 | CAL-04, UQP-02 | N | K4 |
| [UQS-01 — Summary, интервалы и независимые информационные единицы](bundles/UQS-01.md) | B199, B200, B201, B202 | UQP-02, CAL-06 | N | K4 |
| [UQP-01 — Настоящая функция отклика и полный effective call](bundles/UQP-01.md) | B186, B189, B190, B191 | — | N | K4 |
| [UQP-02 — Оси covariance, совместный закон и эмпирический carrier](bundles/UQP-02.md) | B187, B188, B192 | UQP-01 | N | K4 |
| [UQP-03 — Точность функционала, остановка MC и непокрытая область](bundles/UQP-03.md) | B193, B194 | UQP-02 | N | K4 |
| [CAU-01 — Standard DiD: допустимый дизайн, covariance и уровни CI](bundles/CAU-01.md) | B204, B205, B206 | — | N | K5 |
| [CAU-02 — Staggered DiD: единицы, H0 и anticipation](bundles/CAU-02.md) | B207, B208, B209 | CAU-01 | N | K5 |
| [CAU-03 — RDD: честная RBC capability и линейная память WLS](bundles/CAU-03.md) | B210, B211 | CAU-01 | N | K5 |
| [CAU-04 — DoWhy: реальный estimand и point-only результат](bundles/CAU-04.md) | B212, B213 | — | L | K5 |
| [GRF-01 — Правильные static ADMG m-separation и perfect-do](bundles/GRF-01.md) | B216, B217 | — | L | K5 |
| [GRF-02 — Неизменяемый граф, mixed-edge export и версии кэша](bundles/GRF-02.md) | B219, B220 | GRF-01 | L | K5 |
| [GRF-03 — Известные направления и явная временная/частичная семантика](bundles/GRF-03.md) | B214, B218 | GRF-02 | L | K5 |
| [SCM-01 — Наблюдаемые корни и выполняемый nonlinear payload](bundles/SCM-01.md) | B221, B222 | GRF-02 | N | K5 |
| [SCM-02 — Factual abduction и две явные стороны attribution](bundles/SCM-02.md) | B215, B223 | SCM-01 | N | K5 |
| [SCM-03 — Активный query-plan и сохранённый stochastic law](bundles/SCM-03.md) | B224, B225 | SCM-02, GRF-01, GRF-02 | N | K5 |
