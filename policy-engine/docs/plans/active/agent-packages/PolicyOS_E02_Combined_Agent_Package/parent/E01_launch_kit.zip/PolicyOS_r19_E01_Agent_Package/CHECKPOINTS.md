# Укрупнённые приёмки и полное соответствие T1–T21

Шесть окон — не шесть full CI. Сценарии выполняются через реальные проектные API на малых inputs. Historical probes не являются их заменой. Необязательный неиспользуемый профиль получает явное not-used/unsupported, не выдуманный pass.

## K1 — Первый полезный цикл

**Связанные пакеты:** CYC-01, SIM-01, SIM-02, SIM-03, CYC-02, CYC-03, CYC-04, CYC-05, EMP-01, SEL-01, CMP-01, CMP-02, CMP-03, JIT-01.

I1 фиксирует интеграционный SHA и последовательно запускает выбранные native проверки готового блока; I2 проверяет семантику межконтрактных outputs. Входные размеры и научный объект сохранены; никаких parallel large suites. На выходе: exact commands, counts, logs, actual environment, passed/failed/not-run и список конкретно принимаемых B-карточек.

## K2 — Сохранность, данные и ресурсы

**Связанные пакеты:** SCL-01, STA-01, STA-02, EXE-01, RES-01, RES-02, RES-03, EXE-02, RUN-01, RUN-02, RUN-03, DUR-01, DUR-02, RES-04, LLM-01, LLM-02, ING-01, ING-02, ING-03, NET-01, NET-02, WIRE-01, FED-01, FED-02, OBS-01, CAS-01, CAS-02, CAS-03.

I1 фиксирует интеграционный SHA и последовательно запускает выбранные native проверки готового блока; I2 проверяет семантику межконтрактных outputs. Входные размеры и научный объект сохранены; никаких parallel large suites. На выходе: exact commands, counts, logs, actual environment, passed/failed/not-run и список конкретно принимаемых B-карточек.

## K3 — Поиск, история и проверка

**Связанные пакеты:** STP-01, DOE-01, DOE-02, DOE-03, STR-01, OPT-01, OPT-02, OPT-03, OPT-04, CTL-01, CTL-02, TRN-01, TRN-02, TRN-03, FUN-01, FUN-02, FUN-03, BKT-01, BKT-02, BKT-03, BKT-04.

I1 фиксирует интеграционный SHA и последовательно запускает выбранные native проверки готового блока; I2 проверяет семантику межконтрактных outputs. Входные размеры и научный объект сохранены; никаких parallel large suites. На выходе: exact commands, counts, logs, actual environment, passed/failed/not-run и список конкретно принимаемых B-карточек.

## K4 — Калибровка и uncertainty

**Связанные пакеты:** FIT-01, CAL-01, CAL-02, CAL-03, CAL-04, CAL-05, CAL-06, UQS-01, UQP-01, UQP-02, UQP-03.

I1 фиксирует интеграционный SHA и последовательно запускает выбранные native проверки готового блока; I2 проверяет семантику межконтрактных outputs. Входные размеры и научный объект сохранены; никаких parallel large suites. На выходе: exact commands, counts, logs, actual environment, passed/failed/not-run и список конкретно принимаемых B-карточек.

## K5 — Причинный граф и query

**Связанные пакеты:** CAU-01, CAU-02, CAU-03, CAU-04, GRF-01, GRF-02, GRF-03, SCM-01, SCM-02, SCM-03.

I1 фиксирует интеграционный SHA и последовательно запускает выбранные native проверки готового блока; I2 проверяет семантику межконтрактных outputs. Входные размеры и научный объект сохранены; никаких parallel large suites. На выходе: exact commands, counts, logs, actual environment, passed/failed/not-run и список конкретно принимаемых B-карточек.

## K6 — Ограниченная итоговая поставка

**Связанные пакеты:** CYC-01, SIM-01, SIM-02, SIM-03, CYC-02, CYC-03, CYC-04, CYC-05, EMP-01, SCL-01, SEL-01, CMP-01, CMP-02, CMP-03, JIT-01, FIT-01, STA-01, STA-02, EXE-01, RES-01, RES-02, RES-03, EXE-02, RUN-01, RUN-02, RUN-03, DUR-01, DUR-02, RES-04, STP-01, LLM-01, LLM-02, ING-01, ING-02, ING-03, NET-01, NET-02, WIRE-01, DOE-01, DOE-02, DOE-03, STR-01, OPT-01, OPT-02, OPT-03, OPT-04, CTL-01, CTL-02, TRN-01, TRN-02, TRN-03, FED-01, FED-02, OBS-01, CAS-01, CAS-02, CAS-03, FUN-01, FUN-02, FUN-03, BKT-01, BKT-02, BKT-03, BKT-04, CAL-01, CAL-02, CAL-03, CAL-04, CAL-05, CAL-06, UQS-01, UQP-01, UQP-02, UQP-03, CAU-01, CAU-02, CAU-03, CAU-04, GRF-01, GRF-02, GRF-03, SCM-01, SCM-02, SCM-03.

I1 фиксирует интеграционный SHA и последовательно запускает выбранные native проверки готового блока; I2 проверяет семантику межконтрактных outputs. Входные размеры и научный объект сохранены; никаких parallel large suites. На выходе: exact commands, counts, logs, actual environment, passed/failed/not-run и список конкретно принимаемых B-карточек.

## Покрытие исходных T-сценариев

| Сценарий | Пакеты, реализующие его границы |
|---|---|
| T1 | CYC-01 SIM-01 SIM-02 SIM-03 CYC-02 SEL-01 |
| T2 | CYC-03 CYC-04 CYC-05 |
| T3 | RES-03 RUN-01 RUN-02 RUN-03 DUR-01 DUR-02 CYC-04 |
| T4 | CMP-01 CMP-02 CMP-03 JIT-01 |
| T5 | STA-01 STA-02 RES-01 |
| T6 | RES-01 RES-02 RES-04 EXE-02 DUR-02 |
| T7 | ING-01 ING-02 ING-03 NET-01 |
| T8 | NET-01 NET-02 WIRE-01 RUN-03 |
| T9 | DOE-01 DOE-02 DOE-03 STR-01 |
| T10 | OPT-01 OPT-02 OPT-03 OPT-04 |
| T11 | CTL-01 CTL-02 STP-01 |
| T12 | TRN-01 TRN-02 TRN-03 |
| T13 | FED-01 FED-02 OBS-01 |
| T14 | CAS-01 CAS-02 CAS-03 |
| T15 | FUN-01 FUN-02 FUN-03 |
| T16 | BKT-01 BKT-02 BKT-03 BKT-04 |
| T17 | CAL-01 CAL-02 CAL-03 CAL-04 |
| T18 | CAL-05 UQP-01 UQP-02 UQP-03 |
| T19 | CAL-03 CAL-04 CAL-06 UQS-01 |
| T20 | CAU-01 CAU-02 CAU-03 CAU-04 GRF-03 SCM-02 |
| T21 | GRF-01 GRF-02 GRF-03 SCM-01 SCM-02 SCM-03 |

Дополнительные source-guided gates: EMP-01 — перед соответствующими эмпирическими helpers; SCL-01 — разрешённый bounded search; FIT-01 — нативный nuisance fit в K4. Полный исходный текст всех T-сценариев сохранён в исторических разделах основного документа.
