# Начать здесь — PolicyOS r19-E01

**84 пакета реализации; 225 исходных B-карточек; 8 отдельных пакетов развития EVO/S.**

Главный обновлённый документ: [PolicyOS_All_Findings_S02_r19_E01_Agent_Bundles.md](PolicyOS_All_Findings_S02_r19_E01_Agent_Bundles.md). В нём карточки сгруппированы по агентным задачам; их текст сохранён дословно. Все оставшиеся разделы r19 также сохранены, а непрерывный оригинал лежит в `source/`.

Для начала работы передайте Sol [SOL_ORCHESTRATOR.md](SOL_ORCHESTRATOR.md), [EXECUTION_GUIDE.md](EXECUTION_GUIDE.md), [BUNDLE_INDEX.md](BUNDLE_INDEX.md) и `bundle_manifest.json`. Исполнителю выдаётся только TEAM_RULES.md плюс один packet из `bundles/`, branch/worktree/base SHA. Проверяющему — packet, exact patch и REVIEWER_PROMPT.md. Два интегратора используют WRITE_OWNERSHIP.md, CROSS_BOUNDARY_MATRIX.md и CHECKPOINTS.md.

**Режим команды:** обычно 9 implementers +3 reviewers +2 integrators =14 Luna; допустимо 12–16. **Нагрузка Mac:** максимум 2 лёгких тестовых jobs либо 1 native/numerical/milestone job на весь Mac. Модели/агенты продолжают работать, пока тестовая очередь занята. Большие проверки объединены в 6 окон K1–K6. Это стартовая политика, не измеренный benchmark машины.

Первый набор: CYC-01, SEL-01, STA-01, ING-01, DOE-01, OPT-01, CAS-01, CAL-01, GRF-01. Далее — динамическая ready queue, не ожидание всех участников волны.

`bundle_manifest.json` — статический план, не конфиг Codex. `templates/` — пустые примеры handoff/ledger. QA в `qa/` относится только к целостности этого комплекта: **ни код PolicyOS, ни пользовательский Mac, ни native CI здесь не испытывались**. Current repository HEAD не перечитывался. Исторические research ZIP и code/probe файлы не входят в комплект; передан только фактически доступный r19 Markdown и новый план.

Проверка комплекта без third-party packages: `python3 verify_plan.py`. Она читает текст/JSON и сверяет распределение, DAG, source preservation и ссылки; не запускает PolicyOS и не создаёт нагрузки модели/CI.
