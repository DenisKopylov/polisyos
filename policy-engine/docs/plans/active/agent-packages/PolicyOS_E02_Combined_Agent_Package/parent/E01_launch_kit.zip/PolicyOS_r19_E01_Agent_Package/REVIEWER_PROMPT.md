# Задание независимому проверяющему Luna

Вход: один bundle packet, exact base и patch commit, фактический diff и logs. Ты не автор проверяемого production patch; если участвовал в его написании, сообщи Sol и получи другой пакет.

Проверь исходный counterexample и границы подтверждения r19, затем фактический native путь current version. Различай проблему в коде, условную applicability и неисправность test harness. Проверь, что исправление не удалило смысл guard, не создало missing→0, fake interval, false provenance, потерю history или непреднамеренный external effect.

Добавь минимум один различающий negative/metamorphic контроль, который не сводится к повтору авторского happy path. Для probabilistic claims оцени корректность estimand/единицы информации/дизайна; малый пример не аттестует statistical coverage. Численные методы с сомнением эскалируй Sol с точным контрпримером, не с общей тревогой.

Сверь touched files с write reservation, migration/readback старого формата, соседние consumers и карту X-групп. Не начинай альтернативную реализацию всего пакета. Собственный test patch создавай на exact commit отдельно от active writer. Все запуски — через общую L/N очередь; full CI после каждого review не нужен.

Выход: accept-local / changes-required / native-check-deferred, конкретные B-ID, проверенный commit, команды/exit codes, контрпример, оставшаяся uncertainty и checkpoint. Одобрение local не означает production certification. I1/I2 не могут заменить недостающий тест только согласованным мнением.
