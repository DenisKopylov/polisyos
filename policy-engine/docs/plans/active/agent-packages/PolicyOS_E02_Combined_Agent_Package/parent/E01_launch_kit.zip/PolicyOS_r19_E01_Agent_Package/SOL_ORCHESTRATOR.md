# Master-prompt Sol — PolicyOS r19-E01

Организуй реализацию готового плана r19-E01, не начинай новый общий аудит и не перераспределяй 225 пунктов заново. Основные данные: bundle_manifest.json, dependency_graph.json, CROSS_BOUNDARY_MATRIX.md и packets bundles/. Полный source r19 сохранён в source/; его findings имеют разную доказанность. Репозиторий: DenisKopylov/polisyos; baseline аудита 5fd3ebcc15637e98bbd4938de5d62ee5004504a8, фактический стартовый HEAD должен быть прочитан в твоём checkout.

Команда: по умолчанию 14 Luna =9 implementers +3 reviewers +2 integrators. Начни с 12 при фактическом ограничении клиентских slots или отсутствии готовой работы; расширяй до 16 как 10+4+2 только при отсутствии backlog review. Sol сверху в этот счёт не включён. Роли Sol/Luna выбирай штатным текущим клиентом; JSON плана не является конфигурацией Codex.

Назначь I1 владельцем SETUP-01, integration branch и общей очереди test jobs; I2 — version/interface compatibility и cross-boundary review. SETUP-01 выполняется один раз: repository instructions, текущий SHA, Python/lock/native environment, правильная source-import привязка worktree, один маленький baseline smoke и workspace-local outputs. Не создавай 16 полных окружений и не трать цикл на мониторинг hardware.

После setup выдай первые 9 code packets: CYC-01, SEL-01, STA-01, ING-01, DOE-01, OPT-01, CAS-01, CAL-01, GRF-01. Для 8 оставь CAL-01 следующим; возможный 10-й — LLM-01. У каждого свой base SHA, branch/worktree, утверждённый write-set и reviewer неавтор. Дальше работай ready queue: завершился пакет — передавай следующему агенту умеренный готовый блок, не жди завершения всей волны. При busy hotspot выбирай другую область.

Глобальная нагрузка Mac M2/16GB: максимум 2 лёгких L jobs либо 1 N/C, включая все descendants. Никаких -n auto/full pytest/watchers/parallel installs. Число рассуждающих агентов не равно числу вычисляющих процессов. Пока ждут тесты, агенты пишут код, читают consumers или делают review. Только I1 реагирует на реальное ухудшение отзывчивости/OOM; не заставляй всех проверять load перед каждым шагом.

Не запускай большие suites на каждом пакете. Маленькая native regression и сохранившиеся negative controls нужны по мере реализации. Укрупнённые проверки объединяй в K1–K6 на зафиксированном SHA; не переноси обязательный короткий consumer check в неопределённый финал. Сопоставимость вычисления важнее raw speedup. Непроверенная платформа/метод остаётся явным остатком, не успешной аттестацией.

Управляй отдельно depends_on, write conflicts и activation prerequisites. Список related findings не создаёт новую hard dependency. Не плодить writers общего carrier. I2 может уточнить план по actual HEAD с конкретной записью, не отменяя необходимые bindings ради parallelism. Изменённые consumer dependencies требуют адресного retest, не автоматического полного CI.

Принимай handoff по каждому B-ID. Различай исправлено и проверено, уже исправлено раньше, неприменимо на выбранном пути, не воспроизведено, нет окружения, отложен native тест и принято явное ограничение режима. Последнее не означает реализации отсутствующей capability. Не считать 225 карточек обязательными production incidents или очередью перед первым результатом.

Около 4 patches без первого review — сигнал временно направить свободные роли на проверку, а не создавать новых writers. Держи один малый ledger active/reservations/test queue/accepted SHA/next-ready. Каждый worker отдаёт свой handoff; только I1/Sol обновляют центральный ledger. Merge последовательный, branch/code не меняются во время чтения тестом.

S01–S08 представлены EVO-пакетами; по умолчанию не расширяй ими кодовую remediation-очередь без отдельного принятого scope. Доведи первый реальный conditional route до positive output, readback, meaningful second iteration и recovery. После K6 выдай точный список B-исходов, native coverage, remaining gaps и готового сценария — не декларацию универсальной готовности.
