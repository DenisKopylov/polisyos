# Очереди общих production-файлов

Порядок ниже — совместимый с DAG начальный порядок. Это не монолитные bundles: каждый ID остаётся самостоятельным заданием. Sol может выбирать иной допустимый порядок при сохранении dependencies и текущих контрактов. Не требовать file lock для обычного чтения собственного зафиксированного base; перед приёмкой проверять drift затронутых read-contracts.

| Исторический файл | Очередь потенциальных writers |
|---|---|
| `policy-engine/src/polisyos/runtime/quality/generation_cycle.py` | CYC-01 → SIM-01 → CYC-03 → EMP-01 → CYC-04 → CYC-02 → CYC-05 → RES-03 |
| `policy-engine/src/polisyos/runtime/quality/recursive_generation_cycle.py` | CYC-01 → SIM-01 → CYC-03 → CYC-02 → CYC-05 |
| `policy-engine/src/polisyos/foundry/calibration/calibrator.py` | CAL-02 → CAL-03 → CAL-04 → CAL-06 |
| `policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_query.py` | GRF-03 → SCM-01 → SCM-02 → SCM-03 |
| `policy-engine/src/polisyos/runtime/http/services/control/run_lifecycle.py` | CYC-01 → CYC-04 → CYC-05 → RES-03 |
| `policy-engine/src/polisyos/scientist/orchestration/engine/async_executor.py` | RES-02 → EXE-01 → RES-01 → EXE-02 |
| `policy-engine/src/polisyos/fabric/data_plane/streaming.py` | NET-01 → ING-02 → ING-03 |
| `policy-engine/src/polisyos/foundry/methods/backends/async_chain_executor.py` | CMP-01 → CMP-02 → RES-03 |
| `policy-engine/src/polisyos/foundry/methods/backends/chain_executor.py` | CMP-01 → CMP-02 → RES-04 |
| `policy-engine/src/polisyos/foundry/methods/catalog/causal/admg_ops.py` | GRF-01 → GRF-02 → GRF-03 |
| `policy-engine/src/polisyos/foundry/uncertainty/monte_carlo.py` | UQP-01 → UQP-02 → UQP-03 |
| `policy-engine/src/polisyos/runtime/quality/joint_simulation_horizon.py` | SIM-01 → SIM-02 → SIM-03 |
| `policy-engine/src/polisyos/scientist/methods/backtesting/orchestrator.py` | BKT-01 → BKT-02 → BKT-03 |
| `policy-engine/src/polisyos/scientist/methods/search/funnel/orchestrator.py` | FUN-01 → FUN-02 → FUN-03 |
| `policy-engine/src/polisyos/scientist/orchestration/engine/idempotency.py` | STA-01 → STA-02 → RES-01 |
| `policy-engine/src/polisyos/scientist/orchestration/engine/retry.py` | RUN-01 → RUN-02 → RUN-03 |
| `policy-engine/src/polisyos/fabric/connectors/federation/composer.py` | FED-01 → FED-02 |
| `policy-engine/src/polisyos/fabric/connectors/federation/types.py` | FED-01 → FED-02 |
| `policy-engine/src/polisyos/fabric/data_plane/cursor_store.py` | ING-01 → ING-02 |
| `policy-engine/src/polisyos/fabric/data_plane/modes.py` | ING-01 → ING-03 |
| `policy-engine/src/polisyos/foundry/calibration/measurement.py` | CAL-01 → CAL-02 |
| `policy-engine/src/polisyos/foundry/calibration/uncertainty_adapter.py` | CAL-06 → UQS-01 |
| `policy-engine/src/polisyos/foundry/methods/catalog/causal/_common.py` | CAU-01 → CAU-04 |
| `policy-engine/src/polisyos/foundry/methods/catalog/causal/did.py` | CAU-01 → CAU-02 |
| `policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_fit.py` | GRF-03 → SCM-01 |
| `policy-engine/src/polisyos/foundry/methods/catalog/causal/rdd.py` | CAU-01 → CAU-03 |
| `policy-engine/src/polisyos/foundry/methods/catalog/causal/twin_network_query.py` | SCM-01 → SCM-02 |
| `policy-engine/src/polisyos/foundry/methods/components/composer.py` | CMP-01 → CMP-02 |
| `policy-engine/src/polisyos/foundry/methods/components/semantic_validator.py` | CMP-02 → CMP-03 |
| `policy-engine/src/polisyos/foundry/uncertainty/covariance.py` | UQP-02 → CAL-06 |
| `policy-engine/src/polisyos/foundry/uncertainty/delta.py` | UQP-01 → UQP-02 |
| `policy-engine/src/polisyos/foundry/uncertainty/dispatcher.py` | UQP-01 → UQP-02 |
| `policy-engine/src/polisyos/ir/analytics/calibration.py` | CAL-01 → CAL-06 |
| `policy-engine/src/polisyos/ir/analytics/causal_graph.py` | GRF-02 → GRF-03 |
| `policy-engine/src/polisyos/ir/analytics/causal_queries.py` | SCM-02 → SCM-03 |
| `policy-engine/src/polisyos/runtime/http/services/control/generation_cycle.py` | CYC-01 → CYC-05 |
| `policy-engine/src/polisyos/scientist/methods/autotune/models.py` | OPT-01 → OPT-02 |
| `policy-engine/src/polisyos/scientist/methods/autotune/runtime.py` | OPT-02 → OPT-04 |
| `policy-engine/src/polisyos/scientist/methods/doe/analysis.py` | DOE-02 → DOE-03 |
| `policy-engine/src/polisyos/scientist/methods/doe/designs.py` | DOE-01 → DOE-02 |
| `policy-engine/src/polisyos/scientist/methods/doe/sampling.py` | DOE-01 → DOE-02 |
| `policy-engine/src/polisyos/scientist/methods/search/stopping.py` | STP-01 → CTL-01 |
| `policy-engine/src/polisyos/scientist/methods/search/strategies/base.py` | OPT-03 → CTL-02 |
| `policy-engine/src/polisyos/scientist/methods/search/strategies/space.py` | OPT-02 → CTL-02 |
| `policy-engine/src/polisyos/scientist/methods/search/strategies/transfer.py` | TRN-02 → TRN-01 |
| `policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py` | RES-02 → RES-01 |
| `policy-engine/src/polisyos/scientist/orchestration/engine/executor.py` | STA-01 → RES-01 |
| `policy-engine/src/polisyos/scientist/orchestration/llm/factory.py` | LLM-01 → LLM-02 |
| `policy-engine/src/polisyos/scientist/orchestration/llm/prompt_cache.py` | LLM-01 → LLM-02 |
