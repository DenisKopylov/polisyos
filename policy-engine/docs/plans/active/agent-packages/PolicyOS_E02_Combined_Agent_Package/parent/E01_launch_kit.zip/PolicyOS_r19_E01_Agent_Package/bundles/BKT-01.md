<a id="bundle-bkt-01"></a>

# BKT-01 — Фактический historical view, тип прогноза и реплики

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B166, B169, B170**. Локальный класс: **L**. Укрупнённая приёмка: **K3**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** нет; после общего SETUP-01 и короткой проверки current base. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Связать фактический Scientist input с pre-cutoff view и временной осью. Принимать trajectory/CI в их реальном estimand/time contract; scalar становится constant forecast только явно. Передать backend объявленный план повторов.

**Минимальные различающие проверки.** Для[1,2,900,901]/cutoff=2 runner реально получает префикс. Scalar ATE=7 не размножается в forecast/CI без контракта; явный constant profile работает. n=1/n=7 меняют действительный план либо дают capability-result. PROVIDED не запускает лишних симуляций.

**Не менять / не считать исправлением.** Не вставлять массив в случайное поле state, не забывать derived-feature leakage и не считать одну cutoff-date доказательством фактически применённой маски.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_bkt_01.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T16. **Cross-boundary review:** X08, X13. **Activation rules:** общие правила scope/приёмки.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/scientist/methods/backtesting/orchestrator.py` |
| Production write candidate | `policy-engine/src/polisyos/scientist/methods/backtesting/masking.py` |
| Production write candidate | `policy-engine/src/polisyos/scientist/methods/backtesting/plan.py` |
| Read / consumer contract | `policy-engine/src/polisyos/ir/analytics/backtest.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/methods/backtesting/evaluator.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/governance/backtest_matrix.py` |

**Не писать одновременно с:** BKT-02, BKT-03. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B166 lines=4316-4327 sha256=fca923e26ad0c81b5a1097f0c5b09b3a85434faf70826001b2e5d6c676e8a541 -->
## B166. Историческая маска вычислена, но не связана с фактическим входом Scientist

Основание и область: `OutcomeMasker.mask`, `HistoricalValidationPlan`, `_run_single_scenario` и `_predict_with_scientist`. Маска получает истинную последовательность и `intervention_step`; Scientist затем вызывается с отдельным `plan.scientist_state`. В эту структуру не передаётся полученный `masked_data` и не сверяется соответствие её ссылок требуемому историческому срезу. Параметр используется только в fallback на naive. Кроме того, при `intervention_step=None` masker возвращает данные без изменения, даже если план содержит дату интервенции и длину предшествующего периода. [C16.R01, R04, R05]

**Проверка.** На входе `[1, 2, 900, 901]` и cutoff 2 настоящий masker дал `[1, 2]`, исходную структуру не изменил. Но run_experiment-фикстура получила отдельно переданное состояние с полным рядом и ссылкой `unmasked-v1`; результат остался `degraded=False`. План только с датой и pre-periods прошёл валидацию, маска сохранила все четыре значения. Контроль явной привязки текущего вида передал только префикс. Это доказательство отсутствия связи на прочитанном переходе, не утверждение, что реальный Scientist в production прочитал эти тестовые поля.

**Рекомендуемое решение.** Разрешить историческую границу по объявленной оси времени и материализовать либо адресовать неизменяемый допустимый срез у существующего владельца данных. Тот же срез и его идентичность должны потребляться вычислительным запросом. Имеющийся независимо подготовленный `scientist_state` допустим, когда соответствие срезу действительно проверено. Для уже предоставленных прогнозов нужен иной контракт происхождения; их не обязательно повторно вычислять.

Не подставлять массив в произвольное поле и не считать маскирование одного target доказательством отсутствия утечки через производные признаки. Отсутствие временной границы не означает автоматически нулевое обучение: допустим явный режим «данные уже отсечены» с проверяемым основанием. Не требовать полной копии всей базы на каждый сценарий.

**Приёмка и приоритет.** T16 должен показать фактические ссылки, дошедшие до вычислительного backend, и недоступность post-cutoff исходов в этом режиме. Высокий смысловой приоритет для Scientist-replay; связующая работа умеренная. Локальная передача корректного вида — контроль дизайна, не установленный патч. Связь с B166 не заменяет прежние проверки изоляции state и контекста.

<!-- END_SOURCE_CARD B166 -->

<!-- SOURCE_CARD B169 lines=4352-4363 sha256=8f7c03d7a40a2faa62a4b0c4bc41b43510c9f5c35941ca50ec1fb8dc88fae26b -->
## B169. Scalar и единственный интервал превращаются в траекторию без подтверждения предмета

Основание и область: Scientist-адаптер размножает scalar из `metrics_ref` до длины ground truth. Аналогично один `confidence_interval` из uncertainty-envelope копируется на весь горизонт; остальная семантика envelope не проверяется. Длинный список предсказаний тихо обрезается по горизонту. [C16.R01]

**Проверка.** Фикстура метрики 20 и envelope `[19,21]` с декларацией `estimand='mean_ate'`, nominal 0,8 породила прогноз `[20,20,20]` и три одинаковых интервала для запроса 0,95, без degraded-флага. Четырёхточечный список на трёхточечном запросе вернулся без последнего элемента и без warning. Контроль настоящих трёх прогнозов с тремя соответствующими интервалами дал нулевую ошибку и полное покрытие.

**Рекомендуемое решение.** Связать измеряемую величину, единицы, baseline, origin/cutoff, временные координаты и реплику с каждой прогнозной траекторией. Scalar может означать постоянный прогноз, средний эффект, агрегат за период или показатель качества; эти значения не взаимозаменяемы. Размножение разрешать только как явно заявленную и допустимую операцию данного producer. Срез горизонта делать по совпадающим координатам и отражать в provenance.

Интервал среднего эффекта и интервал будущего наблюдения — разные объекты. Следует переиспользовать настоящий набор draws или соответствующие summary, а не автоматически перезапускать модель и не придумывать дисперсию. Корректная стационарная модель с постоянным прогнозом остаётся разрешённой. [C16.E03]

**Приёмка и приоритет.** Прямой scalar без нужной семантики не получает неподтверждённый временной статус; явная constant-forecast модель проходит; длина и координаты не теряются; неправильный estimand даёт адресный пробел. Высокий приоритет перед интерпретацией Scientist-output как исторического прогноза. Истинная семантика production metrics/envelope в этом проходе не установлена: нарушение показано на допускаемых адаптером словарях, не на реальной модели.

<!-- END_SOURCE_CARD B169 -->

<!-- SOURCE_CARD B170 lines=4364-4375 sha256=ebd468778c34a525226f1631f17dbb9eb3e040a6c9a5d96d038620576528181a -->
## B170. Число запрошенных повторений не влияет на Scientist-вызов

Основание и область: HistoricalValidationPlan содержит проверяемый `n_simulation_runs>=1`. `_run_single_scenario` обращается к `_predict` один раз; `_predict_with_scientist` передаёт seed, но не число повторений и не выполняет соответствующий цикл. [C16.R01, R05]

**Проверка.** Планы с n_simulation_runs=1 и 7 породили по одному вызову run_experiment-фикстуры с идентичными структурами и `random_seed=12`. Ноль повторений правильно отвергался валидатором. Это доказывает, что именно данный параметр не изменяет dispatch; не устанавливает, сколько внутренних Monte Carlo draws мог бы выполнить настоящий workflow по другим настройкам.

**Рекомендуемое решение.** Определить, что параметр считает: независимые исполнения, случайные реплики модели, bootstrap или иной объект. Провести число и план случайных потоков к существующему владельцу вычисления либо реализовать ограниченный набор реплик с сохранением requested/started/completed/failed и настоящей стоимости.

Для PROVIDED-режима допустим отдельный контракт уже выполненных реплик; не надо повторно запускать внешний прогноз только из-за поля в общей модели. Точный cache-hit одной реализации нельзя засчитать независимой новой репликой. Необходимо сохранить результирующее распределение либо достаточные статистики, а не просто усреднить всё в scalar и снова размножить по времени.

**Приёмка и приоритет.** Один и семь повторений отличаются реальным планом либо явным supported/unsupported результатом; одна неудача не скрывает знаменатель; ограничение бюджета действует до дорогой работы. Средний приоритет: для первого честного одиночного расчёта можно явно принять n=1, не блокируя весь продукт. Нельзя обещать многократную проверку на основе одной одинаковой dispatch-структуры.

<!-- END_SOURCE_CARD B170 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**C16.R01. Историческая оркестрация: masking, Scientist, интервалы, aggregate и t-test.** `policy-engine/src/polisyos/scientist/methods/backtesting/orchestrator.py`. Окно чтения 1–600; файл мог быть короче запрошенного окна. Локально — только выбранные определения; полного blob нет. Git blob `f2cf1389036b1ad8d9ec8c92a0400b56f5096210`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/backtesting/orchestrator.py).

**C16.R02. Сопоставление прогнозов и интервальное покрытие.** `policy-engine/src/polisyos/scientist/methods/backtesting/evaluator.py`. Прочитан полный файл. Полный локальный blob сверен; project-imports заменяются в harness. Git blob `497f6de446e7d27717775595edc87588243a89a1`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/backtesting/evaluator.py).

**C16.R04. OutcomeMasker: фактический temporal cutoff.** `policy-engine/src/polisyos/scientist/methods/backtesting/masking.py`. Прочитан полный файл. Полный локальный blob сверен; project-imports заменяются в harness. Git blob `0df32cbc5495950d97634e5c7c6a117d4104750d`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/backtesting/masking.py).

**C16.R05. Публичный HistoricalValidationPlan.** `policy-engine/src/polisyos/scientist/methods/backtesting/plan.py`. Прочитан полный файл. Полный локальный blob сверен; project-imports заменяются в harness. Git blob `3c037bfdb3929142e06b4ce99287188979dc9bc6`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/backtesting/plan.py).

**C16.R06. DTO результата и настоящие конечные числовые проверки.** `policy-engine/src/polisyos/ir/analytics/backtest.py`. Окно чтения 1–330; файл мог быть короче запрошенного окна. Локально — только выбранные определения; полного blob нет. Git blob `90837bffda3e8408b7ab36919fde75792fb88b24`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/ir/analytics/backtest.py).

**C16.R12. Настоящий потребитель: BacktestMatrixRunner.** `policy-engine/src/polisyos/scientist/governance/backtest_matrix.py`. Окно чтения 1–245; файл мог быть короче запрошенного окна. В данном проходе не исполнялся. Git blob `d4184f6519d665bf1b38ff912ca6abc8969b4ceb`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/governance/backtest_matrix.py).

**C16.E03. statsmodels: интервалы среднего прогноза и нового наблюдения.** Первичная документация просмотрена 18 сентября 2026 года; это методологическое основание, не свидетельство запуска PolicyOS. [Документация](https://www.statsmodels.org/stable/generated/statsmodels.regression.linear_model.RegressionResults.get_prediction.html).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
