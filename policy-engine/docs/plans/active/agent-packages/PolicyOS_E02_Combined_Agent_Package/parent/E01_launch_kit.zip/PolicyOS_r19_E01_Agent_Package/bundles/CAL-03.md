<a id="bundle-cal-03"></a>

# CAL-03 — Несколько стартов: span lifecycle и пригодность выбора

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B183, B195**. Локальный класс: **N**. Укрупнённая приёмка: **K4**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** CAL-02. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Создавать свежий span на каждый restart либо один правильный внешний span. При выборе отдельно валидировать loss, отсутствие Hessian, известную вырожденность и удовлетворительную диагностику. Сохранять полезный ограниченный вариант, не приписывая ему прохождение фильтра.

**Минимальные различающие проверки.** Два старта с OTel и без него проходят; повтор одноразового context manager отсутствует. NaN-loss не выигрывает из-за порядка списка. condition=inf не считается отсутствием диагностики, finite-large и unknown имеют свои результаты. Проверка выбора на таблице кандидатов; один маленький настоящий Hessian в K4.

**Не менять / не считать исправлением.** Не выключать observability или multi-start, не запрещать все ill-conditioned модели и не исправлять уже правильную raw-Hessian диагностику вместо потребителя.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_cal_03.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T17, T19. **Cross-boundary review:** X12. **Activation rules:** общие правила scope/приёмки.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/foundry/calibration/multi_start.py` |
| Production write candidate | `policy-engine/src/polisyos/foundry/calibration/calibrator.py` |
| Read / consumer contract | `policy-engine/src/polisyos/foundry/calibration/hessian.py` |
| Read / consumer contract | `policy-engine/src/polisyos/foundry/execute/_internal/numeric/__init__.py` |

**Названные в r19 тематически близкие tests (не подтверждение их покрытия/запуска):**

- `policy-engine/tests/unit/foundry/calibration/test_multi_start.py`

**Не писать одновременно с:** CAL-02, CAL-04, CAL-06. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B183 lines=4595-4604 sha256=036471c121686d6b68a603fde76ce9c015a1a374d090d47465b79abcbbc00c44 -->
## B183. Включение observability делает второй старт оптимизации неисполняемым

**Наблюдение.** `Calibrator.run` создаёт `span_cm` один раз перед multi-start, затем входит в тот же объект через `with span_cm` внутри каждого старта. В режиме без наблюдаемости используется повторно пригодный `nullcontext`. Стандартный контекст span в OpenTelemetry — одноразовый; его повторный вход не эквивалентен созданию нового span. [C17.R04]

**Различающий результат.** Настоящий установленный OpenTelemetry API выполнил первый вход, а второй дал `AttributeError: '_AgnosticContextManager' object has no attribute 'args'`. Свежий context-manager на каждый старт прошёл два раза. Повторный `nullcontext` тоже прошёл оба старта, объясняя, почему неисправность может не обнаруживаться без telemetry. Оптимизатор и настоящий provider/exporter не запускались: воспроизведён именно жизненный цикл контекста. [C17.P26–P28]

**Оптимальное направление исправления.** Один внешний span на исследование и отдельные свежие child-spans на старты либо фабрика контекстов на каждую итерацию. Сохранять идентичность старта, статус и уже выполненную работу. Не ограничивать multi-start единицей и не выключать наблюдаемость как постоянный ремонт. При ошибке дополнительного exporter должна действовать объявленная политика telemetry, не автоматический отказ всей науки или сокрытие обязательного аудита.

**Приёмка и граница.** Два старта с теми же входами проходят с telemetry и без неё; заголовочный span не используется повторно. Настоящее изменение цели между стартами по-прежнему требует своей привязки. Документация Python различает одноразовые и повторно используемые context managers; не каждый произвольный переданный пользователем tracer обязан воспроизвести проблему. Находка условна включённым HPC-observability, количеством стартов более одного и таким типом контекста, а не каждым запуском калибровки. [C17.E03]

<!-- END_SOURCE_CARD B183 -->

<!-- SOURCE_CARD B195 lines=4894-4907 sha256=69b56d13bbee8d87f83987b09b991e08cf33eff2204302a3b938acef363de747 -->
## B195. Заведомо плохая обусловленность принимается как отсутствие диагностики

**Основание.** `_select_best_loss` фильтрует большие конечные condition numbers. Но при существующем Hessian с `inf` или NaN попадает в ветку «No Hessian info — accept by loss only». Известная вырожденность поэтому обходит фильтр, который действует для менее плохого конечного числа. Конечность самого `loss` до `min` также не установлена. `compute_hessian` уже корректно сохраняет `condition_number=inf` для вырожденного сырого Hessian; проблема находится в потребителе, а не в отсутствии диагностики. [C19.R01; C19.R07]

**Различающие проверки.** При threshold=10^8 вариант с loss=0,1 и condition=10^12 уступил варианту loss=0,5, condition=10. Замена первого condition на `inf` дала победу первому и строку `best_loss=0.1 (condition<1e+08)`. При loss NaN у первой записи `min` выбрал её; после перестановки впереди оказался действительный loss=0,5. Настоящий вычислитель Hessian на постоянной функции сохранил бесконечную обусловленность, несмотря на ремонт матрицы. C19-P01–P05.

**Почему важно.** Улучшенный restart может быть не выбран, а downstream получает неверное объяснение пригодности победителя. Это проявляется уже на двух стартовых состояниях.

**Рекомендуемое исправление.** Сначала проверять пригодность численного результата; отдельно различать действительную удовлетворительную диагностику, известное нарушение и отсутствие оценки. Допустимый режим выбора только по loss при отсутствующем Hessian сохраняется, но не маскирует известную вырожденность. Когда все варианты ограничены, можно вернуть лучший конечный диагностический результат с точными ограничениями; не нужно уничтожать уже выполненную работу. Ветка `best_identifiability` и одиночный проход также требуют согласованной обработки недопустимого loss.

**Приёмка.** Конечный пригодный кандидат не проигрывает NaN из-за порядка списка. Известная вырожденность не считается неизвестностью. Причина выбора соответствует реально применённой политике. Существующие тесты для конечного большого condition и выбранного числа идентифицированных параметров сохраняются. [C19.R08]

**Статус и предел.** Полный source-модуль selection исполнен с явными импортными фикстурами; реальные JAX/NumPy Hessian использованы в контроле. Полный multi-start optimizer не запускался. Не предлагается запрещать все ill-conditioned модели: их ограниченное исследовательское применение отличается от прохождения конкретного фильтра.

<!-- END_SOURCE_CARD B195 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**C17.R04. Calibrator: подготовка, сборка цели, multi-start и финализация.** `policy-engine/src/polisyos/foundry/calibration/calibrator.py`. Окно чтения 1–1360; файл мог быть короче запрошенного окна. Локально — выбранные определения; полного blob нет. Вложенные функции вынесены без изменения арифметики; wrapper финализации указан в harness. Git blob `86e4bd04068592644cacca451aa7d3e36d89d44a`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/calibration/calibrator.py).

**C17.R06. Существующие конечные числовые проверки.** `policy-engine/src/polisyos/foundry/execute/_internal/numeric/__init__.py`. Окно чтения 1–260; файл мог быть короче запрошенного окна. Локально — выбранные определения; полного blob нет. Вложенные функции вынесены без изменения арифметики; wrapper финализации указан в harness. Git blob `505d43b68c00227f9278caec9fd2cc87ab479bba`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/execute/_internal/numeric/__init__.py).

**C18.R10. Hessian: положительный контроль сырых eigenvalues.** `policy-engine/src/polisyos/foundry/calibration/hessian.py`. Прочитан полный файл. Локально не исполнялся как полный модуль. Git blob `1543998995fcbdf4f30bfa1c1c36cb54ee8324e7`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/calibration/hessian.py).

**C19.R01. Выбор нескольких стартов.** `policy-engine/src/polisyos/foundry/calibration/multi_start.py`. Полное чтение. Полный локальный blob сверен; проектные imports при исполнении явно заменены согласно harness. Git blob `6ec6c40b2dd362b2a9ab5539828eeee671933e48`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/calibration/multi_start.py).

**C19.R02. Группы, optimizer-loop, naming и Hessian финализации.** `policy-engine/src/polisyos/foundry/calibration/calibrator.py`. Окна чтения: 440–550; 850–905; 930–1460; файл мог быть короче окна. Локально — помеченные выбранные определения; это не полный исходный файл. Git blob `86e4bd04068592644cacca451aa7d3e36d89d44a`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/calibration/calibrator.py).

**C19.R07. Hessian и сохранение raw-degeneracy.** `policy-engine/src/polisyos/foundry/calibration/hessian.py`. Полное чтение. Полный локальный blob сверен; проектные imports при исполнении явно заменены согласно harness. Git blob `1543998995fcbdf4f30bfa1c1c36cb54ee8324e7`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/calibration/hessian.py).

**C17.E03. Python contextlib: одноразовые и повторно используемые контексты.** Первичная документация просмотрена 18 сентября 2026 года; это основание интерпретации, не подтверждение production-запуска. [Документация](https://docs.python.org/3/library/contextlib.html).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
