<a id="bundle-cal-05"></a>

# CAL-05 — Неактивный механизм не вычисляется как активный

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B185**. Локальный класс: **N**. Укрупнённая приёмка: **K4**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** нет; после общего SETUP-01 и короткой проверки current base. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Подготовить разрешённый active plan или условное исполнение с нейтральным patch-пакетом той же структуры. Сохранить порядок зависимостей, merge semantics и логические PRNG-потоки; разделить проверку структуры и runtime вычисление.

**Минимальные различающие проверки.** Отложенный log(x) при x=0 не портит доступный префикс и градиент; активный режим сохраняет реальный отказ на недопустимом входе. Проверить eager, JIT и применимый vmap на маленьком механизме; обе ветви имеют согласованные формы. Счётчик emitter отличает tracing от численного исполнения.

**Не менять / не считать исправлением.** Не применять Python if к tracer, не обещать экономию любого lax.cond под vmap, не создавать фиктивные inputs будущему механизму и не отключать finite-guards.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_cal_05.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T18. **Cross-boundary review:** X12. **Activation rules:** общие правила scope/приёмки.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/foundry/calibration/pure_executor.py` |
| Production write candidate | `policy-engine/src/polisyos/foundry/methods/components/merge_engine.py` |
| Read / consumer contract | `policy-engine/src/polisyos/foundry/calibration/calibrator.py` |
| Read / consumer contract | `policy-engine/src/polisyos/foundry/execute/_internal/numeric/__init__.py` |

**Не писать одновременно с:** нет установленного совпадения production paths в этой статической карте. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B185 lines=4702-4711 sha256=784336950cf2e3f1d11e577a321235819c6660d9a8218210ec05620e492988bc -->
## B185. Неактивный по расписанию механизм всё равно вычисляется и может испортить градиент

**Основание и причина.** В `apply_nodes` сначала вычисляется `active`, но затем безусловно вызываются selector и `mechanism.emit_patches`. Маска применяется к уже полученным patch-records и к PRNG carry. SUM-merge использует `where` и корректно не добавляет неактивное численное значение; это не тождественно пропуску вычисления и его производной. C18.R01–R02; P01–P04.

**Воспроизведение.** Три шага до начала расписания дали три вызова инструментированного emitter. Для модельного delta `log(x)` при x=0 и неактивном узле прямое значение итогового state равно 0, а настоящий `jax.grad` равен NaN. Emitter, поднимающий ошибку отсутствующего входа, также прервал неактивный шаг. Контроль с `lax.cond` дал неактивную производную 1 (сохраняется сам state x), а при активном x=2 — 1,5, как у x+log(x). Это локальные функции, не производственный механизм и не измеренный профиль compiled scan.

**Предпочтительное исправление.** Для заранее известного расписания специализировать только допустимые активные участки либо условно исполнять вычислительную ветвь с нейтральным patch-пакетом той же структуры. Сохранить порядок зависимостей, правила слияния и принятую семантику PRNG. Подготовка структуры и runtime-вычисление должны быть раздельны. Нельзя применять обычный Python `if` к tracer или терять compile-time проверки разрешённых механизмов.

**Оговорки и приёмка.** `cond` трассирует обе ветви, требует согласованной формы и при некоторых `vmap` преобразуется в select; это не автоматическое обещание экономии. Проверить eager/JIT/градиент на разрешённых входах, диапазон расписания и нормальный активный отказ. Настоящий активный NaN остаётся ошибкой. Не отключать finite-guards, не использовать `nan_to_num` и не добавлять фиктивные входы будущему вмешательству. Приоритет высокий для использующего pure-executor маршрута: полезен уже один отложенный механизм, кластер не нужен.

<!-- END_SOURCE_CARD B185 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**C17.R04. Calibrator: подготовка, сборка цели, multi-start и финализация.** `policy-engine/src/polisyos/foundry/calibration/calibrator.py`. Окно чтения 1–1360; файл мог быть короче запрошенного окна. Локально — выбранные определения; полного blob нет. Вложенные функции вынесены без изменения арифметики; wrapper финализации указан в harness. Git blob `86e4bd04068592644cacca451aa7d3e36d89d44a`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/calibration/calibrator.py).

**C17.R06. Существующие конечные числовые проверки.** `policy-engine/src/polisyos/foundry/execute/_internal/numeric/__init__.py`. Окно чтения 1–260; файл мог быть короче запрошенного окна. Локально — выбранные определения; полного blob нет. Вложенные функции вынесены без изменения арифметики; wrapper финализации указан в harness. Git blob `505d43b68c00227f9278caec9fd2cc87ab479bba`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/execute/_internal/numeric/__init__.py).

**C18.R01. Чистый исполнитель: расписание, patches и scan.** `policy-engine/src/polisyos/foundry/calibration/pure_executor.py`. Окно чтения 1–940; файл мог быть короче запрошенного окна. Локально — выбранные определения; полного blob нет. Wrapper выбранных определений и тестовая композиция описаны в harness; это не полный native pipeline. Git blob `bdb5780f1cba9c8beedba564c92503ebaa2e7676`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/calibration/pure_executor.py).

**C18.R02. Общее и JAX-слияние; SUM-маскирование.** `policy-engine/src/polisyos/foundry/methods/components/merge_engine.py`. Окно чтения 1–320; 340–700; файл мог быть короче запрошенного окна. Локально — выбранные определения; полного blob нет. Wrapper выбранных определений и тестовая композиция описаны в harness; это не полный native pipeline. Git blob `8d043633e368829e46658cf1c7955238d7fb36ba`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/components/merge_engine.py).

**C19.R02. Группы, optimizer-loop, naming и Hessian финализации.** `policy-engine/src/polisyos/foundry/calibration/calibrator.py`. Окна чтения: 440–550; 850–905; 930–1460; файл мог быть короче окна. Локально — помеченные выбранные определения; это не полный исходный файл. Git blob `86e4bd04068592644cacca451aa7d3e36d89d44a`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/calibration/calibrator.py).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
