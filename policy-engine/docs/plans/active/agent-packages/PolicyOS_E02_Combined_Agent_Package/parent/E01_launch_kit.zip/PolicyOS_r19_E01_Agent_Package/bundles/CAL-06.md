<a id="bundle-cal-06"></a>

# CAL-06 — Tied-параметры и неизменный масштаб условного закона

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B197, B198**. Локальный класс: **N**. Укрупнённая приёмка: **K4**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** CAL-04, UQP-02. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Сохранить явную проекцию групповых координат на node.field. Передавать covariance с этой проекцией и зависимостью полей, а не копировать одну группу как независимые оценки. Условный mean/std-law отделить от эвристического статуса отображаемой полосы.

**Минимальные различающие проверки.** Два поля одной tied-группы имеют дисперсии и cross-covariance=0.0025, оставаясь одной степенью свободы. Переименование группы не теряет envelopes. Отображение уровня 0.8/0.95 не меняет исходный STD=1; heuristic/gate prohibition остаётся. Untied и unknown-STD контроли сохранены.

**Не менять / не считать исправлением.** Не угадывать mapping по разбору строки и не ставить confidence_level=0.95 ради правильной формулы extract_std. Произвольная полоса не задаёт Normal-law.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_cal_06.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T19. **Cross-boundary review:** X07, X12. **Activation rules:** общие правила scope/приёмки.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/foundry/calibration/calibrator.py` |
| Production write candidate | `policy-engine/src/polisyos/foundry/calibration/uncertainty_adapter.py` |
| Production write candidate | `policy-engine/src/polisyos/foundry/uncertainty/covariance.py` |
| Production write candidate | `policy-engine/src/polisyos/ir/analytics/calibration.py` |
| Read / consumer contract | `policy-engine/src/polisyos/ir/analytics/uncertainty.py` |
| Read / consumer contract | `policy-engine/src/polisyos/foundry/calibration/hessian.py` |

**Названные в r19 тематически близкие tests (не подтверждение их покрытия/запуска):**

- `policy-engine/tests/unit/foundry/calibration/test_calibration_uncertainty_adapter.py`

**Не писать одновременно с:** CAL-01, CAL-02, UQP-02, CAL-03, CAL-04, UQS-01. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

**Связанные карточки для адресного чтения, не второе назначение:** B187 → UQP-02; B188 → UQP-02.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B197 lines=4922-4935 sha256=2f5e64ff7238ff5a340224382fa2875b57ea9e960e0e50bfea7f349c6a83ff3d -->
## B197. Связанные параметры получают covariance в другой системе имён и теряют envelopes

**Основание.** При связывании параметров `tie_id` становится `group_id`. Hessian и `CalibrationUncertainty.params` используют эти групповые имена. `calibrated_params` формируется в именах `node_id.field_name`. `envelopes_from_calibration` перебирает второе множество, а `envelope_from_calibration_param` требует точного присутствия ключа в первом. Явной проекции групп на поля на этом переходе нет. [C19.R02; C19.R03]

**Различающий пример.** Два поля `A.rate` и `B.rate` имеют общее значение 0,25 и tied-группу `shared_rate`. При наличии STD=0,05 для группы адаптер возвратил ноль envelopes. В контроле без связывания параметров с совпадающими именами возвратил два. Исходные точки и covariance при этом не обязательно потеряны в самом CalibrationReport — теряется их пригодное downstream-сопоставление. C19-P10–P12.

**Рекомендуемое исправление.** Сохранить отображение групповых координат на конкретные поля и передавать его вместе с результатом. Для точного скалярного равенства θA=θB=g проекция имеет строки [1] и [1], поэтому Σθ=JΣgJᵀ: обе дисперсии и перекрёстная covariance равны 0,0025. Это одна степень свободы, не два независимых свидетельства. Для нелинейного отображения использовать соответствующую локальную либо точную семантику преобразования.

**Минимальная реализация.** Групповое представление остаётся основным; поля получают проверяемые ссылки/alias и проекцию. Не копировать группу как два независимых Normal-распределения, не подгонять имена строковым разбором и не добавлять фиктивные STD. Настоящее отсутствие uncertainty по полю по-прежнему должно давать ограниченный результат.

**Приёмка.** Tied и untied конфигурации сохраняют точные адреса параметров, размерность и зависимость. Изменение технического имени группы не убирает результат. Несовместимые bounds и неразрешённая проекция отвергаются адресно.

**Статус.** Исполнены выбранные producer-loops naming и полный adapter с report-фикстурой; оптимизация и нативный DTO отчёта не запускались. Не касается маршрута без tied-групп либо с дополнительной внешней проекцией.

<!-- END_SOURCE_CARD B197 -->

<!-- SOURCE_CARD B198 lines=4936-4949 sha256=2cbd889b85b881ae22f7f99c28e68c82200022c7dfa01cbb150ecf895a30672b -->
## B198. Эвристическая полоса Hessian меняет STD при следующем чтении

**Основание.** Адаптер Hessian правильно выдаёт `HEURISTIC_RANGE`, `confidence_level=None`, `is_heuristic_ci=True`, `gate_eligible=False`. В metadata сохраняется действительный вычисленный `std`; границы строятся через z для запрошенного отображаемого уровня. Но `extract_std` читает только границы и confidence level. При `None` использует width/(2√3), игнорируя сохранённый параметр закона. [C19.R03; C19.R04]

**Различающие проверки.** Один и тот же report с STD=1 дал извлечённое STD=1,131585734 при отображаемом уровне 0,95 и STD=0,739904141 при 0,8. В обоих envelopes metadata оставалось `std=1`. Статистический Normal-интервал с известным уровнем корректно восстановил STD=1. Эвристический статус и отсутствие допуска сохранились в положительном контроле. C19-P13–P16.

**Рекомендуемое исправление.** Представление условного закона и статус его обоснованности должны быть раздельны. Передавать типизированный параметрический носитель mean/std либо проверяемую ссылку на covariance; потребитель использует этот закон, сохраняя эвристические ограничения. Metadata допустима как переходный источник только по точному проверенному профилю, а не как универсальная доверенная строка.

**Чего не делать.** Не ставить confidence_level=0,95 только ради включения правильной формулы. Это повысит статус по технической причине. Не заменять всякий неизвестный интервал нормальным распределением: для произвольной полосы STD вообще может быть не определён.

**Приёмка.** Изменение только запрошенной формы отображения не меняет уже заданную sigma. Сохранение и последующая propagation представляют тот же условный закон; вывод не получает новых полномочий. При отсутствии подходящего carrier возвращается явная неоднозначность.

**Статус.** Полные adapter и covariance исполнены; сквозной Monte Carlo здесь не запускался. Это отдельная проблема от перестановки covariance B187 и зависимости входов B188: информация о масштабе уже существует, но неверно восстанавливается.

<!-- END_SOURCE_CARD B198 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**C17.R04. Calibrator: подготовка, сборка цели, multi-start и финализация.** `policy-engine/src/polisyos/foundry/calibration/calibrator.py`. Окно чтения 1–1360; файл мог быть короче запрошенного окна. Локально — выбранные определения; полного blob нет. Вложенные функции вынесены без изменения арифметики; wrapper финализации указан в harness. Git blob `86e4bd04068592644cacca451aa7d3e36d89d44a`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/calibration/calibrator.py).

**C17.R05. Объявленный смысл target/align/loss/weight/config.** `policy-engine/src/polisyos/ir/analytics/calibration.py`. Окно чтения 1–470; файл мог быть короче запрошенного окна. Локально не исполнялся как полный модуль. Git blob `91c6dbaa8676c7f7a882f74876eba67726891a84`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/ir/analytics/calibration.py).

**C18.R04. Построение covariance и извлечение маргинальной дисперсии.** `policy-engine/src/polisyos/foundry/uncertainty/covariance.py`. Прочитан полный файл. Полный локальный blob сверен; при исполнении проектные импорты заменены явными фикстурами. IR certificate/provenance валидатор не исполнялся. Git blob `9ef5909b646747a8bb11375cd67bad43aa28d6f4`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/uncertainty/covariance.py).

**C18.R10. Hessian: положительный контроль сырых eigenvalues.** `policy-engine/src/polisyos/foundry/calibration/hessian.py`. Прочитан полный файл. Локально не исполнялся как полный модуль. Git blob `1543998995fcbdf4f30bfa1c1c36cb54ee8324e7`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/calibration/hessian.py).

**C19.R02. Группы, optimizer-loop, naming и Hessian финализации.** `policy-engine/src/polisyos/foundry/calibration/calibrator.py`. Окна чтения: 440–550; 850–905; 930–1460; файл мог быть короче окна. Локально — помеченные выбранные определения; это не полный исходный файл. Git blob `86e4bd04068592644cacca451aa7d3e36d89d44a`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/calibration/calibrator.py).

**C19.R03. Адаптер Hessian и Bayesian-summary.** `policy-engine/src/polisyos/foundry/calibration/uncertainty_adapter.py`. Полное чтение. Полный локальный blob сверен; проектные imports при исполнении явно заменены согласно harness. Git blob `e2bc155fe56a2659e230d488f218c3a60853cead`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/calibration/uncertainty_adapter.py).

**C19.R04. Извлечение STD и covariance.** `policy-engine/src/polisyos/foundry/uncertainty/covariance.py`. Полное чтение. Полный локальный blob сверен; проектные imports при исполнении явно заменены согласно harness. Git blob `9ef5909b646747a8bb11375cd67bad43aa28d6f4`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/uncertainty/covariance.py).

**C19.R06. IR carriers, numerical validator и joins.** `policy-engine/src/polisyos/ir/analytics/uncertainty.py`. Окна чтения: 460–1080; 1180–1575; файл мог быть короче окна. Локально — помеченные выбранные определения; это не полный исходный файл. Git blob `0a2495855d707a6548da6983bdef9abed9c4b0c7`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/ir/analytics/uncertainty.py).

**C19.R07. Hessian и сохранение raw-degeneracy.** `policy-engine/src/polisyos/foundry/calibration/hessian.py`. Полное чтение. Полный локальный blob сверен; проектные imports при исполнении явно заменены согласно harness. Git blob `1543998995fcbdf4f30bfa1c1c36cb54ee8324e7`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/calibration/hessian.py).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
