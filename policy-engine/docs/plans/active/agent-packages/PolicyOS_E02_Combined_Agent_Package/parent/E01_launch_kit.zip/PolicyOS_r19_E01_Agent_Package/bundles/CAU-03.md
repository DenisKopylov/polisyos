<a id="bundle-cau-03"></a>

# CAU-03 — RDD: честная RBC capability и линейная память WLS

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B210, B211**. Локальный класс: **N**. Укрупнённая приёмка: **K5**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** CAU-01. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Отделить поддержанный uncorrected local-polynomial от реально исполняемой bias-corrected процедуры. Убрать N×N diagonal weight matrix и повторную факторизацию без одновременной неявной смены covariance. Подключение RBC выполняется только через проверенный профиль/зависимость с фактическими параметрами.

**Минимальные различающие проверки.** Curved data с requested correction не даёт прежний uncorrected результат под флагом True. Uncorrected допустим отдельно. На 400 точках weighted-vector formula сохраняет point/SE и не создаёт 400×400. Kernel/order/rank и nonpositive-bandwidth контроли. Настоящий RBC-профиль — ограниченный K5, не повторные установки библиотек каждым агентом.

**Не менять / не считать исправлением.** Не называть quadratic fit robust bias correction. Честный unsupported corrected mode устраняет ложное обещание, но не считается внедрением самой RBC; capability-debt остаётся явно отмеченным.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_cau_03.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T20. **Cross-boundary review:** X15. **Activation rules:** A10.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/foundry/methods/catalog/causal/rdd.py` |
| Read / consumer contract | `policy-engine/src/polisyos/foundry/methods/catalog/causal/_common.py` |
| Read / consumer contract | `policy-engine/src/polisyos/foundry/methods/catalog/causal/protocols.py` |

**Не писать одновременно с:** CAU-01. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B210 lines=5170-5181 sha256=3b72bb59c40ef347388195b3309dd81f188e96d3bb205b3e3be72c77b76ac010 -->
## B210. RDD сообщает включённую bias correction без её вычисления

**Приоритет:** высокий для заявленного режима corrected inference; малый честный ограничитель плюс отдельный методологический ремонт. **Основание:** RegressionDiscontinuity.pure_step и его signature; RD01–RD03. [C20.R03, C20.E03]

**Проблема.** Параметр bias_correction используется лишь при заполнении method_params. Численно вычисляются разность локальных intercept и её текущая стандартная ошибка; дополнительных производных, correction-term и соответствующей variance-адаптации нет. Внутренний комментарий о heuristic bandwidth уже честен — его не следует превращать в заявление о точном IK-selector.

**Воспроизведение.** На 200 точках с истинным разрывом 3 и различной кривизной слева/справа оба значения флага дали estimate=2,793901410060 и CI=[2,754318328822;2,833484491298]. Флаг в metadata поменялся, вычисление — нет. Полином второй степени восстановил 3 в этом точном полиномиальном случае, но этот контроль не является реализацией robust bias correction (RBC). Неположительный bandwidth существующий метод правильно отвергает.

**Рекомендуемое исправление.** Разделить реально поддержанный обычный local-polynomial результат и подтверждённую RBC-процедуру. До внедрения последней явно ограничить requested corrected mode либо предложить разрешённый uncorrected результат с его областью применения, а не переписывать флаг в True. Если подключается профиль rdrobust, сохранить фактические bandwidth, порядки аппроксимации, variance-настройки, version и данные, не создавая конкурирующий причинный facade.

**Приёмка.** Настоящая curvature-проверка, известный скачок, контролируемая гетероскедастичность и finite-sample coverage. Численное включение correction должно изменять действительную вычислительную цепочку там, где поправка ненулевая. В этой работе rdrobust не установлен и не запускался. Обычную подгонку не следует блокировать полностью из-за неготовности более сильного inferential-профиля.

<!-- END_SOURCE_CARD B210 -->

<!-- SOURCE_CARD B211 lines=5182-5193 sha256=cf651667294eca28d2feef026f185292e15f443e1d3f4e8d515b40b67835b674 -->
## B211. Локальная RDD-подгонка материализует квадратичную диагональную матрицу весов

**Приоритет:** высокая экономия относительно малого объёма правки на используемом RDD-пути. **Основание:** _fit_local_polynomial; RD04–RD05. [C20.R03]

**Проблема.** Для n наблюдений одной стороны создаётся np.diag(weights), затем XᵀWX и XᵀWy. Большая N×N матрица не нужна для диагонального оператора; дополнительно pseudoinverse одинаковой маленькой XᵀWX вызывается дважды.

**Воспроизведение.** На 400 точках одной стороны зафиксирована матрица 400×400, 1 280 000 bytes. Векторно-взвешенный design с двумя столбцами занял 6400 bytes. Диагонально-свободная формула дала тот же intercept=3,040424179788 и SE=0,005783542516. Независимый weighted-QR совпал по точке. Это сравнение выделенных структур и значений, не измеренный коэффициент ускорения всего RDD.

**Рекомендуемое исправление.** Минимально: Xᵀ(w⊙X), Xᵀ(w⊙y), одна разрешённая факторизация; не менять одновременно статистический смысл residual covariance. Следующий численно устойчивый вариант — weighted QR/SVD, масштабирование running variable относительно bandwidth и контроль ранга. Увеличение числа точек тогда не создаёт искусственный расход O(n²) только ради хранения весов.

**Приёмка.** Сопоставить точку, SE текущего профиля и effective sample count на всех поддержанных kernel/order. Случаи недостаточной опоры сохраняют точный отказ. Исправление производительности не доказывает правильность нынешней covariance или RBC — B210 остаётся отдельной задачей. Пакетирование нескольких bandwidth допускается только с корректной идентичностью выбранной области и профиля.

<!-- END_SOURCE_CARD B211 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**C20.R03. RDD: local polynomial, inference и metadata.** `policy-engine/src/polisyos/foundry/methods/catalog/causal/rdd.py`. Окна чтения: 1–340; файл мог быть короче окна. Локально сохранены выбранные определения с помеченными импортами; это не полный Git blob. Git blob `0b89993caa808a1f5b82965709b8f86ea29217bd`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/catalog/causal/rdd.py).

**C20.R04. Panel и graph observational data contracts.** `policy-engine/src/polisyos/foundry/methods/catalog/causal/protocols.py`. Окна чтения: 1–350; 420–545; файл мог быть короче окна. Локально сохранены выбранные определения с помеченными импортами; это не полный Git blob. Git blob `2d35616ebe69a23b820cca258c77cf296d155bef`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/catalog/causal/protocols.py).

**C20.R05. Общие reports и percentile-bootstrap helper.** `policy-engine/src/polisyos/foundry/methods/catalog/causal/_common.py`. Полное чтение. Полный локальный blob сверен; проектные imports явно заменены согласно harness. Git blob `9097e312036819146bac6bbd8bc8decebf236f3f`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/catalog/causal/_common.py).

**C20.E03. rdrobust: отличие local-polynomial point и robust bias-corrected inference.** Первичная документация просмотрена 18 сентября 2026 года. Это основание методологического различения, не доказательство runtime-версии/запуска PolicyOS. [Документация](https://pypi.org/project/rdrobust/2.0.0/).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
