<a id="bundle-cau-04"></a>

# CAU-04 — DoWhy: реальный estimand и point-only результат

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B212, B213**. Локальный класс: **L**. Укрупнённая приёмка: **K5**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** нет; после общего SETUP-01 и короткой проверки current base. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Связать запрошенный estimand/contrast/population с поддержанным identify/estimate API и проверить фактический ответ. Сохранить point, даже если CI недоступен, через совместимый частичный report; при необходимости согласованно расширить contract и consumers.

**Минимальные различающие проверки.** Recorder point=7 без CI не создаёт 7±epsilon. Настоящий interval[5,9] сохраняется. NIE-request не выдаёт backend-defaultATE под новой подписью; unsupported profile — точный capability-result. Native DTO тест обязателен; один действительный DoWhy smoke на K5. Proceed_when_unidentifiable=False остаётся.

**Не менять / не считать исправлением.** Не подставлять нулевую дисперсию и не ослаблять общий SUCCESS-guard без versioned смысла. Spy не доказывает работу реального DoWhy API.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_cau_04.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T20. **Cross-boundary review:** X06, X11. **Activation rules:** A10.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/foundry/methods/catalog/causal/dowhy_identify_estimate.py` |
| Production write candidate | `policy-engine/src/polisyos/foundry/methods/catalog/causal/_common.py` |
| Production write candidate | `policy-engine/src/polisyos/ir/analytics/causal.py` |
| Read / consumer contract | `policy-engine/src/polisyos/foundry/methods/catalog/causal/protocols.py` |
| Read / consumer contract | `policy-engine/src/polisyos/ir/analytics/uncertainty.py` |

**Не писать одновременно с:** CAU-01. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B212 lines=5194-5205 sha256=dd369570f1235d66729b8c5526f88a5968905343594089f5a4c00da90631238f -->
## B212. Point-only ответ DoWhy превращается в почти точный доверительный интервал

**Приоритет:** высокий, центральная граница частичной полезности. **Основание:** _run_dowhy и _extract_confidence_interval; DW01–DW04. [C20.R06–R07]

**Проблема.** Если backend не возвращает interval, адаптер создаёт point±max(|point|×10⁻⁹,10⁻⁹) и вызывает build_success_report. В общем CausalEffectReport для SUCCESS требуются одновременно point и interval. Это создаёт давление заполнить отсутствующую неопределённость, но не делает такое заполнение обоснованным.

**Воспроизведение.** Recorder-backend вернул конечную точку 7 без CI и SE. Исходный адаптер запросил успешный report с [6,999999993;7,000000007], уровнем 0,95 и SE=None. Интервал [5,9], когда backend действительно его предоставил, сохранён. Ошибка identify и нечисловая point корректно пошли по отказным ветвям.

**Рекомендуемое исправление.** Независимо сохранять определённый estimand, вычисленную point и состояние inferential-части. Недоступность CI не должна ни стирать полезную point, ни создавать очень узкую фикцию. Вызывать действительную поддержанную CI-процедуру либо использовать реальный SE только при подходящем распределении и предпосылках. Для point-only пути нужен существующий совместимый частичный результат или адресное расширение общего контракта с согласованными потребителями.

**Приёмка и граница.** Recorder не является DoWhy; реальная библиотека, IR-envelope, права и публикация здесь не запускались. В production-тесте backend без inference должен давать point-only; backend с настоящим interval — сохранить его; недоступный backend — прежнее явное ограничение. Нельзя подставлять нулевую дисперсию, бесконечно узкую полосу или общий SUCCESS-гейт только ради завершения pipeline.

<!-- END_SOURCE_CARD B212 -->

<!-- SOURCE_CARD B213 lines=5206-5217 sha256=6684013f61227644563e3dd6ac181b2546b5797168cd0b93fef3ef1bf75fe243 -->
## B213. Запрошенный estimand_type остаётся только подписью отчёта DoWhy

**Приоритет:** высокий при нескольких видах причинного запроса; небольшой явный binding. **Основание:** _run_dowhy; DW05–DW06. [C20.R06, C20.E04]

**Проблема.** Параметр estimand_type объявлен в методе и читается, но не передаётся ни CausalModel, ни identify_effect. В estimate_effect передаётся только method_name. Итоговый report записывает именно запрошенную строку, хотя фактический backend мог использовать свой default.

**Воспроизведение.** Для requested nonparametric-nie recorder с определённым default ATE получил constructor(data,treatment,outcome,graph), identify(proceed_when_unidentifiable=False), estimate(method_name=...). В отчёте одновременно оказались estimand_type=nonparametric-nie и identified_estimand='ATE(x:0->1) [fixture default]'. Это различающий протокольный опыт, не численное оценивание реального NIE.

**Рекомендуемое исправление.** До исполнения связать запрос с поддержанным типом estimand, вмешательством/контрастом, target population и фактической формулой идентификации. Для поддержанного профиля передать параметры по API конкретной версии, проверить ответ; для неподдержанного — точный capability-result. Неизвестное имя нельзя просто переслать в библиотеку и надеяться, что она корректно его поймёт.

**Приёмка.** Наблюдать реальные аргументы identify/estimate на обычном dispatcher-маршруте, а не только совпадение labels. Default ATE должен остаться рабочим. Существующий proceed_when_unidentifiable=False передаётся правильно и сохраняется. Документация DoWhy показывает отдельную точку задания estimand_type; её чтение не доказывает установленную runtime-версию проекта. [C20.E04]

<!-- END_SOURCE_CARD B213 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**C19.R06. IR carriers, numerical validator и joins.** `policy-engine/src/polisyos/ir/analytics/uncertainty.py`. Окна чтения: 460–1080; 1180–1575; файл мог быть короче окна. Локально — помеченные выбранные определения; это не полный исходный файл. Git blob `0a2495855d707a6548da6983bdef9abed9c4b0c7`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/ir/analytics/uncertainty.py).

**C20.R04. Panel и graph observational data contracts.** `policy-engine/src/polisyos/foundry/methods/catalog/causal/protocols.py`. Окна чтения: 1–350; 420–545; файл мог быть короче окна. Локально сохранены выбранные определения с помеченными импортами; это не полный Git blob. Git blob `2d35616ebe69a23b820cca258c77cf296d155bef`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/catalog/causal/protocols.py).

**C20.R05. Общие reports и percentile-bootstrap helper.** `policy-engine/src/polisyos/foundry/methods/catalog/causal/_common.py`. Полное чтение. Полный локальный blob сверен; проектные imports явно заменены согласно harness. Git blob `9097e312036819146bac6bbd8bc8decebf236f3f`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/catalog/causal/_common.py).

**C20.R06. DoWhy identification/estimation adapter.** `policy-engine/src/polisyos/foundry/methods/catalog/causal/dowhy_identify_estimate.py`. Окна чтения: 1–360; файл мог быть короче окна. Локально сохранены выбранные определения с помеченными импортами; это не полный Git blob. Git blob `908bdfb81c955cc7b2caa86bf5123e0959209480`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/catalog/causal/dowhy_identify_estimate.py).

**C20.R07. CausalEffectReport, SUCCESS и неопределённость.** `policy-engine/src/polisyos/ir/analytics/causal.py`. Окна чтения: 1–360; файл мог быть короче окна. Прочитано как кодовое основание/контроль области, не исполнялось в production-окружении. Git blob `6ada4b5b0444780b97bbb06f8fcb980a78f8911a`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/ir/analytics/causal.py).

**C20.E04. DoWhy CausalModel: estimand_type, identify и estimate API.** Первичная документация просмотрена 18 сентября 2026 года. Это основание методологического различения, не доказательство runtime-версии/запуска PolicyOS. [Документация](https://www.pywhy.org/dowhy/main/_modules/dowhy/causal_model.html).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
