<a id="bundle-cmp-01"></a>

# CMP-01 — Импорт, effective DAG и единый payload исполнителей

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B42, B43, B44**. Локальный класс: **L**. Укрупнённая приёмка: **K1**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** нет; после общего SETUP-01 и короткой проверки current base. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Разорвать конкретный circular import с сохранением диагностики внутренних ошибок. Сохранять один effective DAG с ordering-only requires и доступными уровнями. Переиспользовать единый static→dynamic→override parameter builder во всех режимах.

**Минимальные различающие проверки.** Два свежих процесса с обратным порядком импорта получают рабочий wrapper. Build→freeze→execute: B.requires(A) соблюдается без data-flow ребра; независимый сосед параллелен. window=20 доходит в async без ручного повторного override; cycle выявлен до исполнения.

**Не менять / не считать исправлением.** Не создавать второй executor, не считать фикстурный DAG результатом MethodComposer.build, не сериализовать все узлы ради сокрытия пропавшего requires.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_cmp_01.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T4. **Cross-boundary review:** X01. **Activation rules:** A06.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/foundry/methods/backends/chain_executor.py` |
| Production write candidate | `policy-engine/src/polisyos/foundry/methods/backends/async_chain_executor.py` |
| Production write candidate | `policy-engine/src/polisyos/foundry/methods/components/composer.py` |
| Read / consumer contract | `policy-engine/src/polisyos/foundry/methods/components/semantic_validator.py` |
| Read / consumer contract | `policy-engine/src/polisyos/foundry/methods/backends/dispatch.py` |

**Не писать одновременно с:** CMP-02, RES-04, RES-03. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B42 lines=788-803 sha256=3a897e3117a39458b90c2efaa82f45d9b4568ce41e586ca814466741226b63cf -->
## B42. Круговой импорт превращает установленный async-исполнитель в недоступную возможность

*Источник карточки: C03-01. Код прочитан в C03; локальные проверки, не полное исполнение PolicyOS.*

**Приоритет и охват:** При использовании общего async-wrapper; локальное исправление S.

**Основание и область.** В chain_executor.py до определения ChainExecutionResult выполняется импорт AsyncChainExecutor. Второй модуль в ответ импортирует ChainExecutionResult из первого. Ошибка импорта перехватывается широким except Exception, а глобальная ссылка становится None. Общие execute_heterogeneous_chain_async и _execute_async_chain затем проверяют именно эту ссылку. Два порядка импорта в минимальном модульном воспроизведении дали недоступность wrapper, хотя прямой класс второго модуля существовал. Это опыт над топологией импорта, не импорт всего PolicyOS. [N01, N02]

**Уточнение новизны.** Журнал 27 августа уже описывает этот класс проблем. Исправление фасада сделало backend-экспорты ленивыми и не загружает chain-модули при использовании несвязанных инструментов. Это реальное исправление другой границы, которое здесь не отрицается. Прямой экспорт AsyncChainExecutor может работать; исследуется оставшаяся ссылка в общем wrapper. [N06, N07]

**Предлагаемое исправление.** Разрешать зависимость в момент вызова после завершения инициализации модулей либо перенести разделяемый carrier в подходящий существующий нейтральный модуль. Для небольшого исправления предпочтительнее локальный отложенный импорт; не заводить второй executor. Различать отсутствие реально необязательной зависимости и ошибку внутренней инициализации; не сохранять любое исключение как permanent unavailable.

**Приёмка.** В двух свежих процессах проверить оба порядка импорта и реальную собранную двухузловую цепочку через общий wrapper. Негатив: отсутствующая необходимая зависимость остаётся адресной ошибкой. Пустая совместимая фикстура не заменяет результат MethodComposer.build().

**Граница.** Непосредственный production-import всех зависимостей не выполнен. Исправление импорта не закрывает B43. Это новая локализация для данного сводного аудита, не претензия на первое обнаружение в проекте.

<!-- END_SOURCE_CARD B42 -->

<!-- SOURCE_CARD B43 lines=804-819 sha256=7f2c41dcdea454413c8616c04b8e6f91650dcb656dcec2419c153db671f8b57a -->
## B43. Скомпилированный граф не предоставляет уровни исполнения и теряет дополнительную зависимость requires

*Источник карточки: C03-02. Код прочитан в C03; локальные проверки, не полное исполнение PolicyOS.*

**Приоритет и охват:** Для настоящей композиции; согласованное исправление M.

**Основание.** MethodComposer.build() вычисляет execution_order с req_predecessors, однако freeze() сохраняет только собственные рёбра DAG. FrozenCompositionDAG не имеет compute_parallel_levels, который вызывает AsyncChainExecutor.execute(). LevelAwareExecutor перехватывает ошибку и выбирает sequential; явный async-путь не получает ожидаемый интерфейс. В журнале проекта несовпадение frozen-интерфейса уже зарегистрировано как незакрытый участок вне того изменения. [N02, N03, N07]

**Почему недостаточно добавить один метод.** После простого восстановления compute_parallel_levels останется второй разрыв: дополнительные requires-рёбра использовались для последовательного порядка, но не вошли в замороженный граф. При уровнях по одному data-flow графу зависимые методы могут оказаться в одном параллельном уровне. Локальный graphlib-контроль показывает A→B в эффективном графе и [A,B] в одном уровне после удаления requirement-ребра. Это условный дефект следующего шага, не утверждение, что нынешняя сломанная ветвь уже исполняет их параллельно.

**Предлагаемое исправление.** Компилятор один раз сохраняет неизменяемый эффективный граф зависимостей или выведенные из него проверяемые уровни. Sequential, async, auto и другие действительные потребители читают один план. Сохранить различие data-flow и ordering-only ребра: requires не обязан передавать данные. Не заставлять все узлы стать последовательными ради сокрытия проблемы.

**Приёмка.** Цепочка с B.requires(A), но без data-flow ребра, соблюдает A раньше B во всех режимах. Независимая ветвь остаётся доступной для параллельности. Цикл выявляется до исполнения. Проверяются именно build→freeze→execute, сериализация плана и изменение существенного ребра.

**Граница.** Непосредственная ошибка интерфейса установлена кодом; готовность всех executor-режимов не проверена. Для первого простого последовательного исследования эта правка не обязательна; для открытия композиции её нельзя заменить повышением max_nodes.

<!-- END_SOURCE_CARD B43 -->

<!-- SOURCE_CARD B44 lines=820-835 sha256=1c398f07ae05cd7d9b76d11696e156ea2103f2dd73fa33568a75f6250cc29c62 -->
## B44. Параллельная ветвь передаёт динамические параметры, но теряет заданные статические

*Источник карточки: C03-03. Код прочитан в C03; локальные проверки, не полное исполнение PolicyOS.*

**Приоритет и охват:** S; до включения async-режима на выбранной цепочке.

**Основание.** MethodComposer.add() разносит параметры по node.static_params и node.params. Последовательный путь использует _build_node_param_payload: static → dynamic → per-call override. В AsyncChainExecutor._dispatch_node берётся только dict(node.params), затем override и seed. Статические параметры из узла не добавляются. [N01–N03]

**Следствие и опыт.** В локальном payload-примере явно заданное window=20 есть у последовательного вызова и отсутствует у параллельного. Дальнейший dispatcher может отказать либо восстановить default метода; неверный численный результат всего приложения здесь не измерен. Переданный заново per-call window скрывает дефект — поэтому тест, всегда поставляющий все параметры через params_map, недостаточен.

**Предлагаемое исправление.** Переиспользовать существующую сборку полного параметрического payload для всех исполнителей с одним правилом приоритета значений. Служебную случайность и runtime-параметры передавать по их действующему контракту; не добавлять пользовательский seed в обход проверки сигнатуры. Не менять статическое/динамическое разделение ради исправления передачи.

**Приёмка.** Один MethodNode с нестандартным статическим параметром получает равнозначный payload в sequential и async без повторного ручного параметра. Проверить dynamic и разрешённый override, неизвестный параметр, воспроизводимость и фактический численный результат простого метода.

**Граница.** Текущие B42–B43 могут препятствовать достижению этой ветви через общий wrapper. B44 — обязательное условие её правильного открытия, а не доказательство, что все сегодняшние расчёты используют defaults.

<!-- END_SOURCE_CARD B44 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**N01.** `foundry/methods/backends/chain_executor.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/backends/chain_executor.py). 1–1085

**N02.** `foundry/methods/backends/async_chain_executor.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/backends/async_chain_executor.py). 1–конец полученного файла

**N03.** `foundry/methods/components/composer.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/components/composer.py). 1–конец полученного файла

**N05.** `foundry/methods/components/semantic_validator.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/components/semantic_validator.py). 1–конец полученного файла

**N10.** `foundry/methods/backends/dispatch.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/backends/dispatch.py). 1–245

**C06.R10. Foundry: per-node результаты и их воспроизводимость.** `policy-engine/src/polisyos/foundry/methods/backends/chain_executor.py`. Окна чтения: 1–230. Git blob SHA: `82a8a146658bfd7ee7a54434a76215fdbded09d9`. ChainExecutionResult и _build_chain_reproducibility_contract; потребление metadata результатов, не запуск агрегатора. [Закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/backends/chain_executor.py).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
