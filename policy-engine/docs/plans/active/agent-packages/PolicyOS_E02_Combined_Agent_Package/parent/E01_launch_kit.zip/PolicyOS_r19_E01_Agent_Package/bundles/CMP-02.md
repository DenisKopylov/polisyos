<a id="bundle-cmp-02"></a>

# CMP-02 — Однозначные slots и ordering по occurrence

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B45, B46**. Локальный класс: **L**. Укрупнённая приёмка: **K1**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** CMP-01. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Применить существующую chain-level проверку уникального производителя входа. Проверять prerequisite для конкретных node_id/occurrence, не по последнему общему FQN. Явный merge остаётся отдельным узлом с семантикой.

**Минимальные различающие проверки.** Два источника одного scalar-slot не зависят от UUID; разные slots работают. estimate1→sensitivity→estimate2 не отвергается; sensitivity1→estimate→sensitivity2 не скрывает раннее нарушение. Проверить strict/warning режимы и явный merge.

**Не менять / не считать исправлением.** Не выбирать источник по UUID и не объявлять эвристические tag-rules универсальными методологическими законами.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_cmp_02.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T4. **Cross-boundary review:** X01. **Activation rules:** A06.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/foundry/methods/components/composer.py` |
| Production write candidate | `policy-engine/src/polisyos/foundry/methods/components/semantic_validator.py` |
| Production write candidate | `policy-engine/src/polisyos/foundry/methods/backends/chain_executor.py` |
| Production write candidate | `policy-engine/src/polisyos/foundry/methods/backends/async_chain_executor.py` |
| Read / consumer contract | `policy-engine/src/polisyos/foundry/methods/components/linker.py` |
| Read / consumer contract | `policy-engine/src/polisyos/foundry/methods/types/checker.py` |

**Не писать одновременно с:** CMP-01, CMP-03, RES-04, RES-03. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B45 lines=836-851 sha256=fa7b68c73e6d931b4381d6a50a79855f9a6d20e60b9c92d2940e2dae19fa0c17 -->
## B45. Два производителя одного входа разрешаются последней записью, а порядок зависит от UUID

*Источник карточки: C03-04. Код прочитан в C03; локальные проверки, не полное исполнение PolicyOS.*

**Приоритет и охват:** Высокий для композиции; S–M.

**Основание.** Несколько connect могут привести разные источники к одному target slot. Composer собирает bindings и сортирует их, в том числе по строке source_node_id; MethodNode создаётся с uuid4. В sequential и async сборщиках используется bound_inputs[target_slot] = source_value, поэтому последняя привязка перезаписывает предыдущую. Общий SlotLinker.validate_chain уже умеет обнаруживать повтор одного target, но в прочитанной последовательности MethodComposer.build()/validate() он не вызывается. CrossMethodValidator также не заменяет эту проверку. [N01–N05]

**Локальное свидетельство.** Два источника 10 и 20, назначенные одному x, дали разные x при перестановке фиксированных UUID. Это контролируемая иллюстрация порядка, не статистика случайных ошибок. Валидность полного набора предметных DTO и распространение результата до policy-решения здесь не испытывались.

**Предлагаемое исправление.** Проверить уникальность производителя каждого входного слота при окончательной сборке цепочки, переиспользуя существующий chain-level checker. Если нужны оба источника, вставить явный подходящий merge/aggregation-узел с определённой семантикой. Не выбирать «лучший» источник по UUID и не устранять дубли слепым dict/dedupe.

**Приёмка.** Два источника для одного однозначного входа не исполняются как молчаливый last-wins; два источника для разных входов проходят. Явное объединение воспроизводимо. Повторное построение с другими UUID не меняет смысл результата.

**Граница.** Номинальная совместимость двух пар слотов не доказывает допустимость их совместной записи. Это локальный контракт построения цепочки, а не новая система полномочий.

<!-- END_SOURCE_CARD B45 -->

<!-- SOURCE_CARD B46 lines=852-867 sha256=56558253cab9bf7c69857ed498ece3afda7376a541269def0ff6cb384a759ca9 -->
## B46. Проверка порядка смешивает разные появления одного метода по общему FQN

*Источник карточки: C03-05. Код прочитан в C03; локальные проверки, не полное исполнение PolicyOS.*

**Приоритет и охват:** S; перед повторным применением методов в цепочке.

**Основание.** CrossMethodValidator._check_ordering_rules собирает ordered_nodes по появлениям, но затем строит fqn_order_index = {fqn: i ...}. Повторный FQN заменяет позицию предыдущего экземпляра. Требования после этого проверяются по последним позициям имён, а не по конкретным узлам. При strict=True нарушение становится ошибкой. [N05]

**Два контрпримера.** estimate₁ → sensitivity → estimate₂: корректный ранний prerequisite теряется, возникает ложный отказ. sensitivity₁ → estimate → sensitivity₂: позднее корректное появление dependent скрывает раннее некорректное. В локальных проверках воспроизведены оба направления; обычная последовательность двух разных методов остаётся положительным контролем.

**Предлагаемое исправление.** Индексировать и проверять конкретные node_id/occurrence, а FQN использовать для идентичности метода и поиска требуемого класса. Для каждого dependent проверить нужную предшествующую occurrence или явное ребро, не последний индекс имени. После этого отдельно уточнять предметные правила по тегам, не выдавая их за универсальные научные законы.

**Приёмка.** Повтор одной процедуры после промежуточной проверки не создаёт искусственную цикличность; ранняя чувствительность без нужного основания не становится допустимой благодаря более поздней оценке. Проверить два повторяющихся prerequisite и dependent, строгий и предупредительный режимы.

**Граница.** Некоторые из tag-based правил могут быть лишь эвристикой. Данный диагноз касается механики индексации, а не доказанности всех содержательных правил валидатора.

<!-- END_SOURCE_CARD B46 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**N01.** `foundry/methods/backends/chain_executor.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/backends/chain_executor.py). 1–1085

**N02.** `foundry/methods/backends/async_chain_executor.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/backends/async_chain_executor.py). 1–конец полученного файла

**N03.** `foundry/methods/components/composer.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/components/composer.py). 1–конец полученного файла

**N04.** `foundry/methods/components/linker.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/components/linker.py). 1–конец полученного файла

**N05.** `foundry/methods/components/semantic_validator.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/components/semantic_validator.py). 1–конец полученного файла

**N08.** `foundry/methods/types/checker.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/types/checker.py). 120–305; 550–825

**C06.R10. Foundry: per-node результаты и их воспроизводимость.** `policy-engine/src/polisyos/foundry/methods/backends/chain_executor.py`. Окна чтения: 1–230. Git blob SHA: `82a8a146658bfd7ee7a54434a76215fdbded09d9`. ChainExecutionResult и _build_chain_reproducibility_contract; потребление metadata результатов, не запуск агрегатора. [Закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/backends/chain_executor.py).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
