<a id="bundle-ctl-02"></a>

# CTL-02 — Содержательные даты и воспроизводимый RNG/checkpoint

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B124, B125, B126**. Локальный класс: **L**. Укрупнённая приёмка: **K3**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** OPT-02. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Исключать волатильность по типизированным служебным полям, сохраняя предметные даты. Кодировать Python Random state по его версии. Для Sobol сохранить одну логическую последовательность и cursor/scramble при batch, cache и resume.

**Минимальные различающие проверки.** Разные starts_at в содержательном кандидате дают разные identities; audit timestamp не меняет предмет. JSON round-trip восстанавливает Random sequence. Один batch и несколько batches после restore дают один Sobol-префикс; несовместимый legacy checkpoint имеет точный исход.

**Не менять / не считать исправлением.** Не удалять рекурсивно любой *_at/*_ts, не превращать все lists в tuples, не считать новый seed от длины cache продолжением прежнего эксперимента.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_ctl_02.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T11. **Cross-boundary review:** X02. **Activation rules:** общие правила scope/приёмки.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/scientist/methods/search/frontier.py` |
| Production write candidate | `policy-engine/src/polisyos/scientist/policy_design/objectives.py` |
| Production write candidate | `policy-engine/src/polisyos/scientist/methods/search/strategies/base.py` |
| Production write candidate | `policy-engine/src/polisyos/scientist/methods/search/strategies/space.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/methods/search/strategies/types.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/methods/search/controller.py` |

**Не писать одновременно с:** OPT-02, OPT-03. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B124 lines=3250-3263 sha256=77a12566a323c32df2df5d2440997a01226630d79ef6fd1d1f5b939a3b1fa3c5 -->
## B124. Эвристика «волатильных» полей удаляет содержательные даты внутри кандидата

**Основание и область:** `policy_candidate_hash`, `_strip_volatile_candidate_fields`, `update_legacy_pareto_front`; HA1–HA5. Полный `frontier.py` сверён по Git blob; helpers сериализации заменены явными детерминированными fixtures. [C11.R03]

**Проблема.** Удаление ключей `timestamp`, `*_at`, `*_ts`, `*_timestamp` и начинающихся с подчёркивания применяется рекурсивно к любому словарю, не только к транспортной оболочке. В generic-кандидате это может стереть предметную дату начала вмешательства или момент наблюдения. Два различных предметных входа затем получают одинаковый hash. При совпавшем hash frontier может заменить один результат другим вместо сохранения настоящего компромисса.

**Проверка.** Два dict-кандидата, отличающиеся только `semantic.interventions[0].starts_at`, стали одинаковыми уже после stripping. Для несравнимых векторов `(0,10)` и `(10,0)` осталось одно предложение. Изменение amount давало разные ключи; изменение верхнего provenance `created_at` правильно не меняло ключ. Независимое вычисление идентичности только явно выбранного предметного payload сохранило различие дат.

**Ограничение достижимости.** Даты и структура этого примера модельные. Не утверждается, что текущий канонический `PolicyCandidateSchema` содержит именно поле `starts_at` или что каждый producer использует fallback-hash: явный проверенный hash/metadata_hash может обходить эвристику. Тем не менее generic-API принимает такой payload, а потеря различия в helper воспроизводится точно; реальный маршрут требуется проверить отдельно.

**Рекомендуемое исправление.** Разделить предмет кандидата и оболочку исполнения по схеме, исключая только известные технические пути. Содержательное время, seed научной реплики и версии входов включать согласно контракту. Идентичности кандидата, его оценки и попытки исполнения не сливать в один случайный UUID.

**Приёмка.** Разные даты реального действия дают разные предметные ключи; только дата загрузки/trace не вызывает лишнее вычисление. Тестируется нормальная дедупликация одного и того же канонического входа и сохранение нескольких оценок/реплик. Перестановка полей JSON не меняет смысл, а временные данные не удаляются только по суффиксу имени.

<!-- END_SOURCE_CARD B124 -->

<!-- SOURCE_CARD B125 lines=3264-3277 sha256=da6f01affaab6b25e26af7613845243eeafc15f0041b3374d39ce18adbe7721b -->
## B125. Сериализуемое состояние стратегии не восстанавливает собственный Python RNG после JSON

**Основание и область:** `StrategyState.to_artifact/from_artifact`, `BaseSearchStrategy.get_state/set_state`; RG1–RG3. Полные `types.py` и `base.py` сверены по Git blob и исполнены с фикстурами зависимостей. [C11.R04, C11.R05]

**Проблема.** `random.Random.getstate()` даёт структурированный tuple. JSON сериализация превращает его вложенные tuples в lists; `from_artifact` декодирует bytes модели, но не восстанавливает представление Python RNG. Затем `_rng.setstate` получает несовместимый тип внутреннего вектора.

**Проверка.** Передача state напрямую в памяти сохранила следующую случайную точку. Настоящий `to_artifact → from_artifact → set_state` дал `TypeError: state vector must be a tuple`. Схемно-ограниченное восстановление только структуры Python RNG вернуло ровно ту же следующую точку. Версия опыта — Python 3.13.5; target-проект целиком не устанавливался.

**Рекомендуемое исправление.** Версионировать codec состояния каждого используемого генератора и восстанавливать проверенную структуру по его схеме. Для Python RNG это небольшая локальная нормализация необходимых контейнеров с проверкой версии, длины и типов. Не рекурсивно превращать все lists произвольного metadata в tuples и не десериализовать произвольные исполняемые объекты.

**Что сохранить.** Состояние модели, RNG и его идентичность должны иметь собственные правила совместимости. Возобновление с одним только seed обычно означает повтор начала, а не продолжение. Ошибка codec должна быть явной; новый случайный запуск — другая операция, не незаметный fallback под прежней меткой replay. [C11.E01]

**Приёмка.** Полный persisted round-trip каждого поддерживаемого strategy-state, а не только `get_state/set_state` в одной памяти. Восстановленная следующая последовательность совпадает; повреждённое/чужое состояние не принимается; случайный поток независимой реплики остаётся независимым.

<!-- END_SOURCE_CARD B125 -->

<!-- SOURCE_CARD B126 lines=3278-3291 sha256=f05138039bb68e205dc185417722e7c5113d18276733c1e4f91577e83476e16d -->
## B126. Соболь-последовательность зависит от заполнения кэша и не включена в checkpoint

**Основание и область:** `BaseSearchStrategy._sobol_candidate/get_state`, `SearchSpace.sample_sobol`; SQ1–SQ4. Использовалась действительная ветвь SciPy при явно установленном `torch=None`; PyTorch/BoTorch не запускались. [C11.R04–R06]

**Проблема.** При расширении `_sobol_cache` создаётся новый sampler с seed, зависящим от текущей длины кэша, и запрашивается только недостающая часть. Следовательно, четыре последовательных запроса по одной точке используют разные scramble-seeds; один запрос четвёртого индекса создаёт четыре точки одного sampler. Сам `_sobol_cache` и позиция его потока не сохраняются в `StrategyState`.

**Проверка.** Четыре incremental-точки и четыре точки, подготовленные одним расширением, совпали только в первом элементе. После трёх вызовов get_state/set_state через память — без JSON-проблемы B125 — следующий Sobol-кандидат отличался от непрерывного исполнения. Реальный SciPy-контроль одного sampler с фиксированным seed и восстановленной позицией дал ту же точку. Сохранение старого cache отдельно также воспроизвело старый алгоритм; это контроль совместимости, не подтверждение свойств полноценной QMC-последовательности.

**Рекомендуемое исправление.** Для нового алгоритмического режима — одна идентичность sampler, scramble/seed, пространство, backend/version и курсор; последовательное продолжение либо восстановление через поддерживаемый fast-forward. Для уже существующих снимков — явная совместимая миграция или сохранение недостающего cache, а не подмена прежних результатов новой последовательностью.

**О численной гарантии.** В SciPy документированы особенности balanced выборок размера степени двойки. Исправление воспроизводимости не требует заставлять каждый поиск выполнять 2^m дорогих симуляций: можно честно поддерживать ограниченный префикс, не приписывая ему свойств полного balanced-дизайна. Реальная QMC-ошибка или улучшение качества оптимизации здесь не измерялись. [C11.E02]

**Приёмка.** Одинаковый логический индекс после 1+1+… и пакетной подготовки, до/после checkpoint и при чтении уже известной точки. Без смены объявленного algorithm-version исходное исследование не меняется из-за способа заполнения кэша.

<!-- END_SOURCE_CARD B126 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**C10.R05. Базовая стратегия: настоящий ранний sample-путь.** `policy-engine/src/polisyos/scientist/methods/search/strategies/base.py`. Прочитанные окна 1–300. Полная локальная копия не заявлена; извлечённые тела, где применимо, отдельны от Git blob. Git blob `451f10a7489bf79cb2c5258f22c06ac85d0e9932`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/strategies/base.py).

**C10.R10. Существующий полноценный SearchSpace.** `policy-engine/src/polisyos/scientist/methods/search/strategies/space.py`. Прочитанные окна 1–270. Полная локальная копия не заявлена; извлечённые тела, где применимо, отдельны от Git blob. Git blob `891ee459f937aa1b68c88f77cfab1b352289ed63`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/strategies/space.py).

**C11.R01. Legacy SearchController: run, generator, evaluation и typed fallback.** `policy-engine/src/polisyos/scientist/methods/search/controller.py`. Окна чтения: 1–240, 241–520, 520–850. Полная локальная копия не заявлена. Перенесённые тела в `sources/controller_run.py`; сокращены аннотации/комментарии и форматирование, это не полный Git blob. Git blob `95668197ea04405006cb0778de259f94af0cf633`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/controller.py).

**C11.R03. Ключ кандидата и legacy-frontier.** `policy-engine/src/polisyos/scientist/methods/search/frontier.py`. Полный файл: 168 строк; Git blob совпал. Исполнен с описанными импортными fixtures. Git blob `b98f3ffcc2179c43fb4b2716728fff95c13724b0`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/frontier.py).

**C11.R04. Base strategy: RNG, Sobol-cache и восстановление.** `policy-engine/src/polisyos/scientist/methods/search/strategies/base.py`. Полный файл: 115 строк; Git blob совпал. Исполнен с описанными импортными fixtures. Git blob `451f10a7489bf79cb2c5258f22c06ac85d0e9932`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/strategies/base.py).

**C11.R05. StrategyState и представление кандидата.** `policy-engine/src/polisyos/scientist/methods/search/strategies/types.py`. Полный файл: 172 строк; Git blob совпал. Исполнен с описанными импортными fixtures. Git blob `8f82b4759f3f9aab8eb6213644e4c8b3b511148f`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/strategies/types.py).

**C11.R06. SearchSpace: нормализация и настоящий SciPy-sampler.** `policy-engine/src/polisyos/scientist/methods/search/strategies/space.py`. Полный файл: 143 строк; Git blob совпал. Исполнен с описанными импортными fixtures. Git blob `891ee459f937aa1b68c88f77cfab1b352289ed63`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/strategies/space.py).

**C11.R08. Typed objectives: schema, feasibility и legacy proxy.** `policy-engine/src/polisyos/scientist/policy_design/objectives.py`. Окна чтения: 1–250. Полная локальная копия не заявлена. Перенесённые тела в `sources/policy_vector_extract.py`; сокращены аннотации/комментарии и форматирование, это не полный Git blob. Git blob `1c5993f07dee5c77cead3a4bb95a94db8448fef0`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/policy_design/objectives.py).

**C12.R07. Унаследованный Evaluation DTO: параметры, метаданные, provenance.** `policy-engine/src/polisyos/scientist/methods/search/strategies/types.py`. Унаследованный полный DTO, не новое чтение; 172 строк, Git blob совпал. Исполнен с описанными импортными fixtures. Git blob `8f82b4759f3f9aab8eb6213644e4c8b3b511148f`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/strategies/types.py).

**C12.R09. Legacy consumer передаёт min_confidence в lesson query.** `policy-engine/src/polisyos/scientist/methods/search/controller.py`. Прочитанные окна: 540–585. Полный локальный blob не заявлен. Git blob `95668197ea04405006cb0778de259f94af0cf633`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/controller.py).

**C11.E01. Python Random: getstate/setstate и воспроизводимость.** Первичная документация просмотрена 18.09.2026; версия локального опыта приведена отдельно. [Документация](https://docs.python.org/3.11/library/random.html).

**C11.E02. SciPy Sobol: состояние последовательности, fast_forward и balanced-design.** Первичная документация просмотрена 18.09.2026; версия локального опыта приведена отдельно. [Документация](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.qmc.Sobol.html).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
