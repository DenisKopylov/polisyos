<a id="bundle-cyc-01"></a>

# CYC-01 — Штатный вход и связанные контексты N4/N5

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B01, B02, B03**. Локальный класс: **L**. Укрупнённая приёмка: **K1**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** нет; после общего SETUP-01 и короткой проверки current base. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Разделить предварительный допуск и привязку к уже скомпилированному DesignProblem. Провести один действительный CycleSubstrateContext через HTTP, рекурсию и N6; собрать сериализуемый запрос N5 из кандидата, WMR, атомов, горизонта и разрешённого ресурса. Согласовать три изменения в одном пакете: открытие входа без потребляемого контекста не является результатом.

**Минимальные различающие проверки.** Штатный вход без вручную собранного Python-context доходит до настоящего разрешённого N5. Изменение problem/model/catalog binding отвергается. Отсутствующие параметры не становятся нулями. В локальном тесте использовать настоящий builder/DTO и захват границы вызова; численный результат и CAS-readback проверяет K1.

**Не менять / не считать исправлением.** Не удалять ранний access-control для защищённых данных/действий; не выдавать fixture bundle за доступный источник; не строить второй world store.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_cyc_01.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T1. **Cross-boundary review:** X02. **Activation rules:** общие правила scope/приёмки.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/runtime/quality/generation_cycle.py` |
| Production write candidate | `policy-engine/src/polisyos/runtime/quality/recursive_generation_cycle.py` |
| Production write candidate | `policy-engine/src/polisyos/runtime/http/services/control/generation_cycle.py` |
| Production write candidate | `policy-engine/src/polisyos/runtime/http/services/control/run_lifecycle.py` |
| Read / consumer contract | `policy-engine/src/polisyos/runtime/quality/world_model_record.py` |
| Read / consumer contract | `policy-engine/src/polisyos/runtime/quality/joint_simulation_horizon.py` |
| Read / consumer contract | `policy-engine/src/polisyos/foundry/methods/selection/advisor.py` |

**Не писать одновременно с:** SIM-01, CYC-03, EMP-01, CYC-04, CYC-02, CYC-05, RES-03. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B01 lines=205-216 sha256=515ee67aec37de92c27b20c9ddd90cc61c95c41608b1daf4eddc88d640c78759 -->
## B01. Контекст оценивания требуется до формирования оцениваемой задачи

*Источник карточки: A:B01. Унаследовано из прочитанной сводки A; не новый интеграционный прогон.*

**Происхождение и подтверждение:** P1; код, повторно прочитан в P3. В HTTP-композиции отсутствие `root_evaluation_context` отвергается до `build_design_problem_from_nl_request`. После компиляции отдельно проверяется привязка контекста данных к хэшу полученного `DesignProblem`. Требование заранее передать внутренний контекст может остановить обычный запрос ещё до содержательной работы. [A.R06: 450–565]

**Экономное расширение:** разделить общий предварительный допуск пользователя, ресурсов и инструментов и позднюю привязку оценивания к фактически полученному объекту. Для разрешённого чистого вычисления строить точный симуляционный контекст из реального результата N5; для действия с людьми или защищёнными данными сохранять необходимый допуск до действия. Уже существующий `simulation_value_execution_context` — точка переиспользования, не повод создавать второй EvalSafety. [A.R04: 1920–2200]

**Критерий:** обычный пользовательский вход без вручную созданного Python-контекста достигает разрешённого вычисления; чужой кандидат, чужая модель, неразрешённые данные и защищённое действие не проходят. Снятие одной ранней проверки без восстановления остальных привязок не считается исправлением.

**Ограничение и приоритет:** не доказана невозможность всех видов запуска; установлен порядок конкретной композиции. Высокое влияние, средняя интеграционная сложность. Зависит от B02–B03.

<!-- END_SOURCE_CARD B01 -->

<!-- SOURCE_CARD B02 lines=217-228 sha256=6b6265c0da20f55356b1a97a791c6d2e909fd1a38c32b8ccd8375bce507c1f38 -->
## B02. Контекст данных и модели не должен теряться при передаче между слоями

*Источник карточки: A:B02. Унаследовано из прочитанной сводки A; не новый интеграционный прогон.*

**Происхождение и подтверждение:** P1; статическое наблюдение о стандартной композиции. Нижележащий маршрут принимает `cycle_substrate_context`; N4 при его отсутствии возвращает `cycle_substrate_context_unavailable`. Поэтому снятие B01 само по себе не включает настоящий генератор. [A.R04: 1130–1235; A.R05: 600–705; A.R06]

**Экономное расширение:** после компиляции разрешить существующий `CycleSubstrateContext` через его владельцев и провести одну точную привязку через HTTP → рекурсию → лист N6 → N4/N5/N8. Использовать существующие сборщики и проверку идентичности, не создавать другой store или параллельное представление мира.

**Критерий:** один и тот же контекст действительно потреблён всеми стадиями; изменённый `DesignProblem`, другой WMR или иная версия каталога дают конкретный отказ. Отсутствующий настоящий источник остаётся отсутствующим, а не заполняется тестовым bundle.

**Ограничение и приоритет:** это не утверждение, что контексты нигде не строятся: в проекте есть отдельные подготовленные маршруты и контекстные вызовы. Высокое влияние; средняя сложность соединения. Проверять вместе с B01 и B03.

<!-- END_SOURCE_CARD B02 -->

<!-- SOURCE_CARD B03 lines=229-240 sha256=9dcbf9befc0921cfe71e8cb743417b59cc9faec769ae21342ff874c21260314d -->
## B03. N5 ожидает готовый запрос вместо штатной сборки его входа

*Источник карточки: A:B03. Унаследовано из прочитанной сводки A; не новый интеграционный прогон.*

**Происхождение и подтверждение:** P1/P2; код. `JointSimulationPort` получает `joint_simulation_request_factory` или готовый `joint_simulation_request` из `runtime_hints`. Без них возможен корректный WMR, но возвращается `joint_simulation_request_missing`. Это разрыв сборки входа, а не отсутствие симуляторов. [A.R04: 1330–1503]

**Экономное расширение:** узкий сборщик из реального кандидата, связанных атомов вмешательства, WMR, требуемых исходов, горизонта, разрешённого бюджета и применимого существующего движка. Использовать `WorldModelSimulationInput` и входные привязки Foundry. У неизвестного параметра должен быть собственный пробел, а не молчаливое численное значение. [A.R08; A.R13]

**Критерий:** штатный запрос приводит к реальному вызову подходящего метода; изменение существенной привязки отвергается. Сохраняемая спецификация и серверное разрешение ссылок заменяют несериализуемый callable на пользовательском долговременном пути.

**Ограничение и приоритет:** не установлено отсутствие всех фабрик во всём репозитории. Нельзя обеспечить произвольную задачу универсальным заполнением полей. Высокое влияние, средняя сложность; это необходимая связка, а не новый движок.

<!-- END_SOURCE_CARD B03 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**A.R04, L.S03, L.S04, L.S05, L.S06, L.S08, L.S11, L.S12, L.S13, L.S18, L.S19, L.S20, L.S21, L.S22, L.S24, L.S25.** `runtime/quality/generation_cycle.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/runtime/quality/generation_cycle.py). 255–415; 1000–1830; 1920–2965; 3210–4170; 4460–4660; Прочитанные участки исходника; не запуск модуля

**A.R05, L.S09.** `runtime/quality/recursive_generation_cycle.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/runtime/quality/recursive_generation_cycle.py). 1–180; 600–760; Прочитанные участки исходника; не запуск модуля

**A.R06, L.S01.** `runtime/http/services/control/generation_cycle.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/runtime/http/services/control/generation_cycle.py). 1–245; 450–680; Прочитанные участки исходника; не запуск модуля

**A.R07, L.S02.** `runtime/http/services/control/run_lifecycle.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/runtime/http/services/control/run_lifecycle.py). ветвь natural_language_run; 3040–3500; compile_and_run_recursive_generation_cycle; Прочитанные участки исходника; не запуск модуля

**A.R08, L.S07.** `runtime/quality/joint_simulation_horizon.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/runtime/quality/joint_simulation_horizon.py). 210–340; 420–810; 970–1370; 1460–1815; Прочитанные участки исходника; не запуск модуля

**A.R13, L.S29.** `runtime/quality/world_model_record.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/runtime/quality/world_model_record.py). 1–315; Прочитанные участки исходника; не запуск модуля

**C.Q01, C.Q02, C.Q03, C.Q04, C.Q12.** `foundry/methods/selection/advisor.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/selection/advisor.py). [[1080, 1590]]; [[660, 950]]; [[1630, 1885]]; [[1910, 2210]]; [[3450, 3635]]

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
