<a id="bundle-doe-02"></a>

# DOE-02 — Один дизайн распределений и локальные RNG

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B100, B101**. Локальный класс: **N**. Укрупнённая приёмка: **K3**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** DOE-01. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Определить единый backend mapping закона с настоящей параметризацией для sampler/analyzer. Передать version-compatible seed/Generator библиотеке, разделить logical substreams и убрать global NumPy reset.

**Минимальные различающие проверки.** Корректно заданные UNIFORM/NORMAL действительно меняют sample support/квантили. Одинаковый seed повторяет малую выборку; порядок независимых задач не меняет inputs; внешний RNG не сбрасывается. Один маленький настоящий SALib/SciPy путь выполняется в слоте N.

**Не менять / не считать исправлением.** Не копировать только dists без смысла mean/std/bounds. Не читать неоднозначные старые планы как uniform; не превращать reuse в новую реплику.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_doe_02.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T9. **Cross-boundary review:** X15. **Activation rules:** общие правила scope/приёмки.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/scientist/methods/doe/sampling.py` |
| Production write candidate | `policy-engine/src/polisyos/scientist/methods/doe/analysis.py` |
| Production write candidate | `policy-engine/src/polisyos/scientist/methods/doe/designs.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/methods/doe/uncertainty.py` |

**Не писать одновременно с:** DOE-01, DOE-03. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B100 lines=2666-2677 sha256=34825cfe459b3861a6461797f12e9e1983399355660131e224359e5d9984fd67 -->
## B100. Sampling и analysis используют разные определения распределений параметров

**Основание и область:** две функции `_plan_to_salib_problem` в sampling.py и analysis.py, `ParameterSpec`. Высокий при неравномерных распределениях; M. [C09.R01, R03, R05, E02]

**Проблема.** В sampler передаются только имена, число параметров и пары границ. `distribution` отсутствует. Analyzer для того же плана добавляет `norm`, `lognorm` или `triang`. Таким образом, изменение заявленного распределения не изменяет переданное sampler описание, а два этапа уже не ссылаются на одно определение эксперимента. Это не утверждение, что каждый SALib analyzer использует эти метки одинаково; первичен сам разрыв между планом и генерацией.

**Локальный опыт D1–D3.** Для NORMAL и UNIFORM с одинаковыми границами sampling-helper вернул одинаковые словари; analysis-helper для NORMAL добавил `dists=['norm']`. Для UNIFORM оба совпали. Эти helpers исполнены целиком. Реальная SALib-выборка не генерировалась.

**Рекомендуемое решение.** Единое разрешённое определение распределений и преобразования в backend, используемое и producer, и analyzer, сохранённое с дизайном. Не ограничиваться копированием поля `dists`: интервальные границы, параметры нормального/логнормального закона и параметры треугольного закона имеют разный смысл. Нынешние `lower_bound/upper_bound` с проверкой порядка нельзя автоматически переименовать в mean/std. Неоднозначные старые планы должны получать адресное уточнение/миграцию, а не молча исследоваться как uniform.

**Приёмка.** Проверить содержательное изменение сэмплов при смене закона с фиксированным допустимым RNG; support, квантили и способ усечения; round-trip описания; совпадение sampler/analyzer fingerprint. Нормировка и независимость параметров являются научными предпосылками и не создаются удобством адаптера. Для однозначного UNIFORM сохранить нынешний работающий путь.

<!-- END_SOURCE_CARD B100 -->

<!-- SOURCE_CARD B101 lines=2678-2689 sha256=1245f7e21214f8264fc2921296954e64869c1758685cccde09eebef16fda2c66 -->
## B101. Seed плана не доходит до локального генератора библиотеки, но меняет глобальный NumPy state

**Основание и область:** sensitivity sampling/analysis и `_set_numpy_seed`; актуальные интерфейсы SALib и SciPy. M, либо S для явной передачи поддерживаемого seed. [C09.R01, R03, E01]

**Проблема.** Sampling вызывает `np.random.seed(plan.seed)`, но не передаёт `seed` в вызовы SALib. В sensitivity analyzers он также не передаётся. У библиотечных реализаций, использующих собственный Generator/QMC, глобальное legacy-seed не заменяет seed конкретного генератора. Одновременно helper меняет случайное состояние соседних потребителей. Это зависит от версии/backend; не следует объявлять одинаково неверными все SALib-реализации.

**Локальный опыт S1–S4.** Boundary-spy подтвердил отсутствие `seed` в переданном вызове при `plan.seed=13`. Настоящий SciPy QMC дал разные сетки после одинаковых `np.random.seed(13)`, но одинаковые при явном seed самого Sobol-генератора. Этот опыт не назван запуском SALib. RANDOM_TAIL использует свой `default_rng(plan.seed)` и повторяет собственные значения, но всё равно сбрасывает внешнее состояние через предшествующий helper.

**Рекомендуемое решение.** Передавать seed/Generator через поддерживаемый versioned backend API; независимые стадии sampling, model randomness и uncertainty получают определённые под-потоки. Сохранить идентичность реплики и дизайна при resume и кэшировании. Не использовать глобальный reset в общем процессе. Для неизбежного legacy backend нужна изоляция, а не один локальный lock, которого не соблюдают остальные библиотеки.

**Приёмка.** Одинаковый полный запрос в заявленной версии воспроизводим; другая seed/replica меняет нужную случайную часть; перестановка независимых задач не меняет их входы. Повторная статистическая реплика и cache-hit не должны считаться двумя независимыми наблюдениями. Подключение локальных генераторов не удостоверяет само по себе сходимость или достоверность модели мира.

<!-- END_SOURCE_CARD B101 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**C09.R01. Генерация sensitivity и adversarial samples.** `policy-engine/src/polisyos/scientist/methods/doe/sampling.py`. Полный файл, 99 строк. Локальная копия сверена по Git blob; исполнение с явно описанными fixtures. Git blob `0fd0b7a5d9544ba7ddca36b948fcead82f948020`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/doe/sampling.py).

**C09.R03. Подготовка прогонов и анализ чувствительности.** `policy-engine/src/polisyos/scientist/methods/doe/analysis.py`. Полный файл, 249 строк. Локальная копия сверена по Git blob; исполнение с явно описанными fixtures. Git blob `83efbf7c9f48f7c4e65f7274e60ca3572ffc240e`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/doe/analysis.py).

**C09.R05. Контракты планов, распределений и отказов.** `policy-engine/src/polisyos/scientist/methods/doe/designs.py`. Полный файл, 211 строк. Локальная копия сверена по Git blob; исполнение с явно описанными fixtures. Git blob `5f5be37b314dca1a8842bc0298bddc24019fce96`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/doe/designs.py).

**C09.R06. Morris elementary effects, row blocks и bootstrap.** `policy-engine/src/polisyos/scientist/methods/doe/uncertainty.py`. Прочитанные окна: 414–550. Полная локальная копия не заявлена. Git blob `a2d800683e1a9b28e6e76d825b340a608a72e994`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/doe/uncertainty.py).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
