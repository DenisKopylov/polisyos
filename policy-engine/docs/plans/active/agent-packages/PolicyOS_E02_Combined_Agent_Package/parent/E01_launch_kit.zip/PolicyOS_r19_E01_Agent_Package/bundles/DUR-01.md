<a id="bundle-dur-01"></a>

# DUR-01 — Аварийно-устойчивый бюджетный snapshot

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B37**. Локальный класс: **L**. Укрупнённая приёмка: **K2**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** нет; после общего SETUP-01 и короткой проверки current base. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Согласовать чтение/запись file-ledger на стабильном lockfile и атомарной публикации. Отделить отсутствующий новый ledger от повреждённого существующего. Сохранить ревизии, fsync и действующий owner.

**Минимальные различающие проверки.** Пауза writer после начала записи не даёт читателю blank=no-limits. Обрыв JSON и controlled crash между temp/write/replace оставляют valid old/new либо адресное восстановление, не обнуление расходов. Повтор чтения не списывает новую работу.

**Не менять / не считать исправлением.** Не создавать вторую SQLite/бюджетную подсистему, не блокировать на inode заменяемого snapshot и не принимать повреждение за свежий BudgetState.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_dur_01.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T3. **Cross-boundary review:** X09. **Activation rules:** общие правила scope/приёмки.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/scientist/orchestration/engine/budget_ledger.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/orchestration/engine/budget_middleware.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/orchestration/engine/budget.py` |
| Read / consumer contract | `policy-engine/src/polisyos/core/artifacts/_atomic_write.py` |

**Не писать одновременно с:** нет установленного совпадения production paths в этой статической карте. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B37 lines=700-717 sha256=4cb4cba956a6535facb92240a7755afd76eabd8c50ecda00d76e607299ab9985 -->
## B37. Бюджетный файл защищён при записи, но читатель может увидеть промежуточную пустоту

*Источник карточки: C02-04. Унаследовано из полного C02/r01; 25 исторических локальных записей.*

**Источник:** C.Q05–C.Q07. **Свидетельство:** полное чтение основных методов ledger; B1–B4 на локальной файловой системе. **Достижимость:** используется FileBudgetLedger, чтение пересекается с записью либо запись прервана.

У FileBudgetLedger уже есть блокировка писателей, журнал ревизий, fsync и интерфейс через BudgetMiddleware. Поэтому проблема не в отсутствии бюджетной подсистемы. Однако `_persist_snapshot` делает ftruncate(0), затем запись, а `_load_snapshot` читает путь без согласованной file-lock. Пустое содержимое интерпретируется как отсутствие снимка; `load` возвращает `BudgetState()` без лимитов. BudgetState.remaining для неуказанного лимита возвращает None, и pre_check не трактует это как исчерпание.

В локальном опыте writer удерживал LOCK_EX и был остановлен в контролируемой точке после ftruncate. Незаблокированный читатель прочитал пустоту. Отдельный читатель с LOCK_SH|LOCK_NB корректно обнаружил занятость; после завершения записи прочитал полный новый снимок. Для искусственно оборванного JSON воспроизведён JSONDecodeError. Это не измерение частоты гонки и не имитация полного сбоя питания.

Проблема двойная: неполное состояние может остановить цикл исключением, а пустота может временно выглядеть как отсутствие ограничения. После сбоя пустой существовавший файл нельзя автоматически считать новым ledger с нулевым расходом.

**Разумное расширение.** Для текущего file-backed владельца согласовать чтение и запись; различить «ещё не создано» и «существующий снимок повреждён/оборван». Для устойчивого сохранения использовать полную запись временного файла с fsync и атомарную замену в той же файловой системе, затем синхронизацию директории и реальную процедуру восстановления. При replace замок следует держать на стабильном отдельном lockfile, а не на заменяемом inode данных. Один LOCK_SH у читателя уменьшает окно гонки, но не устраняет повреждение после аварии. [C.E01/C.E02]

Альтернативный путь — использовать подходящую существующую транзакционную реализацию хранения, не вводя новый сервис. Выбор нужно согласовать с действующими требованиями multi-host/ledger; просто поменять JSON на ещё одну параллельную SQLite-базу не является целью.

**Проверка:** конкурентное чтение не видит пустой частичный бюджет; авария между стадиями записи сохраняет проверяемое старое или новое состояние; повреждённый ledger не отменяет лимиты и не обнуляет расходы. Поздняя попытка не расходует бюджет второй раз под тем же идентификатором операции — это отдельное условие идемпотентности, не доказанное текущими опытами.

<!-- END_SOURCE_CARD B37 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**C.Q05.** `scientist/orchestration/engine/budget_middleware.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/budget_middleware.py). [[1, 290]]

**C.Q06.** `scientist/orchestration/engine/budget_ledger.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/budget_ledger.py). [[1, 510]]

**C.Q07.** `scientist/orchestration/engine/budget.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/budget.py). [[1, 320]]

**C07.R05. BudgetState: исследованная гипотеза, не новая карточка.** `policy-engine/src/polisyos/scientist/orchestration/engine/budget.py`. Окна чтения: возвращённый полный текст / metadata. Git blob SHA: `1a2fbb73bb87d60674d168791a214f882e79347f`. Получен полный текст; production-admission не установлен. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/budget.py).

**C07.R06. BudgetMiddleware: advisory check и reservation lifecycle.** `policy-engine/src/polisyos/scientist/orchestration/engine/budget_middleware.py`. Окна чтения: возвращённый полный текст / metadata. Git blob SHA: `9ec1ef8622779386ff7740df58781caa9643c9d4`. Получен полный текст; не новая отдельная finding. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/budget_middleware.py).

**C14.R06. AtomicFileWriter: write_once и атомарная замена.** `policy-engine/src/polisyos/core/artifacts/_atomic_write.py`. Прочитан полный файл. Полный локальный файл сверен по Git blob. Git blob `3592cb0f87498c4f58d254965ccd1c267b9408ee`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/core/artifacts/_atomic_write.py).

**C.E01.** `Python os.replace / fsync`. [Открыть закреплённый источник](https://docs.python.org/3.14/library/os.html). 

**C.E02.** `Python fcntl / flock`. [Открыть закреплённый источник](https://docs.python.org/3.14/library/fcntl.html). 

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
