<a id="bundle-dur-02"></a>

# DUR-02 — Поколение worker и безопасный backend handover

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B38, B78**. Локальный класс: **L**. Укрупнённая приёмка: **K2**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** RUN-03, RES-02. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Связать complete/fail/progress с актуальными owner/attempt/lease, проверять affected rows и согласовать status/event. Fallback различает pre-dispatch недоступность и неопределённый post-dispatch исход; после старта сначала сверка фактически завершённой работы.

**Минимальные различающие проверки.** Stale worker A не портит running/completed attemptB; актуальный B завершает. Primary создал тестовый эффект и потерял ответ — local не повторяет его вслепую. Unhealthy/probe-network-error до старта допускает только разрешённый fallback; access/contract failure не даёт нового права.

**Не менять / не считать исправлением.** Не обещать exactly-once внешних действий одним SQL UPDATE; не считать локальную отмену достаточным fencing и не обнулять существующий CAS-результат.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_dur_02.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T3, T6. **Cross-boundary review:** X04, X10. **Activation rules:** A09.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/runtime/http/services/control_worker.py` |
| Production write candidate | `policy-engine/src/polisyos/runtime/http/services/control_plane_store.py` |
| Production write candidate | `policy-engine/src/polisyos/scientist/orchestration/engine/runner/fallback_runner.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/orchestration/engine/runner/local_runner.py` |

**Не писать одновременно с:** нет установленного совпадения production paths в этой статической карте. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B38 lines=718-735 sha256=55b93abe088e8226f8e0ba2338c2327152689127d999c19c1ea20e6963f50b06 -->
## B38. Старый исполнитель способен перезаписать состояние новой попытки задания

*Источник карточки: C02-05. Унаследовано из полного C02/r01; 25 исторических локальных записей.*

**Источник:** C.Q08a/C.Q08b. **Свидетельство:** worker и store прочитаны; SQL-предикаты исполнены на SQLite в L1–L4. **Достижимость:** lease утрачен/передан, но старый обработчик ещё работает.

`renew_job_lease` обновляет запись лишь при совпадении running-state и lease_owner. Но метод возвращает None и не сообщает о нулевом количестве обновлённых строк. В ControlWorker поток heartbeat при недоступности store может завершиться, не останавливая сам handler. `complete_job`, `fail_job` и обновление progress в прочитанных интерфейсах не принимают ожидаемый номер попытки/владельца; финальный UPDATE ограничен только job_id.

В локальной SQLite-схеме задание уже принадлежит worker-B, attempt=2. Продление от worker-A обновило 0 строк; затем форма UPDATE из fail_job обновила 1 строку и оставила failed с ошибкой старой попытки. Отдельно ранее completed attempt=2 также был изменён на failed. Контроль с условием ожидаемых owner/attempt/running/valid lease отверг старого писателя и допустил актуального.

Это не полный запуск ControlWorker и не утверждение о реально случившемся двойном внешнем действии. Но отсутствие fencing в этих SQL-предикатах установлено прямо. Сценарий возможен уже при локальном перезапуске или кратком сбое связи, не только в большом кластере.

**Разумное расширение.** Сделать право прикрепить результат к заданию зависимым от актуальных `(job_id, lease_owner, attempt)` и соответствующего действительного поколения владения. Проверять affected-row count. Потеря lease должна доходить до исполнителя как отмена/запрет нового защищённого действия; восстановление само по себе не может вернуть старой попытке право финализации. Сохранившийся CAS-артефакт устаревшей попытки допустимо оставить для диагностики, но нельзя прикреплять его как актуальный результат новой.

Изменение terminal, привязанного progress и соответствующего события следует согласовать транзакционно. В том же store `append_normative_evidence_head` уже использует проверку ожидаемого predecessor и транзакцию SQLite/PostgreSQL; это полезный локальный пример, не разрешение переносить его предметные полномочия. [C.Q08a/C.Q08b, C.E03]

**Проверка:** старый worker не завершает и не портит новую попытку; актуальный завершает; ошибка между фиксацией статуса и события восстанавливается без противоречивой истории. Условие UPDATE не обеспечивает exactly-once для внешних действий: им отдельно нужны разрешение, идемпотентность и проверка актуального исполнителя.

<!-- END_SOURCE_CARD B38 -->

<!-- SOURCE_CARD B78 lines=1999-2014 sha256=93c248082a0e76e9ad7e91276e92316bc07d4159dae3031f553da1377444b9d0 -->
## B78. Fallback не различает «ещё не начали» и «выполнили, но потеряли подтверждение»

**Происхождение:** C06-09. **Основание:** полный `fallback_runner.py`, сверенный по Git blob SHA-1, factory config и четыре R78-контроля. **Приоритет:** высокий при включённом переключении backend; M. [C06.R07–R08]

**Проблема после старта.** При healthy primary обёртка перехватывает широкий набор ошибок исполнения, включая RuntimeError/OSError/ValueError, и вызывает локальный runner с прежними workflow/state и переданными изначально seed refs. В этой границе не установлено, какие операции уже завершены, какие внешние действия произошли и продолжает ли primary работать. Сообщение об ошибке не доказывает отсутствие результата или эффекта.

В опыте исполнен весь неизменённый модуль обёртки с фикстурными primary/local и заменёнными импор­тами инфраструктуры. Primary записал один тестовый эффект и выбросил RuntimeError «потеря подтверждения». Local записал второй: история `primary, local`. Это не настоящий денежный платёж, не производственный дубликат и не запуск Ray/Temporal. Реальный downstream может иметь собственную идемпотентность или восстановленный кэш; их отсутствие во всём проекте не заявляется. Установлено отсутствие достаточного различения на самой границе fallback.

**Обратный дешёвый пробел.** `health = await self.health_check()` находится вне защищённой ветви. OSError самого probe проходит наружу без вызова local. В контроле же обычный `healthy=False` правильно переключил на local до substantive-исполнения. Эти случаи требуют разных действий, а не универсального except с повтором.

**Рекомендуемое решение.** Отделить отказ подготовки до любого исполнения от ошибки после dispatch и неопределённого исхода. До старта допустимо безопасное переключение в разрешённый backend. После старта — сначала сверка действительного рубежа, владения попыткой, результатов и внешних эффектов; затем продолжение лишь недоделанной работы. Старый исполнитель должен утратить право актуальной записи через существующий fencing/attempt-механизм B38, а не только через локальную отмену ожидания. Для неидемпотентного внешнего действия необходима сверка или идемпотентный operation ID, не новый случайный ID на повтор.

Временная ошибка health-probe до начала работы может давать классифицированную недоступность и разрешённый local fallback. Ошибку контракта, tenant/access или конфигурации нельзя автоматически превращать в право выполнить в другом месте. Разрешение сменить вычислительную среду не выводится из одного network exception.

**Приёмка.** Healthy success — один primary; unhealthy до старта — один local; временный сбой probe — предусмотренный ограниченный переход; потеря ответа после эффекта — сверка, не второй эффект. Существующий общий deadline и бюджет охватывают handover. Для чисто локального первого T1 без fallback эта карточка не становится новой обязательной предпосылкой.

<!-- END_SOURCE_CARD B78 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**C.Q08a.** `runtime/http/services/control_worker.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/runtime/http/services/control_worker.py). [[1, 310]]

**C.Q08b.** `runtime/http/services/control_plane_store.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/runtime/http/services/control_plane_store.py). [[650, 920], [1720, 2070], [2570, 3180]]

**C06.R01. Scientist: checkpoint, delta, фиксация и materialize.** `policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py`. Окна чтения: 1–250, 360–700, 975–1250, 1420–1750. Git blob SHA: `dd90c9121de3e14b7ea2ff8db4781fa3ef750334`. Типы, scope, hook, delta, создание и материализация checkpoint; не полный аудит файла. [Закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py).

**C06.R02. Scientist: resume и остаточный workflow.** `policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py`. Окна чтения: 975–1120, 1760–2070. Git blob SHA: `dd90c9121de3e14b7ea2ff8db4781fa3ef750334`. Pruning, fingerprint и resume; последнее окно до конца полученного файла. Повтор того же blob, а не второй независимый источник. [Закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py).

**C06.R04. Локальный runner: передача остаточного workflow.** `policy-engine/src/polisyos/scientist/orchestration/engine/runner/local_runner.py`. Окна чтения: 1–240. Git blob SHA: `3d789d27667fb75bbcac07e03a446a5255b31b82`. Получен полный короткий файл; LocalWorkflowRunner делегирует AsyncWorkflowExecutor. [Закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/runner/local_runner.py).

**C06.R07. Переключение primary → local runner.** `policy-engine/src/polisyos/scientist/orchestration/engine/runner/fallback_runner.py`. Окна чтения: 1–300. Git blob SHA: `383018a98c9c74c76aaad294cbe644b199a49676`. Полный короткий файл; локальные байты сверены по Git blob, затем исполнены с четырьмя заменёнными инфраструктурными импортами. [Закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/runner/fallback_runner.py).

**C.E03.** `SQLite transactions`. [Открыть закреплённый источник](https://sqlite.org/lang_transaction.html). 

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
