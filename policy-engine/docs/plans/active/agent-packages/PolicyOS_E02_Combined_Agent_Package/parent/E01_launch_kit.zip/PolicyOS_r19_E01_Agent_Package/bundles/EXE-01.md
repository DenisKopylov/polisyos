<a id="bundle-exe-01"></a>

# EXE-01 — Допуск cache read, неблокирующий I/O и fail-fast

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B51, B52, B55**. Локальный класс: **L**. Укрупнённая приёмка: **K2**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** STA-01, RUN-01. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Развести разрешённое чтение готового результата и новое вычисление. Подключить имеющуюся ограниченную async-границу CAS с эффективным deadline. Повторно проверять fail-fast после получения semaphore, всегда освобождая ресурс.

**Минимальные различающие проверки.** Hit при нулевом compute-budget читается только при разрешённом read-budget; miss не запускает producer. Медленный local store не блокирует соседнюю coroutine. Parallelism=1 и fail первого из четырёх не запускает остальных при fail_fast, но continue выполняет их.

**Не менять / не считать исправлением.** Не переносить все access/deadline проверки за cache-hit; не создавать pool на каждый I/O и не считать отмену await прекращением underlying write.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_exe_01.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** адресные проверки B-карточек; общий K6. **Cross-boundary review:** X03, X09. **Activation rules:** общие правила scope/приёмки.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/scientist/orchestration/engine/async_executor.py` |
| Production write candidate | `policy-engine/src/polisyos/core/artifacts/async_store.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/orchestration/engine/idempotency.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/orchestration/engine/budget_middleware.py` |
| Read / consumer contract | `policy-engine/src/polisyos/common/async_tools.py` |

**Не писать одновременно с:** RES-02, RES-01, EXE-02. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

**Связанные карточки для адресного чтения, не второе назначение:** B13 → RES-03; B39 → RUN-03; B40 → RUN-01.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B51 lines=1331-1346 sha256=e9b4ac7cef4037c2a72c1e5b9ebef5401d821d718b1be3dfb7b4fd44c38004f8 -->
## B51. Исчерпанный бюджет нового вычисления не даёт прочитать уже готовый кэш

**Происхождение:** C04-03. **Основание:** `_execute_node` в `AsyncWorkflowExecutor`, BG1–BG4. **Приоритет:** высокий для разрешённого replay/продолжения; охват S–M. [C04.K03, C04.K04]

**Проблема.** Сначала вычисляется cache-key, затем `BudgetMiddleware.pre_check(alias)` и threshold alerts. При исчерпании бюджета возвращается `node.budget_exhausted`. Только после этого вызывается `self._cache.get(cache_key)`. Поэтому готовый допустимый результат не рассматривается вообще, даже если дальнейшее новое вычисление не требуется.

В модели BG1 готовый hit при нулевом остатке дал отказ с нулём чтений кэша. Контроль BG2 сначала допустил ограниченное чтение и вернул сохранённое с нулём новых compute-вызовов. BG3 при miss и нулевом compute-бюджете по-прежнему отказал; BG4 при запрещённом чтении отказал до обращения к данным.

**Рекомендуемое решение.** Разрешать бюджет и допуск относительно фактического действия. Сначала актуальные права, область использования и небольшой разрешённый бюджет чтения/проверки; затем cache lookup и проверка настоящего артефакта. Только при miss запрашивать бюджет нового вычисления. Использовать существующее слияние разрешённых state-writes и проверку происхождения результата, а не подменять текущий state целиком сохранённым старым.

**Важное условие.** Это решение применимо, если политика действительно различает чтение готового и запуск нового. Если достигнут общий жёсткий deadline, запрещено любое дальнейшее I/O либо нет права читать источник, hit не получает исключение. Cache lookup тоже стоит CPU/I/O и может оказаться повреждённым. Поэтому простое переставление всех проверок после hit без анализа их назначения недопустимо.

**Почему это расширяет цикл.** Последний оплаченный шаг может завершить вычисление и исчерпать compute-бюджет; следующий законный потребитель должен суметь прочитать уже полученное, если это разрешено его собственными лимитами. Иначе экономия за счёт reuse существует технически, но не достигает пользователя.

**Приёмка.** Hit не запускает producer повторно и не списывает его прежний расход как новый; miss не обходит бюджет; повреждение или смена прав не превращаются в успешный hit; обязательный бюджетный учёт не отключается. Диагностика различает запрет чтения, исчерпание compute и отсутствие результата. Установлен порядок данного async-пути, не всех исполнителей PolicyOS.

<!-- END_SOURCE_CARD B51 -->

<!-- SOURCE_CARD B52 lines=1347-1362 sha256=1a6929c4d593f31111984bfc232aa5047093e63c0ae8b30bc8a77f988c193ab9 -->
## B52. Синхронное чтение и запись кэша блокируют асинхронный исполнитель

**Происхождение:** C04-04. **Основание:** `AsyncWorkflowExecutor._execute_node` → `NodeResultCache.get/put` → синхронный artifact store; IO1/IO2. **Приоритет:** зависит от размера артефактов и latency хранилища; охват M. [C04.K03, C04.K04]

**Проблема.** Внутри async-функции напрямую вызываются синхронные `self._cache.get()` и `put()`. Первый читает bytes, разбирает canonical-пакет и для output-aware результата проверяет целостность и manifests. Второй сериализует outcome со state и сохраняет outcome плюс cache-entry, также с необходимыми проверками. Медленное хранилище либо большой payload занимает поток event loop; остальные готовые задачи не продвигаются. Сама метка async вокруг внешнего метода этого не меняет.

**Опыт.** При фикстурном синхронном чтении длительностью около 80 мс фоновая coroutine не получила ни одного такта во время чтения. Контроль с вынесенным чтением дал 26 тактов. Общая длительность в контроле не стала меньше — и это не заявляется: тест проверяет отзывчивость других задач, а не ускорение диска. Это ограниченная модель, не измерение настоящего CAS и не импорт `NodeResultCache`.

**Рекомендуемое решение.** Провести асинхронный путь cache/CAS через существующий `AsyncArtifactStore`/`AsyncArtifactStoreAdapter` либо ограниченно вынести действительно синхронную операцию из event loop. Такой адаптер в проекте уже есть. Но его стандартный timeout и общий executor тоже должны получать согласованный остаток deadline; механическое подключение способно вернуть ранее найденный B40. [C04.K06]

Для store с ограничениями на потоки нужна подходящая граница владения соединением, а не случайный thread pool. Проверки целостности, output-aware epoch, tenant/access и current applicability сохраняются. Большую CPU-сериализацию следует отдельно профилировать: `to_thread` не гарантирует ускорения CPU-кода под GIL. Не следует создавать отдельный executor на каждый get/put или складывать неограниченную очередь в общий пул. [C04.E03]

**Дополнительное экономное решение.** На подтверждённом hit не делать предварительные копии, нужные только новому producer, когда существующая процедура слияния позволяет безопасно отложить их. Это гипотеза оптимизации, не измеренная стоимость `branch_state`. Переписывать весь outcome-cache в delta-cache без анализа потребителей сейчас не предлагается.

**Приёмка.** Во время медленного cache I/O независимые задачи продолжаются; deadline понятен; отменённая запись не публикуется наполовину; полностью записанный артефакт читается после восстановления. Измерять p95/p99 ожидания соседних задач, объём сериализации и стоимость hit, а не один общий hit-rate. Полезный readback не должен обходить действующие проверки ради скорости.

<!-- END_SOURCE_CARD B52 -->

<!-- SOURCE_CARD B55 lines=1395-1408 sha256=26067194bc63e79de6b0a05c8ec8d1baa08f15661428174ded6ddbeea336a422 -->
## B55. Fail-fast не останавливает задачи, уже ожидающие свободный слот

**Происхождение:** C04-07. **Основание:** `_run_parallel_tier` в `AsyncWorkflowExecutor`; FF1–FF3. **Приоритет:** высокий при дорогих ожидающих узлах; охват S. [C04.K03]

**Проблема.** `cancel_event.is_set()` проверяется до `await semaphore.acquire()`. Если событие установлено, пока задача ждала, повторной проверки после получения слота нет: вызывается `_execute_node`. При возвращённом `status='fail'` и `error_policy='fail_fast'` событие устанавливается, но уже ожидающие coroutine прошли свой единственный тест. Это отдельный механизм от прежнего B13 о сохранности результатов и B39 о retries.

**Локальный опыт.** При parallelism=1 четыре задачи одновременно вошли в процедуру, затем первая вернула fail. Текущий порядок запустил все четыре. Контроль с проверкой сразу после acquire запустил только первую; три остальных получили skip. При политике continue контроль продолжил все четыре, как и требовалось. События гарантировали, что остальные уже ожидают до первого отказа; случайная гонка не использовалась как доказательство.

**Рекомендуемое решение.** Перепроверить актуальность допуска после получения semaphore и непосредственно до substantive-вызова, внутри защищённого `try/finally`, всегда освобождающего слот. Отделить ожидающую работу, которую ещё можно не запускать, от уже выполняющейся: последней нужны её собственные правила остановки и сохранения. Не превращать fail_fast в неуправляемое убийство потоков либо потерю завершённых независимых результатов.

**Почему это дешёвый выигрыш.** Один дополнительный правильный пункт проверки сохраняет бюджет для следующего осмысленного действия. Увеличение parallelism не решает проблему — оно может лишь быстрее запустить ненужные работы. При этом политика continue остаётся самостоятельным корректным режимом.

**Приёмка.** На насыщенном малом семафоре отказ первой задачи не запускает следующих; все слоты освобождены после ошибки/отмены; уже завершённые результаты сохраняются; continue работает прежним образом. Отдельно проверить падение необязательной метрики между acquire и execute: ни один такой путь не должен обходить освобождение ресурса. Последнее — требование приёмки границы, не дополнительная девятая карточка.

<!-- END_SOURCE_CARD B55 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**A.R10, L.S16, C.Q10.** `common/async_tools.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/common/async_tools.py). полный проектный модуль из предыдущего пакета; Полный модуль из прежнего пакета; в новом проходе совпадение Git blob SHA проверено и короткие задачи выполнены; [[1, 155]]

**C.Q05.** `scientist/orchestration/engine/budget_middleware.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/budget_middleware.py). [[1, 290]]

**C04.K03. Scientist AsyncWorkflowExecutor.** `policy-engine/src/polisyos/scientist/orchestration/engine/async_executor.py`. 500–740; 735–1030. Git blob: `5f0ac743d28ad0112b9f988f7ba47e10c4297249`. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/async_executor.py).

**C04.K04. NodeResultCache / idempotency.** `policy-engine/src/polisyos/scientist/orchestration/engine/idempotency.py`. 1–315. Git blob: `3ae08d7ccf0e35da459c74446d322a766e40c62a`. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/idempotency.py).

**C04.K06. Существующий async artifact store adapter.** `policy-engine/src/polisyos/core/artifacts/async_store.py`. 1–165. Git blob: `cfab46e12fe8c42af84b391e852da9ca91d33f08`. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/core/artifacts/async_store.py).

**C05.N03.** `policy-engine/src/polisyos/scientist/orchestration/engine/idempotency.py`. 35–275; 247–335. Ключ, запись всего outcome и процедуры восстановления; модуль целиком не импортирован. Git blob: `3ae08d7ccf0e35da459c74446d322a766e40c62a`. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/idempotency.py).

**C06.R03. Scientist: асинхронное исполнение, уровни, checkpoint и rollback.** `policy-engine/src/polisyos/scientist/orchestration/engine/async_executor.py`. Окна чтения: 100–250, 240–535, 535–735, 1090–1220. Git blob SHA: `5f0ac743d28ad0112b9f988f7ba47e10c4297249`. Фактическая передача workflow_fingerprint; одиночный skip; параллельное слияние и сохранение; барьер уровня. [Закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/async_executor.py).

**C07.R06. BudgetMiddleware: advisory check и reservation lifecycle.** `policy-engine/src/polisyos/scientist/orchestration/engine/budget_middleware.py`. Окна чтения: возвращённый полный текст / metadata. Git blob SHA: `9ec1ef8622779386ff7740df58781caa9643c9d4`. Получен полный текст; не новая отдельная finding. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/budget_middleware.py).

**C07.R07. AsyncWorkflowExecutor: потребитель pre_check.** `policy-engine/src/polisyos/scientist/orchestration/engine/async_executor.py`. Окна чтения: 735–1040. Git blob SHA: `5f0ac743d28ad0112b9f988f7ba47e10c4297249`. Для проверки достижимости budget-гипотезы, не полное исполнение. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/async_executor.py).

**C08.R08. Существующие мосты с copy_context.** `policy-engine/src/polisyos/common/async_tools.py`. Запрошенные окна: 1–230, для короткого файла — до конца. Git blob `01981db2ccbbb39ab54d2afa6ef3dafafcb0e3c0`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/common/async_tools.py).

**C04.E03. Python asyncio: блокирующий I/O и executors.** Первичная справка прочитана 18.09.2026; не утверждается совпадение версии со средой проекта. [Открыть источник](https://docs.python.org/3.12/library/asyncio-eventloop.html#executing-code-in-thread-or-process-pools).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
