<a id="bundle-exe-02"></a>

# EXE-02 — Готовность зависимостей вместо лишнего tier-ожидания

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B77**. Локальный класс: **L**. Укрупнённая приёмка: **K2**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** RES-02, RES-01. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Для доказанно независимого подграфа убрать чисто технический барьер: разблокировать successor после готовности его собственных входов. Сначала проверить read/write и атомарную единицу commit. Если tier — содержательная граница, сохранить её и зафиксировать неприменимость оптимизации к этому маршруту.

**Минимальные различающие проверки.** Управляемые события A и независимого B: C(A) стартует после A, не дожидаясь B; после добавления настоящего B→C ожидает обоих. Число методов, входы, seeds, provenance и checkpoint остаются прежними. Это тест расписания на крошечном DAG, не нагрузочный тест.

**Не менять / не считать исправлением.** Не строить новый scheduler, не снимать барьер при неизвестных mutable dependencies и не повышать worker-count ради результата.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_exe_02.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T6. **Cross-boundary review:** I2 по фактическим consumers. **Activation rules:** общие правила scope/приёмки.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/scientist/orchestration/engine/async_executor.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/orchestration/engine/state_merge.py` |

**Не писать одновременно с:** RES-02, EXE-01, RES-01. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

**Связанные карточки для адресного чтения, не второе назначение:** B59 → STA-01; B73 → RES-02.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B77 lines=1985-1998 sha256=9a964e072d3e3b2f8a636c8ba2d38de5e8ea300b9c7b11dbc7c5e09463fe392f -->
## B77. Барьер уровня задерживает узел, чьи собственные зависимости уже готовы

**Происхождение:** C06-08. **Основание:** topo_sort_tiers и ожидание всего `_run_parallel_tier`; R77-1/R77-2. **Приоритет:** условная производительная оптимизация после корректной фиксации; M. [C06.R03, C06.E02, C06.E03]

**Наблюдение.** AsyncWorkflowExecutor выполняет уровни графа последовательно; следующий уровень начинается после завершения всего предыдущего. Непосредственные зависимости узла могут закончиться существенно раньше медленного независимого соседа. Свободный исполнитель при этом не получает уже потенциально готовую работу.

**Различающий расчёт расписания.** Два worker: A длится 2 условные единицы, независимый B — 9; C зависит только от A и длится 8. Послойное расписание запускает C на отметке 9 и заканчивает на 17. При запуске C после готовности A — C начинается на 2, всё заканчивается на 10. Это точная модель выбранного расписания, а не измеренный speedup PolicyOS. Если C действительно зависит и от B, отметка 9 необходима; отрицательный контроль её сохраняет.

**Рекомендуемое решение.** Не заменять весь исполнитель немедленно. Сначала установить, какие связи являются реальными data/control dependencies, а где барьер — только техническая форма расписания. Для доказанно независимых подграфов допустим ограниченный readiness-driven путь внутри существующего runner. Узел получает неизменяемую версию входов от своих завершённых предков и ресурс; completion разблокирует только его successors. Стандартный `TopologicalSorter.get_ready()/done()` иллюстрирует базовую механику без нового тяжёлого scheduler, но сам не решает state/authority/commit-семантику.

**Граница применимости.** В текущем дизайне tier служит также единицей snapshot и merge. Если научный смысл требует общего состояния на конец волны либо read/write-декларации неполны, снять барьер небезопасно. До расширения нужны B59, B73, точные зависимости и правило конфликтов. Более дешёвый первый шаг — независимые компонентные подграфы с явным последующим join; общие mutable reads, скрытые зависимости и внешние эффекты исключают слепую перестановку.

**Приёмка.** На размеченном независимом примере C стартует после A, а не после B; число методов, их входы, seeds, артефакты и научные повторения не меняются. Добавление настоящей зависимости на B возвращает ожидание. Измерять время до первого полезного результата, критический путь и простой ресурсов, не только total wall time. Это возможность развития, не доказанный дефект корректности каждого послойного исполнения.

<!-- END_SOURCE_CARD B77 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**C04.K03. Scientist AsyncWorkflowExecutor.** `policy-engine/src/polisyos/scientist/orchestration/engine/async_executor.py`. 500–740; 735–1030. Git blob: `5f0ac743d28ad0112b9f988f7ba47e10c4297249`. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/async_executor.py).

**C05.N01.** `policy-engine/src/polisyos/scientist/orchestration/engine/state_merge.py`. Весь возвращённый файл; 1–340. Локальная копия совпала с полным Git blob и исполнена с DTO-фикстурами. Git blob: `65b51cb121ff31ef58d497eead16a467c4e1726f`. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/state_merge.py).

**C06.R01. Scientist: checkpoint, delta, фиксация и materialize.** `policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py`. Окна чтения: 1–250, 360–700, 975–1250, 1420–1750. Git blob SHA: `dd90c9121de3e14b7ea2ff8db4781fa3ef750334`. Типы, scope, hook, delta, создание и материализация checkpoint; не полный аудит файла. [Закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py).

**C06.R02. Scientist: resume и остаточный workflow.** `policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py`. Окна чтения: 975–1120, 1760–2070. Git blob SHA: `dd90c9121de3e14b7ea2ff8db4781fa3ef750334`. Pruning, fingerprint и resume; последнее окно до конца полученного файла. Повтор того же blob, а не второй независимый источник. [Закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py).

**C06.R03. Scientist: асинхронное исполнение, уровни, checkpoint и rollback.** `policy-engine/src/polisyos/scientist/orchestration/engine/async_executor.py`. Окна чтения: 100–250, 240–535, 535–735, 1090–1220. Git blob SHA: `5f0ac743d28ad0112b9f988f7ba47e10c4297249`. Фактическая передача workflow_fingerprint; одиночный skip; параллельное слияние и сохранение; барьер уровня. [Закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/async_executor.py).

**C07.R07. AsyncWorkflowExecutor: потребитель pre_check.** `policy-engine/src/polisyos/scientist/orchestration/engine/async_executor.py`. Окна чтения: 735–1040. Git blob SHA: `5f0ac743d28ad0112b9f988f7ba47e10c4297249`. Для проверки достижимости budget-гипотезы, не полное исполнение. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/async_executor.py).

**C06.E02. Python: TaskGroup.** Ожидание всех задач группы; контекст для барьера уровня, не benchmark приложения. [Закреплённый источник](https://docs.python.org/3.14/library/asyncio-task.html#task-groups).

**C06.E03. Python: готовность узлов DAG.** TopologicalSorter.get_ready/done как пример локальной обработки готовности; не решение версионного state и не требование нового framework. [Закреплённый источник](https://docs.python.org/3.14/library/graphlib.html).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
