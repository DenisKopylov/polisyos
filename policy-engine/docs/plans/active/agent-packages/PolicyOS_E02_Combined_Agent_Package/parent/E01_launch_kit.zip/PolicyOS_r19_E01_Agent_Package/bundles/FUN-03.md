<a id="bundle-fun-03"></a>

# FUN-03 — Текущее знание, calibration routing и pre-commit ограничение

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B161, B163, B164**. Локальный класс: **L**. Укрупнённая приёмка: **K3**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** FUN-02. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Разделить исторический максимум ограничений и текущее same-scope знание. Metrics/routing читают одно состояние tracker; empty не считается измеренным drift. Допуск effectful promotion callback проверяется до вызова, а право записи — ещё раз владельцем при commit.

**Минимальные различающие проверки.** Unknown=1 затем связанная оценка 0.1 обновляет current, сохраняя историю и независимый risk=0.8. Пустой tracker не сообщает одновременно normal/no_promotion. Запрет не вызывает callback; готовый payload читается без нового действия; потеря разрешения перед commit обнаруживается.

**Не менять / не считать исправлением.** Не заменять merge_max на min/last везде. Не вызывать runner ради последующего обнуления результата. Сходство contexts не является разрешением публикации.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_fun_03.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T15. **Cross-boundary review:** X10. **Activation rules:** A09.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/scientist/methods/search/funnel/orchestrator.py` |
| Production write candidate | `policy-engine/src/polisyos/scientist/methods/search/uncertainty.py` |
| Production write candidate | `policy-engine/src/polisyos/scientist/methods/search/stages.py` |
| Production write candidate | `policy-engine/src/polisyos/scientist/methods/search/funnel/level6_promotion.py` |
| Production write candidate | `policy-engine/src/polisyos/scientist/nodes/builtins/decide/run_policy_blueprint_runtime.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/methods/search/funnel/types.py` |

**Названные в r19 тематически близкие tests (не подтверждение их покрытия/запуска):**

- `policy-engine/tests/unit/foundry/calibration/test_calibration_uncertainty_adapter.py`

**Не писать одновременно с:** FUN-01, FUN-02. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

**Связанные карточки для адресного чтения, не второе назначение:** B78 → DUR-02; B114 → OPT-03; B117 → OPT-04; B137 → TRN-03.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B161 lines=4165-4176 sha256=f08fecf0caf482a9f2d93c1f808ea16daa2232de161e5eeb98a7995fa2d41e0a -->
## B161. Ранняя неоценённость навсегда доминирует над поздним уточнением

Основание и область: `get_outcome` применяет `UncertaintyEnvelope.merge_max` ко всем результатам ticket. Статическая стадия корректно возвращает unknown с уровнем 1 по каждому типу. Максимум по истории поэтому сохраняет эту запись даже после подходящего более точного оценивания. [C15.R01, R05]

**Наблюдение:** ранний deterministic-envelope с 1 и поздняя статистическая оценка 0,1 дали `final_result.statistical=0.1`, но `outcome.statistical=1.0` с источником «deterministic gate; not assessed». Для двух независимых ограничений 0,2 и 0,8 максимум 0,8 остаётся правильным. Контроль явного same-scope update сохранил историю 1, текущую оценку 0,1 и неизвестность другого измерения.

**Рекомендуемое исправление:** отделить исторический консервативный обзор от текущего разрешённого состояния знания. Поздняя оценка может заместить прежнее «не оценено» только по тому же предмету, величине, входам и допустимой процедуре. Источники независимой неопределённости и нерешённые разногласия продолжают действовать. По возможности переиспользовать имеющиеся контракты версий и существенных зависимостей, а не создавать новый универсальный агрегатор истинности.

**Не исправлять** глобальной заменой max на min или «последний результат», приравниванием большего номера стадии к доказательной силе либо удалением старых ограничений. Когда итог намеренно означает максимум исторического риска, он может оставаться таким — но не заменять текущую оценку и не называться ею.

**Приёмка:** разрешённое уточнение действительно меняет текущий результат; независимый высокий риск не затирается; другая популяция не замещает прежнюю неизвестность. Здесь доказано расхождение агрегата и последней стадии; конкретный downstream-отказ из-за него не воспроизведён. Приоритет по фактическому потребителю, сложность средняя. Связь S03/S08 и B137 — различие изменения знания и простого обращения к истории.

<!-- END_SOURCE_CARD B161 -->

<!-- SOURCE_CARD B163 lines=4189-4200 sha256=0c5055c18e4bbfb9bc2ed8cbc6904766eb95627e736de08f4084a90fb2be8ba5 -->
## B163. Один tracker без наблюдений одновременно сообщает normal и no_promotion

Основание и область: `CorrelationTracker.compute_metrics()` для пустого корпуса возвращает normal и `promotion_ban_active=False`. Но `routing_mode()` вызывает drift-логику, которая использует нулевую «корреляцию» пустого набора и выдаёт PROMOTION_BAN. Orchestrator потребляет оба интерфейса. Нативный policy-node создаёт новый tracker, хотя ранее загружает calibration-report и state-metrics. [C15.R04, R07]

**Наблюдение:** пустой tracker дал normal/False в metrics и no_promotion в routing; Stage5 получил metrics=normal, а итог оказался no_promotion/defer_to_human. На трёх согласованных парах оба пути дали normal; на трёх противоположных — no_promotion. В опытах запись калибровки в orchestrator отключена фикстурой и не выдается за проверку естественного накопления.

**Рекомендуемое исправление:** одна текущая оценка пригодности калибровки с размером и областью наблюдений, результатом измерения либо явным `not established`, единым routing-решением. Научная публикация может быть ограничена без калибровки, но это не измеренное падение корреляции. Разрешённый последовательный исследовательский маршрут и получение калибровочных данных остаются доступными.

Для реально используемого node проверить, должен ли он восстанавливать совместимый tracker-snapshot через уже существующий `from_snapshot` или принимать другой авторитетный источник routing-состояния. Нельзя автоматически доверять неименованным прежним метрикам либо обнулять корпус при каждом создании объекта.

**Приёмка:** оба публичных интерфейса согласованы; пустой и статистически плохой корпуса различимы; ограничения публикации не снимаются ради зелёного статуса; совместимая калибровка переиспользуется. Подключение node статически прочитано, полный runtime не запущен. Приоритет высокий на новом/восстановленном tracker; сложность небольшая/средняя. Связь B114/B137 — нужное прошлое не теряется и не становится новым доказательством без оснований.

<!-- END_SOURCE_CARD B163 -->

<!-- SOURCE_CARD B164 lines=4201-4212 sha256=ed8189c34e88eec186ca2c6c3d764e796f0cc4f967c601f6a5ec223c43b6c137 -->
## B164. Запрет продвижения проверяется после вызова потенциально записывающего runner

Основание и область: `Level6PromotionStage.evaluate` сначала получает `promotion_payload` вызовом `_promotion_runner`, затем проверяет `no_promotion`, `reduced_judge`, `auto_cap`. Результат запрещённого исполнения обнуляется после вызова, но возможный эффект уже произошёл. [C15.R06]

**Наблюдение:** полный blob-проверенный модуль с runner, записывающим только в тестовый список, при no_promotion добавил один эффект и вернул defer_to_human. Runner, поднявший RuntimeError при auto_cap, прервал путь до контролируемого defer. При normal callback выполнялся один раз и завершался complete. Если готовый promotion_payload передан явно, callback не вызывается; это сохранённый положительный контроль.

**Рекомендуемое исправление:** до вызова потенциально эффектного владельца проверить актуальную политику режима и допустимость именно запрошенной операции. При необходимости отделить чистую подготовку плана от commit. Настоящий владелец записи независимо перепроверяет поколение ticket, действующие полномочия и ограничения непосредственно при commit; ранний preflight не заменяет эту защиту от изменения условий между проверкой и действием.

**Не исправлять** только заменой финальной надписи либо удалением уже произошедшего эффекта без истории. Ранее рассчитанный результат можно читать и анализировать при корректном доступе, не запуская новую публикацию. Если callback действительно чистый и это контрактно установлено, данный эффектный риск уже; лишний расчёт и неудачное исключение всё равно требуют точного порядка.

**Приёмка:** ограниченный режим не вызывает запрещённый producer; нормальный режим сохраняет работу; готовый результат доступен по своей политике; потеря разрешения перед commit обнаруживается владельцем. Реальная авторизация, запись в реестр и публикация не исполнялись, поэтому обход системных полномочий не заявлен. Приоритет высокий для callback-пути, локальный preflight плюс согласование владельца. Связь B78/B117 — иной участок границы решения и эффекта.

<!-- END_SOURCE_CARD B164 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**C15.R01. Ticket, переходы, результат и compatibility-адаптеры.** `policy-engine/src/polisyos/scientist/methods/search/funnel/orchestrator.py`. Окна чтения: 1–1100. В опытах — выбранные тела; полный локальный blob не заявлен. Git blob `6b0a47df3034acce47842438215d7ffcb5412a83`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/funnel/orchestrator.py).

**C15.R04. ExpensiveStage и CorrelationTracker.** `policy-engine/src/polisyos/scientist/methods/search/stages.py`. Окна чтения: 1–900. В опытах — выбранные тела; полный локальный blob не заявлен. Git blob `85cacfbcc11141bf956390b09d637ff1ccbfea6e`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/stages.py).

**C15.R05. UncertaintyEnvelope: unknown, update, merge_max.** `policy-engine/src/polisyos/scientist/methods/search/uncertainty.py`. Прочитан полный файл. Полный локальный файл сверен по Git blob, импорты в опытах заменены фикстурами. Git blob `856c6919a3be13f676172d7d0767d0d2d3554f43`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/uncertainty.py).

**C15.R06. L6: callback до cap и локальный результат.** `policy-engine/src/polisyos/scientist/methods/search/funnel/level6_promotion.py`. Прочитан полный файл. Полный локальный файл сверен по Git blob, импорты в опытах заменены фикстурами. Git blob `26318b94c6bee23948790b7bb992b38fdd0ab5bd`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/funnel/level6_promotion.py).

**C15.R07. Нативный вызывающий node и explicit fidelity backend.** `policy-engine/src/polisyos/scientist/nodes/builtins/decide/run_policy_blueprint_runtime.py`. Окна чтения: 1–220, 235–310, 550–780. Исполнение этого файла в настоящем окружении не заявлено. Git blob `255aa44f06ac3514e083c68f899ad601233eaffe`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/nodes/builtins/decide/run_policy_blueprint_runtime.py).

**C15.R08. FunnelStageResult и CheapSignalVector.** `policy-engine/src/polisyos/scientist/methods/search/funnel/types.py`. Прочитан полный файл. Полный локальный файл сверен по Git blob, импорты в опытах заменены фикстурами. Git blob `d3974bf7fac98f7c6ad5cbb06a0425e3f02a37d0`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/funnel/types.py).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
