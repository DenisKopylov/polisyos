<a id="bundle-grf-02"></a>

# GRF-02 — Неизменяемый граф, mixed-edge export и версии кэша

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B219, B220**. Локальный класс: **L**. Укрупнённая приёмка: **K5**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** GRF-01. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Сохранить directed/bidirected/lag отношения в поддержанном представлении. Публиковать глубоко immutable topology; новая версия не наследует старые derived-properties. Кэши строятся один раз для реальной версии и сохраняют правильный cleanup.

**Минимальные различающие проверки.** X→Y и X↔Y не перезаписывают друг друга при перестановке edges. После прогрева export/adjacency новое пустое ребро-представление совпадает с dump и cold-query. Nested mutation отвергается или остаётся только в builder до публикации. Weakref-cleanup сохраняется.

**Не менять / не считать исправлением.** Не хэшировать весь граф при каждом BFS и не отключать все кэши. MultiDiGraph сам по себе не делает directed-path algorithm причинно корректным.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_grf_02.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T21. **Cross-boundary review:** X11. **Activation rules:** A07.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/ir/analytics/causal_graph.py` |
| Production write candidate | `policy-engine/src/polisyos/foundry/methods/catalog/causal/admg_ops.py` |
| Read / consumer contract | `policy-engine/src/polisyos/foundry/methods/catalog/causal/_graph_projection.py` |

**Не писать одновременно с:** GRF-01, GRF-03. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B219 lines=5375-5388 sha256=c3c2613bd397c8dd5d252ccb15562a6aa2f4bee46e36fa86eff1b12bf7c30009 -->
## B219. Простое DiGraph-представление перезаписывает параллельные причинные отношения

**Происхождение и приоритет:** C21-04. Условно высокий на границе, обещающей полный каузальный граф. Основание: `CausalGraphModel.to_networkx`. [C21.R01]

**Проблема.** Адаптер создаёт `networkx.DiGraph`, где одна упорядоченная пара вершин имеет одну запись атрибутов. Но исходный IR может хранить одновременно направленное воздействие X→Y и bidirected-связь X↔Y, а также несколько лагов. Последний `add_edge` заменяет атрибуты предыдущего отношения.

**EDGE01–EDGE02.** Два исходных отношения X→Y и X↔Y дают одно ребро. Перестановка записей меняет surviving `mark_src` между tail и arrow. Два лаговых ребра также сокращаются до одного. Контрольный `MultiDiGraph` с полной идентичностью рёбер сохраняет оба. Поддержка parallel edges является явным свойством этого контейнера. [C21.E04]

**Исправление.** Выбрать представление по назначению: отдельные directed/bidirected adjacency либо типизированный mixed-edge graph; для транспорта допустим MultiDiGraph с ключом, включающим тип концов и lag. Полные сведения о свидетельствах остаются прикреплёнными к правильному ребру. Простой DiGraph может сохраняться как явно ограниченная проекция для задач, которым она действительно достаточна.

Важно: MultiDiGraph ремонтирует хранение, но сам по себе не делает обычный directed-path алгоритм каузальным. Потребитель должен интерпретировать метки и временную структуру. Нельзя заменять bidirected-связь двумя произвольными причинными стрелками.

**Положительная граница.** Нативный `CachedAdjacency` уже хранит directed- и bidirected-множества раздельно. Не заявляется, что весь ID-engine проходит через NetworkX или теряет эту пару. Rustworkx/Kuzu не исполнялись. Приёмка — round-trip и неизменность результата при перестановке edges, отдельно для каждого реально используемого backend и класса графа.

<!-- END_SOURCE_CARD B219 -->

<!-- SOURCE_CARD B220 lines=5389-5402 sha256=d0c39288b089bc7e1a85c4eec40ffd1c4fa3273293734b758729b4bb7dc54b71 -->
## B220. Frozen-модель не обеспечивает неизменность topology; кэш и копия расходятся с текущим графом

**Происхождение и приоритет:** C21-05. Высокий для переиспользования изменяемых графов; средняя связующая правка. Основания: nested lists/frozen DTO, ID-based adjacency cache и cached export properties. [C21.R01–R02]

**Проблема.** Pydantic `frozen=True` защищает присваивание полю, но `nodes`, `edges` и вложенные metadata остаются изменяемыми. Кэш adjacency адресуется `id(graph)`, а подготовленные Kuzu-строки — `cached_property`. Кроме того, обычный `model_copy(update=...)` переносит уже вычисленные cached properties в новый объект. В результате даже новый object-id не всегда устраняет устаревшую экспортную проекцию. Поверхностная immutable-семантика Pydantic документирована. [C21.E05]

**CACHE01–CACHE04.** Для A→B после первого чтения `edges.clear()` разрешён, хотя прямое присваивание `edges=[]` запрещено. Сериализация видит ноль рёбер, тёплый `ancestors(B)` — A и B, холодная реконструкция — только B, экспорт продолжает содержать одно ребро. Отдельно `model_copy(update={'edges':[]})` даёт корректную новую adjacency, но наследует старую экспортную строку. Свежая валидированная версия согласует оба представления. Положительный контроль: weakref-cleanup после удаления объекта действительно очищает adjacency-cache.

**Исправление.** Сделать семантически существенную topology глубоко неизменяемой и обновлять её через новый снимок. Конструктор новой версии обязан сбрасывать зависимые derived-properties; кэш связывается с реальной версией topology и правильной областью параметров. Подготовленные возвращаемые строки тоже не должны быть общим доступным для изменения источником истины.

Не нужно пересчитывать hash большого графа при каждом BFS либо отключать все кэши. Предварительная проверка неизменяемой версии и одноразовая adjacency сохраняют выигрыш. Если mutable-builder нужен, он остаётся отдельной подготовительной формой и публикует immutable-view только после завершения.

**Приёмка.** Проверить mutation-отказ, copy/update после прогрева cached property, согласованность dump/ancestors/export и правильное освобождение старого cache-entry. Здесь установлен механизм локального расхождения, а не порча настоящей Kuzu-базы. Прежнюю работающую weakref-инвалидацию нельзя ошибочно объявлять утечкой и заменять небезопасным LRU.

<!-- END_SOURCE_CARD B220 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**C20.R08. Проекция частично ориентированного графа.** `policy-engine/src/polisyos/foundry/methods/catalog/causal/_graph_projection.py`. Полное чтение. Полный локальный blob сверен; проектные imports явно заменены согласно harness. Git blob `eb97330cb39884e675a8835b12e8cfb0f3a6dd4a`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/catalog/causal/_graph_projection.py).

**C20.R09. Marks, graph types и валидация DAG.** `policy-engine/src/polisyos/ir/analytics/causal_graph.py`. Окна чтения: 1–280; файл мог быть короче окна. Прочитано как кодовое основание/контроль области, не исполнялось в production-окружении. Git blob `ddad43aba1e6eff00f3440f4ce4bb23162a48b18`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/ir/analytics/causal_graph.py).

**C21.R01. Контракт графа, lag-validation и адаптеры/кэшированные строки.** `policy-engine/src/polisyos/ir/analytics/causal_graph.py`. Окна чтения: 1–430; файл мог быть короче окна. Локально — выбранные определения и явно помеченные фикстуры, не полный Git blob. Git blob прочитанного источника `ddad43aba1e6eff00f3440f4ce4bb23162a48b18`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/ir/analytics/causal_graph.py).

**C21.R02. Общие ADMG adjacency, surgery и m-separation.** `policy-engine/src/polisyos/foundry/methods/catalog/causal/admg_ops.py`. Окна чтения: 1–650; файл мог быть короче окна. Локально — выбранные определения и явно помеченные фикстуры, не полный Git blob. Git blob прочитанного источника `01023e8e13bcc26a9125884dec3e9edb91f6f4ca`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/catalog/causal/admg_ops.py).

**C21.E04. NetworkX: MultiDiGraph и идентичность параллельных рёбер.** Первичный источник просмотрен 18 сентября 2026 года. Версия страницы не подменяет зафиксированные версии локальной среды; источник не доказывает запуск PolicyOS. [Источник](https://networkx.org/documentation/stable/reference/classes/multidigraph.html).

**C21.E05. Pydantic: model-copy и поверхностная frozen-семантика.** Первичный источник просмотрен 18 сентября 2026 года. Версия страницы не подменяет зафиксированные версии локальной среды; источник не доказывает запуск PolicyOS. [Источник](https://pydantic.dev/docs/validation/2.12/concepts/models/).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
