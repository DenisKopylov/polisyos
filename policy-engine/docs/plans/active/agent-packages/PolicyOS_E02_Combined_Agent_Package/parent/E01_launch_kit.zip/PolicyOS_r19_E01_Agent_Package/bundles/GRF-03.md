<a id="bundle-grf-03"></a>

# GRF-03 — Известные направления и явная временная/частичная семантика

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B214, B218**. Локальный класс: **L**. Укрупнённая приёмка: **K5**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** GRF-02. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Канонически нормализовать уже известное обратное направление без потери marks. Для частично ориентированных и lag-графов выбрать supported consumer/явное корректное преобразование; если его нет, вернуть ограничение конкретного маршрута, не произвольный DAG. Сохранить компактный temporal input и контроль нулевого лага.

**Минимальные различающие проверки.** PAG X←Y не превращается в X→Y. CPDAG triangle не получает labelDAG поверх цикла. Lag=1/lag=2 различимы после round-trip; autoregression разрешается в подходящем temporal contract. Малое конечное развёртывание четырёх времён сохраняет ацикличность. Static DAG остаётся рабочим.

**Не менять / не считать исправлением.** Не удалять неудобные рёбра/лаги, не отключать DAG validation. Полная поддержка всех PAG/temporal families не является предварительным условием статического K5; незавершённые capability части отмечать отдельно.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_grf_03.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T20, T21. **Cross-boundary review:** X11. **Activation rules:** общие правила scope/приёмки.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/foundry/methods/catalog/causal/_graph_projection.py` |
| Production write candidate | `policy-engine/src/polisyos/ir/analytics/causal_graph.py` |
| Production write candidate | `policy-engine/src/polisyos/foundry/methods/catalog/causal/admg_ops.py` |
| Production write candidate | `policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_fit.py` |
| Production write candidate | `policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_query.py` |
| Read / consumer contract | `policy-engine/src/polisyos/foundry/methods/catalog/causal/id_engine/core.py` |
| Read / consumer contract | `policy-engine/src/polisyos/ir/analytics/causal_queries.py` |

**Не писать одновременно с:** GRF-01, GRF-02, SCM-01, SCM-02, SCM-03. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B214 lines=5218-5229 sha256=48c1311f230c5c8f4886013cf47fec75931cde810c20feee8889c9d820dcb1ad -->
## B214. Проекция PAG/CPDAG разворачивает известное направление и может создать цикл

**Приоритет:** высокий при передаче графа DAG-потребителю; нормализация известного направления дешева, выбор допустимого расширения — отдельная задача. **Основание:** полный _graph_projection.py, CausalGraphModel и GCM-fit caller; GP01–GP04. [C20.R08–R10]

**Проблема.** Единственный признанный полностью ориентированным случай — tail на src и arrow на dst. Случай arrow на src и tail на dst означает известное обратное направление, но обрабатывается как неопределённость: метки меняются на tail/arrow без перестановки концов. Для неопределённых рёбер применяется тот же порядок хранения, после чего graph_type заменяется на DAG через model_copy без повторной валидации.

**Воспроизведение.** В PAG ребро X←Y стало X→Y и получило orientation_uncertain=True. Полный неориентированный CPDAG-треугольник, записанный A—B, B—C, C—A, стал циклом A→B→C→A с меткой DAG. Численная фикстура графа — не полный native DTO; допустимость такого reversed edge и запрет циклов в настоящем DAG проверены чтением контракта.

**Рекомендуемое исправление.** Сначала канонически нормализовать уже известные направления, сохраняя origin и marks. Затем либо использовать допускающий частичную ориентацию идентификатор, либо строить согласованное расширение с проверкой направлений, ацикличности и свойств класса эквивалентности. Для PAG произвольный выбор одного DAG вообще не заменяет causal-identification по допустимому семейству; исследовательскую модель нужно сохранять условной.

**Положительные контроли.** Готовый корректный DAG возвращается без изменения; bidirected edge заменяется общим latent U и двумя исходящими рёбрами. Это полезные существующие части. Уточнение не должно превращать все частично определённые графы в полный отказ: можно сохранять несколько допустимых моделей или ограниченный результат. Простое удаление ребра цикла либо отключение DAG-validation неприемлемо. Исправленная нормализация одного известного reversed edge проверена отдельно; общий sound-extension алгоритм здесь не реализован.

<!-- END_SOURCE_CARD B214 -->

<!-- SOURCE_CARD B218 lines=5361-5374 sha256=8ce1868ddb2663580547f475288d03502e03ae6a4bc38923313bc069efb0a40a -->
## B218. Временной граф теряет лаги при экспорте, а лаговая самозависимость отвергается как обычный self-loop

**Происхождение и приоритет:** C21-03. Высокий при передаче temporal discovery в статические методы; иначе условный. Основания: `CausalGraphModel` validation/export, adjacency и GCM parent-view. [C21.R01–R02, C21.R05]

**Проблема.** Контракт хранит `lag` и допускает взаимные лаговые рёбра, проверяя ацикличность лишь для одновременных. Но `to_dot` не передаёт lag и использует одно имя переменной на все времена. Общие ADMG-операции включают лаговые отношения как статические, тогда как GCM parent-map их пропускает. Одновременно любая связь `src==dst` отвергается до проверки лага. Поэтому разные потребители получают разные временные модели из одного объекта.

**TIME01–TIME04.** X→Y с lag=1 и lag=2 дают один и тот же DOT. Допустимый в DTO граф X→Y lag=1, Y→X lag=1 после статического представления имеет цикл. Простая авторегрессия X(t−1)→X(t), записанная одним именем и lag=1, отвергается. Контрольное конечное развёртывание обратной связи на четыре момента, восемь узлов, ациклично.

**Исправление.** Разрешать временную семантику на границе потребителя: координата `(variable,time)`, соглашение о лаге, начальные условия и горизонт. Использовать подходящий temporal-consumer либо конечное развёртывание только нужной области запроса. Для чисто статического потребителя возвращать точную несовместимость, если временное преобразование ещё не выполнено.

Параметризация одной переменной во времени и явные временные узлы могут сосуществовать через однозначный адаптер. Не следует просто разрешить все self-loops, отбросить лаг или удалить неудобное ребро для получения DAG. Нулевая задержка в обычном DAG по-прежнему требует запрета цикла. Проверка expanded-формы должна относиться к фактически читаемым данным и временам, иначе правильный рисунок не обеспечит правильного расчёта.

**Приёмка/граница.** Round-trip должен различать lag1/lag2 и сохранять причинное время. Для известного статического DAG путь не меняется. Контрпример касается принятого compact temporal-формата; отдельный маршрут, сразу создающий явные временные узлы, может не испытывать этого дефекта. Не установлено, что вся временная часть системы использует данный экспорт.

<!-- END_SOURCE_CARD B218 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**C20.R08. Проекция частично ориентированного графа.** `policy-engine/src/polisyos/foundry/methods/catalog/causal/_graph_projection.py`. Полное чтение. Полный локальный blob сверен; проектные imports явно заменены согласно harness. Git blob `eb97330cb39884e675a8835b12e8cfb0f3a6dd4a`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/catalog/causal/_graph_projection.py).

**C20.R09. Marks, graph types и валидация DAG.** `policy-engine/src/polisyos/ir/analytics/causal_graph.py`. Окна чтения: 1–280; файл мог быть короче окна. Прочитано как кодовое основание/контроль области, не исполнялось в production-окружении. Git blob `ddad43aba1e6eff00f3440f4ce4bb23162a48b18`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/ir/analytics/causal_graph.py).

**C20.R10. GCM-fit использует projection перед fitting.** `policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_fit.py`. Окна чтения: 1–285; 310–410; файл мог быть короче окна. Прочитано как кодовое основание/контроль области, не исполнялось в production-окружении. Git blob `43b183049b678aa7d82afbfc1d07261f9373faa7`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_fit.py).

**C20.R11. GCM query: traversal, abduction и simulation.** `policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_query.py`. Окна чтения: 1–735; файл мог быть короче окна. Локально сохранены выбранные определения с помеченными импортами; это не полный Git blob. Git blob `b21fbb1b911415125f401390dacc335e925f7b93`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_query.py).

**C20.R12. Factual context и типизированный causal-query.** `policy-engine/src/polisyos/ir/analytics/causal_queries.py`. Окна чтения: 1–220; файл мог быть короче окна. Прочитано как кодовое основание/контроль области, не исполнялось в production-окружении. Git blob `f1b13ceae6e280ac2088c548e2981ec8c69c161b`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/ir/analytics/causal_queries.py).

**C21.R01. Контракт графа, lag-validation и адаптеры/кэшированные строки.** `policy-engine/src/polisyos/ir/analytics/causal_graph.py`. Окна чтения: 1–430; файл мог быть короче окна. Локально — выбранные определения и явно помеченные фикстуры, не полный Git blob. Git blob прочитанного источника `ddad43aba1e6eff00f3440f4ce4bb23162a48b18`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/ir/analytics/causal_graph.py).

**C21.R02. Общие ADMG adjacency, surgery и m-separation.** `policy-engine/src/polisyos/foundry/methods/catalog/causal/admg_ops.py`. Окна чтения: 1–650; файл мог быть короче окна. Локально — выбранные определения и явно помеченные фикстуры, не полный Git blob. Git blob прочитанного источника `01023e8e13bcc26a9125884dec3e9edb91f6f4ca`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/catalog/causal/admg_ops.py).

**C21.R04. SCM-fit: пропуск корней и полиномиальные family-params.** `policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_fit.py`. Окна чтения: 65–148; 340–610; файл мог быть короче окна. Локально — выбранные определения и явно помеченные фикстуры, не полный Git blob. Git blob прочитанного источника `43b183049b678aa7d82afbfc1d07261f9373faa7`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_fit.py).

**C21.R05. SCM-query: family dispatch, sampling, intervention и attribution.** `policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_query.py`. Окна чтения: 105–335; 472–580; 700–900; файл мог быть короче окна. Локально — выбранные определения и явно помеченные фикстуры, не полный Git blob. Git blob прочитанного источника `b21fbb1b911415125f401390dacc335e925f7b93`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_query.py).

**C21.R08. Действительный пакет ID-engine: core и PAG-вход.** `policy-engine/src/polisyos/foundry/methods/catalog/causal/id_engine/core.py`. Окна чтения: 1–330; listing id_engine/; файл мог быть короче окна. Прочитано для анализа вызовов/контракта; этот полный компонент не исполнялся. Git blob прочитанного источника `f66eecbf76fe1ef423a654daaa08c881ece9e7b6`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/catalog/causal/id_engine/core.py).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
