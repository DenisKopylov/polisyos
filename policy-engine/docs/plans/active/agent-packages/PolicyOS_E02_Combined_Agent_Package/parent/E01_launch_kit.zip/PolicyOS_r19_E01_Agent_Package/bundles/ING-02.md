<a id="bundle-ing-02"></a>

# ING-02 — Непрерывное окно, позиция и полная lineage

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B81, B82, B85**. Локальный класс: **L**. Укрупнённая приёмка: **K2**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** ING-01, NET-01. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Согласовать committed offset, pending operator-state, dedupe и порядок. Сохранить незавершённое окно или достаточный replay-prefix. Передать все contributor refs; блок, закрывающий старое окно, не становится его единственным data input.

**Минимальные различающие проверки.** Поток [1,2]+[3] даёт одно окно после остановки до chunk commit и после commit с pending buffer. Ошибка после poll/dedupe не теряет строки. Окно A+B хранит обе ссылки; trigger следующего bucket отделён от contributor. COUNT/SESSION/sliding проверяются на десятках строк.

**Не менять / не считать исправлением.** Не обещать глобальный exactly-once; не закрывать окно при рестарте ради RAM и не выдавать pending dedupe за завершённую обработку.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_ing_02.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T7. **Cross-boundary review:** X05. **Activation rules:** общие правила scope/приёмки.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/fabric/data_plane/streaming.py` |
| Production write candidate | `policy-engine/src/polisyos/fabric/data_plane/cursor_store.py` |
| Read / consumer contract | `policy-engine/src/polisyos/fabric/quality/processing_guarantees.py` |
| Read / consumer contract | `policy-engine/src/polisyos/core/artifacts/store.py` |

**Не писать одновременно с:** ING-01, NET-01, ING-03. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B81 lines=2181-2194 sha256=13dc074365e636ede836f221f8ecc0f831016f30f7b65349bcb6750d7d475292 -->
## B81. Ошибка обработки закрепляет позицию уже прочитанного, но ещё не зафиксированного блока

**Происхождение:** C07-03. **Основание:** error-handler `process_stream_dataset`, `StreamingSourceSession.checkpoint/rewind`, выбор latest в CursorStore; SC1–SC3. [C07.R02: окна 1–570 и 870–1450; C07.R03]

**Проблема.** `poll()` устанавливает `_last_chunk` до очистки, сохранения chunk/window и фиксации результатов. При исключении handler вызывает `session.checkpoint(...)` по этому последнему наблюдению и сохраняет PAUSED-checkpoint. `find_latest_stream_checkpoint` не ограничивает чтение только committed lifecycle. Fallback-rewind после переподключения пропускает все `chunk_index <= checkpoint.offset`. Поэтому ошибка после чтения блока 1, но до его сохранения, способна сделать следующей точкой чтения блок 2.

В SC1 исполнено исходное тело fallback-rewind на фикстурном источнике `[0,1,2]`: checkpoint offset=1 оставляет `[2]`. Модель handler привязывает этот offset к ошибке обработки 1; это не полный native streaming-run. Контроль с последней подтверждённой границей 0 оставляет `[1,2]`. Dedupe-key добавляется в live-набор ещё до persistence; если сохранить его как подтверждённый при ошибке, простой откат offset тоже не спасёт повтор — строка будет отброшена как уже виденная. SC3 различает pending и committed dedupe.

**Рекомендуемое исправление.** Отделить позицию прочитанного от позиции зафиксированного. Аварийная диагностика может содержать observed offset и ошибку, но не должна автоматически стать точкой продолжения. Продвигать committed cursor и подтверждённую дедупликацию только вместе с достаточным сохранением выходов и состояния оператора. После неопределённого исхода использовать безопасное повторное чтение плюс идемпотентную публикацию, а не молчаливый skip.

Не требуется распределённая exactly-once транзакция ради первого примера. Сам контракт уже честно объявляет at-least-once with dedupe; нужно обеспечить, чтобы перезапуск не терял необработанное. Коннекторы с native `rewind_stream` могут иметь иную семантику — их offset/resume-token нужно проверить отдельно, не навязывая всем универсальное `+1`.

**Приёмка.** Ошибка после poll, после dedupe, после сохранения raw-chunk и до/после window publication не теряет строки; каждый повтор имеет фактическую принадлежность. Повреждение или отсутствие нужного checkpoint вызывает явный repair, а не положительное продвижение. Проверка отдельного error-checkpoint не заменяет испытания реального writer → reader.

<!-- END_SOURCE_CARD B81 -->

<!-- SOURCE_CARD B82 lines=2195-2208 sha256=fd1257bfd3f64dd10ab0b37a3b10f70cc54ed6bfe66097e8bf9bd00682db2f6a -->
## B82. Позиция источника восстанавливается без незавершённого окна и состояния порядка

**Происхождение:** C07-04. **Основание:** создание нового `StreamWindowAccumulator`/`_StreamOrderingState`, поля checkpoint и восстановление dedupe; WS1–WS4. [C07.R02: окна 290–1190]

**Проблема.** При restart создаются пустые accumulator и ordering state. Из checkpoint восстанавливаются dedupe_keys и schema_fields, но не `_count_buffer`, session/sliding buckets, `_ordinal`, `_next_slide_at` или максимальный event-time. При этом offset уже может быть подтверждён после блока с незакрытым окном. Ранее прочитанные строки остаются в сохранённом raw-chunk, но данный маршрут их не загружает обратно в окно.

На исходных методах accumulator: непрерывные `[1,2,3]` образуют одно count-окно размера 3. После остановки с `[1,2]` в буфере и новой пустой accumulator оставшаяся строка 3 даёт при flush только `[3]`. Контроль с сохранённым операторным состоянием восстанавливает `[1,2,3]`. Отдельно новый accumulator вновь выдаёт `count:0`: это коллизия логического имени окна, не доказательство коллизии CAS content hash.

**Рекомендуемое исправление.** Сохранять версионированный достаточный state оконного оператора вместе с committed-позицией: pending rows либо ссылки на неизменяемые сегменты, параметры окна, event-time/watermark, ordinal и согласованную дедупликацию. Альтернатива для малого начала — откат к подтверждённой границе, от которой весь незавершённый операторный state можно воспроизвести из сохранённых сегментов. Dedupe не должен подавлять строки, необходимые именно для такого восстановления окна.

Массивные строки не обязаны копироваться в каждом checkpoint: неизменяемые segments/CAS refs дешевле полного payload. Политика закрытия окна и policy-version должны входить в связь результата; «flush при любом рестарте» изменит смысл окна и не считается ремонтом.

**Приёмка.** Непрерывный и interrupted/resumed проходы дают одинаковые логические окна и lineage для COUNT, SESSION и выбранного sliding-режима. Незавершённое окно, политика late events и номера окон не забываются. Raw-данные действительно читаемы; утерянный state не маскируется как пустой поток. B81–B82 принимать совместно.

<!-- END_SOURCE_CARD B82 -->

<!-- SOURCE_CARD B85 lines=2237-2248 sha256=0775c04c77c9d3d0f9afce1d2a8dae5592bcbd20c7987cbea43fcc566bff66b8 -->
## B85. Окно нескольких блоков ссылается только на последний, а иногда — на вообще не входящий в него

**Происхождение:** C07-07. **Основание:** вызов и тело `_persist_stream_window_async`; LN1–LN3. [C07.R02: окна 870–1450]

**Проблема.** Accumulator хранит строки, но не их исходные chunk-ref. При emission writer получает единственный `input_ref=chunk_ref` текущего блока. Окно COUNT размера 3 может содержать две строки A и одну B, но manifest называет только B. При tumbling-window первая строка нового временного bucket закрывает предыдущий: текущий chunk вообще может не содержать ни одной строки публикуемого окна. Финальный flush также привязывается только к последнему chunk.

LN1 исполняет сохранение окна из `[1,2]` в A и `[3]` в B: payload содержит все три строки, а объявленные inputs — только `chunk-B`. LN2 показывает старое bucket-окно, закрытое строкой следующего bucket. **Численные строки при этом не обязательно потеряны; теряется полный путь происхождения.** CAS-хэш результата не восстанавливает отсутствующую зависимость от A.

**Рекомендуемое исправление.** Переносить вместе с pending rows/segments их действительные provenance refs. Окно получает объединение всех фактических источников и идентичность преобразования/политики; повторяющиеся refs можно компактно объединить. Для очень больших окон — ссылка на неизменяемый lineage-set или ranges, но не пропуск зависимостей. Строка, вызвавшая закрытие, хранится как control trigger при необходимости, а не как вымышленный data input.

**Приёмка.** Удаление/отзыв A выявляет зависимое окно; неизменённый B не делает весь результат актуальным. Одноблочный пример сохраняет простой правильный путь. Сравнить payload rows с реальными contributor refs, включая финальный flush и restart. Это расширяет адресную ревалидацию и безопасный reuse, не требует повторно исследовать всё хранилище.

<!-- END_SOURCE_CARD B85 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**C07.R02. Fabric: stream loop, session, accumulator и сохранение окон.** `policy-engine/src/polisyos/fabric/data_plane/streaming.py`. Окна чтения: 1–290; 290–570; 570–870; 870–1190; 1190–1450. Git blob SHA: `5b4656d8fbe7f4f6cce05f3ab394bb6a072499f8`. Последовательные прочитанные окна 1–1450; конец файла вне окна не заявлен. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/fabric/data_plane/streaming.py).

**C07.R03. CursorStore: выбор latest и lifecycle.** `policy-engine/src/polisyos/fabric/data_plane/cursor_store.py`. Окна чтения: 160–365. Git blob SHA: `267a7b1cdf1785a177c31235ec3eb4016aa25d67`. Чтение, не импорт модуля. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/fabric/data_plane/cursor_store.py).

**C07.R04. Контракты гарантий, dedupe, порядка, backpressure и CDC.** `policy-engine/src/polisyos/fabric/quality/processing_guarantees.py`. Окна чтения: 1–260. Git blob SHA: `3074055a1cdac38d7031f36158a2a0b33b54620b`. Полный возвращённый текст в окне; не выполнена модель Pydantic. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/fabric/quality/processing_guarantees.py).

**C14.R02. FileSystemCAS: dedup, ref, чтение, lock-map и вызывающие обёртки.** `policy-engine/src/polisyos/core/artifacts/store.py`. Окна чтения: 175–302, 300–700, 700–1030. Локально сохранены выбранные тела; полный blob не заявлен. Git blob `76cc3574f2bbbb102f47111872ac31f131c253fe`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/core/artifacts/store.py).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
