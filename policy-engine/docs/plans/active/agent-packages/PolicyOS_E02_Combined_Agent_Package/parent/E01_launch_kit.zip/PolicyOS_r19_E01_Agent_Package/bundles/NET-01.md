<a id="bundle-net-01"></a>

# NET-01 — Владение соединением от acquire до cleanup

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B87, B89, B90**. Локальный класс: **L**. Укрупнённая приёмка: **K2**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** нет; после общего SETUP-01 и короткой проверки current base. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Один lifecycle permit/handle: acquire, reservation, transfer, retirement, release ровно один раз. Подготовка session и rewind входят в гарантированный cleanup. Сетевые connect/health/close выполняются вне общего lock с отдельным владением и проверкой поколения при публикации.

**Минимальные различающие проверки.** Отмена после permit во время lock/connect/close не уменьшает ёмкость. Закрытый pool не делает double-release. Ошибка subscribe и повторный close завершают cleanup. Медленный connect не блокирует release другого handle. Достаточно пула из 1–2 соединений и управляемых событий.

**Не менять / не считать исправлением.** Bare BaseException+release недостаточен без учёта физического handle. Не повышать max_size и не возвращать повреждённое соединение как здоровое.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_net_01.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T7, T8. **Cross-boundary review:** X05. **Activation rules:** общие правила scope/приёмки.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/fabric/connectors/pool.py` |
| Production write candidate | `policy-engine/src/polisyos/fabric/data_plane/streaming.py` |
| Read / consumer contract | `policy-engine/src/polisyos/fabric/quality/processing_guarantees.py` |
| Read / consumer contract | `policy-engine/src/polisyos/common/async_tools.py` |

**Не писать одновременно с:** ING-02, ING-03. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B87 lines=2263-2274 sha256=6e2bbb77d53fcdc1c29b51651016758e2e2b05b5f51bec0cf69a00d20f4e8996 -->
## B87. Ошибка подготовки или закрытия потока оставляет приобретённое соединение без cleanup

**Происхождение:** C07-09. **Основание:** StreamingSourceSession.create/subscribe/close и границы try в process_stream_dataset; LC1–LC4. [C07.R02: окна 1–570 и 570–1190]

**Проблема.** `subscribe()` приобретает connector/handle до последующего await подписки. При её ошибке create не возвращает session и не выполняет cleanup. В process_stream_dataset создание session, поиск latest checkpoint и rewind также происходят до основного try/finally. Кроме того, close устанавливает `_closed=True` до `close_stream`; если тот выбросит исключение, pool.release/close_all не выполнятся, а повторный close сразу вернётся по `_closed`.

На перенесённых методах: ошибка close дала ноль release/close_all; второй close уже не пытался завершить очистку. Нормальный путь корректно вызвал оба — отсутствие управления ресурсами вообще не утверждается. Ошибка subscribe возникла после одного acquire и без освобождения внутри метода. Pool и connector фикстурные; реальные leaked descriptors в работающем сервисе не измерялись.

**Рекомендуемое исправление.** Каждый успешно приобретённый ресурс немедленно включать в область гарантированного освобождения. Подготовка session и восстановление курсора должны находиться внутри той же области владения. Close различает requested/closing/fully-closed и через вложенный finally либо существующий async-context выполняет все обязательные стадии, сохраняя исходную причину ошибки. Повреждённый handle нужно инвалидировать, а не бездумно возвращать в пул как здоровый. `AsyncExitStack` — возможный стандартный механизм, не требование новой подсистемы. [C07.E02–E03]

**Приёмка.** Ошибка подписки, чтения checkpoint, rewind, обычного close и отмена не оставляют занятый слот пула. Повторный close безопасен и способен закончить незавершённую очистку; одна ошибка cleanup не маскирует первичную. Подавление всех ошибок не считается решением. Такая локальная правка полезна уже для нескольких последовательных попыток, без кластерного масштаба.

<!-- END_SOURCE_CARD B87 -->

<!-- SOURCE_CARD B89 lines=2405-2418 sha256=43cfad4b987c5efbb7cc52c98e8a7d84508a7d4d6e64395cc926086c91f3de1a -->
## B89. Отмена теряет слот пула, а закрытый пул возвращает его дважды

**Происхождение:** C08-01. **Основание:** `ConnectionPool.acquire/acquire_with_connector/release`, P1–P7. **Приоритет:** высокий для повторных ошибок и отмены в connector-пути. [C08.R01]

**Проблема.** После получения semaphore permit код может ожидать общий lock, проверку или создание соединения. Возврат permit ограждён `except Exception`; `asyncio.CancelledError` наследуется от BaseException и эту ветвь не проходит. В `release` запись сначала удаляется из `_in_use`, затем могут выполняться отменяемые сетевые ожидания, а освобождение permit находится ниже без общего finally. Повторный release уже не находит запись. В отдельной ветви закрытого пула permit возвращается внутри `if self._closed`, затем ещё раз внешним обработчиком исключения. [C08.E01]

**Различающие проверки.** P1/P2: при отмене после получения единственного слота — во время ожидания lock или connect — свободных слотов остаётся 0; следующая попытка получает PoolExhaustedError. P3: отмена во время retirement оставляет 0 слотов и пустой `_in_use`; второй release ёмкость не восстанавливает. P4: acquire у уже закрытого пула ёмкости 1 оставляет значение semaphore 2. P5/P6 — нормальный двойной release и отмена до получения permit — работают без утечки. Увеличенный semaphore закрытого пула сам по себе не доказывает выдачу лишних действующих соединений: это нарушение учёта, не заявленный production-overrun.

**Рекомендуемое исправление.** Ввести единый локальный жизненный цикл разрешения: получено → передано конкретному pooled-handle либо возвращено ровно один раз. Охват cleanup начинается сразу после получения permit. Отмена должна выполнять компенсацию и затем распространяться; нельзя превращать её в успешное выполнение. После удаления handle из общего индекса должен оставаться владелец незавершённого retirement/close. Не выдавать заменяющий ресурс сверх лимита, пока неизвестно, закрыт ли старый физический ресурс.

Не достаточно заменить `except Exception` на голый `except BaseException` и всегда вернуть слот: это может исправить один счётчик, потеряв незакрытый handle или допустив превышение физической ёмкости. Нужны правильные состояния владения. BoundedSemaphore полезен как тестовый детектор двойного release, но не заменяет сам протокол.

**Приёмка.** Отмена в ожидании lock, connect, validation и disconnect; нормальная ошибка; закрытие во время acquire; повторный release. Во всех случаях разрешения учтены ровно один раз, ресурс либо передан, либо очищен/изолирован с действующим владельцем. P7 показывает только модель сохранения permit на отмене, не production-патч. Полный ConnectionPool с реальными коннекторами не запускался; тестировались выбранные исходные тела с явно заданными оболочками.

<!-- END_SOURCE_CARD B89 -->

<!-- SOURCE_CARD B90 lines=2419-2434 sha256=40d664e5fe4a6a8f7559b5a5faf15b49ac0b739e538d9377c00e76e8a3dd26ee -->
## B90. Сеть удерживает общий замок пула, а acquire-timeout покрывает только очередь слотов

**Происхождение:** C08-02. **Основание:** тот же pool, L1–L3. **Приоритет:** высокий при медленных connect/health и нескольких потребителях. [C08.R01]

**Проблема.** Под `async with self._lock` исполняются `_get_idle_connection()` и `_create_connection()`. Первый может выполнять health-check и retirement нескольких кандидатов; второй ждёт сеть. `release()` также удерживает общий lock во время проверки/закрытия. Поэтому один медленный сетевой шаг задерживает не только другой connect, но и возврат уже использованного независимого handle. Параллелизм semaphore не снимает эту сериализацию.

`acquire_timeout_seconds` ограничивает получение permit, но не всю процедуру. Ожидание lock после permit не получает остатка этого deadline. Отдельный connection-timeout и фиксированные 10 секунд на health-check тоже не образуют автоматически общий верхний предел. Название acquire-timeout может подразумевать только очередь — тогда это следует явно отразить, а не представлять его полным лимитом операции.

**Проверки.** L1: при двух слотах второй connect не начинается, пока первый удерживает lock; начат один. L2: при acquire-timeout 5 мс контролируемое сетевое ожидание 20 мс удерживает и acquire, и независимый release. Это тест порядка, не измерение реальной задержки источника. L3 показывает контрольный шаблон: короткое резервирование под lock, сетевое ожидание вне него — оба connect начинаются.

**Рекомендуемое исправление.** Под lock только выбрать/зарезервировать запись и изменить метаданные. Connect, health и disconnect выполнять с выделенным владением вне общего замка. При повторном входе проверять закрытие/поколение пула, не публикуя ресурс в уже закрытое поколение. Для idle-объекта на проверке нужна отдельная отметка занятости: его нельзя одновременно выдать второму клиенту. Сохранить предел физических соединений и требования конкретного connector к потоку/loop.

Один monotonic deadline на согласованную операцию должен распределяться между ожиданием слота, lock и сетью. Если политика сознательно разделяет queue-timeout и connect-timeout, оба эффективных значения показываются пользователю и trace. Не повышать общий max_size как основное исправление.

**Приёмка.** Медленный connect не задерживает независимый release; два разрешённых connect могут идти одновременно; cancellation не возвращает B89; закрытие между reservation и publication не создаёт поздний действующий handle. Общая производительность измеряется после проверки корректности; универсальное ускорение в процентах не заявляется.

<!-- END_SOURCE_CARD B90 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**A.R10, L.S16, C.Q10.** `common/async_tools.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/common/async_tools.py). полный проектный модуль из предыдущего пакета; Полный модуль из прежнего пакета; в новом проходе совпадение Git blob SHA проверено и короткие задачи выполнены; [[1, 155]]

**C07.R02. Fabric: stream loop, session, accumulator и сохранение окон.** `policy-engine/src/polisyos/fabric/data_plane/streaming.py`. Окна чтения: 1–290; 290–570; 570–870; 870–1190; 1190–1450. Git blob SHA: `5b4656d8fbe7f4f6cce05f3ab394bb6a072499f8`. Последовательные прочитанные окна 1–1450; конец файла вне окна не заявлен. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/fabric/data_plane/streaming.py).

**C07.R04. Контракты гарантий, dedupe, порядка, backpressure и CDC.** `policy-engine/src/polisyos/fabric/quality/processing_guarantees.py`. Окна чтения: 1–260. Git blob SHA: `3074055a1cdac38d7031f36158a2a0b33b54620b`. Полный возвращённый текст в окне; не выполнена модель Pydantic. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/fabric/quality/processing_guarantees.py).

**C08.R01. ConnectionPool: acquire, release, I/O и lifecycle.** `policy-engine/src/polisyos/fabric/connectors/pool.py`. Запрошенные окна: 1–970, для короткого файла — до конца. Git blob `6672ef6bdf8f6ff1f60102f8adba3b000fc4d4b9`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/fabric/connectors/pool.py).

**C08.R08. Существующие мосты с copy_context.** `policy-engine/src/polisyos/common/async_tools.py`. Запрошенные окна: 1–230, для короткого файла — до конца. Git blob `01981db2ccbbb39ab54d2afa6ef3dafafcb0e3c0`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/common/async_tools.py).

**C07.E02. Python contextlib.AsyncExitStack.** Стандартный механизм async resource cleanup; не новый framework. [Открыть источник](https://docs.python.org/3/library/contextlib.html#contextlib.AsyncExitStack).

**C08.E01. Python: CancelledError наследуется от BaseException.** Первичная документация просмотрена 18.09.2026; не подтверждает состояние PolicyOS. [Открыть источник](https://docs.python.org/3.13/library/asyncio-exceptions.html).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
