<a id="bundle-opt-02"></a>

# OPT-02 — Настоящий SearchSpace и координаты фактического исполнения

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B112, B113, B127**. Локальный класс: **L**. Укрупнённая приёмка: **K3**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** OPT-01. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Переиспользовать настоящий SearchSpace API. Передать реальные candidate parameters, normalization, split и полные IDs истории. Различить continuous proposal и canonical discrete execution: loss принадлежит фактически исполненному объекту.

**Минимальные различающие проверки.** Backend получает поддержанные sample_sobol/denormalize. Разные параметры не превращаются в 0.5; отсутствие оценки не становится успешную оценку 0. Две координаты одного discrete action связаны с одним исполнением, но отдельные допустимые реплики сохраняются.

**Не менять / не считать исправлением.** Не записывать metrics вместо params, не сокращать ID до 8 символов, не объявлять current_best результатом нового успешного Bayesian поиска.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_opt_02.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T10. **Cross-boundary review:** X02, X08. **Activation rules:** A05.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/scientist/methods/autotune/bayesian_generator.py` |
| Production write candidate | `policy-engine/src/polisyos/scientist/methods/search/strategies/space.py` |
| Production write candidate | `policy-engine/src/polisyos/scientist/methods/autotune/models.py` |
| Production write candidate | `policy-engine/src/polisyos/scientist/methods/autotune/runtime.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/methods/search/strategies/types.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/methods/search/strategies/base.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/methods/search/strategies/bayesian.py` |

**Не писать одновременно с:** OPT-01, OPT-04, CTL-02. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B112 lines=2955-2968 sha256=ebcbfcc121108068640bc1d871fd4f596f6fdd3c0e6c54203025810562dea15f -->
## B112. Bayesian-обёртка предоставляет не тот SearchSpace, который потребляет оптимизатор

**Основание и область:** `autotune/bayesian_generator.SearchSpace`, `BaseSearchStrategy._sobol_candidate`, ранний маршрут `BayesianOptimizer.suggest`, полноценный `strategies/space.SearchSpace`; S01–S03. [C10.R04–C10.R06, C10.R10]

**Проблема.** Локальная обёртка пространства хранит только `dim` и `param_bounds`. Настоящий базовый алгоритм сразу вызывает `sample_sobol` и `denormalize`; поздний acquisition также ожидает `to_botorch_bounds`. Эти операции отсутствуют. Конструктор при этом может успешно создать оптимизатор и выставить `_botorch_available=True`; ошибка возникает при первом suggest и перехватывается как повод вернуть current_best/history/context.

**Локальное воспроизведение.** Полный оригинальный adapter соединён с fixture-оптимизатором, вызывающим неизменённое тело `_sobol_candidate`. Два вызова дают один и тот же `current_best={'x':7}` после ошибки отсутствующего `sample_sobol`; свойство доступности остаётся True. Контроль с объектом полного необходимого протокола доходит до настоящего построения выходного кандидата. BoTorch здесь не импортировался и GP не обучался.

**Рекомендуемое решение.** Не строить второе пространство: делегировать уже существующему `strategies.space.SearchSpace` через явную адаптацию `ParameterBounds`. Оно содержит нормализацию, категориальное раскрытие, sample и границы. Проверить протокол при сборке и различать установленную зависимость, корректную проводку интерфейса и готовность конкретного режима исполнения.

**Отказ не должен выглядеть новым поиском.** Возврат прежнего лучшего варианта допустим как повторное представление, но не как новая независимая рекомендация стратегии. При неподдерживаемой зависимости либо ошибке wiring — typed причина и разрешённая реально исполнимая стратегия. Не использовать словарь контекста как якобы новый кандидат без его контракта.

**Приёмка и предел.** Первый suggest при выбранном штатном SearchSpace проходит без ручного monkeypatch; категории/лог-шкалы round-trip; отсутствие optional stack честно различено. Не следует принимать fixture-контроль за доказательство работы реального Bayesian backend. Эта карточка о стыке, не об отсутствии оптимизатора в проекте.

<!-- END_SOURCE_CARD B112 -->

<!-- SOURCE_CARD B113 lines=2969-2982 sha256=1bd3fb58eb1fd1fbdc00d8a88c085a3c60b33ee11fab6f5e8c8c80c1c5d17115 -->
## B113. История Bayesian-поиска теряет координаты, параметры и полную идентичность наблюдения

**Основание и область:** `_history_to_evaluations`, `benchmark_to_evaluation`, downstream `_prepare_training_data`; X01–X04. [C10.R04, C10.R06]

**Проблема.** Для каждого словарного history entry нормализованные координаты задаются константой `(0.5,...,0.5)`, независимо от фактических параметров. Непереданный score становится успешным нулевым наблюдением. В benchmark-конвертере `params` заполняется метриками, не параметрами кандидата, а ID обрезается до первых восьми символов полного artifact ID.

**Локальное воспроизведение.** Наблюдения `x=0` и `x=10` при границах `[0,10]` превращаются в одинаковые `(0.5,)`. Entry без score получает `SUCCESS` и scalar 0. Два разных корректно оформленных `sha256:` ID превратились в одинаковое `sha256:0`; в params лежит `score`, а не `x`. Настоящий `_prepare_training_data` читает именно `params_normalized`, поэтому различимость параметров не восстанавливается позже автоматически.

**Рекомендуемое решение.** Разрешать параметры по полному candidate ref и версии search space, затем использовать существующий normalize. Связать наблюдение с полным ID кандидата, ID его конкретной оценки, snapshot данных, split и случайной репликой. Метрики хранить отдельно. Неполное score/params — адресный непригодный training input, а не центр пространства или нулевой успех.

**Ограничения reuse.** Одна точка с несколькими допустимыми репликами — не обязательно дубликат. Напротив, один и тот же результат, дважды пришедший из разных списков, не должен становиться двумя независимыми наблюдениями. Короткий ID допустим для интерфейса, но не для идентичности обучения или дедупликации. Для закрытых holdout нельзя автоматически переносить результаты в training: правила разделения источников сохраняются.

**Приёмка.** Разные физические параметры дают разные ожидаемые координаты; категориальные размеры корректны; полные IDs переживают сериализацию; отсутствие результата не становится нулём. Проверить оба формата истории и фактический caller. Измерение реального качества GP и конкретное downstream-стирание записи по короткому ID не выполнялись; показана потеря информации на самом adapter.

<!-- END_SOURCE_CARD B113 -->

<!-- SOURCE_CARD B127 lines=3292-3305 sha256=ae9f5e873bb33019cfd9524bd407a26c8aa7a5ec84cd2af79a6f2e497427cc70 -->
## B127. Разные непрерывные координаты обозначают одно и то же дискретное исполнение

**Основание и область:** `SearchSpace.denormalize/normalize`, `BaseSearchStrategy._random_candidate`, Bayesian `_is_duplicate`; DQ1–DQ4. Проверены полные `space.py/types.py/base.py` и перенесённый duplicate-предикат, без настоящего Bayesian acquisition. [C11.R04–R07]

**Проблема.** Целочисленный параметр округляется, категориальный выбирается по argmax, но в `PolicyCandidate.params_normalized` сохраняется исходный relaxed-вектор. Проверка дубликатов сравнивает расстояние между такими векторами, а не фактически исполненные параметры. Разные точки непрерывной области могут означать одно действие и пройти как разные; тот же вектор затем может не совпадать с координатой действительно выполненного опыта.

**Проверка.** Для integer `[0,1]` координаты 0,1 и 0,2 обе дают `n=0`, но duplicate-предикат возвращает false. Категориальные `(0,9;0,1)` и `(0,8;0,2)` обе выбирают A и тоже не считаются дублем. Нормализация фактически полученных параметров дала одинаковый canonical-vector. Контроль разных continuous-значений сохранил различие.

**Рекомендуемое исправление.** Сохранять отдельно предложенную relaxed-точку и действительный типизированный набор параметров с его канонической кодировкой. Для предотвращения повторного детерминированного вычисления сравнивать эффективный вход, версию модели/данных и область; surrogate-обучение получает координату произведённого эксперимента либо явно заданную модель дискретного пространства. Proposal-vector может оставаться в диагностике оптимизатора.

**Не уничтожить полезные реплики.** Повторное стохастическое измерение того же действия иногда намеренно и нужно для оценки неопределённости. Тогда его самостоятельный seed/replicate-ID сохраняется; оно не объявляется новым действием, но и не удаляется как лишнее. Округление continuous-координат ради дедупликации без принятого допуска также недопустимо.

**Приёмка.** Бинарные, integer, categorical и continuous параметры; две разные relaxed-точки с одним эффективным действием; разрешённые независимые реплики; исчерпанное конечное пространство. Проверить фактический адаптер Evaluation и pending/completed-учёт: upstream-канонизация может уже защищать отдельный путь, чего этот локальный опыт не устанавливает.

<!-- END_SOURCE_CARD B127 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**C10.R03. BenchmarkEvaluation, PromotionPolicy и указатель.** `policy-engine/src/polisyos/scientist/methods/autotune/models.py`. Прочитанные окна 1–320. Полная локальная копия не заявлена; извлечённые тела, где применимо, отдельны от Git blob. Git blob `21bb082b8ef77c0ce6d4791e5399b8df61ebea7f`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/autotune/models.py).

**C10.R04. Bayesian adapter: пространство, history и benchmark conversion.** `policy-engine/src/polisyos/scientist/methods/autotune/bayesian_generator.py`. Полный файл, 222 строк; Git blob локальной копии совпал. Исполнение с явно указанными fixtures. Git blob `7333f8d274097456155c1864f950fd9eb6f97996`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/autotune/bayesian_generator.py).

**C10.R05. Базовая стратегия: настоящий ранний sample-путь.** `policy-engine/src/polisyos/scientist/methods/search/strategies/base.py`. Прочитанные окна 1–300. Полная локальная копия не заявлена; извлечённые тела, где применимо, отдельны от Git blob. Git blob `451f10a7489bf79cb2c5258f22c06ac85d0e9932`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/strategies/base.py).

**C10.R06. Bayesian optimizer: warm, subset, refit и acquisition.** `policy-engine/src/polisyos/scientist/methods/search/strategies/bayesian.py`. Прочитанные окна 1–360, 360–700. Полная локальная копия не заявлена; извлечённые тела, где применимо, отдельны от Git blob. Git blob `ae5f35ca39afc0f7929f11cced25568c2fe19ef4`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/strategies/bayesian.py).

**C10.R10. Существующий полноценный SearchSpace.** `policy-engine/src/polisyos/scientist/methods/search/strategies/space.py`. Прочитанные окна 1–270. Полная локальная копия не заявлена; извлечённые тела, где применимо, отдельны от Git blob. Git blob `891ee459f937aa1b68c88f77cfab1b352289ed63`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/strategies/space.py).

**C10.R11. SearchLoopRunner: получение оценки и передача в registry.** `policy-engine/src/polisyos/scientist/methods/autotune/runtime.py`. Прочитанные окна 1–240, 238–350. Полная локальная копия не заявлена; извлечённые тела, где применимо, отдельны от Git blob. Git blob `6ab312bf51f77eb2791331a810edd44fda779650`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/autotune/runtime.py).

**C11.R04. Base strategy: RNG, Sobol-cache и восстановление.** `policy-engine/src/polisyos/scientist/methods/search/strategies/base.py`. Полный файл: 115 строк; Git blob совпал. Исполнен с описанными импортными fixtures. Git blob `451f10a7489bf79cb2c5258f22c06ac85d0e9932`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/strategies/base.py).

**C11.R05. StrategyState и представление кандидата.** `policy-engine/src/polisyos/scientist/methods/search/strategies/types.py`. Полный файл: 172 строк; Git blob совпал. Исполнен с описанными импортными fixtures. Git blob `8f82b4759f3f9aab8eb6213644e4c8b3b511148f`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/strategies/types.py).

**C11.R06. SearchSpace: нормализация и настоящий SciPy-sampler.** `policy-engine/src/polisyos/scientist/methods/search/strategies/space.py`. Полный файл: 143 строк; Git blob совпал. Исполнен с описанными импортными fixtures. Git blob `891ee459f937aa1b68c88f77cfab1b352289ed63`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/strategies/space.py).

**C11.R07. Bayesian: duplicate-предикат и tensor-to-candidate.** `policy-engine/src/polisyos/scientist/methods/search/strategies/bayesian.py`. Окна чтения: 375–480. Полная локальная копия не заявлена. Перенесённые тела в `sources/duplicate_extract.py`; сокращены аннотации/комментарии и форматирование, это не полный Git blob. Git blob `ae5f35ca39afc0f7929f11cced25568c2fe19ef4`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/strategies/bayesian.py).

**C12.R07. Унаследованный Evaluation DTO: параметры, метаданные, provenance.** `policy-engine/src/polisyos/scientist/methods/search/strategies/types.py`. Унаследованный полный DTO, не новое чтение; 172 строк, Git blob совпал. Исполнен с описанными импортными fixtures. Git blob `8f82b4759f3f9aab8eb6213644e4c8b3b511148f`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/strategies/types.py).

**C12.R08. Bayesian-подготовка обучающей цели: −scalar_score.** `policy-engine/src/polisyos/scientist/methods/search/strategies/bayesian.py`. Прочитанные окна: 290–325. Полный локальный blob не заявлен. Git blob `ae5f35ca39afc0f7929f11cced25568c2fe19ef4`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/strategies/bayesian.py).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
