<a id="bundle-opt-03"></a>

# OPT-03 — Рабочий warm-start и сохранённое GP-состояние

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B114, B115**. Локальный класс: **N**. Укрупнённая приёмка: **K3**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** OPT-02. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Сформировать совместимый обучающий корпус warm/current evaluations с настоящими origin/replica. В ветви без refit сохранить обученные гиперпараметры и согласованные transforms/noise через supported conditioning либо явно выбранный bounded refit.

**Минимальные различающие проверки.** Исторические оценки действительно достигают GP training/conditioning и начального порога. Новый observation не создаёт модель с defaults. Несовместимые bounds/transforms исключаются адресно. Tiny GP на 8–12 точках выполняется в K3; локальный boundary test использует spy.

**Не менять / не считать исправлением.** Не переносить state_dict в несовместимую модель, не удваивать одну ссылку как независимую информацию и не запускать GP обучение каждым агентом.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_opt_03.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T10. **Cross-boundary review:** I2 по фактическим consumers. **Activation rules:** A05.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/scientist/methods/search/strategies/base.py` |
| Production write candidate | `policy-engine/src/polisyos/scientist/methods/search/strategies/bayesian.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/methods/search/strategies/types.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/methods/search/strategies/space.py` |

**Не писать одновременно с:** CTL-02. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B114 lines=2983-2996 sha256=751ea1f4c2439927f429abb7d2be1bd0c15d45fd802529085431f219337fd766 -->
## B114. Warm-start сохраняет исторические оценки, но выбранный путь обучения их не использует

**Основание и область:** `BayesianOptimizer.warm_start`, `suggest`, `_select_training_subset`; файл прочитан до конца. W01–W03. [C10.R06]

**Проблема.** `warm_start` фильтрует валидные оценки и добавляет их в `_warm_evals`. Но условие initial sampling и `_select_training_subset` работают только с аргументом `evaluations`. В прочитанном полном файле `_warm_evals` не объединяется с ним для fit. Принятые исторические результаты остаются побочным списком, не эффективным обучающим корпусом.

**Локальное воспроизведение.** После приёма трёх валидных одномерных оценок `_warm_evals` содержит 3, а `_select_training_subset([])` возвращает 0. С одним текущим наблюдением выбрано 1, не 4. При явном контрольном объединении функция получает все 4. Условие `len(evaluations) < n_initial` также не учитывает накопленную историю. Это исполнение соответствующих исходных методов, не полный suggest/GP-fit.

**Рекомендуемое решение.** Сформировать один эффективный training corpus из совместимых исторических и текущих оценок до решения о cold-start и ограничения `max_train_size`. Проверять пространство, исходы, data/context vintage, split/доступ и независимость. Существующий механизм подвыборки оставить, но применить к действительно разрешённому корпусу. Непригодную историю сохранять с объяснением, не насильно добавлять в fit.

**Почему это производительность в широком смысле.** Уже оплаченные и подходящие наблюдения могут уменьшить число дорогих новых запросов. Просто увеличить `_warm_evals` или `n_initial` не помогает. Если caller уже сам передаёт историю в evaluations, для него дефект может быть компенсирован; такой случай должен быть отдельным контролем против двойного учёта.

**Приёмка.** Один и тот же пригодный корпус, переданный целиком или через warm-start + новую часть, даёт согласованную обучающую выборку и план; отклонённые записи не исчезают без причины; идентичные артефакты не удваивают sample-count; намеренные независимые повторы остаются отдельными.

<!-- END_SOURCE_CARD B114 -->

<!-- SOURCE_CARD B115 lines=2997-3010 sha256=4d5afea998b22ec18956bf039ae38fd1751fe457a8994ce87161fa2fdac20872 -->
## B115. Ветка «без refit» создаёт новую модель и теряет выученные параметры

**Основание и область:** `BayesianOptimizer._fit_gp`; G01–G03. [C10.R06, C10.E01]

**Проблема.** При необходимости refit создаётся `SingleTaskGP` и вызывается `fit_gpytorch_mll`. В соседней ветви, описанной как обновление данных без полного refit, снова создаётся `SingleTaskGP`, но прежние параметры/обученное состояние не передаются и fit не вызывается. Поэтому экономия обучения реализована через замену обученной модели новой, не через условление прежней на новые данные.

**Локальное воспроизведение.** Factory-fixture создаёт модель с параметром theta=1; fixture-fit устанавливает theta=7. Первый вызов выдаёт 7. Следующая итерация до refit interval создаёт иной объект с 1 и не увеличивает счётчик fit. Плановый refit снова даёт 7. Это доказательство порядка constructor/fit/assignment, не численный эксперимент с реальным kernel или измеренная деградация предсказаний.

**Рекомендуемое решение.** Развести обновление наблюдений и оптимизацию гиперпараметров. Для совместимого состояния использовать поддерживаемый backend-путь условления/обновления данных с сохранением выученной модели; при новой выборке, трансформациях или архитектуре — контролируемый refit. BoTorch предоставляет `condition_on_observations`, но его применение должно соответствовать режиму модели, input/outcome transforms и noise; простое копирование произвольного state_dict между несовместимыми шкалами небезопасно.

**Минимальный безопасный режим.** Пока reuse не проверен, явно выполнять refit для небольшой контрольной цепочки и показывать его стоимость. Затем вводить экономию как отдельный режим с эквивалентностью результата в её заявленных пределах, а не оставлять новое необученное состояние под старой меткой.

**Приёмка.** Проверить на настоящем SingleTaskGP сохранение learned parameters между разрешёнными refit, использование новых наблюдений, правильные transforms и version/shape; смена basis не маскируется повторным использованием. Замерить затраты отдельно от качества. Fixture theta не является найденным конкретным параметром настоящей модели.

<!-- END_SOURCE_CARD B115 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**C10.R05. Базовая стратегия: настоящий ранний sample-путь.** `policy-engine/src/polisyos/scientist/methods/search/strategies/base.py`. Прочитанные окна 1–300. Полная локальная копия не заявлена; извлечённые тела, где применимо, отдельны от Git blob. Git blob `451f10a7489bf79cb2c5258f22c06ac85d0e9932`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/strategies/base.py).

**C10.R06. Bayesian optimizer: warm, subset, refit и acquisition.** `policy-engine/src/polisyos/scientist/methods/search/strategies/bayesian.py`. Прочитанные окна 1–360, 360–700. Полная локальная копия не заявлена; извлечённые тела, где применимо, отдельны от Git blob. Git blob `ae5f35ca39afc0f7929f11cced25568c2fe19ef4`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/strategies/bayesian.py).

**C10.R10. Существующий полноценный SearchSpace.** `policy-engine/src/polisyos/scientist/methods/search/strategies/space.py`. Прочитанные окна 1–270. Полная локальная копия не заявлена; извлечённые тела, где применимо, отдельны от Git blob. Git blob `891ee459f937aa1b68c88f77cfab1b352289ed63`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/strategies/space.py).

**C11.R04. Base strategy: RNG, Sobol-cache и восстановление.** `policy-engine/src/polisyos/scientist/methods/search/strategies/base.py`. Полный файл: 115 строк; Git blob совпал. Исполнен с описанными импортными fixtures. Git blob `451f10a7489bf79cb2c5258f22c06ac85d0e9932`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/strategies/base.py).

**C11.R05. StrategyState и представление кандидата.** `policy-engine/src/polisyos/scientist/methods/search/strategies/types.py`. Полный файл: 172 строк; Git blob совпал. Исполнен с описанными импортными fixtures. Git blob `8f82b4759f3f9aab8eb6213644e4c8b3b511148f`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/strategies/types.py).

**C11.R06. SearchSpace: нормализация и настоящий SciPy-sampler.** `policy-engine/src/polisyos/scientist/methods/search/strategies/space.py`. Полный файл: 143 строк; Git blob совпал. Исполнен с описанными импортными fixtures. Git blob `891ee459f937aa1b68c88f77cfab1b352289ed63`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/strategies/space.py).

**C11.R07. Bayesian: duplicate-предикат и tensor-to-candidate.** `policy-engine/src/polisyos/scientist/methods/search/strategies/bayesian.py`. Окна чтения: 375–480. Полная локальная копия не заявлена. Перенесённые тела в `sources/duplicate_extract.py`; сокращены аннотации/комментарии и форматирование, это не полный Git blob. Git blob `ae5f35ca39afc0f7929f11cced25568c2fe19ef4`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/strategies/bayesian.py).

**C12.R07. Унаследованный Evaluation DTO: параметры, метаданные, provenance.** `policy-engine/src/polisyos/scientist/methods/search/strategies/types.py`. Унаследованный полный DTO, не новое чтение; 172 строк, Git blob совпал. Исполнен с описанными импортными fixtures. Git blob `8f82b4759f3f9aab8eb6213644e4c8b3b511148f`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/strategies/types.py).

**C12.R08. Bayesian-подготовка обучающей цели: −scalar_score.** `policy-engine/src/polisyos/scientist/methods/search/strategies/bayesian.py`. Прочитанные окна: 290–325. Полный локальный blob не заявлен. Git blob `ae5f35ca39afc0f7929f11cced25568c2fe19ef4`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/strategies/bayesian.py).

**C10.E01. BoTorch: condition_on_observations и transform-aware model API.** Первичная документация просмотрена 18.09.2026; это не проверка версии целевого окружения. [Документация](https://botorch.readthedocs.io/en/stable/models.html).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
