<a id="bundle-opt-04"></a>

# OPT-04 — Привязанный champion и compare-and-publish

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B116, B117**. Локальный класс: **L**. Укрупнённая приёмка: **K3**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** OPT-01, OPT-02. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Проверить candidate/evaluation/suite/split/loop и базу сравнения. Связать чтение предшественника, сравнение и публикацию head существующей атомарной операцией/lock. Дорогая оценка остаётся вне транзакции.

**Минимальные различающие проверки.** Чужая evaluation или другой suite не promote. Старый score=2 не переписывает уже опубликованный score=3. Сравнение против нового predecessor выполняется явно. Две управляемые локальные попытки проверяют гонку; новый comparison profile требует собственного перехода.

**Не менять / не считать исправлением.** Не считать atomic rename атомарным compare. Право записи не выводится из факта хорошего score.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_opt_04.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T10. **Cross-boundary review:** X08, X10. **Activation rules:** A09.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/scientist/methods/autotune/registry.py` |
| Production write candidate | `policy-engine/src/polisyos/scientist/methods/autotune/runtime.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/methods/autotune/models.py` |
| Read / consumer contract | `policy-engine/src/polisyos/core/artifacts/store.py` |

**Не писать одновременно с:** OPT-02. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B116 lines=3011-3024 sha256=3f04f3ddd1d21f7ffbea51147028ae51287460255c7b5dc52ad9a1b487e49f98 -->
## B116. Технический champion может получить оценку другого кандидата или несопоставимого испытания

**Основание и область:** generic `ChampionRegistry.consider_promotion`, `BenchmarkEvaluation`, вызов из `SearchLoopRunner._evaluate_candidate`; C01–C04. Особый `claim_adjudication` путь не исполнялся. [C10.R03, C10.R07, C10.R11]

**Проблема.** API отдельно получает candidate_ref и evaluation_ref. Загруженная оценка содержит собственные candidate_ref, loop_id, suite_id/version и runtime split, но перед созданием pointer они не сопоставляются с эффективным запросом. Проверяются guardrails, promotable, sample count и число метрики; этого недостаточно для установления предмета доказательства. Текущий champion хранит suite_version, однако совместимость старой и новой базы сравнения также не проверяется в этой функции.

**Локальное воспроизведение.** Полный registry на fixture-store с настоящими временными JSON-файлами записал candidate B с evaluation, описывающей A. Отдельно прошла оценка из другого loop и смена suite/version при лучшем числе. Контроль `promotable=False` правильно отказал: защита не отсутствует целиком, она не закрывает идентичность. В нормальном caller candidate передаётся evaluator, но результат затем сохраняется и рассматривается без обнаруженной проверки соответствия внутри прочитанного участка.

**Рекомендуемое решение.** До использования числа связать candidate, evaluation и активную политику; подтвердить применимую версию suite, split, методику метрики и data basis. Не сравнивать два числа только потому, что ключ метрики одинаков. Для новой suite — переоценить текущий champion на новой базе либо явно начать новое сравнение; не запрещать развитие benchmark вообще.

**Сохранить границы полномочий.** Это проверка технической привязки, не добавление нового институционального допуска. Не следует ослаблять специализированные guards, выдавать подпись за валидность оценки или считать этот опыт обходом всех tenant/authentication/CAS-проверок. Fixture-store здесь не воспроизводит их.

**Приёмка.** Перепутанная пара A/B, чужой loop, неверный split и несовместимая suite не меняют pointer; одинаковая подтверждённая база допускает честное улучшение; ошибка возвращает конкретную несовместимость, а не общий low score. Проверить cache-replay оценки и штатный evaluator-to-registry путь.

<!-- END_SOURCE_CARD B116 -->

<!-- SOURCE_CARD B117 lines=3025-3038 sha256=716aa89ce5b68d85b0487a8509806214c17d261958740f7363c2228a033f924d -->
## B117. Атомарная запись champion-файла не делает атомарным сравнение с предшественником

**Основание и область:** `get → compare → _write_pointer` и `_write_json`; R01–R02. Полный registry, настоящий файловый ввод-вывод и управляемая конкурентная последовательность. [C10.R07, C10.E02]

**Проблема.** Указатель читается, улучшение вычисляется, затем файл атомарно заменяется. Между чтением и записью другой вызов может установить более сильный вариант. Второй писатель не проверяет, что сравнивавшийся предшественник всё ещё актуален. Atomic replace защищает целостность одного файла, не изоляцию всей операции read–compare–publish.

**Локальное воспроизведение.** Исходный score=1. Писатель B со score=2 прочитал его и остановлен непосредственно перед записью. Писатель C со score=3 прочитал тот же 1 и опубликовал 3. После освобождения B записал 2. Обе операции вернули promoted=True, окончательный pointer содержит 2. При последовательном контроле C→B значение осталось 3, а B отвергнут. Синхронизация событий обеспечивает порядок; случайная гонка не используется как доказательство.

**Рекомендуемое решение.** Сделать conditional publish относительно конкретной версии predecessor под существующим владельцем: транзакция/compare-and-swap или подходящий стабильный lock вокруг чтения, сравнения и фиксации. На конфликте заново сравнить с актуальным pointer, а не слепо повторять старую запись. Дорогой benchmark исполняется вне критической секции; под ней остаётся короткая проверка неизменяемых артефактов и перехода.

**Два обязательных уточнения.** In-process lock недостаточен для нескольких процессов, если такой режим разрешён. Для специализированного claim-пути pointer и promotion_basis должны оставаться согласованными; просто добавить блокировку одной записи недостаточно. История конфликтовавшего кандидата/оценки сохраняется независимо от того, стал ли он текущим.

**Приёмка и предел.** Управляемая последовательность B/C не ухудшает лучший актуальный результат по одной принятой политике; conflicting predicate возвращается явно. Авария на границе публикации даёт старое или новое согласованное состояние. На production workload конкурентное обращение к этому registry не измерялось; карточка применима при разрешении нескольких писателей. Новый распределённый реестр ради одного локального сценария не нужен.

<!-- END_SOURCE_CARD B117 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**C10.R03. BenchmarkEvaluation, PromotionPolicy и указатель.** `policy-engine/src/polisyos/scientist/methods/autotune/models.py`. Прочитанные окна 1–320. Полная локальная копия не заявлена; извлечённые тела, где применимо, отдельны от Git blob. Git blob `21bb082b8ef77c0ce6d4791e5399b8df61ebea7f`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/autotune/models.py).

**C10.R07. ChampionRegistry: generic consideration и запись.** `policy-engine/src/polisyos/scientist/methods/autotune/registry.py`. Полный файл, 277 строк; Git blob локальной копии совпал. Исполнение с явно указанными fixtures. Git blob `7544c51adae9d6024825ee09e5f06fd5571d647f`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/autotune/registry.py).

**C10.R11. SearchLoopRunner: получение оценки и передача в registry.** `policy-engine/src/polisyos/scientist/methods/autotune/runtime.py`. Прочитанные окна 1–240, 238–350. Полная локальная копия не заявлена; извлечённые тела, где применимо, отдельны от Git blob. Git blob `6ab312bf51f77eb2791331a810edd44fda779650`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/autotune/runtime.py).

**C14.R02. FileSystemCAS: dedup, ref, чтение, lock-map и вызывающие обёртки.** `policy-engine/src/polisyos/core/artifacts/store.py`. Окна чтения: 175–302, 300–700, 700–1030. Локально сохранены выбранные тела; полный blob не заявлен. Git blob `76cc3574f2bbbb102f47111872ac31f131c253fe`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/core/artifacts/store.py).

**C10.E02. Python: atomic replace и файловые операции.** Первичная документация просмотрена 18.09.2026; это не проверка версии целевого окружения. [Документация](https://docs.python.org/3/library/os.html).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
