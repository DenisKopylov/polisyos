<a id="bundle-res-01"></a>

# RES-01 — Повторный resume, достаточный state и дешёвый индекс

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B63, B70, B71**. Локальный класс: **L**. Укрупнённая приёмка: **K2**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** STA-02, RES-02. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Сохранять original workflow fingerprint отдельно от остатка. Проверять доступность нужных output/state, а не кардинальность cache refs. Восстанавливать индекс по уникальным успешно проверенным точным refs; checkpoint-tail применять только при доказанной границе истории.

**Минимальные различающие проверки.** A→B→C переживает две остановки: A/B не запускаются заново. Полный valid-state без ненужного cache seed продолжает C; две копии A не покрывают B. 100 повторных точных refs не дают 100 повторных чтений; failed load не помечается проверенным. Changed functional input остаётся несовместимым.

**Не менять / не считать исправлением.** Не отключать fingerprint/scope guards, не выдавать allow_replay за реально возвращённые в план узлы, не dedupe только по idempotency_key.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_res_01.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T5, T6. **Cross-boundary review:** X04. **Activation rules:** общие правила scope/приёмки.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py` |
| Production write candidate | `policy-engine/src/polisyos/scientist/orchestration/engine/idempotency.py` |
| Production write candidate | `policy-engine/src/polisyos/scientist/orchestration/engine/executor.py` |
| Production write candidate | `policy-engine/src/polisyos/scientist/orchestration/engine/async_executor.py` |
| Production write candidate | `policy-engine/src/polisyos/scientist/orchestration/engine/runner/local_runner.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/orchestration/engine/state.py` |

**Названные в r19 тематически близкие tests (не подтверждение их покрытия/запуска):**

- `policy-engine/tests/integration/scientist/test_checkpoint_resume.py`

**Не писать одновременно с:** STA-01, STA-02, RES-02, EXE-01, EXE-02. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B63 lines=1629-1642 sha256=32962af76b9f728aceb504125f39eede0c6431de9547983bc235eb05459f6bf1 -->
## B63. Восстановление кэша многократно читает одинаковые записи и их результаты

**Происхождение:** C05-07. **Основание:** WorkflowExecutor.execute, seed_from_trace/seed_from_entry_refs/load_entry; W1–W3. **Охват:** S для устранения повторных точных ссылок; M для checkpoint-tail восстановления. **Приоритет:** экономия восстановления при длинной истории/медленном CAS. [C05.N03, C05.N04]

**Проблема.** При execute создаётся новый NodeResultCache, затем читается весь trace, затем refs checkpoint. Каждая найденная запись вызывает load_entry: читается cache-entry, далее bytes его outcome, даже если та же точная запись уже была загружена. Общей дедупликации успешных проверок между двумя источниками нет. При первом настоящем get outcome снова читается. Поэтому «тёплое» возобновление само способно выполнить существенный объём повторного I/O и разбора данных прежде, чем дать полезный результат.

**Воспроизведение.** Счётная модель с 100 появлениями entry-A и одним entry-B выполнила 202 чтения «entry+outcome». Контроль, отмечающий только уже успешно проверенные точные refs, выполнил четыре и восстановил тот же индекс. Для ста действительно разных refs оба пути сделали 200 чтений: эффект не приписан всем workload. W3 проверяет, что временно нечитабельную запись нельзя отметить проверенной и затем навсегда пропускать. В опыте не запускался настоящий store и не отменялись его epoch/custody проверки.

**Рекомендуемое решение.** Первое дешёвое изменение — в рамках одной операции восстановления объединить точные refs trace/checkpoint и повторно использовать успешную проверку одной неизменяемой записи. Дедуплицировать не только по idempotency_key: две записи одного ключа могут иметь разное содержимое и требовать диагностики противоречия. Контекст доверия, доступ и область run остаются частью допустимости.

Следующий шаг — использовать проверенный checkpoint как границу и читать после него только нужный хвост журнала, а не пересобирать весь run каждый раз. Смещение/последовательность должны быть связаны с подлинной историей и актуальной попыткой; простое числовое offset без этой связи небезопасно. Ленивое чтение payload допустимо лишь там, где неизменяемый манифест уже однозначно определяет схему и все обязательные проверки всё равно выполняются до использования. Сегодня усиленная проверка output-aware результата действительно существует — её пропуск не является оптимизацией.

**Приёмка и границы.** Cold и restored-index дают одинаковое множество допустимых записей; точные дубли не вызывают повторного большого чтения; конфликтующий outcome, повреждённая эпоха и неверный run не становятся hits. Считать байты, число обращений и время до первого полезного шага, а не только hit-rate. Частота дубликатов, размер trace и реальная доля этого I/O в задержке PolicyOS здесь не измерены. Это адресная оптимизация существующего механизма, не новый сервис кэширования.

<!-- END_SOURCE_CARD B63 -->

<!-- SOURCE_CARD B70 lines=1873-1888 sha256=eadcf7072e1ce0c09c3ddb56144e572674cf1df043750d1b4fe23211020573cc -->
## B70. Первое восстановление меняет отпечаток workflow и может запретить второе

**Происхождение:** C06-01. **Основание:** `resume_from_checkpoint`, `_build_resume_workflow_spec`, `compute_workflow_fingerprint`, LocalWorkflowRunner, AsyncWorkflowExecutor и CASCheckpointHook; R70-1–R70-4. **Приоритет:** высокий для повторного восстановления; S–M. [C06.R01–R04]

**Проблема.** При resume исходный workflow сверяется с отпечатком контрольной точки, затем из него удаляются завершённые узлы и зависимости на них. Сокращённый workflow передаётся runner. AsyncWorkflowExecutor заново вычисляет fingerprint именно переданного остатка и передаёт его hook; hook сохраняет это значение в новой контрольной точке, одновременно объединяя список ранее завершённых узлов с новым прогрессом. Связь с исходным графом в этой передаче не сохраняется отдельным полем.

Для исходного A→B→C первая остановка после A оставляет B→C. Если после восстановления B выполнен и создана новая точка, её fingerprint относится к B→C, а completed_nodes уже содержит A и B. Следующий resume с исходным A→B→C попадает в WorkflowMismatchError. Передать вместо исходного только B→C тоже недостаточно: A теперь отсутствует в этом графе и отвергается проверкой completed_nodes. Это не смена научной задачи — изменение создаёт сама процедура продолжения.

**Проверка.** Исполнены извлечённые функции сокращения графа и построения fingerprint на Pydantic-оболочках. Канонический сериализатор проекта заменён явно указанной стабильной JSON-сериализацией; это не проверка всех правил PolicyOS canon. Различие содержательных payload и две ветви отказа воспроизведены. Контроли сохраняют одинаковый fingerprint при изменении только retry/timeout и различие при изменении функционального параметра. Полный двойной resume ещё должен быть выполнен в проектной среде.

**Рекомендуемое решение.** Сохранить неизменяемую идентичность исходного принятого workflow и отдельно представлять план оставшейся работы. Hook должен записывать исходный функциональный fingerprint вместе с доказуемой связью текущего плана исполнения с ним. Проверять завершённые появления узлов относительно исходного графа, а остаток выводить из него и подтверждённого прогресса. Можно передавать исходный граф с явным набором уже зафиксированных узлов либо оставить сокращённый граф и добавить origin-binding — выбирается вариант, лучше согласующийся с действующими владельцами.

**Чего не делать.** Не отключать сравнение fingerprint и не менять его задним числом на произвольный «ожидаемый». Настоящее изменение параметров, зависимостей, популяции или метода требует отдельной версии исследования и инвалидации затронутой работы; технический resume не должен легализовать такую смену.

**Приёмка.** A выполняется; первый сбой; resume выполняет B; второй сбой; второй resume выполняет C. A и B не вызываются снова, история связна. Изменённый настоящий запрос по-прежнему не принимается по старой точке. Дополнительно проверить повторное открытие уже полностью завершённого run. Имеющиеся тесты однократного resume и tenant/cell-защиты сохраняются, а не заменяются. [C06.R05]

<!-- END_SOURCE_CARD B70 -->

<!-- SOURCE_CARD B71 lines=1889-1904 sha256=6239c931b0f33cd80db9286a7010e500f4fcf8f9d03765a4e5c615172c2bb1ca -->
## B71. Cache-seed остаётся обязательным даже для уже удалённых из плана узлов

**Происхождение:** C06-02. **Основание:** последовательность `resume_from_checkpoint`; R71-1–R71-4. **Приоритет:** высокий при полном восстановленном состоянии; S–M. [C06.R01, C06.R02]

**Проблема.** После materialize_checkpoint_state завершённые узлы удаляются из графа. Тем не менее стратегия `require_cache_seed` отвергает resume, если число cache_entry_refs меньше числа завершённых cacheable-узлов. В этом маршруте ссылки требуются как обязательное условие для операций, которые уже не будут исполняться. При полном допустимом снимке и доступных входах остатка отсутствие оптимизационной записи может стать искусственным препятствием.

Проверка к тому же кардинальная: два повторения ссылки на A проходят численный порог двух завершённых узлов, не доказывая покрытия B или читаемости результатов. Это не доказательство принятия испорченного полного checkpoint: его целостность проверяется отдельно. Это показывает, что число cache refs — неподходящий заменитель требуемого свойства.

**Связанный смысловой разрыв.** `allow_replay` ослабляет эту проверку и пишет предупреждение о возможном повторном запуске завершённых узлов, но `_build_resume_workflow_spec` в обоих режимах удаляет их одинаково. В рассматриваемой процедуре само название стратегии не возвращает эти узлы в план. Нельзя рекомендовать allow_replay как универсальный способ восстановить отсутствующее вычисление.

**Рекомендуемое решение.** Отдельно доказать достаточность и актуальность восстановленного состояния и всех артефактов, необходимых незавершённой части. Когда это доказано, cache-entry является ускорителем, а не новым обязательным свидетельством той же уже зафиксированной работы. Если конкретный результат действительно требуется восстановить через кэш или повтор, проверять связанный план восстановления по появлению узла, входам, версиям и результату; число ссылок не заменяет такую проверку.

При неполном состоянии и недоступном обязательном результате следует адресно восстановить данные или остановить зависимый шаг. Нельзя просто удалить guard, принять любые ссылки или считать полный JSON доказательством наличия всех внешних blobs. Scope, целостность, ограничения использования и исходная идентичность сохраняются.

**Приёмка.** Полный проверенный снимок с доступными входами C и без ненужных cache refs продолжает C; недостающий обязательный вход вызывает настоящий repair/отказ; дубликаты не засчитываются как независимое покрытие. Обе стратегии имеют точное документированное поведение. Локальные проверки воспроизводят предикат и проекцию графа, не весь protected-resume.

<!-- END_SOURCE_CARD B71 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**C04.K03. Scientist AsyncWorkflowExecutor.** `policy-engine/src/polisyos/scientist/orchestration/engine/async_executor.py`. 500–740; 735–1030. Git blob: `5f0ac743d28ad0112b9f988f7ba47e10c4297249`. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/async_executor.py).

**C04.K04. NodeResultCache / idempotency.** `policy-engine/src/polisyos/scientist/orchestration/engine/idempotency.py`. 1–315. Git blob: `3ae08d7ccf0e35da459c74446d322a766e40c62a`. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/idempotency.py).

**C05.N03.** `policy-engine/src/polisyos/scientist/orchestration/engine/idempotency.py`. 35–275; 247–335. Ключ, запись всего outcome и процедуры восстановления; модуль целиком не импортирован. Git blob: `3ae08d7ccf0e35da459c74446d322a766e40c62a`. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/idempotency.py).

**C05.N04.** `policy-engine/src/polisyos/scientist/orchestration/engine/executor.py`. 365–390; 690–724; 881–905; 903–1035. Cache-key, replay, store и seed из двух источников. Git blob: `dbb0812a5e49222d1c65858e8d905e012c775d0c`. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/executor.py).

**C05.N07.** `policy-engine/src/polisyos/scientist/orchestration/engine/state.py`. 1–210; весь возвращённый файл. Форма ExperimentState; в опытах всё равно использован явный минимальный DTO-заместитель. Git blob: `3724db92babaa2e2da1d1e35f8467159d3afe980`. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/state.py).

**C06.R01. Scientist: checkpoint, delta, фиксация и materialize.** `policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py`. Окна чтения: 1–250, 360–700, 975–1250, 1420–1750. Git blob SHA: `dd90c9121de3e14b7ea2ff8db4781fa3ef750334`. Типы, scope, hook, delta, создание и материализация checkpoint; не полный аудит файла. [Закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py).

**C06.R02. Scientist: resume и остаточный workflow.** `policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py`. Окна чтения: 975–1120, 1760–2070. Git blob SHA: `dd90c9121de3e14b7ea2ff8db4781fa3ef750334`. Pruning, fingerprint и resume; последнее окно до конца полученного файла. Повтор того же blob, а не второй независимый источник. [Закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py).

**C06.R03. Scientist: асинхронное исполнение, уровни, checkpoint и rollback.** `policy-engine/src/polisyos/scientist/orchestration/engine/async_executor.py`. Окна чтения: 100–250, 240–535, 535–735, 1090–1220. Git blob SHA: `5f0ac743d28ad0112b9f988f7ba47e10c4297249`. Фактическая передача workflow_fingerprint; одиночный skip; параллельное слияние и сохранение; барьер уровня. [Закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/async_executor.py).

**C06.R04. Локальный runner: передача остаточного workflow.** `policy-engine/src/polisyos/scientist/orchestration/engine/runner/local_runner.py`. Окна чтения: 1–240. Git blob SHA: `3d789d27667fb75bbcac07e03a446a5255b31b82`. Получен полный короткий файл; LocalWorkflowRunner делегирует AsyncWorkflowExecutor. [Закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/runner/local_runner.py).

**C07.R07. AsyncWorkflowExecutor: потребитель pre_check.** `policy-engine/src/polisyos/scientist/orchestration/engine/async_executor.py`. Окна чтения: 735–1040. Git blob SHA: `5f0ac743d28ad0112b9f988f7ba47e10c4297249`. Для проверки достижимости budget-гипотезы, не полное исполнение. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/async_executor.py).

**C08.R06. ExperimentState: контракт Decimal и мутаций.** `policy-engine/src/polisyos/scientist/orchestration/engine/state.py`. Запрошенные окна: 1–95, для короткого файла — до конца. Git blob `3724db92babaa2e2da1d1e35f8467159d3afe980`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/state.py).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
