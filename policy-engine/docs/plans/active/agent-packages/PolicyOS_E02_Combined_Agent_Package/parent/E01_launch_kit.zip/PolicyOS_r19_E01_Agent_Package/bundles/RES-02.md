<a id="bundle-res-02"></a>

# RES-02 — Единый завершённый frontier и атомарный tier checkpoint

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B72, B73**. Локальный класс: **L**. Укрупнённая приёмка: **K2**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** STA-01. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Уравнять смысл skip/ok в одиночном и параллельном пути. Определить commit/rollback действующего tier; сохранять state и complete-set одного рубежа вместе. Для нынешнего атомарного merge предпочтительна одна согласованная точка уровня, не N одинаковых snapshots с разным списком completed.

**Минимальные различающие проверки.** Независимый сосед не меняет skip в completed. A/B increment: остановка после первой публикации не применяет B дважды. A=ok/B=fail при fail_fast и continue даёт согласованные returned state, durable head и компенсацию. CAS-результат завершённого вычисления не уничтожается из-за rollback state.

**Не менять / не считать исправлением.** Не чинить только append-порядок; не смешивать наличие артефакта и принятую state-write; не объявлять skip успешным producer.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_res_02.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T6. **Cross-boundary review:** X03, X04. **Activation rules:** общие правила scope/приёмки.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/scientist/orchestration/engine/async_executor.py` |
| Production write candidate | `policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/orchestration/engine/state_merge.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/orchestration/engine/state_branching.py` |

**Названные в r19 тематически близкие tests (не подтверждение их покрытия/запуска):**

- `policy-engine/tests/integration/scientist/test_checkpoint_resume.py`

**Не писать одновременно с:** EXE-01, RES-01, EXE-02. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

**Связанные карточки для адресного чтения, не второе назначение:** B29 → CYC-05; B70 → RES-01; B71 → RES-01.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B72 lines=1905-1920 sha256=38979cf3522b6b847946b86db0042408c08d07996d5b2f52a7c127e56c718189 -->
## B72. Одиночный skip считается завершением, а параллельный — нет

**Происхождение:** C06-03. **Основание:** `_run_single_node` и `_execute_tiers` в AsyncWorkflowExecutor; R72-1–R72-4. **Приоритет:** высокий; S. [C06.R03]

**Проблема.** `_run_single_node` возвращает `node_failed = outcome.status == 'fail'`. Внешняя одиночная ветвь добавляет alias в completed_nodes всякий раз, когда node_failed ложен. Значит, `skip` попадает в успешно завершённые. Параллельная ветвь добавляет туда лишь записи `status == 'ok'`. Наличие другого независимого runnable-узла меняет смысл одного и того же skip.

Сам пропущенный узел checkpoint не создаёт. Но следующий успешный узел может сохранить уже загрязнённый completed_nodes. В дальнейшем пропущенная работа будет удалена из плана resume либо включена в знаменатель B71, хотя cache-entry для её успешного результата не производился. Это отдельная проблема от проекции stop→abstain из B29.

**Рекомендуемое решение.** В одиночном и параллельном маршрутах одинаково учитывать явно успешную фиксацию результата. Различать «попытка терминальна», «работа осмысленно не требуется по условию» и «заявленные выходы действительно произведены». Использовать существующие статусы и skip-blocker; не вводить новый vocabulary только ради исправления одного условия. Для зависимого шага проверять наличие именно нужных выходов, а не полагаться на отрицание fail.

Это не означает, что любой условный skip нужно автоматически повторять. Решение о повторе зависит от неизменности условия и состояния задачи. Но skip не должен молча превращаться в свидетельство выполненного вычисления.

**Приёмка.** Метаморфный тест: добавить независимый соседний узел, не меняя входов исследуемого узла. Его skip и дальнейший resume сохраняют один смысл в обеих ширинах. Ok добавляется в завершённые в обеих ветках; fail не добавляется. Тест выполняется на нативных статусах, а не с локальной заменой skip на ok.

**Граница.** Локально исполнено точное логическое условие обеих ветвей; частота таких одиночных skip в реальном workflow не измерена. Реальная достижимость полного отказа через checkpoint требует интеграционного контроля B70–B73.

<!-- END_SOURCE_CARD B72 -->

<!-- SOURCE_CARD B73 lines=1921-1938 sha256=e621748d93e6a09366084624850c95e9765196b665a628702f05054dd857bd9b -->
## B73. Снимок параллельного уровня не совпадает с его отметками завершения и отката

**Происхождение:** C06-04. **Основание:** `_run_parallel_tier`, `_execute_tiers`, `_handle_checkpoint`, CASCheckpointHook; R73-1–R73-4. **Приоритет:** высокий до надёжного resume; M. [C06.R01, C06.R03]

**Первый механизм.** Все успешные результаты уровня сначала сливаются в state. Затем checkpoint создаётся последовательно для каждого успешного alias, а список checkpoint_completed растёт по одному элементу. Уже первая точка содержит эффекты всех успешных соседей, но отмечает завершённым только первого. Сбой между двумя записями оставляет несогласованный рубеж: данные B включены, а B по metadata ещё предстоит выполнить.

В модели A и B работают от одной базы; B увеличивает n с 0 до 1. Первая точка содержит n=1 и completed=[A]. Resume снова исполняет B и получает n=2. Внешний кэш не обязан предотвратить повтор: если B читает n, его ключ на восстановленном n=1 уже отличается от исходного ключа на n=0.

**Второй механизм.** Если один сосед успешен, а другой вернул fail, `_run_parallel_tier` может сохранить успешный state до возврата. Затем внешняя fail_fast-ветвь возвращает state к tier_savepoint, но опубликованная контрольная точка этим кодом обратно не согласуется. Текущий итог и durable head способны указывать на разные решения о фиксации. В той же последовательности `completed_before_tier` для compensation формируется после добавления успешных aliases; это также следует согласовать с реальным рубежом.

**Рекомендуемое решение.** Сначала определить принятое правило commit/rollback для уровня, затем фиксировать согласованный state вместе с полным набором действительно зафиксированных появлений узлов и их результатами. Для текущей схемы естественный экономный вариант — одна контрольная точка на атомарно сливаемый уровень, а отдельные node-events и результаты сохранить независимо. Для поузловой фиксации требуется состояние именно соответствующего префикса, а не уже общий финальный state.

При fail_fast, означающем откат всего уровня, новая успешная head не публикуется до решения об откате. При явно принятой политике частичной фиксации она должна одинаково отражаться в возвращаемом state, metadata и последующем resume. Ни одна политика не должна стирать уже сохранённый артефакт успешного вычисления: наличие артефакта и его включение в текущий рабочий state — разные факты.

**Дополнительная экономия.** Один checkpoint согласованного уровня вместо N одинаковых общих снимков уменьшает повторную сериализацию и обновление head. Это предполагаемая экономия числа операций; производительность настоящего CAS здесь не измерена.

**Приёмка.** Остановить процесс после первой возможной публикации уровня A/B: восстановленный state и complete-set совпадают по смыслу; инкремент B не применяется второй раз. Отдельно A=ok/B=fail при fail_fast и continue. Проверить compensation, output cache и seed refs; просто переставить один append недостаточно. Локальные R73 — модель порядка, не запуск полного executor.

<!-- END_SOURCE_CARD B73 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**C04.K03. Scientist AsyncWorkflowExecutor.** `policy-engine/src/polisyos/scientist/orchestration/engine/async_executor.py`. 500–740; 735–1030. Git blob: `5f0ac743d28ad0112b9f988f7ba47e10c4297249`. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/async_executor.py).

**C05.N01.** `policy-engine/src/polisyos/scientist/orchestration/engine/state_merge.py`. Весь возвращённый файл; 1–340. Локальная копия совпала с полным Git blob и исполнена с DTO-фикстурами. Git blob: `65b51cb121ff31ef58d497eead16a467c4e1726f`. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/state_merge.py).

**C05.N02.** `policy-engine/src/polisyos/scientist/orchestration/engine/state_branching.py`. Весь возвращённый файл; 1–240. Локальная копия совпала с полным Git blob и исполнена с DTO-фикстурами. Git blob: `1f89e922ab4c207ba779625746364abb4bc07611`. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/state_branching.py).

**C06.R01. Scientist: checkpoint, delta, фиксация и materialize.** `policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py`. Окна чтения: 1–250, 360–700, 975–1250, 1420–1750. Git blob SHA: `dd90c9121de3e14b7ea2ff8db4781fa3ef750334`. Типы, scope, hook, delta, создание и материализация checkpoint; не полный аудит файла. [Закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py).

**C06.R02. Scientist: resume и остаточный workflow.** `policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py`. Окна чтения: 975–1120, 1760–2070. Git blob SHA: `dd90c9121de3e14b7ea2ff8db4781fa3ef750334`. Pruning, fingerprint и resume; последнее окно до конца полученного файла. Повтор того же blob, а не второй независимый источник. [Закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py).

**C06.R03. Scientist: асинхронное исполнение, уровни, checkpoint и rollback.** `policy-engine/src/polisyos/scientist/orchestration/engine/async_executor.py`. Окна чтения: 100–250, 240–535, 535–735, 1090–1220. Git blob SHA: `5f0ac743d28ad0112b9f988f7ba47e10c4297249`. Фактическая передача workflow_fingerprint; одиночный skip; параллельное слияние и сохранение; барьер уровня. [Закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/async_executor.py).

**C07.R07. AsyncWorkflowExecutor: потребитель pre_check.** `policy-engine/src/polisyos/scientist/orchestration/engine/async_executor.py`. Окна чтения: 735–1040. Git blob SHA: `5f0ac743d28ad0112b9f988f7ba47e10c4297249`. Для проверки достижимости budget-гипотезы, не полное исполнение. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/async_executor.py).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
