<a id="bundle-res-03"></a>

# RES-03 — Сохранение частичного результата через последующий отказ

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B13**. Локальный класс: **L**. Укрупнённая приёмка: **K2**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** CYC-02, CMP-01. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** На существующих границах сохранять завершённые численные артефакты и точную ошибку следующего этапа. В async-chain включить успешных независимых соседей в доступное представление частичного результата без ложного успеха всей цепи.

**Минимальные различающие проверки.** После настоящего численного producer следующий узел падает: предыдущий результат читается повторно со scope и error. A success/B fail сохраняет A. Нарушение общего основания отзывает зависимые выводы, а независимая техническая ошибка не стирает всё.

**Не менять / не считать исправлением.** Не создавать второй журнал истории и не менять общий terminal на success ради частичного результата.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_res_03.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T3. **Cross-boundary review:** X04. **Activation rules:** общие правила scope/приёмки.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/runtime/quality/generation_cycle.py` |
| Production write candidate | `policy-engine/src/polisyos/scientist/orchestration/workflows/engine_simple.py` |
| Production write candidate | `policy-engine/src/polisyos/foundry/methods/backends/async_chain_executor.py` |
| Production write candidate | `policy-engine/src/polisyos/runtime/http/services/control/run_lifecycle.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py` |
| Read / consumer contract | `policy-engine/src/polisyos/core/artifacts/store.py` |

**Не писать одновременно с:** CYC-01, SIM-01, CMP-01, CYC-03, EMP-01, CMP-02, CYC-04, CYC-02, CYC-05. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B13 lines=349-362 sha256=8718ad1c767f83c1f9e5cf47c86e84a80b44005a548d2a109c9d15cc0ebbc799 -->
## B13. Частичный результат должен существовать независимо от успеха следующего этапа

*Источник карточки: A:B13. Унаследовано из прочитанной сводки A; не новый интеграционный прогон.*

**Происхождение и подтверждение:** P1/P2; код. `SimpleLoopEngine.run_async` передаёт исключение наружу; итоговый объект цикла собирается после последовательности. Обработчик задания может завершить job как failed без общего согласованного представления частичного результата. При этом независимое сохранение исходных объектов N4 уже присутствует. [A.R12; A.R04: 2820–2965, 3580–3700; A.R07: 3320–3500]

**Экономное расширение:** на существующих границах генерации, симуляции и оценивания сохранять завершённые артефакты и ссылки на причину последующей остановки. При повторе использовать завершённое содержимое, если его зависимости действительны. Не создавать вторую систему истории.

**Критерий:** после реальной симуляции следующий этап падает; пользователь читает корректный результат симуляции, область его использования и ошибку этапа. Нарушение общего основания отзывает зависимые выводы; независимый локальный сбой не уничтожает всё.

**Ограничение и приоритет:** прежний тезис «всё теряется» был бы слишком сильным и не принят. Проверяется гарантия частичного итогового представления, а не отсутствие любых CAS-записей. Высокое влияние, средняя сложность.

**Расширение C03.** В AsyncChainExecutor._execute_level successes собираются, но при любом node_error поднимается объект, несущий только node_errors, до возврата level_results. Поэтому успешный независимый сосед не попадает в normal return цепочки. Локальный gather-контроль подтвердил успешное значение до такого raise, не сохранность всех проектных артефактов. Применить ту же стратегию B13: сохранить успешные узлы и границы зависимостей, не маскируя общий сбой. [N02]

<!-- END_SOURCE_CARD B13 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**A.R04, L.S03, L.S04, L.S05, L.S06, L.S08, L.S11, L.S12, L.S13, L.S18, L.S19, L.S20, L.S21, L.S22, L.S24, L.S25.** `runtime/quality/generation_cycle.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/runtime/quality/generation_cycle.py). 255–415; 1000–1830; 1920–2965; 3210–4170; 4460–4660; Прочитанные участки исходника; не запуск модуля

**A.R07, L.S02.** `runtime/http/services/control/run_lifecycle.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/runtime/http/services/control/run_lifecycle.py). ветвь natural_language_run; 3040–3500; compile_and_run_recursive_generation_cycle; Прочитанные участки исходника; не запуск модуля

**A.R12, L.S15.** `scientist/orchestration/workflows/engine_simple.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/workflows/engine_simple.py). 1–100; Прочитанные участки исходника; не запуск модуля

**N02.** `foundry/methods/backends/async_chain_executor.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/backends/async_chain_executor.py). 1–конец полученного файла

**C06.R01. Scientist: checkpoint, delta, фиксация и materialize.** `policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py`. Окна чтения: 1–250, 360–700, 975–1250, 1420–1750. Git blob SHA: `dd90c9121de3e14b7ea2ff8db4781fa3ef750334`. Типы, scope, hook, delta, создание и материализация checkpoint; не полный аудит файла. [Закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py).

**C06.R02. Scientist: resume и остаточный workflow.** `policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py`. Окна чтения: 975–1120, 1760–2070. Git blob SHA: `dd90c9121de3e14b7ea2ff8db4781fa3ef750334`. Pruning, fingerprint и resume; последнее окно до конца полученного файла. Повтор того же blob, а не второй независимый источник. [Закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py).

**C14.R02. FileSystemCAS: dedup, ref, чтение, lock-map и вызывающие обёртки.** `policy-engine/src/polisyos/core/artifacts/store.py`. Окна чтения: 175–302, 300–700, 700–1030. Локально сохранены выбранные тела; полный blob не заявлен. Git blob `76cc3574f2bbbb102f47111872ac31f131c253fe`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/core/artifacts/store.py).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
