<a id="bundle-res-04"></a>

# RES-04 — Точный Foundry checkpoint и неизменяемые sidecars

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B74, B75, B76**. Локальный класс: **N**. Укрупнённая приёмка: **K2**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** CMP-02. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Связать checkpoint с effective plan/inputs/params/seed и occurrence-prefix. Сохранить настоящие per-node results с исходной reproducibility. Публиковать JSON и sidecars как новое immutable поколение, используя однозначное кодирование путей.

**Минимальные различающие проверки.** Цепочка multiply/add: changed factor/input не принимает прежний результат 7 вместо холодный результат 10/9. Выходы 6/7 после resume остаются 6/7, исходный seed сохраняется. a_b и a→b сохраняют разные массивы; ошибка нового save после sidecar не портит старый snapshot. Tiny NumPy-файлы, без больших массивов.

**Не менять / не считать исправлением.** Не подставлять final_state в каждый исторический MethodResult, не переписывать старые массивы до публикации нового манифеста и не вводить второй канонизатор.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_res_04.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T6. **Cross-boundary review:** X01, X04, X14. **Activation rules:** A06.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/foundry/methods/backends/checkpointing.py` |
| Production write candidate | `policy-engine/src/polisyos/foundry/methods/backends/chain_executor.py` |
| Read / consumer contract | `policy-engine/src/polisyos/foundry/methods/components/composer.py` |
| Read / consumer contract | `policy-engine/src/polisyos/foundry/methods/compiler/__init__.py` |
| Read / consumer contract | `policy-engine/src/polisyos/core/artifacts/store.py` |

**Не писать одновременно с:** CMP-01, CMP-02. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B74 lines=1939-1952 sha256=8d9049975bdf678761aab8dbf7f9b2e3fa2aa4dabda2d6c2fd9a2d2c6ba5a88b -->
## B74. Foundry checkpoint идентифицирует список методов, но не эффективное вычисление

**Происхождение:** C06-05. **Основание:** `_compute_chain_digest`, `CheckpointingChainExecutor.execute`, `ChainCheckpoint`; R74-1–R74-4. **Приоритет:** высокий при использовании этого resume-пути; M. [C06.R06]

**Проблема.** Digest строится только из упорядоченного списка FQN. Параметры узлов, params_per_node, seed, исходное состояние, slot bindings и эффективные зависимости в него не входят. При совпавшем digest исполнитель заменяет initial_state сохранённым intermediate_state и пропускает первые n_completed узлов. Соответствие completed_node_ids текущему префиксу отдельно не проверяется в этой ветви.

**Воспроизведение.** Исполнено извлечённое тело execute с простыми тестовыми MethodResult/registry/dispatcher. Цепочка «умножить на 2, прибавить 1» на x=3 имеет промежуточный результат 6. При изменении множителя на 3 холодный расчёт даёт 10, а resume по старой точке — 7. При изменении initial x на 4 холодный результат 9, resume — 7. Новый граф с теми же FQN и другими UUID принимает старые ID завершённого префикса. Смена порядка FQN корректно отвергается — существующий digest не бесполезен, но его область слишком узка для полного обещания совместимости.

**Рекомендуемое решение.** Использовать существующую функциональную идентичность скомпилированного плана и эффективных входов: параметры после разрешения defaults/overrides, slot bindings, зависимости, версии методов и модельного контекста, исходные артефакты, смысл случайного seed/повторения. Не выдумывать второй несовместимый канонизатор, а согласовать checkpoint с действующими контрактами composer/dispatcher. Идентичность появления узла и его место в сохранённом рубеже должны быть проверяемы.

Изменение только расписания или допустимого operational-timeout не обязано уничтожать численный reuse; изменение научного параметра обязано инвалидировать зависимую работу. В сложном случае следует повторно использовать незатронутые предки по графу зависимостей, а не отвергать весь корпус и не принимать весь прежний результат. Полный хэш огромного input не нужно вычислять заново, если есть настоящая связанная immutable artifact identity.

**Приёмка.** Тёплый и холодный результат совпадают для одного эффективного запроса. Смена параметра, seed, входного снимка, порядка/семантики binding либо версии метода либо отвергает старую точку, либо даёт явный план частичного пересчёта. Неверный completed-prefix не принимается. Это тест данного Foundry executor, не утверждение о неправильности всех кэшей и всех других checkpoint-контуров.

<!-- END_SOURCE_CARD B74 -->

<!-- SOURCE_CARD B75 lines=1953-1968 sha256=25d5059a21fb186c9825ac2fde8cb74cd29c692834f2ddd5614c99dfc84d0b74 -->
## B75. При восстановлении итоговый state выдаётся за результат каждого прежнего узла

**Происхождение:** C06-06. **Основание:** восстановление stub_result и последующая сборка ChainExecutionResult; R75-1–R75-3. **Приоритет:** высокий перед использованием per-node history; M. [C06.R06, C06.R10]

**Проблема.** Checkpoint хранит общий intermediate_state, список методов/UUID и timing. На resume для каждого прежнего узла создаётся MethodResult с `output=dict(state)`, где state — один и тот же итог всего сохранённого префикса. Исходные результаты отдельных методов не восстанавливаются. ReproducibilityInfo также создаётся заново по нынешнему runtime и переданному сейчас seed, а не по сохранённым условиям той попытки.

В тестовой цепочке настоящие выходы двух узлов равны 6 и 7; восстановленные MethodResult содержат 7 и 7. Настоящих новых dispatch-вызовов не было. Сохранённый расчёт выполнялся с seed=7, а при resume с seed=99 восстановленные metadata записали 99 и fingerprint тестового текущего окружения. Итоговый state при неизменном запросе при этом остаётся верным — проблема относится к потере и последующему восстановлению истории.

**Важный существующий сигнал.** Код добавляет warning и note `restored_from_checkpoint`. Поэтому не утверждается, что восстановление вообще скрыто. Но предупреждение не возвращает отсутствующий исходный output и не делает нынешний fingerprint историческим. А построитель общего reproducibility_contract читает данные из этих MethodResult; конкретный последующий authority-потребитель и ложная публикация не воспроизведены.

**Рекомендуемое решение.** Сохранять ссылки на настоящие per-node MethodResult, их исходные inputs, outputs и reproducibility metadata. Общий resume-state хранить отдельно. Если старый формат не содержит node-output, возвращать явную неполноту истории, не подставляя финальное состояние как произведённое каждым методом. Данные нового сеанса чтения — отдельная запись replay, не переписывание оригинального исполнения. Ранее полученные warnings, ошибки, артефакты и ограничения не должны исчезать.

**Почему это связано с производительностью.** Имея точные выходы и зависимости, можно повторно использовать отдельный дорогой шаг и пересчитать только следующий. Общий state без верной истории провоцирует либо небезопасный reuse, либо дорогое повторение всего префикса. Нативные immutable refs предпочтительнее многократной сериализации одинакового полного state.

**Приёмка.** После resume выход A остаётся 6, B — 7; исходные seed/runtime/версия сохраняются; новый replay не записывается как новое независимое вычисление. Для legacy-точки без этих данных отсутствующее явно отсутствует. Доступ к final_state остаётся возможным в его подтверждённой области.

<!-- END_SOURCE_CARD B75 -->

<!-- SOURCE_CARD B76 lines=1969-1984 sha256=36a6087dde2ea2e4d90a2e063141b4f2d583e20fa62214997bed2eea192d315e -->
## B76. Идентичность sidecar-файлов не обеспечивает целостность всего checkpoint

**Происхождение:** C06-07. **Основание:** `_serialise_state`, save/load, атомарные файловые helpers; R76-1–R76-4. **Приоритет:** высокий для численных checkpoint; S–M. [C06.R06, C06.E01]

**Коллизия внутри одного снимка.** Имя массива строится конкатенацией stem и имён ключей через `_`. Пути `['a_b']` и `['a','b']` получают одинаковое имя `stem_a_b.npy`. При объединении sidecars последняя запись заменяет первую, а обе ссылки указывают на один файл. В настоящем локальном save/load двух массивов [1] и [2] прочитаны [2] и [2]. Это не коллизия SHA-256 и не теоретически редкое событие: это неоднозначное кодирование пути.

**Смешение поколений при сбое.** Save атомарно заменяет каждый sidecar по отдельности, затем сериализует и публикует JSON. Если запись идёт по тому же checkpoint path, старые sidecars могут быть заменены до успешной публикации нового JSON. В тесте новая запись массива [2] состоялась, а JSON-сериализация другого значения в списке завершилась ошибкой. Старый JSON остался побайтово прежним, но при чтении прежнего checkpoint вернулся новый массив [2] вместо [1]. Сценарий использует намеренно неподдерживаемое новое значение для проверки отказоустойчивости; ошибка нового save не должна портить ранее валидный снимок.

Внешний `_save_checkpoint` использует секунды времени, сокращённый digest и индекс узла для имени. Поэтому повторная запись того же шага в тот же каталог не имеет универсальной гарантии уникального поколения. При разных путях снимков отрицательный контроль сохранил старый массив. Произошедшая production-порча не заявляется.

**Рекомендуемое решение.** Адресовать массивы по однозначному структурному пути плюс поколению или по настоящему content-addressed ref. Опубликовать сначала весь новый неизменяемый набор данных, проверить его, затем атомарно переключить единственный manifest/head. Не перезаписывать файлы, на которые ещё ссылается предыдущий manifest. Использовать существующий CAS, когда этот путь допустим, либо отдельный generation-directory; валидировать также shape/dtype/content и безопасный путь разрешения sidecar.

Атомарная замена отдельного файла не является транзакцией над JSON и всеми массивами. fsync и rename уже используются — их не надо изобретать заново; нужно правильно определить объект публикации. Garbage collection удаляет только действительно недостижимые поколения после фиксации, а не при неудачной попытке сохранения.

**Приёмка.** Плоский ключ с подчёркиванием и вложенный путь сохраняют разные массивы; перестановка ключей не меняет данные. Сбой после записи любого sidecar оставляет доступным полный старый либо полный новый снимок, не смесь. Контроль включает одновременные писатели, повтор того же шага, отсутствие и повреждение файла. Тесты C06 исполнили извлечённые методы save/load с реальными JSON/NumPy/filesystem, но не весь проектный ArtifactStore.

<!-- END_SOURCE_CARD B76 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**N01.** `foundry/methods/backends/chain_executor.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/backends/chain_executor.py). 1–1085

**N03.** `foundry/methods/components/composer.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/components/composer.py). 1–конец полученного файла

**C04.K01. MethodCompiler / CompilationCache / compile_chain.** `policy-engine/src/polisyos/foundry/methods/compiler/__init__.py`. 1–560; compile_chain, warmup, CompiledChainExecutor и конец файла из запроса 550–805. Git blob: `9d8e6bfd44ef24aeb66faed7f9fbf9c218e912be`. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/compiler/__init__.py).

**C06.R06. Foundry: цепочка с файловыми checkpoints.** `policy-engine/src/polisyos/foundry/methods/backends/checkpointing.py`. Окна чтения: 1–300, 300–620. Git blob SHA: `e0e03603478db6853912f2eb3a68f9e1fcab2145`. Получен полный файл до конца; digest, execute, stubs, save/load, sidecars, atomic writes. В probes исполнены извлечённые тела с фикстурами. [Закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/backends/checkpointing.py).

**C06.R10. Foundry: per-node результаты и их воспроизводимость.** `policy-engine/src/polisyos/foundry/methods/backends/chain_executor.py`. Окна чтения: 1–230. Git blob SHA: `82a8a146658bfd7ee7a54434a76215fdbded09d9`. ChainExecutionResult и _build_chain_reproducibility_contract; потребление metadata результатов, не запуск агрегатора. [Закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/backends/chain_executor.py).

**C14.R02. FileSystemCAS: dedup, ref, чтение, lock-map и вызывающие обёртки.** `policy-engine/src/polisyos/core/artifacts/store.py`. Окна чтения: 175–302, 300–700, 700–1030. Локально сохранены выбранные тела; полный blob не заявлен. Git blob `76cc3574f2bbbb102f47111872ac31f131c253fe`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/core/artifacts/store.py).

**C06.E01. Python: atomic replace и fsync.** Гарантия замены отдельного имени файла; сама по себе не групповая транзакция JSON и массивов. [Закреплённый источник](https://docs.python.org/3.14/library/os.html#os.replace).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
