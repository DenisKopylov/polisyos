<a id="bundle-run-02"></a>

# RUN-02 — Доставка результата через процессную границу

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B24**. Локальный класс: **N**. Укрупнённая приёмка: **K2**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** RUN-01. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Исправить join-before-drain: контролируемо читать канал параллельно живучести либо передавать маленькую существующую artifact-ref. Разделить compute и delivery timeout; согласовать выбранный процессный старт и cleanup с macOS.

**Минимальные различающие проверки.** В отдельном тестовом процессе маленький результат и 1MiB доставляются без ложного timeout. Compute timeout прекращает только принадлежащее тесту вычисление; сбой отправки не публикует success. Проверить сериализацию и отсутствие висящих собственных потомков после завершения.

**Не менять / не считать исправлением.** Не запускать большой payload во множестве агентов. Не менять fork на spawn одним словом без сериализации/владения; не заявлять Linux/Ray/Temporal coverage по Mac-тесту.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_run_02.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T3. **Cross-boundary review:** I2 по фактическим consumers. **Activation rules:** общие правила scope/приёмки.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/scientist/orchestration/engine/retry.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/orchestration/engine/runner/serialization.py` |
| Read / consumer contract | `policy-engine/src/polisyos/common/async_tools.py` |

**Не писать одновременно с:** RUN-01, RUN-03. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

**Связанные карточки для адресного чтения, не второе назначение:** B14 → RUN-01.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B24 lines=489-502 sha256=ae15e81cc6f82a0cf31bfd1a4689724b00bd3fdae45748292a8735108acc9ec1 -->
## B24. Готовый большой результат может выглядеть как зависший вычислитель

*Источник карточки: A:B24. Унаследовано из прочитанной сводки A; не новый интеграционный прогон.*

**Подтверждение:** код, официальная документация Python и P06. В обоих процессных timeout-путях сначала ожидается завершение дочернего процесса, затем читается multiprocessing.Queue. Дочерний процесс передаёт model_dump результата. При большом сообщении завершение отправки может ждать чтения родителем, который ждёт завершения ребёнка. [A.R11: 335–445; A.E01]

В локальном опыте с 64 байтами процесс завершился. С 1 MiB тело работы завершилось, но после ожидания 0,6 с процесс оставался жив, результат не получен. При чтении очереди до join те же 1 MiB доставлены, процесс завершился примерно за 0,004 с. Это воспроизведение механизма на стандартной библиотеке, не запуск реального метода PolicyOS.

**Экономное расширение:** ограниченно читать канал одновременно с контролем живучести; либо хранить объёмный результат через подходящий существующий artifact store и передавать небольшой проверяемый указатель. Различать compute timeout и delivery timeout. Не увеличивать время ожидания как основной ремонт.

Дополнительно wrapper явно использует fork и daemon=True. В многопоточном окружении и для методов, создающих дочерние процессы, это отдельные проверяемые ограничения. Переход на spawn/forkserver требует корректной сериализации и владения ресурсами, а не замены одного слова. Принудительная остановка не должна оставлять подтверждённые наполовину записи.

**Критерий:** малый и большой результаты возвращаются; compute timeout действительно прекращает работу; авария во время отправки не создаёт успешный receipt. Проверяются очистка и точка фиксации результата. Высокое влияние и средняя сложность; существенная поправка к B14.

<!-- END_SOURCE_CARD B24 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**A.R10, L.S16, C.Q10.** `common/async_tools.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/common/async_tools.py). полный проектный модуль из предыдущего пакета; Полный модуль из прежнего пакета; в новом проходе совпадение Git blob SHA проверено и короткие задачи выполнены; [[1, 155]]

**A.R11, L.S17, C.Q09.** `scientist/orchestration/engine/retry.py`. [Открыть закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/retry.py). 310–445; связанные timeout wrappers; Прочитанные участки исходника; не запуск модуля; [[1, 326], [450, 640]]

**C08.R05. State/outcome wire serialization и начало context meta.** `policy-engine/src/polisyos/scientist/orchestration/engine/runner/serialization.py`. Запрошенные окна: 1–295, для короткого файла — до конца. Git blob `f9ddcccfbc8c53c994d74420270b260a560549df`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/runner/serialization.py).

**C08.R07. Retry и timeout: sync, process и async пути.** `policy-engine/src/polisyos/scientist/orchestration/engine/retry.py`. Запрошенные окна: 1–690, для короткого файла — до конца. Git blob `06902d221fc02ef85fc4d1b8fdb69a590bb50e30`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/retry.py).

**C08.R08. Существующие мосты с copy_context.** `policy-engine/src/polisyos/common/async_tools.py`. Запрошенные окна: 1–230, для короткого файла — до конца. Git blob `01981db2ccbbb39ab54d2afa6ef3dafafcb0e3c0`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/common/async_tools.py).

**L.E01, A.E01.** `Python: multiprocessing, очереди и завершение процессов`. [Открыть закреплённый источник](https://docs.python.org/3/library/multiprocessing.html). Прочитаны предупреждения о join до чтения очереди. Использовано только для объяснения механизма F24.

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
