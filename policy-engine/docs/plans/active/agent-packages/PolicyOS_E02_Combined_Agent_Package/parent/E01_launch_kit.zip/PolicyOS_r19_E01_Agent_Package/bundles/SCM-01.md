<a id="bundle-scm-01"></a>

# SCM-01 — Наблюдаемые корни и выполняемый nonlinear payload

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B221, B222**. Локальный класс: **N**. Укрупнённая приёмка: **K5**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** GRF-02. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** При fit сохранить необходимый наблюдаемый закон корней или явный источник/неизвестность. Согласовать family payload от fitting до query/twin; для уже сохранённого простого polynomial формата выполнить именно его, не linear surrogate с чужим маленьким residual noise.

**Минимальные различающие проверки.** Y=3T+2Z, Z=99/101, do(T=1) даёт условное среднее около 203, не 3. y=x² при x=2 выполняет 4, не 1.36 с почти нулевым noise. LINEAR y=1+3x остаётся 7. Неинтервенируемые зависимые корни сохраняют joint relation; недостающий корень не становится тайным N(0,1).

**Не менять / не считать исправлением.** Не изобретать данные корня и не выдавать warning за исправление закона. Generic polynomial support не означает автоматическую работу любого нелинейного abduction.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_scm_01.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T21. **Cross-boundary review:** X07, X11. **Activation rules:** общие правила scope/приёмки.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_fit.py` |
| Production write candidate | `policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_query.py` |
| Production write candidate | `policy-engine/src/polisyos/foundry/methods/catalog/causal/twin_network_query.py` |
| Production write candidate | `policy-engine/src/polisyos/ir/analytics/structural_causal_model.py` |
| Read / consumer contract | `policy-engine/src/polisyos/ir/analytics/causal_graph.py` |
| Read / consumer contract | `policy-engine/src/polisyos/ir/analytics/uncertainty.py` |

**Не писать одновременно с:** GRF-03, SCM-02, SCM-03. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B221 lines=5403-5416 sha256=e22ca23d5d49e736162b73f80d43ae77719ada061f0898f1ba083a31e54943e4 -->
## B221. Fitting игнорирует наблюдаемые корни, а query придумывает для них стандартный Normal

**Происхождение и приоритет:** C21-06. Высокий для fit→query при неинтервенируемых наблюдаемых корнях. Основания: HybridSCMFit root-skip, SCM-validator и missing-mechanism sampler. [C21.R04–R06]

**Проблема.** `HybridSCMFit.pure_step` пропускает вершины, не входящие в множество non-roots. Общий `StructuralCausalModelSpec` требует механизмы только для некорневых узлов. Query при отсутствии механизма генерирует N(0,1) и пишет warning. Наличие данных корня на входе fit не приводит к их сохранению в выполняемой модели.

**ROOT01–ROOT02.** Для T→Y, Z→Y данные удовлетворяют Y=3T+2Z, Z принимает 99 и 101 со средним 100. OLS дочернего узла правильно восстанавливает коэффициенты 3 и 2. Уменьшенный driver повторяет обычную observed/no-prior ветвь и сохраняет только механизм Y. При do(T=1) query генерирует Z со средним 0,007724 и получает среднее Y=3,015448 вместо ожидаемого около 203. Добавление существующего EMPIRICAL-контракта корня с mean100/std1 с теми же случайными реализациями даёт 203,015448. Дочерний OLS не меняется.

**Исправление.** При сборке модели определить покрытие всех необходимых для запроса корней: наблюдаемый закон, фактическое условие, явно выбранная внешняя модель или нерешённый пробел. Для доступных данных переиспользовать существующие carriers/ссылки, а не терять их и затем изобретать default. Совместный закон нескольких корней сохраняется там, где он требуется; независимость не возникает из раздельного хранения.

Missing-root default может быть полезной гипотезой в явно объявленной исследовательской модели. Он не эквивалентен fitted distribution. При наличии такого предположения оно входит в идентичность результата и ограничивает его применение. Глобально запрещать partial SCM не требуется.

**Граница.** Полный HybridSCMFit/DoWhy не запускался: использован явно сокращённый driver DATA_FITTED-ветви и выбранный query-loop. Warning существует; ошибку нельзя называть полностью скрытой. Явное вмешательство или наблюдаемое условие, полностью определяющее корень, может исключить потребность в его естественном законе для конкретного запроса.

<!-- END_SOURCE_CARD B221 -->

<!-- SOURCE_CARD B222 lines=5417-5430 sha256=b13339d3c9e2d80995027a0f1acbaf09ccad855a643deb0b283c065bc4232aa5 -->
## B222. Сохранённый полином исполняется как линейная аппроксимация с шумом от более точной модели

**Происхождение и приоритет:** C21-07. Высокий при использовании ADDITIVE_NOISE/poly-пакета; условная достижимость. Основания: `_fit_additive_noise_poly`, `_sample_node_value`, аналогичный twin-helper. [C21.R04–R05, C21.R07]

**Проблема.** Fitter сохраняет и линейные коэффициенты, и полиномиальную модель. `noise_std` берётся из остатков полиномиального fit. Query для ADDITIVE_NOISE меняет family на LINEAR и использует линейные коэффициенты вместе с этой новой, потенциально очень малой дисперсией. Warning о fallback присутствует, но численный закон уже другой.

**POLY01–POLY02.** На 101 точке x∈[−2,2], y=x² сохранённый полином даёт при x=2 значение 4 с точностью floating-point. Query выдаёт 1,36 со стандартным шумом около 4,9×10⁻¹⁶. Иными словами, аппроксимация с большим смещением исполняется почти детерминированно. Положительный LINEAR-контроль y=1+3x даёт 7 при x=2.

**Исправление.** Один выполняемый контракт family для fit, sampling, abduction и twin-world. Первое недорогое расширение — корректный evaluator уже сохраняемого полиномиального формата без cross-terms; сложные семейства можно оставить с явной недоступностью или обозначенной аппроксимацией. Если используется линейный surrogate, его расхождение и шум оцениваются для surrogate, а не заимствуются из другой модели.

Не следует добавлять произвольный большой шум, считать warning коррекцией значения или запрещать все nonlinear-модели. Поддерживаемый ограниченный полином уже содержит достаточно информации для точного исполнения своего заявленного семейства.

**Область.** В прочитанной стандартной observed-data ветви HybridSCMFit выбирает LINEAR, а автоматический вызов polynomial-helper оттуда не установлен. Поэтому это дефект совместимости подготовленного payload/helper с публичным query, не утверждение, что каждый обычный GCM-fit автоматически обучает и теряет полином. Полный native pipeline и контрфактическая инверсия нелинейного шума не выполнялись.

<!-- END_SOURCE_CARD B222 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**C19.R06. IR carriers, numerical validator и joins.** `policy-engine/src/polisyos/ir/analytics/uncertainty.py`. Окна чтения: 460–1080; 1180–1575; файл мог быть короче окна. Локально — помеченные выбранные определения; это не полный исходный файл. Git blob `0a2495855d707a6548da6983bdef9abed9c4b0c7`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/ir/analytics/uncertainty.py).

**C20.R09. Marks, graph types и валидация DAG.** `policy-engine/src/polisyos/ir/analytics/causal_graph.py`. Окна чтения: 1–280; файл мог быть короче окна. Прочитано как кодовое основание/контроль области, не исполнялось в production-окружении. Git blob `ddad43aba1e6eff00f3440f4ce4bb23162a48b18`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/ir/analytics/causal_graph.py).

**C20.R10. GCM-fit использует projection перед fitting.** `policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_fit.py`. Окна чтения: 1–285; 310–410; файл мог быть короче окна. Прочитано как кодовое основание/контроль области, не исполнялось в production-окружении. Git blob `43b183049b678aa7d82afbfc1d07261f9373faa7`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_fit.py).

**C20.R11. GCM query: traversal, abduction и simulation.** `policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_query.py`. Окна чтения: 1–735; файл мог быть короче окна. Локально сохранены выбранные определения с помеченными импортами; это не полный Git blob. Git blob `b21fbb1b911415125f401390dacc335e925f7b93`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_query.py).

**C21.R01. Контракт графа, lag-validation и адаптеры/кэшированные строки.** `policy-engine/src/polisyos/ir/analytics/causal_graph.py`. Окна чтения: 1–430; файл мог быть короче окна. Локально — выбранные определения и явно помеченные фикстуры, не полный Git blob. Git blob прочитанного источника `ddad43aba1e6eff00f3440f4ce4bb23162a48b18`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/ir/analytics/causal_graph.py).

**C21.R04. SCM-fit: пропуск корней и полиномиальные family-params.** `policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_fit.py`. Окна чтения: 65–148; 340–610; файл мог быть короче окна. Локально — выбранные определения и явно помеченные фикстуры, не полный Git blob. Git blob прочитанного источника `43b183049b678aa7d82afbfc1d07261f9373faa7`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_fit.py).

**C21.R05. SCM-query: family dispatch, sampling, intervention и attribution.** `policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_query.py`. Окна чтения: 105–335; 472–580; 700–900; файл мог быть короче окна. Локально — выбранные определения и явно помеченные фикстуры, не полный Git blob. Git blob прочитанного источника `b21fbb1b911415125f401390dacc335e925f7b93`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_query.py).

**C21.R06. Структурный SCM-контракт и требование покрытия некорневых узлов.** `policy-engine/src/polisyos/ir/analytics/structural_causal_model.py`. Окна чтения: 1–290; файл мог быть короче окна. Прочитано для анализа вызовов/контракта; этот полный компонент не исполнялся. Git blob прочитанного источника `461205bb1e831023744321c60a585a67f3928373`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/ir/analytics/structural_causal_model.py).

**C21.R07. Соседний twin-world: общие шумы и обход natural treatment.** `policy-engine/src/polisyos/foundry/methods/catalog/causal/twin_network_query.py`. Окна чтения: 1–260; файл мог быть короче окна. Прочитано для анализа вызовов/контракта; этот полный компонент не исполнялся. Git blob прочитанного источника `cc6fd2a51233e0a41d4d321f6214ce51e855fd62`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/catalog/causal/twin_network_query.py).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
