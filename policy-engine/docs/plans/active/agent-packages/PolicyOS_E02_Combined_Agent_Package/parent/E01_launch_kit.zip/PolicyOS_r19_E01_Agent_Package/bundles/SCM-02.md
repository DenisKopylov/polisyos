<a id="bundle-scm-02"></a>

# SCM-02 — Factual abduction и две явные стороны attribution

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B215, B223**. Локальный класс: **N**. Укрупнённая приёмка: **K5**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** SCM-01. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Отделить фактически наблюдённых родителей от model-imputed values. Для поддержанного linear-Gaussian partial evidence использовать условный закон noises; полный invertible factual input сохраняет точную residual-инверсию. Явно представить target и comparator, различив no-override и observational baseline.

**Минимальные различающие проверки.** X=Ux, Y=X+Uy, evidenceY=2, doX=0 даёт mean=1/variance=0.5 в поддержанном Gaussian-контроле, а полное X=1, Y=2 —Y(0)=1. Для Y=1+3X targetX=2/baselineX=0 контраст 6, не 0; одинаковые явные стороны дают 0. Shared-U и независимые межмировые выборки не смешиваются.

**Не менять / не считать исправлением.** Не считать подставленное среднее наблюдением, не подменять counterfactual обычным intervention и не трактовать None одновременно как наследование и отмену.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_scm_02.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T20, T21. **Cross-boundary review:** X07, X11. **Activation rules:** A07.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_query.py` |
| Production write candidate | `policy-engine/src/polisyos/ir/analytics/causal_queries.py` |
| Production write candidate | `policy-engine/src/polisyos/foundry/methods/catalog/causal/twin_network_query.py` |
| Read / consumer contract | `policy-engine/src/polisyos/ir/analytics/structural_causal_model.py` |

**Не писать одновременно с:** GRF-03, SCM-01, SCM-03. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B215 lines=5230-5243 sha256=285a9f3f9267aaf97e7844c252fffd271febbc5cfb5212bcbbdefd7252f119a9 -->
## B215. Абдукция принимает подставленное среднее скрытого родителя за наблюдённый факт

**Приоритет:** высокий для контрфактуала с неполным factual context; точный линейно-Gaussian путь возможен без универсального sampler. **Основание:** _abduce_linear_noises и _simulate_samples; CF01–CF03. [C20.R11–R12, C20.E05]

**Проблема.** Перед восстановлением шума ненаблюдаемые узлы заполняются линейным предсказанием или нулём. Проверка all(parent in pseudo_observed) затем считает их известными и вычисляет один residual для наблюдённого потомка. При counterfactual simulation этот residual фиксируется вместо условного распределения экзогенных переменных.

**Воспроизведение.** SCM: X=Ux, Y=X+Uy, независимые Ux,Uy~N(0,1). Factual evidence содержит только Y=2, запрос do(X=0). Точный Gaussian conditioning даёт Uy|Y=2 со средним 1 и дисперсией 0,5. Исходная абдукция подставила X=0, восстановила Uy=2; 100 контрфактических реализаций дали среднее 2 и дисперсию 0. При полном наблюдении X=1,Y=2 контроль правильно даёт детерминированный Y(0)=1.

**Рекомендуемое исправление.** Различать фактически наблюдённых родителей и модельно восстановленные значения. Когда invertible-механизм и все необходимые factual inputs действительно известны, использовать существующую точную residual-инверсию. В линейно-Gaussian случае с неполным наблюдением решать условную Gaussian-задачу; в общем случае нужна явная поддержанная posterior-abduction либо ограничение соответствующего контрфактуала. Фиксировать одну и ту же posterior-noise реализацию для сравниваемых миров и хранить её происхождение.

**Экономия.** Для линейного случая условную факторизацию можно подготовить один раз для заданного observation pattern и модели, затем переиспользовать векторизованные реализации. Увеличение числа draws исходного детерминированного residual только повторит неверную точку. Не нужно запрещать все counterfactuals либо подменять factual-condition обычным intervention-запросом.

**Граница.** Исполнены выбранные настоящие traversal/abduction/sample-loop тела, но механизм ограничен явно тестовым LINEAR/ATOMIC backend и небольшими DTO. Полные GCMQuery/twin-network, проверка идентификации SCM, native query-result и CAS не запускались. Формула контрольного Gaussian-conditioning рассчитана напрямую; это не inference из реальных социальных данных.

<!-- END_SOURCE_CARD B215 -->

<!-- SOURCE_CARD B223 lines=5431-5444 sha256=2f7406d0704ebafed25947c6ebdc6e7e910da062e19fc8b62aed081343ffefcf -->
## B223. Attribution вычитает одно и то же вмешательство из самого себя

**Происхождение и приоритет:** C21-08. Высокий; локальная правка интерфейса режима. Основания: ветвь ATTRIBUTION и `_simulate_samples`/`_effective_intervention`. [C21.R05]

**Проблема.** Основная attribution-ветвь передаёт целевое intervention. Для baseline передаётся `intervention_override=None`, но query остаётся INTERVENTIONAL с прежним treatment_value. В sampler None означает «взять эффективное вмешательство из query», а не «не вмешиваться». Оба вычисления поэтому получают один do-режим.

**ATTR01.** В детерминированной модели Y=1+3X и запросе X=2 все сто treated- и baseline-реализаций имеют X=2, Y=7. Средний контраст равен нулю. Явный baseline do(X=0) даёт правильный контраст 6. Проверены две настоящие выбранные ветви вызова, а не native CausalQueryResult или registry.

**Исправление.** Разделить отсутствие override, явный observational-режим и явное альтернативное вмешательство. Лучше представлять две разрешённые стороны контраста отдельно: целевой режим, baseline, популяция, исход и соответствующее состояние мира. Значение `None` не должно одновременно обозначать «унаследовать» и «отменить» действие.

После этой правки нужно сохранить смысл статистики: разность средних независимых межмировых выборок и распределение индивидуальных эффектов с общими U — разные объекты. Уже существующий twin-network реализует shared-noise путь; его можно использовать при соответствующих предпосылках, а не строить новый движок.

**Приёмка.** Известный ненулевой линейный эффект, одинаковые явно заданные режимы с нулевым контрастом, observational baseline и стохастическая политика с определённым сравнением. Сохранять оба query-ref в результате. Исправление не устанавливает, что конкретное вмешательство эмпирически идентифицировано: оно делает исполняемый контраст соответствующим запросу.

<!-- END_SOURCE_CARD B223 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**C20.R11. GCM query: traversal, abduction и simulation.** `policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_query.py`. Окна чтения: 1–735; файл мог быть короче окна. Локально сохранены выбранные определения с помеченными импортами; это не полный Git blob. Git blob `b21fbb1b911415125f401390dacc335e925f7b93`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_query.py).

**C20.R12. Factual context и типизированный causal-query.** `policy-engine/src/polisyos/ir/analytics/causal_queries.py`. Окна чтения: 1–220; файл мог быть короче окна. Прочитано как кодовое основание/контроль области, не исполнялось в production-окружении. Git blob `f1b13ceae6e280ac2088c548e2981ec8c69c161b`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/ir/analytics/causal_queries.py).

**C21.R05. SCM-query: family dispatch, sampling, intervention и attribution.** `policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_query.py`. Окна чтения: 105–335; 472–580; 700–900; файл мог быть короче окна. Локально — выбранные определения и явно помеченные фикстуры, не полный Git blob. Git blob прочитанного источника `b21fbb1b911415125f401390dacc335e925f7b93`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_query.py).

**C21.R06. Структурный SCM-контракт и требование покрытия некорневых узлов.** `policy-engine/src/polisyos/ir/analytics/structural_causal_model.py`. Окна чтения: 1–290; файл мог быть короче окна. Прочитано для анализа вызовов/контракта; этот полный компонент не исполнялся. Git blob прочитанного источника `461205bb1e831023744321c60a585a67f3928373`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/ir/analytics/structural_causal_model.py).

**C21.R07. Соседний twin-world: общие шумы и обход natural treatment.** `policy-engine/src/polisyos/foundry/methods/catalog/causal/twin_network_query.py`. Окна чтения: 1–260; файл мог быть короче окна. Прочитано для анализа вызовов/контракта; этот полный компонент не исполнялся. Git blob прочитанного источника `cc6fd2a51233e0a41d4d321f6214ce51e855fd62`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/catalog/causal/twin_network_query.py).

**C20.E05. DoWhy: counterfactuals и фактическое наблюдение.** Первичная документация просмотрена 18 сентября 2026 года. Это основание методологического различения, не доказательство runtime-версии/запуска PolicyOS. [Документация](https://www.pywhy.org/dowhy/main/user_guide/causal_tasks/what_if/counterfactuals.html).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
