<a id="bundle-scm-03"></a>

# SCM-03 — Активный query-plan и сохранённый stochastic law

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B224, B225**. Локальный класс: **N**. Укрупнённая приёмка: **K5**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** SCM-02, GRF-01, GRF-02. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Для perfect intervention подставить действие до заменённого механизма и готовить только действительную область запроса с factual dependencies. Разрешать stochastic law один раз, сохранять тип политики; устойчивый truncated-normal sampler не заменяется clipping после rejection-limit.

**Минимальные различающие проверки.** DoX=2 даёт Y=7 даже если старый natural X не нужен/невычислим; shift=5+2 всё ещё требует естественное 5.20 посторонних корней не вычисляются без запроса full-trace. Typo-law не превращается в atomic=7. Truncnorm[8,9] имеет внутренние значения, не 100 граничных восьмёрок. Логические seeds сохраняются при сужении плана.

**Не менять / не считать исправлением.** Не отсекать нужные factual ancestors/sharedU, не увеличивать rejection-limit вслепую. Atomic fallback — другой отдельно принятый запрос, не успешное завершение исходной stochastic задачи.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_scm_03.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T21. **Cross-boundary review:** X11. **Activation rules:** A07.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_query.py` |
| Production write candidate | `policy-engine/src/polisyos/ir/analytics/causal_queries.py` |
| Read / consumer contract | `policy-engine/src/polisyos/foundry/methods/catalog/causal/admg_ops.py` |
| Read / consumer contract | `policy-engine/src/polisyos/foundry/methods/catalog/causal/twin_network_query.py` |
| Read / consumer contract | `policy-engine/src/polisyos/ir/analytics/causal_graph.py` |

**Не писать одновременно с:** GRF-03, SCM-01, SCM-02. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B224 lines=5445-5458 sha256=854f9eab140c71438e188c91ef3d9792895b0402ab22c5866de3584683596ca1 -->
## B224. Идеальное do сначала выполняет заменяемый механизм; нерелевантные узлы расходуют работу и память

**Происхождение и приоритет:** C21-09. Высокий для проходимости atomic-запроса; оптимизация после проверки графового смысла. Основание: `_simulate_samples` и контраст с twin-path. [C21.R05, C21.R07]

**Проблема.** В каждом прогоне сначала собираются родители и вычисляется естественное значение узла; затем для treatment применяется intervention. Даже идеальное do, полностью заменяющее механизм, поэтому зависит от исправности и стоимости старого механизма. Кроме того, цикл проходит весь граф и сохраняет массивы всех вершин, хотя обычному запросу часто нужен только заданный исход.

**EXEC01–EXEC03.** При do(X=2), Y=1+3X и некорректном старом intercept X sampler поднимает ValueError до применения действия. Вычисление Y с уже заданным X правильно даёт 7. Для X,Y и двадцати независимых посторонних корней на десяти реализациях выполняется 220 вызовов node-sampler и сохраняется 220 значений. Для известного ограниченного запроса достаточно десяти вычислений Y; результат тот же 7. Это число вызовов и удерживаемых значений, не измеренное ускорение большого приложения.

**Исправление.** На основе правильной graph-surgery заранее подготовить активный план конкретного запроса. Для perfect intervention подставлять действие до вызова заменённого механизма. Обрабатывать необходимые предковые зависимости и фактические условия, сохранять full-trace только при действительной потребности. Кэшировать план по неизменяемому графу и семантике запроса, а не по имени outcome без контекста.

Обычный сдвиг требует естественного значения: контроль current5+shift2 даёт7. Поэтому перенос treatment-ветви должен учитывать тип операции. Для counterfactual нельзя отсечь нужных предков factual-evidence, а для зависимых U — скрытые общие причины. Уплотнение плана не должно менять поток случайности незаметно: полезны логические под-потоки по узлу и реплике.

**Положительная граница.** Twin-loop уже не вызывает естественный механизм treatment при явном действии, то есть соседний подход существует. Единичная ошибка старого механизма в опыте допустима в generic fixture; проверка более строгого producer может предотвратить её раньше. Она всё равно показывает ненужную зависимость perfect do от заменяемого вычисления.

<!-- END_SOURCE_CARD B224 -->

<!-- SOURCE_CARD B225 lines=5459-5472 sha256=9fc38772c0cd77e8bb8da7abd1d8423345cf151f598107387b177b4900860879 -->
## B225. Ошибка стохастической политики меняет вмешательство; хвостовой truncnorm превращается в атом

**Происхождение и приоритет:** C21-10. Высокий для заданного стохастического закона; небольшой первый ремонт sampler. Основание: `_sample_stochastic_distribution` и `_apply_intervention`. [C21.R05]

**Проблема.** Ошибка разбора стохастического распределения при наличии fallback_treatment_value приводит к atomic do, хотя исходный InterventionSpec остаётся STOCHASTIC. Записывается warning, но исполняется другая политика. Отдельно truncnorm делает не более 200 rejection-попыток, затем берёт ещё один обычный normal и обрезает его до границ. Ограничение времени разумно; замена условного распределения обрезанным значением — нет.

**LAW01–LAW04.** `typo(0,1)` с fallback7 выдаёт десять семёрок и одно предупреждение. Без fallback существующая ветвь правильно отказывает. Для `truncnorm(0,1,8,9)` сто samples потребовали 20 100 normal-draws; все результаты равны нижней границе8. Настоящий SciPy truncnorm на том же диапазоне дал сто внутренних значений, среднее8,116469, ни одного граничного атома. Uniform(2,3) в положительном контроле сохранил поддержку.

**Исправление.** Разрешать и проверять intervention-law один раз до sampling. Для поддержанного truncnorm применять устойчивый алгоритм условной хвостовой выборки, например существующий SciPy с корректным переводом границ в стандартизованные a,b; не умножать rejection-лимит вслепую. [C21.E06]

Неподдержанный закон даёт адресный capability-result либо отдельный явно выбранный альтернативный запрос. Atomic-альтернатива может быть полезной, но не считается завершением исходной стохастической задачи. Warning сохраняется и не заменяет эту привязку. Операция TRUNCATED как clipping естественного значения может быть самостоятельной правильной политикой; она не тождественна conditional truncnorm.

**Приёмка.** Проверять положительную масштабную величину, поддержку, вырожденные и хвостовые случаи, фиксацию random-stream, отсутствие неразрешённой смены политики. Для дорогой модели парсинг и подготовка закона переиспользуются; каждая новая научная реплика остаётся отдельной реализацией. Настоящий policy-authority/registry/публикация здесь не запускались.

<!-- END_SOURCE_CARD B225 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**C20.R09. Marks, graph types и валидация DAG.** `policy-engine/src/polisyos/ir/analytics/causal_graph.py`. Окна чтения: 1–280; файл мог быть короче окна. Прочитано как кодовое основание/контроль области, не исполнялось в production-окружении. Git blob `ddad43aba1e6eff00f3440f4ce4bb23162a48b18`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/ir/analytics/causal_graph.py).

**C20.R11. GCM query: traversal, abduction и simulation.** `policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_query.py`. Окна чтения: 1–735; файл мог быть короче окна. Локально сохранены выбранные определения с помеченными импортами; это не полный Git blob. Git blob `b21fbb1b911415125f401390dacc335e925f7b93`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_query.py).

**C20.R12. Factual context и типизированный causal-query.** `policy-engine/src/polisyos/ir/analytics/causal_queries.py`. Окна чтения: 1–220; файл мог быть короче окна. Прочитано как кодовое основание/контроль области, не исполнялось в production-окружении. Git blob `f1b13ceae6e280ac2088c548e2981ec8c69c161b`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/ir/analytics/causal_queries.py).

**C21.R01. Контракт графа, lag-validation и адаптеры/кэшированные строки.** `policy-engine/src/polisyos/ir/analytics/causal_graph.py`. Окна чтения: 1–430; файл мог быть короче окна. Локально — выбранные определения и явно помеченные фикстуры, не полный Git blob. Git blob прочитанного источника `ddad43aba1e6eff00f3440f4ce4bb23162a48b18`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/ir/analytics/causal_graph.py).

**C21.R02. Общие ADMG adjacency, surgery и m-separation.** `policy-engine/src/polisyos/foundry/methods/catalog/causal/admg_ops.py`. Окна чтения: 1–650; файл мог быть короче окна. Локально — выбранные определения и явно помеченные фикстуры, не полный Git blob. Git blob прочитанного источника `01023e8e13bcc26a9125884dec3e9edb91f6f4ca`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/catalog/causal/admg_ops.py).

**C21.R05. SCM-query: family dispatch, sampling, intervention и attribution.** `policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_query.py`. Окна чтения: 105–335; 472–580; 700–900; файл мог быть короче окна. Локально — выбранные определения и явно помеченные фикстуры, не полный Git blob. Git blob прочитанного источника `b21fbb1b911415125f401390dacc335e925f7b93`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/catalog/causal/gcm_query.py).

**C21.R07. Соседний twin-world: общие шумы и обход natural treatment.** `policy-engine/src/polisyos/foundry/methods/catalog/causal/twin_network_query.py`. Окна чтения: 1–260; файл мог быть короче окна. Прочитано для анализа вызовов/контракта; этот полный компонент не исполнялся. Git blob прочитанного источника `cc6fd2a51233e0a41d4d321f6214ce51e855fd62`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/methods/catalog/causal/twin_network_query.py).

**C21.E06. SciPy: truncnorm, стандартизованные границы и условный хвостовой закон.** Первичный источник просмотрен 18 сентября 2026 года. Версия страницы не подменяет зафиксированные версии локальной среды; источник не доказывает запуск PolicyOS. [Источник](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.truncnorm.html).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
