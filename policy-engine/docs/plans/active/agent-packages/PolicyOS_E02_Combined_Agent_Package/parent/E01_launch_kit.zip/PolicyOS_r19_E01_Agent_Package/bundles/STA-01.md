<a id="bundle-sta-01"></a>

# STA-01 — Изоляция ветвей и точные эффекты replay

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B57, B58, B59**. Локальный класс: **L**. Укрупнённая приёмка: **K2**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** нет; после общего SETUP-01 и короткой проверки current base. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** На объявленном write-subtree обеспечить настоящую изоляцию. В существующем результате определить фактические присваивания/удаления и применение к новой основе, включая запись значения, уже равного старому. Согласовать carrier и replay-reader; старые snapshots не читать как безопасный patch.

**Минимальные различающие проверки.** Warm/cold сохраняют unrelated=new; явно записанное y=4 заменяет текущее 9 даже при старом 4. Delete≠null≠no-write. Мутация вложенного списка не протекает в base/соседа; failed branch не меняет базу. Запрещённое удаление evidence-index по-прежнему отвергается.

**Не менять / не считать исправлением.** Не заменять семантику операций простым diff старого input/output, не делать deepcopy всего state, не переигрывать расходы и внешние действия как чистые присваивания.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_sta_01.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T5. **Cross-boundary review:** X03. **Activation rules:** общие правила scope/приёмки.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/scientist/orchestration/engine/state_branching.py` |
| Production write candidate | `policy-engine/src/polisyos/scientist/orchestration/engine/state_merge.py` |
| Production write candidate | `policy-engine/src/polisyos/scientist/orchestration/engine/idempotency.py` |
| Production write candidate | `policy-engine/src/polisyos/scientist/orchestration/engine/executor.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/orchestration/engine/state.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/nodes/builtins/guards.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py` |

**Не писать одновременно с:** STA-02, RES-01. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B57 lines=1543-1558 sha256=0d78e1d5818a8ee8e0f4ba236038d69d06c75e74da87ce22dd7327a13f2f8f06 -->
## B57. Cache-hit способен откатить поля, которые узел не изменял

**Происхождение:** C05-01. **Основание:** NodeResultCache.put, _merge_cached_outcome_state, merge_parallel_outcomes; R1–R6. **Охват:** M. **Приоритет:** высокий при широких state_writes и повторном использовании. [C05.N01, C05.N03, C05.N04]

**Проблема.** Ключ узла строится из объявленных чтений и параметров. Это позволяет не пересчитывать результат после изменения действительно несущественного поля. Но в кэш записывается весь NodeOutcome со старым конечным state. При hit этот state передаётся в merge_parallel_outcomes вместе с текущим base_state. Для широкого объявления `state_writes=['params']` слияние считает записью каждое отличие старого post-state от нынешнего state, а не фактическое изменение, произведённое первоначальным узлом. Разница двух состояний здесь отвечает не на тот вопрос.

**Воспроизведение.** Первоначально `x=2`, `unrelated='old'`; узел вычисляет только `y=4`. Перед replay независимый шаг меняет `unrelated` на `'new'`. Ключ по `params.x` остаётся тем же. Настоящее исполнение на текущем состоянии даёт `'new'` и `y=4`, а проверенный merge из кэша — `'old'` и `y=4`. В applied_paths попадают и `params.y`, и чужое изменение `params.unrelated`. Поле, удалённое из нынешнего состояния, таким же образом может быть восстановлено из старого post-state. Положительный контроль с точным write-path `params.y` сохраняет новое независимое поле.

**Рекомендуемое решение.** Сохранять рядом с результатом компактный, версионированный набор фактических операций записи или отдельные произведённые выходы, привязанные к истинным входам узла. При replay применять только эти операции к разрешённой текущей основе. Исторический checkpoint остаётся снимком для восстановления целого состояния; он не должен незаметно служить патчем для другого состояния. Точный state_writes — полезное немедленное ограничение области, но не универсальная замена фактическому набору записей, особенно для условных no-op.

**Важный отрицательный контроль решения.** Простой diff «старый вход → старый выход» тоже не всегда достаточен. Узел мог явно установить `y=4`, когда на старом входе уже было 4. Diff пуст, но на нынешнем входе с `y=9` настоящее исполнение снова должно установить 4. Проба R6 это различает. Нужен договор о произведённых значениях/намерениях записи, а не только наблюдаемой разнице. Счётчики расходов, добавление событий и внешние действия нельзя переигрывать как обычные чистые присваивания; им нужна собственная идентичность операции и идемпотентность.

**Производительность.** Полный outcome со всё растущим state также увеличивает сериализацию. В счётной иллюстрации 16/32/64 последовательных добавлений дали 37 925 / 146 717 / 577 037 байт сериализованных полных состояний против 4 566 / 9 142 / 18 294 байт небольших записей. Это не размер реального CAS, не latency-benchmark и не обещание такого коэффициента экономии: показан механизм повторной обработки общего префикса. Сохранять периодические полноценные checkpoint и компактные результаты узлов разумнее, чем полностью запретить снимки.

**Приёмка и границы.** Warm/cold совпадают на текущих релевантных входах; независимые обновления не откатываются; удалённое не воскресает без настоящей операции; явная запись прежнего значения не теряется. Старые cache-entry без достаточной семантики можно читать как исторические результаты, но не объявлять безопасными патчами. Проверены два настоящих модуля с тестовыми DTO; конкретный production-узел с широким объявлением и такая история исполнения не запускались. Это условие семантики общей процедуры, не утверждение о порче всех cache-hits.

<!-- END_SOURCE_CARD B57 -->

<!-- SOURCE_CARD B58 lines=1559-1572 sha256=1c1de2a09c78b01dcd21aff5b3b9aafb037873624e4848a2df85846e40cbe9df -->
## B58. Разрешённое удаление поля исчезает при слиянии ветви

**Происхождение:** C05-02. **Основание:** _writes_for_spec и guard удаления; D1–D4. **Охват:** S–M. **Приоритет:** высокий для очистки временных параметров и исследовательского пересмотра. [C05.N01, C05.N06]

**Проблема.** Для полного словаря сборщик записей проходит только по ключам outcome. Если ключ удалён, его уже нет в этом обходе. Для точного пути отсутствие значения также приводит к `return []`. Поэтому результат с удалённым `params.stale` сливается обратно без удаления. Это относится к нынешней процедуре merge; прямое присвоение всего нового state другим путём может работать иначе.

**Воспроизведение.** В исходном состоянии `{stale:1, keep:2}` ветвь удаляет stale. При объявлениях `params` и `params.stale` реальный merge сохраняет stale=1 и возвращает пустой applied_paths. Явный `stale=None` переносится, но ключ остаётся: null — не эквивалент удаления. Отдельный контроль показывает ожидаемое сохранение только keep при явной операции delete.

**Рекомендуемое решение.** Для областей, где удаление разрешено контрактом, передавать его явно как операцию или tombstone и обрабатывать в той же атомарной фазе конфликтов, что и присваивания. Отличать «узел ничего не писал», «записал null» и «удалил». Определить конфликт удаления родителя с записью потомка, повтор удаления и условия применения к новой основе. Можно развить набор операций из B57, а не создавать отдельный сервис удаления.

**Граница прав.** Текущий StateMutationGuard специально запрещает физическое удаление ключей из inputs/artifacts_index/reports_index. Это правило здесь не предлагается отменять. Контрпример использует params; история доказательств и CAS не стираются ради удобства. Для снятия актуальности доказательного объекта предпочтительна существующая версионная запись об отзыве, а не исчезновение следа.

**Приёмка.** Разрешённое удаление временного параметра одинаково работает при прямом, параллельном и кэшированном пути; запрещённое удаление индекса отвергается. Удаление отсутствующего поля и конфликтующие операции имеют объявленную семантику. Оставшееся устаревшее поле не становится входом следующей итерации лишь потому, что merge не умеет передать delete.

<!-- END_SOURCE_CARD B58 -->

<!-- SOURCE_CARD B59 lines=1573-1586 sha256=f1be31314c74127f473589edbd1cda207e908ba5d0d1917d3cdbbb857ed306a8 -->
## B59. Копирование объявленного поддерева изолирует оболочку, но не вложенные изменения

**Происхождение:** C05-03. **Основание:** полный blob-верифицированный state_branching.py; I1–I5; правила покрытия state_writes. **Охват:** S–M. **Приоритет:** высокий на ветвях с изменяемыми вложенными контейнерами. [C05.N02, C05.N06, C05.N07, C05.E01]

**Проблема.** На верхнем write-path из одного сегмента используется deepcopy. Но у вложенного пути `_ensure_isolated_container` доходит до объявленного контейнера и вызывает `_clone_container`: dict/list/Pydantic-модель копируются неглубоко. Если разрешено изменять всё `params.config`, его вложенный список history остаётся общим с исходной ветвью. Это не настоящее перехватывающее copy-on-write: последующая мутация не вызывает автоматического клонирования потомка.

**Воспроизведение.** При `write_paths=('params.config',)` добавление элемента в `branch.params['config']['history']` меняет также base.history с [1] на [1,2]. При `params.config.rows` копируется список, но изменение поля словаря внутри него снова меняет исходник. Контроли с точным листом-списком скаляров и с верхнеуровневым `params` сохраняют base. Значит, оптимизация не ошибочна во всех случаях, но обещание изоляции шире реализованного поведения.

**Рекомендуемое решение.** Сохранить неглубокое копирование предков пути, а на границе объявленного изменяемого поддерева обеспечить его настоящую изоляцию: сначала практичное глубокое копирование только этого поддерева; для доказанно больших горячих областей — неизменяемые структуры или полноценный механизм copy-on-write. Не возвращаться к безусловному deepcopy всего ExperimentState на каждый узел. Нормализовать перекрывающиеся write-paths, чтобы один родитель не копировался повторно вместе с каждым ребёнком. Общие DAG-ссылки внутри разрешённого поддерева и циклические структуры требуют отдельного контроля.

**Почему это важно для проходимости.** Ошибка или отмена ветви после такой утечки не возвращает исходное состояние. Другая исследовательская ветвь может увидеть её незавершённый результат; сравнение before/after способно не заметить изменение, поскольку before уже испорчен общей ссылкой. Это риск даже последовательного запуска с откатом, не только массовой параллельности.

**Приёмка и границы.** Изменения внутри объявленного поддерева не видны основе и соседу до commit; отказ ветви не оставляет следов; неиспользуемая крупная область остаётся общей, если она неизменяема. I5 показывает ограниченное deep-leaf решение с сохранением общей несвязанной ветви. Это контроль проектирования, не внедрённый patch. Полный StateMutationGuard и все реальные узлы здесь не запускались.

<!-- END_SOURCE_CARD B59 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**C04.K04. NodeResultCache / idempotency.** `policy-engine/src/polisyos/scientist/orchestration/engine/idempotency.py`. 1–315. Git blob: `3ae08d7ccf0e35da459c74446d322a766e40c62a`. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/idempotency.py).

**C05.N01.** `policy-engine/src/polisyos/scientist/orchestration/engine/state_merge.py`. Весь возвращённый файл; 1–340. Локальная копия совпала с полным Git blob и исполнена с DTO-фикстурами. Git blob: `65b51cb121ff31ef58d497eead16a467c4e1726f`. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/state_merge.py).

**C05.N02.** `policy-engine/src/polisyos/scientist/orchestration/engine/state_branching.py`. Весь возвращённый файл; 1–240. Локальная копия совпала с полным Git blob и исполнена с DTO-фикстурами. Git blob: `1f89e922ab4c207ba779625746364abb4bc07611`. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/state_branching.py).

**C05.N03.** `policy-engine/src/polisyos/scientist/orchestration/engine/idempotency.py`. 35–275; 247–335. Ключ, запись всего outcome и процедуры восстановления; модуль целиком не импортирован. Git blob: `3ae08d7ccf0e35da459c74446d322a766e40c62a`. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/idempotency.py).

**C05.N04.** `policy-engine/src/polisyos/scientist/orchestration/engine/executor.py`. 365–390; 690–724; 881–905; 903–1035. Cache-key, replay, store и seed из двух источников. Git blob: `dbb0812a5e49222d1c65858e8d905e012c775d0c`. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/executor.py).

**C05.N06.** `policy-engine/src/polisyos/scientist/nodes/builtins/guards.py`. 20–180. Покрытие state_writes и отдельный запрет удаления индексов. Git blob: `72594e91a75ec59cb33bc88bebc975f3dc880ed6`. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/nodes/builtins/guards.py).

**C05.N07.** `policy-engine/src/polisyos/scientist/orchestration/engine/state.py`. 1–210; весь возвращённый файл. Форма ExperimentState; в опытах всё равно использован явный минимальный DTO-заместитель. Git blob: `3724db92babaa2e2da1d1e35f8467159d3afe980`. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/state.py).

**C06.R01. Scientist: checkpoint, delta, фиксация и materialize.** `policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py`. Окна чтения: 1–250, 360–700, 975–1250, 1420–1750. Git blob SHA: `dd90c9121de3e14b7ea2ff8db4781fa3ef750334`. Типы, scope, hook, delta, создание и материализация checkpoint; не полный аудит файла. [Закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py).

**C06.R02. Scientist: resume и остаточный workflow.** `policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py`. Окна чтения: 975–1120, 1760–2070. Git blob SHA: `dd90c9121de3e14b7ea2ff8db4781fa3ef750334`. Pruning, fingerprint и resume; последнее окно до конца полученного файла. Повтор того же blob, а не второй независимый источник. [Закреплённый источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/checkpoint.py).

**C08.R06. ExperimentState: контракт Decimal и мутаций.** `policy-engine/src/polisyos/scientist/orchestration/engine/state.py`. Запрошенные окна: 1–95, для короткого файла — до конца. Git blob `3724db92babaa2e2da1d1e35f8467159d3afe980`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/state.py).

**C05.E01.** `Первичный внешний/версионный источник`. Shallow/deep copy, memo и цена излишнего deepcopy; не доказательство project readiness [Открыть источник](https://docs.python.org/3/library/copy.html).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
