<a id="bundle-trn-03"></a>

# TRN-03 — Контекст переноса, фильтры lessons и время подтверждения

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B135, B136, B137**. Локальный класс: **L**. Укрупнённая приёмка: **K3**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** нет; после общего SETUP-01 и короткой проверки current base. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Различить explicit value и default при разрешении task_family/domain. Одинаковые фильтры действуют на local и transferred lessons до/после материализации. Last-access не обновляет время проверки evidence; учёт чтения ограничен.

**Минимальные различающие проверки.** Переданный typed context не заменяется policy/isolated defaults. Source_run/trust/threshold одинаковы в обеих ветвях. Два чтения старого урока не повышают confidence без новой проверки; настоящее подтверждение имеет свои ссылки/время.

**Не менять / не считать исправлением.** Не менять tenant/права через default override. Не переписывать весь CAS snapshot при каждом чтении и не стирать исторический след.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_trn_03.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T12. **Cross-boundary review:** I2 по фактическим consumers. **Activation rules:** общие правила scope/приёмки.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/scientist/methods/search/transfer_context.py` |
| Production write candidate | `policy-engine/src/polisyos/scientist/methods/search/lessons.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/methods/search/strategies/transfer.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/methods/search/controller.py` |

**Не писать одновременно с:** нет установленного совпадения production paths в этой статической карте. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B135 lines=3515-3528 sha256=2616ea6686a29681f5379ae2e54588f2a82afd9882dd1909aa261ee5990ed1e7 -->
## B135. Переданный типизированный контекст теряет task_family и domain при разрешении значений

**Основание и область:** `resolve_transfer_context` успешно извлекает вложенный TransferContext, но для task_family до обращения к base уже ставит truthy fallback policy/discovery. Domain из base вообще не входит в выражение выбора; вместо него появляется isolated-домен. При этом run_id, tenant_hash и timestamp из base могут сохраняться. [C12.R04]

**Локальный результат:** вложенный `TransferContext(task_family='discovery', domain='education', run_id='r')` — и объект, и соответствующий словарь — разрешились как `policy / isolated::r / r`. Повторение task_family/domain отдельными явными аргументами восстанавливает правильный результат. P26–P28.

**Потеря:** вызывающий код уже передал нужную область, но поиск уроков и перенос могут попасть в другой namespace либо получить нулевую совместимость. Это не «не хватает контекста», а потеря существующего контекста на адаптере.

**Рекомендуемое решение:** установить явный приоритет источников, сохраняя значения base, когда не задано разрешённое переопределение. Подстановка defaults выполняется только после попытки взять все допустимые содержательные значения. Конфликт явного и вложенного контекста различается, а не маскируется. Для tenant/полномочий по-прежнему приоритет действительного execution-owner; агентный словарь не создаёт право доступа. Не объединять различные домены лишь ради успешного поиска.

**Приёмка:** вложенный объект, сериализованный объект и равнозначные явные поля ведут к одному эффективному предметному контексту; настоящее разрешённое override работает; невалидный base имеет адресный результат; isolated-fallback остаётся для действительно неизвестной области.

**Приоритет и оговорка:** дешёвый локальный ремонт существующего resolver. Security-импорт в опыте возвращал None; реальные tenant-разрешения не проверялись, и обход из этой ошибки не выводится.

<!-- END_SOURCE_CARD B135 -->

<!-- SOURCE_CARD B136 lines=3529-3542 sha256=1182d49f6e0f40a47b62e7bfe488d75ff540516f4ba6f022cbedba1340c60deb -->
## B136. Ограничения запроса к урокам действуют локально, но теряются на ветви переноса

**Основание и область:** `_query_local` проверяет trust_levels, min_confidence и source_run_id. `_entry_matches`/`_revalidate_transfer`, используемые find/materialize, не обеспечивают этих же проверок. `query_with_transfer` добавляет материализованные карточки без финальной проверки всей семантики LessonQuery. Перенос при этом может сам изменить trust_level. Legacy controller действительно вызывает query_with_transfer с min_confidence=0,5 при наличии lesson_registry; это связывает API с условным потребителем, но не доказывает полную проходимость GY. [C12.R05, C12.R09]

**Локальный результат:** запрос `min_confidence=0.8`, `trust_levels=[LOCAL]` вернул перенесённую карточку с confidence=0,2 и trust=TRANSFERRED. Тот же слабый пример в local-ветви отвергнут. Контроль с несовместимой stage тоже отвергнут; явно разрешающий слабые transferred-hints запрос получил допустимый результат. Исполнена цепочка выбранных тел query → find → materialize с фикстурами хранения, а не вся инфраструктура. P29–P32.

**Потеря:** расширение поиска на чужую историю незаметно смягчает фильтр пользователя. Система может расходовать следующие итерации на материал, который сама локальная ветвь считает неподходящим. Наличие карточки не означает её применение как полномочного доказательства — такое применение здесь не испытывалось.

**Рекомендуемое решение:** единый явный предикат выдачи для local и transferred, с отдельной проверкой до дорогой материализации и после преобразования значимых статусов. При необходимости ослабления фильтра вернуть отдельное предложение расширить поиск или отдельную не соответствующую запросу группу, а не включать её в подходящие результаты. Фильтры доступа/tenant проверяет владелец; совпадение labels этого не заменяет. Адресную применимость/разрешённый перенос сохранить.

**Приёмка:** переданный threshold и trust-filter соблюдаются независимо от маршрута; локальный промах не меняет требования; действительно допустимая transferred-карточка возвращается; несоответствующая не материализуется зря. Проверить source_run_id и политику частичного ответа, не только два численных примера.

**Приоритет и оговорка:** небольшая согласующая работа вокруг существующих predicates. Это не предложение запретить cross-domain transfer; контроль уже показывает полезный разрешённый вариант.

<!-- END_SOURCE_CARD B136 -->

<!-- SOURCE_CARD B137 lines=3543-3556 sha256=133330308d63d9cf44d4105d556e1e4740ff31b519643791722beb8a8a7bc961 -->
## B137. Обычное чтение старого урока восстанавливает уверенность без новой проверки

**Основание и область:** `_materialize_query_card` определяет возраст через `entry.last_accessed_at` или last_seen и при превышении TTL понижает confidence до 0,5 и trust до LOW_CONFIDENCE. `_query_local` после выдачи обновляет last_accessed_at и сохраняет индекс. Исходная карточка с прежними confidence/trust остаётся неизменной. При следующем чтении age мал, и прежние значения вновь возвращаются. [C12.R05]

**Локальный результат:** для карточки возрастом 100 дней при TTL=90 первый широкий запрос вернул `0.5 / low_confidence`; немедленный второй с `min_confidence=0.8, trust=LOCAL` вернул `0.9 / local`. Источник и его created_at не изменялись. Без предшествующего широкого чтения строгий запрос правильно отвергался. Контроль отдельного evidence-clock сохраняет понижение. P33–P35.

**Потеря:** популярность начинает действовать как подтверждение актуальности. Повторные чтения могут поддерживать старое основание без наблюдений или ревалидации. Кроме того, успешное чтение вызывает `_persist_index`: полный изменённый snapshot пишется в файл и CAS. Это установленный путь вызовов, не измеренная деградация скорости на большом реестре. [C12.R05]

**Рекомендуемое решение:** различить clock использования для retention/LRU и clock действительной проверки/версии доказательства. Чтение может продлить доступность кэша, но не уверенность и не срок эмпирической применимости. Использовать существующую запись проверки и происхождение; если требуется новая семантика last_verified, она должна быть явно определена, а не автоматически заполнена now. Счётчики доступа можно обновлять отдельно или пакетно, не публикуя новый полный доказательный snapshot при каждом чтении. Старые пригодные идеи сохранять с их ограниченным статусом, не удалять историю.

**Приёмка:** любое число обычных чтений не повышает доверие; настоящая разрешённая ревалидация создаёт новую версию с новыми основаниями; повторный холодный и тёплый запрос дают одинаковую содержательную степень актуальности. Retention может учитывать популярность, evidence sufficiency — нет. Проверить восстановление после restart и перенос, а не только пару запросов в одной памяти.

**Приоритет и оговорка:** высокий для использующего age-demotion реестра. Число 0,9 здесь внутренний confidence урока, не измеренная вероятность истинности. Нельзя объявлять весь урок ложным по календарному возрасту: политика доказательной актуальности зависит от природы его основания.

<!-- END_SOURCE_CARD B137 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**C11.R01. Legacy SearchController: run, generator, evaluation и typed fallback.** `policy-engine/src/polisyos/scientist/methods/search/controller.py`. Окна чтения: 1–240, 241–520, 520–850. Полная локальная копия не заявлена. Перенесённые тела в `sources/controller_run.py`; сокращены аннотации/комментарии и форматирование, это не полный Git blob. Git blob `95668197ea04405006cb0778de259f94af0cf633`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/controller.py).

**C12.R01. TransferLearningManager: сохранение, выбор и чтение истории.** `policy-engine/src/polisyos/scientist/methods/search/strategies/transfer.py`. Полная копия; 221 строк, Git blob совпал. Исполнен с описанными импортными fixtures. Git blob `c353825ea6c81c3cacf3bc1f3fb303b9adcbe5d5`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/strategies/transfer.py).

**C12.R04. Контекст переноса и политика веса/возраста.** `policy-engine/src/polisyos/scientist/methods/search/transfer_context.py`. Полная копия; 306 строк, Git blob совпал. Исполнен с описанными импортными fixtures. Git blob `8ac649925d16eee2b7aceb923d177c4ae8472079`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/transfer_context.py).

**C12.R05. LessonRegistry: local/transfer query, materialize, freshness, snapshot.** `policy-engine/src/polisyos/scientist/methods/search/lessons.py`. Прочитанные окна: 1–270, 270–615, 610–965, 950–1070. Полный локальный blob не заявлен. Выбранные тела: `sources/lessons_extract.py`. Git blob `75fce092498d567d488aa033c830008f49fac342`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/lessons.py).

**C12.R09. Legacy consumer передаёт min_confidence в lesson query.** `policy-engine/src/polisyos/scientist/methods/search/controller.py`. Прочитанные окна: 540–585. Полный локальный blob не заявлен. Git blob `95668197ea04405006cb0778de259f94af0cf633`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/methods/search/controller.py).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
