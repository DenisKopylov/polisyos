<a id="bundle-uqp-01"></a>

# UQP-01 — Настоящая функция отклика и полный effective call

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B186, B189, B190, B191**. Локальный класс: **N**. Укрупнённая приёмка: **K4**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** нет; после общего SETUP-01 и короткой проверки current base. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Разрешить полный набор fixed и varying inputs, реально обоснованную модель/affine-карту и ожидаемые outputs. Убрать Python float cast с дифференцируемого tracer. Missing sensitivity остаётся неизвестной/явной гипотезой, не автоматически mapped; отсутствие output не становится нулевой константой.

**Минимальные различающие проверки.** y=x*scale при scale=2 сохраняет 20 в nominal/delta/MC, не 10. Для реальной affine-карты dispatcher выбирает delta без сотни fallback calls. y=x−2 при baseline=0 имеет ненулевую дисперсию, если Var(x)>0. Missing output не даёт [0,0]; настоящая константа 0 остаётся допустимой. Малые массивы и JAX grad по одному слоту.

**Не менять / не считать исправлением.** Не открывать быстрый delta отдельно от исправления смысловой карты B190. Не угадывать связи каждого output со всеми params и не повторять один структурный TypeError сотни раз.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_uqp_01.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T18. **Cross-boundary review:** X06. **Activation rules:** A04.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/foundry/uncertainty/delta.py` |
| Production write candidate | `policy-engine/src/polisyos/foundry/uncertainty/dispatcher.py` |
| Production write candidate | `policy-engine/src/polisyos/scientist/nodes/builtins/simulate/propagate_uncertainty.py` |
| Production write candidate | `policy-engine/src/polisyos/foundry/uncertainty/monte_carlo.py` |
| Read / consumer contract | `policy-engine/src/polisyos/foundry/uncertainty/config.py` |
| Read / consumer contract | `policy-engine/src/polisyos/foundry/uncertainty/covariance.py` |

**Не писать одновременно с:** UQP-02, UQP-03. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B186 lines=4712-4721 sha256=9278fafc393d83f73e09a50cb1d74308961a627d63a775905c103e831bb8e6ea -->
## B186. Фиксированные nominal-параметры пропадают в delta и Monte Carlo

**Основание и причина.** `DeltaMethodPropagator` и оба MC sampling-loop строят kwargs только из ключей `input_envelopes`. Остальные `nominal_params` не передаются. При этом `_safe_nominal_outputs` вызывает функцию с полным nominal. Один отчёт может соединить номинальный результат одной задачи с выборкой другой. C18.R05, R07–R08; P05–P08.

**Воспроизведение.** Для y=x×scale, nominal x=10, scale=2, и envelope только у x, delta вернул 10 вместо 20: использован Python-default scale=1. MC nominal дал 20, а среднее 200 sampled-вызовов — 9,950506. Если scale обязателен и default отсутствует, номинальный вызов всё ещё даёт 20, но все 100 sampled-вызовов завершаются ошибкой. Обёртка, объединяющая фиксированный nominal с изменяемой частью, вернула point=20 и дисперсию 4 при σx=1.

**Предпочтительное исправление.** Один раз разрешить полный эффективный набор входов и разделить его на фиксированные и варьируемые. При каждом прогоне менять только объявленные случайные координаты; все прочие параметры, версии модели и артефактов сохраняются. Использовать эту же привязку в пробной дифференциации, nominal, delta и MC. Большие неизменяемые объекты не копировать целиком: замыкание или типизированные ссылки достаточны.

**Оговорки и приёмка.** Если API намеренно требует, чтобы фиксированные значения были замкнуты вызывающей стороной, это должно проверяться и документироваться до запусков. Native-node из C18.R09 номинал строит только по envelope-ключам и может избегать данного контрпримера. Не создавать нулевую неопределённость каждой фиксированной константе ради обхода; не повторять сто раз один TypeError. Проверить совпадение effective kwargs, сохранение реальных defaults только при их намеренном выборе и адресный отказ при неразрешённом входе.

<!-- END_SOURCE_CARD B186 -->

<!-- SOURCE_CARD B189 lines=4742-4751 sha256=d4807669b03d45438519948f53992d9b71fd88351e4df7dbf91230791d002c6a -->
## B189. Штатная функция отклика ломает собственный быстрый delta-путь

**Основание и причина.** Scientist-node передаёт `is_jax_differentiable=True`, но созданный `_build_propagation_fn` внутри вызывает `float(current)` на параметре, по которому берётся Jacobian. `eval_shape/jacfwd` dispatcher получает tracer; преобразование к Python-float невозможно. После диагностического сообщения выбирается MC. C18.R05, R07, R09; P15–P17.

**Воспроизведение.** Для явно заданного линейного отклика y=10×[1+(x−2)/2] дифференцирование узловой функции дало `ConcretizationTypeError`; dispatcher выбрал Monte Carlo. Тестовый MC-driver с настоящим выбранным random-loop выполнил 100 образцов. Та же формула без scalar-cast выбрала delta и вернула point=10, variance=25 при Var(x)=1.

**Предпочтительное исправление.** Разрешать Python-константы до трассировки, а изменяемые значения сохранять в JAX-совместимых выражениях. Конвертировать конечные результаты в Python только на границе отчёта. Для явно известной affine-карты возможен ещё более дешёвый Jacobian, но он должен совпадать с настоящим отображением и его единицами.

**Оговорки и приёмка.** MC — нормальная стратегия для действительно недифференцируемых моделей, не ошибка сама по себе. Не отключать fallback; различать неподдержанную математическую модель и дефект адаптера. Удаление cast не доказывает научную достоверность синтетической карты — B190 исправляется совместно. Опыт не измеряет многократное ускорение всей системы: штатная карта сравнительно дешева, а full production-node и настоящий MC report не запущены. Проверить eager/JIT, kwargs, точный Jacobian и отсутствие лишних sampled-вызовов на известном линейном контроле.

<!-- END_SOURCE_CARD B189 -->

<!-- SOURCE_CARD B190 lines=4752-4761 sha256=bb28f0e65d6317465c37bae99ed3a0bd89a03a3194f111e0f3faf24553724d53 -->
## B190. Неизвестная чувствительность заменяется произвольной связью, а нулевой baseline подавляет всю неопределённость

**Основание и причина.** При отсутствии явной карты и совпадений имён `_resolve_sensitivity_map` создаёт малые связи каждого выхода со всеми параметрами и отмечает их `mapped`. `_build_propagation_fn` умножает baseline выхода на 1+относительную поправку. Если есть хоть одна явная карта, остальные выходы могут остаться просто константами. Это модельная эвристика, не вызов существующей полной симуляции. C18.R09; P18–P20.

**Воспроизведение.** Для неизвестной связи x→y и baseline y=0 helper построил коэффициент x=1 и mapped={x}, но y остался 0 при x=2 и x=3. При явно заданном только y остальные z=20 не менялись. Контроль настоящего отображения y=x−2 при x₀=2 имел тот же нулевой baseline, но дисперсию 1; отсутствие эффекта в baseline не означает отсутствия чувствительности.

**Предпочтительное исправление.** Различить установленную карту, исследовательское предположение и неразрешённую связь. Переиспользовать реально исполненную модель, сохранённый Jacobian или явно заданную affine-карту с происхождением и единицами. Для нулевого baseline допустим размерный аддитивный отклик, если его смысл установлен; нельзя заменять ноль epsilon и считать вопрос решённым.

**Оговорки и приёмка.** Простая surrogate-карта полезна как отдельная гипотеза. Она должна быть помечена соответствующим образом, не выдаваться за консервативную границу и не подтверждать полноту mapping по числу автоматически добавленных имён. Неизвестность не обязана блокировать все известные выходы: сохранить частичную проекцию с адресным запросом на недостающую связь. Проверить нулевой и ненулевой baseline, частичные карты, масштаб единиц и настоящую постоянную модель. Производственный допуск или публикация эвристической карты в опыте не проверялись.

<!-- END_SOURCE_CARD B190 -->

<!-- SOURCE_CARD B191 lines=4762-4771 sha256=91e46d98b7af41ab8bda1facccae166d7348da11389426af576e2d48293769cd -->
## B191. Отсутствующий выход в delta становится нулевым интервалом

**Основание и причина.** `_vectorized_fn` берёт `result.get(metric_id, 0.0)`, и аналогичный default используется в проверке применимости dispatcher. Для отсутствующего ключа Jacobian нулевой. Метод затем запрашивает Normal-envelope с point=0, интервалом [0,0] и `gate_eligible=True`. C18.R05, R07; P21–P23.

**Воспроизведение.** Функция вернула только `actual`, а запрос содержал `missing`: локальный производитель сформировал [0,0]. В MC отсутствие этого же выхода записывается как NaN, а не ноль. Настоящий постоянный нулевой выход корректно даёт [0,0] и не должен быть запрещён.

**Предпочтительное исправление.** До дифференциации связать ожидаемые выходы с их реальными производителями, именами и формой. Отсутствующий ключ — структурный пробел, не константа и не причина слепо повторить сотни вычислений. При допустимом частичном ответе сохранить присутствующие выходы; для остальных вернуть адресную недоступность. Если отсутствует весь запрошенный результат, не считать пустое вычисление успешным оцениванием.

**Оговорки и приёмка.** `RecordingDTO` только зафиксировал аргументы конструктора; настоящий валидатор composition_provenance/gate и CAS не запускались. Нулевой сертификат мог бы быть отвергнут дальше, поэтому не заявляется выданное ложное разрешение. Native-node по C18.R09 строит список выходов из исходных метрик и обычно сохраняет все ключи своей карты; generic API остаётся проверенной областью риска. Проверить одинаковую семантику отсутствия для delta и MC, именованные реальные нули и частично выполненную функцию.

<!-- END_SOURCE_CARD B191 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**C18.R03. Конфигурация propagation и адаптивного MC.** `policy-engine/src/polisyos/foundry/uncertainty/config.py`. Прочитан полный файл. Полный локальный blob сверен; при исполнении проектные импорты заменены явными фикстурами. IR certificate/provenance валидатор не исполнялся. Git blob `112098e1359877691d07a81126e201aacc8bd012`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/uncertainty/config.py).

**C18.R04. Построение covariance и извлечение маргинальной дисперсии.** `policy-engine/src/polisyos/foundry/uncertainty/covariance.py`. Прочитан полный файл. Полный локальный blob сверен; при исполнении проектные импорты заменены явными фикстурами. IR certificate/provenance валидатор не исполнялся. Git blob `9ef5909b646747a8bb11375cd67bad43aa28d6f4`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/uncertainty/covariance.py).

**C18.R05. Delta: kwargs, Jacobian и выходной envelope.** `policy-engine/src/polisyos/foundry/uncertainty/delta.py`. Прочитан полный файл. Полный локальный blob сверен; при исполнении проектные импорты заменены явными фикстурами. IR certificate/provenance валидатор не исполнялся. Git blob `37751416edd561d03597d816f7b8763bc7ccd6f6`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/uncertainty/delta.py).

**C18.R07. Выбор стратегии и fallback.** `policy-engine/src/polisyos/foundry/uncertainty/dispatcher.py`. Прочитан полный файл. Полный локальный blob сверен; при исполнении проектные импорты заменены явными фикстурами. IR certificate/provenance валидатор не исполнялся. Git blob `fe4d20b4f3aaf3f7612ee010de83def54276227e`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/uncertainty/dispatcher.py).

**C18.R08. MC: random/QMC, остановка, отбор valid, samples и отчёт.** `policy-engine/src/polisyos/foundry/uncertainty/monte_carlo.py`. Окно чтения первый ответ обрезан; затем 345–440 и 430–800; файл мог быть короче запрошенного окна. Локально — выбранные определения; полного blob нет. Wrapper выбранных определений и тестовая композиция описаны в harness; это не полный native pipeline. Git blob `06fcb630a3234eab4973b711722e19ac6bd32f1c`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/uncertainty/monte_carlo.py).

**C18.R09. Штатный Scientist-node и создаваемое отображение отклика.** `policy-engine/src/polisyos/scientist/nodes/builtins/simulate/propagate_uncertainty.py`. Окно чтения 1–440; файл мог быть короче запрошенного окна. Локально — выбранные определения; полного blob нет. Wrapper выбранных определений и тестовая композиция описаны в harness; это не полный native pipeline. Git blob `7e9a291df5e49747463966b96b3e1d9fa9c3d618`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/nodes/builtins/simulate/propagate_uncertainty.py).

**C19.R04. Извлечение STD и covariance.** `policy-engine/src/polisyos/foundry/uncertainty/covariance.py`. Полное чтение. Полный локальный blob сверен; проектные imports при исполнении явно заменены согласно harness. Git blob `9ef5909b646747a8bb11375cd67bad43aa28d6f4`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/uncertainty/covariance.py).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
