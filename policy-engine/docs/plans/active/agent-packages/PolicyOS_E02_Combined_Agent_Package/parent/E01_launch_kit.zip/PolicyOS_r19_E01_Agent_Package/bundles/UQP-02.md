<a id="bundle-uqp-02"></a>

# UQP-02 — Оси covariance, совместный закон и эмпирический carrier

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B187, B188, B192**. Локальный класс: **N**. Укрупнённая приёмка: **K4**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** UQP-01. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Сначала правильно адресовать строки/столбцы covariance, затем проверять численную пригодность. До выбора backend разрешить общий joint-law. Поддержанные Gaussian и empirical carriers передавать с реальной зависимостью и согласованными random/QMC transforms.

**Минимальные различающие проверки.** Перестановка covariance columns при разных дисперсиях 1/9 сохраняет diag(1,9), не искусственную матрицу 2.5. Для a=b и y=a−b analytical/delta/совместный MC дают 0; для независимых inputs сохраняется 2. Эмпирический carrier [-1,0,0,1] сохраняет атомы и joint row IDs. Десятки/сотни простых draws, не большой Monte Carlo.

**Не менять / не считать исправлением.** Не исправлять неверные оси спектральным repair, не превращать неизвестную зависимость в независимость и не реконструировать полный закон из двух границ CI.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_uqp_02.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T18. **Cross-boundary review:** X07. **Activation rules:** общие правила scope/приёмки.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/foundry/uncertainty/covariance.py` |
| Production write candidate | `policy-engine/src/polisyos/foundry/uncertainty/analytical.py` |
| Production write candidate | `policy-engine/src/polisyos/foundry/uncertainty/monte_carlo.py` |
| Production write candidate | `policy-engine/src/polisyos/foundry/uncertainty/delta.py` |
| Production write candidate | `policy-engine/src/polisyos/foundry/uncertainty/dispatcher.py` |
| Read / consumer contract | `policy-engine/src/polisyos/ir/analytics/uncertainty.py` |
| Read / consumer contract | `policy-engine/src/polisyos/foundry/uncertainty/config.py` |

**Не писать одновременно с:** UQP-01, UQP-03, CAL-06. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B187 lines=4722-4731 sha256=2b4d8ebdce33646e0610e74f827232b75cd324432972a7957ab5896c2765275b -->
## B187. Перестановка covariance_params меняет дисперсии; численный repair скрывает неправильную адресацию

**Основание и причина.** `build_covariance_matrix` собирает rows в порядке `param_names`: имя envelope уже определяет строку. Затем при отличающемся `covariance_params` переставляются и столбцы, и уже упорядоченные строки. Получившаяся несимметричность симметризуется и спектрально исправляется. C18.R04; P09–P11.

**Воспроизведение.** Независимые a,b имеют дисперсии 1 и 9. Метаданные столбцов задают порядок [b,a], а строки корректно принадлежат своим envelopes: a=[0,1], b=[9,0]. Ожидаемая матрица в порядке [a,b] — diag(1,9). Функция вернула [[2,5;2,5],[2,5;2,5]]: изменились обе дисперсии и появилась зависимость. При уже совпадающем порядке положительный контроль дал правильную матрицу. Перестановка только столбцов в данном контракте восстановила diag(1,9).

**Предпочтительное исправление.** Определить единый контракт осей и сначала привести строки и столбцы по их действительным идентификаторам. Когда row принадлежит имени envelope, повторная row-перестановка не нужна. Затем проверить длины, уникальность имён, диагонали, симметрию и смысл согласования с маргинальными envelopes. Спектральный repair применять только к численной проблеме с объявленной допустимой величиной, а не к неизвестной перестановке.

**Оговорки и приёмка.** Замена одной индексации достаточна лишь при подтверждении контракта всех производителей. Проверить перестановки двух и трёх координат, неравные дисперсии и недиагональные элементы; одинаковая diag или одинаковые дисперсии скрывают дефект. Существующая поддержка full covariance полезна и должна сохраняться. Переход к диагонали без причины не исправляет потерю корреляции. Приоритет высокий, объём ремонта обычно локальный; неправильная матрица не требует дополнительных симуляций для обнаружения.

<!-- END_SOURCE_CARD B187 -->

<!-- SOURCE_CARD B188 lines=4732-4741 sha256=845944fcb63293d09ccc282370335bbe03a508973c704ac6a58175d019e86771 -->
## B188. Выбор стратегии меняет совместный закон параметров

**Основание и причина.** Delta использует `build_covariance_matrix`, а analytical суммирует w²σ² без перекрёстных членов. MC создаёт отдельный случайный поток для каждого параметра; QMC отдельно преобразует координаты. Ни analytical-dispatch, ни показанные sampling-loop не используют заявленную covariance и не устанавливают независимость как условие применимости. C18.R04–R08; P12–P14.

**Воспроизведение.** Для a=b, unit variance и y=a−b правильная дисперсия 0. При выровненных метаданных (B187 исключён из опыта) delta дал 0; analytical — 2; MC на 1000 запросах — 1,923327. Контроль совместного draw z для обеих координат дал 0. При действительно независимых a,b analytical=2 является правильным: внутренняя формула не ошибочна в собственной области применимости.

**Предпочтительное исправление.** Разрешить общий совместный входной закон до выбора вычислительного backend. Для допустимой совместной Gaussian-модели переиспользовать covariance: analytical считает wᵀΣw, sampling использует совместные draw. Эмпирические совместные наблюдения сохраняют пары по индексу реплики. Для общей нелинейной зависимости одной covariance недостаточно: нужен подходящий совместный carrier, явно принятая модель зависимости либо набор допустимых альтернатив.

**Оговорки и приёмка.** Независимость остаётся дешёвым полезным режимом, когда она действительно объявлена или обоснована. Она не является консервативной заменой неизвестной зависимости: для суммы и разности направление ошибки разное. Сначала совместимые входы, потом любой fallback. Проверять эквивалентность backend на линейном Gaussian-случае и сохранение нелинейной семантики отдельно. Полная проектная валидация сертификатов не запускалась; опыт устанавливает математическое расхождение локальных производителей, не институциональный допуск результата.

<!-- END_SOURCE_CARD B188 -->

<!-- SOURCE_CARD B192 lines=4772-4781 sha256=3ba8c9b9a37ba35d3d7e210af7d91ecdfaebbc6d642739172a988840a9c2ef34 -->
## B192. Сохранённый эмпирический закон не используется в повторном распространении

**Основание и причина.** MC `_build_results` сохраняет выборку в `PosteriorSamplesCarrier`, но `_sample_from_envelope` и QMC-transform не читают `distribution_payload`. Для BOOTSTRAP и остальных неразобранных семейств используется Normal с point и std=(hi−lo)/4. Поэтому следующий переход может стереть уже вычисленный закон. C18.R08; P24–P26.

**Воспроизведение.** Два эмпирических carrier с поддержками [-1,1] и [-1,0,0,1], общими point=0 и interval=[−1,1], дали побитово одинаковые 1000 Normal-draw при одном seed. Ни один draw не попал на заявленные атомы. QMC-точки u=0,125/0,375/0,625/0,875 дали приблизительно [−0,575;−0,159;0,159;0,575] вместо эмпирических [−1;−1;1;1]. Контроль, реально выбирающий атомы второго carrier, сохранил поддержку и включил 490 нулей.

**Предпочтительное исправление.** Общий адаптер закона должен сначала использовать имеющийся типизированный carrier: действительные draws/weights, параметрический закон или явный поддерживаемый transform. Для эмпирического закона random sampling и inverse-CDF/QMC должны представлять один предмет. Совместные пары draws сохраняются по B188. Новый resampling уменьшает лишь вычислительную ошибку относительно сохранённого закона, но не создаёт новое эмпирическое основание.

**Оговорки и приёмка.** Normal-аппроксимация допустима как явно выбранная компрессия с проверкой ошибки, областью использования и происхождением. Нельзя автоматически реконструировать полный закон по двум концам интервала. Запрет всех эмпирических priors тоже неоптимален: носитель уже предусмотрен. Проверены helper-функции с carrier-фикстурами, не весь граф IR-валидации. Для первого ремонта достаточно поддержать реально используемое семейство и точно обозначить остальные, без нового универсального sampler.

<!-- END_SOURCE_CARD B192 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**C18.R03. Конфигурация propagation и адаптивного MC.** `policy-engine/src/polisyos/foundry/uncertainty/config.py`. Прочитан полный файл. Полный локальный blob сверен; при исполнении проектные импорты заменены явными фикстурами. IR certificate/provenance валидатор не исполнялся. Git blob `112098e1359877691d07a81126e201aacc8bd012`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/uncertainty/config.py).

**C18.R04. Построение covariance и извлечение маргинальной дисперсии.** `policy-engine/src/polisyos/foundry/uncertainty/covariance.py`. Прочитан полный файл. Полный локальный blob сверен; при исполнении проектные импорты заменены явными фикстурами. IR certificate/provenance валидатор не исполнялся. Git blob `9ef5909b646747a8bb11375cd67bad43aa28d6f4`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/uncertainty/covariance.py).

**C18.R05. Delta: kwargs, Jacobian и выходной envelope.** `policy-engine/src/polisyos/foundry/uncertainty/delta.py`. Прочитан полный файл. Полный локальный blob сверен; при исполнении проектные импорты заменены явными фикстурами. IR certificate/provenance валидатор не исполнялся. Git blob `37751416edd561d03597d816f7b8763bc7ccd6f6`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/uncertainty/delta.py).

**C18.R06. Аналитическая линейная комбинация.** `policy-engine/src/polisyos/foundry/uncertainty/analytical.py`. Прочитан полный файл. Полный локальный blob сверен; при исполнении проектные импорты заменены явными фикстурами. IR certificate/provenance валидатор не исполнялся. Git blob `3d09d995384352903ba7b619f434976c7c74025c`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/uncertainty/analytical.py).

**C18.R07. Выбор стратегии и fallback.** `policy-engine/src/polisyos/foundry/uncertainty/dispatcher.py`. Прочитан полный файл. Полный локальный blob сверен; при исполнении проектные импорты заменены явными фикстурами. IR certificate/provenance валидатор не исполнялся. Git blob `fe4d20b4f3aaf3f7612ee010de83def54276227e`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/uncertainty/dispatcher.py).

**C18.R08. MC: random/QMC, остановка, отбор valid, samples и отчёт.** `policy-engine/src/polisyos/foundry/uncertainty/monte_carlo.py`. Окно чтения первый ответ обрезан; затем 345–440 и 430–800; файл мог быть короче запрошенного окна. Локально — выбранные определения; полного blob нет. Wrapper выбранных определений и тестовая композиция описаны в harness; это не полный native pipeline. Git blob `06fcb630a3234eab4973b711722e19ac6bd32f1c`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/uncertainty/monte_carlo.py).

**C19.R04. Извлечение STD и covariance.** `policy-engine/src/polisyos/foundry/uncertainty/covariance.py`. Полное чтение. Полный локальный blob сверен; проектные imports при исполнении явно заменены согласно harness. Git blob `9ef5909b646747a8bb11375cd67bad43aa28d6f4`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/foundry/uncertainty/covariance.py).

**C19.R06. IR carriers, numerical validator и joins.** `policy-engine/src/polisyos/ir/analytics/uncertainty.py`. Окна чтения: 460–1080; 1180–1575; файл мог быть короче окна. Локально — помеченные выбранные определения; это не полный исходный файл. Git blob `0a2495855d707a6548da6983bdef9abed9c4b0c7`. [Исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/ir/analytics/uncertainty.py).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
