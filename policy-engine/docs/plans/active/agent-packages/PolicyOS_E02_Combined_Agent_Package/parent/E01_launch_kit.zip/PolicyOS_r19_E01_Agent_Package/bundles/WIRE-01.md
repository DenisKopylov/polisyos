<a id="bundle-wire-01"></a>

# WIRE-01 — Версионированный transport допустимых типов state

**Исполнение: один Luna implementer + reviewer неавтор.** Карточки: **B94**. Локальный класс: **L**. Укрупнённая приёмка: **K2**. Начальный статус: `planned`.

## План пакета E01

**Необходимые предшественники выбранного плана:** нет; после общего SETUP-01 и короткой проверки current base. Подготовка может начинаться раньше; production запись — после удовлетворения действительных контрактов и освобождения write-set.

**Работа и порядок.** Согласовать typed wire-codec для state/outcome и safe-digest. Сохранить Decimal в типизированных и union-полях, идентичность bytes и non-finite policy через оба заявленных JSON backend.

**Минимальные различающие проверки.** Decimal в budget и params после round-trip имеет прежний тип/значение. Nested non-finite/unsupported даёт точный отказ, не строку/ноль. Настоящие ArtifactRef и OutputAwareNodeOutcome проходят native codec. Запуск Ray/Temporal для codec-теста не нужен.

**Не менять / не считать исправлением.** Не использовать default=str или float(Decimal). JSON-mode сам по себе не доказывает сохранение union-типа. Не повторять вычисление из-за детерминированной serialization ошибки.

**Регрессии и handoff.** Сначала тест исходного native поведения, затем тот же тест после исправления и независимый negative/metamorphic контроль. Исторические критерии каждой карточки ниже обязательны в своей применимой области; краткий план выше их не заменяет. Передать exact base/patch SHA, B-исходы, команды/exit codes/логи, readback/migration и deferred-native пункты. Малые проверки — через глобальную очередь I1; полный CI не запускать на каждом пакете.

**Предлагаемый новый regression-файл:** `policy-engine/tests/unit/remediation/test_wire_01.py`. Это planned path, не обнаруженный существующий файл. При наличии подходящего co-located test использовать его по действующим repository conventions и записать точный node ID.

**Сценарии источника:** T8. **Cross-boundary review:** X14. **Activation rules:** общие правила scope/приёмки.

## Область записи и чтения

Это карта r19. На старте уточнить действительный write-set по current checkout; чтение файла не даёт права менять его попутно. Для нового общего carrier — одна адресная reservation через Sol/I2. Не создавать новый service/registry только потому, что указанная граница требует согласования.

| Режим | Точный исторический путь |
|---|---|
| Production write candidate | `policy-engine/src/polisyos/scientist/orchestration/engine/runner/serialization.py` |
| Read / consumer contract | `policy-engine/src/polisyos/scientist/orchestration/engine/state.py` |
| Read / consumer contract | `policy-engine/src/polisyos/core/llm/response.py` |

**Названные в r19 тематически близкие tests (не подтверждение их покрытия/запуска):**

- `policy-engine/tests/unit/scientist/orchestration/engine/runner/test_serialization.py`

**Не писать одновременно с:** нет установленного совпадения production paths в этой статической карте. Это конфликт записи, не дополнительная логическая prerequisite всех перечисленных пакетов.

## Полные исходные карточки r19 — без изменения текста

<!-- SOURCE_CARD B94 lines=2477-2492 sha256=da315729082384722dd083535cd9f7e944d8ff25aaa8856ca4ab8fc1f1d99bc7 -->
## B94. Wire-сериализация не принимает Decimal, разрешённый собственным состоянием

**Происхождение:** C08-06. **Основание:** runner serialization → типы ExperimentState → callers Ray/Temporal; J1–J7. **Приоритет:** для реального перехода через этот codec; не обязательное условие локального in-process запуска. [C08.R05, C08.R06, C08.R10, C08.R11]

**Проблема.** `serialize_state`, `serialize_outcome` и `serialize_state_safe` передают `model_dump()` в orjson либо стандартный json без type-aware default. `ExperimentState.budgets` явно содержит Decimal; Decimal также допускается в params и causal_method_params. Python-mode dump сохраняет такие объекты. Поэтому обычный непустой бюджет останавливает сериализацию до отправки. Версия с digest использует тот же encoder и не устраняет проблему добавлением хэша.

**Проверки.** На реальном Pydantic/stdlib/orjson с уменьшенной DTO той же формы Decimal-бюджет вызывает TypeError в обоих JSON backend; аналогично outcome и safe-state. JSON-mode позволяет точно вернуть Decimal в типизированное поле budgets. Но Decimal внутри union-поля params превращается в строку и после model_validate остаётся строкой. Следовательно, одного глобального `mode='json'` недостаточно для полного сохранения типов.

J7 дополнительно показывает зависимость поведения от необязательной библиотеки: вложенный NaN в list[Any] стандартный encoder сохраняет нестандартным NaN, orjson преобразует в null. Это не отдельный доказанный ошибочный научный результат, но обязательный негативный тест нового codec: unsupported/non-finite нельзя молча превращать в другое значение. [C08.E03, C08.E04]

**Рекомендуемое исправление.** Использовать единый версионированный wire-контракт с точным кодированием допустимых типов и согласованной политикой непригодных значений. Переиспользовать существующую canonical/typed инфраструктуру, предварительно проверив round-trip требований state/outcome; не вводить параллельный формат без необходимости. Типизированные поля могут читать точные decimal-строки по схеме; неоднозначные Any/union-поля требуют явного tag либо нормализованного предметного представления.

Не переводить Decimal в float ради скорости; не применять `default=str` ко всем неизвестным объектам; не лечить transport TypeError повторным дорогостоящим вычислением. Число байтов, hash и версия должны связываться с действительно переданным представлением. Access/tenant-проверки не заменяются digest: он устанавливает целостность bytes, не полномочия.

**Приёмка.** Непустые бюджеты, Decimal в union, вложенные типы, настоящие ArtifactRef, OutputAwareNodeOutcome; оба поддерживаемых JSON backend; cold/warm; unsupported/non-finite; повреждённый digest. Проверять значение и тип после round-trip. Существующие тесты пустого состояния и простых params прочитаны; они не объявлены отсутствующими и не выданы за покрытие Decimal. Реальные Ray/Temporal не запускались.

<!-- END_SOURCE_CARD B94 -->

## Связанные записи source ledger r19

Текст ниже исторический; current HEAD и внешние runtime API проверяются адресно при реализации. Наличие source ref не означает, что полные Git blobs/probes включены в E01.

**C05.N07.** `policy-engine/src/polisyos/scientist/orchestration/engine/state.py`. 1–210; весь возвращённый файл. Форма ExperimentState; в опытах всё равно использован явный минимальный DTO-заместитель. Git blob: `3724db92babaa2e2da1d1e35f8467159d3afe980`. [Открыть источник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/state.py).

**C08.R05. State/outcome wire serialization и начало context meta.** `policy-engine/src/polisyos/scientist/orchestration/engine/runner/serialization.py`. Запрошенные окна: 1–295, для короткого файла — до конца. Git blob `f9ddcccfbc8c53c994d74420270b260a560549df`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/runner/serialization.py).

**C08.R06. ExperimentState: контракт Decimal и мутаций.** `policy-engine/src/polisyos/scientist/orchestration/engine/state.py`. Запрошенные окна: 1–95, для короткого файла — до конца. Git blob `3724db92babaa2e2da1d1e35f8467159d3afe980`. [Закреплённый исходник](https://github.com/DenisKopylov/polisyos/blob/5fd3ebcc15637e98bbd4938de5d62ee5004504a8/policy-engine/src/polisyos/scientist/orchestration/engine/state.py).

**C08.E03. Pydantic: Decimal и режимы сериализации.** Первичная документация просмотрена 18.09.2026; не подтверждает состояние PolicyOS. [Открыть источник](https://docs.pydantic.dev/latest/api/standard_library_types/#decimals).

**C08.E04. orjson: поддерживаемые типы и error semantics.** Первичная документация просмотрена 18.09.2026; не подтверждает состояние PolicyOS. [Открыть источник](https://github.com/ijl/orjson).

Полный исходный документ и оставшиеся references: [r19](../source/PolicyOS_All_Findings_S02_r19_original.md). Организация: [TEAM_RULES](../TEAM_RULES.md), [полный runbook](../EXECUTION_GUIDE.md), [cross-boundary matrix](../CROSS_BOUNDARY_MATRIX.md).
