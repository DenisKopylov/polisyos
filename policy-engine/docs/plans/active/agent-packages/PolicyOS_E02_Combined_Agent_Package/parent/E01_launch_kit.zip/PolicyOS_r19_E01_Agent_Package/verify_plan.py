#!/usr/bin/env python3
"""Verify only this planning package. Does not import or execute PolicyOS.

Usage: python3 verify_plan.py [package_directory]
Requires Python standard library only. Exits nonzero on any discrepancy.
"""
from __future__ import annotations
import collections
import graphlib
import hashlib
import json
from pathlib import Path
import re
import sys

EXPECTED_SOURCE_SHA = '9c98584cbfa72996b058abf127f6c689f919a3421cdd563a82c84a7324ab39b5'

def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def load(root: Path, name: str):
    return json.loads((root / name).read_text(encoding='utf-8'))

def verify(root: Path) -> dict:
    root = root.resolve()
    m = load(root, 'bundle_manifest.json')
    source = (root / m['source']['copy']).read_bytes()
    require(sha(source) == EXPECTED_SOURCE_SHA == m['source']['sha256'], 'Original source bytes changed')
    s = source.decode('utf-8')
    main = (root / m['main_document']).read_text(encoding='utf-8')
    bundles = m['bundles']
    require(len(bundles) == 84, 'Expected84 B-bundles')
    ids = [b['id'] for b in bundles]
    require(len(set(ids)) == len(ids), 'Duplicate bundle ID')
    byid = {b['id']: b for b in bundles}
    assigned = collections.Counter(f for b in bundles for f in b['findings'])
    expected = {f'B{i:02d}' for i in range(1, 226)}
    require(set(assigned) == expected, 'Missing/unknown B finding')
    require(all(n == 1 for n in assigned.values()), 'A B finding has multiple primary owners')
    require(all(1 <= len(b['findings']) <= 5 for b in bundles), 'Bundle size outside1–5')
    owner = {f: b['id'] for b in bundles for f in b['findings']}
    require(owner == load(root,'finding_to_bundle.json'), 'Crosswalk differs from manifest')
    for b in bundles:
        require(set(b['depends_on']) <= set(ids), 'Unknown dependency: '+b['id'])
        require(b['id'] not in b['depends_on'], 'Self dependency: '+b['id'])
        require(set(b['related_findings']) <= expected, 'Unknown related finding: '+b['id'])
        require(b['initial_status'] == 'planned', 'Unexpected implementation claim: '+b['id'])
        require(b['checkpoint_status'] == 'not_run', 'Unexpected checkpoint completion: '+b['id'])
        require((root/b['artifact_path']).is_file(), 'Missing bundle packet: '+b['id'])
        for p in b['write_paths']+b['read_paths']:
            require(p in s, 'Owner/read path absent from actual source: '+p)
        for p in b['source_test_refs']:
            require(p in s, 'Claimed source test absent: '+p)
    topo = list(graphlib.TopologicalSorter({b['id']: b['depends_on'] for b in bundles}).static_order())
    g = load(root, 'dependency_graph.json')
    edges = {(d,b['id']) for b in bundles for d in b['depends_on']}
    require(edges == {(e['from'],e['to']) for e in g['edges']}, 'DAG JSON differs from manifest')
    require(set(g['topological_order']) == set(ids), 'Topological order has wrong nodes')
    pos = {x:i for i,x in enumerate(g['topological_order'])}
    require(all(pos[a] < pos[z] for a,z in edges), 'Invalid topological order')
    conflicts = {}
    for i,a in enumerate(bundles):
        for b in bundles[i+1:]:
            paths = sorted(set(a['write_paths']) & set(b['write_paths']))
            if paths: conflicts[tuple(sorted([a['id'],b['id']]))] = paths
    require(conflicts == {tuple(sorted(c['bundles'])): c['write_paths'] for c in g['write_conflicts']}, 'Conflict map differs from actual write sets')
    first = m['first_dispatch']
    require(len(first) == 9 and len(set(first)) == 9, 'First dispatch must have9 unique packets')
    for id in first:
        require(not byid[id]['depends_on'], 'First dispatch has unmet bundle prerequisite')
    require(not any(set(pair) <= set(first) for pair in conflicts), 'First dispatch has production write conflict')
    # Parse each original card from the exact source, not from a claimed count.
    heads = list(re.finditer(r'^#{1,2} .+$', s, re.M))
    cards = {}
    for i,head in enumerate(heads):
        match = re.match(r'## ([BS]\d+)\. (.+)', head[0])
        if match:
            end = heads[i+1].start() if i+1 < len(heads) else len(s)
            cards[match[1]] = (head.start(), end, s[head.start():end])
    require(set(cards) == expected | {f'S{i:02d}' for i in range(1,9)}, 'Original source card parser mismatch')
    ci = load(root,'source/card_index.json')
    require(set(ci) == set(cards), 'Source card index incomplete')
    rawlines = s.splitlines(keepends=True)
    for id,(a,z,text) in cards.items():
        require(ci[id]['sha256'] == sha(text.encode()), 'Card checksum mismatch '+id)
        require(''.join(rawlines[ci[id]['start_line']-1:ci[id]['end_line']]) == text, 'Raw line range mismatch '+id)
        pattern = r'<!-- SOURCE_CARD '+re.escape(id)+r' [^>]* -->\n(.*?)<!-- END_SOURCE_CARD '+re.escape(id)+r' -->'
        blocks = re.findall(pattern,main,re.S)
        require(len(blocks) == 1 and blocks[0] == text, 'Main modified or duplicated source card '+id)
        if id.startswith('B'):
            packet = (root/byid[owner[id]]['artifact_path']).read_text(encoding='utf-8')
        else:
            evo = next(e for e in m['evolution'] if e['source_direction']==id)
            packet = (root/evo['artifact_path']).read_text(encoding='utf-8')
        blocks = re.findall(pattern,packet,re.S)
        require(len(blocks)==1 and blocks[0]==text, 'Packet changed/missing source card '+id)
    # Every non-card character is kept unchanged too. Together these reproduce source exactly.
    cindex = load(root,'source/context_index.json')
    segments = [(a,z,text) for a,z,text in cards.values()]
    for f in cindex:
        text = s[f['start_char']:f['end_char']]
        require(sha(text.encode())==f['sha256'], 'Context checksum mismatch '+f['id'])
        pattern=r'<!-- SOURCE_CONTEXT '+re.escape(f['id'])+r' -->\n(.*?)<!-- END_SOURCE_CONTEXT '+re.escape(f['id'])+r' -->'
        blocks = re.findall(pattern,main,re.S)
        require(len(blocks)==1 and blocks[0]==text, 'Historical context changed '+f['id'])
        segments.append((f['start_char'],f['end_char'],text))
    segments.sort()
    cursor=0
    for a,z,text in segments:
        require(a==cursor, 'Source segmentation has a gap or overlap')
        cursor=z
    require(cursor==len(s) and ''.join(x[2] for x in segments)==s, 'Cannot reconstruct exact full source')
    evo = m['evolution']
    require(len(evo)==8 and {x['source_direction'] for x in evo}=={f'S{i:02d}' for i in range(1,9)}, 'Incomplete S mapping')
    require(all(x['initial_status']=='scope_selection_required' for x in evo), 'Evolution implicitly activated')
    allids=set(ids)|{e['id'] for e in evo}
    for e in evo: require(set(e['prerequisites_for_selected_scope'])<=allids, 'Unknown evolution prerequisite')
    graphlib.TopologicalSorter({**{b['id']:b['depends_on'] for b in bundles},**{e['id']:e['prerequisites_for_selected_scope'] for e in evo}}).prepare()
    require(set(m['T_scenarios'])=={f'T{i}' for i in range(1,22)}, 'T1–T21 mapping incomplete')
    for t,vals in m['T_scenarios'].items():require(set(vals)<=set(ids), 'Unknown T bundle '+t)
    for a in m['activation_rules']:require(set(a['bundles'])<=set(ids), 'Unknown activation bundle')
    require(not m['native_PolicyOS_tests_run'] and not m['source']['current_head_verified'], 'False execution/read claim in manifest')
    require(m['local_execution']['max_L_jobs']==2 and m['local_execution']['max_N_or_C_jobs']==1 and m['local_execution']['N_C_exclusive_of_L'], 'Resource policy mismatch')
    require([sum(m['roles'][x].values()) for x in ['minimum','default','maximum']]==[12,14,16], 'Role counts mismatch')
    # Check new package links. Historical source links are not claims of packaged artifacts.
    link_checks=0
    for name in ['README_START_HERE.md','BUNDLE_INDEX.md']:
        text=(root/name).read_text(encoding='utf-8')
        for target in re.findall(r'\]\(([^)]+)\)',text):
            if target.startswith(('https:','http:','#')):continue
            require((root/target.split('#')[0]).exists(), 'Broken package link '+name+': '+target)
            link_checks+=1
    anchors=set(re.findall(r'<a id="([^"]+)"',main))
    for target in re.findall(r'\]\(#([^)]+)\)',main):
        require(target in anchors,'Broken explicit main anchor '+target)
        link_checks+=1
    for cp in range(1,7):require((root/f'checkpoints/K{cp}.md').is_file(),'Missing checkpoint packet')
    return {'status':'passed','scope':'planning-package integrity only; no PolicyOS tests or Mac benchmark',
            'B_findings':225,'B_bundles':84,'S_directions':8,'source_bytes':len(source),'source_lines':len(s.splitlines()),
            'source_sha256':sha(source),'all_233_cards_verbatim':True,'all_noncard_context_verbatim':True,
            'full_original_reconstruction':True,'unique_primary_assignment':True,'bundle_sizes':dict(sorted(collections.Counter(len(b['findings']) for b in bundles).items())),
            'DAG_acyclic':True,'dependency_edges':len(edges),'write_conflict_pairs':len(conflicts),
            'first_9_dispatch_write_disjoint':True,'all_21_T_scenarios_mapped':True,
            'new_links_checked':link_checks,'native_PolicyOS_tests_run':False,'current_HEAD_reaudited':False}

def main() -> int:
    try:
        root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent
        result=verify(root)
        print(json.dumps(result,ensure_ascii=False,indent=2))
        return 0
    except Exception as exc:
        print(json.dumps({'status':'failed','error':str(exc)},ensure_ascii=False),file=sys.stderr)
        return 1
if __name__=='__main__':
    raise SystemExit(main())
