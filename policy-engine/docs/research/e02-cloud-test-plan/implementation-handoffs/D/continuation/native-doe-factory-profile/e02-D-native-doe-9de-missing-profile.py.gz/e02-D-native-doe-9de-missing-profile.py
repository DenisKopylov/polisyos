from pathlib import Path
import importlib.abc,json,subprocess,sys
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert source=='9de48387c01e7437f31093829610bb461fa3defe'
class MissingBoTorch(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname=='botorch' or fullname.startswith('botorch.'):
   raise ModuleNotFoundError("controlled unavailable optional BoTorch profile",name=fullname)
sys.meta_path.insert(0,MissingBoTorch())
import pytest
argv=['tests/unit/scientist/methods/autotune/test_native_doe_factory.py', '--collect-only', '-rs', '--basetemp=/tmp/e02-D-native-doe-9de-missing-profile-53820e229a9f43d1b982a4af187dda33', '--junitxml=/tmp/e02-D-native-doe-9de-missing-profile-junit.xml']
print(json.dumps({'source':source,'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),'executable':sys.executable,'python':sys.version,'argv':argv,'control':'actual import machinery rejects BoTorch; no mock backend or numerical execution'}),flush=True)
status=pytest.main(argv)
print(json.dumps({'pytest_exit':int(status),'scope':'expected one module SKIP/UNRUN and no collected numerical cases; exit5 is no-tests-collected, not PASS'}),flush=True)
raise SystemExit(status)
