from pathlib import Path
import hashlib,importlib,json,subprocess,sys
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert source=='9de48387c01e7437f31093829610bb461fa3defe',source
argv=['tests/unit/scientist/methods/autotune/test_native_doe_factory.py::test_ordinary_spec_metadata_changes_actual_proposal_and_typed_persisted_consumer', '-s', '--basetemp=/tmp/e02-D-native-doe-9de-positive-7e2a8701ca434a3a9342c05320aeb1ac', '--junitxml=/tmp/e02-D-native-doe-9de-positive-junit.xml']
print(json.dumps({'source':source,'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),'argv':argv,'python':sys.version,'executable':sys.executable}),flush=True)
import pytest,torch,botorch,gpytorch
from importlib.metadata import version
names=['polisyos.scientist.methods.autotune.models','polisyos.scientist.methods.autotune.runtime','polisyos.scientist.methods.autotune.bayesian_generator','polisyos.scientist.methods.autotune.sensitivity_bridge','polisyos.scientist.methods.search.sensitivity_adapter','polisyos.scientist.methods.search.service','polisyos.scientist.methods.search.controller','polisyos.scientist.methods.search.run_state','polisyos.scientist.methods.search.strategies.base','polisyos.scientist.methods.search.strategies.bayesian','polisyos.scientist.methods.search.strategies.space','polisyos.scientist.methods.search.strategies.types','polisyos.scientist.methods.doe._receipt','polisyos.scientist.methods.doe.analysis','polisyos.scientist.methods.doe.designs','polisyos.scientist.methods.doe.sampling','polisyos.core.artifacts.store','polisyos.core.artifacts._integrity_ops']
modules=[importlib.import_module(n) for n in names]
print(json.dumps({'versions':{'pytest':pytest.__version__,'torch':torch.__version__,'botorch':botorch.__version__,'gpytorch':gpytorch.__version__,'SALib':version('SALib')},'origins':{m.__name__:{'path':m.__file__,'sha256':hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()} for m in modules},'backend_paths':{'torch':torch.__file__,'botorch':botorch.__file__,'gpytorch':gpytorch.__file__}}),flush=True)
for m in modules:
 p=Path(m.__file__); relative=str(p.relative_to(Path.cwd()))
 expected=subprocess.check_output(['git','show',source+':policy-engine/'+relative])
 assert expected==p.read_bytes(),relative
print(json.dumps({'all18_origins_git_byte_match':True}),flush=True)
status=pytest.main(argv)
print(json.dumps({'pytest_exit':int(status),'new_default_factory_scope_only':True,'gp_numerical_model_fit_claim':False}),flush=True)
raise SystemExit(status)
