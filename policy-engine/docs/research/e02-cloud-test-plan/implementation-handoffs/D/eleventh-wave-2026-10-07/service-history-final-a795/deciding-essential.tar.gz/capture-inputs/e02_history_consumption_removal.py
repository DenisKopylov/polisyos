"""Remove only the actual inner strategy/consumed-corpus proof for a negative control."""
from __future__ import annotations


def pytest_configure(config):
    from polisyos.scientist.methods.search.strategies.adapter import StrategyAdapter

    original = StrategyAdapter._validate_strategy_consumption

    def removed_owner_consumption(self, rows, strategy_state):
        # Canonical corpus/cursor/digest/config/CAS/history gates remain active.
        # Only the owner's actual consumed-state relation is deliberately removed.
        return None

    StrategyAdapter._validate_strategy_consumption = removed_owner_consumption
    config._e02_original_consumption_proof = original


def pytest_unconfigure(config):
    from polisyos.scientist.methods.search.strategies.adapter import StrategyAdapter

    original = getattr(config, "_e02_original_consumption_proof", None)
    if original is not None:
        StrategyAdapter._validate_strategy_consumption = original
