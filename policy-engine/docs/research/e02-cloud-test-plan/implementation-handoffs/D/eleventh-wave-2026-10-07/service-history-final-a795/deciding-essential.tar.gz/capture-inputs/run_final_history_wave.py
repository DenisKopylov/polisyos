"""Immutable generic history/restore consumer capture; no source/index mutations."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
import xml.etree.ElementTree as ET
ROOT=Path('/dev/shm/e02-D-oct07-continuation'); PRODUCT=ROOT/'policy-engine'
BASE=Path('/dev/shm/e02-D-service-history-binding-drafts')
PYTHON='/tmp/e02-D-runtime-minimal-20261006/bin/python'
SOURCE=sys.argv[1];NAME=sys.argv[2];OUT=Path(sys.argv[3]);OUT.mkdir(parents=True,exist_ok=True)
selectors=json.loads(Path(sys.argv[4]).read_text())
plugin=sys.argv[5] if len(sys.argv)>5 else None

def git(*args):return subprocess.check_output(['git','-C',str(ROOT),*args],text=True).strip()
def inventory():
 result={}
 for entry in subprocess.check_output(['git','-C',str(ROOT),'ls-files','-s','-z']).decode().split('\0'):
  if not entry:continue
  stage,p=entry.split('\t',1);f=ROOT/p
  result[p]={'index':stage,'available':f.is_file(),**({'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} if f.is_file() else {})}
 return result
assert git('rev-parse','HEAD')==SOURCE,'candidate HEAD mismatch'
status=git('status','--porcelain=v1');assert not status,'candidate not clean'
argv=[PYTHON,'-m','pytest','-o','addopts=','-p','no:cacheprovider','--noconftest','--import-mode=importlib','-p','service_history_observer','-q','-s','-ra','--basetemp='+str(OUT/(NAME+'-fixtures')),'--junitxml='+str(OUT/(NAME+'.junit.xml'))]
if plugin:argv+=['-p',plugin]
argv+=selectors
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=os.pathsep.join([str(PRODUCT/'src'),str(PRODUCT),str(BASE)]),E02_SERVICE_OBSERVER_OUTPUT=str(OUT/(NAME+'.origins-phases.json')))
record={'name':NAME,'source_sha':SOURCE,'source_tree':git('rev-parse','HEAD^{tree}'),'status_before':status,'argv':argv,'cwd':str(PRODUCT),'environment_overrides':{k:env[k] for k in ['PYTHONDONTWRITEBYTECODE','PYTHONPATH','E02_SERVICE_OBSERVER_OUTPUT']},'runtime':json.loads(subprocess.check_output([PYTHON,'-c','import sys,platform,json,importlib.metadata as m; print(json.dumps({"python":sys.version,"executable":sys.executable,"platform":platform.platform(),"packages":{n:m.version(n) for n in ["pytest","pydantic","numpy","scipy"]}}))'],text=True)),'backend_scope':'Actual native SearchService/Runner/FileSystemCAS, supported Scalar/Grid/RL and complete owner consumption witness. Native wrapper profile-only refusal does not claim GP execution; missing numerical dependencies remain UNRUN for numerical properties.','no_artificial_quotas':True,'started_at':datetime.datetime.now(datetime.UTC).isoformat(),'inputs_before':inventory(),'harness':{'path':str(Path(__file__)),'sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},'observer':{'path':str(BASE/'service_history_observer.py'),'sha256':hashlib.sha256((BASE/'service_history_observer.py').read_bytes()).hexdigest()}}
if plugin:record['removal_plugin']={'path':str(BASE/(plugin+'.py')),'sha256':hashlib.sha256((BASE/(plugin+'.py')).read_bytes()).hexdigest(),'scope':'Single inner consumption proof removal; all count/rows/digest/config/raw history/CAS identities retained.'}
command=OUT/(NAME+'.command.json');assert not command.exists(),'outputs immutable/exist';command.write_text(json.dumps(record,indent=2)+'\n')
start=time.monotonic()
with (OUT/(NAME+'.stdout.txt')).open('w') as stdout,(OUT/(NAME+'.stderr.txt')).open('w') as stderr:
 completed=subprocess.run(argv,cwd=PRODUCT,env=env,stdout=stdout,stderr=stderr)
record.update(returncode=completed.returncode,elapsed_seconds=time.monotonic()-start,completed_at=datetime.datetime.now(datetime.UTC).isoformat(),source_after=git('rev-parse','HEAD'),status_after=git('status','--porcelain=v1'),inputs_after=inventory())
record['same_inputs']=record['inputs_before']==record['inputs_after'];record['outputs']={}
for ext in ['stdout.txt','stderr.txt','junit.xml','origins-phases.json']:
 p=OUT/(NAME+'.'+ext);record['outputs'][ext]={'available':p.is_file(),**({'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} if p.is_file() else {})}
record['cases']={k:0 for k in ['PASS','FAIL','ERROR','SKIP']};p=OUT/(NAME+'.junit.xml')
if p.is_file():
 for case in ET.parse(p).getroot().iter('testcase'):
  tag=next((t for t in ['failure','error','skipped'] if case.find(t)is not None),None)
  record['cases'][{None:'PASS','failure':'FAIL','error':'ERROR','skipped':'SKIP'}[tag]]+=1
command.write_text(json.dumps(record,indent=2)+'\n')
summary={k:record[k] for k in ['name','source_sha','returncode','elapsed_seconds','cases','same_inputs','outputs']};(OUT/(NAME+'.summary.json')).write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
