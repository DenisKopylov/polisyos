const { chromium } = require('/workspace/e02-D-published-root/policy-engine/apps/runtime-dashboard/node_modules/playwright');
const started = Date.now();
(async () => {
  let browser;
  try {
    browser = await chromium.launch({ headless: true });
    const cdp = await browser.newBrowserCDPSession();
    const version = await cdp.send('Browser.getVersion');
    const commandLine = await cdp.send('Browser.getBrowserCommandLine');
    const page = await browser.newPage();
    await page.goto('data:text/html,<title>e02-D243 native readiness</title><p id="native">ready</p>');
    const observed = await page.locator('#native').textContent();
    if (observed !== 'ready') throw new Error('Actual Chromium page readiness mismatch: ' + observed);
    console.log('ACTUAL_CHROMIUM_DEVTOOLS=' + JSON.stringify({ source_sha: '243ca4e04d6fcb2cbe8c9494e68f06c75fe749a3', source_tree: 'f3763c0911f1f80d8c5ee049667045a594fb55c2', node: process.version, execPath: process.execPath, playwright: require('/workspace/e02-D-published-root/policy-engine/apps/runtime-dashboard/node_modules/playwright/package.json').version, browsersPath: process.env.PLAYWRIGHT_BROWSERS_PATH, browserVersion: browser.version(), cdpVersion: version, commandLine, pageText: observed, elapsedMilliseconds: Date.now() - started }));
  } finally {
    if (browser) await browser.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
