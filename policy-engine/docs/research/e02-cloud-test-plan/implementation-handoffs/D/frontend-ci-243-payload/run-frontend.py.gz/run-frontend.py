import concurrent.futures
import dataclasses
import hashlib
import json
import os
import pathlib
import subprocess
import time

ROOT = pathlib.Path('/workspace/e02-D-published-root')
PRODUCT = ROOT / 'policy-engine'
APP = PRODUCT / 'apps/runtime-dashboard'
OUT = pathlib.Path('/workspace/e02-D2-receipts/frontend-243')
SOURCE = '243ca4e04d6fcb2cbe8c9494e68f06c75fe749a3'
ENV = dict(os.environ, PATH='/home/agent/.npm/_npx/52027bd8fc0022aa/node_modules/node/bin:/dev/shm/e02-D-parity-env/bin:' + os.environ['PATH'], PYTHONPATH=str(PRODUCT / 'src') + ':' + str(PRODUCT), PYTHONDONTWRITEBYTECODE='1')


def assert_source():
    actual = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip()
    if actual != SOURCE:
        raise RuntimeError('Source changed during frozen frontend execution: ' + actual)


def run(label, pipelines, literal=None, cwd=APP, extra_env=None):
    assert_source()
    log_path = OUT / (label + '.txt')
    start = time.monotonic()
    steps = []
    with log_path.open('w') as log:
        header = {'source_sha': SOURCE, 'source_tree': 'f3763c0911f1f80d8c5ee049667045a594fb55c2', 'cwd': str(cwd), 'pipelines': pipelines, 'literal_argv': literal, 'env_overrides': {k: ENV[k] for k in ['PATH', 'PYTHONPATH', 'PYTHONDONTWRITEBYTECODE']}, 'numeric_worker_caps_added': False}
        log.write(json.dumps(header) + '\n'); log.flush()
        for argv in pipelines:
            step_start = time.monotonic()
            result = subprocess.run(argv, cwd=cwd, env=dict(ENV, **(extra_env or {})), stdout=log, stderr=subprocess.STDOUT)
            step = {'argv': argv, 'exit_code': result.returncode, 'wall_seconds': time.monotonic() - step_start}
            steps.append(step)
            log.write('\nSTEP=' + json.dumps(step) + '\n'); log.flush()
            if result.returncode:
                break
        assert_source()
        record = {'name': label, 'source_sha': SOURCE, 'exit_code': steps[-1]['exit_code'], 'wall_seconds': time.monotonic() - start, 'steps': steps, 'not_run_due_to_and_semantics': pipelines[len(steps):], 'log_path': str(log_path), 'literal_argv': literal}
        log.write('\nMEASUREMENT=' + json.dumps(record) + '\n')
    data = log_path.read_bytes()
    record.update(log_sha256=hashlib.sha256(data).hexdigest(), log_bytes=len(data))
    (OUT / (label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    return record


def typecheck_build_storybook():
    return [run('typecheck', [['npm', 'run', 'typecheck']]), run('build', [['npm', 'run', 'build']]), run('build-storybook', [['npm', 'run', 'build-storybook']])]


def contracts_coverage():
    contract = run('contracts', [['npm', 'run', 'contracts:verify']])
    coverage = run('coverage-uncapped', [['corepack', 'pnpm', 'exec', 'vitest', 'run', '--coverage', '--testTimeout=20000', '--hookTimeout=20000'], ['node', './scripts/check-coverage-ratchet.mjs']], literal=['npm', 'run', 'test:coverage'])
    return [contract, coverage]


def readiness():
    snippet = '''import dataclasses,json
from tools.devx.workspace import doctor
results=[doctor._check_python(),doctor._check_node(),doctor._check_uv(),doctor._check_playwright()]
print("ACTUAL_DOCTOR_READINESS="+json.dumps([dataclasses.asdict(row) for row in results]))
raise SystemExit(0 if all(row.ok for row in results) else 1)
'''
    return [run('doctor-readiness', [['/dev/shm/e02-D-parity-env/bin/python', '-c', snippet]], cwd=PRODUCT, extra_env={'DEBUG': 'pw:browser'}), run('node-pnpm-readiness', [['node', '--version'], ['corepack', 'pnpm', '--version']], cwd=PRODUCT)]


groups = [typecheck_build_storybook, contracts_coverage, readiness,
          lambda: [run('lint', [['npm', 'run', 'lint']])],
          lambda: [run('format', [['npm', 'run', 'format:check']])],
          lambda: [run('architecture', [['npm', 'run', 'check:architecture']])]]
results = []
with concurrent.futures.ThreadPoolExecutor() as pool:
    futures = [pool.submit(group) for group in groups]
    for future in concurrent.futures.as_completed(futures):
        results.extend(future.result())
assert_source()
(OUT / 'all-results.json').write_text(json.dumps({'source_sha': SOURCE, 'results': results, 'serialization': ['typecheck/build typecheck share TypeScript cache; build and Storybook share Vite cache', 'contract and coverage producers share Vitest cache; sequential only for this shared writer', 'No artificial CPU/process/test worker caps added; six independent chains started together'], 'literal_coverage_status': 'UNRUN/incompatible source maxWorkers=1; uncapped equivalent removes only cap and retains all selectors/timeouts/ratchet && semantics', 'cleanup': 'No manual cleanup; source-default tools may clean own generated output or transient directories; actual observed scope recorded separately'}, indent=2) + '\n')
