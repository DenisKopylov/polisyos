import hashlib
import json
import os
import pathlib
import subprocess
import time

ROOT = pathlib.Path('/workspace/e02-D-published-root')
PRODUCT = ROOT / 'policy-engine'
APP = PRODUCT / 'apps/runtime-dashboard'
OUT = pathlib.Path('/workspace/e02-D2-receipts/frontend-243')
SOURCE = '243ca4e04d6fcb2cbe8c9494e68f06c75fe749a3'
ENV = dict(os.environ, PATH=str(OUT / 'bin') + ':/home/agent/.npm/_npx/52027bd8fc0022aa/node_modules/node/bin:/dev/shm/e02-D-parity-env/bin:' + os.environ['PATH'], PYTHONPATH=str(PRODUCT / 'src') + ':' + str(PRODUCT), PYTHONDONTWRITEBYTECODE='1', PLAYWRIGHT_BROWSERS_PATH='/workspace/e02-D2-receipts/browser-chromium-243', DEBUG='pw:browser')

def run(name, argv, cwd):
    assert subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip() == SOURCE
    before = time.monotonic()
    path = OUT / (name + '.txt')
    with path.open('w') as log:
        log.write(json.dumps({'source_sha': SOURCE, 'source_tree': 'f3763c0911f1f80d8c5ee049667045a594fb55c2', 'argv': argv, 'cwd': str(cwd), 'env_overrides': {key: ENV[key] for key in ['PATH', 'PYTHONPATH', 'PYTHONDONTWRITEBYTECODE', 'PLAYWRIGHT_BROWSERS_PATH', 'DEBUG']}, 'numeric_worker_caps_added': False}) + '\n')
        log.flush()
        result = subprocess.run(argv, cwd=cwd, env=ENV, stdout=log, stderr=subprocess.STDOUT)
        record = {'source_sha': SOURCE, 'name': name, 'argv': argv, 'cwd': str(cwd), 'exit_code': result.returncode, 'wall_seconds': time.monotonic() - before}
        log.write('\nMEASUREMENT=' + json.dumps(record) + '\n')
    assert subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip() == SOURCE
    data = path.read_bytes()
    record.update(log_path=str(path), log_sha256=hashlib.sha256(data).hexdigest(), log_bytes=len(data))
    (OUT / (name + '.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)

snippet = '''import dataclasses,json
from tools.devx.workspace import doctor
results=[doctor._check_python(),doctor._check_node(),doctor._check_uv(),doctor._check_playwright()]
print("ACTUAL_DOCTOR_READINESS="+json.dumps([dataclasses.asdict(row) for row in results]))
raise SystemExit(0 if all(row.ok for row in results) else 1)
'''
run('doctor-readiness-disk-browser', ['/dev/shm/e02-D-parity-env/bin/python', '-c', snippet], PRODUCT)
