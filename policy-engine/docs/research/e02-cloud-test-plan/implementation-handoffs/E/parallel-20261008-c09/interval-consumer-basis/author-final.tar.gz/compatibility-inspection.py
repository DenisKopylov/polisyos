import json,sys,inspect,tomllib;from pathlib import Path
from tools.ops_runners.release.check_compatibility_release_gates import _validate_fragments
from polisyos.scientist.governance import CalibrationLeaderboard as Facade
from polisyos.scientist.governance.calibration_leaderboard import CalibrationLeaderboard as Canonical
root=Path.cwd(); policy=tomllib.loads((root/'architecture/gates/compatibility_release.toml').read_text());fragments=[]
for name in ('2026-10-08-c09-interval-consumer-basis.toml','2026-10-08-c09-mc-mean-error.toml'):
 p=root/'release-fragments/unreleased'/name;f=tomllib.loads(p.read_text());f['__path__']=str(p.relative_to(root));fragments.append(f)
errors,findings=_validate_fragments(root,policy,fragments,breaking_classes=());assert not errors
assert Facade is Canonical;assert Canonical()._store is None
print(json.dumps({'source':'adb66080e3ac64d73b3faa85d693a47c6c284427','selected_fragment_errors':[x.as_dict() for x in errors],'selected_fragment_findings':[x.as_dict() for x in findings],'same_object_governance_alias':True,'canonical_signature':str(inspect.signature(Canonical)),'legacy_default_construction':'diagnostic/no CAS'},indent=2))
