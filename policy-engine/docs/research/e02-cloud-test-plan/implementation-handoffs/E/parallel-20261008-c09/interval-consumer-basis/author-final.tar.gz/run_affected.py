import hashlib,json,os,resource,subprocess,time,xml.etree.ElementTree as E
from pathlib import Path
root=Path("/dev/shm/e02-orch03-20261008/c09");product=root/"policy-engine";out=Path(__file__).parent
source="adb66080e3ac64d73b3faa85d693a47c6c284427";tree="f2c1f993052c25586420d07c766b868f632fbf39"
assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip()==source
assert not subprocess.check_output(["git","status","--porcelain"],cwd=root,text=True).strip()
selected=json.loads((out/"selected-inputs.json").read_text());selectors=selected["interval_consumers"]+selected["mean_law"]
py="/workspace/e02-F-closeout-20261006/policy-engine/.venv/bin/python"
cmd=[py,"-m","pytest","-q","-p","source_origins",*selectors,"--basetemp="+str(out/"affected-bases"),"--junitxml="+str(out/"affected.junit.xml"),"-o","cache_dir="+str(out/"affected-cache")]
env=dict(os.environ,PYTHONPATH=str(out)+os.pathsep+str(product/"src"),C09_SOURCE_ROOT=str(root),C09_SOURCE_SHA=source,C09_ORIGINS_OUTPUT=str(out/"loaded-module-origins.json"))
start=time.monotonic();interrupted=None
with (out/"affected.stdout").open("wb") as so,(out/"affected.stderr").open("wb") as se:
 try:r=subprocess.run(cmd,cwd=product,env=env,stdout=so,stderr=se,timeout=240);rc=r.returncode
 except subprocess.TimeoutExpired:rc=None;interrupted="harness_timeout_240_seconds"
record={"source_sha":source,"source_tree":tree,"command":cmd,"cwd":str(product),"returncode":rc,"interrupted":interrupted,"wall_seconds":time.monotonic()-start,"max_rss_kib":resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,"source_only_review_gate":"full non-author GO before invocation","outputs":{}}
for name in ["affected.stdout","affected.stderr","affected.junit.xml","loaded-module-origins.json"]:
 f=out/name
 if f.exists():record["outputs"][name]={"bytes":f.stat().st_size,"sha256":hashlib.sha256(f.read_bytes()).hexdigest()}
if (out/"affected.junit.xml").exists():
 suites=list(E.parse(out/"affected.junit.xml").getroot().iter("testsuite"));record["denominator"]={k:sum(int(x.attrib.get(k,0)) for x in suites) for k in ["tests","failures","errors","skipped"]}
(out/"affected.execution.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record,indent=2));print((out/"affected.stdout").read_text()[-12000:]);raise SystemExit(rc or (1 if interrupted else 0))
