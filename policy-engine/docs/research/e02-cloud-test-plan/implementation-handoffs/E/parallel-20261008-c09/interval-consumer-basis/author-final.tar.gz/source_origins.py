import hashlib,json,os,subprocess,sys
from pathlib import Path
import pytest

def pytest_sessionfinish(session,exitstatus):
 root=Path(os.environ["C09_SOURCE_ROOT"]).resolve(); source=os.environ["C09_SOURCE_SHA"]
 expected={}
 listing=subprocess.check_output(["git","ls-tree","-r",source,"policy-engine/src"],cwd=root,text=True)
 for line in listing.splitlines():
  header,path=line.split("\t",1);expected[path]=header.split()[2]
 rows=[];mismatches=[]
 for name,module in sorted(sys.modules.items()):
  file=getattr(module,"__file__",None)
  if not name.startswith("polisyos") or not file:continue
  path=Path(file).resolve();data=path.read_bytes()
  actual=hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
  try:relative=path.relative_to(root).as_posix()
  except ValueError:relative=str(path)
  row={"module":name,"path":relative,"actual_git_blob":actual,"expected_git_blob":expected.get(relative)}
  rows.append(row)
  if actual!=expected.get(relative):mismatches.append(row)
 record={"source_sha":source,"source_tree":subprocess.check_output(["git","rev-parse",source+"^{tree}"],cwd=root,text=True).strip(),"loaded_denominator":len(rows),"byte_mismatches":len(mismatches),"mismatches":mismatches,"rows":rows,"pytest_exitstatus":int(exitstatus)}
 Path(os.environ["C09_ORIGINS_OUTPUT"]).write_text(json.dumps(record,indent=2)+"\n")
 if mismatches:session.exitstatus=pytest.ExitCode.INTERNAL_ERROR
