import json,sys,runpy,hashlib,subprocess
from pathlib import Path
root=Path("/dev/shm/e02-orch03-20261008/c09");sys.path.insert(0,str(root/"policy-engine/src"))
from polisyos.core.artifacts import FileSystemCAS
from polisyos.ir.analytics.backtest import load_backtest_report,persist_backtest_report
from polisyos.scientist.methods.backtesting.orchestrator import BacktestOrchestrator
from polisyos.scientist.methods.backtesting.plan import HistoricalValidationPlan,PredictionSource
from polisyos.scientist.methods.backtesting.temporal import TemporalEvaluationResult,build_temporal_backtest_report
out=Path(sys.argv[1]);out.mkdir(exist_ok=True);store=FileSystemCAS(out/"CAS");history=out/"history.json";history.write_text(json.dumps({"m":[0.,0.,0.]}))
report=BacktestOrchestrator(cas=store).run([HistoricalValidationPlan(plan_id="partial",historical_data_path=str(history),prediction_source=PredictionSource.PROVIDED,predicted_outcomes={"m":[0.,0.,0.]},ground_truth_outcomes={"m":[0.,0.,0.]},prediction_intervals={"m":[(-1.,1.)]})])
carrier=TemporalEvaluationResult(scenario=report.scenarios[0],pointwise_metrics={},functional_metrics={},uncertainty_metrics={"band_coverage":1.},diagnostics_checks={"complete":True},gating_checks={},thresholds={},acceptance_checks={},expected_outcome="pass",actual_outcome="pass",matches_expected_outcome=True,passes=True)
projection=build_temporal_backtest_report(report_id="partial-projection",evaluations=[carrier],metadata={"temporal_summary":{"passes_all":True},"annotation":"keep"})
ref=persist_backtest_report(store,projection);fresh=load_backtest_report(FileSystemCAS(out/"CAS"),ref)
record={"source":subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip(),"ref":ref.model_dump(mode="json"),"degraded":fresh.degraded,"trust_eligible":fresh.trust_eligible,"summary":fresh.metadata["temporal_summary"],"annotation":fresh.metadata["annotation"],"requested":fresh.scenarios[0].interval_requested_count,"evaluated":fresh.scenarios[0].interval_evaluated_count}
print(json.dumps(record,indent=2));(out/"result.json").write_text(json.dumps(record,indent=2)+"\n")
assert fresh.metadata["temporal_summary"]["passes_all"] is False,"caller marker replaced recomputed temporal summary"
