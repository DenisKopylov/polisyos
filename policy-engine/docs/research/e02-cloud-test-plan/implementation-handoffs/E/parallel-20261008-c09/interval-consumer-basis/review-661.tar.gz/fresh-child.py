from __future__ import annotations
import hashlib,json,os,resource,subprocess,sys,time
from pathlib import Path
from polisyos.core.artifacts import FileSystemCAS
from polisyos.core.artifacts.manifest import ArtifactRef
from polisyos.core.artifacts.ir_adapter import build_ir_artifact_store
from polisyos.ir.analytics.backtest import load_backtest_report
from polisyos.ir.registry.refs import BacktestReportRef,UncertaintyEnvelopeRef
from polisyos.ir.analytics.uncertainty import load_uncertainty_envelope
from polisyos.scientist.governance.calibration_validation import load_calibration_validation_bundle
from polisyos.calibration.forecast_bridge import load_empirical_calibration_evidence
here=Path(__file__).resolve().parent; start=time.monotonic(); source='66134569f999951e8eefef737424f12aeba24616'; output=[]
for item in json.loads((here/'child-refs.json').read_text()):
    store=FileSystemCAS(item['cas_root'])
    if item['type']=='validation': fresh=load_calibration_validation_bundle(store,ArtifactRef.model_validate(item['ref']))
    elif item['type']=='backtest': fresh=load_backtest_report(store,BacktestReportRef.model_validate(item['ref']))
    elif item['type']=='evidence': fresh=load_empirical_calibration_evidence(store,item['ref'])
    elif item['type']=='uncertainty': fresh=load_uncertainty_envelope(build_ir_artifact_store(item['cas_root']),UncertaintyEnvelopeRef.model_validate(item['ref']))
    else: raise AssertionError(item['type'])
    payload=fresh.model_dump(mode='json');assert payload==item['payload'],item['label']
    output.append({'label':item['label'],'type':item['type'],'ref':item['ref'],'full_payload_matches':True,'cas_root':item['cas_root'],'payload_sha256':hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':')).encode()).hexdigest()})
origins=[]
for name,module in sorted(sys.modules.items()):
    if not name.startswith('polisyos') or not getattr(module,'__file__',None): continue
    path=Path(module.__file__).resolve()
    if path.suffix!='.py':continue
    assert path.is_relative_to(here/'input'),str(path)
    rel=path.relative_to(here/'input').as_posix();raw=path.read_bytes()
    expected=subprocess.check_output(['git','rev-parse',source+':'+rel],cwd='/workspace/e02-F-closeout-20261006',text=True).strip()
    actual=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();assert actual==expected,(name,rel)
    origins.append({'module':name,'path':str(path),'blob':actual,'sha256':hashlib.sha256(raw).hexdigest()})
(here/'fresh-child-origins.json').write_text(json.dumps(origins,indent=2,sort_keys=True))
print(json.dumps({'source':source,'tree':'a1d408e8c9ead9573a9ad846b6672d9c6dc7506e','pid':os.getpid(),'interpreter':sys.version,'exe':sys.executable,'fresh_child_reader':True,'refs':output,'loaded_origins':len(origins),'origin_mismatches':0,'body_seconds':time.monotonic()-start,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'property':'PASS complete native persisted payload readback; expected-removal payloads preserved as controls','authority':'no Runtime/S10/scientific admission'},indent=2,sort_keys=True))
