from __future__ import annotations
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time
from datetime import UTC, datetime, timedelta
from decimal import Decimal

from polisyos.core.artifacts import FileSystemCAS
from polisyos.core.artifacts.store import PutOptions
from polisyos.core.canon import CanonSpec
from polisyos.ir.analytics.backtest import load_backtest_report, persist_backtest_report
from polisyos.ir.analytics.interference import (
    ExposureMappingType, InterferenceCertificate, InterferenceEffectDecomposition,
    InterferenceMethod, NetworkInterferenceReport,
)
from polisyos.ir.artifacts import InputRef, put_json_artifact
from polisyos.ir.observation.bundles import BacktestPlanBundle, ContractCompatibilityTarget
from polisyos.ir.observation.contract_compilers import SpecificationCurveInput
from polisyos.scientist.governance.backtest_matrix import BacktestKind
from polisyos.scientist.governance.calibration import CalibrationAdversarialResult, CalibrationGovernanceReport
from polisyos.scientist.governance.calibration_validation import (
    CalibrationValidationRunner, CalibrationValidationRunnerInput, load_calibration_validation_bundle,
)
from polisyos.scientist.methods.backtesting.plan import HistoricalValidationPlan, PredictionSource
from polisyos.scientist.methods.backtesting.temporal import TemporalEvaluationResult, build_temporal_backtest_report
from polisyos.scientist.methods.discovery.utility_judge import DownstreamUtilityReport, HypothesisUtilityScore
from polisyos.calibration import forecast_bridge as fb

HERE = Path(__file__).resolve().parent
INPUT = HERE / 'input'
GITROOT = Path('/workspace/e02-F-closeout-20261006')
SOURCE = '66134569f999951e8eefef737424f12aeba24616'
child_refs = []
def json_value(value):
    if hasattr(value, 'model_dump'): return value.model_dump(mode='json')
    if isinstance(value, (datetime, Path)): return str(value)
    if isinstance(value, Decimal): return str(value)
    raise TypeError(type(value).__name__)
class RecordingList(list):
    def append(self, value):
        super().append(json.loads(json.dumps(value, default=json_value, allow_nan=False)))
        (HERE/'progress-records.json').write_text(json.dumps(self,sort_keys=True,indent=2))
records = RecordingList()
CACHED={r['label']:r for r in json.loads((HERE/'attempt-2/progress-records.json').read_text())}
started = time.monotonic()

def plans(label, intervals):
    folder = HERE / 'attempt-2-fixtures' / label
    folder.mkdir(parents=True, exist_ok=True)
    bundles = {}
    for kind in BacktestKind:
        path = folder / f'{kind.value}.json'
        path.write_text(json.dumps({'metric': [1., 1., 1.]}))
        plan = HistoricalValidationPlan(
            plan_id=kind.value, historical_data_path=str(path),
            prediction_source=PredictionSource.PROVIDED,
            predicted_outcomes={'metric': [1., 1., 1.]},
            ground_truth_outcomes={'metric': [1., 1., 1.]},
            prediction_intervals=None if intervals is None else {'metric': intervals},
            model_spec_ref='model://oracle/interval/v1', policy_spec_ref='policy://oracle/interval/v1',
            metadata={'interval_admission': {'status': 'evaluated', 'requested_count': 3, 'evaluated_count': 3, 'availability': 1.}},
        )
        bundles[kind] = BacktestPlanBundle(
            contract_target=ContractCompatibilityTarget(contract_id=f'oracle-{kind.value}', contract_fqn='polisyos.ir.observation.bundles.BacktestPlanBundle'),
            required_fields=['metric'], holdout_windows=['fixed-three-row-holdout'],
            plans=[plan.model_dump(mode='json')], historical_payloads={'metric': {'values': [1., 1., 1.]}},
        )
    return bundles

def prerequisites():
    return {
        'governance_report': CalibrationGovernanceReport(verdict='approve', adversarial_results=[
            CalibrationAdversarialResult(alias='strategic_gaming_adversarial', suite_id='oracle-strategic', required=True, status='passed'),
            CalibrationAdversarialResult(alias='multiplicity_disclosure_adversarial', suite_id='oracle-multiplicity', required=True, status='passed'),
        ]),
        'specification_curve_input': SpecificationCurveInput(specification_ids=['s1', 's2', 's3'], estimates=[.3, .28, .32], standard_errors=[.1, .1, .1]),
        'downstream_utility_report': DownstreamUtilityReport(scores=[HypothesisUtilityScore(hypothesis_id='h1', identification_status='identified', identifiability_score=1., stability_score=.8, transportability_score=.82, composite_score=.9, rank=1)], recommended_shortlist=['h1']),
        'network_interference_report': NetworkInterferenceReport(method=InterferenceMethod.PARTIAL_IPW, status='success', effects=InterferenceEffectDecomposition(direct_effect=.1, spillover_effect=.02, total_effect=.12, n_units=8, n_treated=3), exposure_mapping=ExposureMappingType.FRACTIONAL, n_units=8, n_treated=3),
        'interference_certificate': InterferenceCertificate(supported_query_family='spillover', fallback_mode='pairwise', reduction_error_bound=.05),
        'strategic_summary': {'fallback_mode': 'exact_equilibrium', 'closure_summary': {'mode': 'exact_equilibrium', 'equilibrium_count': 1}, 'multiplicity_note': 'disclosed'},
    }

def full_validation(label, intervals):
    # Resume from complete actual native outputs retained in attempt2, not prose.
    from polisyos.core.artifacts.manifest import ArtifactRef
    root=HERE/'attempt-2-fixtures'/label/'cas';store=FileSystemCAS(root)
    row=CACHED[label]
    fresh=load_calibration_validation_bundle(FileSystemCAS(root),ArtifactRef.model_validate(row['bundle_ref']))
    assert fresh.model_dump(mode='json')['leaderboard_entry']==row['leaderboard']
    report=load_backtest_report(FileSystemCAS(root),fresh.backtest_matrix.backtest_report_ref)
    assert [scenario.model_dump(mode='json') for scenario in report.scenarios]==row['scenarios']
    row['producer_execution']='actual native run in attempt2; immutable source661; consumer CAS reread on resume'
    records.append(row)
    child_refs.append({'type':'validation','label':label,'cas_root':str(root),'ref':row['bundle_ref'],'payload':fresh.model_dump(mode='json')})
    return store,report,row

def unused_full_validation_original(label, intervals):
    root = HERE / 'attempt-2-fixtures' / label / 'cas'
    store = FileSystemCAS(root)
    candidate = store.put_json({'candidate': label}, PutOptions(kind='scientist.oracle_candidate', media_type='application/json'), canon_spec=CanonSpec(forbid_floats=False))
    inp = CalibrationValidationRunnerInput(run_id=label, candidate_ref=candidate, calibration_fit_score=.91, backtest_plan_bundles=plans(label, intervals), baseline_metrics={'policy_value': 100., 'coverage': .9}, **prerequisites())
    produced = CalibrationValidationRunner(store).run(inp)
    fresh_store = FileSystemCAS(root)
    fresh = load_calibration_validation_bundle(fresh_store, produced.bundle_ref)
    assert fresh == produced.bundle
    matrix = fresh.backtest_matrix
    assert matrix is not None and matrix.backtest_report_ref is not None
    report = load_backtest_report(fresh_store, matrix.backtest_report_ref)
    assert len(report.scenarios) == len(BacktestKind) == 5
    metrics = fresh.leaderboard_entry.metrics
    row = {'label': label, 'surface': 'CalibrationValidationRunner→actualMatrix→nativeStress→Leaderboard→persistBundle→newCASReader',
           'fixture_governance_other_prerequisites': True, 'scientific_or_production_authority_claim': False,
           'candidate_ref': candidate.model_dump(mode='json'), 'bundle_ref': produced.bundle_ref.model_dump(mode='json'),
           'bundle_readout': fresh.readout_summary(), 'matrix': matrix.model_dump(mode='json'),
           'leaderboard': fresh.leaderboard_entry.model_dump(mode='json'),
           'report_degraded': report.degraded, 'report_trust_eligible': report.trust_eligible,
           'scenarios': [s.model_dump(mode='json') for s in report.scenarios],
           'requested_total': sum(s.interval_requested_count for s in report.scenarios),
           'evaluated_total': sum(s.interval_evaluated_count for s in report.scenarios),
           'conditional_coverage': report.overall_coverage_probability,
           'eligible_for_promotion': metrics.eligible_for_promotion}
    records.append(row)
    child_refs.append({'type':'validation','label':label,'cas_root':str(root),'ref':produced.bundle_ref.model_dump(mode='json'),'payload':fresh.model_dump(mode='json')})
    return store, report, row

complete_store, complete_report, complete = full_validation('complete', [(0., 2.)] * 3)
assert complete['requested_total'] == complete['evaluated_total'] == 15
assert complete['eligible_for_promotion'] is True

partial_store, partial_report, partial = full_validation('partial', [(0., 2.)])
assert partial['requested_total'] == 15 and partial['evaluated_total'] == 5
assert partial['report_degraded'] is True and partial['report_trust_eligible'] is False
assert all(s.metadata['interval_admission']['status'] == 'limited' for s in partial_report.scenarios)
partial['required_property_result'] = 'FAIL' if partial['eligible_for_promotion'] else 'PASS'
partial['required_property'] = 'limited interval basis does not satisfy full admitted promotion evidence'
assert partial['eligible_for_promotion'] is False
assert partial['matrix']['composite_score'] is None
assert 'backtest_interval_basis_limited' in partial['leaderboard']['metrics']['gap_flags']

point_store, point_report, point = full_validation('point_only', None)
assert point['requested_total'] == point['evaluated_total'] == 0
assert all('interval_admission' not in s.metadata for s in point_report.scenarios)
assert point['eligible_for_promotion'] is True

def temporal_projection(label, scenario):
    # Carrier is fixture-constructed; its contained scenario came from actual
    # Matrix/orchestrator and CAS. Upstream trajectory producer remains UNRUN.
    carrier = TemporalEvaluationResult(scenario=scenario, pointwise_metrics={'path_rmse': 0., 'path_mae': 0., 'endpoint_abs_error': 0.}, functional_metrics={'integral_effect_abs_error': 0.}, uncertainty_metrics={'band_coverage': float(scenario.coverage_probability or 0.)}, diagnostics_checks={'complete': True}, gating_checks={'diagnostics_handled': True}, thresholds={}, acceptance_checks={}, expected_outcome='pass', actual_outcome='pass', matches_expected_outcome=True, passes=True)
    report = build_temporal_backtest_report(report_id=label, evaluations=[carrier])
    root = HERE / 'attempt-2-fixtures' / label / 'cas'; store = FileSystemCAS(root)
    ref = persist_backtest_report(store, report)
    fresh = load_backtest_report(FileSystemCAS(root), ref)
    row = {'label': label, 'surface': 'actualScenario→fixtureTemporalEvaluationResult→publicTemporalBuilder→CAS→newCASReader',
           'carrier_fixture_only': True, 'upstream_trajectory_producer': 'UNRUN',
           'requested': scenario.interval_requested_count, 'evaluated': scenario.interval_evaluated_count,
           'admission': fresh.scenarios[0].metadata.get('interval_admission'),
           'trust_eligible': fresh.trust_eligible, 'degraded': fresh.degraded,
           'degraded_reasons': fresh.degraded_reasons, 'ref': ref.model_dump(mode='json'),
           'required_property_result': 'PASS' if fresh.degraded and not fresh.trust_eligible else 'FAIL'}
    assert fresh.degraded and not fresh.trust_eligible
    assert fresh.metadata['temporal_summary']['passes_all'] is False
    child_refs.append({'type':'backtest', 'label':label, 'cas_root':str(root), 'ref':ref.model_dump(mode='json'), 'payload':fresh.model_dump(mode='json')})
    records.append(row)

scenario = partial_report.scenarios[0]
temporal_projection('temporal_partial', scenario)
fake_md = dict(scenario.metadata); fake_md['interval_admission'] = {'status': 'evaluated', 'requested_count': 3, 'evaluated_count': 3, 'availability': 1.}
temporal_projection('temporal_fake_marker', scenario.model_copy(update={'metadata': fake_md}))
missing_md = dict(scenario.metadata); missing_md.pop('interval_admission')
temporal_projection('temporal_missing_marker', scenario.model_copy(update={'metadata': missing_md}))

def neutral_fixture_context(store, report):
    binding = {'report_id': report.report_id, 'model_spec_ref': report.model_spec_ref, 'policy_spec_ref': report.policy_spec_ref, 'estimand': fb.PREDICTIVE_ESTIMAND, 'method_ref': 'forecasting.univariate.exponential_smoothing', 'method_version': '1.0.0', 'rule_version_ref': 'rolling-origin-residual-conformal.v1', 'calibration_threshold': '.8'}
    refs = {}
    for role, (kind, schema, version) in fb.REFERENCE_PROFILES.items():
        identity = report.report_id if role == 'scope_binding' else f'{role}://oracle/content/v1'
        payload = {'role': role, 'report_id': report.report_id, 'identity': identity}
        if role == 'scope_binding': payload['binding'] = binding
        if role == 'calibration_threshold': payload['threshold'] = Decimal('.8')
        raw = put_json_artifact(store, payload, kind=kind, schema_name=schema, schema_version=version)
        refs[role] = fb.EvidenceArtifactRef.model_validate({**raw, 'role': role, 'schema_name': schema, 'schema_version': version, 'identity_path': 'report_id' if role == 'scope_binding' else 'identity', 'identity_value': identity})
    start = datetime(2026, 1, 1, tzinfo=UTC)
    ctx = fb.EmpiricalCalibrationContext(model_spec_ref=report.model_spec_ref, policy_spec_ref=report.policy_spec_ref, method_ref=binding['method_ref'], method_version=binding['method_version'], rule_version_ref=binding['rule_version_ref'], calibration_threshold=.8, scope_binding_ref=refs['scope_binding'], calibration_threshold_ref=refs['calibration_threshold'], observed_outcome_ref=refs['observed_outcome'], prediction_ref=refs['prediction'], evaluation_design_ref=refs['evaluation_design'], credible_evaluation_evidence_ref=refs['credible_evaluation'], source_lineage_refs=(refs['source_lineage'],), method_lineage_refs=(refs['method_lineage'],), data_valid_time=start, calibration_window_start=start+timedelta(days=1), calibration_window_end=start+timedelta(days=2), policy_effective_time=start+timedelta(days=3), prediction_time=start+timedelta(days=4), observation_time=start+timedelta(days=5))
    return refs, ctx, binding

def bridge_probe(label, store, report):
    refs, context, binding = neutral_fixture_context(store, report)
    metadata = dict(report.metadata);metadata.update({k: v for k, v in binding.items() if k != 'calibration_threshold'})
    metadata.update(authority_scope='predictive_only', may_not_use_for=fb.PREDICTIVE_AUTHORITY_DENIALS)
    adapted = report.model_copy(update={'metadata': metadata})
    # This is deliberately a fixture content-consistency context projection,
    # not authentic scientific/Runtime admission. Exact role-profile artifacts
    # are real CAS bytes; their institutional credibility is not established.
    input_refs = [InputRef(artifact_id=r.artifact_id, role=role) for role, r in refs.items()]
    ref = persist_backtest_report(store, adapted, inputs=input_refs)
    ev = fb.produce_empirical_calibration_evidence(store, ref, context=context)
    record = {'label': label, 'surface': 'actualReport→fixtureRoleProfileContext→realForecastBridge',
              'context_fixture_only': True, 'actual_EvalSafety_or_scientific_authority': 'UNRUN/not_established',
              'context': context.model_dump(mode='json'), 'report_ref': ref.model_dump(mode='json'),
              'evidence': ev.model_dump(mode='json'), 'requested': sum(s.interval_requested_count for s in adapted.scenarios),
              'evaluated': sum(s.interval_evaluated_count for s in adapted.scenarios),
              'required_partial_basis_property': 'FAIL' if label == 'forecast_partial' and ev.usable_for_calibration else 'PASS'}
    if label == 'forecast_partial':
        assert not ev.usable_for_calibration and not ev.floor_passed
        assert 'interval_basis_limited' in ev.failure_codes
        try:
            fb.persist_empirical_calibration_evidence(store, ev)
        except ValueError as exc:
            assert 'blocked' in str(exc)
            record['persistence_refusal'] = str(exc)
        else:
            raise AssertionError('limited interval evidence was persisted')
    else:
        assert ev.usable_for_calibration and ev.floor_passed
    if ev.usable_for_calibration:
        evidence_ref = fb.persist_empirical_calibration_evidence(store, ev)
        fresh = fb.load_empirical_calibration_evidence(FileSystemCAS(store.root), evidence_ref)
        assert fresh == ev
        record['persisted_evidence_ref'] = evidence_ref.model_dump(mode='json')
        record['fresh_evidence_reader'] = True
        child_refs.append({'type':'evidence','label':label,'cas_root':str(store.root),'ref':evidence_ref.model_dump(mode='json'),'payload':fresh.model_dump(mode='json')})
    fake = context.model_copy(update={'observed_outcome_ref': context.observed_outcome_ref.model_copy(update={'identity_value': 'observation://foreign/v1'})})
    forged = fb.produce_empirical_calibration_evidence(store, ref, context=fake)
    assert not forged.usable_for_calibration and forged.failure_codes
    record['counterfeit_context_negative'] = forged.model_dump(mode='json')
    records.append(record)

bridge_probe('forecast_complete', complete_store, complete_report.model_copy(update={'degraded': True, 'trust_eligible': False, 'degraded_reasons': ['predictive_only_calibration_bridge_pending']}))
bridge_probe('forecast_partial', partial_store, partial_report)


# All later fixtures remain synthetic consumer mechanics, not scientific authority.
import dataclasses
import math
import runpy
from fractions import Fraction
import numpy as np
from polisyos.calibration import interval_basis as ib
from polisyos.scientist.governance import backtest_matrix as bm
from polisyos.scientist.governance import calibration_leaderboard as lb
from polisyos.scientist.methods.backtesting import temporal as tm
from polisyos.scientist.methods.backtesting import orchestrator as orch
from polisyos.scientist.methods.backtesting import evaluator as evmod
from polisyos.scientist.methods.backtesting.evaluator import PredictionEvaluator
from polisyos.core.artifacts.manifest import SchemaInfo
from polisyos.ir.registry.refs import BacktestReportRef

empty = PredictionEvaluator().evaluate(scenario_id='empty-axis', scenario_label='empty-axis',
    y_pred={'m':[]}, y_true={'m':[]}, intervals={'m':[(-1.,1.)]})
assert not ib._reconcile_interval_basis(empty).complete
assert empty.metadata['interval_admission']['status']=='limited'
records.append({'label':'empty_axis_retained_request','scenario':empty.model_dump(mode='json'),'basis':dataclasses.asdict(ib._reconcile_interval_basis(empty)),'property':'PASS'})
orphan=PredictionEvaluator().evaluate(scenario_id='orphan-hit',scenario_label='orphan-hit',y_pred={'m':[0.]},y_true={'m':[0.]})
orphan.outcome_comparisons[0].within_ci=True
assert not ib._reconcile_interval_basis(orphan).complete
assert bm._score_backtest_scenarios([orphan]) is None
records.append({'label':'orphan_within_ci_no_bounds','scenario':orphan.model_dump(mode='json'),'basis':dataclasses.asdict(ib._reconcile_interval_basis(orphan)),'actual_matrix_score':bm._score_backtest_scenarios([orphan]),'property':'PASS'})


# Actual supported temporal solver -> evaluator, including caller marker spoof.
tfixture=runpy.run_path(str(INPUT/'policy-engine/tests/unit/scientist/methods/backtesting/test_temporal.py'))
trajectory=tfixture['_trajectory']([0.,.2,.4,.6])
native_ok=tm.evaluate_temporal_trajectory(scenario_id='native_temporal_valid',scenario_label='native_temporal_valid',trajectory=trajectory,expected_effect_path=[0.,.2,.4,.6],thresholds=tm.TemporalThresholds(min_band_coverage=0.))
assert native_ok.acceptance_checks['interval_basis_complete'] and native_ok.passes
bad=trajectory.model_dump();bad['confidence_band_lower']=(1.,)*4;bad['confidence_band_upper']=(-1.,)*4
bad=type(trajectory).model_validate(bad)
native_bad=tm.evaluate_temporal_trajectory(scenario_id='native_temporal_invalid',scenario_label='native_temporal_invalid',trajectory=bad,expected_effect_path=[0.,.2,.4,.6],thresholds=tm.TemporalThresholds(min_band_coverage=0.),extra_acceptance_checks={'interval_basis_complete':True},metadata={'interval_admission':{'status':'evaluated','requested_count':4,'evaluated_count':4}})
assert not native_bad.acceptance_checks['interval_basis_complete'] and not native_bad.passes
assert native_bad.scenario.metadata['interval_admission']['status']=='limited'
troot=HERE/'fixtures/native_temporal/cas';tstore=FileSystemCAS(troot)
treport=tm.build_temporal_backtest_report(report_id='native_temporal_invalid',evaluations=[native_bad]);tref=persist_backtest_report(tstore,treport)
tfresh=load_backtest_report(FileSystemCAS(troot),tref)
assert tfresh.degraded and not tfresh.trust_eligible
child_refs.append({'type':'backtest','label':'native_temporal_invalid','cas_root':str(troot),'ref':tref.model_dump(mode='json'),'payload':tfresh.model_dump(mode='json')})
records.append({'label':'actual_temporal_solver_evaluator','supported':dataclasses.asdict(native_ok),'malformed':dataclasses.asdict(native_bad),'actual_compiler_solver':True,'identification_inputs':'maintained typed synthetic panel; no Runtime/scientific authority','fresh_report':tfresh.model_dump(mode='json'),'property':'PASS'})

# The leader resolves actual report bytes when positive matrix markers are forged.
from polisyos.core.artifacts.manifest import ArtifactRef
pbundle=load_calibration_validation_bundle(partial_store, ArtifactRef.model_validate(partial['bundle_ref']))
forged=pbundle.backtest_matrix.model_copy(deep=True);forged.composite_score=1.;forged.gap_flags=[]
for item in forged.kind_results: item.status='ok';item.score=1.;item.gap_flag=None
pre=prerequisites()
def entry(matrix,store=partial_store):
    return lb.CalibrationLeaderboard(store).build_entry(run_id='independent-marker-control',candidate_ref=None,calibration_fit_score=.91,backtest_matrix=matrix,stress_scenarios=pbundle.stress_scenarios,**pre)
assert not entry(forged).metrics.eligible_for_promotion
records.append({'label':'forged_matrix_actual_cas_refuses','matrix':forged.model_dump(mode='json'),'entry':entry(forged).model_dump(mode='json'),'property':'PASS'})
wrong_payload=complete_report.model_dump(mode='json');wrong_payload['metadata']['negative_profile']='foreign_report_kind'
wrong=complete_store.put_json(wrong_payload,PutOptions(kind='test.other_report',media_type='application/json',schema=SchemaInfo(name='ir.backtest_report',version='1.0')),canon_spec=CanonSpec(forbid_floats=False))
cmatrix=load_calibration_validation_bundle(complete_store,ArtifactRef.model_validate(complete['bundle_ref'])).backtest_matrix.model_copy(deep=True)
cmatrix.backtest_report_ref=BacktestReportRef(artifact_id=wrong.artifact_id)
wrong_entry=entry(cmatrix,complete_store)
assert not wrong_entry.metrics.eligible_for_promotion and 'backtest_interval_basis_unresolved' in wrong_entry.metrics.gap_flags
records.append({'label':'actual_foreign_kind_with_retained_shape_refuses','wrong_ref':wrong.model_dump(mode='json'),'entry':wrong_entry.model_dump(mode='json'),'property':'PASS'})

# Real native ETS backend and observed held-out data: no fake evaluator/mock.
ff=runpy.run_path(str(INPUT/'policy-engine/tests/unit/remediation/test_frc_02_owner.py'))
ets=[]
for label,holdout in [('ets_supported',[20.,21.,22.]),('ets_changed_observations',[1000.,1001.,1002.])]:
    root=HERE/'attempt-2-fixtures'/label/'cas';store=FileSystemCAS(root)
    # Completed actual ForecastOwner.run outputs from attempt2; same immutable source.
    from polisyos.scientist.methods.backtesting.forecast_owner import ForecastOwnerResult
    from polisyos.core.contracts.fabric import DataSnapshotRef
    cached=CACHED[label]
    source=DataSnapshotRef.model_validate(cached['observed_source'])
    request=ff['ForecastOwnerRequest'].model_validate(cached['request'])
    produced=ForecastOwnerResult.model_validate(cached['producer'])
    report=load_backtest_report(FileSystemCAS(root),produced.backtest_report_ref)
    from polisyos.ir.analytics.forecasting_uncertainty import load_forecasting_uncertainty_bundle
    bundle=load_forecasting_uncertainty_bundle(FileSystemCAS(root),produced.uncertainty_bundle_ref)
    scenario=report.scenarios[0];basis=ib._reconcile_interval_basis(scenario)
    assert basis.complete and basis.requested_count==basis.evaluated_count==3
    assert report.degraded and not report.trust_eligible
    assert produced.bridge_status=='bridge_pending'
    evidence=fb.produce_empirical_calibration_evidence(store,produced.backtest_report_ref)
    assert not evidence.usable_for_calibration and not evidence.floor_passed
    assert evidence.failure_codes==('explicit_context_missing',)
    assert evidence.empirical_observations_available
    assert 's10_authority' in evidence.may_not_use_for
    erow={'label':label,'actual_native_backend':'statsmodels ETS via actual ForecastOwner.run in retained attempt2; same exact661 and freshCAS on resume','observed_source':source.model_dump(mode='json'),'request':request.model_dump(mode='json'),'producer':produced.model_dump(mode='json'),'fresh_report':report.model_dump(mode='json'),'fresh_bundle':bundle.model_dump(mode='json'),'interval_basis':dataclasses.asdict(basis),'missing_authority_evidence':evidence.model_dump(mode='json'),'property':'PASS'}
    records.append(erow);ets.append(produced)
    child_refs.append({'type':'backtest','label':label,'cas_root':str(root),'ref':produced.backtest_report_ref.model_dump(mode='json'),'payload':report.model_dump(mode='json')})
assert ets[0].point_forecast==ets[1].point_forecast
assert ets[0].predictive_intervals==ets[1].predictive_intervals
assert ets[0].coverage_numerator>ets[1].coverage_numerator
assert ets[0].empirical_suitability=='supported' and ets[1].empirical_suitability=='limited'

# Semantic guard removal in memory, retaining all source enums/metadata/counts.
original=ib._reconcile_interval_basis
modules=[ib,bm,lb,tm,orch,evmod,fb]
originals={m:getattr(m,'_reconcile_interval_basis') for m in modules}
def no_runtime_guard(s): return dataclasses.replace(original(s),issues=())
for module in modules: module._reconcile_interval_basis=no_runtime_guard
removals=[]
try:
    temporal_removed=tm.build_temporal_backtest_report(report_id='removed_guard_temporal',evaluations=[tm.TemporalEvaluationResult(scenario=scenario,pointwise_metrics={},functional_metrics={},uncertainty_metrics={'band_coverage':1.},diagnostics_checks={},gating_checks={},thresholds={},acceptance_checks={},expected_outcome='pass',actual_outcome='pass',matches_expected_outcome=True,passes=True)])
    # 'scenario' above is last ETS row; use the native partial scenario instead.
    temporal_removed=tm.build_temporal_backtest_report(report_id='removed_guard_temporal',evaluations=[tm.TemporalEvaluationResult(scenario=partial_report.scenarios[0],pointwise_metrics={},functional_metrics={},uncertainty_metrics={'band_coverage':1.},diagnostics_checks={},gating_checks={},thresholds={},acceptance_checks={},expected_outcome='pass',actual_outcome='pass',matches_expected_outcome=True,passes=True)])
    removed_lb=entry(forged)
    refs,ctx,binding=neutral_fixture_context(partial_store,partial_report)
    md=dict(partial_report.metadata);md.update({k:v for k,v in binding.items() if k!='calibration_threshold'});md.update(authority_scope='predictive_only',may_not_use_for=fb.PREDICTIVE_AUTHORITY_DENIALS)
    adapted=partial_report.model_copy(update={'metadata':md})
    ref=persist_backtest_report(partial_store,adapted,inputs=[InputRef(artifact_id=r.artifact_id,role=role) for role,r in refs.items()])
    removed_evidence=fb.produce_empirical_calibration_evidence(partial_store,ref,context=ctx)
    for label,actual,property_ok in [
        ('temporal_guard_removed',temporal_removed.model_dump(mode='json'),temporal_removed.degraded and not temporal_removed.trust_eligible),
        ('leaderboard_guard_removed',removed_lb.model_dump(mode='json'),not removed_lb.metrics.eligible_for_promotion),
        ('forecast_guard_removed',removed_evidence.model_dump(mode='json'),not removed_evidence.usable_for_calibration),
    ]:
        try: assert property_ok,'Defining property failed with runtime guard removed and markers retained'
        except AssertionError as exc: removals.append({'label':label,'result':'EXPECTED_FAIL','assertion':str(exc),'actual':actual,'retained_typed_requested':15,'retained_typed_evaluated':5,'runtime_removal':'issues emptied only; rows/counts/labels/profiles/diagnostics unchanged'})
        else: raise AssertionError('Property discriminator missed removal: '+label)
finally:
    for module,fn in originals.items(): module._reconcile_interval_basis=fn
assert ib._reconcile_interval_basis(complete_report.scenarios[0]).complete
assert not ib._reconcile_interval_basis(partial_report.scenarios[0]).complete
records.append({'label':'shared_runtime_guard_removals','controls':removals,'ordinary_control_after_restore':'PASS','scope':'in-memory independent experiment; source files unchanged'})

# Separate sampling-label delta only; no re-run of historical arithmetic wave.
from polisyos.foundry.uncertainty import monte_carlo as mc
from polisyos.foundry.uncertainty.config import PropagationConfig
from polisyos.core.artifacts.ir_adapter import build_ir_artifact_store
from polisyos.ir.analytics.uncertainty import DistributionFamily,IntervalSemantics,ParametricFitCarrier,PosteriorSamplesCarrier,PropagationMethod,UncertaintyEnvelope,UncertaintySource,load_uncertainty_envelope,persist_uncertainty_envelope
normal=UncertaintyEnvelope(point_estimate=0.,confidence_interval=(-2.,2.),distribution_family=DistributionFamily.NORMAL,source=UncertaintySource.CALIBRATION,propagation_method=PropagationMethod.NONE,interval_semantics=IntervalSemantics.CONFIDENCE_INTERVAL,distribution_payload=ParametricFitCarrier(family=DistributionFamily.NORMAL,parameters={'mean':0.,'std':1.}),gate_eligible=False)
weighted=normal.model_copy(update={'distribution_family':DistributionFamily.BOOTSTRAP,'distribution_payload':PosteriorSamplesCarrier(samples=(-1.,1.),weights=(.9,.1),sample_axis='draw'),'metadata':{'sampling_law':'implemented_product_of_typed_normal_fits','iid':True}})
def mc_actual(label,env):
    root=HERE/'attempt-2-fixtures'/label/'cas';store=build_ir_artifact_store(root)
    produced=mc.MonteCarloPropagator(PropagationConfig(mc_n_samples=100,mc_seed=61)).propagate(lambda x=0.:{'y':-1. if x<0. else 1.},{'x':0.},{'x':env},['y'])[0]
    ref=persist_uncertainty_envelope(store,produced.envelope);fresh=load_uncertainty_envelope(build_ir_artifact_store(root),ref)
    d=fresh.metadata['mean_estimator_error']
    assert d['requested_draw_count']==d['attempted_draw_count']==d['finite_output_count']==100
    assert not fresh.gate_eligible and not d['gate_eligible'] and not d['assumptions_verified']
    assert d['supported_estimator_profile']=='fixed_random_product_of_typed_normal_fits'
    row={'label':label,'input':env.model_dump(mode='json'),'ref':ref.model_dump(mode='json'),'diagnostic':d,'fresh_envelope':fresh.model_dump(mode='json'),'property':'PASS'}
    records.append(row);child_refs.append({'type':'uncertainty','label':label,'cas_root':str(root),'ref':ref.model_dump(mode='json'),'payload':fresh.model_dump(mode='json')})
    return d
nd=mc_actual('mc_typed_normal_label',normal)
assert nd['sampling_law']=='implemented_product_of_typed_normal_fits' and nd['status']=='conditional_estimate'
for label,env in [('mc_weighted_actual_recipe',weighted),('mc_legacy_inferred_recipe',normal.model_copy(update={'distribution_payload':None}))]:
    d=mc_actual(label,env)
    assert d['sampling_law']=='implemented_input_sampling_recipe'
    assert d['status']=='unavailable' and d['standard_error'] is None and d['reason']=='unsupported_input_sampling_law'
    if label=='mc_weighted_actual_recipe': assert d['input_recipe_profiles']['x']=={'distribution_family':'bootstrap','carrier':'PosteriorSamplesCarrier'}
original_mean=mc._mean_estimator_error
def old_label(values,**kwargs):
    result=original_mean(values,**kwargs);result['sampling_law']='implemented_product_of_typed_normal_fits';return result
mc._mean_estimator_error=old_label
try:
    d=mc_actual('mc_label_property_removed',weighted)
    try: assert d['sampling_law']=='implemented_input_sampling_recipe','Actual weighted/bootstrap input mislabeled as typed-Normal law'
    except AssertionError as exc: records[-1]['property']='EXPECTED_FAIL';records[-1]['assertion']=str(exc)
    else: raise AssertionError('Law-label discriminator missed old property removal')
    assert d['status']=='unavailable' and d['standard_error'] is None
finally: mc._mean_estimator_error=original_mean
(HERE/'child-refs.json').write_text(json.dumps(child_refs,indent=2,sort_keys=True))

origins = []
for name, module in sorted(sys.modules.items()):
    if not name.startswith('polisyos') or not getattr(module, '__file__', None): continue
    path = Path(module.__file__).resolve()
    if path.suffix != '.py': continue
    assert path.is_relative_to(INPUT), str(path)
    rel = path.relative_to(INPUT).as_posix()
    expected = subprocess.check_output(['git', 'rev-parse', f'{SOURCE}:{rel}'], cwd=GITROOT, text=True).strip()
    raw = path.read_bytes(); actual = hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    assert actual == expected, (name, rel)
    origins.append({'module': name, 'path': str(path), 'git_blob': actual, 'sha256': hashlib.sha256(raw).hexdigest()})
(HERE/'module-origins.json').write_text(json.dumps(origins, sort_keys=True, indent=2))
output = {'source': SOURCE, 'tree': 'a1d408e8c9ead9573a9ad846b6672d9c6dc7506e', 'review_source': '71ec2e0758cd7cd93423d3a91afe1a07cef61401',
          'source_archive_sha256': '6447618a1d45c9e93f987907bb4a255526a8a79a3c542d15e7c622c9fc56acf4',
          'records': records, 'loaded_origins': len(origins), 'origin_mismatches': 0,
          'interpreter': sys.version, 'executable': sys.executable, 'pid': os.getpid(),
          'packages': {p: importlib.metadata.version(p) for p in ['numpy', 'scipy', 'pydantic', 'statsmodels']},
          'body_seconds': time.monotonic()-started, 'peak_rss_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
          'property_status': 'PASS bounded changed downstream interval basis and MC actual-law label; retained marker controls separately EXPECTED_FAIL',
          'authority': 'none; configured synthetic facts/fixture prerequisites; public mechanics only',
          'ETS_actual_producer': 'PASS native ForecastOwner actual Statsmodels ETS with observed holdout; no Runtime/S10 authority',
          'S10_Runtime_or_authentic_credible_evaluation': 'UNRUN'}
print(json.dumps(output, sort_keys=True, indent=2, allow_nan=False))
(HERE/'probe-result.json').write_text(json.dumps(output, sort_keys=True, indent=2, allow_nan=False))
assert partial['eligible_for_promotion'] is False, 'Limited interval basis escaped actual full CalibrationValidationRunner→Matrix→Leaderboard→CAS'
