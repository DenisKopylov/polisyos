from __future__ import annotations
import json,os,resource,sys,time
from pathlib import Path
from polisyos.core.artifacts import FileSystemCAS
from polisyos.ir.analytics.backtest import BacktestScenario,load_backtest_report,persist_backtest_report
from polisyos.scientist.methods.backtesting.temporal import TemporalEvaluationResult,build_temporal_backtest_report
here=Path(__file__).resolve().parent
records=json.loads((here/'probe-result.json').read_text())['records']
native=next(row for row in records if row['label']=='actual_temporal_solver_evaluator')['malformed']
native['scenario']=BacktestScenario.model_validate(native['scenario'])
carrier=TemporalEvaluationResult(**native)
computed=build_temporal_backtest_report(report_id='reserved_summary_normal',evaluations=[carrier])
assert computed.metadata['temporal_summary']['passes_all'] is False
report=build_temporal_backtest_report(report_id='reserved_summary_spoof',evaluations=[carrier],metadata={'temporal_summary':{'passes_all':True,'n_passed':1,'n_total':1}})
root=here/'summary-spoof-cas';store=FileSystemCAS(root);ref=persist_backtest_report(store,report)
fresh=load_backtest_report(FileSystemCAS(root),ref)
assert fresh.degraded and not fresh.trust_eligible
result={'source':'66134569f999951e8eefef737424f12aeba24616','tree':'a1d408e8c9ead9573a9ad846b6672d9c6dc7506e','surface':'actual native temporal solver/evaluator retained result→public report builder→CAS→new reader','actual_upstream_native_execution':'same exact source probe-result.json; carrier reconstructed from retained deciding bytes','caller_metadata':{'temporal_summary':{'passes_all':True,'n_passed':1,'n_total':1}},'computed_summary':computed.metadata['temporal_summary'],'fresh_summary':fresh.metadata['temporal_summary'],'typed_degraded':fresh.degraded,'typed_trust_eligible':fresh.trust_eligible,'ref':ref.model_dump(mode='json'),'property':'FAIL reserved numerical summary can be overwritten; no observed typed trust promotion','source_authority':'UNRUN/not established','pid':os.getpid(),'interpreter':sys.version}
print(json.dumps(result,indent=2,sort_keys=True))
assert fresh.metadata['temporal_summary']['passes_all'] is False,'Caller metadata overwrote the computed limited temporal summary'
