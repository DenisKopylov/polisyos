from __future__ import annotations
import hashlib,json,os,resource,subprocess,sys,time
from pathlib import Path
from polisyos.core.artifacts import FileSystemCAS
from polisyos.ir.analytics.backtest import BacktestScenario,load_backtest_report,persist_backtest_report
from polisyos.ir.registry.refs import BacktestReportRef
from polisyos.scientist.methods.backtesting import temporal as tm
here=Path(__file__).resolve().parent;source='adb66080e3ac64d73b3faa85d693a47c6c284427';start=time.monotonic()
def origins():
    listing=subprocess.check_output(['git','ls-tree','-r',source,'--','policy-engine/src'],cwd='/workspace/e02-F-closeout-20261006',text=True)
    expected={line.split('\t',1)[1]:line.split('\t',1)[0].split()[2] for line in listing.splitlines()}
    items=[]
    for name,module in sorted(sys.modules.items()):
        if not name.startswith('polisyos') or not getattr(module,'__file__',None):continue
        path=Path(module.__file__).resolve()
        if path.suffix!='.py':continue
        assert path.is_relative_to(here/'input'),str(path)
        rel=path.relative_to(here/'input').as_posix();raw=path.read_bytes()
        actual=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();assert actual==expected[rel],(name,rel)
        items.append({'module':name,'path':str(path),'blob':actual,'sha256':hashlib.sha256(raw).hexdigest()})
    return items
if '--child' in sys.argv:
    refs=json.loads((here/'forward-refs.json').read_text());items=[]
    for ref in refs:
        fresh=load_backtest_report(FileSystemCAS(ref['cas_root']),BacktestReportRef.model_validate(ref['ref']))
        assert fresh.model_dump(mode='json')==ref['payload']
        items.append({'label':ref['label'],'payload_matches':True,'trust_eligible':fresh.trust_eligible,'degraded':fresh.degraded,'summary':fresh.metadata['temporal_summary']})
    loaded=origins();(here/'forward-child-origins.json').write_text(json.dumps(loaded,indent=2,sort_keys=True))
    print(json.dumps({'source':source,'tree':'f2c1f993052c25586420d07c766b868f632fbf39','pid':os.getpid(),'fresh_child_reader':True,'refs':items,'loaded_origins':len(loaded),'origin_mismatches':0,'check':'PASS','body_seconds':time.monotonic()-start,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},indent=2,sort_keys=True));raise SystemExit(0)
old=Path('/dev/shm/e02-orch03-20261008/oracle-empirical/interval-consumer/review-661');records=json.loads((old/'probe-result.json').read_text())['records']
native=next(row for row in records if row['label']=='actual_temporal_solver_evaluator')
def carrier(payload):
    payload=dict(payload);payload['scenario']=BacktestScenario.model_validate(payload['scenario']);return tm.TemporalEvaluationResult(**payload)
limited=carrier(native['malformed']);complete=carrier(native['supported'])
point=next(row for row in records if row['label']=='point_only')['scenarios'][0]
point_carrier=tm.TemporalEvaluationResult(scenario=BacktestScenario.model_validate(point),pointwise_metrics={},functional_metrics={},uncertainty_metrics={},diagnostics_checks={},gating_checks={},thresholds={},acceptance_checks={},expected_outcome='pass',actual_outcome='pass',matches_expected_outcome=True,passes=True)
output=[];refs=[]
def actual(label,case,spoof,expected,removal=False):
    report=tm.build_temporal_backtest_report(report_id=label,evaluations=[case],metadata={'temporal_summary':spoof,'annotation':'keep'})
    root=here/label/'cas';store=FileSystemCAS(root);ref=persist_backtest_report(store,report)
    fresh=load_backtest_report(FileSystemCAS(root),ref)
    assert fresh.metadata['annotation']=='keep'
    okay=fresh.metadata['temporal_summary']['passes_all'] is expected
    row={'label':label,'surface':'retained actual661 native producer/evaluator output→exactadb builder→CAS→fresh reader','producer_carry':'unchanged native producer/numerical evaluator code and source/inputs; deciding payloads/hashes retained from661','caller_summary':spoof,'fresh_report':fresh.model_dump(mode='json'),'ref':ref.model_dump(mode='json'),'property':'PASS' if okay else 'FAIL','removal':removal}
    if removal:
        try:assert okay,'Reserved summary property removed while interval markers/typed blockers retained'
        except AssertionError as exc:row['property']='EXPECTED_FAIL';row['assertion']=str(exc)
        else:raise AssertionError('Reserved-summary discriminator missed removal')
        assert fresh.degraded and not fresh.trust_eligible
    else:assert okay
    output.append(row);refs.append({'label':label,'ref':ref.model_dump(mode='json'),'cas_root':str(root),'payload':fresh.model_dump(mode='json')})
actual('limited_spoof',limited,{'passes_all':True,'n_passed':1,'n_total':1},False)
actual('complete_spoof',complete,{'passes_all':False,'n_passed':0,'n_total':1},True)
actual('point_only_spoof',point_carrier,{'passes_all':False},True)
original=tm.build_temporal_backtest_report
def remove_summary_guard(**kwargs):
    report=original(**kwargs);report.metadata.update(kwargs.get('metadata') or {});return report
try:
    tm.build_temporal_backtest_report=remove_summary_guard
    actual('summary_guard_removed',limited,{'passes_all':True},False,True)
finally:tm.build_temporal_backtest_report=original
(here/'forward-refs.json').write_text(json.dumps(refs,indent=2,sort_keys=True))
loaded=origins();(here/'forward-origins.json').write_text(json.dumps(loaded,indent=2,sort_keys=True))
childcmd=[sys.executable,str(here/'forward-probe.py'),'--child'];t=time.monotonic();child=subprocess.run(childcmd,cwd=here,capture_output=True,text=True,env=os.environ.copy())
(here/'forward-child.stdout.json').write_text(child.stdout);(here/'forward-child.stderr.txt').write_text(child.stderr)
(here/'forward-child.execution.json').write_text(json.dumps({'command':childcmd,'cwd':str(here),'source':source,'tree':'f2c1f993052c25586420d07c766b868f632fbf39','returncode':child.returncode,'wall_seconds':time.monotonic()-t,'stdout':str(here/'forward-child.stdout.json'),'stderr':str(here/'forward-child.stderr.txt')},indent=2,sort_keys=True))
assert child.returncode==0,child.stderr
print(json.dumps({'source':source,'tree':'f2c1f993052c25586420d07c766b868f632fbf39','cases':output,'loaded_origins':len(loaded),'origin_mismatches':0,'check':'PASS3ordinary supported/limited/point controls;1EXPECTED_FAIL retained-marker summary removal','child_check':'PASS4refs fresh independent child','pid':os.getpid(),'interpreter':sys.version,'exe':sys.executable,'body_seconds':time.monotonic()-start,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'authority':'none; this checks numerical report truth, not Runtime/S10 or scientific identification'},indent=2,sort_keys=True))
