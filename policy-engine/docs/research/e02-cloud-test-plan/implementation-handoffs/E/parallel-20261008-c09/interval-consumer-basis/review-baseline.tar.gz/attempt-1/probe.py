from __future__ import annotations
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time
from datetime import UTC, datetime, timedelta
from decimal import Decimal

from polisyos.core.artifacts import FileSystemCAS
from polisyos.core.artifacts.store import PutOptions
from polisyos.core.canon import CanonSpec
from polisyos.ir.analytics.backtest import load_backtest_report, persist_backtest_report
from polisyos.ir.analytics.interference import (
    ExposureMappingType, InterferenceCertificate, InterferenceEffectDecomposition,
    InterferenceMethod, NetworkInterferenceReport,
)
from polisyos.ir.artifacts import InputRef, put_json_artifact
from polisyos.ir.observation.bundles import BacktestPlanBundle, ContractCompatibilityTarget
from polisyos.ir.observation.contract_compilers import SpecificationCurveInput
from polisyos.scientist.governance.backtest_matrix import BacktestKind
from polisyos.scientist.governance.calibration import CalibrationAdversarialResult, CalibrationGovernanceReport
from polisyos.scientist.governance.calibration_validation import (
    CalibrationValidationRunner, CalibrationValidationRunnerInput, load_calibration_validation_bundle,
)
from polisyos.scientist.methods.backtesting.plan import HistoricalValidationPlan, PredictionSource
from polisyos.scientist.methods.backtesting.temporal import TemporalEvaluationResult, build_temporal_backtest_report
from polisyos.scientist.methods.discovery.utility_judge import DownstreamUtilityReport, HypothesisUtilityScore
from polisyos.calibration import forecast_bridge as fb

HERE = Path(__file__).resolve().parent
INPUT = HERE / 'input'
GITROOT = Path('/workspace/e02-F-closeout-20261006')
SOURCE = 'ee0b2c85289d8c5537ba4e01713d9be71e2f557e'
records = []
started = time.monotonic()

def plans(label, intervals):
    folder = HERE / 'fixtures' / label
    folder.mkdir(parents=True, exist_ok=True)
    bundles = {}
    for kind in BacktestKind:
        path = folder / f'{kind.value}.json'
        path.write_text(json.dumps({'metric': [1., 1., 1.]}))
        plan = HistoricalValidationPlan(
            plan_id=kind.value, historical_data_path=str(path),
            prediction_source=PredictionSource.PROVIDED,
            predicted_outcomes={'metric': [1., 1., 1.]},
            ground_truth_outcomes={'metric': [1., 1., 1.]},
            prediction_intervals=None if intervals is None else {'metric': intervals},
            model_spec_ref='model://oracle/interval/v1', policy_spec_ref='policy://oracle/interval/v1',
            metadata={'interval_admission': {'status': 'evaluated', 'requested_count': 3, 'evaluated_count': 3, 'availability': 1.}},
        )
        bundles[kind] = BacktestPlanBundle(
            contract_target=ContractCompatibilityTarget(contract_id=f'oracle-{kind.value}', contract_fqn='polisyos.ir.observation.bundles.BacktestPlanBundle'),
            required_fields=['metric'], holdout_windows=['fixed-three-row-holdout'],
            plans=[plan.model_dump(mode='json')], historical_payloads={'metric': {'values': [1., 1., 1.]}},
        )
    return bundles

def prerequisites():
    return {
        'governance_report': CalibrationGovernanceReport(verdict='approve', adversarial_results=[
            CalibrationAdversarialResult(alias='strategic_gaming_adversarial', suite_id='oracle-strategic', required=True, status='passed'),
            CalibrationAdversarialResult(alias='multiplicity_disclosure_adversarial', suite_id='oracle-multiplicity', required=True, status='passed'),
        ]),
        'specification_curve_input': SpecificationCurveInput(specification_ids=['s1', 's2', 's3'], estimates=[.3, .28, .32], standard_errors=[.1, .1, .1]),
        'downstream_utility_report': DownstreamUtilityReport(scores=[HypothesisUtilityScore(hypothesis_id='h1', identification_status='identified', identifiability_score=1., stability_score=.8, transportability_score=.82, composite_score=.9, rank=1)], recommended_shortlist=['h1']),
        'network_interference_report': NetworkInterferenceReport(method=InterferenceMethod.PARTIAL_IPW, status='success', effects=InterferenceEffectDecomposition(direct_effect=.1, spillover_effect=.02, total_effect=.12, n_units=8, n_treated=3), exposure_mapping=ExposureMappingType.FRACTIONAL, n_units=8, n_treated=3),
        'interference_certificate': InterferenceCertificate(supported_query_family='spillover', fallback_mode='pairwise', reduction_error_bound=.05),
        'strategic_summary': {'fallback_mode': 'exact_equilibrium', 'closure_summary': {'mode': 'exact_equilibrium', 'equilibrium_count': 1}, 'multiplicity_note': 'disclosed'},
    }

def full_validation(label, intervals):
    root = HERE / 'fixtures' / label / 'cas'
    store = FileSystemCAS(root)
    candidate = store.put_json({'candidate': label}, PutOptions(kind='scientist.oracle_candidate', media_type='application/json'), canon_spec=CanonSpec(forbid_floats=False))
    inp = CalibrationValidationRunnerInput(run_id=label, candidate_ref=candidate, calibration_fit_score=.91, backtest_plan_bundles=plans(label, intervals), baseline_metrics={'policy_value': 100., 'coverage': .9}, **prerequisites())
    produced = CalibrationValidationRunner(store).run(inp)
    fresh_store = FileSystemCAS(root)
    fresh = load_calibration_validation_bundle(fresh_store, produced.bundle_ref)
    assert fresh == produced.bundle
    matrix = fresh.backtest_matrix
    assert matrix is not None and matrix.backtest_report_ref is not None
    report = load_backtest_report(fresh_store, matrix.backtest_report_ref)
    assert len(report.scenarios) == len(BacktestKind) == 5
    metrics = fresh.leaderboard_entry.metrics
    row = {'label': label, 'surface': 'CalibrationValidationRunner→actualMatrix→nativeStress→Leaderboard→persistBundle→newCASReader',
           'fixture_governance_other_prerequisites': True, 'scientific_or_production_authority_claim': False,
           'candidate_ref': candidate.model_dump(mode='json'), 'bundle_ref': produced.bundle_ref.model_dump(mode='json'),
           'bundle_readout': fresh.readout_summary(), 'matrix': matrix.model_dump(mode='json'),
           'leaderboard': fresh.leaderboard_entry.model_dump(mode='json'),
           'report_degraded': report.degraded, 'report_trust_eligible': report.trust_eligible,
           'scenarios': [s.model_dump(mode='json') for s in report.scenarios],
           'requested_total': sum(s.interval_requested_count for s in report.scenarios),
           'evaluated_total': sum(s.interval_evaluated_count for s in report.scenarios),
           'conditional_coverage': report.overall_coverage_probability,
           'eligible_for_promotion': metrics.eligible_for_promotion}
    records.append(row)
    return store, report, row

complete_store, complete_report, complete = full_validation('complete', [(0., 2.)] * 3)
assert complete['requested_total'] == complete['evaluated_total'] == 15
assert complete['eligible_for_promotion'] is True

partial_store, partial_report, partial = full_validation('partial', [(0., 2.)])
assert partial['requested_total'] == 15 and partial['evaluated_total'] == 5
assert partial['report_degraded'] is True and partial['report_trust_eligible'] is False
assert all(s.metadata['interval_admission']['status'] == 'limited' for s in partial_report.scenarios)
partial['required_property_result'] = 'FAIL' if partial['eligible_for_promotion'] else 'PASS'
partial['required_property'] = 'limited interval basis does not satisfy full admitted promotion evidence'

point_store, point_report, point = full_validation('point_only', None)
assert point['requested_total'] == point['evaluated_total'] == 0
assert all('interval_admission' not in s.metadata for s in point_report.scenarios)

def temporal_projection(label, scenario):
    # Carrier is fixture-constructed; its contained scenario came from actual
    # Matrix/orchestrator and CAS. Upstream trajectory producer remains UNRUN.
    carrier = TemporalEvaluationResult(scenario=scenario, pointwise_metrics={'path_rmse': 0., 'path_mae': 0., 'endpoint_abs_error': 0.}, functional_metrics={'integral_effect_abs_error': 0.}, uncertainty_metrics={'band_coverage': float(scenario.coverage_probability or 0.)}, diagnostics_checks={'complete': True}, gating_checks={'diagnostics_handled': True}, thresholds={}, acceptance_checks={}, expected_outcome='pass', actual_outcome='pass', matches_expected_outcome=True, passes=True)
    report = build_temporal_backtest_report(report_id=label, evaluations=[carrier])
    root = HERE / 'fixtures' / label / 'cas'; store = FileSystemCAS(root)
    ref = persist_backtest_report(store, report)
    fresh = load_backtest_report(FileSystemCAS(root), ref)
    row = {'label': label, 'surface': 'actualScenario→fixtureTemporalEvaluationResult→publicTemporalBuilder→CAS→newCASReader',
           'carrier_fixture_only': True, 'upstream_trajectory_producer': 'UNRUN',
           'requested': scenario.interval_requested_count, 'evaluated': scenario.interval_evaluated_count,
           'admission': fresh.scenarios[0].metadata.get('interval_admission'),
           'trust_eligible': fresh.trust_eligible, 'degraded': fresh.degraded,
           'degraded_reasons': fresh.degraded_reasons, 'ref': ref.model_dump(mode='json'),
           'required_property_result': 'PASS' if fresh.degraded and not fresh.trust_eligible else 'FAIL'}
    records.append(row)

scenario = partial_report.scenarios[0]
temporal_projection('temporal_partial', scenario)
fake_md = dict(scenario.metadata); fake_md['interval_admission'] = {'status': 'evaluated', 'requested_count': 3, 'evaluated_count': 3, 'availability': 1.}
temporal_projection('temporal_fake_marker', scenario.model_copy(update={'metadata': fake_md}))
missing_md = dict(scenario.metadata); missing_md.pop('interval_admission')
temporal_projection('temporal_missing_marker', scenario.model_copy(update={'metadata': missing_md}))

def neutral_fixture_context(store, report):
    binding = {'report_id': report.report_id, 'model_spec_ref': report.model_spec_ref, 'policy_spec_ref': report.policy_spec_ref, 'estimand': fb.PREDICTIVE_ESTIMAND, 'method_ref': 'forecasting.univariate.exponential_smoothing', 'method_version': '1.0.0', 'rule_version_ref': 'rolling-origin-residual-conformal.v1', 'calibration_threshold': '.8'}
    refs = {}
    for role, (kind, schema, version) in fb.REFERENCE_PROFILES.items():
        identity = report.report_id if role == 'scope_binding' else f'{role}://oracle/content/v1'
        payload = {'role': role, 'report_id': report.report_id, 'identity': identity}
        if role == 'scope_binding': payload['binding'] = binding
        if role == 'calibration_threshold': payload['threshold'] = Decimal('.8')
        raw = put_json_artifact(store, payload, kind=kind, schema_name=schema, schema_version=version)
        refs[role] = fb.EvidenceArtifactRef.model_validate({**raw, 'role': role, 'schema_name': schema, 'schema_version': version, 'identity_path': 'report_id' if role == 'scope_binding' else 'identity', 'identity_value': identity})
    start = datetime(2026, 1, 1, tzinfo=UTC)
    ctx = fb.EmpiricalCalibrationContext(model_spec_ref=report.model_spec_ref, policy_spec_ref=report.policy_spec_ref, method_ref=binding['method_ref'], method_version=binding['method_version'], rule_version_ref=binding['rule_version_ref'], calibration_threshold=.8, scope_binding_ref=refs['scope_binding'], calibration_threshold_ref=refs['calibration_threshold'], observed_outcome_ref=refs['observed_outcome'], prediction_ref=refs['prediction'], evaluation_design_ref=refs['evaluation_design'], credible_evaluation_evidence_ref=refs['credible_evaluation'], source_lineage_refs=(refs['source_lineage'],), method_lineage_refs=(refs['method_lineage'],), data_valid_time=start, calibration_window_start=start+timedelta(days=1), calibration_window_end=start+timedelta(days=2), policy_effective_time=start+timedelta(days=3), prediction_time=start+timedelta(days=4), observation_time=start+timedelta(days=5))
    return refs, ctx, binding

def bridge_probe(label, store, report):
    refs, context, binding = neutral_fixture_context(store, report)
    metadata = dict(report.metadata);metadata.update({k: v for k, v in binding.items() if k != 'calibration_threshold'})
    metadata.update(authority_scope='predictive_only', may_not_use_for=fb.PREDICTIVE_AUTHORITY_DENIALS)
    adapted = report.model_copy(update={'metadata': metadata})
    # This is deliberately a fixture content-consistency context projection,
    # not authentic scientific/Runtime admission. Exact role-profile artifacts
    # are real CAS bytes; their institutional credibility is not established.
    input_refs = [InputRef(artifact_id=r.artifact_id, role=role) for role, r in refs.items()]
    ref = persist_backtest_report(store, adapted, inputs=input_refs)
    ev = fb.produce_empirical_calibration_evidence(store, ref, context=context)
    record = {'label': label, 'surface': 'actualReport→fixtureRoleProfileContext→realForecastBridge',
              'context_fixture_only': True, 'actual_EvalSafety_or_scientific_authority': 'UNRUN/not_established',
              'context': context.model_dump(mode='json'), 'report_ref': ref.model_dump(mode='json'),
              'evidence': ev.model_dump(mode='json'), 'requested': sum(s.interval_requested_count for s in adapted.scenarios),
              'evaluated': sum(s.interval_evaluated_count for s in adapted.scenarios),
              'required_partial_basis_property': 'FAIL' if label == 'forecast_partial' and ev.usable_for_calibration else 'PASS'}
    if ev.usable_for_calibration:
        evidence_ref = fb.persist_empirical_calibration_evidence(store, ev)
        fresh = fb.load_empirical_calibration_evidence(FileSystemCAS(store.root), evidence_ref)
        assert fresh == ev
        record['persisted_evidence_ref'] = evidence_ref.model_dump(mode='json')
        record['fresh_evidence_reader'] = True
    fake = context.model_copy(update={'observed_outcome_ref': context.observed_outcome_ref.model_copy(update={'identity_value': 'observation://foreign/v1'})})
    forged = fb.produce_empirical_calibration_evidence(store, ref, context=fake)
    assert not forged.usable_for_calibration and forged.failure_codes
    record['counterfeit_context_negative'] = forged.model_dump(mode='json')
    records.append(record)

bridge_probe('forecast_complete', complete_store, complete_report.model_copy(update={'degraded': True, 'trust_eligible': False, 'degraded_reasons': ['predictive_only_calibration_bridge_pending']}))
bridge_probe('forecast_partial', partial_store, partial_report)

origins = []
for name, module in sorted(sys.modules.items()):
    if not name.startswith('polisyos') or not getattr(module, '__file__', None): continue
    path = Path(module.__file__).resolve()
    if path.suffix != '.py': continue
    assert path.is_relative_to(INPUT), str(path)
    rel = path.relative_to(INPUT).as_posix()
    expected = subprocess.check_output(['git', 'rev-parse', f'{SOURCE}:{rel}'], cwd=GITROOT, text=True).strip()
    raw = path.read_bytes(); actual = hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    assert actual == expected, (name, rel)
    origins.append({'module': name, 'path': str(path), 'git_blob': actual, 'sha256': hashlib.sha256(raw).hexdigest()})
(HERE/'module-origins.json').write_text(json.dumps(origins, sort_keys=True, indent=2))
output = {'source': SOURCE, 'tree': '072e8906ac69f5b3589550a8bd9d57b4cb41b4a3', 'review_source': '71ec2e0758cd7cd93423d3a91afe1a07cef61401',
          'source_archive_sha256': '05281f23a820c8f4ed96c468bca8e4c5e31ec62736b87271cf5f6e2b03fa9c44',
          'records': records, 'loaded_origins': len(origins), 'origin_mismatches': 0,
          'interpreter': sys.version, 'executable': sys.executable, 'pid': os.getpid(),
          'packages': {p: importlib.metadata.version(p) for p in ['numpy', 'scipy', 'pydantic', 'statsmodels']},
          'body_seconds': time.monotonic()-started, 'peak_rss_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
          'property_status': 'FAIL baseline downstream interval-basis escape reproduced',
          'authority': 'none; configured synthetic facts/fixture prerequisites; public mechanics only',
          'ETS_actual_producer': 'UNRUN this baseline consumer probe; unchanged producer handled in existing source-bound receipt',
          'S10_Runtime_or_authentic_credible_evaluation': 'UNRUN'}
print(json.dumps(output, sort_keys=True, indent=2, allow_nan=False))
(HERE/'baseline-result.json').write_text(json.dumps(output, sort_keys=True, indent=2, allow_nan=False))
assert partial['eligible_for_promotion'] is False, 'Limited interval basis escaped actual full CalibrationValidationRunner→Matrix→Leaderboard→CAS'
