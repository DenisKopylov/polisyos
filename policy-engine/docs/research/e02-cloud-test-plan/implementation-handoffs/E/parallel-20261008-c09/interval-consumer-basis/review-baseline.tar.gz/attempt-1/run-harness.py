from __future__ import annotations
import json
import os
from pathlib import Path
import resource
import subprocess
import time

here=Path(__file__).resolve().parent
env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';env['PYTHONPATH']=str(here/'input/policy-engine/src')
cmd=['/workspace/e02-F-closeout-20261006/policy-engine/.venv/bin/python',str(here/'probe.py')]
t=time.monotonic();r=subprocess.run(cmd,cwd=here,capture_output=True,text=True,env=env)
(here/'probe.stdout.json').write_text(r.stdout);(here/'probe.stderr.txt').write_text(r.stderr)
record={'command':cmd,'cwd':str(here),'source_sha':'ee0b2c85289d8c5537ba4e01713d9be71e2f557e','source_tree':'072e8906ac69f5b3589550a8bd9d57b4cb41b4a3','selected_environment':{'PYTHONPATH':env['PYTHONPATH'],'PYTHONDONTWRITEBYTECODE':env['PYTHONDONTWRITEBYTECODE']},'returncode':r.returncode,'wall_seconds':time.monotonic()-t,'child_peak_rss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'stdout':str(here/'probe.stdout.json'),'stderr':str(here/'probe.stderr.txt')}
(here/'harness.json').write_text(json.dumps(record,indent=2,sort_keys=True));print(json.dumps(record,indent=2,sort_keys=True))
raise SystemExit(r.returncode)
