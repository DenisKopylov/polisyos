from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import stat
import subprocess

ROOT = Path('/workspace/e02-F-closeout-20261006')
AUDIT = Path('/tmp/e02-F-continuation-20261006/active-environment-relocation')

def manifest(root):
    items = []
    for p in sorted(root.rglob('*')):
        mode = stat.S_IMODE(p.lstat().st_mode)
        r = {'path': str(p.relative_to(root)), 'mode': mode}
        if p.is_symlink():
            r.update(kind='symlink', target=os.readlink(p))
        elif p.is_file():
            h = hashlib.sha256()
            with p.open('rb') as f:
                for chunk in iter(lambda: f.read(1024 * 1024), b''):
                    h.update(chunk)
            r.update(kind='file', bytes=p.stat().st_size, sha256=h.hexdigest())
        elif p.is_dir():
            r['kind'] = 'directory'
        else:
            raise ValueError('Unrecognized active input: ' + str(p))
        items.append(r)
    return items

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args]).decode()

plan = json.loads((AUDIT / 'plan.json').read_text())
state = {'plan': plan, 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'refs_before': git('for-each-ref', '--format=%(refname) %(objectname)'),
         'worktree_registrations_before': git('worktree', 'list', '--porcelain'),
         'root_head_before': git('rev-parse', 'HEAD').strip(),
         'root_tree_before': git('rev-parse', 'HEAD^{tree}').strip(), 'components': []}
if (AUDIT / 'before.json').exists():
    state = json.loads((AUDIT / 'before.json').read_text())
    state['resumed_after_canonical_symlink_ENOSPC'] = True
else:
    for pair in plan['pairs']:
        source, destination = Path(pair['source']), Path(pair['destination'])
        assert source.is_dir() and not source.is_symlink() and not destination.exists()
        before = manifest(source)
        state['components'].append({**pair, 'before': before})
    (AUDIT / 'before.json').write_text(json.dumps(state, indent=2) + '\n')
# The old environment/cache files share hardlinks: both active trees must move
# before the original filesystem frees their data and can accept symlinks.
for component in state['components']:
    source, destination = Path(component['source']), Path(component['destination'])
    if destination.exists():
        assert manifest(destination) == component['before']
        assert not source.exists()
    else:
        assert manifest(source) == component['before']
        shutil.move(str(source), str(destination))
        assert manifest(destination) == component['before']
for component in state['components']:
    source, destination = Path(component['source']), Path(component['destination'])
    assert not source.exists()
    source.symlink_to(destination, target_is_directory=True)
    after = manifest(source)
    assert after == component['before'], 'Active input byte/mode/link identity changed'
    component.update(after=after, check='PASS', canonical_link=os.readlink(source))
state['refs_after'] = git('for-each-ref', '--format=%(refname) %(objectname)')
state['worktree_registrations_after'] = git('worktree', 'list', '--porcelain')
assert state['refs_after'] == state['refs_before']
assert state['worktree_registrations_after'] == state['worktree_registrations_before']
assert state['root_head_before'] == git('rev-parse', 'HEAD').strip()
assert state['root_tree_before'] == git('rev-parse', 'HEAD^{tree}').strip()
state['outcome'] = 'PASS'
state['byte_count'] = sum(r.get('bytes', 0) for c in state['components'] for r in c['before'])
state['file_count'] = sum(r.get('kind') == 'file' for c in state['components'] for r in c['before'])
state['root_python_probe'] = subprocess.check_output(
    [str(ROOT / 'policy-engine/.venv/bin/python'), '-c',
     'import sys,numpy,scipy,jax; print(sys.version); print(sys.prefix); print(numpy.__version__,scipy.__version__,jax.__version__)']).decode()
(AUDIT / 'receipt.json').write_text(json.dumps(state, indent=2) + '\n')
print(json.dumps({k:state[k] for k in ['outcome','byte_count','file_count','root_head_before','root_tree_before','root_python_probe']}))
