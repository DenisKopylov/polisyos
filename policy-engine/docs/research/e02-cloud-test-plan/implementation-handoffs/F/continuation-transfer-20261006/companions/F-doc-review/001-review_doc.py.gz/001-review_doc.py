"""Read-only byte and caption audit; no product test or tracked write."""
import argparse
import collections
import hashlib
import json
import pathlib
import re
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument("--repository-root", type=pathlib.Path, required=True)
parser.add_argument("--semantic-review", type=pathlib.Path, required=True)
parser.add_argument("--output", type=pathlib.Path, required=True)
args = parser.parse_args()
repo = args.repository_root
doc_path = "policy-engine/docs/research/e02-cloud-test-plan/closure-decisions/F.md"
prefix = "policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/"
def git(*argv):
    return subprocess.check_output(["git", *argv], cwd=repo)
def binding(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
data = (repo / doc_path).read_bytes()
doc = data.decode("utf-8")
head = git("rev-parse", "HEAD").decode().strip()
old = git("show", f"{head}:{doc_path}")
diff = git("diff", "--", doc_path)
semantic_bytes = args.semantic_review.read_bytes()
semantic = json.loads(semantic_bytes)
expected_semantic_hash = "71f1c71ba204a538a70c042e9d4a11e4a1fe960df5dc1bd3f33ed133acf9b8d8"
assert hashlib.sha256(semantic_bytes).hexdigest() == expected_semantic_hash
rows = re.findall(r"^\| (B\d+|LA-\d+) \| (.*?) \|", doc, re.M)
dispositions = {name: text.rsplit("; ", 1)[-1].strip() for name, text in rows}
counts = dict(collections.Counter(dispositions.values()))
expected_counts = semantic["counts"]["current_continuation"]
assert counts == expected_counts and len(rows) == 35
assert len(re.findall(r'^\| <a id="bundle-', doc, re.M)) == 17
assert "**30 closed / 4 limited / 1 held**" in doc
assert "**25 closed / 9 limited / 1 held**" in doc
assert "**33 PASS / 2 UNRUN**" in doc
assert "formal finding acceptance G не выдана" in doc
assert "Сохранённые 160-panel/4000-RDD scientific waves не перезапускались" in doc
assert "Separately reported ABM diagnostic FAIL remains red; selected base replay does not establish P41." in doc
assert "24 complete default float32/x64-off profiles byte-identical" in doc
assert "Separate 40 integer/lower-float cases have 30 whole-patch matches, 10 x64 subsidy dtype changes and 8 government reduction deltas" in doc
assert "these are separately measured profiles/categories, not an additive case denominator" in doc
assert "30/40 whole patches byte-identical under default x64-off" not in doc
locators = []
pat = r"`(F/[^`@]+\.json)@([0-9a-f]{40})`; (\d+) bytes, SHA-256 `([0-9a-f]{64})`"
for path, ref, size, digest in re.findall(pat, doc):
    raw = git("show", f"{ref}:{prefix}{path}")
    actual = binding(raw)
    assert actual == {"bytes": int(size), "sha256": digest}, (path, actual)
    locators.append({"git_ref": ref, "path": prefix+path, **actual, "outcome": "PASS"})
assert len(locators) == 14
source = "8236d9c368336a5ea20c1586f29aea7321db6536"
source_tree = git("rev-parse", f"{source}^{{tree}}").decode().strip()
assert source_tree == "724a77c88d4e6699ffead58a5e3e3990fb88640a"
product_delta = git("diff", "--name-only", source, head, "--", "policy-engine/src", "policy-engine/workers").decode().splitlines()
assert not product_delta
links = []
for target in re.findall(r'\]\(([^)]+)\)', doc):
    path, _, anchor = target.partition("#")
    full = (repo/doc_path).parent/path
    exists = full.is_file()
    links.append({"target": target, "exists_now": exists, "outcome": "PASS" if exists else "UNRUN", "reason": None if exists else "ROOT same-delivery ledger companion not yet materialized; publication must include this exact path."})
fiscal = json.loads(git("show", "3912782bfd55cc87f76757310c32603ecbe58cc3:"+prefix+"F/economic-fiscal-precision-continuation-20261006.json"))
fiscal_compat = fiscal["property"]["compatibility_profile"]
assert "olddefault32whole24exact, lower40whole30/dtype10/sum8, notall40equal" in fiscal_compat
assert (repo/doc_path).read_bytes() == data
result = {
    "schema": "f-doc-companion-review/1",
    "reviewer": "/root/fit_tmle",
    "verdict": "GO_BOUNDED_DOC_CONTENT",
    "scope": "Full updated F.md and literal HEAD diff read; caption/byte-custody audit only. No product/test/scientific rerun or final35 re-adjudication.",
    "document": {"path": doc_path, "base_head": head, "base_blob": git("rev-parse", f"{head}:{doc_path}").decode().strip(), "base": binding(old), "worktree": binding(data), "worktree_git_blob": hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest(), "literal_diff": binding(diff), "read_entire_document_and_diff": True},
    "tested_product_source": {"sha": source, "tree": source_tree, "product_delta_to_doc_base": product_delta, "new_scientific_execution": "UNRUN: deliberately outside documentation review scope"},
    "frozen_final35_review": {"original_path": str(args.semantic_review), **binding(semantic_bytes), "unchanged": True},
    "counts": semantic["counts"],
    "actual_doc_current_35_rows": dispositions,
    "bundle_count": 17,
    "receipt_locators": locators,
    "links": links,
    "caption_correction": {"initial_outcome": "FAIL", "initial_observed_diff_worktree_blob_prefix": "ec1b86abe", "initial_literal_caption": "30/40 whole patches byte-identical under default x64-off, other dtype/reduction deltas explicitly declared.", "defect": "Distinct 24 default32/x64-off and 40 lower/integer mixed-x64 denominators were conflated.", "fixed_outcome": "PASS", "fixed_criterion": "24 full default32/x64-off profiles exact; separate lower40 whole30/dtype10/sum8 categories, not additive denominators.", "deciding_git_ref": "3912782bfd55cc87f76757310c32603ecbe58cc3", "deciding_path": prefix+"F/economic-fiscal-precision-continuation-20261006.json", "pointer": "/property/compatibility_profile", "actual_receipt_caption": fiscal_compat, "scientific_replay": "UNRUN: none needed for wording correction"},
    "preserved_limits": ["Formal G acceptance not issued; 33/2 describe per-ID bounded checks, not all raw outcomes.", "Real-data identification issuer/verifier bridge, Runtime whole-node admission, and B56 competing-study budget remain UNRUN.", "Historical DID/RDD scientific panels were not rerun on source8236.", "Global schema/format/invocation red, 38 static UNKNOWN, ABM diagnostic FAIL and P41 not_established remain explicit.", "Supported finite API loader/ABI window only; computed/external callers remain unknown.", "Missing current35 ledger link is a same-delivery publication prerequisite, not an observed published file."],
    "tracked_writes": [],
}
payload = json.dumps(result, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
result["review_signature"] = {"kind": "reviewer-attributed canonical-content SHA256, not external authority or cryptographic identity", "sha256": hashlib.sha256(payload).hexdigest()}
args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2)+"\n")
print(json.dumps({"outcome": "PASS", "verdict": result["verdict"], "doc": result["document"]["worktree"], "locators_checked": len(locators), "counts": counts, "missing_publication_links": [x["target"] for x in links if not x["exists_now"]], "review": binding(args.output.read_bytes())}, ensure_ascii=False))
