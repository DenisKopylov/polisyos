"""Prepare byte-bound extra receipts. No ledger outcome changes or Git writes."""
from __future__ import annotations

import argparse
import hashlib
import json
import pathlib
import re
import subprocess
import sys

PREFIX = 'policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/F/'
ALLOWED_OUTPUT = pathlib.Path('/tmp/e02-F-continuation-20261006/root-ledger-draft')
FULL_SHA = re.compile(r'[0-9a-f]{40}\Z')


def git(repo, *args):
    return subprocess.check_output(['git', '-C', repo, *args], stderr=subprocess.PIPE)


def tree(repo, ref):
    return git(repo, 'rev-parse', ref + '^{tree}').decode().strip()


def prepare(repo, specifications):
    if not isinstance(specifications, list) or not specifications:
        raise ValueError('Nonempty JSON list required; unpublished placeholder entries are not admitted')
    records = []
    identities = set()
    lanes = set()
    for spec in specifications:
        allowed_keys = {'lane', 'head', 'path', 'bytes', 'sha256', 'implementation_sha', 'candidate_tree_sha'}
        if not isinstance(spec, dict) or set(spec) - allowed_keys:
            raise ValueError('Only receipt identity/hash/tree fields are accepted; no state, closure, authority or result overrides')
        lane, head, path = (spec[k] for k in ('lane', 'head', 'path'))
        if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]*', lane):
            raise ValueError('Stable unique lane name required')
        if not FULL_SHA.fullmatch(head):
            raise ValueError('Receipt carrier head must be full immutable 40-hex Git SHA')
        if not isinstance(path, str) or not path.startswith(PREFIX) or not path.endswith('.json') or '..' in pathlib.PurePosixPath(path).parts:
            raise ValueError('Exact repository-relative F primary receipt path required')
        if (head, path) in identities or lane in lanes:
            raise ValueError('Duplicate component or lane in the supplied attachment packet')
        identities.add((head, path))
        lanes.add(lane)
        raw = git(repo, 'show', head + ':' + path)
        receipt = json.loads(raw)
        actual_hash = hashlib.sha256(raw).hexdigest()
        if 'bytes' in spec and spec['bytes'] != len(raw):
            raise ValueError('Declared receipt carrier size differs from actual Git bytes')
        if 'sha256' in spec and spec['sha256'] != actual_hash:
            raise ValueError('Declared receipt carrier hash differs from actual Git bytes')
        implementations = receipt.get('implementation_commits', [])
        if not isinstance(implementations, list) or not all(isinstance(c, str) and FULL_SHA.fullmatch(c) for c in implementations):
            raise ValueError('Unsupported implementation_commits schema; exact owner packet required')
        source = receipt.get('candidate_source_sha', receipt.get('candidate_sha', receipt.get('implementation_sha', implementations[-1] if implementations else None)))
        if not isinstance(source, str) or not FULL_SHA.fullmatch(source):
            raise ValueError('Exact candidate implementation source required; carrier head is not inferred as code')
        source_tree = tree(repo, source)
        receipt_tree = receipt.get('candidate_tree_sha', receipt.get('candidate_tree'))
        if receipt_tree != source_tree:
            raise ValueError('Primary receipt candidate tree does not bind its declared implementation candidate')
        external = receipt.get('external_tested_source')
        if external is not None and (not isinstance(external, dict) or external.get('sha') != source or external.get('tree') != source_tree):
            raise ValueError('External tested source must match the explicit canonical candidate SHA/tree; receipt carrier is not inferred as code')
        if 'implementation_sha' in spec and spec['implementation_sha'] != source:
            raise ValueError('Requested source does not match the canonical receipt candidate; scientific source remains a separate receipt field')
        if 'candidate_tree_sha' in spec and spec['candidate_tree_sha'] != source_tree:
            raise ValueError('Requested candidate tree differs from actual implementation tree')
        records.append({'lane': lane, 'head': head, 'path': path, 'bytes': len(raw), 'sha256': actual_hash, 'implementation_sha': source, 'candidate_tree_sha': source_tree})
    return records


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--repo', default='/workspace/e02-F-closeout-20261006')
    p.add_argument('--specs', required=True, help='Full published lane/head/path; optional expected carrier bytes/hash and implementation/tree')
    p.add_argument('--output', default=str(ALLOWED_OUTPUT / 'extra-registry-prepared.json'))
    a = p.parse_args()
    output = pathlib.Path(a.output).resolve()
    if output.parent != ALLOWED_OUTPUT.resolve() or output.exists():
        raise ValueError('Only a unique scratch attachment filename is allowed; existing draft outputs are not overwritten')
    records = prepare(a.repo, json.loads(pathlib.Path(a.specs).read_text()))
    output.write_text(json.dumps(records, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'check': 'PASS', 'components': len(records), 'output': str(output), 'sha256': hashlib.sha256(output.read_bytes()).hexdigest(), 'bytes': output.stat().st_size, 'ledger_state_changes': 0, 'scientific_reruns': 0}))


if __name__ == '__main__':
    main()
