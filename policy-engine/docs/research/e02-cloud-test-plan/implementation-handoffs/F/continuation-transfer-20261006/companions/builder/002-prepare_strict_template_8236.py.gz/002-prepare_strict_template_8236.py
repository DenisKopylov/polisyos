"""Prepare a strict original35 recommendation for ROOT, never a ROOT decision.

No tracked writes or scientific reruns. Published owner bytes and original card
bindings are read back. New API closure is conditional on the final Git site
packet; this template deliberately keeps publication checkpoints blocked.
"""
from __future__ import annotations

import argparse
import collections
import copy
import hashlib
import importlib.util
import json
import pathlib
import subprocess

HERE = pathlib.Path(__file__).parent
OUT = pathlib.Path('/tmp/e02-F-continuation-20261006/root-ledger-draft')
REPO = '/workspace/e02-F-closeout-20261006'
ROOT = '8236d9c368336a5ea20c1586f29aea7321db6536'
TREE = '724a77c88d4e6699ffead58a5e3e3990fb88640a'
QUALITY_HEAD = '613a55a5946bdeff2dc849f2488fb88c81b01360'
PREFIX = 'policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/F/'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def local_ref(path):
    path = pathlib.Path(path)
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}


def main():
    spec = importlib.util.spec_from_file_location('current_builder', HERE / 'build_current_pack.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    builder = module.Builder(argparse.Namespace(repo=REPO, root_sha=ROOT, outdir=str(OUT)))
    assert builder.root_tree == TREE
    audit = json.loads((OUT / 'full-audit.json').read_bytes())
    recon_path = HERE.parent / 'original35-reconciliation.json'
    recon = json.loads(recon_path.read_bytes())
    expected = {r['finding_id']: r for r in recon['rows']}
    originals = {r['finding_id']: r for r in audit['rows']}
    assert len(expected) == len(originals) == 35
    quality_path = PREFIX + 'source-quality-freeze-20261006.json'
    quality_ref = builder.ref(QUALITY_HEAD, quality_path)
    quality_ref = {k: quality_ref[k] for k in ('head', 'path', 'bytes', 'sha256')}
    quality = json.loads(builder.raw(QUALITY_HEAD, quality_path))
    assert quality['candidate_source_sha'] == ROOT and quality['candidate_tree_sha'] == TREE

    def canonical_ref(ref):
        actual = builder.ref(ref.get('head', ref.get('git_ref')), ref['path'], ref)
        result = {k: actual[k] for k in ('head', 'path', 'bytes', 'sha256')}
        if ref.get('json_pointer'):
            result['json_pointer'] = ref['json_pointer']
        return result

    rows = []
    bindings = []
    for ident, original in originals.items():
        refs = [canonical_ref(original['receipt_ref'])]
        for entry in original.get('owner_proposals_complete', []):
            current = canonical_ref(entry['receipt_ref'])
            current['json_pointer'] = entry['json_pointer']
            if current not in refs:
                refs.append(current)
        for current in original.get('latest_published_receipt_refs', []):
            ref = canonical_ref(current)
            if ref not in refs:
                refs.append(ref)
        row = {key: copy.deepcopy(original[key]) for key in [
            'finding_id', 'check', 'outcome', 'technical_original_criterion_recommendation',
            'criterion_short_ru', 'actual_consumer', 'source_scope', 'oracle_and_negative',
            'original_criterion_remainder', 'separate_unavailable_inputs_or_authority',
            'latest_owner_packet', 'next_owner', 'technical_check']}
        row['decision_basis'] = 'independently_reconciled'
        row['deciding_receipt_refs'] = refs
        if ident in ('LA-007', 'LA-019', 'LA-020'):
            row.update(check='PASS', outcome='closed', technical_check='PASS',
                       technical_original_criterion_recommendation='closed')
            row['criterion_short_ru'] = {
                'LA-007': 'Exact id_engine.py sibling already absent at base198; bounded maintained package/loader/docs/install migration',
                'LA-019': 'Exact causal_engine.py/interference.py siblings already absent at base198; bounded maintained package/caller/docs/install migration',
                'LA-020': 'Declared supported public facade/FQN/patch/docs/client/install window on the final common source'}[ident]
            row['actual_consumer'] = 'Declared facade loaders/direct/star/private historical windows → actual native algorithms/FQN/pickle/pydoc/patch consumers → isolated source-wheel and rebuilt-sdist sites, canonical dispatcher/CAS/fresh reader'
            row['source_scope'] += '; exact source8236 site profile, finite supported manifest; computed/external unknown clients remain unestablished'
            row['oracle_and_negative'] = 'Published owner108 native/public identity and finite source census; source8236 final wheel/sdist each199PASS,5source-census deselections,0SKIP/ERROR,90actual LGBM feature-name warnings. Eight installed marker-preserving removals fail. API closure recommendation is conditional on publication/readback of that final site packet and ROOT adoption; old5cd is historical, not substituted for8236.'
            row['original_criterion_remainder'] = 'None for the bounded original supported filename/package/caller/docs/install criterion once the final8236 site packet is attached and ROOT adopts this recommendation. Exact retired siblings were already absent at198, not newly deleted by F.'
            row['separate_unavailable_inputs_or_authority'] = '38 finite UNKNOWN/incomplete export candidates and arbitrary computed/external clients are not established supported consumers. Whole Runtime authority, distinct PDC semantic ingress and G formal finding closure remain separate unissued/unmeasured inputs.'
            row['latest_owner_packet'] = 'Published c4 API owner receipt plus final8236 installed site packet pending its immutable Git carrier; conditional proposal only'
            row['next_owner'] = 'ROOT: bind/adopt the actual final installed packet and finite original criterion recommendation. API owns any additional declared supported client window; G owns separate integration/formal ledger.'
        elif row['outcome'] == 'closed':
            row['latest_owner_packet'] += '; exact source8236 quality-equivalence receipt preserves prior scientific source provenance and all historical red checks separately'
        rows.append(row)
        cards = original['original_source_criterion_refs']
        assert len(cards) == len(expected[ident]['original_card_bindings'])
        for card in cards:
            source = builder.raw(card['source_sha'], card['source_path'])
            start, end = card['lines']
            block = b''.join(source.splitlines(keepends=True)[start - 1:end])
            assert sha(block) == card['sha256'] and len(block) == card['bytes']
            assert block.decode().splitlines()[0] == card['title']
        bindings.append({'finding_id': ident, 'primary_bundle': original['primary_bundle'],
                         'primary_tsv_owner': original['primary_tsv_owner'],
                         'original_source_criterion_refs': [{k: v for k, v in c.items() if k != 'complete_original_block'} for c in cards]})

    draft = {'schema': 'F-root-current35-adjudication/1', 'scope': 'complete35',
             'root_source_sha': ROOT, 'root_source_tree_sha': TREE,
             'formal_G_ledger_acceptance': 'not_issued', 'rows': rows,
             'pending_scientific_blockers': {'status': 'freeze_blocked', 'checks': [
                 {'owner': 'ROOT source quality', 'check': 'PASS', 'head': ROOT,
                  'deciding_receipt_refs': [quality_ref],
                  'scope': 'Owned formatting/AST and finite source-equivalence checkpoint only; global format/schema/static FAIL preserved'},
                 {'owner': 'API/Foundry final installed carrier', 'check': 'UNRUN', 'head': ROOT,
                  'scope': 'Actual scratch199PASS×2/8expectedFAIL observed; immutable Git publication/readback/attachment pending. This is a packet checkpoint, not a scientific-method failure.'},
                 {'owner': 'ROOT adoption and independent final ledger', 'check': 'UNRUN', 'head': ROOT,
                  'scope': 'ROOT must independently review and adopt all35 proposal rows plus final native carrier; producer of this template has no ROOT decision authority.'}]}}
    assert collections.Counter(r['outcome'] for r in rows) == {'closed': 25, 'limited': 9, 'held': 1}
    assert collections.Counter(r['check'] for r in rows) == {'PASS': 33, 'UNRUN': 2}
    assert sum(len(r['original_source_criterion_refs']) for r in bindings) == 36
    assert len({r['primary_bundle'] for r in bindings}) == 17
    builder.apply_root_adjudication(copy.deepcopy(audit['rows']), draft,
                                    {'path': str(OUT / 'root-adjudication-template-8236.json'),
                                     'role': 'proposed only, ROOT independent adoption required'})
    output = OUT / 'root-adjudication-template-8236.json'
    output.write_text(json.dumps(draft, ensure_ascii=False, indent=2) + '\n')
    sidecar = {'schema': 'F-strict-adjudication-template-inputs/1',
               'role': 'CAU scratch recommendation for ROOT review; not a ROOT decision, scientific acceptance or G closure',
               'root_source_sha': ROOT, 'root_source_tree': TREE,
               'template': local_ref(output), 'previous_scratch_audit': local_ref(OUT / 'full-audit.json'),
               'original35_reconciliation': local_ref(recon_path),
               'literal_previous_ROOT_draft': local_ref('/tmp/e02-F-continuation-20261006/root-adjudication-draft.json'),
               'original_denominator': {'findings': 35, 'bundles': 17, 'card_bindings': 36},
               'proposed_outcomes': dict(collections.Counter(r['outcome'] for r in rows)),
               'proposed_checks': dict(collections.Counter(r['check'] for r in rows)),
               'bindings': bindings,
               'new_published_quality_registry_spec': {'lane': 'ROOT-source-quality', **quality_ref,
                                                     'implementation_sha': ROOT, 'candidate_tree_sha': TREE},
               'missing_registry_specs': [{'lane': 'api_final_installed', 'head': None, 'path': None,
                                            'status': 'pending actual publication, do not pass null refs to registry helper',
                                            'known_source_sha': ROOT, 'known_source_tree': TREE,
                                            'ready_author_packet': local_ref('/tmp/e02-F-continuation-20261006/api/installed-final-8236/final-consumer-packet.json'),
                                            'ready_independent_review': local_ref('/tmp/e02-F-continuation-20261006/foundry/installed-final-wave/8236-review/review.json')}],
               'institutional_or_data_inputs_not_freeze_blockers': ['Current Runtime/verifier/PDC semantic ingress', 'B56 real admitted common workload/budget', 'Selected exact Lex NormPack/as_of law', 'LA035 real optimizer and normative unit/population/time/sign intent'],
               'historical_RED_and_unknowns_preserved': ['26static regressions/78new unresolved FAIL', '3outside-F format FAIL', '2Core schema FAIL/five nested optional manifest_profile_sha256 projections', '38finite UNKNOWN export candidates', 'historical FAIL/ERROR/SKIP/warnings/source-specific native receipts', 'P41 not_established', '175c historical custody UNRUN/nondeciding lint raw absence'],
               'parser_and_Git_reference_shape_check': 'PASS_BOUNDED',
               'independent_ROOT_adoption': 'UNRUN', 'final_immutable_packet_independent_review': 'UNRUN'}
    side = OUT / 'root-adjudication-template-8236-input-bindings.json'
    side.write_text(json.dumps(sidecar, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'template': local_ref(output), 'binding_sidecar': local_ref(side),
                      'proposed_outcomes': sidecar['proposed_outcomes'], 'proposed_checks': sidecar['proposed_checks'],
                      'ROOT_adoption': 'UNRUN', 'Git_installed_packet': 'UNRUN'}))


if __name__ == '__main__':
    main()
