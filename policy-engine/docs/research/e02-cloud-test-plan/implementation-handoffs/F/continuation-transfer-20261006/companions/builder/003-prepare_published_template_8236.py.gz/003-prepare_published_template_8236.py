"""Attach actual published final receipts to the held original35 proposal.

Only unique scratch outputs are written. This is a metadata proposal for ROOT,
not ROOT adoption, a scientific rerun, final independent review or G closure.
"""
from __future__ import annotations

import argparse
import collections
import copy
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).parent
OUT = Path('/tmp/e02-F-continuation-20261006/root-ledger-draft')
REPO = '/workspace/e02-F-closeout-20261006'
SOURCE = '8236d9c368336a5ea20c1586f29aea7321db6536'
TREE = '724a77c88d4e6699ffead58a5e3e3990fb88640a'
PREFIX = 'policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/F/'
API = {'lane': 'API-final-installed', 'head': '90c72b51155321684c788cd5a03fbb70fc001d53',
       'path': PREFIX + 'api-installed-final-20261006.json', 'bytes': 50455,
       'sha256': 'b01b2dd3d1083298b700beab9f4b97d7837f5172eeae4758bd902bdadaf5fa29',
       'implementation_sha': SOURCE, 'candidate_tree_sha': TREE}
FRY = {'lane': 'FRY-final-installed', 'head': 'a2d55a1942e1f56f35cf2b9772ae56b0b46de95d',
       'path': PREFIX + 'installed-final-consumer-20261006.json', 'bytes': 60843,
       'sha256': '4d57c791f685a12d637564e35255fc6142915b154eae6e152bd9b480c1457ab8',
       'implementation_sha': SOURCE, 'candidate_tree_sha': TREE}


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def local(path):
    path = Path(path)
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': digest(raw)}


def save(name, value):
    path = OUT / name
    if path.exists():
        raise ValueError('Held scratch outputs cannot be overwritten: ' + str(path))
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    return local(path)


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    original_path = OUT / 'root-adjudication-template-8236.json'
    binding_path = OUT / 'root-adjudication-template-8236-input-bindings.json'
    assert local(original_path)['sha256'] == '4a7d77f9248a271a715311005c4eb141aaa7389e7336c35804d1ab149e7812b1'
    assert local(binding_path)['sha256'] == '9b8bc10730c817b543409e0ae4bd2ccb3b9bbb351d07986944f98af7eef817d2'
    proposal = json.loads(original_path.read_bytes())
    bindings = json.loads(binding_path.read_bytes())
    module = load_module('current_pack', HERE / 'build_current_pack.py')
    helper = load_module('extra_registry', HERE / 'prepare_extra_registry.py')
    builder = module.Builder(argparse.Namespace(repo=REPO, root_sha=SOURCE, outdir=str(OUT)))
    assert builder.root_tree == TREE
    specs = json.loads((OUT / 'current-extra-specifications-eight-8236.json').read_bytes()) + [API]
    prepared = helper.prepare(REPO, specs)
    specs_ref = save('current-extra-specifications-nine-8236.json', specs)
    registry_ref = save('current-extra-registry-nine-8236.json', prepared)

    def ref(entry, pointer=None):
        actual = builder.ref(entry['head'], entry['path'], entry)
        result = {k: actual[k] for k in ('head', 'path', 'bytes', 'sha256')}
        if pointer:
            result['json_pointer'] = pointer
        return result

    for item in (API, FRY):
        builder.add_receipt(item['lane'], item['head'], item['path'], item)
    api = builder.receipts[(API['head'], API['path'])]
    fry = builder.receipts[(FRY['head'], FRY['path'])]
    manifest_ref = ref({'head': API['head'], **api['full_output_manifest']})
    manifest = json.loads(builder.raw(manifest_ref['head'], manifest_ref['path']))
    assert manifest['source_sha'] == SOURCE and len(manifest['records']) == 115
    assert len(manifest['external_full_output_refs']) == 53
    for item in manifest['records']:
        assert (API['head'], item['path']) in builder.material
    for item in manifest['external_full_output_refs']:
        assert (item['git_sha'], item['path']) in builder.material
    review_ref = ref({'head': FRY['head'], 'path': fry['complete_independent_review']})
    installed = builder.current_installed_evidence()
    assert installed['check'] == 'PASS'
    # Full source-card line bindings remain immutable and are rechecked here.
    for row in bindings['bindings']:
        for card in row['original_source_criterion_refs']:
            raw = builder.raw(card['source_sha'], card['source_path'])
            first, last = card['lines']
            block = b''.join(raw.splitlines(keepends=True)[first - 1:last])
            assert digest(block) == card['sha256'] and len(block) == card['bytes']
            assert block.decode().splitlines()[0] == card['title']

    for row in proposal['rows']:
        ident = row['finding_id']
        if ident in ('LA-007', 'LA-019', 'LA-020'):
            index = {'LA-007': 0, 'LA-019': 1, 'LA-020': 2}[ident]
            row['deciding_receipt_refs'] += [ref(API, '/per_id/' + str(index)), ref(FRY)]
            row['oracle_and_negative'] = (
                'Published actual source8236 API census16819tracked/6815parsed,243literalimports;225dynamicAST candidates(155unresolved/36finite/13other/21literal); '
                '753filename lexical matches/73ASTloader calls with4runtime computed unresolved. Computed candidates are not established clients. '
                'Final actual wheel/sdist each199PASS,5source-census deselections,0SKIP/ERROR,90LGBM feature-name warnings; '
                'eight installed marker-preserving removals actualFAIL and complete3459resource files/site postguardsPASS. '
                'Both immutable primary receipts and all115author+53independent complete bodies are Git-bound. ROOT adoption remains UNRUN; old5cd/ab56 native results remain historical.')
            row['original_criterion_remainder'] = (
                'None for the bounded original supported filename/package/caller/docs/install criterion, proposed for ROOT adoption using actual final8236 published packet. '
                'Retired exact sibling files were already absent at198, not newly deleted by F.')
            row['latest_owner_packet'] = (
                'API final source8236 receipt carrier90c72b51155321684c788cd5a03fbb70fc001d53 plus independently executed installed consumer carriera2d55a1942e1f56f35cf2b9772ae56b0b46de95d; '
                'source/census/installed publication prerequisite fulfilled; ROOT literal adoption still UNRUN.')
            row['next_owner'] = 'ROOT: independently adopt the finite original criterion recommendation. API: additional declared supported client windows. G: separate integration/formal ledger.'
        elif ident == 'B213':
            row['criterion_short_ru'] = 'Actual requested estimand_type/contrast/target identify/estimate and exact source/CAS/report binding'
            row['actual_consumer'] = 'DoWhyIdentifyEstimate → actual requested estimand_type/contrast/target → genuine identify_effect/estimate_effect → canonical report factory and persisted CAS/fresh reader'
        elif ident == 'LA-003':
            row['oracle_and_negative'] = row['oracle_and_negative'].replace('Native124PASS/1 unrelatedABM FAIL retained', 'Native124PASS/1 separately reported ABM diagnostic FAIL retained; P41 not_established')
            row['original_criterion_remainder'] = 'None for the bounded original native fiscal/labor migration profile; separately reported ABM diagnostic FAIL remains pending its semantic owner packet, with P41 not_established; no whole-law or production acceptance inferred.'

    checkpoints = proposal['pending_scientific_blockers']['checks']
    checkpoints[1] = {'owner': 'API/Foundry final installed carrier', 'check': 'PASS', 'head': SOURCE,
                      'deciding_receipt_refs': [ref(API), ref(FRY), manifest_ref, review_ref],
                      'scope': 'Actual exact8236 published API assembly/census and independent199PASS×2,8expectedFAIL,complete site postguards; no production authority/budget or global quality acceptance.'}
    checkpoints[2]['scope'] = 'ROOT must independently review/adopt all35 proposal rows and final published packet; this scratch producer has no ROOT decision authority. FIT independent semantic GO is a separate reviewer receipt, not ROOT adoption.'
    assert collections.Counter(r['outcome'] for r in proposal['rows']) == {'closed': 25, 'limited': 9, 'held': 1}
    assert collections.Counter(r['technical_original_criterion_recommendation'] for r in proposal['rows']) == {'closed': 30, 'limited': 4, 'held': 1}
    assert collections.Counter(r['check'] for r in proposal['rows']) == {'PASS': 33, 'UNRUN': 2}
    builder.apply_root_adjudication(copy.deepcopy(json.loads((OUT / 'full-audit.json').read_bytes())['rows']), proposal,
                                    {'role': 'CAU proposed template only, ROOT adoption UNRUN'})
    proposal_ref = save('root-adjudication-template-published-8236.json', proposal)
    sidecar = {
        'schema': 'F-published-strict-adjudication-template-inputs/1',
        'role': 'CAU proposed metadata for ROOT review; no ROOT decision, new science or G finding closure',
        'root_source_sha': SOURCE, 'root_source_tree': TREE,
        'held_previous_template': local(original_path), 'held_previous_binding_sidecar': local(binding_path),
        'template': proposal_ref, 'extra_specs': specs_ref, 'extra_registry': registry_ref,
        'original_denominator': {'findings': 35, 'bundles': 17, 'card_bindings': 36},
        'current_continuation_outcomes': dict(collections.Counter(r['outcome'] for r in proposal['rows'])),
        'technical_original_criterion_recommendations': dict(collections.Counter(r['technical_original_criterion_recommendation'] for r in proposal['rows'])),
        'checks': dict(collections.Counter(r['check'] for r in proposal['rows'])),
        'bindings': bindings['bindings'], 'published_native_and_API_refs': [ref(API), ref(FRY), manifest_ref, review_ref],
        'new_material_byte_binding': {'check': 'PASS', 'API_author_full_bodies': 115, 'external_independent_full_bodies': 53,
                                      'material_records': len(builder.material), 'decoded_bindings': sum('decoded_sha256' in r for r in builder.material.values())},
        'current_installed_evidence': installed,
        'metadata_deltas': ['Actual API/Foundry publication fulfills prior packet prerequisite; ROOT adoption still UNRUN',
                            'B213 names estimand_type/contrast/target identification/estimation',
                            'LA003 separates ABM diagnostic FAIL and P41 not_established without classifying it inherited or unrelated',
                            'Current25/9/1 outcome labels versus original technical30/4/1 caption distinction'],
        'institutional_or_data_inputs_not_freeze_blockers': bindings['institutional_or_data_inputs_not_freeze_blockers'],
        'historical_RED_and_unknowns_preserved': bindings['historical_RED_and_unknowns_preserved'],
        'ROOT_adoption': 'UNRUN', 'final_immutable_packet_independent_review': 'UNRUN',
        'script': local(__file__), 'builder': local(HERE / 'build_current_pack.py'),
        'helper': local(HERE / 'prepare_extra_registry.py')}
    side_ref = save('root-adjudication-template-published-8236-input-bindings.json', sidecar)
    print(json.dumps({'check': 'PASS', 'scope': 'published metadata binding/proposed template only', 'extra_registry': registry_ref,
                      'template': proposal_ref, 'binding_sidecar': side_ref,
                      'current_counts': sidecar['current_continuation_outcomes'], 'original_technical_counts': sidecar['technical_original_criterion_recommendations'],
                      'checks': sidecar['checks'], 'material': sidecar['new_material_byte_binding'], 'ROOT_adoption': 'UNRUN', 'scientific_reruns': 0}))


if __name__ == '__main__':
    main()
