"""Read exact final published metadata; never rerun scientific algorithms."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json

HERE = Path(__file__).parent
OUT = Path('/tmp/e02-F-continuation-20261006/root-ledger-draft')


def binding(path):
    path = Path(path)
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def main():
    output = OUT / 'final-published-metadata-enhancement-8236.json'
    assert not output.exists(), 'Do not overwrite earlier observations'
    spec = importlib.util.spec_from_file_location('current_pack', HERE / 'build_current_pack.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    builder = module.Builder(argparse.Namespace(repo='/workspace/e02-F-closeout-20261006',
                                               root_sha='8236d9c368336a5ea20c1586f29aea7321db6536',
                                               outdir=str(OUT)))
    registry_path = OUT / 'current-extra-registry-nine-8236.json'
    selected = [r for r in json.loads(registry_path.read_bytes())
                if r['lane'] in ('ROOT-source-quality', 'FRY-final-installed', 'API-final-installed')]
    assert len(selected) == 3
    for record in selected:
        builder.add_receipt(record['lane'], record['head'], record['path'], record)
    installed = builder.current_installed_evidence()
    assert installed['check'] == 'PASS'
    assert len(installed['profiles']) == 2
    for profile in installed['profiles'].values():
        assert profile['passed'] == 199 and len(profile['deselected']) == 5
        assert profile['failed'] == profile['errors'] == profile['skipped'] == 0
    assert len(installed['retained_marker_controls']) == 8
    assert all(r['check'] == 'FAIL' and r['actual_exit_code'] == 1 for r in installed['retained_marker_controls'])
    packets = builder.owner_packets()
    assert len(packets['packets']) == 7
    assert all(p['check'] == 'UNRUN' and p['not_source_freeze_blocker'] for p in packets['packets'])
    assert 'exact selected normpack' in next(p for p in packets['packets'] if p['packet_id'] == 'Lex-current-local-law')['required'][0].lower()
    assert 'P41 not_established' in next(p for p in packets['packets'] if p['packet_id'] == 'A-ABM-diagnostic-semantics')['required'][1]
    result = {'schema': 'F-final-published-metadata-enhancement-check/1', 'check': 'PASS',
              'scope': 'Read-only exact source/receipt metadata and Git/decoded byte binding; no scientific or final independent acceptance',
              'source_sha': builder.root_sha, 'source_tree': builder.root_tree,
              'receipt_inputs': selected, 'current_installed_evidence': installed,
              'minimal_owner_packets': packets,
              'material_binding': {'check': 'PASS', 'full_records': len(builder.material),
                                   'decoded_records': sum('decoded_sha256' in x for x in builder.material.values()),
                                   'manifest_denominators': builder.manifest_denominators},
              'fullbyte_material_refs': list(builder.material.values()),
              'script': binding(__file__), 'builder': binding(HERE / 'build_current_pack.py'),
              'registry': binding(registry_path), 'ROOT_adoption': 'UNRUN',
              'scientific_reruns': 0, 'historical_FAIL_ERROR_SKIP_and_P41_preserved': True,
              'whole_Node_B56_localLaw_GformalClosure': 'UNRUN'}
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'check': 'PASS', 'output': binding(output), 'material': result['material_binding'],
                      'native_profile_counts': [x['passed'] for x in installed['profiles'].values()],
                      'expected_retained_marker_FAIL': 8, 'owner_packet_UNRUN': 7,
                      'ROOT_adoption': 'UNRUN', 'scientific_reruns': 0}))


if __name__ == '__main__':
    main()
