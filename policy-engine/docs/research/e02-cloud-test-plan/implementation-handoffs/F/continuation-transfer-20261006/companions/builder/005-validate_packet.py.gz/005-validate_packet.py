"""Independent metadata/custody guards for the forthcoming F continuation ledger.

Reads immutable source cards and Git receipts. No scientific execution or approval.
The final root schema may add fields; unsupported structure is explicit UNRUN.
"""
from __future__ import annotations
import argparse,collections,gzip,hashlib,json,lzma,pathlib,re,subprocess

CHECKS={'PASS','FAIL','ERROR','SKIP','UNRUN'}
OUTCOMES={'closed','limited','held','open'}
FORMAL_NEGATIVE={False,None,'pending','not_issued','not issued','unissued','UNRUN','not_established'}
ID_PATTERN=re.compile(r'\b(?:B\d+|LA-?\d+)\b')

def normalize_id(value):
 text=str(value).upper().replace('LA-','LA')
 return text

def sha(data):return hashlib.sha256(data).hexdigest()
def load_json(path):
 raw=pathlib.Path(path).read_bytes()
 return json.loads(gzip.decompress(raw) if raw[:2]==b'\x1f\x8b' else lzma.decompress(raw) if raw[:6]==b'\xfd7zXZ\x00' else raw)
def pointer(value,path):
 for key in path.strip('/').split('/') if path.strip('/') else []:
  key=key.replace('~1','/').replace('~0','~')
  value=value[int(key)] if isinstance(value,list) else value[key]
 return value

class Validator:
 def __init__(self,repo,manifest,required_registry=None):
  self.repo=repo;self.manifest=manifest;self.issues=[];self.observations=[];self.cache={};self.current_refs=[];self.historical_refs=[]
  self.required_registry=required_registry
  self.expected={normalize_id(r['finding_id']):r for r in manifest['rows']}
  assert len(self.expected)==35
  assert sum(len(r['original_card_bindings']) for r in self.expected.values())==36
  assert len({r['bundle'] for r in self.expected.values()})==17
 def problem(self,kind,where,message):self.issues.append({'kind':kind,'where':where,'message':message})
 def git_bytes(self,ref,path):
  key=(ref,path)
  if key not in self.cache:self.cache[key]=subprocess.check_output(['git','-C',self.repo,'show',ref+':'+path],stderr=subprocess.PIPE)
  return self.cache[key]
 def git_tree(self,ref):return subprocess.check_output(['git','-C',self.repo,'rev-parse',ref+'^{tree}'],text=True,stderr=subprocess.PIPE).strip()
 def card_key(self,b):return (b['source_sha'],b['source_path'],tuple(b['lines']),b['sha256'],b['bytes'],b['title'])
 def cards(self,rows):
  count=0
  for row in rows:
   ident=normalize_id(row.get('finding_id',''));where='finding:'+ident
   if ident not in self.expected:continue
   supplied=row.get('original_source_criterion_refs',row.get('original_card_bindings',[]))
   expected=self.expected[ident]['original_card_bindings'];count+=len(supplied)
   try:
    if collections.Counter(self.card_key(b) for b in supplied)!=collections.Counter(self.card_key(b) for b in expected):
     self.problem('CARD_BINDING',where,'Original source/card lines/hash/size/title differ from independent original block bindings.')
    for b in supplied:
     if normalize_id(b.get('criterion_id',''))!=ident:self.problem('WRONG_CRITERION_ID',where,'Card criterion ID differs from row ID.')
     doc=self.git_bytes(b['source_sha'],b['source_path']);start,end=b['lines'];block=b''.join(doc.splitlines(keepends=True)[start-1:end])
     if len(block)!=b['bytes'] or sha(block)!=b['sha256']:self.problem('CARD_BYTES',where,'Source block bytes/hash do not match actual immutable Git lines.')
     heading=block.decode('utf8').splitlines()[0]
     if heading!=b['title'] or ident not in [normalize_id(i) for i in ID_PATTERN.findall(heading)]:self.problem('CARD_HEADING',where,'Actual first heading/title does not bind this finding.')
   except (KeyError,ValueError,OSError,subprocess.CalledProcessError) as e:self.problem('CARD_ERROR',where,str(e))
  if count!=36:self.problem('CARD_DENOMINATOR','index','Expected 36 original block bindings, LA016 duplicate counted as one finding.')
  self.observations.append({'property':'original_cards','bindings':count,'expected_unique_ids':35})
 def ref(self,ref,where,historical=False):
  try:
   git_ref=ref.get('git_ref',ref.get('artifact_git_ref',ref.get('head')))
   path=ref.get('path',ref.get('receipt_path'))
   if not git_ref or not path:raise ValueError('Explicit artifact Git ref and repository path required; scientific source_sha is not inferred as artifact head.')
   raw=self.git_bytes(git_ref,path);expected_bytes=ref.get('bytes',ref.get('receipt_bytes'));expected_hash=ref.get('sha256',ref.get('receipt_sha256'))
   if expected_bytes is None or expected_hash is None:raise ValueError('Artifact bytes/hash required.')
   if len(raw)!=expected_bytes or sha(raw)!=expected_hash:self.problem('ARTIFACT_BYTES',where,'Git artifact size/hash mismatch.')
   entry={'where':where,'git_ref':git_ref,'path':path,'bytes':len(raw),'sha256':sha(raw),'check':'PASS'}
   (self.historical_refs if historical else self.current_refs).append(entry)
   return json.loads(gzip.decompress(raw) if raw[:2]==b'\x1f\x8b' else lzma.decompress(raw) if raw[:6]==b'\xfd7zXZ\x00' else raw) if path.endswith(('.json','.json.gz')) else raw
  except (KeyError,ValueError,OSError,subprocess.CalledProcessError,json.JSONDecodeError) as e:
   entry={'where':where,'check':'UNRUN' if historical else 'ERROR','reason':str(e)}
   (self.historical_refs if historical else self.current_refs).append(entry)
   if not historical:self.problem('CURRENT_REF_UNAVAILABLE',where,str(e))
   return None
 def receipt_tree(self,record,where):
  implementation=record.get('implementation_sha',record.get('implementation_candidate_sha',record.get('candidate_sha')))
  tree=record.get('candidate_tree_sha',record.get('implementation_candidate_tree',record.get('candidate_tree')))
  if not implementation or not tree:self.problem('MISSING_CODE_TREE',where,'Explicit scientific implementation SHA/tree required.');return
  try:
   actual=self.git_tree(implementation)
   if actual!=tree:self.problem('CODE_TREE',where,'Declared tree differs from actual implementation commit tree.')
  except subprocess.CalledProcessError as e:self.problem('CODE_UNAVAILABLE',where,str(e))
 def per_id(self,receipt,ref,ident):
  table=receipt.get(ref.get('table','per_finding'))
  if isinstance(table,dict):return table.get(ident,table.get(self.expected[ident]['finding_id']))
  if isinstance(table,list):return next((r for r in table if normalize_id(r.get('finding_id',r.get('finding',r.get('id',''))))==ident),None)
  return None
 def root_decision(self,index,row,ident,where):
  ref=row.get('ROOT_adjudication_ref')
  if not ref:
   if row.get('ROOT_draft_decision_ref'):self.problem('ROOT_DRAFT_NOT_FINAL',where,'A source-bound ROOT draft is not a frozen final adjudication.')
   return False
  document=self.ref(ref,where+':ROOT-adjudication')
  if not isinstance(document,dict):return False
  try:
   if document.get('schema')!='F-root-current35-adjudication/1':raise ValueError('Final ROOT source-bound adjudication schema required.')
   code=index.get('current_root_source_sha');tree=index.get('current_root_source_tree_sha')
   if document.get('root_source_sha')!=code or document.get('root_source_tree_sha')!=tree or self.git_tree(code)!=tree:raise ValueError('ROOT decision must bind the exact assembled scientific code SHA/tree, distinct from receipt carrier.')
   if document.get('formal_G_ledger_acceptance')!='not_issued':raise ValueError('Formal G closure is not issued.')
   if not ref.get('json_pointer'):raise ValueError('Exact ROOT row pointer required.')
   decision=pointer(document,ref['json_pointer'])
   if not isinstance(decision,dict) or normalize_id(decision.get('finding_id',''))!=ident:raise ValueError('ROOT adjudication pointer selects another criterion.')
   fields=['check','outcome','technical_original_criterion_recommendation','criterion_short_ru','actual_consumer','source_scope','oracle_and_negative','original_criterion_remainder','separate_unavailable_inputs_or_authority','latest_owner_packet','next_owner','decision_basis']
   for key in fields:
    actual=row.get('predicate_basis') if key=='decision_basis' else row.get(key)
    if key not in decision or actual!=decision[key]:raise ValueError('ROOT current row field differs from its explicit decision: '+key)
   refs=decision.get('deciding_receipt_refs')
   if not isinstance(refs,list) or not refs:raise ValueError('Full deciding receipt refs required; presence/markers alone are not an adjudication basis.')
   def identity(record):return (record.get('head',record.get('git_ref',record.get('artifact_git_ref'))),record.get('path'),record.get('bytes'),record.get('sha256'),record.get('json_pointer'))
   if collections.Counter(identity(r) for r in row.get('ROOT_deciding_refs',[]))!=collections.Counter(identity(r) for r in refs):raise ValueError('Index ROOT deciding refs differ from the explicit complete adjudication input.')
   for number,deciding in enumerate(refs):
    full=self.ref(deciding,where+':ROOT-deciding:'+str(number))
    if full is None:raise ValueError('Current deciding artifact cannot be read.')
    if deciding.get('json_pointer'):
     if not isinstance(full,dict):raise ValueError('Deciding pointer requires a complete JSON artifact.')
     pointer(full,deciding['json_pointer'])
   self.observations.append({'property':'explicit_ROOT_re_adjudication','finding_id':ident,'artifact_ref':ref,'scientific_source_sha':code,'deciding_refs':len(refs),'formal_G_closure':'not_issued'})
   return True
  except (ValueError,KeyError,IndexError,TypeError,subprocess.CalledProcessError) as error:
   self.problem('ROOT_ADJUDICATION_BINDING',where,str(error));return False
 def structural(self,index):
  rows=index.get('finding_rows',index.get('rows',[]));ids=[normalize_id(r.get('finding_id','')) for r in rows]
  if len(rows)!=35 or set(ids)!=set(self.expected) or len(set(ids))!=35:self.problem('ROW_DENOMINATOR','index','Expected exact 35 unique original IDs.')
  if {r.get('primary_bundle',r.get('bundle')) for r in rows}!={r['bundle'] for r in self.expected.values()}:self.problem('BUNDLE_DENOMINATOR','index','Expected exact 17 source bundle owners.')
  for row in rows:
   ident=normalize_id(row.get('finding_id',''));where='finding:'+ident
   if ident in self.expected and row.get('primary_bundle',row.get('bundle'))!=self.expected[ident]['bundle']:self.problem('WRONG_OWNER',where,'Original canonical bundle differs.')
   check=row.get('check');outcome=row.get('outcome')
   if check not in CHECKS:self.problem('CHECK_ENUM',where,'Canonical check required.')
   if outcome not in OUTCOMES:self.problem('OUTCOME_ENUM',where,'Canonical outcome required.')
   if outcome=='open':self.problem('OPEN_NOT_FINISHED',where,'Open scientific state cannot be hidden by a finished packet.')
   if outcome=='closed' and check!='PASS':self.problem('NONPASS_CLOSED',where,'SKIP/ERROR/FAIL/UNRUN is not a measured PASS.')
   if any(row.get(k) is True for k in ['G_accepted','formal_G_accepted','formal_ledger_accepted']):self.problem('FORMAL_ACCEPTANCE',where,'G formal closure has not been issued.')
  pending=index.get('pending_scientific_blockers')
  if isinstance(pending,dict):
   if pending.get('status')!='resolved':self.problem('PENDING_SCIENTIFIC','index','Scientific pending status is not resolved.')
   if pending.get('status')=='resolved' and not pending.get('checks'):self.problem('PENDING_CHECK_DENOMINATOR','index','Resolved pending status requires nonempty measured checkpoints.')
   for item in pending.get('checks',[]):
    if item.get('check')!='PASS' or not item.get('head',item.get('source_sha')):self.problem('PENDING_SCIENTIFIC_CHECK','index','Resolved scientific check needs PASS and exact source head.')
    head=item.get('head',item.get('source_sha'))
    if head:
     try:
      full=subprocess.check_output(['git','-C',self.repo,'rev-parse',head+'^{commit}'],text=True,stderr=subprocess.PIPE).strip()
      if len(head)!=40 or full!=head:self.problem('PENDING_HEAD_IDENTITY','index','Checkpoint needs its exact full immutable source/head.')
     except (TypeError,subprocess.CalledProcessError) as error:self.problem('PENDING_HEAD_UNAVAILABLE','index',str(error))
    refs=item.get('deciding_receipt_refs')
    if not isinstance(refs,list) or not refs:self.problem('PENDING_DECIDING_REFS','index','Resolved checkpoints require complete measured artifact refs, not status/head markers.')
    else:
     for number,ref in enumerate(refs):self.ref(ref,'pending:'+str(item.get('owner','unnamed'))+':'+str(number))
  else:self.problem('PENDING_STATUS_MISSING','index','Explicit resolved pending checkpoint structure required.')
  if index.get('current_deciding_issues'):self.problem('CURRENT_ISSUES','index','Current deciding issues remain unresolved.')
 def rows(self,index):
  rows=index.get('finding_rows',index.get('rows',[]));ids=[normalize_id(r.get('finding_id','')) for r in rows]
  if len(rows)!=35 or set(ids)!=set(self.expected) or len(set(ids))!=35:self.problem('ROW_DENOMINATOR','index','Expected exact 35 unique original IDs; no added, missing or duplicate row.')
  bundles={r.get('primary_bundle',r.get('bundle')) for r in rows}
  if bundles!={r['bundle'] for r in self.expected.values()}:self.problem('BUNDLE_DENOMINATOR','index','Primary 17 bundle owners differ from original source map.')
  for row in rows:
   ident=normalize_id(row.get('finding_id',''));where='finding:'+ident
   if ident not in self.expected:continue
   actual_bundle=row.get('primary_bundle',row.get('bundle'))
   if actual_bundle!=self.expected[ident]['bundle']:self.problem('WRONG_OWNER',where,'Primary bundle differs from canonical original source owner.')
   check=row.get('check');outcome=row.get('outcome')
   if check not in CHECKS:self.problem('CHECK_ENUM',where,'Separate canonical check must be PASS/FAIL/ERROR/SKIP/UNRUN.')
   if outcome not in OUTCOMES:self.problem('OUTCOME_ENUM',where,'Outcome must be closed/limited/held/open.')
   if outcome=='open':self.problem('OPEN_NOT_FINISHED',where,'Final packet must not hide an open scientific blocker.')
   if outcome=='closed' and check!='PASS':self.problem('NONPASS_CLOSED',where,'Closed finite property requires measured PASS; ERROR/SKIP/UNRUN/FAIL is not PASS.')
   if row.get('G_accepted') is True or row.get('formal_G_accepted') is True or row.get('formal_ledger_accepted') is True:self.problem('FORMAL_ACCEPTANCE',where,'No formal G closure ledger has been issued for this continuation.')
   self.receipt_tree(row,where)
   ref=row.get('receipt_ref')
   if not ref:self.problem('MISSING_OWNER_RECEIPT',where,'Immutable owner receipt ref required.');continue
   receipt=self.ref(ref,where+':receipt')
   if not isinstance(receipt,dict):continue
   original=self.per_id(receipt,ref,ident)
   if not isinstance(original,dict):self.problem('OWNER_PER_ID',where,'Owner receipt does not contain named per-ID decision table entry.');continue
   owner_check=original.get('check',original.get('canonical_check'));owner_outcome=original.get('outcome',original.get('canonical_outcome'))
   re_adjudicated=self.root_decision(index,row,ident,where)
   if not re_adjudicated:
    if owner_check not in CHECKS:self.problem('OWNER_CHECK_ENUM',where,'Owner per-ID canonical check absent or noncanonical.')
    if owner_outcome not in OUTCOMES:self.problem('OWNER_OUTCOME_ENUM',where,'Owner per-ID canonical outcome absent or noncanonical.')
    if owner_check in CHECKS and check!=owner_check:self.problem('OWNER_CHECK_MISMATCH',where,'Index check differs from actual owner decision.')
    if owner_outcome in OUTCOMES and outcome!=owner_outcome:self.problem('OWNER_OUTCOME_MISMATCH',where,'Index outcome differs from actual owner decision; any re-adjudication needs an explicit newer receipt.')
  self.cards(rows)
  if index.get('finding_count',35)!=35 or index.get('bundle_count',17)!=17:self.problem('SUMMARY_DENOMINATOR','index','Summary denominator differs from actual original rows.')
  observed=collections.Counter(r.get('outcome') for r in rows);declared=index.get('summary',{}).get('outcome_counts')
  if declared is not None and dict(observed)!=declared:self.problem('OUTCOME_ARITHMETIC','index','Summary outcome counts differ from row states.')
  for row in rows:
   ident=normalize_id(row.get('finding_id',''));description=' '.join(str(row.get(k,'')) for k in ['criterion_short_ru','actual_consumer','predicate_basis','limit_next_owner_short_ru'])
   if ident=='B204' and re.search(r'Идентифицированный DiD|identified DiD',description,re.I):self.problem('B204_IDENTIFICATION_LABEL','finding:B204','Design diagnostics do not establish causal identification.')
   if ident=='LA004' and re.search(r'GiniPureExecutor',description):self.problem('LA004_CONSUMER_LABEL','finding:LA004','Actual distinct-model consumer is PureExecutor/EconomicsPlugin, not nonexistent GiniPureExecutor.')
   if ident=='LA035' and row.get('outcome')!='held':self.problem('LA035_INTENT_PACKET','finding:LA035','Current whole continuation remains held without optimizer caller and normative unit/population/time/sign intent packet; technical baseline may be separately closed.')
   if ident=='B56' and row.get('outcome')=='closed':self.problem('B56_SHARED_BUDGET','finding:B56','Genuine per-method producer/folds are not the missing admitted all-study Runtime workload/budget witness.')
  self.observations.append({'property':'row_states','rows':len(rows),'outcome_counts':dict(observed)})
 def registry(self,index):
  registry=index.get('receipt_registry',[])
  identities=[]
  for i,r in enumerate(registry):
   identities.append((r.get('head'),r.get('receipt_path')));self.ref({'head':r.get('head'),'path':r.get('receipt_path'),'bytes':r.get('receipt_bytes'),'sha256':r.get('receipt_sha256')},'registry:'+str(i));self.receipt_tree(r,'registry:'+str(i))
  if len(set(identities))!=len(identities):self.problem('DUPLICATE_COMPONENT','registry','A canonical immutable receipt component occurs twice.')
  if self.required_registry is not None:
   required={(r.get('head',r.get('git_ref')),r.get('path',r.get('receipt_path'))):r for r in self.required_registry}
   for key,record in required.items():
    if key not in identities:self.problem('MISSING_REQUIRED_COMPONENT','registry','Independent required-input footprint is absent even if topics and registry were coherently shortened: '+str(key))
    else:
     actual=registry[identities.index(key)]
     if actual.get('receipt_bytes')!=record.get('bytes',record.get('receipt_bytes')) or actual.get('receipt_sha256')!=record.get('sha256',record.get('receipt_sha256')):self.problem('REQUIRED_COMPONENT_BINDING','registry','Required input carrier bytes/hash differ from the independently selected receipt.')
  components=[c for t in index.get('topics',[]) for c in t.get('components',[])]
  if components:
   components_keys=[(c.get('receipt',{}).get('git_ref'),c.get('receipt',{}).get('path')) for c in components]
   if collections.Counter(components_keys)!=collections.Counter(identities):self.problem('REGISTRY_BIJECTION','topics','Topic components and immutable receipt registry are not a bijection.')
  self.observations.append({'property':'component_registry','components':len(registry),'topics':len(index.get('topics',[])),'counts_not_inherited_from_old421':True})
  self.observations.append({'property':'independent_required_input_registry','check':'UNRUN' if self.required_registry is None else 'PASS' if not any(i['kind'].startswith(('MISSING_REQUIRED','REQUIRED_COMPONENT')) for i in self.issues) else 'FAIL','required_components':None if self.required_registry is None else len(self.required_registry),'limitation':'Without an independently selected footprint, topic bijection alone cannot exclude coherent omission of both a component and its topic entry.'})
 def custody(self,index):
  if index.get('current_deciding_reference_check') not in ('PASS',None):self.problem('CURRENT_CUSTODY','index','Current deciding references are not established PASS.')
  historical=index.get('historical_non_deciding_custody',{})
  if historical.get('check')=='UNRUN' and index.get('all_reference_custody_check')=='PASS':self.problem('ALL_CUSTODY_OVERCLAIM','index','All custody cannot be PASS while unavailable provenance-only historical references are UNRUN.')
  authority=index.get('authority',{})
  if isinstance(authority,dict) and authority.get('formal_G_ledger_accepted') is True:self.problem('FORMAL_ACCEPTANCE','authority','Formal G ledger is not issued.')
  if isinstance(authority,str):self.observations.append({'property':'authority_legacy_text','text':authority,'formal_acceptance_not_inferred':True})
  integration=index.get('G_integration',{})
  if isinstance(integration,dict) and integration.get('formal_finding_closure','not_issued') not in FORMAL_NEGATIVE:self.problem('FORMAL_ACCEPTANCE','G_integration','Formal G finding closure has not been issued; confirmed code acceptance is a different property.')
  self.observations.append({'property':'G_acceptance','formal_ledger':'not issued','only_confirmed_G_code_acceptance':'Lex 00a6; acceptance of code is separate from closure and production authority'})
 def material(self,transports,packet_sha):
  records=transports.get('files',transports.get('items',[]))
  if not records:self.problem('TRANSPORT_DENOMINATOR','transport','No complete material transport records supplied.');return
  seen=set();total=0;decoded=0
  for i,r in enumerate(records):
   where='transport:'+str(i);ref=r.get('git_ref',r.get('artifact_git_ref',packet_sha));path=r.get('path')
   key=(ref,path)
   if key in seen:self.problem('DUPLICATE_TRANSPORT',where,'Same immutable Git artifact transferred twice.')
   seen.add(key)
   try:
    if not ref or not path:raise ValueError('Transport requires an exact artifact ref/path.')
    raw=self.git_bytes(ref,path);total+=len(raw)
    if len(raw)!=r.get('bytes') or sha(raw)!=r.get('sha256'):self.problem('TRANSPORT_BYTES',where,'Complete transported Git size/hash mismatch.')
    body=raw
    if raw[:2]==b'\x1f\x8b':body=gzip.decompress(raw)
    elif raw[:6]==b'\xfd7zXZ\x00':body=lzma.decompress(raw)
    elif 'decoded_sha256' in r and sha(raw)!=r['decoded_sha256'] and raw.lstrip().startswith((b'{',b'"')):
     wrapped=json.loads(raw)
     values=[wrapped] if isinstance(wrapped,str) else [wrapped.get(k) for k in ['raw_utf8','raw_text','text','stdout','stderr','content','output','data','raw_output','utf8_text','original_utf8','utf8','verbatim_utf8','raw']]
     candidates=[v.encode('utf8') for v in values if isinstance(v,str) and sha(v.encode('utf8'))==r['decoded_sha256']]
     if not candidates:raise ValueError('Lossless JSON wrapper has no field matching the explicitly declared raw hash.')
     body=candidates[0]
    if 'decoded_sha256' in r or 'decoded_bytes' in r:
     if sha(body)!=r.get('decoded_sha256') or len(body)!=r.get('decoded_bytes'):self.problem('DECODED_TRANSPORT_BYTES',where,'Decoded full-byte hash/size mismatch.')
     decoded+=1
    self.current_refs.append({'where':where,'git_ref':ref,'path':path,'bytes':len(raw),'sha256':sha(raw),'check':'PASS'})
   except (OSError,ValueError,KeyError,subprocess.CalledProcessError,gzip.BadGzipFile,lzma.LZMAError) as e:self.problem('TRANSPORT_ERROR',where,str(e))
  for r in transports.get('derived_inputs_not_copied',[]):
   if not r.get('source_base_sha') or not r.get('reconstruction') or not r.get('sha256') or not r.get('bytes'):self.problem('DERIVED_RECONSTRUCTION','transport','Omitted source-derived input requires exact source/hash/size and reconstruction locator.')
  self.observations.append({'property':'complete_transport_material','records':len(records),'bytes':total,'decoded_bindings':decoded,'current_doc_ref':packet_sha})
 def validate(self,index):
  self.structural(index);self.rows(index);self.registry(index);self.custody(index)
  return {'schema':'e02-independent-continuation-ledger-check-v1','check':'FAIL' if self.issues else 'PASS','issues':self.issues,'observations':self.observations,'current_artifact_refs':self.current_refs,'historical_non_deciding_refs':self.historical_refs,'original_denominator':{'findings':35,'bindings':36,'bundles':17},'limits':['Metadata/card/receipt custody validation only, not scientific reruns or G approval.','Final REPORT/source-order/transport schema and independent numeric limits require explicit review once frozen packet arrives.','Current owner receipt unavailable is ERROR, never inferred closed. Historical nondeciding reference unavailable may remain UNRUN.']}

def main():
 p=argparse.ArgumentParser();p.add_argument('--repo',default='/workspace/e02-F-closeout-20261006');p.add_argument('--manifest',default='/tmp/e02-F-continuation-20261006/cau/original35-reconciliation.json');p.add_argument('--index',required=True);p.add_argument('--output',required=True);p.add_argument('--transports');p.add_argument('--packet-sha');p.add_argument('--report');p.add_argument('--source-order');p.add_argument('--required-registry',help='Independent expected receipt footprint selected from actual owner/ROOT packets, not inferred from the reviewed index');a=p.parse_args()
 manifest=load_json(a.manifest);raw=pathlib.Path(a.index).read_bytes();index=load_json(a.index);required=load_json(a.required_registry) if a.required_registry else None;v=Validator(a.repo,manifest,required);result=v.validate(index)
 if a.transports:
  v.material(load_json(a.transports),a.packet_sha);result['check']='FAIL' if v.issues else 'PASS'
  result['transport_material_check']='PASS' if not any(i['kind'].startswith(('TRANSPORT','DECODED','DERIVED')) for i in v.issues) else 'FAIL'
 else:result['transport_material_check']='UNRUN'
 result['narrative_inputs']={}
 for kind,path in [('REPORT',a.report),('source_order',a.source_order)]:
  if path:
   b=pathlib.Path(path).read_bytes();result['narrative_inputs'][kind]={'path':path,'bytes':len(b),'sha256':sha(b),'semantic_reconciliation':'requires independent read of exact frozen content; not inferred from metadata guards'}
  else:result['narrative_inputs'][kind]={'check':'UNRUN','reason':'Frozen packet input not yet supplied.'}
 result['inputs']={'index':{'path':a.index,'bytes':len(raw),'sha256':sha(raw)},'original35_manifest':{'path':a.manifest,'bytes':pathlib.Path(a.manifest).stat().st_size,'sha256':sha(pathlib.Path(a.manifest).read_bytes())},'replayer':{'path':__file__,'bytes':pathlib.Path(__file__).stat().st_size,'sha256':sha(pathlib.Path(__file__).read_bytes())}}
 pathlib.Path(a.output).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'check':result['check'],'issues':len(result['issues']),'output':a.output}));raise SystemExit(0 if result['check']=='PASS' else 1)
if __name__=='__main__':main()
