# F current35 scratch transfer proposal

This is a source-bound draft for ROOT. Builder consistency is not independent acceptance, formal G closure, or production admission.

Root source `8236d9c368336a5ea20c1586f29aea7321db6536` / tree `724a77c88d4e6699ffead58a5e3e3990fb88640a`. Exact original denominator: 35 findings, 17 bundles, 36 card bindings (LA-016 is one finding with two bindings).

Proposed current continuation states: `{"closed": 25, "held": 1, "limited": 9}`. Original technical criterion recommendations: `{"closed": 30, "held": 1, "limited": 4}`. Receipt components and topics are counted from this registry, not inherited from frozen421.

| ID | Original owner | Check proposal | Outcome proposal | Actual criterion/consumer |
|---|---|---|---|---|
| B204 | CAU-01 | PASS | closed | Standard DiD: estimable pre/post contrast, ATT3, truthful pretrend states; no identification proof |
| B205 | CAU-01 | PASS | closed | Standard DiD HC1/CR0 covariance with unit clustering |
| B206 | CAU-01 | PASS | closed | Requested confidence level in BOTH Standard DiD and sharp RDD |
| B207 | CAU-02 | PASS | limited | Selected-cohort scalar/share-ratio influence function under declared IID-unit profile |
| B208 | CAU-02 | PASS | limited | One centered studentized unit-bootstrap null test and consistent CI inversion |
| B209 | CAU-02 | PASS | limited | Fixed eligible horizons and full-cohort anticipation/baseline admission |
| B210 | CAU-03 | PASS | closed | Finite sharp RDD RBC/HC0 profile with real rdrobust oracle |
| B211 | CAU-03 | PASS | closed | Weighted RDD algebra and supported kernels/design orders |
| B212 | CAU-04 | PASS | limited | Actual backend shapes and point-only noneligible result disposition |
| B213 | CAU-04 | PASS | limited | Actual estimand_type/contrast/target and identify_effect/estimate_effect request binding on maintained dispatcher/worker profile |
| B214 | GRF-03 | PASS | limited | Endpoint-preserving canonical graph intake; unresolved PAG/circles refuse static identification |
| B215 | SCM-02 | PASS | closed | Declared affine Gaussian conditioning and evidence/singular-law semantics |
| B216 | GRF-01 | PASS | closed | Independent static ADMG m-separation plus actual do/sigma/ID/IDC/IDC*/AMN/CTF callers |
| B217 | GRF-01 | PASS | closed | Perfect graph surgery including bidirected-edge cuts |
| B218 | GRF-03 | PASS | limited | Lag/self-lag representation retained; compact temporal graph refuses static identification |
| B219 | GRF-02 | PASS | closed | Actual NetworkX MultiDiGraph preserves full parallel-edge payload |
| B220 | GRF-02 | PASS | closed | Internal graph/cache lifecycle invariant; internal-stable change fragment |
| B221 | SCM-01 | PASS | closed | Real GCM fitting/source-row lineage and fresh fitted-model query consumer |
| B222 | SCM-01 | PASS | closed | Existing additive-polynomial helper payload in typed manual SCM1.0; not a new nonlinear default fitter |
| B223 | SCM-02 | PASS | closed | Explicit outcome/ITE versus optional IID-refit estimator interval semantics and query binding |
| B224 | SCM-03 | PASS | closed | Surgical planning bypasses intervened natural mechanisms, preserves declared comparators |
| B225 | SCM-03 | PASS | closed | Supported-law conditional tails with independent stdlib math.erfc CDF oracle |
| B54 | FIT-01 | PASS | closed | Native TMLE cache/fit identity and immutable current-reader materialization |
| B56 | FIT-01 | UNRUN | limited | Actual admitted common-study workload/budget remains UNRUN; configured MethodJob bridge is a separate bounded property |
| LA-001 | FRY-01 | PASS | closed | Versioned native RNG caller/compile/execute migration with historical plans |
| LA-002 | FRY-01 | PASS | closed | Supported finite catalog/IC/native IR/caller migration; optional family execution is not original criterion |
| LA-003 | FRY-03 | PASS | closed | Native fiscal/labor PatchMap consumer migration and admitted precision profile; original law/mask/RNG/ABI retained |
| LA-004 | ECO-01 | PASS | closed | Actual matched and deliberately distinct fiscal/labor versus CompositeExecutor model profiles, not Gini |
| LA-007 | GRF-01 | PASS | closed | Exact id_engine.py sibling already absent at base198; bounded maintained package/loader/docs/install migration |
| LA-016 | CAU-05 | PASS | closed | Maintained dedicated Standard DiD FQN/flags/slots/request metadata migration; explicit historical replay |
| LA-017 | LEX-01 | PASS | limited | Supported legal impact caller/config migration; dedupe is a bounded partial property |
| LA-019 | GRF-01 | PASS | closed | Exact causal_engine.py/interference.py siblings already absent at base198; bounded maintained package/caller/docs/install migration |
| LA-020 | API-01 | PASS | closed | Declared supported public facade/FQN/patch/docs/client/install window on the final common source |
| LA-035 | ECO-01 | UNRUN | held | Historical normalized-income loss replay is measured; actual optimizer and normative intent packet held |
| LA-037 | FRY-01 | PASS | closed | Actual IR slot/compiler/state/doc/install migration; optional family state execution is separate |

Publication checkpoints: `resolved`. All per-ID check/outcome/remainder prose above comes from the explicit source-bound ROOT adjudication when supplied; otherwise it remains a proposal. Receipt publication alone changes no outcome.

LA-003 historical precision FAIL and the later finite132 precision evidence remain on separate exact sources; actual component PASS/FAIL/ERROR streams and the ABM neighbor FAIL are preserved. LA-035 optimizer/intent is held until its real packet exists.

B206 retains both DiD and RDD receipts. RDD upstream ancestry and runtime byte equality are reported separately. Full append history and defining-path hashes are in source-order.json; no staged patch is substituted for history.

Known synthetic DGP/mathematical properties are separate from admitted real data. Whole Runtime Node authority/PDC semantic intake, actual common B56 competing workload/budget and selected local Lex law are UNRUN. Configured MethodJob/CAS/freshreader is bounded numerical consumer evidence.

Old5cd installed PASS is source-only and supersedes oldab56; it is not a current combined-runtime PASS. Python3.14 DoWhy/EconML markers are not positive backend evidence. Historical FAIL/ERROR/SKIP and raw warning streams remain exact in component checks and Git transports.

Current measured/material references are byte-verified. Historical175c provenance-only unavailable references keep historical/all-custody UNRUN. P41 inherited-red attribution remains not established. Formal G finding closure has not been issued.

The separate prepared validator must review ROOT's immutable final publication. This builder does not claim to independently verify its own draft.
