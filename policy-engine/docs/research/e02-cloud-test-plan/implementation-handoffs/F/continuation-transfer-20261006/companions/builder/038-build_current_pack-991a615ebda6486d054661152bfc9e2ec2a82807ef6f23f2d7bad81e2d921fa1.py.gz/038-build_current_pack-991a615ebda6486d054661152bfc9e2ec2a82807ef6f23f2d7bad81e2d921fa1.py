"""Build a SOURCE-BOUND SCRATCH proposal, never a closure/independent acceptance.

Only writes under --outdir (the authorized root-ledger-draft scratch directory).
All source/receipt reads use immutable Git objects. New owner components can be
supplied with --extra-registry; an unreceived packet never closes a row.
"""
from __future__ import annotations

import argparse
import collections
import csv
import datetime
import gzip
import hashlib
import io
import lzma
import json
import pathlib
import subprocess
import sys

BASE = "198076863e143dea9f89f02734b13d50dae3eed5"
FROZEN = "421f1dd977b237307394c68820caab4156716eb2"
G_AUDIT = "363e7ae0cb2929a92d9667334fdc0ac3087daf5e"
G_RUNTIME = "acdc3536f93f085d665a7b53460935525373d015"
G_CHECKPOINT = "127dc7ab8365d29eb656fe32c0c894f6cc971286"
LEX_ACCEPTED_CODE = "00a6eda114b903bc5abe86902cd8372426f739a1"
PREFIX = "policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/F/"
OLD_PREFIX = PREFIX + "final-transfer-20261006/"
CHECKS = {"PASS", "FAIL", "ERROR", "SKIP", "UNRUN"}
EXTRA = [
    ("root_tmle", "39133d4d8b9a680942ffeb983385cbee1b1b493a", "tmle-selected-consumer-20261006.json"),
    ("tmle_common", "3ae04e86cc6d22a10d28abb163c1078a0bea6ba4", "tmle-common-report-20261006.json"),
    ("tmle_generated", "27f172d56b59c3157275e90e50b1d00cc5219a91", "tmle-report-schema-20261006.json"),
    ("f_docs", "e84acb04fbe1fbebdfa5a54f87ff0fc72640a4ef", "closure-doc-reconciliation-20261006.json"),
    ("root_worker_projection", "8d7bf448874206429d87705454565d71a367cb32", "worker-value-boundaries-continuation-20261006.json"),
]
# An optional component path is discovered from its exact commit if renamed.
OPTIONAL_DISCOVERY = {"root_worker_projection"}
CURRENT_SHORT = {
    "B204": "Standard DiD: estimable pre/post contrast, ATT3, truthful pretrend states; no identification proof",
    "B205": "Standard DiD HC1/CR0 covariance with unit clustering",
    "B206": "Requested confidence level in BOTH Standard DiD and sharp RDD",
    "B207": "Selected-cohort scalar/share-ratio influence function under declared IID-unit profile",
    "B208": "One centered studentized unit-bootstrap null test and consistent CI inversion",
    "B209": "Fixed eligible horizons and full-cohort anticipation/baseline admission",
    "B210": "Finite sharp RDD RBC/HC0 profile with real rdrobust oracle",
    "B211": "Weighted RDD algebra and supported kernels/design orders",
    "B212": "Actual backend shapes and point-only noneligible result disposition",
    "B213": "Supported backend estimate and exact source/CAS/report binding",
    "B214": "Endpoint-preserving canonical graph intake; unresolved PAG/circles refuse static identification",
    "B215": "Declared affine Gaussian conditioning and evidence/singular-law semantics",
    "B216": "Independent static ADMG m-separation plus actual do/sigma/ID/IDC/IDC*/AMN/CTF callers",
    "B217": "Perfect graph surgery including bidirected-edge cuts",
    "B218": "Lag/self-lag representation retained; compact temporal graph refuses static identification",
    "B219": "Actual NetworkX MultiDiGraph preserves full parallel-edge payload",
    "B220": "Internal graph/cache lifecycle invariant; internal-stable change fragment",
    "B221": "Real GCM fitting/source-row lineage and fresh fitted-model query consumer",
    "B222": "Existing additive-polynomial helper payload in typed manual SCM1.0; not a new nonlinear default fitter",
    "B223": "Explicit outcome/ITE versus optional IID-refit estimator interval semantics and query binding",
    "B224": "Surgical planning bypasses intervened natural mechanisms, preserves declared comparators",
    "B225": "Supported-law conditional tails with independent stdlib math.erfc CDF oracle",
    "B54": "Native TMLE cache/fit identity and immutable current-reader materialization",
    "B56": "Actual admitted common-study workload/budget remains UNRUN; configured MethodJob bridge is a separate bounded property",
    "LA-001": "Versioned native RNG caller/compile/execute migration with historical plans",
    "LA-002": "Supported finite catalog/IC/native IR/caller migration; optional family execution is not original criterion",
    "LA-003": "Native fiscal/labor PatchMap migration; current fiscal precision FAIL remains limited",
    "LA-004": "Actual matched and deliberately distinct fiscal/labor versus CompositeExecutor model profiles, not Gini",
    "LA-007": "Exact id_engine.py sibling already absent at base198; maintained package/caller/window migration",
    "LA-016": "Maintained dedicated Standard DiD FQN/flags/slots/request metadata migration; explicit historical replay",
    "LA-017": "Supported legal impact caller/config migration; dedupe is a bounded partial property",
    "LA-019": "Exact causal_engine.py/interference.py siblings already absent at base198; maintained packages/callers",
    "LA-020": "Supported public facade/docs/client/install window; latest API owner receipt pending",
    "LA-035": "Historical normalized-income loss replay is measured; actual optimizer and normative intent packet held",
    "LA-037": "Actual IR slot/compiler/state/doc/install migration; optional family state execution is separate",
}
CURRENT_CONSUMERS = {
    "B56": "Actual investigated runtime route DurableControlWorker → RunLifecycle → run_experiment → sync_run_causal_full. Separate configured real TMLE MethodJob → numerical result/report/envelope → CAS/fresh reader and internal run_primary source/projection checks. Attempted common causal LocalWorkerPool FAIL execution_context_missing before0fits; no production LocalWorkerPool/TaskRouter constructor witness; admitted shared workload/budget is UNRUN.",
    "LA-004": "Registry-created native fiscal/labor → PatchMap/apply_patch_map/GlobalState versus EconomicsPlugin.get_mechanisms → CompositeExecutor/EconomicState; actual matched and deliberately distinct finite laws.",
    "LA-001": "compile.api.compile → compile_trinity → TreasuryPlan → execute.api.execute → execute_program_graph → adaptive_agent",
    "B206": "StandardDifferenceInDifferences AND RegressionDiscontinuity → native report → MethodJob/CAS/canonical dematerializer/fresh reader",
    "B222": "Existing _fit_additive_noise_poly → typed manual SCM1.0 → actual MethodJob/CAS → fresh GCMQuery/TwinNetworkQuery process",
    "B216": "CachedAdjacency/m_separation → actual do/sigma/ID/IDC/IDC*/AMN/CTF finite static ADMG callers",
}


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def norm_id(ident):
    return ident.replace("LA-", "LA")


class Builder:
    def __init__(self, args):
        self.args = args
        self.cache = {}
        self.observations = []
        self.issues = []
        self.material = {}
        self.manifest_denominators = []
        self.opened_manifests = set()
        self.registry = []
        self.receipts = {}
        self.outdir = pathlib.Path(args.outdir).resolve()
        allowed = pathlib.Path("/tmp/e02-F-continuation-20261006/root-ledger-draft").resolve()
        if self.outdir != allowed:
            raise ValueError("Only the admitted root-ledger-draft scratch output directory is allowed")
        self.outdir.mkdir(parents=True, exist_ok=True)
        self.root_sha = self.git("rev-parse", args.root_sha + "^{commit}").decode().strip()
        self.root_tree = self.tree(self.root_sha)

    def git(self, *argv):
        return subprocess.check_output(["git", "-C", self.args.repo, *argv], stderr=subprocess.PIPE)

    def raw(self, head, path):
        key = (head, path)
        if key not in self.cache:
            self.cache[key] = self.git("show", head + ":" + path)
        return self.cache[key]

    def tree(self, head):
        return self.git("rev-parse", head + "^{tree}").decode().strip()

    def ancestor(self, source, target):
        run = subprocess.run(["git", "-C", self.args.repo, "merge-base", "--is-ancestor", source, target], capture_output=True)
        if run.returncode not in (0, 1):
            return {"check": "ERROR", "stderr": run.stderr.decode(errors="replace")}
        return {"check": "PASS", "is_ancestor": run.returncode == 0}

    def ref(self, head, path, expected=None):
        raw = self.raw(head, path)
        actual = {"git_ref": head, "head": head, "path": path, "bytes": len(raw), "sha256": digest(raw), "git_blob": self.git("rev-parse", head + ":" + path).decode().strip(), "check": "PASS"}
        if expected:
            expected_size = expected.get("bytes", expected.get("receipt_bytes"))
            expected_hash = expected.get("sha256", expected.get("receipt_sha256"))
            if expected_size is not None and expected_size != len(raw):
                raise ValueError(f"Artifact size mismatch: {head}:{path}")
            if expected_hash is not None and expected_hash != digest(raw):
                raise ValueError(f"Artifact hash mismatch: {head}:{path}")
        return actual

    def write(self, name, value):
        path = self.outdir / name
        path.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(value, bytes):
            raw = value
        elif isinstance(value, str):
            raw = value.encode()
        else:
            raw = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()
        path.write_bytes(raw)
        return {"path": str(path), "bytes": len(raw), "sha256": digest(raw)}

    def local(self, path, expected=None):
        raw = pathlib.Path(path).read_bytes()
        if expected and (expected["bytes"] != len(raw) or expected["sha256"] != digest(raw)):
            raise ValueError("Local input binding mismatch: " + path)
        return json.loads(raw), {"path": path, "bytes": len(raw), "sha256": digest(raw)}

    def decode_material(self, raw, record):
        if raw[:2] == b"\x1f\x8b":
            return gzip.decompress(raw), "gzip"
        if raw[:6] == b"\xfd7zXZ\x00":
            return lzma.decompress(raw), "XZ"
        if record.get("lossless_utf8_json") or record.get("encoding") in ("json-string", "lossless-json", "lossless_utf8_json"):
            obj = json.loads(raw)
            if isinstance(obj, str):
                return obj.encode(), "JSON UTF-8 string"
            if isinstance(obj, dict):
                for key in ("raw_utf8", "text", "stdout", "stderr", "content", "output", "data", "raw_output", "raw_text", "utf8_text", "original_utf8", "utf8", "verbatim_utf8", "raw"):
                    if isinstance(obj.get(key), str):
                        return obj[key].encode(), "JSON UTF-8 " + key
            raise ValueError("Unknown lossless JSON wrapper")
        return raw, "raw Git bytes"

    def add_material(self, head, record, origin):
        path = record.get("path", record.get("receipt_path"))
        if not isinstance(path, str) or not path.startswith("policy-engine/"):
            return None
        head = record.get("git_ref", record.get("artifact_git_ref", record.get("git_sha", record.get("git_commit", record.get("head", head)))))
        key = (head, path)
        actual = self.ref(head, path, record)
        if "decoded_bytes" in record or "decoded_sha256" in record:
            raw = self.raw(head, path)
            decoded, encoding = self.decode_material(raw, record)
            # Some wrappers identify encoding with a descriptive string only.
            if record.get("decoded_sha256") != digest(decoded) and raw.lstrip().startswith((b"{", b'"')):
                obj = json.loads(raw)
                candidates = [obj] if isinstance(obj, str) else [obj.get(k) for k in ("raw_utf8", "text", "stdout", "stderr", "content", "output", "data", "raw_output", "raw_text", "utf8_text", "original_utf8", "utf8", "verbatim_utf8", "raw")]
                matching = [s.encode() for s in candidates if isinstance(s, str) and digest(s.encode()) == record.get("decoded_sha256")]
                if matching:
                    decoded, encoding = matching[0], "lossless JSON UTF-8 wrapper"
            if record.get("decoded_bytes", len(decoded)) != len(decoded) or record.get("decoded_sha256", digest(decoded)) != digest(decoded):
                raise ValueError("Decoded bytes mismatch: " + str(key))
            actual.update(decoded_bytes=len(decoded), decoded_sha256=digest(decoded), decoding=encoding)
        actual["origins"] = [origin]
        if key in self.material:
            self.material[key]["origins"].append(origin)
        else:
            self.material[key] = actual
        return actual

    def per_id_entries(self, receipt, ident):
        entries = []
        for table in ("per_finding", "per_id", "per_id_outcomes", "finding_decisions"):
            data = receipt.get(table)
            if isinstance(data, dict):
                pairs = data.items()
            elif isinstance(data, list):
                pairs = [(str(i), value) for i, value in enumerate(data)]
            else:
                continue
            for key, value in pairs:
                if isinstance(value, dict) and norm_id(str(value.get("finding_id", value.get("finding", value.get("id", key))))) == norm_id(ident):
                    entries.append({"json_pointer": "/" + table + "/" + key, "complete_owner_entry": value})
        return entries

    def add_receipt(self, lane, head, path, expected=None, historical=False):
        bound = self.ref(head, path, expected)
        if any(r["head"] == head and r["receipt_path"] == path for r in self.registry):
            r = next(r for r in self.registry if r["head"] == head and r["receipt_path"] == path)
            r["registry_aliases"].append(lane)
            return r
        receipt = json.loads(self.raw(head, path))
        commits = receipt.get("implementation_commits", [])
        if not commits:
            commits = [receipt.get("implementation_sha", receipt.get("implementation_commit"))]
        commits = [c for c in commits if isinstance(c, str)]
        candidate = receipt.get("candidate_source_sha", receipt.get("candidate_sha", receipt.get("implementation_sha", (expected or {}).get("implementation_sha", commits[-1] if commits else None))))
        if not candidate:
            raise ValueError("No implementation source in receipt: " + path)
        tree = self.tree(candidate)
        claimed_tree = receipt.get("candidate_tree_sha", receipt.get("candidate_tree"))
        if claimed_tree and claimed_tree != tree:
            raise ValueError("Declared candidate tree mismatch: " + path)
        external = receipt.get("external_tested_source")
        if external is not None and (not isinstance(external, dict) or external.get("sha") != candidate or external.get("tree") != tree):
            raise ValueError("External tested source/candidate identity mismatch: " + path)
        record = {
            "lane": lane, "registry_aliases": [lane], "head": head, "receipt_path": path,
            "receipt_bytes": bound["bytes"], "receipt_sha256": bound["sha256"], "receipt_git_blob": bound["git_blob"],
            "branch": receipt.get("branch"), "slice": receipt.get("slice"), "bundle_ids": receipt.get("bundle_ids", []),
            "implementation_commits": commits, "implementation_sha": candidate, "candidate_tree_sha": tree,
            "scientific_implementation_sha_literal": receipt.get("scientific_implementation_sha", receipt.get("source_identity")),
            "artifact_document_tree_sha": self.tree(head), "code_tree_check": "PASS", "byte_binding_check": "PASS",
            "component_role": "historical frozen source component" if historical else ("ancillary input/storage custody; not a scientific finding check" if lane == "root_input_custody" else "source quality/equivalence companion; global red retained, not an original finding closure" if path.endswith("source-quality-freeze-20261006.json") else "external tested installed consumer companion; no code-carry/ancestry or whole authority claim" if external else "current exact source-bound owner/consumer companion"),
            "closure_ids_literal": receipt.get("closure_ids", []), "related_finding_ids": receipt.get("related_finding_ids", receipt.get("finding_ids", receipt.get("closure_ids", []))),
            "closure_ids_not_G_acceptance": True,
        }
        self.registry.append(record)
        self.receipts[(head, path)] = receipt
        self.add_material(head, bound, "receipt:" + lane)
        for field, value in receipt.items():
            if any(token in field.lower() for token in ("transport", "artifact", "evidence_transfer", "companions", "manifest", "content_refs", "output_refs", "file_refs")) or field == "complete_implementation_diffs":
                self.walk_material(value, head, lane + ":" + field, follow_manifest=True)
        return record

    def normalized_material_record(self, record):
        result = dict(record)
        for canonical, aliases in {
            "bytes": ("stored_bytes", "compressed_bytes", "encoded_bytes", "size_bytes"),
            "sha256": ("stored_sha256", "compressed_sha256", "encoded_sha256"),
            "decoded_bytes": ("decompressed_bytes", "raw_bytes", "raw_output_bytes", "uncompressed_bytes", "original_bytes"),
            "decoded_sha256": ("decompressed_sha256", "raw_sha256", "raw_output_sha256", "uncompressed_sha256", "original_sha256"),
        }.items():
            if canonical not in result:
                for alias in aliases:
                    if alias.startswith("raw_") and ("raw_lossless_ref" in record or str(record.get("normalization", "")).startswith("strip ")):
                        continue
                    if alias in result:
                        result[canonical] = result[alias]
                        break
        return result

    def walk_material(self, value, head, origin, follow_manifest=False):
        """Walk every declared transport shape, retaining explicit carrier refs.

        A scientific source_sha is NEVER inferred as the artifact carrier head.
        Source-card line/block bindings are validated in their dedicated census.
        """
        if isinstance(value, str):
            path, delimiter, inline_head = value.rpartition("@")
            if delimiter and len(inline_head) == 40 and all(c in "0123456789abcdef" for c in inline_head):
                value, head = path, inline_head
            if value.startswith("policy-engine/") and follow_manifest:
                actual = self.add_material(head, {"path": value}, origin)
                if actual and value.endswith(".json") and (any(token in pathlib.Path(value).name.lower() for token in ("manifest", "transport")) or ":full_output_manifest" in origin or ":output_manifest" in origin):
                    key = (actual["git_ref"], value)
                    if key not in self.opened_manifests:
                        self.opened_manifests.add(key)
                        doc = json.loads(self.raw(*key))
                        self.walk_material(doc, actual["git_ref"], origin + ":declared-json", follow_manifest=False)
            return
        if isinstance(value, list):
            bound_entries = sum(isinstance(v, dict) and isinstance(v.get("path", v.get("receipt_path")), str) and ("sha256" in v or "stored_sha256" in v or "compressed_sha256" in v) for v in value)
            if bound_entries:
                self.manifest_denominators.append({"origin": origin, "carrier_head": head, "declared_entries": bound_entries})
            for i, item in enumerate(value):
                self.walk_material(item, head, origin + "/" + str(i), follow_manifest=False)
            return
        if not isinstance(value, dict):
            return
        record = self.normalized_material_record(value)
        path = record.get("path", record.get("receipt_path"))
        # Only explicit artifact records/transport refs. Never confuse card-block hash with document hash.
        is_record = isinstance(path, str) and path.startswith("policy-engine/") and "lines" not in record and ("sha256" in record or follow_manifest)
        if is_record:
            try:
                actual = self.add_material(head, record, origin)
            except Exception as exc:
                raise ValueError("Transport entry binding failed at " + origin + ": " + str(record)) from exc
            if actual and follow_manifest and path.endswith(".json") and (any(token in pathlib.Path(path).name.lower() for token in ("manifest", "transport")) or ":full_output_manifest" in origin or ":output_manifest" in origin):
                key = (actual["git_ref"], path)
                if key not in self.opened_manifests:
                    self.opened_manifests.add(key)
                    self.walk_material(json.loads(self.raw(*key)), actual["git_ref"], origin + ":declared-json", follow_manifest=False)
        for key, item in value.items():
            if key not in ("original_path", "original_execution_path", "raw_local_path", "path_translation"):
                self.walk_material(item, head, origin + "/" + str(key), follow_manifest=follow_manifest and isinstance(item, (dict, str)))

    def enrich_check(self, record, i, check):
        result = {"receipt_ref": {"head": record["head"], "path": record["receipt_path"], "bytes": record["receipt_bytes"], "sha256": record["receipt_sha256"]}, "json_pointer": "/checks/" + str(i), "complete_actual_check": check, "component_lane": record["lane"], "scope_not_inferred_per_id": True}
        outputs = []
        for key in ("output", "stderr", "stdout", "execution_receipt", "output_ref", "output_refs", "stdout_refs", "stderr_refs", "execution_receipts"):
            item = check.get(key)
            if isinstance(item, list):
                for j, entry in enumerate(item):
                    if isinstance(entry, str) and entry.startswith("policy-engine/"):
                        outputs.append(self.add_material(record["head"], {"path": entry}, record["lane"] + ":checks/" + str(i) + "/" + key + "/" + str(j)))
                    elif isinstance(entry, dict):
                        outputs.append(self.add_material(record["head"], self.normalized_material_record(entry), record["lane"] + ":checks/" + str(i) + "/" + key + "/" + str(j)))
            if isinstance(item, str) and item.startswith("policy-engine/"):
                artifact_head = check.get(key + "_git_sha", check.get(key + "_git_ref", record["head"]))
                path, delimiter, inline_head = item.rpartition("@")
                if delimiter and len(inline_head) == 40 and all(c in "0123456789abcdef" for c in inline_head):
                    item, artifact_head = path, inline_head
                binding = {"path": item}
                for suffix in ("bytes", "sha256"):
                    if key + "_" + suffix in check:
                        binding[suffix] = check[key + "_" + suffix]
                outputs.append(self.add_material(artifact_head, binding, record["lane"] + ":checks/" + str(i) + "/" + key))
            elif isinstance(item, dict):
                outputs.append(self.add_material(record["head"], item, record["lane"] + ":checks/" + str(i) + "/" + key))
        result["verified_complete_output_refs"] = list({(r["git_ref"], r["path"]): r for r in outputs if r}.values())
        if result["verified_complete_output_refs"]:
            result["output_custody_check"] = "PASS"
            result["measurement_witness_check"] = check.get("outcome", check.get("check", "UNRUN"))
        else:
            result["output_custody_check"] = "UNRUN"
            result["output_custody_reason"] = "No complete raw output artifact is declared for this check. Preserve actual owner textual disposition; do not treat a textual run/assertion as measured raw-output PASS."
            result["measurement_witness_check"] = "UNRUN"
            result["non_deciding_literal_assertion"] = check.get("outcome", check.get("check")) == "PASS"
        return result

    def build(self):
        draft, draft_ref = self.local(self.args.draft)
        recon, recon_ref = self.local(self.args.reconciliation, draft["input_reconciliation"])
        old_index = json.loads(self.raw(FROZEN, OLD_PREFIX + "index.json"))
        old_audit = json.loads(self.raw(FROZEN, OLD_PREFIX + "audit/final35-complete-audit.json"))
        old_transport = json.loads(self.raw(FROZEN, OLD_PREFIX + "artifact-transports.json"))
        source_refs = {"ECO_current35_draft": draft_ref, "original35_reconciliation": recon_ref}
        fdocs_head = "e84acb04fbe1fbebdfa5a54f87ff0fc72640a4ef"
        fdocs_prefix = PREFIX + "closure-doc-reconciliation-20261006/"
        source_refs["original35_reconciliation"]["existing_committed_original_ref"] = self.ref(fdocs_head, fdocs_prefix + "original-inputs/original35-reconciliation.json", recon_ref)
        source_refs["ECO_current35_draft"]["portable_reconstruction_ref"] = self.ref(fdocs_head, fdocs_prefix + "reconcile_current35.py")
        source_refs["ECO_current35_draft"]["full_row_equivalence_ref"] = self.ref(fdocs_head, fdocs_prefix + "portable-draft-equivalence.json")
        source_refs["ECO_current35_draft"]["reconstruction_semantics"] = "Local draft is not a committed canonical ledger. Existing e84 portable replayer and full-row equivalence preserve source-bound row reconstruction; artifact/source-path top-level identity may differ. ROOT alone admits final ledger."
        for name, p in (("frozen421_index", "index.json"), ("frozen421_full_audit", "audit/final35-complete-audit.json"), ("frozen421_transports", "artifact-transports.json")):
            source_refs[name] = self.ref(FROZEN, OLD_PREFIX + p)
        source_refs["G363_audit"] = self.ref(G_AUDIT, "policy-engine/docs/research/e02-cloud-test-plan/integration/reviews/F-pr65-continuation-audit-2026-10-06.md")
        source_refs["G127_owner_actions"] = self.ref(G_CHECKPOINT, "policy-engine/docs/research/e02-cloud-test-plan/integration/reviews/F-delta-owner-actions-2026-10-06.md")
        tsv_binding = draft["original_owner_tsv"]
        source_refs["finding_owner_TSV"] = self.ref(BASE, tsv_binding["path"], tsv_binding)
        full_tsv = self.raw(BASE, tsv_binding["path"]).decode()
        owner_rows = list(csv.DictReader(io.StringIO(full_tsv), delimiter="\t"))
        owners = {r["finding_id"]: r for r in owner_rows if r.get("unit") == "F"}
        expected = {r["finding_id"]: r for r in recon["rows"]}
        proposal = {r["finding_id"]: r for r in draft["rows"]}
        historical = {r["finding_id"]: r for r in old_audit["rows"]}
        assert set(expected) == set(proposal) == set(historical) == set(owners)
        assert len(expected) == 35 and sum(len(r["original_card_bindings"]) for r in expected.values()) == 36
        assert len({r["bundle"] for r in expected.values()}) == 17
        # Preserve every immutable old component. Never assume latest source == old receipt head.
        for r in old_index["receipt_registry"]:
            self.add_receipt("frozen421_" + r["lane"], r["head"], r["receipt_path"], r, historical=True)
        current_registry = draft["current_receipt_registry"]
        for lane, r in (current_registry.items() if isinstance(current_registry, dict) else [(r["key"], r) for r in current_registry]):
            self.add_receipt(lane, r.get("published_receipt_head", r.get("git_ref")), r["path"], r)
        extra = [(lane, head, path, None) for lane, head, path in EXTRA]
        if self.args.extra_registry:
            for r in json.loads(pathlib.Path(self.args.extra_registry).read_text()):
                extra.append((r["lane"], r["head"], r["path"], r))
        for lane, head, path, expected_binding in extra:
            path = path if path.startswith("policy-engine/") else PREFIX + path
            try:
                self.raw(head, path)
            except subprocess.CalledProcessError:
                if lane not in OPTIONAL_DISCOVERY:
                    raise
                matches = [p for p in self.git("diff-tree", "--no-commit-id", "--name-only", "-r", head).decode().splitlines() if p.startswith(PREFIX) and p.endswith(".json") and p.count("/") == PREFIX.count("/")]
                if len(matches) != 1:
                    raise ValueError("Ambiguous receipt path discovery for " + head + ": " + repr(matches))
                path = matches[0]
            self.add_receipt(lane, head, path, expected_binding)
        for i, item in enumerate(old_transport["files"]):
            self.add_material(FROZEN, item, "frozen421/full-transports/" + str(i))
        for row in expected.values():
            for b in row["original_card_bindings"]:
                doc = self.raw(b["source_sha"], b["source_path"])
                start, end = b["lines"]
                block = b"".join(doc.splitlines(keepends=True)[start - 1:end])
                assert len(block) == b["bytes"] and digest(block) == b["sha256"]
                assert block.decode().splitlines()[0] == b["title"]
        full_checks = []
        adjudication = None
        if self.args.root_adjudication:
            adjudication, adjudication_ref = self.local(self.args.root_adjudication)
            source_refs["ROOT_explicit_adjudication"] = adjudication_ref
        for record in self.registry:
            receipt = self.receipts[(record["head"], record["receipt_path"])]
            for i, check in enumerate(receipt.get("checks", [])):
                if isinstance(check, dict):
                    full_checks.append(self.enrich_check(record, i, check))
        rows = []
        pending_ids = {"LA-007", "LA-019", "LA-020"}
        for ident, proposed in proposal.items():
            original = expected[ident]
            old = historical[ident]
            cards = []
            for b in original["original_card_bindings"]:
                start, end = b["lines"]
                block = b"".join(self.raw(b["source_sha"], b["source_path"]).splitlines(keepends=True)[start - 1:end])
                cards.append({**b, "complete_original_block": block.decode(), "byte_binding_check": "PASS"})
            owner_proposals = []
            supplemental_components = []
            for i, record in enumerate(self.registry):
                receipt = self.receipts[(record["head"], record["receipt_path"])]
                entries = self.per_id_entries(receipt, ident)
                applicable = norm_id(ident) in {norm_id(i) for i in record["related_finding_ids"]} or bool(entries)
                if not applicable and ident == "B206" and record["lane"] in ("rdd", "frozen421_rdd"):
                    applicable = True
                if applicable:
                    supplemental_components.append(i)
                    for entry in entries:
                        owner_proposals.append({"registry_index": i, "receipt_ref": {"head": record["head"], "path": record["receipt_path"], "bytes": record["receipt_bytes"], "sha256": record["receipt_sha256"]}, **entry})
            current_outcome = proposed["current_continuation_outcome_recommendation"]
            check = old["check"]
            if ident == "LA-003":
                check = "FAIL"
            if ident in pending_ids or ident in ("B56", "LA-035"):
                check = "UNRUN"
            # This is a proposal, not a fabricated new canonical owner decision.
            row = {
                "finding_id": ident, "primary_bundle": original["bundle"], "primary_tsv_owner": owners[ident],
                "original_source_criterion_refs": cards, "criterion_short_ru": CURRENT_SHORT[ident],
                "actual_consumer": CURRENT_CONSUMERS.get(ident, proposed["actual_consumer"]),
                "source_scope": proposed["source_scope"], "oracle_and_negative": proposed["oracle_and_negative"],
                "predicate_basis": "Source-card criterion and actual consumer; synthetic known-DGP property and real-data/authority admission are separate.",
                "check": check, "outcome": current_outcome,
                "state_role": "scratch proposal for ROOT canonical ledger; not independent acceptance or G closure",
                "technical_original_criterion_recommendation": proposed["technical_original_criterion_recommendation"],
                "technical_historical_baseline_profile_outcome": proposed["technical_historical_baseline_profile_outcome"],
                "technical_check": old["check"], "current_continuation_outcome_recommendation": current_outcome,
                "check_interpretation": "Proposed original/current criterion measurement disposition. Component-native PASSs remain on their exact source; pending owner/authority measurements are not PASS.",
                "original_criterion_remainder": proposed["original_criterion_remainder"],
                "separate_unavailable_inputs_or_authority": proposed["separate_unavailable_inputs_or_authority"],
                "limit_next_owner_short_ru": proposed["original_criterion_remainder"],
                "authority_check": "UNRUN", "formal_G_accepted": False, "formal_ledger_acceptance": "not_issued",
                "receipt_ref": old["receipt_ref"], "implementation_sha": old["implementation_sha"], "candidate_tree_sha": old["candidate_tree_sha"],
                "historical_421_per_id_deciding_refs": old["deciding_check_refs"],
                "historical_421_owner_decision": old.get("author_per_id_original"),
                "owner_proposals_complete": owner_proposals, "supplemental_receipt_registry_indices": supplemental_components,
                "current_exact_consumer_receipts": proposed["current_supplement_receipts"],
                "canonical_owner_re_adjudication_required": ident in pending_ids or old["outcome"] != current_outcome or old["check"] != check,
                "latest_owner_packet": proposed["latest_owner_packet"], "next_owner": proposed["next_owner"],
            }
            if ident == "B56":
                row["oracle_and_negative"] = "Historical cap1/2 custom-fixture four-study/24-fold bounded numerical/profile checks retained on their old source; not the actual production resource route. New typed producer configured6/default15 actual folds and selected CAS/projection/source-equality controls PASS on6c/d09/12 sources. Actual investigated Runtime route DurableControlWorker → RunLifecycle → run_experiment → sync_run_causal_full has no measured production LocalWorkerPool/TaskRouter constructor. Whole admitted common study workload/budget positive remains UNRUN; attempted common causal pool FAIL execution_context_missing before0fits is not execution evidence."
                row["original_criterion_remainder"] = "Actual admitted Runtime route DurableControlWorker → RunLifecycle → run_experiment → sync_run_causal_full: shared study workload with complete current context/verifier/HTE ingress and common-budget measurements; no self-issued authority or fake pool."
                row["latest_owner_packet"] = "Published6c producer@3ae04 receipt, generated27f289@27f172 receipt and root12dce consumer@39133 receipt establish their bounded MethodJob/CAS/selected-helper properties. Original shared resource criterion remains UNRUN/limited; no pending producer publication is inferred."
                row["limit_next_owner_short_ru"] = row["original_criterion_remainder"]
            if ident in ("LA-007", "LA-019"):
                row["base198_retirement_facts"] = recon["exact_base_retired_sibling_checks"]
            if ident == "B220":
                row["public_change_classification"] = "internal-stable; preserve cache invariant without reclassifying this internal change as public-stable"
            rows.append(row)
        self.expose_published_evidence(rows)
        if adjudication is not None:
            self.apply_root_adjudication(rows, adjudication, source_refs["ROOT_explicit_adjudication"])
        assert len(rows) == 35 and len({r["finding_id"] for r in rows}) == 35
        for row in rows:
            assert row["check"] in CHECKS and row["outcome"] in ("closed", "limited", "held", "open")
            assert row["outcome"] != "closed" or row["check"] == "PASS"
        packets = self.owner_packets()
        order = self.source_order(recon, old_index)
        order_ref = self.write("source-order.json", order)
        packet_ref = self.write("minimal-owner-packets.json", packets)
        topics = self.topics()
        counts = dict(collections.Counter(r["outcome"] for r in rows))
        current_material_check = "PASS"
        pending = {"status": "freeze_blocked", "scope": "Unpublished latest API owner receipt and ECO fiscal precision repair/review; not missing synthetic numerical reruns.", "checks": [{"owner": "API", "check": "UNRUN", "ids": ["LA-007", "LA-019", "LA-020"], "required": "Exact new implementation/tree and owner per-ID/census/install outcome receipt, pending producer publication"}, {"owner": "ECO precision", "check": "UNRUN", "source_sha": "1324d2fcd7b75e448ad0fa1cce128a79101df1aa", "ids": ["LA-003"], "required": "Exact repaired .10 fiscal budget consumer source and independent precision receipt; current red remains FAIL"}, {"owner": "FIT ConfidencePass", "check": "UNRUN", "ids_not_reassigned": True, "G_source_ref": source_refs["G127_owner_actions"], "property": "Preserve accumulated causal-purpose blocker when simulation CAS is missing/corrupt", "P40": "SAME_CLASS_DEEPER", "required": "Focused actual ConfidencePass current-reference/load-error sibling control and marker-preserving removal on frozen repair source"}, {"owner": "FRY monitor", "check": "UNRUN", "ids_not_reassigned": True, "G_source_ref": source_refs["G127_owner_actions"], "property": "Exactly one canonical anomaly for report/result alias dualview NaN, while distinct raw sidecar is independently reported", "P40": "NEW_CLASS", "required": "Actual native dematerializer/dispatcher dualview control and alias-correspondence removal on frozen repair source"}, {"owner": "Graph/test owner", "check": "UNRUN", "ids_not_reassigned": True, "G_source_ref": source_refs["G127_owner_actions"], "property": "Reconcile three actual neighbor fixture hypotheses: AMN endpoint conditioning and two SID/conditional-ID observed-U collider versus intended bow cases", "required": "Frozen exact fixture/proposal source plus independent actual scientific consumer/oracle; historical threeFAIL remain, no P41 inheritance or automatic method correction"}]}
        if adjudication is not None and adjudication.get("schema") == "F-root-current35-adjudication/1":
            pending = adjudication["pending_scientific_blockers"]
        else:
            for item in pending["checks"]:
                if item["owner"] == "API" and self.latest_record("api-public-export-continuation-20261006.json"):
                    item["required"] = "Exact new API source/receipt is published and exposed. Current installed composition and explicit ROOT per-ID adjudication remain pending; published evidence alone does not close the criterion."
                    item["published_receipt_ref"] = self.record_ref(self.latest_record("api-public-export-continuation-20261006.json"))
                if item["owner"] == "FIT ConfidencePass" and self.latest_record("causal-confidence-issue-preservation-20261006.json"):
                    item["required"] = "Exact blocker-preservation source/native/removal and independent review receipt is published and exposed. ROOT final checkpoint/assembled install is separate; authority-positive remains UNRUN."
                    item["published_receipt_ref"] = self.record_ref(self.latest_record("causal-confidence-issue-preservation-20261006.json"))
                if item["owner"] == "Graph/test owner" and self.latest_record("causal-neighbor-fixtures-20261006.json"):
                    item["required"] = "Exact analytic fixture hypotheses/native/removal and independent review receipt is published and exposed. ROOT final source/installed checkpoint remains separate; original erroneous fixture FAIL stays historical, no P41 inheritance."
                    item["published_receipt_ref"] = self.record_ref(self.latest_record("causal-neighbor-fixtures-20261006.json"))
                if item["owner"] == "FRY monitor" and self.latest_record("output-anomaly-count-20261006.json"):
                    item["required"] = "Exact dualview source/native/removal and independent review receipt is published and exposed; explicit ROOT checkpoint adjudication/current assembled install remains separate."
                    item["published_receipt_ref"] = self.record_ref(self.latest_record("output-anomaly-count-20261006.json"))
                if item["owner"] == "ECO precision" and self.latest_record("economic-fiscal-precision-continuation-20261006.json"):
                    item["required"] = "Exact132 precision owner receipt/review is published and exposed. ROOT must adjudicate original migration/precision criterion separately from the retained ABM neighbor FAIL and prior old-source precision FAIL."
                    item["published_receipt_ref"] = self.record_ref(self.latest_record("economic-fiscal-precision-continuation-20261006.json"))
            pending["scope"] = "Published component evidence awaiting explicit ROOT final adjudication, formatter-only source freeze, exact API/inventory binding refresh and one assembled installed wave. Source formatting is not a scientific method defect; checkpoint receipts alone do not clear this pending status."
            if adjudication is not None:
                pending["ROOT_draft_pending_literal"] = adjudication.get("pending_scientific_blockers")
                pending["ROOT_draft_source_sha"] = adjudication["root_source_sha"]
        audit = {
            "schema": "F-current35-scratch-full-audit/1", "role": "builder-generated draft; NOT independent review/closure/G acceptance", "scientific_reruns": False,
            "root_source_sha": self.root_sha, "root_source_tree": self.root_tree, "source_inputs": source_refs,
            "finding_count": 35, "bundle_count": 17, "original_card_bindings": 36, "unique_original_card_blocks": 35,
            "original_owner_TSV_full_text": full_tsv, "original_owner_TSV_F_rows": list(owners.values()),
            "rows": rows, "receipt_registry": self.registry, "complete_component_checks": full_checks,
            "historical_421_summary_literal": old_index["summary"], "historical_421_protocol_qualification": old_audit["protocol_qualification"],
            "declared_transport_denominators": self.manifest_denominators, "non_deciding_textual_assertions_without_raw_output": [c for c in full_checks if c.get("non_deciding_literal_assertion")], "current_material_byte_bindings": current_material_check, "reference_check_scope": "Exact registry/candidate trees, original cards/TSV, declared manifest artifacts and complete check output/execution streams. All arbitrary nested historical citation custody is not promoted.", "all_reference_custody_check": "UNRUN",
            "historical_non_deciding_reference_check": "UNRUN", "historical_unavailable_provenance": old_index["historical_non_deciding_custody"],
            "P41": "not_established: no full exact-slice-base/full-input denominator zero intersection inference", "pending_scientific_blockers": pending,
            "independent_final_validation": "UNRUN: separate prepared validator/reviewer must read immutable ROOT publication; builder consistency is not independent review",
        }
        audit_ref = self.write("full-audit.json", audit)
        transports = {"schema": "F-current35-existing-Git-byte-transports/1", "role": "No raw copies; complete immutable existing Git bytes and decoded bindings", "files": list(self.material.values()), "declared_transport_denominators": self.manifest_denominators, "current_deciding_reference_check": current_material_check, "historical_non_deciding_reference_check": "UNRUN", "all_reference_custody_check": "UNRUN", "non_deciding_textual_assertions_without_raw_output": [c for c in full_checks if c.get("non_deciding_literal_assertion")], "zero_finding_deciding_dependence_on_these_non_deciding_assertions": True, "unavailable_historical_provenance": old_index["historical_non_deciding_custody"]}
        transport_ref = self.write("artifact-transports.json", transports)
        # The full audit alone carries complete original text/owner excerpts.
        # Keep the compact index navigational without duplicating those bodies.
        index_rows = []
        for number, row in enumerate(rows):
            compact = {k: v for k, v in row.items() if k not in ("owner_proposals_complete", "historical_421_per_id_deciding_refs", "historical_421_owner_decision")}
            compact["original_source_criterion_refs"] = [{k: v for k, v in b.items() if k != "complete_original_block"} for b in row["original_source_criterion_refs"]]
            compact["complete_audit_row_ref"] = {**audit_ref, "json_pointer": "/rows/" + str(number)}
            compact["complete_owner_and_deciding_evidence"] = "Full source-bound owner entries and exact historical/current checks are retained in this audit row and the receipt registry; not duplicated in the index."
            index_rows.append(compact)
        index = {
            "schema": "F-current35-scratch-index/1", "unit": "F", "role": "ROOT proposal only; not tracked/accepted final transfer",
            "common_base_sha": BASE, "common_base_tree_sha": self.tree(BASE), "current_root_source_sha": self.root_sha, "current_root_source_tree_sha": self.root_tree,
            "finding_count": 35, "bundle_count": 17, "original_card_bindings": 36, "unique_original_card_blocks": 35,
            "summary": {"outcome_counts": counts, "technical_original_criterion_counts": dict(collections.Counter(r["technical_original_criterion_recommendation"] for r in rows)), "row_states_are_proposals": True},
            "finding_rows": index_rows, "receipt_registry": self.registry, "topics": topics,
            "complete_input_and_audit_refs": {"full_audit": audit_ref, "transports": transport_ref, "source_order": order_ref, "minimal_owner_packets": packet_ref, **source_refs},
            "current_deciding_reference_check": "PASS", "all_reference_custody_check": "UNRUN", "historical_non_deciding_reference_check": "UNRUN",
            "historical_non_deciding_custody": old_index["historical_non_deciding_custody"],
            "pending_scientific_blockers": pending, "current_deciding_issues": [], "non_deciding_textual_assertions_without_raw_output": [c for c in full_checks if c.get("non_deciding_literal_assertion")], "zero_finding_deciding_dependence_on_missing_historical175c_and_lint_raw": True, "independent_final_validation": "UNRUN",
            "G_integration": {"formal_finding_closure": "not_issued", "accepted_code_only": {"implementation_sha": LEX_ACCEPTED_CODE, "implementation_tree": self.tree(LEX_ACCEPTED_CODE), "ancestor_of_current_G": self.ancestor(LEX_ACCEPTED_CODE, G_CHECKPOINT), "finding_closure": "not_issued"}, "audit_sha": G_AUDIT, "runtime_baseline_sha": G_RUNTIME},
            "runtime_limits": ["Known synthetic DGP/mathematical property is distinct from admitted real data.", "Whole Node current Runtime/verifier/semantic-PDC intake/common competing-study budget UNRUN; no authority self-issue.", "Old5cd installed source-only PASS supersedes oldab56, not a fresh assembled runtime PASS.", "DoWhy/EconML Python3.14 marker exclusions are not backend witnesses; actual pinned3.12 subprocess receipts remain separate.", "Historical FAIL/ERROR/SKIP/UNRUN retain exact source and meaning; P41 inherited attribution not established."],
            "P41": "not_established", "publication_state": "scratch draft, " + pending["status"],
        }
        index_ref = self.write("index.json", index)
        report_ref = self.write("REPORT.md", self.report(index))
        manifest = self.write("builder-result.json", {"schema": "F-current35-builder-result/1", "role": "self consistency only; not independent acceptance", "builder_sha256": digest(pathlib.Path(__file__).read_bytes()), "root_sha": self.root_sha, "root_tree": self.root_tree, "input_refs": source_refs, "artifacts": [index_ref, audit_ref, transport_ref, order_ref, packet_ref, report_ref], "denominator": {"findings": 35, "bundles": 17, "card_bindings": 36, "receipt_components": len(self.registry), "topics": len(topics), "material_records": len(self.material)}, "summary": counts, "pending_scientific_blockers": pending, "builder_checks": "PASS", "independent_final_validation": "UNRUN", "separate_prepared_validator": {"path": str(pathlib.Path(__file__).with_name("validate_packet.py")), "bytes": pathlib.Path(__file__).with_name("validate_packet.py").stat().st_size, "sha256": digest(pathlib.Path(__file__).with_name("validate_packet.py").read_bytes()), "role": "prepared independent final-packet guard, not applied as self-independent acceptance of this builder draft"}, "G_formal_closure": "not_issued"})
        print(json.dumps(manifest, ensure_ascii=False))
        print(json.dumps({"builder_checks": "PASS", "denominator": {"35": len(rows), "17": len({r['primary_bundle'] for r in rows}), "36": sum(len(r['original_source_criterion_refs']) for r in rows)}, "components": len(self.registry), "topics": len(topics), "complete_material_records": len(self.material), "draft_outcomes": counts, "publication_state": pending["status"], "independent_validation": "UNRUN"}, ensure_ascii=False))

    def record_ref(self, record):
        return {"head": record["head"], "path": record["receipt_path"], "bytes": record["receipt_bytes"], "sha256": record["receipt_sha256"], "implementation_sha": record["implementation_sha"], "candidate_tree_sha": record["candidate_tree_sha"]}

    def latest_record(self, basename):
        candidates = [r for r in self.registry if r["receipt_path"].endswith("/" + basename)]
        return candidates[-1] if candidates else None

    def expose_published_evidence(self, rows):
        """Update publication-stage prose only. ROOT alone can adjudicate states."""
        api = self.latest_record("api-public-export-continuation-20261006.json")
        fiscal = self.latest_record("economic-fiscal-precision-continuation-20261006.json")
        for row in rows:
            ident = row["finding_id"]
            if api and ident in ("LA-007", "LA-019", "LA-020", "LA-017"):
                row["latest_owner_packet"] = "Published exact API owner evidence " + api["head"] + ":" + api["receipt_path"] + "; current assembled install/explicit ROOT decision remain separate. Finite UNKNOWN candidates are not established clients."
                row["latest_published_receipt_refs"] = [self.record_ref(api)]
                row["canonical_owner_re_adjudication_required"] = True
            if fiscal and ident == "LA-003":
                row["historical_old_source_disposition"] = {"check": row["check"], "outcome": row["outcome"], "remainder": row["original_criterion_remainder"], "oracle_and_negative": row["oracle_and_negative"]}
                row["check"] = "UNRUN"
                row["criterion_short_ru"] = "Native fiscal/labor migration: published132 finite precision evidence; ROOT whole-criterion adjudication pending, prior precision FAIL retained historically"
                row["original_criterion_remainder"] = "Published132 precision source/checks require explicit ROOT per-ID adjudication of the original finite migration/precision criterion; retained ABM diagnostic FAIL is separately scoped, not erased or inherited by assertion."
                row["limit_next_owner_short_ru"] = row["original_criterion_remainder"]
                row["oracle_and_negative"] = "All actual132 floating-profile budget/matrix/native/compiler/CAS controls and earlier forced32/base/precision FAIL/ERROR streams are preserved in the exact fiscal receipt. Full125native=124PASS1ABMdiagnosticFAIL; source-specific property checks are not a whole125PASS."
                row["latest_owner_packet"] = "Published fiscal source " + fiscal["implementation_sha"] + "/tree" + fiscal["candidate_tree_sha"] + " carried by " + fiscal["head"] + "; no automatic original-finding closure."
                row["latest_published_receipt_refs"] = [self.record_ref(fiscal)]
                row["canonical_owner_re_adjudication_required"] = True

    def apply_root_draft(self, rows, data, input_ref):
        """Apply explicit ROOT draft row choices without claiming a final source freeze.

        The original input SHA/header/bytes remain literal and source-bound. Only
        ancestry is checked here; it is never substituted for scientific replay.
        """
        source = data.get("root_source_sha")
        if not isinstance(source, str) or len(source) != 40:
            raise ValueError("ROOT draft must contain its full actual source SHA")
        relation = self.ancestor(source, self.root_sha)
        if relation.get("is_ancestor") is not True:
            raise ValueError("ROOT draft source is not an admitted ancestor of this draft composition")
        supplied = data.get("rows")
        by_id = {row["finding_id"]: row for row in rows}
        if not isinstance(supplied, list) or len(supplied) != 35 or {row.get("finding_id") for row in supplied} != set(by_id):
            raise ValueError("ROOT draft must provide all35 original rows exactly once")
        required = {"finding_id", "check", "outcome", "criterion_short_ru", "actual_consumer", "oracle_and_negative", "original_criterion_remainder", "limit_next_owner_short_ru", "technical_original_criterion_recommendation"}
        allowed = required | {"pending_root_adjudication_after_new_installed_wave"}
        for number, decision in enumerate(supplied):
            if not required <= set(decision) or set(decision) - allowed:
                raise ValueError("Unsupported ROOT draft row fields; cannot silently invent missing current fields")
            if "pending_root_adjudication_after_new_installed_wave" in decision and not isinstance(decision["pending_root_adjudication_after_new_installed_wave"], bool):
                raise ValueError("ROOT draft pending-installed flag must be a literal boolean")
            if decision["check"] not in CHECKS or decision["outcome"] not in ("closed", "limited", "held", "open") or decision["technical_original_criterion_recommendation"] not in ("closed", "limited", "held", "open"):
                raise ValueError("Canonical separate draft check/outcome required")
            if decision["outcome"] == "closed" and decision["check"] != "PASS":
                raise ValueError("ROOT draft cannot close a nonPASS finding")
            row = by_id[decision["finding_id"]]
            row["historical_proposal_before_ROOT_draft"] = {key: row.get(key) for key in allowed if key != "finding_id"}
            row.update(decision)
            row["current_continuation_outcome_recommendation"] = decision["outcome"]
            row["ROOT_draft_decision_ref"] = {**input_ref, "json_pointer": "/rows/" + str(number)}
            row["ROOT_draft_source_sha_literal"] = source
            row["ROOT_draft_source_tree"] = self.tree(source)
            row["ROOT_draft_ancestry_check"] = relation
            row["ROOT_draft_current_composition_sha"] = self.root_sha
            row["ROOT_draft_not_final_source_freeze"] = True
            row["ROOT_fields_not_supplied_remain_source_carry"] = ["source_scope", "separate_unavailable_inputs_or_authority", "next_owner", "latest_owner_packet", "deciding_receipt_refs"]
            row["check_scope"] = "Explicit ROOT criterion DRAFT recommendation; its original source pin remains distinct from later composition; not final installed or G acceptance"
            row["formal_G_accepted"] = False
            row["canonical_owner_re_adjudication_required"] = True

    def apply_root_adjudication(self, rows, data, input_ref):
        if data.get("schema") == "F-root-explicit-adjudication-draft/1":
            return self.apply_root_draft(rows, data, input_ref)
        if data.get("schema") != "F-root-current35-adjudication/1":
            raise ValueError("Unsupported ROOT adjudication schema")
        if data.get("root_source_sha") != self.root_sha or data.get("root_source_tree_sha") != self.root_tree:
            raise ValueError("ROOT adjudication must bind this exact assembled source SHA/tree")
        if data.get("formal_G_ledger_acceptance") != "not_issued":
            raise ValueError("No formal G finding closure has been issued; it cannot be self-assigned")
        supplied = data.get("rows")
        if not isinstance(supplied, list):
            raise ValueError("ROOT rows list required")
        by_id = {r["finding_id"]: r for r in rows}
        ids = [r.get("finding_id") for r in supplied]
        if len(set(ids)) != len(ids) or not set(ids) <= set(by_id):
            raise ValueError("Wrong/duplicate original finding ID in ROOT adjudication")
        if data.get("scope") not in ("partial", "complete35"):
            raise ValueError("Explicit partial/complete35 adjudication scope required")
        if data.get("scope") == "complete35" and set(ids) != set(by_id):
            raise ValueError("complete35 ROOT adjudication must include every original ID exactly once")
        required = {"finding_id", "check", "outcome", "technical_original_criterion_recommendation", "criterion_short_ru", "actual_consumer", "source_scope", "oracle_and_negative", "original_criterion_remainder", "separate_unavailable_inputs_or_authority", "latest_owner_packet", "next_owner", "decision_basis", "deciding_receipt_refs"}
        allowed = required | {"technical_check", "current_exact_consumer_receipts"}
        for number, decision in enumerate(supplied):
            if not required <= set(decision) or set(decision) - allowed:
                raise ValueError("ROOT row must provide ALL dependent criterion/consumer/oracle/remainder fields; no original-card/owner/authority override permitted: " + str(decision.get("finding_id")))
            if decision["check"] not in CHECKS or decision["outcome"] not in ("closed", "limited", "held", "open") or decision["technical_original_criterion_recommendation"] not in ("closed", "limited", "held", "open"):
                raise ValueError("Noncanonical separate check/outcome")
            if decision["outcome"] == "closed" and decision["check"] != "PASS":
                raise ValueError("SKIP/ERROR/FAIL/UNRUN cannot close a finding")
            if not isinstance(decision["deciding_receipt_refs"], list) or not decision["deciding_receipt_refs"]:
                raise ValueError("Source-bound complete deciding receipt refs required")
            verified = []
            for ref in decision["deciding_receipt_refs"]:
                if not {"head", "path", "bytes", "sha256"} <= set(ref):
                    raise ValueError("Each ROOT deciding artifact needs explicit carrier head/path/hash/bytes")
                actual = self.add_material(ref["head"], ref, "ROOT_adjudication/" + decision["finding_id"])
                if ref.get("json_pointer"):
                    selected = json.loads(self.raw(ref["head"], ref["path"]))
                    for key in ref["json_pointer"].strip("/").split("/"):
                        key = key.replace("~1", "/").replace("~0", "~")
                        selected = selected[int(key)] if isinstance(selected, list) else selected[key]
                    actual = {**actual, "json_pointer": ref["json_pointer"], "complete_deciding_entry": selected}
                verified.append(actual)
            row = by_id[decision["finding_id"]]
            row["historical_proposal_before_ROOT_adjudication"] = {key: row.get(key) for key in required if key != "finding_id"}
            row.update({key: value for key, value in decision.items() if key not in ("finding_id", "deciding_receipt_refs")})
            row["current_continuation_outcome_recommendation"] = decision["outcome"]
            row["limit_next_owner_short_ru"] = decision["original_criterion_remainder"]
            row["predicate_basis"] = decision["decision_basis"]
            row["check_scope"] = "Explicit source-bound ROOT original/current criterion adjudication; exact component outcomes remain separately preserved"
            row["canonical_owner_re_adjudication_required"] = False
            row["ROOT_deciding_refs"] = verified
            row["ROOT_adjudication_ref"] = {**input_ref, "json_pointer": "/rows/" + str(number)}
            row["formal_G_accepted"] = False
        pending = data.get("pending_scientific_blockers")
        if not isinstance(pending, dict) or pending.get("status") not in ("resolved", "freeze_blocked") or not isinstance(pending.get("checks"), list):
            raise ValueError("Explicit ROOT pending status/checks required; receipt presence cannot silently clear blockers")
        if pending["status"] == "resolved" and (data["scope"] != "complete35" or not pending["checks"]):
            raise ValueError("Resolved final packet needs explicit complete35 ROOT decisions and measured checkpoints")
        for check in pending["checks"]:
            if check.get("check") not in CHECKS:
                raise ValueError("Pending check needs canonical disposition")
            if pending["status"] == "resolved" and (check["check"] != "PASS" or not check.get("head", check.get("source_sha"))):
                raise ValueError("Resolved pending checkpoints require PASS and exact source/head; raw FAIL/ERROR controls remain separate")
            head = check.get("head", check.get("source_sha"))
            if head:
                if len(head) != 40 or self.git("rev-parse", head + "^{commit}").decode().strip() != head:
                    raise ValueError("Pending head must resolve as the exact full immutable commit")
            if pending["status"] == "resolved":
                if not check.get("deciding_receipt_refs"):
                    raise ValueError("Resolved checkpoint needs complete exact deciding artifact refs, not only markers/head")
                for ref in check["deciding_receipt_refs"]:
                    if not {"head", "path", "bytes", "sha256"} <= set(ref):
                        raise ValueError("Resolved checkpoint artifact needs exact head/path/hash/bytes")
                    self.add_material(ref["head"], ref, "ROOT_resolved_checkpoint/" + check.get("owner", "unnamed"))

    def topics(self):
        groups = collections.defaultdict(list)
        for r in self.registry:
            branch = r["branch"] or "branch-unspecified:" + r["lane"]
            component = {"lane": r["lane"], "implementation_candidate_sha": r["implementation_sha"], "implementation_candidate_tree": r["candidate_tree_sha"], "receipt": {"git_ref": r["head"], "path": r["receipt_path"], "bytes": r["receipt_bytes"], "sha256": r["receipt_sha256"]}, "role": r["component_role"]}
            groups[branch].append(component)
        return [{"branch": branch, "components": components} for branch, components in sorted(groups.items())]

    def source_order(self, recon, old_index):
        history = self.git("log", "--reverse", "--topo-order", "--format=%H", BASE + ".." + self.root_sha).decode().splitlines()
        records = []
        for head in history:
            header = self.git("show", "-s", "--format=%P%n%T%n%s%n%B", head).decode().splitlines()
            records.append({"sha": head, "parents": header[0].split(), "tree": header[1], "subject": header[2], "full_message": "\n".join(header[3:])})
        sources = {}
        for r in self.registry:
            for source in r["implementation_commits"]:
                if source in sources:
                    sources[source]["components"].append(r["lane"])
                    continue
                paths = self.git("diff-tree", "--no-commit-id", "--name-only", "-r", source).decode().splitlines()
                refs = []
                for path in paths:
                    try:
                        own = self.ref(source, path)
                    except subprocess.CalledProcessError:
                        refs.append({"path": path, "source_sha": source, "disposition": "deleted at source", "root_path_present": self.path_exists(self.root_sha, path)})
                        continue
                    try:
                        root = self.ref(self.root_sha, path)
                        equal = root["sha256"] == own["sha256"] and root["bytes"] == own["bytes"]
                    except subprocess.CalledProcessError:
                        root, equal = None, False
                    refs.append({"path": path, "source_ref": own, "root_ref": root, "bytes_equal": equal, "scope": "Source bytes only; no inherited numerical/runtime result inference"})
                ancestor = self.ancestor(source, self.root_sha)
                unmerged_history = []
                if ancestor.get("is_ancestor") is False:
                    unmerged_history = self.git("log", "--reverse", "--topo-order", "--format=%H %P %T %s", BASE + ".." + source).decode().splitlines()
                sources[source] = {"source_sha": source, "source_tree": self.tree(source), "components": [r["lane"]], "root_ancestry": ancestor, "full_defining_commit_path_bindings": refs, "upstream_complete_history_if_not_ancestor": unmerged_history}
        return {"schema": "F-current35-append-history-and-byte-bindings/1", "base_sha": BASE, "base_tree": self.tree(BASE), "root_sha": self.root_sha, "root_tree": self.root_tree, "complete_root_topological_append_history": records, "implementation_source_bindings": list(sources.values()), "historical_source_order_ref": {"git_ref": FROZEN, **old_index["complete_input_and_audit_refs"]["G_source_order"]}, "historical_complete_source_order": json.loads(self.raw(FROZEN, old_index["complete_input_and_audit_refs"]["G_source_order"]["path"])), "exact_base_retirement_facts": recon["exact_base_retired_sibling_checks"], "unchanged_historical_installed_bindings": recon["fresh_independent_unchanged_installed_source_and_output_bindings"], "installed_interpretation": "Historical5cd190d24d133f618fcc66ecc01f70c8a1b4f1f6 source-only installed PASS superseded ab56 on its own source; full old source-order remains immutable421. Current source/site evidence is separately bound below, never inferred by rewriting old results.", "current_installed_evidence": self.current_installed_evidence(), "original_local_recipe_status": "superseded for current source; exact original recipe/source locators remain in historical immutable421 source-order", "current_local_production_packet": {"check": "UNRUN", "command": None, "source_sha": self.root_sha, "source_tree": self.root_tree, "required": "Actual current Runtime/verifier/PDC semantic intake, admitted B56 shared workload and selected local law/optimizer owner inputs; no guessed production command or self-issued authority"}, "ancestry_is_separate_from_byte_equivalence": True, "no_staged_patch_used_as_history": True, "no_history_rewrite": True, "no_P41_inherited_claim": True, "G": {"audit_sha": G_AUDIT, "runtime_baseline_sha": G_RUNTIME, "current_document_checkpoint_sha": G_CHECKPOINT, "checkpoint_tree": self.tree(G_CHECKPOINT), "delta_from_G363_paths": self.git("diff", "--name-only", G_AUDIT, G_CHECKPOINT).decode().splitlines(), "accepted_Lex_code_sha": LEX_ACCEPTED_CODE, "accepted_Lex_code_ancestry": self.ancestor(LEX_ACCEPTED_CODE, G_CHECKPOINT), "formal_closure": "not_issued"}}

    def path_exists(self, head, path):
        run = subprocess.run(["git", "-C", self.args.repo, "cat-file", "-e", head + ":" + path], capture_output=True)
        return run.returncode == 0

    def current_installed_evidence(self):
        record = self.latest_record("installed-final-consumer-20261006.json")
        if not record:
            return {"check": "UNRUN", "source_sha": self.root_sha, "reason": "Current immutable installed consumer primary not attached; historical5cd is not substituted"}
        receipt = self.receipts[(record["head"], record["receipt_path"])]
        declared = receipt.get("external_tested_source", {})
        if declared.get("sha") != self.root_sha or declared.get("tree") != self.root_tree:
            return {"check": "UNRUN", "receipt_ref": self.record_ref(record), "tested_source_literal": declared, "reason": "Exact external tested source differs from this composition; no inherited runtime inference"}
        review_path = receipt["complete_independent_review"]
        review_ref = self.add_material(record["head"], {"path": review_path}, "current_installed_evidence/independent_review")
        review = json.loads(self.raw(record["head"], review_path))
        if review.get("source_sha") != self.root_sha or review.get("source_tree") != self.root_tree:
            raise ValueError("Installed independent review source identity differs from the registered external candidate")
        profiles = {}
        removals = []
        for name, profile in review["profiles"].items():
            profiles[name] = {key: profile[key] for key in ("check", "passed", "failed", "errors", "skipped", "deselected", "deselection_scope", "warning_classification")}
            profiles[name]["complete_profile_ref"] = {**review_ref, "json_pointer": "/profiles/" + name}
            for index, control in enumerate(profile["retained_marker_negative_controls"]):
                removals.append({"profile": name, "mode": control["mode"], "actual_exit_code": control["exit_code"], "check": "FAIL" if control["exit_code"] == 1 else "ERROR", "complete_control_ref": {**review_ref, "json_pointer": "/profiles/" + name + "/retained_marker_negative_controls/" + str(index)}})
        return {"check": review["check"], "source_sha": self.root_sha, "source_tree": self.root_tree, "receipt_ref": self.record_ref(record), "independent_review_ref": review_ref, "profiles": profiles, "retained_marker_controls": removals, "scope": review["scope"], "authority_limits": review["authority_limits"], "old_installed_5cd_ab56_retained_separately": True, "formal_G_closure": "not_issued", "not_whole_Runtime_Node_or_B56_authority": True}

    def owner_packets(self):
        result = {"schema": "F-current35-minimal-missing-owner-inputs/1", "not_scientific_closure_prerequisites_for_all_rows": True, "no_authority_self_issue": True, "packets": [
            {"packet_id": "runtime-causal-admission", "owners": ["Runtime/C", "PDC semantic owner", "G local runner"], "check": "UNRUN", "scope": "Actual production route DurableControlWorker → RunLifecycle → run_experiment → sync_run_causal_full and RunCausalEvaluationNode authority/intake, separate from internal numerical run_primary and finite ArtifactRef byte resolver", "required": ["Exact candidate SHA/deployment interpreter and real registered study/HTE input view with original CAS manifests and selected raw arrays", "Current EvalSafetyContext plus real accepted issuer/verifier, rights/revision/appointment and unchanged fresh challenge", "Actual PDC distinct semantic hash profile with exact current input basis and source owner; byte-identical ArtifactRef view resolution is not semantic admission"], "consumer_falsifiers": ["Change only current diagnostic input time_treatment with selected-target markers retained must recompute/refuse", "Same-shape TMLE X/W/Y/A/sample-ID change must refuse before job", "Missing/stale/duplicate/wrong-view CAS manifest identity and semantic-profile mismatch must reject"], "not_required": "No issuer can be invented by F; no broad production data upload"},
            {"packet_id": "B56-common-budget", "owners": ["Runtime/C", "G local runner"], "ids": ["B56"], "check": "UNRUN", "scope": "Actual production DurableControlWorker → RunLifecycle → run_experiment → sync_run_causal_full admitted shared competing-study workload and budget", "required": ["Real current EvalSafety context/verifier ingress and supported typed HTE→registered study route", "Named multiple study workloads/folds/repeats/seeds, actual deployment common CPU/memory/admission budget and competing jobs", "Full observed active/wait/wall/memory/admitted/finished/lost result measurements, exact per-study native fit counts and numerical/provenance comparison"], "already_measured_separate": "Configured real6/default15-fold MethodJob/CAS/freshreader and internal numerical projection; attempted common causal LocalWorkerPool FAIL execution_context_missing before0fits; old four-studies24fold fixture is bounded historical evidence, no production LocalWorkerPool/TaskRouter constructor witness", "falsifier": "Nested/global admission removal must cause an actual common-budget violation while preserving numerical/source markers; no fake pool or quota on independent cloud tests"},
            {"packet_id": "Lex-current-local-law", "owners": ["Lex legal semantic owner", "G local data runner"], "ids": ["LA-017"], "check": "UNRUN", "scope": "Selected current local law/jurisdiction/corpus and supported caller/config migration", "required": ["Exact current jurisdiction/edition/date/corpus inputs and lawful semantic applicability basis", "Named supported caller/config/CLI/reader window, old persisted corpus samples and exact root candidate", "Real local selected producer→CAS→fresh consumer outputs with full law-dependent deciding residual"], "already_measured_separate": "Synthetic LegalPass/impact/dedupe consumer and Lex code-only G acceptance", "no_broad_authority_propagation": True},
            {"packet_id": "LA035-optimizer-intent", "owners": ["Economics semantic owner", "Maintained optimizer owner"], "ids": ["LA-035"], "check": "UNRUN", "outcome": "held", "scope": "Actual maintained optimizer and normative unit/population/time/sign intent", "required": ["Named actual maintained optimizer caller, finite expected caller/state/config and source SHA", "Normative unit/population/time/sign intent for the selected objective, including meaning of income>=1 historical constant−1", "Selected optimizer JIT/gradient/guardrail actual consumer and bounded finite oracle"], "already_measured_separate": "Historical normalized_income_budget_loss baseline, aliases/JIT/grad/replay profile; not whole original/current semantic acceptance"},
        ]}
        quality = self.latest_record("source-quality-freeze-20261006.json")
        quality_ref = None if quality is None else self.record_ref(quality)
        for packet in result["packets"]:
            packet["not_source_freeze_blocker"] = True
            if packet["packet_id"] in ("Lex-current-local-law", "LA035-optimizer-intent"):
                packet["published_owner_packet_and_quality_ref"] = quality_ref
            if packet["packet_id"] == "Lex-current-local-law":
                packet["required"][0] = "Exact selected NormPack/current_manifest_ref/original norms input basis, jurisdiction/edition and explicit as_of time; lawful semantic applicability supplied by the legal owner"
        result["packets"] += [
            {"packet_id": "Core-Feedback-schema-projections", "owners": ["Canonical Core/IR Feedback schema owner", "99-schema owner"], "check": "UNRUN", "not_source_freeze_blocker": True, "scope": "Exact FeedbackSolveResult and IR manifest snapshot drift; five nested optional manifest_profile_sha256 projections", "required": ["Actual schema owner review of the five optional properties and exact generator/manifest contract at current source", "Regenerate through the canonical owner and retain full99-schema check outputs; no F blanket schema patch"], "observed_global_check": "FAIL at feedback_solve_result.schema.json and _manifest.json; Ruff/native consumer PASS does not clear it", "source_quality_receipt_ref": quality_ref},
            {"packet_id": "A-C-graph-policy-contract", "owners": ["A policy/EMP owner", "C graph intake producer/contract owner", "G local runner"], "check": "UNRUN", "not_source_freeze_blocker": True, "scope": "Policy gate graph intake, temporal/endpoint contract and actual EMP-01 metadata expectations", "required": ["Actual appointed source graph/data/prior/config/seed basis and upstream producer→CAS/request lineage", "Owner decision for unresolved PAG/circles/lag before static identification and current EMP input profile", "Exact same original EMP command/input denominator at the slice base and current source before any P41 attribution"], "bounded_F_property": "Canonical existing reconcile owner resolves current CAS/request input and refuses unsupported static scope; no global graph-writer ownership or propagated E authority", "source_quality_receipt_ref": quality_ref},
            {"packet_id": "A-ABM-diagnostic-semantics", "owners": ["A ABM diagnostic semantic owner"], "check": "UNRUN", "not_source_freeze_blocker": True, "scope": "Actual retained ABM diagnostic FAIL is separate from the finite native fiscal/labor migration and x64 precision profile", "required": ["Canonical diagnostic intent/allowed contextual and protective fields, exact failing actual consumer inputs and authoritative expected behavior", "Owner behavioral oracle/removal and current finite run; no alteration of fiscal law to make an unrelated diagnostic green"], "source_quality_receipt_ref": quality_ref},
        ]
        return result

    def report(self, index):
        lines = ["# F current35 scratch transfer proposal", "", "This is a source-bound draft for ROOT. Builder consistency is not independent acceptance, formal G closure, or production admission.", "", f"Root source `{self.root_sha}` / tree `{self.root_tree}`. Exact original denominator: 35 findings, 17 bundles, 36 card bindings (LA-016 is one finding with two bindings).", "", f"Proposed continuation states: `{json.dumps(index['summary']['outcome_counts'], sort_keys=True)}`. Receipt components and topics are counted from this registry, not inherited from frozen421.", "", "| ID | Original owner | Check proposal | Outcome proposal | Actual criterion/consumer |", "|---|---|---|---|---|"]
        for r in index["finding_rows"]:
            lines.append("| " + " | ".join(str(x).replace("|", "\\|").replace("\n", " ") for x in (r["finding_id"], r["primary_bundle"], r["check"], r["outcome"], r["criterion_short_ru"])) + " |")
        pending = index["pending_scientific_blockers"]
        lines += ["", "Publication checkpoints: `" + pending["status"] + "`. All per-ID check/outcome/remainder prose above comes from the explicit source-bound ROOT adjudication when supplied; otherwise it remains a proposal. Receipt publication alone changes no outcome.", "", "LA-003 historical precision FAIL and the later finite132 precision evidence remain on separate exact sources; actual component PASS/FAIL/ERROR streams and the ABM neighbor FAIL are preserved. LA-035 optimizer/intent is held until its real packet exists.", "", "B206 retains both DiD and RDD receipts. RDD upstream ancestry and runtime byte equality are reported separately. Full append history and defining-path hashes are in source-order.json; no staged patch is substituted for history.", "", "Known synthetic DGP/mathematical properties are separate from admitted real data. Whole Runtime Node authority/PDC semantic intake, actual common B56 competing workload/budget and selected local Lex law are UNRUN. Configured MethodJob/CAS/freshreader is bounded numerical consumer evidence.", "", "Old5cd installed PASS is source-only and supersedes oldab56; it is not a current combined-runtime PASS. Python3.14 DoWhy/EconML markers are not positive backend evidence. Historical FAIL/ERROR/SKIP and raw warning streams remain exact in component checks and Git transports.", "", "Current measured/material references are byte-verified. Historical175c provenance-only unavailable references keep historical/all-custody UNRUN. P41 inherited-red attribution remains not established. Formal G finding closure has not been issued.", "", "The separate prepared validator must review ROOT's immutable final publication. This builder does not claim to independently verify its own draft.", ""]
        return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", default="/workspace/e02-F-closeout-20261006")
    parser.add_argument("--root-sha", default="7185572917f7a3db5e93385a176cb611b35aff42")
    parser.add_argument("--draft", default="/tmp/e02-F-continuation-20261006/economics/docs-reconciliation/current35-doc-ledger-draft.json")
    parser.add_argument("--reconciliation", default="/tmp/e02-F-continuation-20261006/cau/original35-reconciliation.json")
    parser.add_argument("--outdir", default="/tmp/e02-F-continuation-20261006/root-ledger-draft")
    parser.add_argument("--extra-registry", help="JSON list of additional exact lane/head/path/hash receipt records; no automatic closure promotion")
    parser.add_argument("--root-adjudication", help="Explicit ROOT source-bound row decisions plus pending status; presence of extra receipts alone never changes outcomes")
    args = parser.parse_args()
    Builder(args).build()


if __name__ == "__main__":
    main()
