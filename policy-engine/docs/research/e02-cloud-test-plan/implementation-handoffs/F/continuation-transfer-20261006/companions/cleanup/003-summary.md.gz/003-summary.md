Read-only custody helper at root snapshot `613a55a5946bdeff2dc849f2488fb88c81b01360`, scientific source `8236d9c368336a5ea20c1586f29aea7321db6536`.

There are 63 exact existing conditional retired/reproducible candidates, 0 historical absent locators and 7 reclassified/non-actionable nominations. These are proposals only: publication release and inactive-user checks remain NOT_PERFORMED. Native Trash is unavailable; no move/delete/Git mutation/source edit occurred.

Root app `.venv`, current Python3.12 DoWhy worker, shared Git objects and both active cuDNN groups are protected. Historical mixed `root-input-binding`, `root-did-consumer`, `root-input-views` parents are preserved; only exact existing tmp/cache children are listed. All deciding output directories and the four semantic owner packets stay preserved.

Initial d5 archives and prepared sites have native UNRUN; final8236 archives/sites remain protected as actual deciding inputs. Final wheel and rebuilt-sdist each have199PASS,0FAIL/ERROR/SKIP and5 source-only deselections. All53 published encoded/decoded companions were verified from Git `a2d55a1942e1f56f35cf2b9772ae56b0b46de95d`; no remote release-for-cleanup check or numeric rerun was performed.
