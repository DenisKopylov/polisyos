from pathlib import Path
import hashlib,json,os,stat,subprocess,datetime,gzip
REPO=Path('/workspace/e02-F-closeout-20261006')
SNAPSHOT='613a55a5946bdeff2dc849f2488fb88c81b01360'
FROZEN='8236d9c368336a5ea20c1586f29aea7321db6536'
OLD='73f1e698f4271983ed8e83fba0314ca1f36b5a48'
INSTALLED='a2d55a1942e1f56f35cf2b9772ae56b0b46de95d'
PRE='policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/F/'
BASE=Path('/tmp/e02-F-continuation-20261006')
OUT=BASE/'economics/cleanup-input-custody'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(ref,path):return subprocess.check_output(['git','show',ref+':'+path],cwd=REPO)
def bind_file(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def bind_git(ref,path):
 b=git(ref,path);return {'git_ref':ref,'path':path,'git_blob':subprocess.check_output(['git','rev-parse',ref+':'+path],cwd=REPO,text=True).strip(),'bytes':len(b),'sha256':sha(b)}
def observation(p):
 p=Path(p);d={'path':str(p),'exists':p.exists(),'lexists':os.path.lexists(p)}
 if not os.path.lexists(p):return d
 s=p.lstat();d.update({'kind':'symlink' if p.is_symlink() else 'directory' if p.is_dir() else 'file','mode':oct(stat.S_IMODE(s.st_mode)),'resolved_path':str(p.resolve()),'lstat_inode':s.st_ino,'lstat_device':s.st_dev})
 if p.is_symlink():d['literal_symlink_target']=os.readlink(p)
 if p.is_file():d.update(bind_file(p))
 elif p.is_dir():d['directory_byte_census']='NOT_PERFORMED; existence/direct path inspection only, not an aggregate size claim'
 return d
paths=[p for p in subprocess.check_output(['git','ls-tree','-r','--name-only',SNAPSHOT,PRE],cwd=REPO,text=True).splitlines() if p.endswith('.json') and p.count('/')==PRE.count('/')]
manifest=[];fragments=[];documents={}
for p in paths:
 b=git(SNAPSHOT,p);manifest.append({'path':p,'bytes':len(b),'sha256':sha(b)});d=json.loads(b);documents[p]=d
 def walk(v,ptr):
  if isinstance(v,dict):
   for k,w in v.items():
    q=ptr+'/'+k.replace('~','~0').replace('/','~1')
    if any(t in k.lower() for t in ('cleanup','retired','trash')):fragments.append({'source':bind_git(SNAPSHOT,p),'json_pointer':q,'complete_value':w})
    elif isinstance(w,(dict,list)):walk(w,q)
  elif isinstance(v,list):
   for i,w in enumerate(v):
    if isinstance(w,(dict,list)):walk(w,ptr+'/'+str(i))
 walk(d,'')
oldpath=PRE+'final-transfer-20261006/cleanup-candidates.json';oldraw=git(OLD,oldpath);old=json.loads(oldraw)
(OUT/'historical-exact-cleanup-candidates.json').write_bytes(oldraw)
active={
 '/workspace/e02-F-closeout-20261006/policy-engine/.venv':'Current readonly Python3.14 app/dependency site explicitly configured in final installed8236 profile; historical nomination superseded.',
 '/workspace/e02-F-dowhy-20261006/policy-engine/workers/dowhy-014/.venv':'Current configured genuine Python3.12.14 DoWhy worker in final8236 app/installed profiles; current worker is not retired.',
 '/workspace/polisyos/.git/objects':'Active shared canonical Git-object path, symlink-preserved. No prune/rewrite/cleanup.',
 str(BASE/'active-git-objects'):'Active shared Git objects for all F source/topic receipts; lossless relocation was preservation.',
 str(BASE/'active-environment-relocation/cudnn-environment'):'Active root-cuDNN native library bytes; canonical env path remains linked.',
 str(BASE/'active-environment-relocation/cudnn-cache-archive'):'Active retained shared cuDNN cache/hardlink-group bytes, not a retired cache.',
}
candidates={};absent=[];reclassified=[]
def add(p,kind,basis,reason,precision=None):
 p=str(p);obs=observation(p)
 if p in active:
  reclassified.append({'historical_path':p,'source_basis':basis,'current_classification':'PRESERVE_ACTIVE_NOT_CLEANUP','reason':active[p],'observation':obs});return
 if not obs['lexists']:
  absent.append({'path':p,'historical_basis':basis,'status':'ABSENT_AT_READ_NOT_AN_EXISTING_CLEANUP_CANDIDATE'});return
 if p not in candidates:
  candidates[p]={'path':p,'kind':kind,'classification':'REPRODUCIBLE_OR_RETIRED_CANDIDATE_CONDITIONAL_ONLY','retirement':'NOT_ESTABLISHED; no claim of inactive users from age/name/path','source_basis':[],'reason':reason,'observed':obs,'currently':'NOT_PERFORMED','move_performed':False,'deletion_performed':False,'before_any_move':{'publication_and_lossless_readback':'NOT_PERFORMED_FOR_CLEANUP; Git source/receipt bindings below are navigation/custody only, not release to move','inactive_users_and_dependencies':'NOT_PERFORMED; owning root and all live users must affirm no dependency; inspect exe/cwd/open file/map descendants and symlink/hardlink/shared imports, current queued/running tools','unique_input_and_deciding_output_split':'NOT_PERFORMED; first prove all actual inputs reproducible from published source/recipe and every deciding byte preserved elsewhere; reject mixed parent directories','native_trash':'UNAVAILABLE; no substitute permanent deletion authorized'},'permitted_action_now':'NONE; retain exact path'}
 if basis not in candidates[p]['source_basis']:candidates[p]['source_basis'].append(basis)
 if precision:candidates[p]['native_scope']=precision
oldbasis=bind_git(OLD,oldpath)
for i,v in enumerate(old['candidates']):add(v['path'],v['kind'],{**oldbasis,'json_pointer':'/candidates/'+str(i)},'Historical exact conditional nomination; exists rechecked, current inactivity/publication-release not asserted.')
for f in fragments:
 v=f['complete_value'];p=f['source']['path']
 if not isinstance(v,dict):continue
 for key in ('exact_cleanup_candidates','cleanup_candidates_after_publication_and_inactive_user_check','candidates_after_publication_readback_and_inactive_use'):
  for i,loc in enumerate(v.get(key,[])):
   basis={'source':f['source'],'json_pointer':f['json_pointer']+'/'+key+'/'+str(i)}
   if not loc.startswith('/'):
    reclassified.append({'historical_locator':loc,'source_basis':basis,'current_classification':'NO_EXACT_PATH_UNALLOCATED_NOT_ACTIONABLE','reason':'No wildcard or broad directory inference is admitted.'});continue
   if loc in [str(BASE/x) for x in ('root-input-binding','root-did-consumer','root-input-views')]:
    reclassified.append({'historical_path':loc,'source_basis':basis,'current_classification':'PRESERVE_MIXED_PARENT_CONTAINS_DECIDING_OUTPUTS','reason':'Parent has complete receipts/stdout/stderr; narrow only existing synthetic tmp/cache child directories. Never move this parent as a unit.','observed':observation(loc)})
    q=Path(loc)
    if q.exists():
     for child in sorted(q.iterdir()):
      if child.is_dir() and child.name in ('tmp','tmp-corrected','cache','cache-corrected'):add(child,'repeatable synthetic CAS/test/cache fixture',basis,'Narrowed child of mixed historical parent; deciding receipt/stdout/stderr siblings preserved.')
   else:add(loc,'repeatable synthetic test/cache fixture',basis,'Exact current receipt conditional nomination; preserve complete deciding output siblings.')
# Initial d5 archives/sites are specifically superseded setup-only inputs, never native PASS.
d5=BASE/'api/installed-final-d5ae';cfg=json.loads((d5/'installed-config.json').read_bytes());setup=json.loads((d5/'initial-setup-build-and-pth-profile.json').read_bytes())
d5basis={'config':bind_file(d5/'installed-config.json'),'initial_setup':bind_file(d5/'initial-setup-build-and-pth-profile.json'),'source_sha':cfg['source_sha'],'source_tree':cfg['source_tree']}
for name,path in cfg['archives'].items():add(path,'superseded initial source/rebuilt build archive',d5basis,'Exact d5 source build artifact; later8236 archives replaced it before deciding native wave.',{'native_outcome':'UNRUN','basis':setup['scope'],'not_a_native_witness':True})
for name,path in cfg['installed_pythons'].items():add(Path(path).parent.parent,'superseded initial wheel/sdist installed test environment',d5basis,'Initial d5 site preparation only; product Python was not launched in either site according to initial setup record.',{'native_outcome':'UNRUN','product_python_not_launched':setup['sites'][name]['product_python_not_launched'],'not_a_native_witness':True})
for name in ('wheel-consumer','sdist-consumer','uv-cache'):
 add(d5/name,'superseded prepared carrier directory or private build cache',d5basis,'Initial d5 installed carrier/cache, not final8236 deciding output; no whole parent nomination.',{'native_outcome':'UNRUN','not_a_native_witness':True})
# Exact final profile inputs and deciding bytes remain protected.
final=BASE/'api/installed-final-8236';fcfg=json.loads((final/'installed-config.json').read_bytes());review_dir=BASE/'foundry/installed-final-wave/8236-review';review=json.loads((review_dir/'review.json').read_bytes());publication=json.loads((review_dir/'publication-git-readback.json').read_bytes());ipath=publication['primary']['path'];ib=git(INSTALLED,ipath);assert sha(ib)==publication['primary']['sha256'];installed=json.loads(ib)
protected=[]
for p,reason in active.items():protected.append({'path':p,'classification':'ACTIVE_NOT_CLEANUP','reason':reason,'observation':observation(p)})
for name,path in fcfg['archives'].items():protected.append({'path':path,'classification':'PRESERVE_FINAL_DECIDING_NATIVE_INPUT','reason':'Exact8236 installed profile input; build/archive identity must remain available for audit/G acceptance.','observation':observation(path)})
for name,path in fcfg['installed_pythons'].items():protected.append({'path':str(Path(path).parent.parent),'classification':'PRESERVE_CURRENT_FINAL_CONSUMER_ENVIRONMENT','reason':'Actual final8236 wheel/sdist199-case native run used this source-bound site; not the superseded d5 site.','observation':observation(Path(path).parent.parent)})
protected.extend([
 {'path':str(final),'classification':'PRESERVE_MIXED_FINAL_PROFILE_PARENT','reason':'Contains exact inputs, binding manifests, setup stdout/stderr and current sites; do not move parent.'},
 {'path':str(review_dir),'classification':'PRESERVE_DECIDING_OUTPUTS','reason':'Full final199/199 native outputs, warnings, negative/removal traces, preflight, import denominators and author-publication readback; no cleanup.'},
 {'path':str(BASE/'economics/base-source-archive'),'classification':'PRESERVE_SOURCE_ARCHIVE','reason':'Pinned Git source archive is source basis; source/doc directories expressly excluded from this cleanup task.','basis':bind_file(BASE/'economics/base-source-archive.json')},
 {'path':str(BASE/'economics/acceptance-owner-inputs'),'classification':'PRESERVE_UNIQUE_OWNER_INPUTS','reason':'Four semantic owner packets now root Git613 transport-bound; not regenerated synthetic outputs.'},
 {'path':str(BASE/'economics/fiscal-precision'),'classification':'PRESERVE_DECIDING_OUTPUTS_AND_OPERATOR_INPUTS','reason':'All real124PASS1ABMFAIL/full outputs, originalErrors/removals and lossless170MBscanner raw remain original custody; current task never nominates this mixed directory.'},
 {'path':'/workspace/e02-F-20261006-receipts','classification':'PRESERVE_MIXED_ORIGINAL_EVIDENCE_PARENT','reason':'Original unique deciding outputs/inputs live beside exact synthetic candidates; no parent move.'},
 {'path':'All tracked F source/docs/worktrees and all Git refs/registrations','classification':'PRESERVE_SOURCE_AND_HISTORY','reason':'No source-worktree cleanup, history rewrite, prune or production traversal.'},
 {'path':'Production data and locally retained full inputs outside this finite scope','classification':'PRESERVE_UNIQUE_LOCAL_INPUTS','reason':'No production paths enumerated/read/touched.'},
])
# Protected roots must never be nominated directly.
protected_paths={x['path'] for x in protected}
assert not protected_paths.intersection(candidates)
# Check actual declared final native outputs from Git, preserving FAIL/deselection context.
verified=[]
for c in installed['content_refs']:
 b=git(INSTALLED,c['path']);assert len(b)==c['bytes'] and sha(b)==c['sha256'];raw=b
 if c.get('format')=='lossless_utf8_output_json':
  x=json.loads(b)
  keys=[k for k,v in x.items() if isinstance(v,str) and len(v.encode('utf-8'))==c['original_bytes'] and sha(v.encode('utf-8'))==c['original_sha256']]
  assert len(keys)==1;raw=x[keys[0]].encode('utf-8')
 assert len(raw)==c['original_bytes'] and sha(raw)==c['original_sha256']
 verified.append({'git_ref':INSTALLED,**c,'encoded_and_decoded_git_readback':'PASS'})
# Source list is complete only for this defined188-top-level-JSON Git denominator; not whole scratch/host.
basis={'snapshot':SNAPSHOT,'snapshot_tree':subprocess.check_output(['git','rev-parse',SNAPSHOT+'^{tree}'],cwd=REPO,text=True).strip(),'frozen_root_source':FROZEN,'frozen_root_tree':subprocess.check_output(['git','rev-parse',FROZEN+'^{tree}'],cwd=REPO,text=True).strip(),'scope':'Full exact top-level F JSON set at snapshot plus literal historical cleanup receipt and named installed d5/8236 profiles; no broad/tmp/production census.','top_level_json_denominator':len(paths),'complete_top_level_json_manifest':manifest,'all_cleanup_key_fragments':fragments,'historical_exact_list':oldbasis,'d5_setup':{'bindings':d5basis,'complete_scope':setup['scope'],'sites':setup['sites']},'final8236':{'config':bind_file(final/'installed-config.json'),'setup_packet':bind_file(final/'final-consumer-packet.json'),'setup_snapshot_native_state':'UNRUN launch-ready snapshot remains historical; not overwritten into PASS','actual_deciding_review':bind_file(review_dir/'review.json'),'published_receipt':{**bind_git(INSTALLED,ipath),'local_git_readback':'PASS','remote_readback_by_this_helper':'NOT_PERFORMED'},'profiles':{p:{k:v.get(k) for k in ('check','passed','failed','errors','skipped','deselected','native_wall_seconds','loaded_product_origins','namespace_origin_violations','all_product_resource_files_unchanged_after_native_and_removal')} for p,v in review['profiles'].items()},'all53_actual_published_encoded_and_decoded_outputs':verified},'active_environment_preservation':{'plan':bind_file(BASE/'active-environment-relocation/plan.json'),'receipt':bind_file(BASE/'active-environment-relocation/receipt.json'),'git_storage_original_receipt':bind_file(BASE/'active-git-storage-relocation.json'),'meaning':'Both relocations preserved active data; explicitly not retired cleanup.'},'active_worker':{'pyvenv_config':bind_file('/workspace/e02-F-dowhy-20261006/policy-engine/workers/dowhy-014/.venv/pyvenv.cfg'),'version_info':'3.12.14 (read from pyvenv.cfg; no interpreter/native wave invoked)','configured_by_final_installed_profile':fcfg['worker_python']}}
(OUT/'source-basis.json').write_text(json.dumps(basis,ensure_ascii=False,indent=2)+'\n')
packet={'schema':'policyos.e02.cleanup_candidate_custody.v1','unit':'F','prepared_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'role':'read-only helper for root; proposed future candidate custody, not executed cleanup or scientific rerun','source_basis':bind_file(OUT/'source-basis.json'),'root_snapshot':SNAPSHOT,'root_scientific_source':FROZEN,'native_trash_available':False,'permanent_deletion_authorized':False,'git_prune_authorized':False,'currently':'NOT_PERFORMED','source_edit_performed':False,'git_mutation_performed':False,'moves_performed':False,'deletions_performed':False,'inactive_user_checks':'NOT_PERFORMED; do not equate native completion or historical nomination with inactive dependencies','publication_checks':'Actual final installed53 Git companions decoded and byte-verified for custody only; no remote/readback-release-before-move check performed','exact_existing_conditional_candidates':list(candidates.values()),'historical_absent_locators':absent,'reclassified_not_actionable_locators':reclassified,'protected_not_cleanup':protected,'before_any_move_sequence':['Owning root identifies exact single candidate and actual users; never choose a whole mixed scratch/worktree/env parent by its name.','Preserve and read back from published Git/approved custody every source, useful doc, unique input, deciding output and required environment/version/build recipe. Compare complete exact bytes/hash; local existence or summary is insufficient.','Confirm complete candidate content denominator has no unretained unique inputs/deciding outputs; explicitly resolve symlink/hardlink/imported shared dependency reuse.','Coordinate inactive-user check across all current tool/test processes, cached/queued interpreters and owner reservations. Current8236 sites/Git/cuDNN/3.12worker are protected regardless of age.','Use native Trash only when available and authorized. Here unavailable: every candidate remains in place; no permanent deletion substitute.','Before any future action create an exact path inventory/receipt and readback; record NOT_PERFORMED until actually done.'], 'limits':['No retirement is proven by directory name, source age, an older nomination or completion of native tests.','The exact188 JSON denominator is Git-F-navigation only; no host-wide absence, whole/tmp census or production input claim.','Initiald5 setup/build/nativeUNRUN is distinct from final8236 actual199PASSperprofile/5deselected/0skip; deciding negative FAIL and warning outputs preserved.','No G acceptance,35finding closure or new backend witness comes from this cleanup helper.'],'counts':{'existing_conditional_candidates':len(candidates),'historical_absent_locators':len(absent),'reclassified_not_actionable_locators':len(reclassified),'protected_rows':len(protected),'moves':0,'deletions':0}}
(OUT/'cleanup-candidates.json').write_text(json.dumps(packet,ensure_ascii=False,indent=2)+'\n')
(OUT/'summary.md').write_text(f'''Read-only custody helper at root snapshot `{SNAPSHOT}`, scientific source `{FROZEN}`.\n\nThere are {len(candidates)} exact existing conditional retired/reproducible candidates, {len(absent)} historical absent locators and {len(reclassified)} reclassified/non-actionable nominations. These are proposals only: publication release and inactive-user checks remain NOT_PERFORMED. Native Trash is unavailable; no move/delete/Git mutation/source edit occurred.\n\nRoot app `.venv`, current Python3.12 DoWhy worker, shared Git objects and both active cuDNN groups are protected. Historical mixed `root-input-binding`, `root-did-consumer`, `root-input-views` parents are preserved; only exact existing tmp/cache children are listed. All deciding output directories and the four semantic owner packets stay preserved.\n\nInitial d5 archives and prepared sites have native UNRUN; final8236 archives/sites remain protected as actual deciding inputs. Final wheel and rebuilt-sdist each have199PASS,0FAIL/ERROR/SKIP and5 source-only deselections. All53 published encoded/decoded companions were verified from Git `{INSTALLED}`; no remote release-for-cleanup check or numeric rerun was performed.\n''')
files=[bind_file(OUT/x) for x in ('cleanup-candidates.json','source-basis.json','historical-exact-cleanup-candidates.json','summary.md','build_packet.py')]
selection={'schema':'policyos.e02.transfer_selection.v1','role':'Full read-only cleanup candidate/custody packet and exact replayer; scratch only, no tracked publication by helper','files':files,'total_bytes':sum(x['bytes'] for x in files)}
(OUT/'transfer-selection.json').write_text(json.dumps(selection,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'counts':packet['counts'],'files':files,'selection':bind_file(OUT/'transfer-selection.json'),'total_bytes':selection['total_bytes']}))
