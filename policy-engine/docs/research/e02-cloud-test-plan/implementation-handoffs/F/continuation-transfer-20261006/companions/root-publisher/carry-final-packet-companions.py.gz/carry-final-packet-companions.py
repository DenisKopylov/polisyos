from pathlib import Path
import gzip, hashlib, json

repo=Path('/workspace/e02-F-closeout-20261006')
s=Path('/tmp/e02-F-continuation-20261006')
dest=repo/'policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/F/continuation-transfer-20261006/companions'
records=[]

def carry(p,q):
    b=p.read_bytes();q=dest/q
    q=q.with_name(q.name+'.gz') if len(b)>800 else q
    q.parent.mkdir(parents=True,exist_ok=True)
    assert not q.exists(),q
    e=gzip.compress(b,mtime=0) if len(b)>800 else b;q.write_bytes(e)
    r={'path':str(q.relative_to(repo)),'bytes':len(e),'sha256':hashlib.sha256(e).hexdigest(),
       'decoded_bytes':len(b),'decoded_sha256':hashlib.sha256(b).hexdigest(),'encoding':'gzip' if len(b)>800 else 'raw',
       'original_execution_path':str(p)}
    records.append(r)

for group,selection in [
    ('builder',s/'cau/final35-validator/transfer-selection-final-builder-8236.json'),
    ('cleanup',s/'economics/cleanup-input-custody/transfer-selection.json'),
    ('F-doc-review',s/'fit-final35-doc-review/transfer-selection-append.json')]:
    j=json.loads(selection.read_text());items=j.get('items',j.get('files'))
    for n,x in enumerate(items):
        p=Path(x.get('path',x.get('original_path')));b=p.read_bytes()
        assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256']
        carry(p,Path(group)/(str(n).zfill(3)+'-'+p.name))
    carry(selection,Path(group)/selection.name)
for group in ['root-final-native-merge','root-final-api-merge','root-final-publication-checkpoint','root-adjudication-publication','root-quality-publication']:
    for p in sorted((s/group).glob('*')):
        if p.is_file():carry(p,Path(group)/p.name)
for name in ['stage-current35-pack.py','carry-final-packet-companions.py','root-final-pack-staging.json']:
    carry(s/name,Path('root-publisher')/name)
transport={'schema':'policyos.e02.output_transport.v1','complete_companions':records,
           'role':'Full actual metadata builder outputs/errors/version bindings, independent doc review, final read-only checkpoint and exact conditional cleanup plan. No new scientific measurement or authority.',
           'canonical_vs_raw':'Seven raw scratch builder views are preserved as exact builder outputs. Canonical portable publication has its own hashes and independent frozen check; raw self-check is not independent acceptance.'}
(dest/'transport.json').write_text(json.dumps(transport,ensure_ascii=False,indent=2)+'\n')
for r in records:
    b=(repo/r['path']).read_bytes();assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']
    raw=gzip.decompress(b) if r['encoding']=='gzip' else b
    assert len(raw)==r['decoded_bytes'] and hashlib.sha256(raw).hexdigest()==r['decoded_sha256']
print(json.dumps({'full_companions':len(records),'encoded_bytes':sum(r['bytes'] for r in records),'decoded_bytes':sum(r['decoded_bytes'] for r in records)}))
