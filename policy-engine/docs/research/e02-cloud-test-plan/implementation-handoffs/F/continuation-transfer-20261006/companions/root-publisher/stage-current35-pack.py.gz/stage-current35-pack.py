from pathlib import Path
import collections, gzip, hashlib, json, subprocess, sys

repo=Path('/workspace/e02-F-closeout-20261006')
scratch=Path('/tmp/e02-F-continuation-20261006')
draft=scratch/'root-ledger-draft'
prefix=Path('policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/F')
relative=prefix/'continuation-transfer-20261006'
dest=repo/relative
decision_head=sys.argv[1]
decision_input=Path(sys.argv[2])
source='8236d9c368336a5ea20c1586f29aea7321db6536'
tree='724a77c88d4e6699ffead58a5e3e3990fb88640a'
decision_path=str(relative/'root-adjudication.json')
decision_raw=subprocess.check_output(['git','show',decision_head+':'+decision_path],cwd=repo)
assert decision_raw==decision_input.read_bytes()

def dump(p,j): p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
def ref(p):
 b=p.read_bytes();return {'path':str(p.relative_to(repo)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def portable(value):
 if isinstance(value,list):return [portable(v) for v in value]
 if not isinstance(value,dict):return value
 d={k:portable(v) for k,v in value.items()}
 p=d.get('path')
 if p==str(decision_input):
  d['path']=decision_path;d['head']=decision_head;d['git_ref']=decision_head
 elif isinstance(p,str) and p.startswith(str(draft)+'/'):
  name=Path(p).name
  if name in ['index.json','full-audit.json','artifact-transports.json','source-order.json','minimal-owner-packets.json','REPORT.md']:
   d['path']=str(relative/name)
 return d

index=portable(json.loads((draft/'index.json').read_text()))
audit=portable(json.loads((draft/'full-audit.json').read_text()))
transport=portable(json.loads((draft/'artifact-transports.json').read_text()))
order=portable(json.loads((draft/'source-order.json').read_text()))
packets=portable(json.loads((draft/'minimal-owner-packets.json').read_text()))
assert index['current_root_source_sha']==source and index['current_root_source_tree_sha']==tree
assert index['pending_scientific_blockers']['status']=='resolved'
assert len(index['finding_rows'])==35 and len(audit['rows'])==35
for collection in [index['finding_rows'],audit['rows']]:
 for r in collection:
  r['state_role']='Explicit F ROOT recommendation on original byte-bound criterion; separate technical profile and current continuation. G formal acceptance not issued.'
  r['canonical_owner_re_adjudication_required']='For unavailable semantic/institutional inputs only; source-bound ROOT decisions and independent reviews are carried separately.'
  assert r['ROOT_adjudication_ref']['head']==decision_head
audit['role']='Complete source-bound original35 evidence and F ROOT recommendations; all historical component check dispositions preserved'
index['role']='F ROOT current35 continuation ledger; recommendations only, not G applied closure'
index['publication_state']='F source and original35 decision frozen; independent frozen-packet custody review recorded in separate final receipt'
pending_notice={'check':'UNRUN at this immutable packet seal','resolution_receipt_path':str(prefix/'continuation-closeout-20261006.json'),
                'meaning':'The independent check must target these exact committed packet bytes; its later signed receipt is appended without changing scientific source.'}
index['independent_final_validation']=pending_notice
audit['independent_final_validation']=pending_notice
counts=collections.Counter(r['outcome'] for r in index['finding_rows'])
technical=collections.Counter(r['technical_original_criterion_recommendation'] for r in index['finding_rows'])
checks=collections.Counter(r['check'] for r in index['finding_rows'])
assert dict(counts)=={'closed':25,'limited':9,'held':1}
assert dict(technical)=={'closed':30,'limited':4,'held':1}
assert dict(checks)=={'PASS':33,'UNRUN':2}
index['summary']['technical_original_bounded_outcome_counts']=dict(technical)
index['summary']['actual_check_counts']=dict(checks)
index['summary']['counts_scope']='Current continuation outcomes and technical original bounded outcomes are separate, neither is G applied closure.'
order['transfer_carrier_history_through_adjudication']=[{'sha':h,'parents':subprocess.check_output(['git','show','-s','--format=%P',h],cwd=repo,text=True).strip().split(),
 'tree':subprocess.check_output(['git','rev-parse',h+'^{tree}'],cwd=repo,text=True).strip()} for h in subprocess.check_output(['git','log','--reverse','--topo-order','--format=%H',source+'..'+decision_head],cwd=repo,text=True).splitlines()]
dump(dest/'source-order.json',order)
dump(dest/'minimal-owner-packets.json',packets)
dump(dest/'artifact-transports.json',transport)
dump(dest/'full-audit.json',audit)
for name,key in [('full-audit.json','full_audit'),('artifact-transports.json','transports'),('source-order.json','source_order'),('minimal-owner-packets.json','minimal_owner_packets')]:
 index['complete_input_and_audit_refs'][key]=ref(dest/name)
per_id_refs=[]
for number,r in enumerate(index['finding_rows']):
 r['complete_audit_row_ref']={**ref(dest/'full-audit.json'),'json_pointer':'/rows/'+str(number)}
 full=audit['rows'][number];assert full['finding_id']==r['finding_id']
 p=dest/'per-ID'/ (r['finding_id']+'.json')
 dump(p,{'schema':'F-original-finding-continuation-receipt/1','unit':'F','source_sha':source,'source_tree':tree,
         'formal_G_acceptance':'not_issued','check_scope':'Actual bounded measurement is separate from unresolved original/current authority inputs.',
         'complete_original_bound_row':full,'independent_packet_review_resolution':pending_notice})
 pr=ref(p);per_id_refs.append(pr);r['current_per_ID_receipt']=pr
index['current_per_ID_receipts']=per_id_refs
dump(dest/'index.json',index)

def cell(x):return str(x).replace('|','\\|').replace('\n',' ')
lines=['# F — продолжение PR65: полный ledger 35 IDs','',
       'F рекомендует **25 closed / 9 limited / 1 held** для текущего продолжения; checks: **33 PASS / 2 UNRUN**. Это не запись о принятии G. Исходные bounded technical критерии отдельно: **30 closed / 4 limited / 1 held**.', '',
       f'Общий product source `{source}`, tree `{tree}`. Каждый численный receipt сохраняет свой отдельный implementation SHA/tree и полный output. Byte equality, ancestor или package install сами не переносят прежний PASS на новый candidate.', '',
       'Полный знаменатель: 35 IDs, 17 bundles, 36 оригинальных card bindings; LA-016 — один ID с двумя bindings. Original text/lines/bytes/owners, producer→artifact→bridge→consumer, oracle/negative и все component checks сохранены в full-audit.json, per-ID receipts и artifact-transports.json.', '',
       '| ID | Bundle | Исходный критерий и actual consumer | Code SHA | Check | Current outcome | Original bounded technical | Остаток / следующий owner |',
       '|---|---|---|---|---|---|---|---|']
for r in index['finding_rows']:
 remainder=r['original_criterion_remainder']
 if r['outcome'] in ['limited','held']:remainder=str(r['separate_unavailable_inputs_or_authority'])+'; '+str(r['next_owner'])
 code=r['implementation_sha']
 if r['finding_id']=='B206':code='DiD '+code+'; RDD fb022aa12599ee1617f83d154cd9a8027b2a58b8'
 if r['finding_id']=='B222':code+='; helper consumer 6f95f55ca7d9c5cd9489256a354a27da058b46b9'
 if r['finding_id'] in ['LA-007','LA-019','LA-020']:code+='; final consumers '+source
 values=[r['finding_id'],r['primary_bundle'],str(r['criterion_short_ru'])+' → '+str(r['actual_consumer']),code,r['check'],r['outcome'],r['technical_original_criterion_recommendation'],remainder]
 lines.append('| '+' | '.join(cell(v) for v in values)+' |')
lines+=['', 'Wheel и rebuilt-sdist на точном общем source: **199 PASS каждый**, 0 FAIL/ERROR/SKIP; пять source-census fixtures явно deselected и не входят в 199 PASS. Отдельный свежий census на source8236 имеет полный tracked/config/docs/loader denominator. Все восемь installed property-removal probes дали ожидаемый FAIL без ERROR/SKIP. 3459 files/site, семь worker resources и архивы совпали после прогонов. Python 3.14 consumer вызывал настоящий pinned Python 3.12 / DoWhy 0.14 worker; отсутствие DoWhy/EconML в 3.14 не backend witness.', '',
       'Исторические 14 runtime-warning memberships стали 0 на тех же real consumer cases. Все 90 предупреждений каждого текущего прогона сохранены: 30 LGBMClassifier и 60 LGBMRegressor feature-name warnings. Instrumentation warning и auxiliary classifier gap отражены отдельно.', '',
 'Общий quality: Ruff PASS на 92 paths; format FAIL на трёх вне F paths; schema FAIL на двух Core/IR Feedback snapshot paths; production-invocation FAIL с 26 regressions и 78 new unresolved, coverage partial. Полные deciding outputs и owner packets сохранены в source-quality-freeze receipt. **P41 not_established**: полный disjoint zero-overlap denominator не доказан. Канонический export parser оставляет 38 entrypoints UNKNOWN/incomplete FAIL; computed candidates не объявлены доказанными clients.', '',
 'Диагностика DiD теперь binds time_treatment/input/result basis и пересчитывается. Shared monitor проверяет normalized slots и отдельно raw sidecars; genuine missing/malformed slot остаётся red. Missing/fake/wrong identification basis не создаёт Confidence/value admission; accumulated causal blocker сохраняется при missing/corrupt simulation CAS. Fully specified static ADMG admission не пропускает tail-tail/circle/lagged profiles перед separation/rewrite. Эти property followups не назначены автоматически историческим IDs.', '',
 'LA-004 относится к distinct native/plugin fiscal/labor laws, а не Gini или welfare hold. LA-003 сохраняет original law/PatchMap/RNG/ABI с объявленной precision compatibility boundary: 30/40 whole patches совпадают по bytes, остальные dtype/reduction differences перечислены. LA-002 catalog/IC migration не требует неподготовленных family→state execution maps. LA-007/019 shadow files уже отсутствовали на base198; новая работа — реальные supported loaders/callers/docs/install, не повторное удаление. B222 — настоящий existing polynomial helper→typed manual payload→CAS→query/twin/fresh reader, без обещания нового default nonlinear fitter.', '',
 'Runtime/PDC semantic identity, genuine current verifier/context/challenge и whole admitted Node; B56 actual competing study workload/budget; A/C широкие policy/temporal graph inputs; LA-035 optimizer+normative intent; Lex current local NormPack/source/jurisdiction/effective-time/custody остаются точными минимальными owner packets. Production inputs не загружались, неизвестные refs не подставлены в команды. G — local/integration runner, не научный или институциональный owner.', '',
 'Historical175c provenance-only четыре недоступных refs остаются custody UNRUN; ни один из 35 deciding verdicts не опирается на них. Старый nondeciding RDD textual lint raw также unavailable UNRUN. Все source FAIL/ERROR/SKIP/UNRUN сохраняются. Check PASS означает измеренную указанную bounded property; не положительную authority admission и не успех всего original/current остатка.', '',
 'Git source-order сохраняет полную append-only upstream history, exact own commits/base/tree/dependency footprints. RDD upstream ancestor и byte equality разделены. Нет 160-path cumulative installed patch, rebase/reset/force/mainpush. Latest installed receipt supersedes old5cd/3dde для общего source; historical refs сохранены. После самостоятельной проверки frozen packet читать отдельный continuation-closeout receipt.', '',
 'Cloud native Trash отсутствует. Источники, документация, unique inputs и deciding outputs сохранены; exact reproducible cleanup candidates перечислены отдельно, permanent deletion не выполнялась.', '']
(dest/'REPORT.md').write_text('\n'.join(lines))
summary={'source_sha':source,'source_tree':tree,'decision_head':decision_head,'findings':35,'bundles':17,'card_bindings':36,
         'current_outcomes':dict(counts),'original_bounded_outcomes':dict(technical),'checks':dict(checks),
         'files':[ref(p) for p in sorted(dest.glob('*.json'))]+[ref(dest/'REPORT.md')]+per_id_refs}
dump(scratch/'root-final-pack-staging.json',summary)
print(json.dumps({k:v for k,v in summary.items() if k!='files'}))
