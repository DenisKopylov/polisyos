"""Assemble the read-only reviewer decision, retaining exact immutable input refs."""
import collections
import hashlib
import json
import pathlib
import subprocess

ROOT=pathlib.Path('/workspace/e02-F-closeout-20261006')
OUT=pathlib.Path('/tmp/e02-F-continuation-20261006/fit-final35-review')
SOURCE='8236d9c368336a5ea20c1586f29aea7321db6536'
TEMPLATE=OUT.parent/'root-ledger-draft/root-adjudication-template-8236.json'
def file_ref(path):
    path=pathlib.Path(path);data=path.read_bytes()
    return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def git_ref(ref,path):
    data=subprocess.check_output(['git','show',ref+':'+path],cwd=ROOT)
    return {'git_ref':ref,'path':path,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
            'git_blob':subprocess.check_output(['git','rev-parse',ref+':'+path],cwd=ROOT).decode().strip()}
template=json.loads(TEMPLATE.read_text())
bindings=json.loads((OUT/'input-bindings.json').read_text())
metadata=json.loads((OUT/'strict-template-audit.json').read_text())
decisions=json.loads((OUT/'semantic_decisions.json').read_text())
assert metadata['check']=='PASS' and len(decisions)==len(template['rows'])==35
assert set(decisions)=={row['finding_id'] for row in template['rows']}
rows=[]
for proposed in template['rows']:
    identifier=proposed['finding_id']
    review=decisions[identifier]
    rows.append({'finding_id':identifier,'check':proposed['check'],
        'current_continuation_outcome':proposed['outcome'],
        'technical_original_criterion_outcome':proposed['technical_original_criterion_recommendation'],
        'criterion_refs':[ref for ref in bindings['criteria'] if ref['finding_id']==identifier],
        'independent_criterion':review['criterion'],'independent_assessment':review['assessment'],
        'limits_and_missing_owner_inputs':review['limit'],'decision_basis':'independently_reconciled',
        'deciding_receipt_refs':proposed['deciding_receipt_refs'],
        'semantics':'Criterion-specific finite technical/code recommendation; not an institutional identification or G ledger admission.'})
current=dict(collections.Counter(row['current_continuation_outcome'] for row in rows))
original=dict(collections.Counter(row['technical_original_criterion_outcome'] for row in rows))
checks=dict(collections.Counter(row['check'] for row in rows))
assert current=={'closed':25,'limited':9,'held':1}
assert original=={'closed':30,'limited':4,'held':1}
assert checks=={'PASS':33,'UNRUN':2}
latest_inputs=OUT/'latest-published-inputs.json'
latest=json.loads(latest_inputs.read_text()) if latest_inputs.exists() else {'api_final_census_carrier':'pending'}
published=bool(latest.get('api_final_census_carrier') and latest.get('api_final_census_carrier')!='pending')
if published:
    foundry_ref=git_ref('a2d55a1942e1f56f35cf2b9772ae56b0b46de95d',
        'policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/F/installed-final-consumer-20261006.json')
    for row in rows:
        if row['finding_id'] in {'LA-007','LA-019','LA-020'}:
            row['deciding_receipt_refs'].extend([latest['api_primary'], foundry_ref])
            row['current_full_census_and_filename_basis']='Current immutable carrier90c72, entire decoded census/filename evidence and true installed consumer packet are bound in /current_installed_evidence; bounded API delivery precondition is met.'
review={'schema':'F-independent-final35-semantic-review/1','reviewer':'/root/fit_tmle',
    'candidate_source_sha':SOURCE,'candidate_tree_sha':bindings['candidate_tree'],
    'review_scope':'Read-only exact original criterion reconciliation and source-bound actual evidence review; no new product tests or tracked writes by this reviewer.',
    'verdict':'GO_BOUNDED' if published else 'GO_BOUNDED_PENDING_IMMUTABLE_API_DELIVERY',
    'formal_G_ledger_acceptance':False,'denominator':bindings['denominator'],
    'counts':{'current_continuation':current,'technical_original_criterion':original,'criterion_checks':checks},
    'count_caption':'25/9/1 describes the current continuation disposition. The original finite-criterion technical recommendations are 30/4/1. 33PASS/2UNRUN are per-ID bounded checks, not counts of all raw commands, failures or institutional admissions.',
    'inputs':{'strict_template':file_ref(TEMPLATE),'input_bindings':file_ref(OUT/'input-bindings.json'),
              'strict_metadata_audit':file_ref(OUT/'strict-template-audit.json'),
              'independent_semantic_decisions':file_ref(OUT/'semantic_decisions.json')},
    'current_installed_evidence':{'published_foundry_primary':git_ref('a2d55a1942e1f56f35cf2b9772ae56b0b46de95d',
        'policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/F/installed-final-consumer-20261006.json'),
        'native_profile_counts':{'wheel':{'selected':199,'passed':199,'skipped':0,'errors':0,'deselected':5,'sklearn_feature_name_warnings':90},
                                 'rebuilt_sdist':{'selected':199,'passed':199,'skipped':0,'errors':0,'deselected':5,'sklearn_feature_name_warnings':90}},
        'scope':'Actual isolated3.14 installed product imports, configured real3.12 worker, canonical MethodJob/CAS/fresh-I reader and monitor/confidence consumers. Five Git-dependent source-census tests were deselected, not promoted to backend witnesses.',
        'new_exact_source_census':file_ref(OUT.parent/'api/census-8236-full.json'),
        'filename_loader_classification':file_ref(OUT.parent/'api/filename-loader-8236-classification.json'),
        'publication':latest},
    'required_editorial_corrections':[
        {'id':'dual-count-caption','action':'Keep current continuation and original finite criterion recommendation separate; do not label25/9/1 as the original criterion closure total.'},
        {'id':'B213-exact-original-binding','action':'Name actual estimand_type/contrast/target-population and identify/estimate binding explicitly. Generic source/CAS equality is not this original estimand criterion.'},
        {'id':'LA003-global-red-attribution','action':'Replace an unqualified unrelated/inherited ABM red label with separately reported ABM diagnostic FAIL; preserve P41not_established. The bounded base replay is not a full denominator/disjointness proof.'},
        {'id':'B56-subproperty-versus-criterion','action':'Keep the whole common admitted-workload checkUNRUN even where the configured producer/fold/CAS subproperty hasPASS.'},
        {'id':'API-delivery','action':'Bind current8236 full census/loader classification and199×2 installed receipts to their real immutable Git carrier before final ROOT adoption. Do not replace with older548/5cd witnesses.'}],
    'retained_global_outcomes':{'ruff':'PASS','format':'FAIL','schema':'FAIL','production_invocation':'FAIL/partial',
        'production_invocation_counts':{'regressions':26,'new_unresolved':78},'P41':'not_established',
        'static_public_export_completeness':'FAIL:38UNKNOWN/incomplete; native finite facade proof does not repair this global predicate',
        'admitted_real_data_inference':'UNRUN','genuine_identification_issuer_verifier_bridge':'UNRUN',
        'actual_current_Runtime_Node_semantic_positive':'UNRUN','actual_common_admitted_study_budget_B56':'UNRUN'},
    'rows':rows,
    'read_and_binder_error_history':[
        'Earlier review navigation read used a criterion document key as a path; corrected lookup through criterion_documents without altering tracked inputs.',
        'Two guessed package-local README/public lifecycle filenames were absent; actual causal/README.md and maintained architecture docs were then read.',
        'Initial binder manifest bundle_id key causedKeyError; exact raw stderr plus initial replayer retained. Corrected actual schema keyid.',
        'Intermediate binder assumed an sdist collection-only sidecar; absent file ERROR retained. Actual sdist199 collection/call proof is in its native observer JSON; no missing output fabricated.',
        'An inline final-API metadata read used absent candidate_sha rather than actual candidate_source_sha. The tool traceback reportedKeyError before final binding; that initial inline raw stdout/stderr was not separately retained, so its standalone byte provenance is not_established. Corrected retained read_published_api.py and complete PASSstdout/stderr bind actual published bytes.',
        'All these are read/navigation harness errors, not product native outcomes, and they do not turn a missing observation intoPASS.'],
    'limits':[
        'Historical numerical components retain their exact candidate/environment receipts. This reviewer did not claim a repeated full4000-study RDD wave on8236.',
        'Known synthetic/DGP/graph computations are distinct from causal or legal inference on admitted production inputs.',
        'BaselinePython3.14 DoWhy/EconML marker absence is not a positive witness; selected real3.12 worker is a separate explicit supported profile, not a shim.',
        'Arbitrary computed/external filename/plugin clients are named unknowns and not assumed actual supported callers or absent clients.',
        'No new normative fiscal rounding, welfare target, estimator flag admission, authority enum, self-issued seal or scheduler is invented.',
        'Reviewer identity and content digest below record this technical review only; they are not causal identification or Runtime authority.']}
canonical=json.dumps(review,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
review['review_signature']={'reviewer':'/root/fit_tmle','scheme':'reviewer-attributed-canonical-json-sha256',
    'payload_sha256':hashlib.sha256(canonical).hexdigest(),'covered_payload':'Complete JSON with review_signature omitted',
    'authority':'Independent technical review attribution; no institutional issuer or cryptographic identity authority claimed.'}
(OUT/'review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'verdict':review['verdict'],'counts':review['counts'],'review':file_ref(OUT/'review.json')}))
