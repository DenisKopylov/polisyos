"""Read the strict candidate ledger; byte and RFC6901 pointer checks only."""
import collections
import hashlib
import json
import pathlib
import subprocess

ROOT=pathlib.Path('/workspace/e02-F-closeout-20261006')
SCRATCH=pathlib.Path('/tmp/e02-F-continuation-20261006/fit-final35-review')
TEMPLATE=SCRATCH.parent/'root-ledger-draft/root-adjudication-template-8236.json'
data=json.loads(TEMPLATE.read_text())
results=[]
errors=[]
def resolve(value, pointer):
    assert pointer.startswith('/')
    for token in pointer[1:].split('/'):
        token=token.replace('~1','/').replace('~0','~')
        value=value[int(token)] if isinstance(value,list) else value[token]
    return value
for row in data['rows']:
    for ref in row['deciding_receipt_refs']:
        payload=subprocess.check_output(['git','show',ref['head']+':'+ref['path']],cwd=ROOT)
        outcome={'finding_id':row['finding_id'],'ref':ref,'actual_bytes':len(payload),
                 'actual_sha256':hashlib.sha256(payload).hexdigest()}
        outcome['bytes_match']=outcome['actual_bytes']==ref['bytes']
        outcome['hash_match']=outcome['actual_sha256']==ref['sha256']
        if 'json_pointer' in ref:
            try:
                value=resolve(json.loads(payload),ref['json_pointer'])
                outcome['pointer']='PASS'
                outcome['selected_id']=value.get('id',value.get('finding_id')) if isinstance(value,dict) else None
            except (IndexError,KeyError,ValueError,AssertionError,TypeError) as error:
                outcome['pointer']='ERROR';outcome['error']=repr(error)
        if not outcome['bytes_match'] or not outcome['hash_match'] or outcome.get('pointer')=='ERROR':errors.append(outcome)
        results.append(outcome)
counts=collections.Counter(row['outcome'] for row in data['rows'])
checks=collections.Counter(row['check'] for row in data['rows'])
original=collections.Counter(row['technical_original_criterion_recommendation'] for row in data['rows'])
out={'schema':'F-independent-strict-template-audit/1','template':{'path':str(TEMPLATE),'bytes':TEMPLATE.stat().st_size,
    'sha256':hashlib.sha256(TEMPLATE.read_bytes()).hexdigest()},'candidate':data['root_source_sha'],
    'full_denominator':len(data['rows']),'proposed_current_counts':dict(counts),'proposed_original_counts':dict(original),
    'proposed_check_counts':dict(checks),'references':results,'errors':errors,'check':'FAIL' if errors else 'PASS',
    'scope':'Metadata byte/pointer and count audit only; scientific adequacy is adjudicated independently.'}
(SCRATCH/'strict-template-audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'check':out['check'],'refs':len(results),'errors':len(errors),'current':dict(counts),
    'original':dict(original),'checks':dict(checks)}))
