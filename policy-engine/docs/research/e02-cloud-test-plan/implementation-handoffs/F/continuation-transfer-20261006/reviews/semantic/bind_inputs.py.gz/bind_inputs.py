"""Read-only immutable semantic-review input binder; does not execute product tests."""
import csv
import argparse
import hashlib
import json
import pathlib
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--repository-root', default='/workspace/e02-F-closeout-20261006')
parser.add_argument('--output-directory', default='/tmp/e02-F-continuation-20261006/fit-final35-review')
args = parser.parse_args()
ROOT = pathlib.Path(args.repository_root)
OUT = pathlib.Path(args.output_directory)
OUT.mkdir(parents=True, exist_ok=True)
SOURCE = '8236d9c368336a5ea20c1586f29aea7321db6536'
CARRIER = '613a55a5946bdeff2dc849f2488fb88c81b01360'
PREFIX = 'policy-engine/docs/research/e02-cloud-test-plan/'
H = PREFIX + 'implementation-handoffs/F/'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

def binding(ref, path):
    data = git('show', f'{ref}:{path}')
    return {'git_ref': ref, 'path': path, 'git_blob': git('rev-parse', f'{ref}:{path}').decode().strip(),
            'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def read(ref, path):
    return json.loads(git('show', f'{ref}:{path}'))

coverage_path = PREFIX + 'closure-decisions/coverage.json'
owners_path = PREFIX + 'execution-organization/finding-owners.tsv'
manifest_path = 'policy-engine/docs/plans/active/agent-packages/PolicyOS_E02_Combined_Agent_Package/bundle_manifest.json'
coverage = read(SOURCE, coverage_path)
manifest = read(SOURCE, manifest_path)
rows = [x for x in coverage['findings'] if x['unit'] == 'F']
owners = list(csv.DictReader(git('show', f'{SOURCE}:{owners_path}').decode().splitlines(), delimiter='\t'))
owner_f = [x for x in owners if x['unit'] == 'F']
assert len(rows) == len(owner_f) == 35
assert {x['id'] for x in rows} == {x['finding_id'] for x in owner_f}
bundles = [x for x in coverage['bundles'] if x['unit'] == 'F']
assert len(bundles) == 17
manifest_index = {x['id']: x for x in manifest['bundles']}
criterion_bindings = []
for row in rows:
    for ref in row['criterion_refs']:
        path = coverage['criterion_documents'][ref['document']]['path']
        data = git('show', f'{SOURCE}:{path}')
        text = b''.join(data.splitlines(keepends=True)[ref['lines'][0]-1:ref['lines'][1]])
        assert hashlib.sha256(text).hexdigest() == ref['sha256']
        criterion_bindings.append({'finding_id': row['id'], **ref, 'source_document': binding(SOURCE, path),
                                   'selected_bytes': len(text), 'selected_sha256': hashlib.sha256(text).hexdigest()})
assert len(criterion_bindings) == 36
card_bindings = []
for row in bundles:
    m = manifest_index[row['id']]
    assert m['artifact_path'] == 'bundles/' + row['id'] + '.md'
    card_bindings.append({'bundle_id': row['id'], 'finding_ids': row['finding_ids'],
                          'source': binding(SOURCE, row['criterion_card'])})

primaries = [
    (CARRIER, 'did-selected-cohort-20261006.json'),
    (CARRIER, 'did-diagnostic-basis-20261006.json'),
    ('15a04c4400497374416e167a5f61ebc12f61b8e4', 'rdd-sharp-rbc-20261006.json'),
    ('c8c2319d6c48f23f90103322da8cd63bc959da6f', 'dowhy-worker-20261006.json'),
    (CARRIER, 'scm-source-bound-20261006.json'),
    (CARRIER, 'static-admg-profile-20261006.json'),
    (CARRIER, 'graph-cache-immutability-20261006.json'),
    (CARRIER, 'graph-intake-review-20261006.json'),
    (CARRIER, 'polynomial-helper-cas-20261006.json'),
    (CARRIER, 'scm-schema-version-20261006.json'),
    (CARRIER, 'tmle-20261006.json'),
    (CARRIER, 'tmle-common-report-20261006.json'),
    (CARRIER, 'tmle-selected-consumer-20261006.json'),
    (CARRIER, 'tmle-report-schema-20261006.json'),
    (CARRIER, 'causal-identification-candidates-20261006.json'),
    (CARRIER, 'causal-confidence-issue-preservation-20261006.json'),
    (CARRIER, 'treasury-execution-20261006.json'),
    (CARRIER, 'family-layout-consumers-20261006.json'),
    (CARRIER, 'economic-science-profiles-20261006.json'),
    (CARRIER, 'economics-continuation-20261006.json'),
    (CARRIER, 'economic-fiscal-precision-continuation-20261006.json'),
    (CARRIER, 'lex-input-binding.json'),
    (CARRIER, 'api-20261006.json'),
    (CARRIER, 'api-public-export-continuation-20261006.json'),
    (CARRIER, 'source-quality-freeze-20261006.json'),
]
receipt_bindings = []
for ref, name in primaries:
    path = H + name
    data = read(ref, path)
    checks = []
    for i, check in enumerate(data.get('checks', [])):
        checks.append({'index': i, 'name': check.get('name'), 'outcome': check.get('outcome'),
                       'target_sha': check.get('target_sha', check.get('source_sha')),
                       'command': check.get('command'), 'output': check.get('output'),
                       'output_ref': check.get('output_ref')})
    receipt_bindings.append({'name': name, 'source': binding(ref, path),
                             'candidate': data.get('candidate_source_sha', data.get('candidate_sha')),
                             'implementation_commits': data.get('implementation_commits'), 'checks': checks})

installed = pathlib.Path('/tmp/e02-F-continuation-20261006/foundry/installed-final-wave/8236-review')
SITE_CARRIER = 'a2d55a1942e1f56f35cf2b9772ae56b0b46de95d'
site_primary = read(SITE_CARRIER, H+'installed-final-consumer-20261006.json')
site_map = {entry['original_path']: entry for entry in site_primary['content_refs']}

def site_bytes(original_path):
    entry = site_map[str(original_path)]
    encoded = git('show', SITE_CARRIER+':'+entry['path'])
    assert len(encoded) == entry['bytes']
    assert hashlib.sha256(encoded).hexdigest() == entry['sha256']
    if entry['format'] == 'verbatim':
        raw = encoded
    elif entry['format'] == 'lossless_utf8_output_json':
        payload = json.loads(encoded)
        raw = payload['text'].encode('utf-8')
    else:
        raise ValueError(entry['format'])
    assert len(raw) == entry['original_bytes']
    assert hashlib.sha256(raw).hexdigest() == entry['original_sha256']
    return raw

installed_bindings = []
for profile in ['wheel', 'sdist']:
    for name in [profile+'-native.json', profile+'-native.stdout.txt', profile+'-native.stderr.txt',
                 profile+'-independent-consumer-proof.json',
                 profile+'-removals.json']:
        path = installed/name
        data = site_bytes(path)
        installed_bindings.append({'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    native = json.loads(site_bytes(installed/(profile+'-native.json')))
    proof = json.loads(site_bytes(installed/(profile+'-independent-consumer-proof.json')))
    assert native['source_sha'] == proof['source_sha'] == SOURCE
    assert native['source_tree'] == proof['source_tree'] == git('rev-parse', SOURCE+'^{tree}').decode().strip()
    assert native['exit_code'] == proof['pytest_exit'] == 0
    assert len(proof['collection']) == len(proof['test_reports']) == 199
    assert not proof['nonpassed_reports'] and not proof['namespace_origin_violations']
    assert len(proof['all_warnings']) == 90
    assert not proof['runtime_warnings']
collection = installed/'wheel-collection-denominator.json'
data = site_bytes(collection)
installed_bindings.append({'path': str(collection), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
assert len(json.loads(data)['deselected']) == 5

out = {'schema': 'F-independent-final35-input-bindings/1', 'reviewer': '/root/fit_tmle',
       'candidate_source_sha': SOURCE, 'candidate_tree': git('rev-parse', SOURCE+'^{tree}').decode().strip(),
       'receipt_anchor': CARRIER, 'denominator': {'original_findings': 35, 'criterion_bindings': 36, 'bundles': 17},
       'inputs': [binding(SOURCE, p) for p in [coverage_path, owners_path, manifest_path]],
       'criteria': criterion_bindings, 'bundles': card_bindings, 'receipts': receipt_bindings,
       'installed_observations': installed_bindings,
       'limits': ['No new product tests run by this semantic reviewer; source-bound existing measurements are read.',
                  'Installed current controls/raw bytes await their immutable publication locator; scratch is not G delivery.',
                  'No copied source-card bodies or full derived source inventories are emitted.']}
(OUT/'input-bindings.json').write_text(json.dumps(out, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({'check': 'PASS', 'denominator': out['denominator'], 'primary_receipts': len(receipt_bindings),
                  'installed_observations': len(installed_bindings), 'output': str(OUT/'input-bindings.json')}))
