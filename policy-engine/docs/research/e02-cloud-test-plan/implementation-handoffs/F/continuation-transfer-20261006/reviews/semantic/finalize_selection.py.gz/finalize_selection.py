"""Freeze unique reviewer outputs; refer to existing immutable evidence without recopy."""
import hashlib
import json
import pathlib

OUT=pathlib.Path('/tmp/e02-F-continuation-20261006/fit-final35-review')
def ref(path):
    path=pathlib.Path(path);data=path.read_bytes()
    return {'original_path':str(path),'relative_path':str(path.relative_to(OUT)),
            'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
review=json.loads((OUT/'review.json').read_text())
signature=review.pop('review_signature')
assert hashlib.sha256(json.dumps(review,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()==signature['payload_sha256']
assert review['verdict']=='GO_BOUNDED'
latest=json.loads((OUT/'latest-published-inputs.json').read_text())
names=[
 'review.json','semantic_decisions.json','strict-template-audit.json',
 'strict-template-audit.stdout.txt','strict-template-audit.stderr.txt','audit_template.py',
 'bind_inputs.py','bind_inputs_initial.py','bind_inputs_intermediate.py','bind_inputs_scratch_bound.py',
 'bind-inputs.stdout.txt','bind-inputs.stderr.txt','bind-inputs-corrected.stdout.txt',
 'bind-inputs-corrected.stderr.txt','bind-inputs-final.stdout.txt','bind-inputs-final.stderr.txt',
 'git-only-reconstruction.stdout.txt','git-only-reconstruction.stderr.txt','git-only-reconstruction-proof.json',
 'assemble_review.py','assemble-review-final.stdout.txt','assemble-review-final.stderr.txt',
 'read_published_api.py','published-api-readback.stdout.txt','published-api-readback.stderr.txt',
 'latest-published-inputs.json','finalize_selection.py'
]
files=[ref(OUT/name) for name in names]
derived=ref(OUT/'input-bindings.json')
selection={'schema':'F-independent-final35-transfer-selection/1','reviewer':'/root/fit_tmle',
    'candidate_source_sha':'8236d9c368336a5ea20c1586f29aea7321db6536',
    'verdict':'GO_BOUNDED','files':files,'unique_files':len(files),'unique_bytes':sum(a['bytes'] for a in files),
    'reconstruction_only':[{'original_path':derived['original_path'],'bytes':derived['bytes'],'sha256':derived['sha256'],
        'replayer':'bind_inputs.py','command':'python3 bind_inputs.py --repository-root <fetched-repository> --output-directory <unique-local-output>',
        'immutable_receipt_roots':['613a55a5946bdeff2dc849f2488fb88c81b01360','15a04c4400497374416e167a5f61ebc12f61b8e4','c8c2319d6c48f23f90103322da8cd63bc959da6f','a2d55a1942e1f56f35cf2b9772ae56b0b46de95d'],
        'source_sha':'8236d9c368336a5ea20c1586f29aea7321db6536',
        'reason':'Deterministic Git-derived35/36 criterion metadata and25primary check headers; all11sitepacket inputs decoded from existing Foundry immutable Git. Exact418258byte reconstruction was actually verified without/tmp input reads.',
        'proof':'git-only-reconstruction-proof.json','copy_to_Git':False}],
    'existing_git_files':[latest['api_primary'],latest['current_census'],latest['filename_loader'],
        review['current_installed_evidence']['published_foundry_primary']],
    'existing_evidence_scope':'FinalAPI90c72 commits full own115 outputs/census/setup/replayers and binds53Foundry companions ata2d55; use these complete existing byte sources without duplicating them.',
    'not_copied':'No original source card bodies, production inputs, generated views, archives, installed environments or whole source inventories copied by this reviewer.',
    'limits':'Review identity/contentdigest is technical attribution only; G formal acceptance/identification issuer/currentadmitted study budget remain separateUNRUN. First inline candidate_sha readerror rawbytes were not separately retained and are explicitlynot_established inreview.'}
(OUT/'transfer-selection.json').write_text(json.dumps(selection,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'check':'PASS','review':ref(OUT/'review.json'),'selection':ref(OUT/'transfer-selection.json'),
    'unique_files':len(files),'unique_bytes':selection['unique_bytes'],'reconstruction':derived}))
