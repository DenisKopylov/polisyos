"""Read actual final carrier bytes; no predicted Git heads or product executions."""
import gzip
import hashlib
import json
import pathlib
import subprocess

ROOT=pathlib.Path('/workspace/e02-F-closeout-20261006')
OUT=pathlib.Path('/tmp/e02-F-continuation-20261006/fit-final35-review')
REF='90c72b51155321684c788cd5a03fbb70fc001d53'
PREFIX='policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/F/'
FILES=[('api-installed-final-20261006.json',None),
       ('api-installed-final-20261006/author/census-8236-full.json.gz',OUT.parent/'api/census-8236-full.json'),
       ('api-installed-final-20261006/author/filename-loader-8236-classification.json.gz',OUT.parent/'api/filename-loader-8236-classification.json')]
actual=[]
for path,local in FILES:
    encoded=subprocess.check_output(['git','show',REF+':'+PREFIX+path],cwd=ROOT)
    entry={'git_ref':REF,'path':PREFIX+path,'bytes':len(encoded),'sha256':hashlib.sha256(encoded).hexdigest()}
    if local:
        raw=gzip.decompress(encoded)
        assert raw==local.read_bytes()
        entry.update(decoded_bytes=len(raw),decoded_sha256=hashlib.sha256(raw).hexdigest(),encoding='gzip-lossless')
    else:
        primary=json.loads(encoded)
        assert primary['candidate_source_sha']=='8236d9c368336a5ea20c1586f29aea7321db6536'
        assert primary['candidate_tree_sha']=='724a77c88d4e6699ffead58a5e3e3990fb88640a'
        assert primary['product_source_delta']==[]
        assert primary['closure_ids']==[]
        entry['candidate_source_sha']=primary['candidate_source_sha']
    actual.append(entry)
latest={'api_final_census_carrier':REF,'api_primary':actual[0],'current_census':actual[1],
        'filename_loader':actual[2],'readback_check':'PASS',
        'scope':'All primary and full decoded current census/filename bytes read directly from actual published immutable Git; product remains8236.',
        'ROOT_editorial_reconciliation':'Parent adopted explicit B213estimand binding and separately reported ABMFAIL/P41not_established captions; review recommendations are metadata-only.'}
(OUT/'latest-published-inputs.json').write_text(json.dumps(latest,indent=2)+'\n')
print(json.dumps({'check':'PASS','carrier':REF,'inputs':actual}))
