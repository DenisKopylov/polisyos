import sys,json,hashlib
from pathlib import Path
D=Path(__file__).parent;sys.path.insert(0,str(D/'source-5e3/policy-engine/src'))
from polisyos.core.artifacts.store import FileSystemCAS
from polisyos.ir.artifacts.contracts import StorePutOptions
from polisyos.ir.model_layer.canon import CanonSpec
from polisyos.ir.artifacts import put_json_artifact
from polisyos.ir.registry.refs import ProofBundleRef
from polisyos.ir.analytics.causal import load_proof_bundle
s=FileSystemCAS(D/'C08-independent-CAS-False')
rows=[]
for aid in s.iter_artifact_ids():
 m=s.get_manifest(aid)
 if m.kind=='ir.proof_bundle':
  payload=json.loads(s.get_bytes(aid))
  if payload.get('metadata',{}).get('partial_graph_query',{}).get('graph_payload_sha256')!='f'*64 and payload.get('graph_ref') and len(m.inputs)==1:
   try:p=load_proof_bundle(s,ProofBundleRef(artifact_id=aid))
   except ValueError:continue
   opts=StorePutOptions(kind='ir.proof_bundle',media_type='application/json',schema={'name':'ir.proof_bundle','version':'1.0'},inputs=[])
   core=s.put_json(payload,opts,CanonSpec(forbid_floats=False));selected=s.get_manifest(core)
   ir=ProofBundleRef.model_validate(put_json_artifact(s,payload,kind='ir.proof_bundle',schema_name='ir.proof_bundle',schema_version='1.0',inputs=[],canon_spec=CanonSpec(forbid_floats=False)))
   pp=load_proof_bundle(s,ir);default=s.get_manifest(ir.artifact_id)
   assert not selected.inputs and len(default.inputs)==1
   assert pp==p and core.manifest_profile_sha256 is not None
   rows.append({'core_selected_ref':core.model_dump(mode='json'),'ir_ref':ir.model_dump(mode='json'),'default_manifest':default.model_dump(mode='json'),'selected_manifest':selected.model_dump(mode='json'),'same_bytes_sha256':hashlib.sha256(s.get_bytes(aid)).hexdigest(),'reader_proof_status':pp.proof_status,'reader_authority_eligible':pp.metadata['partial_graph_query']['authority_eligible']})
assert len(rows)==1, len(rows)
(D/'C08-default-view-trace.json').write_text(json.dumps({'source':'5e3f2cdfe700186bec621d8b7e6ed48f8af6098d','rows':rows,'classification':'Observed selected-view loss at existing IR producer/reference boundary. Default fresh binding works; new selected lineage/currentness/admission UNRUN. This attempt does not establish a fresh default-reader counterexample.'},indent=2)+'\n');print(json.dumps({'rows':len(rows),'selected_view_loss_observed':True}))
