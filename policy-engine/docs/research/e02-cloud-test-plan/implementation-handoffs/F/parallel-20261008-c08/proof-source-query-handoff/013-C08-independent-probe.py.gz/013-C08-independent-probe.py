import os,sys,json,hashlib,subprocess,importlib.util
from pathlib import Path
from fractions import Fraction as F
from itertools import product
SCRATCH=Path(__file__).parent
ROOT=SCRATCH/'source-5e3/policy-engine'
SRC=ROOT/'src'
sys.path.insert(0,str(SRC))
spec=importlib.util.spec_from_file_location('fraction_oracle','/dev/shm/e02-orch03-20261008/producer-packets/native-id/fraction_oracle.py')
o=importlib.util.module_from_spec(spec);spec.loader.exec_module(o)
from polisyos.foundry.methods.catalog.causal.id_engine import id_algorithm,idc_algorithm
from polisyos.ir.analytics.causal_graph import CausalGraphModel,CausalEdge,GraphType,load_causal_graph_model,persist_causal_graph_model
from polisyos.foundry.methods.catalog.causal.causal_engine import CausalEngine
from polisyos.core.artifacts.store import FileSystemCAS
from polisyos.ir.analytics.causal import load_proof_bundle,persist_proof_bundle
from polisyos.ir.registry.refs import CausalGraphModelRef,ProofBundleRef
from polisyos.ir.artifacts import InputRef,put_json_artifact
from polisyos.ir.model_layer.canon import CanonSpec
rows=[]
for case in o.CASES:
 g=CausalGraphModel(graph_type=GraphType.DAG,nodes=case['order'],edges=[CausalEdge(src=p,dst=v) for v,ps in case['parents'].items() for p in ps])
 obs=o.joint(case)
 for outcomes in [['Y']]+([['Y','Z']] if 'Z' in case['order'] else []):
  r=id_algorithm(treatment=frozenset({'X'}),outcome=frozenset(outcomes),graph=g,dataset_ref='fraction-observed-law');a=r.estimand_ast
  assert a and a.treatment=='X' and set(a.all_variables)==set(g.nodes)
  vals=[]
  for x in (0,1):
   ints=o.joint(case,{'X':x})
   for bits in product((0,1),repeat=len(outcomes)):
    ev=dict(zip(outcomes,bits,strict=True));expected=o.conditional(ints,ev);actual=o.eval_ast(a.root,{'X':x,**ev},obs);assert actual==expected,(case['id'],outcomes,x,ev,actual,expected)
    vals.append({'x':x,'event':ev,'value':str(actual)})
  rows.append({'case':case['id'],'outcomes':outcomes,'query':a.query_str,'values':vals,'AST':a.root.model_dump(mode='json')})
 if case['id']=='collider_X_to_Z_from_Y':
  r=idc_algorithm(treatment=frozenset({'X'}),outcome=frozenset({'Y'}),conditions=frozenset({'Z'}),graph=g,dataset_ref='fraction-observed-law');a=r.estimand_ast
  assert a and a.treatment=='X'
  vals=[]
  for x,z,y in product((0,1),repeat=3):
   e=o.conditional(o.joint(case,{'X':x}),{'Y':y},{'Z':z});v=o.eval_ast(a.root,{'X':x,'Z':z,'Y':y},obs);assert v==e,(x,z,y,v,e);vals.append({'x':x,'z':z,'y':y,'value':str(v)})
  rows.append({'case':'collider_conditional_IDC','values':vals,'AST':a.root.model_dump(mode='json')})
# Actual engine owns producer, not hand-created report or proof.
graph_rows=[]
for common in (False,True):
 d=SCRATCH/('C08-independent-fresh-CAS-'+str(common));store=FileSystemCAS(d)
 g=CausalGraphModel(graph_type=GraphType.CPDAG,nodes=['X','Y','Z'] if common else ['X','Y'],edges=[CausalEdge(src='Y' if common else 'X',dst='Z' if common else 'Y',mark_dst='tail')])
 eng=CausalEngine(artifact_store=store);result=eng.identify('X','Y',g,dataset_ref='observed-law');audit=eng.audit(result,None,run_id='independent-review',graph=g)
 ref=audit.proof_bundle_ref;assert ref is not None
 fresh=FileSystemCAS(d);p=load_proof_bundle(fresh,ref);b=p.metadata['partial_graph_query'];assert b['authority_eligible'] is False
 assert b['disposition']==('common_functional' if common else 'conditional');assert load_causal_graph_model(fresh,CausalGraphModelRef(artifact_id=p.graph_ref))==g
 assert hashlib.sha256(fresh.get_bytes(p.graph_ref)).hexdigest()==b['graph_payload_sha256']
 assert [(str(i.artifact_id),i.role) for i in fresh.get_manifest(ref.artifact_id).inputs]==[(p.graph_ref,'causal_graph')]
 child_script="import sys,json,hashlib;from polisyos.core.artifacts.store import FileSystemCAS;from polisyos.ir.analytics.causal import load_proof_bundle;from polisyos.ir.analytics.causal_graph import load_causal_graph_model;from polisyos.ir.registry.refs import ProofBundleRef,CausalGraphModelRef;s=FileSystemCAS(sys.argv[1]);p=load_proof_bundle(s,ProofBundleRef.model_validate_json(sys.argv[2]));g=load_causal_graph_model(s,CausalGraphModelRef(artifact_id=p.graph_ref));assert g.model_dump(mode='json')==json.loads(sys.argv[3]);assert p.metadata['partial_graph_query']['authority_eligible'] is False;assert hashlib.sha256(s.get_bytes(p.graph_ref)).hexdigest()==p.metadata['partial_graph_query']['graph_payload_sha256'];print(json.dumps({'graph':g.model_dump(mode='json'),'basis':p.metadata['partial_graph_query'],'proof_status':p.proof_status}))"
 env={**os.environ,'PYTHONPATH':str(SRC)};c=subprocess.run([sys.executable,'-c',child_script,str(d),ref.model_dump_json(),g.model_dump_json()],env=env,text=True,capture_output=True)
 (SCRATCH/('C08-child-'+str(common)+'.stdout')).write_text(c.stdout);(SCRATCH/('C08-child-'+str(common)+'.stderr')).write_text(c.stderr);assert c.returncode==0,c.stderr
 negatives=[]
 other=persist_causal_graph_model(store,CausalGraphModel(graph_type=GraphType.DAG,nodes=['X','Y'],edges=[CausalEdge(src='Y',dst='X')]))
 for damage in ['stale_hash','wrong_ref','no_input','duplicate_input','wrong_input']:
  pp=p.model_copy(update={'metadata':{**p.metadata,'independent_review_nonce':damage}});ins=[InputRef(artifact_id=p.graph_ref,role='causal_graph')]
  if damage=='stale_hash':pp=pp.model_copy(update={'metadata':{**pp.metadata,'partial_graph_query':{**b,'graph_payload_sha256':'f'*64}}})
  if damage=='wrong_ref':pp=pp.model_copy(update={'graph_ref':str(other.artifact_id)})
  if damage=='no_input':ins=[]
  if damage=='duplicate_input':ins*=2
  if damage=='wrong_input':ins=[InputRef(artifact_id=other.artifact_id,role='causal_graph')]
  rr=ProofBundleRef.model_validate(put_json_artifact(store,pp.model_dump(mode='json'),kind='ir.proof_bundle',schema_name='ir.proof_bundle',schema_version='1.0',inputs=ins,canon_spec=CanonSpec(forbid_floats=False)))
  assert pp.proof_status==p.proof_status and pp.metadata['partial_graph_query']['authority_eligible'] is False
  try:load_proof_bundle(FileSystemCAS(d),rr)
  except (ValueError,FileNotFoundError) as e:negatives.append({'damage':damage,'error_type':type(e).__name__,'message':str(e),'ref':rr.model_dump(mode='json'),'retained_status':pp.proof_status})
  else:raise AssertionError('invalid reader accepted '+damage)
 graph_rows.append({'common':common,'result_status':result.status,'audit_status':audit.identification_status,'proof_ref':ref.model_dump(mode='json'),'graph_ref':p.graph_ref,'basis':b,'child_returncode':c.returncode,'negatives':negatives})
# Full actual origins bound to immutable export; dependency source audit is recorded below.
origins=[]
for name,m in sorted(sys.modules.items()):
 if name=='polisyos' or name.startswith('polisyos.'):
  f=getattr(m,'__file__',None)
  if f is not None:
   p=Path(f).resolve();assert p.is_relative_to(SRC),str(p);data=p.read_bytes();origins.append({'module':name,'path':str(p),'repo_path':'policy-engine/src/'+str(p.relative_to(SRC)),'sha256':hashlib.sha256(data).hexdigest()})
report={'source':'5e3f2cdfe700186bec621d8b7e6ed48f8af6098d','tree':'4065489cce119da0c7623464edbba37799d7550a','interpreter':sys.executable,'python':sys.version,'scope':'finite observed static DAG/IDC arithmetic and default fresh CAS original graph binding; no source-currentness or authority','Fraction_rows':rows,'graph_rows':graph_rows,'origins':origins,'state':'PASS'}
(SCRATCH/'C08-independent-probe.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'state':'PASS','Fraction_queries':len(rows),'graph_producers':len(graph_rows),'fresh_children':2,'reader_negatives':10,'source_origins':len(origins)}))
