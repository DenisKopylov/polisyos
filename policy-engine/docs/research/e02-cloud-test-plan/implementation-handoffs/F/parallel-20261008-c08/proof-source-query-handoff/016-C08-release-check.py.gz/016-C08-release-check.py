import sys,json,tomllib
from pathlib import Path
root=Path('/dev/shm/e02-orch03-20261008/oracle-ir/companion-962/policy-engine')
sys.path.insert(0,str(root))
from tools.ops_runners.release.check_compatibility_release_gates import _validate_fragments
policy=tomllib.loads((root/'architecture/gates/compatibility_release.toml').read_text())
fs=[]
for name in ['2026-10-08-c08-native-dag-query.toml','2026-10-08-c08-proof-source-binding.toml']:
 p=root/'release-fragments/unreleased'/name;f=tomllib.loads(p.read_text());f['__path__']=str(p.relative_to(root));fs.append(f)
e,ff=_validate_fragments(root,policy,fs,breaking_classes=('persisted-artifact-format',))
print(json.dumps({'source':'96258000e70847dcd1ec54607664e81c92bfa3d6','denominator':{'fragments':len(fs),'compatibility_rows':sum(len(f['compatibility_change']) for f in fs)},'errors':[x.as_dict() for x in e],'findings':[x.as_dict() for x in ff]},indent=2))
sys.exit(bool(e))
