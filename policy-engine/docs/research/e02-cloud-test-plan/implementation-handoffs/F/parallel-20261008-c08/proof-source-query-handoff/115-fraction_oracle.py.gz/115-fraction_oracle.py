"""Independent finite observed binary DAG arithmetic; not an ID algorithm.

Tables are declared SCM conditional laws, not admitted empirical data. The
observational law and manual truncated intervention law are enumerated with
Fraction. AST interpretation uses observational atoms and only dist/sum/product/
ratio nodes. No PolicyOS module contributes to expected arithmetic.
"""
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path

CASES = [
 {"id":"isolated_X_Z_to_Y", "order":["X","Z","Y"], "parents":{"X":[],"Z":[],"Y":["Z"]}, "p1":{"X":{"":"1/3"},"Z":{"":"3/4"},"Y":{"0":"1/10","1":"9/10"}}},
 {"id":"isolated_X_changed_Z_prior", "order":["X","Z","Y"], "parents":{"X":[],"Z":[],"Y":["Z"]}, "p1":{"X":{"":"1/3"},"Z":{"":"1/4"},"Y":{"0":"1/10","1":"9/10"}}},
 {"id":"fork_Z_to_X_Y", "order":["Z","X","Y"], "parents":{"Z":[],"X":["Z"],"Y":["Z"]}, "p1":{"Z":{"":"2/5"},"X":{"0":"1/4","1":"3/4"},"Y":{"0":"1/5","1":"4/5"}}},
 {"id":"collider_X_to_Z_from_Y", "order":["X","Y","Z"], "parents":{"X":[],"Y":[],"Z":["X","Y"]}, "p1":{"X":{"":"1/3"},"Y":{"":"3/5"},"Z":{"00":"1/10","01":"1/2","10":"3/5","11":"9/10"}}},
 {"id":"mediator_X_to_M_to_Y", "order":["X","M","Y"], "parents":{"X":[],"M":["X"],"Y":["M"]}, "p1":{"X":{"":"1/3"},"M":{"0":"1/4","1":"3/4"},"Y":{"0":"1/5","1":"4/5"}}},
 {"id":"fork_plus_direct_X_to_Y", "order":["Z","X","Y"], "parents":{"Z":[],"X":["Z"],"Y":["X","Z"]}, "p1":{"Z":{"":"2/5"},"X":{"0":"1/4","1":"3/4"},"Y":{"00":"1/10","01":"3/10","10":"3/5","11":"4/5"}}},
]

def joint(case, intervention=None):
    intervention = intervention or {}
    rows=[]
    for bits in product((0,1), repeat=len(case['order'])):
        assignment=dict(zip(case['order'],bits,strict=True));w=F(1)
        for v in case['order']:
            if v in intervention:
                w *= int(assignment[v]==intervention[v]);continue
            parent_key=''.join(str(assignment[p]) for p in case['parents'][v])
            p=F(case['p1'][v][parent_key]);assert F(0)<p<F(1)
            w*=p if assignment[v] else 1-p
        rows.append((assignment,w))
    assert sum(w for _,w in rows)==1
    return rows

def event_probability(rows, event):
    return sum((w for a,w in rows if all(a[k]==v for k,v in event.items())),F(0))

def conditional(rows,event,given=None):
    given=given or {}
    if any(k in given and given[k]!=v for k,v in event.items()):return F(0)
    den=event_probability(rows,given)
    if not den:raise ValueError('unsupported zero-probability conditioning event')
    return event_probability(rows,{**given,**event})/den

def eval_ast(node, assignment, observational_rows):
    """Interpret observational symbolic arithmetic, without identifying a query."""
    if not isinstance(node,dict):node=node.model_dump(mode='json')
    kind=node['node_type']
    if kind=='dist':
        if node.get('intervention_set') or node.get('event') is not None:
            raise ValueError('oracle supports observational probability atoms only')
        event={v:assignment[v] for v in node['variables']}
        given={v:assignment[v] for v in node.get('conditioning',[])}
        return conditional(observational_rows,event,given)
    if kind=='sum':
        vs=node['summation_vars'];total=F(0)
        for bits in product((0,1),repeat=len(vs)):
            total+=eval_ast(node['operand'],{**assignment,**dict(zip(vs,bits,strict=True))},observational_rows)
        return total
    if kind=='product':
        value=F(1)
        for factor in node['factors']:value*=eval_ast(factor,assignment,observational_rows)
        return value
    if kind=='ratio':
        numerator=eval_ast(node['numerator'],assignment,observational_rows)
        denominator=eval_ast(node['denominator'],assignment,observational_rows)
        if not denominator:raise ValueError('zero AST denominator')
        return numerator/denominator
    raise ValueError('oracle unsupported AST node '+kind)

def law(rows, outcomes, given=None):
    result={}
    for bits in product((0,1),repeat=len(outcomes)):
        event=dict(zip(outcomes,bits,strict=True));result[''.join(map(str,bits))]=str(conditional(rows,event,given))
    assert sum(F(v) for v in result.values())==1
    return result

def report():
    expected={'isolated_X_Z_to_Y':('7/10','7/10'),'isolated_X_changed_Z_prior':('3/10','3/10'),'fork_Z_to_X_Y':('11/25','11/25'),'collider_X_to_Z_from_Y':('3/5','3/5'),'mediator_X_to_M_to_Y':('7/20','13/20'),'fork_plus_direct_X_to_Y':('9/50','17/25')}
    rows=[]
    for case in CASES:
        obs=joint(case); inter={x:joint(case,{'X':x}) for x in (0,1)}
        y={x:conditional(inter[x],{'Y':1}) for x in (0,1)}
        assert tuple(str(y[x]) for x in (0,1))==expected[case['id']]
        row={'case':case['id'],'declared_cpt':case,'P_Y1_do_X0':str(y[0]),'P_Y1_do_X1':str(y[1]),'contrast':str(y[1]-y[0]),'Y_laws':{str(x):law(inter[x],['Y']) for x in (0,1)},'observational_Y1_given_X1':str(conditional(obs,{'Y':1},{'X':1}))}
        if 'Z' in case['order']:
            row['YZ_joint_do_X']={str(x):law(inter[x],['Y','Z']) for x in (0,1)}
        if case['id']=='collider_X_to_Z_from_Y':
            row['conditional_interventional_Y1_given_Z1']={str(x):str(conditional(inter[x],{'Y':1},{'Z':1})) for x in (0,1)}
            assert row['conditional_interventional_Y1_given_Z1']=={'0':'15/17','1':'9/13'}
        rows.append(row)
    return {'schema':'policyos.e02.independent_fraction_static_dag_oracle.v1','scope':'Six declared finite positive observed binary DAGs; independent enumeration. No latent ID/PAG/temporal completeness, empirical/source rights or scientific admission.','oracle_state':'PASS independent Fraction arithmetic, not native producer PASS','rows':rows,'query_invariants':['Original requested treatment X/outcome Y/query survives dropping causally irrelevant X from computational factorization.','P(Y|do(X)) marginalizes all nuisance variables, not P(Y|parents(Y)) with free parent.','Treatment is fixed, never summed over or assigned an observational P(X) factor.','Joint outcome(Y,Z) retains Z; summing joint over Z matches marginal Y.','Collider conditional-interventional query is separate from unconditional target; positive conditional probability is not unconditioned causal effect.'],'native_AST_scope':'Only observational DistributionRef + SumNode/ProductNode/RatioNode over binary variables; missing free assignments or unsupported/interventional atom refuses in oracle. Expected values never read from native AST.'}

if __name__=='__main__':
    p=Path(__file__).with_name('fraction-tables.json');p.write_text(json.dumps(report(),indent=2)+'\n');print(p)
