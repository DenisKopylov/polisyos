import hashlib, json, os, resource, subprocess, sys, time
from pathlib import Path
label=sys.argv[1]
command=sys.argv[2:]
scratch=Path('/dev/shm/e02-orch03-20261008/c08-scratch')
out=scratch/(label+'.stdout'); err=scratch/(label+'.stderr')
start=time.monotonic()
with out.open('wb') as stdout, err.open('wb') as stderr:
    child=subprocess.Popen(command, stdout=stdout, stderr=stderr)
    _, status, usage=os.wait4(child.pid,0)
    returncode=os.waitstatus_to_exitcode(status)
    child.returncode=returncode
result={'label':label,'source_sha':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),'cwd':str(Path.cwd()),'argv':command,'returncode':returncode,'wall_seconds':time.monotonic()-start,'max_rss_kib':usage.ru_maxrss,'environment':{key:os.environ.get(key) for key in ('PYTHONPATH','PYTHONDONTWRITEBYTECODE','LANG')},'outputs':{str(path):{'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()} for path in (out,err)}}
(scratch/(label+'.json')).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
print(out.read_text()[-1800:])
print(err.read_text()[-1000:])
sys.exit(returncode)
