import ast, hashlib, inspect, json, sys
from pathlib import Path
import pytest

kind=sys.argv[1]
scratch=Path('/dev/shm/e02-orch03-20261008/c08-scratch')
if kind=='graph-hash':
    from polisyos.ir.analytics import causal as owner
    original=inspect.getsource(owner._partial_proof_graph_input)
    removed=original.replace('    if actual_bytes_hash != expected or typed_payload_hash != expected:\n        raise ValueError("Partial graph proof original graph content does not match its basis.")\n','')
    assert original!=removed
    code=compile(removed, '<runtime-property-removal:exact-source-graph-hash>', 'exec')
    exec(code, owner.__dict__)
    selectors=['policy-engine/tests/unit/ir/analytics/test_causal_proof_graph_binding.py::test_fresh_reader_refuses_retained_marker_proof_with_wrong_graph_or_lineage[stale_hash]']
else:
    from polisyos.foundry.methods.catalog.causal import id_engine as facade
    from polisyos.foundry.methods.catalog.causal.id_engine import core as owner
    original=inspect.getsource(owner.id_algorithm)
    start=original.index('    # Preserve the requested query before recursive ancestral shortcuts')
    end=original.index('    # ------------------------------------------------------------------\n    # Step 1:',start)
    removed=original[:start]+original[end:]
    exec(compile(removed,'<runtime-property-removal:exact-native-DAG-query>','exec'),owner.__dict__)
    facade.id_algorithm=owner.id_algorithm
    selectors=['policy-engine/tests/unit/foundry/methods/catalog/causal/test_id_engine_native_query_marginal.py::test_isolated_treatment_keeps_original_query_and_marginalizes_outcome_parent']
(scratch/(kind+'-property-original.py')).write_text(original)
(scratch/(kind+'-property-removed.py')).write_text(removed)
(scratch/(kind+'-property-input.json')).write_text(json.dumps({'kind':kind,'harness':'delete only exact runtime source guard using its maintained globals; immutable tracked candidate is unchanged','original_function_sha256':hashlib.sha256(original.encode()).hexdigest(),'removed_function_sha256':hashlib.sha256(removed.encode()).hexdigest(),'markers_kept':True,'selector':selectors},indent=2)+'\n')
raise SystemExit(pytest.main(['-o','addopts=','-o','cache_dir='+str(scratch/(kind+'-removal-cache')),'--import-mode=importlib','--basetemp',str(scratch/(kind+'-removal-temp')),'--junitxml',str(scratch/(kind+'-removal.xml')),'-v',*selectors]))
