import hashlib,json,os,subprocess,sys
from pathlib import Path
from polisyos.core.artifacts.store import FileSystemCAS
from polisyos.foundry.methods.catalog.causal.causal_engine import CausalEngine
from polisyos.ir.analytics.causal_graph import CausalGraphModel,CausalEdge,GraphType

child_source="""
import hashlib,json,os,sys
from polisyos.core.artifacts.store import FileSystemCAS
from polisyos.ir.analytics.causal import load_proof_bundle
from polisyos.ir.analytics.causal_graph import load_causal_graph_model
from polisyos.ir.registry.refs import ProofBundleRef,CausalGraphModelRef
store=FileSystemCAS(sys.argv[1])
ref=ProofBundleRef.model_validate_json(sys.argv[2])
proof=load_proof_bundle(store,ref)
graph=load_causal_graph_model(store,CausalGraphModelRef(artifact_id=proof.graph_ref))
assert graph.model_dump(mode='json')==json.loads(sys.argv[3])
basis=proof.metadata['partial_graph_query']
actual=hashlib.sha256(store.get_bytes(proof.graph_ref)).hexdigest()
assert actual==basis['graph_payload_sha256']
lineage=store.get_manifest(ref.artifact_id).inputs
assert [(str(i.artifact_id),i.role) for i in lineage]==[(proof.graph_ref,'causal_graph')]
assert basis['authority_eligible'] is False
print(json.dumps({'child_pid':os.getpid(),'proof_ref':str(ref.artifact_id),'graph_ref':proof.graph_ref,'graph_payload_sha256':actual,'disposition':basis['disposition'],'proof_status':proof.proof_status,'original_graph_matches':True,'lineage_matches':True,'authority_eligible':False}))
"""
results=[]
for common in [False,True]:
    graph=CausalGraphModel(graph_type=GraphType.CPDAG,nodes=['X','Y','Z'] if common else ['X','Y'],edges=[CausalEdge(src='Y' if common else 'X',dst='Z' if common else 'Y',mark_dst='tail')])
    store=FileSystemCAS(Path('/dev/shm/e02-orch03-20261008/c08-scratch/bound-proof-child')/str(common))
    engine=CausalEngine(artifact_store=store)
    result=engine.identify('X','Y',graph,dataset_ref='configured-synthetic-observed-law')
    audit=engine.audit(result,None,run_id='configured-c08-proof-source-'+str(common),graph=graph)
    run=subprocess.run([sys.executable,'-c',child_source,str(store.root),audit.proof_bundle_ref.model_dump_json(),graph.model_dump_json()],capture_output=True,text=True)
    print(json.dumps({'common':common,'returncode':run.returncode,'stdout':run.stdout,'stderr':run.stderr}))
    assert run.returncode==0
    readback=json.loads(run.stdout.splitlines()[-1]); assert readback['child_pid']!=os.getpid()
    results.append({'parent_pid':os.getpid(),'store_root':str(store.root),'result_status':result.status.value,'readback':readback})
Path('/dev/shm/e02-orch03-20261008/c08-scratch/proof-child-readback.json').write_text(json.dumps(results,indent=2)+'\n')
