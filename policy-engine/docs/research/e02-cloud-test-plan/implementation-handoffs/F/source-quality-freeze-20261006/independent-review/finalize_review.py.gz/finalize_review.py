"""Freeze measured read-only review and complete transport selection without re-running tests."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parent
ROOT = Path('/workspace/e02-F-closeout-20261006')
AUTHOR = Path('/tmp/e02-F-continuation-20261006/root-format-forward')
QUALITY = Path('/tmp/e02-F-continuation-20261006/root-final-quality')
SHA = '8236d9c368336a5ea20c1586f29aea7321db6536'

def ref(path):
    body = path.read_bytes()
    return {'path': str(path), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}

def blob(path):
    return subprocess.check_output(['git', 'show', SHA + ':' + path], cwd=ROOT)

review_path = OUT / 'independent-source-review.json'
review = json.loads(review_path.read_bytes())
assert review['check'] == 'PASS' and review['candidate_sha'] == SHA
for run in review['collection_comparison']['runs']:
    measured = run.pop('node_ids', None)
    if measured is not None:
        run['case_ID_sequence_sha256'] = hashlib.sha256(
            ('\n'.join(measured) + '\n').encode()
        ).hexdigest()
assert len({run['case_ID_sequence_sha256'] for run in review['collection_comparison']['runs']}) == 1
review['complete_changed_source_bindings'] = []
for path in review['changed_paths']:
    body = blob(path)
    review['complete_changed_source_bindings'].append(
        {'source_sha': SHA, 'source_path': path, 'bytes': len(body),
         'sha256': hashlib.sha256(body).hexdigest()}
    )
review['review_interpreter'] = {'executable': sys.executable, 'version': sys.version}
review['author_native_execution']['spec_ref'] = ref(AUTHOR / 'spec.json')
review['provenance_disposition'] = {
    'providers': ['id_engine/core.py', 'id_engine/counterfactual.py', 'ir/analytics/causal_graph.py'],
    'ownership': 'Existing F provider leases; only own518/e2 changes since198 throughd5.',
    'style_origin': 'These exact formatting hunks also reproduce on original198; do not attribute introduction to F.',
    'P41': 'not_established; historical scoped replay is not full disjoint-input proof',
}
review['broader_quality'] = {
    'check': 'FAIL', 'source_sha': 'd5ae668fe6079bfa81bd7448aa911fa4bee4e03b',
    'complete_path_denominator': 92, 'original_formatter_failures': 11,
    'already_formatted': 81,
    'current_scope_note': '8 Ruff formatter changes plus1 import separation;3outsideF remain outside this lease.',
    'receipt_ref': ref(QUALITY / 'format.receipt.json'),
    'outputs': [ref(QUALITY / 'format.stdout.txt'), ref(QUALITY / 'format.stderr.txt')],
    'P41': 'not_established',
}
review['reviewer_coverage'] = {
    'full_git_diff_read': {'changed_path_denominator': 11, 'python_path_denominator': 9,
                           'doc_release_companions': 2},
    'AST_normalization': 'Only ast.TypeIgnore.lineno source coordinate (tags retained); only single pytest argnames string/tuple syntax-equivalence.',
    'negative_controls_check': 'PASS',
    'negative_control_comparison_outcomes': ['FAIL as expected: changed literal retains markers',
                                            'FAIL as expected: reordered two-name tuple retains markers'],
    'no_new_numerical_runtime_wave': True,
}
review_path.write_text(json.dumps(review, indent=2) + '\n')
summary = (
    'GO_BOUNDED exact8236d9c368336a5ea20c1586f29aea7321db6536 / tree724a77c88d4e6699ffead58a5e3e3990fb88640a.\n'
    'All11changed paths read;9Python paths independently measured.8full ASTs identical;sole pytest argname declaration equivalent.\n'
    '108actual caseIDs identical in before/after collection;fresh frozen source823 author native108PASS0FAIL/SKIP/ERROR.\n'
    'Independent scoped Ruff9 lint/format and canonical1internal/compatible fragment PASS.\n'
    'Changed-literal and reordered-name counterfeit comparisons FAIL as required; source/markers retained.\n'
    'Three graph providers lie in actual F leases;exact style hunks also observed on198,so introduction attribution not established.\n'
    'Original92formatFAIL and3outsideFtargets remain bounded nonPASS;P41not_established.\n'
    'Source-bound publicinventory must re-render;old installed/numerical receipts remain source-specific.No new scientific closure.\n'
)
(OUT / 'review.txt').write_text(summary)

selected = [review_path, OUT / 'review.txt', OUT / 'review_source.py', Path(__file__),
            OUT / 'provenance.json', OUT / 'provenance-corrected.py', OUT / 'provenance.py',
            OUT / 'initial-type-ignore-location-harness.stdout.txt',
            OUT / 'initial-type-ignore-location-harness.stderr.txt',
            OUT / 'fragment-validation.json', OUT / 'fragment-rendered.md']
for label in ['base-d5ae', 'candidate-8236']:
    selected += [OUT / f'{label}-collection.stdout.txt', OUT / f'{label}-collection.stderr.txt']
for label in ['independent-ruff', 'independent-format']:
    selected += [OUT / f'{label}.stdout.txt', OUT / f'{label}.stderr.txt']
for name in ['core.py', 'counterfactual.py', 'causal_graph.py']:
    for label in ['base198', 'currentd5']:
        selected += [OUT / f'{name}.{label}.formatted.txt', OUT / f'{name}.{label}.stderr.txt']
selected += [AUTHOR / 'spec.json', AUTHOR / 'AST-proof.json']
for label in ['native-api', 'frozen-native-api']:
    selected += [AUTHOR / f'{label}.xml', AUTHOR / f'{label}.stdout.txt', AUTHOR / f'{label}.stderr.txt']
selected += [QUALITY / 'format.receipt.json', QUALITY / 'format.stdout.txt', QUALITY / 'format.stderr.txt']
assert len(selected) == len(set(selected))
items = []
for path in selected:
    relative = path.relative_to(OUT) if path.is_relative_to(OUT) else (
        Path('author') / path.name if path.is_relative_to(AUTHOR) else Path('prior-quality') / path.name
    )
    items.append({**ref(path), 'transport_path': str(relative)})
selection = {'schema': 'e02-F-independent-review-transfer.v1', 'reviewer': 'graph_scm',
             'candidate_sha': SHA, 'check': 'PASS', 'decision': 'GO_BOUNDED',
             'items': items, 'unique_items': len(items),
             'total_bytes': sum(item['bytes'] for item in items),
             'omitted_recomputable_sources': 'Tracked source bodies and full Git patch are cited by exact source SHA/path;no duplicate source copies transported.',
             'source_body_binding': review['complete_changed_source_bindings']}
(OUT / 'transfer-selection.json').write_text(json.dumps(selection, indent=2) + '\n')
print(json.dumps({'review': ref(review_path), 'selection': ref(OUT / 'transfer-selection.json'),
                  'unique_items': selection['unique_items'], 'bytes': selection['total_bytes'],
                  'decision': selection['decision']}, indent=2))
