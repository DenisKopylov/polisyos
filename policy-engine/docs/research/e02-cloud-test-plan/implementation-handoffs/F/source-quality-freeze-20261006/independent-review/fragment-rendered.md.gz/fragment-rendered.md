## [review-only] - 2026-10-06

### Fixed
- `foundry`: Normalize causal source and equivalent pytest declarations: Normalize F-owned source formatting and use equivalent explicit pytest parameter names before regenerating source-bound inventory.

## Compatibility Notes
- Production ASTs, literals, docstrings, causal algorithms, public identities and wire schemas are unchanged.

## Change Classes
- internal

## Supported Surface Classification
- internal: source formatting and test declaration syntax

## Migration Notes
- Regenerate canonical source-bound inventory and bind installed evidence to the corrected SHA.

## Known Limitations
- The broader runtime formatting and Core schema failures remain separate; no P41 or global-green claim.

## Structured Compatibility Changes
- `internal` / `compatible` / internal: causal source and test declaration formatting: Production ASTs and numerical algorithms remain unchanged; source hashes and their inventory bindings are refreshed. (owner: team-foundry; version owner: team-foundry; deprecation: not_applicable: equivalent formatting correction)
