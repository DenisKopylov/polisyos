import ast,difflib,hashlib,json,pathlib,subprocess
root=pathlib.Path('/workspace/e02-F-graph-20261006');out=pathlib.Path(__file__).parent
base='198076863e143dea9f89f02734b13d50dae3eed5';current='d5ae668fe6079bfa81bd7448aa911fa4bee4e03b';python='/workspace/e02-F-closeout-20261006/policy-engine/.venv/bin/python'
paths=['policy-engine/src/polisyos/foundry/methods/catalog/causal/id_engine/core.py','policy-engine/src/polisyos/foundry/methods/catalog/causal/id_engine/counterfactual.py','policy-engine/src/polisyos/ir/analytics/causal_graph.py']
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
configs=['policy-engine/ruff.toml','policy-engine/architecture/tooling/ruff/generated.toml']
assert not git('diff','--name-only',base,current,'--',*configs)
config_refs=[]
for p in configs:
 b=git('show',current+':'+p);assert b==(root/p).read_bytes();config_refs.append({'source_path':p,'source_sha':current,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
rows=[]
for path in paths:
 name=pathlib.Path(path).name;data={};
 for label,sha in [('base198',base),('currentd5',current)]:
  body=git('show',sha+':'+path);cmd=[python,'-m','ruff','format','--stdin-filename',str(root/path),'-'];r=subprocess.run(cmd,input=body,cwd=root/'policy-engine',capture_output=True);assert r.returncode==0,r.stderr
  (out/(name+'.'+label+'.stderr.txt')).write_bytes(r.stderr);(out/(name+'.'+label+'.original.txt')).write_bytes(body);(out/(name+'.'+label+'.formatted.txt')).write_bytes(r.stdout)
  assert ast.dump(ast.parse(body,type_comments=True),include_attributes=False)==ast.dump(ast.parse(r.stdout,type_comments=True),include_attributes=False)
  diff=''.join(difflib.unified_diff(body.decode().splitlines(True),r.stdout.decode().splitlines(True),fromfile=path+'@'+sha,tofile=path+'@Ruff0.14.10'))
  (out/(name+'.'+label+'.format.patch')).write_text(diff)
  data[label]={'source_sha':sha,'source_path':path,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),'command':cmd,'needs_format':body!=r.stdout,'format_diff_bytes':len(diff.encode()),'AST_type_comments_equal':True,'formatted_sha256':hashlib.sha256(r.stdout).hexdigest()}
 own=git('log','--format=%H',base+'..'+current,'--',path).decode().splitlines();rows.append({'path':path,'changes_since198':own,'format_observations':data})
d={'schema':'e02-F-readonly-format-provenance/1','source_sha':current,'source_tree':git('rev-parse',current+'^{tree}').decode().strip(),'check':'PASS','scope':'three actual F providers; no product writes','config_bindings':config_refs,'rows':rows,'P41':'not_established; scoped historical formatting observations are not complete disjoint-input proof'};(out/'provenance.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d,indent=2))
