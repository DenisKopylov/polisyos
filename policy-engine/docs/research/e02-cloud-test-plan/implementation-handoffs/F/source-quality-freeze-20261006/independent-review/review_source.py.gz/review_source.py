"""Read-only independent review of exact root formatting candidate."""
import ast
import concurrent.futures
import copy
import dataclasses
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import tomllib
import xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
ROOT = Path('/workspace/e02-F-closeout-20261006')
BASE_ROOT = Path('/workspace/e02-F-api-20261006')
BASE = 'd5ae668fe6079bfa81bd7448aa911fa4bee4e03b'
CANDIDATE = '8236d9c368336a5ea20c1586f29aea7321db6536'
PYTHON = str(ROOT / 'policy-engine/.venv/bin/python')
AUTHOR = Path('/tmp/e02-F-continuation-20261006/root-format-forward')
MODULES = [
    'tests/repo_quality/architecture/test_public_surface_export_resolution.py',
    'tests/repo_quality/architecture/test_public_surface_supported_entrypoint_inventory.py',
]

def git(*args, root=ROOT):
    return subprocess.check_output(['git', *args], cwd=root)

def ref_bytes(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}

def file_ref(path):
    return {'path': str(path), **ref_bytes(path.read_bytes())}

def tree_for(body):
    tree = ast.parse(body, type_comments=True)
    # Preserve type-ignore tags and every other AST field. lineno alone is a
    # source coordinate stored as a field rather than an AST attribute.
    for node in ast.walk(tree):
        if isinstance(node, ast.TypeIgnore):
            node.lineno = 0
    return tree

def dump(tree):
    return ast.dump(tree, include_attributes=False)

def normalize_argnames(tree):
    copied = copy.deepcopy(tree)
    for node in ast.walk(copied):
        if not isinstance(node, ast.Call) or not node.args:
            continue
        if ast.unparse(node.func) != 'pytest.mark.parametrize':
            continue
        first = node.args[0]
        if isinstance(first, ast.Constant) and isinstance(first.value, str):
            node.args[0] = ast.Tuple(
                elts=[ast.Constant(value=name.strip()) for name in first.value.split(',')],
                ctx=ast.Load(),
            )
    return copied

def collect(label, repo, sha):
    assert git('rev-parse', 'HEAD', root=repo).decode().strip() == sha
    product = repo / 'policy-engine'
    env = os.environ.copy()
    selected = {'PYTHONPATH': f'{product}/src:{product}/tools:{product}',
                'PYTHONDONTWRITEBYTECODE': '1'}
    env.update(selected)
    argv = [PYTHON, '-m', 'pytest', *MODULES, '--collect-only', '-q',
            '-o', 'addopts=', '--import-mode=importlib', '-p', 'no:cacheprovider',
            '--color=no']
    start = time.monotonic()
    proc = subprocess.run(argv, cwd=product, env=env, capture_output=True)
    (OUT / f'{label}-collection.stdout.txt').write_bytes(proc.stdout)
    (OUT / f'{label}-collection.stderr.txt').write_bytes(proc.stderr)
    assert proc.returncode == 0, proc.stdout.decode() + proc.stderr.decode()
    ids = [line for line in proc.stdout.decode().splitlines()
           if line.startswith('tests/') and '::' in line]
    assert len(ids) == 108, len(ids)
    assert git('rev-parse', 'HEAD', root=repo).decode().strip() == sha
    return {'source_sha': sha, 'argv': argv, 'cwd': str(product),
            'environment': selected, 'exit_code': proc.returncode,
            'wall_seconds': time.monotonic() - start, 'case_count': len(ids),
            'node_ids': ids, 'stdout': file_ref(OUT / f'{label}-collection.stdout.txt'),
            'stderr': file_ref(OUT / f'{label}-collection.stderr.txt')}

assert git('rev-parse', CANDIDATE + '^').decode().strip() == BASE
assert git('rev-parse', 'HEAD').decode().strip() == CANDIDATE
before_status = git('status', '--porcelain').decode()
changed = git('diff', '--name-only', BASE, CANDIDATE).decode().splitlines()
python_paths = [p for p in changed if p.endswith('.py')]
assert len(changed) == 11 and len(python_paths) == 9
spec = json.loads((AUTHOR / 'spec.json').read_bytes())
assert sorted('policy-engine/' + p for p in spec['paths']) == sorted(python_paths)
bindings = {b['path']: b for b in spec['before_bindings']}
rows = []
for path in python_paths:
    before = git('show', BASE + ':' + path)
    after = git('show', CANDIDATE + ':' + path)
    short = path.removeprefix('policy-engine/')
    assert before == (AUTHOR / 'before' / short).read_bytes()
    assert before == (BASE_ROOT / path).read_bytes()
    assert after == (ROOT / path).read_bytes()
    assert ref_bytes(before) == {k: bindings[short][k] for k in ('bytes', 'sha256')}
    left, right = tree_for(before), tree_for(after)
    same = dump(left) == dump(right)
    normalized_same = dump(normalize_argnames(left)) == dump(normalize_argnames(right))
    assert normalized_same, path
    rows.append({'path': path, 'before': ref_bytes(before), 'after': ref_bytes(after),
                 'full_module_AST_equal': same,
                 'pytest_argname_normalized_AST_equal': normalized_same})
assert sum(r['full_module_AST_equal'] for r in rows) == 8
only = next(r for r in rows if not r['full_module_AST_equal'])
assert only['path'].endswith('test_public_surface_export_resolution.py')
before_tree = tree_for(git('show', BASE + ':' + only['path']))
after_tree = tree_for(git('show', CANDIDATE + ':' + only['path']))
target_name = 'test_passive_dependency_protocol_bindings_are_unknown_on_actual_import'
def declaration(tree):
    fn = next(node for node in tree.body
              if isinstance(node, ast.FunctionDef) and node.name == target_name)
    return next(node for node in fn.decorator_list
                if isinstance(node, ast.Call) and ast.unparse(node.func) == 'pytest.mark.parametrize')
left, right = declaration(before_tree), declaration(after_tree)
assert ast.literal_eval(left.args[0]) == 'declaration, import_refused'
assert ast.literal_eval(right.args[0]) == ('declaration', 'import_refused')
assert dump(left.args[1]) == dump(right.args[1])
left.args[0] = copy.deepcopy(right.args[0])
assert dump(before_tree) == dump(after_tree)

# Counterfeit properties retain module/function/decorator markers.
mutated = copy.deepcopy(after_tree)
declaration(mutated).args[0].elts.reverse()
assert dump(normalize_argnames(mutated)) != dump(normalize_argnames(after_tree))
production_tree = tree_for(git('show', CANDIDATE + ':' + python_paths[0]))
mutated_production = copy.deepcopy(production_tree)
literal = next(n for n in ast.walk(mutated_production)
               if isinstance(n, ast.Constant) and isinstance(n.value, str))
literal.value += '\nchanged-property'
assert dump(mutated_production) != dump(production_tree)

patch = git('diff', BASE, CANDIDATE)
(OUT / 'full-candidate.patch').write_bytes(patch)
with concurrent.futures.ThreadPoolExecutor() as pool:
    futures = [pool.submit(collect, 'base-d5ae', BASE_ROOT, BASE),
               pool.submit(collect, 'candidate-8236', ROOT, CANDIDATE)]
    collections = [future.result() for future in futures]
assert collections[0]['node_ids'] == collections[1]['node_ids']
for run in collections:
    run['case_ID_sequence_sha256'] = hashlib.sha256(
        ('\n'.join(run.pop('node_ids')) + '\n').encode()
    ).hexdigest()

product = ROOT / 'policy-engine'
cmd = [PYTHON, '-m', 'ruff', 'check', *(p.removeprefix('policy-engine/') for p in python_paths)]
lint = subprocess.run(cmd, cwd=product, capture_output=True)
(OUT / 'independent-ruff.stdout.txt').write_bytes(lint.stdout)
(OUT / 'independent-ruff.stderr.txt').write_bytes(lint.stderr)
assert lint.returncode == 0, lint.stdout.decode() + lint.stderr.decode()
format_cmd = [PYTHON, '-m', 'ruff', 'format', '--check', *(p.removeprefix('policy-engine/') for p in python_paths)]
formatted = subprocess.run(format_cmd, cwd=product, capture_output=True)
(OUT / 'independent-format.stdout.txt').write_bytes(formatted.stdout)
(OUT / 'independent-format.stderr.txt').write_bytes(formatted.stderr)
assert formatted.returncode == 0, formatted.stdout.decode() + formatted.stderr.decode()

sys.path.insert(0, str(product))
from tools.ops_runners.release.check_compatibility_release_gates import _validate_fragments
from tools.ops_runners.release.build_release_notes import structured_compatibility_changes, render_release_notes
fragment_path = 'release-fragments/unreleased/2026-10-06-F-causal-source-formatting.toml'
fragment = tomllib.loads((product / fragment_path).read_text())
fragment['__path__'] = fragment_path
policy_path = product / 'architecture/gates/compatibility_release.toml'
errors, findings = _validate_fragments(product, tomllib.loads(policy_path.read_text()),
                                      [fragment], breaking_classes=())
assert not errors and not findings, (errors, findings)
changes = structured_compatibility_changes([fragment])
assert len(changes) == 1
assert changes[0]['change_class'] == 'internal' and changes[0]['impact'] == 'compatible'
notes = render_release_notes('review-only', [fragment], '2026-10-06')
(OUT / 'fragment-rendered.md').write_text(notes)
fragment_output = {'canonical_errors': [dataclasses.asdict(x) for x in errors],
                   'canonical_findings': [dataclasses.asdict(x) for x in findings],
                   'structured_changes': changes, 'policy': file_ref(policy_path)}
(OUT / 'fragment-validation.json').write_text(json.dumps(fragment_output, indent=2) + '\n')

native = ET.parse(AUTHOR / 'frozen-native-api.xml').getroot()
suites = [native] if native.tag == 'testsuite' else list(native.iter('testsuite'))
native_totals = {key: sum(int(suite.get(key, '0')) for suite in suites)
                 for key in ('tests', 'failures', 'errors', 'skipped')}
assert native_totals == {'tests': 108, 'failures': 0, 'errors': 0, 'skipped': 0}
assert git('status', '--porcelain').decode() == before_status
assert git('rev-parse', 'HEAD').decode().strip() == CANDIDATE
for path in python_paths:
    assert git('show', CANDIDATE + ':' + path) == (ROOT / path).read_bytes()
summary = {'schema': 'e02-F-independent-source-format-review.v1',
           'reviewer': 'graph_scm', 'check': 'PASS', 'decision': 'GO_BOUNDED',
           'candidate_sha': CANDIDATE,
           'candidate_tree': git('rev-parse', CANDIDATE + '^{tree}').decode().strip(),
           'slice_base_sha': BASE, 'changed_paths': changed, 'AST': rows,
           'complete_changed_source_bindings': [
               {'source_sha': CANDIDATE, 'source_path': path,
                **ref_bytes(git('show', CANDIDATE + ':' + path))}
               for path in changed],
           'review_interpreter': {'executable': sys.executable, 'version': sys.version},
           'pytest_change': {'function': target_name,
               'before_argnames': 'declaration, import_refused',
               'after_argnames': ['declaration', 'import_refused'],
               'values_AST_equal': True, 'entire_module_AST_equal_after_only_this_normalization': True},
           'collection_comparison': {'check': 'PASS', 'scope': 'actual declared case IDs only; no scientific runtime claim',
                                     'complete_node_ID_sequence_equal': True, 'runs': collections},
           'negative_controls': ['changed literal with markers retained -> AST inequality',
                                 'reversed parameter-name tuple with same markers -> inequality'],
           'author_native_execution': {'check': 'PASS', 'source_sha': CANDIDATE,
                                       'totals_from_full_JUnit': native_totals,
                                       'recomputed_by_reviewer': False,
                                       'literal_invocation_binding': {k: spec[k] for k in
                                           ['native_command', 'cwd', 'environment', 'source_sha', 'source_tree']},
                                       'previous_execution_qualification': spec['precommit_native_execution'],
                                       'complete_outputs': [file_ref(AUTHOR / name) for name in
                                           ['frozen-native-api.xml', 'frozen-native-api.stdout.txt', 'frozen-native-api.stderr.txt']]},
           'independent_Ruff': {'check': 'PASS', 'lint_argv': cmd, 'format_argv': format_cmd,
                               'cwd': str(product)},
           'canonical_fragment': {'check': 'PASS', 'structured_count': len(changes),
                                  'errors': 0, 'findings': 0, 'classification': 'internal/compatible'},
           'tracked_delta_and_source_unchanged': True,
           'existing_untracked_state': before_status,
           'limitations': ['Nine Python paths and two owned documentation companions only.',
               'Old broad92 styleFAIL and full inputprojection scannerFAIL remain nonPASS; P41 not_established.',
               'Canonical public inventory source-byte bindings require fresh author rendering.',
               'No new graph/SCM/backend numerical or installed source-equivalence claim.'],
           'provenance_review': file_ref(OUT / 'provenance.json')}
(OUT / 'independent-source-review.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({k: summary[k] for k in ('check', 'decision', 'candidate_sha', 'candidate_tree')}, indent=2))
print('8/9 exact full-module ASTs equal; sole remaining two-name pytest string/tuple equivalent.')
print('108/108 actual complete node-ID sequences equal; scoped Ruff9 and canonical fragment PASS.')
