from pathlib import Path
import os,subprocess,json,time,hashlib,sys
kind=sys.argv[1];root=Path('/workspace/e02-F-api-20261006');product=root/'policy-engine';dest=Path('/tmp/e02-F-continuation-20261006/root-final-quality');s='d5ae668fe6079bfa81bd7448aa911fa4bee4e03b';t='299a64a56f84ae9ce0044032dba78f014ceec60e';py='/workspace/e02-F-closeout-20261006/policy-engine/.venv/bin/python'
def git(*a):return subprocess.check_output(['git',*a],cwd=root,text=True).strip()
def guard():assert git('rev-parse','HEAD')==s and git('rev-parse','HEAD^{tree}')==t and not git('status','--porcelain','--untracked-files=no')
base='421f1dd977b237307394c68820caab4156716eb2';env=os.environ.copy();env['PYTHONPATH']=str(product/'src')+':'+str(product);env['PYTHONDONTWRITEBYTECODE']='1'
paths=[p.removeprefix('policy-engine/') for p in git('diff','--name-only',base,s,'--','policy-engine/src','policy-engine/tools','policy-engine/tests').splitlines() if p.endswith('.py') and (root/p).is_file()]
if kind=='invocation':argv=[py,'-m','polisyos.runtime.quality.production_invocation','--repo-root',str(product),'--base',base,'--receipt',str(dest/'invocation-full.json')]
elif kind=='schema':argv=[py,'tools/quality/diagnostics/gen_schema.py','--check','--cache-dir',str(dest/'schema-private-cache')]
elif kind=='ruff':argv=['/workspace/e02-F-closeout-20261006/policy-engine/.venv/bin/ruff','check',*paths]
elif kind=='format':argv=['/workspace/e02-F-closeout-20261006/policy-engine/.venv/bin/ruff','format','--check',*paths]
else:raise ValueError(kind)
guard();start=time.monotonic()
with (dest/(kind+'.stdout.txt')).open('wb') as out,(dest/(kind+'.stderr.txt')).open('wb') as err:result=subprocess.run(argv,cwd=product,env=env,stdout=out,stderr=err)
guard();r={'command':argv,'cwd':str(product),'environment':{'PYTHONPATH':env['PYTHONPATH'],'PYTHONDONTWRITEBYTECODE':'1','actual_application_interpreter':'Python3.14.7'},'source_sha':s,'source_tree':t,'slice_base_sha':base,'exit_code':result.returncode,'wall_seconds':time.monotonic()-start,'complete_input_python_paths':paths if kind in ['ruff','format'] else 'full maintained checker denominator','outputs':[]}
for f in [dest/(kind+'.stdout.txt'),dest/(kind+'.stderr.txt')]+([dest/'invocation-full.json'] if kind=='invocation' and (dest/'invocation-full.json').is_file() else []):
 b=f.read_bytes();r['outputs'].append({'path':str(f),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
r['check']='PASS' if result.returncode==0 else 'ERROR' if result.returncode<0 else 'FAIL';r['limitation']='Static checker/schema/drift/lint is not native runtime invocation or authority evidence. FullFAIL/ERROR staysred; P41not_established.'
(dest/(kind+'.receipt.json')).write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'kind':kind,'exit_code':result.returncode,'check':r['check'],'wall_seconds':r['wall_seconds'],'paths':len(paths)}))
