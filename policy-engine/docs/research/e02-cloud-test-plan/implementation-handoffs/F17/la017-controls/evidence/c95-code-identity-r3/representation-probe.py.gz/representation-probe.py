"""Bounded CPython 3.14 code representation probe; no product imports."""
from pathlib import Path
from types import CodeType, SimpleNamespace, FunctionType
import hashlib, json, marshal, os, sys

source=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos/policy-engine/src/polisyos/lex/legal_evaluation/impact_diff.py')
data=source.read_bytes()
root=compile(data,str(source),'exec',dont_inherit=True,optimize=0)
queue=[root];found=[]
while queue:
 c=queue.pop()
 if c.co_name=='_infer_candidate_topics_v1_1': found.append(c)
 queue.extend(q for q in c.co_consts if isinstance(q,CodeType))
assert len(found)==1
code=found[0]
class KPI:
 def __init__(self,kpi_id,description):
  self.kpi_id=kpi_id;self.description=description;self.affected_norm_ids=[]
ns={'NormChangeType':SimpleNamespace(UNCHANGED=0),'RuleType':SimpleNamespace(OBLIGATION=1,PROHIBITION=2),'AffectedKPI':KPI}
func=FunctionType(code,ns)
diff=SimpleNamespace(changes=[SimpleNamespace(change_type=1,new_rule=SimpleNamespace(rule_type=1),old_rule=None,norm_id='a'),SimpleNamespace(change_type=1,new_rule=SimpleNamespace(rule_type=2),old_rule=None,norm_id='b')])
def sha(b):return hashlib.sha256(b).hexdigest()
def snap(label):
 b=marshal.dumps(code);return {'label':label,'marshal_sha256':sha(b),'marshal_bytes':len(b),'co_code_sha256':sha(code.co_code),'code_id':id(code),'co_consts_repr':repr(code.co_consts),'co_names':code.co_names,'co_varnames':code.co_varnames,'co_flags':code.co_flags,'co_exceptiontable_sha256':sha(code.co_exceptiontable),'co_linetable_sha256':sha(code.co_linetable)}
snaps=[snap('before')];calls=[]
def trace(frame,event,arg):
 if event=='call' and frame.f_code is code:
  calls.append(snap('call'))
 return trace
sys.setprofile(trace)
try:
 func(diff);func(diff)
finally:sys.setprofile(None)
snaps.extend(calls);snaps.append(snap('after'))
print(json.dumps({'python':sys.version,'pid':os.getpid(),'source_sha256':sha(data),'code_name':code.co_name,'snapshots':snaps,'same_code_object':all(x['code_id']==id(code) for x in snaps),'marshal_hashes':sorted({x['marshal_sha256'] for x in snaps}),'co_code_hashes':sorted({x['co_code_sha256'] for x in snaps})},indent=2,sort_keys=True))
