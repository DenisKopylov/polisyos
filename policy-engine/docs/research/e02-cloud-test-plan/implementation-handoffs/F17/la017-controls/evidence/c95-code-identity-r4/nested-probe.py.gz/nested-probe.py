"""Examine nested CodeType execution on the actual interpreter; stdlib only."""
from __future__ import annotations
import dis,hashlib,json,sys,types

def code_for(value:str):
 module=compile(f'def outer():\n    def inner():\n        return {value}\n    return inner()\n','<identity-test>','exec',dont_inherit=True,optimize=0)
 return next(x for x in module.co_consts if isinstance(x,types.CodeType))

def measure(name,source,replacement,expected):
 outer=code_for(source);inner=next(x for x in outer.co_consts if isinstance(x,types.CodeType))
 changed=inner.replace(co_consts=tuple(replacement if v==expected else v for v in inner.co_consts));mutant=outer.replace(co_consts=tuple(changed if v is inner else v for v in outer.co_consts));calls=[]
 def observer(frame,event,arg):
  if event=='call' and frame.f_code.co_name=='inner':calls.append({'code_id':id(frame.f_code),'is_original':frame.f_code is inner,'is_changed':frame.f_code is changed,'constants':repr(frame.f_code.co_consts),'bytecode_sha256':hashlib.sha256(frame.f_code.co_code).hexdigest()})
  return observer
 sys.setprofile(observer)
 try: before=types.FunctionType(outer,{})();after=types.FunctionType(mutant,{})()
 finally:sys.setprofile(None)
 def instr(code):return [{'opname':x.opname,'arg':x.arg,'argrepr':x.argrepr} for x in dis.get_instructions(code)]
 return {'name':name,'outer_same_bytes':outer.co_code==mutant.co_code,'inner_same_bytes':inner.co_code==changed.co_code,'inner_original_consts':repr(inner.co_consts),'inner_mutated_consts':repr(changed.co_consts),'before':before,'after':after,'original_disassembly':instr(inner),'mutated_disassembly':instr(changed),'actual_inner_calls':calls,'original_id':id(inner),'mutated_id':id(changed)}
rows=[measure('numeric_literal','3',4,3),measure('string_literal',"'original'",'changed','original')]
print(json.dumps({'python':sys.version,'cases':rows},indent=2,sort_keys=True))
