#!/usr/bin/env bash
set -u
PHASE=$1; WT=$2; SELECTOR=$3; EVENT_JSON=${4-}
PY=/workspace/polisyos/policy-engine/.venv/bin/python
OUTROOT=$(cat /tmp/ddm-r19-current)/evidence/runs/$PHASE
mkdir -p "$OUTROOT/observer"
PE="$WT/policy-engine"; TARGET=${5-}
{
 printf 'phase=%s\nworktree=%s\ncwd=%s\ncommit=%s\ntree=%s\ntarget=%s\ntarget_sha256=' "$PHASE" "$WT" "$PE" "$(git -C "$WT" rev-parse HEAD)" "$(git -C "$WT" rev-parse HEAD^{tree})" "$TARGET"
 if [[ -n "$TARGET" ]]; then sha256sum "$WT/$TARGET" | cut -d' ' -f1; else echo n/a; fi
 echo 'status_porcelain_v1<<EOF'; git -C "$WT" status --porcelain=v1; echo EOF
 echo 'diff_binary<<EOF'; git -C "$WT" diff --binary; echo EOF
 echo 'diff_cached<<EOF'; git -C "$WT" diff --cached; echo EOF
} > "$OUTROOT/pre.txt"
printf '%q ' "$PY" -m pytest -p e02_observer -vv --tb=long -s "--junitxml=$OUTROOT/junit.xml" "$SELECTOR" > "$OUTROOT/argv.shell"; echo >> "$OUTROOT/argv.shell"
cat > "$OUTROOT/environment.json" <<EOF
{"PYTHONPATH":"$PE/docs/research/e02-cloud-test-plan/full-run","E02_OBSERVER_DIR":"$OUTROOT/observer","POLISYOS_DDM_EVENT_PICKLE_RECORD_JSON":"$([[ -n "$EVENT_JSON" ]] && echo supplied || echo absent)","PYTHONDONTWRITEBYTECODE":"inherited/unset at pytest layer; cold-child test sets 1"}
EOF
START=$(date +%s%N)
cd "$PE"
if [[ -n "$EVENT_JSON" ]]; then
 PYTHONPATH="$PE/docs/research/e02-cloud-test-plan/full-run" E02_OBSERVER_DIR="$OUTROOT/observer" POLISYOS_DDM_EVENT_PICKLE_RECORD_JSON="$EVENT_JSON" "$PY" -m pytest -p e02_observer -vv --tb=long -s "--junitxml=$OUTROOT/junit.xml" "$SELECTOR" >"$OUTROOT/stdout.txt" 2>"$OUTROOT/stderr.txt"
else
 env -u POLISYOS_DDM_EVENT_PICKLE_RECORD_JSON PYTHONPATH="$PE/docs/research/e02-cloud-test-plan/full-run" E02_OBSERVER_DIR="$OUTROOT/observer" "$PY" -m pytest -p e02_observer -vv --tb=long -s "--junitxml=$OUTROOT/junit.xml" "$SELECTOR" >"$OUTROOT/stdout.txt" 2>"$OUTROOT/stderr.txt"
fi
STATUS=$?
END=$(date +%s%N)
printf '{"exit_status":%d,"start_ns":%s,"end_ns":%s,"duration_ns":%s,"pytest_pid_from_observer_dirs":[' "$STATUS" "$START" "$END" "$((END-START))" > "$OUTROOT/process.json"
first=1; for d in "$OUTROOT"/observer/*; do [[ -d "$d" ]] || continue; [[ $first == 1 ]] || printf ',' >> "$OUTROOT/process.json"; first=0; basename "$d" | tr -cd '0-9' >> "$OUTROOT/process.json"; done; echo ']}' >> "$OUTROOT/process.json"
{
 echo 'status_porcelain_v1<<EOF'; git -C "$WT" status --porcelain=v1; echo EOF
 echo 'diff_binary<<EOF'; git -C "$WT" diff --binary; echo EOF
 echo 'diff_cached<<EOF'; git -C "$WT" diff --cached; echo EOF
} > "$OUTROOT/post.txt"
exit "$STATUS"
