# C48 single-child sandbox repair

Status: RAW harness/source-plan proposal; independent review pending. The small stdlib infrastructure diagnostic passed. Product/native pytest, removal controls, generated qualification and G remain UNRUN. Root alone installs the append-only runner and launches native work.

## Actual failure and bounded repair

Root's r2 `check_outer_guard.py c48-two-source-composed-r3-20261028` stopped before product/native execution: exit71, empty stdout, `sandbox-exec: sandbox_apply: Operation not permitted`. That helper put the D-shaped child write profile inside an outer sandbox. This is a harness composition ERROR, not product FAIL; the failed case and r2 bytes remain immutable.

The proposed `run_case_with_tools_r3.py` is 7,337 bytes, copied from exact D_R2 SHA256 `4c3eae2136b6c8941ba09d4438d12ea6ea11310527768f0482877b877b8e30c2`. It retains the original D write policy as the first component and appends one Root-controlled inline profile fragment before its sole child `sandbox-exec` call. The fragment denies network operations and read access to the known lexical production link and physical target. No outer sandbox is used. No observer, monitor, environment, native pytest/default-plugin profile, source guard, deadline, resource cap, output handling or failure handling is replaced.

R3 checks the inline fragment hash and exact full combined profile bytes/hash against the plan before child launch. It retains `sandbox-fragment.sb` and `child.sb`, adds both to the existing selected-input pins and unchanged post-run all-input hash check, and records both texts/hashes in the existing `source-profile-freeze.json`. The profile is constructed once before launch; there is no waiting, profile injection race, mutation watcher or broad new harness. The precise delta and reversible text/AST equivalence evidence are `runner-delta.patch` and `runner-equivalence.json`; reversing only the declared profile seam changes gives the exact R2 text and AST.

`source-bindings.json` preserves all 75 selected path/explicit conftest absence rows and expected hashes. Only the first of four RAW runner pins changes R2→R3. Its 75-source admission accepts later attached clean descendant heads when those actual bytes remain equal; it does not force a fixed HEAD. C48 source was physically committed by Root at `b8fcda7332c89609410e8ca936b472ef2eed43e1` / tree `bcc0766ff9eae30e3bbeda86631bbcf79eae3c7a`; later disjoint commits do not require source reimplementation. C71 remains independent and unapplied, with future affected requalification reserved.

## Infrastructure diagnostic and boundary

The authorized small stdlib check used exactly one `sandbox-exec` and only synthetic RAW fixtures in `guard-infra-single-diagnostic-r1-20261028/`. Receipt: exit0, empty stderr, direct and symlink reads denied with EACCES/EPERM, an allowed sibling read succeeded, an output write succeeded, and a write outside the permitted output subtree was denied. The production profile fragment is text only; no production content was opened. The diagnostic used isolated Python `-I -S -B`, no product import/test, no port, and no network syscall/message.

The declared `deny network*` rule remains in both the synthetic and future production profile. Because no network syscall was issued, actual network denial remains `not_established`. The read protection covers the known lexical/physical production path, not universal host-private input provenance. The single-profile diagnostic demonstrates read/write rule composition on the retained D-shaped policy; it does not establish the native C48 result or reproduce every native package read.

## Root-only installation and launch recipe

First independently review this packet, diagnostic and reversible runner delta. Root then verifies the runner target is absent and creates that ONE new ignored D file without editing R2. `install-runner.patch` is an alternative new-file proposal; use either the exclusive-create recipe below or the patch, not both. Both remain unapplied by the author. Never install it as a tracked product file or commit the RAW harness.

From the repository root, Root may run this after review:

```python
from pathlib import Path
import hashlib
packet = Path('LOCAL/raw/e02-execution-20261027/repairs/C48-single-sandbox-r1')
import json
record = json.loads((packet / 'runner-equivalence.json').read_text())
source = packet / 'postimage' / record['proposed_runner']
target = Path(record['proposed_runner'])
assert hashlib.sha256(source.read_bytes()).hexdigest() == record['new_sha256']
assert not target.exists()
with target.open('xb') as stream:
    stream.write(source.read_bytes())
assert hashlib.sha256(target.read_bytes()).hexdigest() == record['new_sha256']
```

Use a fresh Root-selected r4 case ID, for example `c48-two-source-composed-r4-20261028`; never overwrite the failed r3 guard/case. Run only the guard and plan preparer first:

```sh
python3 -B LOCAL/raw/e02-execution-20261027/repairs/C48-single-sandbox-r1/check_single_guard.py c48-two-source-composed-r4-20261028
python3 -B LOCAL/raw/e02-execution-20261027/repairs/C48-single-sandbox-r1/prepare_plan.py c48-two-source-composed-r4-20261028
```

The preparer requires the installed exact R3/four RAW pins, all 75 source rows present in both live/committed bytes, correct attached branch and unchanged clean head during preflight, exact known production symlink, the successful SAME-case single-combined guard receipt/code/profile/fragment, and D's free-disk floor. It emits the real full combined profile text/hash and fragment text/hash in the new exclusively created D plan. It writes no product source and invokes no pytest. Re-run Root's live source/profile/ownership guard and acquire the source/native resource lease before native launch.

Invoke R3 directly under the established minimal launch environment, **without an outer `sandbox-exec`**. Set `D` only as a shell-local task path or substitute its full known path:

```sh
D='policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1'
/usr/bin/env -i PATH=/usr/bin:/bin:/usr/sbin:/sbin HOME="$HOME" LANG=C.UTF-8 PYTHONDONTWRITEBYTECODE=1 \
  policy-engine/.venv/bin/python -B "$D/run_case_with_tools_r3.py" \
  "$(pwd)/$D/c48-two-source-composed-r4-20261028.json"
```

The unchanged D runner creates the only child sandbox around the native pytest argv, retains the existing monitor and observer and enforces the provisional 600s/2,415,919,104-byte sampled process-tree RSS limit and 6GiB free-disk floor. Record actual resource/profile/readset and owner/CAS outputs. The first pilot remains one selector: two completed Graph sources, separate actual planner and fresh authorized GET with means1/2, B frontier and candidate-only status. No C48/C53/generic authority closure is claimed. Later source joins, revocation and removal qualification remain separate.

Pattern pass: P29/P33 exercise actual denial and positive controls, not a profile marker; P37/P38 inspect single-sandbox composition instead of assuming nested policy application; P40 widen the original comparison/source boundary without discarding the protection; P41 preserve the infrastructure error rather than reporting product failure. The next owner is Root for install/admission/launch and actual qualification.
