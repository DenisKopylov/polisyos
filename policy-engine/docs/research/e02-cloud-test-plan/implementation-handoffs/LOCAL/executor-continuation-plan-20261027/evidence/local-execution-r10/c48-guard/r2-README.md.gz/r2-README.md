# C48 fresh-r4 admission after C05 composition

Status: RAW source-frame/preparer delta; independent review pending. No tests, product imports, sandbox diagnostic, native run, runner installation, canonical edit, index or ref mutation occurred in this task. R1 remains immutable. The exact R3 runner and single-sandbox policy are reused without change.

## Complete source inspection and behavior

`audit_c05_delta.py` walks the entire existing 75-entry C48 source frame (paths plus explicit conftest absences), reads every entry from committed C05 source `545c6990e2bfa42bf580b475e23cf88df04e71d8` / tree `abd7d9913680d5531081c45536c1cf7d7d701835`, and compares live bytes. Exactly two frame entries changed; all 75 live entries matched that source when read. The same script enumerates all 37 paths in the actual C05 commit: 19 product Python modules, three product README files, one release fragment and 14 test Python modules. These are complete finite-set counts from Git, not sampled grep or an import census.

The two intersections were inspected rather than merely rehashed:

- `run_lifecycle.py`: complete class-method AST comparison finds only existing `ControlPlaneService.get_job_status` changed and `_current_producer_cost_job_record` added. Every other preexisting method is equal to the committed b8fcda C48 source. The new reader returns the record unchanged before imports/readback unless it is a `natural_language_run` with a candidate proposal. The C48 requests are `workflow_run`; Graph selection, completed-source owner, candidate scoring/comparison, fresh revalidation and `_run_legacy_scientist_workflow` definitions are unchanged. A possible shared status read on a workflow record therefore takes the early return. New source SHA: `6fdf9b4f230df67cef23f3f33283eb95e38790920ce4e25f141fb81aec7c2d6f`.
- `control_plane_store.py`: complete class-method AST comparison finds all 158 preexisting methods equal and only `verify_llm_producer_admission` added. That method explicitly verifies a current natural-language job; Graph dispatch/selection methods do not call it. New source SHA: `c95f43bebad7f917320530da9691adae63e731a07ad619b42f9b39e3c26bb9ed`.

The rest of C05 is not casually classified as unloaded or disjoint. Runtime app construction creates the changed `BudgetMiddleware` (`runtime/http/container.py:405`, including its new short binding lock); Runtime's lifecycle module imports the NL job/mixin, and NL imports the changed factory/cache classes (`nl_pipeline.py:104-105`). Factory/Gateway/prepared/cache/settlement modules may be imported during app composition even though this explicit Graph pilot does not request provider or NL execution. This packet therefore pins the complete changed 19-product-Python subset: the two existing entries are rebound and the remaining 17 become `supplemental_c05_runtime_inputs`, for 92 unique finite source inputs including the original explicit conftest absences. Actual loaded-source/dispatch evidence still comes from the unchanged native observer and actual owner path; this is not a transitive dependency or all-provider proof.

The existing shared helper `prepare_only=True` return, selected synthetic Catalog, matching tenant scopes, Graph owner, real paired arrays and separate planner/fresh GET remain unchanged. C71 is not a start prerequisite. C05's complete test/removal wave is a separate qualification obligation; this bounded C48 pilot does not claim C05 acceptance or require that entire wave to finish first.

## C05 hold and generator work remain separate

The independent C05 r8 review `reviews/C05-r8-code.md` identifies a prepared-call decoder signature mismatch, while `reviews/C05-r8-code-sol.md` gives source GO with runtime missing. Preserve the HOLD as its own C05 residual. The identified failure requires thawing a prepared provider/cache call; the selected C48 Graph inputs do not request that call. This is not evidence that all C05 runtime behavior is correct or that no C05 code loads. The supplemental pins deliberately expose a later actual decoder/source repair as drift for narrow rebind/review rather than silently accepting it.

Four Root-owned Foundry `.pyi` files were modified when this audit read the tree: `foundry/methods/base.pyi`, `foundry/methods/components/composer.pyi`, `foundry/methods/composer.pyi`, `foundry/methods/registry.pyi`. They are outside both the original 75 and the supplemental 17 source entries. They are known generator WIP, not a C48 product failure. The unchanged clean-tree admission still refuses launch until Root finishes and commits the genuine generator repair. Later HEAD may advance normally; it must descend from the reviewed C05 composition and every pinned source byte must remain exact. A later source mismatch requires inspection and delta review, not a blanket hash refresh.

## Minimal final admission recipe

1. Root completes its genuine generator repair and normal commit/readback. Do not modify, stash or discard the four WIP files for this plan. Recheck the attached branch and clean tracked/index state. Re-run Root's existing current source/ownership admission and hold its source/native resource lease.
2. Independently review this source-frame/preparer delta. Reuse exact `repairs/C48-single-sandbox-r1` runner proposal SHA256 `b15b573c4b7854dddd3cdd55933fd4634d013cbe1410dd1cf965d6bdaff53243` and bounded harness review `reviews/C48-single-sandbox-r1-dependency-graph.md@sha256:2a5e10f179e082fa3d5efc5f8d417410a75240f7213e41890252763ec366ebb0`. Root exclusively installs the new ignored D `run_case_with_tools_r3.py` only if absent, using R1's exact recipe; if already installed, verify its exact hash and never overwrite it. The other three RAW runner/monitor/observer pins remain unchanged. The author has not installed it.
3. Use the fresh r4 case ID, never the failed r3 case. Run the unchanged guard from THIS successor directory so the same-case receipt belongs to this source plan, then prepare:

```sh
python3 -B LOCAL/raw/e02-execution-20261027/repairs/C48-single-sandbox-r2-c05/check_single_guard.py c48-two-source-composed-r4-20261028
python3 -B LOCAL/raw/e02-execution-20261027/repairs/C48-single-sandbox-r2-c05/prepare_plan.py c48-two-source-composed-r4-20261028
```

The preparer checks all 75 original source entries, all 17 supplemental C05 Python entries, live AND current committed bytes, the four exact RAW runtime pins, original and C05 ancestry, attached branch, clean stable head, the known production symlink and successful same-case single-sandbox guard/code/profile receipt. It emits exact actual combined profile and fragment bytes/hashes and current dynamic head/tree into one exclusively created D plan. The source frame is finite; new unrelated generated commits can pass when all these properties remain true.

4. With the same Root source/resource lease, execute the existing R3 directly under the established clean environment—NO outer sandbox:

```sh
D='policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1'
/usr/bin/env -i PATH=/usr/bin:/bin:/usr/sbin:/sbin HOME="$HOME" LANG=C.UTF-8 PYTHONDONTWRITEBYTECODE=1 \
  policy-engine/.venv/bin/python -B "$D/run_case_with_tools_r3.py" \
  "$(pwd)/$D/c48-two-source-composed-r4-20261028.json"
```

R3's one child sandbox retains D's write confinement and known-production read/network-denial fragment. Its monitor/observer/default pytest profile, 600s/2,415,919,104-byte sampled RSS cap and 6GiB free-disk floor are unchanged provisional limits. Actual network denial remains `not_established` because the guard intentionally uses no network syscall/port/message. The prior own-RAW stdlib diagnostic remains an infrastructure result, not product evidence; Root's fresh same-case guard is still required.

Qualify exactly one native selector first: two completed real sources with independent means1/2, separate actual planner and fresh authorized GET, B frontier, exact selected environment-plan lineage and candidate-only status. Retain complete actual source/profile/readset/owner/CAS/resource outputs. Other tests, revocation, removals, API/generated verification and G remain separate UNRUN obligations. No later composed-source PASS is inferred from earlier bytes.

Pattern pass: P01/P02/P12 actual producer chain; P05 candidate-only; P29/P32 exact source/content admission; P35 complete 75/37 denominators; P37/P38 behavior review before hash rebind and branch/property admission; P40 reuse the existing bounded repair; P41 preserve the infrastructure error and version all future source qualification. Capability remains `verification_missing`.
