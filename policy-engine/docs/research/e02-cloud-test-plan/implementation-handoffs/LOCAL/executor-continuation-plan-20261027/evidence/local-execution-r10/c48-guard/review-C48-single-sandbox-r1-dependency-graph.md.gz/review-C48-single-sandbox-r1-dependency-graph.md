# C48 single-child sandbox: independent harness delta review

**Verdict: bounded harness/source-plan GO. No blocking finding.** Root may install the exact new ignored R3 runner and continue the separately guarded first native attempt under the reviewed recipe. This is not a product/native PASS, a network-isolation proof or a G/closure decision.

Packet `repairs/C48-single-sandbox-r1/manifest.json` SHA-256 `fd2ea0c91a90d4f22423fc5c3c99a726510d0f3089bb8674f2496c2732605c0d`; runner SHA-256 `b15b573c4b7854dddd3cdd55933fd4634d013cbe1410dd1cf965d6bdaff53243` (7,337 bytes). Canonical source observed clean/attached at `b8fcda7332c89609410e8ca936b472ef2eed43e1`, tree `bcc0766ff9eae30e3bbeda86631bbcf79eae3c7a`, branch `codex/e02-unified-local-20261009`.

## Exact delta and preserved execution contract

All 16 manifest support pins matched. Independent in-memory replay of `runner-delta.patch@7cea610c2838884dadd98191174d1796df2686453a8bd79ea4041adfd74fdf9a` reconstructs R3 from exact D_R2 `4c3eae2136b6c8941ba09d4438d12ea6ea11310527768f0482877b877b8e30c2`. The two changed hunks contain only the declared profile/fragment seam and its freeze/pin record. `install-runner.patch@e9257056488fb56ac4386ef157fe3e93e716ba6ab4af9afb753c2e5f717d4397` independently reconstructs the same new file from absence. The actual target is absent; old R2 bytes remain unchanged.

A separate AST normalization removes only the new fragment assignment/assert/file, full-profile assertion and added pins, restores the original profile write, and removes the new `sandbox_profile` freeze field. The complete remaining AST equals D_R2. Inspection of the full diff also preserves its exact native argv/default pytest profile, observer, monitor, environment handling, Root source guard, timeout/RSS/disk supervision, output/XML/readset processing, post-run source checks and error handling. There is exactly one `/usr/bin/sandbox-exec` invocation in the proposed runner; it remains the existing monitored child launch.

The runner first checks the inline fragment's string type/hash, constructs the original D write policy plus that fragment, and requires exact complete profile text AND hash equality with the plan. It retains `sandbox-fragment.sb` and `child.sb`, pins both in the unchanged post-run input check, and records their complete texts/hashes in `source-profile-freeze.json` before launch. No profile watcher, product generation, environment install or replacement native executor is introduced. The README invokes the runner directly with the established clean environment and explicitly removes the outer `sandbox-exec`; the original failing nested case is preserved as harness ERROR, not product FAIL.

The Root-only installation recipe uses exclusive `open('xb')`, exact payload/hash readback and one new RAW target. The patch is an alternative to that recipe, not an additional application. Do not overwrite R2, track/commit this RAW harness, reuse a failed case ID or invoke R3 under another outer sandbox. Root's existing exclusive source/native-resource coordination remains required; the byte checks are integrity checks, not a new authority issuer or operating-system writer lock.

## Preparer and finite source frame

`prepare_plan.py@66805afb531ec7556c1e3956a85f8f6defda10c9481e95c36e126afcb014102d` parses and preserves the prior branch/ancestry/clean-state, committed-source, disk and unique-case checks. It additionally validates the same-case successful single-guard schema, current guard code digest, lexical/physical production link, exact fixed production fragment, retained synthetic profile and complete expected diagnostic result. It constructs the exact future D child profile from that case's output path and fragment, and stores both complete profile and fragment text/hash in an exclusively created plan. The runner recomputes and checks those same bytes before its child starts.

The entire 75-entry selected source/explicit-conftest-absence array is byte-data equal to the prior reviewed C48 r2 frame: 69 `.py`, 3 `.toml`, 1 `.ini`, 1 `.md`, 1 `.lock` rows. Every expected source value matched both working and current committed bytes. Of the four RAW runner pins, only the first changes R2 to exact proposed R3; the other three monitor/observer/Root-helper pins remain equal and present. New frame SHA-256 is `4951410f5f528c9a2f3108871e9ec488735da43653dd303abb5acb7dae036c79`. R3 must first be installed for its new raw pin to pass. The actual source bytes, not a fixed HEAD, govern later clean-descendant admission.

The plan still selects exactly the one C48 Graph positive, with case-local stores and provisional 600 seconds / 2,415,919,104-byte sampled process-tree RSS / 6 GiB free-disk floor. These are launch limits, not measured resource requirements. D still records process/disk samples, full stdout/stderr, JUnit, source profile and finite loaded-source readsets. D exit 0 alone can include a skipped pytest case; Root's qualification still requires exactly 1 PASS and 0 FAIL/ERROR/SKIP, no abort/mismatch, and actual owner/CAS/scientific result readback. C71 remains independent for this first Graph selector; a later affected source composition needs its own exact rebind/requalification.

## Retained synthetic diagnostic and its limits

I read and reconciled, but did not rerun, `guard-infra-single-diagnostic-r1-20261028/receipt.json@99ebd7a7ee488f83a146799f74ec30f40b8286195f82eed9f617784c8073f1d6`. It records one sandbox call, isolated stdlib Python `-I -S -B`, return 0, empty stderr and complete stdout:

```json
{"allowed": true, "direct": "denied", "symlink": "denied", "write_allowed": true, "write_denied": true}
```

The receipt's guard-script/code, command, complete synthetic profile/fragment and production-fragment bytes/hashes match their actual retained inputs. Guard source opens only its own synthetic content: parent reads prove denied/alias files exist, child reads require EACCES/EPERM for both, sibling read and inside-output write succeed, and the outside-output write is refused. The outside-write target remains absent and the allowed output contains the expected bytes. Production paths are resolved as link metadata and serialized into the proposed rule text; no production content is opened by this diagnostic. Actual diagnostic fragment is `e713e37c560c3b6c183dd7766a317d819b86a9477ff444c71647da9eeb6dd042`.

This is bounded evidence that the retained D-shaped write policy and synthetic direct/symlink read rules compose in a single sandbox on this host. It does not establish native-package behavior or universal host-private read absence. No network syscall/port/message was used; although `deny network*` is in the exact profile, actual network denial remains `not_established`.

Pattern pass: P29/P33 actual synthetic denial plus allowed controls, P37/P38 actual single-profile composition and byte binding, P40 bounded harness repair, P41 infrastructure ERROR classification. The previous R2 comparison/source/dependency reviews remain unchanged. Product imports/tests, native execution, removal controls, generated qualification, G acceptance and original occurrence closures remain UNRUN/unaccepted. Generic calibration/observation-unit/same-ticket/lesson/VOI/C53 authority residuals stay open. Only this authorized RAW review artifact was written and read back by me.
