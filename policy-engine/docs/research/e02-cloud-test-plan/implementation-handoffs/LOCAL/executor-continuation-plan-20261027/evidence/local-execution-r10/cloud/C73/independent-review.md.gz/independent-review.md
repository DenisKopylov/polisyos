# C73 actual return: independent source and evidence review

**HOLD full LA-034 acceptance and the reader companion.** The return supplies useful construction/wire-profile characterization and a concrete numeric-coercion witness, but the fresh-reader/removal/runtime evidence is not established by delivered deciding outputs. Treat the test addition as bounded diagnostic WIP, not a completed schema/reader capability. Production source and the committed schema are unchanged. The companion remains an unapplied owner proposal; it must not be installed automatically under C24's separate held lease. `closure_ids=[]`.

No product imports, tests, dependency/environment changes, clone, product/checkout/index/ref mutations or companion application were performed. Review used immutable source/file/AST/lock-graph inspection, native Ruff on the new test via stdin, independent in-memory patch reconstruction and a read-only `git apply --check`. Only this unique RAW review and JSON receipt were written. Root's later C41/C48 or other source advances are context, not evidence for this Cloud return.

## Actual delivered identity

- Base: `45fe14d8fe6f6822efab491495886501158d4b45`.
- Reconstructed candidate: `2cce0e5701e2694e3d3a12cdea35eec0163947f3`.
- `cloud/C73/source.diff`: 13,862 bytes, SHA-256 `f185e1d211149d08ce64496037c37560151bf6ad44b00eff600eb2df2222e306`.
- Candidate manifest: `cf16537a9b4baf3895322080695e30141eaa48f4c05ac4366c2c1c9a1002245e`.

I reconciled the complete base-to-candidate Git path set with all three manifest entries and verified every blob, postimage SHA-256 and length. All entries are new files; none modifies a producer, reader, schema, version, public authority or dependency declaration.

| New path under `policy-engine/` | Bytes | SHA-256 |
| --- | --- | --- |
| `docs/research/e02-cloud-test-plan/task-receipts/C73/README.md` | 6,171 | `bc8e761240aec91c0a55425c23bbc2d3bcd1f4418e3ac6af624c1aa4968a99a0` |
| `docs/research/e02-cloud-test-plan/task-receipts/C73/reader-companion.patch` | 1,218 | `088633d0053dd6b06909875812b1764a8ccda46f336dd0132b1008076adb4d74` |
| `tests/unit/berl/test_schema_profiles.py` | 5,124 | `e6cf5d1e68948bf7b67c1138cd67a394b99da0cfb06f1ea5ef24e8376a764a59` |

The receipt records an initial source commit/tree but no final author commit/tree readback. The identity reviewed here is the received diff and coordinator-reconstructed candidate above, not an independently verified final Cloud commit. The actual received C73 directory contains retrieval/diff/index/manifest bookkeeping, but no deciding stdout/stderr/JUnit, active removal, restoration or restored-positive output files.

## Useful bounded work

The new tests use the committed Draft 2020-12 schema with `FormatChecker`, independently from DTO conversion. They characterize missing construction defaults versus complete serialized output; `methods`, nested `model_id`, nested extras, version `9.9.9` and malformed datetime distinguish actual profile dispositions. This is useful semantic testing rather than a constructor-only test. The minimal serialized record has empty methods and is a structural fixture; it is not a reliability/display/authority positive.

The new numeric-string test deliberately expects the current reader to coerce `prediction.raw_score="1.25"` to a float after the wire oracle rejects it. That is consistent with the published reader's required/version checks followed by lax `ExplanationBundle.model_validate`. It preserves a diagnostic mismatch; its green result is not proof of strict wire rejection. The receipt correctly says the proposed strict-reader patch is not applied and combined strict-reader PASS is not claimed. After an admitted reader correction, this characterization must become a refusal assertion or a separately named pre-fix witness rather than permanently requiring the defect.

The existing integration selector cited by the receipt genuinely exists at the admitted source. Its complete parameter set is marginal/conditional × empty/colliding CAS. It runs the actual orchestrator and persisted producer, creates fresh stores, invokes both Scientist and Runtime consumers, asserts a non-null selected profile, uses opposing inline data and tests bad selected refs. The conditional fixture remains a blocked diagnostic; Runtime marginal diagnostics do not remove the subject-not-established authority boundary. This is a legitimate source route for the reported four cases, not a fabricated consumer. Its reported execution is not independently established without the missing outputs.

The LF observation is now correctly bounded: the actual pinned exporter already appends LF. No generator/schema change was warranted merely by the earlier static re-serialization observation. The claimed two fresh-process results match the known committed schema identity, but they remain receipt-reported rather than source-bound execution evidence delivered here.

## Findings by whole class

### C73-R1 — proof/delivery class: reported negatives are not matched removals

The receipt labels schema-content removal PASS. The only supplied implementation creates a local schema copy, changes its version constant, then asserts `mutated != generated_explanation_bundle_schema()`. That assertion is supposed to remain green. It does not feed changed owner output into the real drift assertion and observe the deciding gate fail. The useful earlier `committed == generated` check would detect an actual changed generator/schema; the local inequality alone does not execute that removal.

Likewise, the existing integration selector supplies bad profiles and opposing inline bytes while resolution stays enabled. Those are useful ordinary negative cases. They are not a source/function removal of CAS resolution, nor a source-bound demonstration that bypassing resolution is caught. The receipt's selected-resolution “removal PASS (existing active test)” must be reclassified or backed by actual control code and intended-red output. The separately admitted reader-check removal is honestly marked UNRUN.

No complete output/active control identity/restoration/restored-positive evidence is among the three new paths or the received directory. The generator commands contain `-c ...` rather than an exact reconstructible command body; the combined eight-module command/node denominator is not supplied. Claimed 8 new-test passes, 4 existing-consumer passes, setup/lint failures and combined-wave failures are therefore **author-reported**, not independently reconciled deciding evidence. Full A/D deciding bytes required by the commission were not delivered; file hashes or a prose PASS do not replace them (P29/P37/P38).

Smallest next evidence work: retain the exact fresh-process exporter commands and full compact outputs; supply the actual pytest node/JUnit/stdout/stderr scope; execute the matched real drift/resolution/reader controls at an admitted owner layer, preserve the intended red and exact restoration/positive. If a required output is unavailable, mark it `evidence_unavailable` and name its exact bounded replay. Do not repeat unrelated Cloud compute or treat a deliberately passing negative assertion as a removal red. This is one proof-scope/delivery class, not a new repair round for each missing log or field.

### C73-R2 — exact selected-profile class: the new raw witness does not request selection

`test_schema_profiles.py::_store_raw` (definition line 66; `put_json` call line 70) omits `return_selected_profile=True` and does not assert the returned profile is non-null. At the pinned Core API, that keyword defaults to false. Copying the returned optional field into `ExplanationBundleRef` does not establish that an exact manifest profile was selected; a first write can be profileless. The test's fresh single-default-view read is useful, but it is not the exact selected-manifest adversarial witness described in the receipt/commission.

The required capability already exists: request the actual selected profile from the same raw write and assert it is established before testing the same frozen bytes. Keep an explicitly profileless legacy/default case separate, with a same-content competing manifest where it discriminates the default from the selected view. This is the existing selected-lineage/property class, not justification for another authority owner or a new CAS.

### C73-R3 — reader/runtime-profile class: companion introduces a test-only dependency

The companion is correctly bound to persistence preimage SHA-256 `d2b284b97f7c140023cec916790584e63bfc91b838c0ceba43c303be2879922a`. I independently reconstructed its two hunks; proposed postimage SHA-256 is `99366f4f66441ef4321d14a932ba14336b593af6ee368a6ca9d83345e9d1804f`, Git blob `27c29d05d75c809afd2cd90bd4abca0eec5c9d48`, matching its abbreviated patch header. A read-only apply check returns zero with empty output against the matching native preimage. Nothing was applied.

The generic schema check is a reasonable whole-profile direction, but the patch eagerly imports `jsonschema` into production `persistence.py`. At the admitted `pyproject.toml`, it is declared only as `jsonschema[format-nongpl]` in the **test** extra. I walked the complete mandatory `policy-engine` dependency graph in the pinned `uv.lock`, including activated edge extras, all listed versions and ignoring markers as a superset: its 116 package names do not include jsonschema. Thus the proposal changes production import availability while supplying no supported production dependency/format profile. A test environment masks that missing runtime contract.

The persistence/runtime owner must decide and supply the proper admitted runtime dependency/lock/packaging companions, or reuse an already supported wire-admission mechanism that actually enforces the whole profile. Do not apply this patch automatically, silently require test extras in production, or replace it with per-field coercion patches. Preserve old valid/current/unknown behavior, construction defaults, CAN .2 and both consumer/authority boundaries. No BERL service/summary, conditional law, issuer or C24 authority change is authorized by this schema proposal.

### Remaining corpus/consumer coverage belongs to the same uncompleted LA-034 chain

The new test does not generically exercise every schema-required top-level/nested deletion, empty nested objects, boolean/numeric-slot alternatives, or manifest/profile/member corruption through both real consumers. The unknown version and several raw corruptions are tested only against the wire oracle/DTO, not Runtime and Scientist. The reported four-case existing selector covers current producer/collision/selected-negative behavior; it does not establish the legacy-shaped 1.0.0 payload, unknown-wire/schema dispositions and every new raw-schema corruption through both consumer paths. No authenticated historical fixture provenance is provided. These remain precise acceptance gaps, not a demand to invent support for 0.9.0 or to promote schema success into reliability authority.

Derive the rejection corpus from the actual schema/DTO and use the existing loader and consumers. Assert resolution/content/ref outcomes as well as final status, because Runtime correctly remains subject-not-established even for valid candidate diagnostics. A boolean overall failure caused by another gate cannot prove strict wire admission. These are worked parts of the existing schema/reader predicate class under P40, not independent reasons to redesign BERL.

## Source quality, failure provenance and next handoff

The new Python file parses. Fresh native Ruff check on the exact candidate bytes with logical `tests/unit/berl/test_schema_profiles.py` passes; format check has one `_SCHEMA_PATH` wrapping hunk. Complete outputs are in the JSON receipt. This minor new format delta should be batched with any accepted test cleanup, not given a separate semantic repair ladder. No full architecture/type/resource/wheel/generated/runtime check was run here.

The receipt's “pre-existing/outside changed-input denominator” label for the four Core-to-IR canon-spec failures is **not established under P41 by the delivery**. A current unchanged module rerun and prose assertion that new files were not imported do not provide the exact slice-base deciding command, complete output/readset and empty-intersection proof. I neither infer a product regression nor discharge root's earlier source work as inherited debt. The current composed checkout, including later C41/C48 changes, must receive its own source-qualified proof if/when authorized.

The return appropriately stays inside the schema/test lease and leaves the reader proposal unapplied. With no applied behavior/schema change, omitting a behavioral release/migration/generated update is reasonable for these three diagnostic files. Adopting the companion would change that assessment: its normal dependency, reader, release/compatibility and supported-profile companions then belong to the actual owner, with a fresh source freeze and composed proof.

Next useful checkpoint is the bounded test/receipt characterization plus a clearly HOLD companion and truthful evidence statuses. Recover only the missing deciding artifacts or run their exact authorized replay, establish exact selected refs, complete the old/current/unknown/negative reader routes, and execute genuine matched removals. No product changes or native tests are requested to be auto-run by this review. Source admission, author result, composed proof, G acceptance and formal closure remain separate.

Machine-readable identity, full delivery inventory and complete static-check outputs: `reviews/C73-return-independent.json`, SHA-256 `5d640e6104481656b9d6e6885aca0e04f193c4ac31124a8ad3481ca2e2f50a40`.
