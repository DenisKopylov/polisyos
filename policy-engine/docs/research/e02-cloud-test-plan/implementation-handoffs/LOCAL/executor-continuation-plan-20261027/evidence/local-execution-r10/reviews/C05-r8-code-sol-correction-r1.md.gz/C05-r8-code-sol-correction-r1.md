# C05 r8 Sol review correction r1

**Corrected source verdict: HOLD.** My earlier `C05-r8-code-sol.md/json` GO was incorrect. This append-only addendum supersedes that source verdict; the original reports remain unchanged. Capability remains `verification_missing`; product imports, native tests and removals are UNRUN.

## Confirmed blocking contract mismatch

Frozen r8 `scientist/orchestration/llm/prepared_request.py:49` calls:

```python
decode_json_object(value, kind="prepared LLM request")
```

The canonical shared owner at `common/serialization/__init__.py:297` requires:

```python
decode_json_object(raw, *, source: str, kind: str = "JSON record")
```

`source` has no default. I independently parsed both ASTs and read the exact signatures. The shared definition has SHA-256 `9dd34967d6bb95244085410a5988d326824c017aadb3233db903eab1efb31685` on both pinned base `7382a1c4eb32ee3370dc8f370133449cb95dd0db` and observed Root HEAD `545c6990e2bfa42bf580b475e23cf88df04e71d8`. The composed source retains the same call. If reached, Python argument binding raises the missing required keyword-only argument error before decoding.

This is a **High severity, high confidence implementation defect**. Exact native call restoration, Gateway preparation, simulator configuration, opaque physical-call digesting and accounting-enabled provider preflight traverse the helper. Their positive paths cannot establish the proposed behavior in this state. This is a source binding proof; no runtime exception was produced by this review.

Use the actual canonical decoder with a stable diagnostic `source` at the shared invocation. Preserve its strict decoding. Catching this error as a cache miss or substituting a permissive decoder would not repair the contract.

## Review error and P40 disposition

I checked the representation, hunk identities and literal source census but did not bind this actual helper call to its required signature. I also failed to reconcile the already-existing `C05-r8-code.md` HOLD before issuing my GO. That was a review error. The independent HOLD was reread at SHA-256 `65439448f966f563a19166eddaf5b41683923ed8753344494fc65f502faa1d60`.

This is the **SAME shared-consumer API compatibility class as r6's stale preflight `_request_digest` call**, distinct from the r7 lossless-input representation class. The r8 representation observations remain source observations, but the decoder blocks their executable paths. Hash reconstruction, AST parsing and a literal call census do not establish API compatibility.

The original reports were read back unchanged: Markdown `853adb32bed43964e2580f9b8240e87ee47153dffd4e33fa475c5c78dfa0fef3`; JSON `5d75477e8b1863be3154806dd1eceb0f930401ef379648b7b86fa1a6f9fe2f7b`. Root's published composition was source-only; this addendum makes no claim that Root issued a runtime PASS.

## Broader shared-call inspection

The new read-only `C05-r8-code-sol-shared-contract-audit.py` walks the complete pinned `policy-engine/src/**/*.py` blobs plus exact frozen overlays, then inspects **every added-line-intersecting AST call in all 19 source Python postimages** (18 mechanisms and the facade). It resolves literal repository imports, same-module functions, module attributes and same-class calls to source signatures.

The measured denominator is **2,828 candidate source Python files**. Its **560 changed call sites** comprise **143 explicit-argument compatible**, **one confirmed mismatch**, and **416 unresolved**: 374 dynamic/external/receiver cases, 36 generated/inherited constructors and six star expansions. The confirmed mismatch is the decoder above. Unresolved rows are not passes. The complete audit JSON is retained with script SHA-256 `fc8297d8efe5a453123a182bce67b0e21988bc08420cf99692662a32c87ec14e` and receipt SHA-256 `2e59a6a19228f4294ba55c1213f65bb039bb50e90641306977668005003b644e`.

The script also walks changed signature-name candidates over the complete source. Those name-only matches include unrelated owners and nested helper names; their counts are navigation, not proof of actual consumer identity or an absence verdict. Dynamic receiver types, generated constructors, decorators, star-expansion values, lexical alias ambiguity, tests, other languages and runtime protocol semantics remain unresolved by construction.

I separately inspected the actual prepared-provider family, native value/result constructor fields, cache digest callers, begin/observer/guard/on-close callback shapes, Runtime producer artifact writer, ledger resolve/list readers, and imported manifest/model validators against their concrete signatures. No additional concrete signature mismatch was found in those inspected shared contracts. This does not green the unresolved set.

## Deciding evidence after the forward repair

Root must first obtain a passing positive native baseline on the repaired, composed source, including exact/prebound input, opaque original values, actual Gateway JSON, real provider-preflight and research POST consumers. Preserve the genuine reuse, physical-count, actual owner and cancellation assertions.

Only then count a property removal: it must fail at its intended semantic assertion, rather than at this same setup-time argument error. Restore exact source and pass again, retaining full command/output/source/backend readback. Type, architecture, API, generated and compatibility checks remain Root-owned and UNRUN here.

Correction evidence: `C05-r8-code-sol-correction-r1.json`, SHA-256 `28d3587bc2939890e7f96397ef130da8dde33e638fa6e4a24bb400124e4ae96a`. No canonical source, tests, environment, Git index/object/ref or branch was changed. Only new RAW review artifacts were written. The author's separately frozen forward fix will receive its own delta review; neither this correction nor the original GO will be rewritten.

Pattern pass: P29/P32 non-vacuous behavior; P31 shared consumer; P35 bounded complete denominator; P37/P38 actual signature rather than API shape; P40 same-class disposition; P41 no inherited-red claim.
