# C05 shared decoder: actual native receipt review r1

**Qualified actual runtime PASS for these seven decoder cases only: 7 passed, 0 failures, 0 errors, 0 skips.** The recorded source is `8623b3908bb3317060e84f2db7857a971e8887f7`, tree `2bd8450b2b4b5c283ba7840e13ef06abb2a9beed`. No reviewer product imports, tests or native processes were executed.

The target is `deep-task-status-audit-20261027-r1/c05-shared-decoder-native-r1-20261028` under the existing native-priority RAW directory. Its audit SHA-256 is `af4d5c9627537311a03671976c4989ed53609870adce8d211af81dabec112bd8`; parent Git/readback receipt SHA-256 is `c1aeedba764ec170053b42ebb2034debb866a0b012ab56c9911c4420801f7c25`.

## Exact executed cases and outcomes

I parsed every JUnit testcase and suite attribute, matched the names to the two selected canonical node IDs and the literal six-case parametrization in Git `8623b390`, and found no extra, duplicate, failed, errored or skipped case.

| Case | Actual outcome |
| --- | --- |
| `test_prepared_values_use_the_real_strict_decoder_contract`: real wire and native tuple/list round trip | Passed |
| Strict refusal: malformed UTF-8 `\xff` | Passed |
| Strict refusal: duplicate keys `{"same":1,"same":2}` | Passed |
| Strict refusal: nonfinite `{"value":NaN}` | Passed |
| Strict refusal: overflow `{"value":1e1000}` | Passed |
| Strict refusal: non-object root `[]` | Passed |
| Strict refusal: truncated `{"missing":` | Passed |

The exact full canonical IDs are retained in the review JSON. Stdout reports `7 passed in 0.36s`; stderr is empty. Controller and phase records agree on return code 0, complete execution, no abort or termination signal, and process group gone. Supervisor wall time is **4.222839 seconds**; JUnit suite time is 0.310 seconds. These timings measure different layers and are not a performance benchmark.

All four process samples were read. Recomputed sample RSS sums/maxima agree with **141,705,216 bytes maximum sampled process-tree RSS**. This is a sampled maximum, not a continuous peak measurement.

## Source and native-profile binding

The complete runtime observer denominator is the **96 unique imported `.py` paths** in `readsets/input-readset-73095.json`: 89 under `src/polisyos`, seven under `tests`, and none under `tools`. I walked all 96 records and independently compared each recorded SHA-256 against the Git `8623b390` blob, current index blob and working bytes: **zero mismatches**.

The counted set is produced by `readset_observer_tools_r1.py`, SHA-256 `45db8cc07483a583d6c9029e0c3e5197f6a01ab905cac7948d072ef422d74a49`. It selects runtime-loaded repository Python paths from `sys.modules`; unimported source, external packages/native libraries and arbitrary parser/plugin inputs are outside that denominator.

I read the launcher, sandbox profile, runner and observer source, source/profile freeze, complete controller/phase records, and process samples. The frozen command uses the normal `pytest.ini` importlib/strict-marker profile and default plugin autoload, with one read-only observer added. The runner clears ambient import/plugin switches, redirects outputs and caches to the case directory, and uses `-B` plus a fresh private empty pycache search prefix. This does not enumerate or certify the installed external plugin/native-library inventory.

Plan/profile/readset/source-frame hashes and before/after guard identities agree. All three selected product/test source pins match the committed target. The four exact Root-owned generated `.pyi` WIP hashes agree with the recorded source frame and working files and are outside the 96 observed Python paths. This is not a whole-tree Git-clean claim.

At review, Root had advanced to `ea3d65682d76a5d66d514e525ad2212e5a85f669`. The historical `root-live-ownership` metadata pin consequently differs from the current mutable metadata; all other selected pins and the 96 Python paths still matched. The qualification remains bound to `8623b390` and does not transfer automatically to later changes.

## Regression evidence and limits

I separately read and hash-verified Root's same one-call helper reproduction: receipt `7429c37e3725177ce8f9d02e89c3ac6a34c913562f7ac61c5750bb56b05b76cd` records exit 1 with the actual missing-required-`source` TypeError on `545c6990`; receipt `a204e2bcc2f81a0c03ed6c71c8d95710d213f2fdba453036ae32f87442818262` records exit 0 and the same child's round-trip PASS on `8623b390`. The native seven-case run adds real pytest positive and strict-refusal coverage after that forward repair. Prior source-review corrections remain preserved.

This qualifies the decoder compatibility smoke. It does not establish the full 14-module C05 suite, HTTP/preflight/cache flows, authorization/cancellation/lifecycle behavior, semantic removals, type/architecture/generated/API/compatibility gates, G acceptance or any formal closure. Overall C05 capability remains `verification_missing`.

Independent review JSON: `C05-shared-decoder-native-r1-actual.json`, SHA-256 `6556e3a4fa1aa40ad6f7ae62864c373e643982301ad17f65d267909f1548bad1`. It references exact retained evidence bytes without copying the raw logs. Only these new RAW review files were written.
