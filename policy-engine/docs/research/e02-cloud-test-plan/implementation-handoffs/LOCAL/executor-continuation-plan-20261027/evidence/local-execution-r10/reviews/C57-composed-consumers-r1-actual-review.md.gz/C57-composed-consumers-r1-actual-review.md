# C57 composed consumer wave r1: independent actual-run review

**Verdict: HOLD for calling the 183-case affected wave green.** The exact run has three failures and four expected PostgreSQL skips. The failures cluster into two causes; source evidence does not yet establish that either is a C57 publication defect. Resolve the timestamp and progress-state contracts, then rerun the affected wave before qualification.

## Source and run binding

- Source: `575432f281aeec5dbe89e906cd2545fcd2bc4087`, tree `8107f2cbbdbb39d0861134a0ff5f47b19025ef57`.
- Plan: `policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1/c57-composed-intent-diagnostic-consumers-r1-20261028.json`, SHA-256 `85db9f1ada38c7dc2a5f4285989c45d913cb102a44dd7bf8c3de865704ce5204`.
- Audit SHA-256 `e5ad17f5a0005c5999845deec041a397ded5e538dfe3783013aa0494f2aaa1c9`; JUnit SHA-256 `f68a205450d698eb33a076e986129652057b13c8af7adac0fa973c313fe27173`; stdout SHA-256 `38ba689b12bfdd166e7edb50e37818c00e6120bb498e3187d64be25ac6ffee9e`.
- Freeze SHA-256 `2db55d3ce304c02e1845b8716a7c048b6666b047a12a26425f0a7be2a1b68bf1`; readset SHA-256 `53b099990199b07f595f53be78645fe9981432463525c4f03ff7c20d9d365b99`.
- Root Git readback SHA-256 `f296e7a4f444c23c847aaba6370f49acf314694d45e51b6b7a5018c72ea737eb`.

The JUnit and stdout agree: **183 tests, 176 passed, 3 failed, 0 errors, 4 skipped**; the command returned 1 after 33.715 seconds. Maximum sampled process-tree RSS was 1,136,574,464 bytes, below the 2,415,917,904-byte cap. The four PostgreSQL cases skipped because the dedicated disposable DSN was absent; they are not product passes. The run includes the full 151-case C37 module cohort and seven event-log consumer tests, all passing, plus the 25-case C57 publication module (18 pass, three fail, four PostgreSQL skips).

I independently matched all 1,932 readset paths to present, tracked worktree files with identical SHA-256 values (1,884 `src`, 28 `tests`, 20 `tools`), and all 22 frozen selected-input pins. The Git readback binds the same HEAD/tree and reports zero index/work/readset mismatches. This is the observer's finite Python set; unimported source, external packages, and native bytes are outside its denominator.

## Three failures, two causes

1. **Two SQLite timestamp assertions share one precision class.** Both `pending-sqlite` and `failed-sqlite` fail at `test_control_job_admission_publication.py:201`, where the test asserts `diagnostic.created_at >= source.created_at`. The persisted source lifecycle row has microseconds (`03:22:50.456341` / `.496445`), while the diagnostic record timestamp is second precision (`03:22:50`). This follows the existing Store code: `_utc_now()` truncates microseconds (`control_plane_store.py:118`), `append_event` writes source `created_at` with microseconds (`:5215`), and `append_diagnostic_event` records its row time through `_utc_now()` (`:7839` onward). C57 also sets `diagnostic.event.event_time = source.created_at` (`:4268`); the preceding exact-equality assertion passes. Diagnostic listing is documented as append order and uses `row_id ASC` (`:7923` onward), not `created_at`.

   Thus the failing comparison does not establish SQL insert order under the current timestamp contract. If `ControlDiagnosticEventRecord.created_at` is required to represent a post-source append time at subsecond precision, the current value violates that requirement and needs a producer-side precision decision. If event time is the bound source time and `row_id`/transaction order represents append order, the test is asserting an unsupported cross-field comparison. Treat the temporal contract as unresolved until the owner makes that choice; do not dismiss the observed timestamp discrepancy.

2. **One cancellation progress-state assertion exceeds the current state contract.** `test_fast_worker_or_cancellation_cannot_be_overwritten_by_late_admission_progress[cancelled]` fails at line 480 because job state is `cancelled` while `progress["state"]` remains `pending`. The existing `cancel_job` owner changes `control_jobs.state`, preserves existing progress, and adds a typed `progress["cancellation"]` object; it does not rewrite `progress["state"]`. `ControlJobResponse` separately exposes authoritative top-level `state`/`execution_status` and documents `progress` as an open projection whose evidence must be validated. The test's later `current.progress == terminal_progress[0]` assertion passes, so the no-late-overwrite part of the C57 race witness holds; the additional requirement that a generic progress field mirror cancellation is not established by this contract. If that mirror is required by a product surface, implement it in the existing cancellation owner and test it. Otherwise assert authoritative `state == "cancelled"`, cancellation disposition/physical-stop status, and preservation of admission diagnostic links without requiring `progress["state"]` to mirror.

The cancellation fixture uses `_sql_cancel` and a synthetic `cancellation_request_scope`, not the HTTP cancellation route or its authorization path. It also cannot establish physical process/provider stop. The separate authenticated-launch case covers launch proof binding, not cancellation HTTP authorization or the full B56 contract.

## Disposition

The seven-case pilot remains valid for its bounded result: its five exact C37 failed selectors passed, as did the completed-worker-before-enqueue and SQLite CAS-versus-other-job-cancellation witnesses. This broader 183-case run does not upgrade that pilot to full C57 acceptance. PostgreSQL, full B56, production currentness, physical-stop semantics, G acceptance, and closure remain unestablished. No tests were rerun for this review.

Pattern pass: P29 (the failures are behavioral), P37/P38 (the timestamp and progress predicates require explicit contracts rather than adjacent markers), P40 (two timestamp parameter failures are one class; cancellation projection is separate), and P41 (results are bound to the exact 575432 source cut).
