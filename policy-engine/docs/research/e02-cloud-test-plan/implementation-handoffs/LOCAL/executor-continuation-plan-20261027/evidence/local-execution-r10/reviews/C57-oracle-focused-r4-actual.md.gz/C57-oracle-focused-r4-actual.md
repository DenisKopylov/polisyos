# C57 r4 focused native execution review

**Verdict: bounded GO for the six focused C57 r4 cases on source `7382a1c4`.** The retained stdout and JUnit show both corrected SQLite timestamp cases and all four fast-worker outcomes pass. The run is correctly bounded to the changed oracle and its sibling state controls; it does not convert the earlier 183-case wave into a green result or establish PostgreSQL, removal-probe, G, or closure acceptance.

## Frozen source and evidence

- Plan `policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1/c57-oracle-focused-r4-20261028.json`, SHA-256 `57955869835435d465f32b5cc1e016c09fe092a02348bd232c92c0329230c717`.
- Source `7382a1c4eb32ee3370dc8f370133449cb95dd0db`, tree `b3840419a81bad0f96c933ff1cf920b76efb6d96`, parent `575432f281aeec5dbe89c906cd2545fcd2bc4087`. The commit contains the reviewed C57 README/test and a separate repo-quality generation test; the executed selectors are all from the C57 module. Its test-module blob SHA-256 is the reviewed r4 postimage `f271b80810b566c306fd873ca0f5dc7cac200b77936640e594794b224eed5c54`; the README blob remains `07f47a1291b2c80c810ffee67de5f505832f6a5fe35f0bfae7d0d9652a6588c7`.
- Audit `.../c57-oracle-focused-r4-20261028/audit-result.json`, SHA-256 `6b20bada807825932408bd0d01a5f9bc390127c74f366d811a8537f3e5555860`.
- Full pytest XML `.../c57-oracle-focused-r4-20261028/pytest.xml`, SHA-256 `120ad9cad0ae566f98260326607c8a611a2bcced11a17e850a8e668c3430f44b`.
- Complete compact stdout `.../c57-oracle-focused-r4-20261028/c57-oracle-focused-r4-20261028.stdout.txt`, SHA-256 `35970edb3debbb59ccbcbe5be9b50ed7cdd33723c1bbb4446b4b224b863b232b`; stderr is empty.
- Full finite imported-Python readset `.../c57-oracle-focused-r4-20261028/readsets/input-readset-51668.json`, SHA-256 `01bd8ee403fe84e75ea88bd7b8e22a8dfbd6a0d586ca72de84b10d2deaf63d43`. It records 1,814 paths (1,800 `src`, 14 `tests`, 0 `tools`). The paired Git readback `.../c57-oracle-focused-r4-20261028-Git-readback.json`, SHA-256 `f8f5956b8707c0bf36515dd230866dac3beb42944aaaeb99598aa620dfb72e70`, binds the same source/tree and reports zero Git/index/work mismatches. Direct checks confirm the readset's changed test and C57 Store/service source hashes match the frozen source. This is the observer's finite imported Python set, not a repository-wide or external-package census.

## Actual result and semantics

JUnit reports exactly six cases, with zero failures, errors, or skips:

- `pending-sqlite` and `failed-sqlite` actual-recording-time cases: both PASS.
- `running`, `completed`, `failed`, and `cancelled` fast-worker cases: all PASS.

The candidate keeps `diagnostic.event.event_time == source.created_at` and source payload identity while comparing `diagnostic.created_at` to the actual stored SQL row value. The Store owner uses whole-second UTC recording time, a separate role. The six results therefore demonstrate that the corrected oracle passes on the actual retained SQLite path without loosening precise phase/source binding.

The cancellation case passes through a fast actual `ControlWorker` dispatch before admission resumes. It checks the full post-owner progress snapshot survives that later enqueue write; verifies the cancelled row through the cancellation source-event/outbox reconciler; and requires response `state` and `execution_status` to equal the row, with `publication_fenced` and `physical_stop_status=not_established`. Its helper remains a SQL-isolation fixture, not an HTTP authorization test or proof that physical work stopped. Full response-progress equality is only asserted for cancellation, preserving the existing completed natural-language projection decoration.

The audit records return code 0, complete process-group exit, empty stderr, 1814 loaded Python paths, no readback mismatches, 25.7617 seconds supervisor wall time, and 1,103,282,176 bytes maximum sampled process-tree RSS against the run's 1,610,612,736-byte cap. Pytest's own stdout says `6 passed in 1.72s`; the JUnit case durations sum to its reported 1.314 seconds. These are different timing scopes, not contradictory results.

## Limits and next step

This qualifies only these six SQLite/native nodes on the pinned source. It does not rerun the unchanged 151 earlier C37 cases or seven event-log cases, qualify the full 183-case wave, run the PostgreSQL parameter cases, or execute either r4 removal mutant and restored-baseline replay. The original 183-case receipt remains a separate result at 176 PASS / 3 FAIL / 4 PostgreSQL SKIP on the earlier source. These six selectors include the three previously failing C57 outcomes, now PASS on `7382a1c4`; the other 177 cases, including the four PostgreSQL skips, were not rerun. Do not relabel the original full-wave receipt green. The new removal controls are feasible as two sequential isolated one-selector probes under the same observed resource envelope: one timestamp-reader mutant with the `pending-sqlite` selector and one response-status mutant with the `cancelled` selector, each followed by exact source restoration and the same selector PASS. Their outcomes remain UNRUN until root executes them.

No tests were rerun by this reviewer; no product import, canonical source/index/ref write, or environment change was made. This review makes no G acceptance or formal-closure claim.
