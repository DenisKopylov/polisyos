# Independent actual C60 R4 generated-output review

**BOUNDED GO to root atomically compose the exact four genuine R4 staged stub payloads below, with current canonical preimage and stage-hash rechecks.** The actual defining real-owner test passed. No blocking artifact/source-custody finding. This is not complete C60/B42–B48 runtime acceptance, Ray qualification, canonical-owner freshness, semantic type qualification, source-removal PASS, G acceptance or E02 closure. Canonical `--check` and affected type/import consumers remain later.

Reviewer used read-only source/evidence/actual-byte inspection and stdlib Git/hash/AST/TOML/XML processing. No generator, test, product/helper import, supervisor, canonical/index/ref mutation, or output edit/recovery was performed. Only the requested RAW review Markdown/JSON were written.

## Actual case, profile and source identity

D is `policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1/`. Case is `D/c60-four-stub-owner-native-r4-20261028/`.

Qualified execution source: `7382a1c4eb32ee3370dc8f370133449cb95dd0db`, tree `b3840419a81bad0f96c933ff1cf920b76efb6d96`, attached branch `codex/e02-unified-local-20261009`. The exact test source is SHA `dc6bd31efd9e1fae8270650424adaaa592d6c380687af37678fd0f69a70fe1aa`, the independently reviewed one-test physical-path/content repair. The two other prior PASS tests are not rerun or relabeled new-source runtime evidence.

Verified exact actual locators and SHA-256:

- `D/plan-c60-four-stub-owner-native-r4-20261028.json`: `1751b0b1dbfb516704bebf8f68f63f67886a3cc576f087ff0a710a91fd6b33a4`.
- `case/audit-result.json`: `a6635c9257e119866d38609e4e38baf9cdf2aed5c36c35a292b634cb4da4f531`.
- `case/source-profile-freeze.json`: `75d3c60cf50852da52a7d208741d97752b17f32566d005b0a87547622624257f`.
- `case/pytest.xml`: `03f2436b179771181b8318bd6b03bee05eccac03330a0c64fce5219afa4a88d0`.
- `case/c60-four-stub-owner-native-r4-20261028.stdout.txt`: `d28e6b3a20fe31b9eb21044c972b21d183b217e9de6fe9d80576c4a725c90973`; stderr is empty (`e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`).
- `D/c60-four-stub-owner-native-r4-20261028-Git-readback.json`: `271617ee44dadd1f226e4a8cb4c4a828035254cf3ee71717debe3b0740c9b901`.

Read the full retained stdout/stderr and XML; independently required the exact classname/name for `tests/repo_quality/tools/test_foundry_stub_generation.py::test_actual_stub_owner_staging_and_check_detect_complete_byte_drift`. Exactly **one PASS, zero failures/errors/skips**, complete=true, return_code=0, no aborted_reason and process group gone. Wall 28.928584417008096s, maximum sampled aggregate process-tree RSS 327385088 bytes, minimum sampled disk 14053085184 bytes. Pytest reports one passed in 25.05s; that is a different scope than the supervisor's wall measurement.

The plan matches the audit/freeze. All **13 selected freeze pins** reconcile: twelve against retained/current bytes, the mutable root-live receipt against the actual retained pre-wave gzip bytes, whose digest exactly equals the launch pin. Freeze before and guard_after remain at the execution source. This does not substitute today's live root receipt for the run's receipt.

Independently read the actual observer readset and checked **all 87 observed Python paths**, not a sample: each recorded digest equals the qualified commit blob, index and current worktree bytes. Distribution is 69 src, six tests, twelve tools; zero mismatches. The observer's own file digest and exitstatus match the actual audit. This is the finite imported parent pytest set; unimported code, child stubgen/exporter imports and external package/native-library bytes are not observed. The installed native default-plugin configuration/retained interpreter/startup mapping was the reviewed profile; this record does not convert metadata or process sampling into complete external execution provenance.

Root has since advanced normally to `b8fcda7332c89609410e8ca936b472ef2eed43e1`, tree `bcc0766ff9eae30e3bbeda86631bbcf79eae3c7a`. The complete four-path C48 advance has zero intersection with the observed 87 Python paths, the explicit 40-input native basis, and four canonical output preimages. All 40 physical basis inputs still match with only the known repaired-test override. Current tracked/index state is clean and all four canonical preimages still equal execution-source/index bytes. This allows exact artifact composition to proceed without resetting to the run source. It is not a claim that unobserved child imports are identical; the later actual canonical check/import consumers qualify the current composition.

## Real owner/probe substance and complete staged outputs

The unchanged generator SHA is `6cdbee185e6c7d0d9fba9a8249202fc860f0da10da5f8da3f6536659ebe45289`; unchanged measurement owner `tools/lib/fs.py` SHA is `0ddf42f824ddfe55386f5d5d63b39cacfb53f73dad03d8d2158f19a6b9a15119`. Read actual current owner/test source. The complete real OUTPUT_MAP was independently derived from its AST and reconciled with the actual TOML family. Exactly four selected output paths; no second sampled/hardcoded owner denominator is used for the census.

The passing actual test traverses all seven real owner calls: staged generation, initial check, full corruption refusal, restoration check, selected missing error, selected directory/unreadable error, and final outside-selector positive. Each call renders base and canonical composer with the real stubgen branch and uses two owner reexport payloads: fourteen child-invocation branches on complete traversal. This statement follows the qualified actual test PASS plus unchanged branch/call source; it is not a claim that sampling recorded all fourteen distinct child PIDs or their reads.

The repaired oracle resolves receipt labels against the real owner root, checks exact physical selected-read set equality and every actual corrupted/restored full payload's length/hash, requires all STALE paths, and requires exact physical unreadable victim/error without invented bytes/hash. Its final positive also proves an actual outside file is absent from all measured operations and canonical outputs remain unchanged. Those are real behavior/content assertions; the run is not dry-run or marker-only. Internal captured Measurement JSONs are asserted by the passing test, not separately retained raw receipts in this case; the reviewer does not claim an independent row-by-row raw-receipt replay unavailable in the retained stdout.

Read every actual selected staged byte and syntax-parsed every file. Stage root is `case/basetemp/test_actual_stub_owner_staging0/staged/`. Full stage .pyi census has five members: four selected real outputs and exactly `unselected.pyi` with the known outside-selector fixture bytes. Only the four selected payloads are admitted:

| Product-relative target | Bytes | Exact staged SHA-256 |
| --- | ---: | --- |
| `src/polisyos/foundry/methods/base.pyi` | 7312 | `80331b6912bdf9fa470011ba566bca95de80038a9566838be5fbf97fe64904c3` |
| `src/polisyos/foundry/methods/registry.pyi` | 58 | `57f3509e55e92e57e7c5cc3fd6f257c0ff433bfefcb3d6286747126eae1377ef` |
| `src/polisyos/foundry/methods/composer.pyi` | 59 | `46d5d113361d487abf5cef5c85f88b8bbe1cd22f70ba266d763a1deb4aa4e781` |
| `src/polisyos/foundry/methods/components/composer.pyi` | 5086 | `d7efa8503e09b906344545786093cad72bc5a73e5a8dc46e9b4b8bf6ae9c760b` |

All four differ from canonical preimages, are real non-symlink files and contain none of the corruption class payload. The exact locators/preimage digests are recorded in companion JSON. Their eligibility comes from the full successful real restore/check path, qualified source and actual byte readback; marker absence alone is not the oracle.

Reviewed the complete four-file generated delta. Base AST is equivalent to its existing canonical stub after import-order normalization; changes are formatting/quotes/layout. The two facade files exactly equal the existing owner's declared one-line star reexports. Their actual owners have explicit __all__ (registry ten names; canonical composer seven), so these are canonical typed bridges rather than new implementation owners. The canonical composer output reflects current source: SemanticValidationLevel, ValidationContext and reconcile_validation_context exports; actual defaulted node/DAG/chain fields, extra predecessor/freeze/parallel signatures, concrete SlotLinker and validation-mode annotations, validation_context/linker_config/cache fields. All seven public exports and public annotated fields across the five relevant dataclasses match current source; private insertion bookkeeping is correctly not a public field requirement. No new issuer/status/authority claim or invented ABI is inferred. Type/import compatibility still requires its later actual checks.

Old R3 stage is separate. Independently reread all four old payloads against the frozen evidence hashes: all remain exactly corrupted and ineligible. No marker stripping, recovery, hand-edit or silent reuse occurred. `unselected.pyi` is also excluded from root composition. Only the four genuine R4 payloads above may be copied unchanged.

## Resource/concurrency context and remaining gates

This actual run overlapped the separately isolated C57 focused case under root's explicit new admission, not a claimed solitary performance measurement. `LOCAL/raw/e02-execution-20261027/root-oracle-replay-wave-r1/admission.json` SHA `5dcb1d03dd699aefec3676b23429c0328fe3f091154bd5d6df7b35c5e62ecfe9` records the 2.25+1.5=3.75-GiB aggregate caps, one numerical thread per pool, distinct scratch/fixture roots, immutable source lease and no unknown C38 concurrency. Retained disk/RAM/swap stdout exists. The two actual individual sampled peaks sum to **1430667264 bytes** (327385088+1103282176); this conservative sum of separate sampled maxima is not an observed synchronized whole-machine RSS census. Both source-frozen cases completed without resource abort. C57 semantic results are not reused as generator evidence, and these measurements grant no six-family/resource blanket waiver.

P40 disposition: the known same-class P38 path oracle now has actual PASS on the real staged path. No new blocking class was found. The declared finite observer/external/child-read/type boundaries remain limits, not another repair round. Source-removal mutants remain UNRUN; staged corruption controls are distinct from removing the source comparator.

Root may use its retained atomic new-inode writer to compose exactly all four stage payloads with the JSON's canonical preimage/stage-hash checks, ordinary hooks/commit, and committed-blob readback. Preserve output bytes unchanged; if a hook would rewrite them, that is a concrete new byte delta requiring owner agreement, not permission to report these hashes as published. Then execute the actual owner `--check` on canonical outputs and affected type/import consumers against the resulting source. No broader criterion/G/closure status changes follow from this bounded artifact GO.
