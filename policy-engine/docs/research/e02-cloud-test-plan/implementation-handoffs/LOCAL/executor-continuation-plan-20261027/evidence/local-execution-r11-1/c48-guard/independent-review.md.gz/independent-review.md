# C48 literal-root metadata guard: independent delta review

**Verdict: bounded harness/preparer GO. No blocking finding.** Root may run the fresh R5 guard/preparer sequence and the already authorized native attempt under the reviewed recipe. This does not establish a target PASS, C48/C53 closure or G acceptance.

Packet `repairs/C48-root-metadata-guard-r1/manifest.json` SHA-256 `231aa31f7f42ebcefb54a459b2ef308080b29f395a1770c527e97f17b28f9d6e`; guard `919e052ec0ae59805a80c03549a96f4b89b7baa2852ba4b06ae7e9790cfd671d`; preparer `3a324276645ec738cb111aa3c2010c686d0174c2ea7acab156bbefe54d88d7fc`; production fragment `e32b29d96c194caa1b6d22981823771d1f3b618dd5c73d4956f61bde4fb2f6db`.

Observed canonical source is clean/attached at `a437f597212cc7cc6dcb1c60fff9fb018ce43fe0`, tree `bdbc4ede0bd0607c74a293a4a8cc95024bfd6b6e`, branch `codex/e02-unified-local-20261009`. All 99 expected source/explicit-absence rows match both live and that current commit. The frame is byte-identical to the reviewed C71 successor (`6212cbd8761b14e223724dc2d4a61a3e2d78c0543dad51c8f24cdb1d42070b76`); all four RAW runtime pins match. Installed R3 is unchanged at `b15b573c4b7854dddd3cdd55933fd4634d013cbe1410dd1cf965d6bdaff53243`. No source/control reimplementation or fixed-HEAD condition is added.

## Actual failure and property

I read the retained R4 stdout/stderr, audit, XML and profile freeze. They bind to audit SHA `3ba32d3588b47e582087e7e74919d4cf77e3b6a1fded0b67250a3fad411cee2c`, XML `e44264ec3b6b1ca3c2f6c9731897e5cd6e0f277b21f56362d99121548424f5fb`, freeze `f19a9d90a05c388692a84d79373ceb879410ba46faae153594b87599ebda0907` under the retained D `c48-two-source-composed-r4-20261028` case. R4 returned 4 with one collection ERROR before the selected target; it did not establish a product failure or any target assertion. Its measured collection/process resource receipt is not an estimate for the complete target.

The installed caller confirms the seam: `_pytest/pathlib.py:971` invokes `DirEntry.is_file()` while scanning the project directory; `_pytest/main.py:557-558` then classifies directory entries before selecting the requested child path. The broad known-production read rule blocks root metadata at that initial classification. This is an infrastructure policy mismatch. The installed `_in_venv` helper catches descendant-probe `OSError`; no new descendant metadata grant is required by that inspected path. This is bounded caller inspection, not a claim about every plugin or pytest version.

The revised property is `literal_roots_metadata_only`. Independent complete fragment reconstruction confirms that every prior network/read denial is retained and **exactly two allow rules** are added: `file-read-metadata` with `literal` matching the known lexical symlink root, and `file-read-metadata` with `literal` matching the exact physical root. There is no subpath metadata allow, file-data allow, listing allow or descendant allow. Root metadata itself is intentionally permitted; it is not described as universally nonsensitive.

The change is not justified by a general assumption about Seatbelt allow/deny precedence. The actual synthetic diagnostic below exercises the precise profile and operation distinction. Any later actual attempt to list/read protected content or stat descendants must remain refused; do not widen descendant permissions merely to obtain a target result.

## Exact programs and retained diagnostic

All 12 support pins match. Independent in-memory replay reconstructs both new complete programs from their approved predecessor using `check_single_guard-delta.patch` and `prepare_plan-delta.patch`; both ASTs parse. The guard delta changes only the two literal rules, the expanded stdlib controls and receipt description/schema. The preparer changes guard digest, the exact expected fragment, diagnostic schema/12-result expectation and the plan's explicit guard-property description. Its existing source/ancestry/clean-state/RAW-pin, known-link, same-case receipt/code/profile, disk and exclusive-case/plan checks remain intact.

The unchanged R3 still constructs and checks exact full profile/fragment bytes and hashes before its sole child sandbox, retains them in the freeze and post-run pins, and preserves the monitor/observer/native pytest profile. The source frame, installed runner, resource limits and actual Graph inputs are unchanged.

I reconciled but did not rerun `guard-infra-root-metadata-r1-20261028/receipt.json@d98b99acfc864d90257831e55e1f2244861b93561b8147ef5f720fff591df117`. It records one sandbox, isolated stdlib `-I -S -B`, return 0 and empty stderr. Its child code, command, complete synthetic/production-fragment texts/hashes and retained fixture files all match. Its complete 12-result expectation equals actual stdout:

- Physical and lexical roots: `stat`/`is_dir` positive; symlink `lstat` identifies the alias; parent `scandir` followed by both `DirEntry.is_file`/`is_dir` classifications succeeds.
- Direct and alias payload reads: denied with EACCES/EPERM.
- Direct and alias descendant `stat`: denied with EACCES/EPERM.
- Direct and alias root `listdir`: denied with EACCES/EPERM.
- Sibling read and inside-output write: positive; outside-output write: denied. Its target remains absent and the allowed output has the expected bytes.

The child receives only owned RAW fixture paths. Production addresses are serialized as policy text and checked as known symlink metadata, not opened as content. These measurements establish the synthetic operation separation on this host. They do not establish universal arbitrary/private read absence, every native package's behavior or a target result. No network syscall/port/message was used, so actual network denial remains `not_established` even though `deny network*` remains in the exact policy.

## Root next step and limits

Use fresh `c48-two-source-composed-r5-20261028`, preserving R4 and all earlier failed cases. Root rechecks the current source/ownership guard, clean attached/index state, exact installed R3 and native-resource lease, then runs this successor directory's guard and preparer. The new preparer rejects an old guard receipt lacking the exact new code/profile/schema/results. It binds the actual full child profile and fragment into the new exclusive D plan. Launch R3 directly with the established minimal environment and **no outer sandbox**.

Actual target collection, two real completed source workflows, separate planner/fresh GET, independent means1/2, B frontier, environment-plan lineage and candidate-only/revalidation assertions remain to be run. Later native failures must be classified from their actual path; this metadata review does not predeclare them product failures or successes. Provisional 600s/2,415,919,104-byte sampled RSS and 6 GiB free-disk limits are unchanged and are not measured target needs.

P29/P33: actual operation positives and payload/listing/descendant negatives; P37/P38: byte-recomputed literal scope plus retained synthetic observations rather than a broad-read proxy; P40: preserve the known-path boundary; P41: retain R4 collection ERROR as infrastructure evidence. Earlier C05/C71/source/harness reviews and authority limitations remain intact. This reviewer ran no product import/test, native target, sandbox/network diagnostic, generation, removal or G action. Only this authorized RAW review artifact was written and read back.
