# C83 — standalone C05 native verification and bounded owner repair

Requested author model: **Sol**. The actual scheduler/model is `not_established` until a real scheduler receipt names it. This request is not evidence of which model ran.

Your task is to verify the complete C05 cache/client/session/lifecycle mechanism on the exact published source below, repair a real defect only within the bounded existing C05 owner chain when necessary, and deliver reviewable source plus complete deciding evidence. Do not launch another task, ask for midrun follow-ups, delegate, or wait for private local material. You have everything required in published Git and the inlined instructions. The human/Root will review your final delta; your own analysis is author review, not independent acceptance. No E02/G/global closure is requested.

## Exact portable input and transport first

Repository: `https://github.com/DenisKopylov/polisyos.git`.
Immutable input topic: `codex/e02-composed-progress-20261028-r5`.
Required input commit: `ea3d65682d76a5d66d514e525ad2212e5a85f669`.
Required complete tree: `7c5412fddc4ef3e56c859b83d237162e0fd260e7`.
Product: `policy-engine/`.

This carrier contains all 37 composed C05 paths, the required canonical decoder-source forward fix and C71's typed observational-source/derived-writer context. Earlier carrier r4 at545c had a real missing-required-keyword defect and was NOT a passing result. Do not start from it, an old cloud candidate, a local RAW postimage, or the carrier's branch name without checking commit and tree. Fetch/read the exact remote topic using the environment's ordinary Git support, verify `git rev-parse HEAD` and `HEAD^{tree}`, attached task branch and physical product path, and record a clean starting source state. Keep the input topic immutable. Work on the task/output branch using ordinary append-only commits; no reset, rebase, force push, historical rewrite or hook bypass.

Before dependency installation or expensive tests, check and prove the ordinary result-transport path using a small committed `preflight.json` carrying source identity, toolchain/resource facts and test status UNRUN. Prefer normal push to your task branch plus actual remote commit/tree/file readback; if the platform supplies a different ordinary commit/diff artifact transport, prove that concrete supported path with the small bytes first. If neither can be established, return a precise transport block before consuming the native wave. No CI/workflow, encoded upload fragments, self-executing automation, or network workarounds. A local hash or a claimed delivery capability is not remote byte delivery.

Do not require or copy any Root `D`, `LOCAL/raw`, source-frame, receipt, environment, DB, credentials or ignored fixture. Their prior observations are not inputs to this commission. All tests and fixture builders below are in Git. Synthetic loopback prices demonstrate the actual accounting path, not provider invoices or institutional permission.

## Read the actual owners before work

Read root `AGENTS.md`, `policy-engine/CONTRIBUTING.md`, applicable nested instructions and package READMEs. Open `docs/reference/policy-design-case-failure-patterns.md` before design and before final handoff. Follow reuse-existing → extend → consolidate. Relevant patterns: P05/P12 actual ownership/producer handshake; P29/P32 real behavioral evidence; P31/P33 whole class and adversarial variants; P35 complete denominators; P37/P38 actual predicate versus normalization proxy; P40 bucket before repair; P41 do not call a failing gate inherited without actual base isolation.

The public C71 context is documented in `policy-engine/docs/reference/runtime-observational-source-access.md` and the Runtime services README. Source tenant A is provenance. A real shared read grant to job B does not make A the derived-artifact writer: the actual admitted B writes. Core checks current blob and exact selected-view ownership; Runtime reconciles the typed request/current job/authorized reader with the actual enforcing owner. This is byte-read custody, NOT protected TC, publication authority or institutional permission. Keep C38 protected authority refusals. No C71 source-access rewrite, source made unscoped/public merely to green a fixture, fake grant, bypass of observation grounding, or new issuer is authorized here. The carrier already contains that separate owner. If an actual C71 boundary blocks a test, record its exact request, route/result, persisted job and refusal; distinguish an external owner issue from a C05 defect without weakening it.

C05 source of truth is the existing chain:

- Core `core/llm/cache_settlement.py`, `response.py` and `traced_client.py`: exact Core-owned wrapper registration; response/proof projection; actual begin and terminal producer acknowledgments; local origin reuse proof.
- Scientist `scientist/orchestration/llm/{prepared_request,prompt_cache,gateway_client,fallback_router,simulated_gateway,provider_verification,factory}.py`: lossless call binding, actual transport preparation, app-owned bounded cache/flights, real preflight and request-local trace hooks.
- Scientist engine `budget_ledger.py` and `budget_middleware.py`: durable monetary event origin, returned/read-back pending begin ownership, legacy readers and cross-run reuse admission; actual budget consumer remains wired.
- Runtime `control/{job_nl_execution,producer_basis,run_lifecycle}.py`, `control_plane_store.py` and their existing proposal/publication bridges: current job/actor/tenant/cell/attempt/lease/profile before effects, persisted independent complete producer-begin basis, exact terminal proposal/profile/attempt, fresh GET and debug ledger consumers. Preserve C37 selected queue reader, C49 budget observer, C57 diagnostic creation/cancelled ownership and C71 source custody.

The supplied source-pin table at the end binds the complete 37-path C05 footprint plus the canonical decoder and public C71 context. Inspect actual definitions and callers, not just names. The decoder owner is `polisyos.common.serialization.decode_json_object(raw, *, source: str, kind=...)`. `thaw_wire_object` now supplies stable source `polisyos.scientist.orchestration.llm.prepared_request`; do not relax that owner or catch a missing-signature TypeError as a cache miss.

## Properties to exercise and preserve

1. A saved prepared plan accepts only the actual invoked call. Native exact identity uses complete type-tagged values, raw bytes and dictionary order, independently of cache/evidence normalization and HTTP projection. Valid snapshot A and invoked invalid B with unchanged declared SHA(A) must differ in both directions. Bool/int, integer/float, signed zero, tuple/list and bytes/bytearray distinctions must survive. Mismatch refuses before authorizer/producer begin/wire work, and does not consume a rightful unchanged single use.
2. Actual Python providers retain supported tuple/list types. Opaque/unfreezable objects, aliases/cycles, views, subclasses, nonfinite Python values and excessive depth remain original-object physical-only calls. They acquire no cache equality/immutable payload claim and cannot bind an external saved plan. No user-defined stringification/copy hook or generic JSON roundtrip may substitute old inputs. The actual Gateway separately owns strict finite native JSON; supported sequences become JSON arrays there, raw unknown objects fail there. Existing private cache-control projection remains separate from caller wire metadata.
3. Request identity and dispatch share actual prepared immutable values, URL/headers/configuration/body. Preserve every actual caller wire field, including nested timestamp-like names and cache busters. Only the Gateway's own generated retry nonce is neutral; explicit caller idempotency is bound. Select the actual available endpoint head; alternate outcome or changed response-format success is not reusable under the old requested payload. Health recovery and newly supported format must not hit a prior different successful route/payload. Do not assert an opaque adapter reusable by assumption.
4. The real accounting-enabled preflight uses one actual prepared Gateway request for retention digest and physical execution. Share a cache resource and current durable original reference, with fresh provider/cache/traced wrappers and hooks. Reopen owner/origin before network checks. Positive same-binding second call genuinely avoids one physical completion; it emits a distinct zero-cost reuse event pointing at the original source. Changed owner/run/provider/transport/payload separates; altered/missing origin refuses. Cancelling a waiter must not close admitted physical work before its actual settlement and eventual close.
5. A callback's matching declaration cannot replace a current job/attempt/lease fence. Closed scoped clients refuse NEW physical work; no uncached unowned fallback and no reinstated old lease. Legitimate already-begun work keeps independently captured original ownership through success/error/cancellation. Guard unavailable/timeout fails closed/retryable. Scope/binding close does not wait indefinitely for a timed-out callback lock. Existing limitation: a running blocking dependency thread cannot be forcibly killed and may retain its own bounded worker/mutex until return; that is neither dispatch permission nor a complete basis.
6. Before external producer dispatch, compare actual returned and reopened durable begin receipt ownership, not a reconstructed expected declaration. Preserve the original source across reuse; do not reattest old origin as fresh. Core proof binds the WHOLE allowed response projection consumed by downstream code. Custom cache duck values, fake origins, same-content changed usage/model/provider/raw/tool metadata and shared followers must not bypass actual session/origin proof. Cache/flight/origin entry lifetimes, TTL/capacity/eviction, multi-loop concurrency and shutdown stay bounded. No-key and None/zero modes remain supported uncached. Unknown external sampling defaults, tools and strict independent seeds do not become reusable; do not force temperature0 merely to green an existing producer.
7. Durable ledger status keeps reported/estimated/reuse/unknown distinct, including real zero and unknown amounts. Fresh ordinary API reads join the exact selected terminal proposal/profile and V3 Core run/attempt, reopen actual complete central begin set including the citation sibling, and compare the current ledger's complete owning event set. Missing/changed/foreign-attempt/extra/unobserved-sibling rows withhold reconciliation. Preserve legacy limited readers honestly. Current budget consumers must use the actual canonical validation/owner, not stale copied sums or estimates converted into measured money. Source/currentness/policy permission remain separate.

## Native environment and resource admission

Measure this VM independently: platform/architecture, cgroup/container memory and CPU limits where applicable, physical RAM, available disk, active native processes, Python/tool versions and retained/installable backends. Do not copy Root's macOS timings/RSS or environment. Unknown first profile runs ALONE, one native case at a time, a 600-second deadline and at most2.25GiB aggregate sampled process-tree RSS (`2415919104`bytes), one-second samples, six-GiB free-disk floor, one numerical thread. If this VM cannot safely admit that profile, report the measured boundary; do not begin a knowingly underprovisioned wave or call137 alone proof of OOM. After each actual case inspect measured wall/RSS/exit/collection before admitting the next. Bound bootstrap separately and retain complete setup failures.

Use the actual project Python3.14 baseline and published `uv.lock`. Prefer an existing correct environment. If provisioning is necessary, use the documented frozen workspace/bootstrap or `uv sync --frozen --extra lint --extra test --extra runtime`; inspect actual project optional groups before adding a genuinely required backend. Record exact commands/lock/backend metadata; no source fake modules, dependency stubs, copied environment, narrowed plugin set or pretending missing imports are product semantics. A missing dependency, unsupported interpreter, collection/setup/plugin failure or resource abort is a distinct outcome, not a product-property FAIL or an inherited red without isolation.

Preserve native `pytest.ini`: default plugin autoload, importlib mode, strict markers, `asyncio_mode=auto`, normal conftests and helper plugins. Do not set `PYTEST_DISABLE_PLUGIN_AUTOLOAD`, remove default plugins, use `--ignore`, `-k`, `--maxfail=1`, custom test replacements or reduced parameter sets. Clear ambient PYTHONPATH/PYTHONHOME/PYTEST_ADDOPTS/PYTEST_PLUGINS/PYTEST_DISABLE_PLUGIN_AUTOLOAD/VIRTUAL_ENV before invoking the selected interpreter; preserve the actual installed editable roots and disclose all startup `.pth` bytes and pytest11 entrypoint declarations. Installed declarations are not proof of actual plugin execution. No TS scanner is requested; if you invoke one, honor CONTRIBUTING's frozen corepack pnpm links rule.

Per case create unique private scratch/tmp/cache/basetemp/SQLite/CAS/ledger paths. Redirect bytecode search/output to an empty private prefix and disable new pyc writes, XDG/matplotlib/numba/hypothesis/benchmark caches below scratch. Set the actual supported `POLISYOS_CONTROL_SQLITE_PATH` to that private case if needed; existing fixtures may select their own tmp_path backend. Do not force a different default backend/profile merely to pass a test. Loopback HTTP tests own ephemeral `127.0.0.1:0` listeners; use NO_PROXY/no_proxy for localhost. Unit transports at fake/example addresses are mocked by the existing tests; no real remote LLM, API key, production_data or external permission service is needed. Never supply a real provider credential. Unexpected external network or shared DB writes are a diagnostic boundary, not an invitation to widen the sandbox/permissions.

Use a portable process-tree supervisor, kill the entire case group on deadline/RSS/disk breach and keep the actual controller record/units. Capture quiet full stdout and stderr without truncation, JUnit, exact selected and collected node IDs, source/profile/backend pins and resource samples. A small read-only pytest observer may record collected items and the finite runtime-loaded `src/polisyos`, `tests`, `tools` Python files at sessionfinish; it must not change execution or replace default plugins. Explicitly disclose that this misses unloaded source, child import reads and external package contents. Record actual source/input hashes before and after; no mutation during a deciding baseline.

## Exact execution sequence

All paths below are physical paths relative to `policy-engine`. Run from that product directory with its actual interpreter. Redirect only output locations. Example native shape:

`<python> -B -m pytest -o cache_dir=<case>/pytest-cache --benchmark-storage=file://<case>/benchmarks --basetemp <case>/basetemp --junitxml=<case>/pytest.xml --tb=short --color=no --maxfail=0 <exact selectors>`

A source observer launcher may call the same native `pytest.main(...,plugins=[read_only_observer])` and preserve default autoload. Never run a test copy under an evidence/RAW ancestor; pytest's physical import context is part of the test.

**A. First smoke, alone:**

- `tests/unit/scientist/orchestration/llm/test_prepared_request_dispatch.py::test_prepared_values_use_the_real_strict_decoder_contract`
- `tests/unit/scientist/orchestration/llm/test_prepared_request_dispatch.py::test_prepared_decoder_preserves_strict_refusal_with_stable_source`

Source-derived expectation:7 cases. Actual collection/results must be read back. This proves the exact required decoder contract at runtime before the semantic removals; a failing positive baseline makes all later removal FAILs vacuous.

**B. Priority positive/adversarial component smoke:** use these exact function selectors with every native parameter case:

- `tests/unit/scientist/orchestration/llm/test_prompt_cache_scope_admission.py::test_prebound_snapshot_compares_raw_invocation_before_current_owner_authorization`
- `tests/unit/scientist/orchestration/llm/test_prompt_cache.py::TestCachingLLMClient::test_skips_cache_for_tool_calls_and_freshness_sensitive_inputs`
- `tests/unit/scientist/orchestration/llm/test_prepared_request_dispatch.py::test_prebound_call_identity_preserves_native_type_and_value`
- `tests/unit/scientist/orchestration/llm/test_prompt_cache.py::test_opaque_python_call_preserves_original_values_after_admission`
- `tests/unit/scientist/orchestration/llm/test_prepared_request_dispatch.py::test_actual_gateway_keeps_json_arrays_and_rejects_unknown_before_dispatch`
- `tests/unit/scientist/orchestration/llm/test_prepared_request_dispatch.py::test_prepared_cache_plan_binds_one_actual_client_and_one_logical_call`
- `tests/unit/scientist/orchestration/llm/test_provider_verification.py::test_provider_preflight_records_bound_gateway_completion_and_reuses_exact_event`
- `tests/unit/scientist/orchestration/llm/test_provider_verification.py::test_preflight_uses_its_exact_prepared_request_across_catalog_waits`
- `tests/unit/scientist/orchestration/llm/test_provider_verification.py::test_preflight_negotiated_success_cannot_supply_requested_format_reuse`
- `tests/unit/scientist/orchestration/llm/test_provider_verification.py::test_cancelled_preflight_waiter_preserves_admitted_gateway_settlement_and_close`

Source-derived expectation:30 cases. Then prioritize actual proof/timeout/closed-owner/in-flight controls in `test_cache_owner_admission.py` and `test_control_nl_producer_admission.py`, and real research POST selector `tests/integration/runtime/http/test_r3_pre_admission_attempt_owner.py::test_actual_nl_post_gateway_settlement_reopens_and_serves_same_run` (seven parameter cases). Keep every original physical count, separate owning event, nullable amount, lost-ack reconciliation and fresh read assertion.

**C. Complete full-module deciding wave:** all14 modules in the table below, no selection trimming. Source-derived202 test definitions expand through literal parameter declarations to402 cases; actual collection is UNRUN at commissioning and must be reconciled against full node IDs, fixtures/plugins, XML and outcome counts. The table is an expectation, not a receipt. If grouping modules, record each exact group and run unknown profiles alone; all14 must have complete outcomes. An abort or discrepancy does not authorize silently omitting a module or rewriting expected counts. Capture a complete collection result even on errors.

| Full canonical module | Source-derived cases |
| --- | ---: |
| `tests/integration/runtime/http/test_nl_pipeline_cache_reuse_authorization.py` | 23 |
| `tests/integration/runtime/http/test_r3_pre_admission_attempt_owner.py` | 10 |
| `tests/unit/core/llm/test_cache_settlement.py` | 17 |
| `tests/unit/core/llm/test_traced_client_settlement.py` | 28 |
| `tests/unit/remediation/test_llm_01.py` | 8 |
| `tests/unit/runtime/http/test_control_nl_producer_admission.py` | 8 |
| `tests/unit/runtime/http/test_nl_pipeline_cost_projection.py` | 30 |
| `tests/unit/scientist/orchestration/llm/test_cache_owner_admission.py` | 47 |
| `tests/unit/scientist/orchestration/llm/test_fallback_router.py` | 8 |
| `tests/unit/scientist/orchestration/llm/test_gateway_client_retry.py` | 99 |
| `tests/unit/scientist/orchestration/llm/test_prepared_request_dispatch.py` | 23 |
| `tests/unit/scientist/orchestration/llm/test_prompt_cache.py` | 44 |
| `tests/unit/scientist/orchestration/llm/test_prompt_cache_scope_admission.py` | 12 |
| `tests/unit/scientist/orchestration/llm/test_provider_verification.py` | 45 |

Prefer one complete14-module native pytest process after the smoke is admitted, since it also exposes shared-state/lifecycle interactions. If a measured resource boundary requires bounded grouping, disclose the exact groups, preserve every parameter and outcome, and do not repeat already qualified expensive groups without new source/failure/concern. Unchanged direct-consumer companions are `tests/unit/scientist/orchestration/llm/test_factory_cache_composition.py`, `tests/unit/scientist/orchestration/engine/test_budget_ledger_producer_events.py` and `tests/unit/scientist/orchestration/engine/test_budget_ledger_settlement.py`. If a repair touches their actual factory/ledger contract, execute those full modules too and report their counts separately; a14-module result alone does not establish every legacy-reader or importer contract.

**D. Three isolated semantic removals, only after corrected positives PASS:** all changes are temporary, explicitly declared working-source overlays. Hold exact before/mutant/after source-byte hashes and HEAD/tree/profile; do not call a mutant the pristine Git tree. One mutation at a time, same environment/profile/tests, then exact restoration and a fresh positive replay. Never leave a mutant in final code. Root's old private patch files are not required: the exact existing function anchors below generate the controls from this public source. Count each anchor exactly once before editing; retain the actual diff, bytes/hashes and complete outcomes. If a genuine repair changes an anchor, derive an equivalent removal of the same property from the actual implementation and explain the exact executable difference; do not use a no-op marker change.

1. **Exact invoked-call binding removal.** In `src/polisyos/scientist/orchestration/llm/prompt_cache.py`, `PreparedCacheRequest._consume`, replace only:

```python
        if not invoked.exact or invoked.identity != self._call.identity:
```

with:

```python
        expected_args, expected_kwargs = self.call_values()
        if not invoked.exact or _normalize_cache_metadata(
            {"args": args, "kwargs": kwargs}
        ) != _normalize_cache_metadata({"args": expected_args, "kwargs": expected_kwargs}):
```

Run the valid-A/invalid-B actual CAS-owner selector and `test_prebound_call_identity_preserves_native_type_and_value` from B. Expected property FAIL: saved A is accepted instead of rejecting invoked B; native type/order distinctions collapse. APIs, actual owner, origin proof, decoder and physical generation remain. The failure must be a mismatch/authorization/type semantic assertion, not missing source, syntax, fixture or backend error. Restore and require the same complete selectors PASS.

2. **Python dispatch preservation removal.** In `src/polisyos/scientist/orchestration/llm/prepared_request.py`, inside `prepare_immutable_call.execute`, replace only:

```python
        response = generate(*actual_args, **actual_kwargs)
```

with:

```python
        wire = thaw_wire_object(freeze_wire_object({"args": actual_args, "kwargs": actual_kwargs}))
        response = generate(*wire["args"], **wire["kwargs"])
```

Keep the corrected canonical decoder source argument intact. Run the existing tools-present `_FakeLLMClient` selector and all `test_opaque_python_call_preserves_original_values_after_admission` cases from B. The provider-observed tuple/original-value contract must FAIL; begin refusal still precedes work and actual Gateway remains strict JSON. Restore exact bytes and require those same selectors PASS.

3. **Actual preflight reuse bridge removal.** In `src/polisyos/scientist/orchestration/llm/provider_verification.py`, `_PreflightGatewayClientAdapter.prepare_cache_request`, replace only:

```python
        return PreparedLLMRequest(actual.identity, execute, actual.reusable)
```

with:

```python
        return PreparedLLMRequest(actual.identity, execute, False)
```

Run `test_provider_preflight_records_bound_gateway_completion_and_reuses_exact_event` and real `test_actual_nl_post_gateway_settlement_reopens_and_serves_same_run`, every parameter case. Actual Gateway preparation and sending remain. The genuine reuse/physical-count/original-event assertions must FAIL while successful setup/decoder/owner path still executes. Restore and require both selectors PASS.

All three are marker-preserving behavioral falsifiers. No semantic removal is accepted merely because pytest exits nonzero. Retain exact collected IDs and failed assertion locations/reasons. Expected negative cases have complete=true and a deliberate assertion failure; infrastructure/setup/collection/capacity failures are separately classified and do not satisfy the oracle. Keep source ownership, snapshot authorization, cost provenance and strict decoding intact in every positive and restored case.

## Bounded repair authority and final review

If a real defect occurs, diagnose the actual request→producer→persisted event→bridge→consumer path before editing. Bucket it as same/new P40 class with the exact property, actual predicate and divergent case. Fix the existing owner for the whole known quantity, not the named fixture alone. Do not introduce a new issuer/subsystem, permissive catch, cost zero default, arbitrary callback trust, fake source receipt, forced deterministic sampling, weakened assertion, reduced test set or fixture scope laundering. Preserve all mixed reported/estimated/reuse/unknown outcomes.

Authorized mechanism files are the18 existing C05 mechanism Python paths enumerated in the source table, plus necessary direct C05 owner/consumer corrections when the actual call/definition chain establishes them. Shared `run_lifecycle.py` is limited to C05 cache/client/producer begin/basis/fresh monetary consumer spans; `control_plane_store.py` is limited to the existing DB-only `verify_llm_producer_admission`. No C57 creation/diagnostic/activation algorithm, C49 convergence/method scoring, C37 typed request normalization, C71 observational source ownership, Foundry executor/checkpoint family or unrelated generated-owner rewrite is authorized. Read those owners as context and report a concrete outside-scope blocker rather than changing them.

Mandatory companions may extend the mechanism footprint: real mirrored negative/integration tests, fully typed API/facade/schema/legacy reader/runtime consumer companions if moved, package README and release/migration notes. Do not count those against a mechanism path budget or split one mechanism merely to fit arithmetic. The Source carrier's `public_surface_inventory_reviewed=false` is honest: run actual affected generated/public/type/architecture checks if feasible and classify exact limits; do not simply set it true. No stale generated snapshot or marker proves serialized API equality.

Before final baseline freeze, inspect all introduced shared calls against actual owner definitions. The late decoder defect was a real missing keyword despite static Ruff and prior source GO. Do not treat syntax/style or method existence as runtime compatibility. After a bounded fix, run its focused regression, inspect the full delta, freeze source, then execute the complete affected deciding wave once. Broaden only when a new failure/change/concern justifies it. Run actual canonical-filename product Ruff/format over changed Python and required import/architecture/type checks appropriate to changes. Distinguish your final source review from independent review; Root supplies the latter after delivery.

## Complete, modest, retrievable output

Use a nonignored committed evidence directory such as `policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/c83-c05-native-20261028/`. Check ignore rules before relying on delivery. Quiet deciding stdout/stderr/JUnit/collection/resource/source-readset files should be gzip-compressed with full bytes retained, not truncated text or SHA-only pointers to ignored scratch. Retain every deciding failure, corrected baseline, semantic removal and restoration output. Compress routine repetition; do not copy source trees, environments, data, two complete artifact versions, raw giant dumps or derive five views of the same bytes. Cite tracked source as path@commit and include an actual source diff only for your final changes. No `git add -f` of oversized dumps without an explicit stated reason; prefer the nonignored modest packet.

Commit a compact `report.md`, `receipt.json`, exact commands/selected and collected IDs, final source/base/tree/dirty-state pins, actual backend/default plugin/.pth profile, process/resource controller facts, per-case outcomes and complete compressed deciding outputs. Include each actual output path/length/SHA256 and gzip integrity; the files themselves must be in the delivered commit. Report actual model if established, otherwise `not_established`. Record setup/collection PASS/FAIL/ERROR/SKIP/UNRUN/abort separately; sum exact full module outcomes and explain discrepancies without hiding them. No product or all-backend claim follows from a finite import observer.

Normal hooks/commits and the ordinary transport must deliver the final branch/commit/tree. Read back every changed source, report and compressed deciding file from that delivered commit, and verify actual remote commit/tree where that transport is supported. A tool success or local staging hash is not delivered bytes. Include a modest complete final diff and no leftover mutant, environment, DB or runtime cache. If transport/runtime/protected-source boundary remains blocked, deliver the actual completed source/evidence and name the exact missing capability and smallest next action; do not claim tests PASS or “unrelated” without actual evidence.

Final verdict distinguishes: exact source-only work; actual native14-module outcomes; additional direct consumers if run; all three baseline→semantic FAIL→restore PASS removals; measured resource/profile/source readback; and remaining architecture/type/generated/institutional/invoice limits. Capability is `verification_missing` wherever a required result remains unrun. Never claim full E02, G acceptance, protected authority or closure.

## Exact input source pins

These SHA256 values are from complete Git blobs at the required input commit, not Root RAW staging. Check them against fetched source before edits; a different field value is a source mismatch, not permission to update the expected hash. The complete commit/tree pins remain the primary source identity.

| Published path | Role | SHA256 |
| --- | --- | --- |
| `policy-engine/release-fragments/unreleased/2026-10-27-e02-cache-reuse-lifetime.toml` | mandatory release companion | `65d45892dd581de8c755ad9969c607b4996ea4cf51d05caf6a5633a7e204e403` |
| `policy-engine/src/polisyos/core/llm/README.md` | mandatory documentation companion | `22d03092b3abfa59fcb6d2d515fd485f01de88e77be71d53fa871899fc47c314` |
| `policy-engine/src/polisyos/core/llm/__init__.py` | mandatory facade companion | `6d85b26f9d8fe6b460a22794b55c235335273601bd42753531cfc82f70acba83` |
| `policy-engine/src/polisyos/core/llm/cache_settlement.py` | mechanism | `fde6449b48571ec167e3ee4ee462476ca948026e3f33b6725c6205842b9b0473` |
| `policy-engine/src/polisyos/core/llm/settlement.py` | mechanism | `442d0ddf13d30a91d442ce58a3a6e6cd4178d508edb8b284f1d0de0fda6dc8a1` |
| `policy-engine/src/polisyos/core/llm/traced_client.py` | mechanism | `aaa53e86314b7231e06a240a21c47e2ff4341d0affa2693497672d5fdaabfe46` |
| `policy-engine/src/polisyos/runtime/http/services/README.md` | mandatory documentation companion | `b6c08d4e1aacb41853532d77e067bec7a3bbe2296b8d63fd789d4e82b09bf8b9` |
| `policy-engine/src/polisyos/runtime/http/services/control/job_nl_execution.py` | mechanism | `c3708768ecb6ac9e2b4ec4d64133588e133f01331d4ec409893566aa1739a59f` |
| `policy-engine/src/polisyos/runtime/http/services/control/nl_pipeline.py` | mechanism | `5aac12fbcb311ecd90d02c651265961a6e1fd8d1541d44702e81520bf0f7722b` |
| `policy-engine/src/polisyos/runtime/http/services/control/producer_basis.py` | mechanism | `bdc032091100fd2cb40db2d6fbfd343cfb0d1177501d7c6c95dd20ec0715ada5` |
| `policy-engine/src/polisyos/runtime/http/services/control/run_lifecycle.py` | mechanism | `83a85ed5d27ded497bd725e4cd1558b2cac10fec266e52cedc56295625da1c18` |
| `policy-engine/src/polisyos/runtime/http/services/control_plane_store.py` | mechanism | `c95f43bebad7f917320530da9691adae63e731a07ad619b42f9b39e3c26bb9ed` |
| `policy-engine/src/polisyos/runtime/http/services/debug.py` | mechanism | `01dd49aad4c4555727918eb36ad060b4b78ef2eef5bdbcb6371fdd0d6157b6d0` |
| `policy-engine/src/polisyos/scientist/orchestration/engine/budget_middleware.py` | mechanism | `8abd43ad46b34b1dc2865ec8fe5d60f04bfbb20693ec8cbe0b1de6a89660e8f1` |
| `policy-engine/src/polisyos/scientist/orchestration/llm/README.md` | mandatory documentation companion | `2cff1f1ab5c544bcea37f2461e7b14bc46b368cff8789535959b95092163669b` |
| `policy-engine/src/polisyos/scientist/orchestration/llm/factory.py` | mechanism | `47497d983c315b370982f7549eec0cf3ac35b8df198e65380a572daed1fcd32a` |
| `policy-engine/src/polisyos/scientist/orchestration/llm/fallback_router.py` | mechanism | `ab113caaae65dc94d68106be1bbd6627cf30c24d8685bc51a7c14b4085f3b5f7` |
| `policy-engine/src/polisyos/scientist/orchestration/llm/gateway_client.py` | mechanism | `8dd538fc74926f449cbc8abaec4353d4d8151bddc5a6c2988d6b38b56635cd3e` |
| `policy-engine/src/polisyos/scientist/orchestration/llm/prepared_request.py` | mechanism | `b147b4788ae96373af086703752b40d74b686a350301e9e351386360745e779f` |
| `policy-engine/src/polisyos/scientist/orchestration/llm/prompt_cache.py` | mechanism | `d1553de4c7f710ee2483593f92e1fae8760d811398f1cb8f545b1d5072df8351` |
| `policy-engine/src/polisyos/scientist/orchestration/llm/provider_verification.py` | mechanism | `a37d6bcb8ce2e80bf92c2eaee035c0e7ebff7fe68069cd316319e3510d4631f6` |
| `policy-engine/src/polisyos/scientist/orchestration/llm/simulated_gateway.py` | mechanism | `9956d879a398abcf4bd7a02cf94f46197957ef7bfc289e992f705c82e4912561` |
| `policy-engine/src/polisyos/scientist/validation/citation_faithfulness.py` | mechanism | `a47e85813b10dc003b79283ae5e2e8d5efda84988ab62f15492f9878ccb4d427` |
| `policy-engine/tests/integration/runtime/http/test_nl_pipeline_cache_reuse_authorization.py` | mandatory semantic test companion | `64a96b8c7194180f03fe14d333486c9375d911c756765a6dc2aceb4b642426c6` |
| `policy-engine/tests/integration/runtime/http/test_r3_pre_admission_attempt_owner.py` | mandatory semantic test companion | `afbc4887c106d687546f843b64697afdb4f6d236ff720cc6493c2e6165e0046e` |
| `policy-engine/tests/unit/core/llm/test_cache_settlement.py` | mandatory semantic test companion | `442542af8c337530da184149f27162a6066cc525dce34ea21a62272bcdd7eb74` |
| `policy-engine/tests/unit/core/llm/test_traced_client_settlement.py` | mandatory semantic test companion | `180a61920bcb68bfcd0f884046fe71a13bde9a1c39eb1fcdd6bbc1f301d8498e` |
| `policy-engine/tests/unit/remediation/test_llm_01.py` | mandatory semantic test companion | `f576cb657c7724979f7b227f5896e9a5c67a19af67f53982f079b21cec60a8a0` |
| `policy-engine/tests/unit/runtime/http/test_control_nl_producer_admission.py` | mandatory semantic test companion | `c459f78276a36273482ea224c81227078c45b10fc3675ef5e5484a8fd4bcc481` |
| `policy-engine/tests/unit/runtime/http/test_nl_pipeline_cost_projection.py` | mandatory semantic test companion | `c96fc573bde833be72bac511e2b1ab32d1ca895cf7d25436fd9db1f1226f58fe` |
| `policy-engine/tests/unit/scientist/orchestration/llm/test_cache_owner_admission.py` | mandatory semantic test companion | `9035a7c53a0948da0eda911ca4c85cd642c300d7fd121cea2fc69545e34c94ab` |
| `policy-engine/tests/unit/scientist/orchestration/llm/test_fallback_router.py` | mandatory semantic test companion | `76499cf737e159b9477e30b6a3fff787c9c9fcc873b4e5780e04d4e1748b456c` |
| `policy-engine/tests/unit/scientist/orchestration/llm/test_gateway_client_retry.py` | mandatory semantic test companion | `beca5aee91b1e9bb8b7604f31e855e7bb70ba446a5752c462aad56edfd0c10c1` |
| `policy-engine/tests/unit/scientist/orchestration/llm/test_prepared_request_dispatch.py` | mandatory semantic test companion | `2581468d08cb21530dbf140eeed88ac136b6d2c5828bafb0b3e003828961147f` |
| `policy-engine/tests/unit/scientist/orchestration/llm/test_prompt_cache.py` | mandatory semantic test companion | `2dac534e1a31b98a8f6b3494eda561e49731600252ded9f411161aecaa7053d2` |
| `policy-engine/tests/unit/scientist/orchestration/llm/test_prompt_cache_scope_admission.py` | mandatory semantic test companion | `3e2eef1eb057b0dc540efdeeeb140fe0e5474569de4d5502b1f04fecb69577b1` |
| `policy-engine/tests/unit/scientist/orchestration/llm/test_provider_verification.py` | mandatory semantic test companion | `5e4154bf070fe34d7a8fdddd01f57d5b6781a9fafb86f80379c5cbc6ac910c6d` |
| `policy-engine/src/polisyos/common/serialization/__init__.py` | public shared-owner/context | `9dd34967d6bb95244085410a5988d326824c017aadb3233db903eab1efb31685` |
| `policy-engine/docs/reference/runtime-observational-source-access.md` | public shared-owner/context | `5cfb562f083813735362e2a37b902a1709d589fd50fc9e718b5103745e2f2818` |
| `policy-engine/src/polisyos/runtime/http/services/control/observational_source_access.py` | public shared-owner/context | `faef9afc1a2c72ebd2dd7c6344c68ed4d595d0a9e40aba1027033c908c7efebb` |
