# C86 — portable runtime verification of scoped source access and derived HTE custody

You are the authorized verification/test author in isolated Codex Cloud environment `6965429cdb308191a0e6eb63cb118ea3`. Execute the portable C71 tests and the five property-removal controls below against the published source. This is a standalone commission: indispensable law, source pins, actual selectors, mutation recipes, resources and delivery rules are inline or in the exact public Git tree. No earlier conversation, local RAW file, unpublished working tree, private Mac helper, production data or mid-run coordinator answer is an input. Root alone launches this task; authoring this prompt is not execution.

## 1. Exact input and verification lease

Published topic `codex/e02-composed-progress-20261028-r5`, source commit `ea3d65682d76a5d66d514e525ad2212e5a85f669`, tree `7c5412fddc4ef3e56c859b83d237162e0fd260e7`. Read back HEAD/tree, branch/status and every finite pin below before execution. Cloud `work`, detached HEAD or absent origin is acceptable when the actual source is exact; do not create/reset/switch a checkout to change its label. If another provisioned source differs, derive the complete relevant source delta and return a concrete source rebind; do not silently claim this source was tested. Do not depend on a later generated-stub successor which exists only in root's local worktree.

Read AGENTS.md, CONTRIBUTING, failure register, measurement author contract and the named owners. This lease authorizes test/verification helper work and isolated temporary mutations required by the removal experiments. Keep production source frozen. If an actual bounded C71 defect is exposed, preserve the failing output and return its exact mechanism/consumer/minimal counterexample; prepare a separate reviewable patch only if necessary to make that concrete, without adopting a new law, weakening a guard or rewriting unrelated source. No C05 producer/cache/lifetime rewrite: a separate C83 task owns that complete14-module cohort. No C48 Graph metrics, C57 Store mechanism, GY/B198 or protected TC-purpose repair is commissioned here. Do not run their broad suites to accumulate unrelated green counts.

No main/G publication, external messaging, CI/upload automation, credentials or production datasets. Useful test/helper changes may be committed through normal hooks only on a safe attached own task topic; otherwise deliver a complete applicable patch including new files. Never disable hooks or repair history to make publication work. Re-read delivered source/branch bytes, not only staging scratch.

## 2. Property and decisive divergences

Required property: before each actual protected source read/use, Runtime's authenticated request/effective policy, reselected live ControlPlane job, or authorized Direct reader supplies the expected scope. The actual ownership-enforcing Core handle must resolve that same full tenant/cell tuple. Core independently rechecks current blob-reader and exact selected-view ownership and immutable content/profile integrity. A bound `FileSystemCAS.for_tenant(A)` can override an ambient B scope: reading A genuinely under A is insufficient for a B route/job. An enforcement-disabled store cannot establish the predicate. Governance=`public`, an absent tenant header, a principal-shaped mapping, prior successful read, caller receipt, cache equality or diagnostic ownership_evidence is never an access grant.

Source tenant A is provenance. A genuine current Core read grant to authenticated job B permits the supported candidate source profile, while newly derived policy/requested/admitted intent, normalization/physical materialization, selected rows, results and evidence carry actual admitted writer B. Keep exact selected sourceA refs/provenance. Core's writer-context invariant stays enforced. The actual legacy physical loader requires normalized derived custody==physical binding custody, plus exact submitted/effective refs, original-source lineage, normalized bytes/canon/governance and complete physical recomputation; it must not require normalizedB==sourceA or accept conflicting normalizedB/bindingA merely because all payload bytes agree.

Existing source mechanism: control/observational_source_access.py reconciles typed RuntimePrincipal/effective execution policy, current Store admission and reader scope with actual Core `_resolve_owner` and enforcement; known exact CoreToIR/GuardedDependencyProxy carriers are inspected without replacing the guarded IO handle. Control/run_lifecycle.py re-enters before launch reads, current worker admission, content-admitted persistence, completion and fresh Direct selection/projection. The get_method_execution_selection fence is inside its Direct branch; C48 Graph uses its existing path. Current ControlPlaneStore admission/fence and Core blob+view checks remain the owners. A worker-local typed derived context crosses runner→prepare→selected-row/result/evidence and owned-attempt consumers; no new persisted permission receipt, issuer or wire schema is created.

Compatibility: public unscoped legacy reads retain limited behavior under the existing enforcing ambient-compatible owner; tenant metadata is not itself permission. Historical None headers do not gain authority. Canonical passthrough sourceA may remain effectiveA while a new physical binding is derivedB. Legacy normalization emits effectiveB and bindingB with exact sourceA lineage. Restricted outer classifications remain unsupported here. The source_access_revalidation_status Literal remains not_established. Successful scoped software access does not prove external institutional permission, online IAM revocation, source truth, PII suitability, calibration, legal adequacy, production currentness or complete TC purpose authority. C38 advisory declared-basis cache equality cannot promote into protected role/surface/gates; existing protected TC writers stay disabled. B198 semantics remain intact.

Ratified law: S0-K03 classify planes separately; K05/K07 transport/projection is not authority; K06 candidate work may carry declared limitations while unauthorized reads/protected claims fail closed; K11 equivalent action-specific protection; K12 content equality is not authority validity. The pinned G14 selected request-time/closure/delivery decisions select exact payload/kind/media/profile/role identity and current boundary policy re-entry, preserve historical read meaning, and grant no code acceptance (`code_acceptance=false`, closure_ids=[]). No external issuer appointment or new semantic question is needed to exercise the existing owned-byte profile. A broader action needs its own owner/evidence, not an invented tenant assertion.

B161 [C15.R01,R05], pinned B_r19_original.md:4165–4175: an early explicit unassessed placeholder may be refined only by admitted later assessment of the same subject/measure/input/procedure; independent uncertainty/disagreement and different-population boundaries survive. This task does not close B161/S1, B31/B214, LA-023, G528 or the original finding set. AD04 keeps a computed point when intervals are unavailable; a real accepted model-conditional backend interval is distinct from inference failure. AD06/first-assessment/contested replay remain as the original selected source test asserts. Do not globally replace max/min/latest or erase warnings to get green.

Historical supplied observation only: at95f4b9b2022642cb1ea4e4f2a31b3493c36fd125/treec78d0f80fbe5de8f4cad3626f2a62fe94b380f76, Core14 passed and the first ordinary HTE POST failed403 observational_source_current_access_not_established with “requires an unscoped public observation.” Those retained Mac outputs are not delivered as C86 deciding evidence and are not your source's result. Cloud C71's public-only relaxation later failed independent source review because it did not reconcile effective A versus admitted B or require actual enforcement. The current published repair received source-bounded independent review; no runtime/native/removal acceptance follows from it. Never make the original source unscoped/public, skip grounding or forge a grant to force a positive.

## 3. Portable execution matrix

Use the existing committed tests, with normal pytest.ini/plugins/strict markers/importlib mode. No --override-ini addopts='', -p no:..., plugin-autoload suppression, blanket xfail, blanket skip, numeric-output substitution or fake resolver/issuer positive. Record all actual collection/selection/profile flags. The first command selects the new module's portable tests and excludes only its one clearly named actual native backend test:

```text
.venv/bin/python -B -m pytest tests/unit/runtime/http/test_observational_source_access.py -k 'not shared_source_native_result_is_owned_by_job_and_reopened_by_fresh_service' --tb=short --color=no --junitxml=<private-out>/source-access.xml
```

This module declares12 functions/18 parametrized cases at the pinned source; the filter is expected to select17 and deselect1 by AST arithmetic, not a collection/result claim. Actual collection must confirm it. It exercises genuine authenticated HTTP, actual CAS, durable current jobs, wrong tenant/cell and disabled enforcement with and without tenant metadata, no transfer before scope rejection, exact ArtifactRef-subclass selected profile versus default, worker scope before payload read, pre-effect reentry, current owner-generation withdrawal, missing live fence, shared sourceA/readB/derivedB and both canonical/legacy physical loader paths. The legacy physical preparation positive includes a genuine alternate bindingA profile with identical payload/input refs, actual A read grants on effectiveB before writerA input admission, an explicit B exact-view grant, successful real Core read and exact derived-custody refusal. Keep that prerequisite: otherwise Core input-owner refusal masks the intended loader oracle.

Run these affected portable producer/consumer modules once, capturing separate outputs so a failure does not hide other independent outcomes:

```text
.venv/bin/python -B -m pytest tests/unit/foundry/data_plane/test_hte_observational_input.py --tb=short --color=no --junitxml=<private-out>/physical-input.xml
.venv/bin/python -B -m pytest tests/unit/foundry/data_plane/test_selected_row_candidate_scope.py --tb=short --color=no --junitxml=<private-out>/selected-rows.xml
.venv/bin/python -B -m pytest tests/unit/scientist/compute/test_runner_method_execution_work.py --tb=short --color=no --junitxml=<private-out>/runner-contract.xml
```

Run these exact existing Runtime companion functions (including all their parametrizations), rather than unrelated numerical/Graph/C05 tails:

- test_observational_method_runtime.py::test_direct_selection_revalidates_real_cas_manifests_and_result_edges
- ::test_legacy_normalization_requires_exact_full_source_lineage
- ::test_direct_selection_rejects_result_or_evidence_edge_profile_substitution
- ::test_direct_selection_rejects_output_governance_removal
- ::test_http_post_refuses_restricted_or_foreign_tenant_source_before_enqueue
- ::test_http_post_accepts_currently_owned_public_tenant_scoped_source
- ::test_http_post_refuses_source_without_owner_claim_before_enqueue

Prefix each with tests/unit/runtime/http/. Preserve returned selections, exact profiles/roles/lineage, governed limitations and no-enqueue refusal assertions. Derive actual affected loader/derived-context callers from complete tracked src/tests/tools .py enumeration+AST and record selector and file-type denominator; named aliases/dynamic/external inputs remain unresolved. Known loader uses include selected-row producer and fresh reader, owned-attempt anchor, HTE outcome bridge and search uncertainty. Do not infer all consumers from a sampled grep.

A separate root Mac lane covers all seven ordinary native HTE modes and one shared A→B full native chain/fresh service. C86 portable tests and controls do not wait for that lane. If Cloud capacity/profile already supports EconML, an optional clearly separated run of test_observational_source_access.py::test_shared_source_native_result_is_owned_by_job_and_reopened_by_fresh_service is useful; record its actual outcome or SKIP/UNRUN, but do not present it as all seven modes. Native source selector names and original seven modes are public in test_search_hte_first_assessment_outbox.py and must remain unchanged. Missing backend is not a passing native check.

Run logical-path Ruff and format checks for actual changed/selected Python modules and test companions. The published commit reordered two test import blocks with physical Ruff I001; preserve the final committed bytes and compare non-import AST if reformatting helpers. Architecture/public interface checks must use existing owners; do not regenerate/commit global inventories merely to run this bounded verification. If a relevant check fails, retain actual output and classify it separately. No environment issue or unrelated source red is inherited without exact slice-base replay plus zero intersection with that check's complete input denominator (P41).

## 4. Five isolated property-removal experiments

The exact patches below are freshly rebound to r5 committed whole-file bytes and qualified function ASTs. They are experiments, not proposed production changes. For each: freeze source, observe original selected node PASS, apply only that patch in your isolated task checkout, run the SAME node in a fresh process, capture actual named function/module invocation, require the stated semantic assertion/missing-refusal failure, restore exact original bytes (no reset/checkout), hash-readback, and run fresh restored PASS. Keep full normal markers, refs, schema/role/status fields and all unrelated guards. A fixture/import/collection error, timeout, skip, unselected test, different earlier denial or wrong failure is not the intended mutant red. If an original is already red, retain it, do not call the mutant decisive, and continue independent experiments whose prerequisites pass.

Use stdlib AST/text structural location plus these exact full-file/function hashes to establish what changed; do not blindly replace every string or assume old line numbers. Each provided patch was scratch-applied and only its named qualified function AST changed. Recheck against your actual loaded source and record original/mutant/restored hashes. Read-only sys.setprofile or pytest instrumentation may count the named target function before/after; do not insert product probe hooks or satisfy the observation with an unrelated wrapper.

### M2-job-vs-ambient-owner

Path `policy-engine/src/polisyos/runtime/http/services/control/run_lifecycle.py`; target `resolve_method_execution_admission`. Whole-file original SHA256 `83a85ed5d27ded497bd725e4cd1558b2cac10fec266e52cedc56295625da1c18`; mutant `aab1c8144889816d9a95273cba99eb83ee51ce6b9bd6ca9ea35d7e78b3661fb0`. Function AST original `ac307d65fb6a57a4ffabdaa5b1cef10d09043551e5510d4edc943bfdf28d56ac`; mutant `f77a183365e8a75edc8d596a7d4f40cbc0a40612bd7d7bb19e0c38859ec0fc4b`. Patch SHA256 `601ad46e70b8f186c5a8380f1ecbe9064770b7f39bab8552e92b4cb5a344b161`.

Selector(s):

- `tests/unit/runtime/http/test_observational_source_access.py::test_real_job_admission_cannot_borrow_another_ambient_owner`

Property: derive expected owner from live reconciled job rather than an unrelated ambient owner. Intended signal: job read private payload through another ambient owner assertion fails; a later derived-header refusal does not erase that transfer.

```diff
--- a/policy-engine/src/polisyos/runtime/http/services/control/run_lifecycle.py
+++ b/policy-engine/src/polisyos/runtime/http/services/control/run_lifecycle.py
@@ -6538,7 +6538,7 @@
 
         current = self._control_store.current_execution_job_admission()
         job = current.job
-        source_read_scope = _job_source_read_scope(current)
+        source_read_scope = _current_source_read_scope()
         _require_source_read_owner(self._artifact_store, source_read_scope)
         if (
             job.kind != "workflow_run"
```

### M3-cold-reader-before-transfer

Path `policy-engine/src/polisyos/runtime/http/services/control/run_lifecycle.py`; target `_validate_direct_method_execution_selection_artifacts`. Whole-file original SHA256 `83a85ed5d27ded497bd725e4cd1558b2cac10fec266e52cedc56295625da1c18`; mutant `65bf89b012bc08f5ffcb2f8ab4c3959790be5215149ec16c877da43136cdcbee`. Function AST original `3d42772041dac8115eba0d31fd0146053029310116e60ada1d9eee2db28686cc`; mutant `3d48cdf52b28d53d3f945348dc7dc93379a593be1d5444496bea983edab0ab79`. Patch SHA256 `880be6f9cdd20e216d6f4a0952e13df888f9a3a549fe5deef17c0603fc5cb831`.

Selector(s):

- `tests/unit/runtime/http/test_observational_source_access.py::test_fresh_selection_reader_uses_active_owner_not_configured_foreign_owner`

Property: fresh consumer binds expected/effective owner before first Core manifest transfer. Intended signal: fresh reader transferred private metadata before scope binding assertion fails; late source guard may still deny, which does not erase the forbidden earlier transfer.

```diff
--- a/policy-engine/src/polisyos/runtime/http/services/control/run_lifecycle.py
+++ b/policy-engine/src/polisyos/runtime/http/services/control/run_lifecycle.py
@@ -615,7 +615,6 @@
     )
 
     source_scope = source_scope or _current_source_read_scope()
-    _require_source_read_owner(store, source_scope)
 
     def read_manifest(
         ref: ArtifactRef,
```

### M4-selected-profile-propagation

Path `policy-engine/src/polisyos/runtime/http/services/control/run_lifecycle.py`; target `_read_observational_source_manifest`. Whole-file original SHA256 `83a85ed5d27ded497bd725e4cd1558b2cac10fec266e52cedc56295625da1c18`; mutant `5f1eb3a773f7c5930edb6eb39e16407a24ddb5a5793d318871a0eca5ec6a47d3`. Function AST original `144d6295a3d5751f7babb314760ff0d6bdccf94d221e16c614bc3936b1f1da7e`; mutant `40acb784455ff5102ec3d2ba7c38c3c6bbebbfc1e175277dce8413dcbc5a71ce`. Patch SHA256 `fbf6518991c3838ace4af1eb3c3226cb16fac1769d9c5e1e65475acd78a3e60e`.

Selector(s):

- `tests/unit/runtime/http/test_observational_source_access.py::test_selected_subclass_profile_is_not_replaced_by_default`

Property: selected ArtifactRef subclass profile survives actual Core read; immutable payload ID alone is insufficient. Intended signal: selected subclass manifest view was not preserved assertion/refusal fails; actual default and selected views differ.

```diff
--- a/policy-engine/src/polisyos/runtime/http/services/control/run_lifecycle.py
+++ b/policy-engine/src/polisyos/runtime/http/services/control/run_lifecycle.py
@@ -5713,7 +5713,7 @@
         limits = self._observational_read_limits()
         bounded = read_core_manifest_profile_bounded(
             self._require_core_bounded_manifest_reader(limits=limits),
-            source_ref,
+            source_ref.model_copy(update={"manifest_profile_sha256": None}),
             max_manifest_bytes=limits.max_manifest_bytes,
         )
         if not _same_selected_artifact_ref(bounded.effective_ref, source_ref):
```

### M6-origin-is-not-writer

Path `policy-engine/src/polisyos/runtime/http/services/control/run_lifecycle.py`; target `_launch_observational_workflow_run`. Whole-file original SHA256 `83a85ed5d27ded497bd725e4cd1558b2cac10fec266e52cedc56295625da1c18`; mutant `2c9be99e0e60573a34919ad2b34348d637689aac59b164dbfb7abd2595a5c1d2`. Function AST original `a35330205fb6f92bb13a8d9709bd25efd1f57680ad51a16af444c1debdbecb27`; mutant `08a1ceb615a3373913345ae01a47d60c844038802ac47a668a72b8c77c370727`. Patch SHA256 `9057f8b42d96118d477d0212a69b71b0ba73c64c458e944442fabb4d7f5235e5`.

Selector(s):

- `tests/unit/runtime/http/test_observational_source_access.py::test_real_shared_view_grant_uses_reader_scope_without_rewriting_source_tenant`

Property: derive producer custody from admitted request B while preserving source origin A. Intended signal: shared POST200/derived-B header oracle fails at actual Core writer invariant; legitimate B read grant is retained.

```diff
--- a/policy-engine/src/polisyos/runtime/http/services/control/run_lifecycle.py
+++ b/policy-engine/src/polisyos/runtime/http/services/control/run_lifecycle.py
@@ -6218,7 +6218,7 @@
             schema_name="polisyos.runtime.ObservationalInputResourcePolicy",
             schema_version="1.0",
             governance=source_governance,
-            tenant_context=source_read_scope.writer_tenant_context,
+            tenant_context=source_tenant,
             inputs=[selection.source_ref],
             input_roles=("requested_source",),
         )
@@ -6391,7 +6391,7 @@
             schema_name="polisyos.runtime.ObservationalRunIntent",
             schema_version=_observational_intent_manifest_identity(intent.schema_version)[2],
             governance=source_governance,
-            tenant_context=source_read_scope.writer_tenant_context,
+            tenant_context=source_tenant,
             inputs=[ref for ref, _role in intent_input_edges],
             input_roles=tuple(role for _ref, role in intent_input_edges),
         )
```

### M8-normalized-derived-custody

Path `policy-engine/src/polisyos/foundry/data_plane/bindings.py`; target `load_hte_physical_source_materialization_binding`. Whole-file original SHA256 `f8cf224d4adeb718240e10508f680aeed5d0f1da4f95de9b03e1516848af1980`; mutant `2d481e163a63d39e73db681993112b119d69a1e9c61d038d95876a705d1f4260`. Function AST original `f8e6fa5ca54b95f74a59460c79f809a7192f769ae72256aee9fab9ae82a9d4aa`; mutant `53f33e28008ede76878595b722ee1da2ff29388ce702037613e4e79ad1166d75`. Patch SHA256 `57d3930ba75fe64d5615ee36aa25baa99e27888dfc260857cb8b11316924d8bb`.

Selector(s):

- `tests/unit/runtime/http/test_observational_source_access.py::test_shared_source_keeps_origin_and_uses_actual_job_writer_through_preparation[legacy_hte_json_v1]`

Property: current Core readable physical binding and normalized artifact share derived custody while original selected source provenance stays independent. Intended signal: DID NOT RAISE source_binding_legacy_derived_custody_mismatch for actual signed conflicting binding profile; all bytes/lineage/recomputation and current B read grants still agree.

```diff
--- a/policy-engine/src/polisyos/foundry/data_plane/bindings.py
+++ b/policy-engine/src/polisyos/foundry/data_plane/bindings.py
@@ -918,7 +918,7 @@
         # The submitted source is provenance. Normalization and its physical
         # binding are derived artifacts written under the same actual custody;
         # their exact selected lineage still binds the independently read source.
-        if effective_read.manifest.tenant_context != binding_read.manifest.tenant_context:
+        if False and effective_read.manifest.tenant_context != binding_read.manifest.tenant_context:
             raise HTEInputPreparationRefusal("source_binding_legacy_derived_custody_mismatch")
         if (
             normalized_bytes != effective_read.raw_payload_bytes
```


The five controls are independent: live job scope versus ambient scope; fresh reader's owner check before first metadata transfer; selected profile propagation; source provenance versus derived writer; and normalized/physical custody agreement. A later refusal cannot erase forbidden earlier transfer. M6 may fail at Core's real context-binding invariant, which is the expected before-POST protection against wrong derived custody. M8 requires current Core reads to succeed for the contradictory selected binding; equality alone is not a read grant. Retain all exact real ownership prerequisites. Additional owner/enforcement/current-permission controls may reuse existing tests but are not permission to build a new issuer or replace current Core with a fake callback.

## 5. Environment, actual PID/profile and resources

Read actual interpreter, OS/arch, installed distribution/backend versions, CPU/RAM/free disk and dependency profile before execution. Reuse an existing supported environment. If unavailable in this isolated Cloud environment, provision only the locked test/runtime/causal-core profile using the repo's existing uv tooling (for example uv sync --frozen --extra test --extra runtime --extra causal-core from policy-engine); record exact command/resolution and do not edit locks/global settings. Do not copy a Mac .venv or install production data/credentials. Use actual Python>=3.14,<3.15 from pyproject; no unsupported interpreter workaround. Provisioning failure leaves relevant checks UNRUN but does not erase independent static evidence. The Mac single600s/2300MiB quota does not apply to Cloud: set explicit safe Cloud deadlines/RSS/disk limits from measured capacity and first ordinary portable command, then reuse the measured profile; serialize shared CAS/DB/port/source-mutant state only.

An actual pytest PID must be observed, not just a supervisor/shell PID. For every deciding command, use a small standalone audit launcher or equivalent pytest hooks which print/write os.getpid(), sys.executable, argv, cwd, monotonic start/end, collected/selected node IDs and normal plugin names/options from inside pytest's process. A session-finish hook must record the actual finite loaded src/polisyos, tests and tools .py module paths and SHA256 bytes under the project root, with actual phase/exit and plugin source hash. Record external package versions separately; this finite loaded set is not an all-repo/environment closure. Pin the audit launcher and helper bytes in the source/profile receipt. Read-only tracing may observe actual protected function calls and backend dispatch, but mere process existence or an exit0 field is not proof the property ran. Retain psutil/process-tree or available OS resource sampling linked to the same PID; if pytest exits/crashes before a complete readset, source admission remains not_established for that run.

Clear accidental ambient PYTHONPATH/PYTHONHOME/PYTEST_ADDOPTS/PYTEST_PLUGINS/PYTEST_DISABLE_PLUGIN_AUTOLOAD/VIRTUAL_ENV before launching the explicitly chosen interpreter; do not disable normal plugin discovery. Use one numerical thread through standard OMP/OPENBLAS/MKL/NUMBA/NUMEXPR/VECLIB/BLIS/POLARS thread variables for these bounded checks. Redirect temporary caches, basetemp, JUnit and benchmark outputs to a fresh private output directory through normal pytest options; leave repository config/plugin behavior intact. Record actual pytest.ini addopts/importlib/strict markers/default plugin autoload, any -k selection (only the named native exclusion above), quarantine entries affecting chosen nodes and skips with reasons. A required ordinary test skipped by quarantine/backend absence is SKIP/UNRUN, not a pass. No fake profile or no-op subprocess may satisfy a selected native/backend test.

## 6. Evidence, delivery and acceptance

Freeze source and helper/tests before the deciding wave; use task-local independent review if available under active delegation policy, without spawning a new task/runtime just to bypass limits. Review is source-bounded; runtime evidence remains separate. Pattern pass: P05/P15 no authority promotion; P27/P31 one expected/effective owner and full derived-writer consumer chain; P29/P32 remove actual property, keep markers; P35 finite complete named input denominator; P37/P38 recomputed/reconciled predicate versus metadata proxy; P39 required companions outside mechanism budget; P40 same class one level deeper widens the quantity, not more blacklist patches; P41 exact provenance for red. All external/IAM/production/purpose completeness predicates remain not_established.

Return requirement→actual node→source/PID/profile→outcome→full deciding bytes. Separate PASS, FAIL, ERROR, SKIP, timeout/resource abort and UNRUN; counts must sum to actual collected/selected/report totals, including before/removal/restored phases. Include exact artifact/profile/source/job/producer/consumer observations, real permission prerequisite and intended assertion reached. List every unavailable boundary and smallest next owner/check. Runtime success verifies the bounded software mechanism only, never wholeE02/S1/G acceptance.

Compact A–D transport: A=actual useful test/helper/repair bytes and applicable patch including new files; B=exact public Git/command/input recipes, cite instead of copying source; C=noise/duplicate/source dumps omit; D=necessary complete nonreproducible deciding stdout/stderr/JUnit/readsets/profile/PID/resource and removal-restoration outputs, lossless gzip allowed. Deliver D through the task's actual retrievable attachment/diff or safe own-topic tracked artifact channel with a compact SHA256/byte-size index. An ignored Cloud path+hash is not delivery. If evidence transport cannot carry D, report transport_blocked/not_established, identify exact missing witness and narrow rerun; do not fabricate a receipt, summarize away the deciding output, add CI/upload tricks or block unrelated useful preparation. Re-read final delivered bytes from their actual delivery channel/branch. Root retrieves, recomputes hashes and independently accepts.

## 7. Finite public source pins

All paths below are public Git file bytes at the required ea3d source, not local RAW inputs. Read whole named owners when deriving their sets. Recompute all hashes; table presence does not prove actual runtime imports. New helper/test postimages require their own hashes. Scope is these66 files, not all repository inputs.

| Public Git path | SHA256 | Bytes |
|---|---|---:|
| `AGENTS.md` | `424b84e3280df143219fe27e28149088f9e92b947e4956b2103388e11849e65c` | 22824 |
| `policy-engine/CONTRIBUTING.md` | `e78f1bdb99a900f6426f9f451b7e9cbc0e21007eb12012eaf209d89c505f3a1f` | 12253 |
| `policy-engine/architecture/imports/policy.toml` | `a233241dd0b8999b8b124c775fbd0bcd3b9bf480e23cff8a0e5df98c2d9acafa` | 3668 |
| `policy-engine/architecture/public_surface/README.md` | `0d395c9f23e51a0890992eafec2269d14f7ff3e14849138d8387a2fe533aa298` | 979 |
| `policy-engine/architecture/public_surface/contract.toml` | `cce2e7cd4d96b4595ae5bf0721002776265d70f878d4fbfcd51570f9d89f10c9` | 21465 |
| `policy-engine/docs/how-to/author-measurement-instruments.md` | `aff79970df5d0ba029e4fd3bc519e91210a4cbb4c4e6d36efd2cfee1f57d49dc` | 5387 |
| `policy-engine/docs/plans/active/agent-packages/PolicyOS_E02_Combined_Agent_Package/source/B_r19_original.md` | `9c98584cbfa72996b058abf127f6c689f919a3421cdd563a82c84a7324ab39b5` | 1336380 |
| `policy-engine/docs/reference/policy-design-case-failure-patterns.md` | `bd9876488d7d4791be9334923e22fb50e8f76580d7c33639bce4d917307789c7` | 74098 |
| `policy-engine/docs/reference/runtime-observational-source-access.md` | `5cfb562f083813735362e2a37b902a1709d589fd50fc9e718b5103745e2f2818` | 3163 |
| `policy-engine/docs/research/e02-cloud-test-plan/execution-prompts/HANDOFF.md` | `8519f95eb0ff2ec2c64caa4497eb58b957fe7cd47a0a6955bad98a2c20795d3b` | 20260 |
| `policy-engine/docs/research/e02-cloud-test-plan/execution-prompts/unified-local-2026-10-09/TASKS.json` | `a37c75cfe09d33c1f50379d5bbfd04bdb728c990e832aec3bf19c0d17035734c` | 27989 |
| `policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/executor-continuation-plan-20261027/cloud-inputs/g14bf/02-request-time-context.md` | `8d344bd9045385c0df77a9ed0f69dc0c6abed55bc688f32e661aba4997be3134` | 16944 |
| `policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/executor-continuation-plan-20261027/cloud-inputs/g14bf/03-exact-view-closure.md` | `55c1743beb4f59878328846645c10a481f281f856c57555c0c5d9aa812dcfc9f` | 13949 |
| `policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/executor-continuation-plan-20261027/cloud-inputs/g14bf/04-delivery-and-acceptance.md` | `1871528ae6b1f92431a111f1b09b7aca8d0c0601e201bccc8880652e5260b068` | 17334 |
| `policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/executor-continuation-plan-20261027/cloud-inputs/g14bf/README.md` | `259c93d06285f76c1375754f21e973efc2b75dd56bbcb03157c53ca77ce0754e` | 6701 |
| `policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/executor-continuation-plan-20261027/prompts/C07-s1-source-binding.md` | `bda7b43f38bfe29284f2597306941e99e10563d9250e3f4bc511de08c188938f` | 26689 |
| `policy-engine/docs/system-design-decisions/policyos-identity-and-custody-boundary.md` | `f9b3776032e88190ac8d29f60d9623450f4d734e163cc16ae53f49b0f2a77bce` | 21556 |
| `policy-engine/docs/system-design-decisions/stage0-custody-kernel-ratification.md` | `a8410cddf3e2c8b7f4c194d06d0c38523fb64634f247e6baf96dfd6359197ea7` | 16120 |
| `policy-engine/pyproject.toml` | `5f65308cb088086b6fc0aa40a5bae6ed852ae3a2e261103bd0d4158d97c1e8f2` | 11241 |
| `policy-engine/pytest.ini` | `61270205a9f573a090b3c051a4b78351e67308a49e21660dbf33e76186d799eb` | 1021 |
| `policy-engine/ruff.toml` | `8ffeafd8510518f1e89e6a2028aff685817bf5466dbffbc8c8bce85d01c8a4c5` | 999 |
| `policy-engine/src/polisyos/core/artifacts/__init__.py` | `fa040abf9b26519aa18f53a00e1c5025fa1899616a714d2e66663e4bd55b926b` | 14023 |
| `policy-engine/src/polisyos/core/artifacts/canonical_profile.py` | `e59d52189834a76a2bfe6854d1d61d3ef659bff80451002b4efab75ab62e2b80` | 115749 |
| `policy-engine/src/polisyos/core/artifacts/manifest.py` | `3ec97132a4a04c6152ed3456f75aae4d2fc6f35b0b8921a3a8f7cefcc426df3f` | 13401 |
| `policy-engine/src/polisyos/core/artifacts/ownership.py` | `11feb86117d5e06261fea8555d024d46611c5ba40e1b90cc8b6bd5c6b81c6ad2` | 109066 |
| `policy-engine/src/polisyos/core/artifacts/store.py` | `5359836ce92f6e9d05964d85a1ba775f25d6dc04a77cc50f64d8820ae5607dcf` | 272501 |
| `policy-engine/src/polisyos/core/contracts/control.py` | `b0a8ccf45ccd897826c913e71ff0a4bfe0fbcca72235f70087b2652f10dff027` | 93768 |
| `policy-engine/src/polisyos/core/contracts/runtime.py` | `abb367ae9c515a3ea1b603711f888e361f79f8d9b57d9eb52369b68a77cec418` | 378933 |
| `policy-engine/src/polisyos/core/security/access_scope.py` | `55633d848a8dc258a7a28d00ebd69d267ca605992af330269ba5d3398a32fb12` | 3696 |
| `policy-engine/src/polisyos/core/security/tenant_context.py` | `f9051375fa189e5bc3e020356eccc4d14f6c1e6402080cd4261396ef3b56c9e0` | 4174 |
| `policy-engine/src/polisyos/foundry/data_plane/bindings.py` | `f8cf224d4adeb718240e10508f680aeed5d0f1da4f95de9b03e1516848af1980` | 113833 |
| `policy-engine/src/polisyos/foundry/data_plane/selected_row_candidate_scope.py` | `776a6c5006b2bba708f9c1518d5e7b0041a096ec40fa9931adca27a82ef55dad` | 51563 |
| `policy-engine/src/polisyos/runtime/http/execution_policy.py` | `4bb9dae097f9d4d42511fa9f01bbe3fe0ed2c00ecbfafedbc619d4da29a9c3e3` | 16101 |
| `policy-engine/src/polisyos/runtime/http/routes/control.py` | `a85ce7228f3bf37100afe175ea3dde634965ff30ecf0c329f926de5594275a35` | 47902 |
| `policy-engine/src/polisyos/runtime/http/services/control/job_diagnostics.py` | `74d07ea036bdf1f141db70ef14753d546d54ef761a8293baa7c309df8ac29c95` | 44787 |
| `policy-engine/src/polisyos/runtime/http/services/control/job_scope_admission.py` | `9c3dde641f2868262b7e589a9514a826f1fd7be33f293feafe1d91978d4280b2` | 45024 |
| `policy-engine/src/polisyos/runtime/http/services/control/observational_source_access.py` | `faef9afc1a2c72ebd2dd7c6344c68ed4d595d0a9e40aba1027033c908c7efebb` | 8393 |
| `policy-engine/src/polisyos/runtime/http/services/control/owned_attempt_anchor.py` | `1e7d1c79ff61e2490e6672128a2a44a3180376ff02ade6db7f8670a881c87b59` | 205620 |
| `policy-engine/src/polisyos/runtime/http/services/control/run_lifecycle.py` | `83a85ed5d27ded497bd725e4cd1558b2cac10fec266e52cedc56295625da1c18` | 579828 |
| `policy-engine/src/polisyos/runtime/http/services/control_plane_store.py` | `c95f43bebad7f917320530da9691adae63e731a07ad619b42f9b39e3c26bb9ed` | 417530 |
| `policy-engine/src/polisyos/runtime/quality/authority.py` | `8fa8f62049038041520640856fd608ae922bde265ae76a3f1863c7fe404a54c0` | 176510 |
| `policy-engine/src/polisyos/runtime/quality/hte_source_projection.py` | `bb3c0c70e0446eed13ae81fd299e5ca6a702b3ddd8fd95bcc2345c897b592b3b` | 19318 |
| `policy-engine/src/polisyos/scientist/compute/runner.py` | `95db7f839b7ee8d198247f7eb96a0897d6c239484c9afdc368d28aeb3852e929` | 115297 |
| `policy-engine/src/polisyos/scientist/methods/search/uncertainty.py` | `7dece18c25b87aa48b43c26472530f91314964e08d56b19144708590b001028b` | 361587 |
| `policy-engine/tests/_helpers/control_worker.py` | `75e89435f4dbdd23b217433b2ebee2a5f0b8bfb742bd3a0b5d9f7ffb1c30e0a3` | 3098 |
| `policy-engine/tests/_helpers/observational_source_runtime.py` | `af91871d567aa8013cd381cb17a651db8b5f2ad88bfb510c37e0656553a6101f` | 1426 |
| `policy-engine/tests/conftest.py` | `691bf0914650edbef7cc5ededdb2828a8992c513abcaa875f0eb5ac7b318dbdd` | 10518 |
| `policy-engine/tests/quarantine.toml` | `3cd9b583ef697b890efbb764933eaa4125bd0ce328426c83777492b1a7d5b5e1` | 492 |
| `policy-engine/tests/unit/core/artifacts/test_multi_tenant_shared_cas.py` | `435470b8ba933564deb362c31a66ab7e2f8d2c2677ee1ed76e4cbccf4ee35ed4` | 33437 |
| `policy-engine/tests/unit/core/artifacts/test_ownership_history.py` | `1b838ea63ffdade1c95011c7414ff199f1be31f81c28eb3f98e78f42e0358ed4` | 40543 |
| `policy-engine/tests/unit/foundry/data_plane/test_hte_observational_input.py` | `b7b9c4f60b437258b01ee9234f31664975c35fb556f6273c05ea340110c79084` | 63025 |
| `policy-engine/tests/unit/foundry/data_plane/test_selected_row_candidate_scope.py` | `6546a68887bf7f0793b9ec303f1c164bb0e4feda980a0e01cd4403f78ae0130d` | 23549 |
| `policy-engine/tests/unit/runtime/http/test_control_job_execution_intent.py` | `45edda4efdb14a453a146350054e8bacb32a3e7b9ee11f049c55047983bd702d` | 101279 |
| `policy-engine/tests/unit/runtime/http/test_control_job_execution_split.py` | `99a2e068cf67f9cf95a165ad3698f52afeec377f965ad1893c389541fa169456` | 4458 |
| `policy-engine/tests/unit/runtime/http/test_direct_method_evidence_producer_limitations.py` | `f0773dc262dd0568895baa06f1eac8119fb815c8884ff6c23f2c2c09dabdf463` | 4462 |
| `policy-engine/tests/unit/runtime/http/test_observational_hte_resource_summary_contract.py` | `58b4448b661fa8162e5afb020cf0b471fd949e8bb46b2643dd6cbcd4f65c341e` | 32403 |
| `policy-engine/tests/unit/runtime/http/test_observational_method_runtime.py` | `ed6dedba363534f10fd22af88ddf6158ab86ee1b6b660c03cc8eef30dec70024` | 199498 |
| `policy-engine/tests/unit/runtime/http/test_observational_run_intent_contract.py` | `fa8f58eb0d8c381bbe6077c3719f5123077b1cdcfa47c8a8cdebc4e6052fe3ea` | 55679 |
| `policy-engine/tests/unit/runtime/http/test_observational_source_access.py` | `68a7906fa9e3edc9ea3d9d4b896a3ef976ca6f64abeb283ce5d4568a9ca07c0d` | 39015 |
| `policy-engine/tests/unit/runtime/http/test_owned_attempt_anchor_associations.py` | `838ba236850629b5f5d7cb32319da2c4ca820d22472ab152f59f45408ffcab6d` | 141967 |
| `policy-engine/tests/unit/runtime/http/test_owned_hte_inference_basis_materialization.py` | `06a8072794ad747b8b7c3859835a3b0a59643823f509d3e6cc4399ce9ece16b2` | 13509 |
| `policy-engine/tests/unit/runtime/http/test_runtime_api_authz.py` | `21f6a18dbebda5d859acbe751437aacd372523234f44e2d35a8d8a26ba22ed66` | 161598 |
| `policy-engine/tests/unit/runtime/http/test_search_hte_first_assessment_outbox.py` | `12e2ded33a9f3bbe5fcc9cfba732d51d67f0a56afb3acd76ad14338ffd19971e` | 88648 |
| `policy-engine/tests/unit/runtime/quality/test_closure_authority_withdrawal.py` | `71f77fc796ca897cf8befd51cc2a0da589ab8f6300d8490c3f05b4209fe56028` | 7291 |
| `policy-engine/tests/unit/scientist/compute/test_runner_method_execution_work.py` | `b33d9e558f149b1474b750194f3b53079666ccbc4fe2fac857bcb7b09f8c0623` | 28299 |
| `policy-engine/uv.lock` | `ccfdca0e741dc77795f5af61871af5d62e73feebf55c7ffb28cd16e55fe207e9` | 808851 |

