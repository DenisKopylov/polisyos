# Independent actual C60 R6 runtime and four-output adoption review

**BOUNDED GO to Root forward-adopt the exact four genuine R6 staged payloads below, with source/stage/destination-preimage rechecks and ordinary checkpoint/blob readback.** The new producer's complete defining native test passed; no blocking artifact/source-custody finding. No reviewer generator/test/Ruff/supervisor/product/helper execution or canonical/index/ref write occurred. This review used read-only actual-byte/source/evidence inspection and stdlib Git/hash/AST/TOML/XML processing; only these requested RAW review files were written.

This is complete proof for the selected four-output owner's defining staged case at its qualified source/profile. It is not whole C60/B42–B48 or Ray acceptance, semantic type qualification, executed canonical --check after transfer, six-family/global generated freshness, source-property removal PASS, G acceptance or E02 closure.

## Actual source/profile and deciding outputs

D is `policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1/`. Case is `D/c60-four-stub-owner-native-r6-20261028/`.

Qualified committed code: HEAD `3c25549becd143f8f482543a7e6fef60541b4f97`, tree `855949b0ce16e1e69314571ae8193bc9a45b030f`. Actual generator SHA `e3eb3cd00fd7f6fe9ef4c87cfd6f9473a20a0345cbf5dea3ed635a15612d065d`; defining test SHA `b20ddf909d564b287441520bc0f7fb4701a767a7904b642fa2b91e2bf45b1cc4`. These are the reviewed canonical producer plus generic export-layout oracle, with no normalizer/config/export waiver.

Independently verified the exact actual evidence identities:

- `D/c60-four-stub-owner-native-r6-20261028-plan.json`: SHA `20f97960941a2a8ce8260d007dac79c58dc904f75b19171453065990ceb5e800`; plan bytes equal the audit plan and freeze pin.
- `case/audit-result.json`: SHA `0c1ad8c9257583c94214f0a818871d1d8be4c56602e53fbe9cc2a732c020eb46`.
- `case/source-profile-freeze.json`: SHA `da5e6fbd69a3c43a816ed5c7a5b8632fda7fd9728f56a07182e9d702189cc245`.
- `case/pytest.xml`: SHA `5613e05d281e0f7406041d6a1d578cae63250cd8cb12a843d40844f62e7ecb2f`.
- `case/c60-four-stub-owner-native-r6-20261028.stdout.txt`: SHA `439e7c29d97a27ed51b00c390cacd98aa448a73425bd9175c99039281dbf7741`; stderr empty SHA `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.
- Actual observer receipt SHA `b71857fcfc78f531e7ecdb576a1313fe42e5b4cbd4895f5139a279d59740dedf` at `case/readsets/input-readset-82087.json`.
- `D/c60-four-stub-owner-native-r6-20261028-Git-readback.json`: SHA `46cb41467c0ad93e635792f462d5cb690da04a20e11d41b25c1824952ae4e5fd`.
- Actual retained metadata bytes `D/c60-four-stub-owner-native-r6-20261028-root-live-input.json`: SHA `47cd2083e51fd39edbce4d35b7093352695a489ae9a1d21e3c3a3dbe0307b4b8`, exactly matching both freeze input and plan. Its pointed immutable source-frame bytes exist and match the recorded hash, including the four known-WIP rows.

Read full retained stdout/stderr/XML. The exact selected testcase classname/name is `tests.repo_quality.tools.test_foundry_stub_generation::test_actual_stub_owner_staging_and_check_detect_complete_byte_drift`. Exactly **one PASS, zero failures/errors/skips**, complete=true, exit0, no aborted_reason and process group gone. Supervisor wall **34.7838406660012s**, maximum sampled aggregate process-tree RSS **362708992 bytes**, minimum sampled disk **12498231296 bytes**. Pytest's1 passed in31.60s is its own measurement scope, not a substitute for supervisor wall. This solitary new-producer case stayed within its retained600s/2.25GiB profile; the measurement does not price arbitrary future workloads or six-family concurrency.

All **13** freeze pins reconcile, using the retained actual prelaunch Root metadata rather than today's live receipt. All **17** selected committed source/config pins match qualified commit, index and physical bytes. Independently walked the complete **155** observed parent Python paths: every recorded digest equals the qualified commit blob, index and current worktree bytes. Distribution:137 src, six tests, twelve tools; zero mismatches. This includes the actual generator/test and both runtime facade consumers. The observer remains finite: child stubgen/Ruff imports/reads, unimported source, external package/native-library content and complete child PID provenance are not established by this parent receipt.

Root's D helper preserved normal pytest.ini/default-plugin configuration, canonical cwd, redirected cache/temp/pycache/output and one-thread numerical settings under its process-group supervisor. Source/profile/plan data and real successful commands qualify this particular run; installed backend declarations and package metadata are not promoted to a complete external-code audit.

## Complete real behavior and semantic bridge

The passing body now reaches every original branch: real complete four-output stage generation; independent actual canonical-filename/config Ruff check and format --check for every staged member; both actual runtime facade/canonical export and object-identity consumers; initial real staged comparison; all-four marker-preserving byte corruption and STALE refusal with exact physical read/content size/SHA reconciliation; restored-byte PASS; exact missing-victim FileNotFoundError/ERROR; directory-victim IsADirectoryError/ERROR with no invented content identity; full restoration plus real outside-selector witness and explicit absence from all measured operations; canonical-before bytes unchanged.

The generic facade gate flattens every ImportFrom alias, requires the actual absolute canonical owner, exact total/set/self-alias relation and generated __all__ equality with the actual canonical declaration. Both registry10 and composer7 public-name/object-identity relations now passed in the real case. The earlier one-statement formatting proxy is absent. Actual producer applies I-only import organization, format and full canonical policy before any output publication/comparison; no manual output formatting or skipped lint is a deciding result.

Qualified source control flow plus complete actual PASS now supports **seven completed owner calls /14 real stubgen branches** and the planned **92 Ruff invocation branches** (84 producer steps +8 independent checks). It is not a claim that process sampling observed every child PID or audited all backend imports. The test consumes internal Measurement JSONs with full assertions; those are not separately retained raw per-phase JSON receipts, so no independent raw-row replay unavailable in stdout is claimed. Actual deciding pytest stdout/stderr and final full payload bytes are retained.

Missing selected files and deliberate staged corruption are real tested controls. The **three additional source-property removal recipes remain UNRUN** and distinct: comparator removal, normalizer removal and facade export truncation. This PASS does not manufacture their outcomes or scientific/institutional authority.

## Exact real R6 bytes eligible for forward adoption

Independently derived the complete four-member OUTPUT_MAP from the actual owner AST and reconciled it against the actual generated-family TOML. Read every selected R6 staged file in full, syntax-parsed all four, and reviewed the full delta against current known WIP. Stage root is `case/basetemp/test_actual_stub_owner_staging0/staged/`. Full .pyi census under it has five members: the four selected outputs plus the exact known `unselected.pyi` fixture. Only these four selected files are eligible:

| Product-relative target | Bytes | Actual R6 SHA-256 |
| --- | ---: | --- |
| `src/polisyos/foundry/methods/base.pyi` |7401| `b63fce515499ea4ca59a8395f3fff01f5b1958877655a8942fa65e59c1311a94` |
| `src/polisyos/foundry/methods/registry.pyi` |1272| `368c201c9958cb394b2d2ca148b34cdc0632cbc8c7d97710b742c328762a3706` |
| `src/polisyos/foundry/methods/composer.pyi` |943| `3df09480a797cf46cf1e094798e24aa391126a25ab43acfb56bfd56f393080ec` |
| `src/polisyos/foundry/methods/components/composer.pyi` |5317| `e15114ffdad344f609b8d911de474c433bc5f2dce6c3338e70f8128fa332c7b0` |

Companion JSON binds each full actual R6 locator and exact old-WIP destination preimage. These are non-symlink files and contain no corruption class. Eligibility comes from full real restore/check/source qualification plus actual byte readback, not marker absence or equality with a static preview.

Base and canonical composer ASTs are equivalent to the genuine earlier WIP after import/alias-order normalization; changes are producer-applied canonical formatting. The facade delta replaces wildcard representation with explicit same-owner self-alias imports and __all__ preserving actual10/7 public names. Independently rechecked every actual facade import module/absolute level, total and pair set, and __all__ against actual canonical source. No runtime export owner or fifth output is introduced. These bytes expose the already-reviewed current composition/validation contract; broader type/API consumers remain required, and generation is not their execution.

Do not substitute old R3 corrupt files, R4 style-failing WIP, R5 partial-stage results, static Ruff previews or the outside fixture. Even where byte hashes happen to agree, this adoption disposition names the actual R6 output locators and complete R6 evidence, not those earlier incomplete qualifications. No stripping, recovery, hand-edit or extra generator run was used by this reviewer.

## Current Root context, transfer conditions and limits

Observed post-run Root advance: current HEAD `f8e65c5b6bf5bb5c2c6e708616cd87afcfab2cac`, tree `5c4ab585e35fe244579e60a42a1ab604e1996a40`. Its complete **seven-path** change set consists of test helpers/tests/READMEs and intersects the observed155, selected17 source/config pins and four output destinations at zero. This is an explicit finite qualification, not a claim the whole tree is unchanged or that all external/child reads were observed. Current physical four-WIP map, live ownership and hash-bound current source-frame rows remain exactly the admitted preimages; index empty and no additional tracked dirt. The qualified run source stays3c255..., not relabeled to the later commit.

The complete four-member stage-to-HEAD comparison also settles the Git footprint: **four physical transfers, three resulting tracked Git changes**. The base payload restores the already-committed b63fce... bytes and therefore becomes clean; registry, facade composer and canonical composer remain changed. Derive the ordinary commit/staged set from those actual three deltas while reading back all four adopted payloads. Do not demand a fabricated four-path Git diff or confuse this with a smaller generated family.

Root may now forward-atomically replace exactly the four declared old-WIP preimages with exactly these actual R6 bytes, rechecking stage hashes and destination bytes, recording the new source frame and using normal hooks/commit/committed-blob readback. No hand-format or broad dirty exception is necessary. Run the planned physical four-file Ruff check/format check and genuinely required affected type/import gates against the resulting source. The specific actual runtime facade imports here are PASS; broader C60 execution/type/import consumers are not thereby qualified.

A source/profile-preserved validated-stage→canonical byte-identical transfer is custody evidence. Do not call it an executed canonical owner --check unless that command is actually run. There is no reason to replay the unchanged full seven-call/92-Ruff case merely to give the transfer commit another runtime label; run any genuinely affected mandatory gate honestly.

P40 disposition: known producer/Ruff and statement-layout proxy classes now have a real complete defining PASS at the repaired semantic quantity; no new blocker found and no hypothetical verifier ladder requested. **Bounded actual runtime/artifact GO for exactly this owner/case and four generated payloads.** Global/native six-family freshness, complete C60/B42–B48/Ray, source-removal outcomes, broader type qualification, G acceptance and formal closure remain absent/UNRUN as applicable.
