# C72 input roots r2 independent delta review

**GO for Root composition and defining-property verification of the exact final seven-path R2 union. No blocking source finding remains.** Runtime, semantic removals/restored positives, physical-topology Ruff/import/architecture checks, ordinary N7, predictive S10/HTTP, G acceptance and formal closure remain UNRUN.

The manifest `repairs/C72-input-roots-r2/manifest.json` is SHA256 `2a5ac1d8acdf345129c9eb2b00d405255381d041078c97c96633ea8d48ab3af9`. Complete Root-base-to-final `source.patch` is 32,836 bytes, SHA256 `1e05aaa4aed9e4daf083fc9450703786964a1489661e52c41166268afb5d38be`; the exact two-module R1-to-R2 delta is 2,098 bytes, SHA256 `69e7f0656eff6e9666525bfc8fc3c194cde8c9d0e87b4d27b7a88b60da2a5d49`. Base remains 545c6990e2bfa42bf580b475e23cf88df04e71d8 / tree abd7d9913680d5531081c45536c1cf7d7d701835.

This follows the explicit R1 erratum (`C72-input-roots-r1-independent-erratum-v1.md`, SHA256 `62c8bda620cc8ede801d53927606e4bbe3cdc54800340601c06b487b9c7f8888`). The first source GO missed the actual global writer fixture's default disabled ownership; exact R1 remains HOLD. That error is preserved in the review history, not erased by this delta.

## Actual delta and custody property

Both new modules now provide their own `@pytest.fixture store(cas_root)`. Each constructs actual Core `FileSystemCAS(cas_root, tenant_id=_TENANT, cell_id=_CELL, ownership_enforced=True)` before any test writes. The matching tenant/cell constants, actual Core producer calls/scopes and strict fresh readers are unchanged. This provides real ownership recording at write time through the existing mechanism, instead of asking a fresh enforced reader to trust unrecorded bare-store writes. No reader guard or Core contract is weakened, and no synthetic ownership receipt is introduced. The actual Core constructor/write/read law and its pinned base hash/blob were independently checked.

This closes the concrete R1 setup mismatch at source level. It does not predict runtime outcomes. The inherited source-root correction remains one coherent owner change: independently admitted SKG root; no-selection forwarding; fixed separate output owner; optional generic kw; real canonical selected source in the credal sibling; exact selected path/type/version/snapshot/schema/byte checks. Legacy physical root aliasing remains permitted; no general filesystem sandbox is claimed.

## Verified final union

All seven baseline/current preimages and postimage length/SHA256/Git blobs match. Independent in-memory reconstruction of the complete patch yields all seven exact postimages; R1-to-R2 reconstruction yields exactly the two new-module postimages. The other five files are byte-identical to reviewed R1. Current `git apply --check` exits 0 with empty stdout/stderr at Root 72d83ce91ad2e75f508eda4c9caaa2bbb6311e3c / tree 579fb9f6c66225c2d82f9ede27282859e658dfa2. This observation is not a reservation.

The sparse union deliberately stores only two changed files in R2. Root must use each manifest `files[].postimage_file`, resolving it under Root and verifying its hash; five point into immutable R1. Assuming every postimage is next to the R2 manifest would lose the mechanism/companions.

All six new R2 artifact links and six retained R1 links verify. All five final Python files parse. The two new static Ruff records' eight steps have matching full stdout/stderr hashes and zero exits; the unchanged three Python inputs retain their R1 checks. These are canonical-filename stdin checks, not final physical-topology proof.

All six complete literal-symbol/AST censuses reproduce 8,069 base tracked `.py` files and 8,071 with overlays, including changed test hashes/line positions. Direct-call ordering is normalized; no record is missing. Dynamic aliases, non-Python and external callers remain outside this bounded census. The two modules still define nine unit parameter cases plus one integration case; actual collection is UNRUN.

The three helper property-removal patches/positive/mutant hashes are unchanged and remain applicable to the same test node names in R2. The actual positive must run first; removal must turn the same semantic assertion red, not fail during setup/backend/import, followed by exact restoration and a passing positive. No mutant/restored output is claimed here.

## Boundaries and next action

Footprint remains two private test-helper mechanisms and five companions: the real credal caller, two behavioral modules and two helper/unit navigation READMEs. No product/API/DTO/schema/lock/generated/public surface change or release fragment is required. Root retains canonical/index/ref ownership, must recheck all seven preimages, atomically place the union and run physical full-file Ruff/format plus affected import/architecture checks.

Use the actual bounded fixture cases and three removal/restored witnesses on a frozen composed source with complete compact deciding outputs and actual source/readset/backend/input bindings. `NEXT-CLOUD.md` correctly remains an ingredient note: publish/read back a normal immutable author checkpoint before creating a new exact-bound standalone Cloud task. Signed exact-version FTS setup and compact capture of actual HTTP planner premises are routine alternatives to try, not results already established. No blanket replay of the unchanged two synthetic S10 passes is required merely for a new HEAD.

The four B16/B32/LA-051 occurrences, eight V4/V7 assignments and six task-finding edges stay open; E02 totals 26/127/282/291/319 and B198 remain unchanged. Source GO establishes neither ordinary producer/compiler/planner nor real measured calibration/fresh HTTP acceptance. P40 keeps this in one existing fixture-admission class; P29/P38 retain semantic controls; P35 records complete bounded denominators; P37 separates static reconciliation from runtime proof; P41 does not invent inherited-red ownership. State: `verification_missing`.

Only read-only Git/file/stdlib/AST checks and RAW review outputs were used. No product imports, pytest/native/numerical execution, installs/downloads, canonical/environment/index/refs/objects mutation, source copying, commits/push or children.
