# C77 structural owner r4 independent final source review

**Source verdict: GO for bounded source integration. Overall verification: PARTIAL. Runtime evidence: NOT ESTABLISHED / UNRUN.** No remaining concrete blocking source finding was established in the frozen r4 delta. This is acceptance of the bounded proposed kernel for root integration and real verification, not a runtime PASS, a wired capability, or closure of an original criterion.

## Exact frozen target and scope

Manifest SHA-256 `4f517b829408ca139fb14c6413dad1387976e771dc30db5ec968307973b30edd`; source.patch SHA-256 `d1e0e69c71679abe03dfe3d6fda9e4b3fd99b2fba533ce266117e82a854c7182`, 200108 bytes. Independent stdlib traversal matched the complete 12 postimage paths, all sizes and all hashes: 9 Python, 2 Markdown, 1 TOML; 5 mechanism and 7 mandatory companions. Root HEAD readback was `72d83ce91ad2e75f508eda4c9caaa2bbb6311e3c`, on the intended root worktree; ordinary advancing root commits are not an incident. All proposal bytes remain unapplied RAW at this review boundary.

This is a delta review of `repairs/C77-structural-owner-r4` against the immutable r3 source, informed by the complete r1/r2/r3 findings. The source change closes the named scalar-carrier/output-profile quantity rather than matching one large integer. Readback also covers the new immutable selected source-declaration projection requested by the root-owned bridge.

## Exact-value property and stopping point

`profile.py:scalar_frame`, `scalar_rows`, `align_scalar_series`, and `cast_series_losslessly` derive their columns and scalar comparisons from actual held frames. Object-backed per-column working values prevent a shared homogeneous row buffer from rounding an unrelated integer. Candidate casts are compared to retained original wire scalars before promotion; reversible numeric representation changes are allowed only for the declared output projection, while artifact restoration requires strict tagged equality. Actual alignment indexes are reconciled to the complete held typed key set. Mean/median remain explicitly declared float64 numerical programs; mode retains observed scalar values.

UNION now selects tuple/dict rows from the object carrier and builds an object result before per-column projection. JOIN working columns and sidecar iteration avoid value-bearing row Series. OVERLAY alignment preserves scalar values; CONSENSUS uses the same carriers and tuple rows. The output projection restores a representable common source dtype and refuses a target that cannot represent the held scalar exactly. This is a generic content check at the actual carrier/emission boundary, not a marker, dtype-name whitelist, or enumerated ID patch.

The independent oracle now supplies integer keys beyond float precision, nullable Int64/UInt64/boolean and float columns, declares complete expected values/dtypes, and exercises direct production, selected fresh readback and nested continuation in all four strategies. The multi-input generated-name oracle no longer disables dtype checking. A separate unrepresentable-common-dtype witness expects a typed refusal before publication. These are inspectable semantic oracle sources; their actual runtime results remain UNRUN.

The bounded residual is explicit: this schema-free artifact profile does not provide a schema-aware lossless dtype-join/identity rule. Unsupported mixed key declarations and unrepresentable common output dtypes refuse. Such a worked example is within that declared limitation, not a new P40 repair round. P29's stopping point applies: the generic carrier/reconciler derives its domain from the actual columns and scalars, so no recursive verifier or hypothetical future extension gate is required for source acceptance.

## Complete bounded census readback

`scalar-carrier-census.json` SHA-256 `3b37568b006ff212ca0391df7288a40033b5225a1862d4ab3df52bfab71ad396` records 51 source operations. Independently walking the complete direct federation package Python-file set confirms its 9-file denominator and every selected byte hash (5 postimage overrides plus 4 unchanged canonical files). An independent AST walk of those actual 9 files finds no `iterrows` call. This is a bounded package claim only, not repository-wide absence or runtime proof.

An independent AST walk of all four proposed test Python files finds no direct CompositionRequest attribute mutation/setattr and no `check_dtype=False` call argument. This verifies the exact prior fixture/property omissions in the complete delivered test scope. It does not prove test execution or all conceivable pandas behavior. The author's logical-path Ruff/format receipts remain static evidence; physical integrated-path checks remain root-owned.

## Prior classes and bounded capability

- Custody/status: actual held selected parent bytes are resolved and replayed; copied attrs cannot self-admit. Typed `limited_candidate_unverified_leaf_history` remains visible for raw/unknown ancestry. Selected-byte recomputation does not promote leaf history, issuer, authorization, currentness or source-universe truth.
- Physical relation: parent edge occurrence namespaces, physical participant/exclusion/absence projections, and audit row/source-pair identity address the named same-ID/nested/duplicate-event witnesses. Duplicate-key OVERLAY/CONSENSUS and unsupported composite ranking have explicit typed refusals.
- Work/cardinality: whole-operation preflight, null-aware key-count propagation, aggregate profile, predecode work/string checks, output/audit reservations, paired writer/reader profile and staged actual fresh verification before manifest-last publication remain in source. Conservative admission may refuse a fitting eventual result; no total pandas/native O(1) claim follows.
- Audit sample: bounded heap tie eviction reverses the whole declared priority/ordinal order, with forward output projection and an actual JOIN surface oracle for mixed priorities. Required real mutation/restoration remains UNRUN.
- Effective rule/profile: strict typed request JSON roundtrip, supported resolver policy/seed and per-column enum readback are retained; unsupported schema/custom resolver/quality-coverage profiles refuse before publication.
- Bridge projection: returned `source_declarations` is an immutable sorted tuple of token/canonical-declaration strings from the replay-compared basis. It gives the root-owned bridge the whole selected declaration quantity without trusting mutable attrs or the carrier's declared trust. This remains software/candidate evidence, not institutional authority.

All eight original occurrences still require their deciding runtime oracles and actual source removals/restorations. B138 additionally needs the production bridge. B139 retains its selected bounded compose/result/summary surface and external HTTP/export `surface_out_of_scope`. B140 row/null/budget behavior, B141 full projection, B142 empty-versus-failure next read, B143 live details plus scoped Python allocation, B144 used-secondary/index/NONE behavior and representative follow-up, and B145 contributor arithmetic all remain `verification_missing` until executed. The semantic oracles are now present in source; no original criterion is closed here.

The root-assigned operational route remains the existing FED `fabric/api.py:fabric_get_data` -> source fetch -> selected persist -> fresh read extension, with a real non-test terminus and unchanged-negative production call removal required. At this boundary the isolated kernel is `implemented_but_not_orchestrated` / `bridge_missing`, and runtime verification remains missing. Public/generated companion review stays pending root; the release inventory flag remains false. No helper-only wired claim is accepted.

## Evidence discipline and closeout

Read the frozen delta, actual scalar producer/consumer source, semantic fixtures, README/release/register, PLAN/REMOVALS and bounded census. Reopened the failure/repair register before closeout; relevant P01/P02/P03/P07/P14/P29/P31/P32/P33/P35/P37/P38/P40/P41 remain respected. Ran only read-only source views and stdlib identity/AST traversals. No product imports, native/runtime tests, env changes, real mutations/removals, index/ref/object writes, cloning or worktrees occurred. Only this new raw review pair was written.

Next acceptance signal: root integrates this exact full sparse patch over matching preimages (not r1+r2+r3 overlays), rereads actual branch bytes, completes physical-path checks/public-generated companions, freezes source, and runs the deciding runtime/removal wave plus the assigned production bridge. Keep the complete deciding outputs. No failed check may be labelled inherited without exact slice-base replay and complete input-denominator disjointness.

B198 historical closure, ledger/appendix dispositions and all original B138-B145 `closure_now=not_adjudicated` remain unchanged. No G/R9/GY/Atlas acceptance or global count is assigned by this source GO.
