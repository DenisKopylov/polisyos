# C81 admission r1 — independent full source review

**Verdict: HOLD for source composition.** The frozen owner repair closes the previously observed
retained-coordinate omission at its actual pre-emission parser, but the exposed in-memory
consumer can still use a different source law after its comparison. The proposed positive
producer/selected-reader/consumer tests are substantive; none has been executed or establishes
a current runtime pass. This review is of the exact r1 packet, not any later repair.

## Exact subject and evidence

- Proposal base: commit `545c6990e2bfa42bf580b475e23cf88df04e71d8`, tree
  `abd7d9913680d5531081c45536c1cf7d7d701835`.
- Frozen manifest:
  `repairs/C81-admission-r1/manifest.json` SHA-256
  `e82b2c33bd121d494958509e5eed25e1d712ff5776d9dd74b390633a208fe13c`.
- Complete patch: `repairs/C81-admission-r1/source.patch` SHA-256
  `68988283d3c45f8b81083c8a73e6e17288ba3a0a1bc01735e4893a2191e00488`,
  53,432 bytes. The paths are under
  `LOCAL/raw/e02-execution-20261027/` unless another prefix is given.
- Source review observed HEAD `3c25549becd143f8f482543a7e6fef60541b4f97`,
  tree `855949b0ce16e1e69314571ae8193bc9a45b030f`; all five owned path
  preimages matched at inspection. Four unrelated tracked Foundry `.pyi` files were already
  modified. HEAD may advance normally; composition must rebind the affected paths and real
  deciding readset, not restore this HEAD.
- A separate in-memory unified-diff reconstruction checked every hunk, base SHA-256/Git blob,
  all five exact postimages, lengths and blobs, and parsed the three Python postimages. It
  independently checked all 17 manifest-declared supporting artifact hashes and sizes. All 49
  C81-r2 prompt pin rows match their recorded blob, byte count and SHA-256 at the proposal base.
  The pins are declared inputs, not a transitive executed readset.
- All six exact removal patches apply to their declared source in memory, yield their declared
  mutant hashes and parse as Python. They have not been run. The author's six retained Ruff
  command results and 12 stdout/stderr byte hashes reconcile to its `static-final-r2` record;
  this reviewer did not rerun Ruff or claim a physical composed check.
- Independent AST comparison confirms all five original IR test definitions and six original
  MethodJob test definitions are unchanged. This does not prove successful collection or execution.

## Blocking finding: equality is not source-bound execution

**High confidence source trace; no product runtime was executed here.** The defining property is
that the actual evaluator and exposed row reader consume the exact content-bound finite source
values and coordinates. The current Monte Carlo implementation instead compares a recomputed
model with the caller's model using ordinary Pydantic/Python equality, then uses the caller's
mutable parameters. Those predicates diverge for numerically equal but observably different
values:

1. The r1 `PosteriorSummaryV11` is shallow-frozen but its `parameters` field is a mutable
   dictionary (`repairs/C81-admission-r1/policy-engine/src/polisyos/ir/analytics/posterior_summary.py:101`).
   Its owner validator reconstructs the correct source-derived dictionary at lines 128–157.
2. After a fresh read of a source containing `(-0.0, +0.0, -0.0, +0.0)`, replace the
   `parameters["x"]` entry with an unvalidated `model_copy` whose draw tuple contains only
   `+0.0`, leaving source ref, hash and payload untouched. Python treats the two zero signs
   as equal and the installed Pydantic `BaseModel.__eq__` compares its model dictionaries
   with ordinary equality. The locally inspected Python equality gives `-0.0 == 0.0` while
   `math.copysign` distinguishes them.
3. `policy-engine/src/polisyos/foundry/uncertainty/monte_carlo.py:954` recomputes the source,
   but line 962 accepts that equality and lines 965–967 take rows and selected point from the
   supplied object. The joint-matrix digest at lines 970–989 validates the altered rows against
   a digest freshly generated from those same altered rows; it does not compare those rows to
   the recomputed source. A `copysign` evaluator sees four positive signs instead of the
   source's alternating signs, while the output still carries the original source hash.
4. Similarly, changing only a source-derived `selected_point=0.0` to unvalidated
   `False` passes equality and is forwarded to the evaluator; the matrix digest does not
   include that point. A type-sensitive evaluator can distinguish it. The boolean *draw-slot*
   variant is not used as this witness: matrix DTO coercion can make its digest refuse first.
5. The public `PosteriorSummaryV11.joint_row_values()` method itself reads the mutable map
   directly at r1 lines 160–181, with no source reconciliation. It can return altered rows
   even for a plainly unequal mutation.

The new forged-consumer test at runner-test lines 969–1004 checks values such as `99.0`,
which ordinary equality detects. Its signed-zero test at lines 1007–1035 checks a correct
fresh read without mutating the returned model. Neither distinguishes this counterexample.
A direct owner-writer negative based on `model_construct` and a post-validation nested-dict
mutation are also absent; the current seven direct-writer mutations use `model_copy`.

**P40 bucket:** same complete posterior source-law, coordinate and consumer-admission class
as the prior Cloud omission, one level deeper, not a new naming exception. Widen the source-bound
quantity once: derive a private typed source projection and make both the public row path and
the real Monte Carlo path use that projection for the selected point and all rows, or provide
an equally strong general invariant. Preserve refusal of unequal corruptions, real owner and
selected-view checks, and exact source values. Add direct and fresh-reader/real-evaluator
falsifiers for nested mutations, equal-valued IEEE signs, equal-valued type aliases and
`model_construct`; an isolated remove-the-property control must make the same assertion fail
while surrounding markers/guards remain. The author is evaluating this in a separately frozen
proposal; no revision is reviewed by this report.

There is a further *unexecuted concurrency risk in the same bucket*: r1 hashes the caller's
mutable `source_draws_payload` at lines 201–204, then subsequently reads its nested
`parameters` at lines 224 onward. Owner admission starts from a private frozen serialized
payload, but the direct in-memory consumer can receive an externally mutable dictionary.
A change between hashing and decoding can bind different content to the checked hash if the
caller also aligns its declarations. A single private snapshot whose same bytes are hashed
and decoded would close this; otherwise the permitted concurrency boundary and its real
falsifier must be stated. This is a static risk, not a claimed run.

## Weight-format boundary in the same law class

The helper checks only top-level `weights` and `sample_weights`, while accepting other
extra payload fields. A correctly re-hashed draw payload augmented with
`sample_weight=[0.9,0.1]` is not rejected by that check and is processed with equal draw
mass, even though `sample_weight` is the actual weight argument spelling in
`foundry/methods/catalog/bayesian/protocols.py:392`. The resulting DTO says
`weight_status=not_supplied_by_source`. The native `canonical_draws_artifact` producer
currently emits the fixed unweighted fields and this review does **not** assert it emitted
such an extension. The question is therefore the admitted input contract: either prove and
enforce the complete source format excludes weight-bearing extras, or preserve a truthful
unsupported/unknown refusal for them. Do not repair a growing list of field spellings. A
source-bound purported-weight negative belongs to the same structural law admission.
The existing test checks only `weights`; runtime remains unrun.

## What the repair and tests do establish from source

- The helper traverses every source parameter and tensor coordinate, checks chain/draw axes,
  finite binary float64 data, decoded size and payload hash/ref, derives separate mean,
  median, inverse-CDF bounds and named selected point, and refuses a duplicate exposed key
  before assigning the dictionary entry. Scalar/vector, tensor and nested-bracket aliases
  are tested in both source insertion orders; valid multichain tensor and isolated bracket
  names have positive source tests.
- The full source-derived component set is checked against the DTO when the frozen payload
  passes the real IR owner writer. The writer's `_prepare_owned_json_artifact_write`
  validates a private decode before its real Core `put_json` / `put_bytes` path. The
  proposed counting CAS observes that real call, requires zero calls for bad payloads and
  one call for the valid payload; it does not replace the writer. This closes the specific
  old omitted-coordinate writer proxy in source. The actual runtime result is unestablished.
- The controlled fixture calls real `run_job`, real method result/evidence persistence,
  existing summary bridge, a selected evidence profile and a new FileSystemCAS reader;
  controlled finite draws do not attest a native fit or independent scientific evidence.
  The intentionally injected generic-Core historical/malformed records are negative cases,
  not positive owner proof.
- Source tests specify the 99-zero/one-100 point roles; two independently counted 100-row
  atom laws with equal mean 0 and variance 6/5 but P(X=0)=2/5 and 7/10; complete ordered
  outputs and attempt counts; and same/opposite four-row joint pairings, with independent
  difference variance 0/4. An independent standard-library Fraction calculation confirms
  those values and the test-only two-ULP bounds. The missing-output case retains its source
  slot and states successful-draws-only conditional semantics. These are source assertions,
  not observed passes.
- The selected-evidence sibling/profile, absent source/profile, wrong kind/schema,
  changed source, kernel and credible-mass cases reach the actual fresh-reader seam in the
  test source before any intended evaluator. The required runtime qualification still must
  show the expected exception, no evaluator calls and real selected source identities.
- The six proposed single-property mutants cover injective projection, whole owner
  admission, named mean, joint row order, selected evidence edge and actual evidence
  re-resolution. Static patch applicability is not a semantic red or restoration proof.
  The new whole-consumer snapshot property will also need its own real removal witness.

## Caller denominator and scope

An independent literal/AST walk of all **2,828 tracked
`policy-engine/src/**/*.py` base blobs**, substituting the one sparse owner postimage,
reproduced the author's source-set SHA-256
`9175974efefa85bd28c2d03b147cfc7a44804d9b4951aad5158a213464e60384`.
It found eight files mentioning the selected symbol set. With `joint_row_values` added to
the selected names, it found 11 literal calls, including the real Monte Carlo call at line
965; the author's 10-call count used a narrower symbol set. Both are limited to tracked
Python source and literal/direct-import alias recognition. Neither proves absence of dynamic
adapters, tests, non-Python tooling, runtime-loaded modules or subprocesses. The default
Scientist route remains the existing envelope route; this explicit candidate consumer is not
proof of a changed default production path.

## Authority and remaining evidence

B201@UQS-01 and B202@UQS-01 are the two original occurrences, at
`closure-decisions/coverage.json#/findings/121/criterion_refs/0` and `/122/criterion_refs/0`.
The commissioned E technical choice and the older E accepted/proposed-closed outcomes are
separate from G acceptance and the formally held/not-adjudicated ledger. E selected the
weighted profile-1.0 envelope/carrier and named-mean route; this current finite unweighted
candidate profile 1.1 is a distinct artifact and does not establish that route. S3/B31
identification, E-M1 objective/Hessian/covariance semantics, source fit/mixing/ESS,
calibration, currentness, institutional authority and G acceptance remain separate.
`gate_eligible=False` remains the source literal; `closure_ids=[]`.

No test, product import, native run, dependency installation, canonical edit, Git index,
ref, object, or environment change was performed by this reviewer. Before any source or
runtime PASS: independently review the complete widened frozen revision; compose only
matching preimages; run the physical Ruff/format and relevant ABI/public/generated checks;
perform actual focused old-base red or label it UNRUN; run the two affected modules,
selected old consumer/adapter companions, the native NumPy HMC pilot, and the isolated
same-test before/mutant/restored controls with actual source/readset and environment
binding. Retain complete deciding bytes. G adjudication and the historical weighted chain
remain independent.
