# C88 — Published r6 C60 portable verification

Bound to the actually published topic source below. Root independently reviewed the predecessor commission (SOURCE GO only); this binding/control-replay delta needs independent delta review before launch. No mid-run coordinator message channel is assumed.

## Mission and fixed input

PolicyOS is a causal operating system for policy justification. Its typed producer → artifact → bridge → consumer → verification → surface chain must stay honest; a candidate/LLM declaration is not authority. This task verifies the existing C60 composition-custody and generated-ABI mechanisms; it adds no legal/institutional/scientific authority. It does not own G acceptance or formal E02 closure. Preserve historical B198 and all other accepted dispositions. Do not implement R9/GY/Atlas.

Expected source HEAD: `192fc44303c63e52e4dfa8e0b4ee77790bae3394`.
Expected source tree: `fd6881f1c9fc1e63984ed0b24095e0482faba2e9`.
Selected published input branch: `codex/e02-composed-progress-20261028-r6`.
Root remote-readback receipt: `Coordinator-only receipt LOCAL/raw/e02-execution-20261027/publication-composed-progress-r6/remote-readback.json SHA256 a7958d54a971b4c7fd5da488fb12c06abc455d96650e694687e868866522dce3; ordinary hooked push exit0 and fetched remote commit/tree verified. Not a Cloud filesystem input; identities are fully stated here.`.

Selected Codex Cloud environment: `polisyos`, ID `6965429cdb308191a0e6eb63cb118ea3`. This is a Codex Cloud task, not a local chat/ChatGPT Work Cloud task. The source is published at `https://github.com/DenisKopylov/polisyos/commit/192fc44303c63e52e4dfa8e0b4ee77790bae3394`. The coordinator-only receipt is already verified locally and need not exist in Cloud. All required worker inputs are Git source at that exact cut plus the fully embedded compact patches/client bytes below; no local RAW path is a required Cloud input.

Root rechecked every one of the predecessor commission's39 explicit input files against published Git blobs and physical source: all unchanged. Complete intervening delta from the predecessor cut is111 paths:104 continuation-plan documents/evidence plus the C81 seven-path slice (two product Python, two tests, two READMEs and release fragment). Product changes are `src/polisyos/foundry/uncertainty/monte_carlo.py` and `src/polisyos/ir/analytics/posterior_summary.py`: posterior DTO source-format/recompute admission and consuming detached recomputed values. Neither is in the complete155-entry R6 parent-observed import set. That finite zero does NOT prove child stubgen/mypy/plugin import equivalence. C60 base.py already imports lazy ir.analytics; fresh commands must preserve/report actual transitive C81 consequences. Do not add C81 or whole IR suites merely from a shared package prefix, nor call new type diagnostics inherited.

At entry print/read actual cwd, branch/detached status, HEAD/tree, compact tracked/index/untracked classification, tools and real VM disk/RAM/CPU. A work branch, detached HEAD and no origin are acceptable when actual HEAD/tree match and checkout is isolated. If mismatched, report actual identities and preserve useful diagnosis/receipt; do not switch, reset, recreate origin, push work/main, or guess an equivalent source. Explicitly verify producer SHA256 `e3eb3cd00fd7f6fe9ef4c87cfd6f9473a20a0345cbf5dea3ed635a15612d065d` and test SHA256 `b20ddf909d564b287441520bc0f7fb4701a767a7904b642fa2b91e2bf45b1cc4` before running. If a later Root-owned source changed them, stop this exact commission with mismatch, not a silent pin update.

Read actual AGENTS.md, policy-engine/CONTRIBUTING.md, `policy-engine/docs/research/e02-cloud-test-plan/execution-prompts/HANDOFF.md`, failure/repair register, tools/devx/foundry/README.md and current generated-artifact family. Original C60 criterion trace is B42–B48, `policy-engine/docs/plans/active/agent-packages/PolicyOS_E02_Combined_Agent_Package/source/B_r19_original.md` lines788–899, pointers `#/findings/167/criterion_refs/0` through `#/findings/173/criterion_refs/0`; locate the published copy through canonical bindings rather than assuming a local absolute path. Missing research prose is not permission to reconstruct authority. This bounded commission concerns byte freshness, canonical style, complete owner-derived facade exports and typed/imported context consumers; it does not claim all seven criteria are closed.

Current source owner is `tools/devx/foundry/generate_stubs.py`: two real stubgen calls render OUTPUT_MAP's four paths `src/polisyos/foundry/methods/{base,registry,composer}.pyi` and `src/polisyos/foundry/methods/components/composer.pyi`. REEXPORT_OWNERS derives names from actual canonical owners' __all__, then actual Ruff import organization/format/full policy runs against canonical logical filenames and ruff.toml/ruff.generated.toml. Missing backend/config/export declaration is ERROR before publication. A dry-run is not a freshness proof. Compatibility composer remains canonical-owner reexport. Checkpoint validation_context is Python-owned, not a shared IR/OpenAPI/client schema.

Local R6 actual defining-node PASS and Root transfer already exist at source `3c25549becd143f8f482543a7e6fef60541b4f97`, tree `855949b0ce16e1e69314571ae8193bc9a45b030f`, retained Mac profile: all seven owner calls, fourteen stubgen children, actual ten/seven facade import statements, all byte/error/outside controls and four independent Ruff checks. This Cloud task supplies its own source/profile results and three new source-property removal outcomes. Do not relabel local R5 partial-render success as full R6, treat marker presence as proof, or count author evidence as independent review/G acceptance. Published R6 receipt and independent review are available under `policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/executor-continuation-plan-20261027/evidence/local-execution-r11/`: `c60-four-stub-owner-native-r6-20261028/receipt.json` and `reviews/C60-four-stub-owner-r6-actual.md.gz` (compressed SHA256 `3c711e79a8d172c84de0f7fdcecbbe42d8bdce7f7a20070a2ffb0e6ffd10035e`). Do not replay the unchanged seven-owner/fourteen-stubgen R6 staging suite as a baseline or restoration positive just for this HEAD. It remains historical local bounded proof; full staging suite at this Cloud source/profile is UNRUN, not a new Cloud PASS.

## Ownership and available inputs

This task has no persistent product-code writer lease. Only transient single-file source mutations of `policy-engine/tools/devx/foundry/generate_stubs.py` for the three exact controls below are permitted in this isolated checkout; restore exact original bytes in finally. Never mutate shared Root source or an environment in another task. Do not change test behavior, Ruff/mypy config, schema/DTO, lock, fixture, signature baseline, canonical generated artifacts, public inventory or acceptance flags. Persistent outputs are compact evidence/receipt and these static client witnesses under an ordinary NONignored owned directory `policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/C88/cloud/verification-r1/`. Required source tests/APIs/config/generated companions already exist in the published cut. Root owns common generators, final artifact adoption, public inventory/reference projection and composition.

The published Git source, uv.lock, pyproject.toml, default pytest config/conftest, actual source tests, four generated stubs and Ruff/mypy configs are sufficient. The three small mutation patches and both static clients are fully embedded below. Production payload, credentials, private RAW/CAS/DB, Mac retained D harness and historical untracked receipts are NOT available or required. Never fetch/copy them. A portable fixture proves software mechanics only, not production provenance. Do not copy checkout/environments/dependencies/CAS/database/recovery archives into evidence.

## Environment/resource and transport admission

Reuse any valid provided environment. A fresh Cloud checkout may require its supported locked setup: from product root, `uv sync --frozen --extra lint --extra test --extra runtime`. Measure actual space first and after setup; 32GB is approximate TOTAL DISK, not free space or RAM. Base dependencies include JAX; do not install unrelated methods-full/Ray/production backends to green optional siblings. Do not edit global config, unlock dependencies, replace supported Python3.14 or suppress missing packages. Record actual uv/Python/mypy/Ruff/pytest versions, interpreter and import origins. Local starting versions were mypy1.19.1/Ruff0.14.10; use frozen-lock actuals and report differences. If setup fails, preserve full deciding output, bounded alternative supported setup attempt and exact missing dependency; mark ERROR/UNRUN, not product FAIL.

Use one native/type numerical job at a time, CPU backend and one numerical thread (JAX_PLATFORMS=cpu; OMP/OPENBLAS/MKL/NUMEXPR thread limits1). First actual generator profile alone; initial external case budget600s, local retained 2.25GiB RSS cap is a resource estimate, not a Cloud guarantee. Measure real available RAM/peak RSS/wall and scratch growth. Keep at least measured setup/run headroom; initial planning disk floor6GiB with expected small run growth is not permission to exceed VM capacity. No DB/port is needed. If backend/resource is unavailable, preserve useful source/receipt and continue independent available checks. Exit137 alone does not prove OOM. Bound first mypy target separately; timeout is harness/resource ERROR until diagnosed, not semantic FAIL. Do not launch full Core/IR/CI/all127 bundles, six-family guardrails freshness or repeated unchanged full suites.

**Delivery is measured managed task diff/snapshot, not ordinary Git push.** Root has received source/new files through that channel; ordinary push recently returned403 and is OPTIONAL, never a task prerequisite. Keep all required small evidence files NONignored and include their bytes in ordinary task changes/managed snapshot. Explicitly stage only owned evidence files if necessary for the managed diff; normal commit/hooks are allowed but not mandatory if the managed snapshot already supplies bytes. Do not require origin, switch branches, push work/main, invent a workflow/uploader or credentials. Root's publication/readback of the INPUT source is separate from your OUTPUT transport.

Before expensive controls, create a small admission receipt and a complete quiet stdout gzip with actual identities/tool/resource admission in that owned nonignored directory; ensure it appears as a new file in managed output. Continue autonomously; do not wait indefinitely for an unavailable mid-run reply. At completion make source/new-file content and required deciding outputs available through the same channel. An ignored Cloud path plus SHA is NOT delivered evidence. A hash proves nothing if Root cannot retrieve its bytes. If a delivery channel cannot carry a necessary file, label unavailable evidence and the exact rerun required, not automatic replay of every Cloud computation. Never claim delivered before Root verifies bytes; your receipt labels prepared/available-to-managed-snapshot, with final Root delivery verification separate.

Classify outputs A necessary implementation/reproduction/G bytes → deliver; B reproducible from Git+command+available input → recipe/locator; C noise/duplicate → omit; D nonreproducible deciding evidence → preserve and ensure actual transfer, explaining exception. Retain full quiet command output for each deciding command/control; gzip losslessly if needed. Do not emit debug payloads/source copies. Target small logs/receipts, not a fixed cap that hides genuine failure; disclose actual bytes/hashes and any exceptional size before relying on transport.

## Execution order and required judgments

1. Freeze exact source/inputs/profile and admission; verify producer/test pins. Read actual source rather than guessing a diagnosis. Retain compact source identity and changed footprint.
2. One real canonical four-output comparison under supervisor, from policy-engine: `PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 PYTHONHASHSEED=0 JAX_PLATFORMS=cpu PYTHONPATH=src:. .venv/bin/python -m tools.cli foundry generate-stubs --check`. It must compare actual canonical files; `--dry-run`/staged comparison is not equivalent. Preserve all bytes unchanged. Any Linux/backend-specific byte drift is reported exactly and investigated; do not hand-edit generated files or claim local Mac acceptance from it.
3. Reuse the published source/profile-bound R6 defining-node receipt as historical evidence only. Do NOT rerun its unchanged full seven-owner staging positive before/after the controls just because the published HEAD differs. Step2's new actual canonical --check is this Cloud profile's positive producer/four-output comparison (and its actual canonical Ruff pipeline), not a replacement claim for every R6 error/outside case. Keep full R6 staged-case status UNRUN at this Cloud profile. If step2 yields ERROR, do not run confounded removal controls; continue independent source/type diagnostics. If step2 is FAIL, preserve exact drift and determine whether the specific removal remains meaningful before a bounded run; never hand-edit artifacts to force a clean comparator.
4. Execute each exact source removal below separately in a NEW pytest process. Preserve correct bytes and verify correct hash from Git, apply the small patch, verify exact mutant hash, run `.venv/bin/python -m pytest -ra --tb=short --color=no --junitxml=<owned-evidence>/<control>.xml tests/repo_quality/tools/test_foundry_stub_generation.py::test_actual_stub_owner_staging_and_check_detect_complete_byte_drift`. Expect pytest exit1 AT the named assertion; a setup/collection/backend/timeout failure is not a successful removal control. Each mutant's run necessarily uses the actual defining node and its positive prefixes until the falsifier; it is not an unchanged full positive replay. Save complete quiet stdout/stderr/JUnit. In finally restore exact producer bytes, verify correct hash and zero producer diff before the next control. Set PYTHONDONTWRITEBYTECODE=1 and do not reuse an in-process imported mutant. No reset/stash/clean/generated edits. After final restoration verify exact correct source hash, complete source diff and original four generated-output hashes; do not rerun the unchanged full staging suite. Restoration is source-byte identity evidence, not a runtime restoration PASS; subsequent selected type/import commands run only restored source. If one control fails to falsify its property, diagnose boundedly within existing test/producer contract, preserve result, do not change owner/test to teach the oracle or add new architecture; report minimal real missing input/decision.
5. Run narrow type checks, one explicit target at a time, using `.venv/bin/python -m mypy --config-file mypy.ini --strict <target>`. Targets: the four .pyi outputs; positive client below; negative client below; components/composer.py; backends/chain_executor.py; backends/async_chain_executor.py; backends/checkpointing.py; backends/ray_chain_executor.py; compiler/__init__.py; components/semantic_validator.py (source paths relative to src/polisyos/foundry/methods). Positive client must PASS. Negative client must yield both incompatible-return-value sites, not unrelated backend errors. No ignore-missing-imports, Any/cast/noqa weakening, config changes or updating a baseline to green. Root mypy.ini is strict with real plugins; generated.ini suppresses four affected implementations and is NOT the decisive config. Explicit targets do not bound mypy's transitive graph; retain full diagnostics and actual config/profile. If red, record source-owned/not-established pending exact slice-base P41 diagnosis; do not assert inherited from current-HEAD replay alone.
6. Run existing affected import/runtime consumers only where not already supplied as fresh equivalent evidence for this exact profile: `.venv/bin/python -m pytest -ra --tb=short --color=no --junitxml=<owned-evidence>/consumers.xml tests/unit/foundry/methods/test_linker.py tests/unit/foundry/methods/test_compiler.py tests/unit/foundry/methods/test_composer.py tests/unit/foundry/methods/test_composer_hardening.py tests/unit/foundry/methods/test_semantic_validator.py tests/unit/remediation/test_cmp_01.py tests/unit/remediation/test_cmp_02.py tests/unit/remediation/test_cmp_03.py tests/unit/remediation/test_res_04.py tests/unit/foundry/methods/backends/test_checkpointing.py tests/unit/foundry/methods/components/test_composition_custody.py`. Report actual collected IDs/outcomes, optional Ray absence as SKIP/UNRUN. Tests include fresh process imports, compiler/linker whole combination, static window/seed, async, partial/fresh checkpoint, context reconciliation and warning consumers. No claim that a constructor/marker test alone demonstrates a capability.
7. Small existing API/tool companions: `tests/unit/foundry/contracts/test_signature_compat.py` and `tests/repo_quality/tools/test_phase4_consolidation.py::test_registry_discovers_phase4_consolidation_commands`. ABI red requires review, not signature-baseline refresh. Leave broader public inventory/reference batch to Root. Do not run six-family generated freshness to validate this one family.
8. Verify producer restored, canonical generated bytes and all product/config/lock/tests unchanged; full changed footprint only approved evidence/witness additions. Preserve actual final HEAD/tree and managed diff availability. Report each command independently PASS/FAIL/ERROR/SKIP/UNRUN; no “overall PASS” hiding an absent consumer or unavailable evidence.

For every deciding run capture command/exit/time/profile/source/input IDs, complete quiet stdout/stderr (gzip if needed), JUnit where pytest, expected/actual property and exact control assertion. Typed clients are static mypy inputs, never run them as Python. No native removal result may be inferred from source inspection. Outside budget/backend/input absence does not stop independent useful checks. Real architecture choices need a concrete options/reuse/extend/consolidate/build analysis and minimal falsifier; do not invent law/issuer/permission/calibration/production currentness.

## Exact compact mutation inputs

All paths in these Git patches are repo-relative. Correct/test hashes above are mandatory. Each test node is `tests/repo_quality/tools/test_foundry_stub_generation.py::test_actual_stub_owner_staging_and_check_detect_complete_byte_drift`.

### byte-comparator

Expected correct SHA256 `e3eb3cd00fd7f6fe9ef4c87cfd6f9473a20a0345cbf5dea3ed635a15612d065d`; mutant SHA256 `d8cc86d7a25817e2321ec8a24ee88705b594d0bbcc34f9b953612ac91a6365bd`; patch SHA256 `b5ed3340caae94d61a34f19f5949f141edb1ac612f52e7c39480b3d0d471009f`. Named assertion: `freshness comparator must refuse every changed declared output`.

```diff
--- a/policy-engine/tools/devx/foundry/generate_stubs.py
+++ b/policy-engine/tools/devx/foundry/generate_stubs.py
@@ -204,6 +204,7 @@
             print("Generation completed; freshness comparison UNRUN; no output files written.")
             return 0, "UNRUN"
         if args.check:
+            return 0, "PASS"  # property removed; rendered family/receipt remain
             stale: list[Path] = []
             unreadable: list[Path] = []
             for target, content in rendered.items():
```

### canonical-style

Expected correct SHA256 `e3eb3cd00fd7f6fe9ef4c87cfd6f9473a20a0345cbf5dea3ed635a15612d065d`; mutant SHA256 `384559c30eb6513f2ba93aa3a9011d55b3a6563fc89029ee40ff269753b8cd3f`; patch SHA256 `8263423ff83ccae3f8b9a59c8ac3ff5a3ecdce1dc1658e358d2ceaa01b9fb175`. Named assertion: `actual generated stub must pass canonical Ruff check`.

```diff
--- a/policy-engine/tools/devx/foundry/generate_stubs.py
+++ b/policy-engine/tools/devx/foundry/generate_stubs.py
@@ -122,6 +122,7 @@
 
 def _canonicalize_stub(target: Path, content: str) -> str:
     """Apply canonical import organization/format and require the full Ruff policy."""
+    return content  # canonicalization property removed; caller/config markers remain
     logical_path = target.relative_to(REPO_ROOT).as_posix()
     policy = ("--config", str(RUFF_CONFIGS[0]), "--no-cache", "--stdin-filename", logical_path)
     steps = (
```

### facade-completeness

Expected correct SHA256 `e3eb3cd00fd7f6fe9ef4c87cfd6f9473a20a0345cbf5dea3ed635a15612d065d`; mutant SHA256 `4e79d59dfe7be79a01ecef585880f77dfe44f134a1570b77981a526c1f51d52f`; patch SHA256 `42cdfc2c5948a5e17a2df0026a3ce8ea38d20006daeedeee3b1563cca4d7f518`. Named assertion: `facade stub must preserve every actual canonical export without wildcard`.

```diff
--- a/policy-engine/tools/devx/foundry/generate_stubs.py
+++ b/policy-engine/tools/devx/foundry/generate_stubs.py
@@ -116,6 +116,7 @@
         or len(names) != len(set(names))
     ):
         raise ValueError(f"{owner} __all__ must be a nonempty unique identifier sequence")
+    names = names[:1]  # actual canonical export completeness removed
     aliases = "\n".join(f"    {name} as {name}," for name in names)
     return f"from {owner} import (\n{aliases}\n)\n\n__all__ = {list(names)!r}\n"
 
```

## Static positive client

Save as an owned nonignored `typed_consumer.py`; no product source changes:

```python
"""Static-only C60 consumers; run mypy, never execute this witness."""

from typing import assert_type

from polisyos.foundry.methods.backends.chain_executor import ChainExecutionResult
from polisyos.foundry.methods.composer import (
    CompiledMethodChain as CompatibilityChain,
    MethodComposer as CompatibilityComposer,
    ValidationContext as CompatibilityContext,
)
from polisyos.foundry.methods.components.composer import (
    CompiledMethodChain,
    MethodComposer,
    SemanticValidationLevel,
    ValidationContext,
    reconcile_validation_context,
)


def consume_c60_surface(
    chain: CompiledMethodChain,
    result: ChainExecutionResult,
    composer: MethodComposer,
    compatibility_composer: CompatibilityComposer,
    compatibility_chain: CompatibilityChain,
    compatibility_context: CompatibilityContext,
    context: ValidationContext,
) -> None:
    """Require actual declared types across canonical, facade and result consumers."""
    assert_type(chain.validation_context, ValidationContext | None)
    assert_type(chain.warnings, tuple[str, ...])
    assert_type(result.validation_context, ValidationContext | None)
    assert_type(reconcile_validation_context(chain), ValidationContext)
    assert_type(context.mode, SemanticValidationLevel)
    assert_type(composer.build(validate_semantics=True), CompiledMethodChain)
    assert_type(composer.build(validate_semantics=SemanticValidationLevel.OFF), CompiledMethodChain)
    assert_type(compatibility_composer.build(), CompiledMethodChain)
    assert_type(compatibility_chain, CompiledMethodChain)
    assert_type(compatibility_context, ValidationContext)
```

## Static negative client

Save as `typed_consumer_invalid.py`; both actual context returns must fail with typed diagnostics:

```python
"""Negative C60 type-use control: the real context is not a string."""

from polisyos.foundry.methods.backends.chain_executor import ChainExecutionResult
from polisyos.foundry.methods.components.composer import CompiledMethodChain


def invalid_compiled_context(chain: CompiledMethodChain) -> str:
    return chain.validation_context


def invalid_result_context(result: ChainExecutionResult) -> str:
    return result.validation_context
```

## Final delivery

Produce compact `receipt.json` and `handoff.md`, plus deciding quiet outputs/JUnit/control patches/client bytes required for reproduction. Receipt includes task/environment actual IDs (if unavailable say so), exact expected/actual base and final commit/tree; complete changed footprint and restored-source hashes; Python/uv/mypy/Ruff/pytest/backend/profile; actual input identity/config; every command and scope; separate PASS/FAIL/ERROR/SKIP/UNRUN; positive/adversarial/removal/restore results; wall/RSS/disk measurements; exact nonignored relative file locators, byte lengths and SHA256; transport prepared versus Root-retrieved distinction; unavailable evidence and exact limited repeat if any; no private inputs; limitations/closure_ids=[]. Use lossless gzip for complete logs, no fake full logs reconstructed from a summary. Do not deliver caches/env/fixture/checkout/CAS/DB copies or duplicate intermediate representation.

If ordinary commit hooks fail, retain the complete error and useful files through managed diff/snapshot; do not bypass hooks or make output transport depend on push. If commit is created, report exact parent/final commit/tree with Git readback; never fake a future commit field or remote publication. A managed result with no ordinary commit reports actual unchanged source HEAD/tree and actual staged/working artifact footprint honestly. Root independently verifies bytes, reviews author result and composes; source review, author runtime proof, independent review, G acceptance and formal closure remain separate.
