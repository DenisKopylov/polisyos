# C89 — standalone C05 native verification and bounded owner repair

Requested author model: **Sol**. The actual scheduler/model is `not_established` until a real scheduler receipt names it. This request is not evidence of which model ran.

Your task is to verify the complete C05 cache/client/session/lifecycle mechanism on the exact published source below, repair a real defect only within the bounded existing C05 owner chain when necessary, and deliver reviewable source plus complete deciding evidence. Do not launch another task, ask for midrun follow-ups, delegate, or wait for private local material. You have everything required in published Git and the inlined instructions. The human/Root will review your final delta; your own analysis is author review, not independent acceptance. No E02/G/global closure is requested.

## Exact local input and measured managed-snapshot delivery

Repository context: `https://github.com/DenisKopylov/polisyos.git`.
Root-verified immutable topic: `codex/e02-composed-progress-20261028-r5`.
Required initial local HEAD: `ea3d65682d76a5d66d514e525ad2212e5a85f669`.
Required complete local tree: `7c5412fddc4ef3e56c859b83d237162e0fd260e7`.
Product: `policy-engine/`.

Use the managed task's existing checkout. Before edits, verify actual `git rev-parse HEAD`, `HEAD^{tree}`, physical product path, working/index state and the 40 local source-blob pins below. Correct local HEAD/tree and source pins are sufficient input admission: Root already verified the published r5 topic. No Git fetch, origin, remote readback, download CLI, new clone, push or midrun coordinator acknowledgment is required. A missing origin or Git HTTPS403 is NOT a compute blocker when the pinned local source is valid and the managed final task snapshot/diff is available. If the local source differs, report the exact mismatch; do not repair it by blindly switching, resetting, adding origin or selecting a similarly named branch.

This carrier includes all 37 composed C05 paths, the required canonical decoder-source forward fix and C71's typed observational-source/derived-writer context. Earlier r4 at545c was known broken source, not a passing result. Keep the input topic immutable. Stay on the provided managed task branch. Use ordinary local append-only commits when possible or stage exact new/changed files for the managed final snapshot. Never push `work`, `main`, any integration branch or the input topic. An optional ordinary push to a separately authorized task topic may be used only if already available; its absence/failure does not block computation or snapshot delivery. No reset, rebase, force push, historical rewrite, blind branch switch, hook bypass or newly invented transport automation.

**Measured qualification, supplied inline:** C83 ran on this same required EA commit/tree and created one 2,052-byte `preflight.json`, SHA256 `aaf5d6a21e3323ca6b82efd65cf55798c56c2af38d09c2e390e31ed5192f2750`. It observed Linux 6.18.55 x86_64, Python 3.14.4, uv 0.7.22, pytest 9.0.2 and Ruff missing in the provided .venv; cgroup memory 17179869184 bytes, CPU quota 200000/100000 (two CPUs), available workspace disk 29042180096 bytes. Both ordinary Git fetch and `push origin work` returned CONNECT-tunnel403. C83 then stopped because its commission incorrectly made ordinary remote delivery a prerequisite; all C05 tests stayed UNRUN. This is useful environment/transport evidence, not a source or product FAIL and not a timing/RAM guarantee for C89.

Root nevertheless retrieved all 2,052 preflight bytes via the existing managed cloud task diff: received diff 2,592 bytes SHA256 `f69975867522b70c1707f51d3f4977baa84dd7de325fd22a567e0a8ee501990d`, reconstructed candidate tree `a7161ba4af5f98027e4212fc043e35f9503b563f`. Root also verified every one of 26 delivered C80 payload files using the same managed channel; that is additional transport evidence only, not C05/C80 correctness. The managed task final diff/snapshot is therefore the DEFAULT result channel. Do not repeat C83's Git-network prerequisite or wait for a worker-side export CLI or acknowledgment that only the coordinator can perform after task completion.

Create a small nonignored preflight record with the actual local source, fresh VM/tool facts, optional Git reachability only if already observed, and C05 status UNRUN. Proceed to supported dependency setup and native work using the measured managed channel. Keep bounded nonignored source/evidence files committed or explicitly staged so the platform's final task snapshot contains their bytes; the coordinator retrieves them with the existing task tools after you finish. You need not invoke or download those coordinator tools. Worker-side local/index readback proves file visibility, NOT that the coordinator has already retrieved a future result. If the platform actually reports snapshot/export unavailability, or files cannot be made visible in its snapshot, state the exact affected paths/bytes and delivery gap; do not invent a successful export or replace artifacts by hashes. Preserve and deliver whatever bytes are available through the managed result.

Do not require or copy any Root `D`, `LOCAL/raw`, source-frame, receipt, environment, DB, credentials or ignored fixture. No CI/workflow, upload encoding fragments, firewall/credential bypass or new automation as a transport workaround. All tests and fixture builders are in the pinned local Git source. Synthetic loopback prices exercise actual accounting behavior, not provider invoices or institutional permission.

## Read the actual owners before work

Read root `AGENTS.md`, `policy-engine/CONTRIBUTING.md`, applicable nested instructions and package READMEs. Open `docs/reference/policy-design-case-failure-patterns.md` before design and before final handoff. Follow reuse-existing → extend → consolidate. Relevant patterns: P05/P12 actual ownership/producer handshake; P29/P32 real behavioral evidence; P31/P33 whole class and adversarial variants; P35 complete denominators; P37/P38 actual predicate versus normalization proxy; P40 bucket before repair; P41 do not call a failing gate inherited without actual base isolation.

The public C71 context is documented in `policy-engine/docs/reference/runtime-observational-source-access.md` and the Runtime services README. Source tenant A is provenance. A real shared read grant to job B does not make A the derived-artifact writer: the actual admitted B writes. Core checks current blob and exact selected-view ownership; Runtime reconciles the typed request/current job/authorized reader with the actual enforcing owner. This is byte-read custody, NOT protected TC, publication authority or institutional permission. Keep C38 protected authority refusals. No C71 source-access rewrite, source made unscoped/public merely to green a fixture, fake grant, bypass of observation grounding, or new issuer is authorized here. The carrier already contains that separate owner. If an actual C71 boundary blocks a test, record its exact request, route/result, persisted job and refusal; distinguish an external owner issue from a C05 defect without weakening it.

C05 source of truth is the existing chain:

- Core `core/llm/cache_settlement.py`, `response.py` and `traced_client.py`: exact Core-owned wrapper registration; response/proof projection; actual begin and terminal producer acknowledgments; local origin reuse proof.
- Scientist `scientist/orchestration/llm/{prepared_request,prompt_cache,gateway_client,fallback_router,simulated_gateway,provider_verification,factory}.py`: lossless call binding, actual transport preparation, app-owned bounded cache/flights, real preflight and request-local trace hooks.
- Scientist engine `budget_ledger.py` and `budget_middleware.py`: durable monetary event origin, returned/read-back pending begin ownership, legacy readers and cross-run reuse admission; actual budget consumer remains wired.
- Runtime `control/{job_nl_execution,producer_basis,run_lifecycle}.py`, `control_plane_store.py` and their existing proposal/publication bridges: current job/actor/tenant/cell/attempt/lease/profile before effects, persisted independent complete producer-begin basis, exact terminal proposal/profile/attempt, fresh GET and debug ledger consumers. Preserve C37 selected queue reader, C49 budget observer, C57 diagnostic creation/cancelled ownership and C71 source custody.

The supplied source-pin table at the end binds the complete 37-path C05 footprint plus the canonical decoder and public C71 context. Inspect actual definitions and callers, not just names. The decoder owner is `polisyos.common.serialization.decode_json_object(raw, *, source: str, kind=...)`. `thaw_wire_object` now supplies stable source `polisyos.scientist.orchestration.llm.prepared_request`; do not relax that owner or catch a missing-signature TypeError as a cache miss.

## Properties to exercise and preserve

1. A saved prepared plan accepts only the actual invoked call. Native exact identity uses complete type-tagged values, raw bytes and dictionary order, independently of cache/evidence normalization and HTTP projection. Valid snapshot A and invoked invalid B with unchanged declared SHA(A) must differ in both directions. Bool/int, integer/float, signed zero, tuple/list and bytes/bytearray distinctions must survive. Mismatch refuses before authorizer/producer begin/wire work, and does not consume a rightful unchanged single use.
2. Actual Python providers retain supported tuple/list types. Opaque/unfreezable objects, aliases/cycles, views, subclasses, nonfinite Python values and excessive depth remain original-object physical-only calls. They acquire no cache equality/immutable payload claim and cannot bind an external saved plan. No user-defined stringification/copy hook or generic JSON roundtrip may substitute old inputs. The actual Gateway separately owns strict finite native JSON; supported sequences become JSON arrays there, raw unknown objects fail there. Existing private cache-control projection remains separate from caller wire metadata.
3. Request identity and dispatch share actual prepared immutable values, URL/headers/configuration/body. Preserve every actual caller wire field, including nested timestamp-like names and cache busters. Only the Gateway's own generated retry nonce is neutral; explicit caller idempotency is bound. Select the actual available endpoint head; alternate outcome or changed response-format success is not reusable under the old requested payload. Health recovery and newly supported format must not hit a prior different successful route/payload. Do not assert an opaque adapter reusable by assumption.
4. The real accounting-enabled preflight uses one actual prepared Gateway request for retention digest and physical execution. Share a cache resource and current durable original reference, with fresh provider/cache/traced wrappers and hooks. Reopen owner/origin before network checks. Positive same-binding second call genuinely avoids one physical completion; it emits a distinct zero-cost reuse event pointing at the original source. Changed owner/run/provider/transport/payload separates; altered/missing origin refuses. Cancelling a waiter must not close admitted physical work before its actual settlement and eventual close.
5. A callback's matching declaration cannot replace a current job/attempt/lease fence. Closed scoped clients refuse NEW physical work; no uncached unowned fallback and no reinstated old lease. Legitimate already-begun work keeps independently captured original ownership through success/error/cancellation. Guard unavailable/timeout fails closed/retryable. Scope/binding close does not wait indefinitely for a timed-out callback lock. Existing limitation: a running blocking dependency thread cannot be forcibly killed and may retain its own bounded worker/mutex until return; that is neither dispatch permission nor a complete basis.
6. Before external producer dispatch, compare actual returned and reopened durable begin receipt ownership, not a reconstructed expected declaration. Preserve the original source across reuse; do not reattest old origin as fresh. Core proof binds the WHOLE allowed response projection consumed by downstream code. Custom cache duck values, fake origins, same-content changed usage/model/provider/raw/tool metadata and shared followers must not bypass actual session/origin proof. Cache/flight/origin entry lifetimes, TTL/capacity/eviction, multi-loop concurrency and shutdown stay bounded. No-key and None/zero modes remain supported uncached. Unknown external sampling defaults, tools and strict independent seeds do not become reusable; do not force temperature0 merely to green an existing producer.
7. Durable ledger status keeps reported/estimated/reuse/unknown distinct, including real zero and unknown amounts. Fresh ordinary API reads join the exact selected terminal proposal/profile and V3 Core run/attempt, reopen actual complete central begin set including the citation sibling, and compare the current ledger's complete owning event set. Missing/changed/foreign-attempt/extra/unobserved-sibling rows withhold reconciliation. Preserve legacy limited readers honestly. Current budget consumers must use the actual canonical validation/owner, not stale copied sums or estimates converted into measured money. Source/currentness/policy permission remain separate.

## Native environment and resource admission

Measure this VM independently: platform/architecture, cgroup/container memory and CPU limits where applicable, physical RAM, available disk, active native processes, Python/tool versions and retained/installable backends. Do not copy Root's macOS timings/RSS or environment. Unknown first profile runs ALONE, one native case at a time, a 600-second deadline and at most2.25GiB aggregate sampled process-tree RSS (`2415919104`bytes), one-second samples, six-GiB free-disk floor, one numerical thread. If this VM cannot safely admit that profile, report the measured boundary; do not begin a knowingly underprovisioned wave or call137 alone proof of OOM. After each actual case inspect measured wall/RSS/exit/collection before admitting the next. Bound bootstrap separately and retain complete setup failures.

Use the actual project Python 3.14.x baseline and published `uv.lock`; record the actual patch version. Prefer an existing working task environment. C83's Python 3.14.4 and pytest 9.0.2 were observed, not automatically the C89 profile. Its uv 0.7.22 and missing Ruff are setup/tool gaps, NOT product FAILs. In this fresh Cloud VM, normal supported setup is authorized: obtain/use canonical uv 0.9.21 when needed, then the documented frozen workspace/bootstrap or `uv sync --frozen --extra lint --extra test --extra runtime`. For example, use an available normal pip install of `uv==0.9.21` or a normal `uv tool run --from uv==0.9.21 uv ...`; use official PyPI or an already supported configured package mirror with bounded attempts. Inspect actual optional groups before adding a genuinely required backend. Do not let an outdated preprovided uv or missing lint extra stop useful work without attempting supported setup within measured RAM/disk/time.

This authorization applies to the fresh task VM only: never reinstall/copy/modify the coordinator's existing working Root environment. Do not copy an environment or source tree. Ordinary supported dependency/network alternatives are allowed without bypassing firewall, proxy policy or credentials, inventing automation, hiding dependency failures or faking source modules. Record complete setup commands/errors and actual selected interpreter/backend/plugin/.pth metadata. A genuinely unavailable package/interpreter/setup/collection/plugin/capacity boundary remains a distinct outcome, not a product-property FAIL or an inherited red without exact isolation.

Preserve native `pytest.ini`: default plugin autoload, importlib mode, strict markers, `asyncio_mode=auto`, normal conftests and helper plugins. Do not set `PYTEST_DISABLE_PLUGIN_AUTOLOAD`, remove default plugins, use `--ignore`, `-k`, `--maxfail=1`, custom test replacements or reduced parameter sets. Clear ambient PYTHONPATH/PYTHONHOME/PYTEST_ADDOPTS/PYTEST_PLUGINS/PYTEST_DISABLE_PLUGIN_AUTOLOAD/VIRTUAL_ENV before invoking the selected interpreter; preserve the actual installed editable roots and disclose all startup `.pth` bytes and pytest11 entrypoint declarations. Installed declarations are not proof of actual plugin execution. No TS scanner is requested; if you invoke one, honor CONTRIBUTING's frozen corepack pnpm links rule.

Per case create unique private scratch/tmp/cache/basetemp/SQLite/CAS/ledger paths. Redirect bytecode search/output to an empty private prefix and disable new pyc writes, XDG/matplotlib/numba/hypothesis/benchmark caches below scratch. Set the actual supported `POLISYOS_CONTROL_SQLITE_PATH` to that private case if needed; existing fixtures may select their own tmp_path backend. Do not force a different default backend/profile merely to pass a test. Loopback HTTP tests own ephemeral `127.0.0.1:0` listeners; use NO_PROXY/no_proxy for localhost. Unit transports at fake/example addresses are mocked by the existing tests; no real remote LLM, API key, production_data or external permission service is needed. Never supply a real provider credential. Unexpected external network or shared DB writes are a diagnostic boundary, not an invitation to widen the sandbox/permissions.

### Observe the actual pytest process BEFORE tests

Planned command strings, exported environment declarations, a separate tiny probe PID or a later receipt are insufficient. Retain actual facts from the SAME Python PID that invokes native pytest, first before importing pytest/product and again in `pytest_configure` before collection/test execution. Use a new empty private bytecode prefix for EACH case; launch the actual interpreter with `-B -X pycache_prefix=<that prefix>` and `PYTHONDONTWRITEBYTECODE=1`. The supervisor creates/independently checks the fresh empty directory; the child recomputes its existence/emptiness and checks actual `sys.flags.dont_write_bytecode` and `sys.pycache_prefix`. Retain both observations and PID/PPID. A wrong flag/prefix is a setup/profile error to correct before tests, never a native PASS or product FAIL. Do not infer this property from a file merely declaring the intended values.

A compact allowed read-only launcher skeleton is below. Write it under this task's nonignored evidence directory, set the two C89 case environment paths from the supervisor, and execute it with the SAME pytest arguments/selectors below. Extend only observation for full collect-report outcomes, finite source readsets and resource receipts; preserve normal pytest execution and default plugin autoload. Record no secrets or full ambient environment dump.

```python
import json, os, pathlib, sys, time
case = pathlib.Path(os.environ["C89_CASE_DIRECTORY"]).resolve()
prefix = pathlib.Path(os.environ["C89_EMPTY_PYCACHE_PREFIX"]).resolve()
case.mkdir(parents=True, exist_ok=True)
allow = ("PYTHONDONTWRITEBYTECODE", "PYTHONPYCACHEPREFIX", "PYTHONPATH",
         "PYTHONHOME", "PYTEST_ADDOPTS", "PYTEST_PLUGINS",
         "PYTEST_DISABLE_PLUGIN_AUTOLOAD", "VIRTUAL_ENV", "PYTHONNOUSERSITE",
         "JAX_PLATFORMS", "OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS",
         "MKL_NUM_THREADS", "SCIENTIST_TORCH_NUM_THREADS",
         "SCIENTIST_TORCH_NUM_INTEROP_THREADS", "TMPDIR", "XDG_CACHE_HOME")
def save(name, value):
    (case / name).write_text(json.dumps(value, indent=2) + "\n")
def process_facts():
    actual = sys.pycache_prefix
    return {"pid": os.getpid(), "ppid": os.getppid(), "at_monotonic": time.monotonic(),
            "executable": sys.executable, "python": sys.version,
            "argv": sys.argv, "orig_argv": sys.orig_argv, "cwd": os.getcwd(),
            "flags": {key: getattr(sys.flags, key) for key in
                      ("dont_write_bytecode", "no_user_site", "ignore_environment",
                       "isolated", "safe_path")},
            "xoptions": sys._xoptions, "pycache_prefix": actual,
            "expected_prefix": str(prefix), "prefix_is_directory": prefix.is_dir(),
            "prefix_empty_observed": prefix.is_dir() and not any(prefix.rglob("*")),
            "environment": {key: os.environ.get(key) for key in allow},
            "sys_path": sys.path}
start = process_facts()
save("pytest-process-start.json", start)
assert start["flags"]["dont_write_bytecode"] == 1
assert start["pycache_prefix"] is not None
assert pathlib.Path(start["pycache_prefix"]).resolve() == prefix
assert start["prefix_is_directory"] and start["prefix_empty_observed"]
import pytest
class Observe:
    def pytest_configure(self, config):
        facts = process_facts()
        facts.update({"pytest_module": pytest.__file__, "pytest_version": pytest.__version__,
                      "pytest_invocation_args": list(config.invocation_params.args),
                      "rootpath": str(config.rootpath), "inipath": str(config.inipath),
                      "ini_addopts": config.getini("addopts"),
                      "asyncio_mode": config.getini("asyncio_mode"),
                      "effective_options": {key: getattr(config.option, key, None) for key in
                       ("importmode", "strict_markers", "keyword", "markexpr", "maxfail", "numprocesses")},
                      "actual_plugins": [{"name": name,
                       "module": getattr(plugin, "__name__", type(plugin).__module__),
                       "file": getattr(plugin, "__file__", None)}
                       for name, plugin in config.pluginmanager.list_name_plugin()]})
        save("pytest-configured.json", facts)
        assert facts["pid"] == start["pid"]
        assert facts["flags"]["dont_write_bytecode"] == 1
        assert pathlib.Path(facts["pycache_prefix"]).resolve() == prefix
        assert facts["prefix_empty_observed"]
        assert facts["effective_options"]["importmode"] == "importlib"
        assert facts["effective_options"]["strict_markers"] is True
        assert facts["effective_options"]["keyword"] == ""
        assert facts["effective_options"]["markexpr"] == ""
        assert facts["effective_options"]["maxfail"] == 0
        assert facts["effective_options"]["numprocesses"] in (None, 0)
        assert facts["asyncio_mode"] == "auto"
    def pytest_collection_finish(self, session):
        save("pytest-collection.json", {"pid": os.getpid(),
             "items": [{"nodeid": item.nodeid, "physical_path": str(item.path)}
                       for item in session.items]})
raise SystemExit(pytest.main(sys.argv[1:], plugins=[Observe()]))
```

The sample is a real process/profile observation, not a complete source/network observer. Keep full stdout/stderr/XML for setup or collection errors, including errors before the hook. Add/read the finite loaded src/tests/tools source set at sessionfinish and report the explicit unobserved child/external/unloaded boundaries. Actual collected nodes, plugin manager objects/options and active environment are the inputs to the receipt; do not fabricate a matching profile object after a run. Missing pytest-asyncio/default dependencies are setup issues to provision normally, not a reason to change source's native configuration. This prevents the unobserved-profile mistake encountered in the earlier C80 evidence.

Use a portable process-tree supervisor, kill the entire case group on deadline/RSS/disk breach and keep the actual controller record/units. Capture quiet full stdout and stderr without truncation, JUnit, exact selected and collected node IDs, source/profile/backend pins and resource samples. A small read-only pytest observer may record collected items and the finite runtime-loaded `src/polisyos`, `tests`, `tools` Python files at sessionfinish; it must not change execution or replace default plugins. Explicitly disclose that this misses unloaded source, child import reads and external package contents. Record actual source/input hashes before and after; no mutation during a deciding baseline.

## Exact execution sequence

All paths below are physical paths relative to `policy-engine`. Run from that product directory with its actual interpreter. Redirect only output locations. Example native shape:

`<actual-python> -B -X pycache_prefix=<new-empty-case-prefix> <read-only-launcher.py> -o cache_dir=<case>/pytest-cache --benchmark-storage=file://<case>/benchmarks --basetemp <case>/basetemp --junitxml=<case>/pytest.xml --tb=short --color=no --maxfail=0 <exact selectors>`

A source observer launcher may call the same native `pytest.main(...,plugins=[read_only_observer])` and preserve default autoload. Never run a test copy under an evidence/RAW ancestor; pytest's physical import context is part of the test.

**A. First smoke, alone:**

- `tests/unit/scientist/orchestration/llm/test_prepared_request_dispatch.py::test_prepared_values_use_the_real_strict_decoder_contract`
- `tests/unit/scientist/orchestration/llm/test_prepared_request_dispatch.py::test_prepared_decoder_preserves_strict_refusal_with_stable_source`

Source-derived expectation:7 cases, not a stopping quota. Attempt the complete actual collection of both selectors and read back results. This proves the exact required decoder contract at runtime before the semantic removals; a failing positive baseline makes all later removal FAILs vacuous.

**B. Priority positive/adversarial component smoke:** use these exact function selectors with every native parameter case:

- `tests/unit/scientist/orchestration/llm/test_prompt_cache_scope_admission.py::test_prebound_snapshot_compares_raw_invocation_before_current_owner_authorization`
- `tests/unit/scientist/orchestration/llm/test_prompt_cache.py::TestCachingLLMClient::test_skips_cache_for_tool_calls_and_freshness_sensitive_inputs`
- `tests/unit/scientist/orchestration/llm/test_prepared_request_dispatch.py::test_prebound_call_identity_preserves_native_type_and_value`
- `tests/unit/scientist/orchestration/llm/test_prompt_cache.py::test_opaque_python_call_preserves_original_values_after_admission`
- `tests/unit/scientist/orchestration/llm/test_prepared_request_dispatch.py::test_actual_gateway_keeps_json_arrays_and_rejects_unknown_before_dispatch`
- `tests/unit/scientist/orchestration/llm/test_prepared_request_dispatch.py::test_prepared_cache_plan_binds_one_actual_client_and_one_logical_call`
- `tests/unit/scientist/orchestration/llm/test_provider_verification.py::test_provider_preflight_records_bound_gateway_completion_and_reuses_exact_event`
- `tests/unit/scientist/orchestration/llm/test_provider_verification.py::test_preflight_uses_its_exact_prepared_request_across_catalog_waits`
- `tests/unit/scientist/orchestration/llm/test_provider_verification.py::test_preflight_negotiated_success_cannot_supply_requested_format_reuse`
- `tests/unit/scientist/orchestration/llm/test_provider_verification.py::test_cancelled_preflight_waiter_preserves_admitted_gateway_settlement_and_close`

Source-derived expectation:30 cases, not a stopping quota; preserve the complete actual collected set. Then prioritize actual proof/timeout/closed-owner/in-flight controls in `test_cache_owner_admission.py` and `test_control_nl_producer_admission.py`, and real research POST selector `tests/integration/runtime/http/test_r3_pre_admission_attempt_owner.py::test_actual_nl_post_gateway_settlement_reopens_and_serves_same_run` (seven parameter cases). Keep every original physical count, separate owning event, nullable amount, lost-ack reconciliation and fresh read assertion.

**C. Complete full-module deciding wave:** all14 modules in the table below, no selection trimming. The pinned source has202 test definitions with a literal-parameter estimate of402 cases. This is informational, NOT a quota, upper bound, stopping condition, required literal equality or permission to deselect. Collection is UNRUN at commissioning. Execute the complete actual framework-collected set from all14 physical modules, including genuine cases beyond the estimate; reconcile actual node IDs, fixture/plugin effects, XML and outcomes. Explain discrepancies from the source estimate without falsifying the actual collection or silently editing the baseline count. If grouping modules, record the exact groups and run unknown profiles alone; every module and actual item needs an outcome. A setup/collection/resource abort is a concrete incomplete result, not permission to omit the rest. Retain full collection/error results.

| Full canonical module | Source-derived cases |
| --- | ---: |
| `tests/integration/runtime/http/test_nl_pipeline_cache_reuse_authorization.py` | 23 |
| `tests/integration/runtime/http/test_r3_pre_admission_attempt_owner.py` | 10 |
| `tests/unit/core/llm/test_cache_settlement.py` | 17 |
| `tests/unit/core/llm/test_traced_client_settlement.py` | 28 |
| `tests/unit/remediation/test_llm_01.py` | 8 |
| `tests/unit/runtime/http/test_control_nl_producer_admission.py` | 8 |
| `tests/unit/runtime/http/test_nl_pipeline_cost_projection.py` | 30 |
| `tests/unit/scientist/orchestration/llm/test_cache_owner_admission.py` | 47 |
| `tests/unit/scientist/orchestration/llm/test_fallback_router.py` | 8 |
| `tests/unit/scientist/orchestration/llm/test_gateway_client_retry.py` | 99 |
| `tests/unit/scientist/orchestration/llm/test_prepared_request_dispatch.py` | 23 |
| `tests/unit/scientist/orchestration/llm/test_prompt_cache.py` | 44 |
| `tests/unit/scientist/orchestration/llm/test_prompt_cache_scope_admission.py` | 12 |
| `tests/unit/scientist/orchestration/llm/test_provider_verification.py` | 45 |

Prefer one complete14-module native pytest process after the smoke is admitted, since it also exposes shared-state/lifecycle interactions. If a measured resource boundary requires bounded grouping, disclose the exact groups, preserve every parameter and outcome, and do not repeat already qualified expensive groups without new source/failure/concern. Unchanged direct-consumer companions are `tests/unit/scientist/orchestration/llm/test_factory_cache_composition.py`, `tests/unit/scientist/orchestration/engine/test_budget_ledger_producer_events.py` and `tests/unit/scientist/orchestration/engine/test_budget_ledger_settlement.py`. If a repair touches their actual factory/ledger contract, execute those full modules too and report their counts separately; a14-module result alone does not establish every legacy-reader or importer contract.

**D. Three isolated semantic removals, only after corrected positives PASS:** all changes are temporary, explicitly declared working-source overlays. Hold exact before/mutant/after source-byte hashes and HEAD/tree/profile; do not call a mutant the pristine Git tree. One mutation at a time, same environment/profile/tests, then exact restoration and a fresh positive replay. Never leave a mutant in final code. Root's old private patch files are not required: the exact existing function anchors below generate the controls from this public source. Count each anchor exactly once before editing; retain the actual diff, bytes/hashes and complete outcomes. If a genuine repair changes an anchor, derive an equivalent removal of the same property from the actual implementation and explain the exact executable difference; do not use a no-op marker change.

1. **Exact invoked-call binding removal.** In `src/polisyos/scientist/orchestration/llm/prompt_cache.py`, `PreparedCacheRequest._consume`, replace only:

```python
        if not invoked.exact or invoked.identity != self._call.identity:
```

with:

```python
        expected_args, expected_kwargs = self.call_values()
        if not invoked.exact or _normalize_cache_metadata(
            {"args": args, "kwargs": kwargs}
        ) != _normalize_cache_metadata({"args": expected_args, "kwargs": expected_kwargs}):
```

Run the valid-A/invalid-B actual CAS-owner selector and `test_prebound_call_identity_preserves_native_type_and_value` from B. Expected property FAIL: saved A is accepted instead of rejecting invoked B; native type/order distinctions collapse. APIs, actual owner, origin proof, decoder and physical generation remain. The failure must be a mismatch/authorization/type semantic assertion, not missing source, syntax, fixture or backend error. Restore and require the same complete selectors PASS.

2. **Python dispatch preservation removal.** In `src/polisyos/scientist/orchestration/llm/prepared_request.py`, inside `prepare_immutable_call.execute`, replace only:

```python
        response = generate(*actual_args, **actual_kwargs)
```

with:

```python
        wire = thaw_wire_object(freeze_wire_object({"args": actual_args, "kwargs": actual_kwargs}))
        response = generate(*wire["args"], **wire["kwargs"])
```

Keep the corrected canonical decoder source argument intact. Run the existing tools-present `_FakeLLMClient` selector and all `test_opaque_python_call_preserves_original_values_after_admission` cases from B. The provider-observed tuple/original-value contract must FAIL; begin refusal still precedes work and actual Gateway remains strict JSON. Restore exact bytes and require those same selectors PASS.

3. **Actual preflight reuse bridge removal.** In `src/polisyos/scientist/orchestration/llm/provider_verification.py`, `_PreflightGatewayClientAdapter.prepare_cache_request`, replace only:

```python
        return PreparedLLMRequest(actual.identity, execute, actual.reusable)
```

with:

```python
        return PreparedLLMRequest(actual.identity, execute, False)
```

Run `test_provider_preflight_records_bound_gateway_completion_and_reuses_exact_event` and real `test_actual_nl_post_gateway_settlement_reopens_and_serves_same_run`, every parameter case. Actual Gateway preparation and sending remain. The genuine reuse/physical-count/original-event assertions must FAIL while successful setup/decoder/owner path still executes. Restore and require both selectors PASS.

All three are marker-preserving behavioral falsifiers. No semantic removal is accepted merely because pytest exits nonzero. Retain exact collected IDs and failed assertion locations/reasons. Expected negative cases have complete=true and a deliberate assertion failure; infrastructure/setup/collection/capacity failures are separately classified and do not satisfy the oracle. Keep source ownership, snapshot authorization, cost provenance and strict decoding intact in every positive and restored case.

## Bounded repair authority and final review

If a real defect occurs, diagnose the actual request→producer→persisted event→bridge→consumer path before editing. Bucket it as same/new P40 class with the exact property, actual predicate and divergent case. Fix the existing owner for the whole known quantity, not the named fixture alone. Do not introduce a new issuer/subsystem, permissive catch, cost zero default, arbitrary callback trust, fake source receipt, forced deterministic sampling, weakened assertion, reduced test set or fixture scope laundering. Preserve all mixed reported/estimated/reuse/unknown outcomes.

Authorized mechanism files are the18 existing C05 mechanism Python paths enumerated in the source table, plus necessary direct C05 owner/consumer corrections when the actual call/definition chain establishes them. Shared `run_lifecycle.py` is limited to C05 cache/client/producer begin/basis/fresh monetary consumer spans; `control_plane_store.py` is limited to the existing DB-only `verify_llm_producer_admission`. No C57 creation/diagnostic/activation algorithm, C49 convergence/method scoring, C37 typed request normalization, C71 observational source ownership, Foundry executor/checkpoint family or unrelated generated-owner rewrite is authorized. Read those owners as context and report a concrete outside-scope blocker rather than changing them.

Mandatory companions may extend the mechanism footprint: real mirrored negative/integration tests, fully typed API/facade/schema/legacy reader/runtime consumer companions if moved, package README and release/migration notes. Do not count those against a mechanism path budget or split one mechanism merely to fit arithmetic. The Source carrier's `public_surface_inventory_reviewed=false` is honest: run actual affected generated/public/type/architecture checks if feasible and classify exact limits; do not simply set it true. No stale generated snapshot or marker proves serialized API equality.

Before final baseline freeze, inspect all introduced shared calls against actual owner definitions. The late decoder defect was a real missing keyword despite static Ruff and prior source GO. Do not treat syntax/style or method existence as runtime compatibility. After a bounded fix, run its focused regression, inspect the full delta, freeze source, then execute the complete affected deciding wave once. Broaden only when a new failure/change/concern justifies it. Run actual canonical-filename product Ruff/format over changed Python and required import/architecture/type checks appropriate to changes. Distinguish your final source review from independent review; Root supplies the latter after delivery.

## Complete, modest, retrievable output

Use a bounded nonignored evidence directory such as `policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/c89-c05-native-20261028/`, with all new files committed or explicitly staged for the managed snapshot. Check ignore rules before relying on delivery. Quiet deciding stdout/stderr/JUnit/collection/resource/source-readset files should be gzip-compressed with full bytes retained, not truncated text or SHA-only pointers to ignored scratch. Retain every deciding failure, corrected baseline, semantic removal and restoration output. Compress routine repetition; do not copy source trees, environments, data, two complete artifact versions, raw giant dumps or derive five views of the same bytes. Cite tracked source as path@commit and include an actual source diff only for your final changes. No `git add -f` of oversized dumps without an explicit stated reason; prefer the nonignored modest packet.

Commit normally when possible, or explicitly stage a compact `report.md`, `receipt.json`, exact commands/selected and collected IDs, final source/base/tree/dirty-state pins, actual backend/default plugin/.pth profile, same-PID `pytest-process-start.json` and `pytest-configured.json`, complete actual collection, process/resource controller facts, per-case outcomes and complete compressed deciding outputs. Include every actual output path/length/SHA256 and gzip integrity; retain the FULL quiet stdout/stderr/XML bytes as modest gzip files. The actual files—not hashes pointing to ignored scratch—must be visible in the managed final snapshot. Do not ship an environment, DB, cache, giant raw dump or leftover mutant. Report actual model if established, otherwise `not_established`. Record setup/collection PASS/FAIL/ERROR/SKIP/UNRUN/abort separately; sum actual full-module outcomes and explain differences from the estimate without imposing402 as a quota. A finite import observer is not an all-source/all-backend proof.

Verify nonignored file visibility with ordinary `git ls-files`, exact staging/commit readback and actual binary blob content where applicable; use `git diff --binary` for a useful local snapshot/diff check. Normal hooks/commits remain preferred; if a normal commit is unavailable, record why and leave all intended files explicitly staged for the existing managed snapshot rather than bypassing hooks or stopping solely for ordinary Git connectivity. Do not create origin or push protected/provided work/main/integration branches. Ordinary Git topic push/readback is OPTIONAL and cannot invalidate the independently measured snapshot channel.

Finish the task normally through the managed platform. The coordinator—not a new CLI or a midrun acknowledgment from you—retrieves the final task diff/snapshot and verifies actual source/new-file/output bytes as it did for C83/C80. In your report distinguish local/index/commit visibility from coordinator retrieval, which is not yet observed by the worker. A future successful export is never fabricated. If an actual snapshot/file-export error is reported, name the concrete unavailable paths/byte counts and preserve every available file and exact gap; do not substitute ignored SHA-only pointers or invent a successful transfer. Runtime/protected-source blocks likewise retain completed actual evidence and the smallest next action, without laundering UNRUN as PASS or declaring a failure unrelated without isolation.

Final verdict distinguishes: exact source-only work; actual native14-module outcomes; additional direct consumers if run; all three baseline→semantic FAIL→restore PASS removals; measured resource/profile/source readback; and remaining architecture/type/generated/institutional/invoice limits. Capability is `verification_missing` wherever a required result remains unrun. Never claim full E02, G acceptance, protected authority or closure.

## Exact input source pins

These SHA256 values are from complete Git blobs at the required input commit, not Root RAW staging. Check them against the pinned LOCAL Git blobs and actual checkout before edits; no fetch is required. A different field value is a source mismatch, not permission to update the expected hash. The complete commit/tree pins remain the primary source identity.

| Published path | Role | SHA256 |
| --- | --- | --- |
| `policy-engine/release-fragments/unreleased/2026-10-27-e02-cache-reuse-lifetime.toml` | mandatory release companion | `65d45892dd581de8c755ad9969c607b4996ea4cf51d05caf6a5633a7e204e403` |
| `policy-engine/src/polisyos/core/llm/README.md` | mandatory documentation companion | `22d03092b3abfa59fcb6d2d515fd485f01de88e77be71d53fa871899fc47c314` |
| `policy-engine/src/polisyos/core/llm/__init__.py` | mandatory facade companion | `6d85b26f9d8fe6b460a22794b55c235335273601bd42753531cfc82f70acba83` |
| `policy-engine/src/polisyos/core/llm/cache_settlement.py` | mechanism | `fde6449b48571ec167e3ee4ee462476ca948026e3f33b6725c6205842b9b0473` |
| `policy-engine/src/polisyos/core/llm/settlement.py` | mechanism | `442d0ddf13d30a91d442ce58a3a6e6cd4178d508edb8b284f1d0de0fda6dc8a1` |
| `policy-engine/src/polisyos/core/llm/traced_client.py` | mechanism | `aaa53e86314b7231e06a240a21c47e2ff4341d0affa2693497672d5fdaabfe46` |
| `policy-engine/src/polisyos/runtime/http/services/README.md` | mandatory documentation companion | `b6c08d4e1aacb41853532d77e067bec7a3bbe2296b8d63fd789d4e82b09bf8b9` |
| `policy-engine/src/polisyos/runtime/http/services/control/job_nl_execution.py` | mechanism | `c3708768ecb6ac9e2b4ec4d64133588e133f01331d4ec409893566aa1739a59f` |
| `policy-engine/src/polisyos/runtime/http/services/control/nl_pipeline.py` | mechanism | `5aac12fbcb311ecd90d02c651265961a6e1fd8d1541d44702e81520bf0f7722b` |
| `policy-engine/src/polisyos/runtime/http/services/control/producer_basis.py` | mechanism | `bdc032091100fd2cb40db2d6fbfd343cfb0d1177501d7c6c95dd20ec0715ada5` |
| `policy-engine/src/polisyos/runtime/http/services/control/run_lifecycle.py` | mechanism | `83a85ed5d27ded497bd725e4cd1558b2cac10fec266e52cedc56295625da1c18` |
| `policy-engine/src/polisyos/runtime/http/services/control_plane_store.py` | mechanism | `c95f43bebad7f917320530da9691adae63e731a07ad619b42f9b39e3c26bb9ed` |
| `policy-engine/src/polisyos/runtime/http/services/debug.py` | mechanism | `01dd49aad4c4555727918eb36ad060b4b78ef2eef5bdbcb6371fdd0d6157b6d0` |
| `policy-engine/src/polisyos/scientist/orchestration/engine/budget_middleware.py` | mechanism | `8abd43ad46b34b1dc2865ec8fe5d60f04bfbb20693ec8cbe0b1de6a89660e8f1` |
| `policy-engine/src/polisyos/scientist/orchestration/llm/README.md` | mandatory documentation companion | `2cff1f1ab5c544bcea37f2461e7b14bc46b368cff8789535959b95092163669b` |
| `policy-engine/src/polisyos/scientist/orchestration/llm/factory.py` | mechanism | `47497d983c315b370982f7549eec0cf3ac35b8df198e65380a572daed1fcd32a` |
| `policy-engine/src/polisyos/scientist/orchestration/llm/fallback_router.py` | mechanism | `ab113caaae65dc94d68106be1bbd6627cf30c24d8685bc51a7c14b4085f3b5f7` |
| `policy-engine/src/polisyos/scientist/orchestration/llm/gateway_client.py` | mechanism | `8dd538fc74926f449cbc8abaec4353d4d8151bddc5a6c2988d6b38b56635cd3e` |
| `policy-engine/src/polisyos/scientist/orchestration/llm/prepared_request.py` | mechanism | `b147b4788ae96373af086703752b40d74b686a350301e9e351386360745e779f` |
| `policy-engine/src/polisyos/scientist/orchestration/llm/prompt_cache.py` | mechanism | `d1553de4c7f710ee2483593f92e1fae8760d811398f1cb8f545b1d5072df8351` |
| `policy-engine/src/polisyos/scientist/orchestration/llm/provider_verification.py` | mechanism | `a37d6bcb8ce2e80bf92c2eaee035c0e7ebff7fe68069cd316319e3510d4631f6` |
| `policy-engine/src/polisyos/scientist/orchestration/llm/simulated_gateway.py` | mechanism | `9956d879a398abcf4bd7a02cf94f46197957ef7bfc289e992f705c82e4912561` |
| `policy-engine/src/polisyos/scientist/validation/citation_faithfulness.py` | mechanism | `a47e85813b10dc003b79283ae5e2e8d5efda84988ab62f15492f9878ccb4d427` |
| `policy-engine/tests/integration/runtime/http/test_nl_pipeline_cache_reuse_authorization.py` | mandatory semantic test companion | `64a96b8c7194180f03fe14d333486c9375d911c756765a6dc2aceb4b642426c6` |
| `policy-engine/tests/integration/runtime/http/test_r3_pre_admission_attempt_owner.py` | mandatory semantic test companion | `afbc4887c106d687546f843b64697afdb4f6d236ff720cc6493c2e6165e0046e` |
| `policy-engine/tests/unit/core/llm/test_cache_settlement.py` | mandatory semantic test companion | `442542af8c337530da184149f27162a6066cc525dce34ea21a62272bcdd7eb74` |
| `policy-engine/tests/unit/core/llm/test_traced_client_settlement.py` | mandatory semantic test companion | `180a61920bcb68bfcd0f884046fe71a13bde9a1c39eb1fcdd6bbc1f301d8498e` |
| `policy-engine/tests/unit/remediation/test_llm_01.py` | mandatory semantic test companion | `f576cb657c7724979f7b227f5896e9a5c67a19af67f53982f079b21cec60a8a0` |
| `policy-engine/tests/unit/runtime/http/test_control_nl_producer_admission.py` | mandatory semantic test companion | `c459f78276a36273482ea224c81227078c45b10fc3675ef5e5484a8fd4bcc481` |
| `policy-engine/tests/unit/runtime/http/test_nl_pipeline_cost_projection.py` | mandatory semantic test companion | `c96fc573bde833be72bac511e2b1ab32d1ca895cf7d25436fd9db1f1226f58fe` |
| `policy-engine/tests/unit/scientist/orchestration/llm/test_cache_owner_admission.py` | mandatory semantic test companion | `9035a7c53a0948da0eda911ca4c85cd642c300d7fd121cea2fc69545e34c94ab` |
| `policy-engine/tests/unit/scientist/orchestration/llm/test_fallback_router.py` | mandatory semantic test companion | `76499cf737e159b9477e30b6a3fff787c9c9fcc873b4e5780e04d4e1748b456c` |
| `policy-engine/tests/unit/scientist/orchestration/llm/test_gateway_client_retry.py` | mandatory semantic test companion | `beca5aee91b1e9bb8b7604f31e855e7bb70ba446a5752c462aad56edfd0c10c1` |
| `policy-engine/tests/unit/scientist/orchestration/llm/test_prepared_request_dispatch.py` | mandatory semantic test companion | `2581468d08cb21530dbf140eeed88ac136b6d2c5828bafb0b3e003828961147f` |
| `policy-engine/tests/unit/scientist/orchestration/llm/test_prompt_cache.py` | mandatory semantic test companion | `2dac534e1a31b98a8f6b3494eda561e49731600252ded9f411161aecaa7053d2` |
| `policy-engine/tests/unit/scientist/orchestration/llm/test_prompt_cache_scope_admission.py` | mandatory semantic test companion | `3e2eef1eb057b0dc540efdeeeb140fe0e5474569de4d5502b1f04fecb69577b1` |
| `policy-engine/tests/unit/scientist/orchestration/llm/test_provider_verification.py` | mandatory semantic test companion | `5e4154bf070fe34d7a8fdddd01f57d5b6781a9fafb86f80379c5cbc6ac910c6d` |
| `policy-engine/src/polisyos/common/serialization/__init__.py` | public shared-owner/context | `9dd34967d6bb95244085410a5988d326824c017aadb3233db903eab1efb31685` |
| `policy-engine/docs/reference/runtime-observational-source-access.md` | public shared-owner/context | `5cfb562f083813735362e2a37b902a1709d589fd50fc9e718b5103745e2f2818` |
| `policy-engine/src/polisyos/runtime/http/services/control/observational_source_access.py` | public shared-owner/context | `faef9afc1a2c72ebd2dd7c6344c68ed4d595d0a9e40aba1027033c908c7efebb` |
