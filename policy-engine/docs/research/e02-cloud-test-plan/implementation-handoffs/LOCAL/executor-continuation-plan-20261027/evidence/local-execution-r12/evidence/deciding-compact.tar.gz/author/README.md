# C86 portable scoped-source verification receipt

## Admission and profile

This bounded run used commit `ea3d65682d76a5d66d514e525ad2212e5a85f669`
and tree `7c5412fddc4ef3e56c859b83d237162e0fd260e7` on attached branch
`work`. The two mutation targets retained their published SHA-256 values:
`run_lifecycle.py` = `83a85ed5...1c18` and `bindings.py` =
`f8cf224d...1980`. No production file was mutated.

The interpreter was CPython 3.14.4 at
`/workspace/polisyos/policy-engine/.venv/bin/python` on Linux x86_64. The
container exposed 3 CPUs, 17 GiB RAM (16 GiB available), and 28 GiB free disk.
Installed deciding packages included pytest 9.0.2 and NumPy 2.3.5. EconML,
psutil, and Ruff were absent. A locked-profile provisioning attempt with
`uv sync --frozen --extra test --extra runtime --extra causal-core` failed
because the environment could not download the locked `llvmlite==0.50.0`
wheel through its network tunnel. Consequently the optional native check was
UNRUN, not passed.

Normal `pytest.ini` addopts remained active (`-ra -q --import-mode=importlib
--strict-markers` and normal plugin discovery). The only `-k` expression was
the commissioned native exclusion. Quarantine contained no cases. Commands
used one numerical thread and private pytest temp/JUnit locations. The audit
plugin records the actual pytest PID, executable, argv, monotonic interval,
selected node IDs, plugins, exit status, and the finite loaded `.py` set below
`src/polisyos`, `tests`, and `tools`. That set is not an all-repository or
environment closure.

## Outcomes

| Wave | Actual PID | Selected | Outcome |
| --- | ---: | ---: | --- |
| portable source-access module, native exclusion | 12830 | 18 | 1 PASS, 16 FAIL, 1 deselected |
| physical-input companion | 7384 | 59 | 59 PASS |
| selected-row companion | 8135 | 10 | 10 PASS |
| runner-contract companion | 8108 | 12 | 7 PASS, 5 FAIL |
| seven named Runtime companion functions | 12109 | 11 parametrized cases | 7 PASS, 1 FAIL, 3 ERROR |

The source-access collection confirms 18 collected cases and the expected 17
selected/1 deselected arithmetic. Sixteen selected cases failed during fixture
construction because the default catalog database was absent
(`CatalogReadSourceError: catalog_read_source_unavailable`). This occurs before
the scoped-source property or any of the five intended mutant assertions.
The sole pass was the static RuntimePrincipal shape check. The Runtime companion
failure/error cases have the same unavailable catalog substrate; seven cases
that do not require that construction passed.

The runner-contract failures are separate: qualified preparation returned
`source_protocol_kind_mismatch`, causing five later expected completion,
integrity, exception-type, and persistence signals to fail. This is a bounded
source result, not classified as inherited: no slice-base replay was available.

Because every commissioned removal selector's original node was already red at
fixture construction, M2, M3, M4, M6, and M8 were **not applied** and are
non-decisive/UNRUN. Calling those mutants red would violate the required
original-PASS prerequisite. The pristine post-run hashes above establish exact
restoration without using reset/checkout. No forbidden transfer, selected-view
substitution, wrong writer context, or derived-custody oracle was reached.
The smallest next check is to rerun the exact selectors in an environment with
the repository's selected catalog snapshot available, then perform each
original/mutant/restored triplet in isolation.

## Complete tracked Python caller census

`loaded-caller-enumeration.py` walks `git ls-files`, selects all `.py` files
under `src/`, `tests/`, and `tools/`, parses their ASTs, and finds calls by
resolved syntactic function/attribute name. Its denominator was 6,706 tracked
Python files and it found 22 call sites: five production callers (selected-row
producer/fresh reader, owned-attempt anchor, HTE outcome bridge, and search
uncertainty) plus 17 test calls. Aliases, dynamic dispatch, and external inputs
remain unresolved; the census therefore does not claim semantic call-graph
closure.

## Evidence transport and bounded verdict

`deciding-evidence.tar.gz` is the retrievable, lossless bundle of stdout/stderr,
JUnit XML, and per-process audit JSON. Its SHA-256 is
`4aae1e45600801a7ea1431d774b17d84152ded9c6c70bf022e80e4be2380abd2`.
The audit plugin SHA-256 is
`fc7894519adde353e119691a94d0fa3103ecd62a8cb0e8822d8609ed28341469`;
the caller census SHA-256 is
`eeffd6ad14e226771bab9befb0a3f25ddbcec454cd3c4710e1e71b76cbacc0f2`.

Result: the physical-input and selected-row portable companions pass, but C86
scoped-source runtime verification and all five removal controls are
`not_established` in this environment. No result establishes external
institutional permission, online IAM revocation, source truth, PII suitability,
calibration, legal adequacy, production currentness, TC-purpose authority, or
whole-E02/S1/G acceptance. Pattern pass: P05/P15 authority was not promoted;
P27/P31 owner paths were preserved; P29/P32 mutants were not claimed without a
behavioral oracle; P35 records its exact denominator; P37/P38 classify the
missing catalog/property divergence; and P41 leaves unreplayed reds
`not_established`.
