import ast,subprocess
files=[p for p in subprocess.check_output(['git','ls-files'],text=True).splitlines() if p.endswith('.py') and p.startswith(('src/','tests/','tools/'))]
h=[]
for p in files:
 try:t=ast.parse(open(p,encoding='utf8').read(),p)
 except Exception:continue
 for n in ast.walk(t):
  if isinstance(n,ast.Call) and ((isinstance(n.func,ast.Name) and n.func.id=='load_hte_physical_source_materialization_binding') or (isinstance(n.func,ast.Attribute) and n.func.attr=='load_hte_physical_source_materialization_binding')):h.append((p,n.lineno))
print('selector=git ls-files; prefix=src/,tests/,tools/; suffix=.py')
print('denominator',len(files),'calls',len(h));print(*h,sep='\n')
