"""Bounded pytest process and loaded-source receipt for the C86 verification lane.

This plugin records only Python modules loaded from ``src/polisyos``, ``tests``,
and ``tools``.  It is evidence about the selected process, not a repository or
environment closure.
"""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import sys
import time
from typing import Any

import pytest

_START = time.monotonic()
_SELECTED: list[str] = []


def pytest_collection_modifyitems(items: list[pytest.Item]) -> None:
    """Capture the node IDs remaining after normal pytest selection."""
    _SELECTED[:] = [item.nodeid for item in items]


def pytest_sessionfinish(session: pytest.Session, exitstatus: int | pytest.ExitCode) -> None:
    """Write the process identity and finite loaded-source read set."""
    root = Path(str(session.config.rootpath)).resolve()
    prefixes = tuple((root / part).resolve() for part in ("src/polisyos", "tests", "tools"))
    loaded: dict[str, dict[str, Any]] = {}
    for module in tuple(sys.modules.values()):
        raw_path = getattr(module, "__file__", None)
        if not raw_path:
            continue
        path = Path(raw_path)
        if path.suffix in {".pyc", ".pyo"}:
            path = path.with_suffix(".py")
        try:
            resolved = path.resolve(strict=True)
            relative = resolved.relative_to(root)
        except (OSError, ValueError):
            continue
        if resolved.suffix != ".py" or not any(resolved.is_relative_to(prefix) for prefix in prefixes):
            continue
        payload = resolved.read_bytes()
        loaded[relative.as_posix()] = {
            "bytes": len(payload),
            "sha256": hashlib.sha256(payload).hexdigest(),
        }
    plugins = sorted(
        {
            f"{type(plugin).__module__}.{type(plugin).__qualname__}"
            for plugin in session.config.pluginmanager.get_plugins()
        }
    )
    receipt = {
        "argv": sys.argv,
        "cwd": os.getcwd(),
        "end_monotonic": time.monotonic(),
        "exitstatus": int(exitstatus),
        "loaded_python": dict(sorted(loaded.items())),
        "pid": os.getpid(),
        "plugins": plugins,
        "python": sys.executable,
        "root": str(root),
        "selected_count": len(_SELECTED),
        "selected_nodeids": _SELECTED,
        "start_monotonic": _START,
    }
    output = Path(os.environ["C86_AUDIT_OUT"])
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")
