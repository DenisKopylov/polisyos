# C40-r3 frozen delta review

**GO for root composition and native verification of the bounded proposal.** Both blocking r2 findings and the profile-removal selector issue are resolved in the reviewed bytes. No new material static finding was identified in this delta. Runtime/removal outcomes remain **UNRUN**; whole B13 currentness, G acceptance and closure remain unestablished.

Exact package: `LOCAL/raw/e02-execution-20261027/repairs/C40-r3/`. Source patch: 44,271 bytes / SHA-256 `779629271b99dbb9e9910f035f4351bed652a8bfb3772561220d03fbd8c19337`. Manifest SHA-256 `d02281f3e40a8840ec5330309742e282fc16e8281daf900461a30939ad33af08`. Base commit `aefc080e6ed12f2fcc5e820b454c6fc4a9b494f2`, tree `56d746f575a06d77cb46ea6e5a839264f77fd877`.

## Findings resolved

- **R2 review R1, actual ArtifactManifest field:** the real-child CAS witness now reads `.artifact_schema`, requires both schemas to be present, then preserves the distinct expected schema-name assertions. The inherited BaseModel `.schema` method is no longer mistaken for a field. The selected-parent, actual sibling-view, integrity, default-manifest and reopened-DAG assertions are retained.
- **R2 review R2, copied-spec duplicate aliases:** immediately after constructing the alias map and before using it for admission/projection, the source checks its size against `workflow_spec.nodes` and rejects duplicate aliases. The new adversary constructs a valid spec, bypasses constructor validation through `model_copy(update=...)`, and requires that refusal. There is no silent last-wins lookup or fabricated duplicate outcome. The invariant is enforced before the map can authorize projection; map allocation itself does not weaken it.
- **Selected-profile removal:** PLAN.md now selects the first/default-write `test_research_dag_persists_and_loads_from_cas` and explicitly states why the conflicting-ambient-default test can remain green without the flag. The new `removal-parent-selector.patch` changes only the writer's `return_selected_profile=True` to False. This addresses the actual Core selection semantics without altering assertions or weakening CAS checks.

The complete r2→r3 postimage delta is limited to projection alias uniqueness and its test, plus the persistence test's actual schema field. The original cloud receipt/reconciliation, bounded selected-parent writer, full propagation-closure oracle, real engine witness, C28 identity/target repair and truthful authority limitations are retained. PLAN changes qualify the two removals and record the review corrections. No additional producer/currentness authority is introduced.

## Integrity, applicability and overlap

The complete manifest denominator is **twelve files: nine Python, one JSON, one Markdown and one TOML**. Every postimage digest/length and every existing base blob/SHA matches the manifest; declared new paths are absent at the base. At review, HEAD was exactly aefc and all twelve current preimages matched. This is a snapshot, not an enduring lease: root must repeat the normal preimage/ownership check before applying.

A read-only, in-memory application of every source.patch hunk checked its context/removal bytes and lengths against aefc and reproduced all twelve exact postimages. No Git index/object/ref or canonical source was written.

Both removal artifacts match their manifest hashes and have uniquely matching contexts in the frozen postimages:

- `removal-record-order.patch`: SHA-256 `b12780370cacb08b4520c0b824ccdad611ba4ef6e650a399f19f15238895ff20`. It retains selected-spec/limitation markers and reintroduces chronological reachability; the real propagation closure assertion is the deciding property.
- `removal-parent-selector.patch`: SHA-256 `6a391337e4018cfac01e9d706c1fcd407f8e9b03944b0fa5d550c3f230a0fbbf`. It removes exact selection only at the DAG writer; the planned first-write assertion must detect a profileless return.

Only their text transformation/applicability was independently verified. No control was executed and no expected red is reported as observed. The supplied AST/Ruff/format report is author static evidence over logical paths; root still needs final physical-topology checks and source-qualified native positive/removal/restore-green evidence.

## Bounded scope and remaining class

The actual parent/child CAS test, component/omitted-record admission, full closure oracle and real WorkflowExecutor/RunContext/finalization witness remain appropriate for **scheduling topology and selected artifact views**. The test invalidation is supplied directly and the public graph may redact refs. It is not a durable real source event, complete observed readset, causal-use proof or fresh served currentness decision.

Consumed-basis, typed edge-use, source revision/event universe, fencing and the fresh SimulationResult consumer remain the **SAME declared P40 residual** from the prior C40 review: `not_established`, `bridge_missing`, `consumer_missing`, `verification_missing`, `semantic_test_missing`. No new round is charged for another example of that known limitation, and this bounded repair is not promoted to whole B13 completion. The reconciliation appropriately preserves the old author receipt while qualifying its unsupported PASS summaries.

Proceed with root composition/freeze, then the planned bounded native/consumer checks and both isolated removals with full stdout/stderr/JUnit/source/readset/restore bindings. The failure/repair register was reopened before closeout (P37–P40; P29 behavioral stopping point retained). This reviewer ran no product/native test, installed no dependency, spawned no child and changed no canonical file or Git state. Only this review file was written.
