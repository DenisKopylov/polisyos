# C71 actual native partial run — independent qualification

**Qualified result: 1 completed PASS, 4 completed FAIL; 5 requested selectors have no completed outcome. Full ten-selector verification remains HOLD/incomplete.** Source admission is qualified for the observed finite Python set. Supervisor `complete=true` means the command/process group ended, not that the test wave completed.

Run: `D/c71-composed-native-original-seven-shared-custody-r2-20261028`, source `192fc44303c63e52e4dfa8e0b4ee77790bae3394` / tree `fd6881f1c9fc1e63984ed0b24095e0482faba2e9`. Audit SHA `55af7ed761387c2f7005cb40081af905293a148cb7474153a253dd7c59651ad5`; parent Git readback `86b6bae7d3b2dd68a637a6d42cc9b1187c06a2381b4f86acd3cadbf4942c4851`.

| Identified original-mode parameter ID | Result | JUnit seconds | Actual boundary |
| --- | --- | ---: | --- |
| raw-unit-unknown | PASS | 40.828 | Completed original node |
| selected-source-unit | FAIL | 178.457 | Row-hash inequality assertion, test:1767 |
| edge-removed-markers-retained | FAIL | 86.938 | Outbox pending rather than published, test:1698 |
| ambiguous-cell-self-consistent-mean | FAIL | 101.679 | Same outbox/projection boundary |
| source-refusal-retains-native-interval | FAIL | 101.951 | Same outbox/projection boundary |

**Do not derive two passes from XML.** Stdout progress is `.FFFF`, terminal summary is `4 failed, 1 passed` and pytest captured session state reports10 collected. XML's suite attributes declare tests=5, failures=4, errors=0, skipped=0. It contains six testcase elements: five identified reports above plus an anonymous `<testcase time="2.248"/>` with no name/class or finished assertion outcome. The runner's raw `junit.tests=6` counts elements. That extra element is an interruption artifact, not an additional PASS.

The requested canonical-declared-unit-normalization, same-payload-other-selected-profile, shared A-source/B-job native/fresh-service node, and both physical preparation nodes have **no completed named outcome**. The next planned selector was canonical-declared-unit-normalization; the anonymous element cannot itself establish a finished result or even a named assignment. Preserve these five as interrupted/UNRUN/not_established as applicable. Loaded/collected modules are not executed assertion receipts.

**Failure qualification.** These failures occur beyond the historical firstPOST403 source-access obstruction.

For selected-source-unit, both jobs have reached the completed-job/outcome/basis and earlier outbox/projection checks before test:1767 requires `inference_basis.fit_rows_sha256 != outcome.selected_rows_sha256`. Both observed hashes are `adb6a6d38b7130ce7a5707ad889ea995bd412d155c9f7f5b4ff09d72ab2d0c38`. At this exact source, `hte_v2.py::_row_identity_hashes` (1333–1367) hashes row_keys and sorted(row_keys); equality can occur when the selected keys are already canonically ordered. Equality alone therefore does not diagnose a native producer defect. Reconcile the actual row/order quantities and oracle with a discriminating permutation/noncanonical-order witness; do not simply delete/invert the assertion or rename a digest.

For the next three modes, the test has loaded a completed native interval job, its completed event, interval outcome and inference basis before attempting reconciliation. Outbox delivery remains pending at test:1698. Captured cause chain is Runtime `_deliver_search_hte_completion_outbox` → `consume_owned_hte_completion` → `_read_admitted_completion_result` → `_read_projection_for_row` → `_verify_projection_references`. At `uncertainty.py:6088`, comparison against the recomputed routing score raises `current routing score is not recomputed from its native interval`, wrapped as `selected Search projection or one of its CAS relations is malformed`. This is the consumer/projection revalidation boundary; it is not missing native backend or setup failure. The evidence does not yet settle which producer/revalidation input or limitation diverges. The owner must preserve genuine native interval, candidate grade, source/query/unit restrictions and unavailable routing semantics rather than force a positive score or erase uncertainty.

Raw-unit-unknown is useful bounded evidence for the exercised software path and source/profile. It does not prove all seven modes, shared A/B custody, all-native closure, external permission, calibration or production currentness.

**Interruption and resources.** Root explicitly requested SIGINT for actual pytest PID3704 at05:48:51.525692UTC, about578.898 seconds after command start (last sampled elapsed578.751),21.102 seconds before the fixed600-second quantum. Stop record SHA `46c0cfecf11f84f8c1a11d81984f8bd02456fa0d50a1ef2f178ac262935a144c` states a graceful partial stop to retain reports. Pytest caught KeyboardInterrupt and exited2; the supervisor finished585.109529875 seconds after launch,6.210 seconds after the signal, with process group gone and `aborted_reason=null`.

All553 resource samples were read. Peak sampled tree RSS was1,379,549,184B, below2,411,724,800B; minimum free disk10,785,325,056B, above the6GiB floor. There is no sampled RSS/disk abort or hard deadline event. Exit2 does not establish OOM. The command ended cleanly as a process operation while the requested verification remained partial and failed.

**Source/PID qualification.** Readset `373e49cfcb2a37229086a954c34689b208ea0d016f883a045f902ed965628668` contains **1,845 unique observed Python paths:1,830 src,15 tests,0 tools**. Independent comparison of every path to immutable run Git192fc and the index yields0 mismatches. Source-profile hash `9c1811e75972c6b62d9b52b36b1272e6a94dfd07c23dff568a86223cbcd1e422` binds the plan, normal profile, private outputs and guard-before/after identity. The session-finish readset PID is3704, its argv exactly matches the frozen pytest child argv, and supervisor samples show that actual PID running pytest_launcher.py. This is not merely a waiting-wrapper PID.

The parent receipt's Git/index/work0 mismatch is a receipt-time observation. During this later review, root has advanced to6c61 and three worktree files differ from the run: foundry/compile/__init__.py, foundry/compile/api.py and policy_runtime_method_metrics.py. All three exactly match the declared current C48 owner frame `36786c8d…`; they are later owned edits, not a reason to rewrite this run's source identity or stop on an unmatched state. The run is qualified at192fc, not those later bytes. Unimported files, external packages/native libraries and other processes remain outside this finite readset.

No exact slice-base replay and zero-intersection proof was performed, so **inherited-red attribution is not_established under P41**. Preserve these actual failures rather than exporting them as somebody else's debt.

The next meaningful work is to diagnose the row-hash oracle and shared Search routing/projection path from retained192fc artifacts, freeze any authorized repair with lower semantic evidence, then obtain completed evidence for repaired and unfinished selectors under a newly admitted source/resource frame. Do not blindly rerun this same partial wave or publish2PASS/10completed/nativeclosed claims.

Complete stdout84199B, stderr0B, XML4547B, readset465367B and resource trace2187368B remain in the actual raw run directory; their exact locators/hashes are in the companion JSON. Reviewer performed read-only evidence/Git/stdlb JSON/XML/hash/source inspection only: no product import, native/test rerun, canonical/index/refs/environment mutation or children. No capability/G/B198/S1 closure is granted.
