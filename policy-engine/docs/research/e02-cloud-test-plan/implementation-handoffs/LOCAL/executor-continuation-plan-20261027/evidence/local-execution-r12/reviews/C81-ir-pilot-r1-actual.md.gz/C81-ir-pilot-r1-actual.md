# C81 IR pilot r1 — independent actual-result qualification

**Bounded PASS: 10 cases in four selected IR test functions**, on source commit
`192fc44303c63e52e4dfa8e0b4ee77790bae3394`, tree
`fd6881f1c9fc1e63984ed0b24095e0482faba2e9`. The actual JUnit,
observer and supervisor receipts reconcile to that source cut. This does not qualify
HMC, MethodJob production, CAS writer admission, actual Monte Carlo provenance,
the ten removal controls, full B201/B202 or C81, S3/B31, E-M1 or G.

The only evidence directory abbreviated **D** below is:

`policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1/`.

The case is `D/c81-source-law-ir-pilot-r1-20261028/`. The exact plan SHA-256 is
`d44157696b4c6661ddb5e6761dd871a00fa143ce1e3d0c7f59917f783c35bef8`;
`audit-result.json` is
`17b518d5b5822448435b9cc4c6849ccaadb42775d84612567a84d410622129d6`.
Root's Git readback is
`D/c81-source-law-ir-pilot-r1-20261028-Git-readback.json` SHA-256
`8f3a3a8210826b7de15e15167e59b6afba740c4c2760279217a65c47b5136623`.
The independently parsed XML is `case/pytest.xml` SHA-256
`66654a71ce85a51301f6326e87ea4215882cc8e7f6064454e58e9e177209b103`.
The complete case stdout is SHA-256
`bd07d538b30aeccb05dd853987670864890bf141dbfa69ebab94fe2ee69fb228`;
stderr is empty.

## Actual selected assertions

The XML contains exactly these ten distinct cases, all with the expected test-module
classname and no failure, error or skipped elements:

- `test_source_hash_and_decoding_use_the_same_private_snapshot` — one case.
- `test_b201_keeps_named_point_functional_separate_from_equal_tail_interval`
  — `[posterior_mean-1.0]` and `[posterior_median-0.0]`.
- `test_constructed_summary_cannot_bypass_coordinate_identity` — one case.
  This tests an edited serialized mapping passed to `model_validate`; it is not
  the separate `model_construct` + actual CAS owner-writer test.
- `test_posterior_draw_artifact_refuses_ambiguous_scalar_coordinate_projection`
  — all six exact cases `[False-samples0]`, `[False-samples1]`,
  `[False-samples2]`, `[True-samples0]`, `[True-samples1]`,
  and `[True-samples2]`. The producer sorts source keys, so these are six
  collected cases spanning three alias fixtures and two input insertion orders;
  they are not claimed as six distinct serialized source laws.

The snapshot test wraps the real digest call and mutates the caller's source mapping
after hashing; the assertion checks the captured data remains bound to the original
bytes. The point test checks mean 1, median 0 and equal-tail [0,0] for 99 zeros and
one 100, including the existing envelope validator refusal. The remaining tests
exercise a forged coordinate declaration and the source projection's collision
refusals. This is bounded behavior on these fixtures, not proof of every source law
or of removal sensitivity. All four planned selectors match the actual XML names;
the result is not inferred from process exit alone.

## Source and input reconciliation

The selected owner and test bytes in the plan match Git and the working files at the
reviewed cut: `posterior_summary.py` SHA-256
`dd016b943dab63057414296da0631038dab653c596c4a36be104d87e960dd41f`;
`test_posterior_summary.py` SHA-256
`ccea24111bf04d83e3855eab87fe081f271ba017e0f518053e885076a6712c7b`.
The code-r2 composition commit `22a836d084b6e936eb639b4216596bc7a3bd3329`
is an ancestor of the source cut; its reviewed source hashes match those exercised.

The recorded `sys.modules` observer set is
`case/readsets/input-readset-1798.json` SHA-256
`5964eaafbdc7b0eb4eeef628e762be723f296084c363384b260464b92e687393`.
An independent complete comparison of its **874 distinct recorded Python paths**
found 867 under `policy-engine/src/polisyos/`, seven under `policy-engine/tests/`,
and zero under `policy-engine/tools/`. Every recorded SHA-256 matched both its
Git blob at 192fc and the inspected working file; no mismatch or untracked recorded
path was found.

The pinned source frame SHA-256 is
`99a87661b02cac37b9572ce40a2c389a1f15dacd5bedf963dc81184d36b01dc2`.
An independent comparison of its entire explicit **2,496-path, mixed-file-type**
denominator found all 2,492 declared file hashes matched Git and the inspected
working tree, and all four declared absences were absent in both. This is a selected
frame, not a complete-repository runtime census. The frame's historical `base`
field is not the run commit; matching the explicit path rows to 192fc is the basis
of this qualification.

All 13 recorded selected-input pins reconcile, including the plan, selected test,
runner, observer, supervisor, launcher, config and frame. The root-live input bytes
retained before launch in `D/c81-source-law-ir-pilot-r1-20261028-root-live-input.json`
hash to `0e3d0780b18aeb056b96752c7a3bf7e0ba2e2e951b0ea11ab49d716fab178480`,
exactly the freeze's root-live pin; their head, tree and source-frame binding match
the plan. Its filesystem mtime precedes the recorded freeze/start. The audited
guard records an empty expected staged diff at that cut; this review did not create
or alter Git state.

## Execution profile and limitations

The recorded argv uses the project venv, `python -B`, normal pytest configuration
and plugin discovery, the readset observer, and a sandbox profile limiting file writes
to the unique case directory. The selected source/profile freeze is SHA-256
`e4cfd1372eb4675041049ec12681c183133f9e5dfa32f86e00b11f0398f149e1`.
The bound runner clears the listed ambient Python/pytest control names, applies
one-thread numeric settings and a unique case-local bytecode prefix. The prefix
does not exist at review; the freeze and runner describe its fresh use. The record
reports no originally present restricted control names. This is not an independent
inventory of all native packages, plugins or their versions.

The supervisor reports exit 0, `complete=true`, no abort or termination signal,
and process-group disappearance. All 15 retained process-tree samples independently
reproduce the reported **693,780,480-byte sampled maximum RSS** and minimum sampled
free disk of **12,366,213,120 bytes**; the monotonic wall time is
**15.836535833 seconds**. The sampled process set contains PID 1798. Sampling
does not prove an unsampled peak or absence of a very short-lived descendant.

The observer walks `sys.modules` at pytest session finish and records resolved
project `.py` paths still present then. It does not prove a complete transient-import,
subprocess, non-Python, external-package or backend readset, nor is its last-read
hash a full import-time byte trace. No such broader claim is made here. The sandbox,
unique case directory, bound launcher and pre/post source guards provide the stated
finite-context support; current-source claims after a later Root advance require
affected-path/readset reconciliation rather than relabeling this result.

The source-law property is `recomputed` by the selected tests; their actual
recorded source set and pinned case artifacts were `independently_reconciled`.
The selected-evidence-ref and credible-mass linkage at a standalone or mutated
Monte Carlo input remain `consumer_asserted`, with both falsifiers UNRUN. The
failure register was reread: P29/P35/P38 constrain the receipt and its denominator;
P37 preserves that authority boundary. `closure_ids=[]`.

This reviewer performed no product imports, tests, native run, installation,
canonical edit, index/ref/object mutation or environment change.
