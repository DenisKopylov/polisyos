# C89 actual code and evidence review

**Narrow provider delta: source GO for Root contextual composition, with the README/release companions and local checks still required. Full C05 acceptance: HOLD, Partial / `verification_missing`.** The returned full wave is 359 PASS / 43 FAIL, not a green suite. No C05 closure, G acceptance, protected-authority acceptance, current-Root runtime PASS, or inherited-red waiver follows.

This is an independent review of the Cloud-authored C89 provider fix and its actually delivered evidence. I authored earlier local C05 proposals and the commission; this is not a new independent approval of that entire prior implementation. Review execution used stdlib parsing and read-only Git only: no product imports, native tests, environment changes, canonical changes, index/ref mutation, or children.

## Frozen input and complete transport

* Actual received `cloud/C89/source.diff`: 2,387,786 B, SHA-256 `f41413f2491e65682f5d69ee18345ce1550b005d240c11495c7e621c2257dc9a`.
* `candidate-manifest.json`: SHA-256 `c8a0d928446225afaee76d6446a3bef6e7cd26cc6e9283c5170208aa431301c4`.
* Base: commit `ea3d65682d76a5d66d514e525ad2212e5a85f669`, tree `7c5412fddc4ef3e56c859b83d237162e0fd260e7`.
* Candidate tree `28285d69e23a34bd0d4fbe568df8e44025aeb3e4` is Root's reconstruction from the retrieved diff. A final worker commit ID is **not established** by the packet; do not describe the reconstructed tree as a worker commit/readback.
* All 117 changed manifest paths were checked against actual bytes, SHA-256, length and Git blob identity: 116 new evidence documents plus one changed production Python file. All 116 evidence files are physically present under `cloud/C89/delivered/c89-c05-native-20261028/`. All 36 gzip members (12 stdout, 12 stderr, 12 JUnit) decompress and pass integrity checks. Every JUnit outcome was reconciled with its complete framework collection and receipt. All 40 input source pins were reopened from Git EA and matched.
* `receipt.json` is `b1a6ecef7e549ea40fc5334a5ea751ef21d449bd85c0ce00cb6e4f5849e291f6`. Its inventory has 117 rows: 115 match delivered files, and two ignored `__pycache__` rows (`pytest_launcher.cpython-314.pyc`, `run_case.cpython-314.pyc`) were not exported. The receipt excludes itself to avoid a recursive hash. Thus the report's “every file” inventory wording needs this qualification. No deciding output is missing in these two rows; do not claim all 117 receipt inventory rows were delivered.

The full received diff is a valid lossless carrier for this packet. The checkpoint may retain one lossless gzip of that diff with its raw hash/length, the base identity and this review instead of duplicating all 116 exported files. It must not reduce deciding evidence to hashes without retaining the payload. The two omitted bytecode caches are not required evidence. The deciding pytest outputs, commands, full collections, actual profiles/readsets/resources, two actual mutant diffs, launcher and supervisor are necessary; all are in the received carrier.

## Production fix and its actual consumer

The sole changed source is `policy-engine/src/polisyos/scientist/orchestration/llm/provider_verification.py`. Candidate blob `9d144f6a7b73d74bb512ad5b9b889dc2d9946fae`, SHA-256 `2db50729304ed575816253aeadcc6dbfd400669f9c38680ce5337514421a59df`, 71,496 B. Base blob is `94284e3314f4a0674d26624326ec80522b49630e`. The receipt's source-only diff hash recomputes exactly with `git diff --abbrev=8 EA CAND -- <path>`: `5b32a53d4a0be05d686f094369b166e8b4e52b4f3d18f2fcb7bf7029f6c1273a`. The changed source AST parses without executing it.

**P40 bucket: SAME durable-origin reconciliation class, at owner reopen.** The property is that malformed or altered durable origin state leaves settlement unknown before further provider work. Before this delta, `settlement_owner_identity` reloaded and validated the whole durable ledger; a validation/decode exception fell through the existing generic unavailable-store branch and emitted `failed`/`not_started`, even though the failure concerned an existing origin. A concrete divergent case is the existing native test changing a persisted reuse provider, or removing its original event while retaining a dependent reuse row.

At candidate lines 1074, 1106–1119 and 1163–1172 the fix separates TypeError/ValueError/JSON decode failure from the generic setup-failure branch and returns the existing `_preflight_unknown_report`. It returns before cache key/catalog/network dispatch. The canonical `BudgetMiddleware.settlement_owner_identity` holds its lock and delegates to `FileBudgetLedger.settlement_owner_identity`; the latter reopens the persisted snapshot under the file lock, so invalid persisted origin structure raises during actual owner reading. No callback statement, cached old identity, new issuer, default cost, or copied fresh origin is substituted.

The existing unconfigured middleware raises RuntimeError and the missing unbootstrapped file raises FileNotFoundError; these still reach the existing failed/unavailable path. A missing ordinary store operation still fails the required-operation check. This source conclusion is bounded to the actual canonical owner: the new try also surrounds operation lookup, and a custom exception-throwing descriptor is not independently classified as a supported durable-owner contract by this review. There is no new broad catch that permits I/O or success.

`_preflight_unknown_report` (candidate 668–700) emits existing status `unknown`, code `llm_provider_preflight_settlement_unknown`, retryable false and completion observation `unavailable` by the existing DTO default. The actual Runtime launch consumer in `runtime/http/services/control/run_lifecycle.py` reads this observation and status; it cannot admit `unknown` as complete. `_pre_admission_producer_event_refs` reopens exact run-bound rows and returns `unavailable` on failed reconciliation; the launch branch records an unresolved attempt and refuses admission. Its real POST assertions are **not proved here**, because the seven requisite Runtime baseline cases stop at catalog setup.

The unchanged real-loopback test `test_provider_preflight_records_bound_gateway_completion_and_reuses_exact_event` now passes all three reported/estimated/unknown variants. It checks real completion/reuse counts, distinct receiver events, preserved original source, foreign owner/run/provider separation, persisted-row mutation/deletion refusal and no additional provider fetch/send. The separate two-case `test_provider_preflight_required_accounting_refuses_before_provider_io` still passes within the complete 45-case provider module, including the unconfigured-store and wrong-run-key controls. FileNotFoundError behavior is source-traced, not a new dedicated runtime result.

No new DTO, facade, enum, import surface, ledger writer/schema, or cache/factory contract is introduced by this delta. Root should add the nearest README note and operator-visible bugfix release fragment required by CONTRIBUTING. Existing regression cases already exercise this fix, so a copied constructor/marker test is unnecessary. Root still owns physical Ruff/check/format, contextual application and current-source replay.

## Actual native outcomes

All rows below concern EA plus the one provider fix when noted. Overlapping reruns are not added together as independent cases.

* Decoder smoke: 7 PASS. Initial priority component: 27 PASS / 3 FAIL; exact isolated pre-fix replay: 3 FAIL. After the provider change, focused replay: 3 PASS; identical priority collection: 30 PASS; complete provider module: 45 PASS.
* Full wave: all 14 requested physical modules, exactly 402 framework-collected items, 359 PASS / 43 FAIL, zero errors/skips/deselection. No count quota or source estimate terminated the run. It took 178.27 s, with peak sampled process-tree RSS 1,287,487,488 B; no deadline/RSS/disk abort.
* Removal 1: the exact seven items passed in the normal component baseline, failed with the actual exact-invocation guard removed (`call_mismatch` stopped raising), then all seven passed after restore. The mutant source readset hashes match the independently applied marker-preserving diff; restored hashes match the normal candidate.
* Removal 2: the exact fifteen items passed in the normal component baseline, failed with actual native/opaque dispatch replaced by wire thaw (tuple/type/identity or unsupported-wire property failures), then all fifteen passed after restore. These were property failures after test execution, not collection/import failures. Mutant/restored source hashes reconcile.
* Removal 3: its provider positive subset is 3 PASS, but all seven Runtime positive items FAIL at catalog construction. No third mutant/restored run was applied or delivered. The Runtime complete-producer-basis/ledger removal claim remains **UNRUN**.

Complete full-wave module denominator:

| Physical module under `policy-engine/` | PASS | FAIL |
| --- | ---: | ---: |
| `tests/integration/runtime/http/test_nl_pipeline_cache_reuse_authorization.py` | 0 | 23 |
| `tests/integration/runtime/http/test_r3_pre_admission_attempt_owner.py` | 0 | 10 |
| `tests/unit/core/llm/test_cache_settlement.py` | 17 | 0 |
| `tests/unit/core/llm/test_traced_client_settlement.py` | 28 | 0 |
| `tests/unit/remediation/test_llm_01.py` | 7 | 1 |
| `tests/unit/runtime/http/test_control_nl_producer_admission.py` | 8 | 0 |
| `tests/unit/runtime/http/test_nl_pipeline_cost_projection.py` | 26 | 4 |
| `tests/unit/scientist/orchestration/llm/test_cache_owner_admission.py` | 45 | 2 |
| `tests/unit/scientist/orchestration/llm/test_fallback_router.py` | 8 | 0 |
| `tests/unit/scientist/orchestration/llm/test_gateway_client_retry.py` | 99 | 0 |
| `tests/unit/scientist/orchestration/llm/test_prepared_request_dispatch.py` | 23 | 0 |
| `tests/unit/scientist/orchestration/llm/test_prompt_cache.py` | 43 | 1 |
| `tests/unit/scientist/orchestration/llm/test_prompt_cache_scope_admission.py` | 10 | 2 |
| `tests/unit/scientist/orchestration/llm/test_provider_verification.py` | 45 | 0 |
| **Total** | **359** | **43** |

## Complete 43-failure taxonomy and routes

This taxonomy exhausts every failed full-wave node; exact parametrized node IDs are in the adjacent JSON. The complete original failure text remains in `cases/c_full14/{stdout.raw.gz,pytest.xml.gz}`. Every row remains actual FAIL. The source diagnoses below are bounded repair directions, not replayed repairs, exemptions or P41 inherited labels.

**A. Catalog selected-source construction: 36 FAIL.** There are 34 direct `CatalogReadSourceError: catalog_read_source_unavailable` failures and two expected-failure regex assertions preempted by that same exception. The shared observed chain is `build_runtime_api_env` → `_build_runtime_api_env_for_fixture_data` → `ControlPlaneService.__init__` (EA line 4235) → `CatalogSearch.__init__` → `CatalogKnowledgeStore.__init__` → `_fetch_source_identities` → `identify_read_sources` → `identify` (store.py:1227). One simulated-cost case constructs the service directly and reaches the same source-owner boundary. C05 authorization, source/attempt drift, citation-row completeness and real POST assertions in these tests have not run far enough to decide their properties.

All catalog-blocked functions, without sampling:

* `tests/integration/runtime/http/test_nl_pipeline_cache_reuse_authorization.py::test_control_plane_reuses_only_current_owner_authorized_snapshot`: 4; variants `[False-False]`, `[False-True]`, `[True-False]`, `[True-True]`.
* `tests/integration/runtime/http/test_nl_pipeline_cache_reuse_authorization.py::test_authorizer_preserves_no_key_and_explicit_uncached_modes`: 2; variants `[False]`, `[True]`.
* `tests/integration/runtime/http/test_nl_pipeline_cache_reuse_authorization.py::test_fresh_job_cost_projection_refuses_ledger_drift`: 3; variants `[missing]`, `[changed]`, `[foreign_attempt]`.
* `tests/integration/runtime/http/test_nl_pipeline_cache_reuse_authorization.py::test_matching_snapshot_decision_cannot_replace_live_job_admission`: 3; variants `[attempt]`, `[lease_owner]`, `[actor]`.
* `tests/integration/runtime/http/test_nl_pipeline_cache_reuse_authorization.py::test_ordinary_n4_unknown_provider_sampling_stays_uncached`: 1.
* `tests/integration/runtime/http/test_nl_pipeline_cache_reuse_authorization.py::test_actual_unobserved_citation_is_in_reopened_complete_basis`: 2; variants `[producer_row]`, `[spend_receipt]`.
* `tests/integration/runtime/http/test_nl_pipeline_cache_reuse_authorization.py::test_fresh_job_reader_requires_current_typed_proposal_attempt`: 4; variants `[absent_attempt]`, `[wrong_attempt]`, `[wrong_core]`, `[empty_stale]`.
* `tests/integration/runtime/http/test_nl_pipeline_cache_reuse_authorization.py::test_fresh_job_projection_preserves_typed_dependency_failure`: 2; variants `[unavailable]`, `[timeout]`.
* `tests/integration/runtime/http/test_nl_pipeline_cache_reuse_authorization.py::test_fresh_job_reader_joins_exact_proposal_output_profile`: 1.
* `tests/integration/runtime/http/test_nl_pipeline_cache_reuse_authorization.py::test_ordinary_job_refuses_an_actual_begin_without_attempt_attribution`: 1.
* `tests/integration/runtime/http/test_r3_pre_admission_attempt_owner.py::test_actual_nl_post_gateway_settlement_reopens_and_serves_same_run`: 7; variants `[reported]`, `[estimated]`, `[unknown]`, `[unknown-cost-cancel-before-enqueue]`, `[cancel-after-settlement-before-enqueue]`, `[ordinary-failure-after-settlement-before-enqueue]`, `[remove-settlement-keep-job-markers]`.
* `tests/integration/runtime/http/test_r3_pre_admission_attempt_owner.py::test_nl_route_owner_preempts_generic_x_idempotency_replay`: 1.
* `tests/integration/runtime/http/test_r3_pre_admission_attempt_owner.py::test_nl_pre_admission_4xx_marks_noncreated_attempt_and_404_is_uncached`: 2; variants `[malformed-profile-not-defaulted]`, `[missing-idempotency-key-refused]`.
* `tests/unit/runtime/http/test_nl_pipeline_cost_projection.py::test_runtime_api_env_builder_closes_worker_when_fixture_setup_raises`: 1.
* `tests/unit/runtime/http/test_nl_pipeline_cost_projection.py::test_runtime_api_env_closes_published_client_when_registration_fails`: 1.
* `tests/unit/runtime/http/test_nl_pipeline_cost_projection.py::test_simulated_nl_producer_costs_settle_and_capture_four_origins`: 1.

Catalog routing is to the actual selected-source fixture/lifespan producer, not to weaker observational guards or a public-scope marker. C71 author confirmed the current **draft** is `repairs/C86-portable-fixtures-r1`: `_selected_runtime_api_env` / `selected_source_runtime_api_env` reuse the existing selected fixture, typed `CatalogServingSourceSelection` and `source_owner_root`; `scoped_source_runtime` enters authenticated TestClient lifespan and carries the selected source. That draft changes two C71 fixtures and deliberately leaves generic `runtime_http.py` / `runtime_api_env` unchanged. It is therefore a reusable route for C89's callers, **not** an automatic correction of all 36 failures and not a reviewed/native PASS. The older C71 physical fixture prerequisite only supplies an input owner and does not address Catalog. The direct-constructor simulated-cost case and generic C89 runtime builders need their actual source-owner context composed explicitly.

**B–G. Seven distinct remaining failures, all outside the 36 catalog blocks:**

| Boundary / exact test function | Items | Actual failure and smallest property-preserving next step |
| --- | ---: | --- |
| `tests/unit/remediation/test_llm_01.py::test_gateway_prompt_form_maps_to_supported_user_message_once` | 1 | Its `fake_post_json` rejects Gateway's actual `_prepared_transport` keyword (`gateway_client.py:355`, via real Traced generate). Repair the test adapter companion while still asserting one supported user-message wire payload; do not drop prepared transport from production to green the fake. |
| `tests/unit/runtime/http/test_nl_pipeline_cost_projection.py::test_ordinary_nl_post_persists_and_serves_durable_cost_events_after_reopen` | 1 | At line 1572 the exact response-key set omits the new `producer_cost_projection_status` and `producer_cost_projection_limitation_code`. Reconcile this outward test/API expectation with the intended typed limitation surface and real persisted evidence; do not remove honest limitations to satisfy old keys. This case reached the API assertion; it is not catalog-blocked. |
| `tests/unit/scientist/orchestration/llm/test_cache_owner_admission.py::test_unknown_default_never_establishes_deterministic_reuse[nan]` | 1 | Expected ValueError was not raised by the opaque Python fixture. R8 keeps unsupported native values physical-only rather than imposing Gateway's JSON law on every Python protocol adapter. Distinguish that real adapter contract from strict Gateway rejection; verify physical-only/no-reuse and keep an actual Gateway invalid-value refusal. This is a source diagnosis, not a proven repaired outcome. |
| `tests/unit/scientist/orchestration/llm/test_cache_owner_admission.py::test_injected_cache_selectors_never_reach_actual_gateway_wire[fallback]` | 1 | Expected 2 bodies, observed 4: two logical requests each try failing primary plus successful alternate, whose negotiated/fallback outcome is intentionally not reusable. The metadata assertions occur after the failing count assertion, so this fallback emission property is not established by the red test. Count actual endpoint attempts and retain assertions over every actual emitted body; do not reenable alternate-outcome reuse to force 2. |
| `tests/unit/scientist/orchestration/llm/test_prompt_cache.py::TestCachingLLMClient::test_pi_distinct_operations_do_not_reuse_same_content_response` | 1 | The uncached calls have `sampling_policy_not_established` twice instead of expected `cache_disabled_by_metadata`. The fake omits an explicit deterministic temperature and sampling eligibility precedes metadata disable. Preserve the distinct physical/no-reuse assertions and reconcile reason precedence; do not infer deterministic provider defaults. |
| `tests/unit/scientist/orchestration/llm/test_prompt_cache_scope_admission.py::test_cas_admitted_flight_cleanup_allows_fresh_physical_retry[error]` and `[deadline]` | 2 | Both timeout waiting for `all_waiting` at line 264. The fixture counts `asyncio.shield` only when its object is `flight.task`; shared flight now waits on per-loop Futures. Thus it stops before the cleanup/retry assertion and proves neither cleanup failure nor success. Observe real Core session join/receiver admission as in the existing factory-composition fixture, retaining four receivers, one physical call, cancellation, terminal cleanup and fresh retry assertions. |

The routes above form one coordinated test/consumer reconciliation batch, not permission to waive results or repair production toward obsolete proxies. No P41 clean-base/disjoint replay was supplied for the 43 nodes. Provenance of the reds is consequently `not_established` with respect to inheritance.

## Actual process profile and proof limits

The delivered launcher and supervisor were read in full. All twelve cases independently reconcile start/configuration/collection/session-finish PID, actual `-B`/dont-write-bytecode flag, actual pycache prefix existence and emptiness at start and pytest configuration, effective importlib/strict-markers/asyncio-auto settings, no keyword/mark selection, maxfail 0, native default plugin autoload, private cache/temp/SQLite paths, localhost proxy exclusion, and one numerical thread. The config receipts disclose the real plugin set and Python search path rather than claiming an empty environment. The cgroup supplied 16 GiB RAM and two CPUs; per-case limits were 600 s and 2.25 GiB sampled process-tree RSS with a 6 GiB disk floor. The observer is a one-second Linux process-tree sampler, not an instantaneous RSS bound or a full child import audit.

Cloud used Python 3.14.4, pytest 9.0.2 and the preprovided environment. `.pth` contents disclose the editable product root/src paths and `_virtualenv` hook. Model identity is `not_established`. Full pytest stdout/stderr/JUnit are retained for all twelve cases. The actual Ruff absence command/stdout/stderr is retained in `preflight.json`; Ruff/check/format is UNRUN, not a product FAIL. The pip uv-upgrade CONNECT-403 attempt is only a command/result summary in preflight/report; complete pip stdout/stderr is not delivered. Architecture download blockage/partial findings and Python compilation PASS are likewise report-only: their complete commands/outputs are absent, so no independent architecture/public-inventory or py_compile verdict is established. Reviewer AST parsing is separate, read-only evidence. No type/API/generated/current-platform gate is silently green.

All session-finish source hashes were compared with their exact expected EA/candidate/mutant/restored source state; zero mismatches. The complete finite union is **1,916 `.py` paths**, selected by end-of-session `sys.modules` observations rooted in src/tests/tools. This is not a repository-wide input closure: unloaded source, child/external imports, resources and exact bytes at each import instant are unresolved by construction.

At review readback Root was clean at commit `d9397c7c0458ec2980fa58115c5ee597eb58dbc8`, tree `832c6d744f3f09f261fbd8c72dc647109e2baceb`. Six observed source paths differ from the normal Cloud candidate: `foundry/compile/__init__.py`, `foundry/compile/api.py`, `foundry/uncertainty/monte_carlo.py`, `ir/analytics/posterior_summary.py`, `scientist/nodes/builtins/decide/policy_runtime_method_metrics.py`, and the unapplied Cloud `provider_verification.py` fix. Their exact hashes are in the JSON. Federation has **zero observed module paths** in this finite selector; it is unresolved by construction, not proof of complete disjoint Runtime inputs. MC, IR and compile/method-metric advances visibly intersect the observed denominator. Consequently 45 provider passes, 359 full-wave passes and both removal controls remain tied to EA plus the exact provider delta, not current Root.

## Closeout and next deciding checks

Root can context-compose the one-file provider fix plus README/release companions and run physical product Ruff/check/format. First reconcile the seven noncatalog consumer fixtures against the actual invariants; compose an authentic selected-source/lifespan fixture route for the catalog-blocked cases. Then rebind the same bounded modules and profiles to a clean composed checkpoint, rerun the actual Runtime positives and only run removal 3 after its seven-item positive baseline is green. Restore and replay it, retain full deciding outputs and readsets, and do not carry a current PASS across intervening source changes. No observational guard, durable owner, cost origin or unknown-state gate should be relaxed to repair setup.

Pattern pass: P05/P12 preserve canonical durable authority; P29/P32 use actual owner/loopback and behavioral removals; P35 exhausts delivered files, gzip members, framework items and the explicitly finite `.py` readset; P37/P38 distinguish durable unknown from a provider-failure proxy and exact call properties from old test-shape proxies; P40 keeps the repair in its declared class; P41 supplies no inherited waiver. The failure register was read again before closeout. The accepted result is a bounded source/evidence handoff with `verification_missing`, not a complete capability claim.

Independent recomputation: `C89-code-evidence-c05-audit.py` SHA-256 `2c20084cdfc082f972a970db3ec7d72101a07646c9547c9c90c50d89ebcfd43b`. Machine receipt: `C89-code-evidence-c05.json` SHA-256 `7d029190f775750d705842bf14a36c720d5f2f575f8ef2097c75a06ebce44824`. Both live beside this review under `LOCAL/raw/e02-execution-20261027/reviews/`; all raw deciding outputs remain in the delivered packet.
