from typing import Literal, assert_type
from polisyos.foundry.methods.base import _stable_digest
assert_type(_stable_digest({}), str)
import polisyos.foundry.methods.base as owner_0
assert_type(owner_0.FidelityLevel.LOW, Literal[owner_0.FidelityLevel.LOW])
value_0: int = owner_0.FidelityLevel.LOW.value
literal_0: Literal[1] = owner_0.FidelityLevel.LOW.value
assert_type(owner_0.FidelityLevel.MEDIUM, Literal[owner_0.FidelityLevel.MEDIUM])
value_1: int = owner_0.FidelityLevel.MEDIUM.value
literal_1: Literal[2] = owner_0.FidelityLevel.MEDIUM.value
assert_type(owner_0.FidelityLevel.HIGH, Literal[owner_0.FidelityLevel.HIGH])
value_2: int = owner_0.FidelityLevel.HIGH.value
literal_2: Literal[3] = owner_0.FidelityLevel.HIGH.value
assert_type(owner_0.ComplexityClass.O_1, Literal[owner_0.ComplexityClass.O_1])
value_3: int = owner_0.ComplexityClass.O_1.value
literal_3: Literal[1] = owner_0.ComplexityClass.O_1.value
assert_type(owner_0.ComplexityClass.O_LOG_N, Literal[owner_0.ComplexityClass.O_LOG_N])
value_4: int = owner_0.ComplexityClass.O_LOG_N.value
literal_4: Literal[2] = owner_0.ComplexityClass.O_LOG_N.value
assert_type(owner_0.ComplexityClass.O_N, Literal[owner_0.ComplexityClass.O_N])
value_5: int = owner_0.ComplexityClass.O_N.value
literal_5: Literal[3] = owner_0.ComplexityClass.O_N.value
assert_type(owner_0.ComplexityClass.O_N2, Literal[owner_0.ComplexityClass.O_N2])
value_6: int = owner_0.ComplexityClass.O_N2.value
literal_6: Literal[4] = owner_0.ComplexityClass.O_N2.value
assert_type(owner_0.ComplexityClass.O_N3, Literal[owner_0.ComplexityClass.O_N3])
value_7: int = owner_0.ComplexityClass.O_N3.value
literal_7: Literal[5] = owner_0.ComplexityClass.O_N3.value
assert_type(owner_0.ComplexityClass.O_EXP, Literal[owner_0.ComplexityClass.O_EXP])
value_8: int = owner_0.ComplexityClass.O_EXP.value
literal_8: Literal[6] = owner_0.ComplexityClass.O_EXP.value
assert_type(owner_0.SlotType.SCALAR, Literal[owner_0.SlotType.SCALAR])
value_9: int = owner_0.SlotType.SCALAR.value
literal_9: Literal[1] = owner_0.SlotType.SCALAR.value
assert_type(owner_0.SlotType.VECTOR, Literal[owner_0.SlotType.VECTOR])
value_10: int = owner_0.SlotType.VECTOR.value
literal_10: Literal[2] = owner_0.SlotType.VECTOR.value
assert_type(owner_0.SlotType.MATRIX, Literal[owner_0.SlotType.MATRIX])
value_11: int = owner_0.SlotType.MATRIX.value
literal_11: Literal[3] = owner_0.SlotType.MATRIX.value
assert_type(owner_0.SlotType.TENSOR, Literal[owner_0.SlotType.TENSOR])
value_12: int = owner_0.SlotType.TENSOR.value
literal_12: Literal[4] = owner_0.SlotType.TENSOR.value
assert_type(owner_0.ComputeBackend.JAX, Literal[owner_0.ComputeBackend.JAX])
value_13: str = owner_0.ComputeBackend.JAX.value
literal_13: Literal['jax'] = owner_0.ComputeBackend.JAX.value
assert_type(owner_0.ComputeBackend.NUMPY, Literal[owner_0.ComputeBackend.NUMPY])
value_14: str = owner_0.ComputeBackend.NUMPY.value
literal_14: Literal['numpy'] = owner_0.ComputeBackend.NUMPY.value
assert_type(owner_0.ComputeBackend.SOLVER, Literal[owner_0.ComputeBackend.SOLVER])
value_15: str = owner_0.ComputeBackend.SOLVER.value
literal_15: Literal['solver'] = owner_0.ComputeBackend.SOLVER.value
assert_type(owner_0.ComputeBackend.BAYESIAN, Literal[owner_0.ComputeBackend.BAYESIAN])
value_16: str = owner_0.ComputeBackend.BAYESIAN.value
literal_16: Literal['bayesian'] = owner_0.ComputeBackend.BAYESIAN.value
assert_type(owner_0.MethodKind.PURE, Literal[owner_0.MethodKind.PURE])
value_17: str = owner_0.MethodKind.PURE.value
literal_17: Literal['pure'] = owner_0.MethodKind.PURE.value
assert_type(owner_0.MethodKind.MECHANISM, Literal[owner_0.MethodKind.MECHANISM])
value_18: str = owner_0.MethodKind.MECHANISM.value
literal_18: Literal['mechanism'] = owner_0.MethodKind.MECHANISM.value
assert_type(owner_0.MethodKind.SIMULATION, Literal[owner_0.MethodKind.SIMULATION])
value_19: str = owner_0.MethodKind.SIMULATION.value
literal_19: Literal['simulation'] = owner_0.MethodKind.SIMULATION.value
assert_type(owner_0.SideEffectProfile.NONE, Literal[owner_0.SideEffectProfile.NONE])
value_20: str = owner_0.SideEffectProfile.NONE.value
literal_20: Literal['none'] = owner_0.SideEffectProfile.NONE.value
assert_type(owner_0.SideEffectProfile.PATCH_EMISSION, Literal[owner_0.SideEffectProfile.PATCH_EMISSION])
value_21: str = owner_0.SideEffectProfile.PATCH_EMISSION.value
literal_21: Literal['patch_emission'] = owner_0.SideEffectProfile.PATCH_EMISSION.value
assert_type(owner_0.SideEffectProfile.ARTIFACT_EMISSION, Literal[owner_0.SideEffectProfile.ARTIFACT_EMISSION])
value_22: str = owner_0.SideEffectProfile.ARTIFACT_EMISSION.value
literal_22: Literal['artifact_emission'] = owner_0.SideEffectProfile.ARTIFACT_EMISSION.value
assert_type(owner_0.SideEffectProfile.TRAINING, Literal[owner_0.SideEffectProfile.TRAINING])
value_23: str = owner_0.SideEffectProfile.TRAINING.value
literal_23: Literal['training'] = owner_0.SideEffectProfile.TRAINING.value
import polisyos.foundry.methods.components.composer as owner_1
assert_type(owner_1.SemanticValidationLevel.OFF, Literal[owner_1.SemanticValidationLevel.OFF])
value_24: str = owner_1.SemanticValidationLevel.OFF.value
literal_24: Literal['off'] = owner_1.SemanticValidationLevel.OFF.value
assert_type(owner_1.SemanticValidationLevel.WARN, Literal[owner_1.SemanticValidationLevel.WARN])
value_25: str = owner_1.SemanticValidationLevel.WARN.value
literal_25: Literal['warn'] = owner_1.SemanticValidationLevel.WARN.value
assert_type(owner_1.SemanticValidationLevel.STRICT, Literal[owner_1.SemanticValidationLevel.STRICT])
value_26: str = owner_1.SemanticValidationLevel.STRICT.value
literal_26: Literal['strict'] = owner_1.SemanticValidationLevel.STRICT.value
