from typing import Any, Literal, assert_type
from collections.abc import Iterator
from pathlib import Path
from polisyos.foundry.methods.base import FoundryMethod, MethodMetadata, MethodSignature, _stable_digest
from polisyos.foundry.methods.lifecycle import LifecycleLog
from polisyos.foundry.methods.selection import registry as canonical_registry
assert_type(_stable_digest({}), str)
import polisyos.foundry.methods.base as owner_0
assert_type(owner_0.FidelityLevel.LOW, Literal[owner_0.FidelityLevel.LOW])
value_0: int = owner_0.FidelityLevel.LOW.value
literal_0: Literal[1] = owner_0.FidelityLevel.LOW.value
assert_type(owner_0.FidelityLevel.MEDIUM, Literal[owner_0.FidelityLevel.MEDIUM])
value_1: int = owner_0.FidelityLevel.MEDIUM.value
literal_1: Literal[2] = owner_0.FidelityLevel.MEDIUM.value
assert_type(owner_0.FidelityLevel.HIGH, Literal[owner_0.FidelityLevel.HIGH])
value_2: int = owner_0.FidelityLevel.HIGH.value
literal_2: Literal[3] = owner_0.FidelityLevel.HIGH.value
assert_type(owner_0.ComplexityClass.O_1, Literal[owner_0.ComplexityClass.O_1])
value_3: int = owner_0.ComplexityClass.O_1.value
literal_3: Literal[1] = owner_0.ComplexityClass.O_1.value
assert_type(owner_0.ComplexityClass.O_LOG_N, Literal[owner_0.ComplexityClass.O_LOG_N])
value_4: int = owner_0.ComplexityClass.O_LOG_N.value
literal_4: Literal[2] = owner_0.ComplexityClass.O_LOG_N.value
assert_type(owner_0.ComplexityClass.O_N, Literal[owner_0.ComplexityClass.O_N])
value_5: int = owner_0.ComplexityClass.O_N.value
literal_5: Literal[3] = owner_0.ComplexityClass.O_N.value
assert_type(owner_0.ComplexityClass.O_N2, Literal[owner_0.ComplexityClass.O_N2])
value_6: int = owner_0.ComplexityClass.O_N2.value
literal_6: Literal[4] = owner_0.ComplexityClass.O_N2.value
assert_type(owner_0.ComplexityClass.O_N3, Literal[owner_0.ComplexityClass.O_N3])
value_7: int = owner_0.ComplexityClass.O_N3.value
literal_7: Literal[5] = owner_0.ComplexityClass.O_N3.value
assert_type(owner_0.ComplexityClass.O_EXP, Literal[owner_0.ComplexityClass.O_EXP])
value_8: int = owner_0.ComplexityClass.O_EXP.value
literal_8: Literal[6] = owner_0.ComplexityClass.O_EXP.value
assert_type(owner_0.SlotType.SCALAR, Literal[owner_0.SlotType.SCALAR])
value_9: int = owner_0.SlotType.SCALAR.value
literal_9: Literal[1] = owner_0.SlotType.SCALAR.value
assert_type(owner_0.SlotType.VECTOR, Literal[owner_0.SlotType.VECTOR])
value_10: int = owner_0.SlotType.VECTOR.value
literal_10: Literal[2] = owner_0.SlotType.VECTOR.value
assert_type(owner_0.SlotType.MATRIX, Literal[owner_0.SlotType.MATRIX])
value_11: int = owner_0.SlotType.MATRIX.value
literal_11: Literal[3] = owner_0.SlotType.MATRIX.value
assert_type(owner_0.SlotType.TENSOR, Literal[owner_0.SlotType.TENSOR])
value_12: int = owner_0.SlotType.TENSOR.value
literal_12: Literal[4] = owner_0.SlotType.TENSOR.value
assert_type(owner_0.ComputeBackend.JAX, Literal[owner_0.ComputeBackend.JAX])
value_13: str = owner_0.ComputeBackend.JAX.value
literal_13: Literal['jax'] = owner_0.ComputeBackend.JAX.value
assert_type(owner_0.ComputeBackend.NUMPY, Literal[owner_0.ComputeBackend.NUMPY])
value_14: str = owner_0.ComputeBackend.NUMPY.value
literal_14: Literal['numpy'] = owner_0.ComputeBackend.NUMPY.value
assert_type(owner_0.ComputeBackend.SOLVER, Literal[owner_0.ComputeBackend.SOLVER])
value_15: str = owner_0.ComputeBackend.SOLVER.value
literal_15: Literal['solver'] = owner_0.ComputeBackend.SOLVER.value
assert_type(owner_0.ComputeBackend.BAYESIAN, Literal[owner_0.ComputeBackend.BAYESIAN])
value_16: str = owner_0.ComputeBackend.BAYESIAN.value
literal_16: Literal['bayesian'] = owner_0.ComputeBackend.BAYESIAN.value
assert_type(owner_0.MethodKind.PURE, Literal[owner_0.MethodKind.PURE])
value_17: str = owner_0.MethodKind.PURE.value
literal_17: Literal['pure'] = owner_0.MethodKind.PURE.value
assert_type(owner_0.MethodKind.MECHANISM, Literal[owner_0.MethodKind.MECHANISM])
value_18: str = owner_0.MethodKind.MECHANISM.value
literal_18: Literal['mechanism'] = owner_0.MethodKind.MECHANISM.value
assert_type(owner_0.MethodKind.SIMULATION, Literal[owner_0.MethodKind.SIMULATION])
value_19: str = owner_0.MethodKind.SIMULATION.value
literal_19: Literal['simulation'] = owner_0.MethodKind.SIMULATION.value
assert_type(owner_0.SideEffectProfile.NONE, Literal[owner_0.SideEffectProfile.NONE])
value_20: str = owner_0.SideEffectProfile.NONE.value
literal_20: Literal['none'] = owner_0.SideEffectProfile.NONE.value
assert_type(owner_0.SideEffectProfile.PATCH_EMISSION, Literal[owner_0.SideEffectProfile.PATCH_EMISSION])
value_21: str = owner_0.SideEffectProfile.PATCH_EMISSION.value
literal_21: Literal['patch_emission'] = owner_0.SideEffectProfile.PATCH_EMISSION.value
assert_type(owner_0.SideEffectProfile.ARTIFACT_EMISSION, Literal[owner_0.SideEffectProfile.ARTIFACT_EMISSION])
value_22: str = owner_0.SideEffectProfile.ARTIFACT_EMISSION.value
literal_22: Literal['artifact_emission'] = owner_0.SideEffectProfile.ARTIFACT_EMISSION.value
assert_type(owner_0.SideEffectProfile.TRAINING, Literal[owner_0.SideEffectProfile.TRAINING])
value_23: str = owner_0.SideEffectProfile.TRAINING.value
literal_23: Literal['training'] = owner_0.SideEffectProfile.TRAINING.value
import polisyos.foundry.methods.registry as owner_1
owner_1.MethodEntry
owner_1.MethodLifecycle
owner_1.MethodRegistry
owner_1.RegistryAuditEvent
owner_1.RegistryAuditLog
owner_1.RegistrySnapshot
owner_1.RegistrySnapshotEntry
owner_1.get_registry
owner_1.get_registry_audit_log
owner_1.registry_scope
import polisyos.foundry.methods.composer as owner_2
owner_2.CompiledMethodChain
owner_2.CompositionDAG
owner_2.MethodComposer
owner_2.MethodNode
owner_2.SemanticValidationLevel
owner_2.ValidationContext
owner_2.reconcile_validation_context
import polisyos.foundry.methods.components.composer as owner_3
owner_3.CompiledMethodChain
owner_3.CompositionDAG
owner_3.MethodComposer
owner_3.MethodNode
owner_3.SemanticValidationLevel
owner_3.ValidationContext
owner_3.reconcile_validation_context
assert_type(owner_3.SemanticValidationLevel.OFF, Literal[owner_3.SemanticValidationLevel.OFF])
value_24: str = owner_3.SemanticValidationLevel.OFF.value
literal_24: Literal['off'] = owner_3.SemanticValidationLevel.OFF.value
assert_type(owner_3.SemanticValidationLevel.WARN, Literal[owner_3.SemanticValidationLevel.WARN])
value_25: str = owner_3.SemanticValidationLevel.WARN.value
literal_25: Literal['warn'] = owner_3.SemanticValidationLevel.WARN.value
assert_type(owner_3.SemanticValidationLevel.STRICT, Literal[owner_3.SemanticValidationLevel.STRICT])
value_26: str = owner_3.SemanticValidationLevel.STRICT.value
literal_26: Literal['strict'] = owner_3.SemanticValidationLevel.STRICT.value
import polisyos.foundry.methods.selection.registry as owner_4
owner_4.MethodEntry
owner_4.MethodLifecycle
owner_4.MethodRegistry
owner_4.RegistryAuditEvent
owner_4.RegistryAuditLog
owner_4.RegistrySnapshot
owner_4.RegistrySnapshotEntry
owner_4.get_registry
owner_4.get_registry_audit_log
owner_4.registry_scope
def registry_consumer(registry: canonical_registry.MethodRegistry, signature: MethodSignature, metadata: MethodMetadata, factory: canonical_registry.MethodFactory, lifecycle: LifecycleLog) -> None:
    assert_type(registry.get(signature.fqn), type[FoundryMethod[Any, Any]])
    assert_type(registry.list_all(), list[MethodSignature])
    assert_type(registry.snapshot().entries(), Iterator[canonical_registry.RegistrySnapshotEntry])
    entry = canonical_registry.MethodEntry(signature=signature, metadata=metadata, factory=factory, loaded=False, lifecycle_log=lifecycle)
    assert_type(entry.fqn, str)
    assert_type(canonical_registry.RegistrySnapshotEntry.from_entry(entry), canonical_registry.RegistrySnapshotEntry)
    audit = canonical_registry.RegistryAuditLog()
    audit.export_jsonl(Path('static-only.jsonl'))
    audit.export_jsonl('static-only.jsonl')
    assert_type(audit.get_history(), list[canonical_registry.RegistryAuditEvent])
    with registry.snapshot_scope() as snapshot:
        assert_type(snapshot, canonical_registry.RegistrySnapshot)
    with canonical_registry.registry_scope() as scoped:
        assert_type(scoped, canonical_registry.MethodRegistry)
def specialized_registry_consumer(registry: canonical_registry.MethodRegistry, method: type[FoundryMethod[int, dict[str, int]]]) -> None:
    registry.register(method)
