from polisyos.foundry.methods.base import MethodSignature
from polisyos.foundry.methods.compiler import MethodCompiler
from polisyos.foundry.methods.compiler.specialization import Specialization

class WrongStep:
    @staticmethod
    def pure_step(state: str) -> str:
        return state

def witness(compiler: MethodCompiler, signature: MethodSignature,
            specialization: Specialization) -> None:
    compiler._compile_method(WrongStep, signature, specialization, {}, {}, (), False, False, None, ())
