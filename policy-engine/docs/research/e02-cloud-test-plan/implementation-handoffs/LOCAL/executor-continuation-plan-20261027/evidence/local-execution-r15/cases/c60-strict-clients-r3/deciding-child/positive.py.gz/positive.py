from collections.abc import Mapping
from typing import Any, ClassVar, assert_type
from polisyos.foundry.methods.base import FoundryMethod, MethodMetadata, MethodSignature
from polisyos.foundry.methods.compiler import FoundryMethodProtocol, MethodCompiler
from polisyos.foundry.methods.compiler.specialization import Specialization
from polisyos.foundry.methods.selection.registry import MethodRegistry

class SpecializedRegistered:
    signature: ClassVar[MethodSignature]
    metadata: ClassVar[MethodMetadata]

    @staticmethod
    def pure_step(state: int, params: dict[str, int]) -> int:
        return state + params["delta"]

    @staticmethod
    def materialize_input(bound_inputs: Mapping[str, Any], fallback_state: Any) -> Any:
        return bound_inputs if bound_inputs else fallback_state

    @staticmethod
    def dematerialize_output(output: Any) -> Mapping[str, Any]:
        return {"value": output}

class LegacyStructural:
    signature: MethodSignature

    @staticmethod
    def pure_step(state: Any, params: Mapping[str, Any]) -> Any:
        return state

def witness(registry: MethodRegistry, compiler: MethodCompiler, signature: MethodSignature,
            specialization: Specialization) -> None:
    registry.register(SpecializedRegistered)
    registered = registry.get(signature.fqn)
    assert_type(registered, type[FoundryMethod[Any, Any]])
    legacy: type[FoundryMethodProtocol] = LegacyStructural
    compiler._compile_method(registered, signature, specialization, {}, {}, (), False, False, None, ())
    compiler._compile_method(legacy, signature, specialization, {}, {}, (), False, False, None, ())
