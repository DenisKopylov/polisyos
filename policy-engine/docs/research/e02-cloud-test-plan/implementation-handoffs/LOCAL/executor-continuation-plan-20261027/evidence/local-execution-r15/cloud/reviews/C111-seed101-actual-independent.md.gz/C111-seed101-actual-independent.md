# C111 actual seed-101 return — independent qualification review

**Overall disposition: HOLD / ERROR-UNRUN for R11-qualified acceptance.** The actual three raw pytest outcomes and the typed CAS / producer-mutation evidence are present. The mandatory per-phase loaded-source/readset reconciliation is explicitly `not_established`; do not promote these raw outcomes to a complete R11 source-qualified witness. `closure_ids=[]`; no G acceptance or product failure is inferred. No tests, imports, or reruns were performed during this review.

## Return integrity and source scope

- Retrieved `source.diff`: 158,372 bytes, SHA-256 `672c8b5eaa9378182f17e366a6b7767d58810f835a35b1c1817c6651a5b7c3fe`; base R11 commit/tree `b349e5c17351b160ff39a8c23c1759a2c522f81f` / `2d297ee70ea7eaee0d4c833b8daa634750f499e5`; candidate tree `dac9c9118b1a8ced981f615f6d1801bf5e466173`.
- Candidate manifest: `LOCAL/raw/e02-execution-20261027/cloud/C111/candidate-manifest.json`, SHA-256 `079fae2b6b1ee63dca3815e1c2b14cee8f589ea26f38044ef7d1e7ccf0156816`. It lists 44 new files and no deletions. The R11→candidate Git tree diff is exactly those 44 additions; there are no product source or existing test-file edits. The only source addition is `policy-engine/tests/observers/c109_seed101_identity.py`.
- I verified all 43 separate delivered files against manifest SHA-256/byte size, verified the 42 entries in `checksums.sha256`, and extracted the observer from the actual patch to compare byte-for-byte with approved R3/R6 source SHA-256 `3816243c7590986d6c4cc412155eb282c77164ba7f633f327feb63e908b3dc07`. The 44th file is that observer, carried in `source.diff`; its phase events report the same hash and 9,927 bytes. The candidate tree object is present, and the diff is below the 524,288-byte task target.
- R11 source admission independently matched all 43 declared Git-object pins and corresponding working bytes. Commit/tree match the commission. Remote-tip confirmation was unavailable because the checkout has no `origin`; it is recorded as a setup limit, not a product failure. The R11 publication-readback digest matches the coordinator receipt.

## Per-phase witness qualification

| Witness | Raw result and deciding evidence | R11-qualified status |
|---|---|---|
| Initial seed-101 positive / CAS identity | PASS, PID 5815, exit 0, 39.951566 s. One typed `TreasuryPlan`; ArtifactRef `sha256:7ed46f17503d67fb1e8061221bfa5d8e9de08cfbff032878645258c430e66c24`, 428-byte payload with matching manifest integrity; target setup/call/teardown all passed. | HOLD: actual per-phase loaded-origin set is missing. |
| Producer-only removal / actual consumer red | Expected raw FAIL, PID 5875, exit 1, 37.213308 s. The event records the actual compiler global, exact target, a full plan before/after, and `changed_fields=["node_salts"]`; root seed 17, stream salts, schema and notes remain the same. The actual public consumer raised `ValueError: treasury_seed_or_salts_mismatch`; JUnit reports one failure, not a harness error. Persisted artifact is `sha256:08a9c6d2c856ce0edf3991bd157760739bb1f5375fc07742f1c2036574a047b9`, 260 bytes, with matching manifest integrity. | HOLD: mutation and intended red are evidenced, but actual per-phase loaded-origin set is missing. |
| Restored seed-101 positive / identity | PASS, PID 5933, exit 0, 39.151992 s. One typed `TreasuryPlan`; full ArtifactRef and payload identity equal initial; payload is 428 bytes with matching manifest integrity; target setup/call/teardown all passed. | HOLD: actual per-phase loaded-origin set is missing. |

All three phases use the exact `[101]` selector. Initial and restored ArtifactRef equality is separately reported from content equality; both are true in this return. Each identity event has exactly one TreasuryPlan record and no harness errors. The real CAS bytes and manifest were read immediately after `put_json` while the temporary CAS existed. The full manifests bind `polisyos.foundry.TreasuryPlan` schema 1.0 to the same program-graph input. The raw removal FAIL is the intended semantic negative, not a product failure.

## Blocking evidence gap

The observer records CAS identity, mutation and pytest reports, but not `sys.modules` origins or a phase readset. `python -B` left the pycache directories empty, so the return contains no alternative origin trace. Each `identity.json` marks readset reconciliation `not_established`; `summary.json` and `REPORT.md` correctly classify current-source acceptance as `ERROR/UNRUN`.

Consequently, this evidence cannot say which of the 13 historical R10→R11 changed origins were loaded by each R11 phase, including whether the changed C60 intersection path `foundry/methods/compiler/__init__.py` appeared in this exact selector’s runtime. The 43 pin admission proves the named bytes, not the complete loaded-origin set. Do not infer presence or absence from the R10 readsets or promote any C60 result.

The three initial setup attempts using the global Python failed at pytest plugin import because `pydantic` was absent; they are setup `ERROR/UNRUN`, not product failures. The recorded final phase commands used the existing project `.venv` and completed. Resources were adequate (about 29.0 GB free disk, 17.7 GB available RAM, 3 CPUs, planned one numerical thread). Environment profile reports Python 3.14.4, pytest 9.0.2, JAX/JAXlib 0.8.2 on CPU with x64 disabled; phase commands explicitly set OMP/OpenBLAS/MKL thread variables to 1. No source mismatch was reported for the 43 admitted pins.

## Historical evidence and minimum next result

The earlier independent C109-R1 review remains bounded to R10 commit/tree `870855f3ca83fcb32d4bb91d00d34daab3151032` / `18a3178510405de4fcd8e6ce7dbc8b3d77932633`: six initial positives, six restored positives, and one wrong-node-salt adversary, with eight reconciled readsets and 983 first-party Python origins. That evidence is supported by `C109-r1-actual-independent.md` SHA-256 `448b24129196d3b53b14e2c73c4d410ff80d01f7e19fbff51c255311f31785dd`; it remains historical and is not upgraded to R11 by this return.

**P40 bucket:** new sub-gap in the evidence-provenance family — current-phase loaded-origin capture is absent. The exact seed-101 identity and mutation artifacts now exist; the missing capability is an in-process per-phase origin/readset recorder with byte reconciliation. The current commission authorizes no fourth run, so the minimum next result here is to preserve these raw outcomes as partial evidence, retain `verification_missing`, and leave R11 acceptance `ERROR/UNRUN`. No further execution or source change is proposed by this review.
