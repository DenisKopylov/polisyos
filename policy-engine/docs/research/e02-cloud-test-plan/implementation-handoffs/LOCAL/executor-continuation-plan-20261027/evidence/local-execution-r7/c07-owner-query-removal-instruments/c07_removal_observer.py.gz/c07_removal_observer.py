"""Observe the reviewed C07 removal control and restore it inside the test process."""

from __future__ import annotations

import hashlib
import importlib
import importlib.util
import inspect
import json
import marshal
import os
import threading
from pathlib import Path
from types import CodeType
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Callable

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
D = ROOT / (
    "policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/"
    "root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/"
    "deep-task-status-audit-20261027-r1"
)
OWNER = ROOT / "policy-engine/src/polisyos/core/artifacts/ownership.py"
TEST = ROOT / "policy-engine/tests/unit/core/artifacts/test_cas_owner_snapshot_query.py"
ORIGINAL_PLUGIN = ROOT / (
    "LOCAL/raw/e02-execution-20261027/repairs/C07-CAS-owner-dedup-r1/remove_snapshot_query.py"
)
OWNER_SHA = "ba56a58da7f9929d33384e71e8c3bf8877a64775b0a7e3c69deed5f991ec0ce7"
TEST_SHA = "7335f1be5372e0b47e67c99a4d95458f86204e07bdcdcd2774ff401a40b93de0"
PLUGIN_SHA = "3e6cc0fc5881b94a30739f0d734ec139f812f5bca906603f94621deb4afd8bbe"
_STATE: dict[str, object] = {}
_COUNTS = {"total": 0, "blob_readers_true": 0, "blob_readers_false": 0}
_COUNT_LOCK = threading.Lock()


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _describe(fn: Callable[..., object]) -> dict[str, str]:
    code = getattr(fn, "__code__", None)
    source = inspect.getsourcefile(fn)
    if not isinstance(code, CodeType) or source is None:
        raise RuntimeError("c07_removal_missing_function_identity")
    return {
        "identity": hex(id(fn)),
        "code_sha256": hashlib.sha256(marshal.dumps(code)).hexdigest(),
        "source": str(Path(source).resolve()),
        "module": fn.__module__,
        "qualname": fn.__qualname__,
    }


def _check_inputs() -> dict[str, str]:
    paths = {"owner": OWNER, "test": TEST, "original_plugin": ORIGINAL_PLUGIN}
    actual = {name: _sha(path) for name, path in paths.items()}
    if actual != {"owner": OWNER_SHA, "test": TEST_SHA, "original_plugin": PLUGIN_SHA}:
        raise RuntimeError("c07_removal_source_identity_mismatch")
    expected_wrapper = os.environ.get("POLISYOS_C07_WRAPPER_SHA256")
    if not expected_wrapper or _sha(Path(__file__).resolve()) != expected_wrapper:
        raise RuntimeError("c07_removal_wrapper_identity_mismatch")
    actual["wrapper"] = expected_wrapper
    return actual


def pytest_configure(config: object) -> None:
    """Install only the pinned original removal and a call-through observer."""
    if _STATE:
        raise RuntimeError("c07_removal_already_configured")
    input_hashes = _check_inputs()
    out_raw = os.environ.get("POLISYOS_C07_REMOVAL_OUTPUT")
    out = Path(out_raw) if out_raw else None
    if out is None or not out.is_absolute() or out.parent != D or not out.is_dir():
        raise RuntimeError("c07_removal_output_identity_missing")
    if not out.name.startswith("c07-owner-query-removal-mutant-"):
        raise RuntimeError("c07_removal_output_identity_mismatch")

    owner = importlib.import_module("polisyos.core.artifacts.ownership")
    if Path(owner.__file__).resolve() != OWNER:
        raise RuntimeError("c07_removal_loaded_owner_mismatch")
    cls = owner.ArtifactOwnershipIndex
    original = cls._claim_rows_for_query
    before = _describe(original)
    if (
        before["source"] != str(OWNER)
        or before["module"] != "polisyos.core.artifacts.ownership"
        or before["qualname"] != "ArtifactOwnershipIndex._claim_rows_for_query"
    ):
        raise RuntimeError("c07_removal_original_identity_mismatch")

    spec = importlib.util.spec_from_file_location("c07_existing_removal_control", ORIGINAL_PLUGIN)
    if spec is None or spec.loader is None:
        raise RuntimeError("c07_removal_plugin_loader_missing")
    plugin = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(plugin)
    plugin.pytest_configure(config)
    mutant = cls._claim_rows_for_query
    mutant_description = _describe(mutant)
    if (
        mutant is original
        or mutant_description["source"] != str(ORIGINAL_PLUGIN)
        or mutant_description["module"] != "c07_existing_removal_control"
        or mutant_description["qualname"] != "pytest_configure.<locals>.original_full_index_path"
    ):
        raise RuntimeError("c07_removal_mutant_identity_mismatch")

    def observed(self: object, artifact_id: object, *, blob_readers: bool) -> object:
        with _COUNT_LOCK:
            _COUNTS["total"] += 1
            _COUNTS["blob_readers_true" if blob_readers else "blob_readers_false"] += 1
        return mutant(self, artifact_id, blob_readers=blob_readers)

    cls._claim_rows_for_query = observed
    if cls._claim_rows_for_query is not observed:
        raise RuntimeError("c07_removal_observer_identity_mismatch")
    _STATE.update(
        {
            "class": cls,
            "original": original,
            "mutant": mutant,
            "observed": observed,
            "before": before,
            "mutant_description": mutant_description,
            "observer_description": _describe(observed),
            "input_hashes": input_hashes,
            "output": out,
        }
    )


def pytest_unconfigure(config: object) -> None:
    """Restore the exact saved method and retain an auditable identity receipt."""
    del config
    if not _STATE:
        raise RuntimeError("c07_removal_setup_identity_missing")
    cls = _STATE["class"]
    original = _STATE["original"]
    observed = _STATE["observed"]
    active_was_observer = cls._claim_rows_for_query is observed
    cls._claim_rows_for_query = original
    restored = cls._claim_rows_for_query
    restored_description = _describe(restored)
    input_hashes_after = _check_inputs()
    with _COUNT_LOCK:
        counts = dict(_COUNTS)
    receipt = {
        "scope": (
            "Actual calls to the replaced private owner-row method in this process; "
            "not a count of independent artifact edges or authorization decisions."
        ),
        "before": _STATE["before"],
        "mutant": _STATE["mutant_description"],
        "observer": _STATE["observer_description"],
        "restored": restored_description,
        "active_was_observer": active_was_observer,
        "restored_same_object": restored is original,
        "restored_same_code_hash": (
            restored_description["code_sha256"] == _STATE["before"]["code_sha256"]
        ),
        "input_hashes_before": _STATE["input_hashes"],
        "input_hashes_after": input_hashes_after,
        "invocations": counts,
        "closure_ids": [],
    }
    receipt_path = _STATE["output"] / "c07-removal-observer.json"
    with receipt_path.open("x", encoding="utf-8") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    if (
        not active_was_observer
        or restored is not original
        or not receipt["restored_same_code_hash"]
        or input_hashes_after != _STATE["input_hashes"]
        or counts["total"] <= 0
        or counts["total"] != counts["blob_readers_true"] + counts["blob_readers_false"]
    ):
        raise RuntimeError("c07_removal_identity_or_invocation_invalid")
