# C64 independent source and delivered-evidence review

Verdict: **GO for retaining/composing the narrow exact `MetricsRef` implementation as bounded work; HOLD for the complete C64/BKT capability and runtime qualification.** No runtime PASS or G acceptance is assigned. This review ran no product imports, tests or backend, and changed only these two review files under the assigned RAW lease. `closure_ids=[]`.

## Exact admitted source and complete returned set

The launch prompt is SHA-256 `ea5fda85ea2135a1fdaa931df4372c5b07c0aedc8bf0e66ae05c8a42c6e3c526`. Every one of its **73 unique pins** was checked from base `caa91a64d7d6afc4310186ba5fadbac2008dddab`, tree `730308224f7f1bb0d49b60c3fdb5929d791e6ebd`: 52 `.py`, 13 `.md`, 4 `.json`, and one each `.gz`, `.ini`, `.lock`, `.toml`. All matched size, SHA-256 and Git blob. All **10 original criterion spans** were rehashed from `B_r19_original.md` at that base, preserving occurrence and Q0/S1 pointers.

Received `cloud/C64/source.diff` is 35,858 bytes, SHA-256 `0e74d53032ce12ee01b00ce1ddcfa76a934f9727af1c9c1c3df2de9744b43e41`. Independently applying its six textual hunk sets **in memory** to exact base bytes reproduces every candidate postimage. The tree is `3b9fd32bf2de786d5ce34c9a5821350b333909d0`; this is a reconstructed delivered-source tree, **not an attested cloud final commit**. A regenerated default-context Git diff has different formatting/length; all received hunk postimages nonetheless agree exactly. The manifest and this review JSON give the complete six-path blob/hash/size set.

The six files are the orchestrator, its new helper-level regression in `test_backtesting.py`, two C36 seed tests, the receipt, and one Foundry failure output. Both seed tests were independently extracted from the published C36 gzip and are byte-identical to returned files: fresh-report SHA `e1168a7e63e1e95f2e676bd922bc3a1f10b0dd4e5e6d2679d0819a35ac1dbd99`, bootstrap SHA `282b4a86edc145d9f48223f23712656faea6c68549fb3f4b795e84981276151c`. Deduplicate them; neither is a newly authored C64 capability. No CV/bootstrap source or test writer authority was exercised.

Observed root at review: attached `codex/e02-unified-local-20261009`, HEAD `67beb3461ab96c4cb64b92226228da39b30bcb06`, tree `306e3c150f6a1368f23c8ebece35aeec3feb180b`. Its two changed tracked owner/test preimages still equal the C64 base; four added paths are absent. Root can advance normally; refresh these specific preimages before composition. No index/HEAD/ref mutation was performed. Cloud final commit/tree/model/Fast identity was not provided and is not invented.

## Useful source change and its boundary

`orchestrator.py:960–975` now reconstructs the already validated full `MetricsRef` and passes it to both `load_core_json_artifact` and `_is_constant_forecast`. The helper at `:1216` resolves the selected manifest digest through existing `resolve_manifest_by_profile`; that existing owner validates digest, selected artifact identity and actual CAS bytes. Legacy profileless ID fallback is retained. Existing `CoreToIRArtifactStoreAdapter` exposes the needed profile resolution and selected get-bytes path. No new public signature/DTO/schema/registry/generator/lock mechanism is introduced. The source change closes the identified local profile-loss seam without creating another artifact mechanism.

The larger contract remains bounded. `ForecastProfileContract` validates a constant label, producer identity, horizon and a unique time-index of that length; current admission compares producer and horizon, not requested subject/unit or actual coordinate equality. Do not call selected manifest identity a proof of those relations. Actual producer → `SimulationResult` → metrics pairing exists earlier in `_predict_with_scientist`; the new test does not traverse it.

`load_backtest_report` delegates the full typed ref to IR owned admission, validating representation/profile. It returns a report value; it does not return an independently reconciled history/lineage admission receipt. The unchanged fresh-CAS seed exercises a useful PROVIDED value round trip with a stable returned ref; its current run is author-reported only, and it supplies no competing selected report profile or runtime observer of the consumed view. Do not turn a later `get_manifest` lookup or equal ID into that stronger consumer claim.

## Classified findings and minimum repair

### C64-R1 — high: verification_gap

Bucket: same P29/P38 actual-consumer proof class, deeper boundary. Pointers: policy-engine/tests/unit/scientist/methods/backtesting/test_backtesting.py:270, policy-engine/src/polisyos/scientist/methods/backtesting/orchestrator.py:960.

Property: The completed single-run Scientist consumer must use the selected MetricsRef for both bytes and producer-bound constant-trajectory admission.

Calls only _is_constant_forecast(payload, selected_ref, 3); does not run _predict_with_scientist, selected metrics load, SimulationResult pairing or fresh report.

Distinguishing case: Keep the new helper and its test, restore only caller conversion to ArtifactID at the selected content/validation seam: this new test has no call to that branch and cannot guard it. This is source dependency reasoning, not an executed mutant.

Next: Use real supported single-run route or current typed admitted fake Foundry, same payload/different selected producer views, actual selected content-read observation delegated to owner, persisted fresh report/refusal. Freeze red/witness; run both caller and helper selector removals and restored positive.

### C64-R2 — high: incomplete_route

Bucket: same P01/P02/P38 execution-chain gap. Pointers: policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/Q0/cloud/e02-c64-backtesting-20261028-r1/outputs/foundry-replicas.txt, policy-engine/tests/unit/remediation/test_bkt_02.py:330.

Property: Actual masked Foundry requests and owner-admitted interval reach real consumers, with source-bound failure diagnostics.

Delivered Foundry file contains FFF.. and three assertion failures; no first failed node, cohort failure payload, warning, selected binding/profile or concrete backend cause. BKT02 source fake accepts only one positional state and returns no current reports/admission chain. No corrected fixture was delivered.

Next: One bounded first-positive route diagnostic captures selected cohort/workflow ref, first failed node/error/warnings, then fix only demonstrated in-lease cause or give shared-owner reproduction. Repair BKT02 fixture against real typed admission before interpreting nominal/metadata assertions. Distinct requests are not statistical independence and >1 remains explicit unsupported projection.

### C64-R3 — medium: evidence_gap

Bucket: same P14/P30/P41 evidence/source-binding class. Pointers: policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/Q0/cloud/e02-c64-backtesting-20261028-r1/receipt.md.

PASS20 and BKT02 13 PASS/4 FAIL exist only as receipt prose. No full positive output, collection/JUnit, exit record, backend versions, removal/restoration bytes or run-specific final source binding. Foundry output bytes are delivered, but no exact-base output or complete input-denominator nonintersection establishes inherited red. Changed orchestrator.py is in that test input set.

Next: Correct inherited classification to not_established; retain author reports without promoting them to PASS. Recover compact existing deciding bytes if available, otherwise repeat only selected missing checks after composition. No blanket local/cloud rerun.

### C64-R4 — medium: source_residual_not_introduced_here

Bucket: same P02/P31 persisted-chain class, deeper exit. Pointers: policy-engine/src/polisyos/scientist/methods/backtesting/orchestrator.py:1005, policy-engine/src/polisyos/scientist/methods/backtesting/orchestrator.py:581, policy-engine/src/polisyos/scientist/methods/backtesting/orchestrator.py:526.

Property: Every post-execution diagnostic result retains the already persisted cohort and complete requested denominator through report lineage.

After cohort persistence, completed single-run metrics/profile/shape refusal reaches scientist_predictions_missing. That branch builds a separate naive result without replica_cohort_ref; _run_single_scenario adds cohort only when present and run_with_ref links it only from scenario metadata.

Distinguishing case: One completed physical run whose scalar has an incompatible selected producer or whose list has wrong horizon: report is degraded but loses the durable cohort edge/denominator; on the default path without a caller-supplied cohort input, the cohort remains as unattached CAS bytes. This is source-observed conditional path, runtime UNRUN.

Next: Reuse _naive_with_cohort for every post-cohort fallback, preserving warnings/reasons and any necessary interval limitations. Test fresh report/ref lineage for accepted and rejected metrics; remove edge but keep labels and require oracle failure. No new subsystem.

### C64-R5 — medium: delivery_companion

Bucket: same P39 mandatory-companion completeness. Pointers: policy-engine/src/polisyos/scientist/methods/backtesting/README.md, policy-engine/release-fragments/unreleased/.

Six-file return contains no public behavior documentation/release fragment. No public signature/DTO/schema/generator/lock change is introduced by private helper extension, so wholesale generated regeneration is not required. Selected forecast admission is compatibility-sensitive/operator-visible behavior; CONTRIBUTING.md:210 requires a fragment. README selected-profile section currently documents ForecastOwner, not this Scientist MetricsRef boundary.

Next: Add small accurate selected-MetricsRef behavior/legacy default and limitations documentation and ordinary release fragment on composition; retain independent review/author/runtime distinctions.

### C64-R6 — medium: current typed interval-to-trajectory bridge is not established

Bucket: the same P01/P02/P38 actual typed-bridge class, an explicit residual rather than another instance repair. Candidate `orchestrator.py:1091–1124` consumes `admission.envelope.model_dump()`. The canonical `UncertaintyEnvelope` (`ir/analytics/uncertainty.py:1378`) is `extra="forbid"`, has one `confidence_interval`, and has no top-level `confidence_intervals`, `forecast_profile` or `forecast_contract`. Thus a genuine admitted envelope cannot satisfy the current top-level constant-forecast predicate for a horizon greater than one. The remaining `env_id` conversion does lose the selected ref, but that profile-dependent helper body is not reached without the absent forecast label; blindly updating the ID is not a demonstrated interval repair.

Minimum next result: repair BKT02 first with an actual admitted **one-period** .80 envelope versus a .95 plan, retaining real source/provenance controls. This proves nominal propagation without multiplying one interval into a trajectory. For multiple periods retain explicit unsupported/`bridge_missing` unless the real existing typed predictive source supports the adapter; inspect/reuse `ForecastOwner` and its actual temporal/uncertainty artifacts before building anything. A shared envelope/schema change requires its canonical owner. Do not bypass admission, invent top-level fields or infer joint/time semantics from a marginal interval. This source limitation predates C64 and does not overturn its narrow selected-MetricsRef source GO.

## Actual evidence availability

- **Author-reported PASS20 only:** focused new helper test + `test_bkt_03.py` + three fresh-report seed cases. Complete stdout/stderr, exact collection/JUnit, exit and run-specific backend/source/input identities were not among the six returned files. Source contains the expected existing bias/SciPy discriminators, but that is not runtime PASS.
- **Delivered assertion FAIL:** `cloud/C64/delivered/Q0/cloud/e02-c64-backtesting-20261028-r1/outputs/foundry-replicas.txt`, 8,320 bytes, SHA-256 `3440209a0a91679e2713052fc9ad1788ef9b5fec9d708f11db18d64ee8ec36f8`. It contains `FFF..`, three failure traces and `real 0m30.785s`: two positives captured 0 expected 3 delegate calls, third expected `workflow_status='fail'` but got `None`. Five top-level cases exist in the exact source module. The two successful dots are not identified by name in this output. Exit code, full selected/JUnit record and actual backend/input/profile/source-at-execution are not present. No concrete first-node error/cohort diagnostic is delivered. Missing backend, OOM, Foundry owner defect and inherited red are **not established**.
- **Author-reported BKT02 13 PASS/4 FAIL only:** exact command is in the receipt; full output is absent. Source shows the stale fake API and incomplete current workflow/admission fixture, but the actual exception/warning was not independently observed. Changing only `lambda _state` to accept kwargs cannot establish the intended envelope property.
- **Removal and restored-positive evidence:** UNRUN/unavailable; no mutant hashes, deciding output or restoration bytes are included.
- Receipt bytes are actually delivered: 4,409 bytes, SHA-256 `4d11019cfa784a1362fd0835a9166a3700168d440a715f84c20bd6943d244c2a`. These and the Foundry output equal their candidate blobs. Successful transport of them does not deliver the missing positive outputs.

Recover compact existing outputs first if they remain accessible. Otherwise repeat only the exact bounded missing check after source/input/backend freeze; do not rerun all cloud computations. Before a costly real route, solve actual output delivery. No CAS, database, environment or source copy is requested.

## Complete original occurrence disposition

This table is the full admitted C64 BKT occurrence set: eight Q0 plus two S1, not ten closures or independent capabilities. All historical G bounded decisions and B198 remain unchanged.

| Occurrence / row | Exact criterion pointer | Current evidence and source boundary | Minimum next result |
|---|---|---|---|
| B166@BKT-01 / Q0 | `#/findings/82/criterion_refs/0` | Existing target/time mask, selected snapshot and request wrapper are source-visible. Delivered real-route positive reaches zero of three delegate calls. **verification_missing; non-target temporal binding remains unqualified.** | Diagnose first workflow failure on one exact selected real route, reach delegated execute, inspect actual masked bound state; then supported non-target/derived-channel sentinel and removal. |
| B167@BKT-02 / Q0 | `#/findings/83/criterion_refs/0` | Unchanged C36 PROVIDED test persists/fresh-loads missing address 1 and trust refusal versus complete exact A; author PASS only. **verification_missing for selected lineage and requested-address removal.** | Keep seed once; prove same-ID selected report consumer and remove actual hard requested cell without removing labels; retain deciding output. |
| B168@BKT-02 / Q0 | `#/findings/84/criterion_refs/0` | Unchanged PROVIDED seed covers .80, unknown interval and 2/1/1/0. Scientist envelope fixture is still old lambda without keyword/report/typed admission ABI. **verification_missing; actual admitted-envelope bridge not established.** | Reuse current typed fake Foundry plus PropagateUncertaintyNode admission, capture semantic witness before product edit, .80 versus plan .95 and incompatible/missing provenance controls. |
| B169@BKT-01 / Q0 | `#/findings/85/criterion_refs/0` | Narrow source repair retains exact MetricsRef for content read and producer lookup. New same-ID test only exercises helper. **verification_missing; subject/unit/coordinate source relation not established.** | Add actual completed single-run consumer sibling-profile witness and missing/corrupt-profile refusal; removal must separately undo caller retention and helper selected resolution. Preserve explicit unsupported coordinate/unit/subject boundary. |
| B170@BKT-01 / Q0 | `#/findings/87/criterion_refs/0` | Source retains per-request records, seed and cohort; >1 explicitly falls back with projection unsupported. Delivered real delegate and middle-failure tests fail before expected dispatch. Missing-prediction fallback omits already persisted cohort link. **bridge_missing on post-cohort prediction-refusal fallback; verification_missing for real dispatch.** | Preserve cohort through every post-cohort exit; fresh-read report lineage/denominator on accepted and rejected selected metrics; qualify real distinct requests/seeds/failed record then removal, without independence/projection claims. |
| B171@BKT-02 / Q0 | `#/findings/88/criterion_refs/0` | Unchanged seed has independent sqrt(200/3), split invariance and explicit macro 5. No delivered current PASS output or pooled-to-macro removal. **verification_missing.** | Retain seed once, qualify numeric output plus candidate ordering/weights where contract supports them; remove pooled computation while keeping policy label. |
| B172@BKT-03 / S1 | `#/findings/89/criterion_refs/0` | Existing source preserves nonzero descriptive signed-mean magnitude and unresolved direction/independence/multiplicity; existing unit tests cover zero, nonzero, small and cancellation. Author says included in PASS20. **verification_missing for delivered deciding run and fresh selected/removal witness.** | Preserve historical G dispositions; retain compact BKT03 deciding output and fresh selected report comparator, remove descriptive residual while keeping labels. |
| B173@BKT-03 / S1 | `#/findings/90/criterion_refs/0` | Existing source calls real scipy.stats.ttest_1samp and reports backend/version or explicit unavailable without normal replacement; tests include independent SciPy and controlled absence. Author says included in PASS20. **verification_missing for delivered current output and actual method removal.** | Retain real-backend/version output and unavailable branch, fresh selected report; substitute normal computation with t label retained and require semantic oracle failure, then restore. |
| B174@BKT-04 / Q0 | `#/findings/91/criterion_refs/0` | No C64 CV production/test changes or current run. Separate canonical CV writer is ready independent of this replay. **verification_missing; outside C64 write lease.** | Grant refreshed cv.py/test_cv.py lease; reuse owner, verify valid order and pre-materialization bounds/progress; cap-removal control. |
| B175@BKT-04 / Q0 | `#/findings/92/criterion_refs/0` | Returned bootstrap oracle is byte-identical to the C36 input seed; bootstrap.py unchanged and command did not select it. **verification_missing; outside C64 write lease.** | Deduplicate seed; separate bootstrap/S3-compatible owner runs shape/typo-before-RNG, multiplicity, named/custom functional, late nonfinite and removals; no invented sampling-unit law. |

## Composition and verification route

1. Root retains the useful source delta and helper regression with their exact preimages, deduplicates the two common input tests, and supplies truthful README/release companions. These are candidate implementation/WIP, not accepted full BKT.
2. The canonical backtesting writer extends the actual consumer witness and preserves the cohort on every post-cohort exit; prepare the independently selected report discriminator in the same owner chain. Do not add a second writer to shared Core/IR/Foundry/lifecycle resources.
3. Establish first failed node on one bounded real positive; fix a proven in-lease cause or give the shared owner a preimage-bound reproduction. Repair BKT02 fixture against actual `SimulationResult`, selected refs and `PropagateUncertaintyNode` source admission before any envelope-owner change. Do not waive grounding.
4. Review the delta independently, freeze actual source/inputs/backend, run defining positives/adversaries and each named semantic removal plus restored positive. Save complete compact deciding bytes/JUnit and exact selectors; source review is not composed runtime qualification. Run affected typed consumer/importer and Ruff checks on the final physical topology. No broad replay is justified by documentation alone.
5. CV/B174 and bootstrap/B175 have independent leases and can proceed now. TC/CAN/other unrelated lanes need no dependency on this replay. Subject/unit relation, statistical law, real authority/calibration/currentness and production provenance remain explicit separate limitations, never synthetic facts.

Pattern pass: P01/P02/P03 real chain and retained public lineage; P04/P05/P14 point/interval/status/authority separation; P29/P32/P38 actual consumer and content-bound removal; P35/P36 full six-file/73-pin/10-occurrence denominator and finding pointers; P37 actual predicates; P39 mandatory companions; P40 the findings are the same chain/proxy/evidence classes at distinct boundaries, not a ladder of new class claims; P41 inherited red remains `not_established`. Read back of all received bytes and the source conclusions supplies bounded source GO only. G acceptance and formal closure remain separate.
