# C69 — ordinary N7 producer-gap and independent V4/V7 predictive diagnostic

This is a standalone diagnostic/test task, not permission to change production
ordering, generic profile purpose, EvalSafety or acquisition authority.

## Goal and source admission

PolicyOS keeps candidate policy programs useful while proving exactly why an
output remains limited. Determine whether an ordinary real-N4 candidate can
carry an actual Catalog data gap into the existing candidate planner, and name
the smallest missing workflow join if it cannot. Distinguish this from a
causally grounded N8/effect/calibration claim and from physical acquisition.

Admit exactly published topic `codex/e02-cloud-calibration-input-20261028`, commit `caa91a64d7d6afc4310186ba5fadbac2008dddab`, tree
`730308224f7f1bb0d49b60c3fdb5929d791e6ebd`. The coordinator read the topic back and compared all 32 named
ordinary-route files with the fb413 analysis base: all 32 bytes match. Verify
the actual checkout and pins below before editing; never run this prompt on a
different source merely because a branch name matches.

Use Codex Cloud environment `polisyos` (`6965429cdb308191a0e6eb63cb118ea3`),
when the exact source and locked dependencies are available. Detached HEAD,
`work` and no origin are valid observations if commit/tree match. Do not reset,
switch, repair source blindly, install another agent runtime or expect mid-run
messages. On mismatch, deliver exact observed identities and useful read-only
findings. Any local fallback is a later coordinator action on the intact existing checkout/environment;
this Cloud task cannot access those local bytes and must not wait for them. No production data, credentials, private RAW,
CAS or databases are cloud inputs.

Read applicable AGENTS, CONTRIBUTING, failure register, execution HANDOFF,
source-referenced task rows V4/V7, S0-K06 §4.3 and selected AD-E02-01/03. Binding
criterion occurrences are B16@EMP-01 (`B_r19_original.md:387`), B32@FRC-01
(`B_r19_original.md:607`), LA-051@FRC-01 and LA-051@FRC-02 (same
`LA_r09_original.md:3712` block, two occurrences). This task closes none of them.
The bounded V4/V7 exit is measured predictive evidence→fresh S10/default HTTP;
it requires neither completed N7 acquisition nor grounded causal N8. S0-K06 already permits
candidate computation under declared unknown; do not submit that as a new G
question. Missing authority cannot be supplied by a fixture declaration. The
four distinct occurrences are assigned to each of V4 and V7, giving eight
task-occurrence assignments rather than eight distinct criterion occurrences.
The three distinct finding IDs yield six task-finding edges; do not alter the
canonical total of 319 task-finding edges. Both task rows remain open. Historical
closures, including B198, remain unchanged; do not implement R9/GY/Atlas or
publish main/integration.

## Inputs, scope and existing owners

Required published inputs:

- `architecture/policy_design_case/layer3_gy_design_generation_replay_recordings.json`,
  SHA-256 `db5f892c19412e74ff78683901dd81e49ebb446f75eb394d254cc75d7c74ae71`.
  It has two complete records. Preserve recording hashes and altered-overlay
  lineage; never present edited responses as the original capture.
- `tests/_helpers/generic_n4_served_replay.py` and
  `candidate_cycle_source_profile.py`: build a fixture-owned source root and use
  `prepare_generic_n4_served_replay(source_root=...)`. Use actual source-root
  readers. Do not let an absolute default path silently read private data.
- `tests/_helpers/controlled_candidate_profile.py`: real traced gateway protocol
  fixture, original replay input and owner WMR/NCM materializers. This is
  deterministic model replay, not live-model evidence or production truth.
- `tests/_helpers/semantic_epoch_native.py`: if actual available source rows are
  needed, reuse its native owner/projection producer. Do not copy production DBs.
- Existing compiler, Catalog owner, `PolicyGroundingPort`, real ValueOwner,
  `plan_requirement_gap_acquisition`, compiler/planner persistence and fresh
  reader owners. The named input and replay bytes are tracked at the pinned base; inspect and
  record additional actual runtime imports, dependencies and source readset.
  Verify relevant hashes against that Git identity and the working bytes.
  The local coordinator's `input-availability.json` and `sources.json` are
  optional navigation context, never missing cloud runtime inputs. The prompt
  itself and these published Git paths are sufficient; do not wait for private
  RAW or the local analysis packet.

Canonical mechanism owners remain root/C41 for generation source/request joins,
C49 for stopping/budget contexts, C32 for Catalog selected-read scope. They are
read-only here. Do not edit `generation_cycle.py`, `generation_source.py`,
`acquisition_production.py` (C09/shared V1 helper), fixtures used by other lanes,
generated/public inventories, dependency locks, schema/DTOs or runtime config.
Write only `tests/integration/runtime_quality/test_c69_ordinary_n7_planner_diagnostic.py`
(absent at the pinned base), and compact task-scoped documentation/receipts
under `docs/research/e02-cloud-test-plan/implementation-handoffs/Q0/cloud/e02-c69-ordinary-n7-20261028-r1/`.
Those paths are relative to `policy-engine/`; carry any required new-file bytes
in the diff. This task has no production-source writer lease. If a maintained companion edit is indispensable, return an exact
unapplied preimage-bound hunk to its owner. Root alone composes shared mutations.

## Old observations, exact boundary and current source

The old ordinary contract fixture on commit `ce3bcbbec3643ecba2b0017a7c99c230c2935ba4` reported `n6.acquisition.n7_substrate_registry_unresolved`, with no planner report and no retained nested registry cause. Its historical stdout SHA-256 is `047376574e99653c59812f19ed845487455e803f24fbce5d9bb6a8e9402d04cb`; the old raw bytes are not a Cloud input, so this is versioned reported context, not evidence of the current failure. Do not equate it with the current generic candidate-profile branch. On the actual source, `_DefaultSimulationBoundFoundryValuePort` can emit `value_conditional` before `RealValueOwnerGateway`; `_revise_node` labels that generic candidate-only, `_reconcile_blocked_voi_action` blocks the terminal, and `run` can therefore skip `_plan_n7_requirement_gap_if_requested`. Trace whether those are the actual branches of your selected producer; their presence in source alone does not prove a run occurred.

The exact `_n7_cycle_source_gap` owner requires an actual `GenerationCycleRecord`, actual emitted grounding/value gap, matching request bytes and actual driver, and a candidate ID/content hash/problem ref which match that cycle. A request-only or fabricated cycle is rightly refused. The public planner accepts typed compiled gaps but does not itself prove the ordinary cycle/producer binding; a direct plan is a bounded owner observation, not an ordinary planner success. Record the compiler report separately from the planner report; compiler persistence alone is not a planner. Catalog availability and source/registry selection are not permission/currentness, and a plan is not physical acquisition. Never use `_CgfGenerationPort`, `_WDIGap`, fabricated producer gap, forced CGF grounded/current status, or changed production generation ordering as the ordinary positive. Transparent observers must delegate actual owners; adversarial fakes are refusal controls only.

## Finite discriminating work

1. Trace and instrument actual selected paths with transparent observers that
   call the original functions unchanged. Record actual N4 candidate/content/
   problem refs, CGF disposition, selected source/profile refs, grounding gap,
   N5/N8 outcome, terminal, VOI reason, compiler ref, planner ref and physical
   dispatch count. Use the normal authenticated POST→ControlWorker path from
   `test_generic_n4_child_profile_set_served.py::test_original_second_capture_serves_two_meaningful_children_through_fresh_get`
   with its existing fixture-owned source input. Reuse an existing qualified
   run/readset if the coordinator already has this exact source/profile/input;
   do not repeat the full served replay merely for a new report HEAD. The existing
   `controlled_candidate_gateway` and `served_worker_phase_probe` pytest fixtures
   are local to that existing test module; they are not automatically available
   by name in the new module. Instantiate the existing `ControlledCandidateGateway`
   and reuse its supported test-local environment setup in your own unique fixture,
   or explicitly reuse a valid local helper; reproduce the small callback locally
   or use its optional `phase_callback` contract. Do not edit a shared fixture,
   import/copy credentials, or bypass product gates.
2. Retain the control that the declared generic profile stays conditional and
   cannot enter ordinary EvalSafety or N9. Observe `_revise_node` and the
   pre-planner terminal guard rather than guessing from report absence. A
   profile purpose stop is distinct from source/registry/compilation failure.
3. From the actual producer-emitted candidate and its exact problem/context,
   query the real selected Catalog availability and, when appropriate, the
   actual `RealValueOwnerGateway`. Preserve actual available values or actual
   typed unavailable evidence. Do not hand-author `_WDIGap`, alter the candidate
   target/problem after N4, invent a world record or stamp current grounding.
4. Investigate a **plan-only** composition using the existing compiler and
   planner owner over that real typed gap. Keep the complete compiler output,
   selected requirement join and persistence binding; use existing semantic
   matching/rejection logic rather than inserting caller-authored specs. A
   direct owner composition is a bounded witness, not an ordinary loop report.
   In particular, do not forge a GenerationCycleRecord to pass
   `_n7_cycle_source_gap`; its no-cycle refusal is intentional. If existing
   public APIs cannot represent this join without a forged cycle, stop that arm
   with the precise missing contract/producer link and an unapplied minimal
   design proposal. Continue the ordinary observation and other controls.
5. Reopen any produced compiler/planner artifact in a fresh authorized reader.
   Verify exact candidate/problem/variable/scope/selected source and distinct
   compiler refs. Planner result is candidate/routing-only, with unknown basis
   carried honestly. Physical acquisition count, activation, promotion and
   fabricated measured/causal evidence must remain zero. If no planner is
   produced, preserve exact typed refusal and the last completed real stage.

At least one positive uses actual producer bytes; independent adversarial
controls change candidate/problem/variable/source/scope separately while keeping
cheap labels constant. Keep available A/A and unavailable A/A controls. A
foreign source with the same summary must not be accepted. A positive planner
witness must survive fresh read; the corresponding removal of source/requirement
binding must fail behaviorally while marker fields remain. If a full positive
cannot be reached because a real software seam is absent, classify removals
UNRUN and provide the smallest next owner hunk/contract and distinguishing
signal; never call setup failure an expected adversarial PASS.

For a source-property removal use an isolated source variant or a temporary,
scoped in-process mutation of the actual owner method, never a persisted edit
to another writer’s source. Capture original and mutant bytes/hash, exact test
selector and failure reason; restore the original and rerun the unchanged
positive. A mock refusal, setup error or passing marker-only assertion is not a
valid removal. Record all unrun removals explicitly.

Do not weaken scientific gates, select a new backend to obtain green silently,
monkeypatch CGF status/current_valid, treat synthetic source declarations as
permission, or map conditional K_sim into world/effect evidence. Do not reorder
N5/N8/N7 just because the candidate branch stops. Any proposed stage extension
must state actual old profile purpose, explicit new version/selection,
compatibility/history, consumers/surface and minimal falsifier.

## Independent predictive-only V4/V7 path

This branch is independent of a completed N7 planner, grounded causal N8, or real physical acquisition. Do not hold it behind the N7 observation or claim it is a full B16, B32 or LA-051 closure. Reuse the actual existing `ForecastOwner`, selected CAS evidence, S10 and default HTTP owners. The existing real composition is `tests/unit/runtime/http/test_control_service_di.py::test_predictive_calibration_post_event_reopen_get_and_exact_intent_retry`; its source constructs an actual run-bound N5/candidate context, authenticated default-app POST, real ForecastOwner, empirical evidence and association event, and fresh default-app GET, with a second run holding prediction/interval geometry and method constant while changing only rooted held-out observations. Companion `tests/unit/remediation/test_frc_02_s10.py::test_same_ets_shape_with_different_held_out_observations_changes_s10_suitability` and `::test_nominal_confidence_only_does_not_change_s10_suitability` isolate S10 behavior; recognize their constructed observations are fixture-level evidence, not an authentic production corpus. `tests/integration/core_runtime/test_predictive_calibration_profile_owner_binding.py` exercises the real selected profile owner and forgery refusal.

First inspect source/readsets and record available locally constructed inputs, exact test IDs and measured backend/profile. Run the smallest actually supported positive: real selected source -> forecast producer -> held-out numerator/denominator -> persisted evidence/association -> fresh S10/default HTTP; capture actual refs, selected profile hashes, temporal roles, event and prediction-time vs observation-time. The two supported fixtures retain different empirical suitability when true held-out observations change and interval geometry is held fixed. Compute expected count independently from actual held-out values and interval endpoints; do not let the product's own derived grade be its oracle. Include nominal-only, foreign/wrong-kind/profile mismatch and missing/tampered evidence controls on real readers; behavior must refuse or retain explicit limitations. Remove the actual resolver/observation-to-grade binding while keeping labels/nominal fields, show a named semantic failure, restore and rerun the positive. A mere source inspection, fixture label or fixed interval is not measured coverage; actual Cloud fixture bytes prove only the bounded synthetic case. S10's predictive-only status and unresolved causal/counterfactual authority must survive fresh HTTP. If a public S10/HTTP route or backend is unavailable, preserve exact reason, incomplete capability label and bounded next owner/test; continue independent N7 observations.

## Environment, execution and resource admission

Read disk total/free, RAM and CPU separately. Around 32GB cloud disk is total
capacity, not RAM or guaranteed free space. Account for Git, locked Python3.14
runtime/test extras, caches, small native fixtures and deciding outputs. Use an
existing supported `.venv` or necessary minimal frozen setup. A setup/tunnel
failure is ERROR; inspect existing supported interpreter/backend before
repeating dependency downloads. Never reinstall a working local environment.

Preserve pytest.ini/plugins and all product gates. New served/native profile
runs alone first; use one numerical thread as the initial measured admission
profile, not a scientific weakening. Local provisional outer guards: 600s,
2.25GiB sampled process-tree RSS, 8GiB free before start and the retained
supervisor's 6GiB floor. These are guards, not measured promises. The old native
normal diagnostic took23.98s/~1.17GB; this different real-producer replay remains
unmeasured. Cloud uses actual capacity and one isolated fixture DB/CAS/ephemeral
loopback gateway; no fixed ports, shared generators or private state. Never
interpret exit137 alone as OOM. Record actual stage timings and disk growth;
leave the next costly arm UNRUN if the first admission fails.

## Delivery and truthful end conditions

Prefer useful diagnostic tests/oracles and compact reports. Before costly replay
prepare a small transport package containing complete diff/new files, receipt and
one deciding output; inspect the actual produced bytes and supported ordinary
Git/cloud-diff channel. Earlier tasks delivered bytes through that channel, but
visibility for this run is not guaranteed. Do not wait for a mid-run coordinator
acknowledgement. Root independently retrieves and hashes the bytes after they
become accessible; a cloud ignored path plus SHA is not delivered evidence. If
that channel cannot carry an irreplaceable deciding output, explicitly name it
unavailable and the one exact bounded rerun; do not trigger automatic blanket
local repeats. Classify evidence A (essential bytes: deliver), B (reconstructible
from published Git/inputs: recipe only), C (duplicate/noise: omit), and D
(non-reproducible deciding bytes: retain and make accessible; justified size
exception if needed).
Retain full concise command stdout/stderr, JUnit, selected node IDs, input/profile/
backend versions, actual loaded source/readset and resources; compress deciding
logs losslessly if needed. Do not ship checkout/dependency/CAS/database/recovery
copies or duplicate intermediate payloads. A required unavailable witness is
explicitly unavailable with its exact bounded rerun, not automatic replay of
all cloud work.

Deliver: task/environment; actual base/final commit/tree or complete patch
identity; every changed path and companion; commands actually executed;
PASS/FAIL/ERROR/SKIP/UNRUN separately; ordinary versus direct-owner versus source
inference; complete source/input hashes and accessible output bytes/locators;
positive/adversarial/removal outcomes and limitations, command argv/exit/time,
full deciding stdout+stderr (or explicit combined stream), JUnit+selected node IDs,
backend/profile, selected source/fixture identities and measured resources.
Losslessly compress modest deciding logs if useful and include actual accessible
bytes in the supported patch/commit. Record all four original occurrence pointers
and their V4/V7 task edges separately, plus the N7 route; author result, review
and G closure remain distinct. Re-read delivered source from its actual commit or
exact patch postimages. Ordinary topic commits and
publication use normal hooks; no main/integration/G publication or bypass.

Conclude with one finite next owner action: existing path qualification, exact
software bridge, or concrete external fact affecting one original criterion.
Check existing owners/inputs before declaring an external block. Author result,
independent review and G acceptance/closure remain distinct. No message-only
assumption or endless wait for coordinator clarification is an end condition.

## Exact published source and input pins

The first 32 named original analysis paths were compared in full against fb413 and exactly match this published base; extra directly named tasks, instructions, backend and predictive owners follow. These are a named path denominator, not a claim to cover every transitive module or fixture. Record the actual run readset and changed preimages. The new unique diagnostic test is absent at this base.

| Path | Git blob | Bytes | SHA-256 |
| --- | --- | ---: | --- |
| `policy-engine/architecture/policy_design_case/layer3_gy_design_generation_replay_recordings.json` | `ae80ce0fce426422c539cb0ea5fad44df905a495` | 1009265 | `db5f892c19412e74ff78683901dd81e49ebb446f75eb394d254cc75d7c74ae71` |
| `policy-engine/docs/plans/active/agent-packages/PolicyOS_E02_Combined_Agent_Package/source/B_r19_original.md` | `d800082eebfc12eaf647b0c0257c4f06e135d25a` | 1336380 | `9c98584cbfa72996b058abf127f6c689f919a3421cdd563a82c84a7324ab39b5` |
| `policy-engine/docs/plans/active/agent-packages/PolicyOS_E02_Combined_Agent_Package/source/LA_r09_original.md` | `4bdf76e99f0c26e40bc2a71e76d4940c23712260` | 648034 | `2e13d05d40ab162dba6f1ed495865037bc08fc359a987e7a42c4d445a9b8d727` |
| `policy-engine/docs/reference/policy-design-case-failure-patterns.md` | `ef82878fae6a33d03d05b77bffc8367fdacfb098` | 73467 | `741f66a832fde5d4d0fb00e35bf4d5a34ec1b976f94d61b83c7eaedc048defd4` |
| `policy-engine/docs/research/e02-cloud-test-plan/execution-prompts/unified-local-2026-10-09/TASKS.json` | `b06e511735005a9ba72c826c2504c413d32679c2` | 27989 | `a37c75cfe09d33c1f50379d5bbfd04bdb728c990e832aec3bf19c0d17035734c` |
| `policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/executor-handover-20261027/canonical-task-bindings.json` | `2858c0e9a16a92bd021c3253a47096a62403af1f` | 26299 | `fdd538cf36b3eef95224353972b5f87da18cfa3c16d0b4020d891cd94b63d0b3` |
| `policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/g-review-followup-20261027/dispositions.json` | `d53792331e6837e66ca21fd29efc5115a91c2410` | 13086 | `0e1337a4d5e038dbc7ea13fb82a0913f85f8bb50b34bc7fa4aad2f1c54c4082f` |
| `policy-engine/docs/research/e02-cloud-test-plan/integration/architecture-decisions-2026-10-20/03-observational-http-input.md` | `537074023acc69ec42b6052eab896b02727a17fe` | 23358 | `af03053228ca0f755b9e03e77c137f1c8504874d9e76b1dc96c5f71e695c4687` |
| `policy-engine/docs/research/e02-cloud-test-plan/integration/architecture-decisions-2026-10-20/06-final-decisions-and-solo-review.md` | `9d9e09fc84cee10c27ece0c3953f2a6af0975d59` | 24170 | `4eb1e7e966194f424d0cc1ab57e91fd664a1534367bf776d07895741b5d8939b` |
| `policy-engine/docs/system-design-decisions/stage0-custody-kernel-ratification.md` | `6397ec2b9ba043c742f096813a0229418721fbfb` | 16120 | `a8410cddf3e2c8b7f4c194d06d0c38523fb64634f247e6baf96dfd6359197ea7` |
| `policy-engine/src/polisyos/runtime/http/services/predictive_calibration.py` | `20aa89e5ad1d4c5d524d8afa08cdd112b575f91d` | 95799 | `2f5b9f0e327cbd8bb736de9869dfa93aaf9407290c1397fcec7015ca50eafdb8` |
| `policy-engine/src/polisyos/runtime/quality/acquisition_planner.py` | `9491662454ad6ae4862b868330eb3072c8ee09b7` | 268310 | `05a5d0fd34d67fa5a63a0777993eb13a10c5cda80b8c493ac6597181e2d00737` |
| `policy-engine/src/polisyos/runtime/quality/candidate_simulation.py` | `48adb194cb7b550e243c47b53ecd091efbc00554` | 46524 | `f0fffbd512b061aa340a7ba9d72c11210d8a6c61a5e85fb912e079ec9d0a7a9d` |
| `policy-engine/src/polisyos/runtime/quality/credal_reference.py` | `371bd0ae47f2918e038c426c749a3816d3ddf51c` | 147641 | `b0c6a360d19d3f53bd391af3af732d58566e84cfe69393c34e2bce0d0435243c` |
| `policy-engine/src/polisyos/runtime/quality/cycle_substrate.py` | `4e20cf07289cf574e4b76e2961ab4200598055b1` | 188698 | `fa41b25c7d0c78d4482e99f73a6dc773820c5eebd81f48b6bb57022532b6f5ac` |
| `policy-engine/src/polisyos/runtime/quality/design_generation.py` | `79101201121de046c58d2e5c51e9a6e679881e4a` | 190988 | `e8b7a1709ea7431f1026e152857b1b359c76a9cfc8fcff5316be2a7e815e8a8a` |
| `policy-engine/src/polisyos/runtime/quality/generation_cycle.py` | `5771b7b1dbdc23f59a54869e8a3f453f7cb7d2ee` | 940372 | `758d13ec33c7a98d60fc6d4806d75cdd08746151e3efe3f15d558df0f2326ae3` |
| `policy-engine/src/polisyos/runtime/quality/generic_simulation_admission.py` | `9704fe9af723b68a18ce1a78f4ba5e57760046c3` | 137470 | `74b190bf66a720c211fc5d585ab55952021d4b74fbb5aac76ee913be56eb8f2c` |
| `policy-engine/src/polisyos/runtime/quality/substrate_registry.py` | `b3674796ec698114378132fa250609e8b94a873f` | 96636 | `4bb061b74455402a5bd130b29fd7594a579a3b3a74bac0a55c3def9df0542531` |
| `policy-engine/tests/_helpers/acquisition_production.py` | `f608117fe740019d4803cdc90fee0a73a48d4714` | 56068 | `f04e9b5fd36eb482d42b3a1570741ad2abb11c9009db1dfed3a9757806ad1a0e` |
| `policy-engine/tests/_helpers/candidate_cycle_source_profile.py` | `7aa88af4d941898c79b0b052040827de2a285a7f` | 39967 | `a33bd8dee33bae07359dbd34976a9353106d51debcc873bdcdd93bb3626b6a6d` |
| `policy-engine/tests/_helpers/controlled_candidate_profile.py` | `e608f54be496bebd314e8d69da9618906a26bd38` | 85784 | `1a5e206648bd5bc59a1de2218a600ddc17012a7189b29e8868927925b832751c` |
| `policy-engine/tests/_helpers/generic_n4_served_replay.py` | `9e456541455b938f02b9738911a06945f1f6ec14` | 94604 | `5bc8d68162ff7de95104d932eeb34a0c2009f7cf75a75b594e3468cc8477624d` |
| `policy-engine/tests/_helpers/semantic_epoch_native.py` | `d8079798bb3a72342c976695237f815a09628067` | 58832 | `239c33f90ebd951b6ee1f84afc19b77b37a65450cde435d9d1e0aedcaf170eaa` |
| `policy-engine/tests/integration/runtime_quality/test_configured_candidate_simulation_served.py` | `15a29dbeccb017a695e45f8370b7553bf33e3905` | 116668 | `0f7d905373d0156483cf591c76239268b970fe648b1dbd508e5d98d02c07f33b` |
| `policy-engine/tests/integration/runtime_quality/test_generic_n4_child_profile_set_served.py` | `99961b42768e0aabd0068eb9b34e9790ef6e5a9e` | 157428 | `8e9c8b1d1d6d9aef397880d085b7a94cf7cdaa69987f96d2890578fe91565637` |
| `policy-engine/tests/unit/runtime/http/test_control_service_di.py` | `439d293212f50012431f79a12b5c0021d53a0020` | 290893 | `95c8bb5c1db535ff644a841416e230eb200dfae681c05e458f9eb1da5ee18f3d` |
| `policy-engine/tests/unit/runtime/quality/test_design_generation.py` | `9354c83c748ad08f4ab853585345874fa7629d18` | 167441 | `25fd5f58503878e27f8b76f33143b8b6bd48193699e1893455a4fbe4463ff583` |
| `policy-engine/tests/unit/runtime/quality/test_generation_cycle.py` | `b02afa5a9a96cd34b44dca94e0f56ebb2d608d93` | 525367 | `9cef0c976d3d51ff4a09df5383993034cebcb5255b18e9e92a8ab2b94ed51572` |
| `policy-engine/tests/unit/runtime/quality/test_joint_simulation_horizon.py` | `24c0eb50de0d586daa63872bc4da4f8469bce3c1` | 128633 | `653b3857055fc944f76794c815f4fd831a98a35469a91035adf476d04be08b9e` |
| `policy-engine/tests/unit/runtime/quality/test_n7_source_gap_projection.py` | `ed76193d1fcc0221c87bb3173d5dfafe2a11deb8` | 9645 | `269100d0ca19600a7376575a8c543b25aa5ac8d91d92c40b86341afb4b6bb85e` |
| `policy-engine/tools/quality/validation/check_layer3_gy_design_generation_contract.py` | `b400aed5f3135cd1d97c49067b33d4695bdcce30` | 167265 | `fee9f11596335ebabb5c98be494d127b27426f7225de9342990f2195236ede6b` |
| `AGENTS.md` | `0f724f52375e8e08321e3f12fcd5244a799e01b8` | 22824 | `424b84e3280df143219fe27e28149088f9e92b947e4956b2103388e11849e65c` |
| `policy-engine/CONTRIBUTING.md` | `8ff414198e306e671abff1f76f31330a1f29d765` | 12253 | `e78f1bdb99a900f6426f9f451b7e9cbc0e21007eb12012eaf209d89c505f3a1f` |
| `policy-engine/docs/research/e02-cloud-test-plan/execution-prompts/HANDOFF.md` | `b9f1a717049d9e30f68bf291e3f8321013abf83e` | 20260 | `8519f95eb0ff2ec2c64caa4497eb58b957fe7cd47a0a6955bad98a2c20795d3b` |
| `policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/executor-continuation-plan-20261027/analysis/criterion-routes.json` | `ea61cf00850d62bee2713f34e533f9047d8def61` | 179931 | `08f8dd27542514cc108a48b21bb5fa6bca79c7191fac5c108c1c0e52107a3c74` |
| `policy-engine/tests/_helpers/runtime_http.py` | `f64c4419889b0fae2e41c5ebe21e3079c5fe8624` | 96992 | `e76358a7b7d2b2b0badc35c600b102118f8a9c83ad2cb3fa6c1212e2ae534cdd` |
| `policy-engine/tests/conftest.py` | `f5d684c2678e5acefa5d0e4af62297c473d3dfaf` | 10518 | `691bf0914650edbef7cc5ededdb2828a8992c513abcaa875f0eb5ac7b318dbdd` |
| `policy-engine/tests/unit/remediation/test_frc_02_s10.py` | `245f6379e0a1e79243ba6235dcd993e302b0966b` | 45785 | `1532c8b7e947ca341bcd9d6492fbe0d9b2dc955930c990d18e1b3142a51ba1f7` |
| `policy-engine/tests/unit/scientist/methods/backtesting/test_forecast_owner_profile.py` | `2e3c84e8c77e11c55d3999fa3a4f6529e3d9de26` | 24472 | `50d8fe7dbfb0fb92b90811da71ae61eb31885c391eb244d93764f89a970dac33` |
| `policy-engine/tests/integration/core_runtime/test_predictive_calibration_profile_owner_binding.py` | `8db8dcd152693cb717cfebb96b7218b11e7ab277` | 8424 | `e17dc5acc7abfd318ea99baf235b1061e6df57233270b592a973f2a5ddf94a76` |
| `policy-engine/tests/unit/runtime/http/README.md` | `de64fdf2ec455105599205ee0db23007968beca4` | 2099 | `fbc6b97dbb09121dcedd5ea5ea68d2222f5634057957e8e15e9e3f41f45f2169` |
| `policy-engine/src/polisyos/scientist/methods/backtesting/forecast_owner.py` | `07d4e46c0d015e9090bab2446b3407dd0e7dbc55` | 56739 | `e246e670e007e0d9da0438fb7ec65dc4398d2b409131fac6de52b3f10de36587` |
| `policy-engine/src/polisyos/calibration/forecast_bridge.py` | `91a5a1897851b179d51b77a3f73645790691b931` | 76473 | `953abaf6021ebc35629f03c4c132851515903eb96aba53a242ec450d855ca750` |
| `policy-engine/pyproject.toml` | `e4bb0ae9d77ae3bbb4b961ddd8f5f7e2e597ca51` | 11241 | `5f65308cb088086b6fc0aa40a5bae6ed852ae3a2e261103bd0d4158d97c1e8f2` |
| `policy-engine/uv.lock` | `c34f9273799807fbf0bb95a30668f75a4c4e69a9` | 808851 | `ccfdca0e741dc77795f5af61871af5d62e73feebf55c7ffb28cd16e55fe207e9` |
| `policy-engine/pytest.ini` | `f6b18091a37290d7b5c375b3aef44ffebc0a293a` | 1021 | `61270205a9f573a090b3c051a4b78351e67308a49e21660dbf33e76186d799eb` |

## Exact original criterion occurrences

Each of the following four original criterion occurrences belongs to both canonical task rows V4 and V7; the identical LA-051 source span is shown once without merging its two coverage pointers. Source blocks are exact UTF-8 bytes from the published base; they establish the original requirement, not completion or G acceptance.

### B16@EMP-01 `#/findings/75/criterion_refs/0`

`policy-engine/docs/plans/active/agent-packages/PolicyOS_E02_Combined_Agent_Package/source/B_r19_original.md:387–398`; SHA-256 `fddf1601c092be1f87a19a79a3f6975264850d8df9428e3f54bd3f8fe48d8706`

## B16. Область задачи должна ограничивать выборку до LIMIT и агрегации

*Источник карточки: A:B16. Унаследовано из прочитанной сводки A; не новый интеграционный прогон.*

**Происхождение и подтверждение:** P2; код. Загрузчик профиля L1 фильтрует canonical_var, наличие значения и периода, затем применяет сортировку и `LIMIT 20000`. Регион/популяция конкретной задачи не передаются ему явно; несколько источников для пары unit-period усредняются. Сейчас профиль используется для формы данных/выбора метода, а положительная причинная ветвь далее не установлена. [A.R04: 4460–4635]

**Экономное расширение:** передать область задачи и семантику измерения до ограничения объёма; различать усечение, неполноту и отсутствие. Сохранять источники и единицы; усреднять только по объявленному допустимому правилу. Не исправлять проблему простым повышением LIMIT.

**Критерий:** подходящие строки не исчезают из-за сортировки чужих областей; перемешанные единицы не усредняются; реально маленькая выборка не выдаётся за полную. Изменение области задачи меняет фактически потреблённый набор и его идентичность.

**Ограничение и приоритет:** не утверждается, что опубликован неверный причинный эффект. Это риск входного профиля, обязательный к проверке при открытии B08. Высокое влияние на корректность; средняя локальная сложность.



### B32@FRC-01 `#/findings/157/criterion_refs/0`

`policy-engine/docs/plans/active/agent-packages/PolicyOS_E02_Combined_Agent_Package/source/B_r19_original.md:607–620`; SHA-256 `68a3acb0a34e8ebfce5217cdc99785a851a21368ea2d552795f68272e7140d6c`

## B32. Прогноз и калибровка получают одну зашитую дату и оптимистичные значения по умолчанию

*Источник карточки: L:F30. Унаследовано из Library S01; не дублируется с A.*

**Основание:** Вспомогательный путь прочитан; его актуальный production-допуск не доказан. **Происхождение:** P4 — новая находка. **Приоритет:** A до подключения B08. **Охват изменения:** S–M.

**Наблюдение и барьер.** _build_s10_forecast_inputs использует datetime(2026,6,2,UTC) и назначает её нескольким различным временным ролям. Также есть fallback counterfactual_credibility="credible" и floor_passed, выводимый из calibration_status при отсутствии отдельного входа. [L.S24, L.S06]

**Минимальное расширение.** Получать временные роли и основания проверки из реального связанного результата/источника; неизвестное оставлять неизвестным. Для чистой условной симуляции не создавать запись эмпирической калибровки. Старые артефакты не переписывать: новая схема и явный переход.

**Проверка результата.** Расчёт 18 сентября не выдаёт 2 июня как фактическое время наблюдения; отсутствие доказательства credibility не превращается в credible; тесты различают prediction time, observation time, valid time и calibration window.

**Граница вывода.** Не заменять все даты на now: это другая подмена. Наличие helper не доказывает, что такой пакет уже попал в production; данный пункт — обязательная проверка перед оживлением положительной цепочки.



### LA-051@FRC-01 `#/findings/275/criterion_refs/0`; LA-051@FRC-02 `#/findings/275/criterion_refs/1`

`policy-engine/docs/plans/active/agent-packages/PolicyOS_E02_Combined_Agent_Package/source/LA_r09_original.md:3712–3746`; SHA-256 `5d3fe7ce8b71d77c07f35e5a68fed244c0d40e0f24925714edbf7297c37ea616`

## LA-051. N8 → S10: адаптер формы причинной оценки продолжает выполнять роль производителя калибровки

**M — разделение estimator diagnostics и эмпирически обоснованной calibration admission**

**Точная область:** `src/polisyos/runtime/quality/generation_cycle.py`:

`RealValueOwnerGateway.produce_forecast_inputs`, `_build_real_s10_forecast_inputs`, `_s10_calibration_evidence_from_report`, `_build_s10_forecast_inputs`.

**Существующие владельцы для сопоставления:** `runtime/quality/design_axes/outcome_prediction.py` — S10 records, builders и ограничения назначения; `calibration/continuous.py` и `calibration/curve.py` — generic численная диагностика по наблюдениям и предиктивным интервалам. [E200–E204]

**Статус.** Положительный вызов из production-named gateway подтверждён полным прочтением соответствующего метода. Числовой helper исполнен как точный excerpt. Всю `generation_cycle.py`, настоящий Foundry estimator, S10 envelope и конечный N9 admission этот проход не исполняет. Вывод относится к производству входных показателей, не к доказанному выпуску ошибочной production-рекомендации.

**Что установлено.** `_s10_calibration_evidence_from_report` проверяет finite point/CI, finite либо отсутствующий standard error, булевы diagnostics и положительные количества treated/control/pre/post. Если эта проверка выполнена, он назначает `calibration_status="pass"`, `floor_passed=True`, числитель равным `sample_size`, а `pass_rate=1`. Поле `interval_coverage_metric` получает объявленный `confidence_level` отчёта либо `0.95`; поле `calibration_error_metric` — ограниченную сверху относительную ширину CI. Попарных прогнозов и наблюдённых исходов, списка калибровочных испытаний или их результатов helper не получает. [E200]

Это не одно и то же измерение. Объявленный уровень интервала и наблюдаемая доля покрытых исходов имеют разные входы; ширина интервала и ошибка калибровки тоже не тождественны. При этом finite-check и диагностика исходного estimator полезны: они не становятся лишними от того, что их недостаточно для другого вывода.

**Различающее испытание.** На явном mapping, содержащем только поля estimator, helper выдал `pass`, `pass_rate=1`, `interval_coverage_metric=0.95`. Изменение только `confidence_level` на `0.8` изменило названное coverage на `0.8`, не добавив наблюдения. Отдельный настоящий `evaluate_continuous` на 100 исходах вне интервалов дал empirical coverage `0.0` и ECE `0.95`. Последнее — **иллюстрация различия измеряемых величин**, не заявление, что CI причинного параметра следует автоматически проверять как предиктивный интервал индивидуального исхода. Правильный калибровочный корпус должен соответствовать своему estimand и дизайну оценки. [r08-P20–P22]

В `_build_s10_forecast_inputs` дополнительно обнаружена фиксированная дата `2026-06-02 UTC`, которую код использует сразу как prediction, observation, policy-effective, data-valid time и обе границы calibration window. Ссылки `observed_outcome_ref`, `credible_evaluation_evidence_ref` и ряд lineage refs конструируются строками из имеющихся IDs. В прочитанном builder они не разрешаются в эмпирические источники. Это статическое наблюдение текущего исходника; данный builder целиком не запускался и существование всех таких refs во внешнем хранилище не проверялось. Простая замена даты на `now()` не восстановит разные временные роли. [E200]

**Почему это legacy-кандидат.** В orchestration-adapter сохранилось самостоятельное суррогатное производство калибровки рядом с уже существующими владельцами расчёта и S10-records. Название `RealValueOwnerGateway` и вызов S10-builder не превращают локально сочинённые показатели в результат другого производителя. Нужна миграция обязанности, а не перемещение той же формулы в ещё один файл `calibration.py`.

**Что сохранить.** CausalEffectReport, численные оценки и интервалы, estimator diagnostics, knowledge gaps, errors, реальные ограниченные forecast tiers и S10 purpose denials. Нельзя автоматически заменить причинную модель generic predictive-calibration функцией. Нельзя снимать EvalSafety/WMR/candidate checks или считать временный доступ к отчёту сертификатом на production.

**С чем объединить.** Generic вычисление интервал-покрытия/ошибок — существующий `polisyos.calibration`, когда ему передан подходящий корпус. Дизайн калибровочного эксперимента и binding к предсказываемому эффекту должны оставаться у фактического исследовательского/методового владельца. S10 получает проверяемый результат и определяет допустимую ограниченную роль. N8 gateway переносит ссылки, значения, эффективный запрос и отдельные времена, а не создаёт evidence из наличия finite CI. Готового полного bridge от всех Foundry reports к независимой калибровке в этом проходе **не установлено**.

**Порядок миграции.** Сначала переименовать/разделить существующий результат как estimator-shape diagnostics; такие сведения можно сохранять, не называя их calibration pass. Когда действительного калибровочного основания нет, выдавать поддержанное состояние отсутствия/ограничения с причиной, не маскируя его идеальным pass rate. Затем подключить один реальный calibration producer для одного совместимого метода, связать данные, версию модели, правило, калибровочный знаменатель и времена. После переключения потребителей удалить суррогатное ветвление. Исторические записи сохраняются с прежним provenance и явным статусом; их нельзя задним числом назвать измеренной новой калибровкой.

**Приёмка.** Одинаковая форма estimator-report с разными результатами настоящего калибровочного корпуса; изменение nominal confidence без новых observations; отсутствие history; failing diagnostic; неполный/несогласованный calibration record; другой model/rule revision; независимые temporal roles; недоступный reference. Сравнивать происхождение numerator/denominator и фактическое измерение, а не только shape DTO и значение `pass`.

**Отрицательные контроли.** `report=None` даёт `blocked`; явно неуспешная diagnostic даёт `limit` и `floor_passed=False`. Эти защитные ветки воспроизведены. S10-record проверяет согласованность numerator/denominator, ненулевой знаменатель для pass и порядок окна, а S10-назначение явно ограничено. Они полезны, но arithmetic-consistency не устанавливает происхождение чисел. [E201; r08-P23–P24]

**Приоритет:** высокий по смысловой корректности; первый шаг ограничен прекращением неподтверждённого calibration pass. **Граница:** ни обход production admission, ни фактический ущерб пользовательским решениям не установлены.

<!-- PAGEBREAK -->


