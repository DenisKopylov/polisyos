# C37 actual native r2 — independent evidence review

**Overall affected gate: FAIL (144 PASS, 5 FAIL, zero ERROR/SKIP). Bounded requested-temporal-intent cohort: 49/49 PASS on the actual composed source.** The first requested-cursor producer/selected queue/worker/projection path now has executed evidence. The five remaining failures are in the control-intent consumer module and route to the existing C57 writer; they are not waived or labelled inherited. This review creates no competing implementation lane and grants no TC-wide, Legal, production-authority or G acceptance.

## Exact source, inputs and available evidence

Case `c37-typed-json-error-consumers-r2-20261028` ran on commit `a8bee9746d0ea6c9582648b60944f8a4a27eb31e`, tree `f54638ce89e0c2589d9be3b47809af12bd509c93`, attached author branch `codex/e02-unified-local-20261009`. The exact supervised argv, seven module selectors, native configuration, source/profile freeze and output locators are retained in `audit-result.json` / `source-profile-freeze.json` and indexed with full hashes in [C37-actual-native-r2.json](C37-actual-native-r2.json).

The deciding audit is `policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1/c37-typed-json-error-consumers-r2-20261028/audit-result.json`, SHA-256 `90bc340dcd438f6b88faf4ab18dc3456962f75113a95e49e1597a1b396f172b8`. Its complete stdout (9,261 bytes, SHA-256 `e1fecd54b5e0f5496232511b774d071febcd3a433c130bee72ecfff31c7e3b73`), empty stderr and complete JUnit (35,500 bytes, SHA-256 `8e2eb202d98a6c9b6d32662a4c93e596e2ae59d4d2101531b5f50a096104cf7a`) were read, not replaced by summaries. All 149 testcase records and all five full failure bodies were parsed; their grouping and traces match the separately retained root failures JSON exactly.

The retained Root readback at `LOCAL/raw/e02-execution-20261027/c37-typed-json-error-consumers-r2-Git-readback.json` qualifies its run-time Git/index/work state and finite imported source. This reviewer independently verified all **1,926** observer file hashes against immutable Git blobs at the run commit, with no missing/mismatched Git member. The readset bytes, source/profile freeze, archived source frame, plan/harness/config/test pins and their hashes remain available. The 1,926 count is the complete observer denominator of loaded `src/polisyos`, tests and tools Python paths; it is not all repository files, all executable inputs or external package bytes. The historical cumulative frame's entry base/tree is not substituted for the actual run commit/tree.

The normal pytest profile retained default plugin loading/importlib/strict markers; the harness redirected output/cache scratch and used an empty pycache prefix to prevent stale canonical bytecode reuse. Test outcomes were not made green by a reduced selector or disabled plugin. The process completed with exit 1, no abort or termination signal, and its process group was gone. Supervised wall time was 34.92 seconds (pytest's own summary: 10.96 seconds), sampled peak process-tree RSS 1.13 GiB, minimum sampled free disk 14.35 GiB. These are measurements of this bounded wave, not a quota for unrelated workloads or an OOM diagnosis.

No test, product import, collection or Git mutation was executed by this reviewer. Operations were reads, stdlib JSON/XML/hash/AST inspection, immutable `git show`/`cat-file`, and index/work readback. Only the two RAW review files were written.

## Complete result denominator

| Selected module | PASS | FAIL | ERROR | SKIP |
| --- | ---: | ---: | ---: | ---: |
| `test_nl_temporal_scope_intake.py` | 29 | 0 | 0 | 0 |
| `test_nl_temporal_scope_lifecycle.py` | 20 | 0 | 0 | 0 |
| `test_nl_request_json_admission.py` | 42 | 0 | 0 | 0 |
| `test_runtime_http_error_state.py` | 7 | 0 | 0 | 0 |
| `test_error_semantics.py` | 6 | 0 | 0 | 0 |
| `test_control_job_execution_intent.py` | 28 | 5 | 0 | 0 |
| `test_nl_predictive_basis_intake.py` | 12 | 0 | 0 | 0 |
| **Total** | **144** | **5** | **0** | **0** |

Counts come from the complete JUnit, not source test-definition counts or sampled output. The 49 temporal cases are the first two rows, and are already included in 149; they are not added again as independent evidence or criterion closures. The previous 49-case run at `67beb…` had 32 PASS/17 FAIL before the producer. This new executed evidence supersedes that admission limitation for the properties actually exercised on `a8bee…`; it does not erase the older receipt or retroactively mark it green.

## What now has executed evidence

The 49-case temporal result exercises the actual source DTO in both schema modes; omitted/selected inner presence and ordinary include/exclude; raw-authorized-body presence mismatch; strict timestamps and typed UTC overflow refusal; version-specific fixture projection; exact selected queue read; real admitted worker and requested-scope CAS artifact/binding; full expected cursor manifest-profile reconstruction; mutable payload and identity/refusal controls; fenced progress retention and terminal projection; repeated unlinked materialization; fresh service/CAS/store-instance readback; and caller alias stripping including the binding alias.

The schema-return-annotation, DTO→queue and queue→producer behavioral controls also passed. These retained a real property oracle and markers while removing the relevant behavior; the results now support a bounded semantic witness rather than source-review-only confidence. The raw JSON/typed-delegation and mutable-exception class repairs have their own executed 42, 7 and 6-case rows. Existing predictive-basis intake has 12 passing cases on this source.

The consumer seam deliberately captures trusted candidate context and terminates work with its named sentinel. This demonstrates the requested-intent bridge; it does not demonstrate that a data owner honoured the cursor, resolved a moving branch into an immutable basis or executed a temporal query. The fresh instances are in the same OS process, and their direct service/CAS reads are not authenticated HTTP POST/job/artifact GET coverage. The sealed route-proof fixture demonstrates the programmed authorization binding, not an external issuer or production permission.

Original TC-01/T01–T05 obligations therefore have useful bounded runtime evidence, but their full acceptance routes remain distinct: HTTP/generated surfaces, original-8db-qualified predictive-v2 full snapshot/hash/profile/authorization golden and same-authorized-key POST retry/conflict are not established by these passing rows. Runtime artifact materialization/selected replay is exercised; schema/producer governance registration and full TC T06–T16/provider/Legal/closure consumers are not silently accepted by its existence. The current component should no longer be called wholly `producer_missing` or wholly unrun; actual data-view consumption remains the separate `producer_missing` / `bridge_missing` / `consumer_missing` residual.

## Five remaining failures and their boundaries

All source pointers below refer to immutable `a8bee9746d0ea6c9582648b60944f8a4a27eb31e`, not C57's later proposal.

### Three initial-refusal publication failures — product caller/owner mismatch

Failing nodes are the two parametrizations of `test_unestablished_attempt_band_refuses_before_evaluation_safety_or_n4` and `test_authenticated_launch_binds_all_five_intent_bands_and_actor_scope`. The latter is one failed testcase with an internal case loop; its name is not proof that every band finished verification.

`job_diagnostics.py::_enqueue_job` derives `initially_refused` at lines 744–754 and correctly creates the record as failed at lines 816–841, with `nl_job_execution_intent_not_established` and a failed creation/outbox state. It subsequently emits diagnostic IDs and **unconditionally** calls `update_progress_state` at line 945, including for this already terminal failed record. `control_plane_store.py::_job_fence_where` at line 2115 permits unfenced lifecycle writes only for pending/running records; the update affects zero rows and `_require_fenced_write` raises at line 2133 / call site 6897. Full observed traces match that source path.

This is a real refusal-path publication defect in the composed source. The intended fail-closed refusal must return its typed failed/admission projection and diagnostic provenance without re-opening a job or raising an unrelated lease-loss exception. The general terminal/lost-lease write fence must remain intact. The existing C57 canonical writer owns the lifecycle/publication repair and companions; no local patch or second writer is commissioned here. The first two tests do not reach their later failed-state/no-evaluator/no-compiler assertions; those assertions must be reached after the repair before their defining properties can pass.

### Two terminal diagnostic fixture failures — attempted forbidden transition

Both `test_terminal_handler_diagnostic_rejects_foreign_and_replaced_attempt[completed]` and `[failed]` fail at test line 782. The test first completes/fails the job under its real lease, successfully exercises several terminal-diagnostic acceptance/rejection checks, and then calls `admin_store.mark_running` on that terminal row to manufacture a replacement attempt. `mark_running` at lines 5852–5875 permits only pending or expired-running rows; it correctly rejects the requested terminal→running transition.

The failure occurs in fixture setup for the later stale-attempt assertion. It is not evidence that the production terminal fence should be weakened. Preserve the intended foreign/malformed/stale-proof discriminators using a valid lifecycle setup or explicit bounded corruption fixture, and preserve terminal absorption/current-attempt semantics. The two tests remain FAIL until repaired and executed; their earlier assertions are not converted into full testcase PASS. They route to the existing C57 test/owner work alongside the publication mismatch.

No exact slice-base replay of these five nodes was performed by this reviewer, so none is labelled inherited. The aggregate affected gate remains FAIL while the individually evidenced temporal/raw/error properties retain their actual source-qualified results.

## Post-run state and evidence custody qualification

During independent readback, root continued its authorized Foundry composition and committed `aaefd17075b84ef45fbac6a56e04e29148e7e724`. Three files in the imported readset now differ in index/work from the run commit: `foundry/methods/api.py`, `foundry/methods/compiler/__init__.py`, and `foundry/methods/components/linker.py` under `policy-engine/src/polisyos/`. Their later bytes are **not** awarded this run's PASS. All 1,926 run-commit blob comparisons still match; the original Root Git/index/work receipt describes the completed run, not current mutable composition. The recorded current differences are not substituted into the historical source binding.

Eighteen of nineteen selected freeze pins still matched current bytes during review. The sole changed file was the live coordinator `LOCAL/raw/root-live-ownership-20261021.json` (run SHA `9ab1294c…`, observed later SHA `bdb4b805…`). The frozen runner source explicitly asserts all selected pin hashes **after the child completes and before writing the final audit**, followed by its run guard. The immutable audit contains that guard's head, source-frame identity and expected index. The retained harness uses this document as parent guard metadata; the native argv does not select it as a test fixture. This is source inspection, not an exhaustive runtime open-file trace. Current lease metadata drift is recorded separately and does not silently invalidate or rewrite the actual 149 outcomes. This review does not claim that the old full coordinator JSON bytes have been delivered merely because its hash survives; the captured guard/frame and native deciding outputs remain available.

Root should finish C57's existing source/test work, independently review it, then run its defining refusal/terminal cases and affected consumers on the composed source. Assess requalification of the shared progress/lifecycle consumers by the actual C57 footprint; do not repeat unchanged raw JSON/DTO/exception computations just for a new HEAD. The original request evidence remains pinned to its source even when a later bounded replay is needed. Actual provider/data inputs, current access and Legal-dependent claims remain separately unmet; independent G acceptance/formal closure remains outside this author review.

Pattern closeout: P01/P02 requested producer/bridge now witnessed; P05/P15 candidate intent retains its authority boundary; P07/P08 version/presence/time roles; P29 behavioral removal witnesses; P35 complete seven-module/149-case and 1,926 imported-Python denominators; P37/P38 current source versus historical proof and correct lifecycle fence versus invalid fixture setup; P40 route the remaining lifecycle class to one existing writer; P41 no inherited-red claim. No Git state, product source, task bindings, G decision or closure ledger was changed by this reviewer.
