"""Audit-only physical close/acquire race witness; no product edits."""

import asyncio
import errno
import os
from pathlib import Path

from polisyos.fabric.connectors.base import ConnectionConfig, ConnectionHandle, HealthStatus
from polisyos.fabric.connectors.pool import ConnectionPool, PoolClosedError, PoolConfig

WAIT = 5.0
SOURCE = Path(__file__).parents[9] / "src/polisyos/fabric/connectors/pool.py"


async def wait(event: asyncio.Event) -> None:
    await asyncio.wait_for(event.wait(), WAIT)


class GatedFDConnector:
    connector_id = "e02-close-race-oracle"

    def __init__(self) -> None:
        self.connect_started, self.allow_connect = asyncio.Event(), asyncio.Event()
        self.disconnect_started, self.allow_disconnect = asyncio.Event(), asyncio.Event()
        self.fd_closed = asyncio.Event()
        self.fd: int | None = None
        self.handle: ConnectionHandle | None = None
        self.disconnects = 0

    async def connect(self, config: ConnectionConfig) -> ConnectionHandle:
        self.connect_started.set()
        await wait(self.allow_connect)
        self.fd = os.open(config.url, os.O_RDONLY)
        self.handle = ConnectionHandle(connector_id=self.connector_id, config=config)
        return self.handle

    async def health_check(self, handle: ConnectionHandle) -> HealthStatus:
        return HealthStatus(healthy=True)

    async def disconnect(self, handle: ConnectionHandle) -> None:
        assert handle is self.handle and self.fd is not None
        self.disconnects += 1
        self.disconnect_started.set()
        await wait(self.allow_disconnect)
        os.close(self.fd)
        self.fd_closed.set()


async def probe() -> None:
    assert SOURCE.is_file(), SOURCE
    connector = GatedFDConnector()
    pool = ConnectionPool(
        lambda: connector,
        ConnectionConfig(url=str(SOURCE), max_connections=1),
        PoolConfig(max_size=1, validate_on_acquire=False, acquire_timeout_seconds=10),
    )
    acquire = close = None
    try:
        acquire = asyncio.create_task(pool.acquire())
        await wait(connector.connect_started)
        assert pool._active_acquires == 1 and pool._semaphore._value == 0
        generation = pool._generation
        close = asyncio.create_task(pool.close_all())
        async with asyncio.timeout(WAIT):
            while not pool.is_closed:
                await asyncio.sleep(0)
        assert pool._generation == generation + 1 and not close.done()
        connector.allow_connect.set()
        await wait(connector.disconnect_started)
        assert connector.fd is not None and os.pread(connector.fd, 1, 0)
        assert not close.done() and not acquire.done()
        assert len(pool._pending_cleanup) == 1
        assert next(iter(pool._pending_cleanup.values())).handle is connector.handle
        assert pool._semaphore._value == 0
        connector.allow_disconnect.set()
        await wait(connector.fd_closed)
        try:
            await asyncio.wait_for(acquire, WAIT)
        except PoolClosedError:
            pass
        else:
            raise AssertionError("closed-generation acquire published a handle")
        await asyncio.wait_for(close, WAIT)
        try:
            os.fstat(connector.fd)
        except OSError as exc:
            assert exc.errno == errno.EBADF
        else:
            raise AssertionError("close_all completed before physical FD closure")
        stats = pool.get_stats()
        assert connector.disconnects == 1
        assert stats.total_connections == stats.idle_connections == stats.in_use_connections == 0
        assert pool._active_acquires == 0
        assert not pool._in_use and not pool._idle and not pool._pending_cleanup
        assert pool._semaphore._value == 1
        try:
            await pool.acquire()
        except PoolClosedError:
            pass
        else:
            raise AssertionError("closed pool admitted another handle")
        assert pool._semaphore._value == 1
    finally:
        connector.allow_connect.set()
        connector.allow_disconnect.set()
        if close is None:
            close = asyncio.create_task(pool.close_all())
        await asyncio.wait_for(
            asyncio.gather(*(t for t in (acquire, close) if t is not None), return_exceptions=True), WAIT
        )
        if connector.fd is not None and not connector.fd_closed.is_set():
            os.close(connector.fd)


def test_b89_close_all_during_connect_retires_handle_and_reserved_permit() -> None:
    asyncio.run(probe())
