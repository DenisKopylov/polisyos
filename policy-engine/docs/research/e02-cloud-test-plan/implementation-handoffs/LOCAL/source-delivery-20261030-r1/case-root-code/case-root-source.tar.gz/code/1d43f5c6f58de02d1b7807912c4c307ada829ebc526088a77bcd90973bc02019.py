        def removed(*args, **kwargs):
            global _CALLS
            _CALLS += 1
            result = _ORIGINAL(*args, **kwargs)
            return dataclasses.replace(result, reasons=tuple(
                value for value in result.reasons
                if value != 'degradation_budget_consumption_mismatch'
            ))
