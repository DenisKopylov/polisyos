"""Read-only pytest hook to record the runtime-loaded PolicyOS Python input set."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import sys

def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()

def pytest_sessionfinish(session, exitstatus):
    project = Path(os.environ["POLISYOS_R4_INPUT_PROJECT_ROOT"]).resolve()
    input_dir = Path(os.environ["POLISYOS_R4_INPUT_READSET_DIR"])
    modules = {}
    for name, module in sorted(sys.modules.items()):
        raw = getattr(module, "__file__", None)
        if not raw:
            continue
        try:
            path = Path(raw).resolve(strict=True)
        except (OSError, RuntimeError):
            continue
        if path.suffix != ".py" or not path.is_file():
            continue
        try:
            relative = path.relative_to(project).as_posix()
        except ValueError:
            continue
        if not (relative.startswith("src/polisyos/") or relative.startswith("tests/") or relative.startswith("tools/")):
            continue
        modules[relative] = {"module_names": [], "sha256": _sha256(path)}
        modules[relative]["module_names"].append(name)
    records = [
        {"path": path, "sha256": modules[path]["sha256"],
         "module_names": sorted(modules[path]["module_names"])}
        for path in sorted(modules)
    ]
    own_path = Path(__file__).resolve()
    record = {
        "schema": "r4-runtime-loaded-python-readset-v1",
        "pid": os.getpid(),
        "phase": "native_child" if os.environ.get("POLISYOS_R4_CHILD") == "1" else "driver",
        "case_id": Path(os.environ.get("POLISYOS_R4_RECEIPT_DIR", "driver")).name,
        "capacity": os.environ.get("POLISYOS_R4_CAPACITY"),
        "bypass": os.environ.get("POLISYOS_R4_BYPASS"),
        "pytest_exitstatus": int(exitstatus),
        "argv": sys.argv,
        "project_root": str(project),
        "module_count": len(records),
        "source_module_count": sum(item["path"].startswith("src/polisyos/") for item in records),
        "test_module_count": sum(item["path"].startswith("tests/") for item in records),
        "tools_module_count": sum(item["path"].startswith("tools/") for item in records),
        "plugin_path": str(own_path),
        "plugin_sha256": _sha256(own_path),
        "modules": records,
    }
    input_dir.mkdir(parents=True, exist_ok=True)
    output = input_dir / f"input-readset-{os.getpid()}.json"
    output.write_text(json.dumps(record, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    print("R4_INPUT_READSET_SUMMARY=" + json.dumps({
        "pid": record["pid"], "phase": record["phase"], "case_id": record["case_id"],
        "capacity": record["capacity"], "bypass": record["bypass"],
        "module_count": record["module_count"],
        "source_module_count": record["source_module_count"],
        "test_module_count": record["test_module_count"],
        "tools_module_count": record["tools_module_count"],
        "readset_path": str(output),
    }, sort_keys=True), flush=True)
