def _run_random_loop(self, simulation_fn: Callable[..., Mapping[str, float]], nominal_params: Mapping[str, float], param_names: list[str], input_envelopes: Mapping[str, UncertaintyEnvelope], output_metric_ids: list[str], n_samples: int, batch_size: int, sample_buffers: _SampleBuffers, adaptive: Any, alpha: float, missing_outputs: dict[str, int], draw_outcomes: list[_DrawOutcomeRecord], evaluation_attempts: _EvaluationAttempts, empirical_spec: _EmpiricalJointSpec | None, gaussian_spec: _GaussianJointSpec | None) -> tuple[int, int]:
    gaussian_spec = None
    rng = jrandom.PRNGKey(self._config.mc_seed)
    generated = 0
    failed = 0
    while generated < n_samples:
        this_batch = self._adaptive_batch_size(generated=generated, batch_size=batch_size, remaining=n_samples - generated, adaptive=adaptive)
        batch_samples: dict[str, np.ndarray | jnp.ndarray] = {}
        if gaussian_spec is not None:
            rng, joint_key = jrandom.split(rng)
            standard = jrandom.normal(joint_key, shape=(this_batch, len(param_names)))
            joint = standard @ jnp.asarray(gaussian_spec.factor.T) + jnp.asarray(gaussian_spec.means)
            batch_samples.update({name: joint[:, i] for i, name in enumerate(param_names)})
        shared_indices: jnp.ndarray | None = None
        if empirical_spec is not None:
            rng, shared_key = jrandom.split(rng)
            shared_indices = jrandom.choice(shared_key, empirical_spec.sample_count, shape=(this_batch,), p=jnp.asarray(empirical_spec.probabilities, dtype=jnp.float32))
        for name in param_names:
            if gaussian_spec is not None:
                continue
            env = input_envelopes[name]
            if empirical_spec is not None and name in empirical_spec.names:
                assert shared_indices is not None
                selected_indices = np.asarray(shared_indices, dtype=np.intp)
                batch_samples[name] = empirical_spec.samples[name][selected_indices]
                continue
            rng, subkey = jrandom.split(rng)
            batch_samples[name] = self._sample_from_envelope(subkey, env, this_batch)
        for i in range(this_batch):
            params = dict(nominal_params)
            params.update({name: batch_samples[name][i] for name in param_names})
            sample_idx = generated + i
            ok = self._eval_and_record(simulation_fn, params, param_names, output_metric_ids, sample_buffers, sample_idx=sample_idx, missing_outputs=missing_outputs, draw_outcomes=draw_outcomes, evaluation_attempts=evaluation_attempts)
            if not ok:
                failed += 1
        generated += this_batch
        if adaptive.enabled and self._check_adaptive_stop(generated, adaptive, sample_buffers.values, output_metric_ids, alpha):
            return (generated, failed)
    return (n_samples, failed)
