"""Audit-only runner r4: verify actual branch/head/tree and full-repository source pins before native pytest; no canonical writes."""
from pathlib import Path
import argparse, datetime, hashlib, importlib.util, json, os, runpy, signal, subprocess, sys, time, xml.etree.ElementTree as ET
R=Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
P=R/"policy-engine"
N=P/"docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1"
O=Path(__file__).resolve().parent
S3_SELECTOR="tests/unit/runtime/quality/test_real_source_unit_join.py::test_real_source_keeps_subject_and_native_interval"
S3_TEST=Path("tests/unit/runtime/quality/test_real_source_unit_join.py")
S3_OWNER=Path("src/polisyos/runtime/quality/generation_cycle.py")
S3_TREATMENT=Path("src/polisyos/foundry/methods/catalog/causal/treatment_effects.py")
EXPECTED_S3_TEST_SHA256="332c5691fcbc966b76048abe4e44671d798f2ca8742ba13991fca58bfac50070"
EXPECTED_S3_TEST_BLOB="b416ae3d2501abd3a19ebbffafe989a5d3062562"
EXPECTED_S3_OWNER_SHA256="383f7e1b640e0c4144b5d17400979beb379ac4fc6e25a988b9dbeeaa1f694473"
EXPECTED_S3_OWNER_BLOB="deed43dc78109b73d7866bc951e1c055bccf47d9"
EXPECTED_S3_TREATMENT_SHA256="83c101402001d6eb4890b8a5740c6fba2d8fde10905f143ae1416760352133dc"
EXPECTED_S3_TREATMENT_BLOB="18dfda08673f322a021d0d2313f97c00112b33bb"
EXPECTED_BRANCH="codex/e02-unified-local-20261009"
EXPECTED_NATIVE_LIBRARY=P/".venv/lib/python3.14/site-packages/sklearn/.dylibs/libomp.dylib"
EXPECTED_NATIVE_SHA256="7fe04d06d824817d39e4c99ec44e837fd6b5f0f75f2cc3e77a384c298f3f1709"
C134_DIR=P/"tools/quality/testing/tc_sql_mc_witness"
C134_RAW=R/"LOCAL/raw/e02-execution-20261027/repairs/C134-tracked-helper-adoption-r4"
C134_SITE_SHA256="c39de7af3f237eba8fdd7b99c1af5bd95aa73d8c8a3c9dab7ec3dfcba16a8beb"
C134_ADMIT_SHA256="aabe68801ee20cd75e0e2b95f512596a58e0e4ecf2688bdf864c4158e43ec871"
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
save=lambda p,d: p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+"\n")
parser=argparse.ArgumentParser()
parser.add_argument("--head",required=True)
parser.add_argument("--tree",required=True)
parser.add_argument("plan",type=Path)
args=parser.parse_args()
EXPECTED_HEAD=args.head
EXPECTED_TREE=args.tree
plan_path=args.plan.resolve()
assert plan_path.is_absolute() and plan_path.parent==O
plan=json.loads(plan_path.read_text()); case=plan["case_id"]
assert case and all(c.isalnum() or c in "-_" for c in case)
assert len(EXPECTED_HEAD)==40 and len(EXPECTED_TREE)==40
assert plan.get("source_head")==EXPECTED_HEAD and plan.get("source_tree")==EXPECTED_TREE
assert plan.get("closure_ids")==[]
assert plan.get("nodes")==[S3_SELECTOR], "this runner is restricted to the one admitted S3 selector"
native_library=Path(plan.get("native_library_path", ""))
assert native_library.is_absolute() and native_library.resolve(strict=True)==EXPECTED_NATIVE_LIBRARY.resolve(strict=True)
assert plan.get("native_library_sha256")==EXPECTED_NATIVE_SHA256 and sha(native_library)==EXPECTED_NATIVE_SHA256
assert "DYLD_LIBRARY_PATH" not in plan.get("extra_env", {}), "loader path is injected only after sandbox-exec"
out=O/case; out.mkdir(exist_ok=False)
guard=runpy.run_path(str(N/"root-layer-lib.py"))["guard"]
live_path=R/"LOCAL/raw/root-live-ownership-20261021.json"
live=json.loads(live_path.read_text())
before=guard()
def git_identity():
 return {
  "branch":subprocess.check_output(["git","-C",str(R),"symbolic-ref","--short","HEAD"],text=True).strip(),
  "head":subprocess.check_output(["git","-C",str(R),"rev-parse","HEAD"],text=True).strip(),
  "tree":subprocess.check_output(["git","-C",str(R),"rev-parse","HEAD^{tree}"],text=True).strip(),
 }
source_identity_before=git_identity()
assert source_identity_before["branch"]==live["branch"]==EXPECTED_BRANCH
assert source_identity_before["head"]==live["head"]==before["head"]==plan["source_head"]==EXPECTED_HEAD
assert source_identity_before["tree"]==live["tree"]==plan["source_tree"]==EXPECTED_TREE
selected=plan["nodes"]; assert selected and len(selected)==len(set(selected))
test_paths=sorted({v.split("::")[0] for v in selected})
assert all(v.startswith("tests/") and (P/v).is_file() for v in test_paths)
assert sha(P/S3_TEST)==EXPECTED_S3_TEST_SHA256 and sha(P/S3_OWNER)==EXPECTED_S3_OWNER_SHA256
assert sha(P/S3_TREATMENT)==EXPECTED_S3_TREATMENT_SHA256
assert subprocess.check_output(["git","hash-object",str(P/S3_TEST)],cwd=R,text=True).strip()==EXPECTED_S3_TEST_BLOB
assert subprocess.check_output(["git","hash-object",str(P/S3_OWNER)],cwd=R,text=True).strip()==EXPECTED_S3_OWNER_BLOB
assert subprocess.check_output(["git","hash-object",str(P/S3_TREATMENT)],cwd=R,text=True).strip()==EXPECTED_S3_TREATMENT_BLOB
c134_site=C134_DIR/"sitecustomize.py"
c134_admit=C134_DIR/"source_admit.py"
assert sha(c134_site)==C134_SITE_SHA256 and sha(c134_admit)==C134_ADMIT_SHA256
observer=O/"readset_observer_tools_r1.py"
s3_observer=R/"LOCAL/raw/e02-execution-20261027/next-native/S3-current-local-r1/native-runner-r3/s3_bounded_phase_observer.py"
exception_control=R/"LOCAL/raw/e02-execution-20261027/next-native/S3-current-local-r1/native-runner-r3/exception_transparency_control.py"
exception_case=R/"LOCAL/raw/e02-execution-20261027/next-native/S3-current-local-r1/native-runner-r3/exception-control-actual-r4"
exception_result=exception_case/"result.json"
exception_payload=json.loads(exception_result.read_text())
exception_origin=Path(exception_payload["origin_receipt"]).resolve(strict=True)
assert exception_origin.is_relative_to(exception_case.resolve())
exception_child=json.loads(exception_payload["child"]["stdout"])
assert exception_payload["status"]=="PASS" and exception_payload["selected_return_callbacks"]==1
assert exception_payload["selected_fixture_rows"]==2 and exception_payload["helper_sitecustomize_sha256"]==C134_SITE_SHA256
assert exception_child["normal_return_identity_preserved"] and exception_child["exception_object_and_type_preserved"]
assert exception_child["exceptional_path_return_callback_count"]==0 and not exception_child["global_py_unwind_enabled"]
assert exception_child["local_selected_event_contract"]=="PY_RETURN only"
exception_origin_payload=json.loads(exception_origin.read_text())
exception_origin_capture=exception_origin_payload["actual_code_capture"]
assert exception_origin_capture["code_census_complete_for_observed_events"] and not exception_origin_capture["errors"]
assert sha(exception_origin)==exception_payload["origin_receipt_sha256"]
e02_observer=P/"docs/research/e02-cloud-test-plan/full-run/e02_observer.py"
pilot_script=R/"LOCAL/raw/e02-execution-20261027/cloud/C139/delivered/LOCAL/s3-r19-reduced-profile-recovery-20261028/return/helpers/pilot_lightgbm.py"
pilot_receipt=R/"LOCAL/raw/e02-execution-20261027/next-native/S3-current-local-r1/pilot-actual-r2/receipt.json"
pilot_stdout=pilot_receipt.parent/"lightgbm-real-fit.stdout.txt"
assert s3_observer.is_file() and e02_observer.is_file() and pilot_script.is_file() and pilot_receipt.is_file() and pilot_stdout.is_file()
pilot=json.loads(pilot_receipt.read_text())
assert pilot["monitor"]["status"]=="passed" and pilot["monitor"]["complete"] and pilot["monitor"]["return_code"]==0 and not pilot["monitor"]["aborted_reason"]
assert pilot["pilot_sha256"]==sha(pilot_script)
assert pilot["existing_openmp_library"]=={"path":str(EXPECTED_NATIVE_LIBRARY),"sha256":EXPECTED_NATIVE_SHA256}
source_pins={"files":[
 {"path":(Path("policy-engine")/S3_OWNER).as_posix(),"sha256":EXPECTED_S3_OWNER_SHA256,"git_blob":EXPECTED_S3_OWNER_BLOB},
 {"path":(Path("policy-engine")/S3_TREATMENT).as_posix(),"sha256":EXPECTED_S3_TREATMENT_SHA256,"git_blob":EXPECTED_S3_TREATMENT_BLOB},
 {"path":(Path("policy-engine")/S3_TEST).as_posix(),"sha256":EXPECTED_S3_TEST_SHA256,"git_blob":EXPECTED_S3_TEST_BLOB},
]}
source_pins_path=out/"s3-source-pins.json"; save(source_pins_path,source_pins)
admission_out=out/"source-admission"; admission_out.mkdir()
admission_scratch=out/"source-admission-scratch"
admission_cmd=[str(P/".venv/bin/python"),"-B",str(c134_admit),"--root",str(R),"--base",EXPECTED_HEAD,"--tree",EXPECTED_TREE,
               "--pins",str(source_pins_path),"--pins-sha256",sha(source_pins_path),"--out",str(admission_out),"--scratch",str(admission_scratch)]
admission_env={"PATH":os.environ.get("PATH",""),"HOME":os.environ.get("HOME",""),"LANG":os.environ.get("LANG","C.UTF-8"),"PYTHONDONTWRITEBYTECODE":"1"}
admission=subprocess.run(admission_cmd,cwd=R,capture_output=True,text=True,check=False,env=admission_env)
(admission_out/"command.stdout").write_text(admission.stdout,encoding="utf-8")
(admission_out/"command.stderr").write_text(admission.stderr,encoding="utf-8")
(admission_out/"command.exit").write_text(str(admission.returncode)+"\n",encoding="ascii")
if admission.returncode!=0: raise SystemExit("C134 source admission failed; see source-admission/command.*")
git_input_index=admission_scratch/"git-input-index.json"
assert git_input_index.is_file()
c134_out=out/"c134"; c134_out.mkdir()
monitor=P/"docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-postfix-709-q2-helper-actual-20261018/supervise.py"
launcher=out/"pytest_launcher.py"
runtime_metadata=out/"runtime-execution-metadata.json"
launcher.write_text("import importlib.util, json, os, pathlib, sys\nimport pytest\npath=pathlib.Path("+repr(str(observer))+")\nspec=importlib.util.spec_from_file_location('loaded_source_observer',path)\nplugin=importlib.util.module_from_spec(spec); spec.loader.exec_module(plugin)\nmetadata={'schema':'s3-native-pytest-runtime-v1','pid':os.getpid(),'ppid':os.getppid(),'sys_executable':sys.executable,'sys_version':sys.version,'pytest_version':pytest.__version__,'pytest_file':pytest.__file__,'argv':sys.argv,'dyld_library_path':os.environ.get('DYLD_LIBRARY_PATH')}\npathlib.Path(os.environ['S3_RUNTIME_METADATA_PATH']).write_text(json.dumps(metadata,sort_keys=True,indent=2)+'\\n',encoding='utf-8')\nif __name__ == '__main__':\n    raise SystemExit(pytest.main(sys.argv[1:],plugins=[plugin]))\n")
tmp=out/"tmp"; tmp.mkdir()
profile=out/"child.sb"
fragment=plan["sandbox_profile_fragment"]
assert type(fragment) is str and hashlib.sha256(fragment.encode()).hexdigest()==plan["sandbox_profile_fragment_sha256"]
fragment_path=out/"sandbox-fragment.sb"; fragment_path.write_text(fragment)
profile.write_text('(version 1)\n(allow default)\n(deny file-write*)\n(allow file-write* (subpath '+json.dumps(str(out))+'))\n(allow file-write* (literal "/dev/null"))\n'+fragment)
assert profile.read_text()==plan["sandbox_profile_text"] and sha(profile)==plan["sandbox_profile_sha256"]
pins=[P/"pytest.ini",P/"pyproject.toml",P/"uv.lock",Path(__file__),plan_path,observer,monitor,launcher,s3_observer,exception_control,
      exception_result,exception_origin,exception_case/"child.stdout.txt",exception_case/"child.stderr.txt",exception_case/"child.exit",e02_observer,
      pilot_script,pilot_receipt,pilot_stdout,native_library,c134_site,c134_admit,
      C134_RAW/"README.md",C134_RAW/"proposal-manifest.json",
      C134_RAW/"controls/final.stdout",C134_RAW/"controls/final.stderr",C134_RAW/"controls/final.exit",
      C134_RAW/"controls/startup.stdout",C134_RAW/"controls/startup.stderr",C134_RAW/"controls/startup.exit",
      C134_RAW/"controls/removal.stdout",C134_RAW/"controls/removal.stderr",C134_RAW/"controls/removal.exit",
      source_pins_path,admission_out/"source-admission.json",admission_out/"command.stdout",admission_out/"command.stderr",admission_out/"command.exit",git_input_index,
      P/S3_OWNER,P/S3_TREATMENT,P/S3_TEST,N/"root-layer-lib.py",R/"LOCAL/raw/root-live-ownership-20261021.json",R/before["source_frame"]["path"]]
input_pins={str(p.relative_to(R)):sha(p) for p in pins}
removed={}
for name in ["PYTHONPATH","PYTEST_ADDOPTS","PYTEST_PLUGINS","PYTEST_DISABLE_PLUGIN_AUTOLOAD","PYTHONHOME","VIRTUAL_ENV","DYLD_LIBRARY_PATH"]:
 if name in os.environ: removed[name]="present_removed"
 os.environ.pop(name,None)
extra_env=plan.get("extra_env",{})
assert extra_env.get("PYTEST_PLUGINS")=="e02_observer,s3_bounded_phase_observer"
python_paths=extra_env.get("PYTHONPATH","").split(os.pathsep)
assert python_paths[0]==str(C134_DIR) and str(s3_observer.parent) in python_paths and str(e02_observer.parent) in python_paths
assert extra_env.get("JAX_PLATFORMS")=="cpu"
assert extra_env.get("E02_OBSERVER_DIR")==str(out/"e02")
assert extra_env.get("S3_SEMANTIC_EVENTS")==str(out/"semantic.jsonl")
assert extra_env.get("S3_SEMANTIC_SUMMARY")==str(out/"semantic-summary.json")
assert "S3_RUNTIME_METADATA_PATH" not in extra_env
assert all(name not in extra_env for name in ["E02C_ROOT","E02C_OUT","E02C_INDEX","E02C_PHASE"])
env={"PYTHONDONTWRITEBYTECODE":"1","TMPDIR":str(tmp),"XDG_CACHE_HOME":str(tmp/"xdg"),"MPLCONFIGDIR":str(tmp/"mpl"),"NUMBA_CACHE_DIR":str(tmp/"numba"),"HYPOTHESIS_STORAGE_DIRECTORY":str(tmp/"hypothesis"),
     "PYTHONPYCACHEPREFIX":str(tmp/"empty-pycache"),"POLISYOS_R4_INPUT_PROJECT_ROOT":str(P),"POLISYOS_R4_INPUT_READSET_DIR":str(out/"readsets"),
     "SCIENTIST_TORCH_NUM_THREADS":"1","SCIENTIST_TORCH_NUM_INTEROP_THREADS":"1",**extra_env,
     "E02C_ROOT":str(R),"E02C_OUT":str(c134_out),"E02C_INDEX":str(git_input_index),"E02C_PHASE":case,
     "S3_RUNTIME_METADATA_PATH":str(runtime_metadata)}
argv=[str(P/".venv/bin/python"),"-B",str(launcher),"-o","cache_dir="+str(out/"pytest-cache"),"--benchmark-storage=file://"+str(out/"benchmarks"),"--basetemp",str(out/"basetemp"),"--junitxml="+str(out/"pytest.xml"),"--tb=short","--color=no","--maxfail=0",*selected]
actualargv=["/usr/bin/sandbox-exec","-f",str(profile),"/usr/bin/env","DYLD_LIBRARY_PATH="+str(native_library.parent),
            "E02C_ROOT="+str(R),"E02C_OUT="+str(c134_out),"E02C_INDEX="+str(git_input_index),"E02C_PHASE="+case,*argv]
spec=importlib.util.spec_from_file_location("audit_bounded_monitor",monitor)
s=importlib.util.module_from_spec(spec);sys.modules[spec.name]=s;spec.loader.exec_module(s)
s.RSS_CAP_BYTES=plan.get("rss_cap_bytes",2300*1024**2);s.DISK_FLOOR_BYTES=6*1024**3;s.SAMPLE_SECONDS=1.0
signal.signal(signal.SIGTERM,s.note_stop_signal);signal.signal(signal.SIGINT,s.note_stop_signal)
profile_freeze={"at":datetime.datetime.now(datetime.UTC).isoformat(),"before":before,"plan_sha256":sha(plan_path),"selected_input_pins":input_pins,
 "native_profile":"pytest.ini, default plugin autoload/importlib/strict markers; R4 read-only sys.modules observer plus E02 and S3 semantic observers; outputs redirected only; private empty pycache search prefix prevents stale canonical pyc reuse",
 "native_library":{"path":str(native_library),"sha256":sha(native_library),"source":"verified existing LightGBM pilot receipt; one exact sklearn/.dylibs/libomp.dylib path only"},
 "sandbox_profile":{"path":str(profile.relative_to(R)),"text":profile.read_text(),"sha256":sha(profile),"fragment_path":str(fragment_path.relative_to(R)),"fragment_text":fragment,"fragment_sha256":sha(fragment_path)},
 "cleared_ambient_control_names":removed,"extra_env":env,"numeric_threads":s.NUMERIC_THREADS,"argv":argv,
 "actualargv":actualargv,"runtime_metadata_path":str(runtime_metadata.relative_to(R)),"cwd":str(P),"scope":plan["scope"],
 "unresolved_by_construction":["unimported source and arbitrary executable parser/plugin inputs are not a repository-wide runtime census","observer records src/polisyos, tests and tools Python modules; external package modules are outside this observer selection","this is an audit-specific source/profile freeze, not E02 global acceptance"],"closure_ids":[]}
profile_freeze["c134_source_admission"]={"command":admission_cmd,"return_code":admission.returncode,"stdout":admission.stdout,"stderr":admission.stderr,
 "receipt_path":str((admission_out/"source-admission.json").relative_to(R)),"receipt_sha256":sha(admission_out/"source-admission.json"),
 "git_input_index_path":str(git_input_index.relative_to(R)),"git_input_index_sha256":sha(git_input_index)}
profile_freeze["c134_bounded_monitor"]={"sitecustomize_path":str(c134_site.relative_to(R)),"sitecustomize_sha256":sha(c134_site),
 "source_admit_path":str(c134_admit.relative_to(R)),"source_admit_sha256":sha(c134_admit),
 "startup_env_assignments_in_actualargv":{k:env[k] for k in ["E02C_ROOT","E02C_OUT","E02C_INDEX","E02C_PHASE"]},
 "selection":"C134 PY_START/DISABLE discovery and source-authenticated local PY_RETURN; no PY_UNWIND"}
save(out/"source-profile-freeze.json",profile_freeze)
prelaunch_freeze_sha=sha(out/"source-profile-freeze.json")
started=time.monotonic()
result=s.run_command(out,case,actualargv,P,started,started+plan.get("deadline_seconds",600),env)
if (out/"pytest.xml").exists():
 cases=list(ET.parse(out/"pytest.xml").iter("testcase"))
 result["junit"]={"tests":len(cases),"failures":sum(q.find("failure") is not None for q in cases),"errors":sum(q.find("error") is not None for q in cases),"skipped":sum(q.find("skipped") is not None for q in cases)}
 result["skips"]=[{"node":q.get("classname","")+"::"+q.get("name",""),"reason":q.find("skipped").get("message","")} for q in cases if q.find("skipped") is not None]
readsets=[]; mismatches=[];seen={}
for f in sorted((out/"readsets").glob("*.json")):
 d=json.loads(f.read_text())
 readsets.append({"path":str(f.relative_to(R)),"sha256":sha(f),"python_paths":len(d["modules"]),"pytest_exitstatus":d["pytest_exitstatus"]})
 for row in d["modules"]:
  path=P/row["path"]
  actual=sha(path) if path.is_file() else None
  if actual!=row["sha256"]:mismatches.append({"path":str(path.relative_to(R)),"run":row["sha256"],"current":actual})
  seen[row["path"]]=row["sha256"]
assert all(sha(R/path)==digest for path,digest in input_pins.items()),"selected input mutation"
after=guard()
source_identity_after=git_identity()
assert source_identity_after==source_identity_before, "branch/HEAD/tree changed during S3 execution"
runtime=None
runtime_sha=None
if runtime_metadata.is_file():
 runtime=json.loads(runtime_metadata.read_text()); runtime_sha=sha(runtime_metadata)
 profile_freeze["observed_child_runtime_metadata"]=runtime
 profile_freeze["observed_child_runtime_metadata_sha256"]=runtime_sha
 profile_freeze["prelaunch_source_profile_freeze_sha256"]=prelaunch_freeze_sha
 save(out/"source-profile-freeze.json",profile_freeze)
runtime_interpreter_matches=bool(runtime and Path(runtime["sys_executable"]).resolve()==(P/".venv/bin/python").resolve())
runtime_loader_matches=bool(runtime and runtime["dyld_library_path"]==str(native_library.parent))
runtime_pytest_origin_local=bool(runtime and Path(runtime["pytest_file"]).resolve().is_relative_to((P/".venv").resolve()))
runtime_matches=runtime_interpreter_matches and runtime_loader_matches and runtime_pytest_origin_local and bool(runtime and runtime["pytest_version"])
semantic_summary_path=out/"semantic-summary.json"
semantic_summary=json.loads(semantic_summary_path.read_text()) if semantic_summary_path.is_file() else None
origin_files=sorted((c134_out/"origins").glob(f"{case}-*.json")) if (c134_out/"origins").is_dir() else []
origin_receipts=[{"path":str(f.relative_to(R)),"sha256":sha(f),"value":json.loads(f.read_text())} for f in origin_files]
main_pid=runtime.get("pid") if runtime else None
main_origins=[row for row in origin_receipts if row["value"].get("pid")==main_pid]
main_capture=main_origins[0]["value"].get("actual_code_capture",{}) if len(main_origins)==1 else {}
c134_main_complete=bool(main_capture.get("code_census_complete_for_observed_events") and not main_capture.get("errors"))
required_semantic_events={"actual_aipw_return","actual_fresh_consumer_return","actual_selected_case_return","actual_adversarial_selected_ref"}
observed_event_kinds=(semantic_summary or {}).get("event_kinds",{})
semantic_complete=bool(semantic_summary and required_semantic_events.issubset(observed_event_kinds)
 and not observed_event_kinds.get("observer_error")
 and semantic_summary.get("sitecustomize_path")==str(c134_site.resolve())
 and semantic_summary.get("sitecustomize_sha256")==C134_SITE_SHA256)
record={"plan":plan,
 "source_admission":{"command":admission_cmd,"environment":admission_env,"return_code":admission.returncode,"stdout":admission.stdout,"stderr":admission.stderr,
  "receipt_path":str((admission_out/"source-admission.json").relative_to(R)),"receipt_sha256":sha(admission_out/"source-admission.json"),
  "pins_path":str(source_pins_path.relative_to(R)),"pins_sha256":sha(source_pins_path),
  "git_index_path":str(git_input_index.relative_to(R)),"git_index_sha256":sha(git_input_index)},
 "source_profile_freeze_sha256":sha(out/"source-profile-freeze.json"),"prelaunch_source_profile_freeze_sha256":prelaunch_freeze_sha,
 "runtime_metadata":{"path":str(runtime_metadata.relative_to(R)),"sha256":runtime_sha,"value":runtime,"interpreter_matches_venv":runtime_interpreter_matches,
  "loader_path_matches_pilot":runtime_loader_matches,"pytest_origin_under_venv":runtime_pytest_origin_local,"metadata_complete":runtime_matches},
 "c134_origin_receipts":origin_receipts,"main_c134_code_census_complete":c134_main_complete,
 "semantic_summary":{"path":str(semantic_summary_path.relative_to(R)) if semantic_summary else None,
  "sha256":sha(semantic_summary_path) if semantic_summary else None,"value":semantic_summary},"semantic_capture_complete":semantic_complete,
 "result":result,"readsets":readsets,"unique_runtime_loaded_python_paths":len(seen),"current_mismatches":mismatches,"guard_before":before,"guard_after":after,
  "source_identity_before":source_identity_before,"source_identity_after":source_identity_after,
 "scope":"Fresh canonical-source S3 selector run using C134 bounded source-authenticated monitoring and task-local hash-pinned existing OpenMP loader; finite imported src/tests/tools readset, not repository-wide or all-backend proof.","closure_ids":[]}
save(out/"audit-result.json",record)
print(json.dumps({"case":case,"exit":result["return_code"],"complete":result["complete"],"abort":result["aborted_reason"],"junit":result.get("junit"),"seconds":result["wall_seconds"],"peak_rss":result["max_sampled_process_tree_rss_bytes"],"runtime_py":len(seen),"runtime_metadata":runtime_sha,"runtime_interpreter_matches_venv":runtime_interpreter_matches,"runtime_loader_matches_pilot":runtime_loader_matches,"runtime_pytest_origin_under_venv":runtime_pytest_origin_local,"runtime_metadata_complete":runtime_matches,"mismatches":len(mismatches),"audit_result_sha256":sha(out/"audit-result.json")}),flush=True)
raise SystemExit(0 if result["return_code"]==0 and result["complete"] and not result["aborted_reason"] and not mismatches and runtime_matches and c134_main_complete and semantic_complete and origin_receipts else 1)

