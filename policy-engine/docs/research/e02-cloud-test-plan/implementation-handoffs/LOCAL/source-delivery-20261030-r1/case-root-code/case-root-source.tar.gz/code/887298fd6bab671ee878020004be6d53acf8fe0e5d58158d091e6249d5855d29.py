        def removed(*args, **kwargs):
            global _CALLS
            _CALLS += 1
            result = _ORIGINAL(*args, **kwargs)
            payload = json.loads(result.payload_json)
            payload['invalidation_events'] = []
            from polisyos.ddm.calibration.observations import CalibrationObservationWindow
            normalized = CalibrationObservationWindow.model_validate(payload).model_dump_json()
            binding = result.binding.model_copy(update={
                'payload_sha256': hashlib.sha256(normalized.encode()).hexdigest(),
            })
            return dataclasses.replace(result, payload_json=normalized, binding=binding)
