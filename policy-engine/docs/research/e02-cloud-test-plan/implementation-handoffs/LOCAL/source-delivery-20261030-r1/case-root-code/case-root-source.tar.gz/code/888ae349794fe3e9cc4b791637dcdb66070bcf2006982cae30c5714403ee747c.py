"""Audit-only original B89 cancellation after permit/before metadata registration."""

import asyncio

from polisyos.fabric.connectors.base import ConnectionConfig, ConnectionHandle, HealthStatus
from polisyos.fabric.connectors.pool import ConnectionPool, PoolConfig


async def probe() -> None:
    acquired = asyncio.Event()
    calls = {"connect": 0, "disconnect": 0}

    class Connector:
        connector_id = "e02-post-permit-lock-oracle"

        async def connect(self, config: ConnectionConfig) -> ConnectionHandle:
            calls["connect"] += 1
            return ConnectionHandle(connector_id=self.connector_id, config=config)

        async def health_check(self, handle: ConnectionHandle) -> HealthStatus:
            return HealthStatus(healthy=True)

        async def disconnect(self, handle: ConnectionHandle) -> None:
            calls["disconnect"] += 1

    connector = Connector()
    pool = ConnectionPool(
        lambda: connector,
        ConnectionConfig(url="audit-only://post-permit-lock", max_connections=1),
        PoolConfig(max_size=1, validate_on_acquire=False, acquire_timeout_seconds=10),
    )

    class HandoffSemaphore(asyncio.BoundedSemaphore):
        gated = True

        async def acquire(self) -> bool:
            result = await super().acquire()
            if self.gated:
                # In the same task, after real permit acquisition and before return to owner.
                await pool._lock.acquire()
                acquired.set()
            return result

    semaphore = HandoffSemaphore(1)
    pool._semaphore = semaphore
    task = asyncio.create_task(pool.acquire())
    try:
        await asyncio.wait_for(acquired.wait(), 5)
        # The public owner has returned from semaphore.acquire and is waiting for metadata.
        assert semaphore._value == 0 and pool._lock.locked() and not task.done()
        assert pool._active_acquires == 0 and calls["connect"] == 0
        assert not pool._in_use and not pool._pending_cleanup
        task.cancel()
        await asyncio.sleep(0)
        semaphore.gated = False
        pool._lock.release()
        try:
            await asyncio.wait_for(task, 5)
        except asyncio.CancelledError:
            pass
        else:
            raise AssertionError("cancellation was converted into success")
        assert semaphore._value == 1 and pool._active_acquires == 0
        assert calls == {"connect": 0, "disconnect": 0}
        assert not pool._in_use and not pool._idle and not pool._pending_cleanup
        handle = await asyncio.wait_for(pool.acquire(), 5)
        assert semaphore._value == 0 and calls["connect"] == 1
        await asyncio.wait_for(pool.release(handle), 5)
        await asyncio.wait_for(pool.close_all(), 5)
        assert semaphore._value == 1 and calls == {"connect": 1, "disconnect": 1}
    finally:
        semaphore.gated = False
        if pool._lock.locked():
            pool._lock.release()
        if not task.done():
            task.cancel()
        await asyncio.wait_for(asyncio.gather(task, return_exceptions=True), 5)
        await asyncio.wait_for(pool.close_all(), 5)


def test_b89_cancel_after_permit_before_metadata_returns_slot_once() -> None:
    asyncio.run(probe())
