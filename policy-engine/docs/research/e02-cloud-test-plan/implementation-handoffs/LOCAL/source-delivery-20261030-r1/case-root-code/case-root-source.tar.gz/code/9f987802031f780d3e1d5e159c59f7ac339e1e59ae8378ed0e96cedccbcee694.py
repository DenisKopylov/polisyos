import runpy, sys
sys.argv[0] = '/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos/LOCAL/raw/e02-execution-20261027/runtime-prep/R166-basis-mapping-removal-r2/pytest_launcher.py'
runpy.run_path(sys.argv[0], run_name='__main__')
