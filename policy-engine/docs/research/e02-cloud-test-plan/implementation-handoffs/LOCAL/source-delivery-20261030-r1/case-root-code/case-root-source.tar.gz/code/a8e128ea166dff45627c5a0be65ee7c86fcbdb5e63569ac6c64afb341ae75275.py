import importlib.util, pathlib, sys
import pytest
path=pathlib.Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos/policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/r4-competing-workload-oracle-20261027-r1/readset-instrumentation-r1/r4_readset_plugin.py')
spec=importlib.util.spec_from_file_location('loaded_source_observer',path)
plugin=importlib.util.module_from_spec(spec); spec.loader.exec_module(plugin)
import faulthandler
faulthandler.dump_traceback_later(5,repeat=True,file=sys.stderr)
raise SystemExit(pytest.main(sys.argv[1:],plugins=[plugin]))
