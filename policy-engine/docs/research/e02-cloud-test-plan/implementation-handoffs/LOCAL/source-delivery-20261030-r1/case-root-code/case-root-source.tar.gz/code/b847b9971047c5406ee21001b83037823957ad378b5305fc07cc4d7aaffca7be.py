import importlib.util, pathlib, sys
import pytest
paths=('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos/policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1/readset_observer_tools_r1.py','/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos/LOCAL/raw/e02-execution-20261027/repairs/C07-policy-relation-r2/c07_adapter_exception_observer.py')
plugins=[]
for index, raw in enumerate(paths):
    path=pathlib.Path(raw)
    spec=importlib.util.spec_from_file_location('audit_observer_'+str(index),path)
    plugin=importlib.util.module_from_spec(spec); spec.loader.exec_module(plugin)
    plugins.append(plugin)
if __name__ == '__main__':
    raise SystemExit(pytest.main(sys.argv[1:],plugins=plugins))
