"""Task-private R2 observer overlay; copy only for the admitted local run.

This module intentionally imports only the standard library at import time.
It is not product code and is not installed in the checkout by this packet.
"""

from __future__ import annotations

import atexit
import hashlib
import importlib
import json
import os
import subprocess
import sys
import threading
import time
from pathlib import Path
from types import CodeType, FrameType, ModuleType
from typing import Any


_ROOT = Path(os.environ.get("E02_C104_ROOT", "")).resolve()
_OBS = Path(os.environ.get("E02_C104_OBSERVATION_DIR", "")).resolve()
_HEAD = os.environ.get("E02_C104_EXPECTED_HEAD", "")
_TREE = os.environ.get("E02_C104_EXPECTED_TREE", "")
_PHASE = os.environ.get("E02_C104_PHASE", "")
_TRANSPORT = "tests.unit.scientist.orchestration.engine.runner.decimal_worker_transport"
_PREPARED = "tests.unit.scientist.orchestration.engine.test_prepared_b_removal_controls"
_TYPED_TEST = "tests.unit.scientist.orchestration.engine.runner.test_serialization_e02"
_OVERLAY = "policy-engine/tests/_helpers/r2_source_observer.py"
_SOURCE_PREFIXES = ("policy-engine/src/", "policy-engine/tests/", "policy-engine/tools/")

_EXPECTED = {
    "polisyos.scientist.orchestration.engine.runner._activity_worker:run_node_in_worker_sync",
    "polisyos.scientist.orchestration.engine.runner._activity_worker:run_node_in_worker",
    "polisyos.scientist.orchestration.engine.runner.serialization:deserialize_state",
    "polisyos.scientist.orchestration.engine.runner.serialization:serialize_outcome",
    "polisyos.scientist.orchestration.engine.registry:discover_nodes",
    "polisyos.scientist.orchestration.engine.retry:execute_with_retry_async",
    "polisyos.scientist.orchestration.engine.retry:_execute_with_timeout_process",
    f"{_TRANSPORT}:execute_decimal_worker",
    f"{_TRANSPORT}:execute_decimal_worker_without_budget_tag",
    f"{_TRANSPORT}:DecimalTransportNode.execute",
}
_PHASE_NODES = {
    "typed-worker": {
        f"{_TYPED_TEST}::test_real_worker_process_consumes_state_and_emits_exact_typed_outcome[stdlib]",
        f"{_TYPED_TEST}::test_real_worker_process_consumes_state_and_emits_exact_typed_outcome[orjson]",
    },
    "prepared-removal": {
        f"{_PREPARED}::test_branch_isolation_removal_leaks_to_real_parallel_sibling",
        f"{_PREPARED}::test_merge_operation_removal_is_red_for_direct_and_executor_replay",
        f"{_PREPARED}::test_replay_proof_removal_admits_stale_real_cache_to_fresh_reader",
        f"{_PREPARED}::test_current_wire_schema_removal_accepts_unknown_version_with_markers",
        f"{_PREPARED}::test_typed_decimal_refusal_survives_actual_worker_and_marker_removal",
        f"{_PREPARED}::test_worker_merge_conflict_removal_changes_real_typed_receiver",
    },
}


def _canonical_nodeid(item: Any, root: Path, pytest_root: Path) -> str:
    """Bind pytest's file-path node ID to the collected module's exact source."""
    nodeid = getattr(item, "nodeid", None)
    if not isinstance(nodeid, str):
        raise RuntimeError("C104 collected item has no textual pytest node ID")
    file_locator, separator, node_suffix = nodeid.partition("::")
    if not separator or not file_locator or not node_suffix:
        raise RuntimeError(f"C104 collected item has a malformed pytest node ID: {nodeid!r}")

    item_path = Path(item.path).resolve()
    pytest_root = Path(pytest_root).resolve()
    node_path = Path(file_locator)
    if not node_path.is_absolute():
        node_path = pytest_root / node_path
    if node_path.resolve() != item_path:
        raise RuntimeError("C104 pytest node file locator differs from the collected item's path")

    tests_root = (Path(root).resolve() / "policy-engine" / "tests").resolve()
    try:
        relative = item_path.relative_to(tests_root)
    except ValueError as exc:
        raise RuntimeError("C104 selected item is outside the admitted tests tree") from exc
    if relative.suffix != ".py":
        raise RuntimeError("C104 selected item does not resolve to a Python source file")

    module = getattr(item, "module", None)
    module_name = getattr(module, "__name__", None)
    module_origin = getattr(module, "__file__", None)
    expected_module = "tests." + relative.with_suffix("").as_posix().replace("/", ".")
    if module_name != expected_module or not module_origin or Path(module_origin).resolve() != item_path:
        raise RuntimeError("C104 pytest item module name/origin differs from its exact collected source")
    return f"{module_name}::{node_suffix}"

_lock = threading.RLock()
_pid = os.getpid()
_frames: dict[str, dict[str, Any]] = {}
_code_refs: dict[str, CodeType] = {}
_modules: set[tuple[str, str]] = set()
_events: list[dict[str, Any]] = []
_flushed = False
_profile_guard = threading.local()
_original_execute: Any = None
_original_without: Any = None
_role = "observer-process"
_previous_profile: Any = sys.getprofile()


def _same_code_object(actual: CodeType | None, expected: CodeType | None) -> bool:
    """Compare actual code object identity within one process only."""
    return actual is not None and expected is not None and actual is expected


def observation_path_for_pid(pid: int) -> Path:
    """Return the one configured observer receipt path for a process."""
    return _OBS / f"source-observer-{pid}.json"


def _check_environment() -> None:
    if not _ROOT.is_dir() or not _OBS.is_dir() or not _HEAD or not _TREE:
        raise RuntimeError("C104 observer environment is incomplete")
    if "E02_B_PROPERTY_REMOVAL" in os.environ:
        raise RuntimeError("C104 requires E02_B_PROPERTY_REMOVAL to be absent")
    actual_head = subprocess.check_output(
        ["git", "-C", str(_ROOT), "rev-parse", "HEAD"], text=True
    ).strip()
    actual_tree = subprocess.check_output(
        ["git", "-C", str(_ROOT), "rev-parse", "HEAD^{tree}"], text=True
    ).strip()
    if (actual_head, actual_tree) != (_HEAD, _TREE):
        raise RuntimeError(
            f"C104 source mismatch: expected {_HEAD}/{_TREE}, "
            f"observed {actual_head}/{actual_tree}"
        )


def _reset_after_fork() -> None:
    global _pid, _frames, _code_refs, _modules, _events, _flushed
    current = os.getpid()
    if current != _pid:
        _pid = current
        _frames = {}
        _code_refs = {}
        _modules = set()
        _events = []
        _flushed = False


def _inside_root(path: Path) -> bool:
    try:
        path.resolve().relative_to(_ROOT)
        return True
    except ValueError:
        return False


def _repo_relative(path: Path) -> str | None:
    try:
        rel = path.resolve().relative_to(_ROOT).as_posix()
    except ValueError:
        return None
    return rel if rel.startswith(_SOURCE_PREFIXES) else None


def _record_census(checkpoint: str) -> None:
    _reset_after_fork()
    with _lock:
        for name, module in tuple(sys.modules.items()):
            if not (name == "polisyos" or name.startswith("polisyos.") or name == "tests" or name.startswith("tests.")):
                continue
            path = _module_path(module)
            rel = _repo_relative(path) if path is not None else None
            if rel is not None:
                _modules.add((name, rel))
        _events.append(
            {"event": "module_census", "checkpoint": checkpoint, "pid": os.getpid(), "time_ns": time.time_ns()}
        )


def _module_path(module: ModuleType) -> Path | None:
    spec = getattr(module, "__spec__", None)
    origin = getattr(spec, "origin", None) if spec is not None else None
    if not origin or origin in {"built-in", "frozen"}:
        origin = getattr(module, "__file__", None)
    if not origin:
        return None
    path = Path(origin)
    return path if path.is_absolute() and _inside_root(path) else None


def _profile(frame: FrameType, event: str, _arg: Any) -> None:
    _reset_after_fork()
    if event != "call" or getattr(_profile_guard, "active", False):
        return
    module = frame.f_globals.get("__name__", "")
    key = f"{module}:{frame.f_code.co_qualname}"
    if key not in _EXPECTED:
        return
    path = Path(frame.f_code.co_filename)
    rel = _repo_relative(path) if path.is_absolute() else None
    if rel is None:
        return
    code_key = f"{os.getpid()}:{id(frame.f_code)}"
    with _lock:
        _code_refs[code_key] = frame.f_code
        _frames.setdefault(
            code_key,
            {
                "pid": os.getpid(),
                "ppid": os.getppid(),
                "module": module,
                "qualname": frame.f_code.co_qualname,
                "first_line": frame.f_code.co_firstlineno,
                "observed_line": frame.f_lineno,
                "repo_path": rel,
                "is_code_type": isinstance(frame.f_code, CodeType),
                "code_object_id_process_local": id(frame.f_code),
                "call_count": 0,
            },
        )["call_count"] += 1


def _resolve_qualname(module: ModuleType, qualname: str) -> Any:
    value: Any = module
    for part in qualname.split("."):
        if part == "<locals>":
            return None
        value = getattr(value, part, None)
        if value is None:
            return None
    return value


def _source_identity(rel: str) -> dict[str, Any]:
    actual = (_ROOT / rel).read_bytes()
    result: dict[str, Any] = {
        "path": rel,
        "actual_bytes": len(actual),
        "actual_sha256": hashlib.sha256(actual).hexdigest(),
    }
    if rel == _OVERLAY:
        result["classification"] = "task-authored-observer-overlay"
        return result
    try:
        blob = subprocess.check_output(
            ["git", "-C", str(_ROOT), "rev-parse", f"{_HEAD}:{rel}"],
            text=True,
            stderr=subprocess.PIPE,
        ).strip()
        expected = subprocess.check_output(
            ["git", "-C", str(_ROOT), "cat-file", "blob", blob],
            stderr=subprocess.PIPE,
        )
    except subprocess.CalledProcessError as exc:
        detail = exc.stderr or ""
        if isinstance(detail, bytes):
            detail = detail.decode(errors="replace")
        result.update({"classification": "SOURCE_ERROR", "git_error": str(detail)[-500:]})
        return result
    result.update(
        {
            "git_blob": blob,
            "git_bytes": len(expected),
            "git_sha256": hashlib.sha256(expected).hexdigest(),
            "matches_current_head": actual == expected,
            "classification": "tracked-source" if actual == expected else "SOURCE_ERROR",
        }
    )
    return result


def _flush(reason: str) -> None:
    global _flushed
    _reset_after_fork()
    with _lock:
        if _flushed:
            return
        _flushed = True
        frame_rows = list(_frames.values())
        module_rows = [{"module": name, "path": rel} for name, rel in sorted(_modules)]
        code_refs = dict(_code_refs)
        events = list(_events)

    paths = {row["path"] for row in module_rows}
    paths.update(row["repo_path"] for row in frame_rows)
    identities = {path: _source_identity(path) for path in sorted(paths)}
    for row in frame_rows:
        code = code_refs.get(f"{row['pid']}:{row['code_object_id_process_local']}")
        module = sys.modules.get(row["module"])
        resolved = _resolve_qualname(module, row["qualname"]) if module is not None else None
        row["same_process_function_code_identity"] = _same_code_object(
            code, getattr(resolved, "__code__", None)
        )
        row["identity_kind"] = "in-process CodeType object identity; do not compare across PIDs"

    payload = {
        "schema": "policyos.e02.c104.local_source_observer.v1",
        "phase": _PHASE,
        "reason": reason,
        "source": {"head": _HEAD, "tree": _TREE},
        "process": {
            "role": _role,
            "pid": os.getpid(),
            "ppid": os.getppid(),
            "python": sys.version,
            "executable": sys.executable,
            "argv": sys.argv,
            "cwd": os.getcwd(),
            "sys_path": sys.path,
            "named_controls": {
                name: os.environ.get(name)
                for name in (
                    "E02_C104_ROOT",
                    "E02_C104_EXPECTED_HEAD",
                    "E02_C104_EXPECTED_TREE",
                    "E02_C104_PHASE",
                    "E02_C104_OBSERVATION_DIR",
                    "PYTHONPYCACHEPREFIX",
                    "E02_B_PROPERTY_REMOVAL",
                )
            },
        },
        "module_origins": module_rows,
        "target_code_frames": frame_rows,
        "source_identities": list(identities.values()),
        "events": events,
        "limitations": [
            "module census is bounded to loaded in-repository source modules observed by this process",
            "code object identity is process-local; no marshal digest is used as a stable cross-run identity",
            "the native supervisor separately records process ancestry, resource samples, sandbox, stdout/stderr, JUnit and child receipts",
        ],
    }
    out = observation_path_for_pid(os.getpid())
    out.write_text(json.dumps(payload, sort_keys=True, separators=(",", ":")) + "\n", encoding="utf-8")


def _shutdown_profile(reason: str) -> None:
    """Restore the prior thread profile before Python module teardown begins."""
    if sys.getprofile() is _profile:
        sys.setprofile(_previous_profile)
    _flush(reason)


def _install_profile() -> None:
    _check_environment()
    _record_census("observer-import")
    sys.setprofile(_profile)


def _load_originals() -> tuple[Any, Any, ModuleType]:
    global _original_execute, _original_without
    module = importlib.import_module(_TRANSPORT)
    if _original_execute is None:
        candidate = getattr(module, "execute_decimal_worker")
        if candidate is not wrapped_execute:
            _original_execute = candidate
    if _original_without is None:
        candidate = getattr(module, "execute_decimal_worker_without_budget_tag")
        if candidate is not wrapped_without_budget_tag:
            _original_without = candidate
    if _original_execute is None or _original_without is None:
        raise RuntimeError("C104 observer could not resolve the original worker helpers")
    return _original_execute, _original_without, module


def wrapped_execute(*args: Any, **kwargs: Any) -> Any:
    global _role
    _role = "outer-worker:execute_decimal_worker"
    _install_profile()
    execute, _without, _module = _load_originals()
    _record_census("worker-helper-imported")
    try:
        return execute(*args, **kwargs)
    finally:
        _record_census("worker-helper-return")
        _flush("worker-helper-return")


def wrapped_without_budget_tag(*args: Any, **kwargs: Any) -> Any:
    global _role
    _role = "outer-worker:execute_decimal_worker_without_budget_tag"
    _install_profile()
    _execute, without, module = _load_originals()
    _record_census("worker-helper-imported")
    current = getattr(module, "execute_decimal_worker")
    try:
        # The original mutant delegates to the ordinary helper by module global.
        # Restore only that exact binding for this child call to avoid recursion.
        module.execute_decimal_worker = _execute
        return without(*args, **kwargs)
    finally:
        module.execute_decimal_worker = current
        _record_census("worker-helper-return")
        _flush("worker-helper-return")


def pytest_sessionstart(session: Any) -> None:
    _record_census("pytest-session-start")


def pytest_collection_modifyitems(session: Any, config: Any, items: list[Any]) -> None:
    global _original_execute, _original_without
    if _PHASE not in _PHASE_NODES:
        raise RuntimeError(f"unsupported C104 phase {_PHASE!r}")
    # Collection imports the selected module before this hook. Record its actual
    # source before comparing canonical module names with pytest file node IDs.
    _record_census("pytest-collection-items-loaded")
    actual = {_canonical_nodeid(item, _ROOT, Path(config.rootpath)) for item in items}
    expected = _PHASE_NODES[_PHASE]
    if actual != expected:
        raise RuntimeError(
            f"C104 selected node mismatch for {_PHASE}: "
            f"expected={sorted(expected)!r} actual={sorted(actual)!r}"
        )
    transport = importlib.import_module(_TRANSPORT)
    _original_execute = getattr(transport, "execute_decimal_worker")
    _original_without = getattr(transport, "execute_decimal_worker_without_budget_tag")
    transport.execute_decimal_worker = wrapped_execute
    for item in items:
        if item.module.__name__ == _PREPARED:
            item.module.execute_decimal_worker = wrapped_execute
            item.module.execute_decimal_worker_without_budget_tag = wrapped_without_budget_tag
    _record_census("exact-selection-and-wrapper-bindings")


def pytest_runtest_setup(item: Any) -> None:
    _record_census(f"test-setup:{item.nodeid}")


def pytest_runtest_teardown(item: Any, nextitem: Any) -> None:
    _record_census(f"test-teardown:{item.nodeid}")


def pytest_sessionfinish(session: Any, exitstatus: int) -> None:
    _record_census(f"pytest-session-finish:{exitstatus}")
    _shutdown_profile("pytest-session-finish")


_install_profile()
atexit.register(_shutdown_profile, "atexit")
