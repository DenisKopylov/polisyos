import importlib.util, json, os, pathlib, sys
import pytest
path=pathlib.Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos/policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1/readset_observer_tools_r1.py')
spec=importlib.util.spec_from_file_location('loaded_source_observer',path)
plugin=importlib.util.module_from_spec(spec); spec.loader.exec_module(plugin)
metadata={'schema':'s3-native-pytest-runtime-v1','pid':os.getpid(),'ppid':os.getppid(),'sys_executable':sys.executable,'sys_version':sys.version,'pytest_version':pytest.__version__,'pytest_file':pytest.__file__,'argv':sys.argv,'dyld_library_path':os.environ.get('DYLD_LIBRARY_PATH')}
pathlib.Path(os.environ['S3_RUNTIME_METADATA_PATH']).write_text(json.dumps(metadata,sort_keys=True,indent=2)+'\n',encoding='utf-8')
if __name__ == '__main__':
    raise SystemExit(pytest.main(sys.argv[1:],plugins=[plugin]))
