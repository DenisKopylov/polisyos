def _interval_coverage_admission(self) -> tuple[str | None, int | None, str | None]:
    """Reconcile the recorded comparison basis, without asserting its origin.

    Counts are derived from curve bins; producer metadata is checked only
    for agreement and cannot create an observed comparison. The recorded
    request is itself a declaration and cannot prove source provenance.
    """
    if self.task != 'continuous':
        return (None, None, None)
    return ('evaluated', 1, None)
