def _build_dfk_02_published_catalog_fixture(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    """Use the public full-pipeline fixture for DFK-02 consumer proofs."""
    import importlib.util
    import sys

    fixture_path = Path(__file__).parents[1] / "runtime" / "http" / "_published_catalog_fixture.py"
    module_name = "_e02_dfk_02_published_catalog_fixture"
    spec = importlib.util.spec_from_file_location(module_name, fixture_path)
    if spec is None or spec.loader is None:
        raise AssertionError("published catalog fixture module spec is unavailable")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module.build_published_catalog_fixture(tmp_path, monkeypatch)


def test_warm_and_fresh_catalog_consumers_reconcile_same_id_source_policy(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Reissue bound producer evidence before each warm and fresh consumer assertion."""
    import json
    import os
    from dataclasses import replace

    import yaml

    from polisyos.core.contracts.control import DataNeed, DataResolveRequest
    from polisyos.data_forge.domains.catalog.batch.config import DatasetBatchConfig
    from polisyos.data_forge.domains.catalog.batch.core_sources.validators import (
        _current_core_output_receipt_state,
    )
    from polisyos.data_forge.domains.catalog.batch.core_sources_ingest import (
        run_core_sources_ingest,
    )
    from polisyos.data_forge.domains.catalog.batch.pipeline import (
        _harvest_stage_receipt,
        current_catalog_publish_receipt,
        current_catalog_report_basis,
        run_content_stage_with_receipt,
        run_dataset_pipeline_sync,
    )
    from polisyos.data_forge.domains.catalog.knowledge.search import DatasetCatalogGraph
    from polisyos.data_forge.domains.catalog.registry import load_catalog_source_registry
    from polisyos.data_forge.read_api import catalog as catalog_read_api
    from polisyos.fabric.retrieval.service import RetrievalService

    fixture = _build_dfk_02_published_catalog_fixture(tmp_path, monkeypatch)
    reader_graphs: list[DatasetCatalogGraph] = [fixture.producer_graph]
    try:
        registry_path = tmp_path / "registry.yaml"
        monkeypatch.setattr(
            catalog_read_api,
            "load_catalog_source_registry",
            lambda: load_catalog_source_registry(registry_path),
        )
        monkeypatch.setenv("POLISYOS_RETRIEVAL_FASTLANE_ENABLED", "0")

        stage_state = json.loads(
            (fixture.snapshot_root / "datasets" / "manifests" / "stage_state.json").read_text(
                encoding="utf-8"
            )
        )
        producer_config_snapshot = stage_state["qc"]["input_basis"]["config"][
            "effective_producer_config"
        ]
        config = DatasetBatchConfig.from_producer_config_snapshot(producer_config_snapshot)
        assert config is not None
        config.run_profile = "prod_core_blocking"

        def worldbank_row(payload: object) -> dict[str, object]:
            assert isinstance(payload, dict)
            sources = payload.get("sources")
            assert isinstance(sources, list)
            rows = [
                row
                for row in sources
                if isinstance(row, dict) and row.get("name", row.get("source_id")) == "worldbank"
            ]
            assert len(rows) == 1
            return rows[0]

        def replace_worldbank_policy_bytes(
            blocking: bool,
            *,
            preserve_stat: os.stat_result | None = None,
        ) -> bytes:
            old_bytes = registry_path.read_bytes()
            payload = yaml.safe_load(old_bytes)
            row = worldbank_row(payload)
            assert isinstance(row.get("publish_blocking"), bool)
            text = old_bytes.decode("utf-8")
            document = yaml.compose(text)
            assert document is not None
            root_fields = {key.value: value for key, value in document.value}
            sources_node = root_fields["sources"]
            matching_nodes = []
            for source_node in sources_node.value:
                source_fields = {key.value: value for key, value in source_node.value}
                name_node = source_fields.get("name")
                if name_node is not None and name_node.value == "worldbank":
                    matching_nodes.append(source_fields["publish_blocking"])
            assert len(matching_nodes) == 1
            policy_node = matching_nodes[0]
            line_end = text.find("\n", policy_node.end_mark.index)
            if line_end < 0:
                line_end = len(text)
            assert text[policy_node.end_mark.index : line_end].strip() == ""
            replacement = "true " if blocking else "false"
            new_bytes = (
                text[: policy_node.start_mark.index] + replacement + text[line_end:]
            ).encode("utf-8")
            assert new_bytes != old_bytes
            registry_path.write_bytes(new_bytes)
            if preserve_stat is not None:
                os.utime(
                    registry_path,
                    ns=(preserve_stat.st_atime_ns, preserve_stat.st_mtime_ns),
                )
                actual_stat = registry_path.stat()
                assert (
                    actual_stat.st_dev,
                    actual_stat.st_ino,
                    actual_stat.st_size,
                    actual_stat.st_mtime_ns,
                ) == (
                    preserve_stat.st_dev,
                    preserve_stat.st_ino,
                    preserve_stat.st_size,
                    preserve_stat.st_mtime_ns,
                )
            actual_payload = yaml.safe_load(new_bytes)
            actual_row = worldbank_row(actual_payload)
            assert actual_row["publish_blocking"] is blocking
            return new_bytes

        def close_reader_graphs() -> None:
            while reader_graphs:
                reader_graphs.pop().close()

        def reissue_current_producer_basis() -> None:
            assert reader_graphs == []
            harvest_config = replace(config, stages=frozenset({"harvest"}))
            run_dataset_pipeline_sync(harvest_config)
            assert _harvest_stage_receipt(config) is not None

            core_stats = run_core_sources_ingest(config)
            assert not core_stats.failures
            assert not core_stats.failed_shards
            assert not core_stats.deferred_shards
            assert _current_core_output_receipt_state(config).is_current

            run_content_stage_with_receipt(config, "benchmark")
            run_content_stage_with_receipt(config, "qc")
            assert current_catalog_report_basis(config)["state"] == "current"
            run_content_stage_with_receipt(config, "publish")
            receipt = current_catalog_publish_receipt(
                config.db_path, run_profile=config.run_profile
            )
            assert receipt["state"] == "current"
            assert receipt["profile_input_coverage_state"] == "established"

        def open_consumer(label: str) -> RetrievalService:
            graph = DatasetCatalogGraph(
                fixture.database_path,
                fixture.snapshot_root / "datasets",
                overlay_path=tmp_path / f"missing-{label}-overlay.duckdb",
            )
            reader_graphs.append(graph)
            return RetrievalService(
                curated_dir=tmp_path / f"curated-{label}",
                dataset_catalog=graph,
                profiles=fixture.profile_registry,
            )

        request = DataResolveRequest(
            data_needs=[
                DataNeed(
                    metric="scope_metric",
                    geography="DEU",
                    time_start="2025",
                    time_end="2025",
                )
            ],
            mode="fastlane",
            allow_explore_fallback=False,
        )

        def plan_ids(service: RetrievalService) -> list[str]:
            return [
                plan.dataset_id
                for plan in service.resolve(request, run_profile=config.run_profile).fetch_plans
            ]

        initial_registry_bytes = registry_path.read_bytes()
        registry = yaml.safe_load(initial_registry_bytes)
        initial_worldbank = worldbank_row(registry)
        assert initial_worldbank["enabled"] is True
        assert initial_worldbank["publish_blocking"] is True
        padded_true_bytes = replace_worldbank_policy_bytes(True)
        assert padded_true_bytes != initial_registry_bytes

        close_reader_graphs()
        reissue_current_producer_basis()
        original_registry_bytes = registry_path.read_bytes()
        original_stat = registry_path.stat()

        warm = open_consumer("warm-true")
        assert plan_ids(warm) == ["scope_dataset"]
        warmed_stat = registry_path.stat()
        assert (warmed_stat.st_size, warmed_stat.st_mtime_ns) == (
            original_stat.st_size,
            original_stat.st_mtime_ns,
        )

        changed_registry_bytes = replace_worldbank_policy_bytes(False, preserve_stat=warmed_stat)
        changed_stat = registry_path.stat()
        assert changed_registry_bytes != original_registry_bytes
        assert (changed_stat.st_size, changed_stat.st_mtime_ns) == (
            warmed_stat.st_size,
            warmed_stat.st_mtime_ns,
        )
        assert (
            current_catalog_publish_receipt(config.db_path, run_profile=config.run_profile)["state"]
            != "current"
        )
        fresh_false = open_consumer("fresh-false-stale")
        assert plan_ids(warm) == []
        assert plan_ids(fresh_false) == []

        close_reader_graphs()
        reissue_current_producer_basis()
        current_false = open_consumer("warm-false")
        assert plan_ids(current_false) == []

        restored_registry_bytes = replace_worldbank_policy_bytes(True, preserve_stat=changed_stat)
        restored_stat = registry_path.stat()
        assert restored_registry_bytes != changed_registry_bytes
        assert (restored_stat.st_size, restored_stat.st_mtime_ns) == (
            changed_stat.st_size,
            changed_stat.st_mtime_ns,
        )
        assert (
            current_catalog_publish_receipt(config.db_path, run_profile=config.run_profile)["state"]
            != "current"
        )
        fresh_true = open_consumer("fresh-true-stale")
        assert plan_ids(current_false) == ["scope_dataset"]
        assert plan_ids(fresh_true) == ["scope_dataset"]

        close_reader_graphs()
        reissue_current_producer_basis()
        current_true = open_consumer("fresh-true-current")
        assert plan_ids(current_true) == ["scope_dataset"]

        registry_path.write_text("version: 1\nsources: invalid\n", encoding="utf-8")
        with pytest.raises(ValueError):
            plan_ids(current_true)
    finally:
        close_reader_graphs()
        fixture.close()


def test_fresh_catalog_consumer_fails_closed_on_disabled_seed_without_index_mutation(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Exercise disabled seed closure through a real fresh catalog reader."""
    import copy
    import hashlib

    import yaml

    from polisyos.core.contracts.control import DataNeed, DataResolveRequest
    from polisyos.data_forge.domains.catalog.batch.pipeline import (
        current_catalog_publish_receipt,
    )
    from polisyos.data_forge.domains.catalog.knowledge.search import DatasetCatalogGraph
    from polisyos.data_forge.domains.catalog.registry import load_catalog_source_registry
    from polisyos.data_forge.read_api import catalog as catalog_read_api
    from polisyos.fabric.retrieval.service import RetrievalService

    fixture = _build_dfk_02_published_catalog_fixture(tmp_path / "producer", monkeypatch)
    reader_graphs: list[DatasetCatalogGraph] = [fixture.producer_graph]
    try:
        registry_path = tmp_path / "producer" / "registry.yaml"
        consumer_root = tmp_path / "consumer-policies"
        consumer_root.mkdir()
        disabled_registry_path = consumer_root / "disabled-seed.yaml"
        removed_seed_registry_path = consumer_root / "removed-seed-edge.yaml"
        producer_registry_bytes = registry_path.read_bytes()
        index_root = fixture.snapshot_root / "datasets"

        def physical_index_identity() -> tuple[tuple[str, int, str], ...]:
            return tuple(
                (
                    str(path.relative_to(index_root)),
                    path.stat().st_size,
                    hashlib.sha256(path.read_bytes()).hexdigest(),
                )
                for path in sorted(index_root.rglob("*"))
                if path.is_file()
            )

        consumer_payload = yaml.safe_load(producer_registry_bytes)
        worldbank_rows = [
            row
            for row in consumer_payload["sources"]
            if row.get("name", row.get("source_id")) == "worldbank"
        ]
        assert len(worldbank_rows) == 1
        worldbank_rows[0]["seed_from"] = "i4_disabled_seed"
        consumer_payload["sources"].append(
            {
                "name": "i4_disabled_seed",
                "family": "fixture",
                "wave": "A",
                "endpoint": "https://example.invalid/i4-disabled-seed",
                "connector_id": "fixture.disabled_seed",
                "enabled": False,
                "execution_tier": "catalog",
                "run_lane": "catalog",
                "publish_blocking": False,
            }
        )
        disabled_registry_path.write_text(
            yaml.safe_dump(consumer_payload, sort_keys=False),
            encoding="utf-8",
        )
        removed_seed_payload = copy.deepcopy(consumer_payload)
        removed_worldbank = next(
            row
            for row in removed_seed_payload["sources"]
            if row.get("name", row.get("source_id")) == "worldbank"
        )
        removed_worldbank.pop("seed_from")
        removed_seed_registry_path.write_text(
            yaml.safe_dump(removed_seed_payload, sort_keys=False),
            encoding="utf-8",
        )

        monkeypatch.setenv("POLISYOS_RETRIEVAL_FASTLANE_ENABLED", "0")
        request = DataResolveRequest(
            data_needs=[
                DataNeed(
                    metric="scope_metric",
                    geography="DEU",
                    time_start="2025",
                    time_end="2025",
                )
            ],
            mode="fastlane",
            allow_explore_fallback=False,
        )

        def resolve_fresh(label: str, selected_registry: Path):
            monkeypatch.setattr(
                catalog_read_api,
                "load_catalog_source_registry",
                lambda: load_catalog_source_registry(selected_registry),
            )
            graph = DatasetCatalogGraph(
                fixture.database_path,
                index_root,
                overlay_path=tmp_path / f"missing-{label}-overlay.duckdb",
            )
            try:
                service = RetrievalService(
                    curated_dir=tmp_path / f"curated-{label}",
                    dataset_catalog=graph,
                    profiles=fixture.profile_registry,
                )
                return service.resolve(request, run_profile="prod_full")
            finally:
                graph.close()

        assert (
            current_catalog_publish_receipt(fixture.database_path, run_profile="prod_full")["state"]
            == "current"
        )
        original_index_identity = physical_index_identity()

        with pytest.raises(catalog_read_api.CatalogSelectionError) as caught:
            resolve_fresh("disabled-seed", disabled_registry_path)
        assert caught.value.code == "dependency_disabled"
        assert caught.value.detail == "source=worldbank/seed=i4_disabled_seed"
        assert physical_index_identity() == original_index_identity
        assert registry_path.read_bytes() == producer_registry_bytes

        wrong_registry = resolve_fresh("wrong-registry-control", registry_path)
        assert [plan.dataset_id for plan in wrong_registry.fetch_plans] == ["scope_dataset"]
        assert physical_index_identity() == original_index_identity
        assert registry_path.read_bytes() == producer_registry_bytes

        removed_seed = resolve_fresh("removed-seed-control", removed_seed_registry_path)
        assert [plan.dataset_id for plan in removed_seed.fetch_plans] == ["scope_dataset"]
        assert physical_index_identity() == original_index_identity
        assert registry_path.read_bytes() == producer_registry_bytes
        assert (
            current_catalog_publish_receipt(fixture.database_path, run_profile="prod_full")["state"]
            == "current"
        )
    finally:
        while reader_graphs:
            reader_graphs.pop().close()
        fixture.close()
