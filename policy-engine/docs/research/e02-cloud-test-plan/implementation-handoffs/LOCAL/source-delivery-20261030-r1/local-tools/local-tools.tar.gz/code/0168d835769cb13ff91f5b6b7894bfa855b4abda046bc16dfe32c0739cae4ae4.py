"""Check readset admission without product imports or executing the builder."""
import ast
import re
from pathlib import Path

path = Path(__file__).with_name('run_builder.py')
tree = ast.parse(path.read_text())
owners = next(x for x in tree.body if isinstance(x, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'REQUIRED_OWNERS' for t in x.targets))
validator = next(x for x in tree.body if isinstance(x, ast.FunctionDef) and x.name == 'validate_readset')
namespace = {'Path': Path, 're': re}
exec(compile(ast.Module(body=[owners, validator], type_ignores=[]), '<readset-canary>', 'exec'), namespace)
validate, required = namespace['validate_readset'], namespace['REQUIRED_OWNERS']
valid = {key: 'a' * 64 for key in required}
assert validate(valid) == len(required)
for value in ({}, [], {'src/example.py': 'a' * 64}, {**valid, '../escape': 'a' * 64}, {**valid, 'src/other.py': 'invalid'}, {**valid, 'src/other.py': 3}):
    try:
        validate(value)
    except ValueError:
        continue
    raise AssertionError('invalid readset was admitted')
print('PASS: nonempty/typed required-owner inventory, malformed hashes and traversal rejected')
