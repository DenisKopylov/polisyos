"""Pure cleanup authorization gate for the C104 local Root driver.

The caller supplies independently read-back file evidence. Summary and audit
booleans are descriptive only: process identities and exit states are derived
from the phase, monitor, process-tree, and child-observer receipts.
"""
from __future__ import annotations

from typing import Any, Callable


PHASE_ORDER = ("phase-a", "phase-b", "phase-c")
CHILD_CASES = (
    "01-positive-typed",
    "02-negative-malformed-typed",
    "03-removal-malformed-untyped",
    "04-restored-malformed-typed",
)
CHILD_ROLES = (
    "outer-worker:execute_decimal_worker",
    "outer-worker:execute_decimal_worker",
    "outer-worker:execute_decimal_worker_without_budget_tag",
    "outer-worker:execute_decimal_worker",
)


class CleanupGateError(ValueError):
    """Raised when cleanup evidence is incomplete, inconsistent, or live."""


def _need(condition: object, reason: str) -> None:
    if not condition:
        raise CleanupGateError(reason)


def _pid(value: object) -> bool:
    return type(value) is int and value > 0


def _binding_tuple(binding: dict[str, Any]) -> tuple[str, int, str]:
    path = binding.get("path")
    size = binding.get("bytes")
    sha = binding.get("sha256")
    _need(isinstance(path, str) and path, "evidence binding path is absent")
    _need(type(size) is int and size >= 0, f"evidence size is invalid: {path}")
    _need(isinstance(sha, str) and len(sha) == 64, f"evidence hash is invalid: {path}")
    return path, size, sha


def _require_binding(bindings: list[dict[str, Any]], required: dict[str, Any], label: str) -> None:
    target = _binding_tuple(required)
    matches = [item for item in bindings if isinstance(item, dict) and item.get("path") == target[0]]
    _need(len(matches) == 1 and _binding_tuple(matches[0]) == target,
          f"{label} is absent, duplicated, or has a different content binding")


def _record_bindings(report: dict[str, Any]) -> dict[str, dict[str, Any]]:
    rows = report.get("verified_outputs")
    _need(isinstance(rows, list), "audit verified_outputs is not a list")
    result: dict[str, dict[str, Any]] = {}
    for row in rows:
        _need(isinstance(row, dict), "audit output binding is malformed")
        path, _size, _sha = _binding_tuple(row)
        _need(path not in result, f"audit contains duplicate output binding: {path}")
        result[path] = row
    return result


def derive_cleanup_proof(
    summary: dict[str, Any],
    phase_evidence: list[dict[str, Any]],
    report: dict[str, Any],
    summary_binding: dict[str, Any],
    plan_binding: dict[str, Any],
    process_group_is_live: Callable[[int], bool],
    process_pid_is_live: Callable[[int], bool],
) -> dict[str, Any]:
    """Reconcile every started command and observed worker before cleanup.

    ``phase_evidence`` is built from current bytes by the caller. Its records
    include the phase receipt, exact monitor-result and invocation bindings,
    monitor process-tree samples, source-observer receipts, and Phase C child
    receipts. This function never trusts audit summary booleans as evidence.
    """
    _need(report.get("cleanup_allowed") is True and report.get("all_started_groups_gone") is True,
          "audit did not admit explicit cleanup")
    _need(summary.get("case_id") == report.get("case_id") and summary.get("source") == report.get("source"),
          "audit case/source differs from the run summary")

    phase_rows = summary.get("phases")
    report_rows = report.get("phases")
    _need(isinstance(phase_rows, list) and isinstance(report_rows, list), "summary or audit phase list is malformed")
    phase_ids = [row.get("phase_id") for row in phase_rows if isinstance(row, dict)]
    _need(phase_ids == list(PHASE_ORDER[:len(phase_ids)]), "summary phase IDs are not the exact started prefix")
    _need(summary.get("unrun") == list(PHASE_ORDER[len(phase_ids):]), "summary unrun set is not the exact phase suffix")
    _need([row.get("phase_id") for row in report_rows if isinstance(row, dict)] == phase_ids,
          "audit phase IDs differ from the summary")
    _need(len(report_rows) == len(phase_ids) and len(phase_evidence) == len(phase_ids),
          "phase evidence set is incomplete or contains extras")
    evidence_by_id: dict[str, dict[str, Any]] = {}
    for evidence in phase_evidence:
        _need(isinstance(evidence, dict), "phase evidence record is malformed")
        phase_id = evidence.get("phase_id")
        _need(phase_id not in evidence_by_id, "duplicate phase evidence ID")
        evidence_by_id[phase_id] = evidence
    _need(list(evidence_by_id) == phase_ids, "phase evidence ordering or membership differs")

    output_bindings = _record_bindings(report)
    for binding, label in ((summary_binding, "run-summary"), (plan_binding, "prepared plan")):
        _require_binding(list(output_bindings.values()), binding, label)

    started_commands: list[dict[str, Any]] = []
    observed_pids: set[int] = set()
    observed_groups: set[int] = set()
    for summary_row, report_row in zip(phase_rows, report_rows, strict=True):
        phase_id = summary_row["phase_id"]
        evidence = evidence_by_id[phase_id]
        receipt = evidence.get("phase_receipt")
        monitor = evidence.get("monitor_result")
        _need(isinstance(receipt, dict) and isinstance(monitor, dict), f"{phase_id} receipt is unavailable")
        phase_binding = evidence.get("phase_receipt_binding")
        monitor_binding = evidence.get("monitor_result_binding")
        invocation_binding = evidence.get("invocation_binding")
        process_tree_binding = evidence.get("process_tree_binding")
        _need(all(isinstance(x, dict) for x in (phase_binding, monitor_binding, invocation_binding)),
              f"{phase_id} critical file bindings are incomplete")
        _need(receipt.get("phase_id") == phase_id and receipt.get("source") == summary.get("source"),
              f"{phase_id} receipt does not bind phase/source")
        _need(receipt.get("status") == summary_row.get("status"), f"{phase_id} status differs from its receipt")
        _need(receipt.get("monitor") == monitor, f"{phase_id} monitor file differs from its phase receipt")
        _need(monitor.get("id") == phase_id, f"{phase_id} monitor command ID differs")
        _need(summary_row.get("receipt") == phase_binding.get("path")
              and summary_row.get("receipt_sha256") == phase_binding.get("sha256"),
              f"{phase_id} summary does not bind the actual phase receipt")
        _need(summary_row.get("pid") == monitor.get("pid")
              and summary_row.get("return_code") == monitor.get("return_code")
              and summary_row.get("process_group_gone") == monitor.get("process_group_gone"),
              f"{phase_id} summary PID/exit differs from the monitor receipt")
        _need(report_row.get("status") == summary_row.get("status")
              and report_row.get("pid") == monitor.get("pid")
              and report_row.get("return_code") == monitor.get("return_code")
              and report_row.get("receipt") == phase_binding.get("path")
              and report_row.get("receipt_sha256") == phase_binding.get("sha256")
              and report_row.get("process_group_exit_established") is True,
              f"{phase_id} audit row differs from monitor/phase receipts")
        _need(report_row.get("process_group_still_exists") is False,
              f"{phase_id} audit observed a live process group")

        deciding = receipt.get("outputs", {}).get("deciding_files")
        _need(isinstance(deciding, list), f"{phase_id} deciding file list is absent")
        required = [phase_binding, monitor_binding, invocation_binding]
        if process_tree_binding is not None:
            required.append(process_tree_binding)
        for binding in required:
            _require_binding(list(output_bindings.values()), binding, f"{phase_id} audit output")
        _require_binding(deciding, monitor_binding, f"{phase_id} phase monitor binding")
        _require_binding(deciding, invocation_binding, f"{phase_id} phase invocation binding")

        pid = monitor.get("pid")
        if pid is None:
            _need(monitor.get("status") in {
                "skipped_parent_signal", "skipped_overall_wall_cap", "skipped_disk_floor", "rejected_command"
            } and monitor.get("complete") is True,
                f"{phase_id} has no PID but the monitor does not prove it never started")
            _need(monitor.get("return_code") is None and monitor.get("process_group_gone") in (None, True),
                  f"{phase_id} no-PID monitor receipt is internally inconsistent")
            _need(not evidence.get("observer_receipts") and not evidence.get("child_receipts"),
                  f"{phase_id} no-PID phase unexpectedly has process observations")
            started = False
        else:
            _need(_pid(pid), f"{phase_id} monitor PID is invalid")
            _need(monitor.get("complete") is True and type(monitor.get("return_code")) is int
                  and monitor.get("process_group_gone") is True,
                  f"{phase_id} started command lacks complete observed exit state")
            started = True
            observed_pids.add(pid)
            observed_groups.add(pid)  # The retained supervisor starts each command in a new session.

        samples = evidence.get("process_tree_samples", [])
        _need(isinstance(samples, list), f"{phase_id} process-tree samples are malformed")
        if started:
            _need(type(monitor.get("sample_count")) is int and len(samples) == monitor.get("sample_count")
                  and len(samples) > 0,
                  f"{phase_id} sampled process tree does not reconcile with monitor count")
            root_seen = False
            pid_group: dict[int, int] = {}
            pid_command: dict[int, str] = {}
            for sample in samples:
                _need(isinstance(sample, dict) and sample.get("kind") == "sample"
                      and sample.get("command_id") == phase_id, f"{phase_id} process-tree sample identity differs")
                processes = sample.get("processes")
                _need(isinstance(processes, list), f"{phase_id} process-tree process list is malformed")
                for process in processes:
                    _need(isinstance(process, dict) and _pid(process.get("pid"))
                          and type(process.get("ppid")) is int and process.get("ppid") >= 0
                          and _pid(process.get("pgid")), f"{phase_id} process-tree identity is malformed")
                    process_pid = process["pid"]
                    group_id = process["pgid"]
                    command = process.get("command")
                    _need(isinstance(command, str), f"{phase_id} process-tree command identity is absent")
                    _need(process_pid not in pid_group or pid_group[process_pid] == group_id,
                          f"{phase_id} sampled PID changed process group")
                    _need(process_pid not in pid_command or pid_command[process_pid] == command,
                          f"{phase_id} sampled PID changed command identity")
                    pid_group[process_pid] = group_id
                    pid_command[process_pid] = command
                    if process_pid == pid:
                        root_seen = True
                    observed_pids.add(process_pid)
                    observed_groups.add(group_id)
            _need(root_seen, f"{phase_id} monitor PID is absent from every process-tree sample")
        else:
            _need(not samples, f"{phase_id} no-PID command has process-tree samples")

        observers = evidence.get("observer_receipts", [])
        _need(isinstance(observers, list), f"{phase_id} observer receipts are malformed")
        readset = receipt.get("readset", {})
        declared_observers = readset.get("receipts") if isinstance(readset, dict) else None
        _need(isinstance(declared_observers, list) and len(declared_observers) == len(observers),
              f"{phase_id} observer receipt set differs from the phase receipt")
        observer_by_pid: dict[int, dict[str, Any]] = {}
        for declared, observed in zip(declared_observers, observers, strict=True):
            _need(isinstance(declared, dict) and isinstance(observed, dict), f"{phase_id} observer binding is malformed")
            binding = observed.get("binding")
            value = observed.get("value")
            _need(isinstance(binding, dict) and isinstance(value, dict), f"{phase_id} observer bytes are absent")
            _require_binding(deciding, binding, f"{phase_id} phase observer binding")
            _require_binding(list(output_bindings.values()), binding, f"{phase_id} audit observer binding")
            process = value.get("process", {})
            observer_pid = process.get("pid") if isinstance(process, dict) else None
            _need(_pid(observer_pid) and observer_pid == declared.get("pid")
                  and process.get("ppid") == declared.get("ppid")
                  and process.get("role") == declared.get("role")
                  and binding.get("sha256") == declared.get("sha256")
                  and binding.get("bytes") == declared.get("bytes"),
                  f"{phase_id} observer content differs from its hash-bound receipt row")
            _need(observer_pid not in observer_by_pid, f"{phase_id} observer PID is duplicated")
            observer_by_pid[observer_pid] = observed
            observed_pids.add(observer_pid)

        children = evidence.get("child_receipts", [])
        if phase_id == "phase-c" and started:
            phase_c = receipt.get("phase_c")
            _need(isinstance(phase_c, dict) and phase_c.get("child_receipt_count") == 4
                  and len(children) == 4 and len(phase_c.get("child_checks", [])) == 4,
                  "started Phase C lacks all four child observation receipts")
            checks = phase_c["child_checks"]
            child_pids: set[int] = set()
            for index, (case_name, role, check, child) in enumerate(
                zip(CHILD_CASES, CHILD_ROLES, checks, children, strict=True)
            ):
                _need(isinstance(check, dict) and isinstance(child, dict), "Phase C child receipt row is malformed")
                binding = child.get("binding")
                value = child.get("value")
                _need(isinstance(binding, dict) and isinstance(value, dict), "Phase C child receipt bytes are absent")
                _require_binding(deciding, binding, "Phase C child receipt binding")
                _require_binding(list(output_bindings.values()), binding, "Phase C audit child receipt binding")
                process = value.get("process", {})
                child_pid = process.get("process_object_pid") if isinstance(process, dict) else None
                observer = observer_by_pid.get(child_pid)
                _need(check.get("case") == case_name and check.get("expected_role") == role
                      and check.get("pid") == child_pid and check.get("actual_child_readset_bound") is True
                      and value.get("case") == case_name and _pid(child_pid)
                      and process.get("parent_pid") == pid
                      and type(process.get("child_exit_code")) is int
                      and value.get("source_binding", {}).get("valid") is True
                      and check.get("observer_sha256") == (observer or {}).get("binding", {}).get("sha256")
                      and value.get("observer_delivery", {}).get("sha256")
                      == (observer or {}).get("binding", {}).get("sha256")
                      and _binding_tuple(check.get("receipt_file", {})) == _binding_tuple(binding),
                      f"Phase C child {index + 1} differs from its observed process receipt")
                _need(child_pid not in child_pids and observer is not None,
                      "Phase C child PID is duplicated or lacks its in-child observer receipt")
                child_pids.add(child_pid)
                observed_pids.add(child_pid)
            _need(len(observer_by_pid) == 5 and pid in observer_by_pid,
                  "Phase C observer set is not exactly parent plus four children")
            parent_observer = observer_by_pid[pid]
            _need(parent_observer.get("value", {}).get("process", {}).get("role") == "observer-process",
                  "Phase C parent observer role differs")
            for index, (case_name, role) in enumerate(zip(CHILD_CASES, CHILD_ROLES, strict=True)):
                child = children[index]["value"]
                observer = observer_by_pid[child["process"]["process_object_pid"]]["value"]
                observed_process = observer.get("process", {})
                _need(observed_process.get("role") == role and observed_process.get("ppid") == pid,
                      f"Phase C child observer role/parent differs for {case_name}")
        elif children:
            raise CleanupGateError(f"{phase_id} has unexpected child receipts")

        if started:
            for observed_pid in observer_by_pid:
                # Root/child process IDs may be repeated by the process-tree sample.
                observed_pids.add(observed_pid)
            started_commands.append({
                "phase_id": phase_id,
                "pid": pid,
                "process_group_id": pid,
                "return_code": monitor["return_code"],
                "process_group_gone_receipt": True,
                "phase_receipt": phase_binding,
                "monitor_result": monitor_binding,
                "invocation": invocation_binding,
                "observer_receipts": [item["binding"] for item in observers],
                "child_receipts": [item["binding"] for item in children],
                "process_tree": process_tree_binding,
            })

    live_pids = sorted(pid for pid in observed_pids if process_pid_is_live(pid))
    live_groups = sorted(group for group in observed_groups if process_group_is_live(group))
    _need(not live_pids and not live_groups,
          f"live process identities remain before overlay cleanup: pids={live_pids}, groups={live_groups}")
    return {
        "schema": "policyos.e02.c104.cleanup_process_proof.v2",
        "started_command_count": len(started_commands),
        "started_commands": started_commands,
        "observed_pid_count": len(observed_pids),
        "observed_pids": sorted(observed_pids),
        "observed_process_group_ids": sorted(observed_groups),
        "live_pids_at_cleanup": live_pids,
        "live_groups_at_cleanup": live_groups,
        "summary_binding": summary_binding,
        "plan_binding": plan_binding,
        "all_started_command_exit_states_reconciled": True,
        "all_observed_child_receipts_hash_bound": True,
        "cleanup_authorized_by_recomputed_evidence": True,
    }
