from pathlib import Path
import ast,difflib,hashlib,json,subprocess
root=Path.cwd(); batch=Path('LOCAL/raw/e02-execution-20261027/repairs/C48-r4'); dst=batch/'lint-companion'
manifest=json.loads((batch/'manifest.json').read_text())
paths=[]
for key,sub in [('main_files','postimages'),('c53_overlay_files','c53-postimages')]:
 for row in manifest[key]:
  p=Path(row['path'])
  if p.suffix!='.py':continue
  old=(batch/sub/p).read_bytes()
  for phase in ('preimages','postimages'):
   dest=dst/phase/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(old)
  paths.append(p)
def edit(path, changes):
 p=dst/'postimages'/path;s=p.read_text()
 for a,b in changes:
  if s.count(a)!=1:raise RuntimeError((str(path),a,s.count(a)))
  s=s.replace(a,b,1)
 p.write_text(s)
base='policy-engine/src/polisyos/scientist/'
edit(base+'methods/search/controller.py',[
('import os\n','import os as os\n'),('from datetime import UTC, date, datetime','from datetime import UTC as UTC, date, datetime'),('    cast,\n','    cast as cast,\n'),('from uuid import uuid4','from uuid import uuid4 as uuid4'),('from pydantic import BaseModel, ValidationError','from pydantic import BaseModel, ValidationError as ValidationError'),
*[(f'    {x},\n',f'    {x} as {x},\n') for x in ['CandidatePayload','SearchContext','_EvaluationDisposition','_EvaluationTransition','policy_candidate_hash','update_legacy_pareto_front']],
('from polisyos.scientist.methods.search.sentinels import extract_sentinel_metadata','from polisyos.scientist.methods.search.sentinels import extract_sentinel_metadata as extract_sentinel_metadata')])
edit(base+'methods/search/lifecycle.py', [('    ObjectiveScoreAdmission,\n','    ObjectiveScoreAdmission as ObjectiveScoreAdmission,\n')])
edit(base+'methods/search/pareto_registry.py',[('    tenant_partition,\n','    tenant_partition as tenant_partition,\n')])
edit(base+'nodes/builtins/decide/policy_blueprint_runtime_reporting.py',[
('    StressOutcomeBasis,\n','    StressOutcomeBasis as StressOutcomeBasis,\n'),
*[(f'import {x}\n',f'import {x} as {x}\n') for x in ['Level0StaticValidator','Level1CheapHeuristic','Level2CausalPlausibility','Level3MediumFidelity','Level4FullFidelity','Level6PromotionStage']],
('    Level5RefutationGovernanceStage,\n','    Level5RefutationGovernanceStage as Level5RefutationGovernanceStage,\n'),
('    owner = session.owner\n    outcome = session.outcome\n    artifacts = [session.selection_ref, session.evidence_ref]','    _owner = session.owner\n    outcome = session.outcome\n    artifacts = [session.selection_ref, session.evidence_ref]')])
edit(base+'nodes/builtins/planning/run_hierarchical_policy_search.py',[
('    SchemaInfo,\n','    SchemaInfo as SchemaInfo,\n'),('from polisyos.core.artifacts.store import PutOptions','from polisyos.core.artifacts.store import PutOptions as PutOptions'),('from polisyos.core.canon import CanonSpec','from polisyos.core.canon import CanonSpec as CanonSpec')])
edit(base+'methods/search/funnel/orchestrator.py',[(f'    {x},\n',f'    {x} as {x},\n') for x in ['FunnelWorkPacketStatus','RoutingAction','SchedulingDecision']])
sha=lambda b:hashlib.sha256(b).hexdigest()
def lint(path,content):
 cmd=[str(root/'policy-engine/.venv/bin/python'),'-m','ruff','check','--no-cache','--config',str(root/'policy-engine/pyproject.toml'),'--output-format','json','--stdin-filename',str(root/path),'-']
 p=subprocess.run(cmd,input=content,capture_output=True)
 if p.returncode not in (0,1):raise RuntimeError((path,p.stderr))
 return json.loads(p.stdout)
report=[]
for p in paths:
 pre=(dst/'preimages'/p).read_bytes();post=(dst/'postimages'/p).read_bytes()
 ast.parse(post,str(p))
 # Read the slice base without changing any worktree or Git state.
 old=subprocess.run(['git','show',f'cfdb1ac1b7a44a782ec8e13b5f0ed9277beed65c:{p}'],capture_output=True)
 baseline=lint(p,old.stdout) if old.returncode==0 else None
 before=lint(p,pre);after=lint(p,post)
 report.append({'path':str(p),'slice_base_diagnostics':baseline,'frozen_r4_diagnostics':before,'companion_diagnostics':after,'preimage_sha256':sha(pre),'postimage_sha256':sha(post)})
parts=[];changed=[]
for p in paths:
 pre=(dst/'preimages'/p).read_bytes();post=(dst/'postimages'/p).read_bytes()
 if pre==post:continue
 parts.extend(difflib.unified_diff(pre.decode().splitlines(keepends=True),post.decode().splitlines(keepends=True),fromfile='a/'+str(p),tofile='b/'+str(p)))
 changed.append(str(p))
patch=''.join(parts);(dst/'lint.patch').write_text(patch)
(dst/'ruff-full-denominator.json').write_text(json.dumps(report,indent=2)+'\n')
result={'status':'frozen_lint_companion_pending_delta_review','parent_manifest_sha256':sha((batch/'manifest.json').read_bytes()),'source_base':'cfdb1ac1b7a44a782ec8e13b5f0ed9277beed65c','input_denominator_count':len(paths),'changed_paths':changed,'patch_sha256':sha(patch.encode()),'diagnostics_report_sha256':sha((dst/'ruff-full-denominator.json').read_bytes()),'baseline_diagnostics':sum(len(r['slice_base_diagnostics'] or []) for r in report),'r4_diagnostics':sum(len(r['frozen_r4_diagnostics']) for r in report),'companion_diagnostics':sum(len(r['companion_diagnostics']) for r in report),'ast_parsed':len(paths),'runtime':'UNRUN'}
(dst/'manifest.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
