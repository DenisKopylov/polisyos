"""Prepare the unchanged N7 route with a short owned case ID; never run it."""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import sys
from pathlib import Path

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
PREPARER = ROOT / "LOCAL/raw/e02-execution-20261027/next-native/N7-grounded-report-r2/prepare_served_case.py"
PREPARER_SHA256 = "9359dd42d2242a569af7048d431ceff14c7302900e2f4e390b4f7e273c84737d"
CASE_ID = "n7r3"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expected-head", required=True)
    parser.add_argument("--expected-tree", required=True)
    args = parser.parse_args()
    if PREPARER.is_symlink() or not PREPARER.is_file():
        raise SystemExit("reviewed R2 preparer is unavailable")
    if hashlib.sha256(PREPARER.read_bytes()).hexdigest() != PREPARER_SHA256:
        raise SystemExit("reviewed R2 preparer bytes changed")
    spec = importlib.util.spec_from_file_location("_e02_n7_reviewed_r2", PREPARER)
    if spec is None or spec.loader is None:
        raise SystemExit("reviewed R2 preparer loader unavailable")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    old_id = module.CASE_ID
    if old_id != "n7-served-grounded-route-r2-20261029":
        raise SystemExit("unexpected retained R2 case identity")
    if any((module.D / name).exists() for name in (CASE_ID, CASE_ID + ".json")):
        raise SystemExit("short case slot already exists; preserve it and prepare a new identity")
    module.CASE_ID = CASE_ID
    sys.argv = [str(PREPARER), "--expected-head", args.expected_head,
                "--expected-tree", args.expected_tree]
    return module.main()


if __name__ == "__main__":
    raise SystemExit(main())
