from pathlib import Path
base=Path('LOCAL/raw/e02-execution-20261027/repairs/q1-inspection-consumer-r2/postimages/policy-engine')
p=base/'src/polisyos/runtime/http/routes/artifacts.py';s=p.read_text()
for name,end in [('get_artifact_content','get_artifact_lineage'),('get_artifact_schema','render_bureaucratic_artifact')]:
 start=s.index('    def '+name+'(');stop=s.index('    def '+end+'(',start);chunk=s[start:stop]
 # The first content conditional belongs to raw; only the semantic block is evidence-backed.
 target='''        not_modified = build_not_modified_response(
            request.headers,
            etag=etag,
            last_modified=manifest.created_at,
            profile_selected=manifest_profile_sha256 is not None and evidence_ref is None,
        )'''
 if name=='get_artifact_content':
  target='''            not_modified = build_not_modified_response(
                request.headers,
                etag=etag,
                last_modified=manifest.created_at,
                profile_selected=manifest_profile_sha256 is not None and evidence_ref is None,
            )'''
 indent='            ' if name=='get_artifact_content' else '        '
 replacement=indent+'not_modified = (\n'+indent+'    build_not_modified_response(\n'+indent+'        request.headers,\n'+indent+'        etag=etag,\n'+indent+'        last_modified=manifest.created_at,\n'+indent+'        profile_selected=manifest_profile_sha256 is not None,\n'+indent+'    )\n'+indent+'    if evidence_ref is None\n'+indent+'    else None\n'+indent+')'
 assert target in chunk
 chunk=chunk.replace(target,replacement,1)
 chunk=chunk.replace('{"technical_inspection_evidence": evidence_ref.model_dump(mode="json")}', '''{
                        "technical_inspection_subject": _artifact_ref_for_manifest(manifest).model_dump(
                            mode="json"
                        ),
                        "technical_inspection_evidence": evidence_ref.model_dump(mode="json"),
                    }''',1)
 s=s[:start]+chunk+s[stop:]
p.write_text(s)
p=base/'release-fragments/unreleased/2026-10-29-technical-inspection-http.toml';s=p.read_text().replace('generated_client_compatibility = "Additive optional query parameters; generated clients require regeneration."','generated_client_compatibility = "requires_regeneration"')
s+='''
[[compatibility_change]]
id = "technical-inspection-preview-query"
change_class = "schema-openapi-abi"
impact = "additive"
surface = "public_stable: Runtime API artifact content and schema preview query parameters"
owner = "team-polisyos"
version_owner = "team-runtime"
deprecation_window = "not_applicable"
release_note = "Content and schema previews accept explicit selected technical-inspection evidence."
generated_client_compatibility = "requires_regeneration"
migration_docs = ["src/polisyos/runtime/http/services/README.md"]
runbook_docs = ["src/polisyos/runtime/http/services/README.md"]
'''
p.write_text(s)
