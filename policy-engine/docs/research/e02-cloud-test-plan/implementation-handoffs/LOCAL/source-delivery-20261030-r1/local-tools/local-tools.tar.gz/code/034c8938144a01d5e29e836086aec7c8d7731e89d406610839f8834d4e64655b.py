"""Synthetic restoration guard and parent-env checks; no pytest/product import."""
from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import types

here = Path(__file__).resolve().parent
fake = types.ModuleType("pytest")
fake.hookimpl = lambda **_kwargs: lambda function: function
fake.ExitCode = types.SimpleNamespace(INTERNAL_ERROR=3)
sys.modules["pytest"] = fake

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

restore = load("synthetic_restoration_launcher", here / "restored_launcher.py")
env_owner = load("synthetic_parent_environment_guard", here / "parent_env_guard.py")
source = b'''\
class GenerationCycleController:
    def _plan_n7_requirement_gap_if_requested(self):
        return "requirement_basis_not_established"
'''
owner = types.ModuleType(restore.OWNER)
owner.__file__ = str(restore.OWNER_PATH)
exec(compile(source, str(restore.OWNER_PATH), "exec", dont_inherit=True), owner.__dict__)
recursive = types.ModuleType(restore.RECURSIVE)
recursive.GenerationCycleController = owner.GenerationCycleController
sys.modules[restore.OWNER] = owner
sys.modules[restore.RECURSIVE] = recursive
function = owner.GenerationCycleController.__dict__["_plan_n7_requirement_gap_if_requested"]
core = types.SimpleNamespace(make_codes=lambda *_args: (function.__code__, function.__code__, {}))
item = types.SimpleNamespace(nodeid=restore.NODE, module=types.SimpleNamespace(cycle_owner=owner))
config = types.SimpleNamespace(pluginmanager=types.SimpleNamespace(list_name_plugin=lambda: [("synthetic", types.ModuleType("synthetic"))]))
launch = {"launcher_sha256": "fixture", "core_sha256": "fixture", "binding_sha256": "fixture"}

class Report:
    nodeid = restore.NODE
    def __init__(self, when, outcome):
        self.when, self.outcome = when, outcome

before_environment = dict(os.environ)
with tempfile.TemporaryDirectory(dir=here) as name:
    root = Path(name)
    trace_path = root / "restore.jsonl"
    stream = trace_path.open("w", encoding="utf-8")
    guard = restore.RestorationGuard(stream, {}, core, launch)
    guard.check_pins = lambda: True
    guard.pytest_collection_modifyitems(None, config, [item])
    guard.pytest_runtest_logreport(Report("setup", "passed"))
    wrapper = guard.pytest_runtest_call(item)
    next(wrapper)
    assert owner.GenerationCycleController()._plan_n7_requirement_gap_if_requested() == "requirement_basis_not_established"
    try:
        next(wrapper)
    except StopIteration:
        pass
    else:
        raise AssertionError("restoration wrapper did not finish")
    guard.pytest_runtest_logreport(Report("call", "passed"))
    guard.pytest_runtest_logreport(Report("teardown", "passed"))
    session = types.SimpleNamespace(exitstatus=0)
    guard.pytest_sessionfinish(session, 0)
    assert session.exitstatus == 0
    guard.pytest_unconfigure(config)
    trace = [json.loads(line) for line in trace_path.read_text().splitlines()]
    assert next(row for row in trace if row["event"] == "restore_session_finish")["classification"] == "RESTORED_POSITIVE"
    bad = types.ModuleType("synthetic_bad_removal")
    bad.__file__ = str(here.parent / "R166-basis-mapping-removal-r1/e02_basis_removal.py")
    sys.modules["synthetic_bad_removal"] = bad
    assert restore.removal_modules() == ["synthetic_bad_removal"]
    del sys.modules["synthetic_bad_removal"]
    receipt_path = root / "parent-env.json"
    with env_owner.ParentEnvironmentGuard(receipt_path) as env_guard:
        removal_env = env_guard.child_environment(role="removal", updates={"E02_BASIS_REMOVAL_TRACE": "synthetic"})
        restore_env = env_guard.child_environment(role="restored", updates={"E02_BASIS_RESTORE_TRACE": "synthetic"})
        assert "E02_BASIS_REMOVAL_TRACE" not in restore_env
        env_guard.record_spawn(role="removal", pid=123, argv=["synthetic", "removal"], environment=removal_env)
        env_guard.record_spawn(role="restored", pid=124, argv=["synthetic", "restored"], environment=restore_env)
        os.environ["E02_BASIS_REMOVAL_TRACE"] = "synthetic-parent-change"
    receipt = json.loads(receipt_path.read_text())
    assert receipt["restored"] and receipt["before"] == receipt["after"]
    assert receipt["changed_keys"] == ["E02_BASIS_REMOVAL_TRACE"]
    assert [row["pid"] for row in receipt["children"]] == [123, 124]
assert dict(os.environ) == before_environment
print(json.dumps({"scope": "synthetic restoration guard, plugin census and parent env helper; fake pytest, no product import", "trace": trace, "parent_receipt": receipt, "parent_environment_restored": True}, indent=2))
