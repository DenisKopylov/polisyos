"""Prepare RAW-only C05 native templates from real physical source; never import/run product."""
from pathlib import Path
import ast,configparser,hashlib,json,math,subprocess
R=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos');P=R/'policy-engine'
O=R/'LOCAL/raw/e02-execution-20261027/repairs/C05-r8-native-admission-r2';O.mkdir(exist_ok=False)
D=P/'docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1'
HEAD='ea3d65682d76a5d66d514e525ad2212e5a85f669';TREE='7c5412fddc4ef3e56c859b83d237162e0fd260e7'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def record(p):return {'path':str(p.relative_to(R)),'sha256':sha(p),'bytes':p.stat().st_size}
def save(name,obj):(O/name).write_text(json.dumps(obj,indent=2)+'\n')
m=json.loads((R/'LOCAL/raw/e02-execution-20261027/repairs/C05-composed-fixture-r8/manifest.json').read_text())
modules=[x['path'] for x in m['files'] if x['role']=='mandatory semantic test companion'];assert len(modules)==14
inventory=[];node_map={};conftests=set();network=[];fixtures=[]
for path in modules:
 p=R/path;source=p.read_text();tree=ast.parse(source);rows=[]
 def visit(nodes,prefix=''):
  for n in nodes:
   if isinstance(n,ast.ClassDef) and n.name.startswith('Test'):visit(n.body,prefix+n.name+'::')
   if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_'):
    dims=[]
    for d in n.decorator_list:
     if isinstance(d,ast.Call) and isinstance(d.func,ast.Attribute) and d.func.attr=='parametrize':
      val=d.args[1] if len(d.args)>1 else next((k.value for k in d.keywords if k.arg=='argvalues'),None)
      dims.append(len(val.elts) if isinstance(val,(ast.List,ast.Tuple,ast.Set)) else None)
    node=str(p.relative_to(P))+'::'+prefix+n.name;count=math.prod(dims) if all(v is not None for v in dims) else None
    row={'node':node,'line':n.lineno,'literal_parameter_dimensions':dims,'source_derived_cases':count};rows.append(row);node_map[node]=row
 visit(tree.body)
 for n in ast.walk(tree):
  if isinstance(n,ast.Call):
   name=n.func.id if isinstance(n.func,ast.Name) else n.func.attr if isinstance(n.func,ast.Attribute) else None
   if name in {'TCPSite','ThreadingHTTPServer','HTTPServer','create_server','start_server','bind'}:
    network.append({'path':path,'line':n.lineno,'constructor':name,'expression':ast.get_source_segment(source,n)})
  if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):
   for d in n.decorator_list:
    if isinstance(d,ast.Call) and isinstance(d.func,ast.Attribute) and d.func.attr=='fixture' and any(k.arg=='params' for k in d.keywords):fixtures.append({'path':path,'fixture':n.name,'line':n.lineno})
 for parent in p.parents:
  if parent==P.parent:break
  c=parent/'conftest.py'
  if c.is_file():conftests.add(c)
 inventory.append({'path':path,'physical_canonical_path':str(p),'sha256':sha(p),'test_function_definitions':len(rows),'source_derived_cases':sum(x['source_derived_cases'] for x in rows) if all(x['source_derived_cases'] is not None for x in rows) else None,'nodes':rows,'runtime_collection':'UNRUN'})
for c in sorted(conftests):
 t=ast.parse(c.read_bytes())
 for n in ast.walk(t):
  if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):
   if n.name=='pytest_generate_tests':fixtures.append({'path':str(c.relative_to(R)),'generation_hook':n.name,'line':n.lineno})
   for d in n.decorator_list:
    if isinstance(d,ast.Call) and isinstance(d.func,ast.Attribute) and d.func.attr=='fixture' and any(k.arg=='params' for k in d.keywords):fixtures.append({'path':str(c.relative_to(R)),'fixture':n.name,'line':n.lineno})
save('collection-inventory.json',{'observed_reviewed_checkpoint':{'head':HEAD,'tree':TREE},'scope':'Complete14 physical test modules from C05 manifest plus actually present ancestor conftests. Literal AST collection expectations only; no pytest collection/import.','module_count':len(inventory),'function_definitions':sum(x['test_function_definitions'] for x in inventory),'source_derived_cases':sum(x['source_derived_cases'] for x in inventory),'modules':inventory,'ancestor_conftests':[record(c) for c in sorted(conftests)],'parametrized_fixture_or_generation_hooks':fixtures,'network_constructor_selector':network,'unresolved_by_construction':['Plugin/default hook effects, inheritance/dynamic generation and runtime fixture outcomes require actual collection and full XML reconciliation.','Literal network constructors identify expected test-owned loopback listeners, not a complete socket/child import census.'],'runtime':'UNRUN'})
# Retained .venv metadata/.pth declaration profile, no interpreter or module execution.
site=next((P/'.venv/lib').glob('python*/site-packages'));entryfiles=sorted([*site.glob('*.dist-info/entry_points.txt'),*site.glob('*.egg-info/entry_points.txt')]);plugins=[]
for entry in entryfiles:
 cfg=configparser.ConfigParser();cfg.read_string(entry.read_text())
 if 'pytest11' not in cfg:continue
 meta=entry.parent/'METADATA'
 if not meta.exists():meta=entry.parent/'PKG-INFO'
 lines=meta.read_text().splitlines();decl={k:next(v.removeprefix(k+': ') for v in lines if v.startswith(k+': ')) for k in ['Name','Version']}
 plugins.append({'distribution':decl,'entrypoints':dict(cfg['pytest11']),'entry_points':record(entry),'metadata':record(meta)})
pth=[record(q) for q in sorted(site.glob('*.pth'))]
editable=site/'_editable_impl_policy_engine.pth';assert editable.read_text().splitlines()==[str(P),str(P/'src')]
backend={'profile_kind':'Existing author .venv declared files only; actual imports/plugins UNRUN','python_resolved':str((P/'.venv/bin/python').resolve()),'venv_cfg':record(P/'.venv/pyvenv.cfg'),'venv_declared_text':(P/'.venv/pyvenv.cfg').read_text(),'pytest_ini':record(P/'pytest.ini'),'pyproject':record(P/'pyproject.toml'),'lock':record(P/'uv.lock'),'pth_file_denominator':len(pth),'pth_files':pth,'editable_declared_roots':editable.read_text().splitlines(),'entrypoint_file_denominator':len(entryfiles),'pytest11_distribution_count':len(plugins),'pytest11_entrypoint_count':sum(len(v['entrypoints']) for v in plugins),'pytest11':plugins,'conftest_plugins':['tests/_helpers/artifacts.py','tests/_helpers/observability.py'],'native_observer':record(D/'readset_observer_tools_r1.py'),'native_runner':record(D/'run_case_with_tools_r2.py'),'no_environment_copy_install_or_runtime':True}
save('backend-profile.json',backend)
sourcepins=[]
for row in m['files']:
 p=R/row['path'];raw=subprocess.check_output(['git','show',HEAD+':'+row['path']],cwd=R);assert p.read_bytes()==raw
 sourcepins.append(record(p))
for q in [P/'src/polisyos/common/serialization/__init__.py',P/'pytest.ini',P/'pyproject.toml',P/'uv.lock',*sorted(conftests),P/'tests/_helpers/artifacts.py',P/'tests/_helpers/observability.py']:
 if str(q.relative_to(R)) not in {x['path'] for x in sourcepins}:sourcepins.append(record(q))
harness=[D/'run_case_with_tools_r2.py',D/'readset_observer_tools_r1.py',D.parent/'root-layer-lib.py',P/'docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-postfix-709-q2-helper-actual-20261018/supervise.py']
save('source-basis.json',{'reviewed_checkpoint_head':HEAD,'reviewed_checkpoint_tree':TREE,'binding':'UNBOUND until Root finishes generator fix and supplies clean actual head/tree; this is not545c or8623 launch admission.','canonical_readset':sourcepins,'retained_harness':[record(p) for p in harness],'tree_objects':{name:subprocess.check_output(['git','rev-parse',HEAD+':policy-engine/'+name],cwd=R).decode().strip() for name in ['src','tests','tools','architecture','schemas']},'current_known_WIP':['policy-engine/src/polisyos/foundry/methods/base.pyi','policy-engine/src/polisyos/foundry/methods/components/composer.pyi','policy-engine/src/polisyos/foundry/methods/composer.pyi','policy-engine/src/polisyos/foundry/methods/registry.pyi'],'source_delta_rule':'At bind, complete base→actual changed path list is recorded; all explicit C05/read/config/test/harness/profile pins must still match. Any changed pinned source requires a new reviewed basis, not a blanket waiver. Other whole committed tree changes are disclosed for Root review, never called neutral solely from path disjointness.','source_lease':'D live ownership +source frame must stay byte-identical during each case; any Root commit/canonical mutation invalidates its receipt, even disjoint.'})
plans=[]
def add(name,nodes,purpose,kind='positive',required=None):
 for n in nodes:assert n.split('::')[0].startswith('tests/') and (P/n.split('::')[0]).is_file();assert '::' not in n or n in node_map,n
 count=sum(node_map[n]['source_derived_cases'] for n in nodes) if all(n in node_map for n in nodes) else sum(next(v['source_derived_cases'] for v in inventory if v['path']=='policy-engine/'+n) for n in nodes)
 template={'case_id':name+'-REBIND-REVISION','source_head':None,'source_tree':None,'nodes':nodes,'deadline_seconds':600,'rss_cap_bytes':2415919104,'extra_env':{'PYTHONNOUSERSITE':'1','PYTHONHASHSEED':'0','JAX_PLATFORMS':'cpu','NO_PROXY':'127.0.0.1,localhost','no_proxy':'127.0.0.1,localhost','POLISYOS_CONTROL_SQLITE_PATH':'REBIND_ABSOLUTE_CASE_DIRECTORY/control.sqlite3'},'scope':purpose,'expected_source_derived_testcases':count,'expected_collected_testcases':count,'collection_observed':'UNRUN','case_kind':kind,'prepared_plan_only':True,'root_admission_required':True,'required_preceding':required or [],'result_rule':'Normal:complete,exit0,no abort/mismatch,exact observed collection/XML,zero fails/errors/skips. Removal:baseline must already PASS,only named semantic assertions fail with no setup/decode/import error; restore exact source then new positive case.'}
 filename='template-'+name+'.json';save(filename,template);plans.append({'template':filename,'case_kind':kind,'nodes':nodes,'source_derived_cases':count})
pre='tests/unit/scientist/orchestration/llm/test_prepared_request_dispatch.py::'
scope='tests/unit/scientist/orchestration/llm/test_prompt_cache_scope_admission.py::'
cache='tests/unit/scientist/orchestration/llm/test_prompt_cache.py::'
prov='tests/unit/scientist/orchestration/llm/test_provider_verification.py::'
post='tests/integration/runtime/http/test_r3_pre_admission_attempt_owner.py::'
add('c05-r8-smoke00-decoder',[pre+'test_prepared_values_use_the_real_strict_decoder_contract',pre+'test_prepared_decoder_preserves_strict_refusal_with_stable_source'],'FIRST unknown native profile, run alone; actual canonical strict decoder positive and six refusal shapes after required-source forward fix.')
add('c05-r8-smoke01-call-and-preflight',[scope+'test_prebound_snapshot_compares_raw_invocation_before_current_owner_authorization',cache+'TestCachingLLMClient::test_skips_cache_for_tool_calls_and_freshness_sensitive_inputs',pre+'test_prebound_call_identity_preserves_native_type_and_value',cache+'test_opaque_python_call_preserves_original_values_after_admission',pre+'test_actual_gateway_keeps_json_arrays_and_rejects_unknown_before_dispatch',pre+'test_prepared_cache_plan_binds_one_actual_client_and_one_logical_call',prov+'test_provider_preflight_records_bound_gateway_completion_and_reuses_exact_event',prov+'test_preflight_uses_its_exact_prepared_request_across_catalog_waits',prov+'test_preflight_negotiated_success_cannot_supply_requested_format_reuse',prov+'test_cancelled_preflight_waiter_preserves_admitted_gateway_settlement_and_close'],'Exact raw invocation/current CAS owner, Python types/original opaque values, actual HTTP JSON and real preflight reuse/origin/late settlement after smoke00.',required=['c05-r8-smoke00-decoder'])
owner='tests/unit/scientist/orchestration/llm/test_cache_owner_admission.py::'
add('c05-r8-smoke02-lifetime',[owner+'test_every_cache_hit_requires_exact_retained_response_proof',owner+'test_actual_dependency_guard_failure_never_dispatches',owner+'test_closed_factory_scope_cannot_serve_a_retained_hit',owner+'test_started_producer_keeps_exact_owner_after_scope_close','tests/unit/runtime/http/test_control_nl_producer_admission.py::test_running_dependency_timeout_closes_without_holding_the_job_transaction'],'Current owner/proof/dependency timeout and real admitted in-flight settlement; no observation-access rewrite.',required=['c05-r8-smoke01-call-and-preflight'])
add('c05-r8-smoke03-actual-post',[post+'test_actual_nl_post_gateway_settlement_reopens_and_serves_same_run'],'Real research POST actual Gateway/durable ledger/pre-admission same-owner reuse. Root separately coordinates actual C71 observation-access consumers; a C71 refusal is not patched into public scope.',required=['c05-r8-smoke01-call-and-preflight','Root C71 actual consumer admission if affected'])
order=['test_prepared_request_dispatch.py','test_prompt_cache.py','test_prompt_cache_scope_admission.py','test_provider_verification.py','test_cache_settlement.py','test_traced_client_settlement.py','test_cache_owner_admission.py','test_control_nl_producer_admission.py','test_fallback_router.py','test_gateway_client_retry.py','test_llm_01.py','test_nl_pipeline_cost_projection.py','test_nl_pipeline_cache_reuse_authorization.py','test_r3_pre_admission_attempt_owner.py']
for i,name in enumerate(order,1):
 module=next(v for v in inventory if Path(v['path']).name==name);add(f'c05-r8-module{i:02d}-'+name.removeprefix('test_').removesuffix('.py').replace('_','-'),[module['path'].removeprefix('policy-engine/')],'Full physical canonical module; no -k/selection trimming. '+('Root coordinates C71 before real POST consumers.' if '/integration/' in module['path'] else 'Independent C05 component; no C71 wait required.'),required=['c05-r8-smoke00-decoder','fresh per-case resource/source admission'])
add('c05-r8-remove01-exact-binding',[scope+'test_prebound_snapshot_compares_raw_invocation_before_current_owner_authorization',pre+'test_prebound_call_identity_preserves_native_type_and_value'],'Root-only isolated declared mutation: replace exact input equality by lossy evidence/cache normalization while preserving admission and names. Expect semantic mismatch assertions FAIL after fixed decoder baseline PASS.','removal',['c05-r8-smoke01-call-and-preflight PASS','isolated exact mutation/source-frame receipt'])
add('c05-r8-remove02-python-dispatch',[cache+'TestCachingLLMClient::test_skips_cache_for_tool_calls_and_freshness_sensitive_inputs',cache+'test_opaque_python_call_preserves_original_values_after_admission'],'Root-only isolated declared mutation: generic JSON roundtrip before actual Python provider call; preserve producer begin and actual Gateway JSON. Expect actual observed types/original-value assertions FAIL.','removal',['c05-r8-smoke01-call-and-preflight PASS','isolated exact mutation/source-frame receipt'])
add('c05-r8-remove03-preflight-reuse',[prov+'test_provider_preflight_records_bound_gateway_completion_and_reuses_exact_event',post+'test_actual_nl_post_gateway_settlement_reopens_and_serves_same_run'],'Root-only isolated declared mutation: actual preflight prepared reusability False while same actual Gateway executes. Require genuine reuse/count FAIL, never missing-source setup failure.','removal',['c05-r8-smoke01-call-and-preflight PASS','c05-r8-smoke03-actual-post PASS','isolated exact mutation/source-frame receipt'])
for i,target in enumerate(['c05-r8-remove01-exact-binding','c05-r8-remove02-python-dispatch','c05-r8-remove03-preflight-reuse'],1):
 row=next(x for x in plans if x['template']=='template-'+target+'.json');add('c05-r8-restore'+str(i).zfill(2),row['nodes'],'After exact restoration, fresh declared positive replay of the same property selectors.','restoration',[target+' semantic FAIL, not setup error','exact pre-mutation source restored and read back'])
save('sequence.json',{'status':'UNBOUND PLAN ONLY','first_unknown_profile':'c05-r8-smoke00-decoder alone600s/2.25GiB; inspect actual wall/RSS/XML/readset before next admission. No new concurrent native case.','full_module_count':len(order),'full_module_source_derived_cases':sum(x['source_derived_cases'] for x in inventory),'plans':plans,'bound_run_order':'smoke00→smoke01→smoke02; smoke03 only when actual source-access contract is admitted; full14 modules sequentially or Root separately measured grouping; each removal only after its baseline PASS, one isolated mutation at a time, then exact restore and same selectors PASS.','runtime':'UNRUN'})
print(json.dumps({'out':str(O),'module_count':len(inventory),'test_definitions':sum(x['test_function_definitions'] for x in inventory),'source_derived_cases':sum(x['source_derived_cases'] for x in inventory),'templates':len(plans),'installed_pytest11_distributions':len(plugins),'pytest11_entries':sum(len(x['entrypoints']) for x in plugins),'entrypoint_files':len(entryfiles),'pth_files':len(pth),'param_fixture_hooks':fixtures},indent=2))
