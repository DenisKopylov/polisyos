"""Capture selected Mach-O images actually mapped in this macOS process."""
from __future__ import annotations

import ctypes
import hashlib
import json
import os
import sys
import uuid
from pathlib import Path


def _sha_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def _sysctl_string(name: str) -> str | None:
    libc = ctypes.CDLL(None)
    fn = libc.sysctlbyname
    fn.argtypes = (ctypes.c_char_p, ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t), ctypes.c_void_p, ctypes.c_size_t)
    fn.restype = ctypes.c_int
    size = ctypes.c_size_t()
    if fn(name.encode(), None, ctypes.byref(size), None, 0) != 0 or not size.value:
        return None
    buf = ctypes.create_string_buffer(size.value)
    if fn(name.encode(), buf, ctypes.byref(size), None, 0) != 0:
        return None
    return buf.value.decode('utf-8', errors='replace')


def snapshot() -> dict:
    """Read the dyld-loaded image set; do not load a candidate provider library."""
    if sys.platform != 'darwin':
        return {'status': 'unavailable', 'reason': 'not macOS'}
    api = ctypes.CDLL(None)
    try:
        count = api._dyld_image_count
        count.argtypes = (); count.restype = ctypes.c_uint32
        name = api._dyld_get_image_name
        name.argtypes = (ctypes.c_uint32,); name.restype = ctypes.c_char_p
        header = api._dyld_get_image_header
        header.argtypes = (ctypes.c_uint32,); header.restype = ctypes.c_void_p
        cached = api._dyld_shared_cache_contains_path
        cached.argtypes = (ctypes.c_char_p,); cached.restype = ctypes.c_bool
        image_uuid = api._dyld_get_image_uuid
        image_uuid.argtypes = (ctypes.c_void_p, ctypes.POINTER(ctypes.c_ubyte)); image_uuid.restype = ctypes.c_bool
        cache_uuid = api._dyld_get_shared_cache_uuid
        cache_uuid.argtypes = (ctypes.POINTER(ctypes.c_ubyte),); cache_uuid.restype = ctypes.c_bool
        cache_range = api._dyld_get_shared_cache_range
        cache_range.argtypes = (ctypes.POINTER(ctypes.c_size_t),); cache_range.restype = ctypes.c_void_p
    except AttributeError as exc:
        return {'status':'unavailable','reason':f'dyld symbol unavailable: {exc}'}
    cache = (ctypes.c_ubyte * 16)()
    cache_id = str(uuid.UUID(bytes=bytes(cache))) if cache_uuid(cache) else None
    cache_size = ctypes.c_size_t()
    cache_start = cache_range(ctypes.byref(cache_size))
    try:
        overridden = api.dyld_shared_cache_some_image_overridden
        overridden.argtypes = (); overridden.restype = ctypes.c_bool
        any_cache_override = bool(overridden())
    except AttributeError:
        any_cache_override = None
    try:
        interpose = api.dyld_has_inserted_or_interposing_libraries
        interpose.argtypes = (); interpose.restype = ctypes.c_bool
        has_interposing = bool(interpose())
    except AttributeError:
        has_interposing = None
    initial = int(count())
    matches = []
    for index in range(initial):
        raw = name(index)
        if not raw:
            continue
        path = os.fsdecode(raw)
        lower = path.lower()
        if not any(token in lower for token in ('accelerate.framework', 'veclib.framework', 'libblas', 'liblapack', 'libjax_common', '/numpy/', '/scipy/', '/jaxlib/')):
            continue
        current_header = header(index)
        image = (ctypes.c_ubyte * 16)()
        image_id = str(uuid.UUID(bytes=bytes(image))) if current_header and image_uuid(current_header, image) else None
        from_cache = bool(cached(raw))
        p = Path(path)
        file_hash = None
        file_error = None
        if p.is_file():
            try:
                file_hash = _sha_file(p)
            except OSError as exc:
                file_error = f'{type(exc).__name__}: {exc}'
        elif not from_cache:
            file_error = 'mapped image path is neither available as file nor recognized in active shared cache'
        header_in_cache_range = bool(cache_start and current_header and cache_start <= current_header < cache_start + cache_size.value)
        matches.append({'path':path, 'dyld_image_uuid':image_id, 'path_is_in_shared_cache':from_cache,
                        'header_in_shared_cache_range':header_in_cache_range,
                        'sha256_if_file_backed':file_hash, 'file_error':file_error})
    final = int(count())
    return {'status':'observed' if initial==final else 'unstable', 'dyld_image_count_before':initial,
            'dyld_image_count_after':final, 'active_shared_cache_uuid':cache_id,
            'shared_cache_range_available': bool(cache_start and cache_size.value),
            'any_shared_cache_image_overridden':any_cache_override,
            'inserted_or_interposing_libraries':has_interposing,
            'os_build':_sysctl_string('kern.osversion'), 'images':sorted(matches,key=lambda row:row['path']),
            'identity_boundary':'Dyld image UUID and active shared-cache UUID identify mapped Mach-O/cache objects; neither is a cryptographic digest of shared-cache image bytes. File-backed matched images have SHA-256 when readable.',
            'observation_boundary':'Current-process snapshot, not a complete history of prior images or a guarantee against concurrent unload/reload.'}


if __name__ == '__main__':
    print(json.dumps(snapshot(), indent=2, sort_keys=True))
