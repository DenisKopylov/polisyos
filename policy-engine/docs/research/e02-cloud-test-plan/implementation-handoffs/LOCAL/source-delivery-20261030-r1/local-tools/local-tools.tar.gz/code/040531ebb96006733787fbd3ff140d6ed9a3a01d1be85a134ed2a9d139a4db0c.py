from __future__ import annotations

import ast
import difflib
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
OUT = ROOT / 'LOCAL/raw/e02-execution-20261027/repairs/V3-rule-math-reader-r1'
R1 = ROOT / 'LOCAL/raw/e02-execution-20261027/repairs/V3-world-rule-quantity-r1'
BASE = '2130f07de1eb93316d22bf5f91adc05ded67fbd2'
TREE = 'd67b5b827eb0d0f7286603d2c214c3d68a98675a'
P = 'policy-engine/'
DATA = P + 'src/polisyos/runtime/quality/data_state_substrate.py'
EVAL = P + 'src/polisyos/runtime/quality/acquisition_evaluation.py'
DISPATCH = P + 'src/polisyos/runtime/quality/acquisition_evaluation_dispatch.py'
GROWTH = P + 'src/polisyos/runtime/quality/acquisition_world_growth.py'
N5 = P + 'src/polisyos/runtime/quality/n5_execution_basis.py'
AUTH = P + 'src/polisyos/runtime/quality/agent_action_authority.py'
ACTION = P + 'src/polisyos/runtime/http/services/acquisition_action_service.py'
PORT = P + 'src/polisyos/runtime/http/services/acquisition_surface_execution.py'
HELPER = P + 'tests/_helpers/world_model_record.py'
WORLDTEST = P + 'tests/integration/core_runtime/test_acquisition_world_semantic_preparation.py'
DOC = P + 'src/polisyos/runtime/quality/README.md'
RELEASE = P + 'release-fragments/unreleased/2026-10-29-acquisition-owned-evaluation-retention.toml'
PATHS = (DATA, EVAL, DISPATCH, GROWTH, HELPER, WORLDTEST, DOC, RELEASE)
sha = lambda x: hashlib.sha256(x).hexdigest()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == BASE
assert subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, text=True).strip() == TREE
r1 = json.loads((R1 / 'manifest.json').read_text())
assert sha((R1 / 'manifest.json').read_bytes()) == 'a6b5b84501ea533b0e8f8f5bca062b78819933fa5650003a67d63d625ba12de2'
before = {}
after = {}
for path in PATHS:
    raw = (ROOT / path).read_bytes()
    assert raw == subprocess.check_output(['git', 'show', f'{BASE}:{path}'], cwd=ROOT)
    before[path] = raw.decode('utf-8')
    if path in (DATA, HELPER, WORLDTEST):
        post = (R1 / 'postimage' / path).read_bytes()
        assert sha(post) == r1['postimages'][path]['sha256']
        after[path] = post.decode('utf-8')
    else:
        after[path] = before[path]


def replace_one(path: str, original: str, replacement: str) -> None:
    assert after[path].count(original) == 1, (path, original)
    after[path] = after[path].replace(original, replacement, 1)

# Subsequent replacements are source-bound to the exact 2130 preimages.

replace_one(EVAL,
'''PRODUCER = "polisyos.runtime.acquisition_evaluation"
''',
'''PRODUCER = "polisyos.runtime.acquisition_evaluation"

# Readers understand both versions before any new comparison record is emitted.
# Enabling v2 requires the staged old-source/restart compatibility controls.
_COMPARISON_V2_EMITTER_ENABLED = False
_BASIS_V1 = "controlled_acquired_observation_ncm_v1"
_BASIS_V2 = "controlled_acquired_observation_ncm_v2"
type _BasisProfile = Literal[
    "controlled_acquired_observation_ncm_v1", "controlled_acquired_observation_ncm_v2"
]
''')
replace_one(EVAL,
'''    schema_version: Literal["AcquisitionEvaluationBasis@1.0"] = "AcquisitionEvaluationBasis@1.0"
''',
'''    schema_version: Literal["AcquisitionEvaluationBasis@1.0", "AcquisitionEvaluationBasis@1.1"] = (
        "AcquisitionEvaluationBasis@1.0"
    )
''')
replace_one(EVAL,
'''    comparison_profile: Literal["controlled_acquired_observation_ncm_v1"] = (
        "controlled_acquired_observation_ncm_v1"
    )
''',
'''    comparison_profile: _BasisProfile = "controlled_acquired_observation_ncm_v1"
''')
replace_one(EVAL,
'''    def _content(self) -> AcquisitionEvaluationBasis:
        try:
''',
'''    def _content(self) -> AcquisitionEvaluationBasis:
        if (self.schema_version, self.comparison_profile) not in {
            ("AcquisitionEvaluationBasis@1.0", _BASIS_V1),
            ("AcquisitionEvaluationBasis@1.1", _BASIS_V2),
        }:
            raise ValueError("acquisition_evaluation_basis_profile_version_mismatch")
        try:
''')
replace_one(EVAL,
'''    schema_version: Literal["AcquisitionEvaluationDecision@1.0"] = (
        "AcquisitionEvaluationDecision@1.0"
    )
''',
'''    schema_version: Literal[
        "AcquisitionEvaluationDecision@1.0", "AcquisitionEvaluationDecision@1.1"
    ] = "AcquisitionEvaluationDecision@1.0"
''')
replace_one(EVAL,
'''    comparison_rule: Literal["AD-E02-B09-01/owned-complete-native-values/v1"] = (
        "AD-E02-B09-01/owned-complete-native-values/v1"
    )
''',
'''    comparison_rule: Literal[
        "AD-E02-B09-01/owned-complete-native-values/v1",
        "AD-E02-B09-01/owned-complete-native-values/v2",
    ] = "AD-E02-B09-01/owned-complete-native-values/v1"
''')
replace_one(EVAL,
'''    def _content(self) -> AcquisitionEvaluationDecision:
        if self.content_hash != exact_n5_content_hash(
''',
'''    def _content(self) -> AcquisitionEvaluationDecision:
        if (self.schema_version, self.comparison_rule) not in {
            ("AcquisitionEvaluationDecision@1.0", "AD-E02-B09-01/owned-complete-native-values/v1"),
            ("AcquisitionEvaluationDecision@1.1", "AD-E02-B09-01/owned-complete-native-values/v2"),
        }:
            raise ValueError("acquisition_evaluation_decision_rule_version_mismatch")
        if self.content_hash != exact_n5_content_hash(
''')
replace_one(EVAL,
'''    payload = record.model_dump(mode="json")
    identity = record.content_hash.removeprefix("sha256:")
''',
'''    payload = record.model_dump(mode="json")
    version = record.schema_version.rsplit("@", 1)[-1]
    if version == "1.1" and not _COMPARISON_V2_EMITTER_ENABLED:
        raise ValueError("acquisition_evaluation_v2_emitter_disabled")
    identity = record.content_hash.removeprefix("sha256:")
''')
replace_one(EVAL,
'''            schema=artifacts.SchemaInfo(name=record.ARTIFACT_SCHEMA_NAME, version="1.0"),
            producer=artifacts.ProducerInfo(component=PRODUCER, version="1.0"),
''',
'''            schema=artifacts.SchemaInfo(name=record.ARTIFACT_SCHEMA_NAME, version=version),
            producer=artifacts.ProducerInfo(component=PRODUCER, version=version),
''')
replace_one(EVAL,
'''        reader_contract_version="1.0",
''',
'''        reader_contract_version=version,
''')
replace_one(EVAL,
'''        or manifest.artifact_schema.version != "1.0"
        or manifest.producer is None
        or manifest.producer.component != PRODUCER
        or manifest.producer.version != "1.0"
''',
'''        or manifest.artifact_schema.version not in {"1.0", "1.1"}
        or manifest.producer is None
        or manifest.producer.component != PRODUCER
        or manifest.producer.version != manifest.artifact_schema.version
''')
replace_one(EVAL,
'''    record = record_type.model_validate(load_core_json_artifact(store, ref))
    expected_inputs = tuple(
''',
'''    record = record_type.model_validate(load_core_json_artifact(store, ref))
    if record.schema_version.rsplit("@", 1)[-1] != manifest.artifact_schema.version:
        raise ValueError("acquisition_evaluation_artifact_version_mismatch")
    expected_inputs = tuple(
''')
replace_one(EVAL,
'''        left.predicate_provenance == right.predicate_provenance == "recomputed"
        and bytes.fromhex(left.effective_native_values_hex)
''',
'''        left.predicate_provenance == right.predicate_provenance == "recomputed"
        and left.comparison_profile == right.comparison_profile
        and bytes.fromhex(left.effective_native_values_hex)
''')

replace_one(EVAL,
'''    actual_evaluation: bool,
    _historical_read_only: bool = False,
) -> tuple[dict[str, object], tuple[str, ...]]:
''',
'''    actual_evaluation: bool,
    _historical_read_only: bool = False,
    _comparison_profile: _BasisProfile = "controlled_acquired_observation_ncm_v1",
) -> tuple[dict[str, object], tuple[str, ...]]:
''')
replace_one(EVAL,
'''    from polisyos.foundry.data_plane import load_input_bindings
    from polisyos.foundry.execute import load_state_snapshot, state_snapshot_value_projection
''',
'''    from polisyos.foundry.data_plane import load_input_bindings, prepare_input_bindings
    from polisyos.foundry.execute import load_state_snapshot, state_snapshot_value_projection
''')
replace_one(EVAL,
'''    if type(prepared) is not AcquisitionCandidatePreparation:
        raise TypeError("acquisition_evaluation_preparation_not_owner_typed")
    reasons: list[str] = []
''',
'''    if type(prepared) is not AcquisitionCandidatePreparation:
        raise TypeError("acquisition_evaluation_preparation_not_owner_typed")
    if _comparison_profile not in {_BASIS_V1, _BASIS_V2}:
        raise ValueError("acquisition_evaluation_comparison_profile_unsupported")
    reasons: list[str] = []
''')
replace_one(EVAL,
'''            rules = list(bindings.rules)
            effective_rule = observation["binding_rule"]
''',
'''            if _comparison_profile == _BASIS_V2:
                owner_preparation = prepare_input_bindings(
                    bridge.artifact_store,
                    data_snapshot_ref=views.data_snapshot_ref,
                    registry_bundle_ref=views.registry_bundle_ref,
                    rules=list(bindings.rules),
                )
                if state_snapshot_value_projection(owner_preparation.materialized_state) != (
                    state_snapshot_value_projection(state)
                ):
                    raise ValueError("acquisition_evaluation_binding_state_mismatch")
                rules = list(owner_preparation.effective_rules)
            else:
                rules = list(bindings.rules)
            effective_rule = observation["binding_rule"]
''')
replace_one(EVAL,
'''        if world["predicate_provenance"] != "recomputed":
            reasons.extend(str(reason) for reason in world["reason_codes"])
        # Verify the exact owner rule before replacing its generated report
''',
'''        if world["predicate_provenance"] != "recomputed":
            reasons.extend(str(reason) for reason in world["reason_codes"])
        elif _comparison_profile == _BASIS_V1:
            # Pinned 2130 v1 mathematical projection; an old artifact still
            # requires independently qualified historical comparator source.
            from polisyos.runtime.quality.data_state_substrate import (
                _effective_acquired_world_rules,
                _prepare_acquired_observation_world,
            )

            if actual_evaluation:
                legacy_rules = tuple(bindings.rules)
            else:
                legacy_rules = _prepare_acquired_observation_world(
                    bridge.artifact_store,
                    base_world_model_record=prepared.base_world,
                    acquired_rule=owned_rule,
                    registry_bundle_ref=world_model_artifact_views(
                        prepared.base_world
                    ).registry_bundle_ref,
                    substrate_registry=prepared.configured_profile.context_inputs.substrate_registry,
                ).rules
            legacy_world = dict(world["effective_values"])
            legacy_world["rules"] = _effective_acquired_world_rules(legacy_rules, owned_rule)
            world = {**world, "effective_values": legacy_world}
        # Verify the exact owner rule before replacing its generated report
''')

# History uses the selected profile's projection; the retained v1 branch above
# reconstructs the pinned 2130 order, while v2 uses Foundry's effective order.
replace_one(EVAL,
'''        actual_evaluation=basis.evaluation is not None,
        _historical_read_only=True,
''',
'''        actual_evaluation=basis.evaluation is not None,
        _historical_read_only=True,
        _comparison_profile=basis.comparison_profile,
''')
replace_one(GROWTH,
'''        from polisyos.foundry.data_plane import InputBindingValuesPreparation, load_input_bindings
''',
'''        from polisyos.foundry.data_plane import (
            InputBindingValuesPreparation,
            load_input_bindings,
            prepare_input_bindings,
        )
''')
replace_one(GROWTH,
'''        if actual_bindings.rules != list(prospective_values.effective_rules):
            raise ValueError("acquisition_prospective_rule_owner_reconciliation_failed")
''',
'''        replayed = prepare_input_bindings(
            self.artifact_store,
            data_snapshot_ref=actual_world_views.data_snapshot_ref,
            registry_bundle_ref=actual_world_views.registry_bundle_ref,
            rules=list(actual_bindings.rules),
        )
        if (
            replayed.effective_rules != prospective_values.effective_rules
            or replayed.applied_binding_ids != prospective_values.applied_binding_ids
            or replayed.warnings != prospective_values.warnings
            or state_snapshot_value_projection(replayed.materialized_state)
            != state_snapshot_value_projection(actual_state)
        ):
            raise ValueError("acquisition_prospective_rule_owner_reconciliation_failed")
''')
replace_one(DISPATCH,
'''    if (
        old_basis.predicate_provenance != "recomputed"
''',
'''    if old_basis.comparison_profile != current.comparison_profile:
        return (
            current,
            old_ref,
            selected,
            "not_established",
            ("acquisition_comparison_profile_relation_not_established",),
            frontier,
            prior,
        )
    if (
        old_basis.predicate_provenance != "recomputed"
''')
replace_one(DISPATCH,
'''            or record.predicate_provenance != replay.predicate_provenance
''',
'''            or record.comparison_profile != replay.comparison_profile
            or record.predicate_provenance != replay.predicate_provenance
''')

# Extend the existing actual WMR fixture to exercise the outer bridge with its
# real persisted snapshot/registry. This is not a production authority claim.
replace_one(WORLDTEST,
'''    assert persisted_world == actual.world_model.record
    persisted_rules = load_input_bindings(
''',
'''    assert persisted_world == actual.world_model.record
    from polisyos.runtime.http.services.control_plane_store import ControlPlaneStore
    from polisyos.runtime.quality.acquisition_world_growth import (
        AcquisitionWorldGrowthBridge,
        AcquisitionWorldGrowthConfig,
    )
    from polisyos.runtime.quality.event_log import RuntimeDiagnosticEventLog

    control_store = ControlPlaneStore(backend="sqlite", sqlite_path=tmp_path / "control.sqlite")
    bridge = AcquisitionWorldGrowthBridge(
        config=AcquisitionWorldGrowthConfig(),
        repo_root=tmp_path,
        runtime_root=tmp_path,
        authority=case.scenario.authority,
        artifact_store=fresh_store,
        event_log=RuntimeDiagnosticEventLog(store=control_store, artifact_store=fresh_store),
        epoch_deployment=None,
    )
    bridge._reconcile_acquired_candidate_values(
        prospective_values=numerical, world_model_record=persisted_world
    )
    persisted_rules = load_input_bindings(
''')
replace_one(WORLDTEST,
'''        assert same_operations == observed

    # Supplied order is not an execution order; the actual Foundry owner
''',
'''        assert same_operations == observed
        bridge._reconcile_acquired_candidate_values(
            prospective_values=numerical, world_model_record=persisted_world
        )

    def altered_retained_reader(reader_store, ref):
        typed = load_input_bindings(reader_store, ref)
        changed = [
            rule.model_copy(update={"notes": ["different retained owner note"]})
            if rule.binding_id == first.binding_id
            else rule
            for rule in typed.rules
        ]
        return typed.model_copy(update={"rules": changed})

    with monkeypatch.context() as altered:
        altered.setattr(foundry_data_plane, "load_input_bindings", altered_retained_reader)
        with pytest.raises(
            ValueError, match="acquisition_prospective_rule_owner_reconciliation_failed"
        ):
            bridge._reconcile_acquired_candidate_values(
                prospective_values=numerical, world_model_record=persisted_world
            )
    bridge._reconcile_acquired_candidate_values(
        prospective_values=numerical, world_model_record=persisted_world
    )

    # Supplied order is not an execution order; the actual Foundry owner
''')
replace_one(DOC,
'''The controlled acquired-observation dispatcher separates three owner operations:
''',
'''The world semantic reader and candidate bridge resolve the selected Foundry
snapshot and registry through the real binding preparation owner. They compare
its complete ordered operations, applied IDs, warnings and materialized state;
the encoded list order is not itself an execution-order admission rule. Rule
IDs and their source-to-target association remain load-bearing. The bounded
fixture reopens the produced WMR through a fresh CAS and includes overlapping
writes; it does not establish active-SKG quantity custody.

The versioned comparison reader can parse Basis/Decision @1.0 and @1.1. The
v2 quantity uses Foundry effective rule order on both ports, but the v2 writer
is disabled. V1's 2130 projection is retained for source-qualified replay;
legacy records do not themselves identify their comparator source. Establishing
a particular old record's source law, reentry-only current guards and a fresh
process recovery remains `verification_missing`. Do not treat a readable v1
record, an N5 implementation witness or a Core node identity as proof of that
source binding or a current retention permit. Mixed profiles have no established
comparison relation. This is a bounded implementation proposal, not G acceptance.

The controlled acquired-observation dispatcher separates three owner operations:
''')
replace_one(RELEASE,
'''limitations = "Same-live-process observed controlled NCM profile only.''',
'''limitations = "The versioned effective-rule comparison writer is disabled; legacy comparator-source qualification and fresh-process reentry remain verification_missing, and mixed comparison profiles are not equivalent by declaration. Same-live-process observed controlled NCM profile only.''')

postimages = {}
preimages = {}
parts = []
for path in PATHS:
    if path.endswith('.py'):
        ast.parse(after[path], filename=path)
    preimages[path] = {
        'source': path + '@' + BASE,
        'sha256': sha(before[path].encode()),
        'git_blob': subprocess.check_output(['git', 'rev-parse', f'{BASE}:{path}'], cwd=ROOT, text=True).strip(),
    }
    if after[path] == before[path]:
        continue
    post = OUT / 'postimage' / path
    post.parent.mkdir(parents=True, exist_ok=True)
    post.write_text(after[path])
    assert post.read_bytes() == after[path].encode()
    postimages[path] = {'path': str(post.relative_to(ROOT)), 'sha256': sha(post.read_bytes())}
    parts.extend(difflib.unified_diff(
        before[path].splitlines(keepends=True), after[path].splitlines(keepends=True),
        fromfile='a/' + path, tofile='b/' + path,
    ))
patch = OUT / 'proposal.patch'
patch.write_text(''.join(parts))
(OUT / 'preimages.json').write_text(json.dumps(preimages, indent=2, sort_keys=True) + '\n')
manifest = {
    'status': 'HOLD — bounded mathematics and reader candidate; not a complete migration, not for application',
    'base': BASE, 'tree': TREE,
    'postimages': postimages,
    'preimages': {'path': str((OUT / 'preimages.json').relative_to(ROOT)),
                  'sha256': sha((OUT / 'preimages.json').read_bytes())},
    'patch': {'path': str(patch.relative_to(ROOT)), 'sha256': sha(patch.read_bytes())},
    'r1_manifest': {'path': str((R1 / 'manifest.json').relative_to(ROOT)),
                    'sha256': sha((R1 / 'manifest.json').read_bytes())},
    'runtime_status': 'UNRUN; no product imports or tests',
    'readme': {'path': str((OUT / 'README.md').relative_to(ROOT)),
               'sha256': sha((OUT / 'README.md').read_bytes())},
    'static_checks': {'path': str((OUT / 'static-checks.json').relative_to(ROOT)),
                      'sha256': sha((OUT / 'static-checks.json').read_bytes())},
    'static_checker': {'path': str((OUT / 'static_check.py').relative_to(ROOT)),
                       'sha256': sha((OUT / 'static_check.py').read_bytes())},
    'author': {'path': str((OUT / 'prepare.py').relative_to(ROOT)),
               'sha256': sha((OUT / 'prepare.py').read_bytes())},
}
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
print(json.dumps({'manifest_sha256': sha((OUT / 'manifest.json').read_bytes()),
                  'patch_sha256': sha(patch.read_bytes()), 'postimage_count': len(postimages)}))
