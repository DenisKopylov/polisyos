"""Select the same semantic case for unmodified C43 before/after controls."""
from __future__ import annotations
import hashlib
import json
import os
import subprocess
from pathlib import Path
import pytest

_STATE = {}


def _need(name: str) -> str:
    value = os.environ.get(name)
    if not value:
        raise pytest.UsageError('C43 selection requires ' + name)
    return value


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pytest_configure(config: pytest.Config) -> None:
    root = Path(config.rootpath).resolve(strict=True)
    if root != Path.cwd().resolve(strict=True):
        raise pytest.UsageError('C43 selection requires product cwd')
    if _sha(Path(__file__).resolve(strict=True)) != _need('C43_SELECT_PLUGIN_SHA256'):
        raise pytest.UsageError('C43 selection plugin mismatch')
    test = root / 'tests/unit/remediation/test_c43_joint_gaussian.py'
    if _sha(test) != _need('C43_CONTROL_TEST_SHA256'):
        raise pytest.UsageError('C43 selection test mismatch')
    source = root / _need('C43_CONTROL_SOURCE_RELATIVE')
    if _sha(source) != _need('C43_CONTROL_SOURCE_SHA256'):
        raise pytest.UsageError('C43 selection source mismatch')
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
    tree = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=root, text=True).strip()
    if head != _need('C43_CONTROL_SOURCE_HEAD') or tree != _need('C43_CONTROL_SOURCE_TREE'):
        raise pytest.UsageError('C43 selection head/tree mismatch')
    output = Path(_need('C43_CONTROL_OUTPUT')).resolve(strict=True)
    if output != Path(_need('POLISYOS_R4_INPUT_READSET_DIR')).parent.resolve(strict=True):
        raise pytest.UsageError('C43 selection output mismatch')
    choice = json.loads(_need('C43_SELECTED_CASE'))
    if set(choice) != {'function', 'parameters', 'expected_collected'}:
        raise pytest.UsageError('C43 selection malformed')
    _STATE.update(choice=choice, output=output)


@pytest.hookimpl(tryfirst=True)
def pytest_collection_modifyitems(config: pytest.Config, items: list[pytest.Item]) -> None:
    choice = _STATE['choice']
    if len(items) != choice['expected_collected']:
        raise pytest.UsageError('C43 selection cardinality changed')
    selected = []
    for item in items:
        if getattr(item, 'originalname', None) != choice['function']:
            raise pytest.UsageError('C43 selection function changed')
        actual = getattr(getattr(item, 'callspec', None), 'params', {})
        expected = choice['parameters']
        if set(actual) == set(expected) and all(type(actual[k]) is type(v) and actual[k] == v for k, v in expected.items()):
            selected.append(item)
    if len(selected) != 1:
        raise pytest.UsageError('C43 selection is not unique')
    deselected = [item for item in items if item is not selected[0]]
    out = _STATE['output'] / 'semantic-case-selection.json'
    if out.exists() or out.is_symlink():
        raise pytest.UsageError('C43 selection output exists')
    out.write_text(json.dumps({'selected_node': selected[0].nodeid, 'parameters': choice['parameters'], 'deselected_nodes': [item.nodeid for item in deselected], 'mutation': False}, indent=2, sort_keys=True) + '\n')
    config.hook.pytest_deselected(items=deselected)
    items[:] = selected
