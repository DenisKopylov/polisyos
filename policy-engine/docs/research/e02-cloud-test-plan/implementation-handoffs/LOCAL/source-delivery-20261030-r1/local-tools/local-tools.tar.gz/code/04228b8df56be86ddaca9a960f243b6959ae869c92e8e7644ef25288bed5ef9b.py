"""Refresh exact RAW artifacts from the five postimages; no product import or Git write."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import re
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[4]
PRODUCT = ROOT / "policy-engine"
PYTHON = PRODUCT / ".venv/bin/python"
POST = OUT / "postimages"
BINDINGS = json.loads((OUT / "source-bindings.json").read_text())


def sha(data):
    return hashlib.sha256(data).hexdigest()


def delta(path, before, after):
    prefix = "diff --git a/" + path + " b/" + path + "\n"
    if before is None:
        prefix += "new file mode 100644\n"
    return prefix + "".join(difflib.unified_diff(
        [] if before is None else before.decode().splitlines(keepends=True),
        after.decode().splitlines(keepends=True),
        fromfile="/dev/null" if before is None else "a/" + path, tofile="b/" + path))


def relocate_exact_hunks(source, patch):
    lines = patch.splitlines(keepends=True)
    starts = [i for i, line in enumerate(lines) if line.startswith("@@ ")]
    for ordinal, start in enumerate(starts):
        end = starts[ordinal + 1] if ordinal + 1 < len(starts) else len(lines)
        payload = lines[start + 1:end]
        assert all(line[0] in " +-" for line in payload)
        before = "".join(line[1:] for line in payload if line[0] in " -")
        after = "".join(line[1:] for line in payload if line[0] in " +")
        assert source.count(before) == 1
        source = source.replace(before, after, 1)
    ast.parse(source)
    return source


ruff_rows = []
for path in sorted(POST.rglob("*.py")):
    logical = path.relative_to(POST)
    run = subprocess.run([str(PYTHON), "-m", "ruff", "format", "--stdin-filename", str(ROOT / logical)],
                         cwd=PRODUCT, input=path.read_bytes(), capture_output=True)
    assert run.returncode == 0
    path.write_bytes(run.stdout)
    ast.parse(run.stdout.decode())
    check = subprocess.run([str(PYTHON), "-m", "ruff", "check", "--no-cache", "--stdin-filename", str(ROOT / logical)],
                           cwd=PRODUCT, input=run.stdout, capture_output=True)
    fmt = subprocess.run([str(PYTHON), "-m", "ruff", "format", "--check", "--stdin-filename", str(ROOT / logical)],
                         cwd=PRODUCT, input=run.stdout, capture_output=True)
    assert check.returncode == fmt.returncode == 0, check.stdout.decode()
    ruff_rows.append({"path": str(logical), "bytes": len(run.stdout), "sha256": sha(run.stdout),
                      "AST": "PASS", "check_exit": check.returncode, "check_stdout": check.stdout.decode(),
                      "check_stderr": check.stderr.decode(), "format_exit": fmt.returncode,
                      "format_stdout": fmt.stdout.decode(), "format_stderr": fmt.stderr.decode()})
(OUT / "static-ruff.json").write_text(json.dumps({"scope": "Three RAW Python postimages under canonical logical filenames; no product imports/runtime.", "records": ruff_rows}, indent=2) + "\n")

source_patch = ""
for row in BINDINGS["rows"]:
    run = subprocess.run(["git", "show", BINDINGS["root_entry_commit"] + ":" + row["path"]], cwd=ROOT, capture_output=True)
    before = None if run.returncode else run.stdout
    assert (None if before is None else sha(before)) == row["root_entry_sha256"]
    after = (OUT / row["postimage"]).read_bytes()
    row["postimage_sha256"], row["bytes"] = sha(after), len(after)
    source_patch += delta(row["path"], before, after)
(OUT / "source.patch").write_text(source_patch)
(OUT / "source-bindings.json").write_text(json.dumps(BINDINGS, indent=2) + "\n")

controls = json.loads((OUT / "property-removals.json").read_text())
for row in controls["rows"]:
    source = (POST / row["source_path"]).read_text()
    mutant = relocate_exact_hunks(source, (OUT / row["patch"]).read_text())
    patch = delta(row["source_path"], source.encode(), mutant.encode())
    (OUT / row["patch"]).write_text(patch)
    row["original_sha256"], row["mutant_sha256"] = sha(source.encode()), sha(mutant.encode())
    row["patch_sha256"] = sha(patch.encode())
(OUT / "property-removals.json").write_text(json.dumps(controls, indent=2) + "\n")
print(json.dumps({"targets": len(BINDINGS["rows"]), "source_patch_sha256": sha(source_patch.encode()),
                  "controls": len(controls["rows"]), "logical_Ruff": "PASS", "runtime": "UNRUN"}))
