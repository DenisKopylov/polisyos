from pathlib import Path
import json,hashlib,difflib,re,subprocess,ast
R=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos');H=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
proposal=json.loads((H/'proposal.json').read_text());files={r['path']:r for r in proposal['files']}
post=lambda path:(H/files[path]['postimage']).read_bytes() if path in files else (R/path).read_bytes()
def apply_patch_text(src,patch):
 lines=patch.splitlines(keepends=True);chunks=[];old=[];new=[];inside=False
 for line in lines:
  if line.startswith('@@'):
   if inside:chunks.append((''.join(old),''.join(new)))
   inside=True;old=[];new=[];continue
  if not inside:continue
  if line.startswith(' '):old.append(line[1:]);new.append(line[1:])
  elif line.startswith('-'):old.append(line[1:])
  elif line.startswith('+'):new.append(line[1:])
  elif line.startswith('\\'):continue
 if inside:chunks.append((''.join(old),''.join(new)))
 for before,after in chunks:
  assert src.count(before)==1,(len(before),src.count(before))
  src=src.replace(before,after,1)
 return src
controls=json.loads((H.parent/'C48-compile-state-view-r2/existing-controls-rebound.json').read_text())
rebound=[]
for case in controls['cases']:
 if case['source'] in files:
  current=post(case['source']).decode();oldpatch=(R/case['patch_source']).read_text()
  mutant=apply_patch_text(current,oldpatch)
  patch=''.join(difflib.unified_diff(current.splitlines(keepends=True),mutant.splitlines(keepends=True),fromfile='a/'+case['source'],tofile='b/'+case['source']))
  dest=H/'controls'/(case['id']+'.patch');dest.write_text(patch)
  case.update(source_sha256=sha(current.encode()),patch_source=str(dest.relative_to(R)),patch_sha256=sha(patch.encode()),mutant_sha256=sha(mutant.encode()),mutant_git_blob=blob(mutant.encode()),disposition='Rebound exact R3 source/test bytes; behavioral removal UNRUN')
  rebound.append(case['id'])
 case['test_sha256']=sha(post(case['test_source']))
controls.update(status='Complete21 existing controls rebound to R3 proposed source/test bytes; UNRUN',rebound_source_ids=rebound)
(H/'existing-controls-rebound.json').write_text(json.dumps(controls,indent=2)+'\n')
# Remove structural validation only, leaving canonical replay/helper/markers intact.
c06='policy-engine/src/polisyos/scientist/nodes/builtins/decide/policy_runtime_method_metrics.py';s=post(c06).decode()
old='''    if graph != replayed or plan.order != order:
        raise _InvalidProjectionError("comparison_canonical_method_graph_or_order_mismatch")
'''
new='''    # Removal probe: keep replay and markers, remove the equality property.
    _ = graph != replayed or plan.order != order
'''
assert s.count(old)==1;m=s.replace(old,new)
d=''.join(difflib.unified_diff(s.splitlines(keepends=True),m.splitlines(keepends=True),fromfile='a/'+c06,tofile='b/'+c06))
(H/'remove-full-graph-reconciliation.patch').write_text(d)
(H/'graph-removal.json').write_text(json.dumps({'source':c06,'source_sha256':sha(s.encode()),'patch_sha256':sha(d.encode()),'mutant_sha256':sha(m.encode()),'mutant_git_blob':blob(m.encode()),'test_source':'policy-engine/tests/unit/scientist/nodes/builtins/decide/test_policy_runtime_method_metrics.py','test_sha256':sha(post('policy-engine/tests/unit/scientist/nodes/builtins/decide/test_policy_runtime_method_metrics.py')),'selector':'tests/unit/scientist/nodes/builtins/decide/test_policy_runtime_method_metrics.py::test_actual_compiler_comparison_reconciles_whole_operator_closure','expected':'At least one auxiliary/edge/order refusal stops raising; test fails while replay/helper/markers remain. Baseline must pass first.','runtime':'UNRUN'},indent=2)+'\n')
# Rebind compile removal test bytes too.
x=json.loads((H/'removal.json').read_text());x['test_sha256']=sha(post('policy-engine/tests/unit/scientist/nodes/builtins/compile/test_compile_foundry_state_views.py'));(H/'removal.json').write_text(json.dumps(x,indent=2)+'\n')
# Future frame: check all prior99 CURRENT values before declaring only proposed deltas.
frame=json.loads((H.parent/'C48-single-sandbox-r3-c71/source-bindings.json').read_text())
rows=frame['selected_paths_and_explicit_conftest_absences']+frame['supplemental_c05_runtime_inputs']+frame['supplemental_c71_inputs'];updates=[]
assert len(rows)==len({row['path'] for row in rows})==99
frame['supplemental_r3_inputs']=[]
for row in rows:
 p=R/row['path'];live=sha(p.read_bytes()) if p.exists() else None
 assert live==row['expected_for_pilot'],(row['path'],live,row['expected_for_pilot'])
 if row['path'] in files:
  row['expected_for_pilot']=files[row['path']]['post_sha256'];updates.append(row['path'])
known={r['path'] for r in rows};newpaths=[]
for path in [*files,'policy-engine/src/polisyos/foundry/compile/_lowering.py','policy-engine/src/polisyos/ir/kernel/constraints.py']:
 if path not in known:
  pre=sha((R/path).read_bytes()) if (R/path).exists() else None
  newrow={'path':path,'baseline':pre,'expected_for_pilot':sha(post(path)),'purpose':'R3 compiler/comparison source, test/mandatory companion or canonical replay input'}
  rows.append(newrow);frame['supplemental_r3_inputs'].append(newrow)
  known.add(path);newpaths.append(path)
frame.update(status='PROPOSED future source frame; not launchable before Root composition/generation/clean source admission',r3_changed_existing_paths=updates,r3_new_paths=newpaths,worktree_head_at_read=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),source_profile_note='Original99 current values verified; future exact generated public outputs are mandatory Root-owned supplemental pins, pending actual generation.')
(H/'source-bindings-proposed.json').write_text(json.dumps(frame,indent=2)+'\n')
# R2→R3 delta is review context, not a replacement canonical patch.
r2=H.parent/'C48-compile-state-view-r2';delta=''
for path in files:
 oldpath=r2/'postimage'/path
 before=oldpath.read_text() if oldpath.exists() else (R/path).read_text() if (R/path).exists() else ''
 after=post(path).decode()
 if before!=after:delta+=''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path))
(H/'r2-batch-delta.patch').write_text(delta)
print(json.dumps({'existing_controls':len(controls['cases']),'rebound_source_ids':rebound,'prior_frame':99,'future_frame':len(rows),'updated_rows':updates,'new_paths':newpaths},indent=2))
