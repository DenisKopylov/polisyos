#!/bin/bash
# Guard a single C50 retained case; a mechanical check is not a semantic verdict.
set -uo pipefail
if [ "$#" -ne 2 ]; then
  printf '%s\n' 'Usage: run_case.sh <absolute-plan> <full-plan-sha256>' >&2
  exit 125
fi
C50_PLAN="$1"
C50_PLAN_SHA="$2"
C50_ROOT="/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos"
C50_D="$C50_ROOT/policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1"
C50_PY="$C50_ROOT/policy-engine/.venv/bin/python"
C50_GUARD="$C50_ROOT/LOCAL/raw/e02-execution-20261027/repairs/C59-r2-native/run_guarded.py"
C50_EXPECTED_GUARD_SHA="e7d26efd7738eaa482388d00663d7749586a64fffd92d9aff52a1aa39bee2621"
C50_GUARD_SHA=$(/usr/bin/shasum -a 256 "$C50_GUARD") || exit 125
if [ "${C50_GUARD_SHA%% *}" != "$C50_EXPECTED_GUARD_SHA" ]; then
  printf '%s\n' 'C59 guard bytes differ; native runner was not launched.' >&2
  exit 125
fi
C50_CLEAN=(/usr/bin/env -u PYTHONPATH -u PYTEST_ADDOPTS -u PYTEST_PLUGINS -u PYTEST_DISABLE_PLUGIN_AUTOLOAD -u PYTHONHOME -u VIRTUAL_ENV PYTHONDONTWRITEBYTECODE=1)
c50_check() {
  "${C50_CLEAN[@]}" C50_PLAN="$C50_PLAN" C50_PLAN_SHA="$C50_PLAN_SHA" C50_CHECK_PHASE="$1" "$C50_PY" -B - "$C50_GUARD" <<'PY'
import importlib.util, os, sys
from pathlib import Path
path=Path(sys.argv[1])
spec=importlib.util.spec_from_file_location('reviewed_c59_guard',path)
module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
plan, errors=module.check(Path(os.environ['C50_PLAN']),os.environ['C50_PLAN_SHA'])
if not errors:
 output=module.RUNNER_DIR / str(plan['case_id'])
 if os.environ['C50_CHECK_PHASE']=='pre' and (output.exists() or output.is_symlink()): errors.append('case output already exists')
 if os.environ['C50_CHECK_PHASE']=='post' and not output.is_dir(): errors.append('case output missing after run')
print({'case':plan.get('case_id'),'errors':errors},flush=True)
if errors: raise SystemExit(125)
PY
}
if ! c50_check pre; then
  printf '%s\n' 'C50 precheck refused; native runner was not launched.' >&2
  exit 125
fi
if "${C50_CLEAN[@]}" "$C50_PY" -B "$C50_D/run_case_with_tools_r2.py" "$C50_PLAN"; then
  C50_RUNNER_STATUS=0
else
  C50_RUNNER_STATUS=$?
fi
if ! c50_check post; then
  printf '%s\n' 'C50 postcheck refused; no result is qualified.' >&2
  exit 125
fi
printf 'C50 guarded mechanical runner exit: %s; manual semantic and backend review required.\n' "$C50_RUNNER_STATUS"
exit "$C50_RUNNER_STATUS"
