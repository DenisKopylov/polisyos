"""Run the reviewed R10 builder once with Root-owned source admission.

No product module is imported by this controller.  Its child is sandboxed and
records the finite parent-process Python source origins it actually imports.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import re
import runpy
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
PRODUCT = ROOT / "policy-engine"
RAW = ROOT / "LOCAL/raw/e02-execution-20261027"
PACKET = RAW / "runtime-prep/N7-candidate-bundle-design-r11"
PRIOR = RAW / "runtime-prep/N7-builder-r117"
PRIOR_HEAD = "e151479e1349639c89daf026a1b8282772194f80"
ROOT_LAYER = (
    PRODUCT
    / "docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/root-layer-lib.py"
)
MONITOR = (
    PRODUCT
    / "docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-postfix-709-q2-helper-actual-20261018/supervise.py"
)
PROFILE_TEMPLATE = RAW / "runtime-prep/N7-builder-r83/child.sb"
AUTHORITY_RECEIPT = (
    RAW / "runtime-prep/N7-candidate-bundle-design-r6/cases/n7-inputs-r83/candidate-inputs.json"
)
REVIEW = RAW / "reviews/N7-actual-source-fixture-r3-independent/review.json"
IDENTITY_REVIEW = RAW / "reviews/child-computation-identity-r3-independent/review.json"
IDENTITY_READBACK = RAW / "composition/child-identity-foundation-r150/commit/branch-readback.json"
IDENTITY_HEAD = "4ccfa564f925d048f3c46dc0069ffcbfe028a13a"
IDENTITY_TREE = "5f44a9eca496ff46472ee426daf457cfdcef9beb"
IDENTITY_PATH = "policy-engine/src/polisyos/scientist/orchestration/engine/component_identity.py"
IDENTITY_PRIOR_SHA = "f4434f5634b7fb56b2b52b0070d94948e18855c1ed362b5f98e8720757679535"
PINS = {
    PACKET / "manifest.json": "b8ffbf3c6e7bd05a83b5f0244b1496ac8ef56e584c656e81a71cb150ac7fc1bc",
    PACKET
    / "prepare_candidate_inputs.py": "d79018bee8d90ea5c69ee36b79ec215d8be6cb63a9836432ec7bb6841a5c3f56",
    PACKET
    / "run-contract-proposal.json": "17175a9f97cf7c5d1949ee87706263b67321b3d507928330c580ad8eb6e67cb6",
    REVIEW: "ad8dde3c624684b196b68cc4e9b40b1eadfe70043df5f6876b283701b7930eb1",
    IDENTITY_REVIEW: "6f03b4130a4f383846df732c783ea3ff1c90afad711a494523f9668a8dc66ff0",
    IDENTITY_READBACK: "55a6220a427ebd22433bf43bd97810199b32bcedb6c59e174821274e7b474106",
    MONITOR: "a94a662308270ba3aca96c1d9c75e53a05e37a923a6188d0f464f8ac1e90909e",
    PROFILE_TEMPLATE: "5ed9b14cf01021c73f9517c8ca4c5d175c9476811bb558feed3776872559794b",
    AUTHORITY_RECEIPT: "886ac528f251087ed66b895893b6552b8280c273042b7c927749b9822654bdd7",
    PRIOR
    / "loaded-source.json": "4180551d6d00dc4dfa04fc87bce0fbd3bf1d61c189c99287ef3f3200bb4b1bbd",
    PRIOR / "Git-readback.json": "22c6b78c97b48cf5203040136fdb223af7c2228c29c043c19b038b006576e5f0",
    ROOT_LAYER: "4b381f40f830180c0aa3d1a3cc6d091bc5e5f4598660a1824894d7a188351d35",
}
ALLOWED_PRIOR_ORIGIN_CHANGES = {
    IDENTITY_PATH: "d5946ebd3e77f033b6a283e04a803a30450ace501c106a0cb02f83a67cbef3a9",
    "policy-engine/src/polisyos/runtime/quality/design_generation.py": "4c645aaca73fbdb00748d98f4f1a832156f5de77d5451bf62e4d26ae85dd1504",
    "policy-engine/tests/unit/runtime/quality/test_generation_source.py": "64c9fc1a4eeca461561aed1004f0a5b7f32965b628b21b0ce5ccc84f68327f60",
}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args: str) -> bytes:
    return subprocess.check_output(["git", *args], cwd=ROOT)


def assert_fresh(path: Path) -> None:
    assert not os.path.lexists(path), f"output_exists:{path}"
    assert path.is_relative_to(ROOT)
    for parent in (path, *path.parents):
        assert not parent.is_symlink(), f"symlink_component:{parent}"



REQUIRED_OWNERS = {
    "tests/_helpers/world_model_record.py",
    "tests/unit/runtime/quality/test_generation_source.py",
    "tests/unit/runtime/quality/test_design_generation.py",
    "tests/unit/runtime/quality/test_intervention_substrate.py",
    "tests/unit/runtime/quality/test_grounding_bind.py",
    "src/polisyos/runtime/quality/cycle_substrate.py",
    "src/polisyos/runtime/quality/intervention_substrate.py",
    "src/polisyos/runtime/quality/substrate_registry.py",
    "src/polisyos/runtime/quality/world_model_record.py",
    "src/polisyos/runtime/quality/design_generation.py",
    "src/polisyos/ir/kernel/slots.py",
}


def validate_readset(rows):
    """Reject malformed or missing observations, independently of mismatch checks."""
    if type(rows) is not dict or not rows:
        raise ValueError("readset_not_nonempty_object")
    for name, sha in rows.items():
        if (type(name) is not str or not name or Path(name).is_absolute()
            or ".." in Path(name).parts or not name.startswith(("src/", "tests/", "tools/"))
            or type(sha) is not str or not re.fullmatch(r"[0-9a-f]{64}", sha)):
            raise ValueError("malformed_readset_entry")
    missing = REQUIRED_OWNERS.difference(rows)
    if missing:
        raise ValueError("missing_required_owner:" + ",".join(sorted(missing)))
    return len(rows)

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--expected-controller-sha256", required=True)
    parser.add_argument("--head", required=True)
    parser.add_argument("--tree", required=True)
    parser.add_argument("--label", required=True)
    parser.add_argument("--case-id", required=True)
    parser.add_argument("--prepare-only", action="store_true")
    args = parser.parse_args()
    assert re.fullmatch(r"[0-9a-f]{64}", args.expected_controller_sha256)
    assert digest(Path(__file__)) == args.expected_controller_sha256, "controller_hash_mismatch"
    assert re.fullmatch(r"[0-9a-f]{40}", args.head) and re.fullmatch(r"[0-9a-f]{40}", args.tree)
    assert re.fullmatch(r"[A-Za-z0-9-]+", args.label) and re.fullmatch(
        r"[A-Za-z0-9-]+", args.case_id
    )
    output = RAW / "runtime-prep" / args.label
    cases = PACKET / "cases"
    case = cases / args.case_id
    assert_fresh(output)
    assert_fresh(case)
    assert shutil.disk_usage(ROOT).free >= 8 * 1024**3
    pressure = subprocess.check_output(["/usr/bin/memory_pressure", "-Q"], text=True)
    match = re.search(r"System-wide memory free percentage:\s*(\d+)%", pressure)
    assert match, "memory_pressure_unavailable"
    total = int(subprocess.check_output(["/usr/sbin/sysctl", "-n", "hw.memsize"], text=True))
    assert total * int(match.group(1)) // 100 >= 6 * 1024**3, "ram_start_floor"
    guard = runpy.run_path(str(ROOT_LAYER))["guard"]
    before = guard()
    live = json.loads((ROOT / "LOCAL/raw/root-live-ownership-20261021.json").read_text())
    assert not live["known_dirty_paths"]
    assert before["head"] == live["head"] == args.head == git("rev-parse", "HEAD").decode().strip()
    assert live["tree"] == args.tree == git("rev-parse", "HEAD^{tree}").decode().strip()
    assert (
        git("symbolic-ref", "--short", "HEAD").decode().strip()
        == "codex/e02-unified-local-20261009"
    )
    assert not git("diff", "--name-only") and not git("diff", "--cached", "--name-only")
    for path, value in PINS.items():
        assert digest(path) == value, path
    assert args.head == IDENTITY_HEAD and args.tree == IDENTITY_TREE, "identity_rebind_source_changed"
    identity_review = json.loads(IDENTITY_REVIEW.read_text())
    identity_readback = json.loads(IDENTITY_READBACK.read_text())
    assert identity_review["verdict"] == "GO_SOURCE_FOUNDATION"
    assert identity_review["manifest_sha256"] == "185e87bb407638239fee53b82c767999acc3dbd9e07064b60cb79c35acfe404c"
    assert identity_readback["head"] == args.head and identity_readback["tree"] == args.tree
    assert identity_readback["parents"] == ["0da0c0e524680a5090dc68dd5551921ca164720b"]
    assert identity_readback["paths"][IDENTITY_PATH] == ALLOWED_PRIOR_ORIGIN_CHANGES[IDENTITY_PATH]
    assert hashlib.sha256(git("show", PRIOR_HEAD + ":" + IDENTITY_PATH)).hexdigest() == IDENTITY_PRIOR_SHA
    review = json.loads(REVIEW.read_text())
    assert review["verdict"] == "GO_BOUNDED_COMPOSITION_REGRESSIONS_AND_DIAGNOSTICS"
    assert (
        review["manifest_sha256"]
        == "10f577104a797065aae5199bfdea8ad5592753aada9388b505ddce6d15b77d4d"
    )
    assert review["r10"]["manifest_matches"] is True
    assert review["r10"]["manifest_sha256"] == "2110e559b1d1d2031b31fa3235cfb8dcdfe1960351d68c50281ee7943363147a"
    successor = json.loads((PACKET / "manifest.json").read_text())
    assert successor["base_builder_sha256"] == "d5fd658fe9f4a69a40038fed68f2d5ebe1fac6cd4674818123899ad1bfbeeb0f"
    assert successor["files_sha256"]["prepare_candidate_inputs.py"] == PINS[PACKET / "prepare_candidate_inputs.py"]
    contract = json.loads((PACKET / "run-contract-proposal.json").read_text())
    inputs = contract["required_post_composition_source_pins"]
    assert len(inputs) == 17
    for rel, expected in inputs.items():
        data = (ROOT / rel).read_bytes()
        assert hashlib.sha256(data).hexdigest() == expected, rel
        assert git("show", args.head + ":" + rel) == data, rel
    prior = json.loads((PRIOR / "loaded-source.json").read_text())
    prior_git = json.loads((PRIOR / "Git-readback.json").read_text())
    assert prior_git["head"] == PRIOR_HEAD and not prior_git["mismatches"]
    assert len(prior) == prior_git["finite_module_count"] == 1619
    assert prior[IDENTITY_PATH.removeprefix("policy-engine/")] == IDENTITY_PRIOR_SHA
    changed = git("diff", "--name-only", PRIOR_HEAD, args.head).decode().splitlines()
    intersect = {
        rel
        for rel in changed
        if rel.startswith("policy-engine/") and rel[len("policy-engine/") :] in prior
    }
    assert intersect == set(ALLOWED_PRIOR_ORIGIN_CHANGES), (
        f"prior_origin_intersection:{sorted(intersect)}"
    )
    for rel, expected in ALLOWED_PRIOR_ORIGIN_CHANGES.items():
        assert (
            digest(ROOT / rel) == expected
            and git("show", args.head + ":" + rel) == (ROOT / rel).read_bytes()
        ), rel
    old = json.loads(AUTHORITY_RECEIPT.read_text())
    authority = Path(old["l6"]["code_authority_bindings_path"])
    authority_sha = digest(authority)
    assert (
        authority_sha
        == old["l6"]["code_authority_sha256_after"]
        == "c8cfdebc407f5bea94b9857a93172567f0e81b10b4eb5a69adcd81ac29fb0baa"
    )
    temp = output / "tmp"
    wrapper = output / "launch_builder.py"
    wrapper_source = (
        'import hashlib,json,pathlib,runpy,sys\n'
        f'P=pathlib.Path({str(PRODUCT)!r})\n'
        'if __name__ == "__main__":\n'
        f' sys.argv=[{str(PACKET / "prepare_candidate_inputs.py")!r},"--repo-root",{str(ROOT)!r},"--case-id",{args.case_id!r}]\n'
        ' entry=pathlib.Path(sys.argv[0]); before=hashlib.sha256(entry.read_bytes()).hexdigest()\n'
        ' try:\n  runpy.run_path(sys.argv[0],run_name="__main__")\n finally:\n  rows={}\n'
        '  for mod in tuple(sys.modules.values()):\n   f=getattr(mod,"__file__",None)\n   if not isinstance(f,str):continue\n'
        '   q=pathlib.Path(f).resolve()\n   if q.suffix==".py" and q.is_relative_to(P) and q.relative_to(P).parts[0] in ("src","tests","tools") and q.is_file():rows[str(q.relative_to(P))]=hashlib.sha256(q.read_bytes()).hexdigest()\n'
        f'  pathlib.Path({str(output / "loaded-source.json")!r}).write_text(json.dumps(rows,indent=2)+"\\n")\n'
        f'  pathlib.Path({str(output / "builder-origin.json")!r}).write_text(json.dumps({{"path":str(entry),"sha256_before":before,"sha256_after":hashlib.sha256(entry.read_bytes()).hexdigest()}})+"\\n")\n'
    )
    compile(wrapper_source, str(wrapper), "exec")
    template = PROFILE_TEMPLATE.read_text()
    for original, replacement in (
        (RAW / "runtime-prep/N7-builder-r83", output),
        (RAW / "runtime-prep/N7-candidate-bundle-design-r6/cases/n7-inputs-r83", case),
        (RAW / "runtime-prep/N7-candidate-bundle-design-r6/cases", cases),
    ):
        assert template.count(str(original)) == 1, str(original)
        template = template.replace(str(original), str(replacement))
    assert "(deny network*)" in template and "policy-engine/production_data" in template
    sandbox = output / "child.sb"
    if args.prepare_only:
        assert guard() == before
        print(
            json.dumps(
                {
                    "classification": "PREPARATION_ONLY",
                    "head": args.head,
                    "tree": args.tree,
                    "source_pins_checked": len(inputs),
                    "prior_origin_intersection": sorted(intersect),
                    "wrapper_sha256": hashlib.sha256(wrapper_source.encode()).hexdigest(),
                    "sandbox_sha256": hashlib.sha256(template.encode()).hexdigest(),
                    "product_imports": "UNRUN",
                    "builder": "UNRUN",
                    "outputs_created": False,
                    "closure_ids": [],
                }
            )
        )
        return 0
    output.mkdir()
    temp.mkdir()
    wrapper.write_text(wrapper_source)
    sandbox.write_text(template)
    original_home = os.environ.get("HOME")
    assert original_home, "home_unavailable"
    env = {
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONPATH": str(PRODUCT / "src") + ":" + str(PRODUCT),
        "TMPDIR": str(temp),
        "XDG_CACHE_HOME": str(temp / "xdg"),
        "NUMBA_CACHE_DIR": str(temp / "numba"),
        "MPLCONFIGDIR": str(temp / "mpl"),
        "HOME": original_home,
        "PATH": "/usr/bin:/bin:/usr/sbin:/sbin:/opt/homebrew/bin",
        "LANG": "C.UTF-8",
        "PYTHONPYCACHEPREFIX": str(temp / "empty-pyc"),
        "SCIENTIST_TORCH_NUM_THREADS": "1",
        "SCIENTIST_TORCH_NUM_INTEROP_THREADS": "1",
    }
    # The supervisor merges os.environ into the child: replace it with an
    # explicit, non-secret baseline rather than selectively stripping keys.
    os.environ.clear()
    os.environ.update(env)
    admitted = {
        "head": args.head,
        "tree": args.tree,
        "branch": live["branch"],
        "source_pins": inputs,
        "source_review_sha256": digest(REVIEW),
        "identity_foundation_review_sha256": digest(IDENTITY_REVIEW),
        "identity_foundation_readback_sha256": digest(IDENTITY_READBACK),
        "builder_sha256": digest(PACKET / "prepare_candidate_inputs.py"),
        "contract_sha256": digest(PACKET / "run-contract-proposal.json"),
        "controller_sha256": digest(Path(__file__)),
        "wrapper_sha256": digest(wrapper),
        "sandbox_sha256": digest(sandbox),
        "prior_origin_intersection": sorted(intersect),
        "prior_origin_scope": "R117 finite parent Python imports only; new imports qualified after this run",
        "authority_sha256": authority_sha,
        "slot_scope": "selected original plus actual declared target slots only; not all default WMR slots",
        "legal_map": "empty",
        "environment": env,
        "environment_scope": "explicit child baseline plus supervisor numeric thread settings; no inherited ambient environment",
        "disk_free_at_admission": shutil.disk_usage(ROOT).free,
        "memory_pressure_free_percent": int(match.group(1)),
        "ram_total_bytes": total,
        "runtime": "RUNNING",
        "closure_ids": [],
    }
    (output / "admission.json").write_text(json.dumps(admitted, indent=2) + "\n")
    spec = importlib.util.spec_from_file_location("n7_r10_monitor", MONITOR)
    assert spec and spec.loader
    monitor = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = monitor
    spec.loader.exec_module(monitor)
    monitor.RSS_CAP_BYTES = 2300 * 1024**2
    monitor.DISK_FLOOR_BYTES = 6 * 1024**3
    monitor.SAMPLE_SECONDS = 1.0
    signal.signal(signal.SIGTERM, monitor.note_stop_signal)
    signal.signal(signal.SIGINT, monitor.note_stop_signal)
    start = time.monotonic()
    result = monitor.run_command(
        output,
        args.label,
        [
            "/usr/bin/sandbox-exec",
            "-f",
            str(sandbox),
            str(PRODUCT / ".venv/bin/python"),
            "-B",
            str(wrapper),
        ],
        PRODUCT,
        start,
        start + 600,
        env,
    )
    (output / "command-result.json").write_text(json.dumps(result, indent=2) + "\n")
    assert guard()["head"] == args.head and digest(authority) == authority_sha
    readset = output / "loaded-source.json"
    if not readset.is_file():
        (output / "classification.json").write_text(
            json.dumps(
                {
                    "classification": "HARNESS_ERROR",
                    "reason": "child did not leave finite parent readset",
                    "closure_ids": [],
                },
                indent=2,
            )
            + "\n"
        )
        return 1
    try:
        rows = json.loads(readset.read_text())
        count = validate_readset(rows)
        origin = json.loads((output / "builder-origin.json").read_text())
        assert origin == {
            "path": str(PACKET / "prepare_candidate_inputs.py"),
            "sha256_before": PINS[PACKET / "prepare_candidate_inputs.py"],
            "sha256_after": PINS[PACKET / "prepare_candidate_inputs.py"],
        }, "entrypoint_witness_mismatch"
    except (OSError, ValueError, TypeError, AssertionError) as exc:
        (output / "classification.json").write_text(json.dumps({
            "classification": "HARNESS_ERROR", "reason": str(exc),
            "closure_ids": [],
        }, indent=2) + "\n")
        return 1
    fmt = git("rev-parse", "--show-object-format").decode().strip()
    assert fmt in ("sha1", "sha256")
    entries = git(
        "ls-tree",
        "-rz",
        "--full-tree",
        args.head,
        "--",
        "policy-engine/src/polisyos",
        "policy-engine/tests",
        "policy-engine/tools",
    )
    tree = {}
    for entry in entries.split(b"\0"):
        if not entry:
            continue
        header, sep, path = entry.partition(b"\t")
        assert sep
        mode, kind, oid = header.decode().split()
        if kind == "blob" and mode in ("100644", "100755"):
            tree[os.fsdecode(path)] = oid
    mismatches = []
    for name, loaded_sha in sorted(rows.items()):
        rel = "policy-engine/" + name
        data = (ROOT / rel).read_bytes()
        oid = hashlib.new(fmt, b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        if hashlib.sha256(data).hexdigest() != loaded_sha or tree.get(rel) != oid:
            mismatches.append(
                {
                    "path": rel,
                    "loaded_sha256": loaded_sha,
                    "current_sha256": hashlib.sha256(data).hexdigest(),
                    "git_blob": tree.get(rel),
                    "computed_blob": oid,
                }
            )
    record = {
        "head": args.head,
        "tree": args.tree,
        "parent_python_only": True,
        "finite_module_count": count,
        "required_owner_count": len(REQUIRED_OWNERS),
        "builder_origin_sha256": digest(output / "builder-origin.json"),
        "coverage_limit": "Python module __file__ in parent process only; native libraries and child process imports not observed",
        "loaded_readset_sha256": digest(readset),
        "mismatches": mismatches,
        "closure_ids": [],
    }
    (output / "Git-readback.json").write_text(json.dumps(record, indent=2) + "\n")
    receipt = case / "candidate-inputs.json"
    data_reconciliation = {"status": "UNRUN"}
    success = bool(
        result["complete"]
        and not result["aborted_reason"]
        and result["return_code"] == 0
        and not mismatches
        and receipt.is_file()
    )
    if success:
        try:
            candidate = json.loads(receipt.read_text())
            assert candidate["status"] == "CANDIDATE_ONLY_NOT_AUTHENTIC_N7_INPUTS"
            env_pins = candidate["required_environment"]
            assert set(env_pins) == {
                "CORR_C_L6_SOURCE_HASH",
                "CORR_C_L6_SOURCE_ROOT",
                "CORR_C_WORLD_CAS",
                "CORR_C_WORLD_HASH",
                "CORR_C_WORLD_REF",
            }
            l6_root = Path(env_pins["CORR_C_L6_SOURCE_ROOT"]).resolve(strict=True)
            assert l6_root.is_relative_to(case.resolve(strict=True))
            assert Path(candidate["l6"]["source_owner_root"]).resolve(strict=True) == l6_root
            members = candidate["l6"]["members"]
            assert isinstance(members, list) and members
            seen = set()
            for member in members:
                rel = Path(member["relative_to_l6_data_root"])
                assert not rel.is_absolute() and ".." not in rel.parts and str(rel) not in seen
                seen.add(str(rel))
                path = (l6_root / rel).resolve(strict=True)
                assert path.is_relative_to(l6_root) and path.is_file()
                assert path.stat().st_size == member["bytes"] and digest(path) == member["sha256"]
            cas = Path(env_pins["CORR_C_WORLD_CAS"]).resolve(strict=True)
            assert cas.is_relative_to(case.resolve(strict=True))
            assert env_pins["CORR_C_WORLD_REF"] == candidate["world_model"]["artifact_ref"]
            assert env_pins["CORR_C_WORLD_HASH"] == candidate["world_model"]["logical_content_hash"]
            artifact = env_pins["CORR_C_WORLD_REF"]
            assert re.fullmatch(r"sha256:[0-9a-f]{64}", artifact)
            hexdigest = artifact.removeprefix("sha256:")
            blob = (
                cas
                / "artifacts"
                / "sha256"
                / hexdigest[:2]
                / hexdigest[2:4]
                / (hexdigest + ".blob")
            )
            assert blob.resolve(strict=True).is_relative_to(cas) and digest(blob) == hexdigest
            data_reconciliation = {
                "status": "PASS",
                "listed_l6_members_verified": len(seen),
                "world_blob_sha256": hexdigest,
                "scope": "physical bytes only; owner semantic claims require consumers",
            }
        except (AssertionError, KeyError, TypeError, ValueError, OSError) as exc:
            data_reconciliation = {
                "status": "FAIL",
                "error_type": type(exc).__name__,
                "detail": str(exc)[:300],
            }
            success = False
    (output / "data-readback.json").write_text(json.dumps(data_reconciliation, indent=2) + "\n")
    classification = {
        "classification": "BUILDER_PASS_BOUNDED" if success else "BUILDER_NOT_QUALIFIED",
        "command_result_sha256": digest(output / "command-result.json"),
        "git_readback_sha256": digest(output / "Git-readback.json"),
        "data_readback_sha256": digest(output / "data-readback.json"),
        "candidate_receipt_sha256": digest(receipt) if receipt.is_file() else None,
        "scope": "synthetic input and candidate-only fixture mechanics; no normal N7, authority, G acceptance or closure",
        "closure_ids": [],
    }
    (output / "classification.json").write_text(json.dumps(classification, indent=2) + "\n")
    print(json.dumps(classification))
    return 0 if success else 1


if __name__ == "__main__":
    raise SystemExit(main())
