from pathlib import Path
import ast,difflib,hashlib,json,subprocess,tomllib
root=Path.cwd(); folder=root/'LOCAL/raw/e02-execution-20261027/repairs/C52-r5'
postdir=folder/'postimages'; prior=root/'LOCAL/raw/e02-execution-20261027/repairs/C52-r4/postimages'
base='caa91a64d7d6afc4310186ba5fadbac2008dddab'
files=sorted(str(f.relative_to(postdir)) for f in postdir.rglob('*') if f.is_file())
def gitread(path):
 r=subprocess.run(['git','show',base+':'+path],capture_output=True)
 return r.stdout if r.returncode==0 else None
def sha(data): return hashlib.sha256(data).hexdigest()
def blob(data):return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
def diff(old,new,path):
 if old==new:return ''
 return ''.join(difflib.unified_diff((old or b'').decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+path if old is not None else '/dev/null',tofile='b/'+path))
patches={'base-to-r5.patch':'','r4-to-r5.patch':''}; entries=[]
for path in files:
 old=gitread(path); new=(postdir/path).read_bytes(); earlier=(prior/path).read_bytes() if (prior/path).is_file() else old
 patches['base-to-r5.patch']+=diff(old,new,path);patches['r4-to-r5.patch']+=diff(earlier,new,path)
 entries.append({'path':path,'base_blob':None if old is None else blob(old),'base_sha256':None if old is None else sha(old),'postimage_blob':blob(new),'postimage_sha256':sha(new),'bytes':len(new)})
for name,contents in patches.items():(folder/name).write_text(contents)
checks=[]
for path in files:
 f=postdir/path
 if f.suffix=='.py':
  ast.parse(f.read_text(),filename=path)
  rel=str(f.relative_to(postdir/'policy-engine'))
  cmd=[str(root/'policy-engine/.venv/bin/python'),'-m','ruff','check','--no-cache','--config',str(root/'policy-engine/ruff.toml'),'--stdin-filename',rel,'-']
  r=subprocess.run(cmd,input=f.read_text(),capture_output=True,text=True,cwd=root/'policy-engine')
  checks.append({'path':path,'check':'AST + Ruff','exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
 if f.suffix=='.toml':
  tomllib.loads(f.read_text());checks.append({'path':path,'check':'TOML parse','exit_code':0})
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip()
intersection=subprocess.check_output(['git','diff','--name-only',base,head,'--',*files],text=True).splitlines()
cmd=['git','apply','--check',str(folder/'base-to-r5.patch')];r=subprocess.run(cmd,capture_output=True,text=True,cwd=root)
checks.append({'check':'git apply --check against observed working tree','exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
checks.append({'check':'base-to-observed-head destination intersection','files':intersection})
(folder/'static-checks.json').write_text(json.dumps({'checks':checks,'runtime':'UNRUN','mutant_execution':'UNRUN'},indent=2)+'\n')
manifest={'schema':'policyos.e02.scratch_repair.v1','slice':'C52-r5','base_commit':base,'base_tree':'730308224f7f1bb0d49b60c3fdb5929d791e6ebd','observed_head':head,'observed_head_tree':tree,'later_head_path_intersection':intersection,'r4_manifest_sha256':'ab4959d0f3d8fa6657c91be18e2cf259036e43df2b49c0a488be825d90f08853','r4_review_sha256':'c86ff6dd4e0714f2a3438e6805cb078929050556bf8f93941e4a754bd8ce57d5','architecture_packet_sha256':'9fbe11b11f246a812435449c33fda6ea9083ecd98d1653cee1220d4081bce64a','postimages':entries,'patches':{n:{'sha256':sha((folder/n).read_bytes()),'bytes':(folder/n).stat().st_size} for n in patches},'support_files':{n:{'sha256':sha((folder/n).read_bytes()),'bytes':(folder/n).stat().st_size} for n in ['README.md','make_mutant.py','static-checks.json']},'runtime':'UNRUN','semantic_removals':'UNRUN','public_generated_inventory':'UNRUN','canonical_source_changed':False,'index_or_ref_changed':False,'code_acceptance':False,'closure_ids':[]}
(folder/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('manifest',sha((folder/'manifest.json').read_bytes()),'files',len(files),'head',head,'intersection',intersection)
print('checks',[(x['check'],x.get('exit_code')) for x in checks])
