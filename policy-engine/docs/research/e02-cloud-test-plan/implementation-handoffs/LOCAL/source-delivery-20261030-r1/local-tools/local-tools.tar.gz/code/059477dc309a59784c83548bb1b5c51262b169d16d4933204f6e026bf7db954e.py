from pathlib import Path
D=Path(__file__).parent/'postimages/policy-engine'
p=D/'src/polisyos/runtime/http/access_audit.py';s=p.read_text()
s=s.replace('from polisyos.core import artifacts, canon\n','''from polisyos.core import artifacts, canon
from polisyos.core.contracts.runtime import (
    CompletedExAnteCandidateSource,
    CompletedExAnteComparisonRequest,
)
''')
s=s.replace('    audit_read_error_count: int\n','''    audit_read_error_count: int
    invalid_authorization_event_count: int = 0
    authorization_decisions: tuple[RuntimeAuthorizationAuditEvent, ...] = ()
''',1)
idx=s.index('\nclass RuntimeAuthorizationAuditEvent(')
s=s[:idx]+'''
class RuntimeAuthorizationRunContext(BaseModel):
    """Exact selected-run/Core-attempt context frozen by the canonical binding owner."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    context_version: Literal["runtime.run.method_metric_context.v1"]
    selection_run_id: str = Field(min_length=1)
    core_run_id: str = Field(min_length=1)
    control_job_id: str | None
    core_manifest_ref: artifacts.ArtifactRef | None
    tenant_id: str = Field(min_length=1)
    cell_id: str = Field(min_length=1)


class RuntimeAuthorizationComparisonBasis(BaseModel):
    """Typed immutable comparison owner basis; lookup keys carry no policy authority."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    job_id: str = Field(min_length=1)
    attempt: int = Field(ge=1)
    state_ref: artifacts.ArtifactRef | None
    request: CompletedExAnteComparisonRequest | None


class RuntimeAuthorizationRelatedRunContext(BaseModel):
    """A content-bound source selection and its separately resolved policy target."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    source: CompletedExAnteCandidateSource
    run_context: RuntimeAuthorizationRunContext
    source_state_ref: artifacts.ArtifactRef
    vector_ref: artifacts.ArtifactRef
    selection_job_id: str = Field(min_length=1)
    selection_attempt: int = Field(ge=1)
    policy_resource_id: str = Field(min_length=1)


class RuntimeAuthorizationComparisonContext(RuntimeAuthorizationRunContext):
    """Complete bounded member set derived from the actual comparison owner basis."""

    comparison_basis: RuntimeAuthorizationComparisonBasis
    related_run_contexts: tuple[RuntimeAuthorizationRelatedRunContext, ...] = Field(
        min_length=2, max_length=20
    )

    @model_validator(mode="after")
    def _reconcile_owner_members(self) -> RuntimeAuthorizationComparisonContext:
        basis = self.comparison_basis
        if basis.request is None or basis.job_id != self.control_job_id:
            raise ValueError("comparison audit lacks its primary owner basis")
        if tuple(row.source for row in self.related_run_contexts) != basis.request.sources:
            raise ValueError("comparison audit member order differs from the owner basis")
        for row in self.related_run_contexts:
            run = row.run_context
            if (
                run.selection_run_id != row.source.source_run_id
                or run.tenant_id != self.tenant_id
                or run.cell_id != self.cell_id
                or row.selection_job_id != run.control_job_id
            ):
                raise ValueError("comparison audit source selection context differs")
        return self


class RuntimeAuthorizationBindingReceipt(BaseModel):
    """Request bytes omitted from the event, retained as their exact owner digest inputs."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    body_sha256: str = Field(pattern=r"^sha256:[0-9a-f]{64}$")
    query_sha256: str = Field(pattern=r"^sha256:[0-9a-f]{64}$")


'''+s[idx:]
s=s.replace('    @model_validator(mode="after")\n    def _validate_target_audit_version', '''    binding_receipt: RuntimeAuthorizationBindingReceipt | None = None
    receipt_sha256: str | None = Field(default=None, pattern=r"^sha256:[0-9a-f]{64}$")

    @model_validator(mode="after")
    def _validate_target_audit_version''',1)
s=s.replace('''            if self.bound_context is not None or self.related_target_decisions:
                raise ValueError("v1 authorization audit cannot carry a target set")
        elif self.bound_context is None:
            raise ValueError("v2 authorization audit requires its exact bound context")
        return self
''','''            if (
                self.bound_context is not None
                or self.related_target_decisions
                or self.binding_receipt is not None
                or self.receipt_sha256 is not None
            ):
                raise ValueError("v1 authorization audit cannot carry a target set")
        else:
            _verify_serialized_authorization_context(self)
        return self
''',1)
s=s.replace('            payload.pop("related_target_decisions", None)\n','''            payload.pop("related_target_decisions", None)
            payload.pop("binding_receipt", None)
            payload.pop("receipt_sha256", None)
''',1)
idx=s.index('\nclass HumanDecisionExposureDeliveryReservation(')
s=s[:idx]+'''
def _authorization_receipt_sha256(payload: Mapping[str, Any]) -> str:
    """Bind the complete serialized request and actual policy results, without a MAC claim."""
    from polisyos.runtime.http.resource_binding import _digest_payload

    return _digest_payload({key: value for key, value in payload.items() if key != "receipt_sha256"})


def _verify_serialized_authorization_context(event: RuntimeAuthorizationAuditEvent) -> None:
    """Cold-verify the whole typed v2 context using the live binding owner's digest law.

    This establishes internal content and request consistency. The local audit
    trail has no authenticated-history owner; rewriting all bytes and recomputing
    this checksum is outside that property and is not asserted impossible.
    """
    from polisyos.runtime.http.resource_binding import (
        _binding_resource_urn,
        _canonical_json,
        _digest_payload,
        _sha256,
        authorization_resource_digest_inputs,
    )

    if event.bound_context is None or event.binding_receipt is None or event.receipt_sha256 is None:
        raise ValueError("v2 authorization audit lacks its content-bound receipt")
    if (
        event.permission != "runs.review"
        or event.resource_kind != "runtime.run.method_metrics.ownership_verified"
        or event.binding_authority != "ownership_verified"
        or event.method != "GET"
        or event.route_path != "/api/v1/runs/{run_id}/method-metric-comparison"
    ):
        raise ValueError("v2 authorization audit differs from its owned comparison action")
    context = RuntimeAuthorizationComparisonContext.model_validate_json(event.bound_context)
    spec = canon.CanonSpec(forbid_floats=False)
    context_bytes = canon.to_canonical_bytes(context.model_dump(mode="json"), spec)
    if context_bytes.decode("utf-8") != event.bound_context or context.tenant_id != event.tenant_id:
        raise ValueError("v2 authorization audit context is not exact canonical scoped content")
    receipt = event.binding_receipt
    if receipt.body_sha256 != _sha256(b""):
        raise ValueError("comparison audit has an unexpected request body")

    def digest(run: RuntimeAuthorizationRunContext, content: bytes, targets: tuple[str, ...]) -> str:
        return _digest_payload(
            authorization_resource_digest_inputs(
                permission=event.permission,
                resource_kind="runtime.run.method_metrics",
                authority=event.binding_authority,
                tenant_id=run.tenant_id,
                body_sha256=receipt.body_sha256,
                query_sha256=receipt.query_sha256,
                selectors=(("run_id", _canonical_json(run.core_run_id)),),
                resolved_context=content,
                policy_target_digests=targets,
            )
        )

    target_digests = tuple(
        digest(row.run_context, canon.to_canonical_bytes(row.run_context.model_dump(mode="json"), spec), ())
        for row in context.related_run_contexts
    )
    expected = tuple(_binding_resource_urn(value) for value in target_digests)
    if len(set(expected)) != len(expected) or expected != tuple(
        row.policy_resource_id for row in context.related_run_contexts
    ):
        raise ValueError("v2 authorization audit target digest differs from its full owner context")
    primary_digest = digest(context, context_bytes, target_digests)
    if event.resource_digest != primary_digest or event.resource_id != _binding_resource_urn(primary_digest):
        raise ValueError("v2 authorization audit primary run binding differs")
    decisions = event.related_target_decisions
    observed = tuple(row.resource_id for row in decisions)
    if len(observed) > len(expected) or observed != expected[:len(observed)]:
        raise ValueError("v2 authorization audit decisions are not the ordered evaluated prefix")
    for index, decision in enumerate(decisions):
        if decision.resource_digest != target_digests[index] or decision.permission != event.permission:
            raise ValueError("v2 authorization audit decision binding or permission differs")
        if decision.outcome is RuntimeAuthorizationOutcome.DENY and index != len(decisions) - 1:
            raise ValueError("v2 authorization audit contains decisions after a denied target")
    if event.outcome is RuntimeAuthorizationOutcome.ALLOW and (
        observed != expected
        or any(row.outcome is not RuntimeAuthorizationOutcome.ALLOW for row in decisions)
        or event.denial_reason
    ):
        raise ValueError("v2 authorization audit ALLOW lacks the complete authorized target set")
    if event.outcome is RuntimeAuthorizationOutcome.DENY and not event.denial_reason:
        raise ValueError("v2 authorization audit DENY lacks its terminal reason")
    payload = event.model_dump(mode="json")
    if event.receipt_sha256 != _authorization_receipt_sha256(payload):
        raise ValueError("v2 authorization audit request/content checksum differs")


'''+s[idx:]
# Build full raw payload, checksum, and call the same canonical parser used cold.
s=s.replace('''    event = RuntimeAuthorizationAuditEvent(
        schema_version=(''','''    event_payload = dict(
        schema_version=(''',1)
needle='''    app_state = getattr(getattr(request, "app", object()), "state", object())
'''
idx=s.index(needle,s.index('def emit_runtime_authorization_audit('))
s=s[:idx]+'''    if targets:
        event_payload["binding_receipt"] = RuntimeAuthorizationBindingReceipt(
            body_sha256=bound_resource.body_sha256,
            query_sha256=bound_resource.query_sha256,
        ).model_dump(mode="json")
        # Convert nested enums/models exactly as the strict event serializer will.
        event_payload["outcome"] = outcome.value
        event_payload["related_target_decisions"] = [
            decision.model_dump(mode="json") for decision in decisions
        ]
        event_payload["receipt_sha256"] = _authorization_receipt_sha256(event_payload)
    event = RuntimeAuthorizationAuditEvent.model_validate(event_payload)
'''+s[idx:]
# scan actual cold stream, retaining raw entries and the invalid count rather than
# converting malformed receipt bytes into complete observational coverage.
s=s.replace('''        nonobject_line_count = 0
        for raw_line in lines:''','''        nonobject_line_count = 0
        invalid_authorization_event_count = 0
        authorization_decisions: list[RuntimeAuthorizationAuditEvent] = []
        for raw_line in lines:''',1)
s=s.replace('''            entries.append(cast("dict[str, object]", parsed))
        return RuntimeAuditScanResult(''','''            entries.append(cast("dict[str, object]", parsed))
            if parsed.get("event_type") == _AUTHORIZATION_EVENT_TYPE:
                try:
                    authorization_decisions.append(RuntimeAuthorizationAuditEvent.model_validate(parsed))
                except (TypeError, ValueError):
                    invalid_authorization_event_count += 1
        return RuntimeAuditScanResult(''',1)
s=s.replace('''            audit_read_error_count=0,
        )

    def _reserve_exposure_delivery''','''            audit_read_error_count=0,
            invalid_authorization_event_count=invalid_authorization_event_count,
            authorization_decisions=tuple(authorization_decisions),
        )

    def _reserve_exposure_delivery''',1)
# Public companion exports.
s=s.replace('    "RuntimeAuthorizationAuditEvent",\n','''    "RuntimeAuthorizationAuditEvent",
    "RuntimeAuthorizationBindingReceipt",
    "RuntimeAuthorizationComparisonBasis",
    "RuntimeAuthorizationComparisonContext",
    "RuntimeAuthorizationRelatedRunContext",
    "RuntimeAuthorizationRunContext",
''')
p.write_text(s)
p=D/'src/polisyos/runtime/http/services/review_effectiveness.py';s=p.read_text();s=s.replace('and invalid_authorization_event_count == 0','and invalid_authorization_event_count == 0\n            and scan.invalid_authorization_event_count == 0',1)
s=s.replace('invalid_authorization_event_count=invalid_authorization_event_count,','''invalid_authorization_event_count=(
                invalid_authorization_event_count + scan.invalid_authorization_event_count
            ),''',1);p.write_text(s)
