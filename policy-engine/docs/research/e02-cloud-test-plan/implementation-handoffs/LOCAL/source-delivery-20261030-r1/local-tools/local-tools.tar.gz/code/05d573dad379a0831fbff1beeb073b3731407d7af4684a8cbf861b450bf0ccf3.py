"""Exercise the complete frozen stdlib-only recorder control set, not product code."""
from __future__ import annotations

import ast
import hashlib
import json
import os
import resource
import runpy
import subprocess
import sys
import time
import traceback
from pathlib import Path

ROOT = Path.cwd()
PREFIX = ROOT / "policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/N7-host-recorder-synthetic-20261030-r1"
SOURCE = PREFIX / "source/policy-engine"
TEST = SOURCE / "tests/unit/runtime/quality/test_loaded_execution_capture.py"
RECORDER = SOURCE / "tools/loaded_execution_capture.py"
FREEZE = PREFIX / "source-freeze.json"
HEAD = "0cf2132d0218864240d4a888ee534948e150b90f"
TREE = "8069d34f78fd28f0d998ab66d4c7e1948c07c982"
GUARDED = (
    "policy-engine/pyproject.toml",
    "policy-engine/tools/cli.py",
    "policy-engine/tools/lib/runner.py",
    "policy-engine/src/polisyos/runtime/quality/confidence_ledger.py",
    "policy-engine/src/polisyos/runtime/quality/promotion_sequence.py",
    "LOCAL/raw/root-live-ownership-20261021.json",
)
NATIVE_CAPTURE = r'''
import atexit, json, os, sys

def _probe_origins():
    native, forbidden, foreign_native = [], [], []
    for name, module in sorted(tuple(sys.modules.items())):
        if name == "polisyos" or name.startswith("polisyos.") or name == "pytest" or name.startswith("pytest."):
            forbidden.append(name)
        spec = getattr(module, "__spec__", None)
        origin = getattr(spec, "origin", None)
        if type(origin) is str and (origin in ("built-in", "frozen") or origin.endswith((".so", ".dylib"))):
            native.append([name, origin])
            if origin not in ("built-in", "frozen") and not os.path.realpath(origin).startswith(os.path.realpath(sys.base_prefix) + os.sep):
                foreign_native.append([name, origin])
    print("PROBE_MODULES=" + json.dumps({"providers": native, "forbidden_product_or_pytest": forbidden, "thirdparty_native": foreign_native}, sort_keys=True))
atexit.register(_probe_origins)
'''


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args: str) -> str:
    return subprocess.run(["git", *args], cwd=ROOT, check=True, capture_output=True, text=True, timeout=10, env={**os.environ, "GIT_OPTIONAL_LOCKS": "0"}).stdout.strip()


def guard() -> dict[str, object]:
    return {
        "branch": git("symbolic-ref", "--short", "HEAD"),
        "head": git("rev-parse", "HEAD"), "tree": git("rev-parse", "HEAD^{tree}"),
        "tracked_status": git("status", "--porcelain", "-uno"),
        "index_diff_sha256": hashlib.sha256(git("diff", "--cached", "--binary").encode()).hexdigest(),
        "guarded_hashes": {name: sha(ROOT / name) for name in GUARDED},
        "frozen_source": {str(path.relative_to(PREFIX)): sha(path) for path in (RECORDER, TEST, SOURCE / "tools/__init__.py")},
        "freeze_sha256": sha(FREEZE),
    }


start = time.monotonic()
freeze = json.loads(FREEZE.read_text())
before = guard()
assert before["head"] == HEAD and before["tree"] == TREE and before["tracked_status"] == ""
assert before["branch"] == "codex/e02-unified-local-20261009"
assert before["frozen_source"] == freeze["frozen_source"]
parsed = ast.parse(TEST.read_bytes(), filename=str(TEST))
cases = tuple(node.name for node in parsed.body if isinstance(node, ast.FunctionDef) and node.name.startswith("test_"))
assert len(cases) == 18 and len(set(cases)) == len(cases)
namespace = runpy.run_path(str(TEST))
case_globals = namespace[cases[0]].__globals__
original = case_globals["_run_fresh"]
case_outputs: dict[str, object] = {}
active = ""


def instrumented(tmp_path: Path, program: str) -> subprocess.CompletedProcess[str]:
    result = original(tmp_path, NATIVE_CAPTURE + "\n" + program)
    case_outputs[active] = {"returncode": result.returncode, "stdout": result.stdout, "stderr": result.stderr}
    markers = [line.removeprefix("PROBE_MODULES=") for line in result.stdout.splitlines() if line.startswith("PROBE_MODULES=")]
    if len(markers) != 1:
        raise AssertionError("stdlib_provider_record_missing")
    providers = json.loads(markers[0])
    if providers["forbidden_product_or_pytest"] or providers["thirdparty_native"]:
        raise AssertionError("forbidden_import_observed")
    case_outputs[active]["providers"] = providers
    return result


case_globals["_run_fresh"] = instrumented
results = {}
for active in cases:
    target = PREFIX / active
    target.mkdir()
    try:
        namespace[active](target)
    except BaseException:
        results[active] = {"status": "FAIL", "traceback": traceback.format_exc()}
    else:
        results[active] = {"status": "PASS"}
after = guard()
units = 1 if sys.platform == "darwin" else 1024
rss_upper = (resource.getrusage(resource.RUSAGE_SELF).ru_maxrss + resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss) * units
receipt = {
    "schema": "policyos.e02.loaded_execution.synthetic_recorder_probe.v2",
    "classification": "SYNTHETIC_PRODUCER_ONLY_NOT_AUTHORITY",
    "denominator": {"test_source": str(TEST.relative_to(PREFIX)), "file_type": "one Python test file", "case_names": cases, "count": len(cases)},
    "tests": results, "case_outputs": case_outputs, "pre": before, "post": after,
    "guard_unchanged": before == after, "peak_rss_upper_bound_bytes": rss_upper,
    "rss_method": "harness plus largest serial child maximum RSS; Darwin reports bytes; outer process tree sampled separately",
    "elapsed_seconds": round(time.monotonic() - start, 3), "authority": False,
    "source_acceptance": False, "n7_n9_verdict": "UNRUN", "closure_ids": [],
}
(PREFIX / "result.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
if before != after or rss_upper > 256 * 1024 * 1024 or any(row["status"] != "PASS" for row in results.values()):
    raise SystemExit(1)
