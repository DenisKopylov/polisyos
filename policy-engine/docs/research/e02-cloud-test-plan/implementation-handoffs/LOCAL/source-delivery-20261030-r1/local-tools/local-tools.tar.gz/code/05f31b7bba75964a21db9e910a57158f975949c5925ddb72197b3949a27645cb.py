"""Read-only, stdlib source and retained-result controls; no product imports."""
from __future__ import annotations

import ast
import copy
import hashlib
import json
import subprocess
from difflib import unified_diff
from pathlib import Path
from types import SimpleNamespace
from xml.etree import ElementTree

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
PKG = ROOT / 'LOCAL/raw/e02-execution-20261027/repairs/N7-generation-source-fixture-r1'
BASE = '662237cec3f0d7f9b01d4ba89f2ad5bdb23a3c80'
REL = 'policy-engine/tests/unit/runtime/quality/test_generation_source.py'
D = ROOT / ('policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/'
            'root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/'
            'deep-task-status-audit-20261027-r1')


def git_bytes(path: str) -> bytes:
    return subprocess.check_output(['git', 'show', f'{BASE}:{path}'], cwd=ROOT)


def top_functions(module):
    return {n.name: n for n in module.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}


def digest(node):
    return hashlib.sha256(ast.dump(node, include_attributes=False).encode()).hexdigest()


old = git_bytes(REL)
new = (PKG / 'postimages' / REL).read_bytes()
old_ast = ast.parse(old, filename=REL)
new_ast = ast.parse(new, filename=REL)
old_functions, new_functions = top_functions(old_ast), top_functions(new_ast)
modified = {'actual_n4_source', 'test_synthetic_cg2_contract_mechanism_remains_non_promotable'}
for name, node in old_functions.items():
    if name not in modified:
        assert digest(node) == digest(new_functions[name]), name
old_asserts = {digest(item.test) for item in ast.walk(old_functions['test_synthetic_cg2_contract_mechanism_remains_non_promotable']) if isinstance(item, ast.Assert)}
new_asserts = {digest(item.test) for item in ast.walk(new_functions['test_synthetic_cg2_contract_mechanism_remains_non_promotable']) if isinstance(item, ast.Assert)}
assert old_asserts <= new_asserts
fixture_users = []
for node in old_ast.body:
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith('test_'):
        args = (*node.args.posonlyargs, *node.args.args, *node.args.kwonlyargs)
        if any(arg.arg == 'actual_n4_source' for arg in args):
            fixture_users.append(node.name)
assert len(fixture_users) == 11, fixture_users
xml = ElementTree.parse(D / 'n7cc1/pytest.xml')
all_cases = xml.findall('.//testcase')
errors = [case for case in all_cases if case.find('error') is not None]
assert len(all_cases) == 84 and len(errors) == 11
assert {case.attrib['name'] for case in errors} == set(fixture_users)
assert all('root.lock' in case.find('error').attrib['message'] and 'PermissionError' in case.find('error').attrib['message'] for case in errors)
failures = [case.attrib['name'] for case in all_cases if case.find('failure') is not None]
assert len(failures) == 2 and 'test_synthetic_cg2_contract_mechanism_remains_non_promotable' in failures
patch = ''.join(unified_diff(old.decode().splitlines(keepends=True), new.decode().splitlines(keepends=True), fromfile='a/'+REL, tofile='b/'+REL))
assert (PKG / 'proposal.patch').read_text() == patch

# Execute only the real source predicate's one return expression with synthetic
# objects. The truncated pytest repr supplies too few fields for a conclusion.
promotion_rel = 'policy-engine/src/polisyos/runtime/quality/promotion_sequence.py'
promotion = ast.parse(git_bytes(promotion_rel))
fn = copy.deepcopy(top_functions(promotion)['_cg2_resolution_is_contract_lane_bind'])
assert len(fn.body) == 1 and isinstance(fn.body[0], ast.Return)
fn.decorator_list = []
fn.returns = None
for arg in (*fn.args.posonlyargs, *fn.args.args, *fn.args.kwonlyargs):
    arg.annotation = None
allowed = (ast.FunctionDef, ast.arguments, ast.arg, ast.Return, ast.BoolOp, ast.And, ast.Or, ast.Compare, ast.Attribute, ast.Load, ast.Name, ast.Constant, ast.Set, ast.UnaryOp, ast.Not, ast.Eq, ast.IsNot, ast.In)
assert all(isinstance(node, allowed) for node in ast.walk(fn))
module = ast.fix_missing_locations(ast.Module(body=[fn], type_ignores=[]))
namespace = {}
exec(compile(module, '<extracted-cg2-mechanical-predicate>', 'exec'), namespace)
predicate = namespace[fn.name]
base = {
    'decision': 'bind', 'authority_scope': 'contract_testing',
    'store_authority_scope': 'contract_testing', 'reason': 'synthetic_input_cannot_grant_authority',
    'content_hash_valid': True, 'reference_epoch_match': True, 'promotable': False,
    'certificate_promotable_claim': False, 'owned_anchor_id': 'owner',
    'certificate_anchor_content_hash': 'sha256:' + 'a'*64,
    'store_anchor_content_hash': 'sha256:' + 'a'*64,
}
assert predicate(SimpleNamespace(**base)) is True
for field, value in (
    ('decision', 'abstain'), ('authority_scope', 'production'),
    ('store_authority_scope', 'production'), ('content_hash_valid', False),
    ('reference_epoch_match', False), ('promotable', True),
    ('certificate_promotable_claim', True), ('owned_anchor_id', None),
    ('certificate_anchor_content_hash', None), ('store_anchor_content_hash', 'sha256:'+'f'*64),
):
    changed = dict(base); changed[field] = value
    assert predicate(SimpleNamespace(**changed)) is False, field
# Both assignments match the facts visible in the actual truncated repr.
assert predicate(SimpleNamespace(**base)) is True
assert predicate(SimpleNamespace(**{**base, 'decision': 'abstain'})) is False

checks = {
    'n7cc1_denominator': {'junit_testcases': len(all_cases), 'setup_errors': len(errors), 'failed': failures, 'all_11_exact_fixture_root_lock_errors': True},
    'actual_n4_source_fixture_users': fixture_users,
    'unchanged_original_top_level_functions': len(old_functions) - len(modified),
    'original_synthetic_cg2_assertions_retained': len(old_asserts),
    'extracted_cg2_predicate_positive_and_10_one_field_refusals': 'PASS',
    'truncated_actual_repr_identifies_false_conjunct': 'NOT_ESTABLISHED',
    'source_controls_boundary': 'extracted predicate only uses synthetic stdlib objects; no product imports, real owner, pytest, or native execution',
    'proposed_runtime': 'UNRUN',
}
result = subprocess.run(['git', 'apply', '--check', str(PKG / 'proposal.patch')], cwd=ROOT, capture_output=True)
assert result.returncode == 0
assert result.stdout == (PKG / 'apply-check.stdout.txt').read_bytes()
assert result.stderr == (PKG / 'apply-check.stderr.txt').read_bytes()
for mode in ('check', 'format'):
    args = [str(ROOT / 'policy-engine/.venv/bin/python'), '-B', '-m', 'ruff', mode]
    if mode == 'format': args.append('--check')
    args += ['--stdin-filename', REL.removeprefix('policy-engine/'), '-']
    result = subprocess.run(args, cwd=ROOT/'policy-engine', input=new, capture_output=True)
    assert result.returncode == 0
    assert result.stdout == (PKG / f'ruff-{mode}.stdout.txt').read_bytes()
    assert result.stderr == (PKG / f'ruff-{mode}.stderr.txt').read_bytes()
checks['git_apply_check'] = 'PASS'
checks['canonical_stdin_ruff_check_and_format'] = 'PASS'
print(json.dumps(checks, sort_keys=True, indent=2))
