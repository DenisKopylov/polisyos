"""R166 CALL-only basis-mapping removal with behavioral and restoration evidence."""
from __future__ import annotations

import ast
import hashlib
import importlib.util
import json
import marshal
import os
from pathlib import Path
import sys
import threading
import types

import pytest

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
OWNER_PATH = ROOT / "policy-engine/src/polisyos/runtime/quality/generation_cycle.py"
OWNER_MODULE = "polisyos.runtime.quality.generation_cycle"
RECURSIVE_MODULE = "polisyos.runtime.quality.recursive_generation_cycle"
CLASS = "GenerationCycleController"
METHOD = "_plan_n7_requirement_gap_if_requested"
NODE = (
    "tests/integration/core_runtime/test_acquisition_cov_seed_served.py::"
    "test_served_cov_seed_reaches_persisted_refusal_without_cost_or_authority"
)
TEST_PATH = ROOT / "policy-engine/tests/integration/core_runtime/test_acquisition_cov_seed_served.py"
EXPECTED = "requirement_basis_not_established"
MUTATED = "unbound_requirement_input_refused"
PINS = {
    "policy-engine/src/polisyos/runtime/quality/generation_cycle.py": "62a5b6e94c7cee7ffee95516d0580a1d642d2ca1ff4e297aa64b53b7550068e8",
    "policy-engine/src/polisyos/runtime/quality/recursive_generation_cycle.py": "33c4fbcaf9afe49c1f4dce5ec82271a46a7dbebd5d54e5c9fa0ea168416cc253",
    "policy-engine/src/polisyos/runtime/quality/acquisition_planner.py": "c22a4aa7bc9517752ae96e3deb799285accd7885b0167513343613ce29473624",
    "policy-engine/src/polisyos/data_requirement/compiler.py": "01664bd6b6f4863bdead5b420ecbf685fa06985c4fef9e4557a270f1aacfc509",
    "policy-engine/src/polisyos/data_requirement/_impl/models.py": "af3dcf8122d93badd0974feb439bf25d3295bb507721cdb2ef4fbd26e614596a",
    "policy-engine/tests/integration/core_runtime/test_acquisition_cov_seed_served.py": "5ce2ae722debd2424e8bd79e03dd8150f9b6950a8178778c3623dd77e724b0c3",
    "policy-engine/tests/_helpers/acquisition_served_history.py": "f17a6150f6c9648293fcd0fa38d8de3093fc073be73c2fa57288676b0e215c6e",
    "policy-engine/tests/_helpers/candidate_cycle_source_profile.py": "e34852d276e51a226b1403c1e1f9aff922dfff34b4d6811df09e7f1ebccba704",
    "policy-engine/tests/unit/runtime/http/_published_catalog_fixture.py": "9a861ea7df80a64b1828058620110b506361e106fe6715b3e070fabb04af00c4",
    "policy-engine/tests/_helpers/control_worker.py": "75e89435f4dbdd23b217433b2ebee2a5f0b8bfb742bd3a0b5d9f7ffb1c30e0a3",
    "policy-engine/src/polisyos/runtime/http/services/control_worker.py": "f7d2990379ddbe57ef227287729aa2faefbd2dfab3961036433a401c18c9f852",
}

_stream = None
_lock = threading.RLock()
_owner = None
_class = None
_function = None
_original = None
_mutant = None
_globals = None
_defaults = None
_kwdefaults = None
_kwdefaults_values = None
_closure = None
_prev_sys_profile = None
_prev_thread_profile = None
_base_environment = None
_assertion_line = None
_errors: list[str] = []
_active: set[tuple[int, int]] = set()
_witnesses: list[dict[str, object]] = []
_reports: dict[str, dict[str, object]] = {}
_seen = False
_restored = False


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _code_hash(code: types.CodeType) -> str:
    return _sha(marshal.dumps(code))


def _trace(event: str, **fields: object) -> None:
    if _stream is None:
        return
    with _lock:
        _stream.write(json.dumps({"event": event, "pid": os.getpid(), **fields}, sort_keys=True) + "\n")
        _stream.flush()
        os.fsync(_stream.fileno())


def _require(condition: bool, message: str) -> None:
    if condition:
        return
    _errors.append(message)
    _trace("instrument_error", reason=message)
    raise RuntimeError("R166 basis removal instrumentation error: " + message)


def _pins() -> bool:
    for name, expected in PINS.items():
        _require(_sha((ROOT / name).read_bytes()) == expected, "source pin " + name)
    _require(
        _sha(Path(__file__).read_bytes()) == os.environ["E02_BASIS_REMOVAL_PLUGIN_SHA256"],
        "plugin pin",
    )
    _require(
        _sha((Path(__file__).parent / "mutation_core.py").read_bytes())
        == os.environ["E02_BASIS_REMOVAL_CORE_SHA256"],
        "mutation core pin",
    )
    _require(
        _sha((Path(__file__).parent / "pytest_launcher.py").read_bytes())
        == os.environ["E02_BASIS_REMOVAL_LAUNCHER_SHA256"],
        "launcher pin",
    )
    return True


def _find_assertion_line() -> int:
    tree = ast.parse(TEST_PATH.read_bytes(), filename=str(TEST_PATH))
    target = ast.dump(
        ast.parse('loaded.basis_limitation_code == "requirement_basis_not_established"', mode="eval").body,
        include_attributes=False,
    )
    nodes = [
        node
        for node in ast.walk(tree)
        if isinstance(node, ast.Assert) and ast.dump(node.test, include_attributes=False) == target
    ]
    _require(len(nodes) == 1 and nodes[0].lineno == 234, "exact original COV assertion")
    return nodes[0].lineno


def _state(expected_code: types.CodeType, item=None) -> dict[str, object]:
    _require(_owner is sys.modules.get(OWNER_MODULE), "current owner module identity")
    _require(getattr(_owner, CLASS) is _class, "owner class identity")
    _require(_class.__dict__.get(METHOD) is _function, "class function identity")
    _require(_function.__code__ is expected_code, "effective code identity")
    _require(_function.__globals__ is _globals is vars(_owner), "function globals identity")
    _require(_function.__defaults__ is _defaults, "defaults identity")
    _require(_function.__kwdefaults__ is _kwdefaults, "keyword defaults identity")
    _require(_function.__kwdefaults__ == _kwdefaults_values, "keyword defaults values")
    _require(_function.__closure__ is _closure, "closure identity")
    if item is not None:
        _require(item.module.cycle_owner is _owner, "test module owner alias")
    return {
        "function_id": id(_function),
        "class_id": id(_class),
        "globals_id": id(_globals),
        "code_sha256": _code_hash(expected_code),
        "same_function_class_globals_defaults_closure": True,
    }


def _prepare(item) -> dict[str, object]:
    global _owner, _class, _function, _original, _mutant, _globals
    global _defaults, _kwdefaults, _kwdefaults_values, _closure
    _pins()
    owner = sys.modules.get(OWNER_MODULE)
    _require(owner is not None, "test-loaded owner module required")
    _require(Path(owner.__file__).resolve() == OWNER_PATH, "loaded owner path")
    cls = getattr(owner, CLASS)
    function = cls.__dict__.get(METHOD)
    _require(isinstance(function, types.FunctionType), "original class function required")
    _require(function.__code__.co_filename == str(OWNER_PATH), "code origin")
    path = Path(__file__).parent / "mutation_core.py"
    spec = importlib.util.spec_from_file_location("e02_r166_basis_mutation_core", path)
    _require(spec is not None and spec.loader is not None, "mutation core loader")
    core = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(core)
    original, mutant, details = core.make_codes(OWNER_PATH.read_bytes(), str(OWNER_PATH))
    _require(function.__code__ == original, "live code equals full pinned module compile")
    _owner, _class, _function = owner, cls, function
    _original, _mutant = function.__code__, mutant
    _globals = function.__globals__
    _defaults, _kwdefaults, _closure = function.__defaults__, function.__kwdefaults__, function.__closure__
    _kwdefaults_values = None if _kwdefaults is None else dict(_kwdefaults)
    _trace("compiled_mutation", details=details, original_sha256=_code_hash(_original), mutant_sha256=_code_hash(_mutant))
    return _state(_original, item)


def _observe(frame, event: str, result) -> None:
    """Observe only execution of the installed target code in this process."""
    if frame.f_code is not _mutant or event not in {"call", "return"}:
        return
    try:
        thread_id = threading.get_ident()
        key = (thread_id, id(frame))
        if event == "call":
            with _lock:
                _active.add(key)
            recursive = sys.modules.get(RECURSIVE_MODULE)
            instance = frame.f_locals.get("self")
            binding_ok = (
                frame.f_globals is _globals
                and getattr(type(instance), METHOD, None) is _function
                and recursive is not None
                and getattr(recursive, CLASS, None) is _class
            )
            if not binding_ok:
                _errors.append("actual execution did not use the admitted class/global aliases")
            _trace("target_call", thread_id=thread_id, frame_id=id(frame), thread_name=threading.current_thread().name, binding_ok=binding_ok)
            return
        with _lock:
            if key not in _active:
                _errors.append("target return lacked its observed call")
            _active.discard(key)
        values = frame.f_locals
        report = values.get("report")
        basis = values.get("basis")
        binding = values.get("basis_binding")
        resolution = getattr(binding, "resolution", None)
        gaps = values.get("gaps")
        record = {
            "thread_id": thread_id,
            "frame_id": id(frame),
            "thread_name": threading.current_thread().name,
            "basis_state": getattr(resolution, "state", None),
            "basis_grade": getattr(resolution, "basis_grade", None),
            "routing_limitation_code": getattr(basis, "routing_limitation_code", None),
            "provided_gap_count": len(gaps) if isinstance(gaps, tuple) else None,
            "report_status": getattr(report, "status", None),
            "report_limitation": getattr(report, "basis_limitation_code", None),
            "cost_estimation_status": getattr(report, "cost_estimation_status", None),
            "record_count": len(getattr(report, "acquisition_records", ())),
            "bound_report": bool(getattr(report, "planning_binding_hash", None)),
            "returned_same_report": getattr(result, "report", None) is report,
            "returned_report_ref_kind": getattr(getattr(result, "report_ref", None), "kind", None),
            "cost_basis_absent": getattr(result, "cost_basis", object()) is None,
        }
        with _lock:
            _witnesses.append(record)
        _trace("target_return", **record)
    except Exception as exc:
        # Do not change the product decision because observation failed.
        _errors.append("profile observation failed: " + type(exc).__name__ + ": " + str(exc))
        try:
            _trace("instrument_error", reason=_errors[-1])
        except Exception:
            pass


def pytest_collection_modifyitems(session, config, items) -> None:
    global _stream, _base_environment, _assertion_line
    _require(len(items) == 1 and items[0].nodeid == NODE, "exact single COV selector")
    _require(sys.flags.optimize == 0, "unoptimized interpreter")
    _pins()
    _assertion_line = _find_assertion_line()
    _base_environment = dict(os.environ)
    trace = Path(os.environ["E02_BASIS_REMOVAL_TRACE"])
    temp = Path(os.environ["TMPDIR"])
    _require(trace.is_absolute() and temp.is_absolute(), "absolute trace and TMPDIR")
    _require(".." not in trace.parts and ".." not in temp.parts, "no parent traversal")
    _require(trace.is_relative_to(ROOT) and temp.is_relative_to(ROOT), "workspace-owned trace and TMPDIR")
    _require(temp.is_dir() and trace.parent == temp.parent, "fresh case geometry")
    _require(trace.name == "basis-removal-trace.jsonl", "expected trace name")
    _require(not any(path.is_symlink() for path in (trace, temp, *trace.parents)), "trace symlink")
    fd = os.open(trace, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    _stream = os.fdopen(fd, "w", encoding="utf-8")
    _trace(
        "admission",
        nodeid=NODE,
        expected_assertion_line=_assertion_line,
        source_pins=PINS,
        plugin_sha256=os.environ["E02_BASIS_REMOVAL_PLUGIN_SHA256"],
        core_sha256=os.environ["E02_BASIS_REMOVAL_CORE_SHA256"],
        thread_scope="current test thread and threads created after CALL hook; existing threads and other processes unobserved",
        initial_thread_ids=sorted(thread.ident for thread in threading.enumerate() if thread.ident is not None),
        environment_sha256=_sha(json.dumps(_base_environment, sort_keys=True).encode()),
    )


@pytest.hookimpl(hookwrapper=True, tryfirst=True)
def pytest_runtest_call(item):
    global _seen, _prev_sys_profile, _prev_thread_profile, _restored
    _require(item.nodeid == NODE and not _seen, "one exact CALL")
    before = _prepare(item)
    _seen = True
    _prev_sys_profile = sys.getprofile()
    _prev_thread_profile = threading.getprofile()
    _require(_prev_sys_profile is None and _prev_thread_profile is None, "existing profile hook")
    _trace("enter", original=before, mutant_code_sha256=_code_hash(_mutant))
    try:
        _function.__code__ = _mutant
        _trace("mutate", effective=_state(_mutant, item))
        threading.setprofile(_observe)
        sys.setprofile(_observe)
        yield
    finally:
        current_sys, current_thread = sys.getprofile(), threading.getprofile()
        sys.setprofile(_prev_sys_profile)
        threading.setprofile(_prev_thread_profile)
        if current_sys is not _observe or current_thread is not _observe:
            _errors.append("profile hook replaced during CALL")
        if _active:
            _errors.append("target frame remained active at restoration")
        _function.__code__ = _original
        restored = _state(_original, item)
        _restored = True
        _trace(
            "restore",
            restored=restored,
            source_pins_match=_pins(),
            exact_original_code_identity=True,
            sys_profile_restored=sys.getprofile() is _prev_sys_profile,
            thread_profile_restored=threading.getprofile() is _prev_thread_profile,
            active_target_frames=len(_active),
        )


def pytest_runtest_logreport(report) -> None:
    if report.nodeid != NODE:
        return
    row: dict[str, object] = {"outcome": report.outcome}
    if report.when == "call" and report.failed:
        crash = getattr(report.longrepr, "reprcrash", None)
        text = str(report.longrepr)
        row.update(
            {
                "failure_path": str(getattr(crash, "path", "")),
                "failure_line": getattr(crash, "lineno", None),
                "contains_original_assertion": "loaded.basis_limitation_code" in text,
                "contains_observed_code": MUTATED in text,
                "contains_expected_code": EXPECTED in text,
                "is_assertion_error": "AssertionError" in text,
            }
        )
    _reports[report.when] = row
    _trace("phase_report", phase=report.when, **row)


def pytest_sessionfinish(session, exitstatus) -> None:
    if _stream is None:
        return
    after_env = dict(os.environ)
    changed_env = sorted(
        key for key in set(_base_environment or {}) | set(after_env)
        if (_base_environment or {}).get(key) != after_env.get(key)
    )
    witness = any(
        row["basis_state"] == "not_established"
        and row["basis_grade"] == "not_established"
        and row["provided_gap_count"] == 0
        and row["report_status"] == "blocked"
        and row["report_limitation"] == MUTATED
        and row["cost_estimation_status"] == "not_estimated"
        and row["record_count"] == 0
        and row["bound_report"] is True
        and row["returned_same_report"] is True
        and row["returned_report_ref_kind"] == "runtime.acquisition_planner_report"
        and row["cost_basis_absent"] is True
        for row in _witnesses
    )
    call = _reports.get("call", {})
    failure_path = call.get("failure_path")
    semantic_failure = (
        call.get("outcome") == "failed"
        and isinstance(failure_path, str)
        and Path(failure_path).resolve() == TEST_PATH
        and call.get("failure_line") == _assertion_line
        and call.get("contains_original_assertion") is True
        and call.get("contains_observed_code") is True
        and call.get("contains_expected_code") is True
        and call.get("is_assertion_error") is True
    )
    qualified = (
        _seen
        and _restored
        and not _errors
        and not changed_env
        and _reports.get("setup", {}).get("outcome") == "passed"
        and _reports.get("teardown", {}).get("outcome") == "passed"
        and int(exitstatus) == 1
        and witness
        and semantic_failure
    )
    if not qualified:
        session.exitstatus = pytest.ExitCode.INTERNAL_ERROR
    _trace(
        "session_finish",
        original_exitstatus=int(exitstatus),
        final_exitstatus=int(session.exitstatus),
        classification="EXPECTED_SEMANTIC_REMOVAL" if qualified else "INSTRUMENT_OR_ORACLE_ERROR",
        witness=witness,
        semantic_failure=semantic_failure,
        reports=_reports,
        instrumentation_errors=_errors,
        changed_environment_keys=changed_env,
        environment_restored=not changed_env,
        environment_sha256=_sha(json.dumps(after_env, sort_keys=True).encode()),
    )


def pytest_unconfigure(config) -> None:
    global _stream
    try:
        if _function is not None and _original is not None:
            if _function.__code__ is not _original:
                _errors.append("code changed after CALL restoration")
                _function.__code__ = _original
            _trace(
                "final_restoration",
                restored=_state(_original),
                sys_profile_restored=sys.getprofile() is _prev_sys_profile,
                thread_profile_restored=threading.getprofile() is _prev_thread_profile,
                source_pins_match=_pins(),
                instrumentation_errors=_errors,
            )
    finally:
        if _stream is not None:
            _stream.close()
            _stream = None
