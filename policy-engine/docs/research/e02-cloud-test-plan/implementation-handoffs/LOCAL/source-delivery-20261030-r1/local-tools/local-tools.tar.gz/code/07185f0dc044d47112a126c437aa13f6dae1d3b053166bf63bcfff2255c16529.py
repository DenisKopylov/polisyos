"""Build/read back C05 r8 source artifacts without product/index/ref writes."""
from __future__ import annotations

import ast
import difflib
import hashlib
import json
import os
import re
import stat
import subprocess
from collections import Counter
from pathlib import Path

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
OUT = ROOT / 'LOCAL/raw/e02-execution-20261027/repairs/C05-composed-fixture-r8'
BASE = '7382a1c4eb32ee3370dc8f370133449cb95dd0db'
BASE_TREE = 'b3840419a81bad0f96c933ff1cf920b76efb6d96'


def git(*args: str) -> bytes:
    return subprocess.check_output(['git', *args], cwd=ROOT)


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def obj(kind: str, raw: bytes) -> str:
    return hashlib.sha1(kind.encode() + b' ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def inventory(ref: str) -> dict[str, tuple[str, str]]:
    result = {}
    for row in git('ls-tree', '-r', '-z', ref).split(b'\0'):
        if row:
            info, path = row.split(b'\t', 1)
            mode, _kind, oid = info.split(b' ')
            result[os.fsdecode(path)] = mode.decode(), oid.decode()
    return result


def tree_hash(files: dict[str, tuple[str, str]]) -> str:
    root: dict = {}
    for path, entry in files.items():
        node = root
        parts = os.fsencode(path).split(b'/')
        for part in parts[:-1]:
            node = node.setdefault(part, {})
        node[parts[-1]] = entry

    def visit(node: dict) -> str:
        entries = []
        for name, value in node.items():
            if isinstance(value, dict):
                mode, oid = '40000', visit(value)
                order = name + b'/'
            else:
                mode, oid = value
                order = name
            entries.append((order, mode.encode() + b' ' + name + b'\0' + bytes.fromhex(oid)))
        return obj('tree', b''.join(value for _key, value in sorted(entries)))
    return visit(root)


def role(path: str) -> str:
    if '/tests/' in path:
        return 'mandatory semantic test companion'
    if path.endswith('/README.md'):
        return 'mandatory documentation companion'
    if '/release-fragments/' in path:
        return 'mandatory release companion'
    if path.endswith('/core/llm/__init__.py'):
        return 'mandatory facade companion'
    return 'mechanism'


def artifact(path: Path) -> dict:
    raw = path.read_bytes()
    return {'path': str(path.relative_to(ROOT)), 'sha256': sha(raw), 'bytes': len(raw)}


assert git('rev-parse', BASE + '^{tree}').decode().strip() == BASE_TREE
base_entries = inventory(BASE)
assert tree_hash(base_entries) == BASE_TREE
observed_head = git('rev-parse', 'HEAD').decode().strip()
head_entries = inventory(observed_head)
files = []
preimages = {}
postimages = {}
patch_parts = []
subset = {}
current = []
for path in sorted((OUT / 'policy-engine').rglob('*')):
    if not path.is_file():
        continue
    relative = str(path.relative_to(OUT))
    for ancestor in [path, *list(path.parents)[:len(path.relative_to(OUT).parts)]]:
        assert not ancestor.is_symlink(), ancestor
    info = path.stat()
    assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1, path
    raw = path.read_bytes()
    mode, oid = base_entries.get(relative, (None, None))
    old = git('show', BASE + ':' + relative) if oid is not None else b''
    assert old != raw, ('unchanged source postimage', relative)
    assert (not old or old.endswith(b'\n')) and raw.endswith(b'\n'), relative
    assert oid is None or obj('blob', old) == oid
    canonical = ROOT / relative
    working = canonical.read_bytes() if canonical.is_file() else None
    if canonical.exists():
        assert (canonical.stat().st_dev, canonical.stat().st_ino) != (info.st_dev, info.st_ino)
    previous = ROOT / 'LOCAL/raw/e02-execution-20261027/repairs/C05-composed-fixture-r7' / relative
    if previous.is_file():
        assert (previous.stat().st_dev, previous.stat().st_ino) != (info.st_dev, info.st_ino)
    post_oid = obj('blob', raw)
    preimages[relative] = old
    postimages[relative] = raw
    subset[relative] = ('100644', post_oid)
    current.append({
        'path': relative, 'base_blob': oid, 'head_blob': head_entries.get(relative, (None, None))[1],
        'working_sha256': sha(working) if working is not None else None,
        'matches_base_preimage': working == old if oid is not None else working is None,
        'working_source_kind': 'regular' if canonical.is_file() and not canonical.is_symlink() else 'absent_or_other',
    })
    files.append({
        'path': relative, 'role': role(relative),
        'preimage_mode': mode, 'preimage_blob': oid,
        'preimage_sha256': sha(old) if oid is not None else None,
        'preimage_bytes': len(old) if oid is not None else 0,
        'postimage_mode': '100644', 'postimage_blob': post_oid,
        'postimage_sha256': sha(raw), 'postimage_bytes': len(raw),
        'current_working_preimage_match': current[-1]['matches_base_preimage'],
        'independent_regular_file': True,
    })
    header = f'diff --git a/{relative} b/{relative}\n'
    if oid is None:
        header += 'new file mode 100644\n'
    header += f'index {oid or "0" * 40}..{post_oid}' + (' 100644\n' if oid else '\n')
    diff = ''.join(difflib.unified_diff(
        old.decode().splitlines(keepends=True), raw.decode().splitlines(keepends=True),
        fromfile='a/' + relative if oid else '/dev/null', tofile='b/' + relative, n=3,
    ))
    patch_parts.append(header + diff)
patch = ''.join(patch_parts).encode()
(OUT / 'repair.patch').write_bytes(patch)

# Independently replay the exact serialized unified hunks in memory.
reconstructed = {}
sections = re.split(r'(?m)^diff --git ', patch.decode())[1:]
for section in sections:
    rows = section.splitlines(keepends=True)
    match = re.fullmatch(r'a/(.+) b/(.+)\n', rows[0])
    assert match and match[1] == match[2]
    path = match[1]
    original = preimages[path].decode().splitlines(keepends=True)
    cursor = 0
    output = []
    index = 1
    while index < len(rows):
        if not rows[index].startswith('@@ '):
            index += 1
            continue
        header = re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', rows[index])
        assert header
        old_start, old_count = int(header[1]), int(header[2] or 1)
        new_count = int(header[4] or 1)
        start = old_start - 1 if old_count else old_start
        assert start >= cursor
        output.extend(original[cursor:start]); cursor = start
        removed = added = 0
        index += 1
        while index < len(rows) and not rows[index].startswith('@@ '):
            line = rows[index]
            assert line[:1] in {' ', '-', '+'}, (path, line)
            if line[0] in ' -':
                assert cursor < len(original) and original[cursor] == line[1:], (path, cursor)
                cursor += 1; removed += 1
            if line[0] in ' +':
                output.append(line[1:]); added += 1
            index += 1
        assert (removed, added) == (old_count, new_count), (path, removed, added, old_count, new_count)
    output.extend(original[cursor:])
    result = ''.join(output).encode()
    assert result == postimages[path], path
    reconstructed[path] = sha(result)
assert set(reconstructed) == set(postimages)

candidate = dict(base_entries); candidate.update(subset)
virtual_tree = tree_hash(candidate)
check = subprocess.run(['git', 'apply', '--check', str(OUT / 'repair.patch')], cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
reconstruction = {
    'base_commit': BASE, 'base_tree': BASE_TREE,
    'base_tree_recomputed_from_complete_git_inventory': True,
    'postimage_path_count': len(files), 'serialized_patch_sections': len(sections),
    'all_exact_hunks_replayed_against_pinned_base': True,
    'all_reconstructed_bytes_match_postimages': True,
    'virtual_candidate_tree': virtual_tree,
    'source_subset_tree': tree_hash(subset),
    'no_git_objects_index_or_refs_written': True,
}
(OUT / 'base-patch-reconstruction.json').write_text(json.dumps(reconstruction, indent=2) + '\n')
(OUT / 'current-preimages-and-apply-check.json').write_text(json.dumps({
    'observed_head': observed_head, 'observed_head_tree': git('rev-parse', observed_head + '^{tree}').decode().strip(),
    'branch': git('symbolic-ref', '-q', 'HEAD').decode().strip(),
    'files': current,
    'git_apply_check': {'argv': ['git', 'apply', '--check', str(OUT / 'repair.patch')], 'returncode': check.returncode, 'stdout': check.stdout.decode(), 'stderr': check.stderr.decode()},
    'qualification': 'Read-only current snapshot; normal Root advances are expected. Root must recheck and merge shared functions contextually before applying. No stale postimage overwrite is authorized.',
}, indent=2) + '\n')

inputs = []
for relative, expected in [
    ('LOCAL/raw/e02-execution-20261027/reviews/C05-r7-code.md', 'fd275d90e0ee2fe8bf42af88eda0f820d854020291bf08cd721d9a9c7df2714d'),
    ('LOCAL/raw/e02-execution-20261027/reviews/C05-r7-code.json', '8d2b3403d34b0b3d7a5c9e363a71e5e12d1517839588e693879f099fb5b00913'),
    ('LOCAL/raw/e02-execution-20261027/repairs/C05-composed-fixture-r7/manifest.json', 'fd06941ab44810a66a097847b91cbecc54aa35d1b59e38cb289b958fd6276e1e'),
    ('LOCAL/raw/e02-execution-20261027/repairs/C05-composed-fixture-r7/repair.patch', '3aa627cf4230d89068a91c2d0d1fa79003dc27d27019914ed32ae83bc1a25883'),
]:
    item = artifact(ROOT / relative)
    assert item['sha256'] == expected, relative
    inputs.append(item)
previous = ROOT / 'LOCAL/raw/e02-execution-20261027/repairs/C05-composed-fixture-r7'
previous_manifest = json.loads((previous / 'manifest.json').read_text())
for item in previous_manifest['files']:
    assert sha((previous / item['path']).read_bytes()) == item['postimage_sha256'], item['path']

census = json.loads((OUT / 'shared-consumer-census.json').read_text())
assert census['base_commit'] == BASE and not census['syntax_errors']
assert not census['provider_verification_private_digest_calls']
counts = Counter(item['role'] for item in files)
python_paths = [item['path'] for item in files if item['path'].endswith('.py')]
toml_paths = [item['path'] for item in files if item['path'].endswith('.toml')]
readme_paths = [item['path'] for item in files if item['path'].endswith('/README.md')]
summary = json.loads((OUT / 'static-summary.json').read_text())
assert summary['ast_pass'] == len(python_paths) and summary['toml_pass'] == len(toml_paths)
assert summary['ruff_invocations'] == 2 * len(python_paths) and summary['ruff_failures'] == 0
ruff = json.loads((OUT / 'static-ruff-full.json').read_text())
for item in ruff:
    assert item['returncode'] == 0 and item['source_sha256'] == sha(postimages[item['path']])
composition = json.loads((OUT / 'base-composition.json').read_text())
assert composition['base_commit'] == BASE and len(composition['paths']) == len(files)
r8_delta_paths = [item['path'] for item in composition['paths'] if item['composed_r7_postimage_sha256'] != sha(postimages[item['path']])]
manifest = {
    'schema': 'policyos.e02.sparse_repair_manifest.v2',
    'task': 'C05 r8 lossless prepared-call identity and original Python dispatch repair',
    'status': 'frozen_source_proposal_pending_independent_review',
    'capability_state': 'verification_missing',
    'base_commit': BASE, 'base_tree': BASE_TREE,
    'virtual_candidate_tree': virtual_tree, 'source_subset_tree': tree_hash(subset),
    'virtual_tree_note': 'Complete pinned base plus exact sparse overlays hashed in memory. No Git tree/object/ref was written; this is not a composed product or runtime receipt.',
    'files': files, 'patch': artifact(OUT / 'repair.patch'), 'readme': artifact(OUT / 'README.md'),
    'inputs': inputs,
    'evidence': [artifact(OUT / name) for name in ['CHANGE-CONTRACT.md', 'static-ruff-full.json', 'static-summary.json', 'formatting-receipt.json', 'base-patch-reconstruction.json', 'current-preimages-and-apply-check.json', 'shared-consumer-census.json', 'census_shared_consumers.py', 'property-removals.json', 'remove-exact-call-binding.patch', 'remove-python-dispatch-preservation.patch', 'remove-preflight-reuse-bridge.patch', 'base-composition.json', 'prepare_manifest.py']],
    'footprint': {'complete_paths': len(files), 'mechanism_paths': counts['mechanism'], 'mandatory_companion_paths': len(files) - counts['mechanism'], 'roles': dict(counts), 'python_paths': len(python_paths), 'toml_paths': len(toml_paths), 'readme_paths': len(readme_paths), 'r8_delta_from_context_replayed_r7_paths': r8_delta_paths},
    'shared_consumer_census': {'base_source_python': census['base_python_files'], 'candidate_source_python': census['candidate_python_files'], 'literal_call_rows': len(census['calls']), 'form': 'complete source *.py AST literal preparation/constructor/call-values/legacy digest references; not nonliteral dynamic callers, tests or other languages', 'preflight_private_cache_digest_calls': 0, 'runtime': 'UNRUN'},
    'static_results': {'ast': f'{len(python_paths)}/{len(python_paths)} PASS', 'ruff_check_canonical_filename': f'{len(python_paths)}/{len(python_paths)} PASS', 'ruff_format_check_canonical_filename': f'{len(python_paths)}/{len(python_paths)} PASS', 'release_toml_parse': f'{len(toml_paths)}/{len(toml_paths)} PASS', 'complete_pinned_base_hunk_reconstruction': f'{len(files)}/{len(files)} PASS', 'current_worktree_apply_check_returncode': check.returncode},
    'p40_disposition': {
        'prepared_call_input_preservation': 'SAME class as both r7 findings, widened once across the shared complete logical-call representation and its actual dispatch callers. Exact equality uses lossless native types/raw bytes/order, never cache/evidence normalization; opaque/unfreezable values remain physical-only with original Python objects and cannot be pre-bound.',
        'actual_transport_owner': 'Gateway alone owns strict HTTP JSON; actual successful dispatch/fallback identity and R7 preflight delegation are retained. Simulator propagates actual snapshot reusability.',
        'request_identity_and_lifetime': 'R6 whole response/origin proof, actual returned/read-back begin receipt, current guard, independent complete basis, terminal proposal/profile/attempt and nonblocking closure remain unchanged in mechanism.',
        'preflight_resource_lifetime': 'Retain cache resource and current durable origin with fresh local wrappers and a single actual prepared request; defer closing an already admitted physical Gateway after only its waiter is cancelled.',
        'composition': 'R7 hunks replayed in memory onto the advanced pinned base. Preserve C37/C49/C57/C48 and context-compose future C71 without overwriting shared source.',
    },
    'predicate_basis': {
        'exact_prebound_invocation': 'recomputed from the complete lossless native Python value tree; unsupported/opaque equality is not_established and refuses external pre-binding',
        'opaque_physical_call': 'not_established as immutable payload identity or cache equivalence; original values are forwarded only after the existing current owner and producer-begin admission; fresh token identifies that physical event, not wire bytes',
        'caller_wire_and_successful_dispatch': 'recomputed by the actual prepared Gateway/fallback/simulator executor; preflight uses the same actual plan for digest and send',
        'current_job_actor_scope_attempt_lease_profile': 'independently_reconciled through canonical persisted live job and creation/outbox envelope',
        'actual_pending_begin_owner': 'independently_reconciled from returned exact BudgetLedgerProducerRecord and reopened canonical ledger record before dispatch',
        'response_projection_and_origin': 'recomputed by Core whole allowed projection and exact cache-owner session/retained-origin proof',
        'central_begin_set': 'produced at actual mandatory scoped factory/Core begin hook; closed admission interval independently reopened from terminal Core trace and compared as a complete set to current-attempt ledger',
        'institutional_permission_provider_invoice_and_interruptible_io': 'not_established; excluded from the authority claim and declared as bounded limitations',
    },
    'declared_limits': [
        'Native immutable equality is bounded to exact supported nonaliased native value trees. Aliases/cycles/views/subclasses/nonfinite/opaque values and excessive depth stay physical-only with original nested objects; no cache/equality authority is inferred and external pre-binding refuses. Generic arbitrary Python plugin behavior is not certified.',
        'Already-running blocking dependency I/O cannot be killed by the existing guard and may retain a bounded worker or its own mutex until return. Factory/binding/trace close does not wait on it; late admissions cannot dispatch and incomplete basis cannot reconcile.',
        'The complete central basis covers actual scoped producer begins, not catalog calls, internal transport retry invoices or institutional permission.',
        'All behavioral controls/removals/native tests and broad type/architecture/API/generated-surface checks remain UNRUN. Source/static green is not runtime or closure evidence.',
        'Pre-bound prepared-cache plans are ordinary calls only; live scoped clients retain internal preparation and current admission. No old scope, lease or receipt is reinstated.',
    ],
    'root_composition_boundaries': [
        'ControlPlaneStore: only additive DB-only verify_llm_producer_admission. C57 __init__/create_job/diagnostic helpers retained from pinned source; no callback-spanning transaction.',
        'run_lifecycle: only get_job_status/current cost helper delta. Preserve C37 selected queue payload reader, C57 cancelled record verification, C49 producer observer and C48 method-metric reader regions.',
        'BudgetMiddleware: separate binding-registry lock and register/release/lookup only. Preserve C49 snapshot_safe and observer/reconciler.',
        'C71 observational-source read grants/provenance/derived writer, C37 typed request admission, C07 outbox and other common owners remain separate. Root context-composes their advances.',
        'Root owns mandatory generated schema/lock/public-surface inventory and actual compatibility/type/architecture/API/native/hook checks. Release inventory flag remains false pending actual review.',
    ],
    'runtime_unrun': ['all supplied canonical component/integration modules including complete provider verification and real research POST pre-admission consumers', 'valid snapshot A vs invalid B with unchanged declared hash, reverse and changed-hash current CAS-owner controls', 'native tuple/list/byte/scalar/order equality and actual provider-observed Python types', 'opaque object/alias/cycle/view/subclass/nonfinite/deep original values with and without preparation, producer-begin rejection and positive admission', 'actual Gateway strict JSON array/rejection controls', 'ordinary POST warm hit/durable ledger/fresh GET', 'HTTP mutation/health/format, preflight catalog-wait/shared input/transport/cancelled waiter late settlement and close', 'in-progress guard/begin timeout and normal/error/cancel closure, actual returned owner and complete citation/terminal controls', 'all isolated property removals/restoration', 'mypy/architecture/generated/public API/hook/G checks'],
    'prior_r7_postimages_read_back_unchanged': len(previous_manifest['files']),
    'canonical_mutation': False, 'index_or_ref_mutation': False, 'product_imports_run': False,
    'pytest_run': False, 'children_spawned': 0, 'closure_ids': [],
}
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
readback = json.loads((OUT / 'manifest.json').read_text())
for item in readback['files']:
    path = OUT / item['path']
    assert sha(path.read_bytes()) == item['postimage_sha256'] and path.stat().st_nlink == 1
for item in [readback['patch'], readback['readme'], *readback['evidence'], *readback['inputs']]:
    assert sha((ROOT / item['path']).read_bytes()) == item['sha256']
print(json.dumps({'manifest_sha256': sha((OUT / 'manifest.json').read_bytes()), 'manifest_bytes': (OUT / 'manifest.json').stat().st_size, 'patch_sha256': sha(patch), 'patch_bytes': len(patch), 'virtual_candidate_tree': virtual_tree, 'source_subset_tree': tree_hash(subset), 'paths': len(files), 'role_counts': dict(counts), 'current_apply_check': check.returncode, 'current_mismatching_preimages': [item['path'] for item in current if not item['matches_base_preimage']], 'observed_head': observed_head, 'r8_delta_paths': r8_delta_paths}, indent=2))
