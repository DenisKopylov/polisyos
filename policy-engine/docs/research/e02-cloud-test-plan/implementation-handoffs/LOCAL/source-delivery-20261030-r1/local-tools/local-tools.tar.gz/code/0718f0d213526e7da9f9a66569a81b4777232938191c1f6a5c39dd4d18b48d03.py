"""Exercise only the proposed pure oracle against synthetic receipts, not product code."""
import ast
import copy
import hashlib
import json
from pathlib import Path

P = Path(__file__).resolve().parent
syntax = ast.parse((P/'lossy-decoder-test.txt').read_text())
functions = [n for n in ast.walk(syntax) if isinstance(n,ast.FunctionDef) and n.name=='preserves_raw_identities']
assert len(functions)==1
module=ast.fix_missing_locations(ast.Module(body=[functions[0]],type_ignores=[]))
namespace={};exec(compile(module,'<synthetic-i2-oracle>','exec'),namespace)
oracle=namespace['preserves_raw_identities']
raw={b'README.md':b'tracked fixture\n',b'native_\xff.json':b'first',b'native_\xfe.json':b'second',b'native_\xef\xbf\xbd.json':b'third'}
expected={k.decode('utf-8','surrogateescape'):hashlib.sha256(v).hexdigest() for k,v in raw.items()}
expected_matches={k.decode('utf-8','surrogateescape') for k in raw if k!=b'README.md'}
paths=list(expected)
def receipt(names: list[str]) -> dict:
 return {'selection':{'selected_paths':names,'selected_path_count':len(names)},
         'scanned_denominator':{'read_paths':names,'successful_byte_reads':len(names)},
         'read_receipt':{'complete_verdict':True,'inputs':[{'path':n,'sha256':expected[n],'operation':'read_bytes','status':'read'} for n in names]},
         'matches':[{'path':n,'target':'polisyos.foundry.domain.mechanisms'} for n in names if n in expected_matches]}
positive=receipt(paths)
# Models the present-collision receipt preserving existing fields, success status and
# literal replacement path while both raw invalid-byte identities disappear.
complete_but_collapsed=receipt(['README.md','native_\ufffd.json'])
wrong_digest=copy.deepcopy(positive);wrong_digest['read_receipt']['inputs'][1]['sha256']='0'*64
wrong_count=copy.deepcopy(positive);wrong_count['selection']['selected_path_count']-=1
wrong_marker=copy.deepcopy(positive);wrong_marker['matches'].pop()
absent=receipt(['README.md']);absent['read_receipt']['complete_verdict']=False
checks={'positive':oracle(positive,expected,expected_matches),
        'present_collision_complete_zero':not oracle(complete_but_collapsed,expected,expected_matches),
        'absent_collision':not oracle(absent,expected,expected_matches),
        'same_paths_wrong_digest':not oracle(wrong_digest,expected,expected_matches),
        'same_paths_wrong_count':not oracle(wrong_count,expected,expected_matches),
        'same_paths_missing_match':not oracle(wrong_marker,expected,expected_matches)}
assert all(checks.values());out={'scope':'pure oracle only; synthetic dictionaries, no Git/scanner/pytest/product imports','checks':checks,'product_runtime':'UNRUN','closure_ids':[]}
(P/'oracle-synthetic-results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
