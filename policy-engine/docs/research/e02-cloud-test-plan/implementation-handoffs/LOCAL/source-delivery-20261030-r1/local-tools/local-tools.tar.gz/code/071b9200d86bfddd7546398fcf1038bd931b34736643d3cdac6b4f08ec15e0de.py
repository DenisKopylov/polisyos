from pathlib import Path
import ast

packet = Path(__file__).resolve().parent
post = packet / 'postimages/policy-engine'

def edit(rel, replacements):
    path = post / rel
    text = path.read_text()
    for old, new in replacements:
        assert old in text, (rel, old)
        text = text.replace(old, new)
    ast.parse(text) if path.suffix == '.py' else None
    path.write_text(text)

edit('tools/devx/foundry/generate_stubs.py', [
    ('import ast\n', 'import ast\nimport copy\n'),
    ('from importlib import import_module\n', 'from enum import Enum\nfrom importlib import import_module\n'),
    ('        "--no-analysis",\n', '        "--no-analysis",\n        "--include-private",\n'),
    ('def _render_reexport(owner: str) -> str:', '''def _preserve_source_contract(module: str, content: str) -> str:
    """Preserve runtime Enum membership and explicit free-function annotations.

    Parse-only stubgen does not classify Enum members and treats every first
    argument named ``cls`` as implicit, including module-level functions.
    Derive members from actual runtime Enum classes; preserve source annotations
    on existing functions rather than curating symbol-specific corrections.
    ``--include-private`` also retains typed internal callables used by consumers.
    """
    source, error = resolve_polisyos_source_module_file(REPO_ROOT, module, is_file=measured_is_file)
    if source is None or error is not None:
        raise ValueError(f"Unable to resolve stub source {module}: {error}")
    source_tree = ast.parse(measured_read_text(source), filename=str(source))
    tree = ast.parse(content)
    runtime = import_module(module)
    functions = {
        node.name: node
        for node in source_tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    }
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            original = functions.get(node.name)
            if original is None:
                continue
            original_args = {
                arg.arg: arg
                for arg in (
                    *original.args.posonlyargs,
                    *original.args.args,
                    *original.args.kwonlyargs,
                )
            }
            for arg in (*node.args.posonlyargs, *node.args.args, *node.args.kwonlyargs):
                original_arg = original_args.get(arg.arg)
                if arg.annotation is None and original_arg is not None:
                    arg.annotation = copy.deepcopy(original_arg.annotation)
        elif isinstance(node, ast.ClassDef):
            actual = getattr(runtime, node.name, None)
            if not isinstance(actual, type) or not issubclass(actual, Enum):
                continue
            members = actual.__members__
            retained = [
                item
                for item in node.body
                if not (
                    isinstance(item, ast.AnnAssign)
                    and isinstance(item.target, ast.Name)
                    and item.target.id in members
                )
                and not (
                    isinstance(item, ast.Assign)
                    and any(isinstance(target, ast.Name) and target.id in members for target in item.targets)
                )
            ]
            assignments = []
            for name, member in members.items():
                value = member.value
                # Primitive values retain their precise ABI; other Enum values
                # still require an assignment, and ellipsis is valid in stubs.
                literal = value if type(value) in {str, int, float, bool, bytes, type(None)} else Ellipsis
                assignments.append(ast.Assign(targets=[ast.Name(id=name, ctx=ast.Store())], value=ast.Constant(value=literal)))
            node.body = [*assignments, *retained]
    return ast.unparse(ast.fix_missing_locations(tree)) + "\\n"


def _render_reexport(owner: str) -> str:'''),
    ('                cleaned = _remove_private_exports(measured_read_text(stub_path))', '                cleaned = _preserve_source_contract(\n                    module, _remove_private_exports(measured_read_text(stub_path))\n                )'),
])
edit('src/polisyos/foundry/methods/base.py', [('ParamsT = TypeVar("ParamsT", bound=Mapping[str, Any])', 'ParamsT = TypeVar("ParamsT", bound=Mapping[str, Any], contravariant=True)')])
edit('src/polisyos/foundry/methods/selection/registry.py', [('    MethodLifecycle,\n', '    MethodLifecycle as MethodLifecycle,\n')])
edit('src/polisyos/foundry/methods/backends/async_chain_executor.py', [('    error: Exception\n', '    error: BaseException\n')])
edit('src/polisyos/foundry/methods/components/linker.py', [
    ('from collections.abc import Iterator, Mapping, Sequence', 'from collections.abc import Iterable, Iterator, Mapping, Sequence'),
    ('def _slots_by_name(slots: Sequence[SlotSpec])', 'def _slots_by_name(slots: Iterable[SlotSpec])'),
    ('            src_name = matched_targets.get(tgt_name)\n            if src_name is None:', '            matched_source = matched_targets.get(tgt_name)\n            if matched_source is None:'),
    ('                if slot.name == src_name\n', '                if slot.name == matched_source\n'),
    ('                source_slot=src_name,\n', '                source_slot=matched_source,\n'),
])
edit('src/polisyos/foundry/methods/components/composer.py', [
    ('                frozen_dag.nodes[uid].node_key.static_params_digest\n                for uid in upstream_ids\n                if frozen_dag.nodes[uid].node_key is not None', '                key.static_params_digest\n                for uid in upstream_ids\n                if (key := frozen_dag.nodes[uid].node_key) is not None'),
])
edit('src/polisyos/foundry/methods/compiler/__init__.py', [
    ('from polisyos.foundry.methods.components.composer import ValidationContext', 'from polisyos.foundry.methods.components.composer import CompiledMethodChain, ValidationContext'),
    ('        method_class: type,\n', '        method_class: type[FoundryMethodProtocol],\n'),
    ('        if jit:\n            jit_kwargs:', '        step_core: KernelStepFn\n        if jit:\n            jit_kwargs:'),
    ('    chain: Any\n    compiled_methods:', '    chain: CompiledMethodChain\n    compiled_methods:'),
])
edit('src/polisyos/foundry/methods/backends/checkpointing.py', [
    ('def _iter_array_paths(value: Any, path: tuple[str, ...] = ()):', 'def _iter_array_paths(value: Any, path: tuple[str, ...] = ()) -> Iterator[tuple[str, ...]]:'),
])
edit('src/polisyos/foundry/methods/backends/chain_executor.py', [
    ('from typing import TYPE_CHECKING, Any, Literal, Protocol', 'from typing import TYPE_CHECKING, Any, Literal, Protocol, SupportsFloat, SupportsIndex'),
    ('from polisyos.foundry.methods.base import ComputeBackend, _stable_digest', 'from polisyos.foundry.methods.base import (\n    ComputeBackend,\n    FoundryMethod,\n    MethodSignature,\n    _stable_digest,\n)'),
    ('    from polisyos.foundry.methods.components.composer import ValidationContext', '    from polisyos.foundry.methods.components.composer import CompiledMethodChain, ValidationContext'),
    ('            return float(value)', '            if not isinstance(value, (str, bytes, bytearray, SupportsFloat, SupportsIndex)):\n                raise TypeError("FX rate does not support numeric conversion")\n            return float(value)'),
    ('    budgets = [\n', '    budgets: list[Mapping[str, Any]] = [\n'),
    ('    tiers = [result.reproducibility.determinism_tier for _, result in node_results]', '    tiers: list[DeterminismTier | None] = [\n        result.reproducibility.determinism_tier for _, result in node_results\n    ]'),
    ('    observed_tier = composed_budget.get("downgraded_to") or (\n        None if meet_determinism_tiers(tiers) is None else meet_determinism_tiers(tiers).value\n    )', '    met_tier = meet_determinism_tiers(tiers)\n    observed_tier = composed_budget.get("downgraded_to") or (\n        None if met_tier is None else met_tier.value\n    )'),
    ('    observed_tier = composed_budget.get("downgraded_to") or (\n        None\n        if meet_determinism_tiers(level_tiers) is None\n        else meet_determinism_tiers(level_tiers).value\n    )', '    met_tier = meet_determinism_tiers(level_tiers)\n    observed_tier = composed_budget.get("downgraded_to") or (\n        None if met_tier is None else met_tier.value\n    )'),
    ('    signature,\n    params:', '    signature: MethodSignature,\n    params:'),
    ('    signature_a,\n    signature_b,', '    signature_a: MethodSignature,\n    signature_b: MethodSignature,'),
    ('    chain,\n    node_id: UUID,\n    reg,', '    chain: CompiledMethodChain,\n    node_id: UUID,\n    reg: MethodRegistry,'),
    ('    signature,\n    current_context:', '    signature: MethodSignature,\n    current_context:'),
    (') -> tuple[Any, Any, Mapping[str, Any], dict[str, Any]]:', ') -> tuple[type[FoundryMethod[Any, Mapping[str, Any]]], Any, MethodSignature, dict[str, Any]]:'),
    ('def _can_fuse_pair(chain,', 'def _can_fuse_pair(chain: CompiledMethodChain,'),
    ('    method_class,\n    signature,', '    method_class: type[FoundryMethod[Any, Mapping[str, Any]]],\n    signature: MethodSignature,'),
    ('    method_class_a,\n    method_class_b,', '    method_class_a: type[FoundryMethod[Any, Mapping[str, Any]]],\n    method_class_b: type[FoundryMethod[Any, Mapping[str, Any]]],'),
    ('        import jax  # type: ignore[import-not-found]', '        import jax'),
    ('            if fused_supported:\n', '            if fused_supported and b_binding is not None:\n'),
])
# Ensure changing the optional binding check closes over the lazy builder too.
p=post/'src/polisyos/foundry/methods/backends/chain_executor.py';s=p.read_text();s=s.replace('                    kernel_key = _make_fused_kernel_key(', '                    b_input_slot = b_binding.source_slot\n                    kernel_key = _make_fused_kernel_key(').replace('b_input_slot=b_binding.source_slot,','b_input_slot=b_input_slot,').replace('                            b_binding.source_slot,','                            b_input_slot,');p.write_text(s)
