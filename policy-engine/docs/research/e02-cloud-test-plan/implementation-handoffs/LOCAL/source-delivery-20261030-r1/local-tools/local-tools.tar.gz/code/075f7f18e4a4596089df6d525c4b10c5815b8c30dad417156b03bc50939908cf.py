from __future__ import annotations
import _abc
import gc
import ast
import builtins as _builtins
import contextvars
import dataclasses as _dataclasses
import dis, functools, hashlib, importlib, importlib.util, inspect as _inspect, json, os, sys, sysconfig, tomllib, types, typing
from collections.abc import Callable, Iterable, Mapping
from contextlib import contextmanager
from dataclasses import dataclass
from enum import Enum
from fractions import Fraction
from pathlib import Path
from importlib.machinery import SourceFileLoader
import copy
ROOT=Path.cwd()
source=ROOT/'LOCAL/raw/e02-execution-20261027/repairs/N7-protocol-identity-r1/provider-removal.py'
tree=ast.parse(source.read_bytes(),filename=str(source))
module=types.ModuleType('identity_source_census')
sys.modules[module.__name__]=module
ns=vars(module)
ns.update(globals())
class ConfidenceLedgerError(Exception):
    pass
ns['ConfidenceLedgerError']=ConfidenceLedgerError
ns['_UNKNOWN_SOURCE_LITERAL']=object()
ns['_STATIC_FACADE_UNKNOWN']=ns['_UNKNOWN_SOURCE_LITERAL']
ns['_SOURCE_FACADE_NAMESPACE_EFFECT_GUARD']='__polisyos_static_namespace_effect_guard__'
ns['_READ_API_SURFACES_MODULE']='polisyos.data_forge.read_api.surfaces'
ns['_READ_API_SURFACE_ROUTES_MODULE']='polisyos.data_forge.read_api.surface_routes'
ns['_READ_API_PACKAGE_MODULE']='polisyos.data_forge.read_api'
ns['_READ_API_SURFACE_FIELDS']=('name','module','summary')
ns['_SOURCE_DERIVATION_FAILED']=object()
ns['_UNSUPPORTED_SOURCE_LITERAL']=object()
ns['_active_integrity_analysis']=lambda: None
future=ast.ImportFrom(module='__future__', names=[ast.alias(name='annotations')],level=0)
def install(node):
    m=ast.fix_missing_locations(ast.Module(body=[future, node],type_ignores=[]))
    exec(compile(m,str(source),'exec'),ns)
for name in ('_LiteralModuleGetattrProviderIndex','_AuthorityImportClosureSourceIndex','_SourceModuleImportRouteCandidate','_ProviderSourceGraphReconciliation','_LoaderOwnedCallableSlot'):
    install(copy.deepcopy(next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==name)))
missed={}
for node in tree.body:
    if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
        n=copy.deepcopy(node)
        n.decorator_list=[]
        try:
            install(n)
        except NameError as exc:
            missed[n.name]=str(exc)
ns['_active_integrity_analysis']=lambda: None

ns['BaseModel']=type('PlaceholderModel',(),{})
ns['PromotionObligationClass']=type('PlaceholderObligation',(),{})
ns['_LRU_CACHE_WRAPPER_TYPE']=type(functools.lru_cache(maxsize=1)(lambda: None))
print('PROVIDER RESULT',ns['_python_typing_protocol_source_supported']())
source_path=ROOT/'policy-engine/src/polisyos/core/artifacts/protocol.py'
protocol_tree=ast.parse(source_path.read_bytes(),filename=str(source_path))
owner=types.ModuleType('polisyos.core.artifacts.protocol')
owner.__file__=str(source_path)
owner.__spec__=importlib.util.spec_from_file_location(owner.__name__,source_path)
sys.modules[owner.__name__]=owner
selected=[next(n for n in protocol_tree.body if isinstance(n,ast.ImportFrom) and n.module=='__future__'),
          next(n for n in protocol_tree.body if isinstance(n,ast.Import) and any(a.name=='inspect' for a in n.names)),
          next(n for n in protocol_tree.body if isinstance(n,ast.ImportFrom) and n.module=='typing'),
          next(n for n in protocol_tree.body if isinstance(n,ast.FunctionDef) and n.name=='_require_return_selected_profile_writer'),
          next(n for n in protocol_tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='require_return_selected_profile_writer' for t in n.targets)),
          next(n for n in protocol_tree.body if isinstance(n,ast.ClassDef) and n.name=='ArtifactReader')]
exec(compile(ast.Module(body=selected,type_ignores=[]),str(source_path),'exec',dont_inherit=True),vars(owner))

def route(name):
    return ns['_source_module_direct_binding_route'](
        ROOT/'policy-engine', owner.__name__, name, directory_entries={},
        source_index=ns['_AuthorityImportClosureSourceIndex']({},{}),
        visited=frozenset({(owner.__name__,name)}),
    )
def reject(label,name):
    try:
        route(name)
    except ConfidenceLedgerError:
        print('PASS REJECT',label)
        return True
    print('FAIL ADMITTED',label)
    return False
assert route('ArtifactReader') is not None
assert route('require_return_selected_profile_writer') is not None
print('PASS POSITIVES')
original=owner.require_return_selected_profile_writer
owner.require_return_selected_profile_writer = lambda *_args: None
ok=reject('alias-substitution','require_return_selected_profile_writer')
owner.require_return_selected_profile_writer=original
exec(compile('def _require_return_selected_profile_writer(store, method_name):\n    return None\n',str(source_path),'exec'),vars(owner))
owner.require_return_selected_profile_writer=owner._require_return_selected_profile_writer
ok=reject('forged-alias-and-owner','require_return_selected_profile_writer') and ok
owner._require_return_selected_profile_writer=original
owner.require_return_selected_profile_writer=original
cls=owner.ArtifactReader
old=cls.has
exec(compile('def forged_has(self, artifact_id):\n    return True\n',str(source_path),'exec'),vars(owner))
cls.has=owner.forged_has
ok=reject('changed-method','ArtifactReader') and ok
cls.has=old
old_runtime=typing.runtime_checkable
typing.runtime_checkable = lambda cls: cls
ok=reject('forged-decorator-provider','ArtifactReader') and ok
typing.runtime_checkable=old_runtime
old_method=typing._ProtocolMeta.__instancecheck__
def forged_instance(cls, instance):
    return True
typing._ProtocolMeta.__instancecheck__=forged_instance
ok=reject('changed-provider-method','ArtifactReader') and ok
typing._ProtocolMeta.__instancecheck__=old_method
old_lazy=typing._lazy_load_getattr_static
calls=[]
def hostile_lazy():
    calls.append('executed')
    return _inspect.getattr_static
fake_lazy=functools.cache(hostile_lazy)
fake_lazy.__wrapped__=old_lazy.__wrapped__
typing._lazy_load_getattr_static=fake_lazy
ok=reject('spoofed-stdlib-cache-wrapper','ArtifactReader') and ok
print('HOSTILE CALLBACKS',len(calls))
typing._lazy_load_getattr_static=old_lazy
old_annotationlib=typing._lazy_annotationlib
old_annotation_module=sys.modules.get('annotationlib')
fake_annotationlib=types.ModuleType('annotationlib')
sys.modules['annotationlib']=fake_annotationlib
typing._lazy_annotationlib=fake_annotationlib
ok=reject('spoofed-annotation-provider','ArtifactReader') and ok
typing._lazy_annotationlib=old_annotationlib
if old_annotation_module is None:
    del sys.modules['annotationlib']
else:
    sys.modules['annotationlib']=old_annotation_module
cls._is_runtime_protocol=False
ok=reject('forged-runtime-flag','ArtifactReader') and ok
cls._is_runtime_protocol=True
fake=type('ArtifactReader',(typing.Protocol,),{'__module__':owner.__name__,'has':cls.has,'get_bytes':cls.get_bytes,'get_manifest':cls.get_manifest})
typing.runtime_checkable(fake)
owner.ArtifactReader=fake
ok=reject('same-name-fake-class','ArtifactReader') and ok
owner.ArtifactReader=cls
class Bad:
    def has(self, artifact_id): return True
    def get_bytes(self, artifact_id): return b''
    def get_manifest(self, artifact_id): return None
assert isinstance(Bad(),cls)
ok=reject('nonempty-abc-cache','ArtifactReader') and ok
raise SystemExit(0 if ok else 1)
