from pathlib import Path
base=Path('LOCAL/raw/e02-execution-20261027/repairs/C41-r8-companions/postimages/policy-engine/apps/runtime-dashboard/src')
p=base/'api/validators.test.ts';s=p.read_text();needle='import type { components } from "./types";\n';assert s.count(needle)==1;s=s.replace(needle,needle+'import { c41JointParentObservation } from "@/test/fixtures/c41JointParent";\n')
needle='describe("runtime API validators", () => {\n';assert s.count(needle)==1
code='''function c41V5Payload() {
  const payload = runDetailsPayload("projection only");
  const projection = mutableRecord(genericCycleSimulationProjection("run-projection-mask"));
  const first = firstMutableRecord(projection.n5_observations, "n5_observations");
  first.n5_owner_join_status = "resolved";
  const limited = structuredClone(first);
  limited.candidate_id = "candidate-limited";
  limited.cycle_index = 1;
  limited.design_problem_ref = `sha256:${"8".repeat(64)}`;
  limited.node_ref = `design-problem://${"8".repeat(64)}`;
  limited.n5_execution_ref = null;
  limited.n5_owner_join_status = "unavailable";
  limited.n5_owner_join_limitation_code = "generic_n5_owner_view_absent";
  limited.n5_request_binding_status = "not_established";
  limited.n5_request_content_hash = null;
  limited.n8_lineage_status = "not_established";
  limited.n8_value_ref = null;
  limited.n8_limitation_code = "n5_execution_request_provenance_not_established";
  limited.n8_authority_blockers = [
    ...((limited.n8_authority_blockers as string[]) ?? []),
    "n5_execution_request_provenance_not_established",
  ];
  limited.authority_blockers = [
    ...((limited.authority_blockers as string[]) ?? []),
    "n5_execution_request_provenance_not_established",
  ];
  limited.simulation_result_body = null;
  limited.simulation_result_body_status = "not_established";
  limited.simulation_result_body_limitation_code =
    "generic_n5_result_body_request_binding_not_established";
  projection.n5_observations = [first, limited];
  projection.schema_version = "policyos.runtime.run_generic_cycle_simulation_projection.v5";
  projection.joint_parent_status = "resolved";
  projection.joint_parent_observations = [c41JointParentObservation()];
  mutableRecord(payload.run).generic_cycle_simulation = projection;
  return payload;
}

'''
s=s.replace(needle,code+needle)
needle='''describe("runtime API validators", () => {
'''
tests='''describe("runtime API validators", () => {
  it("parses a v5 parent assessment separately from mixed child owner outcomes", () => {
    const parsed = runDetailsSchema.parse(c41V5Payload());
    const projection = parsed.run.generic_cycle_simulation;
    expect(projection?.schema_version).toBe(
      "policyos.runtime.run_generic_cycle_simulation_projection.v5",
    );
    expect(projection?.n5_observations.map((row) => row.n5_owner_join_status)).toEqual([
      "resolved", "unavailable",
    ]);
    expect(projection?.n5_observations[1]?.status).toBe("joint_simulated");
    expect(projection?.n5_observations[1]?.authority_blockers).toContain(
      "n5_execution_request_provenance_not_established",
    );
    expect(projection?.joint_parent_status).toBe("resolved");
    expect(projection?.joint_parent_observations?.[0]).toMatchObject({
      n8_status: "value_conditional",
      n8_candidate_decision_grade: "low",
      n8_joint_scope_status: "not_established",
      n8_source_candidate_relationship: "alternatives",
      n8_policy_composition_status: "not_established",
    });
    expect(projection?.joint_parent_observations?.[0]?.n5_interaction_evidence
      ?.higher_order_residuals["outcome-a"]?.["0"]).toBe(1);
    expect(projection?.publication_authority).toBe(false);
  });

  it("retains v5 parent unavailability with its limitation and successful child", () => {
    const payload = c41V5Payload();
    const projection = mutableRecord(mutableRecord(payload.run).generic_cycle_simulation);
    projection.joint_parent_status = "not_established";
    projection.joint_parent_observations = [];
    projection.joint_parent_limitation_code = "generic_joint_parent_result_not_established";
    const parsed = runDetailsSchema.parse(payload).run.generic_cycle_simulation;
    expect(parsed?.joint_parent_status).toBe("not_established");
    expect(parsed?.joint_parent_limitation_code).toBe("generic_joint_parent_result_not_established");
    expect(parsed?.n5_observations[0]?.n5_owner_join_status).toBe("resolved");
  });

  it.each([
    "v4_with_new_extension", "v5_without_extension", "resolved_owner_missing_execution",
    "limited_owner_missing_reason", "mismatch_with_unblocked_row", "resolved_parent_blocked",
    "resolved_parent_missing_result", "parent_missing_selection", "conditional_parent_missing_grade",
    "conditional_parent_wrong_ref", "conditional_parent_missing_provenance", "parent_claims_authority",
    "parent_residual_removed_with_markers",
  ])("refuses contradictory v5 candidate status or evidence: %s", (control) => {
    const payload = c41V5Payload();
    const projection = mutableRecord(mutableRecord(payload.run).generic_cycle_simulation);
    const children = projection.n5_observations as Record<string, unknown>[];
    const first = children[0]!;
    const limited = children[1]!;
    const parent = firstMutableRecord(projection.joint_parent_observations, "joint_parent_observations");
    if (control === "v4_with_new_extension") {
      projection.schema_version = "policyos.runtime.run_generic_cycle_simulation_projection.v4";
    } else if (control === "v5_without_extension") {
      delete projection.joint_parent_status;
      delete projection.joint_parent_observations;
      for (const child of children) {
        delete child.n5_owner_join_status;
        delete child.n5_owner_join_limitation_code;
      }
    } else if (control === "resolved_owner_missing_execution") {
      first.n5_execution_ref = null;
    } else if (control === "limited_owner_missing_reason") {
      delete limited.n5_owner_join_limitation_code;
    } else if (control === "mismatch_with_unblocked_row") {
      limited.n5_owner_join_status = "mismatch";
    } else if (control === "resolved_parent_blocked") {
      parent.status = "simulation_blocked";
    } else if (control === "resolved_parent_missing_result") {
      parent.simulation_result_ref = null;
    } else if (control === "parent_missing_selection") {
      delete parent.n8_candidate_joint_selection_status;
    } else if (control === "conditional_parent_missing_grade") {
      delete parent.n8_candidate_decision_grade;
    } else if (control === "conditional_parent_wrong_ref") {
      parent.n8_candidate_value_ref = `sha256:${"0".repeat(64)}`;
    } else if (control === "conditional_parent_missing_provenance") {
      parent.n8_authority_blockers = (parent.n8_authority_blockers as string[]).filter(
        (code) => code !== "n5_execution_request_provenance_not_established",
      );
    } else if (control === "parent_claims_authority") {
      projection.publication_authority = true;
    } else {
      const evidence = mutableRecord(parent.n5_interaction_evidence);
      evidence.higher_order_residuals = {};
      evidence.higher_order_residual_sampling = {};
    }
    expect(runDetailsSchema.safeParse(payload).success).toBe(false);
  });

'''
s=s.replace(needle,tests);p.write_text(s)
p=base/'features/runs/domain/genericCycleSimulation.test.ts';s=p.read_text();needle='import {\n  normalizeGenericCycleSimulation,';assert s.count(needle)==1;s=s.replace(needle,'import { c41JointParentObservation } from "@/test/fixtures/c41JointParent";\n'+needle)
needle='''  it("withholds N6 history when its projection is bound to a different run", () => {'''
test='''  it("accepts v5 parent assessment only with a valid candidate extension", () => {
    const projection = parsedProjection();
    if (!projection) throw new Error("expected a parsed projection");
    const v5 = {
      ...projection,
      schema_version: "policyos.runtime.run_generic_cycle_simulation_projection.v5",
      joint_parent_status: "resolved",
      joint_parent_observations: [c41JointParentObservation()],
    };
    const parsed = runDetailsSchema.parse({
      meta: { request_id: "req-v5", generated_at: "2026-10-11T10:00:00Z", source_kinds: ["core_run"] },
      run: { run_id: "run-1", source_kind: "core_run", status: "completed", generic_cycle_simulation: v5 },
      temporal_scope: null,
    }).run.generic_cycle_simulation;
    expect(normalizeGenericCycleSimulation("run-1", parsed)).toMatchObject({ kind: "candidate_only" });
    const corrupted = { ...parsed!, joint_parent_status: "resolved", joint_parent_observations: [] };
    expect(normalizeGenericCycleSimulation("run-1", corrupted as RunGenericCycleSimulationProjection))
      .toEqual({ kind: "refused", reason: "projection_version_binding_invalid" });
  });

'''
assert s.count(needle)==1;s=s.replace(needle,test+needle);p.write_text(s)
p=base/'features/runs/routes/tabs/OverviewTab.test.tsx';s=p.read_text();needle='import { runN5InteractionEvidenceFixture } from "@/test/fixtures/runN5InteractionEvidence";\n';assert s.count(needle)==1;s=s.replace(needle,needle+'import { c41JointParentObservation } from "@/test/fixtures/c41JointParent";\n')
needle='''  it("renders generic leaf outcomes separately from the pending frontier", () => {'''
test='''  it("renders the v5 parent joint candidate separately from child rows", () => {
    const projection = genericCycleSimulationProjection("run-1");
    const v5 = {
      ...projection,
      schema_version: "policyos.runtime.run_generic_cycle_simulation_projection.v5",
      joint_parent_status: "resolved",
      joint_parent_observations: [c41JointParentObservation()],
      n5_observations: projection.n5_observations.map((row, index) => index === 0
        ? { ...row, n5_owner_join_status: "resolved" }
        : { ...row, n5_owner_join_status: "not_established", n5_owner_join_limitation_code: "generic_n5_owner_ref_not_established" }),
    };
    overviewState.run = runDetailsSchema.parse({
      meta: { request_id: "req-v5", generated_at: "2026-10-11T10:00:00Z", source_kinds: ["core_run"] },
      run: { run_id: "run-1", source_kind: "core_run", status: "completed", generic_cycle_simulation: v5 },
      temporal_scope: null,
    }).run;
    renderWithProviders(<OverviewTab />);
    const parent = screen.getByTestId("overview-generic-cycle-joint-parent");
    expect(parent).toHaveTextContent("Parent joint candidate assessment");
    expect(parent).toHaveTextContent("value_conditional");
    expect(parent).toHaveTextContent("low");
    expect(parent).toHaveTextContent("non_additive");
    expect(parent).toHaveTextContent("Higher-order residual for outcome-a, step 0: 1");
    expect(parent).toHaveTextContent("alternatives");
    expect(parent).toHaveTextContent("n5_execution_request_provenance_not_established");
    expect(screen.getAllByTestId("overview-generic-cycle-n5-row")).toHaveLength(2);
    expect(screen.getAllByTestId("overview-generic-cycle-n5-owner-join")).toHaveLength(2);
    expect(parent).not.toHaveTextContent("publication_ready");
  });

'''
assert s.count(needle)==1;s=s.replace(needle,test+needle);p.write_text(s)
