from pathlib import Path
p=Path('LOCAL/raw/e02-execution-20261027/repairs/q1-inspector-tests-r1/postimages/policy-engine/tests/unit/runtime/http/test_artifact_inspector_api.py');s=p.read_text()
s=s.replace('import polisyos.runtime.http.routes.artifacts as artifact_routes\n','import polisyos.runtime.http.routes.artifacts as artifact_routes\nimport polisyos.runtime.http.services.artifact_inspector as inspector_module\n',1)
old='''        default_envelope = envelope_ref(f"{label}-default", denied=default_denied)
        selected_envelope = envelope_ref(
            f"{label}-selected",
            denied=selected_denied,
            denied_purpose=selected_denied_purpose,
            kind=selected_envelope_kind,
        )

'''
assert old in s;s=s.replace(old,'',1)
old='''        default_ref = store.put_json(
            payload,
            write_options(default_envelope),
            return_selected_profile=True,
        )
        selected_ref = store.put_json(
            payload,
            write_options(selected_envelope, selected_authority_link),
            return_selected_profile=True,
        )'''
new='''        # Write under the real fixture owner, including when this payload ID
        # already belongs to an earlier selected view in the same test.
        with tenant_scope(
            None, tenant_id=runtime_api_env["tenant_a"], cell_id=runtime_api_env["cell_a"]
        ):
            default_envelope = envelope_ref(f"{label}-default", denied=default_denied)
            selected_envelope = envelope_ref(
                f"{label}-selected",
                denied=selected_denied,
                denied_purpose=selected_denied_purpose,
                kind=selected_envelope_kind,
            )
            default_ref = store.put_json(
                payload,
                write_options(default_envelope),
                return_selected_profile=True,
            )
            selected_ref = store.put_json(
                payload,
                write_options(selected_envelope, selected_authority_link),
                return_selected_profile=True,
            )'''
assert old in s;s=s.replace(old,new,1)
start=s.index('def test_default_json_content_and_schema_carry_one_bounded_manifest_selection(')
end=s.find('\n\ndef ',start+5)
if end<0:end=len(s)
s=s[:start]+'''def test_default_json_content_and_schema_carry_one_bounded_manifest_selection(
    runtime_api_env, monkeypatch
) -> None:
    artifact_id = runtime_api_env["workflow_report_artifact_id"]
    client = runtime_api_env["client"]
    expected_selector = ArtifactID.model_validate(artifact_id)
    route_reader = artifact_routes.read_core_manifest_profile_bounded
    inspector_reader = inspector_module.read_core_manifest_profile_bounded
    semantic_reader = inspector_module._read_inspector_semantic_json
    route_reads: list[tuple[object, dict[str, object], object]] = []
    inspector_reads: list[object] = []
    semantic_headers: list[object] = []

    def observe_route(store, selector, **kwargs):
        result = route_reader(store, selector, **kwargs)
        route_reads.append((selector, dict(kwargs), result))
        return result

    def observe_inspector(store, selector, **kwargs):
        inspector_reads.append(selector)
        return inspector_reader(store, selector, **kwargs)

    def observe_semantic(store, selector, *, max_payload_bytes, manifest_read=None):
        semantic_headers.append(manifest_read)
        return semantic_reader(
            store, selector, max_payload_bytes=max_payload_bytes, manifest_read=manifest_read
        )

    monkeypatch.setattr(artifact_routes, "read_core_manifest_profile_bounded", observe_route)
    monkeypatch.setattr(inspector_module, "read_core_manifest_profile_bounded", observe_inspector)
    monkeypatch.setattr(inspector_module, "_read_inspector_semantic_json", observe_semantic)

    def carries_single_selected_header() -> bool:
        if len(route_reads) != 2 or len(semantic_headers) != 1 or inspector_reads:
            return False
        default_selector, default_options, default_read = route_reads[0]
        selected_selector, selected_options, selected_read = route_reads[1]
        return (
            default_selector == expected_selector
            and selected_selector == expected_selector
            and default_options == {
                "max_manifest_bytes": artifact_routes.INSPECTOR_MANIFEST_MAX_BYTES,
                "manifest_profile_sha256": None,
                "allow_profile_absent": True,
            }
            and selected_options == {
                "max_manifest_bytes": artifact_routes.INSPECTOR_MANIFEST_MAX_BYTES,
                "manifest_profile_sha256": artifact_manifest_profile_sha256(default_read.manifest),
                "allow_profile_absent": True,
            }
            and selected_read.manifest == default_read.manifest
            and semantic_headers[0] is selected_read
        )

    for surface in ("content", "schema"):
        route_reads.clear()
        inspector_reads.clear()
        semantic_headers.clear()
        response = _runtime_api_request(
            runtime_api_env, client.get, f"/api/v1/artifacts/{artifact_id}/{surface}"
        )
        assert response.status_code == 200, response.text
        assert carries_single_selected_header()

    # Property-removal control: discard the carried selected header at the
    # actual semantic read. The response remains valid but the owner must do a
    # fresh bounded selection, which the invariant above must detect.
    def discard_header(store, selector, *, max_payload_bytes, manifest_read=None):
        return observe_semantic(store, selector, max_payload_bytes=max_payload_bytes)

    monkeypatch.setattr(inspector_module, "_read_inspector_semantic_json", discard_header)
    for surface in ("content", "schema"):
        route_reads.clear()
        inspector_reads.clear()
        semantic_headers.clear()
        response = _runtime_api_request(
            runtime_api_env, client.get, f"/api/v1/artifacts/{artifact_id}/{surface}"
        )
        assert response.status_code == 200, response.text
        assert len(inspector_reads) == 1
        assert not carries_single_selected_header()
''' + s[end:]
p.write_text(s)
