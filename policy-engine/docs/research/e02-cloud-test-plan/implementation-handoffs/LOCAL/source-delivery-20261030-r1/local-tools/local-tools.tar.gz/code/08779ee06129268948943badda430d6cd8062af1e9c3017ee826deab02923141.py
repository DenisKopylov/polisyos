from pathlib import Path
r=Path(__file__).parent/'policy-engine'
p=r/'src/polisyos/scientist/orchestration/engine/budget_ledger.py';s=p.read_text();s=s.replace('from polisyos.scientist.orchestration.engine.budget import BudgetState','from polisyos.core.llm.cache_settlement import CacheSettlementSession\nfrom polisyos.core.llm.settlement import LLMProducerEvent\nfrom polisyos.scientist.orchestration.engine.budget import BudgetState');s=s.replace('_SNAPSHOT_VERSION = "1.4"','_SNAPSHOT_VERSION = "1.5"')
pos=s.index('\n\nclass BudgetLedgerProducerRecord')
s=s[:pos]+'''

class BudgetLedgerCacheReuseAdmission(BaseModel):
    """Frozen local admission of an exact authorized cache edge across runs.

    This is an accounting observation by the ledger, not external permission.
    Only the live Core response verifier can create it at a new write; readers
    recheck its exact source/receiver graph bindings without reissuing the source.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    verifier: Literal["core.cache_settlement.response.v1"] = "core.cache_settlement.response.v1"
    cache_key: str = Field(min_length=1)
    response_digest: str = Field(pattern=r"^[a-f0-9]{64}$")
    issuer: str = Field(min_length=1)
    epoch: str = Field(min_length=1)
    actor_id: str = Field(min_length=1)
    tenant_id: str = Field(min_length=1)
    scope: str = Field(min_length=1)
    purpose: str = Field(min_length=1)


def _verified_cache_reuse_admission(
    *,
    session: CacheSettlementSession | None,
    response: object | None,
    event_id: str,
    request_digest: str,
    payload_digest: str,
    origin_event_id: str | None,
    model: str,
    provider: str,
) -> BudgetLedgerCacheReuseAdmission | None:
    """Resolve the opaque Core proof and bind all current event payload fields."""
    if session is None and response is None:
        return None
    if type(session) is not CacheSettlementSession or response is None:
        raise ValueError("producer_reuse_admission_missing_core_response")
    proof = getattr(response, "_polisyos_reuse_provenance", None)
    evidence = session.verify_reuse_attestation(proof, response)
    if evidence is None:
        raise ValueError("producer_reuse_admission_invalid_core_response")
    scope = evidence.scope_key
    if (
        evidence.reuse_event_id != event_id
        or evidence.request_digest != request_digest
        or evidence.origin_event_id != origin_event_id
    ):
        raise ValueError("producer_reuse_admission_event_mismatch")
    event = LLMProducerEvent(
        event_id=event_id, request_digest=request_digest,
        response_digest=evidence.response_digest, model=model, provider=provider,
        amount=Decimal(0), cost_origin="reuse", kind="reuse", origin_event_id=origin_event_id,
    )
    if event.payload_digest != payload_digest:
        raise ValueError("producer_reuse_admission_payload_mismatch")
    # Ordinary same-run cache reuse still uses the original ledger contract.
    # Only a current authorizer decision can widen it across run boundaries.
    if len(scope) < 9 or scope[7] != model or scope[8] != request_digest:
        return None
    return BudgetLedgerCacheReuseAdmission(
        cache_key=evidence.cache_key, response_digest=evidence.response_digest,
        issuer=scope[0], epoch=scope[1], actor_id=scope[2], tenant_id=scope[3],
        scope=scope[4], purpose=scope[5],
    )
'''+s[pos:]
s=s.replace('    revision: int = Field(ge=1)\n    committed_at: datetime = Field(default_factory=lambda: datetime.now(UTC))\n\n    def model_post_init', '    reuse_admission: BudgetLedgerCacheReuseAdmission | None = Field(\n        default=None, json_schema_extra={"introduced_in": "1.5"}\n    )\n    revision: int = Field(ge=1)\n    committed_at: datetime = Field(default_factory=lambda: datetime.now(UTC))\n\n    def model_post_init',1)
s=s.replace('        elif self.origin_event_id is not None:\n            raise ValueError("producer_reuse_origin_unexpected")\n        if self.run_binding', '        elif self.origin_event_id is not None or self.reuse_admission is not None:\n            raise ValueError("producer_reuse_origin_unexpected")\n        if self.run_binding',1)
s=s.replace('            or source.key != self.key\n','',1).replace('            or source.run_binding != self.run_binding\n','',1)
needle='            raise ValueError("producer_reuse_origin_mismatch")\n\n\ndef _validate_producer_settlement_origin_graph'
assert needle in s
s=s.replace(needle,'''            raise ValueError("producer_reuse_origin_mismatch")
        if source.key == self.key and source.run_binding == self.run_binding:
            return
        admission = self.reuse_admission
        source_binding, receiver_binding = source.run_binding, self.run_binding
        if (
            admission is None or source_binding is None or receiver_binding is None
            or (source_binding.tenant_id, source_binding.cell_id, source_binding.profile_id)
            != (receiver_binding.tenant_id, receiver_binding.cell_id, receiver_binding.profile_id)
            or admission.tenant_id != receiver_binding.tenant_id
            or admission.scope != f"{receiver_binding.tenant_id}/{receiver_binding.cell_id}"
        ):
            raise ValueError("producer_reuse_origin_cross_run_admission_missing")
        event = LLMProducerEvent(
            event_id=self.event_id, request_digest=self.request_digest,
            response_digest=admission.response_digest, model=self.model, provider=self.provider,
            amount=Decimal(0), cost_origin="reuse", kind="reuse", origin_event_id=self.origin_event_id,
        )
        if event.payload_digest != self.payload_digest:
            raise ValueError("producer_reuse_origin_cross_run_payload_mismatch")


def _validate_producer_settlement_origin_graph''',1)
s=s.replace('        "1.3",\n        _SNAPSHOT_VERSION,','        "1.3",\n        "1.4",\n        _SNAPSHOT_VERSION,',1)
# Both concrete and protocol signatures receive the live proof, never a caller-constructed admission record.
old='        pre_admission_attempt_id: str | None = None,\n    ) -> BudgetLedgerProducerRecord:'
# occurs begin concrete/protocol too; only target settle definitions by textual section boundaries.
for marker in ['    def settle_producer_event(\n']:
 starts=[];offset=0
 while (idx:=s.find(marker,offset))>=0:starts.append(idx);offset=idx+len(marker)
 for idx in reversed(starts):
  stop=s.index('    ) -> BudgetLedgerProducerRecord:',idx)
  s=s[:stop]+'''        cache_reuse_session: CacheSettlementSession | None = None,
        cache_reuse_response: object | None = None,
'''+s[stop:]
needle='        status: Literal["committed", "unknown"] = "unknown" if amount is None else "committed"\n        candidate ='
s=s.replace(needle,'''        status: Literal["committed", "unknown"] = "unknown" if amount is None else "committed"
        if cost_origin != "reuse" and (cache_reuse_session is not None or cache_reuse_response is not None):
            raise ValueError("producer_reuse_admission_unexpected")
        admission = _verified_cache_reuse_admission(
            session=cache_reuse_session, response=cache_reuse_response,
            event_id=event_id, request_digest=request_digest, payload_digest=payload_digest,
            origin_event_id=origin_event_id, model=model, provider=provider,
        ) if cost_origin == "reuse" else None
        candidate =''',1)
s=s.replace('            cost_origin=cost_origin,\n            status=status,','            cost_origin=cost_origin,\n            reuse_admission=admission,\n            status=status,',1)
s=s.replace('                            "origin_event_id",\n                            "control_job_attempt",','                            "origin_event_id",\n                            "reuse_admission",\n                            "control_job_attempt",',1)
s=s.replace('    "BudgetLedgerProducerRecord",','    "BudgetLedgerProducerRecord",\n    "BudgetLedgerCacheReuseAdmission",',1)
p.write_text(s)
p=r/'src/polisyos/scientist/orchestration/engine/budget_middleware.py';s=p.read_text();s=s.replace('from polisyos.scientist.orchestration.engine.budget import','from polisyos.core.llm.cache_settlement import CacheSettlementSession\nfrom polisyos.scientist.orchestration.engine.budget import',1)
start=s.index('    def settle_producer_event_safe(');idx=s.index('    ) -> BudgetLedgerProducerRecord:',start);s=s[:idx]+'''        cache_reuse_session: CacheSettlementSession | None = None,
        cache_reuse_response: object | None = None,
'''+s[idx:]
idx=s.index('                pre_admission_attempt_id=pre_admission_attempt_id,',start);end=idx+len('                pre_admission_attempt_id=pre_admission_attempt_id,');s=s[:end]+'''
                cache_reuse_session=cache_reuse_session,
                cache_reuse_response=cache_reuse_response,'''+s[end:];p.write_text(s)
p=r/'src/polisyos/core/llm/traced_client.py';s=p.read_text();start=s.index('    def _persist_producer_event(');idx=s.index('        route: _ProducerSettlementRoute | None = None,',start)+len('        route: _ProducerSettlementRoute | None = None,');s=s[:idx]+'''\n        cache_reuse_response: object | None = None,'''+s[idx:]
idx=s.index('            record = settle(',start);s=s[:idx]+'''            reuse_kwargs = (
                {"cache_reuse_session": self._cache_settlement_session,
                 "cache_reuse_response": cache_reuse_response}
                if cache_reuse_response is not None else {}
            )
'''+s[idx:];idx=s.index('                origin_event_id=event.origin_event_id,',idx)+len('                origin_event_id=event.origin_event_id,');s=s[:idx]+'''\n                **reuse_kwargs,'''+s[idx:]
s=s.replace('                prior = self._persist_producer_event(producer_event, route=route)','                prior = self._persist_producer_event(\n                    producer_event, route=route, cache_reuse_response=response\n                )',1);p.write_text(s)
