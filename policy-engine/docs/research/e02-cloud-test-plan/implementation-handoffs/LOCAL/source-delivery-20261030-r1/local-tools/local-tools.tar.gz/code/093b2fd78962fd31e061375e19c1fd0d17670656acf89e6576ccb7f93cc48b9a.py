"""Opt-in, in-memory matched-removal controls for the composed C50 source.

The plugin is inert unless the native D runner explicitly loads it. Each run
admits exact source/test/plugin bytes, applies one AST-checked removal to the
loaded owner, and retains the active function plus a run receipt under the D
case directory. A setup or collection error can never count as a behavioral
removal.
"""

from __future__ import annotations

import ast
import functools
import hashlib
import importlib
import inspect
import json
import marshal
import os
import subprocess
import sys
import textwrap
from pathlib import Path
from types import ModuleType
from typing import Any, Callable

import pytest
import _pytest

_TEST_CONSISTENCY = "tests/unit/calibration/diagnostics/test_c50_receipt_consistency.py"

# These pins are the composed C50-r2 bytes. The root-owned source-bound D plan
# must repeat this set and bind the moving HEAD/tree immediately before a run.
_SOURCE_PINS = {
    "src/polisyos/ir/analytics/calibration_diagnostics.py": "d62583344c7a85ebc25869adc65917bfbcd0d1419f1824877d1fd81635ff5e95",
    "src/polisyos/calibration/diagnostics/continuous.py": "c7202a9d529919d1231fe8ce301700251705b3e742f31074ff66ba5a5036093b",
    "src/polisyos/calibration/diagnostics/adapters.py": "1bc5e8164b0ca7b86ef8f860191ed9c7a082121a90bca46b776ad29025896e5c",
    "src/polisyos/ir/analytics/_truthfulness.py": "a450f6a11c8b8e6519088527d50828bd51343cf7ea655e20ad8d45a47503193f",
    "src/polisyos/foundry/methods/backends/dispatch.py": "99b06b71938f581679d1fb87eab61c1f42fd0522d9e311c67f92262b5076861b",
    "src/polisyos/ir/api.py": "4754f7212fde5a35ecc00079c1fd0596301afb64c3dc4dfac14d2bfdbb40fa18",
    "src/polisyos/ir/analytics/__init__.py": "e21e25be3d824db6944cae20673515a74b8d10a7bf1127f906ebe4813bb40318",
    "src/polisyos/ir/__init__.py": "e3f0dd7f5625fbb453c3e085c953fb3f6b168e7be7af129dc83aa7fd8d46ea0a",
    _TEST_CONSISTENCY: "ffe7ba998371788f879f43ec35a94f74512c56626189bbc97726f80d0e3446a2",
}

_NODES = {
    "coverage_reconciliation": (
        f"{_TEST_CONSISTENCY}::test_positive_metadata_cannot_admit_an_empty_interval_curve",
    ),
    "origin_cap": (
        f"{_TEST_CONSISTENCY}::test_hand_authored_coherent_report_without_source_binding_is_limited",
    ),
    "typed_report_precedence": (
        f"{_TEST_CONSISTENCY}::test_embedded_positive_receipt_cannot_bypass_continuous_recomputation",
    ),
    "dispatch_sidecar_merge": (
        f"{_TEST_CONSISTENCY}::test_typed_incomplete_report_dominates_a_positive_sidecar_in_real_dispatch_merge",
    ),
    "duplicate_levels": (
        f"{_TEST_CONSISTENCY}::test_continuous_producer_rejects_duplicate_requested_levels",
    ),
    "severity_status": (
        f"{_TEST_CONSISTENCY}::test_any_fatal_diagnostic_issue_cannot_leave_a_pass_ready_validation[binary-probability]",
        f"{_TEST_CONSISTENCY}::test_any_fatal_diagnostic_issue_cannot_leave_a_pass_ready_validation[multiclass-probability]",
    ),
    "warning_suppression": (
        f"{_TEST_CONSISTENCY}::test_warning_with_the_expected_issue_code_cannot_mask_recomputed_error",
    ),
}

_EXPECTED_FAILURES = {
    "coverage_reconciliation": {
        "assertion": 'assert validation.verdict == "fail"',
        "actual_semantic": "metadata-only positive with zero curve bins yields blocked, not fail",
    },
    "origin_cap": {
        "assertion": "receipt.runtime_truthfulness_tier is TruthfulnessTier.UNVERIFIED",
        "actual_semantic": "coherent hand-authored continuous report receives approximate_calibrated",
    },
    "typed_report_precedence": {
        "assertion": "assert extracted == recomputed",
        "actual_semantic": "embedded positive receipt is returned instead of the recomputed limited report receipt",
    },
    "dispatch_sidecar_merge": {
        "assertion": "receipt.runtime_truthfulness_tier is TruthfulnessTier.UNVERIFIED",
        "actual_semantic": "positive sidecar is selected over the typed incomplete report in the real merge result",
    },
    "duplicate_levels": {
        "assertion": "Failed: DID NOT RAISE <class 'ValueError'>",
        "actual_semantic": "the real continuous producer accepts duplicate requested levels",
    },
    "severity_status": {
        "assertion": 'assert report.verdict == "fail"',
        "actual_semantic": "binary and multiclass fatal issues remain present but verdict/readiness default positive",
    },
    "warning_suppression": {
        "assertion": 'assert validation.verdict == "fail"',
        "actual_semantic": "a warning with the same code suppresses the recomputed fatal interval error",
    },
}

_ENV_PREFIX = "POLISYOS_C50_CONTROL_"
_STATE: dict[str, Any] = {}


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _canonical_json(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def _required(name: str) -> str:
    value = os.environ.get(name)
    if not value:
        raise pytest.UsageError(f"C50 removal input missing: {name}")
    return value


def _control_env(name: str) -> str:
    return _required(_ENV_PREFIX + name)


def _git(root: Path, *args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=root, text=True).strip()


def _save(path: Path, value: object) -> None:
    if path.is_symlink():
        raise pytest.UsageError(f"C50 control output cannot be a symlink: {path}")
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _function_tree(original: Callable[..., Any], target: str) -> ast.Module:
    parsed = ast.parse(textwrap.dedent(inspect.getsource(original)))
    definitions = [
        node
        for node in parsed.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    ]
    if len(definitions) != 1 or definitions[0].name != target:
        raise pytest.UsageError(f"C50 expected one source definition for {target}")
    if not isinstance(definitions[0], ast.FunctionDef):
        raise pytest.UsageError(f"C50 refuses async removal target {target}")
    return parsed


def _compile_active(
    module: ModuleType,
    original: Callable[..., Any],
    target: str,
    mode: str,
) -> tuple[Callable[..., Any], str, str, int, str]:
    """Transform only a pinned current function and compile the in-memory copy."""

    parsed = _function_tree(original, target)
    function = next(
        node for node in parsed.body if isinstance(node, ast.FunctionDef) and node.name == target
    )
    rewrite_count = 0
    description = ""

    if mode == "coverage_reconciliation":
        guard_index = None
        for index, statement in enumerate(function.body):
            if not isinstance(statement, ast.If):
                continue
            test = statement.test
            if (
                isinstance(test, ast.Compare)
                and isinstance(test.left, ast.Attribute)
                and isinstance(test.left.value, ast.Name)
                and test.left.value.id == "self"
                and test.left.attr == "task"
                and len(test.ops) == 1
                and isinstance(test.ops[0], ast.NotEq)
                and len(test.comparators) == 1
                and isinstance(test.comparators[0], ast.Constant)
                and test.comparators[0].value == "continuous"
                and any(isinstance(child, ast.Return) for child in ast.walk(statement))
            ):
                guard_index = index
                break
        if guard_index is None or guard_index == len(function.body) - 1:
            raise pytest.UsageError("C50 coverage removal could not preserve the noncontinuous guard")
        fallback = ast.Return(
            value=ast.Tuple(
                elts=[
                    ast.Constant(value="evaluated"),
                    ast.Constant(value=1),
                    ast.Constant(value=None),
                ],
                ctx=ast.Load(),
            )
        )
        function.body = [*function.body[: guard_index + 1], fallback]
        rewrite_count = 1
        description = (
            "After preserving the noncontinuous guard, replace only the report-owned "
            "continuous inventory/curve reconciliation with ('evaluated', 1, None)."
        )

    elif mode == "origin_cap":
        for node in ast.walk(function):
            if not isinstance(node, ast.If):
                continue
            test = node.test
            has_continuous_test = (
                isinstance(test, ast.Compare)
                and isinstance(test.left, ast.Attribute)
                and isinstance(test.left.value, ast.Name)
                and test.left.value.id == "self"
                and test.left.attr == "task"
                and len(test.ops) == 1
                and isinstance(test.ops[0], ast.Eq)
                and len(test.comparators) == 1
                and isinstance(test.comparators[0], ast.Constant)
                and test.comparators[0].value == "continuous"
            )
            if has_continuous_test and any(
                isinstance(child, ast.Constant)
                and child.value == "measurement_source_not_established"
                for child in ast.walk(node)
            ):
                node.body = [ast.copy_location(ast.Pass(), node)]
                rewrite_count += 1
        if rewrite_count != 1:
            raise pytest.UsageError("C50 origin control did not find the unique source-origin cap")
        description = (
            "Remove only the continuous runtime-tier downgrade/reason branch; preserve "
            "candidate_numeric_tier and measurement_source_assurance diagnostics."
        )

    elif mode == "typed_report_precedence":
        for node in ast.walk(function):
            if not isinstance(node, ast.If) or not (
                isinstance(node.test, ast.Name) and node.test.id == "typed_receipts"
            ):
                continue
            returns_min = any(
                isinstance(child, ast.Return)
                and isinstance(child.value, ast.Call)
                and isinstance(child.value.func, ast.Name)
                and child.value.func.id == "min"
                for child in ast.walk(node)
            )
            if returns_min:
                node.test = ast.copy_location(ast.Constant(value=False), node.test)
                rewrite_count += 1
        if rewrite_count != 1:
            raise pytest.UsageError("C50 extractor control did not find its typed precedence branch")
        description = "Disable only the typed-continuous-report precedence branch in the real extractor."

    elif mode == "dispatch_sidecar_merge":
        for node in ast.walk(function):
            if not isinstance(node, ast.Assign):
                continue
            if not any(isinstance(target_node, ast.Name) and target_node.id == "truthfulness_receipt" for target_node in node.targets):
                continue
            call = node.value
            if not isinstance(call, ast.Call) or not (
                isinstance(call.func, ast.Name)
                and call.func.id == "extract_truthfulness_receipt"
                and len(call.args) == 1
                and isinstance(call.args[0], ast.Dict)
            ):
                continue
            argument = call.args[0]
            keys = [key.value for key in argument.keys if isinstance(key, ast.Constant)]
            values = argument.values
            if keys != ["artifacts", "output"] or not any(
                isinstance(value, ast.Attribute)
                and isinstance(value.value, ast.Name)
                and value.value.id == "result"
                and value.attr == "output"
                for value in values
            ):
                continue
            call.args[0] = ast.copy_location(ast.Name(id="merged_artifacts", ctx=ast.Load()), argument)
            rewrite_count += 1
        if rewrite_count != 1:
            raise pytest.UsageError("C50 dispatch control did not find the output-vs-sidecar reconciliation call")
        description = "Make the second receipt selection inspect merged artifacts only, dropping typed output precedence."

    elif mode == "duplicate_levels":
        for node in ast.walk(function):
            if not isinstance(node, ast.If):
                continue
            test = node.test
            exact_unique_check = (
                isinstance(test, ast.Compare)
                and isinstance(test.left, ast.Call)
                and isinstance(test.left.func, ast.Name)
                and test.left.func.id == "len"
                and len(test.left.args) == 1
                and isinstance(test.left.args[0], ast.Call)
                and isinstance(test.left.args[0].func, ast.Name)
                and test.left.args[0].func.id == "set"
                and len(test.left.args[0].args) == 1
                and isinstance(test.left.args[0].args[0], ast.Name)
                and test.left.args[0].args[0].id == "level_values"
                and len(test.ops) == 1
                and isinstance(test.ops[0], ast.NotEq)
                and len(test.comparators) == 1
                and isinstance(test.comparators[0], ast.Call)
                and isinstance(test.comparators[0].func, ast.Name)
                and test.comparators[0].func.id == "len"
                and len(test.comparators[0].args) == 1
                and isinstance(test.comparators[0].args[0], ast.Name)
                and test.comparators[0].args[0].id == "level_values"
            )
            raises_unique = any(
                isinstance(child, ast.Raise)
                and isinstance(child.exc, ast.Call)
                and any(
                    isinstance(part, ast.Constant)
                    and isinstance(part.value, str)
                    and "unique" in part.value
                    for part in ast.walk(child.exc)
                )
                for child in ast.walk(node)
            )
            if exact_unique_check and raises_unique:
                node.test = ast.copy_location(ast.Constant(value=False), node.test)
                rewrite_count += 1
        if rewrite_count != 1:
            raise pytest.UsageError("C50 producer control did not find the unique level guard")
        description = "Disable only duplicate requested-level rejection in the real interval-set producer."

    elif mode == "severity_status":
        for node in ast.walk(function):
            if not isinstance(node, ast.If):
                continue
            test = node.test
            assigns_verdict_fields = any(
                isinstance(child, ast.Assign)
                and any(
                    isinstance(target_node, ast.Name) and target_node.id == "verdict_fields"
                    for target_node in child.targets
                )
                for child in node.body
            )
            is_error_branch = (
                isinstance(test, ast.Name)
                and test.id == "error_count"
                and assigns_verdict_fields
            )
            is_continuous_branch = (
                isinstance(test, ast.Compare)
                and isinstance(test.left, ast.Attribute)
                and isinstance(test.left.value, ast.Name)
                and test.left.value.id == "diagnostics"
                and test.left.attr == "task"
                and len(test.ops) == 1
                and isinstance(test.ops[0], ast.Eq)
                and len(test.comparators) == 1
                and isinstance(test.comparators[0], ast.Constant)
                and test.comparators[0].value == "continuous"
                and assigns_verdict_fields
            )
            if is_error_branch or is_continuous_branch:
                node.test = ast.copy_location(ast.Constant(value=False), node.test)
                rewrite_count += 1
        if rewrite_count != 2:
            raise pytest.UsageError("C50 status control did not find both error/continuous verdict branches")
        description = "Disable only the fatal-error and continuous-blocked verdict/readiness assignments."

    elif mode == "warning_suppression":
        for node in ast.walk(function):
            if not isinstance(node, ast.Assign):
                continue
            if not any(isinstance(target_node, ast.Name) and target_node.id == "existing_codes" for target_node in node.targets):
                continue
            value = node.value
            if not isinstance(value, ast.SetComp):
                continue
            ifs = value.generators[0].ifs if len(value.generators) == 1 else []
            exact_error_filter = len(ifs) == 1 and any(
                isinstance(child, ast.Compare)
                and isinstance(child.left, ast.Attribute)
                and child.left.attr == "value"
                and len(child.ops) == 1
                and isinstance(child.ops[0], ast.Eq)
                and len(child.comparators) == 1
                and isinstance(child.comparators[0], ast.Constant)
                and child.comparators[0].value == "error"
                for child in ast.walk(ifs[0])
            )
            if exact_error_filter:
                value.generators[0].ifs = []
                rewrite_count += 1
        if rewrite_count != 1:
            raise pytest.UsageError("C50 warning control did not find the severity-qualified code set")
        description = "Let warning issue codes enter the suppression set used for recomputed errors."

    else:
        raise pytest.UsageError(f"C50 unknown control mode: {mode}")

    ast.fix_missing_locations(parsed)
    active_source = ast.unparse(parsed) + "\n"
    code = compile(active_source, "<c50-active-control>", "exec")
    namespace = dict(vars(module))
    exec(code, namespace)  # noqa: S102 - the exact in-memory source is pinned and hashed above.
    active = namespace[target]
    if not callable(active):
        raise pytest.UsageError(f"C50 active control is not callable: {target}")
    code_sha = _sha(marshal.dumps(active.__code__))
    return active, active_source, code_sha, rewrite_count, description


def _install(module: ModuleType | type, attribute: str, active: Callable[..., Any]) -> Callable[..., Any]:
    current = getattr(module, attribute)
    if not callable(current):
        raise pytest.UsageError(f"C50 target is not callable: {module}.{attribute}")
    if "original" not in _STATE:
        _STATE["original"] = current
    elif current not in {
        _STATE["original"],
        _STATE.get("active_callable"),
        _STATE.get("active"),
    }:
        raise pytest.UsageError(f"C50 alias mismatch before install: {module}.{attribute}")

    @functools.wraps(active)
    def counted(*args: Any, **kwargs: Any) -> Any:
        _STATE["active_calls"] += 1
        return active(*args, **kwargs)

    setattr(module, attribute, counted)
    _STATE["installations"].append((module, attribute, _STATE["original"], counted))
    return counted


def _load_target(mode: str) -> tuple[ModuleType | type, str, str]:
    if mode in {"coverage_reconciliation", "origin_cap"}:
        module = importlib.import_module("polisyos.ir.analytics.calibration_diagnostics")
        return module.CalibrationDiagnosticsReport, (
            "_interval_coverage_admission" if mode == "coverage_reconciliation" else "to_truthfulness_receipt"
        ), "src/polisyos/ir/analytics/calibration_diagnostics.py"
    if mode == "duplicate_levels":
        module = importlib.import_module("polisyos.calibration.diagnostics.continuous")
        return module, "_prepare_interval_sets", "src/polisyos/calibration/diagnostics/continuous.py"
    if mode == "typed_report_precedence":
        module = importlib.import_module("polisyos.ir.analytics._truthfulness")
        return module, "extract_truthfulness_receipt", "src/polisyos/ir/analytics/_truthfulness.py"
    if mode == "dispatch_sidecar_merge":
        module = importlib.import_module("polisyos.foundry.methods.backends.dispatch")
        return module, "_merge_dispatch_result", "src/polisyos/foundry/methods/backends/dispatch.py"
    if mode in {"severity_status", "warning_suppression"}:
        module = importlib.import_module("polisyos.calibration.diagnostics.adapters")
        return module, ("to_validation_report" if mode == "severity_status" else "_interval_admission_issues"), "src/polisyos/calibration/diagnostics/adapters.py"
    raise pytest.UsageError(f"C50 unknown control mode: {mode}")


def _install_aliases(mode: str, owner: ModuleType | type, target: str, active: Callable[..., Any]) -> None:
    primary = _install(owner, target, active)
    _STATE["active_callable"] = primary
    if mode == "typed_report_precedence":
        # The expected test postimage imports the real analytics facade. The
        # root polisyos.ir facade does not export this symbol and must not be
        # invented as a control alias.
        alias_module = importlib.import_module("polisyos.ir.analytics")
        alias = getattr(alias_module, target, None)
        if alias not in {_STATE["original"], primary, active}:
            raise pytest.UsageError("C50 analytics facade alias is not the pinned extractor owner")
        _install(alias_module, target, active)
    elif mode == "severity_status":
        package = importlib.import_module("polisyos.calibration")
        alias = getattr(package, target, None)
        if alias is not _STATE["original"]:
            raise pytest.UsageError("C50 calibration facade does not expose the pinned adapter function")
        _install(package, target, active)


def _read_source_pins(root: Path) -> dict[str, str]:
    found: dict[str, str] = {}
    for relative, expected in _SOURCE_PINS.items():
        path = root / relative
        if path.is_symlink() or not path.is_file():
            raise pytest.UsageError(f"C50 pinned input is not a regular file: {path}")
        actual = _sha(path.read_bytes())
        if actual != expected:
            raise pytest.UsageError(f"C50 pinned input bytes mismatch: {relative}")
        found[relative] = actual
    return found


def pytest_configure(config: pytest.Config) -> None:
    """Admit only the native project root and one exact source-bound control."""

    root = Path(config.rootpath).resolve(strict=True)
    if Path.cwd().resolve(strict=True) != root:
        raise pytest.UsageError("C50 controls require the D runner's actual policy-engine cwd")
    mode = _control_env("MODE")
    if mode not in _NODES:
        raise pytest.UsageError(f"C50 control mode is not admitted: {mode}")

    plugin_path = Path(__file__).resolve(strict=True)
    if Path(__file__).is_symlink():
        raise pytest.UsageError("C50 control plugin path cannot be a symlink")
    plugin_sha = _control_env("PLUGIN_SHA256")
    if _sha(plugin_path.read_bytes()) != plugin_sha:
        raise pytest.UsageError("C50 control plugin bytes mismatch")
    registered_plugin = config.pluginmanager.get_plugin("c50_removal_plugin")
    if registered_plugin is not sys.modules.get(__name__):
        raise pytest.UsageError("C50 control plugin was not explicitly loaded under its admitted name")
    pinset_sha = _sha(_canonical_json(_SOURCE_PINS))
    if _control_env("PINSET_SHA256") != pinset_sha:
        raise pytest.UsageError("C50 control source/test pinset binding mismatch")
    source_hashes = _read_source_pins(root)

    head = _git(root, "rev-parse", "HEAD")
    tree = _git(root, "rev-parse", "HEAD^{tree}")
    if head != _control_env("SOURCE_HEAD") or tree != _control_env("SOURCE_TREE"):
        raise pytest.UsageError("C50 control HEAD/tree differs from the root-bound native plan")
    source_frame_sha = _control_env("SOURCE_FRAME_SHA256")

    output_argument = Path(_control_env("OUTPUT"))
    readset_argument = Path(_required("POLISYOS_R4_INPUT_READSET_DIR"))
    if output_argument.is_symlink() or readset_argument.is_symlink():
        raise pytest.UsageError("C50 output/readset paths cannot be symlinks")
    output = output_argument.resolve(strict=True)
    readset_dir = readset_argument.resolve(strict=True)
    if output != readset_dir.parent:
        raise pytest.UsageError("C50 output must equal the admitted native D run directory")
    if output.is_symlink() or not output.is_dir():
        raise pytest.UsageError("C50 control output must be an existing non-symlink D directory")
    active_path = output / "c50-active-control.py"
    receipt_path = output / "c50-control-mutation.json"
    if active_path.exists() or receipt_path.exists():
        raise pytest.UsageError("C50 control outputs already exist")

    owner, target, source_path = _load_target(mode)
    owner_file = Path(owner.__file__).resolve(strict=True) if isinstance(owner, ModuleType) else Path(
        importlib.import_module("polisyos.ir.analytics.calibration_diagnostics").__file__
    ).resolve(strict=True)
    if owner_file != (root / source_path).resolve(strict=True):
        raise pytest.UsageError(f"C50 loaded owner path mismatch for {mode}")
    original = getattr(owner, target)
    active, active_source, active_code_sha, rewrite_count, description = _compile_active(
        owner if isinstance(owner, ModuleType) else importlib.import_module(
            "polisyos.ir.analytics.calibration_diagnostics"
        ),
        original,
        target,
        mode,
    )
    active_path.write_text(active_source, encoding="utf-8")

    _STATE.update(
        mode=mode,
        root=root,
        output=output,
        active_path=active_path,
        receipt_path=receipt_path,
        owner=owner,
        target=target,
        original=original,
        active=active,
        active_calls=0,
        installations=[],
        expected_nodes=list(_NODES[mode]),
        expected_failure=_EXPECTED_FAILURES[mode],
        reports=[],
        collection_nodes=None,
        collection_complete=False,
        source_hashes=source_hashes,
        head=head,
        tree=tree,
        plugin_sha=plugin_sha,
        active_source_sha=_sha(active_source.encode()),
        active_code_sha=active_code_sha,
        rewrite_count=rewrite_count,
        description=description,
        original_code_sha=_sha(marshal.dumps(original.__code__)),
        source_frame_sha=source_frame_sha,
        child_context={
            "cwd": str(Path.cwd().resolve(strict=True)),
            "sys_executable": sys.executable,
            "sys_argv": list(sys.argv),
            "pytest_version": pytest.__version__,
            "pytest_module_path": str(Path(_pytest.__file__).resolve(strict=True)),
            "pytest_plugins_env": os.environ.get("PYTEST_PLUGINS"),
            "pythonpath_env": os.environ.get("PYTHONPATH"),
            "readset_dir": str(readset_dir),
            "junitxml_arguments": [
                argument
                for argument in sys.argv
                if argument.startswith("--junitxml") or argument.startswith("--junit-xml")
            ],
        },
    )
    _STATE["receipt"] = {
        "mode": mode,
        "state": "RUNNING",
        "property_removed": description,
        "source_head": head,
        "source_tree": tree,
        "source_frame_sha256_supplied_by_root_plan": _STATE["source_frame_sha"],
        "source_frame_predicate_assurance": "institutionally_supplied_to_plugin; parent qualifier must resolve and verify it",
        "project_root": str(root),
        "owner_path": str(owner_file),
        "owner_source_sha256": source_hashes[source_path],
        "source_and_test_sha256": source_hashes,
        "source_test_pinset_sha256": pinset_sha,
        "plugin_path": str(plugin_path),
        "plugin_sha256": plugin_sha,
        "plugin_registration_name": "c50_removal_plugin",
        "plugin_registration_identity_verified": True,
        "original_function_code_sha256": _STATE["original_code_sha"],
        "active_function_source_path": str(active_path),
        "active_function_source_sha256": _STATE["active_source_sha"],
        "active_function_code_sha256": active_code_sha,
        "active_function_filename": active.__code__.co_filename,
        "rewrite_count": rewrite_count,
        "expected_nodeids": list(_NODES[mode]),
        "expected_semantic_failure": _EXPECTED_FAILURES[mode],
        "python": sys.version,
        "child_execution_context": _STATE["child_context"],
        "pytest_profile": "native policy-engine/pytest.ini via D runner; default plugin autoload and read-only observer retained",
        "product_source_writes": False,
        "limitations": [
            "A matched removal is not a fixed-source PASS or C50 acceptance.",
            "The generic untyped Mapping receipt route remains outside the typed-report control.",
            "The numeric producer is not executed by this plugin's static preparation; D runner execution remains separately authorized and UNRUN here.",
        ],
    }
    _install_aliases(mode, owner, target, active)
    _save(receipt_path, _STATE["receipt"])


def pytest_collection_finish(session: pytest.Session) -> None:
    """Reject any node selection besides the exact control quantity."""

    selected = [item.nodeid for item in session.items]
    _STATE["collection_nodes"] = selected
    if selected != _STATE["expected_nodes"]:
        raise pytest.UsageError(
            f"C50 control requires exact nodes {_STATE['expected_nodes']!r}; got {selected!r}"
        )
    if _STATE["mode"] in {"typed_report_precedence", "severity_status"}:
        item = session.items[0]
        alias = (
            "extract_truthfulness_receipt"
            if _STATE["mode"] == "typed_report_precedence"
            else "to_validation_report"
        )
        installed_aliases = {
            replacement
            for _module, attribute, _original, replacement in _STATE["installations"]
            if attribute == alias
        }
        if getattr(item.module, alias, None) not in installed_aliases:
            raise pytest.UsageError(f"C50 test imported a different callable than the active {alias}")
    _STATE["collection_complete"] = True
    _STATE["receipt"]["selected_nodeids"] = selected


def pytest_runtest_logreport(report: pytest.TestReport) -> None:
    """Retain phase, exact node, and failure text for behavioral classification."""

    if not _STATE:
        return
    longrepr = getattr(report, "longreprtext", "") or ""
    _STATE["reports"].append(
        {
            "nodeid": report.nodeid,
            "when": report.when,
            "outcome": report.outcome,
            "longreprtext": longrepr[-12000:] if longrepr else "",
        }
    )


def _classify() -> tuple[str, list[str]]:
    if not _STATE.get("collection_complete"):
        return "SETUP_ERROR_NOT_BEHAVIORAL", ["exact test collection was not completed"]
    failures = [row for row in _STATE["reports"] if row["outcome"] == "failed"]
    skipped = [row for row in _STATE["reports"] if row["outcome"] == "skipped"]
    if skipped:
        return "SKIP_NOT_BEHAVIORAL", [
            f"skip in {row['when']} phase for {row['nodeid']}" for row in skipped
        ]
    non_call_failures = [row for row in failures if row["when"] != "call"]
    if non_call_failures:
        return "SETUP_ERROR_NOT_BEHAVIORAL", [
            f"failure in {row['when']} phase for {row['nodeid']}" for row in non_call_failures
        ]
    expected = set(_STATE["expected_nodes"])
    call_reports = {
        row["nodeid"]: row
        for row in _STATE["reports"]
        if row["when"] == "call" and row["nodeid"] in expected
    }
    if set(call_reports) != expected:
        return "UNCLASSIFIED_FAILURE", ["one or more admitted target nodes did not reach call phase"]
    missing = []
    for nodeid, row in call_reports.items():
        if row["outcome"] != "failed":
            missing.append(f"target did not fail at call assertion: {nodeid}")
        if _STATE["expected_failure"]["assertion"] not in row["longreprtext"]:
            missing.append(f"expected semantic assertion marker absent: {nodeid}")
    if missing:
        return "UNCLASSIFIED_FAILURE", missing
    if _STATE.get("active_calls", 0) <= 0:
        return "UNCLASSIFIED_FAILURE", ["active mutated callable was not invoked"]
    return "EXPECTED_SEMANTIC_RED_UNQUALIFIED", [
        "Parent must bind child backend/profile, current source frame before/after, plugin and active-control bytes, exact selection, JUnit and D-runner stdout/stderr before treating this red as a qualified matched removal."
    ]


def pytest_sessionfinish(session: pytest.Session, exitstatus: int) -> None:
    """Restore all in-process aliases and verify exact source/test byte custody."""

    if not _STATE:
        return
    for module, attribute, original, replacement in reversed(_STATE["installations"]):
        if getattr(module, attribute) is not replacement:
            _STATE["receipt"].setdefault("restore_conflicts", []).append(
                f"{getattr(module, '__name__', module)}.{attribute} changed while control was active"
            )
        setattr(module, attribute, original)

    try:
        after_hashes = _read_source_pins(_STATE["root"])
    except (OSError, pytest.UsageError) as exc:
        after_hashes = {"readback_error": type(exc).__name__}
    try:
        final_head = _git(_STATE["root"], "rev-parse", "HEAD")
        final_tree = _git(_STATE["root"], "rev-parse", "HEAD^{tree}")
    except (OSError, subprocess.CalledProcessError) as exc:
        final_head = final_tree = f"readback-error:{type(exc).__name__}"
    restored = all(
        getattr(module, attribute) is original
        for module, attribute, original, _replacement in _STATE["installations"]
    )
    classification, reasons = _classify()
    if after_hashes != _STATE["source_hashes"]:
        classification = "UNCLASSIFIED_FAILURE"
        reasons.append("one or more pinned source/test files changed during the control")
    if final_head != _STATE["head"] or final_tree != _STATE["tree"]:
        classification = "UNCLASSIFIED_FAILURE"
        reasons.append("HEAD or tree changed during the control")
    if not restored:
        classification = "UNCLASSIFIED_FAILURE"
        reasons.append("in-process original callable restoration failed")

    _STATE["receipt"].update(
        {
            "state": classification,
            "classification_reasons": reasons,
            "pytest_exitstatus": int(exitstatus),
            "reports": _STATE["reports"],
            "active_callable_invocations": int(_STATE.get("active_calls", 0)),
            "source_and_test_sha256_after": after_hashes,
            "source_and_test_bytes_unchanged": after_hashes == _STATE["source_hashes"],
            "source_head_after": final_head,
            "source_tree_after": final_tree,
            "source_head_tree_unchanged": final_head == _STATE["head"] and final_tree == _STATE["tree"],
            "original_callable_restored_in_process": restored,
            "execution_qualification": "UNPREPARED",
            "execution_qualification_reason": "This plugin cannot authenticate the D runner's child backend/profile or independently bind the final JUnit/stdout/source-frame receipts; root-owned qualifier required.",
        }
    )
    _save(_STATE["receipt_path"], _STATE["receipt"])
    print(
        "C50_REMOVAL_CONTROL="
        + json.dumps(
            {
                "mode": _STATE["mode"],
                "state": classification,
                "active_calls": _STATE.get("active_calls", 0),
                "source_and_test_bytes_unchanged": after_hashes == _STATE["source_hashes"],
                "original_callable_restored_in_process": restored,
                "receipt_path": str(_STATE["receipt_path"]),
            },
            sort_keys=True,
        )
    )

