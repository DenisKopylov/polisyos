"""Freeze source bytes and read-only checks before the single bounded POST."""
from pathlib import Path
import ast, difflib, hashlib, json, subprocess, tomllib
P=Path(__file__).resolve().parent; R=P.parents[4]; C=P/'candidate'; product=R/'policy-engine'
expected='80e2bd118c40d97db1601fe58d8dd8ec165a5f67'; expected_tree='8e6edafc28569be011a9643d8d81f5fa97fc5e78'
def sha(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
assert git('rev-parse','HEAD')==expected and git('rev-parse','HEAD^{tree}')==expected_tree
assert git('symbolic-ref','--short','HEAD')=='codex/e02-unified-local-20261009'
rels=[Path('policy-engine/tools/quality/validation/decomposition_preflight.py'),Path('policy-engine/tests/repo_quality/architecture/test_decomposition_preflight_gates.py'),Path('policy-engine/tools/quality/validation/README.md'),Path('policy-engine/docs/reference/policy-design-case-failure-patterns.md'),Path('policy-engine/release-fragments/unreleased/2026-10-30-dynamic-scope-provenance.toml')]
records=[]; patch=[]
for rel in rels:
    target=R/rel; post=(C/rel).read_bytes(); exists=target.exists()
    if exists:
        pre=target.read_bytes(); assert subprocess.check_output(['git','show',f'{expected}:{rel}'],cwd=R)==pre
        blob=git('rev-parse',f'{expected}:{rel}'); old='a/'+str(rel)
        save=P/'preimages'/rel; save.parent.mkdir(parents=True,exist_ok=True); save.write_bytes(pre)
    else:
        assert not git('ls-tree',expected,str(rel)); pre=b''; blob=None; old='/dev/null'
    assert pre!=post
    patch.extend(difflib.unified_diff(pre.decode().splitlines(True),post.decode().splitlines(True),fromfile=old,tofile='b/'+str(rel)))
    if rel.suffix=='.py': ast.parse(post)
    if rel.suffix=='.toml': tomllib.loads(post.decode())
    records.append({'path':str(rel),'preimage_path':str(P/'preimages'/rel) if exists else None,'preimage_sha256':sha(pre) if exists else None,'preimage_git_blob':blob,'postimage_path':str(C/rel),'postimage_sha256':sha(post),'postimage_bytes':len(post)})
patchfile=P/'proposal.patch'; patchfile.write_text(''.join(patch))
checks=[]
def check(label, command, cwd, input_data=None):
    result=subprocess.run(command,cwd=cwd,input=input_data,capture_output=True)
    (P/(label+'.stdout.txt')).write_bytes(result.stdout); (P/(label+'.stderr.txt')).write_bytes(result.stderr)
    checks.append({'label':label,'command':command,'cwd':str(cwd),'exit_code':result.returncode,'stdout_sha256':sha(result.stdout),'stderr_sha256':sha(result.stderr)})
    assert result.returncode==0, checks[-1]
check('freeze-apply-check',['git','apply','--check',str(patchfile)],R)
for tag,rel in [('owner',rels[0]),('test',rels[1])]:
    logical=str(rel.relative_to('policy-engine'))
    check('freeze-ruff-'+tag,[str(product/'.venv/bin/python'),'-m','ruff','check','--no-cache','--config','ruff.toml','--stdin-filename',logical,'-'],product,(C/rel).read_bytes())
for tag,rel in [('owner',rels[0]),('test',rels[1])]:
    logical=str(rel.relative_to('policy-engine'))
    check('freeze-ruff-format-'+tag,[str(product/'.venv/bin/python'),'-m','ruff','format','--check','--no-cache','--config','ruff.toml','--stdin-filename',logical,'-'],product,(C/rel).read_bytes())
result={'schema':'raw-dynamic-r14-pre-freeze-v1','source':{'root':str(R),'head':expected,'tree':expected_tree,'branch':git('symbolic-ref','--short','HEAD')},'files':records,'patch_path':str(patchfile),'patch_sha256':sha(patchfile.read_bytes()),'runner_sha256':sha((P/'post_and_controls.py').read_bytes()),'supervisor_sha256':sha((P/'supervise_post_and_controls.py').read_bytes()),'pre_witness_sha256':sha((R/'LOCAL/raw/e02-execution-20261027/repairs/dynamic-native-compatibility-r12/pre-witness-r1.stdout.json').read_bytes()),'r13_manifest_sha256':sha((R/'LOCAL/raw/e02-execution-20261027/repairs/dynamic-native-compatibility-r13/manifest.json').read_bytes()),'canonical_composed_unit_sha256':sha((product/'tests/repo_quality/architecture/test_dynamic_code_reconstitution.py').read_bytes()),'r12_manifest_sha256':sha((R/'LOCAL/raw/e02-execution-20261027/repairs/dynamic-native-compatibility-r12/manifest.json').read_bytes()),'r11_manifest_sha256':sha((R/'LOCAL/raw/e02-execution-20261027/repairs/dynamic-native-compatibility-r11/manifest.json').read_bytes()),'registry_sha256':sha((product/'architecture/imports/dynamic.toml').read_bytes()),'checks':checks}
(P/'pre-freeze.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'head':expected,'patch_sha256':result['patch_sha256'],'owner_sha256':records[0]['postimage_sha256'],'test_sha256':records[1]['postimage_sha256'],'checks':[(row['label'],row['exit_code']) for row in checks]}))
