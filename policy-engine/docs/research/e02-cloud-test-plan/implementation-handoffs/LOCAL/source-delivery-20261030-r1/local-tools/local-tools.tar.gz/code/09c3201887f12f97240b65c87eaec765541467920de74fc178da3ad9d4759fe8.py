"""Read-only root admission for one prepared C07/C19 native plan; never run tests."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
PRODUCT = ROOT / 'policy-engine'
HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None


def require(condition, reason):
    if not condition:
        raise SystemExit('NOT ADMITTED: ' + reason)


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])


def main():
    require(len(sys.argv) == 2 and sys.argv[1] in ('c07', 'c19'), 'choose c07 or c19')
    m = json.loads((HERE / 'manifest.json').read_text())
    require(sha(Path(__file__)) == m['admit_sha256'], 'admission script mismatch')
    require(sha(HERE / 'readback.py') == m['readback_sha256'], 'readback script mismatch')
    item = m['plans'][sys.argv[1]]
    p = ROOT / item['path']
    require(sha(p) == item['sha256'], 'plan bytes differ')
    plan = json.loads(p.read_text())
    require(plan['case_id'] == item['case_id'], 'case ID differs')
    require(not (p.parent / plan['case_id']).exists(), 'output already exists; use a unique plan')
    require(git('symbolic-ref', '--short', 'HEAD').decode().strip() == m['branch'], 'branch differs')
    head = git('rev-parse', 'HEAD').decode().strip()
    tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
    require(head == plan['source_head'] and tree == plan['source_tree'],
            'plan HEAD/tree differs; make a new journal-bound plan, never move HEAD')
    require(not git('status', '--porcelain', '--untracked-files=no').strip(),
            'tracked or staged state changed')
    live = json.loads((ROOT / 'LOCAL/raw/root-live-ownership-20261021.json').read_text())
    require(live['branch'] == m['branch'] and live['head'] == head and live['tree'] == tree,
            'root ledger differs from actual state')
    idx = hashlib.sha256(git('diff', '--cached', '--raw', '--no-abbrev', '-z')).hexdigest()
    require(idx == live['expected_index']['raw_diff_sha256'], 'index differs from ledger')
    frame = live['source_readback']
    require(frame == plan['root_source_frame'], 'root frame differs from plan')
    fp = ROOT / frame['path']
    require(sha(fp) == frame['sha256'], 'root frame hash differs')
    frame_rows = json.loads(fp.read_text())['paths'] + live['known_dirty_paths']
    for row in frame_rows:
        require(sha(ROOT / row['path']) == row['sha256'], 'root-frame source changed: ' + row['path'])
    for path, expected in {**m['harness_bindings'], **item['reviewed_source_bindings'],
                           **item['review_bindings']}.items():
        require(sha(ROOT / path) == expected, 'pinned input changed: ' + path)
    for path, expected in item['reviewed_source_bindings'].items():
        blob = git('show', head + ':' + path)
        require(hashlib.sha256(blob).hexdigest() == expected, 'owner path differs from HEAD: ' + path)
    prior = item['prior']
    require(sha(ROOT / prior['audit_path']) == prior['audit_sha256'], 'prior audit changed')
    require(sha(ROOT / prior['readset_path']) == prior['readset_sha256'], 'prior readset changed')
    readset = json.loads((ROOT / prior['readset_path']).read_text())['modules']
    differences = []
    for row in readset:
        actual = sha(PRODUCT / row['path'])
        if actual != row['sha256']:
            differences.append({'path': row['path'], 'prior_sha256': row['sha256'],
                                'current_sha256': actual})
    free = shutil.disk_usage(ROOT).free
    require(free >= 8 * 1024**3, 'less than 8 GiB free; supervisor hard floor is 6 GiB')
    require((PRODUCT / '.venv/bin/python').is_file(), 'native interpreter unavailable')
    print(json.dumps({'admitted': True, 'case_id': plan['case_id'], 'head': head, 'tree': tree,
        'frame_path': frame['path'], 'frame_sha256': frame['sha256'],
        'reviewed_source_bindings': item['reviewed_source_bindings'],
        'prior_readset_denominator': len(readset), 'prior_readset_differences': differences,
        'prior_pass_transfer_condition_met': differences == item['expected_prior_differences'],
        'prior_pass_scope': 'Only original prior source and outcome; no rerun claimed. A false transfer condition does not block this new run.',
        'disk_free_bytes': free, 'rss_cap_bytes': plan['rss_cap_bytes'],
        'deadline_seconds': plan['deadline_seconds'],
        'operator_must_admit': 'Wait until C50/other contended native work is finished and obtain an isolated compute slot. Keep tracked source, index, refs, ledger and harness stable throughout the run.',
        'launch_command': item['launch_command'], 'launch_command_sha256': item['launch_command_sha256'],
        'runtime_executed': False, 'closure_ids': []}, indent=2))


if __name__ == '__main__':
    main()
