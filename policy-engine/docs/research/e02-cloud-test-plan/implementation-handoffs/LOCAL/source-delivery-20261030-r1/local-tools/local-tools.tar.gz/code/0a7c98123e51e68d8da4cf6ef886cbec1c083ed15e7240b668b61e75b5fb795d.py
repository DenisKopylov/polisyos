"""Reconcile actual bounded C32 evidence; never infer semantic red from exit alone."""
from __future__ import annotations
import argparse, hashlib, json, xml.etree.ElementTree as ET
from pathlib import Path
R=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos');P=R/'policy-engine';HERE=Path(__file__).resolve().parent
D=P/'docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1'
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_text())
def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('--plan',type=Path,required=True);a.add_argument('--plan-sha256',required=True);a.add_argument('--receipt',type=Path,required=True);x=a.parse_args();errors=[];plan=load(x.plan);out=D/plan['case_id'];assert sha(x.plan.read_bytes())==x.plan_sha256
 audit=load(out/'audit-result.json');freeze=load(out/'source-profile-freeze.json');w=load(out/'c32-witness.json');result=audit['result']
 if audit['plan']!=plan or freeze['plan_sha256']!=x.plan_sha256 or sha((out/'source-profile-freeze.json').read_bytes())!=audit['source_profile_freeze_sha256']:errors.append('plan/freeze/audit differ')
 if freeze['before']['head']!=plan['source_head'] or audit['guard_after']['head']!=plan['source_head'] or audit['current_mismatches']:errors.append('source/readset changed during actual run')
 if not result['complete'] or result['aborted_reason'] is not None:errors.append('incomplete/resource-aborted run')
 junit=list(ET.parse(out/'pytest.xml').iter('testcase'));counts={'tests':len(junit),'failures':sum(t.find('failure') is not None for t in junit),'errors':sum(t.find('error') is not None for t in junit),'skipped':sum(t.find('skipped') is not None for t in junit)}
 if result['junit']!=counts:errors.append('JUnit audit mismatch')
 selected=w['selected'];calls=[r for r in w['reports'] if r['when']=='call']
 if not selected or w['deselected'] or sorted(w['early'])!=sorted(selected) or len(set(selected))!=len(selected) or sorted(r['node'] for r in calls)!=sorted(selected):errors.append('collection/execution mismatch or deselection')
 if len(calls)!=counts['tests'] or any(r['when']!='call' and r['outcome']!='passed' for r in w['reports']):errors.append('setup/teardown error is not semantic evidence')
 for n in selected:
  if not any(n==v or n.startswith(v+'[') or ('::' not in v and n.startswith(v+'::')) for v in plan['nodes']):errors.append('unexpected selected node '+n)
 if w['plan_sha256']!=x.plan_sha256 or w['plugin_sha256']!=plan['extra_env']['C32_PLUGIN_SHA256']:errors.append('plugin/plan witness mismatch')
 profiles={r['node']:r['profile'] for r in w['profiles']}
 if set(profiles)!=set(selected) or any(not p['duckdb_version'] for p in profiles.values()):errors.append('actual child backend/profile missing')
 phase=plan['control_phase'];mode=plan['control_mode'];failure_reports=[r for r in calls if r['outcome']=='failed']
 if phase!='mutant':
  if result['return_code']!=0 or counts['failures'] or counts['errors'] or counts['skipped'] or any(r['outcome']!='passed' for r in calls):errors.append('positive is not all-pass without skips/errors')
 else:
  c=plan['control_hypothesis'];expected_fails={'empty_subtype':2,'capture_forward':3,'acquisition_adapter':6,'n7_mapping':3,'fabric_family':4,'graph_binding':3,'postread':1,'wal':2}[mode]
  if result['return_code']!=1 or counts!={'tests':c['literal_cases'],'failures':expected_fails,'errors':0,'skipped':0}:errors.append('mutant JUnit differs from exact semantic hypothesis')
  if any(c['expected_assertion'] not in (r['longrepr'] or '') for r in failure_reports):errors.append('wrong failure assertion; needs diagnosis, never exit-only qualification')
  if mode=='capture_forward' and any('persisted_capture' not in r['node'] for r in failure_reports):errors.append('capture forwarding failed outside persisted branch')
  if any(not r['restored_in_process'] or sum(r['active_entries'].values())<=0 for r in w['restored']):errors.append('mutated callable entry/restoration missing')
  if len(w['restored'])!=len(selected):errors.append('missing per-case active-code witnesses')
 observed={};evidence=[]
 for record in w['restored']:
  for mutation in record['mutations']:
   p=Path(mutation['active_source_path'])
   if not p.is_relative_to(out) or sha(p.read_bytes())!=mutation['active_source_sha256']:errors.append('active source bytes mismatch')
   row={'path':str(p.relative_to(R)),'sha256':sha(p.read_bytes())}
   if row not in evidence:evidence.append(row)

 for row in audit['readsets']:
  p=R/row['path'];assert sha(p.read_bytes())==row['sha256']
  for q in load(p)['modules']:
   if q['path'] in observed and observed[q['path']]!=q['sha256']:errors.append('conflicting imported input '+q['path'])
   observed[q['path']]=q['sha256']
   if sha((P/q['path']).read_bytes())!=q['sha256']:errors.append('observed module changed '+q['path'])
  evidence.append({'path':row['path'],'sha256':row['sha256']})
 if not observed:errors.append('actual loaded module denominator missing')
 for p,pin in plan['c32_binding']['committed_inputs'].items():
  if sha((R/p).read_bytes())!=pin['sha256']:errors.append('explicit committed input changed '+p)
 for prior in plan['prior_qualified_receipts']:
  receipt=load(Path(prior['path']))
  for e in receipt['evidence']:
   if sha((R/e['path']).read_bytes())!=e['sha256']:errors.append('prior deciding bytes unavailable')
  if profiles!=prior['actual_child_profiles'] or selected!=prior['selected_nodeids'] or observed!=prior['observed_module_pins']:errors.append('matched phase profile/selected/readset mismatch')
 # Retain bytes; no stdout/JSON embedding or copies of repository sources/environments.
 for n in ['audit-result.json','source-profile-freeze.json','c32-witness.json','pytest.xml',result['stdout'],result['stderr']]:
  p=out/n
  if not p.is_file():errors.append('missing deciding output '+n)
  else:evidence.append({'path':str(p.relative_to(R)),'sha256':sha(p.read_bytes())})
 report={'schema':'policyos.c32.native_receipt.v1','qualification':'qualified' if not errors else 'UNQUALIFIED','errors':errors,'phase':phase,'mode':mode,'source_head':plan['source_head'],'source_tree':plan['source_tree'],'selected_nodeids':selected,'actual_child_profiles':profiles,'committed_input_sha256':{p:v['sha256'] for p,v in load(HERE/'source-bindings.json')['inputs'].items()},'observed_module_pins':observed,'counts':counts,'resources':{'wall_seconds':result['wall_seconds'],'peak_process_tree_rss_bytes':result['max_sampled_process_tree_rss_bytes']},'evidence':evidence,'scope':'Finite actual imported readset, default native pytest, selected Catalog consumers only. Matched mutant requires independent semantic review before restoration. Not ordinary N7/V4/V7, authority/currentness, atomic custody, G acceptance or closure.','closure_ids':[]}
 with x.receipt.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
 print(json.dumps({'receipt':str(x.receipt),'sha256':sha(x.receipt.read_bytes()),'qualification':report['qualification'],'errors':errors}));raise SystemExit(0 if not errors else 125)
if __name__=='__main__':main()
