"""Complete tracked-file literal census over an immutable Git tree plus sparse overlay."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
ROOT=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
OUT=Path(__file__).resolve().parent
POST=OUT/'postimages'
BASE='545c6990e2bfa42bf580b475e23cf88df04e71d8'
CURRENT=json.loads((OUT/'manifest.json').read_text())['current_root_head']
pattern=re.compile(r'\b(?:CalibrationExecutionInputBasis|CalibrationOrderedBatchInput|CalibrationOrderedBatchReport|CalibrationReport|CALIBRATION_RUNTIME_INPUT_NAMES(?:_V1_2)?|load_calibration_execution_input_basis|put_calibration_execution_input_basis|OrderedBatchCalibrationProfile|evaluate_ordered_batch_objective|apply_nodes_batch|replay_ordered_batch_report_projection|serialize_calibration_report_v1|CalibrationSourceRead|CalibrationSourceReadRefusal|CalibrationSourceStatus|classify_calibration_source_error|record_calibration_source_error|read_calibration_source|read_calibration_model_source|read_calibration_config_source|read_calibration_registry_source|read_calibration_report_source|read_calibration_execution_input_basis_source)\b')
def run_set(commit,prefix,suffix,query):
    paths={p for p in subprocess.check_output(['git','ls-tree','-r','--name-only',commit,'--',prefix],cwd=ROOT,text=True).splitlines() if p.endswith(suffix)}
    paths|={str(p.relative_to(POST)) for p in POST.rglob('*'+suffix) if str(p.relative_to(POST)).startswith(prefix)}
    proc=subprocess.Popen(['git','cat-file','--batch'],cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
    hasher=hashlib.sha256();hits=[]
    for path in sorted(paths):
        selected=POST/path
        if selected.exists(): data=selected.read_bytes()
        else:
            proc.stdin.write((commit+':'+path+'\n').encode());proc.stdin.flush()
            header=proc.stdout.readline().split();assert len(header)==3,header
            data=proc.stdout.read(int(header[2]));assert proc.stdout.read(1)==b'\n'
        hasher.update((path+'\0'+hashlib.sha256(data).hexdigest()+'\n').encode())
        lines=[]
        for number,line in enumerate(data.decode().splitlines(),1):
            found=sorted({m.group(0) for m in query.finditer(line)})
            if found:lines.append({'line':number,'symbols':found})
        if lines:hits.append({'path':path,'sha256':hashlib.sha256(data).hexdigest(),'hits':lines})
    proc.stdin.close();proc.wait();assert proc.returncode==0
    return {'commit':commit,'prefix':prefix,'suffix':suffix,'denominator':'all tracked matching files plus selected new postimages','files':len(paths),'source_set_sha256':hasher.hexdigest(),'matching_files':len(hits),'matching_lines':sum(len(row['hits']) for row in hits),'matches':hits}
sets=[]
for commit in [BASE,CURRENT]:
    for prefix in ['policy-engine/src/','policy-engine/tests/']:
        sets.append(run_set(commit,prefix,'.py',pattern))
surface_pattern=re.compile(r'CalibrationReport|CalibrationExecutionInputBasis|CalibrationOrderedBatchInput|CalibrationOrderedBatchReport|calibration_execution_input_basis|calibration_ordered_input')
for prefix,suffix in [('policy-engine/schemas/','.json'),('policy-engine/tools/','.py')]:
    sets.append(run_set(CURRENT,prefix,suffix,surface_pattern))
(OUT/'source-census.json').write_text(json.dumps({'query':pattern.pattern,'surface_query':surface_pattern.pattern,'sets':sets,'limits':['Literal static census over complete stated file-type sets only. No dynamic/nonliteral/other-language consumer absence claim.','Selected source denominator is reproducible from Git plus this exact sparse overlay; this is not runtime loaded-source qualification.','No product imports, global disk scan, production payload reads or environment changes.']},indent=2)+'\n')
print(json.dumps([{key:row[key] for key in ['commit','prefix','suffix','files','source_set_sha256','matching_files','matching_lines']} for row in sets]))
