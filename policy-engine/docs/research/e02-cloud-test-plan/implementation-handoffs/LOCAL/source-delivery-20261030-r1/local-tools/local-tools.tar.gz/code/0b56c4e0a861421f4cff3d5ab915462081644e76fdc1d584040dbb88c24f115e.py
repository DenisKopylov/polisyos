"""Capture first-party Python origins only in the exact R1 driver and commissioned spawned producer.

Loaded as sitecustomize by the native pytest process and its multiprocessing
spawn child through an isolated PYTHONPATH entry. The driver records at normal
interpreter exit. The child records immediately before the test's intentional
os._exit(73); the original exit code is preserved. This is a test harness
observer, not a product module or runtime capability.
"""
from __future__ import annotations

import atexit
import json
import os
import sys

_ORIGINAL_EXIT = os._exit
_ARGV_AT_SITE_STARTUP = tuple(sys.argv)
_IS_MULTIPROCESSING_CHILD = "--multiprocessing-fork" in _ARGV_AT_SITE_STARTUP
_EXPECTED_LAUNCHER = os.environ.get("POLISYOS_R1_EXPECTED_LAUNCHER")

def _same_path(left: str, right: str) -> bool:
    try:
        return os.path.normcase(os.path.abspath(left)) == os.path.normcase(os.path.abspath(right))
    except (OSError, ValueError):
        return False

_DRIVER_ARGV_MATCH = bool(
    _ARGV_AT_SITE_STARTUP
    and _EXPECTED_LAUNCHER
    and _same_path(_ARGV_AT_SITE_STARTUP[0], _EXPECTED_LAUNCHER)
)


def _claim_exact_driver_pid() -> str | None:
    """Freeze one driver PID with an exclusive claim bound to its startup argv."""
    if not _DRIVER_ARGV_MATCH or _IS_MULTIPROCESSING_CHILD:
        return None
    output_root = os.environ.get("POLISYOS_R1_READSET_DIR")
    if not output_root:
        return None
    path = os.path.join(output_root, "exact-driver-pid.json")
    record = {
        "schema": "polisyos.e02.r1.exact_driver_pid_claim.v1",
        "pid": os.getpid(),
        "ppid": os.getppid(),
        "argv_at_sitecustomize_startup": list(_ARGV_AT_SITE_STARTUP),
        "expected_launcher_path": _EXPECTED_LAUNCHER,
        "argv_path_match": _DRIVER_ARGV_MATCH,
        "spawn_marker_present_at_sitecustomize_startup": _IS_MULTIPROCESSING_CHILD,
    }
    payload = (json.dumps(record, sort_keys=True) + "\n").encode()
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
    try:
        fd = os.open(path, flags, 0o600)
    except FileExistsError:
        return None
    try:
        view = memoryview(payload)
        while view:
            written = os.write(fd, view)
            if written <= 0:
                raise OSError("r1_driver_claim_short_write")
            view = view[written:]
        os.fsync(fd)
    finally:
        os.close(fd)
    return path


_DRIVER_CLAIM_PATH = _claim_exact_driver_pid()
_IS_PYTEST_DRIVER = _DRIVER_CLAIM_PATH is not None


def _trace_startup_role() -> None:
    """Emit an opt-in conformance trace; production case runs leave it disabled."""
    trace_root = os.environ.get("POLISYOS_R1_ROLE_TRACE_DIR")
    if not trace_root:
        return
    payload = {
        "pid": os.getpid(),
        "ppid": os.getppid(),
        "process_role": (
            "pytest_driver" if _IS_PYTEST_DRIVER else
            "multiprocessing_spawn_child" if _IS_MULTIPROCESSING_CHILD else
            "auxiliary_or_unclassified"
        ),
        "argv_at_sitecustomize_startup": list(_ARGV_AT_SITE_STARTUP),
        "spawn_marker_present_at_sitecustomize_startup": _IS_MULTIPROCESSING_CHILD,
        "expected_launcher_path": _EXPECTED_LAUNCHER,
        "driver_argv_path_match": _DRIVER_ARGV_MATCH,
        "driver_claim_path": _DRIVER_CLAIM_PATH,
    }
    path = os.path.join(trace_root, f"startup-role-{os.getpid()}.json")
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(path, flags, 0o600)
    try:
        payload_bytes = (json.dumps(payload, sort_keys=True) + "\n").encode()
        view = memoryview(payload_bytes)
        while view:
            written = os.write(fd, view)
            if written <= 0:
                raise OSError("r1_startup_role_short_write")
            view = view[written:]
        os.fsync(fd)
    finally:
        os.close(fd)


_trace_startup_role()


def _is_under(path: str, root: str) -> bool:
    try:
        return os.path.commonpath((path, root)) == root
    except (OSError, ValueError):
        return False


def _record_origins(phase: str, filename: str, exit_code: int | None = None) -> None:
    """Write loaded module origins without hashing or touching product inputs."""
    output_root = os.environ.get("POLISYOS_R1_READSET_DIR")
    project_root = os.environ.get("POLISYOS_R1_PROJECT_ROOT")
    if not output_root or not project_root:
        raise RuntimeError("r1_readset_roots_missing")
    project_root = os.path.realpath(project_root)
    records: dict[str, dict[str, object]] = {}
    for module_name, module in tuple(sys.modules.items()):
        raw_origin = getattr(module, "__file__", None)
        if not isinstance(raw_origin, str) or not raw_origin:
            continue
        origin = os.path.realpath(raw_origin)
        in_project = _is_under(origin, project_root)
        relative = os.path.relpath(origin, project_root) if in_project else None
        first_party_name = (
            module_name == "polisyos"
            or module_name.startswith("polisyos.")
            or module_name == "tests"
            or module_name.startswith("tests.")
            or module_name == "tools"
            or module_name.startswith("tools.")
        )
        first_party_path = bool(
            relative
            and (
                relative.startswith("src/polisyos/")
                or relative.startswith("tests/")
                or relative.startswith("tools/")
            )
        )
        if not (first_party_name or first_party_path):
            continue
        row = records.setdefault(
            origin,
            {
                "origin_path": origin,
                "project_relative_path": relative,
                "inside_project": in_project,
                "module_names": [],
            },
        )
        names = row["module_names"]
        assert isinstance(names, list)
        names.append(module_name)
    modules = []
    for origin in sorted(records):
        row = records[origin]
        row["module_names"] = sorted(set(row["module_names"]))
        modules.append(row)
    record = {
        "schema": "polisyos.e02.r1.loaded_module_origins.v1",
        "capture_status": "complete",
        "phase": phase,
        "event_exit_code": exit_code,
        "pid": os.getpid(),
        "ppid": os.getppid(),
        "python_executable": sys.executable,
        "python_version": sys.version,
        "cwd": os.getcwd(),
        "argv_at_capture": sys.argv,
        "argv_at_sitecustomize_startup": list(_ARGV_AT_SITE_STARTUP),
        "spawn_marker_present_at_sitecustomize_startup": _IS_MULTIPROCESSING_CHILD,
        "expected_launcher_path": _EXPECTED_LAUNCHER,
        "driver_argv_path_match": _DRIVER_ARGV_MATCH,
        "driver_claim_path": _DRIVER_CLAIM_PATH,
        "process_role": (
            "pytest_driver" if _IS_PYTEST_DRIVER else
            "multiprocessing_spawn_child" if _IS_MULTIPROCESSING_CHILD else
            "auxiliary_or_unclassified"
        ),
        "project_root": project_root,
        "sys_path": sys.path,
        "module_origin_count": len(modules),
        "modules": modules,
        "hashes": "not computed by the observer; host reconciles exact bytes after process exit",
    }
    payload = (json.dumps(record, sort_keys=True, ensure_ascii=False) + "\n").encode()
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
    path = os.path.join(output_root, filename.format(pid=os.getpid()))
    fd = os.open(path, flags, 0o600)
    try:
        view = memoryview(payload)
        while view:
            written = os.write(fd, view)
            if written <= 0:
                raise OSError("r1_child_readset_short_write")
            view = view[written:]
        os.fsync(fd)
    finally:
        os.close(fd)


def _capture_then_exit(exit_code: int) -> None:
    """Capture only the commissioned child exit and always preserve its code."""
    if exit_code == 73 and _IS_MULTIPROCESSING_CHILD:
        try:
            _record_origins(
                "multiprocessing_spawn_child_before_intentional_exit",
                "spawned-child-{pid}.json",
                exit_code,
            )
        except BaseException as exc:
            error_root = os.environ.get("POLISYOS_R1_READSET_DIR")
            if error_root:
                error = {
                    "schema": "polisyos.e02.r1.spawned_child_readset_error.v1",
                    "capture_status": "error",
                    "pid": os.getpid(),
                    "error_type": type(exc).__name__,
                    "error": str(exc)[:500],
                }
                try:
                    path = os.path.join(error_root, f"readset-error-{os.getpid()}.json")
                    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
                    fd = os.open(path, flags, 0o600)
                    try:
                        os.write(fd, (json.dumps(error, sort_keys=True) + "\n").encode())
                        os.fsync(fd)
                    finally:
                        os.close(fd)
                except BaseException:
                    pass
    _ORIGINAL_EXIT(exit_code)


os._exit = _capture_then_exit


def _record_driver_origins_at_exit() -> None:
    """Record only the exact commissioned launcher at normal interpreter exit."""
    if not _IS_PYTEST_DRIVER:
        return
    try:
        _record_origins(
            "pytest_driver_at_interpreter_exit",
            "input-readset-{pid}.json",
        )
    except BaseException as exc:
        error_root = os.environ.get("POLISYOS_R1_READSET_DIR")
        if error_root:
            error = {
                "schema": "polisyos.e02.r1.driver_readset_error.v1",
                "capture_status": "error",
                "pid": os.getpid(),
                "error_type": type(exc).__name__,
                "error": str(exc)[:500],
            }
            try:
                path = os.path.join(error_root, f"readset-error-driver-{os.getpid()}.json")
                flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
                fd = os.open(path, flags, 0o600)
                try:
                    os.write(fd, (json.dumps(error, sort_keys=True) + "\n").encode())
                    os.fsync(fd)
                finally:
                    os.close(fd)
            except BaseException:
                pass


if _IS_PYTEST_DRIVER:
    atexit.register(_record_driver_origins_at_exit)
