"""Read-only just-in-time identity/resource admission for a prepared native plan."""
from __future__ import annotations
import argparse
import hashlib
import json
import runpy
import shutil
import subprocess
from pathlib import Path

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
PRODUCT = ROOT/'policy-engine'
D = PRODUCT/'docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1'
LAYER=D.parent/'root-layer-lib.py'


def sha(path: Path) -> str:
 return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args: str) -> str:
 return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()


def main() -> None:
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--plan',type=Path,required=True);args=parser.parse_args()
 path=args.plan
 if not path.is_absolute() or path.parent!=D or not path.is_file() or path.is_symlink():
  raise SystemExit('Plan must be a regular absolute file in retained D')
 plan=json.loads(path.read_text());case=plan['case_id']
 if (D/case).exists() or (D/case).is_symlink():
  raise SystemExit('Native output already exists; issue a unique plan')
 head,tree=git('rev-parse','HEAD'),git('rev-parse','HEAD^{tree}')
 if (head,tree)!=(plan['source_head'],plan['source_tree']):
  raise SystemExit(f'Stale plan: actual {head}/{tree}; rebind explicitly')
 if git('symbolic-ref','--short','HEAD')!='codex/e02-unified-local-20261009' or git('status','--porcelain=v1','--untracked-files=no'):
  raise SystemExit('Branch/clean tracked state admission failed')
 guard=runpy.run_path(str(LAYER))['guard']()
 if guard['head']!=head or guard['source_frame']!=plan['source_frame_binding']:
  raise SystemExit('Root native source frame differs from plan')
 for pin in plan['source_bindings']:
  source=ROOT/pin['path']
  if source.is_symlink() or not source.is_file() or sha(source)!=pin['sha256']:
   raise SystemExit('Bound source changed or missing: '+pin['path'])
  if git('rev-parse',head+':'+pin['path'])!=pin['git_blob']:
   raise SystemExit('Git blob differs: '+pin['path'])
 for relative,digest in plan['runner_bindings'].items():
  p=ROOT/relative
  if not p.is_file() or sha(p)!=digest: raise SystemExit('Native runner/profile changed: '+relative)
 manifest=plan['reviewed_original_manifest']; mp=ROOT/manifest['path']
 if sha(mp)!=manifest['sha256']: raise SystemExit('Reviewed original manifest changed')
 delta=plan.get('reviewed_c50_test_import_delta')
 if delta and (not (ROOT/delta['path']).is_file() or sha(ROOT/delta['path'])!=delta['sha256']):
  raise SystemExit('C50 separately reviewed test import delta changed')
 disk=shutil.disk_usage(ROOT).free
 if disk<8*1024**3: raise SystemExit(f'Disk below 8 GiB starting reserve: {disk} bytes; reassess')
 script="import importlib.metadata as m,json,platform,sys; names=['jax','jaxlib','numpy','scipy','pytest','pydantic','statsmodels']; versions={}; [(versions.__setitem__(n,m.version(n) if m.packages_distributions() is not None else None)) for n in []]; exec('for n in names:\\n try: versions[n]=m.version(n)\\n except m.PackageNotFoundError: versions[n]=None'); print(json.dumps({'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'distribution_versions':versions}))"
 proc=subprocess.run([str(PRODUCT/'.venv/bin/python'),'-B','-c',script],text=True,capture_output=True)
 if proc.returncode:
  raise SystemExit('Unable to read product environment metadata: '+proc.stderr[-1000:])
 try: hw=subprocess.check_output(['sysctl','-n','hw.memsize'],text=True).strip()
 except (OSError,subprocess.CalledProcessError): hw=None
 try: vm=subprocess.check_output(['vm_stat'],text=True).strip()
 except (OSError,subprocess.CalledProcessError): vm=None
 if git('rev-parse','HEAD')!=head or git('rev-parse','HEAD^{tree}')!=tree:
  raise SystemExit('Source moved during admission')
 print(json.dumps({'plan':str(path),'plan_sha256':sha(path),'source_head':head,'source_tree':tree,
       'source_frame':guard['source_frame'],'source_binding_count':len(plan['source_bindings']),
       'free_disk_bytes':disk,'physical_ram_bytes':int(hw) if hw else None,'vm_stat_raw':vm,
       'backend_distribution_metadata':json.loads(proc.stdout),'resource_note':'Available RAM, CPU load, numeric leases and any shared DB/port contention still require root interpretation; package metadata does not prove backend usability.',
       'output_path_absent':True,'native_tests_executed':False,'closure_ids':[]},indent=2))

if __name__=='__main__':main()
