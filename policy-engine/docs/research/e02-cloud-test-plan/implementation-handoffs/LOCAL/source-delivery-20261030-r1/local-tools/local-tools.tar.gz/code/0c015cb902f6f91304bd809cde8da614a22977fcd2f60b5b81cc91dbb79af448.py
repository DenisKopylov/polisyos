from pathlib import Path
P=Path.cwd()/'LOCAL/raw/e02-execution-20261027/repairs/C17/postimages/policy-engine'
def edit(rel,old,new):
 p=P/rel;s=p.read_text();assert s.count(old)==1,(rel,old[:100],s.count(old));p.write_text(s.replace(old,new))
edit('src/polisyos/lex/normpack/diff.py','from typing import Any\n','from typing import Any, ClassVar\n')
edit('src/polisyos/lex/normpack/diff.py','''    model_config = ConfigDict(extra="forbid")

    schema_version: str = "1.0"
    old_pack_id: str
''','''    model_config = ConfigDict(extra="forbid")

    ARTIFACT_KIND: ClassVar[str] = "lex.norm_diff"
    ARTIFACT_MEDIA_TYPE: ClassVar[str] = "application/json"
    ARTIFACT_SCHEMA_NAME: ClassVar[str] = "polisyos.lex.NormDiff"
    ARTIFACT_SCHEMA_VERSION: ClassVar[str] = "1.0"

    schema_version: str = "1.0"
    old_pack_id: str
''')
edit('src/polisyos/lex/legal_evaluation/impact_diff.py','from collections import defaultdict\n','from collections import defaultdict\nfrom dataclasses import dataclass\n')
edit('src/polisyos/lex/legal_evaluation/impact_diff.py','from typing import Any\n','from typing import Any, ClassVar, Literal\n')
edit('src/polisyos/lex/legal_evaluation/impact_diff.py','from pydantic import BaseModel, ConfigDict, Field\n','from pydantic import BaseModel, ConfigDict, Field, model_validator\n')
edit('src/polisyos/lex/legal_evaluation/impact_diff.py','''from polisyos.core.artifacts import FileSystemCAS, PutOptions, SchemaInfo
''','''from polisyos.core.artifacts import (
    ArtifactRef,
    FileSystemCAS,
    PutOptions,
    SchemaInfo,
    input_ref_from_artifact_ref,
    validate_core_model_json_artifact,
)
from polisyos.core.artifacts.ids import ArtifactID
''')
edit('src/polisyos/lex/legal_evaluation/impact_diff.py','''    schema_version: str = "1.0"
    report_id: str
''','''    ARTIFACT_KIND: ClassVar[str] = "lex.norm_impact_report"
    ARTIFACT_MEDIA_TYPE: ClassVar[str] = "application/json"
    ARTIFACT_SCHEMA_NAME: ClassVar[str] = "polisyos.lex.NormImpactReport"
    ARTIFACT_SCHEMA_VERSION: ClassVar[str] = "1.1"
    LEGACY_ARTIFACT_SCHEMA_VERSION: ClassVar[str] = "1.0"

    schema_version: Literal["1.0", "1.1"] = "1.0"
    report_id: str
''')
edit('src/polisyos/lex/legal_evaluation/impact_diff.py','''    norm_diff_ref: str | None = None
    norms_added: int = 0
''','''    norm_diff_ref: str | None = None
    norm_diff_artifact_ref: ArtifactRef | None = Field(
        default=None, exclude_if=lambda value: value is None
    )
    norms_added: int = 0
''')
edit('src/polisyos/lex/legal_evaluation/impact_diff.py','''    cas_artifact_id: str | None = None
    metadata: dict[str, object] = Field(default_factory=dict)

    @property
''','''    cas_artifact_id: str | None = None
    cas_artifact_ref: ArtifactRef | None = Field(
        default=None, exclude_if=lambda value: value is None
    )
    metadata: dict[str, object] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_selected_artifact_refs(self) -> NormImpactReport:
        if self.schema_version == "1.0":
            if self.norm_diff_artifact_ref is not None or self.cas_artifact_ref is not None:
                raise ValueError("legacy_report_cannot_claim_selected_artifact_refs")
            return self
        diff_ref = self.norm_diff_artifact_ref
        if (
            diff_ref is None
            or diff_ref.manifest_profile_sha256 is None
            or diff_ref.kind != NormDiff.ARTIFACT_KIND
            or diff_ref.media_type != NormDiff.ARTIFACT_MEDIA_TYPE
            or self.norm_diff_ref != str(diff_ref.artifact_id)
        ):
            raise ValueError("selected_norm_diff_reference_required")
        if self.cas_artifact_ref is not None and (
            self.cas_artifact_ref.manifest_profile_sha256 is None
            or self.cas_artifact_ref.kind != self.ARTIFACT_KIND
            or self.cas_artifact_ref.media_type != self.ARTIFACT_MEDIA_TYPE
            or self.cas_artifact_id != str(self.cas_artifact_ref.artifact_id)
        ):
            raise ValueError("selected_report_reference_mismatch")
        return self

    @property
''')
edit('src/polisyos/lex/legal_evaluation/impact_diff.py','''        legal_backend: object | None = None,
    ) -> None:
''','''        legal_backend: object | None = None,
        report_schema_version: Literal["1.0", "1.1"] = "1.1",
    ) -> None:
''')
edit('src/polisyos/lex/legal_evaluation/impact_diff.py','''        self._legal_backend = legal_backend
''','''        self._legal_backend = legal_backend
        if report_schema_version not in ("1.0", "1.1"):
            raise ValueError("Unsupported impact report schema version")
        self._report_schema_version = report_schema_version
''')
edit('src/polisyos/lex/legal_evaluation/impact_diff.py','''        report = NormImpactReport(
            report_id=self._generate_report_id(old_pack, new_pack, diff),
''','''        # The new version describes an issued view and is only written after
        # the diff's exact selected profile exists. In-memory-only results keep
        # the legacy, explicitly unbound shape until an artifact is issued.
        diff_ref = self._persist_diff(diff) if persist else None
        report_version = self._report_schema_version if persist else "1.0"
        report = NormImpactReport(
            schema_version=report_version,
            report_id=self._generate_report_id(old_pack, new_pack, diff),
            norm_diff_ref=str(diff_ref.artifact_id) if diff_ref is not None else None,
            norm_diff_artifact_ref=diff_ref if report_version == "1.1" else None,
''')
edit('src/polisyos/lex/legal_evaluation/impact_diff.py','''        if persist:
            diff_ref = self._persist_diff(diff)
            report.norm_diff_ref = str(diff_ref.artifact_id)
            report_ref = self._persist_report(report)
            report.cas_artifact_id = str(report_ref.artifact_id)

        return report
''','''        if persist:
            report_ref = self._persist_report(report)
            return NormImpactReport.model_validate(
                report.model_dump(mode="python")
                | {
                    "cas_artifact_id": str(report_ref.artifact_id),
                    "cas_artifact_ref": report_ref if report_version == "1.1" else None,
                }
            )
        return report
''')
edit('src/polisyos/lex/legal_evaluation/impact_diff.py','''    def _persist_diff(self, diff: NormDiff):
        return self._cas.put_json(
            diff.model_dump(mode="json"),
            PutOptions(
                kind="lex.norm_diff",
                media_type="application/json",
                schema=SchemaInfo(name="polisyos.lex.NormDiff", version="1.0"),
            ),
        )

    def _persist_report(self, report: NormImpactReport):
        return self._cas.put_json(
            report.model_dump(mode="json"),
            PutOptions(
                kind="lex.norm_impact_report",
                media_type="application/json",
                schema=SchemaInfo(name="polisyos.lex.NormImpactReport", version="1.0"),
            ),
        )
''','''    def _persist_diff(self, diff: NormDiff) -> ArtifactRef:
        return self._cas.put_json(
            diff.model_dump(mode="json"),
            PutOptions(
                kind=NormDiff.ARTIFACT_KIND,
                media_type=NormDiff.ARTIFACT_MEDIA_TYPE,
                schema=SchemaInfo(
                    name=NormDiff.ARTIFACT_SCHEMA_NAME,
                    version=NormDiff.ARTIFACT_SCHEMA_VERSION,
                ),
            ),
            return_selected_profile=True,
        )

    def _persist_report(self, report: NormImpactReport) -> ArtifactRef:
        inputs = (
            [input_ref_from_artifact_ref(report.norm_diff_artifact_ref, role="norm_diff")]
            if report.norm_diff_artifact_ref is not None
            else []
        )
        return self._cas.put_json(
            report.model_dump(mode="json"),
            PutOptions(
                kind=report.ARTIFACT_KIND,
                media_type=report.ARTIFACT_MEDIA_TYPE,
                schema=SchemaInfo(name=report.ARTIFACT_SCHEMA_NAME, version=report.schema_version),
                inputs=inputs,
            ),
            return_selected_profile=report.schema_version == "1.1",
        )
''')
edit('src/polisyos/lex/legal_evaluation/impact_diff.py','''def _group_issues(
''','''@dataclass(frozen=True)
class NormImpactReadResult:
    """A decoded report and diff with a bounded view-binding disposition.

    This is a read result, not an authority token or proof of source-law
    authenticity, currentness, complete context, or issuer identity.
    """

    report: NormImpactReport
    diff: NormDiff | None
    diff_binding: Literal["exact_selected", "legacy_unbound", "legacy_absent"]


def load_norm_impact_report(
    cas: FileSystemCAS,
    report_ref: ArtifactRef | ArtifactID | str,
) -> NormImpactReadResult:
    """Read a report and resolve its bound diff or an explicitly limited legacy view.

    Version 1.1 requires the caller's exact report profile and reconciles the
    report's selected diff ref against its manifest input before reading the
    diff. Version 1.0 has no issued diff-profile binding and stays limited.

    Raises:
        ValueError: If a selected reference, schema, manifest edge or payload
            cannot be verified or reconciled.
        OSError: If a required artifact cannot be read.
    """
    report = validate_core_model_json_artifact(NormImpactReport, cas, report_ref)
    if report.schema_version == "1.1":
        if not isinstance(report_ref, ArtifactRef) or report_ref.manifest_profile_sha256 is None:
            raise ValueError("selected_report_profile_required")
        if report.cas_artifact_id is not None or report.cas_artifact_ref is not None:
            raise ValueError("persisted_report_cannot_self_reference")
        selected_diff = report.norm_diff_artifact_ref
        if selected_diff is None:
            raise ValueError("selected_norm_diff_reference_required")
        manifest = cas.get_manifest(report_ref)
        expected_edge = input_ref_from_artifact_ref(selected_diff, role="norm_diff")
        if manifest.inputs != [expected_edge]:
            raise ValueError("report_norm_diff_input_mismatch")
        diff = validate_core_model_json_artifact(NormDiff, cas, selected_diff)
        binding: Literal["exact_selected", "legacy_unbound", "legacy_absent"] = "exact_selected"
    elif report.norm_diff_ref is not None:
        diff = validate_core_model_json_artifact(NormDiff, cas, report.norm_diff_ref)
        binding = "legacy_unbound"
    else:
        return NormImpactReadResult(report=report, diff=None, diff_binding="legacy_absent")
    if (
        diff.old_pack_id != report.old_pack_id
        or diff.new_pack_id != report.new_pack_id
        or diff.jurisdiction != report.jurisdiction
    ):
        raise ValueError("report_norm_diff_scope_mismatch")
    return NormImpactReadResult(report=report, diff=diff, diff_binding=binding)


def _group_issues(
''')
edit('src/polisyos/lex/legal_evaluation/impact_diff.py','''    "NormImpactAnalyzer",
    "NormImpactReport",
]''','''    "NormImpactAnalyzer",
    "NormImpactReadResult",
    "NormImpactReport",
    "load_norm_impact_report",
]''')
edit('src/polisyos/lex/simulator/cli.py','''    if "legal" in report.passes_executed:
''','''    if report.schema_version == "1.0" and report.norm_diff_ref is not None:
        lines.extend(
            ["**Diff view limitation:** Legacy report does not bind the issued manifest profile.", ""]
        )

    if "legal" in report.passes_executed:
''')
edit('src/polisyos/lex/simulator/cli.py','''                "The report records expr_ast, which evaluates only rules assigned to it; source authenticity "
                "and complete rule coverage are not established."
''','''                "The report records expr_ast, which evaluates only rules assigned to it; "
                "source authenticity, complete rule coverage, and comparison-context "
                "binding are not established."
''')
edit('src/polisyos/core/components/_cli_lex.py','''    lex_sim_cli = importlib.import_module("polisyos.lex.simulator.cli")
''','''    lex_sim_cli = importlib.import_module("polisyos.lex.simulator.cli")
    impact_owner = importlib.import_module("polisyos.lex.legal_evaluation.impact_diff")
''')
edit('src/polisyos/core/components/_cli_lex.py','''            legal_backend=getattr(args, "legal_backend", None),
''','''            legal_backend=getattr(args, "legal_backend", None),
            report_schema_version=getattr(args, "report_schema_version", "1.1"),
''')
edit('src/polisyos/core/components/_cli_lex.py','''    report = analyzer.analyze(old_pack, new_pack)

    rendered: str
''','''    report = analyzer.analyze(old_pack, new_pack)
    selector = report.cas_artifact_ref or report.cas_artifact_id
    if selector is None:
        print("ERROR: impact report was not persisted", file=sys.stderr)
        return 1
    try:
        read_result = impact_owner.load_norm_impact_report(cas, selector)
    except (OSError, ValueError) as exc:
        print(f"ERROR: failed to verify persisted impact report: {exc}", file=sys.stderr)
        return 1
    report = type(report).model_validate(
        read_result.report.model_dump(mode="python")
        | {"cas_artifact_id": report.cas_artifact_id, "cas_artifact_ref": report.cas_artifact_ref}
    )

    rendered: str
''')
edit('tools/ops_runners/runtime_cli.py','''    impact.add_argument("--profile", choices=["fast", "mvp", "strict"], default="strict")
''','''    impact.add_argument(
        "--report-schema-version",
        choices=["1.0", "1.1"],
        default="1.1",
        help="1.1 binds the issued diff view; 1.0 is the explicitly limited rollback format",
    )
    impact.add_argument("--profile", choices=["fast", "mvp", "strict"], default="strict")
''')
