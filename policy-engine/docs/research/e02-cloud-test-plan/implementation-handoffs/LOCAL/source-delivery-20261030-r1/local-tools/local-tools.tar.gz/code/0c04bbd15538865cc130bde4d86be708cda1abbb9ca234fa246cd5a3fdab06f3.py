"""Enumerate complete AST construction/guarded transfer families, not sampled search hits."""
from pathlib import Path
import ast, hashlib,json
P=Path(__file__).resolve().parent;R=P.parents[4]
rel=Path('policy-engine/tools/quality/validation/decomposition_preflight.py')
def census(path):
 data=path.read_bytes();tree=ast.parse(data);parents={c:n for n in ast.walk(tree) for c in ast.iter_child_nodes(n)}
 def owner(node):
  while node in parents:
   node=parents[node]
   if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):return node.name
  return '<module>'
 sites=[]
 for node in ast.walk(tree):
  families=[]
  if isinstance(node,ast.Attribute) and node.attr=='guarded':families.append('guarded_attribute')
  if isinstance(node,ast.Call):
   if isinstance(node.func,ast.Name) and node.func.id=='_DynamicImportBinding':families.append('binding_constructor')
   if isinstance(node.func,ast.Name) and node.func.id=='replace':families.append('replace_constructor')
   if any(k.arg=='guarded' for k in node.keywords):families.append('guarded_keyword_call')
  if isinstance(node,ast.arg) and node.arg=='guarded':families.append('guarded_formal')
  for family in families:sites.append({'family':family,'function':owner(node),'line':node.lineno,'column':node.col_offset})
 from collections import Counter
 return {'source':str(path),'sha256':hashlib.sha256(data).hexdigest(),'file_type_denominator':'one complete parsed Python module; every AST node walked','counts':dict(Counter(s['family'] for s in sites)),'sites':sorted(sites,key=lambda s:(s['line'],s['column'],s['family']))}
result={'canonical_preimage':census(R/rel),'candidate_postimage':census(P/'candidate'/rel),'scope':'Static transfer denominator only; semantic evidence is in final behavioral controls and exact failed-case replay. Families overlap.'}
(P/'guarded-transfer-family-census.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v['counts'] for k,v in result.items() if isinstance(v,dict)}))
