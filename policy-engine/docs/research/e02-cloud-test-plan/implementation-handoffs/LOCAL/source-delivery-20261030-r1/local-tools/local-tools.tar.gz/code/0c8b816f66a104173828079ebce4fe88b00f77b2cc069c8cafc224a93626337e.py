"""Compute virtual Git trees from immutable Git entries in memory; never writes objects/index/refs."""
from pathlib import Path
import hashlib,json,subprocess
ROOT=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
OUT=Path(__file__).resolve().parent
manifest=json.loads((OUT/'manifest.json').read_text())
def digest(kind,data):
    return hashlib.sha1(kind+b' '+str(len(data)).encode()+b'\0'+data).hexdigest()
def entries_at(commit):
    result={}
    for item in subprocess.check_output(['git','ls-tree','-r','-z',commit],cwd=ROOT).split(b'\0'):
        if not item:continue
        meta,name=item.split(b'\t',1);mode,kind,oid=meta.split()
        result[name]=(mode,oid.decode())
    return result
def tree_id(entries):
    root={}
    for name,value in entries.items():
        parts=name.split(b'/');cursor=root
        for component in parts[:-1]:cursor=cursor.setdefault(component,{})
        cursor[parts[-1]]=value
    def visit(node):
        body=[]
        for name,value in sorted(node.items(),key=lambda item:item[0]+(b'/' if isinstance(item[1],dict) else b'')):
            if isinstance(value,dict):mode=b'40000';oid=visit(value)
            else:mode,oid=value
            body.append(mode+b' '+name+b'\0'+bytes.fromhex(oid))
        return digest(b'tree',b''.join(body))
    return visit(root)
receipts=[]
for commit in [manifest['base_commit'],manifest['current_root_head']]:
    entries=entries_at(commit);computed=tree_id(entries)
    expected=subprocess.check_output(['git','rev-parse',commit+'^{tree}'],cwd=ROOT,text=True).strip()
    assert computed==expected,(computed,expected)
    for row in manifest['files']:
        path=row['path'].encode();before=entries.get(path)
        if row['preimage_git_blob'] is None:assert before is None
        else:assert before==(row['preimage_mode'].encode(),row['preimage_git_blob'])
        data=(ROOT/row['postimage']).read_bytes();assert hashlib.sha256(data).hexdigest()==row['postimage_sha256']
        assert digest(b'blob',data)==row['postimage_git_blob']
        entries[path]=((row['preimage_mode'] or '100644').encode(),row['postimage_git_blob'])
    receipts.append({'base_commit':commit,'base_tree':expected,'base_tree_algorithm_reconciled':True,'virtual_overlay_tree':tree_id(entries),'complete_flat_entry_count':len(entries),'changed_paths':len(manifest['files'])})
(OUT/'tree-reconciliation.json').write_text(json.dumps({'mode':'standard-library in-memory tree and blob hashing only; no object/index/ref writes','identities':receipts,'not_an_actual_commit_or_composed_runtime_receipt':True},indent=2)+'\n')
print(json.dumps(receipts))
