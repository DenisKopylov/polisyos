"""Proposal: create candidate-only WMR/L6 inputs in an owned RAW case.

Not executed during preparation. This script does not create law, authority,
grounding, or normal N7 route evidence. It writes only below its sibling
``cases/<unique-case-id>`` path when a future runner explicitly invokes it.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path
from typing import Any


CASE_ID_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,48}$")
L6_PAYLOADS: tuple[tuple[str, dict[str, Any]], ...] = (
    ("intervention_knob_dictionary", {"selected_data": {"v": 1}}),
    ("lex_intervention_map", {"law": ["selected_data"]}),
    ("observation_to_contract_manifest", {"routes": []}),
    ("policy_scenario_templates", {"selected_root": "physical-data"}),
    ("slot_family_manifest", {"selected_root": "physical-data"}),
)


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _source_cut(repo_root: Path) -> dict[str, str]:
    def git(*args: str) -> str:
        return subprocess.run(
            ["git", "-C", str(repo_root), *args],
            check=True,
            capture_output=True,
            text=True,
        ).stdout.strip()

    return {
        "branch": git("branch", "--show-current"),
        "head": git("rev-parse", "HEAD"),
        "tree": git("rev-parse", "HEAD^{tree}"),
    }


def _assert_case_geometry(
    product_root: Path,
    script_root: Path,
    cases_root: Path,
    case_root: Path,
) -> None:
    product_root = product_root.resolve(strict=True)
    script_root = script_root.resolve(strict=True)
    cases_root = cases_root.resolve(strict=False)
    case_root = case_root.resolve(strict=False)
    if cases_root == script_root or not cases_root.is_relative_to(script_root):
        raise SystemExit("candidate_cases_root_not_inside_own_RAW_directory")
    if not case_root.is_relative_to(cases_root):
        raise SystemExit("candidate_case_outside_own_RAW_cases_root")
    if any(
        candidate == product_root
        or candidate in product_root.parents
        or product_root in candidate.parents
        for candidate in (cases_root, case_root)
    ):
        raise SystemExit("candidate_case_overlaps_product_root")


def prepare(repo_root: Path, case_id: str) -> dict[str, Any]:
    repo_root = repo_root.resolve(strict=True)
    product_root = repo_root / "policy-engine"
    if not (product_root / "pyproject.toml").is_file():
        raise SystemExit("policy_engine_product_root_unavailable")
    if not CASE_ID_RE.fullmatch(case_id):
        raise SystemExit("candidate_case_id_invalid")

    script_root = Path(__file__).resolve().parent
    if not script_root.is_relative_to(repo_root):
        raise SystemExit("candidate_builder_not_inside_requested_repository")
    cases_root = script_root / "cases"
    case_root = cases_root / case_id
    _assert_case_geometry(product_root, script_root, cases_root, case_root)
    if case_root.exists():
        raise SystemExit("candidate_case_already_exists")

    # Future explicit execution imports only the existing fixture/data owners.
    # Do not replace _load_recorded_n4_world with a marker or a fabricated ref.
    # Protect the product checkout from import-time bytecode writes even if a
    # future caller forgets to invoke Python with -B.
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(product_root))
    from tests._helpers import world_model_record as wmr_fixture_owner
    from tests.unit.runtime.quality.test_generation_source import (
        _load_recorded_n4_world,
    )
    from tests.unit.runtime.quality.test_design_generation import _test_design_problem
    from tests.unit.runtime.quality.test_intervention_substrate import _write_l6_fixture
    from polisyos.runtime.quality.cycle_substrate import build_cycle_substrate_context
    from polisyos.runtime.quality.intervention_substrate import (
        default_l6_bundle_paths,
        load_l6_intervention_substrate,
    )
    from polisyos.runtime.quality.substrate_registry import (
        load_substrate_registry,
        persist_substrate_registry,
    )
    from polisyos.runtime.quality.world_model_record import world_model_artifact_views
    from polisyos.runtime.quality import design_generation as n4
    from tests._helpers.world_model_record import _build_record

    # Create only a new case after all path guards. Both owners receive paths
    # under this RAW case; no default product .tmp or production_data write.
    cases_root.mkdir(parents=True, exist_ok=True)
    case_root.mkdir()

    persisted_registry_refs: list[Any] = []
    original_build_world_model_record = wmr_fixture_owner.build_world_model_record

    def build_with_same_registry_artifact(store: Any, *args: Any, **kwargs: Any) -> Any:
        # Persist the exact registry DTO that _build_record is about to pass to
        # WMR construction. This adds a genuine selected CAS input edge; it
        # does not synthesize a ref or modify/re-hash the registry DTO.
        registry_dto = kwargs["substrate_registry"]
        registry_ref = persist_substrate_registry(store, registry_dto)
        if registry_ref.manifest_profile_sha256 is None:
            raise SystemExit("candidate_substrate_registry_profile_not_selected")
        if load_substrate_registry(store, registry_ref) != registry_dto:
            raise SystemExit("candidate_substrate_registry_writer_readback_mismatch")
        persisted_registry_refs.append(registry_ref)
        kwargs["substrate_registry_artifact_ref"] = registry_ref
        return original_build_world_model_record(store, *args, **kwargs)

    # The adapter is scoped to this one fixture-owner call and restored even if
    # fixture construction fails. The canonical helper and product source are
    # not edited.
    wmr_fixture_owner.build_world_model_record = build_with_same_registry_artifact
    try:
        wmr_store, built, _model_spec, _registry_bundle_ref = _build_record(
            case_root / "wmr-owner"
        )
    finally:
        wmr_fixture_owner.build_world_model_record = original_build_world_model_record
    if len(persisted_registry_refs) != 1:
        raise SystemExit("candidate_substrate_registry_persist_count_invalid")
    persisted_registry_ref = persisted_registry_refs[0]
    world_ref = str(built.record_ref.artifact_id)
    selected_store, loaded_world = _load_recorded_n4_world(
        wmr_store.root,
        world_ref,
        built.record.content_hash,
    )
    # ReadOnlyFileSystemCAS intentionally exposes the ArtifactReader API and
    # has no root attribute. Bind the reopened reader through public content
    # operations and compare with the writer-owned artifact.
    if not selected_store.verify(world_ref).ok:
        raise SystemExit("candidate_wmr_selected_reader_verification_failed")
    if selected_store.get_bytes(world_ref) != wmr_store.get_bytes(world_ref):
        raise SystemExit("candidate_wmr_selected_reader_bytes_mismatch")
    if selected_store.get_manifest(world_ref) != wmr_store.get_manifest(world_ref):
        raise SystemExit("candidate_wmr_selected_reader_manifest_mismatch")
    if loaded_world != built.record:
        raise SystemExit("candidate_wmr_selected_reader_mismatch")
    registry_view_ref = world_model_artifact_views(loaded_world).substrate_registry_ref
    if registry_view_ref is None:
        raise SystemExit("candidate_wmr_substrate_registry_view_missing")
    if registry_view_ref != persisted_registry_ref:
        raise SystemExit("candidate_wmr_substrate_registry_view_mismatch")
    loaded_registry = load_substrate_registry(selected_store, registry_view_ref)
    if loaded_registry != load_substrate_registry(wmr_store, persisted_registry_ref):
        raise SystemExit("candidate_wmr_substrate_registry_reader_mismatch")

    l6_root = case_root / "l6-data-owner"
    paths = default_l6_bundle_paths(product_root, source_owner_root=l6_root)
    authority_path = paths["owner_authority_bindings"]
    expected_authority_path = (
        product_root
        / "architecture/policy_design_case/layer3_gy_l6_owner_authority_bindings.json"
    ).resolve(strict=True)
    if authority_path.resolve(strict=True) != expected_authority_path:
        raise SystemExit("candidate_L6_code_authority_path_not_code_owned")
    authority_hash_before = _sha256(authority_path)

    # This writes the five data-plane fixture members at owner-selected paths.
    # It intentionally does not invoke _minimal_split_l6_fixture, whose helper
    # also writes fake owner_authority_bindings under code_root.
    payload_by_key = dict(L6_PAYLOADS)
    l6_keys = (
        "intervention_knob_dictionary",
        "lex_intervention_map",
        "observation_to_contract_manifest",
        "policy_scenario_templates",
        "slot_family_manifest",
    )
    for key in l6_keys:
        _write_l6_fixture(paths[key], payload_by_key[key])

    bundle = load_l6_intervention_substrate(product_root, source_owner_root=l6_root)
    # Exercise the same selected registry + WMR + L6 context boundary that the
    # actual_n4_source fixture uses before the later admitted pytest cohort.
    from polisyos.runtime.quality.cycle_substrate import revalidate_cycle_substrate_context

    problem = _test_design_problem()
    problem = problem.model_copy(
        update={"runtime_hints": {**problem.runtime_hints, "synthetic": True}}
    )
    problem_ref = n4.gy_content_hash(problem.model_dump(mode="json"))
    cycle_context = build_cycle_substrate_context(
        design_problem_ref=problem_ref,
        domain=problem.domain,
        substrate_registry=loaded_registry,
        selected_registry_entry_hashes=tuple(
            item.entry_content_hash
            for item in loaded_world.substrate_registry_ref.resolved_entries
        ),
        world_model_record=loaded_world,
        intervention_substrate=bundle,
        candidate_levers=(),
        transport_context=None,
        source_pack_content_hash=None,
        substrate_input_content_hash=None,
    )
    revalidate_cycle_substrate_context(cycle_context)
    authority_hash_after = _sha256(authority_path)
    if authority_hash_after != authority_hash_before:
        raise SystemExit("candidate_builder_changed_code_authority_input")

    l6_members = [
        {
            "owner_key": key,
            "relative_to_l6_data_root": paths[key].relative_to(l6_root).as_posix(),
            "bytes": paths[key].stat().st_size,
            "sha256": _sha256(paths[key]),
            "classification": "synthetic_candidate_data",
        }
        for key in l6_keys
    ]
    receipt: dict[str, Any] = {
        "schema": "e02.n7-candidate-only-wmr-l6-inputs.r2",
        "status": "CANDIDATE_ONLY_NOT_AUTHENTIC_N7_INPUTS",
        "source_cut": _source_cut(repo_root),
        "repo_root": str(repo_root),
        "product_root": str(product_root),
        "case_root": str(case_root.resolve()),
        "claims": [],
        "authority": "none_claimed",
        "world_model": {
            "cas_root": str(wmr_store.root.resolve()),
            "artifact_ref": world_ref,
            "logical_content_hash": built.record.content_hash,
            "producer_fixture": "tests._helpers.world_model_record::_build_record",
            "fixture_producer_ref": "test.world_model_record_builder",
            "classification": "synthetic test WorldModelRecord; not production-composed WMR",
            "persisted_substrate_registry_artifact_ref": str(persisted_registry_ref),
            "registry_view_ref": str(registry_view_ref),
            "registry_logical_content_hash": loaded_registry.content_hash,
            "preflight_cycle_context_hash": cycle_context.content_hash,
        },
        "l6": {
            "source_owner_root": str(l6_root.resolve()),
            "bundle_content_hash": bundle.content_hash,
            "members": l6_members,
            "code_authority_bindings_path": str(authority_path.resolve()),
            "code_authority_sha256_before": authority_hash_before,
            "code_authority_sha256_after": authority_hash_after,
            "classification": "synthetic candidate data; actual code-owner authority read-only",
        },
        "required_environment": {
            "CORR_C_WORLD_CAS": str(wmr_store.root.resolve()),
            "CORR_C_WORLD_REF": world_ref,
            "CORR_C_WORLD_HASH": built.record.content_hash,
            "CORR_C_L6_SOURCE_ROOT": str(l6_root.resolve()),
            "CORR_C_L6_SOURCE_HASH": bundle.content_hash,
        },
        "forbidden_environment": ["CORR_C2_LEGACY_EFFECT_BRIDGE_PATH"],
        "limits": [
            "candidate software mechanics only",
            "no current-law, legal-authority, permission, grounding, source-currentness, or production-provenance claim",
            "does not establish normal N7 route/planner behavior or G acceptance",
            "all existing synthetic and negative assertions must remain unchanged",
        ],
    }
    (case_root / "candidate-inputs.json").write_text(
        json.dumps(receipt, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return receipt


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", type=Path, required=True)
    parser.add_argument("--case-id", required=True)
    args = parser.parse_args()
    receipt = prepare(args.repo_root, args.case_id)
    print(
        json.dumps(
            {
                "status": receipt["status"],
                "case_root": receipt["case_root"],
                "world_model": receipt["world_model"],
                "l6_member_count": len(receipt["l6"]["members"]),
                "required_environment": receipt["required_environment"],
                "forbidden_environment": receipt["forbidden_environment"],
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
