import ast,difflib,hashlib,json
from pathlib import Path
base=Path('LOCAL/raw/e02-execution-20261027/repairs/C48-r4')
dest=base/'removals';dest.mkdir(exist_ok=True)
f='policy-engine/src/polisyos/scientist/methods/search/frontier.py'
l='policy-engine/src/polisyos/scientist/methods/search/lifecycle.py'
r='policy-engine/src/polisyos/scientist/methods/search/pareto_registry.py'
a='policy-engine/src/polisyos/scientist/methods/search/strategies/adapter.py'
o='policy-engine/src/polisyos/scientist/methods/search/funnel/orchestrator.py'
t='tests/unit/scientist/search/test_candidate_identity_semantics.py::'
u='tests/unit/scientist/search/test_funnel_subject_identity.py::'
cases=[
 ('root-underscore',f,[( '        actual = "sha256:" + hashlib.sha256(stable_json_dumps(candidate).encode("utf-8")).hexdigest()','        actual = "sha256:" + hashlib.sha256(stable_json_dumps({k: v for k, v in candidate.items() if not k.startswith("_")}).encode("utf-8")).hexdigest()')],t+'test_bare_semantic_keys_reach_two_incomparable_frontier_points','different semantic underscore inputs collapse'),
 ('supplied-digest',f,[( '        if supplied not in (None, "") and (not isinstance(supplied, str) or supplied.strip() != actual):','        if False:')],t+'test_context_binds_exact_payload_and_only_declared_transport','forged digest is accepted'),
 ('proposal-payload',f,[( '        if not candidate_payloads_equal(reconstructed, proposal.payload):','        if False:')],t+'test_context_binds_exact_payload_and_only_declared_transport','mismatched evaluated payload is accepted'),
 ('source-binding',r,[( '    if store is None or entry.candidate_ref is None or entry.evaluation_ref is None:\n        return False','    if store is None or entry.candidate_ref is None or entry.evaluation_ref is None:\n        return True')],t+'test_matching_caller_digest_does_not_establish_source_or_rank','matching asserted digest acquires rank without selected source'),
 ('tell-before-state',l,[( '        metadata_hash = policy_evaluation.metadata.get("candidate_hash") if policy_evaluation else None','        return policy_candidate_hash(candidate_proposal or candidate)\n        metadata_hash = policy_evaluation.metadata.get("candidate_hash") if policy_evaluation else None')],t+'test_tell_mismatch_retains_pending_and_does_not_change_best_or_history','forged tell consumes pending state'),
 ('replica-metadata',a,[( '            for key in ("replicate_id", "replica_id", "seed"):','            for key in ():')],t+'test_real_strategy_lifecycle_persists_and_reloads_two_replicas','replica identity is lost at fresh consumer'),
 ('technical-to-stage',f,[( '    # Producer-only strategy fields never enter the evaluator payload. Any\n','    if fields:\n        subject.setdefault("_strategy_metadata", {}).update(fields)\n    # Producer-only strategy fields never enter the evaluator payload. Any\n')],u+'test_funnel_hides_producer_context_and_keys_effective_context','producer-only field enters stage and identical subjects execute differently'),
 ('effective-basis',o,[( '        if metric_projection_basis is not None:\n            cache_context["_funnel_method_metric_projection_basis"] = metric_projection_basis\n',''),('        if basis is not None:\n            context["_funnel_method_metric_projection_basis"] = basis\n','')],u+'test_method_metric_basis_that_stage_reads_changes_cache_and_opaque_runs_fresh','different effective stage basis incorrectly reuses prior ticket'),
 ('opaque-attempt',o,[( '            ticket.prior_attempt_ticket_id = prior_attempt.ticket_id\n','')],u+'test_opaque_split_exposes_both_physical_attempt_traces','earlier physical trace and cost disappear'),
 ('funnel-transfer-serialization',a,[( '        if isinstance(stage_b_result, dict) and "_funnel_outcome" in stage_b_result:','        if False and isinstance(stage_b_result, dict) and "_funnel_outcome" in stage_b_result:')],u+'test_real_funnel_lifecycle_history_round_trips_selected_source','raw non-JSON funnel outcome prevents retained history receipt'),
]
rows=[]
for ident,path,replacements,selector,failure in cases:
 src=(base/('c53-postimages' if path==o else 'postimages')/path).read_text();mut=src
 for old,new in replacements:
  count=mut.count(old)
  if count!=1: raise ValueError(f'{ident}: {count} occurrences: {old}')
  mut=mut.replace(old,new,1)
 ast.parse(mut,path)
 patch=''.join(difflib.unified_diff(src.splitlines(keepends=True),mut.splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path))
 (dest/(ident+'.patch')).write_text(patch)
 sha=lambda x:hashlib.sha256(x.encode()).hexdigest()
 rows.append({'id':ident,'source':path,'source_sha256':sha(src),'mutant_sha256':sha(mut),'patch_sha256':sha(patch),'selector':selector,'expected_semantic_failure':failure,'status':'UNRUN'})
(dest/'manifest.json').write_text(json.dumps({'status':'UNRUN','cases':rows},indent=2)+'\n')
print('prepared',len(rows),'source-bound removal patches; all UNRUN')
