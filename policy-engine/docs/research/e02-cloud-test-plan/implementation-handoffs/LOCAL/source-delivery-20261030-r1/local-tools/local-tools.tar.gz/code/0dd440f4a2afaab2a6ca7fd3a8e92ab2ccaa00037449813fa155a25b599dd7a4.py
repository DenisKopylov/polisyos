from pathlib import Path
base=Path('LOCAL/raw/e02-execution-20261027/repairs/TC-closure-owner-r3/proposal')
p=base/'policy-engine/src/polisyos/runtime/quality/owned_execution_identity.py'
s=p.read_text()
def rep(a,b):
 global s
 n=s.count(a)
 if n!=1: raise ValueError((n,a[:130]))
 s=s.replace(a,b,1)
rep('''if TYPE_CHECKING:
    from polisyos.core.artifacts import ArtifactManifest
    from polisyos.runtime.http.services.control import ControlPlaneService
''','''if TYPE_CHECKING:
    from polisyos.core.artifacts import ArtifactManifest
    from polisyos.runtime.http.services.control import ControlPlaneService
    from polisyos.scientist.nodes.builtins.decide.policy_runtime_method_metrics import (
        _ProjectionReadBudget,
    )
''')
rep('''    __slots__ = ("_control", "_run_id", "_scope", "_sealed", "_simulation_key")''','''    __slots__ = (
        "_aggregate_read_budget", "_control", "_run_id", "_scope", "_sealed", "_simulation_key"
    )''')
rep('''        self, *, control: ControlPlaneService, run_id: str, simulation_ref: ArtifactRef
    ) -> None:
        from polisyos.runtime.http.services.control import ControlPlaneService
''','''        self,
        *,
        control: ControlPlaneService,
        run_id: str,
        simulation_ref: ArtifactRef,
        aggregate_read_budget: _ProjectionReadBudget,
    ) -> None:
        from polisyos.runtime.http.services.control import ControlPlaneService
        from polisyos.scientist.nodes.builtins.decide.policy_runtime_method_metrics import (
            _ProjectionReadBudget,
        )
''')
rep('''            type(control) is not ControlPlaneService
            or type(scope) is not AccessScope''','''            type(control) is not ControlPlaneService
            or type(aggregate_read_budget) is not _ProjectionReadBudget
            or aggregate_read_budget.parent is not None
            or type(scope) is not AccessScope''')
rep('''        object.__setattr__(self, "_control", control)
''','''        object.__setattr__(self, "_aggregate_read_budget", aggregate_read_budget)
        object.__setattr__(self, "_control", control)
''')
rep('''            run_id=self._run_id, tenant_id=scope.tenant_id, cell_id=scope.cell_id
        )''','''            run_id=self._run_id, tenant_id=scope.tenant_id, cell_id=scope.cell_id,
            aggregate_read_budget=self._aggregate_read_budget,
        )''')
rep('''            restricted_exante_call_collector=calls,
        )''','''            restricted_exante_call_collector=calls,
            aggregate_read_budget=self._aggregate_read_budget,
        )''')
rep('''        budget = _ProjectionReadBudget()
''','''        budget = _ProjectionReadBudget(parent=self._aggregate_read_budget)
''')
rep('''                run_id=self._run_id, tenant_id=scope.tenant_id, cell_id=scope.cell_id
            ) != selection''','''                run_id=self._run_id, tenant_id=scope.tenant_id, cell_id=scope.cell_id,
                aggregate_read_budget=self._aggregate_read_budget,
            ) != selection''')
rep('''    *, control: ControlPlaneService, run_id: str, simulation_ref: ArtifactRef
) -> tuple[SameInputClosure, VerifiedSameInputClosure]:''','''    *,
    control: ControlPlaneService,
    run_id: str,
    simulation_ref: ArtifactRef,
    aggregate_read_budget: _ProjectionReadBudget,
) -> tuple[SameInputClosure, VerifiedSameInputClosure]:''')
rep('''        control=control, run_id=run_id, simulation_ref=simulation_ref
    )''','''        control=control,
        run_id=run_id,
        simulation_ref=simulation_ref,
        aggregate_read_budget=aggregate_read_budget,
    )''')
p.write_text(s)
p=base/'policy-engine/src/polisyos/runtime/http/services/debug_registered_sql.py'
s=p.read_text()
rep('''    try:
        _require_runtime_ambient_ownership(store)
        with tenant_scope(None, tenant_id=tenant, cell_id=cell):''','''    aggregate_budget = _ProjectionReadBudget()
    try:
        _require_runtime_ambient_ownership(store)
        with tenant_scope(None, tenant_id=tenant, cell_id=cell):''')
rep('''                cell_id=cell, expected_manifest_ref=manifest_ref,
            )''','''                cell_id=cell, expected_manifest_ref=manifest_ref,
                aggregate_read_budget=aggregate_budget,
            )''')
rep('''            selection = control.get_method_execution_selection(
                run_id=run.run_id, tenant_id=tenant, cell_id=cell
            )''','''            selection = control.get_method_execution_selection(
                run_id=run.run_id, tenant_id=tenant, cell_id=cell,
                aggregate_read_budget=aggregate_budget,
            )''')
rep('''                restricted_exante_call_collector=calls,
            )''','''                restricted_exante_call_collector=calls,
                aggregate_read_budget=aggregate_budget,
            )''')
rep('''            budget = _ProjectionReadBudget()
''','''            budget = _ProjectionReadBudget(parent=aggregate_budget)
''')
rep('''                control=control, run_id=run.run_id, simulation_ref=simulation_ref
            )''','''                control=control, run_id=run.run_id, simulation_ref=simulation_ref,
                aggregate_read_budget=aggregate_budget,
            )''')
rep('''                run_id=run.run_id, tenant_id=tenant, cell_id=cell
            ) != selection:''','''                run_id=run.run_id, tenant_id=tenant, cell_id=cell,
                aggregate_read_budget=aggregate_budget,
            ) != selection:''')
p.write_text(s)
print('owner+debug budget wiring generated')
