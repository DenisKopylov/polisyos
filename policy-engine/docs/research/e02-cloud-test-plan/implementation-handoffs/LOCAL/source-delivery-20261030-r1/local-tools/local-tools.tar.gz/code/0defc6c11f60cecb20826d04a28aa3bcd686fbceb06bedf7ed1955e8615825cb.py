"""Freeze only RAW C60 provider-family repair metadata; no canonical writes."""
from pathlib import Path
import ast
import copy
import difflib
import hashlib
import json
import subprocess
import tomllib

root = Path.cwd()
packet = Path(__file__).resolve().parent
post = packet / 'postimages'
base = '24a7b01e85e613fcd7bc789bca9fead6f38846d7'
tree = 'eb2013a7ae2fa246d45c6a88c92e9042a48793f8'
sha = lambda data: hashlib.sha256(data).hexdigest()
footprint = []
patch = []
for path in sorted(post.rglob('*')):
    if not path.is_file():
        continue
    rel = path.relative_to(post).as_posix()
    before = subprocess.check_output(['git', 'show', f'{base}:{rel}'], cwd=root)
    assert (root / rel).read_bytes() == before, rel
    after = path.read_bytes()
    assert before != after, rel
    if path.suffix == '.py':
        ast.parse(after)
    if path.suffix == '.toml':
        tomllib.loads(after.decode())
    footprint.append({'path': rel, 'preimage_sha256': sha(before), 'postimage_sha256': sha(after), 'postimage': str(path.relative_to(root)), 'bytes': len(after)})
    patch.append(''.join(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True), fromfile='a/' + rel, tofile='b/' + rel)))
(packet / 'source.patch').write_text(''.join(patch))
methods = root / 'policy-engine/src/polisyos/foundry/methods'
tracked = set(subprocess.check_output(['git', 'ls-files', '--', 'policy-engine/src/polisyos/foundry/methods'], cwd=root, text=True).splitlines())
census = [{'path': str(path.relative_to(root)), 'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes()), 'tracked': str(path.relative_to(root)) in tracked} for path in sorted(methods.rglob('*.pyi')) if path.is_file()]
assert len(census) == 5 and all(row['tracked'] for row in census)
(packet / 'physical-stub-census.json').write_text(json.dumps({'source_commit': base, 'source_tree': tree, 'scope': 'Complete physical *.pyi beneath src/polisyos/foundry/methods, compared to complete tracked same subtree; module-relative names are not collapsed by physical alias identity.', 'files': census}, indent=2) + '\n')
source_path = 'policy-engine/src/polisyos/foundry/methods/selection/registry.py'
stub_path = 'policy-engine/src/polisyos/foundry/methods/selection/registry.pyi'
source = ast.parse((root / source_path).read_text())
stub = ast.parse((root / stub_path).read_text())
old = {}
current = {}
for result, nodes in [(old, stub.body), (current, source.body)]:
    for node in nodes:
        if isinstance(node, ast.ClassDef):
            result[node.name] = [child.name for child in node.body if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef))]
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            result[node.name] = []
relations = [{'declaration': name, 'old_method_property_count': len(members), 'source_present': name in current, 'missing_old_members_in_source': sorted(set(members) - set(current.get(name, [])))} for name, members in old.items()]
assert all(row['source_present'] and not row['missing_old_members_in_source'] for row in relations)
compat = {'source_path': source_path, 'source_sha256': sha((root / source_path).read_bytes()), 'legacy_stub_path': stub_path, 'legacy_stub_sha256': sha((root / stub_path).read_bytes()), 'complete_old_class_function_set': relations, 'old_class_function_count': len(old), 'old_method_property_count': sum(len(v) for v in old.values()), 'source_policy': 'Generate actual provider source through the existing owner; do not preserve inaccurate hand-maintained typing behavior.', 'specific_shape_dispositions': ['All old declared classes/functions/method/property identities exist in actual source; no useful runtime API is deleted.', 'RegistryAuditLog.export_jsonl accepts both str and pathlib.Path at runtime; source annotation extends to str|os.PathLike[str], preserving former typed Path clients and current string clients.', 'RegistryAuditEvent.details remains dict[str,Any] as legacy stub promised; canonical source bare dict is made explicit.', 'FoundryMethod registry annotations now explicitly instantiate existing heterogeneous state Any and Mapping[str,Any] input contract instead of omitted generic arguments; no ignore or broader Any fallback.', 'MethodEntry actual defaults, optional persisted import metadata, cached class and load lock are source truth; former required-only stub constructor was incomplete.', 'RegistrySnapshotEntry actual frozen=True and from_entry are source truth; earlier writable snapshot typing was inaccurate.', 'RegistryAuditLog constructor/max_events and MethodRegistry.snapshot_scope already exist in source and are included by genuine generation.', 'MethodLifecycle is already in runtime canonical __all__ and explicit self-reexport; only stale provider .pyi omitted it.', 'MethodFactory remains an actual callable type alias and is exercised by strict consumer, even though it is not a wildcard __all__ export.'], 'verification': 'Static complete source/stub review only; actual generated5 payloads/strict/runtime checks UNRUN.'}
(packet / 'provider-contract-review.json').write_text(json.dumps(compat, indent=2) + '\n')
D = root / 'policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1'
case = D / 'c60-strict-abi-defining-r4-20261028'
node = case / 'basetemp/test_actual_stub_owner_staging0'
required = [case / 'audit-result.json', case / 'source-profile-freeze.json', node / 'enum-mypy-output/invocation.json', node / 'enum-mypy-output/stdout.txt', node / 'enum-mypy-output/stderr.txt', node / 'enum_consumer.py']
proof = [{'path': str(path.relative_to(root)), 'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes())} for path in required]
assert proof[0]['sha256'] == '36e3a3f9895a10c06cc571967115b08f9e08d0dea034a9adcf268d7c7fb071f4'
inv = json.loads((node / 'enum-mypy-output/invocation.json').read_text())
assert inv['returncode'] == 1 and inv['capture_complete'] is True and len(inv['staged_inputs']) == 4
(packet / 'actual-predecessor-evidence.json').write_text(json.dumps({'source_commit': base, 'source_tree': tree, 'outcome': 'Actual1FAIL defining node, complete child1typeerror; no new generated output adoption', 'observed_child_error': 'registry.pyi:4 selection.registry has no attribute MethodLifecycle [attr-defined]', 'binding': 'Fifth complete physical .pyi shadows corrected.py; this is the observed boundary. No other unknown runtime diagnosis is asserted.', 'files': proof}, indent=2) + '\n')
producer_path = 'policy-engine/tools/devx/foundry/generate_stubs.py'
test_path = 'policy-engine/tests/repo_quality/tools/test_foundry_stub_generation.py'
producer = (post / producer_path).read_text()
test_hash = sha((post / test_path).read_bytes())
original = root / 'LOCAL/raw/e02-execution-20261027/generated-admission-r1/c60-generator-style-r1/controls'
provider_block = '''    "polisyos.foundry.methods.selection.registry": SRC_ROOT
    / "polisyos"
    / "foundry"
    / "methods"
    / "selection"
    / "registry.pyi",
'''
controls = [
 ('byte-comparator', '        if args.check:\n', '        if args.check:\n            return 0, "PASS"  # property removed; rendered family/receipt remain\n', 'freshness comparator must refuse every changed declared output'),
 ('canonical-style', '    logical_path = target.relative_to(REPO_ROOT).as_posix()\n', '    return content  # canonicalization property removed; caller/config markers remain\n    logical_path = target.relative_to(REPO_ROOT).as_posix()\n', 'actual generated stub must pass canonical Ruff'),
 ('facade-completeness', '    aliases = "\\n".join(f"    {name} as {name}," for name in names)\n', '    names = names[:1]  # actual canonical export completeness removed\n    aliases = "\\n".join(f"    {name} as {name}," for name in names)\n', 'facade stub must preserve every actual canonical export without wildcard'),
 ('source-abi-preservation', '    source_tree = ast.parse(measured_read_text(source), filename=str(source))\n', '    return content  # semantic property removed; all original stub names/markers remain\n    source_tree = ast.parse(measured_read_text(source), filename=str(source))\n', 'actual generated Enum ABI must pass strict member/value consumers'),
 ('provider-family-closure', provider_block, '    # canonical provider marker retained: polisyos.foundry.methods.selection.registry\n', 'the generated family must own every physical method stub, including canonical providers'),
]
control_rows = []
for name, old_text, new_text, signal in controls:
    assert producer.count(old_text) == 1, name
    mutant = producer.replace(old_text, new_text, 1)
    ast.parse(mutant)
    out = packet / 'controls' / name / 'property-removal.patch'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(''.join(difflib.unified_diff(producer.splitlines(True), mutant.splitlines(True), fromfile='a/' + producer_path, tofile='b/' + producer_path)))
    row = {'id': name, 'producer_path': producer_path, 'correct_producer_sha256': sha(producer.encode()), 'mutant_producer_sha256': sha(mutant.encode()), 'patch': str(out.relative_to(root)), 'patch_sha256': sha(out.read_bytes()), 'test_path': test_path, 'test_sha256': test_hash, 'node': 'test_actual_stub_owner_staging_and_check_detect_complete_byte_drift', 'required_failure': signal, 'outcome': 'UNRUN', 'restoration': 'Exact correct source bytes/hash before next case; no canonical/generated adoption from any mutant; source restore is not runtimePASS.'}
    if name in {'byte-comparator', 'canonical-style', 'facade-completeness'}:
        prior = original / name / 'property-removal.patch'
        row['original_reviewed_patch'] = str(prior.relative_to(root))
        row['original_reviewed_patch_sha256'] = sha(prior.read_bytes())
    control_rows.append(row)
(packet / 'controls.json').write_text(json.dumps(control_rows, indent=2) + '\n')
old_profile = root / 'LOCAL/raw/e02-execution-20261027/generated-admission-r1/c60-local-cli-admission-r5/inputs.json'
profile = json.loads(old_profile.read_text())
commands = [copy.deepcopy(c) for group in profile['groups'] if group['name'] != 'canonical-cli' for c in group['commands']]
new_command = copy.deepcopy(next(c for c in commands if c['id'] == 'abi-04'))
new_command['id'] = 'abi-13-canonical-selection-provider'
new_command['arguments'][-1] = str(methods / 'selection/registry.pyi')
commands.insert(-1, new_command)
assert len(commands) == 15 and all(c['arguments'][0] == '--no-fast-exit' for c in commands)
denominator = copy.deepcopy(profile['type_denominator'])
denominator['generated_stubs'].append('src/polisyos/foundry/methods/selection/registry.pyi')
denominator.update(file_targets=13, total_mypy_commands=15)
(packet / 'type-profile-delta.json').write_text(json.dumps({'schema': 'policyos.e02.c60.type_profile_delta.v1', 'predecessor': str(old_profile.relative_to(root)), 'predecessor_sha256': sha(old_profile.read_bytes()), 'source_commit': None, 'source_tree': None, 'status': 'HOLD until Root composed source and all5 genuine outputs committed/read back, then fresh source/profile admission', 'denominator': denominator, 'commands': commands, 'new_explicit_source_pins': [source_path, stub_path], 'profile_unchanged': 'Existing mypy1.19.1/python3.14/.pth/--no-fast-exit/strict mypy.ini/private cache, Root resource/source/sandbox guards; do not execute predecessor with stale pins.', 'rebind_requirements': ['Actual future Root clean source HEAD/tree; every changed selected source and generated-reference input', 'All5 generated genuine postimage hashes; canonical provider source pin and canonical provider.pyi new pin', 'Historical4-output14-target receipts stay unchanged; no inherited-red attribution without P41 replay', 'Ray absent remains setupERROR; negative client requires exactly2 intended return-value sites and zero unrelated errors']}, indent=2) + '\n')
manifest = {'schema': 'policyos.e02.c60.strict_abi_provider_closure.v3', 'base_commit': base, 'base_tree': tree, 'footprint': footprint, 'source_patch_sha256': sha((packet / 'source.patch').read_bytes()), 'generated_companions': [dict(row, postimage=None, status='UNRUN actual common owner generation required') for row in census], 'generated_reference_companion': {'path': 'policy-engine/docs/reference/generated-artifacts.md', 'status': 'UNRUN real existing guardrails renderer; no hand edits'}, 'family_quantity': {'physical_pyi': 5, 'declared_outputs_after': 5, 'canonical_stubgen_providers': 3, 'compatibility_facades': 2, 'owner_cycles_in_defining_node': 7, 'planned_stubgen_child_calls': 21, 'strict_abi_file_targets': 13, 'clients': 2, 'total_type_commands': 15}, 'scope': 'Same P40 generated ABI quantity class: consolidate actual canonical provider once; source enums/annotations/private semantics unchanged.', 'evidence': {'actual_predecessor': 'actual-predecessor-evidence.json', 'physical_census': 'physical-stub-census.json', 'provider_api_review': 'provider-contract-review.json', 'controls': 'controls.json', 'profile_delta': 'type-profile-delta.json'}, 'static_results': '3PythonAST,1TOML and6canonical-logical Ruff check/format PASS; static-ruff-results.json', 'runtime_results': 'UNRUN by author; no imports/stubgen/mypy/tests/native or canonical/index/ref/env mutation', 'existing_small_child_delivery_allowlist': {'path': 'LOCAL/raw/e02-execution-20261027/repairs/C60-strict-abi-r2/delivery-allowlist.json', 'sha256': sha((root / 'LOCAL/raw/e02-execution-20261027/repairs/C60-strict-abi-r2/delivery-allowlist.json').read_bytes()), 'note': 'Same4 small stream/invocation/consumer files; actual staged_inputs receipt becomes5 automatically. Root must retrieve actual bytes.'}, 'resource_admission': 'New profile alone under retained supervisor. Actual predecessor54.95574s peak2190245888B is not a bound proof for new3-provider5-output profile. Existing600s/2.25GiB initial ceiling and8GiB launch/6GiB runtime disk guard require fresh Root admission; keep unknown memory/resource termination an ERROR, not productFAIL.', 'residuals': ['All5 real outputs and reference remain UNRUN; no manually computed generated files.', 'Actual strict typing/provider API/removal/affected runtime results pending independent source review and Root execution.', 'Optional Ray backend remains absent setupERROR, no suppression or hidden import workaround.', 'No G acceptance/formalclosure or R9/GY/Atlas implementation.']}
(packet / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print('frozen preindex', len(footprint), 'source paths;', len(census), 'deferred outputs;', len(control_rows), 'controls;', len(commands), 'future type commands')
