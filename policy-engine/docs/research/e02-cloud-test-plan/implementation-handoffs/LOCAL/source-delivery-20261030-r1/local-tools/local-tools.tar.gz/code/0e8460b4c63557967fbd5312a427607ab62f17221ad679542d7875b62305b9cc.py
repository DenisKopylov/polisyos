"""Freeze only proposal bytes and their preimage identities; do not modify Git."""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess

root = Path.cwd()
p = root/'LOCAL/raw/e02-execution-20261027/repairs/TC-public-route-companion-r1'
old = p/'preimages'
new = p/'postimages'
def sha(data): return hashlib.sha256(data).hexdigest()
files = sorted(f for f in new.rglob('*') if f.is_file())
records = []
chunks = []
for f in files:
    rel = f.relative_to(new)
    before_path = old/rel
    before = before_path.read_bytes() if before_path.exists() else None
    after = f.read_bytes()
    actual = root/rel
    if before is None:
        if actual.exists():
            raise RuntimeError(f'new path already exists: {rel}')
    elif not actual.exists() or actual.read_bytes() != before:
        raise RuntimeError(f'actual preimage changed: {rel}')
    records.append({'path': str(rel), 'preimage_sha256': None if before is None else sha(before), 'postimage_sha256': sha(after)})
    before_lines = [] if before is None else before.decode().splitlines(keepends=True)
    chunks.extend(difflib.unified_diff(before_lines, after.decode().splitlines(keepends=True), fromfile='/dev/null' if before is None else 'a/'+str(rel), tofile='b/'+str(rel)))
patch = ''.join(chunks).encode()
(p/'source.diff').write_bytes(patch)

rel = Path('policy-engine/src/polisyos/ir/__init__.py')
source = (new/rel).read_text()
needle = '    "LinkReport": ("polisyos.ir.linker", "LinkReport"),'
assert source.count(needle) == 1
mutation = source.replace(needle, '    "LinkReport": ("polisyos.ir.linker", "LinkIssue"),')
control = ''.join(difflib.unified_diff(source.splitlines(keepends=True), mutation.splitlines(keepends=True), fromfile='a/'+str(rel), tofile='b/'+str(rel))).encode()
(p/'wrong-owner-control.diff').write_bytes(control)

rel = Path('policy-engine/src/polisyos/runtime/quality/owned_execution_identity.py')
source = (new/rel).read_text()
needle = '        from polisyos.ir import LinkReport\n'
assert source.count(needle) == 1
mutation = source.replace(needle, '        from polisyos.ir.linker import LinkReport\n')
control2 = ''.join(difflib.unified_diff(source.splitlines(keepends=True), mutation.splitlines(keepends=True), fromfile='a/'+str(rel), tofile='b/'+str(rel))).encode()
(p/'deep-import-control.diff').write_bytes(control2)
manifest = {
    'status': 'SOURCE_PROPOSAL_RUNTIME_UNRUN',
    'source_head': subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'source_binding': 'Exact preimages below, over dirty TC/C105 composition; HEAD alone is not the source identity.',
    'prerequisite': 'TC-facade-registration-r1 reviewed source patch 8f05d62613c03fded88d8912c549c82731ff755ecca02f2f6129bf2de4a7dbcd must be composed for Scientist route scanner test.',
    'source_diff_sha256': sha(patch),
    'wrong_owner_control_sha256': sha(control),
    'deep_import_control_sha256': sha(control2),
    'files': records,
    'static_checks': 'Run static-check.py from checkout root. Python AST, configured Ruff, TOML parse, two entrypoint inventory overlay checks, and actual classifier for two selected modules with r1 registrations assumed. No product imports or runtime tests.',
    'runtime_checks': 'UNRUN: tests/repo_quality/architecture/test_tc_execution_public_routes.py; focused TC/runtime and compiler tests; scanner and wrong-owner removal on composed source.',
    'companions': ['public surface inventory regeneration/readback', 'dynamic-import registry/check after full source freeze', 'release-fragment public_surface_inventory_reviewed only after actual review'],
    'limitations': ['Input identity and facade routes do not confer legal, scientific, external SQL freshness, or publication authority.', 'Static source scanner is not native owner identity proof.', 'G acceptance and formal closure remain separate.'],
}
(p/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
print('Frozen', len(records), 'paths; patch SHA-256', sha(patch))
