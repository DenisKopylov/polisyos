"""Run only C115's extracted provenance branch with stdlib stand-ins."""
import ast
import copy
import json
import subprocess
from datetime import datetime, timedelta, timezone, tzinfo
from enum import Enum

source = subprocess.check_output(['git', 'show', 'a396d80cce7c0c593d2c8bf826267b2771092e66:policy-engine/src/polisyos/foundry/uncertainty/monte_carlo.py'], text=True)
tree = ast.parse(source)
prepare = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == '_prepare_execution_envelope')
branch = next(n for n in prepare.body if isinstance(n, ast.If) and isinstance(n.test, ast.Compare) and isinstance(n.test.left, ast.Name) and n.test.left.id == 'provenance')
code = compile(ast.fix_missing_locations(ast.Module(body=branch.orelse, type_ignores=[])), '<C115 extracted branch>', 'exec')

class Step:
    def __init__(self, notes):
        self.notes = notes
    def model_copy(self, *, update, deep):
        clone = copy.deepcopy(self) if deep else copy.copy(self)
        clone.__dict__.update(update)
        return clone

class Provenance:
    def __init__(self, notes):
        self.operator_history = (Step(notes),)
    def model_copy(self, *, update, deep):
        clone = copy.deepcopy(self) if deep else copy.copy(self)
        clone.__dict__.update(update)
        return clone

class Zone(tzinfo):
    minutes = 0
    def __deepcopy__(self, memo):
        return self
    def utcoffset(self, dt):
        return timedelta(minutes=self.minutes)
    def dst(self, dt):
        return timedelta(0)

class Case(Enum):
    VALUE = {'items': ['before']}

zone = Zone()
prior = Provenance({'nested': {'timestamp': datetime(2026, 10, 28, 12, tzinfo=zone), 'tag': Case.VALUE}})
namespace = {'provenance': prior, 'deepcopy': copy.deepcopy, 'datetime': datetime, 'timezone': timezone, 'CompositionProvenance': Provenance}
exec(code, namespace)
prepared = namespace['provenance']
result = prepared.operator_history[0].notes['nested']
before = {'timestamp': result['timestamp'].isoformat(), 'tag': json.dumps(result['tag'].value)}
zone.minutes = 60
Case.VALUE.value['items'].append('after')
after = {'timestamp': result['timestamp'].isoformat(), 'tag': json.dumps(result['tag'].value)}
assert before != after and before['timestamp'] != after['timestamp'] and before['tag'] != after['tag']
print(json.dumps({'probe': 'C115 extracted provenance branch using stdlib stand-ins', 'before': before, 'after': after, 'result': 'aliases reproduced'}))
