"""ROOT-ONLY: freeze the reviewed C48 positive plan for the existing D runner.

This file does not invoke pytest or the runner. Execute only after the test-only
patch is independently reviewed, composed and committed, and the outer sandbox
has passed its synthetic controls. Its source frame is intentionally finite.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
HERE = Path(__file__).resolve().parent
D = ROOT / 'policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1'
FRAME_SHA256 = '1f78096aa2b020aacbe32487386dad6d0a2401293d7cccaff6b06e526e38bb2e'
EXPECTED_BRANCH = 'codex/e02-unified-local-20261009'
SELECTOR = 'tests/unit/runtime/http/test_observational_method_runtime.py::test_two_real_completed_ex_ante_sources_produce_fresh_candidate_comparison'


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git(*args: str) -> bytes:
    env = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
    return subprocess.check_output(['git', *args], cwd=ROOT, env=env)


def main() -> None:
    if len(sys.argv) != 2 or not re.fullmatch(r'[A-Za-z0-9_-]+', sys.argv[1]):
        raise SystemExit('usage: prepare_plan.py UNIQUE_CASE_ID (letters, digits, _, -)')
    case = sys.argv[1]
    frame_bytes = (HERE / 'source-bindings.json').read_bytes()
    if sha(frame_bytes) != FRAME_SHA256:
        raise SystemExit('source frame changed; require independent re-review')
    frame = json.loads(frame_bytes)
    branch = git('symbolic-ref', '--short', 'HEAD').decode().strip()
    if branch != EXPECTED_BRANCH:
        raise SystemExit(f'unexpected attached branch: {branch!r}')
    head = git('rev-parse', 'HEAD').decode().strip()
    tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
    status = git('status', '--porcelain', '--untracked-files=no').decode()
    if status:
        raise SystemExit('tracked/index changes exist; wait for Root to freeze them')
    if subprocess.run(['git', 'merge-base', '--is-ancestor', frame['baseline_commit'], head], cwd=ROOT).returncode:
        raise SystemExit('frozen source baseline is not an ancestor of HEAD')
    mismatches = []
    for entry in frame['selected_paths_and_explicit_conftest_absences']:
        path = ROOT / entry['path']
        expected = entry['expected_for_pilot']
        live = sha(path.read_bytes()) if path.is_file() else None
        commit = subprocess.run(['git', 'show', head + ':' + entry['path']], cwd=ROOT, capture_output=True)
        committed = sha(commit.stdout) if commit.returncode == 0 else None
        if live != expected or committed != expected:
            mismatches.append({'path': entry['path'], 'expected': expected, 'worktree': live, 'committed': committed})
    for entry in frame['raw_runner_inputs']:
        path = ROOT / entry['path']
        live = sha(path.read_bytes()) if path.is_file() else None
        if live != entry['sha256']:
            mismatches.append({'path': entry['path'], 'expected': entry['sha256'], 'worktree': live})
    if mismatches:
        raise SystemExit('source mismatch; do not run; re-review:\n' + json.dumps(mismatches, indent=2))
    if git('rev-parse', 'HEAD').decode().strip() != head or git('status', '--porcelain', '--untracked-files=no').decode():
        raise SystemExit('source changed during preflight')
    lexical = ROOT / 'policy-engine/production_data'
    physical = Path('/Users/deniskopylov/polisyos/policy-engine/production_data')
    if not lexical.is_symlink() or Path(os.path.realpath(lexical)) != physical:
        raise SystemExit('production_data symlink changed; stop for review')
    guard_dir = HERE / ('guard-' + case)
    guard_receipt = json.loads((guard_dir / 'receipt.json').read_text())
    guard_profile = guard_dir / 'production-outer.sb'
    guard_observation = json.loads(guard_receipt['stdout'])
    if (guard_receipt['return_code'] != 0
        or guard_receipt['case_id'] != case
        or guard_receipt['production_lexical_link'] != str(lexical)
        or guard_receipt['production_physical_target'] != str(physical)
        or guard_receipt['production_profile_sha256'] != sha(guard_profile.read_bytes())
        or guard_observation != {'direct': 'denied', 'symlink': 'denied', 'allowed': True}):
        raise SystemExit('missing or inconsistent synthetic nested read-guard receipt')
    plan_path = D / (case + '.json')
    if (D / case).exists():
        raise SystemExit('case output already exists')
    disk = shutil.disk_usage(D)
    if disk.free < 6 * 1024**3:
        raise SystemExit('D monitor would refuse the 6 GiB free disk floor')
    plan = {
        'case_id': case,
        'source_head': head,
        'source_tree': tree,
        'task_ids': ['C48'],
        'nodes': [SELECTOR],
        'extra_env': {},
        'deadline_seconds': 600,
        'rss_cap_bytes': 2415919104,
        'scope': 'Candidate-only one-axis mean model-input contrast: two Runtime/Foundry completed sources, separate actual planner, scoped fresh GET. No broader authority or P40 closure.',
        'closure_ids': [],
        'c48_source_bindings_sha256': FRAME_SHA256,
        'c48_outer_profile_sha256': sha(guard_profile.read_bytes()),
        'c48_synthetic_guard_receipt_sha256': sha((guard_dir / 'receipt.json').read_bytes()),
        'disk_total_bytes_at_prepare': disk.total,
        'disk_free_bytes_at_prepare': disk.free,
    }
    with plan_path.open('x', encoding='utf-8') as stream:
        json.dump(plan, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'plan_path': str(plan_path), 'plan_sha256': sha(plan_path.read_bytes()), 'head': head, 'tree': tree, 'disk_total_bytes': disk.total, 'disk_free_bytes': disk.free, 'sandbox_and_root_guard': 'require separate checked receipts before launch'}, indent=2))


if __name__ == '__main__':
    main()
