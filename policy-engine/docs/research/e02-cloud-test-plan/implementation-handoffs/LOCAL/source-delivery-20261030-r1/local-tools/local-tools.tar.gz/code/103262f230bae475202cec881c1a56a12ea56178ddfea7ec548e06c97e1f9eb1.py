"""Stdlib-only adversarial physical-boundary check; no product/native imports."""
from pathlib import Path
import ast,json
from types import SimpleNamespace
from physical_inputs import admit,read_bounded
HERE=Path(__file__).resolve().parent
root=HERE/'physical-selfcheck';root.mkdir(exist_ok=False);case=root/'case';case.mkdir();direct=case/'direct';direct.mkdir();session=case/'session';session.mkdir();outside=root/'outside';outside.mkdir();secret=outside/'not-test-input';secret.write_bytes(b'uninspected outside bytes');inside=direct/'catalog.duckdb';inside.write_bytes(b'fixture');(direct/'escaped.duckdb').symlink_to(secret);(direct/'catalog.duckdb.wal').symlink_to(secret);(direct/'dangling.duckdb').symlink_to(direct/'missing-target');(session/'catalog.duckdb').write_bytes(b'session')
original=Path.open;outside_reads=[]
def guarded(self,*args,**kwargs):
 if self.resolve()==secret.resolve():outside_reads.append(str(self));raise AssertionError('outside bytes read')
 return original(self,*args,**kwargs)
Path.open=guarded
try:
 assert read_bounded(admit(inside,case))['raw']==b'fixture'
 assert read_bounded(admit(direct/'absent.duckdb',case))['status']=='absent'
 for p in [secret,direct/'escaped.duckdb',direct/'catalog.duckdb.wal',direct/'dangling.duckdb',direct/'..'/'..'/'outside'/'not-test-input']:
  assert read_bounded(admit(p,case))['status']=='not_established',p
 assert read_bounded(admit(inside,case),cap=3)['status']=='not_established'
 source=ast.parse((HERE/'c32_native_plugin.py').read_bytes());fn=next(n for n in source.body if isinstance(n,ast.FunctionDef) and n.name=='fixture_root');scope={'Path':Path,'admit':admit,'_STATE':{'output':case,'outside_native_inputs':[]}};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<physical-scope-selfcheck>','exec'),scope)
 item=SimpleNamespace(nodeid='static-case',funcargs={'tmp_path':direct});actual_root,role,a=scope['fixture_root'](item,session/'catalog.duckdb');assert a['status']=='admitted' and role=='observed_native_parent_1' and actual_root==session.resolve()
 assert not outside_reads
finally:Path.open=original
print(json.dumps({'direct_input_read':True,'real_absence_distinct':True,'outside_database_wal_traversal_and_dangling_refused_before_byte_read':True,'oversize_refused_before_read':True,'same_case_session_root_admitted':True,'outside_reads':outside_reads,'product_imports':False,'native_runtime':'UNRUN'},indent=2))
