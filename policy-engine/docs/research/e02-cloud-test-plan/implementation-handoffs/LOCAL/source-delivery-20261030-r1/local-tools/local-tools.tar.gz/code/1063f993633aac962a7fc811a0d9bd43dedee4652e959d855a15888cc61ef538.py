from pathlib import Path
p = Path('LOCAL/raw/e02-execution-20261027/repairs/C17-r2/postimages/policy-engine/tests/unit/remediation/test_lex_impact_semantics.py')
s = p.read_text()
def change(old: str, new: str, count: int = 1) -> None:
    global s
    assert s.count(old) == count, (s.count(old), old[:100])
    s = s.replace(old, new)

change('''    one = NormImpactAnalyzer(cas, passes=("legal",), legal_backend="expr_ast").analyze(
        old_pack, new_pack, context={"income": 2}, decision_packet_ref="decision.test"
    )
    duplicate = NormImpactAnalyzer(
        cas, passes=("legal", "legal"), legal_backend="expr_ast"
''', '''    one = NormImpactAnalyzer(
        cas, passes=("legal",), legal_backend="expr_ast", report_schema_version="1.1"
    ).analyze(old_pack, new_pack, context={"income": 2}, decision_packet_ref="decision.test")
    duplicate = NormImpactAnalyzer(
        cas, passes=("legal", "legal"), legal_backend="expr_ast", report_schema_version="1.1"
''')
change('''        "--legal-backend",
        "expr_ast",
        "--cas-root",
''', '''        "--legal-backend",
        "expr_ast",
        "--report-schema-version",
        "1.1",
        "--cas-root",
''')
change('''    assert report.cas_artifact_ref is not None
    persisted, _ = _read_fresh_chain(cas_root, report.cas_artifact_ref)
    assert persisted.metadata["legal_backend"] == "stub"
''', '''    assert report.schema_version == "1.0"
    assert report.cas_artifact_ref is None and report.cas_artifact_id is not None
    assert report.norm_diff_artifact_ref is None
    loaded = load_norm_impact_report(FileSystemCAS(cas_root), report.cas_artifact_id)
    assert loaded.diff_binding == "legacy_unbound" and loaded.diff is not None
    persisted = loaded.report
    assert persisted.metadata["legal_backend"] == "stub"
''')
change('    analyzer = NormImpactAnalyzer(cas, passes=())\n', '    analyzer = NormImpactAnalyzer(cas, passes=(), report_schema_version="1.1")\n')
change('''    produced = NormImpactAnalyzer(cas, passes=("legal",), legal_backend="expr_ast").analyze(
        *_packs()
    )
''', '''    produced = NormImpactAnalyzer(
        cas, passes=("legal",), legal_backend="expr_ast", report_schema_version="1.1"
    ).analyze(*_packs())
''')
change('''    legacy_writer = NormImpactAnalyzer(
        cas, passes=("legal",), legal_backend="expr_ast", report_schema_version="1.0"
    )
''', '''    # No schema option is deliberate: readers must be deployable before any
    # existing writer starts emitting the new schema.
    legacy_writer = NormImpactAnalyzer(cas, passes=("legal",), legal_backend="expr_ast")
''')
change('''    modern = NormImpactAnalyzer(cas, passes=("legal",), legal_backend="expr_ast").analyze(old, new)
''', '''    modern = NormImpactAnalyzer(
        cas, passes=("legal",), legal_backend="expr_ast", report_schema_version="1.1"
    ).analyze(old, new)
''')
change('''    after_rollback = legacy_writer.analyze(old, new)
''', '''    rollback_writer = NormImpactAnalyzer(
        cas, passes=("legal",), legal_backend="expr_ast", report_schema_version="1.0"
    )
    after_rollback = rollback_writer.analyze(old, new)
''')
change('''    assert report.metadata["comparison_context_binding"] == "not_established"
    assert (report.metadata["old_issues_total"], report.metadata["new_issues_total"]) == (1, 1)
''', '''    assert report.metadata["comparison_context_binding"] == "not_established"
    assert report.metadata["declared_old_jurisdiction"] == "ua"
    assert report.metadata["declared_new_jurisdiction"] == "ua"
    assert (report.metadata["old_issues_total"], report.metadata["new_issues_total"]) == (1, 1)
''')

insert = '''def _persist_selected_report_payload(
    cas: FileSystemCAS, payload: dict[str, object], diff_ref: ArtifactRef
) -> ArtifactRef:
    return cas.put_json(
        payload,
        PutOptions(
            kind=NormImpactReport.ARTIFACT_KIND,
            media_type=NormImpactReport.ARTIFACT_MEDIA_TYPE,
            schema=SchemaInfo(name=NormImpactReport.ARTIFACT_SCHEMA_NAME, version="1.1"),
            inputs=[input_ref_from_artifact_ref(diff_ref, role="norm_diff")],
        ),
        return_selected_profile=True,
    )


@pytest.mark.parametrize(
    ("field", "error"),
    [
        ("norms_added", "report_norm_diff_counts_mismatch"),
        ("norms_removed", "report_norm_diff_counts_mismatch"),
        ("norms_modified", "report_norm_diff_counts_mismatch"),
        ("affected_kpis", "report_norm_diff_topics_mismatch"),
        ("report_id", "report_norm_diff_id_mismatch"),
        ("passes_executed", "report_pass_plan_invalid"),
        ("new_blockers", "report_compliance_delta_counts_mismatch"),
        ("resolved_blockers", "report_compliance_delta_counts_mismatch"),
        ("new_warnings", "report_compliance_delta_counts_mismatch"),
        ("resolved_warnings", "report_compliance_delta_counts_mismatch"),
        ("severity_changed", "report_compliance_delta_counts_mismatch"),
        ("jurisdiction", "report_norm_diff_scope_mismatch"),
        ("old_pack_id", "report_norm_diff_scope_mismatch"),
        ("new_pack_id", "report_norm_diff_scope_mismatch"),
        ("declared_new_jurisdiction", "report_declared_jurisdiction_mismatch"),
    ],
)
def test_selected_report_refuses_forged_derived_values(
    tmp_path: Path, field: str, error: str
) -> None:
    """A correct selected edge cannot launder false locally derivable report values."""
    cas = FileSystemCAS(tmp_path / "cas")
    produced = NormImpactAnalyzer(
        cas, passes=("legal",), legal_backend="expr_ast", report_schema_version="1.1"
    ).analyze(*_packs())
    assert produced.cas_artifact_ref is not None and produced.norm_diff_artifact_ref is not None
    received = load_norm_impact_report(FileSystemCAS(cas.root), produced.cas_artifact_ref)
    assert received.diff_binding == "exact_selected" and received.diff is not None
    payload = received.report.model_dump(mode="json")
    if field == "affected_kpis":
        payload[field][0]["affected_norm_ids"] = ["n.fake"]
    elif field == "passes_executed":
        payload[field].append("legal")
    elif field == "declared_new_jurisdiction":
        payload["metadata"][field] = "us"
    elif field in {"jurisdiction", "old_pack_id", "new_pack_id", "report_id"}:
        payload[field] = "counterfeit"
    else:
        payload[field] += 99
    forged = _persist_selected_report_payload(cas, payload, produced.norm_diff_artifact_ref)
    with pytest.raises(ValueError, match=error):
        load_norm_impact_report(FileSystemCAS(cas.root), forged)


@pytest.mark.parametrize(
    "corruption",
    [
        "missing_added_rule",
        "mismatched_norm_id",
        "duplicate_norm_id",
        "false_unchanged",
        "field_delta",
        "diff_summary_count",
    ],
)
def test_selected_report_refuses_incoherent_embedded_diff(
    tmp_path: Path, corruption: str
) -> None:
    """Changes and summary counts are reconstructed from the embedded actual rules."""
    cas = FileSystemCAS(tmp_path / "cas")
    produced = NormImpactAnalyzer(
        cas, passes=("legal",), legal_backend="expr_ast", report_schema_version="1.1"
    ).analyze(*_packs())
    assert produced.cas_artifact_ref is not None
    read = load_norm_impact_report(FileSystemCAS(cas.root), produced.cas_artifact_ref)
    assert read.diff is not None
    diff_payload = read.diff.model_dump(mode="json")
    changes = diff_payload["changes"]
    by_id = {change["norm_id"]: change for change in changes}
    if corruption == "missing_added_rule":
        by_id["n.added"]["new_rule"] = None
    elif corruption == "mismatched_norm_id":
        by_id["n.added"]["norm_id"] = "n.counterfeit"
    elif corruption == "duplicate_norm_id":
        changes.append(deepcopy(by_id["n.added"]))
    elif corruption == "false_unchanged":
        by_id["n.modified"]["change_type"] = "unchanged"
    elif corruption == "field_delta":
        by_id["n.modified"]["field_deltas"][0]["new_value"] = "counterfeit"
    elif corruption == "diff_summary_count":
        diff_payload["added_count"] = 99
    forged_diff = cas.put_json(
        diff_payload,
        PutOptions(
            kind=NormDiff.ARTIFACT_KIND,
            media_type=NormDiff.ARTIFACT_MEDIA_TYPE,
            schema=SchemaInfo(name=NormDiff.ARTIFACT_SCHEMA_NAME, version="1.0"),
        ),
        return_selected_profile=True,
    )
    report_payload = read.report.model_dump(mode="json")
    report_payload["norm_diff_ref"] = str(forged_diff.artifact_id)
    report_payload["norm_diff_artifact_ref"] = forged_diff.model_dump(mode="json")
    forged_report = _persist_selected_report_payload(cas, report_payload, forged_diff)
    with pytest.raises(ValueError, match="selected_norm_diff_inconsistent"):
        load_norm_impact_report(FileSystemCAS(cas.root), forged_report)


def test_cross_jurisdiction_is_declared_for_legacy_and_refused_for_opt_in(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """A legacy comparison may proceed but must not silently hide the new scope."""
    cas = FileSystemCAS(tmp_path / "cas")
    old_pack, new_pack = _packs()
    foreign_pack = new_pack.model_copy(update={"jurisdiction": "us"})
    legacy = NormImpactAnalyzer(cas, passes=()).analyze(old_pack, foreign_pack)
    assert legacy.schema_version == "1.0" and legacy.cas_artifact_id is not None
    received = load_norm_impact_report(FileSystemCAS(cas.root), legacy.cas_artifact_id)
    assert received.diff_binding == "legacy_unbound"
    assert received.report.jurisdiction == "ua"
    assert received.report.metadata["declared_old_jurisdiction"] == "ua"
    assert received.report.metadata["declared_new_jurisdiction"] == "us"
    assert "Input pack declarations differ (old: `ua`, new: `us`)" in render_impact_markdown(
        received.report
    )

    def forbidden_write(*args: object, **kwargs: object) -> None:
        raise AssertionError("mismatched selected report must not persist anything")

    monkeypatch.setattr(cas, "put_json", forbidden_write)
    with pytest.raises(ValueError, match="selected_report_jurisdiction_mismatch"):
        NormImpactAnalyzer(cas, passes=(), report_schema_version="1.1").analyze(
            old_pack, foreign_pack
        )


def test_cli_refuses_cross_jurisdiction_in_opt_in_selected_mode(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    """The CLI signals the incompatible scopes without writing a report."""
    old_pack, new_pack = _packs()
    paths = [tmp_path / "old.json", tmp_path / "new.json"]
    paths[0].write_text(old_pack.model_dump_json(), encoding="utf-8")
    paths[1].write_text(
        new_pack.model_copy(update={"jurisdiction": "us"}).model_dump_json(), encoding="utf-8"
    )
    output = tmp_path / "report.json"
    code = main(
        [
            "lex", "impact", *(str(path) for path in paths),
            "--report-schema-version", "1.1", "--format", "json",
            "--output", str(output), "--cas-root", str(tmp_path / "cas"),
        ]
    )
    captured = capsys.readouterr()
    assert code == 2
    assert "selected_report_jurisdiction_mismatch" in captured.err
    assert captured.out == "" and not output.exists()


'''
change('def test_versioned_reader_first_and_explicit_legacy_writer_rollback(tmp_path: Path) -> None:\n', insert + 'def test_versioned_reader_first_and_explicit_legacy_writer_rollback(tmp_path: Path) -> None:\n')
p.write_text(s)
print('Updated regression proposal: no-option 1.0, opt-in 1.1, independent falsifiers')
