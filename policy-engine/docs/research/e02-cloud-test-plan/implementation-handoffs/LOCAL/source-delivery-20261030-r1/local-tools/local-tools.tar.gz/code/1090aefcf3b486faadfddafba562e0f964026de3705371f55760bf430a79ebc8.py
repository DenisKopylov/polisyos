"""Sparse one-owner diagnostic variants, not repository/environment clones."""
from pathlib import Path
import ast,hashlib,json,subprocess
ROOT=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos');P=Path(__file__).resolve().parent
path='policy-engine/tools/quality/validation/decomposition_preflight.py';current=(ROOT/path).read_text();assert hashlib.sha256(current.encode()).hexdigest()=='bb28c329c41dac89cdfae8e94e59efa837748842f8f672ed031681bdd50dde4d'
tree=ast.parse(current);cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='_DynamicImportBinding');method=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_normalize_negative_execution');lines=current.splitlines(True)
no_norm=''.join(lines[:method.body[0].lineno-1])+('        return None\n')+''.join(lines[method.end_lineno:])
flag='''            # Nominal source identity is not proof of an untransferred deferred effect.
            self._source_code_opaque_effect = True
''';assert current.count(flag)==1
baseline=subprocess.check_output(['git','show','1198d42823137ad588c9138b03c3506fb37707d6:'+path],cwd=ROOT,text=True);assert hashlib.sha256(baseline.encode()).hexdigest()=='f3f286d15017c2c0a9eb0cba3458093d38b6852b7bfecbe825036c0f6145ec56'
variants={'current':current,'without_R9_normalizer':no_norm,'without_R10_deferred_flag':current.replace(flag,'',1),'pre_R9_owner_1198':baseline};records=[]
for name,source in variants.items():
 product=P/'variants'/name/'policy-engine';owner=product/'tools/quality/validation/decomposition_preflight.py';owner.parent.mkdir(parents=True,exist_ok=True);(product/'src').mkdir(exist_ok=True);(product/'pyproject.toml').write_text('# RAW explicit input-root sentinel, not canonical source.\n');owner.write_text(source);ast.parse(source);records.append({'name':name,'owner':str(owner),'sha256':hashlib.sha256(source.encode()).hexdigest()})
(P/'variant-inputs.json').write_text(json.dumps({'canonical_owner_sha256':hashlib.sha256(current.encode()).hexdigest(),'variants':records,'baseline_semantics':'Owner-only controlled interventions with current exact legacy test bytes; not an exact full native base replay or P41 inherited verdict.'},indent=2)+'\n')
print(json.dumps([{'name':r['name'],'sha256':r['sha256']} for r in records]))
