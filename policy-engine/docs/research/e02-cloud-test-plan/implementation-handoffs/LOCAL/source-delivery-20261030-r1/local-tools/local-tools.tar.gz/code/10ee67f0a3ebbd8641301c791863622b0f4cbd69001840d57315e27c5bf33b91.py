"""Prepare source-bound plans for the unchanged retained native runner; never run tests."""

from __future__ import annotations

import argparse
import ast
import datetime
import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
PRODUCT = ROOT / 'policy-engine'
HERE = Path(__file__).resolve().parent
D = PRODUCT / 'docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1'
RUNNER = D / 'run_case_with_tools_r2.py'
OBSERVER = D / 'readset_observer_tools_r1.py'
SUPERVISOR = PRODUCT / 'docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-postfix-709-q2-helper-actual-20261018/supervise.py'
PROPOSAL = ROOT / 'LOCAL/raw/e02-execution-20261027/repairs/C19-r8/manifest.json'
PROPOSAL_SHA = 'b260b944e90410366eb7624c702ad25c27fcc921019767478d5a32011e0fd1e1'
TEST = 'tests/integration/core_runtime/test_acquisition_data_preparation.py'
PILOT = [
 TEST + '::test_actual_l4_legacy_producer_result_remains_usable_by_world_and_predictive',
 TEST + '::test_store_only_acquisition_rows_never_enter_the_authority_band',
 TEST + '::test_acquired_world_is_limited_and_default_authority_reentry_refuses_coherent_forgery',
 TEST + '::test_predictive_observed_intake_refuses_coherent_acquired_rows',
]
HELPERS = [
 'tests/_helpers/semantic_epoch_native.py',
 'tests/unit/runtime/quality/test_acquisition_executor.py',
 'tests/_helpers/world_model_record.py',
 'tests/_helpers/acquisition_production.py',
]


def sha(path: Path) -> str:
 return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args: str) -> str:
 return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def pin(path: Path) -> dict:
 if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(ROOT.resolve()):
  raise SystemExit(f'Input is not a regular checkout file: {path}')
 rel = str(path.relative_to(ROOT))
 blob = git('rev-parse', 'HEAD:' + rel)
 data = subprocess.check_output(['git', 'cat-file', 'blob', blob], cwd=ROOT)
 if hashlib.sha256(data).hexdigest() != sha(path):
  raise SystemExit(f'Worktree differs from admitted HEAD: {rel}')
 return {'path': rel, 'sha256': sha(path), 'git_blob': blob, 'last_change_commit': git('log', '-1', '--format=%H', 'HEAD', '--', rel)}


def census() -> tuple[list[dict], dict[str, int]]:
 cases = []
 for function in ast.parse((PRODUCT / TEST).read_text()).body:
  if not isinstance(function, ast.FunctionDef) or not function.name.startswith('test_'):
   continue
  variants = [{}]
  for decorator in function.decorator_list:
   if isinstance(decorator, ast.Call) and isinstance(decorator.func, ast.Attribute) and decorator.func.attr == 'parametrize':
    variants = [{**prior, ast.literal_eval(decorator.args[0]): value} for prior in variants for value in ast.literal_eval(decorator.args[1])]
  cases.extend({'function': function.name, 'parameters': value} for value in variants)
 counts = {name: sum(case['function'] == name for case in cases) for name in sorted({case['function'] for case in cases})}
 if len(cases) != 31:
  raise SystemExit(f'Test cardinality changed: complete AST denominator={len(cases)}, expected31. Requalify, do not assume old selectors.')
 return cases, counts


def qualify_positive(path: Path, *, stage: str, bindings: list[dict]) -> dict:
 audit = json.loads(path.read_text())
 result = audit['result']
 expected = 5 if stage == 'matrix' else 31
 if not result['complete'] or result['return_code'] != 0 or result.get('aborted_reason') or audit['current_mismatches']:
  raise SystemExit('Prior positive is incomplete, failed, aborted or source-mismatched; followups not admitted.')
 if result['junit'] != {'tests': expected, 'failures': 0, 'errors': 0, 'skipped': 0}:
  raise SystemExit(f'Prior positive must have {expected}PASS/0FAIL/ERROR/SKIP, actual {result.get("junit")}')
 required_nodes = PILOT if stage == 'matrix' else [TEST]
 if audit['plan']['nodes'] != required_nodes:
  raise SystemExit('Prior positive has a different selected scope.')
 if subprocess.run(['git', 'merge-base', '--is-ancestor', audit['plan']['source_head'], 'HEAD'], cwd=ROOT).returncode:
  raise SystemExit('Prior source is not an ancestor of current admitted source.')
 prior = {row['path']: row['sha256'] for row in audit['plan']['source_bindings']}
 for row in bindings:
  if prior.get(row['path']) != row['sha256']:
   raise SystemExit(f'Prior positive does not qualify current deciding input: {row["path"]}')
 loaded = {}
 for row in audit['readsets']:
  readset = ROOT / row['path']
  if sha(readset) != row['sha256']:
   raise SystemExit(f'Prior readset bytes unavailable/mismatched: {readset}')
  for module in json.loads(readset.read_text())['modules']:
   loaded[module['path']] = module['sha256']
 mismatches = [name for name, digest in loaded.items() if not (PRODUCT / name).is_file() or sha(PRODUCT / name) != digest]
 if mismatches:
  raise SystemExit(f'Prior finite imported-source proof stale at {len(mismatches)} paths: {mismatches[:8]}')
 return {'path': str(path.relative_to(ROOT)), 'sha256': sha(path), 'source_head': audit['plan']['source_head'], 'scope': required_nodes, 'counts': result['junit'], 'all_prior_loaded_python_paths_rechecked': len(loaded), 'wall_seconds': result['wall_seconds'], 'max_sampled_process_tree_rss_bytes': result['max_sampled_process_tree_rss_bytes'], 'qualification': 'Prior positive on unchanged deciding files/profile and complete finite imported Python readset; no automatic whole-repository PASS.'}


def main() -> None:
 parser = argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--admitted-head', required=True)
 parser.add_argument('--case-prefix', required=True)
 parser.add_argument('--stage', choices=['pilot', 'matrix', 'controls'], required=True)
 parser.add_argument('--positive-audit', type=Path)
 parser.add_argument('--deadline-seconds', type=int)
 parser.add_argument('--rss-cap-gib', type=float, default=3.0)
 parser.add_argument('--minimum-free-gib', type=float, default=8.0)
 args = parser.parse_args()
 if not args.case_prefix or any(not (c.isalnum() or c in '-_') for c in args.case_prefix):
  raise SystemExit('Case prefix must be nonempty alphanumeric/hyphen/underscore.')
 if git('symbolic-ref', '--short', 'HEAD') != 'codex/e02-unified-local-20261009':
  raise SystemExit('Wrong branch; report actual state, never switch.')
 head = git('rev-parse', 'HEAD'); tree = git('rev-parse', 'HEAD^{tree}')
 if head != args.admitted_head:
  raise SystemExit(f'HEAD mismatch: expected {args.admitted_head}, actual {head}; re-admit explicitly.')
 if git('status', '--porcelain', '--untracked-files=no'):
  raise SystemExit('Tracked/index state is dirty; root must resolve its owned state before native proof.')
 if sha(PROPOSAL) != PROPOSAL_SHA:
  raise SystemExit('Frozen preferred proposal manifest bytes changed.')
 proposal = json.loads(PROPOSAL.read_text())
 source_paths = []
 for row in proposal['files']:
  path = ROOT / row['path']
  if sha(path) != row['postimage_sha256']:
   raise SystemExit(f'Current source differs from reviewed proposal: {row["path"]}. Qualify a named delta; do not assume a new source is accepted.')
  source_paths.append(path)
 for row in proposal['context_companions']:
  path = ROOT / row['path']
  if sha(path) != row['candidate_postimage_sha256']:
   raise SystemExit(f'Composed context changed: {row["path"]}. Review actual merged preimage before replacing this source admission.')
  source_paths.append(path)
 source_paths += [PRODUCT / item for item in HELPERS]
 source_paths += [PRODUCT / 'pytest.ini', PRODUCT / 'pyproject.toml', PRODUCT / 'uv.lock']
 bindings = [pin(path) for path in source_paths]
 cases, counts = census()
 if sum(counts[node.split('::')[1]] for node in PILOT) != 5:
  raise SystemExit('Pilot source cardinality changed.')
 free = shutil.disk_usage(ROOT).free
 if args.minimum_free_gib < 6 or free < args.minimum_free_gib * 1024**3:
  raise SystemExit(f'Insufficient admitted disk reserve: free={free}, requestedGiB={args.minimum_free_gib}; supervisor hard floor remains6GiB.')
 prior = None
 if args.stage != 'pilot':
  if args.positive_audit is None or not args.positive_audit.is_absolute():
   raise SystemExit('Provide an absolute prior positive audit: pilot5PASS before matrix, matrix31PASS before controls.')
  prior = qualify_positive(args.positive_audit, stage=args.stage, bindings=bindings)
 elif args.positive_audit is not None:
  raise SystemExit('Pilot does not consume a prior proof; measure this first new-cost profile alone.')
 runner_pins = {str(path.relative_to(ROOT)): sha(path) for path in [RUNNER, OBSERVER, SUPERVISOR]}
 plans = []
 def add(suffix: str, nodes: list[str], expected: dict, extra_env: dict | None = None):
  case_id = args.case_prefix + '-' + suffix
  path = D / (case_id + '.json')
  if path.exists() or (D / case_id).exists():
   raise SystemExit(f'Refusing to overwrite retained plan/output: {case_id}')
  deadline = args.deadline_seconds or (600 if args.stage == 'pilot' else 1200 if args.stage == 'matrix' else 600)
  plan = {'case_id': case_id, 'source_head': head, 'source_tree': tree, 'task_ids': ['V3-U1a', 'C19'], 'nodes': nodes, 'extra_env': extra_env or {}, 'deadline_seconds': deadline, 'rss_cap_bytes': int(args.rss_cap_gib * 1024**3), 'scope': 'C19 recognized-acquired lineage: actual native-owner preparation, uniform typed generic/candidate results, default protected refusal, WMR limited/blocker lifecycle and predictive strict intake. Controlled L4 source projection is program-contract evidence, never production provenance. No whole V3/E02/G closure.', 'source_bindings': bindings, 'runner_bindings': runner_pins, 'proposal_manifest_sha256': PROPOSAL_SHA, 'expected_result': expected, 'prior_positive': prior, 'resource_admission': {'pilot_alone': args.stage == 'pilot', 'root_compute_slot_required': True, 'free_disk_bytes_at_preparation': free, 'minimum_free_gib': args.minimum_free_gib, 'supervisor_hard_floor_gib': 6, 'policy': 'One first-cost pilot alone; RSS is a process-tree bound, not available RAM. Reuse environments. Matrix/controls only after qualifying positive. No concurrent tracked-source/index/ref mutations during a native run.'}, 'profile': 'Unchanged D retained supervisor and native pytest.ini/default plugins/importlib/strict markers; normal numeric thread profile. Additional plugins only for declared one-case in-memory controls.', 'closure_ids': []}
  plans.append((path, plan))
 if args.stage == 'pilot':
  add('pilot', PILOT, {'outcome': 'PASS', 'tests': 5, 'failures': 0, 'errors': 0, 'skipped': 0, 'new_cost_measurement': 'Run alone; use actual RSS/wall/disk samples to admit followups.'})
 elif args.stage == 'matrix':
  add('matrix', [TEST], {'outcome': 'PASS', 'tests': 31, 'failures': 0, 'errors': 0, 'skipped': 0, 'scope': 'Complete unfiltered module; expected AST count must agree with actual collection/JUnit.'})
 else:
  producer = ROOT / proposal['producer_removal_plugin']['path']; reader = ROOT / proposal['reader_removal_plugin']['path']; selector = HERE / 'select_native_case.py'
  for path, expected in [(producer, proposal['producer_removal_plugin']['sha256']), (reader, proposal['reader_removal_plugin']['sha256'])]:
   if sha(path) != expected: raise SystemExit(f'Frozen control plugin mismatch: {path}')
  source_sha = sha(PRODUCT / 'src/polisyos/runtime/quality/data_state_substrate.py'); reader_sha = sha(PRODUCT / 'src/polisyos/runtime/quality/data_snapshot_lineage.py'); test_sha = sha(PRODUCT / TEST)
  for mode, node, reason in [('executor_owner', TEST+'::test_resigned_preparation_cannot_replace_fresh_owner_result[payload]', 'DID NOT RAISE acquisition_preparation_owner_state_changed after genuine preparation and re-signing'), ('no_write', TEST+'::test_preparation_has_no_cas_write_and_materialization_rechecks_actual_owner', 'writes == [] fails after an exact same-selected-view idempotent real put')]:
   suffix='remove-'+mode.replace('_','-'); out=D/(args.case_prefix+'-'+suffix); env={'PYTHONPATH':os.pathsep.join([str(producer.parent),str(PRODUCT/'src')]),'PYTEST_PLUGINS':'c19_removal_plugin','C19_CONTROL_PLUGIN_SHA256':sha(producer),'C19_CONTROL_SOURCE_SHA256':source_sha,'C19_CONTROL_TEST_SHA256':test_sha,'C19_CONTROL_SOURCE_HEAD':head,'C19_CONTROL_OUTPUT':str(out),'C19_CONTROL_MODE':mode};add(suffix,[node],{'outcome':'expected FAIL','tests':1,'errors':0,'skipped':0,'distinguishing_signal':reason,'required_custody':'active-control.py and control-mutation.json; original_function_restored true; no source mutation; setup/backend/other assertion is ERROR, not control success'},env)
  for mode,function,params,total,reason in [('codec','test_fresh_lineage_consumer_rejects_wrong_epoch_codec_and_unbound_profile',{'member':'passport_ref','invalid':'media'},8,'named pytest.raises DataSnapshotLineageError no longer raises after actual Core codec refusal is wrongly ignored'),('authority_band','test_store_only_acquisition_rows_never_enter_the_authority_band',{'forge':True},2,'named pytest.raises DataSnapshotSourceRowNotEstablishedError no longer raises; this removes reader API refusal, not every WMR/PCL defense')]:
   suffix='remove-reader-'+mode.replace('_','-');out=D/(args.case_prefix+'-'+suffix);env={'PYTHONPATH':os.pathsep.join([str(HERE),str(reader.parent),str(PRODUCT/'src')]),'PYTEST_PLUGINS':'select_native_case,c19_reader_removal_plugin','C19_READER_CONTROL_PLUGIN_SHA256':sha(reader),'C19_READER_CONTROL_SOURCE_SHA256':reader_sha,'C19_READER_CONTROL_TEST_SHA256':test_sha,'C19_READER_CONTROL_SOURCE_HEAD':head,'C19_READER_CONTROL_OUTPUT':str(out),'C19_READER_CONTROL_MODE':mode,'C19_NATIVE_SELECTION_PLUGIN_SHA256':sha(selector),'C19_NATIVE_SELECTION_TEST_SHA256':test_sha,'C19_NATIVE_SELECTION_SOURCE_HEAD':head,'C19_NATIVE_SELECTED_CASE':json.dumps({'function':function,'parameters':params,'expected_collected':total},sort_keys=True)};add(suffix,[TEST+'::'+function],{'outcome':'expected FAIL','tests':1,'errors':0,'skipped':0,'distinguishing_signal':reason,'selection':'exact callspec semantic values, recorded selected/deselected IDs; no guessed parameter-ID order','required_custody':'semantic-case-selection.json, active-control.py, control-mutation.json; original_function_restored true, unchanged source bytes'},env)
 if git('rev-parse','HEAD') != head or git('status','--porcelain','--untracked-files=no'):
  raise SystemExit('Canonical state changed while preparing; no plans written.')
 for path, plan in plans:
  with path.open('x') as stream: stream.write(json.dumps(plan,indent=2)+'\n')
 receipt={'at':datetime.datetime.now(datetime.UTC).isoformat(),'source_head':head,'source_tree':tree,'stage':args.stage,'generator_sha256':sha(Path(__file__)),'plans':[{'path':str(path),'sha256':sha(path),'expected':plan['expected_result']} for path,plan in plans],'complete_AST_test_count':len(cases),'source_bindings':bindings,'runner_bindings':runner_pins,'prior_positive':prior,'native_tests_executed':False,'no_source_index_ref_mutation':True}
 out=HERE/(args.case_prefix+'-'+args.stage+'-preparation.json')
 with out.open('x') as stream: stream.write(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({'source_head':head,'source_tree':tree,'stage':args.stage,'plans':[str(path) for path,_ in plans],'preparation_receipt':str(out),'native_tests_executed':False},indent=2))

if __name__ == '__main__':
 main()
