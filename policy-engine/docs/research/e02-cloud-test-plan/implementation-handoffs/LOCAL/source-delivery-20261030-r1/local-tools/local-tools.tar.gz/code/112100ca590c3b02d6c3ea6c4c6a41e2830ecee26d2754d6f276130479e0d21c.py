import hashlib, json, os, platform, resource, subprocess, sys, time
from pathlib import Path
from importlib import metadata
from xml.etree import ElementTree
INPUT=Path('/evidence/i2-r81')
OUT=INPUT/'run-output'
BINDING=INPUT/'launch-input-binding.json'
CORE=INPUT/'source-admission'/'source-admission.json'
REMOTE=INPUT/'remote-readback.json'
EXPECTED_BINDING_SHA256='c5061fed0189055898a6e512fcad2daa7e6fd9fd6c97a99a67aeac58fac8ddd0'
EXPECTED_CORE_SHA256='aa6b58050dbf55e5fb21a30b75747651dec2677ee2972cfcabc3bf27cdc73f3d'
EXPECTED_NAMES={
    'test_dfk_01_census_reads_native_invalid_byte_git_filename',
    'test_dfk_01_native_invalid_byte_removal_control_detects_lossy_fsdecode',
}
def write(name,value):
    with (OUT/name).open('x') as f: json.dump(value,f,indent=2,sort_keys=True); f.write('\n')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def cg():
    result={}
    for name in ('memory.events','memory.peak','memory.current','memory.max','cpu.max'):
        p=Path('/sys/fs/cgroup')/name
        result[name]=p.read_text() if p.exists() else None
    return result
a=json.loads(BINDING.read_text())
core=json.loads(CORE.read_text())
remote=json.loads(REMOTE.read_text())
assert sha(BINDING)==EXPECTED_BINDING_SHA256
assert sha(CORE)==EXPECTED_CORE_SHA256
assert a['source']['head']=='992c333d3d2d14b4f113a58e5179625a95573aac'
assert a['source']['tree']=='15c63c42000f7cb45ec63cfceb9e030cc159df70'
assert core['base']==a['source']['head'] and core['head']==a['source']['head'] and core['tree']==a['source']['tree']
assert core['tracked_changed']==[] and core['untracked_source']==[]
assert core['git_index_entries']==7674 and core['initial_pycache_empty'] is True
core_pins={row['path']:row for row in core['pins']}
assert len(core_pins)==len(a['source']['host_pins'])==19
assert a['environment']['all_43_expected_versions_match'] and a['environment']['expected_distribution_count']==43
for row in a['source']['host_pins']: assert core_pins[row['path']]['sha256']==row['sha256'] and core_pins[row['path']]['git_blob']==row['git_blob']
assert sha(REMOTE)==a['source']['publication_readback_sha256']
assert remote['head']==a['source']['head'] and remote['tree']==a['source']['tree']
assert remote['remote_head']==a['source']['head'] and remote['remote_tree']==a['source']['tree']
assert remote['remote_ref']==a['source']['publication_ref']
assert sys.platform=='linux' and sys.version_info[:3]==(3,14,3)
assert not any(n=='polisyos' or n.startswith(('polisyos.','tools.')) for n in sys.modules)
for row in a['container']['runtime_mount_pins']: assert sha(row['container_path'])==row['sha256'],row
versions={n:metadata.version(n) for n in a['environment']['expected_distributions']}
assert versions==a['environment']['expected_distributions']
case=Path('/scratch/i2-r81/run')
if os.path.lexists(OUT): raise SystemExit('r81_output_path_exists')
assert not os.path.lexists(case.parent),str(case.parent)
for p in (case,case/'tmp',case/'cache',case/'benchmarks'):
    assert not os.path.lexists(p),str(p)
    for parent in p.parents: assert not parent.is_symlink(),str(parent)
case.parent.mkdir()
case.mkdir()
mounts=Path('/proc/self/mountinfo').read_text()
assert any(' /scratch ' in line and ' - ext4 ' in line for line in mounts.splitlines())
OUT.mkdir()
argv=['-o','cache_dir='+str(case/'cache'),'--basetemp='+str(case/'tmp'),'--benchmark-storage=file://'+str(case/'benchmarks'),'--junitxml='+str(OUT/'r81.xml'),'tests/unit/remediation/test_dfk_01.py::test_dfk_01_census_reads_native_invalid_byte_git_filename','tests/unit/remediation/test_dfk_01.py::test_dfk_01_native_invalid_byte_removal_control_detects_lossy_fsdecode']
write('r81-admission.json',{'source_binding_sha256':sha(BINDING),'source_admit_core_sha256':sha(CORE),'publication_readback_sha256':sha(REMOTE),'mapped_pins':a['container']['runtime_mount_pins'],'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'filesystem_encoding':sys.getfilesystemencoding(),'filesystem_errors':sys.getfilesystemencodeerrors(),'git':subprocess.check_output(['git','--version'],text=True).strip(),'distributions':versions,'cgroup_before':cg(),'argv':argv,'mountinfo':mounts,'scope':'Two selected DFK-01 tests; finite end-of-session module origins only; child CLI process origins and C134 CodeType binding not established'})
start=time.monotonic()
code=None
error=None
junit=None
try:
    import pytest
    code=int(pytest.main(argv))
except BaseException as exc:
    error={'type':type(exc).__name__,'repr':repr(exc)}
    raise
finally:
    junit_path=OUT/'r81.xml'
    if junit_path.is_file():
        root=ElementTree.parse(junit_path).getroot()
        cases=list(root.iter('testcase'))
        counts={'tests':len(cases),'passed':0,'failures':0,'errors':0,'skipped':0,'names':sorted(c.attrib.get('name','') for c in cases)}
        for item in cases:
            children={child.tag for child in item}
            if 'failure' in children: counts['failures']+=1
            elif 'error' in children: counts['errors']+=1
            elif 'skipped' in children: counts['skipped']+=1
            else: counts['passed']+=1
        junit=counts
    if error is not None or junit is None or junit['tests']!=2 or set(junit['names'])!=EXPECTED_NAMES or junit['skipped']:
        classification='HARNESS_ERROR'
    elif junit['failures']:
        classification='SEMANTIC_FAIL'
    elif junit['errors']:
        classification='TEST_ERROR'
    elif code==0 and junit['passed']==2:
        classification='PASS'
    else:
        classification='HARNESS_ERROR'
    rows={}
    for name,module in list(sys.modules.items()):
        origin=getattr(module,'__file__',None)
        if not isinstance(origin,str): continue
        p=Path(origin)
        if p.is_file() and any(str(p).startswith(prefix) for prefix in ('/tmp/src/','/tmp/tests/','/tmp/tools/')):
            rows[str(p)]={'sha256':sha(p),'module_names':[],'bytes':p.stat().st_size}
    for name,module in list(sys.modules.items()):
        origin=getattr(module,'__file__',None)
        if origin in rows: rows[origin]['module_names'].append(name)
    for row in a['container']['runtime_mount_pins']: assert sha(row['container_path'])==row['sha256'],row
    assert sha(REMOTE)==a['source']['publication_readback_sha256']
    write('r81-result.json',{'classification':classification,'returncode':code,'error':error,'junit':junit,'wall_seconds':time.monotonic()-start,'ru_maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'cgroup_after':cg(),'source_binding_sha256':sha(BINDING),'source_admit_core_sha256':sha(CORE),'publication_readback_sha256':sha(REMOTE),'finite_end_session_loaded_modules':rows,'scope':'Two selected tests only; second node covers absent/present collision, lossy decoder removal and restored consumer. Finite parent-process module origins only; child CLI imports and C134 CodeType origins not established.','closure_ids':[],'G_acceptance':False})
if code is not None: raise SystemExit(code)
