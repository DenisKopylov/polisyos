"""Tiny RAW-only plan write controls; no real case/preparer or product imports."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os

package = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('t02_prepare_control', package/'prepare_t02.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
output = package/'filesystem-controls-r1'
output.mkdir(exist_ok=False)
results = []
regular = output/'regular.json'
regular.write_bytes(b'{"before":1}\n')
module.stage_exact_plan(regular, b'{"before":1}\n', b'{"after":2}\n')
assert regular.read_bytes() == b'{"after":2}\n'
results.append({'case':'regular-owned-exact-preimage-write','status':'PASS'})
for name, create in [
    ('symlink', lambda p: p.symlink_to(regular)),
    ('hardlink', lambda p: os.link(regular,p)),
]:
    target=output/(name+'.json')
    create(target)
    before=regular.read_bytes()
    try:
        module.stage_exact_plan(target, before, b'wrong')
    except (OSError,RuntimeError):
        pass
    else:
        raise AssertionError('unsafe '+name+' was accepted')
    assert regular.read_bytes()==before
    results.append({'case':name+'-refused-no-foreign-write','status':'PASS'})
# The preceding hard link is deliberately preserved; use a new single-link file.
changed = output/'changed.json'
changed.write_bytes(b'actual')
try:
    module.stage_exact_plan(changed,b'stale',b'wrong')
except RuntimeError as error:
    assert str(error)=='plan preimage differs'
else:
    raise AssertionError('stale preimage accepted')
assert changed.read_bytes()==b'actual'
results.append({'case':'stale-preimage-refused','status':'PASS'})
parent_link = output/'symlink-parent'
parent_link.symlink_to(output,target_is_directory=True)
try:
    module.require_fresh(parent_link/'future-plan.json')
except RuntimeError:
    pass
else:
    raise AssertionError('symlink parent accepted')
results.append({'case':'symlink-parent-refused','status':'PASS'})
dangling = output/'dangling'
dangling.symlink_to(output/'absent-target')
try:
    module.require_fresh(dangling)
except RuntimeError:
    pass
else:
    raise AssertionError('dangling output accepted')
results.append({'case':'lexists-dangling-output-refused','status':'PASS'})
report={'results':results,'product_imports':False,'generic_helper_execution':'UNRUN','native_case_created':False}
(output/'results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'PASS','controls':len(results),'native_case':'UNRUN'}))
