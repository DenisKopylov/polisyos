from pathlib import Path
import hashlib,json
R=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
O=Path(__file__).resolve().parent
pins={}
def patch(rel, replacements):
    p=R/rel;b=p.read_bytes();pins[rel]=hashlib.sha256(b).hexdigest();s=b.decode()
    for old,new in replacements:
        assert s.count(old)==1,(rel,old,s.count(old));s=s.replace(old,new)
    q=O/'postimages'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(s)
new_class='''class ArtifactChildReleaseInfo(BaseModel):
    """Bind a managed staged occurrence to its owner-controlled release session.

    This is an identity link, never a release permission or an isolation claim.
    Missing or unresolved release state refuses reads of the selected view.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    schema_version: Literal["1.0"] = "1.0"
    release_id: str = Field(pattern=r"^[0-9a-f]{32}$")
    scope_id: str = Field(pattern=r"^[0-9a-f]{32}$")
    binding_sha256: str = Field(pattern=r"^sha256:[0-9a-f]{64}$")
    served_store_identity: str = Field(pattern=r"^sha256:[0-9a-f]{64}$")
    root_run_id: str = Field(min_length=1)
    child_run_id: str = Field(min_length=1)


'''
patch('policy-engine/src/polisyos/core/artifacts/manifest.py',[
 ('class ArtifactManifest(BaseModel):',new_class+'class ArtifactManifest(BaseModel):'),
 ('    authority: ArtifactAuthorityInfo | None = None\n\n    integrity:', '    authority: ArtifactAuthorityInfo | None = None\n    child_release: ArtifactChildReleaseInfo | None = Field(\n        default=None, exclude_if=lambda value: value is None\n    )\n\n    integrity:'),
 ('        return self\n\n\n', '        if self.child_release is not None and self.manifest_schema_version != "v3":\n            raise ValueError("child release metadata requires manifest schema v3")\n        return self\n\n\n')
])
patch('policy-engine/src/polisyos/core/artifacts/write_contract.py',[
 ('        ArtifactAuthorityInfo,\n','        ArtifactAuthorityInfo,\n        ArtifactChildReleaseInfo,\n'),
 ('    authority: ArtifactAuthorityInfo | None = None\n','    authority: ArtifactAuthorityInfo | None = None\n    child_release: ArtifactChildReleaseInfo | None = None\n')])
# Both constructor and expected-write comparison use this field.
p=R/'policy-engine/src/polisyos/core/artifacts/_manifest_lifecycle.py';b=p.read_bytes();pins[str(p.relative_to(R))]=hashlib.sha256(b).hexdigest();s=b.decode();old='            "authority": getattr(opts, "authority", None),\n';assert s.count(old)==2;s=s.replace(old,old+'            "child_release": getattr(opts, "child_release", None),\n');q=O/'postimages'/p.relative_to(R);q.parent.mkdir(parents=True,exist_ok=True);q.write_text(s)
patch('policy-engine/src/polisyos/ir/artifacts/contracts.py',[
 ('    authority: _MetadataOption | None = None\n','    authority: _MetadataOption | None = None\n    child_release: _MetadataOption | None = None\n')])
patch('policy-engine/src/polisyos/core/artifacts/ir_adapter.py',[
 ('from .manifest import (\n    ArtifactAuthorityInfo,\n','from .manifest import (\n    ArtifactAuthorityInfo,\n    ArtifactChildReleaseInfo,\n'),
 ('    "authority": lambda value, name: _coerce_model(value, ArtifactAuthorityInfo, name),\n','    "authority": lambda value, name: _coerce_model(value, ArtifactAuthorityInfo, name),\n    "child_release": lambda value, name: _coerce_model(value, ArtifactChildReleaseInfo, name),\n'),
 ('        ArtifactAuthorityInfo: {},\n','        ArtifactAuthorityInfo: {},\n        ArtifactChildReleaseInfo: {},\n'),
 ('        "authority": ArtifactAuthorityInfo,\n','        "authority": ArtifactAuthorityInfo,\n        "child_release": ArtifactChildReleaseInfo,\n')])
patch('policy-engine/src/polisyos/core/artifacts/__init__.py',[
 ('    ArtifactGovernanceInfo,\n','    ArtifactChildReleaseInfo,\n    ArtifactGovernanceInfo,\n'),
 ('    "ArtifactAuthorityInfo",\n','    "ArtifactAuthorityInfo",\n    "ArtifactChildReleaseInfo",\n')])
(O/'metadata-preimages.json').write_text(json.dumps(pins,indent=2)+'\n')
print(json.dumps({'metadata_postimages':len(pins),'canonical_changes':False}))
