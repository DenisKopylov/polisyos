from pathlib import Path
p=Path(__file__).parent/'postimages/policy-engine/src/polisyos/fabric/connectors/federation/composer.py'
s=p.read_text().replace('import json\n','import json\nimport weakref\n')
s=s.replace('from polisyos.core.canon import content_hash\n','')
s=s.replace('from polisyos.fabric.connectors.federation.resolver import ConflictResolver\n','from polisyos.fabric.connectors.federation.profile import (\n    MAX_CELLS, MAX_COLUMNS, MAX_FILE_BYTES, MAX_ROWS, MAX_SOURCES,\n    admit_frame, admit_shape, bounded_encode, frame_digest,\n)\nfrom polisyos.fabric.connectors.federation.resolver import ConflictResolver\n',1)
s=s.replace('type _LineageMap = dict[str, SourceMetadata | None]', '''@dataclass(frozen=True)
class _CellSource:
    token: str
    declaration: str

    def metadata(self) -> SourceMetadata:
        return _restore_source_declaration(json.loads(self.declaration))


type _LineageMap = dict[str, tuple[_CellSource, ...]]

# Values are immutable bytes, and weak references release receipts with their
# exact owner-produced carrier. Dataframe attrs never admit their own basis.
_OWNED_BASIS: dict[int, tuple[weakref.ReferenceType[pd.DataFrame], str, bytes]] = {}''')
a=s.index('def _lineage_map('); b=s.index('\n\ndef _source_declaration',a)
s=s[:a]+'''def _lineage_map(value: object) -> _LineageMap:
    """Copy an internal relation; only owner-produced immutable origins qualify."""
    if value is None or _is_missing_scalar(value):
        return {}
    if not isinstance(value, dict) or not all(
        isinstance(key, str) and isinstance(origins, tuple)
        and all(isinstance(origin, _CellSource) for origin in origins)
        for key, origins in value.items()
    ):
        raise FederationError("Invalid internal federation cell basis")
    return dict(value)


def _frame_content_id(frame: pd.DataFrame) -> str:
    return frame_digest(frame)
''' +s[b:]
a=s.index('def _source_token('); b=s.index('\n\ndef _restore_source_declaration',a)
s=s[:a]+'''def _input_lineage(frame: pd.DataFrame, metadata: SourceMetadata, position: int) -> list[_LineageMap]:
    """Resolve owned derived cells or admit one exact declared leaf occurrence."""
    owned = _read_persisted_lineage(frame)
    if owned is not None:
        return owned
    declaration = bounded_encode(_source_declaration(metadata)).decode()
    # Exact supported content and selected occurrence distinguish duplicate
    # declarations and duplicate identical payloads without inventing issuers.
    import hashlib

    digest = hashlib.sha256(bounded_encode([frame_digest(frame), declaration, position])).hexdigest()
    origin = _CellSource(f"{metadata.connector_id}@{digest}", declaration)
    return [
        {column: (origin,) for column in frame.columns if not _is_missing_scalar(value)}
        for row in frame.itertuples(False, None)
        for values in [dict(zip(frame.columns, row, strict=True))]
        for value in [None]
    ] if False else [
        {column: (origin,) for column, value in zip(frame.columns, row, strict=True)
         if not _is_missing_scalar(value)}
        for row in frame.itertuples(False, None)
    ]
''' +s[b:]
a=s.index('def _read_persisted_lineage('); b=s.index('\n\nclass MergeLogCollector',a)
s=s[:a]+'''def _read_persisted_lineage(frame: pd.DataFrame) -> list[_LineageMap] | None:
    """Resolve an exact owner-held basis; a checksum over attrs is not custody."""
    owned = _OWNED_BASIS.get(id(frame))
    if owned is None or owned[0]() is not frame:
        if _LINEAGE_ATTR in frame.attrs:
            raise FederationError("Unverified lineage attrs require a selected parent")
        return None
    if owned[1] != frame_digest(frame):
        raise FederationError("Owned federation carrier changed after production")
    artifact = json.loads(owned[2])
    if _LINEAGE_ATTR in frame.attrs and bounded_encode(frame.attrs[_LINEAGE_ATTR]) != owned[2]:
        raise FederationError("Owned federation lineage projection changed")
    declarations = artifact["source_declarations"]
    origins = {token: _CellSource(token, bounded_encode(value).decode())
               for token, value in declarations.items()}
    return [
        {column: tuple(origins[token] for token in ([tokens] if isinstance(tokens, str) else tokens))
         for column, tokens in row.items()}
        for row in artifact["rows"]
    ]


def _attach_persisted_lineage(frame: pd.DataFrame, lineage: list[_LineageMap]) -> None:
    """Publish a bounded projection while retaining a separate immutable owner basis."""
    if len(lineage) != len(frame):
        raise FederationError("Incomplete federation cell relation")
    declarations: dict[str, dict[str, Any]] = {}
    rows: list[dict[str, Any]] = []
    relation_bytes = 0
    for row in lineage:
        encoded = {}
        for column, origins in row.items():
            if not origins:
                continue
            tokens = []
            for origin in origins:
                declarations.setdefault(origin.token, json.loads(origin.declaration))
                tokens.append(origin.token)
            encoded[column] = tokens[0] if len(tokens) == 1 else tokens
        relation_bytes += len(bounded_encode(encoded)) + 1
        if relation_bytes > MAX_FILE_BYTES // 2:
            raise FederationError("Federation cell relation exceeds engineering byte profile")
        rows.append(encoded)
    artifact = {
        "version": 2, "content_id": frame_digest(frame),
        "source_identity": "exact_selected_occurrence_consumer_declared_issuer",
        "source_declarations": declarations, "rows": rows,
    }
    payload = bounded_encode(artifact, MAX_FILE_BYTES // 2)
    identity = id(frame)
    ref = weakref.ref(frame, lambda _ref: _OWNED_BASIS.pop(identity, None))
    _OWNED_BASIS[identity] = (ref, artifact["content_id"], payload)
    frame.attrs[_LINEAGE_ATTR] = json.loads(payload)


def _origins_metadata(origins: tuple[_CellSource, ...]) -> SourceMetadata | None:
    if not origins:
        return None
    if len(origins) != 1:
        raise FederationError(
            "Aggregate cell cannot be ranked as a single declared leaf; selected aggregate limitation"
        )
    return origins[0].metadata()
''' +s[b:]
s=s.replace('''        sources = list(sources)

        collector''','''        sources = list(sources)
        if len(sources) > MAX_SOURCES:
            raise FederationError("Federation source count exceeds engineering profile")
        total_rows = 0
        for frame, _metadata in sources:
            admit_frame(frame)
            _read_persisted_lineage(frame)
            total_rows += len(frame)
        columns = set().union(*(set(frame.columns) for frame, _ in sources))
        if strategy != CompositionStrategy.JOIN:
            admit_shape(total_rows, len(columns))

        collector''')
# UNION: occurrence marker becomes ordinal row identity, source relation tracks independently.
s=s.replace('''        for df, metadata in sources:
            df_copy = df.copy()
''','''        row_bases: dict[int, _LineageMap] = {}
        ordinal = 0
        for position, (df, metadata) in enumerate(sources):
            basis = _input_lineage(df, metadata, position)
            df_copy = df.copy()
''',1)
s=s.replace('''            df_copy[source_column] = _source_token(metadata)
            all_rows.append(df_copy)''','''            identifiers = list(range(ordinal, ordinal + len(df)))
            row_bases.update(zip(identifiers, basis, strict=True))
            df_copy[source_column] = identifiers
            ordinal += len(df)
            all_rows.append(df_copy)''')
s=s.replace('''        source_lookup = {_source_token(meta): meta for _, meta in sources}

        resolved_rows = []''','''        metadata_lookup = {}
        ordinal = 0
        for frame, metadata in sources:
            metadata_lookup.update((index, metadata) for index in range(ordinal, ordinal + len(frame)))
            ordinal += len(frame)

        resolved_rows = []
        resolved_lineage: list[_LineageMap] = []''')
s=s.replace('''                resolved_rows.append(group.iloc[0].drop(labels=[source_column]))
                continue''','''                row = group.iloc[0]
                resolved_rows.append(row.drop(labels=[source_column]))
                resolved_lineage.append(row_bases[int(row[source_column])])
                continue''')
s=s.replace('''                metadata = source_lookup[source_id]''','''                metadata = metadata_lookup[int(source_id)]''')
s=s.replace('''            resolved_rows.append(pd.Series(resolution.chosen_candidate.value))''','''            chosen = next(index for index, candidate in enumerate(candidates)
                          if candidate is resolution.chosen_candidate)
            resolved_rows.append(pd.Series(resolution.chosen_candidate.value))
            resolved_lineage.append(row_bases[int(group.iloc[chosen][source_column])])''')
s=s.replace('''            return combined.drop(columns=[source_column]).iloc[:0].copy()''','''            empty = combined.drop(columns=[source_column]).iloc[:0].copy()
            _attach_persisted_lineage(empty, [])
            return empty''')
s=s.replace('''        result = result.sort_values(by=key_columns, kind="mergesort").reset_index(drop=True)

        return result''','''        # groupby already emits canonical key order; preserve the corresponding relation.
        result = result.reset_index(drop=True)
        _attach_persisted_lineage(result, resolved_lineage)
        return result''',1)
s=s.replace('''        persisted_lineage = _read_persisted_lineage(result_df)''','''        persisted_lineage = _input_lineage(result_df, first_metadata, 0)''')
a=s.index('        initial_lineage:'); b=s.index('        result_df[lineage_column]',a)
s=s[:a]+'''        initial_lineage = persisted_lineage
'''+s[b:]
s=s.replace('''        for df, metadata in sources[1:]:
            df_copy = df.copy().reset_index(drop=True)''','''        for source_position, (df, metadata) in enumerate(sources[1:], 1):
            self._validate_join_cardinality(
                left=result_df, right=df, join_keys=join_keys, request=request,
                right_source_id=metadata.connector_id,
            )
            right_lineage_values = _input_lineage(df, metadata, source_position)
            df_copy = df.copy().reset_index(drop=True)''')
a=s.index('            persisted_right_lineage ='); b=s.index('            right_work[right_lineage_column]',a)
s=s[:a]+s[b:]
s=s.replace('''row_right_lineage.get(column, metadata)''','''row_right_lineage.get(column, ())''')
s=s.replace('list[dict[str, SourceMetadata | None]]','list[_LineageMap]')
# Resource estimate applies to all joins and temporary scratch dimensions, before data merge.
s=s.replace('''        if request.join_max_rows is not None:
            estimated_rows = self._estimate_join_rows(''','''        if True:
            estimated_rows = self._estimate_join_rows(''')
s=s.replace('''            if estimated_rows > request.join_max_rows:''','''            limit = min(request.join_max_rows, MAX_ROWS) if request.join_max_rows is not None else MAX_ROWS
            admit_shape(estimated_rows, len(set(left.columns) | set(right.columns)))
            if estimated_rows > limit:''')
s=s.replace('''f"estimated={estimated_rows}, limit={request.join_max_rows}"''','''f"estimated={estimated_rows}, limit={limit}"''')
# Use stdlib normalized tuple frequencies: null equivalence is explicit and identical across sides.
a=s.index('        left_keys = DataComposer._join_key_frame',s.index('    def _estimate_join_rows')); b=s.index('        matching = 0',a)
s=s[:a]+'''        from collections import Counter

        def counts(frame: pd.DataFrame) -> tuple[Counter, int]:
            result = Counter()
            unknown = 0
            for values in frame.loc[:, join_keys].itertuples(False, None):
                if not match_nulls and any(_is_missing_scalar(value) for value in values):
                    unknown += 1
                    continue
                key = tuple(None if _is_missing_scalar(value) else value for value in values)
                result[key] += 1
            return result, unknown

        left_counts, left_unknown = counts(left)
        right_counts, right_unknown = counts(right)
''' +s[b:]
s=s.replace('(len(left) - len(left_keys) if not match_nulls else 0)','left_unknown')
s=s.replace('(len(left) - len(left_keys) + len(right) - len(right_keys) if not match_nulls else 0)','(left_unknown + right_unknown)')
# JOIN duplicate resolver keeps origins, consults single-source metadata only at actual decision.
s=s.replace('''    ) -> tuple[pd.Series[Any], list[SourceMetadata | None]]:''','''    ) -> tuple[pd.Series[Any], list[tuple[_CellSource, ...]]]:''')
s=s.replace('''        chosen_lineage_values: list[SourceMetadata | None] = [None] * len(df)''','''        chosen_lineage_values: list[tuple[_CellSource, ...]] = [()] * len(df)''')
a=s.index('            left_source = left_meta',s.index('    def _resolve_duplicate_column')); b=s.index('            left_missing',a)
s=s[:a]+'''            left_origins = left_lineage[position].get(column_name, ()) if left_lineage else ()
            right_origins = right_lineage[position].get(column_name, ()) if right_lineage else ()
''' +s[b:]
s=s.replace('''chosen_lineage_values[position] = None''','''chosen_lineage_values[position] = ()''')
s=s.replace('''                if left_source is None:''','''                if not left_origins:''')
s=s.replace('''chosen_lineage_values[position] = left_source''','''chosen_lineage_values[position] = left_origins''')
s=s.replace('''chosen_lineage_values[position] = right_source''','''chosen_lineage_values[position] = right_origins''')
s=s.replace('''                    left_source = right_source''','''                    left_origins = right_origins''')
s=s.replace('''            if left_source is None:''','''            if not left_origins:''')
s=s.replace('''            row_key = {k: df.at[idx, k] for k in join_keys}
            candidates''','''            left_source = _origins_metadata(left_origins)
            right_source = _origins_metadata(right_origins)
            if left_source is None or right_source is None:
                raise FederationError("Non-null conflicting cell lacks selected origins")
            row_key = {k: df.at[idx, k] for k in join_keys}
            candidates''')
s=s.replace('''chosen_lineage_values[position] = resolution.chosen_candidate.metadata''','''chosen_lineage_values[position] = (
                left_origins if resolution.chosen_candidate is candidates[0] else right_origins
            )''')
# Overlay align lineage with same prepared secondary index once, update exact fill positions.
s=s.replace('''        result_df, primary_metadata = primary
        result_df = result_df.copy()''','''        result_df, primary_metadata = primary
        primary_basis = _input_lineage(result_df, primary_metadata, primary_idx)
        basis_by_key = {
            tuple(None if _is_missing_scalar(value) else value for value in row): basis
            for row, basis in zip(result_df[key_columns].itertuples(False, None), primary_basis, strict=True)
        }
        result_df = result_df.copy()''')
s=s.replace('''        indexed_secondaries: dict[int, pd.DataFrame] = {}''','''        result_basis = [dict(basis_by_key[tuple(None if _is_missing_scalar(value) else value
                        for value in (idx if isinstance(idx, tuple) else (idx,)))])
                        for idx in result_df.index]
        indexed_secondaries: dict[int, pd.DataFrame] = {}
        secondary_bases: dict[int, dict[tuple, _LineageMap]] = {}''')
s=s.replace('''                    indexed_secondaries[secondary_index] = secondary_indexed''','''                    indexed_secondaries[secondary_index] = secondary_indexed
                    source_position = next(index for index, source in enumerate(sources)
                                           if source[0] is secondary_df and source[1] is secondary_meta)
                    basis = _input_lineage(secondary_df, secondary_meta, source_position)
                    secondary_bases[secondary_index] = {
                        tuple(None if _is_missing_scalar(value) else value for value in row): origins
                        for row, origins in zip(secondary_df[key_columns].itertuples(False, None), basis, strict=True)
                    }''')
s=s.replace('''                    result_df.loc[fill_mask, col] = aligned[fill_mask]''','''                    for position, idx in enumerate(result_df.index):
                        if fill_mask.iloc[position]:
                            key = tuple(None if _is_missing_scalar(value) else value
                                        for value in (idx if isinstance(idx, tuple) else (idx,)))
                            result_basis[position][col] = secondary_bases[secondary_index][key].get(col, ())
                    result_df.loc[fill_mask, col] = aligned[fill_mask]''')
s=s.replace('''        result_df = result_df.reset_index()
        return result_df''','''        result_df = result_df.reset_index()
        _attach_persisted_lineage(result_df, result_basis)
        return result_df''',1)
# Consensus carries exact contributing origins, not a fictitious aggregate issuer.
s=s.replace('''        result = pd.DataFrame(index=union_index)
        consensus_stats''','''        result = pd.DataFrame(index=union_index)
        source_basis_by_key = []
        for position, (frame, metadata) in enumerate(sources):
            source_basis_by_key.append({
                tuple(None if _is_missing_scalar(value) else value for value in row): basis
                for row, basis in zip(frame[key_columns].itertuples(False, None),
                                      _input_lineage(frame, metadata, position), strict=True)
            })
        result_basis: list[_LineageMap] = [{} for _ in union_index]
        consensus_stats''')
s=s.replace('''            # Logging conflicts where values differ''','''            for position, idx in enumerate(values_df.index):
                key = tuple(None if _is_missing_scalar(value) else value
                            for value in (idx if isinstance(idx, tuple) else (idx,)))
                contributors = []
                for source_position, value in enumerate(values_df.iloc[position]):
                    if _is_missing_scalar(value):
                        continue
                    if agg_func != "mode":
                        try:
                            admissible = is_finite_number(float(value))
                        except (TypeError, ValueError):
                            admissible = False
                        if not admissible:
                            continue
                    contributors.extend(source_basis_by_key[source_position].get(key, {}).get(col, ()))
                result_basis[position][col] = tuple(contributors)

            # Logging conflicts where values differ''')
s=s.replace('''        result = result.reset_index()
        return result''','''        result = result.reset_index()
        _attach_persisted_lineage(result, result_basis)
        return result''',1)
# Remove unused complex dead expression generated above.
a=s.index('    return [\n        {column: (origin,) for column in frame.columns'); b=s.index('    ] if False else [',a)
s=s[:a]+'    return ['+s[b+len('    ] if False else ['):]
s=s.replace('    MAX_CELLS, MAX_COLUMNS, MAX_FILE_BYTES, MAX_ROWS, MAX_SOURCES,','    MAX_FILE_BYTES, MAX_ROWS, MAX_SOURCES,')
p.write_text(s)
