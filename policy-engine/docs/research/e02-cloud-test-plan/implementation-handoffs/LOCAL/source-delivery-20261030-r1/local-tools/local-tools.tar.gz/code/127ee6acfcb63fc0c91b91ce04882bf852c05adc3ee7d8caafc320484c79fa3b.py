from pathlib import Path
p=Path(__file__).parent/'policy-engine/src/polisyos/runtime/quality/data_state_substrate.py'
s=p.read_text();old='''    The effective payload is retained as private canonical JSON bytes rather
    than a mutable mapping.  This prevents a caller from changing selected
    owner data between preparation and the first CAS write.
''';new='''    The effective payload is retained as JSON bytes rather than a mutable
    mapping. Its recomputable digest detects content drift; it is not evidence
    of owner issuance or continuing eligibility. The materializer reconstructs
    the current owner preparation, compares every dataclass field, and consumes
    only that freshly resolved result before its first write.
''';assert s.count(old)==1;s=s.replace(old,new)
old='''    """Persist the exact owner preparation, preserving the legacy call path."""

    if prepared is None:
        prepared = prepare_acquired_observation_snapshot(
            store,
            base_data_snapshot_ref=base_data_snapshot_ref,
            overlay=overlay,
            receipt_ref=receipt_ref,
            passport=passport,
            authority=authority,
            observation_id=observation_id,
            slot_binding=slot_binding,
            transaction_time=transaction_time,
        )
    if transaction_time.tzinfo is None or transaction_time.utcoffset() is None:
        raise DataStateSubstrateError("acquisition_transaction_time_must_be_aware")
    transaction_time_text = transaction_time.astimezone(UTC).isoformat()
    if (
        prepared.base_data_snapshot_ref != base_data_snapshot_ref
        or prepared.receipt_ref != receipt_ref
        or prepared.selected_observation_id != observation_id
        or prepared.selected_profile != slot_binding
        or prepared.transaction_time_text != transaction_time_text
    ):
        raise DataStateSubstrateError("acquisition_preparation_input_mismatch")
'''
new='''    """Persist a freshly owner-resolved preparation, preserving the legacy path.

    ``prepared`` is a candidate comparison input, never an authority token.
    Re-resolve the active overlay, passport, source authority and selected base
    snapshot at this boundary even when callers supply a preparation. Equality
    covers every dataclass field, including the exact payload bytes, lineage,
    profile and Foundry rule. Only the fresh owner result is consumed. This
    preserves the existing read-before-write boundary; it does not establish an
    atomic transaction or revocation fence across the owner and CAS stores.
    """

    if prepared is not None and type(prepared) is not AcquiredObservationDataPreparation:
        raise DataStateSubstrateError("acquisition_preparation_untyped")
    current = prepare_acquired_observation_snapshot(
        store,
        base_data_snapshot_ref=base_data_snapshot_ref,
        overlay=overlay,
        receipt_ref=receipt_ref,
        passport=passport,
        authority=authority,
        observation_id=observation_id,
        slot_binding=slot_binding,
        transaction_time=transaction_time,
    )
    if prepared is not None and prepared != current:
        raise DataStateSubstrateError("acquisition_preparation_owner_state_changed")
    prepared = current
    transaction_time_text = prepared.transaction_time_text
'''
assert s.count(old)==1;s=s.replace(old,new);p.write_text(s)
