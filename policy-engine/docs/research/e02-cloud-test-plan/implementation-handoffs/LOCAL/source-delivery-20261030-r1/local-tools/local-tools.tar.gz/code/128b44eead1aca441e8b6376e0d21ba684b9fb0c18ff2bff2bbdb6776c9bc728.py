from pathlib import Path
import difflib,hashlib,json,subprocess
root=Path.cwd();base=root/'LOCAL/raw/e02-execution-20261027/repairs/C41-r8-companions'; pre=base/'preimages/policy-engine';post=base/'postimages/policy-engine'
def digest(b):return hashlib.sha256(b).hexdigest()
def blob(b):return subprocess.run(['git','hash-object','--stdin'],input=b,capture_output=True,check=True).stdout.decode().strip()
def git(*args):return subprocess.run(['git',*args],capture_output=True,text=True,check=True).stdout.strip()
entries=[];chunks=[]
for after in sorted(p for p in post.rglob('*') if p.is_file()):
 rel=after.relative_to(post);before=pre/rel;live=root/'policy-engine'/rel
 old=before.read_bytes() if before.exists() else None;new=after.read_bytes();actual=live.read_bytes() if live.exists() else None
 if old==new:continue
 name='policy-engine/'+rel.as_posix();chunks.append(f'diff --git a/{name} b/{name}\n')
 if old is None:chunks.append('new file mode 100644\n')
 chunks.extend(difflib.unified_diff((old or b'').decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile=('a/'+name if old is not None else '/dev/null'),tofile='b/'+name,n=3))
 entries.append({'path':name,'preimage_sha256':digest(old) if old is not None else None,'preimage_git_blob':blob(old) if old is not None else None,'postimage_sha256':digest(new),'postimage_git_blob':blob(new),'postimage_bytes':len(new),'live_sha256':digest(actual) if actual is not None else None,'live_matches_preimage':actual==old})
patch=''.join(chunks).encode();(base/'candidate.patch').write_bytes(patch)
check=subprocess.run(['git','apply','--check',str(base/'candidate.patch')],capture_output=True,text=True)
manifest={'status':'scratch: independent review pending; no native/G/closure claim','bound_c41_r8_patch_sha256':'b27fcdc2f4a15eac319a41d6046f93dc80a186591924fe7bff89eae856b82d59','freeze_head':git('rev-parse','HEAD'),'freeze_tree':git('rev-parse','HEAD^{tree}'),'candidate_patch_sha256':digest(patch),'candidate_patch_bytes':len(patch),'git_apply_check_exit':check.returncode,'git_apply_check_stdout':check.stdout,'git_apply_check_stderr':check.stderr,'changed_paths':entries,'generated_companions_owner':'root','typecheck_tests_native_removals':'UNRUN','closure_ids':[]}
(base/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('head',manifest['freeze_head'],'tree',manifest['freeze_tree'],'paths',len(entries),'all_preimages_match',all(x['live_matches_preimage'] for x in entries),'apply_check',check.returncode,'patch_sha256',digest(patch))
if check.stderr:print(check.stderr)
for key in ['candidate.patch','manifest.json','README.md','non-generic-v6-programming-route.md','consumer-census.json','static-check.json']:
 b=(base/key).read_bytes();print(key,digest(b),len(b))
if check.returncode or not all(x['live_matches_preimage'] for x in entries):raise SystemExit(1)
