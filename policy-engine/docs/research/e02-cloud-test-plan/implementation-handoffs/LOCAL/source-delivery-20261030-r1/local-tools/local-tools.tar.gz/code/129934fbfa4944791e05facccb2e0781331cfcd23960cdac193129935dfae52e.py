"""Prepare one source-bound ordinary served N7 case; never execute the case."""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
RAW = ROOT / 'LOCAL/raw/e02-execution-20261027'
PACKAGE = RAW / 'next-native/N7-grounded-report-r2'
DELTA = RAW / 'repairs/N7-owner-slot-fixture-r1'
DELTA_MANIFEST_SHA256 = '09887511ddceca3b755007ed045c215b0229782cc0d8353caa27e71208df7b75'
R1 = RAW / 'next-native/N7-grounded-report-r1'
NATIVE = ROOT / ('policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/'
                 'LOCAL/raw/root-ir-transport-composition-20261024-r1/'
                 'g-native-priority-20261025-r1')
D = NATIVE / 'deep-task-status-audit-20261027-r1'
CASE_ID = 'n7r4'
NODE = ('tests/integration/core_runtime/test_acquisition_authority_served.py::'
        'test_served_acquisition_binds_n7_compiler_and_planner_cas_before_reentry')
RULES = ('(allow network-bind (local tcp "localhost:*"))',
         '(allow network-inbound (local tcp "localhost:*"))',
         '(allow network-outbound (remote tcp "localhost:*"))')

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def git(*args: str) -> str:
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--expected-tree', required=True)
    args = parser.parse_args()
    if (git('symbolic-ref', '--short', 'HEAD') != 'codex/e02-unified-local-20261009'
        or git('rev-parse', 'HEAD') != args.expected_head
        or git('rev-parse', 'HEAD^{tree}') != args.expected_tree):
        raise SystemExit('explicit current source/branch mismatch; stop for Root reassessment')
    if sha((R1 / 'manifest.json').read_bytes()) != '55d4c385f20de69fa3c9e11fbba7252185607698132dc8197253fee7b01838cc' or sha((R1 / 'source-pins.json').read_bytes()) != '341ff4ca21e150ef71ddb910d10b3dbfda20e76e88fc3fd2935890091cc6db51':
        raise SystemExit('reviewed R1 source binding changed')
    pins = json.loads((R1 / 'source-pins.json').read_text())
    delta_path = DELTA / 'postimages-manifest.json'
    if sha(delta_path.read_bytes()) != DELTA_MANIFEST_SHA256:
        raise SystemExit('reviewed canonical delta manifest changed')
    delta = json.loads(delta_path.read_text())
    overrides = {row['path']: row for row in delta['files']}
    expected_delta_paths = {
        'policy-engine/tests/_helpers/candidate_cycle_source_profile.py',
        'policy-engine/tests/integration/core_runtime/test_acquisition_authority_served.py',
    }
    if set(overrides) != expected_delta_paths or len(delta['files']) != 2:
        raise SystemExit('reviewed source delta is not the two-file candidate fixture')
    if subprocess.run(['git', '-C', str(ROOT), 'merge-base', '--is-ancestor',
                       delta['base_commit'], args.expected_head]).returncode:
        raise SystemExit('new source is not descended from the reviewed delta base')
    if not expected_delta_paths.issubset({row['path'] for row in pins['files']}):
        raise SystemExit('delta contains a path outside the selected source set')
    for row in pins['files']:
        if row['path'] in overrides:
            override = overrides[row['path']]
            if row['sha256'] != override['pre_sha256']:
                raise SystemExit('baseline source pin does not match the reviewed preimage')
            row['sha256'] = override['post_sha256']
            row['bytes'] = override['bytes']
    if subprocess.run(['git', '-C', str(ROOT), 'merge-base', '--is-ancestor',
                       pins['source_head'], args.expected_head]).returncode:
        raise SystemExit('current source is not descended from the reviewed source cut')
    for row in pins['files']:
        path = ROOT / row['path']
        if path.is_symlink() or not path.is_file() or sha(path.read_bytes()) != row['sha256']:
            raise SystemExit(f"bounded source changed: {row['path']}; re-review before execution")
        committed = subprocess.check_output(['git', '-C', str(ROOT), 'show',
                                             args.expected_head + ':' + row['path']])
        if sha(committed) != row['sha256']:
            raise SystemExit(f"working bytes differ from committed source: {row['path']}")
    for row in pins['retained_harness']:
        if sha((ROOT / row['path']).read_bytes()) != row['sha256']:
            raise SystemExit(f"runner/fixture profile changed: {row['path']}")
    module = ROOT / 'policy-engine' / NODE.split('::')[0]
    name = NODE.split('::')[1]
    matches = [x for x in ast.parse(module.read_text()).body
               if isinstance(x, (ast.FunctionDef, ast.AsyncFunctionDef)) and x.name == name]
    if len(matches) != 1 or any(isinstance(d, ast.Call) and
            isinstance(d.func, ast.Attribute) and d.func.attr == 'parametrize'
            for d in matches[0].decorator_list):
        raise SystemExit('selected served function is absent, ambiguous or parametrized')
    scope = ('Ordinary candidate-fixture POST/worker -> real N4 and grounding -> N7 compiler '
             'and planner -> selected CAS -> fresh route resolver; controls remove actual '
             'planner/compiler bytes. Synthetic inputs do not establish production, issuer, '
             'law or scientific currentness. Profile allows localhost TCP, including wildcard '
             'bind; the test servers explicitly bind 127.0.0.1. Production reads remain denied.')
    pins['source_head'] = args.expected_head
    pins['source_tree'] = args.expected_tree
    pins['reviewed_canonical_delta_manifest_sha256'] = DELTA_MANIFEST_SHA256
    admission = DELTA / 'admissions' / (args.expected_head + '-' + CASE_ID)
    admission.mkdir(parents=True, exist_ok=False)
    effective_pins = admission / 'source-pins.json'
    with effective_pins.open('x') as stream:
        stream.write(json.dumps(pins, indent=2) + '\n')
    command = [sys.executable, str(RAW / 'prepare_root_native_case_r2.py'), CASE_ID,
               NODE, '--scope', scope]
    prepared = subprocess.run(command, cwd=ROOT, check=True, capture_output=True, text=True)
    plan_path = D / (CASE_ID + '.json')
    plan = json.loads(plan_path.read_text())
    if (plan['source_head'], plan['source_tree'], plan['nodes']) != (
            args.expected_head, args.expected_tree, [NODE]):
        raise SystemExit('native admission returned unexpected source or selector')
    fragment = plan['sandbox_profile_fragment']
    lines = fragment.splitlines()
    if not lines or lines[0] != '(deny network*)' or any(rule in lines for rule in RULES):
        raise SystemExit('unexpected base network policy')
    required_denies = (
        '(deny file-read* (literal "' + str(ROOT / 'policy-engine/production_data') + '"))',
        '(deny file-read* (subpath "' + str(ROOT / 'policy-engine/production_data') + '"))',
        '(deny file-read* (subpath "/Users/deniskopylov/polisyos/policy-engine/production_data"))',
    )
    if not all(rule in lines for rule in required_denies):
        raise SystemExit('base profile lost a production-data read denial')
    fragment = '\n'.join((lines[0], *RULES, *lines[1:]))
    output = D / CASE_ID
    profile = ('(version 1)\n(allow default)\n(deny file-write*)\n'
               '(allow file-write* (subpath ' + json.dumps(str(output)) + '))\n'
               '(allow file-write* (literal "/dev/null"))\n' + fragment)
    plan.update({'sandbox_profile_fragment': fragment,
                 'sandbox_profile_fragment_sha256': sha(fragment.encode()),
                 'sandbox_profile_text': profile,
                 'sandbox_profile_sha256': sha(profile.encode()),
                 'source_pins_sha256': sha(effective_pins.read_bytes()),
                 'source_pins_path': str(effective_pins.relative_to(ROOT)),
                 'reviewed_canonical_delta_manifest_sha256': DELTA_MANIFEST_SHA256,
                 'preparer_source_sha256': sha(Path(__file__).read_bytes()),
                 'observer_inputs': {name: sha((PACKAGE / name).read_bytes()) for name in ['n7_resolver_observer.py', 'observer_core.py']},
                 'extra_env': {
                     'PYTHONPATH': str(PACKAGE),
                     'PYTEST_PLUGINS': 'n7_resolver_observer',
                     'N7_OBSERVER_NODE': NODE,
                     'N7_OBSERVER_OUT': str(output / 'n7-resolver-events.jsonl'),
                     'N7_OBSERVER_SOURCE_PATH': str(ROOT / 'policy-engine/src/polisyos/runtime/quality/generation_cycle.py'),
                     'N7_OBSERVER_SOURCE_SHA256': next(row['sha256'] for row in pins['files'] if row['path'] == 'policy-engine/src/polisyos/runtime/quality/generation_cycle.py'),
                 },
                 'profile_limit': 'localhost TCP allowed including wildcard bind; fixture servers bind 127.0.0.1',
                 'backend_pilot': 'backend micro-admission is prerequisite but case must execute actual owners'})
    if (git('rev-parse', 'HEAD'), git('rev-parse', 'HEAD^{tree}')) != (
            args.expected_head, args.expected_tree):
        raise SystemExit('source moved during preparation; plan is not admitted')
    plan_path.write_text(json.dumps(plan, indent=2) + '\n')
    if json.loads(plan_path.read_text()) != plan:
        raise SystemExit('case plan readback differs')
    print(json.dumps({'plan': str(plan_path), 'sha256': sha(plan_path.read_bytes()),
                      'head': args.expected_head, 'tree': args.expected_tree, 'node': NODE,
                      'base_admission': prepared.stdout.strip(), 'tests_executed': False}))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
