#!/usr/bin/env python3
"""Build a pinned, local-only fixture proposal without importing product code."""
import ast
import difflib
import hashlib
import json
import subprocess
from pathlib import Path

root = Path.cwd()
out = root / 'LOCAL/raw/e02-execution-20261027/repairs/C44-fixture-abi'
base = 'd7790ad008219da6c74e7c78b7eee7caca212e02'
tree = 'b8ef64227f3903ba4ff1f8a9403befe55bd488ee'
path = 'policy-engine/tests/unit/scientist/orchestration/engine/test_workflow_deadline_custody.py'

def git(*args: str) -> bytes:
    return subprocess.check_output(['git', *args], cwd=root)

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

assert git('rev-parse', f'{base}^{{tree}}').strip().decode() == tree
pre = git('show', f'{base}:{path}')
assert (root / path).read_bytes() == pre, 'working preimage differs from pinned source'
s = pre.decode()
old_import = 'from polisyos.core.artifacts.async_store import (\n'
new_import = ('from polisyos.core.artifacts import artifact_manifest_profile_sha256\n'
              'from polisyos.core.artifacts.async_store import (\n')
assert s.count(old_import) == 1
s = s.replace(old_import, new_import, 1)
old = '''    def put_bytes(self, data, opts):
        if opts.kind != self.target:
            return super().put_bytes(data, opts)
        self.thread = threading.get_ident()
        self.entered.set()
        try:
            if not self.release.wait(5):
                raise RuntimeError("actual CAS publication watchdog expired")
            self.published = super().put_bytes(data, opts)
            return self.published
        finally:
            self.finished.set()
'''
new = '''    def put_bytes(
        self,
        data: bytes,
        opts: PutOptions,
        *,
        return_selected_profile: bool = False,
    ) -> ArtifactRef:
        if opts.kind != self.target:
            return super().put_bytes(data, opts, return_selected_profile=return_selected_profile)
        self.thread = threading.get_ident()
        self.entered.set()
        try:
            if not self.release.wait(5):
                raise RuntimeError("actual CAS publication watchdog expired")
            self.published = super().put_bytes(
                data, opts, return_selected_profile=return_selected_profile
            )
            return self.published
        finally:
            self.finished.set()
'''
assert s.count(old) == 1
s = s.replace(old, new, 1)
anchor = '\n\nclass _ReadGateCAS(FileSystemCAS):\n'
tests = '''\n\n@pytest.mark.parametrize("gated", [False, True])
@pytest.mark.parametrize("mode", ["omitted", "false", "true"])
def test_write_gate_cas_delegates_exact_write_profile(
    tmp_path: Path, gated: bool, mode: str
) -> None:
    store = _WriteGateCAS(tmp_path / "cas")
    opts = PutOptions(kind="test.deadline.profile", media_type="application/octet-stream")
    store.target = opts.kind if gated else None
    store.release.set()
    if mode == "omitted":
        ref = store.put_bytes(b"selected profile witness", opts)
    else:
        ref = store.put_bytes(
            b"selected profile witness", opts, return_selected_profile=mode == "true"
        )

    assert store.entered.is_set() is gated
    assert store.finished.is_set() is gated
    assert store.published == (ref if gated else None)
    if gated:
        assert store.thread == threading.get_ident()
    reopened = FileSystemCAS(store.root)
    assert reopened.verify(ref).ok
    assert reopened.get_bytes(ref) == b"selected profile witness"
    manifest = reopened.get_manifest(ref)
    assert manifest.kind == opts.kind and manifest.media_type == opts.media_type
    if mode == "true":
        assert ref.manifest_profile_sha256 == artifact_manifest_profile_sha256(manifest)
    else:
        assert ref.manifest_profile_sha256 is None


@pytest.mark.parametrize("gated", [False, True])
def test_write_gate_cas_rejects_invalid_profile_flag(tmp_path: Path, gated: bool) -> None:
    store = _WriteGateCAS(tmp_path / "cas")
    opts = PutOptions(kind="test.deadline.profile", media_type="application/octet-stream")
    store.target = opts.kind if gated else None
    store.release.set()
    before = {str(aid) for aid in store.iter_artifact_ids()}
    with pytest.raises(TypeError, match="return_selected_profile must be a bool"):
        store.put_bytes(
            b"invalid profile flag", opts, return_selected_profile=1  # type: ignore[arg-type]
        )
    assert {str(aid) for aid in store.iter_artifact_ids()} == before
'''
assert s.count(anchor) == 1
s = s.replace(anchor, tests + anchor, 1)
post = s.encode()
prepath = out / 'preimage' / path
postpath = out / 'postimage' / path
for dest, data in ((prepath, pre), (postpath, post)):
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
patch = ''.join(difflib.unified_diff(pre.decode().splitlines(keepends=True), s.splitlines(keepends=True), fromfile='a/'+path, tofile='b/'+path)).encode()
(out / 'base-to-proposal.patch').write_bytes(patch)

module = ast.parse(s)
cls = next(x for x in module.body if isinstance(x, ast.ClassDef) and x.name == '_WriteGateCAS')
put = next(x for x in cls.body if isinstance(x, ast.FunctionDef) and x.name == 'put_bytes')
assert [x.arg for x in put.args.kwonlyargs] == ['return_selected_profile']
assert isinstance(put.args.kw_defaults[0], ast.Constant) and put.args.kw_defaults[0].value is False
supercalls = [n for n in ast.walk(put) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == 'put_bytes' and isinstance(n.func.value, ast.Call) and isinstance(n.func.value.func, ast.Name) and n.func.value.func.id == 'super']
assert len(supercalls) == 2
for call in supercalls:
    assert len(call.keywords) == 1 and call.keywords[0].arg == 'return_selected_profile'
    assert isinstance(call.keywords[0].value, ast.Name) and call.keywords[0].value.id == 'return_selected_profile'
    assert [arg.id for arg in call.args if isinstance(arg, ast.Name)] == ['data', 'opts']
for name in ('test_write_gate_cas_delegates_exact_write_profile', 'test_write_gate_cas_rejects_invalid_profile_flag', 'test_workflow_cas_wait_cannot_admit_late_ref_or_next_producer'):
    assert any(isinstance(x, (ast.FunctionDef, ast.AsyncFunctionDef)) and x.name == name for x in module.body)
sourcepaths = [
 path,
 'policy-engine/src/polisyos/core/artifacts/store.py',
 'policy-engine/src/polisyos/core/artifacts/protocol.py',
 'policy-engine/src/polisyos/core/artifacts/async_store.py',
 'policy-engine/src/polisyos/core/run/context.py',
 'policy-engine/src/polisyos/core/registry/builder.py',
 'policy-engine/src/polisyos/scientist/orchestration/engine/async_executor.py',
 'policy-engine/tests/unit/core/artifacts/test_artifact_store_protocol.py',
]
pins = {p: {'sha256': sha(git('show', f'{base}:{p}')), 'git_blob': git('rev-parse', f'{base}:{p}').strip().decode()} for p in sourcepaths}
manifest = {
 'schema':'policyos.e02.sparse-local-proposal.v1', 'base_commit':base, 'base_tree':tree,
 'no_product_execution':True, 'no_canonical_mutation':True,
 'path':path, 'preimage_sha256':sha(pre), 'postimage_sha256':sha(post),
 'patch_sha256':sha(patch), 'pinned_readset':pins,
 'purpose':'Preserve exact return_selected_profile delegation for gated and ungated writes',
 'control_nodes':['test_write_gate_cas_delegates_exact_write_profile','test_write_gate_cas_rejects_invalid_profile_flag'],
 'first_consumer_node':'test_workflow_cas_wait_cannot_admit_late_ref_or_next_producer',
 'test_result':'UNRUN', 'static_checks':{'python_ast_parse':True,'kwonly_false_default':True,'two_super_calls_forward_exact_flag_data_options':True,'required_test_nodes_present':True},
}
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True)+'\n')
print('base',base,tree)
print('preimage_sha256',sha(pre))
print('postimage_sha256',sha(post))
print('patch_sha256',sha(patch))
print('manifest_sha256',sha((out/'manifest.json').read_bytes()))
print('postimage_bytes',len(post),'patch_bytes',len(patch))
