from pathlib import Path

out = Path(__file__).resolve().parent
path = Path('policy-engine/src/polisyos/runtime/http/services/control_plane_store.py')
s = (out / 'base' / path).read_text()
s = s.replace('from polisyos.runtime.quality.evidence_spine_handoff import (', 'from polisyos.runtime.quality.event_log import _PreparedDiagnosticEvent\nfrom polisyos.runtime.quality.evidence_spine_handoff import (', 1)
anchor = '\n\nclass ControlPlaneStore:'
plan = '''

@dataclass(frozen=True, slots=True)
class _ControlJobCreationPlan:
    """Unpublished owner allocation, never a job/event receipt or execution proof."""

    job_id: str
    initial_state: Literal["pending", "failed"]
    source_event_id: int
    fact_created_at: datetime
    source_payload_json: str
    source_payload_sha256: str
    creation_owner: object
'''
assert s.count(anchor) == 1
s = s.replace(anchor, plan + anchor)
s = s.replace('        self._human_decision_transaction = threading.local()\n', '        self._human_decision_transaction = threading.local()\n        self._creation_plan_owner = object()\n', 1)
anchor = '    def create_job(\n'
method = '''    def prepare_job_creation(
        self,
        *,
        job_id: str,
        initial_state: Literal["pending", "failed"],
        creation_event_payload: dict[str, Any],
    ) -> _ControlJobCreationPlan:
        """Allocate immutable creation facts without publishing a job or event.

        Only the existing event sequence is advanced under a short SQL owner
        transaction. Payload/CAS preparation follows outside that transaction.
        Gaps after an abandoned plan are valid sequence gaps, not job receipts.
        The fact timestamp is frozen here; outbox publication has its own time.
        """
        if initial_state not in {"pending", "failed"}:
            raise ValueError("control_job_initial_state_invalid")
        payload = {**creation_event_payload, "state": initial_state}
        if payload.get("job_id") != job_id:
            raise ValueError("control_job_creation_plan_job_mismatch")
        payload_json = json.dumps(payload, sort_keys=True)
        fact_created_at = _utc_now()
        with self._job_transaction():
            if self.backend == "sqlite":
                rows = self._fetchall(
                    "SELECT seq FROM sqlite_sequence WHERE name = ?", ("control_job_events",)
                )
                if len(rows) > 1:
                    raise RuntimeError("control_job_event_sequence_invalid")
                if rows:
                    event_id = int(rows[0][0]) + 1
                    self._execute(
                        "UPDATE sqlite_sequence SET seq = ? WHERE name = ?",
                        (event_id, "control_job_events"),
                    )
                else:
                    event_id = 1
                    self._execute(
                        "INSERT INTO sqlite_sequence (name, seq) VALUES (?, ?)",
                        ("control_job_events", event_id),
                    )
            else:
                row = self._fetchone(
                    "SELECT nextval(pg_get_serial_sequence('control_job_events', 'event_id')) "
                    "AS event_id", ()
                )
                if row is None:
                    raise RuntimeError("control_job_event_sequence_unavailable")
                event_id = int(row["event_id"])
        return _ControlJobCreationPlan(
            job_id=job_id,
            initial_state=initial_state,
            source_event_id=event_id,
            fact_created_at=fact_created_at,
            source_payload_json=payload_json,
            source_payload_sha256="sha256:" + hashlib.sha256(payload_json.encode()).hexdigest(),
            creation_owner=self._creation_plan_owner,
        )

'''
assert s.count(anchor) == 1
s = s.replace(anchor, method + anchor)
old = '''        initial_progress: dict[str, Any] | None = None,
        pre_admission_attempt_id: str | None = None,'''
new = '''        initial_progress: dict[str, Any] | None = None,
        creation_plan: _ControlJobCreationPlan | None = None,
        prepared_admission_diagnostics: tuple[_PreparedDiagnosticEvent, ...] = (),
        diagnostic_preparation_failed: bool = False,
        pre_admission_attempt_id: str | None = None,'''
assert s.count(old) == 1
s = s.replace(old, new)
s = s.replace('''        """Insert a pending or terminally refused job and enqueue its creation event."""''', '''        """Publish a job and its prepared admission records in one SQL transaction.

        Diagnostic payload/CAS work must precede this call. The optional plan is
        an unpublished allocation; actual event/outbox/source bindings are read
        back and reconciled here before diagnostic rows and progress are committed.
        No arbitrary initializer, CAS access or user callback runs under the lock.
        """''', 1)
start = s.index('    def create_job(\n')
pos = s.index('        created_at = _utc_now()\n', start)
s = s[:pos] + '''        if type(diagnostic_preparation_failed) is not bool:
            raise TypeError("control_job_diagnostic_preparation_status_invalid")
        if creation_plan is None and (prepared_admission_diagnostics or diagnostic_preparation_failed):
            raise ValueError("control_job_diagnostics_require_creation_plan")
        if creation_plan is not None and (
            type(creation_plan) is not _ControlJobCreationPlan
            or creation_plan.creation_owner is not self._creation_plan_owner
            or creation_plan.job_id != job_id
            or creation_plan.initial_state != initial_state
            or creation_plan.source_payload_json
            != json.dumps({**dict(creation_event_payload or {}), "state": initial_state}, sort_keys=True)
        ):
            raise ValueError("control_job_creation_plan_mismatch")
        # Decode/hash detached prepared values before acquiring the SQL writer.
        prepared_values = []
        for prepared in prepared_admission_diagnostics:
            if type(prepared) is not _PreparedDiagnosticEvent:
                raise TypeError("control_job_diagnostic_preparation_type_invalid")
            event, payload = prepared.publication_values()
            if payload is None:
                raise ValueError("control_job_diagnostic_preparation_payload_missing")
            prepared_values.append((prepared, event, payload))
        created_at = creation_plan.fact_created_at if creation_plan is not None else _utc_now()
''' + s[pos+len('        created_at = _utc_now()\n'):]
old = '''            self.append_event(
                job_id=job_id,
                event_type="job_created",
                payload=created_event_payload,
            )'''
new = '''            if creation_plan is None:
                self.append_event(
                    job_id=job_id,
                    event_type="job_created",
                    payload=created_event_payload,
                )
            else:
                self._execute(
                    "INSERT INTO control_job_events "
                    "(event_id, job_id, event_type, payload_json, created_at) VALUES (?, ?, ?, ?, ?)",
                    (
                        creation_plan.source_event_id, job_id, "job_created",
                        creation_plan.source_payload_json, _iso(creation_plan.fact_created_at),
                    ),
                )'''
assert s.count(old) == 1
s = s.replace(old, new)
anchor = '''            if pre_admission_attempt_id is not None and pre_admission_outcome is not None:
'''
pos = s.index(anchor, start)
publication = '''            if creation_plan is not None:
                source = self._get_job_created_source_event_record(job_id)
                if (
                    source.event_id != creation_plan.source_event_id
                    or source.created_at != creation_plan.fact_created_at
                    or source.payload_sha256 != creation_plan.source_payload_sha256
                ):
                    raise ControlJobExecutionAdmissionError("control_job_creation_fact_mismatch")
                scope, _ = self._reconcile_control_job_creation_envelope(record)
                expected_binding = {
                    "schema_version": "polisyos.runtime.control_job_execution_binding.v1",
                    "binding_status": "established",
                    "proof_phase": "job_admission",
                    "control_job_id": job_id,
                    "control_run_id": run_id,
                    "source_event_job_state": initial_state,
                    "control_worker_id": None,
                    "control_worker_attempt": None,
                    "source_event_id": source.event_id,
                    "source_event_type": "job_created",
                    "source_event_created_at": source.created_at.isoformat().replace("+00:00", "Z"),
                    "source_event_payload_sha256": source.payload_sha256,
                    "bound_job_record_refs": [
                        ref for ref in (record.payload_ref, record.capability_manifest_ref) if ref
                    ],
                }
                diagnostic_ids: list[str] = []
                authority_withheld = False
                for prepared, event, payload in prepared_values:
                    if (
                        event.job_id != job_id or event.run_id != str(run_id or "run-unknown")
                        or event.phase != "job_admission"
                        or event.execution_profile != effective_execution_profile
                        or event.tenant_id != (scope.tenant_id or "tenant-unknown")
                        or event.cell_id != (scope.cell_id or "cell-unknown")
                        or "attempt" in payload
                        or not _json_values_equal_strict(
                            payload.get("control_job_execution_binding"), expected_binding
                        )
                    ):
                        raise ControlJobExecutionAdmissionError(
                            "control_job_prepared_diagnostic_source_mismatch"
                        )
                    if event.event_id in diagnostic_ids or self.list_diagnostic_events(
                        event_id=event.event_id, limit=1
                    ):
                        raise ControlJobExecutionAdmissionError(
                            "control_job_prepared_diagnostic_already_exists"
                        )
                    self.append_diagnostic_event(
                        event=event,
                        payload_ref=prepared.payload_ref,
                        payload_inline=payload if prepared.inline_payload else None,
                        payload_sha256=prepared.payload_sha256,
                    )
                    diagnostic_ids.append(event.event_id)
                    authority_withheld |= (
                        event.event_type == "polisyos.runtime.diagnostic.scope_limited.v1"
                    )
                diagnostic_progress: dict[str, Any] = {
                    "diagnostic_event_ids": diagnostic_ids,
                    "diagnostic_event_authority": (
                        "scope_limited" if authority_withheld else "progress_reference_only"
                    ),
                    "diagnostic_event_scope_status": scope.status,
                }
                if scope.status == "not_established":
                    diagnostic_progress["diagnostic_event_limitation_code"] = (
                        "control_job_execution_scope_not_established"
                    )
                if diagnostic_preparation_failed:
                    diagnostic_progress["diagnostic_event_preparation_status"] = "limited"
                    diagnostic_progress["diagnostic_event_preparation_limitation_code"] = (
                        "runtime_diagnostic_event_persistence_failed"
                    )
                # The creation owner only appends its own initial diagnostic
                # projection. It never changes a worker/terminal generation.
                self._upsert_progress_unchecked(
                    job_id=job_id, progress={**record.progress, **diagnostic_progress}
                )
                record = self.get_job(job_id)
                if record is None:
                    raise RuntimeError(f"Failed to initialize control job {job_id}")
'''
s = s[:pos] + publication + s[pos:]
p = out / 'postimages' / path
p.parent.mkdir(parents=True, exist_ok=True)
p.write_text(s)
