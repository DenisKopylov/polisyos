"""Read-only owner-scanner and synthetic removal checks for the RAW proposal."""
from pathlib import Path
from unittest.mock import patch
import ast
import subprocess
import sys
import tomllib

root = Path.cwd()
pkg = root / 'policy-engine'
packet = root / 'LOCAL/raw/e02-execution-20261027/repairs/TC-public-route-companion-r1'
post = packet / 'postimages/policy-engine'
sys.path.insert(0, str(pkg))
from tools.devx.architecture import guardrails as g

python_files = sorted(post.rglob('*.py'))
for file in python_files:
    ast.parse(file.read_text())
    rel = file.relative_to(post)
    proc = subprocess.run(
        [str(pkg/'.venv/bin/python'), '-B', '-m', 'ruff', 'check', '--stdin-filename', str(rel), '-'],
        cwd=pkg, input=file.read_text(), text=True, capture_output=True,
    )
    if proc.returncode:
        raise SystemExit(f'Ruff failed: {rel}\n{proc.stdout}\n{proc.stderr}')
print(f'AST and configured Ruff PASS: {len(python_files)} Python files')
for file in post.rglob('*.toml'):
    tomllib.loads(file.read_text())
print('Release fragment TOML parse PASS')

original = g.admitted_read_bytes
facades = {
    (pkg/'src/polisyos/core/contracts/__init__.py'): post/'src/polisyos/core/contracts/__init__.py',
    (pkg/'src/polisyos/ir/__init__.py'): post/'src/polisyos/ir/__init__.py',
}
def overlay(path, admission_root):
    replacement = facades.get(path)
    if replacement is not None:
        return replacement.read_bytes()
    return original(path, admission_root)
with patch.object(g, 'admitted_read_bytes', overlay):
    for module, expected in (
        ('polisyos.core.contracts', {'RegisteredSQLAdmissionBinding', 'RegisteredSQLUseContract', 'data_snapshot_manifest_inputs_match'}),
        ('polisyos.ir', {'LinkReport'}),
    ):
        inv = g._entrypoint_inventory(module)
        assert inv.export_resolution['complete'] is True, (module, inv.export_resolution)
        assert expected <= set(inv.exports), (module, expected - set(inv.exports))
        print(f'{module} owner inventory PASS: {inv.export_count} total source-resolved exports')

policies = g._parse_public_surface(pkg/'architecture/public_surface/contract.toml')
allowed = {}
for row in policies:
    r = g._root_for_module(row.module)
    if r:
        allowed.setdefault(r, set()).update(row.supported_entrypoints)
# Registration r1 is a prerequisite; this is not a claim that it is composed yet.
allowed['scientist'].update(('polisyos.scientist.compute', 'polisyos.scientist.adapters'))

def edges_for(mutated=False):
    edges = {}; facade_cache = {}; star_cache = {}
    for rel in ('src/polisyos/runtime/quality/owned_execution_identity.py', 'src/polisyos/foundry/compile/manifest_inputs.py'):
        actual = pkg/rel
        source_module, is_package = g._module_name_for_path(actual)
        source_root = g._root_for_module(source_module)
        content = (post/rel).read_text()
        if mutated and source_module.endswith('owned_execution_identity'):
            assert content.count('from polisyos.ir import LinkReport') == 1
            content = content.replace('from polisyos.ir import LinkReport', 'from polisyos.ir.linker import LinkReport')
        for node in ast.walk(ast.parse(content)):
            if isinstance(node, ast.Import):
                targets = [alias.name for alias in node.names]
            elif isinstance(node, ast.ImportFrom):
                target = g._resolve_import_module(source_module, is_package, node)
                targets = [] if target is None else [target]
            else:
                continue
            for target in targets:
                g._maybe_add_deep_import(edges=edges, allowed_entrypoints=allowed, source_module=source_module, source_root=source_root, source_file=actual, target_module=target)
                if isinstance(node, ast.ImportFrom):
                    g._maybe_add_fromlist_deep_imports(aliases=node.names, target_module=target, source_module=source_module, source_root=source_root, source_file=actual, allowed_entrypoints=allowed, edges=edges, facade_cache=facade_cache, star_export_cache=star_cache)
    return edges
base_edges = edges_for()
control_edges = edges_for(True)
assert not base_edges, base_edges
assert len(control_edges) == 1 and any(key.endswith('->polisyos.ir.linker') for key in control_edges), control_edges
print('Direct and from-list scanner PASS for 2 changed owner modules (0 edges)')
print('Scanner removal control PASS (deep LinkReport import produces 1 edge)')
print('Native object-identity and integration tests UNRUN')
