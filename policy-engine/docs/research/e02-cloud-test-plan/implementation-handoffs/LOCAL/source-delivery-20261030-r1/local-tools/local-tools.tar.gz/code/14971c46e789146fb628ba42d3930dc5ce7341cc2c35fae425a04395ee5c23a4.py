import faulthandler,json,time
from pathlib import Path
from tools.quality.validation import schema_fqn_census as c
root=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos/policy-engine').resolve()
faulthandler.dump_traceback_later(15,repeat=True)
stages=(('tracked',lambda:c._git_paths(root,'ls-files','--cached')),('untracked_nonignored',lambda:c._git_paths(root,'ls-files','--others','--exclude-standard')),('working_tree_status',lambda:c._git_status_paths(root)))
try:
 for name,run in stages:
  start=time.perf_counter(); paths,meta=run()
  print(json.dumps({'phase':name,'wall_seconds':round(time.perf_counter()-start,3),'path_count':len(paths),'stdout_bytes':meta.get('stdout_bytes'),'stderr_bytes':meta.get('stderr_bytes'),'returncode':meta.get('returncode'),'selected_text_count':sum(c._is_selected_text(path) for path in paths) if name!='working_tree_status' else None},sort_keys=True),flush=True)
finally: faulthandler.cancel_dump_traceback_later()
