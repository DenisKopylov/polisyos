"""Stdlib-only extracted-method controls; not the full collector or product runtime."""
from __future__ import annotations
import ast,copy,hashlib,json,sys,types
from pathlib import Path
from types import SimpleNamespace

R=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
O=Path(__file__).resolve().parent
OWNER=R/'policy-engine/tools/quality/validation/decomposition_preflight.py'
PROFILE=R/'policy-engine/src/polisyos/common/canonical_profile.py'
sha=lambda b:hashlib.sha256(b).hexdigest()
FUNCTIONS={'_dynamic_source_class_origins','_dynamic_binding_nodes','_dynamic_importer_origins','_dynamic_import_namespace_origins','_dynamic_unresolved_importer_origins','_dynamic_temporal_callable_origins','_is_guarded_importer_binding','_dynamic_is_importer_namespace_name','_scope_local_bindings','_dynamic_scope_read_dependencies','_future_annotations_enabled'}
CLASSES={'DynamicImportCollectionError','_DynamicImportBinding','_PendingDynamicImportScope','_DynamicImportScopeNames','_DynamicImportScopeReadCollector'}
CONSTANTS={'DYNAMIC_CALL_NAMES','_DYNAMIC_IMPORT_GUARDED_ROOTS','_DYNAMIC_IMPORT_MODULE_PREFIXES','_DYNAMIC_IMPORT_TEMPORAL_CALLABLES','_DYNAMIC_COMPREHENSION_VALUE_LIMIT'}
BINDINGS={'_source_function_definition','_source_class_definition','_source_class_identity_definition'}
SCANNER={'_invalidate_source_class_effects','_source_class_invocation_read_names','_deferred_scope_importer_names','_raise_for_unproven_temporal_invocations'}

def load(source:bytes,label:str,remove_relevance=False):
 tree=ast.parse(source)
 body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0),ast.Import(names=[ast.alias(name='ast')]),ast.ImportFrom(module='dataclasses',names=[ast.alias(name='dataclass')],level=0)]
 selected=[]
 for node in tree.body:
  name=getattr(node,'name',None)
  if name in FUNCTIONS|CLASSES:
   body.append(copy.deepcopy(node));selected.append(name)
  elif isinstance(node,(ast.Assign,ast.AnnAssign)):
   targets=node.targets if isinstance(node,ast.Assign) else (node.target,)
   names={v.id for target in targets for v in ast.walk(target) if isinstance(v,ast.Name)}
   if names & CONSTANTS:body.append(copy.deepcopy(node));selected.extend(sorted(names&CONSTANTS))
 for original,renamed,methods in [('_DynamicImportSourceBindings','ExtractedBindings',BINDINGS),('_DynamicImportSourceScanner','ExtractedScanner',SCANNER)]:
  original_class=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==original)
  children=[copy.deepcopy(n) for n in original_class.body if isinstance(n,ast.FunctionDef) and n.name in methods]
  if remove_relevance:
   for child in children:
    if child.name!='_deferred_scope_importer_names':continue
    class Strip(ast.NodeTransformer):
     def visit_Expr(self,node):
      if isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Attribute) and node.value.func.attr=='update' and isinstance(node.value.func.value,ast.Name) and node.value.func.value.id=='relevant' and len(node.value.args)==1:
       arg=node.value.args[0]
       if isinstance(arg,ast.Attribute) and arg.attr=='_observed_importer_binding_names':return None
       if isinstance(arg,ast.Name) and arg.id=='_DYNAMIC_IMPORT_GUARDED_ROOTS':return None
      return self.generic_visit(node)
    Strip().visit(child)
  body.append(ast.ClassDef(name=renamed,bases=[],keywords=[],body=children,decorator_list=[],type_params=[]));selected.extend(original+'.'+n.name for n in children)
 module=types.ModuleType('extracted_dynamic_'+label);sys.modules[module.__name__]=module
 exec(compile(ast.fix_missing_locations(ast.Module(body=body,type_ignores=[])),str(OWNER)+'#extracted-'+label,'exec'),module.__dict__)
 return module,selected

profile_tree=ast.parse(PROFILE.read_bytes());profile_fields=next(n for n in profile_tree.body if isinstance(n,ast.FunctionDef) and n.name=='_profile_fields')
MODULE='polisyos.common.canonical_profile';CLASS=MODULE+'.CanonicalProfileRefusalError'

def context(m,invalidated):
 Binding=m._DynamicImportBinding
 class B(m.ExtractedBindings):
  def __init__(self):
   self.invalidated_source_classes=set(invalidated);self.environments={};self.module_paths={MODULE:PROFILE};self.source_trees_by_path={PROFILE:profile_tree};self.env={'CanonicalProfileRefusalError':Binding('other',origin_name=CLASS)}
  def _has_module(self,module):return module==MODULE
  def _module_tree(self,module):return profile_tree if module==MODULE else None
  def _module_environment(self,module,stack):return self.env if module==MODULE else None
  def invalidate_source_classes(self,names):self.invalidated_source_classes.update(names)
 class S(m.ExtractedScanner):
  def __init__(self):
   self.module_name=MODULE;self.relative_path='src/polisyos/common/canonical_profile.py';self.source_bindings=B();self.source_context=SimpleNamespace();self._observed_importer_binding_names={'selected_alias'};self._module_time_proven_scope_ids=set();self._pending_temporal_invocations=[];self._importer_binding_mutations={};self._importer_binding_revisions={}
  def _unknown_binding(self,name):return Binding('unknown',name=name)
 s=S();env=dict(s.source_bindings.env);deferred=m._PendingDynamicImportScope(profile_fields,dict(env),{})
 return s,env,deferred

def expect_error(m,fn,contains):
 try:fn()
 except m.DynamicImportCollectionError as exc:
  assert contains in str(exc),(contains,str(exc));return str(exc)
 raise AssertionError('required refusal missing: '+contains)

baseline,bnames=load(OWNER.read_bytes(),'baseline')
candidate_source=(O/'postimages'/OWNER.relative_to(R)).read_bytes();candidate,cnames=load(candidate_source,'candidate')
mutant,_=load(candidate_source,'removal',remove_relevance=True)
rows=[]
s,env,d=context(baseline,{CLASS})
rows.append({'control':'baseline-real-profile-class-is-invalidated','result':'EXPECTED_REFUSAL','detail':expect_error(baseline,lambda:s._deferred_scope_importer_names(d,env),'neither a selected function nor a selected class')})
s,env,d=context(candidate,{CLASS});roots=s._deferred_scope_importer_names(d,env);expected=candidate._DYNAMIC_IMPORT_GUARDED_ROOTS|s._observed_importer_binding_names;assert roots==expected,(roots,expected)
rows.append({'control':'candidate-all-tracked-roots-relevant','result':'PASS','roots':sorted(roots)})
assert s.source_bindings._source_class_definition(CLASS,current_module=MODULE,current_environment=env,stack=()) is None
assert s.source_bindings._source_class_identity_definition(CLASS,current_module=MODULE,current_environment=env,stack=()) is not None
rows.append({'control':'nominal-identity-does-not-admit-mutable-field-summary','result':'PASS'})
s._raise_for_unproven_temporal_invocations(env,[d]);rows.append({'control':'invalidated-class-unchanged-namespace','result':'PASS'})
for root in sorted(expected):
 s,env,d=context(candidate,{CLASS});s._importer_binding_mutations[root]=1
 detail=expect_error(candidate,lambda:s._raise_for_unproven_temporal_invocations(env,[d]),'proven importer rebind')
 rows.append({'control':'changed-tracked-root-'+root,'result':'PASS','detail':detail})
 removed,e,dd=context(mutant,{CLASS});removed._importer_binding_mutations[root]=1;removed._raise_for_unproven_temporal_invocations(e,[dd])
 rows.append({'control':'remove-relevance-keep-class-identity-'+root,'result':'EXPECTED_FALSE_GREEN'})
 restored,e,dd=context(candidate,{CLASS});restored._importer_binding_mutations[root]=1;expect_error(candidate,lambda:restored._raise_for_unproven_temporal_invocations(e,[dd]),'proven importer rebind')
 rows.append({'control':'restored-relevance-'+root,'result':'PASS'})
s,env,d=context(candidate,set());assert not(s._deferred_scope_importer_names(d,env)&expected);rows.append({'control':'noninvalidated-class-preserves-precise-method-dependencies','result':'PASS'})
s,env,d=context(candidate,{CLASS});s.source_bindings.env['CanonicalProfileRefusalError']=candidate._DynamicImportBinding('other',origin_name=MODULE+'.Rebound');assert s.source_bindings._source_class_identity_definition(CLASS,current_module=MODULE,current_environment=s.source_bindings.env,stack=()) is None
rows.append({'control':'rebound-source-class-not-nominally-selected','result':'PASS'})
s,env,d=context(candidate,{CLASS});s.source_bindings.env['CanonicalProfileRefusalError']=candidate._DynamicImportBinding('other',origin_name=CLASS);profile_tree.body.append(copy.deepcopy(next(n for n in profile_tree.body if isinstance(n,ast.ClassDef) and n.name=='CanonicalProfileRefusalError')));assert s.source_bindings._source_class_identity_definition(CLASS,current_module=MODULE,current_environment=env,stack=()) is None;profile_tree.body.pop()
rows.append({'control':'duplicate-source-class-remains-unresolved','result':'PASS'})
result={'scope':'Extracted original/candidate owner methods and actual profile AST; hand-bound finite environments, not full collector, actual source-effect origin, product imports or runtime','owner_sha256':sha(OWNER.read_bytes()),'candidate_sha256':sha(candidate_source),'profile_sha256':sha(PROFILE.read_bytes()),'selected_extracted_definitions':cnames,'definition_count':len(cnames),'control_count':len(rows),'results':rows,'actual_full_collector':'UNRUN','actual_pytest':'UNRUN','G_acceptance':False,'closure_ids':[]}
output_name=sys.argv[1] if len(sys.argv)>1 else 'extracted-controls-result.json'
assert Path(output_name).name==output_name
with (O/output_name).open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'control_count':len(rows),'definition_count':len(cnames),'result':'PASS','scope':result['scope']}))
