"""Static AST-only exact selector plan; imports no repository/product/test module."""
from pathlib import Path
import ast
import hashlib
import json
import subprocess
import tomllib

ROOT=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
PRODUCT=ROOT/'policy-engine'
P=Path(__file__).resolve().parent
legacy=PRODUCT/'tests/repo_quality/architecture/test_decomposition_preflight_gates.py'
new=PRODUCT/'tests/repo_quality/architecture/test_dynamic_code_reconstitution.py'
owner=PRODUCT/'tools/quality/validation/decomposition_preflight.py'
paths=[legacy,new,owner,PRODUCT/'src/polisyos/runtime/http/resilience.py',PRODUCT/'tests/conftest.py',PRODUCT/'pyproject.toml']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
readset={str(p.relative_to(ROOT)):sha(p) for p in paths}
tree=ast.parse(legacy.read_text());module_functions=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))];tests=[n for n in module_functions if n.name.startswith('test_')];selected=[n for n in tests if 'dynamic' in n.name]
assert len(tests)==258 and len(selected)==185
nodeids=[str(legacy.relative_to(PRODUCT))+'::'+n.name for n in selected]
assert len(nodeids)==len(set(nodeids))
newtree=ast.parse(new.read_text());newtests=[n for n in newtree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_')]
cases=next(n.value for n in newtree.body if isinstance(n,ast.Assign) and any(isinstance(target,ast.Name) and target.id=='CASES' for target in n.targets))
new_module=str(new.relative_to(PRODUCT));selectors=[*nodeids,new_module]
# Persist exact selectors without dumping the name set into the narrative/tool result.
(P/'selectors.txt').write_text('\n'.join(selectors)+'\n')
(P/'selectors.json').write_text(json.dumps({'legacy_nodeids':nodeids,'new_module':new_module,'all_selectors':selectors},indent=2)+'\n')
output=str(P/'native-results-r1')
argv=['.venv/bin/python','-B','-m','pytest','-q','--tb=short','--durations=15','--junitxml='+output+'/junit.xml',*selectors]
(P/'pytest-argv.json').write_text(json.dumps({'cwd':str(PRODUCT),'argv':argv,'execution_owner':'Root','execution_status':'UNRUN','output_root':output},indent=2)+'\n')
opts=tomllib.loads((PRODUCT/'pyproject.toml').read_text()).get('tool',{}).get('pytest',{}).get('ini_options',{}).get('addopts')
plan={'kind':'static_exact_affected_native_selector_plan','source_head_tree':subprocess.check_output(['git','rev-parse','HEAD','HEAD^{tree}'],cwd=ROOT,text=True).splitlines(),'readset_sha256':readset,'counts':{'legacy_all_AST_functions':sum(isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) for n in ast.walk(tree)),'legacy_module_functions':len(module_functions),'legacy_module_test_functions':len(tests),'legacy_dynamic_named_test_functions':len(selected),'legacy_non_dynamic_test_functions':len(tests)-len(selected),'legacy_prefix_test_dynamic_count':sum(n.name.startswith('test_dynamic') for n in tests),'new_module_test_functions':len(newtests),'new_module_literal_CASES':len(cases.keys),'selector_argv_items':len(selectors)},'selector_rule':'Every module-level test function with dynamic in its name, plus the entire new module. Explicit function nodeids avoid -k keyword/parameter-ID over-selection and avoid prefix omission.','prefix_exception':[n.name for n in selected if not n.name.startswith('test_dynamic')],'denominator':'Complete AST of the two named .py test files, module-level pytest test functions; nested helpers counted separately. No native collection/item count claimed.','artifacts':{'selectors':'selectors.json / selectors.txt','native_argv':'pytest-argv.json'},'collection_reconciliation':'Root must record expanded pytest items/param IDs, errors, skips and quarantine/deselection; 185 is a function-selector count, not the native case count. New module nominal 63 CASES plus 3 direct tests, before plugins.','native_status':'UNRUN; child performed no repository imports, pytest collection or runtime tests.','resource_recommendation':{'execution':'One Root-owned supervised native process; serial pytest (no xdist), retain child subprocess monitoring. No concurrent heavy/native lane or full collector.','initial_process_tree_RSS_cap_bytes':3*1024**3,'initial_wall_timeout_seconds':600,'admission_available_memory_bytes':8*1024**3,'low_memory_stop_floor_bytes':6*1024**3,'authority':'Recommendation reuses prior dynamic-native operational envelope, not a newly measured 185-function benchmark. Root owns final admission.','outputs':'Complete stdout/stderr, JUnit, command/env/interpreter/source pins, process-tree RSS/wall/abort reason; no retry-to-green. A harness abort is not a product assertion failure.','economics':'Run the complete affected selection once after source freeze/review. Do not separately rerun the new module or R3 subset before it; they are included. Measure wall/RSS once and adapt only on material failure.'},'pytest_config_addopts':opts,'scope_limits':['Not full suite or cloud.','Does not demonstrate full selected-root collection, registry freshness, or actual resilience opaque executor/context clearance.','Current conftest explicitly registers artifacts/observability plugins; static-only source inspection is not a native startup memory receipt.']}
(P/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
assert readset=={str(p.relative_to(ROOT)):sha(p) for p in paths}
print(json.dumps({'source_head_tree':plan['source_head_tree'],'counts':plan['counts'],'prefix_exception':plan['prefix_exception'],'selector_file':str(P/'selectors.txt'),'native_argv':str(P/'pytest-argv.json'),'pytest_config_addopts':opts},indent=2))
