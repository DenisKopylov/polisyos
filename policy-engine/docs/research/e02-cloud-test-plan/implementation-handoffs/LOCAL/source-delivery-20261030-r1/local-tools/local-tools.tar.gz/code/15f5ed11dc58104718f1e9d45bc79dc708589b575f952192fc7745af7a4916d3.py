"""Root-only preparation of a fresh, exact-source C07 CAS pilot plan."""
from pathlib import Path
import hashlib
import json
import re
import runpy
import subprocess
import sys

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
D = ROOT / "policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1"
OLD = D / "c07-cas-owner-snapshot-probe-r2-20261028.json"
HERE = Path(__file__).resolve().parent
OWNER = "policy-engine/src/polisyos/core/artifacts/ownership.py"
TEST = "policy-engine/tests/unit/core/artifacts/test_cas_owner_snapshot_query.py"
OWNER_SHA256 = "ba56a58da7f9929d33384e71e8c3bf8877a64775b0a7e3c69deed5f991ec0ce7"
TEST_SHA256 = "7335f1be5372e0b47e67c99a4d95458f86204e07bdcdcd2774ff401a40b93de0"
INSPECTOR_SHA256 = "5b2ed06529095208bb0174e50639e8f7af54fe6c73cc8303d6faa98965de88af"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True).strip()


def main():
    if len(sys.argv) != 2 or not re.fullmatch(r"c07-cas-owner-query-pilot-[A-Za-z0-9_-]+", sys.argv[1]):
        raise SystemExit("one unique c07-cas-owner-query-pilot-* case ID is required")
    case = sys.argv[1]
    plan_path = D / (case + ".json")
    out_path = D / case
    receipt_path = HERE / (case + "-preparation.json")
    if plan_path.exists() or out_path.exists() or receipt_path.exists():
        raise SystemExit("plan/output/receipt already exists; choose a unique case ID")
    if git("symbolic-ref", "--short", "HEAD") != "codex/e02-unified-local-20261009":
        raise SystemExit("branch mismatch")
    if git("status", "--porcelain", "--untracked-files=no"):
        raise SystemExit("tracked source or index is dirty")
    head = git("rev-parse", "HEAD")
    tree = git("rev-parse", "HEAD^{tree}")
    guard = runpy.run_path(str(D.parent / "root-layer-lib.py"))["guard"]
    binding = guard()
    if binding["head"] != head:
        raise SystemExit("root journal HEAD differs from actual HEAD")
    if digest(ROOT / OWNER) != OWNER_SHA256 or digest(ROOT / TEST) != TEST_SHA256:
        raise SystemExit("reviewed owner or test bytes differ")
    inspector = HERE / "inspect_snapshot_query_pilot.py"
    if digest(inspector) != INSPECTOR_SHA256:
        raise SystemExit("pilot inspector bytes differ")
    if digest(OLD) != "7d463cd393145dc95523ba52104320baeff3cebfdd78562eb59823557a4fe736":
        raise SystemExit("reviewed predecessor plan bytes differ")
    old = json.loads(OLD.read_text())
    pins = dict(old["input_pins"])
    source_changes = []
    for path, expected in pins.items():
        actual = digest(ROOT / path)
        if path == OWNER:
            if actual != OWNER_SHA256:
                raise SystemExit("final owner mismatch")
        elif actual != expected:
            if not path.startswith("policy-engine/src/") or actual is None:
                raise SystemExit("non-source frozen input mismatch: " + path)
            source_changes.append({"path": path, "r2_sha256": expected, "actual_sha256": actual})
        pins[path] = actual
    pins[TEST] = TEST_SHA256
    pins[str(inspector.relative_to(ROOT))] = INSPECTOR_SHA256
    plan = {"case_id": case, "source_head": head, "source_tree": tree,
        "source_frame": binding["source_frame"], "runner_sha256": old["runner_sha256"],
        "probe_sha256": old["probe_sha256"], "input_pins": pins,
        "deadline_seconds": 300, "rss_cap_bytes": 2415919104,
        "scope": "One actual guarded Search inventory write using 192 role edges/27 selected views and the retained synthetic predecessor clone. No HTE rerun, authority or G closure.",
        "closures": [],
        "source_rebind": {"previous_plan": str(OLD.relative_to(ROOT)),
            "previous_plan_sha256": digest(OLD), "previous_head": old["source_head"],
            "owner_old_sha256": old["input_pins"][OWNER], "owner_new_sha256": OWNER_SHA256,
            "other_changed_source_pins": source_changes,
            "review_requirement": "Review every recorded changed input against the actual head before launch; no old readset is asserted current."}}
    plan_bytes = (json.dumps(plan, indent=2) + "\n").encode()
    launch = "python3 " + str(ROOT / "LOCAL/raw/e02-execution-20261027/repairs/C07-CAS-timeout-r2/run_probe.py") + " " + str(plan_path)
    inspect = "python3 " + str(inspector) + " " + str(out_path)
    receipt = {"case_id":case, "head":head, "tree":tree, "frame":binding["source_frame"],
        "plan":str(plan_path), "plan_sha256":hashlib.sha256(plan_bytes).hexdigest(),
        "preparer_sha256":digest(Path(__file__)), "inspector_sha256":INSPECTOR_SHA256,
        "source_changes":source_changes, "launch":launch,
        "launch_sha256":hashlib.sha256(launch.encode()).hexdigest(), "inspect":inspect,
        "inspect_sha256":hashlib.sha256(inspect.encode()).hexdigest(),
        "scope":"Preparation only; source review, solitary resource admission and runtime are separate.", "closures":[]}
    with plan_path.open("xb") as f:
        f.write(plan_bytes)
    with receipt_path.open("x") as f:
        f.write(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
