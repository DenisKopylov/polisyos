from __future__ import annotations

import ast
import hashlib
import json
import subprocess
import tomllib
from pathlib import Path

root = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
packet = root / 'LOCAL/raw/e02-execution-20261027/repairs/V3-bridge-rule-owner-r3'
manifest = json.loads((packet / 'manifest.json').read_text())
checks = []
for name, item in manifest['postimages'].items():
    raw = (root / item['path']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == item['sha256']
    if name.endswith('.py'):
        ast.parse(raw, filename=name)
        relative = name.removeprefix('policy-engine/')
        for command in ('check', 'format'):
            args = [str(root / 'policy-engine/.venv/bin/python'), '-m', 'ruff', command,
                    '--stdin-filename', relative, '-']
            result = subprocess.run(args, input=raw, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                    cwd=root / 'policy-engine', check=False)
            if result.returncode or (command == 'format' and result.stdout != raw):
                output = result.stderr.decode() if command == 'format' else result.stdout.decode()
                raise RuntimeError(f'{name}: {command}: {output[:4000]}')
        checks.append({'path': name, 'ast': 'PASS', 'ruff': 'PASS', 'format': 'PASS'})
    elif name.endswith('.toml'):
        tomllib.loads(raw.decode())
        checks.append({'path': name, 'toml_parse': 'PASS'})
    else:
        raw.decode('utf-8')
        checks.append({'path': name, 'utf8': 'PASS'})
# The planned mutation locates the actual bridge's one owner-rule and one
# source-view predicates. This is a syntax census, not an executed mutation.
growth = root / manifest['postimages']['policy-engine/src/polisyos/runtime/quality/acquisition_world_growth.py']['path']
tree = ast.parse(growth.read_text())
methods = [n for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
           and n.name == '_reconcile_acquired_candidate_values']
assert len(methods) == 1
rule_sites = [n for n in ast.walk(methods[0]) if isinstance(n, ast.Compare)
              and isinstance(n.left, ast.Attribute) and isinstance(n.left.value, ast.Name)
              and n.left.value.id == 'replayed' and n.left.attr == 'effective_rules'
              and len(n.ops) == 1 and isinstance(n.ops[0], ast.NotEq)
              and len(n.comparators) == 1 and isinstance(n.comparators[0], ast.Attribute)
              and isinstance(n.comparators[0].value, ast.Name)
              and n.comparators[0].value.id == 'prospective_values'
              and n.comparators[0].attr == 'effective_rules']
view_sites = [n for n in ast.walk(methods[0]) if isinstance(n, ast.If)
              and isinstance(n.test, ast.UnaryOp) and isinstance(n.test.op, ast.Not)
              and isinstance(n.test.operand, ast.Call)
              and isinstance(n.test.operand.func, ast.Name)
              and n.test.operand.func.id == 'same_selected_view']
assert len(rule_sites) == len(view_sites) == 1
preimages = json.loads((root / manifest['preimages']['path']).read_text())
for name, pin in preimages.items():
    if pin['sha256'] is None:
        assert not (root / name).exists()
        continue
    local = (root / name).read_bytes()
    assert hashlib.sha256(local).hexdigest() == pin['sha256']
    assert local == subprocess.check_output(['git', 'show', f"{manifest['base']}:{name}"], cwd=root)
result = subprocess.run(['git', 'apply', '--check', str(packet / 'proposal.patch')], cwd=root,
                        stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
assert result.returncode == 0, result.stderr.decode()
report = {'status': 'PASS', 'checks': checks, 'preimage_readbacks': len(preimages),
          'patch_apply_check': 'PASS', 'ast_mutation_sites': {'rule': 1, 'view': 1}, 'product_imports': 'NOT_RUN', 'runtime_tests': 'NOT_RUN'}
(packet / 'static-checks.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps({'paths': len(checks), 'preimage_readbacks': len(preimages),
                  'patch_apply_check': 'PASS', 'runtime': 'NOT_RUN'}))
