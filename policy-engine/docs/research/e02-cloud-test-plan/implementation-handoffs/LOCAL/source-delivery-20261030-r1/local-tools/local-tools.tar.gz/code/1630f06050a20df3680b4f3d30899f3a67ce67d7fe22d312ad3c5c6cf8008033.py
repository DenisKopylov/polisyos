from pathlib import Path
import hashlib,json,subprocess,ast
R=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos');H=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=json.loads((H/'proposal.json').read_text());posts={x['path']:x for x in p['files']};base=H.parent/'C48-compile-state-view-r3-final-r1'
x=json.loads((base/'existing-controls-rebound.json').read_text());affected=[]
for c in x['cases']:
 if c['test_source'] in posts:
  c['test_sha256']=posts[c['test_source']]['post_sha256'];c['disposition']='Test-only fixture coherence rebind; production source/patch/mutant unchanged; behavior UNRUN';affected.append(c['id'])
x['status']='Complete21control test-only successor; eight affected test hashes, no source/mutant change';x['affected_ids']=affected;assert len(affected)==8
(H/'affected-controls.json').write_text(json.dumps(x,indent=2)+'\n')
x=json.loads((base/'graph-removal.json').read_text());x['test_sha256']=posts[x['test_source']]['post_sha256'];x['disposition']='Test-only helper arithmetic/fixture migration rebind; graph source/patch/mutant unchanged';(H/'graph-removal-rebound.json').write_text(json.dumps(x,indent=2)+'\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='d9397c7c0458ec2980fa58115c5ee597eb58dbc8';proof=[]
for row in p['files']:
 live=sha(R/row['path']);committed=subprocess.check_output(['git','show',head+':'+row['path']],cwd=R);assert live==hashlib.sha256(committed).hexdigest()==row['pre_sha256'];proof.append({'path':row['path'],'live_and_committed_sha256':live,'proposed_sha256':row['post_sha256']})
(H/'preimage-proof.json').write_text(json.dumps({'head':head,'files':proof,'production_changes':[]},indent=2)+'\n')
# Positive fixture arithmetic derives from selected rows; complete baseline argument callers are finite here.
testpath='policy-engine/tests/unit/scientist/nodes/builtins/decide/test_policy_runtime_method_metrics.py';tree=ast.parse((H/posts[testpath]['postimage']).read_text());sites=[]
for node in ast.walk(tree):
 if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='_exercise_public_execute_method_metric_source':
  keys=[k.arg for k in node.keywords]
  if 'baseline_values' in keys:sites.append({'line':node.lineno,'baseline':ast.unparse(next(k.value for k in node.keywords if k.arg=='baseline_values'))})
(H/'baseline-caller-census.json').write_text(json.dumps({'denominator':'Complete proposed shared test module AST helper-call set; baseline keyword sites only, not external/dynamic calls','sites':sites},indent=2)+'\n')
p.update(status='Frozen bounded test/doc fixture successor; no production change; independent review pending',capability_status='verification_missing',head_at_freeze=head,failure_evidence_sha256=sha(H/'failure-evidence.json'),affected_control_count=8,source_control_inventory_count=21)
p['support_sha256']={str(f.relative_to(H)):sha(f) for f in sorted(H.rglob('*')) if f.is_file() and f.name!='manifest.json'};(H/'manifest.json').write_text(json.dumps(p,indent=2)+'\n');print({'manifest':sha(H/'manifest.json'),'patch':sha(H/'source.patch'),'preimages':proof,'support_count':len(p['support_sha256'])})
