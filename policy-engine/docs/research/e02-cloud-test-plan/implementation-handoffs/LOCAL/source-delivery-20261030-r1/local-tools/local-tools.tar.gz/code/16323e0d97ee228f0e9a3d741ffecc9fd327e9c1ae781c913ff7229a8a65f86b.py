from pathlib import Path
import subprocess,json,hashlib,difflib,ast
r=Path.cwd();raw=Path(__file__).parent;d=raw/'policy-engine';tree='53a834c476dfc2461ad17cc8c5fc9e128247d599'
for rel in ['src/polisyos/core/llm/README.md','src/polisyos/scientist/orchestration/llm/README.md','src/polisyos/scientist/orchestration/engine/README.md']:
 p=d/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(subprocess.check_output(['git','show',tree+':policy-engine/'+rel]))
p=d/'src/polisyos/core/llm/README.md';s=p.read_text();s+='''

### Shared cache lifetime

The exact cache owns the Core settlement session. Each request wrapper is registered
explicitly with `bind_cache_settlement_client`; a mutable application attribute cannot
alias another cache owner. Attestations bind the exact response object **and its content
digest** to one settled physical origin. A different body on the same response object,
or a later cache head paired with an earlier flight outcome, is refused.

Completed-flight request state is released after its last live waiter. Retained origins
are bounded independently of a cache adapter: the wrapper's `origin_retention_limit`
defaults to128 entries, while the gateway factory supplies its configured cache size;
producer TTL bounds origin retention. A shared owner's bound may tighten, never widen,
when another wrapper binds it. Native LRU eviction/expiry/clear also removes the matching
origin immediately. A retention miss is a physical cache miss, not an unauthenticated
zero-cost reuse. Existing issued response proofs retain their historical meaning.

Scientist's ledger owns durable cross-run admission. It verifies the live Core response
proof and freezes the configured authorizer scope/epoch, then recomputes the cache key
and both physical/reuse event payloads on reopen. Core does not issue external permission
or replace the configured authorizer.
''';p.write_text(s)
p=d/'src/polisyos/scientist/orchestration/llm/README.md';s=p.read_text();s+='''

Configured runtime prompt caches live with the application; provider/traced wrappers and
settlement hooks remain request-local. Shared cache flights use one concurrent result
across request event loops, and followers consume an immutable snapshot of their exact
flight rather than whichever entry is currently at the cache head. No-key and explicit
zero-size/zero-TTL modes remain uncached. `GatewayLLMConfig.cache_maxsize` also bounds
retained Core origins; legacy get/put-only adapters cannot cause unbounded Core history.
The current authorizer still runs for every candidate reuse, including cache hits.
''';p.write_text(s)
p=d/'src/polisyos/scientist/orchestration/engine/README.md';s=p.read_text();old='''The ledger's current snapshot version is `1.2`. Complete valid `1.0` and `1.1`
snapshots migrate explicitly; unknown versions, contracts and coordination modes
are rejected. Version `1.2` retains producer settlement records, including
pending and unknown outcomes, in the same atomic snapshot as budget state and
spend receipts. Existing receipts keep their original accounting meaning:
migration cannot certify a previously unknown provider cost.''';new='''The ledger writer's current snapshot version is `1.5`; complete valid `1.0` through
`1.4` snapshots remain readable. Unknown versions, contracts and coordination modes
are rejected. Version `1.2` introduced producer settlement records; `1.3` added
server-issued run binding, `1.4` added attempt attribution, and `1.5` adds an optional
`BudgetLedgerCacheReuseAdmission`. Existing receipts keep their original accounting
meaning: migration cannot certify a previously unknown provider cost.

Cross-run reuse requires the exact live Core response proof at the new write. The
ledger freezes its authorizer scope/epoch and content digest, recomputes the internal
cache key and both event payloads, and requires matching tenant/cell/profile with the
exact original physical source. The receiver retains its own key/run binding and a
separate zero event; the source is never copied or reissued under the receiver run.
A matching string-shaped origin without that admission still refuses. Reopen and the
runtime budget consumer share `BudgetLedgerProducerRecord.validate_reuse_origin`.
This is local accounting admission, not institutional permission or provider billing
attestation. The runtime budget gate continues to require a known physical source cost.''';assert old in s;s=s.replace(old,new,1);p.write_text(s)
p=d/'release-fragments/unreleased/2026-10-27-e02-cache-reuse-lifetime.toml';p.parent.mkdir(parents=True,exist_ok=True);p.write_text('''id = "2026-10-27-e02-cache-reuse-lifetime"
title = "Bind authorized cache reuse to exact shared-cache origins"
type = "fixed"
component = "runtime"
owner = "team-polisyos"
summary = "Keep provider hooks request-local while sharing one bounded cache owner and flight; verify exact response content and explicit wrapper registration, then retain separate zero-cost receiver events across authorized compatible runs."
compatibility = "Existing ledger1.0–1.4 snapshots remain readable; new writes use1.5 with optional typed reuse admission. Same-run reuse retains its original contract. No HTTP request/response DTO change."
change_class = "additive"
surface_classification = "public_stable: Core cache settlement and Scientist engine facade; additive registration/admission APIs."
migration = "Upgrade ledger readers before enabling1.5 writers across processes. No source event is copied/reissued. Custom direct Core flight producers must bind the actual response digest and retention TTL before issuing a response proof."
api = "The new cross-run bridge verifies a live Core session/response; a caller-created admission model cannot authorize a new ledger write. No-key and zero-size/TTL modes remain uncached."
limitations = "Local accounting admission does not certify provider invoices or institutional permission. Runtime, HTTP, adversarial and removal verification for this proposal is unrun until root composition."
evidence = ["src/polisyos/core/llm/cache_settlement.py", "src/polisyos/scientist/orchestration/engine/budget_ledger.py", "tests/unit/core/llm/test_cache_settlement.py", "tests/unit/core/llm/test_traced_client_settlement.py", "tests/unit/scientist/orchestration/llm/test_prompt_cache.py", "tests/integration/runtime/http/test_nl_pipeline_cache_reuse_authorization.py"]
generated_client_compatibility = "not_applicable"
public_surface_inventory_reviewed = false
migration_docs = ["src/polisyos/scientist/orchestration/engine/README.md"]
runbook_docs = []
''')
