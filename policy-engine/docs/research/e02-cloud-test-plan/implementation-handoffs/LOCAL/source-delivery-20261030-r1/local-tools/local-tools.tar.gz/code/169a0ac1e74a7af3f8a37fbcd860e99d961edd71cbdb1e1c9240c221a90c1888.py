from pathlib import Path
r=Path(__file__).parent/'policy-engine'
def update(p,old,new):
 f=r/p;t=f.read_text();n=t.count(old)
 if n!=1:raise RuntimeError((str(p),n,old[:80]))
 f.write_text(t.replace(old,new))
p=Path('src/polisyos/fabric/ingestion/source_progress.py')
update(p,'    transport_bytes_hash: str | None = None','    transport_bytes_hash: str | None = None\n    transport_bytes: bytes | None = None')
# common actual transport validator replays the complete physical row universe.
start='''        if self.extension.transport_kind == "finite_history_file":
            if raw != self.fixture_bytes:
                raise ValueError("actual history replay differs from the frozen source")
        else:
            # Identity-only scope permits physical redeliveries/annotations, but
            # every actual logical key must be in the owner, and vice versa.
            rows = [json.loads(line, object_pairs_hook=_json_object) for line in raw.splitlines() if line.strip()]
            roles = self.extension.event_fields + self.extension.version_fields
            actual_keys: set[str] = set()
            for row in rows:
                if not isinstance(row, dict):
                    raise ValueError("actual JSONL transport contains a non-object event")
                self._validate_key_schema(row)
                actual_keys.add(_key(row, roles))
            if actual_keys != {_key(row, roles) for row in self.current.rows}:
                raise ValueError("actual whole JSONL source differs from the owner universe")'''
update(p,start,'        self._validate_transport_bytes(raw)')
update(p,'            transport_bytes_hash=content_hash(raw),\n        )\n\n    def assert_transport_current','''            transport_bytes_hash=content_hash(raw),
            transport_bytes=raw,
        )

    def _validate_transport_bytes(self, raw: bytes) -> None:
        if len(raw) > _MAX_FINITE_FIXTURE_BYTES:
            raise ValueError("actual replay transport exceeds the finite admission bound")
        if self.extension.transport_kind == "finite_history_file":
            if raw != self.fixture_bytes:
                raise ValueError("actual history replay differs from the frozen source")
            return
        # Enumerate ALL physical events. Identity-only scope permits physical
        # redelivery annotations, never omitted logical keys in either direction.
        rows = [json.loads(line, object_pairs_hook=_json_object) for line in raw.splitlines() if line.strip()]
        roles = self.extension.event_fields + self.extension.version_fields
        actual_keys: set[str] = set()
        for row in rows:
            if not isinstance(row, dict):
                raise ValueError("actual JSONL transport contains a non-object event")
            self._validate_key_schema(row)
            actual_keys.add(_key(row, roles))
        if actual_keys != {_key(row, roles) for row in self.current.rows}:
            raise ValueError("actual whole JSONL source differs from the owner universe")

    def assert_transport_current''')
update(p,'            old = self.reader._parse_history(raw.encode("utf-8"), tenant_id=self.tenant_id)\n            snapshots','''            old = self.reader._parse_history(raw.encode("utf-8"), tenant_id=self.tenant_id)
            transport_raw = raw if self.extension.transport_kind == "finite_history_file" else witness.get("transport_jsonl")
            if not isinstance(transport_raw, str) or content_hash(transport_raw.encode()) != witness.get("transport_sha256"):
                return None
            old._validate_transport_bytes(transport_raw.encode())
            snapshots''')
update(p,'            "transport_sha256": self.transport_bytes_hash,\n            "extension":','''            "transport_sha256": self.transport_bytes_hash,
            # The history file is already retained below. JSONL is a separate
            # physical transport: retain its deciding bytes once so a fresh
            # reader can recompute its complete logical key universe.
            "transport_jsonl": self.transport_bytes.decode("utf-8") if self.extension.transport_kind == "jsonl_file" and self.transport_bytes is not None else None,
            "extension":''')
p=Path('src/polisyos/fabric/data_plane/streaming.py')
update(p,'    source_progress_ref: ArtifactRef | None = None\n    clock_profile','''    selected_config = connection_config
    if progress_frame is not None:
        try:
            from polisyos.fabric.connectors.sources.event_stream import EventStreamConnector

            resolved_registry = _resolve_connector_registry(registry=registry, registry_provider=registry_provider)
            entry = resolved_registry.get_entry(connector_id)
            config = normalize_connection_config(connection_config) or entry.default_config
            if config is None or progress_frame.extension.transport_kind != "jsonl_file":
                raise ValueError("source owner has no actual JSONL replay transport")
            # The real selected factory and physical handle are checked again
            # below. This preflight rejects unowned transports before effects.
            if entry.connector_class.fetch_stream is not EventStreamConnector.fetch_stream:
                raise ValueError("source reader cannot authorize an unrelated stream producer")
            progress_frame = progress_frame.bind_transport(config, partition_key=options.partition_key)
            selected_config = config
            registry = resolved_registry
            processing_contract = processing_contract.model_copy(update={"guarantee": ProcessingGuarantee.REPLAY_ONLY})
        except (LookupError, OSError, TypeError, ValueError) as exc:
            raise StreamDedupeUnsupported("actual source replay transport is not established") from exc
    source_progress_ref: ArtifactRef | None = None
    clock_profile''')
update(p,'        connection_config=connection_config,\n        partition_key=options.partition_key,\n        registry=registry,','        connection_config=selected_config,\n        partition_key=options.partition_key,\n        registry=registry,')
update(p,'    try:\n        result = StreamDatasetRunResult(','    try:\n        if progress_frame is not None:\n            if (\n                session.connector is None\n                or session.handle is None\n                or type(session.connector).fetch_stream is not EventStreamConnector.fetch_stream\n                or isinstance(session.connector, (_StreamSubscriber, _StreamPoller))\n            ):\n                raise StreamDedupeUnsupported("actual selected producer is not the bounded JSONL file reader")\n            rebound = progress_frame.bind_transport(session.handle.config, partition_key=session.partition_key)\n            if rebound.transport_identity != progress_frame.transport_identity:\n                raise StreamDedupeUnsupported("actual selected handle changed the source transport")\n        result = StreamDatasetRunResult(')
update(p,'            if latest_checkpoint.metadata.get("ingestion_clock_profile") != clock_profile:\n                raise StreamDedupeUnsupported("ingestion clock profile changed across restart")','''            previous_clock_profile = latest_checkpoint.metadata.get("ingestion_clock_profile")
            legacy_disabled = (
                previous_clock_profile is None
                and not processing_contract.idempotency.enabled
                and not latest_checkpoint.dedupe_keys
                and options.ingestion_clock is None
            )
            if previous_clock_profile != clock_profile and not legacy_disabled:
                raise StreamDedupeUnsupported("ingestion clock profile changed across restart")''')
# Every finite admitted stream artifact retains its scope and exact witness.
f=r/p;t=f.read_text()
t=t.replace('''                progress_frame.assert_current()
''','''                progress_frame.assert_current()
                progress_frame.assert_transport_current()
''')
t=t.replace('''            progress_frame.assert_current()
            if source_progress_ref''','''            progress_frame.assert_current()
            progress_frame.assert_transport_current()
            if source_progress_ref''')
# Signatures of three async writers, their invocations, and payloads are updated together.
t=t.replace('''    visible_fields: tuple[str, ...] | None = None,
) -> ArtifactRef:
    payload = {''','''    visible_fields: tuple[str, ...] | None = None,
    source_progress_scope: dict[str, Any] | None = None,
) -> ArtifactRef:
    payload = {''',1)
# CDC has a different prefix body.
t=t.replace('''    visible_fields: tuple[str, ...] | None = None,
) -> ArtifactRef:
    previous = set(previous_fields)''','''    visible_fields: tuple[str, ...] | None = None,
    source_progress_scope: dict[str, Any] | None = None,
) -> ArtifactRef:
    previous = set(previous_fields)''',1)
t=t.replace('''    input_refs: tuple[ArtifactRef | str, ...] | None = None,
) -> ArtifactRef:
    if input_ref''','''    input_refs: tuple[ArtifactRef | str, ...] | None = None,
    source_progress_scope: dict[str, Any] | None = None,
) -> ArtifactRef:
    if input_ref''',1)
# Each actual process-loop call gets scope, no external callers need a new argument.
t=t.replace('''                    visible_fields=visible_schema,
                )''','''                    visible_fields=visible_schema,
                    source_progress_scope=(progress_frame.scope_payload(source_progress_ref) if progress_frame is not None and source_progress_ref is not None else None),
                )''',1)
t=t.replace('''                visible_fields=visible_schema,
            )
            result.chunk_refs''','''                visible_fields=visible_schema,
                source_progress_scope=(progress_frame.scope_payload(source_progress_ref) if progress_frame is not None and source_progress_ref is not None else None),
            )
            result.chunk_refs''',1)
t=t.replace('''                        window_policy=options.window_policy,
                    )
                )''','''                        window_policy=options.window_policy,
                        source_progress_scope=(progress_frame.scope_payload(source_progress_ref) if progress_frame is not None and source_progress_ref is not None else None),
                    )
                )''',1)
t=t.replace('''                    window_policy=options.window_policy,
                )
            )

        if progress_frame''','''                    window_policy=options.window_policy,
                    source_progress_scope=(progress_frame.scope_payload(source_progress_ref) if progress_frame is not None and source_progress_ref is not None else None),
                )
            )

        if progress_frame''',1)
# Limit insertion to exact async-writer blocks, not other sync owners.
for start,end in [('_persist_stream_chunk_async','_persist_stream_window_async'),('_persist_stream_window_async','resolve_dedupe_key'),('_persist_cdc_schema_change_event_async','persist_cdc_schema_change_event')]:
 s=t.index(('async def ' if start.startswith('_persist') else 'def ')+start+'(')
 e=t.index('\n'+('async def ' if end.startswith('_persist') else 'def ')+end+'(',s)
 block=t[s:e]
 needle='''        "processing": processing_contract_snapshot(processing_contract),'''
 assert block.count(needle)==1,(start,block.count(needle))
 block=block.replace(needle,needle+'\n        "source_progress": source_progress_scope,')
 t=t[:s]+block+t[e:]
f.write_text(t)
# Keep governed EvidenceBundle schema/governance from exact source view.
p=Path('src/polisyos/fabric/ingestion/source_collection.py')
update(p,'    evidence = EvidenceBundle.model_validate(load_core_json_artifact(store, evidence_ref))','''    evidence = EvidenceBundle.model_validate(load_core_json_artifact(store, evidence_ref))
    source_manifest = store.get_manifest(evidence_ref)''')
update(p,'schema=SchemaInfo(name="fabric.SourceCollection", version="1.0"), inputs=inputs,','schema=SchemaInfo(name="fabric.SourceCollection", version="1.0"), inputs=inputs, governance=source_manifest.governance,')
update(p,'schema=SchemaInfo(name="polisyos.core.EvidenceBundle", version="0.2.0"),','schema=source_manifest.schema, governance=source_manifest.governance,')
print('actual stream transport and bounded emitted scope repaired in sparse r2')
