"""Adversarial pytest plugin: remove the gate while leaving request/schema markers.

Run only with a configured-context-withholding witness; it must FAIL under
this plugin. This is a temporary runtime control, not product implementation.
"""

import pytest


@pytest.fixture(autouse=True)
def tc_remove_context_gate(monkeypatch):
    from polisyos.runtime.http.services.control import ControlPlaneService

    monkeypatch.setattr(
        ControlPlaneService,
        "_prepare_control_nl_temporal_world_read",
        lambda self, context, **_kwargs: True,
    )
