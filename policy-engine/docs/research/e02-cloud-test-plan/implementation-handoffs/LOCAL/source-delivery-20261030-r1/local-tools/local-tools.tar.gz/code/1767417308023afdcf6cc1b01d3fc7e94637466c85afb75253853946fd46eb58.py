"""Static EnginePlan field/access census; no project import or runtime calls."""
from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path

root = Path.cwd()
source = root / 'policy-engine/src/polisyos/runtime/quality/joint_simulation_horizon.py'
tree = ast.parse(source.read_bytes(), filename=str(source))
cls = next(x for x in tree.body if isinstance(x, ast.ClassDef) and x.name == 'EnginePlan')
fields = [x.target.id for x in cls.body if isinstance(x, ast.AnnAssign) and isinstance(x.target, ast.Name)]
excluded = [
    x.target.id for x in cls.body
    if isinstance(x, ast.AnnAssign) and isinstance(x.target, ast.Name)
    and x.value is not None
    and any(isinstance(n, ast.keyword) and n.arg == 'exclude' and isinstance(n.value, ast.Constant)
            and n.value.value is True for n in ast.walk(x.value))
]
accesses = {}
for node in ast.walk(tree):
    if isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name) and node.value.id == 'plan':
        accesses.setdefault(node.attr, []).append(node.lineno)
report = {
    'source': str(source.relative_to(root)),
    'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'model_field_count': len(fields),
    'model_fields': fields,
    'field_exclude_true_count': len(excluded),
    'field_exclude_true': excluded,
    'syntactic_plan_dot_access': {k: sorted(set(v)) for k,v in sorted(accesses.items())},
    'scope_limit': 'Only direct AST plan.<attribute>; aliases, getattr, dynamic data and transitive consumers require separate owner tracing.',
}
out = Path(__file__).resolve().parent / 'census.json'
out.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'field_count':len(fields), 'excluded':len(excluded), 'direct_attributes':len(accesses)}))
