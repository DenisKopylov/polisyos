from pathlib import Path
import ast
R=Path.cwd();O=R/'LOCAL/raw/e02-execution-20261027/repairs/C25-r2';P=O/'policy-engine';f=P/'tests/unit/ddm/test_full_acceptance.py';s=f.read_text();s=s.replace('from datetime import UTC, datetime','from datetime import UTC, datetime\nfrom typing import TYPE_CHECKING\n\nif TYPE_CHECKING:\n    from pathlib import Path');s=s.replace('from polisyos.ddm.calibration import CalibrationReport, build_calibration_audit','from polisyos.ddm.calibration import CalibrationReport, build_calibration_audit\nfrom polisyos.ddm.calibration.audit import _canonical_report_digest\nfrom polisyos.ddm.calibration.observations import (\n    CalibrationObservationWindow,\n    FiniteCalibrationObservationSource,\n)\nfrom polisyos.ddm.detectors.track_2_2_shift_adapter import adapt_shift_event');s=s.replace('from polisyos.ddm.integration.model_registry import rebind_calibration_validity','from polisyos.ddm.integration.model_registry import (\n    _evaluate_readiness_gate,\n    rebind_calibration_validity as _rebind_calibration_validity,\n)');s=s.replace('DriftAndDegradationMonitor()','_FixtureMonitor()')
insert='''
# This fixture owns and enumerates its finite replay files. These are explicitly
# non-production sources; the public registry gate must preserve that limit.
_SOURCE_FILES: dict[str, Path] = {}
_SOURCE_ROOT: Path | None = None


@pytest.fixture(autouse=True)
def _finite_replay_root(tmp_path: Path) -> None:
    global _SOURCE_ROOT
    _SOURCE_ROOT = tmp_path
    _SOURCE_FILES.clear()


def _finite_source(
    *, report: CalibrationReport, audit: CalibrationAudit,
    budget: MetricBudgetPolicy, shifts: list[object], degradation: object,
    triggers: list[str], now: datetime, source_id: str | None = None,
) -> FiniteCalibrationObservationSource:
    assert _SOURCE_ROOT is not None
    source_id = source_id or f"finite-window-{len(_SOURCE_FILES)}"
    path = _SOURCE_ROOT / f"{source_id}.json"
    window = CalibrationObservationWindow.model_validate({
        "schema_version": "polisyos.ddm.finite_observation_window.v1",
        "source_id": source_id, "profile": "finite_replay",
        "model_id": report.model_id or "legacy-unknown",
        "model_version": report.model_version or "legacy-unknown",
        "calibration_id": audit.calibration_id,
        "detector_id": report.detector_id,
        "stationarity_regime_id": report.stationarity_regime_id,
        "report_digest": _canonical_report_digest(report),
        "observed_from": now, "observed_through": now,
        "invalidation_events": [
            {"event_id": f"trigger-{i}", "timestamp": now, "trigger": trigger}
            for i, trigger in enumerate(triggers)
        ],
        "shift_events": shifts, "degradation_event": degradation,
        "metric_budget": budget,
    })
    path.write_text(window.model_dump_json())
    _SOURCE_FILES[source_id] = path
    return FiniteCalibrationObservationSource(path=path, source_id=source_id)


class _FixtureMonitor(DriftAndDegradationMonitor):
    def evaluate_window(self, **kwargs: object) -> object:
        report = kwargs.get("_calibration_report")
        audit = kwargs.get("calibration_audit")
        budget = kwargs.get("metric_budget")
        triggers = kwargs.get("_observed_invalidation_triggers")
        if (isinstance(report, CalibrationReport) and isinstance(audit, CalibrationAudit)
                and isinstance(budget, MetricBudgetPolicy) and isinstance(triggers, list)
                and report.model_id is not None and report.model_version is not None):
            self._observation_source = _finite_source(
                report=report, audit=audit, budget=budget,
                shifts=[adapt_shift_event(event) for event in kwargs.get("shift_events", [])],
                degradation=kwargs.get("degradation_event"), triggers=triggers,
                now=kwargs["timestamp"],
            )
        return super().evaluate_window(**kwargs)


def rebind_calibration_validity(
    record: ModelRegistryReadinessRecord, **kwargs: object
) -> ModelRegistryReadinessRecord:
    binding = record.applicability_binding
    source = None
    triggers = kwargs.get("observed_invalidation_triggers")
    if binding is not None and binding.observation_binding is not None and triggers is not None:
        source_id = binding.observation_binding.source_id
        path = _SOURCE_FILES.get(source_id)
        if path is not None:
            window = CalibrationObservationWindow.model_validate_json(path.read_text())
            source = _finite_source(
                report=kwargs["report"], audit=kwargs["calibration_audit"],
                budget=window.metric_budget, shifts=list(window.shift_events),
                degradation=window.degradation_event, triggers=triggers,
                now=kwargs["now"], source_id=source_id,
            )
    return _rebind_calibration_validity(record, **kwargs, observation_source=source)

'''
s=s.replace('\ndef _window() -> MonitoringWindow:',insert+'\ndef _window() -> MonitoringWindow:')
# Source-limited positives remain correct valid projections but are not promotion grants.
s=s.replace('assert evaluate_registry_gate(record).promotion_allowed is True','assert evaluate_registry_gate(record).reason == "finite_replay_observation_not_production_authority"')
s=s.replace('assert evaluate_registry_gate(observed_empty).promotion_allowed is True','assert evaluate_registry_gate(observed_empty).reason == "finite_replay_observation_not_production_authority"')
s=s.replace('assert evaluate_registry_gate(rebound).promotion_allowed is True','assert evaluate_registry_gate(rebound).reason == "finite_replay_observation_not_production_authority"')
# LA055 policy contrast is deliberately tested only at its conditional seam, not as proof of production observations.
s=s.replace('gate = evaluate_registry_gate(record, owner_signoff=True)\n\n    assert gate.promotion_allowed is False\n    assert gate.reason == "persisted_readiness_veto"','gate = _evaluate_readiness_gate(record, owner_signoff=True)\n\n    assert gate.promotion_allowed is False\n    assert gate.reason == "persisted_readiness_veto"')
s=s.replace('gate = evaluate_registry_gate(rebound, owner_signoff=True)\n\n    assert gate.promotion_allowed is True','gate = _evaluate_readiness_gate(rebound, owner_signoff=True)\n\n    assert gate.promotion_allowed is True')
# R1 application proof remains limited by finite source before any production grant.
s=s.replace('assert gate.reason == "R1_blocks_promotion"','assert gate.reason == "finite_replay_observation_not_production_authority"')
s=s.replace('assert evaluate_registry_gate(record).promotion_allowed is allowed','assert evaluate_registry_gate(record).promotion_allowed is False\n    if allowed:\n        assert evaluate_registry_gate(record).reason == "finite_replay_observation_not_production_authority"')
# Missing actual source on a fresh reader cannot reconstitute applicability from caller lists.
s=s.replace('assert decision.reason == "registry_applicability_not_established"','assert decision.reason == "calibration_validity_not_established"')
f.write_text(s)
# Existing stationary tests keep the declared-list calculator contrast but no longer infer observation authority from [].
f=P/'tests/unit/ddm/test_stationary_replay.py';s=f.read_text().replace('assert evaluate_registry_gate(accepted.registry_record).promotion_allowed is True','assert evaluate_registry_gate(accepted.registry_record).promotion_allowed is False\n    assert evaluate_registry_gate(accepted.registry_record).reason == "calibration_validity_not_established"');f.write_text(s)
# Focused independent source-mutation and omitted-denominator tests use actual monitor/rebind, not the convenience wrapper.
write=P/'tests/unit/ddm/test_observation_source_admission.py';write.write_text('''"""Source-owned observation/basis controls for current registry admission."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from typing import TYPE_CHECKING

import pytest

from polisyos.ddm.calibration import CalibrationReport, build_calibration_audit
from polisyos.ddm.calibration.audit import _canonical_report_digest
from polisyos.ddm.calibration.observations import (
    CalibrationObservationWindow,
    FiniteCalibrationObservationSource,
)
from polisyos.ddm.detectors.track_2_2_shift_adapter import adapt_shift_event
from polisyos.ddm.integration import (
    DriftAndDegradationMonitor, MetricDirection, ModelRegistryReadinessRecord,
    MonitoringWindow, ShiftDetectedEvent, evaluate_registry_gate,
)
from polisyos.ddm.integration.model_registry import rebind_calibration_validity
from polisyos.ddm.readiness import MetricBudgetPolicy

if TYPE_CHECKING:
    from pathlib import Path

NOW = datetime(2026, 4, 26, tzinfo=UTC)


def _report() -> CalibrationReport:
    return CalibrationReport.model_validate({
        "model_id": "model", "model_version": "v1", "detector_id": "detector",
        "stationarity_regime_id": "regime", "fp_target": {"horizon": "30d", "alpha": .05},
        "threshold": .2, "empirical_stationary_holdout": {
            "alerts": 0, "windows": 100, "empirical_fp_rate": 0.,
            "confidence_interval_95": [0., .03], "pass": True,
        },
        "detection_delay_tests": {
            "synthetic_covariate_shift": {"min_detectable_shift": .25, "median_delay_windows": 2},
            "synthetic_concept_shift": {"min_detectable_shift": .5, "median_delay_windows": 1},
        },
        "expiration": {"valid_until": "2026-05-01T00:00:00Z",
                       "invalidation_triggers": ["model_version_change"]},
    })


def _budget() -> MetricBudgetPolicy:
    return MetricBudgetPolicy(model_id="model", model_version="v1", metric="accuracy",
        metric_direction=MetricDirection.HIGHER_IS_BETTER,
        reference_value=.9, minimum_acceptable_value=.8)


def _shift() -> ShiftDetectedEvent:
    window = MonitoringWindow(start=NOW, end=NOW, n=100)
    return ShiftDetectedEvent(event_id="shift-1", timestamp=NOW, model_id="model",
        model_version="v1", detector_id="detector", detector_family="online_mmd",
        signal="input_shift", representation="features", reference_window=window,
        current_window=window, stationarity_regime_id="regime", calibration_id="calib",
        test_statistic=.1, ert=10000, empirical_fp_rate=.001, shift_severity=.1)


def _source(path: Path, *, shifts: bool = False) -> FiniteCalibrationObservationSource:
    report = _report()
    window = CalibrationObservationWindow(
        schema_version="polisyos.ddm.finite_observation_window.v1", source_id="fixture-owned-log",
        profile="finite_replay", model_id="model", model_version="v1", calibration_id="calib",
        detector_id="detector", stationarity_regime_id="regime",
        report_digest=_canonical_report_digest(report), observed_from=NOW, observed_through=NOW,
        invalidation_events=(), shift_events=(adapt_shift_event(_shift()),) if shifts else (),
        degradation_event=None, metric_budget=_budget(),
    )
    path.write_text(window.model_dump_json())
    return FiniteCalibrationObservationSource(path=path, source_id="fixture-owned-log")


def _produce(source: FiniteCalibrationObservationSource | None, *, shifts: bool = False):
    report = _report()
    audit = build_calibration_audit(calibration_id="calib", report=report)
    result = DriftAndDegradationMonitor(observation_source=source).evaluate_window(
        model_id="model", model_version="v1", metric_budget=_budget(), calibration_audit=audit,
        _calibration_report=report, _observed_invalidation_triggers=[], timestamp=NOW,
        shift_events=[_shift()] if shifts else [],
    )
    assert result.registry_record is not None
    return report, audit, result.registry_record


def test_enumerated_empty_replay_is_valid_but_cannot_grant_production(tmp_path: Path) -> None:
    _, _, record = _produce(_source(tmp_path / "observations.json"))
    assert record.calibration_validity is not None
    assert record.calibration_validity.status == "valid"
    assert record.calibration_validity.observed_invalidation_triggers == []
    assert record.applicability_binding is not None
    assert record.applicability_binding.observation_binding.completeness_provenance == "recomputed"
    decision = evaluate_registry_gate(record)
    assert not decision.promotion_allowed
    assert decision.reason == "finite_replay_observation_not_production_authority"


def test_raw_empty_list_does_not_establish_observed_emptiness() -> None:
    _, _, record = _produce(None)
    assert record.calibration_validity.observation_status == "unavailable"
    assert evaluate_registry_gate(record).reason == "calibration_validity_not_established"


def test_omitted_trigger_is_read_from_source_and_stale_evidence_is_refused(tmp_path: Path) -> None:
    path = tmp_path / "observations.json"
    source = _source(path)
    report, audit, record = _produce(source)
    payload = json.loads(path.read_text())
    payload["invalidation_events"].append({
        "event_id": "real-trigger", "timestamp": NOW.isoformat(), "trigger": "model_version_change",
    })
    path.write_text(json.dumps(payload))
    assert evaluate_registry_gate(record).reason == "calibration_observation_source_changed_or_unavailable"
    fresh = ModelRegistryReadinessRecord.model_validate_json(record.model_dump_json())
    rebound = rebind_calibration_validity(fresh, report=report, calibration_audit=audit, now=NOW,
        observed_invalidation_triggers=[], observation_source=source)
    assert rebound.calibration_validity.status == "invalidated"
    assert rebound.calibration_validity.observed_invalidation_triggers == ["model_version_change"]
    assert evaluate_registry_gate(rebound).reason == "calibration_model_version_change"


def test_resigning_empty_projection_cannot_drop_source_shift_denominator(tmp_path: Path) -> None:
    source = _source(tmp_path / "observations.json", shifts=True)
    report, audit, record = _produce(source, shifts=True)
    payload = json.loads(record.model_dump_json())
    payload["applicability_binding"]["shift_event_digests"] = []
    fresh = ModelRegistryReadinessRecord.model_validate(payload)
    rebound = rebind_calibration_validity(fresh, report=report, calibration_audit=audit, now=NOW,
        observed_invalidation_triggers=[], observation_source=source,
        metric_budget=_budget(), shift_events=[])
    assert rebound._applicability_evidence is not None
    assert "registry_applicability_projection_mismatch" in rebound._applicability_evidence.reasons
    assert "caller_shift_basis_mismatch" in rebound._applicability_evidence.reasons
    assert not evaluate_registry_gate(rebound).promotion_allowed


def test_frozen_binding_and_last_event_consistency_are_independent_controls(tmp_path: Path) -> None:
    source = _source(tmp_path / "observations.json", shifts=True)
    _, _, record = _produce(source, shifts=True)
    with pytest.raises(ValueError, match="frozen"):
        record.applicability_binding.shift_event_digests = ()
    changed = record.model_copy(update={"last_shift_event": None})
    assert evaluate_registry_gate(changed).reason == "registry_last_shift_projection_mismatch"


@pytest.mark.parametrize("field", ["source_id", "report_digest", "observed_through"])
def test_wrong_selected_source_context_cannot_issue_validity(tmp_path: Path, field: str) -> None:
    path = tmp_path / "observations.json"
    source = _source(path)
    payload = json.loads(path.read_text())
    payload[field] = {"source_id": "another-source", "report_digest": "0" * 64,
                      "observed_through": "2026-04-25T00:00:00Z"}[field]
    path.write_text(json.dumps(payload))
    _, _, record = _produce(source)
    assert record.calibration_validity.status == "not_established"
    assert not evaluate_registry_gate(record).promotion_allowed
''')
