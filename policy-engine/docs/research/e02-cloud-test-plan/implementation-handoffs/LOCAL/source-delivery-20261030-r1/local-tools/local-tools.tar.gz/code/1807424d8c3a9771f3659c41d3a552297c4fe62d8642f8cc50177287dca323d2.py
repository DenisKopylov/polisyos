"""Dependency-only controls; never import PolicyOS or run a product test."""
from __future__ import annotations

import inspect
import unittest
from pathlib import Path
from pydantic import create_model, model_validator
from pydantic_core import ValidationError
import v3_exception_witness as base
import pytest_v3_structured_exception_witness as plugin
from structured_capture import CallSite, NativeAccess, StructuredExceptionWitness, extract, schema_fingerprint, FIELDS

# Synthetic stand-in for frame identity, not evidence of a product error.
RAISED = None

class PhysicalSimulationWorkObservation:
    def __new__(cls):
        raise RAISED

def synthetic_constructor():
    return PhysicalSimulationWorkObservation()

def synthetic_target():
    try:
        synthetic_constructor()
    except ValidationError as error:
        return error
    raise AssertionError("missing exception")

def synthetic_target_reraises():
    try:
        synthetic_constructor()
    except ValidationError:
        raise

class DynamicContext:
    calls = 0
    def __str__(self):
        type(self).calls += 1
        return "CONTEXT_SENTINEL_PRIVATE"

def make_error(error_type="string_pattern_mismatch", *, count=1, context=None):
    entries = []
    for i in range(count):
        entry = {"type": error_type, "loc": ("physical_spec_ref",), "input": "INPUT_SENTINEL_PRIVATE"}
        if context is not None:
            entry["ctx"] = context
        elif error_type == "string_pattern_mismatch":
            entry["ctx"] = {"pattern": "^[a-f0-9]{64}$"}
        entries.append(entry)
    return ValidationError.from_exception_data("PhysicalSimulationWorkObservation", entries)

def raised_at_constructor(error):
    global RAISED
    RAISED = error
    try:
        synthetic_constructor()
    except BaseException as actual:
        assert actual is error
        return actual
    finally:
        RAISED = None
    raise AssertionError("synthetic exception not raised")

def bindings():
    return NativeAccess(ValidationError, inspect.getattr_static(ValidationError, "error_count"),
                        inspect.getattr_static(ValidationError, "errors"),
                        inspect.getattr_static(ValidationError, "title"))

def site(*, code=synthetic_constructor.__code__, model=PhysicalSimulationWorkObservation, line=None):
    line = line or synthetic_constructor.__code__.co_firstlineno + 1
    return CallSite(code, globals(), model, line, line)

class Controls(unittest.TestCase):
    def test_real_validation_error_has_bounded_selected_fields_and_no_private_payload(self):
        error = raised_at_constructor(make_error())
        result = extract(error, base._CaptureBudget(), bindings(), site())
        self.assertEqual(result["status"], "available")
        self.assertEqual(result["errors"][0]["type"], "string_pattern_mismatch")
        self.assertEqual(result["errors"][0]["loc"], ["physical_spec_ref"])
        self.assertEqual(result["errors"][0]["msg"], "String should match pattern '^[a-f0-9]{64}$'")
        self.assertNotIn("SENTINEL", repr(result))
        self.assertEqual(set(result["errors"][0]), {"type", "loc", "msg"})

    def test_same_name_different_exception_class_never_invokes_errors(self):
        class Pretender(Exception):
            def errors(self, **kwargs):
                raise AssertionError("must not execute")
        Pretender.__module__ = ValidationError.__module__
        Pretender.__name__ = ValidationError.__name__
        error = raised_at_constructor(Pretender("input"))
        result = extract(error, base._CaptureBudget(), bindings(), site())
        self.assertEqual(result["status"], "unavailable")
        self.assertEqual(result["reason"], "exception_class_mismatch")

    def test_other_traceback_title_and_model_never_format_context(self):
        DynamicContext.calls = 0
        error = raised_at_constructor(make_error("value_error", context={"error": DynamicContext()}))
        for wrong_site in (site(code=(lambda: None).__code__), site(line=99999), site(model=object)):
            result = extract(error, base._CaptureBudget(), bindings(), wrong_site)
            self.assertEqual(result["status"], "unavailable")
        other_title = ValidationError.from_exception_data("OtherObservation", [{"type":"int_parsing", "loc":("physical_spec_ref",), "input":"sentinel"}])
        result = extract(raised_at_constructor(other_title), base._CaptureBudget(), bindings(), site())
        self.assertEqual(result["reason"], "title_mismatch")
        self.assertEqual(DynamicContext.calls, 0)

    def test_count_cap_prevents_errors_call(self):
        error = raised_at_constructor(make_error(count=17))
        def never(*args, **kwargs):
            raise AssertionError("errors must not execute")
        access = bindings()._replace(errors=never)
        result = extract(error, base._CaptureBudget(), access, site())
        self.assertEqual(result["status"], "unavailable")
        self.assertEqual(result["reason"], "error_count_overflow")

    def test_aggregate_text_budget_does_not_silently_truncate(self):
        error = raised_at_constructor(make_error())
        budget = base._CaptureBudget()
        budget.text_bytes_used = base.MAX_TOTAL_TEXT_BYTES
        result = extract(error, budget, bindings(), site())
        self.assertEqual(result["status"], "unavailable")
        self.assertEqual(result["reason"], "capture_budget_exceeded")
        self.assertNotIn("String should", repr(result))

    def test_api_exception_or_malformed_rows_cannot_escape(self):
        error = raised_at_constructor(make_error())
        def broken(*args, **kwargs):
            raise RuntimeError("sensitive")
        for replacement in (broken, lambda *args, **kwargs: [{"type":"x", "loc":(), "msg":"x", "input":"PRIVATE"}]):
            result = extract(error, base._CaptureBudget(), bindings()._replace(errors=replacement), site())
            self.assertEqual(result["status"], "unavailable")
            self.assertNotIn("PRIVATE", repr(result))
            self.assertNotIn("sensitive", repr(result))
        self.assertIs(type(error), ValidationError)

    def test_non_whitelisted_message_never_exports_context_sentinel(self):
        DynamicContext.calls = 0
        error = raised_at_constructor(make_error("value_error", context={"error": DynamicContext()}))
        result = extract(error, base._CaptureBudget(), bindings(), site())
        self.assertEqual(DynamicContext.calls, 1)  # Native formatter invokes __str__.
        self.assertEqual(result["status"], "partial")
        self.assertNotIn("CONTEXT_SENTINEL_PRIVATE", repr(result))
        self.assertEqual(result["errors"][0]["msg"], None)
        self.assertEqual(result["message_status"], "not_whitelisted")

    def test_changed_live_schema_fails_before_formatting(self):
        DynamicContext.calls = 0
        schema = {"kind": ["original"]}
        validator = object()
        def rule(self):
            return self
        model = PhysicalSimulationWorkObservation
        model.__pydantic_core_schema__ = schema
        model.__pydantic_validator__ = validator
        model._work_observation_binding = rule
        guarded = site()._replace(schema=schema, validator=validator, rule=rule,
                                  schema_snapshot=schema_fingerprint(schema), rule_code=rule.__code__)
        schema["kind"].append("changed")
        error = raised_at_constructor(make_error("value_error", context={"error": DynamicContext()}))
        result = extract(error, base._CaptureBudget(), bindings(), guarded)
        self.assertEqual(result["reason"], "live_schema_changed")
        self.assertEqual(DynamicContext.calls, 0)

    def test_real_monitor_keeps_return_identity_and_handles_extraction_fault(self):
        global RAISED
        error = make_error()
        def broken(*args, **kwargs):
            raise RuntimeError("private context")
        for access, expected in ((bindings(), "available"),
                                 (bindings()._replace(errors=broken), "unavailable")):
            RAISED = error
            monitor = StructuredExceptionWitness(synthetic_target.__code__, Path("unused"), access, site())
            monitor.start()
            try:
                self.assertIs(synthetic_target(), error)
            finally:
                monitor._cleanup()
                RAISED = None
            self.assertEqual(monitor.cleanup_errors, [])
            self.assertEqual(monitor.callback_errors, [])
            self.assertEqual(monitor.events_omitted, 0)
            self.assertEqual(len(monitor.events), 1)
            self.assertEqual(monitor.events[0]["structured_validation"]["status"], expected)
            self.assertNotIn("private context", repr(monitor.events))

    def test_real_monitor_keeps_reraised_identity_on_extraction_fault(self):
        global RAISED
        error = make_error()
        def broken(*args, **kwargs):
            raise RuntimeError("private context")
        RAISED = error
        monitor = StructuredExceptionWitness(synthetic_target_reraises.__code__, Path("unused"),
                                             bindings()._replace(errors=broken), site())
        monitor.start()
        try:
            with self.assertRaises(ValidationError) as caught:
                synthetic_target_reraises()
            self.assertIs(caught.exception, error)
        finally:
            monitor._cleanup()
            RAISED = None
        self.assertEqual(monitor.cleanup_errors, [])
        self.assertEqual(monitor.callback_errors, [])
        self.assertEqual(monitor.active, 0)
        self.assertEqual(monitor.events[0]["structured_validation"]["reason"], "extraction_error")

    def test_real_dependency_admission_and_source_falsifier(self):
        native, provenance = plugin.native_access()
        self.assertIs(native.cls, ValidationError)
        self.assertEqual(provenance["pydantic"], "2.12.5")
        source = plugin.JOINT.read_bytes()
        line, last = plugin.model_and_call(source)
        self.assertGreater(last, line)
        before = b'physical_spec_ref: str = Field(pattern=r"^[a-f0-9]{64}$")'
        after = b'physical_spec_ref: str = Field(pattern=r"^[a-f0-9]{32}$")'
        self.assertEqual(source.count(before), 1)
        with self.assertRaises(base.WitnessError):
            plugin.model_and_call(source.replace(before, after))

    def test_synthetic_native_model_schema_admission_and_field_removal(self):
        @model_validator(mode="after")
        def rule(self):
            return self
        model = create_model("Synthetic", __validators__={"_work_observation_binding": rule},
                             **{name: (str, ...) for name in FIELDS})
        schema, validator, retained_rule, fingerprint = plugin.model_schema(model)
        self.assertIs(retained_rule, vars(model)["_work_observation_binding"])
        self.assertEqual(fingerprint, schema_fingerprint(schema))
        schema["schema"]["schema"]["fields"].pop("physical_spec_ref")
        with self.assertRaises(base.WitnessError):
            plugin.model_schema(model)

if __name__ == "__main__":
    unittest.main(verbosity=2)
