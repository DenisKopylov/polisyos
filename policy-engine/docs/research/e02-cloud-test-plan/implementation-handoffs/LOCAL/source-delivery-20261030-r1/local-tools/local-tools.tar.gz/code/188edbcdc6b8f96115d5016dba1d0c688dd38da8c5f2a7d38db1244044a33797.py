from pathlib import Path
root=Path('LOCAL/raw/e02-execution-20261027/repairs/C46-r4/postimages/policy-engine/src/polisyos/data_forge/domains/ukraine')
p=root/'builders/observation.py';s=p.read_text()
def one(s,old,new):
 assert s.count(old)==1,(s.count(old),old[:120]);return s.replace(old,new,1)
s=one(s,'''    if match := _YEAR_PATTERN.fullmatch(normalized):
        year = int(match.group("year"))''','''    if match := _YEAR_PATTERN.fullmatch(normalized):
        precision = 1
        year = int(match.group("year"))''')
s=one(s,'''    elif match := _QUARTER_PATTERN.fullmatch(normalized):
        year = int(match.group("year"))''','''    elif match := _QUARTER_PATTERN.fullmatch(normalized):
        precision = 2
        year = int(match.group("year"))''')
s=one(s,'''    elif match := _MONTH_PATTERN.fullmatch(normalized):
        year = int(match.group("year"))''','''    elif match := _MONTH_PATTERN.fullmatch(normalized):
        precision = 3
        year = int(match.group("year"))''')
s=one(s,'''    elif match := _DATE_PATTERN.fullmatch(normalized):
        year = int(match.group("year"))''','''    elif match := _DATE_PATTERN.fullmatch(normalized):
        precision = 4
        year = int(match.group("year"))''')
s=one(s,'''    elif match := _NUMERIC_MONTH_PATTERN.fullmatch(normalized):
        year = int(match.group("year"))''','''    elif match := _NUMERIC_MONTH_PATTERN.fullmatch(normalized):
        precision = 3
        year = int(match.group("year"))''')
s=one(s,'''    if not 1 <= month <= 12:
''','''    required_precision = {
        TimeFrequency.YEAR: 1,
        TimeFrequency.QUARTER: 2,
        TimeFrequency.MONTH: 3,
    }.get(time_grain)
    if required_precision is None or precision < required_precision:
        raise ValueError("period identifier is coarser than the declared frequency")

    if not 1 <= month <= 12:
''')
p.write_text(s)

p=root/'adapters.py';s=p.read_text()
s=one(s,'''from dataclasses import dataclass
''','''from dataclasses import dataclass
from datetime import date
''')
s=one(s,'''            year_series = (
                pd.to_numeric(frame[year_col], errors="coerce")
                .fillna(self._extract_year_from_name(path.name))
                .astype(int)
            )
            quarter_series = (
                pd.to_numeric(
                    frame[quarter_col] if quarter_col is not None else 4,
                    errors="coerce",
                )
                .fillna(4)
                .clip(1, 4)
                .astype(int)
            )''','''            year_series = frame[year_col]
            quarter_series = (
                frame[quarter_col]
                if quarter_col is not None
                else pd.Series(None, index=frame.index, dtype=object)
            )''')
s=one(s,'''                    "quarter_id": [
                        f"{year}Q{quarter}"
                        for year, quarter in zip(
                            year_series.tolist(), quarter_series.tolist(), strict=False
                        )
                    ],''','''                    "quarter_id": [
                        period if period is not None and re.fullmatch(r"\\d{4}Q[1-4]", period) else None
                        for period in (
                            self._quarter_to_period_id(year, quarter)
                            for year, quarter in zip(
                                year_series.tolist(), quarter_series.tolist(), strict=False
                            )
                        )
                    ],''')
s=one(s,'''            year_series = (
                pd.to_numeric(frame[year_col], errors="coerce")
                .fillna(self._extract_year_from_name(path.name))
                .astype(int)
            )''','''            year_series = frame[year_col]''')
s=one(s,'''                    "period_id": [f"{year}-12" for year in year_series.tolist()],''','''                    "period_id": [self._coerce_period_id(year) for year in year_series.tolist()],''')
start=s.index('    @staticmethod\n    def _coerce_period_id(');end=s.index('\n    @staticmethod\n    def _region_from_registration',start)
s=s[:start]+'''    @staticmethod
    def _coerce_period_id(value: object) -> str | None:
        """Normalize recognized dates while retaining absent and malformed inputs."""
        if value is None or value is pd.NA:
            return None
        if isinstance(value, float):
            if pd.isna(value):
                return None
            if value.is_integer():
                value = int(value)
        text = str(value).strip()
        if not text:
            return text
        iso = re.fullmatch(r"(\\d{4})-(\\d{2})-(\\d{2})(?:[T ].+)?", text)
        dotted = re.fullmatch(r"(\\d{2})\\.(\\d{2})\\.(\\d{4})", text)
        compact = re.fullmatch(r"(\\d{4})(\\d{2})(\\d{2})", text)
        if iso or dotted or compact:
            match = iso or dotted or compact
            assert match is not None
            if dotted:
                day, month, year = map(int, match.groups())
            else:
                year, month, day = map(int, match.groups())
            try:
                date(year, month, day)
            except ValueError:
                return text
            return f"{year:04d}-{month:02d}"
        return text
''' + s[end:]
s=one(s,'''    def _extract_year_from_name(name: str) -> int:
        match = re.search(r"(20\\d{2})", name)
        if match is not None:
            return int(match.group(1))
        return 2021''','''    def _extract_year_from_name(name: str) -> int | None:
        match = re.search(r"(20\\d{2})", name)
        return int(match.group(1)) if match is not None else None''')
s=one(s,'''    def _extract_period_id_from_name(self, name: str) -> str:''','''    def _extract_period_id_from_name(self, name: str) -> str | None:''')
s=one(s,'''        year = self._extract_year_from_name(name)
        return f"{year}-12"''','''        year = self._extract_year_from_name(name)
        return str(year) if year is not None else None''')
s=one(s,'''    def _quarter_to_period_id(year: int, quarter: int) -> str:
        month_lookup = {1: "03", 2: "06", 3: "09", 4: "12"}
        return f"{int(year):04d}-{month_lookup.get(int(quarter), '12')}"''','''    def _quarter_to_period_id(year: object, quarter: object) -> str | None:
        year_text = TabularSourceAdapter._coerce_period_id(year)
        quarter_text = TabularSourceAdapter._coerce_period_id(quarter)
        if year_text is None or not year_text:
            return year_text
        if quarter_text is None or not quarter_text:
            return year_text
        return f"{year_text}Q{quarter_text}"''')
s=one(s,'''        if source.period_column not in result.columns:
            result[source.period_column] = "2025-01"''','''        if source.period_column not in result.columns:
            result[source.period_column] = pd.NA''')
s=one(s,'''        aggregated: dict[tuple[str, str, str], float] = {}''','''        aggregated: dict[tuple[str, str, str | None], float] = {}''')
s=one(s,'''        period_counts: dict[str, int] = {}''','''        period_counts: dict[str | None, int] = {}''')
s=one(s,'''                for period_id, count in sorted(period_counts.items())''','''                for period_id, count in sorted(
                    period_counts.items(), key=lambda item: (item[0] is not None, item[0] or "")
                )''')
p.write_text(s)
