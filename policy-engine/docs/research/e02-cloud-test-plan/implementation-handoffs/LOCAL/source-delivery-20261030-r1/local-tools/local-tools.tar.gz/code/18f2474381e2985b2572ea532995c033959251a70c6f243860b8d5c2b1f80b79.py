from pathlib import Path
p=Path('LOCAL/raw/e02-execution-20261027/repairs/TC-closure-owner-r4/proposal/policy-engine/src/polisyos/runtime/quality/owned_execution_identity.py')
s=p.read_text()
a='''        def validate_parent(
            role: str,
            manifest: ArtifactManifest,
            children: list[tuple[InputRef, ArtifactRef, ArtifactManifest]],
        ) -> None:
            if role.endswith("_registry_bundle") or "_registry_member." in role:
                return
            actual = manifest.inputs
'''
b='''        def validate_parent(
            role: str,
            manifest: ArtifactManifest,
            children: list[tuple[InputRef, ArtifactRef, ArtifactManifest]],
        ) -> None:
            if role.endswith("_registry_bundle") or "_registry_member." in role:
                return
            source_kinds = {
                "exec_plan": "foundry.exec_plan",
                "program_graph": "foundry.program_graph",
                "trinity_bundle": "ir.trinity_bundle",
                "candidate": "scientist.policy_design.candidate",
                "candidate_data_snapshot": "fabric.data_snapshot",
                "actual_data_snapshot": "fabric.data_snapshot",
                "input_bindings": "foundry.input_bindings",
                "bound_state_snapshot": "foundry.state_snapshot",
                "base_state_snapshot": "foundry.state_snapshot",
                "registered_sql_admission": "fabric.registered_sql_admission_binding",
            }
            if manifest.kind != source_kinds.get(role):
                _fail("debug_source_role_kind_mismatch")
            snapshot_kinds = {
                "data_view_request_ref": "ir.data_view_request",
                "data_ref": "fabric.tabular_payload",
                "data_schema_ref": "fabric.data_schema",
                "quality_report_ref": "fabric.quality_report",
                "warnings_ref": "fabric.warnings",
            }
            parent_kinds = {
                "exec_plan": {"program_graph": "foundry.program_graph"},
                "program_graph": {
                    "ir": "ir.trinity_bundle",
                    "registry_bundle": "core.registry_bundle",
                    "link_report": "compiler.link_report",
                    "lowered_ir": "foundry.lowered_ir",
                    "execution_plan_source": "scientist.execution_plan",
                },
                "trinity_bundle": {"policy_candidate": "scientist.policy_design.candidate"},
                "candidate": {
                    "world_model_data_snapshot": "fabric.data_snapshot",
                    "world_model_registry": "core.registry_bundle",
                },
                "candidate_data_snapshot": snapshot_kinds,
                "actual_data_snapshot": snapshot_kinds,
                "input_bindings": {
                    "input.data_snapshot_ref": "fabric.data_snapshot",
                    "input.registry_bundle_ref": "core.registry_bundle",
                    "artifact.bound_state_snapshot_ref": "foundry.state_snapshot",
                    "input.registered_sql_admission_ref": "fabric.registered_sql_admission_binding",
                    "input.quality_report_ref": "fabric.quality_report",
                },
                "bound_state_snapshot": {
                    "input.data_snapshot_ref": "fabric.data_snapshot",
                    "input.registry_bundle_ref": "core.registry_bundle",
                    "state_blob": "foundry.state_blob",
                },
                "base_state_snapshot": {
                    "input.data_snapshot_ref": "fabric.data_snapshot",
                    "input.registry_bundle_ref": "core.registry_bundle",
                    "state_blob": "foundry.state_blob",
                },
                "registered_sql_admission": {
                    "source.snapshot": "fabric.data_snapshot",
                    "source.view": "fabric.registered_sql_view",
                    "source.use": "fabric.registered_sql_use",
                    "source.capture": "fabric.registered_sql_capture",
                    **{f"snapshot.{key}": value for key, value in snapshot_kinds.items()},
                },
            }
            expected_kinds = parent_kinds.get(role, {})
            for edge, child_ref, _ in children[1:]:
                edge_role = edge.role.removeprefix(f"basis.edge.{role}.")
                if child_ref.kind != expected_kinds.get(edge_role):
                    _fail("debug_source_edge_role_kind_mismatch")
            actual = manifest.inputs
'''
assert s.count(a)==1;s=s.replace(a,b,1);p.write_text(s)
print('role-kind binding authored')
