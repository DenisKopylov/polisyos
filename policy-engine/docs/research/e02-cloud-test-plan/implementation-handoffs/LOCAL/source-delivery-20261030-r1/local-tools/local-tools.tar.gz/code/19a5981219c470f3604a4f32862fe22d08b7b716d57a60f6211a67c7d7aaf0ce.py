"""Opt-in observational pytest plugin for the R144 acquisition boundary.

Only the selected COV node is observed. This plugin does not import product
modules, replace a function, change a value, suppress an exception, or alter a
pytest assertion. It observes the current thread and threads started while its
trace hook is installed; pre-existing threads are not covered.
"""
from __future__ import annotations

import hashlib
import inspect
import json
import os
from pathlib import Path
import sys
import threading
from types import FrameType
from typing import Any, Callable

import pytest

NODE = (
    "tests/integration/core_runtime/test_acquisition_cov_seed_served.py::"
    "test_served_cov_seed_reaches_persisted_refusal_without_cost_or_authority"
)
ENV_PATH = "POLISYOS_R144_BASIS_OBSERVATION"
GUARD = "if basis.unbound_input_fields:"
HELPER_NAMES = (
    "_n7_bound_source_gap",
    "_n7_cycle_source_gap",
    "_n7_compiler_families_for_source_gap",
    "_n7_route_compiler_gaps",
)


def _identity(gap: Any) -> dict[str, Any] | None:
    if gap is None:
        return None
    metadata = getattr(gap, "metadata", {})
    if not isinstance(metadata, dict):
        metadata = {}
    return {
        "requirement_gap_id": getattr(gap, "requirement_gap_id", None),
        "compiled_requirement_ref": getattr(gap, "compiled_requirement_ref", None),
        "scenario_requirement_refs": list(getattr(gap, "scenario_requirement_refs", ())),
        "source": metadata.get("source"),
        "issue_codes": metadata.get("issue_codes"),
    }


def _thread() -> dict[str, Any]:
    thread = threading.current_thread()
    return {"name": thread.name, "ident": thread.ident, "native_id": thread.native_id}


def _code_identity(fn: Callable[..., Any]) -> dict[str, Any]:
    code = fn.__code__
    source = Path(code.co_filename).resolve(strict=True)
    return {
        "module": fn.__module__,
        "qualname": code.co_qualname,
        "filename": str(source),
        "first_line": code.co_firstlineno,
        "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "bytecode_sha256": hashlib.sha256(code.co_code).hexdigest(),
    }


class BoundaryObserver:
    """Trace exactly the named real function objects on newly traced threads."""

    def __init__(self, stream: Any, target: Callable[..., Any], helpers: dict[str, Callable[..., Any]]):
        self.stream = stream
        self.target_code = target.__code__
        self.helpers = {fn.__code__: name for name, fn in helpers.items()}
        lines, first = inspect.getsourcelines(target)
        guards = [first + i for i, line in enumerate(lines) if line.strip() == GUARD]
        if len(guards) != 1:
            raise ValueError("pre-constructor guard is absent or ambiguous")
        self.guard_line = guards[0]
        self.lock = threading.Lock()
        self.active = False
        self.records = 0
        self.previous_current = None
        self.previous_future = None
        self.identities = {
            "target": _code_identity(target),
            "helpers": {name: _code_identity(fn) for name, fn in helpers.items()},
        }

    def _write(self, value: dict[str, Any]) -> None:
        # Observation failures do not alter runtime decisions or assertions.
        try:
            with self.lock:
                self.stream.write(json.dumps(value, sort_keys=True) + "\n")
                self.stream.flush()
                self.records += 1
        except Exception:
            pass

    def start(self) -> bool:
        self.previous_current = sys.gettrace()
        self.previous_future = threading.gettrace()
        existing = [{"name": t.name, "ident": t.ident, "native_id": t.native_id} for t in threading.enumerate()]
        if self.previous_current is not None or self.previous_future is not None:
            self._write({"event": "observer_unavailable", "reason": "preexisting_trace", "threads_at_start": existing})
            return False
        self._write({
            "event": "observer_started",
            "pid": os.getpid(),
            "current_thread": _thread(),
            "threads_at_start": existing,
            "coverage": "current thread and future threading.Thread threads only",
            "guard_line": self.guard_line,
            "identities": self.identities,
        })
        self.active = True
        threading.settrace(self._global_trace)
        sys.settrace(self._global_trace)
        return True

    def stop(self) -> None:
        if self.active:
            self.active = False
            sys.settrace(self.previous_current)
            threading.settrace(self.previous_future)
            self._write({"event": "observer_stopped", "pid": os.getpid(), "thread": _thread(), "threads_at_stop": [{"name": t.name, "ident": t.ident, "native_id": t.native_id} for t in threading.enumerate()]})

    def _global_trace(self, frame: FrameType, event: str, arg: Any) -> Any:
        if not self.active or event != "call":
            return None
        if frame.f_code is self.target_code:
            return self._target_trace
        if frame.f_code in self.helpers:
            return self._helper_trace
        return None

    def _target_trace(self, frame: FrameType, event: str, arg: Any) -> Any:
        if not self.active:
            return None
        if event != "line" or frame.f_lineno != self.guard_line:
            return self._target_trace
        try:
            local = frame.f_locals
            basis = local["basis"]
            binding = local["basis_binding"]
            resolution = binding.resolution
            source_gap = basis.routed_source_gap
            report = basis.compilation_report
            request = local["normalized_request"]
            self._write({
                "event": "actual_report_boundary",
                "pid": os.getpid(),
                "thread": _thread(),
                "target_code_object_matches": frame.f_code is self.target_code,
                "observed_line": frame.f_lineno,
                "run_id": local["run_id"],
                "scenario_id": report.scenario_id,
                "routing_limitation_code": basis.routing_limitation_code,
                "unbound_input_fields": list(basis.unbound_input_fields),
                "basis": {
                    "state": resolution.state,
                    "grade": resolution.basis_grade,
                    "source": resolution.source,
                    "reason_codes": list(resolution.reason_codes),
                    "source_refs": list(resolution.source_refs),
                    "compiler_report_artifact_id": str(binding.compiler_report_ref.artifact_id),
                    "compiler_report_digest": binding.compiler_report_digest,
                },
                "request_driver": request.get("driver"),
                "source_gap": _identity(source_gap),
                "compiled_requirement_ids": [getattr(spec, "requirement_id", None) for spec in report.specs],
                "compiled_gap_identities": [_identity(gap) for gap in basis.routed_compiler_gaps],
                "planning_gap_ids": [getattr(gap, "gap_id", None) for gap in local["gaps"]],
            })
        except Exception as exc:
            self._write({"event": "observer_error", "site": "actual_report_boundary", "type": type(exc).__name__, "message": str(exc), "thread": _thread()})
        return None

    def _helper_trace(self, frame: FrameType, event: str, arg: Any) -> Any:
        if not self.active:
            return None
        if event != "return":
            return self._helper_trace
        try:
            name = self.helpers[frame.f_code]
            payload: dict[str, Any] = {
                "event": "actual_helper_return", "helper": name, "pid": os.getpid(),
                "thread": _thread(), "code_object_matches": True,
            }
            if isinstance(arg, tuple) and len(arg) == 2:
                value, limitation = arg
                payload["limitation"] = limitation
                if name == "_n7_compiler_families_for_source_gap":
                    payload["families"] = list(value)
                elif name == "_n7_route_compiler_gaps":
                    payload["gaps"] = [_identity(gap) for gap in value]
                else:
                    payload["gap"] = _identity(value)
            else:
                payload["return_shape"] = type(arg).__name__
            self._write(payload)
        except Exception as exc:
            self._write({"event": "observer_error", "site": "helper_return", "type": type(exc).__name__, "message": str(exc), "thread": _thread()})
        return None


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_protocol(item: Any, nextitem: Any):
    if item.nodeid != NODE:
        yield
        return
    output = os.environ.get(ENV_PATH)
    module = sys.modules.get("polisyos.runtime.quality.generation_cycle")
    if not output or module is None:
        # No observer receipt means no observation; do not change the test.
        yield
        return
    stream = None
    observer = None
    try:
        path = Path(output)
        physical_parent = path.parent.resolve(strict=True)
        absolute_parent = Path(os.path.abspath(path.parent))
        if (
            path.exists()
            or path.is_symlink()
            or not physical_parent.is_dir()
            or physical_parent != absolute_parent
        ):
            raise ValueError("observation path must be new with an existing physical parent")
        stream = path.open("x", encoding="utf-8")
        target = module.GenerationCycleController._plan_n7_requirement_gap_if_requested
        helpers = {name: getattr(module, name) for name in HELPER_NAMES}
        observer = BoundaryObserver(stream, target, helpers)
        observer.start()
    except Exception as exc:
        if stream is not None:
            try:
                stream.write(json.dumps({"event": "observer_unavailable", "type": type(exc).__name__, "message": str(exc)}) + "\n")
                stream.flush()
            except Exception:
                pass
    try:
        yield
    finally:
        if observer is not None:
            observer.stop()
        if stream is not None:
            stream.close()
