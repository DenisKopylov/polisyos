"""Exercise source-extracted resolver with retained but behaviorally bypassed checks."""
from __future__ import annotations
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

root=Path.cwd().resolve()
raw=root/'LOCAL/raw/e02-execution-20261027/repairs/N7-protocol-identity-r1'
post=raw/'post/policy-engine/src/polisyos/runtime/quality/confidence_ledger.py'
probe=raw/'adversarial_probe.py'
cases={
    "provider": (
        '    """Reconcile the live stdlib Protocol machinery to an independent source execution."""\n',
        "FAIL ADMITTED changed-provider-method",
    ),
    "callable_alias": (
        '    """Prove a held callable alias target using the existing loader-owned slot."""\n',
        "FAIL ADMITTED forged-alias-and-owner",
    ),
}
results={}
for name,(needle,expected) in cases.items():
    source=post.read_text()
    assert source.count(needle)==1
    mutant=raw/(name+"-removal.py")
    mutant.write_text(source.replace(needle,needle+"    return True\n",1))
    script=probe.read_text()
    old="source=ROOT/'LOCAL/raw/e02-execution-20261027/repairs/N7-protocol-identity-r1/post/policy-engine/src/polisyos/runtime/quality/confidence_ledger.py'"
    new=f"source=ROOT/'LOCAL/raw/e02-execution-20261027/repairs/N7-protocol-identity-r1/{name}-removal.py'"
    assert script.count(old)==1
    mutant_probe=raw/(name+"-removal-probe.py")
    mutant_probe.write_text(script.replace(old,new))
    env=dict(os.environ);env["PYTHONDONTWRITEBYTECODE"]="1"
    run=subprocess.run([sys.executable,"-B",str(mutant_probe)],cwd=root,env=env,capture_output=True,timeout=60)
    (raw/(name+"-removal.stdout")).write_bytes(run.stdout)
    (raw/(name+"-removal.stderr")).write_bytes(run.stderr)
    found=expected.encode() in run.stdout
    results[name]={"expected":expected,"exit":run.returncode,"expected_admission_observed":found,
        "mutant_sha256":hashlib.sha256(mutant.read_bytes()).hexdigest(),
        "probe_sha256":hashlib.sha256(mutant_probe.read_bytes()).hexdigest(),
        "stdout_sha256":hashlib.sha256(run.stdout).hexdigest(),"stderr_sha256":hashlib.sha256(run.stderr).hexdigest()}
    print(name,"exit",run.returncode,"expected_admission_observed",found)
(raw/'property-removals-result.json').write_text(json.dumps(results,indent=2,sort_keys=True)+"\n")
raise SystemExit(0 if all(x["exit"]==1 and x["expected_admission_observed"] for x in results.values()) else 1)
