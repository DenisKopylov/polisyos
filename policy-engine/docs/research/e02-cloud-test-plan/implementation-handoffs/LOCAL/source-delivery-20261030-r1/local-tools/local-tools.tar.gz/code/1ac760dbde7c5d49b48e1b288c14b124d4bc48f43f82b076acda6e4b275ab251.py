

class _CallerLabeledAdapter:
    """Real empirical implementation behind a caller-controlled adapter label."""

    def __init__(self, label: str, max_features: int = 2) -> None:
        self.method_id = label
        self.effective_method_id = label
        self.max_features = max_features
        self.explain_calls = 0

    def _kernel(self) -> KernelSHAPAdapter:
        return KernelSHAPAdapter(max_exact_features=self.max_features)

    def explain(
        self,
        model: ScalarModel,
        x: Mapping[str, float],
        context: ExplanationContext,
    ) -> RawExplanation:
        self.explain_calls += 1
        # This adapter could falsely describe marginal computation as conditional.
        actual = replace(context, feature_dependence_policy="marginal_interventional")
        raw = self._kernel().explain(model, x, actual)
        return replace(
            raw,
            assumptions={
                **raw.assumptions,
                "feature_dependence_policy": context.feature_dependence_policy,
            },
            effective_method_id=self.effective_method_id,
        )

    def reconstruct_delta(
        self,
        explanation: RawExplanation,
        perturbation: Mapping[str, float],
    ) -> float:
        return self._kernel().reconstruct_delta(explanation, perturbation)

    def estimator_uncertainty(self, explanation: RawExplanation) -> UncertaintyReport:
        return self._kernel().estimator_uncertainty(explanation)

    def assumptions(self, context: ExplanationContext) -> AssumptionReport:
        return self._kernel().assumptions(context)


def test_caller_adapter_labels_cannot_create_independent_agreement() -> None:
    first = _CallerLabeledAdapter("different-label-a")
    second = _CallerLabeledAdapter("different-label-b")
    bundle = ExplanationOrchestrator(adapters={"a": first, "b": second}).explain(
        _CountingModel(),
        _request(methods=("a", "b"), feature_dependence_policy="marginal_interventional"),
    )

    # This is the defining-property assertion: two plausible successful runs
    # with different labels must not manufacture an independent comparison.
    assert bundle.disagreement is None
    assert first.explain_calls == second.explain_calls == 1
    assert [method.requested_method_id for method in bundle.methods] == ["a", "b"]
    assert all(method.effective_method_id is None for method in bundle.methods)
    assert all(method.params["execution_identity_status"] == "not_established" for method in bundle.methods)
    assert bundle.faithfulness_claim == "unbounded"
    assert bundle.display_policy == "diagnostic_only"
    assert "method_execution_identity_not_established" in str(bundle.analyst_warning)
    from polisyos.berl.contracts.display_policy import (
        can_show_bare_bar_chart,
        explanation_limitation_message,
    )

    assert not can_show_bare_bar_chart(bundle)
    assert explanation_limitation_message(bundle) is not None


def test_unknown_identity_cannot_reach_bare_bar_surface() -> None:
    from polisyos.berl.contracts.display_policy import can_show_bare_bar_chart

    custom = _CallerLabeledAdapter("unverified")
    bundle = ExplanationOrchestrator(adapters={"custom": custom}).explain(
        _CountingModel(),
        _request(methods=("custom",), feature_dependence_policy="marginal_interventional"),
    )
    assert bundle.methods[0].scope == "local"
    assert bundle.methods[0].infidelity is not None
    assert not can_show_bare_bar_chart(bundle)


def test_custom_identity_unverified_does_not_pollute_known_builtin_comparison() -> None:
    custom = _CallerLabeledAdapter("kernel_shap", max_features=3)
    adapters = default_adapters()
    adapters["unverified"] = custom
    bundle = ExplanationOrchestrator(adapters=adapters).explain(
        _CountingModel(),
        _request(
            methods=("kernel_shap", "gradient", "unverified"),
            feature_dependence_policy="marginal_interventional",
        ),
    )
    assert bundle.disagreement is not None
    assert bundle.disagreement.methods_compared == ["kernel_shap", "finite_difference_gradient"]
    assert custom.explain_calls == 1
    assert bundle.methods[-1].effective_method_id is None
    assert bundle.methods[-1].params["comparison_identity_status"] == "not_established"
    assert bundle.display_policy == "diagnostic_only"


def test_unverified_conditional_law_stops_plausible_custom_alias_before_execution() -> None:
    adapter = _CallerLabeledAdapter("kernel_shap")
    model = _CountingModel()
    bundle = ExplanationOrchestrator(adapters={"conditional_alias": adapter}).explain(
        model,
        _request(methods=("conditional_alias",), feature_dependence_policy="conditional_observational"),
    )
    method = bundle.methods[0]
    assert method.scope == "diagnostic"
    assert method.attributions == []
    assert adapter.explain_calls == 0
    assert method.effective_method_id is None
    assert "no verified conditional law" in str(method.params["diagnostic"])
    assert bundle.display_policy == "diagnostic_only"
    # The score query is not an attribution or conditional-law execution.
    assert model.calls == [{"x1": 1.0, "x2": 2.0}]


def test_changed_background_forces_real_recomputation_within_one_request(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    background = ({"x1": 0.0, "x2": 0.0}, {"x1": 0.0, "x2": 0.0})
    original = KernelSHAPAdapter.explain
    calls: list[str] = []

    def change_background_after_first(adapter, model, x, context):
        raw = original(adapter, model, x, context)
        calls.append(adapter.method_id)
        if len(calls) == 1:
            for row in background:
                row["x1"] = 1.0
        return raw

    monkeypatch.setattr(KernelSHAPAdapter, "explain", change_background_after_first)
    request = _request(
        methods=("kernel_shap", "kernel_shap_marginal"),
        background_rows=background,
        feature_dependence_policy="marginal_interventional",
    )
    bundle = ExplanationOrchestrator().explain(_CountingModel(), request)
    values = [
        {item.feature: item.value for item in method.attributions}
        for method in bundle.methods
    ]
    assert values[0]["x1"] == pytest.approx(2.0)
    assert values[1]["x1"] == pytest.approx(0.0)
    assert calls == ["kernel_shap", "kernel_shap_marginal"]
    assert bundle.disagreement is None


def _produced_comparison(cas_root: Path):
    request = _request(
        methods=("kernel_shap", "kernel_shap_marginal", "gradient"),
        feature_dependence_policy="marginal_interventional",
    )
    return explain_and_persist(_CountingModel(), request, FileSystemCAS(cas_root))


def _real_runtime_evaluation(cas_root: Path, selected_ref: object):
    from polisyos.runtime.quality.explanation_reliability import evaluate_warrant_berl_reliability

    row = {
        "reliability_id": "berl-real",
        "claim_id": "claim-real",
        "warrant_id": "warrant-real",
        "explanation_bundle_ref": selected_ref,
        "validation_thresholds": {"max_p95_infidelity_upper_bound": 100.0},
    }
    warrant = {
        "warrant_id": "warrant-real",
        "claim_id": "claim-real",
        "berl_reliability_refs": ["berl-real"],
    }
    return evaluate_warrant_berl_reliability(
        {"warrant_reliability_records": [row]},
        warrant,
        claim_id="claim-real",
        artifact_store=FileSystemCAS(cas_root),
    )


def test_real_producer_selected_view_reaches_runtime_warrant_consumer(tmp_path: Path) -> None:
    cas_root = tmp_path / "runtime-selected-cas"
    reference = _produced_comparison(cas_root)
    evaluation = _real_runtime_evaluation(cas_root, reference.model_dump_json())
    assert "policy_design_warrant_berl_bundle_unresolved" not in {issue.code for issue in evaluation.issues}
    record = evaluation.records[0]
    assert record["candidate_diagnostics"]["source"] == "selected_cas_bundle"
    assert record["threshold_decision"]["status"] == "fail"  # claim/run subject is not established
    methods = record["explanation_bundle"]["methods"]
    assert [method["requested_method_id"] for method in methods] == [
        "kernel_shap", "kernel_shap_marginal", "gradient"
    ]
    assert [method["effective_method_id"] for method in methods] == [
        "kernel_shap", "kernel_shap", "finite_difference_gradient"
    ]
    loaded = load_explanation_bundle(FileSystemCAS(cas_root), reference)
    assert loaded.disagreement is not None
    assert loaded.disagreement.methods_compared == ["kernel_shap", "finite_difference_gradient"]
    assert reference.manifest_profile_sha256 is not None

    for modified, expected in (
        ({"kind": "scientist.other"}, "policy_design_warrant_berl_bundle_ref_invalid"),
        ({"media_type": "text/plain"}, "policy_design_warrant_berl_bundle_ref_invalid"),
        ({"manifest_profile_sha256": "sha256:" + "0" * 64}, "policy_design_warrant_berl_bundle_unresolved"),
    ):
        selected = {**reference.model_dump(mode="json"), **modified}
        bad = _real_runtime_evaluation(cas_root, json.dumps(selected))
        assert expected in {issue.code for issue in bad.issues}
        assert bad.records[0]["threshold_decision"]["status"] == "fail"


def test_real_producer_selected_view_reaches_scientist_preflight(tmp_path: Path) -> None:
    from types import SimpleNamespace
    from typing import cast

    from polisyos.scientist.orchestration.engine.context import ExecutionContext
    from polisyos.scientist.orchestration.engine.state import ExperimentState
    from polisyos.scientist.validation.phase5_preflight import collect_phase5_evidence

    cas_root = tmp_path / "scientist-selected-cas"
    reference = _produced_comparison(cas_root)
    ctx = cast("ExecutionContext", SimpleNamespace(store=FileSystemCAS(cas_root)))
    state = ExperimentState(run_id="berl-real-consumer", params={})
    evidence = collect_phase5_evidence(
        ctx, state, artifact_ref=reference, artifact_kind="scientist.explanation_bundle"
    )
    assert not evidence.failed_refs
    assert str(reference.artifact_id) in evidence.loaded_refs
    selected = evidence.payload["_phase5_evidence"][0]
    assert selected["selected_artifact_ref"]["manifest_profile_sha256"] == reference.manifest_profile_sha256
    assert [method["effective_method_id"] for method in selected["payload"]["methods"]] == [
        "kernel_shap", "kernel_shap", "finite_difference_gradient"
    ]
    assert selected["payload"]["disagreement"]["methods_compared"] == [
        "kernel_shap", "finite_difference_gradient"
    ]
    wrong = reference.model_copy(update={"manifest_profile_sha256": "sha256:" + "0" * 64})
    refused = collect_phase5_evidence(
        ctx, state, artifact_ref=wrong, artifact_kind="scientist.explanation_bundle"
    )
    assert refused.failed_refs
    assert not refused.loaded_refs


def test_default_conditional_request_refuses_all_unverified_method_routes() -> None:
    request = ExplanationRequest(
        prediction_id="default-conditional",
        row_id="row-default",
        x={"x1": 1.0, "x2": 2.0},
        feature_names=("x1", "x2"),
        background_rows=({"x1": 0.0, "x2": 0.0},),
        n_eval_perturbations=1,
    )
    bundle = ExplanationOrchestrator().explain(_CountingModel(), request)
    assert request.feature_dependence_policy == "conditional_observational"
    assert [method.requested_method_id for method in bundle.methods] == list(request.methods)
    assert all(method.scope == "diagnostic" and not method.attributions for method in bundle.methods)
    assert all("verified conditional law" in str(method.params["diagnostic"]) for method in bundle.methods)
    assert bundle.display_policy == "diagnostic_only"


def test_marker_removal_cannot_admit_unverified_identity_at_fresh_consumers(tmp_path: Path) -> None:
    from types import SimpleNamespace
    from typing import cast

    from polisyos.berl import persist_explanation_bundle, validate_explanation_bundle
    from polisyos.berl.contracts.display_policy import can_show_bare_bar_chart
    from polisyos.berl.contracts.validation_rules import validate_persisted_explanation_bundle_payload
    from polisyos.scientist.orchestration.engine.context import ExecutionContext
    from polisyos.scientist.orchestration.engine.state import ExperimentState
    from polisyos.scientist.validation.phase5_preflight import build_phase5_validation_report

    custom = _CallerLabeledAdapter("caller-claims-kernel")
    request = replace(
        _request(methods=("custom",), feature_dependence_policy="marginal_interventional"),
        n_eval_perturbations=5,
        residual_cap=0.001,
    )
    produced = ExplanationOrchestrator(adapters={"custom": custom}).explain(_CountingModel(), request)
    assert custom.explain_calls == 1
    method = produced.methods[0]
    # An arbitrary public persister caller can erase non-receipts and invent labels.
    forged_params = {
        key: value for key, value in method.params.items()
        if key not in {"execution_identity_status", "comparison_identity_status"}
    }
    forged_params["effective_method_id"] = "kernel_shap"
    forged_method = method.model_copy(
        update={"effective_method_id": "kernel_shap", "params": forged_params}
    )
    forged = produced.model_copy(
        update={
            "methods": [forged_method],
            "faithfulness_claim": "bounded",
            "display_policy": "analyst_display",
            "analyst_warning": None,
        }
    )
    # The arithmetic-only candidate evaluator can be green with markers intact or removed;
    # it does not verify who executed the claimed implementation.
    assert validate_explanation_bundle(forged).passed
    cas_root = tmp_path / "forged-method-cas"
    reference = persist_explanation_bundle(FileSystemCAS(cas_root), forged)
    fresh = load_explanation_bundle(FileSystemCAS(cas_root), reference)
    assert fresh.methods[0].effective_method_id == "kernel_shap"
    _, admission = validate_persisted_explanation_bundle_payload(fresh.model_dump(mode="json"))
    assert not admission.passed
    assert "execution_identity_provenance_not_established" in admission.violations
    assert not can_show_bare_bar_chart(fresh)

    runtime = _real_runtime_evaluation(cas_root, reference.model_dump_json())
    candidate = runtime.records[0]["candidate_diagnostics"]["threshold_decision"]
    assert candidate["status"] == "fail"
    assert "execution_identity_provenance_not_established" in candidate["violations"]
    ctx = cast("ExecutionContext", SimpleNamespace(store=FileSystemCAS(cas_root)))
    report = build_phase5_validation_report(
        ctx,
        ExperimentState(run_id="forged-berl", params={}),
        artifact_ref=reference,
        artifact_kind="scientist.explanation_bundle",
    )
    explanation = next(component for component in report.phase5_components if component.name == "explanation")
    assert explanation.status == "blocked"
    assert any("execution_identity_provenance_not_established" in reason for reason in explanation.blockers)
