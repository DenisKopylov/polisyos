"""Check this RAW source proposal only; never import or execute product code."""
from pathlib import Path
import ast
import collections
import hashlib
import json

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
PACKET = Path(__file__).absolute().parent
reads = []


def read(path):
    try:
        value = path.read_bytes()
    except OSError as error:
        reads.append({"path": str(path), "status": "failed", "error_type": type(error).__name__})
        raise
    reads.append({"path": str(path), "status": "success", "bytes": len(value),
                  "sha256": hashlib.sha256(value).hexdigest()})
    return value


def function(tree, name):
    return next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)


def edge_calls(fn, env):
    output = []

    def items(value):
        if isinstance(value, ast.List):
            rows = []
            for node in value.elts:
                rows.extend(items(node.value) if isinstance(node, ast.Starred)
                            else [ast.dump(node, include_attributes=False)])
            return rows
        if isinstance(value, ast.IfExp):
            return items(value.body if env[value.test.id] else value.orelse)
        raise AssertionError("unsupported fixture edge expression")

    def visit(nodes):
        for node in nodes:
            if isinstance(node, ast.Assign) and any(
                isinstance(t, ast.Name) and t.id == "edges" for t in node.targets
            ):
                output.extend(items(node.value))
            elif (isinstance(node, ast.Expr) and isinstance(node.value, ast.Call)
                  and isinstance(node.value.func, ast.Attribute)
                  and isinstance(node.value.func.value, ast.Name)
                  and node.value.func.value.id == "edges"
                  and node.value.func.attr == "extend"):
                output.extend(items(node.value.args[0]))
            elif isinstance(node, ast.If) and isinstance(node.test, ast.Name) and node.test.id in env:
                visit(node.body if env[node.test.id] else node.orelse)

    visit(fn.body)
    return output


report = {"schema": "e02.n7-cg2-source-checks.v2", "status": "ERROR", "runtime": "UNRUN",
          "method": "AST parsing and restricted branch walk only; no fixture or product execution",
          "unresolved_by_construction": ["live imports", "solver/DB behavior", "test outcomes",
                                         "external legal proof", "normal N7 route and authority"]}
try:
    pins = json.loads(read(PACKET / "postimage-pins.json"))
    trees = {}
    for pin in pins:
        old = read(ROOT / pin["path"])
        new = read(PACKET / "postimages" / pin["path"])
        assert hashlib.sha256(old).hexdigest() == pin["pre_sha256"]
        assert hashlib.sha256(new).hexdigest() == pin["post_sha256"]
        trees[pin["path"]] = (ast.parse(old), ast.parse(new))
    key = "policy-engine/tests/unit/runtime/quality/test_grounding_bind.py"
    old, new = trees[key]
    compatibility = []
    for duplicate in (False, True):
        env = {"include_duplicate_tax_alias": duplicate, "include_legal_associations": True}
        before = edge_calls(function(old, "_reference"), env)
        after = edge_calls(function(new, "_reference"), env)
        assert before == after
        explicit = edge_calls(function(new, "_reference"), dict(env, include_legal_associations=False))
        assert explicit == [v for v in before if "id='_lex_edge'" not in v]
        compatibility.append({"duplicate": duplicate, "ordered_default_calls_identical": True,
                              "default_edge_calls": len(before), "structural_edge_calls": len(explicit)})
    assertions = []
    for key, name in (
        (key, "test_contract_testing_bind_resolves_non_promotable"),
        ("policy-engine/tests/unit/runtime/quality/test_generation_source.py",
         "test_synthetic_cg2_contract_mechanism_remains_non_promotable"),
    ):
        old, new = (function(t, name) for t in trees[key])
        count = lambda f: collections.Counter(ast.dump(n, include_attributes=False)
            for n in ast.walk(f) if isinstance(n, ast.Assert))
        assert not (count(old) - count(new))
        loops = lambda f: [ast.dump(n, include_attributes=False)
            for n in ast.walk(f) if isinstance(n, ast.For)]
        assert loops(old) == loops(new)
        assertions.append({"path": key, "function": name, "original_assertions": sum(count(old).values()),
                           "all_assertions_and_mutation_loops_retained": True})
    report.update(status="STATIC_CHECKS_ONLY", compatibility=compatibility, assertions=assertions)
except Exception as error:
    report["error_type"] = type(error).__name__
finally:
    report["actual_reads"] = reads
    report["selection"] = "exact two test preimages/postimages named by postimage-pins.json"
    report["exclusions"] = ["all other repository files", "product/runtime/native/DB execution"]
    print(json.dumps(report, indent=2))
if report["status"] == "ERROR":
    raise SystemExit(1)
