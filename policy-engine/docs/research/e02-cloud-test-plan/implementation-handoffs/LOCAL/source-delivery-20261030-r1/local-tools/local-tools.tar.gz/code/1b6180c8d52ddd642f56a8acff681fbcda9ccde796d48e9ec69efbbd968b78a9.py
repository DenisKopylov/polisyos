"""Supervise one stdlib-only collector fixture run with physical RSS and wall bounds."""
import json
from pathlib import Path
import subprocess
import time

packet = Path(__file__).resolve().parent
product = packet.parents[4] / 'policy-engine'
command = [str(product / '.venv/bin/python'), '-B', str(packet / 'probe-r2.py')]
start = time.monotonic()
peak = 0
abort = None
with (packet / 'probe-r2.stdout.json').open('x') as out, (packet / 'probe-r2.stderr.txt').open('x') as err:
    process = subprocess.Popen(command, cwd=product, stdout=out, stderr=err)
    while process.poll() is None:
        elapsed = time.monotonic() - start
        sample = subprocess.run(['/bin/ps', '-o', 'rss=', '-p', str(process.pid)], capture_output=True, text=True, check=False)
        rss = int(sample.stdout.strip() or '0') * 1024
        peak = max(peak, rss)
        if elapsed > 120 or rss > 512 * 1024 * 1024:
            abort = 'wall' if elapsed > 120 else 'rss'
            process.kill()
        time.sleep(0.025)
    exit_code = process.wait()
receipt = {'command': command, 'cwd': str(product), 'exit_code': exit_code, 'elapsed_seconds': time.monotonic() - start, 'peak_sampled_child_rss_bytes': peak, 'limits': {'wall_seconds': 120, 'rss_bytes': 512 * 1024 * 1024}, 'abort': abort, 'scope': 'single collector process; brief git identity children are not sampled'}
(packet / 'command-result.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
raise SystemExit(exit_code if exit_code >= 0 else 1)
