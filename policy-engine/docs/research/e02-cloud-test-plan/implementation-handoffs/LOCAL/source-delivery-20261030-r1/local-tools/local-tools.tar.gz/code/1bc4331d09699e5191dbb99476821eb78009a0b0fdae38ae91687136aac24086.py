from pathlib import Path
s=Path('LOCAL/raw/e02-execution-20261027/repairs/C48-r5/postimages')

def edit(rel, old, new):
 p=s/rel; text=p.read_text(); count=text.count(old)
 if count != 1: raise ValueError(f'{rel}: {count} anchors for {old[:75]}')
 p.write_text(text.replace(old,new))

service='policy-engine/src/polisyos/runtime/http/services/control/run_lifecycle.py'
edit(service,'''    def resolve_completed_method_metric_selection(
''','''    def read_current_completed_ex_ante_comparison(
        self,
        *,
        run_id: str,
        tenant_id: str,
        cell_id: str,
    ) -> CompletedExAnteCandidateRanking | None:
        """Replay a completed planner's bounded candidate comparison under live scope."""
        from types import SimpleNamespace

        from polisyos.core.artifacts import read_core_json_artifact_bounded
        from polisyos.core.artifacts.canonical_profile import validate_core_model_bounded_read
        from polisyos.core.contracts.runtime import (
            CompletedExAnteCandidateRanking,
            CompletedExAnteComparisonRequest,
        )
        from polisyos.scientist.methods.search.pareto_registry import ParetoRegistry
        from polisyos.scientist.nodes.builtins.decide.policy_runtime_method_metrics import (
            _MethodMetricProjectionArtifactStore,
        )
        from polisyos.scientist.orchestration.engine.state import ExperimentState

        def limited(reason: str) -> CompletedExAnteCandidateRanking:
            return CompletedExAnteCandidateRanking(status="verification_missing", limitations=(reason,))

        try:
            record = self._control_store.get_unique_completed_job_by_run_and_kind(
                run_id=run_id, kind="workflow_run"
            )
            if record is None:
                return None
            created = self._control_store.get_job_created_event_payload(record.job_id)
            scope = created.get("execution_scope")
            if (
                created.get("job_id") != record.job_id
                or created.get("run_id") != run_id
                or created.get("job_kind") != "workflow_run"
                or not isinstance(scope, Mapping)
                or scope.get("tenant_id") != tenant_id
                or scope.get("cell_id") != cell_id
            ):
                return limited("completed_planner_scope_not_established")
            state_ref = self._terminal_experiment_state_ref_for_control_job(
                job_id=record.job_id, run_id=run_id, tenant_id=tenant_id, cell_id=cell_id
            )
            if state_ref is None:
                return limited("completed_planner_state_not_established")
            store = _require_bounded_store_protocol(
                self._artifact_store,
                _MethodMetricProjectionArtifactStore,
                limits=self._observational_read_limits(),
                refusal_code="canon_profile_bounded_stream_unavailable",
                failure_stage="completed_ex_ante_comparison_reader_preflight",
            )
            read = read_core_json_artifact_bounded(
                store, state_ref, limits=self._observational_read_limits()
            )
            schema = read.manifest.artifact_schema
            if (
                read.manifest.kind != "scientist.experiment_state"
                or read.manifest.media_type != "application/json"
                or schema is None
                or schema.name != "polisyos.scientist.orchestration.engine.ExperimentState"
            ):
                return limited("completed_planner_state_contract_invalid")
            state = validate_core_model_bounded_read(ExperimentState, read)
            if state.run_id != run_id or state.schema_version != schema.version:
                return limited("completed_planner_state_binding_invalid")
            if "policy_search_completed_ex_ante_comparison" not in state.params:
                return None
            try:
                request = CompletedExAnteComparisonRequest.model_validate(
                    state.params["policy_search_completed_ex_ante_comparison"]
                )
            except (TypeError, ValueError):
                return CompletedExAnteCandidateRanking(
                    status="invalid", limitations=("completed_planner_comparison_request_invalid",)
                )
            # This context is constructed by the actual Runtime service only
            # after the planner job and scoped terminal receipt have been read.
            # The service itself is the existing Runtime selection owner.
            context = SimpleNamespace(
                store=store,
                method_metric_selection_owner=self,
                run=SimpleNamespace(tenant_id=tenant_id, cell_id=cell_id),
            )
            result = ParetoRegistry.rank_completed_ex_ante_candidates(
                ctx=context, sources=request.sources
            )
            current = self._control_store.get_unique_completed_job_by_run_and_kind(
                run_id=run_id, kind="workflow_run"
            )
            if (
                current is None
                or current.job_id != record.job_id
                or current.attempt != record.attempt
                or self._terminal_experiment_state_ref_for_control_job(
                    job_id=current.job_id, run_id=run_id, tenant_id=tenant_id, cell_id=cell_id
                ) != state_ref
            ):
                return limited("completed_planner_changed_during_comparison")
            return result
        except (AttributeError, OSError, RuntimeError, TypeError, ValueError):
            return limited("completed_planner_comparison_read_unavailable")

    def resolve_completed_method_metric_selection(
''')
edit(service,'''        MethodExecutionProducerDiagnostic,
        MethodExecutionSelection,
        MethodMetricCandidateScore,
''','''        CompletedExAnteCandidateRanking,
        MethodExecutionProducerDiagnostic,
        MethodExecutionSelection,
        MethodMetricCandidateScore,
''')

routes='policy-engine/src/polisyos/runtime/http/routes/runs.py'
text=(s/routes).read_text()
needle='    MethodMetricCandidateScore,\n'
assert text.count(needle)==1
text=text.replace(needle,'    CompletedExAnteCandidateRanking,\n'+needle)
(s/routes).write_text(text)
edit(routes,'''        record_data_access_audit(
            request,
            resource_id=run_id,
            resource_kind="runtime.run.method_metrics",
''','''        candidate_comparison = None
        read_comparison = getattr(
            control_service, "read_current_completed_ex_ante_comparison", None
        )
        if callable(read_comparison):
            candidate_comparison = read_comparison(
                run_id=run_id, tenant_id=run.details.tenant_id, cell_id=run.details.cell_id
            )
            if candidate_comparison is not None and not isinstance(
                candidate_comparison, CompletedExAnteCandidateRanking
            ):
                raise service_unavailable(
                    "The current candidate comparison is unavailable",
                    code="method_metric_candidate_comparison_invalid",
                )
        record_data_access_audit(
            request,
            resource_id=run_id,
            resource_kind="runtime.run.method_metrics",
''')
edit(routes,'''            candidate_score=candidate_score,
        )
''','''            candidate_score=candidate_score,
            candidate_comparison=candidate_comparison,
        )
''')
