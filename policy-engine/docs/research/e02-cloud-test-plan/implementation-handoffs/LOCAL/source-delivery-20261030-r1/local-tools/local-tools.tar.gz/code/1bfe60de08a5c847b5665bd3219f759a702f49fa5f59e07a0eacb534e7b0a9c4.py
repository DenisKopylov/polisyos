from pathlib import Path
import importlib.util,sys,json
root=Path.cwd();scratch=root/'LOCAL/raw/e02-execution-20261027/repairs/C04';sys.path.insert(0,str(root/'policy-engine/src'))
name='polisyos.fabric.connectors.contracts._c04_source_contract_schema'
path=scratch/'policy-engine/src/polisyos/fabric/connectors/contracts/source_contract.py'
spec=importlib.util.spec_from_file_location(name,path)
module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)
payload=module.SourceProgressContract.model_json_schema()
payload={'$schema':'https://json-schema.org/draft/2020-12/schema','$id':'https://polisyos.local/schemas/fabric/source_progress.schema.json',**payload}
out=scratch/'policy-engine/schemas/fabric/source_progress.schema.json';out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(payload,indent=2,sort_keys=True)+'\n')
print('SourceProgressContract schema generated from the exact sparse owner; no product tests or source admission executed.')
