"""Retain source-extracted diagnostic controls; this is not a product runtime run."""
from __future__ import annotations
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

root = Path.cwd().resolve()
raw = root / "LOCAL/raw/e02-execution-20261027/repairs/N7-protocol-identity-r1"
scripts = ("source_route_probe.py", "adversarial_probe.py", "core_protocol_census_probe.py", "warmed_provider_boundary_probe.py")
out = {}
for script in scripts:
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    start = time.monotonic()
    process = subprocess.run([sys.executable, "-B", str(raw / script)], cwd=root, env=env, capture_output=True, timeout=60)
    stdout_path = raw / (script + ".stdout")
    stderr_path = raw / (script + ".stderr")
    stdout_path.write_bytes(process.stdout)
    stderr_path.write_bytes(process.stderr)
    out[script] = {
        "exit": process.returncode,
        "elapsed_seconds": round(time.monotonic() - start, 3),
        "script_sha256": hashlib.sha256((raw / script).read_bytes()).hexdigest(),
        "stdout_sha256": hashlib.sha256(process.stdout).hexdigest(),
        "stderr_sha256": hashlib.sha256(process.stderr).hexdigest(),
    }
    print(script, "exit", process.returncode, "seconds", out[script]["elapsed_seconds"])
(raw / "source-probes-result.json").write_text(json.dumps(out, indent=2, sort_keys=True) + "\n")
raise SystemExit(0 if all(row["exit"] == 0 for row in out.values()) else 1)
