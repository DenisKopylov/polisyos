"""Single bounded source-tool POST, semantic removals, and the existing 94 controls."""
from pathlib import Path
import gc, hashlib, importlib.util, inspect, io, json, os, re, resource, signal, sys, time, traceback
from contextlib import redirect_stdout, redirect_stderr

P = Path(__file__).resolve().parent
R = P.parents[4]
PRODUCT = R / 'policy-engine'
R11 = R / 'LOCAL/raw/e02-execution-20261027/repairs/dynamic-native-compatibility-r11'
R12 = R / 'LOCAL/raw/e02-execution-20261027/repairs/dynamic-native-compatibility-r12'
C = P / 'candidate/policy-engine'
signal.alarm(110)
blocked = []
class NoProduct:
    def find_spec(self, fullname, path=None, target=None):
        if fullname == 'polisyos' or fullname.startswith('polisyos.'):
            blocked.append(fullname)
            raise RuntimeError('hard product import guard: ' + fullname)
sys.meta_path.insert(0, NoProduct())
assert not any(n == 'polisyos' or n.startswith('polisyos.') for n in sys.modules)

busy = False
reads = {}
read_errors = []
def audit(event, args):
    global busy
    if event == 'import' and args and isinstance(args[0], str) and (args[0] == 'polisyos' or args[0].startswith('polisyos.')):
        blocked.append(args[0])
        raise RuntimeError('hard product import audit guard: ' + args[0])
    if busy or event != 'open' or not isinstance(args[0], (str, bytes, os.PathLike)):
        return
    path = Path(os.fsdecode(args[0])); mode = args[1]; flags = args[2]
    if isinstance(mode, str) and not ('r' in mode or '+' in mode): return
    if isinstance(flags, int) and flags & os.O_ACCMODE == os.O_WRONLY: return
    busy = True
    try:
        if path.is_file():
            data = path.read_bytes(); resolved = path.resolve(); digest = hashlib.sha256(data).hexdigest()
            reads[(str(resolved), digest)] = {'path': str(path.absolute()), 'resolved_path': str(resolved), 'sha256': digest, 'bytes': len(data)}
    except OSError as error:
        read_errors.append({'path': str(path), 'error': type(error).__name__, 'errno': error.errno})
    finally:
        busy = False
sys.addaudithook(audit)
sys.path.insert(0, str(PRODUCT))
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    m = importlib.util.module_from_spec(spec); sys.modules[name] = m; spec.loader.exec_module(m); return m

def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def run_case(name, function):
    started = time.monotonic(); out = io.StringIO(); err = io.StringIO()
    row = {'case': name}
    try:
        with redirect_stdout(out), redirect_stderr(err): function()
    except BaseException as error:
        row.update(status='FAIL', error_type=type(error).__name__, error=str(error), traceback=traceback.format_exc())
    else: row['status'] = 'PASS'
    row.update(elapsed_seconds=round(time.monotonic()-started, 6), stdout=out.getvalue(), stderr=err.getvalue())
    gc.collect(); return row

try:
    owner_path = C / 'tools/quality/validation/decomposition_preflight.py'
    new_tests_path = PRODUCT / 'tests/repo_quality/architecture/test_dynamic_code_reconstitution.py'
    old_tests_path = R11 / 'candidate/policy-engine/tests/repo_quality/architecture/test_dynamic_code_reconstitution.py'
    legacy_path = C / 'tests/repo_quality/architecture/test_decomposition_preflight_gates.py'
    old_legacy_path = PRODUCT / 'tests/repo_quality/architecture/test_decomposition_preflight_gates.py'
    owner_hash = digest(owner_path)
    T = load('r14_legacy_controls', legacy_path)
    Torig = load('r14_original_legacy', old_legacy_path)
    Nold = load('r12_r11_controls', old_tests_path)
    N = load('r12_new_witnesses', new_tests_path)
    owner = load('r14_candidate_owner', owner_path)
    original_owner = load('r14_canonical_preimage_owner', PRODUCT/'tools/quality/validation/decomposition_preflight.py')
    owner.REPO_ROOT = PRODUCT; owner.SRC_ROOT = PRODUCT / 'src'
    T.preflight = owner; Torig.preflight = original_owner; Nold.preflight = owner; N.preflight = owner
    for name in ['REPO_ROOT','validate_dynamic_imports','validate_import_cycles','validate_import_time_regression','validate_reexport_shim_shapes']:
        setattr(T, name, getattr(owner, name)); setattr(Torig, name, getattr(original_owner, name))
    pre = json.loads((R12 / 'pre-witness-r1.stdout.json').read_text())
    pair = {'protected-bool-and': 'truth-and', 'known-code-unknown-star': 'known-code-unknown-star'}
    for oldname, newname in pair.items():
        old = next(row for row in pre['rows'] if row['case'] == oldname)
        assert old['outcome'] == 'INVENTORY' and old['entries'] == []
        assert old['source'] == N._R12_CASES[newname][0]
    fixtures = P / 'post-fixtures-r14'
    fixtures.mkdir(exist_ok=False)
    witnesses = []
    for index, (name, (source, refusal)) in enumerate(N._R12_CASES.items()):
        expected = refusal
        def check(source=source, expected=expected, index=index):
            try: entries = N.collect_case(fixtures / 'witness' / str(index), source)
            except owner.DynamicImportCollectionError as error:
                assert expected is not None and re.search(expected, str(error)), (expected, str(error))
                observed = {'outcome': 'REFUSAL', 'error': str(error)}
            else:
                assert expected is None and entries == [], (expected, entries)
                observed = {'outcome': 'INVENTORY', 'entries': entries}
            print(json.dumps(observed, separators=(',', ':')))
        row = run_case('witness:' + name, check)
        row.update(source_sha256=hashlib.sha256(source.encode()).hexdigest(), expected='REFUSAL:'+refusal if refusal else 'INVENTORY:[]', paired_pre=next((old for old,new in pair.items() if new==name), None))
        witnesses.append(row)
    for index, (name, expression, expect_refusal) in enumerate([
        ('selected-helper-unknown', 'value and None', True),
        ('selected-helper-pure', 'None', False),
    ]):
        helper = 'def check(value):\n    return ' + expression + '\n'
        bridge = ('from types import FunctionType\nfrom polisyos.helper import check\n'
                  'def body(value):\n    return check(value)\nCODE = body.__code__\n'
                  'run = FunctionType(CODE, globals())\ndef later(value):\n    return run(value)\n')
        def check_cross(index=index, helper=helper, bridge=bridge, expect_refusal=expect_refusal):
            root = fixtures / 'helper' / str(index)
            for scope in ('src','tools','apps','packages'): (root / scope).mkdir(parents=True, exist_ok=True)
            package = root / 'src/polisyos'; package.mkdir(); (package/'__init__.py').write_text(''); (package/'bridge.py').write_text(bridge); (package/'helper.py').write_text(helper)
            with N.pytest.MonkeyPatch.context() as patch:
                patch.setattr(owner, 'REPO_ROOT', root); patch.setattr(owner, 'SRC_ROOT', root/'src')
                try: entries = owner.collect_dynamic_imports()
                except owner.DynamicImportCollectionError as error:
                    assert expect_refusal and 'opaque implicit dispatch' in str(error), str(error)
                    print(json.dumps({'outcome':'REFUSAL','error':str(error)}, separators=(',',':')))
                else:
                    assert not expect_refusal and entries == [], entries
                    print(json.dumps({'outcome':'INVENTORY','entries':entries}, separators=(',',':')))
        row=run_case('witness:'+name, check_cross); row.update(bridge_sha256=hashlib.sha256(bridge.encode()).hexdigest(), helper_sha256=hashlib.sha256(helper.encode()).hexdigest()); witnesses.append(row)
    removals = []
    for index, name in enumerate(['test_protected_implicit_intake_removal_is_semantic','test_shape_erasure_member_transfer_removal_is_semantic']):
        def check_removal(name=name,index=index):
            with N.pytest.MonkeyPatch.context() as patch: getattr(N,name)(fixtures/'removal'/str(index), patch)
        removals.append(run_case('removal:'+name, check_removal))
    CASES = [
     ('test_dynamic_import_scanner_does_not_treat_plain_root_words_as_capabilities',{}),
     ('test_dynamic_import_operator_results_keep_unknown_callable_origin_ambiguous',{}),
     ('test_dynamic_import_collector_allows_ambiguous_nonimporter_return',{}),
     ('test_dynamic_import_collector_ignores_sys_path_setup',{}),
     ('test_dynamic_import_collector_allows_unrelated_importlib_utility_call',{}),
     ('test_dynamic_import_collector_ignores_unknown_registry_nonimporter_method',{}),
     ('test_dynamic_import_importer_in_deferred_object_refuses_opaque_call_argument',{}),
     ('test_dynamic_import_guarded_origin_nested_deferred_no_sink_stays_nonfailing',{}),
     ('test_dynamic_import_collector_tracks_unmodeled_source_mapping_transfers',{'transfer':'setdefault','payload_kind':'unrelated-scalar','mutator_module':'a_mutator'}),
     ('test_dynamic_import_exact_local_mapping_slot_write_preserves_nested_source_map',{'mutation':'store-new-slot','mutator_module':'a_mutator'}),
     ('test_dynamic_import_lazy_export_map_tracks_selected_sibling_effects',{'source_effect':'opaque-module-attribute','owner_map_resolved_first':True}),
     ('test_dynamic_import_lazy_export_map_tracks_selected_sibling_effects',{'source_effect':'opaque-module-attribute','owner_map_resolved_first':False}),
    ]
    assert len(CASES) == 12 and len(Nold.CASES) == 78
    controls = []
    for i, (name, kwargs) in enumerate(CASES):
        fn=getattr(T,name); args=dict(kwargs); params=inspect.signature(fn).parameters
        if 'tmp_path' in params: args['tmp_path']=fixtures/'controls'/'legacy'/str(i); args['tmp_path'].mkdir(parents=True,exist_ok=True)
        def check_legacy(fn=fn,args=args,params=params):
            with T.pytest.MonkeyPatch.context() as patch:
                if 'monkeypatch' in params: args['monkeypatch']=patch
                fn(**args)
        row=run_case('legacy:'+name, check_legacy); row['parameters']=kwargs; controls.append(row)
    for i, name in enumerate(Nold.CASES):
        controls.append(run_case('r11:'+name, lambda i=i,name=name: Nold.test_dynamic_code_reconstitution(name, fixtures/'controls'/'r11'/str(i))))
    for i, name in enumerate(['test_dynamic_code_invocation_removal_is_semantic','test_dynamic_code_join_provenance_removal_is_semantic','test_dynamic_code_normalization_removal_is_semantic','test_dynamic_deferred_payload_removal_is_semantic']):
        def check_old_removal(name=name,i=i):
            with Nold.pytest.MonkeyPatch.context() as patch: getattr(Nold,name)(fixtures/'controls'/'removal'/str(i),patch)
        controls.append(run_case('r11-removal:'+name, check_old_removal))
    # Run the review-batched source witnesses through the candidate test's real collector seam.
    extra = [
        ('resolved-bool-unknown', lambda root: N.test_protected_resolved_builtin_truth_protocol('value','opaque implicit dispatch',root)),
        ('resolved-bool-literal', lambda root: N.test_protected_resolved_builtin_truth_protocol('True',None,root)),
        ('module-attribute-original', lambda root: N.test_protected_module_receiver_refuses_without_identity_proof('importlib',root)),
        ('module-attribute-alias', lambda root: N.test_protected_module_receiver_refuses_without_identity_proof('loader',root)),
        ('module-unknown-receiver', lambda root: N.test_protected_unknown_receiver_refuses(root)),
        ('module-changed-slot', lambda root: N.test_protected_rebound_module_slot_does_not_emit_old_import(root)),
        ('module-shadowed-parameter', lambda root: N.test_protected_module_receiver_uses_actual_invocation_binding('shadowed-parameter',root)),
        ('module-rebound-global', lambda root: N.test_protected_module_receiver_uses_actual_invocation_binding('rebound-global',root)),
        ('direct-importer-positive', lambda root: N.test_protected_direct_importer_binding_transfers_effect(root)),
    ]
    for i,(name,fn) in enumerate(extra):
        witnesses.append(run_case('r13:'+name, lambda i=i,fn=fn: fn(fixtures/'r13'/str(i))))
    module_source = ("import importlib\nfrom types import FunctionType\ndef body():\n"
                     "    return importlib.import_module('bridge_module')\nCODE = body.__code__\n"
                     "run = FunctionType(CODE, globals())\nrun()\n")
    def module_counterexample():
        try: entries=N.collect_case(fixtures/'module-counterexample',module_source)
        except owner.DynamicImportCollectionError as error:
            assert 'opaque implicit dispatch' in str(error),str(error)
            print(json.dumps({'outcome':'REFUSAL','error':str(error)},separators=(',',':')))
        else: raise AssertionError(('expected module-attribute refusal',entries))
    row=run_case('r13:module-attribute-actual-counterexample',module_counterexample)
    row['source_sha256']=hashlib.sha256(module_source.encode()).hexdigest();witnesses.append(row)

    def release_fragment_checks():
        # The full gate imports polisyos during module initialization. Compile
        # only its unchanged fragment-validation definitions with the canonical
        # renderer as a bounded isolated replay; do not claim a full gate run.
        import ast, dataclasses, tomllib, types
        from typing import Any
        renderer_path=PRODUCT/'tools/ops_runners/release/build_release_notes.py'
        gate_path=PRODUCT/'tools/ops_runners/release/check_compatibility_release_gates.py'
        renderer=load('r13_release_renderer',renderer_path)
        gate_source=gate_path.read_text(); tree=ast.parse(gate_source,filename=str(gate_path))
        wanted=['Finding','_field_values','_required_fragment_field_is_missing','_validate_optional_boolean_fields','_optional_boolean_field_names','_validate_fragments','_read_toml','_resolve','_relative','_path_or_glob_exists','_as_string_list']
        definitions={n.name:n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in wanted}
        assert set(definitions)==set(wanted)
        future=next(n for n in tree.body if isinstance(n,ast.ImportFrom) and n.module=='__future__')
        extracted=ast.fix_missing_locations(ast.Module(body=[future,*[definitions[n] for n in wanted]],type_ignores=[]))
        module=types.ModuleType('r13_extracted_fragment_gate'); module.__file__=str(gate_path);sys.modules[module.__name__]=module
        module.__dict__.update({'dataclass':dataclasses.dataclass,'Path':Path,'Any':Any,'tomllib':tomllib,'PUBLIC_SURFACE_REVIEW_FIELD':'public_surface_inventory_reviewed','SECTION_TITLES':renderer.SECTION_TITLES,'structured_compatibility_changes':renderer.structured_compatibility_changes})
        exec(compile(extracted,str(gate_path),'exec'),module.__dict__)
        policy_path=PRODUCT/'architecture/gates/compatibility_release.toml'
        policy=tomllib.loads(policy_path.read_text()); fragments=renderer.load_fragments(C/'release-fragments/unreleased')
        assert len(fragments)==1
        fragment=fragments[0]; errors,findings=module._validate_fragments(PRODUCT,policy,fragments,breaking_classes=())
        assert not errors,[x.as_dict() for x in errors]
        rendered=renderer.render_release_notes('0.0.0',fragments,'2026-10-30')
        assert '## Known Limitations' in rendered and str(fragment['limitations']) in rendered
        required=tomllib.loads((PRODUCT/'ops/release/release-fragment-policy.toml').read_text())['release_fragments']['required_fields']
        removal_results=[]
        for field in required:
            changed=dict(fragment);changed.pop(field)
            changed_errors,_=module._validate_fragments(PRODUCT,policy,[changed],breaking_classes=())
            observed=[x.as_dict() for x in changed_errors]
            assert any(x['check']=='fragment-schema' and x['message']==f'missing `{field}`' for x in observed),(field,observed)
            removal_results.append({'removed':field,'errors':observed})
        omitted=dict(fragment);omitted.pop('limitations');rendered_without=renderer.render_release_notes('0.0.0',[omitted],'2026-10-30')
        assert '## Known Limitations' not in rendered_without
        old_path=R12/'candidate/policy-engine/release-fragments/unreleased/2026-10-30-dynamic-negative-payload-precision.toml'
        old=tomllib.loads(old_path.read_text());old['__path__']=str(old_path)
        old_errors,_=module._validate_fragments(PRODUCT,policy,[old],breaking_classes=())
        old_missing=sorted(e.message for e in old_errors if e.check=='fragment-schema' and e.message.startswith('missing `'))
        assert old_missing==sorted(f'missing `{field}`' for field in required if module._required_fragment_field_is_missing(field,old.get(field)))
        print(json.dumps({'scope':'Canonical fragment-validator function and dependencies compiled from pinned actual source AST under hard no-product-import guard, plus real release renderer; not the full compatibility-gate caller.','gate_source_sha256':digest(gate_path),'renderer_source_sha256':digest(renderer_path),'policy_sha256':digest(policy_path),'required_fields':required,'new_errors':[e.as_dict() for e in errors],'new_findings':[f.as_dict() for f in findings],'old_missing':old_missing,'field_removal_results':removal_results,'limitations_rendered':True,'limitations_removal_detected':True},separators=(',',':')))
    release=[run_case('release:isolated-fragment-validator-and-renderer',release_fragment_checks)]
    import ast, itertools, textwrap
    def parameter_rows(fn):
        groups=[]
        for mark in getattr(fn,'pytestmark',[]):
            if mark.name!='parametrize': continue
            names=mark.args[0]
            names=tuple(x.strip() for x in names.split(',')) if isinstance(names,str) else tuple(names)
            entries=[]
            for item in mark.args[1]:
                if hasattr(item,'marks') and hasattr(item,'values'):
                    values=tuple(item.values)
                elif len(names)==1:
                    values=(item,)
                else:
                    values=tuple(item)
                assert len(names)==len(values),(fn.__name__,names,values)
                entries.append(dict(zip(names,values,strict=True)))
            groups.append(entries)
        if not groups: return [{}]
        return [{key:value for group in product for key,value in group.items()} for product in itertools.product(*groups)]
    def run_test_function(module,fn,parameters,root):
        args=dict(parameters); params=inspect.signature(fn).parameters
        if 'tmp_path' in params: root.mkdir(parents=True,exist_ok=True);args['tmp_path']=root
        with module.pytest.MonkeyPatch.context() as patch:
            if 'monkeypatch' in params: args['monkeypatch']=patch
            fn(**args)
    unit_cases=[]
    for name in sorted(vars(N)):
        fn=getattr(N,name)
        if name.startswith('test_') and inspect.isfunction(fn) and fn.__module__==N.__name__:
            for parameters in parameter_rows(fn): unit_cases.append((name,fn,parameters))
    assert len(unit_cases)==110,('composed-unit-denominator',len(unit_cases))
    units=[]
    for i,(name,fn,parameters) in enumerate(unit_cases):
        row=run_case('unit:'+name,lambda i=i,fn=fn,parameters=parameters: run_test_function(N,fn,parameters,fixtures/'units'/str(i)))
        row['parameters']=parameters;units.append(row)
    legacy_names=[
        'test_dynamic_import_collector_tracks_comprehension_scope_and_rebinding',
        'test_dynamic_import_collector_ignores_shadow_inside_comprehension',
        'test_dynamic_import_expression_path_join_preserves_same_origin_alias_and_removal_probe',
        'test_dynamic_import_validator_refuses_guarded_value_through_unsupported_expression',
    ]
    legacy=[]
    for i,name in enumerate(legacy_names):
        legacy.append(run_case('legacy-four:'+name,lambda i=i,name=name: run_test_function(T,getattr(T,name),{},fixtures/'legacy-four'/str(i))))
    adversarial=[]
    for name in ('test_dynamic_import_exact_tuple_index_is_inventoried_and_registry_checked','test_dynamic_import_scope_and_origin_precision_controls','test_dynamic_import_scope_and_origin_negative_controls'):
        fn=getattr(T,name)
        for parameters in parameter_rows(fn):
            i=len(adversarial);row=run_case('adversary:'+name,lambda i=i,fn=fn,parameters=parameters: run_test_function(T,fn,parameters,fixtures/'adversary'/str(i)));row['parameters']=parameters;adversarial.append(row)
    def original_oracle_failure():
        fn=Torig.test_dynamic_import_validator_refuses_guarded_value_through_unsupported_expression
        try: run_test_function(Torig,fn,{},fixtures/'oracle-original')
        except AssertionError as error:
            print(json.dumps({'original_assertion':'FAIL','error_type':type(error).__name__,'error':str(error)},separators=(',',':')))
        else: raise AssertionError('original R162 assertion unexpectedly passed')
    def original_oracle_actual_semantics():
        fn=Torig.test_dynamic_import_validator_refuses_guarded_value_through_unsupported_expression
        tree=ast.parse(textwrap.dedent(inspect.getsource(fn)))
        calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='_dynamic_import_validator_refusal']
        assert len(calls)==1
        source=ast.literal_eval(calls[0].args[0]);root=fixtures/'oracle-observation';root.mkdir(parents=True)
        with Torig.pytest.MonkeyPatch.context() as patch:
            registry=Torig._dynamic_import_fixture(root,patch,source)
            entries=original_owner.collect_dynamic_imports()
            registry.write_text(Torig._render_dynamic_imports_toml([]),encoding='utf-8')
            findings=original_owner.validate_dynamic_imports()
        assert [e['pattern'] for e in entries]==['unsupported_subscript_origin'],entries
        assert any(f.message=='dynamic import call is not registered' and 'unsupported_subscript_origin' in f.detail for f in findings),[f.render() for f in findings]
        print(json.dumps({'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'entries':entries,'findings':[{'message':f.message,'detail':f.detail} for f in findings]},separators=(',',':')))
    oracle=[run_case('oracle:historical-original-assertion-fails',original_oracle_failure),run_case('oracle:historical-original-exact-index-is-inventoried',original_oracle_actual_semantics)]
    def check_removed_scope():
        original=owner._DynamicImportSourceScanner._scan_comprehension
        source=textwrap.dedent(inspect.getsource(original))
        before='local_scope_info = dict(scope_info)';after='target_scope_info = {**local_scope_info, "globals": set(), "nonlocals": set()}'
        assert source.count(before)==source.count(after)==1
        source=source.replace(before,'local_scope_info = scope_info').replace(after,'target_scope_info = scope_info')
        ns={};exec(compile('from __future__ import annotations\n'+source,'<r14-scope-removal>','exec'),owner.__dict__,ns)
        fn=T.test_dynamic_import_collector_ignores_shadow_inside_comprehension
        run_test_function(T,fn,{},fixtures/'scope-removal'/'positive')
        with T.pytest.MonkeyPatch.context() as patch:
            patch.setattr(owner._DynamicImportSourceScanner,'_scan_comprehension',ns['_scan_comprehension'])
            try: run_test_function(T,fn,{},fixtures/'scope-removal'/'removed')
            except owner.DynamicImportCollectionError as error:
                assert 'unproven module-time dynamic-import namespace (importlib)' in str(error),str(error)
            else: raise AssertionError('scope removal did not reproduce refusal')
        assert owner._DynamicImportSourceScanner._scan_comprehension is original
        run_test_function(T,fn,{},fixtures/'scope-removal'/'restored')
    def check_removed_unbound():
        original=owner._DYNAMIC_UNBOUND;fn=T.test_dynamic_import_collector_tracks_comprehension_scope_and_rebinding
        run_test_function(T,fn,{},fixtures/'unbound-removal'/'positive')
        with T.pytest.MonkeyPatch.context() as patch:
            patch.setattr(owner,'_DYNAMIC_UNBOUND',owner._DYNAMIC_UNKNOWN)
            try: run_test_function(T,fn,{},fixtures/'unbound-removal'/'removed')
            except owner.DynamicImportCollectionError as error:
                assert 'unproven module-time dynamic-import namespace (deleted_loader)' in str(error),str(error)
            else: raise AssertionError('unbound removal did not reproduce refusal')
        assert owner._DYNAMIC_UNBOUND is original
        run_test_function(T,fn,{},fixtures/'unbound-removal'/'restored')
    def check_removed_namespace_normalization():
        original=owner._DynamicImportBinding.__post_init__;fn=T.test_dynamic_import_expression_path_join_preserves_same_origin_alias_and_removal_probe
        run_test_function(T,fn,{},fixtures/'namespace-removal'/'positive')
        def removed(binding): binding._normalize_negative_execution()
        with T.pytest.MonkeyPatch.context() as patch:
            patch.setattr(owner._DynamicImportBinding,'__post_init__',removed)
            try: run_test_function(T,fn,{},fixtures/'namespace-removal'/'removed')
            except owner.DynamicImportCollectionError as error:
                assert 'dynamic importer binding is ambiguous or unresolved through a call target' in str(error),str(error)
            else: raise AssertionError('namespace normalization removal did not reproduce refusal')
        assert owner._DynamicImportBinding.__post_init__ is original
        run_test_function(T,fn,{},fixtures/'namespace-removal'/'restored')
    r14_removals=[run_case('r14-removal:comprehension-scope',check_removed_scope),run_case('r14-removal:unbound-binding',check_removed_unbound),run_case('r14-removal:namespace-normalization',check_removed_namespace_normalization)]
    products=[n for n in sys.modules if n=='polisyos' or n.startswith('polisyos.')]
    result={'scope':'One paired R14 source-tool batch: all 110 composed unit callables, four legacy callables, original-oracle observation, adversarial controls, semantic removals, existing 94 source-tool controls, and isolated release fragment-validator/renderer replay. Fixture source is parsed, never imported; no native/full execution.', 'owner_origin':str(owner_path), 'owner_sha256':owner_hash,'new_tests_sha256':digest(new_tests_path),'r11_controls_test_sha256':digest(old_tests_path),'legacy_test_sha256':digest(legacy_path),'original_legacy_test_sha256':digest(old_legacy_path),'original_owner_sha256':digest(PRODUCT/'tools/quality/validation/decomposition_preflight.py'), 'pre_stdout_sha256':digest(R12/'pre-witness-r1.stdout.json'),'witnesses':witnesses,'removals':removals,'controls':controls,'release':release,'units':units,'legacy_four':legacy,'adversarial':adversarial,'oracle':oracle,'r14_removals':r14_removals,'product_imports':products,'blocked_product_import_attempts':blocked,'ru_maxrss_platform_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
    print(json.dumps(result, separators=(',',':')))
    if products or blocked or any(row['status']!='PASS' for row in (*witnesses,*removals,*controls,*release,*units,*legacy,*adversarial,*oracle,*r14_removals)): raise SystemExit(1)
finally:
    busy=True
    receipt={'scope':'Python audit open events for regular files hashed immediately before observed consumer opens; distinct preimages retained. C-level reads, environment, network and directory enumeration are unresolved; not native or source-wide.','source_root':str(R),'python_executable':sys.executable,'reads':sorted(reads.values(),key=lambda row:(row['resolved_path'],row['sha256'])),'read_errors':read_errors,'blocked_product_import_attempts':blocked}
    (P/'post-and-controls-r14.input-reads.json').write_text(json.dumps(receipt, separators=(',',':'))+'\n')
