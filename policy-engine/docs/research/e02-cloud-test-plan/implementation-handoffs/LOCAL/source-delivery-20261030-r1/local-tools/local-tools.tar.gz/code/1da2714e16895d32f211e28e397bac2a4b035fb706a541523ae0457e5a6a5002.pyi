"""UNRATIFIED design sketch only; not executable or an installed capability.

Existing engine invocation/registry/journal owners would implement this conditional
interface after a selected G ruling. No consumer may construct its issuer/handle.
"""

from typing import Literal, Protocol

from polisyos.core.artifacts import ArtifactRef

class PrivateWorkspaceOutcome(Protocol):
    @property
    def status(self) -> Literal["completed", "rejected", "unavailable"]: ...
    @property
    def parent_invocation_basis_ref(self) -> ArtifactRef: ...
    @property
    def registered_composition_ref(self) -> ArtifactRef: ...
    @property
    def candidate_observation_ref(self) -> ArtifactRef | None: ...
    @property
    def settled_journal_receipt_ref(self) -> ArtifactRef: ...

class EngineOwnedPrivateWorkspace(Protocol):
    """Issuer validates its actual registered parent/child set, not this shape."""
    def evaluate_registered_candidate(
        self,
        *,
        registered_composition_id: str,
        candidate_ref: ArtifactRef,
    ) -> PrivateWorkspaceOutcome: ...
