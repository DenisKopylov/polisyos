from pathlib import Path
P=Path.cwd()/'LOCAL/raw/e02-execution-20261027/repairs/C25-r2/policy-engine'
f=P/'tests/unit/ddm/test_observation_source_admission.py';s=f.read_text();s+='''

def test_source_quality_signal_cannot_be_omitted_from_consumed_window(tmp_path: Path) -> None:
    path = tmp_path / "observations.json"
    source = _source(path)
    payload = json.loads(path.read_text())
    payload["data_quality_signals"].append({
        "signal_id": "actual-owner-dq", "timestamp": NOW.isoformat(),
        "model_id": "model", "model_version": "v1", "risk_score": 1., "hard_failure": True,
    })
    path.write_text(json.dumps(payload))
    _, _, record = _produce(source)
    assert evaluate_registry_gate(record).reason == "window_source_data_quality_basis_mismatch"


def test_wrong_budget_consumption_is_recomputed_despite_matching_source_labels(tmp_path: Path) -> None:
    from polisyos.ddm.integration import PerformanceDegradationEvent

    path = tmp_path / "observations.json"
    source = _source(path)
    payload = json.loads(path.read_text())
    degradation = PerformanceDegradationEvent(
        event_id="degradation", timestamp=NOW, model_id="model", model_version="v1",
        metric="accuracy", metric_direction=MetricDirection.HIGHER_IS_BETTER,
        source="estimated_performance", estimator="cbpe", reference_value=.9,
        minimum_acceptable_value=.8, current_estimate=.84,
        confidence_interval_95=(.82, .86), budget_used=0., calibration_id="calib",
    )
    payload["degradation_event"] = degradation.model_dump(mode="json")
    path.write_text(json.dumps(payload))
    report = _report()
    audit = build_calibration_audit(calibration_id="calib", report=report)
    result = DriftAndDegradationMonitor(observation_source=source).evaluate_window(
        model_id="model", model_version="v1", metric_budget=_budget(), calibration_audit=audit,
        _calibration_report=report, _observed_invalidation_triggers=[], timestamp=NOW,
        degradation_event=degradation,
    )
    assert result.registry_record is not None
    assert evaluate_registry_gate(result.registry_record).reason == "degradation_budget_consumption_mismatch"


def test_direct_builder_last_event_cannot_escape_consumed_basis(tmp_path: Path) -> None:
    from polisyos.ddm.integration.model_registry import build_model_registry_record
    from polisyos.ddm.readiness.readiness_mapper import map_readiness

    source = _source(tmp_path / "observations.json", shifts=True)
    _, audit, original = _produce(source, shifts=True)
    last = adapt_shift_event(_shift())
    record = build_model_registry_record(
        readiness_event=map_readiness(model_id="model", model_version="v1", timestamp=NOW),
        calibration_audit=audit, metric_budget=_budget(), shift_events=[], last_shift_event=last,
        _calibration_validity_evidence=original._calibration_validity_evidence,
    )
    assert "last_shift_event_not_in_consumed_basis" in record._applicability_evidence.reasons
    assert "window_source_shift_basis_mismatch" in record._applicability_evidence.reasons
    assert not evaluate_registry_gate(record).promotion_allowed


def test_registry_schema_accepts_bound_projection_and_rejects_corruption(tmp_path: Path) -> None:
    from pathlib import Path

    from jsonschema import Draft202012Validator, ValidationError

    _, _, record = _produce(_source(tmp_path / "observations.json", shifts=True), shifts=True)
    schema_path = Path(__file__).resolve().parents[3] / "src/polisyos/ddm/integration/model_registry_record.schema.json"
    validator = Draft202012Validator(json.loads(schema_path.read_text()))
    payload = json.loads(record.model_dump_json())
    validator.validate(payload)
    payload["applicability_binding"]["unowned_authority"] = True
    with pytest.raises(ValidationError):
        validator.validate(payload)
''';f.write_text(s)
