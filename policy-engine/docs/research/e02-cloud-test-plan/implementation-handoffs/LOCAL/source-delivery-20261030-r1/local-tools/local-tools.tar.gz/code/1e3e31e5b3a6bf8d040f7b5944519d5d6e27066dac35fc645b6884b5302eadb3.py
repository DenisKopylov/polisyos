from pathlib import Path
p=Path('LOCAL/raw/e02-execution-20261027/repairs/TC-closure-owner-r3/proposal/policy-engine/src/polisyos/runtime/http/services/control/run_lifecycle.py')
s=p.read_text()
def change_function(name, end_marker, edits):
 global s
 start=s.index('    def '+name+'(')
 end=s.index(end_marker,start)
 chunk=s[start:end]
 for a,b in edits:
  n=chunk.count(a)
  expected = 2 if name == 'read_current_completed_ex_ante_candidate_score' and a.startswith('                candidate_ref=candidate_ref,') else 1
  if n != expected: raise ValueError((name,n,a[:100]))
  chunk=chunk.replace(a,b,expected)
 s=s[:start]+chunk+s[end:]
change_function('get_method_execution_selection','\n    def _resolve_observational_method_core_run_binding(',[
('''        cell_id: str | None,
    ) -> MethodExecutionSelection | None:''','''        cell_id: str | None,
        aggregate_read_budget: _TerminalReadBudget | None = None,
    ) -> MethodExecutionSelection | None:'''),
('''                tenant_id=tenant_id,
                cell_id=cell_id,
            )''','''                tenant_id=tenant_id,
                cell_id=cell_id,
                aggregate_read_budget=aggregate_read_budget,
            )'''),
])
change_function('read_current_completed_ex_ante_candidate_score','\n    def read_current_completed_ex_ante_comparison(',[
('''        restricted_exante_call_collector: list[Any] | None = None,
    ) -> MethodMetricCandidateScore:''','''        restricted_exante_call_collector: list[Any] | None = None,
        aggregate_read_budget: _ProjectionReadBudget | None = None,
    ) -> MethodMetricCandidateScore:'''),
('''                run_id=run_id, tenant_id=tenant_id, cell_id=cell_id
            )''','''                run_id=run_id, tenant_id=tenant_id, cell_id=cell_id,
                aggregate_read_budget=aggregate_read_budget,
            )'''),
('''                candidate_ref=candidate_ref,
                tenant_id=tenant_id,
                cell_id=cell_id,
            )''','''                candidate_ref=candidate_ref,
                tenant_id=tenant_id,
                cell_id=cell_id,
                aggregate_read_budget=aggregate_read_budget,
            )'''),
('''                restricted_exante_call_collector=restricted_exante_call_collector,
            )''','''                restricted_exante_call_collector=restricted_exante_call_collector,
                aggregate_read_budget=aggregate_read_budget,
            )'''),

])
change_function('resolve_completed_method_metric_selection','\n    @staticmethod\n    def _completed_hte_source_invalidation_dedupe_key(',[
('''        cell_id: str | None,
    ) -> CompletedMethodMetricSource | None:''','''        cell_id: str | None,
        aggregate_read_budget: _TerminalReadBudget | None = None,
    ) -> CompletedMethodMetricSource | None:'''),
('''            tenant_id=tenant_id,
            cell_id=cell_id,
        )''','''            tenant_id=tenant_id,
            cell_id=cell_id,
            aggregate_read_budget=aggregate_read_budget,
        )''')
])
change_function('_terminal_experiment_state_ref_for_control_job','\n    def get_method_execution_producer_diagnostic(',[
('''        cell_id: str | None,
    ) -> ArtifactRef | None:''','''        cell_id: str | None,
        aggregate_read_budget: _TerminalReadBudget | None = None,
    ) -> ArtifactRef | None:'''),
('''        from polisyos.runtime.http.services.adapters.core_run import (
            load_terminal_core_run_source,
        )''','''        from polisyos.runtime.http.services.adapters.core_run import (
            _bounded_terminal_json_read,
            load_terminal_core_run_source,
        )'''),
('''                core_runs_root=self._core_runs_root,
                run_id=run_id,
            )''','''                core_runs_root=self._core_runs_root,
                run_id=run_id,
                aggregate_read_budget=aggregate_read_budget,
            )'''),
('''            bounded = read_core_json_artifact_bounded(
                self._require_core_bounded_member_reader(limits=limits),
                finalization_ref,
                limits=limits,
            )''','''            reader = self._require_core_bounded_member_reader(limits=limits)
            if aggregate_read_budget is None:
                bounded = read_core_json_artifact_bounded(reader, finalization_ref, limits=limits)
            else:
                bounded = _bounded_terminal_json_read(
                    reader, finalization_ref, aggregate_read_budget, limits=limits
                )''')
])
# Only annotations; imports are lazy for execution and avoid widening layering.
needle='''if TYPE_CHECKING:
'''
if s.count(needle)!=1: raise ValueError(('TYPE_CHECKING',s.count(needle)))
s=s.replace(needle,needle+'''    from polisyos.runtime.http.services.adapters.core_run import _TerminalReadBudget
    from polisyos.scientist.nodes.builtins.decide.policy_runtime_method_metrics import (
        _ProjectionReadBudget,
    )
''',1)
p.write_text(s)
print('lifecycle generated')
