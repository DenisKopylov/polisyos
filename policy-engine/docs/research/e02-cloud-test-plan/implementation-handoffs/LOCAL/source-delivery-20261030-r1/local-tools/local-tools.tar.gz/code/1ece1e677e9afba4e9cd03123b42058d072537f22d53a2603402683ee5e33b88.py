from pathlib import Path
import subprocess
ROOT=Path.cwd()
OUT=ROOT/'LOCAL/raw/e02-execution-20261027/repairs/C38-r3'
p='policy-engine/src/polisyos/runtime/quality/diagnostic_events.py'
target=OUT/'postimages'/p
target.parent.mkdir(parents=True,exist_ok=True)
target.write_bytes(subprocess.check_output(['git','show',f'4396ab7ed42ebcd0aad742ac1f402ffcbccd0c65:{p}']))
s=target.read_text().replace('from pydantic import BaseModel, ConfigDict, Field, field_validator\n','from pydantic import BaseModel, ConfigDict, Field, field_validator\n\nfrom polisyos.core.artifacts import ArtifactRef, CanonInfo, InputRef, ProducerInfo, SchemaInfo\n',1)
needle='class DiagnosticEventContractError(ValueError):\n'
insert='''class RuntimeQualitySelectedReadObservation(BaseModel):
    """Mechanical read facts, explicitly insufficient for input completeness.

    This record covers only the named NL helper invocation. It neither claims
    that all producer reads passed through that helper nor that requested scope
    was honoured by a data owner. Registry metadata matching is not authenticity.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    schema_version: Literal["policyos.runtime.selected_read_observation.v1"] = (
        "policyos.runtime.selected_read_observation.v1"
    )
    reader: Literal["runtime.control.nl_pipeline._load_json_artifact_payload"] = (
        "runtime.control.nl_pipeline._load_json_artifact_payload"
    )
    run_id: str = Field(min_length=1)
    job_id: str = Field(min_length=1)
    tenant_id: str = Field(min_length=1)
    cell_id: str | None
    ordinal: int = Field(ge=0)
    selected_ref: ArtifactRef
    selection_origin: Literal["explicit_selected_ref", "default_view_at_read"]
    payload_sha256: str = Field(pattern=r"^sha256:[0-9a-f]{64}$")
    canonical_profile: CanonInfo
    manifest_schema: SchemaInfo | None
    manifest_producer: ProducerInfo | None
    manifest_inputs: tuple[InputRef, ...]
    matching_registered_output_owner: str | None
    read_fact_basis: Literal["recomputed"] = "recomputed"
    purpose_completeness_basis: Literal["not_established"] = "not_established"
    authority_role: Literal["diagnostic_only"] = "diagnostic_only"
    limitation_code: Literal["nl_helper_read_is_not_complete_producer_consumption"] = (
        "nl_helper_read_is_not_complete_producer_consumption"
    )


'''
assert needle in s
s=s.replace(needle,insert+needle,1)
target.write_text(s)
p='policy-engine/src/polisyos/runtime/http/services/control/nl_pipeline.py'
target=OUT/'postimages'/p
s=target.read_text()
s=s.replace('            runtime_quality_diagnostic_events: list[dict[str, Any]] = []\n', '''            runtime_quality_diagnostic_events: list[dict[str, Any]] = []
            runtime_quality_selected_reads: list[RuntimeQualitySelectedReadObservation] = []
''',1)
# Local import follows existing lazy large-NL implementation import pattern.
s=s.replace('            store = self._artifact_store\n', '''            from polisyos.runtime.quality.diagnostic_events import (
                RuntimeQualitySelectedReadObservation,
            )

            store = self._artifact_store
''',1)
needle='''                if runtime_quality_diagnostic_events:
                    snapshot["diagnostic_events"] = _progress_json(
                        runtime_quality_diagnostic_events
                    )
'''
rep=needle+'''                if runtime_quality_selected_reads:
                    snapshot["selected_read_observations"] = [
                        observation.model_dump(mode="json")
                        for observation in runtime_quality_selected_reads
                    ]
'''
assert needle in s
s=s.replace(needle,rep,1)
needle='''                                "progress_authority": "progress_reference_only",
'''
rep=needle+'''                                "selected_read_observations": [
                                    observation.model_dump(mode="json")
                                    for observation in runtime_quality_selected_reads
                                ],
'''
assert needle in s
s=s.replace(needle,rep,1)
old='''                try:
                    payload = read_core_json_artifact(store, artifact_id).value
                except (OSError, RuntimeError, TypeError, ValueError):
                    return None
                return dict(payload) if isinstance(payload, Mapping) else None
'''
new='''                from polisyos.core.artifacts import (
                    artifact_manifest_profile_sha256,
                    artifact_ref_for_manifest,
                    read_core_manifest_profile,
                )

                selector: object = artifact_id
                selection_origin = "default_view_at_read"
                if type(ref_value) is ArtifactRef and ref_value.manifest_profile_sha256:
                    selector = ref_value
                    selection_origin = "explicit_selected_ref"
                elif isinstance(ref_value, Mapping) and ref_value.get("manifest_profile_sha256"):
                    try:
                        selector = ArtifactRef.model_validate(dict(ref_value))
                    except ValueError:
                        return None
                    selection_origin = "explicit_selected_ref"
                try:
                    read = read_core_json_artifact(store, selector)
                    payload = read.value
                    if not isinstance(payload, Mapping):
                        return None
                    manifest, declaration = read_core_manifest_profile(
                        store,
                        artifact_id,
                        manifest_profile_sha256=read.selected_manifest_profile_sha256,
                    )
                    selected_ref = artifact_ref_for_manifest(manifest)
                    payload_digest = "sha256:" + hashlib.sha256(read.raw_payload_bytes).hexdigest()
                    if (
                        declaration.status != "declared"
                        or selected_ref.manifest_profile_sha256 is None
                        or read.selected_artifact_id != str(selected_ref.artifact_id)
                        or read.selected_manifest_profile_sha256
                        != artifact_manifest_profile_sha256(manifest)
                        or payload_digest != str(selected_ref.artifact_id)
                        or manifest.canon is None
                    ):
                        return None
                    matching_owner = None
                    for report_key, ref_key in QUALITY_REPORT_RUNTIME_REFS.items():
                        contract = runtime_quality_report_owner_contract(report_key, ref_key)
                        if (
                            contract is not None
                            and selected_ref.kind == contract.artifact_kind
                            and selected_ref.media_type == contract.media_type
                            and manifest.artifact_schema is not None
                            and manifest.artifact_schema.name == contract.schema_name
                            and manifest.artifact_schema.version == contract.schema_version
                            and manifest.producer is not None
                            and manifest.producer.component == contract.producer_component
                            and manifest.producer.version == contract.producer_version
                        ):
                            matching_owner = report_key
                            break
                    observation = RuntimeQualitySelectedReadObservation(
                        run_id=run_id,
                        job_id=_runtime_quality_job_id(),
                        tenant_id=_runtime_quality_identity_value("tenant_id"),
                        cell_id=_runtime_quality_identity_value("cell_id"),
                        ordinal=len(runtime_quality_selected_reads),
                        selected_ref=selected_ref,
                        selection_origin=selection_origin,
                        payload_sha256=payload_digest,
                        canonical_profile=manifest.canon,
                        manifest_schema=manifest.artifact_schema,
                        manifest_producer=manifest.producer,
                        manifest_inputs=tuple(manifest.inputs),
                        matching_registered_output_owner=matching_owner,
                    )
                except (OSError, RuntimeError, TypeError, ValueError):
                    return None
                # Capture only after the real selected reader returned bytes.
                # This helper is not the complete NL producer read denominator.
                runtime_quality_selected_reads.append(observation)
                return dict(payload)
'''
assert old in s
s=s.replace(old,new,1)
# Persist the bounded read facts alongside the existing projection; the projection
# carries no authority. New record remains explicitly diagnostic/limited.
needle='''                        "events": list(runtime_quality_diagnostic_events),
'''
rep=needle+'''                        "selected_read_observations": [
                            observation.model_dump(mode="json")
                            for observation in runtime_quality_selected_reads
                        ],
'''
assert s.count(needle)==2,s.count(needle)
s=s.replace(needle,rep)
# Caller/model context cannot substitute its own temporal identity. Carry owner
# request linkage as candidate only; independent owner re-entry is a root bridge.
needle='''    provenance["source_context"] = source_context
    merged["nl_provenance"] = provenance
'''
rep='''    temporal_owner_keys = (
        "temporal_scope", "temporal_scope_artifact_ref", "temporal_scope_request_binding",
        "nl_request_payload_ref", "nl_request_snapshot_content_hash",
    )
    for key in temporal_owner_keys:
        source_context.pop(key, None)
    source_context.pop("temporal_scope_intent", None)
    if trusted_source_context is not None:
        binding = trusted_source_context.get("temporal_scope_request_binding")
        if isinstance(binding, Mapping):
            source_context["temporal_scope_intent"] = {
                "binding": deepcopy(dict(binding)),
                "verification_status": "not_established",
                "requested_view_only": True,
                "authority_role": "diagnostic_only",
                "limitation_code": "temporal_scope_consumed_view_not_established",
            }
    provenance["source_context"] = source_context
    merged["nl_provenance"] = provenance
'''
assert needle in s
s=s.replace(needle,rep,1)
target.write_text(s)
print('Prepared actual selected-read observation and diagnostic persistence postimages.')
