"""Bounded read-only summaries for R171 diagnostic observation."""
from __future__ import annotations

import ast
from collections.abc import Mapping
from pathlib import Path
from typing import Any


def reader_assertion_span(source: bytes) -> tuple[int, int]:
    """Locate the one exact full-cycle JSON reader equality in the pinned test."""
    tree = ast.parse(source)
    tests = [node for node in tree.body if isinstance(node, ast.AsyncFunctionDef)
             and node.name == 'test_n7_grounding_gap_with_unestablished_basis_survives_fresh_reader']
    if len(tests) != 1:
        raise ValueError('reader test definition changed')
    expression = ast.parse('generation_cycle_module.GenerationCycleRecord.model_validate(cycle.model_dump(mode="json")) == cycle', mode='eval').body
    expected = ast.dump(expression, include_attributes=False)
    candidates = [node for node in ast.walk(tests[0]) if isinstance(node, ast.Assert)
                  and ast.dump(node.test, include_attributes=False) == expected]
    if len(candidates) != 1 or candidates[0].end_lineno is None:
        raise ValueError('reader equality assertion changed')
    return candidates[0].lineno, candidates[0].end_lineno


def exact_reader_failure(item: object, call: object, *, test_file: Path, span: tuple[int, int]) -> bool:
    """Select only an AssertionError raised at the exact pinned equality site."""
    info = call.excinfo
    if info is None or info.type is not AssertionError or not info.traceback:
        return False
    entry = info.traceback[-1]
    raw = entry.frame.raw
    return (raw.f_code.co_name == item.name and Path(raw.f_code.co_filename).resolve() == test_file.resolve()
            and span[0] <= entry.lineno + 1 <= span[1] and 'cycle' in entry.frame.f_locals)


def basis_return(value: object, local: Mapping[str, Any]) -> dict[str, object]:
    report = getattr(value, 'compilation_report')
    resolution = getattr(report, 'requirement_basis')
    source = getattr(value, 'routed_source_gap')
    request = local.get('acquisition_request')
    request = request if isinstance(request, Mapping) else {}
    return {
        'source_family_limitation': local.get('source_family_limitation', '<not_evaluated>'),
        'final_local_routing_limitation': local.get('routing_limitation_code', '<not_evaluated>'),
        'returned_routing_limitation': getattr(value, 'routing_limitation_code'),
        'request_binding_refused': local.get('request_binding_refused', '<not_evaluated>'),
        'unbound_input_fields': list(getattr(value, 'unbound_input_fields')),
        'request_required_data_families': request.get('required_data_families'),
        'request_driver': request.get('driver'),
        'request_has_requirement_gap': 'requirement_gap' in request,
        'source_gap_id': getattr(source, 'requirement_gap_id', None),
        'source_kind': (getattr(source, 'metadata', {}) or {}).get('source') if source else None,
        'basis_state': getattr(resolution, 'state'),
        'basis_grade': getattr(resolution, 'basis_grade'),
        'compiled_spec_ids': [getattr(spec, 'requirement_id') for spec in getattr(value, 'specs')],
        'routed_compiler_gap_ids': [getattr(gap, 'requirement_gap_id') for gap in getattr(value, 'routed_compiler_gaps')],
    }


def value_differences(left: object, right: object, *, limit: int = 60) -> dict[str, object]:
    """Locate type/value/private differences without deciding equality for the test."""
    rows: list[dict[str, str]] = []
    visited: set[tuple[int, int]] = set()
    truncated = False

    def add(path: str, a: object, b: object, reason: str) -> None:
        nonlocal truncated
        if len(rows) >= limit:
            truncated = True
            return
        rows.append({'path': path, 'reason': reason, 'left_type': type(a).__qualname__,
                     'right_type': type(b).__qualname__, 'left_repr': repr(a)[:160], 'right_repr': repr(b)[:160]})

    def visit(a: object, b: object, path: str) -> None:
        nonlocal truncated
        if len(rows) >= limit:
            truncated = True
            return
        if a is b:
            return
        if type(a) is not type(b):
            add(path, a, b, 'type_mismatch')
            return
        key = (id(a), id(b))
        if key in visited:
            return
        visited.add(key)
        fields = getattr(type(a), 'model_fields', None)
        if isinstance(fields, Mapping):
            for name in fields:
                visit(getattr(a, name), getattr(b, name), path + '.' + name)
            visit(getattr(a, '__pydantic_private__', None), getattr(b, '__pydantic_private__', None), path + '.__pydantic_private__')
            visit(getattr(a, '__pydantic_extra__', None), getattr(b, '__pydantic_extra__', None), path + '.__pydantic_extra__')
        elif isinstance(a, Mapping):
            keys = set(a) | set(b)
            for key in sorted(keys, key=repr):
                if key not in a or key not in b:
                    add(path + '[' + repr(key) + ']', a.get(key, '<missing>'), b.get(key, '<missing>'), 'key_missing')
                else:
                    visit(a[key], b[key], path + '[' + repr(key) + ']')
        elif isinstance(a, (tuple, list)):
            if len(a) != len(b):
                add(path, a, b, 'length_mismatch')
            for index, (x, y) in enumerate(zip(a, b)):
                visit(x, y, path + '[' + str(index) + ']')
        else:
            try:
                equal = a == b
                if not isinstance(equal, bool):
                    equal = bool(equal)
            except Exception:
                add(path, a, b, 'comparison_error')
                return
            if not equal:
                add(path, a, b, 'value_mismatch')

    visit(left, right, 'cycle')
    return {'differences': rows, 'truncated': truncated, 'limit': limit}
