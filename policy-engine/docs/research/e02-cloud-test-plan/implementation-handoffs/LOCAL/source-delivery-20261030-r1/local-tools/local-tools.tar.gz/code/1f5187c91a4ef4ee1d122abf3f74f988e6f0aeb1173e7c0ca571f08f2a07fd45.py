"""Check AST anchors without importing product or running any test."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path

here = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('control_planning', here / 'e02_property_controls.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
for rel in m.PINS:
    m._file_pin(rel)
cases = [
    ('law_positive_gen', 'tests/unit/runtime/quality/test_generation_source.py', 'test_synthetic_cg2_contract_mechanism_remains_non_promotable', None, m._replace_positive_reference),
    ('law_positive_bind', 'tests/unit/runtime/quality/test_grounding_bind.py', 'test_contract_testing_bind_resolves_non_promotable', None, m._replace_positive_reference),
    ('hidden_legal_edge', 'tests/unit/runtime/quality/test_grounding_bind.py', '_reference', None, m._inject_legal_reference),
    ('legal_firewall_removed', 'src/polisyos/runtime/quality/credal_reference.py', 'reference_lift', 'CredalReference', m._remove_legal_lift),
    ('per_seed_stale', 'src/polisyos/runtime/quality/joint_simulation_horizon.py', '_run_cached_replicates', None, m._stale_seed),
    ('trajectory_guard_removed', 'src/polisyos/runtime/quality/generation_cycle.py', '_validate_loaded_joint_simulation_result', None, lambda n: m._remove_guard(n, 'joint_simulation_result_trajectory_missing')),
    ('work_count_guard_removed', 'src/polisyos/runtime/quality/joint_simulation_horizon.py', 'physical_work_observations', 'JointSimulationResult', lambda n: m._remove_guard(n, 'n5_physical_work_unit_count_mismatch')),
]
rows = []
for name, rel, fn, cls, transform in cases:
    n = m._function_node(rel, fn, cls)
    before = ast.dump(n, include_attributes=False)
    assertions = [ast.dump(x, include_attributes=False) for x in ast.walk(n) if isinstance(x, ast.Assert)]
    transform(n)
    after = ast.dump(n, include_attributes=False)
    assert before != after
    if rel.startswith('tests/'):
        assert assertions == [ast.dump(x, include_attributes=False) for x in ast.walk(n) if isinstance(x, ast.Assert)]
    ast.fix_missing_locations(n)
    compile(ast.Module(body=[n], type_ignores=[]), str(m.P / rel), 'exec', flags=__import__('__future__').annotations.compiler_flag, dont_inherit=True)
    rows.append({'control': name, 'source': rel, 'qualified_name': f'{cls}.{fn}' if cls else fn, 'before_ast_sha256': hashlib.sha256(before.encode()).hexdigest(), 'after_ast_sha256': hashlib.sha256(after.encode()).hexdigest(), 'assertions_unchanged': rel.startswith('tests/')})
print(json.dumps({'status': 'STATIC_AST_ONLY', 'source_pins': m.PINS, 'transform_anchors': rows, 'reentry_stale': 'manual wrapper, source owner read and pinned; actual behavior UNRUN', 'runtime': 'UNRUN', 'closure_ids': []}, indent=2))
