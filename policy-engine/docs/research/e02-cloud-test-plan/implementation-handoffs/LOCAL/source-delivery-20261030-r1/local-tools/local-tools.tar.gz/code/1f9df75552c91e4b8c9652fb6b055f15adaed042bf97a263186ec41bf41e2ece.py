"""Bounded actual-collector/test-callable comparisons; no native/full collection."""
from pathlib import Path
import gc,hashlib,importlib.util,inspect,json,resource,signal,sys,time,traceback
ROOT=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos');PRODUCT=ROOT/'policy-engine';P=Path(__file__).resolve().parent
signal.alarm(110);sys.path.insert(0,str(PRODUCT))
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
T=load('r11_legacy_tests',PRODUCT/'tests/repo_quality/architecture/test_decomposition_preflight_gates.py')
RECORDS=[r for r in json.loads((P/'r11_failure_case_arguments.json').read_text())['records'] if r['execution_plan']=='include']
CASES=[(r['function'],r['param_kwargs']) for r in RECORDS]

result={'scope':'86 exact R107 failing nonregistry test-callable invocations per owner; not full native/P41 replay','test_module_sha256':hashlib.sha256(Path(T.__file__).read_bytes()).hexdigest(),'rows':[]}
for variant in [v for v in json.loads((P/'variant-inputs.json').read_text())['variants'] if v['name']!='current']+[dict(json.loads((P/'candidate-owner.json').read_text()),name='candidate-draft3')]:
 owner=load('r11_'+variant['name'],Path(variant['owner']));owner.REPO_ROOT=PRODUCT;owner.SRC_ROOT=PRODUCT/'src'
 T.preflight=owner
 for name in ['REPO_ROOT','validate_dynamic_imports','validate_import_cycles','validate_import_time_regression','validate_reexport_shim_shapes']:setattr(T,name,getattr(owner,name))
 for i,(name,kwargs) in enumerate(CASES):
  fixture=P/'fixtures'/sys.argv[1]/variant['name']/str(i);fixture.mkdir(parents=True,exist_ok=True)
  fn=getattr(T,name);args=dict(kwargs);params=inspect.signature(fn).parameters
  if 'tmp_path' in params:args['tmp_path']=fixture
  row={'variant':variant['name'],'case':name,'parameters':kwargs,'r107_testcase':RECORDS[i]['testcase_name'],'owner_origin':owner.__file__,'owner_sha256':variant['sha256']};start=time.monotonic()
  try:
   with T.pytest.MonkeyPatch.context() as patch:
    if 'monkeypatch' in params:args['monkeypatch']=patch
    fn(**args)
  except BaseException as e:row.update(status='FAIL',error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc())
  else:row['status']='PASS'
  row['elapsed_seconds']=time.monotonic()-start;result['rows'].append(row)
  with (P/'representatives.progress.jsonl').open('a') as stream:stream.write(json.dumps(row)+'\n')
  gc.collect()
result.update(product_imports=[n for n in sys.modules if n=='polisyos' or n.startswith('polisyos.')],ru_maxrss_platform_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
print(json.dumps(result,indent=2))
