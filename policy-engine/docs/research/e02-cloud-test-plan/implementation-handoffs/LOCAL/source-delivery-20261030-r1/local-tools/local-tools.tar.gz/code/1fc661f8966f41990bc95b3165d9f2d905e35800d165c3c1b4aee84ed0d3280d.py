"""Produce sparse bridge postimages from the exact author base; no canonical writes."""
from pathlib import Path
import subprocess
R=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos');H=R/'LOCAL/raw/e02-execution-20261027/repairs/FED-operational-bridge-r1';B='545c6990e2bfa42bf580b475e23cf88df04e71d8'
def read(p):return subprocess.check_output(['git','show',B+':'+p],cwd=R).decode()
def save(p,s):
 t=H/'postimages'/p;t.parent.mkdir(parents=True,exist_ok=True);assert not t.exists();t.write_text(s)
p='policy-engine/src/polisyos/fabric/api.py';s=read(p).replace('from datetime import UTC, datetime','from dataclasses import dataclass\nfrom datetime import UTC, datetime')
s=s.replace('    from collections.abc import AsyncIterable, Callable, Iterable','    from collections.abc import AsyncIterable, Callable, Iterable\n    from pathlib import Path\n\n    from polisyos.fabric.connectors.federation.types import CompositionRequest')
anchor='def fabric_get_data(\n'
addition='''@dataclass(frozen=True)
class FederationFetchSource:
    """One explicitly selected connector/dataset pair, preserving caller order."""

    connector_id: str
    dataset_id: str


@dataclass(frozen=True)
class FederationFetchRequest:
    """Opt-in bounded composition; the output directory must not already exist.

    Sources may be selected by the existing FederationPlanner or explicitly by
    the caller. This object grants no source-selection authority. Constraints
    supplied to fabric_get_data apply to every source's FetchRequest.
    """

    composition: CompositionRequest
    sources: tuple[FederationFetchSource, ...]
    output_root: Path


'''
assert s.count(anchor)==1;s=s.replace(anchor,addition+anchor)
s=s.replace('    registry: ConnectorRegistryLike | None = None,\n) -> FetchResult[Any]:','    registry: ConnectorRegistryLike | None = None,\n    federation: FederationFetchRequest | None = None,\n) -> FetchResult[Any]:',1)
anchor='    from polisyos.ir.connectors import FetchRequest\n\n    constraints = constraints or {}'
rep='''    from polisyos.ir.connectors import FetchRequest

    if federation is not None:
        from polisyos.fabric.federated_fetch import fetch_federated

        if connector_id is not None:
            raise ValueError("connector_id and explicit federation selections are mutually exclusive")
        return fetch_federated(
            dataset_id=dataset_id,
            federation=federation,
            constraints=constraints,
            registry=resolve_connector_registry(registry),
        )

    constraints = constraints or {}'''
assert s.count(anchor)==1;s=s.replace(anchor,rep)
s=s.replace('    Returns\n    -------\n    FetchResult','    federation : FederationFetchRequest | None\n        Explicit opt-in ordered composition and new selected-output directory.\n        Default None preserves the single-connector path.\n\n    Returns\n    -------\n    FetchResult',1);save(p,s)
p='policy-engine/src/polisyos/fabric/__init__.py';s=read(p)
names=['FederatedFetchResult','FederationFetchAudit','FederationFetchRequest','FederationFetchSource','reopen_federated_fetch_result']
s=s.replace('    "FabricFetchReceipt",','    "FabricFetchReceipt",\n    "FederatedFetchResult",\n    "FederationFetchAudit",\n    "FederationFetchRequest",\n    "FederationFetchSource",',1)
s=s.replace('    "resolve_connector_registry",','    "reopen_federated_fetch_result",\n    "resolve_connector_registry",',1)
anchor='    "fabric_get_data": ("polisyos.fabric.api", "fabric_get_data"),'
entries='\n'.join(f'    "{n}": ("polisyos.fabric.{"api" if n in {"FederationFetchRequest","FederationFetchSource"} else "federated_fetch"}", "{n}"),' for n in names)
assert s.count(anchor)==1;s=s.replace(anchor,anchor+'\n'+entries);save(p,s)
p='policy-engine/src/polisyos/scientist/adapters/fabric_bridge.py';s=read(p)
s=s.replace('    from polisyos.fabric.api import ConnectorRegistryLike','    from polisyos.fabric.api import ConnectorRegistryLike, FederationFetchRequest')
s=s.replace('        registry: ConnectorRegistryLike | None = None,\n    ) -> FetchResult[Any]: ...','        registry: ConnectorRegistryLike | None = None,\n        federation: FederationFetchRequest | None = None,\n    ) -> FetchResult[Any]: ...')
s=s.replace('        catalog_store: DatasetCatalogStoreLike | None = None,\n    ) -> None:','        catalog_store: DatasetCatalogStoreLike | None = None,\n        federation: FederationFetchRequest | None = None,\n    ) -> None:',1)
s=s.replace('        self._catalog_store = catalog_store','        self._catalog_store = catalog_store\n        self._federation = federation',1)
anchor='''        fetch_result = self._fetch_data(
            dataset_id=dataset_id,
            constraints=constraints,
            registry=self._connector_registry,
        )'''
rep='''        federation_audit: dict[str, Any] | None = None
        if self._federation is None:
            fetch_result = self._fetch_data(
                dataset_id=dataset_id,
                constraints=constraints,
                registry=self._connector_registry,
            )
        else:
            from polisyos.fabric import reopen_federated_fetch_result

            fetched = self._fetch_data(
                dataset_id=dataset_id,
                constraints=constraints,
                registry=self._connector_registry,
                federation=self._federation,
            )
            # This consumer reopens actual selected bytes; caller data/attrs and
            # audit summaries cannot substitute for this second fresh replay.
            fetch_result = reopen_federated_fetch_result(fetched)
            federation_audit = fetch_result.federation_audit.model_dump(mode="json")'''
assert s.count(anchor)==1;s=s.replace(anchor,rep)
anchor='''        evidence_ref = _coerce_evidence_ref(fetch_result)'''
rep='''        if federation_audit is not None:
            quality_payload["freshness_status"] = {
                "is_fresh": False,
                "level": "unknown",
                "data_age_seconds": None,
                "message": "Federation replay does not establish source currentness",
                "fetched_at": fetch_result.fetched_at.isoformat(),
            }
        evidence_ref = _coerce_evidence_ref(fetch_result)'''
assert s.count(anchor)==1;s=s.replace(anchor,rep)
s=s.replace('        warnings_ref = _persist_warnings(store, fetch_result)','        warnings_ref = _persist_warnings(\n            store, fetch_result, federation_audit=federation_audit\n        )',1)
anchor='''        semantic_stats, semantic_notes = _collect_snapshot_semantics(fetch_result.data)'''
rep='''        if federation_audit is not None:
            snapshot_stats["federation_manifest_sha256"] = str(
                federation_audit["manifest_sha256"]
            )
            snapshot_notes.extend(
                [
                    "federation.assurance=software_derivation_candidate",
                    "federation.leaf_history=consumer_asserted",
                    "federation.currentness=not_established",
                ]
            )
        semantic_stats, semantic_notes = _collect_snapshot_semantics(fetch_result.data)'''
assert s.count(anchor)==1;s=s.replace(anchor,rep)
s=s.replace('def _persist_warnings(store: ArtifactStore, result: FetchResult[Any]) -> WarningsRef | None:','''def _persist_warnings(
    store: ArtifactStore,
    result: FetchResult[Any],
    *,
    federation_audit: dict[str, Any] | None = None,
) -> WarningsRef | None:''')
anchor='''    if not warnings:
        return None'''
rep='''    if federation_audit is not None:
        warnings.append(
            WarningRecord(
                code="fabric.federation.candidate_derivation",
                msg="Selected software replay; source history and currentness remain unknown",
                data=federation_audit,
            )
        )
    if not warnings:
        return None'''
assert s.count(anchor)==1;s=s.replace(anchor,rep);save(p,s)
