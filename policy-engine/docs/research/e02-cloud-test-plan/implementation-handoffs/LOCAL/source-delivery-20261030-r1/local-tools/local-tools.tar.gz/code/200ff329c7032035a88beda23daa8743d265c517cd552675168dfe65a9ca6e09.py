from pathlib import Path
p=Path('LOCAL/raw/e02-execution-20261027/repairs/C48-r5/c53-postimages/policy-engine/src/polisyos/scientist/methods/search/funnel/orchestrator.py')
s=p.read_text()
def rep(a,b):
 global s
 if s.count(a)!=1:raise RuntimeError((s.count(a),a[:100]))
 s=s.replace(a,b,1)
start=s.index('        cached_ticket = (\n',s.index('    def submit('))
end=s.index('        ticket_id = str(uuid4())\n',start)
s=s[:start]+'''        # Reuse only the explicit live Stage A attempt handed back by this
        # owner to its matching Stage B call. A separate request must run the
        # current stage, lesson, correlation, uncertainty and access gates.
        # Immutable selected Foundry/AD01 source computation remains reusable
        # through its owner; a whole prior funnel result is not that source.
        if prior_attempt is not None and search_uncertainty_owner_context is None:
            try:
                same_context = _stable_context_identity(
                    self._ticket_effective_context(prior_attempt)
                ) == _stable_context_identity(cache_context)
            except (TypeError, ValueError):
                same_context = False
            if same_context:
                return prior_attempt
        previous_ticket = None
        reusable_result = None
''' + s[end:]
start=s.index('        if previous_ticket is None and prior_attempt is not None:\n',s.index('    def submit('))
end=s.index('        store = ticket.context.get("store")\n',start)
s=s[:start]+'''        if prior_attempt is not None:
            # This is a distinct physical attempt. Retain the actual preceding
            # ticket's trace regardless of unrelated cache/continuation lookup.
            ticket.parent_ticket_id = prior_attempt.ticket_id
            ticket.prior_attempt_ticket_id = prior_attempt.ticket_id
            ticket.lineage = (*prior_attempt.lineage, ticket_id)
''' + s[end:]
rep('''        if cacheable:
            self._latest_ticket_by_candidate[candidate_hash] = ticket.ticket_id
            self._latest_ticket_by_context[continuation_key] = ticket.ticket_id
            self._ticket_cache[cache_key] = ticket.ticket_id
''','''        # The current request retains its ticket, but does not publish a
        # reusable aggregate decision for a later independent request.
''')
rep('''            result = _reconcile_funnel_score(
                stage.evaluate(
                    resolved_ticket.candidate,
                    self._build_stage_context(resolved_ticket),
                )
            )
            work_packet_claim = self._admit_executed_work_packet(
''','''            stage_candidate = deepcopy(resolved_ticket.candidate)
            result = stage.evaluate(stage_candidate, self._build_stage_context(resolved_ticket))
            try:
                subject_unchanged = candidate_payloads_equal(stage_candidate, resolved_ticket.candidate)
            except (TypeError, ValueError):
                subject_unchanged = False
            if not subject_unchanged:
                # Preserve the physical attempt and cost, but admit no score,
                # work packet, routing decision or changed subject as the input.
                resolved_ticket.trace.append(
                    FunnelTraceStep(
                        fidelity_level=next_level,
                        stage_name=result.stage_name,
                        objective_value=None,
                        is_promising=False,
                        duration_seconds=result.duration_seconds,
                        compute_cost_usd=result.compute_cost_usd,
                        compute_cost_origin=result.compute_cost_origin,
                        score_status=ObjectiveScoreStatus.INVALID,
                    )
                )
                resolved_ticket.final_action = "defer"
                resolved_ticket.is_terminal = True
                resolved_ticket.continuation_reason = "evaluated_subject_mutated"
                break
            result = _reconcile_funnel_score(result)
            work_packet_claim = self._admit_executed_work_packet(
''')
# The compatibility wrapper reports only same-attempt continuation as a hit.
start=s.index('            sentinel_meta = extract_sentinel_metadata(candidate) or {}\n',s.index('    def as_stage_b_callable('))
end=s.index('            ticket = self.submit(\n',start)
s=s[:start]+s[end:]
rep('''            feedback["funnel_cache"] = "hit" if cache_hit else "miss"
''','''            feedback["funnel_cache"] = (
                "hit" if prior_ticket_id is not None and ticket.ticket_id == prior_ticket_id else "miss"
            )
''')
p.write_text(s)
