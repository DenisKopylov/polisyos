from pathlib import Path
import subprocess
ROOT=Path.cwd(); OUT=ROOT/'LOCAL/raw/e02-execution-20261027/repairs/C38-r3'
for p in ['policy-engine/src/polisyos/runtime/quality/authority.py','policy-engine/src/polisyos/runtime/http/services/control/nl_pipeline.py']:
    f=OUT/'postimages'/p
    s=f.read_text().replace('        if candidate.get("authority_role") == "producer_authority" and "same_input_closure" in candidate:\n','        if (\n            candidate.get("authority_role") == "producer_authority"\n            and "same_input_closure" in candidate\n        ):\n')
    r=subprocess.run([str(ROOT/'policy-engine/.venv/bin/python'),'-m','ruff','check','--fix','--select','I,RUF022','--stdin-filename',str(ROOT/p),'-'],input=s.encode(),capture_output=True,cwd=ROOT/'policy-engine')
    if r.returncode: raise SystemExit(r.stderr.decode()+r.stdout.decode())
    f.write_bytes(r.stdout)
print('Applied import/all ordering and wrapped the added long condition in scratch only.')
