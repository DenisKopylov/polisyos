"""Explicitly gated, bounded local execution for the I2 phase observer. Not run by preparation."""
import argparse
import gzip
import hashlib
import json
import os
import resource
import selectors
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path

PACKET = Path(__file__).resolve().parent
ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
PRODUCT = ROOT / "policy-engine"
OUT = PACKET / "run" / "attempt-r188-1"
MANIFEST = json.loads((PACKET / "manifest.json").read_text(encoding="utf-8"))


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def git(*args):
    return subprocess.check_output(["git", "-C", str(ROOT), *args], text=True).strip()


def resource_limits(manifest):
    resources = manifest.get("resources")
    caps = resources.get("hard_caps") if isinstance(resources, dict) else None
    if not isinstance(caps, dict):
        raise ValueError("resources.hard_caps missing; no attempt output created")
    required = {
        "wall_timeout_seconds": "wall_timeout_seconds",
        "cpu_seconds_soft_hard": "cpu_seconds_soft_hard",
        "virtual_address_space_bytes": "virtual_address_space_bytes",
        "per_child_file_bytes": "per_child_file_bytes",
        "stdout_uncompressed_bytes": "max_uncompressed_output_bytes",
        "stdout_compressed_bytes": "max_compressed_output_bytes",
        "stderr_bytes": "max_stderr_bytes",
        "tmpdir_bytes": "tmpdir_bytes",
        "max_process_group_rss_kib": "max_process_group_rss_kib",
        "rss_sample_interval_seconds": "rss_sample_interval_seconds",
        "metadata_bytes": "metadata_bytes",
        "rss_sample_bytes": "rss_sample_bytes",
        "numerical_threads": "numerical_threads",
        "max_inflight_stdout_chunk_bytes": "max_stdout_chunk_bytes",
    }
    limits = {}
    for cap_key, output_key in required.items():
        value = caps.get(cap_key)
        if cap_key == "cpu_seconds_soft_hard":
            valid = isinstance(value, list) and len(value) == 2 and all(type(v) is int and v > 0 for v in value) and value[0] <= value[1]
        else:
            valid = type(value) is int and value > 0
        if not valid:
            raise ValueError("invalid or missing resource cap " + cap_key + "; no attempt output created")
        if cap_key == "numerical_threads" and value != 1:
            raise ValueError("numerical_threads must remain 1; no attempt output created")
        if cap_key == "max_inflight_stdout_chunk_bytes" and value > 65536:
            raise ValueError("stdout chunks exceed supervisor read buffer; no attempt output created")
        limits[output_key] = value
    if limits["numerical_threads"] != 1:
        raise ValueError("numerical thread count must be 1; no attempt output created")
    admission = resources.get("execution_admission")
    minimum_free = admission.get("minimum_free_disk_bytes") if isinstance(admission, dict) else None
    if type(minimum_free) is not int or minimum_free <= 0:
        raise ValueError("invalid disk admission threshold; no attempt output created")
    limits["minimum_free_disk_bytes"] = minimum_free
    expected_additional = resources.get("expected_added_disk_upper_bound_bytes")
    if type(expected_additional) is not int or expected_additional <= 0 or expected_additional > 64 * 1024**2:
        raise ValueError("output forecast must be bounded to 64 MiB; no attempt output created")
    minimum_required = 6 * 1024**3 + 512 * 1024**2 + expected_additional
    if minimum_free < minimum_required:
        raise ValueError("disk admission must retain 512 MiB above the 6 GiB stop after the output forecast")
    maxima = {
        "wall_timeout_seconds": 120,
        "max_uncompressed_output_bytes": 32 * 1024**2,
        "max_compressed_output_bytes": 8 * 1024**2,
        "max_stderr_bytes": 1 * 1024**2,
        "tmpdir_bytes": 32 * 1024**2,
        "metadata_bytes": 4 * 1024**2,
        "per_child_file_bytes": 1 * 1024**2,
        "rss_sample_bytes": 1 * 1024**2,
        "max_process_group_rss_kib": 1024 * 1024,
        "rss_sample_interval_seconds": 1,
    }
    for key, maximum in maxima.items():
        if limits[key] > maximum:
            raise ValueError("resource cap exceeds R188 ceiling: " + key)
    limits["expected_added_disk_upper_bound_bytes"] = expected_additional
    limits["run_monitor_disk_floor_bytes"] = 6 * 1024**3 + 512 * 1024**2
    return limits


def preflight():
    limits = resource_limits(MANIFEST)
    expected_python = (PRODUCT / ".venv/bin/python").resolve()
    actual_python = Path(sys.executable).resolve()
    if actual_python != expected_python or sys.version_info[:3] != (3, 14, 3):
        raise RuntimeError("supervisor interpreter mismatch; no command executed")
    identity = {
        "branch": git("symbolic-ref", "--short", "HEAD"),
        "head": git("rev-parse", "HEAD"),
        "tree": git("rev-parse", "HEAD^{tree}"),
    }
    if identity != MANIFEST["source_identity"]:
        raise RuntimeError("source admission mismatch; no command executed")
    if subprocess.run(["git", "-C", str(ROOT), "diff", "--quiet", "HEAD", "--"]).returncode:
        raise RuntimeError("tracked worktree is dirty; no command executed")
    if subprocess.run(["git", "-C", str(ROOT), "diff", "--cached", "--quiet"]).returncode:
        raise RuntimeError("index is dirty; no command executed")
    for rel, pin in MANIFEST["source_pins"].items():
        if sha(ROOT / rel) != pin["sha256"]:
            raise RuntimeError("source pin mismatch: " + rel)
    packet_hash_path = PACKET / "packet-hashes.json"
    if sha(packet_hash_path) != MANIFEST.get("packet_hashes_sha256"):
        raise RuntimeError("packet manifest hash mismatch; no command executed")
    packet_hashes = json.loads(packet_hash_path.read_text(encoding="utf-8"))
    for rel, expected in packet_hashes.items():
        if sha(PACKET / rel) != expected:
            raise RuntimeError("prepared instrument packet changed: " + rel)
    free = shutil.disk_usage(PRODUCT).free
    min_free = limits["minimum_free_disk_bytes"]
    if free < min_free:
        raise RuntimeError("disk admission below 6 GiB plus required headroom and forecast; no command executed")
    return {**identity, "supervisor_interpreter": str(actual_python), "supervisor_python_version": sys.version,
            "disk_free_bytes": free, "disk_free_after_requirement_bytes": free - min_free,
            "resource_limits": limits,
            "root_guard_sha256": sha(ROOT / MANIFEST["root_guard_path"]),
            "effective_child_limit_status": {
                "RLIMIT_CPU": "APPLIED",
                "RLIMIT_FSIZE": "APPLIED",
                "RLIMIT_AS": "UNAVAILABLE_EXACT_HOST_RUNTIME_PROBE_R187",
                "sampled_combined_rss": "DIAGNOSTIC_ABORT_AT_DECLARED_THRESHOLD_NOT_HARD_LIMIT"}}


def compress_stdout_chunk(chunk, raw_bytes, compressed_bytes, raw_limit, compressed_limit):
    """Return one complete gzip member only when both retained-byte caps allow it."""
    if raw_bytes + len(chunk) > raw_limit:
        raise ValueError("public_output_uncompressed_cap")
    member = gzip.compress(chunk, mtime=0)
    if compressed_bytes + len(member) > compressed_limit:
        raise ValueError("public_output_compressed_cap")
    return member


def sample_diagnostic_rss_kib(process_group_id, supervisor_pid):
    result = subprocess.run(
        ["/bin/ps", "-o", "pid=,pgid=,rss=", "-g", str(process_group_id), "-p", str(supervisor_pid)],
        capture_output=True, text=True, timeout=1, check=False,
    )
    if result.returncode != 0:
        raise RuntimeError("RSS sampler failed")
    group_rows = []
    supervisor_values = []
    for line in result.stdout.splitlines():
        fields = line.split()
        if len(fields) != 3:
            raise RuntimeError("RSS sampler returned an unparseable row")
        pid, pgid, rss_kib = (int(value) for value in fields)
        if pgid == process_group_id:
            group_rows.append((pid, rss_kib))
        if pid == supervisor_pid:
            supervisor_values.append(rss_kib)
    if len(supervisor_values) != 1:
        raise RuntimeError("supervisor RSS row missing or duplicated")
    group_kib = sum(rss for _, rss in group_rows)
    supervisor_kib = supervisor_values[0]
    return group_kib + supervisor_kib, len(group_rows), group_kib, supervisor_kib


def metadata_tree_bytes(path):
    excluded = {"tmp", "public-output.json.gz", "stderr.log"}
    total = 0
    for item in path.iterdir():
        if item.name in excluded or item.is_symlink():
            continue
        if item.is_file():
            total += item.stat().st_size
        elif item.is_dir():
            total += subtree_bytes(item)
    return total


def append_bounded_json_line(path, value, maximum_bytes):
    encoded = (json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode()
    current = path.stat().st_size if path.exists() else 0
    if current + len(encoded) > maximum_bytes:
        raise ValueError("supervisor_metadata_cap")
    with path.open("ab") as stream:
        stream.write(encoded)


def set_child_limits(limits):
    # CPU and file-size limits are kernel-enforced; RSS remains a sampled diagnostic guard.
    cpu_soft, cpu_hard = limits["cpu_seconds_soft_hard"]
    resource.setrlimit(resource.RLIMIT_CPU, (cpu_soft, cpu_hard))
    # R187 measured RLIMIT_AS as unavailable on this admitted macOS/Python host.
    # Keep the declared requested value for the receipt; do not attempt the failing syscall.
    file_bytes = limits["per_child_file_bytes"]
    resource.setrlimit(resource.RLIMIT_FSIZE, (file_bytes, file_bytes))


def subtree_bytes(path):
    total = 0
    for current, dirs, files in os.walk(path, followlinks=False):
        dirs[:] = [name for name in dirs if not (Path(current) / name).is_symlink()]
        for name in files:
            item = Path(current) / name
            if not item.is_symlink():
                total += item.stat().st_size
    return total


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--execute", action="store_true", help="required; preparation never starts a run")
    args = parser.parse_args()
    if not args.execute:
        parser.error("run only after Root issues a source/resource lease and says --execute")
    pre = preflight()
    limits = pre["resource_limits"]
    OUT.mkdir(parents=True, exist_ok=False)
    (OUT / "preflight.json").write_text(json.dumps(pre, indent=2) + "\n", encoding="utf-8")
    profile = OUT / "sandbox.sb"
    profile.write_text("(version 1)\n(allow default)\n(deny file-write*)\n(allow file-write* (subpath " + json.dumps(str(OUT)) + "))\n(allow file-write* (literal \"/dev/null\"))\n", encoding="utf-8")
    (OUT / "tmp").mkdir()
    python = str(PRODUCT / ".venv/bin/python")
    command = ["/usr/bin/sandbox-exec", "-f", str(profile), python, "-B", str(PACKET / "launch_cli.py")]
    env = os.environ.copy()
    env.update({
        "GIT_OPTIONAL_LOCKS": "0",
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONPATH": str(PACKET / "observer") + os.pathsep + str(PRODUCT),
        "TMPDIR": str(OUT / "tmp"),
        "E02_PHASE_PROFILE_DIR": str(OUT),
        "E02_PHASE_PACKET": str(PACKET),
        "POLISYOS_TOOLS_TIMING_LOG": str(OUT / "cli-timing.jsonl"),
        "OMP_NUM_THREADS": str(limits["numerical_threads"]),
        "OPENBLAS_NUM_THREADS": str(limits["numerical_threads"]),
        "MKL_NUM_THREADS": str(limits["numerical_threads"]),
        "NUMEXPR_NUM_THREADS": str(limits["numerical_threads"]),
        "VECLIB_MAXIMUM_THREADS": str(limits["numerical_threads"]),
    })
    public_cli_argv = ["polisyos-tools", "validation", "schema-fqn-census", "--output-format", "json", "--repo-root", "."]
    (OUT / "command.json").write_text(json.dumps({"supervised_argv": command,
        "public_cli_argv": public_cli_argv, "cwd": str(PRODUCT),
        "scope": "unchanged public tools.cli dispatch via runpy; observer wraps in-memory functions and regex iterators",
        "source_identity": MANIFEST["source_identity"]}, indent=2) + "\n", encoding="utf-8")
    stdout_path, stderr_path = OUT / "public-output.json.gz", OUT / "stderr.log"
    raw_hash = hashlib.sha256()
    raw_bytes = 0
    compressed_limit = limits["max_compressed_output_bytes"]
    raw_limit = limits["max_uncompressed_output_bytes"]
    stderr_limit = limits["max_stderr_bytes"]
    started = time.monotonic()
    stop_reason = None
    rss_samples_path = OUT / "resource-samples.ndjson"
    rss_peak_kib = 0
    rss_sample_count = 0
    rss_process_peak = 0
    process = subprocess.Popen(command, cwd=PRODUCT, env=env, stdout=subprocess.PIPE,
        stderr=subprocess.PIPE, stdin=subprocess.DEVNULL, close_fds=True,
        start_new_session=True, preexec_fn=lambda: set_child_limits(limits))
    ready_deadline = time.monotonic() + 5.0
    while not (OUT / "observer.ready").is_file() and process.poll() is None and time.monotonic() < ready_deadline:
        time.sleep(0.05)
    if not (OUT / "observer.ready").is_file():
        stop_reason = "observer_not_armed"
        try:
            os.killpg(process.pid, signal.SIGTERM)
            process.wait(timeout=3)
        except (ProcessLookupError, subprocess.TimeoutExpired):
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait()
    selector = selectors.DefaultSelector()
    selector.register(process.stdout, selectors.EVENT_READ, "stdout")
    selector.register(process.stderr, selectors.EVENT_READ, "stderr")
    os.set_blocking(process.stdout.fileno(), False)
    os.set_blocking(process.stderr.fileno(), False)
    stderr_bytes = 0
    chunk_size = limits["max_stdout_chunk_bytes"]
    with stdout_path.open("wb") as compressed_file, stderr_path.open("wb") as stderr_file:
        deadline = started + limits["wall_timeout_seconds"]
        next_rss_sample = started
        while selector.get_map() or process.poll() is None:
            if time.monotonic() >= deadline:
                stop_reason = "harness_wall_timeout"
                break
            if shutil.disk_usage(PRODUCT).free < limits["run_monitor_disk_floor_bytes"]:
                stop_reason = "host_disk_headroom_guard"
                break
            if subtree_bytes(OUT / "tmp") > limits["tmpdir_bytes"]:
                stop_reason = "tmpdir_aggregate_cap"
                break
            if metadata_tree_bytes(OUT) > limits["metadata_bytes"]:
                stop_reason = "metadata_aggregate_cap"
                break
            if time.monotonic() >= next_rss_sample:
                try:
                    observed_rss_kib, observed_processes, group_rss_kib, supervisor_rss_kib = sample_diagnostic_rss_kib(
                        process.pid, os.getpid()
                    )
                    append_bounded_json_line(rss_samples_path, {
                        "elapsed_s": round(time.monotonic() - started, 3),
                        "process_group_id": process.pid,
                        "child_process_count": observed_processes,
                        "child_process_group_rss_kib": group_rss_kib,
                        "supervisor_rss_kib": supervisor_rss_kib,
                        "combined_diagnostic_rss_kib": observed_rss_kib,
                    }, limits["rss_sample_bytes"])
                except (RuntimeError, OSError, subprocess.TimeoutExpired, ValueError) as error:
                    stop_reason = "rss_or_metadata_sampler_incomplete"
                    break
                rss_sample_count += 1
                rss_peak_kib = max(rss_peak_kib, observed_rss_kib)
                rss_process_peak = max(rss_process_peak, observed_processes)
                if observed_rss_kib > limits["max_process_group_rss_kib"]:
                    stop_reason = "combined_diagnostic_rss_abort"
                    break
                next_rss_sample = time.monotonic() + limits["rss_sample_interval_seconds"]
            for key, _ in selector.select(timeout=0.5):
                chunk = os.read(key.fd, chunk_size)
                if not chunk:
                    selector.unregister(key.fileobj)
                    continue
                if key.data == "stdout":
                    # Independent gzip members let us know the exact compressed size
                    # before writing; concatenated members decode as one byte stream.
                    try:
                        member = compress_stdout_chunk(
                            chunk, raw_bytes, compressed_file.tell(), raw_limit, compressed_limit
                        )
                    except ValueError as error:
                        stop_reason = str(error)
                        break
                    raw_bytes += len(chunk)
                    raw_hash.update(chunk)
                    compressed_file.write(member)
                    compressed_file.flush()
                else:
                    remaining = stderr_limit - stderr_bytes
                    if len(chunk) > remaining:
                        if remaining:
                            stderr_file.write(chunk[:remaining])
                            stderr_bytes += remaining
                        stop_reason = "stderr_cap"
                        break
                    stderr_bytes += len(chunk)
                    stderr_file.write(chunk)
            if stop_reason:
                break
        if stop_reason:
            try:
                os.killpg(process.pid, signal.SIGTERM)
                process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
        else:
            process.wait()
        # After a stop, discard all buffered stdout: it cannot exceed either
        # declared stdout ceiling. Retain only a bounded stderr prefix.
        for stream, label in ((process.stdout, "stdout"), (process.stderr, "stderr")):
            while True:
                try: chunk = os.read(stream.fileno(), chunk_size)
                except BlockingIOError: break
                if not chunk: break
                if label == "stderr":
                    remaining = stderr_limit - stderr_bytes
                    if len(chunk) > remaining:
                        if remaining:
                            stderr_file.write(chunk[:remaining])
                            stderr_bytes += remaining
                        stop_reason = stop_reason or "stderr_cap"
                        break
                    stderr_bytes += len(chunk)
                    stderr_file.write(chunk)
    wall = time.monotonic() - started
    rc = process.returncode
    after = {"branch": git("symbolic-ref", "--short", "HEAD"), "head": git("rev-parse", "HEAD"),
             "tree": git("rev-parse", "HEAD^{tree}"), "root_guard_sha256": sha(ROOT / MANIFEST["root_guard_path"]),
            "effective_child_limit_status": {
                "RLIMIT_CPU": "APPLIED",
                "RLIMIT_FSIZE": "APPLIED",
                "RLIMIT_AS": "UNAVAILABLE_EXACT_HOST_RUNTIME_PROBE_R187",
                "sampled_combined_rss": "DIAGNOSTIC_ABORT_AT_DECLARED_THRESHOLD_NOT_HARD_LIMIT"}}
    source_drift = after["head"] != pre["head"] or after["tree"] != pre["tree"] or after["branch"] != pre["branch"]
    root_guard_drift = after["root_guard_sha256"] != pre["root_guard_sha256"]
    if (source_drift or root_guard_drift) and stop_reason is None:
        stop_reason = "source_or_root_guard_changed_during_diagnostic"
    classification = "HARNESS_INCOMPLETE" if stop_reason or rc < 0 else "CLI_RETURNED_REQUIRES_RECEIPT_RECONCILIATION"
    receipt = {
        "classification": classification,
        "stop_reason": stop_reason, "exit_code": rc, "wall_seconds": round(wall, 3),
        "postflight_source_identity": after, "source_drift": source_drift, "root_guard_drift": root_guard_drift,
        "command": command, "source_identity": pre,
        "public_stdout_uncompressed_bytes": raw_bytes, "public_stdout_sha256": raw_hash.hexdigest(),
        "public_stdout_gzip_bytes": stdout_path.stat().st_size, "public_stdout_gzip_sha256": sha(stdout_path),
        "stderr_bytes": stderr_bytes, "stderr_sha256": sha(stderr_path),
        "max_supervisor_direct_child_rusage_platform_units": resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
        "rss_scope_note": "sampled combined RSS of the supervisor process plus its dedicated public-CLI child process group; diagnostic abort threshold is sampled, not a kernel-hard RSS limit. RLIMIT_AS is unavailable for the exact host/runtime combination recorded in the R187 probe and is not applied by R188.",
        "combined_diagnostic_rss_limit_kib": limits["max_process_group_rss_kib"],
        "combined_diagnostic_rss_peak_kib": rss_peak_kib,
        "rss_sample_count": rss_sample_count,
        "child_process_count_peak": rss_process_peak,
        "disk_free_after_run_bytes": shutil.disk_usage(PRODUCT).free,
        "run_monitor_disk_floor_bytes": limits["run_monitor_disk_floor_bytes"],
        "metadata_bytes_retained": metadata_tree_bytes(OUT),
        "tmpdir_bytes_retained": subtree_bytes(OUT / "tmp"),
        "source_semantic_result": "UNRUN unless completed JSON is independently parsed and reconciled",
        "g_acceptance": False, "closure_ids": []
    }
    (OUT / "supervisor-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: receipt[k] for k in ("classification", "stop_reason", "exit_code", "wall_seconds", "public_stdout_uncompressed_bytes", "public_stdout_gzip_bytes")}, sort_keys=True))
    return rc if stop_reason is None and rc >= 0 else 124


if __name__ == "__main__":
    raise SystemExit(main())
