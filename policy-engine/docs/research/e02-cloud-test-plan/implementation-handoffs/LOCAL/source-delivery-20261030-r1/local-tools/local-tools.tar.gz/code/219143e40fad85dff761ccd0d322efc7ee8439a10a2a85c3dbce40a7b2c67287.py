"""Build the review-only R7 postimage from its pinned canonical preimage."""
from pathlib import Path
import hashlib

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
PACKET = Path(__file__).resolve().parent
source = (ROOT / 'policy-engine/tools/quality/validation/decomposition_preflight.py').read_text()
assert hashlib.sha256(source.encode()).hexdigest() == 'f3f286d15017c2c0a9eb0cba3458093d38b6852b7bfecbe825036c0f6145ec56'

def edit(before, after):
    global source
    count = source.count(before)
    assert count == 1 or (count == 2 and before.endswith('and base.kind in {"object", "other"}')), (count, before[:100])
    source = source.replace(before, after, 1)

edit('@dataclass(frozen=True, slots=True)\nclass _DynamicImportBinding:', '''@dataclass(frozen=True, slots=True)
class _DynamicSourceCodeOrigin:
    """Selected immutable code identity, separate from a mutable function object."""

    identity: str
    context_identity: str
    content_sha256: str
    source_module: str
    relative_path: str
    node: ast.FunctionDef
    free_variables: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class _DynamicImportBinding:''')
edit('        "callable",\n        "source_function",\n        "unknown",', '        "callable",\n        "source_function",\n        "source_method",\n        "source_code",\n        "reconstructed_function",\n        "source_closure",\n        "unknown",')
edit('    module_registry_complete: bool = True\n', '''    module_registry_complete: bool = True
    code_origin: _DynamicSourceCodeOrigin | None = None
    globals_owner: str | None = None
    function_builtins: _DynamicImportBinding | None = None
    closure_names: tuple[str, ...] = ()
''')
edit('    if module == "types" and name == "MappingProxyType":', '''    if module == "types" and name == "FunctionType":
        return _DynamicImportBinding(
            "callable", "types.FunctionType", temporal_callable_origins=("types.FunctionType",)
        )
    if module == "types" and name == "MappingProxyType":''')
edit('def _is_unresolved_importer_binding(binding: _DynamicImportBinding) -> bool:\n', '''def _dynamic_has_source_execution(binding: _DynamicImportBinding) -> bool:
    """Keep executable source values fail-closed at unsupported escape boundaries."""
    return any(
        item.kind in {"source_method", "source_code", "reconstructed_function", "source_closure"}
        for item in _dynamic_binding_nodes(binding)
    )


def _is_unresolved_importer_binding(binding: _DynamicImportBinding) -> bool:
''')
edit('    return binding.kind in {"ambiguous", "unknown", "union"} and _is_guarded_importer_binding(\n        binding\n    )', '''    if binding.kind == "union" and binding.items and all(
        item.kind in {"source_function", "reconstructed_function", "source_closure"}
        for item in binding.items
    ):
        return False
    return binding.kind in {"ambiguous", "unknown", "union"} and _is_guarded_importer_binding(
        binding
    )''')
edit('        if not importer_origins:\n            return binding\n        return _dynamic_unresolved_importer_binding(', '''        importer_origins.update(_dynamic_temporal_callable_origins(binding))
        if not importer_origins:
            return binding
        return _dynamic_unresolved_importer_binding(''')
edit('        self._module_function_summaries: dict[str, _DynamicImportFunctionSummary] = {}', '''        self._module_function_summaries: dict[str, _DynamicImportFunctionSummary] = {}
        self._invalidated_function_code: set[str] = set()
        self._source_code_depth = 0
        self._active_code_builtins: _DynamicImportBinding | None = None''')
edit('        if _is_guarded_importer_binding(binding):\n            raise DynamicImportCollectionError(\n                f"{self.relative_path}:{getattr(node, \'lineno\', 1)}: guarded importer value "', '        if _is_guarded_importer_binding(binding) or _dynamic_has_source_execution(binding):\n            raise DynamicImportCollectionError(\n                f"{self.relative_path}:{getattr(node, \'lineno\', 1)}: guarded importer value "')
edit('        if name == "__name__" and self.module_name is not None:', '''        if self._active_code_builtins is not None:
            return _dynamic_mapping_lookup(
                self._active_code_builtins, _dynamic_string_binding(name), default=_DYNAMIC_OTHER
            )
        if name == "__name__" and self.module_name is not None:''')
edit('        if binding.origin_name == "scope:globals":\n            return _DynamicNamespaceOwnerResolution("selected", self.module_name)', '        if binding.origin_name == "scope:globals":\n            return _DynamicNamespaceOwnerResolution("selected", binding.globals_owner or self.module_name)')
edit('            if (\n                self.source_bindings is not None\n                and base.kind in {"object", "other"}', '''            if node.attr == "__code__":
                return self._capture_source_code(base, node)
            if (
                self.source_bindings is not None
                and base.kind == "other"
                and base.origin_name is not None
                and base.origin_name.startswith("polisyos.")
            ):
                method = self.source_bindings.source_method_definition(base.origin_name, node.attr)
                if method is not None and method[0] == self.module_name:
                    origin = self._selected_code_origin(method[2], node)
                    return _DynamicImportBinding(
                        "source_method", origin_name=origin.identity, code_origin=origin
                    )
            if (
                self.source_bindings is not None
                and base.kind in {"object", "other"}''')
edit('            self._record_call(node, callee, argument_bindings)\n            source_function_result', '''            self._record_call(node, callee, argument_bindings)
            if callee.kind == "callable" and callee.name == "types.FunctionType":
                return self._construct_source_function(node, argument_bindings)
            source_function_result''')
edit('                    return _dynamic_scope_mapping(\n                        self._module_environment,\n                        scope_name="globals",\n                    )', '''                    return replace(
                        _dynamic_scope_mapping(
                            self._active_module_environment or self._module_environment,
                            scope_name="globals",
                        ),
                        globals_owner=self.module_name,
                    )''')
edit('            for binding in argument_bindings:\n                self._reject_guarded_escape(binding, node, "a call argument")\n            return _DYNAMIC_OTHER', '''            if callee.kind == "callable" and callee.name in DYNAMIC_CALL_NAMES:
                for binding in argument_bindings:
                    self._reject_guarded_escape(binding, node, "a dynamic importer argument")
                return _DYNAMIC_OTHER
            if self._source_code_depth:
                raise DynamicImportCollectionError(
                    f"{self.relative_path}:{node.lineno}: reconstructed source invocation "
                    "reaches opaque callable dispatch"
                )
            for binding in argument_bindings:
                for item in _dynamic_binding_nodes(binding):
                    if item.kind == "source_function" and item.origin_name is not None:
                        self._invalidated_function_code.add(item.origin_name)
                self._reject_guarded_escape(binding, node, "a call argument")
            return _DYNAMIC_OTHER''')
edit('        if isinstance(target, ast.Attribute):\n            self._reject_guarded_escape(value, target, "attribute storage")\n            receiver = self._expression_binding(target.value, environment, pending, scope_info)', '''        if isinstance(target, ast.Attribute):
            receiver = self._expression_binding(target.value, environment, pending, scope_info)
            if receiver.kind in {"source_function", "source_method"}:
                if receiver.origin_name is not None:
                    self._invalidated_function_code.add(receiver.origin_name)
                if target.attr == "__code__":
                    # Mutating a function cannot rewrite an already captured code object.
                    return
            self._reject_guarded_escape(value, target, "attribute storage")''')
edit('            if scope_info is self._module_scope_info:\n                identity = f"{self.relative_path}:{node.lineno}:{node.col_offset}"', '''            if self._source_code_depth and scope_info is not self._module_scope_info:
                if node.decorator_list or node.args.defaults or any(node.args.kw_defaults):
                    raise DynamicImportCollectionError(
                        f"{self.relative_path}:{node.lineno}: reconstructed nested callable "
                        "defaults or decorators are unsupported"
                    )
                reads, _, children = _dynamic_scope_read_dependencies(node)
                all_reads = set(reads)
                for child in children:
                    all_reads.update(_dynamic_scope_read_dependencies(child)[0])
                free = tuple(sorted(all_reads & scope_info.get("_source_lexical", set())))
                if not set(free) <= scope_info.get("_source_stable_cells", set()):
                    raise DynamicImportCollectionError(
                        f"{self.relative_path}:{node.lineno}: reconstructed nested callable "
                        "has mutable or unproven closure cells"
                    )
                captures = tuple(environment[name] for name in free)
                if any(value.kind in {"unknown", "ambiguous", "object", "mapping", "namespace"}
                       for value in captures):
                    raise DynamicImportCollectionError(
                        f"{self.relative_path}:{node.lineno}: reconstructed closure value is unresolved"
                    )
                origin = self._selected_code_origin(node, node, free_variables=free)
                environment[node.name] = _DynamicImportBinding(
                    "source_closure", origin_name=origin.identity, code_origin=origin,
                    globals_owner=self.module_name,
                    function_builtins=self._active_code_builtins,
                    closure_names=free, source_arguments=captures,
                )
            elif scope_info is self._module_scope_info:
                identity = f"{self.relative_path}:{node.lineno}:{node.col_offset}"''')
edit('                if _is_guarded_importer_binding(returned):\n', '                if _is_guarded_importer_binding(returned) or _dynamic_has_source_execution(returned):\n')
edit('        for name in global_names:\n            environment[name] = self._lookup(name, module_env)\n        for name in nonlocal_names:\n            environment[name] = parent_env.get(name, self._unknown_binding(name))', '''        if self._source_code_depth:
            parameter_names = {
                argument.arg for argument in (
                    *node.args.posonlyargs, *node.args.args, *node.args.kwonlyargs,
                    *((node.args.vararg,) if node.args.vararg else ()),
                    *((node.args.kwarg,) if node.args.kwarg else ()),
                )
            }
            scope_info["_source_lexical"] = local_names | parameter_names | set(parent_env)
            scope_info["_source_stable_cells"] = (parameter_names - local_names) | set(parent_env)
            if nonlocal_names:
                raise DynamicImportCollectionError(
                    f"{self.relative_path}:{node.lineno}: reconstructed nonlocal cells are unsupported"
                )
        for name in global_names:
            environment[name] = self._lookup(name, module_env)
        for name in nonlocal_names:
            environment[name] = parent_env.get(name, self._unknown_binding(name))''')
edit('        if binding.kind == "callable" and binding.name in DYNAMIC_CALL_NAMES:\n            resolved_call = str(binding.name)', '''        if binding.kind in {"source_code", "reconstructed_function", "source_closure"}:
            return
        if binding.kind == "union" and binding.items and all(
            item.kind in {"source_function", "reconstructed_function", "source_closure"}
            for item in binding.items
        ):
            return
        if binding.kind == "callable" and binding.name == "types.FunctionType":
            return
        if binding.kind == "callable" and binding.name in DYNAMIC_CALL_NAMES:
            resolved_call = str(binding.name)''')
edit('                    scanner = self\n                    identity = alternative.origin_name\n                    if alternative.kind == "other":', '''                    scanner = self
                    identity = alternative.origin_name
                    if alternative.kind in {"reconstructed_function", "source_closure"}:
                        if alternative.code_origin is None:
                            raise DynamicImportCollectionError(
                                f"{self.relative_path}:{call.lineno}: source code origin is unavailable"
                            )
                        pending.append(alternative.code_origin.node)
                        relevant.update(self._observed_importer_binding_names)
                        relevant.update(_DYNAMIC_IMPORT_GUARDED_ROOTS)
                        continue
                    if alternative.kind == "other":''')
# Extend the single existing invocation engine, not a second body interpreter.
edit('            if callee.kind == "source_function"\n            else ()\n        )\n        function_bindings = tuple(\n            binding for binding in alternatives if binding.kind == "source_function"\n        )', '''            if callee.kind in {"source_function", "reconstructed_function", "source_closure"}
            else ()
        )
        function_bindings = tuple(
            binding for binding in alternatives
            if binding.kind in {"source_function", "reconstructed_function", "source_closure"}
        )''')
edit('        if scope_info is not self._module_scope_info and not self._active_module_function_stack:\n            return None', '''        source_code_call = any(
            binding.kind in {"reconstructed_function", "source_closure"}
            for binding in function_bindings
        )
        if (scope_info is not self._module_scope_info
                and not self._active_module_function_stack and not source_code_call):
            return None''')
edit('                    _DynamicImportFunctionSummary,\n                ]\n            ] = []', '                    _DynamicImportFunctionSummary,\n                    _DynamicImportBinding,\n                ]\n            ] = []')
edit('                if binding.kind == "source_function":\n                    identity = binding.origin_name\n                elif (', '''                if binding.kind in {"reconstructed_function", "source_closure"}:
                    origin = binding.code_origin
                    if (origin is None or self.source_context is None
                            or origin.context_identity != self.source_context.identity
                            or origin.source_module != self.module_name
                            or binding.globals_owner != self.module_name):
                        raise DynamicImportCollectionError(
                            f"{self.relative_path}:{node.lineno}: reconstructed code context is unresolved"
                        )
                    identity = origin.identity
                elif binding.kind == "source_function":
                    identity = binding.origin_name
                    if identity in self._invalidated_function_code:
                        raise DynamicImportCollectionError(
                            f"{self.relative_path}:{node.lineno}: source function code was mutated"
                        )
                elif (''')
edit('                summary = scanner._module_function_summaries.get(identity)\n                if summary is None:', '''                summary = (
                    _DynamicImportFunctionSummary(binding.code_origin.node, {})
                    if binding.kind in {"reconstructed_function", "source_closure"}
                    and binding.code_origin is not None
                    else scanner._module_function_summaries.get(identity)
                )
                if summary is None:''')
edit('                candidates.append((scanner, identity, summary))', '                candidates.append((scanner, identity, summary, binding))')
edit('                    self._active_module_environment or environment\n                    if scanner is self', '                    (self._active_module_environment or self._module_environment\n                     if source_code_call else self._active_module_environment or environment)\n                    if scanner is self')
edit('            for scanner, identity, summary in candidates:', '            for scanner, identity, summary, binding in candidates:')
edit('                previous_active_environment = scanner._active_module_environment\n                scanner._active_module_environment = branch_environment', '''                previous_active_environment = scanner._active_module_environment
                previous_builtins = scanner._active_code_builtins
                previous_code_depth = scanner._source_code_depth
                if binding.kind in {"reconstructed_function", "source_closure"}:
                    if not scanner._module_namespace_complete:
                        raise DynamicImportCollectionError(
                            f"{self.relative_path}:{node.lineno}: reconstructed globals have opaque writes"
                        )
                    scanner._source_code_depth += 1
                    scanner._active_code_builtins = binding.function_builtins
                scanner._active_module_environment = branch_environment''')
edit('                        if parameter_bindings is not None:\n                            invocation_state', '''                        if parameter_bindings is None and scanner._source_code_depth:
                            raise DynamicImportCollectionError(
                                f"{self.relative_path}:{node.lineno}: reconstructed arguments do not bind"
                            )
                        if parameter_bindings is not None:
                            invocation_state''')
edit('                            if repeated_invocation:\n                                # The active body', '''                            if repeated_invocation and scanner._source_code_depth:
                                raise DynamicImportCollectionError(
                                    f"{self.relative_path}:{node.lineno}: reconstructed recursion is unresolved"
                                )
                            if repeated_invocation:
                                # The active body''')
edit('                                        function,\n                                        {},\n                                        branch_environment,', '''                                        function,
                                        dict(zip(binding.closure_names, binding.source_arguments or (), strict=True))
                                        if binding.kind == "source_closure" else {},
                                        branch_environment,''')
edit('                                    if not _dynamic_function_has_unmodeled_implicit_dispatch(\n                                        function,\n                                        branch_environment,\n                                    ):\n                                        scanner._module_time_proven_scope_ids.add(id(function))', '''                                    implicit = _dynamic_function_has_unmodeled_implicit_dispatch(
                                        function, branch_environment
                                    )
                                    if implicit and scanner._source_code_depth:
                                        raise DynamicImportCollectionError(
                                            f"{self.relative_path}:{node.lineno}: reconstructed source body "
                                            "has opaque implicit dispatch"
                                        )
                                    if not implicit:
                                        scanner._module_time_proven_scope_ids.add(id(function))''')
edit('                    scanner._active_module_environment = previous_active_environment\n                    if pushed_target_module:', '''                    scanner._active_module_environment = previous_active_environment
                    scanner._active_code_builtins = previous_builtins
                    scanner._source_code_depth = previous_code_depth
                    if pushed_target_module:''')
edit('            if not source_method_call:\n                self._invalidate_source_class_effects(call_values)', '            if not source_method_call and not (\n                callee.kind == "callable" and callee.name == "types.FunctionType"\n            ):\n                self._invalidate_source_class_effects(call_values)')
edit('                self._reject_guarded_escape(value, target, "container storage")', '''                key_known, key_value = _dynamic_binding_literal_key_value(key)
                local_live_write = (
                    is_scope_mapping and base.globals_owner == self.module_name
                    and owner == self.module_name and key_known and isinstance(key_value, str)
                    and (self._module_execution_active or self._active_module_function_stack)
                )
                if not local_live_write:
                    self._reject_guarded_escape(value, target, "container storage")''')
edit('    if attribute == "__dict__" and binding.module_registry_origins:', '''    if binding.kind in {
        "source_function", "source_method", "source_code", "reconstructed_function", "source_closure"
    }:
        return _dynamic_unresolved_importer_binding(("source-executable-introspection",))
    if attribute == "__dict__" and binding.module_registry_origins:''')
edit('            if receiver.kind in {"source_function", "source_method"}:', '''            if receiver.kind in {"reconstructed_function", "source_closure", "source_code"}:
                raise DynamicImportCollectionError(
                    f"{self.relative_path}:{target.lineno}: reconstructed callable mutation is unsupported"
                )
            if receiver.kind in {"source_function", "source_method"}:''')
edit('''        if self._active_code_builtins is not None:
            return _dynamic_mapping_lookup(
                self._active_code_builtins, _dynamic_string_binding(name), default=_DYNAMIC_OTHER
            )
        if name == "__name__" and self.module_name is not None:
            return _dynamic_string_binding(self.module_name)''', '''        if name == "__name__" and self.module_name is not None:
            return _dynamic_string_binding(self.module_name)
        if name == "__builtins__" and self._active_code_builtins is not None:
            return _dynamic_builtin_dual_namespace_binding()
        if self._active_code_builtins is not None:
            return _dynamic_mapping_lookup(
                self._active_code_builtins, _dynamic_string_binding(name), default=_DYNAMIC_OTHER
            )''')
edit('''        if _is_guarded_importer_binding(binding) or _dynamic_has_source_execution(binding):
            raise DynamicImportCollectionError(''', '''        self._invalidate_source_function_code((binding,))
        if _is_guarded_importer_binding(binding) or _dynamic_has_source_execution(binding):
            raise DynamicImportCollectionError(''')
edit('''                if argument_bindings:
                    owner = self._module_namespace_owner(argument_bindings[0], scope_info)
                    if owner is not None:
                        key = (''', '''                if argument_bindings:
                    function_targets = tuple(
                        item for item in _dynamic_binding_nodes(argument_bindings[0])
                        if item.kind in {
                            "source_function", "source_method", "reconstructed_function", "source_closure"
                        }
                    )
                    if function_targets:
                        if _dynamic_has_source_execution(argument_bindings[0]):
                            raise DynamicImportCollectionError(
                                f"{self.relative_path}:{node.lineno}: reconstructed callable mutation is unsupported"
                            )
                        self._invalidate_source_function_code(function_targets)
                        return _DYNAMIC_NONE
                    owner = self._module_namespace_owner(argument_bindings[0], scope_info)
                    if owner is not None:
                        key = (''')
edit('''    def _invalidate_source_class_effects(
''', '''    def _invalidate_source_function_code(
        self, bindings: Iterable[_DynamicImportBinding],
    ) -> None:
        """Invalidate mutable function identities at any unsupported exposure or mutation."""
        self._invalidated_function_code.update(
            item.origin_name for binding in bindings for item in _dynamic_binding_nodes(binding)
            if item.kind in {"source_function", "source_method"} and item.origin_name is not None
        )

    def _invalidate_source_class_effects(
''')
edit('        self._source_code_depth = 0', '        self._source_code_depth = 0\n        self._source_code_opaque_effect = False')
edit('''        """Retain call-time namespace evidence for a module call the scanner cannot transfer."""
        if not (self._module_execution_active or self._active_module_function_stack):''', '''        """Retain call-time namespace evidence for a module call the scanner cannot transfer."""
        self._source_code_opaque_effect = True
        if not (self._module_execution_active or self._active_module_function_stack):''')
edit('''                    owner = self._module_namespace_owner(argument_bindings[0], scope_info)
                    if owner is not None:
                        key = (''', '''                    owner = self._module_namespace_owner(argument_bindings[0], scope_info)
                    if owner is None:
                        self._source_code_opaque_effect = True
                    if owner is not None:
                        key = (''')
edit('''            value = _dynamic_attribute_binding(base, node.attr)
            if self.source_bindings is not None:''', '''            if base.kind in {"unknown", "ambiguous", "object", "other"}:
                self._source_code_opaque_effect = True
            value = _dynamic_attribute_binding(base, node.attr)
            if self.source_bindings is not None:''')
edit('''                module_binding = argument_bindings[0]
                attribute_binding = argument_bindings[1]''', '''                module_binding = argument_bindings[0]
                if module_binding.kind in {"unknown", "ambiguous", "object", "other"}:
                    self._source_code_opaque_effect = True
                attribute_binding = argument_bindings[1]''')
edit('''            self._invalidate_unmodeled_source_mapping_inputs((receiver, value), environment)
            self._invalidate_source_class_effects((receiver, value))''', '''            self._source_code_opaque_effect = True
            self._invalidate_unmodeled_source_mapping_inputs((receiver, value), environment)
            self._invalidate_source_class_effects((receiver, value))''')
edit('''            self._reject_guarded_escape(base, target, "container mutation")
            self._reject_guarded_escape(value, target, "container storage")''', '''            self._source_code_opaque_effect = True
            self._reject_guarded_escape(base, target, "container mutation")
            self._reject_guarded_escape(value, target, "container storage")''')
edit('''            self._expression_binding(node.test, environment, pending, scope_info)
            runtime_type_checking_branch = _type_checking_runtime_branch(''', '''            condition = self._expression_binding(node.test, environment, pending, scope_info)
            if condition.kind in {"unknown", "ambiguous", "object", "other"} and not condition.literal_key_known:
                self._source_code_opaque_effect = True
            runtime_type_checking_branch = _type_checking_runtime_branch(''')
edit('''                    if not scanner._module_namespace_complete:
                        raise DynamicImportCollectionError(''', '''                    if scanner._source_code_opaque_effect:
                        raise DynamicImportCollectionError(
                            f"{self.relative_path}:{node.lineno}: reconstructed invocation crosses opaque source effects"
                        )
                    if not scanner._module_namespace_complete:
                        raise DynamicImportCollectionError(''')
edit('''        body_nodes = [] if isinstance(node, ast.Lambda) else node.body
        local_names, global_names, nonlocal_names = _scope_local_bindings(body_nodes)''', '''        declaration_only = not self._active_module_function_stack
        previous_opaque_effect = self._source_code_opaque_effect
        body_nodes = [] if isinstance(node, ast.Lambda) else node.body
        local_names, global_names, nonlocal_names = _scope_local_bindings(body_nodes)''')
edit('''                self._scan_type_parameter_fields(scope, child_parent, pending)

    def _scan_class(''', '''                self._scan_type_parameter_fields(scope, child_parent, pending)
        if declaration_only:
            # An uninvoked declaration's unknown effects do not mutate the module.
            # Its own later reconstructed call still sees effects earlier in that body.
            self._source_code_opaque_effect = previous_opaque_effect

    def _scan_class(''')
# New bridge methods own representation/binding only; body execution stays above.
anchor = '    def _source_function_scanner_for(\n'
methods = '''    def _selected_code_origin(
        self, function: ast.FunctionDef | ast.AsyncFunctionDef, node: ast.AST,
        *, free_variables: tuple[str, ...] = (),
    ) -> _DynamicSourceCodeOrigin:
        """Bind a plain source body to the invocation-local selected byte context."""
        member = next((item for item in self.source_context.members
                       if item.path == self.source_path), None) if self.source_context else None
        if (member is None or self.module_name is None
                or not isinstance(function, ast.FunctionDef) or function.decorator_list
                or getattr(function, "type_params", ())
                or not any(item is function for item in ast.walk(member.tree))
                or any(isinstance(item, ast.Name) and item.id in {"__class__", "super"}
                       for item in ast.walk(function))):
            raise DynamicImportCollectionError(
                f"{self.relative_path}:{getattr(node, 'lineno', 1)}: selected code origin is unsupported"
            )
        identity = f"{self.relative_path}:{function.lineno}:{function.col_offset}"
        return _DynamicSourceCodeOrigin(
            identity, self.source_context.identity, member.content_sha256,
            self.module_name, self.relative_path, function, free_variables,
        )

    def _capture_source_code(
        self, binding: _DynamicImportBinding, node: ast.AST,
    ) -> _DynamicImportBinding:
        """Freeze code at capture; subsequent function writes invalidate only later lookups."""
        alternatives = binding.items if binding.kind == "union" else (binding,)
        captures: list[_DynamicImportBinding] = []
        for target in alternatives or ():
            if target.origin_name in self._invalidated_function_code:
                raise DynamicImportCollectionError(
                    f"{self.relative_path}:{getattr(node, 'lineno', 1)}: source function code was mutated"
                )
            if target.kind == "source_function":
                summary = self._module_function_summaries.get(target.origin_name or "")
                origin = self._selected_code_origin(summary.node, node) if summary else None
            elif target.kind == "source_method":
                origin = target.code_origin
            else:
                origin = None
            if origin is None or origin.free_variables:
                raise DynamicImportCollectionError(
                    f"{self.relative_path}:{getattr(node, 'lineno', 1)}: code capture lacks a "
                    "plain selected function with no free cells"
                )
            captures.append(_DynamicImportBinding("source_code", code_origin=origin))
        if not captures:
            raise DynamicImportCollectionError(f"{self.relative_path}: code alternatives are unresolved")
        return _dynamic_union_binding(captures)

    def _construct_source_function(
        self, node: ast.Call, arguments: Sequence[_DynamicImportBinding],
    ) -> _DynamicImportBinding:
        """Admit selected code with same-origin live globals and fixed native builtins."""
        if (len(node.args) != 2 or node.keywords or len(arguments) != 2
                or any(isinstance(item, ast.Starred) for item in node.args)):
            raise DynamicImportCollectionError(
                f"{self.relative_path}:{node.lineno}: FunctionType defaults, closure or call shape unsupported"
            )
        if self._source_code_opaque_effect:
            raise DynamicImportCollectionError(
                f"{self.relative_path}:{node.lineno}: FunctionType construction crosses opaque source effects"
            )
        code, namespace = arguments
        if (namespace.kind != "mapping" or namespace.origin_name != "scope:globals"
                or namespace.globals_owner != self.module_name or self.module_name is None
                or not self._module_namespace_complete):
            raise DynamicImportCollectionError(
                f"{self.relative_path}:{node.lineno}: FunctionType requires same-origin live globals"
            )
        effects = dict(self.source_context.module_namespace_effects or ()) if self.source_context else {}
        if "builtins" in effects or "types" in effects or self.module_name in effects:
            raise DynamicImportCollectionError(
                f"{self.relative_path}:{node.lineno}: FunctionType namespace has cross-module effects"
            )
        live = self._active_module_environment or self._module_environment
        native_builtins = live.get("__builtins__")
        if native_builtins is not None and not (
            native_builtins.kind in {"module", "namespace"} and native_builtins.name == "builtins"
        ):
            raise DynamicImportCollectionError(
                f"{self.relative_path}:{node.lineno}: FunctionType construction builtins are unsupported"
            )
        builtins = _dynamic_builtin_namespace_binding()
        alternatives = code.items if code.kind == "union" else (code,)
        callables: list[_DynamicImportBinding] = []
        for value in alternatives or ():
            origin = value.code_origin
            if (value.kind != "source_code" or origin is None or self.source_context is None
                    or origin.context_identity != self.source_context.identity
                    or origin.source_module != self.module_name or origin.free_variables):
                raise DynamicImportCollectionError(
                    f"{self.relative_path}:{node.lineno}: FunctionType code origin is unresolved"
                )
            callables.append(_DynamicImportBinding(
                "reconstructed_function", code_origin=origin, globals_owner=self.module_name,
                function_builtins=builtins,
            ))
        if not callables:
            raise DynamicImportCollectionError(f"{self.relative_path}: FunctionType has no selected code")
        return _dynamic_union_binding(callables)

'''
edit(anchor, methods + anchor)
postimage = PACKET / 'candidate/policy-engine/tools/quality/validation/decomposition_preflight.py'
postimage.write_text(source)
(PACKET / 'candidate/policy-engine/pyproject.toml').write_text('# RAW fixture import-root sentinel; not part of canonical patch.\n')
print(hashlib.sha256(source.encode()).hexdigest())
