"""Check original cycle assertions are retained; stdlib AST only."""
import ast
import json
from pathlib import Path

repo = Path.cwd()
raw = repo / "LOCAL/raw/e02-execution-20261027/runtime-prep/R165-basis-test-fixture-repair-r1"
old = repo / "policy-engine/tests/unit/runtime/quality/test_generation_cycle.py"
new = raw / "postimages/policy-engine/tests/unit/runtime/quality/test_generation_cycle.py"
names = (
    "test_n7_typed_gap_persists_costed_plan_before_authority_refusal",
    "test_conflicting_n7_family_declaration_is_costed_refusal",
    "test_n7_grounding_gap_with_unestablished_basis_survives_fresh_reader",
    "test_n7_blocked_candidate_plan_does_not_cost_or_dispatch",
)

def functions(path):
    return {
        node.name: node
        for node in ast.parse(path.read_text()).body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    }

before, after = functions(old), functions(new)
rows = []
for name in names:
    left = [ast.dump(node.test, include_attributes=False) for node in ast.walk(before[name]) if isinstance(node, ast.Assert)]
    right = [ast.dump(node.test, include_attributes=False) for node in ast.walk(after[name]) if isinstance(node, ast.Assert)]
    missing = [item for item in left if item not in right]
    rows.append({"selector": name, "assertions_before": len(left), "assertions_after": len(right), "missing_count": len(missing)})
    if missing:
        raise SystemExit(f"assertion predicate removed: {name}")
result = {"scope": "four catalog-dependent test functions; AST assert predicates only", "results": rows}
print(json.dumps(result, indent=2))
