from pathlib import Path

root = Path('LOCAL/raw/e02-execution-20261027/repairs/C40-r2/postimages/policy-engine')

def edit(path, old, new):
    p = root / path
    s = p.read_text()
    assert s.count(old) == 1, (path, s.count(old))
    p.write_text(s.replace(old, new))

edit('src/polisyos/scientist/methods/research_dag/projections.py', '''        if unknown:
            raise ValueError(f"workflow projection records absent from selected spec: {unknown}")
        projection_aliases = [item.alias for item in workflow_spec.nodes if item.alias in record_by_alias]
''', '''        if unknown:
            raise ValueError(f"workflow projection records absent from selected spec: {unknown}")
        for alias, record in record_by_alias.items():
            if str(getattr(record, "node_id", "")) != str(spec_by_alias[alias].node_id):
                raise ValueError(f"workflow projection component identity mismatch for {alias}")
        omitted = sorted(set(spec_by_alias) - set(record_by_alias))
        builder.metadata["record_coverage"] = "partial" if omitted else "complete"
        builder.metadata["omitted_record_aliases"] = omitted
        projection_aliases = [
            item.alias for item in workflow_spec.nodes if item.alias in record_by_alias
        ]
''')
edit('src/polisyos/scientist/methods/research_dag/projections.py', '''        builder.metadata["dependency_basis"] = "selected_workflow_spec"
''', '''        # Scheduling prerequisites are not an observed or verified read set.
        builder.metadata["dependency_basis"] = "selected_workflow_spec_prerequisites_only"
        builder.metadata["actual_consumed_basis"] = "not_established"
''')
edit('src/polisyos/scientist/methods/research_dag/persistence.py', '''        canon_spec=CanonSpec(forbid_floats=False),
    )
''', '''        canon_spec=CanonSpec(forbid_floats=False),
        return_selected_profile=True,
    )
''')
edit('tests/unit/scientist/methods/research_dag/test_projections.py', '''from polisyos.core.artifacts.manifest import ArtifactRef
''', '''import pytest

from polisyos.core.artifacts.manifest import ArtifactRef
''')
edit('tests/unit/scientist/methods/research_dag/test_projections.py', '''from polisyos.scientist.methods.research_dag.models import ResearchNodeType
''', '''from polisyos.scientist.methods.research_dag.invalidation import (
    SourceInvalidationEvent,
    propagate_source_invalidation,
)
from polisyos.scientist.methods.research_dag.models import (
    ResearchDAGEdge,
    ResearchEdgeType,
    ResearchNodeType,
)
''')
p=root/'tests/unit/scientist/methods/research_dag/test_projections.py'
s=p.read_text(); start=s.index('def test_workflow_projection_uses_selected_spec_not_record_order()'); end=s.index('\ndef test_tool_projection_redacts_prompt_injection_result()',start)
s=s[:start]+'''def test_workflow_projection_invalidation_closure_uses_spec_not_record_order() -> None:
    source_ref = _ref("2")
    sibling_ref = _ref("3")
    source = NodeRunRecord(
        alias="source",
        node_id="scientist.source@1.0.0",
        status="ok",
        duration_ms=1,
        artifacts=[source_ref],
    )
    dependent = NodeRunRecord(
        alias="dependent", node_id="scientist.dependent@1.0.0", status="ok", duration_ms=1
    )
    sibling = NodeRunRecord(
        alias="independent_sibling",
        node_id="scientist.sibling@1.0.0",
        status="ok",
        duration_ms=1,
        artifacts=[sibling_ref],
    )
    spec = WorkflowSpec(
        workflow_id="scientist_policy_design",
        nodes=[
            NodeInvocation(alias="source", node_id=source.node_id),
            NodeInvocation(alias="dependent", node_id=dependent.node_id, depends_on=["source"]),
            NodeInvocation(alias="independent_sibling", node_id=sibling.node_id),
        ],
    )
    event = SourceInvalidationEvent(
        event_id="source_changed",
        source_ref=source_ref,
        invalidation_type="stale",
        reason="The source selected for this witness changed.",
    )
    sibling_event = SourceInvalidationEvent(
        event_id="sibling_changed",
        source_ref=sibling_ref,
        invalidation_type="stale",
        reason="The independent witness changed.",
    )
    expected = {
        "scientist_policy_design:execution:source",
        "scientist_policy_design:execution:dependent",
    }
    independent = "scientist_policy_design:execution:independent_sibling"
    for records in ([source, dependent, sibling], [sibling, source, dependent]):
        dag = project_workflow_execution_to_research_dag(
            run_id="run_1", workflow_id=spec.workflow_id, records=records, workflow_spec=spec
        )
        impact = propagate_source_invalidation(dag, event)
        assert set(impact.affected_node_ids) == expected
        assert propagate_source_invalidation(dag, sibling_event).affected_node_ids == [independent]
        assert dag.metadata["record_coverage"] == "complete"
        assert dag.metadata["actual_consumed_basis"] == "not_established"

    # An additional edge defeats the old metadata-filtering oracle while retaining
    # all of its markers. The real propagation owner must see its consequence.
    altered = dag.model_copy(
        update={
            "edges": [
                *dag.edges,
                ResearchDAGEdge(
                    source_node_id="scientist_policy_design:execution:dependent",
                    target_node_id=independent,
                    edge_type=ResearchEdgeType.DEPENDS_ON,
                    metadata={"basis": "legacy_record_order"},
                ),
            ]
        }
    )
    assert independent in propagate_source_invalidation(altered, event).affected_node_ids


def test_workflow_projection_rejects_cross_component_record() -> None:
    spec = WorkflowSpec(
        workflow_id="scientist_policy_design",
        nodes=[NodeInvocation(alias="step", node_id="scientist.expected@1.0.0")],
    )
    record = NodeRunRecord(
        alias="step", node_id="scientist.other@1.0.0", status="ok", duration_ms=1
    )
    with pytest.raises(ValueError, match="component identity mismatch"):
        project_workflow_execution_to_research_dag(
            run_id="run_1", workflow_id=spec.workflow_id, records=[record], workflow_spec=spec
        )


def test_workflow_projection_declares_omitted_independent_record() -> None:
    spec = WorkflowSpec(
        workflow_id="scientist_policy_design",
        nodes=[
            NodeInvocation(alias="present", node_id="scientist.present@1.0.0"),
            NodeInvocation(alias="omitted", node_id="scientist.omitted@1.0.0"),
        ],
    )
    record = NodeRunRecord(
        alias="present", node_id="scientist.present@1.0.0", status="ok", duration_ms=1
    )
    dag = project_workflow_execution_to_research_dag(
        run_id="run_1", workflow_id=spec.workflow_id, records=[record], workflow_spec=spec
    )
    assert dag.metadata["record_coverage"] == "partial"
    assert dag.metadata["omitted_record_aliases"] == ["omitted"]
    assert all(node.metadata.get("alias") != "omitted" for node in dag.nodes)

'''+s[end:];p.write_text(s)
edit('tests/unit/scientist/methods/research_dag/test_invalidation.py', '''def _claim(claim_id: str = "claim_1") -> ClaimRecord:
''', '''def _claim(claim_id: str = "claim_1", *, source_ref: ArtifactRef | None = None) -> ClaimRecord:
''')
edit('tests/unit/scientist/methods/research_dag/test_invalidation.py', '''        evidence_refs=[_ref("1")],
''', '''        evidence_refs=[source_ref or _ref("1")],
''')
edit('tests/unit/scientist/methods/research_dag/test_invalidation.py', '''    claims = [_claim("claim_a"), _claim("claim_b"), _claim("claim_independent")]
''', '''    claims = [
        _claim("claim_a"),
        _claim("claim_b"),
        _claim("claim_independent", source_ref=_ref("2")),
    ]
''')
edit('tests/unit/scientist/methods/research_dag/test_invalidation.py', '''    event = SourceInvalidationEvent(
        event_id="source_invalid_false_target",
        source_ref=common_ref,
        invalidation_type="stale",
        affected_node_ids=[independent.node_id],
        affected_claim_ids=["claim_independent"],
        reason="Caller selected an unrelated present sibling.",
    )

    with pytest.raises(ValueError, match="outside the source-derived closure"):
        propagate_source_invalidation(dag, event)
''', '''    for node_ids, claim_ids in (
        ([independent.node_id], []),
        ([], ["claim_independent"]),
    ):
        event = SourceInvalidationEvent(
            event_id="source_invalid_false_target",
            source_ref=common_ref,
            invalidation_type="stale",
            affected_node_ids=node_ids,
            affected_claim_ids=claim_ids,
            reason="Caller selected an unrelated present sibling.",
        )
        with pytest.raises(ValueError, match="outside the source-derived closure"):
            propagate_source_invalidation(dag, event)
''')
print('scratch edits applied')
