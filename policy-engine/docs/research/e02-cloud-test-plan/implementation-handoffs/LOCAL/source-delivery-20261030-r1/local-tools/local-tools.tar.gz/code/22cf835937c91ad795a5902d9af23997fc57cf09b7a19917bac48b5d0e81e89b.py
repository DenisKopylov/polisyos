"""Bounded pinned-tree source and generated-surface inventory; no product imports."""
from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path
import subprocess

REV = "4ccfa564f925d048f3c46dc0069ffcbfe028a13a"
raw = subprocess.check_output(["git", "ls-tree", "-r", "--name-only", "-z", REV, "--", "policy-engine"])
paths = [row.decode() for row in raw.split(b"\0") if row]
groups = {
    "src_python": [p for p in paths if p.startswith("policy-engine/src/") and p.endswith(".py")],
    "tests_python": [p for p in paths if p.startswith("policy-engine/tests/") and p.endswith(".py")],
    "frontend_typescript": [p for p in paths if p.startswith(("policy-engine/apps/", "policy-engine/packages/")) and p.endswith((".ts", ".tsx"))],
    "schemas_json": [p for p in paths if p.startswith("policy-engine/schemas/") and p.endswith(".json")],
}
results = {}
for group, members in groups.items():
    found = []
    for start in range(0, len(members), 400):
        selected = members[start : start + 400]
        command = ["git", "grep", "-l", "-F", "AcquisitionPlannerReport", REV, "--", *selected]
        result = subprocess.run(command, capture_output=True, text=True)
        if result.returncode not in (0, 1):
            raise SystemExit(result.stderr)
        found.extend(line.split(":", 1)[1] for line in result.stdout.splitlines())
    results[group] = {"file_type": group, "tracked_files_at_revision": len(members), "literal_match_paths": sorted(found)}

openapi_path = "policy-engine/schemas/runtime_api_v1.openapi.json"
openapi_raw = subprocess.check_output(["git", "show", f"{REV}:{openapi_path}"])
openapi = json.loads(openapi_raw)
needles = ("AcquisitionPlannerReport", "basis_limitation_code", "acquisition_routing_report")
occurrences = {key: [] for key in needles}
def walk(value: object, path: str) -> None:
    if isinstance(value, dict):
        for key, item in value.items():
            pointer = path + "/" + str(key).replace("~", "~0").replace("/", "~1")
            for needle in needles:
                if needle in str(key): occurrences[needle].append(pointer + "#key")
            walk(item, pointer)
    elif isinstance(value, list):
        for index, item in enumerate(value): walk(item, path + "/" + str(index))
    elif isinstance(value, str):
        for needle in needles:
            if needle in value: occurrences[needle].append(path + "#value")
walk(openapi, "")

frozen_path = "policy-engine/src/polisyos/runtime/quality/_generation_cycle_history_schema.py"
frozen_raw = subprocess.check_output(["git", "show", f"{REV}:{frozen_path}"])
source = ast.parse(frozen_raw)
constants = {}
for node in source.body:
    if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
        if node.targets[0].id in ("_FROZEN_SCHEMA_JSON", "_FROZEN_SCHEMA_V3_JSON"):
            constants[node.targets[0].id] = ast.literal_eval(node.value)
    if isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
        if node.target.id in ("_FROZEN_SCHEMA_JSON", "_FROZEN_SCHEMA_V3_JSON"):
            constants[node.target.id] = ast.literal_eval(node.value)
owner = "polisyos.runtime.quality.acquisition_planner.AcquisitionPlannerReport"
frozen = {}
for name, text in constants.items():
    graphs = json.loads(text)
    if name == "_FROZEN_SCHEMA_V3_JSON": graphs = {"v3": graphs}
    for version, graph in graphs.items():
        shape = graph.get(owner)
        if shape:
            frozen[version] = {"declared_fields": shape.get("declared_fields"), "basis_limitation_code_vocabulary": shape.get("field_vocabulary", {}).get("basis_limitation_code"), "status_vocabulary": shape.get("field_vocabulary", {}).get("status")}
print(json.dumps({
    "revision": REV,
    "scope": "tracked source and generated files only at the pinned tree; name references, not dynamic consumer discovery",
    "literal_census": results,
    "openapi": {"path": openapi_path, "sha256": hashlib.sha256(openapi_raw).hexdigest(), "documents": 1, "component_schema_count": len(openapi.get("components", {}).get("schemas", {})), "occurrences": occurrences},
    "frozen_history": {"path": frozen_path, "sha256": hashlib.sha256(frozen_raw).hexdigest(), "owners": frozen},
    "limitations": "No imports, OpenAPI export, client generation, runtime routes, external deployments, hidden consumers or backend tests were inspected or executed. Generated-family owners must run their declared drift gates."
}, indent=2, sort_keys=True))
