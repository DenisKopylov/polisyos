from pathlib import Path
import subprocess, hashlib, difflib, json, ast
ROOT=Path.cwd()
OUT=ROOT/'LOCAL/raw/e02-execution-20261027/repairs/C38-r3'
BASE='cfdb1ac1b7a44a782ec8e13b5f0ed9277beed65c'
TREE='4396ab7ed42ebcd0aad742ac1f402ffcbccd0c65'
# Preserve the cloud's separate v2 reader schema; no v2 authority writer enabled.
p='policy-engine/schemas/runtime_quality/evidence_authority_envelope_v2.schema.json'
f=OUT/'postimages'/p
f.parent.mkdir(parents=True,exist_ok=True)
f.write_bytes(subprocess.check_output(['git','show',f'{TREE}:{p}']))
paths=sorted(str(f.relative_to(OUT/'postimages')) for f in (OUT/'postimages').rglob('*') if f.is_file())
records=[]
patches={BASE:[],TREE:[]}
for p in paths:
    post=(OUT/'postimages'/p).read_bytes()
    rec={'path':p,'postimage_sha256':hashlib.sha256(post).hexdigest(),'postimage_bytes':len(post)}
    for basis in (BASE,TREE):
        old=subprocess.run(['git','show',f'{basis}:{p}'],capture_output=True)
        pre=old.stdout if old.returncode==0 else b''
        rec[basis]={'preimage_sha256':hashlib.sha256(pre).hexdigest() if old.returncode==0 else None,'preimage_bytes':len(pre) if old.returncode==0 else None}
        diff=''.join(difflib.unified_diff(pre.decode().splitlines(True),post.decode().splitlines(True),fromfile=f'a/{p}' if old.returncode==0 else '/dev/null',tofile=f'b/{p}'))
        patches[basis].append(diff)
    if p.endswith('.py'):
        ast.parse(post,filename=p)
    records.append(rec)
(OUT/'cumulative-local.patch').write_text(''.join(patches[BASE]))
(OUT/'repair-vs-cloud.patch').write_text(''.join(patches[TREE]))
(OUT/'manifest.json').write_text(json.dumps({'local_base':BASE,'cloud_candidate_tree':TREE,'canonical_source_written':False,'paths':records},indent=2)+'\n')
ruff=[]
for p in paths:
    if not p.endswith('.py'): continue
    data=(OUT/'postimages'/p).read_bytes()
    r=subprocess.run([str(ROOT/'policy-engine/.venv/bin/python'),'-m','ruff','check','--stdin-filename',str(ROOT/p),'-'],input=data,cwd=ROOT/'policy-engine',capture_output=True)
    token=Path(p).stem
    (OUT/f'ruff-{token}.stdout').write_bytes(r.stdout)
    (OUT/f'ruff-{token}.stderr').write_bytes(r.stderr)
    ruff.append({'logical_path':p,'command':['policy-engine/.venv/bin/python','-m','ruff','check','--stdin-filename',str(ROOT/p),'-'],'exit_code':r.returncode,'stdout':f'ruff-{token}.stdout','stderr':f'ruff-{token}.stderr'})
check=subprocess.run(['git','apply','--check',str(OUT/'cumulative-local.patch')],capture_output=True)
(OUT/'scratch-apply-check.stdout').write_bytes(check.stdout)
(OUT/'scratch-apply-check.stderr').write_bytes(check.stderr)
(OUT/'verification.json').write_text(json.dumps({'ast':'PASS','ruff':ruff,'local_git_apply_check_exit':check.returncode,'tests':'UNRUN by assigned scratch-only lane','canonical_index_written':False},indent=2)+'\n')
print(json.dumps({'ast':'PASS','ruff':[(r['logical_path'],r['exit_code']) for r in ruff],'apply_check':check.returncode,'paths':len(paths)}))
