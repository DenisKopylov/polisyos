const fs = require('node:fs');
const path = require('node:path');
const ts = require(process.cwd() + '/policy-engine/apps/runtime-dashboard/node_modules/typescript/lib/typescript.js');
const base = process.cwd() + '/LOCAL/raw/e02-execution-20261027/repairs/C41-r8-companions';
const post = base + '/postimages/policy-engine/apps/runtime-dashboard/src';
function walk(p) {return fs.readdirSync(p,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(p,e.name)):[path.join(p,e.name)]);}
const reports=[];
for(const p of walk(post).filter(p=>/\.tsx?$/.test(p))) {
 const source=fs.readFileSync(p,'utf8');
 const tree=ts.createSourceFile(p,source,ts.ScriptTarget.Latest,true,p.endsWith('.tsx')?ts.ScriptKind.TSX:ts.ScriptKind.TS);
 const errors=tree.parseDiagnostics.map(d=>({code:d.code,message:ts.flattenDiagnosticMessageText(d.messageText,' '),start:d.start}));
 reports.push({path:path.relative(post,p),parseDiagnostics:errors});
}
const added=['jointParentTitle','jointParentAuthority','jointParentStatus','jointParentValue','jointParentSelection','jointParentInteraction','jointParentOrders','jointParentResidual','ownerJoinStatus'];
const keys={};
for(const lang of ['en','uk','ru']) {
 const after=JSON.parse(fs.readFileSync(path.join(post,'shared/i18n/locales',lang+'.json'),'utf8'));
 const before=JSON.parse(fs.readFileSync(path.join(base,'preimages/policy-engine/apps/runtime-dashboard/src/shared/i18n/locales',lang+'.json'),'utf8'));
 const a=after.pages.runs.genericCycleSimulation;const b=before.pages.runs.genericCycleSimulation;
 const allAdded=added.every(k=>Object.hasOwn(a,k));
 const placeholders=Object.fromEntries(added.map(k=>[k,(a[k].match(/\{[A-Za-z_][A-Za-z0-9_]*\}/g)||[]).sort()]));
 for(const key of added) delete a[key];
 keys[lang]={onlyExpectedKeys:JSON.stringify(a)===JSON.stringify(b),allAdded,placeholders};
}
const placeholderParity=['uk','ru'].every(lang=>JSON.stringify(keys[lang].placeholders)===JSON.stringify(keys.en.placeholders));
const result={kind:'TypeScript parser syntax only; no module execution or semantic typecheck',files:reports,localeJsonSyntaxAndSurgicalFields:keys,placeholderParity};
fs.writeFileSync(base+'/static-check.json',JSON.stringify(result,null,2)+'\n');
const errors=reports.filter(r=>r.parseDiagnostics.length);console.log('TypeScript parsed',reports.length,'errors',errors.length,'locale comparison',JSON.stringify(keys));
if(errors.length||!placeholderParity||Object.values(keys).some(v=>!v.onlyExpectedKeys||!v.allAdded))process.exitCode=1;
