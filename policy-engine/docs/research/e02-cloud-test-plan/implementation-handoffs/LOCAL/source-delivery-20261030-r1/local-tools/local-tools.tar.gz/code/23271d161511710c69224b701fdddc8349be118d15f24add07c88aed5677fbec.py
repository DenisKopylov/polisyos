"""Read only the two retained synthetic fixture failures; stdlib, no product imports."""
from pathlib import Path
from fractions import Fraction
import ast,hashlib,io,json,struct,xml.etree.ElementTree as E,zipfile
R=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos');H=Path(__file__).resolve().parent
D=R/'policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1/c48-compiler-comparison-components-r2-20261028'
P=D/'basetemp/test_ex_ante_rank_comparison_d0/b/cas/artifacts/sha256';sha=lambda data:hashlib.sha256(data).hexdigest()
reads=[]
def read(path):
 data=path.read_bytes();reads.append({'path':str(path.relative_to(R)),'sha256':sha(data),'bytes':len(data)});return data
def blob(digest):
 digest=digest.removeprefix('sha256:');return read(P/digest[:2]/digest[2:4]/(digest+'.blob'))
xml=read(D/'pytest.xml');tests=list(E.fromstring(xml).iter('testcase'));failures=[{'name':t.attrib['name'],'text':t.find('failure').text} for t in tests if t.find('failure') is not None];assert len(tests)==117 and len(failures)==2
capture=json.loads(blob('ca862f7fd296e08c0a7b3d7c1018af14cf5900f458990c2e8147e3bc74da7f7a'));snapshot=json.loads(blob(capture['pre_dispatch_state_ref']['artifact_id']));npz=blob(snapshot['state_ref']['artifact_id']);assert sha(npz)==snapshot['checksum_sha256'];arrays={}
with zipfile.ZipFile(io.BytesIO(npz)) as z:
 assert set(z.namelist())=={'baseline.npy','scenario.npy'}
 for name in z.namelist():
  entry=z.read(name);assert entry[:8]==b'\x93NUMPY\x01\x00';n=struct.unpack('<H',entry[8:10])[0];header=ast.literal_eval(entry[10:10+n].decode());assert header=={'descr':'<f4','fortran_order':False,'shape':(3,)};arrays[name[:-4]]=[x[0] for x in struct.iter_unpack('<f',entry[10+n:])]
output=json.loads(blob('6d8fbd453302c4b6aa35f249377fe642cffb1c70960e018492e4bada9fc8cc6a'));value=float(output['value']['repr']);differences=[Fraction(right)-Fraction(left) for left,right in zip(arrays['baseline'],arrays['scenario'],strict=True)];mean=sum(differences,Fraction())/len(differences)
assert mean==Fraction(2,3) and Fraction(value)!=mean
out={'source_commit':'d9397c7c0458ec2980fa58115c5ee597eb58dbc8','complete_pytest_xml_denominator':len(tests),'failures':failures,'selected_retained_rows':arrays,'selected_capture_dtypes':[(s['slot_id'],s['dtype']) for s in capture['slots']],'selected_output':output,'exact_mean':{'numerator':mean.numerator,'denominator':mean.denominator},'float_output_is_exact_mean':Fraction(value)==mean,'diagnosis':'Actual arrays/output are coherent; the positive-fixture expectation is outside the existing exact-float law profile. No product tolerance change is proposed.','reads':reads,'runtime_by_author':'UNRUN; read-only retained-artifact and stdlib arithmetic inspection'}
(H/'failure-evidence.json').write_text(json.dumps(out,indent=2)+'\n');print({'tests':len(tests),'failed':len(failures),'rows':arrays,'exact_mean':str(mean),'actual_output':value,'evidence_sha256':sha((H/'failure-evidence.json').read_bytes())})
