from pathlib import Path
import subprocess
ROOT=Path.cwd(); OUT=ROOT/'LOCAL/raw/e02-execution-20261027/repairs/C38-r4-report-tests-r1'
BASE='caa91a64d7d6afc4310186ba5fadbac2008dddab'
p='policy-engine/tests/unit/runtime/quality/test_runtime_quality_report_owner_contract.py'
s=subprocess.check_output(['git','show',f'{BASE}:{p}']).decode()
s=s.replace('from typing import Any','from typing import Any, Literal',1)
s=s.replace('''    closure_refs: dict[str, str] | None = None,
) -> tuple[FileSystemCAS, Any, dict[str, Any], dict[str, Any]]:
''','''    closure_refs: dict[str, str] | None = None,
    authority_role: Literal["runtime_blocker", "producer_authority"] = "runtime_blocker",
) -> tuple[FileSystemCAS, Any, dict[str, Any], dict[str, Any]]:
    """Persist real CAS ownership as blocked evidence by default.

    A producer claim is used only by explicit refusal probes; this fixture never
    establishes complete same-input purpose admission or issues a verifier token.
    """
''',1)
s=s.replace('''        authority_role="producer_authority",
        provenance_kind="runtime_emitted",
''','''        authority_role=authority_role,
        provenance_kind="runtime_emitted" if authority_role == "producer_authority" else "runtime_blocker",
''',1)
s=s.replace('''        blocking_status="non_blocking",
''','''        blocking_status="non_blocking" if authority_role == "producer_authority" else "blocking",
''',1)
s=s.replace('"""Build the fixture closure from the current owner scope and complete inputs."""','"""Build declared writer metadata; no complete input-purpose admission is claimed."""',1)
# Reentry's independently rebuilt expected context must describe the same
# non-authorizing stored report; none of the actual CAS/input checks is skipped.
s=s.replace('''        "authority_role": "producer_authority",
        "provenance_kind": "runtime_emitted",
''','''        "authority_role": "runtime_blocker",
        "provenance_kind": "runtime_blocker",
''',1)
s=s.replace('''        "blocking_status": "non_blocking",
''','''        "blocking_status": "blocking",
''',1)
needle='''def test_selected_report_cas_is_content_bound_before_scorecard_authority(
    tmp_path: Path,
) -> None:
'''
assert needle in s
s=s.replace(needle,needle+'''    """CAS ownership/content may verify for blocked evidence; authority remains refused."""
''',1)
needle='''    assert "hds_borrowed_authority_envelope" not in {gate["code"] for gate in gates}
'''
assert needle in s
s=s.replace(needle,needle+'''    assert envelope["authority_role"] == "runtime_blocker"
    assert any(gate["status"] == "fail" and gate["blocking"] for gate in gates)
''',1)
s+='''\n\ndef test_public_authority_refusal_and_actual_cas_corruption_are_separate_planes(
    tmp_path: Path,
) -> None:
    """A public missing-input-owner refusal is never reported as verified CAS data."""
    from polisyos.runtime.quality.authority import AuthorityEnvelopeError, assert_runtime_emitted

    cases = []
    for role in ("runtime_blocker", "producer_authority"):
        store, result, report, envelope = _persist_report(
            tmp_path, report_key="fabric_retrieval_trace", run_suffix=f"planes-{role}",
            payload={"schema_version": "1.0", "status": "pass", "claims": []},
            authority_role=role,
        )
        fresh = FileSystemCAS(tmp_path / f"cas-planes-{role}").for_tenant("tenant-1", cell_id="cell-a")
        args = dict(
            artifact_store=fresh, selected_ref=result.cas_ref,
            runtime_ref=str(result.cas_ref.artifact_id), report_key="fabric_retrieval_trace",
            ref_key="fabric_retrieval_trace_ref", report=report, envelope=envelope,
        )
        assert fresh.verify(result.cas_ref).ok
        before = {str(issue["code"]) for issue in runtime_quality_report_cas_admission_issues(**args)}
        if role == "runtime_blocker":
            assert before == set()  # Ownership/read result, explicitly not authority.
        else:
            assert before == {"same_input_closure_owner_not_established"}
        with pytest.raises(AuthorityEnvelopeError):
            assert_runtime_emitted(envelope)
        cases.append((role, store, result, fresh, args))
    for role, store, result, fresh, args in cases:
        blob = store._paths(result.cas_ref.artifact_id)[0]
        blob.write_bytes(blob.read_bytes() + b" ")
        assert not fresh.verify(result.cas_ref).ok
        after = {str(issue["code"]) for issue in runtime_quality_report_cas_admission_issues(**args)}
        if role == "runtime_blocker":
            assert after == {"runtime_quality_selected_cas_resolution_failed"}
        else:
            # The public authority guard deliberately dominates. Independent
            # actual Core verification above proves this is corrupt, not empty
            # or owner-verified, even though the public refusal stays unchanged.
            assert after == {"same_input_closure_owner_not_established"}
'''
f=OUT/'postimages'/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(s)
p='policy-engine/tests/unit/runtime/quality/test_closure_authority_withdrawal.py'
s=(ROOT/'LOCAL/raw/e02-execution-20261027/repairs/C38-r4/postimages'/p).read_text()
needle='''            run_suffix="c38-withdrawal",
'''
assert needle in s
s=s.replace(needle,needle+'''            authority_role="producer_authority",  # Explicit legacy-claim refusal probe.
''',1)
f=OUT/'postimages'/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(s)
print('Prepared report-owner tests-only purpose-plane migration; all r4 source bytes untouched.')
