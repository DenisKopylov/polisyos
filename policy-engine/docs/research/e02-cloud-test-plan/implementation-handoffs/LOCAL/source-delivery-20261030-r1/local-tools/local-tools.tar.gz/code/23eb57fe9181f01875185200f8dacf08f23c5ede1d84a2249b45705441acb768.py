from __future__ import annotations

import difflib
import hashlib
import json
import subprocess
from pathlib import Path

root = Path.cwd()
s = root / 'LOCAL/raw/e02-execution-20261027/repairs/C48-r5'

def digest(value: bytes | None) -> str | None:
    return None if value is None else hashlib.sha256(value).hexdigest()

def gitblob(value: bytes | None) -> str | None:
    return None if value is None else hashlib.sha1(b'blob '+str(len(value)).encode()+b'\0'+value).hexdigest()

def git(*args: str) -> str:
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()

head = git('rev-parse','HEAD')
tree = git('rev-parse','HEAD^{tree}')
posts = {p.relative_to(s/'postimages'):p for p in (s/'postimages').rglob('*') if p.is_file()}
for path in (s/'c53-postimages').rglob('*'):
    if path.is_file(): posts[path.relative_to(s/'c53-postimages')] = path
rows=[]; hunks=[]; mismatches=[]
for rel,path in sorted(posts.items()):
    overlay = (s/'c53-postimages'/rel).exists()
    pre = s/('c53-preimages' if overlay else 'preimages')/rel
    old = pre.read_bytes() if pre.exists() else None
    new = path.read_bytes()
    live = root/rel
    actual = live.read_bytes() if live.exists() else None
    if actual != old: mismatches.append(str(rel))
    if old == new: continue
    before = [] if old is None else old.decode().splitlines(keepends=True)
    after = new.decode().splitlines(keepends=True)
    hunks.extend(difflib.unified_diff(before,after,fromfile='/dev/null' if old is None else 'a/'+str(rel),tofile='b/'+str(rel)))
    rows.append({'path':str(rel), 'owner_overlay':'c53-postimages' if overlay else 'postimages',
                 'pre_sha256':digest(old),'pre_git_blob':gitblob(old),'post_sha256':digest(new),'post_git_blob':gitblob(new)})
if mismatches:
    raise SystemExit('preimage mismatches: '+', '.join(mismatches))
if git('rev-parse','HEAD') != head or git('rev-parse','HEAD^{tree}') != tree:
    raise SystemExit('root advanced while source identities were measured; redo readback')
patch=''.join(hunks).encode();(s/'candidate.patch').write_bytes(patch)
check=subprocess.run(['git','apply','--check','--whitespace=error',str(s/'candidate.patch')],cwd=root,text=True,capture_output=True)
receipt={'argv':['git','apply','--check','--whitespace=error',str(s/'candidate.patch')], 'head':head,'tree':tree,'exit_code':check.returncode,'stdout':check.stdout,'stderr':check.stderr}
(s/'apply-check.json').write_text(json.dumps(receipt,indent=2)+'\n')
if check.returncode or git('rev-parse','HEAD') != head:
    raise SystemExit('patch check failed or root advanced during check: '+check.stderr)
support=['README.md','verification-recipe.md','NATIVE-POSITIVE-NEXT.md','CALIBRATION-UNIT-QUESTION.md','CALIBRATION-UNIT-CORRECTION-01.md','check-before-format.json','format-transform.json','removals/manifest.json','apply-check.json']
manifest={
 'status':'FROZEN_FOR_INDEPENDENT_REVIEW_AND_BOUNDED_NATIVE_PILOT_NOT_G_ACCEPTANCE',
 'base_commit':head,'base_tree':tree,'postimage_denominator':len(posts),'changed_path_count':len(rows),
 'preimage_mismatches':mismatches,'patch_sha256':digest(patch),'apply_check_exit_code':check.returncode,
 'paths':rows,'support_sha256':{name:digest((s/name).read_bytes()) for name in support},
 'authoritative_funnel_overlay':'c53-postimages',
 'native_positive_selector':'tests/unit/runtime/http/test_observational_method_runtime.py::test_two_real_completed_ex_ante_sources_are_reselected_by_fresh_planner',
 'compile_bridge_selectors':['tests/unit/scientist/nodes/builtins/compile/test_compile_foundry.py::test_compile_node_threads_request_selected_metric_binding','tests/unit/scientist/nodes/builtins/compile/test_compile_foundry.py::test_compile_node_rejects_malformed_or_conflicting_metric_binding_before_foundry'],
 'fresh_http_routes':['GET /api/v1/runs/{run_id}/method-metrics','GET /api/v1/runs/{run_id}/method-metric-comparison'],
 'python_ast_ruff_format':'32 exact Python postimages checked; see check-before-format.json',
 'removals':'20 source-bound controls prepared, all UNRUN',
 'runtime_tests_generated_g':'UNRUN',
 'known_residual':'Generic observation-unit accounting, same-ticket prior recorded flags, independent control, calibration/lesson/VOI qualification and broader C53 authority remain unmitigated; exploratory fallback is source HOLD and not included. This is not a B156/B163 or 21-occurrence closure.',
 'independent_review':'PENDING'
}
(s/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'base_commit':head,'base_tree':tree,'postimage_denominator':len(posts),'changed_path_count':len(rows),'patch_sha256':digest(patch),'manifest_sha256':digest((s/'manifest.json').read_bytes()),'apply_exit':check.returncode}))
