from pathlib import Path
import ast,hashlib,json,subprocess
out=Path('LOCAL/raw/e02-execution-20261027/repairs/C06-wire');manifest=json.loads((out/'manifest.json').read_text());paths=[Path(f['postimage_path']) for f in manifest['files'] if f['is_changed_from_base']]
for f in manifest['files']:
 assert hashlib.sha256(Path(f['postimage_path']).read_bytes()).hexdigest()==f['postimage_sha256']
for p in paths:ast.parse(p.read_bytes(),filename=str(p))
commands={'ruff-check':['policy-engine/.venv/bin/python','-m','ruff','check','--no-cache','--config','policy-engine/pyproject.toml',*[str(p) for p in paths]],'ruff-format-check':['policy-engine/.venv/bin/python','-m','ruff','format','--check','--config','policy-engine/pyproject.toml',*[str(p) for p in paths]],'patch-check':['git','apply','--check',str(out/'base-to-wire-overlay.patch')]}
result={'postimages_checked':len(manifest['files']),'changed_python_paths_ast_parsed':len(paths),'runtime_tests':'UNRUN','commands':{}}
for name,argv in commands.items():
 p=subprocess.run(argv,capture_output=True);row={'argv':argv,'exit':p.returncode}
 for label,data in [('stdout',p.stdout),('stderr',p.stderr)]:
  file=out/f'{name}.{label}.txt';file.write_bytes(data);row[label]={'path':str(file),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
 result['commands'][name]=row
(out/'static-checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v['exit'] for k,v in result['commands'].items()}))
