from pathlib import Path
p=Path('LOCAL/raw/e02-execution-20261027/repairs/C41-r9/postimages/policy-engine')
f=p/'tests/integration/runtime_quality/test_joint_interaction_cubic_consumer.py';s=f.read_text()
needle='''        # Present a foreign candidate expectation while the selected execution
'''
addition='''        # Exercise the same served run through parent profile faults. These are
        # targeted reader failures after the real worker persisted the parent and
        # independently readable children; no parent evidence is invented.
        parent_ref = ArtifactRef.model_validate(
            projection["joint_parent_observations"][0]["simulation_result_ref"]
        )
        from polisyos.core.artifacts import ArtifactOwnershipError
        from polisyos.core.artifacts.ownership import ArtifactReadOnlyUnavailableError
        from polisyos.runtime.http.routes import runs as runs_route

        def is_parent(ref: Any) -> bool:
            return (
                getattr(ref, "artifact_id", None) == parent_ref.artifact_id
                and getattr(ref, "manifest_profile_sha256", None)
                == parent_ref.manifest_profile_sha256
            )

        def checked_parent_limitation(response: Any, code: str) -> None:
            assert response.status_code == 200, response.text
            result = response.json()["run"]["generic_cycle_simulation"]
            assert result["joint_parent_status"] == "not_established"
            assert result["joint_parent_limitation_code"] == code
            assert not result["joint_parent_observations"]
            assert {(row["node_ref"], row["candidate_id"]) for row in result["n5_observations"]} == before_keys
            assert any(row["n5_owner_join_status"] == "resolved" for row in result["n5_observations"])

        def missing_parent(ref: Any, *args: Any, **kwargs: Any) -> bytes:
            if is_parent(ref):
                raise FileNotFoundError("synthetic selected parent missing")
            return original_raw_manifest(ref, *args, **kwargs)

        def invalid_parent(ref: Any, *args: Any, **kwargs: Any) -> bytes:
            if is_parent(ref):
                return b"{"
            return original_raw_manifest(ref, *args, **kwargs)

        def unavailable_parent(ref: Any, *args: Any, **kwargs: Any) -> bytes:
            if is_parent(ref):
                raise ArtifactReadOnlyUnavailableError("synthetic backend unavailable")
            return original_raw_manifest(ref, *args, **kwargs)

        for failure, expected_code in (
            (missing_parent, "generic_joint_parent_result_unavailable"),
            (invalid_parent, "generic_joint_parent_result_invalid"),
            (unavailable_parent, "generic_joint_parent_result_unavailable"),
        ):
            with monkeypatch.context() as fault:
                fault.setattr(store, "get_raw_manifest_bytes", failure)
                checked_parent_limitation(client.get(f"/api/v1/runs/{run_id}"), expected_code)

        def denied_parent(ref: Any, *args: Any, **kwargs: Any) -> bytes:
            if is_parent(ref):
                raise ArtifactOwnershipError("synthetic selected owner denial")
            return original_raw_manifest(ref, *args, **kwargs)

        with monkeypatch.context() as fault:
            fault.setattr(store, "get_raw_manifest_bytes", denied_parent)
            denied_response = client.get(f"/api/v1/runs/{run_id}")
        assert denied_response.status_code == 403, denied_response.text
        assert "n5_observations" not in json.dumps(denied_response.json())

        def inaccessible_parent(ref: Any, *args: Any, **kwargs: Any) -> bytes:
            if is_parent(ref):
                raise PermissionError("synthetic filesystem permission failure")
            return original_raw_manifest(ref, *args, **kwargs)

        with monkeypatch.context() as fault:
            fault.setattr(store, "get_raw_manifest_bytes", inaccessible_parent)
            unavailable_response = client.get(f"/api/v1/runs/{run_id}")
        assert unavailable_response.status_code == 503, unavailable_response.text
        assert "n5_observations" not in json.dumps(unavailable_response.json())

        # Reader-scope comparison after a valid selected manifest was opened:
        # the injected different tenant is a simulated fault, not evidence of a
        # real foreign owner grant. The actual selector and request are unchanged.
        original_profile_reader = runs_route.read_core_manifest_profile
        scope_checks: list[str] = []

        def foreign_scope(reader: Any, ref: Any, *args: Any, **kwargs: Any) -> Any:
            manifest, declaration = original_profile_reader(reader, ref, *args, **kwargs)
            if is_parent(ref):
                assert manifest.tenant_context is not None
                scope_checks.append("parent")
                foreign = manifest.tenant_context.model_copy(update={"cell_id": "foreign-cell"})
                manifest = manifest.model_copy(update={"tenant_context": foreign})
            return manifest, declaration

        with monkeypatch.context() as fault:
            fault.setattr(runs_route, "read_core_manifest_profile", foreign_scope)
            foreign_response = client.get(f"/api/v1/runs/{run_id}")
        assert scope_checks
        assert foreign_response.status_code == 403, foreign_response.text
        assert "n5_observations" not in json.dumps(foreign_response.json())

        # The second selected parent read denies access after the first succeeded.
        parent_reads: list[int] = []

        def denied_after_parent_read(ref: Any, *args: Any, **kwargs: Any) -> bytes:
            if is_parent(ref):
                parent_reads.append(1)
                if len(parent_reads) == 2:
                    raise ArtifactOwnershipError("synthetic post-read owner denial")
            return original_raw_manifest(ref, *args, **kwargs)

        with monkeypatch.context() as fault:
            fault.setattr(store, "get_raw_manifest_bytes", denied_after_parent_read)
            race_response = client.get(f"/api/v1/runs/{run_id}")
        assert len(parent_reads) == 2
        assert race_response.status_code == 403, race_response.text
        assert "n5_observations" not in json.dumps(race_response.json())

        # Deny a distinct child-source view after another sibling could have
        # been replayed. Permission refusal must suppress the whole response.
        last_leaf = max(candidate_before, key=lambda row: row["node_ref"])
        child_ref = ArtifactRef.model_validate(last_leaf["n4_source_ref"])
        child_denials: list[str] = []

        def denied_child_source(ref: Any, *args: Any, **kwargs: Any) -> bytes:
            if (
                getattr(ref, "artifact_id", None) == child_ref.artifact_id
                and getattr(ref, "manifest_profile_sha256", None)
                == child_ref.manifest_profile_sha256
            ):
                child_denials.append("denied")
                raise ArtifactOwnershipError("synthetic child source denial")
            return original_raw_manifest(ref, *args, **kwargs)

        with monkeypatch.context() as fault:
            fault.setattr(store, "get_raw_manifest_bytes", denied_child_source)
            child_denied_response = client.get(f"/api/v1/runs/{run_id}")
        assert child_denials
        assert child_denied_response.status_code == 403, child_denied_response.text
        assert "n5_observations" not in json.dumps(child_denied_response.json())

'''
assert s.count(needle)==1;s=s.replace(needle,addition+needle);f.write_text(s)
q=p/'tests/unit/core/artifacts/test_selected_profile_verification_reader.py';q.parent.mkdir(parents=True,exist_ok=True)
q.write_text('''"""The strict replay reader preserves selected-owner read failures."""

from pathlib import Path

import pytest

from polisyos.core.artifacts import (
    ArtifactOwnershipError,
    ArtifactReadOnlyUnavailableError,
    FileSystemCAS,
    PutOptions,
    SelectedProfileVerificationReader,
    raise_artifact_read_access_error,
)
from polisyos.core.canon import CanonSpec
from polisyos.core.security.tenant_context import tenant_scope


def test_selected_reader_reopens_owner_and_content_without_using_false_as_access_proof(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    store = FileSystemCAS(tmp_path / "cas").with_ambient_ownership_enforcement()
    with tenant_scope(None, tenant_id="tenant-a", cell_id="cell-a"):
        ref = store.put_json(
            {"witness": "selected"},
            PutOptions(kind="test.selected", media_type="application/json"),
            canon_spec=CanonSpec(),
            return_selected_profile=True,
        )
        selected = SelectedProfileVerificationReader(store)
        assert selected.verify(ref).ok
        original = store.get_bytes

        def deny_after_manifest(_ref: object) -> bytes:
            raise ArtifactOwnershipError("changed owner during selected read")

        with monkeypatch.context() as fault:
            fault.setattr(store, "get_bytes", deny_after_manifest)
            with pytest.raises(ArtifactOwnershipError):
                selected.verify(ref)
        with monkeypatch.context() as fault:
            fault.setattr(store, "get_bytes", lambda _ref: b"wrong bytes")
            assert selected.verify(ref).ok is False
        assert store.get_bytes(ref) == original(ref)

    with tenant_scope(None, tenant_id="tenant-b", cell_id="cell-b"):
        with pytest.raises(ArtifactOwnershipError):
            selected.verify(ref)


def test_access_error_preserves_only_explicit_cause_and_typed_unavailability() -> None:
    denial = ArtifactOwnershipError("tenant denied")
    try:
        raise ValueError("owner wrapper") from denial
    except ValueError as wrapped:
        with pytest.raises(ArtifactOwnershipError) as seen:
            raise_artifact_read_access_error(wrapped)
    assert seen.value is denial
    unavailable = ArtifactReadOnlyUnavailableError("temporarily unavailable")
    raise_artifact_read_access_error(unavailable)
    filesystem_error = PermissionError("filesystem refused")
    with pytest.raises(PermissionError) as seen_permission:
        raise_artifact_read_access_error(filesystem_error)
    assert type(seen_permission.value) is PermissionError
''')
