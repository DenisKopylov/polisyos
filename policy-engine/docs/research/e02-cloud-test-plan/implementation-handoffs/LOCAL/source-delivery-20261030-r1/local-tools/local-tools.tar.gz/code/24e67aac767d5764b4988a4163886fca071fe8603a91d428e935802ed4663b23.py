"""Root one-mode recipe reusing the retained monitor, sandbox, guard and readback."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import runpy
import shutil
import signal
import subprocess
import sys
import time
import traceback

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
P = ROOT / 'policy-engine'
PACKET = Path(__file__).resolve().parent
OWNED = None
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, default=str)
        stream.write('\n')


def main():
    global OWNED
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('core', 'guarded', 'guarded-legacy'))
    parser.add_argument('--head', required=True)
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    manifest = json.loads((PACKET / 'manifest.json').read_text())
    for row in manifest['pins']:
        assert sha(ROOT / row['path']) == row['sha256'], row['path']
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == args.head
    assert subprocess.run(['git', 'merge-base', '--is-ancestor', manifest['basis_head'], args.head], cwd=ROOT).returncode == 0
    for row in manifest['committed_sources']:
        assert hashlib.sha256(subprocess.check_output(['git', 'show', args.head + ':' + row['path']], cwd=ROOT)).hexdigest() == row['sha256']
    N = ROOT / manifest['native_root']
    D = N / 'deep-task-status-audit-20261027-r1'
    case = 'c100-catalog-cas-' + args.mode + '-' + args.head[:8] + '-r2'
    output = D / case
    assert not output.exists() and not (D / (case + '.json')).exists()
    if not args.run:
        print(json.dumps({'case': case, 'mode': args.mode, 'execution': 'UNRUN'}))
        return 0
    guard = runpy.run_path(str(N / 'root-layer-lib.py'))['guard']
    before = guard()
    assert before['head'] == args.head
    live_path = ROOT / 'LOCAL/raw/root-live-ownership-20261021.json'
    live = json.loads(live_path.read_text())
    assert not live['known_dirty_paths'] and shutil.disk_usage(ROOT).free >= 8 * 1024**3
    output.mkdir(exist_ok=False)
    OWNED = output
    tmp = output / 'tmp'
    tmp.mkdir()
    fragment = json.loads((D / 'c48-two-source-composed-r5-20261028.json').read_text())['sandbox_profile_fragment']
    assert hashlib.sha256(fragment.encode()).hexdigest() == 'e32b29d96c194caa1b6d22981823771d1f3b618dd5c73d4956f61bde4fb2f6db'
    profile = '(version 1)\n(allow default)\n(deny file-write*)\n(allow file-write* (subpath ' + json.dumps(str(output)) + '))\n(allow file-write* (literal "/dev/null"))\n' + fragment
    (output / 'child.sb').write_text(profile)
    (output / 'root-live-input.json').write_bytes(live_path.read_bytes())
    for key in ('PYTHONPATH', 'PYTEST_ADDOPTS', 'PYTEST_PLUGINS', 'PYTEST_DISABLE_PLUGIN_AUTOLOAD', 'PYTHONHOME', 'VIRTUAL_ENV'):
        os.environ.pop(key, None)
    env = {'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONPYCACHEPREFIX': str(tmp / 'empty-pycache'),
           'TMPDIR': str(tmp), 'XDG_CACHE_HOME': str(tmp / 'xdg'), 'MPLCONFIGDIR': str(tmp / 'mpl'),
           'RUNTIME_AA_ROOT': str(ROOT), 'RUNTIME_AA_OUTPUT': str(output),
           'RUNTIME_AA_OBSERVER': str(D / 'readset_observer_tools_r1.py'),
           'POLISYOS_R4_INPUT_PROJECT_ROOT': str(P), 'POLISYOS_R4_INPUT_READSET_DIR': str(output / 'readsets'),
           'POLISYOS_R4_CHILD': '1', 'POLISYOS_R4_RECEIPT_DIR': str(output)}
    monitor_path = ROOT / manifest['monitor_path']
    spec = importlib.util.spec_from_file_location('retained_native_monitor', monitor_path)
    monitor = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = monitor
    spec.loader.exec_module(monitor)
    monitor.RSS_CAP_BYTES = 2300 * 1024**2
    monitor.DISK_FLOOR_BYTES = 6 * 1024**3
    monitor.SAMPLE_SECONDS = 1.0
    signal.signal(signal.SIGTERM, monitor.note_stop_signal)
    signal.signal(signal.SIGINT, monitor.note_stop_signal)
    argv = ['/usr/bin/sandbox-exec', '-f', str(output / 'child.sb'), str(P / '.venv/bin/python'), '-B', str(PACKET / 'probe_worker.py'), '--mode', args.mode, '--head', args.head]
    plan = {'case_id': case, 'source_head': args.head, 'source_tree': live['tree'], 'mode': args.mode, 'scope': 'Saved producer/CAS timings only; CLI not pytest/Runtime', 'closure_ids': []}
    save(D / (case + '.json'), plan)
    save(output / 'source-profile-freeze.json', {'before': before, 'plan': plan, 'pins': manifest['pins'], 'argv': argv, 'extra_env': env, 'numeric_threads': monitor.NUMERIC_THREADS, 'cas_environment': {k: v for k, v in os.environ.items() if k.startswith('POLISYOS_RUNTIME_CAS_')}, 'profile_sha256': sha(output / 'child.sb'), 'live_sha256': sha(live_path)})
    started = time.monotonic()
    result = monitor.run_command(output, case, argv, P, started, started + 600, env)
    save(output / 'audit-result.json', {'plan': plan, 'result': result, 'guard_after': guard()})
    readback = subprocess.run([sys.executable, str(ROOT / manifest['readback_path']), case, args.head], cwd=ROOT, capture_output=True)
    (output / 'Git-readback.stdout.txt').write_bytes(readback.stdout)
    (output / 'Git-readback.stderr.txt').write_bytes(readback.stderr)
    for row in manifest['pins']:
        assert sha(ROOT / row['path']) == row['sha256'], row['path']
    assert guard() == before
    save(output / 'controller-result.json', {'CLI_returncode': result['return_code'], 'readback_returncode': readback.returncode, 'complete': result['complete'], 'aborted_reason': result.get('aborted_reason'), 'scope': 'Inspect result.json operation failures; controller success is not a producer/Runtime PASS.'})
    return 0 if result['return_code'] == 0 and readback.returncode == 0 and result['complete'] and not result.get('aborted_reason') else 1


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception:
        if OWNED is not None:
            save(OWNED / 'controller-error.json', {'traceback': traceback.format_exc()})
        raise
