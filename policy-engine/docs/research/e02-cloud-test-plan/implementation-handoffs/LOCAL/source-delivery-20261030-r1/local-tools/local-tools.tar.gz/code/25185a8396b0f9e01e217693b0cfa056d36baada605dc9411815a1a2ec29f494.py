"""Stdlib-only fake pytest checks of the one-test cwd plugin; no product import."""

from __future__ import annotations

import ast
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import tempfile
import types
from pathlib import Path

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
P = ROOT / "policy-engine"
HERE = Path(__file__).resolve().parent
PLUGIN = HERE / "plugin/e02_q2_cwd_guard.py"
CONTROL = HERE / "controls-r11"
CONTROL.mkdir(exist_ok=False)
fake_pytest = types.ModuleType("pytest")
fake_pytest.hookimpl = lambda **_kwargs: (lambda function: function)
fake_pytest.__version__ = "9.0.2"
sys.modules["pytest"] = fake_pytest
spec = importlib.util.spec_from_file_location("e02_q2_cwd_guard_fake", PLUGIN)
if spec is None or spec.loader is None:
    raise RuntimeError("plugin loader unavailable")
guard = importlib.util.module_from_spec(spec)
spec.loader.exec_module(guard)
for module_name, (rel, _digest) in guard.PYTEST_PROFILE_SOURCES.items():
    fake_module = types.ModuleType(module_name)
    fake_module.__file__ = str(P / ".venv/lib/python3.14/site-packages" / rel)
    sys.modules[module_name] = fake_module


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def raises(call: object, expected: str) -> None:
    try:
        call()
    except RuntimeError as exc:
        require(expected in str(exc), f"unexpected exception: {exc}")
    else:
        raise AssertionError(f"missing refusal: {expected}")


original_cwd = Path.cwd().resolve()
require(original_cwd == P.resolve(), "control must start at product root")
wrong = types.SimpleNamespace(nodeid="tests/wrong.py::wrong")
items = [wrong]
raises(lambda: guard.pytest_collection_modifyitems(items), "unexpected_collection")
require(items == [wrong] and Path.cwd().resolve() == original_cwd, "collection mutated")

existing = CONTROL / "existing"
existing.mkdir()
(existing / guard.WORK_NAME).mkdir()
raises(lambda: guard._allocate(existing), "workspace_already_exists")
require((existing / guard.WORK_NAME).is_dir(), "existing workspace was modified")

dangling = CONTROL / "dangling"
dangling.mkdir()
(dangling / guard.WORK_NAME).symlink_to(dangling / "not-present", target_is_directory=True)
raises(lambda: guard._allocate(dangling), "workspace_already_exists")
require((dangling / guard.WORK_NAME).is_symlink(), "dangling symlink was modified")

# Inspect actual files as data, without importing pytest or PolicyOS code.
app_path = P / "src/polisyos/runtime/http/app.py"
test_path = P / guard.TEST
checker_path = P / "tools/ops_runners/runtime/check_runtime_api_contract.py"
exporter_path = P / "tools/ops_runners/runtime/export_runtime_openapi.py"
app_tree = ast.parse(app_path.read_text(encoding="utf-8"))
app_def = next(
    n
    for n in app_tree.body
    if isinstance(n, ast.FunctionDef) and n.name == "create_runtime_api_app"
)
app_defaults = {
    arg.arg: ast.unparse(default)
    for arg, default in zip(app_def.args.kwonlyargs, app_def.args.kw_defaults, strict=True)
    if default is not None
}
require(app_defaults["cas_root"] == "Path('.polisyos/cas')", "default CAS changed")
require(app_defaults["repo_root"] == "None", "default repo root changed")
test_tree = ast.parse(test_path.read_text(encoding="utf-8"))
test = next(
    n
    for n in test_tree.body
    if isinstance(n, ast.FunctionDef)
    and n.name == "test_runtime_contract_gate_rejects_nested_epoch_semantic_corruption"
)
export_calls = [
    n
    for n in ast.walk(test)
    if isinstance(n, ast.Call)
    and isinstance(n.func, ast.Name)
    and n.func.id == "export_runtime_openapi_schema"
]
require(
    len(export_calls) == 1 and not export_calls[0].args and not export_calls[0].keywords,
    "test no longer uses default app",
)
checker_tree = ast.parse(checker_path.read_text(encoding="utf-8"))
checker_fn = next(
    n
    for n in checker_tree.body
    if isinstance(n, ast.FunctionDef) and n.name == "_check_openapi_drift"
)
checker_calls = [ast.unparse(n) for n in ast.walk(checker_fn) if isinstance(n, ast.Call)]
require(
    any(s.startswith("tempfile.TemporaryDirectory(") for s in checker_calls),
    "checker scratch changed",
)
require("render_runtime_openapi(Path(scratch))" in checker_calls, "checker render path changed")
export_tree = ast.parse(exporter_path.read_text(encoding="utf-8"))
export_fn = next(
    n
    for n in export_tree.body
    if isinstance(n, ast.FunctionDef) and n.name == "render_runtime_openapi"
)
app_calls = [
    n
    for n in ast.walk(export_fn)
    if isinstance(n, ast.Call)
    and isinstance(n.func, ast.Name)
    and n.func.id == "create_runtime_api_app"
]
require(
    len(app_calls) == 1
    and any(
        k.arg == "cas_root" and ast.unparse(k.value) == "scratch_root / 'cas'"
        for k in app_calls[0].keywords
    ),
    "exporter scratch CAS changed",
)

# Fake result and file writes test the wrapper; no pytest or product is executed.
positive_case = CONTROL / "positive"
positive_temp = positive_case / "tmp"
positive_temp.mkdir(parents=True)
comparison = positive_case / "runtime_api_v1.clean.openapi.json"
comparison.write_text('{"fixture":"clean"}\n', encoding="utf-8")
corrupted = positive_case / "runtime_api_v1.corrupted.openapi.json"
corrupted.write_text('{"fixture":"corrupted"}\n', encoding="utf-8")
item = types.SimpleNamespace(nodeid=guard.NODE, module=types.SimpleNamespace(subprocess=subprocess))
real_run = subprocess.run


def fake_run(argv: object, **_kwargs: object) -> subprocess.CompletedProcess[str]:
    clean = "runtime_api_v1.clean.openapi.json" in str(argv)
    return subprocess.CompletedProcess(
        argv,
        0 if clean else 1,
        stdout="Runtime API contract check passed\n" if clean else "OpenAPI drift detected\n",
        stderr="",
    )


subprocess.run = fake_run
try:
    with guard._isolated_body(item, positive_temp, {"control": "fake"}):
        require(
            Path.cwd().resolve() == (positive_temp / guard.WORK_NAME).resolve(), "cwd not entered"
        )
        Path(".polisyos/cas/artifacts/sha256").mkdir(parents=True)
        response = item.module.subprocess.run(
            [
                sys.executable,
                "tools/ops_runners/runtime/check_runtime_api_contract.py",
                "--openapi",
                str(comparison),
                "--skip-client-drift",
            ],
            cwd=P,
            env={**os.environ, "PYTHONPATH": f"{P / 'src'}:{P}"},
            capture_output=True,
            text=True,
            check=False,
        )
        require(response.returncode == 0, "clean return changed")
        negative = item.module.subprocess.run(
            [
                sys.executable,
                "tools/ops_runners/runtime/check_runtime_api_contract.py",
                "--openapi",
                str(corrupted),
                "--skip-client-drift",
            ],
            cwd=P,
            env={**os.environ, "PYTHONPATH": f"{P / 'src'}:{P}"},
            capture_output=True,
            text=True,
            check=False,
        )
        require(
            negative.returncode == 1 and negative.stdout == "OpenAPI drift detected\n",
            "return changed",
        )
finally:
    subprocess.run = real_run
require(
    Path.cwd().resolve() == original_cwd and item.module.subprocess is subprocess,
    "positive did not restore",
)
receipt = json.loads((positive_temp / guard.RECEIPT).read_text())
require(
    receipt["cwd_restored"] and receipt["private_cas_artifact_layout_created"],
    "positive receipt mismatch",
)
require(
    len(receipt["checker_calls"]) == 2 and not receipt["evidence_errors"], "checker trace mismatch"
)
require(
    (positive_temp / "q2-checker-0.stdout.txt").read_text() == "Runtime API contract check passed\n"
    and (positive_temp / "q2-checker-1.stdout.txt").read_text() == "OpenAPI drift detected\n",
    "stdout lost",
)
require((positive_temp / "q2-checker-0.stderr.txt").read_bytes() == b"", "stderr lost")

failure_temp = CONTROL / "exception" / "tmp"
failure_temp.mkdir(parents=True)
item = types.SimpleNamespace(nodeid=guard.NODE, module=types.SimpleNamespace(subprocess=subprocess))
sentinel = RuntimeError("fake test failure")
try:
    with guard._isolated_body(item, failure_temp, {"control": "exception"}):
        raise sentinel
except RuntimeError as exc:
    require(exc is sentinel, "exception changed")
else:
    raise AssertionError("exception swallowed")
require(
    Path.cwd().resolve() == original_cwd and item.module.subprocess is subprocess,
    "failure did not restore",
)
failure = json.loads((failure_temp / guard.RECEIPT).read_text())
require(
    failure["cwd_restored"] and failure["test_body_exception_type"] == "RuntimeError",
    "failure receipt mismatch",
)

# Drive the decorated hook generator with fake pytest/config/app modules only.
fake_case = CONTROL / "fake-hook"
fake_temp = fake_case / "tmp"
fake_temp.mkdir(parents=True)
fake_test_tmp = fake_case / "basetemp/test_tmp0"
fake_test_tmp.mkdir(parents=True)
fake_comparison = fake_case / "runtime_api_v1.clean.openapi.json"
fake_comparison.write_text('{"fixture":"clean"}\n', encoding="utf-8")
fake_corrupted = fake_case / "runtime_api_v1.corrupted.openapi.json"
fake_corrupted.write_text('{"fixture":"corrupt"}\n', encoding="utf-8")
original_d = guard.D
guard.D = CONTROL
fake_app = types.ModuleType("polisyos.runtime.http.app")
fake_app.__file__ = str(app_path)


def fake_create(*, cas_root: Path = Path(".polisyos/cas"), repo_root: object = None) -> None:
    return None


def fake_export() -> None:
    return None


fake_app.create_runtime_api_app = fake_create
fake_app.export_runtime_openapi_schema = fake_export
old_app = sys.modules.get("polisyos.runtime.http.app")
sys.modules["polisyos.runtime.http.app"] = fake_app
fake_options = {
    "importmode": "importlib",
    "strict_markers": True,
    "strict": None,
    "strict_config": None,
    "disable_plugin_autoload": False,
    "basetemp": str(fake_case / "basetemp"),
}
fake_config = types.SimpleNamespace(
    rootpath=P,
    inipath=P / "pytest.ini",
    getoption=lambda name, default=None: fake_options.get(name, default),
    getini=lambda name: {
        "strict_markers": None,
        "strict": False,
        "strict_config": None,
        "addopts": ["--import-mode=importlib", "--strict-markers"],
    }[name],
    known_args_namespace=types.SimpleNamespace(disable_plugin_autoload=False),
)
fake_item = types.SimpleNamespace(
    nodeid=guard.NODE,
    path=test_path,
    config=fake_config,
    funcargs={},
    iter_markers=lambda: [
        types.SimpleNamespace(name="integration"),
        types.SimpleNamespace(name="slow"),
    ],
    module=types.SimpleNamespace(
        subprocess=subprocess,
        export_runtime_openapi_schema=fake_export,
    ),
)
env_updates = {
    "E02_Q2_CASE_ID": "fake-hook",
    "TMPDIR": str(fake_temp),
    "POLISYOS_CACHE_HOME": str(fake_temp / "polisyos-cache"),
    "XDG_CACHE_HOME": str(fake_temp / "xdg"),
    "MPLCONFIGDIR": str(fake_temp / "mpl"),
    "NUMBA_CACHE_DIR": str(fake_temp / "numba"),
    "HYPOTHESIS_STORAGE_DIRECTORY": str(fake_temp / "hypothesis"),
    "PYTHONPYCACHEPREFIX": str(fake_temp / "empty-pycache"),
    "PYTHONDONTWRITEBYTECODE": "1",
    "PYTHONPATH": str(PLUGIN.parent),
    "PYTEST_PLUGINS": "e02_q2_cwd_guard",
    "E02_Q2_PLUGIN_SHA256": hashlib.sha256(PLUGIN.read_bytes()).hexdigest(),
    "E02_Q2_TEST_SHA256": hashlib.sha256(test_path.read_bytes()).hexdigest(),
    "E02_Q2_APP_SHA256": hashlib.sha256(app_path.read_bytes()).hexdigest(),
}
old_env = {name: os.environ.get(name) for name in [*env_updates, "PYTEST_DISABLE_PLUGIN_AUTOLOAD"]}
os.environ.update(env_updates)
os.environ.pop("PYTEST_DISABLE_PLUGIN_AUTOLOAD", None)
old_pycache = sys.pycache_prefix
old_tempdir = tempfile.tempdir
sys.pycache_prefix = str(fake_temp / "empty-pycache")
tempfile.tempdir = None
subprocess.run = fake_run
try:
    setup_hook = guard.pytest_runtest_setup(fake_item)
    next(setup_hook)
    fake_item.funcargs["tmp_path"] = fake_test_tmp
    os.environ["POLISYOS_CACHE_HOME"] = str(fake_test_tmp / "runtime-http-cache")
    try:
        next(setup_hook)
    except StopIteration:
        pass
    else:
        raise AssertionError("setup hook yielded more than once")
    hook = guard.pytest_runtest_call(fake_item)
    next(hook)
    require(Path.cwd().resolve() == (fake_temp / guard.WORK_NAME).resolve(), "hook cwd mismatch")
    Path(".polisyos/cas/artifacts/sha256").mkdir(parents=True)
    hook_response = fake_item.module.subprocess.run(
        [
            sys.executable,
            "tools/ops_runners/runtime/check_runtime_api_contract.py",
            "--openapi",
            str(fake_comparison),
            "--skip-client-drift",
        ],
        cwd=P,
        env={**os.environ, "PYTHONPATH": f"{P / 'src'}:{P}"},
        capture_output=True,
        text=True,
        check=False,
    )
    require(hook_response.returncode == 0, "hook clean result changed")
    hook_negative = fake_item.module.subprocess.run(
        [
            sys.executable,
            "tools/ops_runners/runtime/check_runtime_api_contract.py",
            "--openapi",
            str(fake_corrupted),
            "--skip-client-drift",
        ],
        cwd=P,
        env={**os.environ, "PYTHONPATH": f"{P / 'src'}:{P}"},
        capture_output=True,
        text=True,
        check=False,
    )
    require(hook_negative.returncode == 1, "hook negative result changed")
    try:
        next(hook)
    except StopIteration:
        pass
    else:
        raise AssertionError("hook yielded more than once")
    sys.path.append(str(fake_case / "unexpected-import-root"))
    try:
        raises(lambda: guard._validate(fake_item), "setup_sys_path_changed")
    finally:
        sys.path.pop()
    fake_item.iter_markers = lambda: [
        types.SimpleNamespace(name="integration"),
        types.SimpleNamespace(name="slow"),
        types.SimpleNamespace(name="unknown_test_marker"),
    ]
    raises(lambda: guard._validate(fake_item), "unexpected_selected_item_markers")
    fake_item.iter_markers = lambda: [
        types.SimpleNamespace(name="integration"),
        types.SimpleNamespace(name="slow"),
        types.SimpleNamespace(name="xfail"),
    ]
    raises(lambda: guard._validate(fake_item), "unexpected_selected_item_markers")
    fake_item.iter_markers = lambda: [
        types.SimpleNamespace(name="integration"),
        types.SimpleNamespace(name="slow"),
    ]
    fake_failure_temp = CONTROL / "fake-hook-failure" / "tmp"
    fake_failure_temp.mkdir(parents=True)
    fake_failure_test_tmp = fake_failure_temp.parent / "basetemp/test_tmp0"
    fake_failure_test_tmp.mkdir(parents=True)
    fake_options["basetemp"] = str(fake_failure_temp.parent / "basetemp")
    fake_item.funcargs = {}
    os.environ.update(
        {
            "E02_Q2_CASE_ID": "fake-hook-failure",
            "TMPDIR": str(fake_failure_temp),
            "POLISYOS_CACHE_HOME": str(fake_failure_temp / "polisyos-cache"),
            "XDG_CACHE_HOME": str(fake_failure_temp / "xdg"),
            "MPLCONFIGDIR": str(fake_failure_temp / "mpl"),
            "NUMBA_CACHE_DIR": str(fake_failure_temp / "numba"),
            "HYPOTHESIS_STORAGE_DIRECTORY": str(fake_failure_temp / "hypothesis"),
            "PYTHONPYCACHEPREFIX": str(fake_failure_temp / "empty-pycache"),
        }
    )
    sys.pycache_prefix = str(fake_failure_temp / "empty-pycache")
    failure_setup = guard.pytest_runtest_setup(fake_item)
    next(failure_setup)
    fake_item.funcargs["tmp_path"] = fake_failure_test_tmp
    os.environ["POLISYOS_CACHE_HOME"] = str(fake_failure_test_tmp / "runtime-http-cache")
    try:
        next(failure_setup)
    except StopIteration:
        pass
    else:
        raise AssertionError("failure setup hook yielded more than once")
    hook_failure = guard.pytest_runtest_call(fake_item)
    next(hook_failure)
    hook_sentinel = RuntimeError("fake hook failure")
    try:
        hook_failure.throw(hook_sentinel)
    except RuntimeError as exc:
        require(exc is hook_sentinel, "hook exception changed")
    else:
        raise AssertionError("hook exception swallowed")
    hook_failure_receipt = json.loads((fake_failure_temp / guard.RECEIPT).read_text())
    require(hook_failure_receipt["cwd_restored"], "hook exception cwd not restored")
    require(fake_item.module.subprocess is subprocess, "hook exception did not restore proxy")
    setup_exception_temp = CONTROL / "fake-setup-exception" / "tmp"
    setup_exception_temp.mkdir(parents=True)
    os.environ["E02_Q2_CASE_ID"] = "fake-setup-exception"
    fake_item.funcargs = {}
    setup_exception = guard.pytest_runtest_setup(fake_item)
    next(setup_exception)
    setup_sentinel = ValueError("fake setup exception")
    try:
        setup_exception.throw(setup_sentinel)
    except ValueError as exc:
        require(exc is setup_sentinel, "setup exception changed")
    else:
        raise AssertionError("setup exception swallowed")
    require((setup_exception_temp / guard.SETUP_RECEIPT).is_file(), "setup receipt missing")
finally:
    subprocess.run = real_run
    guard.D = original_d
    sys.pycache_prefix = old_pycache
    tempfile.tempdir = old_tempdir
    for name, value in old_env.items():
        if value is None:
            os.environ.pop(name, None)
        else:
            os.environ[name] = value
    if old_app is None:
        sys.modules.pop("polisyos.runtime.http.app", None)
    else:
        sys.modules["polisyos.runtime.http.app"] = old_app
require(Path.cwd().resolve() == original_cwd, "hook did not restore cwd")
hook_receipt = json.loads((fake_temp / guard.RECEIPT).read_text())
require(hook_receipt["cwd_restored"] and len(hook_receipt["checker_calls"]) == 2, "hook receipt")
require(
    hook_receipt["pytest_profile"]["strict_markers_option"] is True
    and hook_receipt["pytest_profile"]["effective_marker_strict"] is False,
    "requested flag/effective behavior must remain separate",
)

result = {
    "mode": "stdlib-only fake pytest/control; no real pytest or product import/run",
    "plugin_sha256": hashlib.sha256(PLUGIN.read_bytes()).hexdigest(),
    "unexpected_node_refused": True,
    "existing_directory_refused": True,
    "dangling_symlink_refused": True,
    "fake_positive_restores_cwd_and_test_subprocess": True,
    "fake_positive_checker_text_and_cas_directory_recorded": True,
    "fake_exception_preserved_and_cwd_restored": True,
    "fake_hook_checks_config_and_records_checker": True,
    "fake_setup_fixture_resource_and_call_binding": True,
    "fake_setup_exception_preserved_and_observed": True,
    "post_setup_import_path_change_refused": True,
    "unexpected_unknown_or_xfail_item_markers_refused": True,
    "fake_hook_exception_restored_without_masking": True,
    "static_default_app_cas": app_defaults["cas_root"],
    "static_default_repo_root": app_defaults["repo_root"],
    "static_checker_scratch_and_exporter_explicit_cas": True,
    "real_candidate_runtime": "UNRUN",
}
with (HERE / "control-r11.json").open("x", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, sort_keys=True)
    stream.write("\n")
sys.stdout.write(json.dumps(result, sort_keys=True) + "\n")
