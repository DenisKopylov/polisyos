"""Author-side oracle arithmetic sanity only; no product or coverage execution."""
import ast
import math
from pathlib import Path

import numpy as np

p = Path(__file__).parent / 'postimages/policy-engine/tests/unit/foundry/methods/catalog/causal/test_rdd_rbc_independent_oracle.py'
tree = ast.parse(p.read_text())
names = {'_fixed_design', '_weighted_fit', '_oracle_side', '_oracle'}
nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in names]
assert len(nodes) == 4
side = next(n for n in nodes if n.name == '_oracle_side')
assert not any(isinstance(n, ast.Name) and n.id in {'H', 'B'} for n in ast.walk(side))
ns = {'np': np, 'H': .45, 'B': .70, 'TRUE_JUMP': 2.}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(p), 'exec'), ns)
x, mean, sigma = ns['_fixed_design']()
y = mean + np.random.default_rng(20261027).normal(0, sigma)
for h, b in [(.45, .70), (.70, .45)]:
    result, uncorrected = [], []
    for right in [False, True]:
        mask = x >= 0 if right else x < 0
        x0, y0 = x[mask], y[mask]
        wh = np.maximum(1 - np.abs(x0 / h), 0)
        wb = np.maximum(1 - np.abs(x0 / b), 0)
        p_design = np.column_stack([np.ones(len(x0)), x0 / h])
        q_design = np.column_stack([np.ones(len(x0)), x0 / b, (x0 / b) ** 2])
        alpha = np.linalg.solve(p_design.T @ (wh[:, None] * p_design), p_design.T @ (wh * y0))
        gamma = np.linalg.solve(q_design.T @ (wb[:, None] * q_design), q_design.T @ (wb * y0))
        lead = np.linalg.solve(p_design.T @ (wh[:, None] * p_design), p_design.T @ (wh * (x0 / h) ** 2))[0] * (h / b) ** 2
        result.append(alpha[0] - lead * gamma[2])
        uncorrected.append(alpha[0])
    point, se = ns['_oracle'](x, y, h=h, b=b)
    direct_point = result[1] - result[0]
    correction = direct_point - (uncorrected[1] - uncorrected[0])
    assert math.isclose(point, direct_point, rel_tol=2e-11, abs_tol=2e-11)
    assert abs(correction) > .04
    print(f'h={h} b={b} independent_tau={point:.12f} independent_se={se:.12f} correction={correction:.12f}')
linear_y = 1 + .3 * x + np.where(x < 0, 0, 2 + .4 * x)
point, se = ns['_oracle'](x, linear_y)
assert abs(point - 2) < 2e-11 and se < 2e-11
print(f'zero-curvature independent point={point:.12f} independent_se={se:.3e}')
print('AUTHOR ORACLE SANITY ONLY: no product method, no pytest, no deciding coverage seed')
