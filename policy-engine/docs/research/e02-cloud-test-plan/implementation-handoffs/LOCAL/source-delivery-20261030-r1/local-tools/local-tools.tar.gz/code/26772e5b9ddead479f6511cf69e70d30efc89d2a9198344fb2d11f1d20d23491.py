"""Fail-closed actual evidence reconciliation, not an exit-status classifier."""
from __future__ import annotations
import argparse,hashlib,json,marshal,xml.etree.ElementTree as ET
from pathlib import Path
from code_tools import code_child,expected_codes
R=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos');P=R/'policy-engine';HERE=Path(__file__).resolve().parent
D=P/'docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1'
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_text())
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'))
def qualify(plan,plan_sha,out,evidence):
 errors=[]
 def retain(p):
  if not p.is_file():errors.append('missing deciding output: '+str(p));return
  row={'path':str(p.relative_to(R)),'sha256':sha(p.read_bytes())}
  if row not in evidence:evidence.append(row)
 audit=load(out/'audit-result.json');freeze=load(out/'source-profile-freeze.json');w=load(out/'c32-witness.json');result=audit['result']
 if audit['plan']!=plan or freeze['plan_sha256']!=plan_sha or sha((out/'source-profile-freeze.json').read_bytes())!=audit['source_profile_freeze_sha256']:errors.append('plan/freeze/audit differ')
 if freeze['before']['head']!=plan['source_head'] or audit['guard_after']['head']!=plan['source_head'] or audit['current_mismatches']:errors.append('source/readset changed during run')
 if not result['complete'] or result['aborted_reason'] is not None:errors.append('incomplete/resource-aborted run')
 junit=list(ET.parse(out/'pytest.xml').iter('testcase'));counts={'tests':len(junit),'failures':sum(t.find('failure') is not None for t in junit),'errors':sum(t.find('error') is not None for t in junit),'skipped':sum(t.find('skipped') is not None for t in junit)}
 if result['junit']!=counts:errors.append('JUnit audit mismatch')
 selected=w['selected'];calls=[r for r in w['reports'] if r['when']=='call']
 if not selected or w['deselected'] or sorted(w['early'])!=sorted(selected) or len(set(selected))!=len(selected) or sorted(r['node'] for r in calls)!=sorted(selected):errors.append('collection/execution mismatch')
 if len(calls)!=counts['tests'] or any(r['when']!='call' and r['outcome']!='passed' for r in w['reports']):errors.append('setup/teardown failure is not semantic evidence')
 for n in selected:
  if not any(n==v or n.startswith(v+'[') or ('::' not in v and n.startswith(v+'::')) for v in plan['nodes']):errors.append('unexpected selected node '+n)
 for roster in plan['expected_roster']:
  members=[n for n in selected if n==roster['node_prefix'] or n.startswith(roster['node_prefix']+'[')]
  if not members:errors.append('requested test missing: '+roster['node_prefix'])
  if roster['parameters'] is not None and sorted(canonical(w['parameters'][n]) for n in members)!=sorted(canonical(p) for p in roster['parameters']):errors.append('exact parameter roster differs: '+roster['node_prefix'])
 if w['plan_sha256']!=plan_sha or w['plugin_sha256']!=plan['extra_env']['C32_PLUGIN_SHA256']:errors.append('plugin/plan witness mismatch')
 profiles={r['node']:r['profile'] for r in w['profiles']}
 if set(profiles)!=set(selected) or any(not p['duckdb_version'] for p in profiles.values()):errors.append('actual child backend/profile missing')
 phase=plan['control_phase'];mode=plan['control_mode'];failures=[r for r in calls if r['outcome']=='failed'];records=[r for r in w['restored'] if not r.get('observer_restoration')]
 if any(not r['restored_in_process'] for r in w['restored']):errors.append('in-process observer/control restoration failed')
 if phase!='mutant':
  if result['return_code']!=0 or any(counts[k] for k in ['failures','errors','skipped']) or any(r['outcome']!='passed' for r in calls):errors.append('positive is not all-pass without skips/errors')
 else:
  c=plan['control_hypothesis'];expected={'empty_subtype':2,'capture_forward':3,'acquisition_adapter':6,'n7_mapping':3,'fabric_family':4,'graph_binding':3,'postread':1,'wal':2}[mode]
  if result['return_code']!=1 or counts!={'tests':c['literal_cases'],'failures':expected,'errors':0,'skipped':0}:errors.append('mutant JUnit differs from semantic hypothesis')
  if any(c['expected_assertion'] not in (r['longrepr'] or '') for r in failures):errors.append('wrong assertion')
  if any(not r['installed'] or r.get('changed_during_call') for r in w['source_trace_admission']):errors.append('source trace unavailable or changed; preserve native tracer and requalify')
  if mode=='capture_forward' and any(w['parameters'][r['node']]['capture_mode']!='persisted_capture' for r in failures):errors.append('capture mutant failed outside persisted branch')
  if len(records)!=len(selected):errors.append('per-case active-code witnesses missing')
  target_set={t['qualified_name'] for t in c['functions']}
  for row in records:
   if {v['qualified_name'] for v in row['mutations']}!=target_set or set(row['active_entries'])!=target_set:errors.append('active target roster differs')
   if sum(row['active_entries'].values())<=0:errors.append('no active callable entry')
   # Fabric has two owners: identity enters publish-admission and metric cases enter
   # row resolution. A per-parameter owner not on that real path may remain uncalled;
   # the aggregate over all eight cases must exercise every installed target.
   for index,t in enumerate(c['functions']):
    actual=next(v for v in row['mutations'] if v['qualified_name']==t['qualified_name']);p=Path(actual['active_source_path']);retain(p)
    if sha(p.read_bytes())!=actual['active_source_sha256'] or actual['mutant_definition_sha256']!=t['mutant_source_sha256'] or actual['rewrite_count']!=t['rewrite_count'] or actual['source_sha256']!=c['source_sha256']:errors.append('active definition/source binding differs')
    raw=(P/c['source']).read_bytes()
    if Path(actual['original_filename']).resolve()!=(P/c['source']).resolve():errors.append('original callable source path differs')
    original=code_child(compile(raw,actual['original_filename'],'exec',dont_inherit=True),t['qualified_name'])
    if sha(marshal.dumps(original))!=actual['original_code_sha256']:errors.append('original callable code differs from whole module')
    _,code=expected_codes(raw,t['qualified_name'],p.read_bytes(),f'<C32-{mode}-{index}>')
    if sha(marshal.dumps(code))!=actual['mutant_code_sha256']:errors.append('active code differs from compiled actual source/mutation')
  if any(sum(r['active_entries'].get(q,0) for r in records)<=0 for q in target_set):errors.append('installed target never entered')
  for node in selected:
   states=[v for v in w['native_states'] if v['node']==node]
   if mode=='wal':
    member=w['parameters'][node]['member'];name='overlay.duckdb' if member=='overlay' else 'catalog.duckdb'
    if not any(v['relative_path']==name and v['stage']=='identify' and v['status']=='complete' and v['wal_exists'] and v.get('wal_bytes',0)>0 for v in states):errors.append('actual uncheckpointed native WAL bytes not observed')
   if mode=='postread':
    initial=[v for v in states if v['relative_path']=='catalog.duckdb' and v['stage']=='identify' and v['status']=='complete']
    final=[v for v in states if v['relative_path']=='catalog.duckdb' and v['stage']=='close' and v['status']=='complete']
    if not initial or not final or initial[0]['raw_sha256']==final[-1]['raw_sha256']:errors.append('actual native source replacement not observed')
   if mode=='fabric_family' and w['parameters'][node]['typed_source'] and not any(e['node']==node and e['code']=='future_owner_read_state' and e['function'] in ['_catalog_publish_admission','_resolve_via_catalog_rows'] for e in w['source_exception_events']):errors.append('actual typed source exception missing at Fabric catch owner')
   events=[v for v in w['consumer_events'] if v['node']==node]
   if mode=='graph_binding':
    if not any(v['role']=='resolver' and v['entered'] for v in events) or not any(v['role']=='native_bindings' and v['entered'] for v in events):errors.append('graph mutant lacks actual resolver/native entry')
   if mode in ['capture_forward','acquisition_adapter','n7_mapping']:
    expected_code=w['parameters'][node]['expected_code'];raised=[v for v in events if v['role']=='resolver' and v['outcome']=='raised' and v.get('typed_catalog_source') and v.get('code')==expected_code]
    if not any(any(Path(f['filename']).resolve()==(P/'src/polisyos/data_forge/domains/catalog/knowledge/store.py').resolve() for f in v['frames']) for v in raised):errors.append('actual typed native source cause missing')
 if w['outside_native_inputs']:errors.append('native inputs outside fixture root were not inspected')
 normalized={}
 for key,basis in w['native_inputs'].items():
  if basis['status']=='not_established':errors.append('native fixture basis not established: '+key)
  normalized[key]={k:v for k,v in basis.items() if k not in ['absolute_path','raw_sha256','raw_bytes']}
 if not normalized:errors.append('actual native input basis missing')
 observed={}
 for row in audit['readsets']:
  p=R/row['path'];retain(p)
  if sha(p.read_bytes())!=row['sha256']:errors.append('readset hash mismatch')
  for v in load(p)['modules']:
   if v['path'] in observed and observed[v['path']]!=v['sha256']:errors.append('conflicting module '+v['path'])
   observed[v['path']]=v['sha256']
   if sha((P/v['path']).read_bytes())!=v['sha256']:errors.append('actual imported module changed '+v['path'])
 if not observed:errors.append('actual loaded readset missing')
 for p,pin in plan['c32_binding']['committed_inputs'].items():
  if sha((R/p).read_bytes())!=pin['sha256']:errors.append('explicit committed input changed '+p)
 for prior in plan['prior_qualified_receipts']:
  p=Path(prior['path']);retain(p)
  if sha(p.read_bytes())!=prior['sha256']:errors.append('prior receipt changed')
  receipt=load(p)
  for e in receipt['evidence']:
   p=R/e['path'];retain(p)
   if sha(p.read_bytes())!=e['sha256']:errors.append('prior deciding bytes unavailable')
  if profiles!=receipt['actual_child_profiles'] or selected!=receipt['selected_nodeids'] or observed!=receipt['observed_module_pins'] or normalized!=receipt['normalized_native_input_basis']:errors.append('matched profile/selection/readset/complete normalized fixture basis mismatch')
 review=plan.get('independent_mutant_review')
 if review is not None:
  p=Path(review['path']);retain(p);actual=load(p)
  if sha(p.read_bytes())!=review['sha256'] or actual['verdict']!='expected_semantic_failure' or actual['reviewer_identity']!=review['reviewer_identity'] or actual['mutant_receipt_sha256']!=review['mutant_receipt_sha256']:errors.append('independent mutant review binding changed')
 for n in ['audit-result.json','source-profile-freeze.json','c32-witness.json','pytest.xml',result['stdout_path'],result['stderr_path']]:
  p=out/n
  if Path(n).is_absolute() or not p.resolve().is_relative_to(out.resolve()):errors.append('output locator escapes case')
  else:retain(p)
 return {'qualification':'qualified' if not errors else 'UNQUALIFIED','errors':errors,'phase':phase,'mode':mode,'source_head':plan['source_head'],'source_tree':plan['source_tree'],'selected_nodeids':selected,'actual_child_profiles':profiles,'committed_input_sha256':{p:v['sha256'] for p,v in plan['c32_binding']['committed_inputs'].items()},'observed_module_pins':observed,'normalized_native_input_basis':normalized,'actual_native_inputs':w['native_inputs'],'counts':counts,'resources':{'wall_seconds':result['wall_seconds'],'peak_process_tree_rss_bytes':result['max_sampled_process_tree_rss_bytes']}}
def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('--plan',type=Path,required=True);a.add_argument('--plan-sha256',required=True);a.add_argument('--receipt',type=Path,required=True);x=a.parse_args();evidence=[];out=None;plan={}
 try:
  plan=load(x.plan);assert sha(x.plan.read_bytes())==x.plan_sha256
  assert plan['case_id'] and all(c.isalnum() or c in '-_' for c in plan['case_id']);out=D/plan['case_id']
  report=qualify(plan,x.plan_sha256,out,evidence)
 except (OSError,ValueError,KeyError,TypeError,AssertionError,ET.ParseError) as exc:
  report={'qualification':'UNQUALIFIED','errors':['missing/malformed/invalid deciding evidence: '+type(exc).__name__+': '+str(exc)],'phase':plan.get('control_phase'),'mode':plan.get('control_mode')}
  if out is not None and out.is_dir():
   for p in sorted(out.iterdir()):
    if p.is_file() and p.suffix in ['.json','.xml','.txt','.py']:evidence.append({'path':str(p.relative_to(R)),'sha256':sha(p.read_bytes())})
 report.update(schema='policyos.c32.native_receipt.v2',evidence=evidence,scope='Finite actual readset and native fixture basis only; raw native identities retained separately. Only exact tmp_path string prefixes normalized; no time/authority/hash values silently removed. Semantic inputs may differ: mismatch is UNQUALIFIED, never declared identical by test hash. Independent mutant review required before restored phase. Not ordinary N7/V4/V7/G acceptance/closure.',closure_ids=[])
 with x.receipt.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
 print(json.dumps({'receipt':str(x.receipt),'sha256':sha(x.receipt.read_bytes()),'qualification':report['qualification'],'errors':report['errors']}));raise SystemExit(0 if report['qualification']=='qualified' else 125)
if __name__=='__main__':main()
