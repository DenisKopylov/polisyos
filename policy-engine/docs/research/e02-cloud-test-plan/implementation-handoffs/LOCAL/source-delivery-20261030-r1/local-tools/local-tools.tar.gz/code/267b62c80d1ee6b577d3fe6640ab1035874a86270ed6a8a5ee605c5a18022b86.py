"""Freeze sparse C32 proposals; only scratch is written and Git is read/check-only."""
from pathlib import Path
import ast
import datetime
import difflib
import hashlib
import io
import json
import subprocess
import tomllib

R = Path.cwd()
O = R / 'LOCAL/raw/e02-execution-20261027/repairs/C32-r7'
BASE = '2ef22b8818f8a35611af3898c07c7121ca89075d'
GEN = 'policy-engine/src/polisyos/runtime/quality/generation_cycle.py'
C41 = R / 'LOCAL/raw/e02-execution-20261027/repairs/C41-r8/postimages' / GEN
HTE = 'policy-engine/tests/unit/runtime/http/test_search_hte_first_assessment_outbox.py'
sha = lambda b: hashlib.sha256(b).hexdigest()
DOC_OVERRIDES = json.loads((O/'documentation-preimage-overrides.json').read_text())

def git(*args):
    return subprocess.check_output(['git', *args], cwd=R)

def diff(path, before, after):
    header = f'diff --git a/{path} b/{path}\n'
    if before is None:
        header += 'new file mode 100644\n'
    return header + ''.join(difflib.unified_diff(
        (before or b'').decode().splitlines(keepends=True), after.decode().splitlines(keepends=True),
        fromfile='a/'+path if before is not None else '/dev/null', tofile='b/'+path))

assert git('symbolic-ref','--short','HEAD').decode().strip() == 'codex/e02-unified-local-20261009'
assert git('diff','--name-only') == b'' and git('diff','--cached','--name-only') == b''
old_gen = git('show', BASE+':'+GEN)
combined = (O/GEN).read_bytes()
assert sha(C41.read_bytes()) == '3cd38a269c1127780fe79c85da3194dfaade8c844e75342b9e4e44ade051407c'
c41_patch = O/'generation-context-on-C41-r8.patch'
c41_patch.write_text(diff(GEN, C41.read_bytes(), combined))
illustration = O/'root-base-context'/GEN
illustration.parent.mkdir(parents=True,exist_ok=True)
illustration.write_bytes(old_gen)
q = subprocess.run(['git','apply','--directory='+str((O/'root-base-context').relative_to(R)),str(c41_patch)],cwd=R,capture_output=True)
assert q.returncode == 0, q.stderr
root_new = illustration.read_bytes()
root_patch = O/'generation-context-on-root-base.patch'
root_patch.write_text(diff(GEN,old_gen,root_new))
q = subprocess.run(['git','apply','--check','--whitespace=error',str(root_patch)],cwd=R,capture_output=True)
assert q.returncode == 0,q.stderr
bindings = {'path':GEN,'root_base':BASE,'root_preimage_sha256':sha(old_gen),
    'root_postimage_sha256':sha(root_new),'root_illustration':str(illustration.relative_to(R)),
    'root_context_patch_sha256':sha(root_patch.read_bytes()),
    'C41_manifest_sha256':'fc297e86027b7775173c8d070ab95a90584c6d5080f6921305ab12580a590728',
    'C41_preimage_sha256':sha(C41.read_bytes()),'C41_postimage_sha256':sha(combined),
    'C41_context_patch_sha256':sha(c41_patch.read_bytes()),'semantic_dependency_on_C41':False,
    'composition':'Apply one matching context variant; never copy the shared full postimage. C41/C49 own separate mechanisms.'}
(O/'generation-context-bindings.json').write_text(json.dumps(bindings,indent=2)+'\n')
# Check the independent root-only illustration at the canonical Ruff topology.
q = subprocess.run([str(R/'policy-engine/.venv/bin/python'),'-m','ruff','check','--stdin-filename',GEN.removeprefix('policy-engine/'),'-'],input=root_new,cwd=R/'policy-engine',capture_output=True)
(O/'root-generation.ruff.stdout').write_bytes(q.stdout)
(O/'root-generation.ruff.stderr').write_bytes(q.stderr)
assert q.returncode == 0,q.stderr
ast.parse(root_new)
rows=[]; patches=[]; syntax=[]
for f in sorted((O/'policy-engine').rglob('*')):
    if not f.is_file():
        continue
    p=f.relative_to(O).as_posix()
    if p==GEN:
        old=C41.read_bytes()
    else:
        effective_base = DOC_OVERRIDES.get(p, {}).get('base_commit', BASE)
        q=subprocess.run(['git','show',effective_base+':'+p],cwd=R,capture_output=True)
        old=q.stdout if q.returncode==0 else None
        assert p.endswith('.md') or ((R/p).read_bytes() if (R/p).exists() else None)==old,('owned preimage changed',p)
    new=f.read_bytes()
    assert old != new,p
    row={'path':p,'base_commit':DOC_OVERRIDES.get(p, {}).get('base_commit', BASE) if p!=GEN else 'C41-r8 sparse postimage',
        'base_sha256':sha(old) if old is not None else None,
        'observed_root_preimage_sha256':sha((R/p).read_bytes()) if (R/p).is_file() else None,
        'root_preimage_equals_base':((R/p).read_bytes() if (R/p).exists() else None)==old,
        'postimage_path':str(f.relative_to(R)), 'postimage_sha256':sha(new),'bytes':len(new),
        'composition':'context_merge' if p==GEN or p==HTE or p.endswith('.md') else 'exact_preimage_bound_patch'}
    if p==GEN:
        row['accepted_postimage_sha256']=[sha(root_new),sha(combined)]
        row['warning']='Shared full-file illustration includes C41, not C32-owned replacement authority.'
    else:
        patches.append(diff(p,old,new))
    if p==HTE:
        (O/'hte-fixture-context.patch').write_text(diff(p,old,new))
    rows.append(row)
    if f.suffix=='.py':
        tree=ast.parse(new);tests=[]
        for n in tree.body:
            if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_'):
                factor=1;unknown=False
                for d in n.decorator_list:
                    if isinstance(d,ast.Call) and isinstance(d.func,ast.Attribute) and d.func.attr=='parametrize':
                        try:
                            vals=ast.literal_eval(d.args[1]);factor*=len(vals)
                        except (ValueError,TypeError,IndexError,SyntaxError):
                            unknown=True
                tests.append({'name':n.name,'literal_cases':None if unknown else factor})
        syntax.append({'path':p,'kind':'python_ast','test_functions':tests})
    elif f.suffix=='.toml':
        tomllib.loads(new.decode());syntax.append({'path':p,'kind':'toml'})
# Complete tracked-test literal constructor census; no production payload walk.
tracked=[p for p in git('ls-tree','-r','--name-only',BASE,'policy-engine/tests').decode().splitlines() if p.endswith('.py')]
source = subprocess.run(['git','cat-file','--batch'],input=('\n'.join(BASE+':'+p for p in tracked)+'\n').encode(),cwd=R,capture_output=True,check=True).stdout
stream=io.BytesIO(source)
literals=[]
for p in tracked:
    header=stream.readline().decode().split();assert header[1]=='blob',(p,header)
    raw=stream.read(int(header[2]));assert stream.read(1)==b'\n'
    for n in ast.walk(ast.parse(raw)):
        if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='CatalogServingSourcePaths':
            literals.append({'path':p,'line':n.lineno})
migration=json.loads((O/'fixture-constructor-migration.json').read_text())
assert {(r['path'],r['old_constructor_line']) for r in migration['literal_constructors']} == {(r['path'],r['line']) for r in literals}
migration['walked_tracked_python_files']=len(tracked)
(O/'fixture-constructor-migration.json').write_text(json.dumps(migration,indent=2)+'\n')
(O/'constructor-census.json').write_text(json.dumps({'base':BASE,'tracked_python_test_files':len(tracked),'literal_calls':literals,'boundary':'Literal bare-name calls only; alias/reflection cannot be excluded by this AST instrument.'},indent=2)+'\n')
(O/'syntax-and-cases.json').write_text(json.dumps(syntax,indent=2)+'\n')
patch=O/'base-to-proposal.patch';patch.write_text(''.join(patches))
q=subprocess.run(['git','apply','--check','--whitespace=error',str(patch)],cwd=R,capture_output=True)
(O/'apply-check.stdout').write_bytes(q.stdout);(O/'apply-check.stderr').write_bytes(q.stderr)
assert q.returncode==0,q.stderr
static=json.loads((O/'static-checks.json').read_text())
assert all(x['exit']==0 for x in static)
assert {x['path'] for x in static} == {r['path'].removeprefix('policy-engine/') for r in rows if r['path'].endswith('.py')}
assert all(sha((O/'policy-engine'/x['path']).read_bytes())==x['source_sha256'] for x in static)
artifacts=['documentation-preimage-overrides.json','README.md','prepare_native.py','static-checks.json','syntax-and-cases.json','affected-nodes.json','fixture-constructor-migration.json','constructor-census.json','generation-context-bindings.json','hte-fixture-context.patch','generation-context-on-root-base.patch','generation-context-on-C41-r8.patch']
m={'schema':'policyos.e02.sparse_source_proposal.v1','slice':'C32-r7 selected Catalog typed source failure through actual Fabric/acquisition/N7 consumers',
    'base_commit':BASE,'base_tree':git('rev-parse',BASE+'^{tree}').decode().strip(),
    'observed_head':git('rev-parse','HEAD').decode().strip(),'observed_tree':git('rev-parse','HEAD^{tree}').decode().strip(),
    'files':rows,'own_patch_excludes_shared_generation':True,'patch_sha256':sha(patch.read_bytes()),
    'artifacts':{p:sha((O/p).read_bytes()) for p in artifacts},
    'parent_packets':{'r6_manifest':'7de9dd9c8420b43e5d585bb277bbfd3c751516277a12cae3bea6dc56e9d00c0d','r5_manifest':'cad610f139eec6e78bb8ccabd112f162b247ae176326e69d2b6ea36dc676a961','r5_review':'5dda4dc71f06a39171c3e4b9dcba8fdf80bdaff365cbaf2a4948787fea81fa45','r3_manifest':'4cc562a032e59532151bc64e35dc24fcdad6e8d6c81523280262444aede92ce6','r4_manifest':'8859e9e52d259f93ac87e49a5a928cff5863b8905b081a855d275eb4853fd3fb','r4_review':'91dbcf4fb553f4136b1b47b957893fa9dcf26d95aa7219fdf6583ec92366afeb'},
    'runtime':'UNRUN','removal_controls':'UNRUN; recipes only','canonical_mutations':False,'G_acceptance':False,'closure_ids':[],
    'declared_residual':'Before/after byte scans do not establish atomic filesystem custody; concrete ABA diagnostic pending and must retain actual JSON bytes.',
    'required_root_companions':['Merge only matching generation/HTE context hunks; preserve C41/C49 and tenant/unit/source-owner semantics','Regenerate/check affected public surface family and review release marker','Native new-profile pilot alone; actual graph gateway, four Fabric fallback seams, after-guard source fault and persisted/fresh N7 diagnostics plus all prior affected consumers; matched removals','Run residual diagnostic and retain actual classification; do not promote pytest completion to custody proof','Ordinary supported served CGF-to-fresh-planner V4/V7 route remains separately UNRUN; no grounding/EvalSafety override']}
(O/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
# Read back every frozen artifact, not only the assembly variables.
for row in json.loads((O/'manifest.json').read_text())['files']:
    assert sha((R/row['postimage_path']).read_bytes())==row['postimage_sha256']
assert all(sha((O/p).read_bytes())==d for p,d in m['artifacts'].items())
print(json.dumps({'files':len(rows),'python_files':len(static),'manifest_sha256':sha((O/'manifest.json').read_bytes()),'patch_sha256':sha(patch.read_bytes()),'patch_bytes':patch.stat().st_size,'generation_contexts':bindings,'runtime':'UNRUN'}))
