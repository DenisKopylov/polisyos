from pathlib import Path
p=Path('LOCAL/raw/e02-execution-20261027/repairs/child-core-custody-r1/postimages/policy-engine/src/polisyos/core/artifacts/store.py')
s=p.read_text()
anchor='    def _publish_admitted_staged_import(\n'
assert s.count(anchor)==1
new='''    def _publish_child_release_profiles(
        self,
        source: FileSystemCAS,
        refs: tuple[ArtifactRef, ...],
        ledger: object,
        *,
        token: object,
    ) -> ImportPublication:
        """Transfer only Core-enrolled child profiles, retaining their deny-first gate.

        This internal path reuses durable storage reservation and import publication.
        It does not admit arbitrary claimed manifest views and cannot commit release.
        No Root/job fence is held over this streaming preparation and transfer.
        """
        import shutil

        from .child_release import (
            _CHILD_STAGING_TOKEN,
            _ChildReleaseLedger,
            _safe_read,
            child_store_identity,
        )

        if token is not _CHILD_STAGING_TOKEN or type(ledger) is not _ChildReleaseLedger:
            raise ArtifactIntegrityError("child_publication_owner_required")
        if type(source) is not FileSystemCAS or source is self:
            raise ArtifactIntegrityError("child_publication_private_source_required")
        if ledger.root != self.root.resolve(strict=True) or ledger.head().status != "pending":
            raise ArtifactIntegrityError("child_publication_pending_owner_required")
        if child_store_identity(source.root) == ledger.store_identity or not refs:
            raise ArtifactIntegrityError("child_publication_private_source_invalid")
        stage = self._coordinator.transaction_root / "stage" / ("child-" + ledger.release_id)
        if self._ownership_index._path_has_symlink_component(stage):
            raise ArtifactIntegrityError("child_transfer_stage_symlink")
        _ensure_directory_durable(stage)
        members: set[str] = set()
        artifact_refs: set[str] = set()
        profiles: set[tuple[str, str]] = set()
        for ref in refs:
            if type(ref) is not ArtifactRef or ref.manifest_profile_sha256 is None:
                raise ArtifactIntegrityError("child_transfer_selected_profile_required")
            key = (str(ref.artifact_id), ref.manifest_profile_sha256)
            if key in profiles:
                raise ArtifactIntegrityError("child_transfer_duplicate_profile")
            profiles.add(key)
            manifest = source.get_manifest(ref)
            info = manifest.child_release
            if (
                info is None or info not in source._private_child_infos()
                or info.release_id != ledger.release_id
                or info.root_run_id != ledger.root_run_id
                or info.served_store_identity != ledger.store_identity
            ):
                raise ArtifactIntegrityError("child_transfer_scope_not_owner_bound")
            enrollment = self.root / "artifacts/ownership/child_releases/enrollments" / ref.artifact_id.hex / (ref.manifest_profile_sha256[7:] + ".json")
            if _safe_read(self.root, enrollment) != info.model_dump_json().encode():
                raise ArtifactIntegrityError("child_transfer_not_enrolled_before_copy")
            prefix = f"artifacts/sha256/{ref.artifact_id.hex[:2]}/{ref.artifact_id.hex[2:4]}/{ref.artifact_id.hex}"
            paths = (
                (prefix + ".blob", source._layout.blob_path(ref.artifact_id)),
                (prefix + ".view." + ref.manifest_profile_sha256[7:] + ".manifest.json", source._manifest_path_for_ref(ref.artifact_id, ref.manifest_profile_sha256)),
            )
            for member, source_path in paths:
                if member in members:
                    continue
                if source._ownership_index._path_has_symlink_component(source_path) or not source_path.is_file():
                    raise ArtifactIntegrityError("child_transfer_source_unsafe")
                destination = stage / member
                if self._ownership_index._path_has_symlink_component(destination):
                    raise ArtifactIntegrityError("child_transfer_destination_unsafe")
                _ensure_directory_durable(destination.parent)
                if destination.exists():
                    raise ArtifactIntegrityError("child_transfer_stage_already_populated")
                # Hard-link immutable CAS content on the same volume; cross-volume
                # fallback copies only this selected closure, never input CAS bytes.
                try:
                    os.link(source_path, destination)
                except OSError as exc:
                    if exc.errno != errno.EXDEV:
                        raise
                    with source_path.open("rb") as reader, destination.open("xb") as writer:
                        shutil.copyfileobj(reader, writer, length=1024 * 1024)
                        writer.flush()
                        os.fsync(writer.fileno())
                members.add(member)
            artifact_refs.add(str(ref.artifact_id))
        # The existing publisher rehashes bodies, selected manifests and lineage,
        # reserves actual storage, and atomically records existing tenant ownership.
        return self._publish_admitted_staged_import(stage, members, artifact_refs)

'''
s=s.replace(anchor,new+anchor)
# errno already imported? use local explicit import to avoid touching module import family.
s=s.replace('        import shutil\n\n        from .child_release', '        import errno\n        import shutil\n\n        from .child_release')
# Actual layout's blob accessor may be named differently: canonical uses _paths.
s=s.replace('source._layout.blob_path(ref.artifact_id)', 'source._paths(ref.artifact_id)[0]')
p.write_text(s)
p=Path('LOCAL/raw/e02-execution-20261027/repairs/child-core-custody-r1/postimages/policy-engine/src/polisyos/core/run/child_custody.py')
s=p.read_text().replace('import hashlib\n','').replace('import os\n','')
s=s.replace('from ..artifacts._integrity_ops import ArtifactBoundedManifestRead','from ..artifacts._integrity_ops import ArtifactBoundedManifestRead, VerificationReport')
s=s.replace('from ..artifacts.protocol import ArtifactReader, VerificationReport','from ..artifacts.protocol import ArtifactReader')
s=s.replace('        self.receipt = receipt\n        super().__init__("child_release_committed_parent_effects_unknown")','        self.receipt = receipt\n        self.reason = "child_release_committed_parent_effects_unknown"\n        super().__init__(self.reason)')
s=s.replace('        self.check_active(scope)\n        if _key(projection_ref)', '        self.check_active(scope)\n        if not scope.run._closed or scope.run._suspended or scope.run.run_manifest.finished_at is None:\n            raise ChildReleaseUnavailableError("child_execution_not_quiescent")\n        if _key(projection_ref)')
anchor='    def _closure(self, store: ArtifactReader, projection_ref: ArtifactRef) -> tuple[ArtifactRef, ...]:\n'
new='''    def revoke_parent(self, *, reason: str) -> None:
        """Close all managed session writes, even if no child has been opened."""
        if not reason:
            raise ValueError("revocation_reason_required")
        with self._lock:
            self._revoked.update(self._bindings)
            if self._state != "released":
                self._state = "revoked"
                self._ledger.revoke(reason)

'''
assert s.count(anchor)==1
s=s.replace(anchor,new+anchor)
p.write_text(s)
# Ensure all owner directories are created without following symlinks.
p=Path('LOCAL/raw/e02-execution-20261027/repairs/child-core-custody-r1/postimages/policy-engine/src/polisyos/core/artifacts/child_release.py')
s=p.read_text().replace('from ._atomic_write import AtomicFileDurabilityError, AtomicFileWriter','from ._atomic_write import AtomicFileDurabilityError, AtomicFileWriter, ensure_directory_durable')
anchor='def _head_path(root: Path, release_id: str) -> Path:\n'
new='''def _safe_directory(root: Path, path: Path) -> None:
    relative = path.relative_to(root)
    current = root
    for part in relative.parts:
        current = current / part
        if os.path.lexists(current) and not stat.S_ISDIR(os.lstat(current).st_mode):
            raise ChildReleaseUnavailableError("owner_directory_unsafe")
    ensure_directory_durable(path)


'''
s=s.replace(anchor,new+anchor).replace('self.path.parent.mkdir(parents=True, exist_ok=True)', '_safe_directory(self.root, self.path.parent)').replace('path.parent.mkdir(parents=True, exist_ok=True)', '_safe_directory(self.root, path.parent)')
s=s.replace('        or manifest.child_release is None\n', '        or (manifest.tenant_context.tenant_id if manifest.tenant_context is not None else None) != record.tenant_id\n        or (manifest.tenant_context.cell_id if manifest.tenant_context is not None else None) != record.cell_id\n        or manifest.child_release is None\n')
p.write_text(s)
