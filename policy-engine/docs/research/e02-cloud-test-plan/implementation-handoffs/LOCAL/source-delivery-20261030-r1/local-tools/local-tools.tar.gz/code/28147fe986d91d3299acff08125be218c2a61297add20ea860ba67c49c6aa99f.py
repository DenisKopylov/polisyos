"""Read selected saved inputs through read-only owners, then measure a fresh CAS."""

import argparse
from concurrent.futures import Future, wait
from dataclasses import asdict
import hashlib
import importlib.util
import inspect
import json
import marshal
import os
from pathlib import Path
import subprocess
import sys
import threading
import time
import traceback
import types

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
PACKET = Path(__file__).resolve().parent
OUTPUT = Path(os.environ['RUNTIME_AA_OUTPUT'])
TOOL_ID = 5
EVENTS = []
ACTIVE = {}
FUTURES = {}
MONITORED = set()
LEGACY_PROFILE = None
EVENT_STREAM = None
CONDITION = threading.Condition()


def save(name, value):
    with (OUTPUT / name).open('x') as stream:
        json.dump(value, stream, indent=2, default=str)
        stream.write('\n')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def exception_chain(error):
    rows, seen = [], set()
    while error is not None and id(error) not in seen:
        seen.add(id(error))
        rows.append({'type': type(error).__module__ + '.' + type(error).__qualname__,
                     'message': str(error)})
        error = error.__cause__ or error.__context__
    return rows


def emit(row):
    EVENTS.append(row)
    EVENT_STREAM.write(json.dumps(row, default=str) + '\n')
    EVENT_STREAM.flush()


def quiescent():
    return not ACTIVE and all(future.done() for future in FUTURES.values())


def wait_for_actual_futures():
    deadline = time.monotonic() + 30
    checkpointed = False
    while True:
        with CONDITION:
            if quiescent():
                emit({'event': 'future_terminal_snapshot', 'ns': time.monotonic_ns(),
                      'states': [{'id': key, 'done': value.done(), 'cancelled': value.cancelled()}
                                 for key, value in FUTURES.items()],
                      'scope': 'Observed upper bound, not exact terminal publication time.'})
                return not checkpointed
            pending = tuple(value for value in FUTURES.values() if not value.done())
            timeout = None if checkpointed else max(0, deadline - time.monotonic())
            if timeout == 0:
                save('pending-after-30s.json', {'ns': time.monotonic_ns(),
                    'future_states': [{'id': key, 'done': value.done(), 'running': value.running(),
                                       'cancelled': value.cancelled()} for key, value in FUTURES.items()],
                    'active_selected_frames': len(ACTIVE),
                    'scope': 'Observation remains active; retained600s supervisor owns abort.'})
                checkpointed = True
                continue
        if pending:
            # Reuse the real Future owner; no custom callback can outlive our stream.
            wait(pending, timeout=timeout)
        else:
            with CONDITION:
                CONDITION.wait_for(lambda: not ACTIVE or any(not item.done() for item in FUTURES.values()),
                                   timeout=timeout)
        # Reconcile again: captured Future set may have grown during this wait.


def start(code, offset):
    frame = sys._getframe(1)
    if frame.f_code is not code:
        raise RuntimeError('monitoring_callback_frame_not_established')
    now = time.monotonic_ns()
    local = frame.f_locals
    row = {'event': 'enter', 'ns': now, 'thread': threading.get_ident(),
           'code': code.co_qualname, 'code_id': id(code),
           'file': code.co_filename, 'line': code.co_firstlineno}
    actual_profile = sys.getprofile()
    row['profile_none'] = actual_profile is None
    row['legacy_profile_active'] = LEGACY_PROFILE is not None and actual_profile is LEGACY_PROFILE
    if actual_profile is not None:
        row['actual_profile_callable'] = actual_profile.__module__ + '.' + actual_profile.__qualname__
        row['actual_profile_code_sha256'] = hashlib.sha256(marshal.dumps(actual_profile.__code__)).hexdigest()
    func = local.get('func')
    if callable(func):
        row['guarded_callable'] = func.__module__ + '.' + func.__qualname__
        row['positional_argument_count'] = len(local.get('args', ()))
        row['keyword_arguments'] = sorted(local.get('kwargs', {}))
    owner = local.get('self')
    if hasattr(owner, '_timeout_seconds'):
        row['actual_guard_timeout_seconds'] = owner._timeout_seconds
    snapshot = local.get('snapshot')
    if snapshot is not None and hasattr(snapshot, 'timeout_seconds'):
        row['actual_attempt_timeout_seconds'] = snapshot.timeout_seconds
        row['actual_attempt_dependency'] = snapshot.dependency_name
        row['actual_attempt_timeout_callback_present'] = snapshot.on_timeout is not None
    if isinstance(owner, Future):
        row['future_id'] = id(owner)
        row['future_timeout_argument'] = local.get('timeout')
    opts = local.get('opts')
    if opts is not None:
        row['artifact_kind'] = getattr(opts, 'kind', None)
        row['media_type'] = getattr(opts, 'media_type', None)
        row['schema'] = repr(getattr(opts, 'schema', None))
        row['input_count'] = len(getattr(opts, 'inputs', ()) or ())
        row['tenant_context_provided'] = getattr(opts, 'tenant_context', None) is not None
    if 'return_selected_profile' in local:
        row['return_selected_profile'] = local['return_selected_profile']
    if 'canon_spec' in local:
        row['canon_spec'] = repr(local['canon_spec'])
    data = local.get('data')
    if isinstance(data, bytes):
        row['payload_bytes'] = len(data)
    with CONDITION:
        row['event_id'] = len(EVENTS)
        ACTIVE.setdefault((threading.get_ident(), code), []).append(row)
        emit(row)
        if isinstance(owner, Future) and id(owner) not in FUTURES:
            FUTURES[id(owner)] = owner
            CONDITION.notify_all()


def finish(code, offset, value, *, unwind=False):
    now = time.monotonic_ns()
    key = (threading.get_ident(), code)
    with CONDITION:
        stack = ACTIVE.get(key)
        if not stack:
            raise RuntimeError('monitoring_unpaired_exit')
        entered = stack.pop()
        if not stack:
            del ACTIVE[key]
        row = {'event': 'unwind' if unwind else 'return', 'ns': now,
               'thread': key[0], 'code': code.co_qualname,
               'duration_ns': now - entered['ns'], 'enter_event_id': entered['event_id']}
        if unwind:
            row['exception_chain'] = exception_chain(value)
        elif isinstance(value, bool):
            row['returned_bool'] = value
        emit(row)
        CONDITION.notify_all()


def unwind(code, offset, error):
    if code in MONITORED:
        finish(code, offset, error, unwind=True)


def install_local_observer(functions):
    codes = set()
    def add(code):
        codes.add(code)
        for constant in code.co_consts:
            if isinstance(constant, types.CodeType) and constant.co_name == '_invoke':
                add(constant)
    for function in functions:
        add(function.__code__)
        add(inspect.unwrap(function).__code__)
    if sys.monitoring.get_tool(TOOL_ID) is not None:
        raise RuntimeError('monitoring_tool_already_owned')
    sys.monitoring.use_tool_id(TOOL_ID, 'c100-saved-cas-boundaries')
    events = sys.monitoring.events
    sys.monitoring.register_callback(TOOL_ID, events.PY_START, start)
    sys.monitoring.register_callback(TOOL_ID, events.PY_RETURN, finish)
    MONITORED.update(codes)
    # PY_UNWIND is a global event in Python3.14; filter its callback to these exact codes.
    sys.monitoring.register_callback(TOOL_ID, events.PY_UNWIND, unwind)
    sys.monitoring.set_events(TOOL_ID, events.PY_UNWIND)
    for code in codes:
        sys.monitoring.set_local_events(TOOL_ID, code, events.PY_START | events.PY_RETURN)
    return codes


def main():
    global EVENT_STREAM, LEGACY_PROFILE
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=('core', 'guarded', 'guarded-legacy'), required=True)
    parser.add_argument('--head', required=True)
    args = parser.parse_args()
    manifest = json.loads((PACKET / 'manifest.json').read_text())
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == args.head
    for row in manifest['pins']:
        assert digest(ROOT / row['path']) == row['sha256'], row['path']
    # Only the authentic read-only facade may open the old store; no writer or copy.
    saved = json.loads((PACKET / 'saved-inputs.json').read_text())
    from polisyos.common.async_tools import get_shared_executor_profile
    from polisyos.core.artifacts import (
        ArtifactManifest, ArtifactRef, ArtifactStoreConfig, CoreToIRArtifactStoreAdapter, FileSystemCAS,
        artifact_ref_for_manifest, build_artifact_store, ensure_ir_artifact_store,
        validate_core_model_json_artifact, with_ambient_ownership_enforcement_if_supported,
    )
    from polisyos.core.contracts.execution_plan import MethodCatalogSnapshot
    from polisyos.core.observability import get_metrics, get_tracer
    from polisyos.core.security.tenant_context import tenant_scope
    from polisyos.foundry.methods import persist_method_catalog_snapshot
    from polisyos.ir.analytics.causal_capabilities import (
        load_causal_capability_contract, persist_causal_capability_contract,
    )
    from polisyos.ir.registry import CausalCapabilityContractRef
    from polisyos.runtime.http.resilience import BlockingDependencyGuard, guard_runtime_cas
    source_roots = {ROOT / row['cas_root'] for row in saved.values()}
    assert len(source_roots) == 1
    source = FileSystemCAS.open_existing_read_only(source_roots.pop())
    catalog_ref = ArtifactRef.model_validate(saved['catalog']['selected_ref'])
    capability_ref = CausalCapabilityContractRef.model_validate(saved['capability']['selected_ref'])
    with tenant_scope(None, tenant_id=saved['catalog']['tenant_id'], cell_id=saved['catalog']['cell_id']):
        catalog = validate_core_model_json_artifact(MethodCatalogSnapshot, source, catalog_ref)
        capability = load_causal_capability_contract(CoreToIRArtifactStoreAdapter(source), capability_ref)
    save('input-read-proof.json', {'pid': os.getpid(), 'source_facade': type(source).__qualname__,
         'catalog_selected_ref': catalog_ref.model_dump(mode='json'),
         'capability_selected_ref': capability_ref.model_dump(mode='json'),
         'catalog_generated_at_type': type(catalog.generated_at).__module__ + '.' + type(catalog.generated_at).__qualname__,
         'scope': 'Actual selected-profile Core/IR canonical readers; old facade has no writer interface.'})
    scratch = OUTPUT / 'scratch-cas'
    assert not scratch.exists()
    config = ArtifactStoreConfig.from_env().model_copy(update={'root': str(scratch)})
    assert config.backend == 'filesystem'
    base = build_artifact_store(config, metrics=get_metrics(), tracer=get_tracer())
    ambient = with_ambient_ownership_enforcement_if_supported(base)
    store = ambient if args.mode == 'core' else guard_runtime_cas(ambient)
    legacy = None
    assert sys.getprofile() is None and threading.getprofile() is None, 'unexpected_existing_profile'
    if args.mode == 'guarded-legacy':
        spec = importlib.util.spec_from_file_location('retained_aa_call_witness', ROOT / manifest['legacy_profile_path'])
        legacy = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(legacy)
        LEGACY_PROFILE = legacy.profile
    EVENT_STREAM = (OUTPUT / 'operation-events.jsonl').open('x')
    codes = install_local_observer([
        persist_causal_capability_contract, persist_method_catalog_snapshot,
        CoreToIRArtifactStoreAdapter.put_json, FileSystemCAS.put_json, FileSystemCAS.put_bytes,
        BlockingDependencyGuard.run, BlockingDependencyGuard._run_snapshot, Future.result, Future.cancel,
    ])
    save('observed-code-identities.json', [
        {'qualname': code.co_qualname, 'code_id': id(code), 'file': code.co_filename,
         'source_sha256': digest(Path(code.co_filename).resolve(strict=True)),
         'code_sha256': hashlib.sha256(marshal.dumps(code)).hexdigest()}
        for code in sorted(codes, key=lambda item: (item.co_filename, item.co_firstlineno))
    ])
    save('entry.json', {'pid': os.getpid(), 'ppid': os.getppid(), 'argv': sys.argv,
         'python': sys.version, 'mode': args.mode, 'config': config.model_dump(mode='json'),
         'thread_env': {k: v for k, v in os.environ.items() if k.endswith('_NUM_THREADS')},
         'cas_environment': {k: v for k, v in os.environ.items() if k.startswith('POLISYOS_RUNTIME_CAS_')},
         'shared_executor_profile': asdict(get_shared_executor_profile()),
         'guard_timeout_seconds': getattr(getattr(store, '_guard', None), '_timeout_seconds', None),
         'legacy_hook': legacy is not None, 'local_code_count': len(codes),
         'threads_before_operations': [{'name': thread.name, 'ident': thread.ident} for thread in threading.enumerate()],
         'scope': 'Saved typed producer inputs; no discovery/rebuild/Runtime/fit or old-store write.'})
    outcomes = []
    try:
        if legacy is not None:
            threading.setprofile(legacy.profile)
            sys.setprofile(legacy.profile)
        with tenant_scope(None, tenant_id=saved['catalog']['tenant_id'], cell_id=saved['catalog']['cell_id']):
            for label, operation in (
                ('capability', lambda: persist_causal_capability_contract(ensure_ir_artifact_store(store), capability)),
                ('catalog', lambda: persist_method_catalog_snapshot(store, catalog)),
            ):
                entered = time.monotonic_ns()
                outcome = {'operation': label, 'entered_ns': entered}
                try:
                    ref = operation()
                    outcome['returned_ref'] = ref.model_dump(mode='json')
                    assert str(ref.artifact_id) == saved[label]['artifact_id'], 'saved_payload_identity_changed'
                except BaseException as error:
                    outcome['exception_chain'] = exception_chain(error)
                    outcome['traceback'] = traceback.format_exc()
                outcome['exited_ns'] = time.monotonic_ns()
                outcomes.append(outcome)
                # Do not run a second producer after a failed first producer.
                if 'exception_chain' in outcome:
                    break
        # Observe outstanding actual worker completion, bounded without changing its deadline.
        completed_at_30s = wait_for_actual_futures()
        finished = time.monotonic_ns()
    finally:
        if legacy is not None:
            threading.setprofile(None)
            sys.setprofile(None)
        with CONDITION:
            sys.monitoring.set_events(TOOL_ID, 0)
            for code in codes:
                sys.monitoring.set_local_events(TOOL_ID, code, 0)
            sys.monitoring.free_tool_id(TOOL_ID)
            EVENT_STREAM.close()
    writer_codes = {id(FileSystemCAS.put_json.__code__), id(FileSystemCAS.put_bytes.__code__)}
    writer_events = [row for row in EVENTS if row.get('event') == 'enter' and row.get('code_id') in writer_codes]
    writer_hook_established = bool(writer_events) and all(
        row['legacy_profile_active'] if legacy is not None else row['profile_none'] for row in writer_events
    )
    persisted = []
    for name, row in saved.items():
        content = row['artifact_id'].split(':', 1)[1]
        blobs = list(scratch.rglob(content + '.blob'))
        assert len(blobs) <= 1
        blob = blobs[0] if blobs else None
        views = list(scratch.rglob(content + '.view.*.manifest.json'))
        selected = []
        with tenant_scope(None, tenant_id=saved['catalog']['tenant_id'], cell_id=saved['catalog']['cell_id']):
            for view in views:
                ref = artifact_ref_for_manifest(ArtifactManifest.model_validate_json(view.read_bytes()))
                selected.append({'path': str(view.relative_to(OUTPUT)), 'sha256': digest(view),
                                 'selected_ref': ref.model_dump(mode='json'),
                                 'real_core_verification_ok': base.verify(ref).ok})
        persisted.append({'operation': name, 'blob_present': blob is not None,
                          'blob_sha256': digest(blob) if blob is not None else None,
                          'selected_views': selected})
    for row in manifest['pins']:
        assert digest(ROOT / row['path']) == row['sha256'], row['path']
    save('result.json', {'pid': os.getpid(), 'mode': args.mode, 'outcomes': outcomes,
         'workers_quiescent': quiescent(), 'completed_within_initial_30s': completed_at_30s,
         'future_states': [{'id': key, 'done': value.done(), 'cancelled': value.cancelled()} for key, value in FUTURES.items()],
         'writer_enter_event_ids': [row['event_id'] for row in writer_events],
         'writer_hook_established': writer_hook_established, 'finished_ns': finished, 'persisted': persisted,
         'operation_failed': any('exception_chain' in row for row in outcomes),
         'scope': 'Diagnostic measurements only; no Runtime PASS or root-cause verdict.', 'closure_ids': []})
    return 0 if quiescent() and writer_hook_established else 2


if __name__ == '__main__':
    status = 1
    try:
        status = main()
    finally:
        # Retained same-process finite readset observer; compatibility exit field is CLI rc.
        observer = Path(os.environ['RUNTIME_AA_OBSERVER'])
        spec = importlib.util.spec_from_file_location('retained_cli_readset', observer)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        module.pytest_sessionfinish(None, status)
    raise SystemExit(status)
