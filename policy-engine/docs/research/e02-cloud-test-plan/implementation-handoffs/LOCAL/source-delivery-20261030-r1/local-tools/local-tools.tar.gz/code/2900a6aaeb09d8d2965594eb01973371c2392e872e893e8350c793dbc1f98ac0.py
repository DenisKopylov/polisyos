"""Read-only exact native admission. This does not launch pytest or import the product."""
from __future__ import annotations
import argparse, hashlib, json, shutil, subprocess
from pathlib import Path
R=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos');HERE=Path(__file__).resolve().parent
D=R/'policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=R)
def admit(path,expected):
 errors=[];plan=json.loads(path.read_text());binding=plan['c32_binding']
 if sha(path.read_bytes())!=expected:errors.append('plan hash mismatch')
 if path!=D/(plan['case_id']+'.json') or (D/plan['case_id']).exists():errors.append('not a fresh retained-runner plan')
 if git('symbolic-ref','--short','HEAD').decode().strip()!='codex/e02-unified-local-20261009':errors.append('wrong branch/detached')
 if git('rev-parse','HEAD').decode().strip()!=plan['source_head'] or git('rev-parse','HEAD^{tree}').decode().strip()!=plan['source_tree']:errors.append('source HEAD/tree changed')
 if git('status','--porcelain','--untracked-files=no'):errors.append('tracked/index state changed')
 for rel,pin in binding['committed_inputs'].items():
  p=R/rel
  if p.is_symlink() or not p.is_file() or sha(p.read_bytes())!=pin['sha256'] or git('show',plan['source_head']+':'+rel)!=p.read_bytes():errors.append('committed input mismatch: '+rel)
 for rel in binding['absent_ancestor_conftests']:
  if (R/rel).exists() or (R/rel).is_symlink():errors.append('ancestor conftest appeared: '+rel)
 for rel,h in binding['tool_pins'].items():
  if sha((R/rel).read_bytes())!=h:errors.append('retained tool changed: '+rel)
 review=plan.get('independent_mutant_review')
 if review is not None:
  p=Path(review['path'])
  if not p.is_file() or sha(p.read_bytes())!=review['sha256']:errors.append('independent mutant review unavailable/mismatch')
  else:
   actual=json.loads(p.read_text())
   if actual['verdict']!=review['verdict'] or actual['mutant_receipt_sha256']!=review['mutant_receipt_sha256'] or actual['reviewer_identity']!=review['reviewer_identity']:errors.append('independent mutant review binding mismatch')
 mpath=R/binding['packet_manifest'];m=json.loads(mpath.read_text())
 if sha(mpath.read_bytes())!=binding['packet_manifest_sha256']:errors.append('packet manifest mismatch')
 for rel,h in m['artifacts'].items():
  if sha((R/rel).read_bytes())!=h:errors.append('packet artifact mismatch: '+rel)
 disk=shutil.disk_usage(R)
 if disk.free<8*1024**3:errors.append('below provisional 8 GiB initial reserve; root must re-admit bounded growth, not delete data')
 return {'admitted':not errors,'errors':errors,'plan_sha256':sha(path.read_bytes()),'disk':{'total_bytes':disk.total,'free_bytes':disk.free},'resource_conditions':['Root holds source/index/ref lease across runner plus qualification; before/after snapshots alone cannot exclude restored edits','First unknown profile runs alone: 600 seconds / 2411724800-byte process-tree guard; not a measured promise','Root records current RAM, active CPU/numerical jobs and shared DB/ports/scratch admission separately; sufficient disk is not RAM admission'],'runtime':'UNRUN','closure_ids':[]}
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--plan',type=Path,required=True);p.add_argument('--sha256',required=True);a=p.parse_args();r=admit(a.plan,a.sha256);print(json.dumps(r,indent=2));raise SystemExit(0 if r['admitted'] else 125)
if __name__=='__main__':main()
