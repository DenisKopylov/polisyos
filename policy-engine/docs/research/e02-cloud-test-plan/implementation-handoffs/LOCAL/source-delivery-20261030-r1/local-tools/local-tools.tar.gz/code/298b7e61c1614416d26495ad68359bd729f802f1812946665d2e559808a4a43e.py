from pathlib import Path
import ast,difflib,hashlib,json,subprocess,tomllib
root=Path('LOCAL/raw/e02-execution-20261027/repairs/TC-closure-owner-r5')
base=root/'base-assembly'
if base.exists(): raise RuntimeError('base assembly exists; freeze is append-only')
intake=Path('LOCAL/raw/e02-execution-20261027/repairs/SQL-owner-chain-r3-intake-20261028-r1')
a=intake/'sql-61-manifest.json';b=intake/'v3-8-after-sql-r3-manifest.json'
sha=lambda x:hashlib.sha256(x).hexdigest()
assert sha(a.read_bytes())=='edd7e6677f01d48d4044888d92c06fe9e80447bb49b0eaed7e53417b55e8eaad'
assert sha(b.read_bytes())=='91c6b004732f6253245d9a14ff671dda88f46157a856122a99007d8d11aff518'
rows={x['path']:x for x in json.loads(a.read_text())['files']}
rows.update({x['path']:x for x in json.loads(b.read_text())['files']})
files=sorted(x for x in (root/'proposal/policy-engine').rglob('*') if x.is_file())
parts=[];entries=[]
for p in files:
 rel=p.relative_to(root/'proposal').as_posix();pre=root/'preimages'/rel; row=rows.get(rel)
 if row:
  old=pre.read_bytes(); assert sha(old)==row['post_sha256'],rel; source='sql-v3-virtual-union'
 else:
  try: old=subprocess.check_output(['git','show','0dfdb737fcbbcd2c1585a9ece543eefe1a38f87a:'+rel],stderr=subprocess.DEVNULL)
  except subprocess.CalledProcessError: old=None
  if old is not None: assert pre.exists() and pre.read_bytes()==old,rel
  else: assert not pre.exists(),rel
  source='0dfdb737' if old is not None else 'new'
 new=p.read_bytes()
 if p.suffix=='.py':ast.parse(new.decode())
 if p.suffix=='.toml':tomllib.loads(new.decode())
 if old is not None:
  target=base/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(old)
 parts.append(''.join(difflib.unified_diff((old or b'').decode().splitlines(True),new.decode().splitlines(True),fromfile=('/dev/null' if old is None else 'a/'+rel),tofile='b/'+rel)))
 entries.append({'path':rel,'preimage_sha256':None if old is None else sha(old),'postimage_sha256':sha(new),'preimage_source':source})
patch=''.join(parts).encode();(root/'source.diff').write_bytes(patch)
controls={n:sha((root/n).read_bytes()) for n in ('removal-registry-schema.diff','removal-trace-charge.diff','removal-debug-identity-check.diff')}
manifest={'status':'SOURCE_REVIEW_IN_PROGRESS','base_commit':'0dfdb737fcbbcd2c1585a9ece543eefe1a38f87a',
 'base_tree':'9f60f7e13759d686267fcff71e938410af780a4e','requires_sql_manifest_sha256':sha(a.read_bytes()),
 'requires_v3_manifest_sha256':sha(b.read_bytes()),'source_diff_sha256':sha(patch),'files':entries,'controls':controls,
 'runtime':'UNRUN','source_review':'IN_PROGRESS',
 'generated_companions_required':['runtime-quality-authority-envelope-v2-schema','public-surface-inventory'],
 'limitations':['one SQL-backed trusted built-in execution profile','unsupported roles and schemas refuse','selected CAS and strict trace budget, excludes DB and external SQL I/O','external SQL completeness/currentness and environment-manifest equivalence not established','all runtime and controls UNRUN']}
(root/'candidate-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('paths',len(files),'source_diff',sha(patch),'manifest',sha((root/'candidate-manifest.json').read_bytes()))
