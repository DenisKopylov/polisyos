from pathlib import Path
base=Path(__file__).parent/'postimages/policy-engine/src/polisyos/fabric/connectors/federation'
p=base/'composer.py';s=p.read_text()
s=s.replace('''    admit_output_envelope,''','''    admit_output_envelope,
    align_scalar_series,
    cast_series_losslessly,
    scalar_frame,
    scalar_rows,''')
s=s.replace('''    encode_scalar,''','''    encode_scalar,''') if False else s
# output caste reconciler must run for all strategies, after their actual operation
# but before an emitted/retained public result; originals remain held during casts.
a=s.index('        collector.finalize()',s.index('    def _compose'))
s=s[:a]+'''        result = self._restore_output_profile(result, sources, strategy, request)

'''+s[a:]
a=s.index('    def get_last_merge_summary(')
s=s[:a]+'''    def _restore_output_profile(
        self, result: pd.DataFrame, sources: list[tuple[pd.DataFrame, SourceMetadata]],
        strategy: CompositionStrategy, request: CompositionRequest,
    ) -> pd.DataFrame:
        """Project column dtypes only after lossless reconciliation to exact held values."""
        lineage = _read_persisted_lineage(result)
        if lineage is None:
            raise FederationError("Output profile lacks its owned cell basis")
        keys = (request.join_keys or []) if strategy == CompositionStrategy.JOIN else self._resolve_key_columns(request, self._resolve_time_dimension(request))
        columns = {}
        for column in result.columns:
            aggregation = (request.column_aggregation_funcs or {}).get(column) or request.aggregation_func or "median"
            if strategy == CompositionStrategy.CONSENSUS and column not in keys and aggregation in {"mean", "median"}:
                target = "float64"  # Explicit numeric transform, not source-row projection.
            else:
                templates = [frame[column].iloc[:0] for frame, _ in sources if column in frame.columns]
                target_dtype = pd.concat(templates, ignore_index=True).dtype
                if result[column].isna().any() and pd.api.types.is_integer_dtype(target_dtype) and not pd.api.types.is_extension_array_dtype(target_dtype):
                    target = "float64"  # Existing pandas null-extension output profile.
                elif result[column].isna().any() and pd.api.types.is_bool_dtype(target_dtype) and not pd.api.types.is_extension_array_dtype(target_dtype):
                    target = "object"
                else:
                    target = str(target_dtype)
            columns[column] = cast_series_losslessly(
                result[column], target, allow_exact_numeric_projection=True,
            )
        projected = pd.DataFrame(columns, index=result.index)
        _attach_persisted_lineage(projected, lineage, self._all_source_declarations, self._basis_status)
        return projected

''' +s[a:]
# Non-JOIN key dtype variation has no admitted typed identity normalization rule.
s=s.replace('''        total_rows = 0
        input_wire_bytes''','''        if strategy != CompositionStrategy.JOIN:
            profile_keys = self._resolve_key_columns(request, self._resolve_time_dimension(request))
            for key in profile_keys:
                declarations = {str(frame[key].dtype) for frame, _ in sources if key in frame.columns}
                if len(declarations) > 1:
                    raise SchemaIncompatibilityError("Mixed key dtypes require an explicit lossless identity profile")
        total_rows = 0
        input_wire_bytes''')
# UNION row selection uses original column scalars, never row-Series coercion.
s=s.replace('''            df_copy = df.copy()
''','''            df_copy = scalar_frame(df)
''',1)
s=s.replace('''            if len(group) == 1:
                row = group.iloc[0]
                resolved_rows.append(row.drop(labels=[source_column]))
                resolved_lineage.append(row_bases[int(row[source_column])])
                continue

            candidates = []
            for _, row in group.iterrows():''','''            group_rows = [dict(zip(group.columns, row, strict=True)) for row in scalar_rows(group)]
            if len(group_rows) == 1:
                row = group_rows[0]
                resolved_rows.append({column: value for column, value in row.items() if column != source_column})
                resolved_lineage.append(row_bases[int(row[source_column])])
                continue

            candidates = []
            for row in group_rows:''')
s=s.replace('''value=row.drop(labels=[source_column]).to_dict(),''','''value={column: value for column, value in row.items() if column != source_column},''')
s=s.replace('''            resolved_rows.append(pd.Series(resolution.chosen_candidate.value))
            resolved_lineage.append(row_bases[int(group.iloc[chosen][source_column])])''','''            resolved_rows.append(dict(resolution.chosen_candidate.value))
            resolved_lineage.append(row_bases[int(group_rows[chosen][source_column])])''')
s=s.replace('''empty = combined.drop(columns=[source_column]).iloc[:0].copy()''','''empty = scalar_frame(sources[0][0].iloc[:0])''')
s=s.replace('''        result = pd.DataFrame(resolved_rows)''','''        result = pd.DataFrame(resolved_rows, dtype=object)''',1)
# JOIN uses object-backed working columns; sidecars are read by exact columns.
s=s.replace('''        result_df = result_df.copy().reset_index(drop=True)''','''        result_df = scalar_frame(result_df).reset_index(drop=True)''',1)
s=s.replace('''            df_copy = df.copy().reset_index(drop=True)''','''            df_copy = scalar_frame(df).reset_index(drop=True)''',1)
s=s.replace('''            for _, row in result_df.iterrows():
                row_lineage = _lineage_map(row.get(lineage_column))
                row_right_lineage = _lineage_map(row.get(right_lineage_column))''','''            for left_basis, right_basis in zip(result_df[lineage_column], result_df[right_lineage_column], strict=True):
                row_lineage = _lineage_map(left_basis)
                row_right_lineage = _lineage_map(right_basis)''')
# OVERLAY object primary and object secondary alignment prevent fill coercion.
s=s.replace('''        result_df = result_df.copy()
''','''        result_df = scalar_frame(result_df)
''',1)
s=s.replace('''aligned = secondary_indexed[col].reindex(result_df.index)''','''aligned = align_scalar_series(secondary_indexed[col], result_df.index)''')
# CONSENSUS exact index carrier; numeric conversion only in explicit mean/median.
s=s.replace('''            indexed = df.set_index(key_columns, drop=True)''','''            indexed = scalar_frame(df).set_index(key_columns, drop=True)''')
s=s.replace('''[indexed[col].reindex(union_index) for indexed, _ in indexed_sources]''','''[align_scalar_series(indexed[col], union_index) for indexed, _ in indexed_sources]''')
s=s.replace('''            for position, idx in enumerate(values_df.index):''','''            for position, (idx, row_values) in enumerate(zip(values_df.index, scalar_rows(values_df), strict=True)):''')
s=s.replace('''enumerate(values_df.iloc[position])''','''enumerate(row_values)''')
s=s.replace('''        for idx, row in values_df.iterrows():''','''        for idx, row in zip(values_df.index, scalar_rows(values_df), strict=True):''')
# Mode never constructs a homogeneous all-row numeric result buffer.
a=s.index('        if agg_func == "mode":',s.index('    def _apply_consensus'));b=s.index('            for idx, row in zip',a)
s=s[:a]+'''        if agg_func == "mode":
            from collections import Counter

            selected_values = []
            for row in scalar_rows(values_df):
                non_null = [value for value in row if not _is_missing_scalar(value)]
                if not non_null:
                    selected_values.append(pd.NA)
                    continue
                frequencies = Counter(non_null)
                maximum = max(frequencies.values())
                tied = [value for value in non_null if frequencies[value] == maximum]
                try:
                    selected_values.append(min(tied))
                except TypeError:
                    selected_values.append(tied[0])
            result = pd.Series(selected_values, index=values_df.index, dtype=object)
''' +s[b:]
p.write_text(s)
p=base/'artifact.py';s=p.read_text()
s=s.replace('''    bounded_encode,''','''    bounded_encode,
    cast_series_losslessly,''')
s=s.replace('''        frame[column] = frame[column].astype(dtype)''','''        frame[column] = cast_series_losslessly(frame[column], dtype)''')
s=s.replace('''    basis_status: FederationBasisStatus
    assurance''','''    basis_status: FederationBasisStatus
    source_declarations: tuple[tuple[str, str], ...]
    assurance''')
s=s.replace('''    return VerifiedFederationResult(recomputed, tuple(lineage["rows"]), _summary(composer), status)''','''    declarations = tuple((token, bounded_encode(declaration).decode())
                         for token, declaration in sorted(lineage["source_declarations"].items()))
    return VerifiedFederationResult(recomputed, tuple(lineage["rows"]), _summary(composer), status, declarations)''')
p.write_text(s)
