def _build_dfk_02_published_catalog_fixture(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    """Use the public full-pipeline fixture for DFK-02 consumer proofs."""
    import importlib.util
    import sys

    fixture_path = (
        Path(__file__).parents[1] / "runtime" / "http" / "_published_catalog_fixture.py"
    )
    module_name = "_e02_dfk_02_published_catalog_fixture"
    spec = importlib.util.spec_from_file_location(module_name, fixture_path)
    if spec is None or spec.loader is None:
        raise AssertionError("published catalog fixture module spec is unavailable")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module.build_published_catalog_fixture(tmp_path, monkeypatch)


def test_warm_and_fresh_catalog_consumers_reconcile_same_id_source_policy(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Recompute producer evidence before exercising warm and fresh consumers."""
    import json
    import os

    import yaml

    from polisyos.core.contracts.control import DataNeed, DataResolveRequest
    from polisyos.data_forge.domains.catalog.batch.config import DatasetBatchConfig
    from polisyos.data_forge.domains.catalog.batch.pipeline import (
        current_catalog_publish_receipt,
        current_catalog_report_basis,
        run_content_stage_with_receipt,
    )
    from polisyos.data_forge.domains.catalog.knowledge.search import DatasetCatalogGraph
    from polisyos.data_forge.domains.catalog.registry import load_catalog_source_registry
    from polisyos.data_forge.read_api import catalog as catalog_read_api
    from polisyos.fabric.retrieval.service import RetrievalService

    fixture = _build_dfk_02_published_catalog_fixture(tmp_path, monkeypatch)
    reader_graphs: list[DatasetCatalogGraph] = []
    registry_path = tmp_path / "registry.yaml"
    monkeypatch.setattr(
        catalog_read_api,
        "load_catalog_source_registry",
        lambda: load_catalog_source_registry(registry_path),
    )
    monkeypatch.setenv("POLISYOS_RETRIEVAL_FASTLANE_ENABLED", "0")

    try:
        stage_state = json.loads(
            (fixture.snapshot_root / "datasets" / "manifests" / "stage_state.json").read_text(
                encoding="utf-8"
            )
        )
        producer_config_snapshot = stage_state["qc"]["input_basis"]["config"][
            "effective_producer_config"
        ]
        config = DatasetBatchConfig.from_producer_config_snapshot(producer_config_snapshot)
        assert config is not None
        config.run_profile = "prod_core_blocking"

        registry = yaml.safe_load(registry_path.read_text(encoding="utf-8"))
        worldbank_rows = [
            row
            for row in registry["sources"]
            if row.get("name", row.get("source_id")) == "worldbank"
        ]
        assert len(worldbank_rows) == 1
        assert worldbank_rows[0]["enabled"] is True
        assert worldbank_rows[0]["publish_blocking"] is True
        original_registry_bytes = registry_path.read_bytes()

        def publish_current_basis() -> None:
            run_content_stage_with_receipt(config, "benchmark")
            run_content_stage_with_receipt(config, "qc")
            assert current_catalog_report_basis(config)["state"] == "current"
            run_content_stage_with_receipt(config, "publish")
            receipt = current_catalog_publish_receipt(
                config.db_path, run_profile=config.run_profile
            )
            assert receipt["state"] == "current"
            assert receipt["profile_input_coverage_state"] == "established"

        def set_worldbank_blocking(blocking: bool) -> bytes:
            payload = yaml.safe_load(registry_path.read_text(encoding="utf-8"))
            rows = [
                row
                for row in payload["sources"]
                if row.get("name", row.get("source_id")) == "worldbank"
            ]
            assert len(rows) == 1
            rows[0]["publish_blocking"] = blocking
            registry_path.write_text(
                yaml.safe_dump(payload, sort_keys=False),
                encoding="utf-8",
            )
            return registry_path.read_bytes()

        publish_current_basis()
        assert current_catalog_publish_receipt(
            config.db_path, run_profile="prod_core_blocking"
        )["state"] == "current"

        def open_consumer(label: str) -> RetrievalService:
            graph = DatasetCatalogGraph(
                fixture.database_path,
                fixture.snapshot_root / "datasets",
                overlay_path=tmp_path / f"missing-{label}-overlay.duckdb",
            )
            reader_graphs.append(graph)
            return RetrievalService(
                curated_dir=tmp_path / f"curated-{label}",
                dataset_catalog=graph,
                profiles=fixture.profile_registry,
            )

        request = DataResolveRequest(
            data_needs=[
                DataNeed(
                    metric="scope_metric",
                    geography="DEU",
                    time_start="2025",
                    time_end="2025",
                )
            ],
            mode="fastlane",
            allow_explore_fallback=False,
        )

        def plan_ids(service: RetrievalService) -> list[str]:
            return [
                plan.dataset_id
                for plan in service.resolve(request, run_profile=config.run_profile).fetch_plans
            ]

        warm = open_consumer("warm")
        assert plan_ids(warm) == ["scope_dataset"]

        previous_stat = registry_path.stat()
        changed_registry_bytes = set_worldbank_blocking(False)
        os.utime(
            registry_path,
            ns=(previous_stat.st_atime_ns, previous_stat.st_mtime_ns + 1_000_000),
        )
        assert changed_registry_bytes != original_registry_bytes
        fresh = open_consumer("fresh")
        assert current_catalog_publish_receipt(
            config.db_path, run_profile="prod_core_blocking"
        )["state"] != "current"
        assert plan_ids(warm) == []
        assert plan_ids(fresh) == []

        publish_current_basis()
        assert plan_ids(warm) == []
        assert plan_ids(fresh) == []

        previous_stat = registry_path.stat()
        restored_registry_bytes = set_worldbank_blocking(True)
        os.utime(
            registry_path,
            ns=(previous_stat.st_atime_ns, previous_stat.st_mtime_ns + 1_000_000),
        )
        assert restored_registry_bytes != changed_registry_bytes
        assert current_catalog_publish_receipt(
            config.db_path, run_profile="prod_core_blocking"
        )["state"] != "current"
        publish_current_basis()
        assert plan_ids(warm) == ["scope_dataset"]
        assert plan_ids(fresh) == ["scope_dataset"]

        registry_path.write_text("version: 1\nsources: invalid\n", encoding="utf-8")
        with pytest.raises(ValueError):
            plan_ids(warm)
        with pytest.raises(ValueError):
            plan_ids(fresh)
    finally:
        for graph in reader_graphs:
            graph.close()
        fixture.producer_graph.close()
        fixture.close()


def test_fresh_catalog_consumer_fails_closed_on_disabled_seed_without_index_mutation(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Exercise disabled seed closure through a real fresh catalog reader."""
    import copy
    import hashlib
    import yaml

    from polisyos.core.contracts.control import DataNeed, DataResolveRequest
    from polisyos.data_forge.domains.catalog.batch.pipeline import current_catalog_publish_receipt
    from polisyos.data_forge.domains.catalog.knowledge.search import DatasetCatalogGraph
    from polisyos.data_forge.read_api import catalog as catalog_read_api
    from polisyos.data_forge.domains.catalog.registry import load_catalog_source_registry
    from polisyos.fabric.retrieval.service import RetrievalService

    fixture = _build_dfk_02_published_catalog_fixture(tmp_path / "producer", monkeypatch)
    registry_path = tmp_path / "producer" / "registry.yaml"
    consumer_root = tmp_path / "consumer-policies"
    consumer_root.mkdir()
    disabled_registry_path = consumer_root / "disabled-seed.yaml"
    removed_seed_registry_path = consumer_root / "removed-seed-edge.yaml"
    producer_registry_bytes = registry_path.read_bytes()
    index_root = fixture.snapshot_root / "datasets"

    def physical_index_identity() -> tuple[tuple[str, int, str], ...]:
        return tuple(
            (
                str(path.relative_to(index_root)),
                path.stat().st_size,
                hashlib.sha256(path.read_bytes()).hexdigest(),
            )
            for path in sorted(index_root.rglob("*"))
            if path.is_file()
        )

    consumer_payload = yaml.safe_load(producer_registry_bytes)
    worldbank_rows = [
        row
        for row in consumer_payload["sources"]
        if row.get("name", row.get("source_id")) == "worldbank"
    ]
    assert len(worldbank_rows) == 1
    worldbank_rows[0]["seed_from"] = "i4_disabled_seed"
    consumer_payload["sources"].append(
        {
            "name": "i4_disabled_seed",
            "family": "fixture",
            "wave": "A",
            "endpoint": "https://example.invalid/i4-disabled-seed",
            "connector_id": "fixture.disabled_seed",
            "enabled": False,
            "execution_tier": "catalog",
            "run_lane": "catalog",
            "publish_blocking": False,
        }
    )
    disabled_registry_path.write_text(
        yaml.safe_dump(consumer_payload, sort_keys=False),
        encoding="utf-8",
    )
    removed_seed_payload = copy.deepcopy(consumer_payload)
    removed_worldbank = next(
        row
        for row in removed_seed_payload["sources"]
        if row.get("name", row.get("source_id")) == "worldbank"
    )
    removed_worldbank.pop("seed_from")
    removed_seed_registry_path.write_text(
        yaml.safe_dump(removed_seed_payload, sort_keys=False),
        encoding="utf-8",
    )

    monkeypatch.setenv("POLISYOS_RETRIEVAL_FASTLANE_ENABLED", "0")
    request = DataResolveRequest(
        data_needs=[
            DataNeed(
                metric="scope_metric",
                geography="DEU",
                time_start="2025",
                time_end="2025",
            )
        ],
        mode="fastlane",
        allow_explore_fallback=False,
    )

    def resolve_fresh(label: str, selected_registry: Path):
        monkeypatch.setattr(
            catalog_read_api,
            "load_catalog_source_registry",
            lambda: load_catalog_source_registry(selected_registry),
        )
        graph = DatasetCatalogGraph(
            fixture.database_path,
            index_root,
            overlay_path=tmp_path / f"missing-{label}-overlay.duckdb",
        )
        try:
            service = RetrievalService(
                curated_dir=tmp_path / f"curated-{label}",
                dataset_catalog=graph,
                profiles=fixture.profile_registry,
            )
            return service.resolve(request, run_profile="prod_full")
        finally:
            graph.close()

    try:
        assert current_catalog_publish_receipt(
            fixture.database_path, run_profile="prod_full"
        )["state"] == "current"
        original_index_identity = physical_index_identity()

        with pytest.raises(catalog_read_api.CatalogSelectionError) as caught:
            resolve_fresh("disabled-seed", disabled_registry_path)
        assert caught.value.code == "dependency_disabled"
        assert caught.value.detail == "source=worldbank/seed=i4_disabled_seed"
        assert physical_index_identity() == original_index_identity
        assert registry_path.read_bytes() == producer_registry_bytes

        wrong_registry = resolve_fresh("wrong-registry-control", registry_path)
        assert [plan.dataset_id for plan in wrong_registry.fetch_plans] == ["scope_dataset"]
        assert physical_index_identity() == original_index_identity
        assert registry_path.read_bytes() == producer_registry_bytes

        removed_seed = resolve_fresh("removed-seed-control", removed_seed_registry_path)
        assert [plan.dataset_id for plan in removed_seed.fetch_plans] == ["scope_dataset"]
        assert physical_index_identity() == original_index_identity
        assert registry_path.read_bytes() == producer_registry_bytes
        assert current_catalog_publish_receipt(
            fixture.database_path, run_profile="prod_full"
        )["state"] == "current"
    finally:
        fixture.producer_graph.close()
        fixture.close()
