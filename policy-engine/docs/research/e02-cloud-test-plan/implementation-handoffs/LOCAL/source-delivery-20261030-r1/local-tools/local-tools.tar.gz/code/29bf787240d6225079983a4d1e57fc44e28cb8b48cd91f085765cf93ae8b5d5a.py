"""Write a single source-removal control in scratch; never execute product code."""
from __future__ import annotations
import argparse
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'postimages/policy-engine/src/polisyos/scientist/agent/vector_memory.py'
NPZ_SOURCE = ROOT / 'postimages/policy-engine/src/polisyos/foundry/execute/_internal/snapshots/__init__.py'
TRANSFER_SOURCE = ROOT / 'postimages/policy-engine/src/polisyos/scientist/methods/search/strategies/transfer.py'


def once(source: str, old: str, new: str) -> str:
    if source.count(old) != 1:
        raise ValueError('mutation site is not unique')
    return source.replace(old, new, 1)


def remove_lock(source: str, name: str) -> str:
    tree = ast.parse(source)
    cls = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == 'VectorMemoryStore')
    fn = next(node for node in cls.body if isinstance(node, ast.FunctionDef) and node.name == name)
    locks = [node for node in fn.body if isinstance(node, ast.With) and len(node.items) == 1
             and ast.unparse(node.items[0].context_expr) == 'self._generation_lock']
    if len(locks) != 1 or locks[0].end_lineno is None:
        raise ValueError('generation lock not unique')
    lock = locks[0]
    lines = source.splitlines(keepends=True)
    return ''.join(lines[:lock.lineno-1] + [line[4:] if line.strip() else line for line in lines[lock.lineno:lock.end_lineno]] + lines[lock.end_lineno:])


def build(source: str, kind: str) -> str:
    if kind == 'query_lock':
        return remove_lock(source, 'query')
    if kind == 'save_lock':
        return remove_lock(source, 'save_to_artifact')
    if kind == 'metadata_copy_hook':
        source = once(source, 'import hashlib\n', 'import hashlib\nfrom copy import deepcopy\n')
        return once(source, '    return _owned_json(value)\n', '    return deepcopy(value)\n')
    if kind == 'reserved_metadata_tag':
        return once(source, '        if "_type" in value:\n            raise ValueError("Vector memory JSON metadata contains reserved key _type")', '        if False and "_type" in value:\n            raise ValueError("Vector memory JSON metadata contains reserved key _type")')
    if kind == 'label_membership':
        source = once(source, 'if labels != set(range(count)):', 'if False and labels != set(range(count)):')
        return once(source, 'if len(labels) != expected_count or set(labels) != set(range(expected_count)):', 'if False and (len(labels) != expected_count or set(labels) != set(range(expected_count))):')
    if kind == 'selected_view_read':
        return once(source, 'index_bytes = store.get_bytes(ref)', 'index_bytes = store.get_bytes(ref.artifact_id)')
    if kind == 'index_lineage':
        return once(source, 'if [item for item in bundle_manifest.inputs if item.role == _INDEX_ROLE] != [edge]:', 'if False and [item for item in bundle_manifest.inputs if item.role == _INDEX_ROLE] != [edge]:')
    if kind == 'rollback_poison':
        return once(source, '                except BaseException as exc:\n                    raise RuntimeError(', '                except BaseException as exc:\n                    self._generation = generation\n                    raise RuntimeError(')
    if kind == 'deleted_row':
        return once(source, 'if raw[row + offset0 + 2] & 1:', 'if False and raw[row + offset0 + 2] & 1:')
    if kind == 'native_dimension':
        return once(source, 'or label_offset != data_offset + dim * 4', 'or False')
    if kind == 'row_lineage':
        return once(source, 'if [item for item in bundle_manifest.inputs if item.role == _ROWS_ROLE] != [edge]:', 'if False and [item for item in bundle_manifest.inputs if item.role == _ROWS_ROLE] != [edge]:')
    if kind == 'row_normalization':
        return once(source, 'candidate_index.add_items([_owned_vector(row)], [idx])', 'candidate_index.add_items([row], [idx])')
    if kind == 'row_selected_view':
        return once(source, 'manifest_bytes = reader.get_raw_manifest_bytes_bounded(\n            ref, max_manifest_bytes=_MAX_MANIFEST_BYTES\n        )', 'manifest_bytes = reader.get_raw_manifest_bytes_bounded(\n            ref.artifact_id, max_manifest_bytes=_MAX_MANIFEST_BYTES\n        )')
    if kind == 'row_capacity':
        tree = ast.parse(source)
        cls = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == 'VectorMemoryStore')
        fn = next(node for node in cls.body if isinstance(node, ast.FunctionDef) and node.name == 'load_from_artifact')
        matches = [node for node in ast.walk(fn) if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name) and node.value.func.id == '_require_row_resource_bounds']
        if len(matches) != 1 or matches[0].end_lineno is None: raise ValueError('row capacity gate not unique')
        node = matches[0]; lines = source.splitlines(keepends=True)
        return ''.join(lines[:node.lineno-1] + ['            pass\n'] + lines[node.end_lineno:])
    if kind == 'native_refusal':
        source = once(source, 'raise UntrustedNativeVectorBundleError(reason)', 'pass')
        return once(source, 'if not allow_trusted_native:\n            raise UntrustedNativeVectorBundleError("unsupported_vector_bundle_format")', 'if False and not allow_trusted_native:\n            raise UntrustedNativeVectorBundleError("unsupported_vector_bundle_format")')
    if kind == 'known_key_ann':
        return once(source, 'meta = self._index.lookup_metadata(run_id)', 'meta = next((row for key, _, row in self._index.query([0.0] * self._index.dim, top_k=1000) if key == run_id), None)')
    if kind == 'npz_pickle':
        tree = ast.parse(source)
        fn = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'read_numeric_npz_bounded')
        if fn.end_lineno is None: raise ValueError('npz decoder span unavailable')
        lines = source.splitlines(keepends=True)
        replacement = ('def read_numeric_npz_bounded(blob, *, names, **_kwargs):\n'
                       '    with np.load(BytesIO(blob), allow_pickle=True) as data:\n'
                       '        return tuple(data[name] for name in names)\n\n')
        return ''.join(lines[:fn.lineno-1]) + replacement + ''.join(lines[fn.end_lineno:])
    if kind == 'npz_central_count':
        start = source.index('    cursor = central_offset\n', source.index('def _read_npz_entry_count('))
        end = source.index('    return actual_entries\n', start) + len('    return actual_entries\n')
        return source[:start] + '    return total_entries\n' + source[end:]
    raise ValueError('unknown mutant')


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('kind', choices=('query_lock','save_lock','metadata_copy_hook','label_membership',
        'selected_view_read','index_lineage','rollback_poison','deleted_row','native_dimension',
        'row_lineage','row_normalization','row_selected_view','row_capacity','reserved_metadata_tag','native_refusal','known_key_ann','npz_pickle','npz_central_count'))
    kind = parser.parse_args().kind
    output = ROOT / 'mutants' / kind / ('snapshots.py' if kind.startswith('npz_') else 'transfer.py' if kind == 'known_key_ann' else 'vector_memory.py')
    output.parent.mkdir(parents=True, exist_ok=True)
    source = NPZ_SOURCE if kind.startswith('npz_') else TRANSFER_SOURCE if kind == 'known_key_ann' else SOURCE
    text = build(source.read_text(), kind)
    ast.parse(text)
    output.write_text(text)
    print(output)

if __name__ == '__main__':
    main()
