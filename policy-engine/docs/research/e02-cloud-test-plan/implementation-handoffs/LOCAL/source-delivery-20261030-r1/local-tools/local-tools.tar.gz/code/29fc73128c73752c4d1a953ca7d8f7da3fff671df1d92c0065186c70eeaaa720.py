"""Recompute the bounded selected-source reader set without importing product."""
from pathlib import Path
import ast
import hashlib
import json

OUT = Path(__file__).resolve().parent
PREVIOUS = OUT.parent / "C78-chain-r6"
manifest = json.loads((PREVIOUS / "manifest.json").read_text())
paths = [row["path"] for row in manifest["files"] if row["role"] == "mechanism"]
readers = {"read_calibration_source", "read_calibration_model_source", "read_calibration_config_source", "read_calibration_registry_source", "read_calibration_report_source", "read_calibration_execution_input_basis_source"}
def collect(base):
    rows = []
    digest = hashlib.sha256()
    for path in paths:
        source = base / "postimages" / path
        data = source.read_bytes()
        sha = hashlib.sha256(data).hexdigest()
        digest.update((path + "\0" + sha + "\n").encode())
        text = data.decode()
        tree = ast.parse(text)
        parent = {child: node for node in ast.walk(tree) for child in ast.iter_child_nodes(node)}
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call) or not isinstance(node.func, ast.Name) or node.func.id not in readers:
                continue
            owner, names = node, []
            while owner in parent:
                owner = parent[owner]
                if isinstance(owner, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    names.append(owner.name)
            args = {key.arg: ast.unparse(key.value) for key in node.keywords}
            function = ".".join(reversed(names))
            reader = node.func.id
            model = args.get("model")
            if reader == "read_calibration_model_source":
                domain, boundary = "declared Pydantic JSON model", "required actual strict Core owner before decoder"
            elif reader == "read_calibration_config_source":
                domain, model, boundary = "calibration config", "CalibrationConfig", "paired producer schema/version and strict model owner"
            elif reader == "read_calibration_registry_source":
                domain, model, boundary = "registry composition", "RegistryBundlePayload + actual consumed member types", "Core dataclass denominator and strict member owners"
            elif reader == "read_calibration_report_source":
                domain, model, boundary = "calibration report", "CalibrationReport", "strict model and explicit selected version relation"
            elif reader == "read_calibration_execution_input_basis_source":
                domain, model, boundary = "execution-input basis", "CalibrationExecutionInputBasis", "strict model, version and selected-input reconciliation"
            elif "_ordered_json_payload" in function or args.get("role") == "'parameter_source'":
                domain, boundary = "raw mechanism parameter map", "canonical payload/digest; dynamic mechanism contract remains its owner"
            elif args.get("role") == "'state_blob'":
                domain, boundary = "binary state blob", "generic CAS integrity plus exact selected reference; actual Snapshot/NPZ consumer"
            elif "_selected_manifest" in function:
                domain, boundary = "explicit parameter-map metadata", "model=None branch only; exact selected manifest output; known envelope branch calls required-model API"
            elif "read_calibration_registry_source.decode" in function:
                domain, boundary = "registry member preflight", "canonical bytes only; required strict member pass follows before return"
            elif "_selected_input_ref" in function:
                domain, boundary = "exact reference reconstruction", "exact selected reference only, no domain model claim"
            else:
                domain, boundary = "unclassified raw call", "REVIEW REQUIRED"
            rows.append(dict(path=path, sha256=sha, line=node.lineno, owner=function, reader=reader, domain=domain, model=model, boundary=boundary, arguments=args))
    return dict(mechanism_python_files=len(paths), file_set_sha256=digest.hexdigest(), direct_calls=len(rows), rows=sorted(rows, key=lambda row: (row["path"], row["line"])))
old, current = collect(PREVIOUS), collect(OUT)
original = json.loads((PREVIOUS / "consumer-call-matrix.json").read_text())["prior_r5"]
assert old["direct_calls"] == 45
for row in current["rows"]:
    if row["reader"] != "read_calibration_source":
        continue
    decoder = ast.parse(row["arguments"]["decoder"], mode="eval").body
    assert isinstance(decoder, ast.Lambda) and isinstance(decoder.body, ast.Name), row
    positions = [arg.arg for arg in decoder.args.args]
    position = positions.index(decoder.body.id)
    row["actual_raw_projection"] = (
        "exact selected ArtifactRef metadata",
        "exact selected ArtifactManifest metadata",
        "unchanged selected Core-native payload or bytes",
    )[position]
assert all(row["domain"] != "unclassified raw call" for row in current["rows"])
path = OUT / "postimages/policy-engine/src/polisyos/scientist/nodes/builtins/simulate/propagate_uncertainty.py"
tree = ast.parse(path.read_text())
spec = next(node for node in ast.walk(tree) if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "source_specs" for target in node.targets))
models = [dict(field=ast.literal_eval(row.elts[0]), candidate_role=ast.literal_eval(row.elts[1]), basis_role=ast.literal_eval(row.elts[3]), model=ast.unparse(row.elts[4])) for row in spec.value.elts]
record = dict(status="source-only bounded caller classification, not runtime/keyword/count acceptance", original_r5_raw=original, prior_r6=old, current_r7=current, response_declared_models=models, additional_actual_owner_boundaries=["Producer selected model capture now uses required model intake and common availability classification.", "Legacy scalar basis display never qualifies source.", "Other registered IR uncertainty and non-calibration snapshot/metrics owners retain their existing policies; no repository-wide coercion-free claim."], limits=["All 12 mechanism Python postimages, direct Name calls only; aliases/dynamic/outside paths not proved absent.", "Model, raw, reference, binary and legacy boundaries are actual semantic routes, not a model-keyword gate.", "All actual-node/falsifier/removal behavior remains UNRUN."])
(OUT / "consumer-call-matrix.json").write_text(json.dumps(record, indent=2) + "\n")
lines = ["# R7 complete selected-source caller matrix\n", "All 12 mechanism Python postimages are walked. Original 27 raw calls, prior/current 45 named-reader calls and the six current raw calls are navigation, never a capability or PASS gate. Runtime remains UNRUN.\n", "| Owner / line | Reader | Domain / actual model | Boundary |\n", "| --- | --- | --- | --- |\n"]
for row in current["rows"]:
    label = row["path"].removeprefix("policy-engine/src/polisyos/") + ":" + str(row["line"]) + " `" + row["owner"] + "`"
    model = (row["model"] or row.get("actual_raw_projection", "no domain DTO")).replace("|", "\\|")
    lines.append("| " + label + " | `" + row["reader"] + "` | " + row["domain"] + "; `" + model + "` | " + row["boundary"] + " |\n")
lines += ["\nResponse declares these actual source models:\n\n", "| Basis role | Model |\n", "| --- | --- |\n"]
for row in models:
    lines.append("| " + row["basis_role"] + " | `" + row["model"] + "` |\n")
lines += ["\nConfig admission is paired with its actual producer. Typed API requires a BaseModel owner; raw API accepts no model. Its single result owner is independent of media: unchanged Core-native payload/bytes or exact selected ArtifactRef/ArtifactManifest. Direct/nested domain DTOs, changed payloads and foreign metadata refuse. Core owns native typed values; no new JSON-only codec is introduced.\n", "\nProducer selected-model comparisons use the same required Core owner. Legacy scalar basis display is not qualification. Separate registered IR uncertainty and non-calibration snapshot/metrics readers retain their own policies; this is not a repository-wide parser claim. Alias/dynamic calls outside the stated set are not proved absent.\n", "\nconsumer-call-matrix.json binds exact source hashes and all arguments/models. The actual scalar2.0 two-node corruption test and real producer NPZ/raw-result mutation supply behavior; this AST matrix never substitutes for it.\n"]
(OUT / "CONSUMERS.md").write_text("".join(lines))
print(json.dumps(dict(original_raw=original["direct_calls"], prior=old["direct_calls"], current=current["direct_calls"], raw_current=sum(row["reader"] == "read_calibration_source" for row in current["rows"]), mechanism_python_files=len(paths), response_models=len(models))))
