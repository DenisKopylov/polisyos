"""Prepare a RAW-only catalog-oracle proposal without importing product code.

This inspects retained runtime evidence, source bytes and Python ASTs. It does
not run pytest, the product serializer, a registry, or any numerical library.
"""

from __future__ import annotations

import ast
from collections import Counter
import difflib
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parents[5]
OUT = Path(__file__).resolve().parent
RUN = Path(
    "policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/"
    "root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/"
    "deep-task-status-audit-20261027-r1/r3-original14-current-source-r1-20261028"
)
READSET = RUN / "readsets/input-readset-84601.json"
TARGET = Path("policy-engine/tests/unit/runtime/http/test_nl_pipeline_cost_projection.py")
TEST_NAME = "test_simulated_nl_producer_costs_settle_and_capture_four_origins"
RUNTIME_BASE = "3babffa0d176d3fb9c478865f14136ebe1bc54c4"
ARTIFACT_HEX = "e95b1abb210ec4ca65c6d3a83f8990453524f5ad1ac813ba78168622d3335bd5"
CAS = RUN / "basetemp/test_simulated_nl_producer_cos0/.polisyos/artifacts/sha256"
BLOB = CAS / "e9/5b" / (ARTIFACT_HEX + ".blob")
SELECTED_MANIFEST = CAS / "e9/5b" / (
    ARTIFACT_HEX + ".view.8cc2aefa71d766c6ec7f35cc09380cf07460bafaa05245237fa5b9f5ac5a2c83.manifest.json"
)
SOURCES = (
    TARGET,
    Path("policy-engine/src/polisyos/foundry/methods/catalog/snapshot.py"),
    Path("policy-engine/src/polisyos/core/contracts/execution_plan.py"),
    Path("policy-engine/src/polisyos/foundry/methods/base.py"),
    Path("policy-engine/src/polisyos/foundry/methods/selection/registry.py"),
    Path("policy-engine/src/polisyos/foundry/methods/catalog/causal/dynamic_graph_dscm.py"),
    Path("policy-engine/src/polisyos/common/canonical.py"),
    Path("policy-engine/src/polisyos/core/artifacts/store.py"),
    Path("policy-engine/src/polisyos/core/artifacts/canonical_profile.py"),
    Path("policy-engine/src/polisyos/runtime/http/services/control/nl_pipeline.py"),
    Path(
        "policy-engine/docs/plans/active/agent-packages/"
        "PolicyOS_E02_Combined_Agent_Package/source/B_r19_original.md"
    ),
)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git(*args: str) -> bytes:
    return subprocess.check_output(["git", *args], cwd=ROOT)


def dump(name: str, value: object) -> None:
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def top_function(data: bytes) -> ast.AsyncFunctionDef | ast.FunctionDef:
    return next(
        node
        for node in ast.parse(data).body
        if isinstance(node, (ast.AsyncFunctionDef, ast.FunctionDef)) and node.name == TEST_NAME
    )


def main() -> None:
    # Pin the attached shared checkout without enumerating unrelated untracked work.
    branch = git("symbolic-ref", "--short", "HEAD").decode().strip()
    head = git("rev-parse", "HEAD").decode().strip()
    tree = git("rev-parse", "HEAD^{tree}").decode().strip()
    runtime_tree = git("rev-parse", RUNTIME_BASE + "^{tree}").decode().strip()
    readset_bytes = (ROOT / READSET).read_bytes()
    readset = json.loads(readset_bytes)
    loaded = {entry["path"]: entry for entry in readset["modules"]}
    pins = []
    runtime_source = {}
    for path in SOURCES:
        current = (ROOT / path).read_bytes()
        original = git("show", RUNTIME_BASE + ":" + str(path))
        runtime_source[str(path)] = original
        observed = loaded.get(str(path.relative_to("policy-engine")))
        if observed is not None:
            assert sha(original) == observed["sha256"], path
        pins.append(
            {
                "path": str(path),
                "runtime_git_blob": git("rev-parse", RUNTIME_BASE + ":" + str(path)).decode().strip(),
                "runtime_sha256": sha(original),
                "runtime_observed_sha256": None if observed is None else observed["sha256"],
                "runtime_readset_observed": observed is not None,
                "current_git_blob": git("rev-parse", "HEAD:" + str(path)).decode().strip(),
                "current_worktree_sha256": sha(current),
                "current_equals_runtime_bytes": current == original,
            }
        )
    before = (ROOT / TARGET).read_bytes()
    assert before == git("show", "HEAD:" + str(TARGET))
    before_text = before.decode()
    runtime_test = runtime_source[str(TARGET)]
    assert ast.dump(top_function(before)) == ast.dump(top_function(runtime_test))
    old = "        assert persisted_catalog == expected_snapshot\n"
    new = (
        "        # Rich metadata uses CAN.2 sequence normalization; compare every wire value.\n"
        "        assert persisted_catalog.model_dump(mode=\"json\") == expected_snapshot.model_dump(\n"
        "            mode=\"json\"\n"
        "        )\n"
    )
    assert before_text.count(old) == 1
    after = before_text.replace(old, new).encode()
    before_ast = ast.parse(before)
    after_ast = ast.parse(after)
    assert len(before_ast.body) == len(after_ast.body)
    changed_top_level = []
    for left, right in zip(before_ast.body, after_ast.body, strict=True):
        if ast.dump(left) != ast.dump(right):
            changed_top_level.append(getattr(left, "name", type(left).__name__))
    assert changed_top_level == [TEST_NAME]
    left_func = top_function(before)
    right_func = top_function(after)
    assert ast.dump(left_func.args) == ast.dump(right_func.args)
    assert [ast.dump(x) for x in left_func.decorator_list] == [ast.dump(x) for x in right_func.decorator_list]
    assert len(left_func.body) == len(right_func.body)
    # This equality lives inside a for loop. Compare after substituting only its
    # one known expression, so all other assertions and control flow are retained.
    expected_after = before_text.replace(old, new)
    assert after.decode() == expected_after
    patch = "".join(
        difflib.unified_diff(
            before_text.splitlines(keepends=True),
            after.decode().splitlines(keepends=True),
            fromfile="a/" + str(TARGET),
            tofile="b/" + str(TARGET),
            n=4,
        )
    ).encode()
    (OUT / "source.patch").write_bytes(patch)
    postimage = OUT / "test_nl_pipeline_cost_projection.py.gz"
    postimage.write_bytes(gzip.compress(after, mtime=0))
    assert gzip.decompress(postimage.read_bytes()) == after
    xml_path = RUN / "pytest.xml"
    junit = ET.fromstring((ROOT / xml_path).read_bytes())
    all_cases = list(junit.iter("testcase"))
    counts = Counter()
    selected = []
    for case in all_cases:
        outcome = (
            "FAIL" if case.find("failure") is not None else
            "ERROR" if case.find("error") is not None else
            "SKIP" if case.find("skipped") is not None else "PASS"
        )
        counts[outcome] += 1
        if case.get("name") == TEST_NAME:
            failure = case.find("failure")
            selected.append({"name": case.get("name"), "classname": case.get("classname"),
                             "outcome": outcome, "failure_text": None if failure is None else failure.text})
    assert len(all_cases) == 14 and counts == {"FAIL": 14} and len(selected) == 1
    blob_bytes = (ROOT / BLOB).read_bytes()
    assert sha(blob_bytes) == ARTIFACT_HEX
    selected_manifest = json.loads((ROOT / SELECTED_MANIFEST).read_bytes())
    assert selected_manifest["artifact_id"] == "sha256:" + ARTIFACT_HEX
    assert selected_manifest["byte_size"] == len(blob_bytes)
    assert selected_manifest["kind"] == "foundry.method_catalog_snapshot"
    assert selected_manifest["schema"] == {"name": "polisyos.core.MethodCatalogSnapshot", "version": "2.0"}
    assert selected_manifest["canon"]["version"] == "0.2.0"
    payload = json.loads(blob_bytes)
    rows = [entry for entry in payload["entries"] if entry["fqn"] == "causal.dynamic_graph.dscm@1.0.0"]
    assert len(rows) == 1
    dscm_path = "policy-engine/src/polisyos/foundry/methods/catalog/causal/dynamic_graph_dscm.py"
    dscm_ast = ast.parse(runtime_source[dscm_path])
    cls = next(n for n in dscm_ast.body if isinstance(n, ast.ClassDef) and n.name == "DynamicGraphDSCM")
    metadata = next(n for n in cls.body if isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name) and n.target.id == "metadata")
    assert isinstance(metadata.value, ast.Call)
    keyword_nodes = {k.arg: k.value for k in metadata.value.keywords}
    witnesses = []
    for field, key in (("identifiable_target", "estimands"), ("coverage_contract", "outputs")):
        mapping = keyword_nodes[field]
        assert isinstance(mapping, ast.Dict)
        value_node = next(v for k, v in zip(mapping.keys, mapping.values, strict=True) if ast.literal_eval(k) == key)
        assert isinstance(value_node, ast.Tuple)
        native_literal = ast.literal_eval(value_node)
        actual_wire = rows[0][field][key]
        copied_wire = rows[0]["capability_matrix"][field][key]
        assert isinstance(actual_wire, list) and isinstance(copied_wire, list)
        assert list(native_literal) == actual_wire == copied_wire
        assert native_literal != actual_wire
        witnesses.append({"field": field + "." + key, "source_line": value_node.lineno,
                          "source_literal_type": "tuple", "actual_retained_json_type": "list",
                          "all_ordered_elements_equal": True,
                          "native_tuple_equals_actual_list": False,
                          "capability_matrix_copy_equal": True})
    evidence_paths = [xml_path, RUN / "audit-result.json", READSET,
                      RUN / (RUN.name + ".stdout.txt"), RUN / (RUN.name + ".stderr.txt"), BLOB, SELECTED_MANIFEST,
                      Path("LOCAL/raw/e02-execution-20261027/reviews/R3-current-remainder-routing-d205-independent.md"),
                      Path("LOCAL/raw/e02-execution-20261027/reviews/R3-current-remainder-routing-d205-independent.json")]
    evidence = [{"path": str(p), "bytes": (ROOT / p).stat().st_size,
                 "sha256": sha((ROOT / p).read_bytes())} for p in evidence_paths]
    result = {
        "schema": "policyos.e02.catalog-oracle-static-diagnosis.v1",
        "limits": "stdlib/AST/Git inspection only; no product imports, tests, new runtime or numerical computation",
        "runtime_source": RUNTIME_BASE, "runtime_tree": runtime_tree,
        "proposal_source_cut": {"head": head, "tree": tree, "branch": branch},
        "source_pins": pins, "evidence_pins": evidence,
        "complete_junit_denominator": {"testcases": len(all_cases), "outcomes": dict(counts), "selected": selected},
        "readset_boundary": {"recorded_paths": len(readset["modules"]), "source": readset["source_module_count"],
                             "tests": readset["test_module_count"], "tools": readset["tools_module_count"],
                             "pid": readset["pid"], "scope": "finite imported paths; not dynamic reads or all dependencies"},
        "retained_catalog": {"artifact_hex": ARTIFACT_HEX, "bytes": len(blob_bytes),
                             "entries_walked": len(payload["entries"]), "exact_fqn_matches": len(rows),
                             "witnesses": witnesses},
        "proposal": {"target": str(TARGET), "preimage_bytes": len(before), "preimage_sha256": sha(before),
                     "preimage_git_blob": git("rev-parse", "HEAD:" + str(TARGET)).decode().strip(),
                     "postimage_bytes": len(after), "postimage_sha256": sha(after),
                     "patch_bytes": len(patch), "patch_sha256": sha(patch),
                     "gzip_bytes": postimage.stat().st_size, "gzip_sha256": sha(postimage.read_bytes()),
                     "top_level_ast_nodes": len(before_ast.body), "changed_top_level_nodes": changed_top_level,
                     "all_other_bytes_preserved": True, "runtime_test_body_ast_equals_preimage": True},
        "verdict": "fixture native-container equality exceeds existing catalog wire contract; source proposal only; runtime and independent review pending resume",
    }
    dump("diagnosis.json", result)
    print(json.dumps({"head": head, "runtime": RUNTIME_BASE, "junit": dict(counts),
                      "catalog_entries": len(payload["entries"]), "wire_witnesses": len(witnesses),
                      "preimage_sha256": sha(before), "postimage_sha256": sha(after),
                      "patch_sha256": sha(patch), "packet": str(OUT.relative_to(ROOT))}, indent=2))


if __name__ == "__main__":
    main()
