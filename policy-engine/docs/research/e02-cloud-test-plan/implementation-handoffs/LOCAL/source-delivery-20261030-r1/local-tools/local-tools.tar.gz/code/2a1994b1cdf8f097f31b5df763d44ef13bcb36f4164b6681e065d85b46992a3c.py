from pathlib import Path
base=Path('LOCAL/raw/e02-execution-20261027/repairs/TC-closure-owner-r3/proposal')
p=base/'policy-engine/src/polisyos/runtime/quality/owned_execution_identity.py'
s=p.read_text()
a='''        _, graph, _, _ = reader.read_typed_model(ProgramGraph, basis.program_graph_ref)
        _, bundle, _, _ = reader.read_typed_model(
'''
b='''        from polisyos.ir.trinity import TrinityBundle
        from polisyos.scientist.policy_design.schema import PolicyCandidateSchema

        _, trinity, _, _ = reader.read_typed_model(TrinityBundle, basis.trinity_bundle_ref)
        _, candidate, _, _ = reader.read_typed_model(PolicyCandidateSchema, basis.candidate_ref)
        if candidate.trinity_bundle != trinity:
            _fail("debug_selected_trinity_candidate_mismatch")
        _, graph, _, _ = reader.read_typed_model(ProgramGraph, basis.program_graph_ref)
        _, bundle, _, _ = reader.read_typed_model(
'''
assert s.count(a)==1;s=s.replace(a,b,1);p.write_text(s)
p=base/'policy-engine/src/polisyos/runtime/http/services/debug_registered_sql.py'
s=p.read_text()
a='''    from polisyos.core.contracts.foundry import StateSnapshot
'''
b='''    from polisyos.core.contracts.fabric import FabricBridgeDataSnapshotLineage
    from polisyos.core.contracts.foundry import StateSnapshot
    from polisyos.scientist.adapters.fabric_bridge import _parse_query_request
'''
assert s.count(a)==1;s=s.replace(a,b,1)
a='''    if payload.manifest.kind != "fabric.tabular_payload":
        raise ValueError("registered_sql_replay_payload_mismatch")
    encoded, entry_count = _recompute_registered_sql_state(
'''
b='''    lineage = snapshot.source_lineage
    if (
        not isinstance(lineage, FabricBridgeDataSnapshotLineage)
        or payload.manifest.kind != "fabric.tabular_payload"
        or payload.manifest.media_type != "application/json"
        or payload.manifest.artifact_schema
        != SchemaInfo(name="polisyos.fabric.TabularPayload", version="1.0")
        or payload.manifest.inputs
        != [input_ref_from_artifact_ref(
            lineage.data_view_request_ref, role="data_view_request_ref"
        )]
    ):
        raise ValueError("registered_sql_replay_payload_mismatch")
    request_ref = _selected_ref(lineage.data_view_request_ref, kind="ir.data_view_request")
    request = _read_bounded_method_metric_artifact(
        cast("Any", store), ref=request_ref, max_bytes=MAX_METHOD_METRIC_SOURCE_BYTES,
        read_budget=budget,
    )
    if request.manifest.artifact_schema != SchemaInfo(
        name="polisyos.ir.DataViewRequest", version="1.0"
    ):
        raise ValueError("registered_sql_replay_request_schema_mismatch")
    _parse_query_request(request.value)
    encoded, entry_count = _recompute_registered_sql_state(
'''
assert s.count(a)==1;s=s.replace(a,b,1);p.write_text(s)
print('bounded SQL schema and Trinity checks generated')
