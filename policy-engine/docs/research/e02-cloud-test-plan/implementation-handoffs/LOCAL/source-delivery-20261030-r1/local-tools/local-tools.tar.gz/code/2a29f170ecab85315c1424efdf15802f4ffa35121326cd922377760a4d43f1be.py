from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[4]
f=P/'candidate/policy-engine/tests/repo_quality/architecture/test_dynamic_code_reconstitution.py';s=f.read_text()
pos='\n\ndef collect_case(root: Path, source: str)'
add='''

# A deferred constructor can hide a real payload without proving its value protocol.
_DEFERRED_OBJECT = """from importlib import import_module
from pydantic import BaseModel
class Carrier(BaseModel):
    loader: object
    def __getattribute__(self, name):
        return super().__getattribute__(name)
def consume(value):
    return None
"""
for _name, _projection in {
    "direct": "value",
    "list": "[value]",
    "tuple": "(value,)",
    "mapping": '{"value": value}',
}.items():
    CASES[f"deferred-object-selected-consumer-{_name}"] = (
        _DEFERRED_OBJECT + "value = Carrier(loader=import_module)\\n"
        + f"consume({_projection})\\n",
        None,
        "guarded importer value escapes through a call argument",
    )
CASES["deferred-object-no-sink"] = (
    _DEFERRED_OBJECT + "value = Carrier(loader=import_module)\\n", set(), None
)
CASES["deferred-object-scalar-consumer"] = (
    _DEFERRED_OBJECT + 'consume(Carrier(loader="ordinary"))\\n', set(), None
)
for _name, _projection in {
    "unpack": "first, second = value, 1\\nopaque(first)\\n",
    "unknown-unpack": "def expose(unknown):\\n    if callable(None):\\n        values = [value]\\n    else:\\n        values = unknown\\n    first, = values\\n    opaque(first)\\n",
    "dict-unpack": 'def expose(unknown):\\n    if callable(None):\\n        values = {"code": value}\\n    else:\\n        values = unknown\\n    opaque({**values})\\n',
    "star-import": "from unseen import *\\nopaque(value)\\n",
}.items():
    CASES[f"real-code-unknown-projection-{_name}"] = (
        "def body():\\n    return None\\nvalue = body.__code__\\n" + _projection,
        None,
        "escapes|unresolved",
    )
'''
assert s.count(pos)==1;s=s.replace(pos,add+pos)
s+='''

def test_dynamic_deferred_payload_removal_is_semantic(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Erase only the payload capability; retain source, importer and constructor."""
    source = CASES["deferred-object-selected-consumer-direct"][0]
    with pytest.raises(preflight.DynamicImportCollectionError, match="a call argument"):
        collect_case(tmp_path / "positive", source)
    transfer = preflight._DynamicImportSourceBindings._deferred_source_class_instance_binding

    def removed(self, *args, **kwargs):
        return replace(transfer(self, *args, **kwargs), opaque_payload_origins=())

    with monkeypatch.context() as patch:
        patch.setattr(
            preflight._DynamicImportSourceBindings,
            "_deferred_source_class_instance_binding",
            removed,
        )
        assert collect_case(tmp_path / "removed", source) == []
    assert preflight._DynamicImportSourceBindings._deferred_source_class_instance_binding is transfer
    with pytest.raises(preflight.DynamicImportCollectionError, match="a call argument"):
        collect_case(tmp_path / "restored", source)
'''
f.write_text(s)
# Correct class owner name read from real source (asserted by AST below in runner).
