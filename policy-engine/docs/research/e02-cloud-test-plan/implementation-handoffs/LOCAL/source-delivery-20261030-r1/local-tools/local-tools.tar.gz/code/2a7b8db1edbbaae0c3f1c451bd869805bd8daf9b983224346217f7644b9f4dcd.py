from pathlib import Path
base=Path('LOCAL/raw/e02-execution-20261027/repairs/C48-r5/postimages')
p=base/'policy-engine/src/polisyos/core/contracts/runtime.py';s=p.read_text()
needle='\n\nclass MethodMetricProjectionResponse(BaseModel):\n';assert s.count(needle)==1
model='''

class MethodMetricCandidateScore(BaseModel):
    """Current candidate-only score replayed from one completed Runtime source."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    status: Literal["selected", "verification_missing", "invalid"]
    authority_status: Literal["candidate_only"] = "candidate_only"
    revalidation_required: Literal[True] = True
    candidate_ref: ArtifactRef | None = None
    minimized_score: float | None = None
    maximizing_coordinate: float | None = None
    comparison_contract_sha256: str | None = None
    limitations: tuple[str, ...] = Field(default_factory=tuple, max_length=32)

    @model_validator(mode="after")
    def _require_candidate_score_shape(self) -> MethodMetricCandidateScore:
        if self.status == "selected":
            if (
                self.candidate_ref is None
                or self.candidate_ref.manifest_profile_sha256 is None
                or self.minimized_score is None
                or not math.isfinite(self.minimized_score)
                or self.maximizing_coordinate != -self.minimized_score
                or not self.comparison_contract_sha256
                or self.limitations
            ):
                raise ValueError("selected_method_metric_candidate_score_requires_source")
        elif (
            self.candidate_ref is not None
            or self.minimized_score is not None
            or self.maximizing_coordinate is not None
            or self.comparison_contract_sha256 is not None
            or not self.limitations
        ):
            raise ValueError("limited_method_metric_candidate_score_requires_reason_only")
        return self
'''
s=s.replace(needle,model+needle,1)
a='''    observations: tuple[JsonValue, ...] = Field(default_factory=tuple, max_length=8192)
    limitations: tuple[str, ...] = Field(default_factory=tuple, max_length=32)

    @model_validator(mode="after")
    def _require_projection_shape''';b='''    observations: tuple[JsonValue, ...] = Field(default_factory=tuple, max_length=8192)
    limitations: tuple[str, ...] = Field(default_factory=tuple, max_length=32)
    candidate_score: MethodMetricCandidateScore | None = None

    @model_validator(mode="after")
    def _require_projection_shape''';assert s.count(a)==1;s=s.replace(a,b,1)
p.write_text(s)
p=base/'policy-engine/src/polisyos/runtime/http/services/control/run_lifecycle.py';s=p.read_text();needle='''    def resolve_completed_method_metric_selection(
''';assert s.count(needle)==1
method='''    def read_current_completed_ex_ante_candidate_score(
        self,
        *,
        run_id: str,
        tenant_id: str,
        cell_id: str,
    ) -> Any:
        """Reopen one authorized completed source and recompute a candidate score."""
        from polisyos.core.contracts.runtime import MethodMetricCandidateScore
        from polisyos.scientist.nodes.builtins.decide.policy_runtime_method_metrics import (
            _MethodMetricProjectionArtifactStore,
            read_completed_admitted_method_metric_projection,
            recompute_completed_ex_ante_rank_projection,
        )

        limited = lambda reason: MethodMetricCandidateScore(
            status="verification_missing", limitations=(reason,)
        )
        try:
            selection = self.get_method_execution_selection(
                run_id=run_id, tenant_id=tenant_id, cell_id=cell_id
            )
            candidate_ref = getattr(selection, "source_candidate_ref", None)
            if not isinstance(candidate_ref, ArtifactRef):
                return limited("completed_candidate_selection_not_established")
            store = _require_bounded_store_protocol(
                self._artifact_store, _MethodMetricProjectionArtifactStore,
                limits=self._observational_read_limits(),
                refusal_code="canon_profile_bounded_stream_unavailable",
                failure_stage="completed_ex_ante_rank_reader_preflight",
            )
            read = read_completed_admitted_method_metric_projection(
                store, owner=self, source_run_id=run_id, candidate_ref=candidate_ref,
                tenant_id=tenant_id, cell_id=cell_id,
            )
            if read.status != "selected" or read.basis is None:
                return limited("completed_candidate_selection_not_established")
            basis = read.basis
            identity = (
                basis.cache_source_identity(), basis.candidate_ref, basis.source_state_ref,
                basis.vector_ref, basis.verifier_revision, basis.verifier_implementation_sha256,
            )
            score = recompute_completed_ex_ante_rank_projection(
                store, basis=basis, candidate_ref=candidate_ref
            )
            if score.status != "selected":
                return limited("completed_ex_ante_profile_not_established")
            # The source may have been revoked or replaced while the bounded
            # replay was running. Reselect through Runtime before emission.
            current = read_completed_admitted_method_metric_projection(
                store, owner=self, source_run_id=run_id, candidate_ref=candidate_ref,
                tenant_id=tenant_id, cell_id=cell_id,
            )
            if current.status != "selected" or current.basis is None:
                return limited("completed_candidate_selection_no_longer_current")
            basis = current.basis
            if (
                basis.cache_source_identity(), basis.candidate_ref, basis.source_state_ref,
                basis.vector_ref, basis.verifier_revision, basis.verifier_implementation_sha256,
            ) != identity:
                return limited("completed_candidate_selection_changed_during_replay")
            return MethodMetricCandidateScore(
                status="selected", candidate_ref=candidate_ref,
                minimized_score=score.minimized_score,
                maximizing_coordinate=score.maximizing_coordinate,
                comparison_contract_sha256=score.comparison_contract_sha256,
            )
        except (AttributeError, OSError, RuntimeError, TypeError, ValueError):
            return limited("completed_candidate_source_replay_unavailable")

'''
s=s.replace(needle,method+needle,1);p.write_text(s)
p=base/'policy-engine/src/polisyos/runtime/http/routes/runs.py';s=p.read_text();s=s.replace('''    MethodMetricProjectionResponse,
''','''    MethodMetricCandidateScore,
    MethodMetricProjectionResponse,
''',1)
a='''        record_data_access_audit(
            request,
            resource_id=run_id,
            resource_kind="runtime.run.method_metrics",
''';b='''        candidate_score = None
        read_candidate_score = getattr(
            control_service, "read_current_completed_ex_ante_candidate_score", None
        )
        if projection_status == "selected" and callable(read_candidate_score):
            candidate_score = read_candidate_score(
                run_id=run_id, tenant_id=run.details.tenant_id, cell_id=run.details.cell_id
            )
            if not isinstance(candidate_score, MethodMetricCandidateScore):
                raise service_unavailable(
                    "The current candidate score projection is unavailable",
                    code="method_metric_candidate_score_invalid",
                )
        record_data_access_audit(
            request,
            resource_id=run_id,
            resource_kind="runtime.run.method_metrics",
''';assert s.count(a)==1;s=s.replace(a,b,1)
a='''            observations=observations,
            limitations=projection_limitations,
        )

    @router.post(
        "/{run_id}/predictive-calibration",
''';b='''            observations=observations,
            limitations=projection_limitations,
            candidate_score=candidate_score,
        )

    @router.post(
        "/{run_id}/predictive-calibration",
''';assert s.count(a)==1;s=s.replace(a,b,1);p.write_text(s)
