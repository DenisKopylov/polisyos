from pathlib import Path
import difflib,hashlib,json,subprocess,datetime
R=Path.cwd();out=R/'LOCAL/raw/e02-execution-20261027/repairs/C32-r2';base='cfdb1ac1b7a44a782ec8e13b5f0ed9277beed65c';sha=lambda b:hashlib.sha256(b).hexdigest();rows=[];patch=[]
for f in sorted((out/'policy-engine').rglob('*')):
 if not f.is_file():continue
 p=f.relative_to(out).as_posix();q=subprocess.run(['git','show',base+':'+p],capture_output=True);old=q.stdout if q.returncode==0 else b'';new=f.read_bytes();assert old!=new,p
 if q.returncode==0:assert (R/p).read_bytes()==old,(p,'root advanced owned preimage')
 else:assert not (R/p).exists(),p
 rows.append({'path':p,'base_sha256':sha(old) if old else None,'postimage_path':str(f.relative_to(R)),'postimage_sha256':sha(new),'bytes':len(new),'composition':'context_merge' if p.endswith('README.md') or p.endswith('data_state_substrate.py') else 'exact_postimage'})
 patch.append(f'diff --git a/{p} b/{p}\n')
 if not old:patch.append('new file mode 100644\n')
 patch.extend(difflib.unified_diff(old.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile='a/'+p if old else '/dev/null',tofile='b/'+p))
p=out/'base-to-proposal.patch';p.write_text(''.join(patch));q=subprocess.run(['git','apply','--check','--whitespace=error',str(p)],cwd=R,capture_output=True);(out/'apply-check.stdout').write_bytes(q.stdout);(out/'apply-check.stderr').write_bytes(q.stderr);assert q.returncode==0,q.stderr
m={'schema':'policyos.e02.sparse_source_proposal.v1','slice':'C32 selected read-source identity repair','base_commit':base,'base_tree':'48eb8d6b5fb61fa1ce8a731ca47fc0cfaf189343','observed_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'original_cloud_candidate_tree':'2791d9a236fc43098aafd1c17d3325cc0fc35acb','original_cloud_diff_sha256':'64c8a00ea4ba74c05f03d14cb41430c1d9397391193b5bbc631a991dbfee1698','files':rows,'patch_sha256':sha(p.read_bytes()),'readme_sha256':sha((out/'README.md').read_bytes()),'static_checks_sha256':sha((out/'static-checks.json').read_bytes()),'syntax_and_cases_sha256':sha((out/'syntax-and-cases.json').read_bytes()),'prepare_native_sha256':sha((out/'prepare_native.py').read_bytes()),'runtime':'UNRUN','removal_controls':'UNRUN; exact recipes in README','canonical_mutations':False,'G_acceptance':False,'closure_ids':[],'required_root_companions':['Atomic new-inode composition of all source/test/release paths, context-merge shared README and C19 data-state source','Regenerate/check canonical public inventory/reference family; release marker remains false until root review','Source-qualified native pilot alone, full affected consumers and actual overlay/WAL profile; matched removals and declared non-atomic residual falsifier','Normal coherent compiler/planner/fresh served route remains separate UNRUN; no changes to shared CGF helpers']} 
(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');assert json.loads((out/'manifest.json').read_text())==m
print(json.dumps({'files':len(rows),'manifest_sha256':sha((out/'manifest.json').read_bytes()),'patch_sha256':sha(p.read_bytes()),'patch_bytes':p.stat().st_size,'source_changes':False,'runtime':'UNRUN'}))
