from pathlib import Path
import subprocess,json,time
root=Path.cwd();scratch=root/'LOCAL/raw/e02-execution-20261027/repairs/C04-r2';product=root/'policy-engine';pys=sorted((scratch/'policy-engine').rglob('*.py'));python=product/'.venv/bin/python'
results=[]
for p in pys:
 logical=product/p.relative_to(scratch/'policy-engine');source=p.read_text()
 before=subprocess.run([str(python),'-m','ruff','check','--config',str(product/'architecture/tooling/ruff/workspace_root.toml'),'--stdin-filename',str(logical),'--output-format=json','-'],input=source,text=True,capture_output=True)
 errors=json.loads(before.stdout) if before.stdout.strip().startswith('[') else []
 if errors:
  fixed=subprocess.run([str(python),'-m','ruff','check','--config',str(product/'architecture/tooling/ruff/workspace_root.toml'),'--stdin-filename',str(logical),'--fix','-'],input=source,text=True,capture_output=True)
  if fixed.stdout:source=fixed.stdout
 formatted=subprocess.run([str(python),'-m','ruff','format','--config',str(product/'architecture/tooling/ruff/workspace_root.toml'),'--stdin-filename',str(logical),'-'],input=source,text=True,capture_output=True)
 if formatted.returncode:raise RuntimeError((str(p),formatted.stderr))
 p.write_text(formatted.stdout)
 final=subprocess.run([str(python),'-m','ruff','check','--config',str(product/'architecture/tooling/ruff/workspace_root.toml'),'--stdin-filename',str(logical),'--output-format=json','-'],input=formatted.stdout,text=True,capture_output=True)
 err=json.loads(final.stdout) if final.stdout.strip().startswith('[') else []
 try:compile(formatted.stdout,str(logical),'exec');comp='PASS'
 except Exception as exc:comp=str(exc)
 results.append({'path':str(logical.relative_to(root)),'compile':comp,'ruff_exit':final.returncode,'diagnostics':err,'stderr':final.stderr})
(scratch/'static-ruff-first.json').write_text(json.dumps({'kind':'compile_and_lint_only','runtime':'UNRUN','files':results},indent=2)+'\n')
print(json.dumps({'python_files':len(pys),'compile_failures':[r['path'] for r in results if r['compile']!='PASS'],'ruff_failures':[{ 'path':r['path'],'codes':[e['code'] for e in r['diagnostics']]} for r in results if r['ruff_exit']]}))
