"""Freeze a sparse, unapplied source packet and source-removal recipes."""
from __future__ import annotations
import ast,difflib,hashlib,json,subprocess,tomllib
from pathlib import Path
ROOT=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos');raw=ROOT/'LOCAL/raw/e02-execution-20261027/repairs/C94-selected-posterior-consumer-r1';postroot=raw/'postimages'
sha=lambda data:hashlib.sha256(data).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
head=git('rev-parse','HEAD');tree=git('rev-parse','HEAD^{tree}');branch=git('symbolic-ref','--short','HEAD');assert branch=='codex/e02-unified-local-20261009'
paths=['policy-engine/src/polisyos/foundry/calibration/uncertainty_adapter.py','policy-engine/tests/unit/scientist/compute/test_selected_posterior_consumer.py','policy-engine/docs/how-to/selected-posterior-consumption.md','policy-engine/release-fragments/unreleased/2026-10-28-e02-selected-posterior-consumer.toml']
files=[];diff=[]
for rel in paths:
 original=ROOT/rel;post=postroot/rel;before=original.read_bytes() if original.is_file() else b'';data=post.read_bytes()
 if rel.endswith('.py'):ast.parse(data,filename=rel)
 if rel.endswith('.toml'):tomllib.loads(data.decode())
 assert (rel==paths[0])==original.is_file()
 if original.is_file():assert before==subprocess.check_output(['git','show',head+':'+rel],cwd=ROOT)
 files.append({'path':rel,'pre_sha256':sha(before) if original.is_file() else None,'post_sha256':sha(data),'postimage':str(post.relative_to(raw)),'classification':'mechanism' if rel==paths[0] else 'mandatory_companion','bytes':len(data)})
 left='a/'+rel if original.is_file() else '/dev/null';right='b/'+rel
 diff.append(''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),data.decode().splitlines(keepends=True),fromfile=left,tofile=right)))
patch=raw/'proposal.patch';patch.write_text(''.join(diff));v=subprocess.run(['git','apply','--check','--',str(patch)],cwd=ROOT,capture_output=True);(raw/'apply-check.stdout').write_bytes(v.stdout);(raw/'apply-check.stderr').write_bytes(v.stderr);assert v.returncode==0,v.stderr.decode()
code=(postroot/paths[0]).read_text();controls={
 'expected-evidence':('if artifact_ref_identity_key(source_evidence) != artifact_ref_identity_key(expected_evidence):','if False and artifact_ref_identity_key(source_evidence) != artifact_ref_identity_key(expected_evidence):','test_valid_same_bytes_sibling_profile_is_not_the_held_job_view'),
 'fresh-evidence-reader':('summary = load_persisted_posterior_summary(store, selected_summary_ref)','summary = load_posterior_summary(ensure_ir_artifact_store(store), selected_summary_ref)  # load_persisted_posterior_summary removed','test_unavailable_evidence_cannot_be_bypassed_by_intact_summary'),
 'selected-ref-snapshot':('selected_summary_ref = PosteriorSummaryRef.from_selected_write(\n        summary_ref.model_dump(mode="python")\n    )\n    expected_evidence = ArtifactRef.model_validate(\n        expected_method_evidence_ref.model_dump(mode="python")\n    )','selected_summary_ref = summary_ref  # PosteriorSummaryRef.from_selected_write removed\n    expected_evidence = expected_method_evidence_ref  # ArtifactRef.model_validate removed','test_mutable_input_ref_changes_do_not_change_captured_selected_views'),
};controlrows=[];d=raw/'controls';d.mkdir(exist_ok=True)
for name,(old,new,test) in controls.items():
 assert code.count(old)==1,(name,code.count(old));mutant=code.replace(old,new,1);ast.parse(mutant,filename=paths[0]);delta=''.join(difflib.unified_diff(code.splitlines(keepends=True),mutant.splitlines(keepends=True),fromfile='a/'+paths[0],tofile='b/'+paths[0]));p=d/(name+'.patch');p.write_text(delta);controlrows.append({'name':name,'patch':str(p.relative_to(raw)),'sha256':sha(p.read_bytes()),'preimage_sha256':sha(code.encode()),'mutant_sha256':sha(mutant.encode()),'test':'tests/unit/scientist/compute/test_selected_posterior_consumer.py::'+test,'outcome':'UNRUN'})
testtree=ast.parse((postroot/paths[1]).read_text());tests=[n.name for n in testtree.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
manifest={'base':head,'base_tree':tree,'branch':branch,'status':'SOURCE_PROPOSAL_UNAPPLIED_REVIEW_PENDING','runtime':'UNRUN','G_acceptance':False,'closure_ids':[],'capability_state':'bridge_missing until real product consumer; verification_missing for new route','files':files,'proposal_patch_sha256':sha(patch.read_bytes()),'proposal_patch_bytes':patch.stat().st_size,'controls':controlrows,'test_function_count':len(tests),'test_function_names':tests,'parametrized_input_count_declared_by_source':4,'collection_count':'UNRUN','logical_ruff':'PASS: canonical stdin filenames; actual physical configuration pending Root','index_and_refs_changed':False,'facade_and_shared_readme':'Root-owned additive delta after C78 preimages; not in packet'}
p=raw/'manifest.json';assert not p.exists();p.write_text(json.dumps(manifest,indent=2)+'\n');assert git('rev-parse','HEAD')==head
print(json.dumps({'base':head,'tree':tree,'files':len(files),'patch_sha256':manifest['proposal_patch_sha256'],'manifest_sha256':sha(p.read_bytes()),'controls':controlrows,'test_functions':len(tests),'apply_check':'PASS'}))
