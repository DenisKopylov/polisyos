from __future__ import annotations

import ast
import difflib
import hashlib
import json
import subprocess
import tomllib
from pathlib import Path

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
OUT = ROOT / 'LOCAL/raw/e02-execution-20261027/repairs/V3-bridge-rule-owner-r2'
R1 = ROOT / 'LOCAL/raw/e02-execution-20261027/repairs/V3-world-rule-quantity-r1'
BASE = '77daa2ab74d1a40f9ff8cfc67f309b41e6641222'
TREE = '72de860944d320934bd3c4788873cbee39919503'
P = 'policy-engine/'
GROWTH = P + 'src/polisyos/runtime/quality/acquisition_world_growth.py'
HELPER = P + 'tests/_helpers/world_model_record.py'
TEST = P + 'tests/integration/core_runtime/test_acquisition_bridge_rule_quantity.py'
DOC = P + 'src/polisyos/runtime/quality/README.md'
RELEASE = P + 'release-fragments/unreleased/2026-10-29-acquired-observation-semantic-values.toml'
PATHS = (GROWTH, HELPER, TEST, DOC, RELEASE)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == BASE
assert subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, text=True).strip() == TREE
r1 = json.loads((R1 / 'manifest.json').read_text())
assert sha((R1 / 'manifest.json').read_bytes()) == 'a6b5b84501ea533b0e8f8f5bca062b78819933fa5650003a67d63d625ba12de2'
before: dict[str, str] = {}
after: dict[str, str] = {}
for path in PATHS:
    if path == TEST:
        assert not (ROOT / path).exists()
        check = subprocess.run(['git', 'cat-file', '-e', f'{BASE}:{path}'], cwd=ROOT,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        assert check.returncode != 0
        before[path] = ''
        after[path] = (OUT / 'test_acquisition_bridge_rule_quantity.py').read_text()
    else:
        raw = (ROOT / path).read_bytes()
        assert raw == subprocess.check_output(['git', 'show', f'{BASE}:{path}'], cwd=ROOT)
        assert raw == subprocess.check_output(['git', 'show', f'2130f07de1eb93316d22bf5f91adc05ded67fbd2:{path}'], cwd=ROOT)
        before[path] = raw.decode()
        after[path] = raw.decode()
        if path == HELPER:
            proposed = (R1 / 'postimage' / path).read_bytes()
            assert sha(proposed) == r1['postimages'][path]['sha256']
            after[path] = proposed.decode()


def replace_one(path: str, old: str, new: str) -> None:
    assert after[path].count(old) == 1, (path, old)
    after[path] = after[path].replace(old, new, 1)

replace_one(GROWTH,
'''        from polisyos.foundry.data_plane import InputBindingValuesPreparation, load_input_bindings
''',
'''        from polisyos.core.artifacts import (
            ArtifactRef,
            artifact_ref_for_manifest,
            artifact_ref_identity_key,
        )
        from polisyos.foundry.data_plane import (
            InputBindingValuesPreparation,
            load_input_bindings,
            prepare_input_bindings,
        )
''')
replace_one(GROWTH,
'''        actual_world_views = world_model_artifact_views(world_model_record)
        actual_state = load_state_snapshot(
            self.artifact_store, snapshot_ref=actual_world_views.bound_state_snapshot_ref
        )
        if state_snapshot_value_projection(actual_state) != state_snapshot_value_projection(
            prospective_values.materialized_state
        ):
            raise ValueError("acquisition_prospective_state_owner_reconciliation_failed")
        actual_bindings = load_input_bindings(
            self.artifact_store, actual_world_views.input_bindings_ref
        )
        if actual_bindings.rules != list(prospective_values.effective_rules):
            raise ValueError("acquisition_prospective_rule_owner_reconciliation_failed")
''',
'''        actual_world_views = world_model_artifact_views(world_model_record)

        def pin_selected_view(ref: ArtifactRef) -> ArtifactRef:
            # Resolve the actual default if profileless, then keep using that
            # exact verified manifest even if the default changes afterwards.
            if not isinstance(ref, ArtifactRef):
                raise ValueError("acquisition_prospective_selected_view_unverified")
            try:
                manifest = self.artifact_store.get_manifest(ref)
                selected = artifact_ref_for_manifest(manifest)
                if (
                    not self.artifact_store.verify(ref).ok
                    or not self.artifact_store.verify(selected).ok
                    or self.artifact_store.get_manifest(ref) != manifest
                    or self.artifact_store.get_manifest(selected) != manifest
                ):
                    raise ValueError("acquisition_prospective_selected_view_unverified")
                return selected
            except (OSError, RuntimeError, TypeError, ValueError) as exc:
                raise ValueError("acquisition_prospective_selected_view_unverified") from exc

        def same_selected_view(owner_ref: ArtifactRef, selected_ref: ArtifactRef) -> bool:
            # A profileless embedded ref means its actual CAS default, not an
            # arbitrary matching blob. Compare the two complete verified views.
            if (
                not isinstance(owner_ref, ArtifactRef)
                or owner_ref.artifact_id != selected_ref.artifact_id
                or owner_ref.kind != selected_ref.kind
                or owner_ref.media_type != selected_ref.media_type
            ):
                return False
            try:
                return artifact_ref_identity_key(pin_selected_view(owner_ref)) == (
                    artifact_ref_identity_key(selected_ref)
                )
            except ValueError:
                return False

        selected_views = {
            field: pin_selected_view(getattr(actual_world_views, field))
            for field in ("data_snapshot_ref", "registry_bundle_ref", "bound_state_snapshot_ref")
        }
        bindings_ref = pin_selected_view(actual_world_views.input_bindings_ref)
        actual_bindings = load_input_bindings(self.artifact_store, bindings_ref)
        for field, selected in selected_views.items():
            if not same_selected_view(getattr(actual_bindings, field), selected):
                raise ValueError("acquisition_prospective_binding_source_view_mismatch:" + field)
        actual_state = load_state_snapshot(
            self.artifact_store, snapshot_ref=selected_views["bound_state_snapshot_ref"]
        )
        if state_snapshot_value_projection(actual_state) != state_snapshot_value_projection(
            prospective_values.materialized_state
        ):
            raise ValueError("acquisition_prospective_state_owner_reconciliation_failed")
        sql_ref = actual_bindings.registered_sql_admission_ref
        if sql_ref is not None:
            sql_ref = pin_selected_view(sql_ref)
        replayed = prepare_input_bindings(
            self.artifact_store,
            data_snapshot_ref=selected_views["data_snapshot_ref"],
            registry_bundle_ref=selected_views["registry_bundle_ref"],
            rules=list(actual_bindings.rules),
            registered_sql_admission_ref=sql_ref,
        )
        if (
            replayed.effective_rules != prospective_values.effective_rules
            or replayed.applied_binding_ids != prospective_values.applied_binding_ids
            or replayed.warnings != prospective_values.warnings
            or state_snapshot_value_projection(replayed.materialized_state)
            != state_snapshot_value_projection(actual_state)
        ):
            raise ValueError("acquisition_prospective_rule_owner_reconciliation_failed")
''')
replace_one(DOC,
'''## Prospective acquired-world values
''',
'''The acquired candidate bridge reopens the selected WMR and reconciles the
bindings' own data snapshot, registry, and bound state against the WMR-selected
views using the actual CAS default or selected manifest, then consumes those
pinned views. If a selected sidecar is unavailable, reconciliation fails closed.
It asks the Foundry binding owner to recompute the full ordered rules, applied IDs, warnings and
materialized state before accepting the prospective values. A different
serialized rule order can denote the same execution order; changed rule fields
and changed selected source views remain decisive. This bridge is a bounded
producer/consumer consistency check, not source permission, historical
comparison, retention authority, or proof of active SKG consumed values.

## Prospective acquired-world values
''')
replace_one(RELEASE,
'''evidence = ["tests/integration/core_runtime/test_acquisition_observation_semantics.py"]
''',
'''evidence = ["tests/integration/core_runtime/test_acquisition_observation_semantics.py", "tests/integration/core_runtime/test_acquisition_bridge_rule_quantity.py"]
''')
replace_one(RELEASE,
'''limitations = "Only the one-selected-controlled-numerical-row profile is supported.''',
'''limitations = "The candidate bridge recomputes Foundry's ordered rule/state quantity and verifies bindings-to-WMR selected source views; unavailable selected sidecars fail closed. It does not provide historical comparison or retention permission. Only the one-selected-controlled-numerical-row profile is supported.''')

# Static authoring only: no project imports, test execution or canonical edits.
postimages: dict[str, object] = {}
preimages: dict[str, object] = {}
patch_parts: list[str] = []
for path in PATHS:
    if path.endswith('.py'):
        ast.parse(after[path], filename=path)
    elif path.endswith('.toml'):
        tomllib.loads(after[path])
    if path == TEST:
        preimages[path] = {'source': f'absent@{BASE}', 'sha256': None, 'git_blob': None}
    else:
        preimages[path] = {
            'source': path + '@' + BASE,
            'sha256': sha(before[path].encode()),
            'git_blob': subprocess.check_output(['git', 'rev-parse', f'{BASE}:{path}'], cwd=ROOT, text=True).strip(),
        }
    target = OUT / 'postimage' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(after[path])
    assert target.read_bytes() == after[path].encode()
    postimages[path] = {'path': str(target.relative_to(ROOT)), 'sha256': sha(target.read_bytes())}
    patch_parts.extend(difflib.unified_diff(
        before[path].splitlines(keepends=True), after[path].splitlines(keepends=True),
        fromfile='/dev/null' if path == TEST else 'a/' + path, tofile='b/' + path,
    ))
patch = OUT / 'proposal.patch'
patch.write_text(''.join(patch_parts))
(OUT / 'preimages.json').write_text(json.dumps(preimages, indent=2, sort_keys=True) + '\n')
manifest = {'status': 'REVIEW REQUIRED; runtime UNRUN', 'base': BASE, 'tree': TREE,
            'mechanism_paths': [GROWTH], 'mandatory_companions': [HELPER, TEST, DOC, RELEASE],
            'postimages': postimages,
            'preimages': {'path': str((OUT/'preimages.json').relative_to(ROOT)),
                          'sha256': sha((OUT/'preimages.json').read_bytes())},
            'patch': {'path': str(patch.relative_to(ROOT)), 'sha256': sha(patch.read_bytes())},
            'runtime_status': 'UNRUN; no product imports or tests',
            'readme': {'path': str((OUT/'README.md').relative_to(ROOT)),
                       'sha256': sha((OUT/'README.md').read_bytes())},
            'static_checks': {'path': str((OUT/'static-checks.json').relative_to(ROOT)),
                              'sha256': sha((OUT/'static-checks.json').read_bytes())},
            'static_checker': {'path': str((OUT/'static_check.py').relative_to(ROOT)),
                               'sha256': sha((OUT/'static_check.py').read_bytes())},
            'author': {'path': str((OUT/'prepare.py').relative_to(ROOT)),
                       'sha256': sha((OUT/'prepare.py').read_bytes())},
            'test_draft': {'path': str((OUT/'test_acquisition_bridge_rule_quantity.py').relative_to(ROOT)),
                           'sha256': sha((OUT/'test_acquisition_bridge_rule_quantity.py').read_bytes())}}
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
print(json.dumps({'manifest_sha256': sha((OUT / 'manifest.json').read_bytes()),
                  'patch_sha256': sha(patch.read_bytes()), 'postimage_count': len(postimages)}))
