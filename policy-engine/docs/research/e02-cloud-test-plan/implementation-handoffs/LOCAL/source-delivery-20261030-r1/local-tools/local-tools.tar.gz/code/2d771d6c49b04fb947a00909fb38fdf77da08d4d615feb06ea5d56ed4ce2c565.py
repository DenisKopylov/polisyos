from pathlib import Path
p=Path('LOCAL/raw/e02-execution-20261027/repairs/TC-closure-owner-r5/proposal/policy-engine/src/polisyos/runtime/quality/owned_execution_identity.py')
s=p.read_text()
a='''            FoundryInputBindings,
            LoweredIR,
        )
        from polisyos.foundry.compile.trinity_compiler import _program_graph_inputs
'''
b='''            FoundryInputBindings,
            LoweredIR,
            MethodMetricBindingSet,
        )
        from polisyos.foundry.compile import execution_plan_input_refs, program_graph_input_refs
        from polisyos.foundry.compile.randomization import TreasuryPlan, build_treasury_plan
'''
assert s.count(a)==1;s=s.replace(a,b,1)
s=s.replace('_program_graph_inputs(', 'program_graph_input_refs(')
a='''            "foundry.lowered_ir": (LoweredIR, "polisyos.foundry.LoweredIR", {"0.2.0"}),
'''
b='''            "foundry.lowered_ir": (LoweredIR, "polisyos.foundry.LoweredIR", {"0.2.0"}),
            "foundry.treasury_plan": (TreasuryPlan, "polisyos.foundry.TreasuryPlan", {"1.0"}),
            "foundry.method_metric_binding_set": (
                MethodMetricBindingSet,
                MethodMetricBindingSet.ARTIFACT_SCHEMA_NAME,
                {MethodMetricBindingSet.ARTIFACT_SCHEMA_VERSION},
            ),
'''
assert s.count(a)==1;s=s.replace(a,b,1)
a='''                            "foundry.lowered_ir",
                            "scientist.execution_plan",
'''
b='''                            "foundry.lowered_ir",
                            "foundry.treasury_plan",
                            "foundry.method_metric_binding_set",
                            "scientist.execution_plan",
'''
assert s.count(a)==1;s=s.replace(a,b,1)
a='''                "exec_plan": {"program_graph": "foundry.program_graph"},
'''
b='''                "exec_plan": {
                    "program_graph": "foundry.program_graph",
                    "treasury_plan": "foundry.treasury_plan",
                    "method_metric_bindings": "foundry.method_metric_binding_set",
                },
'''
assert s.count(a)==1;s=s.replace(a,b,1)
a='''            if role == "exec_plan":
                expected = [
                    input_ref_from_artifact_ref(basis.program_graph_ref, role="program_graph")
                ]
'''
b='''            if role == "exec_plan":
                by_role = {
                    edge.role.removeprefix("basis.edge.exec_plan."): (ref, child_manifest)
                    for edge, ref, child_manifest in children[1:]
                }
                if set(by_role) != {"program_graph", "treasury_plan", "method_metric_bindings"}:
                    _fail("debug_exec_plan_input_roles_mismatch")
                treasury_ref, treasury_manifest = by_role["treasury_plan"]
                binding_ref, binding_manifest = by_role["method_metric_bindings"]
                if artifact_ref_identity_key(binding_ref) != artifact_ref_identity_key(
                    selection.method_metric_binding_set_ref
                ):
                    _fail("debug_exec_plan_binding_selection_mismatch")
                _, plan, _, _ = reader.read_typed_model(ExecPlan, basis.exec_plan_ref)
                _, treasury, _, _ = reader.read_typed_model(TreasuryPlan, treasury_ref)
                if (
                    treasury != build_treasury_plan(graph, root_seed=plan.random_seed or 0)
                    or treasury_manifest.inputs
                    != [input_ref_from_artifact_ref(basis.program_graph_ref, role="program_graph")]
                ):
                    _fail("debug_exec_plan_treasury_replay_mismatch")
                _, metric_set, _, _ = reader.read_typed_model(MethodMetricBindingSet, binding_ref)
                if (
                    artifact_ref_identity_key(metric_set.program_graph_ref)
                    != artifact_ref_identity_key(basis.program_graph_ref)
                    or artifact_ref_identity_key(metric_set.policy_ref)
                    != artifact_ref_identity_key(basis.trinity_bundle_ref)
                    or artifact_ref_identity_key(metric_set.registry_bundle_ref)
                    != artifact_ref_identity_key(basis.compile_registry_ref)
                    or basis.compile_registry_members.metric_registry is None
                    or basis.compile_registry_members.units_registry is None
                    or artifact_ref_identity_key(metric_set.metric_registry_ref)
                    != artifact_ref_identity_key(basis.compile_registry_members.metric_registry)
                    or artifact_ref_identity_key(metric_set.units_registry_ref)
                    != artifact_ref_identity_key(basis.compile_registry_members.units_registry)
                    or binding_manifest.inputs
                    != [
                        input_ref_from_artifact_ref(metric_set.program_graph_ref, role="program_graph"),
                        input_ref_from_artifact_ref(metric_set.policy_ref, role="policy"),
                        input_ref_from_artifact_ref(metric_set.registry_bundle_ref, role="registry_bundle"),
                        input_ref_from_artifact_ref(metric_set.metric_registry_ref, role="metric_registry"),
                        input_ref_from_artifact_ref(metric_set.units_registry_ref, role="units_registry"),
                    ]
                ):
                    _fail("debug_exec_plan_metric_binding_mismatch")
                expected = execution_plan_input_refs(
                    program_graph_ref=basis.program_graph_ref,
                    treasury_plan_ref=treasury_ref,
                    method_metric_binding_set_ref=selection.method_metric_binding_set_ref,
                )
'''
assert s.count(a)==1;s=s.replace(a,b,1)
p.write_text(s)
print('complete plan treasury + metric binding replay authored')
