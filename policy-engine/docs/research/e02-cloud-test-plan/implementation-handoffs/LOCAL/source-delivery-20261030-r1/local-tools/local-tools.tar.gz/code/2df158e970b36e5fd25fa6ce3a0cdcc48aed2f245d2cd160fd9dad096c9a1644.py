"""Freeze source/test/docs proposal with stdlib only; no product/helper imports."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

R=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
O=R/'LOCAL/raw/e02-execution-20261027/repairs/C100-profile-origin-r3'
BASE='283fb609abfd483504e4f835c79d9b32db3738c0'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R,stderr=subprocess.PIPE)
def dump(name,value):(O/name).write_text(json.dumps(value,indent=2)+'\n')
files=[];patch=[]
for p in sorted((O/'postimages').rglob('*')):
 if not p.is_file():continue
 path=str(p.relative_to(O/'postimages'));after=p.read_text()
 try:before=git('show',BASE+':'+path).decode()
 except subprocess.CalledProcessError:before=None
 if path.endswith('.py'):ast.parse(after)
 files.append({'path':path,'pre_sha256':hashlib.sha256(before.encode()).hexdigest() if before is not None else None,'pre_git_blob':git('rev-parse',BASE+':'+path).decode().strip() if before is not None else None,'post_sha256':sha(p),'postimage':str(p.relative_to(O))})
 patch.append(''.join(difflib.unified_diff((before or '').splitlines(keepends=True),after.splitlines(keepends=True),fromfile='a/'+path if before is not None else '/dev/null',tofile='b/'+path)))
(O/'source.patch').write_text(''.join(patch))
t=subprocess.run(['git','apply','--check',str(O/'source.patch')],cwd=R,capture_output=True,text=True);assert t.returncode==0,(t.stdout,t.stderr)
dump('apply-check.json',{'returncode':t.returncode,'stdout':t.stdout,'stderr':t.stderr,'runtime':'UNRUN'})
test='policy-engine/tests/unit/helpers/test_scientist_runtime_profile.py'
tree=ast.parse((O/'postimages'/test).read_text());functions=[n.name for n in tree.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
dump('execution-selectors.json',{'focused_regression_module':test.removeprefix('policy-engine/'),'defined_regression_functions':functions,'pytest_collection':'UNRUN; actual native collection determines parameter-expanded count','next_diagnostic':'tests/_helpers/scientist_runtime_profile.py --repo-root <actual-root> --output <new-case>/profile.json','next_runtime_AA':'tests/unit/runtime/http/test_completed_ex_ante_runtime_contract.py::test_identical_inputs_complete_two_real_sources_and_refuse_duplicate_ranking','original_AB':'tests/unit/runtime/http/test_observational_method_runtime.py::test_two_real_completed_ex_ante_sources_produce_fresh_candidate_comparison','revocation':'tests/unit/runtime/http/test_observational_method_runtime.py::test_two_real_completed_ex_ante_sources_are_reselected_by_fresh_planner','affected_V1_reference':'tests/integration/core_runtime/test_acquisition_authority_served.py::test_served_acquisition_binds_n7_compiler_and_planner_cas_before_reentry','V1_disposition':'Separate existing Root resource/ownership lane; affected-source requalification, no old-result retag and no execution here.','controls':'All23 remain UNRUN; no new harness/removal changes.'})
# All four numerical-stage functions are untouched; only final collection wiring changes.
path='policy-engine/tests/_helpers/scientist_runtime_profile.py';old=ast.parse(git('show',BASE+':'+path));new=ast.parse((O/'postimages'/path).read_text())
oldmain=next(n for n in old.body if isinstance(n,ast.FunctionDef) and n.name=='main');newmain=next(n for n in new.body if isinstance(n,ast.FunctionDef) and n.name=='main')
oldnested={n.name:ast.dump(n,include_attributes=False) for n in oldmain.body if isinstance(n,ast.FunctionDef)};newnested={n.name:ast.dump(n,include_attributes=False) for n in newmain.body if isinstance(n,ast.FunctionDef)};assert oldnested==newnested
dump('static-audit.json',{'unchanged_main_nested_functions':sorted(oldnested),'numerical_discovery_stage_bodies_AST_equal':True,'changed_paths':len(files),'regression_function_definitions':len(functions),'local_helper_product_imports':False,'tests_diagnostic_runtime':'UNRUN','class':'Actual real-origin selection, never cwd filename resolution; no filename whitelist.'})
names=['README.md','source.patch','freeze.py','logical-ruff.json','apply-check.json','execution-selectors.json','static-audit.json']+[x['postimage'] for x in files]
m={'schema':'policyos.e02.sparse_source_proposal.v1','task':'C100-profile-origin-r3','base':BASE,'tree':'97aa8fbd013c67363a6e63b52dfef6e0cd23aad7','files':files,'patch_sha256':sha(O/'source.patch'),'support':{n:{'sha256':sha(O/n),'bytes':(O/n).stat().st_size} for n in names},'status':'FROZEN_FOR_INDEPENDENT_SOURCE_REVIEW','runtime':'UNRUN','local_product_helper_imports':False,'local_native_tests':False,'checks':'AST, unchanged four-stage bodies, four logical full-file product Ruff checks and gitapply-check PASS. Root physical/tests/diagnostic pending.','prior_actual_result':'ERROR retained; four bounded stages PASS retained on original source, not retagged.','closure_ids':[],'G_acceptance':False}
dump('manifest.json',m);print(json.dumps({'manifest_sha256':sha(O/'manifest.json'),'patch_sha256':m['patch_sha256'],'files':files,'regression_functions':len(functions)},indent=2))
