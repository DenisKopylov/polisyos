from pathlib import Path
import ast, difflib, hashlib, json, subprocess, sys, tomllib

root = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
out = root / 'LOCAL/raw/e02-execution-20261027/repairs/C60-executable-identity-r3'
post = out / 'postimages'
py = root / 'policy-engine/.venv/bin/python'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=root)

def patch_for(rel, before, after):
    a = before.decode().splitlines(keepends=True)
    b = after.decode().splitlines(keepends=True)
    header = f'diff --git a/{rel} b/{rel}\n'
    if before == b'':
        header += 'new file mode 100644\n'
    return header + ''.join(difflib.unified_diff(a, b, fromfile='/dev/null' if before == b'' else f'a/{rel}', tofile=f'b/{rel}'))

head = git('rev-parse', 'HEAD').decode().strip()
tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
files=[]; unchanged=[]; pieces=[]; static=[]
for f in sorted(x for x in post.rglob('*') if x.is_file()):
    rel=f.relative_to(post).as_posix(); target=root/rel; after=f.read_bytes()
    before=target.read_bytes() if target.exists() else None
    if before == after:
        unchanged.append({'path':rel,'sha256':digest(after),'reason':'committed companion; unchanged but an affected check'})
        continue
    if before is not None:
        committed=git('show', f'HEAD:{rel}')
        if committed != before:
            raise RuntimeError(f'Preimage changed or uncommitted: {rel}')
    if rel.endswith('.py'):
        ast.parse(after,filename=rel)
        logical=Path(rel).relative_to('policy-engine').as_posix()
        for kind in ('check','format'):
            args=[str(py),'-m','ruff',kind,'--config','ruff.toml']
            if kind == 'check': args += ['--no-cache']
            else: args += ['--check']
            args += ['--stdin-filename',logical,'-']
            result=subprocess.run(args,cwd=root/'policy-engine',input=after,capture_output=True)
            item={'path':rel,'command':args[1:],'exit':result.returncode,'stdout':result.stdout.decode(),'stderr':result.stderr.decode()}
            static.append(item)
            if result.returncode:
                print(json.dumps(item,indent=2)); raise SystemExit('Ruff failed')
    elif rel.endswith('.toml'):
        tomllib.loads(after.decode())
    files.append({'path':rel,'pre_sha256':digest(before) if before is not None else None,'post_sha256':digest(after),'postimage_file':f.relative_to(root).as_posix(),'bytes':len(after)})
    pieces.append(patch_for(rel,before or b'',after))

assert len(files)==11 and len(unchanged)==1, (len(files),len(unchanged))
full=''.join(pieces).encode(); (out/'source.patch').write_bytes(full)
check=subprocess.run(['git','apply','--check',str(out/'source.patch')],cwd=root,capture_output=True)
if check.returncode: print(check.stderr.decode()); raise SystemExit('git apply --check failed')
static.append({'command':['git','apply','--check','source.patch'],'exit':check.returncode,'stdout':check.stdout.decode(),'stderr':check.stderr.decode()})
(out/'static-results.json').write_text(json.dumps(static,indent=2)+'\n')

helper='policy-engine/src/polisyos/foundry/methods/_internal/executable_identity.py'
compiler='policy-engine/src/polisyos/foundry/methods/compiler/__init__.py'
chain='policy-engine/src/polisyos/foundry/methods/backends/chain_executor.py'
runner='policy-engine/src/polisyos/foundry/methods/backends/jax_runner.py'
control_specs=[
 ('selected-class-forwarding',runner,[(
 '''        compiled = self._compiler._compile_resolved(\n            method_class=method_class,\n            signature=signature,\n            params=params,\n            jit=signature.supports_jit,\n        )''',
 '''        compiled = self._compiler.compile(\n            method_name=signature.fqn,\n            params=params,\n            jit=signature.supports_jit,\n        )''',1)],
 'Scoped public fallback must not silently compile from the global registry.'),
 ('ordinary-cache-scope',compiler,[(
 'self._cache.get(spec, token=token, _identity=identity)',
 'self._cache.get(spec, token=token, _identity=None)',2),(
 'key = (generation, spec.cache_key, _identity)',
 'key = (generation, spec.cache_key, None)',1),(
 'flight_key = (token.generation, spec.cache_key, identity)',
 'flight_key = (token.generation, spec.cache_key, None)',1)],
 'Colliding implementations must not share a compiled entry or in-flight result.'),
 ('fused-cache-scope',chain,[(
 '''                    kernel_key = (\n                        specialization_key,\n                        _ExecutableIdentity(method_a, step_a, _signature_binding(signature_a)),\n                        _ExecutableIdentity(method_b, step_b, _signature_binding(signature_b)),\n                    )''',
 '''                    kernel_key = (specialization_key, None, None)''',1)],
 'A warmed fused kernel must execute the newly selected classes.'),
 ('signature-binding',helper,[(
 'return signature.stable_digest(), inputs, outputs',
 'return signature.stable_digest(), (), ()',1)],
 'Equal ABI digests with changed linker-relevant slot bounds must not be admitted or shared.'),
 ('signature-admission',helper,[(
 '''    return isinstance(actual, MethodSignature) and _signature_binding(actual) == _signature_binding(\n        expected\n    )''',
 '''    return True''',1)],
 'A changed selected signature must refuse before either method runs.'),
 ('selected-a-relookup',chain,[(
 '                        method_class=method_a,\n                    )\n                    static_a,',
 '                    )\n                    static_a,',1)],
 'The eligibility-selected first class must not be reselected by a second registry lookup.'),
 ('signature-context',compiler,[(
 '                sig = bound.signature', '                sig = bound.method_class.signature',1)],
 'The compiler must retain the signature admitted before dispatch when the class is rebound.'),
 ('public-cache-put',compiler,[(
 '                _identity=compiled._implementation_identity,\n', '',1),(
 '                compiled._implementation_identity if _identity is None else _identity',
 '                _identity',1)],
 'Public put and default publish must retain the bound implementation identity.'),
 ('numeric-bound-equivalence',helper,[(
 'slot.name, slot.bounds',
 'slot.name, repr(slot.bounds)',2)],
 'Equivalent numeric bounds must be accepted and a warm executable reused.'),
 ('opaque-code-marker',helper,[(
 '''        function = operation.__func__ if isinstance(operation, MethodType) else operation\n        code = function.__code__ if isinstance(function, FunctionType) else None\n        self._code = code if isinstance(code, CodeType) else None''',
 '''        self._code = getattr(getattr(operation, "__func__", operation), "__code__", None)''',1)],
 'An opaque callable with a forged code marker must not gain reusable identity.'),
]
controls=[]
for name,rel,replacements,property_text in control_specs:
    before=(post/rel).read_text(); after=before
    for old,new,n in replacements:
        if after.count(old)!=n: raise RuntimeError(f'{name} expected {n} occurrences, found {after.count(old)}')
        after=after.replace(old,new)
    ast.parse(after,filename=rel)
    target=out/'controls'/name; target.mkdir(parents=True,exist_ok=True)
    (target/'postimage.py').write_text(after)
    patch=patch_for(rel,before.encode(),after.encode()).encode(); (target/'source.patch').write_bytes(patch)
    controls.append({'id':name,'owner_path':rel,'pre_sha256':digest(before.encode()),'post_sha256':digest(after.encode()),'patch_sha256':digest(patch),'property':property_text,'runtime':'UNRUN'})

manifest={
 'schema':'policyos.e02.c60.selected-executable-binding.v3',
 'status':'FROZEN_SOURCE_PROPOSAL_PENDING_INDEPENDENT_REVIEW',
 'observed_head':head,'observed_tree':tree,
 'previous_proposal_manifest_sha256':'b5815494acbc7ddd9f3746b2be18f3e99f91b9f8a4d0a32577fa00d6d7e10d10',
 'files':files,'unchanged_companions':unchanged,'full_patch_sha256':digest(full),
 'static_results_sha256':digest((out/'static-results.json').read_bytes()),'controls':controls,
 'trigger':'Actual C60 R10 two fallback FAILs: public explicit registry selected a class, while the default JAX runner re-resolved FQN against the singleton. Two same-FQN implementations also collide in process cache.',
 'capability':'One selected class, callable, Python code object when available, and admitted ABI plus linker-relevant slot bounds flow through the existing JAX/compiler and fused cache owners. No persistent specialization or artifact identity change.',
 'type_and_cache_contract':'Numeric slot bounds use Python equality and hashing, preserving exact large integers and equivalent int/float values without blanket float coercion. Prior public compile signature and structural method contract remain. A per-call context carries selection and signature. Opaque callables run but receive an unshared identity and are not cache-reused; no Python source fingerprint is claimed. Unqualified cache.get returns None on multiple bindings, public put/default publish preserve a bound handle, and invalidate clears every matching binding.',
 'proof_boundary':'Process-local object/code identity, not persistent source provenance and not immutable closure, global, opaque internal state, or concurrent in-place mutation after a returned handle. A malicious caller-supplied compiler remains trusted/unknown, not independently verified. The signature predicate binds the existing ABI plus slot bounds used by the current linker; slot descriptions are not execution identity. NaN comparisons follow Python numeric semantics and are not asserted as equivalent across distinct NaN instances.',
 'generated_family':'Persistent Specialization and MethodArtifact identities are unchanged. Five canonical stubs unchanged; owner-driven generation checks and public inventory disposition remain for integration.',
 'public_surface':'CompilationCache, CompiledMethod and MethodCompiler are facade exports. Cache misses on ambiguity and an unbound custom compiler refusal are documented in README/release; existing manual unbound put/get remains supported. Inventory review and release-schema checks remain.',
 'affected_checks':['Two R10 missing/raising fallback regressions and normal fusion; same-FQN warm-cache class outputs in sequential/async both orders', 'Public put/get/publish/invalidate and JIT-01 shared-flight/generation tests', 'Changed signature, equal-ABI changed and numerically equivalent slot bounds including large integers, selected-A relookup, callable and code replacement, opaque forged code marker, concurrent distinct flights, custom compiler boundary', 'Frozen deciding removal controls and restored positives', 'Strict mypy positive and clean negative on affected compiler/chain; actual Ray backend qualification separately'],
 'pattern_pass':{'P27':'Existing compiler and fused cache owners with one private binding.', 'P29':'Behavioral warmed-cache witnesses and removal controls exercise actual selected outputs.', 'P31':'Public registry through common JAX bridge plus ordinary and fused caches, rather than a registry-lookup instance patch.', 'P38':'FQN, ABI digest, and a mere code-shaped marker are inadequate proxies for implementation identity; distinguish by actual class/callable/code type and slot bounds.', 'P40':'Same ownership class widened as a single mechanism; mutable closures, globals and opaque state are explicit bounded residuals.', 'P41':'Previously observed two fallback failures stay source-bound FAIL until requalified.'},
 'runtime':'UNRUN','ray_backend':'UNRUN','G_acceptance':False,'closure_ids':[]}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'head':head,'tree':tree,'changed':len(files),'unchanged_companions':len(unchanged),'ruff_checks':len(static)-1,'controls':len(controls),'patch_sha256':digest(full),'manifest_sha256':digest((out/'manifest.json').read_bytes()),'static_results_sha256':digest((out/'static-results.json').read_bytes())},indent=2))
