from pathlib import Path
OUT=Path(__file__).resolve().parent;P=OUT/'postimages/policy-engine/src/polisyos/foundry/calibration/execution_basis.py'
s=P.read_text()
def repl(old,new):
 global s
 assert s.count(old)==1,(old[:100],s.count(old));s=s.replace(old,new)
repl('if self.schema_version == "1.2" and roster_names != CALIBRATION_RUNTIME_INPUT_NAMES:', 'if self.schema_version == "1.2" and roster_names != CALIBRATION_RUNTIME_INPUT_NAMES_V1_2:')
repl('        if any(not _is_sha256(value) for value in self.report_envelope_sha256.values()):','''        if self.ordered_batch_profile is not None:
            profile = self.ordered_batch_profile
            if self.target_order != (profile.target_id,):
                raise ValueError("ordered_batch_target_must_match_complete_report_target_order")
            target = self.target_inputs[0]
            if (
                canonical_input_sha256(profile.targets) != target.observed_values_sha256
                or calibration_report_time_axis_sha256([float(t) for t in profile.row_times])
                != target.report_time_axis_sha256
            ):
                raise ValueError("ordered_batch_profile_must_match_report_observations_and_rows")
            binding = self.runtime_input_roster[-1]
            if (
                binding.status != "resolved_output_content_bound"
                or binding.resolved_by != ("ordered_batch_profile",)
                or binding.value_sha256 != profile.consumed_profile_sha256
            ):
                raise ValueError("ordered_batch_runtime_binding_must_match_complete_profile")
        if any(not _is_sha256(value) for value in self.report_envelope_sha256.values()):''')
anchor='def put_calibration_execution_input_basis('
helper='''def reconcile_ordered_batch_inputs(
    store: ArtifactStore,
    profile: CalibrationOrderedBatchInput,
    *,
    inputs: Sequence[InputRef],
) -> None:
    """Reopen every selected row and recompute the complete consumed profile.

    Snapshot identity proves local consumed bytes, never external attestation,
    physical time, observation independence or a calibration/noise law.
    """
    from polisyos.foundry.execute import load_state_snapshot

    expected_roles = tuple(f"ordered_batch_row.{i}" for i in range(len(profile.rows)))
    actual_edges = tuple(edge for edge in inputs if edge.role.startswith("ordered_batch_row."))
    if tuple(edge.role for edge in actual_edges) != expected_roles:
        raise ValueError("ordered_batch_selected_row_edges_must_be_complete_and_ordered")
    states = []
    for row, edge in zip(profile.rows, actual_edges, strict=True):
        ref = row.state_snapshot_ref
        if (
            edge.artifact_id != ref.artifact_id
            or edge.manifest_profile_sha256 != ref.manifest_profile_sha256
        ):
            raise ValueError("ordered_batch_selected_row_edge_mismatch")
        manifest = store.get_manifest(ref)
        if manifest.kind != "foundry.state_snapshot" or not store.verify(ref).ok:
            raise ValueError("ordered_batch_selected_state_integrity_failure")
        state = load_state_snapshot(store, snapshot_ref=ref)
        if canonical_input_sha256(state) != row.state_values_sha256:
            raise ValueError("ordered_batch_selected_state_values_mismatch")
        states.append(state)
    batched_state = jax.tree_util.tree_map(lambda *values: np.stack(values), *states)
    targets = np.asarray(profile.targets, dtype=np.dtype(profile.targets_dtype))
    weights = np.asarray(profile.weights, dtype=np.dtype(profile.weights_dtype))
    if tuple(targets.tolist()) != profile.targets or tuple(weights.tolist()) != profile.weights:
        raise ValueError("ordered_batch_values_must_match_declared_array_dtype_exactly")
    actual_profile = {
        "row_ids": tuple(row.row_id for row in profile.rows),
        "states": batched_state,
        "row_times": np.asarray(profile.row_times, dtype=np.dtype(profile.row_times_dtype)),
        "row_keys": np.asarray(profile.row_keys, dtype=np.uint32),
        "target_path": profile.target_path,
        "targets": targets,
        "weights": weights,
    }
    if canonical_input_sha256(actual_profile) != profile.consumed_profile_sha256:
        raise ValueError("ordered_batch_complete_consumed_profile_mismatch")


'''
repl(anchor,helper+anchor)
repl('    """Persist one typed calibration execution-input basis with exact input edges."""\n    return store.put_json(','''    """Persist a freshly validated basis; row identity is admitted before publication."""
    basis = CalibrationExecutionInputBasis.model_validate(basis.model_dump(mode="python"))
    if basis.ordered_batch_profile is not None:
        reconcile_ordered_batch_inputs(store, basis.ordered_batch_profile, inputs=inputs)
    return store.put_json(''')
repl('    if basis.schema_version != schema.version:\n        raise ValueError("calibration_execution_input_basis_schema_version_mismatch")\n    return basis','''    if basis.schema_version != schema.version:
        raise ValueError("calibration_execution_input_basis_schema_version_mismatch")
    if basis.ordered_batch_profile is not None:
        reconcile_ordered_batch_inputs(store, basis.ordered_batch_profile, inputs=manifest.inputs)
    return basis''')
repl('    "CalibrationExecutionInputBasis",','''    "CalibrationExecutionInputBasis",
    "CalibrationOrderedBatchInput",
    "CalibrationOrderedBatchRow",
    "reconcile_ordered_batch_inputs",
    "CALIBRATION_RUNTIME_INPUT_CONTRACT_V1_2",
    "CALIBRATION_RUNTIME_INPUT_NAMES_V1_2",''')
P.write_text(s)
