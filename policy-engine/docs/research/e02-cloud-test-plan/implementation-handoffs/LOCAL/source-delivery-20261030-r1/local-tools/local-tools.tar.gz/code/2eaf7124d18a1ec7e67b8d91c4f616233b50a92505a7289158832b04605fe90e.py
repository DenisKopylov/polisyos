"""Run Root's retained supervisor in-process, observing its real child Popen.

This wrapper does not start until explicitly invoked by Root. It changes only
Root's fresh case-local launcher bytes; all runner, sandbox and supervision
logic continues in the retained scripts. No product module is imported here.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import runpy
import signal
import subprocess
import sys

from parent_env_guard import ParentEnvironmentGuard
import qualify
from trampoline import trampoline

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
PROJECT = ROOT / 'policy-engine'
PACKET = Path(__file__).resolve().parent
RAW = ROOT / 'LOCAL/raw/e02-execution-20261027'
D = PROJECT / ('docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/'
               'root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/'
               'deep-task-status-audit-20261027-r1')
DRIVER = RAW / 'run_native_case_root.py'
RUNNER = D / 'run_case_with_tools_r3.py'
OBSERVER = D / 'readset_observer_tools_r1.py'
NODE = qualify.NODE


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition: bool, reason: str) -> None:
    if not condition:
        raise RuntimeError(reason)


def case_environment(role: str, case: Path) -> dict[str, str]:
    if role == 'removal':
        return {'E02_BASIS_REMOVAL_TRACE': str(case / 'basis-removal-trace.jsonl'),
                'E02_BASIS_REMOVAL_PLUGIN_SHA256': digest(PACKET / 'e02_basis_removal.py'),
                'E02_BASIS_REMOVAL_CORE_SHA256': digest(PACKET / 'mutation_core.py'),
                'E02_BASIS_REMOVAL_LAUNCHER_SHA256': digest(PACKET / 'pytest_launcher.py')}
    return {'E02_BASIS_RESTORE_TRACE': str(case / 'basis-restoration-trace.jsonl'),
            'E02_BASIS_RESTORE_LAUNCHER_SHA256': digest(PACKET / 'restored_launcher.py'),
            'E02_BASIS_RESTORE_CORE_SHA256': digest(PACKET / 'mutation_core.py'),
            'E02_BASIS_RESTORE_BINDING_SHA256': digest(PACKET / 'source-binding.stdout.json')}


def run_retained_driver(role: str, case_id: str, guard: ParentEnvironmentGuard) -> int:
    case = D / case_id
    target = PACKET / ('pytest_launcher.py' if role == 'removal' else 'restored_launcher.py')
    extra = case_environment(role, case)
    source_before = dict(os.environ)
    prior_argv = sys.argv
    prior_sigterm, prior_sigint = signal.getsignal(signal.SIGTERM), signal.getsignal(signal.SIGINT)
    original_run, original_popen, original_write_text = subprocess.run, subprocess.Popen, Path.write_text
    seen = {'trampoline': 0, 'spawn': 0, 'nested': 0}

    # R3 clears six controls before its supervisor merges the full environment.
    # Prevent any inherited probe from being silently propagated to any child.
    for key in tuple(os.environ):
        if key.startswith(('E02_BASIS_REMOVAL_', 'E02_BASIS_RESTORE_')):
            del os.environ[key]

    def observed_run(command, *args, **kwargs):
        if isinstance(command, (list, tuple)) and len(command) == 4 and command[2] == str(RUNNER):
            require(command[:2] == [str(PROJECT / '.venv/bin/python'), '-B'], 'nested interpreter mismatch')
            require(Path(command[3]) == D / (case_id + '.json') and not args and kwargs == {'cwd': ROOT}, 'nested runner arguments changed')
            seen['nested'] += 1
            require(seen['nested'] == 1, 'nested runner repeated')
            old_argv = sys.argv
            sys.argv = [str(RUNNER), command[3]]
            try:
                try:
                    runpy.run_path(str(RUNNER), run_name='__main__')
                except SystemExit as exc:
                    require(type(exc.code) is int, 'noninteger runner exit')
                    return subprocess.CompletedProcess(command, exc.code)
                raise RuntimeError('retained runner returned without an exit')
            finally:
                sys.argv = old_argv
        return original_run(command, *args, **kwargs)

    expected_original = ("import importlib.util, pathlib, sys\nimport pytest\npath=pathlib.Path("
                         + repr(str(OBSERVER))
                         + ")\nspec=importlib.util.spec_from_file_location('loaded_source_observer',path)\n"
                           "plugin=importlib.util.module_from_spec(spec); spec.loader.exec_module(plugin)\n"
                           "if __name__ == '__main__':\n    raise SystemExit(pytest.main(sys.argv[1:],plugins=[plugin]))\n")

    def observed_write_text(path, data, *args, **kwargs):
        if path == case / 'pytest_launcher.py':
            require(data == expected_original and seen['trampoline'] == 0, 'retained launcher template changed')
            seen['trampoline'] += 1
            data = trampoline(target)
        return original_write_text(path, data, *args, **kwargs)

    def observed_popen(*args, **kwargs):
        argv = args[0] if args else kwargs.get('args')
        if isinstance(argv, (list, tuple)) and argv and argv[0] == '/usr/bin/sandbox-exec':
            require(seen['trampoline'] == 1 and seen['spawn'] == 0, 'unexpected case spawn count/order')
            require(list(argv[:6]) == ['/usr/bin/sandbox-exec', '-f', str(case / 'child.sb'),
                                      str(PROJECT / '.venv/bin/python'), '-B', str(case / 'pytest_launcher.py')], 'actual sandbox/launcher argv changed')
            require(argv[-1] == NODE and kwargs.get('cwd') == str(PROJECT), 'actual test selector/cwd changed')
            env = kwargs.get('env')
            require(type(env) is dict and all(env.get(key) == value for key, value in extra.items()), 'actual merged child environment missing instrument')
            forbidden_prefix = 'E02_BASIS_RESTORE_' if role == 'removal' else 'E02_BASIS_REMOVAL_'
            require(not any(key.startswith(forbidden_prefix) for key in env), 'foreign instrument in actual child environment')
            expected_prefix = 'E02_BASIS_REMOVAL_' if role == 'removal' else 'E02_BASIS_RESTORE_'
            require({key for key in env if key.startswith(expected_prefix)} == set(extra), 'unexpected instrument key')
            proc = original_popen(*args, **kwargs)
            try:
                guard.record_spawn(role=role, pid=proc.pid, argv=argv, environment=env)
                seen['spawn'] += 1
            except BaseException:
                proc.kill()
                proc.wait()
                raise
            return proc
        return original_popen(*args, **kwargs)

    subprocess.run, subprocess.Popen, Path.write_text = observed_run, observed_popen, observed_write_text
    sys.argv = [str(DRIVER), case_id, str(PACKET / 'selector.json'),
                'R166 basis mapping: fresh positive, removal, restored positive', json.dumps(extra)]
    try:
        try:
            runpy.run_path(str(DRIVER), run_name='__main__')
        except SystemExit as exc:
            require(type(exc.code) is int, 'noninteger driver exit')
            require(seen == {'trampoline': 1, 'spawn': 1, 'nested': 1}, 'actual instrumentation path incomplete')
            return exc.code
        raise RuntimeError('retained driver returned without an exit')
    finally:
        subprocess.run, subprocess.Popen, Path.write_text = original_run, original_popen, original_write_text
        sys.argv = prior_argv
        signal.signal(signal.SIGTERM, prior_sigterm)
        signal.signal(signal.SIGINT, prior_sigint)
        os.environ.clear()
        os.environ.update(source_before)


def verify_step(role: str, case_id: str, exit_code: int) -> None:
    case = D / case_id
    expected = 1 if role == 'removal' else 0
    require(exit_code == expected, role + ' process exit differs')
    trace_path = case / ('basis-removal-trace.jsonl' if role == 'removal' else 'basis-restoration-trace.jsonl')
    events = [json.loads(line) for line in trace_path.read_text().splitlines()]
    if role == 'removal':
        launch, finish = qualify.one(events, 'admission'), qualify.one(events, 'session_finish')
        require(finish['classification'] == 'EXPECTED_SEMANTIC_REMOVAL' and finish['semantic_failure'] and finish['witness'], 'removal did not reach semantic assertion')
    else:
        launch = qualify.read_positive_trace(trace_path, packet=PACKET)
    qualify.read_xml(case / 'pytest.xml', expected_failure=bool(expected))
    readsets = list((case / 'readsets').glob('*.json'))
    require(len(readsets) == 1 and qualify.read_readset(readsets[0])['pid'] == launch['pid'], 'case readset mismatch')
    qualify.read_audit(case / 'audit-result.json', expected_pid=launch['pid'], expected_exit=expected, launch=launch)


def main() -> None:
    require(len(sys.argv) == 5, 'usage: wrapper BASELINE_CASE REMOVAL_CASE RESTORED_CASE PARENT_RECEIPT')
    names, receipt = sys.argv[1:4], Path(sys.argv[4])
    require(len(set(names)) == 3 and all(name and all(ch.isalnum() or ch in '-_' for ch in name) for name in names), 'invalid or duplicate case identifiers')
    require(receipt.is_absolute() and not os.path.lexists(receipt), 'fresh absolute parent receipt required')
    manifest = json.loads((PACKET / 'manifest.json').read_text())
    for name, expected in manifest['active_packet_pins'].items():
        require('/' not in name and digest(PACKET / name) == expected, 'packet pin mismatch: ' + name)
    for path, expected in manifest['retained_harness_pins'].items():
        relative = Path(path)
        require(not relative.is_absolute() and '..' not in relative.parts and digest(ROOT / relative) == expected, 'retained harness pin mismatch: ' + path)
    binding = json.loads((PACKET / 'source-binding.stdout.json').read_text())
    head = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip()
    tree = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD^{tree}'], text=True).strip()
    require((head, tree) == (binding['current_journaled_head'], binding['current_tree']), 'frozen source differs')
    with ParentEnvironmentGuard(receipt) as guard:
        for role, name in zip(('baseline', 'removal', 'restored'), names, strict=True):
            code = run_retained_driver(role, name, guard)
            verify_step(role, name, code)
    print(json.dumps({'status': 'THREE_LAUNCHES_OBSERVED', 'cases': names,
                      'parent_env_receipt': str(receipt), 'source_head': head, 'source_tree': tree,
                      'next': 'run qualify.py against the actual retained outputs and Root Git readbacks'}))


if __name__ == '__main__':
    main()
