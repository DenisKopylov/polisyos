"""Read pinned complete source blobs plus the one sparse C81 source overlay."""
from pathlib import Path
import ast
import hashlib
import json
import subprocess

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
OUT = Path(__file__).resolve().parent
BASE = '545c6990e2bfa42bf580b475e23cf88df04e71d8'
SYMBOLS = {
    'PosteriorSummaryV11', 'PosteriorParameterSummary',
    'summarize_posterior_draw_artifact', 'persist_posterior_summary',
    'load_posterior_summary', 'persist_posterior_summary_from_method_evidence',
    'load_persisted_posterior_summary', 'propagate_posterior_summary',
}
raw = subprocess.check_output(['git', 'ls-tree', '-rz', BASE, '--', 'policy-engine/src'], cwd=ROOT)
rows = []
for entry in raw.split(b'\0'):
    if not entry:
        continue
    metadata, encoded_path = entry.split(b'\t', 1)
    mode, kind, oid = metadata.decode().split()
    path = encoded_path.decode()
    if kind == 'blob' and path.endswith('.py'):
        rows.append((path, oid))
rows.sort()
process = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=ROOT, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
output, _ = process.communicate(('\n'.join(oid for _path, oid in rows) + '\n').encode())
assert process.returncode == 0
position = 0
matched = []
selected_digest = hashlib.sha256()
parse_errors = []
for path, oid in rows:
    newline = output.index(b'\n', position)
    header = output[position:newline].decode().split()
    assert header[:2] == [oid, 'blob']
    size = int(header[2])
    original = output[newline + 1:newline + 1 + size]
    position = newline + 1 + size + 1
    overlay = OUT / path
    body = overlay.read_bytes() if overlay.is_file() else original
    digest = hashlib.sha256(body).hexdigest()
    selected_digest.update(path.encode() + b'\0' + digest.encode() + b'\n')
    present = sorted(symbol for symbol in SYMBOLS if symbol.encode() in body)
    if not present:
        continue
    try:
        tree = ast.parse(body)
    except SyntaxError as exc:
        parse_errors.append({'path': path, 'error': str(exc)})
        continue
    aliases = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            for item in node.names:
                if item.name in SYMBOLS:
                    aliases[item.asname or item.name] = item.name
    calls = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        fn = node.func
        if isinstance(fn, ast.Name):
            symbol = aliases.get(fn.id, fn.id)
        elif isinstance(fn, ast.Attribute):
            symbol = fn.attr
            if isinstance(fn.value, ast.Name) and aliases.get(fn.value.id, fn.value.id) in SYMBOLS:
                symbol = aliases.get(fn.value.id, fn.value.id) + '.' + fn.attr
        else:
            continue
        if symbol in SYMBOLS or any(symbol.startswith(name + '.') for name in SYMBOLS):
            calls.append({'line': node.lineno, 'symbol': symbol, 'keywords': [kw.arg for kw in node.keywords]})
    matched.append({'path': path, 'base_git_blob': oid, 'candidate_sha256': digest, 'overlay': body != original, 'symbols': present, 'literal_calls': calls})
assert position == len(output)
record = {
    'base': BASE, 'base_tree': subprocess.check_output(['git','rev-parse',BASE+'^{tree}'], cwd=ROOT, text=True).strip(),
    'path_denominator': 'all tracked policy-engine/src/**/*.py blobs at base plus declared sparse source postimage',
    'file_type_denominator': '*.py', 'source_file_count': len(rows), 'source_set_sha256': selected_digest.hexdigest(),
    'matched_file_count': len(matched), 'literal_call_count': sum(len(item['literal_calls']) for item in matched),
    'parse_errors': parse_errors, 'rows': matched,
    'limitations': ['Literal/source AST census only; dynamic adapters, non-Python, tools and test code are not an absence claim.', 'No product imports, execution, native proof or G acceptance.'],
}
(OUT/'consumer-census.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps({key:record[key] for key in ('source_file_count','matched_file_count','literal_call_count','source_set_sha256','parse_errors')}))
