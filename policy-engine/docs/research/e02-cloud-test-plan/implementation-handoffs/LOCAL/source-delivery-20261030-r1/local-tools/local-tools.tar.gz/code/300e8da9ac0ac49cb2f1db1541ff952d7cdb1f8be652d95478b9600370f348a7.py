from pathlib import Path
p=Path('LOCAL/raw/e02-execution-20261027/repairs/C17-r2/removal_controls')
f=p/'lex_impact_removal_plugin.py';s=f.read_text()
def change(old: str,new: str) -> None:
 global s
 assert s.count(old)==1,(s.count(old),old[:90]);s=s.replace(old,new)
change('import os\nfrom pathlib import Path', 'import os\nimport textwrap\nfrom pathlib import Path')
change('''        owner, name = impact_diff.NormImpactAnalyzer, "_infer_affected_kpis"
        original = getattr(owner, name)
''', '''        owner, name = impact_diff, "_infer_candidate_topics_v1_1"
        original = getattr(owner, name)
''')
change('''        def mutant(self: Any, diff: Any) -> Any:
            topics = original(self, diff)
''', '''        def mutant(diff: Any) -> Any:
            topics = original(diff)
''')
change('''    elif mode == "report_bridge":
''', '''    elif mode in {"report_reconciliation", "diff_reconstruction"}:
        owner, name = impact_diff, "_reconcile_selected_report"
        original = getattr(owner, name)

        def mutant(report: Any, diff: Any) -> None:
            # Remove only the 1.1 content reconciliation, preserving the exact
            # selected-profile edge, kind, report shape and marker strings.
            return None

    elif mode == "scope_guard":
        owner, name = impact_diff.NormImpactAnalyzer, "analyze"
        original = getattr(owner, name)
        tree = ast.parse(textwrap.dedent(inspect.getsource(original)))

        class RemoveScopeGuard(ast.NodeTransformer):
            count = 0

            def visit_If(self, node: ast.If) -> Any:
                test = ast.unparse(node.test)
                if (
                    "old_pack.jurisdiction != new_pack.jurisdiction" in test
                    and "self._report_schema_version == '1.1'" in test
                ):
                    self.count += 1
                    node.test = ast.Constant(value=False)
                return self.generic_visit(node)

        transformer = RemoveScopeGuard()
        mutated = ast.fix_missing_locations(transformer.visit(tree))
        if transformer.count != 1:
            raise RuntimeError(f"unexpected scope guard count: {transformer.count}")
        namespace = dict(vars(impact_diff))
        exec(compile(mutated, inspect.getsourcefile(original) or "<missing>", "exec"), namespace)
        mutant = namespace[name]

    elif mode == "report_bridge":
''')
f.write_text(s)
f=p/'prepare_plans.py';s=f.read_text()
assert s.count('repairs/C17"')==1;s=s.replace('repairs/C17"','repairs/C17-r2"')
old='''        "manifest_edge": "test_selected_diff_profile_is_reconciled_with_issued_report_manifest",
'''
new=old+'''        "report_reconciliation": "test_selected_report_refuses_forged_derived_values[norms_added-report_norm_diff_counts_mismatch]",
        "diff_reconstruction": "test_selected_report_refuses_incoherent_embedded_diff[missing_added_rule]",
        "scope_guard": "test_cross_jurisdiction_is_declared_for_legacy_and_refused_for_opt_in",
'''
assert s.count(old)==1;s=s.replace(old,new)
f.write_text(s)
print('Prepared seven source-pinned removal scenarios for r2; none executed')
