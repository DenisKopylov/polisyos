"""Prepare only an exact C25 plan for the retained root native supervisor."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
from pathlib import Path

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
PRODUCT = ROOT / 'policy-engine'
REPAIRS = ROOT / 'LOCAL/raw/e02-execution-20261027/repairs'
DDM_TEST = 'tests/unit/ddm/test_observation_source_admission.py'
RUNNER_DIR = PRODUCT / ('docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/'
    'root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/'
    'deep-task-status-audit-20261027-r1')
MANIFESTS = [
    ('C25-r2', 'fe02102d0cf4ea52684edad9028f78e90357e69563fe5694eaa7f1e026bcf1e3'),
    ('C25-r2-file-admission-supplement', '06beb47977efa707883ebb4288aeb018a7b87f3a66beef0caa450774075b6f0e'),
    ('C25-r2-context-supplement', '84a687878e43bb1e7c33143262ae30e27ccf0a00686c5e994433fdb7f7067e63'),
]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args: str) -> str:
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--admitted-head', required=True)
    parser.add_argument('--case-id', required=True)
    parser.add_argument('--mode', required=True,
        choices=['pilot', 'full', 'removal_trigger', 'removal_budget'])
    args = parser.parse_args()
    assert args.case_id and all(c.isalnum() or c in '-_' for c in args.case_id)
    assert git('symbolic-ref', '--short', 'HEAD') == 'codex/e02-unified-local-20261009'
    assert git('rev-parse', 'HEAD') == args.admitted_head
    final = {}
    for folder, digest in MANIFESTS:
        path = REPAIRS / folder / 'manifest.json'
        assert sha(path) == digest, path
        manifest = json.loads(path.read_text())
        for row in manifest['files']:
            final[row['path']] = row
    # Deliberately bind maintained Python and the governed DDM schema, not prose.
    source_pins = {}
    for path, row in final.items():
        if not (path.endswith('.py') or path.endswith('.schema.json')):
            continue
        actual = ROOT / path
        assert actual.is_file() and not actual.is_symlink(), path
        assert sha(actual) == row['postimage_sha256'], (path, 'reviewed source mismatch')
        assert git('status', '--porcelain', '--', path) == '', (path, 'commit before native run')
        source_pins[path] = sha(actual)
    assert len(source_pins) == 8
    extra_env = {}
    if args.mode == 'pilot':
        nodes = [
            DDM_TEST+'::test_enumerated_empty_replay_is_valid_but_cannot_grant_production',
            DDM_TEST+'::test_omitted_trigger_is_read_from_source_and_stale_evidence_is_refused',
        ]
    elif args.mode == 'full':
        nodes = [DDM_TEST, 'tests/unit/ddm/test_full_acceptance.py',
            'tests/unit/ddm/test_stationary_replay.py']
    else:
        mode = 'trigger_enumeration' if args.mode == 'removal_trigger' else 'budget_reconciliation'
        source_path = ('src/polisyos/ddm/calibration/observations.py'
            if args.mode == 'removal_trigger'
            else 'src/polisyos/ddm/integration/model_registry.py')
        node = ('test_omitted_trigger_is_read_from_source_and_stale_evidence_is_refused'
            if args.mode == 'removal_trigger'
            else 'test_wrong_budget_consumption_is_recomputed_despite_matching_source_labels')
        nodes = [DDM_TEST+'::'+node]
        plugin = REPAIRS/'C25-r2/removal_plugin.py'
        assert sha(plugin) == 'f9e58a6d23927e7e975c85081612f1e02b608a8cde3a5082879a3d13a16ac6c9'
        extra_env = {
            'PYTHONPATH': os.pathsep.join([str(plugin.parent), str(PRODUCT/'src')]),
            'PYTEST_PLUGINS': 'removal_plugin',
            'C25_REMOVAL_MODE': mode,
            'C25_EXPECTED_SOURCE_SHA256': sha(PRODUCT/source_path),
            'C25_CONTROL_OUTPUT_DIR': str(RUNNER_DIR/args.case_id/'c25-control'),
        }
    plan_path = RUNNER_DIR/(args.case_id+'.json')
    assert not plan_path.exists() and not (RUNNER_DIR/args.case_id).exists()
    runner = RUNNER_DIR/'run_case_with_tools_r2.py'
    assert sha(runner) == '4c3eae2136b6c8941ba09d4438d12ea6ea11310527768f0482877b877b8e30c2'
    plan = {
        'case_id': args.case_id, 'source_head': args.admitted_head,
        'task_ids': ['DDM-02', 'LA-054', 'LA-055'], 'nodes': nodes,
        'extra_env': extra_env, 'deadline_seconds': 600 if args.mode == 'full' else 300,
        'rss_cap_bytes': 2411724800,
        'scope': ('C25 '+args.mode+': finite-source protocol and truthful authority limitation only; '
            'production observation owner/selection/coverage/currentness remain not_established; '
            'no G acceptance, deployment action or full LA054/055 closure. Native pytest.ini/default '
            'plugins retained; matched controls must fail at the named property assertion, not setup.'),
        'reviewed_source_pins': source_pins,
        'criterion_pointers': ['#/findings/278/criterion_refs/0', '#/findings/279/criterion_refs/0'],
        'closure_ids': [],
    }
    plan_path.write_text(json.dumps(plan, indent=2)+'\n')
    assert json.loads(plan_path.read_text()) == plan
    print(json.dumps({'prepared_only': True, 'plan': str(plan_path), 'sha256': sha(plan_path),
        'source_head': args.admitted_head, 'selected_nodes': nodes, 'runtime': 'UNRUN'}))


if __name__ == '__main__':
    main()
