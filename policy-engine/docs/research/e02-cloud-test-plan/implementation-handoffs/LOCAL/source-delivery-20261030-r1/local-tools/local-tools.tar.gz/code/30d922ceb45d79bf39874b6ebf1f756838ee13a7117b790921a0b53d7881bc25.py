"""Source-bound in-memory removals for the C18 corrected-RDD discriminator.

This plugin is an optional test control. It is not product code and must be run
only with the source-frozen native supervisor described in the adjacent README.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any

import pytest

_original: Any = None
_active: Any = None
_module: Any = None
_state: dict[str, object] = {}


def _digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pytest_configure(config: pytest.Config) -> None:
    global _active, _module, _original, _state
    from polisyos.foundry.methods.catalog.causal import rdd

    mode = os.environ.get("C18_REMOVAL_MODE")
    if mode not in {"point", "variance"}:
        raise pytest.UsageError("C18_REMOVAL_MODE must be point or variance")
    source = Path(rdd.__file__).resolve()
    test = Path(os.environ["C18_EXPECTED_TEST_PATH"]).resolve()
    plugin = Path(__file__).resolve()
    for label, path, env_key in (
        ("RDD source", source, "C18_EXPECTED_RDD_SHA256"),
        ("test", test, "C18_EXPECTED_TEST_SHA256"),
        ("plugin", plugin, "C18_EXPECTED_PLUGIN_SHA256"),
    ):
        if _digest(path) != os.environ[env_key]:
            raise pytest.UsageError(f"C18 {label} content differs from source-bound control")
    if not any("test_independent_sensitivity_oracle_matches_corrected_point_and_hc0_se" in str(arg) for arg in config.args):
        raise pytest.UsageError("C18 removal requires the independent point/SE discriminator")
    _module = rdd
    _original = rdd._fit_rbc_polynomial

    def remove(*args: object, **kwargs: object) -> tuple[float, float, float, float, int, int]:
        conventional, corrected, variance_us, variance_rb, n_h, n_b = _original(*args, **kwargs)
        if mode == "point":
            corrected = conventional
        else:
            variance_rb = variance_us
        return conventional, corrected, variance_us, variance_rb, n_h, n_b

    _active = remove
    rdd._fit_rbc_polynomial = _active
    _state = {
        "mode": mode,
        "requested_source_head": os.environ["C18_EXPECTED_SOURCE_HEAD"],
        "rdd_path": str(source),
        "rdd_sha256": _digest(source),
        "test_path": str(test),
        "test_sha256": _digest(test),
        "plugin_sha256": _digest(plugin),
        "original_code_sha256": hashlib.sha256(_original.__code__.co_code).hexdigest(),
        "active_code_sha256": hashlib.sha256(_active.__code__.co_code).hexdigest(),
        "check": "target test asserts corrected-profile marker before independent point/SE",
    }


def pytest_sessionfinish(session: pytest.Session, exitstatus: int) -> None:
    if _module is None:
        return
    active = _module._fit_rbc_polynomial is _active
    _module._fit_rbc_polynomial = _original
    _state.update(
        {
            "mutation_still_active_at_finish": active,
            "original_restored": _module._fit_rbc_polynomial is _original,
            "pytest_exit": exitstatus,
        }
    )
    folder = Path(os.environ["C18_CONTROL_OUTPUT_DIR"])
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "control-mutation.json").write_text(json.dumps(_state, indent=2) + "\n")
    if not active:
        raise pytest.UsageError("C18 removal was replaced before session end; control invalid")
