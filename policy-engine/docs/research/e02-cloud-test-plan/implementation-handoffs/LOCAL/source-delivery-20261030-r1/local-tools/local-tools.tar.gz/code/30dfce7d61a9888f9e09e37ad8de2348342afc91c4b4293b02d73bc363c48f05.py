from __future__ import annotations

import hashlib
import importlib
import importlib.metadata
import json
import os
import platform
import sys
import sysconfig
import time
from pathlib import Path
from typing import Any

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos").resolve()
PRODUCT = ROOT / "policy-engine"
TARGET = "polisyos.runtime.quality.confidence_ledger"
SOURCE_ROOTS = {
    "src": PRODUCT / "src",
    "tools": PRODUCT / "tools",
    "tests": PRODUCT / "tests",
}
THREAD_VARS = (
    "OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
    "NUMBA_NUM_THREADS", "NUMEXPR_NUM_THREADS", "ARROW_NUM_THREADS",
    "BLIS_NUM_THREADS", "POLARS_MAX_THREADS", "TF_NUM_INTEROP_THREADS",
    "TF_NUM_INTRAOP_THREADS", "VECLIB_MAXIMUM_THREADS",
    "SCIENTIST_TORCH_NUM_THREADS", "SCIENTIST_TORCH_NUM_INTEROP_THREADS",
)


def type_name(value: Any) -> str:
    cls = type(value)
    return f"{cls.__module__}.{cls.__qualname__}"


def within(path: Path, base: Path) -> bool:
    try:
        path.relative_to(base)
        return True
    except ValueError:
        return False


def digest_path(path: Path) -> dict[str, Any]:
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def simple_value(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    enum_value = getattr(value, "value", None)
    if isinstance(enum_value, (str, int, float, bool)):
        return enum_value
    return str(value)


def failure_record(module: Any) -> dict[str, Any] | None:
    value = getattr(module, "_IMPORT_TIME_DEPLOYMENT_IDENTITY_FAILURE", None)
    if value is None:
        return None
    if not isinstance(value, tuple) or len(value) != 2:
        return {"shape": "unexpected", "type": type_name(value)}
    code, detail = value
    if not isinstance(detail, str):
        detail = str(detail)
    encoded = detail.encode("utf-8", errors="surrogatepass")
    return {
        "shape": "tuple[str,str]",
        "code": code if isinstance(code, str) else str(code),
        "detail": detail[:4096],
        "detail_characters": len(detail),
        "detail_utf8_bytes": len(encoded),
        "detail_sha256": hashlib.sha256(encoded).hexdigest(),
        "detail_truncated": len(detail) > 4096,
    }


def resolved_if_path(value: Any) -> tuple[str | None, bool]:
    if not isinstance(value, str) or value in {"built-in", "frozen"}:
        return None, False
    try:
        path = Path(value)
        return str(path.resolve(strict=True)), True
    except (OSError, RuntimeError, ValueError):
        return None, False


def main() -> int:
    before_names = set(sys.modules)
    start_ns = time.time_ns()
    target_preloaded = TARGET in sys.modules
    module = sys.modules.get(TARGET) if target_preloaded else None
    import_exc: dict[str, Any] | None = None
    if target_preloaded:
        preloaded_text = "Target was already present in sys.modules; no second import was attempted."
        import_exc = {
            "type": "TargetPreloadedBeforeExplicitImport",
            "text": preloaded_text,
            "text_characters": len(preloaded_text),
            "text_truncated": False,
            "text_sha256": hashlib.sha256(preloaded_text.encode()).hexdigest(),
        }
    else:
        try:
            module = importlib.import_module(TARGET)
        except BaseException as exc:
            msg = str(exc)
            import_exc = {
                "type": type_name(exc),
                "text": msg[:4096],
                "text_characters": len(msg),
                "text_truncated": len(msg) > 4096,
                "text_sha256": hashlib.sha256(msg.encode("utf-8", errors="surrogatepass")).hexdigest(),
            }
            module = sys.modules.get(TARGET)

    import_finished_ns = time.time_ns()
    target_spec = getattr(module, "__spec__", None) if module is not None else None
    captured = None
    capture_exc = None
    if module is not None:
        capture_fn = getattr(module, "capture_loaded_deployment_identity", None)
        if callable(capture_fn):
            try:
                observation = capture_fn()
                captured = {
                    "type": type_name(observation),
                    "status": simple_value(getattr(observation, "status", None)),
                    "reason_code": simple_value(getattr(observation, "reason_code", None)),
                }
            except BaseException as exc:
                capture_exc = {
                    "type": type_name(exc),
                    "text": str(exc)[:4096],
                    "text_characters": len(str(exc)),
                }

    failure = failure_record(module) if module is not None else None
    closure = getattr(module, "_IMPORT_TIME_AUTHORITY_IMPORT_CLOSURE", None) if module is not None else None
    try:
        closure_length = len(closure) if closure is not None else None
    except BaseException:
        closure_length = None
    consistent = getattr(module, "_IMPORT_TIME_LOADED_CODE_CONSISTENT", None) if module is not None else None

    roots = {name: path.resolve() for name, path in SOURCE_ROOTS.items()}
    module_rows: dict[str, dict[str, Any]] = {}
    file_rows: dict[str, dict[str, Any]] = {}
    for name, loaded in sorted(tuple(sys.modules.items()), key=lambda item: item[0]):
        if loaded is None:
            continue
        spec = getattr(loaded, "__spec__", None)
        origin = getattr(spec, "origin", None) if spec is not None else None
        file_value = getattr(loaded, "__file__", None)
        loader = getattr(spec, "loader", None) if spec is not None else None
        candidate_records: list[dict[str, Any]] = []
        for field, raw in (("origin", origin), ("file", file_value)):
            physical, exists = resolved_if_path(raw)
            if physical is None:
                continue
            resolved = Path(physical)
            labels = [label for label, base in roots.items() if within(resolved, base)]
            if not labels:
                continue
            label = labels[0]
            candidate_records.append({
                "field": field,
                "raw": raw,
                "resolved": physical,
                "root": label,
                "exists": exists,
                "suffix": resolved.suffix,
            })
            if exists:
                key = physical
                if key not in file_rows:
                    item = digest_path(resolved)
                    try:
                        relative = resolved.relative_to(ROOT).as_posix()
                    except ValueError:
                        relative = None
                    file_rows[key] = {
                        "path": physical,
                        "repo_relative_path": relative,
                        "root": label,
                        "bytes": item["bytes"],
                        "sha256": item["sha256"],
                        "modules": [],
                    }
                file_rows[key]["modules"].append(name)
        if candidate_records:
            module_rows[name] = {
                "module_name": name,
                "spec_origin": origin if isinstance(origin, str) else None,
                "module_file": file_value if isinstance(file_value, str) else None,
                "loader_type": type_name(loader) if loader is not None else None,
                "cached": getattr(loaded, "__cached__", None),
                "spec_origin_equals_file": (
                    isinstance(origin, str)
                    and isinstance(file_value, str)
                    and Path(origin).resolve(strict=False) == Path(file_value).resolve(strict=False)
                ),
                "new_during_target_import": name not in before_names,
                "in_repository_origins": candidate_records,
            }

    target_present = TARGET in module_rows
    strict_map_valid = (
        bool(module_rows)
        and target_present
        and all(
            isinstance(key, str)
            and key
            and isinstance(value, dict)
            and value.get("module_name") == key
            and bool(value.get("in_repository_origins"))
            for key, value in module_rows.items()
        )
    )
    dist_versions = {}
    for dist in ("pydantic", "pydantic-settings", "numpy", "scipy", "jax", "torch", "polars"):
        try:
            dist_versions[dist] = importlib.metadata.version(dist)
        except importlib.metadata.PackageNotFoundError:
            dist_versions[dist] = None

    result = {
        "schema": "policyos.e02.n7.import_only_probe.r152.v1",
        "probe_outcome": ("target_preloaded_before_explicit_import" if target_preloaded else ("import_completed" if import_exc is None else "import_exception_captured")),
        "import_exception": import_exc,
        "target": {
            "name": TARGET,
            "present_in_sys_modules": module is not None,
            "module_file": getattr(module, "__file__", None) if module is not None else None,
            "spec_origin": getattr(target_spec, "origin", None) if target_spec is not None else None,
            "loader_type": type_name(getattr(target_spec, "loader", None)) if target_spec is not None and getattr(target_spec, "loader", None) is not None else None,
            "cached": getattr(module, "__cached__", None) if module is not None else None,
            "sys_pycache_prefix": sys.pycache_prefix,
            "origin_file_exact_match": (
                isinstance(getattr(target_spec, "origin", None), str)
                and isinstance(getattr(module, "__file__", None), str)
                and Path(target_spec.origin).resolve(strict=False) == Path(module.__file__).resolve(strict=False)
            ) if module is not None and target_spec is not None else False,
            "source_sha256": digest_path(Path(module.__file__))["sha256"] if module is not None and isinstance(getattr(module, "__file__", None), str) and Path(module.__file__).is_file() else None,
        },
        "sticky_import_time": {
            "loaded_code_consistent": consistent if isinstance(consistent, bool) else None,
            "failure_tuple": failure,
            "authority_import_closure_type": type_name(closure) if closure is not None else None,
            "authority_import_closure_length": closure_length,
            "authority_import_closure_installed": bool(closure_length),
            "failure_present_with_empty_closure": bool(failure is not None and closure_length == 0),
        },
        "captured_observation": captured,
        "captured_observation_exception": capture_exc,
        "python": {
            "executable": sys.executable,
            "version": sys.version,
            "implementation": platform.python_implementation(),
            "cache_tag": sys.implementation.cache_tag,
            "prefix": sys.prefix,
            "base_prefix": sys.base_prefix,
            "platform": sysconfig.get_platform(),
            "sys_path": sys.path,
            "home_inherited": os.environ.get("HOME"),
            "pycache_prefix": os.environ.get("PYTHONPYCACHEPREFIX"),
            "pycache_prefix_initially_empty": True,
            "temporary_environment": {
                name: os.environ.get(name)
                for name in (
                    "TMPDIR", "XDG_CACHE_HOME", "XDG_CONFIG_HOME", "XDG_DATA_HOME",
                    "XDG_STATE_HOME", "MPLCONFIGDIR", "NUMBA_CACHE_DIR",
                )
            },
            "numeric_threads": {name: os.environ.get(name) for name in THREAD_VARS},
            "distribution_versions": dist_versions,
        },
        "first_party_origin_map": {
            "schema": "policyos.e02.finite_first_party_python_origins.r1",
            "nonempty": bool(module_rows),
            "strict_typed_map_valid": strict_map_valid,
            "target_in_map": target_present,
            "module_count": len(module_rows),
            "file_count": len(file_rows),
            "modules": module_rows,
            "files": file_rows,
            "scope": "Loaded parent-process Python module origins physically under policy-engine/src, tools, or tests; no child/native/unloaded claim.",
        },
        "timing_ns": {
            "import_started": start_ns,
            "import_finished": import_finished_ns,
            "import_elapsed": import_finished_ns - start_ns,
        },
    }
    print(json.dumps(result, sort_keys=True, separators=(",", ":"), ensure_ascii=True))
    return 0 if strict_map_valid else 3


if __name__ == "__main__":
    raise SystemExit(main())
