import hashlib,json,pathlib,runpy,sys
P=pathlib.Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos/policy-engine')
sys.argv=['/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos/LOCAL/raw/e02-execution-20261027/runtime-prep/N7-candidate-bundle-design-r6/prepare_candidate_inputs.py',"--repo-root",'/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos',"--case-id","n7-inputs-r83"]
try:
 runpy.run_path(sys.argv[0],run_name="__main__")
finally:
 rows={}
 for mod in tuple(sys.modules.values()):
  f=getattr(mod,"__file__",None)
  if not isinstance(f,str):continue
  q=pathlib.Path(f).resolve()
  if q.suffix==".py" and q.is_relative_to(P) and q.relative_to(P).parts[0] in ("src","tests","tools") and q.is_file(): rows[str(q.relative_to(P))]=hashlib.sha256(q.read_bytes()).hexdigest()
 pathlib.Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos/LOCAL/raw/e02-execution-20261027/runtime-prep/N7-builder-r83/loaded-source.json').write_text(json.dumps(rows,indent=2)+"\n")
