"""Independent HTTP release oracles; awaiting a real owner-backed fixture.

RAW draft only, not collected in the repository. ``admitted_child_case`` must
invoke the actual configured engine, registry, attempt owner, staging/release
owner, tenant authorization and live FastAPI routes. It must never install a
fake release decision or answer HTTP reads from an in-memory mirror. See the
adjacent report for the required fixture contract and unsupported cases.
"""

from __future__ import annotations

from typing import Any

import pytest


def _get_exact(client: Any, ref: Any, route: str) -> Any:
    assert ref.manifest_profile_sha256 is not None
    return client.get(
        f"/api/v1/artifacts/{ref.artifact_id}/{route}",
        params={"manifest_profile_sha256": ref.manifest_profile_sha256},
        headers={"Accept": "application/octet-stream"},
    )


def _assert_refused(response: Any, secret: bytes) -> None:
    # 422 can indicate a malformed test request; 5xx is not a correct refusal.
    assert response.status_code in {403, 404, 409}, response.text
    assert secret not in response.content


def _assert_actual_release_refusal(result: Any, case: Any) -> None:
    # The expected reason comes from the independently checked owner contract,
    # not the response itself. NodeOutcome uses ok/skip/fail; a separate
    # release DTO can expose refused/limited.
    if result.status == "fail":
        assert result.error is not None
        assert result.error.code == case.expected_release_refusal_code
    else:
        assert result.status in {"refused", "limited"}
        assert result.reason_code == case.expected_release_refusal_code


@pytest.mark.parametrize("route", ["content", "download"])
def test_selected_profile_not_readable_until_actual_release(
    admitted_child_case: Any, route: str
) -> None:
    """Check actual served bytes before and after owner-controlled release."""
    case = admitted_child_case
    selected, sibling = case.start_actual_parent_and_pause_before_release()
    assert selected.manifest_profile_sha256 is not None
    assert sibling.manifest_profile_sha256 is not None
    assert len(case.selected_bytes) >= 32 and len(case.sibling_bytes) >= 32
    assert case.selected_bytes != case.sibling_bytes
    assert case.staging_store.get_bytes(selected) == case.selected_bytes
    assert case.staging_store.get_bytes(sibling) == case.sibling_bytes
    _assert_refused(_get_exact(case.client, selected, route), case.selected_bytes)
    _assert_refused(_get_exact(case.client, sibling, route), case.sibling_bytes)

    # This operation must bind actual selected output and the current root fence.
    case.resume_actual_parent_release()
    response = _get_exact(case.client, selected, route)
    assert response.status_code == 200, response.text
    assert response.content == case.selected_bytes
    _assert_refused(_get_exact(case.client, sibling, route), case.sibling_bytes)


@pytest.mark.parametrize("route", ["content", "download"])
def test_other_authorized_profile_does_not_release_child_occurrence(
    admitted_child_case: Any, route: str
) -> None:
    """The same digest in a different admitted profile carries no child grant."""
    case = admitted_child_case
    previous, child = case.start_parent_with_preexisting_authorized_identical_blob_and_pause()
    assert previous.artifact_id == child.artifact_id
    assert previous.manifest_profile_sha256 != child.manifest_profile_sha256
    assert len(case.selected_bytes) >= 32
    assert case.staging_store.get_bytes(child) == case.selected_bytes
    before = _get_exact(case.client, previous, route)
    assert before.status_code == 200 and before.content == case.selected_bytes
    _assert_refused(_get_exact(case.client, child, route), case.selected_bytes)
    case.resume_actual_parent_release()
    after = _get_exact(case.client, child, route)
    assert after.status_code == 200 and after.content == case.selected_bytes
    prior_after = _get_exact(case.client, previous, route)
    assert prior_after.status_code == 200 and prior_after.content == case.selected_bytes


@pytest.mark.parametrize("route", ["content", "download"])
def test_cancel_before_release_refuses_staged_bytes(
    admitted_child_case: Any, route: str
) -> None:
    """A cancelled root cannot mint release for a still-staged child occurrence."""
    case = admitted_child_case
    selected, _sibling = case.start_actual_parent_and_pause_before_release()
    assert len(case.selected_bytes) >= 32
    assert case.staging_store.get_bytes(selected) == case.selected_bytes
    case.cancel_root_through_actual_control_owner()
    result = case.resume_actual_parent_release()
    _assert_actual_release_refusal(result, case)
    _assert_refused(_get_exact(case.client, selected, route), case.selected_bytes)


def test_nested_ref_closure_withholds_unselected_sibling(admitted_child_case: Any) -> None:
    """A real supported typed payload cannot smuggle an unselected nested ref."""
    case = admitted_child_case
    from polisyos.scientist.methods.search.promotion_evidence import PromotionEvidenceBundle

    bundle_ref, selected, sibling = case.start_actual_reference_bundle_parent_and_pause_before_release()
    payload = case.staging_store.get_bytes(bundle_ref)
    bundle = PromotionEvidenceBundle.model_validate_json(payload)
    assert bundle.candidate_ref == selected
    assert bundle.evaluation_ref == sibling
    result = case.resume_actual_parent_release()
    _assert_actual_release_refusal(result, case)
    _assert_refused(_get_exact(case.client, bundle_ref, "download"), payload)
    _assert_refused(_get_exact(case.client, sibling, "download"), case.sibling_bytes)


def test_forged_missing_manifest_edge_does_not_hide_typed_nested_ref(
    admitted_child_case: Any,
) -> None:
    """A manifest-only walk misses a sibling retained in typed payload bytes."""
    from polisyos.scientist.methods.search.promotion_evidence import PromotionEvidenceBundle

    forged, selected, sibling = case.start_parent_with_forged_missing_sibling_edge()
    payload = case.staging_store.get_bytes(forged)
    bundle = PromotionEvidenceBundle.model_validate_json(payload)
    assert bundle.candidate_ref == selected
    assert bundle.evaluation_ref == sibling
    manifest = case.staging_store.get_manifest(forged)
    assert not any(
        row.artifact_id == sibling.artifact_id
        and row.manifest_profile_sha256 == sibling.manifest_profile_sha256
        for row in manifest.inputs
    )
    result = case.resume_actual_parent_release()
    _assert_actual_release_refusal(result, case)
    _assert_refused(_get_exact(case.client, forged, "download"), payload)
    _assert_refused(_get_exact(case.client, sibling, "download"), case.sibling_bytes)


def test_parent_cache_cannot_skip_current_child_admission(admitted_child_case: Any) -> None:
    """An actual eligible warm parent entry must not bypass revoked admission."""
    case = admitted_child_case
    # The fixture creates/reconciles an actually selectable parent cache entry
    # through the existing cache owner, not a hand-constructed success marker.
    cache_key, before_calls = case.seed_and_verify_selectable_parent_cache()
    assert case.parent_cache_owner.get(cache_key) is not None
    before_events = case.read_actual_parent_run_events()
    before_release = case.read_actual_release_identities()
    before_projection = case.read_actual_parent_projection()
    case.revoke_child_grant_through_actual_admission_owner()
    result = case.run_same_parent_input_and_node_bytes_again()
    assert result.status != "ok"
    assert case.read_real_child_call_count() == before_calls
    after_events = case.read_actual_parent_run_events()
    parent_phase = f"scientist.node.{case.parent_alias}"
    assert sum(
        event.get("event") == "NODE_CACHE_HIT" and event.get("phase") == parent_phase
        for event in after_events
    ) == sum(
        event.get("event") == "NODE_CACHE_HIT" and event.get("phase") == parent_phase
        for event in before_events
    )
    assert case.read_actual_release_identities() == before_release
    assert case.read_actual_parent_projection() == before_projection
