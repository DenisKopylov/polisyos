"""Opt-in single-node pytest wrapper for the V3 handled-exception witness."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path

import pytest

import v3_exception_witness as witness_module
from v3_exception_witness import ExceptionWitness, WitnessError

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
CASES = ROOT / "policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1"
SOURCE = ROOT / "policy-engine/src/polisyos/runtime/quality/generation_cycle.py"
TEST_SOURCE = ROOT / "policy-engine/tests/integration/core_runtime/test_acquisition_receiver_constructor_served.py"
FIXTURE_SOURCES = (
    "policy-engine/tests/_helpers/acquisition_served_history.py",
    "policy-engine/tests/_helpers/acquisition_chain.py",
    "policy-engine/tests/_helpers/candidate_cycle_source_profile.py",
    "policy-engine/tests/_helpers/acquisition_production.py",
    "policy-engine/tests/integration/core_runtime/test_acquisition_retained_sequential_served.py",
)
NODE = "tests/integration/core_runtime/test_acquisition_receiver_constructor_served.py::test_real_b_receiver_dispatch_and_settings_are_consumed"


@pytest.hookimpl(hookwrapper=True, tryfirst=True)
def pytest_runtest_call(item):
    if item.nodeid != NODE:
        yield
        return
    from polisyos.runtime.quality import generation_cycle

    expected_sha = os.environ.get("V3_EXCEPTION_SOURCE_SHA256")
    if (
        not expected_sha
        or Path(generation_cycle.__file__).resolve(strict=True) != SOURCE.resolve(strict=True)
        or hashlib.sha256(SOURCE.read_bytes()).hexdigest() != expected_sha
    ):
        raise WitnessError("v3_witness_target_source_mismatch")
    test_sha = os.environ.get("V3_EXCEPTION_TEST_SHA256")
    if (
        not test_sha
        or Path(str(item.path)).resolve(strict=True) != TEST_SOURCE.resolve(strict=True)
        or hashlib.sha256(TEST_SOURCE.read_bytes()).hexdigest() != test_sha
    ):
        raise WitnessError("v3_witness_test_source_mismatch")
    try:
        fixture_hashes = json.loads(os.environ["V3_EXCEPTION_FIXTURE_HASHES"])
    except (KeyError, TypeError, ValueError) as exc:
        raise WitnessError("v3_witness_fixture_hashes_invalid") from exc
    if not isinstance(fixture_hashes, dict) or set(fixture_hashes) != set(FIXTURE_SOURCES):
        raise WitnessError("v3_witness_fixture_denominator_mismatch")
    for rel in FIXTURE_SOURCES:
        path = ROOT / rel
        if path.is_symlink() or hashlib.sha256(path.read_bytes()).hexdigest() != fixture_hashes[rel]:
            raise WitnessError("v3_witness_fixture_source_mismatch")
    witness_path = Path(witness_module.__file__).resolve(strict=True)
    plugin_path = Path(__file__).resolve(strict=True)
    for label, path in (("V3_EXCEPTION_PLUGIN_SHA256", plugin_path), ("V3_EXCEPTION_WITNESS_SHA256", witness_path)):
        expected = os.environ.get(label)
        if not expected or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise WitnessError("v3_witness_instrument_source_mismatch")
    case = Path(os.environ["V3_EXCEPTION_CASE_DIR"])
    if (
        not case.is_absolute()
        or case.parent != CASES
        or case.is_symlink()
        or any(parent.is_symlink() for parent in case.parents)
        or not case.is_dir()
        or case.resolve(strict=True) != case
    ):
        raise WitnessError("v3_witness_case_path_invalid")
    output = case / "v3-n5-handled-exceptions.json.gz"
    if os.path.lexists(output):
        raise WitnessError("v3_witness_output_already_exists")
    target = generation_cycle.GenerationCycleController._run_proposal_candidate_scenario_n5
    witness = ExceptionWitness(target.__code__, output)
    witness.source_bindings = {
        "product_source_sha256": expected_sha,
        "test_source_sha256": test_sha,
        "fixture_source_sha256": fixture_hashes,
        "plugin_sha256": os.environ["V3_EXCEPTION_PLUGIN_SHA256"],
        "witness_sha256": os.environ["V3_EXCEPTION_WITNESS_SHA256"],
        "selected_node": NODE,
    }
    witness.start()
    try:
        yield
    finally:
        # The result is not changed. Missing/errored witness is a harness
        # limitation the coordinator must classify independently.
        try:
            witness.finish()
        except BaseException:
            pass
