"""Reconcile and seal the sparse packet without importing or mutating product."""
from pathlib import Path
import ast
import hashlib
import json
import stat
import subprocess

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
OUT = Path(__file__).resolve().parent
POST = OUT / 'postimages'
sha = lambda b: hashlib.sha256(b).hexdigest()
manifest = json.loads((OUT / 'manifest.json').read_text())
prior = OUT.parent / 'C78-chain-r5'
prior_manifest = json.loads((prior / 'manifest.json').read_text())
assert sha((prior / 'manifest.json').read_bytes()) == json.loads((OUT / 'r5-input.json').read_text())['manifest_sha256']
for row in prior_manifest['files']:
    assert sha((ROOT / row['postimage']).read_bytes()) == row['postimage_sha256'], row['path']
for key in ('main_review', 'companion'):
    value = json.loads((OUT / 'r5-input.json').read_text())[key]
    locator, expected = value.split('@')
    assert sha((OUT.parents[1] / locator).read_bytes()) == expected, locator

head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
branch = subprocess.check_output(['git', 'symbolic-ref', '-q', 'HEAD'], cwd=ROOT, text=True).strip()
assert branch == 'refs/heads/codex/e02-unified-local-20261009'
readback = []
for row in manifest['files']:
    path = POST / row['path']
    info = path.stat()
    assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and not path.is_symlink()
    assert sha(path.read_bytes()) == row['postimage_sha256']
    assert (ROOT / row['path']).is_file() == (row['preimage_git_blob'] is not None)
    if row['preimage_git_blob'] is not None:
        assert sha((ROOT / row['path']).read_bytes()) == row['preimage_sha256']
        assert subprocess.check_output(['git', 'rev-parse', head + ':' + row['path']], cwd=ROOT, text=True).strip() == row['preimage_git_blob']
    readback.append({'path': row['path'], 'current_preimage_match': True, 'postimage_sha256_reconciled': True})

controls = json.loads((OUT / 'property-removals.json').read_text())['controls']
definitions = []
for control in controls:
    assert sha((OUT / 'removals' / control['name']).read_bytes()) == control['patch_sha256']
    assert sha((POST / control['path']).read_bytes()) == control['preimage_sha256']
    for selector in control['selectors']:
        path, name = selector.split('::', 1)
        name = name.split('[', 1)[0]
        tree = ast.parse((POST / 'policy-engine' / path).read_bytes())
        assert any(isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == name for node in ast.walk(tree)), selector
        definitions.append(selector)
assert all(row['exit'] == 0 for row in json.loads((OUT / 'static-checks.json').read_text())['checks'])
assert json.loads((OUT / 'apply-check.json').read_text())['exit'] == 0
assert sha((OUT / 'proposal.patch').read_bytes()) == manifest['patch']['sha256']
assert sha((OUT / 'r5-to-r6.patch').read_bytes()) == manifest['r5_delta']['sha256']
assert sha((OUT / 'criteria.json').read_bytes()) == sha((prior / 'criteria.json').read_bytes())

register = json.loads((OUT / 'register-proposal.json').read_text())
register_bytes = (ROOT / register['path']).read_bytes()
assert sha(register_bytes) == register['preimage_sha256']
patch_lines = (OUT / 'register-companion.patch').read_text().splitlines(keepends=True)
append = ''.join(line[1:] for line in patch_lines if line.startswith('+') and not line.startswith('+++')).encode()
assert sha(register_bytes + append) == register['postimage_sha256']
assert sha((OUT / register['patch']).read_bytes()) == register['patch_sha256']
check = subprocess.run(['git', 'apply', '--check', '--whitespace=error', str(OUT / register['patch'])], cwd=ROOT, capture_output=True, text=True)
assert check.returncode == 0, check.stderr

record = dict(status='source-only reconciled; awaiting independent delta review and product verification', branch=branch, admission_head=head, freeze_root_head=manifest['current_root_head'], preimage_readback=readback, postimages=len(readback), mechanism_python_paths=manifest['footprint']['mechanism_python_paths'], mandatory_companions=manifest['footprint']['companions'], original_criteria_unchanged=True, control_count=len(controls), control_selector_definitions=len(definitions), control_selector_definition_check='AST presence only; pytest collection and positive/red/restore UNRUN', all_prior_r5_postimages_immutable=True, register_append_preserves_entire_current_prefix=True, register_apply_check=dict(exit=check.returncode, stdout=check.stdout, stderr=check.stderr), product_runtime='UNRUN', physical_topology='UNRUN', source_mutation=False, index_or_refs_mutation=False, child_delegation=False)
(OUT / 'readback.json').write_text(json.dumps(record, indent=2) + '\n')
manifest['packet_files'] = {str(path.relative_to(OUT)): sha(path.read_bytes()) for path in sorted(OUT.iterdir()) if path.is_file() and path.name not in {'manifest.json', 'proposal.patch', 'r5-to-r6.patch'}}
manifest['removal_patch_files'] = {str(path.relative_to(OUT)): sha(path.read_bytes()) for path in sorted((OUT / 'removals').glob('*.patch'))}
manifest['P40_bucket'] = 'Same known typed-source admission quantity; required actual model API and complete current model/raw/binary caller routing. No new issue-class or external decision.'
manifest['independent_review'] = 'PENDING; r5-to-r6 delta against immutable main/companion R5 HOLD'
manifest['source_review_is_not_runtime'] = True
manifest['shared_family_and_register_companions'] = 'Root-only actual merge/generation, pinned proposals included; not counted inside original-base25.'
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
reopened = json.loads((OUT / 'manifest.json').read_text())
for name, expected in reopened['packet_files'].items():
    assert sha((OUT / name).read_bytes()) == expected, name
for name, expected in reopened['removal_patch_files'].items():
    assert sha((OUT / name).read_bytes()) == expected, name
print(json.dumps({'manifest_sha256': sha((OUT / 'manifest.json').read_bytes()), 'patch_sha256': reopened['patch']['sha256'], 'patch_bytes': reopened['patch']['bytes'], 'delta_sha256': reopened['r5_delta']['sha256'], 'delta_bytes': reopened['r5_delta']['bytes'], 'delta_paths': len(reopened['r5_delta']['paths']), 'postimages': len(readback), 'controls': len(controls), 'admission_head': head, 'runtime': 'UNRUN'}))
