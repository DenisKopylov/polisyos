"""Exercise the real wrapper against synthetic driver/runner and fake Popen only."""
from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

import root_wave_wrapper as w


def stub_source(driver, runner, case_root, *, drift=False):
    driver.write_text(
        'from pathlib import Path\nimport subprocess,sys\n'
        f'p={str(w.PROJECT / ".venv/bin/python")!r}\n'
        f'r={str(runner)!r}\n'
        f'd=Path({str(case_root)!r})\n'
        f'v=subprocess.run([p,"-B",r,str(d/(sys.argv[1]+".json"))],cwd=Path({str(w.ROOT)!r}))\n'
        'raise SystemExit(v.returncode)\n'
    )
    expected = ("import importlib.util, pathlib, sys\nimport pytest\npath=pathlib.Path("
                + repr(str(w.OBSERVER))
                + ")\nspec=importlib.util.spec_from_file_location('loaded_source_observer',path)\n"
                  "plugin=importlib.util.module_from_spec(spec); spec.loader.exec_module(plugin)\n"
                  "if __name__ == '__main__':\n    raise SystemExit(pytest.main(sys.argv[1:],plugins=[plugin]))\n")
    if drift:
        expected += '# unexpected upstream change\n'
    runner.write_text(
        'from pathlib import Path\nimport json,os,subprocess,sys\n'
        'plan=json.loads(Path(sys.argv[1]).read_text()); case=Path(plan["case"]); case.mkdir()\n'
        f'(case/"pytest_launcher.py").write_text({expected!r})\n'
        'env=dict(os.environ); env.update(plan["extra"])\n'
        f'p=subprocess.Popen(["/usr/bin/sandbox-exec","-f",str(case/"child.sb"),{str(w.PROJECT / ".venv/bin/python")!r},"-B",str(case/"pytest_launcher.py"),{w.NODE!r}],cwd={str(w.PROJECT)!r},env=env)\n'
        'p.wait()\nraise SystemExit(0)\n'
    )


prior = (w.D, w.DRIVER, w.RUNNER, subprocess.Popen, dict(os.environ), sys.argv)
observed = []


class FakeProcess:
    def __init__(self, argv, **kwargs):
        self.pid = 70001 + len(observed)
        observed.append({'pid': self.pid, 'argv': list(argv), 'env': dict(kwargs['env'])})
    def wait(self):
        return 0
    def kill(self):
        pass


with tempfile.TemporaryDirectory(dir=w.PACKET) as temp:
    temp = Path(temp)
    w.D, w.DRIVER, w.RUNNER = temp, temp / 'driver.py', temp / 'runner.py'
    subprocess.Popen = FakeProcess
    stub_source(w.DRIVER, w.RUNNER, temp)
    os.environ['E02_BASIS_REMOVAL_STALE'] = 'must not propagate'
    initial = dict(os.environ)
    receipt_path = temp / 'parent.json'
    with w.ParentEnvironmentGuard(receipt_path) as guard:
        for role in ('baseline', 'removal', 'restored'):
            (temp / (role + '.json')).write_text(json.dumps({'case': str(temp / role), 'extra': w.case_environment(role, temp / role)}))
            assert w.run_retained_driver(role, role, guard) == 0
            assert dict(os.environ) == initial
    receipt = json.loads(receipt_path.read_text())
    assert receipt['restored'] and receipt['before_environment_sha256'] == receipt['after_environment_sha256']
    assert [row['pid'] for row in receipt['children']] == [70001, 70002, 70003]
    for role, actual, row in zip(('baseline', 'removal', 'restored'), observed, receipt['children'], strict=True):
        assert row['argv_sha256'] == w.qualify.digest(actual['argv'])
        assert row['environment_sha256'] == w.qualify.digest(actual['env'])
        assert 'E02_BASIS_REMOVAL_STALE' not in actual['env']
        target = w.PACKET / ('pytest_launcher.py' if role == 'removal' else 'restored_launcher.py')
        assert (temp / role / 'pytest_launcher.py').read_text() == w.trampoline(target)
    stub_source(w.DRIVER, w.RUNNER, temp, drift=True)
    (temp / 'drift.json').write_text(json.dumps({'case':str(temp / 'drift'),'extra':w.case_environment('baseline',temp / 'drift')}))
    error = None
    try:
        with w.ParentEnvironmentGuard(temp / 'drift-parent.json') as guard:
            w.run_retained_driver('baseline', 'drift', guard)
    except RuntimeError as exc:
        error = str(exc)
    assert error == 'retained launcher template changed'
    assert len(observed) == 3 and dict(os.environ) == initial
    assert json.loads((temp / 'drift-parent.json').read_text())['body_exception'] == 'RuntimeError'
    result = {'scope':'synthetic driver/runner and fake Popen only; no product import', 'actual_popen_observations':len(observed), 'roles':[r['role'] for r in receipt['children']], 'recorded_pids':[r['pid'] for r in receipt['children']], 'env_restored':receipt['restored'], 'template_drift_error':error}
w.D, w.DRIVER, w.RUNNER, subprocess.Popen = prior[:4]
os.environ.clear(); os.environ.update(prior[4]); sys.argv = prior[5]
print(json.dumps(result, indent=2))
