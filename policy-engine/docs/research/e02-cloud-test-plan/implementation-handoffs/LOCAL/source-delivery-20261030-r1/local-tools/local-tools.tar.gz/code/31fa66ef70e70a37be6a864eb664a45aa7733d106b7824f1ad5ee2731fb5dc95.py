"""Build/read back C05 r6 source artifacts without product/index/ref writes."""
from __future__ import annotations

import ast
import difflib
import hashlib
import json
import os
import re
import stat
import subprocess
from collections import Counter
from pathlib import Path

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
OUT = ROOT / 'LOCAL/raw/e02-execution-20261027/repairs/C05-composed-fixture-r6'
BASE = '67beb3461ab96c4cb64b92226228da39b30bcb06'
BASE_TREE = '306e3c150f6a1368f23c8ebece35aeec3feb180b'


def git(*args: str) -> bytes:
    return subprocess.check_output(['git', *args], cwd=ROOT)


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def obj(kind: str, raw: bytes) -> str:
    return hashlib.sha1(kind.encode() + b' ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def inventory(ref: str) -> dict[str, tuple[str, str]]:
    result = {}
    for row in git('ls-tree', '-r', '-z', ref).split(b'\0'):
        if row:
            info, path = row.split(b'\t', 1)
            mode, _kind, oid = info.split(b' ')
            result[os.fsdecode(path)] = mode.decode(), oid.decode()
    return result


def tree_hash(files: dict[str, tuple[str, str]]) -> str:
    root: dict = {}
    for path, entry in files.items():
        node = root
        parts = os.fsencode(path).split(b'/')
        for part in parts[:-1]:
            node = node.setdefault(part, {})
        node[parts[-1]] = entry

    def visit(node: dict) -> str:
        entries = []
        for name, value in node.items():
            if isinstance(value, dict):
                mode, oid = '40000', visit(value)
                order = name + b'/'
            else:
                mode, oid = value
                order = name
            entries.append((order, mode.encode() + b' ' + name + b'\0' + bytes.fromhex(oid)))
        return obj('tree', b''.join(value for _key, value in sorted(entries)))
    return visit(root)


def role(path: str) -> str:
    if '/tests/' in path:
        return 'mandatory semantic test companion'
    if path.endswith('/README.md'):
        return 'mandatory documentation companion'
    if '/release-fragments/' in path:
        return 'mandatory release companion'
    if path.endswith('/core/llm/__init__.py'):
        return 'mandatory facade companion'
    return 'mechanism'


def artifact(path: Path) -> dict:
    raw = path.read_bytes()
    return {'path': str(path.relative_to(ROOT)), 'sha256': sha(raw), 'bytes': len(raw)}


assert git('rev-parse', BASE + '^{tree}').decode().strip() == BASE_TREE
base_entries = inventory(BASE)
assert tree_hash(base_entries) == BASE_TREE
observed_head = git('rev-parse', 'HEAD').decode().strip()
head_entries = inventory(observed_head)
files = []
preimages = {}
postimages = {}
patch_parts = []
subset = {}
current = []
for path in sorted((OUT / 'policy-engine').rglob('*')):
    if not path.is_file():
        continue
    relative = str(path.relative_to(OUT))
    for ancestor in [path, *list(path.parents)[:len(path.relative_to(OUT).parts)]]:
        assert not ancestor.is_symlink(), ancestor
    info = path.stat()
    assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1, path
    raw = path.read_bytes()
    mode, oid = base_entries.get(relative, (None, None))
    old = git('show', BASE + ':' + relative) if oid is not None else b''
    assert old != raw, ('unchanged source postimage', relative)
    assert (not old or old.endswith(b'\n')) and raw.endswith(b'\n'), relative
    assert oid is None or obj('blob', old) == oid
    canonical = ROOT / relative
    working = canonical.read_bytes() if canonical.is_file() else None
    if canonical.exists():
        assert (canonical.stat().st_dev, canonical.stat().st_ino) != (info.st_dev, info.st_ino)
    previous = ROOT / 'LOCAL/raw/e02-execution-20261027/repairs/C05-composed-fixture-r5' / relative
    if previous.is_file():
        assert (previous.stat().st_dev, previous.stat().st_ino) != (info.st_dev, info.st_ino)
    post_oid = obj('blob', raw)
    preimages[relative] = old
    postimages[relative] = raw
    subset[relative] = ('100644', post_oid)
    current.append({
        'path': relative, 'base_blob': oid, 'head_blob': head_entries.get(relative, (None, None))[1],
        'working_sha256': sha(working) if working is not None else None,
        'matches_base_preimage': working == old if oid is not None else working is None,
        'working_source_kind': 'regular' if canonical.is_file() and not canonical.is_symlink() else 'absent_or_other',
    })
    files.append({
        'path': relative, 'role': role(relative),
        'preimage_mode': mode, 'preimage_blob': oid,
        'preimage_sha256': sha(old) if oid is not None else None,
        'preimage_bytes': len(old) if oid is not None else 0,
        'postimage_mode': '100644', 'postimage_blob': post_oid,
        'postimage_sha256': sha(raw), 'postimage_bytes': len(raw),
        'current_working_preimage_match': current[-1]['matches_base_preimage'],
        'independent_regular_file': True,
    })
    header = f'diff --git a/{relative} b/{relative}\n'
    if oid is None:
        header += 'new file mode 100644\n'
    header += f'index {oid or "0" * 40}..{post_oid}' + (' 100644\n' if oid else '\n')
    diff = ''.join(difflib.unified_diff(
        old.decode().splitlines(keepends=True), raw.decode().splitlines(keepends=True),
        fromfile='a/' + relative if oid else '/dev/null', tofile='b/' + relative, n=3,
    ))
    patch_parts.append(header + diff)
patch = ''.join(patch_parts).encode()
(OUT / 'repair.patch').write_bytes(patch)

# Independently replay the exact serialized unified hunks in memory.
reconstructed = {}
sections = re.split(r'(?m)^diff --git ', patch.decode())[1:]
for section in sections:
    rows = section.splitlines(keepends=True)
    match = re.fullmatch(r'a/(.+) b/(.+)\n', rows[0])
    assert match and match[1] == match[2]
    path = match[1]
    original = preimages[path].decode().splitlines(keepends=True)
    cursor = 0
    output = []
    index = 1
    while index < len(rows):
        if not rows[index].startswith('@@ '):
            index += 1
            continue
        header = re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', rows[index])
        assert header
        old_start, old_count = int(header[1]), int(header[2] or 1)
        new_count = int(header[4] or 1)
        start = old_start - 1 if old_count else old_start
        assert start >= cursor
        output.extend(original[cursor:start]); cursor = start
        removed = added = 0
        index += 1
        while index < len(rows) and not rows[index].startswith('@@ '):
            line = rows[index]
            assert line[:1] in {' ', '-', '+'}, (path, line)
            if line[0] in ' -':
                assert cursor < len(original) and original[cursor] == line[1:], (path, cursor)
                cursor += 1; removed += 1
            if line[0] in ' +':
                output.append(line[1:]); added += 1
            index += 1
        assert (removed, added) == (old_count, new_count), (path, removed, added, old_count, new_count)
    output.extend(original[cursor:])
    result = ''.join(output).encode()
    assert result == postimages[path], path
    reconstructed[path] = sha(result)
assert set(reconstructed) == set(postimages)

candidate = dict(base_entries); candidate.update(subset)
virtual_tree = tree_hash(candidate)
check = subprocess.run(['git', 'apply', '--check', str(OUT / 'repair.patch')], cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
reconstruction = {
    'base_commit': BASE, 'base_tree': BASE_TREE,
    'base_tree_recomputed_from_complete_git_inventory': True,
    'postimage_path_count': len(files), 'serialized_patch_sections': len(sections),
    'all_exact_hunks_replayed_against_pinned_base': True,
    'all_reconstructed_bytes_match_postimages': True,
    'virtual_candidate_tree': virtual_tree,
    'source_subset_tree': tree_hash(subset),
    'no_git_objects_index_or_refs_written': True,
}
(OUT / 'base-patch-reconstruction.json').write_text(json.dumps(reconstruction, indent=2) + '\n')
(OUT / 'current-preimages-and-apply-check.json').write_text(json.dumps({
    'observed_head': observed_head, 'observed_head_tree': git('rev-parse', observed_head + '^{tree}').decode().strip(),
    'branch': git('symbolic-ref', '-q', 'HEAD').decode().strip(),
    'files': current,
    'git_apply_check': {'argv': ['git', 'apply', '--check', str(OUT / 'repair.patch')], 'returncode': check.returncode, 'stdout': check.stdout.decode(), 'stderr': check.stderr.decode()},
    'qualification': 'Read-only current snapshot; normal Root advances are expected. Root must recheck and merge shared functions contextually before applying. No stale postimage overwrite is authorized.',
}, indent=2) + '\n')

inputs = []
for relative, expected in [
    ('LOCAL/raw/e02-execution-20261027/reviews/C05-r5-code.md', 'b41529fdc66160689689c93ba54853ed23901477d2ded3391c99036a8a062463'),
    ('LOCAL/raw/e02-execution-20261027/reviews/C05-r5-code.json', '54043801d1c4a4aa1866de4455cece57c067deca4dbb99d2d3e4c3630e08eb79'),
    ('LOCAL/raw/e02-execution-20261027/repairs/C05-composed-fixture-r5/manifest.json', 'e65c8794cad250d272e3225cf18362b45461cfaa1cb1be223c0745f1cd921c36'),
    ('LOCAL/raw/e02-execution-20261027/repairs/C05-composed-fixture-r5/repair.patch', '0df0e9479d4962f1c11159b9424be0c2c060fae2522a9f911e47367c20e5d2cb'),
    ('LOCAL/raw/e02-execution-20261027/repairs/C05-composed-fixture-r4/manifest.json', 'bd730b110bbaed705e1d9a3e9b1acc952fc19264d0b61f05fe5514e95372595e'),
]:
    item = artifact(ROOT / relative)
    assert item['sha256'] == expected, relative
    inputs.append(item)

counts = Counter(item['role'] for item in files)
assert len(files) == 34 and counts['mechanism'] == 17
summary = json.loads((OUT / 'static-summary.json').read_text())
assert summary['ast_pass'] == 30 and summary['toml_pass'] == 1 and summary['ruff_invocations'] == 60 and summary['ruff_failures'] == 0
ruff = json.loads((OUT / 'static-ruff-full.json').read_text())
for item in ruff:
    assert item['returncode'] == 0 and item['source_sha256'] == sha(postimages[item['path']])
manifest = {
    'schema': 'policyos.e02.sparse_repair_manifest.v2',
    'task': 'C05 composed fixture r6 whole request-identity/lifetime repair',
    'status': 'frozen_source_proposal_pending_independent_review',
    'capability_state': 'verification_missing',
    'base_commit': BASE, 'base_tree': BASE_TREE,
    'virtual_candidate_tree': virtual_tree, 'source_subset_tree': tree_hash(subset),
    'virtual_tree_note': 'Complete pinned base plus exact sparse overlays hashed in memory. No Git tree/object/ref was written; this is not a composed product or runtime receipt.',
    'files': files, 'patch': artifact(OUT / 'repair.patch'), 'readme': artifact(OUT / 'README.md'),
    'inputs': inputs,
    'evidence': [artifact(OUT / name) for name in ['static-ruff-full.json', 'static-summary.json', 'base-patch-reconstruction.json', 'current-preimages-and-apply-check.json', 'prepare_manifest.py']],
    'footprint': {'complete_paths': len(files), 'mechanism_paths': counts['mechanism'], 'mandatory_companion_paths': len(files) - counts['mechanism'], 'roles': dict(counts), 'python_paths': 30, 'toml_paths': 1, 'readme_paths': 3},
    'static_results': {'ast': '30/30 PASS', 'ruff_check_canonical_filename': '30/30 PASS', 'ruff_format_check_canonical_filename': '30/30 PASS', 'release_toml_parse': '1/1 PASS', 'complete_pinned_base_hunk_reconstruction': f'{len(files)}/{len(files)} PASS', 'current_worktree_apply_check_returncode': check.returncode},
    'p40_disposition': {
        'request_identity': 'SAME class widened to one immutable full caller/body/transport snapshot and actual successful endpoint/payload; negotiated or alternate successes are physical-only.',
        'producer_lifetime_owner': 'SAME class widened to nonblocking admission tickets, DB-only live selection, independent binding-registry lifetime, actual returned/read-back pending begin owner and parent-owned trace attachment.',
        'unknown_scope': 'Explicit costed refusal for queued physical LLM work; breaking compatibility behavior recorded. Candidate scope is never invented.',
        'composition': 'Preserve C37 selected queue reader and C57 cancelled record verification. Other shared owners compose contextually.',
    },
    'predicate_basis': {
        'caller_wire_snapshot_and_successful_dispatch': 'recomputed by the actual prepared gateway/fallback/simulator executor; complete body/configuration commitments precede hash and send',
        'current_job_actor_scope_attempt_lease_profile': 'independently_reconciled through canonical persisted live job and creation/outbox envelope',
        'actual_pending_begin_owner': 'independently_reconciled from returned exact BudgetLedgerProducerRecord and reopened canonical ledger record before dispatch',
        'response_projection_and_origin': 'recomputed by Core whole allowed projection and exact cache-owner session/retained-origin proof',
        'central_begin_set': 'produced at actual mandatory scoped factory/Core begin hook; closed admission interval independently reopened from terminal Core trace and compared as a complete set to current-attempt ledger',
        'institutional_permission_provider_invoice_and_interruptible_io': 'not_established; excluded from the authority claim and declared as bounded limitations',
    },
    'declared_limits': [
        'Already-running blocking dependency I/O cannot be killed by the existing generic guard and may retain its bounded worker or own I/O mutex until return. Factory/binding/trace admission close does not wait on that callback mutex; late admissions cannot dispatch; incomplete basis cannot reconcile.',
        'The basis covers actual scoped central producer begins including reuse/pending/unknown, not catalog calls or internal transport retry invoice charges.',
        'No arbitrary prepared plugin or institutional permission truth is certified. Opaque adapters are physical-only; snapshot authorizer remains a restrictive integration input.',
        'All behavioral controls/removals/native tests and broad architecture/type/API/generated-surface checks remain UNRUN.',
    ],
    'root_composition_boundaries': [
        'ControlPlaneStore: only new verify_llm_producer_admission, no callback-spanning SQL scope.',
        'run_lifecycle: get_job_status and adjacent current producer cost helper only; retain C37 _load_control_nl_job_payload and C57 cancelled record verification; C48 method-metric region untouched.',
        'BudgetMiddleware: only separate binding-registry lock and register/release/lookup; preserve C49 snapshot_safe and budget observer/reconciler hunks.',
        'C37 job_attempt_publication request projection, C71 observational source access, C07 outbox, C49 convergence/design_generation and other Root advances are not owned or overwritten.',
        'Root owns mandatory generated schema/lock/public-surface inventory and actual runtime API/compatibility checks after composition; public_surface_inventory_reviewed remains explicitly false until that review.',
    ],
    'runtime_unrun': ['all supplied canonical component/integration modules', 'ordinary POST/cache warm hit/durable ledger/fresh GET', 'real HTTP mutation/health/format controls', 'in-progress authorizer and ledger-begin timeout/normal/error/cancel close', 'lost actual attempt ownership and legitimate in-flight settlement controls', 'all isolated property removals/restoration', 'mypy/architecture/generated/public API/hook/G checks'],
    'canonical_mutation': False, 'index_or_ref_mutation': False, 'product_imports_run': False,
    'pytest_run': False, 'children_spawned': 0, 'closure_ids': [],
}
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
# Delivery readback: every frozen byte identity is checked from its saved path.
readback = json.loads((OUT / 'manifest.json').read_text())
for item in readback['files']:
    path = OUT / item['path']
    assert sha(path.read_bytes()) == item['postimage_sha256'] and path.stat().st_nlink == 1
for item in [readback['patch'], readback['readme'], *readback['evidence'], *readback['inputs']]:
    assert sha((ROOT / item['path']).read_bytes()) == item['sha256']
print(json.dumps({'manifest_sha256': sha((OUT / 'manifest.json').read_bytes()), 'manifest_bytes': (OUT / 'manifest.json').stat().st_size, 'patch_sha256': sha(patch), 'patch_bytes': len(patch), 'virtual_candidate_tree': virtual_tree, 'source_subset_tree': tree_hash(subset), 'paths': len(files), 'role_counts': dict(counts), 'current_apply_check': check.returncode, 'current_mismatching_preimages': [item['path'] for item in current if not item['matches_base_preimage']], 'observed_head': observed_head}, indent=2))
