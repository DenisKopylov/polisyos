"""Record actual child dyld mappings around the unchanged selected C43 test."""
from __future__ import annotations
import hashlib
import importlib
import json
import os
import subprocess
from pathlib import Path
import pytest

_STATE={}


def _need(name):
    value=os.environ.get(name)
    if not value:raise pytest.UsageError('C43 dyld observer requires '+name)
    return value


def _sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pytest_configure(config):
    root=Path(config.rootpath).resolve(strict=True)
    if root!=Path.cwd().resolve(strict=True):raise pytest.UsageError('C43 dyld observer wrong cwd')
    plugin=Path(__file__).resolve(strict=True)
    helper=plugin.parent/'c43_dyld_snapshot.py'
    if _sha(plugin)!=_need('C43_DYLD_OBSERVER_SHA256') or _sha(helper)!=_need('C43_DYLD_SNAPSHOT_SHA256'):
        raise pytest.UsageError('C43 dyld observer/helper bytes mismatch')
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
    tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip()
    if head!=_need('C43_CONTROL_SOURCE_HEAD') or tree!=_need('C43_CONTROL_SOURCE_TREE'):
        raise pytest.UsageError('C43 dyld observer head/tree mismatch')
    output=Path(_need('C43_CONTROL_OUTPUT')).resolve(strict=True)
    if output!=Path(_need('POLISYOS_R4_INPUT_READSET_DIR')).parent.resolve(strict=True):
        raise pytest.UsageError('C43 dyld observer output mismatch')
    target=output/'c43-dyld-observation.json'
    if target.exists() or target.is_symlink():raise pytest.UsageError('C43 dyld observation already exists')
    _STATE.update(root=root,head=head,tree=tree,target=target,observer_sha=_sha(plugin),helper_sha=_sha(helper))


def _capture():
    try:
        module=importlib.import_module('c43_dyld_snapshot')
        expected=Path(__file__).resolve(strict=True).parent/'c43_dyld_snapshot.py'
        actual=Path(module.__file__).resolve(strict=True)
        if actual!=expected or _sha(actual)!=_STATE['helper_sha']:
            return {'status':'error','reason':'loaded snapshot helper differs from admitted bytes'}
        return module.snapshot()
    except Exception as exc:
        return {'status':'error','reason':f'{type(exc).__name__}: {exc}'}


@pytest.hookimpl(hookwrapper=True,tryfirst=True)
def pytest_runtest_call(item):
    if item.nodeid!=_need('C43_DYLD_EXACT_NODE'):
        raise pytest.UsageError('C43 dyld observer selected node mismatch')
    before=_capture()
    outcome=yield
    after=_capture()
    record={'nodeid':item.nodeid,'source_head':_STATE['head'],'source_tree':_STATE['tree'],
            'observer_sha256':_STATE['observer_sha'],'snapshot_module_sha256':_STATE['helper_sha'],
            'test_raised':outcome.excinfo is not None,'before_call':before,'after_call':after,
            'scope':'Actual child mappings at test-call boundaries; not a complete history, binary-cache digest or G acceptance.'}
    _STATE['target'].write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
