"""Process-local E02 negative probes. Never install outside an admitted case."""
from __future__ import annotations

import ast
import hashlib
import importlib
import inspect
import json
import marshal
import os
from pathlib import Path

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
P = ROOT / 'policy-engine'
PINS = {
    'tests/unit/runtime/quality/test_grounding_bind.py': 'b9dc04c54c264337f1a844e4363f153c893f5497c81aa71a37b9fccc72556cc8',
    'tests/unit/runtime/quality/test_generation_source.py': '31e5987da415b1db02f26eba6a30e54d924f514a1a79081dbc000f130d2a7ae1',
    'tests/unit/runtime/quality/test_c49_native_stopping_budget.py': 'b6580c71d905bd759750aaa5984974a5f77ddf8cb61eb7b65397693ede353302',
    'src/polisyos/runtime/quality/credal_reference.py': 'a145dc6773d77659ff94ca5fd7e9d9da4560ea0ac8820a671a53be949d8f639d',
    'src/polisyos/runtime/quality/generation_cycle.py': '750fdbb69b04771f836bcb7212378537234117f1ead8fcbd21d73485a458ee0a',
    'src/polisyos/runtime/quality/joint_simulation_horizon.py': '333deedcd2d85bf4a75f58d698a0d487a8a163256609d0825f2063fb087a2454',
    'src/polisyos/scientist/orchestration/engine/producer_budget.py': '4df7b278314117b05e49ee17157cb3c1dd41fbcff614540ac9479a84813ea420',
}
TESTS = {
    'law_positive_gen': 'tests/unit/runtime/quality/test_generation_source.py::test_synthetic_cg2_contract_mechanism_remains_non_promotable',
    'law_positive_bind': 'tests/unit/runtime/quality/test_grounding_bind.py::test_contract_testing_bind_resolves_non_promotable',
    'law_negative': 'tests/unit/runtime/quality/test_grounding_bind.py::test_declared_legal_association_still_refuses_contract_seed_bind',
    'owner': 'tests/unit/runtime/quality/test_c49_native_stopping_budget.py::test_fresh_owner_exhaustion_between_real_seeds_stops_before_second_call',
}
MODES = {
    'law_positive_reversal': {TESTS['law_positive_gen'], TESTS['law_positive_bind'], TESTS['law_negative']},
    'legal_firewall_removed': {TESTS['law_negative']},
    'hidden_legal_edge': {TESTS['law_positive_gen'], TESTS['law_positive_bind']},
    'per_seed_stale': {TESTS['owner']},
    'trajectory_guard_removed': {TESTS['owner']},
    'work_count_guard_removed': {TESTS['owner']},
    'reentry_stale': {TESTS['owner']},
}


def _trace(event, **data):
    path = Path(os.environ['E02_CONTROL_TRACE'])
    # The coordinator binds this to a fresh, case-owned file; refuse arbitrary destinations.
    base = Path(os.environ['TMPDIR']).parent.resolve()
    if path.parent.resolve() != base or path.name != 'property-control-trace.jsonl':
        raise RuntimeError('control trace must be the case-owned property-control-trace.jsonl')
    with path.open('a', encoding='utf-8') as stream:
        stream.write(json.dumps({'event': event, **data}, sort_keys=True) + '\n')
        stream.flush()


def _file_pin(rel):
    path = P / rel
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if digest != PINS[rel]:
        raise RuntimeError(f'source mismatch {rel}: {digest} expected {PINS[rel]}')
    return path


def _function_node(rel, name, cls=None):
    path = _file_pin(rel)
    tree = ast.parse(path.read_text(encoding='utf-8'), filename=str(path))
    parents = [n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == cls] if cls else [tree]
    if len(parents) != 1:
        raise RuntimeError(f'expected one owner {cls} in {rel}')
    nodes = [n for n in parents[0].body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name]
    if len(nodes) != 1:
        raise RuntimeError(f'expected one function {name} in {rel}')
    node = nodes[0]
    node.decorator_list = []
    return node


def _compile(node, original, rel):
    path = _file_pin(rel)
    if Path(inspect.getsourcefile(original)).resolve() != path.resolve():
        raise RuntimeError(f'loaded callable does not originate from pinned file {rel}')
    module = ast.fix_missing_locations(ast.Module(body=[node], type_ignores=[]))
    namespace = {}
    code = compile(module, str(path), 'exec', flags=__import__('__future__').annotations.compiler_flag, dont_inherit=True)
    exec(code, original.__globals__, namespace)
    changed = namespace[node.name]
    _trace('mutation', symbol=f'{original.__module__}.{original.__qualname__}', source_path=rel,
           source_sha256=PINS[rel], original_code_sha256=hashlib.sha256(marshal.dumps(original.__code__)).hexdigest(),
           mutant_code_sha256=hashlib.sha256(marshal.dumps(changed.__code__)).hexdigest())
    return changed


def _remove_guard(node, code):
    class Remove(ast.NodeTransformer):
        count = 0
        def visit_If(self, n):
            if any(isinstance(x, ast.Constant) and x.value == code for x in ast.walk(n)):
                self.count += 1
                n.test = ast.copy_location(ast.BoolOp(op=ast.And(), values=[ast.Name(id='_e02_disabled_guard', ctx=ast.Load()), n.test]), n.test)
                return n
            return self.generic_visit(n)
    visitor = Remove(); visitor.visit(node)
    if visitor.count != 1:
        raise RuntimeError(f'expected exactly one guard {code}, got {visitor.count}')


def _replace_positive_reference(node):
    count = 0
    for n in ast.walk(node):
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == '_reference':
            for k in n.keywords:
                if k.arg == 'include_legal_associations' and isinstance(k.value, ast.Constant) and k.value.value is False:
                    k.value = ast.copy_location(ast.Constant(value=True), k.value); count += 1
    if count != 1:
        raise RuntimeError(f'expected one explicit False reference, got {count}')


def _inject_legal_reference(node):
    count = 0
    for n in ast.walk(node):
        if isinstance(n, ast.IfExp) and isinstance(n.test, ast.Name) and n.test.id == 'include_legal_associations':
            n.test = ast.copy_location(ast.Constant(value=True), n.test); count += 1
    if count != 3:
        raise RuntimeError(f'expected exactly three L6 construction expressions, got {count}')


def _remove_legal_lift(node):
    count = 0
    for n in ast.walk(node):
        if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'is_unverified_legal_mapping':
            n.value = ast.copy_location(ast.Constant(value=False), n.value); count += 1
    if count != 1:
        raise RuntimeError(f'expected exactly one legal mapping predicate, got {count}')


def _stale_seed(node):
    count = 0
    for n in ast.walk(node):
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == 'admit' and isinstance(n.func.value, ast.Name) and n.func.value.id == 'producer_budget_observer':
            if n.args or n.keywords:
                raise RuntimeError('unexpected admission arguments')
            n.func = ast.copy_location(ast.Name(id='_e02_stale_seed_admit', ctx=ast.Load()), n.func)
            n.args = [ast.Name(id='producer_budget_observer', ctx=ast.Load())]; count += 1
    if count != 1:
        raise RuntimeError(f'expected exactly one per-seed admit, got {count}')


def pytest_collection_modifyitems(session, config, items):
    mode = os.environ['E02_CONTROL_MODE']
    digest = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    if digest != os.environ['E02_CONTROL_PLUGIN_SHA256']:
        raise RuntimeError(f'control plugin mismatch: {digest}')
    for rel in PINS:
        _file_pin(rel)
    if mode not in MODES:
        raise RuntimeError(f'unsupported control {mode}')
    selected = {item.nodeid for item in items}
    if selected != MODES[mode]:
        raise RuntimeError(f'wrong selected set for {mode}: {sorted(selected)}')
    _trace('collection', mode=mode, nodes=sorted(selected))


def pytest_runtest_setup(item):
    mode = os.environ['E02_CONTROL_MODE']
    if mode == 'law_positive_reversal':
        if item.nodeid == TESTS['law_negative']:
            return
        rel = item.nodeid.split('::')[0]
        original = item.obj
        node = _function_node(rel, original.__name__)
        before = [ast.dump(x, include_attributes=False) for x in ast.walk(node) if isinstance(x, ast.Assert)]
        _replace_positive_reference(node)
        after = [ast.dump(x, include_attributes=False) for x in ast.walk(node) if isinstance(x, ast.Assert)]
        if before != after:
            raise RuntimeError('test assertions changed')
        item.obj = _compile(node, original, rel)
        return
    if mode == 'hidden_legal_edge':
        mod = importlib.import_module('tests.unit.runtime.quality.test_grounding_bind')
        if getattr(mod, '_e02_control_installed', None) == mode:
            return
        rel = 'tests/unit/runtime/quality/test_grounding_bind.py'; original = mod._reference
        node = _function_node(rel, '_reference'); _inject_legal_reference(node)
        mod._reference = _compile(node, original, rel); mod._e02_control_installed = mode
        return
    if mode == 'legal_firewall_removed':
        mod = importlib.import_module('polisyos.runtime.quality.credal_reference')
        rel = 'src/polisyos/runtime/quality/credal_reference.py'; original = mod.CredalReference.reference_lift
        node = _function_node(rel, 'reference_lift', 'CredalReference'); _remove_legal_lift(node)
        mod.CredalReference.reference_lift = _compile(node, original, rel)
        return
    if mode == 'per_seed_stale':
        mod = importlib.import_module('polisyos.runtime.quality.joint_simulation_horizon')
        rel = 'src/polisyos/runtime/quality/joint_simulation_horizon.py'; original = mod._run_cached_replicates
        node = _function_node(rel, '_run_cached_replicates'); _stale_seed(node)
        cached = {}
        def stale_admit(observer):
            key = id(observer)
            if key not in cached:
                cached[key] = observer.admit()
                _trace('current_admission', observer=key, source_basis_digest=cached[key].source_basis_digest)
            else:
                _trace('stale_seed_admission', observer=key, source_basis_digest=cached[key].source_basis_digest)
            return cached[key]
        mod._e02_stale_seed_admit = stale_admit
        mod._run_cached_replicates = _compile(node, original, rel)
        return
    if mode == 'trajectory_guard_removed':
        mod = importlib.import_module('polisyos.runtime.quality.generation_cycle')
        rel = 'src/polisyos/runtime/quality/generation_cycle.py'; original = mod._validate_loaded_joint_simulation_result
        node = _function_node(rel, '_validate_loaded_joint_simulation_result')
        _remove_guard(node, 'joint_simulation_result_trajectory_missing')
        mod._e02_disabled_guard = False
        mod._validate_loaded_joint_simulation_result = _compile(node, original, rel)
        return
    if mode == 'work_count_guard_removed':
        mod = importlib.import_module('polisyos.runtime.quality.joint_simulation_horizon')
        rel = 'src/polisyos/runtime/quality/joint_simulation_horizon.py'; original = mod.JointSimulationResult.physical_work_observations.fget
        node = _function_node(rel, 'physical_work_observations', 'JointSimulationResult')
        _remove_guard(node, 'n5_physical_work_unit_count_mismatch')
        mod._e02_disabled_guard = False
        mod.JointSimulationResult.physical_work_observations = property(_compile(node, original, rel))
        return
    if mode == 'reentry_stale':
        mod = importlib.import_module('polisyos.scientist.orchestration.engine.producer_budget')
        rel = 'src/polisyos/scientist/orchestration/engine/producer_budget.py'; _file_pin(rel)
        original = mod.ProducerBudgetObserver.admit
        if Path(inspect.getsourcefile(original)).resolve() != (P / rel).resolve():
            raise RuntimeError('unexpected observer origin')
        first = {'observer': None, 'observation': None}
        def stale_reentry(self):
            if first['observer'] is None:
                first['observer'] = self
            if self is first['observer']:
                observation = original(self)
                if first['observation'] is None:
                    first['observation'] = observation
                    _trace('current_admission', source_basis_digest=observation.source_basis_digest)
                return observation
            if first['observation'] is None:
                raise RuntimeError('first owner never admitted before reentry')
            _trace('stale_reentry_admission', source_basis_digest=first['observation'].source_basis_digest)
            return first['observation']
        _trace('mutation', symbol=f'{original.__module__}.{original.__qualname__}', source_path=rel,
               source_sha256=PINS[rel], original_code_sha256=hashlib.sha256(marshal.dumps(original.__code__)).hexdigest(),
               mutant_code_sha256=hashlib.sha256(marshal.dumps(stale_reentry.__code__)).hexdigest())
        mod.ProducerBudgetObserver.admit = stale_reentry
        return
    raise RuntimeError(f'unsupported control {mode}')
