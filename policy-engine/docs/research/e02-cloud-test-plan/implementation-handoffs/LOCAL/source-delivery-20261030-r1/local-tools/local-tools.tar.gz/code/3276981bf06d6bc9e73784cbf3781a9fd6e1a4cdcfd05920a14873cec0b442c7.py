from pathlib import Path
import ast, hashlib, json, re, subprocess, tomllib
R=Path.cwd();D=R/'LOCAL/raw/e02-execution-20261027/repairs/C97-census-oracle-r2'
m=json.loads((D/'manifest.json').read_text())
errors=[]
for row in m['source_pins']:
 data=subprocess.check_output(['git','cat-file','blob',row['git_blob']])
 actual=subprocess.check_output(['git','rev-parse',m['source_base_commit']+':'+row['path']],text=True).strip()
 if actual!=row['git_blob'] or len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:errors.append('pin:'+row['path'])
for row in m['proposal_files']:
 data=(D/row['postimage']).read_bytes()
 if len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:errors.append('postimage:'+row['path'])
 # All proposed canonical paths are still absent at the immutable r7 base.
 actual=subprocess.run(['git','cat-file','-e',m['source_base_commit']+':'+row['path']],capture_output=True)
 if actual.returncode==0:errors.append('r7-preimage-present:'+row['path'])

def apply_independently(patch_path, preimages):
 lines=patch_path.read_text().splitlines(keepends=True); outputs={};i=0
 while i<len(lines):
  if not lines[i].startswith('diff --git '):raise AssertionError(lines[i])
  path=lines[i].split(' b/',1)[1].rstrip('\n');i+=1
  while i<len(lines) and not lines[i].startswith('--- '):i+=1
  assert lines[i].startswith('--- ');i+=1
  assert lines[i]=='+++ b/'+path+'\n';i+=1
  source=preimages.get(path,'').splitlines(keepends=True);cursor=0;out=[]
  while i<len(lines) and not lines[i].startswith('diff --git '):
   match=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',lines[i]);assert match,lines[i]
   oldstart=int(match.group(1));oldcount=int(match.group(2) or 1); newcount=int(match.group(4) or 1)
   start=oldstart-1 if oldcount else oldstart
   out.extend(source[cursor:start]);cursor=start;i+=1; oldseen=newseen=0
   while i<len(lines) and not lines[i].startswith(('diff --git ','@@ ')):
    sign,text=lines[i][:1],lines[i][1:]
    if sign in (' ','-'):
     assert source[cursor]==text,(path,cursor);cursor+=1;oldseen+=1
    if sign in (' ','+'):
     out.append(text);newseen+=1
    assert sign in (' ','-','+');i+=1
   assert (oldseen,newseen)==(oldcount,newcount)
  out.extend(source[cursor:]);outputs[path]=''.join(out).encode()
 return outputs
for mode in ['root-intake','candidate-repair']:
 pre={}
 if mode=='candidate-repair':
  for row in m['proposal_files']:
   if row['candidate_preimage_git_blob']:
    pre[row['path']]=subprocess.check_output(['git','cat-file','blob',row['candidate_preimage_git_blob']]).decode()
 applied=apply_independently(D/(mode+'.diff'),pre)
 assert len(applied)==4
 for row in m['proposal_files']:
  assert applied[row['path']]==(D/row['postimage']).read_bytes()
testrow=next(row for row in m['proposal_files'] if row['path'].endswith('.py'))
test=(D/testrow['postimage']).read_text();tree=ast.parse(test)
obs=next(n.value.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CHILD_OBSERVER' for t in n.targets))
ast.parse(obs)
assert hashlib.sha256(obs.encode()).hexdigest()==m['observer_sha256']
functions=[n.name for n in tree.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
assert functions==['test_installed_census_exact_git_denominator']
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in functions)
params=[]
for dec in fn.decorator_list:
 if isinstance(dec,ast.Call) and isinstance(dec.func,ast.Attribute) and dec.func.attr=='parametrize':
  params.append({'parameter':ast.literal_eval(dec.args[0]),'values':ast.literal_eval(dec.args[1])})
extent=1
for row in params:extent*=len(row['values'])
assert extent==28
release=next(row for row in m['proposal_files'] if row['path'].endswith('.toml'))
tomllib.loads((D/release['postimage']).read_text())
assert not errors,errors
r1=R/'LOCAL/raw/e02-execution-20261027/repairs/C97-census-oracle-r1'
r1test=(r1/testrow['postimage']).read_text()
def outer_functions(text):
 return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(text).body if isinstance(n,ast.FunctionDef)}
assert outer_functions(r1test)==outer_functions(test)
assert 'tools/cli/__main__.py' not in obs
assert 'entry_spec.name != declared_module' in obs
assert 'subjects.append(("__main__", declared_module, entry_module, entry_origin))' in obs
assert 'canonical_cache_is_execution_object' in obs
assert 'installer-generated script, not a wheel/Git module member' in obs
assert 'loaded[name]' in obs and 'canonical_module' in obs
assert len(m['source_pins'])==20
r1index=r1/'delivery-index.json'
assert hashlib.sha256(r1index.read_bytes()).hexdigest()=='2025e7829eb933dde5157ef2c8e7e828eb0a7ee382240d207302f58d312306e8'
current_head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
working_pin_errors=[]
for row in m['source_pins']:
 if (R/row['path']).read_bytes()!=subprocess.check_output(['git','cat-file','blob',row['git_blob']]):
  working_pin_errors.append(row['path'])
assert working_pin_errors==['policy-engine/docs/reference/policy-design-case-failure-patterns.md']
report={
 'schema':'policyos.e02.c97.repair_static_readback.v2',
 'checks':{'immutable_git_pins':len(m['source_pins']),'proposal_files':len(m['proposal_files']),
 'source_r7_missing_paths':4,'test_ast':'parse_only','embedded_child_observer_ast':'parse_only',
 'release_toml':'parse_only','independent_in_memory_patch_modes':['root-intake','candidate-repair'],
 'patch_postimages_compared':8,'errors':errors},
 'test_definitions':functions,'literal_parameters':params,'literal_extent_not_collection':extent,
 'semantic_delta':{'working_tree_changes':'exact byte set equality against independent diff/cached-diff/ls-files oracle',
 'oracle_retention':'before actual CLI launch and assertions, including removal arms',
 'inside_child':'PID/flags/cache/origins/actual wheel and installed RECORD/source Git content',
 'source_head':'read inside actual child; source Git/read command digests retained',
 'current_parser_defect':'not established'},
 'r1_delta':{'finding':'C97-R1-ENTRY-01','outer_functions_ast_identical':True,'canonical_alias_inserted':False,'r1_index_preserved':True,'added_pin':'policy-engine/tools/cli.py','working_source_pin_documentation_deltas':working_pin_errors,'product_tool_pin_deltas':[],'observed_root_head':current_head},
 'performed':'stdlib parsing/hashing/Git reads only; same author self-review, independent delta review pending',
 'product_imports':'UNRUN','pytest':'UNRUN','build_setup':'UNRUN','ruff':'UNRUN','installed':'UNRUN','controls':'UNRUN','Cloud_launch':'UNRUN',
 'G_acceptance':False,'closure_ids':[]}
(D/'static-readback.json').write_text(json.dumps(report,indent=2)+'\n')
files=[]
for path in sorted(D.rglob('*')):
 if path.is_file() and path.name!='delivery-index.json':
  assert not path.is_symlink()
  data=path.read_bytes();files.append({'path':path.relative_to(D).as_posix(),'kind':'regular','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
index={'schema':'policyos.e02.c97.repair_delivery.v1','status':'FROZEN_R2_AUTHOR_PROPOSAL_FOR_DELTA_REVIEW_RUNTIME_UNRUN','files':files,'proposal_files':4,'G_acceptance':False,'closure_ids':[]}
(D/'delivery-index.json').write_text(json.dumps(index,indent=2)+'\n')
print(json.dumps({'checks':report['checks'],'literal_extent_not_collection':extent,'delivery_regular_files':len(files),'index_sha256':hashlib.sha256((D/'delivery-index.json').read_bytes()).hexdigest(),'manifest_sha256':hashlib.sha256((D/'manifest.json').read_bytes()).hexdigest(),'root_intake_diff_sha256':hashlib.sha256((D/'root-intake.diff').read_bytes()).hexdigest(),'candidate_repair_diff_sha256':hashlib.sha256((D/'candidate-repair.diff').read_bytes()).hexdigest(),'static_readback_sha256':hashlib.sha256((D/'static-readback.json').read_bytes()).hexdigest()}))
