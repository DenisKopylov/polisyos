"""Bind pinned probe sources to R166 and the journaled checkout, stdlib only."""
from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path
import subprocess
from xml.etree import ElementTree

repo = Path.cwd()
raw = repo / "LOCAL/raw/e02-execution-20261027/runtime-prep/R166-basis-mapping-removal-r2"
r166 = repo / ("policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/"
               "root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/"
               "deep-task-status-audit-20261027-r1/r166-v3-cov-basis-composed-r1")
base = "80e2bd118c40d97db1601fe58d8dd8ec165a5f67"
head = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
tree = subprocess.check_output(["git", "rev-parse", "HEAD^{tree}"], text=True).strip()
branch = subprocess.check_output(["git", "symbolic-ref", "--short", "HEAD"], text=True).strip()
journal = json.loads((repo / "LOCAL/raw/root-live-ownership-20261021.json").read_text())
if journal.get("head") != head or branch != "codex/e02-unified-local-20261009":
    raise RuntimeError("journal or branch mismatch")
plugin_tree = ast.parse((raw / "e02_basis_removal.py").read_text())
assignments = [node for node in plugin_tree.body if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "PINS" for target in node.targets)]
if len(assignments) != 1:
    raise RuntimeError("pin declaration ambiguous")
pins = ast.literal_eval(assignments[0].value)
for path, expected in pins.items():
    actual = hashlib.sha256((repo / path).read_bytes()).hexdigest()
    before = hashlib.sha256(subprocess.check_output(["git", "show", f"{base}:{path}"])).hexdigest()
    current = hashlib.sha256(subprocess.check_output(["git", "show", f"{head}:{path}"])).hexdigest()
    if {actual, before, current} != {expected}:
        raise RuntimeError("pinned source drift: " + path)
readset_path = r166 / "readsets/input-readset-31968.json"
readset = json.loads(readset_path.read_text())
observed = {"policy-engine/" + row["path"] for row in readset["modules"]}
if len(observed) != len(readset["modules"]) or readset["module_count"] != len(observed):
    raise RuntimeError("R166 readset denominator mismatch")
changed = set(subprocess.check_output(["git", "diff", "--name-only", base, head], text=True).splitlines())
intersection = sorted(observed & changed)
# An intersection does not alter the recorded old result. It requires a fresh
# same-source positive, which the three-run qualifier enforces independently.
xml = ElementTree.parse(r166 / "pytest.xml")
cases = list(xml.iter("testcase"))
if len(cases) != 1 or cases[0].find("failure") is not None or cases[0].find("error") is not None or cases[0].find("skipped") is not None:
    raise RuntimeError("R166 positive result mismatch")
if cases[0].get("name") != "test_served_cov_seed_reaches_persisted_refusal_without_cost_or_authority":
    raise RuntimeError("R166 selector mismatch")
result = {
    "r166_source_head": base,
    "current_journaled_head": head,
    "current_tree": tree,
    "branch": branch,
    "r166_readset_path": str(readset_path.relative_to(repo)),
    "r166_readset_sha256": hashlib.sha256(readset_path.read_bytes()).hexdigest(),
    "r166_observed_python_paths": len(observed),
    "changed_path_count": len(changed),
    "changed_paths": sorted(changed),
    "intersection": intersection,
    "r166_reusable_as_current_positive": not intersection,
    "fresh_same_source_positive_required": True,
    "pinned_sources": pins,
    "r166_positive_xml_sha256": hashlib.sha256((r166 / "pytest.xml").read_bytes()).hexdigest(),
    "scope": "R166 finite observed Python readset and 11 explicit pins; future replay needs its own readset and Git guard",
}
print(json.dumps(result, indent=2))
