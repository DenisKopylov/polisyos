"""Unexecuted in-memory removal probes for the C41-r9 selected-read witness."""

from __future__ import annotations

import ast
import hashlib
import inspect
import os
import textwrap
from typing import Any


def _mutate(function: Any, name: str, namespace: dict[str, Any]) -> Any:
    source = textwrap.dedent(inspect.getsource(function))
    tree = ast.parse(source)
    matches = 0

    class Removal(ast.NodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.AST:
            nonlocal matches
            if (
                name == "profile_pin"
                and isinstance(node.func, ast.Attribute)
                and node.func.attr == "get_bytes"
                and len(node.args) == 1
                and isinstance(node.args[0], ast.Name)
                and node.args[0].id == "selected_ref"
            ):
                matches += 1
                node.args[0] = ast.copy_location(ast.Name(id="selector", ctx=ast.Load()), node.args[0])
            return self.generic_visit(node)

        def visit_If(self, node: ast.If) -> ast.AST:
            nonlocal matches
            if name == "selected_scope" and any(
                isinstance(part, ast.Attribute)
                and isinstance(part.value, ast.Name)
                and part.value.id == "scope"
                and part.attr == "tenant_id"
                for part in ast.walk(node.test)
            ):
                matches += 1
                return ast.copy_location(ast.Pass(), node)
            return self.generic_visit(node)

        def visit_ExceptHandler(self, node: ast.ExceptHandler) -> ast.AST:
            nonlocal matches
            if (
                name == "parent_isolation"
                and isinstance(node.type, ast.Name)
                and node.type.id == "CanonicalProfileRefusalError"
                and any(
                    isinstance(part, ast.Name) and part.id == "parent_fields"
                    for part in ast.walk(node)
                )
            ):
                matches += 1
                node.body = [ast.Raise()]
            return self.generic_visit(node)

        def visit_Expr(self, node: ast.Expr) -> ast.AST:
            nonlocal matches
            if (
                name == "wrapped_cause"
                and isinstance(node.value, ast.Call)
                and isinstance(node.value.func, ast.Name)
                and node.value.func.id == "raise_artifact_read_access_error"
            ):
                matches += 1
                return ast.copy_location(ast.Pass(), node)
            return self.generic_visit(node)

        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.AST:
            nonlocal matches
            if (
                name == "access_denial"
                and node.name == "_raise_generic_read_access_refusal"
            ):
                matches += 1
                node.body = [ast.Pass()]
                return node
            return self.generic_visit(node)

    tree = Removal().visit(tree)
    if matches != 1:
        raise RuntimeError(
            f"C41-r9 removal {name}: expected one target, found {matches}"
        )
    ast.fix_missing_locations(tree)
    print(
        "C41_R9_MUTANT",
        name,
        "source_sha256=" + hashlib.sha256(source.encode()).hexdigest(),
        "ast_sha256=" + hashlib.sha256(ast.dump(tree).encode()).hexdigest(),
        flush=True,
    )
    local: dict[str, Any] = {}
    exec(compile(tree, f"<c41-r9:{name}>", "exec"), namespace, local)  # noqa: S102
    return local[function.__name__]


def pytest_configure(config: Any) -> None:
    name = os.environ.get("C41_R9_MUTATION")
    if not name:
        return
    from polisyos.runtime.http.routes import runs

    functions = {
        "selected_scope": "_generic_selected_result_manifest",
        "parent_isolation": "_generic_cycle_simulation_projection",
        "access_denial": "_raise_generic_read_access_refusal",
    }
    if name in {"wrapped_cause", "profile_pin"}:
        from polisyos.core.artifacts import selected_verification

        cls = selected_verification.SelectedProfileVerificationReader
        field = "__getattr__" if name == "wrapped_cause" else "verify"
        setattr(cls, field, _mutate(getattr(cls, field), name, vars(selected_verification)))
        return
    if name not in functions:
        raise RuntimeError(f"Unknown C41-r9 removal: {name}")
    field = functions[name]
    setattr(runs, field, _mutate(getattr(runs, field), name, vars(runs)))
