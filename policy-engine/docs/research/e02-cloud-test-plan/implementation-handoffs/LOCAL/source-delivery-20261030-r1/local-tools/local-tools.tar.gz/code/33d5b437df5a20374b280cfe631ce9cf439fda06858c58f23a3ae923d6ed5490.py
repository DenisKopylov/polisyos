"""Observe exact unchanged C43 test/backend, without mutating the product."""
from __future__ import annotations
import hashlib
import importlib
import json
import os
import subprocess
from pathlib import Path
import pytest

_STATE={}

def _need(name):
 value=os.environ.get(name)
 if not value:raise pytest.UsageError('C43 positive profile missing '+name)
 return value

def _sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def pytest_configure(config):
 root=Path(config.rootpath).resolve(strict=True)
 if root!=Path.cwd().resolve(strict=True):raise pytest.UsageError('wrong product cwd')
 here=Path(__file__).resolve(strict=True)
 if _sha(here)!=_need('C43_POSITIVE_PLUGIN_SHA256') or _sha(here.parent/'c43_child_profile.py')!=_need('C43_CHILD_PROFILE_SHA256'):
  raise pytest.UsageError('positive profile/helper mismatch')
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
 tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip()
 if head!=_need('C43_CONTROL_SOURCE_HEAD') or tree!=_need('C43_CONTROL_SOURCE_TREE'):raise pytest.UsageError('head/tree mismatch')
 source=root/_need('C43_CONTROL_SOURCE_RELATIVE');test=root/'tests/unit/remediation/test_c43_joint_gaussian.py'
 if _sha(source)!=_need('C43_CONTROL_SOURCE_SHA256') or _sha(test)!=_need('C43_CONTROL_TEST_SHA256'):raise pytest.UsageError('source/test mismatch')
 output=Path(_need('C43_CONTROL_OUTPUT')).resolve(strict=True)
 if output!=Path(_need('POLISYOS_R4_INPUT_READSET_DIR')).parent.resolve(strict=True):raise pytest.UsageError('wrong output directory')
 module_name=_need('C43_OWNER_MODULE');module=importlib.import_module('polisyos.foundry.uncertainty.'+module_name)
 if Path(module.__file__).resolve(strict=True)!=source.resolve(strict=True):raise pytest.UsageError('wrong owner module')
 _STATE.update(root=root,head=head,tree=tree,source=source,test=test,output=output)

@pytest.hookimpl(trylast=True)
def pytest_collection_finish(session):
 if len(session.items)!=1 or session.items[0].nodeid!=_need('C43_EXACT_NODE'):
  raise pytest.UsageError('exact observed test node differs')
 _STATE['selected_node']=session.items[0].nodeid

def pytest_sessionfinish(session,exitstatus):
 if not _STATE:return
 from c43_child_profile import snapshot
 path=_STATE['output']/'c43-positive-profile.json'
 if path.exists() or path.is_symlink():raise pytest.UsageError('profile output exists')
 record={'source_head':_STATE['head'],'source_tree':_STATE['tree'],'source_sha256':_sha(_STATE['source']),'test_sha256':_sha(_STATE['test']),'selected_node':_STATE.get('selected_node'),'pytest_exitstatus':int(exitstatus),'positive_profile_plugin_sha256':_need('C43_POSITIVE_PLUGIN_SHA256'),'profile_module_sha256':_need('C43_CHILD_PROFILE_SHA256'),'actual_child_profile':snapshot(session.config),'mutation':False}
 path.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
