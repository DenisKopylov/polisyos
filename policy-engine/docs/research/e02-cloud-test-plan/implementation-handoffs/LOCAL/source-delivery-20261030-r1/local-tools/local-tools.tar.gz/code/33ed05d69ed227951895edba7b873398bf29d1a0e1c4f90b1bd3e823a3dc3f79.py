"""Prepare and run one source-bound R1 native case with retained Root guards."""
from __future__ import annotations

import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import runpy
import shutil
import signal
import subprocess
import sys
import time
import traceback
import xml.etree.ElementTree as ET

WORKSPACE = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
PRODUCT = WORKSPACE / "policy-engine"
PACKET = Path(__file__).resolve().parent
ROOT_LAYER = PRODUCT / "docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/root-layer-lib.py"
SUPERVISOR = PRODUCT / "docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-postfix-709-q2-helper-actual-20261018/supervise.py"
ROOT_LIVE = WORKSPACE / "LOCAL/raw/root-live-ownership-20261021.json"


class AdmissionError(RuntimeError):
    """Raised before pytest when a source, tool, or resource pin differs."""


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path: Path, payload: object) -> None:
    data = (json.dumps(payload, indent=2, ensure_ascii=False, sort_keys=True) + "\n").encode()
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(path, flags, 0o600)
    try:
        view = memoryview(data)
        while view:
            written = os.write(fd, view)
            if written <= 0:
                raise OSError("r1_receipt_short_write")
            view = view[written:]
        os.fsync(fd)
    finally:
        os.close(fd)


def git(*args: str) -> str:
    return subprocess.check_output(["git", "-C", str(WORKSPACE), *args], text=True).strip()


def git_clean(*args: str) -> bool:
    completed = subprocess.run(
        ["git", "-C", str(WORKSPACE), *args],
        check=False,
        capture_output=True,
        text=True,
    )
    if completed.returncode not in (0, 1):
        raise AdmissionError(f"git_status_command_error:{args}:{completed.returncode}")
    return completed.returncode == 0


def assert_no_symlink_components(path: Path) -> None:
    """Reject symlinked packet/output components below the admitted workspace."""
    absolute = path.absolute()
    try:
        relative = absolute.relative_to(WORKSPACE)
    except ValueError as exc:
        raise AdmissionError(f"path_outside_workspace:{absolute}") from exc
    cursor = WORKSPACE
    if cursor.is_symlink():
        raise AdmissionError(f"workspace_is_symlink:{cursor}")
    for part in relative.parts:
        cursor = cursor / part
        if os.path.lexists(cursor) and cursor.is_symlink():
            raise AdmissionError(f"symlink_component:{cursor}")


def guarded_main(body: str) -> str:
    """Place all executable controller work behind the ordinary main guard."""
    lines = body.splitlines()
    indented = "\n".join(("    " + line) if line else "" for line in lines)
    return "if __name__ == '__main__':\n" + indented + "\n"


def classify_case_symlink(path: Path, case_root: Path, basetemp: Path) -> dict[str, object]:
    """Allow only an existing pytest numbered-dir `current` alias inside basetemp."""
    try:
        assert_no_symlink_components(case_root.absolute())
        assert_no_symlink_components(basetemp.absolute())
        assert_no_symlink_components(path.parent.absolute())
        if not path.is_symlink():
            return {"allowed": False, "classification": "not_a_symlink"}
        resolved_case = case_root.resolve(strict=True)
        resolved_base = basetemp.resolve(strict=True)
        if not resolved_base.is_relative_to(resolved_case):
            raise AdmissionError("basetemp_outside_case_root")
        if path.parent.resolve(strict=True) != resolved_base:
            raise AdmissionError("symlink_not_direct_basetemp_child")
        link_text = os.readlink(path)
        resolved_target = path.resolve(strict=True)
        if not resolved_target.is_relative_to(resolved_base) or not resolved_target.is_relative_to(resolved_case):
            raise AdmissionError("symlink_target_escapes_case_basetemp")
        if not resolved_target.is_dir() or resolved_target.parent != resolved_base:
            raise AdmissionError("symlink_target_not_existing_basetemp_sibling_directory")
        if not path.name.startswith("test_") or not path.name.endswith("current"):
            raise AdmissionError("symlink_name_not_pytest_current_alias")
        prefix = path.name[:-len("current")]
        if not resolved_target.name.startswith(prefix):
            raise AdmissionError("symlink_target_name_prefix_mismatch")
        target_suffix = resolved_target.name[len(prefix):]
        if re.fullmatch(r"(?:re)?[0-9]+", target_suffix) is None:
            raise AdmissionError("symlink_target_not_numbered_pytest_directory")
        return {
            "allowed": True,
            "classification": "pytest_numbered_dir_current_alias",
            "path": str(path),
            "link_text": link_text,
            "link_target_form": "absolute" if os.path.isabs(link_text) else "relative",
            "resolved_target": str(resolved_target),
            "case_root": str(resolved_case),
            "basetemp": str(resolved_base),
        }
    except (OSError, RuntimeError, ValueError, AdmissionError) as exc:
        return {
            "allowed": False,
            "classification": "rejected_symlink",
            "path": str(path),
            "error_type": type(exc).__name__,
            "error": str(exc),
        }


def resource_snapshot(plan: dict[str, object]) -> dict[str, object]:
    disk = shutil.disk_usage(WORKSPACE)
    total_raw = subprocess.check_output(["/usr/sbin/sysctl", "-n", "hw.memsize"], text=True)
    pressure_raw = subprocess.check_output(["/usr/bin/memory_pressure", "-Q"], text=True)
    cpu_raw = subprocess.check_output(["/usr/sbin/sysctl", "-n", "hw.ncpu"], text=True)
    match = re.search(r"System-wide memory free percentage:\s*(\d+)%", pressure_raw)
    if match is None:
        raise AdmissionError("memory_pressure_free_percent_unavailable")
    total_bytes = int(total_raw.strip())
    free_percent = int(match.group(1))
    estimated_free_bytes = total_bytes * free_percent // 100
    policy = plan["resource_admission"]
    assert isinstance(policy, dict)
    disk_start_floor = int(policy["disk_start_floor_bytes"])
    ram_start_floor = int(policy["ram_available_start_floor_bytes"])
    if disk.free < disk_start_floor:
        raise AdmissionError(f"disk_start_floor:{disk.free}<{disk_start_floor}")
    if estimated_free_bytes < ram_start_floor:
        raise AdmissionError(f"ram_available_start_floor:{estimated_free_bytes}<{ram_start_floor}")
    return {
        "measured_at_utc": datetime.datetime.now(datetime.UTC).isoformat(),
        "disk_total_bytes": disk.total,
        "disk_free_bytes": disk.free,
        "disk_used_percent": round(100 * disk.used / disk.total),
        "ram_total_bytes": total_bytes,
        "memory_pressure_stdout": pressure_raw,
        "memory_pressure_free_percent": free_percent,
        "estimated_available_ram_bytes": estimated_free_bytes,
        "cpu_count": int(cpu_raw.strip()),
        "admission_floors": {
            "disk_free_bytes": disk_start_floor,
            "estimated_available_ram_bytes": ram_start_floor,
        },
    }


def load_instrument_plan(plan_path: Path) -> tuple[dict[str, object], dict[str, object]]:
    if plan_path.resolve().parent != PACKET.resolve():
        raise AdmissionError("plan_must_be_in_packet_directory")
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    validation = validate_plan_contract(plan)
    return plan, validation


def load_case_plan(plan_path: Path, case_id: str) -> tuple[dict[str, object], dict[str, object], dict[str, object]]:
    plan, validation = load_instrument_plan(plan_path)
    cases = validation["case_rows"]
    assert isinstance(cases, dict)
    if case_id not in cases:
        raise AdmissionError(f"case_not_unique:{case_id}")
    return plan, cases[case_id], validation


def _require_mapping(value: object, label: str) -> dict[str, object]:
    if not isinstance(value, dict) or not all(isinstance(key, str) for key in value):
        raise AdmissionError(f"{label}_must_be_string_keyed_object")
    return value


def _require_sha_map(value: object, label: str) -> dict[str, str]:
    raw = _require_mapping(value, label)
    for key, digest in raw.items():
        if not isinstance(key, str) or not key or not isinstance(digest, str) or not re.fullmatch(r"[0-9a-f]{64}", digest):
            raise AdmissionError(f"{label}_entry_invalid:{key}")
    return raw  # type: ignore[return-value]


def _require_string(value: object, label: str) -> str:
    if not isinstance(value, str) or not value:
        raise AdmissionError(f"{label}_must_be_nonempty_string")
    return value


def _require_relative_path(value: object, label: str) -> str:
    raw = _require_string(value, label)
    path = Path(raw)
    if path.is_absolute() or ".." in path.parts:
        raise AdmissionError(f"{label}_must_be_safe_workspace_relative_path")
    return raw


def validate_plan_contract(plan: object) -> dict[str, object]:
    """Validate every field consumed by the R6 runner before creating case output."""
    obj = _require_mapping(plan, "plan")
    required = {
        "schema", "state", "instrument_pins", "system_tool_pins", "environment",
        "source_preimage_pins", "source_admission_protocol", "resource_admission",
        "execution", "exact_test", "run_matrix", "harness_contract", "g_acceptance",
        "closure_ids", "source_delta_base_binding",
    }
    missing = sorted(required - set(obj))
    if missing:
        raise AdmissionError(f"plan_required_fields_missing:{missing}")
    if obj["schema"] != "policyos.e02.r1.local_native_requalification_r6.instrument.v1":
        raise AdmissionError("plan_schema_mismatch")
    if obj["g_acceptance"] is not False or obj["closure_ids"] != []:
        raise AdmissionError("closure_or_acceptance_fields_must_remain_false_empty")
    exact_test = _require_mapping(obj["exact_test"], "exact_test")
    nodeid = _require_string(exact_test.get("nodeid"), "exact_test.nodeid")
    if "::" not in nodeid or nodeid.startswith("/"):
        raise AdmissionError("exact_test_nodeid_invalid")
    matrix = obj["run_matrix"]
    if not isinstance(matrix, list) or len(matrix) != 3:
        raise AdmissionError("run_matrix_must_have_exactly_three_rows")
    expected_ids = ["r1-current-positive", "r1-cache-read-removal", "r1-current-restored"]
    case_rows: dict[str, dict[str, object]] = {}
    for row in matrix:
        case = _require_mapping(row, "run_matrix_row")
        if set(case) != {"case_id", "expected", "mutation", "pytest_plugin_args"}:
            raise AdmissionError(f"run_matrix_row_contract_mismatch:{case.get('case_id')}")
        case_id = _require_string(case["case_id"], "case_id")
        if case_id in case_rows:
            raise AdmissionError(f"duplicate_case_id:{case_id}")
        if "nodeid" in case:
            raise AdmissionError(f"nodeid_must_be_resolved_once_from_exact_test:{case_id}")
        _require_string(case["expected"], f"{case_id}.expected")
        mutation = _require_mapping(case["mutation"], f"{case_id}.mutation")
        plugin_args = case["pytest_plugin_args"]
        if not isinstance(plugin_args, list) or not all(isinstance(item, str) for item in plugin_args):
            raise AdmissionError(f"{case_id}.pytest_plugin_args_must_be_string_list")
        if case_id == "r1-cache-read-removal":
            expected_mutation = {
                "kind": "force_node_result_cache_get_miss",
                "receiver_only": True,
                "plugin_module": "remove_cache_read_plugin",
                "event_order": [
                    "NodeResultCache.get_patch_installed",
                    "NodeResultCache.get_forced_miss",
                    "NodeResultCache.get_restored",
                ],
                "activation_check": {
                    "event_order": [
                        "NodeResultCache.get_patch_installed",
                        "NodeResultCache.get_forced_miss",
                        "NodeResultCache.get_restored",
                    ],
                    "event_count": 3,
                    "forced_miss_count": 1,
                    "forced_miss_returned": None,
                    "nonempty_cache_key": True,
                    "restore_success": True,
                    "one_receiver_pid": True,
                    "child_event_count": 0,
                    "plugin_must_be_loaded": True,
                },
                "environment": {"POLISYOS_R1_MUTATION_CALL_LOG": "mutation/cache-read-calls.jsonl"},
            }
            if mutation != expected_mutation:
                raise AdmissionError("removal_mutation_contract_invalid")
            if plugin_args != ["-p", "remove_cache_read_plugin"]:
                raise AdmissionError("removal_plugin_argv_invalid")
        else:
            if mutation != {"kind": "none", "environment": {}} or plugin_args != []:
                raise AdmissionError(f"unexpected_mutation_or_plugin:{case_id}")
        case_rows[case_id] = case
    if list(case_rows) != expected_ids:
        raise AdmissionError(f"run_matrix_order_or_identity_invalid:{list(case_rows)}")

    environment = _require_mapping(obj["environment"], "environment")
    for key in (
        "controller_path", "python_executable", "python_executable_sha256", "python_version",
        "pytest_version", "sandbox_exec", "git_object_format", "process_backend",
    ):
        _require_string(environment.get(key), f"environment.{key}")
    if not re.fullmatch(r"[0-9a-f]{64}", str(environment["python_executable_sha256"])):
        raise AdmissionError("python_executable_sha256_invalid")
    command_resolution = _require_mapping(environment.get("command_resolution"), "command_resolution")
    if set(command_resolution) != {"git", "ps"}:
        raise AdmissionError("command_resolution_contract_invalid")
    for key, value in command_resolution.items():
        _require_string(value, f"command_resolution.{key}")
    numeric_threads = _require_mapping(environment.get("numeric_thread_overrides"), "numeric_thread_overrides")
    expected_numeric_thread_names = {
        "OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMBA_NUM_THREADS",
        "NUMEXPR_NUM_THREADS", "ARROW_NUM_THREADS", "BLIS_NUM_THREADS", "POLARS_MAX_THREADS",
        "TF_NUM_INTEROP_THREADS", "TF_NUM_INTRAOP_THREADS", "VECLIB_MAXIMUM_THREADS",
    }
    if set(numeric_threads) != expected_numeric_thread_names or any(not isinstance(v, str) or v != "1" for v in numeric_threads.values()):
        raise AdmissionError("numeric_thread_overrides_invalid")
    metadata = _require_mapping(environment.get("pytest_distribution_metadata"), "pytest_distribution_metadata")
    for name in ("pytest", "pluggy", "pytest-asyncio", "pytest-benchmark", "pytest-xdist"):
        distribution = _require_mapping(metadata.get(name), f"pytest_distribution_metadata.{name}")
        _require_string(distribution.get("path"), f"{name}.path")
        _require_string(distribution.get("version"), f"{name}.version")
        if not re.fullmatch(r"[0-9a-f]{64}", str(distribution.get("sha256", ""))):
            raise AdmissionError(f"{name}.sha256_invalid")

    for key in ("instrument_pins", "system_tool_pins", "source_preimage_pins"):
        _require_sha_map(obj[key], key)
    instrument_pins = obj["instrument_pins"]
    system_pins = obj["system_tool_pins"]
    if str(environment["sandbox_exec"]) not in system_pins:
        raise AdmissionError("sandbox_executable_not_system_pinned")
    for command, path in command_resolution.items():
        if str(path) not in system_pins:
            raise AdmissionError(f"resolved_command_not_system_pinned:{command}")
    metadata_paths = [
        str(row["path"])
        for row in _require_mapping(environment["pytest_distribution_metadata"], "pytest_distribution_metadata").values()
        if isinstance(row, dict) and isinstance(row.get("path"), str)
    ]
    required_instrument_paths = {
        (PACKET.relative_to(WORKSPACE) / name).as_posix()
        for name in ("README.md", "run_r1_case_r6.py", "sitecustomize.py", "remove_cache_read_plugin.py")
    } | {
        str(environment["python_executable"]),
        str(environment["editable_pth_path"]),
        str(environment["pyvenv_cfg_path"]),
        *metadata_paths,
        str(obj["source_admission_protocol"]["root_guard_path"]),
        "policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1/run_case_with_tools_r3.py",
        "policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-postfix-709-q2-helper-actual-20261018/supervise.py",
    }
    if required_instrument_paths - set(instrument_pins):
        raise AdmissionError(f"required_instrument_pins_missing:{sorted(required_instrument_paths - set(instrument_pins))}")
    execution = _require_mapping(obj["execution"], "execution")
    runs_parent = _require_relative_path(execution.get("runs_parent"), "execution.runs_parent")
    if runs_parent != (PACKET.relative_to(WORKSPACE) / "runs").as_posix():
        raise AdmissionError("runs_parent_must_be_the_stable_r6_packet_parent")
    if execution.get("case_output_root_binding") != "admission.execution_binding.case_output_root; unique wave-specific root under execution.runs_parent":
        raise AdmissionError("case_output_root_binding_contract_mismatch")
    prepare_report = _require_relative_path(execution.get("prepare_only_report"), "execution.prepare_only_report")
    if Path(prepare_report).parent != PACKET.relative_to(WORKSPACE):
        raise AdmissionError("prepare_only_report_must_be_in_packet_directory")
    if execution.get("one_case_per_invocation") is not True or execution.get("do_not_retry_automatically") is not True:
        raise AdmissionError("execution_safety_contract_invalid")
    if execution.get("order") != expected_ids:
        raise AdmissionError("execution_order_mismatch")
    _require_string(execution.get("root_command_interpreter"), "execution.root_command_interpreter")
    _require_string(execution.get("case_command_argv"), "execution.case_command_argv")
    resources = _require_mapping(obj["resource_admission"], "resource_admission")
    numeric_resource_keys = (
        "disk_start_floor_bytes", "ram_available_start_floor_bytes", "sampled_process_tree_rss_cap_bytes",
        "supervisor_disk_stop_floor_bytes", "sample_interval_seconds", "supervisor_deadline_margin_seconds",
        "wall_limit_seconds_per_case",
    )
    for key in numeric_resource_keys:
        value = resources.get(key)
        if isinstance(value, bool) or not isinstance(value, (int, float)) or value <= 0:
            raise AdmissionError(f"resource_admission.{key}_must_be_positive_number")
    harness = _require_mapping(obj["harness_contract"], "harness_contract")
    required_harness = {
        "nodeid_source", "case_row_required_keys", "case_directory_names", "mutation_directory_name",
        "pycache_prefix_name", "pytest_launcher_name", "sandbox_profile_name", "output_files",
        "plugin_contract", "case_order", "case_root_pattern", "case_root_must_be_absent_before_run",
        "pycache_prefix_must_be_absent_before_run_and_after_run", "sandbox_write_scope", "no_automatic_retry",
    }
    if required_harness - set(harness):
        raise AdmissionError(f"harness_contract_fields_missing:{sorted(required_harness - set(harness))}")
    if harness["nodeid_source"] != "exact_test.nodeid" or harness["case_row_required_keys"] != ["case_id", "expected", "mutation", "pytest_plugin_args"]:
        raise AdmissionError("harness_case_contract_mismatch")
    if harness["case_order"] != expected_ids or harness["case_root_must_be_absent_before_run"] is not True or harness["pycache_prefix_must_be_absent_before_run_and_after_run"] is not True:
        raise AdmissionError("harness_order_or_freshness_contract_mismatch")
    expected_dirs = ["tmp", "home", "readsets", "pytest-cache", "benchmarks", "basetemp"]
    if harness["case_directory_names"] != expected_dirs:
        raise AdmissionError("case_directory_layout_mismatch")
    if harness["mutation_directory_name"] != "mutation" or harness["pycache_prefix_name"] != "pycache-prefix-absent":
        raise AdmissionError("private_output_directory_contract_mismatch")
    if harness["pytest_launcher_name"] != "pytest_launcher.py" or harness["sandbox_profile_name"] != "child.sb":
        raise AdmissionError("command_file_contract_mismatch")
    if harness["case_root_pattern"] != "admission.execution_binding.case_output_root / case_id" or harness["sandbox_write_scope"] != "case root plus /dev/null only":
        raise AdmissionError("case_path_or_sandbox_contract_mismatch")
    if harness.get("launcher_main_guard") != "pytest import, profile write, and pytest.main execute only inside __name__ == __main__; spawn __mp_main__ re-entry never starts nested pytest":
        raise AdmissionError("launcher_main_guard_contract_mismatch")
    if harness.get("observer_driver_identity") != "first and only exclusive exact-driver PID claim for the exact absolute startup argv[0] path; absence of startup --multiprocessing-fork marker; auxiliary processes cannot emit driver readsets":
        raise AdmissionError("observer_driver_identity_contract_mismatch")
    if harness.get("output_symlinks") != "permit only strict-existing pytest basetemp sibling current aliases whose resolved target is in the same case basetemp; reject all ancestors, escapes, dangling, cyclic, and other links":
        raise AdmissionError("output_symlink_contract_mismatch")
    if harness.get("wave_output_root") != "Fresh admission.execution_binding.case_output_root, exact child of stable execution.runs_parent and unique to this wave; never reuse R5 outputs":
        raise AdmissionError("wave_output_root_contract_mismatch")
    if harness["no_automatic_retry"] is not True:
        raise AdmissionError("automatic_retry_forbidden")
    output_files = _require_mapping(harness["output_files"], "harness.output_files")
    expected_outputs = {
        "junit": "pytest.xml", "runtime_profile": "pytest-runtime-profile.json",
        "source_profile": "source-profile-freeze.json", "audit_result": "audit-result.json",
        "runner_error": "runner-error.json", "mutation_log": "mutation/cache-read-calls.jsonl",
    }
    if output_files != expected_outputs:
        raise AdmissionError("harness_output_layout_mismatch")
    if harness["plugin_contract"] != {
        "none": [], "force_node_result_cache_get_miss": ["-p", "remove_cache_read_plugin"]
    }:
        raise AdmissionError("harness_plugin_contract_mismatch")
    source_protocol = _require_mapping(obj["source_admission_protocol"], "source_admission_protocol")
    if source_protocol.get("admission_path_mode") != "explicit CLI path; existing regular non-symlink JSON file located under this packet; identity bound by CLI SHA and source fields":
        raise AdmissionError("admission_path_mode_mismatch")
    if source_protocol.get("source_delta_path_mode") != "admission-bound relative path to an existing regular non-symlink file under this packet; validate content identity and actual Git delta, never admit by filename":
        raise AdmissionError("source_delta_path_mode_mismatch")
    _require_string(source_protocol.get("root_guard_path"), "source_admission_protocol.root_guard_path")
    _require_string(source_protocol.get("root_guard_method"), "source_admission_protocol.root_guard_method")
    source_delta_base = _require_mapping(obj["source_delta_base_binding"], "source_delta_base_binding")
    for key in ("commit", "tree"):
        value = _require_string(source_delta_base.get(key), f"source_delta_base_binding.{key}")
        if not re.fullmatch(r"[0-9a-f]{40,64}", value):
            raise AdmissionError(f"source_delta_base_binding.{key}_invalid")
    return {"nodeid": nodeid, "case_rows": case_rows, "execution": execution, "environment": environment, "harness": harness, "runs_parent": runs_parent, "source_delta_base_binding": source_delta_base}


def load_admission(admission_path: Path, expected_sha256: str, *, require_frozen: bool = True) -> dict[str, object]:
    assert_no_symlink_components(admission_path.absolute())
    if admission_path.is_symlink():
        raise AdmissionError("admission_file_must_not_be_symlink")
    resolved_admission = admission_path.resolve(strict=True)
    if not resolved_admission.is_relative_to(PACKET.resolve()) or not resolved_admission.is_file():
        raise AdmissionError("admission_must_be_regular_file_under_packet")
    admission_path = resolved_admission
    if not re.fullmatch(r"[0-9a-f]{64}", expected_sha256):
        raise AdmissionError("expected_admission_sha256_invalid")
    actual_sha256 = sha256(admission_path)
    if actual_sha256 != expected_sha256:
        raise AdmissionError("admission_sha256_mismatch")
    admission = json.loads(admission_path.read_text(encoding="utf-8"))
    if not isinstance(admission, dict) or not all(isinstance(key, str) for key in admission):
        raise AdmissionError("admission_must_be_string_keyed_object")
    if admission.get("schema") != "policyos.e02.r1.local_native_requalification_r6.launch_admission.v1":
        raise AdmissionError("admission_schema_mismatch")
    allowed = {"ADMITTED_FOR_ONE_SOURCE_FROZEN_WAVE"} if require_frozen else {"ADMITTED_FOR_ONE_SOURCE_FROZEN_WAVE", "PREPARATION_SNAPSHOT_NOT_FROZEN"}
    if admission.get("state") not in allowed:
        raise AdmissionError("launch_admission_not_in_allowed_state")
    return admission


def _packet_input(relative: object, label: str) -> Path:
    rel = _require_relative_path(relative, label)
    path = WORKSPACE / rel
    assert_no_symlink_components(path.absolute())
    if path.is_symlink():
        raise AdmissionError(f"{label}_must_not_be_symlink")
    resolved = path.resolve(strict=True)
    if not resolved.is_relative_to(PACKET.resolve()) or not resolved.is_file():
        raise AdmissionError(f"{label}_must_be_regular_file_under_packet")
    return resolved


def validate_admission_contract(plan: dict[str, object], admission: dict[str, object]) -> str:
    if admission.get("g_acceptance") is not False or admission.get("closure_ids") != []:
        raise AdmissionError("admission_must_not_claim_acceptance_or_closure")
    source = _require_mapping(admission.get("source_binding"), "admission.source_binding")
    required = {
        "branch", "commit", "tree", "root_live_path", "root_live_sha256", "source_frame_path",
        "source_frame_sha256", "source_delta_path", "source_delta_sha256",
        "expected_index_raw_diff_sha256", "git_object_format",
    }
    if required - set(source):
        raise AdmissionError(f"admission_source_binding_fields_missing:{sorted(required - set(source))}")
    for key in ("branch", "root_live_path", "source_frame_path", "source_delta_path", "git_object_format"):
        _require_string(source.get(key), f"admission.source_binding.{key}")
    if source["root_live_path"] != str(ROOT_LIVE.relative_to(WORKSPACE)):
        raise AdmissionError("admission_root_live_path_not_canonical")
    frame_rel = _require_relative_path(source["source_frame_path"], "admission.source_frame_path")
    frame_path = WORKSPACE / frame_rel
    assert_no_symlink_components(frame_path.absolute())
    if frame_path.is_symlink() or not frame_path.is_file():
        raise AdmissionError("admission_source_frame_must_be_regular_non_symlink_file")
    if source["git_object_format"] not in {"sha1", "sha256"}:
        raise AdmissionError("admission_git_object_format_invalid")
    for key in ("commit", "tree"):
        value = _require_string(source.get(key), f"admission.source_binding.{key}")
        if not re.fullmatch(r"[0-9a-f]{40,64}", value):
            raise AdmissionError(f"admission_source_binding_identity_invalid:{key}")
    for key, value in source.items():
        if key.endswith("_sha256") and (not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{64}", value)):
            raise AdmissionError(f"admission_source_binding_hash_invalid:{key}")
    input_pins = _require_sha_map(admission.get("input_pins"), "admission.input_pins")
    required_inputs = _require_sha_map(plan["source_preimage_pins"], "plan.source_preimage_pins")
    if set(required_inputs) != set(input_pins):
        raise AdmissionError("admission_input_pin_path_set_must_match_stable_r1_scope")
    for relative in input_pins:
        _require_relative_path(relative, "admission.input_pin_path")
    if admission.get("orchestration_order") != plan["execution"]["order"]:
        raise AdmissionError("admission_order_differs_from_plan")
    execution_binding = _require_mapping(admission.get("execution_binding"), "admission.execution_binding")
    wave_id = _require_string(execution_binding.get("wave_id"), "admission.execution_binding.wave_id")
    if re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}", wave_id) is None:
        raise AdmissionError("execution_binding_wave_id_invalid")
    case_output_root = _require_relative_path(execution_binding.get("case_output_root"), "admission.execution_binding.case_output_root")
    expected_output_root = (PACKET.relative_to(WORKSPACE) / "runs" / wave_id).as_posix()
    if case_output_root != expected_output_root:
        raise AdmissionError("execution_binding_output_root_not_unique_child_of_runs_parent")
    output_root_path = WORKSPACE / case_output_root
    assert_no_symlink_components(output_root_path.absolute())
    if output_root_path.is_symlink():
        raise AdmissionError("execution_binding_output_root_must_not_be_symlink")

    delta_path = _packet_input(source["source_delta_path"], "admission.source_delta_path")
    if sha256(delta_path) != source["source_delta_sha256"]:
        raise AdmissionError("admission_source_delta_hash_mismatch")
    delta = _require_mapping(json.loads(delta_path.read_text(encoding="utf-8")), "source_delta")
    expected_delta_state = (
        "FROZEN_FOR_ONE_R1_WAVE"
        if admission.get("state") == "ADMITTED_FOR_ONE_SOURCE_FROZEN_WAVE"
        else "PREPARATION_SNAPSHOT_NOT_FROZEN"
    )
    if delta.get("schema") != "policyos.e02.r1.r6.source_delta_receipt.v1" or delta.get("state") != expected_delta_state:
        raise AdmissionError("source_delta_schema_or_state_mismatch")
    plan_base = _require_mapping(plan["source_delta_base_binding"], "source_delta_base_binding")
    if delta.get("source_base") != plan_base:
        raise AdmissionError("source_delta_base_does_not_match_stable_plan")
    candidate = _require_mapping(delta.get("candidate_source"), "source_delta.candidate_source")
    if {key: source[key] for key in ("branch", "commit", "tree")} != candidate:
        raise AdmissionError("source_delta_candidate_identity_mismatch")
    root_live = _require_mapping(delta.get("root_live"), "source_delta.root_live")
    if root_live != {"path": source["root_live_path"], "sha256": source["root_live_sha256"]}:
        raise AdmissionError("source_delta_root_live_binding_mismatch")
    frame = _require_mapping(delta.get("source_frame"), "source_delta.source_frame")
    if frame != {"path": source["source_frame_path"], "sha256": source["source_frame_sha256"]}:
        raise AdmissionError("source_delta_source_frame_binding_mismatch")
    index = _require_mapping(delta.get("git_index"), "source_delta.git_index")
    if index.get("raw_diff_sha256") != source["expected_index_raw_diff_sha256"]:
        raise AdmissionError("source_delta_index_binding_mismatch")
    empty_index_sha = hashlib.sha256(b"").hexdigest()
    expected_empty = source["expected_index_raw_diff_sha256"] == empty_index_sha
    if index.get("empty") is not expected_empty:
        raise AdmissionError("source_delta_index_empty_marker_invalid")
    selected_rows = delta.get("selected_input_preimages")
    if not isinstance(selected_rows, list):
        raise AdmissionError("source_delta_selected_inputs_missing")
    selected: dict[str, str] = {}
    for row in selected_rows:
        item = _require_mapping(row, "source_delta.selected_input")
        path = _require_string(item.get("path"), "source_delta.selected_input.path")
        digest = _require_string(item.get("sha256"), "source_delta.selected_input.sha256")
        if not re.fullmatch(r"[0-9a-f]{64}", digest) or path in selected:
            raise AdmissionError("source_delta_selected_input_invalid_or_duplicate")
        selected[path] = digest
    if selected != input_pins:
        raise AdmissionError("source_delta_selected_inputs_differ_from_admission")
    changed = delta.get("changed_paths_from_base")
    if not isinstance(changed, list) or not all(isinstance(path, str) for path in changed):
        raise AdmissionError("source_delta_paths_must_be_string_list")
    if changed != sorted(set(changed)) or delta.get("changed_path_count") != len(changed):
        raise AdmissionError("source_delta_path_denominator_invalid")
    if delta.get("tracked_worktree_clean") is not True or delta.get("closure_ids") != [] or delta.get("g_acceptance") is not False:
        raise AdmissionError("source_delta_state_or_closure_invalid")
    return case_output_root

def verify_static_pins(plan: dict[str, object], expected_sha256: str, plan_path: Path) -> dict[str, object]:
    if not re.fullmatch(r"[0-9a-f]{64}", expected_sha256):
        raise AdmissionError("expected_plan_sha256_invalid")
    actual_plan_sha256 = sha256(plan_path)
    if actual_plan_sha256 != expected_sha256:
        raise AdmissionError("plan_sha256_mismatch")
    pins = plan.get("instrument_pins")
    if not isinstance(pins, dict):
        raise AdmissionError("instrument_pins_missing")
    for relative, expected in pins.items():
        if Path(relative).is_absolute() or ".." in Path(relative).parts:
            raise AdmissionError(f"instrument_pin_path_invalid:{relative}")
        path = WORKSPACE / relative
        if not path.is_file() or sha256(path) != expected:
            raise AdmissionError(f"instrument_pin_mismatch:{relative}")
    system_pins = plan.get("system_tool_pins")
    if not isinstance(system_pins, dict):
        raise AdmissionError("system_tool_pins_missing")
    for absolute, expected in system_pins.items():
        path = Path(absolute)
        if not path.is_absolute() or not path.is_file() or sha256(path) != expected:
            raise AdmissionError(f"system_tool_pin_mismatch:{absolute}")
    environment = plan.get("environment")
    if not isinstance(environment, dict):
        raise AdmissionError("environment_profile_missing")
    controller_path = str(environment["controller_path"])
    os.environ["PATH"] = controller_path
    command_resolution = environment.get("command_resolution")
    if not isinstance(command_resolution, dict):
        raise AdmissionError("controller_command_resolution_missing")
    for command, expected_path in command_resolution.items():
        actual_path = shutil.which(str(command))
        if actual_path is None or Path(actual_path).resolve() != Path(str(expected_path)).resolve():
            raise AdmissionError(f"controller_command_resolution_mismatch:{command}:{actual_path}")
    return {"plan_sha256": actual_plan_sha256, "instrument_pins": pins, "system_tool_pins": system_pins}


def admitted_source_files(source: dict[str, object]) -> dict[str, str]:
    frame_path = WORKSPACE / str(source["source_frame_path"])
    frame = json.loads(frame_path.read_text(encoding="utf-8"))
    live = json.loads(ROOT_LIVE.read_text(encoding="utf-8"))
    files: dict[str, str] = {}
    for row in frame.get("paths", []):
        files[str(row["path"])] = str(row["sha256"])
    for row in live.get("known_dirty_paths", []):
        files[str(row["path"])] = str(row["sha256"])
    return files


def git_source_blob_map() -> tuple[dict[str, str], str]:
    object_format = git("rev-parse", "--show-object-format")
    if object_format not in {"sha1", "sha256"}:
        raise AdmissionError(f"unsupported_git_object_format:{object_format}")
    completed = subprocess.run(
        [
            "git", "-C", str(WORKSPACE), "ls-tree", "-rz", "--full-tree", "HEAD", "--",
            "policy-engine/src/polisyos", "policy-engine/tests", "policy-engine/tools",
        ],
        check=True,
        capture_output=True,
    )
    blobs: dict[str, str] = {}
    for record in completed.stdout.split(b"\0"):
        if not record:
            continue
        header, separator, path = record.partition(b"\t")
        if not separator:
            raise AdmissionError("git_source_tree_record_malformed")
        fields = header.decode("ascii").split()
        if len(fields) != 3 or fields[1] != "blob":
            continue
        blobs[os.fsdecode(path)] = fields[2]
    if not blobs:
        raise AdmissionError("git_source_tree_empty")
    return blobs, object_format


def verify_source_and_inputs(plan: dict[str, object], admission: dict[str, object], guard) -> dict[str, object]:
    validate_admission_contract(plan, admission)
    source = admission["source_binding"]
    assert isinstance(source, dict)
    assert_no_symlink_components(ROOT_LIVE.absolute())
    if ROOT_LIVE.is_symlink() or not ROOT_LIVE.is_file():
        raise AdmissionError("root_live_must_be_regular_non_symlink_file")
    live_hash = sha256(ROOT_LIVE)
    if live_hash != source["root_live_sha256"]:
        raise AdmissionError("root_live_hash_mismatch")
    live = json.loads(ROOT_LIVE.read_text(encoding="utf-8"))
    if live.get("branch") != source["branch"] or live.get("head") != source["commit"] or live.get("tree") != source["tree"]:
        raise AdmissionError("root_live_identity_mismatch")
    if git("symbolic-ref", "--short", "HEAD") != source["branch"]:
        raise AdmissionError("branch_mismatch")
    if git("rev-parse", "HEAD") != source["commit"] or git("rev-parse", "HEAD^{tree}") != source["tree"]:
        raise AdmissionError("head_or_tree_mismatch")
    if not git_clean("diff", "--quiet") or not git_clean("diff", "--cached", "--quiet"):
        raise AdmissionError("tracked_source_or_index_dirty")
    raw_index = subprocess.check_output(["git", "-C", str(WORKSPACE), "diff", "--cached", "--raw", "--no-abbrev", "-z"])
    raw_index_sha = hashlib.sha256(raw_index).hexdigest()
    if raw_index_sha != source["expected_index_raw_diff_sha256"]:
        raise AdmissionError("raw_index_binding_mismatch")
    frame_path = WORKSPACE / str(source["source_frame_path"])
    assert_no_symlink_components(frame_path.absolute())
    if not frame_path.is_file() or frame_path.is_symlink() or sha256(frame_path) != source["source_frame_sha256"]:
        raise AdmissionError("source_frame_hash_mismatch")

    base = plan["source_delta_base_binding"]
    assert isinstance(base, dict)
    if git("rev-parse", f"{base['commit']}^{{tree}}") != base["tree"]:
        raise AdmissionError("source_delta_base_tree_mismatch")
    actual_changed_paths = subprocess.check_output(
        ["git", "-C", str(WORKSPACE), "diff", "--name-only", "--no-renames", str(base["commit"]), str(source["commit"])],
        text=True,
    ).splitlines()
    actual_changed_paths = sorted(set(actual_changed_paths))
    delta_path = _packet_input(source["source_delta_path"], "admission.source_delta_path")
    delta = json.loads(delta_path.read_text(encoding="utf-8"))
    if delta.get("changed_paths_from_base") != actual_changed_paths or delta.get("changed_path_count") != len(actual_changed_paths):
        raise AdmissionError("source_delta_paths_do_not_match_actual_git_diff")
    delta_hash = sha256(delta_path)
    if delta_hash != source["source_delta_sha256"]:
        raise AdmissionError("source_delta_receipt_hash_mismatch")

    before = guard()
    admission_pins = _require_sha_map(admission["input_pins"], "admission.input_pins")
    required_paths = set(_require_sha_map(plan["source_preimage_pins"], "plan.source_preimage_pins"))
    if required_paths != set(admission_pins):
        raise AdmissionError("source_pin_scope_mismatch")
    for relative, expected in admission_pins.items():
        path = WORKSPACE / relative
        if not path.is_file() or path.is_symlink() or sha256(path) != expected:
            raise AdmissionError(f"input_pin_mismatch:{relative}")
    return {
        "branch": source["branch"],
        "head": source["commit"],
        "tree": source["tree"],
        "root_live_sha256": live_hash,
        "source_frame_path": str(source["source_frame_path"]),
        "source_frame_sha256": str(source["source_frame_sha256"]),
        "source_delta_path": str(source["source_delta_path"]),
        "source_delta_sha256": delta_hash,
        "source_delta_base": base,
        "source_delta_path_count_recomputed": len(actual_changed_paths),
        "expected_index_raw_diff_sha256": raw_index_sha,
        "root_guard_before": before,
        "source_input_pins": admission_pins,
        "admitted_source_file_count": len(admitted_source_files(source)),
    }

def pytest_profile_launcher(
    expected_sitecustomize: Path,
    expected_python: Path,
    expected_python_version: str,
    expected_pytest_version: str,
    runtime_profile_path: Path,
    case_id: str,
    pytest_args: list[str],
) -> str:
    body = (
        "import pathlib, sys\n"
        "expected = pathlib.Path(" + repr(str(expected_sitecustomize)) + ").resolve()\n"
        "loaded = sys.modules.get('sitecustomize')\n"
        "if loaded is None or pathlib.Path(getattr(loaded, '__file__', '')).resolve() != expected:\n"
        "    print('R1_SITECUSTOMIZE_ADMISSION_MISMATCH', file=sys.stderr, flush=True)\n"
        "    raise SystemExit(92)\n"
        "if pathlib.Path(sys.executable).resolve() != pathlib.Path(" + repr(str(expected_python)) + ").resolve():\n"
        "    print('R1_PYTHON_EXECUTABLE_MISMATCH', file=sys.stderr, flush=True)\n"
        "    raise SystemExit(93)\n"
        "if '.'.join(map(str, sys.version_info[:3])) != " + repr(expected_python_version) + ":\n"
        "    print('R1_PYTHON_VERSION_MISMATCH', file=sys.stderr, flush=True)\n"
        "    raise SystemExit(94)\n"
        "import pytest\n"
        "if pytest.__version__ != " + repr(expected_pytest_version) + ":\n"
        "    print('R1_PYTEST_VERSION_MISMATCH', file=sys.stderr, flush=True)\n"
        "    raise SystemExit(95)\n"
        "print('R1_RUNTIME_PROFILE python=' + sys.version.split()[0] + ' pytest=' + pytest.__version__, flush=True)\n"
        "import json, os\n"
        "class _R1RuntimeProfile:\n"
        "    def pytest_configure(self, config):\n"
        "        plugins = []\n"
        "        for name, plugin in config.pluginmanager.list_name_plugin():\n"
        "            if plugin is None:\n"
        "                continue\n"
        "            module_name = getattr(plugin, '__name__', type(plugin).__module__)\n"
        "            plugins.append({'name': str(name), 'module': str(module_name), 'version': str(getattr(plugin, '__version__', ''))})\n"
        "        payload = {'schema': 'policyos.e02.r1.pytest_runtime_profile.v1', 'python_version': sys.version.split()[0], 'python_executable': str(pathlib.Path(sys.executable).resolve()), 'pytest_version': pytest.__version__, 'plugins': sorted(plugins, key=lambda row: row['name'])}\n"
        "        path = pathlib.Path(" + repr(str(runtime_profile_path)) + ")\n"
        "        with path.open('x', encoding='utf-8') as stream:\n"
        "            json.dump(payload, stream, sort_keys=True, separators=(',', ':'))\n"
        "            stream.write('\\n')\n"
        "            stream.flush()\n"
        "            os.fsync(stream.fileno())\n"
        "raise SystemExit(pytest.main(" + repr(pytest_args) + ", plugins=[_R1RuntimeProfile()]))\n"
    )
    return guarded_main(body)


def build_case_spec(
    plan: dict[str, object],
    case_row: dict[str, object],
    case_root: Path,
    python_path: Path,
    validation: dict[str, object],
) -> dict[str, object]:
    """Build the exact same launcher, sandbox, environment and argv for preflight and execution."""
    environment = validation["environment"]
    harness = validation["harness"]
    nodeid = str(validation["nodeid"])
    outputs = harness["output_files"]
    directories = harness["case_directory_names"]
    directory_by_name = {name: case_root / name for name in directories}
    launcher_path = case_root / str(harness["pytest_launcher_name"])
    sandbox_path = case_root / str(harness["sandbox_profile_name"])
    pycache_prefix = case_root / str(harness["pycache_prefix_name"])
    mutation = case_row["mutation"]
    assert isinstance(mutation, dict)
    mutation_kind = str(mutation["kind"])
    plugin_args = list(case_row["pytest_plugin_args"])
    junit_path = case_root / str(outputs["junit"])
    pytest_args = [
        "-o", f"cache_dir={directory_by_name['pytest-cache']}",
        "--benchmark-storage=" + (directory_by_name["benchmarks"]).as_uri(),
        "--basetemp", str(directory_by_name["basetemp"]),
        "--junitxml=" + str(junit_path),
        "--tb=short", "--color=no", "--maxfail=0",
        *plugin_args,
        nodeid,
    ]
    helper_dir = PACKET.resolve()
    sitecustomize = helper_dir / "sitecustomize.py"
    plugin = helper_dir / "remove_cache_read_plugin.py"
    launcher_text = pytest_profile_launcher(
        sitecustomize,
        python_path.resolve(),
        str(environment["python_version"]),
        str(environment["pytest_version"]),
        case_root / str(outputs["runtime_profile"]),
        str(case_row["case_id"]),
        pytest_args,
    )
    compile(launcher_text, f"<r1-r6-{case_row['case_id']}-generated-pytest-launcher>", "exec")
    sandbox_text = (
        "(version 1)\n"
        "(allow default)\n"
        "(deny file-write*)\n"
        "(allow file-write* (subpath " + json.dumps(str(case_root)) + "))\n"
        '(allow file-write* (literal "/dev/null"))\n'
    )
    env = {
        "PATH": str(environment["controller_path"]),
        "HOME": str(directory_by_name["home"]),
        "TMPDIR": str(directory_by_name["tmp"]),
        "XDG_CACHE_HOME": str(directory_by_name["tmp"] / "xdg"),
        "MPLCONFIGDIR": str(directory_by_name["tmp"] / "mpl"),
        "NUMBA_CACHE_DIR": str(directory_by_name["tmp"] / "numba"),
        "HYPOTHESIS_STORAGE_DIRECTORY": str(directory_by_name["tmp"] / "hypothesis"),
        "PYTHONPATH": str(helper_dir),
        "PYTHONPYCACHEPREFIX": str(pycache_prefix),
        "PYTHONNOUSERSITE": "1",
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONUNBUFFERED": "1",
        "POLISYOS_R1_PROJECT_ROOT": str(PRODUCT.resolve()),
        "POLISYOS_R1_READSET_DIR": str((case_root / "readsets").resolve()),
        "POLISYOS_R1_RUNTIME_PROFILE": str((case_root / str(outputs["runtime_profile"])).resolve()),
        "POLISYOS_R1_EXPECTED_LAUNCHER": str(launcher_path.absolute()),
    }
    for optional in ("LANG", "LC_ALL", "LC_CTYPE"):
        if optional in os.environ:
            env[optional] = os.environ[optional]
    numeric_threads = environment["numeric_thread_overrides"]
    assert isinstance(numeric_threads, dict)
    env.update({str(key): str(value) for key, value in numeric_threads.items()})
    if mutation_kind != "none":
        mutation_env = mutation["environment"]
        assert isinstance(mutation_env, dict)
        for key, relative in mutation_env.items():
            path = Path(str(relative))
            if path.is_absolute() or ".." in path.parts:
                raise AdmissionError(f"mutation_environment_path_invalid:{key}")
            env[str(key)] = str(case_root / path)
    sandbox_exec = str(environment["sandbox_exec"])
    python_argv = [str(python_path), "-B", str(launcher_path)]
    command_argv = [sandbox_exec, "-f", str(sandbox_path), *python_argv]
    return {
        "case_id": str(case_row["case_id"]),
        "nodeid": nodeid,
        "mutation_kind": mutation_kind,
        "pytest_plugin_args": plugin_args,
        "pytest_args": pytest_args,
        "environment_overrides": env,
        "launcher_path": launcher_path,
        "launcher_text": launcher_text,
        "sandbox_path": sandbox_path,
        "sandbox_text": sandbox_text,
        "sitecustomize_path": sitecustomize,
        "plugin_path": plugin,
        "pycache_prefix": pycache_prefix,
        "python_argv": python_argv,
        "command_argv": command_argv,
        "cwd": PRODUCT,
        "output_paths": {name: case_root / str(relative) for name, relative in outputs.items()},
        "case_directories": list(directories),
        "mutation_directory_name": str(harness["mutation_directory_name"]),
    }


def verify_preparation_source_snapshot(plan: dict[str, object], admission: dict[str, object]) -> dict[str, object]:
    """Reconcile the admitted source snapshot without importing product code or running the Root guard."""
    source = _require_mapping(admission.get("source_binding"), "admission.source_binding")
    if git("symbolic-ref", "--short", "HEAD") != source["branch"]:
        raise AdmissionError("prepare_only_branch_mismatch")
    if git("rev-parse", "HEAD") != source["commit"] or git("rev-parse", "HEAD^{tree}") != source["tree"]:
        raise AdmissionError("prepare_only_head_or_tree_mismatch")
    if not git_clean("diff", "--quiet") or not git_clean("diff", "--cached", "--quiet"):
        raise AdmissionError("prepare_only_tracked_worktree_not_clean")
    raw_index = subprocess.check_output(["git", "-C", str(WORKSPACE), "diff", "--cached", "--raw", "--no-abbrev", "-z"])
    raw_index_sha = hashlib.sha256(raw_index).hexdigest()
    if raw_index_sha != source["expected_index_raw_diff_sha256"]:
        raise AdmissionError("prepare_only_index_binding_mismatch")
    live_path = ROOT_LIVE
    assert_no_symlink_components(live_path.absolute())
    if live_path.is_symlink() or not live_path.is_file() or sha256(live_path) != source["root_live_sha256"]:
        raise AdmissionError("prepare_only_root_live_mismatch")
    live = json.loads(live_path.read_text(encoding="utf-8"))
    expected_live_identity = {"branch": source["branch"], "head": source["commit"], "tree": source["tree"]}
    if {key: live.get(key) for key in ("branch", "head", "tree")} != expected_live_identity:
        raise AdmissionError("prepare_only_root_live_identity_mismatch")
    expected_index = live.get("expected_index")
    if not isinstance(expected_index, dict) or expected_index.get("raw_diff_sha256") != raw_index_sha:
        raise AdmissionError("prepare_only_root_live_index_binding_mismatch")
    source_readback = live.get("source_readback")
    if source_readback != {"path": source["source_frame_path"], "sha256": source["source_frame_sha256"]}:
        raise AdmissionError("prepare_only_root_live_source_frame_binding_mismatch")
    frame_path = WORKSPACE / str(source["source_frame_path"])
    assert_no_symlink_components(frame_path.absolute())
    if frame_path.is_symlink() or not frame_path.is_file() or sha256(frame_path) != source["source_frame_sha256"]:
        raise AdmissionError("prepare_only_source_frame_mismatch")
    base = _require_mapping(plan.get("source_delta_base_binding"), "plan.source_delta_base_binding")
    actual_paths = subprocess.check_output(
        ["git", "-C", str(WORKSPACE), "diff", "--name-only", "--no-renames", str(base["commit"]), str(source["commit"])],
        text=True,
    ).splitlines()
    actual_paths = sorted(set(actual_paths))
    delta_path = _packet_input(source["source_delta_path"], "admission.source_delta_path")
    delta = json.loads(delta_path.read_text(encoding="utf-8"))
    if delta.get("changed_paths_from_base") != actual_paths or delta.get("changed_path_count") != len(actual_paths):
        raise AdmissionError("prepare_only_source_delta_not_current_git_denominator")
    pins = _require_sha_map(admission.get("input_pins"), "admission.input_pins")
    if set(pins) != set(_require_sha_map(plan["source_preimage_pins"], "plan.source_preimage_pins")):
        raise AdmissionError("prepare_only_input_scope_mismatch")
    for relative, expected in pins.items():
        path = WORKSPACE / relative
        assert_no_symlink_components(path.absolute())
        if path.is_symlink() or not path.is_file() or sha256(path) != expected:
            raise AdmissionError(f"prepare_only_input_pin_mismatch:{relative}")
    return {
        "branch": source["branch"],
        "commit": source["commit"],
        "tree": source["tree"],
        "root_live_sha256": sha256(live_path),
        "source_frame_path": source["source_frame_path"],
        "source_frame_sha256": sha256(frame_path),
        "raw_index_diff_sha256": raw_index_sha,
        "source_delta_path_count_recomputed": len(actual_paths),
        "input_pin_count": len(pins),
        "source_snapshot_revalidated": True,
        "product_imports_attempted": False,
        "root_guard_executed": False,
    }


def prepare_only_report(
    plan_path: Path,
    admission_path: Path,
    expected_plan_sha256: str,
    expected_admission_sha256: str,
    report_path: Path | None,
) -> int:
    plan_path = plan_path.resolve(strict=True)
    admission_path = admission_path.resolve(strict=True)
    assert_no_symlink_components(plan_path)
    assert_no_symlink_components(admission_path)
    plan, validation = load_instrument_plan(plan_path)
    static = verify_static_pins(plan, expected_plan_sha256, plan_path)
    admission = load_admission(admission_path, expected_admission_sha256, require_frozen=False)
    case_output_root_rel = validate_admission_contract(plan, admission)
    source_snapshot = verify_preparation_source_snapshot(plan, admission)
    execution = validation["execution"]
    runs_root = WORKSPACE / case_output_root_rel
    assert_no_symlink_components(runs_root)
    prepared = []
    environment = validation["environment"]
    python_path = WORKSPACE / str(environment["python_executable"])
    for case_id in validation["execution"]["order"]:
        case_row = validation["case_rows"][case_id]
        case_root = runs_root / case_id
        assert_no_symlink_components(case_root)
        if os.path.lexists(case_root):
            raise AdmissionError(f"preflight_case_output_already_exists:{case_root}")
        spec = build_case_spec(plan, case_row, case_root, python_path, validation)
        prepared.append({
            "case_id": case_id,
            "nodeid": spec["nodeid"],
            "mutation_kind": spec["mutation_kind"],
            "pytest_plugin_args": spec["pytest_plugin_args"],
            "pytest_args": spec["pytest_args"],
            "environment_overrides": spec["environment_overrides"],
            "command_argv": spec["command_argv"],
            "output_paths": {key: str(value) for key, value in spec["output_paths"].items()},
            "cwd": str(spec["cwd"]),
            "generated_launcher_sha256": hashlib.sha256(str(spec["launcher_text"]).encode()).hexdigest(),
            "generated_launcher_compiles": True,
            "generated_sandbox_sha256": hashlib.sha256(str(spec["sandbox_text"]).encode()).hexdigest(),
            "case_root_absent": True,
            "pycache_prefix_absent": not os.path.lexists(spec["pycache_prefix"]),
        })
        if os.path.lexists(spec["pycache_prefix"]):
            raise AdmissionError(f"preflight_pycache_prefix_not_absent:{case_id}")
    target = report_path or (WORKSPACE / str(execution["prepare_only_report"]))
    assert_no_symlink_components(target.absolute())
    if target.resolve().parent != PACKET.resolve():
        raise AdmissionError("preflight_report_must_be_in_packet_directory")
    report = {
        "schema": "policyos.e02.r1.r6.prepare_only_command_preflight.v1",
        "state": "PREPARATION_ONLY_OK_NOT_RUNTIME_OR_SOURCE_ADMISSION",
        "plan_path": str(plan_path.relative_to(WORKSPACE)),
        "plan_sha256": static["plan_sha256"],
        "admission_path": str(admission_path.relative_to(WORKSPACE)),
        "admission_sha256": sha256(admission_path),
        "source_binding_snapshot": admission["source_binding"],
        "source_snapshot_reconciliation": source_snapshot,
        "execution_binding": admission["execution_binding"],
        "case_output_root_absent": not os.path.lexists(runs_root),
        "validated_case_count": len(prepared),
        "case_order": [row["case_id"] for row in prepared],
        "cases": prepared,
        "pytest_invoked": False,
        "product_imports_attempted": False,
        "multiprocessing_child_started": False,
        "root_guard_executed": False,
        "resource_admission_remeasured": False,
        "launch_approval": False,
        "runtime": "UNRUN",
        "g_acceptance": False,
        "closure_ids": [],
    }
    write_json(target, report)
    print(json.dumps({"state": report["state"], "validated_case_count": len(prepared), "report": str(target.relative_to(WORKSPACE)), "report_sha256": sha256(target)}, sort_keys=True), flush=True)
    return 0

def parse_junit(path: Path) -> dict[str, object] | None:
    if not path.is_file():
        return None
    root = ET.parse(path).getroot()
    cases = list(root.iter("testcase"))
    failures = []
    errors = []
    skipped = []
    for case in cases:
        for tag, dest in (("failure", failures), ("error", errors), ("skipped", skipped)):
            node = case.find(tag)
            if node is not None:
                dest.append({
                    "testcase": case.get("classname", "") + "::" + case.get("name", ""),
                    "message": node.get("message", ""),
                    "text": node.text or "",
                })
    return {"tests": len(cases), "failures": failures, "errors": errors, "skipped": skipped}


def read_process_origins(
    case_root: Path,
    expected_product_root: Path,
    expected_python: Path,
    expected_python_version: str,
    source_blobs: dict[str, str],
    git_object_format: str,
    driver_pid: int | None,
) -> dict[str, object]:
    readset_dir = case_root / "readsets"
    errors = sorted(readset_dir.glob("readset-error-*.json"))
    driver_files = sorted(readset_dir.glob("input-readset-*.json"))
    child_files = sorted(readset_dir.glob("spawned-child-*.json"))
    if errors or len(driver_files) != 1 or len(child_files) != 1:
        raise AdmissionError("driver_or_child_readset_missing_or_ambiguous")
    driver = json.loads(driver_files[0].read_text(encoding="utf-8"))
    child = json.loads(child_files[0].read_text(encoding="utf-8"))
    if driver.get("capture_status") != "complete" or child.get("capture_status") != "complete":
        raise AdmissionError("incomplete_process_origin_readset")
    if driver.get("phase") != "pytest_driver_at_interpreter_exit" or child.get("phase") != "multiprocessing_spawn_child_before_intentional_exit":
        raise AdmissionError("process_origin_phase_mismatch")
    if driver.get("process_role") != "pytest_driver" or driver.get("driver_argv_path_match") is not True:
        raise AdmissionError("driver_exact_launcher_identity_mismatch")
    claim_path = readset_dir / "exact-driver-pid.json"
    if claim_path.is_symlink() or not claim_path.is_file():
        raise AdmissionError("exact_driver_pid_claim_missing_or_linked")
    claim = json.loads(claim_path.read_text(encoding="utf-8"))
    expected_launcher = driver.get("expected_launcher_path")
    startup_argv = driver.get("argv_at_sitecustomize_startup")
    if (
        claim.get("pid") != driver.get("pid")
        or claim.get("argv_path_match") is not True
        or claim.get("spawn_marker_present_at_sitecustomize_startup") is not False
        or not isinstance(startup_argv, list)
        or not startup_argv
        or startup_argv[0] != expected_launcher
    ):
        raise AdmissionError("exact_driver_pid_argv_claim_mismatch")
    if child.get("process_role") != "multiprocessing_spawn_child" or child.get("spawn_marker_present_at_sitecustomize_startup") is not True:
        raise AdmissionError("spawn_child_role_identity_mismatch")
    if driver.get("event_exit_code") is not None:
        raise AdmissionError("driver_readset_not_from_normal_interpreter_exit")
    if child.get("spawn_marker_present_at_sitecustomize_startup") is not True or child.get("event_exit_code") != 73:
        raise AdmissionError("spawned_child_identity_or_exit_mismatch")
    if driver.get("spawn_marker_present_at_sitecustomize_startup") is not False:
        raise AdmissionError("driver_spawn_identity_mismatch")
    if driver_pid is not None and driver.get("pid") != driver_pid:
        raise AdmissionError("mutation_log_pid_differs_from_driver")
    if not isinstance(driver.get("pid"), int) or child.get("ppid") != driver.get("pid") or child.get("pid") == driver.get("pid"):
        raise AdmissionError("spawned_process_parent_identity_mismatch")
    expected_product_root = expected_product_root.resolve()
    if Path(driver.get("project_root", "")).resolve() != expected_product_root or Path(child.get("project_root", "")).resolve() != expected_product_root:
        raise AdmissionError("process_origin_product_root_mismatch")
    for process_record in (driver, child):
        if Path(str(process_record.get("python_executable", ""))).resolve() != expected_python.resolve():
            raise AdmissionError("process_origin_python_executable_mismatch")
        if str(process_record.get("python_version", "")).split()[0] != expected_python_version:
            raise AdmissionError("process_origin_python_version_mismatch")
    required_process_origins = {
        "pytest_driver_at_interpreter_exit": {
            "tests/unit/scientist/orchestration/engine/test_engine_executor_idempotency.py",
            "tests/_helpers/process_run_lifecycle.py",
            "tests/_helpers/run_lifecycle.py",
            "src/polisyos/scientist/orchestration/engine/idempotency.py",
            "src/polisyos/scientist/orchestration/engine/executor.py",
            "src/polisyos/core/run/context.py",
        },
        "multiprocessing_spawn_child_before_intentional_exit": {
            "tests/_helpers/process_run_lifecycle.py",
            "tests/_helpers/run_lifecycle.py",
            "src/polisyos/scientist/orchestration/engine/idempotency.py",
            "src/polisyos/scientist/orchestration/engine/executor.py",
            "src/polisyos/core/run/context.py",
        },
    }
    for process_record in (driver, child):
        loaded_paths = {
            str(row.get("project_relative_path"))
            for row in process_record.get("modules", [])
            if row.get("inside_project") is True
        }
        missing = required_process_origins[str(process_record["phase"])] - loaded_paths
        if missing:
            raise AdmissionError(f"required_process_source_origins_missing:{process_record['phase']}:{sorted(missing)}")
    reconciled_origins: dict[str, dict[str, object]] = {}
    for process_record in (driver, child):
        for row in process_record.get("modules", []):
            names = row.get("module_names", [])
            first_party_name = any(
                name == root or name.startswith(root + ".")
                for name in names
                for root in ("polisyos", "tests", "tools")
            )
            if first_party_name and row.get("inside_project") is not True:
                raise AdmissionError(f"first_party_origin_outside_product_root:{row.get('origin_path')}")
            if row.get("inside_project") is True:
                relative = row.get("project_relative_path")
                if not isinstance(relative, str) or not relative.startswith(("src/polisyos/", "tests/", "tools/")):
                    if first_party_name:
                        raise AdmissionError(f"first_party_path_outside_admitted_roots:{relative}")
                    continue
                path = expected_product_root / relative
                if not path.is_file() or path.resolve() != Path(row.get("origin_path", "")).resolve():
                    raise AdmissionError(f"loaded_origin_path_mismatch:{relative}")
                repository_relative = "policy-engine/" + relative
                expected_blob = source_blobs.get(repository_relative)
                if expected_blob is None:
                    raise AdmissionError(f"loaded_origin_not_tracked_in_admitted_source_tree:{repository_relative}")
                payload = path.read_bytes()
                git_blob = hashlib.new(git_object_format, b"blob " + str(len(payload)).encode() + b"\0" + payload).hexdigest()
                if git_blob != expected_blob:
                    raise AdmissionError(f"loaded_origin_bytes_differ_from_admitted_git_tree:{repository_relative}")
                row = reconciled_origins.setdefault(
                    repository_relative,
                    {"path": repository_relative, "git_blob": expected_blob, "sha256_after_run": hashlib.sha256(payload).hexdigest(), "module_names": []},
                )
                if row["sha256_after_run"] != hashlib.sha256(payload).hexdigest():
                    raise AdmissionError(f"loaded_origin_observed_hash_disagreement:{repository_relative}")
                row["module_names"] = sorted(set(row["module_names"]) | set(names))
    return {
        "driver": {"path": str(driver_files[0].relative_to(WORKSPACE)), "sha256": sha256(driver_files[0]), "pid": driver.get("pid"), "modules": len(driver.get("modules", []))},
        "child": {"path": str(child_files[0].relative_to(WORKSPACE)), "sha256": sha256(child_files[0]), "pid": child.get("pid"), "ppid": child.get("ppid"), "modules": len(child.get("modules", []))},
        "unique_first_party_origins_reconciled_to_git_tree": len(reconciled_origins),
        "origin_reconciliation_sha256": hashlib.sha256(json.dumps([reconciled_origins[k] for k in sorted(reconciled_origins)], sort_keys=True, separators=(",", ":")).encode()).hexdigest(),
        "scope": "Finite loaded first-party Python module origins from the pytest driver and spawned producer; each path was required to be tracked under policy-engine/src/polisyos, tests, or tools and its bytes matched the admitted HEAD Git blob. This is not syscall-level file tracing or a repository-wide absence claim.",
    }


def classify_case(
    case_row: dict[str, object],
    result: dict[str, object],
    junit: dict[str, object] | None,
    origins: dict[str, object] | None,
    case_root: Path,
    environment: dict[str, object],
) -> tuple[str, list[str]]:
    reasons = []
    if result.get("complete") is not True or result.get("aborted_reason") is not None:
        return "HARNESS_ERROR", ["supervisor_incomplete_or_aborted"]
    if junit is None:
        return "HARNESS_ERROR", ["junit_missing"]
    if int(junit["tests"]) != 1:
        return "HARNESS_ERROR", ["selector_did_not_produce_exactly_one_testcase"]
    if junit["errors"]:
        return "HARNESS_ERROR", ["pytest_setup_import_or_teardown_error"]
    if origins is None:
        return "EVIDENCE_INCOMPLETE", ["driver_or_child_origin_inventory_missing"]
    runtime_profile_path = case_root / "pytest-runtime-profile.json"
    if not runtime_profile_path.is_file():
        return "HARNESS_ERROR", ["pytest_runtime_profile_missing"]
    runtime_profile = json.loads(runtime_profile_path.read_text(encoding="utf-8"))
    if (
        runtime_profile.get("schema") != "policyos.e02.r1.pytest_runtime_profile.v1"
        or runtime_profile.get("python_version") != environment["python_version"]
        or Path(str(runtime_profile.get("python_executable", ""))).resolve()
        != (WORKSPACE / str(environment["python_executable"])).resolve()
        or runtime_profile.get("pytest_version") != environment["pytest_version"]
    ):
        return "HARNESS_ERROR", ["pytest_runtime_profile_mismatch"]
    case_id = str(case_row["case_id"])
    tests = int(junit["tests"])
    failures = junit["failures"]
    errors = junit["errors"]
    skipped = junit["skipped"]
    rc = result.get("return_code")
    if case_id == "r1-cache-read-removal":
        call_log = case_root / "mutation/cache-read-calls.jsonl"
        if not call_log.is_file():
            return "HARNESS_ERROR", ["mutation_call_log_missing"]
        events = [json.loads(line) for line in call_log.read_text(encoding="utf-8").splitlines() if line.strip()]
        driver_pid = origins["driver"]["pid"]
        mutation = case_row["mutation"]
        assert isinstance(mutation, dict)
        activation = mutation["activation_check"]
        assert isinstance(activation, dict)
        expected_order = activation["event_order"]
        if len(events) != activation["event_count"] or any(e.get("pid") != driver_pid for e in events):
            return "HARNESS_ERROR", ["mutation_event_scope_or_count_mismatch"]
        forced = [e for e in events if e.get("event") == expected_order[1] and e.get("pid") == driver_pid and e.get("returned") is activation["forced_miss_returned"]]
        installed = [e for e in events if e.get("event") == expected_order[0] and e.get("pid") == driver_pid]
        restored = [e for e in events if e.get("event") == expected_order[2] and e.get("pid") == driver_pid and e.get("restored") is activation["restore_success"]]
        plugin_loaded = any(row.get("name") == mutation["plugin_module"] for row in runtime_profile.get("plugins", []))
        forced_keys = [e.get("key") for e in forced]
        event_order = [e.get("event") for e in events]
        if len(forced) != activation["forced_miss_count"] or (activation["nonempty_cache_key"] and (not forced_keys or not isinstance(forced_keys[0], str) or not forced_keys[0])) or len(installed) != 1 or len(restored) != 1 or (activation["plugin_must_be_loaded"] and not plugin_loaded) or event_order != expected_order:
            return "HARNESS_ERROR", ["mutation_not_reached_or_reader_not_restored"]
        failure_text = "\n".join(str(x.get("text", "")) + str(x.get("message", "")) for x in failures)
        target_failure = (
            "test_engine_executor_idempotency.py:541" in failure_text
            and "CachedCounterNode.calls == 0" in failure_text
            and "assert 1 == 0" in failure_text
        )
        if tests == 1 and len(failures) == 1 and not errors and not skipped and rc == 1 and target_failure:
            return "EXPECTED_RED", ["receiver_cache_read_removed_and_no_recompute_assertion_failed"]
        return "TEST_FAIL_UNCLASSIFIED", ["removal_result_did_not_match_exact_expected_red"]
    if any(row.get("name") == "remove_cache_read_plugin" for row in runtime_profile.get("plugins", [])):
        return "HARNESS_ERROR", ["removal_plugin_loaded_outside_control_case"]
    if tests == 1 and not failures and not errors and not skipped and rc == 0:
        return "PASS", ["current_source_positive_replay"]
    if errors or failures or skipped:
        return "TEST_FAIL", ["positive_or_restored_selector_failed"]
    return "HARNESS_ERROR", ["unexpected_pytest_exit_or_junit_shape"]


def admit_case_wave(
    plan: dict[str, object],
    plan_path: Path,
    plan_sha256: str,
    admission: dict[str, object],
    admission_path: Path,
    case_id: str,
    runs_root: Path,
) -> None:
    """Create or validate one unique wave binding and enforce ordered no-retry cases."""
    order = list(plan["execution"]["order"])
    if case_id not in order:
        raise AdmissionError("case_not_in_admitted_wave_order")
    index = order.index(case_id)
    source = _require_mapping(admission.get("source_binding"), "admission.source_binding")
    execution_binding = _require_mapping(admission.get("execution_binding"), "admission.execution_binding")
    expected = {
        "schema": "policyos.e02.r1.r6.case_wave_binding.v1",
        "wave_id": execution_binding["wave_id"],
        "case_output_root": execution_binding["case_output_root"],
        "plan_path": str(plan_path.relative_to(WORKSPACE)),
        "plan_sha256": plan_sha256,
        "admission_path": str(admission_path.relative_to(WORKSPACE)),
        "admission_sha256": sha256(admission_path),
        "source": {key: source[key] for key in ("branch", "commit", "tree")},
        "case_order": order,
        "g_acceptance": False,
        "closure_ids": [],
    }
    assert_no_symlink_components(runs_root.absolute())
    wave_path = runs_root / "wave-binding.json"
    if not runs_root.exists():
        if index != 0:
            raise AdmissionError("wave_must_start_with_positive_case")
        runs_root.mkdir(parents=True, exist_ok=False)
        write_json(wave_path, expected)
        return
    if runs_root.is_symlink() or not runs_root.is_dir():
        raise AdmissionError("admitted_wave_root_must_be_regular_directory")
    assert_no_symlink_components(wave_path.absolute())
    if wave_path.is_symlink() or not wave_path.is_file():
        raise AdmissionError("admitted_wave_binding_missing_or_linked")
    if json.loads(wave_path.read_text(encoding="utf-8")) != expected:
        raise AdmissionError("admitted_wave_binding_identity_mismatch")
    if index == 0:
        raise AdmissionError("positive_case_wave_root_already_used; choose_a_new_wave_id")
    required_prior = {order[0]: "PASS"}
    if index >= 2:
        required_prior[order[1]] = "EXPECTED_RED"
    for prior_case_id, expected_classification in required_prior.items():
        prior_audit = runs_root / prior_case_id / str(plan["harness_contract"]["output_files"]["audit_result"])
        assert_no_symlink_components(prior_audit.absolute())
        if prior_audit.is_symlink() or not prior_audit.is_file():
            raise AdmissionError(f"prior_case_audit_missing_or_linked:{prior_case_id}")
        prior = json.loads(prior_audit.read_text(encoding="utf-8"))
        if (
            prior.get("case_id") != prior_case_id
            or prior.get("classification") != expected_classification
            or prior.get("plan_sha256") != plan_sha256
            or prior.get("admission_sha256") != sha256(admission_path)
            or prior.get("g_acceptance") is not False
            or prior.get("closure_ids") != []
        ):
            raise AdmissionError(f"prior_case_outcome_does_not_admit_next_case:{prior_case_id}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", required=True, type=Path)
    parser.add_argument("--expected-plan-sha256", required=True)
    parser.add_argument("--admission", required=True, type=Path)
    parser.add_argument("--expected-admission-sha256", required=True)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--case", choices=("r1-current-positive", "r1-cache-read-removal", "r1-current-restored"))
    mode.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    case_root: Path | None = None
    try:
        assert_no_symlink_components(args.plan.absolute())
        assert_no_symlink_components(args.admission.absolute())
        plan_path = args.plan.resolve(strict=True)
        if args.prepare_only:
            return prepare_only_report(
                plan_path,
                args.admission,
                args.expected_plan_sha256,
                args.expected_admission_sha256,
                args.report,
            )
        assert args.case is not None
        plan, case_row, validation = load_case_plan(plan_path, args.case)
        static_admission = verify_static_pins(plan, args.expected_plan_sha256, plan_path)
        admission_path = args.admission.resolve(strict=True)
        admission = load_admission(admission_path, args.expected_admission_sha256, require_frozen=True)
        case_output_root_rel = validate_admission_contract(plan, admission)
        environment = plan["environment"]
        assert isinstance(environment, dict)
        os.environ["PATH"] = str(environment["controller_path"])
        python_path = WORKSPACE / str(environment["python_executable"])
        if not python_path.is_file() or sha256(python_path) != environment["python_executable_sha256"]:
            raise AdmissionError("python_executable_pin_mismatch")
        helper_bundle = runpy.run_path(str(ROOT_LAYER))
        guard = helper_bundle["guard"]
        source_admission = verify_source_and_inputs(plan, admission, guard)
        source_blobs, git_object_format = git_source_blob_map()
        source = admission["source_binding"]
        assert isinstance(source, dict)
        if git_object_format != environment["git_object_format"] or git_object_format != source["git_object_format"]:
            raise AdmissionError("git_object_format_mismatch")
        source_admission["git_source_blob_count"] = len(source_blobs)
        source_admission["git_object_format"] = git_object_format
        source_admission["git_source_blob_map_sha256"] = hashlib.sha256(
            json.dumps(source_blobs, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest()
        resources = resource_snapshot(plan)

        output_spec = validation["execution"]
        harness = validation["harness"]
        runs_root = WORKSPACE / case_output_root_rel
        case_root = runs_root / str(case_row["case_id"])
        admit_case_wave(
            plan,
            plan_path,
            static_admission["plan_sha256"],
            admission,
            admission_path,
            str(case_row["case_id"]),
            runs_root,
        )
        assert_no_symlink_components(runs_root)
        assert_no_symlink_components(case_root)
        if os.path.lexists(case_root):
            raise AdmissionError(f"case_output_already_exists:{case_root}")
        spec = build_case_spec(plan, case_row, case_root, python_path, validation)
        case_root.mkdir(parents=True, exist_ok=False)
        for name in spec["case_directories"]:
            (case_root / str(name)).mkdir()
        mutation = case_row["mutation"]
        assert isinstance(mutation, dict)
        if mutation["kind"] != "none":
            (case_root / str(spec["mutation_directory_name"])).mkdir()
        pycache_prefix = spec["pycache_prefix"]
        assert isinstance(pycache_prefix, Path)
        if os.path.lexists(pycache_prefix):
            raise AdmissionError("private_pycache_prefix_not_absent")
        sys.pycache_prefix = str(pycache_prefix)

        sitecustomize = spec["sitecustomize_path"]
        plugin = spec["plugin_path"]
        launcher = spec["launcher_path"]
        launcher_text = str(spec["launcher_text"])
        sandbox = spec["sandbox_path"]
        sandbox_text = str(spec["sandbox_text"])
        env = spec["environment_overrides"]
        argv = spec["command_argv"]
        assert isinstance(launcher, Path) and isinstance(sandbox, Path)
        assert isinstance(sitecustomize, Path) and isinstance(plugin, Path)
        assert isinstance(env, dict) and isinstance(argv, list)
        launcher.write_text(launcher_text, encoding="utf-8")
        sandbox.write_text(sandbox_text, encoding="utf-8")

        supervisor_spec = importlib.util.spec_from_file_location("r1_retained_supervisor", str(SUPERVISOR))
        if supervisor_spec is None or supervisor_spec.loader is None:
            raise AdmissionError("retained_supervisor_import_spec_unavailable")
        supervisor = importlib.util.module_from_spec(supervisor_spec)
        sys.modules[supervisor_spec.name] = supervisor
        supervisor_spec.loader.exec_module(supervisor)
        limits = plan["resource_admission"]
        assert isinstance(limits, dict)
        if supervisor.NUMERIC_THREADS != validation["environment"]["numeric_thread_overrides"]:
            raise AdmissionError("retained_supervisor_numeric_thread_contract_mismatch")
        supervisor.RSS_CAP_BYTES = int(limits["sampled_process_tree_rss_cap_bytes"])
        supervisor.DISK_FLOOR_BYTES = int(limits["supervisor_disk_stop_floor_bytes"])
        supervisor.SAMPLE_SECONDS = float(limits["sample_interval_seconds"])
        signal.signal(signal.SIGTERM, supervisor.note_stop_signal)
        signal.signal(signal.SIGINT, supervisor.note_stop_signal)

        source_profile = {
            "schema": "policyos.e02.r1.current_source_native_case_freeze.v1",
            "state": "FROZEN_BEFORE_SINGLE_CASE; NOT_G_ACCEPTANCE",
            "case_id": case_row["case_id"],
            "plan_path": str(plan_path.relative_to(WORKSPACE)),
            "plan_sha256": static_admission["plan_sha256"],
            "admission_path": str(admission_path.relative_to(WORKSPACE)),
            "admission_sha256": sha256(admission_path),
            "source_admission": source_admission,
            "resource_admission": resources,
            "selected_case": case_row,
            "current_sitecustomize": {"path": str(sitecustomize.relative_to(WORKSPACE)), "sha256": sha256(sitecustomize)},
            "current_removal_plugin": {"path": str(plugin.relative_to(WORKSPACE)), "sha256": sha256(plugin)},
            "fresh_launcher": {"path": str(launcher.relative_to(WORKSPACE)), "sha256": sha256(launcher), "source": launcher_text},
            "sandbox": {"path": str(sandbox.relative_to(WORKSPACE)), "sha256": sha256(sandbox), "text": sandbox_text},
            "environment_overrides_only": env,
            "ambient_environment_policy": "host environment is temporarily reduced to PATH and locale for the supervisor spawn; child gets only the recorded env plus supervisor numeric thread caps; no credentials are forwarded",
            "argv": argv,
            "cwd": str(PRODUCT),
            "python_profile": {
                "retained_interpreter": str(environment["python_executable"]),
                "resolved_interpreter": str(python_path.resolve()),
                "python_version": environment["python_version"],
                "pytest_version_expected_and_checked_in_process": environment["pytest_version"],
                "uv_version_from_retained_pyvenv_cfg": environment["uv_version"],
                "pytest_ini": "policy-engine/pytest.ini at admitted source bytes",
                "bytecode_policy": "-B + PYTHONDONTWRITEBYTECODE=1 + unique absent case-local PYTHONPYCACHEPREFIX; verify prefix remains absent",
            },
            "closure_ids": [],
        }
        write_json(case_root / str(harness["output_files"]["source_profile"]), source_profile)

        overall_start = time.monotonic()
        deadline = overall_start + float(limits["wall_limit_seconds_per_case"])
        old_env = os.environ.copy()
        try:
            os.environ.clear()
            os.environ.update({k: v for k, v in env.items() if k in {"PATH", "LANG", "LC_ALL", "LC_CTYPE"}})
            result = supervisor.run_command(
                case_root,
                str(case_row["case_id"]),
                argv,
                PRODUCT,
                overall_start,
                deadline,
                env,
            )
        finally:
            os.environ.clear()
            os.environ.update(old_env)

        junit = parse_junit(case_root / str(harness["output_files"]["junit"]))
        origins = None
        origin_error = None
        try:
            origins = read_process_origins(
                case_root,
                PRODUCT,
                python_path.resolve(),
                str(environment["python_version"]),
                source_blobs,
                git_object_format,
                None,
            )
        except Exception as exc:  # evidence is preserved and classified, never retried here
            origin_error = {"type": type(exc).__name__, "message": str(exc)}
        classification, reasons = classify_case(case_row, result, junit, origins, case_root, environment)
        post_admission_error = None
        try:
            verify_static_pins(plan, args.expected_plan_sha256, plan_path)
            load_admission(admission_path, args.expected_admission_sha256)
            post = verify_source_and_inputs(plan, admission, guard)
        except Exception as exc:
            post = None
            post_admission_error = {"type": type(exc).__name__, "message": str(exc)}
            classification = "HARNESS_ERROR"
            reasons.append("post_run_source_or_input_reconciliation_failed")
        if os.path.lexists(pycache_prefix):
            classification = "HARNESS_ERROR"
            reasons.append("unexpected_private_pycache_prefix_created")
        outputs = []
        basetemp = case_root / str(harness["case_directory_names"][-1])
        for path in sorted(case_root.rglob("*")):
            if path.is_symlink():
                link = classify_case_symlink(path, case_root, basetemp)
                outputs.append({"kind": "symlink", **link})
                if link.get("allowed") is not True:
                    classification = "HARNESS_ERROR"
                    reasons.append("case_output_symlink_invalid")
            elif path.is_file() and path.name != "audit-result.json":
                outputs.append({"kind": "file", "path": str(path.relative_to(WORKSPACE)), "size_bytes": path.stat().st_size, "sha256": sha256(path)})
        audit = {
            "schema": "policyos.e02.r1.current_source_native_case_result.v1",
            "classification": classification,
            "reasons": reasons,
            "case_id": case_row["case_id"],
            "source_profile_freeze_sha256": sha256(case_root / "source-profile-freeze.json"),
            "plan_sha256": static_admission["plan_sha256"],
            "admission_sha256": sha256(admission_path),
            "supervisor_result": result,
            "junit": junit,
            "process_origins": origins,
            "origin_error": origin_error,
            "post_run_source_reconciliation": post,
            "post_run_source_reconciliation_error": post_admission_error,
            "outputs": outputs,
            "g_acceptance": False,
            "closure_ids": [],
            "limitations": ["one exact R1 selector only", "not the 13-contour R1 task completion", "no G acceptance or formal closure"],
        }
        audit_path = case_root / str(harness["output_files"]["audit_result"])
        write_json(audit_path, audit)
        print(json.dumps({"case_id": case_row["case_id"], "classification": classification, "junit": junit, "audit_sha256": sha256(audit_path)}, sort_keys=True), flush=True)
        return 0 if classification in {"PASS", "EXPECTED_RED"} else 1
    except Exception as exc:
        if case_root is not None and case_root.is_dir() and not (case_root / "runner-error.json").exists():
            try:
                write_json(case_root / "runner-error.json", {"classification": "HARNESS_ERROR", "error_type": type(exc).__name__, "error": str(exc), "traceback": traceback.format_exc(), "closure_ids": []})
            except Exception:
                pass
        print(json.dumps({"classification": "HARNESS_ERROR", "error_type": type(exc).__name__, "error": str(exc)}, sort_keys=True), file=sys.stderr, flush=True)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
