from pathlib import Path
R=Path(__file__).resolve().parent/'postimages'
p=R/'policy-engine/tests/unit/runtime/http/test_search_hte_first_assessment_outbox.py';s=p.read_text()
s=s.replace('    include_assignment_edge: bool = True,\n) -> tuple[ArtifactRef, ArtifactRef, ArtifactRef]:','    include_assignment_edge: bool = True,\n    projection_fault: str | None = None,\n    alternate_unit_scope_profile: bool = False,\n) -> tuple[ArtifactRef, ArtifactRef, ArtifactRef]:',1)
start=s.index('        for role, variable_id, _raw_field, _unit in variables:\n')
end=s.index('            profile_ref = put_selected(\n',start)
s=s[:start]+'''        for role, variable_id, _raw_field, _unit in variables:
            projection = fixture.projections[variable_id]
            profile = gc._load_value_data_profile_from_l1_dcat(
                repo_root=fixture.repo_root,
                outcome=variable_id,
                owner_access_ref=f"fixture:{run_id}:{variable_id}",
                overlay_path=fixture.overlay_path,
                artifact_store=store,
                activated_observation_projection=projection,
            )
            assert profile is not None
            if role == "outcome" and projection_fault is not None:
                from polisyos.fabric.data_plane import content_sha256

                # Start with a genuinely loaded profile. The following cases
                # deliberately alter only the selected candidate CAS snapshot;
                # they do not claim that the catalog owner issued that view.
                projection_payload = projection.model_dump(
                    mode="json", exclude={"projection_content_sha256"}
                )
                projected_rows = projection_payload["observations"]
                if projection_fault == "trimmed-unit":
                    for projected_row in projected_rows:
                        observation = projected_row["observation"]
                        observation["condition_json"] = json.dumps({"unit": " m "})
                        projected_row["row_content_sha256"] = content_sha256(observation)
                else:
                    first_observation = projected_rows[0]["observation"]
                    duplicate = dict(first_observation)
                    duplicate["observation_id"] += ":duplicate-cell"
                    if projection_fault == "mixed-units":
                        duplicate["condition_json"] = json.dumps({"unit": "cm"})
                    elif projection_fault != "duplicate-cell":
                        raise AssertionError(f"unknown projection fault: {projection_fault}")
                    projected_rows.append(
                        {
                            "observation": duplicate,
                            "row_content_sha256": content_sha256(duplicate),
                        }
                    )
                    if projection_fault == "duplicate-cell":
                        # Construct the concrete self-consistent mean witness
                        # from the review, bypassing owner admission on purpose.
                        # Both values are equal, so their mean and the native HTE
                        # arrays stay unchanged; only the two source hashes vary.
                        source_members = sorted(
                            (first_observation, duplicate),
                            key=lambda item: (
                                item["dataset_id"], item["observation_id"], item["value"]
                            ),
                        )
                        source_hashes = tuple(
                            gc.gy_content_hash(
                                {
                                    "outcome": variable_id,
                                    "unit_id": first_observation["country_code"],
                                    "period_id": first_observation["year"],
                                    "value": item["value"],
                                    "dataset_id": item["dataset_id"],
                                    "observation_id": item["observation_id"],
                                    "measurement_unit": profile.measurement_unit,
                                }
                            )
                            for item in source_members
                        )
                        row_payload = {
                            "unit_id": first_observation["country_code"],
                            "period_id": first_observation["year"],
                            "outcome_value": first_observation["value"],
                            "measurement_unit": profile.measurement_unit,
                            "source_row_content_hashes": source_hashes,
                        }
                        counterfeit_row = gc.ValueOwnerRow(
                            **row_payload, row_content_hash=gc.gy_content_hash(row_payload)
                        )
                        profile_rows = tuple(
                            counterfeit_row
                            if (row.unit_id, row.period_id)
                            == (counterfeit_row.unit_id, counterfeit_row.period_id)
                            else row
                            for row in profile.rows
                        )
                        profile_payload = profile.model_dump(
                            mode="json", exclude={"content_hash"}
                        )
                        profile_payload["rows"] = [
                            row.model_dump(mode="json") for row in profile_rows
                        ]
                        profile_payload["owner_rows_content_hash"] = gc.gy_content_hash(
                            tuple(row.model_dump(mode="json") for row in profile_rows)
                        )
                        profile = gc.ValueDataProfile.model_validate(
                            {
                                **profile_payload,
                                "content_hash": gc.gy_content_hash(profile_payload),
                            }
                        )
                projection = type(projection).model_validate(
                    {
                        **projection_payload,
                        "projection_content_sha256": content_sha256(projection_payload),
                    }
                )
            projection_ref = put_selected(
                projection.model_dump(mode="json"),
                kind="runtime.value_owner_source_projection",
                schema_name="runtime.value_owner_source_projection.v1",
                schema_version="1.0",
            )
'''+s[end:]
s=s.replace('    return source_ref, assignment_ref, profile_refs["outcome.effect"]\n\ndef _put_v2_hte_source(','''    unit_scope_ref = profile_refs["outcome.effect"]
    if alternate_unit_scope_profile:
        # The same profile payload has a second genuinely persisted manifest
        # view. Keeping its artifact ID cannot rescue the selected-view mismatch.
        unit_scope_ref = put_selected(
            outcome_profile.model_dump(mode="json"),
            kind="runtime.value_data_profile",
            schema_name="runtime.value_data_profile.v2",
            schema_version="2.0",
            inputs=[],
        )
        assert unit_scope_ref.artifact_id == profile_refs["outcome.effect"].artifact_id
        assert (
            unit_scope_ref.manifest_profile_sha256
            != profile_refs["outcome.effect"].manifest_profile_sha256
        )
    return source_ref, assignment_ref, unit_scope_ref


def _put_v2_hte_source(''',1)
s=s.replace('    ["raw", "joined", "assignment-edge-removed"],\n    ids=["raw-unit-unknown", "selected-source-unit", "edge-removed-markers-retained"],','''    [
        "raw",
        "joined",
        "assignment-edge-removed",
        "duplicate-cell",
        "mixed-units",
        "trimmed-unit",
        "alternate-profile",
    ],
    ids=[
        "raw-unit-unknown",
        "selected-source-unit",
        "edge-removed-markers-retained",
        "ambiguous-cell-self-consistent-mean",
        "source-refusal-retains-native-interval",
        "canonical-declared-unit-normalization",
        "same-payload-other-selected-profile",
    ],''',1)
s=s.replace('                include_assignment_edge=source_mode == "joined",','''                include_assignment_edge=source_mode != "assignment-edge-removed",
                projection_fault=(
                    source_mode
                    if source_mode in {"duplicate-cell", "mixed-units", "trimmed-unit"}
                    else None
                ),
                alternate_unit_scope_profile=source_mode == "alternate-profile",''',1)
s=s.replace('    if source_mode == "joined":\n        assert first_assessment.routing_score.status', '''    assert first_assessment.theta != 0.0
    assert first_assessment.lower_bound is not None
    assert first_assessment.upper_bound is not None
    assert "source_owner_issuance_not_established" in first_assessment.limitations
    if source_mode in {"joined", "trimmed-unit"}:
        assert first_assessment.routing_score.status''',1)
anchor='''    else:
        assert first_assessment.routing_score.status == "unavailable"
        assert first_assessment.routing_score.unavailable_reason == "unit_not_bound"
    assert first_assessment.obligation_id'''
assert s.count(anchor)==1
s=s.replace(anchor,'''    elif source_mode in {"duplicate-cell", "mixed-units", "alternate-profile"}:
        assert first_assessment.routing_score.status == "unavailable"
        assert first_assessment.routing_score.unavailable_reason == "scope_not_comparable"
        assert "source_variable_to_array_mapping_not_established" in first_assessment.limitations
        expected_refusal = (
            "source_unit_scope_profile_mismatch"
            if source_mode == "alternate-profile"
            else "acquire_data:value_owner_unit_binding_ambiguous"
        )
        assert (
            f"source_variable_to_array_join_refused:{expected_refusal}"
            in first_assessment.limitations
        )
    else:
        assert first_assessment.routing_score.status == "unavailable"
        assert first_assessment.routing_score.unavailable_reason == "unit_not_bound"
    assert first_assessment.obligation_id''',1)
p.write_text(s)
