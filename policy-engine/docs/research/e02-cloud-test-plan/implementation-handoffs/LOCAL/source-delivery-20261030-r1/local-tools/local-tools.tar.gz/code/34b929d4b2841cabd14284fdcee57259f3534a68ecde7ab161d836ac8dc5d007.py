"""Bind the single observed POST and every frozen pre/postimage without replay."""
from pathlib import Path
import hashlib, json, subprocess
P=Path(__file__).resolve().parent; R=P.parents[4]
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def artifact(name):
 p=P/name
 return {'path':str(p),'sha256':digest(p),'bytes':p.stat().st_size}
def git(*args): return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
frozen=json.loads((P/'pre-freeze.json').read_text()); post=json.loads((P/'post-and-controls-r1.stdout.json').read_text()); cmd=json.loads((P/'post-and-controls-r1.command-result.json').read_text()); reads=json.loads((P/'post-and-controls-r1.input-reads.json').read_text()); pre=json.loads((P/'pre-witness-r1.stdout.json').read_text())
assert git('rev-parse','HEAD')==frozen['source']['head'] and git('rev-parse','HEAD^{tree}')==frozen['source']['tree'] and git('symbolic-ref','--short','HEAD')==frozen['source']['branch']
for f in frozen['files']:
 assert digest(Path(f['postimage_path']))==f['postimage_sha256']
 if f['preimage_path']:
  assert digest(Path(f['preimage_path']))==f['preimage_sha256']
  assert digest(R/f['path'])==f['preimage_sha256']
 else: assert not (R/f['path']).exists()
assert digest(P/'proposal.patch')==frozen['patch_sha256']
assert digest(P/'post_and_controls.py')==frozen['runner_sha256'] and digest(P/'supervise_post_and_controls.py')==frozen['supervisor_sha256']
assert post['owner_sha256']==frozen['files'][0]['postimage_sha256'] and post['new_tests_sha256']==frozen['files'][1]['postimage_sha256']
assert post['pre_stdout_sha256']==digest(P/'pre-witness-r1.stdout.json')
assert len(post['controls'])==94 and len(post['witnesses'])==17 and len(post['removals'])==2
assert cmd['exit_code']==1 and cmd['abort'] is None and cmd['peak_sampled_child_rss_bytes']<=536870912 and cmd['elapsed_seconds']<=120
assert not post['product_imports'] and not post['blocked_product_import_attempts']
assert all(row['status']=='PASS' for row in post['controls']+post['removals'])
failures=[row for row in post['witnesses'] if row['status']!='PASS']; assert len(failures)==1 and failures[0]['case']=='witness:builtins-bool'
paired=[]
for row in pre['rows']:
 matching=next(x for x in post['witnesses'] if x.get('paired_pre')==row['case'])
 paired.append({'case':row['case'],'source_sha256':row['source_sha256'],'pre_outcome':row['outcome'],'pre_entries':row['entries'],'post_status':matching['status'],'post_observation':json.loads(matching['stdout'])})
manifest={'schema':'raw-dynamic-native-compatibility-r12-v1','state':'HOLD: RAW proposal only, canonical unapplied; one witness assertion FAIL','capability_label':'verification_missing','source':frozen['source'],'files':frozen['files'],'patch':artifact('proposal.patch'),'pre_freeze':artifact('pre-freeze.json'),'pre_witness':artifact('pre-witness-r1.stdout.json'),'post_stdout':artifact('post-and-controls-r1.stdout.json'),'post_stderr':artifact('post-and-controls-r1.stderr.txt'),'post_command':artifact('post-and-controls-r1.command-result.json'),'post_input_reads':artifact('post-and-controls-r1.input-reads.json'),'readset_scope':reads['scope'],'observed_regular_file_path_and_sha_pairs':len(reads['reads']),'read_errors':reads['read_errors'],'result':{'exit_code':cmd['exit_code'],'abort':cmd['abort'],'wall_seconds':cmd['elapsed_seconds'],'peak_sampled_child_rss_bytes':cmd['peak_sampled_child_rss_bytes'],'paired':paired,'new_witnesses':{'pass':16,'fail':1,'total':17,'failed_case':failures[0]['case'],'expected':failures[0]['expected'],'observed_exception':failures[0]['error'],'classification':'Assertion expected only implicit-dispatch wording; actual collector refused with opaque callable dispatch. The assertion and run remain FAIL; no diagnostic reclassification to PASS.'},'semantic_removals':{'pass':2,'fail':0,'total':2},'existing_r11_source_tool_controls':{'pass':94,'fail':0,'total':94,'composition':'12 legacy controls + 78 frozen R11 CASES + 4 R11 semantic-removal controls'},'product_imports':post['product_imports'],'blocked_product_import_attempts':post['blocked_product_import_attempts']},'static_checks':frozen['checks'],'prior_evidence':{'r11_manifest_sha256':frozen['r11_manifest_sha256'],'r11_applied':False,'r107_full_native':'560 cases, 469 PASS, 91 FAIL on its recorded source; not R12 verification','r11_legacy_86':'informational only; crossed no-product-import boundary; not native PASS'},'unresolved_by_construction':['full native suite and actual source-wide collection were not run','ordinary Python object lifetimes and finalizers','ambient concurrency and arbitrary external protocol or executor behavior','C-level reads, environment, network and directory enumeration in the read receipt','P41 attribution and G acceptance'], 'semantic_scope':'R12 is a bounded source-analysis proposal; no arbitrary Python equivalence, native clearance, or closure is claimed.'}
(P/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'manifest_sha256':digest(P/'manifest.json'),'patch_sha256':manifest['patch']['sha256'],'owner_sha256':frozen['files'][0]['postimage_sha256'],'result':'HOLD, 16/17 witnesses, 2/2 removals, 94/94 controls'}))
