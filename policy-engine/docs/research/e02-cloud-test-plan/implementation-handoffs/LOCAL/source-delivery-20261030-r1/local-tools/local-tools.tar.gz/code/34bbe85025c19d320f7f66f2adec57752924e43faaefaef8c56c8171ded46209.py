"""Exercise the actual RAW tool postimage with fixture-selected collector inputs."""
from __future__ import annotations
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import resource
import signal
import subprocess
import sys
import time
import traceback

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
PRODUCT = ROOT / 'policy-engine'
PACKET = Path(__file__).resolve().parent
RUN = PACKET/'fixtures'/sys.argv[1]
signal.alarm(110)
sys.path.insert(0, str(PRODUCT))

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

readset = [PRODUCT/'tools/quality/validation/decomposition_preflight.py', PRODUCT/'tests/repo_quality/architecture/test_decomposition_preflight_gates.py', PRODUCT/'architecture/imports/dynamic.toml', PRODUCT/'src/polisyos/runtime/http/resilience.py']
pre = {str(p.relative_to(ROOT)):sha(p) for p in readset}
head = subprocess.check_output(['git','rev-parse','HEAD','HEAD^{tree}'],cwd=ROOT,text=True).splitlines()
tests = load('r9_tests', PACKET/'candidate/policy-engine/tests/repo_quality/architecture/test_dynamic_code_reconstitution.py')
canonical = tests.preflight
candidate_path = PACKET/'candidate/policy-engine/tools/quality/validation/decomposition_preflight.py'
assert ast.parse(candidate_path.read_text())
candidate = load('r9_candidate', candidate_path)
result = {'head_tree_before':head,'readset_preimage':pre,'origins':{'canonical':str(Path(canonical.__file__).resolve()),'candidate':str(Path(candidate.__file__).resolve())},'owner_sha256':{'canonical':sha(Path(canonical.__file__)),'candidate':sha(candidate_path)},'rows':[],'product_imports':[]}
for mode, owner in [('canonical',canonical),('candidate',candidate)]:
    tests.preflight = owner
    names = ['noop','callback','class-method'] if mode == 'canonical' else list(tests.CASES)
    for name in names:
        source, expected, refusal = tests.CASES[name]
        row = {'mode':mode,'case':name,'fixture_root':str(RUN/mode/name),'fixture_source_sha256':hashlib.sha256(source.encode()).hexdigest(),'expected_patterns':sorted(expected) if expected is not None else None,'expected_refusal':refusal}
        try:
            entries=tests.collect_case(RUN/mode/name,source)
        except Exception as error:
            row.update(status='refused',error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc())
            row['property_pass'] = isinstance(error,owner.DynamicImportCollectionError) and refusal is not None and re.search(refusal,str(error)) is not None
        else:
            row.update(status='collected',entries=entries)
            locations = {node.lineno for node in ast.walk(ast.parse(source)) if isinstance(node,ast.Call) and node.args and isinstance(node.args[0],ast.Constant) and node.args[0].value in (expected or set())}
            row['property_pass'] = refusal is None and {e['pattern'] for e in entries} == expected and all(e['source_file']=='src/polisyos/bridge.py' and e['line'] in locations and e['call'] in {'importlib.import_module','__import__'} for e in entries)
        result['rows'].append(row)
# Execute the projected semantic removal/restoration test through its actual callable.
tests.preflight = candidate
with tests.pytest.MonkeyPatch.context() as patch:
    tests.test_dynamic_code_invocation_removal_is_semantic(RUN/'removal', patch)
with tests.pytest.MonkeyPatch.context() as patch:
    tests.test_dynamic_code_join_provenance_removal_is_semantic(RUN/'provenance-removal', patch)
result['provenance_removal_test'] = {'status':'PASS','method':'single join-helper removal retains the constructor-normalized guarded-unknown backstop; exact helper identity and refusal restore; not whole-property removal'}
with tests.pytest.MonkeyPatch.context() as patch:
    tests.test_dynamic_code_normalization_removal_is_semantic(RUN/'normalization-removal', patch)
result['normalization_removal_test'] = {'status':'PASS','method':'disabled only canonical constructor normalizer; identical match source becomes successful-empty despite retained fields/markers; exact method identity and refusal restore'}
result['removal_test'] = {'status':'PASS','method':'actual projected test callable; only reconstructed/source_closure invocation transfer replaced with _DYNAMIC_OTHER; full source unchanged; restored exact method identity and inventory'}
# Existing R3 canonical eleven-case cohort: full functions, actual RAW candidate owner.
legacy = load('r9_existing_tests', PRODUCT/'tests/repo_quality/architecture/test_decomposition_preflight_gates.py')
legacy.preflight = candidate
result['existing_cohort'] = []
positive = legacy.test_dynamic_deferred_escaped_class_keeps_known_inventory_without_field_authority
negative = legacy.test_dynamic_deferred_escaped_class_refuses_changed_importer_and_removal
cohort = [(positive.__name__, positive, {})]
marks = {mark.args[0]:mark.args[1] for mark in negative.pytestmark if mark.name=='parametrize'}
for changed_root in marks['changed_root']:
    for index, (class_declarations,escaped_class) in enumerate(marks[('class_declarations','escaped_class')]):
        cohort.append((f'{negative.__name__}[{changed_root}-{index}]',negative,dict(changed_root=changed_root,class_declarations=class_declarations,escaped_class=escaped_class)))
for index, (name,function,kwargs) in enumerate(cohort):
    fixture=RUN/'existing-cohort'/str(index)
    fixture.mkdir(parents=True,exist_ok=True)
    try:
        with tests.pytest.MonkeyPatch.context() as patch:
            function(fixture, patch, **kwargs)
    except Exception as error:
        result['existing_cohort'].append({'case':name,'status':'FAIL','error':str(error),'traceback':traceback.format_exc()})
    else:
        result['existing_cohort'].append({'case':name,'status':'PASS'})
result['existing_cohort_test_origin'] = str(Path(legacy.__file__).resolve())
result['existing_cohort_test_sha256'] = sha(Path(legacy.__file__))
result.update(readset_postimage={str(p.relative_to(ROOT)):sha(p) for p in readset},head_tree_after=subprocess.check_output(['git','rev-parse','HEAD','HEAD^{tree}'],cwd=ROOT,text=True).splitlines(),product_imports=sorted(name for name in sys.modules if name=='polisyos' or name.startswith('polisyos.')),ru_maxrss_platform_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
print(json.dumps(result,indent=2,sort_keys=True))
raise SystemExit(0 if all(r['property_pass'] for r in result['rows'] if r['mode']=='candidate') and all(r['status']=='PASS' for r in result['existing_cohort']) else 1)
