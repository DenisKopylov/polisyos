from pathlib import Path
import ast, subprocess, hashlib, json, difflib, tomllib
root=Path.cwd(); raw=root/'LOCAL/raw/e02-execution-20261027/repairs/q1-inspection-consumer-r2'; base=raw/'postimages'; files=[];checks=[];diffs=[]
for p in sorted(base.rglob('*')):
 if not p.is_file(): continue
 rel=p.relative_to(base); original=root/rel; prior=original.read_bytes() if original.exists() else b''
 if p.suffix=='.py':
  logical=str(rel.relative_to('policy-engine'))
  result=subprocess.run(['.venv/bin/python','-m','ruff','format','--config','ruff.toml','--stdin-filename',logical,'-'],cwd='policy-engine',input=p.read_bytes(),capture_output=True,check=True);p.write_bytes(result.stdout)
  post=p.read_bytes();ast.parse(post,filename=logical)
  check=subprocess.run(['.venv/bin/python','-m','ruff','check','--config','ruff.toml','--stdin-filename',logical,'-'],cwd='policy-engine',input=post,capture_output=True)
  fmt=subprocess.run(['.venv/bin/python','-m','ruff','format','--check','--config','ruff.toml','--stdin-filename',logical,'-'],cwd='policy-engine',input=post,capture_output=True)
  checks.append({'path':str(rel),'ast':'pass','ruff_exit':check.returncode,'ruff_stdout':check.stdout.decode(),'ruff_stderr':check.stderr.decode(),'format_exit':fmt.returncode,'format_stdout':fmt.stdout.decode(),'format_stderr':fmt.stderr.decode()})
 else:
  post=p.read_bytes()
  if p.suffix=='.toml': tomllib.loads(post.decode())
 files.append({'path':str(rel),'pre_sha256':hashlib.sha256(prior).hexdigest() if original.exists() else None,'post_sha256':hashlib.sha256(post).hexdigest()})
 diffs.extend(difflib.unified_diff(prior.decode().splitlines(keepends=True),post.decode().splitlines(keepends=True),fromfile='a/'+str(rel) if original.exists() else '/dev/null',tofile='b/'+str(rel)))
(raw/'consumer.diff').write_text(''.join(diffs));(raw/'manifest.json').write_text(json.dumps({'base_commit':'2b38fd815046fcd20427841fb96e5978ddacdaaf','base_tree':'dfbffe1285b7c976f4d8687f3bc147cd7aa1f63c','files':files,'checks':checks,'runtime':'UNRUN','generated_contracts':'UNRUN','independent_review':'UNRUN'},indent=2)+'\n')
print(json.dumps(checks,indent=2))
