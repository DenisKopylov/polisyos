from pathlib import Path
base=Path('LOCAL/raw/e02-execution-20261027/repairs/C41-r7/postimages/policy-engine/src/polisyos')
p=base/'runtime/quality/generic_simulation_admission.py';s=p.read_text()
old='''    profile_selection_ref: str
    design_problem_ref: str'''
new='''    profile_selection_ref: str
    profile: GenericCycleSimulationProfileV1 | None = None
    child_selection: GenericCycleSimulationChildSelectionV1 | None = None
    design_problem_ref: str'''
assert old in s;s=s.replace(old,new,1)
old='''                    or input_record.profile.profile_selection_ref != expected.profile_selection_ref
                    or input_record.design_problem_ref != expected.design_problem_ref'''
new='''                    or input_record.profile.profile_selection_ref != expected.profile_selection_ref
                    or (
                        expected.profile is not None
                        and (
                            input_record.profile != expected.profile
                            or input_record.child_selection != expected.child_selection
                        )
                    )
                    or input_record.design_problem_ref != expected.design_problem_ref'''
assert old in s;s=s.replace(old,new,1)
old='''                    return refused("mismatch", "generic_n5_input_cycle_join_mismatch")
        if ref is None:'''
new='''                    return refused("mismatch", "generic_n5_input_cycle_join_mismatch")
                if expected.profile is None:
                    input_problem = refused(
                        "not_established", "generic_n5_expected_profile_not_established"
                    )
        if ref is None:'''
assert old in s;s=s.replace(old,new,1);p.write_text(s)
# Generic GET receives profile and child selection from the independently
# reopened family owner, not from the input record under inspection.
p=base/'runtime/http/routes/runs.py';s=p.read_text()
old='''                        profile_selection_ref=selection_ref,
                        design_problem_ref=cycle.design_problem_basis_ref,'''
new='''                        profile_selection_ref=selection_ref,
                        profile=binding.handoff.profile,
                        child_selection=binding.selection,
                        design_problem_ref=cycle.design_problem_basis_ref,'''
assert old in s;s=s.replace(old,new,1);p.write_text(s)
# Thread the real active worker handoff/scope and source run into the live N8
# consumer. A missing verified scope remains candidate-limited.
p=base/'runtime/quality/generation_cycle.py';s=p.read_text()
old='''    generic_cycle_simulation_currentness_resolver: Callable[[], bool] | None = None,
    cycle_index: int | None = None,
) -> ValuePortObservation | None:'''
new='''    generic_cycle_simulation_currentness_resolver: Callable[[], bool] | None = None,
    cycle_index: int | None = None,
    generic_handoff: GenericCycleSimulationContextHandoffV1 | None = None,
    generic_child_selection: GenericCycleSimulationChildSelectionV1 | None = None,
    generic_verified_scope: object | None = None,
    generic_source_run_id: str | None = None,
) -> ValuePortObservation | None:'''
assert old in s;s=s.replace(old,new,1)
old='''        artifact_store=artifact_store,
        cycle_index=cycle_index,
    )
    if generic_refusal =='''
new='''        artifact_store=artifact_store,
        cycle_index=cycle_index,
        handoff=generic_handoff,
        child_selection=generic_child_selection,
        verified_scope=generic_verified_scope,
        source_run_id=generic_source_run_id,
    )
    if generic_refusal =='''
assert old in s;s=s.replace(old,new,1)
old='''    artifact_store: ArtifactStore,
    cycle_index: int | None,
) -> str | None:
    """Reconcile a generic N5 observation'''
new='''    artifact_store: ArtifactStore,
    cycle_index: int | None,
    handoff: GenericCycleSimulationContextHandoffV1 | None,
    child_selection: GenericCycleSimulationChildSelectionV1 | None,
    verified_scope: object | None,
    source_run_id: str | None,
) -> str | None:
    """Reconcile a generic N5 observation'''
assert old in s;s=s.replace(old,new,1)
old='''        from polisyos.runtime.quality.cycle_substrate import (
            cycle_job_design_problem_ref,
        )
        from polisyos.runtime.quality.generic_simulation_admission import ('''
new='''        from polisyos.runtime.quality.cycle_substrate import (
            VerifiedNLJobScope,
            cycle_job_design_problem_ref,
        )
        from polisyos.runtime.quality.generic_simulation_admission import ('''
# Change only the occurrence inside the N8 helper.
start=s.index('def _generic_n5_observation_refusal(');a=s[:start];b=s[start:];assert old in b;b=b.replace(old,new,1)
old='''        if cycle_index is None:
            return "n5_execution_request_provenance_not_established"
        outcome_variable = _value_outcome_variable(candidate, problem)'''
new='''        if cycle_index is None:
            return "n5_execution_request_provenance_not_established"
        established_scope = (
            type(verified_scope) is VerifiedNLJobScope
            and verified_scope._was_issued_by_verified_nl_execution_owner
            and type(handoff) is GenericCycleSimulationContextHandoffV1
            and source_run_id is not None
        )
        if established_scope and (
            (handoff.job_id, handoff.run_id, handoff.tenant_id, handoff.cell_id)
            != (
                verified_scope.job_id,
                verified_scope.run_id,
                verified_scope.tenant_id,
                verified_scope.cell_id,
            )
            or context_ref != handoff.context_job_ref
            or profile_ref != handoff.profile_ref
            or simulation.generic_n4_child_profile_family_ref
            != handoff.n4_child_profile_family_ref
            or selection_ref != handoff.profile.profile_selection_ref
        ):
            return "generic_cycle_simulation_projection_binding_mismatch"
        outcome_variable = _value_outcome_variable(candidate, problem)'''
assert old in b;b=b.replace(old,new,1)
old='''                profile_selection_ref=selection_ref,
                design_problem_ref=cycle_job_design_problem_ref(problem),'''
new='''                profile_selection_ref=selection_ref,
                profile=handoff.profile if established_scope else None,
                child_selection=child_selection if established_scope else None,
                design_problem_ref=cycle_job_design_problem_ref(problem),'''
assert old in b;b=b.replace(old,new,1)
old='''                job_id=input_record.job_id,
                run_id=input_record.run_id,
                source_run_id=input_record.source_run_id,
                tenant_id=input_record.tenant_id,
                cell_id=input_record.cell_id,'''
new='''                job_id=verified_scope.job_id if established_scope else input_record.job_id,
                run_id=verified_scope.run_id if established_scope else input_record.run_id,
                source_run_id=source_run_id if established_scope else input_record.source_run_id,
                tenant_id=verified_scope.tenant_id if established_scope else input_record.tenant_id,
                cell_id=verified_scope.cell_id if established_scope else input_record.cell_id,'''
assert old in b;b=b.replace(old,new,1)
old='''    if join.status in {"unavailable", "not_established"}:
        return "n5_execution_request_provenance_not_established"'''
new='''    if join.status in {"unavailable", "not_established"} or not established_scope:
        return "n5_execution_request_provenance_not_established"'''
assert old in b;b=b.replace(old,new,1);s=a+b
# New optional state is maintained on the canonical default port.
old='''    generic_cycle_simulation_currentness_resolver: Callable[[], bool] | None = None

    def _selection_configuration'''
new='''    generic_cycle_simulation_currentness_resolver: Callable[[], bool] | None = None
    generic_handoff: GenericCycleSimulationContextHandoffV1 | None = None
    generic_child_selection: GenericCycleSimulationChildSelectionV1 | None = None
    generic_verified_scope: object | None = None
    generic_source_run_id: str | None = None

    def _selection_configuration'''
assert old in s;s=s.replace(old,new,1)
old='''            cycle_index=cycle_index,
        )
        if conditional is not None:'''
new='''            cycle_index=cycle_index,
            generic_handoff=self.generic_handoff,
            generic_child_selection=self.generic_child_selection,
            generic_verified_scope=self.generic_verified_scope,
            generic_source_run_id=self.generic_source_run_id,
        )
        if conditional is not None:'''
assert old in s;s=s.replace(old,new,1)
old='''            generic_cycle_simulation_currentness_resolver=(
                generic_cycle_simulation_currentness_resolver
            ),
        )
        if authority_scope == "production" and promotion_port is not None:'''
new='''            generic_cycle_simulation_currentness_resolver=(
                generic_cycle_simulation_currentness_resolver
            ),
            generic_handoff=generic_cycle_simulation_handoff,
            generic_child_selection=generic_cycle_simulation_child_selection,
            generic_verified_scope=candidate_cycle_verified_nl_job_scope,
        )
        if authority_scope == "production" and promotion_port is not None:'''
assert old in s;s=s.replace(old,new,1)
old='''        self._source_run_id = run_id
        self._source_handoff_refs = []'''
new='''        self._source_run_id = run_id
        if isinstance(self._value_port, _DefaultSimulationBoundFoundryValuePort):
            self._value_port = replace(self._value_port, generic_source_run_id=run_id)
        self._source_handoff_refs = []'''
assert old in s;s=s.replace(old,new,1)
old='''        self._generic_cycle_simulation_handoff = rebound_handoff
        self._generic_cycle_simulation_child_selection = rebound_child_selection
        if isinstance(self._simulation_port, JointSimulationPort):'''
new='''        self._generic_cycle_simulation_handoff = rebound_handoff
        self._generic_cycle_simulation_child_selection = rebound_child_selection
        if isinstance(self._value_port, _DefaultSimulationBoundFoundryValuePort):
            self._value_port = replace(
                self._value_port,
                generic_handoff=rebound_handoff,
                generic_child_selection=rebound_child_selection,
            )
        if isinstance(self._simulation_port, JointSimulationPort):'''
assert old in s;s=s.replace(old,new,1);p.write_text(s)
