from pathlib import Path
p=Path('LOCAL/raw/e02-execution-20261027/repairs/C41-r9/postimages/policy-engine')
def edit(path, old, new, *, n=1):
 q=p/path; s=q.read_text(); c=s.count(old)
 if c != n: raise RuntimeError(f'{path}: count {c}, expected {n} for {old[:80]!r}')
 q.write_text(s.replace(old,new))

q=p/'src/polisyos/core/artifacts/selected_verification.py'; q.parent.mkdir(parents=True,exist_ok=True)
q.write_text('''"""Direct selected-profile verification for a scoped replay reader."""

from __future__ import annotations

from typing import Any

from ._integrity_ops import VerificationReport, verification_report_from_loaded_artifact
from .canonical_profile import read_core_manifest_profile
from .ids import ArtifactID
from .manifest import ArtifactRef, artifact_reference_parts


class SelectedProfileVerificationReader:
    """Reopen a selected view and check its bytes without a boolean access probe.

    Only verification changes: other operations remain on the original owner.
    Direct read failures retain their original exception. A false verification
    report means the opened bytes and manifest failed integrity checks; it is
    never used to decide whether access was denied. This read-only replay facade
    does not add an owner, grant, attestation, or currentness claim.
    """

    def __init__(self, owner: Any) -> None:
        self._owner = owner

    def __getattr__(self, name: str) -> Any:
        return getattr(self._owner, name)

    def verify(self, selector: ArtifactID | ArtifactRef | str) -> VerificationReport:
        """Recompute the standard Core report after exact owner reads."""
        artifact_id, _, _ = artifact_reference_parts(selector)
        manifest, _ = read_core_manifest_profile(self._owner, selector)
        data = self._owner.get_bytes(selector)
        return verification_report_from_loaded_artifact(
            artifact_id, data=data, manifest=manifest
        )
''')

edit('src/polisyos/core/artifacts/ownership.py', '\n\n@dataclass(frozen=True)\nclass _ArtifactTransactionLease:', '''\n\ndef raise_artifact_read_access_error(exc: BaseException) -> None:
    """Preserve an actual access error through an owner wrapper's cause chain.

    Typed unavailability is not an ownership denial. Other permission errors
    remain distinct from typed ownership errors for the caller to classify.
    This function does not infer tenant identity from exception text.
    """
    pending: list[BaseException] = [exc]
    seen: set[int] = set()
    while pending:
        current = pending.pop()
        if id(current) in seen:
            continue
        seen.add(id(current))
        if isinstance(current, PermissionError) and not isinstance(
            current, ArtifactUnavailableError
        ):
            raise current
        if current.__cause__ is not None:
            pending.append(current.__cause__)
        if current.__context__ is not None:
            pending.append(current.__context__)


@dataclass(frozen=True)
class _ArtifactTransactionLease:''')
edit('src/polisyos/core/artifacts/__init__.py','    ArtifactUnavailableError,\n)', '    ArtifactUnavailableError,\n    raise_artifact_read_access_error,\n)')
edit('src/polisyos/core/artifacts/__init__.py','from .protocol import (\n    AUTHORITY_ENVELOPE_ARTIFACT_KIND,', 'from .selected_verification import SelectedProfileVerificationReader\nfrom .protocol import (\n    AUTHORITY_ENVELOPE_ARTIFACT_KIND,')
edit('src/polisyos/core/artifacts/__init__.py','    "ArtifactUnavailableError",\n', '    "ArtifactUnavailableError",\n    "SelectedProfileVerificationReader",\n')
# __all__ alphabetic lowercase at end; append before list closure via known entry
s=(p/'src/polisyos/core/artifacts/__init__.py').read_text(); pos=s.index('__all__ = ['); print('Core __all__ tail:',s[pos:][-700:])
edit('src/polisyos/core/artifacts/__init__.py','    "ArtifactOwnershipIndex",\n', '    "ArtifactOwnershipIndex",\n    "raise_artifact_read_access_error",\n')

# Remove the false-as-absence test: later direct bytes and exact manifest read
# already establish the complete integrity and selected view.
path='src/polisyos/runtime/quality/generation_cycle.py'
edit(path, '''    try:
        present = store.has(resolved_ref)
    except (FileNotFoundError, ArtifactOwnershipError) as exc:
        raise GenerationCycleError(
            "joint_simulation_result_unavailable",
            "N5 selected result view is absent or not owned by this store",
        ) from exc
    except (RuntimeDependencyError, TimeoutError, ConnectionError, OSError) as exc:
        raise GenerationCycleError(
            "joint_simulation_result_unavailable",
            "N5 selected result view availability could not be checked",
        ) from exc
    if not present:
        raise GenerationCycleError(
            "joint_simulation_result_unavailable",
            "N5 result blob or manifest is absent",
        )

''','')
# Preserve cause only in the explicit parent GET replay; other callers retain
# the established blocked observation and unavailable exception contract.
q=p/path; s=q.read_text(); start=s.index('def _conditional_simulation_value_observation('); end=s.index('\n\ndef ',start+4)
f=s[start:end]; print('conditional signature:',f[:1300]);
old='''    except GenerationCycleError as exc:
        return _blocked_value_observation(
            code=exc.code,
            reason=f"N8 conditional simulation result is not admissible: {exc}",'''
new='''    except GenerationCycleError as exc:
        if propagate_artifact_access_errors:
            from polisyos.core.artifacts import raise_artifact_read_access_error

            raise_artifact_read_access_error(exc)
        return _blocked_value_observation(
            code=exc.code,
            reason=f"N8 conditional simulation result is not admissible: {exc}",'''
if f.count(old)!=1: raise RuntimeError('conditional exception')
f=f.replace(old,new); s=s[:start]+f+s[end:]; q.write_text(s)
# function signature inspected in output; next script inserts flag.
# Historical replay must not discard a denial already wrapped by an owner.
q=p/path;s=q.read_text(); start=s.index('def resolve_generation_cycle_run_context_history(');end=s.index('\n\ndef ',start+4);f=s[start:end]
old='''        ) as exc:
            issues.append(
                {
                    "code": "generation_cycle_context_history_owner_refused",'''
new='''        ) as exc:
            from polisyos.core.artifacts import raise_artifact_read_access_error

            raise_artifact_read_access_error(exc)
            issues.append(
                {
                    "code": "generation_cycle_context_history_owner_refused",'''
if f.count(old)!=1: raise RuntimeError('history handler')
f=f.replace(old,new);q.write_text(s[:start]+f+s[end:])

# Generic owner preserves actual access failures, even when older owners wrap them.
path='src/polisyos/runtime/quality/generic_simulation_admission.py'
q=p/path;s=q.read_text();start=s.index('    def resolve_n5_execution_join(');end=s.index('    def _replay_n5_execution_sources(',start);f=s[start:end]
f=f.replace('''            read_core_json_artifact,
''','''            read_core_json_artifact,
            raise_artifact_read_access_error,
''')
for old,new in [
('''            except ArtifactOwnershipError:
                return refused("invalid", "generic_n5_input_scope_refused")''','''            except ArtifactOwnershipError:
                raise'''),
('''        except ArtifactOwnershipError:
            return refused("invalid", "generic_n5_owner_scope_refused")''','''        except ArtifactOwnershipError:
            raise'''),
('''        except ArtifactOwnershipError:
            return refused("invalid", "generic_n5_execution_scope_refused")''','''        except ArtifactOwnershipError:
            raise'''),
('''            except (CycleSubstrateContextOwnerError, TypeError, ValueError):
                input_problem''','''            except (CycleSubstrateContextOwnerError, TypeError, ValueError) as exc:
                raise_artifact_read_access_error(exc)
                input_problem'''),
('''        except GenerationCycleError as exc:
            return refused("not_established", exc.code)''','''        except GenerationCycleError as exc:
            raise_artifact_read_access_error(exc)
            return refused("not_established", exc.code)'''),
('''        except (CycleSubstrateContextOwnerError, TypeError, ValueError):
            # Some old owner failures''','''        except (CycleSubstrateContextOwnerError, TypeError, ValueError) as exc:
            raise_artifact_read_access_error(exc)
            # Some old owner failures'''),
]:
 if f.count(old)!=1: raise RuntimeError(f'generic snippet {old}')
 f=f.replace(old,new)
# Scope values are independently compared separately from non-scope mismatch.
old='''                if (
                    input_record.n4_source_ref != expected.n4_source_ref'''
new='''                if (input_record.tenant_id, input_record.cell_id) != (
                    expected.tenant_id, expected.cell_id
                ):
                    return refused("invalid", "generic_n5_input_scope_refused")
                if (
                    input_record.n4_source_ref != expected.n4_source_ref'''
if f.count(old)!=1: raise RuntimeError('input scope')
f=f.replace(old,new)
f=f.replace('''                    or input_record.tenant_id != expected.tenant_id
                    or input_record.cell_id != expected.cell_id
''','')
old='''        if (
            record.status != expected.status'''
new='''        if (record.tenant_id, record.cell_id) != (expected.tenant_id, expected.cell_id):
            return refused("invalid", "generic_n5_execution_scope_refused")
        if (
            record.status != expected.status'''
if f.count(old)!=1: raise RuntimeError('record scope')
f=f.replace(old,new)
f=f.replace('''            or record.tenant_id != expected.tenant_id
            or record.cell_id != expected.cell_id
''','')
q.write_text(s[:start]+f+s[end:])
