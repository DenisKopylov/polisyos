"""UNRUN source-derived falsifier; it is not a canonical test or receipt.

Run only after the separate physical-reference format repair makes N5 runnable.
The fixture is software-only; it establishes no external causal authority.
"""

from __future__ import annotations

import pytest

from polisyos.core.artifacts.store import FileSystemCAS
from polisyos.runtime.quality.generation_cycle import (
    GenerationCycleError,
    load_joint_simulation_result,
    persist_joint_simulation_result,
)
from polisyos.runtime.quality.joint_simulation_horizon import (
    HorizonSpec,
    JointSimulationControllerError,
    JointSimulationHorizonController,
)
from tests.unit.runtime.quality.test_joint_simulation_horizon import _program_graph_plan, _request


def _actual_pair(tmp_path, changed_input):
    """Build two owner-consumed inputs through existing engine fixtures."""
    base = _request()
    if changed_input == "program_base_state":
        plan = _program_graph_plan(tmp_path)
        assert plan.program_base_ref is None
        state = plan.program_base_state
        changed_state = state.replace(
            agents=state.agents.replace(income=state.agents.income + 100.0)
        )
        first = base.model_copy(
            update={
                "engine_plan": (plan,),
                "selected_outcomes": ("mean_income",),
                "baseline_state": {"mean_income": 0.0},
                "horizon": HorizonSpec(start=0, end=0, step=1),
            }
        )
        changed_plan = plan.model_copy(update={"program_base_state": changed_state})
        second = first.model_copy(update={"engine_plan": (changed_plan,)})
        return first, second, "mean_income"
    if changed_input == "semantic_time_like_variable_name":
        plan = base.engine_plan[0]
        first_plan = plan.model_copy(
            update={"variable_map": {**plan.variable_map, "captured_at": "firm_survival"}}
        )
        second_plan = plan.model_copy(
            update={"variable_map": {**plan.variable_map, "captured_at": "income_delta"}}
        )
        first = base.model_copy(
            update={
                "engine_plan": (first_plan,),
                "selected_outcomes": ("captured_at",),
                "baseline_state": {"captured_at": 0.0},
                "evidence_state": {},
                "horizon": HorizonSpec(start=0, end=0, step=1),
            }
        )
        second = first.model_copy(update={"engine_plan": (second_plan,)})
        return first, second, "captured_at"
    raise AssertionError("unrecognized adversarial input")


@pytest.mark.parametrize(
    "changed_input", ["program_base_state", "semantic_time_like_variable_name"]
)
def test_actual_changed_effectful_input_cannot_retain_a_selected_result(tmp_path, changed_input):
    """One property for two actual, semantically different engine inputs.

    These two counterexamples do not exhaust every EnginePlan field or caller.
    A failure establishes a software-property gap only for the reached input.
    """
    request_a, request_b, outcome = _actual_pair(tmp_path, changed_input)
    controller = JointSimulationHorizonController()
    result_a = controller.run(request_a)
    result_b = controller.run(request_b)
    role_a = result_a.trajectory_for("joint", result_a.atom_ids)
    role_b = result_b.trajectory_for("joint", result_b.atom_ids)
    value_a = role_a.points[-1].outcomes[outcome]
    value_b = role_b.points[-1].outcomes[outcome]
    assert value_a != value_b  # Actual numerical difference, not a field-name marker.
    assert result_a.physical_work_observations and result_b.physical_work_observations
    direct_error = None
    try:
        controller.validate_selected_result(request=request_b, result=result_a)
    except JointSimulationControllerError as exc:
        direct_error = str(exc)
    store_path = tmp_path / "selected-input-cas"
    ref = persist_joint_simulation_result(result_a, store=FileSystemCAS(store_path))
    fresh_error = None
    try:
        load_joint_simulation_result(
            ref, store=FileSystemCAS(store_path), expected_request=request_b
        )
    except GenerationCycleError as exc:
        fresh_error = str(exc)
    assert (
        direct_error is not None
        and "selected_plan_execution_binding_missing" in direct_error
        and fresh_error is not None
        and "joint_simulation_result_execution_binding_invalid" in fresh_error
    ), (direct_error, fresh_error)
    assert role_a.diagnostics["physical_run_ref"] != role_b.diagnostics["physical_run_ref"]
