"""Freeze a sparse author proposal; stdlib/Git diagnostics only, no apply/import/test."""
from pathlib import Path
import ast,collections,datetime,difflib,hashlib,json,subprocess,tomllib
R=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos');H=R/'LOCAL/raw/e02-execution-20261027/repairs/FED-operational-bridge-r1';P=H/'postimages';B='545c6990e2bfa42bf580b475e23cf88df04e71d8';sha=lambda b:hashlib.sha256(b).hexdigest();blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=R,stderr=subprocess.PIPE)
def source(path):
 p=subprocess.run(['git','show',f'{B}:{path}'],cwd=R,capture_output=True)
 return p.stdout if p.returncode==0 else None
head0=git('rev-parse','HEAD').decode().strip();index0=sha(git('diff','--cached','--raw','--no-abbrev','-z'))
paths=sorted(str(p.relative_to(P)) for p in P.rglob('*') if p.is_file());rows=[];patch='';ast_paths=[];whitespace=[]
assert len(paths)==8
for path in paths:
 old=source(path);new=(P/path).read_bytes();assert old!=new
 if new.endswith(b'\n') is False:raise ValueError('Missing final newline '+path)
 for n,line in enumerate(new.decode().splitlines(),1):
  if line.rstrip()!=line:whitespace.append([path,n])
 if path.endswith('.py'):ast.parse(new.decode());ast_paths.append(path)
 if path.endswith('.toml'):tomllib.loads(new.decode())
 pre=None if old is None else {'sha256':sha(old),'bytes':len(old),'git_blob':blob(old),'mode':'100644'}
 post={'sha256':sha(new),'bytes':len(new),'git_blob':blob(new),'mode':'100644'}
 actual=R/path;match=(not actual.exists() and not actual.is_symlink()) if old is None else (actual.is_file() and actual.read_bytes()==old)
 rows.append({'path':path,'preimage':pre,'postimage':post,'current_worktree_preimage_matches':match,'classification':'mechanism' if path.endswith(('/fabric/api.py','/fabric/federated_fetch.py','/adapters/fabric_bridge.py')) else 'mandatory_companion'})
 patch+=f'diff --git a/{path} b/{path}\n'
 patch+=('new file mode 100644\n' if old is None else '')+f'index {blob(old) if old is not None else "0"*40}..{blob(new)}'+(' 100644' if old is not None else '')+'\n'
 patch+=''.join(difflib.unified_diff((old or b'').decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile='/dev/null' if old is None else 'a/'+path,tofile='b/'+path,n=3))
assert not whitespace,whitespace
api_old=source('policy-engine/src/polisyos/fabric/api.py').decode();api_new=(P/'policy-engine/src/polisyos/fabric/api.py').read_text()
a=api_old.split('    constraints = constraints or {}',1)[1];b=api_new.split('    constraints = constraints or {}',1)[1];assert a==b,'Default API executable suffix changed'
port_old=ast.parse(source('policy-engine/src/polisyos/scientist/adapters/fabric_bridge.py').decode());port_new=ast.parse((P/'policy-engine/src/polisyos/scientist/adapters/fabric_bridge.py').read_text())
find=lambda t,name:next(x for x in ast.walk(t) if isinstance(x,ast.ClassDef) and x.name==name)
assert ast.dump(find(port_old,'FabricFetchDataFn'),include_attributes=False)==ast.dump(find(port_new,'FabricFetchDataFn'),include_attributes=False),'Legacy callback protocol changed'
patch_bytes=patch.encode();(H/'source.patch').write_bytes(patch_bytes)
check=subprocess.run(['git','apply','--check','--whitespace=error',str(H/'source.patch')],cwd=R,capture_output=True)
(H/'apply-check.stdout').write_bytes(check.stdout);(H/'apply-check.stderr').write_bytes(check.stderr)
read_paths=['AGENTS.md','policy-engine/CONTRIBUTING.md','policy-engine/docs/research/e02-cloud-test-plan/execution-prompts/HANDOFF.md','policy-engine/docs/reference/policy-design-case-failure-patterns.md','policy-engine/docs/plans/active/agent-packages/PolicyOS_E02_Combined_Agent_Package/source/B_r19_original.md','policy-engine/docs/research/e02-cloud-test-plan/closure-decisions/C.md','policy-engine/docs/research/e02-cloud-test-plan/closure-decisions/coverage.json','policy-engine/src/polisyos/ir/connectors/__init__.py','policy-engine/src/polisyos/core/artifacts/manifest.py','policy-engine/src/polisyos/core/contracts/fabric.py','policy-engine/src/polisyos/fabric/connectors/federation/planner.py','policy-engine/src/polisyos/fabric/connectors/_registry_models.py','policy-engine/src/polisyos/fabric/connectors/registry_core_parts.py','policy-engine/src/polisyos/fabric/connectors/sources/sql_query.py','policy-engine/src/polisyos/runtime/quality/production_invocation.py','policy-engine/architecture/public_surface/contract.toml','policy-engine/docs/reference/fabric/runtime-annotations.md','policy-engine/tests/unit/fabric/test_connector_bridge.py','policy-engine/tests/unit/scientist/adapters/test_fabric_bridge.py']
readset=[]
for path in sorted(set(read_paths+paths)):
 data=source(path)
 if data is not None:readset.append({'path':path,'commit':B,'sha256':sha(data),'bytes':len(data),'git_blob':blob(data)})
kernel=H.parent/'C77-structural-owner-r3';km=(kernel/'manifest.json').read_bytes();kernelfiles=[]
for name in ('artifact.py','profile.py','types.py','composer.py'):
 p=kernel/'postimages/policy-engine/src/polisyos/fabric/connectors/federation'/name
 kernelfiles.append({'path':str(p.relative_to(R)),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size})
head1=git('rev-parse','HEAD').decode().strip();index1=sha(git('diff','--cached','--raw','--no-abbrev','-z'))
record={'schema':'policyos.e02.sparse_author_proposal.v1','status':'RAW_PROPOSAL_NOT_APPLIED_RUNTIME_UNRUN','at':datetime.datetime.now(datetime.UTC).isoformat(),'root':str(R),'base_commit':B,'base_tree':git('rev-parse',B+'^{tree}').decode().strip(),'branch':'codex/e02-unified-local-20261009','files':rows,'denominator':{'paths':len(paths),'file_types':dict(collections.Counter(Path(p).suffix for p in paths)),'mechanism_paths':sum(r['classification']=='mechanism' for r in rows),'mandatory_companions':sum(r['classification']=='mandatory_companion' for r in rows)},'readset':readset,'kernel_input':{'r3_manifest_sha256':sha(km),'files':kernelfiles,'composition_dependency':'Final independently reviewed R4 kernel including scalar-preserving carrier correction and immutable fresh source_declarations tuple projection; R4 exact frozen identity not yet supplied. R3 is a read input, not claimed runtime accepted.'},'source_patch':{'path':str((H/'source.patch').relative_to(R)),'bytes':len(patch_bytes),'sha256':sha(patch_bytes),'read_only_apply_check_exit':check.returncode},'static_checks':{'AST_parse':{'outcome':'PASS','python_paths':ast_paths},'TOML_parse':'PASS','no_trailing_whitespace':'PASS','default_API_executable_suffix_identical':'PASS','legacy_callback_protocol_AST_identical':'PASS','apply_check_stdout':{'path':str((H/'apply-check.stdout').relative_to(R)),'sha256':sha(check.stdout),'bytes':len(check.stdout)},'apply_check_stderr':{'path':str((H/'apply-check.stderr').relative_to(R)),'sha256':sha(check.stderr),'bytes':len(check.stderr)}},'checks_unrun':['product imports','pytest and meaningful semantic old-red','Ruff/format/type/architecture/public/schema checks','production_invocation diagnostic','actual caller run/persisted readback','matched source removals/restored checks','resource/profile measurements'],'required_root_companions':['Final kernel R4 binding/review/runtime','public_surface inventory and generated reference','new public DTO/schema disposition','schema projection consumer compatibility','canonical handoff/journal/queue bindings','independent full-footprint review'],'source_review':'pending independent author review; no acceptance assigned','runtime':'UNRUN','G_acceptance':False,'closure_ids':[],'observed_root_head_before':head0,'observed_root_head_after':head1,'observed_index_before_sha256':index0,'observed_index_after_sha256':index1,'canonical_source_index_refs_mutated_by_author':False,'root_progress_during_freeze':head0!=head1 or index0!=index1}
(H/'manifest.json').write_text(json.dumps(record,indent=2)+'\n');assert json.loads((H/'manifest.json').read_text())==record;assert (H/'source.patch').read_bytes()==patch_bytes
print(json.dumps({'manifest_sha256':sha((H/'manifest.json').read_bytes()),'source_patch':record['source_patch'],'denominator':record['denominator'],'all_current_preimages_match':all(r['current_worktree_preimage_matches'] for r in rows),'runtime':'UNRUN'},indent=2))
