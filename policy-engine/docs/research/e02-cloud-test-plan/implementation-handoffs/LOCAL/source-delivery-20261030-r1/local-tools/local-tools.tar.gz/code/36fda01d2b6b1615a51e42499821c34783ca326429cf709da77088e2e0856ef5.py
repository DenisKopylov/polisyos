"""Widen the single fresh-consumer scope intake; RAW-only source authoring."""
from pathlib import Path
H=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos/LOCAL/raw/e02-execution-20261027/repairs/FED-operational-bridge-r3/postimages')
p=H/'policy-engine/src/polisyos/fabric/federated_fetch.py';s=p.read_text().replace('from dataclasses import asdict','from dataclasses import asdict, fields').replace('    QualityTier,\n','    QualityTier,\n    TrustLevel,\n',1)
s=s.replace('    provenance_basis: Literal["connector_reported"] = "connector_reported"','    provenance_basis: Literal["consumer_asserted"] = "consumer_asserted"').replace('    observation_basis: Literal["connector_reported"] = "connector_reported"','    observation_basis: Literal["consumer_asserted"] = "consumer_asserted"').replace('    captured_bytes_basis: Literal["independently_reconciled"] = "independently_reconciled"','    captured_bytes_basis: Literal["consumer_asserted"] = "consumer_asserted"').replace('    captured_row_count_basis: Literal["recomputed"] = "recomputed"','    selected_member_bytes_basis: Literal["recomputed"] = "recomputed"\n    selected_member_row_count_basis: Literal["recomputed"] = "recomputed"')
s=s.replace('    leaf_history_basis: Literal["consumer_asserted"] = "consumer_asserted"','''    leaf_history_basis: Literal["consumer_asserted"] = "consumer_asserted"
    capture_origin_basis: Literal["consumer_asserted"] = "consumer_asserted"
    observation_origin_basis: Literal["consumer_asserted"] = "consumer_asserted"''',1)
s=s.replace('_FORMAT = "policyos.fabric.federation-acquisition/1"','_FORMAT = "policyos.fabric.federation-acquisition/2"')
anchor='def _validate_kernel_binding(\n'
new='''def _capture_bound(context: dict[str, Any]) -> int | None:
    constraints = context.get("constraints")
    if type(constraints) is not dict or set(constraints) != {"page_size"}:
        raise FederationError("Unsupported frozen capture constraint profile")
    bound = constraints["page_size"]
    if bound is not None and (type(bound) is not int or not 1 <= bound <= MAX_ROWS):
        raise FederationError("Invalid frozen source/output row bound")
    return bound


def _admit_rows(rows: int, bound: int | None, subject: str) -> None:
    if bound is not None and rows > bound:
        raise FederationError(f"{subject} exceeds the independently requested row bound")


def _admit_context(context: dict[str, Any], root: Path) -> None:
    expected = {
        "dataset_id", "composition", "sources", "constraints", "held_parents",
        "output_root", "capture_scope",
    }
    if set(context) != expected or context["capture_scope"] != "captured_rows_only":
        raise FederationError("Unsupported frozen acquisition profile")
    composition = context["composition"]
    if type(composition) is not dict or set(composition) != {
        field.name for field in fields(CompositionRequest)
    }:
        raise FederationError("Frozen composition does not match the owner contract")
    if (
        composition["schema"] is not None
        or composition["max_staleness"] is not None
        or type(composition["min_trust_level"]) is not int
        or type(context["dataset_id"]) is not str
        or context["dataset_id"] != composition["dataset_pattern"]
        or str(root.resolve()) != context["output_root"]
    ):
        raise FederationError("Unsupported or mismatched frozen request scope")
    TrustLevel(composition["min_trust_level"])
    sources = context["sources"]
    if type(sources) is not list or not 1 <= len(sources) <= MAX_SOURCES:
        raise FederationError("Frozen source selection exceeds its supported profile")
    if type(context["held_parents"]) is not dict or len(context["held_parents"]) > MAX_GRAPH_NODES:
        raise FederationError("Frozen parent registry exceeds its supported profile")
    _capture_bound(context)


'''
assert s.count(anchor)==1;s=s.replace(anchor,new+anchor,1)
s=s.replace('''    if manifest["request"] != context["composition"]:''','''    if _fingerprint(manifest["request"]) != _fingerprint(context["composition"]):''',1)
a=s.index('    for position, (record, source) in enumerate(zip(records, context["sources"], strict=True)):\n');b=s.index('    return manifest\n',a)
s=s[:a]+'''    bound = _capture_bound(context)
    held = {digest: Path(path) for digest, path in context["held_parents"].items()}
    for position, (record, source) in enumerate(zip(records, context["sources"], strict=True)):
        value = _read_selected_json(root / record["path"], record["sha256"])
        if source["kind"] == "parent":
            expected = {"parent": source["digest"], "metadata": source["metadata"]}
            if _fingerprint(value) != _fingerprint(expected):
                raise FederationError("Selected parent differs from the independently held basis")
            parent = read_verified_federation_derivation(
                held[source["digest"]], FederationArtifactRef(source["digest"]), held_parents=held
            )
            actual_rows = len(parent.data)
            if type(source["metadata"]["row_count"]) is not int or (
                source["metadata"]["row_count"] != actual_rows
            ):
                raise FederationError("Declared parent row count differs from its selected rows")
            _admit_rows(actual_rows, bound, f"Selected parent {position}")
            continue
        if source["kind"] != "connector" or set(value) != {"frame", "metadata"}:
            raise FederationError("Unsupported selected source kind")
        observation = by_position[position]
        request = FetchRequest(
            dataset_id=source["dataset_id"], page_size=context["constraints"]["page_size"]
        )
        actual_rows = len(value["frame"]["rows"])
        expected_metadata = {
            "connector_id": observation.connector_id, "metadata": source["metadata"],
            "row_count": actual_rows, "fetched_at": observation.provenance.fetched_at.isoformat(),
            "last_updated": observation.provenance.source_updated_at.isoformat()
            if observation.provenance.source_updated_at else None,
            "observed_latency_ms": None,
        }
        if (
            _fingerprint(value["metadata"]) != _fingerprint(expected_metadata)
            or observation.connector_id != (
                ConnectorMetadataSpec.model_validate(source["metadata"]).fully_qualified_id
            )
            or observation.dataset_id != source["dataset_id"]
            or observation.request_key != request.request_key
            or observation.selected_source_sha256 != record["sha256"]
            or observation.row_count != actual_rows
        ):
            raise FederationError("Selected member/receipt differs from the requested source basis")
        # Matching bytes/request is not proof of who supplied the capture.
        # All receipt-origin observations remain consumer_asserted.
        _admit_rows(actual_rows, bound, f"Declared connector capture {position}")
''' +s[b:]
anchor='def _result(\n'
intake='''def _admit_selected_capture(
    root: Path, ref: FederationArtifactRef, context: dict[str, Any],
    observations: tuple[FederationFetchObservation, ...],
) -> VerifiedFederationResult:
    """The sole successful-result admission, shared by producer and consumer.

    Every load-bearing predicate is recomputed from independent frozen intent
    and actual fresh selected graph bytes. Capture origin is not authenticated.
    """
    _admit_context(context, root)
    held = {digest: Path(path) for digest, path in context["held_parents"].items()}
    verified = read_verified_federation_derivation(root, ref, held_parents=held)
    _validate_kernel_binding(root, ref, context, observations)
    if not verified.source_declarations:
        raise FederationError("Fresh graph does not expose its declared whole-leaf basis")
    threshold = TrustLevel(context["composition"]["min_trust_level"])
    for _token, declaration in verified.source_declarations:
        leaf = ConnectorMetadataSpec.model_validate(json.loads(declaration)["metadata"])
        if leaf.trust_level < threshold:
            raise FederationError("Fresh selected graph contains a declared leaf below the filter")
    _admit_rows(len(verified.data), _capture_bound(context), "Composed output")
    return verified


'''
assert s.count(anchor)==1;s=s.replace(anchor,intake+anchor,1)
s=s.replace('''        "federation.output_completeness_not_established",''','''        "federation.output_completeness_not_established",
        "federation.capture_origin_consumer_asserted",''',1)
a=s.index('''            parent = read_verified_federation_derivation(\n''',s.index('def fetch_federated('));b=s.index('''            inputs.append(selected)''',a)
s=s[:a]+'''            # The canonical intake below replays the selected parent and applies
            # every scope/preference predicate from the frozen context again.
'''+s[b:]
needle='''        metadata = ConnectorMetadataSpec.model_validate(source["metadata"])
'''
s=s.replace(needle,'''        _admit_rows(len(fetched.data), _capture_bound(context), "Returned connector capture")
'''+needle,1)
s=s.replace('''    verified = read_verified_federation_derivation(root, ref, held_parents=held)
    manifest = _read_selected_json(root / "manifest.json", ref.manifest_sha256)''','''    manifest = _read_selected_json(root / "manifest.json", ref.manifest_sha256)''',1)
s=s.replace('''    _validate_kernel_binding(root, ref, context, observed)
    serialized_observations''','''    verified = _admit_selected_capture(root, ref, context, observed)
    serialized_observations''',1)
s=s.replace('''    verified = read_verified_federation_derivation(root, ref, held_parents=held)
    observed = tuple(FederationFetchObservation.model_validate_json(json.dumps(row))
                     for row in receipt["fetches"])
    _validate_kernel_binding(root, ref, context, observed)''','''    observed = tuple(FederationFetchObservation.model_validate_json(json.dumps(row))
                     for row in receipt["fetches"])
    verified = _admit_selected_capture(root, ref, context, observed)''',1)
# Context exactness must preserve bool/int and other typed distinctions.
s=s.replace('''        or receipt.get("context") != context''','''        or _fingerprint(receipt.get("context")) != _fingerprint(context)''',1)
p.write_text(s)
p=H/'policy-engine/src/polisyos/scientist/adapters/fabric_bridge.py';s=p.read_text().replace('''            federation_audit = fetch_result.federation_audit.model_dump(mode="json")''','''            # Admission uses the exact frozen page bound, not result.row_count
            # or unknown-completeness markers. No rows are silently sliced.
            if len(fetch_result.data) > query_request.pagination.limit:
                raise ValueError("Composed capture exceeds the independent query output bound")
            federation_audit = fetch_result.federation_audit.model_dump(mode="json")''',1)
s=s.replace('''        if federation_audit is not None:
            snapshot_stats["federation_manifest_sha256"]''','''        if federation_audit is not None:
            snapshot_notes.remove("source=fabric_get_data")
            snapshot_notes.append("source=federation_receipt_consumer_asserted")
            snapshot_stats["federation_manifest_sha256"]''',1)
p.write_text(s)
