"""Freeze an explicit committed N7 fixture descendant; never execute product code."""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
import runpy
import subprocess
from pathlib import Path

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
RAW = ROOT / "LOCAL/raw/e02-execution-20261027"
PACKET = RAW / "runtime-prep/N7-candidate-bundle-design-r9"
ROOT_LIB = ROOT / "policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/root-layer-lib.py"
ORIGINAL_BASE = "f44a6455be0313dc1b6258e7fca2518f232c4e43"
FIXTURE = "policy-engine/tests/unit/runtime/quality/test_generation_source.py"
ADAPTER = "policy-engine/src/polisyos/core/artifacts/ir_adapter.py"
APPROVED_POSTS = {
    FIXTURE: "2ac5b4a03b069b535a25084d52fa5aab05773921e7a945563b18a3edcc2cda31",
    ADAPTER: "51971e1cc470657f75c48f0b0fddd3e8c51f6f03d250abbefb261c6564f8934f",
}
PINNED = {
    "run_n7_builder_root_r9.py": "25dcdd22074cdc01bbd6ce2afb42d3864d3215bc7b06f10b9a450f60348fe884",
    "runtime-prep/N7-builder-r116/loaded-source.json": "2aa2056d8d803cfd1597c98a1b526d0a7967428aa4d8ec849efb7f0158a7b5d6",
    "runtime-prep/N7-builder-r116/Git-readback.json": "aa468738a7ee252d51d3f698656c16a56906ef14f8e3cdc3aebc6472769abdab",
    "repairs/N7-actual-source-fixture-r2/manifest.json": "99c468a69bb32a02779c746320cd11226d6a28a218ebaf33479d74841023a98c",
    "reviews/N7-actual-source-fixture-r2-independent/review.json": "6c0e120915829d5dda041f4c6a0faa9b3c502809c880a6dee23950a2d84901a5",
    "reviews/ir-adapter-type-constraints-r1-independent/review.json": "220b6ec87f25b6317ed00962cff903ea4a48699598135d9fd3e28f9e7a8c1a1a",
}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args: str) -> bytes:
    return subprocess.check_output(["git", *args], cwd=ROOT)


def guard_source(head: str, tree: str) -> dict:
    before = runpy.run_path(str(ROOT_LIB))["guard"]()
    live = json.loads((ROOT / "LOCAL/raw/root-live-ownership-20261021.json").read_text())
    assert not live["known_dirty_paths"], "source is not frozen"
    assert before["head"] == head == git("rev-parse", "HEAD").decode().strip()
    assert live["tree"] == tree == git("rev-parse", "HEAD^{tree}").decode().strip()
    assert git("symbolic-ref", "--short", "HEAD").decode().strip() == "codex/e02-unified-local-20261009"
    subprocess.run(["git", "merge-base", "--is-ancestor", ORIGINAL_BASE, head], cwd=ROOT, check=True)
    assert not git("diff", "--name-only") and not git("diff", "--cached", "--name-only")
    return before


def validate_source(head: str, tree: str) -> dict:
    """Reconcile the complete prior finite Python set, not a sampled index."""
    before = guard_source(head, tree)
    for rel, expected in PINNED.items():
        assert sha(RAW / rel) == expected, rel
    fixture_review = json.loads((RAW / "reviews/N7-actual-source-fixture-r2-independent/review.json").read_text())
    assert fixture_review["independent"] is True
    assert fixture_review["verdict"] == "GO_SOURCE_ONLY"
    assert fixture_review["manifest_sha256"] == PINNED["repairs/N7-actual-source-fixture-r2/manifest.json"]
    assert fixture_review["postimage_sha256"] == APPROVED_POSTS[FIXTURE]
    style_path = RAW / "composition/ir-type-r121/style.json"
    style = json.loads(style_path.read_text())
    adapter_style = [row for row in style if row["path"] == ADAPTER]
    assert len(adapter_style) == 1
    assert adapter_style[0]["pre_sha256"] == "ec7dca276bbad930e1e1222e3454be96764a72746b9bca7d74818a5409706d6d"
    assert adapter_style[0]["post_sha256"] == APPROVED_POSTS[ADAPTER]
    assert adapter_style[0]["format_ast_equal"] is True and adapter_style[0]["substantive_delta"] is None
    shadow = RAW / "repairs/ir-adapter-type-constraints-r1/candidate-r2.py"
    assert sha(shadow) == adapter_style[0]["pre_sha256"]
    assert ast.dump(ast.parse(shadow.read_text()), include_attributes=False) == ast.dump(ast.parse((ROOT / ADAPTER).read_text()), include_attributes=False)
    prior = json.loads((RAW / "runtime-prep/N7-builder-r116/loaded-source.json").read_text())
    old_readback = json.loads((RAW / "runtime-prep/N7-builder-r116/Git-readback.json").read_text())
    assert old_readback["head"] == ORIGINAL_BASE and not old_readback["mismatches"]
    assert len(prior) == old_readback["finite_module_count"] == 1619
    changes = []
    for path, previous in sorted(prior.items()):
        rel = "policy-engine/" + path
        raw = (ROOT / rel).read_bytes()
        actual = hashlib.sha256(raw).hexdigest()
        assert raw == git("show", head + ":" + rel), rel + ": physical/Git mismatch"
        if actual != previous:
            assert APPROVED_POSTS.get(rel) == actual, rel + ": unapproved prior-readset change"
            changes.append({"path": rel, "previous_sha256": previous, "post_sha256": actual})
    assert {row["path"] for row in changes} == set(APPROVED_POSTS)
    contract = json.loads((PACKET / "run-contract.json").read_text())
    assert sha(PACKET / "prepare_candidate_inputs.py") == contract["builder_sha256"] == "b3dae74285bfc5bf6c17c8c27467f6a64efce08f1181c013954423bff6e216e2"
    pins = {}
    for rel, previous in contract["source_pins"].items():
        actual = sha(ROOT / rel)
        assert actual == APPROVED_POSTS.get(rel, previous), rel + ": unapproved R9 contract input"
        assert (ROOT / rel).read_bytes() == git("show", head + ":" + rel)
        pins[rel] = actual
    assert len(pins) == 17
    after = guard_source(head, tree)
    assert before == after
    return {
        "schema": "e02.n7.r117-source-binding.r1",
        "head": head, "tree": tree, "root_guard": after,
        "original_r9_contract_sha256": sha(PACKET / "run-contract.json"),
        "builder_sha256": contract["builder_sha256"],
        "source_pins": pins, "prior_parent_python_file_denominator": len(prior),
        "prior_readset_path": str(RAW / "runtime-prep/N7-builder-r116/loaded-source.json"),
        "prior_readset_sha256": PINNED["runtime-prep/N7-builder-r116/loaded-source.json"],
        "all_changed_prior_loaded_inputs": changes,
        "v3_four_proposed_files_in_prior_readset": [],
        "v3_absence_scope": "Only prior R116 parent Python readset; new run observes its actual finite imports and may add members.",
        "ir_format_style_proof": {"path": str(style_path), "sha256": sha(style_path), "normalized_ast_equal_recomputed": True},
        "pinned_preparation_inputs": PINNED,
        "runtime": "UNRUN", "g_acceptance": False, "closure_ids": [],
    }


def check_binding(path: Path) -> None:
    saved = json.loads(path.read_text())
    current = validate_source(saved["head"], saved["tree"])
    assert current == saved, "source binding changed after overlay creation"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--expected-head", required=True)
    parser.add_argument("--expected-tree", required=True)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    candidate = args.output.absolute()
    assert not os.path.lexists(candidate)
    for parent in candidate.parents:
        assert not parent.is_symlink()
    output = candidate.resolve(strict=False)
    assert output.is_relative_to(RAW) and not output.is_relative_to(ROOT / "policy-engine")
    assert not os.path.lexists(output)
    assert output.parent.is_dir()
    binding = validate_source(args.expected_head, args.expected_tree)
    original = json.loads((PACKET / "run-contract.json").read_text())
    original["source_pins"] = binding["source_pins"]
    original["source_cut"] = {"branch": "codex/e02-unified-local-20261009", "head": args.expected_head, "tree": args.expected_tree, "test_generation_source_sha256": APPROVED_POSTS[FIXTURE]}
    original["source_binding_overlay"] = {"schema": "e02.n7.r117-source-overlay.r1", "binding_path": str(output / "binding.json"), "status": "EXPLICIT_COMMITTED_SOURCE_ONLY_RUNTIME_UNRUN", "prior_contract_immutable": str(PACKET / "run-contract.json")}
    original["whole_fixture_preflight"]["producer_is_unchanged"] = False
    original["whole_fixture_preflight"]["fixture_change_scope"] = "Committed complete synthetic-result assembly R2; all original 38 test functions unchanged; no product changes in fixture repair."
    original["status"] = "SOURCE_BINDING_OVERLAY_RUNTIME_UNRUN"
    output.mkdir()
    (output / "binding.json").write_text(json.dumps(binding, indent=2) + "\n")
    (output / "run-contract-overlay.json").write_text(json.dumps(original, indent=2) + "\n")
    old_line = "contract=json.loads((packet/'run-contract.json').read_text())"
    source = (RAW / "run_n7_builder_root_r9.py").read_text()
    assert source.count(old_line) == 1
    source = source.replace(old_line, "contract=json.loads(Path(" + repr(str(output / "run-contract-overlay.json")) + ").read_text())")
    old_receipt = "'contract_sha256':sha(packet/'run-contract.json')"
    assert source.count(old_receipt) == 1
    source = source.replace(old_receipt, "'contract_sha256':sha(Path(" + repr(str(output / "run-contract-overlay.json")) + "))")
    code = "from pathlib import Path\nimport runpy\nprep=runpy.run_path(" + repr(str(Path(__file__).absolute())) + ")\nbinding=Path(" + repr(str(output / "binding.json")) + ")\nprep['check_binding'](binding)\ntry:\n exec(compile(" + repr(source) + "," + repr(str(RAW / "run_n7_builder_root_r9.py")) + ",'exec'),{'__name__':'__main__'})\nfinally:\n prep['check_binding'](binding)\n"
    compile(code, str(output / "launch_builder.py"), "exec")
    (output / "launch_builder.py").write_text(code)
    print(json.dumps({"binding": str(output / "binding.json"), "binding_sha256": sha(output / "binding.json"), "launcher": str(output / "launch_builder.py"), "launcher_sha256": sha(output / "launch_builder.py"), "head": args.expected_head, "tree": args.expected_tree, "runtime": "UNRUN"}))


if __name__ == "__main__":
    main()
