from __future__ import annotations
import difflib
import hashlib
import json
import subprocess
from pathlib import Path

R=Path.cwd()
scope=R/'LOCAL/raw/e02-execution-20261027/repairs/C17-r2'
prev=R/'LOCAL/raw/e02-execution-20261027/repairs/C17'
post=scope/'postimages'
base='8db01b1076e425b7998b05a658776c991b7bd594'
base_tree='1706923ebe943f1a332dca4860cd145ddd366e36'
previous_hash='42b3e29618a6bbabc8d844a7ee363d9556d6e71910b8ef6de7e80cfe6bfb3544'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha((prev/'manifest.json').read_bytes())==previous_hash
previous=json.loads((prev/'manifest.json').read_text())
previous_rows={row['path']:row for row in previous['files']}
rows=[];base_patch=[];delta_patch=[];mismatches=[]
for f in sorted((post/'policy-engine').rglob('*')):
 if not f.is_file(): continue
 assert not f.is_symlink() and f.stat().st_nlink==1 and f.resolve().is_relative_to(scope.resolve())
 path=f.relative_to(post).as_posix()
 prior=previous_rows[path]
 prev_file=R/prior['postimage_path']
 prev_bytes=prev_file.read_bytes()
 assert sha(prev_bytes)==prior['postimage_sha256'],path
 proc=subprocess.run(['git','show',base+':'+path],capture_output=True)
 original=proc.stdout if proc.returncode==0 else None
 current=R/path
 state=current.stat() if current.exists() else None
 actual=current.read_bytes() if current.is_file() else None
 if actual!=original:
  mismatches.append({'path':path,'base_sha256':sha(original) if original is not None else None,'actual_sha256':sha(actual) if actual is not None else None})
 data=f.read_bytes()
 row={'path':path,'base_sha256':sha(original) if original is not None else None,'previous_sha256':sha(prev_bytes),'postimage_sha256':sha(data),'postimage_bytes':len(data),'postimage_path':str(f.relative_to(R)),'observed_source_link_count':state.st_nlink if state else None,'observed_source_inode':state.st_ino if state else None,'observed_source_symlink':current.is_symlink() if state else None}
 rows.append(row)
 def add_diff(out,before,after,new_file=False):
  if before==after:return
  out.append(f'diff --git a/{path} b/{path}\n')
  if new_file:out.append('new file mode 100644\n')
  out.extend(difflib.unified_diff(before.decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),fromfile=('/dev/null' if new_file else 'a/'+path),tofile='b/'+path))
 add_diff(base_patch,original or b'',data,original is None)
 add_diff(delta_patch,prev_bytes,data)
assert len(rows)==len(previous_rows) and {r['path'] for r in rows}==set(previous_rows)
base_bytes=''.join(base_patch).encode();delta_bytes=''.join(delta_patch).encode()
for name,data in [('base-to-proposal.patch',base_bytes),('previous-to-r2.patch',delta_bytes)]:
 with (scope/name).open('xb') as handle: handle.write(data)
check=subprocess.run(['git','apply','--check','--whitespace=error','--',str(scope/'base-to-proposal.patch')],cwd=R,capture_output=True)
with (scope/'apply-check.stderr').open('xb') as handle: handle.write(check.stderr)
controls={
 'status':'prepared_runtime_unrun',
 'scenarios':['producer_topics','report_bridge','markdown_disclaimer','manifest_edge','report_reconciliation','diff_reconstruction','scope_guard'],
 'plugin':{'path':str((scope/'removal_controls/lex_impact_removal_plugin.py').relative_to(R)),'sha256':sha((scope/'removal_controls/lex_impact_removal_plugin.py').read_bytes())},
 'plan_preparer':{'path':str((scope/'removal_controls/prepare_plans.py').relative_to(R)),'sha256':sha((scope/'removal_controls/prepare_plans.py').read_bytes())},
 'requirements':'normal plugins, source and active-code pins, full output/JUnit, original callable restored, intended red; setup/error/timeout are not successful controls',
 'runtime':'UNRUN'
}
with (scope/'controls-manifest.json').open('x') as h:json.dump(controls,h,indent=2);h.write('\n')
receipt={
 'schema':'policyos.e02.sparse_proposal.v1',
 'scope':'LA-017 legacy reader-first activation, selected diff/report internal consistency and declared jurisdiction limitation',
 'status':'proposal_not_applied_runtime_unrun',
 'base_commit':base,'base_tree':base_tree,
 'previous_proposal_manifest_sha256':previous_hash,
 'previous_independent_review':'LOCAL/raw/e02-execution-20261027/reviews/C17-delta.md',
 'previous_independent_review_sha256':sha((R/'LOCAL/raw/e02-execution-20261027/reviews/C17-delta.md').read_bytes()),
 'received_cloud_candidate_tree':'9baae9ea9e36078953d470666be197b049ab19bb',
 'received_cloud_diff_sha256':'49d537d8cdeb32162a1582dfd11056177c64181344d043d3e045326fd578d066',
 'files':rows,'base_preimage_mismatches_against_current':mismatches,
 'patch':{'path':str((scope/'base-to-proposal.patch').relative_to(R)),'sha256':sha(base_bytes),'bytes':len(base_bytes),'git_apply_check_exit':check.returncode,'git_apply_check_stderr':str((scope/'apply-check.stderr').relative_to(R))},
 'previous_to_r2_patch':{'path':str((scope/'previous-to-r2.patch').relative_to(R)),'sha256':sha(delta_bytes),'bytes':len(delta_bytes)},
 'README_sha256':sha((scope/'README.md').read_bytes()),
 'static_checks_sha256':sha((scope/'static-checks.json').read_bytes()),
 'controls_manifest_sha256':sha((scope/'controls-manifest.json').read_bytes()),
 'hardlink_preservation':'canonical preimages have multiple links; verify hashes and use a new inode plus atomic replacement, never truncate in place',
 'shared_generated_family':'root must regenerate and review public-surface family after composition',
 'runtime':'UNRUN','G_acceptance':False,'closure_ids':[]
}
with (scope/'manifest.json').open('x') as h:json.dump(receipt,h,indent=2);h.write('\n')
print(json.dumps({'paths':len(rows),'changed_since_previous':sum(r['previous_sha256']!=r['postimage_sha256'] for r in rows),'base_patch_sha256':sha(base_bytes),'delta_patch_sha256':sha(delta_bytes),'manifest_sha256':sha((scope/'manifest.json').read_bytes()),'controls_manifest_sha256':sha((scope/'controls-manifest.json').read_bytes()),'apply_check_exit':check.returncode,'mismatches':mismatches},indent=2))
if mismatches or check.returncode:
 raise SystemExit('Current preimage/apply mismatch: do not apply until root resolves')
