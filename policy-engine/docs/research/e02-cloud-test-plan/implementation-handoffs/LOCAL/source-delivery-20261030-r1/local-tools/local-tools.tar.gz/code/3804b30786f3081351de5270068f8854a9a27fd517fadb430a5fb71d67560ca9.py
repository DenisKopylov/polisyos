"""Remove only the canonical gate dispatch, preserving request/ref/DTO markers.

The scoped candidate and generic mismatch witnesses must FAIL under this
plugin. No product file/default configuration is changed.
"""

import pytest


@pytest.fixture(autouse=True)
def tc_remove_context_gate(monkeypatch):
    from polisyos.runtime.quality.cycle_substrate import (
        CycleSubstrateContextArtifactOwner,
    )

    original = CycleSubstrateContextArtifactOwner.resolve_for_current_job

    def without_gate(self, *args, **kwargs):
        verifier = self._context_admission_verifier
        self._context_admission_verifier = None
        try:
            return original(self, *args, **kwargs)
        finally:
            self._context_admission_verifier = verifier

    monkeypatch.setattr(
        CycleSubstrateContextArtifactOwner, "resolve_for_current_job", without_gate
    )
