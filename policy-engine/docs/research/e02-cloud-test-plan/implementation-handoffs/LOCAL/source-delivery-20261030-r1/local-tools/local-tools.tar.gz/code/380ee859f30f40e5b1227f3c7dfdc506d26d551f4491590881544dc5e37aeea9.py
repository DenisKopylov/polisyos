from pathlib import Path
r=Path(__file__).parent/'policy-engine'
p=r/'src/polisyos/core/llm/settlement.py';s=p.read_text().replace('import secrets\n','import secrets\nimport time\nfrom collections import OrderedDict\n');s=s.replace('    def __init__(self, client: Any = None) -> None:\n','    def __init__(self, client: Any = None, *, retention_limit: int = 128) -> None:\n',1);s=s.replace('        self._published: dict[tuple[str, str], tuple[str, tuple[str, ...], str]] = {}','        if type(retention_limit) is not int or retention_limit < 1:\n            raise ValueError("cache origin retention limit must be a positive integer")\n        self._retention_limit = retention_limit\n        self._published: OrderedDict[tuple[str, str], tuple[str, tuple[str, ...], str, float]] = OrderedDict()')
s=s.replace('''        registration = _CacheFlightRegistration(
''','''        self._prune_retained_origins()
        registration = _CacheFlightRegistration(
''',1)
start=s.index('    def settle_flight(');stop=s.index('    def forget_cached_key',start);x=s[start:stop];x=x.replace('        response_digest: str | None = None,','        response_digest: str | None = None,\n        retain_for_s: float = 0,',1).replace('                origin_event_id, producer.scope_key, response_digest\n','                origin_event_id, producer.scope_key, response_digest,\n                time.monotonic() + max(float(retain_for_s), 0),\n',1).replace('        return outcome\n','        self._prune_retained_origins()\n        return outcome\n',1);s=s[:start]+x+s[stop:]
s=s.replace('    def forget_cached_key(self, cache_key: str) -> None:', '''    def configure_retention(self, retention_limit: int) -> None:
        """Tighten a shared owner's resource bound without widening its authority."""
        if type(retention_limit) is not int or retention_limit < 1:
            raise ValueError("cache origin retention limit must be a positive integer")
        self._retention_limit = min(self._retention_limit, retention_limit)
        self._prune_retained_origins()

    def _prune_retained_origins(self) -> None:
        now = time.monotonic()
        for identity, retained in tuple(self._published.items()):
            if retained[3] <= now:
                del self._published[identity]
        while len(self._published) > self._retention_limit:
            self._published.popitem(last=False)

    def forget_cached_key(self, cache_key: str) -> None:''',1)
s=s.replace('''            retained = self._published.get((cache_key, request_digest))
            origin_id, scope_key, expected_response_digest = (
                retained if retained is not None else (None, (), None)
            )''','''            self._prune_retained_origins()
            retained = self._published.get((cache_key, request_digest))
            origin_id, scope_key, expected_response_digest, _ = (
                retained if retained is not None else (None, (), None, None)
            )
            if retained is not None:
                self._published.move_to_end((cache_key, request_digest))''',1);p.write_text(s)
p=r/'src/polisyos/core/llm/cache_settlement.py';s=p.read_text();start=s.index('    def settle_flight(');stop=s.index('    @_locked_cache_operation\n    def issue_reuse_attestation',start);x=s[start:stop].replace('        response_digest: str | None = None,','        response_digest: str | None = None,\n        retain_for_s: float = 0,',1).replace('            response_digest=response_digest,','            response_digest=response_digest,\n            retain_for_s=retain_for_s,',1);s=s[:start]+x+s[stop:]
s=s.replace('def bind_cache_settlement_client(cache: object, client: object) -> CacheSettlementSession:', 'def bind_cache_settlement_client(\n    cache: object, client: object, *, retention_limit: int = 128\n) -> CacheSettlementSession:')
s=s.replace('    session = create_cache_settlement_session(cache)\n','    session = create_cache_settlement_session(cache, retention_limit=retention_limit)\n',1)
s=s.replace('def create_cache_settlement_session(client: object) -> CacheSettlementSession:', 'def create_cache_settlement_session(\n    client: object, *, retention_limit: int = 128\n) -> CacheSettlementSession:')
s=s.replace('''        if current is not None and current[0]() is client:
            return current[1]
        session =''','''        if current is not None and current[0]() is client:
            _owner_or_raise(current[1]).configure_retention(retention_limit)
            return current[1]
        session =''',1).replace('        owner = _CacheReuseOwner(client)','        owner = _CacheReuseOwner(client, retention_limit=retention_limit)',1);p.write_text(s)
p=r/'src/polisyos/scientist/orchestration/llm/prompt_cache.py';s=p.read_text();start=s.index('class CachingLLMClient:');tail=s[start:];tail=tail.replace('        require_reuse_authorization: bool = False,','        require_reuse_authorization: bool = False,\n        origin_retention_limit: int = 128,',1).replace('        self._cache_settlement_session = bind_cache_settlement_client(cache, self)','        self._cache_settlement_session = bind_cache_settlement_client(\n            cache, self, retention_limit=origin_retention_limit\n        )',1);tail=tail.replace('                        terminal="success",','                        terminal="success",\n                        retain_for_s=self._ttl_s,',1);s=s[:start]+tail;p.write_text(s)
p=r/'src/polisyos/scientist/orchestration/llm/factory.py';s=p.read_text().replace('            ttl_s=cfg.cache_ttl_s,','            ttl_s=cfg.cache_ttl_s,\n            origin_retention_limit=cfg.cache_maxsize,',1);p.write_text(s)
p=r/'tests/unit/core/llm/test_cache_settlement.py';s=p.read_text().replace('        response_digest=hashlib.sha256(b"cached result").hexdigest(),','        response_digest=hashlib.sha256(b"cached result").hexdigest(),\n        retain_for_s=30,',1);p.write_text(s)
