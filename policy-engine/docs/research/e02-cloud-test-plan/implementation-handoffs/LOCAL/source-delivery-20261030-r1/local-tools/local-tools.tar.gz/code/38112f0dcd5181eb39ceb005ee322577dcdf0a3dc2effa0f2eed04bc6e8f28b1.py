"""Recreate the two earlier provider-shape escapes against the source-derived route."""
from __future__ import annotations
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

root=Path.cwd().resolve()
raw=root/'LOCAL/raw/e02-execution-20261027/repairs/N7-protocol-identity-r1'
source=(raw/'post/policy-engine/src/polisyos/runtime/quality/confidence_ledger.py').read_text()
probe=(raw/'adversarial_probe.py').read_text()
start=source.index('        if type(expected) is _LRU_CACHE_WRAPPER_TYPE:',source.index('def _python_typing_protocol_source_supported()'))
end=source.index('        if isinstance(expected, type) and getattr(expected, "__module__", None) == "typing":',start)
naive_cache='''        if type(expected) is _LRU_CACHE_WRAPPER_TYPE:
            return bool(
                type(actual) is _LRU_CACHE_WRAPPER_TYPE
                and matching(actual.__wrapped__, expected.__wrapped__)
                and actual.cache_info().maxsize == expected.cache_info().maxsize
                and actual.cache_parameters() == expected.cache_parameters()
                and actual() is _inspect.getattr_static
            )
'''
old_annotation='''            return (
                type(actual) is not types.ModuleType
                and matching(type(actual), expected_type)
                and matching(vars(actual), vars(expected))
            )'''
naive_annotation='''            if type(actual) is types.ModuleType:
                return (
                    getattr(actual, "__name__", None) == "annotationlib"
                    and sys.modules.get("annotationlib") is actual
                )
            return (
                matching(type(actual), expected_type)
                and matching(vars(actual), vars(expected))
            )'''
assert source.count(old_annotation)==1
variants={
    "writable-wrapper-metadata":(source[:start]+naive_cache+source[end:],
        ("FAIL ADMITTED spoofed-stdlib-cache-wrapper","HOSTILE CALLBACKS 1")),
    "module-name-proxy":(source.replace(old_annotation,naive_annotation,1),
        ("FAIL ADMITTED spoofed-annotation-provider",)),
}
old="source=ROOT/'LOCAL/raw/e02-execution-20261027/repairs/N7-protocol-identity-r1/post/policy-engine/src/polisyos/runtime/quality/confidence_ledger.py'"
assert probe.count(old)==1
result={}
for name,(variant,witnesses) in variants.items():
    src=raw/(name+"-variant.py");src.write_text(variant)
    script=raw/(name+"-probe.py")
    script.write_text(probe.replace(old,f"source=ROOT/'LOCAL/raw/e02-execution-20261027/repairs/N7-protocol-identity-r1/{src.name}'",1))
    env=dict(os.environ);env["PYTHONDONTWRITEBYTECODE"]="1"
    run=subprocess.run([sys.executable,"-B",str(script)],cwd=root,env=env,capture_output=True,timeout=60)
    stdout=raw/(name+".stdout");stdout.write_bytes(run.stdout)
    stderr=raw/(name+".stderr");stderr.write_bytes(run.stderr)
    found=all(marker.encode() in run.stdout for marker in witnesses)
    result[name]={"exit":run.returncode,"witnesses":witnesses,"all_witnesses_present":found,
        "source_sha256":hashlib.sha256(src.read_bytes()).hexdigest(),"probe_sha256":hashlib.sha256(script.read_bytes()).hexdigest(),
        "stdout_sha256":hashlib.sha256(run.stdout).hexdigest(),"stderr_sha256":hashlib.sha256(run.stderr).hexdigest()}
    print(name,"expected-admission",found,"exit",run.returncode)
result_path=raw/'shape-proxy-falsifiers.json';result_path.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
print('sha256',hashlib.sha256(result_path.read_bytes()).hexdigest())
raise SystemExit(0 if all(v['exit']==1 and v['all_witnesses_present'] for v in result.values()) else 1)
