from pathlib import Path
p=Path('LOCAL/raw/e02-execution-20261027/repairs/C48-ad01-ranked-profile-r1/postimages/policy-engine/src/polisyos/scientist/nodes/builtins/decide/policy_runtime_method_metrics.py')
s=p.read_text()
needle='\n\ndef _build_unobserved_method_metric_observation(\n'
assert s.count(needle)==1
addition='''

@dataclass(frozen=True, slots=True)
class CompletedExAnteRankProjection:
    """One recomputed candidate-grade scalar and its exact comparison contract.

    This result is not an issuer or a persistent capability. A Runtime-owned
    consumer must resolve the completed source again at every action/read.
    """

    status: Literal["selected", "verification_missing", "invalid"]
    minimized_score: float | None = None
    maximizing_coordinate: float | None = None
    comparison_contract_sha256: str | None = None
    limitations: tuple[str, ...] = ()
    authority_status: Literal["candidate_only"] = "candidate_only"

    def __post_init__(self) -> None:
        if self.status == "selected":
            if (
                self.minimized_score is None
                or not math.isfinite(self.minimized_score)
                or self.maximizing_coordinate != -self.minimized_score
                or not self.comparison_contract_sha256
                or self.limitations
            ):
                raise ValueError("selected_ex_ante_rank_projection_requires_recomputed_basis")
        elif (
            self.minimized_score is not None
            or self.maximizing_coordinate is not None
            or self.comparison_contract_sha256 is not None
            or not self.limitations
        ):
            raise ValueError("limited_ex_ante_rank_projection_requires_reason_only")


def _ex_ante_rank_comparison_contract(
    *,
    observation: MethodMetricObservation,
    execution_context: Any,
    capture: Any,
    environment: dict[str, Any] | None,
) -> dict[str, Any] | None:
    """Partition only the registered paired-array profile after full AD01 replay.

    Actual baseline bytes, both array layouts, complete resolved parameters,
    backend/seed contract, source environment and objective/measurement rules
    remain in the comparison. The verified scenario bytes may differ between
    candidates. This helper does not authenticate a caller or issue authority.
    """
    from polisyos.ir.kernel.method_metrics import METHOD_METRIC_EX_ANTE_MEAN_CHANGE_LAW_ID

    if (
        observation.source_status != "observed"
        or observation.method_fqn != "policy.evaluation.ex_ante_simulation@1.0.0"
        or observation.method_version != "1.0.0"
        or observation.law_id != METHOD_METRIC_EX_ANTE_MEAN_CHANGE_LAW_ID
        or observation.configured_objective_count != 1
        or observation.objective_spec_sha256 is None
        or observation.objective_direction not in {"minimize", "maximize"}
        or observation.objective_target_present is not False
        or observation.method_build_digest_scope != "class_source_only"
        or observation.method_build_digest is None
        or environment is None
        or execution_context.parameter_resolution_status != "captured"
        or any(row.status != "captured" for row in execution_context.parameter_values)
        or execution_context.prestate_identity_status != "captured"
        or execution_context.backend_identity_status != "reconciled"
        or execution_context.backend_trace_status != "captured"
        or execution_context.fallback_status != "not_fell_back"
        or execution_context.seed_status != "reconciled"
        or set(execution_context.signature_input_slot_ids) != {"baseline", "scenario"}
        or set(execution_context.signature_parameter_names) != {"poverty_line"}
    ):
        return None
    slots = {slot.slot_id: slot for slot in capture.slots}
    if set(slots) != {"baseline", "scenario"} or len(capture.slots) != 2:
        return None
    if slots["baseline"].shape != slots["scenario"].shape:
        return None
    role_values = {
        (item.role_id, item.method_input_slot_id): item.value_sha256
        for item in execution_context.input_role_values
    }
    if role_values != {
        ("baseline", "baseline"): slots["baseline"].value_sha256,
        ("scenario", "scenario"): slots["scenario"].value_sha256,
    }:
        return None
    # Retain the complete typed observation except selected run-specific refs,
    # values and execution digest, which the AD01 owner has just revalidated.
    observation_contract = observation.model_dump(
        mode="json",
        exclude={
            "binding_set_ref", "execution_bundle_ref", "simulation_result_ref",
            "environment_manifest_ref", "output_ref", "input_capture_ref",
            "occurrence_id", "invocation_id", "value", "checked_context_sha256",
            "predicate_evidence",
        },
    )
    # Reconciled predicate classes and limitations remain part of the contract;
    # source-specific evidence refs/digests were independently replayed above.
    observation_contract["predicate_evidence"] = [
        {"predicate_id": row.predicate_id, "classification": row.classification, "limitation": row.limitation}
        for row in observation.predicate_evidence
    ]
    execution = execution_context.model_dump(
        mode="json",
        exclude={
            "started_at", "completed_at", "dispatch_elapsed_ms", "runner_wall_time_ms",
            "runner_cpu_time_ms", "runner_compile_time_ms", "prestate_identity_sha256",
            "input_slot_values", "input_role_values",
        },
    )
    baseline = slots["baseline"].model_dump(mode="json")
    scenario = slots["scenario"].model_dump(mode="json", exclude={"value_sha256"})
    return {
        "profile": "completed_ex_ante_single_objective_v1",
        "observation": observation_contract,
        "execution": execution,
        "environment": environment,
        "baseline": baseline,
        "scenario_layout": scenario,
    }


def recompute_completed_ex_ante_rank_projection(
    store: _MethodMetricProjectionArtifactStore,
    *,
    basis: object | None,
    candidate_ref: ArtifactRef | None,
) -> CompletedExAnteRankProjection:
    """Replay a freshly selected owner basis for one candidate-only rank coordinate.

    ``basis`` must come from the completed Runtime owner read in the same
    authorized consumer. This helper accepts no persisted source/profile claim.
    It does not authenticate a structural owner passed to that earlier read.
    """
    from polisyos.scientist.methods.search.objective import ObjectiveScoreStatus

    if type(basis) is not _CompletedMethodMetricProjectionBasis:
        return CompletedExAnteRankProjection(
            status="verification_missing", limitations=("completed_method_metric_basis_missing",)
        )
    score = admit_completed_method_metric_objective_score(
        basis, candidate_ref=candidate_ref, request_status="requested"
    )
    if (
        score is None
        or score.status is not ObjectiveScoreStatus.AVAILABLE
        or score.predicate_status != "recomputed"
        or score.reported_assessment != score.recomputed_assessment
        or score.recomputed_assessment is None
        or score.recomputed_assessment.value is None
    ):
        return CompletedExAnteRankProjection(
            status="verification_missing", limitations=("completed_whole_objective_not_available",)
        )
    try:
        selected_candidate = _selected_ref(candidate_ref, kind="scientist.policy_design.candidate")
        if not _same_selected_ref(selected_candidate, basis.candidate_ref):
            raise _InvalidProjectionError("completed_rank_candidate_mismatch")
        source_tuple = _MethodMetricSourceTuple(
            job_id=basis.source_job_id,
            run_id=basis.source_run_id,
            attempt=basis.source_attempt,
            method_result_ref=None,
            simulation_result_ref=basis.simulation_result_ref.materialize(),
            method_execution_bundle_ref=basis.method_execution_bundle_ref.materialize(),
            method_metric_binding_set_ref=basis.method_metric_binding_set_ref.materialize(),
        )
        budget = _ProjectionReadBudget()
        replay_candidate = _admit_execution_source_candidate(
            store, source_tuple=source_tuple, read_budget=budget
        )
        if not _same_selected_ref(replay_candidate, selected_candidate):
            raise _InvalidProjectionError("completed_rank_candidate_replay_mismatch")
        contracts: list[dict[str, Any]] = []
        replayed = _admit_method_metric_observations(
            store, source_tuple=source_tuple, read_budget=budget, comparison_collector=contracts
        )
        if replayed != basis.observations:
            raise _InvalidProjectionError("completed_rank_selected_observation_replay_mismatch")
        if len(replayed) != 1 or len(contracts) != 1:
            return CompletedExAnteRankProjection(
                status="verification_missing", limitations=("completed_ex_ante_profile_not_supported",)
            )
        minimized = float(score.recomputed_assessment.value)
        if not math.isfinite(minimized):
            raise _InvalidProjectionError("completed_rank_score_not_finite")
        return CompletedExAnteRankProjection(
            status="selected", minimized_score=minimized, maximizing_coordinate=-minimized,
            comparison_contract_sha256=_canonical_sha256(contracts[0]),
        )
    except _UnestablishedProjectionError as exc:
        return CompletedExAnteRankProjection(status="verification_missing", limitations=(str(exc),))
    except (AttributeError, KeyError, OSError, RuntimeError, TypeError, ValueError):
        return CompletedExAnteRankProjection(
            status="invalid", limitations=("completed_rank_source_replay_invalid",)
        )
'''
s=s.replace(needle,addition+needle,1)
p.write_text(s)
