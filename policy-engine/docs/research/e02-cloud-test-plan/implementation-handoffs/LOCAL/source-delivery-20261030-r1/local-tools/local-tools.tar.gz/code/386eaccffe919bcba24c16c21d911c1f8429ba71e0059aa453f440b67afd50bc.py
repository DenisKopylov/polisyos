from pathlib import Path
base=Path('LOCAL/raw/e02-execution-20261027/repairs/C52-r4/postimages/policy-engine/src/polisyos/foundry/execute')
p=base/'_internal/snapshots/__init__.py'
s=p.read_text()
start=s.index('def _read_npz_entry_count(')
end=s.index('def read_state_snapshot_inputs_bounded(',start)
s=s[:start]+'''class BoundedNumericNPZError(ValueError):
    """One bounded numeric NPZ refusal with observed and allowed extents."""

    def __init__(self, reason: str, *, observed_bytes: int | None = None, limit_bytes: int = 0) -> None:
        super().__init__(reason)
        self.reason = reason
        self.observed_bytes = observed_bytes
        self.limit_bytes = limit_bytes


def _read_npz_entry_count(blob: bytes) -> int:
    """Read the ZIP central-directory count from a size-bounded NPZ trailer."""
    start = max(0, len(blob) - 65_557)
    end_record = blob.rfind(b"PK\\x05\\x06", start)
    if end_record < 0 or end_record + 22 > len(blob):
        raise BoundedNumericNPZError("npz_end_record_missing")
    (signature, disk, central_disk, disk_entries, total_entries, central_size,
     central_offset, comment) = struct.unpack_from("<4s4H2LH", blob, end_record)
    if (
        signature != b"PK\\x05\\x06" or disk != 0 or central_disk != 0
        or disk_entries != total_entries or total_entries == 0xFFFF
        or central_size == 0xFFFFFFFF or central_offset == 0xFFFFFFFF
        or end_record + 22 + comment != len(blob)
        or central_offset + central_size > end_record
    ):
        raise BoundedNumericNPZError("npz_layout_unsupported")
    return total_entries


def read_numeric_npz_bounded(
    blob: bytes, *, names: tuple[str, ...], max_entries: int, max_elements: int,
    max_member_bytes: int, ndim: int, allow_empty: bool = False,
    exact_dtype: str | None = None,
) -> tuple[np.ndarray, ...]:
    """Decode exactly named stored numeric arrays under input and allocation bounds.

    Args:
        blob: Complete already-bounded immutable NPZ bytes.
        names: Exact ordered array basenames, without extensions.
        max_entries: Maximum archive members.
        max_elements: Maximum total numeric values across arrays.
        max_member_bytes: Maximum archive and each uncompressed member length.
        ndim: Required number of dimensions for all arrays.
        allow_empty: Permit zero rows only for a two-dimensional matrix.
        exact_dtype: Optional exact NumPy dtype string, such as ``<f4``.

    Returns:
        Read-only arrays in the supplied name order.

    Raises:
        BoundedNumericNPZError: When any count, format or content is unsupported.
    """
    if (
        type(blob) is not bytes or type(names) is not tuple or not names
        or any(not _is_snapshot_slot_id(name) for name in names)
        or len(set(names)) != len(names)
        or any(type(v) is not int or v < 1 for v in (max_entries, max_elements, max_member_bytes, ndim))
        or type(allow_empty) is not bool or (allow_empty and ndim != 2)
        or (exact_dtype is not None and type(exact_dtype) is not str)
    ):
        raise BoundedNumericNPZError("npz_contract_invalid")
    if len(blob) > max_member_bytes:
        raise BoundedNumericNPZError("npz_entry_codec_or_size_unsupported", observed_bytes=len(blob), limit_bytes=max_member_bytes)
    entry_count = _read_npz_entry_count(blob)
    if entry_count > max_entries:
        raise BoundedNumericNPZError("npz_entry_limit_exceeded", observed_bytes=entry_count, limit_bytes=max_entries)
    elements = 0
    arrays_by_name: dict[str, np.ndarray] = {}
    try:
        with ZipFile(BytesIO(blob)) as archive:
            infos = archive.infolist()
            archive_names = tuple(info.filename for info in infos)
            expected = {f"{name}.npy" for name in names}
            if len(infos) != entry_count or len(set(archive_names)) != len(archive_names) or set(archive_names) != expected:
                raise BoundedNumericNPZError("npz_slot_inventory_mismatch")
            for info in infos:
                if info.compress_type != ZIP_STORED or info.file_size > max_member_bytes:
                    raise BoundedNumericNPZError("npz_entry_codec_or_size_unsupported", observed_bytes=info.file_size, limit_bytes=max_member_bytes)
                with archive.open(info) as entry:
                    version = np.lib.format.read_magic(entry)
                    if version == (1, 0):
                        shape, fortran_order, dtype = np.lib.format.read_array_header_1_0(entry, max_header_size=10_000)
                    elif version == (2, 0):
                        shape, fortran_order, dtype = np.lib.format.read_array_header_2_0(entry, max_header_size=10_000)
                    else:
                        raise BoundedNumericNPZError("npz_npy_version_unsupported")
                    shape = tuple(int(size) for size in shape)
                    dtype = np.dtype(dtype)
                    count = math.prod(shape) if shape else 1
                    raw_size = count * dtype.itemsize
                    empty_ok = allow_empty and len(shape) == 2 and shape[0] == 0 and shape[1] > 0
                    if (
                        len(shape) != ndim or any(size < 0 for size in shape)
                        or (count <= 0 and not empty_ok) or dtype.hasobject
                        or dtype.kind not in {"i", "u", "f"} or fortran_order
                        or (exact_dtype is not None and dtype.str != exact_dtype)
                        or count > max_elements - elements or raw_size > max_member_bytes
                        or entry.tell() + raw_size != info.file_size
                    ):
                        raise BoundedNumericNPZError("npz_array_shape_or_byte_limit_exceeded", observed_bytes=raw_size, limit_bytes=max_member_bytes)
                    raw = entry.read(raw_size + 1)
                    if len(raw) != raw_size:
                        raise BoundedNumericNPZError("npz_array_length_mismatch")
                    array = np.frombuffer(raw, dtype=dtype).reshape(shape).copy(order="C")
                    if dtype.kind == "f" and not np.isfinite(array).all():
                        raise BoundedNumericNPZError("npz_array_non_finite")
                    array.setflags(write=False)
                    arrays_by_name[info.filename[:-4]] = array
                    elements += count
    except BoundedNumericNPZError:
        raise
    except (BadZipFile, OSError, EOFError, ValueError, TypeError) as exc:
        raise BoundedNumericNPZError("npz_decode_failed") from exc
    return tuple(arrays_by_name[name] for name in names)


''' +s[end:]
start=s.index('    try:\n        entry_count = _read_npz_entry_count(bytes(blob_bytes))')
end=s.index('    usage = current_usage()',start)
s=s[:start]+'''    try:
        decoded = read_numeric_npz_bounded(
            bytes(blob_bytes), names=slot_ids, max_entries=max_entries,
            max_elements=max_elements, max_member_bytes=max_state_blob_bytes, ndim=1,
        )
    except BoundedNumericNPZError as exc:
        refuse(f"state_snapshot_{exc.reason}", observed_bytes=exc.observed_bytes, limit_bytes=exc.limit_bytes)
    entry_count = len(decoded)
    arrays = list(zip(slot_ids, decoded, strict=True))
    elements = sum(array.size for array in decoded)
''' +s[end:]
s=s.replace('''    "BoundedStateSnapshotInputs",''','''    "BoundedNumericNPZError",
    "BoundedStateSnapshotInputs",''',1).replace('''    "read_state_snapshot_inputs_bounded",''','''    "read_numeric_npz_bounded",
    "read_state_snapshot_inputs_bounded",''',1)
p.write_text(s)
p=base/'__init__.py'
s=p.read_text().replace('''    "BoundedStateSnapshotInputs",''','''    "BoundedNumericNPZError",
    "BoundedStateSnapshotInputs",''',1).replace('''    "read_state_snapshot_inputs_bounded",''','''    "read_numeric_npz_bounded",
    "read_state_snapshot_inputs_bounded",''',1)
s=s.replace('''_LAZY_IMPORTS: dict[str, tuple[str, str]] = {''','''_LAZY_IMPORTS: dict[str, tuple[str, str]] = {
    "BoundedNumericNPZError": ("polisyos.foundry.execute._internal.snapshots", "BoundedNumericNPZError"),
    "read_numeric_npz_bounded": ("polisyos.foundry.execute._internal.snapshots", "read_numeric_npz_bounded"),''')
p.write_text(s)
