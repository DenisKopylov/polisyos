"""Recompute bounded-capture receipt consistency against fresh source identities."""
from __future__ import annotations
import hashlib
from pathlib import Path
from typing import Any


def qualify_capture(value: dict[str, Any], root: Path, index: dict[str, str], overlay: str, overlay_sha: str) -> list[str]:
    """Reject absent, incomplete, foreign, changed or unbound actual-code rows."""
    report = value.get('bounded_code_capture')
    if not isinstance(report, dict):return ['bounded capture absent']
    problems = []
    rows = report.get('codes');non_targets = report.get('distinct_disabled_non_targets')
    if not isinstance(rows,list) or type(non_targets) is not int:return ['bounded capture set malformed']
    if report.get('errors') != []:problems.append('bounded capture errors')
    if report.get('callback_invocations') != len(rows) + non_targets:problems.append('callback denominator differs')
    if report.get('distinct_captured_codes') != len(rows):problems.append('code denominator differs')
    if report.get('code_census_complete_for_observed_events') is not True:problems.append('actual code incomplete')
    files = {}
    for row in rows:
        if not isinstance(row,dict):problems.append('code row malformed');continue
        rel = row.get('relative_path')
        if not isinstance(rel,str) or Path(rel).is_absolute() or '..' in Path(rel).parts or not rel.startswith(('policy-engine/src/','policy-engine/tests/','policy-engine/tools/')):
            problems.append('code path outside admitted roots');continue
        path = root / rel
        if path.is_symlink() or not path.is_file():problems.append('actual source unavailable');continue
        if rel not in files:
            data = path.read_bytes();files[rel] = (hashlib.sha256(data).hexdigest(),hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data,usedforsecurity=False).hexdigest())
        sha,blob = files[rel]
        expected = blob if rel == overlay and sha == overlay_sha else index.get(rel)
        if row.get('source_sha256') != sha or row.get('git_blob') != blob or row.get('expected_blob') != expected or blob != expected:
            problems.append('actual source or Git binding differs')
        if row.get('origin_error') or row.get('compilation_match') is not True:
            problems.append('actual module/code admission failed')
        if Path(str(row.get('resolved_path',''))).resolve() != path.resolve():problems.append('resolved code path differs')
    return problems
