from pathlib import Path
OUT=Path(__file__).resolve().parent;P=OUT/'postimages/policy-engine/src/polisyos/foundry/calibration/calibrator.py';s=P.read_text()
def repl(old,new,count=1):
 global s
 assert s.count(old)==count,(old[:100],s.count(old));s=s.replace(old,new)
repl('    CALIBRATION_RUNTIME_INPUT_NAMES,','    CALIBRATION_RUNTIME_INPUT_CONTRACT_V1_2,\n    CALIBRATION_RUNTIME_INPUT_NAMES_V1_2,')
repl('    CalibrationExecutionInputBasis,','    CalibrationExecutionInputBasis,\n    CalibrationOrderedBatchInput,\n    CalibrationOrderedBatchRow,')
repl('    TrainableParamRef,','    TrainableParamRef,\n    TargetLossConfig,')
start=s.index('def evaluate_ordered_batch_objective(');end=s.index('\n\njax.tree_util.register_dataclass(',start)
s=s[:start]+'''def _ordered_batch_loss(
    predictions: jax.Array,
    profile: OrderedBatchCalibrationProfile,
    loss_config: TargetLossConfig,
) -> tuple[jax.Array, jax.Array]:
    """Apply the existing pointwise loss and a finite positive row reduction."""
    targets = jnp.asarray(profile.targets)
    weights = jnp.asarray(profile.weights)
    pointwise = pointwise_base_loss(predictions, targets, loss_config, 1.0)
    support = jnp.sum(weights)
    inputs_valid = (
        jnp.all(jnp.isfinite(targets))
        & jnp.all(jnp.isfinite(weights))
        & jnp.all(weights >= 0)
        & jnp.isfinite(support)
        & (support > 0)
        & jnp.all(jnp.isfinite(predictions))
    )
    safe_support = jnp.where(inputs_valid, support, jnp.ones_like(support))
    candidate = jnp.sum(weights * pointwise) / safe_support
    valid = inputs_valid & jnp.isfinite(candidate)
    return jnp.where(valid, candidate, jnp.inf), valid


def evaluate_ordered_batch_objective(
    profile: OrderedBatchCalibrationProfile,
    *,
    bundle: StaticBundle,
    loss_config: TargetLossConfig | None = None,
) -> OrderedBatchCalibrationEvaluation:
    """Evaluate ordered scalar rows with an explicit transformed validity result.

    Dynamic invalid targets, weights, support, predictions or reductions return
    ``objective=inf`` and ``valid=False``. Shape, key dtype and unsupported
    configured loss contracts refuse before execution. A finite curvature is
    a numerical diagnostic and supplies no inferential covariance or noise law.
    """
    rows = len(profile.row_ids)
    if rows == 0 or any(not row.strip() for row in profile.row_ids):
        raise ValueError("batch row_ids must be non-empty strings")
    if len(set(profile.row_ids)) != rows:
        raise ValueError("batch row_ids must be unique")
    config = loss_config or TargetLossConfig(relative=False)
    if config.kind != "mse" or config.relative:
        raise ValueError("ordered batch helper supports absolute MSE only")
    if not np.isfinite(config.epsilon) or config.epsilon < 0:
        raise ValueError("ordered batch loss epsilon must be finite and nonnegative")
    times = jnp.asarray(profile.row_times)
    keys = jnp.asarray(profile.row_keys)
    targets = jnp.asarray(profile.targets)
    weights = jnp.asarray(profile.weights)
    if times.shape != (rows,) or not jnp.issubdtype(times.dtype, jnp.integer):
        raise ValueError(f"batch row_times must be an integer vector of shape ({rows},)")
    if keys.shape != (rows, 2) or keys.dtype != jnp.uint32:
        raise ValueError(f"batch row_keys must have uint32 shape ({rows}, 2)")
    if targets.shape != (rows,) or weights.shape != (rows,):
        raise ValueError(f"batch targets and weights must have shape ({rows},)")
    if targets.dtype.kind not in "iuf" or weights.dtype.kind not in "iuf":
        raise ValueError("batch targets and weights must use real numeric dtypes")
    final_states, final_keys = apply_nodes_batch(profile.states, times, keys, bundle=bundle)
    value: Any = final_states
    for part in profile.target_path.split("."):
        value = getattr(value, part)
    predictions = jnp.asarray(value)
    if predictions.shape != (rows,):
        raise ValueError("batch target_path must resolve to exactly one scalar per row")
    objective, valid = _ordered_batch_loss(predictions, profile, config)
    valid = valid & jnp.all(times >= 0)
    for leaf in jax.tree_util.tree_leaves(profile.states):
        valid = valid & jnp.all(jnp.isfinite(leaf))
    objective = jnp.where(valid, objective, jnp.inf)
    return OrderedBatchCalibrationEvaluation(
        objective, predictions, final_states, final_keys, valid
    )
''' +s[end:]
repl('    fidelity_force_override: bool\n','    fidelity_force_override: bool\n    objective_input_sha256: str | None = None\n')
repl('    steps: int,\n) -> _HessianReuseKey:', '    steps: int,\n    objective_input_sha256: str | None = None,\n) -> _HessianReuseKey:')
repl('        fidelity_force_override=bool(config.fidelity.force_override),','        fidelity_force_override=bool(config.fidelity.force_override),\n        objective_input_sha256=objective_input_sha256,')
repl('    if input_names != CALIBRATION_RUNTIME_INPUT_NAMES:', '    if input_names != CALIBRATION_RUNTIME_INPUT_NAMES_V1_2:')
repl('    for name, usage, source_role in CALIBRATION_RUNTIME_INPUT_CONTRACT:', '''    runtime_contract = (
        CALIBRATION_RUNTIME_INPUT_CONTRACT_V1_2
        if ordered_profile_basis is not None
        else CALIBRATION_RUNTIME_INPUT_CONTRACT
    )
    for name, usage, source_role in runtime_contract:''')
repl('        if name == "ordered_batch_profile" and inputs.ordered_batch_profile is None:\n            continue\n','')
repl('        if name in {"constraint_registry", "constraint_values"}:','''        if name == "ordered_batch_profile":
            assert ordered_profile_basis is not None
            resolved_by = ("ordered_batch_profile",)
            value_digest_override = ordered_profile_basis.consumed_profile_sha256
        elif name in {"constraint_registry", "constraint_values"}:''')
start=s.index('    ordered_profile_basis = None\n');end=s.index('    basis = CalibrationExecutionInputBasis(',start)
s=s[:start]+s[end:]
# Prepare selected row artifacts before the roster, using the same snapshotted inputs as fit.
anchor='    active_target_queries = any(target.fabric_query is not None for target in inputs.config.targets)'
rows='''    ordered_profile_basis = None
    ordered_row_input_refs: list[InputRef] = []
    if inputs.ordered_batch_profile is not None:
        profile = inputs.ordered_batch_profile
        row_inputs = []
        for ordinal, row_id in enumerate(profile.row_ids):
            row_state = jax.tree_util.tree_map(lambda leaf: leaf[ordinal], profile.states)
            row_ref = put_state_snapshot(
                store, state=row_state, step=int(profile.row_times[ordinal]),
                return_selected_profile=True,
            )
            row_inputs.append(CalibrationOrderedBatchRow(
                row_id=row_id,
                state_snapshot_ref=row_ref,
                state_values_sha256=canonical_input_sha256(row_state),
            ))
            ordered_row_input_refs.append(
                input_ref_from_artifact_ref(row_ref, role=f"ordered_batch_row.{ordinal}")
            )
        target = inputs.config.targets[0]
        ordered_profile_basis = CalibrationOrderedBatchInput(
            target_id=target.target_id,
            target_metric_id=target.model_metric_path,
            target_path=profile.target_path,
            rows=tuple(row_inputs),
            row_times=tuple(np.asarray(profile.row_times).tolist()),
            row_times_dtype=str(np.asarray(profile.row_times).dtype),
            row_keys=tuple(tuple(row) for row in np.asarray(profile.row_keys).tolist()),
            targets=tuple(np.asarray(profile.targets).tolist()),
            targets_dtype=str(np.asarray(profile.targets).dtype),
            weights=tuple(np.asarray(profile.weights).tolist()),
            weights_dtype=str(np.asarray(profile.weights).dtype),
            consumed_profile_sha256=canonical_input_sha256(profile),
            loss_epsilon=target.loss.epsilon,
            target_priority=target.loss.weight,
        )
'''
repl(anchor,rows+'\n'+anchor)
repl('        *state_blob_inputs,','        *state_blob_inputs,\n        *ordered_row_input_refs,')
# Declare unsupported combinations before the actual fit; ordinary scalar path untouched.
repl('            if target.model_metric_path != batch_profile.target_path:', '            if path_by_target[target.target_id] != batch_profile.target_path:')
repl('                or self.inputs.aux_loss_components\n', '''                or self.inputs.aux_loss_components
                or self.inputs.measurement_loss_adapter is not None
                or self.inputs.measurement_loss_config is not None
                or self.inputs.raw_targets
                or self.inputs.udf_engine is not None
                or self.inputs.target_fetcher is not None
                or target.fabric_query is not None
                or cfg.seed_strategy != "fixed"
                or cfg.multi_start is not None
                or cfg.constraint_loss.enabled
''')
repl('            initial_batch = evaluate_ordered_batch_objective(batch_profile, bundle=bundle)', '''            initial_batch = evaluate_ordered_batch_objective(
                batch_profile, bundle=bundle, loss_config=target.loss
            )
            if not np.isfinite(target.loss.weight) or target.loss.weight <= 0:
                raise ValueError("ordered_batch_profile requires positive finite target priority")
            rows = len(batch_profile.row_ids)
            if cfg.steps not in (None, rows):
                raise ValueError("ordered_batch_profile steps must equal its row count")
            if cfg.time_axis is not None and list(cfg.time_axis) != [
                float(t) for t in batch_profile.row_times
            ]:
                raise ValueError("ordered_batch_profile forbids target resampling or reordering")''')
repl('        if measurement_bundle is None:\n            fetched_target_ids: set[str] = set()\n            if batch_profile is not None:\n                raw_targets[targets[0].target_id] = batch_profile.targets\n            elif self.inputs.raw_targets:', '''        if batch_profile is not None:
            target_id = targets[0].target_id
            steps = len(batch_profile.row_ids)
            aligned_targets = {target_id: batch_profile.targets}
            scales = {target_id: 1.0}
            time_axes = {target_id: [float(t) for t in batch_profile.row_times]}
            fetched_target_ids: set[str] = set()
        elif measurement_bundle is None:
            fetched_target_ids = set()
            if self.inputs.raw_targets:''')
# Capture is no longer mislabeled as a target fetch when explicit rows supply observations.
repl('                if measurement_bundle is not None and target_id in aligned_targets:', '                if batch_profile is not None:\n                    source_kind = "ordered_batch_profile"\n                elif measurement_bundle is not None and target_id in aligned_targets:')
repl('        measurement_enabled = measurement_bundle is not None\n', '''        measurement_enabled = measurement_bundle is not None
        batch_objective_identity = (
            canonical_input_sha256({"profile": batch_profile, "config": cfg})
            if batch_profile is not None else None
        )
''')
repl('                    bundle=sim_bundle,\n                )\n                return {batch_profile.target_path:', '                    bundle=sim_bundle,\n                    loss_config=targets[0].loss,\n                )\n                return {batch_profile.target_path:')
a=s.index('            if batch_profile is not None:\n                predictions =',s.index('        def _base_vec_from_traces('));b=s.index('            losses = []',a)
s=s[:a]+'''            if batch_profile is not None:
                value, valid = _ordered_batch_loss(
                    jnp.asarray(traces[batch_profile.target_path]), batch_profile, targets[0].loss
                )
                return jnp.asarray([jnp.where(valid, value, jnp.inf)])
'''+s[b:]
# Both actual per-start and selected final Hessian identities bind the full objective input.
repl('                steps=steps,\n            )\n            flat_theta', '                steps=steps,\n                objective_input_sha256=batch_objective_identity,\n            )\n            flat_theta') if False else None
# Exact key call endings differ by indentation; replace AST-local steps keyword only.
import ast
module=ast.parse(s);lines=s.splitlines(keepends=True)
for call in sorted([n for n in ast.walk(module) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='_make_hessian_reuse_key'],key=lambda n:n.lineno,reverse=True):
 line=next(k.lineno for k in call.keywords if k.arg=='steps')-1
 indent=lines[line][:len(lines[line])-len(lines[line].lstrip())]
 lines.insert(line+1,indent+'objective_input_sha256=batch_objective_identity,\n')
s=''.join(lines)
# Consumers of fit_quality receive the same effective rows/weights as the fit.
repl('        def _fit_metrics(model_series: Any, real_series: Any) -> CalibrationFitMetrics:', '        def _fit_metrics(\n            model_series: Any, real_series: Any, row_weights: Any | None = None\n        ) -> CalibrationFitMetrics:')
repl('            diff = model_arr - real_arr\n            mse = float(np.mean(diff**2))', '''            diff = model_arr - real_arr
            if row_weights is not None:
                weight_arr = np.asarray(row_weights, dtype=float)
                if weight_arr.shape != diff.shape:
                    raise ValueError("ordered fit metric weights must match complete row shape")
                support = float(weight_arr.sum())
                mse = float(np.sum(weight_arr * diff**2) / support)
                mae = float(np.sum(weight_arr * np.abs(diff)) / support)
                mean = float(np.sum(weight_arr * real_arr) / support)
                denom = float(np.sum(weight_arr * (real_arr - mean)**2))
                r2 = None if denom <= 0 else float(1 - np.sum(weight_arr * diff**2) / denom)
                return CalibrationFitMetrics(
                    mse=mse, rmse=float(np.sqrt(mse)), mae=mae, r2=r2,
                    n=int(np.count_nonzero(weight_arr > 0)),
                )
            mse = float(np.mean(diff**2))''')
repl('            per_target_metrics[target_id] = _fit_metrics(model_list, real_list)', '''            per_target_metrics[target_id] = _fit_metrics(
                model_list, real_list,
                batch_profile.weights if batch_profile is not None else None,
            )''')
repl('        if all_real:\n            aggregate_metrics = _fit_metrics(np.concatenate(all_model), np.concatenate(all_real))', '''        if batch_profile is not None:
            aggregate_metrics = per_target_metrics[targets[0].target_id]
        elif all_real:
            aggregate_metrics = _fit_metrics(np.concatenate(all_model), np.concatenate(all_real))''')
P.write_text(s)
