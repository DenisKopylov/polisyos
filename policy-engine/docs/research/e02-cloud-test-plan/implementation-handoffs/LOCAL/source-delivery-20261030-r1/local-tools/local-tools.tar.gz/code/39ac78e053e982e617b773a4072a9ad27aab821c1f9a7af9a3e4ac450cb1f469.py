from pathlib import Path
p=Path('LOCAL/raw/e02-execution-20261027/repairs/C46-r2/postimages/policy-engine/src/polisyos/scientist/governance/blueprint_release.py')
s=p.read_text()
def replace(old,new):
 global s
 n=s.count(old)
 if n!=1: raise ValueError(f'{n}: {old[:100]!r}')
 s=s.replace(old,new,1)
replace('''    UKRAINE_D4_SOURCE_JSON_SNAPSHOT_ROLE_BY_CONTRACT,
    ArtifactRecord,''','''    UKRAINE_D4_SOURCE_JSON_SNAPSHOT_ROLE_BY_CONTRACT,
    UKRAINE_PERIOD_PROJECTION_VERSION,
    ArtifactRecord,''')
replace('''    load_verified_stage_output_bytes,
)
from polisyos.foundry''','''    load_verified_stage_output_bytes,
    project_ukraine_observation_periods,
)
from polisyos.foundry''')
replace('''from polisyos.ir.governance.gate import GateDecision''','''from polisyos.ir import TimeFrequency
from polisyos.ir.governance.gate import GateDecision''')
replace('''    families: dict[str, FamilyEligibilityEntry] = {}
    waived_set = set(waived_families)''','''    observation_panel = _reconcile_ukraine_period_projection(observation_panel)
    families: dict[str, FamilyEligibilityEntry] = {}
    waived_set = set(waived_families)''')
replace('''        reasons: list[str] = []
        tier = FamilyTier.A
        has_proxy_lineage = proxy_count > 0''','''        reasons: list[str] = []
        tier = FamilyTier.A
        period_status = family_frame["period_disposition"].astype("string")
        unresolved = period_status != "valid"
        if bool(unresolved.fillna(True).any()):
            tier = FamilyTier.B
            reasons.extend(
                family_frame.loc[unresolved.fillna(True), "period_reason"]
                .dropna()
                .astype(str)
                .unique()
                .tolist()
            )
        has_proxy_lineage = proxy_count > 0''')
replace('''        if kind_frame["period_start_dt"].isna().any():
            bundles[kind] = BacktestPlanBundle(''','''        if kind_frame["period_start_dt"].isna().any():
            period_reasons = (
                sorted(set(kind_frame.loc[
                    kind_frame["period_start_dt"].isna(), "period_reason"
                ].dropna().astype(str)))
                if "period_reason" in kind_frame.columns
                else []
            )
            period_gap = f"intervention_time_axis_unresolved:{kind.value}"
            if period_reasons:
                period_gap += ":" + ",".join(period_reasons)
            bundles[kind] = BacktestPlanBundle(''')
replace('''                gap_reason=f"intervention_time_axis_unresolved:{kind.value}",
            )
            continue
        aggregated = (''','''                gap_reason=period_gap,
            )
            continue
        aggregated = (''')
start=s.index('def _household_distribution_observation_panel(')
end=s.index('\n\ndef run_verified_ukraine_d4_governance(',start)
s=s[:start]+'''def _reconcile_ukraine_period_projection(
    frame: pd.DataFrame,
    *,
    fixed_time_grain: TimeFrequency | None = None,
) -> pd.DataFrame:
    """Recompute period facts from the source IDs; preserve legacy limitations."""
    original_index = frame.index
    work = frame.reset_index(drop=True).copy()
    had_period_id = "period_id" in work.columns
    had_time_grain = "time_grain" in work.columns or fixed_time_grain is not None
    if fixed_time_grain is not None:
        work["time_grain"] = fixed_time_grain.value
    for column in (
        "period_id", "period_start", "period_end", "period_disposition", "period_reason",
        "period_projection_version", "time_grain",
    ):
        if column not in work.columns:
            work[column] = pd.NA
    work["period_source_projection_version"] = work["period_projection_version"].astype("string")

    marker = work["period_disposition"].astype("string")
    version = work["period_projection_version"].astype("string")
    declared = marker.notna() | version.notna() | work["period_reason"].notna()
    already_unavailable = marker.eq("not_established").fillna(False) & version.isna()
    declared = declared & ~already_unavailable
    available = (
        work["time_grain"].notna()
        & had_period_id
        & had_time_grain
        & ~already_unavailable
    )
    if bool((declared & ~available).any()):
        raise UkraineStageArtifactVerificationError("period_projection_incomplete")
    unavailable = ~available
    work.loc[unavailable, "period_disposition"] = "not_established"
    work.loc[unavailable, "period_reason"] = "period_projection_not_established"
    work.loc[unavailable, "period_projection_version"] = pd.NA
    work.loc[unavailable, "period_projection_provenance"] = "legacy_unavailable"

    names = ("period_start", "period_end", "period_disposition", "period_reason")
    for grain, indexes in work.loc[available].groupby("time_grain", sort=False).groups.items():
        try:
            frequency = TimeFrequency(str(grain))
        except ValueError as exc:
            raise UkraineStageArtifactVerificationError("period_projection_invalid_frequency") from exc
        projected = project_ukraine_observation_periods(
            work.loc[indexes, "period_id"], time_grain=frequency
        )
        declared_indexes = [index for index in indexes if bool(declared.loc[index])]
        if declared_indexes:
            if not bool(
                version.loc[declared_indexes].eq(UKRAINE_PERIOD_PROJECTION_VERSION)
                .fillna(False).all()
            ):
                raise UkraineStageArtifactVerificationError("period_projection_incomplete")
            for name, expected in zip(names, projected, strict=True):
                actual = work.loc[declared_indexes, name].astype("string")
                target = expected.loc[declared_indexes].astype("string")
                if not actual.equals(target):
                    raise UkraineStageArtifactVerificationError(
                        f"period_projection_mismatch:{name}"
                    )
        for name, expected in zip(names, projected, strict=True):
            work.loc[indexes, name] = expected
        work.loc[indexes, "period_projection_version"] = UKRAINE_PERIOD_PROJECTION_VERSION
        work.loc[indexes, "period_projection_provenance"] = "legacy_recomputed"
        work.loc[declared_indexes, "period_projection_provenance"] = "artifact_recomputed"
    work.index = original_index
    return work


def _household_distribution_observation_panel(cells: pd.DataFrame) -> pd.DataFrame:
    """Project verified D3 household cells into the D4 observation contract."""
    if cells.empty:
        return pd.DataFrame()
    required = {"cell_id", "region_code", "period_id", "household_income_mean"}
    missing = sorted(required.difference(cells.columns))
    if missing:
        raise UkraineStageArtifactVerificationError(
            "calibrated household cells are missing columns: " + ",".join(missing)
        )
    frame = _reconcile_ukraine_period_projection(cells, fixed_time_grain=TimeFrequency.MONTH)
    return pd.DataFrame(
        {
            "family": ObservationFamily.HOUSEHOLD_DISTRIBUTION.value,
            "time_grain": TimeFrequency.MONTH.value,
            "period_id": frame["period_id"],
            "period_start": frame["period_start"],
            "period_end": frame["period_end"],
            "period_disposition": frame["period_disposition"],
            "period_reason": frame["period_reason"],
            "period_projection_version": frame["period_projection_version"],
            "period_source_projection_version": frame["period_source_projection_version"],
            "period_projection_provenance": frame["period_projection_provenance"],
            "observed_value": pd.to_numeric(frame["household_income_mean"], errors="coerce").fillna(
                0.0
            ),
            "trust_weight": 0.0,
            "coverage_estimate": 0.0,
            "measurement_bias_flag": True,
            "source_id": "d3_calibrated_household_cells",
            "source_version": "d3_verified",
            "identification_mode": IdentificationMode.BOUNDS_ONLY.value,
            "source_confidence_tier": SourceConfidenceTier.EXPLORATORY.value,
            "proxy_source_id": "calibrated_household_cells.parquet",
            "regime_id": "regime_a",
            "entity_id": frame["cell_id"].astype(str),
        }
    )
''' + s[end:]
replace('''    household_panel = _household_distribution_observation_panel(
        pd.read_parquet(''','''    observation_panel = _reconcile_ukraine_period_projection(observation_panel)
    household_panel = _household_distribution_observation_panel(
        pd.read_parquet(''')
p.write_text(s)
