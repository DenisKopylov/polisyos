import ast,difflib,hashlib,json,subprocess,tomllib
from pathlib import Path
base=Path('LOCAL/raw/e02-execution-20261027/repairs/C48-r4')
def sha(b):return hashlib.sha256(b).hexdigest()
def git_blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def git(*args):return subprocess.run(['git',*args],capture_output=True,text=True,check=True).stdout.strip()
def build(postname,prename,patchname,exclude=frozenset()):
 post=base/postname;pre=base/prename;files=[];parts=[]
 for p in sorted(post.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(post); name=str(rel)
  if name in exclude:continue
  source=pre/rel;before=source.read_bytes() if source.exists() else None;after=p.read_bytes()
  if before==after:continue
  if p.suffix=='.py':ast.parse(after,str(rel))
  if p.suffix=='.toml':tomllib.loads(after.decode())
  beforelines=[] if before is None else before.decode().splitlines(keepends=True)
  parts.extend(difflib.unified_diff(beforelines,after.decode().splitlines(keepends=True),fromfile='a/'+name if before is not None else '/dev/null',tofile='b/'+name))
  files.append({'path':name,'preimage_sha256':sha(before) if before is not None else None,'preimage_git_blob':git_blob(before) if before is not None else None,'postimage_sha256':sha(after),'postimage_git_blob':git_blob(after)})
 text=''.join(parts);(base/patchname).write_text(text)
 return files,sha(text.encode())
main,mainsha=build('postimages','preimages','candidate.patch',{'policy-engine/src/polisyos/scientist/methods/search/funnel/orchestrator.py'})
c53,c53sha=build('c53-postimages','c53-preimages','c53-frozen2-context.patch')
head=git('rev-parse','HEAD');tree=git('rev-parse','HEAD^{tree}')
comparison=[]
for item in main:
 path=Path(item['path']);actual=sha(path.read_bytes()) if path.exists() else None
 comparison.append({'path':str(path),'current_sha256':actual,'matches_preimage':actual==item['preimage_sha256']})
manifest={'status':'frozen_source_proposal_pending_independent_review','runtime_status':'UNRUN','closure_ids':[],
'slice_base':'cfdb1ac1b7a44a782ec8e13b5f0ed9277beed65c','slice_base_tree':'48eb8d6b5fb61fa1ce8a731ca47fc0cfaf189343',
'readback_head':head,'readback_tree':tree,'prior_r2_review_sha256':'2294b11d1138bbd0d48509630f44080d86b54e33fc283a58d2d11d060379c06f',
'prior_r3_review_sha256':'e194fb295ceca98c32a2a927cf90f34caf6ba4d716eb59b836ae190fe0e4f446',
'c53_frozen2_manifest_sha256':'d6148ab1e29aa69a52fe2ea45b1890b70d43986f4bd80205f6e56ed258aebd8b',
'candidate_patch_sha256':mainsha,'c53_frozen2_context_patch_sha256':c53sha,'main_files':main,'c53_overlay_files':c53,
'readback_main_preimage_checks':comparison,'excluded_obsolete_r3_orchestrator':'Use c53-postimages against C53 frozen2, never postimages copy',
'cross_owner':['C52 planning node exact-context composition; transfer.py belongs to C52','C53 frozen2 orchestrator/types and runtime reporting exact-context composition','Root-generated public API/schema/client companions'],
'limitations':['Nonempty unbound historical Pareto snapshots refused without rewrite','Bayesian acquisition_type metadata unsupported by typed policy consumer before Stage A','No authenticated vector-index producer established','Candidate digest is not a selected CAS ArtifactRef; downstream artifact-only consumer bridge remains','Opaque context executes fresh; actual attempt traces are linked, not reused','Finite ranked selected-source and fresh policy output witness remains UNRUN']}
(base/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('head',head,'tree',tree,'main_files',len(main),'overlay_files',len(c53))
print('candidate_patch_sha256',mainsha,'c53_overlay_sha256',c53sha)
print('main_preimage_mismatches',[r['path'] for r in comparison if not r['matches_preimage']])
