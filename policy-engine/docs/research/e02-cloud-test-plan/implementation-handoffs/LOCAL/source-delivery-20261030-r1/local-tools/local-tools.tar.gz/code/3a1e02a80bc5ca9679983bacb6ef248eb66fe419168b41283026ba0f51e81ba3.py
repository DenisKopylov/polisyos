"""Freeze bounded RAW proposal metadata; never execute or edit canonical code."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import subprocess
import tomllib

root = Path.cwd()
packet = Path(__file__).resolve().parent
post = packet / 'postimages'
sha = lambda data: hashlib.sha256(data).hexdigest()
base = 'cb3e81aa6998cb6d0ecda91c68c9e1789d4f35b6'
tree = 'f848b376a36e272770baed965123327ca00f34fc'
rows = []
patches = []
for path in sorted(post.rglob('*')):
    if not path.is_file():
        continue
    rel = path.relative_to(post).as_posix()
    canonical = root / rel
    before = subprocess.check_output(['git', 'show', f'{base}:{rel}'], cwd=root)
    assert canonical.read_bytes() == before, rel
    after = path.read_bytes()
    assert before != after, rel
    if path.suffix == '.py':
        ast.parse(after)
    elif path.suffix == '.toml':
        tomllib.loads(after.decode())
    diff = ''.join(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True), fromfile='a/' + rel, tofile='b/' + rel))
    patches.append(diff)
    rows.append({'path': rel, 'preimage_sha256': sha(before), 'postimage_sha256': sha(after), 'bytes': len(after), 'postimage': str(path.relative_to(root))})
(packet / 'source.patch').write_text(''.join(patches))
producer_path = 'policy-engine/tools/devx/foundry/generate_stubs.py'
producer = (post / producer_path).read_text()
test_path = 'policy-engine/tests/repo_quality/tools/test_foundry_stub_generation.py'
test_sha = sha((post / test_path).read_bytes())
original = root / 'LOCAL/raw/e02-execution-20261027/generated-admission-r1/c60-generator-style-r1/controls'
controls = [
 ('byte-comparator', '        if args.check:\n', '        if args.check:\n            return 0, "PASS"  # property removed; rendered family/receipt remain\n', 'freshness comparator must refuse every changed declared output'),
 ('canonical-style', '    logical_path = target.relative_to(REPO_ROOT).as_posix()\n', '    return content  # canonicalization property removed; caller/config markers remain\n    logical_path = target.relative_to(REPO_ROOT).as_posix()\n', 'actual generated stub must pass canonical Ruff'),
 ('facade-completeness', '    aliases = "\\n".join(f"    {name} as {name}," for name in names)\n', '    names = names[:1]  # actual canonical export completeness removed\n    aliases = "\\n".join(f"    {name} as {name}," for name in names)\n', 'facade stub must preserve every actual canonical export without wildcard'),
 ('source-abi-preservation', '    source_tree = ast.parse(measured_read_text(source), filename=str(source))\n', '    return content  # semantic property removed; all original stub names/markers remain\n    source_tree = ast.parse(measured_read_text(source), filename=str(source))\n', 'actual generated Enum ABI must pass strict member/value consumers'),
]
control_rows = []
for name, old, new, signal in controls:
    assert producer.count(old) == 1, name
    mutant = producer.replace(old, new, 1)
    ast.parse(mutant)
    directory = packet / 'controls' / name
    directory.mkdir(parents=True, exist_ok=True)
    diff = ''.join(difflib.unified_diff(producer.splitlines(True), mutant.splitlines(True), fromfile='a/' + producer_path, tofile='b/' + producer_path))
    target = directory / 'property-removal.patch'
    target.write_text(diff)
    row = {'id': name, 'producer_path': producer_path, 'correct_producer_sha256': sha(producer.encode()), 'mutant_producer_sha256': sha(mutant.encode()), 'patch': str(target.relative_to(root)), 'patch_sha256': sha(target.read_bytes()), 'test_path': test_path, 'test_sha256': test_sha, 'node': 'test_actual_stub_owner_staging_and_check_detect_complete_byte_drift', 'required_failure': signal, 'outcome': 'UNRUN', 'restore_requirement': 'Exact source bytes/hash restored before next control; generated staged outputs never copied from mutant; do not call restoration a runtime PASS.'}
    if name != 'source-abi-preservation':
        original_patch = original / name / 'property-removal.patch'
        original_bytes = original_patch.read_bytes()
        # Preserve and bind reviewed originals, not truncated Cloud returns.
        assert original_bytes.decode().endswith('\n')
        row['original_reviewed_patch'] = str(original_patch.relative_to(root))
        row['original_reviewed_patch_sha256'] = sha(original_bytes)
        row['semantic_rebase'] = 'Same exact removed property and markers; only new producer context/line offsets rebased.'
    control_rows.append(row)
(packet / 'controls.json').write_text(json.dumps(control_rows, indent=2) + '\n')
outputs = []
for rel in ['base.pyi', 'registry.pyi', 'composer.pyi', 'components/composer.pyi']:
    path = root / 'policy-engine/src/polisyos/foundry/methods' / rel
    outputs.append({'path': str(path.relative_to(root)), 'preimage_sha256': sha(path.read_bytes()), 'postimage': None, 'status': 'UNRUN: genuine owner generation required; no manually computed output supplied'})
inputs = []
for rel in ['policy-engine/.venv/lib/python3.14/site-packages/mypy/stubgen.py', 'policy-engine/.venv/lib/python3.14/site-packages/mypy/version.py', 'policy-engine/mypy.ini', 'policy-engine/ruff.toml', 'policy-engine/ruff.generated.toml', 'policy-engine/pyproject.toml', 'policy-engine/uv.lock', 'policy-engine/tools/devx/architecture/guardrails.py']:
    path = root / rel
    inputs.append({'path': rel, 'sha256': sha(path.read_bytes()), 'purpose': 'actual retained backend/config/owner source; no installation performed'})
manifest = {'schema': 'policyos.e02.c60.strict_abi_proposal.v1', 'base_commit': base, 'base_tree': tree, 'canonical_mutations_by_author': False, 'footprint': rows, 'generated_companions': outputs, 'inputs': inputs, 'source_patch_sha256': sha((packet / 'source.patch').read_bytes()), 'census_sha256': sha((packet / 'diagnostic-census.json').read_bytes()), 'controls_sha256': sha((packet / 'controls.json').read_bytes()), 'static_results': {'AST': 'PASS10 Python postimages', 'TOML': 'PASS1 family manifest', 'Ruff': 'PASS20 canonical-logical check/format invocations; static-ruff-results.json'}, 'runtime_results': 'UNRUN: no product imports, stubgen, mypy, tests or native jobs executed by author', 'unresolved': ['Actual strict Ray target has import-not-found because backend absent. No config/import suppression, fabricated Ray type stub or dynamic-import concealment included. Supported real Ray profile/setup must be qualified separately.', 'Generated4 outputs and derived generated-artifacts reference bytes do not exist for proposed source until Root executes actual owners.', 'Actual new strict ABI/mutation outcomes pending. Existing CB3 failures and earlier positive runtime/freshness evidence remain bound to their historical versions.']}
(packet / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print('source paths', len(rows), 'controls', len(control_rows), 'deferred generated', len(outputs))
