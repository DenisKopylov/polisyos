"""Audit R3 stream-retention delta without importing or executing product code."""
from pathlib import Path
import ast
import hashlib
import json

base=Path('LOCAL/raw/e02-execution-20261027/repairs/C93-observer-code-identity-r3')
parent=base.with_name('C93-observer-code-identity-r2')
root=base/'postimages';oldroot=parent/'postimages';sha=lambda data:hashlib.sha256(data).hexdigest()
rows=[]
for p in sorted(x for x in root.rglob('*') if x.is_file()):
 rel=p.relative_to(root);old=oldroot/rel;assert old.exists()
 rows.append({'path':rel.as_posix(),'r2_sha256':sha(old.read_bytes()),'r3_sha256':sha(p.read_bytes()),'changed':old.read_bytes()!=p.read_bytes()})
changed=[r['path'] for r in rows if r['changed']]
assert changed==['policy-engine/tests/unit/fabric/connectors/test_federation_execution_observer.py']
for p in sorted((base/'controls').glob('*')):
 old=parent/'controls'/p.name;assert old.exists() and old.read_bytes()==p.read_bytes()
path=root/changed[0];oldpath=oldroot/changed[0];a=ast.parse(oldpath.read_text());b=ast.parse(path.read_text())
name='test_real_entrypoint_rejects_project_preimport_in_fresh_process'
other=lambda t:[ast.dump(n,include_attributes=False) for n in t.body if not isinstance(n,ast.FunctionDef) or n.name!=name]
assert other(a)==other(b)
fn=next(n for n in b.body if isinstance(n,ast.FunctionDef) and n.name==name)
positions={}
for node in fn.body:
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='run' for t in node.targets):positions['run']=node.lineno
 if isinstance(node,ast.Expr) and isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Attribute) and node.value.func.attr=='write_bytes':
  arg=node.value.args[0]
  if isinstance(arg,ast.Attribute) and isinstance(arg.value,ast.Name) and arg.value.id=='run':positions[arg.attr]=node.lineno
 if isinstance(node,ast.Expr) and 'guard-child.json' in ast.unparse(node):
  text=ast.unparse(node);assert "'argv': command" in text and "'returncode': run.returncode" in text
  positions['argv_returncode']=node.lineno
 if isinstance(node,ast.Assert):positions.setdefault('first_assert',node.lineno)
assert positions['run']<positions['stdout']<positions['first_assert']
assert positions['run']<positions['stderr']<positions['first_assert']
assert positions['run']<positions['argv_returncode']<positions['first_assert']
print(json.dumps({'scope':'source AST and control bytes only; product/pytest/runtime UNRUN',
                  'source_deltas':rows,'all_control_files_unchanged':True,
                  'run_stdout_stderr_before_first_assert':positions,
                  'actual_precondition_probe_is_unchanged':(base/'probe-result.json').read_bytes()==(parent/'probe-result.json').read_bytes()},indent=2))
