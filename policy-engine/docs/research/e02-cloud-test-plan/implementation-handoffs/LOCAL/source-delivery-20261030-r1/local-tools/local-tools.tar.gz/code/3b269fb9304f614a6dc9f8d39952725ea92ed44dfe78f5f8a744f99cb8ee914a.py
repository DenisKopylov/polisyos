"""Prepare three C43 manual-custody plans using the reviewed C59 admission contract."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import re
import runpy
import shutil
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

R=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos');P=R/'policy-engine';HERE=Path(__file__).resolve().parent
D=P/'docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1'
LAYER=D.parent/'root-layer-lib.py';LIVE=R/'LOCAL/raw/root-live-ownership-20261021.json'
DYLD=R/'LOCAL/raw/e02-execution-20261027/repairs/C43-dyld-witness-r3'
C59=R/'LOCAL/raw/e02-execution-20261027/repairs/C59-r2-native';REVIEW=R/'LOCAL/raw/e02-execution-20261027/reviews/C59-r2-native-final.md'
SUP=P/'docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-postfix-709-q2-helper-actual-20261018/supervise.py'
MANIFEST=R/'LOCAL/raw/e02-execution-20261027/repairs/C43-r5/manifest.json'
PILOT=D/'c43-c50-native-r2-20261028-c43-pilot';TEST='tests/unit/remediation/test_c43_joint_gaussian.py'
CASES={
 'random_joint':('monte_carlo','test_same_declared_joint_gaussian_has_same_linear_variance_in_four_backends[random-0.8]'),
 'sobol_joint':('monte_carlo','test_same_declared_joint_gaussian_has_same_linear_variance_in_four_backends[sobol-0.8]'),
 'dispatcher_preflight':('dispatcher','test_dispatcher_rejects_unresolved_input_before_even_the_applicability_probe'),
 'fixed_auto':('dispatcher','test_all_actual_evaluator_calls_keep_the_fixed_value_without_a_fake_envelope[auto]'),
 'fixed_delta':('delta','test_all_actual_evaluator_calls_keep_the_fixed_value_without_a_fake_envelope[delta]'),
 'fixed_random':('monte_carlo','test_all_actual_evaluator_calls_keep_the_fixed_value_without_a_fake_envelope[random]'),
 'fixed_sobol':('monte_carlo','test_all_actual_evaluator_calls_keep_the_fixed_value_without_a_fake_envelope[sobol]'),
 'analytical_matrix':('analytical','test_analytical_supplied_covariance_must_match_the_named_input_law'),
}
EXPECTED={
 DYLD/'c43_dyld_observer.py':'323a57911109df5264b24ac857d431f7dfce09ede19b732628782c2dd7bedab2',
 DYLD/'c43_dyld_snapshot.py':'b9ca153bab982ddc3488e81f0c497395a65e5ad8df9dfeda1ee0d3198c7569ad',
 HERE/'c43_positive_profile.py':'33d5b437df5a20374b280cfe631ce9cf439fda06858c58f23a3ae923d6ed5490',
 HERE/'c43_removal_plugin.py':'44e20eca03b9cdd42206b0f33fedad5847e6b6a18d76647aea5059de195ffc87',
 HERE/'c43_child_profile.py':'a3010d25e7f7076ab4ad203b942c38a77de87b7d13edbf62310fc28839276e2b',
 C59/'run_guarded.py':'e7d26efd7738eaa482388d00663d7749586a64fffd92d9aff52a1aa39bee2621',
 C59/'native_env.py':'863a86b08045f0f21677089cad3f48c64ab4b3a2eff427313d00e66648c4273a',
 C59/'c59_collection_observer.py':'d412489cc0b0d4aea1b3d31276f4cc48f6616df0d5afe640bedf72f989b1a2ce',
 D/'run_case_with_tools_r2.py':'4c3eae2136b6c8941ba09d4438d12ea6ea11310527768f0482877b877b8e30c2',
 MANIFEST:'afc483eefa5c65108360bd749643d0866d1979af72044c401accc0fb3d7e3b5d'}


def sha(p:Path)->str:return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args:str)->str:return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
def pin(p:Path,head:str)->dict:
 if p.is_symlink() or not p.is_file():raise SystemExit('Missing regular source: '+str(p))
 rel=str(p.relative_to(R));data=subprocess.check_output(['git','show',head+':'+rel],cwd=R)
 if hashlib.sha256(data).hexdigest()!=sha(p):raise SystemExit('Source differs from commit: '+rel)
 if subprocess.run(['git','diff','--cached','--quiet',head,'--',rel],cwd=R).returncode:raise SystemExit('Index differs: '+rel)
 return {'sha256':sha(p),'git_blob':git('rev-parse',head+':'+rel)}


def main()->None:
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--admitted-head',required=True);ap.add_argument('--admitted-tree',required=True);ap.add_argument('--suffix',required=True);ap.add_argument('--mode',choices=['random_joint'],required=True);a=ap.parse_args()
 if not re.fullmatch('[a-z0-9][a-z0-9-]{0,39}',a.suffix):raise SystemExit('Invalid suffix')
 head=git('rev-parse','HEAD');tree=git('rev-parse','HEAD^{tree}')
 if (head,tree)!=(a.admitted_head,a.admitted_tree) or git('symbolic-ref','--short','HEAD')!='codex/e02-unified-local-20261009' or git('status','--porcelain=v1','--untracked-files=no'):
  raise SystemExit('Branch/head/tree/clean tracked state not admitted')
 live=runpy.run_path(str(LAYER))['guard']()
 if live['head']!=head:raise SystemExit('Current root source frame unavailable')
 if shutil.disk_usage(R).free < 8*1024**3:raise SystemExit('Disk below 8 GiB starting headroom')
 for f,v in EXPECTED.items():
  if sha(f)!=v:raise SystemExit('Reviewed artifact mismatch: '+str(f))
 old=json.loads((PILOT/'audit-result.json').read_text())
 if old['result'].get('junit')!={'tests':30,'failures':0,'errors':0,'skipped':0} or old['result']['return_code']!=0 or not old['result']['complete'] or old['result'].get('aborted_reason') or old['current_mismatches']:
  raise SystemExit('Original measured C43 pilot not an all-pass')
 if subprocess.run(['git','merge-base','--is-ancestor',old['plan']['source_head'],head],cwd=R).returncode:raise SystemExit('Original pilot source is not an ancestor')
 oldfreeze=PILOT/'source-profile-freeze.json'
 if sha(oldfreeze)!=old['source_profile_freeze_sha256']:raise SystemExit('Original pilot source-profile freeze bytes mismatch')
 freeze=json.loads(oldfreeze.read_text())
 if freeze['before']['head']!=old['plan']['source_head'] or old['guard_after']['head']!=old['plan']['source_head'] or freeze['before']['source_frame']!=old['guard_after']['source_frame']:
  raise SystemExit('Original pilot source frame mismatch')
 old_live_rel='LOCAL/raw/root-live-ownership-20261021.json'
 old_live_sha=freeze['selected_input_pins'].get(old_live_rel)
 if not old_live_sha:raise SystemExit('Original pilot root-live guard digest missing')
 for rel,digest in freeze['selected_input_pins'].items():
  if rel==old_live_rel:continue  # Mutable ownership document is freshly admitted separately below.
  f=R/rel
  if not f.is_file() or sha(f)!=digest:raise SystemExit('Original pilot selected input changed: '+rel)
 if not old['readsets']:raise SystemExit('Original pilot has no finite imported-source readset')
 for rs in old['readsets']:
  f=R/rs['path']
  if sha(f)!=rs['sha256']:raise SystemExit('Original readset bytes mismatch')
  for entry in json.loads(f.read_text())['modules']:
   f=P/entry['path'];rel=str(f.relative_to(R))
   if not f.is_file() or sha(f)!=entry['sha256'] or hashlib.sha256(subprocess.check_output(['git','show',head+':'+rel],cwd=R)).hexdigest()!=entry['sha256']:
    raise SystemExit('Original pilot imported source changed: '+rel)
 if sha(R/'LOCAL/raw/e02-execution-20261027/repairs/C43-C50-native-plans-r2/c43-pilot-qualified-r1.json')!='9526c1da0f968f0df2d7d3ea92e512cb0b5d83bf5a4d437b7adb6b66a7498d9b':
  raise SystemExit('Original pilot qualification receipt changed')
 module,test_name=CASES[a.mode];node=TEST+'::'+test_name
 cases=list(ET.parse(PILOT/'pytest.xml').iter('testcase'))
 if sum(c.get('classname')=='tests.unit.remediation.test_c43_joint_gaussian' and c.get('name')==test_name and c.find('failure') is None and c.find('error') is None and c.find('skipped') is None for c in cases)!=1:
  raise SystemExit('Exact case not present and passing in original pilot JUnit')
 rows=json.loads(MANIFEST.read_text())['footprints']['postimages']
 for row in rows:
  if sha(R/row['path'])!=row['post_sha256']:raise SystemExit('Reviewed C43 postimage changed: '+row['path'])
 src='src/polisyos/foundry/uncertainty/'+module+'.py';fixed=['pytest.ini','pyproject.toml','uv.lock','src/polisyos/ir/analytics/uncertainty.py','src/polisyos/ir/api.py','src/polisyos/ir/artifacts/contracts.py','src/polisyos/ir/artifacts/io.py','src/polisyos/core/canon/canon_json.py']
 delta=git('diff','--name-only','aefc080e6ed12f2fcc5e820b454c6fc4a9b494f2',head,'--','policy-engine/src/polisyos/core','policy-engine/src/polisyos/ir')
 paths={R/r['path'] for r in rows}|{P/x for x in fixed}|{R/x for x in delta.splitlines() if x.endswith('.py')}
 ancestors=set();cur=(P/TEST).parent
 while cur.is_relative_to(P):ancestors.add(cur/'conftest.py');cur=cur.parent
 present={p for p in ancestors if p.exists() or p.is_symlink()};absent=sorted(str(p.relative_to(R)) for p in ancestors-present)
 for p in absent:
  if subprocess.run(['git','cat-file','-e',head+':'+p],cwd=R,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0:raise SystemExit('Missing committed conftest: '+p)
 pins={str(p.relative_to(R)):pin(p,head) for p in sorted(paths|present)}
 env=os.environ.copy()
 for n in ('PYTHONPATH','PYTEST_ADDOPTS','PYTEST_PLUGINS','PYTEST_DISABLE_PLUGIN_AUTOLOAD','PYTHONHOME','VIRTUAL_ENV'):env.pop(n,None)
 env['PYTHONDONTWRITEBYTECODE']='1'
 profile=json.loads(subprocess.check_output([str(P/'.venv/bin/python'),str(C59/'native_env.py')],cwd=R,env=env,text=True))
 guardfiles={str(LIVE.relative_to(R)):sha(LIVE),live['source_frame']['path']:live['source_frame']['sha256']}
 extras={D/'readset_observer_tools_r1.py',SUP,LAYER,REVIEW,HERE/'prepare_plans.py',HERE/'run_case.sh',PILOT/'pytest.xml',PILOT/'audit-result.json',oldfreeze,PILOT/old['result']['stdout_path'],PILOT/old['result']['stderr_path'],R/'LOCAL/raw/e02-execution-20261027/repairs/C43-C50-native-plans-r2/c43-pilot-qualified-r1.json',R/'LOCAL/raw/e02-execution-20261027/c43-c50-native-r2-20261028-c43-pilot-postflight.json'} | {R/rs['path'] for rs in old['readsets']} | {R/rel for rel in freeze['selected_input_pins'] if rel != old_live_rel}
 artifact={str(p.relative_to(R)):sha(p) for p in {*EXPECTED,*extras}}
 bind={'branch':'codex/e02-unified-local-20261009','committed_affected_inputs':pins,'native_python':profile,'absent_pytest_ancestor_conftests':absent,'artifact_pins':artifact,'guard_input_pins':guardfiles}
 plans=[]
 for phase in ('before','mutant','restored'):
  case='c43-'+a.mode.replace('_','-')+'-'+a.suffix+'-'+phase;path=D/(case+'.json')
  if path.exists() or (D/case).exists():raise SystemExit('Existing output/plan: '+case)
  plugin='c43_removal_plugin' if phase=='mutant' else 'c43_positive_profile'
  extra={'PYTHONPATH':os.pathsep.join([str(C59),str(DYLD),str(HERE),str(P/'src')]),'PYTEST_PLUGINS':'c59_collection_observer,c43_dyld_observer,'+plugin,'C59_COLLECTION_PLUGIN_SHA256':EXPECTED[C59/'c59_collection_observer.py'],
   'C43_DYLD_OBSERVER_SHA256':EXPECTED[DYLD/'c43_dyld_observer.py'],'C43_DYLD_SNAPSHOT_SHA256':EXPECTED[DYLD/'c43_dyld_snapshot.py'],'C43_DYLD_EXACT_NODE':node,
   'C43_CHILD_PROFILE_SHA256':EXPECTED[HERE/'c43_child_profile.py'],'C43_CONTROL_SOURCE_HEAD':head,'C43_CONTROL_SOURCE_TREE':tree,'C43_CONTROL_SOURCE_SHA256':sha(P/src),'C43_CONTROL_TEST_SHA256':sha(P/TEST),'C43_CONTROL_OUTPUT':str(D/case)}
  if phase=='mutant':extra.update(C43_CONTROL_PLUGIN_SHA256=EXPECTED[HERE/'c43_removal_plugin.py'],C43_CONTROL_MODE=a.mode)
  else:extra.update(C43_POSITIVE_PLUGIN_SHA256=EXPECTED[HERE/'c43_positive_profile.py'],C43_CONTROL_SOURCE_RELATIVE=src,C43_OWNER_MODULE=module,C43_EXACT_NODE=node)
  plan={'case_id':case,'source_head':head,'source_tree':tree,'task_ids':['UQP-01','UQP-02'],'nodes':[node], 'extra_env':extra,'deadline_seconds':600,'rss_cap_bytes':2415919104,'source_rebind':bind,'root_manual_mode':a.mode,'root_manual_phase':phase,'root_manual_exact_node':node,'historical_pilot_live_guard':{'path':old_live_rel,'sha256_at_prior_run':old_live_sha,'bytes_on_disk_match_prior':sha(LIVE)==old_live_sha,'scope':'Historical mutable guard may advance; its original bytes are not reconstructed. Prior audit has before/after frame and source freeze; a fresh current guard is separately bound.'},'expected_junit_hypothesis':{'tests':1,'failures':int(phase=='mutant'),'errors':0,'skipped':0}, 'scope':'One exact unchanged C43 case. Resolve actual audit/freeze/JUnit/collection/full output and active function independently. No automatic result or removal acceptance.', 'closure_ids':[]}
  plans.append((path,plan))
 if git('rev-parse','HEAD')!=head or git('status','--porcelain=v1','--untracked-files=no'):raise SystemExit('Source moved; no plans written')
 runpy.run_path(str(LAYER))['guard']()
 for path,plan in plans:
  with path.open('x') as f:f.write(json.dumps(plan,indent=2,sort_keys=True)+'\n')
  if json.loads(path.read_text())!=plan:raise SystemExit('Plan readback mismatch')
 receipt={'head':head,'tree':tree,'node':node,'mode':a.mode,'plans':[{'path':str(p),'sha256':sha(p)} for p,_ in plans],'status':'PREPARED ONLY; manual review/source lease required; runtime UNRUN'}
 rec=HERE/('preparation-'+a.mode.replace('_','-')+'-'+a.suffix+'.json')
 with rec.open('x') as f:f.write(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
