from pathlib import Path
import difflib, hashlib, json, subprocess, ast
root=Path('LOCAL/raw/e02-execution-20261027/repairs/C41-r9')
pre=root/'preimages';post=root/'postimages';out=[]; entries=[]
paths=sorted(set(x.relative_to(post) for x in post.rglob('*') if x.is_file()) | set(x.relative_to(pre) for x in pre.rglob('*') if x.is_file()))
sha=lambda b:hashlib.sha256(b).hexdigest()
def blob(b:bytes)->str:return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
for path in paths:
 a=pre/path;b=post/path
 old=a.read_bytes() if a.exists() else None;new=b.read_bytes() if b.exists() else None
 if old==new:continue
 name=path.as_posix();old_lines=old.decode().splitlines(keepends=True) if old is not None else [];new_lines=new.decode().splitlines(keepends=True) if new is not None else []
 out.append(f'diff --git a/{name} b/{name}\n')
 if old is None:out.append('new file mode 100644\n')
 if new is None:out.append('deleted file mode 100644\n')
 out.extend(difflib.unified_diff(old_lines,new_lines,fromfile=f'a/{name}' if old is not None else '/dev/null',tofile=f'b/{name}' if new is not None else '/dev/null',n=3))
 live=Path(name);lv=live.read_bytes() if live.is_file() else None
 entries.append({'path':name,'preimage_sha256':sha(old) if old is not None else None,'preimage_git_blob':blob(old) if old is not None else None,'postimage_sha256':sha(new) if new is not None else None,'postimage_git_blob':blob(new) if new is not None else None,'postimage_bytes':len(new) if new is not None else None,'live_sha256':sha(lv) if lv is not None else None,'live_matches_preimage':lv==old})
patch=''.join(out).encode();(root/'candidate.patch').write_bytes(patch)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip()
manifest={'kind':'C41-r9 bounded selected-owner replay proposal; pending review and runtime','base_head_at_freeze':head,'base_tree_at_freeze':tree,'delta_base':'C41-r8 postimages / C41-r8-docs-companions-r2 postimages; Core README from C07 frame','candidate_patch_sha256':sha(patch),'removal_plugin_sha256':sha((root/'c41_r9_mutants.py').read_bytes()),'paths':entries,'checks':'AST and Ruff source-only; no product runtime/import/tests/environment changes; no G decision','coordinate':'root-only context composition; C07 ownership is deliberate preimage drift; C32/C49 generation and C48 runs contexts may advance'}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for item in entries:
 q=post/item['path']
 if q.suffix=='.py':ast.parse(q.read_text())
ast.parse((root/'c41_r9_mutants.py').read_text())
print('head',head,'tree',tree,'files',len(entries));print('patch',sha(patch));print('manifest',sha((root/'manifest.json').read_bytes()));print('mutants',manifest['removal_plugin_sha256']);print('live drift',[x['path'] for x in entries if not x['live_matches_preimage'] and x['preimage_sha256'] is not None])
