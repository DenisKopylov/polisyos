"""Compile complete actual modules without executing/importing product code."""
from pathlib import Path
from types import CodeType
import ast,copy,hashlib,json,sys
HERE=Path(__file__).resolve().parent;R=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
def fp(c):return (c.co_code,c.co_names,c.co_varnames,c.co_freevars,c.co_cellvars,c.co_argcount,c.co_posonlyargcount,c.co_kwonlyargcount,c.co_flags,tuple(fp(x) if isinstance(x,CodeType) else x for x in c.co_consts))
def code_child(c,path):
 for name in path.split('.'):
  found=[x for x in c.co_consts if isinstance(x,CodeType) and x.co_name==name];assert len(found)==1;c=found[0]
 return c
def ast_child(t,path):
 for name in path.split('.'):t=next(x for x in t.body if isinstance(x,(ast.ClassDef,ast.FunctionDef)) and x.name==name)
 return t
def main():
 rows=[]
 for mode,s in json.loads((HERE/'controls.json').read_text()).items():
  raw=(R/'policy-engine'/s['source']).read_bytes();assert hashlib.sha256(raw).hexdigest()==s['source_sha256'];module=compile(raw,'<C32-original>','exec',dont_inherit=True)
  for target in s['functions']:
   q=target['qualified_name'];tree=ast.parse(raw);original=code_child(module,q);same=code_child(compile(copy.deepcopy(tree),'<C32-original-AST>','exec',dont_inherit=True),q);assert fp(original)==fp(same),(mode,q)
   ast_child(tree,q).body=ast.parse((HERE/target['mutant_function_source']).read_bytes()).body[0].body;ast.fix_missing_locations(tree);mutant=code_child(compile(tree,'<C32-mutant>','exec',dont_inherit=True),q);assert mutant.co_flags==original.co_flags and mutant.co_freevars==original.co_freevars
   rows.append({'mode':mode,'qualified_name':q,'complete_module_recursive_code_equal':True,'mutant_calling_convention_preserved':True})
 print(json.dumps({'interpreter':sys.version,'rows':rows,'product_execution':False,'product_imports':False,'runtime':'UNRUN'},indent=2))
if __name__=='__main__':main()
