"""Finite stdlib-only fault matrix for the one-node Q2 observer lifecycle.

Loads the requested observer with fake pytest, fake child results, and case-owned
synthetic files. It never imports or runs the PolicyOS product or real pytest.
"""

from __future__ import annotations

import argparse
import contextlib
import hashlib
import importlib.util
import io
import json
import os
import subprocess
import sys
import types
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--plugin", type=Path, required=True)
parser.add_argument("--scratch", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
args.scratch.mkdir(parents=True, exist_ok=False)
if os.path.lexists(args.output):
    raise RuntimeError("output already exists")
fake_pytest = types.ModuleType("pytest")
fake_pytest.hookimpl = lambda **_kwargs: lambda fn: fn
sys.modules["pytest"] = fake_pytest
spec = importlib.util.spec_from_file_location("q2_fake_guard", args.plugin)
if spec is None or spec.loader is None:
    raise RuntimeError("plugin loader unavailable")
guard = importlib.util.module_from_spec(spec)
spec.loader.exec_module(guard)
start = Path.cwd().resolve()
checks: dict[str, dict[str, object]] = {}


def case(name: str) -> tuple[Path, Path, list[str]]:
    parent = args.scratch / name
    temp = parent / "tmp"
    temp.mkdir(parents=True)
    comparator = parent / "runtime_api_v1.clean.openapi.json"
    comparator.write_text('{"corrupt":false}\n', encoding="utf-8")
    (parent / "runtime_api_v1.corrupted.openapi.json").write_text(
        '{"corrupt":true}\n', encoding="utf-8"
    )
    argv = [
        sys.executable,
        "tools/ops_runners/runtime/check_runtime_api_contract.py",
        "--openapi",
        str(comparator),
        "--skip-client-drift",
    ]
    return temp, comparator, argv


def result(argv: list[str]) -> subprocess.CompletedProcess[str]:
    clean = "runtime_api_v1.clean.openapi.json" in argv[3]
    return subprocess.CompletedProcess(
        argv,
        0 if clean else 1,
        stdout="Runtime API contract check passed\n" if clean else "OpenAPI drift detected\n",
        stderr="detail\n",
    )


def negative_argv(argv: list[str]) -> list[str]:
    result_argv = list(argv)
    result_argv[3] = str(Path(argv[3]).with_name("runtime_api_v1.corrupted.openapi.json"))
    return result_argv


def record(name: str, conditions: dict[str, bool], **details: object) -> None:
    checks[name] = {"pass": all(conditions.values()), "conditions": conditions, **details}


def read_receipt(temp: Path) -> dict[str, object]:
    path = temp / guard.RECEIPT
    return json.loads(path.read_text()) if path.exists() else {}


def make_cas() -> None:
    Path(".polisyos/cas/artifacts/sha256").mkdir(parents=True)


def observed_call(item: object, argv: list[str]) -> object:
    return item.module.subprocess.run(
        argv, cwd=guard.P, capture_output=True, text=True, check=False
    )


# Restore failure after an existing body exception cannot hide that exception.
temp, _, _ = case("restore-after-body-exception")
item = types.SimpleNamespace(module=types.SimpleNamespace(subprocess=subprocess))
sentinel = ValueError("body sentinel")
original_chdir = os.chdir


def fail_restore(path: object) -> None:
    if Path(path) == start:
        raise PermissionError("restore sentinel")
    original_chdir(path)


os.chdir = fail_restore
observed = None
try:
    try:
        with guard._isolated_body(item, temp, {}):
            raise sentinel
    except BaseException as exc:
        observed = exc
    receipt = read_receipt(temp)
    actual_cwd = Path.cwd().resolve()
finally:
    os.chdir = original_chdir
    original_chdir(start)
record(
    "restore_failure_preserves_body_exception",
    {
        "original_exception_identity": observed is sentinel,
        "proxy_restored": item.module.subprocess is subprocess,
        "receipt_attempted": bool(receipt),
        "cwd_not_falsely_restored": receipt.get("cwd_restored") is False and actual_cwd != start,
        "qualification_error": receipt.get("qualification_status") == "ERROR",
        "cleanup_error_recorded": bool(receipt.get("cleanup_errors")),
    },
    observed_exception=type(observed).__name__,
)

# Even a successful body cannot qualify when cwd cannot be restored.
temp, _, argv = case("restore-after-success")
item = types.SimpleNamespace(module=types.SimpleNamespace(subprocess=subprocess))
completed = result(argv)
negative = negative_argv(argv)
negative_result = result(negative)
original_run = subprocess.run
subprocess.run = lambda a, **kw: completed if a == argv else negative_result
os.chdir = fail_restore
observed = None
returned = None
try:
    try:
        with guard._isolated_body(item, temp, {}):
            make_cas()
            returned = observed_call(item, argv)
            observed_call(item, negative)
    except BaseException as exc:
        observed = exc
    receipt = read_receipt(temp)
finally:
    subprocess.run = original_run
    os.chdir = original_chdir
    original_chdir(start)
record(
    "restore_failure_fails_success_qualification",
    {
        "completed_process_identity": returned is completed,
        "harness_exception": isinstance(observed, RuntimeError),
        "receipt_attempted": bool(receipt),
        "cwd_not_falsely_restored": receipt.get("cwd_restored") is False,
        "qualification_error": receipt.get("qualification_status") == "ERROR",
        "checker_output_retained": (temp / "q2-checker-0.stdout.txt").exists(),
    },
    observed_exception=type(observed).__name__,
)

# A comparison read failure after the child has returned cannot hide its result
# or prevent retention of the child's available text.
temp, _, argv = case("comparison-read-failure")
completed = result(argv)
observer = guard._ObservedSubprocess(types.SimpleNamespace(run=lambda *a, **kw: completed), temp)
original_sha = guard._sha
guard._sha = lambda _path: (_ for _ in ()).throw(PermissionError("read sentinel"))
observed = None
returned = None
try:
    try:
        returned = observer.run(argv, cwd=guard.P, capture_output=True, text=True, check=False)
    except BaseException as exc:
        observed = exc
finally:
    guard._sha = original_sha
record(
    "comparison_read_failure_preserves_child",
    {
        "completed_process_identity": returned is completed,
        "no_observer_exception": observed is None,
        "checker_call_recorded": len(observer.calls) == 1,
        "comparison_failure_recorded": bool(observer.evidence_errors),
        "stdout_retained": (temp / "q2-checker-0.stdout.txt").is_file(),
        "stderr_retained": (temp / "q2-checker-0.stderr.txt").is_file(),
    },
    observed_exception=type(observed).__name__ if observed else None,
)

# The same missing evidence must prevent an otherwise successful hook qualifying.
temp, _, argv = case("comparison-read-qualification")
item = types.SimpleNamespace(module=types.SimpleNamespace(subprocess=subprocess))
completed = result(argv)
negative = negative_argv(argv)
negative_result = result(negative)
subprocess.run = lambda a, **kw: completed if a == argv else negative_result
guard._sha = lambda _path: (_ for _ in ()).throw(PermissionError("read sentinel"))
returned = None
observed = None
try:
    try:
        with guard._isolated_body(item, temp, {}):
            make_cas()
            returned = observed_call(item, argv)
            observed_call(item, negative)
    except BaseException as exc:
        observed = exc
    receipt = read_receipt(temp)
finally:
    guard._sha = original_sha
    subprocess.run = original_run
record(
    "comparison_read_failure_fails_qualification",
    {
        "completed_process_identity": returned is completed,
        "harness_exception": isinstance(observed, RuntimeError),
        "receipt_written": bool(receipt),
        "qualification_error": receipt.get("qualification_status") == "ERROR",
        "evidence_error_recorded": bool(receipt.get("evidence_errors")),
        "stdout_retained": (temp / "q2-checker-0.stdout.txt").is_file(),
        "stderr_retained": (temp / "q2-checker-0.stderr.txt").is_file(),
        "cwd_restored": Path.cwd().resolve() == start,
    },
    observed_exception=type(observed).__name__ if observed else None,
)

# One output-write failure cannot hide the result or suppress the other stream.
temp, _, argv = case("stdout-write-failure")
completed = result(argv)
observer = guard._ObservedSubprocess(types.SimpleNamespace(run=lambda *a, **kw: completed), temp)
original_open = Path.open


def fail_stdout(path: Path, *a: object, **kw: object) -> object:
    if path == temp / "q2-checker-0.stdout.txt":
        raise PermissionError("stdout write sentinel")
    return original_open(path, *a, **kw)


Path.open = fail_stdout
try:
    returned = observer.run(argv, cwd=guard.P, capture_output=True, text=True, check=False)
finally:
    Path.open = original_open
record(
    "stdout_write_failure_preserves_child_and_stderr",
    {
        "completed_process_identity": returned is completed,
        "checker_call_recorded": len(observer.calls) == 1,
        "output_failure_recorded": bool(observer.evidence_errors),
        "stderr_retained": (temp / "q2-checker-0.stderr.txt").is_file(),
    },
)

# Receipt write failure is separately reported without replacing a primary error.
temp, _, _ = case("receipt-write-after-exception")
item = types.SimpleNamespace(module=types.SimpleNamespace(subprocess=subprocess))
sentinel = ValueError("body sentinel")


def fail_receipt(path: Path, *a: object, **kw: object) -> object:
    if path == temp / guard.RECEIPT:
        raise PermissionError("receipt write sentinel")
    return original_open(path, *a, **kw)


Path.open = fail_receipt
observed = None
stderr = io.StringIO()
try:
    with contextlib.redirect_stderr(stderr):
        try:
            with guard._isolated_body(item, temp, {}):
                raise sentinel
        except BaseException as exc:
            observed = exc
finally:
    Path.open = original_open
record(
    "receipt_write_failure_preserves_body_exception",
    {
        "original_exception_identity": observed is sentinel,
        "receipt_error_reported": "receipt_unavailable" in stderr.getvalue(),
        "cwd_restored": Path.cwd().resolve() == start,
        "proxy_restored": item.module.subprocess is subprocess,
    },
)

# The absence of a receipt must also prevent a successful body qualifying.
temp, _, argv = case("receipt-write-after-success")
item = types.SimpleNamespace(module=types.SimpleNamespace(subprocess=subprocess))
completed = result(argv)
negative = negative_argv(argv)
negative_result = result(negative)
subprocess.run = lambda a, **kw: completed if a == argv else negative_result
Path.open = fail_receipt
observed = None
returned = None
stderr = io.StringIO()
try:
    with contextlib.redirect_stderr(stderr):
        try:
            with guard._isolated_body(item, temp, {}):
                make_cas()
                returned = observed_call(item, argv)
                observed_call(item, negative)
        except BaseException as exc:
            observed = exc
finally:
    Path.open = original_open
    subprocess.run = original_run
record(
    "receipt_write_failure_fails_success_qualification",
    {
        "completed_process_identity": returned is completed,
        "harness_exception": isinstance(observed, RuntimeError),
        "receipt_error_reported": "receipt_unavailable" in stderr.getvalue(),
        "stdout_retained": (temp / "q2-checker-0.stdout.txt").is_file(),
        "cwd_restored": Path.cwd().resolve() == start,
        "proxy_restored": item.module.subprocess is subprocess,
    },
)

# Failure to enter the private cwd is preserved and separately recorded.
temp, _, _ = case("enter-cwd-failure")
item = types.SimpleNamespace(module=types.SimpleNamespace(subprocess=subprocess))
sentinel = PermissionError("enter sentinel")


def fail_enter(path: object) -> None:
    if Path(path) == temp / guard.WORK_NAME:
        raise sentinel
    original_chdir(path)


os.chdir = fail_enter
observed = None
try:
    try:
        with guard._isolated_body(item, temp, {}):
            raise AssertionError("body must not start")
    except BaseException as exc:
        observed = exc
    receipt = read_receipt(temp)
finally:
    os.chdir = original_chdir
    original_chdir(start)
record(
    "enter_cwd_failure_preserved_and_recorded",
    {
        "original_exception_identity": observed is sentinel,
        "proxy_restored": item.module.subprocess is subprocess,
        "cwd_restored": Path.cwd().resolve() == start,
        "receipt_attempted": bool(receipt),
        "qualification_error": receipt.get("qualification_status") == "ERROR",
    },
    observed_exception=type(observed).__name__ if observed else None,
)

# A genuine child exception remains identical; no fabricated CompletedProcess.
temp, _, argv = case("child-exception")
item = types.SimpleNamespace(module=types.SimpleNamespace(subprocess=subprocess))
sentinel = OSError("child sentinel")
subprocess.run = lambda *a, **kw: (_ for _ in ()).throw(sentinel)
observed = None
try:
    try:
        with guard._isolated_body(item, temp, {}):
            observed_call(item, argv)
    except BaseException as exc:
        observed = exc
    receipt = read_receipt(temp)
finally:
    subprocess.run = original_run
record(
    "child_exception_identity_preserved",
    {
        "original_exception_identity": observed is sentinel,
        "no_fabricated_call": receipt.get("checker_calls") == [],
        "cwd_restored": Path.cwd().resolve() == start,
        "proxy_restored": item.module.subprocess is subprocess,
    },
)

report = {
    "scope": "stdlib-only fake pytest and synthetic files; no product imports or native tests",
    "plugin": str(args.plugin),
    "plugin_sha256": hashlib.sha256(args.plugin.read_bytes()).hexdigest(),
    "control_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "checks": checks,
    "passed": sum(bool(v["pass"]) for v in checks.values()),
    "total": len(checks),
    "runtime": "UNRUN",
}
with args.output.open("x", encoding="utf-8") as stream:
    json.dump(report, stream, indent=2, sort_keys=True)
    stream.write("\n")
sys.stdout.write(json.dumps(report, sort_keys=True) + "\n")
raise SystemExit(0 if report["passed"] == report["total"] else 1)
