"""Read the C07 before/removal/restored receipts without running a test."""

from __future__ import annotations

import hashlib
import json
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
HERE = Path(__file__).resolve().parent
D = ROOT / (
    "policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/"
    "root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/"
    "deep-task-status-audit-20261027-r1"
)
NODE = "test_repeated_input_views_recheck_all_roles_without_thawing_index"


def sha(path: Path) -> str | None:
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None


def check(condition: bool, reason: str) -> None:
    if not condition:
        raise ValueError(reason)


def read_case(kind: str, manifest: dict[str, object]) -> dict[str, object]:
    item = manifest["cases"][kind]
    plan_path = Path(item["plan"])
    out = D / item["case_id"]
    check(plan_path.parent == D and sha(plan_path) == item["plan_sha256"], kind + ": plan mismatch")
    required = [out / "audit-result.json", out / "source-profile-freeze.json", out / "pytest.xml"]
    check(all(p.is_file() for p in required), kind + ": missing retained output")
    plan = json.loads(plan_path.read_text())
    audit = json.loads(required[0].read_text())
    freeze = json.loads(required[1].read_text())
    result = audit["result"]
    before = freeze["before"]
    extra = plan.get("extra_env", {})
    check(
        all(freeze["extra_env"].get(key) == value for key, value in extra.items()),
        kind + ": plugin environment mismatch",
    )
    if kind != "mutant":
        check(
            "PYTEST_PLUGINS" not in freeze["extra_env"] and "PYTHONPATH" not in freeze["extra_env"],
            kind + ": unexpected plugin environment",
        )
    check(
        audit["plan"] == plan and freeze["plan_sha256"] == item["plan_sha256"],
        kind + ": plan binding mismatch",
    )
    check(
        audit["source_profile_freeze_sha256"] == sha(required[1]), kind + ": freeze hash mismatch"
    )
    check(
        before["head"] == manifest["head"] and before["source_frame"] == manifest["frame"],
        kind + ": source frame mismatch",
    )
    check(
        audit["guard_after"] == before and audit["current_mismatches"] == [],
        kind + ": source drift",
    )
    check(
        result["return_code"] == item["expected_exit"] and result["complete"] is True,
        kind + ": wrong exit or incomplete",
    )
    check(
        result["aborted_reason"] is None and result["process_group_gone"] is True,
        kind + ": aborted process",
    )
    expected_counts = {"tests": 1, "failures": int(kind == "mutant"), "errors": 0, "skipped": 0}
    check(result["junit"] == expected_counts, kind + ": unexpected JUnit counts")
    cases = list(ET.parse(required[2]).iter("testcase"))  # noqa: S314 -- retained pytest output
    check(len(cases) == 1 and cases[0].get("name") == NODE, kind + ": wrong test case")
    failure = cases[0].find("failure")
    if kind == "mutant":
        check(failure is not None, "mutant: missing intended failure")
        failure_text = (failure.get("message") or "") + (failure.text or "")
        check(
            "768 == 0" in failure_text and "whole_index_thaws" in failure_text,
            "mutant: wrong failure",
        )
    else:
        check(failure is None and cases[0].find("error") is None, kind + ": expected pass")
    readsets = audit.get("readsets")
    check(isinstance(readsets, list) and readsets, kind + ": missing loaded-source readset")
    for row in readsets:
        path = ROOT / row["path"]
        check(
            path.resolve().is_relative_to(out.resolve())
            and path.is_file()
            and sha(path) == row["sha256"],
            kind + ": readset mismatch",
        )
        check(row["pytest_exitstatus"] == item["expected_exit"], kind + ": readset exit mismatch")
    summary = {
        "kind": kind,
        "case_id": item["case_id"],
        "audit_sha256": sha(required[0]),
        "junit_sha256": sha(required[2]),
        "exit": result["return_code"],
        "seconds": result["wall_seconds"],
        "peak_rss": result["max_sampled_process_tree_rss_bytes"],
        "readset_files": len(readsets),
        "loaded_python_paths": audit["unique_runtime_loaded_python_paths"],
    }
    if kind == "mutant":
        receipt_path = out / "c07-removal-observer.json"
        check(receipt_path.is_file(), "mutant: missing hook/identity receipt")
        receipt = json.loads(receipt_path.read_text())
        expected = {
            "owner": manifest["owner_sha256"],
            "test": manifest["test_sha256"],
            "original_plugin": manifest["original_plugin_sha256"],
            "wrapper": manifest["wrapper_sha256"],
        }
        check(
            receipt["input_hashes_before"] == receipt["input_hashes_after"] == expected,
            "mutant: input identity mismatch",
        )
        check(
            receipt["active_was_observer"] is True and receipt["restored_same_object"] is True,
            "mutant: hook restoration missing",
        )
        before_fn, mutant_fn, wrapper_fn, restored_fn = (
            receipt[k] for k in ("before", "mutant", "observer", "restored")
        )
        check(
            before_fn["source"]
            == str(ROOT / "policy-engine/src/polisyos/core/artifacts/ownership.py")
            and before_fn["module"] == "polisyos.core.artifacts.ownership"
            and before_fn["qualname"] == "ArtifactOwnershipIndex._claim_rows_for_query"
            and mutant_fn["source"]
            == str(
                ROOT
                / (
                    "LOCAL/raw/e02-execution-20261027/repairs/C07-CAS-owner-dedup-r1/"
                    "remove_snapshot_query.py"
                )
            )
            and mutant_fn["module"] == "c07_existing_removal_control"
            and mutant_fn["qualname"] == "pytest_configure.<locals>.original_full_index_path"
            and wrapper_fn["source"] == str(HERE / "c07_removal_observer.py"),
            "mutant: method source identity mismatch",
        )
        check(
            before_fn == restored_fn,
            "mutant: restored function differs",
        )
        check(
            before_fn["identity"] != mutant_fn["identity"]
            and wrapper_fn["identity"] not in (before_fn["identity"], mutant_fn["identity"]),
            "mutant: identities not distinct",
        )
        check(
            receipt["restored_same_code_hash"] is True
            and mutant_fn["code_sha256"] != before_fn["code_sha256"],
            "mutant: code identity mismatch",
        )
        counts = receipt["invocations"]
        check(
            counts["total"] > 0
            and counts["total"] == counts["blob_readers_true"] + counts["blob_readers_false"],
            "mutant: missing method invocation",
        )
        summary["observer_receipt_sha256"] = sha(receipt_path)
        summary["actual_method_invocations"] = counts
        summary["same_process_restore"] = True
    return summary


def main() -> None:
    if len(sys.argv) != 2 or sys.argv[1] not in {"before", "mutant", "restored", "all"}:
        raise SystemExit("choose before, mutant, restored or all")
    manifest_path = HERE / "manifest.json"
    check(
        sha(manifest_path) == "6a1d68b15baf1220164970236b9aa96da0d2e3a94232ff3dabf25d4c7d4e014e",
        "manifest mismatch",
    )
    manifest = json.loads(manifest_path.read_text())
    stages = ("before", "mutant", "restored") if sys.argv[1] == "all" else (sys.argv[1],)
    summaries = [read_case(stage, manifest) for stage in stages]
    sys.stdout.write(
        json.dumps(
            {
                "qualified": True,
                "source_head": manifest["head"],
                "cases": summaries,
                "scope": (
                    "Three process-isolated test results; hook identity applies only "
                    "to mutant process. No S1/G closure."
                ),
            },
            indent=2,
        )
        + "\n"
    )


if __name__ == "__main__":
    main()
