from pathlib import Path
R=Path(__file__).parent/'policy-engine'
def edit(path,old,new):
 p=R/path;s=p.read_text();assert old in s,(path,old[:100]);p.write_text(s.replace(old,new,1))
p='src/polisyos/core/llm/cache_settlement.py'
edit(p,'import threading\n','import hashlib\nimport threading\n')
edit(p,'_OWNERS_BY_SESSION: dict[','_SESSIONS_BY_WRAPPER: dict[\n    int,\n    tuple[weakref.ReferenceType[object], weakref.ReferenceType[object], CacheSettlementSession],\n] = {}\n_OWNERS_BY_SESSION: dict[')
edit(p,'    origin_event_id: str\n\n\nclass CacheSettlementSession','    origin_event_id: str\n    response_digest: str\n    scope_key: tuple[str, ...]\n\n\nclass CacheSettlementSession')
edit(p,'        lifetime_owner = getattr(client, "_cache_settlement_owner", client)\n        return owner is not None and owner.owns(lifetime_owner)','        return owner is not None and session_for_cache_client(client) is self')
edit(p,'            response_identity=id(response),\n','            response_identity=id(response),\n            response_digest=_response_digest(response),\n')
edit(p,'        if owner is None or not owner.verify_provenance(provenance):','        if (\n            owner is None\n            or provenance.response_digest != _response_digest(response)\n            or not owner.verify_provenance(provenance)\n        ):')
edit(p,'            origin_event_id=provenance.origin_event_id,\n        )','            origin_event_id=provenance.origin_event_id,\n            response_digest=provenance.response_digest,\n            scope_key=provenance.scope_key,\n        )')
edit(p,'\n\ndef create_cache_settlement_session(client: object)', '''

    def release_flight(
        self,
        registrations: tuple[CacheFlightRegistration, ...],
        outcome: CacheFlightOutcome | None,
    ) -> None:
        """Release completed request bookkeeping after the last live waiter."""
        with _SESSION_LOCK:
            owner = _owner_or_raise(self)
            owner.release_flight(
                tuple(_registration_value(self, item) for item in registrations),
                _outcome_value(self, outcome) if outcome is not None else None,
            )

    def forget_cached_key(self, cache_key: str) -> None:
        """Forget a retained origin when its cache entry expires or is evicted."""
        with _SESSION_LOCK:
            _owner_or_raise(self).forget_cached_key(cache_key)


def _response_digest(response: object) -> str:
    content = getattr(response, "content", None)
    if type(content) is not str:
        raise ValueError("cache response content must be text")
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def bind_cache_settlement_client(cache: object, client: object) -> CacheSettlementSession:
    """Register an exact request wrapper with the exact cache owner inside Core."""
    session = create_cache_settlement_session(cache)
    try:
        client_ref = weakref.ref(client)
    except TypeError as exc:
        raise TypeError("cache wrapper must support weak references") from exc
    client_id = id(client)
    with _SESSION_LOCK:
        current = _SESSIONS_BY_WRAPPER.get(client_id)
        if current is not None and current[0]() is client:
            if current[1]() is not cache or current[2] is not session:
                raise ValueError("cache wrapper already belongs to another cache")
            return session
        client_ref = weakref.ref(
            client, lambda reference: _discard_wrapper(client_id, reference)
        )
        _SESSIONS_BY_WRAPPER[client_id] = (client_ref, weakref.ref(cache), session)
    return session


def _discard_wrapper(client_id: int, reference: weakref.ReferenceType[object]) -> None:
    with _SESSION_LOCK:
        current = _SESSIONS_BY_WRAPPER.get(client_id)
        if current is not None and current[0] is reference:
            del _SESSIONS_BY_WRAPPER[client_id]


def create_cache_settlement_session(client: object)''')
edit(p,'    lifetime_owner = getattr(client, "_cache_settlement_owner", client)\n    with _SESSION_LOCK:\n        current = _SESSIONS_BY_CLIENT.get(id(lifetime_owner))\n        if current is None or current[0]() is not lifetime_owner:\n            return None\n        return current[1]', '''    with _SESSION_LOCK:
        wrapper = _SESSIONS_BY_WRAPPER.get(id(client))
        if wrapper is not None and wrapper[0]() is client and wrapper[1]() is not None:
            return wrapper[2]
        current = _SESSIONS_BY_CLIENT.get(id(client))
        if current is None or current[0]() is not client:
            return None
        return current[1]''')
edit(p,'    "create_cache_settlement_session",','    "bind_cache_settlement_client",\n    "create_cache_settlement_session",')
p='src/polisyos/core/llm/settlement.py'
edit(p,'    response_identity: int\n    signature: bytes','    response_identity: int\n    response_digest: str\n    scope_key: tuple[str, ...]\n    signature: bytes')
edit(p,'        self._published: dict[tuple[str, str], str] = {}','        self._published: dict[tuple[str, str], tuple[str, tuple[str, ...]]] = {}')
edit(p,'            self._published[(cache_key, request_digest)] = origin_event_id','            self._published[(cache_key, request_digest)] = (origin_event_id, producer.scope_key)')
edit(p,'        response_identity: int,\n    ) -> _CacheReuseProvenance:', '        response_identity: int,\n        response_digest: str,\n    ) -> _CacheReuseProvenance:')
edit(p,'            origin_id = outcome.origin_event_id\n','            origin_id = outcome.origin_event_id\n            scope_key = outcome.scope_key\n')
edit(p,'            origin_id = self._published.get((cache_key, request_digest))\n            if not origin_id or origin_event_id != origin_id:', '            retained = self._published.get((cache_key, request_digest))\n            origin_id, scope_key = retained if retained is not None else (None, ())\n            if not origin_id or origin_event_id != origin_id:')
edit(p,'            cache_key, request_digest, reuse_id, origin_id, response_identity\n','            cache_key, request_digest, reuse_id, origin_id, response_identity,\n            response_digest, scope_key,\n')
edit(p,'            response_identity,\n            signature,','            response_identity,\n            response_digest,\n            scope_key,\n            signature,')
edit(p,'            or type(provenance.signature) is not bytes','            or type(provenance.response_digest) is not str\n            or type(provenance.scope_key) is not tuple\n            or not all(type(item) is str for item in provenance.scope_key)\n            or type(provenance.signature) is not bytes')
edit(p,'                provenance.response_identity,\n','                provenance.response_identity,\n                provenance.response_digest,\n                provenance.scope_key,\n')
# Signature method checked separately below.
edit(p,'        response_identity: int,\n    ) -> bytes:', '        response_identity: int,\n        response_digest: str,\n        scope_key: tuple[str, ...],\n    ) -> bytes:')
edit(p,'                "response_identity": response_identity,','                "response_identity": response_identity,\n                "response_digest": response_digest,\n                "scope_key": scope_key,')
edit(p,'    def registered_outcome(self, outcome: _CacheFlightOutcome) -> bool:', '''    def forget_cached_key(self, cache_key: str) -> None:
        """Remove origins for a key whose physical cache entry no longer exists."""
        for identity in tuple(self._published):
            if identity[0] == cache_key:
                del self._published[identity]

    def release_flight(
        self,
        registrations: tuple[_CacheFlightRegistration, ...],
        outcome: _CacheFlightOutcome | None,
    ) -> None:
        """Drop transient flight state after all response attestations were issued."""
        for registration in registrations:
            current = self._registration_handles.get(registration.attempt_id)
            if current is registration:
                self._registrations.pop(registration.attempt_id, None)
                self._registration_handles.pop(registration.attempt_id, None)
        if outcome is not None and self._outcomes.get(outcome.producer_attempt_id) is outcome:
            self._outcomes.pop(outcome.producer_attempt_id, None)

    def registered_outcome(self, outcome: _CacheFlightOutcome) -> bool:''')
p='src/polisyos/runtime/http/container.py'
edit(p,'            llm_prompt_cache = InMemoryPromptCache(\n                maxsize=cache_config.cache_maxsize,\n                default_ttl_s=cache_config.cache_ttl_s,\n            )','            if (\n                cache_config is not None\n                and cache_config.cache_maxsize > 0\n                and cache_config.cache_ttl_s > 0\n            ):\n                llm_prompt_cache = InMemoryPromptCache(\n                    maxsize=cache_config.cache_maxsize,\n                    default_ttl_s=cache_config.cache_ttl_s,\n                )')
# Closing the configured application cache also ends its retained origin lifetime.
edit(p,'            await _close_maybe_async(self.review_collaboration_hub)','            if self.llm_prompt_cache is not None:\n                clear_cache = getattr(self.llm_prompt_cache, "clear", None)\n                if callable(clear_cache):\n                    clear_cache()\n            await _close_maybe_async(self.review_collaboration_hub)')
