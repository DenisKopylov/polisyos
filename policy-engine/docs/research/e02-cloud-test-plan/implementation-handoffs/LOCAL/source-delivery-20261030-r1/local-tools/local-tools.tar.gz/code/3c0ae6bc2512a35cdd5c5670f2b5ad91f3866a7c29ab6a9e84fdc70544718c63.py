"""Construct unexecuted C41 removal ASTs from exact source without product imports."""

import ast
import inspect
import runpy
import types
from pathlib import Path

root = Path('LOCAL/raw/e02-execution-20261027/repairs/C41-r9-r4')
post = root / 'postimages/policy-engine/src/polisyos'
plugin = runpy.run_path(str(root / 'c41_r9_mutants_r4.py'))
mutate = plugin['_mutate']
original = inspect.getsource
items = (
    ('parent_isolation', 'runtime/http/routes/runs.py', '_generic_cycle_simulation_projection'),
    ('selected_scope', 'runtime/http/routes/runs.py', '_generic_selected_result_manifest'),
    ('access_denial', 'runtime/http/routes/runs.py', '_raise_generic_read_access_refusal'),
    ('wrapped_cause', 'core/artifacts/selected_verification.py', '__getattr__'),
    ('profile_pin', 'core/artifacts/selected_verification.py', 'verify'),
    ('history_owner_identity', 'runtime/http/routes/runs.py', '_candidate_simulation_projection'),
    ('legacy_default_pin', 'runtime/http/routes/runs.py', '_candidate_simulation_projection'),
    ('legacy_limitation', 'runtime/http/routes/runs.py', '_candidate_simulation_projection'),
)
try:
    for mode, path, name in items:
        text = (post / path).read_text()
        node = next(
            n for n in ast.walk(ast.parse(text)) if isinstance(n, ast.FunctionDef) and n.name == name
        )
        lines = text.splitlines(keepends=True)
        source = ''.join(lines[node.lineno - 1:node.end_lineno])
        inspect.getsource = lambda _fn, source=source: source
        result = mutate(types.SimpleNamespace(__name__=name), mode, {})
        assert callable(result) and result.__name__ == name
finally:
    inspect.getsource = original
print('eight static transformations constructed; no product import or behavioral execution')
