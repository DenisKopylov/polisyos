"""Build a sparse RAW canonical-owner repair; no product imports or tests."""
from pathlib import Path
import ast,difflib,hashlib,json,subprocess
ROOT=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
HERE=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
SOURCE='policy-engine/src/polisyos/scientist/nodes/builtins/compile/compile_foundry.py'
TEST='policy-engine/tests/unit/scientist/nodes/builtins/compile/test_compile_foundry_state_views.py'
README='policy-engine/src/polisyos/scientist/nodes/README.md'
RELEASE='policy-engine/release-fragments/unreleased/2026-10-28-e02-compile-state-array-views.toml'
source=(ROOT/SOURCE).read_text()
old='            if type(raw_bindings) is not list or len(raw_bindings) > METHOD_METRIC_BINDING_LIMIT:\n'
new='''            # Admitted workflow JSON arrays have a journaled list view. Preserve
            # the list contract without requiring the exact builtin class.
            if not isinstance(raw_bindings, list) or len(raw_bindings) > METHOD_METRIC_BINDING_LIMIT:
'''
assert source.count(old)==1
post=source.replace(old,new)
# Inspect the complete owner boundary, not a sampled neighboring expression.
tree=ast.parse(source)
exact=[{'line':n.lineno,'expression':ast.unparse(n)} for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='type']
assert len(exact)==1
readme=(ROOT/README).read_text()
companion='''
`compile/compile_foundry.py` consumes `params.method_metric_bindings` as a bounded
JSON array. The real engine supplies admitted arrays through journaled list
views, so the node accepts the list contract rather than the exact builtin
class. Each row still passes the strict `MethodMetricBindingRequest` DTO;
non-list inventories, boolean fields, extra fields, conflicting selections and
the existing inventory cap remain fail-closed. Selected policy/plan profiles,
method ABI, metric law and actual compiler provenance are reconciled by the
unchanged Foundry path. The state-view compatibility fix grants no metric value,
completed-source selection, calibration or publication authority.
'''
release='''id = "2026-10-28-e02-compile-state-array-views"
title = "Accept admitted workflow array views at method metric compilation"
type = "fixed"
component = "scientist-nodes"
owner = "team-policyos-runtime"
summary = "CompileFoundryNode accepts the engine's journaled list view for method metric binding requests while retaining strict row, bound and selected-profile validation."
evidence = ["tests/unit/scientist/nodes/builtins/compile/test_compile_foundry_state_views.py", "tests/unit/runtime/http/test_observational_method_runtime.py"]
change_class = "internal validation behavior"
surface_classification = "internal: canonical workflow state to Foundry compile request"
compatibility = "No DTO, schema, endpoint or generated client shape changes. A valid JSON array remains admissible after the existing engine wraps it in its state view. Arbitrary sequences, booleans, extra binding fields and oversized inventories remain refused."
migration = "Rerun affected workflow sources and read back actual compiled binding artifacts; do not synthesize selections or metric values for older failed runs."
limitations = "Source proposal only until focused real engine/compiler and negative checks run. The first R5 source failed at compile intake before simulation, source B or planner; C48 comparison and broader C05/C71/G authority remain unqualified."
generated_client_compatibility = "unchanged_wire_shape"
public_surface_inventory_reviewed = false
'''
files={SOURCE:(source,post),TEST:('',(HERE/'test_proposal.py.txt').read_text()),README:(readme,readme+companion),RELEASE:('',release)}
records=[];patch=''
for path,(pre,post) in files.items():
 if path.endswith('.py'):
  logical=path.removeprefix('policy-engine/')
  # Organize only this newly authored test import block; source mechanism unchanged.
  if path==TEST:
   r=subprocess.run(['.venv/bin/python','-m','ruff','check','--no-cache','--fix','--stdin-filename',logical,'-'],cwd=ROOT/'policy-engine',input=post.encode(),capture_output=True)
   if r.returncode:print(r.stderr.decode()+r.stdout.decode());raise SystemExit('test lint fix failed')
   post=r.stdout.decode()
  r=subprocess.run(['.venv/bin/python','-m','ruff','format','--no-cache','--stdin-filename',logical,'-'],cwd=ROOT/'policy-engine',input=post.encode(),capture_output=True)
  assert r.returncode==0,r.stderr
  formatted=r.stdout.decode();assert ast.dump(ast.parse(post),include_attributes=False)==ast.dump(ast.parse(formatted),include_attributes=False);post=formatted
  checks=[]
  for mode in ('check','format'):
   argv=['.venv/bin/python','-m','ruff',mode,'--no-cache']+(['--check'] if mode=='format' else [])+['--stdin-filename',logical,'-']
   r=subprocess.run(argv,cwd=ROOT/'policy-engine',input=post.encode(),capture_output=True)
   checks.append({'argv':argv,'exit':r.returncode,'output':(r.stdout+r.stderr).decode()})
   assert r.returncode==0,r.stdout+r.stderr
  (HERE/(Path(path).stem+'-static.json')).write_text(json.dumps({'AST':'PASS no imports','checks':checks},indent=2)+'\n')
 dest=HERE/'postimage'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(post)
 piece=''.join(difflib.unified_diff(pre.splitlines(keepends=True),post.splitlines(keepends=True),fromfile='a/'+path if pre else '/dev/null',tofile='b/'+path));patch+=piece
 records.append({'path':path,'pre_sha256':sha(pre.encode()) if pre else None,'post_sha256':sha(post.encode()),'postimage':str(dest.relative_to(HERE))})
(HERE/'source.patch').write_text(patch)
(HERE/'proposal.json').write_text(json.dumps({'base':'a437f597212cc7cc6dcb1c60fff9fb018ce43fe0','files':records,'patch_sha256':sha(patch.encode()),'complete_owner_exact_type_calls':exact,'runtime':'UNRUN'},indent=2)+'\n')
r=subprocess.run(['git','apply','--check','--',str(HERE/'source.patch')],cwd=ROOT,capture_output=True);assert r.returncode==0,r.stderr
print(json.dumps({'files':records,'patch_sha256':sha(patch.encode()),'apply_check':r.returncode},indent=2))
