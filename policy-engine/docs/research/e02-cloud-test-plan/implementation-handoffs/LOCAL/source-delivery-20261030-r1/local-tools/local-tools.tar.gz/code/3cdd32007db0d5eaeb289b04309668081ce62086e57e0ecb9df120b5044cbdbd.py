"""Synthetic plugin CALL, semantic red and cleanup; fake pytest only."""
from __future__ import annotations

import asyncio
import io
import json
from pathlib import Path
import sys
import tempfile
from types import ModuleType, SimpleNamespace

pytest = ModuleType('pytest')
pytest.hookimpl = lambda **_kwargs: lambda f: f
pytest.ExitCode = SimpleNamespace(INTERNAL_ERROR=3)
sys.modules['pytest'] = pytest
import r171_reason_removal as probe

owner_source = '''\
class GenerationCycleController:
    def _n7_data_requirement_basis_with_report(self):
        source_gap = SimpleNamespace(requirement_gap_id="source-gap")
        request_binding_refused = False
        source_family_limitation = "unbound_requirement_input_refused"
        routing_limitation_code = source_family_limitation
        if source_gap is not None and not request_binding_refused and routing_limitation_code is None:
            routing_limitation_code = "requirement_gap_not_compiled"
        resolution = SimpleNamespace(state="not_established", basis_grade="not_established")
        return SimpleNamespace(compilation_report=SimpleNamespace(requirement_basis=resolution), routed_source_gap=source_gap,
                               routing_limitation_code=routing_limitation_code, specs=(), routed_compiler_gaps=())
'''
test_source = '''\
async def test_conflicting_n7_family_declaration_is_costed_refusal():
    basis = owner.GenerationCycleController()._n7_data_requirement_basis_with_report()
    report = SimpleNamespace(status="blocked", basis_limitation_code="requirement_basis_not_established", cost_estimation_status="not_estimated", acquisition_records=())
    cycle = SimpleNamespace(acquisition_routing_report=report, acquisition_routing_report_ref="persisted-ref", acquisition_cost_basis_record=None, acquisition_receipt=None)
    assert basis.routing_limitation_code == "unbound_requirement_input_refused"
'''
with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as name:
    root = Path(name); owner_path = root / 'owner.py'; test_path = root / 'test.py'
    owner_path.write_text(owner_source); test_path.write_text(test_source)
    owner = ModuleType('synthetic_r171_owner'); owner.__file__ = str(owner_path); owner.SimpleNamespace = SimpleNamespace
    exec(compile(owner_source, str(owner_path), 'exec', dont_inherit=True), owner.__dict__)
    sys.modules[owner.__name__] = owner
    namespace = {'owner':owner, 'SimpleNamespace':SimpleNamespace}
    exec(compile(test_source, str(test_path), 'exec', dont_inherit=True), namespace)
    probe.OWNER, probe.TEST, probe.stream, probe.pins = owner_path, test_path, io.StringIO(), lambda: {}
    probe.assertion_span = probe.assertion()
    item = SimpleNamespace(nodeid=probe.NODE, module=SimpleNamespace(generation_cycle_module=owner))
    hook = probe.pytest_runtest_call(item); next(hook)
    try:
        asyncio.run(namespace[probe.TEST_NAME]())
    except AssertionError:
        tb = sys.exc_info()[2]
        entries = []
        while tb:
            entries.append(SimpleNamespace(lineno=tb.tb_lineno-1, frame=SimpleNamespace(raw=tb.tb_frame, f_locals=tb.tb_frame.f_locals)))
            tb = tb.tb_next
    else:
        raise AssertionError('removal failed to change the actual selected semantic assertion')
    try:
        next(hook)
    except StopIteration:
        pass
    call = SimpleNamespace(when='call', excinfo=SimpleNamespace(type=AssertionError, traceback=entries))
    for when,outcome in [('setup','passed'),('call','failed'),('teardown','passed')]:
        event = call if when == 'call' else SimpleNamespace(when=when, excinfo=None)
        reporter = probe.pytest_runtest_makereport(item,event); next(reporter)
        try:
            reporter.send(SimpleNamespace(get_result=lambda:SimpleNamespace(when=when,outcome=outcome)))
        except StopIteration:
            pass
    session=SimpleNamespace(exitstatus=1);probe.pytest_sessionfinish(session,1)
    rows=[json.loads(line) for line in probe.stream.getvalue().splitlines()]
    assert session.exitstatus == 1 and probe.semantic_failure and probe.restored
    assert rows[-1]['classification']=='EXPECTED_SEMANTIC_REMOVAL'
    assert owner.GenerationCycleController()._n7_data_requirement_basis_with_report().routing_limitation_code == 'unbound_requirement_input_refused'
    assert not probe.errors
    # An unrelated earlier failure cannot qualify merely because a prior
    # producer witness and the same fixture locals happened to exist.
    probe.semantic_failure = False
    entries[-1].lineno = probe.assertion_span[0] - 2
    reporter = probe.pytest_runtest_makereport(item, call); next(reporter)
    try:
        reporter.send(SimpleNamespace(get_result=lambda:SimpleNamespace(when='call',outcome='failed')))
    except StopIteration:
        pass
    other = SimpleNamespace(exitstatus=1); probe.pytest_sessionfinish(other, 1)
    rows=[json.loads(line) for line in probe.stream.getvalue().splitlines()]
    assert other.exitstatus == 3 and not probe.semantic_failure
    assert rows[-1]['classification'] == 'INSTRUMENT_OR_ORACLE_ERROR'
    print(json.dumps({'scope':'synthetic producer, selected assertion, unrelated failure and fake pytest; no product import','events':rows},indent=2))
