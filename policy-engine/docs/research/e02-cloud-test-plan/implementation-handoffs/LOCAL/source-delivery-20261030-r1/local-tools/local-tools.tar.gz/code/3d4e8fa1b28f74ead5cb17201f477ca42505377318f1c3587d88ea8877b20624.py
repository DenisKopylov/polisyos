"""Isolated behavioral removals for C01, with exact active function custody.

This opt-in pytest plugin never writes product source. A root-authored native plan
must bind the correct frozen source, test, plugin and mode before it is loaded.
It transforms one current function in memory and records the actual transformed
function source/code plus real HTTP observations; a failing product assertion is
expected evidence, not a passing product check.
"""

from __future__ import annotations

import ast
import hashlib
import inspect
import json
import marshal
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

import pytest

_NODE = (
    "tests/unit/runtime/http/test_debug_api.py::"
    "test_simulation_result_http_requires_exact_identity_for_every_same_id_node_ref"
)
_DEBUG_PATH = "src/polisyos/runtime/http/services/debug.py"
_TEST_PATH = "tests/unit/runtime/http/test_debug_api.py"
_STATE: dict[str, Any] = {}


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _required(name: str) -> str:
    value = os.environ.get(name)
    if not value:
        raise pytest.UsageError(f"C01 control input missing: {name}")
    return value


def _save(path: Path, value: object) -> None:
    if path.is_symlink():
        raise pytest.UsageError("C01 control output cannot be a symlink")
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def _git(root: Path, *args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=root, text=True).strip()


def pytest_configure(config: pytest.Config) -> None:
    """Admit exact correct source and install precisely one in-memory removal."""
    root = Path(config.rootpath).resolve(strict=True)
    if Path.cwd().resolve(strict=True) != root:
        raise pytest.UsageError("C01 control must use the actual product cwd")
    plugin_path = Path(__file__).resolve(strict=True)
    expected_plugin_sha = _required("POLISYOS_C01_CONTROL_PLUGIN_SHA256")
    if _sha(plugin_path.read_bytes()) != expected_plugin_sha:
        raise pytest.UsageError("C01 control plugin bytes mismatch")
    source_path = root / _DEBUG_PATH
    test_path = root / _TEST_PATH
    source_sha = _required("POLISYOS_C01_CONTROL_DEBUG_SHA256")
    test_sha = _required("POLISYOS_C01_CONTROL_TEST_SHA256")
    if _sha(source_path.read_bytes()) != source_sha or _sha(test_path.read_bytes()) != test_sha:
        raise pytest.UsageError("C01 control correct source/test bytes mismatch")
    entry_head = _git(root, "rev-parse", "HEAD")
    entry_tree = _git(root, "rev-parse", "HEAD^{tree}")
    if entry_head != _required("POLISYOS_C01_CONTROL_SOURCE_HEAD"):
        raise pytest.UsageError("C01 control source HEAD mismatch")
    output = Path(_required("POLISYOS_C01_CONTROL_OUTPUT")).resolve(strict=True)
    allowed_parent = Path(_required("POLISYOS_R4_INPUT_READSET_DIR")).parent.resolve(strict=True)
    if output != allowed_parent:
        raise pytest.UsageError("C01 control output must equal the admitted native run directory")
    active_path = output / "active-control.py"
    receipt_path = output / "control-mutation.json"
    if active_path.exists() or receipt_path.exists():
        raise pytest.UsageError("C01 control outputs already exist")

    from polisyos.runtime.http.services import debug

    if Path(debug.__file__).resolve(strict=True) != source_path.resolve(strict=True):
        raise pytest.UsageError("C01 control loaded debug owner from a different source")
    mode = _required("POLISYOS_C01_CONTROL_MODE")
    if mode == "profile":
        target = "_require_exact_artifact_ref_binding"
    elif mode == "ambiguity":
        target = "_unique_workflow_report_node"
    else:
        raise pytest.UsageError("C01 control mode invalid")
    original = getattr(debug, target)
    source = inspect.getsource(original)
    tree = ast.parse(source)
    rewritten = 0
    if mode == "profile":

        class RemoveProfile(ast.NodeTransformer):
            def visit_Call(self, node: ast.Call) -> ast.AST:
                nonlocal rewritten
                self.generic_visit(node)
                if isinstance(node.func, ast.Name) and node.func.id == "artifact_ref_identity_key":
                    rewritten += 1
                    return ast.copy_location(
                        ast.Subscript(
                            value=node,
                            slice=ast.Slice(upper=ast.Constant(value=3)),
                            ctx=ast.Load(),
                        ),
                        node,
                    )
                return node

        tree = RemoveProfile().visit(tree)
        if rewritten != 2:
            raise pytest.UsageError("C01 profile control did not find exactly two owner-key calls")
        description = "Drop only the profile coordinate from each current identity-key comparison"
    else:
        for node in ast.walk(tree):
            if not isinstance(node, ast.If):
                continue
            check = node.test
            if (
                isinstance(check, ast.Compare)
                and isinstance(check.left, ast.Name)
                and check.left.id == "selected"
                and len(check.ops) == 1
                and isinstance(check.ops[0], ast.IsNot)
                and len(check.comparators) == 1
                and isinstance(check.comparators[0], ast.Constant)
                and check.comparators[0].value is None
            ):
                node.test = ast.BoolOp(
                    op=ast.And(),
                    values=[
                        check,
                        ast.Call(
                            func=ast.Name(id="_c01_ambiguity_enabled", ctx=ast.Load()),
                            args=[],
                            keywords=[],
                        ),
                    ],
                )
                rewritten += 1
        if rewritten != 1:
            raise pytest.UsageError(
                "C01 ambiguity control did not find exactly one duplicate guard"
            )
        description = "Suppress only the duplicate-alias guard; keep its message and all ref checks"
    ast.fix_missing_locations(tree)
    active_source = ast.unparse(tree) + "\n"
    active_path.write_text(active_source)
    namespace = dict(vars(debug))
    namespace["_c01_ambiguity_enabled"] = lambda: False
    # This compiles only the admitted owner function with the declared AST removal.
    exec(compile(active_source, str(active_path), "exec"), namespace)  # noqa: S102
    active = namespace[target]
    setattr(debug, target, active)
    _STATE.update(
        module=debug,
        target=target,
        original=original,
        active=active,
        root=root,
        source_path=source_path,
        test_path=test_path,
        source_sha=source_sha,
        test_sha=test_sha,
        receipt_path=receipt_path,
        receipt={
            "mode": mode,
            "property_removed": description,
            "source_head": entry_head,
            "source_tree": entry_tree,
            "correct_module_path": str(source_path),
            "correct_module_sha256": source_sha,
            "correct_test_path": str(test_path),
            "correct_test_sha256": test_sha,
            "plugin_path": str(plugin_path),
            "plugin_sha256": expected_plugin_sha,
            "original_function_source_sha256": _sha(source.encode()),
            "original_function_code_sha256": _sha(marshal.dumps(original.__code__)),
            "active_function_source_path": str(active_path),
            "active_function_source_sha256": _sha(active_source.encode()),
            "active_function_code_sha256": _sha(marshal.dumps(active.__code__)),
            "active_function_filename": active.__code__.co_filename,
            "rewrite_count": rewritten,
            "python": sys.version,
            "http_observations": [],
            "runtime_outcome": "RUNNING",
            "limitations": [
                "Deliberate in-memory control: module readset hashes describe correct frozen files; active function bytes are separately delivered here",
                "This is one behavioral removal, not a production PASS or all-E02 acceptance",
            ],
        },
    )
    _save(receipt_path, _STATE["receipt"])


def pytest_collection_finish(session: pytest.Session) -> None:
    """Require the actual served matrix as the complete selected control quantity."""
    nodes = [item.nodeid for item in session.items]
    if nodes != [_NODE]:
        raise pytest.UsageError(f"C01 control requires exactly the canonical HTTP matrix: {nodes}")
    _STATE["receipt"]["selected_nodes"] = nodes


@pytest.hookimpl(wrapper=True)
def pytest_runtest_call(item: pytest.Item):
    """Observe real HTTP results without replacing responses or test assertions."""
    env = item.funcargs.get("simulation_result_api_env")
    if not isinstance(env, dict) or env.get("client") is None:
        raise pytest.UsageError("C01 control lacks the real HTTP fixture client")
    client = env["client"]
    original_get = client.get

    def observed_get(*args: Any, **kwargs: Any):
        response = original_get(*args, **kwargs)
        if args and str(args[0]).endswith("/nodes/simulate/simulation-result"):
            payload = response.json()
            debug_payload = payload.get("debug") if isinstance(payload, dict) else None
            _STATE["receipt"]["http_observations"].append(
                {
                    "url": str(args[0]),
                    "params": kwargs.get("params"),
                    "status": response.status_code,
                    "response_bytes_sha256": _sha(response.content),
                    "error_code": payload.get("code") if isinstance(payload, dict) else None,
                    "projected_node_id": debug_payload.get("node_id")
                    if isinstance(debug_payload, dict)
                    else None,
                    "projected_artifact_ref": debug_payload.get("artifact_ref")
                    if isinstance(debug_payload, dict)
                    else None,
                }
            )
        return response

    client.get = observed_get
    try:
        return (yield)
    finally:
        client.get = original_get


def pytest_sessionfinish(session: pytest.Session, exitstatus: int) -> None:
    """Retain the actual mutation/result identity and restore the in-process owner."""
    if not _STATE:
        return
    receipt = _STATE["receipt"]
    receipt["pytest_exitstatus"] = int(exitstatus)
    receipt["runtime_outcome"] = "FINISHED"
    receipt["correct_module_bytes_unchanged"] = (
        _sha(_STATE["source_path"].read_bytes()) == _STATE["source_sha"]
    )
    receipt["correct_test_bytes_unchanged"] = (
        _sha(_STATE["test_path"].read_bytes()) == _STATE["test_sha"]
    )
    receipt["head_unchanged"] = _git(_STATE["root"], "rev-parse", "HEAD") == receipt["source_head"]
    receipt["active_function_still_installed_at_finish"] = (
        getattr(_STATE["module"], _STATE["target"]) is _STATE["active"]
    )
    setattr(_STATE["module"], _STATE["target"], _STATE["original"])
    receipt["original_function_restored_in_process"] = (
        getattr(_STATE["module"], _STATE["target"]) is _STATE["original"]
    )
    _save(_STATE["receipt_path"], receipt)
    print(
        "C01_REMOVAL_CONTROL="
        + json.dumps(
            {
                "mode": receipt["mode"],
                "pytest_exitstatus": receipt["pytest_exitstatus"],
                "http_reads": len(receipt["http_observations"]),
                "correct_module_bytes_unchanged": receipt["correct_module_bytes_unchanged"],
                "correct_test_bytes_unchanged": receipt["correct_test_bytes_unchanged"],
                "receipt_path": str(_STATE["receipt_path"]),
            },
            sort_keys=True,
        )
    )
