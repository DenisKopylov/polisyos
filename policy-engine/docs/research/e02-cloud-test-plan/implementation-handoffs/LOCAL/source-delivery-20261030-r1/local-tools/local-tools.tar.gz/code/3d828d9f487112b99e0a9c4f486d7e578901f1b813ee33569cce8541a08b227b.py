"""Root-only preparation of one committed G27 oracle case; no test execution."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
PRODUCT = ROOT / "policy-engine"
PACKET = ROOT / "LOCAL/raw/e02-execution-20261027/repairs/G27-local-owner-oracle-r1"
PREPARE = ROOT / "LOCAL/raw/e02-execution-20261027/prepare_root_native_case_r2.py"
NATIVE = PRODUCT / (
    "docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/"
    "root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/"
    "deep-task-status-audit-20261027-r1"
)
TEST = "tests/integration/runtime/http/test_g27_owner_generation_oracle.py"
NODES = {
    "pilot": [f"{TEST}::test_g27_real_sql_withdraw_a_after_b_fresh_owner"],
    "cohort": [
        f"{TEST}::test_g27_retry_conflict_gap",
        f"{TEST}::test_g27_unknown_scope_and_legacy",
    ],
}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git(*args: str) -> bytes:
    return subprocess.check_output(["git", "-C", str(ROOT), *args])


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expected-head", required=True)
    parser.add_argument("--expected-tree", required=True)
    parser.add_argument("--case-id", required=True)
    parser.add_argument("--phase", choices=tuple(NODES), required=True)
    args = parser.parse_args()
    assert git("rev-parse", "HEAD").decode().strip() == args.expected_head
    assert git("rev-parse", "HEAD^{tree}").decode().strip() == args.expected_tree
    assert Path(sys.prefix).resolve() == (PRODUCT / ".venv").resolve()
    manifest = json.loads((PACKET / "manifest.json").read_bytes())
    for row in manifest["files"]:
        data = (ROOT / row["path"]).read_bytes()
        assert sha(data) == row["post_sha256"]
        assert data == git("show", args.expected_head + ":" + row["path"])
        assert data == git("show", ":" + row["path"])
    inputs = json.loads((PACKET / "mechanism-inputs.json").read_bytes())
    pin_bytes = (ROOT / inputs["pin_manifest"]).read_bytes()
    assert sha(pin_bytes) == inputs["pin_manifest_sha256"]
    for row in json.loads(pin_bytes)["files"]:
        assert sha((ROOT / row["path"]).read_bytes()) == row["sha256"]
    scope = (
        "G27 direct registered-SQL owner oracle " + args.phase + ": genuine configured "
        "service/JWT/OPA, selected SQLite/Fabric CAS, real durable owner. T01/T02/T06 only; "
        "no process-kill/fence-order, packet, SimulationResult or external-currentness proof. "
        "The local TCP exception also allows wildcard binds; production-data reads stay denied. "
        "R3 module readback is finite imported-source evidence, not selected CodeType qualification."
    )
    result = subprocess.run(
        [sys.executable, "-B", str(PREPARE), args.case_id, *NODES[args.phase], "--scope", scope],
        cwd=ROOT,
        capture_output=True,
        check=False,
    )
    assert result.returncode == 0, result.stderr.decode()
    plan_path = NATIVE / (args.case_id + ".json")
    plan = json.loads(plan_path.read_bytes())
    assert (plan["source_head"], plan["source_tree"]) == (args.expected_head, args.expected_tree)
    assert plan["nodes"] == NODES[args.phase]
    fragment = plan["sandbox_profile_fragment"]
    assert fragment.count("(deny network*)\n") == 1
    fragment = fragment.replace(
        "(deny network*)\n",
        "(deny network*)\n"
        '(allow network-bind (local tcp "localhost:*"))\n'
        '(allow network-inbound (local tcp "localhost:*"))\n'
        '(allow network-outbound (remote tcp "localhost:*"))\n',
    )
    text = (
        "(version 1)\n(allow default)\n(deny file-write*)\n(allow file-write* (subpath "
        + json.dumps(str(NATIVE / args.case_id))
        + "))\n"
        '(allow file-write* (literal "/dev/null"))\n' + fragment
    )
    plan.update(
        {
            "sandbox_profile_fragment": fragment,
            "sandbox_profile_fragment_sha256": sha(fragment.encode()),
            "sandbox_profile_text": text,
            "sandbox_profile_sha256": sha(text.encode()),
        }
    )
    assert git("rev-parse", "HEAD").decode().strip() == args.expected_head
    plan_path.write_text(json.dumps(plan, indent=2) + "\n")
    print(
        json.dumps(
            {
                "plan": str(plan_path),
                "sha256": sha(plan_path.read_bytes()),
                "expected_head": args.expected_head,
                "expected_tree": args.expected_tree,
                "phase": args.phase,
                "selected_count": len(NODES[args.phase]),
                "tests_run": False,
            }
        )
    )


if __name__ == "__main__":
    main()
