from pathlib import Path
import ast, subprocess
r=Path(__file__).parent/'policy-engine'
p=r/'tests/unit/fabric/data_plane/test_e02_c_streaming_oracle.py';t=p.read_text()
a=t.index('@pytest.mark.parametrize("manifest_kind"') if '@pytest.mark.parametrize("manifest_kind"' in t else t.index('def test_b79_supported_rest_request')
# Preserve the decorator if it precedes the function under the expected name.
if t[a:].startswith('def '):
 prev=t.rfind('@pytest.mark.parametrize',0,a)
 if prev>a-150:a=prev
b=t.index('@pytest.mark.parametrize("strategy"',a)
new='''@pytest.mark.parametrize("manifest_kind", ["dict", "spec"])
def test_b79_finite_file_replay_uses_only_its_admitted_persisted_cursor(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, manifest_kind: str
) -> None:
    """Actual file replay proves portable progress; it makes no live REST claim."""
    from copy import deepcopy
    from tests._helpers.source_progress import write_source_history
    from polisyos.fabric.data_plane.modes import run_batch_incremental
    from polisyos.fabric.ingestion import resolve_ingestion_dependencies
    from polisyos.fabric.ingestion.source_progress import ReconciledSourceFrame

    reader = finite_source_reader(
        tmp_path / "owner", connector_id="rest.json", dataset_id="dataset",
        schema_id="rest.json.dataset", snapshots=[('"etag-prior"', [])],
    )
    ConnectorRegistry.reset_instance()
    registry = ConnectorRegistry.get_instance()
    config = ConnectionConfig(url=reader.fixture_path.as_uri())
    registry.set_default_config("rest.json", config)
    dependencies = resolve_ingestion_dependencies(registry=registry, source_progress_readers=(reader,))
    if manifest_kind == "dict":
        manifest: Any = {"datasets": [{"connector_id": "rest.json", "dataset_id": "dataset"}]}
    else:
        from polisyos.fabric.ingestion import ConnectorManifestSpec, DatasetFetchSpec
        manifest = ConnectorManifestSpec(datasets=[DatasetFetchSpec(connector_id="rest.json", dataset_id="dataset")])
    observed = []
    real_fetch = ReconciledSourceFrame.replay_fetch
    def observe(frame, actual_config, request):
        observed.append(request)
        return real_fetch(frame, actual_config, request)
    monkeypatch.setattr(ReconciledSourceFrame, "replay_fetch", observe)
    cas_root = tmp_path / "cas"
    def run(root=cas_root):
        return run_batch_incremental(connector_manifest=manifest, source="b79-file-replay", license_name="fixture-only", cas_root=root, connection_config=config, produce_snapshot=True, ingestion_dependencies=dependencies)
    try:
        first = run()
        assert first.status == "completed" and first.cursor_ref is not None
        assert observed[-1].incremental_since is None
        prior = CursorStore(FileSystemCAS(cas_root)).find_latest_cursor("rest.json", "dataset")
        row = {"event_id": "one", "source_version": "1"}
        write_source_history(reader, [('"etag-prior"', []), ('"etag-next"', [row])])
        result = run()
        assert result.status == "completed" and result.cursor_ref is not None
        assert observed[-1].incremental_since.value == '"etag-prior"'
        current = CursorStore(FileSystemCAS(cas_root)).find_latest_cursor("rest.json", "dataset")
        assert current.watermark_value == '"etag-next"'
        assert current.metadata["cache_key"] == observed[-1].cache_key
        from polisyos.core.artifacts import load_core_json_artifact
        from polisyos.core.contracts.fabric import DataSnapshot
        from polisyos.foundry.data_plane.bindings import _load_binding_payload
        store = FileSystemCAS(cas_root)
        snapshot = DataSnapshot.model_validate(load_core_json_artifact(store, result.data_snapshot_ref))
        payload = _load_binding_payload(store, snapshot)
        assert payload["admission_scope"] == "finite_source_fixture"
        assert payload["production_currentness"] == "not_established"
        assert {r["event_id"] for member in payload["sources"].values() for r in member["data"]} == {"one"}
        changed_metadata = deepcopy(current.metadata)
        changed_metadata["source_progress"]["payload_ref"]["manifest_profile_sha256"] = "0" * 64
        changed_profile = current.model_copy(update={"metadata": changed_metadata})
        CursorStore(store).save_cursor(changed_profile)
        negative = run()
        assert negative.status == "partial" and negative.cursor_ref is None
        assert observed[-1].incremental_since is None
        assert CursorStore(store).find_latest_cursor("rest.json", "dataset") == changed_profile
        legacy_root = tmp_path / "legacy"
        legacy = prior.model_copy(update={"metadata": {}, "evidence_bundle_ref": None})
        CursorStore(FileSystemCAS(legacy_root)).save_cursor(legacy)
        refused = run(legacy_root)
        assert refused.status == "partial" and refused.data_snapshot_ref is None
        assert observed[-1].incremental_since is None
        assert CursorStore(FileSystemCAS(legacy_root)).find_latest_cursor("rest.json", "dataset") == legacy
    finally:
        registry.shutdown()


def test_b79_matching_finite_file_cannot_authorize_a_live_endpoint(
    tmp_path: Path,
) -> None:
    """Hidden C with unchanged A/B/complete declarations never promotes live progress."""
    from polisyos.fabric.data_plane.modes import run_batch_incremental
    from polisyos.fabric.ingestion import resolve_ingestion_dependencies
    rows = [{"event_id": key, "source_version": "1"} for key in ("A", "B", "C")]
    observed = []
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            query = parse_qs(urlsplit(self.path).query)
            observed.append(query)
            # The network source has C, but declares A/B to be a complete A9.
            body = json.dumps({"data": rows[:2]}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("eTaG", '"a9"')
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        def log_message(self, format, *args):
            del format, args
    reader = finite_source_reader(tmp_path / "owner", connector_id="rest.json", dataset_id="dataset", schema_id="rest.json.dataset", snapshots=[('"a9"', rows[:2])])
    ConnectorRegistry.reset_instance()
    registry = ConnectorRegistry.get_instance()
    dependencies = resolve_ingestion_dependencies(registry=registry, source_progress_readers=(reader,))
    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        result = run_batch_incremental(connector_manifest={"datasets": [{"connector_id": "rest.json", "dataset_id": "dataset"}]}, source="b79-live-negative", license_name="fixture-only", cas_root=tmp_path / "cas", connection_config=ConnectionConfig(url=f"http://127.0.0.1:{server.server_port}/records"), produce_snapshot=True, ingestion_dependencies=dependencies)
        assert result.status == "partial" and result.cursor_ref is None and result.data_snapshot_ref is None
        assert observed and all("since" not in query for query in observed)
        assert CursorStore(FileSystemCAS(tmp_path / "cas")).find_latest_cursor("rest.json", "dataset") is None
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)
        registry.shutdown()


def test_b80_two_source_failure_then_fresh_snapshot_consumes_both_sources(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A9/B4 then fresh Snapshot B is A9/B5 through the real Foundry loader."""
    from tests._helpers.source_progress import write_source_history
    from polisyos.core.artifacts import load_core_json_artifact
    from polisyos.core.artifacts.manifest import SchemaInfo
    from polisyos.core.artifacts.write_contract import ArtifactWriteOptions
    from polisyos.core.canon import CanonSpec
    from polisyos.core.contracts.fabric import DataSnapshot
    from polisyos.fabric.connectors.sources.rest_json import RestJsonConnector
    from polisyos.fabric.data_plane.modes import run_batch_incremental
    from polisyos.fabric.ingestion import resolve_ingestion_dependencies
    from polisyos.fabric.ingestion.source_collection import SourceCollection, source_namespace
    from polisyos.fabric.ingestion.source_progress import ReconciledSourceFrame, SourceProgressAdmissionError
    from polisyos.foundry.data_plane.bindings import _load_binding_payload, _resolve_source_path

    a9 = {"event_id": "a-event-9", "source_version": "9", "event_time": "2025-01-01T00:00:00Z"}
    b5 = {"event_id": "b-late-event-5", "source_version": "5", "event_time": "2024-01-01T00:00:00Z"}
    readers = {source: finite_source_reader(tmp_path / "owner", connector_id=f"fixture.{source}", dataset_id="events", schema_id=f"fixture.{source}.events", snapshots=[(version, [])]) for source, version in (("source_a", "a8"), ("source_b", "b4"))}
    ConnectorRegistry.reset_instance()
    registry = ConnectorRegistry.get_instance()
    for source, reader in readers.items():
        cls = type(source.title()+"Connector", (RestJsonConnector,), {"connector_id": f"fixture.{source}", "namespace": "fixture", "short_id": source, "metadata": RestJsonConnector.metadata.model_copy(update={"connector_id": source, "namespace": "fixture"})})
        registry.register(cls, config=ConnectionConfig(url=reader.fixture_path.as_uri()))
    dependencies = resolve_ingestion_dependencies(registry=registry, source_progress_readers=tuple(readers.values()))
    manifest = {"datasets": [{"connector_id": f"fixture.{source}", "dataset_id": "events"} for source in readers]}
    observed = []
    phase = {"value": "initial"}
    real_fetch = ReconciledSourceFrame.replay_fetch
    def transient_io(frame, config, request):
        observed.append((frame.extension.connector_id, request.incremental_since.value if request.incremental_since else None))
        if phase["value"] == "fail-b" and frame.extension.connector_id == "fixture.source_b":
            raise SourceProgressAdmissionError("actual_source_unavailable", connector_id="fixture.source_b", dataset_id="events")
        return real_fetch(frame, config, request)
    monkeypatch.setattr(ReconciledSourceFrame, "replay_fetch", transient_io)
    cas_root = tmp_path / "cas"
    def run():
        return run_batch_incremental(connector_manifest=manifest, source="b80-file-replay", license_name="fixture-only", cas_root=cas_root, produce_snapshot=True, ingestion_dependencies=dependencies)
    try:
        assert run().status == "completed"
        write_source_history(readers["source_a"], [("a8", []), ("a9", [a9])])
        write_source_history(readers["source_b"], [("b4", []), ("b5", [b5])])
        phase["value"] = "fail-b"
        partial = run()
        assert partial.status == "partial" and partial.data_snapshot_ref is None
        after_failure = CursorStore(FileSystemCAS(cas_root))
        assert after_failure.find_latest_cursor("fixture.source_a", "events").watermark_value == "a9"
        assert after_failure.find_latest_cursor("fixture.source_b", "events").watermark_value == "b4"
        phase["value"] = "retry"
        complete = run()
        assert complete.status == "completed" and complete.data_snapshot_ref is not None
        assert observed == [("fixture.source_a", None), ("fixture.source_b", None), ("fixture.source_a", "a8"), ("fixture.source_b", "b4"), ("fixture.source_a", "a9"), ("fixture.source_b", "b4")]
        # A's successful retry transport delta is empty. Only the newly returned
        # Snapshot B is opened; no union with any earlier bundle/snapshot exists.
        fresh_store = FileSystemCAS(cas_root)
        snapshot = DataSnapshot.model_validate(load_core_json_artifact(fresh_store, complete.data_snapshot_ref))
        payload = _load_binding_payload(fresh_store, snapshot)
        a_key = source_namespace("fixture.source_a", "events")
        b_key = source_namespace("fixture.source_b", "events")
        assert _resolve_source_path(payload, f"sources.{a_key}.data", missing=None) == [a9]
        assert _resolve_source_path(payload, f"sources.{b_key}.data", missing=None) == [b5]
        assert payload["composition_semantics"] == "namespaced_collection_no_inferred_join"
        assert payload["production_currentness"] == "not_established"
        # Removal/adversarial control: drop the actual B member while retaining
        # A/B source evidence, all declarations and manifest inputs. The real
        # consumer must refuse rather than publish a superficially complete A.
        collection = SourceCollection.model_validate(payload)
        truncated = collection.model_copy(update={"sources": {a_key: collection.sources[a_key]}})
        manifest_view = fresh_store.get_manifest(snapshot.data_ref)
        bad_ref = fresh_store.put_json(truncated, ArtifactWriteOptions(kind="fabric.source_collection", media_type="application/json", schema=SchemaInfo(name="fabric.SourceCollection", version="1.0"), inputs=manifest_view.inputs), canon_spec=CanonSpec(forbid_floats=False), return_selected_profile=True)
        with pytest.raises(ValueError, match="omits|duplicates"):
            _load_binding_payload(fresh_store, snapshot.model_copy(update={"data_ref": bad_ref}))
        # Also retain both members while omitting an actual source row.
        wrong_b = collection.sources[b_key].model_copy(update={"data": []})
        wrong_rows = collection.model_copy(update={"sources": {**collection.sources, b_key: wrong_b}})
        bad_rows_ref = fresh_store.put_json(wrong_rows, ArtifactWriteOptions(kind="fabric.source_collection", media_type="application/json", schema=SchemaInfo(name="fabric.SourceCollection", version="1.0"), inputs=manifest_view.inputs), canon_spec=CanonSpec(forbid_floats=False), return_selected_profile=True)
        with pytest.raises(ValueError, match="data differs"):
            _load_binding_payload(fresh_store, snapshot.model_copy(update={"data_ref": bad_rows_ref}))
    finally:
        registry.shutdown()


'''
t=t[:a]+new+t[b:]
# Add real stream transport binding to each source owner setup (all such calls
# are in functions with an actual stream_path). Scope test adds partition too.
tree=ast.parse(t);replacements=[];lines=t.splitlines(keepends=True);offsets=[0]
for line in lines:offsets.append(offsets[-1]+len(line))
for n in ast.walk(tree):
 if not isinstance(n,ast.Call) or not isinstance(n.func,ast.Name) or n.func.id!='finite_source_reader':continue
 kw={k.arg:k.value for k in n.keywords}
 conn=kw.get('connector_id')
 isstream=(isinstance(conn,ast.Constant) and conn.value=='stream.jsonl') or isinstance(conn,ast.Name)
 if not isstream:continue
 pos=offsets[n.end_lineno-1]+n.end_col_offset-1
 indent=' '*(n.col_offset+4)
 text='\n'+indent+'transport_path=stream_path,'
 if isinstance(conn,ast.Name):text+='\n'+indent+'partition_key=partition_key,'
 replacements.append((pos,text))
for pos,value in sorted(replacements,reverse=True):t=t[:pos]+value+'\n'+' '*max(0,t[:pos].split('\n')[-1].count(' ')-0)+t[pos:]
# Broad invalid key preflight now fails before polling. Match the typed transport
# rejection as well; no weakening of accepted source identity is introduced.
t=t.replace('match="event/version|event-key|dedupe"','match="event/version|event-key|dedupe|transport"')
p.write_text(t)
print('rewrote actual-file B79/B80 tests and bound',len(replacements),'stream owners')
# Source unit tests: bind actual transport before authority operations.
p=r/'tests/unit/fabric/data_plane/test_source_progress.py';t=p.read_text();t=t.replace('from polisyos.core.contracts.cursor import CursorState, WatermarkType','from polisyos.core.contracts.cursor import CursorState, WatermarkType\nfrom polisyos.fabric.connectors.base import ConnectionConfig')
t=t.replace('frame = reader.freeze(tenant_id="tenant-a")','frame = reader.freeze(tenant_id="tenant-a").bind_transport(ConnectionConfig(url=reader.fixture_path.as_uri()))')
t=t.replace('frame = reader.freeze(tenant_id=None)','frame = reader.freeze(tenant_id=None).bind_transport(ConnectionConfig(url=reader.fixture_path.as_uri()))')
p.write_text(t)
# Two actual processes reconstruct the exact same source root and actual stream file.
p=r/'tests/unit/fabric/data_plane/test_source_progress_processes.py';t=p.read_text();t=t.replace('''        snapshots=[("source-current", [event])],''','''        snapshots=[("source-current", [event])],
        transport_path=tmp_path / "stream.jsonl",''');t=t.replace('''        "root": str(tmp_path),''','''        "root": str(tmp_path),
        "source_root": str(reader.source_root),''');p.write_text(t)
p=r/'tests/_helpers/source_progress_stream_worker.py';t=p.read_text().replace('FiniteSourceProgressReader(root / "owner", source, extension)','FiniteSourceProgressReader(Path(config["source_root"]), source, extension)');p.write_text(t)
