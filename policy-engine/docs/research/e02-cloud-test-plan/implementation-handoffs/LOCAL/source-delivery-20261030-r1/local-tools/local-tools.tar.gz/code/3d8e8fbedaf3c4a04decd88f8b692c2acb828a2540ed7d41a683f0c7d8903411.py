from pathlib import Path
import ast, hashlib, json, subprocess, tomllib
root=Path.cwd()
out=root/'LOCAL/raw/e02-execution-20261027/repairs/C46-r6-companions-r1'
base=json.loads((out/'preimages.json').read_text())
source_dir=root/'LOCAL/raw/e02-execution-20261027/repairs/C46-r6'
source=json.loads((source_dir/'manifest.json').read_text())
source_patch=source_dir/'base-to-proposal.patch'
assert hashlib.sha256(source_patch.read_bytes()).hexdigest()==source['patch_sha256']
source_records=[]
for row in source['paths']:
 blob=(source_dir/'postimages'/row['path']).read_bytes()
 assert hashlib.sha256(blob).hexdigest()==row['postimage_sha256']
 current=(root/row['path']).read_bytes()
 assert hashlib.sha256(current).hexdigest()==row['preimage_sha256'], row['path']
 source_records.append({'path':row['path'],'preimage_sha256':row['preimage_sha256'],'postimage_sha256':row['postimage_sha256']})
observation=ast.parse((source_dir/'postimages/policy-engine/src/polisyos/data_forge/domains/ukraine/builders/observation.py').read_text())
api=ast.parse((source_dir/'postimages/policy-engine/src/polisyos/data_forge/read_api/ukraine.py').read_text())
functions={n.name:n for n in observation.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
fn=functions['project_ukraine_observation_periods']
assert fn.returns is not None and len(fn.args.args)==1 and fn.args.args[0].annotation is not None
assert len(fn.args.kwonlyargs)==1 and fn.args.kwonlyargs[0].arg=='time_grain' and fn.args.kwonlyargs[0].annotation is not None
assert all(x in (ast.get_docstring(fn) or '') for x in ('Args:', 'Returns:', 'inclusive'))
classes={n.name:n for n in observation.body if isinstance(n,ast.ClassDef)}
assert ast.get_docstring(classes['PeriodDisposition'])
def assigned(tree,name):
 return [node for node in tree.body if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in node.targets)]
all_api=ast.literal_eval(assigned(api,'__all__')[0].value)
exports=assigned(api,'_EXPORTS')[0].value
assert isinstance(exports,ast.Dict)
mapping={ast.literal_eval(k):v for k,v in zip(exports.keys,exports.values,strict=True) if isinstance(k,ast.Constant)}
owner=assigned(api,'_UKRAINE_OBSERVATION')[0].value
assert ast.literal_eval(owner)=='polisyos.data_forge.domains.ukraine.builders.observation'
for name in ('UKRAINE_PERIOD_PROJECTION_VERSION','project_ukraine_observation_periods'):
 assert name in all_api and isinstance(mapping[name],ast.Name) and mapping[name].id=='_UKRAINE_OBSERVATION'
assert len({name for name in all_api if name in ('UKRAINE_PERIOD_PROJECTION_VERSION','project_ukraine_observation_periods')})==2
tracked=[row['path'] for row in base['tracked']]
new=base['new_files_expected_absent'][0]
assert not (root/new).exists()
assert subprocess.run(['git','cat-file','-e',f"{base['base_commit']}:{new}"],capture_output=True).returncode!=0
frag_path=out/'postimages'/new;fragment=tomllib.loads(frag_path.read_text())
policy=tomllib.loads((root/'policy-engine/ops/release/release-fragment-policy.toml').read_text())['release_fragments']
compat=tomllib.loads((root/'policy-engine/architecture/gates/compatibility_release.toml').read_text())['compatibility_release_gates']
assert all(fragment.get(k) for k in policy['required_fields'])
assert fragment['type'] in policy['allowed_types']
assert fragment['public_surface_inventory_reviewed'] is False
assert fragment['generated_client_compatibility'] in policy['generated_client_compatibility_values']
changes=fragment['compatibility_change']
assert len(changes)==3
for change in changes:
 assert all(change.get(k) for k in policy['structured_compatibility_required_fields'])
 assert change['change_class'] in compat['allowed_change_classes']
 assert change.get('generated_client_compatibility') in policy['generated_client_compatibility_values']
 if change['change_class']=='python-public-api':
  assert change['public_surface_inventory_reviewed'] is False
for p in fragment['evidence']+fragment['migration_docs']:
 assert (root/'policy-engine'/p).exists(),p
patch_parts=[];footprint=[]
for rel in tracked+[new]:
 b=out/'postimages'/rel
 if rel in tracked:
  a=out/'preimages'/rel
  original=(root/rel).read_bytes(); assert original==a.read_bytes()
  args=['git','diff','--no-index','--',str(a.relative_to(out)),str(b.relative_to(out))]
  pre=hashlib.sha256(original).hexdigest()
 else:
  args=['git','diff','--no-index','--','/dev/null',str(b.relative_to(out))]
  pre=None
 r=subprocess.run(args,cwd=out,capture_output=True,text=True)
 assert r.returncode==1, (rel,r.returncode,r.stderr)
 lines=[]
 for line in r.stdout.splitlines(keepends=True):
  if line.startswith(('diff --git ','--- ','+++ ')):
   line=line.replace('a/preimages/','a/').replace('a/postimages/','a/').replace('b/postimages/','b/')
  lines.append(line)
 patch_parts.append(''.join(lines))
 footprint.append({'path':rel,'preimage_sha256':pre,'postimage_sha256':hashlib.sha256(b.read_bytes()).hexdigest()})
patch=out/'companion.patch';patch.write_text(''.join(patch_parts))
checks=[]
for args in (['git','apply','--check',str(patch)],['git','apply','--check','--whitespace=error',str(patch)]):
 p=subprocess.run(args,cwd=root,capture_output=True,text=True)
 checks.append({'command':args,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
 assert p.returncode==0,checks[-1]
result={'base_commit':base['base_commit'],'base_tree':base['base_tree'],'code_overlay':{'path':str(source_patch.relative_to(root)),'sha256':source['patch_sha256'],'source_base':source['base_commit'],'source_tree':source['base_tree'],'paths':source_records},'footprint':footprint,'companion_patch_sha256':hashlib.sha256(patch.read_bytes()).hexdigest(),'companion_patch_bytes':patch.stat().st_size,'static_checks':checks,'api_ast':{'export_count':2,'typed_function':True,'google_args_returns_docstring':True,'class_docstring':True,'route_owner':ast.literal_eval(owner)},'release_toml':{'parse':'PASS','required_fields':'PASS','structured_entries':len(changes),'public_surface_inventory_reviewed':False,'release_gate_expected':'public-surface-review remains unresolved until actual inventory generation/review'},'runtime':'UNRUN','product_imports':'UNRUN','manual_governance_inventory':'No change: the supported Ukraine entrypoint already exists; JSON/public-reference generation is root-owned and still required.'}
(out/'manifest.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'footprint':len(footprint),'bound_source_paths':len(source_records),'patch_sha256':result['companion_patch_sha256'],'static_exits':[c['exit'] for c in checks],'toml_public_inventory_reviewed':False}))
