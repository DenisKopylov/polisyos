"""Bounded stdlib path controls, with retained synthetic fixtures and no cleanup."""
from pathlib import Path
import json
from external_admission import external_existing_dir, external_existing_file, no_symlink_components, fresh, fixture_snapshot

base = Path(__file__).resolve().parent / 'geometry-controls-r2'
base.mkdir(exist_ok=False)
root = base / 'checkout'; raw = root / 'LOCAL/raw'; good = raw / 'case-parent'
good.mkdir(parents=True)
product = root / 'policy-engine'; product.mkdir()
regular = good / 'existing'; regular.write_text('existing')
(good / 'dangling').symlink_to(good / 'missing-target')
(raw / 'link').symlink_to(good, target_is_directory=True)
results = {}
def check(name, fn, accept):
    try:
        fn()
    except (ValueError, OSError) as exc:
        if accept: raise
        results[name] = {'outcome':'REFUSED', 'exception':type(exc).__name__, 'message':str(exc)}
    else:
        if not accept: raise AssertionError(f'{name} unexpectedly accepted')
        results[name] = {'outcome':'ACCEPTED'}
check('valid_external_parent',lambda:external_existing_dir(str(good),root),True)
check('existing_external_file',lambda:external_existing_file(str(regular),root),True)
check('fresh_case',lambda:fresh(good/'new',good),True)
check('traversal',lambda:external_existing_dir(str(raw)+'/case-parent/../case-parent',root),False)
check('wrong_product_parent',lambda:external_existing_dir(str(product),root),False)
check('allowed_root_itself',lambda:external_existing_dir(str(raw),root),False)
check('missing_parent',lambda:external_existing_dir(str(raw/'not-created'),root),False)
check('symlink_parent',lambda:external_existing_dir(str(raw/'link'),root),False)
check('existing_output',lambda:fresh(regular,good),False)
check('dangling_output',lambda:fresh(good/'dangling',good),False)
check('wrong_direct_parent',lambda:fresh(good/'other'/'leaf',good),False)
check('dangling_file',lambda:external_existing_file(str(good/'dangling'),root),False)
fixture = raw/'fixture'
fixture.mkdir()
(fixture/'w').write_text('wmr-v1')
(fixture/'l').write_text('l6-v1')
frozen = fixture_snapshot(str(fixture),root)
assert len(frozen) == 2
(fixture/'l').write_text('l6-v2')
assert fixture_snapshot(str(fixture),root) != frozen
(fixture/'new').write_text('new input')
assert set(fixture_snapshot(str(fixture),root)) != set(frozen)
results['fixture_byte_mutation']={'outcome':'DETECTED'}
results['fixture_added_file']={'outcome':'DETECTED'}
(fixture/'link').symlink_to(fixture/'missing')
check('fixture_dangling_symlink',lambda:fixture_snapshot(str(fixture),root),False)
print(json.dumps({'status':'PASS_stdlib_geometry_only','cases':results,'limitations':['Checks pathname geometry at the instant of inspection, not adversarial concurrent filesystem mutation','No product imports, pytest or sandbox launch','case-specific fixture, source and resource admission remain UNRUN'], 'closure_ids':[]},indent=2))
