"""Read the retained synthetic R5 SQLite/CAS only; never import or execute product."""
from pathlib import Path
from collections import Counter
import hashlib,json,sqlite3
ROOT=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
HERE=Path(__file__).resolve().parent
CASE=ROOT/'policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1/c48-two-source-composed-r5-20261028'
TEST=CASE/'basetemp/test_two_real_completed_ex_ant0'
DB=TEST/'c48-runtime/.polisyos/control_plane.sqlite3'
CAS=TEST/'c48-runtime/.polisyos/artifacts/sha256'
sha=lambda b:hashlib.sha256(b).hexdigest()
def artifact(digest):
 p=CAS/digest[:2]/digest[2:4]/(digest+'.blob');raw=p.read_bytes();assert sha(raw)==digest
 return json.loads(raw)
db_hash=sha(DB.read_bytes())
c=sqlite3.connect(DB.as_uri()+'?mode=ro&immutable=1',uri=True);c.row_factory=sqlite3.Row
jobs=[dict(r) for r in c.execute('select job_id,job_kind,state,run_id,attempt,effective_profile,payload_ref,error_message,method_execution_selection_json from control_jobs')]
assert len(jobs)==1 and jobs[0]['state']=='completed' and jobs[0]['method_execution_selection_json'] is None
job=jobs[0];payload_digest=job['payload_ref'].removeprefix('sha256:');payload=artifact(payload_digest)
events=[dict(r) for r in c.execute('select event_id,event_type,payload_json from control_job_events order by event_id')]
c.close();assert sha(DB.read_bytes())==db_hash
report_digest='309827096b90f4f5d9f2f1fb663368aabc20394d8215fe021c73f317d069cfdb'
report=artifact(report_digest);assert report['run_id']==job['run_id']
workflow_spec_digest='16b69b2a2b3ec2ff5d13c750312cc69557c1f51387809ce6186731e0ccad6bd4'
workflow_spec=artifact(workflow_spec_digest)
compile_invocation=next(row for row in workflow_spec['nodes'] if row['alias']=='compile_foundry')
assert compile_invocation['retry'] is None and compile_invocation['timeout_s'] is None
nodes=[{k:r.get(k) for k in ('alias','status','error','skip_reason')} for r in report['nodes']]
manifest_files=[p for p in CAS.rglob('*.manifest.json') if '.view.' not in p.name]
counts=Counter(json.loads(p.read_text())['kind'] for p in manifest_files)
absence_kinds=['foundry.program_graph','foundry.exec_plan','foundry.simulation_result','foundry.method_execution_bundle','foundry.method_metric_binding_set']
inputs=payload['state_payload']['inputs'];bindings=payload['state_payload']['params']['method_metric_bindings']
readset=CASE/'readsets/input-readset-91631.json'
loaded=json.loads(readset.read_text())
selected_loaded=[r for r in loaded['modules'] if r['path'] in {'src/polisyos/scientist/orchestration/engine/executor.py','src/polisyos/scientist/orchestration/engine/state_branching.py','src/polisyos/scientist/nodes/builtins/compile/compile_foundry.py'}]
assert len(selected_loaded)==3
record={'actual_loaded_source_readset_sha256':sha(readset.read_bytes()),'actual_loaded_failure_path_sources':selected_loaded,'source':'a437f597212cc7cc6dcb1c60fff9fb018ce43fe0','case':str(CASE.relative_to(ROOT)),'audit_sha256':sha((CASE/'audit-result.json').read_bytes()),'xml_sha256':sha((CASE/'pytest.xml').read_bytes()),'sqlite_sha256_before_and_after_read':db_hash,'sqlite_read_mode':'mode=ro&immutable=1','complete_job_row_denominator':len(jobs),'jobs':jobs,'complete_job_event_denominator':len(events),'job_events':[{k:r[k] for k in ('event_id','event_type')} for r in events],'actual_payload_ref':job['payload_ref'],'payload_selected_inputs':inputs,'actual_binding_request':bindings,'actual_workflow_spec_ref':'sha256:'+workflow_spec_digest,'actual_compile_invocation':compile_invocation,'workflow_report_ref':'sha256:'+report_digest,'workflow_report_status':report['status'],'workflow_id':report['workflow_id'],'complete_workflow_node_denominator':len(nodes),'workflow_nodes':nodes,'workflow_node_status_counts':dict(Counter(r['status'] for r in nodes)),'default_CAS_manifest_denominator':len(manifest_files),'default_CAS_manifest_kind_counts':dict(counts),'bounded_absence_counts':{kind:counts.get(kind,0) for kind in absence_kinds},'bounded_absence_scope':'Only complete default *.manifest.json set within this retained synthetic R5 CAS; selected view sidecars, other cases and repository-wide artifacts are not this denominator. Positive controls are the actual payload/workflow report/node snapshots that were found and hash-verified.','volume':'First source A prepared and one workflow job completed transport; scientific compile node failed. No B job or planner job exists in this DB; no compiled/simulation/binding artifacts exist in this bounded default-manifest set.','first_selection_read_gate':'record exists but method_execution_selection is None; get_method_execution_selection returns at its initial no-selection check before scope/wire/Graph terminal gates','source_cause_inference':'Actual loaded synchronous WorkflowExecutor mandatory enforce_write_scope branch wraps list into canonical _TrackedList; exact builtin type check in CompileFoundryNode rejects that admitted list view. Runtime concrete type was not separately logged; Root must exercise the actual branched-state/engine oracle before executable confirmation.','product_imports_tests_native':'UNRUN by this author'}
(HERE/'failure-evidence.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'job_count':len(jobs),'node_status_counts':record['workflow_node_status_counts'],'default_manifest_count':len(manifest_files),'bounded_absence_counts':record['bounded_absence_counts'],'evidence_sha256':sha((HERE/'failure-evidence.json').read_bytes())},indent=2))
