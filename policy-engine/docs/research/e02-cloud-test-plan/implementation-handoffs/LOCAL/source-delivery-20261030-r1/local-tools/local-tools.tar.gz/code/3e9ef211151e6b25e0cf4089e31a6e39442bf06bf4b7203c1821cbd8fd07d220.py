"""Source-pinned collection/profile witness and opt-in in-memory C32 removals.

This is a planning artifact until independently reviewed. Load only through the
retained native runner. Disk source, index, refs and native fixture bytes are
never mutated by this plugin. A nonzero exit is not a qualified removal.
"""
from __future__ import annotations
import ast
import functools
import datetime
import gzip
import decimal
import uuid
import hashlib
import importlib
import importlib.metadata
import inspect
import json
import marshal
import os
import platform
import sys
import textwrap
from pathlib import Path
from types import CodeType
import pytest
from parameter_identity import parameters

_STATE={"early":[],"selected":[],"deselected":[],"reports":[],"calls":[],"profiles":[],"parameters":{},"restored":[],"consumer_events":[],"native_inputs":{},"outside_native_inputs":[],"source_exception_events":[],"source_trace_admission":[],"native_states":[]}
HERE=Path(__file__).resolve().parent

def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,d):
 with p.open('x') as f:json.dump(d,f,indent=2,sort_keys=True);f.write('\n')
def fingerprint(c):
 return (c.co_code,c.co_names,c.co_varnames,c.co_freevars,c.co_cellvars,c.co_argcount,c.co_posonlyargcount,c.co_kwonlyargcount,c.co_flags,tuple(fingerprint(x) if isinstance(x,CodeType) else x for x in c.co_consts))
def code_child(code,qualified_name):
    for name in qualified_name.split('.'):
        found=[x for x in code.co_consts if isinstance(x,CodeType) and x.co_name==name]
        assert len(found)==1,(qualified_name,name)
        code=found[0]
    return code

def ast_child(tree,qualified_name):
    for name in qualified_name.split('.'):
        found=[n for n in tree.body if isinstance(n,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name]
        assert len(found)==1,(qualified_name,name)
        tree=found[0]
    return tree

def profile(config):
 exe=Path(sys.executable).resolve()
 plugins=[]
 for name,plugin in config.pluginmanager.list_name_plugin():
  if plugin is None:continue
  mod=plugin if inspect.ismodule(plugin) else sys.modules.get(type(plugin).__module__)
  path=getattr(mod,'__file__',None)
  plugins.append({'name':None if str(name)==str(id(plugin)) else str(name),'anonymous_role':(type(plugin).__module__+'.'+type(plugin).__qualname__) if str(name)==str(id(plugin)) else None,'module':getattr(mod,'__name__',None),'path':path,'sha256':sha(Path(path).read_bytes()) if path and Path(path).is_file() else None})
 return {'python':sys.version,'flags':list(sys.flags),'executable':str(exe),'executable_sha256':sha(exe.read_bytes()),'prefix':sys.prefix,'platform':platform.platform(),'duckdb_version':getattr(sys.modules.get('duckdb'),'__version__',None),'distribution_versions':{n:importlib.metadata.version(n) for n in ['pytest','duckdb','pydantic']},'numerical_env':{n:os.environ.get(n) for n in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS','SCIENTIST_TORCH_NUM_THREADS','SCIENTIST_TORCH_NUM_INTEROP_THREADS']},'plugins':sorted(plugins,key=lambda r:json.dumps(r,sort_keys=True))}
def pytest_configure(config):
 expected=os.environ['C32_PLUGIN_SHA256'];assert sha(Path(__file__).read_bytes())==expected
 plan=Path(os.environ['C32_PLAN_PATH']) # Exact plan bytes are admitted by the external guard and retained runner freeze.
 _STATE['plan']=json.loads(plan.read_text());_STATE['output']=Path(os.environ['POLISYOS_R4_INPUT_READSET_DIR']).parent
 for rel,pin in _STATE['plan']['c32_binding']['committed_inputs'].items():assert sha((Path.cwd().parent/rel).read_bytes())==pin['sha256'],rel
@pytest.hookimpl(hookwrapper=True,tryfirst=True)
def pytest_collection_modifyitems(items):
 _STATE['early'].extend(i.nodeid for i in items);yield;_STATE['selected'].extend(i.nodeid for i in items);_STATE['parameters'].update({i.nodeid:parameters(dict(getattr(getattr(i,'callspec',None),'params',{}))) for i in items})
def pytest_deselected(items):_STATE['deselected'].extend(i.nodeid for i in items)


def fixture_root(item,path):
    direct=item.funcargs.get('tmp_path');path=Path(path)
    if direct is not None:return direct,'direct_tmp_path'
    output=_STATE['output'].resolve()
    if path.resolve().is_relative_to(output):
        parent=path.parent.resolve();roles=_STATE.setdefault('_fixture_root_roles',{})
        key=(item.nodeid,str(parent))
        if key not in roles:roles[key]='observed_native_parent_'+str(1+sum(n==item.nodeid for n,p in roles))
        return parent,roles[key]
    _STATE['outside_native_inputs'].append({'node':item.nodeid,'path':str(path),'status':'not_established','reason':'native use outside admitted runner output; bytes were not inspected'})
    return None,None

def retain_native_bytes(raw):
    digest=sha(raw);folder=_STATE['output']/'native-input-bytes';folder.mkdir(exist_ok=True)
    p=folder/(digest+'.bin.gz')
    if p.exists():assert sha(gzip.decompress(p.read_bytes()))==digest
    else:
        with p.open('xb') as f:f.write(gzip.compress(raw,mtime=0))
    return {'path':str(p),'compressed_sha256':sha(p.read_bytes()),'raw_sha256':digest,'raw_bytes':len(raw),'purpose':'Necessary small deciding native source/fault bytes retained once by content identity; no environment/checkout/CAS/production copy.'}

def native_state(item,path,stage):
    path=Path(path);root,role=fixture_root(item,path)
    if root is None:return
    event={'node':item.nodeid,'relative_path':str(path.relative_to(root)),'stage':stage,'fixture_root_role':role,'exists':path.exists()}
    try:
        if path.exists():
            if path.stat().st_size>64*1024**2:raise ValueError('native state exceeds 64MiB witness bound')
            raw=path.read_bytes();event.update(raw_sha256=sha(raw),raw_bytes=len(raw),retained_bytes=retain_native_bytes(raw))
        wal=path.with_name(path.name+'.wal');event['wal_exists']=wal.exists()
        if wal.exists():
            if wal.stat().st_size>64*1024**2:raise ValueError('WAL exceeds 64MiB witness bound')
            raw=wal.read_bytes();event.update(wal_sha256=sha(raw),wal_bytes=len(raw),retained_wal_bytes=retain_native_bytes(raw))
        event['status']='complete'
    except Exception as exc:event.update(status='not_established',reason=type(exc).__name__+': '+str(exc))
    _STATE['native_states'].append(event)

def native_input(item,path):
    """Hash complete small native relation inputs; normalize only fixture-root paths."""
    path=Path(path);root,role=fixture_root(item,path)
    if root is None:return
    if not path.resolve().is_relative_to(root.resolve()):
        _STATE['outside_native_inputs'].append({'node':item.nodeid,'path':str(path),'status':'not_established','reason':'outside test fixture root; bytes were not inspected'})
        return
    rel=str(path.relative_to(root));key=item.nodeid+'::'+role+'::'+rel
    if key in _STATE['native_inputs']:return
    record={'node':item.nodeid,'relative_path':rel,'fixture_root_role':role,'absolute_path':str(path),'normalization':'Only occurrences of this exact admitted fixture root prefix in string cells become <FIXTURE_ROOT>; all rows/columns/order/other values remain.'}
    def encode(v):
        if v is None or isinstance(v,(bool,int)):return v
        if isinstance(v,str):return v.replace(str(root),'<FIXTURE_ROOT>')
        if isinstance(v,float):return {'float_hex':v.hex()}
        if isinstance(v,bytes):return {'bytes_hex':v.hex()}
        if isinstance(v,(datetime.date,datetime.datetime,datetime.time)):return {'type':type(v).__name__,'iso':v.isoformat()}
        if isinstance(v,(decimal.Decimal,uuid.UUID)):return {'type':type(v).__name__,'value':str(v)}
        if isinstance(v,(list,tuple)):return [encode(x) for x in v]
        if isinstance(v,dict):return {str(k):encode(x) for k,x in v.items()}
        raise TypeError('unsupported native value '+type(v).__name__)
    try:
        if not path.exists():record.update(status='absent');return
        if path.stat().st_size>64*1024**2:record.update(status='not_established',reason='native fixture exceeds 64MiB witness bound');return
        raw=path.read_bytes();record.update(raw_sha256=sha(raw),raw_bytes=len(raw),retained_bytes=retain_native_bytes(raw))
        if not raw:record.update(status='empty',semantic_sha256=sha(b''));return
        wal=path.with_name(path.name+'.wal')
        if wal.exists():record.update(status='not_established',reason='WAL already present before initial fixture witness',wal_sha256=sha(wal.read_bytes()));return
        import duckdb
        con=duckdb.connect(str(path),read_only=True)
        try:
            tables=con.execute("SELECT table_catalog, table_schema, table_name FROM information_schema.tables WHERE table_schema NOT IN ('information_schema','pg_catalog') ORDER BY 1,2,3").fetchall();basis=[]
            for catalog,schema,table in tables:
                quoted='.'.join('"'+x.replace('"','""')+'"' for x in [catalog,schema,table])
                cursor=con.execute('SELECT * FROM '+quoted);columns=[(d[0],str(d[1])) for d in cursor.description];data=[encode(row) for row in cursor.fetchall()]
                basis.append({'table':[catalog,schema,table],'columns':columns,'rows':data})
            encoded=json.dumps(basis,sort_keys=True,separators=(',',':')).encode();record.update(status='complete',tables=[{'table':x['table'],'columns':x['columns'],'row_count':len(x['rows'])} for x in basis],semantic_sha256=sha(encoded))
        finally:con.close()
    except Exception as exc:record.update(status='not_established',reason=type(exc).__name__+': '+str(exc))
    finally:_STATE['native_inputs'][key]=record

def observe_consumers(item):
    """Forward original calls; retain events without replacing results or exceptions."""
    from polisyos.data_forge.read_api import catalog as catalog_api
    from polisyos.fabric.retrieval.service import RetrievalService
    reverts=[]
    store=catalog_api.DatasetCatalogStore
    init=store.__init__
    @functools.wraps(init)
    def observed_init(self,*args,**kwargs):
        result=init(self,*args,**kwargs)
        native_input(item,self.database_path)
        overlay=getattr(self,'overlay_path',None)
        if overlay is not None:native_input(item,overlay)
        return result
    store.__init__=observed_init;reverts.append((store,'__init__',init,observed_init))
    identity=store.identify_read_sources
    @functools.wraps(identity)
    def observed_identity(database_path,*,overlay_path=None):
        native_state(item,database_path,'identify')
        if overlay_path is not None:native_state(item,overlay_path,'identify')
        native_input(item,database_path)
        if overlay_path is not None:native_input(item,overlay_path)
        return identity(database_path,overlay_path=overlay_path)
    close=store.close
    @functools.wraps(close)
    def observed_close(self,*args,**kwargs):
        native_state(item,self.database_path,'close')
        return close(self,*args,**kwargs)
    store.close=observed_close;reverts.append((store,'close',close,observed_close))
    old_identity=inspect.getattr_static(store,'identify_read_sources');new_identity=staticmethod(observed_identity)
    store.identify_read_sources=new_identity;reverts.append((store,'identify_read_sources',old_identity,new_identity))
    variable=sys.modules.get('tests.unit.data_forge.domains.catalog.knowledge.test_variable_availability')
    if variable is not None:
        catalog=variable._catalog
        @functools.wraps(catalog)
        def observed_catalog(path,*args,**kwargs):
            result=catalog(path,*args,**kwargs);native_input(item,path);return result
        variable._catalog=observed_catalog;reverts.append((variable,'_catalog',catalog,observed_catalog))
    for owner,attribute,role in [(RetrievalService,'resolve','resolver'),(catalog_api.DatasetCatalogGraph,'resolve_metric_bindings','native_bindings')]:
        original=getattr(owner,attribute)
        def make(original,role):
            @functools.wraps(original)
            def forward(*args,**kwargs):
                event={'node':item.nodeid,'role':role,'entered':True,'outcome':'entered'}
                _STATE['consumer_events'].append(event)
                try:
                    result=original(*args,**kwargs)
                except Exception as failure:
                    frames=[];tb=failure.__traceback__
                    while tb is not None:
                        frames.append({'filename':tb.tb_frame.f_code.co_filename,'function':tb.tb_frame.f_code.co_name});tb=tb.tb_next
                    event.update(outcome='raised',exception_type=type(failure).__module__+'.'+type(failure).__qualname__,code=getattr(failure,'code',None),typed_catalog_source=isinstance(failure,catalog_api.CatalogReadSourceError),frames=frames)
                    raise
                event.update(outcome='returned',result_type=type(result).__module__+'.'+type(result).__qualname__)
                if role=='native_bindings':event['row_count']=len(result)
                return result
            return forward
        wrapper=make(original,role);setattr(owner,attribute,wrapper);reverts.append((owner,attribute,original,wrapper))
    _STATE['_consumer_reverts']=reverts

@pytest.hookimpl(hookwrapper=True,tryfirst=True)
def pytest_runtest_teardown(item):
    # Fixture finalizers may reinstall our saved forwarding function.
    yield
    for owner,attribute,original,wrapper in reversed(_STATE.pop('_consumer_reverts',[])):
        observed=inspect.getattr_static(owner,attribute) if attribute=='identify_read_sources' else getattr(owner,attribute)
        _STATE['restored'].append({'node':item.nodeid,'observer_restoration':True,'observer_role':attribute,'restored_in_process':observed is wrapper})
        setattr(owner,attribute,original)

@pytest.hookimpl(hookwrapper=True,trylast=True)
def pytest_runtest_call(item):
 plan=_STATE['plan'];mode=plan.get('control_mode');phase=plan.get('control_phase');reverts=[];hit_counts={};records=[];previous_trace=sys.gettrace();trace_installed=False
 try:
  observe_consumers(item)
  from polisyos.data_forge.read_api import catalog as catalog_api
  observed_files={str((Path.cwd()/v).resolve()) for v in ['src/polisyos/data_forge/domains/catalog/knowledge/store.py','src/polisyos/fabric/retrieval/service.py','src/polisyos/runtime/quality/acquisition_planner.py','src/polisyos/runtime/quality/generation_cycle.py']}
  def source_trace(frame,event,arg):
   if frame.f_code.co_filename not in observed_files and not frame.f_code.co_filename.startswith('<C32-'):return None
   if event=='exception' and isinstance(arg[1],catalog_api.CatalogReadSourceError):
    failure=arg[1];_STATE['source_exception_events'].append({'node':item.nodeid,'filename':frame.f_code.co_filename,'function':frame.f_code.co_name,'exception_type':type(failure).__module__+'.'+type(failure).__qualname__,'code':failure.code})
   return source_trace
  # Never replace an existing coverage/debug tracer. Missing source observation
  # then remains unqualified rather than silently changing the native profile.
  if previous_trace is None:sys.settrace(source_trace);trace_installed=True
  _STATE['source_trace_admission'].append({'node':item.nodeid,'installed':trace_installed,'preexisting_tracer':None if previous_trace is None else type(previous_trace).__module__+'.'+type(previous_trace).__qualname__})
  _STATE['profiles'].append({'node':item.nodeid,'profile':profile(item.config)})
  if phase=='mutant':
   spec=json.loads((HERE/'controls.json').read_text())[mode]
   module=importlib.import_module('polisyos.'+spec['source'].removeprefix('src/polisyos/').removesuffix('.py').replace('/','.'))
   assert sha(Path(module.__file__).read_bytes())==spec['source_sha256']
   for index,target in enumerate(spec['functions']):
    owner=module
    for part in target['qualified_name'].split('.')[:-1]:owner=getattr(owner,part)
    original=inspect.unwrap(getattr(owner,target['qualified_name'].split('.')[-1]))
    assert Path(original.__code__.co_filename).resolve()==Path(module.__file__).resolve()
    tree=ast.parse(textwrap.dedent(inspect.getsource(original)));fn=tree.body[0];assert isinstance(fn,(ast.FunctionDef,ast.AsyncFunctionDef));fn.decorator_list=[]
    assert sha(ast.dump(fn,include_attributes=False).encode())==target['source_function_ast_sha256']
    original_module=Path(module.__file__).read_bytes()
    original_module_code=compile(original_module,str(module.__file__),'exec',dont_inherit=True)
    assert fingerprint(code_child(original_module_code,target['qualified_name']))==fingerprint(original.__code__),'active function/source mismatch'
    mutant=(HERE/target['mutant_function_source']).read_bytes();assert sha(mutant)==target['mutant_source_sha256']
    active_tree=ast.parse(mutant);active_fn=active_tree.body[0];hook='_c32_native_control_hit';key=target['qualified_name'];hit_counts[key]=0
    def hit(name):hit_counts[name]+=1
    hook_before=original.__globals__.get(hook);hook_present=hook in original.__globals__;original.__globals__[hook]=hit
    at=1 if active_fn.body and isinstance(active_fn.body[0],ast.Expr) and isinstance(active_fn.body[0].value,ast.Constant) and isinstance(active_fn.body[0].value.value,str) else 0
    active_fn.body.insert(at,ast.Expr(ast.Call(ast.Name(hook,ast.Load()),[ast.Constant(key)],[])));ast.fix_missing_locations(active_tree)
    active_source=ast.unparse(active_tree)+'\n'
    active_path=_STATE['output']/f'c32-{mode}-{index}-active.py'
    if active_path.exists():assert active_path.read_text()==active_source
    else:active_path.write_text(active_source)
    filename=f'<C32-{mode}-{index}>'
    full_tree=ast.parse(original_module)
    selected=ast_child(full_tree,target['qualified_name']);selected.body=ast.parse(active_source).body[0].body
    ast.fix_missing_locations(full_tree)
    active_code=code_child(compile(full_tree,filename,'exec',dont_inherit=True),target['qualified_name'])
    assert active_code.co_freevars==original.__code__.co_freevars
    old_code=original.__code__;original.__code__=active_code
    reverts.append((original,old_code,active_code,hook,hook_before,hook_present))
    records.append({'qualified_name':key,'original_code_sha256':sha(marshal.dumps(old_code)),'original_filename':old_code.co_filename,'mutant_code_sha256':sha(marshal.dumps(active_code)),'active_source_path':str(active_path),'active_source_sha256':sha(active_path.read_bytes()),'mutant_definition_sha256':sha(mutant),'rewrite_count':target['rewrite_count'],'source_sha256':spec['source_sha256']})
  yield
 finally:
  if trace_installed:
   if sys.gettrace() is not source_trace:_STATE['source_trace_admission'][-1]['changed_during_call']=True
   sys.settrace(previous_trace)
  clean=True
  for fn,old,active,hook,previous,present in reversed(reverts):
   if fn.__code__ is not active:clean=False
   fn.__code__=old
   if present:fn.__globals__[hook]=previous
   else:fn.__globals__.pop(hook,None)
   clean=clean and fn.__code__ is old
  _STATE['restored'].append({'node':item.nodeid,'restored_in_process':clean,'active_entries':hit_counts,'mutations':records})
def pytest_runtest_logreport(report):
 _STATE['reports'].append({'node':report.nodeid,'when':report.when,'outcome':report.outcome,'longrepr':str(report.longrepr) if report.failed else None})
def pytest_sessionfinish(session,exitstatus):
 plan=_STATE['plan'];out=_STATE['output'];payload={k:v for k,v in _STATE.items() if k not in {'output','plan'} and not k.startswith('_')}
 payload.update({'schema':'policyos.c32.native_witness.v1','plan_sha256':sha(Path(os.environ['C32_PLAN_PATH']).read_bytes()),'plugin_sha256':sha(Path(__file__).read_bytes()),'phase':plan.get('control_phase','positive'),'mode':plan.get('control_mode'),'exitstatus':int(exitstatus),'qualification':'UNQUALIFIED until external actual JUnit/output/readset/source/profile reconciliation and independent semantic failure review','closure_ids':[]})
 save(out/'c32-witness.json',payload)
