from pathlib import Path
P=Path.cwd()/'LOCAL/raw/e02-execution-20261027/repairs/C17/postimages/policy-engine'
def edit(rel, old, new):
 p=P/rel;s=p.read_text();assert s.count(old)==1,(rel,old[:80],s.count(old));p.write_text(s.replace(old,new))
edit('src/polisyos/lex/legal_evaluation/impact_diff.py', '''        report = NormImpactReport(
''', '''        if "legal" not in self._pass_ids:
            legal_backend = "not_run"
            legal_evaluation_scope = "not_run"
        elif self._legal_backend is None or self._legal_backend == "stub":
            legal_backend = "stub"
            legal_evaluation_scope = "not_implemented"
        elif isinstance(self._legal_backend, str):
            legal_backend = self._legal_backend
            legal_evaluation_scope = (
                "selected_backend_rules_only"
                if legal_backend == "expr_ast"
                else "backend_semantics_not_established"
            )
        else:
            # A custom backend's self-reported name is not proof of its semantics.
            legal_backend = "custom"
            legal_evaluation_scope = "backend_semantics_not_established"

        report = NormImpactReport(
''')
edit('src/polisyos/lex/legal_evaluation/impact_diff.py', '''                "profile": self._profile.level.value,
''', '''                "profile": self._profile.level.value,
                "legal_backend": legal_backend,
                "legal_evaluation_scope": legal_evaluation_scope,
''')
edit('src/polisyos/lex/simulator/cli.py', '''    if report.compliance_deltas:
''', '''    if "legal" in report.passes_executed:
        backend = report.metadata.get("legal_backend")
        if backend == "stub":
            limitation = "The stub backend did not evaluate legal rules."
        elif backend == "expr_ast":
            limitation = (
                "The expr_ast backend evaluates rules assigned to it; source authenticity "
                "and complete rule coverage are not established."
            )
        else:
            limitation = "The legal backend or its evaluation scope is not established."
        lines.extend([f"**Legal evaluation limitation:** {limitation}", ""])

    if report.compliance_deltas:
''')
edit('src/polisyos/core/components/_cli_lex.py', '''            passes=pass_ids,
''', '''            passes=pass_ids,
            legal_backend=getattr(args, "legal_backend", None),
''')
edit('tools/ops_runners/runtime_cli.py', '''    impact.add_argument("--passes", default="legal,safety")
''', '''    impact.add_argument("--passes", default="legal,safety")
    impact.add_argument(
        "--legal-backend",
        choices=["stub", "expr_ast"],
        default=None,
        help="Legal rule backend; omitted uses the historical, non-evaluating stub",
    )
''')
edit('src/polisyos/lex/legal_evaluation/README.md', '''  `polisyos.lex.simulator` imports and CLI use this same canonical owner.
''', '''  `polisyos.lex.simulator` imports and CLI use this same canonical owner. Reports
  record the configured legal backend and the limit of its evaluated scope in
  `metadata`. Omitted backend uses the historical stub: its not-implemented
  results do not establish rule compliance. The CLI accepts
  `--legal-backend expr_ast` to evaluate supplied rules assigned to that backend.
  This does not authenticate source law or establish coverage of all rules.
  Historical reports without backend metadata remain readable, with backend
  and evaluation scope not established.
''')
edit('docs/reference/cli.md', '''| `lex impact`         | `polisyos lex impact OLD_REF NEW_REF [--passes PASSES] [--profile {fast,mvp,strict}] [--format {json,md}] [--output PATH] [--cas-root PATH]` | Compare two NormPack references and emit a legal impact report |
''', '''| `lex impact`         | `polisyos lex impact OLD_REF NEW_REF [--passes PASSES] [--legal-backend {stub,expr_ast}] [--profile {fast,mvp,strict}] [--format {json,md}] [--output PATH] [--cas-root PATH]` | Compare two NormPacks, retain pass and backend limits, and emit candidate impact topics |
''')
edit('docs/reference/cli.md', '''polisyos lex impact old_normpack.json new_normpack.json --format md --output impact.md
''', '''polisyos lex impact old_normpack.json new_normpack.json --legal-backend expr_ast --format md --output impact.md
''')
edit('docs/reference/cli.md', '''### `polisyos scientist`
''', '''`lex impact` uses the historical legal stub when `--legal-backend` is omitted;
the stub does not evaluate legal rules. `expr_ast` evaluates only supplied rules
assigned to that backend. Neither backend selection authenticates source law or
establishes complete coverage. The report records its backend and scope; older
reports without that metadata remain readable with those facts unestablished.

### `polisyos scientist`
''')
