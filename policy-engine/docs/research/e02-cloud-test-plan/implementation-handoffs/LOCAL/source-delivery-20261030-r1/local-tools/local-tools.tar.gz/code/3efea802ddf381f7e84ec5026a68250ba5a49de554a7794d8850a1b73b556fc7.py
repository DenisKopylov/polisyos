from pathlib import Path
import subprocess
s = Path('LOCAL/raw/e02-execution-20261027/repairs/C48-r5')
r = Path('LOCAL/raw/e02-execution-20261027/repairs/C48-r4/lint-companion/product-config-r1')
for before in sorted((r / 'preimages').rglob('*.py')):
    rel = before.relative_to(r / 'preimages')
    after = r / 'postimages' / rel
    current = s / 'c53-postimages' / rel
    if not current.exists():
        current = s / 'postimages' / rel
    if not current.exists():
        continue
    if before.read_bytes() == current.read_bytes():
        current.write_bytes(after.read_bytes())
        print('reused', rel)
        continue
    result = subprocess.run(['git', 'merge-file', '-p', str(current), str(before), str(after)], capture_output=True)
    if result.returncode == 0:
        current.write_bytes(result.stdout)
        print('merged', rel)
    else:
        print('unmerged', rel, 'exit', result.returncode)
