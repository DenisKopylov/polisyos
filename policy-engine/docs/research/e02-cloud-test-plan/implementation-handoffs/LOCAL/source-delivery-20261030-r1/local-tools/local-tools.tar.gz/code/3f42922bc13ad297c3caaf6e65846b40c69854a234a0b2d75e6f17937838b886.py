"""Read-only stdlib inspection of the exact R18 failure artifacts; no product imports."""
from collections import Counter
from hashlib import sha256
from pathlib import Path
import json
import os
import sqlite3
import xml.etree.ElementTree as ET

CASE = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos/policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1/sql-v3-owner-first-native-r18-20261028')
root = CASE / 'basetemp/test_selected_registered_sql_p0/cas/artifacts/sha256'

def blob(artifact):
    digest = artifact.removeprefix('sha256:')
    raw = (root / digest[:2] / digest[2:4] / (digest + '.blob')).read_bytes()
    if sha256(raw).hexdigest() != digest:
        raise ValueError('blob hash mismatch')
    return json.loads(raw)

profiles = [path for path in root.rglob('*.manifest.json') if '.view.' in path.name]
candidates = [path for path in profiles if json.loads(path.read_text())['kind'] == 'fabric.registered_sql_capture']
assert len(candidates) == 1
manifest_path = candidates[0]
manifest = json.loads(manifest_path.read_text())
capture = blob(manifest['artifact_id'])
snapshot = blob(capture['snapshot_ref']['artifact_id'])
expected = []
for key, role in [('snapshot_ref', 'source.snapshot'), ('view_ref', 'source.view'), ('use_ref', 'source.use')]:
    ref = capture[key]
    expected.append((role, ref['artifact_id'], ref['manifest_profile_sha256']))
for key in ('data_ref', 'data_schema_ref', 'evidence_ref', 'quality_report_ref', 'warnings_ref'):
    ref = snapshot.get(key)
    if ref is not None:
        expected.append(('snapshot.' + key, ref['artifact_id'], ref['manifest_profile_sha256']))
ref = snapshot['source_lineage']['data_view_request_ref']
expected.append(('snapshot.data_view_request_ref', ref['artifact_id'], ref['manifest_profile_sha256']))
actual = Counter((row['role'], row['artifact_id'], row.get('manifest_profile_sha256')) for row in manifest['inputs'])
want = Counter(expected)
for _, artifact_id, profile in expected:
    digest, profile_hex = artifact_id[7:], profile[7:]
    profile_path = root / digest[:2] / digest[2:4] / (digest + '.view.' + profile_hex + '.manifest.json')
    assert profile_path.is_file()
    blob(artifact_id)

fixture = CASE / 'basetemp/test_in_place_config_aba_canno0'
a, b = fixture / 'source-a.sqlite', fixture / 'source-b.sqlite'
def read_income(db):
    connection = sqlite3.connect(db.as_uri() + '?mode=ro', uri=True)
    try:
        return [row[0] for row in connection.execute('SELECT income FROM policy_inputs')]
    finally:
        connection.close()
xml = ET.parse(CASE / 'pytest.xml').getroot()
failures = {x.attrib['name']: x.find('failure').attrib['message'] for x in xml.iter('testcase') if x.find('failure') is not None}
summary = {
    'base_commit': '0c2169fd0d17dc59b49733fe6a001ec4114d2d1c',
    'case_directory': str(CASE),
    'junit_sha256': sha256((CASE / 'pytest.xml').read_bytes()).hexdigest(),
    'failure_names': sorted(failures),
    'saved_driver_query_failure': failures['test_aba_default_config_cannot_change_the_executed_view'],
    'saved_path_failure': failures['test_in_place_config_aba_cannot_change_driver_database'],
    'sqlite_observed_double_slash_samefile_as_a': os.path.samefile('/' + str(a), a),
    'sqlite_a_samefile_as_b': os.path.samefile(a, b),
    'sqlite_a_values': read_income(a),
    'sqlite_b_values': read_income(b),
    'capture_artifact_id': manifest['artifact_id'],
    'capture_selected_manifest_path': str(manifest_path),
    'capture_selected_manifest_sha256': sha256(manifest_path.read_bytes()).hexdigest(),
    'capture_statement': capture['statement'],
    'capture_request_equals_snapshot_lineage': capture['request_ref'] == ref,
    'capture_manifest_edges_equal_independently_derived_snapshot_and_registration_edges': actual == want,
    'edge_count': sum(actual.values()),
    'expected_edge_count': sum(want.values()),
    'missing_edges': list((want - actual).elements()),
    'extra_edges': list((actual - want).elements()),
    'selected_edge_profiles_and_blob_hashes_checked': len(expected),
    'capture_output_digest': capture['output_sha256'],
    'saved_payload': blob(capture['payload_ref']['artifact_id']),
    'boundary': 'Saved objects do not retain Python class identities. The subclass explanation follows current source and installed Pydantic equality/revalidation semantics; the successor requires runtime confirmation.',
}
print(json.dumps(summary, indent=2))
