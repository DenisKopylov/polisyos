from pathlib import Path
root=Path('LOCAL/raw/e02-execution-20261027/repairs/TC-closure-owner-r4/proposal')
p=root/'policy-engine/tests/unit/scientist/nodes/builtins/decide/test_policy_runtime_method_metrics.py'
s=p.read_text()
a='''    registered_sql_admission_ref: ArtifactRef | None = None,
    candidate_data_snapshot_edge_ref: ArtifactRef | None = None,
'''
b='''    registered_sql_admission_ref: ArtifactRef | None = None,
    merge_registry_schema_override: str | None = None,
    candidate_data_snapshot_edge_ref: ArtifactRef | None = None,
'''
assert s.count(a)==1;s=s.replace(a,b,1)
a='''    source_payload_ref = _put_selected(
        {"baseline": baseline.tolist(), "scenario": scenario.tolist()},
'''
b='''    if merge_registry_schema_override is not None:
        # Same exact registry payload, separately selected manifest profile:
        # do not let a metadata name manufacture a known schema contract.
        from polisyos.core.artifacts.registry import RegistryBundle, RegistryBundlePayload

        original_merge = registry.merge_registry
        reprofiled_merge = store.put_json(
            DEFAULT_MERGE_RULE_REGISTRY,
            PutOptions(
                kind="ir.merge_rule_registry",
                media_type="application/json",
                schema=SchemaInfo(
                    name="polisyos.ir.kernel.MergeRuleRegistry",
                    version=merge_registry_schema_override,
                ),
            ),
            return_selected_profile=True,
        )
        assert reprofiled_merge.artifact_id == original_merge.artifact_id
        assert reprofiled_merge.manifest_profile_sha256 != original_merge.manifest_profile_sha256
        original_bundle = store.get_manifest(registry.bundle_ref)
        payload_dict = registry.model_dump(mode="python", exclude={"bundle_ref"})
        payload_dict["merge_registry"] = reprofiled_merge
        payload = RegistryBundlePayload.model_validate(payload_dict)
        edges = [
            input_ref_from_artifact_ref(reprofiled_merge, role="merge_registry")
            if edge.role == "merge_registry" else edge
            for edge in original_bundle.inputs
        ]
        new_ref = store.put_json(
            payload,
            PutOptions(kind="core.registry_bundle", media_type="application/json", inputs=edges),
            return_selected_profile=True,
        )
        registry = RegistryBundle(bundle_ref=new_ref, **payload.model_dump(mode="python"))

    source_payload_ref = _put_selected(
        {"baseline": baseline.tolist(), "scenario": scenario.tolist()},
'''
assert s.count(a)==1;s=s.replace(a,b,1);p.write_text(s)
p=root/'policy-engine/tests/integration/runtime/http/test_registered_sql_live_grant.py'
s=p.read_text()
a='''    def run_source(result, name):
'''
b='''    def run_source(result, name, *, merge_registry_schema_override=None):
'''
assert s.count(a)==1;s=s.replace(a,b,1)
a='''                registered_sql_admission_ref=source_ref,
            )
'''
b='''                registered_sql_admission_ref=source_ref,
                merge_registry_schema_override=merge_registry_schema_override,
            )
'''
assert s.count(a)==1;s=s.replace(a,b,1)
a='''    run_a, selection_a, ref_a = run_source(a, "sql-a")
    run_i, selection_i, ref_i = run_source(independent, "sql-i")
'''
b='''    run_a, selection_a, ref_a = run_source(a, "sql-a")
    run_i, selection_i, ref_i = run_source(independent, "sql-i")
    run_bad, selection_bad, _ = run_source(
        a, "sql-a-unknown-merge-schema", merge_registry_schema_override="99.0"
    )
'''
assert s.count(a)==1;s=s.replace(a,b,1)
a='''    assert actual.value["parameter_origin"] == "explicit_parameter"

    # Reuse the measured actual complete request budget'''
b='''    assert actual.value["parameter_origin"] == "explicit_parameter"
    # Same registry bytes under a real, unknown selected manifest profile are
    # carried by a real completed worker and must not yield a closed identity.
    assert get_result(run_bad, selection_bad)["exante_source_use"]["status"] == "unknown"

    # Reuse the measured actual complete request budget'''
assert s.count(a)==1;s=s.replace(a,b,1);p.write_text(s)
print('real CAS profile adversary authored')
