"""Exercise extracted class-domain logic with stdlib stand-ins, not product imports."""
import ast
import copy
import hashlib
import json
from dataclasses import dataclass, replace
from datetime import datetime, time, timedelta, timezone, tzinfo
from enum import Enum
from pathlib import Path

source = Path('LOCAL/raw/e02-execution-20261027/repairs/C90-provenance-domain-r5/postimages/policy-engine/src/polisyos/foundry/uncertainty/monte_carlo.py').read_text()
tree = ast.parse(source)
names = {'_own_provenance_value', '_own_json_metadata', '_metadata_wire_matches', '_provenance_wire_matches', '_finalize_prepared_results', '_envelope_identity_and_context_wires'}
functions = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in names]
assert {n.name for n in functions} == names
future = ast.ImportFrom(module='__future__', names=[ast.alias(name='annotations')], level=0)
code = compile(ast.fix_missing_locations(ast.Module(body=[future, *functions], type_ignores=[])), '<extracted proposal functions>', 'exec')

class ComposedFlavour(str, Enum):
    X = 'x'
class ExactnessKind(str, Enum):
    X = 'x'
class CertificateKind(str, Enum):
    X = 'x'
class CompositionStep:
    model_fields = {'flavour': None, 'notes': None}
    def __init__(self, flavour, notes):
        self.flavour = flavour
        self.notes = notes
    def model_copy(self, *, update):
        return CompositionStep(**update)
class CompositionProvenance:
    model_fields = {'operator_history': None, 'origins': None}
    def __init__(self, operator_history, origins):
        self.operator_history = operator_history
        self.origins = origins
    def model_copy(self, *, update):
        return CompositionProvenance(**update)
class Zone(tzinfo):
    minutes = 0
    def utcoffset(self, dt):
        return timedelta(minutes=self.minutes)
    def dst(self, dt):
        return timedelta(0)
class Borrowed(Enum):
    ITEM = {'data': [1]}
class DictSubclass(dict):
    pass

namespace = dict(globals())
exec(code, namespace)
own = namespace['_own_provenance_value']
zone = Zone()
values = [1]
timestamp = datetime(2026, 10, 28, 12, tzinfo=zone)
original = CompositionProvenance((CompositionStep(ComposedFlavour.X, {'nested': [(timestamp, values)]}),), ('origin',))
snapshot, owned = own(original, set())
assert owned is True
zone.minutes = 60
values.append(2)
event = snapshot.operator_history[0].notes['nested'][0]
assert type(event) is tuple and type(event[0]) is datetime
assert event[0].isoformat() == '2026-10-28T12:00:00+00:00'
assert event[1] == [1]
for value in (Borrowed.ITEM, time(12, tzinfo=zone), DictSubclass(x=1), object()):
    candidate = CompositionProvenance((CompositionStep(ComposedFlavour.X, {'nested': [value]}),), ('origin',))
    copied, qualified = own(candidate, set())
    assert not qualified and copied.operator_history[0].notes['nested'][0] is value
cycle = []
cycle.append(cycle)
assert own(cycle, set())[1] is False

@dataclass
class Envelope:
    gate_eligible: bool
    metadata: dict
    def model_copy(self, *, update):
        return replace(self, **update)
@dataclass
class Result:
    envelope: Envelope
    diagnostics: dict
@dataclass
class Prepared:
    nominal_params: dict
    input_envelopes: dict
    input_envelope_digests: dict
    fixed_scalar_values_owned: bool
    provenance_context_owned: bool
    metadata_context_owned: bool
result = Result(Envelope(True, {}), {})
prepared = Prepared({'x': 0.0}, {'x': None}, {'x': 'a'*64}, True, False, True)
finalized = namespace['_finalize_prepared_results']([result], prepared)[0]
assert not finalized.envelope.gate_eligible
assert finalized.diagnostics['input_identity_status'] == 'not_established'
assert finalized.envelope.metadata['provenance_context_status'] == 'not_established'
class WireProvenance:
    def __init__(self, label):
        self.label = label
    def model_dump(self, *, mode):
        return {'label': self.label}
class WireEnvelope:
    def __init__(self, label):
        self.composition_provenance = WireProvenance(label)
    def model_dump(self, *, mode):
        return {'composition_provenance': {'label': self.composition_provenance.label}, 'metadata': {'valid': [1]}, 'x': 1}
wire_envelope = WireEnvelope('initial')
digest, captured, metadata_wire = namespace['_envelope_identity_and_context_wires'](wire_envelope)
expected_bytes = json.dumps(wire_envelope.model_dump(mode='json'), sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode('utf-8')
assert digest == hashlib.sha256(expected_bytes).hexdigest()
assert namespace['_provenance_wire_matches'](wire_envelope, captured)
wire_envelope.composition_provenance.label = 'changed'
assert not namespace['_provenance_wire_matches'](wire_envelope, captured)
metadata = {'valid': [1]}
owned_metadata, meta_owned = namespace['_own_json_metadata'](metadata, set())
assert meta_owned and namespace['_metadata_wire_matches'](owned_metadata, metadata_wire)
metadata['valid'].append(2)
assert owned_metadata['valid'] == [1]
assert not namespace['_metadata_wire_matches'](metadata, metadata_wire)
assert not namespace['_own_json_metadata']({'nested': [Borrowed.ITEM]}, set())[1]
metadata_limited = Prepared({'x': 0.0}, {'x': None}, {'x': 'a'*64}, True, True, False)
limited = namespace['_finalize_prepared_results']([result], metadata_limited)[0]
assert not limited.envelope.gate_eligible and limited.envelope.metadata['metadata_context_status'] == 'not_established'
print(json.dumps({'digest': 'original bytes preserved and later provenance drift rejected', 'snapshot': 'nested tuple/list/datetime detached', 'borrowed': 'Enum, time, dict subclass, object and cycle capped', 'finalizer': 'non-gating and explicit', 'scope': 'extracted functions with stdlib stand-ins; not a product run'}))
