from pathlib import Path
p=Path('LOCAL/raw/e02-execution-20261027/repairs/q1-inspection-consumer-companion-r1/postimages/policy-engine/tests/unit/runtime/http/test_method_artifact_writer_inspector.py')
s=p.read_text()
s=s.replace('from polisyos.core.artifacts import CanonInfo, PutOptions, SchemaInfo','''from polisyos.core.artifacts import ArtifactRef, CanonInfo, FileSystemCAS, PutOptions, SchemaInfo
from polisyos.core.artifacts.signing import SigningConfig''')
s=s.replace('from polisyos.runtime.http.services.artifact_inspector import ArtifactInspectorService','''from polisyos.core.security.access_scope import AccessScope
from polisyos.core.security.tenant_context import (
    reset_current_access_scope,
    set_current_access_scope,
    tenant_scope,
)
from polisyos.runtime.http.resilience import GuardedDependencyProxy, build_runtime_cas_guard
from polisyos.runtime.http.services import artifact_inspector as inspector_module
from polisyos.runtime.http.services.artifact_inspector import (
    ArtifactInspectorService,
    ArtifactSurfaceAdmissionError,
)
from polisyos.runtime.quality.technical_inspection_evidence import (
    create_technical_inspection_evidence,
)''')
start=s.index('def test_fresh_public_inspector_consumes_literal_collision_payload(')
end=s.index('\n\n@pytest.mark.parametrize("surface"',start)
s=s[:start]+'''def test_fresh_public_inspector_consumes_literal_collision_payload(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("POLISYOS_HPC_OBSERVABILITY_ENABLED", "false")
    root = tmp_path / "cas"
    tenant, cell = "inspection-tenant", "inspection-cell"
    scope = AccessScope.for_service(
        tenant_id=tenant, cell_id=cell, spiffe_id="spiffe://test/inspection"
    )
    with tenant_scope(None, tenant_id=tenant, cell_id=cell):
        token = set_current_access_scope(scope)
        try:
            # The source writer's bounded publication owner requires a concrete
            # FileSystemCAS; writes register blob and selected-view ownership.
            store = FileSystemCAS(
                root, ownership_enforced=True, signing_config=SigningConfig(enabled=False)
            )
            capture, occurrence = capture_fixture(store)
            raw = {"ordinary": {"_type": "decimal", "value": "9"}, "null": None}
            produced = selected_ref(produce(store, capture, occurrence, {"sidecar": raw}))
            ref = ArtifactRef.model_validate(produced.model_dump(mode="python"))
            assert store.get_manifest(ref).artifact_id == ref.artifact_id
            guard = build_runtime_cas_guard()
            guarded = GuardedDependencyProxy(target=store, guard=guard)
            try:
                evidence = create_technical_inspection_evidence(guarded, ref)
            finally:
                guard.close()
            # Reopen the ownership-enforcing backend and preserve the guarded
            # handle for the actual consumer; read-only opening disables owner checks.
            fresh = FileSystemCAS(
                root, ownership_enforced=True, signing_config=SigningConfig(enabled=False)
            )
            fresh_guard = build_runtime_cas_guard()
            guarded_fresh = GuardedDependencyProxy(target=fresh, guard=fresh_guard)
            try:
                inspector = ArtifactInspectorService(
                    store=guarded_fresh, lineage_service=LineageService(store=guarded_fresh)
                )
                header = read_core_manifest_profile_bounded(
                    guarded_fresh, ref, max_manifest_bytes=inspector_module.INSPECTOR_MANIFEST_MAX_BYTES
                )
                with pytest.raises(ArtifactSurfaceAdmissionError) as missing:
                    inspector.get_content_preview(ref.artifact_id, manifest_read=header)
                assert missing.value.decision.reason == "authority_surface_signal_missing"
                preview = inspector.get_content_preview(
                    ref.artifact_id, manifest_read=header,
                    technical_inspection_evidence_ref=evidence,
                )
                assert preview.mode == "json"
                assert preview.preview["payload"] == raw
                assert preview.canon_read_status == "declared_bytes_conformant"
                schema = inspector.get_schema_view(
                    ref.artifact_id, manifest_read=header,
                    technical_inspection_evidence_ref=evidence,
                )
                assert schema.top_level_keys == sorted(MethodArtifactOutputPayload.model_fields)
                assert schema.canon_read_status == "declared_bytes_conformant"
            finally:
                fresh_guard.close()
        finally:
            reset_current_access_scope(token)
''' + s[end:]
start=s.index('def test_qualified_legacy_inspector_preview_unchanged(');end=s.index('\n\ndef test_backend_without_bounded_owner_ports',start)
s=s[:start]+'''def test_qualified_legacy_reader_succeeds_but_public_inspection_remains_blocked(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("POLISYOS_HPC_OBSERVABILITY_ENABLED", "false")
    store = local_store(tmp_path / "cas")
    capture, occurrence = capture_fixture(store, "legacy")
    produced = selected_ref(produce(store, capture, occurrence, {"sidecar": {"answer": 2}}))
    ref = ArtifactRef.model_validate(produced.model_dump(mode="python"))
    # The existing .2 reader still interprets the actual produced payload.
    read = inspector_module._read_inspector_semantic_json(store, ref, max_payload_bytes=65536)
    assert read.value["payload"] == {"answer": 2}
    inspector = ArtifactInspectorService(store=store, lineage_service=LineageService(store=store))
    # The .2 cohort is outside the new proof producer. Its public-positive
    # authority remains HOLD; codec conformance does not supply that authority.
    with pytest.raises(ArtifactSurfaceAdmissionError) as blocked:
        inspector.get_content_preview(ref.artifact_id)
    assert blocked.value.decision.reason == "authority_surface_signal_missing"
''' + s[end:]
start=s.index('def test_unknown_non_json_selected_cohort_remains_uninterpreted_raw_preview(')
s=s[:start]+s[start:].replace('def test_unknown_non_json_selected_cohort_remains_uninterpreted_raw_preview(', 'def test_unknown_non_json_projection_is_uninterpreted_but_public_read_blocked(',1)
old='''    preview = inspector.get_content_preview(unrelated.artifact_id, manifest_read=header)
    assert preview.mode == "text"
    assert preview.preview == raw.decode("utf-8")
    assert preview.canon_read_status == "not_evaluated"
    schema = inspector.get_schema_view(unrelated.artifact_id, manifest_read=header)
    assert schema.canon_read_status == "not_evaluated"
    assert schema.top_level_keys == []'''
new='''    seen: list[object] = []
    original = inspector_module.authority_surface_decision

    def observe(payload: object, **kwargs: Any) -> Any:
        seen.append(payload)
        return original(payload, **kwargs)

    monkeypatch.setattr(inspector_module, "authority_surface_decision", observe)
    # No replacement grant: preserve the real authority gate, recording the
    # actual pre-gate projection to prove the unknown view is not interpreted.
    with pytest.raises(ArtifactSurfaceAdmissionError) as content_blocked:
        inspector.get_content_preview(unrelated.artifact_id, manifest_read=header)
    assert content_blocked.value.decision.reason == "authority_surface_signal_missing"
    assert seen[-1] == raw
    with pytest.raises(ArtifactSurfaceAdmissionError) as schema_blocked:
        inspector.get_schema_view(unrelated.artifact_id, manifest_read=header)
    assert schema_blocked.value.decision.reason == "authority_surface_signal_missing"
    assert isinstance(seen[-1], dict)
    assert seen[-1]["canon_read_status"] == "not_evaluated"
    assert seen[-1]["top_level_keys"] == []
    # This cohort is not eligible for the bounded .3 Method evidence. Its
    # public-positive raw preview remains HOLD pending independently admitted
    # authority; the negative above does not claim to repair it.'''
assert old in s
s=s.replace(old,new,1)
p.write_text(s)
