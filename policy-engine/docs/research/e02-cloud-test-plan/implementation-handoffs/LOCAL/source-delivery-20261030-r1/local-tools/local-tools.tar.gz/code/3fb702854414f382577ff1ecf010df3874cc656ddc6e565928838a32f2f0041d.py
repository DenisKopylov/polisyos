"""Select actual Root receipts and retain the exact three-launch qualification."""
from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys

import root_wave_wrapper as w


def main() -> None:
    if len(sys.argv) != 6:
        raise ValueError('usage: qualify_wave BASELINE_CASE REMOVAL_CASE RESTORED_CASE PARENT_RECEIPT OUTPUT_DIRECTORY')
    names, parent, output = sys.argv[1:4], Path(sys.argv[4]), Path(sys.argv[5])
    if len(set(names)) != 3 or not all(name and all(ch.isalnum() or ch in '-_' for ch in name) for name in names):
        raise ValueError('invalid case identifiers')
    if not output.is_absolute() or not output.is_relative_to(w.ROOT) or any(p.is_symlink() for p in (output, *output.parents)):
        raise ValueError('output must be an absolute, symlink-free workspace path')
    output.mkdir(exist_ok=False)
    command = [str(w.PROJECT / '.venv/bin/python'), '-B', str(w.PACKET / 'qualify.py')]
    for role, name in zip(('baseline', 'removal', 'restored'), names, strict=True):
        case = w.D / name
        audit = json.loads((case / 'audit-result.json').read_text())
        if len(audit['readsets']) != 1:
            raise ValueError('one actual observer readset required for ' + role)
        readset = w.ROOT / audit['readsets'][0]['path']
        trace = case / ('basis-removal-trace.jsonl' if role == 'removal' else 'basis-restoration-trace.jsonl')
        trace_option = '--trace' if role == 'removal' else '--' + role + '-trace'
        command += [trace_option, str(trace), '--' + role + '-junit', str(case / 'pytest.xml'),
                    '--' + role + '-readset', str(readset), '--' + role + '-audit', str(case / 'audit-result.json'),
                    '--' + role + '-exit', str(audit['result']['return_code'])]
    command += ['--parent-env-receipt', str(parent)]
    result = subprocess.run(command, capture_output=True, text=True)
    for name, contents in (('stdout.txt', result.stdout), ('stderr.txt', result.stderr),
                           ('execution.json', json.dumps({'argv': command, 'exit_code': result.returncode}, indent=2) + '\n')):
        fd = os.open(output / name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            stream.write(contents)
            stream.flush()
            os.fsync(stream.fileno())
    print(json.dumps({'output':str(output), 'qualifier_exit':result.returncode}))
    raise SystemExit(result.returncode)


if __name__ == '__main__':
    main()
