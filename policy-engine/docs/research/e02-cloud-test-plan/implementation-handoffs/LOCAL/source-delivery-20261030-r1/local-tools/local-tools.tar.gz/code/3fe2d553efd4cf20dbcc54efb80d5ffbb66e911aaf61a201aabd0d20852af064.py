from pathlib import Path
import ast,subprocess,json,hashlib,difflib,tomllib
r=Path.cwd();raw=Path(__file__).parent;d=raw/'policy-engine';tree='53a834c476dfc2461ad17cc8c5fc9e128247d599';base='8db01b1076e425b7998b05a658776c991b7bd594'
files=[];patch=[];py=[]
for p in sorted(d.rglob('*')):
 if not p.is_file():continue
 rel='policy-engine/'+str(p.relative_to(d));old=subprocess.run(['git','show',tree+':'+rel],capture_output=True);data=p.read_bytes()
 if old.returncode==0 and data==old.stdout:continue
 if p.suffix=='.py':ast.parse(data,filename=rel);py.append(str(p))
 if p.suffix=='.toml':tomllib.loads(data.decode())
 before=subprocess.run(['git','rev-parse',base+':'+rel],capture_output=True,text=True)
 files.append({'path':rel,'postimage_path':str(p.relative_to(r)),'candidate_exists':old.returncode==0,'candidate_sha256':hashlib.sha256(old.stdout).hexdigest() if old.returncode==0 else None,'source_base_blob':before.stdout.strip() if before.returncode==0 else None,'postimage_sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
 patch.append('diff --git a/'+rel+' b/'+rel+'\n')
 patch.extend(difflib.unified_diff(old.stdout.decode().splitlines(True) if old.returncode==0 else [],data.decode().splitlines(True),fromfile='a/'+rel if old.returncode==0 else '/dev/null',tofile='b/'+rel))
(raw/'repair.patch').write_text(''.join(patch))
cmd=[str(r/'policy-engine/.venv/bin/python'),'-m','ruff','format','--config',str(r/'policy-engine/ruff.toml'),'--check',*py]
f=subprocess.run(cmd,capture_output=True,text=True);cmd2=[str(r/'policy-engine/.venv/bin/python'),'-m','ruff','check','--config',str(r/'policy-engine/ruff.toml'),'--select','F','--output-format','concise',*py];c=subprocess.run(cmd2,capture_output=True,text=True)
(raw/'diagnostics.txt').write_text('AST syntax parse: '+str(len(py))+' changed sparse Python postimages; no imports/runtime.\n\nCOMMAND '+json.dumps(cmd)+'\n'+f.stdout+f.stderr+'EXIT '+str(f.returncode)+'\n\nCOMMAND '+json.dumps(cmd2)+'\n'+c.stdout+c.stderr+'EXIT '+str(c.returncode)+'\n')
cloud=json.loads((r/'LOCAL/raw/e02-execution-20261027/cloud/C05/candidate-manifest.json').read_text());final={x['path']:{'sha256':x['postimage_sha256'],'source':'received cloud candidate'} for x in cloud['files']}
for x in files:final[x['path']]={'sha256':x['postimage_sha256'],'source':'sparse repair postimage'}
manifest={'slice':'C05','kind':'unapplied_sparse_proposal','source_base_commit':base,'candidate_tree':tree,'complete_repair_footprint':files,'complete_final_footprint':final,'repair_patch_sha256':hashlib.sha256((raw/'repair.patch').read_bytes()).hexdigest(),'repair_patch_bytes':(raw/'repair.patch').stat().st_size,'diagnostics_sha256':hashlib.sha256((raw/'diagnostics.txt').read_bytes()).hexdigest(),'checks':{'ast_parse':'PASS (syntax only)','sparse_formatter_exit':f.returncode,'sparse_f_only_ruff_exit':c.returncode,'canonical_runtime_tests':'UNRUN','canonical_full_ruff':'UNRUN','mypy':'UNRUN','adversarial_controls':'UNRUN','removal_controls':'UNRUN','G_acceptance':'not_requested/not_granted'},'mandatory_root_companions':['Regenerate architecture/public_surface/inventory.json and docs/reference/public-surface.md under root generated-family lease; read actual complete generated footprint.','Set release fragment public_surface_inventory_reviewed=true only after actual generated surface review.','Root composition receipt must bind actual commit/tree and full delivered deciding outputs, original cloud receipt remains author history.'],'canonical_tree_index_refs_modified_by_this_agent':False}
(raw/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
# Re-read all package deliverables, not merely an in-memory staging view.
for x in files:assert hashlib.sha256((r/x['postimage_path']).read_bytes()).hexdigest()==x['postimage_sha256']
assert json.loads((raw/'manifest.json').read_text())['repair_patch_sha256']==hashlib.sha256((raw/'repair.patch').read_bytes()).hexdigest()
print(json.dumps({'repair_files':len(files),'final_footprint':len(final),'patch_bytes':manifest['repair_patch_bytes'],'patch_sha256':manifest['repair_patch_sha256'],'manifest_sha256':hashlib.sha256((raw/'manifest.json').read_bytes()).hexdigest(),'format_exit':f.returncode,'F_only_exit':c.returncode}))
