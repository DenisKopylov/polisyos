from pathlib import Path
base=Path('LOCAL/raw/e02-execution-20261027/repairs/C41-r2/postimages/policy-engine/src/polisyos/runtime')
p=base/'quality/generic_simulation_admission.py'; s=p.read_text()
old='''                    expected_request=request,
                )
                if ('''; new='''                    # Old results can lack a selected profile. They remain
                    # candidate inputs, but cannot carry a verified join.
                    expected_request=(
                        request if record.result_ref.manifest_profile_sha256 is not None else None
                    ),
                )
                if ('''; assert old in s; s=s.replace(old,new,1); p.write_text(s)
p=base/'quality/generation_cycle.py'; s=p.read_text()
old='''    if not generic_refs_present:
        # Historical results may remain useful, but no selected owner request
        # is recoverable here; never silently promote that absence to authority.
        blockers.add("n5_execution_request_provenance_not_established")'''
new='''    if not generic_refs_present or simulation.simulation_result_ref.manifest_profile_sha256 is None:
        # Historical results may remain useful, but a selected owner join is
        # unavailable; never silently promote that absence to authority.
        blockers.add("n5_execution_request_provenance_not_established")'''
assert old in s; s=s.replace(old,new,1)
old='''    if (
        resolved_ref.kind != JOINT_SIMULATION_RESULT_ARTIFACT_KIND
        or resolved_ref.media_type != "application/json"
    ):
        _joint_simulation_result_integrity_error("artifact_reference_contract_mismatch")
    try:
        manifest = read_core_manifest_profile(store, resolved_ref)[0]'''
new='''    if (
        resolved_ref.kind != JOINT_SIMULATION_RESULT_ARTIFACT_KIND
        or resolved_ref.media_type != "application/json"
    ):
        _joint_simulation_result_integrity_error("artifact_reference_contract_mismatch")
    if expected_request is not None and resolved_ref.manifest_profile_sha256 is None:
        raise GenerationCycleError("joint_simulation_result_selected_view_binding_missing")
    try:
        manifest = read_core_manifest_profile(store, resolved_ref)[0]'''
assert old in s; s=s.replace(old,new,1)
s=s.replace('''    if expected_request is not None:
        if resolved_ref.manifest_profile_sha256 is None:
            raise GenerationCycleError("joint_simulation_result_selected_view_binding_missing")
        try:''','''    if expected_request is not None:
        try:''',1)
p.write_text(s)
p=base/'http/routes/runs.py'; s=p.read_text()
s=s.replace('''                            if type(execution) is GenericCycleSimulationN5ExecutionV3:
                                replay_request = execution.request_binding.request''','''                            if (
                                type(execution) is GenericCycleSimulationN5ExecutionV3
                                and simulation.simulation_result_ref.manifest_profile_sha256
                                is not None
                            ):
                                replay_request = execution.request_binding.request''',1)
old='''                            if request_binding_status == "resolved"
                            and type(execution) is GenericCycleSimulationN5ExecutionV3
                            else None
                        ),'''
new='''                            if request_binding_status == "resolved"
                            and type(execution) is GenericCycleSimulationN5ExecutionV3
                            and execution.result_ref.manifest_profile_sha256 is not None
                            else None
                        ),'''
# Two sites: load + port projection. The separate expected_atom_ids expression
# does not have this trailing call syntax.
assert s.count(old)==2, s.count(old); s=s.replace(old,new,2)
old='''                    if (
                        execution.status == "joint_simulated" and result_status != "joint_simulated"
                    ) or not set(result_blockers).issubset(blockers):
                        raise ValueError("generic_n5_result_execution_status_mismatch")'''
new='''                    added = set(result_blockers) - set(blockers)
                    if (
                        execution.status == "joint_simulated" and result_status != "joint_simulated"
                    ) or added - {"n5_execution_request_provenance_not_established"}:
                        raise ValueError("generic_n5_result_execution_status_mismatch")
                    blockers = tuple(dict.fromkeys((*blockers, *result_blockers)))'''
assert old in s; s=s.replace(old,new,1)
old='''                    if request_binding_status == "resolved":
                        n8_resolved = True
                        n8_value_ref = value_port.value_ref
                        n8_limitation = None
                    else:
                        n8_limitation = "generic_n5_request_binding_not_established"'''
new='''                    if request_binding_status == "resolved" and result_body_status == "resolved":
                        n8_resolved = True
                        n8_value_ref = value_port.value_ref
                        n8_limitation = None
                    else:
                        n8_limitation = "generic_n5_request_binding_not_established"'''
assert old in s; s=s.replace(old,new,1)
s=s.replace('''                        n8_authority_blockers=tuple(value_port.authority_blockers),''','''                        n8_authority_blockers=tuple(
                            dict.fromkeys((*value_port.authority_blockers, *blockers))
                        ),''',1)
p.write_text(s)
