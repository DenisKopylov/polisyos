"""Reconcile delivered C128 bytes/source profiles and enumerate its full failure denominator.

This instrument imports only the Python standard library. It never imports product code or
runs a numerical/test path. Counts are over complete delivered candidate entries, observer
snapshots, and JUnit testcases, with their explicit finite boundaries.
"""
from __future__ import annotations

import argparse
import collections
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET

BASE = "320ceeac32ae5dcea44bfcfe884f74ffb6ba0127"
DIFF_SHA = "bb3a6913046214bd11ba3c377b4812d7470a5bc1c192f92aedd2386231ff95ba"
MC = "policy-engine/src/polisyos/foundry/uncertainty/monte_carlo.py"
TEST = "policy-engine/tests/unit/foundry/uncertainty/test_joint_law_admission.py"
PREFIX = "test_refused_sampling_law_precedes_irrelevant_binding_and_never_evaluates"
MUTANT_SHA = "b9437abe057a8e3c84909e72fde4d8e51160b3ba4ad38cf0a26bb2ab69dda009"
PHASES = ("collect", "pilot", "module", "m13-positive", "m13-mutant", "m13-restored")


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def obj(root: Path, path: str) -> bytes:
    return subprocess.check_output(["git", "show", BASE + ":" + path], cwd=root)


def read(path: Path) -> bytes:
    data = path.read_bytes()
    return gzip.decompress(data) if path.suffix == ".gz" else data


def receipt(root: Path, path: Path) -> dict[str, object]:
    data = path.read_bytes()
    return {"path": str(path.relative_to(root)), "bytes": len(data), "sha256": sha(data)}


def mutate(original: bytes, patch: bytes) -> bytes:
    old = original.decode().splitlines(keepends=True)
    lines = patch.decode().splitlines(keepends=True)
    result = []
    cursor = 0
    i = 2
    while i < len(lines):
        match = re.match(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@", lines[i])
        if match is None:
            raise ValueError("unrecognized patch hunk")
        start = int(match.group(1)) - 1
        if start < cursor:
            raise ValueError("overlapping patch")
        result.extend(old[cursor:start])
        cursor = start
        i += 1
        before = after = 0
        while i < len(lines) and not lines[i].startswith("@@ "):
            line = lines[i]
            i += 1
            if line[0] in " -":
                if old[cursor] != line[1:]:
                    raise ValueError("patch preimage drift")
                cursor += 1
                before += 1
            if line[0] in " +":
                result.append(line[1:])
                after += 1
        if before != int(match.group(2) or 1) or after != int(match.group(4) or 1):
            raise ValueError("patch length drift")
    result.extend(old[cursor:])
    return "".join(result).encode()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    out = args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    carrier = root / "LOCAL/raw/e02-execution-20261027/cloud/C128"
    delivered = carrier / "delivered/c90-r17-mc-pilot-r1"
    manifest_path = carrier / "candidate-manifest.json"
    manifest = json.loads(manifest_path.read_bytes())
    drift = []
    if manifest["base_commit"] != BASE or sha((carrier / "source.diff").read_bytes()) != DIFF_SHA:
        raise ValueError("received source input identity drift")
    actual_paths = {str(p.relative_to(root)) for p in delivered.rglob("*") if p.is_file()}
    declared_paths = {row["delivered_file"] for row in manifest["files"]}
    if actual_paths != declared_paths or any(p.is_symlink() for p in delivered.rglob("*")):
        raise ValueError("delivered regular-file denominator drift")
    for row in manifest["files"]:
        data = (root / row["delivered_file"]).read_bytes()
        git_blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        if (len(data), sha(data), git_blob) != (
            row["bytes"], row["postimage_sha256"], row["postimage_git_blob"]
        ):
            drift.append(row["delivered_file"])
    if drift:
        raise ValueError("delivered payload drift: " + repr(drift))
    expected_mc = obj(root, MC)
    mutant_mc = mutate(expected_mc, (delivered / "M13.patch").read_bytes())
    if sha(mutant_mc) != MUTANT_SHA:
        raise ValueError("M13 reconstructed mutant drift")
    source_cache = {MC: expected_mc}
    source_sets = set()
    snapshots = []
    for phase in PHASES:
        path = delivered / (phase + ".origin.json.gz")
        origin = json.loads(read(path))
        cloud_root = Path(origin["repo_root"])
        failures = []
        seen_sources = set()
        for source, witness in origin["sources"].items():
            try:
                relative = str(Path(source).relative_to(cloud_root))
            except ValueError:
                failures.append({"source": source, "reason": "foreign_origin"})
                continue
            if relative not in source_cache:
                source_cache[relative] = obj(root, relative)
            expected = mutant_mc if phase == "m13-mutant" and relative == MC else source_cache[relative]
            blob = hashlib.sha1(b"blob " + str(len(expected)).encode() + b"\0" + expected).hexdigest()
            if witness != {"sha256": sha(expected), "git_blob": blob}:
                failures.append({"source": source, "reason": "source_hash_or_blob_mismatch"})
            seen_sources.add(relative)
        namespace_paths = set()
        for module in origin["module_origins"]:
            if module["source"] is not None and module["source"] not in origin["sources"]:
                failures.append({"source": module["source"], "reason": "module_source_missing"})
            for namespace in module["namespace_paths"]:
                try:
                    relative = str(Path(namespace).relative_to(cloud_root))
                except ValueError:
                    failures.append({"source": namespace, "reason": "foreign_namespace"})
                    continue
                entry = subprocess.check_output(
                    ["git", "ls-tree", "-d", BASE, "--", relative], cwd=root
                )
                if not entry:
                    failures.append({"source": namespace, "reason": "namespace_absent_at_base"})
                namespace_paths.add(relative)
        source_sets.update(seen_sources)
        snapshot = {
            "phase": phase, "input": receipt(root, path), "pid": origin["pid"],
            "recorded_sources": len(seen_sources), "namespace_paths": len(namespace_paths),
            "reconciliation_failures": failures, "profile_intact": origin["profile_intact_at_finish"],
            "jax_at_finish": origin["jax_at_finish"], "environment_allowlist": origin["env"],
            "interpreter": origin["interpreter"], "inipath": origin["inipath"],
            "observation_boundary": origin["observation_boundary"],
        }
        snapshots.append(snapshot)
    if any(s["reconciliation_failures"] for s in snapshots):
        raise ValueError("observer source reconciliation failed")
    for snapshot in snapshots:
        backend = snapshot["jax_at_finish"]
        if backend.get("backend") != "cpu" or backend.get("x64") is not False:
            raise ValueError("observed numerical profile differs: " + snapshot["phase"])
        if not backend.get("devices"):
            raise ValueError("observed devices unavailable: " + snapshot["phase"])
        if snapshot["phase"] != "collect" and snapshot["profile_intact"] is not True:
            raise ValueError("profile hook not intact: " + snapshot["phase"])
        for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
            if snapshot["environment_allowlist"].get(name) != "1":
                raise ValueError("observed thread profile differs: " + name)
    qualification = {
        "source_diff": receipt(root, carrier / "source.diff"), "sourceBase": BASE,
        "candidate_manifest": receipt(root, manifest_path),
        "candidate_tree": manifest["candidate_tree_reconstructed_from_received_diff"],
        "regular_file_denominator": len(actual_paths), "payload_drift": drift,
        "versions": (delivered / "versions.txt").read_text().splitlines(),
        "snapshots": snapshots, "unique_recorded_source_paths": len(source_sets),
        "boundary": "received bytes and finite session-finish polisyos snapshots; no product import, "
        "test/plugin/config executed-byte attestation, full dynamic reads, child or native custody",
    }
    # Classification occurs only after complete delivered input and finite source/profile checks.
    xml_path = delivered / "module.junit.xml.gz"
    xml = ET.fromstring(read(xml_path))
    cases = list(xml.iter("testcase"))
    outcomes = collections.Counter()
    groups = {}
    failed_nodes = []
    for case in cases:
        status = next((name for name in ("failure", "error", "skipped") if case.find(name) is not None), "pass")
        outcomes[status] += 1
        if status != "failure":
            continue
        failure = case.find("failure")
        text = failure.text or ""
        assertion = re.search(r"^>\s+(assert .+)$", text, re.M)
        location = re.findall(r"^(tests/[^\n]+\.py):(\d+): ([^\n]+)$", text, re.M)
        parameters = [re.search(r"\b" + name + r" = '([^']+)'", text)
            for name in ("route", "fault", "kind")]
        if assertion is None or not location or any(value is None for value in parameters):
            raise ValueError("unclassified failure: " + case.attrib["name"])
        key = (location[-1][0], location[-1][1], assertion.group(1), location[-1][2])
        group = groups.setdefault(key, {"cases": [], "by_route": collections.Counter(),
            "by_fault": collections.Counter(), "by_kind": collections.Counter(),
            "extra_identity_limitation_in_every_failure": True})
        route, fault, kind = (value.group(1) for value in parameters)
        node = TEST.removeprefix("policy-engine/") + "::" + case.attrib["name"]
        failed_nodes.append(node)
        group["cases"].append({"nodeid": node, "route": route, "fault": fault, "kind": kind,
            "failure_text_sha256": sha(text.encode())})
        for field, value in (("by_route", route), ("by_fault", fault), ("by_kind", kind)):
            group[field][value] += 1
        group["extra_identity_limitation_in_every_failure"] &= (
            "{'input_identity_status': 'not_established'}" in text
            and "Left contains 1 more item:" in text
        )
    group_rows = []
    for key, value in sorted(groups.items()):
        group_rows.append({"path": key[0], "line": int(key[1]), "first_real_assertion": key[2],
            "exception": key[3], "count": len(value["cases"]), **value})
    report = {
        "schema": "policyos.c128.complete_failure_denominator.v1",
        "qualification": qualification, "junit_input": receipt(root, xml_path),
        "denominator": {"path": str(xml_path.relative_to(root)), "file_type": "one gzip-compressed JUnit XML",
            "all_testcases": len(cases), "outcomes": dict(outcomes),
            "failure_groups": len(groups), "all_failures_grouped": len(failed_nodes)},
        "groups": group_rows, "local_numeric_or_test_execution": False,
        "G_acceptance": False, "closure_ids": [],
    }
    (out / "failure-denominator.json").write_text(json.dumps(report, indent=2) + "\n")
    (out / "targeted-failed-nodeids.txt").write_text("\n".join(failed_nodes) + "\n")
    summary = {
        "qualified_regular_files": len(actual_paths), "observer_snapshots": len(snapshots),
        "unique_recorded_source_paths": len(source_sets), "source_reconciliation_failures": 0,
        "junit_testcases": len(cases), "outcomes": dict(outcomes),
        "groups": [{k: v for k, v in row.items() if k != "cases"} for row in group_rows],
        "classification_inputs_verified_before_grouping": True,
        "local_product_import_or_numeric_execution": False,
    }
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
