"""Prepare sparse source bytes and static checks; no product imports or Git writes."""
from pathlib import Path
import ast,difflib,hashlib,json,stat,subprocess,tomllib
ROOT=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos');OUT=Path(__file__).resolve().parent;POST=OUT/'postimages';P=ROOT/'policy-engine'
base=json.loads((OUT/'base.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();checks=[]
for path in sorted(POST.rglob('*.py')):
 logical=str(ROOT/path.relative_to(POST));data=path.read_bytes();compile(data,logical,'exec')
 for args in [('check','--select','I','--fix'),('format',)]:
  argv=[str(P/'.venv/bin/python'),'-m','ruff',*args,'--no-cache','--stdin-filename',logical,'-'];done=subprocess.run(argv,input=data,cwd=P,capture_output=True);assert done.returncode==0,(logical,done.stdout.decode(),done.stderr.decode());data=done.stdout
 path.write_bytes(data);compile(data,logical,'exec')
 for args in [('check',),('format','--check')]:
  argv=[str(P/'.venv/bin/python'),'-m','ruff',*args,'--no-cache','--stdin-filename',logical,'-'];done=subprocess.run(argv,input=data,cwd=P,capture_output=True)
  row={'path':str(path.relative_to(POST)),'argv':argv,'exit':done.returncode,'stdout':done.stdout.decode(),'stderr':done.stderr.decode()};checks.append(row);assert done.returncode==0,row
for path in POST.rglob('*.toml'):tomllib.loads(path.read_text())
owner='policy-engine/src/polisyos/scientist/nodes/builtins/simulate/propagate_uncertainty.py'
old=subprocess.check_output(['git','show',base['head']+':'+owner],cwd=ROOT).decode();new=(POST/owner).read_text()
wrong='''                envelope = _mark_state_slot_projection(
                    item,
                    candidate=response_candidate,
                    response_source=response_source,
                    moment_name=moment_name,
                ).envelope
''';correct=wrong.removesuffix(').envelope\n')+')\n'
assert old.count(wrong)==1 and new==old.replace(wrong,correct,1),'Source delta exceeds actual wrong unwrap'
helper=lambda s:next(ast.get_source_segment(s,n) for n in ast.parse(s).body if isinstance(n,ast.FunctionDef) and n.name=='_mark_state_slot_projection')
assert helper(old)==helper(new)
test='policy-engine/tests/unit/foundry/calibration/test_identifiability_response_basis.py'
a=subprocess.check_output(['git','show',base['head']+':'+test],cwd=ROOT).decode();b=(POST/test).read_text()
for name in ['_native_fixture','_diagnostic']:
 f=lambda s:next(ast.get_source_segment(s,n) for n in ast.parse(s).body if isinstance(n,ast.FunctionDef) and n.name==name)
 assert f(a)==f(b),name
# Existing nested JSON params/source fixture remains byte-identical.
fn='test_native_response_calibration_report_reaches_fresh_state_slot_consumer'
def nested(s):
 n=next(n for n in ast.parse(s).body if isinstance(n,ast.FunctionDef) and n.name==fn)
 return next(ast.get_source_segment(s,n) for n in n.body if isinstance(n,ast.FunctionDef) and n.name=='execute_node')
assert nested(a)==nested(b)
files=[];patch=[]
for path in sorted(POST.rglob('*')):
 if not path.is_file():continue
 rel=str(path.relative_to(POST));info=path.stat();assert stat.S_ISREG(info.st_mode) and info.st_nlink==1 and not path.is_symlink()
 pin=subprocess.check_output(['git','ls-tree',base['head'],'--',rel],cwd=ROOT,text=True).split();before=subprocess.check_output(['git','show',base['head']+':'+rel],cwd=ROOT) if pin else b'';after=path.read_bytes();assert before!=after
 assert (ROOT/rel).exists()==bool(pin)
 if pin:assert (ROOT/rel).read_bytes()==before,('Current preimage changed',rel)
 files.append({'path':rel,'role':'mechanism' if rel==owner else 'mandatory companion','preimage_mode':pin[0] if pin else None,'preimage_git_blob':pin[2] if pin else None,'preimage_sha256':sha(before) if pin else None,'postimage_git_blob':hashlib.sha1(b'blob '+str(len(after)).encode()+b'\0'+after).hexdigest(),'postimage_sha256':sha(after),'bytes':len(after),'postimage':str(path.relative_to(ROOT))})
 patch.append(f'diff --git a/{rel} b/{rel}\n')
 if not pin:patch.append('new file mode 100644\n')
 patch.extend(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+rel if pin else '/dev/null',tofile='b/'+rel,n=3))
raw=''.join(patch).encode();(OUT/'proposal.patch').write_bytes(raw)
check=subprocess.run(['git','apply','--check','--whitespace=error',str(OUT/'proposal.patch')],cwd=ROOT,capture_output=True,text=True);assert check.returncode==0,check.stderr
mutant=new.replace(correct,wrong,1);assert mutant==old;compile(mutant,owner,'exec')
removal=''.join(difflib.unified_diff(new.splitlines(True),mutant.splitlines(True),fromfile='a/'+owner,tofile='b/'+owner,n=3)).encode();(OUT/'removals').mkdir(exist_ok=True);(OUT/'removals/restore-incorrect-envelope-unwrap.patch').write_bytes(removal)
(OUT/'property-removals.json').write_text(json.dumps({'controls':[{'path':owner,'patch':'removals/restore-incorrect-envelope-unwrap.patch','patch_sha256':sha(removal),'preimage_sha256':sha(new.encode()),'postimage_sha256':sha(mutant.encode()),'test':'tests/unit/foundry/calibration/test_identifiability_response_basis.py::'+fn,'expected_red':'The real public node raises AttributeError UncertaintyEnvelope has no envelope at the second unwrap, before returning outcome/persisting output. This exactly restores the retained actual R9 source failure. All source/params/DTO/metadata/fixtures remain intact. A setup/import/backend or other error is not this red.','prior_actual_red':base['actual_R9_audit'],'runtime':'UNRUN for a new mutation; prior actual red remains separately bound, not automatically a post-compose removal result.','restore':'Root restores exact source bytes and requires same unchanged consumer positive; no concurrent imports while mutating canonical source.'}]},indent=2)+'\n')
static={'checks':checks,'python_files':len({r['path'] for r in checks}),'compile':'PASS, no execution','TOML':'PASS','mutant_compile':'PASS, no execution','source_only_change':'Remove one extra .envelope suffix on the existing canonical Envelope-returning marker call; entire owner otherwise byte-identical.','marker_contract_bytes_unchanged':True,'fixture_and_nested_JSON_params_unchanged':True,'apply_check':{'exit':check.returncode,'stdout':check.stdout,'stderr':check.stderr},'product_imports':False,'pytest_collection':'UNRUN','runtime':'UNRUN'};(OUT/'static-checks.json').write_text(json.dumps(static,indent=2)+'\n')
manifest={'schema':'policyos.e02.sparse_proposal.v1','task':'C78-state-slot-envelope-r10','base_commit':base['head'],'base_tree':base['tree'],'status':'source candidate awaiting frozen independent delta review and Root execution','files':files,'footprint':{'total_postimage_paths':len(files),'mechanism_paths':sum(f['role']=='mechanism' for f in files),'mandatory_companion_postimages':sum(f['role']=='mandatory companion' for f in files)},'patch':{'path':str((OUT/'proposal.patch').relative_to(ROOT)),'sha256':sha(raw),'bytes':len(raw)},'source_scope':static['source_only_change'],'runtime':'UNRUN by author; actual R9 remains18P/1F; later scalar assertions not reached','capability_state':'verification_missing','canonical_index_refs_changed':False,'closure_ids':[]};(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'patch_sha256':sha(raw),'patch_bytes':len(raw),'postimages':len(files),'source_deleted_bytes':len(old.encode())-len(new.encode()),'static_python_files':static['python_files']}))
