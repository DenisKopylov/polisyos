from pathlib import Path
R=Path(__file__).resolve().parent/'postimages'
p=R/'policy-engine/src/polisyos/runtime/quality/generation_cycle.py';s=p.read_text()
start=s.index('    if not raw_rows:\n        return None\n    grouped:',s.index('def _load_value_data_profile_from_l1_dcat('))
end=s.index('    unit_count = len({row.unit_id for row in owner_rows})',start)
block=s[start:end]
assert block.count('registered_measurement_units_by_id')==1
replacement='''    owner_row_selection = _value_owner_rows_from_source_rows(
        outcome=outcome,
        raw_rows=raw_rows,
        owner_access_ref=owner_access_ref,
        registered_measurement_units_by_id=registered_measurement_units_by_id,
    )
    if owner_row_selection is None:
        return None
    owner_rows, measurement_unit = owner_row_selection
'''
s=s[:start]+replacement+s[end:]
helper='''def _value_owner_rows_from_source_rows(
    *,
    outcome: str,
    raw_rows: Sequence[tuple[str, int, float, str, str, object]],
    owner_access_ref: str,
    registered_measurement_units_by_id: Mapping[str, str],
) -> tuple[tuple[ValueOwnerRow, ...], str] | None:
    """Apply the canonical owner row, unit, and source-set refusal rules.

    This is the common reconstruction boundary for the catalog loader and
    candidate consumers of selected projection bytes. It proves row semantics,
    not that a supplied projection was issued by the active catalog owner.
    Source-scope and registered conversion selection remain the loader's job;
    a candidate reader may not invent those selections.
    """
'''+block+'''    return owner_rows, measurement_unit


'''
anchor=s.index('def _value_owner_row(\n')
s=s[:anchor]+helper+s[anchor:];p.write_text(s)
p=R/'policy-engine/src/polisyos/runtime/quality/hte_source_projection.py';s=p.read_text();s=s.replace('import json\n','').replace('from collections import Counter, defaultdict','from collections import Counter')
s=s.replace('the role choice remains consumer asserted, while semantic alignment and source\ntime remain unestablished.','the role choice remains consumer asserted, while owner issuance, semantic\nalignment, and source time remain unestablished. Selected CAS and projection\ndigests establish internal consistency only; active-owner provenance requires\nthe existing catalog receipt/passport readback and is not inferred here.')
s=s.replace('    role_mapping_status: Literal["consumer_asserted"] = "consumer_asserted"\n','    role_mapping_status: Literal["consumer_asserted"] = "consumer_asserted"\n    owner_issuance_status: Literal["not_established"] = "not_established"\n')
start=s.index('def _profile_rows_from_projection(\n');end=s.index('\n\ndef _cell_values(',start)
s=s[:start]+'''def _profile_rows_from_projection(
    gc: Any,  # noqa: ANN401
    projection: ActivatedAcquisitionObservationProjection,
) -> tuple[Any, ...]:
    """Use the owner intake without assigning a country or unit conversion.

    The supplied CAS snapshot is candidate content, not a current owner read.
    Only its declared coordinates enter this join. An owner-normalized scope or
    registered conversion must already be represented by an exact matching
    profile; this reader never fills it in from a country string or role label.
    """
    raw_rows: list[tuple[str, int, float, str, str, object]] = []
    for projected in projection.observations:
        observation = projected.observation
        period_id = (
            observation.year
            if observation.year is not None
            else observation.survey_year
            if observation.survey_year is not None
            else observation.wave
        )
        if type(period_id) is not int:
            _refuse("source_projection_time_coordinate_not_supported")
        raw_rows.append(
            (
                observation.country_code,
                period_id,
                observation.value,
                observation.dataset_id,
                observation.observation_id,
                observation.condition_json,
            )
        )
    try:
        selected_rows = gc._value_owner_rows_from_source_rows(
            outcome=projection.variable_id,
            raw_rows=raw_rows,
            owner_access_ref="selected_hte_source_projection:internal_consistency_only",
            registered_measurement_units_by_id={},
        )
    except gc.ValueOwnerAccessError as exc:
        raise HTESourceProjectionError(exc.code) from exc
    except (TypeError, ValueError, OverflowError) as exc:
        # Malformed optional source metadata cannot discard an independently
        # verified native point/interval. Programming/backend errors still
        # propagate rather than being relabeled as a source-data refusal.
        raise HTESourceProjectionError("source_projection_rows_invalid") from exc
    if selected_rows is None:
        _refuse("source_projection_rows_missing")
    owner_rows, _measurement_unit = selected_rows
    return owner_rows
'''+s[end:]
p.write_text(s)
p=R/'policy-engine/src/polisyos/scientist/methods/search/uncertainty.py';s=p.read_text()
s=s.replace('    from polisyos.ir.analytics import HTEOutcome\n','    from polisyos.core.artifacts.canonical_profile import CoreJsonReadLimits\n    from polisyos.ir.analytics import HTEOutcome\n',1)
start=s.index('    def verify_physical_materialization(\n');end=s.index('        """Recompute the selected physical HTE input binding from this CAS."""',start)
fragment=s[start:end];assert fragment.count(') -> None:')==1
s=s[:start]+fragment.replace(') -> None:',') -> CoreJsonReadLimits:')+s[end:]
s=s.replace('                    "source_semantic_alignment_not_established",\n                    "source_time_not_established",','                    "source_semantic_alignment_not_established",\n                    "source_owner_issuance_not_established",\n                    "source_time_not_established",',1)
p.write_text(s)
p=R/'policy-engine/src/polisyos/runtime/quality/README.md';s=p.read_text();anchor='## Runtime projection input boundaries\n';assert s.count(anchor)==1
s=s.replace(anchor,'''## Selected HTE source content join

`hte_source_projection.py` joins one frozen HTE input to its exact selected
source-assignment, profile, projection, and array bytes. Its row reconstruction
uses `generation_cycle._value_owner_rows_from_source_rows`, the same intake as
the catalog ValueOwner loader: ambiguous unit-period cells, conflicting or
missing declared units, and mixed source datasets are refused. Optional join
refusals leave an independently verified point/native interval intact and make
candidate routing unavailable. The join establishes selected-snapshot internal
consistency only. It does not re-resolve active catalog receipt/passport
issuance, assign country-scope or unit conversions, establish source time, or
authorize roles. Ordinary admission transport and earlier-funnel wiring remain
separate bridge work.

'''+anchor,1);p.write_text(s)
