"""Exercise guard removal on synthetic code; compile proposed real source only."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import types

from mutation_core import make_codes, MutationDriftError

SYNTHETIC = b'''\
class GenerationCycleController:
    def _n7_data_requirement_basis_with_report(self, source_gap, request_binding_refused, routing_limitation_code):
        if source_gap is not None and not request_binding_refused and routing_limitation_code is None:
            routing_limitation_code = "requirement_gap_not_compiled"
        return routing_limitation_code or "unbound_requirement_input_refused"
'''
original, mutant, details = make_codes(SYNTHETIC, '<synthetic>')
module = types.ModuleType('synthetic')
exec(compile(SYNTHETIC, '<synthetic>', 'exec', dont_inherit=True), module.__dict__)
fn = module.GenerationCycleController.__dict__['_n7_data_requirement_basis_with_report']
assert fn.__code__ == original
instance = module.GenerationCycleController()
assert instance._n7_data_requirement_basis_with_report(object(), False, 'unbound_requirement_input_refused') == 'unbound_requirement_input_refused'
fn.__code__ = mutant
assert instance._n7_data_requirement_basis_with_report(object(), False, 'unbound_requirement_input_refused') == 'requirement_gap_not_compiled'
assert instance._n7_data_requirement_basis_with_report(object(), False, None) == 'requirement_gap_not_compiled'
fn.__code__ = original
assert instance._n7_data_requirement_basis_with_report(object(), False, 'unbound_requirement_input_refused') == 'unbound_requirement_input_refused'
try:
    make_codes(SYNTHETIC.replace(b' and routing_limitation_code is None', b''), '<changed>')
except MutationDriftError as exc:
    drift = str(exc)
else:
    raise AssertionError('removed guard must not pass source admission')
root = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
proposed = root / 'LOCAL/raw/e02-execution-20261027/repairs/R171-reason-monotonicity-r1/postimages/policy-engine/src/polisyos/runtime/quality/generation_cycle.py'
real = proposed.read_bytes()
_, _, actual_details = make_codes(real, str(root / 'policy-engine/src/polisyos/runtime/quality/generation_cycle.py'))
print(json.dumps({'scope':'synthetic behavior plus compile-only proposed producer; no product import','synthetic':details,
                  'proposed_source_sha256':hashlib.sha256(real).hexdigest(),'proposed_ast':actual_details,
                  'synthetic_prior_refusal_preserved_then_removed_then_restored':True,'no_prior_refusal_continues':True,'source_drift_refused':drift},indent=2))
