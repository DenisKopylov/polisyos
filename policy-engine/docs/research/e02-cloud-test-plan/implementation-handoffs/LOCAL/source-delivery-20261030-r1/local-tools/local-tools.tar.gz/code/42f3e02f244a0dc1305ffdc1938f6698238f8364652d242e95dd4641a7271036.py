from pathlib import Path
import ast,datetime,difflib,hashlib,json,subprocess,tomllib
D=Path(__file__).parent;R=D.parent/'R4-public-consumer-context-r5';root=Path.cwd()
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],text=True).strip()
head=git('rev-parse','HEAD');tree=git('rev-parse','HEAD^{tree}');branch=git('symbolic-ref','--short','HEAD');assert head=='78e342fc92cdf51a7940a2c93bc23577fecea8df',head
assert git('status','--porcelain','--untracked-files=no')==''
old=json.loads((R/'manifest.json').read_text());files=[];full=[];delta=[]
for p in sorted((D/'postimages').rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(D/'postimages').as_posix();target=root/rel;pre=target.read_bytes() if target.exists() else None;post=p.read_bytes();oldpost=R/'postimages'/rel;r5pre=oldpost.read_bytes() if oldpost.exists() else pre
 if pre is not None:
  for ref in ('HEAD:'+rel,':'+rel):assert subprocess.check_output(['git','show',ref])==pre,(rel,ref)
 else:assert subprocess.run(['git','ls-files','--error-unmatch',rel],capture_output=True).returncode!=0
 item={'path':rel,'pre_sha256':sha(pre) if pre is not None else None,'r5_post_sha256':sha(r5pre) if r5pre is not None else None,'post_sha256':sha(post),'post_bytes':len(post),'postimage_file':str(p),'delta_from_r5':r5pre!=post};files.append(item)
 for base,parts in ((pre,full),(r5pre,delta)):
  if base!=post:parts.extend(difflib.unified_diff((base or b'').decode().splitlines(True),post.decode().splitlines(True),fromfile='a/'+rel if base is not None else '/dev/null',tofile='b/'+rel))
 if rel.endswith('.py'):compile(post,str(p),'exec')
 if rel.endswith('.toml'):tomllib.loads(post.decode())
(D/'proposal.patch').write_text(''.join(full));(D/'delta-from-r5.patch').write_text(''.join(delta))
apply=subprocess.run(['git','apply','--check',str(D.resolve()/'proposal.patch')],capture_output=True,text=True);assert apply.returncode==0,apply.stderr
inputs={r['path'] for r in old['source_inputs']};inputs.update(f['path'] for f in files if f['pre_sha256']);inputs.update(['policy-engine/tests/unit/runtime/http/test_review_effectiveness_projection.py','policy-engine/src/polisyos/runtime/http/services/review_effectiveness.py','policy-engine/src/polisyos/runtime/http/deployment_security_attestation.py'])
readset=[]
for name in sorted(inputs):
 p=Path(name);b=p.read_bytes();readset.append({'path':name,'sha256':sha(b),'bytes':len(b)})
# Every inherited readset remains exactly the frozen source of the reviewed R4.
for old_input in old['source_inputs']:
 assert next(r for r in readset if r['path']==old_input['path'])['sha256']==old_input['sha256'],old_input['path']
def fn(path,name):
 s=path.read_text();return ast.dump(next(n for n in ast.walk(ast.parse(s)) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name),include_attributes=False)
protected=[('policy-engine/src/polisyos/runtime/http/resource_binding.py','_resolve_method_execution_indexed_run'),('policy-engine/tests/unit/runtime/http/test_observational_method_runtime.py','test_real_forest_fit_progress_spans_durable_cancel_post')]
for rel,name in protected:assert fn(R/'postimages'/rel,name)==fn(D/'postimages'/rel,name),(rel,name)
public=Path('policy-engine/tests/unit/runtime/http/test_method_candidate_evidence_roundtrip.py');assert (R/'postimages'/public).read_bytes()==(D/'postimages'/public).read_bytes()
checks={'runtime':'UNRUN','product_or_test_imports':'NONE','database_queries':'NONE','source_compile':'PASS','TOML_parse':'PASS','latest_Ruff_checks':'PASS for 13 Python postimages','git_apply_check':{'returncode':apply.returncode,'stdout':apply.stdout,'stderr':apply.stderr},'all_existing_preimages_HEAD_index_worktree_equal':True,'protected_alias_resolver_and_Root_native_function_AST_equals_R4':True,'entire_Core_public_test_file_equals_R4':True,'binding_digest_factorization':'same existing canonical dictionary law shared by live/cold; runtime recomputation UNRUN','ordinary_unrelated_denial_policy':'preserved; same generic boundary used only populated target policy and sealed-dependency operations','semantic_and_generated_checks':'UNRUN; no static marker check claimed as runtime evidence'}

source=D/'postimages/policy-engine/src/polisyos/runtime/http/authz_middleware.py'
nodes={n.name:n for n in ast.walk(ast.parse(source.read_text())) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
handlers=[h.type.id for h in ast.walk(nodes['_complete_target_admission_operation']) if isinstance(h,ast.ExceptHandler) and isinstance(h.type,ast.Name)]
assert handlers==['Exception','Exception'],handlers
calls=[{'function':n.name,'line':x.lineno} for n in nodes.values() for x in ast.walk(n) if isinstance(x,ast.Call) and isinstance(x.func,ast.Attribute) and x.func.attr=='_complete_target_admission_operation']
assert len(calls)==2,calls
assert not any(isinstance(n,ast.Name) and n.id=='emit_runtime_authorization_audit_async' for n in ast.walk(nodes['_admit_bound_policy_targets']))
for rel in ['policy-engine/src/polisyos/runtime/http/access_audit.py','policy-engine/src/polisyos/runtime/http/resource_binding.py','policy-engine/src/polisyos/runtime/http/services/review_effectiveness.py','policy-engine/tests/unit/runtime/http/test_review_effectiveness_projection.py']:
 assert (D/'postimages'/rel).read_bytes()==(R/'postimages'/rel).read_bytes(),rel
checks.update({'generic_boundary_handlers':handlers,'complete_boundary_call_sites':calls,'inner_target_operation_terminal_emitter_count':0,'R5_cold_owner_consumer_and_tests_byte_identical':True,'boundary_residual':'BaseException/cancellation/process termination/crash/audit crash durability'})
(D/'static-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
reviews=[]
for name in ['R4-public-consumer-context-r5-independent/review.md']:
 p=D.parents[1]/'reviews'/name;b=p.read_bytes();reviews.append({'path':str(p),'sha256':sha(b),'bytes':len(b)})
raw=[]
for p in sorted(D.iterdir()):
 if p.is_file() and p.name!='manifest.json':b=p.read_bytes();raw.append({'path':str(p),'sha256':sha(b),'bytes':len(b)})
manifest={'schema':'policyos.e02.raw_generic_target_admission_terminalization_proposal.v1','state':'FROZEN_UNAPPLIED_RUNTIME_UNRUN','created_utc':datetime.datetime.now(datetime.UTC).isoformat(),'root':str(root),'canonical_writer':'Root only','source_readback':{'head':head,'previous_commissioned_head':'992c333d3d2d14b4f113a58e5179625a95573aac','authorized_Root_advance':'78e342fc: four V3 paths disjoint from all mechanism and companions; all R5 named inputs and preimages unchanged; Root confirmed','tree':tree,'branch':branch,'tracked_diff_clean':True,'untracked':'preserved'},'R5_parent':{'path':str(R/'manifest.json'),'sha256':sha((R/'manifest.json').read_bytes())},'reviews':reviews,'buckets':{'R5-REVIEW-01':'SECOND SAME P09 class; one generic Exception boundary over complete ordinary process-live target-policy and sealed-dependency operations; one terminal emitter'},'residual':'Cancellation and other BaseException exits, process termination/crash and audit crash durability; generic artifact plane unchanged','files':files,'path_count':len(files),'delta_from_R5_path_count':sum(f['delta_from_r5'] for f in files),'mechanism_path_count':7,'mandatory_companion_path_count':len(files)-7,'source_inputs':readset,'patch':{'path':str(D/'proposal.patch'),'sha256':sha((D/'proposal.patch').read_bytes()),'bytes':(D/'proposal.patch').stat().st_size},'delta_patch':{'path':str(D/'delta-from-r5.patch'),'sha256':sha((D/'delta-from-r5.patch').read_bytes()),'bytes':(D/'delta-from-r5.patch').stat().st_size},'raw_companions':raw,'audit_protocol':'V1 exact historical wire fields retained; V2 full typed context, request checksum, ordered target outcomes and actual cold-consumer verification. No authenticated history/MAC claim. Cold parse does not establish live availability or policy authority.','generic_artifact_permission_plane':'separate unadjudicated boundary; unchanged','generated_companions':'all original registered families retained/mapped, Root sole generator writer, UNRUN','runtime':'UNRUN','product_test_imports':'NONE','DB_queries':'NONE','canonical_index_ref_writes':'NONE','capability_labels':['verification_missing','artifact_missing (generated outputs only)']}
(D/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
# Read back every delivered postimage and RAW companion from its named location.
for row in files:assert sha(Path(row['postimage_file']).read_bytes())==row['post_sha256']
for row in raw:assert sha(Path(row['path']).read_bytes())==row['sha256']
assert git('rev-parse','HEAD')==head and git('status','--porcelain','--untracked-files=no')==''
print(json.dumps({'manifest_sha256':sha((D/'manifest.json').read_bytes()),'patch':manifest['patch'],'delta_patch':manifest['delta_patch'],'paths':len(files),'delta_paths':manifest['delta_from_R5_path_count'],'source_inputs':len(readset),'runtime':'UNRUN'},indent=2))
