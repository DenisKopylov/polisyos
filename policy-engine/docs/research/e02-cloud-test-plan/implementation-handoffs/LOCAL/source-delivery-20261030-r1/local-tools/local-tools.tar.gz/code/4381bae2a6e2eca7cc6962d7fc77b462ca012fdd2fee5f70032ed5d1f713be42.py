def refine(source):
    def sub(old, new, count=1):
        nonlocal source
        assert source.count(old)==count,(old[:70],source.count(old))
        source=source.replace(old,new)
    sub('            binding.kind == "ambiguous"\n            or _is_guarded_importer_binding(binding)', '            binding.callable_result_unresolved\n            or _is_guarded_importer_binding(binding)')
    sub('    opaque_payload_origins: tuple[str, ...] = ()\n', '    opaque_payload_origins: tuple[str, ...] = ()\n    callable_result_unresolved: bool = False\n')
    sub('''    result = retain_provenance(result)
    if result.guarded''','''    result = retain_provenance(result)
    if result.kind in {"unknown", "ambiguous", "union"} and any(
        item.callable_result_unresolved
        for binding in bindings
        for item in _dynamic_binding_nodes(binding)
    ):
        result = replace(result, callable_result_unresolved=True)
    if result.guarded''')
    sub('''    def _reject_guarded_escape(
''','''    def _unmodeled_operator_result(
        self, node: ast.AST, operands: Sequence[_DynamicImportBinding]
    ) -> _DynamicImportBinding:
        """Refuse implicit opaque dispatch during protected body transfer."""
        if self._source_code_depth:
            raise DynamicImportCollectionError(
                f"{self.relative_path}:{node.lineno}: reconstructed source invocation "
                "reaches opaque operator dispatch"
            )
        return _dynamic_join_with_guarded_origin(
            operands, replace(_DYNAMIC_AMBIGUOUS, callable_result_unresolved=True)
        )

    def _reject_guarded_escape(
''')
    sub('return _dynamic_join_with_guarded_origin((operand,), _DYNAMIC_AMBIGUOUS)', 'return self._unmodeled_operator_result(node, (operand,))')
    sub('return _dynamic_join_with_guarded_origin(operands, _DYNAMIC_AMBIGUOUS)', 'return self._unmodeled_operator_result(node, operands)', count=2)
    return source

def normalize_canonical_children(source):
    def sub(old,new):
        nonlocal source
        assert source.count(old)==1,(old[:65],source.count(old))
        source=source.replace(old,new)
    sub('''        pending = [getattr(self, field.name) for field in dataclass_fields(self)]
''','''        pending = [
            getattr(self, field.name)
            for field in dataclass_fields(self)
            if field.name != "receiver" or self.kind == "callable"
        ]
''')
    sub('''                pending.extend(getattr(value, field.name) for field in dataclass_fields(value))
''','''                # Immutable children are canonical by their own construction. Their
                # aggregate origins are the induction step; rewalking dependency graphs
                # would confuse an analysis receiver with a runtime payload and cost O(n²).
''')
    sub('''    execution_origins = {
        origin
        for binding in bindings
        for current in _dynamic_binding_nodes(binding)
        for origin in current.source_execution_origins
    }
''','''    execution_origins = {
        origin for binding in bindings for origin in binding.source_execution_origins
    }
''')
    sub('''        f"{current.code_origin.context_identity}:{current.code_origin.identity}"
        if current.code_origin is not None
        else current.kind
        for binding in bindings
        for current in _dynamic_binding_nodes(binding)
        if current.kind
''','''        f"{binding.code_origin.context_identity}:{binding.code_origin.identity}"
        if binding.code_origin is not None
        else binding.kind
        for binding in bindings
        if binding.kind
''')
    sub('''    return any(
        item.source_execution_origins
        or item.opaque_payload_origins
        or item.kind in {"source_method", "source_code", "reconstructed_function", "source_closure"}
        for item in _dynamic_binding_nodes(binding)
    )
''','''    return bool(
        binding.source_execution_origins
        or binding.opaque_payload_origins
        or binding.kind in {"source_method", "source_code", "reconstructed_function", "source_closure"}
    )
''')
    return source

def normalize_call_intake(source):
    old='''        if any(binding.opaque_payload_origins for binding in argument_bindings):
'''
    new='''        if any(
            binding.opaque_payload_origins for binding in (*argument_bindings, *function_bindings)
        ):
'''
    assert source.count(old)==1;source=source.replace(old,new)
    old='''            for binding in argument_bindings:
                for item in _dynamic_binding_nodes(binding):
'''
    new='''            for binding in call_values:
                for item in _dynamic_binding_nodes(binding):
'''
    assert source.count(old)==1;return source.replace(old,new)
