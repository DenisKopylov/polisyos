from pathlib import Path
import subprocess,hashlib,json,ast,difflib,tomllib
ROOT=Path.cwd();OUT=ROOT/'LOCAL/raw/e02-execution-20261027/repairs/C38-r4'
BASE='caa91a64d7d6afc4310186ba5fadbac2008dddab'
R3=ROOT/'LOCAL/raw/e02-execution-20261027/repairs/C38-r3'
T1=ROOT/'LOCAL/raw/e02-execution-20261027/repairs/C38-tests-r1'
assert hashlib.sha256((R3/'manifest.json').read_bytes()).hexdigest()=='4a40acfb3151e532d71b23cd87557dd76932d0f4992dbedc3b07425ac7d6af16'
assert hashlib.sha256((T1/'manifest.json').read_bytes()).hexdigest()=='a1b6670fb98ca09e67f15f334f356b70ac9d5a68a5466aff815018862e783dcf'
python=str(ROOT/'policy-engine/.venv/bin/python');paths=sorted(str(p.relative_to(OUT/'postimages')) for p in (OUT/'postimages').rglob('*') if p.is_file())
entries=[];checks=[];patch=[];delta=[]
for path in paths:
 f=OUT/'postimages'/path
 if path.endswith('.py'):
  lint=subprocess.run([python,'-m','ruff','check','--fix','--stdin-filename',str(ROOT/path),'-'],input=f.read_bytes(),capture_output=True,cwd=ROOT/'policy-engine')
  if lint.stdout:f.write_bytes(lint.stdout)
  if not path.startswith('policy-engine/src/'):
   fmt=subprocess.run([python,'-m','ruff','format','--stdin-filename',str(ROOT/path),'-'],input=f.read_bytes(),capture_output=True,cwd=ROOT/'policy-engine')
   if fmt.returncode==0:f.write_bytes(fmt.stdout)
  ast.parse(f.read_bytes(),filename=path)
  lint=subprocess.run([python,'-m','ruff','check','--stdin-filename',str(ROOT/path),'-'],input=f.read_bytes(),capture_output=True,cwd=ROOT/'policy-engine')
  token=path.replace('/','__')
  (OUT/f'ruff-{token}.stdout').write_bytes(lint.stdout);(OUT/f'ruff-{token}.stderr').write_bytes(lint.stderr)
  checks.append({'path':path,'exit_code':lint.returncode,'stdout':f'ruff-{token}.stdout','stderr':f'ruff-{token}.stderr'})
 elif path.endswith('.json'):json.loads(f.read_text())
 elif path.endswith('.toml'):tomllib.loads(f.read_text())
 post=f.read_bytes();base=subprocess.run(['git','show',f'{BASE}:{path}'],capture_output=True);pre=base.stdout if base.returncode==0 else b''
 frozen=R3/'postimages'/path
 if not frozen.is_file():frozen=T1/'postimages'/path
 old=frozen.read_bytes() if frozen.is_file() else pre
 oldexists=frozen.is_file() or base.returncode==0
 patch.append(''.join(difflib.unified_diff(pre.decode().splitlines(True),post.decode().splitlines(True),fromfile=f'a/{path}' if base.returncode==0 else '/dev/null',tofile=f'b/{path}')))
 delta.append(''.join(difflib.unified_diff(old.decode().splitlines(True),post.decode().splitlines(True),fromfile=f'a/{path}' if oldexists else '/dev/null',tofile=f'b/{path}')))
 entries.append({'path':path,'postimage_file':str(f.relative_to(OUT)),'new_file':base.returncode!=0,'base_sha256':hashlib.sha256(pre).hexdigest() if base.returncode==0 else None,'base_bytes':len(pre) if base.returncode==0 else None,'r3_plus_tests1_sha256':hashlib.sha256(old).hexdigest() if oldexists else None,'postimage_sha256':hashlib.sha256(post).hexdigest(),'postimage_bytes':len(post)})
(OUT/'cumulative.patch').write_text(''.join(patch));(OUT/'r3-plus-tests1-to-r4.patch').write_text(''.join(delta))
app=subprocess.run(['git','apply','--check',str(OUT/'cumulative.patch')],capture_output=True)
(OUT/'apply-check.stdout').write_bytes(app.stdout);(OUT/'apply-check.stderr').write_bytes(app.stderr)
manifest={'schema':'policyos.c38_coherent_r4_proposal.v1','base_commit':BASE,'source_r3_manifest_sha256':'4a40acfb3151e532d71b23cd87557dd76932d0f4992dbedc3b07425ac7d6af16','tests_r1_manifest_sha256':'a1b6670fb98ca09e67f15f334f356b70ac9d5a68a5466aff815018862e783dcf','source_r3_review_sha256':'3498117af23f1975db414d101c9162296b12b2bc07699f8270bee54286ad11d5','tests_r1_review_sha256':'cf3f68d229b6ab0cefcd04d969b195655606f8cd64628404cc339c67c21ee02d','root_cache_disposition':'Preserve existing isolated_non_authorizing_verification cache fence via explicit declared-basis-only purpose; no new purpose authority issuer or GY/B198 reopening.','files':entries,'patch_sha256':hashlib.sha256((OUT/'cumulative.patch').read_bytes()).hexdigest(),'delta_patch_sha256':hashlib.sha256((OUT/'r3-plus-tests1-to-r4.patch').read_bytes()).hexdigest(),'verification':{'ast_json_toml':'PASS','ruff':checks,'apply_check_exit':app.returncode,'runtime':'UNRUN'},'canonical_source_index_refs_written':False}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'files':len(entries),'ruff_failures':[x['path'] for x in checks if x['exit_code']],'apply':app.returncode,'manifest_sha256':hashlib.sha256((OUT/'manifest.json').read_bytes()).hexdigest()}))
