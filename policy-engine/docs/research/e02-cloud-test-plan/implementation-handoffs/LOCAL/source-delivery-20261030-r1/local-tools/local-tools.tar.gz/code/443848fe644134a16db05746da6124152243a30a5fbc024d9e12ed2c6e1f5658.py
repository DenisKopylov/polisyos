"""Create sparse RAW postimages for an unverified source-refusal hypothesis."""
from __future__ import annotations

import ast
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
OUT = Path(__file__).resolve().parent
REVISIONS = {
    'policy-engine/src/polisyos/runtime/quality/generation_cycle.py':'62a5b6e94c7cee7ffee95516d0580a1d642d2ca1ff4e297aa64b53b7550068e8',
    'policy-engine/tests/unit/runtime/quality/test_generation_cycle.py':'e809f4fadd981b53a9cd8dbda4e29e407a9ee20b1941202323c98ae639e26483',
    'policy-engine/src/polisyos/runtime/quality/README.md':'e0b54a1ceacf3a2f131361954d8d89199324f10283d7901e6359fb0001c9aad7',
}


def replace_one(text: str, old: str, new: str) -> str:
    assert text.count(old) == 1, 'expected one source site'
    return text.replace(old, new, 1)


def source(relative: str) -> str:
    data = (ROOT / relative).read_bytes()
    assert hashlib.sha256(data).hexdigest() == REVISIONS[relative], relative
    return data.decode()


def save(relative: str, text: str) -> None:
    path = OUT / 'postimages' / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    if path.suffix == '.py':
        ast.parse(text, filename=relative)


mechanism = next(key for key in REVISIONS if key.endswith('/generation_cycle.py'))
text = source(mechanism)
text = replace_one(text,
    '        if source_gap is not None and not request_binding_refused:\n            routed_compiler_gaps, routing_limitation_code = _n7_route_compiler_gaps(\n',
    '        if (\n            source_gap is not None\n            and not request_binding_refused\n            and routing_limitation_code is None\n        ):\n            # A source/request refusal is final for this route. A later empty\n            # compiler match must not overwrite the earlier, specific reason.\n            routed_compiler_gaps, routing_limitation_code = _n7_route_compiler_gaps(\n')
save(mechanism,text)

test = next(key for key in REVISIONS if key.endswith('/test_generation_cycle.py'))
text = source(test)
start=text.index('async def test_n7_typed_gap_persists_costed_plan_before_authority_refusal(')
end=text.index('\n\n@pytest.mark.asyncio\nasync def test_conflicting_n7_family_declaration_is_costed_refusal(',start)
block=text[start:end]
block=replace_one(block,'        generation_port=_CgfGenerationPort(),\n        value_port=_DataGapValuePort(),\n',
                  '        generation_port=_CgfGenerationPort(target_world_slots=("administrative_tax_receipts",)),\n        value_port=_CostedDataGapValuePort(),\n')
block=replace_one(block,'    assert cycle.acquisition_cost_basis_record.missing_distribution == "firm_survival"\n',
                  '    assert cycle.acquisition_cost_basis_record.missing_distribution == "administrative_tax_receipts"\n'
                  '    assert cycle.acquisition_cost_basis_record.schedule_content_hash == (\n'
                  '        "sha256:258c2dd22214b8a3bf9157cb6ad186b6320317b526d2f951098bd72ead9328d3"\n'
                  '    )\n'
                  '    assert cycle.acquisition_cost_basis_record.total_amount == 1255.0\n')
text=text[:start]+block+text[end:]
insert='''\n\n@pytest.mark.asyncio\nasync def test_n7_unscheduled_source_gap_stays_uncosted_candidate(\n    tmp_path: Path,\n    n7_complete_catalog_source: tuple[Path, Any],\n) -> None:\n    """The prior source remains a candidate gap but cannot invent a schedule row."""\n    from polisyos.runtime.quality.acquisition_planner import load_acquisition_planner_report\n\n    source_root, catalog_source = n7_complete_catalog_source\n    controller = GenerationCycleController(\n        generation_port=_CgfGenerationPort(),\n        value_port=_DataGapValuePort(),\n        authority_scope="contract_testing",\n        repo_root=source_root,\n        catalog_serving_source=catalog_source,\n        artifact_store=FileSystemCAS(tmp_path / ".tmp/n6-generation-source-cas"),\n    )\n    run = await controller.run(_problem(), budget_state=_budget(), max_cycles=1)\n    cycle = run.cycles[0]\n    assert cycle.acquisition_routing_report_ref is not None\n    assert cycle.acquisition_routing_report is not None\n    assert cycle.acquisition_cost_basis_record is None\n    assert cycle.acquisition_receipt is None\n    assert controller._source_repository is not None\n    fresh = FileSystemCAS.open_existing_read_only(tmp_path / ".tmp/n6-generation-source-cas")\n    report = load_acquisition_planner_report(fresh, cycle.acquisition_routing_report_ref)\n    assert report == cycle.acquisition_routing_report\n    assert report.requirement_basis_binding is not None\n    assert report.requirement_basis_binding.resolution.basis_grade == "consumer_asserted"\n    assert report.status == "warn"\n    assert report.basis_limitation_code == "consumer_declared_basis_candidate_only"\n    source_gap = generation_cycle_module._cycle_acquisition_requirement(\n        cycle.grounding, cycle.value_port\n    )\n    assert source_gap is not None\n    assert generation_cycle_module._requirement_missing_distributions(source_gap) == (\n        "firm_survival",\n    )\n    assert len(report.acquisition_records) == 1\n    assert source_gap.requirement_gap_id in report.acquisition_records[0].scenario_requirement_refs\n'''
anchor='\n\n@pytest.mark.asyncio\nasync def test_conflicting_n7_family_declaration_is_costed_refusal('
assert text.count(anchor)==1
text=text.replace(anchor,insert+anchor,1)
start=text.index('async def test_conflicting_n7_family_declaration_is_costed_refusal(')
end=text.index('\n\n@pytest.mark.asyncio\n@_requires_owner_catalog',start)
block=text[start:end]
block=replace_one(block,') -> None:\n    class _ConflictingFamilyRevision:',
                  ') -> None:\n    from polisyos.runtime.quality.acquisition_planner import load_acquisition_planner_report\n\n    class _ConflictingFamilyRevision:')
block=replace_one(block,'    run = await controller.run(_problem(), budget_state=_budget(), max_cycles=1)\n',
                  '    problem = _problem()\n    run = await controller.run(problem, budget_state=_budget(), max_cycles=1)\n')
block=replace_one(block,'    assert cycle.acquisition_cost_basis_record is None\n', '''    request = cycle.revision_request.strategy_payload["acquisition_request"]
    assert request["required_data_families"] == ("other_panel",)
    source_gap, source_error = generation_cycle_module._n7_cycle_source_gap(
        problem, cycle=cycle, acquisition_request=request
    )
    assert source_gap is not None
    assert source_error is None
    families, family_error = generation_cycle_module._n7_compiler_families_for_source_gap(
        problem, acquisition_request=request, source_gap=source_gap
    )
    assert families == ()
    assert family_error == "unbound_requirement_input_refused"
    basis = controller._n7_data_requirement_basis_with_report(
        problem, acquisition_request=request, cycle=cycle
    )
    assert basis.unbound_input_fields == ()
    assert basis.compilation_report.requirement_basis.basis_grade == "not_established"
    assert basis.specs == ()
    assert basis.routed_compiler_gaps == ()
    assert basis.routing_limitation_code == "unbound_requirement_input_refused"
    assert cycle.acquisition_cost_basis_record is None
''')
block=replace_one(block,'    assert cycle.acquisition_routing_report.acquisition_records == ()\n', '''    assert cycle.acquisition_routing_report.acquisition_records == ()
    assert cycle.acquisition_routing_report_ref is not None
    fresh = FileSystemCAS.open_existing_read_only(tmp_path / ".tmp/n6-generation-source-cas")
    assert load_acquisition_planner_report(fresh, cycle.acquisition_routing_report_ref) == (
        cycle.acquisition_routing_report
    )
''')
text=text[:start]+block+text[end:]
save(test,text)

doc=next(key for key in REVISIONS if key.endswith('/README.md'))
text=source(doc)
old='cycle consistency check; the checkpoint reference\'s custody is checked by the\nlater dispatcher. It does not independently establish the producer or semantic\nadmissibility of a profile already present in that revision.\n'
new=old+'An already detected source or family binding refusal is retained as the route\nreason; a subsequent empty compiler match cannot replace it. The route remains\nblocked and unestimated, and the compiler basis keeps its actual grade.\n'
save(doc,replace_one(text,old,new))
frag='policy-engine/release-fragments/unreleased/2026-10-30-e02-n7-source-refusal-reason.toml'
assert not (ROOT/frag).exists()
save(frag,'''id = "2026-10-30-e02-n7-source-refusal-reason"\ntitle = "Preserve N7 source binding refusal reasons"\ntype = "fixed"\ncomponent = "runtime"\nowner = "team-polisyos"\nsummary = "Keep a detected source-family conflict when compiler routing finds no matching requirement."\nevidence = ["tests/unit/runtime/quality/test_generation_cycle.py"]\ncompatibility = "Blocked, unestimated outcomes retain the more specific source binding refusal; no candidate is promoted."\nchange_class = "internal"\nsurface_classification = "internal"\ngenerated_client_compatibility = "not_applicable"\npublic_surface_inventory_reviewed = false\nmigration_docs = ["src/polisyos/runtime/quality/README.md"]\nrunbook_docs = []\n''')
paths=(*REVISIONS,frag)
diff=[]
manifest={}
for path in paths:
    old=(ROOT/path).read_text() if (ROOT/path).exists() else ''
    new=(OUT/'postimages'/path).read_text()
    diff.extend(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path))
    manifest[path]={'preimage_sha256':hashlib.sha256(old.encode()).hexdigest() if old else None,'postimage_sha256':hashlib.sha256(new.encode()).hexdigest()}
(OUT/'proposal.patch').write_text(''.join(diff))
(OUT/'postimage-manifest.json').write_text(json.dumps({'status':'source-level hypothesis, native UNRUN; R171 runtime boundary observation still required','head':'0cf2132d0218864240d4a888ee534948e150b90f','tree':'8069d34f78fd28f0d998ab66d4c7e1948c07c982','files':manifest},indent=2)+'\n')
print(json.dumps({'paths':len(paths),'diff_lines':len(diff),'manifest':manifest},indent=2))
