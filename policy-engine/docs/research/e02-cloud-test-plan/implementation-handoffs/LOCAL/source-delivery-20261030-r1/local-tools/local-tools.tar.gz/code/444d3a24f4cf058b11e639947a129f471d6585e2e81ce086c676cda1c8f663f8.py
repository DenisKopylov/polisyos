from pathlib import Path
import shutil,subprocess
ROOT=Path.cwd(); OUT=ROOT/'LOCAL/raw/e02-execution-20261027/repairs/C38-r4'
for packet in ['C38-r3','C38-tests-r1']:
 for p in (ROOT/'LOCAL/raw/e02-execution-20261027/repairs'/packet/'postimages').rglob('*'):
  if p.is_file():
   dest=OUT/'postimages'/p.relative_to(ROOT/'LOCAL/raw/e02-execution-20261027/repairs'/packet/'postimages')
   dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes())
for p in ['policy-engine/tools/quality/validation/layer3_gy_confidence_ledger_contract.py','policy-engine/tools/quality/validation/check_layer3_gy_confidence_ledger.py','policy-engine/tests/repo_quality/tools/test_layer3_gy_confidence_ledger_contract.py']:
 dest=OUT/'postimages'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(subprocess.check_output(['git','show',f'caa91a64d7d6afc4310186ba5fadbac2008dddab:{p}']))
p=OUT/'postimages/policy-engine/src/polisyos/runtime/quality/authority.py';s=p.read_text()
s=s.replace('from typing import TYPE_CHECKING, Any, Final, Literal, Protocol, cast','from typing import TYPE_CHECKING, Any, Final, Literal, Protocol, cast, overload',1)
needle='class SealedConsumedInputSet(BaseModel):\n'
insert='''ConsumedInputSealPurpose = Literal["authority", "declared_basis_cache_equality"]


class DeclaredBasisCacheSeal(BaseModel):
    """Content-bound equality of declared cache members, never authority admission.

    This type makes no claim that the member denominator is complete for any
    producer or purpose. It cannot satisfy protected sealing/reuse, envelope
    roles, purpose checks or public authority surfaces.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    schema_version: Literal["policyos.runtime.declared_basis_cache_seal.v1"] = (
        "policyos.runtime.declared_basis_cache_seal.v1"
    )
    purpose: Literal["declared_basis_cache_equality"] = "declared_basis_cache_equality"
    authority_role: Literal["diagnostic_only"] = "diagnostic_only"
    basis_scope: Literal["declared_members_only"] = "declared_members_only"
    purpose_completeness_basis: Literal["not_established"] = "not_established"
    same_input_closure: SameInputClosure
    members: tuple[ConsumedInputMember, ...]
    membership_sha256: str = Field(pattern=r"^sha256:[0-9a-f]{64}$")

    @model_validator(mode="after")
    def _validate_declared_equality(self) -> DeclaredBasisCacheSeal:
        """Recompute only the declared membership snapshot's mechanical identity."""
        members = _normalise_consumed_input_members(self.members)
        if members != self.members:
            raise ValueError("declared_basis_cache_members_not_sorted")
        if self.membership_sha256 != _declared_basis_cache_membership_sha256(
            self.same_input_closure, members
        ):
            raise ValueError("declared_basis_cache_membership_mismatch")
        return self


'''
assert needle in s;s=s.replace(needle,insert+needle,1)
start=s.index('def seal_consumed_input_set(');end=s.index('\ndef _normalise_consumed_input_members(',start)
replacement='''@overload
def seal_consumed_input_set(
    *,
    closure: SameInputClosure,
    members: Iterable[ConsumedInputMember | Mapping[str, Any]],
    verified_closure: VerifiedSameInputClosure | None = None,
    purpose: Literal["authority"] = "authority",
) -> SealedConsumedInputSet: ...


@overload
def seal_consumed_input_set(
    *,
    closure: SameInputClosure,
    members: Iterable[ConsumedInputMember | Mapping[str, Any]],
    verified_closure: VerifiedSameInputClosure | None = None,
    purpose: Literal["declared_basis_cache_equality"],
) -> DeclaredBasisCacheSeal: ...


def seal_consumed_input_set(
    *,
    closure: SameInputClosure,
    members: Iterable[ConsumedInputMember | Mapping[str, Any]],
    verified_closure: VerifiedSameInputClosure | None = None,
    purpose: ConsumedInputSealPurpose = "authority",
) -> SealedConsumedInputSet | DeclaredBasisCacheSeal:
    """Seal admitted authority, or explicitly compare a non-authorizing cache basis.

    The default remains protected and refuses unverified closure input. The
    explicit cache purpose returns a distinct diagnostic type and proves only
    equality of the declared members, not complete producer/purpose admission.
    """
    if purpose == "declared_basis_cache_equality":
        resolved_members = _normalise_consumed_input_members(members)
        return DeclaredBasisCacheSeal(
            same_input_closure=closure,
            members=resolved_members,
            membership_sha256=_declared_basis_cache_membership_sha256(closure, resolved_members),
        )
    if purpose != "authority":
        raise AuthorityEnvelopeError("consumed_input_seal_purpose_unknown")
    _assert_closed_consumed_input_closure(closure, verified_closure=verified_closure)
    resolved_members = _normalise_consumed_input_members(members)
    membership_sha256 = _consumed_input_membership_sha256(closure, resolved_members)
    return SealedConsumedInputSet(
        same_input_closure=closure,
        members=resolved_members,
        membership_sha256=membership_sha256,
    )


@overload
def assert_consumed_input_reuse(
    sealed: SealedConsumedInputSet,
    *,
    closure: SameInputClosure,
    fresh_members: Iterable[ConsumedInputMember | Mapping[str, Any]],
    verified_closure: VerifiedSameInputClosure | None = None,
    purpose: Literal["authority"] = "authority",
) -> SealedConsumedInputSet: ...


@overload
def assert_consumed_input_reuse(
    sealed: DeclaredBasisCacheSeal,
    *,
    closure: SameInputClosure,
    fresh_members: Iterable[ConsumedInputMember | Mapping[str, Any]],
    verified_closure: VerifiedSameInputClosure | None = None,
    purpose: Literal["declared_basis_cache_equality"],
) -> DeclaredBasisCacheSeal: ...


def assert_consumed_input_reuse(
    sealed: SealedConsumedInputSet | DeclaredBasisCacheSeal,
    *,
    closure: SameInputClosure,
    fresh_members: Iterable[ConsumedInputMember | Mapping[str, Any]],
    verified_closure: VerifiedSameInputClosure | None = None,
    purpose: ConsumedInputSealPurpose = "authority",
) -> SealedConsumedInputSet | DeclaredBasisCacheSeal:
    """Recheck protected admission, or explicit declared-basis cache equality only."""
    if purpose == "declared_basis_cache_equality":
        if type(sealed) is not DeclaredBasisCacheSeal:
            raise AuthorityEnvelopeError("declared_basis_cache_seal_required")
        try:
            sealed = DeclaredBasisCacheSeal.model_validate_json(sealed.model_dump_json())
        except (TypeError, ValueError) as exc:
            raise AuthorityEnvelopeError("declared_basis_cache_seal_invalid") from exc
        # Bind the entire declared closure record here, including any v2 members.
        if closure.model_dump(mode="json") != sealed.same_input_closure.model_dump(mode="json"):
            raise AuthorityEnvelopeError("consumed_input_closure_mismatch")
    elif purpose == "authority":
        if type(sealed) is not SealedConsumedInputSet:
            raise AuthorityEnvelopeError("declared_basis_cache_seal_not_authoritative")
        _assert_closed_consumed_input_closure(closure, verified_closure=verified_closure)
        if closure.identity_tuple() != sealed.same_input_closure.identity_tuple():
            raise AuthorityEnvelopeError(
                "consumed_input_closure_mismatch", f"closure_id={closure.closure_id}"
            )
    else:
        raise AuthorityEnvelopeError("consumed_input_seal_purpose_unknown")
    resolved_members = _normalise_consumed_input_members(fresh_members)
    expected_by_key = {member.membership_key(): member for member in sealed.members}
    actual_by_key = {member.membership_key(): member for member in resolved_members}
    for key in sorted(expected_by_key.keys() - actual_by_key.keys()):
        _raise_consumed_input_error("consumed_input_member_missing", key)
    for key in sorted(actual_by_key.keys() - expected_by_key.keys()):
        _raise_consumed_input_error("consumed_input_member_extra", key)
    for key in sorted(expected_by_key):
        if actual_by_key[key] != expected_by_key[key]:
            _raise_consumed_input_error("consumed_input_member_substituted", key)
    actual_sha256 = (
        _declared_basis_cache_membership_sha256(closure, resolved_members)
        if purpose == "declared_basis_cache_equality"
        else _consumed_input_membership_sha256(closure, resolved_members)
    )
    if actual_sha256 != sealed.membership_sha256:
        raise AuthorityEnvelopeError(
            "consumed_input_membership_mismatch",
            f"expected={sealed.membership_sha256} actual={actual_sha256}",
        )
    return sealed

'''
s=s[:start]+replacement+s[end:]
needle='def _consumed_input_membership_sha256(\n'
helper='''def _declared_basis_cache_membership_sha256(
    closure: SameInputClosure,
    members: tuple[ConsumedInputMember, ...],
) -> str:
    """Hash a fully declared cache record without inferring producer completeness."""
    spec = canon.CanonSpec(exclude_none=False)
    return "sha256:" + hashlib.sha256(canon.to_canonical_bytes(
        {
            "domain": "polisyos.runtime.declared_basis_cache_equality",
            "schema_version": "1.0",
            "canonical_spec": core_artifacts.CanonInfo.from_spec(spec).model_dump(mode="json"),
            "same_input_closure": closure.model_dump(mode="json"),
            "members": [member.model_dump(mode="json") for member in members],
        },
        spec,
    )).hexdigest()


'''
assert needle in s;s=s.replace(needle,helper+needle,1)
s=s.replace('    "ConsumedInputMemberKind",\n','    "ConsumedInputMemberKind",\n    "ConsumedInputSealPurpose",\n    "DeclaredBasisCacheSeal",\n',1)
p.write_text(s)
# Only existing non-authorizing tool cache consumer changes its explicit purpose.
for relative in ['policy-engine/tools/quality/validation/layer3_gy_confidence_ledger_contract.py','policy-engine/tools/quality/validation/check_layer3_gy_confidence_ledger.py']:
 p=OUT/'postimages'/relative;s=p.read_text().replace('SealedConsumedInputSet','DeclaredBasisCacheSeal')
 if relative.endswith('layer3_gy_confidence_ledger_contract.py'):
  s=s.replace('''                    fresh_members=post_derivation_inputs.members,
''','''                    fresh_members=post_derivation_inputs.members,
                    purpose="declared_basis_cache_equality",
''',1)
  s=s.replace('    """Resolve and seal every input class consumed by the N11 owner graph."""','    """Resolve declared cache-fence members without claiming complete purpose authority."""',1)
  s=s.replace('return seal_consumed_input_set(closure=closure, members=members)','return seal_consumed_input_set(\n            closure=closure, members=members, purpose="declared_basis_cache_equality"\n        )',1)
 p.write_text(s)
p=OUT/'postimages/policy-engine/tests/repo_quality/tools/test_layer3_gy_confidence_ledger_contract.py';s=p.read_text()
s=s.replace(''') -> object:
    from polisyos.runtime.quality.authority import (
        ConsumedInputMember,
        SameInputClosure,
        seal_consumed_input_set,
''',''') -> object:
    """Create only a declared-basis cache fixture, never purpose-authority admission."""
    from polisyos.runtime.quality.authority import (
        ConsumedInputMember,
        SameInputClosure,
        seal_consumed_input_set,
''',1)
needle='''    return seal_consumed_input_set(
        closure=closure,
        members=(
'''
assert needle in s;s=s.replace(needle,'''    return seal_consumed_input_set(
        closure=closure,
        purpose="declared_basis_cache_equality",
        members=(
''',1)
p.write_text(s)
print('Prepared r4 explicit non-authorizing cache purpose; old r3/tests-r1 untouched.')
