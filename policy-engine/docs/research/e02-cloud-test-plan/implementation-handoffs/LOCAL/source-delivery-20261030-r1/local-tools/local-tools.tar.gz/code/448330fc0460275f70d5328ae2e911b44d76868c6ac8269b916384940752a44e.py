"""Source-text checks for this RAW proposal; never import or execute product/tests."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import subprocess
import tomllib

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
OUT = Path(__file__).parent
POSTS = {str(p.relative_to(OUT / 'postimages')): p.read_bytes()
         for p in (OUT / 'postimages').rglob('*') if p.is_file()}


def function(tree, name):
    return next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == name)


files = []
patch = []
for relative, post in sorted(POSTS.items()):
    path = ROOT / relative
    pre = path.read_bytes() if path.exists() else None
    if pre is not None:
        assert pre == subprocess.check_output(['git', 'show', 'HEAD:' + relative], cwd=ROOT)
        assert pre == subprocess.check_output(['git', 'show', ':' + relative], cwd=ROOT)
    else:
        assert not path.is_symlink()
    files.append({'path': relative, 'pre_sha256': hashlib.sha256(pre).hexdigest() if pre else None,
                  'post_sha256': hashlib.sha256(post).hexdigest(), 'post_bytes': len(post),
                  'postimage_file': str((OUT / 'postimages' / relative).relative_to(ROOT))})
    patch.extend(difflib.unified_diff((pre or b'').decode().splitlines(keepends=True),
                                    post.decode().splitlines(keepends=True),
                                    fromfile='a/' + relative if pre is not None else '/dev/null',
                                    tofile='b/' + relative))
    if relative.endswith('.py'):
        compile(post, str(OUT / 'postimages' / relative), 'exec')
    if relative.endswith('.toml'):
        tomllib.loads(post.decode())
(OUT / 'proposal.patch').write_text(''.join(patch))
result = subprocess.run(['git', 'apply', '--check', str(OUT / 'proposal.patch')], cwd=ROOT,
                        capture_output=True, text=True)
assert result.returncode == 0, result.stderr
paths = [p for p in subprocess.check_output(
    ['git', 'ls-tree', '-r', '--name-only', 'HEAD', '--', 'policy-engine/src', 'policy-engine/tests'],
    cwd=ROOT, text=True).splitlines() if p.endswith('.py')]
assert len(paths) == len(set(paths))
needles = ('test_post_worker_fenced_cas_and_fresh_run_get_preserve_candidate_limits',
           '_GET_RUN_METHOD_METRICS_AUTHZ', 'runtime.run.method_metrics',
           '_resolve_bound_method_metric_indexed_run')
hits = {key: [] for key in needles}
for path in paths:
    source = POSTS[path] if path in POSTS else (ROOT / path).read_bytes()
    for needle in needles:
        for number, line in enumerate(source.decode().splitlines(), 1):
            if needle in line:
                hits[needle].append({'path': path, 'line': number, 'text': line.strip()})
routes = 'policy-engine/src/polisyos/runtime/http/routes/runs.py'
family = []
for node in ast.walk(ast.parse(POSTS[routes])):
    if not isinstance(node, ast.FunctionDef):
        continue
    for decorator in node.decorator_list:
        if not (isinstance(decorator, ast.Call) and isinstance(decorator.func, ast.Attribute)
                and decorator.func.attr == 'get'):
            continue
        dependencies = [value for keyword in decorator.keywords
                        if keyword.arg == 'dependencies' and isinstance(keyword.value, ast.List)
                        for value in keyword.value.elts
                        if isinstance(value, ast.Call) and isinstance(value.func, ast.Name)
                        and value.func.id == 'Depends' and value.args
                        and isinstance(value.args[0], ast.Name)
                        and value.args[0].id == '_GET_RUN_METHOD_METRICS_AUTHZ']
        if dependencies:
            calls = [item for item in ast.walk(node) if isinstance(item, ast.Call)
                     and isinstance(item.func, ast.Name)
                     and item.func.id == '_resolve_bound_method_metric_indexed_run']
            family.append({'function': node.name, 'path_template': decorator.args[0].value,
                           'line': node.lineno, 'strict_context_calls': len(calls)})
assert len(family) == 2 and all(item['strict_context_calls'] == 2 for item in family)
rb = 'policy-engine/src/polisyos/runtime/http/resource_binding.py'
old_rb, new_rb = ast.parse((ROOT / rb).read_bytes()), ast.parse(POSTS[rb])
assert ast.dump(function(old_rb, '_resolve_method_execution_indexed_run')) == ast.dump(
    function(new_rb, '_resolve_method_execution_indexed_run'))
core = 'policy-engine/tests/unit/runtime/http/test_method_candidate_evidence_roundtrip.py'
old_core, new_core = ast.parse((ROOT / core).read_bytes()), ast.parse(POSTS[core])
test_names = [n.name for n in old_core.body if isinstance(n, ast.FunctionDef)
              and n.name.startswith('test_')]
assert len(test_names) == 6
assert all(ast.dump(function(old_core, name)) == ast.dump(function(new_core, name))
           for name in test_names[:-1])

def assertions(node):
    return [ast.dump(item) for item in sorted(
        (item for item in ast.walk(node) if isinstance(item, ast.Assert)),
        key=lambda item: (item.lineno, item.col_offset))]

assert assertions(function(old_core, test_names[-1])) == assertions(
    function(new_core, test_names[-1]))
obs = 'policy-engine/tests/unit/runtime/http/test_observational_method_runtime.py'
old_obs, new_obs = ast.parse((ROOT / obs).read_bytes()), ast.parse(POSTS[obs])
name = 'test_post_worker_fenced_cas_and_fresh_run_get_preserve_candidate_limits'
old_function, new_function = function(old_obs, name), function(new_obs, name)
post_assertions = iter(assertions(new_function))
assert all(any(current == expected for current in post_assertions)
           for expected in assertions(old_function))
assert [ast.dump(d) for d in old_function.decorator_list] == [
    ast.dump(d) for d in new_function.decorator_list]
checks = {'scope': 'static source checks only; no product/test imports or execution',
          'in_memory_python_compile': 'PASS', 'release_TOML_parse': 'PASS',
          'git_apply_check': {'argv': result.args, 'returncode': result.returncode,
                              'stdout': result.stdout, 'stderr': result.stderr},
          'strict_existing_alias_resolver_AST_unchanged': True,
          'first_five_Core_tests_AST_unchanged': test_names[:-1],
          'Core_public_wrapper_assertions_AST_unchanged': True,
          'original_public_oracle_assertions_retained_as_ordered_subsequence': True,
          'original_public_oracle_parametrization_AST_unchanged': True,
          'complete_metric_family': family, 'new_runtime_controls': 'UNRUN',
          'physical_retry_transition': 'UNRUN; stale-bound-context counterexample is synthetic',
          'preimages_HEAD_index_physical_equal': True}
(OUT / 'static-checks.json').write_text(json.dumps(checks, indent=2) + '\n')
(OUT / 'consumer-denominator.json').write_text(json.dumps({
    'scope': 'complete tracked HEAD src/tests Python with exact proposal overlay; excludes RAW and external packages',
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'path_roots': ['policy-engine/src', 'policy-engine/tests'], 'file_type': '.py',
    'complete_file_count': len(paths), 'current_metric_family_from_routes_AST': family,
    'all_textual_occurrences_in_complete_denominator': hits}, indent=2) + '\n')
print(json.dumps({'candidate_paths': len(files), 'python_denominator': len(paths),
                  'family': family, 'all_static_checks': 'PASS',
                  'proposal_patch_sha256': hashlib.sha256((OUT / 'proposal.patch').read_bytes()).hexdigest()}, indent=2))
