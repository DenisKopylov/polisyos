"""Inspect every source Python file in the exact pinned base plus C05 r7 overlays."""
from __future__ import annotations
import ast, hashlib, json, os, subprocess
from pathlib import Path

ROOT=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
OUT=ROOT/'LOCAL/raw/e02-execution-20261027/repairs/C05-composed-fixture-r7'
BASE='a8bee9746d0ea6c9582648b60944f8a4a27eb31e'
items=[]
for raw in subprocess.check_output(['git','ls-tree','-r','-z',BASE,'--','policy-engine/src'],cwd=ROOT).split(b'\0'):
    if raw:
        info,path=raw.split(b'\t',1); mode,kind,oid=info.split(b' ')
        if path.endswith(b'.py'):
            assert kind==b'blob'
            items.append((os.fsdecode(path),oid.decode()))
cp=subprocess.run(['git','cat-file','--batch'],cwd=ROOT,input=('\n'.join(oid for _,oid in items)+'\n').encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
assert cp.returncode==0,cp.stderr
position=0; sources={}
for path,oid in items:
    end=cp.stdout.index(b'\n',position); header=cp.stdout[position:end].split()
    assert header[0].decode()==oid and header[1]==b'blob'
    size=int(header[2]); position=end+1
    sources[path]=cp.stdout[position:position+size];position+=size
    assert cp.stdout[position:position+1]==b'\n';position+=1
assert position==len(cp.stdout)
for path in (OUT/'policy-engine/src').rglob('*.py'):
    sources[str(path.relative_to(OUT))]=path.read_bytes()
rows=[]; dynamic=[]; syntax=[]; digest_attributes=[]; digest_literals=[]
for path,raw in sorted(sources.items()):
    try: tree=ast.parse(raw,filename=path)
    except SyntaxError as exc:
        syntax.append({'path':path,'error':str(exc)});continue
    text=raw.decode()
    for node in ast.walk(tree):
        if isinstance(node,ast.Attribute) and node.attr=='_request_digest':
            digest_attributes.append({'path':path,'line':node.lineno,'expression':ast.get_source_segment(text,node)})
        if isinstance(node,ast.Constant) and node.value=='_request_digest':
            digest_literals.append({'path':path,'line':node.lineno})
        if isinstance(node,ast.Call):
            if isinstance(node.func,ast.Attribute) and node.func.attr in {'_request_digest','cache_request_identity','prepare_cache_request'}:
                rows.append({'path':path,'line':node.lineno,'method':node.func.attr,'expression':ast.get_source_segment(text,node),'keywords':[keyword.arg for keyword in node.keywords],'source_sha256':hashlib.sha256(raw).hexdigest()})
            if isinstance(node.func,ast.Name) and node.func.id in {'prepare_cached_request','prepare_provider_call'}:
                rows.append({'path':path,'line':node.lineno,'method':node.func.id,'expression':ast.get_source_segment(text,node),'keywords':[keyword.arg for keyword in node.keywords],'source_sha256':hashlib.sha256(raw).hexdigest()})
            if isinstance(node.func,ast.Name) and node.func.id=='getattr' and len(node.args)>1 and isinstance(node.args[1],ast.Constant) and node.args[1].value in {'_request_digest','prepare_cache_request','cache_request_identity'}:
                dynamic.append({'path':path,'line':node.lineno,'expression':ast.get_source_segment(text,node)})
report={'scope':'Complete *.py blobs under policy-engine/src in pinned base, plus all r7 source overlays. Bounded literal AST call/getattr census; not absence of nonliteral dynamic callers or other languages.','base_commit':BASE,'base_tree':subprocess.check_output(['git','rev-parse',BASE+'^{tree}'],cwd=ROOT).decode().strip(),'base_python_files':len(items),'candidate_python_files':len(sources),'file_type_denominator':'*.py source blobs under policy-engine/src; tests and other languages excluded','syntax_errors':syntax,'calls':rows,'legacy_digest_attribute_references':digest_attributes,'legacy_digest_exact_string_literals':digest_literals,'literal_dynamic_lookups':dynamic,'provider_verification_private_digest_calls':[row for row in rows if row['path'].endswith('/provider_verification.py') and row['method']=='_request_digest'],'digest_calls_by_owner_note':'Core TracedLLMClient._request_digest is a separate unchanged method. CachingLLMClient internal calls provide prepared/caller_snapshot. Preflight uses the shared PreparedCacheRequest directly.','source_set_sha256':hashlib.sha256(b''.join(path.encode()+b'\0'+hashlib.sha256(raw).digest() for path,raw in sorted(sources.items()))).hexdigest(),'product_imports':False,'runtime':'UNRUN'}
assert not syntax and not report['provider_verification_private_digest_calls']
(OUT/'shared-consumer-census.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'base_python_files':len(items),'candidate_python_files':len(sources),'literal_call_rows':len(rows),'literal_dynamic_lookups':len(dynamic),'provider_verification_private_digest_calls':len(report['provider_verification_private_digest_calls']),'syntax_errors':len(syntax)},indent=2))
