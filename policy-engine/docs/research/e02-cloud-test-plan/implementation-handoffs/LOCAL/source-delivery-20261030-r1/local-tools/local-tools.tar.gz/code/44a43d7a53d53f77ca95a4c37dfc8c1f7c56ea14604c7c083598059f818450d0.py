"""ROOT-ONLY synthetic nested-sandbox control; never open production content."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
HERE = Path(__file__).resolve().parent
LEXICAL = ROOT / 'policy-engine/production_data'
PHYSICAL = Path('/Users/deniskopylov/polisyos/policy-engine/production_data')
PYTHON = ROOT / 'policy-engine/.venv/bin/python'


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def outer(lexical: Path, physical: Path) -> str:
    return '\n'.join([
        '(version 1)',
        '(allow default)',
        '(deny network*)',
        '(deny file-read* (literal ' + json.dumps(str(lexical)) + '))',
        '(deny file-read* (subpath ' + json.dumps(str(lexical)) + '))',
        '(deny file-read* (subpath ' + json.dumps(str(physical)) + '))',
        '',
    ])


def main() -> None:
    if len(sys.argv) != 2 or not re.fullmatch(r'[A-Za-z0-9_-]+', sys.argv[1]):
        raise SystemExit('usage: check_outer_guard.py UNIQUE_CASE_ID')
    case = sys.argv[1]
    if not LEXICAL.is_symlink() or Path(os.path.realpath(LEXICAL)) != PHYSICAL:
        raise SystemExit('production_data link changed: stop for source/context review')
    out = HERE / ('guard-' + case)
    out.mkdir(exist_ok=False)
    denied = out / 'test-owned-denied'
    denied.mkdir()
    (denied / 'value.txt').write_text('test-owned denied fixture\n')
    link = out / 'test-owned-alias'
    link.symlink_to(denied, target_is_directory=True)
    allowed = out / 'allowed.txt'
    allowed.write_text('test-owned allowed fixture\n')
    assert (denied / 'value.txt').read_text() == (link / 'value.txt').read_text()
    synthetic = out / 'synthetic-outer.sb'
    synthetic.write_text(outer(link, denied))
    production = out / 'production-outer.sb'
    production.write_text(outer(LEXICAL, PHYSICAL))
    inner = out / 'inner-write-guard.sb'
    inner.write_text('(version 1)\n(allow default)\n(deny file-write*)\n(allow file-write* (subpath ' + json.dumps(str(out)) + '))\n(allow file-write* (literal "/dev/null"))\n')
    child_code = '''import errno, json, pathlib, sys\nresults = {}\nfor name, raw in (("direct", sys.argv[1]), ("symlink", sys.argv[2])):\n    try:\n        pathlib.Path(raw).read_bytes()\n    except OSError as exc:\n        results[name] = "denied" if exc.errno in (errno.EACCES, errno.EPERM) else "other_error_" + str(exc.errno)\n    else:\n        results[name] = "READ_SUCCEEDED"\nresults["allowed"] = pathlib.Path(sys.argv[3]).read_text() == "test-owned allowed fixture\\n"\nprint(json.dumps(results, sort_keys=True))\nraise SystemExit(0 if results == {"direct": "denied", "symlink": "denied", "allowed": True} else 2)\n'''
    command = ['/usr/bin/sandbox-exec', '-f', str(synthetic), '/usr/bin/sandbox-exec', '-f', str(inner), str(PYTHON), '-B', '-c', child_code, str(denied / 'value.txt'), str(link / 'value.txt'), str(allowed)]
    env = {'PATH': '/usr/bin:/bin:/usr/sbin:/sbin', 'HOME': os.environ['HOME'], 'LANG': 'C.UTF-8', 'PYTHONDONTWRITEBYTECODE': '1'}
    run = subprocess.run(command, cwd=ROOT / 'policy-engine', env=env, capture_output=True, text=True)
    receipt = {
        'schema': 'c48.synthetic-outer-nested-guard.v1',
        'case_id': case,
        'production_lexical_link': str(LEXICAL),
        'production_physical_target': str(PHYSICAL),
        'production_profile_sha256': sha(production),
        'synthetic_profile_sha256': sha(synthetic),
        'inner_profile_sha256': sha(inner),
        'child_code_sha256': hashlib.sha256(child_code.encode()).hexdigest(),
        'return_code': run.returncode,
        'stdout': run.stdout,
        'stderr': run.stderr,
        'scope': 'Only synthetic read denial, symlink denial, allowed read and outer/inner composition; no production file opened.',
        'network_boundary': 'The profile declares deny network*. This check issues no network syscall, binds no port, and does not independently establish network denial.',
    }
    (out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))
    if run.returncode:
        raise SystemExit('nested read guard control failed; do not launch')


if __name__ == '__main__':
    main()
