"""Opt-in, source-bound C43 semantic removals; no product files are written."""
from __future__ import annotations

import __future__
import ast
from functools import wraps
import hashlib
import inspect
import json
import marshal
import os
import subprocess
import textwrap
from pathlib import Path

import pytest

_TEST = 'tests/unit/remediation/test_c43_joint_gaussian.py'
_CASES = {
    'random_joint': ('monte_carlo', '_run_random_loop', 'test_same_declared_joint_gaussian_has_same_linear_variance_in_four_backends', {'method': 'random', 'rho': 0.8}, 10),
    'sobol_joint': ('monte_carlo', '_transform_qmc_samples', 'test_same_declared_joint_gaussian_has_same_linear_variance_in_four_backends', {'method': 'sobol', 'rho': 0.8}, 10),
    'dispatcher_preflight': ('dispatcher', 'propagate', 'test_dispatcher_rejects_unresolved_input_before_even_the_applicability_probe', {}, 1),
    'fixed_auto': ('dispatcher', '_can_use_delta', 'test_all_actual_evaluator_calls_keep_the_fixed_value_without_a_fake_envelope', {'method': 'auto'}, 4),
    'fixed_delta': ('delta', 'propagate', 'test_all_actual_evaluator_calls_keep_the_fixed_value_without_a_fake_envelope', {'method': 'delta'}, 4),
    'fixed_random': ('monte_carlo', '_run_random_loop', 'test_all_actual_evaluator_calls_keep_the_fixed_value_without_a_fake_envelope', {'method': 'random'}, 4),
    'fixed_sobol': ('monte_carlo', '_run_qmc_loop', 'test_all_actual_evaluator_calls_keep_the_fixed_value_without_a_fake_envelope', {'method': 'sobol'}, 4),
    'analytical_matrix': ('analytical', 'propagate_linear_combination', 'test_analytical_supplied_covariance_must_match_the_named_input_law', {}, 1),
}
_STATE = {}


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _need(name: str) -> str:
    value = os.environ.get(name)
    if not value:
        raise pytest.UsageError('C43 removal requires ' + name)
    return value


def _git(root: Path, *args: str) -> str:
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()


def _save(path: Path, record: dict) -> None:
    if path.is_symlink():
        raise pytest.UsageError('C43 refusal of symlink output')
    path.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')


def _is_non_none(name: str, node: ast.AST) -> bool:
    return (isinstance(node, ast.Compare) and isinstance(node.left, ast.Name)
            and node.left.id == name and len(node.ops) == 1 and isinstance(node.ops[0], ast.IsNot)
            and len(node.comparators) == 1 and isinstance(node.comparators[0], ast.Constant)
            and node.comparators[0].value is None)


def pytest_configure(config: pytest.Config) -> None:
    root = Path(config.rootpath).resolve(strict=True)
    if root != Path.cwd().resolve(strict=True):
        raise pytest.UsageError('C43 requires product cwd')
    plugin = Path(__file__).resolve(strict=True)
    if _sha(plugin.read_bytes()) != _need('C43_CONTROL_PLUGIN_SHA256'):
        raise pytest.UsageError('C43 plugin hash mismatch')
    profile_path = plugin.parent / 'c43_child_profile.py'
    if _sha(profile_path.read_bytes()) != _need('C43_CHILD_PROFILE_SHA256'):
        raise pytest.UsageError('C43 child profile bytes mismatch')
    mode = _need('C43_CONTROL_MODE')
    if mode != 'random_joint':
        raise pytest.UsageError('C43 manual r2 admits only reviewed random_joint mode')
    module_name, method, test_name, params, count = _CASES[mode]
    source = root / 'src/polisyos/foundry/uncertainty' / (module_name + '.py')
    test = root / _TEST
    source_sha, test_sha = _need('C43_CONTROL_SOURCE_SHA256'), _need('C43_CONTROL_TEST_SHA256')
    if _sha(source.read_bytes()) != source_sha or _sha(test.read_bytes()) != test_sha:
        raise pytest.UsageError('C43 source/test hash mismatch')
    head, tree = _git(root, 'rev-parse', 'HEAD'), _git(root, 'rev-parse', 'HEAD^{tree}')
    if head != _need('C43_CONTROL_SOURCE_HEAD') or tree != _need('C43_CONTROL_SOURCE_TREE'):
        raise pytest.UsageError('C43 head/tree mismatch')
    output = Path(_need('C43_CONTROL_OUTPUT')).resolve(strict=True)
    if output != Path(_need('POLISYOS_R4_INPUT_READSET_DIR')).parent.resolve(strict=True):
        raise pytest.UsageError('C43 control output outside native case')
    active_path, receipt_path = output / 'active-control.py', output / 'control-mutation.json'
    if active_path.exists() or receipt_path.exists():
        raise pytest.UsageError('C43 existing control output')
    import importlib
    module = importlib.import_module('polisyos.foundry.uncertainty.' + module_name)
    if Path(module.__file__).resolve(strict=True) != source.resolve(strict=True):
        raise pytest.UsageError('C43 wrong imported owner')
    cls = getattr(module, {'monte_carlo': 'MonteCarloPropagator', 'dispatcher': 'PropagationDispatcher', 'delta': 'DeltaMethodPropagator', 'analytical': 'AnalyticalPropagator'}[module_name])
    descriptor = inspect.getattr_static(cls, method)
    original = descriptor.__func__ if isinstance(descriptor, staticmethod) else descriptor
    original_source = textwrap.dedent(inspect.getsource(original))
    parsed = ast.parse(original_source)
    fn = parsed.body[0]
    if not isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)) or fn.name != method:
        raise pytest.UsageError('C43 cannot identify unique admitted method')
    fn.decorator_list = []
    changed = 0
    if mode == 'random_joint':
        # The outer propagator retains its declared joint metadata; this sampler loses only the law.
        index = 1 if fn.body and isinstance(fn.body[0], ast.Expr) and isinstance(fn.body[0].value, ast.Constant) and isinstance(fn.body[0].value.value, str) else 0
        fn.body.insert(index, ast.parse('gaussian_spec = None').body[0]); changed = 1
    elif mode == 'sobol_joint':
        for index, node in enumerate(fn.body):
            if isinstance(node, ast.If) and _is_non_none('gaussian_spec', node.test):
                fn.body.insert(index, ast.parse('gaussian_spec = None').body[0]); changed += 1; break
    elif mode == 'dispatcher_preflight':
        for index, node in enumerate(fn.body):
            if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name) and node.value.func.id == '_validate_effective_inputs':
                fn.body[index] = ast.Pass(); changed += 1
    elif mode.startswith('fixed_'):
        original_name = 'effective_nominal' if mode in {'fixed_auto', 'fixed_delta'} else 'nominal_params'
        replacement = ast.parse('params = {name: ' + original_name + '[name] for name in param_names}').body[0]
        class ReplaceFixed(ast.NodeTransformer):
            def visit_Assign(self, node):
                nonlocal changed
                if len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and node.targets[0].id == 'params' and isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name) and node.value.func.id == 'dict' and len(node.value.args) == 1 and isinstance(node.value.args[0], ast.Name) and node.value.args[0].id == original_name:
                    changed += 1
                    return ast.copy_location(replacement, node)
                return self.generic_visit(node)
        fn = ReplaceFixed().visit(fn)
        parsed.body[0] = fn
    elif mode == 'analytical_matrix':
        for node in fn.body:
            if isinstance(node, ast.If) and any(isinstance(child, ast.Call) and isinstance(child.func, ast.Name) and child.func.id == 'calibration_covariance_blocks_agree_v1' for child in ast.walk(node.test)):
                node.test = ast.Constant(value=False); changed += 1
        for index, node in enumerate(fn.body):
            if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and node.targets[0].id == 'covariance' and isinstance(node.value, ast.Name) and node.value.id == 'admitted_covariance':
                fn.body[index] = ast.parse('covariance = admitted_covariance if covariance is None else covariance').body[0]; changed += 1
    expected_changes = 2 if mode == 'analytical_matrix' else 1
    if changed != expected_changes:
        raise pytest.UsageError(f'C43 {mode} expected {expected_changes} source transforms, found {changed}')
    ast.fix_missing_locations(parsed)
    active_source = ast.unparse(parsed) + '\n'
    active_path.write_text(active_source)
    namespace = dict(vars(module))
    exec(compile(active_source, str(active_path), 'exec', flags=__future__.annotations.compiler_flag), namespace)  # noqa: S102
    active = namespace[method]
    @wraps(active)
    def observed_active(*args, **kwargs):
        _STATE['active_invocation_count'] = _STATE.get('active_invocation_count', 0) + 1
        return active(*args, **kwargs)
    setattr(cls, method, staticmethod(observed_active) if isinstance(descriptor, staticmethod) else observed_active)
    record = {'mode': mode, 'source_head': head, 'source_tree': tree, 'correct_source': str(source), 'correct_source_sha256': source_sha, 'test_sha256': test_sha, 'plugin_sha256': _sha(plugin.read_bytes()), 'original_function_sha256': _sha(original_source.encode()), 'original_code_sha256': _sha(marshal.dumps(original.__code__)), 'active_function': str(active_path), 'active_source_sha256': _sha(active_source.encode()), 'active_code_sha256': _sha(marshal.dumps(active.__code__)), 'rewrite_count': changed, 'runtime_outcome': 'RUNNING', 'qualification': 'Test must fail at the named behavior; collection, setup, backend and unrelated errors are not removal proof.'}
    _STATE.update(root=root, cls=cls, descriptor=descriptor, original=original, method=method, active=observed_active, source=source, source_sha=source_sha, test=test, test_sha=test_sha, test_name=test_name, params=params, count=count, output=output, receipt_path=receipt_path, record=record)
    _save(receipt_path, record)


@pytest.hookimpl(trylast=True)
def pytest_collection_finish(session: pytest.Session) -> None:
    items = session.items
    if len(items) != 1:
        raise pytest.UsageError(f'C43 expected one exact previously observed case, got {len(items)}')
    item = items[0]
    if getattr(item, 'originalname', None) != _STATE['test_name']:
        raise pytest.UsageError('C43 wrong selected test function')
    actual = getattr(getattr(item, 'callspec', None), 'params', {})
    expected = _STATE['params']
    if set(actual) != set(expected) or any(type(actual[k]) is not type(v) or actual[k] != v for k,v in expected.items()):
        raise pytest.UsageError('C43 selected parameter mismatch')
    _STATE['record']['selected_node'] = item.nodeid
    _STATE['record']['selected_parameters'] = actual
    _save(_STATE['receipt_path'], _STATE['record'])


def pytest_sessionfinish(session: pytest.Session, exitstatus: int) -> None:
    if not _STATE:
        return
    r = _STATE['record']
    current = inspect.getattr_static(_STATE['cls'], _STATE['method'])
    r['active_installed_at_finish'] = (current.__func__ if isinstance(current, staticmethod) else current) is _STATE['active']
    r['active_invocation_count'] = _STATE.get('active_invocation_count', 0)
    setattr(_STATE['cls'], _STATE['method'], _STATE['descriptor'])
    r['original_restored_in_process'] = inspect.getattr_static(_STATE['cls'], _STATE['method']) is _STATE['descriptor']
    r['source_bytes_unchanged'] = _sha(_STATE['source'].read_bytes()) == _STATE['source_sha']
    r['test_bytes_unchanged'] = _sha(_STATE['test'].read_bytes()) == _STATE['test_sha']
    r['head_unchanged'] = _git(_STATE['root'], 'rev-parse', 'HEAD') == r['source_head']
    from c43_child_profile import snapshot
    r['actual_child_profile'] = snapshot(session.config)
    r['child_profile_module_sha256'] = _need('C43_CHILD_PROFILE_SHA256')
    r['pytest_exitstatus'] = int(exitstatus)
    r['runtime_outcome'] = 'FINISHED'
    _save(_STATE['receipt_path'], r)
