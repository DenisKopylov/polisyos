"""Root-only read-adapter removal; no source edits or dependency execution at prep."""
import ast
import hashlib
import importlib
import json
import marshal
import os
from pathlib import Path
import types

import pytest

SOURCE = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos/policy-engine/src/polisyos/core/artifacts/ir_adapter.py')
SOURCE_SHA = '27833527e0df929e5ec779c83cb69432d8a544a2037be0606738f84fd636da22'
PINS = {'policy-engine/src/polisyos/core/artifacts/ir_adapter.py': '27833527e0df929e5ec779c83cb69432d8a544a2037be0606738f84fd636da22', 'policy-engine/tests/unit/ir/analytics/test_ncm.py': '4d3a4e73152448bf1dcad21acf2ac80c03bb17ada3eb321b7f91b7920c16f51d', 'policy-engine/src/polisyos/runtime/quality/generation_source.py': 'effa492c3f1848a1d44cf2375687710c6ccee876607fd7f55b344b1cfe44daeb', 'policy-engine/src/polisyos/core/artifacts/__init__.py': '81c423202e396199b19a6bba6fa2293fba0b02618560e1b046b12e04e04c04d6', 'policy-engine/src/polisyos/core/artifacts/protocol.py': '68f7d2749be6a3e9d7817aac855901c1c5e2c31ff559a9439a79e01d8a720fae', 'policy-engine/src/polisyos/core/artifacts/store.py': '208b9aa6867c2303e5444ce6d7e446af2fcf2e9ca60e43c6205d68cf45a0ccc7', 'policy-engine/src/polisyos/ir/artifacts/io.py': '93bc59240493a1d8d75b2b3c2d5e4461555c88538c0cc2976c5e6426a7274160', 'policy-engine/src/polisyos/ir/analytics/ncm.py': 'caeb7c69e34d9c6a91ae0754224ef189abb1b936adbd3d645f3a7bce06ae9aa2'}
NODE = "tests/unit/ir/analytics/test_ncm.py::test_candidate_ncm_is_derived_from_declared_baseline_and_selected_view"
_function = None
_original_code = None
_mutant_code = None
_stream = None
_alias_owners = ()
_globals = None
_defaults = None
_kwdefaults = None


def _code(tree):
    impl = next(n for n in tree.body if isinstance(n, ast.FunctionDef)
                and n.name == "ensure_ir_artifact_store" and len(n.body) > 1)
    full = compile(tree, str(SOURCE), "exec", dont_inherit=True)
    found = [v for v in full.co_consts if isinstance(v, types.CodeType)
             and v.co_name == impl.name and v.co_firstlineno == impl.lineno]
    assert len(found) == 1
    return found[0]


def _sha(code):
    return hashlib.sha256(marshal.dumps(code)).hexdigest()


def _trace(event, **values):
    _stream.write(json.dumps({"event": event, **values}, sort_keys=True) + "\n")
    _stream.flush()


def _alias_state(expected_code):
    rows = {}
    for label, module, name in _alias_owners:
        alias = getattr(module, name)
        assert alias is _function
        assert alias.__code__ is expected_code
        assert alias.__globals__ is _globals
        assert alias.__defaults__ is _defaults
        assert alias.__kwdefaults__ is _kwdefaults
        rows[label] = _sha(alias.__code__)
    return rows


def pytest_collection_modifyitems(session, config, items):
    global _function, _original_code, _mutant_code, _stream
    global _alias_owners, _globals, _defaults, _kwdefaults
    assert [item.nodeid for item in items] == [NODE]
    for relative, digest in PINS.items():
        assert hashlib.sha256((Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos') / relative).read_bytes()).hexdigest() == digest
    source = SOURCE.read_bytes()
    assert hashlib.sha256(source).hexdigest() == SOURCE_SHA
    assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest() == os.environ["E02_IR_REMOVAL_PLUGIN_SHA256"]
    trace = Path(os.environ["E02_IR_REMOVAL_TRACE"])
    assert trace.parent == Path(os.environ["TMPDIR"]).parent
    assert trace.name == "readonly-ir-removal-trace.jsonl"
    assert not any(q.is_symlink() for q in (trace, *trace.parents))
    _stream = os.fdopen(os.open(trace, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600), "w")
    owner = importlib.import_module("polisyos.core.artifacts.ir_adapter")
    assert Path(owner.__file__).resolve() == SOURCE.resolve()
    _function = owner.ensure_ir_artifact_store
    _original_code = _function.__code__
    _globals = _function.__globals__
    _defaults = _function.__defaults__
    _kwdefaults = _function.__kwdefaults__
    assert _globals is vars(owner)
    facade = importlib.import_module("polisyos.core.artifacts")
    repository = importlib.import_module("polisyos.runtime.quality.generation_source")
    _alias_owners = (
        ("public_facade", facade, "ensure_ir_artifact_store"),
        ("source_repository", repository, "_ensure_ir_artifact_store"),
        ("actual_test_module", items[0].module, "_ensure_ir_artifact_store"),
    )
    before_aliases = _alias_state(_original_code)
    tree = ast.parse(source, filename=str(SOURCE))
    assert _original_code == _code(tree)
    impl = next(n for n in tree.body if isinstance(n, ast.FunctionDef)
                and n.name == "ensure_ir_artifact_store" and len(n.body) > 1)
    guards = [n for n in ast.walk(impl) if isinstance(n, ast.If)
              and isinstance(n.test, ast.Call)
              and isinstance(n.test.func, ast.Name)
              and n.test.func.id == "is_core_reader"]
    assert len(guards) == 1
    guards[0].test = ast.copy_location(ast.Constant(value=False), guards[0].test)
    ast.fix_missing_locations(tree)
    _mutant_code = _code(tree)
    assert _mutant_code != _original_code
    assert _mutant_code.co_freevars == _original_code.co_freevars
    _trace("admission", source_sha256=SOURCE_SHA, original_code_sha256=_sha(_original_code),
           mutant_code_sha256=_sha(_mutant_code), source_pins=PINS,
           before_alias_code_sha256=before_aliases, current_globals_retained=True,
           scope="remove only narrow reader dispatch; three actual aliases retain one function; no global-value/native authority claim")


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_call(item):
    assert item.nodeid == NODE and _function.__code__ is _original_code
    _alias_state(_original_code)
    try:
        _function.__code__ = _mutant_code
        aliases = _alias_state(_mutant_code)
        _trace("mutation", code_sha256=_sha(_function.__code__),
               alias_code_sha256=aliases, current_globals_retained=True,
               defaults_preserved=True)
        yield
    finally:
        _function.__code__ = _original_code
        aliases = _alias_state(_original_code)
        _trace("restore", code_sha256=_sha(_function.__code__),
               alias_code_sha256=aliases, exact_code_identity_restored=True)


def pytest_unconfigure(config):
    try:
        if _function is not None and _original_code is not None:
            _function.__code__ = _original_code
            if _stream is not None:
                _trace("plugin_finish_restore", code_sha256=_sha(_function.__code__),
                       alias_code_sha256=_alias_state(_original_code),
                       exact_code_identity_restored=True)
    finally:
        if _stream is not None:
            _stream.close()
