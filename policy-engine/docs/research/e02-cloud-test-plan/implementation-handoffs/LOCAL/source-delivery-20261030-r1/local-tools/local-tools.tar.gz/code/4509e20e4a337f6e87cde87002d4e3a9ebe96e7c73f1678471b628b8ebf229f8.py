"""Prepare (never execute) C18 native plans after root commits the proposed source."""
from __future__ import annotations
import argparse
import hashlib
import json
import subprocess
from pathlib import Path

R = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
P = R / 'policy-engine'
HERE = Path(__file__).resolve().parent
D = P / 'docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1'
TEST = P / 'tests/unit/foundry/methods/catalog/causal/test_rdd_rbc_independent_oracle.py'
SOURCE = P / 'src/polisyos/foundry/methods/catalog/causal/rdd.py'
PLUGIN = HERE / 'c18_removal_plugin.py'
NODE = 'tests/unit/foundry/methods/catalog/causal/test_rdd_rbc_independent_oracle.py::test_independent_sensitivity_oracle_matches_corrected_point_and_hc0_se[h_lt_b]'
EXPECTED_TEST = '4c8398b42efa15eeba4b28c9900a18541269931322edb8122412443d081f1585'
EXPECTED_SOURCE = 'eb2505f40b8a5ad464b5669f5432a8152859aa81ce98e9668787f7208ba8ba43'
EXPECTED_PLUGIN = '30d922ceb45d79bf39874b6ebf1f756838ee13a7117b790921a0b53d7881bc25'

def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args: str) -> str:
    return subprocess.check_output(['git', '-C', str(R), *args], text=True).strip()

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', required=True, help='Exact root-approved current HEAD after C18 commit')
    parser.add_argument('--tag', default='20261027-r1', help='Unique plan/case suffix')
    args = parser.parse_args()
    if not args.tag or any(not (c.isalnum() or c in '-_') for c in args.tag):
        raise SystemExit('invalid tag')
    head = git('rev-parse', 'HEAD')
    if head != args.source or git('symbolic-ref', '--short', 'HEAD') != 'codex/e02-unified-local-20261009':
        raise SystemExit('branch or admitted HEAD mismatch')
    for path, expected in [(TEST, EXPECTED_TEST), (SOURCE, EXPECTED_SOURCE), (PLUGIN, EXPECTED_PLUGIN)]:
        if not path.is_file() or digest(path) != expected:
            raise SystemExit(f'changed or missing reviewed input: {path}')
    for path in [TEST, SOURCE]:
        relative = str(path.relative_to(R))
        if git('status', '--short', '--', relative):
            raise SystemExit(f'dirty input {relative}')
        committed = subprocess.check_output(['git', '-C', str(R), 'show', head + ':' + relative])
        if hashlib.sha256(committed).hexdigest() != digest(path):
            raise SystemExit(f'committed input mismatch {relative}')
    entries = [
        ('c18-rdd-composed-positive', None),
        ('c18-rdd-correction-removal', 'point'),
        ('c18-rdd-variance-removal', 'variance'),
    ]
    paths = []
    for prefix, mode in entries:
        case = prefix + '-' + args.tag
        plan_path = D / (case + '.json')
        if plan_path.exists() or (D / case).exists():
            raise SystemExit(f'refuse overwrite: {case}')
        env = {'OPENBLAS_NUM_THREADS': '1', 'PYTEST_ADDOPTS': '-s'}
        nodes = ['tests/unit/foundry/methods/catalog/causal/test_rdd_rbc.py', str(TEST.relative_to(P))]
        if mode:
            nodes = [NODE]
            env.update({
                'PYTHONPATH': str(HERE) + ':' + str(P / 'src'),
                'PYTEST_PLUGINS': 'c18_removal_plugin',
                'C18_REMOVAL_MODE': mode,
                'C18_EXPECTED_SOURCE_HEAD': head,
                'C18_EXPECTED_RDD_SHA256': EXPECTED_SOURCE,
                'C18_EXPECTED_TEST_PATH': str(TEST),
                'C18_EXPECTED_TEST_SHA256': EXPECTED_TEST,
                'C18_EXPECTED_PLUGIN_SHA256': EXPECTED_PLUGIN,
                'C18_CONTROL_OUTPUT_DIR': str(D / case / 'c18-control'),
            })
        plan = {
            'case_id': case,
            'source_head': head,
            'task_ids': ['B210@CAU-03'],
            'nodes': nodes,
            'extra_env': env,
            'deadline_seconds': 600,
            'rss_cap_bytes': 2411724800,
            'scope': ('bounded sharp-RDD independent point/HC0, two h/b ratios, '
                      'zero/nonzero correction, actual dispatcher/fresh CAS reader, '
                      'synthetic fixed-seed heteroskedastic 400-rep coverage; '
                      'mode=' + str(mode) + '. No general inference, G acceptance or closure.'),
            'expected_control': (None if mode is None else
                ('expected FAIL at independent point assertion after marker for point removal' if mode == 'point' else
                 'expected FAIL at independent SE assertion after marker and point for variance removal')),
            'binding': {'test_sha256': EXPECTED_TEST, 'source_sha256': EXPECTED_SOURCE,
                        'plugin_sha256': EXPECTED_PLUGIN if mode else None,
                        'coverage_seed': 2026102803, 'coverage_acceptance': [0.915, 0.985]},
        }
        paths.append((plan_path, plan))
    for path, plan in paths:
        path.write_text(json.dumps(plan, indent=2) + '\n')
        print('PREPARED ONLY', path)
    print('No pytest or native run was started. Run each plan via run_case_with_tools_r2.py.')

if __name__ == '__main__':
    main()
