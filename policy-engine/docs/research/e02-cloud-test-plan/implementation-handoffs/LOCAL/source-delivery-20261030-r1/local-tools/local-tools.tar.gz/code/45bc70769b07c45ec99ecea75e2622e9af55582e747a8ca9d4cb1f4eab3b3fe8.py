from pathlib import Path
OUT=Path('LOCAL/raw/e02-execution-20261027/repairs/C38-r3')
p=OUT/'postimages/policy-engine/src/polisyos/runtime/quality/authority.py'
s=p.read_text()
needle='def authority_purpose_blockers(\n'
helper='''def _envelope_authority_admission_blockers(payload: Mapping[str, Any]) -> tuple[str, ...]:
    """Compose an envelope's role with any requested positive authority use.

    A purpose list or positive boundary cannot turn a diagnostic, blocker,
    malformed or unadmitted producer envelope into positive authority. Plain
    AuthorityBoundary records keep their existing independent contract.
    """
    if not any(
        field in payload for field in ("authority_role", "evidence_class", "same_input_closure")
    ):
        return ()
    role = (_authority_payload_text(payload, "authority_role") or "").casefold()
    if role != "producer_authority":
        return ("authority_envelope_cannot_authorize_purpose",)
    try:
        assert_authority_bearing(payload)
    except (AuthorityEnvelopeError, TypeError, ValueError):
        return ("same_input_closure_owner_not_established",)
    return ()


'''
assert needle in s
s=s.replace(needle,helper+needle,1)
old='''    if (
        _authority_payload_text(payload, "authority_role") or ""
    ).casefold() == "producer_authority":
        try:
            assert_authority_bearing(payload)
        except (AuthorityEnvelopeError, TypeError, ValueError):
            return ("same_input_closure_owner_not_established",)
'''
new='''    envelope_blockers = _envelope_authority_admission_blockers(payload)
    if envelope_blockers:
        return envelope_blockers
'''
assert old in s
s=s.replace(old,new,1)
old='''    for authority_candidate in (authority_payload, selected_manifest_authority_payload):
        candidate = _authority_payload(authority_candidate)
        if (
            _authority_payload_text(candidate, "authority_role") or ""
        ).casefold() == "producer_authority":
            gate_inputs.append("same_input_closure")
            try:
                assert_authority_bearing(candidate)
            except (AuthorityEnvelopeError, TypeError, ValueError):
                blocking_reasons.append("same_input_closure_owner_not_established")
'''
assert old in s
s=s.replace(old,'',1)
start=s.index('def _authority_boundary_surface_decision(')
end=s.index('\ndef _selected_manifest_authority_payload(',start)
part=s[start:end]
needle='    if blockers:\n'
addition='''    # Candidate and blocked dispositions above remain honest negative/limited
    # diagnostics. A positive boundary additionally needs the role's admission.
    envelope_blockers = tuple(
        blocker
        for candidate in (carrier, surface_packet)
        for blocker in _envelope_authority_admission_blockers(candidate)
    )
    if envelope_blockers:
        return AuthoritySurfaceDecision(
            surface=surface_name,
            purpose=requested_purpose,
            status="blocked",
            authority_result=authority_result,
            transition_disposition=transition_disposition,
            authority_boundary_ref=boundary_ref,
            consumed_authority_boundary=True,
            may_not_use_for=may_not_use_for,
            reason=envelope_blockers[0],
            blocking=True,
            visible_downgrade=True,
        )
'''
assert part.count(needle)==1
part=part.replace(needle,addition+needle,1)
s=s[:start]+part+s[end:]
p.write_text(s)
p=OUT/'postimages/policy-engine/src/polisyos/runtime/http/services/control/nl_pipeline.py'
s=p.read_text().replace('                selection_origin = "default_view_at_read"\n','''                selection_origin: Literal["explicit_selected_ref", "default_view_at_read"] = (
                    "default_view_at_read"
                )
''',1).replace('                if type(ref_value) is ArtifactRef and ref_value.manifest_profile_sha256:\n','                if isinstance(ref_value, ArtifactRef) and ref_value.manifest_profile_sha256:\n',1)
p.write_text(s)
print('Same-class review delta applied in scratch: shared positive-boundary role composition; preserve typed selected subclasses.')
