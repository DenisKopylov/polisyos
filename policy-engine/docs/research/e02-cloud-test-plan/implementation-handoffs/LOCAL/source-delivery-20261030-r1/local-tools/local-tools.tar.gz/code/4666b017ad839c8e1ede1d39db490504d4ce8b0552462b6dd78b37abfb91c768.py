"""Inspect complete default CAS rule artifacts from retained r37c1 without product imports."""
from __future__ import annotations

import hashlib
import json
from collections import Counter
from pathlib import Path

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
AUDIT = ROOT / ('policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/'
    'root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/'
    'deep-task-status-audit-20261027-r1/r37c1')
PRODUCER = 'polisyos.runtime.quality.data_state_substrate.build_acquired_observation_candidate_world'


def find_default_kind(base: Path, kind: str) -> list[tuple[str, dict]]:
    result = []
    for manifest in base.rglob('*.manifest.json'):
        if '.view.' in manifest.name:
            continue
        metadata = json.loads(manifest.read_bytes())
        if metadata['kind'] != kind:
            continue
        digest = manifest.name.removesuffix('.manifest.json')
        raw = (manifest.parent / (digest + '.blob')).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == digest
        assert metadata['artifact_id'] == 'sha256:' + digest
        result.append(('sha256:' + digest, json.loads(raw)))
    return result


def read_id(base: Path, ref: dict | str) -> dict:
    artifact_id = ref['artifact_id'] if isinstance(ref, dict) else ref
    digest = artifact_id.removeprefix('sha256:')
    raw = (base / digest[:2] / digest[2:4] / (digest + '.blob')).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == digest
    return json.loads(raw)


def canon(value: dict) -> str:
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False)


def examine(case: str) -> dict:
    base = AUDIT / 'basetemp' / case / 'source/authority/cas/artifacts/sha256'
    wmrs = find_default_kind(base, 'runtime.quality.world_model_record')
    assert len(wmrs) == 2
    actual_pair = [pair for pair in wmrs if pair[1]['producer_ref'] == PRODUCER]
    base_pair = [pair for pair in wmrs if pair[1]['producer_ref'] == 'test.world_model_record_builder']
    assert len(actual_pair) == len(base_pair) == 1
    actual_id, actual_world = actual_pair[0]
    base_id, prior_world = base_pair[0]
    base_binding_id = prior_world['foundry_binding_ref']['input_bindings_ref']
    actual_binding_id = actual_world['foundry_binding_ref']['input_bindings_ref']
    base_rules = read_id(base, base_binding_id)['rules']
    actual_rules = read_id(base, actual_binding_id)['rules']
    selected = [r for r in actual_rules if r['binding_id'].startswith('acquisition.')]
    assert len(selected) == 1
    acquired = selected[0]
    old_target = [r for r in base_rules if r['target_slot_id'] == acquired['target_slot_id']]
    assert len(old_target) == 1
    reconstructed = [r for r in base_rules if r['target_slot_id'] != acquired['target_slot_id']] + [acquired]
    assert Counter(map(canon, reconstructed)) == Counter(map(canon, actual_rules))
    assert reconstructed != actual_rules
    assert sorted(reconstructed, key=lambda r: r['binding_id']) == actual_rules
    registry = read_id(base, prior_world['artifact_views']['registry_bundle_ref'])
    slots = read_id(base, registry['slot_registry'])['slots']
    report = read_id(base, actual_world['artifact_views']['input_binding_report_ref'])
    applied = report['applied_binding_ids']
    assert applied == [rule['binding_id'] for rule in actual_rules]
    def rows(rules: list[dict]) -> list[dict]:
        return [{'ordinal': i, 'binding_id': r['binding_id'], 'target_slot_id': r['target_slot_id'],
                 'state_path': slots[r['target_slot_id']]['state_path'], 'notes': r.get('notes', []),
                 'full_persisted_rule': r} for i, r in enumerate(rules)]
    target_ids = [r['target_slot_id'] for r in actual_rules]
    paths = [slots[target]['state_path'] for target in target_ids]
    ids = [r['binding_id'] for r in actual_rules]
    return {
        'case': case,
        'base_wmr': base_id,
        'produced_wmr': actual_id,
        'base_binding_artifact': base_binding_id,
        'produced_binding_artifact': actual_binding_id,
        'source_rule_count': len(base_rules),
        'produced_rule_count': len(actual_rules),
        'removed_base_target_rule': old_target[0],
        'acquired_full_rule': acquired,
        'prospective_raw_order_reconstructed_from_source': rows(reconstructed),
        'persisted_actual_order': rows(actual_rules),
        'complete_raw_rule_multisets_equal': True,
        'same_complete_values_in_owner_binding_id_order': True,
        'binding_report_applied_ids': applied,
        'case_unique_binding_ids': len(ids) == len(set(ids)),
        'case_unique_target_slots': len(target_ids) == len(set(target_ids)),
        'case_unique_state_paths': len(paths) == len(set(paths)),
    }


result = {
    'scope': 'Both complete retained r37c1 default CAS case stores. The prospective tuple is reconstructed using the 2130 source formula, base bindings and actually persisted acquired rule; it is not a captured prospective runtime value.',
    'cases': [examine('test_prospective_world_values_0'), examine('test_active_skg_change_stays_u0')],
    'limit': 'Actual owner validates duplicate binding IDs, not duplicate targets/state paths. A distinct alias-overlap behavioral test is needed; per-case uniqueness is not a system guarantee.',
}
print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
