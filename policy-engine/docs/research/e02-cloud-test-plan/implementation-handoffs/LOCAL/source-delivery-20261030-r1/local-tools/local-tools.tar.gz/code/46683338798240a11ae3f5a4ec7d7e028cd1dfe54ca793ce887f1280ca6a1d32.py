"""Bind an unchanged artifact320 tail to Root's actual held execution checkout."""
from pathlib import Path
import argparse,hashlib,json,subprocess
ROOT=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
HERE=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['/usr/bin/git',*args],cwd=ROOT)
def main():
 p=argparse.ArgumentParser();p.add_argument('--workspace-commit',required=True);p.add_argument('--workspace-tree',required=True);p.add_argument('--destination',type=Path,required=True);a=p.parse_args();cfg=json.loads((HERE/'config.json').read_bytes())
 assert git('rev-parse','HEAD').decode().strip()==a.workspace_commit and git('rev-parse','HEAD^{tree}').decode().strip()==a.workspace_tree
 overrides={}
 for i,suffix,expected in cfg['pins']:
  path=cfg['prefixes'][i]+suffix;old=git('cat-file','blob',cfg['source_commit']+':'+path);assert sha(old)==expected;raw=git('cat-file','blob',a.workspace_commit+':'+path);assert (ROOT/path).read_bytes()==raw
  if sha(raw)!=expected:
   assert path=='policy-engine/docs/reference/policy-design-case-failure-patterns.md';overrides[path]=sha(raw)
 cfg.update(workspace_commit=a.workspace_commit,workspace_tree=a.workspace_tree,workspace_pin_overrides=overrides,workspace_changed_paths=git('diff','--name-only',cfg['source_commit'],a.workspace_commit).decode().splitlines())
 for row in cfg['inputs'].values():assert sha(Path(row['path']).read_bytes())==row['sha256']
 a.destination.mkdir(parents=True,exist_ok=False);raw=(json.dumps(cfg,separators=(',',':'))+'\n').encode();(a.destination/'config.json').write_bytes(raw);receipt={'artifact_source_commit':cfg['source_commit'],'artifact_source_tree':cfg['source_tree'],'workspace_commit':a.workspace_commit,'workspace_tree':a.workspace_tree,'pin_readback':59,'runtime_pins_changed':0,'planning_overrides':overrides,'controller_sha256':sha((HERE/'tails.py').read_bytes()),'config_sha256':sha(raw),'runtime':'UNRUN','G_acceptance':False,'closures':[]};(a.destination/'binding.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n');print(json.dumps(receipt))
if __name__=='__main__':main()
