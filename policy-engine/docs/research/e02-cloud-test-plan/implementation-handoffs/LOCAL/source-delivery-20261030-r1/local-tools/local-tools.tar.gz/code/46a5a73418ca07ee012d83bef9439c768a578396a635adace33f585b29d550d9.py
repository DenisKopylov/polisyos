"""Root-only bounded diagnostic supervisor; does not run pytest or the HTE case."""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import os
import runpy
import signal
import sys
import time

R = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
P = R / 'policy-engine'
D = P / 'docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1'
N = D.parent
HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None


def save(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')


def main():
    if len(sys.argv) != 2:
        raise SystemExit('absolute unique plan path required')
    plan_path = Path(sys.argv[1])
    if not plan_path.is_absolute() or plan_path.parent != D:
        raise SystemExit('plan must be an absolute child of D')
    plan = json.loads(plan_path.read_text())
    case = plan['case_id']
    if not case or any(not (x.isalnum() or x in '-_') for x in case):
        raise SystemExit('invalid case id')
    if sha(HERE / 'run_probe.py') != plan['runner_sha256'] or sha(HERE / 'probe.py') != plan['probe_sha256']:
        raise SystemExit('diagnostic scripts differ from plan')
    for path, expected in plan['input_pins'].items():
        if sha(R / path) != expected:
            raise SystemExit('input pin differs: ' + path)
    guard = runpy.run_path(str(N / 'root-layer-lib.py'))['guard']
    before = guard()
    if before['head'] != plan['source_head'] or before['source_frame'] != plan['source_frame']:
        raise SystemExit('journal-bound HEAD/frame differs; prepare a new unique plan, never move HEAD')
    if os.statvfs(R).f_bavail * os.statvfs(R).f_frsize < 8 * 1024**3:
        raise SystemExit('less than 8 GiB free')
    out = D / case
    out.mkdir(exist_ok=False)
    tmp = out / 'tmp'
    tmp.mkdir()
    profile = out / 'child.sb'
    profile.write_text('(version 1)\n(allow default)\n(deny file-write*)\n'
                       '(allow file-write* (subpath ' + json.dumps(str(out)) + '))\n'
                       '(allow file-write* (literal "/dev/null"))\n')
    removed = {}
    for name in ('PYTHONPATH', 'PYTEST_ADDOPTS', 'PYTEST_PLUGINS',
                 'PYTEST_DISABLE_PLUGIN_AUTOLOAD', 'PYTHONHOME', 'VIRTUAL_ENV'):
        if name in os.environ:
            removed[name] = 'present_removed'
        os.environ.pop(name, None)
    env = {'PYTHONDONTWRITEBYTECODE': '1', 'TMPDIR': str(tmp),
           'XDG_CACHE_HOME': str(tmp / 'xdg'), 'MPLCONFIGDIR': str(tmp / 'mpl'),
           'NUMBA_CACHE_DIR': str(tmp / 'numba'), 'HYPOTHESIS_STORAGE_DIRECTORY': str(tmp / 'hypothesis'),
           'PYTHONPYCACHEPREFIX': str(tmp / 'empty-pycache'),
           'POLISYOS_CACHE_HOME': str(out / 'runtime-http-cache'),
           'SCIENTIST_TORCH_NUM_THREADS': '1', 'SCIENTIST_TORCH_NUM_INTEROP_THREADS': '1'}
    monitor = P / 'docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-postfix-709-q2-helper-actual-20261018/supervise.py'
    spec = importlib.util.spec_from_file_location('c07_probe_supervisor', monitor)
    if spec is None or spec.loader is None:
        raise SystemExit('supervisor unavailable')
    m = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = m
    spec.loader.exec_module(m)
    m.RSS_CAP_BYTES = plan['rss_cap_bytes']
    m.DISK_FLOOR_BYTES = 6 * 1024**3
    m.SAMPLE_SECONDS = 1.0
    signal.signal(signal.SIGTERM, m.note_stop_signal)
    signal.signal(signal.SIGINT, m.note_stop_signal)
    argv = ['/usr/bin/sandbox-exec', '-f', str(profile), str(P / '.venv/bin/python'),
            '-B', str(HERE / 'probe.py'), str(out)]
    save(out / 'source-profile-freeze.json', {'at': datetime.datetime.now(datetime.UTC).isoformat(),
        'before': before, 'plan_sha256': sha(plan_path), 'pins': plan['input_pins'],
        'runner_sha256': plan['runner_sha256'], 'probe_sha256': plan['probe_sha256'],
        'cleared_ambient_control_names': removed, 'diagnostic_env': env,
        'numeric_threads': m.NUMERIC_THREADS, 'argv': argv,
        'cas_timeout_env': os.environ.get('POLISYOS_RUNTIME_CAS_TIMEOUT_SECONDS'),
        'scope': plan['scope'], 'closure_ids': []})
    started = time.monotonic()
    result = m.run_command(out, case, argv, P, started, started + plan['deadline_seconds'], env)
    after = guard()
    mismatches = [{'path': path, 'expected': expected, 'actual': sha(R / path)}
                  for path, expected in plan['input_pins'].items() if sha(R / path) != expected]
    readset = out / 'source-readset.json'
    imported_mismatches = []
    if readset.is_file():
        for path, expected in json.loads(readset.read_text())['paths'].items():
            actual = sha(P / path)
            if actual != expected:
                imported_mismatches.append({'path': path, 'expected': expected, 'actual': actual})
    probe = out / 'c07-cas-probe.json'
    report = {'plan': plan, 'plan_sha256': sha(plan_path), 'before': before, 'after': after,
        'source_profile_freeze_sha256': sha(out / 'source-profile-freeze.json'),
        'result': result, 'probe_sha256': sha(probe), 'readset_sha256': sha(readset),
        'input_mismatches': mismatches, 'imported_mismatches': imported_mismatches,
        'scope': 'One diagnostic operation on a reconstructed private synthetic CAS; not a native HTE or product pass.',
        'closure_ids': []}
    save(out / 'audit-result.json', report)
    complete = (result.get('return_code') == 0 and result.get('complete') is True
                and result.get('aborted_reason') is None and probe.is_file() and readset.is_file()
                and before == after and not mismatches and not imported_mismatches)
    print(json.dumps({'case': case, 'diagnostic_complete': complete,
        'audit_sha256': sha(out / 'audit-result.json'), 'probe_sha256': sha(probe),
        'readset_sha256': sha(readset), 'return_code': result.get('return_code'),
        'aborted_reason': result.get('aborted_reason'), 'seconds': result.get('wall_seconds'),
        'peak_sampled_rss': result.get('max_sampled_process_tree_rss_bytes'),
        'input_mismatches': len(mismatches), 'imported_mismatches': len(imported_mismatches)},
        indent=2), flush=True)
    if not complete:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
