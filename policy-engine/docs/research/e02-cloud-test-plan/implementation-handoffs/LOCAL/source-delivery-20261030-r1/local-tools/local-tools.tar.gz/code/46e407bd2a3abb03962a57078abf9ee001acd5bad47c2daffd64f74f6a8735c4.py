"""Build reviewed-source removal recipes; no product import or runtime execution."""
from pathlib import Path
import ast,difflib,hashlib,json
D=Path(__file__).resolve().parent;O=D/'postimages';C=D/'controls';C.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
STATE='policy-engine/src/polisyos/scientist/validation/source_admission_state.py'
OWNER='policy-engine/src/polisyos/scientist/validation/source_admission_owner.py'
CORE='policy-engine/src/polisyos/core/contracts/decision_validity.py'
TEST='tests/unit/scientist/validation/test_source_admission_state.py'
records=[]
def function(source,name):
 matches=[n for n in ast.walk(ast.parse(source))if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))and n.name==name];assert len(matches)==1,(name,len(matches));return matches[0]
def offset(source,line,column):return sum(len(v)for v in source.splitlines(keepends=True)[:line-1])+column
def replace_node(source,node,text):
 start=offset(source,node.lineno,node.col_offset);end=offset(source,node.end_lineno,node.end_col_offset);return source[:start]+text+source[end:]
def false_guard(rel,func,predicate):
 source=(O/rel).read_text();n=function(source,func);matches=[x for x in ast.walk(n)if isinstance(x,ast.If)and predicate(ast.get_source_segment(source,x.test))];assert len(matches)==1,(func,matches);test=matches[0].test;return replace_node(source,test,'False and ('+ast.get_source_segment(source,test)+')')
def save(key,rel,mutant,node,property,signal):
 base=(O/rel).read_bytes();data=mutant.encode();assert data!=base;ast.parse(mutant);p=C/key;p.mkdir();target=p/'postimage.py';target.write_bytes(data)
 diff=''.join(difflib.unified_diff(base.decode().splitlines(keepends=True),mutant.splitlines(keepends=True),fromfile='a/'+rel,tofile='b/'+rel));patch=p/'source.patch';patch.write_text(diff)
 rec={'id':key,'path':rel,'pre_sha256':sha(base),'post_sha256':sha(data),'postimage':str(target.relative_to(D)),'patch':str(patch.relative_to(D)),'patch_sha256':sha(patch.read_bytes()),'node':TEST+'::'+node,'property':property,'intended_signal':signal,'positive':'baseline must PASS first','removal':'actual runtime semantic FAIL required; no acceptance from arbitrary setup/collection/exception failure','restoration':'exact original postimage SHA then same node fresh PASS','runtime':'UNRUN'}
 (p/'manifest.json').write_text(json.dumps(rec,indent=2)+'\n');records.append(rec)
save('M01-withdrawn-reader',STATE,false_guard(STATE,'snapshot_facts',lambda text:'current["status"]'in text and '"active"'in text),'test_actual_owner_withdraw_a_after_b_keeps_b_and_independent_i_and_history','An exact committed withdrawal prevents current use, independent I/B remain valid and original bytes readable','A fresh owner wrongly returns current for withdrawn A; assert status withdrawn is the deciding red')
save('M02-conflicting-event',STATE,false_guard(STATE,'_commit',lambda text:'prior["command_digest"]'in text),'test_event_retry_is_original_and_full_target_conflict_is_refused','An event ID binds its full command including target carrier and predecessor','Changed-target retry is wrongly accepted as the old receipt; expected conflict is absent')
save('M03-predecessor',STATE,false_guard(STATE,'_predecessor',lambda text:True),'test_event_retry_is_original_and_full_target_conflict_is_refused','A missing/out-of-order source predecessor cannot advance the scoped head','Wrong-predecessor readmit incorrectly commits; expected predecessor gap is absent')
source=(O/STATE).read_text();f=function(source,'_durabilize');lines=source.splitlines(keepends=True);start=f.body[0].lineno-1;end=f.end_lineno;body=''.join(lines[start:end]);mutant=''.join(lines[:start])+(' '*8+'if False:\n')+''.join('    '+line if line.strip()else line for line in body.splitlines(keepends=True))+''.join(lines[end:])
save('M04-uncertain-fsync',STATE,mutant,'test_failed_root_directory_fsync_requires_real_durability_retry','An uncertain replaced root is re-fsynced before an original-event retry acknowledgement','Actual root directory fsync reconciliation count stays zero on retry, despite preserved durability markers')
source=(O/OWNER).read_text();f=function(source,'_verify_ref');matches=[n for n in ast.walk(f)if isinstance(n,ast.Compare)and 'manifest_profile_sha256'in ast.get_source_segment(source,n)];assert len(matches)==2,len(matches)
for n in sorted(matches,key=lambda n:n.lineno,reverse=True):source=replace_node(source,n,'(False and ('+ast.get_source_segment(source,n)+'))')
save('M05-full-selected-profile',OWNER,source,'test_selected_profile_is_required_for_real_binary_or_json_refs','Both binary and JSON refs require exact selected profiles; a mutable default is not earlier producer identity','A genuinely profileless ref resolves current default and is wrongly admitted by _verify_ref; required selected-profile refusal is absent')
save('M06-owned-snapshot-denominator',OWNER,false_guard(OWNER,'_materialization_refs',lambda text:'data_snapshot_manifest_inputs_match'in text),'test_real_snapshot_missing_required_manifest_edge_is_refused_before_admission','Actual typed DataSnapshotOwnerBound fields reconcile to the complete exact parent input-role set','A real same-payload alternate selected manifest missing quality edge is wrongly accepted; expected denominator refusal is absent')
source=(O/CORE).read_text();f=function(source,'source_admission_basis_digest');matches=[n for n in ast.walk(f)if isinstance(n,ast.ListComp)];assert len(matches)==1;node=matches[0];text=ast.get_source_segment(source,node);mutant=replace_node(source,node,text[:-1]+' if False]')
save('M07-query-binding',CORE,mutant,'test_projection_binds_ordered_actual_basis_and_selection_query','Fresh projection binds exact ordered/repeated carrier vector rather than anonymous current marker','Different valid input vectors collapse to one digest despite retained markers; independent digest-inequality assertion fails')
source=(O/OWNER).read_text();f=function(source,'_scoped_store');returns=[n for n in ast.walk(f)if isinstance(n,ast.Return)];assert len(returns)==1;node=returns[0].value;mutant=replace_node(source,node,'self._store if True else ('+ast.get_source_segment(source,node)+')')
save('M08-tenant-view-ownership',OWNER,mutant,'test_fresh_unscoped_owner_reuses_exact_core_tenant_view_ownership','A genuine foreign-only selected CAS view cannot satisfy the registered tenant/cell scope','Fresh unscoped backend bypasses Core for_tenant reader and wrongly reads foreign-only input; expected ownership refusal is absent')
(C/'index.json').write_text(json.dumps({'schema':'e02.source-admission.removal-recipes.v1','controls':records,'runtime':'UNRUN','scope':'Storage/CAS/reader defining properties only; actual C106 Runtime/Fabric/Foundry/API producer controls are separate'},indent=2)+'\n')
print(json.dumps({'controls':len(records),'all_mutants_AST':'PASS','index_sha256':sha((C/'index.json').read_bytes()),'runtime':'UNRUN'}))
