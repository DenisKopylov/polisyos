"""Prepare the C32 graph companion native case without executing product code."""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
PACKET = Path(__file__).resolve().parent
RUNNER_DIR = ROOT / ('policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/'
    'LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/'
    'deep-task-status-audit-20261027-r1')


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-head', required=True)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--suffix', required=True)
    args = parser.parse_args()
    assert args.suffix and all(c.isalnum() or c in '-_' for c in args.suffix)
    sha = lambda raw: hashlib.sha256(raw).hexdigest()
    assert sha((PACKET/'manifest.json').read_bytes()) == args.manifest_sha256
    manifest = json.loads((PACKET/'manifest.json').read_text())
    git = lambda *parts: subprocess.check_output(['git', *parts], cwd=ROOT)
    assert git('symbolic-ref', '--short', 'HEAD').decode().strip() == 'codex/e02-unified-local-20261009'
    assert git('rev-parse', 'HEAD').decode().strip() == args.source_head
    assert git('status', '--porcelain', '--untracked-files=no') == b''
    pins = {}
    for row in manifest['composed_files']:
        if not row['path'].endswith('.py'):
            continue
        raw = (ROOT/row['path']).read_bytes()
        assert sha(raw) in row.get('accepted_postimage_sha256', [row['postimage_sha256']]), row['path']
        assert git('show', args.source_head+':'+row['path']) == raw, row['path']
        pins[row['path']] = sha(raw)
    case = 'c32-r4-graph-'+args.suffix
    plan = {'case_id': case, 'source_head': args.source_head,
        'source_tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
        'task_ids': ['C32','V4','V7'],
        'nodes': ['tests/unit/runtime/quality/test_catalog_acquisition_source_binding.py'],
        'extra_env': {}, 'deadline_seconds': 600, 'rss_cap_bytes': 2411724800,
        'reviewed_source_pins': pins,
        'scope': 'Real selected Catalog graph acquisition-gateway companion only; resolve-only with actual native rows. No fetch, authority/currentness, whole ordinary CGF, V4/V7 or G closure claim. New profile first alone.',
        'closure_ids': []}
    target = RUNNER_DIR/(case+'.json')
    assert not target.exists() and not (RUNNER_DIR/case).exists()
    target.write_text(json.dumps(plan,indent=2)+'\n')
    assert json.loads(target.read_text()) == plan
    print(json.dumps({'prepared_only':True,'plan':str(target),'sha256':sha(target.read_bytes()),'runtime':'UNRUN'}))


if __name__ == '__main__':
    main()
