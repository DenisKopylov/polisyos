"""Real stdlib-only behavior checks; no pytest or product imports."""
import hashlib
import importlib.util
import json
import marshal
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import types
import unittest

BASELINE = '--baseline' in sys.argv
if BASELINE:
    sys.argv.remove('--baseline')
else:
    from bounded_call_observer import BoundedCallObserver, ObservationError


class LegacyBaseline:
    """The old all-call mechanism, only for the failing callback-bound witness."""
    def __init__(self, **kwargs):
        self.callback_invocations = 0
    def _callback(self, frame, event, arg):
        self.callback_invocations += 1
    def start(self):
        sys.setprofile(self._callback)
    def stop(self):
        sys.setprofile(None)
    def report(self):
        return {'callback_invocations': self.callback_invocations}


def unrelated():
    return 3


class ObserverBehavior(unittest.TestCase):
    def setUp(self):
        self.scratch = tempfile.TemporaryDirectory(dir=os.environ['OBSERVER_TEST_SCRATCH'])
        self.root = Path(self.scratch.name)
        self.path = self.root / 'owner.py'
        self.path.write_text('from __future__ import annotations\n'
                             'def selected(value):\n    assert value >= 0\n    return value + 1\n'
                             'def outer():\n    def selected(value):\n        return value * 2\n'
                             '    return selected\n')
        self.name = 'stdlib_observer_owner_' + self.root.name
        self.spec = importlib.util.spec_from_file_location(self.name, self.path)
        self.module = importlib.util.module_from_spec(self.spec)
        sys.modules[self.name] = self.module
        self.spec.loader.exec_module(self.module)
        self.owner = {'path': 'owner.py', 'sha256': hashlib.sha256(self.path.read_bytes()).hexdigest(),
                      'names': ['selected']}
        self.observer = None

    def tearDown(self):
        if self.observer is not None:
            self.observer.stop()
        sys.modules.pop(self.name, None)
        self.scratch.cleanup()

    def make(self):
        cls = LegacyBaseline if BASELINE else BoundedCallObserver
        self.observer = cls(root=self.root, owners=[self.owner])
        return self.observer

    def test_100000_repeated_non_target_calls_have_bounded_callbacks(self):
        observer = self.make()
        observer.start()
        for _ in range(100_000):
            self.assertEqual(unrelated(), 3)
        observer.stop()
        report = observer.report()
        print(json.dumps({'test': self._testMethodName, 'callback_invocations': report['callback_invocations'],
                          'non_target_callbacks': report.get('non_target_callbacks'),
                          'distinct_non_target_code_objects': report.get('distinct_non_target_code_objects')}))
        self.assertLess(report['callback_invocations'], 100,
                        'Repeated non-target calls must not dispatch the observer every time')

    @unittest.skipIf(BASELINE, 'Only callback-bound regression is the before mechanism')
    def test_selected_dynamic_and_existing_thread_calls_are_not_missed(self):
        observer = self.make()
        go = threading.Event()
        def work():
            go.wait()
            for value in range(7):
                self.module.selected(value)
        existing = threading.Thread(target=work)
        existing.start()
        observer.start()
        go.set()
        existing.join()
        for value in range(5):
            self.module.selected(value)
        dynamic = self.module.outer()
        self.assertEqual(dynamic(6), 12)
        newer = threading.Thread(target=lambda: self.module.selected(4))
        newer.start()
        newer.join()
        observer.stop()
        report = observer.report()
        counts = {row['qualname']: row['calls'] for row in report['calls'].values()}
        self.assertEqual(counts, {'selected': 13, 'outer.<locals>.selected': 1})
        self.assertEqual(report['errors'], [])
        self.assertGreaterEqual(len(report['thread_ids']), 2)
        self.assertEqual(next(iter(report['calls'].values()))['first_argument_types']['value'], 'builtins.int')
        print(json.dumps({'test': self._testMethodName, 'counts': counts,
                          'thread_ids': report['thread_ids'], 'errors': report['errors']}))

    @unittest.skipIf(BASELINE, 'Not the before regression')
    def test_wrong_code_with_same_name_file_and_owner_is_refused(self):
        observer = self.make()
        observer.start()
        self.module.selected(1)
        altered = self.module.selected.__code__.replace(co_consts=(None, 0, 99))
        self.module.selected.__code__ = altered
        with self.assertRaises(ObservationError):
            self.module.selected(2)
        self.assertTrue(observer.report()['errors'])

    @unittest.skipIf(BASELINE, 'Not the before regression')
    def test_authentic_code_under_a_different_module_owner_is_refused(self):
        observer = self.make()
        observer.start()
        self.module.selected(1)
        foreign = types.ModuleType('foreign_stdlib_owner')
        foreign.__file__ = str(self.root / 'different.py')
        Path(foreign.__file__).write_text('# actual different source owner\n')
        foreign.__spec__ = importlib.util.spec_from_file_location(foreign.__name__, foreign.__file__)
        sys.modules[foreign.__name__] = foreign
        try:
            clone = types.FunctionType(self.module.selected.__code__, foreign.__dict__)
            with self.assertRaises(ObservationError):
                clone(2)
        finally:
            sys.modules.pop(foreign.__name__, None)

    @unittest.skipIf(BASELINE, 'Not the before regression')
    def test_source_bytes_drift_is_refused_before_observation(self):
        observer = self.make()
        self.path.write_text(self.path.read_text() + '# changed\n')
        with self.assertRaises(ObservationError):
            observer.start()

    @unittest.skipIf(BASELINE, 'Not the before regression')
    def test_owner_module_loaded_after_start_is_observed(self):
        observer = self.make()
        late_name = self.name + '_late'
        spec = importlib.util.spec_from_file_location(late_name, self.path)
        late = importlib.util.module_from_spec(spec)
        observer.start()
        sys.modules[late_name] = late
        try:
            spec.loader.exec_module(late)
            self.assertEqual(late.selected(3), 4)
            observer.stop()
            self.assertEqual(sum(row['calls'] for row in observer.report()['calls'].values()), 1)
        finally:
            sys.modules.pop(late_name, None)

    @unittest.skipIf(BASELINE, 'Not the before regression')
    def test_retained_actual_code_is_independently_bound_beyond_its_hash(self):
        from verify_witnesses import verify
        code_output = self.root / 'observed-code'
        code_output.mkdir()
        self.observer = BoundedCallObserver(root=self.root, owners=[self.owner], code_output=code_output)
        self.observer.start()
        self.assertEqual(self.module.selected(2), 3)
        self.observer.stop()
        report = self.observer.report()
        for row in report['calls'].values():
            row['pid'] = os.getpid()
        calls = {'pid': os.getpid(), **report}
        profile = {'pid': os.getpid(), 'assertion_rewrite_config': {'enable_assertion_pass_hook': False}}
        (self.root / 'call-witnesses.json').write_text(json.dumps(calls))
        (self.root / 'native-profile.json').write_text(json.dumps(profile))
        admission = {'product_root': str(self.root), 'owners': [self.owner],
                     'target_predicates': [['owner.py', 'selected']], 'oracle_predicate': ['owner.py', 'selected']}
        self.assertEqual(verify(self.root, admission, compiler_variant=None)['errors'], [])
        row = next(iter(calls['calls'].values()))
        altered = self.module.selected.__code__.replace(co_consts=(None, 0, 99))
        payload = marshal.dumps(altered)
        digest = hashlib.sha256(payload).hexdigest()
        (code_output / (digest + '.marshal')).write_bytes(payload)
        row.update(code_sha256=digest, code_file=digest + '.marshal')
        (self.root / 'call-witnesses.json').write_text(json.dumps(calls))
        errors = verify(self.root, admission, compiler_variant=None)['errors']
        self.assertEqual(errors[0]['reason'], 'actual_code_not_frozen_source_compilation')

    @unittest.skipIf(BASELINE, 'Not the before regression')
    def test_unsupported_actual_interpreter_reports_error(self):
        executable = Path('/usr/bin/python3')
        self.assertTrue(executable.is_file())
        script = ('import json,sys; from bounded_call_observer import BoundedCallObserver,ObservationError; '
                  'o=BoundedCallObserver(root=".",owners=[]); '
                  '\ntry:o.start()\nexcept ObservationError as e: '
                  'print(json.dumps({"python":sys.version,"error":str(e)}));sys.exit(0)'
                  '\nraise SystemExit("unsupported runtime unexpectedly admitted")')
        result = subprocess.run([str(executable), '-B', '-c', script], cwd=Path(__file__).parent,
                                capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        payload = json.loads(result.stdout)
        self.assertIn('unsupported_runtime', payload['error'])
        print(json.dumps({'test': self._testMethodName, 'executable': str(executable),
                          'actual_unsupported_profile': payload}))


if __name__ == '__main__':
    print(json.dumps({'test_process': {'pid': os.getpid(), 'python': sys.version,
                                      'executable': sys.executable}}))
    result = unittest.main(verbosity=2, exit=False).result
    product_modules = sorted(name for name in sys.modules
                             if name == 'polisyos' or name.startswith('polisyos.'))
    print(json.dumps({'complete_loaded_product_namespace_census': product_modules}))
    raise SystemExit(0 if result.wasSuccessful() and not product_modules else 1)
