"""Root-only C96 queued positive, with the retained bounded native supervisor.

The script prepares and runs exactly one fresh case when Root invokes it. Importing
this module runs neither a product import nor a native case.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import importlib.util
import json
import os
import platform
import re
import runpy
import shutil
import signal
import subprocess
import sys
import time
import traceback
import xml.etree.ElementTree as ET
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
PRODUCT = ROOT / "policy-engine"
RAW = ROOT / "LOCAL/raw/e02-execution-20261027"
FRONT = RAW / "repairs/R4-control-front-r1"
WORKORDER = FRONT / "manifest.json"
REFERENCE_PLAN = PRODUCT / (
    "docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/"
    "root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/"
    "deep-task-status-audit-20261027-r1/r37c1.json"
)
GUARD = PRODUCT / (
    "docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/"
    "root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/"
    "root-layer-lib.py"
)
SUPERVISOR = PRODUCT / (
    "docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/"
    "root-postfix-709-q2-helper-actual-20261018/supervise.py"
)
LIVE = ROOT / "LOCAL/raw/root-live-ownership-20261021.json"
HARNESS = PRODUCT / "tests/_helpers/e02_c96_control_harness.py"
PYTHON = PRODUCT / ".venv/bin/python"
NODE = (
    "tests/unit/runtime/http/test_e02_saturated_control_cancellation.py::"
    "test_authenticated_cancellation_advances_while_compute_is_saturated[queued]"
)
PARENT_REQUIRED = {
    "tests/_helpers/e02_c96_control_harness.py",
    "tests/unit/runtime/http/test_e02_saturated_control_cancellation.py",
}
CHILD_REQUIRED = {
    "tests/_helpers/e02_c96_control_harness.py",
    "tests/_helpers/runtime_http.py",
    "src/polisyos/common/async_tools/__init__.py",
    "src/polisyos/runtime/http/cancellation_admission.py",
    "src/polisyos/runtime/http/resilience.py",
    "src/polisyos/runtime/http/routes/control.py",
    "src/polisyos/runtime/http/services/control_plane_store.py",
    "src/polisyos/runtime/http/services/control_worker.py",
}
BRANCH = "codex/e02-unified-local-20261009"
WORKORDER_SHA = "982a1fc28a4785f5ace631af8e30709f2d68321fd2c3ae00c910f2fb80bbdd9c"
FRAGMENT_SHA = "56a5de85bbead034300385917ae76c7718487c044df7311baf1bb8713b02f719"
GUARD_SHA = "4b381f40f830180c0aa3d1a3cc6d091bc5e5f4598660a1824894d7a188351d35"
SUPERVISOR_SHA = "a94a662308270ba3aca96c1d9c75e53a05e37a923a6188d0f464f8ac1e90909e"
CLEARED = (
    "PYTHONPATH",
    "PYTEST_ADDOPTS",
    "PYTEST_PLUGINS",
    "PYTEST_DISABLE_PLUGIN_AUTOLOAD",
    "PYTHONHOME",
    "VIRTUAL_ENV",
)
DISK_START = 8 * 1024**3
DISK_STOP = 6 * 1024**3
RSS_CAP = 2300 * 1024**2
DEADLINE = 600


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def blob(data: bytes) -> str:
    return hashlib.sha1(
        b"blob " + str(len(data)).encode() + b"\0" + data, usedforsecurity=False
    ).hexdigest()


def git(*args: str) -> bytes:
    return subprocess.check_output(["git", "-C", str(ROOT), *args])


def require(ok: object, text: str) -> None:
    if not ok:
        raise RuntimeError(text)


def no_symlink_ancestors(path: Path) -> None:
    """Check each existing directory before exclusive no-follow reservation."""
    require(path.is_absolute(), "reservation parent is not absolute")
    cursor = path
    while True:
        require(
            not cursor.is_symlink() and cursor.is_dir(), "unsafe parent: " + str(cursor)
        )
        if cursor == cursor.parent:
            return
        cursor = cursor.parent


def reserve_case(front: Path, case: str) -> Path:
    """Create only an exclusive fresh case under front/runs; preserve collisions."""
    require(re.fullmatch(r"[A-Za-z0-9_-]{1,16}", case) is not None, "invalid case ID")
    no_symlink_ancestors(front)
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
    parent_fd = os.open(front, flags)
    try:
        if not os.path.lexists(front / "runs"):
            os.mkdir("runs", 0o700, dir_fd=parent_fd)
        run_fd = os.open("runs", flags, dir_fd=parent_fd)
        try:
            run_dir = front / "runs"
            no_symlink_ancestors(run_dir)
            current = run_dir.stat()
            opened = os.fstat(run_fd)
            require(
                (current.st_dev, current.st_ino) == (opened.st_dev, opened.st_ino),
                "runs alias",
            )
            os.mkdir(case, 0o700, dir_fd=run_fd)
            case_fd = os.open(case, flags, dir_fd=run_fd)
            try:
                target = run_dir / case
                stat = target.stat()
                opened_case = os.fstat(case_fd)
                require(
                    (stat.st_dev, stat.st_ino)
                    == (opened_case.st_dev, opened_case.st_ino),
                    "case alias",
                )
            finally:
                os.close(case_fd)
        finally:
            os.close(run_fd)
    finally:
        os.close(parent_fd)
    return target


def write_json(path: Path, value: object) -> str:
    data = (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()
    with path.open("xb") as out:
        out.write(data)
        out.flush()
        os.fsync(out.fileno())
    return sha(data)


def source_pins(head: str, workorder: dict) -> list[dict]:
    """Requalify all listed pins plus the current root conftest."""
    selected = dict(workorder["source_pins"])
    require(len(selected) == 18, "workorder selected-pin denominator changed")
    selected["policy-engine/tests/conftest.py"] = None
    rows = []
    for rel, historic in sorted(selected.items()):
        data = (ROOT / rel).read_bytes()
        committed = git("show", head + ":" + rel)
        index = git("ls-files", "--stage", "--", rel).decode().split()
        require(data == committed, "worktree differs from selected Git input: " + rel)
        require(
            len(index) >= 3 and index[1] == blob(data) and index[2] == "0",
            "index: " + rel,
        )
        row = {
            "path": rel,
            "bytes": len(data),
            "sha256": sha(data),
            "git_blob": blob(data),
        }
        if historic is not None:
            require(
                (row["bytes"], row["sha256"], row["git_blob"])
                == (historic["bytes"], historic["sha256"], historic["git_blob"]),
                "historical selected pin changed; rebind before execution: " + rel,
            )
        rows.append(row)
    return rows


def selected_git_tree(head: str) -> dict[str, str]:
    output = git(
        "ls-tree",
        "-r",
        "-z",
        head,
        "--",
        "policy-engine/src/polisyos",
        "policy-engine/tests",
        "policy-engine/tools",
    )
    mapping = {}
    for row in output.split(b"\0"):
        if not row:
            continue
        header, path = row.split(b"\t", 1)
        mode, kind, oid = header.decode().split()
        require(kind == "blob", "unexpected non-blob selected Git object")
        mapping[path.decode()] = oid
    return mapping


def qualify_readset(
    observation: dict,
    evidence: Path,
    git_index: dict[str, str],
    required: set[str] | None = None,
) -> dict:
    """Recompute every member of this finite source readset against Git and disk."""
    read = observation["readset"]
    filename = read["path"]
    require(
        type(filename) is str
        and Path(filename).name == filename
        and filename.endswith(".json.gz"),
        "unsafe readset locator",
    )
    compressed = (evidence / filename).read_bytes()
    require(sha(compressed) == read["sha256"], "readset output hash differs")
    raw = gzip.decompress(compressed)
    require(
        len(compressed) == read["bytes"] and len(raw) == read["uncompressed_bytes"],
        "readset byte count differs",
    )
    data = json.loads(raw)
    require(data["pid"] == observation["pid"], "readset PID mismatch")
    require(
        data["source_qualified"] is True and data["foreign_source_modules"] == [],
        "observer source refusal",
    )
    rows = data["files"]
    require(len(rows) == read["python_paths"], "readset count mismatch")
    seen = set()
    for row in rows:
        rel = row["path"]
        path = Path(rel)
        require(
            type(rel) is str
            and not path.is_absolute()
            and ".." not in path.parts
            and rel.endswith(".py")
            and path.parts[0] in {"src", "tests", "tools"}
            and (path.parts[0] != "src" or path.parts[:2] == ("src", "polisyos")),
            "unexpected readset path",
        )
        require(rel not in seen, "duplicate source readset path")
        seen.add(rel)
        current = (PRODUCT / path).resolve()
        require(
            current.is_relative_to(PRODUCT.resolve()) and current.is_file(),
            "readset source absent",
        )
        contents = current.read_bytes()
        git_rel = "policy-engine/" + rel
        expected_blob = git_index.get(git_rel)
        require(
            expected_blob is not None
            and row["git_blob"] == row["actual_blob"] == expected_blob == blob(contents)
            and row["sha256"] == sha(contents)
            and row["git_match"] is True,
            "readset Git/worktree mismatch: " + rel,
        )
    require((required or set()) <= seen, "required finite readset members missing")
    return {
        "pid": data["pid"],
        "required_paths": sorted(required or set()),
        "path": str((evidence / filename).relative_to(ROOT)),
        "sha256": sha(compressed),
        "python_paths": len(rows),
        "scope": "finite loaded first-party Python source at observer readout",
        "native_and_unloaded": "NOT_ESTABLISHED",
    }


def property_checks(observed: dict) -> list[str]:
    """Read actual durable/HTTP observations; never treat status alone as proof."""
    queue = observed["queue"]
    durable = observed["persisted"]
    run = observed["running"]
    fresh = observed["fresh_http"]
    renewal = observed["renewal"]
    negatives = observed["adversarial"]
    expected_negatives = {
        "disabled-rollout",
        "denied-permission",
        "wrong-tenant",
        "stale-attempt",
        "body-proof-substitution",
    }
    checks = {
        "actual_queue_held": queue["accepted_pending"] is True
        and queue["running_physical"] is True
        and queue["queued_body_calls"] == 0
        and queue["physical_workers"] == 1
        and queue["queued_jobs"] == 1
        and queue["outstanding_jobs"] == 2
        and queue["overflow_code"] == "shared_executor_queue_full"
        and queue["cancelled_queued"] is False,
        "real_catalog_reader": observed["catalog"]["real_reader_identity_matches"]
        is True,
        "heartbeat_while_held": renewal["after"] > renewal["before"]
        and renewal["calls_under_held_compute"] > 0,
        "control_entry": observed["positive_current_authority_calls"] > 0
        and observed["positive_control_entry_calls"] > 0
        and observed["positive_control_body_calls"] > 0,
        "adversarial_zero_effect": len(negatives) == len(expected_negatives)
        and {row["kind"] for row in negatives} == expected_negatives
        and all(
            row["status"] >= 400 and row["zero_protected_effects"] is True
            for row in negatives
        ),
        "durable_cancellation": durable["state"] == "cancelled"
        and durable["verified"] is True
        and durable["attempt"] == run["attempt"]
        and durable["lease_owner"] is None
        and durable["manifest_ref"] == run["manifest_ref"]
        and durable["cancellation_event_count"]
        == durable["cancellation_outbox_count"]
        == 1
        and durable["other_terminal_count"] == 0
        and durable["progress_preserved"] is True
        and durable["physical_stop_status"] == "not_established",
        "fresh_http": fresh["status"] == 200
        and fresh["state"] == "cancelled"
        and fresh["execution_status"] == "cancelled"
        and fresh["physical_stop_status"] == "not_established"
        and fresh["cancellation_disposition"] == "publication_fenced",
        "idempotent_retry": observed["post"]["status"]
        == observed["retry"]["status"]
        == 200,
        "late_fenced": observed["late_refused"]
        == {"progress": True, "manifest": True, "terminal": True},
        "held_until_readback": observed["held_until_readback"] is True,
        "queue_release": observed["queue_after_release"]["queued_body_calls"] == 1
        and observed["queue_after_release"]["queued_jobs"] == 0
        and observed["queue_after_release"]["outstanding_jobs"] == 0,
        "no_thread_errors": not observed["thread_errors"],
    }
    return [key for key, value in checks.items() if not value]


def qualify_case(
    out: Path, head: str, tree: str, result: dict, argv: list[str]
) -> dict:
    """Distinguish source/fixture errors from a test failure or bounded positive."""
    errors = []
    prop_failures: list[str] = []
    facts = {}
    try:
        parent_dir = out / "evidence/parent"
        child_dir = out / "evidence/queued"
        parent = json.loads((parent_dir / "parent-process.json").read_bytes())
        child = json.loads((child_dir / "observation.json").read_bytes())
        require(
            parent["stage"] == "pytest_finished" and child["stage"] == "complete",
            "prelude/fixture not complete",
        )
        require(
            parent["source"] == parent["source_after"] == [head, tree],
            "parent source mismatch",
        )
        require(child["source"] == [head, tree], "child source mismatch")
        require(
            parent["pytest_not_yet_imported"] is True
            and parent["initial_private_pycache_empty"] is True,
            "parent startup not qualified",
        )
        require(
            parent["collected_node_ids_after_deselection"] == [NODE],
            "selected pytest node differs",
        )
        require(parent["argv"] == argv[2:], "parent actual argv differs")
        require(parent["pytest"]["importmode"] == "importlib", "import mode changed")
        require(
            "--strict-markers" in parent["pytest"]["ini_addopts"],
            "strict markers absent",
        )
        for process in (parent, child):
            environment = process["environment"]
            require(
                environment["PYTHONDONTWRITEBYTECODE"] == "1"
                and environment["PYTHONPYCACHEPREFIX"] == str(out / "pycache")
                and all(
                    environment[key] == "1"
                    for key in (
                        "OMP_NUM_THREADS",
                        "OPENBLAS_NUM_THREADS",
                        "MKL_NUM_THREADS",
                        "NUMEXPR_NUM_THREADS",
                    )
                ),
                "process environment differs",
            )
        require(
            parent["sys_pycache_prefix"] == str(out / "pycache"),
            "pycache prefix differs",
        )
        require(
            Path(parent["pytest"]["inipath"]).resolve()
            == (PRODUCT / "pytest.ini").resolve(),
            "pytest ini changed",
        )
        require(
            parent["environment"]["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] is None
            and not parent["environment"]["PYTEST_ADDOPTS"],
            "pytest ambient controls persisted",
        )
        require(
            parent["pytest"]["pid"] == parent["pid"] and child["ppid"] == parent["pid"],
            "process chain differs",
        )
        require(
            child["case"]["cancel_queued"] is False
            and child["case"]["remove_write_capacity"] is False,
            "not positive queued case",
        )
        expected_python = PYTHON.resolve()
        require(
            Path(parent["executable"]).resolve() == expected_python
            and Path(child["executable"]).resolve() == expected_python,
            "interpreter mismatch",
        )
        index = selected_git_tree(head)
        parent_read = qualify_readset(parent, parent_dir, index, PARENT_REQUIRED)
        child_read = qualify_readset(child, child_dir, index, CHILD_REQUIRED)
        prop_failures = property_checks(child)
        facts = {
            "parent_pid": parent["pid"],
            "child_pid": child["pid"],
            "parent_readset": parent_read,
            "child_readset": child_read,
            "parent_observation_sha256": sha(
                (parent_dir / "parent-process.json").read_bytes()
            ),
            "child_observation_sha256": sha(
                (child_dir / "observation.json").read_bytes()
            ),
            "versions": parent["versions"],
        }
        cases = list(ET.parse(out / "junit.xml").getroot().iter("testcase"))
        require(
            len(cases) == 1 and cases[0].get("name") == NODE.split("::")[-1],
            "JUnit node differs",
        )
        require(
            cases[0].find("skipped") is None and cases[0].find("error") is None,
            "JUnit skipped/error",
        )
        failure = cases[0].find("failure") is not None
        require(
            result.get("complete") is True and result.get("aborted_reason") is None,
            "supervisor incomplete",
        )
        require(
            parent["pytest_exitstatus"] == result["return_code"],
            "pytest/launcher exit differs",
        )
        if failure:
            require(
                result["return_code"] != 0 and bool(prop_failures),
                "failure is not the qualified property",
            )
        else:
            require(
                result["return_code"] == 0 and not prop_failures,
                "positive property or exit mismatch",
            )
        verdict = "FAIL" if failure else "PASS"
    except (
        OSError,
        ValueError,
        KeyError,
        TypeError,
        ET.ParseError,
        RuntimeError,
    ) as exc:
        errors.append(type(exc).__name__ + ": " + str(exc))
        verdict = "ERROR"
    return {
        "outcome": verdict,
        "errors": errors,
        "property_failures": prop_failures,
        **facts,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case-id", required=True)
    parser.add_argument("--expected-head", required=True)
    parser.add_argument("--expected-tree", required=True)
    parser.add_argument("--controller-sha256", required=True)
    args = parser.parse_args()
    require(
        sys.version_info[:2] == (3, 14) and sys.flags.isolated == 1,
        "use existing venv Python 3.14 with -I -B",
    )
    require(
        sys.dont_write_bytecode
        and Path(sys.prefix).resolve() == (PRODUCT / ".venv").resolve(),
        "wrong interpreter",
    )
    require(
        sha(Path(__file__).read_bytes()) == args.controller_sha256,
        "controller SHA mismatch",
    )
    require(sha(WORKORDER.read_bytes()) == WORKORDER_SHA, "workorder mismatch")
    require(
        sha((FRONT / "README.md").read_bytes())
        == "611bb3284df636822289ddfe4cc495b237affa50d92546012bc95e64a985e142",
        "workorder README mismatch",
    )
    require(
        sha(GUARD.read_bytes()) == GUARD_SHA
        and sha(SUPERVISOR.read_bytes()) == SUPERVISOR_SHA,
        "retained helper mismatch",
    )
    git_controls = sorted(key for key in os.environ if key.startswith("GIT_"))
    require(
        not [
            key
            for key in git_controls
            if key not in {"GIT_PAGER", "GIT_TERMINAL_PROMPT"}
        ],
        "unsupported inherited Git controls: " + repr(git_controls),
    )
    require(
        git("symbolic-ref", "--short", "HEAD").decode().strip() == BRANCH,
        "branch mismatch",
    )
    head, tree = git("rev-parse", "HEAD", "HEAD^{tree}").decode().splitlines()
    require((head, tree) == (args.expected_head, args.expected_tree), "source mismatch")
    require(
        not git("status", "--porcelain", "--untracked-files=no"),
        "tracked tree/index is dirty",
    )
    live = json.loads(LIVE.read_bytes())
    require(live["known_dirty_paths"] == [], "root owns dirty paths")
    guard = runpy.run_path(str(GUARD))["guard"]
    before = guard()
    require(
        before["head"] == head and live["tree"] == tree, "root live source mismatch"
    )
    workorder = json.loads(WORKORDER.read_bytes())
    pins = source_pins(head, workorder)
    reference = json.loads(REFERENCE_PLAN.read_bytes())
    fragment = reference["sandbox_profile_fragment"]
    require(sha(fragment.encode()) == FRAGMENT_SHA, "sandbox fragment mismatch")
    require(shutil.disk_usage(ROOT).free >= DISK_START, "8 GiB disk admission unmet")
    require(
        "POLISYOS_C96_REMOVE_CONTROL_WRITE_CAPACITY" not in os.environ,
        "removal mode is not permitted",
    )
    inherited = sorted(
        key
        for key in os.environ
        if key.startswith(("PYTHON", "PYTEST", "POLISYOS_C96_")) or key == "VIRTUAL_ENV"
    )
    unknown_pytest = [
        key for key in inherited if key.startswith("PYTEST_") and key not in CLEARED
    ]
    require(
        not unknown_pytest,
        "unsupported inherited pytest controls: " + repr(unknown_pytest),
    )
    allowed_python = set(CLEARED) | {
        "PYTHONPYCACHEPREFIX",
        "PYTHONDONTWRITEBYTECODE",
        "PYTHONUNBUFFERED",
    }
    unknown_python = [
        key
        for key in inherited
        if key.startswith("PYTHON") and key not in allowed_python
    ]
    require(
        not unknown_python,
        "unsupported inherited Python controls: " + repr(unknown_python),
    )
    allowed_c96 = {
        "POLISYOS_C96_EVIDENCE_DIR",
        "POLISYOS_C96_EXPECTED_HEAD",
        "POLISYOS_C96_EXPECTED_TREE",
    }
    unknown_c96 = [
        key
        for key in inherited
        if key.startswith("POLISYOS_C96_") and key not in allowed_c96
    ]
    require(not unknown_c96, "unsupported inherited C96 controls: " + repr(unknown_c96))
    cleared = [key for key in CLEARED if key in os.environ]
    for key in CLEARED:
        os.environ.pop(key, None)
    out = reserve_case(FRONT, args.case_id)
    for name in ("pycache", "tmp", "benchmarks", "evidence"):
        (out / name).mkdir(mode=0o700)
    require(not any((out / "pycache").iterdir()), "pycache not initially empty")
    profile = (
        "(version 1)\n(allow default)\n(deny file-write*)\n(allow file-write* (subpath "
        + json.dumps(str(out))
        + '))\n(allow file-write* (literal "/dev/null"))\n'
        + fragment
    )
    sandbox = out / "sandbox.sb"
    with sandbox.open("x") as stream:
        stream.write(profile)
    env = {
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONPYCACHEPREFIX": str(out / "pycache"),
        "TMPDIR": str(out / "tmp"),
        "XDG_CACHE_HOME": str(out / "tmp/xdg"),
        "MPLCONFIGDIR": str(out / "tmp/mpl"),
        "NUMBA_CACHE_DIR": str(out / "tmp/numba"),
        "HYPOTHESIS_STORAGE_DIRECTORY": str(out / "tmp/hypothesis"),
        "POLISYOS_C96_EVIDENCE_DIR": str(out / "evidence"),
        "POLISYOS_C96_EXPECTED_HEAD": head,
        "POLISYOS_C96_EXPECTED_TREE": tree,
        "SCIENTIST_TORCH_NUM_THREADS": "1",
        "SCIENTIST_TORCH_NUM_INTEROP_THREADS": "1",
    }
    argv = [
        str(PYTHON),
        "-B",
        str(HARNESS),
        "--observe-pytest",
        "-q",
        "-ra",
        "-o",
        "cache_dir=" + str(out / "pytest-cache"),
        "--benchmark-storage=file://" + str(out / "benchmarks"),
        "--basetemp",
        str(out / "pytest-tmp"),
        "--junitxml",
        str(out / "junit.xml"),
        NODE,
    ]
    monitor_spec = importlib.util.spec_from_file_location(
        "r4_retained_supervisor", SUPERVISOR
    )
    require(
        monitor_spec is not None and monitor_spec.loader is not None,
        "supervisor unavailable",
    )
    monitor = importlib.util.module_from_spec(monitor_spec)
    sys.modules[monitor_spec.name] = monitor
    monitor_spec.loader.exec_module(monitor)
    monitor.RSS_CAP_BYTES = RSS_CAP
    monitor.DISK_FLOOR_BYTES = DISK_STOP
    monitor.SAMPLE_SECONDS = 1.0
    signal.signal(signal.SIGTERM, monitor.note_stop_signal)
    signal.signal(signal.SIGINT, monitor.note_stop_signal)
    inputs = [
        WORKORDER,
        FRONT / "README.md",
        REFERENCE_PLAN,
        GUARD,
        SUPERVISOR,
        LIVE,
        Path(__file__),
    ]
    frame = ROOT / live["source_readback"]["path"]
    inputs.append(frame)
    input_hashes = {str(p.relative_to(ROOT)): sha(p.read_bytes()) for p in inputs}
    resources = {
        "disk_free_bytes": shutil.disk_usage(ROOT).free,
        "cpu_count": os.cpu_count(),
        "platform": platform.platform(),
    }
    for name, command in (
        ("memory_pressure", ["/usr/bin/memory_pressure"]),
        ("memory_total", ["/usr/sbin/sysctl", "-n", "hw.memsize"]),
    ):
        proc = subprocess.run(command, capture_output=True, text=True, check=False)
        resources[name] = {
            "exit": proc.returncode,
            "stdout": proc.stdout,
            "stderr": proc.stderr,
        }
    plan = {
        "schema": "e02-r4-c96-native-pilot-v1",
        "created_at": datetime.now(UTC).isoformat(),
        "source_head": head,
        "source_tree": tree,
        "branch": BRANCH,
        "root_guard_before": before,
        "workorder_sha256": WORKORDER_SHA,
        "selected_source_pins": pins,
        "selected_pin_denominator": len(pins),
        "inputs": input_hashes,
        "argv": argv,
        "cwd": str(PRODUCT),
        "extra_env": env,
        "inherited_control_names_only": inherited,
        "inherited_git_control_names_only": git_controls,
        "cleared_control_names": cleared,
        "numeric_threads": monitor.NUMERIC_THREADS,
        "sandbox_sha256": sha(profile.encode()),
        "sandbox_fragment_sha256": FRAGMENT_SHA,
        "sandbox_scope": "localhost exception includes wildcard bind",
        "resources_before": resources,
        "disk_admission_bytes": DISK_START,
        "disk_stop_bytes": DISK_STOP,
        "rss_cap_bytes": RSS_CAP,
        "deadline_seconds": DEADLINE,
        "closure_ids": [],
    }
    plan_hash = write_json(out / "plan.json", plan)
    result = {}
    qualification = {"outcome": "ERROR", "errors": ["not launched"]}
    errors = []
    try:
        started = time.monotonic()
        result = monitor.run_command(
            out,
            "c96-queued",
            ["/usr/bin/sandbox-exec", "-f", str(sandbox), *argv],
            PRODUCT,
            started,
            started + DEADLINE,
            env,
        )
        qualification = qualify_case(out, head, tree, result, argv)
    except BaseException as exc:
        errors.append(type(exc).__name__ + ": " + str(exc))
        errors.append(traceback.format_exc())
    try:
        after = guard()
        require(
            after["head"] == head
            and git("rev-parse", "HEAD^{tree}").decode().strip() == tree,
            "source moved during run",
        )
        require(
            not git("status", "--porcelain", "--untracked-files=no"),
            "tracked source became dirty",
        )
        require(source_pins(head, workorder) == pins, "selected source inputs changed")
        for rel, expected in input_hashes.items():
            require(
                sha((ROOT / rel).read_bytes()) == expected,
                "consumed input changed: " + rel,
            )
        require(sha((out / "plan.json").read_bytes()) == plan_hash, "plan changed")
        require(sha(sandbox.read_bytes()) == sha(profile.encode()), "sandbox changed")
    except BaseException as exc:
        after = None
        errors.append("post-run identity: " + type(exc).__name__ + ": " + str(exc))
    if errors:
        qualification["outcome"] = "ERROR"
        qualification.setdefault("errors", []).extend(errors)
    deciding_outputs = []
    for rel in (
        "c96-queued.stdout.txt",
        "c96-queued.stderr.txt",
        "junit.xml",
        "evidence/parent/parent-process.json",
        "evidence/queued/observation.json",
    ):
        path = out / rel
        if path.is_file():
            data = path.read_bytes()
            deciding_outputs.append(
                {
                    "path": str(path.relative_to(ROOT)),
                    "bytes": len(data),
                    "sha256": sha(data),
                }
            )
    receipt = {
        "deciding_outputs": deciding_outputs,
        "schema": "e02-r4-c96-native-pilot-receipt-v1",
        "finished_at": datetime.now(UTC).isoformat(),
        "plan_sha256": plan_hash,
        "source_head": head,
        "source_tree": tree,
        "supervisor": result,
        "qualification": qualification,
        "root_guard_after": after,
        "disk_free_after_bytes": shutil.disk_usage(ROOT).free,
        "limitations": [
            "fixture principal/policy only",
            "event-held compute, no native fit",
            "no removal/restoration in this run",
            "finite loaded Python readsets only",
            "no production authority or external currentness",
            "G acceptance false",
        ],
        "closure_ids": [],
    }
    receipt_sha = write_json(out / "audit-result.json", receipt)
    print(
        json.dumps(
            {
                "case": str(out),
                "outcome": qualification["outcome"],
                "errors": qualification.get("errors"),
                "receipt_sha256": receipt_sha,
            }
        )
    )
    return 0 if qualification["outcome"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
