"""Finite fake-pytest fault matrix for complete setup observation finalization."""

from __future__ import annotations

import argparse
import contextlib
import hashlib
import importlib.util
import io
import json
import os
import sys
import types
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--plugin", type=Path, required=True)
parser.add_argument("--scratch", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
args.scratch.mkdir(parents=True, exist_ok=False)
if os.path.lexists(args.output):
    raise RuntimeError("output exists")
fake = types.ModuleType("pytest")
fake.hookimpl = lambda **_kwargs: lambda fn: fn
sys.modules["pytest"] = fake
spec = importlib.util.spec_from_file_location("q2_setup_fake", args.plugin)
if spec is None or spec.loader is None:
    raise RuntimeError("plugin loader unavailable")
guard = importlib.util.module_from_spec(spec)
spec.loader.exec_module(guard)
guard.D = args.scratch
original_env = os.environ
original_open = Path.open
original_snapshot = guard._resource_snapshot
results: dict[str, dict[str, object]] = {}


class BrokenEnvironment:
    def __init__(self, problem: BaseException) -> None:
        self.problem = problem

    def keys(self) -> object:
        raise self.problem

    def __getitem__(self, _key: object) -> object:
        raise self.problem


class BrokenStderr:
    def write(self, _message: str) -> None:
        raise OSError("stderr sentinel")


def run(
    name: str,
    *,
    primary: bool,
    snapshots: bool = False,
    env: bool = False,
    receipt: bool = False,
    stderr: bool = False,
    interrupt: bool = True,
    primary_interrupt: bool = False,
) -> None:
    case = args.scratch / name
    (case / "tmp").mkdir(parents=True)
    original_env["E02_Q2_CASE_ID"] = name
    item = types.SimpleNamespace(nodeid=guard.NODE, funcargs={})
    primary_error = (
        KeyboardInterrupt("primary setup interrupt")
        if primary_interrupt
        else ValueError("primary setup sentinel")
    )
    problem = (
        KeyboardInterrupt("observation sentinel") if interrupt else OSError("observation sentinel")
    )
    snapshot_count = 0

    def snapshot(_item: object) -> dict[str, str]:
        nonlocal snapshot_count
        snapshot_count += 1
        if snapshots and snapshot_count == 2:
            raise problem
        return {"cwd": "synthetic"}

    def bad_open(path: Path, *a: object, **kw: object) -> object:
        if receipt and path == case / "tmp" / guard.SETUP_RECEIPT:
            raise problem
        return original_open(path, *a, **kw)

    guard._resource_snapshot = snapshot
    Path.open = bad_open
    hook = guard.pytest_runtest_setup(item)
    next(hook)
    if env:
        os.environ = BrokenEnvironment(problem)  # noqa: B003 -- inject snapshot failure
    caught: BaseException | None = None
    stderr_target = BrokenStderr() if stderr else io.StringIO()
    try:
        with contextlib.redirect_stderr(stderr_target):
            try:
                if primary:
                    hook.throw(primary_error)
                else:
                    next(hook)
            except BaseException as exc:
                caught = exc
    finally:
        os.environ = original_env  # noqa: B003 -- restore the original object
        Path.open = original_open
        guard._resource_snapshot = original_snapshot
    trace = getattr(guard, "_SETUP_TRACES", {}).get(id(item), {})
    errors = trace.get("observation_errors", [])
    names = {e.get("operation") for e in errors if isinstance(e, dict)}
    expected = set()
    if snapshots:
        expected.add("after_snapshot")
    if env:
        expected.add("after_environment")
    if receipt:
        expected.add("setup_receipt")
    if stderr:
        expected.add("error_report")
    preserved = caught is primary_error if primary else caught is problem
    results[name] = {
        "pass": preserved and bool(trace) and expected <= names,
        "primary_identity_preserved_or_interrupt_propagated": preserved,
        "trace_exists": bool(trace),
        "error_operations": sorted(names),
        "expected_operations": sorted(expected),
        "caught_type": type(caught).__name__ if caught else None,
    }


try:
    run("primary-snapshot-interrupt", primary=True, snapshots=True)
    run("primary-interrupt-stays-primary", primary=True, snapshots=True, primary_interrupt=True)
    run("primary-env-oserror", primary=True, env=True, interrupt=False)
    run("primary-receipt-interrupt", primary=True, receipt=True)
    run(
        "primary-all-observation-failures",
        primary=True,
        snapshots=True,
        env=True,
        receipt=True,
        stderr=True,
    )
    run("no-primary-snapshot-interrupt", primary=False, snapshots=True)
    run("no-primary-env-interrupt", primary=False, env=True)
    run("no-primary-receipt-interrupt", primary=False, receipt=True)
    # A normal setup result must be returned unchanged when observation succeeds.
    case = args.scratch / "normal-result"
    (case / "tmp").mkdir(parents=True)
    original_env["E02_Q2_CASE_ID"] = case.name
    item = types.SimpleNamespace(nodeid=guard.NODE, funcargs={})
    marker = object()
    guard._resource_snapshot = lambda _item: {"cwd": "synthetic"}
    hook = guard.pytest_runtest_setup(item)
    next(hook)
    try:
        hook.send(marker)
    except StopIteration as exc:
        result_identity = exc.value is marker
    else:
        result_identity = False
    trace = getattr(guard, "_SETUP_TRACES", {}).get(id(item), {})
    results["normal-setup-result-preserved"] = {
        "pass": result_identity and bool(trace),
        "result_identity": result_identity,
        "trace_exists": bool(trace),
    }

    # An ordinary observation error must block the later call, not yield a fake PASS.
    case = args.scratch / "normal-observation-error"
    (case / "tmp").mkdir(parents=True)
    original_env["E02_Q2_CASE_ID"] = case.name
    item = types.SimpleNamespace(nodeid=guard.NODE, funcargs={})
    snapshot_count = [0]

    def ordinary_fault(_item: object) -> dict[str, str]:
        snapshot_count[0] += 1
        if snapshot_count[0] == 2:
            raise OSError("ordinary observation sentinel")
        return {"cwd": "synthetic"}

    guard._resource_snapshot = ordinary_fault
    hook = guard.pytest_runtest_setup(item)
    next(hook)
    with contextlib.suppress(StopIteration):
        next(hook)
    try:
        guard._validate(item)
    except RuntimeError as exc:
        blocked = "setup_observation_error" in str(exc)
    else:
        blocked = False
    results["ordinary-observation-error-blocks-call"] = {"pass": blocked}

    # An interrupt before setup has no primary outcome and must escape unchanged.
    pre_interrupt = KeyboardInterrupt("before setup sentinel")
    guard._resource_snapshot = lambda _item: (_ for _ in ()).throw(pre_interrupt)
    hook = guard.pytest_runtest_setup(item)
    try:
        next(hook)
    except BaseException as exc:
        propagated = exc is pre_interrupt
    else:
        propagated = False
    results["before-setup-interrupt-propagates"] = {"pass": propagated}

    # Even failure of the in-memory trace store cannot replace a setup exception.
    class BrokenTrace(dict):
        def __setitem__(self, _key: object, _value: object) -> None:
            raise OSError("trace store sentinel")

    case = args.scratch / "trace-store-failure"
    (case / "tmp").mkdir(parents=True)
    original_env["E02_Q2_CASE_ID"] = case.name
    guard._resource_snapshot = lambda _item: {"cwd": "synthetic"}
    old_traces = guard._SETUP_TRACES
    guard._SETUP_TRACES = BrokenTrace()
    primary_error = ValueError("trace store primary")
    hook = guard.pytest_runtest_setup(item)
    next(hook)
    captured = io.StringIO()
    try:
        with contextlib.redirect_stderr(captured):
            try:
                hook.throw(primary_error)
            except BaseException as exc:
                preserved = exc is primary_error
            else:
                preserved = False
    finally:
        guard._SETUP_TRACES = old_traces
    results["trace-store-failure-preserves-primary"] = {
        "pass": preserved and "q2_setup_trace_unavailable" in captured.getvalue()
    }

    store_interrupt = KeyboardInterrupt("trace store interrupt")

    class InterruptTrace(dict):
        def __setitem__(self, _key: object, _value: object) -> None:
            raise store_interrupt

    case = args.scratch / "trace-store-interrupt"
    (case / "tmp").mkdir(parents=True)
    original_env["E02_Q2_CASE_ID"] = case.name
    guard._SETUP_TRACES = InterruptTrace()
    hook = guard.pytest_runtest_setup(item)
    next(hook)
    try:
        with contextlib.redirect_stderr(io.StringIO()):
            try:
                next(hook)
            except BaseException as exc:
                propagated = exc is store_interrupt
            else:
                propagated = False
    finally:
        guard._SETUP_TRACES = old_traces
    results["trace-store-interrupt-propagates"] = {"pass": propagated}
finally:
    os.environ = original_env  # noqa: B003 -- restore the original object
    Path.open = original_open
    guard._resource_snapshot = original_snapshot


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


report = {
    "scope": "synthetic fake pytest; no product imports or native run",
    "plugin_sha256": sha(args.plugin),
    "control_sha256": sha(Path(__file__)),
    "checks": results,
    "passed": sum(bool(value["pass"]) for value in results.values()),
    "total": len(results),
    "runtime": "UNRUN",
}
with args.output.open("x", encoding="utf-8") as f:
    json.dump(report, f, indent=2, sort_keys=True)
    f.write("\n")
sys.stdout.write(json.dumps(report, sort_keys=True) + "\n")
raise SystemExit(0 if report["passed"] == report["total"] else 1)
