"""Build the source-bound R165 test patch using stdlib only."""
import ast
import difflib
import hashlib
import json
import subprocess
from pathlib import Path

repo = Path.cwd()
raw = repo / "LOCAL/raw/e02-execution-20261027/runtime-prep/R165-basis-test-fixture-repair-r1"
relative = "policy-engine/tests/unit/runtime/quality/test_generation_cycle.py"
source = repo / relative
postimage = raw / "postimages" / relative
head = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
tree = subprocess.check_output(["git", "rev-parse", "HEAD^{tree}"], text=True).strip()
expected_head = "80e2bd118c40d97db1601fe58d8dd8ec165a5f67"
expected_preimage = "0a2769a502d3a4e2682dbbacf37f80f3601741d4ec2bb3278574c7e6d7a549dc"
if head != expected_head:
    raise RuntimeError("HEAD changed; reconcile the journal before repinning")
if json.loads((repo / "LOCAL/raw/root-live-ownership-20261021.json").read_text())["head"] != head:
    raise RuntimeError("ownership journal mismatch")
before = source.read_bytes()
after = postimage.read_bytes()
if hashlib.sha256(before).hexdigest() != expected_preimage:
    raise RuntimeError("source preimage changed")
if subprocess.check_output(["git", "show", f"{head}:{relative}"]) != before:
    raise RuntimeError("working source differs from committed blob")
ast.parse(after, filename=relative)
patch = [f"diff --git a/{relative} b/{relative}\n"]
patch.extend(difflib.unified_diff(before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True), fromfile=f"a/{relative}", tofile=f"b/{relative}", n=3))
patch_file = raw / "proposal.patch"
patch_file.write_text("".join(patch))
check = subprocess.run(["git", "apply", "--check", str(patch_file)], cwd=repo, capture_output=True)
inv = subprocess.run(["python3", str(raw / "assertion_inventory.py")], cwd=repo, capture_output=True)
(raw / "assertion-inventory.stdout.json").write_bytes(inv.stdout)
receipt = {"patch_check": {"exit_code": check.returncode, "stdout": check.stdout.decode(), "stderr": check.stderr.decode()}, "assertion_inventory": {"exit_code": inv.returncode, "stdout_file": "assertion-inventory.stdout.json", "stdout_sha256": hashlib.sha256(inv.stdout).hexdigest(), "stderr": inv.stderr.decode()}}
(raw / "verification.json").write_text(json.dumps(receipt, indent=2) + "\n")
manifest = {"status": "unreviewed RAW candidate; runtime unrun", "head": head, "tree": tree, "path": relative, "preimage_sha256": hashlib.sha256(before).hexdigest(), "postimage_sha256": hashlib.sha256(after).hexdigest(), "patch_sha256": hashlib.sha256(patch_file.read_bytes()).hexdigest(), "patch_check_exit": check.returncode, "assertion_inventory_exit": inv.returncode}
(raw / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps(manifest, indent=2))
if check.returncode or inv.returncode:
    raise SystemExit(1)
