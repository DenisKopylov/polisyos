from pathlib import Path
p=Path('LOCAL/raw/e02-execution-20261027/repairs/C41-r9/postimages/policy-engine')
f=p/'src/polisyos/runtime/http/routes/README.md';s=f.read_text()
a='''When a parent read returns
a `not_established` projection, its limitation is reported separately from readable children.
A `CanonicalProfileRefusalError` during the parent result read can instead escape the projection
and abort the GET, so independently readable child rows are not guaranteed to be returned in that
case.'''
b='''An unavailable or invalid selected parent-result view leaves its parent status
`not_established` with a typed limitation, while independently replayed child rows remain available.
A known selected-view tenant/cell mismatch or a typed ownership denial refuses the GET without
returning child data; an ordinary backing-filesystem permission failure produces a dependency
refusal rather than an inferred tenant denial. A selected-view verifier reopens the original owner,
raw/typed manifest and body bytes instead of interpreting `has` or `verify=False` as permission
proof. This bounded behavior covers selected N5 parent/child replay; other earlier source failures
can still prevent the projection.'''
assert s.count(a)==1;s=s.replace(a,b)
a='''replayed child rows remain in the projection for those child-owner outcomes. This does not cover the
parent profile-read exception described above. A selected artifact reference locates bytes for a separately''';b='''replayed child rows remain in the projection for those child-owner outcomes. A selected artifact reference locates bytes for a separately''';assert s.count(a)==1;s=s.replace(a,b);f.write_text(s)
f=p/'src/polisyos/core/artifacts/README.md';s=f.read_text();needle='''### Atomic local byte replacement
''';insert='''### Scoped selected-profile verification

`SelectedProfileVerificationReader` delegates operations to the supplied artifact owner and offers
an opt-in `verify` that directly reopens the selected raw and typed manifest and body bytes before
using the existing Core integrity report. It preserves actual read errors rather than interpreting
an owner's boolean existence or failed report as an access decision. The general store `has` and
`verify` contracts are unchanged. `raise_artifact_read_access_error` preserves typed ownership and
ordinary filesystem permission errors through explicit exception causes while leaving typed owner
unavailability distinct; the caller must decide its own response. Neither helper grants access,
proves numerical producer identity, or establishes authority or currentness.

''';assert s.count(needle)==1;s=s.replace(needle,insert+needle);f.write_text(s)
f=p/'release-fragments/unreleased/2026-10-28-e02-generic-joint-owner-projection.toml';s=f.read_text();s=s.replace('''  "src/polisyos/core/artifacts/ownership.py",
''','''  "src/polisyos/core/artifacts/ownership.py",
  "src/polisyos/core/artifacts/selected_verification.py",
  "src/polisyos/core/artifacts/README.md",
  "tests/unit/core/artifacts/test_selected_profile_verification_reader.py",
''')
a='''A parent result CanonicalProfileRefusalError can abort the whole GET rather than retain independently readable child rows; a mixed-sibling parent-read falsifier remains unrun.'''
b='''Parent result unavailability or invalidity is projected separately from readable children; typed ownership denial and filesystem permission failures refuse the GET without child rows. Authored mixed-sibling and after-initial-read removal witnesses remain unrun.''';assert s.count(a)==1;s=s.replace(a,b)
s += '''
[[compatibility_change]]
id = "selected-profile-verification-reader"
change_class = "python-public-api"
impact = "additive"
surface = "public_stable: polisyos.core.artifacts"
owner = "team-policyos-runtime"
version_owner = "team-core"
deprecation_window = "not_applicable"
release_note = "An opt-in selected-profile replay reader reopens owner bytes and preserves typed access failures without changing store has or verify."
generated_client_compatibility = "not_applicable"
public_surface_inventory_reviewed = false
migration_docs = ["src/polisyos/core/artifacts/README.md"]
runbook_docs = []
''';f.write_text(s)
