"""Bind an existing R2 plan to the one-node isolated-cwd pytest plugin."""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
P = ROOT / "policy-engine"
D = P / (
    "docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/"
    "root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/"
    "deep-task-status-audit-20261027-r1"
)
HERE = Path(__file__).resolve().parent
PLUGIN_DIR = HERE / "plugin"
PLUGIN = PLUGIN_DIR / "e02_q2_cwd_guard.py"
TEST = "tests/unit/runtime/http/test_runtime_api_contract_hardening.py"
NAME = "test_runtime_contract_gate_rejects_nested_epoch_semantic_corruption"
NODE = TEST + "::" + NAME
APP = "src/polisyos/runtime/http/app.py"
PINS = (
    TEST,
    APP,
    "pytest.ini",
    "tests/conftest.py",
    "tools/ops_runners/runtime/check_runtime_api_contract.py",
    "tools/ops_runners/runtime/export_runtime_openapi.py",
)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git(*args: str) -> bytes:
    return subprocess.check_output(["/opt/homebrew/bin/git", "-C", str(ROOT), *args])  # noqa: S603


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--expected-head", required=True)
    parser.add_argument("--expected-tree", required=True)
    args = parser.parse_args()
    expected = (args.expected_head, args.expected_tree)
    if any(
        len(value) != 40 or any(c not in "0123456789abcdef" for c in value) for value in expected
    ):
        raise SystemExit("full lowercase commit/tree required")
    branch = git("symbolic-ref", "--short", "HEAD").decode().strip()
    actual = (
        git("rev-parse", "HEAD").decode().strip(),
        git("rev-parse", "HEAD^{tree}").decode().strip(),
    )
    if branch != "codex/e02-unified-local-20261009" or actual != expected:
        raise SystemExit(f"source mismatch: {branch=} {actual=} expected={expected}")
    if git("status", "--porcelain=v1", "--untracked-files=no"):
        raise SystemExit("tracked/index changes: preserve and report")
    plan_path = args.plan
    if not plan_path.is_absolute() or plan_path.parent != D or plan_path.is_symlink():
        raise SystemExit("plan must be an existing non-symlink directly within D")
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    case_id = plan["case_id"]
    if not case_id or any(not (c.isalnum() or c in "-_") for c in case_id):
        raise SystemExit("invalid case id")
    if plan_path.name != f"{case_id}.json":
        raise SystemExit("expected unmodified R2 case plan")
    if (plan.get("source_head"), plan.get("source_tree")) != expected or plan.get("nodes") != [
        NODE
    ]:
        raise SystemExit("R2 source/node binding mismatch")
    if plan.get("extra_env") != {}:
        raise SystemExit("unexpected prior environment overrides; inspect rather than replace")
    if os.path.lexists(D / case_id) or os.path.lexists(D / f"{case_id}-cwd.json"):
        raise SystemExit("case output/derived plan already exists; preserve it")
    if (
        not PLUGIN.is_file()
        or PLUGIN.is_symlink()
        or sorted(p.name for p in PLUGIN_DIR.iterdir()) != [PLUGIN.name]
    ):
        raise SystemExit("plugin directory is missing, shared or contains a symlink")
    runner = D / "run_case_with_tools_r3.py"
    if (
        sha(runner.read_bytes())
        != "b15b573c4b7854dddd3cdd55933fd4634d013cbe1410dd1cf965d6bdaff53243"
    ):
        raise SystemExit("retained R3 runner changed; review before binding")
    source_hashes = {}
    for rel in PINS:
        data = (P / rel).read_bytes()
        if data != git("show", f"{expected[0]}:policy-engine/{rel}"):
            raise SystemExit(f"source input differs from exact commit: {rel}")
        source_hashes[rel] = sha(data)
    test_ast = ast.parse((P / TEST).read_text(encoding="utf-8"))
    selected = [
        node for node in test_ast.body if isinstance(node, ast.FunctionDef) and node.name == NAME
    ]
    if len(selected) != 1:
        raise SystemExit("selected test function absent or ambiguous")
    calls = [node for node in ast.walk(selected[0]) if isinstance(node, ast.Call)]
    export_calls = [
        node
        for node in calls
        if isinstance(node.func, ast.Name) and node.func.id == "export_runtime_openapi_schema"
    ]
    if len(export_calls) != 1 or export_calls[0].args or export_calls[0].keywords:
        raise SystemExit("test no longer uses the reviewed default-app export path")
    plugin_sha = sha(PLUGIN.read_bytes())
    temp = D / case_id / "tmp"
    plan["extra_env"] = {
        "PYTHONPATH": str(PLUGIN_DIR),
        "PYTEST_PLUGINS": "e02_q2_cwd_guard",
        "E02_Q2_CASE_ID": case_id,
        "E02_Q2_SOURCE_HEAD": expected[0],
        "E02_Q2_SOURCE_TREE": expected[1],
        "E02_Q2_PLUGIN_SHA256": plugin_sha,
        "E02_Q2_TEST_SHA256": source_hashes[TEST],
        "E02_Q2_APP_SHA256": source_hashes[APP],
        "POLISYOS_CACHE_HOME": str(temp / "polisyos-cache"),
    }
    plan["scope"] += (
        " One extra test-local pytest plugin and plugin-only PYTHONPATH change the cwd only "
        "during the selected test body; cwd, CAS creation and checker output are recorded."
    )
    plan["q2_isolation"] = {
        "plugin_path": str(PLUGIN.relative_to(ROOT)),
        "plugin_sha256": plugin_sha,
        "pinned_source_sha256": source_hashes,
        "profile_variant": (
            "one extra plugin and plugin-only PYTHONPATH; otherwise R3 native pytest config"
        ),
        "limitations": [
            "cwd-sensitive behavior outside the selected test is unchanged, but arbitrary "
            "cwd-sensitive reads inside it are not comprehensively observed",
            "checker child inherits fresh pycache prefix but its loaded Python code is not "
            "independently observed",
            "checker output is complete text as decoded by subprocess, not the original raw "
            "byte stream",
        ],
    }
    if git("rev-parse", "HEAD").decode().strip() != expected[0] or git(
        "status", "--porcelain=v1", "--untracked-files=no"
    ):
        raise SystemExit("source changed during plan binding")
    out = D / f"{case_id}-cwd.json"
    with out.open("x", encoding="utf-8") as stream:
        json.dump(plan, stream, indent=2)
        stream.write("\n")
    sys.stdout.write(
        json.dumps(
            {
                "derived_plan": str(out),
                "sha256": sha(out.read_bytes()),
                "source_head": expected[0],
                "source_tree": expected[1],
                "node": NODE,
                "plugin_sha256": plugin_sha,
                "case_started": False,
            },
            sort_keys=True,
        )
        + "\n"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
