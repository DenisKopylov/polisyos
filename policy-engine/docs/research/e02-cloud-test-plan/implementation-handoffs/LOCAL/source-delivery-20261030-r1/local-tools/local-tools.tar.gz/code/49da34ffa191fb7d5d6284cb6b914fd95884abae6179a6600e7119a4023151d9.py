"""Read-only source/fixture admission for two bounded public-inventory checks."""

from __future__ import annotations

import ast
import hashlib
import importlib.metadata
import io
import json
import shutil
import subprocess
import sys
import tomllib
from pathlib import Path

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
P = ROOT / "policy-engine"
RAW = ROOT / "LOCAL/raw/e02-execution-20261027"
D = P / (
    "docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/"
    "root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/"
    "deep-task-status-audit-20261027-r1"
)
HEAD = "2130f07de1eb93316d22bf5f91adc05ded67fbd2"
TREE = "d67b5b827eb0d0f7286603d2c214c3d68a98675a"
CASE = "q2-public-inventory-corrupt-r1"
TEST = "tests/repo_quality/architecture/test_public_surface_supported_entrypoint_inventory.py"
FUNCTIONS = (
    "test_public_surface_inventory_enumerates_every_supported_entrypoint_facade",
    "test_public_surface_inventory_corrupt_supported_entrypoint_fails_check",
)
PINS = (
    TEST,
    "tests/repo_quality/conftest.py",
    "tests/conftest.py",
    "pytest.ini",
    "pyproject.toml",
    "uv.lock",
    "tools/devx/architecture/guardrails.py",
    "tools/lib/fs.py",
    "architecture/public_surface/contract.toml",
    "architecture/public_surface/inventory.json",
    "docs/reference/public-surface.md",
    "architecture/generated_artifacts.toml",
    "docs/reference/generated-artifacts.md",
    "architecture/baselines/imports/deep_import.json",
    "architecture/exceptions/guardrails.toml",
    "architecture/guardrail_exceptions_registry.md",
    "tests/unit/runtime/http/test_runtime_api_contract_hardening.py",
    "tools/ops_runners/runtime/check_runtime_api_contract.py",
    "tools/ops_runners/runtime/export_runtime_openapi.py",
    "src/polisyos/runtime/http/openapi_contract.py",
    "src/polisyos/runtime/http/app.py",
    "schemas/runtime_api_v1.openapi.json",
    "packages/runtime-api-client/types.ts",
    "packages/runtime-api-client/canonicalRuntimeApiClient.ts",
    "packages/runtime-api-client/canonicalRuntimeApiClient.js",
    "apps/runtime-dashboard/src/api/types.ts",
    "pnpm-lock.yaml",
)


def git(*args: str) -> bytes:
    # Fixed executable and caller-supplied arguments are constant repository paths and ids.
    return subprocess.check_output(["/opt/homebrew/bin/git", "-C", str(ROOT), *args])  # noqa: S603


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def source_identity() -> tuple[str, str, str]:
    return tuple(
        git(*args).decode().strip()
        for args in (
            ("symbolic-ref", "--short", "HEAD"),
            ("rev-parse", "HEAD"),
            ("rev-parse", "HEAD^{tree}"),
        )
    )


def main() -> int:
    expected = ("codex/e02-unified-local-20261009", HEAD, TREE)
    if source_identity() != expected or git("status", "--porcelain=v1", "--untracked-files=no"):
        raise SystemExit("source/branch/index mismatch or tracked changes; preserve and report")
    if Path(sys.prefix).resolve() != (P / ".venv").resolve():
        raise SystemExit("use the existing project .venv interpreter")
    if any(
        path.exists() for path in (D / CASE, D / f"{CASE}.json", D / f"{CASE}-root-live-input.json")
    ):
        raise SystemExit("case id already exists; preserve and use a freshly reviewed identity")
    test_tree = ast.parse((P / TEST).read_text(encoding="utf-8"))
    for name in FUNCTIONS:
        found = [
            node
            for node in test_tree.body
            if isinstance(node, ast.FunctionDef) and node.name == name
        ]
        if len(found) != 1:
            raise SystemExit(f"selected function absent or ambiguous: {name}")
    pins = {}
    for rel in PINS:
        path = P / rel
        content = path.read_bytes()
        if content != git("show", f"{HEAD}:policy-engine/{rel}"):
            raise SystemExit(f"tracked source mismatch: {rel}")
        pins[rel] = {"bytes": len(content), "sha256": sha(content)}
    helpers = {
        str(
            (RAW / "prepare_root_native_case_r2.py").relative_to(ROOT)
        ): "56aab78f632675fe441503b59c49c3d4ee252c22cdf6fe42b150d928d13b9990",
        str(
            (D / "run_case_with_tools_r3.py").relative_to(ROOT)
        ): "b15b573c4b7854dddd3cdd55933fd4634d013cbe1410dd1cf965d6bdaff53243",
    }
    for rel, expected_digest in helpers.items():
        if sha((ROOT / rel).read_bytes()) != expected_digest:
            raise SystemExit(f"retained helper changed: {rel}")
    contract = tomllib.loads((P / "architecture/public_surface/contract.toml").read_text())
    occurrences = [
        module for package in contract["package"] for module in package["supported_entrypoints"]
    ]
    tree_objects = {}
    for raw in git("ls-tree", "-r", "-z", HEAD, "--", "policy-engine/src/polisyos").split(b"\0"):
        if not raw:
            continue
        meta, path = raw.split(b"\t", 1)
        _mode, kind, obj = meta.split()
        if kind == b"blob":
            tree_objects[path.decode()] = obj.decode()
    facade_rows = []
    for module in occurrences:
        if not module.startswith("polisyos.") and module != "polisyos":
            raise SystemExit(f"unexpected public module: {module}")
        prefix = "policy-engine/src/" + module.replace(".", "/")
        paths = (prefix + ".py", prefix + "/__init__.py")
        existing = [rel for rel in paths if (ROOT / rel).is_file()]
        committed = [rel for rel in paths if rel in tree_objects]
        if existing != committed or len(existing) != 1:
            raise SystemExit(
                f"ambiguous/untracked facade candidate: {module}: {existing}/{committed}"
            )
        facade_rows.append(
            {"module": module, "path": existing[0], "git_blob": tree_objects[existing[0]]}
        )
    query = ("\n".join(row["git_blob"] for row in facade_rows) + "\n").encode()
    batch = subprocess.run(  # noqa: S603 -- fixed local git and object IDs from its own tree
        ["/opt/homebrew/bin/git", "-C", str(ROOT), "cat-file", "--batch"],
        input=query,
        capture_output=True,
        check=True,
    )
    stream = io.BytesIO(batch.stdout)
    for row in facade_rows:
        oid, kind, size = stream.readline().split()
        if oid.decode() != row["git_blob"] or kind != b"blob":
            raise SystemExit("unexpected Git batch object identity")
        content = stream.read(int(size))
        if stream.read(1) != b"\n" or (ROOT / row["path"]).read_bytes() != content:
            raise SystemExit(f"facade bytes mismatch: {row['path']}")
        row["sha256"] = sha(content)
    if stream.read():
        raise SystemExit("unexpected trailing Git batch bytes")
    if source_identity() != expected or git("status", "--porcelain=v1", "--untracked-files=no"):
        raise SystemExit("source changed during admission")
    metadata = {name: importlib.metadata.version(name) for name in ("pytest", "PyYAML")}
    result = {
        "source_head": HEAD,
        "source_tree": TREE,
        "branch": expected[0],
        "case_id": CASE,
        "selected_nodes": [f"{TEST}::{name}" for name in FUNCTIONS],
        "tracked_inputs": pins,
        "retained_helpers_sha256": helpers,
        "declared_package_count": len(contract["package"]),
        "declared_entrypoint_occurrences": len(occurrences),
        "distinct_entrypoints": len(set(occurrences)),
        "declared_facades": facade_rows,
        "interpreter": {
            "executable": sys.executable,
            "prefix": sys.prefix,
            "base_prefix": sys.base_prefix,
            "version": sys.version,
        },
        "installed_metadata": metadata,
        "disk_free_bytes": shutil.disk_usage(ROOT).free,
        "limits": (
            "declared facade candidates and listed core inputs only; scanner-dependent "
            "transitive source reads, actual executed Python code objects, native libraries "
            "and untracked nonfacade data are not covered"
        ),
        "tests_executed": False,
        "case_plan_created": False,
        "G_acceptance": False,
        "closure_ids": [],
    }
    sys.stdout.write(json.dumps(result, indent=2, sort_keys=True) + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
