"""Static-only audit for C50-native-controls-r2 inputs and AST seams.

This script reads pinned Python bytes, parses ASTs, applies the same declared
AST predicates to copies, and compiles transformed function ASTs. It imports no
product/test modules and does not run pytest or numerical code.
"""

from __future__ import annotations

import ast
import difflib
import hashlib
import json
import textwrap
from copy import deepcopy
from pathlib import Path
from typing import Any


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _literal_or_name(node: ast.expr, constants: dict[str, Any]) -> Any:
    if isinstance(node, ast.Name):
        return constants[node.id]
    return ast.literal_eval(node)


def _assignments(tree: ast.Module) -> dict[str, ast.expr]:
    found: dict[str, ast.expr] = {}
    for node in tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            found[node.targets[0].id] = node.value
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name) and node.value is not None:
            found[node.target.id] = node.value
    return found


def _extract_pins(plugin_tree: ast.Module) -> dict[str, str]:
    assigned = _assignments(plugin_tree)
    constants = {
        name: ast.literal_eval(assigned[name])
        for name in ("_TEST_CONSISTENCY",)
        if name in assigned
    }
    node = assigned["_SOURCE_PINS"]
    if not isinstance(node, ast.Dict):
        raise AssertionError("_SOURCE_PINS must remain a literal dictionary")
    return {
        _literal_or_name(key, constants): ast.literal_eval(value)
        for key, value in zip(node.keys, node.values, strict=True)
    }


def _get_function(
    source: str,
    name: str,
    *,
    class_name: str | None = None,
    filename: str,
) -> tuple[ast.Module, ast.FunctionDef, str]:
    parsed_file = ast.parse(source, filename=filename)
    if class_name is None:
        candidates = [
            node
            for node in parsed_file.body
            if isinstance(node, ast.FunctionDef) and node.name == name
        ]
    else:
        classes = [
            node
            for node in parsed_file.body
            if isinstance(node, ast.ClassDef) and node.name == class_name
        ]
        if len(classes) != 1:
            raise AssertionError(f"expected unique class {class_name} in {filename}")
        candidates = [
            node
            for node in classes[0].body
            if isinstance(node, ast.FunctionDef) and node.name == name
        ]
    if len(candidates) != 1:
        raise AssertionError(f"expected unique function {name} in {filename}")
    function = candidates[0]
    raw_lines = source.splitlines()
    raw_source = "\n".join(raw_lines[function.lineno - 1 : function.end_lineno]) + "\n"
    dedented = textwrap.dedent(raw_source)
    function_module = ast.parse(dedented, filename=filename)
    definitions = [item for item in function_module.body if isinstance(item, ast.FunctionDef)]
    if len(definitions) != 1 or definitions[0].name != name:
        raise AssertionError(f"dedented source failed to identify {name}")
    return parsed_file, definitions[0], raw_source


def _compile_function(function: ast.FunctionDef, filename: str) -> None:
    copied = deepcopy(function)
    module = ast.Module(body=[copied], type_ignores=[])
    ast.fix_missing_locations(module)
    source = ast.unparse(module)
    compile(source, filename, "exec")


def _has_string(node: ast.AST, value: str) -> bool:
    return any(isinstance(item, ast.Constant) and item.value == value for item in ast.walk(node))


def _task_compare(node: ast.expr, operator: type[ast.cmpop], subject: str, value: str) -> bool:
    return (
        isinstance(node, ast.Compare)
        and isinstance(node.left, ast.Attribute)
        and isinstance(node.left.value, ast.Name)
        and node.left.value.id == subject
        and node.left.attr == "task"
        and len(node.ops) == 1
        and isinstance(node.ops[0], operator)
        and len(node.comparators) == 1
        and isinstance(node.comparators[0], ast.Constant)
        and node.comparators[0].value == value
    )


def _mutate(mode: str, source: str, filename: str, function: ast.FunctionDef) -> int:
    function = deepcopy(function)
    count = 0
    if mode == "coverage_reconciliation":
        guard_index = next(
            (
                i
                for i, statement in enumerate(function.body)
                if isinstance(statement, ast.If)
                and _task_compare(statement.test, ast.NotEq, "self", "continuous")
                and any(isinstance(child, ast.Return) for child in ast.walk(statement))
            ),
            None,
        )
        if guard_index is None or guard_index == len(function.body) - 1:
            raise AssertionError("coverage control must preserve the noncontinuous branch and a reconciliation tail")
        fallback = ast.Return(
            value=ast.Tuple(
                elts=[ast.Constant("evaluated"), ast.Constant(1), ast.Constant(None)],
                ctx=ast.Load(),
            )
        )
        function.body = [*function.body[: guard_index + 1], fallback]
        count = 1

    elif mode == "origin_cap":
        for node in ast.walk(function):
            if isinstance(node, ast.If) and _task_compare(node.test, ast.Eq, "self", "continuous") and _has_string(
                node, "measurement_source_not_established"
            ):
                node.body = [ast.copy_location(ast.Pass(), node)]
                count += 1

    elif mode == "typed_report_precedence":
        for node in ast.walk(function):
            if (
                isinstance(node, ast.If)
                and isinstance(node.test, ast.Name)
                and node.test.id == "typed_receipts"
                and any(
                    isinstance(child, ast.Return)
                    and isinstance(child.value, ast.Call)
                    and isinstance(child.value.func, ast.Name)
                    and child.value.func.id == "min"
                    for child in ast.walk(node)
                )
            ):
                node.test = ast.Constant(False)
                count += 1

    elif mode == "dispatch_sidecar_merge":
        for node in ast.walk(function):
            if not isinstance(node, ast.Assign) or not any(
                isinstance(target, ast.Name) and target.id == "truthfulness_receipt" for target in node.targets
            ):
                continue
            call = node.value
            if (
                isinstance(call, ast.Call)
                and isinstance(call.func, ast.Name)
                and call.func.id == "extract_truthfulness_receipt"
                and len(call.args) == 1
                and isinstance(call.args[0], ast.Dict)
            ):
                mapping = call.args[0]
                keys = [key.value for key in mapping.keys if isinstance(key, ast.Constant)]
                if keys == ["artifacts", "output"] and any(
                    isinstance(value, ast.Attribute)
                    and isinstance(value.value, ast.Name)
                    and value.value.id == "result"
                    and value.attr == "output"
                    for value in mapping.values
                ):
                    call.args[0] = ast.Name("merged_artifacts", ast.Load())
                    count += 1

    elif mode == "duplicate_levels":
        for node in ast.walk(function):
            if not isinstance(node, ast.If):
                continue
            test = node.test
            exact_check = (
                isinstance(test, ast.Compare)
                and isinstance(test.left, ast.Call)
                and isinstance(test.left.func, ast.Name)
                and test.left.func.id == "len"
                and len(test.left.args) == 1
                and isinstance(test.left.args[0], ast.Call)
                and isinstance(test.left.args[0].func, ast.Name)
                and test.left.args[0].func.id == "set"
                and len(test.left.args[0].args) == 1
                and isinstance(test.left.args[0].args[0], ast.Name)
                and test.left.args[0].args[0].id == "level_values"
                and len(test.ops) == 1
                and isinstance(test.ops[0], ast.NotEq)
                and len(test.comparators) == 1
                and isinstance(test.comparators[0], ast.Call)
                and isinstance(test.comparators[0].func, ast.Name)
                and test.comparators[0].func.id == "len"
                and len(test.comparators[0].args) == 1
                and isinstance(test.comparators[0].args[0], ast.Name)
                and test.comparators[0].args[0].id == "level_values"
            )
            unique_error = any(
                isinstance(child, ast.Raise)
                and isinstance(child.exc, ast.Call)
                and _has_string(child.exc, "continuous interval levels must be unique")
                for child in ast.walk(node)
            )
            if exact_check and unique_error:
                node.test = ast.Constant(False)
                count += 1

    elif mode == "severity_status":
        for node in ast.walk(function):
            if not isinstance(node, ast.If):
                continue
            assigns_verdict = any(
                isinstance(child, ast.Assign)
                and any(isinstance(target, ast.Name) and target.id == "verdict_fields" for target in child.targets)
                for child in node.body
            )
            if assigns_verdict and (
                (isinstance(node.test, ast.Name) and node.test.id == "error_count")
                or _task_compare(node.test, ast.Eq, "diagnostics", "continuous")
            ):
                node.test = ast.Constant(False)
                count += 1

    elif mode == "warning_suppression":
        for node in ast.walk(function):
            if not isinstance(node, ast.Assign) or not any(
                isinstance(target, ast.Name) and target.id == "existing_codes" for target in node.targets
            ):
                continue
            value = node.value
            if not isinstance(value, ast.SetComp) or len(value.generators) != 1:
                continue
            generator = value.generators[0]
            if len(generator.ifs) == 1 and any(
                isinstance(child, ast.Compare)
                and isinstance(child.left, ast.Attribute)
                and child.left.attr == "value"
                and len(child.ops) == 1
                and isinstance(child.ops[0], ast.Eq)
                and len(child.comparators) == 1
                and isinstance(child.comparators[0], ast.Constant)
                and child.comparators[0].value == "error"
                for child in ast.walk(generator.ifs[0])
            ):
                generator.ifs = []
                count += 1

    else:
        raise AssertionError(f"unknown control mode {mode}")

    ast.fix_missing_locations(function)
    _compile_function(function, filename)
    return count


def _assertion_text(function: ast.FunctionDef) -> str:
    return "\n".join(ast.unparse(node.test) for node in ast.walk(function) if isinstance(node, ast.Assert))


def _test_calls(function: ast.FunctionDef) -> str:
    return "\n".join(ast.unparse(node) for node in ast.walk(function) if isinstance(node, ast.Call))


def audit() -> dict[str, Any]:
    root = Path(__file__).resolve().parents[5]
    packet = Path(__file__).resolve().parent
    project = root / "policy-engine"
    plugin_path = packet / "c50_removal_plugin.py"
    plugin_bytes = plugin_path.read_bytes()
    plugin_tree = ast.parse(plugin_bytes.decode(), filename=str(plugin_path))
    compile(plugin_tree, str(plugin_path), "exec")
    plugin_sha = _sha(plugin_bytes)
    pinset = _extract_pins(plugin_tree)

    control_path = packet / "control-inputs.json"
    control = json.loads(control_path.read_text(encoding="utf-8"))
    if control["control_plugin"]["sha256"] != plugin_sha:
        raise AssertionError("control inputs do not bind the r2 plugin bytes")
    pinset_sha = _sha(json.dumps(pinset, sort_keys=True, separators=(",", ":")).encode())
    if control["control_plugin"]["pinset_sha256"] != pinset_sha:
        raise AssertionError("control inputs do not bind the r2 source/test pinset")
    if control["source_basis"]["pins"] != pinset:
        raise AssertionError("control input pins differ from plugin admission pins")

    test_rel = "tests/unit/calibration/diagnostics/test_c50_receipt_consistency.py"
    test_postimage = root / control["source_basis"]["expected_future_composition"]["test_import_overlay"]
    test_post_bytes = test_postimage.read_bytes()
    if _sha(test_post_bytes) != pinset[test_rel]:
        raise AssertionError("expected test import postimage hash mismatch")
    canonical_test = project / test_rel
    canonical_sha = _sha(canonical_test.read_bytes())
    expected_preimage = "dbad509c7b60d96b4f461f4a5f0d2d0a4f0567ee0b7cd5c5d1fcc5ad662f9c1c"
    expected_postimage = pinset[test_rel]
    if canonical_sha not in {expected_preimage, expected_postimage}:
        raise AssertionError("canonical selected test is neither admitted preimage nor expected postimage")
    pre_lines = canonical_test.read_text(encoding="utf-8").splitlines()
    post_lines = test_post_bytes.decode("utf-8").splitlines()
    changed = [
        (line[0], line[2:])
        for line in difflib.ndiff(pre_lines, post_lines)
        if line.startswith(("- ", "+ "))
    ]
    patch_path = packet.parent / "C50-test-import-r1" / "base-to-proposal.patch"
    patch_lines = [
        (line[0], line[1:])
        for line in patch_path.read_text(encoding="utf-8").splitlines()
        if line.startswith(("-", "+")) and not line.startswith(("---", "+++"))
    ]
    expected_patch_changes = [
        ("-", "from polisyos.ir import ("),
        ("+", "from polisyos.ir.analytics import ("),
    ]
    if patch_lines != expected_patch_changes:
        raise AssertionError("test import patch does not contain exactly the admitted facade correction")
    if canonical_sha == expected_preimage and changed != expected_patch_changes:
        raise AssertionError("test import overlay is not the single admitted facade correction")
    if canonical_sha == expected_postimage and changed:
        raise AssertionError("canonical postimage differs from the admitted one-line test correction")

    test_source = test_post_bytes.decode("utf-8")
    test_ast = ast.parse(test_source, filename=str(test_postimage))
    tests = {node.name: node for node in test_ast.body if isinstance(node, ast.FunctionDef)}
    control_modes = {row["mode"]: row for row in control["controls"]}
    expected_functions = {
        "coverage_reconciliation": "test_positive_metadata_cannot_admit_an_empty_interval_curve",
        "origin_cap": "test_hand_authored_coherent_report_without_source_binding_is_limited",
        "typed_report_precedence": "test_embedded_positive_receipt_cannot_bypass_continuous_recomputation",
        "dispatch_sidecar_merge": "test_typed_incomplete_report_dominates_a_positive_sidecar_in_real_dispatch_merge",
        "duplicate_levels": "test_continuous_producer_rejects_duplicate_requested_levels",
        "severity_status": "test_any_fatal_diagnostic_issue_cannot_leave_a_pass_ready_validation",
        "warning_suppression": "test_warning_with_the_expected_issue_code_cannot_mask_recomputed_error",
    }
    selectors = {}
    for mode, name in expected_functions.items():
        if name not in tests:
            raise AssertionError(f"selected test function missing from expected postimage: {name}")
        row = control_modes[mode]
        nodes = row["nodes"]
        if any(not node.startswith(test_rel + "::" + name) for node in nodes):
            raise AssertionError(f"selector does not point to its actual function: {mode}")
        selectors[mode] = {"nodes": nodes, "function_present": True}

    required_test_signals = {
        "coverage_reconciliation": ("_assert_measurement_failure", "validation.verdict == 'fail'"),
        "origin_cap": ("_assert_source_origin_residual", "receipt.runtime_truthfulness_tier is TruthfulnessTier.UNVERIFIED"),
        "typed_report_precedence": ("assert extracted == recomputed", "assert extracted != embedded"),
        "dispatch_sidecar_merge": ("assert receipt.runtime_truthfulness_tier is TruthfulnessTier.UNVERIFIED",),
        "duplicate_levels": ("pytest.raises(ValueError", "levels=[0.95, 0.95]"),
        "severity_status": ("report.verdict == 'fail'", "report.readiness == 'blocked'", "binary", "multiclass"),
        "warning_suppression": ("_assert_measurement_failure", "validation.verdict == 'fail'"),
    }
    for mode, signals in required_test_signals.items():
        combined = ast.unparse(tests[expected_functions[mode]]) + "\n" + _assertion_text(tests[expected_functions[mode]]) + "\n" + _test_calls(tests[expected_functions[mode]])
        if mode in {"coverage_reconciliation", "warning_suppression"}:
            combined += "\n" + ast.unparse(tests["_assert_measurement_failure"])
        elif mode == "origin_cap":
            combined += "\n" + ast.unparse(tests["_assert_source_origin_residual"])
        if any(signal not in combined for signal in signals):
            raise AssertionError(f"semantic test signal missing for {mode}: {signals}")
    severity_decorator = ast.unparse(tests[expected_functions["severity_status"]])
    if "binary" not in severity_decorator or "multiclass" not in severity_decorator:
        raise AssertionError("severity variant matrix no longer includes binary and multiclass")

    sources = {relative: (project / relative).read_text(encoding="utf-8") for relative in pinset if relative != test_rel}
    for relative, source in sources.items():
        compile(ast.parse(source, filename=relative), relative, "exec")
    api_tree = ast.parse(sources["src/polisyos/ir/api.py"], filename="ir/api.py")
    api_assignments = _assignments(api_tree)
    analytics_exports = api_assignments["ANALYTICS_FACADE_EXPORTS"]
    if not isinstance(analytics_exports, ast.Dict):
        raise AssertionError("ANALYTICS_FACADE_EXPORTS must remain a static dictionary")
    export_pairs = {
        ast.literal_eval(key): tuple(ast.literal_eval(part) for part in value.elts)
        for key, value in zip(analytics_exports.keys, analytics_exports.values, strict=True)
        if isinstance(key, ast.Constant) and isinstance(value, ast.Tuple)
    }
    expected_extractor_target = (
        "polisyos.ir.analytics._truthfulness",
        "extract_truthfulness_receipt",
    )
    if export_pairs.get("extract_truthfulness_receipt") != expected_extractor_target:
        raise AssertionError("analytics facade does not resolve the extractor to its canonical owner")
    if "ANALYTICS_FACADE_EXPORTS" not in sources["src/polisyos/ir/analytics/__init__.py"]:
        raise AssertionError("analytics facade package no longer uses its pinned lazy export map")
    ir_root_tree = ast.parse(sources["src/polisyos/ir/__init__.py"], filename="ir/__init__.py")
    ir_root_exports = _assignments(ir_root_tree)["_LAZY_IMPORTS"]
    if not isinstance(ir_root_exports, ast.Dict) or any(
        isinstance(key, ast.Constant) and key.value == "extract_truthfulness_receipt"
        for key in ir_root_exports.keys
    ):
        raise AssertionError("root IR facade unexpectedly changed the reviewed extractor gap")

    owner_specs = {
        "coverage_reconciliation": ("src/polisyos/ir/analytics/calibration_diagnostics.py", "_interval_coverage_admission", "CalibrationDiagnosticsReport", 1),
        "origin_cap": ("src/polisyos/ir/analytics/calibration_diagnostics.py", "to_truthfulness_receipt", "CalibrationDiagnosticsReport", 1),
        "typed_report_precedence": ("src/polisyos/ir/analytics/_truthfulness.py", "extract_truthfulness_receipt", None, 1),
        "dispatch_sidecar_merge": ("src/polisyos/foundry/methods/backends/dispatch.py", "_merge_dispatch_result", None, 1),
        "duplicate_levels": ("src/polisyos/calibration/diagnostics/continuous.py", "_prepare_interval_sets", None, 1),
        "severity_status": ("src/polisyos/calibration/diagnostics/adapters.py", "to_validation_report", None, 2),
        "warning_suppression": ("src/polisyos/calibration/diagnostics/adapters.py", "_interval_admission_issues", None, 1),
    }
    transformations = {}
    for mode, (relative, function_name, class_name, expected_rewrites) in owner_specs.items():
        full_source = sources[relative]
        _full_tree, original_fn, raw_function_source = _get_function(
            full_source,
            function_name,
            class_name=class_name,
            filename=relative,
        )
        active_rewrites = _mutate(mode, full_source, relative, original_fn)
        if active_rewrites != expected_rewrites:
            raise AssertionError(f"unexpected rewrite count for {mode}: {active_rewrites}")
        dedent_needed = raw_function_source.startswith("    def ")
        if class_name is not None and not dedent_needed:
            raise AssertionError(f"class method source indentation was not witnessed: {mode}")
        transformations[mode] = {
            "owner": f"{class_name + '.' if class_name else ''}{function_name}",
            "source_path": relative,
            "rewrite_count": active_rewrites,
            "active_ast_compiles": True,
            "class_source_dedented": dedent_needed,
        }

    alias_function = next(
        node
        for node in plugin_tree.body
        if isinstance(node, ast.FunctionDef) and node.name == "_install_aliases"
    )
    alias_imports = {
        child.args[0].value
        for child in ast.walk(alias_function)
        if isinstance(child, ast.Call)
        and isinstance(child.func, ast.Attribute)
        and child.func.attr == "import_module"
        and len(child.args) == 1
        and isinstance(child.args[0], ast.Constant)
        and isinstance(child.args[0].value, str)
    }
    if "polisyos.ir.analytics" not in alias_imports or "polisyos.ir" in alias_imports:
        raise AssertionError("typed extractor must patch only the existing analytics facade alias")
    configure_function = next(
        node
        for node in plugin_tree.body
        if isinstance(node, ast.FunctionDef) and node.name == "pytest_configure"
    )
    active_compile_calls = [
        node
        for node in ast.walk(configure_function)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id == "_compile_active"
        and node.args
    ]
    if len(active_compile_calls) != 1 or not isinstance(active_compile_calls[0].args[0], ast.IfExp):
        raise AssertionError("control compiler must select a real module namespace for class methods")
    module_choice = active_compile_calls[0].args[0]
    module_namespace_ok = (
        isinstance(module_choice.body, ast.Name)
        and module_choice.body.id == "owner"
        and isinstance(module_choice.orelse, ast.Call)
        and isinstance(module_choice.orelse.func, ast.Attribute)
        and module_choice.orelse.func.attr == "import_module"
        and len(module_choice.orelse.args) == 1
        and isinstance(module_choice.orelse.args[0], ast.Constant)
        and module_choice.orelse.args[0].value == "polisyos.ir.analytics.calibration_diagnostics"
    )
    if not module_namespace_ok:
        raise AssertionError("class methods must compile in the actual calibration_diagnostics module namespace")

    import_proposal_dir = packet.parent / "C50-test-import-r1"
    import_proposal_manifest_path = import_proposal_dir / "manifest.json"
    import_proposal_manifest = json.loads(import_proposal_manifest_path.read_text(encoding="utf-8"))
    patch_path = import_proposal_dir / "base-to-proposal.patch"
    if _sha(patch_path.read_bytes()) != control["source_basis"]["expected_future_composition"]["test_import_patch_sha256"]:
        raise AssertionError("test-import patch bytes differ from the admitted proposal")
    if import_proposal_manifest["files"][0]["postimage_sha256"] != expected_postimage:
        raise AssertionError("test-import proposal manifest postimage does not match the selected input")

    r1_packet = packet.parent / "C50-native-controls-r1"
    r1_manifest_path = r1_packet / "manifest.json"
    r1_manifest_bytes = r1_manifest_path.read_bytes()
    expected_r1_manifest_sha = "626923d182e9a72141516735f0a0b1576072adf5697b959f88c71bc0b784f8ae"
    if _sha(r1_manifest_bytes) != expected_r1_manifest_sha:
        raise AssertionError("r1 manifest changed while preparing r2")
    r1_manifest = json.loads(r1_manifest_bytes)
    for name, row in r1_manifest["packet_files"].items():
        if _sha((r1_packet / name).read_bytes()) != row["sha256"]:
            raise AssertionError(f"r1 packet file changed while preparing r2: {name}")
    compile(ast.parse(test_source, filename=str(test_postimage)), str(test_postimage), "exec")
    for relative, expected in pinset.items():
        if relative == test_rel:
            continue
        actual = _sha((project / relative).read_bytes())
        if actual != expected:
            raise AssertionError(f"source pin mismatch: {relative}")

    return {
        "state": "STATIC_SHAPE_AUDIT_PASS",
        "packet": "C50-native-controls-r2",
        "source_composition": "expected C50-r2 production bytes + the one-line C50-test-import-r1 postimage",
        "canonical_test_state": "PREIMAGE_NOT_APPLIED" if canonical_sha == expected_preimage else "EXPECTED_POSTIMAGE_APPLIED",
        "canonical_test_sha256_observed": canonical_sha,
        "expected_test_postimage_sha256": expected_postimage,
        "test_overlay_single_line_verified": True,
        "source_test_pin_count": len(pinset),
        "source_test_pinset_sha256": pinset_sha,
        "plugin_sha256": plugin_sha,
        "analytics_facade_extractor_mapping_verified": True,
        "root_facade_extractor_mapping_absent": True,
        "class_method_compile_namespace_verified": True,
        "r1_packet_unchanged": True,
        "selectors": selectors,
        "transformations": transformations,
        "analytics_alias_only": True,
        "class_methods_dedented_and_compiled": True,
        "product_modules_imported": 0,
        "pytest_or_numerical_execution_count": 0,
        "execution_qualification": "UNPREPARED",
    }


if __name__ == "__main__":
    print(json.dumps(audit(), indent=2, sort_keys=True))

