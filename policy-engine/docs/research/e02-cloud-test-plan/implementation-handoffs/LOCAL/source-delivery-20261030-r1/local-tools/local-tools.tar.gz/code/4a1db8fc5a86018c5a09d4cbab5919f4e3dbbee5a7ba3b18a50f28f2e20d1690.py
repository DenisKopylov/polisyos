from pathlib import Path
import json,subprocess,hashlib
R=Path.cwd();P=R/'policy-engine';out=R/'LOCAL/raw/e02-execution-20261027/repairs/C32-r5';rows=[]
for f in sorted((out/'policy-engine').rglob('*.py')):
 relative=f.relative_to(out/'policy-engine').as_posix();q=subprocess.run([str(P/'.venv/bin/python'),'-m','ruff','check','--fix','--stdin-filename',relative,'-'],input=f.read_bytes(),cwd=P,capture_output=True)
 (out/(f.name+'.ruff-fix.stderr')).write_bytes(q.stderr)
 assert q.returncode in (0,1),(relative,q.stderr)
 f.write_bytes(q.stdout)
 q=subprocess.run([str(P/'.venv/bin/python'),'-m','ruff','format','--stdin-filename',relative,'-'],input=f.read_bytes(),cwd=P,capture_output=True);assert q.returncode==0,(relative,q.stderr);f.write_bytes(q.stdout)
 q=subprocess.run([str(P/'.venv/bin/python'),'-m','ruff','check','--stdin-filename',relative,'-'],input=f.read_bytes(),cwd=P,capture_output=True);rows.append({'path':relative,'exit':q.returncode,'stdout':q.stdout.decode(),'stderr':q.stderr.decode(),'source_sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
 assert q.returncode==0,rows[-1]
(out/'static-checks.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'ruff':len(rows),'results':[r['exit'] for r in rows]}))
