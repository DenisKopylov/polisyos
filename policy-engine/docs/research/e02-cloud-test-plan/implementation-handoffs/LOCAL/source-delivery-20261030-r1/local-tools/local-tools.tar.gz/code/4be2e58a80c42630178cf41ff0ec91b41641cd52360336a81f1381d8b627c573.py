from __future__ import annotations
import _abc
import gc
import ast
import builtins as _builtins
import contextvars
import dataclasses as _dataclasses
import dis, functools, hashlib, importlib, importlib.util, inspect as _inspect, json, os, sys, sysconfig, tomllib, types, typing
from collections.abc import Callable, Iterable, Mapping
from contextlib import contextmanager
from dataclasses import dataclass
from enum import Enum
from fractions import Fraction
from pathlib import Path
from importlib.machinery import SourceFileLoader
import copy
ROOT=Path.cwd()
source=ROOT/'LOCAL/raw/e02-execution-20261027/repairs/N7-protocol-identity-r1/pre/policy-engine/src/polisyos/runtime/quality/confidence_ledger.py'
tree=ast.parse(source.read_bytes(),filename=str(source))
module=types.ModuleType('identity_source_census')
sys.modules[module.__name__]=module
ns=vars(module)
ns.update(globals())
class ConfidenceLedgerError(Exception):
    pass
ns['ConfidenceLedgerError']=ConfidenceLedgerError
ns['_UNKNOWN_SOURCE_LITERAL']=object()
ns['_STATIC_FACADE_UNKNOWN']=ns['_UNKNOWN_SOURCE_LITERAL']
ns['_SOURCE_FACADE_NAMESPACE_EFFECT_GUARD']='__polisyos_static_namespace_effect_guard__'
ns['_READ_API_SURFACES_MODULE']='polisyos.data_forge.read_api.surfaces'
ns['_READ_API_SURFACE_ROUTES_MODULE']='polisyos.data_forge.read_api.surface_routes'
ns['_READ_API_PACKAGE_MODULE']='polisyos.data_forge.read_api'
ns['_READ_API_SURFACE_FIELDS']=('name','module','summary')
ns['_SOURCE_DERIVATION_FAILED']=object()
ns['_UNSUPPORTED_SOURCE_LITERAL']=object()
ns['_active_integrity_analysis']=lambda: None
future=ast.ImportFrom(module='__future__', names=[ast.alias(name='annotations')],level=0)
def install(node):
    m=ast.fix_missing_locations(ast.Module(body=[future, node],type_ignores=[]))
    exec(compile(m,str(source),'exec'),ns)
for name in ('_LiteralModuleGetattrProviderIndex','_AuthorityImportClosureSourceIndex','_SourceModuleImportRouteCandidate','_ProviderSourceGraphReconciliation','_LoaderOwnedCallableSlot'):
    install(copy.deepcopy(next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==name)))
missed={}
for node in tree.body:
    if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
        n=copy.deepcopy(node)
        n.decorator_list=[]
        try:
            install(n)
        except NameError as exc:
            missed[n.name]=str(exc)
ns['_active_integrity_analysis']=lambda: None

ns['BaseModel']=type('PlaceholderModel',(),{})
ns['PromotionObligationClass']=type('PlaceholderObligation',(),{})
ns['_LRU_CACHE_WRAPPER_TYPE']=type(functools.lru_cache(maxsize=1)(lambda: None))

raw=ROOT/'LOCAL/raw/e02-execution-20261027/repairs/N7-protocol-identity-r1'
fixture=raw/'loader-source-experiment.py'
fixture.write_text("MODE = 'canonical'\n\ndef read_mode():\n    return MODE\n")
class Analysis:
    code_cache=None
    def source_bytes(self,path): return path.read_bytes()
    def source_tree(self,path): return ast.parse(path.read_bytes(),filename=str(path))
ns['_active_integrity_analysis']=lambda: Analysis()
class SubstituteLoader(SourceFileLoader):
    def get_code(self, fullname):
        altered=Path(self.path).read_text().replace("MODE = 'canonical'", "MODE = 'substituted'")
        return compile(altered,self.path,'exec',dont_inherit=True)
def load(name,loader):
    spec=importlib.util.spec_from_file_location(name,fixture,loader=loader)
    module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module
    spec.loader.exec_module(module)
    _manifest,consistent=ns['_loaded_code_manifest_body'](raw,((name,fixture.relative_to(raw).as_posix()),))
    print(name,'mode',module.read_mode(),'source_manifest_consistent',consistent,'loader_type',type(module.__spec__.loader).__name__)
    return module.read_mode(),consistent
canonical=load('identity_probe_canonical',SourceFileLoader('identity_probe_canonical',str(fixture)))
substituted=load('identity_probe_substituted',SubstituteLoader('identity_probe_substituted',str(fixture)))
original_get_code=SourceFileLoader.get_code
def altered_get_code(self,fullname):
    altered=Path(self.path).read_text().replace("MODE = 'canonical'", "MODE = 'substituted'")
    return compile(altered,self.path,'exec',dont_inherit=True)
try:
    SourceFileLoader.get_code=altered_get_code
    spec=importlib.util.spec_from_file_location('identity_probe_exact_loader',fixture,loader=SourceFileLoader('identity_probe_exact_loader',str(fixture)))
    exact_module=importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=exact_module
    spec.loader.exec_module(exact_module)
finally:
    SourceFileLoader.get_code=original_get_code
_,exact_consistent=ns['_loaded_code_manifest_body'](raw,((spec.name,fixture.relative_to(raw).as_posix()),))
print(spec.name,'mode',exact_module.read_mode(),'source_manifest_consistent',exact_consistent,'loader_type',type(spec.loader).__name__)
assert canonical==('canonical',True)
assert substituted==('substituted',True)
assert type(spec.loader) is SourceFileLoader and exact_module.read_mode()=='substituted' and exact_consistent
print('BOUNDED RESULT: source/code manifest did not attest the actual module top-level execution; no product import was performed.')
