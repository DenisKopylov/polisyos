"""Read frozen sparse source and independently replay unified hunks in memory."""
from pathlib import Path
import ast
import hashlib
import json
import re

raw=Path(__file__).resolve().parent
repo=raw.parents[4]
manifest=json.loads((raw/'manifest.json').read_bytes())
patch=(raw/'source.patch').read_bytes()
assert hashlib.sha256(patch).hexdigest()==manifest['source_patch']['sha256']
lines=patch.decode().splitlines(keepends=True)
sections=[]
for line in lines:
 if line.startswith('diff --git '): sections.append([line])
 else: sections[-1].append(line)
assert len(sections)==len(manifest['files'])
receipts=[]
for section,item in zip(sections,manifest['files'],strict=True):
 path=item['path'];assert section[0]==f'diff --git a/{path} b/{path}\n'
 pre_path=repo/path
 before=pre_path.read_bytes() if pre_path.exists() else b''
 assert (hashlib.sha256(before).hexdigest() if pre_path.exists() else None)==item['pre_sha256']
 pre=before.decode().splitlines(keepends=True);out=[];cursor=0;i=1
 while i<len(section):
  match=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',section[i])
  if not match:i+=1;continue
  start,count,newstart,newcount=(int(match.group(1)),int(match.group(2) or 1),int(match.group(3)),int(match.group(4) or 1))
  old_index=start-1 if count else start
  out.extend(pre[cursor:old_index]);cursor=old_index;i+=1;deleted=added=0
  while i<len(section) and not section[i].startswith('@@ '):
   line=section[i];kind=line[0];value=line[1:]
   if kind in ' -':assert pre[cursor]==value;cursor+=1;deleted+=1
   if kind in ' +':out.append(value);added+=1
   i+=1
  assert deleted==count and added==newcount
 out.extend(pre[cursor:]);after=''.join(out).encode()
 post=raw/'postimages'/path
 assert after==post.read_bytes() and hashlib.sha256(after).hexdigest()==item['post_sha256']
 assert post.stat().st_nlink==1
 if post.suffix=='.py':ast.parse(after,filename=str(repo/path))
 receipts.append({'path':path,'patch_replay':'PASS','post_sha256':item['post_sha256'],'links':post.stat().st_nlink})
old=raw.parent/'C77-structural-owner-r1'
assert hashlib.sha256((old/'manifest.json').read_bytes()).hexdigest()=='b7335a75b76f614626c1b0ada3b98d3a69fbc804f92adcd1a6769823b9aa70d9'
for item in json.loads((old/'manifest.json').read_bytes())['files']:
 assert hashlib.sha256((old/'postimages'/item['path']).read_bytes()).hexdigest()==item['post_sha256']
result={'status':'PASS','product_imports_tests_native':'UNRUN','canonical_index_ref_env_writes':False,
        'denominator':manifest['denominator'],'r1_immutable_readback':'PASS','files':receipts}
(raw/'readback.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
