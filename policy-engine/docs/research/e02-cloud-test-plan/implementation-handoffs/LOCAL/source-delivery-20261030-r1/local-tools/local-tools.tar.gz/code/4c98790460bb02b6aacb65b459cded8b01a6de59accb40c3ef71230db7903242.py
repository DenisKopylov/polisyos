"""Prepare explicit candidate-only WMR/L6 inputs for N4 consumer mechanics.

This script is a proposal and has not been executed. Its only write target is a
new, caller-named directory under this script's sibling ``cases`` directory.
It never writes product source/data or overwrites an existing case.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path
from typing import Any


CASE_ID_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,48}$")
L6_FIXTURES: tuple[tuple[str, dict[str, Any]], ...] = (
    ("intervention_bundle_v1/intervention_knob_dictionary.json", {"selected_data": {"v": 1}}),
    ("intervention_bundle_v1/lex_intervention_map.json", {"law": ["selected_data"]}),
    ("method_contract_bundle_v1/observation_to_contract_manifest.json", {"routes": []}),
    ("intervention_bundle_v1/policy_scenario_templates.json", {"selected_root": "physical-data"}),
    ("runtime_bundle_v1/slot_family_manifest.json", {"selected_root": "physical-data"}),
)


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _assert_disjoint(product_root: Path, case_root: Path, output_parent: Path) -> None:
    product_root = product_root.resolve(strict=True)
    output_parent = output_parent.resolve(strict=True)
    case_root = case_root.resolve(strict=False)
    if not case_root.is_relative_to(output_parent):
        raise SystemExit("candidate_case_path_outside_owned_cases_directory")
    if (
        case_root == product_root
        or case_root in product_root.parents
        or product_root in case_root.parents
    ):
        raise SystemExit("candidate_case_overlaps_product_root")


def _source_cut(repo_root: Path) -> dict[str, str]:
    def git_value(*args: str) -> str:
        return subprocess.run(
            ["git", "-C", str(repo_root), *args],
            check=True,
            capture_output=True,
            text=True,
        ).stdout.strip()

    return {
        "branch": git_value("branch", "--show-current"),
        "head": git_value("rev-parse", "HEAD"),
        "tree": git_value("rev-parse", "HEAD^{tree}"),
    }


def prepare(repo_root: Path, case_id: str) -> dict[str, Any]:
    repo_root = repo_root.resolve(strict=True)
    product_root = repo_root / "policy-engine"
    if not (product_root / "pyproject.toml").is_file():
        raise SystemExit("policy_engine_product_root_unavailable")
    if not CASE_ID_RE.fullmatch(case_id):
        raise SystemExit("candidate_case_id_invalid")

    here = Path(__file__).resolve().parent
    cases = here / "cases"
    cases.mkdir(parents=True, exist_ok=True)
    case_root = cases / case_id
    _assert_disjoint(product_root, case_root, cases)
    if case_root.exists():
        raise SystemExit("candidate_case_path_already_exists")
    case_root.mkdir()

    # Imports occur only when Root later executes this explicitly candidate-only
    # preparer. No production loader or output is invoked by writing this file.
    sys.path.insert(0, str(product_root))
    from tests._helpers.world_model_record import _build_record
    from tests.unit.runtime.quality.test_intervention_substrate import _write_l6_fixture
    from polisyos.runtime.quality.intervention_substrate import (
        default_l6_bundle_paths,
        load_l6_intervention_substrate,
    )

    # The existing _build_record owner emits the test-owned WorldModelRecord and
    # CAS under this new external case directory, with its own fixture producer
    # provenance intact.
    wmr_store, built, _model_spec, _registry_ref = _build_record(case_root / "wmr-owner")
    wmr_ref = str(built.record_ref.artifact_id)
    wmr_hash = built.record.content_hash

    # Reuse _minimal_split_l6_fixture's five candidate data payloads and the
    # existing test writer, but do not call that helper: it also writes a fake
    # code-owner authority file. The actual product code-root authority is read
    # below and is never authored or replaced by this preparer.
    authority_path = (
        product_root
        / "architecture/policy_design_case/layer3_gy_l6_owner_authority_bindings.json"
    )
    authority_before = _sha256(authority_path)
    l6_root = case_root / "l6-data"
    data_paths = default_l6_bundle_paths(product_root, source_owner_root=l6_root)
    for relative, payload in L6_FIXTURES:
        _write_l6_fixture(l6_root / "production_data" / relative, payload)
    bundle = load_l6_intervention_substrate(product_root, source_owner_root=l6_root)
    authority_after = _sha256(authority_path)
    if authority_after != authority_before:
        raise SystemExit("candidate_builder_changed_code_authority_input")
    if data_paths["owner_authority_bindings"] != authority_path:
        raise SystemExit("candidate_l6_authority_path_not_code_root_owned")

    l6_members = []
    for relative, _payload in L6_FIXTURES:
        path = l6_root / "production_data" / relative
        l6_members.append(
            {
                "relative_path": relative,
                "bytes": path.stat().st_size,
                "sha256": _sha256(path),
                "classification": "synthetic_candidate_data",
            }
        )

    receipt: dict[str, Any] = {
        "schema": "e02.n7-candidate-only-wmr-l6-inputs.r1",
        "status": "CANDIDATE_ONLY_NOT_AUTHENTIC_N7_INPUTS",
        "source_cut": _source_cut(repo_root),
        "product_root": str(product_root),
        "case_root": str(case_root),
        "claims": [],
        "authority": "none_claimed",
        "world_model": {
            "cas_root": str(wmr_store.root.resolve()),
            "artifact_ref": wmr_ref,
            "logical_content_hash": wmr_hash,
            "producer_fixture": "tests._helpers.world_model_record::_build_record",
            "classification": "synthetic test WorldModelRecord; not production-composed WMR",
        },
        "l6": {
            "source_owner_root": str(l6_root.resolve()),
            "bundle_content_hash": bundle.content_hash,
            "members": l6_members,
            "code_authority_bindings_path": str(authority_path),
            "code_authority_sha256_before": authority_before,
            "code_authority_sha256_after": authority_after,
            "classification": "synthetic candidate L6 data; actual code-root authority read-only",
        },
        "environment": {
            "CORR_C_WORLD_CAS": str(wmr_store.root.resolve()),
            "CORR_C_WORLD_REF": wmr_ref,
            "CORR_C_WORLD_HASH": wmr_hash,
            "CORR_C_L6_SOURCE_ROOT": str(l6_root.resolve()),
            "CORR_C_L6_SOURCE_HASH": bundle.content_hash,
            "CORR_C2_LEGACY_EFFECT_BRIDGE_PATH": "must_be_unset",
        },
        "limits": [
            "candidate software mechanics only",
            "not evidence of current law, authority, rights, grounding, source currentness, normal N7 route, or G acceptance",
            "consumer tests must retain every synthetic refusal and negative assertion",
        ],
    }
    output = case_root / "candidate-inputs.json"
    output.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return receipt


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", type=Path, required=True)
    parser.add_argument("--case-id", required=True)
    args = parser.parse_args()
    receipt = prepare(args.repo_root, args.case_id)
    print(json.dumps({"status": receipt["status"], "case_root": receipt["case_root"], "environment": receipt["environment"]}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
