"""Bound the RAW AST-tool fixture process; preserve each attempted run separately."""
import json
from pathlib import Path
import subprocess
import sys
import time

packet=Path(__file__).resolve().parent
product=packet.parents[4]/'policy-engine'
label=sys.argv[1]
command=[str(product/'.venv/bin/python'),'-B',str(packet/'compare_86_candidate.py'),label]
start=time.monotonic()
peak=0
abort=None
with (packet/f'{label}.stdout.json').open('x') as out, (packet/f'{label}.stderr.txt').open('x') as err:
    proc=subprocess.Popen(command,cwd=product,stdout=out,stderr=err)
    while proc.poll() is None:
        sample=subprocess.run(['/bin/ps','-o','rss=','-p',str(proc.pid)],capture_output=True,text=True,check=False)
        rss=int(sample.stdout.strip() or '0')*1024
        peak=max(peak,rss)
        if time.monotonic()-start>120 or rss>512*1024*1024:
            abort='wall' if time.monotonic()-start>120 else 'rss'
            proc.kill()
        time.sleep(.025)
    exit_code=proc.wait()
record={'command':command,'cwd':str(product),'exit_code':exit_code,'elapsed_seconds':time.monotonic()-start,'peak_sampled_child_rss_bytes':peak,'wall_limit_seconds':120,'rss_limit_bytes':512*1024*1024,'abort':abort}
(packet/f'{label}.command-result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
raise SystemExit(exit_code if exit_code>=0 else 1)
