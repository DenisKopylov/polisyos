from pathlib import Path
import ast, json, subprocess, sys
root=Path.cwd(); base=root/'LOCAL/raw/e02-execution-20261027/repairs/C41-r3'; post=base/'postimages'; product=root/'policy-engine'; py=product/'.venv/bin/python'
files=sorted(post.rglob('*.py'))
assert files and all(p.is_file() and p.stat().st_nlink == 1 and p.resolve()==p for p in files)
results=[]
for p in files:
 rel=p.relative_to(post/'policy-engine').as_posix(); text=p.read_text()
 try: ast.parse(text,filename=rel); ast_result='PASS'
 except SyntaxError as exc: ast_result=str(exc)
 cmd=[str(py),'-m','ruff','check','--no-cache','--config','ruff.toml','--stdin-filename',rel,'-']
 r=subprocess.run(cmd,input=text,text=True,cwd=product,capture_output=True)
 print(rel,'AST',ast_result,'RUFF',r.returncode)
 if r.returncode: print(r.stdout[:5000],r.stderr[:1000])
 results.append({'path':rel,'ast':ast_result,'ruff_rc':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'argv':cmd,'cwd':str(product)})
(base/'ast-ruff-check.json').write_text(json.dumps(results,indent=2)+'\n')
