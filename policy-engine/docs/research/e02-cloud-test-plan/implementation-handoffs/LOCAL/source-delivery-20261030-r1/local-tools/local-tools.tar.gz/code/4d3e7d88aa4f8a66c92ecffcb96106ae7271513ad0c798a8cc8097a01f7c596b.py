"""Four serial Root-only controls under the retained macOS process supervisor."""
from __future__ import annotations
import json
import os
import signal
from pathlib import Path
import time

ORDER=('bounded','starts','dead','removal')


def _judge(owner, control, actual, result):
    expected='EXPECTED_RED' if control=='removal' else 'PASS'
    owner.need(actual.get('control')==control and actual.get('status')==expected,'prerequisite semantic control identity failed')
    if control=='removal':owner.need(result.get('return_code')!=0 and actual.get('callbacks',0)>=100000,'DISABLE removal discriminator failed')
    else:owner.need(result.get('return_code')==0,'positive prerequisite failed')
    if control=='bounded':owner.need(actual['callbacks']<100 and actual['auth_refusals']==2,'bounded discovery/source-auth refusal property failed')
    if control=='starts':owner.need(actual['selected_starts']==1 and actual['actual_raises']==2 and actual['return_callbacks']==0,'raising first-start property failed')
    if control=='dead':owner.need(actual['child_exitcode']==0 and actual['child_pid']>0 and actual['refusal_seconds']<35,'silent dead-child refusal failed')
    return expected


def _plan(owner, path):
    owner.need(path.is_absolute() and path.parent==owner.PKG and path.is_file() and not path.is_symlink(),'prerequisite plan outside packet')
    plan=json.loads(path.read_text());plan['_runtime_binding']={'path':str(path.relative_to(owner.R)),'sha256':owner.file_sha(path)}
    owner.need(not owner.check_pins(plan['input_pins']),'prepared input pin changed')
    monitor,native,guard=owner.apis();owner.check_live(plan,monitor,guard)
    owner.need(owner.canonical_sha(owner.environment_fingerprint(owner.env_profile(owner.P/'.venv/bin/python')))==plan['environment_profile_sha256'],'prerequisite environment changed')
    return plan,monitor,native,guard


def run(owner, plan_path, revision):
    plan,monitor,native,guard=_plan(owner,plan_path)
    owner.need(revision.startswith('r') and revision[1:].isdigit(),'fresh rN prerequisite revision required')
    root=owner.D/('prerequisites-'+revision);root.mkdir(exist_ok=False)
    owner.resource_sample(native)
    fragment=json.loads(owner.SANDBOX_JSON.read_text())['fragment']
    sandbox=root/'child.sb';owner.write_new(sandbox,('(version 1)\n(allow default)\n(deny file-write*)\n(allow file-write* (subpath '+json.dumps(str(root))+'))\n(allow file-write* (literal "/dev/null"))\n'+fragment).encode())
    monitor.RSS_CAP_BYTES=owner.RSS_CAP;monitor.DISK_FLOOR_BYTES=owner.DISK_FLOOR;monitor.SAMPLE_SECONDS=owner.SAMPLE_SECONDS
    signal.signal(signal.SIGTERM,monitor.note_stop_signal);signal.signal(signal.SIGINT,monitor.note_stop_signal)
    started=time.monotonic();deadline=started+80;results=[];old_env=owner.sanitized_environment()
    try:
        for control in ORDER:
            owner.check_live(plan,monitor,guard);owner.resource_sample(native)
            case=root/control;case.mkdir(exist_ok=False);(case/'tmp').mkdir()
            (case/'monitor').mkdir(exist_ok=False)
            argv=[str(owner.P/'.venv/bin/python'),'-B',str(owner.PKG/'controls/prerequisite.py'),control,'--output',str(case)]
            env={'TMPDIR':str(case/'tmp'),'TMP':str(case/'tmp'),'TEMP':str(case/'tmp'),'PYTHONPYCACHEPREFIX':str(case/'pycache')}
            owner.save_new(case/'invocation.json',{'argv':argv,'cwd':str(owner.P),'source':plan['source'],'control':control,'shared_capture':json.loads((owner.PKG/'runtime-profile.json').read_text())['shared_capture']})
            value=monitor.run_command(case/'monitor',control,['/usr/bin/sandbox-exec','-f',str(sandbox),*argv],owner.P,started,deadline,env)
            owner.save_new(case/'monitor-result.json',value)
            owner.need(value.get('complete') is True and value.get('process_group_gone') is True,'prerequisite process exit incomplete')
            stdout=case/'monitor'/value['stdout_path'];lines=stdout.read_text().splitlines();payload=json.loads(lines[-1])
            expected=_judge(owner,control,payload,value)
            results.append({'control':control,'status':expected,'monitor':owner.file_binding(case/'monitor-result.json'),'actual_stdout':owner.file_binding(stdout)})
        owner.check_live(plan,monitor,guard)
        files=[owner.file_binding(path) for path in sorted(root.rglob('*')) if path.is_file() and not path.is_symlink()]
        owner.save_new(root/'prerequisite-summary.json',{'schema':'policyos.e02.C104.mac_prerequisites.v1','source':plan['source'],'plan':str(plan_path.relative_to(owner.R)),'plan_sha256':owner.file_sha(plan_path),'controls':results,'files':files,'status':'PASS','native_profile':{'wall_seconds':80,'rss_cap_bytes':owner.RSS_CAP,'disk_floor_bytes':owner.DISK_FLOOR}})
        print(json.dumps({'prerequisite_dir':str(root),'summary_sha256':owner.file_sha(root/'prerequisite-summary.json')}))
    finally:owner.restore_environment(old_env)
    return 0


def verify(owner, root, plan_path):
    plan,monitor,_native,_guard=_plan(owner,plan_path)
    previous=owner.R/'LOCAL/raw/e02-execution-20261027/repairs/C104-mac-selected-start-r4'
    previous_root=previous/'runs/prerequisites-r1'
    owner.need(root.is_absolute() and root.is_dir() and not root.is_symlink(),
               'prerequisite root is not an absolute regular directory')
    path=root/'prerequisite-summary.json'
    if root==previous_root:
        previous_plan=previous/'plan-diagnostic-r1.json'
        owner.need(owner.file_sha(previous_plan)=='653fa2e7b7e2265bc88bc4fa8c9173037c50410616c6f66caa21f747158af025',
                   'retained prerequisite plan bytes changed')
        old=json.loads(previous_plan.read_text())
        owner.need(old['source']==plan['source'] and old['environment_profile_sha256']==plan['environment_profile_sha256'],
                   'retained prerequisite source or Python profile differs')
        owner.need(not owner.check_pins(old['input_pins']), 'retained R4 prerequisite input pins changed')
        owner.need(owner.file_sha(owner.PKG/'controls/prerequisite.py')==owner.file_sha(previous/'controls/prerequisite.py'),
                   'prerequisite control implementation differs from actual R4')
        owner.need(owner.file_sha(path)=='5c644ac4e63386102f44b6e042e08182ecfaf9bee28161f7d8c8f4cae48a471f',
                   'retained prerequisite summary bytes changed')
        expected_plan=previous_plan
    else:
        owner.need(root.parent==owner.D, 'new prerequisite root escaped this packet')
        expected_plan=plan_path
    value=json.loads(path.read_text())
    owner.need(value.get('status')=='PASS' and value['source']==plan['source']
               and value['plan_sha256']==owner.file_sha(expected_plan),
               'prerequisite status/source/plan mismatch')
    owner.need([row['control'] for row in value['controls']]==list(ORDER),'full prerequisite denominator differs')
    for binding in value['files']:owner.verify_binding(binding)
    for row in value['controls']:
        result=json.loads((owner.R/row['monitor']['path']).read_text());pid=result.get('pid')
        owner.need(result.get('complete') is True and result.get('process_group_gone') is True and pid and not owner.process_pid_is_live(pid) and not monitor.process_group_exists(pid),'prerequisite PID/group not proven quiet')
        case=(owner.R/row['monitor']['path']).parent
        pids={pid};groups={pid}
        for line in (case/'monitor/process-tree.jsonl').read_text().splitlines():
            sample=json.loads(line)
            for process in sample.get('processes',[]):
                pids.add(process['pid']);groups.add(process['pgid'])
        for line in (case/'monitor'/result['stdout_path']).read_text().splitlines():
            if line.startswith('{'):actual=json.loads(line)
        _judge(owner,row['control'],actual,result)
        if row['control']=='dead':pids.add(actual['child_pid'])
        owner.need(all(type(value) is int and value>0 for value in pids|groups),'prerequisite numeric process set malformed')
        owner.need(not any(owner.process_pid_is_live(value) for value in pids) and not any(monitor.process_group_exists(value) for value in groups),'a prerequisite numeric PID/group is live; no ownership inference')
    return owner.file_binding(path)
