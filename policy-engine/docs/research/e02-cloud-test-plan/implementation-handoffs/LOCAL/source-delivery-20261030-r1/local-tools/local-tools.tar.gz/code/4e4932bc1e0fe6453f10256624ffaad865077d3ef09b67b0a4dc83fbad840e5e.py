import collections, json, subprocess
from pathlib import Path
base=Path('LOCAL/raw/e02-execution-20261027/repairs/C48-r4')
ruff='policy-engine/.venv/bin/python'

def check(file,logical):
 p=subprocess.run([ruff,'-m','ruff','check','--no-cache','--config','policy-engine/pyproject.toml','--output-format','json','--stdin-filename',str(logical),'-'], input=file.read_bytes(),capture_output=True)
 if p.returncode not in (0,1):
  raise RuntimeError((p.returncode,p.stderr.decode()))
 return json.loads(p.stdout)
def keys(diagnostics,file):
 lines=file.read_text().splitlines()
 return collections.Counter((x['code'],x['message'],lines[x['location']['row']-1].strip()) for x in diagnostics)
report=[]
for sub in ('postimages','c53-postimages'):
 post=base/sub; pre=base/('preimages' if sub=='postimages' else 'c53-preimages')
 for path in sorted(post.rglob('*.py')):
  rel=path.relative_to(post)
  if sub=='postimages' and str(rel).endswith('methods/search/funnel/orchestrator.py'): continue
  old=pre/rel
  if old.exists() and old.read_bytes()==path.read_bytes(): continue
  a=check(path,rel); b=check(old,rel) if old.exists() else []
  new=keys(a,path)-keys(b,old) if old.exists() else keys(a,path)
  report.append({'path':str(rel),'baseline':len(b),'after':len(a),'new':[{'code':k[0],'message':k[1],'line':k[2],'count':v} for k,v in new.items()]})
(base/'lint-summary.json').write_text(json.dumps(report,indent=2)+'\n')
for item in report:
 if item['new']: print(item['path'],item['new'])
print('files',len(report),'new_issues',sum(sum(x['count'] for x in i['new']) for i in report),'existing_after',sum(i['after'] for i in report))
