from pathlib import Path
import ast, hashlib, json, shutil, subprocess
root=Path('LOCAL/raw/e02-execution-20261027/repairs/TC-closure-owner-r5')
intake=Path('LOCAL/raw/e02-execution-20261027/repairs/SQL-owner-chain-r3-intake-20261028-r1')
rows={x['path']:x for x in json.loads((intake/'sql-61-manifest.json').read_text())['files']}
rows.update({x['path']:x for x in json.loads((intake/'v3-8-after-sql-r3-manifest.json').read_text())['files']})

def node(src, *, name, cls=None, typ=ast.FunctionDef):
 tree=ast.parse(src)
 if cls:
  classes=[x for x in tree.body if isinstance(x,ast.ClassDef) and x.name==cls]
  assert len(classes)==1,(cls,len(classes))
  pool=classes[0].body
 else: pool=tree.body
 hits=[x for x in pool if isinstance(x,typ) and getattr(x,'name',None)==name]
 assert len(hits)==1,(name,len(hits))
 return hits[0]

def portion(src,n):
 lines=src.splitlines(keepends=True)
 starts=[n.lineno,*[d.lineno for d in getattr(n,'decorator_list',[])]]
 return ''.join(lines[min(starts)-1:n.end_lineno])

def transplant(style,proposed,targets,*,extra=None):
 changes=[]
 for cls,name in targets:
  old=node(style,name=name,cls=cls);new=node(proposed,name=name,cls=cls)
  content=portion(proposed,new)
  if extra and name in extra:
   en=node(proposed,name=extra[name],typ=ast.ClassDef)
   content=portion(proposed,en)+'\n\n'+content
  starts=[old.lineno,*[d.lineno for d in getattr(old,'decorator_list',[])]]
  changes.append((min(starts)-1,old.end_lineno,content))
 lines=style.splitlines(keepends=True)
 for start,end,content in sorted(changes,reverse=True): lines[start:end]=[content]
 return ''.join(lines)

specs={
 'policy-engine/src/polisyos/runtime/http/services/control/run_lifecycle.py': [('ControlPlaneService',n) for n in ['get_method_execution_selection','read_current_completed_ex_ante_candidate_score','resolve_completed_method_metric_selection','_terminal_experiment_state_ref_for_control_job']],
 'policy-engine/src/polisyos/scientist/nodes/builtins/decide/policy_runtime_method_metrics.py': [(None,n) for n in ['read_completed_admitted_method_metric_projection','_read_owned_method_metric_projection','recompute_completed_ex_ante_rank_projection']],
 'policy-engine/src/polisyos/runtime/http/services/debug_registered_sql.py': [(None,n) for n in ['_reconcile_selected_sql_inputs','read_registered_sql_source_use']],
 'policy-engine/tests/integration/runtime/http/test_registered_sql_live_grant.py': [(None,'test_real_sql_workflows_recheck_current_use_on_every_debug_get')],
 'policy-engine/tests/unit/scientist/nodes/builtins/decide/test_policy_runtime_method_metrics.py': [(None,'_exercise_public_execute_method_metric_source')],
}
for rel,targets in specs.items():
 entry=rows[rel]; raw=Path(entry['postimage_file']).read_bytes()
 assert hashlib.sha256(raw).hexdigest()==entry['post_sha256'],rel
 path=root/'proposal'/rel;proposed=path.read_text();style=raw.decode()
 adapted=transplant(style,proposed,targets,extra={'read_completed_admitted_method_metric_projection':'_BudgetAwareCompletedSelectionOwner'} if rel.endswith('policy_runtime_method_metrics.py') and '/src/' in rel else None)
 if rel.endswith('/control/run_lifecycle.py'):
  def is_type_block(n):return isinstance(n,ast.If) and isinstance(n.test,ast.Name) and n.test.id=='TYPE_CHECKING'
  source_block=next(x for x in ast.parse(proposed).body if is_type_block(x))
  target_block=next(x for x in ast.parse(adapted).body if is_type_block(x))
  lines=adapted.splitlines(keepends=True);lines[target_block.lineno-1:target_block.end_lineno]=[portion(proposed,source_block)];adapted=''.join(lines)
 if rel.endswith('/decide/policy_runtime_method_metrics.py') and '/src/' in rel:
  a=next(x for x in ast.parse(proposed).body if isinstance(x,ast.ImportFrom) and x.module=='typing')
  b=next(x for x in ast.parse(adapted).body if isinstance(x,ast.ImportFrom) and x.module=='typing')
  lines=adapted.splitlines(keepends=True);lines[b.lineno-1:b.end_lineno]=[portion(proposed,a)];adapted=''.join(lines)
  # Budget class is modified independently of the three reader functions.
  adapted=transplant(adapted,proposed,[],extra=None)
  original=node(adapted,name='_ProjectionReadBudget',typ=ast.ClassDef)
  replacement=node(proposed,name='_ProjectionReadBudget',typ=ast.ClassDef)
  lines=adapted.splitlines(keepends=True);start=min([original.lineno,*[d.lineno for d in original.decorator_list]])-1;lines[start:original.end_lineno]=[portion(proposed,replacement)];adapted=''.join(lines)
 # All style source postimages were independently proven AST-equivalent to 77e.
 # Reformat only this reconstructed candidate to keep its style compatible.
 proc=subprocess.run(['policy-engine/.venv/bin/python','-m','ruff','format','--stdin-filename',rel.removeprefix('policy-engine/'),'-'],input=adapted,text=True,capture_output=True,check=True,cwd='.')
 adapted=proc.stdout
 ast.parse(adapted)
 backup=root/'legacy-77e-proposals'/rel;backup.parent.mkdir(parents=True,exist_ok=True);backup.write_text(proposed)
 pre=root/'preimages'/rel;pre.parent.mkdir(parents=True,exist_ok=True);pre.write_bytes(raw)
 path.write_text(adapted)
 print('adapted',rel)

for rel in ['policy-engine/src/polisyos/scientist/adapters/fabric_bridge.py','policy-engine/src/polisyos/scientist/adapters/registered_sql_admission.py']:
 entry=rows[rel];raw=Path(entry['postimage_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==entry['post_sha256']
 path=root/'proposal'/rel;proposed=path.read_text();style=raw.decode()
 if rel.endswith('/fabric_bridge.py'):
  style=style.replace('_parse_query_request(', 'parse_data_view_request(')
  adapted=transplant(style,proposed,[(None,'parse_data_view_request')])
 else:
  style=style.replace('_RegisteredSQLCapture','RegisteredSQLCapture').replace('_capture_edges(', 'registered_sql_capture_input_refs(')
  adapted=transplant(style,proposed,[(None,'registered_sql_capture_input_refs')])
 proc=subprocess.run(['policy-engine/.venv/bin/python','-m','ruff','format','--stdin-filename',rel.removeprefix('policy-engine/'),'-'],input=adapted,text=True,capture_output=True,check=True,cwd='.')
 adapted=proc.stdout;ast.parse(adapted)
 backup=root/'legacy-77e-proposals'/rel;backup.parent.mkdir(parents=True,exist_ok=True);backup.write_text(proposed)
 pre=root/'preimages'/rel;pre.parent.mkdir(parents=True,exist_ok=True);pre.write_bytes(raw);path.write_text(adapted)
 print('adapted',rel)
rel='policy-engine/src/polisyos/foundry/README.md'
entry=rows[rel];raw=Path(entry['postimage_file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==entry['post_sha256']
path=root/'proposal'/rel;prior=path.read_text();marker='\nThe `polisyos.foundry.compile` facade exposes `program_graph_input_refs`'
assert prior.count(marker)==1
append=marker+prior.split(marker,1)[1]
backup=root/'legacy-77e-proposals'/rel;backup.parent.mkdir(parents=True,exist_ok=True);backup.write_text(prior)
(root/'preimages'/rel).write_bytes(raw);path.write_text(raw.decode()+append)
print('adapted',rel)
