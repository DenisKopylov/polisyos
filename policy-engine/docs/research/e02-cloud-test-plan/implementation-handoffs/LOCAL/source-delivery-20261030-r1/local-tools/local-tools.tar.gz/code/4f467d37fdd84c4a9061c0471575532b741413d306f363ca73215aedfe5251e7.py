"""Remove the reconstructed writer-profile comparison while keeping its markers.

Only run on the matching generic witness. Its genuine alternate selected view
must then escape the owner and make the expected refusal assertion FAIL.
"""

import pytest


@pytest.fixture(autouse=True)
def tc_remove_profile_binding(monkeypatch):
    from polisyos.core import artifacts
    from polisyos.runtime.quality.cycle_substrate import (
        CycleSubstrateContextArtifactOwner,
    )

    original = CycleSubstrateContextArtifactOwner.resolve_for_current_job

    def without_profile_reconstruction(owner, ref, *args, **kwargs):
        expected = artifacts.expected_artifact_manifest_for_write
        try:
            artifacts.expected_artifact_manifest_for_write = (
                lambda **_inputs: owner._store.get_manifest(ref)
            )
            return original(owner, ref, *args, **kwargs)
        finally:
            artifacts.expected_artifact_manifest_for_write = expected

    monkeypatch.setattr(
        CycleSubstrateContextArtifactOwner,
        "resolve_for_current_job",
        without_profile_reconstruction,
    )
