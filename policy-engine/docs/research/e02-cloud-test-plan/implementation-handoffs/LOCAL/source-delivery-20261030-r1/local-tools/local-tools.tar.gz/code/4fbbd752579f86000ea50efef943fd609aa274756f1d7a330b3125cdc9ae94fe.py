"""Materialize source-only removal deltas, without executing product code."""
from pathlib import Path
import difflib,json,hashlib,ast
r=Path('LOCAL/raw/e02-execution-20261027/repairs/C60-r2')
base=r/'postimages'
com='policy-engine/src/polisyos/foundry/methods/components/'
back='policy-engine/src/polisyos/foundry/methods/backends/'
controls=[]
def control(name, files, test, failure):
    patch=''; bindings=[]
    for path,mutant in files.items():
        original=(base/path).read_text();assert original!=mutant
        ast.parse(mutant,filename=path)
        patch+=''.join(difflib.unified_diff(original.splitlines(keepends=True),mutant.splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path))
        out=r/'controls'/name/'mutants'/path;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(mutant)
        bindings.append({'path':path,'correct_sha256':hashlib.sha256(original.encode()).hexdigest(),'mutant_sha256':hashlib.sha256(mutant.encode()).hexdigest()})
    p=r/'controls'/name/'property-removal.patch';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(patch)
    controls.append({'name':name,'files':bindings,'test':test,'expected_named_failure':failure,'outcome':'UNRUN'})
def read(p):return (base/p).read_text()
full='tests/unit/foundry/methods/components/test_composition_custody.py'
s=read(com+'linker.py');a=s.index('        issues: list[str] = []',s.index('    def validate_chain('));s=s[:a]+'        return []  # joint validation removed; declarations remain\n'+s[a:]
control('joint-final-gate',{com+'linker.py':s},full+'::test_joint_strict_dag_refuses_missing_input_at_final_gate','DID NOT RAISE ValueError (both explicit and auto)')
s=read(back+'async_chain_executor.py').replace('        node_params = _build_node_param_payload(node, {node_id: params})','        node_params = dict(node.params)\n        node_params.update(params)')
control('async-static-payload',{back+'async_chain_executor.py':s},full+'::test_real_static_dynamic_override_and_runtime_seed_survive_fresh_resume','nondefault static numerical output (window=7 instead of 20)')
s=read(back+'checkpointing.py').replace('            result = disp.dispatch(','            node_params.pop("window", None)\n            result = disp.dispatch(',1)
control('checkpoint-static-payload',{back+'checkpointing.py':s},full+'::test_real_static_dynamic_override_and_runtime_seed_survive_fresh_resume','nondefault static numerical output (checkpoint/resume loses window=20)')
s=read(back+'checkpointing.py').replace('            result = disp.dispatch(','            materialized_state = state\n            result = disp.dispatch(',1)
control('checkpoint-bound-inputs',{back+'checkpointing.py':s},full+'::test_joint_strict_dag_executes_independent_merge_value','joint DAG merge value (-200 instead of 40 from ambient aliases)')
s=read(back+'chain_executor.py');a=s.index('    if not isinstance(node, MethodNode):',s.index('def _build_node_param_payload'));b=s.index('    combined_params.update(node.params)',a);s=s[:a]+'    combined_params = dict(getattr(node, "static_params", {}))\n'+s[b:]
control('typed-static-guard',{back+'chain_executor.py':s},'tests/unit/remediation/test_cmp_01.py::test_incomplete_node_projection_cannot_erase_static_parameters','DID NOT RAISE TypeError')
s=read(com+'composer.py').replace('                    effective_predecessors[target_id].add(predecessor_id)','                    pass  # requires edge omitted from frozen consumer plan').replace('                    effective_successors[predecessor_id].add(target_id)','                    pass  # matching successor omission')
control('requires-effective-edge',{com+'composer.py':s},full+'::test_requires_execution_barrier_keeps_parallel_sibling_and_fresh_prefix','dependent executed before required event (actual method barrier)')
s=read(com+'linker.py').replace('            augment(target_name, set())','''            for src_slot, _compat in candidate_edges[target_name]:
                if src_slot.name not in matched_sources:
                    matched_sources[src_slot.name] = target_name
                    break''')
control('greedy-matching',{com+'linker.py':s},full+'::test_finite_typed_lowering_matches_independent_exhaustive_assignments','bounded exhaustive assignment existence')
s=read(com+'semantic_validator.py').replace('            prereq_indices = [index for index, _node_id, _fqn in prerequisite_nodes]','''            last_by_fqn = {fqn: index for index, _node_id, fqn in prerequisite_nodes}
            prereq_indices = list(last_by_fqn.values())
            dependent_nodes = [item for item in dependent_nodes if item[0] == max(node[0] for node in dependent_nodes if node[2] == item[2])]''')
control('last-fqn-occurrence',{com+'semantic_validator.py':s},full+'::test_repeated_real_occurrences_retain_identity_and_static_parameters','early real prerequisite must not be replaced by last FQN / early invalid dependent must remain visible')
s=read(back+'chain_executor.py').replace('from __future__ import annotations','from __future__ import annotations\n\nfrom polisyos.foundry.methods.backends.async_chain_executor import AsyncChainExecutor')
control('eager-import-cycle',{back+'chain_executor.py':s},'tests/unit/remediation/test_cmp_01.py::test_async_wrapper_survives_both_fresh_import_orders','chain-first import order failed (subprocess assertion, not test collection)')
s=read(com+'composer.py');a=s.index('    if not isinstance(chain, CompiledMethodChain):',s.index('def reconcile_validation_context('));s=s[:a]+'    return chain.validation_context  # replay removed; type and markers retained\n'+s[a:]
c=read(back+'checkpointing.py');a=c.index('            expected_context = _validation_context_payload(chain)');b=c.index('            if checkpoint.execution_digest != execution_digest:',a);c=c[:a]+c[b:];c=c.replace('            "validation_context": _validation_context_payload(chain),\n','').replace('            "composition_warnings": list(getattr(chain, "warnings", ())),\n','')
control('context-custody-full',{com+'composer.py':s,back+'checkpointing.py':c},full+'::test_live_self_hash_cannot_remove_real_compiler_warning '+full+'::test_reopened_context_cannot_erase_limitation '+full+'::test_context_rejects_unknown_rule_or_schema_even_when_warning_hash_agrees','DID NOT RAISE CheckpointDigestMismatchError at changed-only live/reopened/unknown-context assertions')
(r/'controls/manifest.json').write_text(json.dumps({'schema':'policyos.e02.c60.source_removal_controls.v1','method':'exact source-only postimages; no import/test/runtime executed','controls':controls},indent=2)+'\n')
print(json.dumps({'controls_prepared':len(controls),'outcomes':'UNRUN','all_mutants_ast_parse':'PASS'}))
