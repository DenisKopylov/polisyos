"""Run exactly one source-bound R1 native case with retained Root guards."""
from __future__ import annotations

import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import runpy
import shutil
import signal
import subprocess
import sys
import time
import traceback
import xml.etree.ElementTree as ET

WORKSPACE = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
PRODUCT = WORKSPACE / "policy-engine"
PACKET = Path(__file__).resolve().parent
ROOT_LAYER = PRODUCT / "docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/root-layer-lib.py"
SUPERVISOR = PRODUCT / "docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-postfix-709-q2-helper-actual-20261018/supervise.py"
ROOT_LIVE = WORKSPACE / "LOCAL/raw/root-live-ownership-20261021.json"


class AdmissionError(RuntimeError):
    """Raised before pytest when a source, tool, or resource pin differs."""


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path: Path, payload: object) -> None:
    data = (json.dumps(payload, indent=2, ensure_ascii=False, sort_keys=True) + "\n").encode()
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(path, flags, 0o600)
    try:
        view = memoryview(data)
        while view:
            written = os.write(fd, view)
            if written <= 0:
                raise OSError("r1_receipt_short_write")
            view = view[written:]
        os.fsync(fd)
    finally:
        os.close(fd)


def git(*args: str) -> str:
    return subprocess.check_output(["git", "-C", str(WORKSPACE), *args], text=True).strip()


def git_clean(*args: str) -> bool:
    completed = subprocess.run(
        ["git", "-C", str(WORKSPACE), *args],
        check=False,
        capture_output=True,
        text=True,
    )
    if completed.returncode not in (0, 1):
        raise AdmissionError(f"git_status_command_error:{args}:{completed.returncode}")
    return completed.returncode == 0


def assert_no_symlink_components(path: Path) -> None:
    """Reject symlinked packet/output components below the admitted workspace."""
    absolute = path.absolute()
    try:
        relative = absolute.relative_to(WORKSPACE)
    except ValueError as exc:
        raise AdmissionError(f"path_outside_workspace:{absolute}") from exc
    cursor = WORKSPACE
    if cursor.is_symlink():
        raise AdmissionError(f"workspace_is_symlink:{cursor}")
    for part in relative.parts:
        cursor = cursor / part
        if os.path.lexists(cursor) and cursor.is_symlink():
            raise AdmissionError(f"symlink_component:{cursor}")


def resource_snapshot(plan: dict[str, object]) -> dict[str, object]:
    disk = shutil.disk_usage(WORKSPACE)
    total_raw = subprocess.check_output(["/usr/sbin/sysctl", "-n", "hw.memsize"], text=True)
    pressure_raw = subprocess.check_output(["/usr/bin/memory_pressure", "-Q"], text=True)
    cpu_raw = subprocess.check_output(["/usr/sbin/sysctl", "-n", "hw.ncpu"], text=True)
    match = re.search(r"System-wide memory free percentage:\s*(\d+)%", pressure_raw)
    if match is None:
        raise AdmissionError("memory_pressure_free_percent_unavailable")
    total_bytes = int(total_raw.strip())
    free_percent = int(match.group(1))
    estimated_free_bytes = total_bytes * free_percent // 100
    policy = plan["resource_admission"]
    assert isinstance(policy, dict)
    disk_start_floor = int(policy["disk_start_floor_bytes"])
    ram_start_floor = int(policy["ram_available_start_floor_bytes"])
    if disk.free < disk_start_floor:
        raise AdmissionError(f"disk_start_floor:{disk.free}<{disk_start_floor}")
    if estimated_free_bytes < ram_start_floor:
        raise AdmissionError(f"ram_available_start_floor:{estimated_free_bytes}<{ram_start_floor}")
    return {
        "measured_at_utc": datetime.datetime.now(datetime.UTC).isoformat(),
        "disk_total_bytes": disk.total,
        "disk_free_bytes": disk.free,
        "disk_used_percent": round(100 * disk.used / disk.total),
        "ram_total_bytes": total_bytes,
        "memory_pressure_stdout": pressure_raw,
        "memory_pressure_free_percent": free_percent,
        "estimated_available_ram_bytes": estimated_free_bytes,
        "cpu_count": int(cpu_raw.strip()),
        "admission_floors": {
            "disk_free_bytes": disk_start_floor,
            "estimated_available_ram_bytes": ram_start_floor,
        },
    }


def load_case_plan(plan_path: Path, case_id: str) -> tuple[dict[str, object], dict[str, object]]:
    if plan_path.resolve().parent != PACKET.resolve():
        raise AdmissionError("plan_must_be_in_packet_directory")
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    if plan.get("schema") != "policyos.e02.r1.local_native_requalification_r3.instrument.v1":
        raise AdmissionError("plan_schema_mismatch")
    cases = plan.get("run_matrix")
    if not isinstance(cases, list):
        raise AdmissionError("run_matrix_missing")
    matches = [row for row in cases if row.get("case_id") == case_id]
    if len(matches) != 1:
        raise AdmissionError(f"case_not_unique:{case_id}")
    return plan, matches[0]


def load_admission(admission_path: Path, expected_sha256: str) -> dict[str, object]:
    if admission_path.resolve().parent != PACKET.resolve():
        raise AdmissionError("admission_must_be_in_packet_directory")
    if not re.fullmatch(r"[0-9a-f]{64}", expected_sha256):
        raise AdmissionError("expected_admission_sha256_invalid")
    actual_sha256 = sha256(admission_path)
    if actual_sha256 != expected_sha256:
        raise AdmissionError("admission_sha256_mismatch")
    admission = json.loads(admission_path.read_text(encoding="utf-8"))
    if admission.get("schema") != "policyos.e02.r1.local_native_requalification_r3.launch_admission.v1":
        raise AdmissionError("admission_schema_mismatch")
    if admission.get("state") != "ADMITTED_FOR_ONE_SOURCE_FROZEN_WAVE":
        raise AdmissionError("launch_admission_not_frozen")
    return admission


def verify_static_pins(plan: dict[str, object], expected_sha256: str, plan_path: Path) -> dict[str, object]:
    if not re.fullmatch(r"[0-9a-f]{64}", expected_sha256):
        raise AdmissionError("expected_plan_sha256_invalid")
    actual_plan_sha256 = sha256(plan_path)
    if actual_plan_sha256 != expected_sha256:
        raise AdmissionError("plan_sha256_mismatch")
    pins = plan.get("instrument_pins")
    if not isinstance(pins, dict):
        raise AdmissionError("instrument_pins_missing")
    for relative, expected in pins.items():
        if Path(relative).is_absolute() or ".." in Path(relative).parts:
            raise AdmissionError(f"instrument_pin_path_invalid:{relative}")
        path = WORKSPACE / relative
        if not path.is_file() or sha256(path) != expected:
            raise AdmissionError(f"instrument_pin_mismatch:{relative}")
    system_pins = plan.get("system_tool_pins")
    if not isinstance(system_pins, dict):
        raise AdmissionError("system_tool_pins_missing")
    for absolute, expected in system_pins.items():
        path = Path(absolute)
        if not path.is_absolute() or not path.is_file() or sha256(path) != expected:
            raise AdmissionError(f"system_tool_pin_mismatch:{absolute}")
    environment = plan.get("environment")
    if not isinstance(environment, dict):
        raise AdmissionError("environment_profile_missing")
    controller_path = str(environment["controller_path"])
    os.environ["PATH"] = controller_path
    command_resolution = environment.get("command_resolution")
    if not isinstance(command_resolution, dict):
        raise AdmissionError("controller_command_resolution_missing")
    for command, expected_path in command_resolution.items():
        actual_path = shutil.which(str(command))
        if actual_path is None or Path(actual_path).resolve() != Path(str(expected_path)).resolve():
            raise AdmissionError(f"controller_command_resolution_mismatch:{command}:{actual_path}")
    return {"plan_sha256": actual_plan_sha256, "instrument_pins": pins, "system_tool_pins": system_pins}


def admitted_source_files(source: dict[str, object]) -> dict[str, str]:
    frame_path = WORKSPACE / str(source["source_frame_path"])
    frame = json.loads(frame_path.read_text(encoding="utf-8"))
    live = json.loads(ROOT_LIVE.read_text(encoding="utf-8"))
    files: dict[str, str] = {}
    for row in frame.get("paths", []):
        files[str(row["path"])] = str(row["sha256"])
    for row in live.get("known_dirty_paths", []):
        files[str(row["path"])] = str(row["sha256"])
    return files


def git_source_blob_map() -> tuple[dict[str, str], str]:
    object_format = git("rev-parse", "--show-object-format")
    if object_format not in {"sha1", "sha256"}:
        raise AdmissionError(f"unsupported_git_object_format:{object_format}")
    completed = subprocess.run(
        [
            "git", "-C", str(WORKSPACE), "ls-tree", "-rz", "--full-tree", "HEAD", "--",
            "policy-engine/src/polisyos", "policy-engine/tests", "policy-engine/tools",
        ],
        check=True,
        capture_output=True,
    )
    blobs: dict[str, str] = {}
    for record in completed.stdout.split(b"\0"):
        if not record:
            continue
        header, separator, path = record.partition(b"\t")
        if not separator:
            raise AdmissionError("git_source_tree_record_malformed")
        fields = header.decode("ascii").split()
        if len(fields) != 3 or fields[1] != "blob":
            continue
        blobs[os.fsdecode(path)] = fields[2]
    if not blobs:
        raise AdmissionError("git_source_tree_empty")
    return blobs, object_format


def verify_source_and_inputs(plan: dict[str, object], admission: dict[str, object], guard) -> dict[str, object]:
    source = admission["source_binding"]
    assert isinstance(source, dict)
    live_hash = sha256(ROOT_LIVE)
    if live_hash != source["root_live_sha256"]:
        raise AdmissionError("root_live_hash_mismatch")
    delta_path = WORKSPACE / str(source["source_delta_from_r2_path"])
    if not delta_path.is_file() or sha256(delta_path) != source["source_delta_from_r2_sha256"]:
        raise AdmissionError("source_delta_receipt_hash_mismatch")
    live = json.loads(ROOT_LIVE.read_text(encoding="utf-8"))
    if live.get("branch") != source["branch"] or live.get("head") != source["commit"] or live.get("tree") != source["tree"]:
        raise AdmissionError("root_live_identity_mismatch")
    if git("symbolic-ref", "--short", "HEAD") != source["branch"]:
        raise AdmissionError("branch_mismatch")
    if git("rev-parse", "HEAD") != source["commit"] or git("rev-parse", "HEAD^{tree}") != source["tree"]:
        raise AdmissionError("head_or_tree_mismatch")
    if not git_clean("diff", "--quiet") or not git_clean("diff", "--cached", "--quiet"):
        raise AdmissionError("tracked_source_or_index_dirty")
    raw_index_sha = hashlib.sha256(subprocess.check_output(["git", "-C", str(WORKSPACE), "diff", "--cached", "--raw", "--no-abbrev", "-z"])).hexdigest()
    if raw_index_sha != source["expected_index_raw_diff_sha256"]:
        raise AdmissionError("raw_index_binding_mismatch")
    frame_path = WORKSPACE / str(source["source_frame_path"])
    if sha256(frame_path) != source["source_frame_sha256"]:
        raise AdmissionError("source_frame_hash_mismatch")
    before = guard()
    pins = dict(plan["source_preimage_pins"])
    assert isinstance(pins, dict)
    admission_pins = admission["input_pins"]
    assert isinstance(admission_pins, dict)
    for relative, expected in admission_pins.items():
        previous = pins.get(relative)
        if previous is not None and previous != expected:
            raise AdmissionError(f"source_preimage_pin_conflict:{relative}")
        pins[relative] = expected
    for relative, expected in pins.items():
        path = WORKSPACE / relative
        if not path.is_file() or sha256(path) != expected:
            raise AdmissionError(f"input_pin_mismatch:{relative}")
    return {
        "branch": source["branch"],
        "head": source["commit"],
        "tree": source["tree"],
        "root_live_sha256": live_hash,
        "source_frame_path": str(source["source_frame_path"]),
        "source_frame_sha256": source["source_frame_sha256"],
        "source_delta_from_r2_path": str(source["source_delta_from_r2_path"]),
        "source_delta_from_r2_sha256": str(source["source_delta_from_r2_sha256"]),
        "expected_index_raw_diff_sha256": raw_index_sha,
        "root_guard_before": before,
        "source_input_pins": pins,
        "admitted_source_file_count": len(admitted_source_files(source)),
    }


def pytest_profile_launcher(
    expected_sitecustomize: Path,
    expected_python: Path,
    expected_python_version: str,
    expected_pytest_version: str,
    runtime_profile_path: Path,
    case_id: str,
    nodeid: str,
    pytest_plugins: list[str],
    case_root: Path,
) -> str:
    args = [
        "-o",
        f"cache_dir={case_root / 'pytest-cache'}",
        "--benchmark-storage=" + (case_root / "benchmarks").as_uri(),
        "--basetemp",
        str(case_root / "basetemp"),
        "--junitxml=" + str(case_root / "pytest.xml"),
        "--tb=short",
        "--color=no",
        "--maxfail=0",
        *pytest_plugins,
        nodeid,
    ]
    return (
        "import pathlib, sys\n"
        "expected = pathlib.Path(" + repr(str(expected_sitecustomize)) + ").resolve()\n"
        "loaded = sys.modules.get('sitecustomize')\n"
        "if loaded is None or pathlib.Path(getattr(loaded, '__file__', '')).resolve() != expected:\n"
        "    print('R1_SITECUSTOMIZE_ADMISSION_MISMATCH', file=sys.stderr, flush=True)\n"
        "    raise SystemExit(92)\n"
        "if pathlib.Path(sys.executable).resolve() != pathlib.Path(" + repr(str(expected_python)) + ").resolve():\n"
        "    print('R1_PYTHON_EXECUTABLE_MISMATCH', file=sys.stderr, flush=True)\n"
        "    raise SystemExit(93)\n"
        "if '.'.join(map(str, sys.version_info[:3])) != " + repr(expected_python_version) + ":\n"
        "    print('R1_PYTHON_VERSION_MISMATCH', file=sys.stderr, flush=True)\n"
        "    raise SystemExit(94)\n"
        "import pytest\n"
        "if pytest.__version__ != " + repr(expected_pytest_version) + ":\n"
        "    print('R1_PYTEST_VERSION_MISMATCH', file=sys.stderr, flush=True)\n"
        "    raise SystemExit(95)\n"
        "print('R1_RUNTIME_PROFILE python=' + sys.version.split()[0] + ' pytest=' + pytest.__version__, flush=True)\n"
        "import json, os\n"
        "class _R1RuntimeProfile:\n"
        "    def pytest_configure(self, config):\n"
        "        plugins = []\n"
        "        for name, plugin in config.pluginmanager.list_name_plugin():\n"
        "            if plugin is None:\n"
        "                continue\n"
        "            module_name = getattr(plugin, '__name__', type(plugin).__module__)\n"
        "            plugins.append({'name': str(name), 'module': str(module_name), 'version': str(getattr(plugin, '__version__', ''))})\n"
        "        payload = {'schema': 'policyos.e02.r1.pytest_runtime_profile.v1', 'python_version': sys.version.split()[0], 'python_executable': str(pathlib.Path(sys.executable).resolve()), 'pytest_version': pytest.__version__, 'plugins': sorted(plugins, key=lambda row: row['name'])}\n"
        "        path = pathlib.Path(" + repr(str(runtime_profile_path)) + ")\n"
        "        with path.open('x', encoding='utf-8') as stream:\n"
        "            json.dump(payload, stream, sort_keys=True, separators=(',', ':'))\n"
        "            stream.write('\\n')\n"
        "            stream.flush()\n"
        "            os.fsync(stream.fileno())\n"
        "raise SystemExit(pytest.main(" + repr(args) + ", plugins=[_R1RuntimeProfile()]))\n"
    )


def parse_junit(path: Path) -> dict[str, object] | None:
    if not path.is_file():
        return None
    root = ET.parse(path).getroot()
    cases = list(root.iter("testcase"))
    failures = []
    errors = []
    skipped = []
    for case in cases:
        for tag, dest in (("failure", failures), ("error", errors), ("skipped", skipped)):
            node = case.find(tag)
            if node is not None:
                dest.append({
                    "testcase": case.get("classname", "") + "::" + case.get("name", ""),
                    "message": node.get("message", ""),
                    "text": node.text or "",
                })
    return {"tests": len(cases), "failures": failures, "errors": errors, "skipped": skipped}


def read_process_origins(
    case_root: Path,
    expected_product_root: Path,
    expected_python: Path,
    expected_python_version: str,
    source_blobs: dict[str, str],
    git_object_format: str,
    driver_pid: int | None,
) -> dict[str, object]:
    readset_dir = case_root / "readsets"
    errors = sorted(readset_dir.glob("readset-error-*.json"))
    driver_files = sorted(readset_dir.glob("input-readset-*.json"))
    child_files = sorted(readset_dir.glob("spawned-child-*.json"))
    if errors or len(driver_files) != 1 or len(child_files) != 1:
        raise AdmissionError("driver_or_child_readset_missing_or_ambiguous")
    driver = json.loads(driver_files[0].read_text(encoding="utf-8"))
    child = json.loads(child_files[0].read_text(encoding="utf-8"))
    if driver.get("capture_status") != "complete" or child.get("capture_status") != "complete":
        raise AdmissionError("incomplete_process_origin_readset")
    if driver.get("phase") != "pytest_driver_at_interpreter_exit" or child.get("phase") != "multiprocessing_spawn_child_before_intentional_exit":
        raise AdmissionError("process_origin_phase_mismatch")
    if driver.get("event_exit_code") is not None:
        raise AdmissionError("driver_readset_not_from_normal_interpreter_exit")
    if child.get("spawn_marker_present_at_sitecustomize_startup") is not True or child.get("event_exit_code") != 73:
        raise AdmissionError("spawned_child_identity_or_exit_mismatch")
    if driver.get("spawn_marker_present_at_sitecustomize_startup") is not False:
        raise AdmissionError("driver_spawn_identity_mismatch")
    if driver_pid is not None and driver.get("pid") != driver_pid:
        raise AdmissionError("mutation_log_pid_differs_from_driver")
    if not isinstance(driver.get("pid"), int) or child.get("ppid") != driver.get("pid") or child.get("pid") == driver.get("pid"):
        raise AdmissionError("spawned_process_parent_identity_mismatch")
    expected_product_root = expected_product_root.resolve()
    if Path(driver.get("project_root", "")).resolve() != expected_product_root or Path(child.get("project_root", "")).resolve() != expected_product_root:
        raise AdmissionError("process_origin_product_root_mismatch")
    for process_record in (driver, child):
        if Path(str(process_record.get("python_executable", ""))).resolve() != expected_python.resolve():
            raise AdmissionError("process_origin_python_executable_mismatch")
        if str(process_record.get("python_version", "")).split()[0] != expected_python_version:
            raise AdmissionError("process_origin_python_version_mismatch")
    required_process_origins = {
        "pytest_driver_at_interpreter_exit": {
            "tests/unit/scientist/orchestration/engine/test_engine_executor_idempotency.py",
            "tests/_helpers/process_run_lifecycle.py",
            "tests/_helpers/run_lifecycle.py",
            "src/polisyos/scientist/orchestration/engine/idempotency.py",
            "src/polisyos/scientist/orchestration/engine/executor.py",
            "src/polisyos/core/run/context.py",
        },
        "multiprocessing_spawn_child_before_intentional_exit": {
            "tests/_helpers/process_run_lifecycle.py",
            "tests/_helpers/run_lifecycle.py",
            "src/polisyos/scientist/orchestration/engine/idempotency.py",
            "src/polisyos/scientist/orchestration/engine/executor.py",
            "src/polisyos/core/run/context.py",
        },
    }
    for process_record in (driver, child):
        loaded_paths = {
            str(row.get("project_relative_path"))
            for row in process_record.get("modules", [])
            if row.get("inside_project") is True
        }
        missing = required_process_origins[str(process_record["phase"])] - loaded_paths
        if missing:
            raise AdmissionError(f"required_process_source_origins_missing:{process_record['phase']}:{sorted(missing)}")
    reconciled_origins: dict[str, dict[str, object]] = {}
    for process_record in (driver, child):
        for row in process_record.get("modules", []):
            names = row.get("module_names", [])
            first_party_name = any(
                name == root or name.startswith(root + ".")
                for name in names
                for root in ("polisyos", "tests", "tools")
            )
            if first_party_name and row.get("inside_project") is not True:
                raise AdmissionError(f"first_party_origin_outside_product_root:{row.get('origin_path')}")
            if row.get("inside_project") is True:
                relative = row.get("project_relative_path")
                if not isinstance(relative, str) or not relative.startswith(("src/polisyos/", "tests/", "tools/")):
                    if first_party_name:
                        raise AdmissionError(f"first_party_path_outside_admitted_roots:{relative}")
                    continue
                path = expected_product_root / relative
                if not path.is_file() or path.resolve() != Path(row.get("origin_path", "")).resolve():
                    raise AdmissionError(f"loaded_origin_path_mismatch:{relative}")
                repository_relative = "policy-engine/" + relative
                expected_blob = source_blobs.get(repository_relative)
                if expected_blob is None:
                    raise AdmissionError(f"loaded_origin_not_tracked_in_admitted_source_tree:{repository_relative}")
                payload = path.read_bytes()
                git_blob = hashlib.new(git_object_format, b"blob " + str(len(payload)).encode() + b"\0" + payload).hexdigest()
                if git_blob != expected_blob:
                    raise AdmissionError(f"loaded_origin_bytes_differ_from_admitted_git_tree:{repository_relative}")
                row = reconciled_origins.setdefault(
                    repository_relative,
                    {"path": repository_relative, "git_blob": expected_blob, "sha256_after_run": hashlib.sha256(payload).hexdigest(), "module_names": []},
                )
                if row["sha256_after_run"] != hashlib.sha256(payload).hexdigest():
                    raise AdmissionError(f"loaded_origin_observed_hash_disagreement:{repository_relative}")
                row["module_names"] = sorted(set(row["module_names"]) | set(names))
    return {
        "driver": {"path": str(driver_files[0].relative_to(WORKSPACE)), "sha256": sha256(driver_files[0]), "pid": driver.get("pid"), "modules": len(driver.get("modules", []))},
        "child": {"path": str(child_files[0].relative_to(WORKSPACE)), "sha256": sha256(child_files[0]), "pid": child.get("pid"), "ppid": child.get("ppid"), "modules": len(child.get("modules", []))},
        "unique_first_party_origins_reconciled_to_git_tree": len(reconciled_origins),
        "origin_reconciliation_sha256": hashlib.sha256(json.dumps([reconciled_origins[k] for k in sorted(reconciled_origins)], sort_keys=True, separators=(",", ":")).encode()).hexdigest(),
        "scope": "Finite loaded first-party Python module origins from the pytest driver and spawned producer; each path was required to be tracked under policy-engine/src/polisyos, tests, or tools and its bytes matched the admitted HEAD Git blob. This is not syscall-level file tracing or a repository-wide absence claim.",
    }


def classify_case(
    case_row: dict[str, object],
    result: dict[str, object],
    junit: dict[str, object] | None,
    origins: dict[str, object] | None,
    case_root: Path,
    environment: dict[str, object],
) -> tuple[str, list[str]]:
    reasons = []
    if result.get("complete") is not True or result.get("aborted_reason") is not None:
        return "HARNESS_ERROR", ["supervisor_incomplete_or_aborted"]
    if junit is None:
        return "HARNESS_ERROR", ["junit_missing"]
    if int(junit["tests"]) != 1:
        return "HARNESS_ERROR", ["selector_did_not_produce_exactly_one_testcase"]
    if junit["errors"]:
        return "HARNESS_ERROR", ["pytest_setup_import_or_teardown_error"]
    if origins is None:
        return "EVIDENCE_INCOMPLETE", ["driver_or_child_origin_inventory_missing"]
    runtime_profile_path = case_root / "pytest-runtime-profile.json"
    if not runtime_profile_path.is_file():
        return "HARNESS_ERROR", ["pytest_runtime_profile_missing"]
    runtime_profile = json.loads(runtime_profile_path.read_text(encoding="utf-8"))
    if (
        runtime_profile.get("schema") != "policyos.e02.r1.pytest_runtime_profile.v1"
        or runtime_profile.get("python_version") != environment["python_version"]
        or Path(str(runtime_profile.get("python_executable", ""))).resolve()
        != (WORKSPACE / str(environment["python_executable"])).resolve()
        or runtime_profile.get("pytest_version") != environment["pytest_version"]
    ):
        return "HARNESS_ERROR", ["pytest_runtime_profile_mismatch"]
    case_id = str(case_row["case_id"])
    tests = int(junit["tests"])
    failures = junit["failures"]
    errors = junit["errors"]
    skipped = junit["skipped"]
    rc = result.get("return_code")
    if case_id == "r1-cache-read-removal":
        call_log = case_root / "mutation/cache-read-calls.jsonl"
        if not call_log.is_file():
            return "HARNESS_ERROR", ["mutation_call_log_missing"]
        events = [json.loads(line) for line in call_log.read_text(encoding="utf-8").splitlines() if line.strip()]
        driver_pid = origins["driver"]["pid"]
        if len(events) != 3 or any(e.get("pid") != driver_pid for e in events):
            return "HARNESS_ERROR", ["mutation_event_scope_or_count_mismatch"]
        forced = [e for e in events if e.get("event") == "NodeResultCache.get_forced_miss" and e.get("pid") == driver_pid and e.get("returned") is None]
        installed = [e for e in events if e.get("event") == "NodeResultCache.get_patch_installed" and e.get("pid") == driver_pid]
        restored = [e for e in events if e.get("event") == "NodeResultCache.get_restored" and e.get("pid") == driver_pid and e.get("restored") is True]
        plugin_loaded = any(row.get("name") == "remove_cache_read_plugin" for row in runtime_profile.get("plugins", []))
        forced_keys = [e.get("key") for e in forced]
        event_order = [e.get("event") for e in events]
        if len(forced) != 1 or not isinstance(forced_keys[0], str) or not forced_keys[0] or len(installed) != 1 or len(restored) != 1 or not plugin_loaded or event_order != ["NodeResultCache.get_patch_installed", "NodeResultCache.get_forced_miss", "NodeResultCache.get_restored"]:
            return "HARNESS_ERROR", ["mutation_not_reached_or_reader_not_restored"]
        failure_text = "\n".join(str(x.get("text", "")) + str(x.get("message", "")) for x in failures)
        target_failure = (
            "test_engine_executor_idempotency.py:541" in failure_text
            and "CachedCounterNode.calls == 0" in failure_text
            and "assert 1 == 0" in failure_text
        )
        if tests == 1 and len(failures) == 1 and not errors and not skipped and rc == 1 and target_failure:
            return "EXPECTED_RED", ["receiver_cache_read_removed_and_no_recompute_assertion_failed"]
        return "TEST_FAIL_UNCLASSIFIED", ["removal_result_did_not_match_exact_expected_red"]
    if any(row.get("name") == "remove_cache_read_plugin" for row in runtime_profile.get("plugins", [])):
        return "HARNESS_ERROR", ["removal_plugin_loaded_outside_control_case"]
    if tests == 1 and not failures and not errors and not skipped and rc == 0:
        return "PASS", ["current_source_positive_replay"]
    if errors or failures or skipped:
        return "TEST_FAIL", ["positive_or_restored_selector_failed"]
    return "HARNESS_ERROR", ["unexpected_pytest_exit_or_junit_shape"]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", required=True, type=Path)
    parser.add_argument("--expected-plan-sha256", required=True)
    parser.add_argument("--admission", required=True, type=Path)
    parser.add_argument("--expected-admission-sha256", required=True)
    parser.add_argument("--case", required=True)
    args = parser.parse_args()
    case_root: Path | None = None
    try:
        assert_no_symlink_components(args.plan.absolute())
        assert_no_symlink_components(args.admission.absolute())
        plan_path = args.plan.resolve(strict=True)
        plan, case_row = load_case_plan(plan_path, args.case)
        static_admission = verify_static_pins(plan, args.expected_plan_sha256, plan_path)
        admission_path = args.admission.resolve(strict=True)
        admission = load_admission(admission_path, args.expected_admission_sha256)
        environment = plan["environment"]
        assert isinstance(environment, dict)
        os.environ["PATH"] = str(environment["controller_path"])
        python_path = WORKSPACE / str(environment["python_executable"])
        if not python_path.is_file() or sha256(python_path) != environment["python_executable_sha256"]:
            raise AdmissionError("python_executable_pin_mismatch")
        helper_bundle = runpy.run_path(str(ROOT_LAYER))
        guard = helper_bundle["guard"]
        source_admission = verify_source_and_inputs(plan, admission, guard)
        source_blobs, git_object_format = git_source_blob_map()
        source = admission["source_binding"]
        assert isinstance(source, dict)
        if git_object_format != environment["git_object_format"] or git_object_format != source["git_object_format"]:
            raise AdmissionError("git_object_format_mismatch")
        source_admission["git_source_blob_count"] = len(source_blobs)
        source_admission["git_object_format"] = git_object_format
        source_admission["git_source_blob_map_sha256"] = hashlib.sha256(
            json.dumps(source_blobs, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest()
        resources = resource_snapshot(plan)

        output_spec = plan["execution"]
        assert isinstance(output_spec, dict)
        runs_root = WORKSPACE / str(output_spec["runs_root"])
        case_root = runs_root / str(case_row["case_id"])
        assert_no_symlink_components(runs_root)
        if not runs_root.exists():
            runs_root.mkdir(parents=True, exist_ok=False)
        if not runs_root.is_dir():
            raise AdmissionError("runs_root_not_directory")
        assert_no_symlink_components(runs_root)
        assert_no_symlink_components(case_root)
        if os.path.lexists(case_root):
            raise AdmissionError(f"case_output_already_exists:{case_root}")
        case_root.mkdir(parents=True, exist_ok=False)
        for name in ("tmp", "home", "readsets", "pytest-cache", "benchmarks", "basetemp"):
            (case_root / name).mkdir()
        mutation_dir = case_root / "mutation"
        if case_row["case_id"] == "r1-cache-read-removal":
            mutation_dir.mkdir()
        pycache_prefix = case_root / "pycache-prefix-absent"
        if os.path.lexists(pycache_prefix):
            raise AdmissionError("private_pycache_prefix_not_absent")
        sys.pycache_prefix = str(pycache_prefix)

        helper_dir = PACKET.resolve()
        sitecustomize = helper_dir / "sitecustomize.py"
        plugin = helper_dir / "remove_cache_read_plugin.py"
        nodeid = str(case_row["nodeid"])
        plugin_args = ["-p", "remove_cache_read_plugin"] if case_row["case_id"] == "r1-cache-read-removal" else []
        launcher = case_root / "pytest_launcher.py"
        launcher_text = pytest_profile_launcher(
            sitecustomize,
            python_path.resolve(),
            str(environment["python_version"]),
            str(environment["pytest_version"]),
            case_root / "pytest-runtime-profile.json",
            str(case_row["case_id"]),
            nodeid,
            plugin_args,
            case_root,
        )
        launcher.write_text(launcher_text, encoding="utf-8")
        sandbox = case_root / "child.sb"
        sandbox_text = (
            "(version 1)\n"
            "(allow default)\n"
            "(deny file-write*)\n"
            "(allow file-write* (subpath " + json.dumps(str(case_root)) + "))\n"
            '(allow file-write* (literal "/dev/null"))\n'
        )
        sandbox.write_text(sandbox_text, encoding="utf-8")

        supervisor_spec = importlib.util.spec_from_file_location("r1_retained_supervisor", str(SUPERVISOR))
        if supervisor_spec is None or supervisor_spec.loader is None:
            raise AdmissionError("retained_supervisor_import_spec_unavailable")
        supervisor = importlib.util.module_from_spec(supervisor_spec)
        sys.modules[supervisor_spec.name] = supervisor
        supervisor_spec.loader.exec_module(supervisor)
        limits = plan["resource_admission"]
        assert isinstance(limits, dict)
        supervisor.RSS_CAP_BYTES = int(limits["sampled_process_tree_rss_cap_bytes"])
        supervisor.DISK_FLOOR_BYTES = int(limits["supervisor_disk_stop_floor_bytes"])
        supervisor.SAMPLE_SECONDS = float(limits["sample_interval_seconds"])
        signal.signal(signal.SIGTERM, supervisor.note_stop_signal)
        signal.signal(signal.SIGINT, supervisor.note_stop_signal)

        env = {
            "PATH": str(environment["controller_path"]),
            "HOME": str(case_root / "home"),
            "TMPDIR": str(case_root / "tmp"),
            "XDG_CACHE_HOME": str(case_root / "tmp/xdg"),
            "MPLCONFIGDIR": str(case_root / "tmp/mpl"),
            "NUMBA_CACHE_DIR": str(case_root / "tmp/numba"),
            "HYPOTHESIS_STORAGE_DIRECTORY": str(case_root / "tmp/hypothesis"),
            "PYTHONPATH": str(helper_dir),
            "PYTHONPYCACHEPREFIX": str(pycache_prefix),
            "PYTHONNOUSERSITE": "1",
            "PYTHONDONTWRITEBYTECODE": "1",
            "PYTHONUNBUFFERED": "1",
            "POLISYOS_R1_PROJECT_ROOT": str(PRODUCT.resolve()),
            "POLISYOS_R1_READSET_DIR": str((case_root / "readsets").resolve()),
            "POLISYOS_R1_RUNTIME_PROFILE": str((case_root / "pytest-runtime-profile.json").resolve()),
        }
        for optional in ("LANG", "LC_ALL", "LC_CTYPE"):
            if optional in os.environ:
                env[optional] = os.environ[optional]
        env.update(supervisor.NUMERIC_THREADS)
        if case_row["case_id"] == "r1-cache-read-removal":
            env["POLISYOS_R1_MUTATION_CALL_LOG"] = str(case_root / "mutation/cache-read-calls.jsonl")

        argv = [
            str(PRODUCT / ".venv/bin/python"),
            "-B",
            str(launcher),
        ]
        source_profile = {
            "schema": "policyos.e02.r1.current_source_native_case_freeze.v1",
            "state": "FROZEN_BEFORE_SINGLE_CASE; NOT_G_ACCEPTANCE",
            "case_id": case_row["case_id"],
            "plan_path": str(plan_path.relative_to(WORKSPACE)),
            "plan_sha256": static_admission["plan_sha256"],
            "admission_path": str(admission_path.relative_to(WORKSPACE)),
            "admission_sha256": sha256(admission_path),
            "source_admission": source_admission,
            "resource_admission": resources,
            "selected_case": case_row,
            "current_sitecustomize": {"path": str(sitecustomize.relative_to(WORKSPACE)), "sha256": sha256(sitecustomize)},
            "current_removal_plugin": {"path": str(plugin.relative_to(WORKSPACE)), "sha256": sha256(plugin)},
            "fresh_launcher": {"path": str(launcher.relative_to(WORKSPACE)), "sha256": sha256(launcher), "source": launcher_text},
            "sandbox": {"path": str(sandbox.relative_to(WORKSPACE)), "sha256": sha256(sandbox), "text": sandbox_text},
            "environment_overrides_only": env,
            "ambient_environment_policy": "host environment is temporarily reduced to PATH and locale for the supervisor spawn; child gets only the recorded env plus supervisor numeric thread caps; no credentials are forwarded",
            "argv": ["/usr/bin/sandbox-exec", "-f", str(sandbox), *argv],
            "cwd": str(PRODUCT),
            "python_profile": {
                "retained_interpreter": str(environment["python_executable"]),
                "resolved_interpreter": str(python_path.resolve()),
                "python_version": environment["python_version"],
                "pytest_version_expected_and_checked_in_process": environment["pytest_version"],
                "uv_version_from_retained_pyvenv_cfg": environment["uv_version"],
                "pytest_ini": "policy-engine/pytest.ini at admitted source bytes",
                "bytecode_policy": "-B + PYTHONDONTWRITEBYTECODE=1 + unique absent case-local PYTHONPYCACHEPREFIX; verify prefix remains absent",
            },
            "closure_ids": [],
        }
        write_json(case_root / "source-profile-freeze.json", source_profile)

        overall_start = time.monotonic()
        deadline = overall_start + float(limits["wall_limit_seconds_per_case"])
        old_env = os.environ.copy()
        try:
            os.environ.clear()
            os.environ.update({k: v for k, v in env.items() if k in {"PATH", "LANG", "LC_ALL", "LC_CTYPE"}})
            result = supervisor.run_command(
                case_root,
                str(case_row["case_id"]),
                ["/usr/bin/sandbox-exec", "-f", str(sandbox), *argv],
                PRODUCT,
                overall_start,
                deadline,
                env,
            )
        finally:
            os.environ.clear()
            os.environ.update(old_env)

        junit = parse_junit(case_root / "pytest.xml")
        origins = None
        origin_error = None
        try:
            origins = read_process_origins(
                case_root,
                PRODUCT,
                python_path.resolve(),
                str(environment["python_version"]),
                source_blobs,
                git_object_format,
                None,
            )
        except Exception as exc:  # evidence is preserved and classified, never retried here
            origin_error = {"type": type(exc).__name__, "message": str(exc)}
        classification, reasons = classify_case(case_row, result, junit, origins, case_root, environment)
        post_admission_error = None
        try:
            verify_static_pins(plan, args.expected_plan_sha256, plan_path)
            load_admission(admission_path, args.expected_admission_sha256)
            post = verify_source_and_inputs(plan, admission, guard)
        except Exception as exc:
            post = None
            post_admission_error = {"type": type(exc).__name__, "message": str(exc)}
            classification = "HARNESS_ERROR"
            reasons.append("post_run_source_or_input_reconciliation_failed")
        if os.path.lexists(pycache_prefix):
            classification = "HARNESS_ERROR"
            reasons.append("unexpected_private_pycache_prefix_created")
        outputs = []
        for path in sorted(case_root.rglob("*")):
            if path.is_symlink():
                classification = "HARNESS_ERROR"
                reasons.append("unexpected_symlink_in_case_output")
            elif path.is_file() and path.name != "audit-result.json":
                outputs.append({"path": str(path.relative_to(WORKSPACE)), "size_bytes": path.stat().st_size, "sha256": sha256(path)})
        audit = {
            "schema": "policyos.e02.r1.current_source_native_case_result.v1",
            "classification": classification,
            "reasons": reasons,
            "case_id": case_row["case_id"],
            "source_profile_freeze_sha256": sha256(case_root / "source-profile-freeze.json"),
            "plan_sha256": static_admission["plan_sha256"],
            "admission_sha256": sha256(admission_path),
            "supervisor_result": result,
            "junit": junit,
            "process_origins": origins,
            "origin_error": origin_error,
            "post_run_source_reconciliation": post,
            "post_run_source_reconciliation_error": post_admission_error,
            "outputs": outputs,
            "g_acceptance": False,
            "closure_ids": [],
            "limitations": ["one exact R1 selector only", "not the 13-contour R1 task completion", "no G acceptance or formal closure"],
        }
        write_json(case_root / "audit-result.json", audit)
        print(json.dumps({"case_id": case_row["case_id"], "classification": classification, "junit": junit, "audit_sha256": sha256(case_root / "audit-result.json")}, sort_keys=True), flush=True)
        return 0 if classification in {"PASS", "EXPECTED_RED"} else 1
    except Exception as exc:
        if case_root is not None and case_root.is_dir() and not (case_root / "runner-error.json").exists():
            try:
                write_json(case_root / "runner-error.json", {"classification": "HARNESS_ERROR", "error_type": type(exc).__name__, "error": str(exc), "traceback": traceback.format_exc(), "closure_ids": []})
            except Exception:
                pass
        print(json.dumps({"classification": "HARNESS_ERROR", "error_type": type(exc).__name__, "error": str(exc)}, sort_keys=True), file=sys.stderr, flush=True)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
