from pathlib import Path
import subprocess, hashlib, json, ast, difflib
ROOT=Path.cwd(); OUT=ROOT/'LOCAL/raw/e02-execution-20261027/repairs/C38-tests-r1'
R3=ROOT/'LOCAL/raw/e02-execution-20261027/repairs/C38-r3'
BASE='caa91a64d7d6afc4310186ba5fadbac2008dddab'
CLOUD='4396ab7ed42ebcd0aad742ac1f402ffcbccd0c65'
expected='4a40acfb3151e532d71b23cd87557dd76932d0f4992dbedc3b07425ac7d6af16'
assert hashlib.sha256((R3/'manifest.json').read_bytes()).hexdigest()==expected
source=json.loads((R3/'manifest.json').read_text())
for item in source['paths']:
    assert hashlib.sha256((R3/'postimages'/item['path']).read_bytes()).hexdigest()==item['postimage_sha256']
checks=[]; entries=[]; patch=[]
paths=sorted(str(p.relative_to(OUT/'postimages')) for p in (OUT/'postimages').rglob('*.py'))
python=str(ROOT/'policy-engine/.venv/bin/python')
for path in paths:
    f=OUT/'postimages'/path
    lint=subprocess.run([python,'-m','ruff','check','--fix','--stdin-filename',str(ROOT/path),'-'],input=f.read_bytes(),capture_output=True,cwd=ROOT/'policy-engine')
    # Ruff's stdin output is corrected code; messages go to stderr.
    if lint.stdout: f.write_bytes(lint.stdout)
    fmt=subprocess.run([python,'-m','ruff','format','--stdin-filename',str(ROOT/path),'-'],input=f.read_bytes(),capture_output=True,cwd=ROOT/'policy-engine')
    if fmt.returncode==0: f.write_bytes(fmt.stdout)
    post=f.read_bytes(); ast.parse(post,filename=path)
    check=subprocess.run([python,'-m','ruff','check','--stdin-filename',str(ROOT/path),'-'],input=post,capture_output=True,cwd=ROOT/'policy-engine')
    token=Path(path).stem
    (OUT/f'ruff-{token}.stdout').write_bytes(check.stdout); (OUT/f'ruff-{token}.stderr').write_bytes(check.stderr)
    checks.append({'path':path,'exit_code':check.returncode,'stdout':f'ruff-{token}.stdout','stderr':f'ruff-{token}.stderr'})
    before=subprocess.run(['git','show',f'{BASE}:{path}'],capture_output=True)
    pre=before.stdout if before.returncode==0 else b''
    cloud=subprocess.run(['git','show',f'{CLOUD}:{path}'],capture_output=True)
    diff=''.join(difflib.unified_diff(pre.decode().splitlines(True),post.decode().splitlines(True),fromfile=f'a/{path}' if before.returncode==0 else '/dev/null',tofile=f'b/{path}'))
    patch.append(diff)
    tests=[n.name for n in ast.parse(post).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_')]
    entries.append({'path':path,'postimage_file':str(f.relative_to(OUT)),'new_file':before.returncode!=0,'local_preimage_sha256':hashlib.sha256(pre).hexdigest() if before.returncode==0 else None,'local_preimage_bytes':len(pre) if before.returncode==0 else None,'cloud_preimage_sha256':hashlib.sha256(cloud.stdout).hexdigest() if cloud.returncode==0 else None,'postimage_sha256':hashlib.sha256(post).hexdigest(),'postimage_bytes':len(post),'test_functions':tests})
(OUT/'tests.patch').write_text(''.join(patch))
app=subprocess.run(['git','apply','--check',str(OUT/'tests.patch')],capture_output=True)
(OUT/'apply-check.stdout').write_bytes(app.stdout); (OUT/'apply-check.stderr').write_bytes(app.stderr)
manifest={'schema':'policyos.c38_regression_companions.v1','base_commit':BASE,'cloud_test_origin_tree':CLOUD,'source_manifest':'../C38-r3/manifest.json','source_manifest_sha256':expected,'source_review':'../../reviews/C38-r3-code.md','source_review_sha256':'3498117af23f1975db414d101c9162296b12b2bc07699f8270bee54286ad11d5','source_postimages':[{'path':x['path'],'sha256':x['postimage_sha256']} for x in source['paths']],'tests':entries,'patch_sha256':hashlib.sha256((OUT/'tests.patch').read_bytes()).hexdigest(),'canonical_source_index_refs_written':False,'runtime':'UNRUN','verification':{'ast':'PASS','ruff':checks,'apply_check_exit':app.returncode}}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'test_files':len(entries),'ast':'PASS','ruff':[(c['path'],c['exit_code']) for c in checks],'apply':app.returncode,'manifest_sha256':hashlib.sha256((OUT/'manifest.json').read_bytes()).hexdigest()}))
