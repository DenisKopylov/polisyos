"""Explicitly gated, bounded local execution for the I2 phase observer. Not run by preparation."""
import argparse
import gzip
import hashlib
import json
import os
import resource
import selectors
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path

PACKET = Path(__file__).resolve().parent
ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
PRODUCT = ROOT / "policy-engine"
OUT = PACKET / "run" / "attempt-r178-1"
MANIFEST = json.loads((PACKET / "manifest.json").read_text(encoding="utf-8"))


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def git(*args):
    return subprocess.check_output(["git", "-C", str(ROOT), *args], text=True).strip()


def preflight():
    identity = {
        "branch": git("symbolic-ref", "--short", "HEAD"),
        "head": git("rev-parse", "HEAD"),
        "tree": git("rev-parse", "HEAD^{tree}"),
    }
    if identity != MANIFEST["source_identity"]:
        raise RuntimeError("source admission mismatch; no command executed")
    if subprocess.run(["git", "-C", str(ROOT), "diff", "--quiet", "HEAD", "--"]).returncode:
        raise RuntimeError("tracked worktree is dirty; no command executed")
    if subprocess.run(["git", "-C", str(ROOT), "diff", "--cached", "--quiet"]).returncode:
        raise RuntimeError("index is dirty; no command executed")
    for rel, pin in MANIFEST["source_pins"].items():
        if sha(ROOT / rel) != pin["sha256"]:
            raise RuntimeError("source pin mismatch: " + rel)
    packet_hash_path = PACKET / "packet-hashes.json"
    if sha(packet_hash_path) != MANIFEST.get("packet_hashes_sha256"):
        raise RuntimeError("packet manifest hash mismatch; no command executed")
    packet_hashes = json.loads(packet_hash_path.read_text(encoding="utf-8"))
    for rel, expected in packet_hashes.items():
        if sha(PACKET / rel) != expected:
            raise RuntimeError("prepared instrument packet changed: " + rel)
    free = shutil.disk_usage(PRODUCT).free
    min_free = MANIFEST["resources"]["execution_admission"]["minimum_free_disk_bytes"]
    if free < min_free:
        raise RuntimeError("disk admission below 6 GiB; no command executed")
    return {**identity, "disk_free_bytes": free, "disk_free_after_requirement_bytes": free - min_free,
            "root_guard_sha256": sha(ROOT / MANIFEST["root_guard_path"])}


def set_child_limits():
    # These are hard limits. RLIMIT_AS is virtual address space, not RSS.
    resource.setrlimit(resource.RLIMIT_CPU, (110, 112))
    resource.setrlimit(resource.RLIMIT_AS, (6 * 1024**3, 6 * 1024**3))
    resource.setrlimit(resource.RLIMIT_FSIZE, (512 * 1024**2, 512 * 1024**2))


def subtree_bytes(path):
    total = 0
    for current, dirs, files in os.walk(path, followlinks=False):
        dirs[:] = [name for name in dirs if not (Path(current) / name).is_symlink()]
        for name in files:
            item = Path(current) / name
            if not item.is_symlink():
                total += item.stat().st_size
    return total


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--execute", action="store_true", help="required; preparation never starts a run")
    args = parser.parse_args()
    if not args.execute:
        parser.error("run only after Root issues a source/resource lease and says --execute")
    OUT.mkdir(parents=True, exist_ok=False)
    pre = preflight()
    (OUT / "preflight.json").write_text(json.dumps(pre, indent=2) + "\n", encoding="utf-8")
    profile = PACKET / "sandbox.sb"
    profile.write_text("(version 1)\n(allow default)\n(deny file-write*)\n(allow file-write* (subpath " + json.dumps(str(OUT)) + "))\n(allow file-write* (literal \"/dev/null\"))\n", encoding="utf-8")
    (OUT / "tmp").mkdir()
    python = str(PRODUCT / ".venv/bin/python")
    command = ["/usr/bin/sandbox-exec", "-f", str(profile), python, "-B", str(PACKET / "launch_cli.py")]
    env = os.environ.copy()
    env.update({
        "GIT_OPTIONAL_LOCKS": "0",
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONPATH": str(PACKET / "observer") + os.pathsep + str(PRODUCT),
        "TMPDIR": str(OUT / "tmp"),
        "E02_PHASE_PROFILE_DIR": str(OUT),
        "E02_PHASE_PACKET": str(PACKET),
        "POLISYOS_TOOLS_TIMING_LOG": str(OUT / "cli-timing.jsonl"),
    })
    public_cli_argv = ["polisyos-tools", "validation", "schema-fqn-census", "--output-format", "json", "--repo-root", "."]
    (OUT / "command.json").write_text(json.dumps({"supervised_argv": command,
        "public_cli_argv": public_cli_argv, "cwd": str(PRODUCT),
        "scope": "unchanged public tools.cli dispatch via runpy; observer wraps in-memory functions and regex iterators",
        "source_identity": MANIFEST["source_identity"]}, indent=2) + "\n", encoding="utf-8")
    stdout_path, stderr_path = OUT / "public-output.json.gz", OUT / "stderr.log"
    raw_hash = hashlib.sha256()
    raw_bytes = 0
    compressed_limit = MANIFEST["resources"]["max_compressed_output_bytes"]
    raw_limit = MANIFEST["resources"]["max_uncompressed_output_bytes"]
    stderr_limit = MANIFEST["resources"]["max_stderr_bytes"]
    started = time.monotonic()
    stop_reason = None
    process = subprocess.Popen(command, cwd=PRODUCT, env=env, stdout=subprocess.PIPE,
        stderr=subprocess.PIPE, stdin=subprocess.DEVNULL, close_fds=True,
        start_new_session=True, preexec_fn=set_child_limits)
    ready_deadline = time.monotonic() + 5.0
    while not (OUT / "observer.ready").is_file() and process.poll() is None and time.monotonic() < ready_deadline:
        time.sleep(0.05)
    if not (OUT / "observer.ready").is_file():
        stop_reason = "observer_not_armed"
        try:
            os.killpg(process.pid, signal.SIGTERM)
            process.wait(timeout=3)
        except (ProcessLookupError, subprocess.TimeoutExpired):
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait()
    selector = selectors.DefaultSelector()
    selector.register(process.stdout, selectors.EVENT_READ, "stdout")
    selector.register(process.stderr, selectors.EVENT_READ, "stderr")
    os.set_blocking(process.stdout.fileno(), False)
    os.set_blocking(process.stderr.fileno(), False)
    stderr_bytes = 0
    with stdout_path.open("wb") as compressed_file, gzip.GzipFile(fileobj=compressed_file, mode="wb", mtime=0) as gz, stderr_path.open("wb") as stderr_file:
        deadline = started + MANIFEST["resources"]["wall_timeout_seconds"]
        while selector.get_map() or process.poll() is None:
            if time.monotonic() >= deadline:
                stop_reason = "harness_wall_timeout"
                break
            if subtree_bytes(OUT / "tmp") > MANIFEST["resources"]["hard_caps"]["tmpdir_bytes"]:
                stop_reason = "tmpdir_aggregate_cap"
                break
            for key, _ in selector.select(timeout=0.5):
                chunk = os.read(key.fd, 65536)
                if not chunk:
                    selector.unregister(key.fileobj)
                    continue
                if key.data == "stdout":
                    raw_bytes += len(chunk)
                    if raw_bytes > raw_limit:
                        stop_reason = "public_output_uncompressed_cap"
                        break
                    raw_hash.update(chunk)
                    gz.write(chunk)
                    compressed_file.flush()
                    if compressed_file.tell() > compressed_limit:
                        stop_reason = "public_output_compressed_cap"
                        break
                else:
                    stderr_bytes += len(chunk)
                    if stderr_bytes > stderr_limit:
                        stop_reason = "stderr_cap"
                        break
                    stderr_file.write(chunk)
            if stop_reason:
                break
        if stop_reason:
            try:
                os.killpg(process.pid, signal.SIGTERM)
                process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
        else:
            process.wait()
        # Drain bounded remaining pipes after the child is reaped.
        for stream, label in ((process.stdout, "stdout"), (process.stderr, "stderr")):
            while True:
                try: chunk = os.read(stream.fileno(), 65536)
                except BlockingIOError: break
                if not chunk: break
                if label == "stdout" and raw_bytes + len(chunk) <= raw_limit:
                    raw_bytes += len(chunk); raw_hash.update(chunk); gz.write(chunk)
                elif label == "stderr" and stderr_bytes + len(chunk) <= stderr_limit:
                    stderr_bytes += len(chunk); stderr_file.write(chunk)
                else:
                    stop_reason = stop_reason or ("public_output_uncompressed_cap" if label == "stdout" else "stderr_cap")
                    break
    wall = time.monotonic() - started
    rc = process.returncode
    after = {"branch": git("symbolic-ref", "--short", "HEAD"), "head": git("rev-parse", "HEAD"),
             "tree": git("rev-parse", "HEAD^{tree}"), "root_guard_sha256": sha(ROOT / MANIFEST["root_guard_path"])}
    source_drift = after["head"] != pre["head"] or after["tree"] != pre["tree"] or after["branch"] != pre["branch"]
    root_guard_drift = after["root_guard_sha256"] != pre["root_guard_sha256"]
    if (source_drift or root_guard_drift) and stop_reason is None:
        stop_reason = "source_or_root_guard_changed_during_diagnostic"
    classification = "HARNESS_INCOMPLETE" if stop_reason or rc < 0 else "CLI_RETURNED_REQUIRES_RECEIPT_RECONCILIATION"
    receipt = {
        "classification": classification,
        "stop_reason": stop_reason, "exit_code": rc, "wall_seconds": round(wall, 3),
        "postflight_source_identity": after, "source_drift": source_drift, "root_guard_drift": root_guard_drift,
        "command": command, "source_identity": pre,
        "public_stdout_uncompressed_bytes": raw_bytes, "public_stdout_sha256": raw_hash.hexdigest(),
        "public_stdout_gzip_bytes": stdout_path.stat().st_size, "public_stdout_gzip_sha256": sha(stdout_path),
        "stderr_bytes": stderr_bytes, "stderr_sha256": sha(stderr_path),
        "max_supervisor_direct_child_rusage_platform_units": resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
        "rss_scope_note": "RUSAGE_CHILDREN is not asserted to be process-tree RSS; RLIMIT_AS plus one process group are the enforced memory controls.",
        "source_semantic_result": "UNRUN unless completed JSON is independently parsed and reconciled",
        "g_acceptance": False, "closure_ids": []
    }
    (OUT / "supervisor-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: receipt[k] for k in ("classification", "stop_reason", "exit_code", "wall_seconds", "public_stdout_uncompressed_bytes", "public_stdout_gzip_bytes")}, sort_keys=True))
    return rc if stop_reason is None and rc >= 0 else 124


if __name__ == "__main__":
    raise SystemExit(main())
