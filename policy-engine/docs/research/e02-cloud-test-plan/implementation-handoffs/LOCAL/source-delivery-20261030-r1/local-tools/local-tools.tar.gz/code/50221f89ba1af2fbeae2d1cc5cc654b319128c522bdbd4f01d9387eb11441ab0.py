"""Prepare, but never execute, a reviewed canonical-source C32 native case."""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
PACKET = Path(__file__).resolve().parent
RUNNER_DIR = ROOT / ('policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/'
    'LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/'
    'deep-task-status-audit-20261027-r1')
IDENTITY = 'tests/unit/runtime/quality/test_catalog_source_identity.py'


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-head', required=True)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--suffix', required=True)
    parser.add_argument('--mode', choices=['pilot', 'owner', 'controller', 'companions',
        'registry', 'store', 'calibration', 'residual', 'normal-diagnostic', 'graph', 'fabric-family', 'n7-source'], required=True)
    args = parser.parse_args()
    assert args.suffix and all(c.isalnum() or c in '-_' for c in args.suffix)
    sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
    manifest_path = PACKET / 'manifest.json'
    assert sha(manifest_path) == args.manifest_sha256
    manifest = json.loads(manifest_path.read_text())
    git = lambda *parts: subprocess.check_output(['git', *parts], cwd=ROOT, text=True).strip()
    assert git('symbolic-ref', '--short', 'HEAD') == 'codex/e02-unified-local-20261009'
    assert git('rev-parse', 'HEAD') == args.source_head
    assert git('status', '--porcelain', '--untracked-files=no') == ''
    pins = {}
    for row in manifest['files']:
        if not row['path'].endswith('.py'):
            continue
        path = ROOT / row['path']
        allowed = row.get('accepted_postimage_sha256', [row['postimage_sha256']])
        assert sha(path) in allowed, ('re-review composed source before native run', str(path))
        committed = subprocess.check_output(['git', 'show', args.source_head+':'+row['path']], cwd=ROOT)
        assert hashlib.sha256(committed).hexdigest() == sha(path), path
        pins[row['path']] = sha(path)
    cases = {
        'graph': ['tests/unit/runtime/quality/test_catalog_acquisition_source_binding.py'],
        'fabric-family': ['tests/unit/fabric/retrieval/test_catalog_read_source_failure.py'],
        'n7-source': ['tests/unit/runtime/quality/test_catalog_n7_source_refusal.py'],
        'pilot': [IDENTITY+'::test_available_owner_reads_all_actual_rows_under_the_admitted_source'],
        'owner': [IDENTITY, 'tests/unit/data_forge/domains/catalog/knowledge/test_variable_availability.py'],
        'controller': [IDENTITY+'::test_controller_keeps_real_owner_gap_and_fresh_planner_or_typed_readmission'],
        'companions': json.loads((PACKET/'affected-nodes.json').read_text())['nodes'],
        'registry': ['tests/unit/runtime/quality/test_data_state_substrate.py',
            'tests/unit/runtime/quality/test_catalog_source_selection.py',
            'tests/unit/runtime/quality/test_substrate_registry.py',
            'tests/unit/runtime/quality/test_acquisition_planner.py'],
        'store': ['tests/unit/data_forge/domains/catalog/knowledge/test_store.py',
            'tests/unit/data_forge/domains/catalog/knowledge/test_overlay.py'],
        'calibration': ['tests/unit/runtime/http/test_predictive_calibration_profile_boundary.py',
            'tests/unit/runtime/http/test_predictive_calibration_event_selection.py',
            'tests/integration/core_runtime/test_predictive_calibration_profile_owner_binding.py'],
        'residual': ['tests/unit/data_forge/domains/catalog/knowledge/test_catalog_custody_boundary.py'],
        'normal-diagnostic': ['tests/unit/runtime/quality/test_n7_source_gap_projection.py::'
            'test_n7_source_gap_semantics_survive_compiler_and_fresh_route_read'],
    }
    nodes = cases[args.mode]
    assert all((ROOT/'policy-engine'/n.split('::')[0]).is_file() for n in nodes)
    case = 'c32-r7-'+args.mode+'-'+args.suffix
    plan = {'case_id': case, 'source_head': args.source_head,
        'source_tree': git('rev-parse', 'HEAD^{tree}'),
        'task_ids': ['V4', 'V7', 'C32'], 'nodes': nodes, 'extra_env': {},
        'deadline_seconds': 600, 'rss_cap_bytes': 2411724800,
        'scope': ('Selected Catalog full baseline/overlay identity and actual consumers only. '
            'Run new owner/native profiles alone first; 600s/2.25GiB are admission guards, not '
            'previously measured promises. Controller and N7 source-transport witnesses are contract_testing, not ordinary '
            'served CGF. Normal-diagnostic retains the original fixture mismatch and has no promised '
            'PASS. Residual mode measures an ABA attempt: read the retained JSON; pytest completion '
            'does not establish atomic custody or an observed escape. No authority, production '
            'currentness, V4/V7 acceptance, or G closure.'),
        'reviewed_source_pins': pins, 'closure_ids': []}
    path = RUNNER_DIR / (case+'.json')
    assert not path.exists() and not (RUNNER_DIR/case).exists()
    path.write_text(json.dumps(plan, indent=2)+'\n')
    assert json.loads(path.read_text()) == plan
    print(json.dumps({'prepared_only': True, 'plan': str(path), 'sha256': sha(path),
        'runtime': 'UNRUN', 'runner': str(RUNNER_DIR/'run_case_with_tools_r2.py')}))


if __name__ == '__main__':
    main()
