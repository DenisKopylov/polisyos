"""Preimage-only bounded AST collector diagnosis; fixture code is never executed."""
from __future__ import annotations
import ast
import hashlib
import json
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
PACKET = Path(__file__).resolve().parent
PRODUCT = ROOT / 'policy-engine'
READS = ['tools/quality/validation/decomposition_preflight.py', 'tests/repo_quality/architecture/test_decomposition_preflight_gates.py', 'src/polisyos/runtime/http/resilience.py', 'architecture/imports/dynamic.toml', 'docs/reference/policy-design-case-failure-patterns.md', 'CONTRIBUTING.md']
def snapshot():
    return {p: hashlib.sha256((PRODUCT / p).read_bytes()).hexdigest() for p in READS}
def git_identity():
    return subprocess.check_output(['git', 'rev-parse', 'HEAD', 'HEAD^{tree}'], cwd=ROOT, text=True).splitlines()
signal.alarm(110)
# RSS and wall limits are enforced by supervise.py; macOS rejects lowering RLIMIT_AS below its mapped address space.
start = time.monotonic()
preimage = snapshot()
head_before = git_identity()
sys.path.insert(0, str(PRODUCT))
from tools.quality.validation import decomposition_preflight as owner

ordinary = {
    'ordinary-noop': 'def body():\n    return None\nbody()\n',
    'ordinary-literal': 'from importlib import import_module\ndef body():\n    return import_module("bridge_literal")\nbody()\n',
    'ordinary-callback': 'from importlib import import_module\ndef body(callback):\n    return callback("bridge_callback")\nbody(import_module)\n',
}
bodies = {
    'reconstructed-noop': 'def body():\n    return None\n',
    'reconstructed-literal': 'from importlib import import_module\ndef body():\n    return import_module("bridge_literal")\n',
    'reconstructed-callback': 'from importlib import import_module\ndef body(callback):\n    return callback("bridge_callback")\n',
    'live-globals-mutation': 'from importlib import import_module\ndef body():\n    return load("bridge_mutation")\n',
    'captured-code-replacement': 'from importlib import import_module\ndef body():\n    return import_module("bridge_old_code")\ndef replacement():\n    return None\n',
    'explicit-defaults': 'def body(value=None):\n    return value\n',
    'explicit-closure': 'def body():\n    return None\n',
}
cases = dict(ordinary)
for name, body in bodies.items():
    source = 'from types import FunctionType\n' + body + 'CODE = body.__code__\n'
    if name == 'captured-code-replacement':
        source += 'body.__code__ = replacement.__code__\n'
    arguments = 'CODE, globals()'
    if name == 'explicit-defaults':
        arguments += ', "copy", (None,)'
    if name == 'explicit-closure':
        arguments += ', "copy", None, opaque_closure'
    source += f'run = FunctionType({arguments})\n'
    if name == 'live-globals-mutation':
        source += 'load = import_module\n'
    source += 'run(import_module)\n' if name == 'reconstructed-callback' else 'run()\n'
    cases[name] = source
cases.update({
    'class-deferred-real-shape': 'from types import FunctionType\nclass Guard:\n    def run(self, callback, *args, **kwargs):\n        return callback(*args, **kwargs)\nCODE = Guard.run.__code__\ndef invoke(guard, callback, *args, **kwargs):\n    run = FunctionType(CODE, globals())\n    return run(guard, callback, *args, **kwargs)\n',
    'opaque-constructor': 'def body():\n    return None\nCODE = body.__code__\nrun = opaque_constructor(CODE, globals())\nrun()\n',
    'opaque-code': 'from types import FunctionType\nrun = FunctionType(opaque_code, globals())\nrun()\n',
    'foreign-globals': 'from types import FunctionType\nfrom importlib import import_module\ndef body():\n    return load("bridge_foreign")\nCODE = body.__code__\nrun = FunctionType(CODE, {"load": import_module})\nrun()\n',
})
results = []
for name, source in cases.items():
    fixture = PACKET / 'fixtures' / name
    for scope in ('src', 'tools', 'apps', 'packages'):
        (fixture / scope).mkdir(parents=True, exist_ok=True)
    source_path = fixture / 'src/fixture.py'
    source_path.write_text(source, encoding='utf-8')
    owner.REPO_ROOT = fixture
    owner.SRC_ROOT = fixture / 'src'
    row = {'case': name, 'fixture_root': str(fixture), 'source_sha256': hashlib.sha256(source.encode()).hexdigest(), 'fixture_code_executed': False}
    try:
        entries = owner.collect_dynamic_imports()
    except owner.DynamicImportCollectionError as error:
        row.update(status='refused', error_type=type(error).__name__, error=str(error))
    else:
        row.update(status='collected', entries=entries)
    results.append(row)
by_name = {row['case']: row for row in results}
checks = {
    'ordinary_noop_empty': by_name['ordinary-noop']['status'] == 'collected' and by_name['ordinary-noop']['entries'] == [],
    'ordinary_literal_observed': by_name['ordinary-literal']['status'] == 'collected' and any(row['pattern'] == 'bridge_literal' for row in by_name['ordinary-literal']['entries']),
    'ordinary_callback_observed': by_name['ordinary-callback']['status'] == 'collected' and any(row['pattern'] == 'bridge_callback' for row in by_name['ordinary-callback']['entries']),
    'all_reconstruction_and_opaque_controls_refused': all(row['status'] == 'refused' for row in results if row['case'] not in ordinary),
}
resilience = PRODUCT / READS[2]
tree = ast.parse(resilience.read_text(), filename=str(resilience))
constructors = [{'line': node.lineno, 'expression': ast.unparse(node)} for node in ast.walk(tree) if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'FunctionType']
receipt = {'kind': 'diagnostic_preimage_only', 'candidate_status': 'no_candidate', 'owner_origin': str(Path(owner.__file__).resolve()), 'source_selection': 'canonical owner collect_dynamic_imports; explicit per-case REPO_ROOT and SRC_ROOT fixture roots, following existing _dynamic_import_fixture; actual owner origin unchanged', 'fixture_root_configuration_is_not_code_origin': True, 'head_tree_before': head_before, 'head_tree_after': git_identity(), 'readset_preimage_sha256': preimage, 'readset_postimage_sha256': snapshot(), 'checks': checks, 'results': results, 'resilience_direct_constructor_census': {'path': str(resilience.relative_to(ROOT)), 'file_type_denominator': 'one complete .py file AST; direct Name(FunctionType) Call nodes only', 'constructors': constructors}, 'resource_limits': {'wall_alarm_seconds': 110, 'rss_supervisor_limit_bytes': 512 * 1024 * 1024, 'full_collection': False, 'product_imports': sorted(name for name in sys.modules if name == 'polisyos' or name.startswith('polisyos.'))}, 'elapsed_seconds': time.monotonic() - start, 'ru_maxrss_platform_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
print(json.dumps(receipt, indent=2, sort_keys=True))
if not all(checks.values()):
    raise SystemExit(1)
