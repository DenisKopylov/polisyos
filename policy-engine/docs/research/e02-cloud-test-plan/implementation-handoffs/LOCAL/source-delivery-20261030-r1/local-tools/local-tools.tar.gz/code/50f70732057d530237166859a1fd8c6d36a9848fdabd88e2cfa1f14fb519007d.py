"""Prove synthetic tests detect a removed extractor, in this process only."""
import sys
import unittest
import controls
import structured_capture

def removed(*args, **kwargs):
    return {"status": "unavailable", "reason": "control_removed"}

structured_capture.extract = removed
controls.extract = removed
names = (
    "test_real_validation_error_has_bounded_selected_fields_and_no_private_payload",
    "test_real_monitor_keeps_return_identity_and_handles_extraction_fault",
)
suite = unittest.TestSuite(controls.Controls(name) for name in names)
result = unittest.TextTestRunner(verbosity=2).run(suite)
expected = len(result.failures) == 2 and not result.errors and result.testsRun == 2
print("removal control: expected 2/2 assertion failures" if expected else "removal control: UNEXPECTED")
sys.exit(0 if expected else 1)
