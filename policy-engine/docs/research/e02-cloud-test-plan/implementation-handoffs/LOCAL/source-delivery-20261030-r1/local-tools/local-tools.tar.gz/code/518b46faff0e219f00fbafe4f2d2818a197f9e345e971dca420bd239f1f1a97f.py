from pathlib import Path
s=Path('LOCAL/raw/e02-execution-20261027/repairs/C48-r5')

def path(rel): return s/'postimages'/rel
def change(p,a,b):
    v=p.read_text(); n=v.count(a)
    if n!=1: raise ValueError(f'{p}: anchor count {n}: {a[:80]}')
    p.write_text(v.replace(a,b))
core=path('policy-engine/src/polisyos/core/contracts/runtime.py')
registry=path('policy-engine/src/polisyos/scientist/methods/search/pareto_registry.py')
r=registry.read_text(); start=r.index('class CompletedExAnteCandidateSource('); end=r.index('\n\nclass ParetoRegistrySnapshot(',start)
classes=r[start:end]
classes=classes.replace('''    candidate_ref: ArtifactRef


class CompletedExAnteCandidateObservation''','''    candidate_ref: ArtifactRef

    @model_validator(mode="after")
    def _validate_source_selector(self) -> CompletedExAnteCandidateSource:
        if (
            self.candidate_ref.kind != "scientist.policy_design.candidate"
            or self.candidate_ref.media_type != "application/json"
            or self.candidate_ref.manifest_profile_sha256 is None
        ):
            raise ValueError("completed_candidate_source_selected_ref_invalid")
        return self


class CompletedExAnteComparisonRequest(BaseModel):
    """An explicit bounded set of selected-source lookup keys."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    sources: tuple[CompletedExAnteCandidateSource, ...] = Field(min_length=2, max_length=20)


class CompletedExAnteCandidateObservation''')
classes=classes.replace('''        elif self.observations or self.frontier_candidate_hashes or not self.limitations:
''','''        elif (
            self.comparison_contract_sha256 is not None
            or self.observations
            or self.frontier_candidate_hashes
            or not self.limitations
        ):
''')
registry.write_text(r[:start]+r[end+2:])
change(core,'class MethodMetricCandidateScore(BaseModel):\n',classes+'\n\n\nclass MethodMetricCandidateScore(BaseModel):\n')
change(core,'    candidate_score: MethodMetricCandidateScore | None = None\n','    candidate_score: MethodMetricCandidateScore | None = None\n    candidate_comparison: CompletedExAnteCandidateRanking | None = None\n')
for n in ('CompletedExAnteCandidateSource','CompletedExAnteComparisonRequest','CompletedExAnteCandidateObservation','CompletedExAnteCandidateRanking'):
    change(core,'    "MethodMetricCandidateScore",\n',f'    "{n}",\n    "MethodMetricCandidateScore",\n')

facade=path('policy-engine/src/polisyos/core/contracts/__init__.py')
for n in ('CompletedExAnteCandidateSource','CompletedExAnteComparisonRequest','CompletedExAnteCandidateObservation','CompletedExAnteCandidateRanking'):
    change(facade,'        "MethodMetricCandidateScore",\n',f'        "{n}",\n        "MethodMetricCandidateScore",\n')
    change(facade,'        MethodMetricCandidateScore,\n',f'        {n},\n        MethodMetricCandidateScore,\n')
    change(facade,'    "MethodMetricCandidateScore",\n',f'    "{n}",\n    "MethodMetricCandidateScore",\n')

change(registry,'from polisyos.core.artifacts.manifest import ArtifactRef, artifact_ref_identity_key\n', '''from polisyos.core.artifacts.manifest import ArtifactRef, artifact_ref_identity_key
from polisyos.core.contracts.runtime import (
    CompletedExAnteCandidateObservation,
    CompletedExAnteCandidateRanking,
    CompletedExAnteCandidateSource,
)
''')
change(registry,'        from polisyos.core.artifacts import validate_core_model_json_artifact\n','')
change(registry,'        from polisyos.scientist.policy_design.schema import PolicyCandidateSchema\n','')
change(registry,'''                if (
                    ref.kind != PolicyCandidateSchema.ARTIFACT_KIND
                    or ref.manifest_profile_sha256 is None
                ):
                    return CompletedExAnteCandidateRanking(
                        status="invalid", limitations=("candidate_selected_ref_invalid",)
                    )
                candidate = validate_core_model_json_artifact(PolicyCandidateSchema, store, ref)
''','')
change(registry,'''                if rank.minimized_score is None or rank.maximizing_coordinate is None:
''','''                if (
                    rank.minimized_score is None
                    or rank.maximizing_coordinate is None
                    or rank.candidate_hash is None
                ):
''')
change(registry,'                    candidate_hash=candidate.candidate_hash(),\n','                    candidate_hash=rank.candidate_hash,\n')

metrics=path('policy-engine/src/polisyos/scientist/nodes/builtins/decide/policy_runtime_method_metrics.py')
change(metrics,'    minimized_score: float | None = None\n    maximizing_coordinate: float | None = None\n','    candidate_hash: str | None = None\n    minimized_score: float | None = None\n    maximizing_coordinate: float | None = None\n')
change(metrics,'                self.minimized_score is None\n                or not math.isfinite(self.minimized_score)\n','                not self.candidate_hash\n                or self.minimized_score is None\n                or not math.isfinite(self.minimized_score)\n')
change(metrics,'            self.minimized_score is not None\n            or self.maximizing_coordinate is not None\n','            self.candidate_hash is not None\n            or self.minimized_score is not None\n            or self.maximizing_coordinate is not None\n')
change(metrics,'            status="selected",\n            minimized_score=minimized,\n','            status="selected",\n            candidate_hash=candidate.candidate_hash(),\n            minimized_score=minimized,\n')

planning=path('policy-engine/src/polisyos/scientist/nodes/builtins/planning/run_hierarchical_policy_search.py')
change(planning,'''from polisyos.core.contracts.trinity import TrinityBundleRef
''','''from polisyos.core.contracts.runtime import CompletedExAnteComparisonRequest
from polisyos.core.contracts.trinity import TrinityBundleRef
''')
change(planning,'''    CompletedExAnteCandidateSource,
    ParetoRegistry,
''','''    ParetoRegistry,
''')
change(planning,'''class _CompletedExAnteComparisonRequest(BaseModel):
    """Completed candidate sources are scoped lookup keys, not score authority."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    sources: tuple[CompletedExAnteCandidateSource, ...] = Field(min_length=2, max_length=20)


''','')
change(planning,'_CompletedExAnteComparisonRequest.model_validate(raw_comparison)','CompletedExAnteComparisonRequest.model_validate(raw_comparison)')
block='''            candidate_comparison = (
                ParetoRegistry.rank_completed_ex_ante_candidates(
                    ctx=ctx, sources=comparison_request.sources
                )
                if comparison_request is not None
                else None
            )
'''
change(planning,block,'')
change(planning,'''        new_state = branch_state(
            state,
            write_paths=(
                "params.policy_candidate_schema",
                "params.policy_search_result",
''','''        # Search may have taken long enough for an earlier source selection to
        # be replaced or revoked. Resolve both sources at final emission.
        candidate_comparison = (
            ParetoRegistry.rank_completed_ex_ante_candidates(
                ctx=ctx, sources=comparison_request.sources
            )
            if comparison_request is not None
            else None
        )
        new_state = branch_state(
            state,
            write_paths=(
                "params.policy_candidate_schema",
                "params.policy_search_result",
''')
