"""Synthetic profile and traceback witnesses; fake pytest, no product import."""
from __future__ import annotations

import io
import json
from types import ModuleType, SimpleNamespace
import sys

pytest = ModuleType('pytest')
pytest.hookimpl = lambda **_kwargs: lambda f: f
pytest.ExitCode = SimpleNamespace(INTERNAL_ERROR=3)
sys.modules['pytest'] = pytest
import r171_diagnostic as diag


def fake_basis():
    source_family_limitation = 'unbound_requirement_input_refused'
    routing_limitation_code = 'requirement_gap_not_compiled'
    request_binding_refused = False
    acquisition_request = {'required_data_families': ('foreign',), 'requirement_gap': {}}
    report = SimpleNamespace(requirement_basis=SimpleNamespace(state='not_established', basis_grade='not_established'))
    source = SimpleNamespace(requirement_gap_id='real-source-gap', metadata={'source':'l1_dcat_variable_availability'})
    assert source_family_limitation and routing_limitation_code and not request_binding_refused and acquisition_request
    return SimpleNamespace(compilation_report=report, routed_source_gap=source, routing_limitation_code=routing_limitation_code,
                           unbound_input_fields=(), specs=(), routed_compiler_gaps=())


diag.stream = io.StringIO()
diag.current = 'synthetic'
diag.basis_code = fake_basis.__code__
sys.setprofile(diag.observe)
fake_basis()
sys.setprofile(None)
rows = [json.loads(line) for line in diag.stream.getvalue().splitlines()]
assert len(rows) == 1 and rows[0]['source_family_limitation'] == 'unbound_requirement_input_refused'
assert rows[0]['returned_routing_limitation'] == 'requirement_gap_not_compiled'
assert rows[0]['source_gap_id'] == 'real-source-gap' and rows[0]['compiled_spec_ids'] == []


class SyntheticCycle:
    model_fields = {'payload': object()}
    __pydantic_private__ = None
    __pydantic_extra__ = None
    def __init__(self, value):
        self.payload = {'items': value}
    def model_dump(self, *, mode):
        assert mode == 'json'
        return {'payload': {'items': list(self.payload['items'])}}
    @classmethod
    def model_validate(cls, value):
        return cls(value['payload']['items'])
    def __eq__(self, other):
        return type(other) is type(self) and self.payload == other.payload


namespace = {'SyntheticCycle': SyntheticCycle}
exec(compile('def test_n7_grounding_gap_with_unestablished_basis_survives_fresh_reader():\n    cycle = SyntheticCycle((1,2))\n    assert SyntheticCycle.model_validate(cycle.model_dump(mode="json")) == cycle\n', '<synthetic-test>', 'exec'), namespace)
try:
    namespace['test_n7_grounding_gap_with_unestablished_basis_survives_fresh_reader']()
except AssertionError:
    tb = sys.exc_info()[2]
    entries = []
    while tb:
        entries.append(SimpleNamespace(frame=SimpleNamespace(raw=tb.tb_frame, f_locals=tb.tb_frame.f_locals)))
        tb = tb.tb_next
else:
    raise AssertionError('synthetic inequality did not occur')
item = SimpleNamespace(name='test_n7_grounding_gap_with_unestablished_basis_survives_fresh_reader', nodeid='synthetic-dto')
call = SimpleNamespace(when='call', excinfo=SimpleNamespace(traceback=entries))
generator = diag.pytest_runtest_makereport(item, call)
next(generator)
try:
    next(generator)
except StopIteration:
    pass
rows = [json.loads(line) for line in diag.stream.getvalue().splitlines()]
result = rows[-1]
assert result['event'] == 'cycle_reader_equality' and not result['original_equal']
assert result['differences'][0]['path'] == "cycle.payload['items']"
assert result['differences'][0]['reason'] == 'type_mismatch'
assert not diag.errors
print(json.dumps({'scope':'synthetic profile/traceback and fake pytest; no product import','events':rows}, indent=2))
