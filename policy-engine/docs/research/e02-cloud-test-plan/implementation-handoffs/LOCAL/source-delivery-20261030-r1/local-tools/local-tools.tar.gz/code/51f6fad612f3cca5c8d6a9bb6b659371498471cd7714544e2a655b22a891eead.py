"""Root-only C96 matched phases with a provisional 3 GiB cap; no work on import."""

from __future__ import annotations

import argparse
import ast
import gzip
import hashlib
import importlib.util
import json
import os
import platform
import runpy
import shutil
import signal
import sqlite3
import subprocess
import sys
import time
import traceback
import xml.etree.ElementTree as ET
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
RAW = ROOT / "LOCAL/raw/e02-execution-20261027"
PACKET = RAW / "repairs/R4-control-native-r3"
R1_FILE = RAW / "repairs/R4-control-native-r1/controller.py"
R1_SHA = "47acd822e06bb8b3f2979e35f93d2adfbfc0a8a46744de371f8d4752b3f34809"
BASE_CASE = RAW / "repairs/R4-control-front-r1/runs/r4c96p1"
BASE_HEAD = "ec3020062090c0e4c7a9f3d03c4c304d31008358"
BASE_TREE = "d486132c0c573824a56760eb14ca674ca689bdd9"
FOLLOW_HEAD = "2fbe32839aeaf8a5f7247279da09190a0242d1aa"
FOLLOW_TREE = "64668577eafcc4f7a0c0b6ecbd64ba2a72755dd3"
FOLLOW_PATH = (
    "policy-engine/tests/unit/runtime/http/test_runtime_api_contract_hardening.py"
)
FOLLOW_OLD_SHA = "e20aefc1bd432617c34467f095b6284833bbc33d69afda7769fd2c89b5d3c4d2"
FOLLOW_NEW_SHA = "71358209e73aef26da41db78c7d89eb864643bb4eb96e8cbca22fa4f829caf32"
BASE_AUDIT_SHA = "bcbbe7d4f8dbbcde6f75e48f4e3bc732cd78b5c6a32c52cc5a17468a0caaa12a"
BASE_STRICT_SHA = "5020babb46d8999d6b40979925c02241e96a215ca35f44bd886736fa14dc02b5"
BASE_DB_SHA = "96979f50ccf793e2cc14321c83ef4b01b8a4ba0ccc459db01ac97a3aa70d981f"
REVIEW = RAW / "reviews/R4-c96-r39-actual-r1/README.md"
REVIEW_SHA = "0d66a0c04996ed15730fabe3555cfdcb3371f53633ad50e7a4bf4a19b56f7592"
RECONCILIATION = REVIEW.with_name("reconciliation.json")
RECONCILIATION_SHA = "c949144d10c53f685e75db5dd38b957f08588a6b4cd3a39f5c77562d66005b6a"
BASELINE_RSS_CAP = 2300 * 1024**2
PHASE_RSS_CAP = 3 * 1024**3
ABORT_CASE = RAW / "repairs/R4-control-front-r1/runs/r4c96m1"
ABORT_AUDIT_SHA = "44eda948d10b12f2b1be9d50b4ab1eb2c9d822e15c02aa9e10f66d9ed6554d9a"
ABORT_REVIEW = RAW / "reviews/R4-c96-m1-resource-audit-r1/README.md"
ABORT_REVIEW_SHA = "ac47e973b83128d7bdadd493b0d79472dbe303d9017b7451fe12d6d2bc0d7037"
ABORT_OUTPUT = ABORT_REVIEW.with_name("audit-output.json")
ABORT_OUTPUT_SHA = "eaf3f9c7c51600b90faf011b16a2be09ac0aba564b42b344ba604c3cdcb5513b"
ABORT_SAMPLES_SHA = "7b7e16ecf11878e09ea44f41e67358a887448fb1982a5bb09859cc93a9fb4004"
MUTATION = "POLISYOS_C96_REMOVE_CONTROL_WRITE_CAPACITY"
NEGATIVE_KINDS = {
    "disabled-rollout",
    "denied-permission",
    "wrong-tenant",
    "stale-attempt",
    "body-proof-substitution",
}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def need(ok: object, reason: str) -> None:
    if not ok:
        raise RuntimeError(reason)


def import_retained():
    need(sha(R1_FILE.read_bytes()) == R1_SHA, "retained R1 controller differs")
    spec = importlib.util.spec_from_file_location("r4_r1_retained", R1_FILE)
    need(
        spec is not None and spec.loader is not None, "retained controller unavailable"
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def pid_gone(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return True
    except PermissionError:
        return False
    return False


def strict_supervisor(
    case: Path,
    result: dict,
    plan: dict,
    parent: dict,
    child: dict,
    mode: str,
    *,
    check_current_pids: bool = True,
) -> dict:
    """Recompute the complete supervisor sample set and reject every infrastructure error."""
    required_cap = BASELINE_RSS_CAP if case == BASE_CASE else PHASE_RSS_CAP
    need(
        plan["rss_cap_bytes"] == required_cap,
        "plan RSS cap is not its admitted resource class",
    )
    expected_rc = 1 if mode == "remove" else 0
    expected_status = "command_failed" if mode == "remove" else "passed"
    errors = {}

    def collect_errors(value, path="result"):
        if isinstance(value, dict):
            for key, item in value.items():
                location = path + "." + str(key)
                if "error" in str(key).lower() and item not in (
                    None,
                    "",
                    [],
                    {},
                    False,
                ):
                    errors[location] = item
                else:
                    collect_errors(item, location)
        elif isinstance(value, list):
            for index, item in enumerate(value):
                collect_errors(item, path + "[" + str(index) + "]")

    collect_errors(result)
    need(not errors, "nonempty supervisor error fields: " + repr(errors))
    need(
        result.get("complete") is True
        and result.get("return_code") == expected_rc
        and result.get("status") == expected_status
        and result.get("process_group_gone") is True
        and result.get("aborted_reason") is None
        and result.get("termination_signal") is None,
        "supervisor completion/status/signal mismatch",
    )
    need(
        result["id"] == "c96-queued"
        and result["argv"][:3]
        == ["/usr/bin/sandbox-exec", "-f", str(case / "sandbox.sb")]
        and result["argv"][3:] == plan["argv"],
        "supervisor command differs",
    )
    need(result["cwd"] == plan["cwd"], "supervisor cwd differs")
    need(
        result["pid"] == parent["pid"] and child["ppid"] == parent["pid"],
        "process chain differs",
    )
    if check_current_pids:
        need(
            pid_gone(parent["pid"]) and pid_gone(child["pid"]),
            "observed process still exists",
        )
    lines = (case / "process-tree.jsonl").read_bytes().splitlines()
    samples = [json.loads(line) for line in lines]
    need(
        bool(samples) and len(samples) == result["sample_count"],
        "sample denominator mismatch",
    )
    parent_seen = child_seen = False
    times = []
    for sample in samples:
        need(
            sample["kind"] == "sample" and sample["command_id"] == result["id"],
            "sample identity",
        )
        processes = sample["processes"]
        need(
            all(type(p["rss_kib"]) is int and p["rss_kib"] >= 0 for p in processes),
            "invalid RSS",
        )
        rss = sum(p["rss_kib"] * 1024 for p in processes)
        need(
            rss == sample["sampled_process_tree_rss_bytes"] <= plan["rss_cap_bytes"],
            "sample RSS",
        )
        need(sample["disk_free_bytes"] >= plan["disk_stop_bytes"], "sample disk floor")
        times.append(sample["elapsed_command_seconds"])
        parent_seen |= any(p["pid"] == parent["pid"] for p in processes)
        child_seen |= any(
            p["pid"] == child["pid"] and p["ppid"] == parent["pid"] for p in processes
        )
    need(
        parent_seen and child_seen,
        "actual parent or child absent from sampled process tree",
    )
    need(times == sorted(times) and min(times) >= 0, "sample time order")
    peak = max(s["sampled_process_tree_rss_bytes"] for s in samples)
    minimum = min(
        [result["disk_free_before_bytes"]] + [s["disk_free_bytes"] for s in samples]
    )
    need(
        result["disk_free_before_bytes"] >= plan["disk_admission_bytes"],
        "launch disk floor",
    )
    need(peak == result["max_sampled_process_tree_rss_bytes"], "reported RSS peak")
    need(minimum == result["minimum_sampled_disk_free_bytes"], "reported disk minimum")
    need(0 <= result["wall_seconds"] < plan["deadline_seconds"], "deadline exceeded")
    for filename, finish_key, phase_kind in (
        ("controller-events.jsonl", "kind", "command_finish"),
        ("phase-output.jsonl", "phase", "finish"),
    ):
        records = [
            json.loads(line) for line in (case / filename).read_bytes().splitlines()
        ]
        matching = [
            r
            for r in records
            if r.get(finish_key) == phase_kind and r.get("id") == result["id"]
        ]
        need(len(matching) == 1, "supervisor finish record missing/duplicate")
        end = matching[0]
        need(
            end.get("return_code") == expected_rc
            and end.get("status") == expected_status,
            "supervisor finish record differs",
        )
    return {
        "status": expected_status,
        "return_code": expected_rc,
        "error_fields": errors,
        "sample_count": len(samples),
        "sample_sha256": sha((case / "process-tree.jsonl").read_bytes()),
        "sampled_peak_rss_bytes": peak,
        "minimum_sampled_disk_free_bytes": minimum,
        "parent_pid": parent["pid"],
        "child_pid": child["pid"],
        "wall_seconds": result["wall_seconds"],
        "resource_scope": "sampled process tree; continuous machine maximum not established",
    }


def baseline_outputs(receipt: dict) -> list[dict]:
    """Re-read the exact five deciding output bytes recorded by the real pilot."""
    expected = {
        "c96-queued.stdout.txt",
        "c96-queued.stderr.txt",
        "junit.xml",
        "evidence/parent/parent-process.json",
        "evidence/queued/observation.json",
    }
    rows = receipt["deciding_outputs"]
    paths = []
    for row in rows:
        path = ROOT / row["path"]
        need(path.is_relative_to(BASE_CASE), "baseline output outside case")
        data = path.read_bytes()
        need(
            (len(data), sha(data)) == (row["bytes"], row["sha256"]),
            "baseline output changed",
        )
        paths.append(str(path.relative_to(BASE_CASE)))
    need(
        len(paths) == len(expected) and set(paths) == expected,
        "baseline deciding outputs differ",
    )
    return rows


def baseline_admission(r1):
    """Bind actual positive, strict and independent review; recompute current source evidence."""
    audit_data = (BASE_CASE / "audit-result.json").read_bytes()
    strict_data = (BASE_CASE / "strict-native-verdict.json").read_bytes()
    need(
        sha(audit_data) == BASE_AUDIT_SHA and sha(strict_data) == BASE_STRICT_SHA,
        "baseline receipt bytes",
    )
    need(sha(REVIEW.read_bytes()) == REVIEW_SHA, "independent review bytes")
    need(
        sha(RECONCILIATION.read_bytes()) == RECONCILIATION_SHA,
        "independent reconciliation bytes",
    )
    audit = json.loads(audit_data)
    strict = json.loads(strict_data)
    independent = json.loads(RECONCILIATION.read_bytes())
    plan_data = (BASE_CASE / "plan.json").read_bytes()
    plan = json.loads(plan_data)
    need(sha(plan_data) == audit["plan_sha256"], "baseline plan binding")
    need(
        (audit["source_head"], audit["source_tree"])
        == (plan["source_head"], plan["source_tree"])
        == (strict["source_commit"], strict["source_tree"])
        == (BASE_HEAD, BASE_TREE),
        "baseline source differs",
    )
    need(
        strict["classification"] == independent["result"] == "BOUNDED_PASS"
        and independent["head"] == BASE_HEAD
        and independent["tree"] == BASE_TREE
        and independent["sqlite"]["sha256"] == BASE_DB_SHA,
        "baseline independently unqualified",
    )
    need(
        strict["controller_receipt_sha256"] == BASE_AUDIT_SHA
        and strict["closure_ids"] == [],
        "baseline strict binding",
    )
    baseline_outputs(audit)
    parent = json.loads(
        (BASE_CASE / "evidence/parent/parent-process.json").read_bytes()
    )
    child = json.loads((BASE_CASE / "evidence/queued/observation.json").read_bytes())
    prior_qualification = r1.qualify_case(
        BASE_CASE, BASE_HEAD, BASE_TREE, audit["supervisor"], plan["argv"]
    )
    need(
        prior_qualification["outcome"] == "PASS",
        "baseline actual source/property qualification",
    )
    strict_now = strict_supervisor(
        BASE_CASE,
        audit["supervisor"],
        plan,
        parent,
        child,
        "restore",
        check_current_pids=False,
    )
    need(
        strict_now["sample_count"] == strict["sample_count"]
        and strict_now["sampled_peak_rss_bytes"] == strict["sampled_peak_rss_bytes"]
        and strict_now["minimum_sampled_disk_free_bytes"]
        == strict["minimum_sampled_disk_free_bytes"],
        "baseline strict sample mismatch",
    )
    workorder = json.loads(r1.WORKORDER.read_bytes())
    need(
        r1.source_pins(BASE_HEAD, workorder) == plan["selected_source_pins"],
        "baseline source pins",
    )
    need(
        sha((BASE_CASE / "sandbox.sb").read_bytes()) == plan["sandbox_sha256"],
        "baseline sandbox",
    )
    db = baseline_db_path(BASE_CASE)
    need(sha(db.read_bytes()) == BASE_DB_SHA, "independent baseline database bytes")
    common_observation(child)
    guard_property(child, "restore")
    need(
        sqlite_witness(BASE_CASE, child, "restore")["sha256"] == BASE_DB_SHA,
        "independent baseline SQLite witness",
    )
    binding_paths = [
        BASE_CASE / "audit-result.json",
        BASE_CASE / "strict-native-verdict.json",
        BASE_CASE / "plan.json",
        BASE_CASE / "sandbox.sb",
        BASE_CASE / "process-tree.jsonl",
        BASE_CASE / "controller-events.jsonl",
        BASE_CASE / "phase-output.jsonl",
        BASE_CASE / "evidence/parent/parent-readset.json.gz",
        BASE_CASE / "evidence/queued/child-readset.json.gz",
        db,
        REVIEW,
        RECONCILIATION,
    ] + [ROOT / row["path"] for row in audit["deciding_outputs"]]
    bindings = {
        str(path.relative_to(ROOT)): sha(path.read_bytes()) for path in binding_paths
    }
    need(len(bindings) == len(binding_paths), "duplicate baseline binding")
    return plan, strict_now, bindings


def admit_source_delta(r1, head: str, tree: str, baseline: dict) -> dict:
    """Admit only the baseline or the single explicitly reconciled test-only delta."""
    if (head, tree) == (BASE_HEAD, BASE_TREE):
        return {
            "kind": "identical_commit_tree",
            "base_head": BASE_HEAD,
            "current_head": head,
            "changed_paths": [],
            "unobserved_native_and_dynamic_reads": "NOT_ESTABLISHED",
        }
    need(
        (head, tree) == (FOLLOW_HEAD, FOLLOW_TREE),
        "unreviewed current source; new rebind required",
    )
    r1.git("merge-base", "--is-ancestor", BASE_HEAD, head)
    changed = r1.git(
        "diff", "--name-status", "-z", "--no-renames", BASE_HEAD, head, "--"
    )
    fields = changed.split(b"\0")
    need(fields == [b"M", FOLLOW_PATH.encode(), b""], "complete source delta differs")
    old = r1.git("show", BASE_HEAD + ":" + FOLLOW_PATH)
    new = r1.git("show", head + ":" + FOLLOW_PATH)
    need(
        sha(old) == FOLLOW_OLD_SHA
        and sha(new) == FOLLOW_NEW_SHA
        and (ROOT / FOLLOW_PATH).read_bytes() == new,
        "changed file bytes differ",
    )
    index = r1.git("ls-files", "--stage", "--", FOLLOW_PATH).decode().split()
    need(
        len(index) >= 3 and index[1] == r1.blob(new) and index[2] == "0",
        "changed file index",
    )
    old_ast, new_ast = ast.parse(old), ast.parse(new)
    need(len(old_ast.body) == len(new_ast.body), "module-level structure changed")
    differences = []
    for a, b in zip(old_ast.body, new_ast.body, strict=True):
        if ast.dump(a, include_attributes=False) != ast.dump(
            b, include_attributes=False
        ):
            need(
                isinstance(a, ast.FunctionDef)
                and isinstance(b, ast.FunctionDef)
                and a.name == b.name,
                "delta beyond one existing test function",
            )
            differences.append(a.name)
    need(
        differences
        == ["test_runtime_contract_gate_rejects_nested_epoch_semantic_corruption"],
        "changed test body differs",
    )
    source_pins = {row["path"] for row in baseline["selected_source_pins"]}
    need(
        len(source_pins) == baseline["selected_pin_denominator"] == 19,
        "selected pin denominator",
    )
    baseline_inputs = set(baseline["inputs"])
    intersections = {}
    for role, rel in (
        ("parent", "evidence/parent/parent-readset.json.gz"),
        ("child", "evidence/queued/child-readset.json.gz"),
    ):
        compressed = (BASE_CASE / rel).read_bytes()
        obsfile = (
            "evidence/parent/parent-process.json"
            if role == "parent"
            else "evidence/queued/observation.json"
        )
        observation = json.loads((BASE_CASE / obsfile).read_bytes())
        need(
            sha(compressed) == observation["readset"]["sha256"],
            "baseline readset identity",
        )
        rows = json.loads(gzip.decompress(compressed))["files"]
        paths = {"policy-engine/" + row["path"] for row in rows}
        need(
            len(paths) == len(rows) == observation["readset"]["python_paths"],
            "readset denominator",
        )
        need(FOLLOW_PATH not in paths, "changed file was loaded by baseline process")
        intersections[role] = {
            "file_type": ".py",
            "denominator": len(paths),
            "changed_intersection": [],
        }
    need(
        FOLLOW_PATH not in source_pins and FOLLOW_PATH not in baseline_inputs,
        "changed pinned input",
    )
    need(
        r1.source_pins(head, json.loads(r1.WORKORDER.read_bytes()))
        == baseline["selected_source_pins"],
        "current selected inputs differ from baseline",
    )
    return {
        "kind": "single_unloaded_other_test_body",
        "base_head": BASE_HEAD,
        "current_head": head,
        "current_tree": tree,
        "changed_paths": [
            {
                "status": "M",
                "path": FOLLOW_PATH,
                "old_sha256": sha(old),
                "new_sha256": sha(new),
                "changed_top_level_test_functions": differences,
            }
        ],
        "selected_pin_denominator": len(source_pins),
        "selected_pin_intersection": [],
        "named_input_denominator": len(baseline_inputs),
        "named_input_intersection": [],
        "baseline_finite_loaded_python_readsets": intersections,
        "scope": "complete Git path delta and listed pins/readsets only",
        "unobserved_native_and_dynamic_reads": "NOT_ESTABLISHED",
    }


def resource_profile() -> dict:
    """Explicitly distinguish historical baseline from both new phase limits."""
    return {
        "baseline_rss_cap_bytes": BASELINE_RSS_CAP,
        "phase_rss_cap_bytes": PHASE_RSS_CAP,
        "m1_abort_audit_sha256": ABORT_AUDIT_SHA,
        "m1_independent_review_sha256": ABORT_REVIEW_SHA,
        "comparison": "RSS limit changed; source identity and removal environment have separately recorded deltas; remaining compared fields match",
    }


def resource_history_admission() -> tuple[dict, dict[str, str]]:
    """Verify retained m1 resource abort; infer neither OOM nor semantic red."""
    audit_path = ABORT_CASE / "r2-audit-result.json"
    plan_path = ABORT_CASE / "r2-plan.json"
    sample_path = ABORT_CASE / "process-tree.jsonl"
    need(sha(audit_path.read_bytes()) == ABORT_AUDIT_SHA, "m1 audit bytes")
    need(sha(ABORT_REVIEW.read_bytes()) == ABORT_REVIEW_SHA, "m1 review bytes")
    need(
        sha(ABORT_OUTPUT.read_bytes()) == ABORT_OUTPUT_SHA,
        "m1 independent audit output",
    )
    need(sha(sample_path.read_bytes()) == ABORT_SAMPLES_SHA, "m1 sample bytes")
    audit = json.loads(audit_path.read_bytes())
    plan = json.loads(plan_path.read_bytes())
    independent = json.loads(ABORT_OUTPUT.read_bytes())
    result = audit["supervisor"]
    need(sha(plan_path.read_bytes()) == audit["plan_sha256"], "m1 plan bytes")
    need(
        (audit["source_head"], audit["source_tree"]) == (FOLLOW_HEAD, FOLLOW_TREE)
        and plan["rss_cap_bytes"] == BASELINE_RSS_CAP
        and audit["qualification"]["outcome"] == "ERROR"
        and independent["classification"] == "RESOURCE_ABORT_ERROR_NO_SEMANTIC_RESULT",
        "m1 resource classification or source",
    )
    need(
        result["status"] == "resource_limit_abort"
        and result["aborted_reason"] == "sampled_process_tree_rss_cap"
        and result["return_code"] == -15
        and result["process_group_gone"] is True,
        "m1 supervisor abort",
    )
    samples = [json.loads(line) for line in sample_path.read_bytes().splitlines()]
    need(len(samples) == result["sample_count"] == 32, "m1 sample denominator")
    for sample in samples:
        need(
            sample["sampled_process_tree_rss_bytes"]
            == sum(process["rss_kib"] * 1024 for process in sample["processes"]),
            "m1 sampled RSS sum",
        )
    peak = max(sample["sampled_process_tree_rss_bytes"] for sample in samples)
    minimum = min(
        [result["disk_free_before_bytes"]]
        + [sample["disk_free_bytes"] for sample in samples]
    )
    need(
        peak == result["max_sampled_process_tree_rss_bytes"] == 2412118016
        and peak - BASELINE_RSS_CAP == 393216
        and minimum == result["minimum_sampled_disk_free_bytes"] == 9045938176,
        "m1 sampled resource values",
    )
    need(
        all(
            sample["sampled_process_tree_rss_bytes"] <= BASELINE_RSS_CAP
            for sample in samples[:-1]
        )
        and samples[-1]["sampled_process_tree_rss_bytes"] > BASELINE_RSS_CAP,
        "m1 crossing differs",
    )
    need(
        not (ABORT_CASE / "junit.xml").exists()
        and not (ABORT_CASE / "evidence/queued/observation.json").exists()
        and (ABORT_CASE / "c96-queued.stdout.txt").read_bytes() == b""
        and (ABORT_CASE / "c96-queued.stderr.txt").read_bytes() == b"",
        "m1 deciding-output boundary differs",
    )
    parent_path = ABORT_CASE / "evidence/parent/parent-process.json"
    parent = json.loads(parent_path.read_bytes())
    need(
        parent["stage"] == "before_pytest_import"
        and sha(parent_path.read_bytes()) == independent["evidence"]["parent_sha256"],
        "m1 parent observation differs",
    )
    files = [
        audit_path,
        plan_path,
        sample_path,
        ABORT_REVIEW,
        ABORT_OUTPUT,
        parent_path,
        ABORT_CASE / "c96-queued.stdout.txt",
        ABORT_CASE / "c96-queued.stderr.txt",
    ]
    bindings = {str(path.relative_to(ROOT)): sha(path.read_bytes()) for path in files}
    need(len(bindings) == len(files), "duplicate resource history input")
    return {
        "classification": "RESOURCE_ABORT_ERROR_NO_SEMANTIC_RESULT",
        "sample_count": len(samples),
        "sampled_peak_rss_bytes": peak,
        "over_baseline_cap_bytes": peak - BASELINE_RSS_CAP,
        "minimum_sampled_disk_free_bytes": minimum,
        "observed_return_code": result["return_code"],
        "termination_signal_field": result.get("termination_signal"),
        "termination_signal_caveat": "null does not establish no signal on abort",
        "uncapped_peak_and_oom": "NOT_ESTABLISHED",
    }, bindings


def baseline_db_path(case: Path) -> Path:
    candidates = list(
        case.glob(
            "pytest-tmp/test_authenticated_cancellatio*/case/runtime-env/.polisyos/control_plane.sqlite3"
        )
    )
    matches = []
    for path in candidates:
        current = case
        safe = True
        for part in path.relative_to(case).parts:
            current = current / part
            if current.is_symlink():
                safe = False
                break
        if safe and path.is_file():
            matches.append(path)
    need(len(matches) == 1, "unique non-symlink fixture DB missing")
    return matches[0]


def guard_property(child: dict, mode: str) -> None:
    guard = child["guard_identity"]
    need(guard["same_breaker_and_policy"] is True, "guard policy differs")
    need(
        guard["control_executor_id"] != guard["compute_executor_id"],
        "baseline control guard shares compute",
    )
    if mode == "remove":
        need(
            guard["removal_executor_id"] == guard["compute_executor_id"],
            "removal does not use held compute",
        )
    else:
        need(
            guard["removal_executor_id"] is None,
            "unexpected removal guard in positive process",
        )


def common_observation(child: dict) -> None:
    q = child["queue"]
    need(
        q["accepted_pending"] is True
        and q["running_physical"] is True
        and q["queued_body_calls"] == 0
        and q["physical_workers"] == 1
        and q["queued_jobs"] == 1
        and q["outstanding_jobs"] == 2
        and q["overflow_code"] == "shared_executor_queue_full"
        and q["cancelled_queued"] is False,
        "actual queue was not held",
    )
    need(child["catalog"]["real_reader_identity_matches"] is True, "catalog fixture")
    renewal = child["renewal"]
    need(
        renewal["after"] > renewal["before"]
        and renewal["calls_under_held_compute"] > 0,
        "heartbeat absent",
    )
    negatives = child["adversarial"]
    need(
        len(negatives) == len(NEGATIVE_KINDS)
        and {x["kind"] for x in negatives} == NEGATIVE_KINDS
        and all(
            x["status"] >= 400 and x["zero_protected_effects"] is True
            for x in negatives
        ),
        "negative controls incomplete",
    )
    need(
        child["held_until_readback"] is True and not child["thread_errors"],
        "held/threads",
    )
    after = child["queue_after_release"]
    need(
        after["queued_body_calls"] == 1
        and after["queued_jobs"] == after["outstanding_jobs"] == 0,
        "queue did not release",
    )
    trace = child["trace"]
    times = [e["monotonic_ns"] for e in trace]
    need(times == sorted(times), "event timestamps out of order")

    def events(name):
        return [e for e in trace if e["event"] == name]

    full = events("actual_queue_full")
    entered = events("compute_body_entered")
    returned = events("compute_body_returned")
    positive = [
        e
        for e in events("actual_cancel_entry")
        if e.get("operation_id") == "c96-cancel-positive"
    ]
    need(
        len(full) == len(entered) == len(returned) == 1 and bool(positive),
        "observed trace missing",
    )
    need(
        all(
            x["current_authority"] is True and x["tampered"] is False for x in positive
        ),
        "authority",
    )
    need(
        entered[0]["monotonic_ns"]
        < full[0]["monotonic_ns"]
        < positive[0]["monotonic_ns"]
        < returned[0]["monotonic_ns"],
        "saturation ordering",
    )
    renewals = [
        e
        for e in events("actual_renewal")
        if e.get("result") is True
        and full[0]["monotonic_ns"] < e["monotonic_ns"] < positive[0]["monotonic_ns"]
    ]
    need(
        len(renewals) >= renewal["calls_under_held_compute"] > 0,
        "recorded heartbeat order",
    )
    need(
        child["positive_current_authority_calls"] > 0
        and child["positive_control_entry_calls"] > 0,
        "actual current authority/control entry missing",
    )


def sqlite_witness(case: Path, child: dict, mode: str) -> dict:
    """Read the final fixture DB without changing it; intermediate state stays observer-supplied."""
    path = baseline_db_path(case)
    before = sha(path.read_bytes())
    need(
        sorted(p.name for p in path.parent.glob(path.name + "*")) == [path.name],
        "SQLite sidecar exists",
    )
    db = sqlite3.connect(path.resolve().as_uri() + "?mode=ro&immutable=1", uri=True)
    try:
        db.row_factory = sqlite3.Row
        need(
            db.execute("pragma quick_check").fetchone()[0] == "ok", "SQLite quick_check"
        )
        job_id = "job_execution_admission"
        jobs = [
            dict(x)
            for x in db.execute("select * from control_jobs where job_id=?", (job_id,))
        ]
        events = [
            dict(x)
            for x in db.execute(
                "select * from control_job_events where job_id=?", (job_id,)
            )
        ]
        outbox = [
            dict(x)
            for x in db.execute(
                "select * from control_outbox_events where job_id=?", (job_id,)
            )
        ]
        progress = [
            dict(x)
            for x in db.execute(
                "select * from control_job_progress where job_id=?", (job_id,)
            )
        ]
        need(len(jobs) == len(progress) == 1, "fixture job/progress set")
        job = jobs[0]
        need(
            job["attempt"] == child["running"]["attempt"]
            and job["capability_manifest_ref"] == child["running"]["manifest_ref"],
            "DB attempt/manifest",
        )
        cancels = [x for x in events if x["event_type"] == "job_cancelled"]
        cancel_out = [x for x in outbox if x["topic"] == "control.job.cancelled"]
        terminal = [
            x for x in events if x["event_type"] in {"job_completed", "job_failed"}
        ]
        if mode == "remove":
            need(not cancels and not cancel_out, "removal committed cancellation")
        else:
            need(
                job["state"] == "cancelled"
                and job["lease_owner"] is None
                and len(cancels) == len(cancel_out) == 1
                and not terminal,
                "restored durable cancellation",
            )
        return {
            "path": str(path.relative_to(ROOT)),
            "sha256": before,
            "quick_check": "ok",
            "job_state_after_release": job["state"],
            "cancel_events": len(cancels),
            "cancel_outbox": len(cancel_out),
            "other_terminal_events": len(terminal),
            "scope": "final DB only; state at held instant is child observer",
        }
    finally:
        db.close()
        need(sha(path.read_bytes()) == before, "fixture DB changed during read")


def normalized(value: object, case: Path):
    if isinstance(value, str):
        return value.replace(str(case), "<CASE>")
    if isinstance(value, list):
        return [normalized(x, case) for x in value]
    if isinstance(value, dict):
        return {k: normalized(v, case) for k, v in value.items()}
    return value


def compare_profile(plan: dict, case: Path, baseline: dict, mode: str) -> None:
    """Only case-owned paths and the one declared mutation may vary."""
    keys = (
        "argv",
        "cwd",
        "numeric_threads",
        "inherited_control_names_only",
        "cleared_control_names",
        "inherited_git_control_names_only",
        "sandbox_fragment_sha256",
        "disk_admission_bytes",
        "disk_stop_bytes",
        "deadline_seconds",
        "selected_source_pins",
        "selected_pin_denominator",
        "branch",
    )
    for key in keys:
        need(
            normalized(plan[key], case) == normalized(baseline[key], BASE_CASE),
            "profile mismatch: " + key,
        )
    need(
        baseline["rss_cap_bytes"] == BASELINE_RSS_CAP
        and plan["rss_cap_bytes"] == PHASE_RSS_CAP
        and plan["resource_profile"] == resource_profile(),
        "baseline/phase RSS resource class mismatch",
    )
    env = dict(plan["extra_env"])
    if mode == "remove":
        need(env.pop(MUTATION, None) == "1", "removal env is absent")
    else:
        need(MUTATION not in env, "restoration mutation still present")
    baseline_env = dict(baseline["extra_env"])
    for key, phase_value, prior_value in (
        ("POLISYOS_C96_EXPECTED_HEAD", plan["source_head"], BASE_HEAD),
        ("POLISYOS_C96_EXPECTED_TREE", plan["source_tree"], BASE_TREE),
    ):
        need(
            env.get(key) == phase_value and baseline_env.get(key) == prior_value,
            "source environment binding",
        )
        env[key] = baseline_env[key] = "<SOURCE>"
    need(
        normalized(env, case) == normalized(baseline_env, BASE_CASE),
        "environment profile differs",
    )
    need(
        normalized((case / "sandbox.sb").read_text(), case)
        == normalized((BASE_CASE / "sandbox.sb").read_text(), BASE_CASE),
        "sandbox differs",
    )


def removal_observation(child: dict) -> None:
    """Require the actual held durable-state contrast after current-authority entry."""
    durable, run, fresh = child["persisted"], child["running"], child["fresh_http"]
    need(
        child["positive_control_body_calls"] == 0,
        "removal body unexpectedly executed",
    )
    need(
        child["post"]["status"] == 503
        and child["post"]["code"] == "control_plane_store_unavailable",
        "guard refusal not reached",
    )
    need(
        durable["state"] == "running"
        and durable["verified"] is False
        and durable["attempt"] == run["attempt"]
        and durable["lease_owner"] == run["owner"]
        and durable["manifest_ref"] == run["manifest_ref"]
        and durable["cancellation_event_count"]
        == durable["cancellation_outbox_count"]
        == 0
        and durable["other_terminal_count"] == 0
        and durable["progress_preserved"] is True,
        "actual held durable state differs",
    )
    need(
        fresh["status"] == 200
        and fresh["state"] == fresh["execution_status"] == "running",
        "fresh reader state",
    )
    need(
        child["retry"]["status"] is None and child["late_refused"] == {},
        "unexpected post-cancel path",
    )


def qualify_phase(
    r1,
    case: Path,
    plan: dict,
    result: dict,
    mode: str,
    *,
    check_current_pids: bool = True,
) -> dict:
    parent_dir = case / "evidence/parent"
    child_dir = case / "evidence/queued"
    parent = json.loads((parent_dir / "parent-process.json").read_bytes())
    child = json.loads((child_dir / "observation.json").read_bytes())
    strict = strict_supervisor(
        case, result, plan, parent, child, mode, check_current_pids=check_current_pids
    )
    if mode == "restore":
        source = r1.qualify_case(
            case, plan["source_head"], plan["source_tree"], result, plan["argv"]
        )
        need(
            source["outcome"] == "PASS",
            "restored parent/child/source/property qualification",
        )
    else:
        need(
            parent["stage"] == "pytest_finished" and child["stage"] == "complete",
            "fixture not complete",
        )
        need(
            parent["source"]
            == parent["source_after"]
            == child["source"]
            == [plan["source_head"], plan["source_tree"]],
            "source",
        )
        need(
            parent["pid"] == parent["pytest"]["pid"] and child["ppid"] == parent["pid"],
            "process identity",
        )
        need(
            parent["argv"] == plan["argv"][2:]
            and parent["collected_node_ids_after_deselection"] == [r1.NODE],
            "pytest command/collection",
        )
        need(
            parent["pytest_not_yet_imported"] is True
            and parent["initial_private_pycache_empty"] is True
            and parent["sys_pycache_prefix"] == str(case / "pycache"),
            "startup/pycache",
        )
        need(
            parent["pytest"]["importmode"] == "importlib"
            and "--strict-markers" in parent["pytest"]["ini_addopts"]
            and Path(parent["pytest"]["inipath"]).resolve()
            == (r1.PRODUCT / "pytest.ini").resolve(),
            "pytest profile",
        )
        for observation in (parent, child):
            env = observation["environment"]
            need(
                env["PYTHONDONTWRITEBYTECODE"] == "1"
                and env["PYTHONPYCACHEPREFIX"] == str(case / "pycache")
                and env["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] is None
                and not env["PYTEST_ADDOPTS"]
                and all(
                    env[k] == "1"
                    for k in (
                        "OMP_NUM_THREADS",
                        "OPENBLAS_NUM_THREADS",
                        "MKL_NUM_THREADS",
                        "NUMEXPR_NUM_THREADS",
                    )
                ),
                "process environment",
            )
            need(
                Path(observation["executable"]).resolve() == r1.PYTHON.resolve(),
                "interpreter",
            )
        need(parent["pytest_exitstatus"] == result["return_code"] == 1, "pytest exit")
        index = r1.selected_git_tree(plan["source_head"])
        source = {
            "parent_readset": r1.qualify_readset(
                parent, parent_dir, index, r1.PARENT_REQUIRED
            ),
            "child_readset": r1.qualify_readset(
                child, child_dir, index, r1.CHILD_REQUIRED
            ),
        }
        cases = list(ET.parse(case / "junit.xml").getroot().iter("testcase"))
        need(
            len(cases) == 1 and cases[0].get("name") == r1.NODE.split("::")[-1],
            "JUnit selected node",
        )
        failure = cases[0].find("failure")
        need(
            failure is not None
            and cases[0].find("error") is None
            and cases[0].find("skipped") is None,
            "JUnit not single failure",
        )
        failure_text = "".join(failure.itertext())
        need(
            "_assert_persisted_cancellation(observed)" in failure_text
            and 'assert durable["state"] == "cancelled"' in failure_text,
            "not actual durable-state assertion",
        )
    need(
        child["case"]["cancel_queued"] is False
        and child["case"]["remove_write_capacity"] is (mode == "remove"),
        "wrong case variant",
    )
    common_observation(child)
    guard_property(child, mode)
    if mode == "remove":
        removal_observation(child)
    else:
        need(not r1.property_checks(child), "restored positive property")
    db = sqlite_witness(case, child, mode)
    return {
        "outcome": "EXPECTED_SEMANTIC_RED" if mode == "remove" else "PASS",
        "source": source,
        "strict_supervisor": strict,
        "final_sqlite": db,
        "parent_observation_sha256": sha(
            (parent_dir / "parent-process.json").read_bytes()
        ),
        "child_observation_sha256": sha((child_dir / "observation.json").read_bytes()),
        "guard_scope": "observed guard selection per fresh process; in-process cleanup identity not established",
        "intermediate_scope": "child fixture observation; final SQLite independently read",
    }


def deciding_outputs(case: Path) -> list[dict]:
    names = (
        "c96-queued.stdout.txt",
        "c96-queued.stderr.txt",
        "junit.xml",
        "evidence/parent/parent-process.json",
        "evidence/queued/observation.json",
    )
    rows = []
    for name in names:
        path = case / name
        need(
            path.is_file() and not path.is_symlink(), "deciding output missing: " + name
        )
        data = path.read_bytes()
        rows.append(
            {
                "path": str(path.relative_to(ROOT)),
                "bytes": len(data),
                "sha256": sha(data),
            }
        )
    return rows


def predecessor_admission(
    r1,
    name: str,
    expected_sha: str,
    baseline: dict,
    head: str = BASE_HEAD,
    tree: str = BASE_TREE,
) -> tuple[dict, dict[str, str]]:
    """Recompute the actual removal rather than trusting its self-reported receipt."""
    need(
        name != "r4c96p1"
        and len(name) <= 16
        and all(c.isalnum() or c in "-_" for c in name),
        "invalid removal case ID",
    )
    case = r1.FRONT / "runs" / name
    r1.no_symlink_ancestors(case)
    receipt_data = (case / "r3-audit-result.json").read_bytes()
    need(sha(receipt_data) == expected_sha, "removal receipt SHA differs")
    receipt = json.loads(receipt_data)
    need(
        receipt["schema"] == "e02-r4-c96-matched-phase-receipt-v2"
        and receipt["mode"] == "remove"
        and receipt["source_head"] == head
        and receipt["source_tree"] == tree
        and receipt["baseline_audit_sha256"] == BASE_AUDIT_SHA
        and receipt["baseline_strict_sha256"] == BASE_STRICT_SHA
        and receipt["qualification"]["outcome"] == "EXPECTED_SEMANTIC_RED"
        and receipt["closure_ids"] == [],
        "removal receipt not qualified",
    )
    plan_data = (case / "r3-plan.json").read_bytes()
    need(sha(plan_data) == receipt["plan_sha256"], "removal plan SHA differs")
    plan = json.loads(plan_data)
    need(
        plan["mode"] == "remove"
        and plan["source_head"] == head
        and plan["source_tree"] == tree
        and plan["controller_sha256"] == sha(Path(__file__).read_bytes()),
        "removal plan differs",
    )
    current_delta = admit_source_delta(r1, head, tree, baseline)
    need(
        plan["source_delta"] == receipt["source_delta"] == current_delta,
        "removal source delta differs",
    )
    compare_profile(plan, case, baseline, "remove")
    need(
        receipt["resource_profile"] == plan["resource_profile"] == resource_profile(),
        "predecessor resource class differs",
    )
    need(
        deciding_outputs(case) == receipt["deciding_outputs"],
        "removal deciding outputs differ",
    )
    need(
        sha((case / "sandbox.sb").read_bytes()) == plan["sandbox_sha256"],
        "removal sandbox changed",
    )
    qualified = qualify_phase(
        r1, case, plan, receipt["supervisor"], "remove", check_current_pids=False
    )
    need(qualified == receipt["qualification"], "actual removal qualification differs")
    files = [
        case / "r3-audit-result.json",
        case / "r3-plan.json",
        case / "sandbox.sb",
        case / "process-tree.jsonl",
        case / "controller-events.jsonl",
        case / "phase-output.jsonl",
        case / "evidence/parent/parent-readset.json.gz",
        case / "evidence/queued/child-readset.json.gz",
        baseline_db_path(case),
    ] + [ROOT / row["path"] for row in receipt["deciding_outputs"]]
    bindings = {str(path.relative_to(ROOT)): sha(path.read_bytes()) for path in files}
    need(len(bindings) == len(files), "duplicate predecessor binding")
    return receipt, bindings


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("remove", "restore"), required=True)
    parser.add_argument("--case-id", required=True)
    parser.add_argument("--expected-head", required=True)
    parser.add_argument("--expected-tree", required=True)
    parser.add_argument("--controller-sha256", required=True)
    parser.add_argument("--removal-case")
    parser.add_argument("--removal-receipt-sha256")
    args = parser.parse_args()
    need(
        sys.version_info[:2] == (3, 14)
        and sys.flags.isolated == 1
        and sys.dont_write_bytecode,
        "use existing venv Python 3.14 with -I -B",
    )
    r1 = import_retained()
    need(Path(sys.prefix).resolve() == (r1.PRODUCT / ".venv").resolve(), "wrong venv")
    own_sha = sha(Path(__file__).read_bytes())
    need(own_sha == args.controller_sha256, "R3 controller SHA mismatch")
    need(
        (args.expected_head, args.expected_tree)
        in {(BASE_HEAD, BASE_TREE), (FOLLOW_HEAD, FOLLOW_TREE)},
        "new source requires independently commissioned rebind",
    )
    git_controls = sorted(k for k in os.environ if k.startswith("GIT_"))
    need(
        not [k for k in git_controls if k not in {"GIT_PAGER", "GIT_TERMINAL_PROMPT"}],
        "unsupported inherited Git controls",
    )
    need(
        r1.git("symbolic-ref", "--short", "HEAD").decode().strip() == r1.BRANCH,
        "branch mismatch",
    )
    actual = r1.git("rev-parse", "HEAD", "HEAD^{tree}").decode().splitlines()
    need(
        actual == [args.expected_head, args.expected_tree],
        "actual source differs; do not switch",
    )
    need(
        not r1.git("status", "--porcelain", "--untracked-files=no"),
        "tracked source/index dirty",
    )
    live = json.loads(r1.LIVE.read_bytes())
    need(
        live["known_dirty_paths"] == [] and live["tree"] == args.expected_tree,
        "root source lease dirty",
    )
    need(
        sha(r1.WORKORDER.read_bytes()) == r1.WORKORDER_SHA
        and sha(r1.GUARD.read_bytes()) == r1.GUARD_SHA
        and sha(r1.SUPERVISOR.read_bytes()) == r1.SUPERVISOR_SHA,
        "retained input differs",
    )
    need(
        sha((r1.FRONT / "README.md").read_bytes())
        == "611bb3284df636822289ddfe4cc495b237affa50d92546012bc95e64a985e142",
        "workorder README",
    )
    guard = runpy.run_path(str(r1.GUARD))["guard"]
    before = guard()
    need(before["head"] == args.expected_head, "root source identity")
    baseline, baseline_strict, baseline_bindings = baseline_admission(r1)
    resource_history, resource_bindings = resource_history_admission()
    source_delta = admit_source_delta(
        r1, args.expected_head, args.expected_tree, baseline
    )
    predecessor = None
    predecessor_bindings = {}
    if args.mode == "restore":
        need(
            args.removal_case is not None and args.removal_receipt_sha256 is not None,
            "restoration requires actual removal case and exact receipt SHA",
        )
        predecessor, predecessor_bindings = predecessor_admission(
            r1,
            args.removal_case,
            args.removal_receipt_sha256,
            baseline,
            args.expected_head,
            args.expected_tree,
        )
    else:
        need(
            args.removal_case is None and args.removal_receipt_sha256 is None,
            "removal cannot take a restoration predecessor",
        )
    workorder = json.loads(r1.WORKORDER.read_bytes())
    pins = r1.source_pins(args.expected_head, workorder)
    reference = json.loads(r1.REFERENCE_PLAN.read_bytes())
    fragment = reference["sandbox_profile_fragment"]
    need(sha(fragment.encode()) == r1.FRAGMENT_SHA, "sandbox fragment differs")
    need(shutil.disk_usage(ROOT).free >= r1.DISK_START, "8 GiB admission")
    need(MUTATION not in os.environ, "ambient mutation is forbidden")
    inherited = sorted(
        k
        for k in os.environ
        if k.startswith(("PYTHON", "PYTEST", "POLISYOS_C96_")) or k == "VIRTUAL_ENV"
    )
    unknown_pytest = [
        k for k in inherited if k.startswith("PYTEST_") and k not in r1.CLEARED
    ]
    allowed_python = set(r1.CLEARED) | {
        "PYTHONPYCACHEPREFIX",
        "PYTHONDONTWRITEBYTECODE",
        "PYTHONUNBUFFERED",
    }
    unknown_python = [
        k for k in inherited if k.startswith("PYTHON") and k not in allowed_python
    ]
    allowed_c96 = {
        "POLISYOS_C96_EVIDENCE_DIR",
        "POLISYOS_C96_EXPECTED_HEAD",
        "POLISYOS_C96_EXPECTED_TREE",
    }
    unknown_c96 = [
        k for k in inherited if k.startswith("POLISYOS_C96_") and k not in allowed_c96
    ]
    need(
        not unknown_pytest and not unknown_python and not unknown_c96,
        "unsupported inherited controls",
    )
    cleared = [k for k in r1.CLEARED if k in os.environ]
    for key in r1.CLEARED:
        os.environ.pop(key, None)
    case = r1.reserve_case(r1.FRONT, args.case_id)
    for name in ("pycache", "tmp", "benchmarks", "evidence"):
        (case / name).mkdir(mode=0o700)
    need(not any((case / "pycache").iterdir()), "pycache not empty")
    profile = (
        "(version 1)\n(allow default)\n(deny file-write*)\n(allow file-write* (subpath "
        + json.dumps(str(case))
        + '))\n(allow file-write* (literal "/dev/null"))\n'
        + fragment
    )
    sandbox = case / "sandbox.sb"
    with sandbox.open("x") as stream:
        stream.write(profile)
    env = {
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONPYCACHEPREFIX": str(case / "pycache"),
        "TMPDIR": str(case / "tmp"),
        "XDG_CACHE_HOME": str(case / "tmp/xdg"),
        "MPLCONFIGDIR": str(case / "tmp/mpl"),
        "NUMBA_CACHE_DIR": str(case / "tmp/numba"),
        "HYPOTHESIS_STORAGE_DIRECTORY": str(case / "tmp/hypothesis"),
        "POLISYOS_C96_EVIDENCE_DIR": str(case / "evidence"),
        "POLISYOS_C96_EXPECTED_HEAD": args.expected_head,
        "POLISYOS_C96_EXPECTED_TREE": args.expected_tree,
        "SCIENTIST_TORCH_NUM_THREADS": "1",
        "SCIENTIST_TORCH_NUM_INTEROP_THREADS": "1",
    }
    if args.mode == "remove":
        env[MUTATION] = "1"
    argv = [
        str(r1.PYTHON),
        "-B",
        str(r1.HARNESS),
        "--observe-pytest",
        "-q",
        "-ra",
        "-o",
        "cache_dir=" + str(case / "pytest-cache"),
        "--benchmark-storage=file://" + str(case / "benchmarks"),
        "--basetemp",
        str(case / "pytest-tmp"),
        "--junitxml",
        str(case / "junit.xml"),
        r1.NODE,
    ]
    monitor_spec = importlib.util.spec_from_file_location(
        "r4_retained_supervisor_r2", r1.SUPERVISOR
    )
    need(
        monitor_spec is not None and monitor_spec.loader is not None,
        "supervisor unavailable",
    )
    monitor = importlib.util.module_from_spec(monitor_spec)
    sys.modules[monitor_spec.name] = monitor
    monitor_spec.loader.exec_module(monitor)
    monitor.RSS_CAP_BYTES, monitor.DISK_FLOOR_BYTES, monitor.SAMPLE_SECONDS = (
        PHASE_RSS_CAP,
        r1.DISK_STOP,
        1.0,
    )
    signal.signal(signal.SIGTERM, monitor.note_stop_signal)
    signal.signal(signal.SIGINT, monitor.note_stop_signal)
    frame = ROOT / live["source_readback"]["path"]
    inputs = [
        r1.WORKORDER,
        r1.FRONT / "README.md",
        r1.REFERENCE_PLAN,
        r1.GUARD,
        r1.SUPERVISOR,
        r1.LIVE,
        frame,
        R1_FILE,
        Path(__file__),
    ]
    input_hashes = {
        str(path.relative_to(ROOT)): sha(path.read_bytes()) for path in inputs
    }
    need(len(input_hashes) == len(inputs), "duplicate runtime input")
    resources = {
        "disk_free_bytes": shutil.disk_usage(ROOT).free,
        "cpu_count": os.cpu_count(),
        "platform": platform.platform(),
    }
    for name, command in (
        ("memory_pressure", ["/usr/bin/memory_pressure"]),
        ("memory_total", ["/usr/sbin/sysctl", "-n", "hw.memsize"]),
    ):
        proc = subprocess.run(command, capture_output=True, text=True, check=False)
        resources[name] = {
            "exit": proc.returncode,
            "stdout": proc.stdout,
            "stderr": proc.stderr,
        }
    plan = {
        "schema": "e02-r4-c96-matched-phase-plan-v2",
        "mode": args.mode,
        "created_at": datetime.now(UTC).isoformat(),
        "source_head": args.expected_head,
        "source_tree": args.expected_tree,
        "source_delta": source_delta,
        "branch": r1.BRANCH,
        "root_guard_before": before,
        "controller_sha256": own_sha,
        "baseline_audit_sha256": BASE_AUDIT_SHA,
        "baseline_strict_sha256": BASE_STRICT_SHA,
        "baseline_review_sha256": REVIEW_SHA,
        "baseline_reconciliation_sha256": RECONCILIATION_SHA,
        "baseline_strict_recomputed": baseline_strict,
        "baseline_bindings": baseline_bindings,
        "predecessor_case": args.removal_case,
        "predecessor_receipt_sha256": args.removal_receipt_sha256,
        "predecessor_bindings": predecessor_bindings,
        "selected_source_pins": pins,
        "selected_pin_denominator": len(pins),
        "inputs": input_hashes,
        "argv": argv,
        "cwd": str(r1.PRODUCT),
        "extra_env": env,
        "inherited_control_names_only": inherited,
        "cleared_control_names": cleared,
        "inherited_git_control_names_only": git_controls,
        "numeric_threads": monitor.NUMERIC_THREADS,
        "sandbox_sha256": sha(profile.encode()),
        "sandbox_fragment_sha256": r1.FRAGMENT_SHA,
        "sandbox_scope": "localhost exception includes wildcard bind",
        "resources_before": resources,
        "disk_admission_bytes": r1.DISK_START,
        "disk_stop_bytes": r1.DISK_STOP,
        "rss_cap_bytes": PHASE_RSS_CAP,
        "resource_profile": resource_profile(),
        "resource_history": resource_history,
        "resource_bindings": resource_bindings,
        "deadline_seconds": r1.DEADLINE,
        "closure_ids": [],
    }
    compare_profile(plan, case, baseline, args.mode)
    plan_sha = r1.write_json(case / "r3-plan.json", plan)
    result = {}
    qualification = {"outcome": "ERROR", "errors": ["not launched"]}
    errors = []
    try:
        start = time.monotonic()
        result = monitor.run_command(
            case,
            "c96-queued",
            ["/usr/bin/sandbox-exec", "-f", str(sandbox), *argv],
            r1.PRODUCT,
            start,
            start + r1.DEADLINE,
            env,
        )
        qualification = qualify_phase(r1, case, plan, result, args.mode)
    except BaseException as exc:
        errors.extend([type(exc).__name__ + ": " + str(exc), traceback.format_exc()])
    try:
        after = guard()
        need(
            after["head"] == args.expected_head
            and r1.git("rev-parse", "HEAD^{tree}").decode().strip()
            == args.expected_tree,
            "source moved during run",
        )
        need(
            not r1.git("status", "--porcelain", "--untracked-files=no"),
            "tracked source became dirty",
        )
        need(
            r1.source_pins(args.expected_head, workorder) == pins,
            "selected source changed",
        )
        need(
            admit_source_delta(r1, args.expected_head, args.expected_tree, baseline)
            == source_delta,
            "full source delta changed during run",
        )
        for rel, expected in {
            **input_hashes,
            **baseline_bindings,
            **resource_bindings,
            **predecessor_bindings,
        }.items():
            need(
                sha((ROOT / rel).read_bytes()) == expected,
                "bound input changed: " + rel,
            )
        need(
            sha((case / "r3-plan.json").read_bytes()) == plan_sha
            and sha(sandbox.read_bytes()) == plan["sandbox_sha256"],
            "plan or sandbox changed",
        )
    except BaseException as exc:
        after = None
        errors.append("post-run identity: " + type(exc).__name__ + ": " + str(exc))
    if errors:
        qualification = {"outcome": "ERROR", "errors": errors, "earlier": qualification}
    try:
        outputs = deciding_outputs(case)
    except (OSError, RuntimeError) as exc:
        outputs = []
        qualification = {
            "outcome": "ERROR",
            "errors": ["deciding outputs: " + str(exc)],
            "earlier": qualification,
        }
    receipt = {
        "schema": "e02-r4-c96-matched-phase-receipt-v2",
        "finished_at": datetime.now(UTC).isoformat(),
        "mode": args.mode,
        "source_head": args.expected_head,
        "source_tree": args.expected_tree,
        "source_delta": source_delta,
        "resource_profile": resource_profile(),
        "resource_history": resource_history,
        "plan_sha256": plan_sha,
        "baseline_audit_sha256": BASE_AUDIT_SHA,
        "baseline_strict_sha256": BASE_STRICT_SHA,
        "predecessor_case": args.removal_case,
        "predecessor_receipt_sha256": args.removal_receipt_sha256,
        "supervisor": result,
        "qualification": qualification,
        "deciding_outputs": outputs,
        "root_guard_after": after,
        "disk_free_after_bytes": shutil.disk_usage(ROOT).free,
        "limitations": [
            "fixture authority; no institutional authority",
            "event-held compute; no native fit",
            "finite end-process first-party Python readsets only",
            "process cleanup/guard restoration inside removal process not independently established",
            "G acceptance false",
        ],
        "closure_ids": [],
    }
    receipt_sha = r1.write_json(case / "r3-audit-result.json", receipt)
    print(
        json.dumps(
            {
                "case": str(case),
                "mode": args.mode,
                "outcome": qualification["outcome"],
                "receipt_sha256": receipt_sha,
            }
        )
    )
    expected_outcome = "EXPECTED_SEMANTIC_RED" if args.mode == "remove" else "PASS"
    return 0 if qualification["outcome"] == expected_outcome else 1


if __name__ == "__main__":
    raise SystemExit(main())
