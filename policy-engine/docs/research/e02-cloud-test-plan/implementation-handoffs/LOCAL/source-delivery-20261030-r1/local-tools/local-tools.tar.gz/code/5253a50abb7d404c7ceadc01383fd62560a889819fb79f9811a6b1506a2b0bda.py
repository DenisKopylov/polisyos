"""Seal exact R8 proposal/readback with stdlib only, never writing Git objects."""
from pathlib import Path
import ast
import hashlib
import json
import stat
import subprocess

ROOT=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
OUT=Path(__file__).resolve().parent
POST=OUT/'postimages'
sha=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((OUT/'manifest.json').read_text())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
branch=subprocess.check_output(['git','symbolic-ref','-q','HEAD'],cwd=ROOT,text=True).strip()
assert branch=='refs/heads/codex/e02-unified-local-20261009'
for row in m['files']:
    p=POST/row['path'];s=p.stat()
    assert stat.S_ISREG(s.st_mode) and s.st_nlink==1 and not p.is_symlink()
    assert sha(p.read_bytes())==row['postimage_sha256']
    if row['preimage_sha256'] is None:assert not (ROOT/row['path']).exists()
    else:
        assert sha((ROOT/row['path']).read_bytes())==row['preimage_sha256']
        assert subprocess.check_output(['git','rev-parse',head+':'+row['path']],cwd=ROOT,text=True).strip()==row['preimage_git_blob']
assert sha((OUT/'proposal.patch').read_bytes())==m['patch']['sha256']
checks=json.loads((OUT/'static-checks.json').read_text());assert all(r['exit']==0 for r in checks['checks'])
assert checks['outside_core_wire_function_identical'] and not checks['C105_admission_kernel_changed']
plan=json.loads((OUT/'verification-plan.json').read_text())
selected=plan['core_first_nodes']+plan['affected_consumer_nodes']
definitions=[]
for selector in selected:
    rel,name=selector.split('::',1);name=name.split('[',1)[0];p=POST/'policy-engine'/rel
    data=p.read_bytes() if p.exists() else subprocess.check_output(['git','show',m['base_commit']+':policy-engine/'+rel],cwd=ROOT)
    assert any(isinstance(n,ast.FunctionDef) and n.name==name for n in ast.parse(data).body),selector
    definitions.append(selector)
reg=json.loads((OUT/'register-proposal.json').read_text());base=(ROOT/reg['path']).read_bytes();assert sha(base)==reg['preimage_sha256']
added=''.join(line[1:] for line in (OUT/'register-companion.patch').read_text().splitlines(keepends=True) if line.startswith('+') and not line.startswith('+++')).encode()
assert sha(base+added)==reg['postimage_sha256']
check=subprocess.run(['git','apply','--check','--whitespace=error',str(OUT/'register-companion.patch')],cwd=ROOT,capture_output=True,text=True);assert check.returncode==0,check.stderr
control=json.loads((OUT/'property-removals.json').read_text())['controls'][0]
assert sha((OUT/'removals'/control['name']).read_bytes())==control['patch_sha256']
assert sha((POST/control['path']).read_bytes())==control['preimage_sha256']

# Reconcile the complete immutable base tree before computing a virtual overlay.
def git_hash(kind,data):return hashlib.sha1(kind+b' '+str(len(data)).encode()+b'\0'+data).hexdigest()
entries={}
for item in subprocess.check_output(['git','ls-tree','-r','-z',m['base_commit']],cwd=ROOT).split(b'\0'):
    if not item:continue
    meta,name=item.split(b'\t',1);mode,kind,oid=meta.split();entries[name]=(mode,oid.decode())
def tree_id(flat):
    root={}
    for name,value in flat.items():
        parts=name.split(b'/');at=root
        for part in parts[:-1]:at=at.setdefault(part,{})
        at[parts[-1]]=value
    def visit(node):
        data=[]
        for name,value in sorted(node.items(),key=lambda it:it[0]+(b'/' if isinstance(it[1],dict) else b'')):
            if isinstance(value,dict):mode=b'40000';oid=visit(value)
            else:mode,oid=value
            data.append(mode+b' '+name+b'\0'+bytes.fromhex(oid))
        return git_hash(b'tree',b''.join(data))
    return visit(root)
assert tree_id(entries)==m['base_tree']
for row in m['files']:
    key=row['path'].encode()
    if row['preimage_git_blob'] is None:assert key not in entries
    else:assert entries[key]==(row['preimage_mode'].encode(),row['preimage_git_blob'])
    data=(POST/row['path']).read_bytes();assert git_hash(b'blob',data)==row['postimage_git_blob']
    entries[key]=((row['preimage_mode'] or '100644').encode(),row['postimage_git_blob'])
virtual=tree_id(entries)
readback={'source_proposal_readback':True,'admission_head':head,'branch':branch,'current_preimages_all_match':True,'sparse_postimages':len(m['files']),'base_tree_reconciled':True,'virtual_overlay_tree':virtual,'complete_overlay_flat_entry_count':len(entries),'virtual_tree_is_not_commit':True,'Core_outside_changed_wire_function_identical':True,'C105_kernel_unchanged':True,'selected_test_definitions_AST':len(definitions),'collection_runtime_UNRUN':True,'register_entire_current_prefix_preserved':True,'register_apply_check':{'exit':check.returncode,'stdout':check.stdout,'stderr':check.stderr},'canonical_source_index_refs_changed':False,'product_imports_or_execution_by_author':False,'G_acceptance':'not_adjudicated'}
(OUT/'readback.json').write_text(json.dumps(readback,indent=2)+'\n')
m['virtual_overlay_tree']=virtual
m['current_root_head_at_closeout']=head
m['packet_files']={str(p.relative_to(OUT)):sha(p.read_bytes()) for p in sorted(OUT.iterdir()) if p.is_file() and p.name not in {'manifest.json','proposal.patch'}}
m['removal_patch_files']={str(p.relative_to(OUT)):sha(p.read_bytes()) for p in sorted((OUT/'removals').glob('*.patch'))}
m['independent_review']='PENDING; one frozen R8 delta against the composed Root base, preserving all older packets/receipts.'
(OUT/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
reopened=json.loads((OUT/'manifest.json').read_text())
for name,digest in reopened['packet_files'].items():assert sha((OUT/name).read_bytes())==digest,name
for name,digest in reopened['removal_patch_files'].items():assert sha((OUT/name).read_bytes())==digest,name
print(json.dumps({'manifest_sha256':sha((OUT/'manifest.json').read_bytes()),'patch_sha256':m['patch']['sha256'],'patch_bytes':m['patch']['bytes'],'footprint':m['footprint'],'base_commit':m['base_commit'],'current_root_head':head,'virtual_overlay_tree':virtual,'all_runtime':'UNRUN by author'}))
