#!/usr/bin/env python3
"""Emit the locked, minimal Linux/aarch64 CPython 3.14 I2 wheel set.

This is a read-only resolver over uv.lock and the existing product .venv metadata.
It does not import PolicyOS, access a registry, download, install, or run tests.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata as metadata
import json
import re
import subprocess
import sys
import tomllib
from collections import deque
from pathlib import Path
from urllib.parse import urlparse

from packaging.markers import Marker
from packaging.tags import compatible_tags, cpython_tags
from packaging.utils import canonicalize_name, parse_wheel_filename
from packaging.version import Version

TARGET_PYTHON = "3.14.3"
TARGET_ENV = {
    "implementation_name": "cpython",
    "implementation_version": TARGET_PYTHON,
    "os_name": "posix",
    "platform_machine": "aarch64",
    "platform_python_implementation": "CPython",
    "platform_release": "",
    "platform_system": "Linux",
    "platform_version": "",
    "python_full_version": TARGET_PYTHON,
    "python_version": "3.14",
    "sys_platform": "linux",
    "extra": "",
}
TARGET_PLATFORMS = (
    "manylinux_2_17_aarch64",
    "manylinux2014_aarch64",
    "any",
)

# These roots come from module-level imports on the admitted test/CLI path.
# Every evidence snippet is checked and its file hash is emitted in the receipt.
CODE_ROOTS = {
    "click": ("policy-engine/tools/cli.py", "import click"),
    "cryptography": (
        "policy-engine/src/polisyos/core/artifacts/signing.py",
        "from cryptography.",
    ),
    "loguru": ("policy-engine/tests/conftest.py", "from loguru import logger"),
    "opentelemetry-api": (
        "policy-engine/tests/_helpers/observability.py",
        "from opentelemetry import trace",
    ),
    "opentelemetry-sdk": (
        "policy-engine/tests/_helpers/observability.py",
        "from opentelemetry.sdk.trace import",
    ),
    "orjson": (
        "policy-engine/src/polisyos/common/serialization/__init__.py",
        "import orjson as _orjson",
    ),
    "packaging": (
        "policy-engine/src/polisyos/core/components/_provider_origin.py",
        "from packaging.utils import",
    ),
    "pydantic": (
        "policy-engine/src/polisyos/data_forge/kernel/schemas/evolution.py",
        "from pydantic import",
    ),
    "pytest": (
        "policy-engine/tests/unit/remediation/test_dfk_01.py",
        "import pytest",
    ),
}
EXPECTED_CODE_ROOT_VERSIONS = {
    "click": "8.3.1",
    "cryptography": "46.0.4",
    "loguru": "0.7.3",
    "opentelemetry-api": "1.39.1",
    "opentelemetry-sdk": "1.39.1",
    "orjson": "3.11.5",
    "packaging": "25.0",
    "pydantic": "2.12.5",
    "pytest": "9.0.2",
}
EXPECTED_PYTEST11 = {
    ("anyio", "anyio", "anyio.pytest_plugin", "4.12.0"),
    ("hypothesis", "hypothesispytest", "_hypothesis_pytestplugin", "6.151.2"),
    ("jaxtyping", "jaxtyping", "jaxtyping._pytest_plugin", "0.3.4"),
    ("langsmith", "langsmith_plugin", "langsmith.pytest_plugin", "0.6.0"),
    ("pytest-asyncio", "asyncio", "pytest_asyncio.plugin", "1.3.0"),
    ("pytest-benchmark", "benchmark", "pytest_benchmark.plugin", "5.2.3"),
    ("pytest-xdist", "xdist", "xdist.plugin", "3.8.0"),
    ("pytest-xdist", "xdist.looponfail", "xdist.looponfail", "3.8.0"),
}
PLUGIN_ROOT_VERSIONS = {
    "anyio": "4.12.0",
    "hypothesis": "6.151.2",
    "jaxtyping": "0.3.4",
    "langsmith": "0.6.0",
    "pytest-asyncio": "1.3.0",
    "pytest-benchmark": "5.2.3",
    "pytest-xdist": "3.8.0",
}
SOURCE_BINDINGS = (
    "policy-engine/pyproject.toml",
    "policy-engine/pytest.ini",
    "policy-engine/uv.lock",
    "policy-engine/tests/unit/remediation/test_dfk_01.py",
    "policy-engine/tests/conftest.py",
    "policy-engine/tests/_helpers/artifacts.py",
    "policy-engine/tests/_helpers/observability.py",
    "policy-engine/tools/cli.py",
    "policy-engine/tools/registry.py",
    "policy-engine/tools/lib/__init__.py",
    "policy-engine/tools/lib/fs.py",
    "policy-engine/tools/lib/runner.py",
    "policy-engine/tools/lib/timing.py",
    "policy-engine/tools/quality/validation/schema_fqn_census.py",
    "policy-engine/src/polisyos/__init__.py",
    "policy-engine/src/polisyos/core/__init__.py",
    "policy-engine/src/polisyos/core/artifacts/__init__.py",
    "policy-engine/src/polisyos/core/artifacts/manifest.py",
    "policy-engine/src/polisyos/core/artifacts/signing.py",
    "policy-engine/src/polisyos/core/components/__init__.py",
    "policy-engine/src/polisyos/core/components/ids.py",
    "policy-engine/src/polisyos/core/components/_provider_origin.py",
    "policy-engine/src/polisyos/core/canon/__init__.py",
    "policy-engine/src/polisyos/common/logger/__init__.py",
    "policy-engine/src/polisyos/common/serialization/__init__.py",
    "policy-engine/src/polisyos/data_forge/__init__.py",
    "policy-engine/src/polisyos/data_forge/read_api/__init__.py",
    "policy-engine/src/polisyos/data_forge/read_api/surfaces.py",
    "policy-engine/src/polisyos/data_forge/kernel/__init__.py",
    "policy-engine/src/polisyos/data_forge/kernel/schemas/__init__.py",
    "policy-engine/src/polisyos/data_forge/kernel/schemas/evolution.py",
    "policy-engine/src/polisyos/data_forge/kernel/schemas/migrations.py",
    "policy-engine/src/polisyos/data_forge/kernel/schemas/registry.py",
)


def fail(message: str) -> "NoReturn":
    raise SystemExit(f"STOP: {message}")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def normalize(name: str) -> str:
    return str(canonicalize_name(name))


def host_git(repo: Path, *args: str) -> str:
    try:
        proc = subprocess.run(
            ["git", "-C", str(repo), *args],
            check=True,
            capture_output=True,
            text=True,
        )
    except (OSError, subprocess.CalledProcessError) as exc:
        fail(f"host Git admission unavailable for {args!r}: {exc}")
    return proc.stdout.strip()


def verify_pytest11() -> list[dict[str, str]]:
    actual: set[tuple[str, str, str, str]] = set()
    for dist in metadata.distributions():
        dist_name = dist.metadata.get("Name")
        if not dist_name:
            continue
        for ep in dist.entry_points:
            if ep.group == "pytest11":
                actual.add(
                    (normalize(dist_name), ep.name, ep.value, dist.version or "")
                )
    if actual != EXPECTED_PYTEST11:
        fail(
            "default pytest11 entry points differ from the admitted product .venv; "
            f"actual={sorted(actual)!r}"
        )
    return [
        {"distribution": d, "entry_point": e, "module": m, "version": v}
        for d, e, m, v in sorted(actual)
    ]


def verify_roots(repo: Path) -> dict[str, str]:
    product = repo / "policy-engine"
    expected_prefix = (product / ".venv").resolve()
    if Path(sys.prefix).resolve() != expected_prefix:
        fail("run with the existing policy-engine/.venv interpreter")
    if sys.version_info[:2] != (3, 14):
        fail("selector requires the existing CPython 3.14 product .venv")
    if metadata.version("packaging") != "25.0":
        fail("selector requires packaging==25.0 from the existing product .venv")

    for rel, snippet in CODE_ROOTS.values():
        path = repo / rel
        if not path.is_file() or snippet not in path.read_text(encoding="utf-8"):
            fail(f"source import evidence changed or missing: {rel} ({snippet!r})")

    for rel in SOURCE_BINDINGS:
        if not (repo / rel).is_file():
            fail(f"source binding missing: {rel}")

    versions = dict(EXPECTED_CODE_ROOT_VERSIONS)
    versions.update(PLUGIN_ROOT_VERSIONS)
    actual: dict[str, str] = {}
    for name, expected in versions.items():
        try:
            actual[name] = metadata.version(name)
        except metadata.PackageNotFoundError:
            fail(f"selected host .venv distribution is missing: {name}")
        if actual[name] != expected:
            fail(f"{name} .venv pin changed: expected {expected}, got {actual[name]}")
    return actual


def target_tags() -> tuple[list[object], dict[object, int]]:
    ordered = list(
        cpython_tags(
            python_version=(3, 14),
            abis=("cp314", "abi3", "none"),
            platforms=TARGET_PLATFORMS,
        )
    )
    ordered.extend(
        compatible_tags(
            python_version=(3, 14),
            interpreter="cp314",
            platforms=TARGET_PLATFORMS,
        )
    )
    unique = list(dict.fromkeys(ordered))
    return unique, {tag: index for index, tag in enumerate(unique)}


def load_locked_packages(lock_path: Path) -> dict[str, list[dict[str, object]]]:
    data = tomllib.loads(lock_path.read_text(encoding="utf-8"))
    if data.get("requires-python") != "==3.14.*":
        fail(f"uv.lock Python constraint changed: {data.get('requires-python')!r}")
    packages: dict[str, list[dict[str, object]]] = {}
    for package in data.get("package", []):
        packages.setdefault(normalize(str(package["name"])), []).append(package)
    return packages


def select_closure(
    packages: dict[str, list[dict[str, object]]],
    roots: dict[str, str],
    *,
    evaluate_markers: bool,
) -> tuple[dict[str, dict[str, object]], list[dict[str, str]]]:
    selected: dict[str, dict[str, object]] = {}
    excluded: list[dict[str, str]] = []
    pending = deque(roots)
    while pending:
        name = normalize(pending.popleft())
        if name in selected:
            continue
        candidates = packages.get(name, [])
        expected_root_version = roots.get(name)
        if expected_root_version is not None:
            candidates = [
                item for item in candidates
                if str(item["version"]) == expected_root_version
            ]
        if len(candidates) != 1:
            versions = [str(item.get("version")) for item in candidates]
            fail(f"locked package {name} is missing/ambiguous: {versions!r}")
        package = candidates[0]
        source = package.get("source")
        if not isinstance(source, dict) or source.get("registry") != "https://pypi.org/simple":
            fail(f"selected package is not from public PyPI: {name}: {source!r}")
        selected[name] = package
        for dependency in package.get("dependencies", []):
            dep_name = normalize(str(dependency["name"]))
            if dependency.get("extras") or dependency.get("extra"):
                fail(
                    f"selected dependency requests an extra not covered by this selector: "
                    f"{name} -> {dep_name}"
                )
            marker_text = str(dependency.get("marker", ""))
            if evaluate_markers and marker_text:
                try:
                    applies = Marker(marker_text).evaluate(environment=TARGET_ENV)
                except Exception as exc:
                    fail(f"cannot evaluate lock marker {marker_text!r}: {exc}")
                if not applies:
                    excluded.append(
                        {"from": name, "dependency": dep_name, "marker": marker_text}
                    )
                    continue
            pending.append(dep_name)
    return selected, excluded


def choose_wheel(
    name: str,
    package: dict[str, object],
    tag_rank: dict[object, int],
) -> dict[str, object]:
    expected_version = Version(str(package["version"]))
    matches: list[tuple[int, int, str, str, str]] = []
    for wheel in package.get("wheels", []):
        url = str(wheel["url"])
        parsed_url = urlparse(url)
        if parsed_url.scheme != "https" or parsed_url.netloc != "files.pythonhosted.org":
            continue
        filename = parsed_url.path.rsplit("/", 1)[-1]
        try:
            wheel_name, wheel_version, _build, wheel_tags = parse_wheel_filename(filename)
        except Exception:
            continue
        if normalize(str(wheel_name)) != name or wheel_version != expected_version:
            continue
        compatible = [tag for tag in wheel_tags if tag in tag_rank]
        if not compatible:
            continue
        best_tag = min(compatible, key=lambda tag: tag_rank[tag])
        hash_value = str(wheel.get("hash", ""))
        if not hash_value.startswith("sha256:"):
            fail(f"wheel has no locked SHA-256: {name} {filename}")
        size = int(wheel["size"])
        matches.append(
            (tag_rank[best_tag], size, url, hash_value, str(best_tag))
        )
    if not matches:
        fail(f"no locked compatible binary wheel for Linux/aarch64 CPython 3.14: {name}")
    rank, size, url, hash_value, tag = min(matches)
    return {
        "url": url,
        "sha256": hash_value.removeprefix("sha256:"),
        "size_bytes": size,
        "compatible_tag": tag,
        "tag_rank": rank,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    repo = args.repo_root.resolve()
    output_dir = args.output_dir.resolve()
    product = repo / "policy-engine"
    lock_path = product / "uv.lock"

    if output_dir.exists():
        fail(f"output directory already exists; preserve it and choose a new path: {output_dir}")
    if not lock_path.is_file():
        fail(f"uv.lock not found: {lock_path}")

    env_versions = verify_roots(repo)
    pytest11 = verify_pytest11()
    roots = dict(env_versions)
    lock_packages = load_locked_packages(lock_path)
    raw_closure, _ = select_closure(lock_packages, roots, evaluate_markers=False)
    linux_closure, excluded = select_closure(
        lock_packages, roots, evaluate_markers=True
    )
    if len(raw_closure) != 45 or len(linux_closure) != 43:
        fail(
            "selector cardinality changed; inspect sources/markers before admission: "
            f"marker-agnostic={len(raw_closure)}, Linux-Python-3.14={len(linux_closure)}"
        )

    ordered_tags, tag_rank = target_tags()
    selected: list[dict[str, object]] = []
    total_bytes = 0
    for name, package in sorted(linux_closure.items()):
        wheel = choose_wheel(name, package, tag_rank)
        total_bytes += int(wheel["size_bytes"])
        selected.append(
            {
                "name": name,
                "version": str(package["version"]),
                "direct_root": name in roots,
                "dependencies": sorted(
                    normalize(str(dep["name"]))
                    for dep in package.get("dependencies", [])
                    if not dep.get("marker")
                    or Marker(str(dep["marker"])).evaluate(environment=TARGET_ENV)
                ),
                "wheel": wheel,
            }
        )
    if total_bytes != 16_951_703:
        fail(f"selected wheel byte total changed: {total_bytes}")

    binding_paths = sorted(set(SOURCE_BINDINGS) | {rel for rel, _ in CODE_ROOTS.values()})
    source_bindings = {
        rel: {
            "sha256": sha256(repo / rel),
            "git_status": host_git(repo, "status", "--porcelain=v1", "--", rel),
        }
        for rel in binding_paths
    }
    branch = host_git(repo, "branch", "--show-current")
    commit = host_git(repo, "rev-parse", "HEAD")
    tree = host_git(repo, "rev-parse", "HEAD^{tree}")
    lock_sha = sha256(lock_path)
    script_sha = sha256(Path(__file__).resolve())

    requirements = [
        "# Generated from policy-engine/uv.lock; public PyPI wheels only.",
        "# Install with --require-hashes --no-deps --only-binary=:all:.",
    ]
    for item in selected:
        wheel = item["wheel"]
        requirements.append(
            f'{item["name"]} @ {wheel["url"]} --hash=sha256:{wheel["sha256"]}'
        )
    requirements_text = "\n".join(requirements) + "\n"

    result = {
        "schema_version": 1,
        "selector": "I2-minimal-test-cli-linux-aarch64-cp314",
        "source": {
            "branch": branch,
            "commit": commit,
            "tree": tree,
            "input_files": source_bindings,
        },
        "selector_script_sha256": script_sha,
        "uv_lock_sha256": lock_sha,
        "host_selector_environment": {
            "python": sys.version.split()[0],
            "executable": str(Path(sys.executable).resolve()),
            "packaging": metadata.version("packaging"),
            "root_versions": dict(sorted(env_versions.items())),
            "pytest11_entry_points": pytest11,
        },
        "target_environment": TARGET_ENV,
        "target_wheel_platform_floor": "manylinux2014_aarch64 / manylinux_2_17_aarch64",
        "selector_roots": {
            "source_imports": {
                name: {"evidence_file": rel, "import_evidence": snippet}
                for name, (rel, snippet) in sorted(CODE_ROOTS.items())
            },
            "pytest11": pytest11,
        },
        "counts": {
            "marker_agnostic_locked_closure": len(raw_closure),
            "linux_cp314_locked_closure": len(linux_closure),
            "excluded_by_target_markers": excluded,
            "selected_wheels": len(selected),
            "selected_wheel_archive_bytes": total_bytes,
        },
        "packages": selected,
        "requirements_sha256": hashlib.sha256(
            requirements_text.encode("utf-8")
        ).hexdigest(),
    }

    output_dir.mkdir(parents=True, exist_ok=False)
    requirements_path = output_dir / "requirements-linux-aarch64-cp314.txt"
    receipt_path = output_dir / "resolution.json"
    with requirements_path.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(requirements_text)
    with receipt_path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, sort_keys=True)
        stream.write("\n")

    print(
        json.dumps(
            {
                "source_commit": commit,
                "source_tree": tree,
                "uv_lock_sha256": lock_sha,
                "marker_agnostic_packages": len(raw_closure),
                "linux_cp314_packages": len(linux_closure),
                "selected_wheels": len(selected),
                "selected_wheel_archive_bytes": total_bytes,
                "requirements_path": str(requirements_path),
                "requirements_sha256": result["requirements_sha256"],
                "resolution_path": str(receipt_path),
                "resolution_sha256": sha256(receipt_path),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
