"""Supplement R18 forensic evidence from the saved registration object."""
from pathlib import Path
from hashlib import sha256
import json
base = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos/policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1/sql-v3-owner-first-native-r18-20261028/basetemp/test_selected_registered_sql_p0/cas')
obj = base / 'decision_validity/committed_source_objects/98f65f39420afc7a8b073bff80fe85e5e1ed92ad131fa797bb05cfa0ab583129.json'
raw = obj.read_bytes()
assert sha256(raw).hexdigest() == obj.stem
registration = json.loads(raw)['value']
blob = base / 'artifacts/sha256/3d/29/3d292ae3d49223cf7abf638647d2a54b628ce46678c2422a34b7f3496ff649e8.blob'
assert sha256(blob.read_bytes()).hexdigest() == blob.stem
capture = json.loads(blob.read_bytes())
print(json.dumps({'registration_object':str(obj),'registration_sha256':sha256(raw).hexdigest(),'view_matches_capture':registration['effective_view_contract_ref']==capture['view_ref'],'use_matches_capture':registration['use_contract_ref']==capture['use_ref'],'scope':'One saved registration object selected by explicit filename; this does not replay C105 root reachability or establish current use.','forensic_json_correction':'The original selected_edge_profiles_and_blob_hashes_checked count means selected profile filenames existed and corresponding blob hashes were verified. It did not recompute manifest-profile hashes. Its expected source.view/use refs came from capture; this addendum independently compares the saved registration object.'},indent=2))
