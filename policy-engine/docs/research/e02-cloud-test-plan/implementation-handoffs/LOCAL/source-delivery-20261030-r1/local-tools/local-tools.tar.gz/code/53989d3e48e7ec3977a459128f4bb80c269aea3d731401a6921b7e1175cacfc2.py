"""Freeze the narrow structural owner proposal; does not mutate canonical files/index/refs."""
from pathlib import Path
import ast,datetime,difflib,hashlib,json,re,subprocess,tomllib
R=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos');D=Path(__file__).resolve().parent;O=D/'postimages';BASE='ee00568f6067b7cad6efeca700181be09100e33c'
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
def save(rel,data):
 p=O/rel;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(data if isinstance(data,bytes)else data.encode());return p
# Complete canonical-file denominator, before documentation/control companions are added.
code_files=sorted(p for p in O.rglob('*')if p.is_file());py_files=[p for p in code_files if p.suffix=='.py'];assert len(code_files)==9 and len(py_files)==6
config=R/'policy-engine/pyproject.toml';python=R/'policy-engine/.venv/bin/python';ruff=[str(python),'-m','ruff'];checks=[]
version=subprocess.run(ruff+['--version'],cwd=R/'policy-engine',capture_output=True,check=True)
for p in py_files:
 rel=str(p.relative_to(O));fmt=ruff+['format','--config',str(config),'--no-cache','--stdin-filename',str(R/rel),'-'];v=subprocess.run(fmt,input=p.read_bytes(),cwd=R/'policy-engine',capture_output=True,check=True);p.write_bytes(v.stdout)
 for kind,tail in [('lint',['check','--output-format','json']),('format',['format','--check'])]:
  command=ruff+tail+['--config',str(config),'--no-cache','--stdin-filename',str(R/rel),'-'];result=subprocess.run(command,input=p.read_bytes(),cwd=R/'policy-engine',capture_output=True);assert result.returncode==0,(rel,kind,result.stdout,result.stderr)
  checks.append({'path':rel,'kind':kind,'command':command,'cwd':str(R/'policy-engine'),'stdin_sha256':sha(p.read_bytes()),'exit':result.returncode,'stdout':result.stdout.decode(),'stderr':result.stderr.decode()})
 ast.parse(p.read_bytes())
for p in code_files:
 if p.suffix=='.toml':tomllib.loads(p.read_text())
# All removal bases must still match the now-formatted final mechanism files.
controls=json.loads((D/'controls/index.json').read_text())
for c in controls['controls']:
 assert sha((O/c['path']).read_bytes())==c['pre_sha256'],c['id']
 raw=(D/c['postimage']).read_bytes();assert sha(raw)==c['post_sha256'];ast.parse(raw)
# Compare every old function/class body outside the explicitly extended owner functions.
source_preservation=[]
for rel,allowed in [('policy-engine/src/polisyos/core/contracts/decision_validity.py',set()),('policy-engine/src/polisyos/scientist/validation/decision_validity.py',{'_DecisionValidityStateStore.current_projection_generation_ref','DecisionValidityService.__init__'})]:
 old=git('show',BASE+':'+rel).decode();new=(O/rel).read_text()
 def functions(source):
  result={}
  def walk(node,prefix=''):
   for child in ast.iter_child_nodes(node):
    if isinstance(child,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)):
     name=prefix+child.name
     if isinstance(child,(ast.FunctionDef,ast.AsyncFunctionDef)):result[name]=ast.dump(child,include_attributes=False)
     walk(child,name+'.')
    else:walk(child,prefix)
  walk(ast.parse(source));return result
 a,b=functions(old),functions(new);unexpected=[k for k in a if a[k]!=b.get(k)and k not in allowed];assert not unexpected,unexpected
 source_preservation.append({'path':rel,'existing_function_definitions':len(a),'allowed_extended_functions':sorted(allowed),'unexplained_existing_function_delta':unexpected})
static={'schema':'e02.c105.structural-owner.static.v1','at':datetime.datetime.now(datetime.UTC).isoformat(),'base_commit':BASE,'scope':'Six final sparse Python files via canonical stdin filenames; source/test imports and runtime unrun','ruff_version':version.stdout.decode(),'config_sha256':sha(config.read_bytes()),'checks':checks,'existing_function_preservation':source_preservation,'runtime':'UNRUN','code_acceptance':False,'closure_ids':[]}
STATIC='policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/C105/structural-owner-r2/static-receipt.json';save(STATIC,json.dumps(static,indent=2)+'\n')
# Deliver each small patch rather than an unavailable ignored mutant path/hash.
prefix='policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/C105/structural-owner-r2'
portable=[]
for c in controls['controls']:
 target=prefix+'/controls/'+c['id']+'.patch';save(target,(D/c['patch']).read_bytes());entry={k:v for k,v in c.items()if k not in {'postimage','patch'}};entry['patch']=c['id']+'.patch';entry['postimage_delivery']='Reconstruct exactly from the pinned Git source bytes plus this delivered patch; full mutant is not required.';portable.append(entry)
save(prefix+'/controls/index.json',json.dumps({'schema':'e02.c105.portable-removal-recipes.v1','source_rule':'policyos.registered-sql-admission.v1','controls':portable,'runtime':'UNRUN','no_ignored_hash_only_delivery':True},indent=2)+'\n')
execution='''# C105 structural owner R2 execution contract

This is a source proposal, not G acceptance or a completed SQL capability. Follow
G27-02 in `../../LOCAL/executor-continuation-plan-20261027/decisions/G27-02-source-admission.md`.
Historical B13/B198 dispositions are not reopened; `closure_ids=[]`.

## Scope and first actions

One writer composes Core DTOs, the existing DecisionValidityService and its
mandatory helper/test/docs/release/control companions. All source persistence is
inside that owner's existing fence and directory. Do not add a second source
ledger, mutable status authority or publication bypass.

After exact preimage admission and ordinary composition, run physical Ruff on the
six Python paths and the normal relevant architecture/public/schema checks. Read
back actual source from the commit. The static receipt here contains complete
Ruff stdout/stderr on exact final postimage bytes, not runtime or physical-source
qualification. Do not mark the release public-review flag true until the actual
owner inventory/signature/schema disposition has been reviewed.

Use existing Python and environments; no reinstall or production payload. First
admit one new storage/process profile alone, measuring process-tree RSS, disk and
wall time. Initial child/thread 120s guards are deadlock/resource probes, not
product latency criteria; timeout/resource abort is harness ERROR/UNRUN and must
be diagnosed/re-admitted before deciding checks. The native owner process uses
the retained normal pytest/plugins/config profile, one numeric thread, private
cache/output scratch and a frozen full input/source frame. No broad suite replay
for a documentation HEAD.

1. Collect the exact new mirrored test file under normal pytest/import mode.
2. First run `test_unconfigured_and_lookalike_authority_cannot_register_or_admit`.
3. Run the real-CAS storage/reader A/B/I scenario, then readmit, full target event
   conflict, predecessor, orphan and actual uncertain-directory-fsync checks.
4. Run each of the two actual child kill cases separately until their native
   time/RSS/source provenance is measured. The child source-origin inventory is
   finite ordinary imported Python; it is not a whole-repository/syscall/compiled
   dependency proof. Preserve its complete output and JSON alongside the parent
   command outputs, PID, source, profile and actual executed-code observations.
5. Run both barrier orderings, optional-warning byte corruption, full selected
   profile and actual missing-parent-edge cases, complete carrier identity,
   exact basis/query binding and unrelated-index-value/constant-root checks.
6. Only then run the full new file once if changes/failures justify it, plus the
   existing affected DecisionValidityService/epoch consumers. No old packet or
   epoch migration acceptance is implied by the new source-only tests.

All positive storage fixtures intentionally seed the private owner state. Their
real CAS, index, locking, process, lineage and fresh-reader behavior can qualify;
they do not mint an actual Runtime grant or prove SQL producer origin. Public
lookalikes/unconfigured paths must refuse. C106 supplies the actual installed
Runtime factory, live explicitly selected registered SQL producer, real applied
view/capture, Foundry basis and default/exact/cache API chain. This is internal
implementation work in parallel, not an external-data blocker.

## Removal controls and evidence

`controls/index.json` and all eight small patches are delivered here. Their source
SHA is an actual admission guard. Apply a control only in the owning isolated
worker/scratch with an explicit one-writer lease. Freeze the admitted baseline,
record full before/remove/restored source byte manifests, and restore the exact
original bytes by atomic replacement; do not reset, rebase, stash or change refs.
The original test oracle and supported backend/profile stay fixed across the
triplet. Save the complete quiet deciding stdout/stderr and target result per
phase, compressing losslessly if needed. Setup/collection/import/profile failure,
wrong exception or a null exit is not the intended semantic red.

Each patch specifies its actual target node/property/distinguishing red. The
first full source review and execution must independently qualify the controls;
static AST validity is not runtime PASS. The consumer-currentness/source status
field is not a generic scientific/legal admissibility gate. Actual C106 source
withdrawal must still make dependent D refuse while independent I remains valid,
history stays readable, and removal with markers retained produces the real red.

Deliver code/tests/companions before evidence. Return a small receipt with exact
base/final commit/tree and complete changed footprint, input/profile/backend and
actual command/PID/phase source bindings, separate PASS/FAIL/ERROR/SKIP/UNRUN,
positive/control/restoration results and available deciding bytes/locators/hashes.
Classify evidence A required, B reproducible by Git+recipe, C noise, D irreplaceable.
Do not return ignored cloud paths+hashes as delivered bytes, copy environments,
CAS/databases/fixtures or repeat all computation merely because transport failed.
'''
save(prefix+'/EXECUTION.md',execution)
reference='''# Registered materialization owner kernel

This extends the existing DecisionValidityService for G27-02; it does not create a
simulation ledger or confer external SQL currentness. This source-only profile is
`bridge_missing` / `verification_missing` until the actual Runtime/Fabric producer,
Foundry basis and served consumers are composed and checked. No G acceptance or
closure is assigned, and the historical B13/B198 dispositions remain unchanged.

## Reuse and the single authoritative quantity

Reuse actual Core CAS full selected-profile/raw-byte/ownership readers, the
DataSnapshotOwnerBound generic field/role requirements, the existing validity
owner lock and its typed contract family. Extend that owner with one immutable
quantity holding registration, source facts, occurrences, admissions/epochs,
selection, event identities/dedupe and per-use heads. Consolidate all covered
source current-use reads through it; mutable legacy packet fields are not a
second admission authority.

The inspected existing alternatives were `core/security/anchor_lineage.py`
(atomic head but state contains all records and recovery scans transactions),
`core/artifacts/ownership.py` (its own purpose/fence and full artifact snapshot),
and existing validity atomic-file helpers (serialization without a multi-file
commit). They provide useful persistence patterns, but none of these selected
ports is a reusable bounded-key source index under the existing validity fence.
This is a bounded source search, not a repository-wide absence claim. Build only
one private path-copy hash index part here, rather than repurposing another
sovereign state owner or copying every packet/history on each transition.

One constant-size fsynced root under `decision_validity/epoch_batch.lock` points
to reusable immutable index/fact/event objects. Orphans before publication have
no authority. Dedupe is reachable only through that committed root. An uncertain
root replacement is actually re-fsynced before an original receipt or positive
read is returned. No source transition scans all source heads or event history;
the actual I/O oracle rejects unrelated fact-value reads and growing root bytes.
This does not claim the cost of the existing Core CAS ownership index or
unverified NFS/distributed filesystem durability.

## Scope, origin and lifecycle

A private neutral port accepts only registered issuer/capture identities. Its
minting helpers are trusted-composition seams, not public candidate factories.
C106 must bind the real installed Runtime grant/config and actual canonical
registered provider capture. A callback/string/DTO alone is not authority; no
current source producer/factory wiring is claimed in this kernel proposal.
The public unconfigured and lookalike paths fail closed. Storage-unit positives
explicitly seed private state and are not real producer proof.

The issuer freezes tenant/cell/provider, configured logical registration key,
exact view/use refs and explicit permitted operations. Owner-issued incarnation
survives rereads and credential rotation; acquisition occurrences are separate
from CAS content deduplication. Typed materialization carries actual capture,
request/snapshot/data/schema/quality plus schema-derived optional evidence and
warnings. Actual Core tenant-scoped selected-view ownership and raw content are
verified; binary inputs are not forced through a JSON reader.

Admit never changes default selection. Explicit supersede selects an active
carrier. Withdraw targets the exact revision/use; readmit creates a new epoch and
never revives old carriers. Source predecessor and full command/target identity
are load bearing; a changed duplicate or absent predecessor refuses. Timestamps
are not sorted to infer committed order. Existing independent carriers survive
unrelated global generations.

## Fresh consumer contract

CAS reads happen outside the common owner fence. A second fenced read selects
one durable root and checks the exact committed carrier/fact/epoch/registration.
The projection binds the ordered, repeated actual carrier vector and selection
query by `basis_digest`, reports `selection_checked`, root/generation/rule and
`owner_fence_linearization_point`. Any required withdrawn carrier blocks the
conjunction; other missing/incomplete/legacy scope is unknown; current requires
all facts/content and an exact bound query. A prior valid answer is not guaranteed
until network delivery. This projection is internal admission, not scientific or
legal validity.

C106 must derive the complete supported Foundry basis, bind the actual returned
projection to that basis/query and execute this same owner for both default and
explicit/cached API selection. No snapshot-to-latest-carrier shortcut, public
Research DAG protected refs, rewritten SimulationResult/history, success-marker
authority or automatic local replay of missing cloud bytes is allowed.

## Pattern and verification boundary

P01/P02 producer/bridge reality remains explicit; P05/P32/P37 require the actual
configured issuer and captured producer relation; P31/P40 widen the entire
root-reachable fact/event/index quantity once; P29/P38 controls remove runtime
properties while keeping markers; P07/P08 retain exact refs, rule and time roles;
P14 separates source review, store-unit evidence, real runtime, G and closure.
The new source/test/control bundle is pending independent review and all runtime.
See `docs/research/e02-cloud-test-plan/implementation-handoffs/C105/structural-owner-r2/EXECUTION.md`.
'''
save('policy-engine/docs/reference/source-admission-kernel.md',reference)
# Freeze actual coordination contract with code hashes, without rewriting historical R1.
iface=(D/'INTERFACE-r1.md').read_text();iface=iface.replace('## Neutral capability and producer proof','## Neutral capability and producer proof (R2 actual source)')
iface+='''

## R2 binding refinements (supersede the shorter R1 descriptions above)

The private issuer factory additionally REQUIRES configured `registration_key`,
full `effective_view_contract_ref`, full `use_contract_ref`, and explicit nonempty
`permitted_operations: frozenset[SourceAdmissionOperation]`. The operation literal
set is genesis/admit/withdraw/readmit/supersede/read_event. Every command is checked
against the actual committed registration and these exact bounds.
`RegisteredMaterialization` additionally REQUIRES `producer_capture_ref: ArtifactRef`.
Snapshot fields/manifest requirements are derived using the existing Core owner
contract, including present evidence/warnings; no hidden/plugin readset claim.
First admit predecessor is registration.event_ref; receipt.scope_head is the new
event_ref. `resolve_source_admission_event(authority, *, event_id)` returns only a
protected original committed receipt or None; it creates no admission and is not
permission to accept a changed retry command. It reconciles uncertain durability.
The projection adds basis_digest and selection_checked; canonical Core exports
`source_admission_basis_digest(carriers, *, require_selected=False)` to bind the
exact ordered repeated query. C106 must compare the actual queried basis.
Actual selected-view reads reuse concrete FileSystemCAS.for_tenant ownership from
the verified issuer or the committed registration; unsupported/missing ownership
fails closed. Administrative withdrawal does not require a new SQL read. Keep
issuer identity stable across credential rotation, separate from the owner-issued
source incarnation and actual per-acquisition producer capture.

The actual interfaces are implemented in the following frozen postimages, not
merely promised by this coordination record:
'''
for rel in ['policy-engine/src/polisyos/core/contracts/decision_validity.py','policy-engine/src/polisyos/scientist/validation/source_admission_port.py','policy-engine/src/polisyos/scientist/validation/decision_validity.py','policy-engine/src/polisyos/scientist/validation/source_admission_owner.py','policy-engine/src/polisyos/scientist/validation/source_admission_state.py']:
 iface+='- `'+rel+'` @ `'+sha((O/rel).read_bytes())+'`\n'
(D/'INTERFACE-r2.md').write_text(iface)
# Build one explicit normal Git-compatible patch and root-composition manifest.
rows=[];parts=[]
for p in sorted(x for x in O.rglob('*')if x.is_file()):
 rel=str(p.relative_to(O));base=subprocess.run(['git','show',BASE+':'+rel],cwd=R,capture_output=True);before=base.stdout if base.returncode==0 else None
 current=R/rel;assert not current.is_symlink();assert (current.read_bytes()if current.is_file()else None)==before,rel
 data=p.read_bytes();assert data!=before,rel
 if p.suffix=='.json':json.loads(data)
 if p.suffix=='.toml':tomllib.loads(data.decode())
 if p.suffix=='.py':ast.parse(data)
 rows.append({'path':rel,'pre_sha256':sha(before)if before is not None else None,'post_sha256':sha(data),'postimage_file':str(p.relative_to(R)),'bytes':len(data),'category':'mechanism'if '/src/'in rel and p.suffix=='.py' else 'mandatory_companion'})
 parts.append('diff --git a/'+rel+' b/'+rel+'\n')
 if before is None:parts.append('new file mode 100644\n')
 parts.append(''.join(difflib.unified_diff((before or b'').decode().splitlines(keepends=True),data.decode().splitlines(keepends=True),fromfile='a/'+rel if before is not None else '/dev/null',tofile='b/'+rel)))
patch=D/'source.patch';patch.write_text(''.join(parts));check=subprocess.run(['git','apply','--check',str(patch)],cwd=R,capture_output=True);(D/'apply-check.stdout').write_bytes(check.stdout);(D/'apply-check.stderr').write_bytes(check.stderr);assert check.returncode==0,check.stderr.decode()
test=ast.parse((O/'policy-engine/tests/unit/scientist/validation/test_source_admission_state.py').read_bytes());defs=[n.name for n in test.body if isinstance(n,ast.FunctionDef)and n.name.startswith('test_')]
manifest={'schema':'policyos.e02.sparse_author_proposal.v1','status':'FROZEN_SOURCE_PROPOSAL_PENDING_INDEPENDENT_REVIEW_RUNTIME_UNRUN','source_base_commit':BASE,'source_base_tree':git('rev-parse',BASE+'^{tree}').decode().strip(),'observed_root_head':git('rev-parse','HEAD').decode().strip(),'observed_root_tree':git('rev-parse','HEAD^{tree}').decode().strip(),'branch':git('symbolic-ref','--short','HEAD').decode().strip(),'files':rows,'full_patch':{'path':str(patch.relative_to(R)),'sha256':sha(patch.read_bytes()),'bytes':patch.stat().st_size},'interface':{'path':str((D/'INTERFACE-r2.md').relative_to(R)),'sha256':sha((D/'INTERFACE-r2.md').read_bytes())},'complete_sparse_regular_file_denominator':len(rows),'python_files':len(py_files),'test_definition_denominator':len(defs),'test_definitions':defs,'runtime_collection':'UNRUN','removal_controls':len(portable),'control_index_sha256':sha((D/'controls/index.json').read_bytes()),'static_receipt':{'path':STATIC,'sha256':sha((O/STATIC).read_bytes())},'static':{'AST':'PASS all final Python/control mutants','Ruff':'PASS six exact canonical stdin filenames/config; physical Root check UNRUN','TOML':'parse PASS; canonical typed release validator UNRUN','patch_apply_check':'PASS','product_imports':'UNRUN','tests':'UNRUN','architecture_public_generated':'UNRUN Root canonical writer companions'},'implementation_path':'reuse actual CAS selected/raw/tenant owner + typed snapshot field/role intake + existing validity fence; extend existing owner/DTOs; consolidate root-reachable fact/event/epoch/index; build only one narrow private immutable index part after inspecting named existing alternatives','known_class_policy':'Same C99/C105 source authority and root-atomicity classes; widened entire quantity once, not per-site ladder. Actual trusted producer/factory/served bridge remains C106 internal implementation, never external blocker or implied acceptance.','required_root_companions':['Canonical public-surface inventory/MD/source signature owner review using registered generator; no manual generated edits','Schema/FQN and actual C106 DTO/OpenAPI/client/dashboard consumers after real bridge composition','Release public_surface_inventory_reviewed remains false until actual owner review','Canonical plan/journal/original occurrence routes update; preserve all historical closures/denominators'],'unresolved_boundaries':['Actual installed Runtime source issuer and real captured SQL producer are C106, not supplied by arbitrary private callbacks/DTOs','Real Foundry basis and fresh default/exact/cache API/packet migration are C106; no production capability claim','Store positive tests explicitly seed private state, not actual SQL/factory proof','First POSIX local FileSystemCAS/storage/child profile must be measured alone; NFS/distributed durability not claimed','Core flat facade is not modified; direct canonical decision_validity module is the declared API. Attempted flat facade draft/static diagnostics retained, not labelled clean/inherited under P41'],'canonical_source_index_refs_mutated_by_author':False,'G_acceptance':False,'code_acceptance':False,'closure_ids':[]}
p=D/'manifest.json';assert not p.exists();p.write_text(json.dumps(manifest,indent=2)+'\n');read=json.loads(p.read_bytes());assert read['files']==rows
print(json.dumps({'manifest':str(p.relative_to(R)),'manifest_sha256':sha(p.read_bytes()),'paths':len(rows),'mechanism_paths':sum(x['category']=='mechanism'for x in rows),'python_files':len(py_files),'test_definitions':len(defs),'controls':len(portable),'patch_sha256':sha(patch.read_bytes()),'patch_bytes':patch.stat().st_size,'interface_sha256':sha((D/'INTERFACE-r2.md').read_bytes()),'runtime':'UNRUN'}))
