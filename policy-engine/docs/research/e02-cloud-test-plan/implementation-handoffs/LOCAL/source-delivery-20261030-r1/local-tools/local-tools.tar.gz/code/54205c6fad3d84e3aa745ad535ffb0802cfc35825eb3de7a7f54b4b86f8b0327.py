from pathlib import Path
import subprocess,json
R=Path.cwd();O=R/'LOCAL/raw/e02-execution-20261027/repairs/C25-r2';P=O/'policy-engine'
f=P/'src/polisyos/ddm/integration/model_registry.py';s=f.read_text();s=s.replace('None if degradation_event is None else _digest_model(degradation_event)','None if degradation_event is None else _degradation_digest(degradation_event)');s=s.replace('''        if source.degradation_event != degradation_event:
            reasons.append("window_source_degradation_mismatch")''','''        if ((source.degradation_event is None) != (degradation_event is None)
                or (source.degradation_event is not None and degradation_event is not None
                    and _degradation_digest(source.degradation_event) != _degradation_digest(degradation_event))):
            reasons.append("window_source_degradation_mismatch")''');s+='''\n\ndef _degradation_digest(event: PerformanceDegradationEvent) -> str:
    # Readiness enrichment is a derived consumer projection, not a new source fact.
    payload = event.model_dump(mode="json", exclude={"readiness_state", "recommended_action"})
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
''';f.write_text(s)
p='src/polisyos/ddm/integration/model_registry_record.schema.json';b=subprocess.check_output(['git','show','8db01b1076e425b7998b05a658776c991b7bd594:policy-engine/'+p]).decode();point='''    "identity_binding": {''';assert b.count(point)==1
addition='''    "applicability_binding": {
      "type": ["object", "null"],
      "additionalProperties": false,
      "required": [
        "detector_id", "calibration_id", "stationarity_regime_id", "report_digest",
        "shift_event_digests", "metric_budget_digest"
      ],
      "properties": {
        "detector_id": { "type": "string", "minLength": 1 },
        "calibration_id": { "type": "string", "minLength": 1 },
        "stationarity_regime_id": { "type": "string", "minLength": 1 },
        "report_digest": { "type": "string", "pattern": "^[0-9a-f]{64}$" },
        "shift_event_digests": {
          "type": "array", "items": { "type": "string", "pattern": "^[0-9a-f]{64}$" }
        },
        "degradation_event_digest": { "type": ["string", "null"] },
        "metric_budget_digest": { "type": "string", "pattern": "^[0-9a-f]{64}$" },
        "last_shift_event_id": { "type": ["string", "null"] },
        "last_degradation_event_id": { "type": ["string", "null"] },
        "observation_binding": {
          "type": ["object", "null"], "additionalProperties": false,
          "required": [
            "source_id", "profile", "payload_sha256", "observed_from", "observed_through"
          ],
          "properties": {
            "source_id": { "type": "string" },
            "profile": { "const": "finite_replay" },
            "payload_sha256": { "type": "string", "pattern": "^[0-9a-f]{64}$" },
            "observed_from": { "type": "string", "format": "date-time" },
            "observed_through": { "type": "string", "format": "date-time" },
            "completeness_provenance": { "const": "recomputed" },
            "authority_scope": { "const": "finite_replay_only" }
          }
        }
      }
    },
''';d=P/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_text(b.replace(point,addition+point));json.loads(d.read_text())
p='src/polisyos/ddm/README.md';base=subprocess.check_output(['git','show','8db01b1076e425b7998b05a658776c991b7bd594:policy-engine/'+p]).decode();(P/p).write_text(base+'''
## Source-bound observation replay

`calibration/observations.py` resolves a configured finite replay source and
recomputes its whole trigger/event/budget basis independently of consumer lists.
Its strict source identity, report digest and explicit observation window remain
separate from effective checking time. `[]` alone is a consumer assertion; it
cannot establish observed emptiness. Serialized registry digests do not restore
checker authority. Rebinding resolves the configured source again, and retained
private evidence detects changed or unavailable source bytes before consumption.

Finite replay proves only a bounded software protocol. Its current candidate
validity never grants production promotion. The default monitor has no admitted
production observation source and therefore fails closed. Production integration
still needs the actual source owner, its selected stream/window, delivery and
coverage basis, and currentness evidence; this module does not invent them.
''')
p='src/polisyos/ddm/integration/model_registry_gate.md';base=subprocess.check_output(['git','show','8db01b1076e425b7998b05a658776c991b7bd594:policy-engine/'+p]).decode();(P/p).write_text(base+'''
## Observation and applicability boundary

A caller trigger list, including `[]`, is diagnostic input and cannot prove
observation completeness. The private checker requires a separately configured
source. The concrete `FiniteCalibrationObservationSource` enumerates a selected
finite replay file, binds all invalidation entries and consumed shift/degradation
and budget inputs, and reports `completeness_provenance=recomputed` only relative
to that finite source. Source selection is configured out of band; a public
registry payload cannot select the resolver or its path. Changes to source bytes
invalidate retained evidence; rebind reopens the actual source rather than
re-signing public digests or a consumer list. Last-event labels must agree with
the actual consumed basis. Immutable tuples and detached private digests prevent
in-place projection mutation from changing both sides of a comparison.

The finite source has `authority_scope=finite_replay_only`. A valid candidate
projection from it remains visible, but the final gate returns
`finite_replay_observation_not_production_authority`. No production observation
owner is supplied by this change. Until a legitimate owner resolves coverage,
selection and currentness, default production eligibility remains
`not_established`. This limitation preserves the LA-055 policy table; its
conditional state/signoff/veto logic is tested separately from the missing
observation precondition and cannot be used as a production grant.
''')
p='release-fragments/unreleased/e02-ddm-observation-source.md';d=P/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_text('''surface_classification: public_experimental

DDM registry admission no longer treats a supplied empty invalidation list as
observed emptiness or reconstructs consumed-source authority from mutable public
digests. Exact source-backed finite replay remains inspectable but cannot grant
production promotion. Applications that depended on raw list admission must
provide a legitimate observation owner; none is invented by this change.
Existing registry payloads remain readable, with missing basis failing closed.
Migration owner: E02 root coordinator. Shared public inventory/reference updates
compose at that coordinator after source review and native verification.
''')
