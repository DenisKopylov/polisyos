from pathlib import Path
import json
R=Path.cwd();P=R/'LOCAL/raw/e02-execution-20261027/repairs/C32-r5';O=R/'LOCAL/raw/e02-execution-20261027/repairs/C32-r6';O.mkdir(exist_ok=True)
for row in json.loads((P/'manifest.json').read_text())['files']:
 p=O/row['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/row['postimage_path']).read_bytes())
for name in ['README.md','prepare_native.py','freeze.py','static_check.py','affected-nodes.json','fixture-constructor-migration.json','constructor-census.json','documentation-preimage-overrides.json']:
 s=(P/name).read_text().replace("repairs/C32-r5'","repairs/C32-r6'").replace("case = 'c32-r5-'","case = 'c32-r6-'")
 (O/name).write_text(s)
p=O/'policy-engine/src/polisyos/data_forge/domains/catalog/knowledge/store.py';s=p.read_text();old='''        except (OSError, RuntimeError) as exc:
            raise CatalogReadSourceError(
                "catalog_read_source_unavailable", type(exc).__name__
            ) from exc''';assert s.count(old)==1;s=s.replace(old,old.replace('(OSError, RuntimeError)','(OSError, RuntimeError, ValueError)'));p.write_text(s)
p=O/'policy-engine/src/polisyos/runtime/quality/acquisition_planner.py';s=p.read_text();needle='\n\nACQUISITION_FAMILY_DENOMINATOR = (';assert s.count(needle)==1;s=s.replace(needle,'''

class _FabricCaptureError(Exception):
    """Carry an internal capture error to the gateway's sole failure classifier."""

    def __init__(self, failure: Exception) -> None:
        self.failure = failure
        super().__init__(str(failure))
'''+needle);old='''        except (
            catalog_read_api.CatalogReadSourceError,
            catalog_read_api.BaselineMutationError,
            catalog_read_api.OverlayAdmissionError,
            SubstrateRegistryError,
        ) as exc:
            raise AcquisitionPlannerBindingError(str(exc), source_refusal_code=exc.code) from exc''';new='''        except Exception as exc:
            failure = exc.failure if isinstance(exc, _FabricCaptureError) else exc
            if isinstance(
                failure,
                (
                    catalog_read_api.CatalogReadSourceError,
                    catalog_read_api.BaselineMutationError,
                    catalog_read_api.OverlayAdmissionError,
                    SubstrateRegistryError,
                ),
            ):
                raise AcquisitionPlannerBindingError(
                    str(failure), source_refusal_code=failure.code
                ) from failure
            if isinstance(failure, AcquisitionPlannerBindingError) and (
                failure.source_refusal_code is not None
            ):
                if failure is exc:
                    raise
                raise failure from exc
            if isinstance(exc, _FabricCaptureError):
                _LOGGER.warning("Fabric fetch capture refused: %s", failure)
                return None
            raise''';assert s.count(old)==1;s=s.replace(old,new);old='''                    _LOGGER.warning("Fabric fetch capture refused: %s", exc)
                    return None''';new='''                    # Preserve every failure here. The public owner boundary
                    # alone decides typed source refusal versus the existing
                    # optional non-source capture fallback.
                    raise _FabricCaptureError(exc) from exc''';assert s.count(old)==1;s=s.replace(old,new);p.write_text(s)
p=O/'policy-engine/tests/unit/runtime/quality/test_catalog_acquisition_source_binding.py';s=p.read_text().replace('''from polisyos.data_forge.read_api import catalog as catalog_api''','''from polisyos.core.artifacts import FileSystemCAS
from polisyos.data_forge.read_api import catalog as catalog_api''');needle='''@pytest.mark.parametrize(
    ("fault", "expected_code"),''';assert s.count(needle)==1;s=s.replace(needle,'''@pytest.mark.parametrize("capture_mode", ["resolve_only", "persisted_capture"])
'''+needle);s=s.replace('''    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, fault: str, expected_code: str
) -> None:
    """A real file-state''','''    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, fault: str, expected_code: str,
    capture_mode: str,
) -> None:
    """A real file-state''');needle='''    spec, record = _compiled_request()
    with _actual_graphs(tmp_path) as (owner, foreign, source, graph, _other, _overlay):
        original_resolve''';replace='''    spec, record = _compiled_request()
    if capture_mode == "persisted_capture":
        spec["metadata"]["fabric_capture_mode"] = "persisted_payload"
    with _actual_graphs(tmp_path) as (owner, foreign, source, graph, _other, _overlay):
        original_resolve''';assert s.count(needle)==1;s=s.replace(needle,replace);needle='''        monkeypatch.setattr(RetrievalService, "resolve", disturb_only_the_actual_read)
        gateway = RealAcquisitionOwnerGateway(
            repo_root=source.repo_root,''';replace='''        monkeypatch.setattr(RetrievalService, "resolve", disturb_only_the_actual_read)
        gateway = RealAcquisitionOwnerGateway(
            repo_root=source.repo_root,
            artifact_store=FileSystemCAS(tmp_path / "capture-cas"),''';assert s.count(needle)==1;s=s.replace(needle,replace);p.write_text(s)
p=O/'policy-engine/tests/unit/data_forge/domains/catalog/knowledge/test_variable_availability.py';s=p.read_text()+'''\n\n@pytest.mark.parametrize("entry", ["identity", "initial_store"])
def test_empty_initial_native_identity_is_typed_error_not_absent_data(
    tmp_path: Path, entry: str
) -> None:
    database = tmp_path / "empty.duckdb"
    database.write_bytes(b"")
    with pytest.raises(CatalogSelectionError) as failure:
        if entry == "identity":
            DatasetCatalogStore.identify_read_sources(database)
        else:
            DatasetCatalogStore(database, database.parent)
    assert failure.value.code == "catalog_read_source_unavailable"
    assert isinstance(failure.value.__cause__, ValueError)
''';p.write_text(s)
print({'sparse_paths':len([p for p in (O/'policy-engine').rglob('*') if p.is_file()]),'runtime':'UNRUN'})
