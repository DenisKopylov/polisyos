from pathlib import Path
p=Path('LOCAL/raw/e02-execution-20261027/repairs/C41-r9-r3-draft/postimages/policy-engine')
f=p/'tests/unit/core/artifacts/test_selected_profile_verification_reader.py';s=f.read_text();needle='''        with monkeypatch.context() as fault:
            fault.setattr(store, "get_bytes", lambda _ref: b"wrong bytes")
            assert selected.verify(ref).ok is False
        assert store.get_bytes(ref) == original(ref)
''';add='''        with monkeypatch.context() as fault:
            fault.setattr(store, "get_bytes", lambda _ref: b"wrong bytes")
            assert selected.verify(ref).ok is False

        def wrapped_cause(cause: Exception):
            def fail(_ref: object) -> bytes:
                raise RuntimeError("selected backend wrapper") from cause
            return fail

        denial = ArtifactOwnershipError("selected owner denied")
        with monkeypatch.context() as fault:
            fault.setattr(store, "get_bytes", wrapped_cause(denial))
            with pytest.raises(ArtifactOwnershipError) as captured:
                selected.verify(ref)
            assert captured.value is denial
        temporarily_unavailable = ArtifactReadOnlyUnavailableError("unavailable")
        with monkeypatch.context() as fault:
            fault.setattr(store, "get_bytes", wrapped_cause(temporarily_unavailable))
            with pytest.raises(RuntimeError) as captured_unavailable:
                selected.verify(ref)
            assert captured_unavailable.value.__cause__ is temporarily_unavailable
        disk_permission = PermissionError("filesystem permission")
        with monkeypatch.context() as fault:
            fault.setattr(store, "get_bytes", wrapped_cause(disk_permission))
            with pytest.raises(PermissionError) as captured_disk:
                selected.verify(ref)
            assert type(captured_disk.value) is PermissionError
            assert captured_disk.value is disk_permission
        assert store.get_bytes(ref) == original(ref)
''';assert s.count(needle)==1;s=s.replace(needle,add);f.write_text(s)
f=p/'tests/integration/runtime_quality/test_joint_interaction_cubic_consumer.py';s=f.read_text();needle='''        # The second selected parent read denies access after the first succeeded.
''';addition='''        # A dependency wrapper must not turn an explicitly caused owner denial
        # into candidate unavailability. A typed unavailable cause remains
        # unavailable, and an ordinary filesystem permission cause remains 503.
        from polisyos.runtime.http.errors import RuntimeDependencyUnavailableError

        execution_ref = ArtifactRef.model_validate(source_leaf["n5_execution_ref"])
        wrapped_calls: list[str] = []

        def wrapped_raw(target: ArtifactRef, cause: Exception):
            def read(ref: Any, *args: Any, **kwargs: Any) -> bytes:
                if (
                    getattr(ref, "artifact_id", None) == target.artifact_id
                    and getattr(ref, "manifest_profile_sha256", None)
                    == target.manifest_profile_sha256
                ):
                    wrapped_calls.append(str(target.artifact_id))
                    raise RuntimeDependencyUnavailableError("synthetic-cas") from cause
                return original_raw_manifest(ref, *args, **kwargs)
            return read

        for target in (parent_ref, execution_ref):
            wrapped_calls.clear()
            with monkeypatch.context() as fault:
                fault.setattr(
                    store,
                    "get_raw_manifest_bytes",
                    wrapped_raw(target, ArtifactOwnershipError("owner denies selected view")),
                )
                wrapped_denial = client.get(f"/api/v1/runs/{run_id}")
            assert wrapped_calls
            assert wrapped_denial.status_code == 403, wrapped_denial.text
            assert "n5_observations" not in json.dumps(wrapped_denial.json())

            wrapped_calls.clear()
            with monkeypatch.context() as fault:
                fault.setattr(
                    store,
                    "get_raw_manifest_bytes",
                    wrapped_raw(target, PermissionError("filesystem refuses selected read")),
                )
                wrapped_permission = client.get(f"/api/v1/runs/{run_id}")
            assert wrapped_calls
            assert wrapped_permission.status_code == 503, wrapped_permission.text
            assert "n5_observations" not in json.dumps(wrapped_permission.json())

            wrapped_calls.clear()
            with monkeypatch.context() as fault:
                fault.setattr(
                    store,
                    "get_raw_manifest_bytes",
                    wrapped_raw(target, ArtifactReadOnlyUnavailableError("reader unavailable")),
                )
                wrapped_unavailable = client.get(f"/api/v1/runs/{run_id}")
            assert wrapped_calls
            if target == parent_ref:
                checked_parent_limitation(
                    wrapped_unavailable, "generic_joint_parent_result_unavailable"
                )
            else:
                assert wrapped_unavailable.status_code == 200, wrapped_unavailable.text
                wrapped_rows = wrapped_unavailable.json()["run"]["generic_cycle_simulation"][
                    "n5_observations"
                ]
                assert {(row["node_ref"], row["candidate_id"]) for row in wrapped_rows} == before_keys
                wrapped_leaf = next(
                    row
                    for row in wrapped_rows
                    if row["node_ref"] == source_leaf["node_ref"]
                    and row["candidate_id"] == source_leaf["candidate_id"]
                )
                assert wrapped_leaf["n5_owner_join_status"] == "unavailable"
                assert "n5_execution_request_provenance_not_established" in wrapped_leaf[
                    "authority_blockers"
                ]
                assert any(
                    row["node_ref"] != source_leaf["node_ref"]
                    and row["n5_owner_join_status"] == "resolved"
                    for row in wrapped_rows
                )

''';assert s.count(needle)==1;s=s.replace(needle,addition+needle);f.write_text(s)
