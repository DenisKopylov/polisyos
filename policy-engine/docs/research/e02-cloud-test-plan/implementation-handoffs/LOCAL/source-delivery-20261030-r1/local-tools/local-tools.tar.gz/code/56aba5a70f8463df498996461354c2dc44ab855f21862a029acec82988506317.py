from pathlib import Path
base=Path('LOCAL/raw/e02-execution-20261027/repairs/C41-r5/postimages/policy-engine/src/polisyos')
p=base/'runtime/quality/generation_cycle.py';s=p.read_text()
old='''        "n5_execution_request_provenance_not_established",
    }
)
# Exhaustive typed projection partition.'''
new='''        "n5_execution_request_provenance_not_established",
        "n4_source_candidates_are_alternatives_not_authored_compound_design",
        "child_to_parent_refinement_rule_not_established",
    }
)
# Exhaustive typed projection partition.'''
assert old in s;s=s.replace(old,new,1)
marker='''\ndef _generic_n5_canonical_port_issue(
'''
insert='''
@dataclass(frozen=True, slots=True)
class _ParentJointCandidateN8Input:
    """A hypothetical source-member bundle for candidate-only N8 analysis."""

    candidate_id: str
    intervention_atoms: tuple[Any, ...]


def _consume_parent_joint_candidate_n8(
    *,
    candidate_id: str,
    request: JointSimulationRequest,
    result_ref: CASArtifactRef,
    result: JointSimulationResult,
    problem: DesignProblem,
    artifact_store: ArtifactStore,
) -> ValuePortObservation:
    """Consume the persisted N5 body without asserting an authored design or authority."""
    if (
        type(request) is not JointSimulationRequest
        or request.candidate_intent != "n4_unique_parent_source_members.v1"
        or request.member_basis != "hypothetical_all_unique_n4_source_members"
        or request.source_candidate_relationship != "alternatives"
        or request.composition_status != "not_established"
        or request.child_to_parent_refinement_status != "not_established"
    ):
        raise GenerationCycleError("parent_joint_candidate_n8_intent_not_established")
    candidate = _ParentJointCandidateN8Input(
        candidate_id=candidate_id,
        intervention_atoms=tuple(request.intervention_atoms),
    )
    _, result_blockers = _joint_simulation_port_outcome(result)
    limitations = (
        "n5_execution_request_provenance_not_established",
        "n4_source_candidates_are_alternatives_not_authored_compound_design",
        "child_to_parent_refinement_rule_not_established",
    )
    simulation = SimulationPortObservation(
        candidate_id=candidate_id,
        status="joint_simulated",
        simulation_ref=result.receipt.payload_hash,
        simulation_result_ref=result_ref,
        world_model_record=request.world_model_record,
        k_world_ref_before=request.world_model_record.content_hash,
        k_world_ref_after=request.world_model_record.content_hash,
        authority_blockers=tuple(dict.fromkeys((*result_blockers, *limitations))),
    )
    observation = _conditional_simulation_value_observation(
        candidate=candidate,
        simulation=simulation,
        problem=problem,
        artifact_store=artifact_store,
    )
    if observation is None:
        raise GenerationCycleError("parent_joint_candidate_n8_not_established")
    return observation

'''
assert marker in s;s=s.replace(marker,'\n'+insert+marker,1);p.write_text(s)
p=base/'core/contracts/runtime.py';s=p.read_text();pos=s.index('class RunCandidateSimulationN5Observation(');a=s[:pos];b=s[pos:]
old='''    n8_authority_blockers: tuple[str, ...] = ()
    n8_joint_request_content_hash:'''
new='''    n8_authority_blockers: tuple[str, ...] = ()
    n8_candidate_value_ref: str | None = Field(
        default=None, exclude_if=lambda value: value is None
    )
    n8_candidate_decision_grade: Literal["low"] | None = Field(
        default=None, exclude_if=lambda value: value is None
    )
    n8_joint_request_content_hash:'''
assert old in b;b=b.replace(old,new,1)
old='''        elif self.n8_status != "value_pending_n8":
            raise ValueError("run_n8_joint_scope_must_remain_pending")
        elif self.n8_joint_scope_status == "not_established":'''
new='''        elif self.n8_status not in {"value_pending_n8", "value_conditional"}:
            raise ValueError("run_n8_joint_scope_must_remain_candidate_only")
        elif self.n8_joint_scope_status == "not_established":'''
assert old in b;b=b.replace(old,new,1)
old='''        candidate_selection_fields_present = any(
'''
new='''        if self.n8_candidate_value_ref is not None or self.n8_candidate_decision_grade is not None:
            if (
                self.n8_status != "value_conditional"
                or self.n8_candidate_decision_grade != "low"
                or self.simulation_result_ref is None
                or self.n8_candidate_value_ref != str(self.simulation_result_ref.artifact_id)
                or self.n8_joint_scope_status != "not_established"
                or not {
                    "n5_execution_request_provenance_not_established",
                    "n4_source_candidates_are_alternatives_not_authored_compound_design",
                    "child_to_parent_refinement_rule_not_established",
                }.issubset(self.n8_authority_blockers)
            ):
                raise ValueError("run_n8_joint_candidate_conditional_binding_invalid")
        if self.n8_status == "value_conditional" and self.n8_joint_scope_status is not None and (
            self.n8_candidate_value_ref is None or self.n8_candidate_decision_grade is None
        ):
            raise ValueError("run_n8_joint_candidate_conditional_value_missing")
        candidate_selection_fields_present = any(
'''
assert old in b;b=b.replace(old,new,1)
b=b.replace('''            or self.n8_status != "value_pending_n8"
            or self.n8_candidate_member_basis is None''','''            or self.n8_status not in {"value_pending_n8", "value_conditional"}
            or self.n8_candidate_member_basis is None''',1)
s=a+b;pos=s.index('class RunGenericCycleSimulationProjection(');a=s[:pos];b=s[pos:]
b=b.replace('''                    or self.joint_parent_observations[0].n8_status != "value_pending_n8"
''','''                    or self.joint_parent_observations[0].n8_status
                    not in {"value_pending_n8", "value_conditional"}
''',1)
p.write_text(a+b)
p=base/'runtime/http/routes/runs.py';s=p.read_text();pos=s.index('def _generic_cycle_simulation_projection(');a=s[:pos];b=s[pos:]
b=b.replace('''        _joint_simulation_port_outcome,
        load_joint_simulation_result,''','''        _consume_parent_joint_candidate_n8,
        _joint_simulation_port_outcome,
        load_joint_simulation_result,''',1)
old='''            parent_row = RunCandidateSimulationN5Observation(
'''
new='''            if parent_node.joint_simulation_request is None:
                raise ValueError("generic_joint_parent_request_missing")
            candidate_value = _consume_parent_joint_candidate_n8(
                candidate_id="joint-candidate:" + parent_node.joint_candidate_selection.content_hash,
                request=parent_node.joint_simulation_request,
                result_ref=parent_result_ref,
                result=parent_result,
                problem=compiled.design_problem,
                artifact_store=store,
            )
            if candidate_value.status != "value_conditional":
                raise ValueError("generic_joint_parent_n8_candidate_not_established")
            parent_row = RunCandidateSimulationN5Observation(
'''
assert old in b;b=b.replace(old,new,1)
old='''                n8_status="value_pending_n8",
                n8_joint_scope_status="not_established",
                n8_joint_scope_limitation_code=scope_limitation,
                n8_authority_blockers=(scope_limitation,),
                **_n5_interaction_scope_fields(parent_result),
                **selection_fields,'''
new='''                n8_status=candidate_value.status,
                n8_candidate_value_ref=candidate_value.value_ref,
                n8_candidate_decision_grade=candidate_value.decision_grade,
                n8_numeric_interaction=candidate_value.numeric_interaction,
                n8_numeric_interaction_basis=candidate_value.numeric_interaction_basis,
                n8_interaction_sampling_status=candidate_value.interaction_sampling_status,
                n8_joint_scope_status="not_established",
                n8_joint_scope_limitation_code=scope_limitation,
                n8_authority_blockers=tuple(
                    dict.fromkeys((*candidate_value.authority_blockers, scope_limitation))
                ),
                **_n5_interaction_scope_fields(parent_result),
                **selection_fields,'''
assert old in b;b=b.replace(old,new,1);p.write_text(a+b)
# The served case observes a real conditional N8 read of the same persisted
# result, and explicitly rejects any inferred policy or publication authority.
p=Path('LOCAL/raw/e02-execution-20261027/repairs/C41-r5/postimages/policy-engine/tests/integration/runtime_quality/test_joint_interaction_cubic_consumer.py');s=p.read_text()
s=s.replace('''    assert parent["n8_status"] == "value_pending_n8"
    # N8 has not consumed the joint candidate yet; the evidence is exposed as
    # a bounded N5 result while the missing joint scope remains explicit.
    assert parent["n8_numeric_interaction_basis"] is None''','''    assert parent["n8_status"] == "value_conditional"
    assert parent["n8_candidate_decision_grade"] == "low"
    assert parent["n8_candidate_value_ref"] == parent["simulation_result_ref"]["artifact_id"]
    assert parent["n8_numeric_interaction_basis"] == "finite_checked_model_point_estimate_only"
    assert "n4_source_candidates_are_alternatives_not_authored_compound_design" in parent[
        "n8_authority_blockers"
    ]
    assert "n5_execution_request_provenance_not_established" in parent["n8_authority_blockers"]''',1)
p.write_text(s)
