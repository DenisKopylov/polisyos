"""Bind reviewed C05 templates at an explicit clean Root checkpoint; do not run or install."""
from pathlib import Path
import argparse,configparser,hashlib,json,re,subprocess
R=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos');P=R/'policy-engine';O=Path(__file__).resolve().parent
D=P/'docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R).decode().strip()
def require(ok,why):
 if not ok:raise RuntimeError(why)
def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('--source-head',required=True);a.add_argument('--source-tree',required=True);a.add_argument('--revision',required=True);args=a.parse_args()
 require(re.fullmatch('[a-f0-9]{40}',args.source_head) and re.fullmatch('[a-f0-9]{40}',args.source_tree),'full source head/tree required')
 require(re.fullmatch('r[1-9][0-9]*',args.revision),'append-only revision required')
 require(git('symbolic-ref','--short','HEAD')=='codex/e02-unified-local-20261009','wrong Root author branch')
 require(git('rev-parse','HEAD')==args.source_head and git('rev-parse','HEAD^{tree}')==args.source_tree,'explicit checkpoint mismatch')
 require(not git('status','--porcelain=v1','--untracked-files=no'),'finish generator WIP and clean Root checkpoint first')
 basis=json.loads((O/'source-basis.json').read_text());profile=json.loads((O/'backend-profile.json').read_text())
 for row in [*basis['canonical_readset'],*basis['retained_harness']]:require(sha(R/row['path'])==row['sha256'],('changed reviewed source/helper; prepare a new reviewed basis, no waiver',row['path']))
 for row in [profile['venv_cfg'],profile['pytest_ini'],profile['pyproject'],profile['lock'],*profile['pth_files']]:require(sha(R/row['path'])==row['sha256'],('changed actual native profile',row['path']))
 site=next((P/'.venv/lib').glob('python*/site-packages'));require(sorted(str(v.relative_to(R)) for v in site.glob('*.pth'))==sorted(x['path'] for x in profile['pth_files']),'startup pth set changed')
 expected={}
 for row in profile['pytest11']:
  require(sha(R/row['entry_points']['path'])==row['entry_points']['sha256'] and sha(R/row['metadata']['path'])==row['metadata']['sha256'],'default pytest plugin metadata changed')
  expected[row['entry_points']['path']]=row['entrypoints']
 entries=sorted([*site.glob('*.dist-info/entry_points.txt'),*site.glob('*.egg-info/entry_points.txt')]);actual={}
 for entry in entries:
  cfg=configparser.ConfigParser();cfg.read_string(entry.read_text())
  if 'pytest11' in cfg:actual[str(entry.relative_to(R))]=dict(cfg['pytest11'])
 require(len(entries)==profile['entrypoint_file_denominator'] and actual==expected,'default autoload declaration census changed')
 out=O/('bound-'+args.revision);require(not out.exists(),'append-only binding already exists');out.mkdir()
 receipts=[]
 for template in sorted(O.glob('template-*.json')):
  plan=json.loads(template.read_text());stem=template.name.removeprefix('template-').removesuffix('.json');case=stem+'-'+args.revision+'-20261028';name='plan-'+case+'.json'
  require(not (D/name).exists() and not (D/case).exists(),('D name already exists',case))
  plan['case_id']=case;plan['source_head']=args.source_head;plan['source_tree']=args.source_tree;plan['extra_env']['POLISYOS_CONTROL_SQLITE_PATH']=str(D/case/'control.sqlite3')
  plan['binding_note']='Actual clean Root checkpoint; installed/executed only after separate fresh Root source/resource/ownership-lease admission. Removal cases additionally require exact declared mutant source frame and prior passing baseline.'
  path=out/name;path.write_text(json.dumps(plan,indent=2)+'\n');receipts.append({'prepared_plan':str(path),'D_destination':str(D/name),'case_directory':str(D/case),'sha256':sha(path),'case_kind':plan['case_kind']})
 delta=git('diff','--name-status',basis['reviewed_checkpoint_head'],args.source_head,'--','policy-engine').splitlines()
 receipt={'source_head':args.source_head,'source_tree':args.source_tree,'reviewed_base_head':basis['reviewed_checkpoint_head'],'complete_product_delta_from_reviewed_base':delta,'delta_qualification':'All explicitly pinned C05/source/config/test/helper/profile bytes unchanged. Remaining committed tree changes are disclosed, not inferred neutral; Root reviews actual inputs/transitive concerns before native launch.','plans':receipts,'runtime':'UNRUN; no D installation, product import, environment creation or execution','source_lease':'D live ownership/source frame cannot change during a case.'}
 (out/'binding.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'binding':str(out/'binding.json'),'sha256':sha(out/'binding.json'),'plans':len(receipts),'runtime':'UNRUN'}))
if __name__=='__main__':main()
