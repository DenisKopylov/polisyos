"""Check one RAW test proposal without product imports or test execution."""
from pathlib import Path
import ast
import collections
import hashlib
import json

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
PACKET = Path(__file__).absolute().parent
reads = []

def read(path):
    try:
        data = path.read_bytes()
    except OSError as error:
        reads.append({"path": str(path), "status": "failed", "error_type": type(error).__name__})
        raise
    reads.append({"path": str(path), "status": "success", "bytes": len(data),
                  "sha256": hashlib.sha256(data).hexdigest()})
    return data

report = {"schema": "e02.v3-owner-exhaustion-static-readback.v1", "status": "ERROR",
          "runtime": "UNRUN", "scope": "one pinned test preimage/postimage and five proposed selectors",
          "unresolved_by_construction": ["runtime class/import identity", "native/DB execution",
              "typed receipt/model behavior", "future test outcomes", "all unselected source files"]}
try:
    pins = json.loads(read(PACKET / "postimage-pins.json"))
    assert len(pins) == 1
    pin = pins[0]
    before = read(ROOT / pin["path"])
    after = read(PACKET / "postimages" / pin["path"])
    assert hashlib.sha256(before).hexdigest() == pin["pre_sha256"]
    assert hashlib.sha256(after).hexdigest() == pin["post_sha256"]
    target = "test_fresh_owner_exhaustion_between_real_seeds_stops_before_second_call"
    one = lambda data: next(n for n in ast.parse(data).body
        if isinstance(n, ast.FunctionDef) and n.name == target)
    count = lambda data: collections.Counter(ast.dump(n, include_attributes=False)
        for n in ast.walk(one(data)) if isinstance(n, ast.Assert))
    assert not count(before) - count(after)
    proposal = json.loads(read(PACKET / "proposed-verification.json"))
    for selector in proposal["selectors"]:
        relative, name = selector.split("::")
        module = read(ROOT / "policy-engine" / relative)
        assert any(isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name
                   for n in ast.parse(module).body)
    report.update(status="STATIC_CHECKS_ONLY", original_assertions_retained=True,
                  original_assertions=sum(count(before).values()),
                  post_assertions=sum(count(after).values()),
                  complete_module_AST_selectors=proposal["selectors"])
except Exception as error:
    report["error_type"] = type(error).__name__
finally:
    report["actual_reads"] = reads
    report["exclusions"] = ["no production import", "no test or numerical run", "no DB query"]
    print(json.dumps(report, indent=2))
if report["status"] == "ERROR":
    raise SystemExit(1)
