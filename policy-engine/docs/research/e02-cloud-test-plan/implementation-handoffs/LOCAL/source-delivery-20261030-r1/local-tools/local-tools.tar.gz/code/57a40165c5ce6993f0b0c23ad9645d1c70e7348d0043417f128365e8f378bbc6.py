"""Prepare standalone C89 from immutable C83; RAW writes and Git/blob reads only."""
from pathlib import Path
import difflib,hashlib,json,re,subprocess
R=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
OLD=R/'LOCAL/raw/e02-execution-20261027/repairs/C83-commission-r1'
O=R/'LOCAL/raw/e02-execution-20261027/repairs/C89-commission-r1';O.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=(OLD/'prompt.md').read_text();assert sha(OLD/'prompt.md')=='e294a46fbfcc41abff6f9e5d4f344608af4e4c6b0ab7ad0fb36351565944daab'
text=original.replace('# C83 — standalone C05 native verification and bounded owner repair','# C89 — standalone C05 native verification and bounded owner repair',1)
a=text.index('## Exact portable input and transport first');b=text.index('## Read the actual owners before work',a)
text=text[:a]+'''## Exact local input and measured managed-snapshot delivery

Repository context: `https://github.com/DenisKopylov/polisyos.git`.
Root-verified immutable topic: `codex/e02-composed-progress-20261028-r5`.
Required initial local HEAD: `ea3d65682d76a5d66d514e525ad2212e5a85f669`.
Required complete local tree: `7c5412fddc4ef3e56c859b83d237162e0fd260e7`.
Product: `policy-engine/`.

Use the managed task's existing checkout. Before edits, verify actual `git rev-parse HEAD`, `HEAD^{tree}`, physical product path, working/index state and the40 local source-blob pins below. Correct local HEAD/tree and source pins are sufficient input admission: Root already verified the published r5 topic. No Git fetch, origin, remote readback, download CLI, new clone, push or midrun coordinator acknowledgment is required. A missing origin or Git HTTPS403 is NOT a compute blocker when the pinned local source is valid and the managed final task snapshot/diff is available. If the local source differs, report the exact mismatch; do not repair it by blindly switching, resetting, adding origin or selecting a similarly named branch.

This carrier includes all37 composed C05 paths, the required canonical decoder-source forward fix and C71's typed observational-source/derived-writer context. Earlier r4 at545c was known broken source, not a passing result. Keep the input topic immutable. Stay on the provided managed task branch. Use ordinary local append-only commits when possible or stage exact new/changed files for the managed final snapshot. Never push `work`, `main`, any integration branch or the input topic. An optional ordinary push to a separately authorized task topic may be used only if already available; its absence/failure does not block computation or snapshot delivery. No reset, rebase, force push, historical rewrite, blind branch switch, hook bypass or newly invented transport automation.

**Measured qualification, supplied inline:** C83 ran on this same required EA commit/tree and created one2052-byte `preflight.json`, SHA256 `aaf5d6a21e3323ca6b82efd65cf55798c56c2af38d09c2e390e31ed5192f2750`. It observed Linux6.18.55 x86_64, Python3.14.4, uv0.7.22, pytest9.0.2 and Ruff missing in the provided .venv; cgroup memory17179869184bytes, CPU quota200000/100000(two CPUs), available workspace disk29042180096bytes. Both ordinary Git fetch and `push origin work` returned CONNECT-tunnel403. C83 then stopped because its commission incorrectly made ordinary remote delivery a prerequisite; all C05 tests stayed UNRUN. This is useful environment/transport evidence, not a source or product FAIL and not a timing/RAM guarantee for C89.

Root nevertheless retrieved ALL2052 preflight bytes via the existing managed cloud task diff: received diff2592bytes SHA256 `f69975867522b70c1707f51d3f4977baa84dd7de325fd22a567e0a8ee501990d`, reconstructed candidate tree `a7161ba4af5f98027e4212fc043e35f9503b563f`. Root also verified every one of26 delivered C80 payload files using the same managed channel; that is additional transport evidence only, not C05/C80 correctness. The managed task final diff/snapshot is therefore the DEFAULT result channel. Do not repeat C83's Git-network prerequisite or wait for a worker-side export CLI or acknowledgment that only the coordinator can perform after task completion.

Create a small nonignored preflight record with the actual local source, fresh VM/tool facts, optional Git reachability only if already observed, and C05 status UNRUN. Proceed to supported dependency setup and native work using the measured managed channel. Keep bounded nonignored source/evidence files committed or explicitly staged so the platform's final task snapshot contains their bytes; the coordinator retrieves them with the existing task tools after you finish. You need not invoke or download those coordinator tools. Worker-side local/index readback proves file visibility, NOT that the coordinator has already retrieved a future result. If the platform actually reports snapshot/export unavailability, or files cannot be made visible in its snapshot, state the exact affected paths/bytes and delivery gap; do not invent a successful export or replace artifacts by hashes. Preserve and deliver whatever bytes are available through the managed result.

Do not require or copy any Root `D`, `LOCAL/raw`, source-frame, receipt, environment, DB, credentials or ignored fixture. No CI/workflow, upload encoding fragments, firewall/credential bypass or new automation as a transport workaround. All tests and fixture builders are in the pinned local Git source. Synthetic loopback prices exercise actual accounting behavior, not provider invoices or institutional permission.

''' + text[b:]
old='''Use the actual project Python3.14 baseline and published `uv.lock`. Prefer an existing correct environment. If provisioning is necessary, use the documented frozen workspace/bootstrap or `uv sync --frozen --extra lint --extra test --extra runtime`; inspect actual project optional groups before adding a genuinely required backend. Record exact commands/lock/backend metadata; no source fake modules, dependency stubs, copied environment, narrowed plugin set or pretending missing imports are product semantics. A missing dependency, unsupported interpreter, collection/setup/plugin failure or resource abort is a distinct outcome, not a product-property FAIL or an inherited red without isolation.'''
new='''Use the actual project Python3.14.x baseline and published `uv.lock`; record the actual patch version. Prefer an existing working task environment. C83's Python3.14.4 and pytest9.0.2 were observed, not automatically the C89 profile. Its uv0.7.22 and missing Ruff are setup/tool gaps, NOT product FAILs. In this fresh Cloud VM, normal supported setup is authorized: obtain/use canonical uv0.9.21 when needed, then the documented frozen workspace/bootstrap or `uv sync --frozen --extra lint --extra test --extra runtime`. For example, use an available normal pip install of `uv==0.9.21` or a normal `uv tool run --from uv==0.9.21 uv ...`; use official PyPI or an already supported configured package mirror with bounded attempts. Inspect actual optional groups before adding a genuinely required backend. Do not let an outdated preprovided uv or missing lint extra stop useful work without attempting supported setup within measured RAM/disk/time.

This authorization applies to the fresh task VM only: never reinstall/copy/modify the coordinator's existing working Root environment. Do not copy an environment or source tree. Ordinary supported dependency/network alternatives are allowed without bypassing firewall, proxy policy or credentials, inventing automation, hiding dependency failures or faking source modules. Record complete setup commands/errors and actual selected interpreter/backend/plugin/.pth metadata. A genuinely unavailable package/interpreter/setup/collection/plugin/capacity boundary remains a distinct outcome, not a product-property FAIL or an inherited red without exact isolation.'''
assert text.count(old)==1;text=text.replace(old,new)
needle='''Use a portable process-tree supervisor, kill the entire case group on deadline/RSS/disk breach and keep the actual controller record/units.'''
profile='''### Observe the actual pytest process BEFORE tests

Planned command strings, exported environment declarations, a separate tiny probe PID or a later receipt are insufficient. Retain actual facts from the SAME Python PID that invokes native pytest, first before importing pytest/product and again in `pytest_configure` before collection/test execution. Use a new empty private bytecode prefix for EACH case; launch the actual interpreter with `-B -X pycache_prefix=<that prefix>` and `PYTHONDONTWRITEBYTECODE=1`. The supervisor creates/independently checks the fresh empty directory; the child recomputes its existence/emptiness and checks actual `sys.flags.dont_write_bytecode` and `sys.pycache_prefix`. Retain both observations and PID/PPID. A wrong flag/prefix is a setup/profile error to correct before tests, never a native PASS or product FAIL. Do not infer this property from a file merely declaring the intended values.

A compact allowed read-only launcher skeleton is below. Write it under this task's nonignored evidence directory, set the two C89 case environment paths from the supervisor, and execute it with the SAME pytest arguments/selectors below. Extend only observation for full collect-report outcomes, finite source readsets and resource receipts; preserve normal pytest execution and default plugin autoload. Record no secrets or full ambient environment dump.

```python
import hashlib, json, os, pathlib, sys, time
case = pathlib.Path(os.environ["C89_CASE_DIRECTORY"]).resolve()
prefix = pathlib.Path(os.environ["C89_EMPTY_PYCACHE_PREFIX"]).resolve()
case.mkdir(parents=True, exist_ok=True)
allow = ("PYTHONDONTWRITEBYTECODE", "PYTHONPYCACHEPREFIX", "PYTHONPATH",
         "PYTHONHOME", "PYTEST_ADDOPTS", "PYTEST_PLUGINS",
         "PYTEST_DISABLE_PLUGIN_AUTOLOAD", "VIRTUAL_ENV", "PYTHONNOUSERSITE",
         "JAX_PLATFORMS", "OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS",
         "MKL_NUM_THREADS", "SCIENTIST_TORCH_NUM_THREADS",
         "SCIENTIST_TORCH_NUM_INTEROP_THREADS", "TMPDIR", "XDG_CACHE_HOME")
def save(name, value):
    (case / name).write_text(json.dumps(value, indent=2) + "\\n")
def process_facts():
    actual = sys.pycache_prefix
    return {"pid": os.getpid(), "ppid": os.getppid(), "at_monotonic": time.monotonic(),
            "executable": sys.executable, "python": sys.version,
            "argv": sys.argv, "orig_argv": sys.orig_argv, "cwd": os.getcwd(),
            "flags": {key: getattr(sys.flags, key) for key in
                      ("dont_write_bytecode", "no_user_site", "ignore_environment",
                       "isolated", "safe_path")},
            "xoptions": sys._xoptions, "pycache_prefix": actual,
            "expected_prefix": str(prefix), "prefix_is_directory": prefix.is_dir(),
            "prefix_empty_observed": prefix.is_dir() and not any(prefix.rglob("*")),
            "environment": {key: os.environ.get(key) for key in allow},
            "sys_path": sys.path}
start = process_facts()
save("pytest-process-start.json", start)
assert start["flags"]["dont_write_bytecode"] == 1
assert start["pycache_prefix"] is not None
assert pathlib.Path(start["pycache_prefix"]).resolve() == prefix
assert start["prefix_is_directory"] and start["prefix_empty_observed"]
import pytest
class Observe:
    def pytest_configure(self, config):
        facts = process_facts()
        facts.update({"pytest_module": pytest.__file__, "pytest_version": pytest.__version__,
                      "pytest_invocation_args": list(config.invocation_params.args),
                      "rootpath": str(config.rootpath), "inipath": str(config.inipath),
                      "ini_addopts": config.getini("addopts"),
                      "asyncio_mode": config.getini("asyncio_mode"),
                      "effective_options": {key: getattr(config.option, key, None) for key in
                       ("importmode", "strict_markers", "keyword", "markexpr", "maxfail", "numprocesses")},
                      "actual_plugins": [{"name": name,
                       "module": getattr(plugin, "__name__", type(plugin).__module__),
                       "file": getattr(plugin, "__file__", None)}
                       for name, plugin in config.pluginmanager.list_name_plugin()]})
        save("pytest-configured.json", facts)
        assert facts["pid"] == start["pid"]
        assert facts["flags"]["dont_write_bytecode"] == 1
        assert pathlib.Path(facts["pycache_prefix"]).resolve() == prefix
        assert facts["prefix_empty_observed"]
        assert facts["effective_options"]["importmode"] == "importlib"
        assert facts["effective_options"]["strict_markers"] is True
        assert facts["effective_options"]["keyword"] == ""
        assert facts["effective_options"]["markexpr"] == ""
        assert facts["effective_options"]["maxfail"] == 0
        assert facts["effective_options"]["numprocesses"] in (None, 0)
        assert facts["asyncio_mode"] == "auto"
    def pytest_collection_finish(self, session):
        save("pytest-collection.json", {"pid": os.getpid(),
             "items": [{"nodeid": item.nodeid, "physical_path": str(item.path)}
                       for item in session.items]})
raise SystemExit(pytest.main(sys.argv[1:], plugins=[Observe()]))
```

The sample is a real process/profile observation, not a complete source/network observer. Keep full stdout/stderr/XML for setup or collection errors, including errors before the hook. Add/read the finite loaded src/tests/tools source set at sessionfinish and report the explicit unobserved child/external/unloaded boundaries. Actual collected nodes, plugin manager objects/options and active environment are the inputs to the receipt; do not fabricate a matching profile object after a run. Missing pytest-asyncio/default dependencies are setup issues to provision normally, not a reason to change source's native configuration. This prevents the unobserved-profile mistake encountered in the earlier C80 evidence.

'''
assert text.count(needle)==1;text=text.replace(needle,profile+needle)
text=text.replace('''`<python> -B -m pytest -o cache_dir=<case>/pytest-cache --benchmark-storage=file://<case>/benchmarks --basetemp <case>/basetemp --junitxml=<case>/pytest.xml --tb=short --color=no --maxfail=0 <exact selectors>`''','''`<actual-python> -B -X pycache_prefix=<new-empty-case-prefix> <read-only-launcher.py> -o cache_dir=<case>/pytest-cache --benchmark-storage=file://<case>/benchmarks --basetemp <case>/basetemp --junitxml=<case>/pytest.xml --tb=short --color=no --maxfail=0 <exact selectors>`''')
text=text.replace('''Source-derived expectation:7 cases. Actual collection/results must be read back.''','''Source-derived expectation:7 cases, not a stopping quota. Attempt the complete actual collection of both selectors and read back results.''')
text=text.replace('''Source-derived expectation:30 cases. Then prioritize''','''Source-derived expectation:30 cases, not a stopping quota; preserve the complete actual collected set. Then prioritize''')
old='''**C. Complete full-module deciding wave:** all14 modules in the table below, no selection trimming. Source-derived202 test definitions expand through literal parameter declarations to402 cases; actual collection is UNRUN at commissioning and must be reconciled against full node IDs, fixtures/plugins, XML and outcome counts. The table is an expectation, not a receipt. If grouping modules, record each exact group and run unknown profiles alone; all14 must have complete outcomes. An abort or discrepancy does not authorize silently omitting a module or rewriting expected counts. Capture a complete collection result even on errors.'''
new='''**C. Complete full-module deciding wave:** all14 modules in the table below, no selection trimming. The pinned source has202 test definitions with a literal-parameter estimate of402 cases. This is informational, NOT a quota, upper bound, stopping condition, required literal equality or permission to deselect. Collection is UNRUN at commissioning. Execute the complete actual framework-collected set from all14 physical modules, including genuine cases beyond the estimate; reconcile actual node IDs, fixture/plugin effects, XML and outcomes. Explain discrepancies from the source estimate without falsifying the actual collection or silently editing the baseline count. If grouping modules, record the exact groups and run unknown profiles alone; every module and actual item needs an outcome. A setup/collection/resource abort is a concrete incomplete result, not permission to omit the rest. Retain full collection/error results.'''
assert text.count(old)==1;text=text.replace(old,new)
text=text.replace('''Use a nonignored committed evidence directory such as `policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/c83-c05-native-20261028/`.''','''Use a bounded nonignored evidence directory such as `policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/c89-c05-native-20261028/`, with all new files committed or explicitly staged for the managed snapshot.''')
old='''Commit a compact `report.md`, `receipt.json`, exact commands/selected and collected IDs, final source/base/tree/dirty-state pins, actual backend/default plugin/.pth profile, process/resource controller facts, per-case outcomes and complete compressed deciding outputs. Include each actual output path/length/SHA256 and gzip integrity; the files themselves must be in the delivered commit. Report actual model if established, otherwise `not_established`. Record setup/collection PASS/FAIL/ERROR/SKIP/UNRUN/abort separately; sum exact full module outcomes and explain discrepancies without hiding them. No product or all-backend claim follows from a finite import observer.

Normal hooks/commits and the ordinary transport must deliver the final branch/commit/tree. Read back every changed source, report and compressed deciding file from that delivered commit, and verify actual remote commit/tree where that transport is supported. A tool success or local staging hash is not delivered bytes. Include a modest complete final diff and no leftover mutant, environment, DB or runtime cache. If transport/runtime/protected-source boundary remains blocked, deliver the actual completed source/evidence and name the exact missing capability and smallest next action; do not claim tests PASS or “unrelated” without actual evidence.'''
new='''Commit normally when possible, or explicitly stage a compact `report.md`, `receipt.json`, exact commands/selected and collected IDs, final source/base/tree/dirty-state pins, actual backend/default plugin/.pth profile, same-PID `pytest-process-start.json` and `pytest-configured.json`, complete actual collection, process/resource controller facts, per-case outcomes and complete compressed deciding outputs. Include every actual output path/length/SHA256 and gzip integrity; retain the FULL quiet stdout/stderr/XML bytes as modest gzip files. The actual files—not hashes pointing to ignored scratch—must be visible in the managed final snapshot. Do not ship an environment, DB, cache, giant raw dump or leftover mutant. Report actual model if established, otherwise `not_established`. Record setup/collection PASS/FAIL/ERROR/SKIP/UNRUN/abort separately; sum actual full-module outcomes and explain differences from the estimate without imposing402 as a quota. A finite import observer is not an all-source/all-backend proof.

Verify nonignored file visibility with ordinary `git ls-files`, exact staging/commit readback and actual binary blob content where applicable; use `git diff --binary` for a useful local snapshot/diff check. Normal hooks/commits remain preferred; if a normal commit is unavailable, record why and leave all intended files explicitly staged for the existing managed snapshot rather than bypassing hooks or stopping solely for ordinary Git connectivity. Do not create origin or push protected/provided work/main/integration branches. Ordinary Git topic push/readback is OPTIONAL and cannot invalidate the independently measured snapshot channel.

Finish the task normally through the managed platform. The coordinator—not a new CLI or a midrun acknowledgment from you—retrieves the final task diff/snapshot and verifies actual source/new-file/output bytes as it did for C83/C80. In your report distinguish local/index/commit visibility from coordinator retrieval, which is not yet observed by the worker. A future successful export is never fabricated. If an actual snapshot/file-export error is reported, name the concrete unavailable paths/byte counts and preserve every available file and exact gap; do not substitute ignored SHA-only pointers or invent a successful transfer. Runtime/protected-source blocks likewise retain completed actual evidence and the smallest next action, without laundering UNRUN as PASS or declaring a failure unrelated without isolation.'''
assert text.count(old)==1;text=text.replace(old,new)
text=text.replace('''Check them against fetched source before edits; a different field value is a source mismatch, not permission to update the expected hash.''','''Check them against the pinned LOCAL Git blobs and actual checkout before edits; no fetch is required. A different field value is a source mismatch, not permission to update the expected hash.''')
# Preserve every actual source pin and the complete module/removal semantics.
oldpins=original[original.index('## Exact input source pins'):]
newpins=text[text.index('## Exact input source pins'):]
oldrows=re.findall(r'^\| `([^`]+)` \| ([^|]+) \| `([a-f0-9]{64})` \|$',oldpins,re.M)
newrows=re.findall(r'^\| `([^`]+)` \| ([^|]+) \| `([a-f0-9]{64})` \|$',newpins,re.M);assert oldrows==newrows and len(newrows)==40
for path,role,digest in newrows:
 raw=subprocess.check_output(['git','show','ea3d65682d76a5d66d514e525ad2212e5a85f669:'+path],cwd=R);assert hashlib.sha256(raw).hexdigest()==digest,path
assert len(text)<=95000 and len(text.encode())<131072
(O/'prompt.md').write_text(text)
(O/'delta.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile='C83/prompt.md',tofile='C89/prompt.md')))
# Validate embedded observation code syntactically, without executing/importing it.
import ast
snippet=text.split('A compact allowed read-only launcher skeleton is below.',1)[1].split('```python\n',1)[1].split('\n```',1)[0];ast.parse(snippet)
print(json.dumps({'out':str(O),'chars':len(text),'bytes':len(text.encode()),'prompt_sha256':sha(O/'prompt.md'),'delta_bytes':(O/'delta.patch').stat().st_size,'unchanged_source_pin_rows':len(newrows),'observation_snippet_ast':'PASS','native':'UNRUN'},indent=2))
