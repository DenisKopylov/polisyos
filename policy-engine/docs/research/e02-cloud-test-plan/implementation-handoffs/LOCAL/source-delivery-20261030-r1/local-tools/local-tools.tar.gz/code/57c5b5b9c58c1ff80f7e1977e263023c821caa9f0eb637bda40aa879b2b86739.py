from __future__ import annotations
import ast
import hashlib
import json
from pathlib import Path
import subprocess

root = Path.cwd()
scratch = root / 'LOCAL/raw/e02-execution-20261027/repairs/C48-r5'
product = root / 'policy-engine'
python = str(product / '.venv/bin/python')
rows = []
files = {p.relative_to(scratch / 'postimages'): p for p in (scratch / 'postimages').rglob('*.py')}
for p in (scratch / 'c53-postimages').rglob('*.py'):
    files[p.relative_to(scratch / 'c53-postimages')] = p
for rel, path in sorted(files.items(), key=lambda pair: str(pair[0])):
    text = path.read_text()
    ast_ok = True
    error = None
    try:
        ast.parse(text, filename=str(rel))
    except SyntaxError as exc:
        ast_ok = False
        error = str(exc)
    name = str(rel.relative_to('policy-engine'))
    commands = [
        [python, '-m', 'ruff', 'check', '--no-cache', '--output-format=json', '--stdin-filename', name, '-'],
        [python, '-m', 'ruff', 'format', '--check', '--stdin-filename', name, '-'],
    ]
    checks = []
    for argv in commands:
        proc = subprocess.run(argv, input=text, text=True, capture_output=True, cwd=product)
        checks.append({'argv': argv[1:], 'exit_code': proc.returncode, 'stdout': proc.stdout, 'stderr': proc.stderr})
    rows.append({'path': str(rel), 'source_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'ast_ok': ast_ok, 'ast_error': error, 'checks': checks})
out = scratch / 'check-before-format.json'
out.write_text(json.dumps({'denominator': len(rows), 'rows': rows}, indent=2) + '\n')
for row in rows:
    failed = [i for i, check in enumerate(row['checks']) if check['exit_code']]
    if failed or not row['ast_ok']:
        print(row['path'], 'AST', row['ast_ok'], 'failed', failed)
        if 0 in failed:
            try:
                print(' '.join(f"{item['code']}:{item['location']['row']}" for item in json.loads(row['checks'][0]['stdout'])))
            except Exception:
                print(row['checks'][0]['stdout'][:300], row['checks'][0]['stderr'][:300])
print('denominator', len(rows), 'AST failures', sum(not row['ast_ok'] for row in rows), 'check failures', sum(row['checks'][0]['exit_code'] != 0 for row in rows), 'format failures', sum(row['checks'][1]['exit_code'] != 0 for row in rows))
