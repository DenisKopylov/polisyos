from pathlib import Path
import difflib, hashlib, json, subprocess
root=Path.cwd(); base=root/'LOCAL/raw/e02-execution-20261027/repairs/C41-r6'
pre=base/'preimages/policy-engine'; post=base/'postimages/policy-engine'
def sha(b): return hashlib.sha256(b).hexdigest()
def blob(b): return subprocess.run(['git','hash-object','--stdin'],input=b,capture_output=True,check=True).stdout.decode().strip()
def cmd(*argv): return subprocess.run(argv,capture_output=True,text=True,check=True).stdout.strip()
head=cmd('git','rev-parse','HEAD'); tree=cmd('git','rev-parse','HEAD^{tree}')
entries=[]; chunks=[]
for after in sorted(post.rglob('*.py')):
 rel=after.relative_to(post).as_posix(); before=pre/rel; actual=root/'policy-engine'/rel
 old=before.read_bytes() if before.exists() else None; new=after.read_bytes(); live=actual.read_bytes() if actual.exists() else None
 if old == new: continue
 name='policy-engine/'+rel
 entry={'path':name,'preimage_sha256':sha(old) if old is not None else None,'preimage_git_blob':blob(old) if old is not None else None,'postimage_sha256':sha(new),'postimage_git_blob':blob(new),'postimage_bytes':len(new),'live_sha256_at_freeze':sha(live) if live is not None else None,'live_matches_preimage':live==old}
 entries.append(entry)
 chunks.append(f'diff --git a/{name} b/{name}\n')
 if old is None: chunks.append('new file mode 100644\n')
 lines=list(difflib.unified_diff((old or b'').decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile=('a/'+name if old is not None else '/dev/null'),tofile='b/'+name,n=3))
 chunks.extend(lines)
patch=''.join(chunks).encode(); (base/'candidate.patch').write_bytes(patch)
r=subprocess.run(['git','apply','--check',str(base/'candidate.patch')],cwd=root,capture_output=True,text=True)
manifest={'status':'HOLD — widened scratch candidate pending independent review and native verification; no authority/closure claim','original_cloud_input_commit':'c863b9eae6439138ce60515d6204c84e138a8c9b','original_cloud_input_tree':'9c6993f799c4735f5c60e1c32c2c98e0306a1e14','reviewed_cloud_candidate_tree':'e0d06306a1ce981ccba82a73946b9620f69db0c6','local_source_frame_commit':'caa91a64d7d6afc4310186ba5fadbac2008dddab','local_source_frame_tree':'730308224f7f1bb0d49b60c3fdb5929d791e6ebd','head_at_freeze':head,'tree_at_freeze':tree,'patch_sha256':sha(patch),'patch_bytes':len(patch),'git_apply_check_exit':r.returncode,'git_apply_check_stdout':r.stdout,'git_apply_check_stderr':r.stderr,'changed_paths':entries,'ast_ruff_evidence':str((base/'ast-ruff-check.json').relative_to(root)),'no_tests_executed':True,'closure_ids':[]}
(base/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('head',head,'tree',tree,'patch_sha256',sha(patch),'bytes',len(patch),'apply_check',r.returncode)
print('live preimages equal',all(e['live_matches_preimage'] for e in entries),'paths',len(entries))
print(r.stderr)
for e in entries: print(e['path'], e['postimage_sha256'], 'live_matches_preimage='+str(e['live_matches_preimage']))
