"""Draft served oracle for the versioned acquired-rule owner quantity.

Runs only after the paired V3-rule-math-reader-r1 source is installed in a
reviewed scratch checkout. The fixture's epoch/authority are test-only.
"""

from __future__ import annotations

import ast
import inspect
from pathlib import Path
from typing import Any

import pytest

from polisyos.runtime.quality import acquisition_evaluation as evaluation
from polisyos.runtime.quality import acquisition_evaluation_dispatch as dispatcher
from polisyos.runtime.quality.n5_execution_basis import exact_n5_content_bytes
from tests._helpers import acquisition_served_history as fixture
from tests._helpers.candidate_cycle_source_profile import (
    build_candidate_cycle_substrate_route_inputs,
)
from tests.integration.core_runtime.test_acquisition_retained_sequential_served import (
    _OwnerCallMonitor,
    _SequentialOracle,
)

pytest_plugins = ("tests._helpers.acquisition_served_history",)


def _remove_evaluator_rule_handoff():
    """Mutate exactly the actual-branch v2 owner-rule handoff, retaining all markers."""
    source = inspect.getsource(evaluation.recompute_acquisition_basis_values)
    tree = ast.parse(source)

    class ReplaceHandoff(ast.NodeTransformer):
        count = 0

        def visit_Assign(self, node: ast.Assign) -> ast.AST:
            self.generic_visit(node)
            if (
                len(node.targets) == 1
                and isinstance(node.targets[0], ast.Name)
                and node.targets[0].id == "rules"
                and isinstance(node.value, ast.Call)
                and isinstance(node.value.func, ast.Name)
                and node.value.func.id == "list"
                and len(node.value.args) == 1
                and isinstance(node.value.args[0], ast.Attribute)
                and isinstance(node.value.args[0].value, ast.Name)
                and node.value.args[0].value.id == "owner_preparation"
                and node.value.args[0].attr == "effective_rules"
            ):
                self.count += 1
                node.value = ast.Call(
                    func=ast.Name(id="list", ctx=ast.Load()),
                    args=[
                        ast.Attribute(
                            value=ast.Name(id="bindings", ctx=ast.Load()),
                            attr="rules",
                            ctx=ast.Load(),
                        )
                    ],
                    keywords=[],
                )
            return node

    transformer = ReplaceHandoff()
    mutant = transformer.visit(tree)
    assert transformer.count == 1
    ast.fix_missing_locations(mutant)
    scope: dict[str, Any] = {}
    exec(
        compile(mutant, inspect.getsourcefile(evaluation) or "<evaluation>", "exec"),
        evaluation.__dict__,
        scope,
    )
    return scope["recompute_acquisition_basis_values"]


def test_real_evaluation_replays_owner_rule_order_from_a_fresh_wire_view(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    served_recorded_candidate_gateway: Any,
) -> None:
    """One produced B and equal admission reconcile through actual owner quantities."""
    import polisyos.foundry.data_plane as foundry

    actual_loader = foundry.load_input_bindings
    actual_comparison = dispatcher._comparison
    evidence: list[str] = []

    def observe_comparison(bridge: Any, selection: Any):
        prior = evaluation.resolve_selected_acquisition_evaluation(
            bridge=bridge, closure=selection.closure
        )

        def evaluate(
            *, actual: bool, profile: str, fn: Any = evaluation.recompute_acquisition_basis_values
        ):
            values, reasons = fn(
                bridge=bridge,
                closure=selection.closure,
                prepared=selection.prepared,
                prior=prior,
                actual_evaluation=actual,
                _comparison_profile=profile,
            )
            assert not reasons, reasons
            return values

        a2 = evaluate(actual=True, profile="controlled_acquired_observation_ncm_v2")
        p2 = evaluate(actual=False, profile="controlled_acquired_observation_ncm_v2")
        assert exact_n5_content_bytes(a2) == exact_n5_content_bytes(p2)
        a1 = evaluate(actual=True, profile="controlled_acquired_observation_ncm_v1")
        p1 = evaluate(actual=False, profile="controlled_acquired_observation_ncm_v1")
        assert a1["world"]["rules"] != p1["world"]["rules"]

        def reversed_wire(store: Any, ref: Any):
            bindings = actual_loader(store, ref)
            return bindings.model_copy(update={"rules": list(reversed(bindings.rules))})

        with monkeypatch.context() as reordered:
            reordered.setattr(foundry, "load_input_bindings", reversed_wire)
            a2_reordered = evaluate(actual=True, profile="controlled_acquired_observation_ncm_v2")
            p2_reordered = evaluate(actual=False, profile="controlled_acquired_observation_ncm_v2")
            assert exact_n5_content_bytes(a2_reordered) == exact_n5_content_bytes(a2)
            assert exact_n5_content_bytes(p2_reordered) == exact_n5_content_bytes(p2)
            removed = evaluate(
                actual=True,
                profile="controlled_acquired_observation_ncm_v2",
                fn=_remove_evaluator_rule_handoff(),
            )
            assert removed["foundry_state"] == a2["foundry_state"]
            assert removed["world"] == a2["world"]
            assert removed["applied_rules"] != a2["applied_rules"]
        assert exact_n5_content_bytes(
            evaluate(actual=True, profile="controlled_acquired_observation_ncm_v2")
        ) == exact_n5_content_bytes(a2)
        evidence.append(str(selection.growth_ref.artifact_id))
        return actual_comparison(bridge, selection)

    def after_b(*, issue_equal_source: Any, **_values: Any) -> None:
        with monkeypatch.context() as observed:
            observed.setattr(dispatcher, "_comparison", observe_comparison)
            negative, positive = issue_equal_source()
        assert negative.receipt.terminal_outcome == "quarantined_no_growth"
        assert positive.receipt is not None
        assert evidence, "the ordinary selected evaluator was not observed"

    source = build_candidate_cycle_substrate_route_inputs(tmp_path / "src")
    with _OwnerCallMonitor() as monitor:
        oracle = _SequentialOracle(monkeypatch, monitor, after_real_b=after_b)
        result = fixture._produce_served_acquisition_history(
            tmp_path,
            monkeypatch,
            served_recorded_candidate_gateway,
            source_owner_root=source.root,
            sequential_oracle=oracle,
        )
    assert result is not None
    assert evidence
