from pathlib import Path
import ast,hashlib,json
R=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos');P=Path(__file__).resolve().parent
rel='policy-engine/tools/quality/validation/decomposition_preflight.py';s=(R/rel).read_text();assert hashlib.sha256(s.encode()).hexdigest()=='bb28c329c41dac89cdfae8e94e59efa837748842f8f672ed031681bdd50dde4d'
def sub(a,b):
 global s
 assert s.count(a)==1,(a[:90],s.count(a));s=s.replace(a,b)
sub('    source_execution_origins: tuple[str, ...] = ()\n','    source_execution_origins: tuple[str, ...] = ()\n    opaque_payload_origins: tuple[str, ...] = ()\n')
sub('''        if self.guarded and self.kind in {"unknown", "ambiguous"}:
            # Existing guarded fallbacks deliberately erase exact identity. Preserve
            # their negative meaning, without inventing an importer/body authority.
            origins.add("guarded_unknown")
''','')
# The constructor is the shared carrier-normalization seam for both capabilities.
sub('        origins = set(self.source_execution_origins)\n','        origins = set(self.source_execution_origins)\n        opaque_origins = set(self.opaque_payload_origins)\n')
sub('                origins.update(value.source_execution_origins)\n','                origins.update(value.source_execution_origins)\n                opaque_origins.update(value.opaque_payload_origins)\n')
sub('        if origins:\n            object.__setattr__(self, "guarded", True)\n','        if origins or opaque_origins:\n            object.__setattr__(self, "guarded", True)\n        if opaque_origins:\n            object.__setattr__(self, "opaque_payload_origins", tuple(sorted(opaque_origins)))\n')
sub('''    def retain_provenance(value: _DynamicImportBinding) -> _DynamicImportBinding:
        if execution_origins:
''','''    opaque_origins = {
        origin for binding in bindings for origin in binding.opaque_payload_origins
    }

    def retain_provenance(value: _DynamicImportBinding) -> _DynamicImportBinding:
        if opaque_origins:
            value = replace(
                value,
                opaque_payload_origins=tuple(sorted(set(value.opaque_payload_origins) | opaque_origins)),
            )
        if execution_origins:
''')
# All type-erasing guarded projections in the guarded transfer family use one law.
pos='\n\n_DYNAMIC_TYPE_CHECKING_MODULE_ORIGIN'
sub(pos,'''

def _dynamic_unknown_projection(binding: _DynamicImportBinding) -> _DynamicImportBinding:
    """Lose shape without losing actual importer or executable payload provenance."""
    result = _DYNAMIC_AMBIGUOUS if binding.guarded else _DYNAMIC_UNKNOWN
    return _dynamic_join_with_guarded_origin((binding,), result)
'''+pos)
sub('        return _DYNAMIC_AMBIGUOUS if binding.guarded else _DYNAMIC_OTHER\n','        return _dynamic_join_with_guarded_origin(\n            (binding,), _DYNAMIC_AMBIGUOUS if binding.guarded else _DYNAMIC_OTHER\n        )\n')
sub('            child_value = _DYNAMIC_AMBIGUOUS if value.guarded else _DYNAMIC_UNKNOWN\n','            child_value = _dynamic_unknown_projection(value)\n')
sub('''                    if value.guarded:
                        environment[name] = _DYNAMIC_AMBIGUOUS
''','''                    if value.guarded:
                        environment[name] = _dynamic_unknown_projection(value)
''')
# Both match fallback families, complete by current AST census.
a='''                        name,
                        _DYNAMIC_AMBIGUOUS,
                        pattern,''';assert s.count(a)==1;s=s.replace(a,'''                        name,
                        _dynamic_unknown_projection(value),
                        pattern,''')
a='''                    name,
                    _DYNAMIC_AMBIGUOUS,
                    pattern,''';assert s.count(a)==1;s=s.replace(a,'''                    name,
                    _dynamic_unknown_projection(value),
                    pattern,''')
sub('''            fields[keyword.arg] = replace(
                _DYNAMIC_DEFERRED,
                name=value.name,
                guarded=value.guarded,
                origin_name=value.origin_name,
            )
''','''            fields[keyword.arg] = _dynamic_join_with_guarded_origin(
                (value,),
                replace(_DYNAMIC_DEFERRED, name=value.name, origin_name=value.origin_name),
            )
''')
sub('''            values=tuple(fields.values()),
        )

    def _source_class_instance_binding(''','''            values=tuple(fields.values()),
            opaque_payload_origins=(source_name,)
            if self._source_class_definition(
                source_name, current_module=module, current_environment=environment, stack=stack
            ) is not None and any(
                _is_guarded_importer_binding(value)
                or _dynamic_import_namespace_origins(value)
                or _dynamic_has_source_execution(value)
                or value.opaque_payload_origins
                for value in values
            )
            else (),
        )

    def _source_class_instance_binding(''')
sub('''        if not function_bindings:
            return None
        source_code_call''','''        if not function_bindings:
            return None
        if any(binding.opaque_payload_origins for binding in argument_bindings):
            raise DynamicImportCollectionError(
                f"{self.relative_path}:{node.lineno}: guarded importer value escapes through "
                "a call argument; unresolved source-object payload has no invocation summary"
            )
        source_code_call''')
# Actual invocation of an unclassified callable is distinct from ordinary type uncertainty.
sub('        elif _is_guarded_importer_binding(binding) or _dynamic_has_source_execution(binding):\n','        elif (\n            binding.kind == "ambiguous"\n            or _is_guarded_importer_binding(binding)\n            or _dynamic_has_source_execution(binding)\n        ):\n')
# An ordinary result does not become callable solely because its input shape was
# ambiguous. Actual capability sidebands were retained above.
sub('    if result.kind in {"sequence", "iterable", "mapping", "object", "union"}:\n','    if result.kind == "other" and not (\n        importer_origins or unresolved_origins or temporal_origins or execution_origins or opaque_origins\n    ):\n        return result\n    if result.kind in {"sequence", "iterable", "mapping", "object", "union"}:\n')
# Unknown expression shapes preserve all actual child capabilities.
sub('''        if any(binding.guarded or binding.kind == "ambiguous" for binding in child_values):
            return _DYNAMIC_AMBIGUOUS
''','''        if any(binding.guarded or binding.kind == "ambiguous" for binding in child_values):
            return _dynamic_join_with_guarded_origin(child_values, _DYNAMIC_AMBIGUOUS)
''')
# Unknown dict-unpack drops exact entries, but never its executable payload.
sub('''            shape_known = True
            guarded = False
            for key_node, value_node in zip(node.keys, node.values, strict=True):''','''            shape_known = True
            guarded = False
            payloads: list[_DynamicImportBinding] = []
            for key_node, value_node in zip(node.keys, node.values, strict=True):''')
sub('''                if key_node is None:
                    guarded = guarded or value.guarded''','''                payloads.append(value)
                if key_node is None:
                    guarded = guarded or value.guarded''')
sub('''                keys.append(key)
                values.append(value)
                guarded = guarded or key.guarded''','''                keys.append(key)
                values.append(value)
                payloads.append(key)
                guarded = guarded or key.guarded''')
sub('''                guarded=guarded,
            )
            if (
                mapping.items''','''                guarded=guarded,
            )
            if not shape_known:
                mapping = _dynamic_join_with_guarded_origin(payloads, mapping)
            if (
                mapping.items''')
# Every existing negative-payload consumer uses the same typed capability predicate.
s=s.replace("_dynamic_has_source_execution", "_dynamic_has_guarded_payload")
sub('        item.source_execution_origins\n        or item.kind','        item.source_execution_origins\n        or item.opaque_payload_origins\n        or item.kind')
from refine_candidate import refine, normalize_canonical_children, normalize_call_intake
s=normalize_call_intake(normalize_canonical_children(refine(s)))
ast.parse(s)
out=P/'candidate'/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(s)
prod=out.parents[3];(prod/'src').mkdir(exist_ok=True);(prod/'pyproject.toml').write_text('# RAW candidate explicit source root\n')
(P/'candidate-owner.json').write_text(json.dumps({'owner':str(out),'sha256':hashlib.sha256(s.encode()).hexdigest()},indent=2)+'\n')
print(hashlib.sha256(s.encode()).hexdigest())
