"""Capture first-party Python origins in the R1 driver and spawned producer.

Loaded as sitecustomize by the native pytest process and its multiprocessing
spawn child through an isolated PYTHONPATH entry. The driver records at normal
interpreter exit. The child records immediately before the test's intentional
os._exit(73); the original exit code is preserved. This is a test harness
observer, not a product module or runtime capability.
"""
from __future__ import annotations

import atexit
import json
import os
import sys

_ORIGINAL_EXIT = os._exit


def _is_under(path: str, root: str) -> bool:
    try:
        return os.path.commonpath((path, root)) == root
    except (OSError, ValueError):
        return False


def _record_origins(phase: str, filename: str, exit_code: int | None = None) -> None:
    """Write loaded module origins without hashing or touching product inputs."""
    output_root = os.environ.get("POLISYOS_R1_READSET_DIR")
    project_root = os.environ.get("POLISYOS_R1_PROJECT_ROOT")
    if not output_root or not project_root:
        raise RuntimeError("r1_readset_roots_missing")
    project_root = os.path.realpath(project_root)
    records: dict[str, dict[str, object]] = {}
    for module_name, module in tuple(sys.modules.items()):
        raw_origin = getattr(module, "__file__", None)
        if not isinstance(raw_origin, str) or not raw_origin:
            continue
        origin = os.path.realpath(raw_origin)
        in_project = _is_under(origin, project_root)
        relative = os.path.relpath(origin, project_root) if in_project else None
        first_party_name = (
            module_name == "polisyos"
            or module_name.startswith("polisyos.")
            or module_name == "tools"
            or module_name.startswith("tools.")
        )
        first_party_path = bool(
            relative
            and (
                relative.startswith("src/polisyos/")
                or relative.startswith("tests/")
                or relative.startswith("tools/")
            )
        )
        if not (first_party_name or first_party_path):
            continue
        row = records.setdefault(
            origin,
            {
                "origin_path": origin,
                "project_relative_path": relative,
                "inside_project": in_project,
                "module_names": [],
            },
        )
        names = row["module_names"]
        assert isinstance(names, list)
        names.append(module_name)
    modules = []
    for origin in sorted(records):
        row = records[origin]
        row["module_names"] = sorted(set(row["module_names"]))
        modules.append(row)
    record = {
        "schema": "polisyos.e02.r1.loaded_module_origins.v1",
        "capture_status": "complete",
        "phase": phase,
        "event_exit_code": exit_code,
        "pid": os.getpid(),
        "ppid": os.getppid(),
        "python_executable": sys.executable,
        "python_version": sys.version,
        "cwd": os.getcwd(),
        "argv": sys.argv,
        "spawn_marker_present": "--multiprocessing-fork" in sys.argv,
        "project_root": project_root,
        "sys_path": sys.path,
        "module_origin_count": len(modules),
        "modules": modules,
        "hashes": "not computed in child; host reconciles exact bytes after exit",
    }
    payload = (json.dumps(record, sort_keys=True, ensure_ascii=False) + "\n").encode()
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
    path = os.path.join(output_root, filename.format(pid=os.getpid()))
    fd = os.open(path, flags, 0o600)
    try:
        view = memoryview(payload)
        while view:
            written = os.write(fd, view)
            if written <= 0:
                raise OSError("r1_child_readset_short_write")
            view = view[written:]
        os.fsync(fd)
    finally:
        os.close(fd)


def _capture_then_exit(exit_code: int) -> None:
    """Capture only the commissioned child exit and always preserve its code."""
    if exit_code == 73 and "--multiprocessing-fork" in sys.argv:
        try:
            _record_origins(
                "multiprocessing_spawn_child_before_intentional_exit",
                "spawned-child-{pid}.json",
                exit_code,
            )
        except BaseException as exc:
            error_root = os.environ.get("POLISYOS_R1_READSET_DIR")
            if error_root:
                error = {
                    "schema": "polisyos.e02.r1.spawned_child_readset_error.v1",
                    "capture_status": "error",
                    "pid": os.getpid(),
                    "error_type": type(exc).__name__,
                    "error": str(exc)[:500],
                }
                try:
                    path = os.path.join(error_root, f"readset-error-{os.getpid()}.json")
                    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
                    fd = os.open(path, flags, 0o600)
                    try:
                        os.write(fd, (json.dumps(error, sort_keys=True) + "\n").encode())
                        os.fsync(fd)
                    finally:
                        os.close(fd)
                except BaseException:
                    pass
    _ORIGINAL_EXIT(exit_code)


os._exit = _capture_then_exit


def _record_driver_origins_at_exit() -> None:
    """Record the pytest driver's loaded origins for post-run reconciliation."""
    if "--multiprocessing-fork" in sys.argv:
        return
    try:
        _record_origins(
            "pytest_driver_at_interpreter_exit",
            "input-readset-{pid}.json",
        )
    except BaseException as exc:
        error_root = os.environ.get("POLISYOS_R1_READSET_DIR")
        if error_root:
            error = {
                "schema": "polisyos.e02.r1.driver_readset_error.v1",
                "capture_status": "error",
                "pid": os.getpid(),
                "error_type": type(exc).__name__,
                "error": str(exc)[:500],
            }
            try:
                path = os.path.join(error_root, f"readset-error-driver-{os.getpid()}.json")
                flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
                fd = os.open(path, flags, 0o600)
                try:
                    os.write(fd, (json.dumps(error, sort_keys=True) + "\n").encode())
                    os.fsync(fd)
                finally:
                    os.close(fd)
            except BaseException:
                pass


if "--multiprocessing-fork" not in sys.argv:
    atexit.register(_record_driver_origins_at_exit)
