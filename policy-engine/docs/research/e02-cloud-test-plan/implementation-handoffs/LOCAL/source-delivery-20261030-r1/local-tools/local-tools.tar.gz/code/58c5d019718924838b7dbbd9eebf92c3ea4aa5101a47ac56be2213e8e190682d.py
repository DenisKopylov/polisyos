"""Freeze sparse R2 deltas without importing/executing product code."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

ROOT=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
R=ROOT/'LOCAL/raw/e02-execution-20261027/repairs/C100-runtime-aa-r2'
OLD=R.parent/'C100-runtime-aa-r1'
BASE='870855f3ca83fcb32d4bb91d00d34daab3151032'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,stderr=subprocess.PIPE)
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(n,v):(R/n).write_text(json.dumps(v,indent=2)+'\n')
files=[];patch=[];delta=[]
for p in sorted((R/'postimages').rglob('*')):
 if not p.is_file():continue
 path=str(p.relative_to(R/'postimages'));b=p.read_bytes()
 try:pre=git('show',f'{BASE}:{path}')
 except subprocess.CalledProcessError:pre=None
 if path.endswith('.py'):ast.parse(b)
 files.append({'path':path,'pre_sha256':sha(pre) if pre is not None else None,'pre_git_blob':git('rev-parse',f'{BASE}:{path}').decode().strip() if pre is not None else None,'post_sha256':sha(b),'postimage':str(p.relative_to(R))})
 patch.append(''.join(difflib.unified_diff((pre or b'').decode().splitlines(keepends=True),b.decode().splitlines(keepends=True),fromfile='a/'+path if pre is not None else '/dev/null',tofile='b/'+path)))
 prior=(OLD/'postimages'/path).read_text();delta.append(''.join(difflib.unified_diff(prior.splitlines(keepends=True),b.decode().splitlines(keepends=True),fromfile='r1/'+path,tofile='r2/'+path)))
(R/'source.patch').write_text(''.join(patch));(R/'r1-r2-source-delta.patch').write_text(''.join(delta))
posts={x['path']:x['post_sha256'] for x in files}
profile=json.loads((OLD/'source-profile.json').read_text())
for row in profile['rows']:row['expected_after_sha256']=posts.get(row['path'],row['base_sha256'])
dump('source-profile.json',profile)
controls=json.loads((OLD/'controls-rebind.json').read_text())
for row in controls['rows']:row['expected_composed_test_sha256']=posts.get(row['test_source'],row['R10_test_sha256'])
dump('controls-rebind.json',controls)
checks=[]
for p in sorted((R/'postimages').rglob('*.py')):
 logical=ROOT/p.relative_to(R/'postimages')
 for mode in ['check','format']:
  args=[str(ROOT/'policy-engine/.venv/bin/python'),'-m','ruff',mode,*(['--no-cache'] if mode=='check' else ['--check']),'--config',str(ROOT/'policy-engine/ruff.toml'),'--stdin-filename',str(logical),'-']
  t=subprocess.run(args,input=p.read_text(),capture_output=True,text=True,cwd=ROOT/'policy-engine');checks.append({'path':str(logical),'argv':args,'returncode':t.returncode,'stdout':t.stdout,'stderr':t.stderr})
assert all(x['returncode']==0 for x in checks)
dump('logical-ruff-final.json',checks)
http='policy-engine/tests/unit/runtime/http/test_observational_method_runtime.py'
old=(OLD/'postimages'/http).read_text();new=(R/'postimages'/http).read_text()
oldtree=ast.parse(old);newtree=ast.parse(new)
# All other module definitions and the two original test selectors stay AST-exact.
def defs(tree):return {n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
a,b=defs(oldtree),defs(newtree);changed=[k for k in a if a[k]!=b[k]];assert changed==['_exercise_two_real_completed_ex_ante_sources_and_fresh_planner'],changed
assert new[new.index('@pytest.fixture\ndef c48_isolated_runtime_api_env'):]==old[old.index('@pytest.fixture\ndef c48_isolated_runtime_api_env'):]
for p in (R/'postimages/policy-engine/tests/unit/runtime/http').glob('*.py'):
 assert 'len(bundle.occurrences) == 1' not in p.read_text();assert 'bundle.occurrences[0]' not in p.read_text()
dump('static-audit.json',{'changed_shared_HTTP_definitions':changed,'all_other_shared_HTTP_definitions_AST_equal':len(a)-1,'fixture_and_both_original_selectors_byte_equal':True,'quantity_oracle':'Every invocation covers the selected full plan exactly; selected observed method is joined by actual observation ID. No whole-bundle method-count projection.','origin_oracle':'All loaded polisyos Python files retained; selected-source-root mismatch fails diagnostic.','runtime':'UNRUN','local_product_imports':False,'source_rows':len(profile['rows']),'control_rows':len(controls['rows'])})
t=subprocess.run(['git','apply','--check',str(R/'source.patch')],cwd=ROOT,capture_output=True,text=True);assert t.returncode==0,(t.stdout,t.stderr);dump('apply-check.json',{'argv':['git','apply','--check',str(R/'source.patch')],'returncode':t.returncode,'stdout':t.stdout,'stderr':t.stderr})
names=['README.md','source.patch','r1-r2-source-delta.patch','freeze_r2.py','source-profile.json','controls-rebind.json','logical-ruff-final.json','static-audit.json','apply-check.json']+[x['postimage'] for x in files]
m={'schema':'policyos.e02.sparse_source_proposal.v1','task':'C100-genuine-runtime-AA','base':BASE,'tree':'18a3178510405de4fcd8e6ce7dbc8b3d77932633','files':files,'patch_sha256':sha((R/'source.patch').read_bytes()),'prior_manifest_sha256':sha((OLD/'manifest.json').read_bytes()),'support':{n:{'sha256':sha((R/n).read_bytes()),'bytes':(R/n).stat().st_size} for n in names},'revision':'Full-invocation quantity oracle closes sole R1 blocking class for both AA/AB; foreign-product-origin diagnostic limitation also corrected.','status':'FROZEN_FOR_INDEPENDENT_DELTA_REVIEW','runtime':'UNRUN','discovery_native_diagnostic':'UNRUN','local_product_imports':False,'local_native_tests':False,'static_checks':'Eight complete logical product Ruff checks and Git apply-check PASS. Canonical physical qualification remains Root.','source_rows':len(profile['rows']),'control_rows':len(controls['rows']),'closure_ids':[],'G_acceptance':False}
dump('manifest.json',m);print(json.dumps({'manifest_sha256':sha((R/'manifest.json').read_bytes()),'patch_sha256':m['patch_sha256'],'delta_sha256':sha((R/'r1-r2-source-delta.patch').read_bytes())},indent=2))
