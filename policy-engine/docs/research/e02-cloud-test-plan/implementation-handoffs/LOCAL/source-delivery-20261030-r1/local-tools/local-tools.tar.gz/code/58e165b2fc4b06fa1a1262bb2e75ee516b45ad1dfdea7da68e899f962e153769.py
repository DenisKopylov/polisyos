from __future__ import annotations

import ast
import difflib
import subprocess
from pathlib import Path

r1 = Path('LOCAL/raw/e02-execution-20261027/repairs/TC-closure-owner-r1')
r2 = Path('LOCAL/raw/e02-execution-20261027/repairs/TC-closure-owner-r2')
path='policy-engine/src/polisyos/runtime/quality/authority.py'
base='99217ac06a37bfe12ee8e46da410cd15b2add827'
before=subprocess.check_output(['git','show',f'{base}:{path}'],text=True)
s=(r1/'authority.py.owner-prep-postimage.py').read_text()
old='''    compare_same_input_closure_candidate(\n        closure,\n        contract=contract,\n        resolver=resolver,\n        expected_run_id=expected_run_id,\n        expected_job_id=expected_job_id,\n        expected_tenant_id=expected_tenant_id,\n        expected_cell_id=expected_cell_id,\n    )\n    raise AuthorityEnvelopeError("same_input_closure_owner_not_established")\n'''
new='''    # The only positive owner in this slice is the installed, narrowly scoped\n    # Runtime execution replay. Caller-created contracts/callbacks remain\n    # candidate-only; even the exact owner type must independently replay.\n    from polisyos.runtime.quality.owned_execution_identity import (\n        _RestrictedExecutionIdentityOwner,\n    )\n\n    if type(resolver) is _RestrictedExecutionIdentityOwner:\n        replayed = resolver.replay()\n        if (\n            replayed.contract != contract\n            or replayed.closure != closure\n            or (closure.run_id, closure.job_id, closure.tenant_id, closure.cell_id)\n            != (expected_run_id, expected_job_id, expected_tenant_id, expected_cell_id)\n        ):\n            raise AuthorityEnvelopeError("same_input_closure_owned_replay_mismatch")\n        return VerifiedSameInputClosure(\n            _VERIFIED_CLOSURE_KEY, closure, closure.identity_tuple(), contract, resolver\n        )\n    compare_same_input_closure_candidate(\n        closure,\n        contract=contract,\n        resolver=resolver,\n        expected_run_id=expected_run_id,\n        expected_job_id=expected_job_id,\n        expected_tenant_id=expected_tenant_id,\n        expected_cell_id=expected_cell_id,\n    )\n    raise AuthorityEnvelopeError("same_input_closure_owner_not_established")\n'''
assert s.count(old)==1
s=s.replace(old,new,1)
# A restricted input-identity token must never become generic authority merely
# because a caller passes it to a different existing consumer.
old='''        for envelope, result in zip(validated, verified_items, strict=True):\n            if type(result) is not VerifiedSameInputClosure or not result._revalidate(\n                envelope.same_input_closure\n            ):\n'''
new='''        for envelope, result in zip(validated, verified_items, strict=True):\n            if (\n                type(result) is VerifiedSameInputClosure\n                and result._contract.purpose == "execution_input_identity_only"\n            ):\n                raise AuthorityEnvelopeError("same_input_closure_purpose_mismatch")\n            if type(result) is not VerifiedSameInputClosure or not result._revalidate(\n                envelope.same_input_closure\n            ):\n'''
assert s.count(old)==1
s=s.replace(old,new,1)
old='''    if closure.schema_version != "2.0":\n        raise AuthorityEnvelopeError("same_input_closure_legacy_not_authoritative")\n    if type(verified_closure) is not VerifiedSameInputClosure or not verified_closure._revalidate(\n        closure\n    ):\n'''
new='''    if closure.schema_version != "2.0":\n        raise AuthorityEnvelopeError("same_input_closure_legacy_not_authoritative")\n    if (\n        type(verified_closure) is VerifiedSameInputClosure\n        and verified_closure._contract.purpose == "execution_input_identity_only"\n    ):\n        raise AuthorityEnvelopeError("same_input_closure_purpose_mismatch")\n    if type(verified_closure) is not VerifiedSameInputClosure or not verified_closure._revalidate(\n        closure\n    ):\n'''
assert s.count(old)==1
s=s.replace(old,new,1)
ast.parse(s)
p=r2/'proposal'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
subprocess.run(['policy-engine/.venv/bin/python','-m','ruff','format','--config','policy-engine/ruff.toml',str(p)],check=True,capture_output=True)
s=p.read_text()
(r2/'authority.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='a/'+path,tofile='b/'+path)))
print('prepared',p)
