"""Narrow, bounded Pydantic error witness; valid only with admitted bindings."""
from __future__ import annotations

import hashlib
import re
from typing import NamedTuple
from types import CodeType, TracebackType
import v3_exception_witness as base

MAX_VALIDATION_ERRORS = 16
FIELDS = frozenset({
    "schema_version", "invocation_id", "event_id", "physical_spec_ref", "effective_seed",
    "status", "started_at", "completed_at", "duration_seconds", "work_units", "work_unit",
    "observation_basis", "scientific_authenticity", "usd_cost", "usd_cost_status",
    "budget_status", "budget_source_basis_digest", "error_type",
})
# Even include_context=False may render ctx into msg; export known literals only.
SAFE_MESSAGES = frozenset({
    "String should match pattern '^[a-f0-9]{32}$'",
    "String should match pattern '^[a-f0-9]{64}$'",
    "Value error, physical_work_budget_source_mismatch",
    "Value error, physical_work_error_binding_mismatch",
})

class NativeAccess(NamedTuple):
    cls: type
    count: object
    errors: object
    title: object

class CallSite(NamedTuple):
    code: CodeType
    globals: dict
    model: type
    start: int
    end: int
    schema: object = None
    validator: object = None
    rule: object = None
    schema_snapshot: str | None = None
    rule_code: object = None

def schema_fingerprint(schema: object) -> str:
    """Snapshot built-in schema containers and leaf identities, with hard caps.

    This detects post-admission container or leaf replacement. It is not a
    proof of a native validator's internal schema or mutable leaf contents.
    """
    digest = hashlib.sha256()
    pending = [schema]
    seen: set[int] = set()
    nodes = 0
    total = 0
    while pending:
        item = pending.pop()
        nodes += 1
        if nodes > 8192:
            raise ValueError("schema_node_budget")
        kind = type(item)
        if kind in (dict, list, tuple):
            if len(pending) + len(item) * (2 if kind is dict else 1) > 8192 - nodes:
                raise ValueError("schema_container_budget")
            key = id(item)
            if key in seen:
                part = f"backref:{key};".encode()
            else:
                seen.add(key)
                part = f"container:{kind.__name__}:{key}:{len(item)};".encode()
                if kind is dict:
                    for k, v in reversed(tuple(item.items())):
                        pending.extend((v, k))
                else:
                    pending.extend(reversed(item))
        elif kind is str:
            if len(item) > 262144:
                raise ValueError("schema_text_budget")
            part = b"str:" + item.encode("utf-8", "backslashreplace") + b";"
        elif kind is int and item.bit_length() > 256:
            raise ValueError("schema_number_budget")
        elif kind in (int, float, bool, type(None)):
            part = (kind.__name__ + ":" + repr(item) + ";").encode()
        elif kind is bytes:
            if len(item) > 262144:
                raise ValueError("schema_bytes_budget")
            part = b"bytes:" + item + b";"
        else:
            part = f"opaque:{id(kind)}:{id(item)};".encode()
        total += len(part)
        if total > 262144:
            raise ValueError("schema_byte_budget")
        digest.update(part)
    return digest.hexdigest()

def _unavailable(reason: str) -> dict:
    return {"status": "unavailable", "reason": reason}

def _has_exact_call(exc: BaseException, site: CallSite) -> bool:
    tb = BaseException.__traceback__.__get__(exc, type(exc))
    matches = 0
    visited = 0
    while tb is not None and visited < base.MAX_FRAMES:
        if type(tb) is not TracebackType:
            return False
        frame = tb.tb_frame
        if (frame.f_code is site.code and frame.f_globals is site.globals
                and site.globals.get("PhysicalSimulationWorkObservation") is site.model
                and site.start <= tb.tb_lineno <= site.end):
            matches += 1
        visited += 1
        tb = tb.tb_next
    return tb is None and matches == 1

def extract(exc: BaseException, budget: base._CaptureBudget, native: NativeAccess,
            site: CallSite) -> dict:
    """Copy safe primitives; caller must first admit all source/native bindings."""
    try:
        if type(exc) is not native.cls:
            return _unavailable("exception_class_mismatch")
        if not _has_exact_call(exc, site):
            return _unavailable("constructor_traceback_mismatch_or_incomplete")
        if site.schema is not None:
            model_dict = vars(site.model)
            if (model_dict.get("__pydantic_core_schema__") is not site.schema or
                    model_dict.get("__pydantic_validator__") is not site.validator or
                    model_dict.get("_work_observation_binding") is not site.rule or
                    site.rule.__code__ is not site.rule_code or
                    schema_fingerprint(site.schema) != site.schema_snapshot):
                return _unavailable("live_schema_changed")
        if native.title.__get__(exc, native.cls) != "PhysicalSimulationWorkObservation":
            return _unavailable("title_mismatch")
        count = native.count(exc)
        if type(count) is not int or count < 1:
            return _unavailable("error_count_invalid")
        if count > MAX_VALIDATION_ERRORS:
            return _unavailable("error_count_overflow")
        raw = native.errors(exc, include_url=False, include_context=False, include_input=False)
        if type(raw) is not list or len(raw) != count:
            return _unavailable("error_rows_mismatch")
        rows = []
        withheld = False
        for row in raw:
            if type(row) is not dict or set(row) != {"type", "loc", "msg"}:
                return _unavailable("error_row_shape_invalid")
            kind, loc, msg = row["type"], row["loc"], row["msg"]
            if type(kind) is not str or re.fullmatch(r"[a-z][a-z0-9_]{0,79}", kind) is None:
                return _unavailable("error_type_invalid")
            if type(loc) is not tuple or len(loc) > 1 or (loc and (type(loc[0]) is not str or loc[0] not in FIELDS)):
                return _unavailable("error_location_outside_model")
            if type(msg) is not str:
                return _unavailable("error_message_invalid")
            safe_message = msg if msg in SAFE_MESSAGES else None
            withheld |= safe_message is None
            to_capture = [kind, *loc] + ([safe_message] if safe_message is not None else [])
            frozen = [budget.take(value) for value in to_capture]
            if any(value.get("available") is not True for value in frozen):
                return _unavailable("capture_budget_exceeded")
            rows.append({"type": kind, "loc": list(loc), "msg": safe_message})
        return {"status": "partial" if withheld else "available", "error_count": count,
                "errors": rows, "message_status": "not_whitelisted" if withheld else "available"}
    except BaseException as error:
        # Never call str(error), and never replace the original target behavior.
        return {"status": "unavailable", "reason": "extraction_error", "error_type": type(error).__name__}

class StructuredExceptionWitness(base.ExceptionWitness):
    def __init__(self, target, output, native: NativeAccess, site: CallSite):
        super().__init__(target, output)
        self.native = native
        self.site = site

    def _handled(self, code, offset, exc):
        try:
            if code is not self.target:
                return
            with self.lock:
                self.events_seen += 1
                if len(self.events) >= base.MAX_EVENTS:
                    self.events_omitted += 1
                    return
                event = {"instruction_offset": offset, **base._freeze_exception(exc, self.budget)}
                event["structured_validation"] = extract(exc, self.budget, self.native, self.site)
                self.events.append(event)
        except BaseException as error:
            self._callback_error("target_handled", error)
