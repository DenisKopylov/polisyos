"""Build the sparse params-wire proposal; do not import product or mutate Git."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import stat
import subprocess
import tomllib

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
OUT = Path(__file__).resolve().parent
POST = OUT / 'postimages'
PRODUCT = ROOT / 'policy-engine'
BASE = json.loads((OUT / 'base.json').read_text())
sha = lambda b: hashlib.sha256(b).hexdigest()
checks = []
for path in sorted(POST.rglob('*.py')):
    logical = str(ROOT / path.relative_to(POST))
    data = path.read_bytes()
    compile(data, logical, 'exec')
    for args in [('check', '--select', 'I', '--fix'), ('format',)]:
        argv = [str(PRODUCT / '.venv/bin/python'), '-m', 'ruff', *args, '--no-cache', '--stdin-filename', logical, '-']
        done = subprocess.run(argv, input=data, cwd=PRODUCT, capture_output=True)
        assert done.returncode == 0, (logical, done.stdout.decode(), done.stderr.decode())
        data = done.stdout
    path.write_bytes(data)
    compile(data, logical, 'exec')
    for args in [('check',), ('format', '--check')]:
        argv = [str(PRODUCT / '.venv/bin/python'), '-m', 'ruff', *args, '--no-cache', '--stdin-filename', logical, '-']
        done = subprocess.run(argv, input=data, cwd=PRODUCT, capture_output=True)
        row = dict(path=str(path.relative_to(POST)), argv=argv, exit=done.returncode, stdout=done.stdout.decode(), stderr=done.stderr.decode())
        checks.append(row)
        assert done.returncode == 0, row
for path in POST.rglob('*.toml'):
    tomllib.loads(path.read_text())

owner = 'policy-engine/src/polisyos/scientist/nodes/builtins/simulate/propagate_uncertainty.py'
before = subprocess.check_output(['git', 'show', BASE['head'] + ':' + owner], cwd=ROOT).decode()
after = (POST / owner).read_text()
def outside(source, function):
    node = next(n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name == function)
    lines = source.splitlines(keepends=True)
    return ''.join(lines[:node.lineno - 1] + lines[node.end_lineno:])
assert outside(before, '_load_response_projection') == outside(after, '_load_response_projection')
classes = lambda s: {n.name: ast.get_source_segment(s, n) for n in ast.parse(s).body if isinstance(n, ast.ClassDef)}
assert classes(before) == classes(after), 'DTO or public Node modified'

files = []; patch = []
for path in sorted(POST.rglob('*')):
    if not path.is_file(): continue
    rel = str(path.relative_to(POST)); info = path.stat()
    assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and not path.is_symlink()
    mode = subprocess.check_output(['git', 'ls-tree', BASE['head'], '--', rel], cwd=ROOT, text=True).split()
    old = subprocess.check_output(['git', 'show', BASE['head'] + ':' + rel], cwd=ROOT) if mode else b''
    data = path.read_bytes(); assert data != old
    assert (ROOT / rel).exists() == bool(mode)
    if mode: assert (ROOT / rel).read_bytes() == old, ('Current canonical preimage changed', rel)
    files.append(dict(path=rel, preimage_mode=mode[0] if mode else None, preimage_git_blob=mode[2] if mode else None, preimage_sha256=sha(old) if mode else None, postimage_sha256=sha(data), postimage_git_blob=hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest(), bytes=len(data), postimage=str(path.relative_to(ROOT)), role='mechanism' if rel==owner else 'mandatory companion'))
    patch.append(f'diff --git a/{rel} b/{rel}\n')
    if not mode: patch.append('new file mode 100644\n')
    patch.extend(difflib.unified_diff(old.decode().splitlines(keepends=True), data.decode().splitlines(keepends=True), fromfile='a/' + rel if mode else '/dev/null', tofile='b/' + rel, n=3))
content = ''.join(patch).encode(); (OUT / 'proposal.patch').write_bytes(content)
check = subprocess.run(['git', 'apply', '--check', '--whitespace=error', str(OUT / 'proposal.patch')], cwd=ROOT, capture_output=True, text=True)
assert check.returncode == 0, check.stderr

correct = '''        return _ResponseProjectionSpec.model_validate_json(
            json.dumps(dict(raw), allow_nan=False), strict=True
        )\n'''
wrong = '''        return _ResponseProjectionSpec.model_validate(
            json.loads(json.dumps(dict(raw), allow_nan=False))
        )\n'''
assert after.count(correct)==1
mutant=after.replace(correct, wrong, 1)
compile(mutant, owner, 'exec')
assert outside(mutant, '_load_response_projection') == outside(after, '_load_response_projection')
mutation = ''.join(difflib.unified_diff(after.splitlines(keepends=True), mutant.splitlines(keepends=True), fromfile='a/' + owner, tofile='b/' + owner, n=3)).encode()
(OUT / 'removals').mkdir(exist_ok=True)
(OUT / 'removals/remove-strict-json-wire-mode.patch').write_bytes(mutation)
control = {
 'name':'remove-strict-json-wire-mode.patch', 'path':owner,
 'preimage_sha256':sha(after.encode()), 'postimage_sha256':sha(mutant.encode()), 'patch_sha256':sha(mutation),
 'test':'tests/unit/scientist/nodes/builtins/simulate/test_propagate_uncertainty.py::test_response_projection_json_wire_reaches_public_node_and_keeps_tuple_internals[explicit-version-array]',
 'mirror':'tests/unit/scientist/nodes/builtins/simulate/test_propagate_uncertainty.py::test_response_projection_json_wire_reaches_public_node_and_keeps_tuple_internals[default-version-identifiers-stay-text]',
 'expected_semantic_red':'The public node returns fail/propagation_response_basis_invalid rather than the normal no-simulation skip because the unchanged JSON array reaches strict Python tuple validation. The test asserts the actual public outcome before private DTO assertions. No source/fit/backend path is needed. All DTO constraints, JSON serializer, fixtures, Node metadata and selected-source admission remain intact.',
 'restore':'Restore exact owner postimage, verify its hash, rerun the same unchanged selector and require the intended positive. Root alone schedules mutation while no other process imports the owner. Do not classify import/collection/setup/backend or unrelated strict errors as a property red.',
 'runtime':'UNRUN'
}
(OUT / 'property-removals.json').write_text(json.dumps({'controls':[control], 'prior_R7_R8_controls':'Preserved immutable artifacts; no result carried forward. Requalify only affected properties on the eventual composed source.'},indent=2)+'\n')

tree = ast.parse(after)
parents = {}
for parent in ast.walk(tree):
 for child in ast.iter_child_nodes(parent): parents[child]=parent
calls = []
for n in ast.walk(tree):
 if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id=='_load_response_projection':
  p=n; scope=[]
  while p in parents:
   p=parents[p]
   if isinstance(p,(ast.FunctionDef,ast.ClassDef)): scope.append(p.name)
  calls.append({'line':n.lineno,'scope':'.'.join(reversed(scope)),'argument':ast.unparse(n.args[0])})
assert calls == [{'line':217,'scope':'PropagateUncertaintyNode.execute','argument':'state.params'}]
(OUT / 'caller-census.json').write_text(json.dumps({
 'scope':'Complete AST of the one changed production Python module; not a repository-wide absence claim or dynamic-call proof.',
 'input':owner, 'source_sha256':sha(after.encode()), 'python_file_denominator':1,
 'direct_reader_calls':calls,
 'raw_input_owner':'polisyos.scientist.orchestration.engine.state.ExperimentState.params: dict[str, JsonValue]',
 'reuse':'Pydantic BaseModel.model_validate_json(..., strict=True), with standard json serialization; existing strict DTO/schema/field validators remain the sole field law.',
 'preserved':'All text outside _load_response_projection and all class text are byte-identical, including both actual scalar selected-config checks, raw/media source intake, C105 Core, MC and source joins.',
 'boundaries':'Only syntax in the JSON params plane. Ref/artifact provenance, state-slot grounding, report/intake/join and inferential qualification remain with their existing readers and may still refuse.'
},indent=2)+'\n')
static={'checks':checks,'python_files':len({r['path'] for r in checks}), 'compile':'PASS, no execution','TOML':'PASS','mutant_compile':'PASS, no execution', 'outside_wire_function_sha256':sha(outside(after,'_load_response_projection').encode()),'outside_wire_function_identical':True,'all_DTO_and_node_class_bytes_identical':True,'apply_check':{'exit':check.returncode,'stdout':check.stdout,'stderr':check.stderr}, 'product_imports':False,'pytest_collection':'UNRUN','physical_import_topology':'UNRUN','runtime':'UNRUN'}
(OUT/'static-checks.json').write_text(json.dumps(static,indent=2)+'\n')
manifest={'schema':'policyos.e02.sparse_proposal.v1','task':'C78-projection-wire-r9','status':'source proposal awaiting independent frozen delta review and Root execution','base_commit':BASE['head'],'base_tree':BASE['tree'],'files':files,'footprint':{'total_postimage_paths':len(files),'mechanism_paths':sum(r['role']=='mechanism' for r in files),'mandatory_companion_postimages':sum(r['role']=='mandatory companion' for r in files)},'patch':{'path':str((OUT/'proposal.patch').relative_to(ROOT)),'sha256':sha(content),'bytes':len(content)},'source_scope':'Only _load_response_projection changes; public strict JSON DTO law reused for the complete mapping; all outside function and class bytes identical. No fixture tuple rewrite.','static':'PASS, logical-stdin Ruff/format/compile/TOML/mutant syntax/apply-check only','runtime':'UNRUN by author; Root phase0 failure retained as input; original17P/1F remains truthful','capability_state':'verification_missing','canonical_index_refs_changed':False,'closure_ids':[]}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'manifest_sha256':sha((OUT/'manifest.json').read_bytes()),'patch_sha256':sha(content),'patch_bytes':len(content),'footprint':manifest['footprint'],'static_python_files':static['python_files']}))
