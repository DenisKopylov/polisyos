"""Create a sparse proposal manifest using Git reads only, never index/refs."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import os
import subprocess

ROOT=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
OUT=Path(__file__).resolve().parent
BASE='545c6990e2bfa42bf580b475e23cf88df04e71d8'
BASE_TREE='abd7d9913680d5531081c45536c1cf7d7d701835'
sha=lambda value:hashlib.sha256(value).hexdigest()
blob=lambda value:hashlib.sha1(b'blob '+str(len(value)).encode()+b'\0'+value).hexdigest()
assert subprocess.check_output(['git','rev-parse',BASE+'^{tree}'],cwd=ROOT,text=True).strip()==BASE_TREE
assert not (OUT/'manifest.json').exists()
paths=sorted(str(p.relative_to(OUT)) for p in (OUT/'policy-engine').rglob('*') if p.is_file())
assert len(paths)==5,paths
files=[];patch=[]
for path in paths:
    old=subprocess.run(['git','show',BASE+':'+path],cwd=ROOT,capture_output=True)
    original=old.stdout if old.returncode==0 else None
    current=(ROOT/path).read_bytes() if (ROOT/path).is_file() else None
    candidate=(OUT/path).read_bytes()
    assert original==current,('canonical target preimage drift',path)
    assert candidate!=original
    assert (OUT/path).stat().st_nlink==1
    assert not (OUT/path).is_symlink()
    if original is not None:
        actual_blob=subprocess.check_output(['git','rev-parse',BASE+':'+path],cwd=ROOT,text=True).strip()
        assert actual_blob==blob(original)
        metadata='diff --git a/'+path+' b/'+path+'\nindex '+actual_blob[:12]+'..'+blob(candidate)[:12]+' 100644\n'
        source='a/'+path
    else:
        metadata='diff --git a/'+path+' b/'+path+'\nnew file mode 100644\nindex 000000000000..'+blob(candidate)[:12]+'\n'
        source='/dev/null'
    patch.append(metadata+''.join(difflib.unified_diff((original or b'').decode().splitlines(keepends=True),candidate.decode().splitlines(keepends=True),fromfile=source,tofile='b/'+path)))
    role='mechanism' if path.endswith('/src/polisyos/ir/analytics/posterior_summary.py') else 'mandatory companion'
    files.append({'path':path,'role':role,'preimage_blob':blob(original) if original is not None else None,'preimage_sha256':sha(original) if original is not None else None,'preimage_bytes':len(original) if original is not None else None,'preimage_mode':'100644' if original is not None else None,'postimage_blob':blob(candidate),'postimage_sha256':sha(candidate),'postimage_bytes':len(candidate),'postimage_mode':'100644','independent_regular_file':True,'current_preimage_match':True})
(OUT/'source.patch').write_text(''.join(patch))
cmd=['git','apply','--check','--whitespace=error','--',str(OUT/'source.patch')]
check=subprocess.run(cmd,cwd=ROOT,capture_output=True)
(OUT/'static-final-r2/apply-check.stdout').write_bytes(check.stdout)
(OUT/'static-final-r2/apply-check.stderr').write_bytes(check.stderr)
assert check.returncode==0,check.stderr
links={}
for name in ['README.md','inputs.json','consumer-census.json','census.py','abi-source-comparison.json','static-final-r2/results.json','static-final-r2/test-preservation.json','property-removals.json','build_removals.py','freeze.py','source.patch']:
    data=(OUT/name).read_bytes();links[name]={'path':name,'sha256':sha(data),'bytes':len(data)}
for p in sorted((OUT/'removals').glob('*.patch')):
    data=p.read_bytes();links[str(p.relative_to(OUT))]={'path':str(p.relative_to(OUT)),'sha256':sha(data),'bytes':len(data)}
status=subprocess.check_output(['git','status','-sb','--untracked-files=no'],cwd=ROOT,text=True)
manifest={
    'schema':'policyos.e02.sparse_proposal.v1','task':'C81 complete source-coordinate/law admission r1',
    'status':'unapplied_proposal; independent source review pending; runtime UNRUN','capability_state':'verification_missing',
    'base_commit':BASE,'base_tree':BASE_TREE,'observed_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    'observed_tracked_status':status,'files':files,'footprint':{'canonical_paths':len(files),'mechanism_paths':1,'mandatory_companions':4,'python_files':3},
    'virtual_tree':'not_established; Root composition will create the actual commit/tree','artifacts':links,
    'prior_cloud_return':{'diff_sha256':'fb3d03de1ab6eeae0f8999241f044b81017886926b7d54fd8ac8f18baeb5a933','candidate_tree':'c5c9eff26b54f8c8ea8eaf1444952b824bbe7f41','state':'HOLD; source input only, no runtime delivered'},
    'independent_prior_review':{'path':'LOCAL/raw/e02-execution-20261027/reviews/C81-return-independent.md','sha256':'0aab74f94390da8e0a4c0586dcfa872fc6eaa36e83cfcfdea201644d9fde2318'},
    'criteria':[{'finding_id':'B201','bundle':'UQS-01','pointer':'closure-decisions/coverage.json#/findings/121/criterion_refs/0'},{'finding_id':'B202','bundle':'UQS-01','pointer':'closure-decisions/coverage.json#/findings/122/criterion_refs/0'}],
    'predicate_basis':{'source_coordinate_set_and_statistics':'recomputed from complete hash-bound source payload before frozen owner emission','selected_method_source_view':'existing adapter re-resolution and exact manifest/profile reconciliation, runtime UNRUN','source_validity_units_fit_mixing_ESS_currentness':'not_established','authority':'gate_eligible=False remains literal'},
    'p40_disposition':'SAME posterior law/source-coordinate/selected-source class; widened full-source invariant rather than retained-entry proxy. Evidence custody is separate P29/P38; no author runtime result exists.',
    'static_results':{'AST':'PASS three Python postimages','TOML':'PASS release fragment','Ruff':'PASS canonical product filenames on stdin, exact inputs and complete output pinned; not physical composed Root check','read_only_apply_check':{'command':cmd,'exit':check.returncode,'stdout_sha256':sha(check.stdout),'stderr_sha256':sha(check.stderr)},'original_test_AST':'all five IR and six runner test functions unchanged'},
    'remaining_required_checks':['physical composed Root Ruff check/format','narrow base red or honest UNRUN','two changed full test modules plus affected old MC/adapter consumers','six same-test removal/restoration triplets','separate NumPy HMC pilot','mypy/architecture/ABI/public inventory/generated impact as applicable','actual loaded repository/test/plugin/profile source reconciliation','independent candidate code review','G acceptance and formal adjudication'],
    'boundary_limits':['Unweighted candidate profile1.1 does not close the historical E-selected weighted envelope profile1.0 chain.','S3 B31, E-M1 calibrated objective/Hessian/covariance validity and institutional authority remain separate.','No Calibrator/execution-basis/C78, Core codec/CAN.3 rollout, lifecycle or shared generator owner writes.','Complete literal source census is not a transitive runtime readset or absence proof over dynamic adapters/non-Python/tools.','The default uncertainty route remains UncertaintyEnvelope; no default orchestration claim.','New portable runtime/profile/resource measurement is UNRUN.'],
    'canonical_mutation':False,'index_or_ref_or_object_mutation':False,'product_imports_run':False,'pytest_run':False,'native_run':False,'children_spawned':False,'closure_ids':[],'G_acceptance':False
}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
assert json.loads((OUT/'manifest.json').read_text())==manifest
for item in files:
    assert sha((OUT/item['path']).read_bytes())==item['postimage_sha256']
for item in links.values():
    assert sha((OUT/item['path']).read_bytes())==item['sha256']
print(json.dumps({'manifest':str((OUT/'manifest.json').relative_to(ROOT)),'manifest_sha256':sha((OUT/'manifest.json').read_bytes()),'patch_sha256':sha((OUT/'source.patch').read_bytes()),'patch_bytes':(OUT/'source.patch').stat().st_size,'paths':len(files),'canonical_mutation':False,'runtime':'UNRUN'}))
