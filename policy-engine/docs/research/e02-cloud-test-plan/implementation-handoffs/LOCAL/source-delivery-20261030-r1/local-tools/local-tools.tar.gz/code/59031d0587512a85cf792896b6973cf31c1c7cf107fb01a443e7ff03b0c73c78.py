"""Small untrusted-outcome probe of the C95 decision function; no product imports."""
from __future__ import annotations
import ast, hashlib, json
from pathlib import Path
from types import SimpleNamespace

ROOT=Path(__file__).resolve().parent
source=ROOT/'postimages/policy-engine/tests/unit/remediation/test_e02_lex_impact_controls.py'
tree=ast.parse(source.read_text()); wanted={'_property_holds','_qualified_removal','_reason'}
nodes=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name in wanted]
assert {x.name for x in nodes} == wanted
module=ast.Module(body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0),*nodes],type_ignores=[])
module=ast.fix_missing_locations(module)
ns={'NormDiff':SimpleNamespace(ARTIFACT_KIND='lex.norm_diff'),'NormImpactReport':SimpleNamespace(ARTIFACT_KIND='lex.norm_impact_report')}
exec(compile(module,'<C95-frozen-oracle-probe>','exec'),ns)
phase=lambda value,kind='value':SimpleNamespace(result=SimpleNamespace(kind=kind,value=value),pid=74)
holds=ns['_property_holds']; qualified=ns['_qualified_removal']
base={'legacy_ready':True,'observer_restored':True,'observer_patch_count_after':0,'outcome':'value_error','error':'selected_report_jurisdiction_mismatch','writes':[]}
wrong=base|{'error':'some_other_guard_failed'}
assert holds('scope_guard',phase(base))
assert not holds('scope_guard',phase(wrong))
assert not qualified('scope_guard',phase(wrong))
assert not qualified('scope_guard',phase(base|{'outcome':'returned','selected_ref':'fixture','writes':[]}))
assert not qualified('scope_guard',phase(base|{'outcome':'returned','selected_ref':'fixture','writes':[{'kind':'other','pid':74,'schema':{}}]}))
good=base|{'outcome':'returned','selected_ref':'fixture','writes':[{'kind':'lex.norm_diff','pid':74,'schema':{'version':'1.0'}},{'kind':'lex.norm_impact_report','pid':74,'schema':{'version':'1.1'}}]}
assert not holds('scope_guard',phase(good)) and qualified('scope_guard',phase(good))
assert not qualified('scope_guard',phase(None,'exception'))
assert not qualified('report_bridge',phase({'persisted':True,'reader_error':'unrelated'}))
result={'status':'PASS','scope':'pure oracle robustness; simulated outcomes, not product execution','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'cases':['positive_refusal','wrong_refusal','no_write','wrong_write_kind','expected_two_writes','unexpected_exception','unrelated_bridge_error'],'closure_ids':[]}
print(json.dumps(result,sort_keys=True))
