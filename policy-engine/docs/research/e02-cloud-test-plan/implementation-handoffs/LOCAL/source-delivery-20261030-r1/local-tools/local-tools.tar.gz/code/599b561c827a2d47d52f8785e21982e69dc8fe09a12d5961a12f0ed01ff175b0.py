"""Bounded in-process denominator experiment; canonical source is never written."""
from __future__ import annotations

import hashlib
import importlib
import json
import marshal
import os
import subprocess
import sys
import threading
from pathlib import Path
from types import CodeType, FunctionType

import pytest

_RUNTIME = None


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _codes(code):
    yield code
    for value in code.co_consts:
        if isinstance(value, CodeType):
            yield from _codes(value)


def _function_code(source, filename, name):
    code = compile(source, filename, "exec", dont_inherit=True, optimize=sys.flags.optimize)
    matches = [value for value in _codes(code) if value.co_qualname == name]
    if len(matches) != 1:
        raise RuntimeError("one_exact_target_body_required")
    return matches[0]


class FunctionExperiment:
    """Replace only one function CodeType, observe actual frames and restore it."""

    def __init__(self, module, name, expected, mutant, mode, emit):
        self.module, self.name, self.mode, self.emit = module, name, mode, emit
        self.function = vars(module)[name]
        if not isinstance(self.function, FunctionType):
            raise RuntimeError("target_not_python_function")
        if self.function.__globals__ is not vars(module) or self.function.__code__ != expected:
            raise RuntimeError("original_target_source_or_globals_mismatch")
        self.original = self.function.__code__
        self.selected = mutant if mode == "mutant" else self.original
        if self.original.co_freevars != self.selected.co_freevars:
            raise RuntimeError("target_closure_mismatch")
        self.tool_id = None
        self.active = False
        self.errors = []
        self.starts = 0
        self.falsified_premise_seen = False
        self.restored = False

    def _record(self, kind, **values):
        try:
            self.emit({"event": kind, "pid": os.getpid(), "mode": self.mode, **values})
        except Exception as exc:
            self.errors.append({"event": kind, "capture_error": type(exc).__name__})
            sys.stderr.write("B194_CAPTURE_ERROR=" + type(exc).__name__ + "\n")

    def _observe(self, kind, code):
        try:
            frame = sys._getframe(2)
            if frame.f_code is not code or code is not self.selected:
                raise RuntimeError("actual_target_frame_mismatch")
            if frame.f_globals is not vars(self.module):
                raise RuntimeError("actual_target_globals_mismatch")
            report = frame.f_locals.get("report")
            ledger = report.get("draw_outcome_provenance", {}) if isinstance(report, dict) else {}
            limits = frame.f_locals.get("limitations")
            state = {
                "requested": ledger.get("requested_draw_count"),
                "attempted": ledger.get("attempted_draw_count"),
                "successful": ledger.get("successful_draw_count"),
                "unattempted": ledger.get("unattempted_draw_count"),
                "denominator_complete": ledger.get("outcome_denominator_complete"),
                "failure_record_count": len(ledger["failure_records"])
                if isinstance(ledger.get("failure_records"), list) else None,
            }
            if kind == "actual_start":
                self.starts += 1
                records = ledger.get("failure_records")
                indexes = {row.get("draw_index") for row in records if isinstance(row, dict)} if isinstance(records, list) else set()
                valid_indexes = (
                    isinstance(records, list) and len(indexes) == len(records)
                    and all(type(value) is int and 0 <= value < state["attempted"] for value in indexes)
                )
                counts_typed = all(type(state[key]) is int for key in ("requested", "attempted", "successful", "unattempted"))
                distinct_count = len(indexes) if valid_indexes else None
                state["recomputed_successes"] = state["attempted"] - distinct_count if counts_typed and distinct_count is not None else None
                self.falsified_premise_seen |= bool(
                    counts_typed and valid_indexes and state["requested"] > 0
                    and state["attempted"] <= state["requested"]
                    and state["unattempted"] == state["requested"] - state["attempted"]
                    and state["successful"] != state["recomputed_successes"]
                )
            self._record(
                kind, code_filename=code.co_filename, code_qualname=code.co_qualname,
                code_sha256=_sha(marshal.dumps(code)),
                code_identity_is_admitted_object=code is self.selected,
                module=self.module.__name__, globals_file=frame.f_globals.get("__file__"),
                thread_id=threading.get_ident(), premise=state,
                limitations=list(limits) if isinstance(limits, list) else None,
            )
        except Exception as exc:
            self.errors.append({"event": kind, "capture_error": type(exc).__name__})
            sys.stderr.write("B194_OBSERVER_ERROR=" + type(exc).__name__ + "\n")

    def _start(self, code, offset):
        del offset
        self._observe("actual_start", code)

    def _return(self, code, offset, value):
        del offset, value
        self._observe("actual_return", code)

    def install(self):
        if sys.implementation.name != "cpython" or sys.version_info[:2] != (3, 14):
            raise RuntimeError("CPython3_14_required")
        if sys.getprofile() is not None or threading.getprofile() is not None:
            raise RuntimeError("existing_profiler_not_replaced")
        free = next((n for n in (5, 4) if sys.monitoring.get_tool(n) is None), None)
        if free is None:
            raise RuntimeError("no_unused_bounded_monitor_slot")
        sys.monitoring.use_tool_id(free, "b194-single-function-experiment")
        self.tool_id = free
        try:
            sys.monitoring.register_callback(free, sys.monitoring.events.PY_START, self._start)
            sys.monitoring.register_callback(free, sys.monitoring.events.PY_RETURN, self._return)
            self.function.__code__ = self.selected
            self.active = True
            sys.monitoring.set_local_events(
                free, self.selected,
                sys.monitoring.events.PY_START | sys.monitoring.events.PY_RETURN,
            )
            self._record("installed", original_code_sha256=_sha(marshal.dumps(self.original)),
                         selected_code_sha256=_sha(marshal.dumps(self.selected)),
                         module_attribute_is_original_function=vars(self.module)[self.name] is self.function,
                         selected_code_source="declared RAW mutant" if self.mode == "mutant" else "canonical original")
        except Exception:
            self.restore()
            raise

    def restore(self):
        if self.tool_id is not None:
            sys.monitoring.set_local_events(self.tool_id, self.selected, 0)
            sys.monitoring.register_callback(self.tool_id, sys.monitoring.events.PY_START, None)
            sys.monitoring.register_callback(self.tool_id, sys.monitoring.events.PY_RETURN, None)
            sys.monitoring.free_tool_id(self.tool_id)
            self.tool_id = None
        if self.active:
            if self.function.__code__ is self.selected:
                self.function.__code__ = self.original
            else:
                self.errors.append({"reason": "runtime_code_restoration_conflict"})
            self.active = False
        self.restored = (
            vars(self.module).get(self.name) is self.function
            and self.function.__code__ is self.original
        )
        self._record("restored", exact_original_CodeType_identity=self.restored,
                     original_code_sha256=_sha(marshal.dumps(self.original)))


class Runtime:
    """Bind this case-local experiment to immutable source and exact output paths."""

    def __init__(self):
        self.root = Path(os.environ["E02_B194_ROOT"]).resolve(strict=True)
        self.binding_path = Path(os.environ["E02_B194_BINDING"]).resolve(strict=True)
        self.binding_bytes = self.binding_path.read_bytes()
        if _sha(self.binding_bytes) != os.environ["E02_B194_BINDING_SHA256"]:
            raise RuntimeError("binding_hash_mismatch")
        self.binding = json.loads(self.binding_bytes)
        self.mode = os.environ["E02_B194_MODE"]
        if self.mode not in {"mutant", "restored"}:
            raise RuntimeError("mode_must_be_mutant_or_restored")
        self.case_root = Path(os.environ["E02_B194_CASE_ROOT"]).resolve(strict=True)
        self.output = Path(os.environ["E02_B194_EVIDENCE"]).resolve()
        if not self.output.is_relative_to(self.case_root) or self.output == self.case_root:
            raise RuntimeError("output_not_within_existing_case")
        self.output.mkdir(mode=0o700, exist_ok=False)
        self.events = self.output / "events.jsonl"
        self.experiment = None
        self.outcomes = []
        self.errors = []
        self.owner = self.root / self.binding["owner_path"]
        for key, expected in [("HEAD", self.binding["base_commit"]),
                              ("HEAD^{tree}", self.binding["base_tree"])]:
            actual = subprocess.check_output(["git", "rev-parse", key], cwd=self.root, text=True).strip()
            if actual != expected:
                raise RuntimeError("source_identity_mismatch:" + key)
        self.source_before = self.owner.read_bytes()
        if _sha(Path(__file__).read_bytes()) != self.binding["plugin_sha256"]:
            raise RuntimeError("plugin_source_hash_mismatch")
        for row in self.binding["static_pins"]:
            if _sha((self.root / row["path"]).read_bytes()) != row["sha256"]:
                raise RuntimeError("source_pin_mismatch:" + row["path"])
        mutant_path = self.root / self.binding["mutant_path"]
        mutant_bytes = mutant_path.read_bytes()
        if _sha(mutant_bytes) != self.binding["mutant_sha256"]:
            raise RuntimeError("mutant_source_hash_mismatch")
        name = self.binding["owner_function"]
        self.original_code = _function_code(self.source_before, str(self.owner), name)
        self.mutant_code = _function_code(mutant_bytes, str(mutant_path), name)
        self.record({"event": "admitted", "pid": os.getpid(), "mode": self.mode,
                     "source_commit": self.binding["base_commit"], "source_tree": self.binding["base_tree"],
                     "binding_sha256": _sha(self.binding_bytes),
                     "plugin_sha256": _sha(Path(__file__).read_bytes()),
                     "owner_sha256": _sha(self.source_before),
                     "mutant_sha256": _sha(mutant_bytes),
                     "qualification": "selected explicit experimental code; RAW helper outside Git custody; global census NE"})

    def record(self, record):
        with self.events.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(record, sort_keys=True) + "\n")

    def install(self):
        module = importlib.import_module(self.binding["owner_module"])
        if Path(module.__file__).resolve() != self.owner or Path(module.__spec__.origin).resolve() != self.owner:
            raise RuntimeError("owner_module_origin_mismatch")
        self.experiment = FunctionExperiment(
            module, self.binding["owner_function"], self.original_code,
            self.mutant_code, self.mode, self.record,
        )
        self.experiment.install()

    def finish(self, exitstatus):
        exp = self.experiment
        original_bytes_restored = self.owner.read_bytes() == self.source_before
        input_drift = []
        for row in self.binding["static_pins"]:
            if _sha((self.root / row["path"]).read_bytes()) != row["sha256"]:
                input_drift.append(row["path"])
        if _sha(Path(__file__).read_bytes()) != self.binding["plugin_sha256"]:
            input_drift.append("plugin")
        if _sha((self.root / self.binding["mutant_path"]).read_bytes()) != self.binding["mutant_sha256"]:
            input_drift.append("mutant")
        if self.binding_path.read_bytes() != self.binding_bytes:
            input_drift.append("binding")
        status = "OBSERVED" if exp and exp.starts and exp.falsified_premise_seen and exp.restored and not exp.errors and original_bytes_restored and not input_drift else "QUALIFICATION_ERROR"
        receipt = {"schema": "e02-b194-case-local-function-receipt-v1", "mode": self.mode,
                   "pid": os.getpid(), "source_commit": self.binding["base_commit"],
                   "source_tree": self.binding["base_tree"], "pytest_exitstatus": int(exitstatus),
                   "actual_test_reports": self.outcomes, "status": status,
                   "actual_target_starts": exp.starts if exp else 0,
                   "falsified_premise_actually_reached": exp.falsified_premise_seen if exp else False,
                   "runtime_original_CodeType_restored": exp.restored if exp else False,
                   "canonical_owner_bytes_equal_before_after": original_bytes_restored,
                   "owner_before_sha256": _sha(self.source_before),
                   "owner_after_sha256": _sha(self.owner.read_bytes()),
                   "observer_errors": (exp.errors if exp else []) + self.errors,
                   "input_drift": input_drift,
                   "source_input_boundary": "before/after equality under sole Root lease; continuous absence NE",
                   "global_code_census": "not_established", "G_acceptance": False, "closure_ids": []}
        (self.output / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")


def pytest_configure(config):
    del config
    global _RUNTIME
    _RUNTIME = Runtime()


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_protocol(item, nextitem):
    del nextitem
    if item.nodeid != _RUNTIME.binding["target_nodeid"]:
        yield
        return
    _RUNTIME.install()
    try:
        yield
    finally:
        _RUNTIME.experiment.restore()


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    if item.nodeid == _RUNTIME.binding["target_nodeid"]:
        report = outcome.get_result()
        _RUNTIME.outcomes.append({"nodeid": item.nodeid, "when": report.when,
                                  "outcome": report.outcome,
                                  "exception_type": type(call.excinfo.value).__name__ if call.excinfo else None})


def pytest_sessionfinish(session, exitstatus):
    del session
    if _RUNTIME is not None:
        _RUNTIME.finish(exitstatus)
