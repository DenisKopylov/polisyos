"""Tiny source-qualified owner probe, not a canonical/native pytest receipt."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
import traceback
from pathlib import Path
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
OLD = HERE.parent / "C05/policy-engine/src/polisyos/core/llm/settlement.py"
NEW = HERE / "policy-engine/src/polisyos/core/llm/settlement.py"


def load(path: Path, name: str, *, remove_expiry: bool = False):
    source = path.read_text()
    if remove_expiry:
        needle = "if retained.expires_at <= now:"
        assert source.count(needle) == 1
        source = source.replace(needle, "if False and retained.expires_at <= now:")
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    exec(compile(source, str(path), "exec"), module.__dict__)
    return module


class Client:
    pass


def retained_lifecycle(module, ttl: float) -> None:
    clock = [100.0]
    module.time = SimpleNamespace(monotonic=lambda: clock[0])
    client = Client()
    owner = module._CacheReuseOwner(client)
    request, key, origin = "probe-request", "probe-key", "probe-origin"
    digest = hashlib.sha256(b"actual result body").hexdigest()
    reg = owner.register_request(("fixture-scope",), request, "probe-producer")
    owner.bind_request_key(reg, key)
    owner.dispatch(reg, "probe-producer")
    outcome = owner.settle_flight(
        registrations=(reg,), cache_key=key, request_digest=request,
        producer_attempt_id="probe-producer", terminal="success", origin_event_id=origin,
        response_digest=digest, retain_for_s=ttl,
    )
    owner.release_flight((reg,), outcome)
    if ttl:
        proof = owner.issue(key, request, "initial-reuse", origin,
                            response_identity=1, response_digest=digest)
        assert owner.verify_provenance(proof)
        clock[0] += ttl / 2
        proof = owner.issue(key, request, "later-reuse", origin,
                            response_identity=2, response_digest=digest)
        assert owner.verify_provenance(proof)
    clock[0] = 100 + ttl
    try:
        owner.issue(key, request, "expired-reuse", origin,
                    response_identity=3, response_digest=digest)
    except ValueError as error:
        assert "retained successful producer event" in str(error)
    else:
        raise AssertionError("origin remained reusable at the producer retention deadline")
    assert not owner._published


def invalid_ttl(module, ttl: float) -> None:
    client = Client()
    owner = module._CacheReuseOwner(client)
    reg = owner.register_request(("fixture-scope",), "request", "producer")
    owner.bind_request_key(reg, "key")
    owner.dispatch(reg, "producer")
    try:
        owner.settle_flight(
            registrations=(reg,), cache_key="key", request_digest="request",
            producer_attempt_id="producer", terminal="success", origin_event_id="origin",
            response_digest=hashlib.sha256(b"result").hexdigest(), retain_for_s=ttl,
        )
    except ValueError as error:
        assert "finite and nonnegative" in str(error)
    else:
        raise AssertionError("invalid TTL was admitted")
    assert not owner._outcomes and not owner._published


def main() -> None:
    print(json.dumps({
        "kind": "isolated_stdlib_only_actual_core_owner_probe",
        "base_sha256": hashlib.sha256(OLD.read_bytes()).hexdigest(),
        "successor_sha256": hashlib.sha256(NEW.read_bytes()).hexdigest(),
        "canonical_runtime_imports": False,
        "canonical_native_pytest": "UNRUN",
    }, sort_keys=True))
    old = load(OLD, "c05_d1_old_owner")
    try:
        retained_lifecycle(old, 2.0)
    except IndexError:
        print("BASE_EXPECTED_FAIL: real settle_flight reaches missing expiry tuple item")
        traceback.print_exc(file=sys.stdout)
    else:
        raise AssertionError("frozen D1 baseline did not reproduce")
    new = load(NEW, "c05_d1_new_owner")
    for ttl in (2.0, 0.0):
        retained_lifecycle(new, ttl)
        print(f"SUCCESSOR_PASS: real settle/release/retained reuse/expiry, ttl={ttl}")
    for ttl in (float("nan"), float("inf"), float("-inf"), -1.0):
        invalid_ttl(new, ttl)
        print(f"SUCCESSOR_PASS: invalid TTL rejected before publication, ttl={ttl}")
    removed = load(NEW, "c05_d1_no_expiry_owner", remove_expiry=True)
    try:
        retained_lifecycle(removed, 2.0)
    except AssertionError as error:
        assert "producer retention deadline" in str(error)
        print("REMOVAL_EXPECTED_FAIL: expiry predicate removed while record/markers remain")
        traceback.print_exc(file=sys.stdout)
    else:
        raise AssertionError("expiry removal did not falsify the actual owner behavior")
    print("PROBE_EXIT: 0; scope remains isolated owner behavior, not composed native/session/HTTP acceptance")


if __name__ == "__main__":
    main()
