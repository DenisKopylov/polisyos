"""Freeze source frame and rebound removal proposals without running product code."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import re
import subprocess

ROOT=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
HERE=Path(__file__).resolve().parent
R2=HERE.parent/'C48-native-two-workflow-positive-r2'
S='policy-engine/src/polisyos/scientist/nodes/builtins/decide/policy_runtime_method_metrics.py'
H='policy-engine/tests/unit/runtime/http/test_observational_method_runtime.py'
U='policy-engine/tests/unit/scientist/nodes/builtins/decide/test_policy_runtime_comparison_environment.py'
sha=lambda b:hashlib.sha256(b).hexdigest()
source=(HERE/'postimage'/S).read_text()
http=(HERE/'postimage'/H).read_text()
unit=(HERE/'postimage'/U).read_text()
# Release companion: no new schema or API, changed comparison hash/replay semantics.
release='policy-engine/release-fragments/unreleased/2026-10-28-e02-comparison-environment-lineage.toml'
release_text='''id = "2026-10-28-e02-comparison-environment-lineage"
title = "Reconcile selected environment plan before candidate comparison"
type = "changed"
component = "scientist-search"
owner = "team-policyos-runtime"
summary = "The bounded ex-ante candidate comparison reconciles each captured environment against its exact selected plan before omitting the run-specific plan ID. Other environment semantics remain part of comparability."
evidence = ["tests/unit/scientist/nodes/builtins/decide/test_policy_runtime_comparison_environment.py", "tests/unit/runtime/http/test_observational_method_runtime.py"]
change_class = "internal reader behavior"
surface_classification = "internal: completed ex-ante candidate comparison; public_experimental: existing Runtime method-metric-comparison projection"
compatibility = "No DTO, schema, endpoint or client shape changes. Comparison digests and the verifier implementation digest change; old selected projections require fresh owner replay. Unsupported environment metadata or unresolved plan identity remains limited."
migration = "Reissue method-metric projections through the current producer and current verifier, then replay candidate comparisons. Preserve original environment and plan artifacts."
limitations = "Candidate-only paired model-input contrast; generic calibration, observation-unit/same-ticket, lesson/VOI and C53 authority remain open. Authored controls are not runtime or closure evidence."
generated_client_compatibility = "unchanged_wire_shape; verify existing generated contracts separately"
public_surface_inventory_reviewed = false
'''
p=HERE/'postimage'/release;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(release_text)
# Canonical application patch includes the previously reviewed r2 test delta.
combined=''
for path,after in ((S,source),(U,unit),(H,http),(release,release_text)):
 before=(ROOT/path).read_text() if (ROOT/path).exists() else ''
 combined+=''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='a/'+path if before else '/dev/null',tofile='b/'+path))
(HERE/'combined.patch').write_text(combined)
check=subprocess.run(['git','apply','--check','--',str(HERE/'combined.patch')],cwd=ROOT,capture_output=True)
assert check.returncode==0,check.stderr
# Derive the entire prior control inventory, not a hand-selected subset.
old_controls=ROOT/'LOCAL/raw/e02-execution-20261027/repairs/C48-r5-a8-full-context-r1/controls-rebound.json'
controls=json.loads(old_controls.read_text())

def apply_hunks(text, patch):
 lines=patch.splitlines(keepends=True);out=text
 starts=[i for i,line in enumerate(lines) if line.startswith('@@')]+[len(lines)]
 for i,j in zip(starts,starts[1:]):
  hunk=lines[i+1:j]
  before=''.join(line[1:] for line in hunk if line.startswith((' ','-')))
  after=''.join(line[1:] for line in hunk if line.startswith((' ','+')))
  assert out.count(before)==1, before[:100]
  out=out.replace(before,after,1)
 return out

for case in controls['cases']:
 if case['source']==S:
  old_patch=(ROOT/case['patch_source']).read_text()
  assert sha(old_patch.encode())==case['patch_sha256']
  mutated=apply_hunks(source,old_patch)
  patch=''.join(difflib.unified_diff(source.splitlines(keepends=True),mutated.splitlines(keepends=True),fromfile='a/'+S,tofile='b/'+S))
  path=HERE/'removals'/(case['id']+'.patch');path.parent.mkdir(parents=True,exist_ok=True);path.write_text(patch)
  case.update(source_sha256=sha(source.encode()),mutant_sha256=sha(mutated.encode()),patch_source=str(path.relative_to(ROOT)),patch_sha256=sha(patch.encode()),mutant_git_blob=hashlib.sha1(b'blob '+str(len(mutated.encode())).encode()+b'\0'+mutated.encode()).hexdigest(),disposition='Rebound to environment-plan reconciliation source; semantic adequacy still UNRUN')
 if case.get('test_source')==H:
  case['test_sha256']=sha(http.encode())
 case['execution']='UNRUN'
# Removal of the complete new admission invariant leaves all marker-bearing helper code.
old='''                comparison_environment = _ex_ante_comparison_environment(
                    raw_environment,
                    manifest=environment_manifest,
                    plan_ref=plan_ref,
                )
'''
new='''                comparison_environment = {
                    **{key: value for key, value in raw_environment.items() if key != "captured_at"},
                    "custom_metadata": {
                        key: value
                        for key, value in raw_environment["custom_metadata"].items()
                        if key != "exec_plan_id"
                    },
                }
'''
assert source.count(old)==1
mutant=source.replace(old,new)
removal=''.join(difflib.unified_diff(source.splitlines(keepends=True),mutant.splitlines(keepends=True),fromfile='a/'+S,tofile='b/'+S))
p=HERE/'removals/environment-plan-reconciliation.patch';p.write_text(removal)
controls['cases'].append({'id':'environment-plan-reconciliation','source':S,'source_sha256':sha(source.encode()),'patch_source':str(p.relative_to(ROOT)),'patch_sha256':sha(removal.encode()),'mutant_sha256':sha(mutant.encode()),'selectors':[U.removeprefix('policy-engine/')+'::test_ranking_refuses_environment_with_unreconciled_plan_or_unknown_metadata'],'test_source':U,'test_sha256':sha(unit.encode()),'execution':'UNRUN','disposition':'Remove call, retain helper/markers; negative ranking controls must fail on status/value, never on changed reason only'})
controls['denominator']=len(controls['cases'])
controls['status']='SOURCE REBOUND; all behavior and removals UNRUN'
(HERE/'controls-rebound.json').write_text(json.dumps(controls,indent=2)+'\n')
http_control=json.loads((R2/'http-control-rebind.json').read_text());http_control['case']['test_sha256']=sha(http.encode());http_control['case']['disposition']='Rebound to sparse r2 + actual environment-plan lineage assertions; UNRUN'
(HERE/'http-control-rebind.json').write_text(json.dumps(http_control,indent=2)+'\n')
frame=json.loads((R2/'source-bindings.json').read_text())
expected={S:sha(source.encode()),H:sha(http.encode()),U:sha(unit.encode()),release:sha(release_text.encode())}
entries=frame['selected_paths_and_explicit_conftest_absences']
for row in entries:
 if row['path'] in expected:
  row['expected_for_pilot']=expected.pop(row['path'])
for path,value in expected.items():
 entries.append({'path':path,'baseline':None,'expected_for_pilot':value,'purpose':'new source/test/release companion for reconciled environment comparison'})
for path in ('policy-engine/src/polisyos/core/artifacts/_env_models.py','policy-engine/src/polisyos/foundry/execute/_internal/graph/__init__.py'):
 if not any(row['path']==path for row in entries):
  digest=sha((ROOT/path).read_bytes());entries.append({'path':path,'baseline':digest,'expected_for_pilot':digest,'purpose':'exact environment model and actual Foundry environment producer'})
frame['selected_path_count']=len(entries)
frame['scope']+=' Environment-plan reconciliation source/test/release companion and direct environment model/producer included. C71 composition changes require rebind; this frame refuses them.'
(HERE/'source-bindings.json').write_text(json.dumps(frame,indent=2)+'\n')
framehash=sha((HERE/'source-bindings.json').read_bytes())
prepare=(R2/'prepare_plan.py').read_text().replace('936eef0c5dd65d1500bd3369d62f504206233a9c0af103d964fc562603e73c72',framehash).replace('test-only\npatch','source/test\npatch')
(HERE/'prepare_plan.py').write_text(prepare)
(HERE/'check_outer_guard.py').write_bytes((R2/'check_outer_guard.py').read_bytes())
# Static check all three complete authored Python postimages with canonical names/config.
checks=[]
for path in (S,U,H):
 data=(HERE/'postimage'/path).read_bytes();ast.parse(data)
 for mode in ('check','format'):
  argv=['.venv/bin/python','-m','ruff',mode,'--no-cache']+(['--check'] if mode=='format' else [])+['--stdin-filename',path.removeprefix('policy-engine/'),'-']
  result=subprocess.run(argv,cwd=ROOT/'policy-engine',input=data,capture_output=True)
  assert result.returncode==0,result.stdout+result.stderr
  checks.append({'path':path,'argv':argv,'exit':result.returncode,'output':(result.stdout+result.stderr).decode()})
(HERE/'static-checks.json').write_text(json.dumps({'ast':'PASS (three full postimages; no imports)','ruff':checks,'git_apply_check':{'exit':check.returncode,'output':(check.stdout+check.stderr).decode()},'product_imports':'NONE','runtime_tests_removals':'UNRUN'},indent=2)+'\n')
print(json.dumps({'combined_patch':sha(combined.encode()),'source_frame':framehash,'path_entries':len(entries),'control_entries':len(controls['cases'])},indent=2))
