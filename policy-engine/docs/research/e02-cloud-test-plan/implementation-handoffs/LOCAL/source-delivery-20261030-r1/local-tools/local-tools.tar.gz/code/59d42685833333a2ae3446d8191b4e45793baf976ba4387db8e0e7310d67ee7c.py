from pathlib import Path
p=Path('LOCAL/raw/e02-execution-20261027/repairs/C32-r3/policy-engine/tests/unit/runtime/quality/test_catalog_source_identity.py');s=p.read_text();s=s.replace('def _selected_fixture(tmp_path: Path) -> tuple[Path, Path, CatalogServingSourcePaths]:','''def _selected_fixture(
    tmp_path: Path, *, populated: bool = False
) -> tuple[Path, Path, CatalogServingSourcePaths]:''');s=s.replace('''        connection.execute("CREATE TABLE ds_observations(canonical_var VARCHAR)")''','''        connection.execute("""CREATE TABLE ds_observations(
            canonical_var VARCHAR, country_code VARCHAR, year INTEGER,
            survey_year INTEGER, wave INTEGER, value DOUBLE,
            dataset_id VARCHAR, observation_id VARCHAR, condition_json VARCHAR
        )""")
        if populated:
            connection.executemany(
                "INSERT INTO ds_observations VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                [(_VARIABLE, "UA", 2020 + i, None, None, float(i),
                  "controlled-data", f"controlled-observation-{i}",
                  '{"unit":"synthetic index"}') for i in range(8)],
            )''');s=s.replace('connection.execute("INSERT INTO ds_observations VALUES (?)", [_VARIABLE])','connection.execute("INSERT INTO ds_observations(canonical_var) VALUES (?)", [_VARIABLE])');p.write_text(s)
