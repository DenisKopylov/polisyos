"""Add localhost TCP fixture allowances to one admitted R2 plan.

Reads the preparation plan and writes the adapted plan only under this RAW folder.
It does not run tests or modify source, index, refs, or the D dossier.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
R = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
P = R / "policy-engine"
D = P / "docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1"
BASELINE_SHA256 = "e32b29d96c194caa1b6d22981823771d1f3b618dd5c73d4956f61bde4fb2f6db"
FRAGMENT_SUFFIX = (
    '(allow network-bind (local tcp "localhost:*"))\n'
    '(allow network-inbound (local tcp "localhost:*"))\n'
    '(allow network-outbound (remote tcp "localhost:*"))\n'
)
PROXY_KEYS = {"http_proxy", "https_proxy", "all_proxy", "no_proxy"}
APPROVED_NETWORK_SELECTORS = {
    "tests/integration/runtime/http/test_registered_sql_live_grant.py::test_real_sql_workflows_recheck_current_use_on_every_debug_get",
    "tests/unit/remediation/test_dfk_02.py::test_warm_and_fresh_catalog_consumers_reconcile_same_id_source_policy",
    "tests/unit/remediation/test_dfk_02.py::test_fresh_catalog_consumer_fails_closed_on_disabled_seed_without_index_mutation",
}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def adapt(plan: dict[str, Any], case_id: str) -> dict[str, Any]:
    """Return the TC/C105+I4 plan with a validated local TCP profile delta."""
    nodes = plan["nodes"]
    assert nodes and len(nodes) == len(set(nodes)), "selection must be nonempty and duplicate-free"
    assert set(nodes) <= APPROVED_NETWORK_SELECTORS, "selection contains a test outside the three approved local-network consumers"
    fragment = plan["sandbox_profile_fragment"]
    assert sha256(fragment.encode()) == plan["sandbox_profile_fragment_sha256"] == BASELINE_SHA256
    assert fragment.startswith("(deny network*)\n") and fragment.count("(deny network*)") == 1
    extra_env = plan.get("extra_env", {})
    assert not (set(map(str.lower, extra_env)) & PROXY_KEYS), "proxy environment is outside this local fixture plan"

    adapted_fragment = fragment + FRAGMENT_SUFFIX
    output_dir = D / case_id
    profile = (
        '(version 1)\n(allow default)\n(deny file-write*)\n'
        f'(allow file-write* (subpath {json.dumps(str(output_dir))}))\n'
        '(allow file-write* (literal "/dev/null"))\n'
        + adapted_fragment
    )
    result = dict(plan)
    result["case_id"] = case_id
    result["sandbox_profile_fragment"] = adapted_fragment
    result["sandbox_profile_fragment_sha256"] = sha256(adapted_fragment.encode())
    result["sandbox_profile_text"] = profile
    result["sandbox_profile_sha256"] = sha256(profile.encode())
    result["scope"] += (
        "; harness fixture transport: allow TCP bind/inbound/outbound with a localhost address filter for approved local-network selectors, "
        "preserve deny network* for non-local communication and frozen production-data rules; "
        "Seatbelt localhost includes any local address, so wildcard/IPv6 local binds are an explicit harness residual"
    )
    result["harness_environment_limitations"] = [
        "SBPL localhost filters do not isolate the loopback interface: wildcard and IPv6 local TCP binds pass the retained witness; other local-address TCP endpoints may also match.",
        "Approved fixture selectors bind/address 127.0.0.1 with ephemeral ports.",
        "Non-local network operations remain denied; production-data file-read rules are retained byte-for-byte.",
    ]
    result["extra_env"] = extra_env  # Keep the runner's fresh allowlist; no proxy bypass was needed.
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("prepared_plan", type=Path, help="plan emitted by prepare_root_native_case_r2.py")
    parser.add_argument("--case-id", required=True)
    parser.add_argument("--output", type=Path, help="output JSON; must remain in this repair RAW folder")
    args = parser.parse_args()

    prepared_path = args.prepared_plan.resolve(strict=True)
    assert prepared_path.parent == D, "expected the standard R2 plan in the audited D dossier"
    assert args.case_id and all(c.isalnum() or c in "-_" for c in args.case_id)
    output_path = (args.output or HERE / f"{args.case_id}.json").resolve()
    assert output_path.parent == HERE, "adapted plan output must remain in this repair RAW folder"
    assert not output_path.exists(), f"refusing to overwrite {output_path}"
    assert not (D / args.case_id).exists(), "runner output directory already exists"
    assert not (D / f"{args.case_id}.json").exists(), "runner plan destination already exists"

    result = adapt(json.loads(prepared_path.read_text()), args.case_id)
    output_path.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
    original_fragment = json.loads(prepared_path.read_text())["sandbox_profile_fragment"]
    print(json.dumps({
        "status": "plan_prepared_for_root_copy",
        "output": str(output_path),
        "sha256": sha256(output_path.read_bytes()),
        "case_id": args.case_id,
        "source_head": result["source_head"],
        "nodes": len(result["nodes"]),
        "extra_env_unchanged": True,
        "production_data_rules_unchanged": original_fragment == result["sandbox_profile_fragment"].removesuffix(FRAGMENT_SUFFIX),
        "product_tests_run": False,
    }, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
