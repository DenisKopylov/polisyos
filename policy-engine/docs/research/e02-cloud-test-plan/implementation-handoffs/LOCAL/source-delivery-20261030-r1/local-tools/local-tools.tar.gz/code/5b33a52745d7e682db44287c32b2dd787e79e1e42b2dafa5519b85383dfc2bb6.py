"""Stream the real controller, then check delivered bytes from the returned tree."""
from __future__ import annotations
import argparse, gzip, hashlib, json, os, subprocess, sys, threading, time
from pathlib import Path

def digest(data):
    return hashlib.sha256(data).hexdigest()

def dump(path, obj):
    path.write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n")

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--repo", type=Path, required=True)
    p.add_argument("--run", type=Path, required=True)
    p.add_argument("--return-dir", type=Path, required=True)
    p.add_argument("--app-python", type=Path, required=True)
    p.add_argument("--uv", type=Path, required=True)
    p.add_argument("--config", type=Path, required=True)
    p.add_argument("--controller", type=Path, required=True)
    p.add_argument("--scratch-limit-bytes", type=int, default=3221225472)
    args = p.parse_args()
    root, out = args.repo.resolve(), args.return_dir.resolve()
    assert out.parent == root and out.is_dir(), "preflight must create the repo-root return directory"
    assert not args.run.resolve().is_relative_to(root) and not args.run.exists()
    assert (out / "transport-probe.txt").read_bytes() == b"policyos-i2-linux-managed-return-probe\n"
    preflight = json.loads((out / "preflight/preflight.json").read_bytes())
    assert preflight["outcome"] == "READY" and preflight["app_python"] == str(args.app_python)
    git_env = dict(os.environ, GIT_OPTIONAL_LOCKS="0")
    check = subprocess.run(["git", "check-ignore", "-q", str(out / "transport-probe.txt")],
                           cwd=root, env=git_env)
    assert check.returncode == 1, "managed probe is ignored or Git failed"
    status = subprocess.run(["git", "status", "--porcelain", "--untracked-files=all", "--",
                             str(out.relative_to(root))], cwd=root, env=git_env, capture_output=True)
    assert status.returncode == 0 and b"transport-probe.txt" in status.stdout
    dump(out / "transport-preflight.json", {"git_status_stdout_hex": status.stdout.hex(),
         "git_status_stderr_hex": status.stderr.hex(), "check_ignore_exit": check.returncode,
         "probe_sha256": digest((out / "transport-probe.txt").read_bytes()),
         "scope": "local managed-diff visibility only; external readback pending"})
    (out / "launcher.py").write_bytes(Path(__file__).read_bytes())
    (out / "controller.py").write_bytes(args.controller.read_bytes())
    (out / "config.json").write_bytes(args.config.read_bytes())
    spool = args.run.parent / (args.run.name + "-outer-streams")
    assert not spool.exists()
    spool.mkdir(parents=True)
    argv = [str(args.app_python), "-I", "-S", str(args.controller), "--repo", str(root),
            "--run", str(args.run), "--return-dir", str(out), "--app-python", str(args.app_python),
            "--uv", str(args.uv), "--config", str(args.config), "--scratch-limit-bytes",
            str(args.scratch_limit_bytes)]
    event = {"argv": argv, "cwd": str(root), "started": time.time(), "state": "STARTED",
             "launcher_sha256": digest(Path(__file__).read_bytes()),
             "controller_sha256": digest(args.controller.read_bytes()),
             "config_sha256": digest(args.config.read_bytes())}
    dump(out / "outer-command.json", event)
    proc = subprocess.Popen(argv, cwd=root, stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0)
    event["pid"] = proc.pid
    dump(out / "outer-command.json", event)
    io_errors = []
    def pump(pipe, dest, stream):
        try:
            with dest.open("wb") as f:
                forward = True
                while True:
                    chunk = os.read(pipe.fileno(), 65536)
                    if not chunk:
                        break
                    f.write(chunk)
                    f.flush()
                    if forward:
                        try:
                            stream.buffer.write(chunk)
                            stream.buffer.flush()
                        except BaseException as exc:
                            io_errors.append(type(exc).__name__ + ": " + str(exc))
                            forward = False
        except BaseException as exc:
            io_errors.append(type(exc).__name__ + ": " + str(exc))
            pipe.close()
    threads = [threading.Thread(target=pump, args=(proc.stdout, spool / "stdout", sys.stdout)),
               threading.Thread(target=pump, args=(proc.stderr, spool / "stderr", sys.stderr))]
    for thread in threads:
        thread.start()
    code = proc.wait()
    for thread in threads:
        thread.join()
    event.update(state="TERMINAL", ended=time.time(), returncode=code, io_errors=io_errors)
    for stream in ("stdout", "stderr"):
        raw = (spool / stream).read_bytes()
        path = out / ("outer-" + stream + ".gz")
        path.write_bytes(gzip.compress(raw, mtime=0))
        assert gzip.decompress(path.read_bytes()) == raw
        event[stream] = {"delivered_path": path.name, "bytes": len(raw), "sha256": digest(raw)}
    dump(out / "outer-command.json", event)
    failures = []
    try:
        assert code == 0 and not io_errors
        pre_events = json.loads((out / "preflight/commands.json").read_bytes())
        for pre_event in pre_events:
            assert pre_event["state"] == "TERMINAL" and pre_event["pid"] > 0
            for stream in ("stdout", "stderr"):
                row = pre_event[stream]
                raw = gzip.decompress((out / "preflight" / row["path"]).read_bytes())
                assert len(raw) == row["bytes"] and digest(raw) == row["sha256"]
        inner = json.loads((out / "inner-content-gate.json").read_bytes())
        assert inner["outcome"] == "PASS"
        inventory_bytes = (out / "inventory.json").read_bytes()
        assert digest(inventory_bytes) == inner["inventory_sha256"]
        inv = json.loads(inventory_bytes)
        entries = {r["path"]: r for r in inv["files"]}
        assert len(entries) == len(inv["files"])
        for name, row in entries.items():
            path = out / name
            assert path.is_file() and not path.is_symlink()
            packed = path.read_bytes()
            assert len(packed) == row["bytes"] and digest(packed) == row["sha256"]
            raw = gzip.decompress(packed)
            assert len(raw) == row["raw_bytes"] and digest(raw) == row["raw_sha256"]
        def get(path):
            assert path + ".gz" in entries
            return gzip.decompress((out / (path + ".gz")).read_bytes())
        result = json.loads(get("author-result.json"))
        required = {"source-snapshot", "backend", "artifact"} | {
            f"wheel{i}-{arm}" for i in (1, 2) for arm in ("positive", "M1", "restored")}
        assert result["outcome"] == "AUTHOR_PASS"
        assert set(result["required_phases"]) == set(result["actual_phases"]) == required
        for i in (1, 2):
            controls = f"wheel{i}-control-bytes/"
            assert get(controls + "console.bin")
            assert get(controls + "original-scanner.py") == get(controls + "restored-scanner.py")
            assert get(controls + "original-record.csv") == get(controls + "restored-record.csv")
            assert get(controls + "original-record.csv") != get(controls + "mutant-record.csv")
            assert digest(get(controls + "mutant-scanner.py")) == "26fcae7b668aa91a9ca8c6b63ddc02ff673812e340f5b547e87e679630e377fa"
            for arm in ("positive", "M1", "restored"):
                label = f"wheel{i}-{arm}"
                q = json.loads(get(label + "/qualification.json"))
                assert q["cases"] == 28 and q["native_byte_axes"] == 4
                assert q["outcome"] == ("EXPECTED_SEMANTIC_RED" if arm == "M1" else "PASS")
                prefix = label + "/evidence/"
                oracles = [x for x in entries if x.startswith(prefix + "oracle-") and x.endswith(".json.gz")]
                children = [x for x in entries if x.startswith(prefix) and x.endswith("/child-origin.json.gz")]
                assert len(oracles) == len(children) == 28
                for child in children:
                    stem = child[:-len("child-origin.json.gz")]
                    for name in ("command.json.gz", "stdout.txt.gz", "stderr.txt.gz",
                                 "independent-git.json.gz", "selected-input-bytes.json.gz"):
                        assert stem + name in entries
                for name in ("binding.json", "junit.xml", "qualification.json",
                             "evidence/pytest-controller.json"):
                    get(label + "/" + name)
        for path in ("producer.json", "source-freeze.json", "source-snapshot-command.json",
                     "archive-process.json", "q2-logs/git-archive.stderr.bin",
                     "native.json", "wheel-member-comparison.json", "owner-inventory.json",
                     "asset-source-git-reads.json", "build-tools-host-profile.json",
                     "build-tools-requirements.txt", "app-dependency-profile.json",
                     "installed-env-config.json", "adapter.json", "execution-config.json",
                     "observer.py", "observed-sitecustomize.py", "origin-gate.py", "commands.json"):
            get(path)
        assert digest(get("observer.py")) == "4854906bb0e6424f6079b53269a143ebe68cb7c5019ba647d9b734d7c9d1d316"
    except BaseException as exc:
        failures.append(type(exc).__name__ + ": " + str(exc))
    all_files = []
    for path in sorted(out.rglob("*")):
        if not path.is_file() or path.is_symlink() or path.name in {"return-inventory.json", "return-result.json"}:
            continue
        raw = path.read_bytes()
        all_files.append({"path": path.relative_to(out).as_posix(), "bytes": len(raw), "sha256": digest(raw)})
    dump(out / "return-inventory.json", {"files": all_files, "total_bytes": sum(x["bytes"] for x in all_files),
         "planning_budget_not_omission_gate": 524288})
    dump(out / "return-result.json", {"outcome": "AUTHOR_PASS" if not failures else "PARTIAL_OR_ERROR",
         "outer_returncode": code, "content_gate_errors": failures,
         "delivered_inventory_sha256": digest((out / "return-inventory.json").read_bytes()),
         "external_delivery_readback": "pending", "independent_review": "pending",
         "G_acceptance": False, "closure_ids": []})
    print("RETURN", "AUTHOR_PASS" if not failures else "PARTIAL_OR_ERROR", failures, flush=True)
    if failures:
        raise SystemExit(1)

if __name__ == "__main__":
    main()
