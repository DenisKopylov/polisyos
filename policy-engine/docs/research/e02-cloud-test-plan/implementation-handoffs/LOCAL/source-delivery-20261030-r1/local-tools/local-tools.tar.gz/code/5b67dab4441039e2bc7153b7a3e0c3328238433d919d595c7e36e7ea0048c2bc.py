from pathlib import Path

out=Path(__file__).resolve().parent
path=Path('policy-engine/src/polisyos/runtime/http/services/control_plane_store.py')
s=(out/'base'/path).read_text()
s=s.replace('from polisyos.runtime.quality.evidence_spine_handoff import (','from polisyos.runtime.quality.event_log import _PreparedDiagnosticEvent, _payload_bytes\nfrom polisyos.runtime.http.services._control_contracts import _ControlJobAdmissionDiagnosticBinding\nfrom polisyos.runtime.quality.evidence_spine_handoff import (',1)
anchor='\n\nclass ControlPlaneStore:'
model='''

@dataclass(frozen=True, slots=True)
class _ControlJobCreationBasis:
    """Unpublished immutable preparation basis, never an event/authorization receipt."""

    job_id: str
    initial_state: Literal["pending", "failed"]
    prepared_at: datetime
    source_payload_json: str
    source_payload_sha256: str
    creation_owner: object
'''
assert s.count(anchor)==1;s=s.replace(anchor,model+anchor)
s=s.replace('        self._human_decision_transaction = threading.local()\n','        self._human_decision_transaction = threading.local()\n        self._creation_plan_owner = object()\n',1)
anchor='    def create_job(\n'
methods='''    def prepare_job_creation(
        self,
        *,
        job_id: str,
        initial_state: Literal["pending", "failed"],
        creation_event_payload: dict[str, Any],
    ) -> _ControlJobCreationBasis:
        """Freeze a creation basis without a SQL row, event ID or recorded timestamp.

        Diagnostic CAS work can use this candidate basis outside a writer lock.
        Only create_job can reconcile the subsequently recorded source event and
        outbox before publishing diagnostics/progress. The basis grants no lease,
        current-source admission, authorization or permission.
        """
        if initial_state not in {"pending", "failed"}:
            raise ValueError("control_job_initial_state_invalid")
        payload = {**creation_event_payload, "state": initial_state}
        if payload.get("job_id") != job_id:
            raise ValueError("control_job_creation_basis_job_mismatch")
        payload_json = json.dumps(payload, sort_keys=True)
        return _ControlJobCreationBasis(
            job_id=job_id,
            initial_state=initial_state,
            prepared_at=_utc_now(),
            source_payload_json=payload_json,
            source_payload_sha256="sha256:" + hashlib.sha256(payload_json.encode()).hexdigest(),
            creation_owner=self._creation_plan_owner,
        )

    def _reconcile_admission_diagnostic_basis(
        self,
        *,
        record: ControlJobRecord,
        source: _ControlJobLifecycleSourceEventRecord,
        event: DiagnosticEvent,
        payload: dict[str, Any],
        binding: _ControlJobAdmissionDiagnosticBinding,
    ) -> None:
        """Bind v2 candidate bytes to actual unique creation/outbox rows with no I/O."""
        scope, _ = self._reconcile_control_job_creation_envelope(record)
        source_refs = tuple(
            source.payload[key]
            for key in ("payload_ref", "capability_manifest_ref")
            if source.payload.get(key) is not None
        )
        expected_scope = {
            "schema_version": "polisyos.runtime.control_execution_scope.v1",
            "status": scope.status,
            "source": "job_admission",
            "limitation_code": (
                None if scope.status == "established"
                else "control_job_execution_scope_not_established"
            ),
        }
        if (
            binding.control_job_id != record.job_id
            or binding.control_run_id != record.run_id
            or binding.source_event_job_state != source.payload.get("state")
            or binding.source_event_payload_sha256 != source.payload_sha256
            or binding.bound_job_record_refs != source_refs
            or source.job_id != record.job_id or source.event_type != "job_created"
            or source.event_id < 1 or source.created_at.tzinfo is None
            or event.job_id != record.job_id or event.run_id != str(record.run_id or "run-unknown")
            or event.phase != "job_admission"
            or event.execution_profile != record.effective_execution_profile
            or event.tenant_id != (scope.tenant_id or "tenant-unknown")
            or event.cell_id != (scope.cell_id or "cell-unknown")
            or "attempt" in payload
            or not _json_values_equal_strict(payload.get("execution_scope"), expected_scope)
        ):
            raise ControlJobExecutionAdmissionError("control_job_admission_diagnostic_basis_mismatch")

    def get_job_admission_diagnostic_source_event_record(
        self, *, event_id: str, payload: dict[str, Any]
    ) -> _ControlJobLifecycleSourceEventRecord:
        """Resolve actual event ID/time from a content-bound v2 diagnostic payload.

        The event-log owner resolves CAS bytes before this DB-only read. This
        result describes historical admission, never a current worker proof.
        """
        digest = "sha256:" + hashlib.sha256(_payload_bytes(payload)).hexdigest()
        binding = _ControlJobAdmissionDiagnosticBinding.model_validate_json(
            json.dumps(payload.get("control_job_execution_binding"), sort_keys=True)
        )
        with self._job_transaction():
            diagnostics = self.list_diagnostic_events(event_id=event_id, limit=2)
            if len(diagnostics) != 1 or diagnostics[0].payload_sha256 != digest:
                raise ControlJobExecutionAdmissionError("control_job_admission_diagnostic_not_bound")
            diagnostic = diagnostics[0]
            record = self.get_job(diagnostic.event.job_id)
            if record is None:
                raise ControlJobExecutionAdmissionError("control_job_admission_job_missing")
            source = self._get_job_created_source_event_record(record.job_id)
            self._reconcile_admission_diagnostic_basis(
                record=record, source=source, event=diagnostic.event, payload=payload, binding=binding
            )
            return source

'''
assert s.count(anchor)==1;s=s.replace(anchor,methods+anchor)
old='''        initial_progress: dict[str, Any] | None = None,
        pre_admission_attempt_id: str | None = None,'''
new='''        initial_progress: dict[str, Any] | None = None,
        creation_basis: _ControlJobCreationBasis | None = None,
        prepared_admission_diagnostics: tuple[_PreparedDiagnosticEvent, ...] = (),
        diagnostic_preparation_failed: bool = False,
        pre_admission_attempt_id: str | None = None,'''
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('''        """Insert a pending or terminally refused job and enqueue its creation event."""''','''        """Publish one job and prepared admission diagnostics atomically with SQL only.

        Snapshot/registry validation and CAS I/O precede the writer transaction.
        The v2 creation basis never supplies actual event IDs or recorded times;
        this owner records them normally, reconciles the actual source/outbox,
        then appends prepared diagnostics and their initial progress links.
        """''',1)
start=s.index('    def create_job(\n');pos=s.index('        created_at = _utc_now()\n',start)
preflight='''        if type(diagnostic_preparation_failed) is not bool:
            raise TypeError("control_job_diagnostic_preparation_status_invalid")
        if creation_basis is None and (prepared_admission_diagnostics or diagnostic_preparation_failed):
            raise ValueError("control_job_diagnostics_require_creation_basis")
        if creation_basis is not None and (
            type(creation_basis) is not _ControlJobCreationBasis
            or creation_basis.creation_owner is not self._creation_plan_owner
            or creation_basis.job_id != job_id or creation_basis.initial_state != initial_state
            or creation_basis.source_payload_json
            != json.dumps({**dict(creation_event_payload or {}), "state": initial_state}, sort_keys=True)
        ):
            raise ValueError("control_job_creation_basis_mismatch")
        # Registry/filesystem reads, parsing and complete payload hashing happen
        # before the SQL lock. No provider callback enters the transaction.
        prepared_values = []
        for prepared in prepared_admission_diagnostics:
            if type(prepared) is not _PreparedDiagnosticEvent:
                raise TypeError("control_job_diagnostic_preparation_type_invalid")
            event, payload = prepared.publication_values()
            if payload is None:
                raise ValueError("control_job_diagnostic_preparation_payload_missing")
            binding = _ControlJobAdmissionDiagnosticBinding.model_validate_json(
                json.dumps(payload.get("control_job_execution_binding"), sort_keys=True)
            )
            prepared_values.append((prepared, event, payload, binding))
'''
s=s[:pos]+preflight+s[pos:]
anchor='''            if pre_admission_attempt_id is not None and pre_admission_outcome is not None:
''';pos=s.index(anchor,start)
publication='''            if creation_basis is not None:
                source = self._get_job_created_source_event_record(job_id)
                if source.payload_sha256 != creation_basis.source_payload_sha256:
                    raise ControlJobExecutionAdmissionError("control_job_creation_basis_content_mismatch")
                scope, _ = self._reconcile_control_job_creation_envelope(record)
                diagnostic_ids: list[str] = []
                authority_withheld = False
                for prepared, event, payload, binding in prepared_values:
                    self._reconcile_admission_diagnostic_basis(
                        record=record, source=source, event=event, payload=payload, binding=binding
                    )
                    if event.event_id in diagnostic_ids or self.list_diagnostic_events(
                        event_id=event.event_id, limit=1
                    ):
                        raise ControlJobExecutionAdmissionError(
                            "control_job_prepared_diagnostic_already_exists"
                        )
                    if event.event_type == "polisyos.runtime.diagnostic.phase_transition.v1":
                        # event_time is outside the CAS payload hash. The job
                        # transition occurs now, not at candidate preparation.
                        event = event.model_copy(update={"event_time": source.created_at})
                    self.append_diagnostic_event(
                        event=event,
                        payload_ref=prepared.payload_ref,
                        payload_inline=payload if prepared.inline_payload else None,
                        payload_sha256=prepared.payload_sha256,
                    )
                    diagnostic_ids.append(event.event_id)
                    authority_withheld |= (
                        event.event_type == "polisyos.runtime.diagnostic.scope_limited.v1"
                    )
                diagnostic_progress: dict[str, Any] = {
                    "diagnostic_event_ids": diagnostic_ids,
                    "diagnostic_event_authority": (
                        "scope_limited" if authority_withheld else "progress_reference_only"
                    ),
                    "diagnostic_event_scope_status": scope.status,
                }
                if scope.status == "not_established":
                    diagnostic_progress["diagnostic_event_limitation_code"] = (
                        "control_job_execution_scope_not_established"
                    )
                if diagnostic_preparation_failed:
                    diagnostic_progress["diagnostic_event_preparation_status"] = "limited"
                    diagnostic_progress["diagnostic_event_preparation_limitation_code"] = (
                        "runtime_diagnostic_event_persistence_failed"
                    )
                self._upsert_progress_unchecked(
                    job_id=job_id, progress={**record.progress, **diagnostic_progress}
                )
                record = self.get_job(job_id)
                if record is None:
                    raise RuntimeError(f"Failed to initialize control job {job_id}")
'''
s=s[:pos]+publication+s[pos:]
p=out/'postimages'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
