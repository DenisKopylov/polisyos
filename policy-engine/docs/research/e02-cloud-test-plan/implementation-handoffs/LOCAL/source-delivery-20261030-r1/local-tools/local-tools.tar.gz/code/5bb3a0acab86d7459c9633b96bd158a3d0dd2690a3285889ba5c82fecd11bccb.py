from pathlib import Path
p=Path('LOCAL/raw/e02-execution-20261027/repairs/C48-ad01-ranked-profile-r1/postimages/policy-engine/src/polisyos/scientist/nodes/builtins/decide/policy_runtime_method_metrics.py')
s=p.read_text()
def replace(old,new):
 global s
 n=s.count(old)
 if n!=1:raise RuntimeError((n,old[:150]))
 s=s.replace(old,new,1)
replace('''    source_tuple: _MethodMetricSourceTuple,
    read_budget: _ProjectionReadBudget,
) -> tuple[MethodMetricObservation, ...]:
    """Resolve and reconcile the whole selected graph → bundle → binding source chain."""''','''    source_tuple: _MethodMetricSourceTuple,
    read_budget: _ProjectionReadBudget,
    comparison_collector: list[dict[str, Any]] | None = None,
) -> tuple[MethodMetricObservation, ...]:
    """Resolve and reconcile the whole selected graph → bundle → binding source chain."""''')
replace('''    environment_loaded = False
    observations: list[MethodMetricObservation] = []
''','''    environment_loaded = False
    comparison_environment: dict[str, Any] | None = None
    observations: list[MethodMetricObservation] = []
''')
replace('''        if not environment_loaded:
            environment_manifest, environment = _load_method_metric_model(
                store,
                ref=environment_ref,
                model=EnvironmentManifest,
                expected_kind="foundry.environment_manifest",
                expected_schema_name="polisyos.core.artifacts.environment.EnvironmentManifest",
                expected_schema_versions={"1.0"},
                max_bytes=MAX_METHOD_METRIC_SOURCE_BYTES,
                read_budget=read_budget,
            )
''','''        if not environment_loaded:
            if comparison_collector is None:
                environment_manifest, environment = _load_method_metric_model(
                    store,
                    ref=environment_ref,
                    model=EnvironmentManifest,
                    expected_kind="foundry.environment_manifest",
                    expected_schema_name="polisyos.core.artifacts.environment.EnvironmentManifest",
                    expected_schema_versions={"1.0"},
                    max_bytes=MAX_METHOD_METRIC_SOURCE_BYTES,
                    read_budget=read_budget,
                )
            else:
                # Retain every selected environment field, including future
                # fields ignored by the typed adapter; only the capture instant
                # is run-specific for this explicitly bounded comparison.
                environment_read = _read_bounded_method_metric_artifact(
                    store, ref=environment_ref, max_bytes=MAX_METHOD_METRIC_SOURCE_BYTES,
                    read_budget=read_budget,
                )
                environment_manifest = environment_read.manifest
                environment = _validate_bounded_method_metric_model(
                    EnvironmentManifest, environment_read,
                    expected_kind="foundry.environment_manifest",
                    expected_schema_name="polisyos.core.artifacts.environment.EnvironmentManifest",
                    expected_schema_versions={"1.0"},
                )
                raw_environment = json.loads(environment_read.raw_payload_bytes)
                if type(raw_environment) is not dict or "captured_at" not in raw_environment:
                    raise _UnestablishedProjectionError("ranking_environment_payload_not_established")
                comparison_environment = {key: value for key, value in raw_environment.items() if key != "captured_at"}
''')
replace('''                        verifier_code_digest=verifier_code_digest,
                    )
                )
        else:
''','''                        verifier_code_digest=verifier_code_digest,
                        comparison_collector=comparison_collector,
                        comparison_environment=comparison_environment,
                    )
                )
        else:
''')
replace('''    adapter_identity: tuple[str, str, str],
    verifier_code_digest: str,
) -> MethodMetricObservation:
    """Build one occurrence row, retaining typed non-observation reasons."""''','''    adapter_identity: tuple[str, str, str],
    verifier_code_digest: str,
    comparison_collector: list[dict[str, Any]] | None = None,
    comparison_environment: dict[str, Any] | None = None,
) -> MethodMetricObservation:
    """Build one occurrence row, retaining typed non-observation reasons."""''')
replace('''    return MethodMetricObservation(
        source_status="observed",
''','''    observation = MethodMetricObservation(
        source_status="observed",
''')
replace('''            "external_legal_permission_not_established",
        ),
    )


def _build_unobserved_method_metric_observation(''','''            "external_legal_permission_not_established",
        ),
    )
    if comparison_collector is not None:
        contract = _ex_ante_rank_comparison_contract(
            observation=observation,
            execution_context=execution_context,
            capture=input_capture,
            environment=comparison_environment,
        )
        if contract is not None:
            comparison_collector.append(contract)
    return observation


def _build_unobserved_method_metric_observation(''')
p.write_text(s)
