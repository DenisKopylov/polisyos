from pathlib import Path
O=Path(__file__).resolve().parent;P=O/'postimages/policy-engine/src/polisyos/foundry/calibration/execution_basis.py';s=P.read_text()
def repl(old,new):
 global s
 assert s.count(old)==1,(old[:80],s.count(old));s=s.replace(old,new)
repl('from pydantic import BaseModel, ConfigDict, Field, model_validator','from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, model_validator')
repl('_SHA256_PATTERN = r"^[0-9a-f]{64}$"','''_SHA256_PATTERN = r"^[0-9a-f]{64}$"
_ORDERED_INPUT_KIND = "foundry.calibration_ordered_input"
_ORDERED_INPUT_SCHEMA = "polisyos.foundry.CalibrationOrderedBatchInput"''')
repl('    profile_kind: Literal["ordered_scalar_mse_v1"] = "ordered_scalar_mse_v1"','''    schema_version: Literal["1.0"] = "1.0"
    authority_purpose: Literal["local_fit_input_only"] = "local_fit_input_only"
    calibration_config_ref: ArtifactRef
    profile_kind: Literal["ordered_scalar_mse_v1"] = "ordered_scalar_mse_v1"''')
repl('    ordered_batch_profile: CalibrationOrderedBatchInput | None = None','''    ordered_batch_input_ref: ArtifactRef | None = Field(default=None, exclude_if=lambda x: x is None)
    ordered_batch_input_sha256: str | None = Field(
        default=None, pattern=_SHA256_PATTERN, exclude_if=lambda x: x is None,
    )
    _resolved_ordered_input: CalibrationOrderedBatchInput | None = PrivateAttr(default=None)
    _resolved_ordered_values: dict[str, Any] | None = PrivateAttr(default=None)

    @property
    def ordered_batch_profile(self) -> CalibrationOrderedBatchInput | None:
        """Return the owner-resolved input, never an unverified inline declaration."""
        return self._resolved_ordered_input''')
repl('''        if (self.schema_version == "1.2") != (self.ordered_batch_profile is not None):
            raise ValueError("v1_2_requires_ordered_batch_profile_and_legacy_versions_forbid_it")''','''        if (self.schema_version == "1.2") != (self.ordered_batch_input_ref is not None):
            raise ValueError("v1_2_requires_selected_ordered_input_and_legacy_versions_forbid_it")
        if (self.ordered_batch_input_ref is not None) != (self.ordered_batch_input_sha256 is not None):
            raise ValueError("ordered_input_ref_and_digest_must_coexist")''')
a=s.index('        if self.ordered_batch_profile is not None:\n');b=s.index('        if any(not _is_sha256(value) for value in self.report_envelope_sha256.values()):',a);s=s[:a]+s[b:]
a=s.index('def reconcile_ordered_batch_inputs(');b=s.index('\n\ndef put_calibration_execution_input_basis(',a)
new='''def _ordered_edge(
    inputs: Sequence[InputRef], role: str, expected: ArtifactRef,
) -> None:
    matches = tuple(edge for edge in inputs if edge.role == role)
    if len(matches) != 1 or (
        matches[0].artifact_id != expected.artifact_id
        or matches[0].manifest_profile_sha256 != expected.manifest_profile_sha256
        or expected.manifest_profile_sha256 is None
    ):
        raise ValueError(f"ordered_input_exact_selected_edge_required:{role}")


def _resolve_ordered_input_values(
    store: ArtifactStore, profile: CalibrationOrderedBatchInput,
    *, inputs: Sequence[InputRef],
) -> dict[str, Any]:
    """Reopen the requested selected config and every row, before fit consumption."""
    from polisyos.core.contracts.foundry import StateSnapshot
    from polisyos.foundry.execute import load_state_snapshot
    from polisyos.ir.analytics.calibration import CalibrationConfig, TargetAlignConfig

    config_ref = profile.calibration_config_ref
    _ordered_edge(inputs, "calibration_config", config_ref)
    manifest = store.get_manifest(config_ref)
    schema = manifest.artifact_schema
    if (manifest.kind != "foundry.calibration_config" or manifest.media_type != "application/json"
        or schema is None or schema.name != "polisyos.ir.CalibrationConfig"
        or not store.verify(config_ref).ok):
        raise ValueError("ordered_input_selected_config_invalid")
    config = CalibrationConfig.model_validate(from_canonical_bytes(store.get_bytes(config_ref)))
    if schema.version != config.schema_version:
        raise ValueError("ordered_input_config_schema_version_mismatch")
    if len(config.targets) != 1:
        raise ValueError("ordered_input_requires_one_configured_target")
    target = config.targets[0]
    if (
        target.target_id != profile.target_id or target.model_metric_path != profile.target_metric_id
        or target.loss.kind != "mse" or target.loss.relative or target.aggregation != "none"
        or target.loss.epsilon != profile.loss_epsilon or target.loss.weight != profile.target_priority
        or target.fabric_query is not None or target.fabric_metric is not None
        or target.align != TargetAlignConfig() or config.seed_strategy != "fixed"
        or config.multi_start is not None or config.grad_norm.enabled
        or config.prior_loss.enabled or config.constraint_loss.enabled
        or config.steps not in (None, len(profile.rows))
        or (config.time_axis is not None and list(config.time_axis) != [float(t) for t in profile.row_times])
    ):
        raise ValueError("ordered_input_selected_config_does_not_match_request")
    roles = tuple(f"ordered_batch_row.{i}" for i in range(len(profile.rows)))
    edges = tuple(edge for edge in inputs if edge.role.startswith("ordered_batch_row."))
    if tuple(edge.role for edge in edges) != roles:
        raise ValueError("ordered_input_row_edges_must_be_complete_and_ordered")
    if len(inputs) != len(profile.rows) + 1:
        raise ValueError("ordered_input_has_unbound_manifest_edges")
    states = []
    for ordinal, (row, edge) in enumerate(zip(profile.rows, edges, strict=True)):
        _ordered_edge(inputs, roles[ordinal], row.state_snapshot_ref)
        if not store.verify(row.state_snapshot_ref).ok:
            raise ValueError("ordered_input_row_integrity_failure")
        snapshot = StateSnapshot.model_validate(
            from_canonical_bytes(store.get_bytes(row.state_snapshot_ref))
        )
        if snapshot.step != profile.row_times[ordinal]:
            raise ValueError("ordered_input_row_schedule_does_not_match_selected_snapshot")
        state = load_state_snapshot(store, snapshot_ref=row.state_snapshot_ref)
        if canonical_input_sha256(state) != row.state_values_sha256:
            raise ValueError("ordered_input_row_state_values_mismatch")
        states.append(state)
    try:
        targets = np.asarray(profile.targets, dtype=np.dtype(profile.targets_dtype))
        weights = np.asarray(profile.weights, dtype=np.dtype(profile.weights_dtype))
        times = np.asarray(profile.row_times, dtype=np.dtype(profile.row_times_dtype))
        keys = np.asarray(profile.row_keys, dtype=np.uint32)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError("ordered_input_array_representation_invalid") from exc
    if tuple(targets.tolist()) != profile.targets or tuple(weights.tolist()) != profile.weights:
        raise ValueError("ordered_input_values_do_not_match_declared_dtypes")
    values = {
        "row_ids": tuple(row.row_id for row in profile.rows),
        "states": jax.tree_util.tree_map(lambda *rows: np.stack(rows), *states),
        "row_times": times, "row_keys": keys,
        "target_path": profile.target_path, "targets": targets, "weights": weights,
    }
    if canonical_input_sha256(values) != profile.consumed_profile_sha256:
        raise ValueError("ordered_input_complete_profile_mismatch")
    return values


def put_calibration_ordered_batch_input(
    store: ArtifactStore, profile: CalibrationOrderedBatchInput,
    *, inputs: list[InputRef],
) -> ArtifactRef:
    """Publish the independently selected input that the producer will reopen and consume."""
    profile = CalibrationOrderedBatchInput.model_validate(profile.model_dump(mode="python"))
    _resolve_ordered_input_values(store, profile, inputs=inputs)
    return store.put_json(profile, PutOptions(
        kind=_ORDERED_INPUT_KIND, media_type="application/json",
        schema=SchemaInfo(name=_ORDERED_INPUT_SCHEMA, version=profile.schema_version), inputs=inputs,
    ), canon_spec=CanonSpec(forbid_floats=False), return_selected_profile=True)


def resolve_calibration_ordered_batch_input(
    store: ArtifactStore, ref: ArtifactRef,
) -> tuple[CalibrationOrderedBatchInput, dict[str, Any]]:
    """Read exact selected input bytes and resolve every bound numerical row."""
    if ref.manifest_profile_sha256 is None:
        raise ValueError("ordered_input_requires_selected_profile")
    manifest = store.get_manifest(ref)
    if (manifest.kind != _ORDERED_INPUT_KIND or manifest.media_type != "application/json"
        or manifest.artifact_schema != SchemaInfo(name=_ORDERED_INPUT_SCHEMA, version="1.0")
        or not store.verify(ref).ok):
        raise ValueError("ordered_input_selected_manifest_invalid")
    profile = CalibrationOrderedBatchInput.model_validate(from_canonical_bytes(store.get_bytes(ref)))
    return profile, _resolve_ordered_input_values(store, profile, inputs=manifest.inputs)


def reconcile_ordered_batch_inputs(
    store: ArtifactStore, basis: CalibrationExecutionInputBasis, *, inputs: Sequence[InputRef],
) -> None:
    """Resolve an independent selected input; the basis cannot declare its own weights or keys."""
    if basis.ordered_batch_input_ref is None:
        return
    ref = basis.ordered_batch_input_ref
    _ordered_edge(inputs, "ordered_batch_input", ref)
    _ordered_edge(inputs, "calibration_config", basis.calibration_config_ref)
    profile, values = resolve_calibration_ordered_batch_input(store, ref)
    if profile.calibration_config_ref != basis.calibration_config_ref:
        raise ValueError("ordered_input_basis_config_ref_mismatch")
    digest = canonical_input_sha256(profile)
    if basis.ordered_batch_input_sha256 != digest:
        raise ValueError("ordered_input_basis_payload_digest_mismatch")
    binding = basis.runtime_input_roster[-1]
    if (binding.input_name != "ordered_batch_profile" or binding.status != "selected_source_matched"
        or binding.source_ref != ref or binding.value_sha256 != digest
        or binding.source_payload_sha256 != digest):
        raise ValueError("ordered_input_runtime_roster_does_not_bind_selected_input")
    if basis.target_order != (profile.target_id,):
        raise ValueError("ordered_input_target_order_mismatch")
    target = basis.target_inputs[0]
    if (target.source_kind != "ordered_batch_profile"
        or canonical_input_sha256(profile.targets) != target.observed_values_sha256
        or calibration_report_time_axis_sha256([float(t) for t in profile.row_times])
        != target.report_time_axis_sha256):
        raise ValueError("ordered_input_report_observation_identity_mismatch")
    basis._resolved_ordered_input = profile
    basis._resolved_ordered_values = values
'''
s=s[:a]+new+s[b:]
s=s.replace('if basis.ordered_batch_profile is not None:', 'if basis.ordered_batch_input_ref is not None:')
repl('    "reconcile_ordered_batch_inputs",','    "reconcile_ordered_batch_inputs",\n    "put_calibration_ordered_batch_input",\n    "resolve_calibration_ordered_batch_input",')
P.write_text(s)
