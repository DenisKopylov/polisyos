"""Run the one authorized source-tool POST with bounded wall time and sampled RSS."""
from pathlib import Path
import json, os, subprocess, sys, time
P=Path(__file__).resolve().parent
R=P.parents[4]
product=R/'policy-engine'
command=[str(product/'.venv/bin/python'),'-B',str(P/'post_and_controls.py')]
start=time.monotonic(); peak=0; max_threads=0; abort=None
env=os.environ.copy()
for key in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","VECLIB_MAXIMUM_THREADS","NUMEXPR_NUM_THREADS"):
    env[key]="1"
with (P/'post-and-controls-r15.stdout.json').open('x') as out, (P/'post-and-controls-r15.stderr.txt').open('x') as err:
    proc=subprocess.Popen(command,cwd=product,stdout=out,stderr=err,env=env)
    while proc.poll() is None:
        sample=subprocess.run(['/bin/ps','-o','rss=','-p',str(proc.pid)],capture_output=True,text=True,check=False)
        rss=int(sample.stdout.strip() or '0')*1024; peak=max(peak,rss)
        threads=subprocess.run(['/bin/ps','-M','-p',str(proc.pid)],capture_output=True,text=True,check=False)
        count=max(0,len(threads.stdout.splitlines())-1); max_threads=max(max_threads,count)
        if time.monotonic()-start>120 or rss>512*1024*1024 or count>1:
            abort='wall' if time.monotonic()-start>120 else ('rss' if rss>512*1024*1024 else 'threads'); proc.kill()
        time.sleep(.05)
    exit_code=proc.wait()
record={'command':command,'cwd':str(product),'exit_code':exit_code,'elapsed_seconds':time.monotonic()-start,'peak_sampled_child_rss_bytes':peak,'max_sampled_child_threads':max_threads,'thread_limit':1,'wall_limit_seconds':120,'rss_limit_bytes':512*1024*1024,'abort':abort}
(P/'post-and-controls-r15.command-result.json').write_text(json.dumps(record,separators=(',',':'))+'\n')
print(json.dumps(record,separators=(',',':')))
raise SystemExit(exit_code if exit_code>=0 else 1)
