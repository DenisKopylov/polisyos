"""Synthetic one-sandbox infrastructure control; never open production content."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
HERE = Path(__file__).resolve().parent
LEXICAL = ROOT / 'policy-engine/production_data'
PHYSICAL = Path('/Users/deniskopylov/polisyos/policy-engine/production_data')


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def fragment(lexical: Path, physical: Path) -> str:
    return '\n'.join([
        '(deny network*)',
        '(deny file-read* (literal ' + json.dumps(str(lexical)) + '))',
        '(deny file-read* (subpath ' + json.dumps(str(lexical)) + '))',
        '(deny file-read* (subpath ' + json.dumps(str(physical)) + '))',
        '',
    ])


def base_profile(out: Path) -> str:
    # Exactly the retained D_R2 child write policy, including its final newline.
    return '(version 1)\n(allow default)\n(deny file-write*)\n(allow file-write* (subpath '+json.dumps(str(out))+'))\n(allow file-write* (literal "/dev/null"))\n'


def main() -> None:
    if len(sys.argv) != 2 or not re.fullmatch(r'[A-Za-z0-9_-]+', sys.argv[1]):
        raise SystemExit('usage: check_single_guard.py UNIQUE_CASE_ID')
    case = sys.argv[1]
    if not LEXICAL.is_symlink() or Path(os.path.realpath(LEXICAL)) != PHYSICAL:
        raise SystemExit('production_data link changed: stop for source/context review')
    out = HERE / ('guard-' + case)
    out.mkdir(exist_ok=False)
    denied = out / 'test-owned-denied'
    denied.mkdir()
    (denied / 'value.txt').write_text('test-owned denied fixture\n')
    link = out / 'test-owned-alias'
    link.symlink_to(denied, target_is_directory=True)
    allowed = out / 'allowed.txt'
    allowed.write_text('test-owned allowed fixture\n')
    blocked_write = HERE / ('write-denied-' + case + '.txt')
    if blocked_write.exists():
        raise SystemExit('synthetic denied-write target exists')
    assert (denied / 'value.txt').read_text() == (link / 'value.txt').read_text()
    synthetic_fragment = fragment(link, denied)
    production_fragment = fragment(LEXICAL, PHYSICAL)
    synthetic = out / 'synthetic-combined.sb'
    synthetic.write_text(base_profile(out) + synthetic_fragment)
    production = out / 'production-fragment.sb'
    production.write_text(production_fragment)
    child_code = '''import errno, json, pathlib, sys\nresults = {}\nfor name, raw in (("direct", sys.argv[1]), ("symlink", sys.argv[2])):\n    try:\n        pathlib.Path(raw).read_bytes()\n    except OSError as exc:\n        results[name] = "denied" if exc.errno in (errno.EACCES, errno.EPERM) else "other_error_" + str(exc.errno)\n    else:\n        results[name] = "READ_SUCCEEDED"\nresults["allowed"] = pathlib.Path(sys.argv[3]).read_text() == "test-owned allowed fixture\\n"\ntry:\n    pathlib.Path(sys.argv[4]).write_text("must be denied\\n")\nexcept OSError as exc:\n    results["write_denied"] = exc.errno in (errno.EACCES, errno.EPERM)\nelse:\n    results["write_denied"] = False\npathlib.Path(sys.argv[5]).write_text("allowed output\\n")\nresults["write_allowed"] = pathlib.Path(sys.argv[5]).read_text() == "allowed output\\n"\nprint(json.dumps(results, sort_keys=True))\nraise SystemExit(0 if results == {"direct": "denied", "symlink": "denied", "allowed": True, "write_denied": True, "write_allowed": True} else 2)\n'''
    command = ['/usr/bin/sandbox-exec', '-f', str(synthetic), sys.executable, '-I', '-S', '-B', '-c', child_code, str(denied / 'value.txt'), str(link / 'value.txt'), str(allowed), str(blocked_write), str(out / 'allowed-write.txt')]
    env = {'PATH': '/usr/bin:/bin:/usr/sbin:/sbin', 'HOME': os.environ['HOME'], 'LANG': 'C.UTF-8', 'PYTHONDONTWRITEBYTECODE': '1'}
    run = subprocess.run(command, cwd=HERE, env=env, capture_output=True, text=True)
    receipt = {
        'schema': 'c48.synthetic-single-combined-guard.v1',
        'case_id': case,
        'guard_script_sha256': sha(Path(__file__).read_bytes()),
        'production_lexical_link': str(LEXICAL),
        'production_physical_target': str(PHYSICAL),
        'production_fragment_text': production_fragment,
        'production_fragment_sha256': sha(production.read_bytes()),
        'synthetic_profile_text': synthetic.read_text(),
        'synthetic_profile_sha256': sha(synthetic.read_bytes()),
        'synthetic_fragment_text': synthetic_fragment,
        'synthetic_fragment_sha256': sha(synthetic_fragment.encode()),
        'child_code_sha256': sha(child_code.encode()),
        'command': command,
        'return_code': run.returncode,
        'stdout': run.stdout,
        'stderr': run.stderr,
        'scope': 'One combined D-shaped write policy + synthetic direct/symlink read deny, allowed read/write and denied outside write; only own RAW fixtures, no production content opened.',
        'network_boundary': 'Profile declares deny network*. This diagnostic issues no network syscall, binds no port and sends no network message; actual network denial remains not_established.',
    }
    (out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))
    if run.returncode:
        raise SystemExit('single combined guard failed; native remains UNRUN')


if __name__ == '__main__':
    main()
