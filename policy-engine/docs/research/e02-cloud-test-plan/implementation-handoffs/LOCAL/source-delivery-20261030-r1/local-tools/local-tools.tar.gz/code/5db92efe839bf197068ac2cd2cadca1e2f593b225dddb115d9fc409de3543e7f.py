"""Author microprobe only: load candidate helper, with fake non-product slots."""
from pathlib import Path
from types import SimpleNamespace
import hashlib
import json
import sys

owner = Path(__file__).parent / 'postimages/policy-engine/src/polisyos/foundry/methods/_internal/executable_identity.py'
source = owner.read_bytes()
ns = {'__name__': 'c60_numeric_probe', '__file__': str(owner)}
exec(compile(source, str(owner), 'exec'), ns)
def signature(bounds):
    return SimpleNamespace(stable_digest=lambda: 'same-abi', input_slots=(), output_slots=(SimpleNamespace(name='signal', bounds=bounds),))
binding = ns['_signature_binding']
a, b = binding(signature((0, 1))), binding(signature((-0.0, 1.0)))
assert a == b and hash(a) == hash(b)
huge = 10**20 + 1
assert huge != float(huge)
assert binding(signature((huge, huge))) != binding(signature((float(huge), float(huge))))
print(json.dumps({'result':'PASS','python':sys.version,'helper_sha256':hashlib.sha256(source).hexdigest(),'scope':'helper with synthetic inputs only; public method compiler/chain/runtime UNRUN','checks':['equal int/float and signed-zero hashes','distinct large integer vs rounded float']}))
