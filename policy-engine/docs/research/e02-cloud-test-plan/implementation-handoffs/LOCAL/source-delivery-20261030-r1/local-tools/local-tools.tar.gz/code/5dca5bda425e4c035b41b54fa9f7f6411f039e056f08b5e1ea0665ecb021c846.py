"""Exercise qualification intake on explicit synthetic records, never product runtime."""

from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.util
import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
PRODUCT = ROOT / "policy-engine"


def _load(path: Path, name: str) -> object:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ValueError("cannot load bounded qualification definitions")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> None:
    """Test real qualification functions using clearly synthetic bounded evidence."""
    parser = argparse.ArgumentParser()
    parser.add_argument("--suffix", required=True)
    args = parser.parse_args()
    if not re.fullmatch(r"[A-Za-z0-9_-]+", args.suffix):
        raise ValueError("unique synthetic control suffix must be alphanumeric, '-' or '_'")
    q = _load(HERE / "native/qualify_result.py", "c07_qualification_intake")
    plugin_path = HERE.parent / "C07-final-companions/native/c07_removal_plugin.py"
    plugin = _load(plugin_path, "c07_synthetic_custody_plugin_definitions")
    head = q._git("rev-parse", "HEAD").decode().strip()
    tree = q._git("rev-parse", head + "^{tree}").decode().strip()
    output = HERE / ("synthetic-intake-controls-" + args.suffix)
    output.mkdir(exist_ok=False)
    (output / "readsets").mkdir()
    observer = PRODUCT / (
        "docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/"
        "root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/"
        "deep-task-status-audit-20261027-r1/readset_observer_tools_r1.py"
    )
    source_path = "src/polisyos/runtime/quality/generation_cycle.py"
    test_path = "tests/unit/runtime/quality/test_hte_source_projection.py"
    test_function = "test_hte_projection_preserves_canonical_owner_refusals_as_typed_join_limits"
    source = q._git("show", head + ":policy-engine/" + source_path)
    test = q._git("show", head + ":policy-engine/" + test_path)
    pins = {
        path: hashlib.sha256(data).hexdigest()
        for path, data in ((source_path, source), (test_path, test))
    }
    modules = [
        {"path": path, "sha256": digest, "module_names": ["synthetic_intake_only"]}
        for path, digest in sorted(pins.items())
    ]
    readset_path = output / "readsets/input-readset-synthetic.json"
    readset = {
        "schema": "r4-runtime-loaded-python-readset-v1",
        "project_root": str(PRODUCT),
        "pytest_exitstatus": 1,
        "modules": modules,
        "module_count": 2,
        "source_module_count": 1,
        "test_module_count": 1,
        "tools_module_count": 0,
        "plugin_path": str(observer),
        "plugin_sha256": q._sha(observer),
    }
    readset_path.write_text(json.dumps(readset) + "\n")
    audit = {
        "result": {"return_code": 1},
        "readsets": [
            {
                "path": str(readset_path.relative_to(ROOT)),
                "sha256": q._sha(readset_path),
                "python_paths": 2,
                "pytest_exitstatus": 1,
            }
        ],
        "unique_runtime_loaded_python_paths": 2,
        "current_mismatches": [],
    }
    freeze = {"selected_input_pins": {observer.relative_to(ROOT).as_posix(): q._sha(observer)}}
    plan = {
        "source_head": head,
        "source_tree": tree,
        "source_test_pins": pins,
        "required_runtime_readset_paths": sorted(pins),
        "backend_metadata": {"python": sys.version},
        "nodes": [test_path + "::" + test_function],
        "extra_env": {
            "POLISYOS_C07_CONTROL_MODE": "owner_ambiguity",
            "PYTHONPATH": str(plugin_path.parent),
            "POLISYOS_C07_CONTROL_PLUGIN_SHA256": q._sha(plugin_path),
            "PYTEST_PLUGINS": "c07_removal_plugin",
            "POLISYOS_C07_CONTROL_PINS": json.dumps(pins),
        },
    }
    outcomes = []

    def check(label: str, action: object, should_raise: bool) -> None:
        try:
            action()
        except (OSError, KeyError, TypeError, ValueError) as exc:
            if not should_raise:
                raise
            outcomes.append(
                {"property": label, "verdict": "EXPECTED_REJECTION", "reason": str(exc)}
            )
        else:
            if should_raise:
                raise AssertionError(label + ": corrupted evidence was accepted")
            outcomes.append({"property": label, "verdict": "VALID_INTAKE_ACCEPTED"})

    check(
        "complete synthetic readset uses real committed bytes",
        lambda: q._reconcile_readsets(audit, plan, freeze, output, []),
        False,
    )
    absent = copy.deepcopy(audit)
    absent["readsets"] = []
    check(
        "absent readset plus empty current_mismatches cannot qualify",
        lambda: q._reconcile_readsets(absent, plan, freeze, output, []),
        True,
    )
    wrong = copy.deepcopy(audit)
    wrong["readsets"][0]["sha256"] = "0" * 64
    check(
        "actual retained readset bytes must match receipt",
        lambda: q._reconcile_readsets(wrong, plan, freeze, output, []),
        True,
    )
    missing = copy.deepcopy(plan)
    missing["required_runtime_readset_paths"] += [
        "src/polisyos/runtime/quality/hte_source_projection.py"
    ]
    check(
        "defining production path must really be in observed set",
        lambda: q._reconcile_readsets(audit, missing, freeze, output, []),
        True,
    )
    active, predicate, duplicate_index = q._control_shape(source, "owner_ambiguity", test)
    if duplicate_index != 0:
        raise ValueError("actual reviewed source duplicate-cell position changed")
    active_path = output / "active-control.py"
    active_path.write_bytes(active)
    nodeids = [test_path + "::" + test_function + f"[synthetic-{i}]" for i in range(5)]
    cases = []
    for index, node in enumerate(nodeids):
        case = ET.Element(
            "testcase",
            classname=test_path.removesuffix(".py").replace("/", "."),
            name=node.split("::")[1],
        )
        if index == duplicate_index:
            ET.SubElement(case, "failure").text = "synthetic intake fixture, not pytest execution"
        cases.append(case)
    control = {
        "mode": "owner_ambiguity",
        "source_head": head,
        "source_tree": tree,
        "source_test_pins": pins,
        "plugin_path": str(plugin_path),
        "plugin_sha256": q._sha(plugin_path),
        "python": sys.version,
        "active_function_source_path": str(active_path),
        "active_function_source_sha256": q._sha(active_path),
        "active_compiler_filename": str(active_path),
        "original_function_code_sha256": "1" * 64,
        "active_function_code_sha256": "2" * 64,
        "observer_plugin_code_sha256": plugin._code_sha(plugin._observed_owner_intake),
        "installed_function_code_sha256": plugin._code_sha(plugin._observed_owner_intake),
        "namespace_override": {
            "name": "_c07_ambiguity_guard_enabled",
            "value_at_admission": False,
            "code_sha256": "3" * 64,
        },
        "runtime_outcome": "FINISHED",
        "pytest_exitstatus": 1,
        "selected_nodes": nodeids,
        "expected_property_failure_nodes": [nodeids[0]],
        "test_path": test_path,
        "test_discriminator_line": predicate,
        "reports": [
            {
                "node": node,
                "when": phase,
                "outcome": "failed" if index == 0 and phase == "call" else "passed",
                **(
                    {"failure_line": predicate, "failure_path": test_path}
                    if index == 0 and phase == "call"
                    else {}
                ),
            }
            for index, node in enumerate(nodeids)
            for phase in ("setup", "call", "teardown")
        ],
        "owner_observations": [
            {
                "result": "returned",
                "ambiguous_cells": [
                    {
                        "controlled_values": [1.0, 3.0],
                        "independent_mean": 2.0,
                        "returned_value": 2.0,
                    }
                ],
            }
        ],
        "observed_semantic_signal": True,
        "targeted_assertion_failure": True,
        "control_discriminator_satisfied": True,
    }
    for key in (
        "source_test_pins_unchanged",
        "plugin_bytes_unchanged",
        "head_unchanged",
        "tree_unchanged",
        "installed_function_unchanged",
        "original_function_restored",
        "namespace_override_unchanged",
    ):
        control[key] = True
    check(
        "complete synthetic removal observations reconcile",
        lambda: q._reconcile_control(control, plan, output, cases, []),
        False,
    )
    altered = copy.deepcopy(control)
    altered["owner_observations"][0]["ambiguous_cells"][0]["returned_value"] = 7.0
    check(
        "retain all success markers but remove actual semantic divergence",
        lambda: q._reconcile_control(altered, plan, output, cases, []),
        True,
    )
    altered_phase = copy.deepcopy(control)
    altered_phase["reports"][1]["when"] = "setup"
    check(
        "retain markers but move failure out of real assertion call",
        lambda: q._reconcile_control(altered_phase, plan, output, cases, []),
        True,
    )
    restored = copy.deepcopy(control)
    restored["original_function_restored"] = False
    check(
        "claimed discriminator cannot bypass failed restoration",
        lambda: q._reconcile_control(restored, plan, output, cases, []),
        True,
    )
    changed_plugin = copy.deepcopy(plan)
    changed_plugin["extra_env"]["POLISYOS_C07_CONTROL_PLUGIN_SHA256"] = "0" * 64
    check(
        "control plugin must be bound to issued exact plan",
        lambda: q._reconcile_control(control, changed_plugin, output, cases, []),
        True,
    )
    original_active = active_path.read_bytes()
    active_path.write_bytes(
        original_active.replace(
            b"ambiguous_keys and _c07_ambiguity_guard_enabled()", b"ambiguous_keys"
        )
    )
    active_changed = copy.deepcopy(control)
    active_changed["active_function_source_sha256"] = q._sha(active_path)
    check(
        "updated hash plus markers cannot substitute unremoved property source",
        lambda: q._reconcile_control(active_changed, plan, output, cases, []),
        True,
    )
    active_path.write_bytes(original_active)
    record = {
        "scope": (
            "Synthetic qualification-intake controls only; no pytest hooks/product functions/"
            "native/backend computations or issued plans executed; no product runtime PASS."
        ),
        "source_head_for_real_Git_bytes": head,
        "source_tree": tree,
        "qualifier_sha256": q._sha(HERE / "native/qualify_result.py"),
        "unchanged_plugin_sha256": q._sha(plugin_path),
        "checks": outcomes,
        "runtime": "PRODUCT_UNRUN",
        "closure_ids": [],
    }
    (HERE / ("self-check-result-" + args.suffix + ".json")).write_text(
        json.dumps(record, indent=2) + "\n"
    )
    sys.stdout.write(json.dumps(record, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
