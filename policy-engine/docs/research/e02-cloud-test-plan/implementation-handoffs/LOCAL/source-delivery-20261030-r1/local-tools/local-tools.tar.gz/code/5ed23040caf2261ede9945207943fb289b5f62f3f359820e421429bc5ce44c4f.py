"""Disable only the prior-refusal guard during one selected semantic test."""
from __future__ import annotations

import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import threading

import pytest

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
PROJECT = ROOT / 'policy-engine'
OWNER = PROJECT / 'src/polisyos/runtime/quality/generation_cycle.py'
TEST = PROJECT / 'tests/unit/runtime/quality/test_generation_cycle.py'
PACKET = Path(__file__).resolve().parent
TEST_NAME = 'test_conflicting_n7_family_declaration_is_costed_refusal'
NODE = 'tests/unit/runtime/quality/test_generation_cycle.py::' + TEST_NAME
EXPECTED = 'unbound_requirement_input_refused'
MUTATED = 'requirement_gap_not_compiled'
stream = None
function = original = mutant = owner = plan_code = None
assertion_span = None
observations = []
observed_objects = {}
planned_objects = []
active_frames = set()
reports = {}
errors = []
restored = False
semantic_failure = False
lock = threading.Lock()


def write(event, **values):
    with lock:
        stream.write(json.dumps({'event':event, 'pid':os.getpid(), **values}, sort_keys=True, default=str) + '\n')
        stream.flush()


def require(value, reason):
    if not value:
        raise RuntimeError('R171 removal instrumentation: ' + reason)


def pins():
    declared = json.loads(os.environ['E02_R171_REMOVE_PINS'])
    paths = {'owner':OWNER, 'test':TEST, 'plugin':Path(__file__), 'core':PACKET / 'mutation_core.py'}
    require(set(declared) == set(paths), 'pin denominator')
    for name, path in paths.items():
        require(hashlib.sha256(path.read_bytes()).hexdigest() == declared[name], 'source pin ' + name)
    return declared


def assertion():
    tree = ast.parse(TEST.read_bytes(), filename=str(TEST))
    tests = [node for node in tree.body if isinstance(node, ast.AsyncFunctionDef) and node.name == TEST_NAME]
    require(len(tests) == 1, 'test denominator')
    expression = ast.dump(ast.parse('basis.routing_limitation_code == "unbound_requirement_input_refused"', mode='eval').body, include_attributes=False)
    matches = [node for node in ast.walk(tests[0]) if isinstance(node, ast.Assert) and ast.dump(node.test, include_attributes=False) == expression]
    require(len(matches) == 1 and matches[0].end_lineno is not None, 'semantic assertion denominator')
    return matches[0].lineno, matches[0].end_lineno


def pytest_configure(config):
    global stream, assertion_span
    declared = pins()
    assertion_span = assertion()
    trace, temp = Path(os.environ['E02_R171_REMOVAL_TRACE']), Path(os.environ['TMPDIR'])
    require(trace.is_absolute() and temp.is_absolute() and trace.is_relative_to(ROOT)
            and trace.parent == temp.parent and temp.is_dir() and trace.name == 'r171-reason-removal.jsonl', 'trace geometry')
    require(not any(path.is_symlink() for path in (trace, *trace.parents)), 'trace symlink')
    stream = os.fdopen(os.open(trace, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600), 'w', encoding='utf-8')
    write('admission', node=NODE, argv=sys.argv, pins=declared, assertion_span=assertion_span)


def pytest_collection_modifyitems(session, config, items):
    require([item.nodeid for item in items] == [NODE], 'selector')


def observe(frame, event, result):
    if frame.f_code not in {mutant, plan_code} or event not in {'call', 'return'}:
        return
    try:
        key = (threading.get_ident(), id(frame), 'basis' if frame.f_code is mutant else 'plan')
        if event == 'call':
            with lock:
                active_frames.add(key)
            return
        with lock:
            paired_call = key in active_frames
            active_frames.discard(key)
        if not paired_call or result is None:
            return
        if frame.f_code is plan_code:
            planned_objects.append(result)
            write('plan_return', basis_id=id(result.basis), report_id=id(result.report), ref_id=id(result.report_ref))
            return
        result_basis = result.compilation_report.requirement_basis
        row = {'result_id':id(result), 'thread_id':key[0], 'frame_id':key[1], 'paired_call':paired_call,
               'earlier_refusal':frame.f_locals.get('source_family_limitation', '<not_evaluated>'),
               'returned_refusal':result.routing_limitation_code,
               'source_gap_id':getattr(result.routed_source_gap, 'requirement_gap_id', None),
               'state':result_basis.state, 'grade':result_basis.basis_grade,
               'spec_count':len(result.specs), 'routed_gap_count':len(result.routed_compiler_gaps)}
        observations.append(row)
        observed_objects[id(result)] = result
        write('basis_return', **row)
    except Exception as exc:
        errors.append(type(exc).__name__ + ': ' + str(exc))
        write('observer_error', reason=errors[-1])


@pytest.hookimpl(hookwrapper=True, tryfirst=True)
def pytest_runtest_call(item):
    global function, original, mutant, owner, restored, plan_code
    require(item.nodeid == NODE and sys.getprofile() is None and threading.getprofile() is None, 'CALL selector or existing profiler')
    pins()
    owner = item.module.generation_cycle_module
    require(Path(owner.__file__).resolve() == OWNER and sys.modules.get(owner.__name__) is owner, 'loaded owner')
    cls = owner.GenerationCycleController
    function = cls.__dict__['_n7_data_requirement_basis_with_report']
    plan_code = cls.__dict__['_plan_n7_requirement_gap_if_requested'].__code__
    require(function.__globals__ is vars(owner) and function.__code__.co_filename == str(OWNER), 'real class/function binding')
    spec = importlib.util.spec_from_file_location('r171_remove_core', PACKET / 'mutation_core.py')
    require(spec is not None and spec.loader is not None, 'core loader')
    core = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(core)
    compiled, mutant, details = core.make_codes(OWNER.read_bytes(), str(OWNER))
    require(function.__code__ == compiled, 'loaded producer differs from pinned fresh compilation')
    original = function.__code__
    try:
        function.__code__ = mutant
        sys.setprofile(observe)
        threading.setprofile(observe)
        write('mutation_installed', function_id=id(function), **details)
        yield
    finally:
        sys.setprofile(None)
        threading.setprofile(None)
        function.__code__ = original
        require(cls.__dict__['_n7_data_requirement_basis_with_report'] is function
                and function.__code__ is original and function.__globals__ is vars(owner)
                and sys.getprofile() is None and threading.getprofile() is None and not active_frames, 'restore failed')
        pins()
        restored = True
        write('restored', function_id=id(function), same_original_code=True, profilers_absent=True)


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    global semantic_failure
    outcome = yield
    report = outcome.get_result()
    if item.nodeid != NODE:
        return
    reports[report.when] = report.outcome
    if call.when != 'call' or call.excinfo is None or call.excinfo.type is not AssertionError or not call.excinfo.traceback:
        return
    entry = call.excinfo.traceback[-1]
    frame = entry.frame.raw
    if not (frame.f_code.co_name == TEST_NAME and Path(frame.f_code.co_filename).resolve() == TEST
            and assertion_span[0] <= entry.lineno + 1 <= assertion_span[1]):
        return
    locals_ = entry.frame.f_locals
    basis, cycle = locals_['basis'], locals_['cycle']
    report_value = cycle.acquisition_routing_report
    paired = [row for row in observations if row['result_id'] == id(basis)
              and observed_objects.get(row['result_id']) is basis and row['paired_call']
              and row['earlier_refusal'] == EXPECTED and row['returned_refusal'] == MUTATED
              and row['source_gap_id'] and row['state'] == row['grade'] == 'not_established'
              and row['spec_count'] == row['routed_gap_count'] == 0]
    planned = [route for route in planned_objects if observed_objects.get(id(route.basis)) is route.basis
               and any(row['result_id'] == id(route.basis) and row['earlier_refusal'] == EXPECTED
                       and row['returned_refusal'] == MUTATED and row['paired_call'] for row in observations)
               and route.report == report_value and route.report_ref == cycle.acquisition_routing_report_ref]
    semantic_failure = bool(restored and paired and planned and basis.routing_limitation_code == MUTATED
                            and report_value.status == 'blocked'
                            and report_value.basis_limitation_code == 'requirement_basis_not_established'
                            and report_value.cost_estimation_status == 'not_estimated'
                            and report_value.acquisition_records == () and cycle.acquisition_routing_report_ref is not None
                            and cycle.acquisition_cost_basis_record is None and cycle.acquisition_receipt is None)
    write('semantic_failure', qualified=semantic_failure, actual=basis.routing_limitation_code,
          expected=EXPECTED, report_limitation=report_value.basis_limitation_code, matched_assertion_returns=len(paired), matched_planned_routes=len(planned), fresh_readback='not_observed')


def pytest_sessionfinish(session, exitstatus):
    ok = (semantic_failure and restored and not errors and reports == {'setup':'passed','call':'failed','teardown':'passed'}
          and int(exitstatus) == 1)
    if not ok:
        session.exitstatus = pytest.ExitCode.INTERNAL_ERROR
    write('session_finish', classification='EXPECTED_SEMANTIC_REMOVAL' if ok else 'INSTRUMENT_OR_ORACLE_ERROR',
          original_exit=int(exitstatus), final_exit=int(session.exitstatus), reports=reports, errors=errors, restored=restored)


def pytest_unconfigure(config):
    if stream is not None:
        write('final', restored=restored, profilers_absent=sys.getprofile() is None and threading.getprofile() is None)
        stream.close()
