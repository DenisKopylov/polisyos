"""Measure saved producer inputs into one fresh CAS; never reopen the failed store."""

import argparse
from concurrent.futures import Future
from dataclasses import asdict
import hashlib
import importlib.util
import inspect
import json
import marshal
import os
from pathlib import Path
import subprocess
import sys
import threading
import time
import traceback
import types

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
PACKET = Path(__file__).resolve().parent
OUTPUT = Path(os.environ['RUNTIME_AA_OUTPUT'])
TOOL_ID = 5
EVENTS = []
ACTIVE = {}
CONDITION = threading.Condition()


def save(name, value):
    with (OUTPUT / name).open('x') as stream:
        json.dump(value, stream, indent=2, default=str)
        stream.write('\n')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def exception_chain(error):
    rows, seen = [], set()
    while error is not None and id(error) not in seen:
        seen.add(id(error))
        rows.append({'type': type(error).__module__ + '.' + type(error).__qualname__,
                     'message': str(error)})
        error = error.__cause__ or error.__context__
    return rows


def start(code, offset):
    frame = sys._getframe(1)
    if frame.f_code is not code:
        raise RuntimeError('monitoring_callback_frame_not_established')
    now = time.monotonic_ns()
    local = frame.f_locals
    row = {'event': 'enter', 'ns': now, 'thread': threading.get_ident(),
           'code': code.co_qualname, 'file': code.co_filename, 'line': code.co_firstlineno}
    func = local.get('func')
    if callable(func):
        row['guarded_callable'] = func.__module__ + '.' + func.__qualname__
    owner = local.get('self')
    if hasattr(owner, '_timeout_seconds'):
        row['actual_guard_timeout_seconds'] = owner._timeout_seconds
    if isinstance(owner, Future):
        row['future_id'] = id(owner)
        row['future_timeout_argument'] = local.get('timeout')
    opts = local.get('opts')
    if opts is not None:
        row['artifact_kind'] = getattr(opts, 'kind', None)
    data = local.get('data')
    if isinstance(data, bytes):
        row['payload_bytes'] = len(data)
    with CONDITION:
        row['event_id'] = len(EVENTS)
        ACTIVE.setdefault((threading.get_ident(), code), []).append(row)
        EVENTS.append(row)


def finish(code, offset, value, *, unwind=False):
    now = time.monotonic_ns()
    key = (threading.get_ident(), code)
    with CONDITION:
        stack = ACTIVE.get(key)
        if not stack:
            raise RuntimeError('monitoring_unpaired_exit')
        entered = stack.pop()
        if not stack:
            del ACTIVE[key]
        row = {'event': 'unwind' if unwind else 'return', 'ns': now,
               'thread': key[0], 'code': code.co_qualname,
               'duration_ns': now - entered['ns'], 'enter_event_id': entered['event_id']}
        if unwind:
            row['exception_chain'] = exception_chain(value)
        elif isinstance(value, bool):
            row['returned_bool'] = value
        EVENTS.append(row)
        CONDITION.notify_all()


def install_local_observer(functions):
    codes = set()
    def add(code):
        codes.add(code)
        for constant in code.co_consts:
            if isinstance(constant, types.CodeType) and constant.co_name == '_invoke':
                add(constant)
    for function in functions:
        add(function.__code__)
        add(inspect.unwrap(function).__code__)
    if sys.monitoring.get_tool(TOOL_ID) is not None:
        raise RuntimeError('monitoring_tool_already_owned')
    sys.monitoring.use_tool_id(TOOL_ID, 'c100-saved-cas-boundaries')
    events = sys.monitoring.events
    sys.monitoring.register_callback(TOOL_ID, events.PY_START, start)
    sys.monitoring.register_callback(TOOL_ID, events.PY_RETURN, finish)
    sys.monitoring.register_callback(TOOL_ID, events.PY_UNWIND,
                                     lambda code, offset, error: finish(code, offset, error, unwind=True))
    for code in codes:
        sys.monitoring.set_local_events(TOOL_ID, code,
            events.PY_START | events.PY_RETURN | events.PY_UNWIND)
    return codes


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=('core', 'guarded', 'guarded-legacy'), required=True)
    parser.add_argument('--head', required=True)
    args = parser.parse_args()
    manifest = json.loads((PACKET / 'manifest.json').read_text())
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == args.head
    for row in manifest['pins']:
        assert digest(ROOT / row['path']) == row['sha256'], row['path']
    # Read immutable files as bytes only. No old FileSystemCAS handle or directory copy.
    saved = json.loads((PACKET / 'saved-inputs.json').read_text())
    payloads = {name: (ROOT / row['blob']['path']).read_bytes() for name, row in saved.items()}
    from polisyos.common.async_tools import get_shared_executor_profile
    from polisyos.core.artifacts import (
        ArtifactManifest, ArtifactStoreConfig, CoreToIRArtifactStoreAdapter, FileSystemCAS,
        artifact_ref_for_manifest, build_artifact_store, ensure_ir_artifact_store,
        with_ambient_ownership_enforcement_if_supported,
    )
    from polisyos.core.contracts.execution_plan import MethodCatalogSnapshot
    from polisyos.core.observability import get_metrics, get_tracer
    from polisyos.core.security.tenant_context import tenant_scope
    from polisyos.foundry.methods import persist_method_catalog_snapshot
    from polisyos.ir.analytics.causal_capabilities import (
        CausalCapabilityContract, persist_causal_capability_contract,
    )
    from polisyos.runtime.http.resilience import BlockingDependencyGuard, guard_runtime_cas
    catalog = MethodCatalogSnapshot.model_validate_json(payloads['catalog'])
    capability = CausalCapabilityContract.model_validate_json(payloads['capability'])
    scratch = OUTPUT / 'scratch-cas'
    assert not scratch.exists()
    config = ArtifactStoreConfig.from_env().model_copy(update={'root': str(scratch)})
    assert config.backend == 'filesystem'
    base = build_artifact_store(config, metrics=get_metrics(), tracer=get_tracer())
    ambient = with_ambient_ownership_enforcement_if_supported(base)
    store = ambient if args.mode == 'core' else guard_runtime_cas(ambient)
    legacy = None
    if args.mode == 'guarded-legacy':
        assert sys.getprofile() is None and threading.getprofile() is None
        spec = importlib.util.spec_from_file_location('retained_aa_call_witness', ROOT / manifest['legacy_profile_path'])
        legacy = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(legacy)
    codes = install_local_observer([
        persist_causal_capability_contract, persist_method_catalog_snapshot,
        CoreToIRArtifactStoreAdapter.put_json, FileSystemCAS.put_json, FileSystemCAS.put_bytes,
        BlockingDependencyGuard.run, Future.result, Future.cancel,
    ])
    save('observed-code-identities.json', [
        {'qualname': code.co_qualname, 'file': code.co_filename,
         'source_sha256': digest(Path(code.co_filename).resolve(strict=True)),
         'code_sha256': hashlib.sha256(marshal.dumps(code)).hexdigest()}
        for code in sorted(codes, key=lambda item: (item.co_filename, item.co_firstlineno))
    ])
    save('entry.json', {'pid': os.getpid(), 'ppid': os.getppid(), 'argv': sys.argv,
         'python': sys.version, 'mode': args.mode, 'config': config.model_dump(mode='json'),
         'thread_env': {k: v for k, v in os.environ.items() if k.endswith('_NUM_THREADS')},
         'cas_environment': {k: v for k, v in os.environ.items() if k.startswith('POLISYOS_RUNTIME_CAS_')},
         'shared_executor_profile': asdict(get_shared_executor_profile()),
         'guard_timeout_seconds': getattr(getattr(store, '_guard', None), '_timeout_seconds', None),
         'legacy_hook': legacy is not None, 'local_code_count': len(codes),
         'scope': 'Saved typed producer inputs; no discovery/rebuild/Runtime/fit or old-store write.'})
    outcomes = []
    try:
        if legacy is not None:
            threading.setprofile(legacy.profile)
            sys.setprofile(legacy.profile)
        with tenant_scope(None, tenant_id=saved['catalog']['tenant_id'], cell_id=saved['catalog']['cell_id']):
            for label, operation in (
                ('capability', lambda: persist_causal_capability_contract(ensure_ir_artifact_store(store), capability)),
                ('catalog', lambda: persist_method_catalog_snapshot(store, catalog)),
            ):
                entered = time.monotonic_ns()
                outcome = {'operation': label, 'entered_ns': entered}
                try:
                    ref = operation()
                    outcome['returned_ref'] = ref.model_dump(mode='json')
                    assert str(ref.artifact_id) == saved[label]['artifact_id'], 'saved_payload_identity_changed'
                except BaseException as error:
                    outcome['exception_chain'] = exception_chain(error)
                    outcome['traceback'] = traceback.format_exc()
                outcome['exited_ns'] = time.monotonic_ns()
                outcomes.append(outcome)
                # Do not run a second producer after a failed first producer.
                if 'exception_chain' in outcome:
                    break
        # Observe outstanding actual worker completion, bounded without changing its deadline.
        with CONDITION:
            quiescent = CONDITION.wait_for(lambda: not ACTIVE, timeout=30)
        finished = time.monotonic_ns()
    finally:
        if legacy is not None:
            threading.setprofile(None)
            sys.setprofile(None)
        save('operation-events.json', EVENTS)
        for code in codes:
            sys.monitoring.set_local_events(TOOL_ID, code, 0)
        sys.monitoring.free_tool_id(TOOL_ID)
    persisted = []
    for name, row in saved.items():
        content = row['artifact_id'].split(':', 1)[1]
        blobs = list(scratch.rglob(content + '.blob'))
        assert len(blobs) <= 1
        blob = blobs[0] if blobs else None
        views = list(scratch.rglob(content + '.view.*.manifest.json'))
        selected = []
        with tenant_scope(None, tenant_id=saved['catalog']['tenant_id'], cell_id=saved['catalog']['cell_id']):
            for view in views:
                ref = artifact_ref_for_manifest(ArtifactManifest.model_validate_json(view.read_bytes()))
                selected.append({'path': str(view.relative_to(OUTPUT)), 'sha256': digest(view),
                                 'selected_ref': ref.model_dump(mode='json'),
                                 'real_core_verification_ok': base.verify(ref).ok})
        persisted.append({'operation': name, 'blob_present': blob is not None,
                          'blob_sha256': digest(blob) if blob is not None else None,
                          'selected_views': selected})
    for row in manifest['pins']:
        assert digest(ROOT / row['path']) == row['sha256'], row['path']
    save('result.json', {'pid': os.getpid(), 'mode': args.mode, 'outcomes': outcomes,
         'workers_quiescent': quiescent, 'finished_ns': finished, 'persisted': persisted,
         'operation_failed': any('exception_chain' in row for row in outcomes),
         'scope': 'Diagnostic measurements only; no Runtime PASS or root-cause verdict.', 'closure_ids': []})
    return 0 if quiescent else 2


if __name__ == '__main__':
    status = 1
    try:
        status = main()
    finally:
        # Retained same-process finite readset observer; compatibility exit field is CLI rc.
        observer = Path(os.environ['RUNTIME_AA_OBSERVER'])
        spec = importlib.util.spec_from_file_location('retained_cli_readset', observer)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        module.pytest_sessionfinish(None, status)
    raise SystemExit(status)
