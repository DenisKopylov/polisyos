from pathlib import Path
O=Path(__file__).resolve().parent;POST=O/'postimages';P=POST/'policy-engine/src/polisyos/foundry/calibration/report.py';s=P.read_text()
anchor='class CalibrationReport(BaseModel):'
new='''class CalibrationOrderedBatchReport(BaseModel):
    """Declare the batch objective scope without granting inferential authority."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    profile_kind: Literal["ordered_scalar_mse_v1"] = "ordered_scalar_mse_v1"
    objective_kind: Literal["generic_weighted_mse_curvature_only"] = (
        "generic_weighted_mse_curvature_only"
    )
    inference_status: Literal["unavailable_generic_loss"] = "unavailable_generic_loss"
    consumed_profile_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    selected_input_ref: ArtifactRef | None = None
    input_status: Literal["selected_input_consumed", "in_memory_input_only"]

    @model_validator(mode="after")
    def validate_selected_input(self) -> CalibrationOrderedBatchReport:
        if (self.input_status == "selected_input_consumed") != (self.selected_input_ref is not None):
            raise ValueError("ordered_report_input_status_must_match_selected_reference")
        if self.selected_input_ref is not None and (
            self.selected_input_ref.kind != "foundry.calibration_ordered_input"
            or self.selected_input_ref.media_type != "application/json"
            or self.selected_input_ref.manifest_profile_sha256 is None
        ):
            raise ValueError("ordered_report_requires_selected_full_input")
        return self


''';assert s.count(anchor)==1;s=s.replace(anchor,new+anchor)
needle='''    schema_version: str = Field("2.0", pattern=r"^\d+\.\d+$")
''';new=needle+'''    ordered_batch_execution: CalibrationOrderedBatchReport | None = Field(
        default=None, exclude_if=lambda value: value is None,
    )

    @model_validator(mode="after")
    def validate_ordered_scope(self) -> CalibrationReport:
        if (self.schema_version == "2.1") != (self.ordered_batch_execution is not None):
            raise ValueError("report_v2_1_requires_typed_ordered_objective_scope")
        if self.ordered_batch_execution is None and "ordered_batch" in self.execution_context:
            raise ValueError("ordered_execution_markers_cannot_downgrade_to_legacy_scope")
        return self

''';assert s.count(needle)==1;s=s.replace(needle,new)
needle='''    # V2 carries typed nulls, including `confidence_level=None` for heuristic''';new='''    if report.ordered_batch_execution is not None:
        from polisyos.foundry.calibration.execution_basis import (
            load_calibration_execution_input_basis,
            reconcile_ordered_batch_report_identity,
        )

        scope = report.ordered_batch_execution
        if scope.selected_input_ref is None:
            raise ValueError("persist_ordered_report_with_run_and_persist_selected_input")
        basis_edges = [edge for edge in inputs or () if edge.role == "calibration_execution_input_basis"]
        config_edges = [edge for edge in inputs or () if edge.role == "calibration_config"]
        if len(basis_edges) != 1 or len(config_edges) != 1:
            raise ValueError("ordered_report_requires_exact_config_and_basis_edges")
        edge = basis_edges[0]
        if edge.manifest_profile_sha256 is None:
            raise ValueError("ordered_report_basis_edge_requires_selected_profile")
        basis = load_calibration_execution_input_basis(store, ArtifactRef(
            artifact_id=edge.artifact_id, kind="foundry.calibration_execution_input_basis",
            media_type="application/json", manifest_profile_sha256=edge.manifest_profile_sha256,
        ))
        config = config_edges[0]
        if (config.artifact_id != basis.calibration_config_ref.artifact_id
            or config.manifest_profile_sha256 != basis.calibration_config_ref.manifest_profile_sha256):
            raise ValueError("ordered_report_config_edge_mismatch")
        reconcile_ordered_batch_report_identity(basis, report)
    # V2 carries typed nulls, including `confidence_level=None` for heuristic''';assert s.count(needle)==1;s=s.replace(needle,new)
P.write_text(s)
P=POST/'policy-engine/src/polisyos/foundry/calibration/calibrator.py';s=P.read_text();s=s.replace('    CalibrationMetricsCollector,' if False else '    CalibrationCoordinateProjection,','    CalibrationCoordinateProjection,\n    CalibrationOrderedBatchReport,');needle='''        report = CalibrationReport(
            calibrated_params=calibrated_params,''';new='''        selected_input_ref = (
            self._execution_capture.get("ordered_input_ref")
            if self._execution_capture is not None else None
        )
        report = CalibrationReport(
            schema_version="2.1" if batch_profile is not None else "2.0",
            ordered_batch_execution=(
                CalibrationOrderedBatchReport(
                    consumed_profile_sha256=canonical_input_sha256(batch_profile),
                    selected_input_ref=selected_input_ref,
                    input_status=("selected_input_consumed" if selected_input_ref is not None
                                  else "in_memory_input_only"),
                ) if batch_profile is not None else None
            ),
            calibrated_params=calibrated_params,''';assert s.count(needle)==1;s=s.replace(needle,new);P.write_text(s)
