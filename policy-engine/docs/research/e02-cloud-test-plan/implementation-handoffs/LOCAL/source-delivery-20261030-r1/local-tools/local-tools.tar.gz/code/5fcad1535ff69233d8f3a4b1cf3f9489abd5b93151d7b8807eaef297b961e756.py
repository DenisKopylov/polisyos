"""Root-only scoped canonical-owner rendering after reviewed R3 composition.

This script is authored but UNRUN by the RAW-only worker. It imports the real
architecture owner (which imports product Markdown helpers), so only Root may
execute it. It never installs output or collects global deep-import edges.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
PRODUCT = ROOT / 'policy-engine'
HERE = Path(__file__).resolve().parent
sha = lambda payload: hashlib.sha256(payload).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--output-root', type=Path, required=True)
    args = parser.parse_args()
    target = args.output_root.resolve()
    target.relative_to(ROOT / 'LOCAL/raw/e02-execution-20261027')
    if target.exists():
        raise SystemExit('Use a fresh retained RAW output root')
    pins = json.loads((HERE / 'owner-pins.json').read_text())
    for name, digest in pins['owner_and_baseline_sha256'].items():
        if sha((ROOT / name).read_bytes()) != digest:
            raise SystemExit(f'Owner/baseline pin changed; requalify before staging: {name}')
    # Root has composed the source packet; all source postimages must be actual.
    packet = ROOT / pins['source_packet_manifest']
    if sha(packet.read_bytes()) != pins['source_packet_manifest_sha256']:
        raise SystemExit('Source packet manifest drift')
    manifest = json.loads(packet.read_text())
    for item in manifest['files']:
        if sha((ROOT / item['path']).read_bytes()) != item['post_sha256']:
            raise SystemExit(f'Reviewed R3 source not installed exactly: {item["path"]}')
    sys.path.insert(0, str(PRODUCT))
    from tools.devx.architecture import guardrails as owner

    baseline = json.loads(owner.DEFAULT_PUBLIC_JSON.read_text())
    policies = owner._parse_public_surface(owner.DEFAULT_PUBLIC_MANIFEST)
    families = owner._parse_public_generated_artifact_families(owner.DEFAULT_PUBLIC_MANIFEST)
    inventory = []
    for record in baseline['packages']:
        fields = dict(record)
        fields['entrypoints'] = tuple(owner.SupportedEntrypointInventory(**row) for row in fields['entrypoints'])
        inventory.append(owner.PackageInventory(**fields))
    # No candidate is written unless the same canonical renderer reproduces the
    # complete baseline format. Outside Foundry, retained entries are not remeasured.
    if owner.render_public_surface_json(inventory, generated_artifact_families=families) != owner.DEFAULT_PUBLIC_JSON.read_text():
        raise SystemExit('Canonical public JSON baseline round-trip differs')
    if owner.render_public_surface_markdown(inventory) != owner.DEFAULT_PUBLIC_MD.read_text():
        raise SystemExit('Canonical public Markdown baseline round-trip differs')
    selected = [policy for policy in policies if policy.module == 'polisyos.foundry']
    if len(selected) != 1:
        raise SystemExit('Foundry public policy owner is not unique')
    refreshed = owner.build_public_surface_inventory(selected)[0]
    compile_entry = next(row for row in refreshed.entrypoints if row.module == 'polisyos.foundry.compile')
    if compile_entry.export_resolution.get('complete') is not True or 'replay_method_program_graph' not in compile_entry.exports:
        raise SystemExit('New facade export is not source-established by canonical owner')
    old_foundry = next(row for row in inventory if row.module == selected[0].module)
    changed_entrypoints = [row.module for row in refreshed.entrypoints if row != next(old for old in old_foundry.entrypoints if old.module == row.module)]
    inventory = [refreshed if row.module == selected[0].module else row for row in inventory]
    candidates = {
        'architecture/public_surface/inventory.json': owner.render_public_surface_json(inventory, generated_artifact_families=families),
        'docs/reference/public-surface.md': owner.render_public_surface_markdown(inventory),
    }
    # The registered generated reference depends on its unchanged TOML, not the
    # facade export. Compare through its real owner; do not manufacture a delta.
    generated = owner.render_generated_artifacts_markdown(owner._parse_generated_artifacts(owner.DEFAULT_GENERATED_MANIFEST))
    if generated != owner.DEFAULT_GENERATED_MD.read_text():
        raise SystemExit('Generated-artifacts reference has separate source drift; inspect its owner before staging this cut')
    candidates['docs/reference/generated-artifacts.md'] = generated
    target.mkdir(parents=True)
    outputs = []
    for relative, content in candidates.items():
        destination = target / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(content)
        original = (PRODUCT / relative).read_bytes()
        outputs.append({'path': 'policy-engine/' + relative, 'before_sha256': sha(original), 'candidate_sha256': sha(content.encode()), 'changed': original != content.encode(), 'staged_path': str(destination.relative_to(ROOT))})
    receipt = {
        'scope': 'Actual canonical owner, Foundry package only; outside-package public records preserved, not remeasured. No full guardrail/generated freshness verdict.',
        'source_packet_manifest_sha256': pins['source_packet_manifest_sha256'],
        'entrypoint_denominator': len(refreshed.entrypoints),
        'changed_entrypoints': changed_entrypoints,
        'outputs': outputs,
        'compile_exports': list(compile_entry.exports),
        'compile_export_resolution': compile_entry.export_resolution,
        'canonical_install': 'UNRUN: Root must inspect and apply only changed candidates, then rebind exact installed outputs.',
    }
    (target / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'outputs': outputs, 'changed_entrypoints': changed_entrypoints}, indent=2))


if __name__ == '__main__':
    main()
