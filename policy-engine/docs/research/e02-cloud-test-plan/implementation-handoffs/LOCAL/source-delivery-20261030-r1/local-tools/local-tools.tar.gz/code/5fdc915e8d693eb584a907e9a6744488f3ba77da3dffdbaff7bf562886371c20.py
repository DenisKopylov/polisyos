"""Small synthetic mechanism controls; no product or actual pytest imports."""
from __future__ import annotations
import hashlib
import importlib.util
import json
import sys
import types
from pathlib import Path

root = Path(__file__).resolve().parent
fake_pytest = types.ModuleType("pytest")
fake_pytest.hookimpl = lambda **_kwargs: lambda function: function
sys.modules["pytest"] = fake_pytest
spec = importlib.util.spec_from_file_location("b194_probe_control", root / "b194_denominator_probe.py")
probe = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = probe
spec.loader.exec_module(probe)
original_source = '''def _check_propagation_report(report, envelope, *, metric_id, limitations):
    del envelope, metric_id
    ledger = report["draw_outcome_provenance"]
    if ledger["successful_draw_count"] != ledger["attempted_draw_count"]:
        limitations.append("propagation_draw_denominator_mismatch")
'''
mutant_source = original_source.replace(
    'if ledger["successful_draw_count"] != ledger["attempted_draw_count"]:',
    'if ledger["successful_draw_count"] != ledger["attempted_draw_count"] and False:',
)
results = []
for mode in ["mutant", "restored"]:
    module = types.ModuleType("fake_b194_owner")
    module.__file__ = "<synthetic-b194-original>"
    exec(compile(original_source, module.__file__, "exec", dont_inherit=True), vars(module))
    original = module._check_propagation_report.__code__
    mutant = probe._function_code(mutant_source, "<synthetic-b194-mutant>", "_check_propagation_report")
    events = []
    experiment = probe.FunctionExperiment(module, "_check_propagation_report", original, mutant, mode, events.append)
    limits = []
    try:
        experiment.install()
        module._check_propagation_report(
            {"draw_outcome_provenance": {"requested_draw_count": 100, "unattempted_draw_count": 0, "attempted_draw_count": 100, "successful_draw_count": 99,
                                        "failure_records": [], "outcome_denominator_complete": True}},
            None, metric_id="y", limitations=limits,
        )
    finally:
        experiment.restore()
    assert experiment.restored and not experiment.errors
    assert experiment.starts == 1 and experiment.falsified_premise_seen
    assert [row["event"] for row in events] == ["installed", "actual_start", "actual_return", "restored"]
    assert limits == ([] if mode == "mutant" else ["propagation_draw_denominator_mismatch"])
    assert module._check_propagation_report.__code__ is original
    results.append({"case": mode, "status": "PASS", "events": events,
                    "diagnostic_present": bool(limits), "exact_original_code_restored": True})

# A real callee exception cannot be replaced by the observer; restoration still runs.
module = types.ModuleType("fake_b194_exception_owner")
module.__file__ = "<synthetic-b194-exception>"
exception_source = 'def _check_propagation_report(report, envelope, *, metric_id, limitations):\n    raise RuntimeError("original-body-error")\n'
exec(compile(exception_source, module.__file__, "exec", dont_inherit=True), vars(module))
original = module._check_propagation_report.__code__
events = []
experiment = probe.FunctionExperiment(module, "_check_propagation_report", original, original, "restored", events.append)
try:
    experiment.install()
    try:
        module._check_propagation_report({}, None, metric_id="y", limitations=[])
    except RuntimeError as exc:
        assert str(exc) == "original-body-error"
    else:
        raise AssertionError("original callee error was lost")
finally:
    experiment.restore()
assert experiment.restored and not experiment.errors
results.append({"case": "exception-preserved-and-restored", "status": "PASS"})

# An occupied slot is never replaced or silently skipped.
owned = []
try:
    for slot in (5, 4):
        assert sys.monitoring.get_tool(slot) is None
        sys.monitoring.use_tool_id(slot, "synthetic-external-owner")
        owned.append(slot)
    module = types.ModuleType("fake_b194_busy_owner")
    module.__file__ = "<synthetic-b194-busy>"
    exec(compile(original_source, module.__file__, "exec", dont_inherit=True), vars(module))
    original = module._check_propagation_report.__code__
    experiment = probe.FunctionExperiment(module, "_check_propagation_report", original, original, "mutant", lambda _row: None)
    try:
        experiment.install()
    except RuntimeError as exc:
        assert str(exc) == "no_unused_bounded_monitor_slot"
    else:
        raise AssertionError("occupied monitoring slots were replaced")
    assert module._check_propagation_report.__code__ is original
finally:
    for slot in owned:
        sys.monitoring.free_tool_id(slot)
results.append({"case": "occupied-slots-no-mutation", "status": "PASS"})

report = {"schema": "e02-b194-stdlib-synthetic-controls-v1", "results": results,
          "product_imports": False, "real_pytest_imports": False,
          "product_tests": "UNRUN", "mode": "synthetic mechanism controls only"}
(root / "stdlib-controls.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"status": "PASS", "cases": len(results), "product_tests": "UNRUN"}))
