"""Start the unchanged public tools.cli module only after observer admission."""
import os
import runpy
import sys
from pathlib import Path

import sitecustomize

out = Path(os.environ["E02_PHASE_PROFILE_DIR"])
if not (out / "observer.ready").is_file():
    raise SystemExit("HARNESS_ERROR: phase observer did not arm; public CLI not invoked")
args = [
    "polisyos-tools",
    "validation",
    "schema-fqn-census",
    "--output-format",
    "json",
    "--repo-root",
]
sys.argv = args + ["."]
runpy.run_module("tools.cli", run_name="__main__", alter_sys=True)
