"""Derive mutually independent source removals from the proposed exact postimages."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

root=Path('LOCAL/raw/e02-execution-20261027/repairs/C90-provenance-domain-r5')
post=root/'postimages'
mc='policy-engine/src/polisyos/foundry/uncertainty/monte_carlo.py'
dispatch='policy-engine/src/polisyos/foundry/uncertainty/dispatcher.py'
test='tests/unit/foundry/uncertainty/test_joint_law_admission.py::'


def one(source, old, new, *, count=1):
    assert source.count(old)==count, (old, source.count(old), count)
    return source.replace(old,new,count)


def m01(s):
    return one(s, '        """Consume the same prepared law from direct and dispatched execution."""\n        param_names = sorted(prepared.input_envelopes)\n', '        """Consume the same prepared law from direct and dispatched execution."""\n        param_names = sorted(prepared.input_envelopes)\n        _validate_effective_inputs(simulation_fn, prepared.nominal_params, param_names)\n')

def m02(s):
    return one(s,'        param_names = sorted(input_envelopes)\n        if prepared.unknown_dependency:\n','        param_names = sorted(input_envelopes)\n        _validate_effective_inputs(simulation_fn, nominal_params, param_names)\n        if prepared.unknown_dependency:\n')

def m03(s):
    return one(s,'            metadata[dependency_key] = "unknown" if unknown else "known"','            metadata[dependency_key] = raw')

def m04(s):
    return one(s,'    """Finish one shared preparation without changing supported fixed scalars."""\n    if prepared.execution_context_prepared:', '    """Finish one shared preparation without changing supported fixed scalars."""\n    return replace(prepared, execution_context_prepared=True)\n    if prepared.execution_context_prepared:')

def m05(s):
    return one(s,'            input_envelope_digests=prepared.input_envelope_digests,','            input_envelope_digests=None,')

def m06(s):
    s=one(s,'        not fixed_names\n        and prepared.fixed_scalar_values_owned\n        and prepared.provenance_context_owned','        prepared.provenance_context_owned')
    return one(s,'            fixed_scalar_values_owned\n            and provenance_context_owned\n            and metadata_context_owned\n            and not has_unbound_fixed_inputs','            provenance_context_owned\n            and metadata_context_owned')

def m07(s):
    return one(s,'self._mc._propagate_prepared(simulation_fn, prepared)','self._mc.propagate(simulation_fn, nominal_params, input_envelopes, output_metric_ids)',count=4)

def m08(s):
    return one(s,'        weights = converted\n','        weights = prepared.weights\n')

def m09(s):
    return one(s,'            provenance, provenance_owned = _own_provenance_value(provenance, set())','            provenance, provenance_owned = provenance, True')

def m10(s):
    s=one(s,'        and prepared.provenance_context_owned\n','')
    return one(s,'            and provenance_context_owned\n','')

def m11(s):
    return one(s,'''            snapshot[2]
            and (
                snapshot[0].composition_provenance is None
                or _provenance_wire_matches(snapshot[0], original_wires.get(name))
            )
''','''            snapshot[2]
''')

def m12(s):
    return one(s,'name: np.asarray(carrier.samples, dtype=np.float64).copy()','name: np.asarray(carrier.samples, dtype=np.float64)')

def m13(s):
    s=one(s,'        and prepared.metadata_context_owned\n','')
    return one(s,'            and metadata_context_owned\n','')

def m14(s):
    return one(s,'        and _metadata_wire_matches(snapshot[0], metadata_wires[name])','        and True')

controls=[
('M01-mc-binding-before-law',mc,m01,[test+'test_refused_sampling_law_precedes_irrelevant_binding_and_never_evaluates[empirical_unestablished-missing_nominal-mc]'], 'refused MC law precedes irrelevant binding'),
('M02-dispatcher-binding-before-law',dispatch,m02,[test+'test_refused_sampling_law_precedes_irrelevant_binding_and_never_evaluates[empirical_unestablished-missing_nominal-dispatcher_mc]'], 'dispatcher preserves law refusal before binding'),
('M03-retain-behavioral-dependency-alias',mc,m03,[test+'test_behavioral_metadata_meaning_is_owned_at_actual_mc_law_and_result_consumers[enum-dependency-signature-mc]'], 'dependency meaning is prepared once'),
('M04-skip-owned-execution-view',mc,m04,[test+'test_mutated_parametric_parameters_cannot_change_the_prepared_marginal_law[signature-mc]'], 'fit is owned before effects'),
('M05-recompute-wire-identity-after-effects',mc,m05,[test+'test_inert_sidecars_preserve_original_identity_limitation_and_numerical_law[timezone-signature-mc]'], 'original envelope digest survives effects'),
('M06-promote-borrowed-fixed-identity',mc,m06,[test+'test_mutable_fixed_objects_keep_borrowed_computation_without_owned_identity_or_gate[list-mc]',test+'test_fixed_invocation_identity_limitation_finalizes_every_moment_route[delta]',test+'test_fixed_invocation_identity_limitation_finalizes_every_moment_route[analytical]'], 'unbound fixed values cannot gate in MC or moment routes'),
('M07-discard-shared-preparation',dispatch,m07,[test+'test_behavioral_metadata_meaning_is_owned_at_actual_mc_law_and_result_consumers[enum-dependency-signature-dispatcher_mc]'], 'dispatcher passes the original preparation to MC and fallback'),
('M08-discard-consumed-weight-projection',mc,m08,[test+'test_analytical_weight_numeric_value_is_captured_before_signature_mutation'], 'analytical weights resolve before evaluator signature effects'),
('M09-retain-provenance-wire-alias',mc,m09,[test+'test_nested_datetime_and_containers_own_the_prior_wire_meaning[mc]',test+'test_nested_datetime_and_containers_own_the_prior_wire_meaning[delta]',test+'test_nested_datetime_and_containers_own_the_prior_wire_meaning[analytical]'], 'owned nested datetime history survives caller mutation'),
('M10-remove-unsupported-provenance-cap',mc,m10,[test+'test_unsupported_provenance_context_is_declared_and_non_gating'], 'unsupported borrowed provenance cannot gate across routes'),
('M11-remove-original-provenance-wire-comparison',mc,m11,[test+'test_provenance_wire_drift_between_digest_and_preparation_cannot_gate'], 'prepared history binds to provenance in original digest'),
('M12-retain-empirical-ndarray-alias',mc,m12,[test+'test_empirical_cache_owns_unvalidated_ndarray_before_signature_mutation'], 'conditional ndarray cache cannot alias caller buffer'),
('M13-remove-metadata-domain-cap',mc,m13,[test+'test_same_wire_dependency_cannot_support_conflicting_eligible_meaning',test+'test_behavioral_numeric_metadata_with_same_wire_is_non_gating',test+'test_unconsumed_nested_behavioral_metadata_cannot_grant_a_context_gate'], 'unsupported metadata interpretation cannot gate on serialized identity'),
('M14-remove-metadata-wire-comparison',mc,m14,[test+'test_cross_envelope_serialization_mutation_breaks_metadata_wire_binding'], 'owned JSON metadata must match the context in the original digest'),
]
(root/'removals').mkdir(exist_ok=True)
manifest=[]
for ident,path,mutate,selectors,prop in controls:
    original=(post/path).read_text()
    mutant=mutate(original)
    ast.parse(mutant)
    diff=''.join(difflib.unified_diff(original.splitlines(keepends=True),mutant.splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path))
    patch=root/'removals'/(ident+'.patch')
    patch.write_text(diff)
    manifest.append({'id':ident,'path':path,'property':prop,'selectors':selectors,'source_sha256':hashlib.sha256(original.encode()).hexdigest(),'mutant_sha256':hashlib.sha256(mutant.encode()).hexdigest(),'patch':str(patch.relative_to(root)),'patch_sha256':hashlib.sha256(diff.encode()).hexdigest(),'status':'UNRUN: AST parsed only'})
(root/'removals.json').write_text(json.dumps({'scope':'isolated per-control source removals, not executed','controls':manifest},indent=2)+'\n')
print('Generated and AST-parsed',len(manifest),'distinct removals against exact postimages; no runtime controls executed')
