from pathlib import Path
import json,hashlib,difflib
R=Path.cwd();old=R/'LOCAL/raw/e02-execution-20261027/repairs/C19-r6';O=old.with_name('C19-r7');assert not O.exists();O.mkdir();m=json.loads((old/'manifest.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
def image(rel):
 row=next(x for x in m['files'] if x['path']==rel);p=O/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/row['postimage_path']).read_bytes());row['postimage_path']=str(p.relative_to(R));return p
p=image('policy-engine/src/polisyos/runtime/quality/data_snapshot_lineage.py');s=p.read_text().replace('from collections.abc import Mapping\n','from collections.abc import Mapping\nfrom dataclasses import dataclass\nfrom typing import Literal\n');mark='''def validate_data_snapshot_owner_lineage(
''';addition='''ACQUIRED_SOURCE_ROW_REVALIDATION_LIMITATION = "acquired_source_row_revalidation_not_established"


class DataSnapshotSourceRowNotEstablished(DataSnapshotLineageError):
    """Refuse protected admission without a current acquired-source row witness."""

    def __init__(self) -> None:
        self.code = ACQUIRED_SOURCE_ROW_REVALIDATION_LIMITATION
        super().__init__(self.code)


@dataclass(frozen=True)
class DataSnapshotLineageResult:
    """Scope of the store-only verification, distinct from source-row authority."""

    acquisition_source_row_status: Literal["not_applicable", "not_established"] = "not_applicable"

    @property
    def required_admissibility_blockers(self) -> tuple[str, ...]:
        """Return the limitation required by any candidate-band consumer."""
        if self.acquisition_source_row_status == "not_established":
            return (ACQUIRED_SOURCE_ROW_REVALIDATION_LIMITATION,)
        return ()


''';assert s.count(mark)==1;s=s.replace(mark,addition+mark);s=s.replace('''    binding_lineage_refs: tuple[str, ...] | None = None,
    _seen:''','''    binding_lineage_refs: tuple[str, ...] | None = None,
    candidate_only: bool = False,
    _seen:''',1).replace(''') -> None:
    """Verify the selected DataSnapshot transport and any recognized owner source.''',''') -> DataSnapshotLineageResult:
    """Verify selected lineage; acquired-source rows remain candidate-only.''',1);s=s.replace('''    unverified 0.3 lineage field or downgrade a malformed owner payload.
''','''    unverified 0.3 lineage field or downgrade a malformed owner payload.

    Immutable epoch statements and selected CAS edges do not reconcile an
    acquired selected value/history with the current native source owner. With
    no overlay/authority resolver inputs here, acquired rows fail closed by
    default. ``candidate_only=True`` returns a typed not-established limitation;
    its consumer must remain in the candidate band and retain the required
    admissibility blocker. It never establishes source-row or basis authority.
''',1);s=s.replace('''        if not legacy_acquisition_probe:
            return
''','''        if not legacy_acquisition_probe:
            return DataSnapshotLineageResult()
''',1);needle='''            if binding_lineage_refs != expected_binding_refs:
                raise DataSnapshotLineageError("acquired_observation_binding_lineage_mismatch")


def _legacy_owner_lineage''';repl='''            if binding_lineage_refs != expected_binding_refs:
                raise DataSnapshotLineageError("acquired_observation_binding_lineage_mismatch")
        if not candidate_only:
            raise DataSnapshotSourceRowNotEstablished()
        return DataSnapshotLineageResult(acquisition_source_row_status="not_established")
    return DataSnapshotLineageResult()


def _legacy_owner_lineage''';assert s.count(needle)==1;s=s.replace(needle,repl);needle='''            base_snapshot,
            _seen=seen,
''';repl='''            base_snapshot,
            # Recursion verifies structure only; the enclosing acquired result
            # carries the source-row limitation or refuses protected admission.
            candidate_only=True,
            _seen=seen,
''';assert s.count(needle)==1;s=s.replace(needle,repl);s=s.replace('''__all__ = [
    "DataSnapshotLineageError",''','''__all__ = [
    "ACQUIRED_SOURCE_ROW_REVALIDATION_LIMITATION",
    "DataSnapshotLineageError",
    "DataSnapshotLineageResult",
    "DataSnapshotSourceRowNotEstablished",''');p.write_text(s)
p=image('policy-engine/src/polisyos/runtime/quality/data_state_substrate.py');s=p.read_text().replace('''    "causal_coupling_not_established",
)''','''    "causal_coupling_not_established",
    "acquired_source_row_revalidation_not_established",
)''',1);needle='''                base_data_snapshot_ref,
                base_snapshot,
            )''';repl='''                base_data_snapshot_ref,
                base_snapshot,
                candidate_only=True,
            )''';assert s.count(needle)==1;s=s.replace(needle,repl);p.write_text(s)
# Shared WMR/PCL writers receive narrow context patches, never saved postimage replacement.
contexts=[]
rel='policy-engine/src/polisyos/runtime/quality/world_model_record.py';base=(R/rel).read_text();s=base;needle='''        validate_data_snapshot_owner_lineage(
            store,
            data_snapshot_ref,
            data_snapshot,
            binding_lineage_refs=data_forge_binding_ref.lineage_refs,
        )''';repl='''        lineage_result = validate_data_snapshot_owner_lineage(
            store,
            data_snapshot_ref,
            data_snapshot,
            binding_lineage_refs=data_forge_binding_ref.lineage_refs,
            candidate_only=candidate_only,
        )
        if lineage_result.required_admissibility_blockers:
            effective_limitations = effective_limitations.model_copy(
                update={
                    "admissibility_blockers": tuple(
                        dict.fromkeys(
                            (*effective_limitations.admissibility_blockers,
                             *lineage_result.required_admissibility_blockers)
                        )
                    )
                }
            )''';assert s.count(needle)==1;s=s.replace(needle,repl);needle='''        validate_data_snapshot_owner_lineage(store, views.data_snapshot_ref, snapshot)
        return record''';repl='''        lineage_result = validate_data_snapshot_owner_lineage(
            store,
            views.data_snapshot_ref,
            snapshot,
            candidate_only=record.authority_status == "limited",
        )
        if not set(lineage_result.required_admissibility_blockers).issubset(
            record.limitations.admissibility_blockers
        ):
            raise WorldModelRecordError("world_model_record_source_row_limitation_missing")
        return record''';assert s.count(needle)==1;s=s.replace(needle,repl);p=O/'contexts'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s);contexts.append((rel,base,s,'world-model-candidate-band.diff'))
rel='policy-engine/src/polisyos/runtime/http/services/predictive_calibration.py';base=(R/rel).read_text();s=base;marker='''def _build_selected_profile_member(
''';helper='''def _load_verified_observed_data_snapshot(
    store: ArtifactStore, observed_source_ref: ArtifactRef
) -> DataSnapshot:
    """Admit observed-source lineage without granting candidate-row authority."""
    from polisyos.runtime.quality.data_snapshot_lineage import (
        DataSnapshotSourceRowNotEstablished,
        validate_data_snapshot_owner_lineage,
    )

    snapshot_payload = get_json_artifact(
        ensure_ir_artifact_store(store), _as_ir_artifact_ref(observed_source_ref)
    )
    snapshot = DataSnapshot.model_validate(snapshot_payload)
    try:
        validate_data_snapshot_owner_lineage(store, observed_source_ref, snapshot)
    except DataSnapshotSourceRowNotEstablished as exc:
        raise PredictiveCalibrationError(
            "predictive_calibration_acquired_source_row_not_established"
        ) from exc
    return snapshot


''';assert s.count(marker)==1;s=s.replace(marker,helper+marker)
for role in ['request','association']:
 before=f'''        snapshot_payload = get_json_artifact(
            ensure_ir_artifact_store(store),
            _as_ir_artifact_ref({role}.observed_source_ref),
        )
        snapshot = DataSnapshot.model_validate(snapshot_payload)
        from polisyos.runtime.quality.data_snapshot_lineage import (
            validate_data_snapshot_owner_lineage,
        )

        validate_data_snapshot_owner_lineage(
            store,
            {role}.observed_source_ref,
            snapshot,
        )''';after=f'''        snapshot = _load_verified_observed_data_snapshot(store, {role}.observed_source_ref)''';assert s.count(before)==1;s=s.replace(before,after)
# Existing enclosing catch keeps operation-specific refusal, cause retains typed limit.
p=O/'contexts'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s);contexts.append((rel,base,s,'predictive-observed-source-intake.diff'))
m['context_companions']=[]
for rel,b,s,name in contexts:
 patch=''.join(difflib.unified_diff(b.splitlines(keepends=True),s.splitlines(keepends=True),fromfile='a/'+rel,tofile='b/'+rel));(O/name).write_text(patch);m['context_companions'].append({'path':rel,'preimage_sha256':sha(b.encode()),'candidate_postimage_sha256':sha(s.encode()),'context_patch':str((O/name).relative_to(R)),'patch_sha256':sha(patch.encode()),'composition':'Root context-merge only; PCL shared C50 writer must reconcile exact preimage; no full postimage overwrite.'})
m['supersedes_manifest_sha256']=sha((old/'manifest.json').read_bytes());m['delta']='Store-only acquired lineage refuses authority by default; explicit candidate result carries source-row not-established limitation. WMR builder/reload carry and enforce limited band/blocker; both PCL observed joins share strict canonical intake.';(O/'manifest.pending.json').write_text(json.dumps(m,indent=2)+'\n')
print(O)
