"""Dependency-only runtime admission probe; no product imports."""
import inspect
import json
import sys
import types
import pytest_v3_structured_exception_witness as plugin
import structured_capture
native, provenance = plugin.native_access()
assert not any(name == "polisyos" or name.startswith("polisyos.") for name in sys.modules)
print(json.dumps({"schema": "e02.v3-r3-dependency-provenance.v1", "status": "dependency_only_PASS", "provenance": provenance, "validation_error_class": {"module": native.cls.__module__, "qualname": native.cls.__qualname__, "error_count_descriptor": type(native.count).__name__, "errors_descriptor": type(native.errors).__name__, "title_descriptor": type(native.title).__name__, "descriptors_owned_by_exact_class": all(x.__objclass__ is native.cls for x in (native.count,native.errors,native.title))}, "capture_fields": sorted(structured_capture.FIELDS), "product_modules_imported": [], "product_model_runtime_class_code_fields": "UNRUN: must be admitted by wrapper inside Root fresh case before target", "unresolved_by_construction": ["native SchemaValidator internal state", "opaque mutable schema leaf contents", "pre-admission same-shaped tampering", "runtime product readset and results"]}, indent=2))
