"""Admit one source-bound V3 node and a narrow handled-error observer."""
from __future__ import annotations

import ast
import hashlib
import importlib.metadata
import inspect
import json
import os
import sys
import types
from pathlib import Path

import pytest
import structured_capture as structured
import v3_exception_witness as witness_module
from structured_capture import CallSite, NativeAccess, StructuredExceptionWitness
from v3_exception_witness import WitnessError

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
CASES = ROOT / "policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1"
SOURCE = ROOT / "policy-engine/src/polisyos/runtime/quality/generation_cycle.py"
JOINT = ROOT / "policy-engine/src/polisyos/runtime/quality/joint_simulation_horizon.py"
TEST_SOURCE = ROOT / "policy-engine/tests/integration/core_runtime/test_acquisition_receiver_constructor_served.py"
FIXTURE_SOURCES = (
    "policy-engine/tests/_helpers/acquisition_served_history.py",
    "policy-engine/tests/_helpers/acquisition_chain.py",
    "policy-engine/tests/_helpers/candidate_cycle_source_profile.py",
    "policy-engine/tests/_helpers/acquisition_production.py",
    "policy-engine/tests/integration/core_runtime/test_acquisition_retained_sequential_served.py",
)
NODE = "tests/integration/core_runtime/test_acquisition_receiver_constructor_served.py::test_real_b_receiver_dispatch_and_settings_are_consumed"
STRICT_AST = "e3ccf9c41d4dafe066b2790ca2e2fd82e553e4fddea281c13d62e08d9e697616"
MODEL_AST = "ddffab090293678a5c4a35f88db4d8ad288492b050d5fab717ed83da72b60d7c"
NATIVE_SHA = "ac3118649cd44d45d951143cc152b34a82d524a499bf74d235a0f827ec3cd771"
PYDANTIC_INIT_SHA = "e62127278c07bf5384cdd2903f368a69929f3b8a524000bae4e0eb608ebf4bc6"
PYDANTIC_MAIN_SHA = "5994f1c16f358a097be58d34cc72499a8537a82352cbed4a084984b013dfb624"
LOCK_SHA = "ccfdca0e741dc77795f5af61871af5d62e73feebf55c7ffb28cd16e55fe207e9"
PROJECT_SHA = "5f65308cb088086b6fc0aa40a5bae6ed852ae3a2e261103bd0d4158d97c1e8f2"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def checked(path: Path, expected: str | None, code: str) -> str:
    if not expected or path.is_symlink() or digest(path) != expected:
        raise WitnessError(code)
    return expected


def model_and_call(source: bytes) -> tuple[int, int]:
    tree = ast.parse(source, filename=str(JOINT))
    def one(name: str, node_type):
        found = [node for node in tree.body if isinstance(node, node_type) and node.name == name]
        if len(found) != 1:
            raise WitnessError("v3_structured_owner_not_unique")
        return found[0]
    for name, expected in (("_StrictModel", STRICT_AST), ("PhysicalSimulationWorkObservation", MODEL_AST)):
        node = one(name, ast.ClassDef)
        actual = hashlib.sha256(ast.dump(node, include_attributes=False).encode()).hexdigest()
        if actual != expected:
            raise WitnessError("v3_structured_model_not_reviewed")
    fn = one("_run_cached_replicates", ast.FunctionDef)
    calls = [node for node in ast.walk(fn) if isinstance(node, ast.Call)
             and isinstance(node.func, ast.Name) and node.func.id == "PhysicalSimulationWorkObservation"]
    if len(calls) != 1:
        raise WitnessError("v3_structured_constructor_not_unique")
    return calls[0].lineno, calls[0].end_lineno


def native_access():
    import pydantic
    import pydantic.main
    import pydantic_core
    import pydantic_core._pydantic_core as native_module
    if sys.version_info[:3] != (3, 14, 3):
        raise WitnessError("v3_structured_python_version_mismatch")
    if (importlib.metadata.version("pydantic") != "2.12.5" or
            importlib.metadata.version("pydantic-core") != "2.41.5"):
        raise WitnessError("v3_structured_dependency_version_mismatch")
    expected_dir = ROOT / "policy-engine/.venv/lib/python3.14/site-packages"
    files = (
        (Path(native_module.__file__), expected_dir / "pydantic_core/_pydantic_core.cpython-314-darwin.so", NATIVE_SHA),
        (Path(pydantic.__file__), expected_dir / "pydantic/__init__.py", PYDANTIC_INIT_SHA),
        (Path(pydantic.main.__file__), expected_dir / "pydantic/main.py", PYDANTIC_MAIN_SHA),
    )
    for actual, expected_path, expected_hash in files:
        if actual.resolve(strict=True) != expected_path.resolve(strict=True):
            raise WitnessError("v3_structured_dependency_origin_mismatch")
        checked(actual, expected_hash, "v3_structured_dependency_bytes_mismatch")
    checked(ROOT / "policy-engine/uv.lock", LOCK_SHA, "v3_structured_lock_mismatch")
    checked(ROOT / "policy-engine/pyproject.toml", PROJECT_SHA, "v3_structured_project_mismatch")
    cls = native_module.ValidationError
    if (pydantic.ValidationError is not cls or pydantic_core.ValidationError is not cls
            or pydantic_core.SchemaValidator is not native_module.SchemaValidator):
        raise WitnessError("v3_structured_native_class_mismatch")
    descriptors = [inspect.getattr_static(cls, name) for name in ("error_count", "errors", "title")]
    if (type(descriptors[0]) is not types.MethodDescriptorType or
            type(descriptors[1]) is not types.MethodDescriptorType or
            type(descriptors[2]) is not types.GetSetDescriptorType or
            any(descriptor.__objclass__ is not cls for descriptor in descriptors)):
        raise WitnessError("v3_structured_native_descriptor_mismatch")
    return NativeAccess(cls, *descriptors), {"python": sys.version, "executable": sys.executable,
        "pydantic": "2.12.5", "pydantic_core": "2.41.5",
        "native_origin": str(files[0][0].resolve(strict=True)), "native_sha256": NATIVE_SHA,
        "pydantic_init_sha256": PYDANTIC_INIT_SHA, "pydantic_main_sha256": PYDANTIC_MAIN_SHA,
        "project_sha256": PROJECT_SHA, "lock_sha256": LOCK_SHA}


def model_schema(model):
    import pydantic_core
    model_dict = vars(model)
    schema = model_dict.get("__pydantic_core_schema__")
    validator = model_dict.get("__pydantic_validator__")
    rule = model_dict.get("_work_observation_binding")
    if (type(validator) is not pydantic_core.SchemaValidator or type(schema) is not dict
            or schema.get("type") != "function-after" or type(schema.get("function")) is not dict
            or schema["function"].get("function") is not rule or type(rule) is not types.FunctionType
            or type(schema.get("schema")) is not dict or schema["schema"].get("cls") is not model
            or type(schema["schema"].get("schema")) is not dict
            or type(schema["schema"]["schema"].get("fields")) is not dict
            or set(schema["schema"]["schema"]["fields"]) != structured.FIELDS):
        raise WitnessError("v3_structured_live_schema_mismatch")
    return schema, validator, rule, structured.schema_fingerprint(schema)


@pytest.hookimpl(hookwrapper=True, tryfirst=True)
def pytest_runtest_call(item):
    if item.nodeid != NODE:
        yield
        return
    from polisyos.runtime.quality import generation_cycle, joint_simulation_horizon as joint
    source_sha = checked(SOURCE, os.environ.get("V3_EXCEPTION_SOURCE_SHA256"), "v3_target_source_mismatch")
    if Path(generation_cycle.__file__).resolve(strict=True) != SOURCE.resolve(strict=True):
        raise WitnessError("v3_target_origin_mismatch")
    test_sha = checked(TEST_SOURCE, os.environ.get("V3_EXCEPTION_TEST_SHA256"), "v3_test_source_mismatch")
    if Path(str(item.path)).resolve(strict=True) != TEST_SOURCE.resolve(strict=True):
        raise WitnessError("v3_test_origin_mismatch")
    fixture_hashes = json.loads(os.environ["V3_EXCEPTION_FIXTURE_HASHES"])
    if type(fixture_hashes) is not dict or set(fixture_hashes) != set(FIXTURE_SOURCES):
        raise WitnessError("v3_fixture_denominator_mismatch")
    for rel in FIXTURE_SOURCES:
        checked(ROOT / rel, fixture_hashes[rel], "v3_fixture_source_mismatch")
    for env_name, file in (("V3_EXCEPTION_PLUGIN_SHA256", Path(__file__)),
                           ("V3_EXCEPTION_WITNESS_SHA256", Path(witness_module.__file__)),
                           ("V3_EXCEPTION_EXTENSION_SHA256", Path(structured.__file__))):
        checked(file, os.environ.get(env_name), "v3_instrument_source_mismatch")
    joint_sha = checked(JOINT, os.environ.get("V3_JOINT_SOURCE_SHA256"), "v3_joint_source_mismatch")
    if Path(joint.__file__).resolve(strict=True) != JOINT.resolve(strict=True):
        raise WitnessError("v3_joint_origin_mismatch")
    line, end_line = model_and_call(JOINT.read_bytes())
    model = joint.PhysicalSimulationWorkObservation
    if (model.__module__ != joint.__name__ or model.__name__ != "PhysicalSimulationWorkObservation"
            or model.__bases__ != (joint._StrictModel,) or set(model.model_fields) != structured.FIELDS):
        raise WitnessError("v3_structured_live_model_mismatch")
    native, native_provenance = native_access()
    schema, validator, rule, schema_snapshot = model_schema(model)
    runtime_code = joint._run_cached_replicates.__code__
    compiled = compile(JOINT.read_bytes(), runtime_code.co_filename, "exec", dont_inherit=True)
    matching = [code for code in compiled.co_consts if isinstance(code, types.CodeType)
                and code.co_name == "_run_cached_replicates"]
    if len(matching) != 1 or runtime_code != matching[0]:
        raise WitnessError("v3_structured_live_function_mismatch")
    class_codes = [code for code in compiled.co_consts if isinstance(code, types.CodeType)
                   and code.co_name == "PhysicalSimulationWorkObservation"]
    rule_codes = [code for code in class_codes[0].co_consts if isinstance(code, types.CodeType)
                  and code.co_name == "_work_observation_binding"] if len(class_codes) == 1 else []
    if len(rule_codes) != 1 or rule.__code__ != rule_codes[0]:
        raise WitnessError("v3_structured_live_rule_mismatch")
    if Path(runtime_code.co_filename).resolve(strict=True) != JOINT.resolve(strict=True):
        raise WitnessError("v3_structured_code_origin_mismatch")
    case = Path(os.environ["V3_EXCEPTION_CASE_DIR"])
    if (not case.is_absolute() or case.parent != CASES or case.is_symlink()
            or any(parent.is_symlink() for parent in case.parents) or not case.is_dir()
            or case.resolve(strict=True) != case):
        raise WitnessError("v3_witness_case_path_invalid")
    output = case / "v3-n5-structured-exceptions.json.gz"
    if os.path.lexists(output):
        raise WitnessError("v3_witness_output_already_exists")
    target = generation_cycle.GenerationCycleController._run_proposal_candidate_scenario_n5
    site = CallSite(runtime_code, vars(joint), model, line, line, schema, validator, rule, schema_snapshot, rule.__code__)
    witness = StructuredExceptionWitness(target.__code__, output, native, site)
    witness.source_bindings = {"product_source_sha256": source_sha, "joint_source_sha256": joint_sha,
        "test_source_sha256": test_sha, "fixture_source_sha256": fixture_hashes,
        "plugin_sha256": os.environ["V3_EXCEPTION_PLUGIN_SHA256"],
        "witness_sha256": os.environ["V3_EXCEPTION_WITNESS_SHA256"],
        "extension_sha256": os.environ["V3_EXCEPTION_EXTENSION_SHA256"], "selected_node": NODE,
        "strict_model_ast_sha256": STRICT_AST, "model_ast_sha256": MODEL_AST,
        "constructor_call_start": line, "constructor_call_end": end_line,
        "accepted_traceback_line": line, "native_provenance": native_provenance,
        "process_schema_container_snapshot_sha256": schema_snapshot}
    witness.start()
    try:
        yield
    finally:
        try:
            witness.finish()
        except BaseException:
            pass
