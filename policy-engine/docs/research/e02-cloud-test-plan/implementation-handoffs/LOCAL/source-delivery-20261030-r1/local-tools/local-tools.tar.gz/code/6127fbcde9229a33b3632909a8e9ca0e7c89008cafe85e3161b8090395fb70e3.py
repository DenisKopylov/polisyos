from pathlib import Path
base=Path('LOCAL/raw/e02-execution-20261027/repairs/child-core-custody-r1/postimages/policy-engine/src/polisyos/core')
p=base/'run/child_custody.py';s=p.read_text()
s=s.replace('    from ..artifacts.protocol import ArtifactReader\n','    from ..artifacts.protocol import ArtifactReader\n    from ..artifacts.store import _BoundedMemberOpenAttempt, _VerifiedCASMemberStream\n')
s=s.replace(') -> Iterator[object]:',') -> Iterator[_VerifiedCASMemberStream]:')
anchor='    def _options(self, opts: ArtifactWriteOptions) -> ArtifactWriteOptions:\n'
new='''    def open_member_bounded(
        self, artifact_id: ArtifactRef, member: Literal["blob"], *,
        max_manifest_bytes: int, expected_manifest_sha256: str, max_member_bytes: int,
    ) -> _BoundedMemberOpenAttempt:
        """Preserve the existing bounded stream and its actual read usage receipts."""
        store, ref = self._resolve(artifact_id)
        return store.open_member_bounded(ref, member,
            max_manifest_bytes=max_manifest_bytes,
            expected_manifest_sha256=expected_manifest_sha256,
            max_member_bytes=max_member_bytes)

'''
assert anchor in s;s=s.replace(anchor,new+anchor)
# Record genuine staged effects as a finite typed JSON preimage, with no Root mutation.
anchor='    def _execution_outcome(\n'
new='''    def _effects_payload(self) -> dict[str, JsonValue]:
        def normalize(value: object) -> JsonValue:
            if type(value) in {ArtifactRef, WarningRecord}:
                return value.model_dump(mode="json")
            if value is None or type(value) in {str, bool, int, float}:
                json.dumps(value, allow_nan=False)
                return value
            if type(value) in {tuple, list}:
                return [normalize(item) for item in value]
            if type(value) is dict and all(type(key) is str for key in value):
                return {key: normalize(item) for key, item in value.items()}
            raise ChildReleaseUnavailableError("parent_effect_not_finite_typed_json")
        return {"updates": normalize(self._updates), "events": normalize(self._events)}

'''
assert anchor in s;s=s.replace(anchor,new+anchor)
s=s.replace('''                execution_outcome=outcome,
            )''','''                execution_outcome=outcome,
                parent_effects=self._effects_payload(),
                parent_effects_sha256=child_binding_digest(self._effects_payload()),
            )''')
# Need exact locate formatted block for fence/effects.
a=s.index('            fence = self._fence.publication()')
b=s.index('    def release(self,',a) if '    def release(self,' in s[a:] else s.index('    def release(\n',a)
old=s[a:b]
new='''            fence = self._fence.publication() if self._fence is not None else nullcontext()
            with fence, self._root._parent_state_transition_lease(run_scoped=False), self._lock:
                self._check_root(self._binding)
                if self._state != "preparing":
                    raise ChildReleaseUnavailableError("session_revoked_during_copy")
                reconciled = self._ledger.commit(record_ref)
                receipt = ChildReleaseReceipt(self._release_id, record_ref, final_projection_ref, selected,
                    outcome, "released_ack_reconciled" if reconciled else "released")
                # Set before context exit: a lost DB/fence acknowledgement after
                # the durable CAS commit must retain the committed receipt.
                self._receipt = receipt
                self._state = "released"
            # The job DB fence is no longer held. Each actual Root operation uses
            # its existing lifecycle owner. Cancellation before settlement refuses
            # remaining effects; committed release is historical, never rolled back.
            total = len(self._updates) + len(self._events)
            self._ledger.record_settlement("pending", completed=0, total=total)
            completed = 0
            for changes in self._updates:
                self._check_root(self._binding)
                self._root.update_manifest(**changes)
                completed += 1
                self._ledger.record_settlement("pending", completed=completed, total=total)
            for event in self._events:
                self._check_root(self._binding)
                self._root.emit(**event)
                completed += 1
                self._ledger.record_settlement("pending", completed=completed, total=total)
            self._ledger.record_settlement("settled", completed=completed, total=total)
            self._effects_settled = True
            return receipt
        except BaseException as exc:
            with self._lock:
                if self._receipt is not None:
                    try:
                        self._ledger.record_settlement("unknown", completed=-1,
                            total=len(self._updates) + len(self._events))
                    except OSError:
                        pass  # Original failure and committed receipt remain the deciding facts.
                    if isinstance(exc, ChildParentSettlementError):
                        raise
                    raise ChildParentSettlementError(self._receipt) from exc
                if self._state == "preparing":
                    self._state = "revoked"
                    self._ledger.revoke("release_preparation_or_currentness_failed")
            raise

'''
s=s[:a]+new+s[b:];p.write_text(s)
p=base/'artifacts/child_release.py';s=p.read_text()
s=s.replace('    execution_outcome: Literal["completed", "partial", "failed", "unknown"]\n','    execution_outcome: Literal["completed", "partial", "failed", "unknown"]\n    parent_effects: dict[str, JsonValue]\n    parent_effects_sha256: str = Field(pattern=r"^sha256:[0-9a-f]{64}$")\n')
s=s.replace('    # Bind the record\'s own staged occurrence too;', '    if child_binding_digest(record.parent_effects) != record.parent_effects_sha256:\n        raise ChildReleaseUnavailableError("parent_effects_digest_mismatch")\n    # Bind the record\'s own staged occurrence too;')
anchor='    def revoke(self, reason: str) -> None:\n'
new='''    def record_settlement(self, state: Literal["pending", "settled", "unknown"], *, completed: int, total: int) -> None:
        """Record acknowledgement progress, never permission or a claim of rollback."""
        if self.head().status != "released":
            raise ChildReleaseUnavailableError("settlement_requires_committed_release")
        path = self.path.with_name(self.release_id + ".settlement.json")
        payload = json.dumps({"schema_version": "1.0", "release_id": self.release_id,
            "status": state, "completed": completed, "total": total}, sort_keys=True).encode()
        AtomicFileWriter.replace(path, payload, durable_parent=True)

'''
assert anchor in s;s=s.replace(anchor,new+anchor);p.write_text(s)
