from pathlib import Path
D=Path(__file__).parent/'postimages/policy-engine'
p=D/'tests/unit/runtime/http/test_observational_method_runtime.py';s=p.read_text()
# Explicit dependency result path uses real policy adapter and preserves the previous evaluated prefix.
s=s.replace('''        self.after_primary: Any = None

    async def check''','''        self.after_primary: Any = None
        self.unavailable: set[str] = set()

    async def check''',1)
s=s.replace('''        return AuthzResult(
            decision=(
                AuthzDecision.DENY
                if authz_input.resource_artifact_id in self.denied''','''        if authz_input.resource_artifact_id in self.unavailable:
            return AuthzResult(
                decision=AuthzDecision.DENY,
                policy="polisyos/authz/decision",
                reasons=("OPA_UNREACHABLE",),
            )
        return AuthzResult(
            decision=(
                AuthzDecision.DENY
                if authz_input.resource_artifact_id in self.denied''',1)
start=s.index('def test_populated_comparison_authorizes_entire_owner_source_set(');end=s.index('\ndef test_two_real_completed_ex_ante_sources_are_reselected_by_fresh_planner(',start);part=s[start:end]
part=part.replace('''    from polisyos.runtime.http import authz_middleware
''','''    from polisyos.runtime.http import access_audit, authz_middleware
    from polisyos.runtime.http.access_audit import (
        RuntimeAuthorizationAuditError,
        RuntimeDataAccessAuditTrail,
        verify_runtime_authorization_audit,
    )
''',1)
needle='''    expected = completed["fresh_comparison"]
''';idx=part.index(needle)
part=part[:idx]+'''    verified = verify_runtime_authorization_audit(
        admission,
        expected_request_id=admission["request_id"],
        expected_selection_run_id=primary.run_id,
    )
    assert verified in audit.authorization_decisions
    assert audit.invalid_authorization_event_count == 0

    # Reopen actual serialized bytes through the real cold trail/parser. These are
    # test-owned copies; no original audit or CAS artifact is edited.
    def cold_scan(name: str, payload: dict[str, Any]) -> Any:
        path = tmp_path / ("audit-v2-" + name + ".jsonl")
        path.write_text(json.dumps(payload) + "\\n", encoding="utf-8")
        return RuntimeDataAccessAuditTrail(path=path).scan_read_only()

    assert cold_scan("valid", admission).authorization_decisions == (verified,)
    corruptions: dict[str, dict[str, Any]] = {}
    for name in (
        "target-order", "owner-member-order", "target-digest", "target-permission",
        "denied-target-in-allow", "changed-primary-run", "changed-request",
    ):
        payload = json.loads(json.dumps(admission))
        if name == "target-order":
            payload["related_target_decisions"].reverse()
        elif name == "owner-member-order":
            context = json.loads(payload["bound_context"])
            context["comparison_basis"]["request"]["sources"].reverse()
            from polisyos.core import canon

            payload["bound_context"] = canon.to_canonical_bytes(
                context, canon.CanonSpec(forbid_floats=False)
            ).decode("utf-8")
        elif name == "target-digest":
            payload["related_target_decisions"][0]["resource_digest"] = "sha256:" + "0" * 64
        elif name == "target-permission":
            payload["related_target_decisions"][0]["permission"] = "artifacts.batch.read"
        elif name == "denied-target-in-allow":
            payload["related_target_decisions"][0]["outcome"] = "deny"
        elif name == "changed-primary-run":
            context = json.loads(payload["bound_context"])
            context["core_run_id"] += "-different"
            from polisyos.core import canon

            payload["bound_context"] = canon.to_canonical_bytes(
                context, canon.CanonSpec(forbid_floats=False)
            ).decode("utf-8")
        else:
            payload["request_id"] += "-different"
        # Except the request checksum control, recompute it: a checksum-only
        # validator must not pass ordered-target/context/permission corruption.
        if name != "changed-request":
            payload["receipt_sha256"] = access_audit._authorization_receipt_sha256(payload)
        corruptions[name] = payload
        with pytest.raises(ValueError):
            verify_runtime_authorization_audit(payload)
        scan = cold_scan(name, payload)
        assert scan.invalid_authorization_event_count == 1
        assert scan.authorization_decisions == ()
        assert scan.parsed_object_count == 1
    # A complete valid receipt for a different independently held tuple is still
    # a replay, even though it is internally consistent. No history-MAC claim.
    with pytest.raises(ValueError, match="different request"):
        verify_runtime_authorization_audit(admission, expected_request_id="other-request")
    with pytest.raises(ValueError, match="different selected run"):
        verify_runtime_authorization_audit(admission, expected_selection_run_id="other-run")
    # Remove only the semantic verifier, keep every field and serializer marker.
    with monkeypatch.context() as remove_cold_property:
        remove_cold_property.setattr(
            access_audit, "_verify_serialized_authorization_context", lambda event: None
        )
        counterexample = cold_scan("removed-verifier", corruptions["target-permission"])
        assert counterexample.invalid_authorization_event_count == 0
        assert len(counterexample.authorization_decisions) == 1
    assert cold_scan("restored-verifier", corruptions["target-permission"]).invalid_authorization_event_count == 1

'''+part[idx:]
# Existing no-output helper also applies audit-unavailable503.
part=part.replace('assert response.status_code in {403, 409}, response.text','assert response.status_code in {403, 409, 503}, response.text',1)
idx=part.index('        with monkeypatch.context() as guard:')
part=part[:idx]+'''        trail = reader["app"].state.runtime_container.runtime_access_audit

        def assert_terminal_deny(
            request_id: str, reason: str, expected_outcomes: tuple[str, ...]
        ) -> None:
            cold = trail.scan_read_only()
            assert cold.invalid_authorization_event_count == 0
            events = [event for event in cold.authorization_decisions if event.request_id == request_id]
            assert len(events) == 1
            event = events[0]
            assert event.outcome.value == "deny"
            assert event.denial_reason == reason
            assert event.resource_id == primary_id
            assert event.bound_context == admission["bound_context"]
            assert tuple(row.outcome.value for row in event.related_target_decisions) == expected_outcomes
            assert tuple(row.resource_id for row in event.related_target_decisions) == tuple(
                row["resource_id"] for row in admission["related_target_decisions"][:len(expected_outcomes)]
            )
            verify_runtime_authorization_audit(
                event.model_dump(mode="json"),
                expected_request_id=request_id,
                expected_selection_run_id=primary.run_id,
            )

'''+part[idx:]
part=part.replace('''            denied = reader["client"].get(url)
''','''            denied = reader["client"].get(url, headers={"X-Request-ID": "r5-target-policy-denied"})
''',1)
part=part.replace('''            assert_no_projection(denied, sources)
''','''            assert_no_projection(denied, sources)
            assert_terminal_deny("r5-target-policy-denied", "related_run_authorization_denied", ("deny",))
''',1)
a=part.index('            for alternate in alternative_bases:');b=part.index('            # Real test-owned lifecycle',a)
part=part[:a]+'''            for alternative_index, alternate in enumerate(alternative_bases):
                for deny_b in (False, True):
                    changed = []

                    def read_basis(
                        *, changed: list[bool] = changed, alternate: Any = alternate, **kwargs: Any
                    ) -> Any:
                        if changed and kwargs["run_id"] == primary.run_id:
                            return alternate
                        return original_basis(**kwargs)

                    request_id = f"r5-changed-{alternative_index}-{int(deny_b)}"
                    policy.denied = {target_b} if deny_b else set()
                    with monkeypatch.context() as crossed_owner_read:
                        crossed_owner_read.setattr(
                            cold_service, "_read_current_completed_ex_ante_comparison_basis", read_basis
                        )
                        policy.after_primary = lambda changed=changed: changed.append(True)
                        refused = reader["client"].get(url, headers={"X-Request-ID": request_id})
                    assert refused.status_code == 409, refused.text
                    assert refused.json()["code"] == "comparison_target_set_changed"
                    assert_no_projection(refused, [*sources, extra])
                    assert_terminal_deny(
                        request_id, "comparison_target_set_changed", ("deny" if deny_b else "allow",)
                    )
                    assert cold_service._control_store.get_job(primary.job_id) == primary_record
                    assert (
                        reader["app"].state.runtime_api_ctx.run_index.get_run(primary.run_id).details.manifest_ref
                        == primary_manifest
                    )
            policy.denied.clear()
            policy.unavailable = {target_b}
            unavailable = reader["client"].get(url, headers={"X-Request-ID": "r5-target-dependency"})
            policy.unavailable.clear()
            assert unavailable.status_code == 503, unavailable.text
            assert_no_projection(unavailable, sources)
            assert_terminal_deny("r5-target-dependency", "related_run_policy_dependency_unavailable", ())

            attempts: list[Any] = []

            def no_audit(*args: Any, **kwargs: Any) -> None:
                attempts.append(args)
                raise RuntimeAuthorizationAuditError("test-owned audit unavailable")

            policy.denied = {target_b}
            with monkeypatch.context() as unavailable_audit:
                unavailable_audit.setattr(trail, "_append_authorization_decision", no_audit)
                refused = reader["client"].get(url, headers={"X-Request-ID": "r5-audit-unavailable"})
            assert refused.status_code == 503, refused.text
            assert refused.json()["code"] == "authorization_audit_unavailable"
            assert_no_projection(refused, sources)
            assert len(attempts) == 1
            assert not any(
                event.request_id == "r5-audit-unavailable" for event in trail.scan_read_only().authorization_decisions
            )
            policy.denied.clear()

'''+part[b:]
part=part.replace('''            refused = reader["client"].get(url)
            assert refused.status_code == 403, refused.text
            assert_no_projection(refused, sources)
            assert cold_service''','''            refused = reader["client"].get(url, headers={"X-Request-ID": "r5-unresolved-source"})
            assert refused.status_code == 403, refused.text
            assert_no_projection(refused, sources)
            assert_terminal_deny("r5-unresolved-source", "comparison_target_basis_unresolved", ("allow",))
            assert cold_service''',1)
s=s[:start]+part+s[end:];p.write_text(s)
