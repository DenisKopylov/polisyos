from pathlib import Path
import ast,json,hashlib,difflib,subprocess
root=Path.cwd();out=root/'LOCAL/raw/e02-execution-20261027/repairs/C86-portable-fixtures-r1';base='192fc44303c63e52e4dfa8e0b4ee77790bae3394';cloud='ea3d65682d76a5d66d514e525ad2212e5a85f669';git=lambda *a:subprocess.check_output(['git',*a],cwd=root);h=lambda b:hashlib.sha256(b).hexdigest();paths=['policy-engine/tests/_helpers/observational_source_runtime.py','policy-engine/tests/unit/runtime/http/test_runtime_api_authz.py','policy-engine/tests/unit/runtime/http/test_observational_method_runtime.py','policy-engine/tests/unit/scientist/compute/test_runner_method_execution_work.py'];pre={x:git('show',base+':'+x).decode() for x in paths};post=dict(pre)
x=paths[0];post[x]='''"""Authenticated selected-Catalog Runtime fixtures for candidate source regressions."""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Any

import pytest

from polisyos.runtime.quality.substrate_registry import CatalogServingSourceSelection
from tests._helpers.control_worker import stop_embedded_control_worker
from tests._helpers.runtime_http import build_runtime_api_env, close_runtime_api_env
from tests.unit.runtime.http.test_runtime_api_authz import (
    _AllowOPA,
    _build_secure_client,
    _claims,
    _fixture_bearer,
)
from tests.unit.runtime.quality.test_catalog_source_identity import _selected_fixture


@contextmanager
def _selected_runtime_api_env(tmp_path: Path) -> Iterator[dict[str, Any]]:
    """Reuse the actual test-owned Catalog and its typed selected-source owner."""
    code_root, owner_root, selected = _selected_fixture(tmp_path / "catalog")
    selection = CatalogServingSourceSelection(
        snapshot_root=selected.snapshot_root,
        source_owner_root=owner_root,
        database_relative_path=selected.database_relative_path,
        catalog_run_profile="prod_full",
    )
    env = build_runtime_api_env(
        tmp_path / "api",
        include_test_client=True,
        app_kwargs={"repo_root": code_root, "catalog_source_selection": selection},
    )
    try:
        source = env["app"].state._control_service._catalog_serving_source
        assert source.selection_basis == "explicit_path_candidate_only"
        assert source.database_path == selected.database_path
        assert source.source_owner_root == owner_root.resolve()
        yield {
            **env,
            "catalog_code_root": code_root,
            "catalog_selection": selection,
            "catalog_source": selected,
        }
    finally:
        close_runtime_api_env(env)


@pytest.fixture
def selected_source_runtime_api_env(tmp_path: Path) -> Iterator[dict[str, Any]]:
    """Expose the same real selected-Catalog fixture to the legacy HTTP cohort."""
    with _selected_runtime_api_env(tmp_path) as env:
        yield env


@pytest.fixture
def scoped_source_runtime(tmp_path: Path) -> Iterator[dict[str, Any]]:
    """Enter the actual authenticated app and retain its selected Catalog owner."""
    with _selected_runtime_api_env(tmp_path) as env:
        client, cell, provider = _build_secure_client(
            env,
            opa_client=_AllowOPA(),
            claims_by_token={},
            repo_root=env["catalog_code_root"],
            catalog_source_selection=env["catalog_selection"],
        )
        # TestClient only runs the real container startup inside its lifespan.
        # Read the new authenticated app's service after that startup completes.
        with client:
            service = client.app.state.runtime_container.control_service
            assert service is not None
            source = service._catalog_serving_source
            assert source.database_path == env["catalog_source"].database_path
            assert source.source_owner_root == env["catalog_source"].source_owner_root
            stop_embedded_control_worker(service)
            result = {**env, "client": client, "service": service, "cell": cell.cell_id}
            for label in ("a", "b"):
                token = _fixture_bearer("source-access-" + label)
                tenant = env["tenant_" + label]
                provider.put_claim(
                    token,
                    _claims(tenant_id=tenant, cell_id=cell.cell_id, jti="source-" + label),
                )
                result["headers_" + label] = {
                    "Authorization": "Bearer " + token,
                    "X-Tenant-ID": tenant,
                }
            try:
                yield result
            finally:
                stop_embedded_control_worker(service)
'''
x=paths[1];post[x]=post[x].replace('from typing import Any, Protocol, TypeGuard, cast','from pathlib import Path\nfrom typing import TYPE_CHECKING, Any, Protocol, TypeGuard, cast',1)
# Type-only selected-source contract, preserving the existing optional dependency guard.
marker='\n\ntry:  # pragma: no cover - optional dependency guard\n';assert post[x].count(marker)==1;post[x]=post[x].replace(marker,'\n\nif TYPE_CHECKING:\n    from polisyos.runtime.quality.substrate_registry import CatalogServingSourceSelection\n'+marker,1)
old='''    service_spiffe_id: str | None = None,
    container_overrides=None,
):
    registry = CellRegistry()''';new='''    service_spiffe_id: str | None = None,
    container_overrides=None,
    repo_root: Path | None = None,
    catalog_source_selection: CatalogServingSourceSelection | None = None,
):
    registry = CellRegistry()''';assert post[x].count(old)==1;post[x]=post[x].replace(old,new)
start=post[x].index('def _build_secure_client(');end=post[x].index('\n\ndef _build_permissionless_client',start);part=post[x][start:end];old='''        container_overrides=container_overrides,
    )''';new='''        container_overrides=container_overrides,
        repo_root=repo_root,
        catalog_source_selection=catalog_source_selection,
    )''';assert part.count(old)==1;post[x]=post[x][:start]+part.replace(old,new)+post[x][end:]
x=paths[2];old='''    scoped_source_runtime as scoped_source_runtime,
''';assert post[x].count(old)==1;post[x]=post[x].replace(old,old+'''    selected_source_runtime_api_env as selected_source_runtime_api_env,
''')
for name in ['test_http_post_refuses_restricted_or_foreign_tenant_source_before_enqueue','test_http_post_refuses_source_without_owner_claim_before_enqueue']:
 start=post[x].index('def '+name+'(');end=post[x].find('\n\ndef ',start+1);part=post[x][start:end];assert part.count('    runtime_api_env: dict[str, Any],')==1;part=part.replace('    runtime_api_env: dict[str, Any],','    selected_source_runtime_api_env: dict[str, Any],',1);part=part.replace(') -> None:\n',') -> None:\n    runtime_api_env = selected_source_runtime_api_env\n',1);post[x]=post[x][:start]+part+post[x][end:]
x=paths[3];old='''    from polisyos.foundry.data_plane import bindings

    prepared = type(''';new='''    from polisyos.foundry import data_plane

    prepared = type(''';assert post[x].count(old)==1;post[x]=post[x].replace(old,new)
old='''    monkeypatch.setattr(bindings, "prepare_hte_observational_input", prepare, raising=False)''';new='''    # The worker imports this public facade at its call boundary; patch the
    # consumed name rather than the implementation module's already-copied alias.
    monkeypatch.setattr(data_plane, "prepare_hte_observational_input", prepare)''';assert post[x].count(old)==1;post[x]=post[x].replace(old,new)
rows=[];patch=''
for path in paths:
 b=post[path].encode();ast.parse(b,filename=path);q=out/'postimages'/path;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);rows.append({'path':path,'preimage_sha256':h(pre[path].encode()),'cloud_ea_preimage_sha256':h(git('show',cloud+':'+path)),'preimage_same_as_cloud':pre[path].encode()==git('show',cloud+':'+path),'postimage_sha256':h(b),'bytes':len(b),'postimage':'postimages/'+path});patch+=''.join(difflib.unified_diff(pre[path].splitlines(True),post[path].splitlines(True),fromfile='a/'+path,tofile='b/'+path))
(out/'source.patch').write_text(patch);(out/'manifest.json').write_text(json.dumps({'schema':'policyos.e02.C86.fixture_remediation_proposal.v1','state':'proposal_only_not_applied_runtime_UNRUN','base_commit':base,'base_tree':git('rev-parse',base+'^{tree}').decode().strip(),'cloud_loaded_base':cloud,'cloud_loaded_tree':'7c5412fddc4ef3e56c859b83d237162e0fd260e7','scope':'test-owned Catalog selection/lifespan propagation and actual consumed unit-stub alias; production guards/protocol/authority unchanged','files':rows,'patch':'source.patch','patch_sha256':h(patch.encode()),'runtime':'UNRUN','canonical_index_refs_environment_written':False},indent=2)+'\n')
print('manifest',h((out/'manifest.json').read_bytes()),'patch',h(patch.encode()),'files',len(rows))
