"""File-only census of the exact v3p3 testcase CAS; no product imports or DB access."""
from pathlib import Path
import collections
import hashlib
import json

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
CASE = ROOT / "policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1/v3p3"
CAS = CASE / "basetemp/test_real_b_receiver_dispatch_0/cas"
reads = []

def read(path):
    try:
        data = path.read_bytes()
    except OSError as error:
        reads.append({"path": str(path), "status": "failed", "error_type": type(error).__name__})
        raise
    reads.append({"path": str(path), "status": "success", "bytes": len(data),
                  "sha256": hashlib.sha256(data).hexdigest()})
    return data

report = {"schema": "e02.v3p3-file-route-census.v1", "status": "ERROR",
          "scope": str(CAS), "runtime_type_admission": "UNRUN",
          "unresolved_by_construction": ["database contents", "live owner execution",
              "strict DTO reconstruction", "other CAS trees", "future candidate outcome"]}
try:
    paths = sorted(CAS.rglob("*.manifest.json"))
    kinds = collections.Counter()
    compiled = {}
    all_ids = set()
    for path in paths:
        manifest = json.loads(read(path))
        all_ids.add(manifest["artifact_id"])
        kinds[manifest["kind"]] += 1
        if manifest["kind"] == "runtime.compiled_recursive_generation_cycle":
            compiled[manifest["artifact_id"]] = path
    rows = []
    total_nodes = total_leaves = 0
    for identity, manifest_path in compiled.items():
        blob = manifest_path.parent / (identity.removeprefix("sha256:") + ".blob")
        data = read(blob)
        assert hashlib.sha256(data).hexdigest() == identity.removeprefix("sha256:")
        payload = json.loads(data)
        nodes = payload["recursive_run"]["nodes"]
        leaves = [node for node in nodes if not node["child_refs"]]
        total_nodes += len(nodes)
        total_leaves += len(leaves)
        for leaf in leaves:
            if leaf["cycle_run"] is None:
                continue
            for cycle in leaf["cycle_run"]["cycles"]:
                assert "acquisition_routing_report" in cycle
                assert "acquisition_cost_basis_record" in cycle
                rows.append({"compiled_artifact_id": identity, "node_ref": leaf["node_ref"],
                    "cycle_index": cycle["cycle_index"],
                    "report_present": cycle["acquisition_routing_report"] is not None,
                    "cost_present": cycle["acquisition_cost_basis_record"] is not None,
                    "value_status": cycle["value_port"]["status"],
                    "value_reason": cycle["value_port"]["reason"],
                    "value_requirement": cycle["value_port"]["acquisition_requirement"]})
    costed = [row for row in rows if row["report_present"] and row["cost_present"]]
    report.update(status="FILE_OBSERVATION_ONLY", manifest_file_denominator=len(paths),
        unique_artifact_denominator=len(all_ids), manifest_kind_counts=dict(kinds),
        compiled_artifact_denominator=len(compiled), nodes=total_nodes, leaves=total_leaves,
        complete_leaf_cycles=rows, costed_routes=costed, costed_route_count=len(costed))
except Exception as error:
    report["error_type"] = type(error).__name__
finally:
    report["actual_reads"] = reads
    report["selection"] = "all *.manifest.json under the exact testcase CAS; compiled blobs only"
    report["exclusions"] = ["no database queries", "no product imports", "no tests/native run"]
    print(json.dumps(report, indent=2))
if report["status"] == "ERROR":
    raise SystemExit(1)
