"""Bounded stdlib-only inventory of the existing local WMR CAS metadata."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


CAS = Path("policy-engine/.tmp/gy-s-composed-wmr-cas")
L6_ROOT = Path(
    "policy-engine/production_data/ukraine_agent_simulation_baseline_20260410/"
    "production_bundle/bundles"
)
L6_MANIFEST = Path(
    "policy-engine/production_data/ukraine_agent_simulation_baseline_20260410/"
    "FINAL_ARTIFACTS_MANIFEST.json"
)
L6_FILES = {
    "intervention_knob_dictionary": (
        "intervention_bundle_v1/intervention_knob_dictionary.json",
        "l6_intervention_knob_dictionary",
    ),
    "lex_intervention_map": (
        "intervention_bundle_v1/lex_intervention_map.json",
        "l6_lex_intervention_map",
    ),
    "observation_to_contract_manifest": (
        "method_contract_bundle_v1/observation_to_contract_manifest.json",
        "l6_observation_contract_routes",
    ),
    "policy_scenario_templates": (
        "intervention_bundle_v1/policy_scenario_templates.json",
        "l6_policy_scenario_templates",
    ),
}
TARGET_ARTIFACT = (
    "e96949676a6f0c9278cc8a82bf083d34f982e90b1c071097e953b2ffbb585bb5"
)
TARGET_LOGICAL = (
    "sha256:61fb1eeb738aac25a6dd71e307cfc6719046bdcd0bc09ddb44ce9b5e9b1d92e6"
)


def main() -> None:
    all_manifests = list(CAS.glob("artifacts/sha256/**/*.manifest.json"))
    base_manifests = [path for path in all_manifests if ".view." not in path.name]
    unique: dict[str, dict[str, object]] = {}
    wmr_manifest_count = 0
    bad_or_missing_blobs: list[dict[str, str]] = []
    for path in all_manifests:
        try:
            manifest = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if manifest.get("kind") != "runtime.quality.world_model_record":
            continue
        wmr_manifest_count += 1
        artifact_ref = manifest.get("artifact_id")
        if not isinstance(artifact_ref, str) or not artifact_ref.startswith("sha256:"):
            continue
        artifact_hex = artifact_ref.removeprefix("sha256:")
        blob = path.parent / f"{artifact_hex}.blob"
        try:
            payload_bytes = blob.read_bytes()
        except OSError:
            bad_or_missing_blobs.append({"artifact_ref": artifact_ref, "problem": "blob_missing"})
            continue
        if hashlib.sha256(payload_bytes).hexdigest() != artifact_hex:
            bad_or_missing_blobs.append(
                {"artifact_ref": artifact_ref, "problem": "blob_sha256_mismatch"}
            )
            continue
        try:
            payload = json.loads(payload_bytes)
        except json.JSONDecodeError:
            bad_or_missing_blobs.append(
                {"artifact_ref": artifact_ref, "problem": "blob_not_json"}
            )
            continue
        logical_hash = payload.get("content_hash")
        unique[artifact_hex] = {
            "artifact_ref": artifact_ref,
            "logical_content_hash": logical_hash,
            "schema": manifest.get("schema", {}).get("version"),
            "created_at": manifest.get("created_at"),
        }

    unique_logicals = sorted(
        {str(row["logical_content_hash"]) for row in unique.values()}
    )
    manifest_payload = json.loads(L6_MANIFEST.read_text(encoding="utf-8"))
    declared_assets = {
        row["path"]: row
        for row in manifest_payload.get("files", [])
        if isinstance(row, dict) and isinstance(row.get("path"), str)
    }
    l6_files: dict[str, dict[str, object]] = {}
    for name, (relative_path, family_id) in L6_FILES.items():
        path = L6_ROOT / relative_path
        raw = path.read_bytes()
        payload = json.loads(raw)
        normalized = json.dumps(
            payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")
        ).encode("utf-8")
        declaration = declared_assets.get(f"production_bundle/bundles/{relative_path}", {})
        l6_files[name] = {
            "path": str(path),
            "raw_bytes": len(raw),
            "raw_sha256": hashlib.sha256(raw).hexdigest(),
            "stdlib_normalized_json_sha256": hashlib.sha256(normalized).hexdigest(),
            "manifest_declared_bytes": declaration.get("size_bytes"),
            "manifest_declared_raw_sha256": declaration.get("sha256"),
            "manifest_size_matches": declaration.get("size_bytes") == len(raw),
            "related_wmr_registry_family_id": family_id,
        }

    representatives = []
    for logical in unique_logicals:
        row = min(
            (row for row in unique.values() if row["logical_content_hash"] == logical),
            key=lambda row: str(row["artifact_ref"]),
        )
        artifact_hex = str(row["artifact_ref"]).removeprefix("sha256:")
        artifact_path = CAS / "artifacts" / "sha256" / artifact_hex[:2] / artifact_hex[2:4]
        payload = json.loads((artifact_path / f"{artifact_hex}.blob").read_bytes())
        row["l6_registry_entry_hashes"] = {
            entry.get("family_id"): entry.get("entry_content_hash")
            for entry in payload.get("substrate_registry_ref", {}).get("resolved_entries", [])
            if entry.get("layer") == "L6"
        }
        representatives.append(row)
    result = {
        "scope": str(CAS),
        "enumeration": {
            "all_manifest_json_files": len(all_manifests),
            "base_manifest_json_files_excluding_view_manifests": len(base_manifests),
            "world_model_record_manifest_occurrences": wmr_manifest_count,
            "unique_verified_world_model_artifact_ids": len(unique),
            "unique_logical_content_hashes": unique_logicals,
        },
        "requested_historical_pin": {
            "artifact_ref": f"sha256:{TARGET_ARTIFACT}",
            "artifact_ref_present": TARGET_ARTIFACT in unique,
            "logical_content_hash": TARGET_LOGICAL,
            "logical_content_hash_present": any(
                row["logical_content_hash"] == TARGET_LOGICAL for row in unique.values()
            ),
        },
        "representatives_by_logical_hash": representatives,
        "current_l6_files": l6_files,
        "bad_or_missing_blobs": bad_or_missing_blobs,
    }
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
