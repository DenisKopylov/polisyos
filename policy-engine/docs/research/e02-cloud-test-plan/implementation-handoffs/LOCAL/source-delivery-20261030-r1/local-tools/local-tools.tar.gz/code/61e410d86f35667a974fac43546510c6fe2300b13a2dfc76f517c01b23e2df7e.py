from pathlib import Path
import ast, hashlib, json, subprocess
out=Path('LOCAL/raw/e02-execution-20261027/repairs/C06');paths=sorted(out.joinpath('policy-engine').rglob('*.py'))
for path in paths: ast.parse(path.read_bytes(), filename=str(path))
commands={'ruff-check':['policy-engine/.venv/bin/python','-m','ruff','check','--no-cache','--config','policy-engine/pyproject.toml',*[str(p) for p in paths]],'ruff-format-check':['policy-engine/.venv/bin/python','-m','ruff','format','--check','--config','policy-engine/pyproject.toml',*[str(p) for p in paths]],'base-patch-check':['git','apply','--check',str(out/'base-to-proposal.patch')]}
result={'ast':{'state':'PASS','python_paths':len(paths),'note':'parsing only; no product import/test'},'commands':{}}
for label,cmd in commands.items():
 p=subprocess.run(cmd,capture_output=True)
 record={'argv':cmd,'exit_code':p.returncode}
 for name,data in [('stdout',p.stdout),('stderr',p.stderr)]:
  target=out/f'{label}.{name}.txt';target.write_bytes(data);record[name]={'path':str(target),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
 result['commands'][label]=record
(out/'static-checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v['exit_code'] for k,v in result['commands'].items()}))
