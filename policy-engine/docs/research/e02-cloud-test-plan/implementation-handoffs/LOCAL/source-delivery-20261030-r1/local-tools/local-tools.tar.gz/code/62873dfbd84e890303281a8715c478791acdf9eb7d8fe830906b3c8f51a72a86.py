"""Observe only the actual C50 child selection and loaded numerical libraries."""
from __future__ import annotations
import ctypes
import hashlib
import importlib.metadata
import importlib.util
import json
import os
import subprocess
import sys
import sysconfig
from pathlib import Path
import pytest

_STATE={}

def _need(k):
 v=os.environ.get(k)
 if not v:raise pytest.UsageError('C50 child profile missing '+k)
 return v

def _sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def pytest_configure(config):
 root=Path(config.rootpath).resolve(strict=True);plugin=Path(__file__).resolve(strict=True)
 if root!=Path.cwd().resolve(strict=True):raise pytest.UsageError('C50 profile requires product cwd')
 if _sha(plugin)!=_need('C50_CHILD_PROFILE_SHA256'):raise pytest.UsageError('C50 profile plugin hash mismatch')
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
 tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip()
 if head!=_need('C50_SOURCE_HEAD') or tree!=_need('C50_SOURCE_TREE'):raise pytest.UsageError('C50 profile head/tree mismatch')
 output=Path(_need('C50_OUTPUT')).resolve(strict=True)
 if output!=Path(_need('POLISYOS_R4_INPUT_READSET_DIR')).parent.resolve(strict=True):raise pytest.UsageError('C50 profile output mismatch')
 _STATE.update(root=root,output=output,head=head,tree=tree)

@pytest.hookimpl(trylast=True)
def pytest_collection_finish(session):
 if [x.nodeid for x in session.items] != [_need('C50_EXACT_NODE')]:raise pytest.UsageError('C50 exact node mismatch')
 _STATE['node']=session.items[0].nodeid

def _python_runtime_image():
 try:
  api=ctypes.CDLL(None);count=api._dyld_image_count;count.argtypes=();count.restype=ctypes.c_uint32
  name=api._dyld_get_image_name;name.argtypes=(ctypes.c_uint32,);name.restype=ctypes.c_char_p
  expected=sysconfig.get_config_var('LDLIBRARY');n=int(count());images=[]
  for i in range(n):
   raw=name(i)
   if raw and Path(os.fsdecode(raw)).name==expected:
    path=Path(os.fsdecode(raw)).resolve(strict=True);images.append({'path':str(path),'sha256':_sha(path)})
  return {'status':'observed' if int(count())==n else 'unstable','expected_name':expected,'images':images}
 except Exception as exc:return {'status':'error','reason':f'{type(exc).__name__}: {exc}','images':[]}


def pytest_sessionfinish(session,exitstatus):
 if not _STATE:return
 binary=Path(sys.executable).resolve(strict=True);plugins=set()
 for name,plugin in session.config.pluginmanager.list_name_plugin():
  mod=getattr(plugin,'__name__',plugin.__class__.__module__)
  if name in {'c50_removal_plugin','c50_child_profile'} or mod in {'c50_removal_plugin','c50_child_profile'}:continue
  plugins.add(mod)
 versions={}
 for name in ('numpy','scipy','pytest','pydantic','pydantic_core','jax','jaxlib'):
  try:versions[name]=importlib.metadata.version(name)
  except importlib.metadata.PackageNotFoundError:versions[name]=None
 try:
  if importlib.util.find_spec('threadpoolctl') is None:blas={'status':'unavailable','libraries':[]}
  else:
   from threadpoolctl import threadpool_info
   libs=[]
   for x in threadpool_info():
    p=Path(x['filepath']).resolve(strict=True);libs.append({'path':str(p),'sha256':_sha(p),'metadata':x})
   blas={'status':'observed','libraries':sorted(libs,key=lambda x:x['path'])}
 except Exception as exc:blas={'status':'error','error':repr(exc),'libraries':[]}
 loaded={}
 for name,mod in sorted(sys.modules.copy().items()):
  if not name.startswith(('numpy','scipy','jax','jaxlib','pydantic','pydantic_core')):continue
  file=getattr(mod,'__file__',None)
  if file:
   path=Path(file)
   if path.is_file():
    resolved=path.resolve(strict=True);loaded[name]={'path':str(resolved),'sha256':_sha(resolved)}
 relevant={'OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS','NUMEXPR_NUM_THREADS','ARROW_NUM_THREADS','BLIS_NUM_THREADS','PYTHONHASHSEED'}
 flags={k:v for k,v in os.environ.items() if k in relevant or k.startswith(('JAX_','XLA_'))}
 record={'source_head':_STATE['head'],'source_tree':_STATE['tree'],'selected_node':_STATE.get('node'),'pytest_exitstatus':int(exitstatus),'python':sys.version,'executable_resolved':str(binary),'executable_sha256':_sha(binary),'python_runtime_image':_python_runtime_image(),'versions':versions,'pytest_plugin_modules':sorted(plugins),'numeric_env':dict(sorted(flags.items())),'loaded_numeric_and_pydantic_python_and_extension_files':loaded,'loaded_blas_libraries':blas,'limitation':'Observed sys.modules and threadpoolctl results are finite, not a complete dynamic-loader census.'}
 out=_STATE['output']/'c50-child-profile.json'
 if out.exists() or out.is_symlink():raise pytest.UsageError('C50 child profile output exists')
 out.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
