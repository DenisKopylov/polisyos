from __future__ import annotations

import ast
import difflib
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
OUT = ROOT / 'LOCAL/raw/e02-execution-20261027/repairs/V3-world-rule-quantity-r1'
BASE = '2130f07de1eb93316d22bf5f91adc05ded67fbd2'
TREE = 'd67b5b827eb0d0f7286603d2c214c3d68a98675a'
SRC = 'policy-engine/src/polisyos/runtime/quality/data_state_substrate.py'
HELPER = 'policy-engine/tests/_helpers/world_model_record.py'
TEST = 'policy-engine/tests/integration/core_runtime/test_acquisition_world_semantic_preparation.py'
PATHS = (SRC, HELPER, TEST)
sha = lambda x: hashlib.sha256(x).hexdigest()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == BASE
assert subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, text=True).strip() == TREE
before = {}
for path in PATHS:
    raw = (ROOT / path).read_bytes()
    assert raw == subprocess.check_output(['git', 'show', f'{BASE}:{path}'], cwd=ROOT)
    before[path] = raw.decode('utf-8')
after = dict(before)


def replace_one(path: str, original: str, replacement: str) -> None:
    assert after[path].count(original) == 1, (path, original)
    after[path] = after[path].replace(original, replacement, 1)

replace_one(SRC,
'''            data_values=data_values,
            state=current.materialized_state,
            data_preparation=data_preparation,
''',
'''            data_values=data_values,
            state=current.materialized_state,
            effective_rules=current.effective_rules,
            data_preparation=data_preparation,
''')
replace_one(SRC,
'''    data_values: dict[str, object],
    state: GlobalState,
    data_preparation: AcquiredObservationDataPreparation,
    binding_execution: dict[str, object],
''',
'''    data_values: dict[str, object],
    state: GlobalState,
    effective_rules: tuple[FoundryInputBindingRule, ...],
    data_preparation: AcquiredObservationDataPreparation,
    binding_execution: dict[str, object],
''')
replace_one(SRC,
'''        limitations=plan.limitations,
        rules=plan.rules,
        state=state,
''',
'''        limitations=plan.limitations,
        rules=effective_rules,
        state=state,
''')
replace_one(SRC,
'''    effective["rules"] = _effective_acquired_world_rules(
        plan.rules, data_preparation.foundry_binding_rule
    )
''',
'''    effective["rules"] = _effective_acquired_world_rules(
        effective_rules, data_preparation.foundry_binding_rule
    )
''')
replace_one(SRC,
'''            limitations=world.limitations,
            rules=tuple(bindings.rules),
            state=state,
''',
'''            limitations=world.limitations,
            rules=prepared.effective_rules,
            state=state,
''')
replace_one(SRC,
'''        effective["rules"] = _effective_acquired_world_rules(tuple(bindings.rules), acquired_rule)
''',
'''        effective["rules"] = _effective_acquired_world_rules(
            prepared.effective_rules, acquired_rule
        )
''')
replace_one(HELPER,
'''from polisyos.core.contracts.fabric import DataSnapshot
''',
'''from polisyos.core.contracts import FoundryInputBindingRule
from polisyos.core.contracts.fabric import DataSnapshot
''')
replace_one(HELPER,
'''    skg_ref_factory: Callable[[Path], SkgCausalPriorRef] | None = None,
):
''',
'''    skg_ref_factory: Callable[[Path], SkgCausalPriorRef] | None = None,
    foundry_binding_rules: list[FoundryInputBindingRule] | None = None,
):
''')
replace_one(HELPER,
'''        producer_ref="test.world_model_record_builder",
        required_substrate_families=("firm_fundamentals",),
''',
'''        producer_ref="test.world_model_record_builder",
        required_substrate_families=("firm_fundamentals",),
        foundry_binding_rules=foundry_binding_rules,
''')
replace_one(TEST,
'''from polisyos.core.artifacts import FileSystemCAS
from polisyos.foundry.data_plane import prepare_json_input_binding_values
''',
'''from polisyos.core.artifacts import FileSystemCAS
from polisyos.core.contracts import FoundryInputBindingRule
from polisyos.foundry.data_plane import load_input_bindings, prepare_json_input_binding_values
''')
replace_one(TEST,
'''    skg_ref_factory: Callable[[Path], SkgCausalPriorRef] = _empty_selected_skg,
):
''',
'''    skg_ref_factory: Callable[[Path], SkgCausalPriorRef] = _empty_selected_skg,
    foundry_binding_rules: list[FoundryInputBindingRule] | None = None,
):
''')
replace_one(TEST,
'''    store, base, _model, _registry = world_fixture._build_record(
        tmp_path / "base", skg_ref_factory=skg_ref_factory
    )
''',
'''    store, base, _model, _registry = world_fixture._build_record(
        tmp_path / "base",
        skg_ref_factory=skg_ref_factory,
        foundry_binding_rules=foundry_binding_rules,
    )
''')
anchor = '\n\ndef test_supplied_state_plan_cannot_self_attest_completeness(\n'
newtest = '''

def test_world_rules_use_executed_owner_order_even_for_overlapping_targets(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Rule IDs fix execution order, including two writes to the same state path."""
    first = FoundryInputBindingRule(
        binding_id="overlap.a-income",
        source_path="agents.income",
        target_slot_id="agents.income",
        notes=["first owner operation"],
    )
    last = FoundryInputBindingRule(
        binding_id="overlap.z-income",
        source_path="agents.reported_income",
        target_slot_id="agents.income",
        notes=["last owner operation"],
    )
    case, base, substrate, views, numerical = _world_case(
        tmp_path, monkeypatch, foundry_binding_rules=[last, first]
    )
    store = case.scenario.store
    expected_ids = (
        case.prepared.foundry_binding_rule.binding_id,
        first.binding_id,
        last.binding_id,
    )
    assert tuple(rule.binding_id for rule in numerical.effective_rules) == expected_ids
    assert numerical.applied_binding_ids == expected_ids
    assert numerical.materialized_state.agents.income.tolist() == pytest.approx([1000.0, 1600.0])

    prospective = owner.prepare_acquired_observation_world_semantic_values(
        store=store,
        base_world_model_record=base.record,
        data_preparation=case.prepared,
        prepared_state_values=numerical,
        registry_bundle_ref=views.registry_bundle_ref,
        substrate_registry=substrate,
    )
    assert prospective["status"] == "established", prospective
    assert prospective["predicate_provenance"] == "recomputed"
    expected_rules = tuple(
        rule.model_dump(
            mode="json", exclude={"notes"} if rule == case.prepared.foundry_binding_rule else set()
        )
        for rule in numerical.effective_rules
    )
    values = prospective["effective_values"]
    assert isinstance(values, dict)
    assert values["rules"] == expected_rules
    assert expected_rules[1]["notes"] == ["first owner operation"]
    assert expected_rules[2]["notes"] == ["last owner operation"]

    materialized = owner.materialize_acquired_observation_snapshot(
        store, **case.args, workspace_dir=case.workspace, prepared=case.prepared
    )
    substrate_ref = persist_substrate_registry(store, substrate)
    actual = owner.build_acquired_observation_candidate_world(
        store,
        base_world_model=base.record,
        substrate_registry=substrate,
        substrate_registry_artifact_ref=substrate_ref,
        materialization=materialized,
        workspace_dir=tmp_path / "world",
        transaction_time=case.args["transaction_time"],
    )
    fresh_store = FileSystemCAS(store.root)
    persisted_world = load_world_model_record(fresh_store, actual.world_model.record_ref)
    assert persisted_world == actual.world_model.record
    persisted_rules = load_input_bindings(
        fresh_store, world_model_artifact_views(persisted_world).input_bindings_ref
    ).rules
    assert tuple(persisted_rules) == numerical.effective_rules
    observed = owner.read_acquired_observation_world_semantic_values(
        store=fresh_store,
        world_model_record=persisted_world,
        registry_bundle_ref=views.registry_bundle_ref,
    )
    assert observed["status"] == "established", observed
    assert observed["effective_values"] == values

    # Simulate a different incoming list encoding while retaining every real
    # typed rule and CAS source. Foundry still computes the same operations.
    import polisyos.foundry.data_plane as foundry_data_plane

    def reverse_reader(reader_store, ref):
        typed = load_input_bindings(reader_store, ref)
        return typed.model_copy(update={"rules": list(reversed(typed.rules))})

    with monkeypatch.context() as reordered:
        reordered.setattr(foundry_data_plane, "load_input_bindings", reverse_reader)
        same_operations = owner.read_acquired_observation_world_semantic_values(
            store=fresh_store,
            world_model_record=persisted_world,
            registry_bundle_ref=views.registry_bundle_ref,
        )
        assert same_operations == observed

    # Supplied order is not an execution order; the actual Foundry owner
    # reconstructs the same complete ordered operations from a reversed input.
    reversed_input = prepare_json_input_binding_values(
        store,
        payload_json=case.prepared.payload_json,
        registry_bundle_ref=views.registry_bundle_ref,
        rules=list(reversed(numerical.effective_rules)),
    )
    assert reversed_input.effective_rules == numerical.effective_rules
    assert reversed_input.applied_binding_ids == numerical.applied_binding_ids
    assert reversed_input.materialized_state.agents.income.tolist() == pytest.approx(
        [1000.0, 1600.0]
    )

    # Keep the same two IDs and source values, but swap which source owns each
    # ID. The owner's last write changes, so ID-to-source/order is substantive.
    swapped_ids = {first.binding_id: last.binding_id, last.binding_id: first.binding_id}
    swapped_rules = [
        rule.model_copy(update={"binding_id": swapped_ids[rule.binding_id]})
        if rule.binding_id in swapped_ids
        else rule
        for rule in numerical.effective_rules
    ]
    swapped = prepare_json_input_binding_values(
        store,
        payload_json=case.prepared.payload_json,
        registry_bundle_ref=views.registry_bundle_ref,
        rules=swapped_rules,
    )
    assert swapped.applied_binding_ids == numerical.applied_binding_ids
    assert swapped.materialized_state.agents.income.tolist() == pytest.approx([1200.0, 1800.0])
    assert swapped.effective_rules != numerical.effective_rules

    # Remove only the owner-rule handoff while leaving the real Foundry
    # preparation, emitted record, numerical state and all rule fields intact.
    # The old source-input order must no longer match the actual consumer.
    actual_constructor = owner._prepare_acquired_world_semantic_result

    def without_owner_rule_order(**kwargs):
        kwargs["effective_rules"] = kwargs["plan"].rules
        return actual_constructor(**kwargs)

    with monkeypatch.context() as removed:
        removed.setattr(owner, "_prepare_acquired_world_semantic_result", without_owner_rule_order)
        stale = owner.prepare_acquired_observation_world_semantic_values(
            store=store,
            base_world_model_record=base.record,
            data_preparation=case.prepared,
            prepared_state_values=numerical,
            registry_bundle_ref=views.registry_bundle_ref,
            substrate_registry=substrate,
        )
        assert stale["status"] == "established", stale
        stale_values = stale["effective_values"]
        assert isinstance(stale_values, dict)
        assert stale_values["rules"] != values["rules"]
        assert stale_values["state"] == values["state"]
    restored = owner.prepare_acquired_observation_world_semantic_values(
        store=store,
        base_world_model_record=base.record,
        data_preparation=case.prepared,
        prepared_state_values=numerical,
        registry_bundle_ref=views.registry_bundle_ref,
        substrate_registry=substrate,
    )
    assert restored == prospective
'''
replace_one(TEST, anchor, newtest + anchor)

for path in PATHS:
    ast.parse(after[path], filename=path)
preimages = {'base': BASE, 'tree': TREE, 'files': {}}
postimages = {}
patch = []
for path in PATHS:
    data = after[path].encode()
    target = OUT / 'postimage' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    preimages['files'][path] = {'sha256': sha(before[path].encode()), 'bytes': len(before[path].encode())}
    postimages[path] = {'sha256': sha(data), 'bytes': len(data)}
    patch.extend(difflib.unified_diff(before[path].splitlines(keepends=True), after[path].splitlines(keepends=True), fromfile='a/' + path, tofile='b/' + path))
(OUT / 'preimages.json').write_text(json.dumps(preimages, indent=2, sort_keys=True) + '\n')
(OUT / 'proposal.patch').write_text(''.join(patch), encoding='utf-8')
manifest = {
    'status': 'raw_proposal_unreviewed_unexecuted',
    'base': BASE,
    'tree': TREE,
    'postimages': postimages,
    'preimages_sha256': sha((OUT / 'preimages.json').read_bytes()),
    'proposal_patch_sha256': sha((OUT / 'proposal.patch').read_bytes()),
    'retained_rule_analysis_sha256': sha((OUT / 'retained-rule-analysis.json').read_bytes()),
    'test_execution': 'not performed',
    'product_imports': 'not performed',
}
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
print('Three full postimages, base preimages, patch and manifest prepared; AST checks passed.')
