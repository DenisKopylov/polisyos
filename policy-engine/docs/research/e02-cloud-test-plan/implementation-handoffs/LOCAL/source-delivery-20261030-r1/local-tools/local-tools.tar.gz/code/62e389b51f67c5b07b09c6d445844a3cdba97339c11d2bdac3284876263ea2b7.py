"""Standard-library controls: no product imports or product runtime."""
from __future__ import annotations

import gzip
import json
import sys
import threading
from pathlib import Path

from v3_exception_witness import ExceptionWitness, WitnessError, MAX_EVENTS

HERE = Path(__file__).resolve().parent
OUT = HERE / "smoke-results-r7"
OUT.mkdir(exist_ok=False)


class BadStr(ValueError):
    calls = 0
    def __str__(self) -> str:
        type(self).calls += 1
        raise RuntimeError("custom formatting must not run")


def raising_child() -> None:
    try:
        raise KeyError("inner cause")
    except KeyError as cause:
        raise ValueError("nested handler detail") from cause


def target(mode: str) -> str:
    try:
        if mode == "nested":
            raising_child()
        if mode == "badstr":
            raise BadStr("custom primitive argument")
        if mode == "aggregate":
            raise ValueError("y" * 12000)
        if mode == "long":
            raise ValueError("x" * 70000)
        raise ValueError("specific handler detail")
    except (ValueError, RuntimeError):
        return "original-return"


def unrelated() -> None:
    try:
        raise ValueError("must not be captured")
    except ValueError:
        return


def unhandled(token: BaseException) -> None:
    raise token


monitor = sys.monitoring
initial = {i: monitor.get_tool(i) for i in range(6)}
assert all(v is None for v in initial.values())
profile, trace = sys.getprofile(), sys.gettrace()
witness = ExceptionWitness(target.__code__, OUT / "events.json.gz")
witness.start()
assert witness.tool_id in (5, 2, 1, 0)
assert monitor.get_tool(3) is None and monitor.get_tool(4) is None
monitor.use_tool_id(3, "simulated-test-monitor")
try:
    assert target("value") == "original-return"
    unrelated()
    assert target("nested") == "original-return"
    assert target("badstr") == "original-return"
    assert target("long") == "original-return"
finally:
    monitor.free_tool_id(3)
report = witness.finish()
assert report["target_entries"] == 4 and report["events_seen"] == 4
assert report["events_omitted"] == 0 and report["target_active_at_cleanup"] == 0
assert report["events"][0]["chain"][0]["message"] == {"available": True, "text": "specific handler detail"}
assert report["events"][1]["chain"][0]["message"] == {"available": True, "text": "nested handler detail"}
assert report["events"][1]["chain"][1]["type"] == "builtins.KeyError"
assert report["events"][2]["chain"][0]["message"]["reason"] == "custom_exception_text_not_invoked"
assert report["events"][2]["chain"][0]["args"][0]["text"] == "custom primitive argument"
assert BadStr.calls == 0
assert report["events"][3]["chain"][0]["message"]["reason"] == "message_args_unavailable"
assert all(item["chain"][0]["traceback"]["frames"] for item in report["events"])
assert report["callback_errors"] == report["cleanup_errors"] == []
assert report["profile_unchanged"] and report["trace_unchanged"]
assert json.loads(gzip.decompress((OUT / "events.json.gz").read_bytes())) == report
assert {i: monitor.get_tool(i) for i in range(6)} == initial

original = RuntimeError("original exception instance")
witness = ExceptionWitness(unhandled.__code__, OUT / "unhandled.json.gz")
witness.start()
try:
    unhandled(original)
except RuntimeError as observed:
    assert observed is original
else:
    raise AssertionError("original exception was masked")
report = witness.finish()
assert report["events"] == [] and report["target_active_at_cleanup"] == 0
assert report["cleanup_errors"] == []

monitor.use_tool_id(5, "independent-smoke-owner")
try:
    w = ExceptionWitness(target.__code__, OUT / "occupied-five.json.gz")
    w.start()
    assert w.tool_id in (2, 1, 0)
    assert target("value") == "original-return"
    w.finish()
    assert monitor.get_tool(5) == "independent-smoke-owner"
finally:
    monitor.free_tool_id(5)

for busy in (3, 4):
    monitor.use_tool_id(busy, "independent-test-owner")
try:
    try:
        ExceptionWitness(target.__code__, OUT / "both-busy.json.gz").start()
    except WitnessError as exc:
        assert str(exc) == "v3_witness_no_test_monitor_slot"
    else:
        raise AssertionError("occupied test monitor slots were accepted")
    assert all(monitor.get_tool(i) == "independent-test-owner" for i in (3, 4))
finally:
    for busy in (3, 4):
        monitor.free_tool_id(busy)

for busy in (5, 2, 1, 0):
    monitor.use_tool_id(busy, "independent-diagnostic-owner")
try:
    try:
        ExceptionWitness(target.__code__, OUT / "all-busy.json.gz").start()
    except WitnessError as exc:
        assert str(exc) == "v3_witness_no_available_slot"
    else:
        raise AssertionError("occupied diagnostic slots were accepted")
    assert all(monitor.get_tool(i) == "independent-diagnostic-owner" for i in (5, 2, 1, 0))
finally:
    for busy in (5, 2, 1, 0):
        monitor.free_tool_id(busy)

witness = ExceptionWitness(target.__code__, OUT / "overflow.json.gz")
witness.start()
for _ in range(MAX_EVENTS + 2):
    assert target("value") == "original-return"
report = witness.finish()
assert report["events_seen"] == MAX_EVENTS + 2 and report["events_omitted"] == 2
assert len(report["events"]) == MAX_EVENTS and report["cleanup_errors"] == []

witness = ExceptionWitness(target.__code__, OUT / "aggregate.json.gz")
witness.start()
for _ in range(MAX_EVENTS):
    # Each accepted short-ish item participates in one aggregate budget.
    try:
        pass
    finally:
        assert target("aggregate") == "original-return"
report = witness.finish()
assert report["text_bytes_used"] <= report["limits"]["aggregate_text_bytes"]
assert report["unavailable_text_count"] > 0
assert report["events_seen"] == MAX_EVENTS and report["events_omitted"] == 0

barrier = threading.Barrier(2)
def concurrent_target() -> str:
    try:
        barrier.wait(timeout=5)
        raise ValueError("concurrent")
    except ValueError:
        return "original-return"

witness = ExceptionWitness(concurrent_target.__code__, OUT / "concurrent.json.gz")
witness.start()
results = []
threads = [threading.Thread(target=lambda: results.append(concurrent_target())) for _ in range(2)]
for thread in threads:
    thread.start()
for thread in threads:
    thread.join(timeout=10)
assert all(not thread.is_alive() for thread in threads)
assert results == ["original-return", "original-return"]
report = witness.finish()
assert report["target_entries"] == report["events_seen"] == 2
assert report["target_active_at_cleanup"] == 0 and not report["callback_errors"] and not report["cleanup_errors"]

collision = OUT / "collision.json.gz"
collision.write_bytes(b"existing-content")
witness = ExceptionWitness(target.__code__, collision)
witness.start()
assert target("value") == "original-return"
report = witness.finish()
assert report["write_error"] == "FileExistsError"
assert collision.read_bytes() == b"existing-content"
assert {i: monitor.get_tool(i) for i in range(6)} == initial
assert sys.getprofile() is profile and sys.gettrace() is trace
print("PASS: exact-code filtering; nested cause; bounded inputs/events; no custom __str__; original return and exception identity; real slot ownership; overlapping threads; exclusive output; monitor/profile/trace cleanup")
