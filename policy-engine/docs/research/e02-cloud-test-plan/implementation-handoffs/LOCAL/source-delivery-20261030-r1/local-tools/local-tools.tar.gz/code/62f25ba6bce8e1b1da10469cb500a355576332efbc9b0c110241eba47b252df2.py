"""Finite Config-admission controls rooted in actual isolated pytest smoke facts."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import sys
import types
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--plugin", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
if os.path.lexists(args.output):
    raise RuntimeError("output already exists")
HERE = Path(__file__).resolve().parent
smoke = HERE / "config-smoke-v1/results.json"
actual = json.loads(smoke.read_text())
fake = types.ModuleType("pytest")
fake.hookimpl = lambda **_kwargs: lambda fn: fn
sys.modules["pytest"] = fake
spec = importlib.util.spec_from_file_location("q2_profile_fake", args.plugin)
if spec is None or spec.loader is None:
    raise RuntimeError("plugin loader missing")
guard = importlib.util.module_from_spec(spec)
spec.loader.exec_module(guard)


class Config:
    def __init__(self, facts: dict[str, object], *, addopts: list[str] | None = None) -> None:
        self.facts = facts
        self.known_args_namespace = types.SimpleNamespace(disable_plugin_autoload=False)
        self.disabled_final = False
        self.addopts = (
            addopts if addopts is not None else ["--import-mode=importlib", "--strict-markers"]
        )

    def getoption(self, name: str, default: object = None) -> object:
        return {
            "importmode": self.facts.get("importmode_option"),
            "strict_markers": self.facts.get("strict_markers_option"),
            "strict": self.facts.get("strict_option"),
            "strict_config": None,
            "disable_plugin_autoload": self.disabled_final,
        }.get(name, default)

    def getini(self, name: str) -> object:
        return {
            "strict_markers": self.facts.get("strict_markers_ini"),
            "strict": self.facts.get("strict_ini"),
            "strict_config": None,
            "addopts": self.addopts,
        }[name]


facts_by_case = {entry["case"]: entry["observed"]["E02_CONFIG_FACTS"] for entry in actual["cases"]}
behavior_by_case = {
    entry["case"]: entry["observed"]["E02_MARKER_BEHAVIOR"] for entry in actual["cases"]
}
results: dict[str, dict[str, object]] = {}
old = os.environ.pop("PYTEST_DISABLE_PLUGIN_AUTOLOAD", None)


def record(name: str, action: object, predicate: object) -> None:
    try:
        value = action()
        passed = bool(predicate(value))
        results[name] = {"pass": passed, "outcome": "returned", "value": value}
    except Exception as exc:
        results[name] = {"pass": False, "outcome": type(exc).__name__, "message": str(exc)}


def refusal(config: Config) -> bool:
    try:
        guard._pytest_profile(config)
    except RuntimeError:
        return True
    return False


try:
    prod = Config(facts_by_case["product-addopts"])
    explicit = Config(facts_by_case["product-explicit-cli"])
    scratch = Config(facts_by_case["scratch-negative"], addopts=["--import-mode=importlib"])
    ini_strict = Config(facts_by_case["scratch-ini-strict"], addopts=["--import-mode=importlib"])
    record(
        "product_actual_flag_is_present_but_not_enforced",
        lambda: guard._pytest_profile(prod),
        lambda v: v["strict_markers_option"] is True
        and v["effective_marker_strict"] is False
        and behavior_by_case["product-addopts"]["outcome"] == "returned",
    )
    record(
        "explicit_cli_effectively_strict",
        lambda: guard._pytest_profile(explicit),
        lambda v: v["strict_markers_option"] is True
        and v["effective_marker_strict"] is True
        and behavior_by_case["product-explicit-cli"]["is_pytest_fail"] is True,
    )
    record("negative_profile_refused", lambda: refusal(scratch), lambda v: v is True)
    record(
        "ini_only_profile_not_same_as_expected_flag",
        lambda: refusal(ini_strict),
        lambda v: v is True,
    )
    wrong_mode = Config({**facts_by_case["product-addopts"], "importmode_option": "prepend"})
    record("wrong_import_mode_refused", lambda: refusal(wrong_mode), lambda v: v is True)
    cli_disabled = Config(facts_by_case["product-addopts"])
    cli_disabled.known_args_namespace.disable_plugin_autoload = True
    record("startup_cli_autoload_off_refused", lambda: refusal(cli_disabled), lambda v: v is True)
    final_disabled = Config(facts_by_case["product-addopts"])
    final_disabled.disabled_final = True
    record("final_cli_autoload_off_refused", lambda: refusal(final_disabled), lambda v: v is True)
    os.environ["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
    record("environment_autoload_off_refused", lambda: refusal(prod), lambda v: v is True)
    os.environ.pop("PYTEST_DISABLE_PLUGIN_AUTOLOAD", None)
    marker_override = Config(
        {**facts_by_case["product-addopts"], "strict_markers_ini": False, "strict_ini": True}
    )
    record(
        "explicit_false_precedes_global_strict",
        lambda: guard._pytest_profile(marker_override),
        lambda v: v["effective_marker_strict"] is False,
    )
    missing_flag = Config(facts_by_case["product-addopts"], addopts=["--import-mode=importlib"])
    record("unbound_config_addopts_refused", lambda: refusal(missing_flag), lambda v: v is True)
finally:
    if old is not None:
        os.environ["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = old
    else:
        os.environ.pop("PYTEST_DISABLE_PLUGIN_AUTOLOAD", None)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


report = {
    "scope": (
        "stdlib fake Config parameterized by four actual pytest smoke results; no product import"
    ),
    "actual_smoke_sha256": sha(smoke),
    "plugin_sha256": sha(args.plugin),
    "control_sha256": sha(Path(__file__)),
    "checks": results,
    "passed": sum(bool(value["pass"]) for value in results.values()),
    "total": len(results),
    "runtime": "UNRUN",
}
with args.output.open("x", encoding="utf-8") as stream:
    json.dump(report, stream, indent=2, sort_keys=True)
    stream.write("\n")
sys.stdout.write(json.dumps(report, sort_keys=True) + "\n")
raise SystemExit(0 if report["passed"] == report["total"] else 1)
