"""Unexecuted in-process falsifiers for the C41 candidate; never write source files."""

from __future__ import annotations

import ast
import hashlib
import inspect
import os
import textwrap
from typing import Any


def _mutate_function(function: Any, *, mutant: str, namespace: dict[str, Any]) -> Any:
    source = textwrap.dedent(inspect.getsource(function))
    tree = ast.parse(source)
    changes = 0

    class Mutator(ast.NodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.AST:
            nonlocal changes
            if (
                mutant == "child_selection_rebind"
                and isinstance(node.func, ast.Attribute)
                and node.func.attr == "_rebind_child_selection_for_problem"
            ):
                changes += 1
                return ast.copy_location(
                    ast.Attribute(
                        value=ast.Name(id="binding", ctx=ast.Load()),
                        attr="selection",
                        ctx=ast.Load(),
                    ),
                    node,
                )
            if (
                mutant == "child_source_run_identity"
                and isinstance(node.func, ast.Name)
                and node.func.id == "_generation_source_run_id"
            ):
                changes += 1
                return ast.copy_location(
                    ast.Attribute(
                        value=ast.Name(id="family", ctx=ast.Load()),
                        attr="source_run_id",
                        ctx=ast.Load(),
                    ),
                    node,
                )
            return self.generic_visit(node)

        def visit_Expr(self, node: ast.Expr) -> ast.AST:
            nonlocal changes
            if (
                mutant == "physical_binding"
                and isinstance(node.value, ast.Call)
                and isinstance(node.value.func, ast.Attribute)
                and node.value.func.attr == "_validate_selected_trajectories"
            ):
                changes += 1
                return ast.copy_location(ast.Pass(), node)
            return self.generic_visit(node)

        def visit_For(self, node: ast.For) -> ast.AST:
            nonlocal changes
            if (
                mutant == "baseline_effect_binding"
                and isinstance(node.target, ast.Name)
                and node.target.id == "trajectory"
                and isinstance(node.iter, ast.Attribute)
                and isinstance(node.iter.value, ast.Name)
                and node.iter.value.id == "result"
                and node.iter.attr == "trajectories"
            ):
                changes += 1
                return ast.copy_location(ast.Pass(), node)
            return self.generic_visit(node)

        def visit_If(self, node: ast.If) -> ast.AST:
            nonlocal changes
            if (
                mutant == "input_cycle_join"
                and any(
                    isinstance(child, ast.Attribute)
                    and isinstance(child.value, ast.Name)
                    and child.value.id == "expected"
                    and child.attr == "profile"
                    for child in ast.walk(node.test)
                )
                and any(
                    isinstance(child, ast.Attribute)
                    and isinstance(child.value, ast.Name)
                    and child.value.id == "input_record"
                    and child.attr == "profile"
                    for child in ast.walk(node.test)
                )
            ):
                changes += 1
                return ast.copy_location(ast.Pass(), node)
            if mutant == "execution_cycle_join" and any(
                isinstance(child, ast.Attribute)
                and isinstance(child.value, ast.Name)
                and child.value.id == "record"
                and child.attr == "result_ref"
                for child in ast.walk(node.test)
            ):
                changes += 1
                return ast.copy_location(ast.Pass(), node)
            return self.generic_visit(node)

        def visit_Assign(self, node: ast.Assign) -> ast.AST:
            nonlocal changes
            if (
                mutant in {"seed_identity", "plan_identity", "evidence_identity"}
                and len(node.targets) == 1
                and isinstance(node.targets[0], ast.Name)
                and node.targets[0].id == "payload"
                and isinstance(node.value, ast.Dict)
            ):
                removed = {
                    "seed_identity": {"seed", "replication_seeds"},
                    "plan_identity": {"plan"},
                    "evidence_identity": {"evidence_state"},
                }[mutant]
                pairs = [
                    (key, value)
                    for key, value in zip(node.value.keys, node.value.values, strict=True)
                    if not (isinstance(key, ast.Constant) and key.value in removed)
                ]
                changes += len(node.value.keys) - len(pairs)
                node.value.keys = [key for key, _ in pairs]
                node.value.values = [value for _, value in pairs]
            return self.generic_visit(node)

    tree = Mutator().visit(tree)
    expected = 2 if mutant == "seed_identity" else 1
    if changes != expected:
        raise RuntimeError(f"mutant selector matched {changes}, expected {expected}: {mutant}")
    ast.fix_missing_locations(tree)
    mutated_bytes = ast.dump(tree, include_attributes=False).encode()
    print(
        "C41_MUTANT",
        mutant,
        "source_sha256=" + hashlib.sha256(source.encode()).hexdigest(),
        "mutant_ast_sha256=" + hashlib.sha256(mutated_bytes).hexdigest(),
        "edits=" + str(changes),
        flush=True,
    )
    local: dict[str, Any] = {}
    exec(compile(tree, f"<c41-mutant:{mutant}>", "exec"), namespace, local)  # noqa: S102
    return local[function.__name__]


def pytest_configure(config: Any) -> None:
    """Install one exact in-memory mutant before the unchanged witness is collected."""
    del config
    mutant = os.environ.get("C41_MUTATION")
    if mutant is None:
        return
    from polisyos.runtime.quality import joint_simulation_horizon as horizon

    if mutant in {"child_source_run_identity", "child_selection_rebind"}:
        from polisyos.runtime.http.routes import runs

        runs._generic_cycle_simulation_projection = _mutate_function(
            runs._generic_cycle_simulation_projection, mutant=mutant, namespace=vars(runs)
        )
    elif mutant in {"execution_cycle_join", "input_cycle_join"}:
        from polisyos.runtime.quality import generic_simulation_admission as admission

        cls = admission.GenericCycleSimulationAdmissionOwner
        cls.resolve_n5_execution_join = _mutate_function(
            cls.resolve_n5_execution_join, mutant=mutant, namespace=vars(admission)
        )
    elif mutant == "parent_n8_consumer":
        from polisyos.runtime.quality import generation_cycle

        original = generation_cycle._consume_parent_joint_candidate_n8

        def removed_n8_consumer(**kwargs: Any) -> Any:
            del kwargs
            raise generation_cycle.GenerationCycleError("c41_removed_parent_n8_consumer")

        print(
            "C41_MUTANT parent_n8_consumer source_sha256="
            + hashlib.sha256(inspect.getsource(original).encode()).hexdigest()
            + " wrapper_sha256="
            + hashlib.sha256(inspect.getsource(removed_n8_consumer).encode()).hexdigest(),
            flush=True,
        )
        generation_cycle._consume_parent_joint_candidate_n8 = removed_n8_consumer
    elif mutant in {"physical_binding", "baseline_effect_binding"}:
        cls = horizon.JointSimulationHorizonController
        cls.validate_selected_result = _mutate_function(
            cls.validate_selected_result, mutant=mutant, namespace=vars(horizon)
        )
    elif mutant in {"seed_identity", "plan_identity", "evidence_identity"}:
        horizon._physical_run_ref = _mutate_function(
            horizon._physical_run_ref, mutant=mutant, namespace=vars(horizon)
        )
    elif mutant == "missingness":
        original = horizon._ncm_outcomes

        def substitute_zero(output: object, selected: Any, plan: Any) -> dict[str, float]:
            try:
                return original(output, selected, plan)
            except horizon.JointSimulationControllerError:
                return {str(outcome): 0.0 for outcome in selected}

        horizon._ncm_outcomes = substitute_zero
        print("C41_MUTANT missingness wrapper-active", flush=True)
    elif mutant == "higher_order":
        original = horizon._numeric_interaction_classification

        def pairwise_only(**kwargs: Any) -> Any:
            kwargs["higher_order_residuals"] = {}
            kwargs["higher_order_residual_sampling"] = {}
            return original(**kwargs)

        horizon._numeric_interaction_classification = pairwise_only
        print("C41_MUTANT higher_order wrapper-active", flush=True)
    else:
        raise RuntimeError(f"unknown C41_MUTATION: {mutant}")
