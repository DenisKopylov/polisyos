from __future__ import annotations
import ast
import hashlib
import json
import subprocess
import tomllib
from pathlib import Path

root=Path.cwd()
scope=root/'LOCAL/raw/e02-execution-20261027/repairs/C17-r3'
product=root/'policy-engine'
post=scope/'postimages/policy-engine'
python=product/'.venv/bin/python'
rows=[]
for f in sorted(post.rglob('*.py')):
    logical=f.relative_to(post).as_posix()
    assert f.stat().st_nlink==1 and not f.is_symlink()
    original=f.read_text()
    tree=ast.dump(ast.parse(original), include_attributes=False)
    proc=subprocess.run([str(python),'-m','ruff','format','--stdin-filename',logical,'-'],cwd=product,input=original,text=True,capture_output=True)
    if proc.returncode:
        raise RuntimeError((logical,proc.stderr))
    formatted=proc.stdout
    assert tree == ast.dump(ast.parse(formatted),include_attributes=False),logical
    f.write_text(formatted)
    check=subprocess.run([str(python),'-m','ruff','check','--stdin-filename',logical,'-'],cwd=product,input=formatted,text=True,capture_output=True)
    rows.append({'path':logical,'format_exit':proc.returncode,'check_exit':check.returncode,'check_stdout':check.stdout,'check_stderr':check.stderr,'sha256':hashlib.sha256(formatted.encode()).hexdigest()})
    if check.returncode: raise RuntimeError((logical,check.stdout,check.stderr))
for f in sorted((scope/'removal_controls').glob('*.py')):
    ast.parse(f.read_text())
release=post/'release-fragments/unreleased/2026-10-27-lex-impact-candidate-topics.toml'
tomllib.loads(release.read_text())
receipt={'scope':'canonical product cwd/config with logical stdin filenames; final physical topology and product runtime UNRUN','toml_parse':'PASS','control_scripts_ast':'PASS','checks':rows}
(scope/'static-checks.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'python_files':len(rows),'format_and_ruff':'PASS','control_scripts_ast':'PASS','toml_parse':'PASS','runtime':'UNRUN'},indent=2))
