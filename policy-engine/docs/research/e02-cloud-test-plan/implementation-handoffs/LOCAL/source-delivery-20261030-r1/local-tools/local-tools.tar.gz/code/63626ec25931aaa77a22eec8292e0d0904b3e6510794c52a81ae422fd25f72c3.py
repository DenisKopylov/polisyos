"""Bind actual R171 observational trace, JUnit, finite readset and Git receipt."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys
from xml.etree import ElementTree

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
PROJECT = ROOT / 'policy-engine'
PACKET = ROOT / 'LOCAL/raw/e02-execution-20261027/runtime-prep/R171-three-failure-diagnosis-r2'
CASES = PROJECT / ('docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/'
                   'root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/'
                   'deep-task-status-audit-20261027-r1')
CASE = 'r171-0cf-three-observed-r2'
MANIFEST_SHA = '815eb6dc78212e70067f44ad4c444e2d020125ae27fe4b85eb568b57d05fb4dc'


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(value: bool, reason: str) -> None:
    if not value:
        raise ValueError(reason)


def one(events: list[dict], event: str) -> dict:
    rows = [row for row in events if row.get('event') == event]
    require(len(rows) == 1, 'event denominator: ' + event)
    return rows[0]


def main() -> None:
    require(len(sys.argv) == 1, 'no positional arguments')
    require(sha(PACKET / 'manifest.json') == MANIFEST_SHA, 'diagnostic manifest changed')
    manifest = json.loads((PACKET / 'manifest.json').read_bytes())
    for name, digest in manifest['files'].items():
        require('/' not in name and sha(PACKET / name) == digest, 'diagnostic packet drift: ' + name)
    launch = json.loads((PACKET / 'launch.json').read_bytes())
    expected_env = json.loads(launch['argv'][-1])
    nodes = json.loads((PACKET / 'selector.json').read_bytes())['nodes']
    require(len(nodes) == 3 and len(set(nodes)) == 3, 'selector denominator')
    case = CASES / CASE
    audit_path = case / 'audit-result.json'
    audit = json.loads(audit_path.read_bytes())
    plan, result = audit['plan'], audit['result']
    require(plan['nodes'] == nodes and plan['source_head'] == launch['source_head']
            and plan['source_tree'] == launch['source_tree'] and plan['extra_env'] == expected_env, 'plan mismatch')
    require(result['complete'] and result['process_group_gone'] and result['aborted_reason'] is None
            and result['return_code'] in (0, 1), 'process incomplete or instrument ERROR')
    require(audit['guard_after']['head'] == launch['source_head'] and not audit['current_mismatches']
            and audit['guard_after']['expected_index']['raw_diff_sha256'] == hashlib.sha256(b'').hexdigest(), 'source/index mismatch')
    freeze_path = case / 'source-profile-freeze.json'
    require(sha(freeze_path) == audit['source_profile_freeze_sha256'], 'profile receipt mismatch')
    freeze = json.loads(freeze_path.read_bytes())
    require(all(freeze['extra_env'].get(k) == v for k,v in expected_env.items()), 'actual planned plugin env mismatch')
    require(result['argv'][3:] == freeze['argv'] and result['argv'][-3:] == nodes, 'actual process argv mismatch')
    outputs = {}
    for field in ('stdout_path','stderr_path'):
        rel = Path(result[field]); require(not rel.is_absolute() and '..' not in rel.parts, 'output path')
        outputs[field] = sha(case / rel)
    readsets = audit['readsets']; require(len(readsets) == 1, 'readset denominator')
    readset_path = ROOT / readsets[0]['path']
    require(sha(readset_path) == readsets[0]['sha256'], 'readset digest mismatch')
    readset = json.loads(readset_path.read_bytes())
    require(readset['schema'] == 'r4-runtime-loaded-python-readset-v1' and readset['pid'] == result['pid']
            and Path(readset['project_root']).resolve() == PROJECT and readset['module_count'] == len(readset['modules']), 'readset identity')
    rows = {row['path']:row['sha256'] for row in readset['modules']}
    require(len(rows) == len(readset['modules']), 'duplicate observed paths')
    pins = json.loads(expected_env['E02_R171_DIAG_PINS'])
    for rel, key in (('tests/unit/runtime/quality/test_generation_cycle.py','test'),
                     ('src/polisyos/runtime/quality/generation_cycle.py','owner'),
                     ('src/polisyos/runtime/quality/acquisition_planner.py','planner')):
        require(rows.get(rel) == pins[key] and sha(PROJECT / rel) == pins[key], 'loaded source mismatch: ' + rel)
    git_path = CASES / (CASE + '-Git-readback.json')
    git = json.loads(git_path.read_bytes())
    require(git['case'] == CASE and git['source_head'] == launch['source_head'] and git['source_tree'] == launch['source_tree']
            and git['audit_sha256'] == sha(audit_path) and git['finite_loaded_py_paths'] == len(rows)
            and not git['git_index_work_mismatches'] and git['runtime_result'] == result['junit'], 'Git readback mismatch')
    cases = list(ElementTree.parse(case / 'pytest.xml').iter('testcase'))
    require(len(cases) == 3 and {NODE.split('::')[1] for NODE in nodes} == {item.get('name') for item in cases}, 'JUnit selector mismatch')
    outcomes = {}
    for item in cases:
        require(item.get('classname') == 'tests.unit.runtime.quality.test_generation_cycle', 'JUnit classname mismatch')
        require(item.find('error') is None and item.find('skipped') is None, 'JUnit error or skip')
        outcomes[item.get('name')] = 'failed' if item.find('failure') is not None else 'passed'
    failures = sum(value == 'failed' for value in outcomes.values())
    require(result['junit'] == {'tests':3,'failures':failures,'errors':0,'skipped':0}
            and result['return_code'] == int(bool(failures)), 'JUnit summary mismatch')
    trace_path = case / 'r171-diagnostic.jsonl'
    events = [json.loads(line) for line in trace_path.read_text().splitlines()]
    require(events and all(row['pid'] == result['pid'] for row in events), 'trace PID mismatch')
    configured, collection, final = one(events,'configured'), one(events,'collection'), one(events,'session_finish')
    require(configured['pins'] == pins and configured['reader_equality_span'] == [14042,14045]
            and set(collection['nodeids']) == set(nodes), 'observer configuration mismatch')
    require(set(final['seen']) == set(nodes) and set(final['basis_seen']) == set(nodes)
            and not final['errors'] and final['final_exit'] == result['return_code'], 'observer incomplete')
    for node in nodes:
        restores = [row for row in events if row.get('event') == 'profile_restored' and row.get('node') == node]
        require(len(restores) == 1 and restores[0]['sys_profile_absent'] and restores[0]['thread_profile_absent'], 'profile not restored: ' + node)
    require(not any(row.get('event') == 'observer_error' for row in events), 'observer error')
    relevant = [row for row in events if row.get('event') in {'basis_return','compiler_route_return','cycle_reader_equality','reader_failure_outside_target'}]
    print(json.dumps({'status':'OBSERVATION_QUALIFIED','scope':'one bounded 0cf diagnostic; no costed COV or authority conclusion',
                      'outcomes':outcomes,'observations':relevant,'audit_sha256':sha(audit_path),'git_readback_sha256':sha(git_path),
                      'trace_sha256':sha(trace_path),'junit_sha256':sha(case / 'pytest.xml'),'readset_sha256':sha(readset_path),
                      'observed_python_paths':len(rows),'complete_output_sha256':outputs},indent=2))


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print(json.dumps({'status':'ERROR','reason':type(exc).__name__+': '+str(exc)}))
        raise SystemExit(2) from exc
