"""Build the local DDM candidate patch and exact source-removal controls.

Reads tracked bytes with Git and writes only beneath this packet's RAW directory.
It does not import PolicyOS or execute tests.
"""

from __future__ import annotations

import difflib
import hashlib
import json
import subprocess
from collections import Counter
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[5]
PACKET = Path(__file__).resolve().parent
ACTUAL_BASE = "283fb609abfd483504e4f835c79d9b32db3738c0"
R12_BASE = "6dea075a5052183bb013e6a54a951ef689731c6f"
R12_CARRIER = (
    "policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/"
    "LOCAL/executor-continuation-plan-20261027/cloud-inputs/ddm-la056-r2"
)

INPUTS: list[tuple[str, str]] = [
    ("instructions", "policy-engine/CONTRIBUTING.md"),
    ("pattern_register", "policy-engine/docs/reference/policy-design-case-failure-patterns.md"),
    ("public_surface_boundary", "policy-engine/architecture/imports/policy.toml"),
    ("public_surface_boundary", "policy-engine/architecture/public_surface/contract.toml"),
    ("criterion_bundle", "policy-engine/docs/plans/active/agent-packages/PolicyOS_E02_Combined_Agent_Package/bundles/DDM-01.md"),
    ("criterion_source", "policy-engine/docs/plans/active/agent-packages/PolicyOS_E02_Combined_Agent_Package/source/LA_r09_original.md"),
    ("criterion_route", "policy-engine/docs/research/e02-cloud-test-plan/execution-prompts/unified-local-2026-10-09/TASKS.json"),
    ("criterion_route", "policy-engine/docs/research/e02-cloud-test-plan/closure-decisions/coverage.json"),
    ("criterion_direction", "policy-engine/docs/research/e02-cloud-test-plan/closure-decisions/E.md"),
    ("criterion_route", "policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/executor-continuation-plan-20261027/analysis/criterion-routes.json"),
    ("input_carrier", f"{R12_CARRIER}/manifest.json"),
    ("input_carrier", f"{R12_CARRIER}/proposal.patch.gz"),
    ("input_carrier", f"{R12_CARRIER}/review.md"),
    ("input_carrier", f"{R12_CARRIER}/review.json"),
    ("ddm_package_contract", "policy-engine/src/polisyos/ddm/README.md"),
    ("contract_owner", "policy-engine/src/polisyos/ddm/contracts/events.py"),
    ("budget_owner", "policy-engine/src/polisyos/ddm/contracts/metric_budget.py"),
    ("public_facade", "policy-engine/src/polisyos/ddm/__init__.py"),
    ("public_facade", "policy-engine/src/polisyos/ddm/integration/__init__.py"),
    ("legacy_forwarder", "policy-engine/src/polisyos/ddm/integration/events.py"),
    ("adapter", "policy-engine/src/polisyos/ddm/detectors/track_2_2_shift_adapter.py"),
    ("manual_schema", "policy-engine/src/polisyos/ddm/integration/shift_event.schema.json"),
    ("monitor_consumer", "policy-engine/src/polisyos/ddm/integration/monitor.py"),
    ("monitor_dependency", "policy-engine/src/polisyos/ddm/integration/incident.py"),
    ("monitor_dependency", "policy-engine/src/polisyos/ddm/integration/model_registry.py"),
    ("budget_forwarder", "policy-engine/src/polisyos/ddm/readiness/__init__.py"),
    ("budget_forwarder", "policy-engine/src/polisyos/ddm/readiness/readiness_mapper.py"),
    ("monitor_dependency", "policy-engine/src/polisyos/ddm/calibration/__init__.py"),
    ("monitor_dependency", "policy-engine/src/polisyos/ddm/calibration/audit.py"),
    ("monitor_dependency", "policy-engine/src/polisyos/ddm/calibration/calibrate.py"),
    ("monitor_dependency", "policy-engine/src/polisyos/ddm/calibration/multiple_testing.py"),
    ("monitor_dependency", "policy-engine/src/polisyos/ddm/calibration/observations.py"),
    ("existing_test", "policy-engine/tests/conftest.py"),
    ("existing_test", "policy-engine/tests/unit/ddm/conftest.py"),
    ("existing_test", "policy-engine/tests/unit/ddm/test_facade.py"),
    ("existing_test", "policy-engine/tests/unit/ddm/test_contract_compatibility.py"),
    ("existing_test", "policy-engine/tests/unit/ddm/mirror_contracts/test_events.py"),
    ("existing_test_helper", "policy-engine/tests/_helpers/mirror_contracts.py"),
    ("existing_test", "policy-engine/tests/unit/ddm/test_full_acceptance.py"),
    ("existing_test", "policy-engine/tests/unit/ddm/test_stationary_replay.py"),
    ("existing_test", "policy-engine/tests/unit/scientist/conftest.py"),
    ("existing_test", "policy-engine/tests/unit/scientist/governance/conftest.py"),
    ("existing_test", "policy-engine/tests/unit/scientist/governance/continuous/detectors/test_drift_detectors.py"),
    ("test_configuration", "policy-engine/pyproject.toml"),
    ("test_configuration", "policy-engine/pytest.ini"),
    ("test_configuration", "policy-engine/ruff.toml"),
    ("test_configuration", "policy-engine/uv.lock"),
]

CONTROL_PATHS = {
    "neutral_import": "policy-engine/src/polisyos/ddm/__init__.py",
    "adapter_model_guard": "policy-engine/src/polisyos/ddm/contracts/events.py",
    "manual_schema_guard": "policy-engine/src/polisyos/ddm/integration/shift_event.schema.json",
    "legacy_event_forwarder": "policy-engine/src/polisyos/ddm/integration/events.py",
}
TEST_PATH = "policy-engine/tests/unit/ddm/test_contract_fresh_consumers.py"
CONTROL_PLAN = {
    "neutral_import": {
        "selector": (
            "tests/unit/ddm/test_contract_fresh_consumers.py::"
            "test_neutral_contract_entrypoints_are_independent_cold_processes["
            "polisyos.ddm.contracts.events]"
        ),
        "baseline": "PASS with empty pre-import namespace and no monitor trap attempts",
        "mutant": (
            "FAIL because the child records the live monitor import trap attempt; "
            "other import/setup errors do not count"
        ),
        "restored": "PASS after exact root-facade byte restoration",
    },
    "adapter_model_guard": {
        "selector": (
            "tests/unit/ddm/test_contract_fresh_consumers.py::"
            "test_manual_schema_and_real_adapter_enforce_channel_guard"
        ),
        "baseline": "PASS with p/e/ERT positives and missing/all-null adapter refusals",
        "mutant": (
            "FAIL at pytest.raises when the no-channel payload is accepted by the real adapter"
        ),
        "restored": "PASS after exact events.py byte restoration",
    },
    "manual_schema_guard": {
        "selector": (
            "tests/unit/ddm/test_contract_fresh_consumers.py::"
            "test_manual_schema_and_real_adapter_enforce_channel_guard"
        ),
        "baseline": "PASS with manual anyOf channel positives and no/all-null refusals",
        "mutant": (
            "FAIL because Draft202012Validator accepts the otherwise-valid no-channel payload"
        ),
        "restored": "PASS after exact schema byte restoration",
    },
    "legacy_event_forwarder": {
        "selector": (
            "tests/unit/ddm/test_contract_fresh_consumers.py::"
            "test_synthetic_legacy_pickle_resolves_in_distinct_cold_reader[event]"
        ),
        "fixture_source": (
            "Generate a baseline synthetic writer record with the same selector; "
            "reuse its exact pickle_bytes_base64, sha256, and writer PID for reader-only "
            "baseline/mutant/restored runs through POLISYOS_DDM_EVENT_PICKLE_RECORD_JSON."
        ),
        "baseline": "PASS in a fresh reader with the baseline writer byte record",
        "mutant": (
            "FAIL in the cold reader when the actual legacy FQN no longer resolves; "
            "the failure must not occur while writing bytes"
        ),
        "restored": "PASS with the same reader fixture after exact alias-byte restoration",
    },
}


def run_git(*args: str, text: bool = True) -> str | bytes:
    result = subprocess.run(
        ["git", *args],
        cwd=REPO,
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=text,
    )
    return result.stdout


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git_blob_oid(data: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def tracked_bytes(revision: str, path: str) -> bytes:
    value = run_git("show", f"{revision}:{path}", text=False)
    assert isinstance(value, bytes)
    return value


def ensure_beneath_packet(path: Path) -> None:
    assert path.resolve().is_relative_to(PACKET.resolve())


def write_packet_file(relative: str, data: bytes) -> Path:
    destination = PACKET / relative
    ensure_beneath_packet(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
    return destination


def git_patch(path: str, before: bytes | None, after: bytes, mode: str = "100644") -> bytes:
    before_text = [] if before is None else before.decode("utf-8").splitlines(keepends=True)
    after_text = after.decode("utf-8").splitlines(keepends=True)
    diff = "".join(
        difflib.unified_diff(
            before_text,
            after_text,
            fromfile="/dev/null" if before is None else f"a/{path}",
            tofile=f"b/{path}",
            n=3,
        )
    )
    if before is None:
        old_oid = "0" * 40
        header = (
            f"diff --git a/{path} b/{path}\n"
            f"new file mode {mode}\n"
            f"index {old_oid}..{git_blob_oid(after)}\n"
        )
    else:
        header = (
            f"diff --git a/{path} b/{path}\n"
            f"index {git_blob_oid(before)}..{git_blob_oid(after)} {mode}\n"
        )
    return (header + diff).encode("utf-8")


def mutate(path: str, original: bytes) -> bytes:
    text = original.decode("utf-8")
    if path == CONTROL_PATHS["neutral_import"]:
        needle = "\nif TYPE_CHECKING:\n"
        assert text.count(needle) == 1
        text = text.replace(
            needle,
            "\nfrom polisyos.ddm.integration.monitor import DriftAndDegradationMonitor\n"
            "\nif TYPE_CHECKING:\n",
            1,
        )
    elif path == CONTROL_PATHS["adapter_model_guard"]:
        needle = (
            "        if self.p_value is None and self.e_value is None and self.ert is None:\n"
            '            raise ValueError("shift event must include p_value, e_value, or ert evidence")\n'
        )
        assert text.count(needle) == 1
        text = text.replace(needle, "", 1)
    elif path == CONTROL_PATHS["manual_schema_guard"]:
        needle = (
            '  "anyOf": [\n'
            '    { "properties": { "p_value": { "type": "number", "minimum": 0, "maximum": 1 } }, "required": ["p_value"] },\n'
            '    { "properties": { "e_value": { "type": "number", "minimum": 0 } }, "required": ["e_value"] },\n'
            '    { "properties": { "ert": { "type": "number", "exclusiveMinimum": 0 } }, "required": ["ert"] }\n'
            "  ],\n"
        )
        assert text.count(needle) == 1
        text = text.replace(needle, "", 1)
    elif path == CONTROL_PATHS["legacy_event_forwarder"]:
        assert text.count("    ShiftDetectedEvent,\n") == 1
        assert text.count('    "ShiftDetectedEvent",\n') == 1
        text = text.replace("    ShiftDetectedEvent,\n", "", 1)
        text = text.replace('    "ShiftDetectedEvent",\n', "", 1)
    else:
        raise AssertionError(f"unknown control path {path}")
    return text.encode("utf-8")


def main() -> None:
    packet_root = PACKET.resolve()
    assert packet_root.is_relative_to(REPO.resolve())
    assert run_git("rev-parse", "HEAD").strip() == ACTUAL_BASE
    assert run_git("rev-parse", "HEAD^{tree}").strip() == (
        "97aa8fbd013c67363a6e63b52dfef6e0cd23aad7"
    )
    assert run_git("branch", "--show-current").strip() == (
        "codex/e02-unified-local-20261009"
    )
    assert run_git("rev-parse", f"{R12_BASE}^{{tree}}").strip() == (
        "090267516a7c64512491501e4a532144bfd43565"
    )
    assert not run_git("ls-tree", "-r", "--name-only", ACTUAL_BASE, "--", TEST_PATH).strip()
    assert not run_git("ls-tree", "-r", "--name-only", R12_BASE, "--", TEST_PATH).strip()

    postimage = (
        PACKET
        / "postimages/policy-engine/tests/unit/ddm/test_contract_fresh_consumers.py"
    ).read_bytes()
    write_packet_file(
        "patches/candidate-test.patch",
        git_patch(TEST_PATH, None, postimage),
    )
    write_packet_file(
        "patches/source.diff",
        git_patch(TEST_PATH, None, postimage),
    )

    control_records: dict[str, dict[str, Any]] = {}
    for control_name, path in CONTROL_PATHS.items():
        original = tracked_bytes(ACTUAL_BASE, path)
        changed = mutate(path, original)
        preimage_relative = f"preimages/{path}"
        postimage_relative = f"controls/mutated/{path}"
        patch_relative = f"controls/{control_name}.patch"
        write_packet_file(preimage_relative, original)
        write_packet_file(postimage_relative, changed)
        patch = git_patch(path, original, changed)
        write_packet_file(patch_relative, patch)
        control_records[control_name] = {
            "path": path,
            "preimage_git_blob": git_blob_oid(original),
            "preimage_sha256": sha256(original),
            "preimage_bytes": len(original),
            "mutant_git_blob": git_blob_oid(changed),
            "mutant_sha256": sha256(changed),
            "mutant_bytes": len(changed),
            "patch_path": patch_relative,
            "patch_sha256": sha256(patch),
            "patch_bytes": len(patch),
        }

    input_records = []
    for category, path in INPUTS:
        actual = tracked_bytes(ACTUAL_BASE, path)
        r12 = tracked_bytes(R12_BASE, path)
        input_records.append(
            {
                "category": category,
                "path": path,
                "actual_base": {
                    "git_blob": git_blob_oid(actual),
                    "sha256": sha256(actual),
                    "bytes": len(actual),
                },
                "r12_published_source": {
                    "git_blob": git_blob_oid(r12),
                    "sha256": sha256(r12),
                    "bytes": len(r12),
                },
                "same_bytes_at_actual_base_and_r12": actual == r12,
                "suffix": Path(path).suffix or "(no suffix)",
            }
        )

    suffix_counts = Counter(item["suffix"] for item in input_records)
    category_counts = Counter(item["category"] for item in input_records)
    candidate_git_blob = git_blob_oid(postimage)
    source_diff = (PACKET / "patches/source.diff").read_bytes()
    context_paths = [
        "LOCAL/raw/e02-execution-20261027/next-cloud/Q0-LA056-r11-r1/prompt.md",
        "LOCAL/raw/e02-execution-20261027/cloud/C116/candidate-manifest.json",
        "LOCAL/raw/e02-execution-20261027/cloud/C116/source.diff",
        "LOCAL/raw/e02-execution-20261027/reviews/C116-ddm-actual-independent.md",
        "LOCAL/raw/e02-execution-20261027/reviews/C116-ddm-actual-independent.json",
    ]
    context_records = []
    for path in context_paths:
        raw = (REPO / path).read_bytes()
        context_records.append(
            {"path": path, "sha256": sha256(raw), "bytes": len(raw), "local_context_only": True}
        )

    manifest = {
        "schema": "policyos.ddm_cold_oracle_r3.proposal_manifest.v1",
        "status": "LOCAL_RAW_PROPOSAL_NOT_APPLIED_NOT_EXECUTED",
        "source_base": {
            "commit": ACTUAL_BASE,
            "tree": "97aa8fbd013c67363a6e63b52dfef6e0cd23aad7",
            "branch": "codex/e02-unified-local-20261009",
            "tracked_worktree_status": run_git(
                "status", "--porcelain=v1", "--untracked-files=no"
            ).splitlines(),
            "tracked_worktree_and_index_clean": not run_git(
                "status", "--porcelain=v1", "--untracked-files=no"
            ).strip(),
        },
        "comparison_source": {
            "r12_published_commit": R12_BASE,
            "tree": "090267516a7c64512491501e4a532144bfd43565",
            "topic": "codex/e02-composed-progress-20261028-r12",
        },
        "proposal_output": {
            "path": TEST_PATH,
            "base_state": "absent_at_actual_and_r12_bases",
            "candidate_file": "postimages/policy-engine/tests/unit/ddm/test_contract_fresh_consumers.py",
            "candidate_sha256": sha256(postimage),
            "candidate_git_blob": candidate_git_blob,
            "candidate_bytes": len(postimage),
            "patch": "patches/source.diff",
            "patch_sha256": sha256(source_diff),
            "patch_bytes": len(source_diff),
            "changed_path_count": 1,
        },
        "named_source_input_denominator": {
            "path_count": len(input_records),
            "suffix_counts": dict(sorted(suffix_counts.items())),
            "category_counts": dict(sorted(category_counts.items())),
            "statement": (
                "This named set is the explicit source, test, config, criterion, and input-carrier "
                "starting set for this repair. It is not the runtime imported-source readset; the "
                "Root-owned per-PID observer must enumerate and reconcile the actual pytest and "
                "fresh-child loaded first-party modules and configuration bytes."
            ),
            "pins": input_records,
        },
        "controls": control_records,
        "control_plan": {
            "status": "PROPOSED_NOT_EXECUTED",
            "stage_requirement": (
                "Apply candidate and exactly one control at a time in a physical scratch "
                "stage from the exact source base; do not share source inodes through links. "
                "For each control preserve baseline, mutant, restored streams and read back "
                "the exact target and candidate bytes after restoration."
            ),
            "cases": CONTROL_PLAN,
        },
        "context_artifacts": context_records,
        "evidence_planning_budget_bytes": 524288,
        "execution": {
            "product_imports_or_tests_run_by_author": False,
            "controls_executed_by_author": False,
            "historical_writer": "UNRUN; only a local synthetic old-FQN writer is included",
            "full_stationary_module": "UNRUN by this author; Root must run whole module or list remainder UNRUN",
            "source_observer": (
                "No new verifier/gate is proposed. The candidate child helper emits exact child "
                "stdout/stderr, argv, selected environment profile, process identity, first-party "
                "module origins and source hashes before assertions. Root retains normal pytest/"
                "JUnit streams and its generic per-PID source/config observer."
            ),
        },
    }
    manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
    write_packet_file("manifest.json", manifest_bytes)


if __name__ == "__main__":
    main()
