"""Build finite committed-input and mutation specifications; never import the product."""
from pathlib import Path
import ast, copy, hashlib, json, subprocess
R=Path.cwd(); O=R/'LOCAL/raw/e02-execution-20261027/repairs/C32-native-composed-r1'; P=R/'policy-engine'
BASE='026f0c89ac7ab9648f0c6727fd32f1be4bcb8f5e'
def git(*args): return subprocess.check_output(['git',*args],cwd=R)
def sha(b): return hashlib.sha256(b).hexdigest()
def put(n,d): (O/n).write_text(json.dumps(d,indent=2)+'\n')
old=json.loads((R/'LOCAL/raw/e02-execution-20261027/repairs/C32-r7/manifest.json').read_text())
paths={x['path'] for x in old['files']}
# Explicit fixture/import/pytest control inputs; runtime readsets remain the actual denominator.
extras=['tests/unit/fabric/test_retrieval_fetch_custody.py','tests/unit/runtime/quality/test_acquisition_planner.py','tests/_helpers/acquisition_production.py','tests/_helpers/controlled_candidate_profile.py','tests/_helpers/measurement_execution_binding.py','tests/conftest.py','pytest.ini','pyproject.toml','uv.lock']
paths.update('policy-engine/'+p for p in extras)
rows={}
for p in sorted(paths):
 b=git('show',BASE+':'+p); assert (R/p).read_bytes()==b,p
 rows[p]={'sha256':sha(b),'git_blob':git('rev-parse',BASE+':'+p).decode().strip(),'kind':'C32 primary' if p in {r['path'] for r in old['files']} else 'explicit fixture/config companion'}
review=json.loads((R/'LOCAL/raw/e02-execution-20261027/root-c32-physical-imports-r1/manifest.json').read_text())
doc_dedup=json.loads((R/'LOCAL/raw/e02-execution-20261027/composition-c41-c49-r1/C32-doc-dedup-r1/manifest.json').read_text())
rebind=[]
for row in old['files']:
 p=row['path']; now=rows[p]['sha256']
 if now!=row['postimage_sha256']:
  basis=('C41/C49 composed generation' if p.endswith('/generation_cycle.py') else ('root README dedup composition' if p.endswith('.md') else 'physical import-only review'))
  if basis.startswith('physical'):
   rr=next(x for x in review['files'] if x['path']==p); assert now==rr['post_sha256']
   t1=ast.parse((R/row['postimage_path']).read_bytes());t2=ast.parse(git('show',BASE+':'+p))
   def removeimports(t):
    class Drop(ast.NodeTransformer):
     def visit_Import(self,n):return None
     def visit_ImportFrom(self,n):return None
    return ast.dump(Drop().visit(t),include_attributes=False)
   assert removeimports(t1)==removeimports(t2)
  elif p.endswith('.md'):
   assert p==doc_dedup['path'] and now==doc_dedup['postimage_sha256']
  else: assert now=='ee3c6effa4e6a68dffbafaeaba5b02ee928af675df7f29b37940edb23ccb8dca'
  rebind.append({'path':p,'historical_r7_sha256':row['postimage_sha256'],'current_sha256':now,'basis':basis})
assert sum(x['path'].endswith('.py') for x in rebind)==9
put('source-bindings.json',{'base_commit':BASE,'base_tree':git('rev-parse',BASE+'^{tree}').decode().strip(),'inputs':rows,'primary_footprint_paths':sorted(x['path'] for x in old['files']),'reviewed_rebinds':rebind,'scope':'Finite explicit input set, not a transitive import census. Subsequent actual imported modules must be reconciled from retained runtime readsets.','runtime':'UNRUN'})
STORE='src/polisyos/data_forge/domains/catalog/knowledge/store.py';ACQ='src/polisyos/runtime/quality/acquisition_planner.py';GEN='src/polisyos/runtime/quality/generation_cycle.py';FAB='src/polisyos/fabric/retrieval/service.py';REG='src/polisyos/runtime/quality/substrate_registry.py'
T='tests/unit/runtime/quality/test_catalog_acquisition_source_binding.py';V='tests/unit/data_forge/domains/catalog/knowledge/test_variable_availability.py';N='tests/unit/runtime/quality/test_catalog_n7_source_refusal.py';F='tests/unit/fabric/retrieval/test_catalog_read_source_failure.py'
C={
 'empty_subtype':(STORE,['DatasetCatalogStore.identify_read_sources'],V+'::test_empty_initial_native_identity_is_typed_error_not_absent_data',2,'assert isinstance(failure.value, CatalogReadSourceError)','actual ValueError normalization emits superclass with identical code/cause, losing transport ancestry'),
 'capture_forward':(ACQ,['RealAcquisitionOwnerGateway._capture_fabric'],T+'::test_real_gateway_preserves_source_fault_after_selection_before_actual_resolution',6,'actual gateway source fault must use the binding-error adapter','restore old inner None fallback only, retaining outer typed classifier; only persisted_capture cases must fail'),
 'acquisition_adapter':(ACQ,['RealAcquisitionOwnerGateway.acquire'],T+'::test_real_gateway_preserves_source_fault_after_selection_before_actual_resolution',6,'actual gateway source fault must use the binding-error adapter','disable typed source-to-binding adapter only; source cause still emitted by actual Store'),
 'n7_mapping':(GEN,['GenerationCycleController._run_n7_acquisition_if_requested'],N+'::test_actual_gateway_fault_is_persisted_as_exact_n7_cycle_refusal',3,'n6.acquisition.n7_catalog_source_refused.','remove typed source-cause-to-cycle diagnostic mapping; generic refusal remains persisted/fresh but exact diagnostic fails'),
 'fabric_family':(FAB,['RetrievalService._catalog_publish_admission','RetrievalService._resolve_via_catalog_rows'],F+'::test_resolver_preserves_owner_failure_family_and_keeps_unrelated_provider_fallback',8,'DID NOT RAISE','remove four typed family rethrows only; four typed cases fail and four unrelated-provider cases must remain pass'),
 'graph_binding':(REG,['require_catalog_serving_graph_binding'],T+'::test_foreign_or_shaped_graph_is_refused_before_actual_consumer_use',3,'selected graph binding must refuse before real consumer use','remove graph owner/identity admission; retain selected markers, actual resolver/native use must be observed in failure diagnostic'),
 'postread':(STORE,['DatasetCatalogStore.read_session'],V+'::test_replacement_during_actual_count_read_refuses_before_result_escapes',1,'DID NOT RAISE','remove final identity reconciliation after actual logical native read, preserving initial guard'),
 'wal':(STORE,['DatasetCatalogStore.identify_read_sources'],V+'::test_read_identity_refuses_uncheckpointed_native_wal_without_deleting_it',2,'DID NOT RAISE','remove both visible-WAL refusals, preserve full byte identity and real WAL bytes')}
# Read actual name instead of a remembered spelling.
names={n.name for n in ast.parse((P/T).read_bytes()).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
foreign=[n for n in names if n.startswith('test_') and ('foreign' in n or 'unbound' in n)];assert len(foreign)==1
c=list(C['graph_binding']);c[2]=T+'::'+foreign[0];C['graph_binding']=tuple(c)
class Rewrite(ast.NodeTransformer):
 def __init__(self,mode):self.mode=mode;self.count=0
 def visit_If(self,n):
  test=ast.unparse(n.test)
  if self.mode=='fabric_family' and test=='isinstance(exc, catalog_read_api.CatalogReadSourceError)':self.count+=1;return None
  if self.mode=='wal' and test=='wal.exists() or wal.is_symlink()':self.count+=1;return None
  if self.mode=='n7_mapping' and test=='exc.source_refusal_code is not None':self.count+=1;return None
  if self.mode=='acquisition_adapter' and isinstance(n.test,ast.Call) and any(isinstance(x,ast.Attribute) and x.attr=='CatalogReadSourceError' for x in ast.walk(n.test)):
   self.count+=1;n.test=ast.Constant(False);return n
  return self.generic_visit(n)
 def visit_Raise(self,n):
  if self.mode=='capture_forward' and isinstance(n.exc,ast.Call) and isinstance(n.exc.func,ast.Name) and n.exc.func.id=='_FabricCaptureError':self.count+=1;return ast.copy_location(ast.Return(ast.Constant(None)),n)
  return self.generic_visit(n)
 def visit_Try(self,n):
  if self.mode=='postread' and n.finalbody and n.body and isinstance(n.body[-1],ast.Expr) and isinstance(n.body[-1].value,ast.Call) and isinstance(n.body[-1].value.func,ast.Attribute) and n.body[-1].value.func.attr=='_require_current_read_session':
   self.count+=1;n.body.pop()
  if self.mode=='empty_subtype':
   for h in n.handlers:
    if h.type is not None and ast.unparse(h.type)=='(OSError, RuntimeError, ValueError)':
     calls=[x for s in h.body for x in ast.walk(s) if isinstance(x,ast.Call) and isinstance(x.func,ast.Name) and x.func.id=='CatalogReadSourceError'];assert len(calls)==1;calls[0].func.id='CatalogSelectionError';self.count+=1
  return self.generic_visit(n)
def find(t,q):
 for part in q.split('.'):
  matches=[n for n in t.body if isinstance(n,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==part];assert len(matches)==1,(q,part);t=matches[0]
 return t
controls={};(O/'mutations').mkdir(exist_ok=True)
for mode,(path,targets,node,cases,assertion,property_) in C.items():
 source=git('show',BASE+':policy-engine/'+path); full=ast.parse(source);functions=[];total=0
 for q in targets:
  orig=copy.deepcopy(find(full,q));orig.decorator_list=[];before=ast.unparse(orig)+'\n';changed=copy.deepcopy(orig)
  if mode=='graph_binding':changed.body=[changed.body[0],ast.Return(ast.Constant(None))];n=1
  else:
   rw=Rewrite(mode);changed=rw.visit(changed);n=rw.count
  total+=n;ast.fix_missing_locations(changed);after=ast.unparse(changed)+'\n';assert before!=after,(mode,q,n)
  # Only source construction and AST checks; never exec/compile/import product here.
  ast.parse(after);artifact=f'mutations/{mode}-{q.replace(".","-")}.py';(O/artifact).write_text(after)
  functions.append({'qualified_name':q,'source_function_ast_sha256':sha(ast.dump(orig,include_attributes=False).encode()),'mutant_function_source':artifact,'mutant_source_sha256':sha(after.encode()),'rewrite_count':n})
 expected={'fabric_family':4,'wal':2}.get(mode,1);assert total==expected,(mode,total)
 controls[mode]={'source':path,'source_sha256':sha(source),'functions':functions,'node':node,'test_sha256':rows['policy-engine/'+node.split('::')[0]]['sha256'],'literal_cases':cases,'expected_assertion':assertion,'property_removed':property_,'expected_semantic_outcome':{'empty_subtype':'2 FAIL','capture_forward':'3 FAIL persisted_capture / 3 PASS resolve_only','acquisition_adapter':'6 FAIL','n7_mapping':'3 FAIL','fabric_family':'4 FAIL typed_source / 4 PASS unrelated','graph_binding':'3 FAIL','postread':'1 FAIL','wal':'2 FAIL'}[mode],'qualification':'Hypothesis only; exact selected cases, actual assertion, active callable entry, preserved backend/profile, no errors/skips, source/readset equivalence and restoration require actual deciding outputs.'}
put('controls.json',controls)
print(json.dumps({'finite_inputs':len(rows),'primary_paths':len(old['files']),'rebinds':len(rebind),'controls':len(controls),'control_functions':sum(len(x['functions']) for x in controls.values()),'runtime':'UNRUN'}))
