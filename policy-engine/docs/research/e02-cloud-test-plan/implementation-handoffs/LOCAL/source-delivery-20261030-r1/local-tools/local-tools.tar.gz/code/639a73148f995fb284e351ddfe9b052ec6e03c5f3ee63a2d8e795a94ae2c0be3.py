from pathlib import Path
import hashlib,json
R=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos');O=Path(__file__).resolve().parent;rel='policy-engine/src/polisyos/core/artifacts/store.py';p=R/rel;s=p.read_text();pre=hashlib.sha256(p.read_bytes()).hexdigest()
def one(old,new):
 global s
 assert s.count(old)==1,(old,s.count(old));s=s.replace(old,new)
one('    signature_surface: bool = False,\n','    signature_surface: bool = False,\n    manifest_bytes_result: bool = False,\n')
one('                operation_token = _PUBLIC_READ_OPERATION.set(method.__name__)\n','                store._require_enrolled_child_release(aid, profile_sha256)\n                operation_token = _PUBLIC_READ_OPERATION.set(method.__name__)\n')
one('                store._capture_public_read_operation(method.__name__, selector_value)\n','                store._require_child_read_result(\n                    result, selector_value, manifest_bytes_result=manifest_bytes_result\n                )\n                store._capture_public_read_operation(method.__name__, selector_value)\n')
one('        self._read_only = read_only\n','        self._read_only = read_only\n        self._child_staging_infos: set[object] = set()\n')
methods='''    def _configure_child_staging(self, info: object, *, token: object) -> None:
        """Admit Core custody's private store view, never a served-root bypass."""
        from .child_release import _CHILD_STAGING_TOKEN, child_store_identity
        from .manifest import ArtifactChildReleaseInfo

        if token is not _CHILD_STAGING_TOKEN or type(info) is not ArtifactChildReleaseInfo:
            raise TypeError("child staging is configured by Core custody")
        if info.served_store_identity == child_store_identity(self.root):
            raise ValueError("a served store cannot use a private staging grant")
        self._child_staging_infos.add(info)

    def _private_child_infos(self) -> tuple[object, ...]:
        return tuple(self._child_staging_infos)

    def _require_enrolled_child_release(
        self, artifact_id: ArtifactID, profile_sha256: str | None
    ) -> None:
        from .child_release import require_enrolled_child_release

        require_enrolled_child_release(
            self.root, artifact_id, profile_sha256,
            private_infos=self._private_child_infos(),
        )

    def _require_child_manifest_release(self, manifest: ArtifactManifest) -> None:
        from .child_release import require_child_release_manifest

        require_child_release_manifest(
            self.root, manifest, private_infos=self._private_child_infos(),
        )

    def _require_child_read_result(
        self, value: object, selector: object, *, manifest_bytes_result: bool
    ) -> None:
        """Gate actual emitted sidecars without an unmetered manifest preread."""
        from .child_release import require_child_release_raw

        if isinstance(value, ArtifactManifest):
            self._require_child_manifest_release(value)
        elif isinstance(value, ArtifactBoundedManifestRead):
            require_child_release_raw(
                self.root, value.raw_manifest_bytes,
                private_infos=self._private_child_infos(),
            )
        elif isinstance(value, _VerifiedArtifactSnapshot):
            require_child_release_raw(
                self.root, value.manifest_bytes,
                private_infos=self._private_child_infos(),
            )
        elif manifest_bytes_result:
            if type(value) is not bytes:
                raise TypeError("manifest-byte read returned a non-byte result")
            require_child_release_raw(
                self.root, value, private_infos=self._private_child_infos(),
            )
        elif type(value) is bool and value:
            # Existence/signature probes must not reveal a pending child view.
            self.get_manifest(selector)

'''
one('    @contextmanager\n    def _capture_public_read_set',methods+'    @contextmanager\n    def _capture_public_read_set')
# Raw byte ports use the same decorator result gate, after their own bounded read.
for name,decorator in [('get_raw_manifest_bytes','@_transactional_read(profile_argument_index=0)'),('get_raw_manifest_bytes_bounded','@_transactional_read(profile_argument_index=1)'),('get_raw_manifest_bytes_bounded_for_input','@_transactional_read()')]:
 old='    '+decorator+'\n    def '+name+'('
 new=old.replace(')',', manifest_bytes_result=True)' if decorator!='@_transactional_read()' else 'manifest_bytes_result=True)',1)
 one(old,new)
# Streaming emission is independently bounded and already has its exact typed manifest.
one('            selected_path = self._member_path(aid, member, profile_sha256)\n','            self._require_child_manifest_release(manifest)\n            selected_path = self._member_path(aid, member, profile_sha256)\n')
# The streamed port also checks deny-first enrollment before transferring metadata.
one('            self._require_blob_owner(aid, operation=f"read_{member}", ref=ref)\n','            self._require_enrolled_child_release(aid, profile_sha256)\n            self._require_blob_owner(aid, operation=f"read_{member}", ref=ref)\n')
# Inventories must not reveal a sidecar merely because tenant enforcement is disabled.
one('        for artifact_hex in sorted(default_ids):\n            artifact_id = ArtifactID.from_sha256_hex(artifact_hex)\n','        for artifact_hex in sorted(default_ids):\n            artifact_id = ArtifactID.from_sha256_hex(artifact_hex)\n            from .child_release import ChildReleaseUnavailableError\n            try:\n                manifest_path = self._paths(artifact_id)[1]\n                self._require_child_manifest_release(self._manifests.read(manifest_path))\n            except ChildReleaseUnavailableError:\n                continue\n')
one('            visible_views.append(\n','            from .child_release import ChildReleaseUnavailableError\n            try:\n                self._require_child_manifest_release(manifest)\n            except ChildReleaseUnavailableError:\n                continue\n            visible_views.append(\n')
# Refuse before archive output creation; streaming repeats the same actual check.
one('        def member_name(request: ArtifactID | ArtifactRef, member: str) -> str:\n','        for artifact_id in artifact_ids:\n            self.get_manifest(artifact_id)\n\n        def member_name(request: ArtifactID | ArtifactRef, member: str) -> str:\n')
q=O/'postimages'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(s);(O/'store-preimage.json').write_text(json.dumps({'path':rel,'sha256':pre},indent=2)+'\n');print('Store proposal prepared; no canonical mutation')
