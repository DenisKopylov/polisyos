"""Bounded actual-collector/test-callable comparisons; no native/full collection."""
from pathlib import Path
import gc,hashlib,importlib.util,inspect,json,resource,signal,sys,time,traceback
ROOT=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos');PRODUCT=ROOT/'policy-engine';P=Path(__file__).resolve().parent
signal.alarm(110);sys.path.insert(0,str(PRODUCT))
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
T=load('r11_legacy_tests',PRODUCT/'tests/repo_quality/architecture/test_decomposition_preflight_gates.py')
CASES=[
 ('test_dynamic_import_scanner_does_not_treat_plain_root_words_as_capabilities',{}),
 ('test_dynamic_import_operator_results_keep_unknown_callable_origin_ambiguous',{}),
 ('test_dynamic_import_collector_allows_ambiguous_nonimporter_return',{}),
 ('test_dynamic_import_collector_ignores_sys_path_setup',{}),
 ('test_dynamic_import_collector_allows_unrelated_importlib_utility_call',{}),
 ('test_dynamic_import_collector_ignores_unknown_registry_nonimporter_method',{}),
 ('test_dynamic_import_importer_in_deferred_object_refuses_opaque_call_argument',{}),
 ('test_dynamic_import_guarded_origin_nested_deferred_no_sink_stays_nonfailing',{}),
 ('test_dynamic_import_collector_tracks_unmodeled_source_mapping_transfers',{'transfer':'setdefault','payload_kind':'unrelated-scalar','mutator_module':'a_mutator'}),
 ('test_dynamic_import_exact_local_mapping_slot_write_preserves_nested_source_map',{'mutation':'store-new-slot','mutator_module':'a_mutator'}),
 ('test_dynamic_import_lazy_export_map_tracks_selected_sibling_effects',{'source_effect':'opaque-module-attribute','owner_map_resolved_first':True}),
 ('test_dynamic_import_lazy_export_map_tracks_selected_sibling_effects',{'source_effect':'opaque-module-attribute','owner_map_resolved_first':False}),
]
result={'scope':'12 legacy discriminator cases plus complete78 candidate CASES and4 semantic removals; not full native/P41 replay','test_module_sha256':hashlib.sha256(Path(T.__file__).read_bytes()).hexdigest(),'owner_sha256':json.loads((P/'candidate-owner.json').read_text())['sha256'],'rows':[]}
for variant in [dict(json.loads((P/'candidate-owner.json').read_text()),name='candidate-final')]:
 owner=load('r11_'+variant['name'],Path(variant['owner']));owner.REPO_ROOT=PRODUCT;owner.SRC_ROOT=PRODUCT/'src'
 T.preflight=owner
 for name in ['REPO_ROOT','validate_dynamic_imports','validate_import_cycles','validate_import_time_regression','validate_reexport_shim_shapes']:setattr(T,name,getattr(owner,name))
 for i,(name,kwargs) in enumerate(CASES):
  fixture=P/'fixtures'/sys.argv[1]/variant['name']/str(i);fixture.mkdir(parents=True,exist_ok=True)
  fn=getattr(T,name);args=dict(kwargs);params=inspect.signature(fn).parameters
  if 'tmp_path' in params:args['tmp_path']=fixture
  row={'variant':variant['name'],'case':name,'parameters':kwargs,'owner_origin':owner.__file__,'owner_sha256':variant['sha256']};start=time.monotonic()
  try:
   with T.pytest.MonkeyPatch.context() as patch:
    if 'monkeypatch' in params:args['monkeypatch']=patch
    fn(**args)
  except BaseException as e:row.update(status='FAIL',error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc())
  else:row['status']='PASS'
  row['elapsed_seconds']=time.monotonic()-start;result['rows'].append(row)
  with (P/'representatives.progress.jsonl').open('a') as stream:stream.write(json.dumps(row)+'\n')
  gc.collect()
N=load('r11_new_tests',P/'candidate/policy-engine/tests/repo_quality/architecture/test_dynamic_code_reconstitution.py');N.preflight=owner
result['new_test_module_origin']=N.__file__;result['new_test_module_sha256']=hashlib.sha256(Path(N.__file__).read_bytes()).hexdigest()
for i,name in enumerate(N.CASES):
 row={'variant':'candidate-final','case':'new:'+name};start=time.monotonic()
 try:N.test_dynamic_code_reconstitution(name, P/'fixtures'/sys.argv[1]/'new'/str(i))
 except BaseException as e:row.update(status='FAIL',error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc())
 else:row['status']='PASS'
 row['elapsed_seconds']=time.monotonic()-start;result['rows'].append(row)
for i,name in enumerate(['test_dynamic_code_invocation_removal_is_semantic','test_dynamic_code_join_provenance_removal_is_semantic','test_dynamic_code_normalization_removal_is_semantic','test_dynamic_deferred_payload_removal_is_semantic']):
 row={'variant':'candidate-final','case':name};start=time.monotonic()
 try:
  with N.pytest.MonkeyPatch.context() as patch:getattr(N,name)(P/'fixtures'/sys.argv[1]/'removal'/str(i),patch)
 except BaseException as e:row.update(status='FAIL',error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc())
 else:row['status']='PASS'
 row['elapsed_seconds']=time.monotonic()-start;result['rows'].append(row)
result.update(product_imports=[n for n in sys.modules if n=='polisyos' or n.startswith('polisyos.')],ru_maxrss_platform_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
print(json.dumps(result,indent=2))
