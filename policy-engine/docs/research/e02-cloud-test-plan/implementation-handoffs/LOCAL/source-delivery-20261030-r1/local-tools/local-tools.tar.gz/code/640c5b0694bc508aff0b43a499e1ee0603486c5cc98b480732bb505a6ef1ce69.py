"""Source-only identity, syntax and patch applicability; no product imports."""
from __future__ import annotations
import ast
import difflib
import hashlib
import json
import subprocess
from pathlib import Path

root=Path.cwd()
out=root/'LOCAL/raw/e02-execution-20261027/repairs/C90-provenance-domain-r5'
post=out/'postimages'
paths=sorted(str(p.relative_to(post)) for p in post.rglob('*') if p.is_file())
manifest=[]
patch=[]
for path in paths:
    physical=root/path
    before=physical.read_bytes() if physical.exists() else None
    after=(post/path).read_bytes()
    try:
        tracked=subprocess.check_output(['git','show','283fb609abfd483504e4f835c79d9b32db3738c0:'+path],cwd=root,stderr=subprocess.DEVNULL)
    except subprocess.CalledProcessError:
        tracked=None
    if before!=tracked:
        raise RuntimeError(f'physical preimage diverges from pinned base: {path}')
    if before is not None:
        saved=(out/'preimages'/path).read_bytes()
        assert saved == before
    sha=lambda b: None if b is None else hashlib.sha256(b).hexdigest()
    blob=lambda b: None if b is None else hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
    manifest.append({'path':path,'preimage_exists':before is not None,'preimage_sha256':sha(before),'preimage_git_blob':blob(before),'postimage_sha256':sha(after),'postimage_git_blob':blob(after),'bytes':len(after)})
    patch.extend(difflib.unified_diff((before or b'').decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),fromfile=('a/'+path if before is not None else '/dev/null'),tofile='b/'+path))
    if path.endswith('.py'):
        ast.parse(after,filename=path)
(out/'source.diff').write_text(''.join(patch))
(out/'source-manifest.json').write_text(json.dumps({'base_commit':'283fb609abfd483504e4f835c79d9b32db3738c0','base_tree':'97aa8fbd013c67363a6e63b52dfef6e0cd23aad7','candidate_input_tree':'a396d80cce7c0c593d2c8bf826267b2771092e66','preimage_source':'physical root checkout, read back and compared to pinned base','files':manifest,'source_patch_sha256':hashlib.sha256((out/'source.diff').read_bytes()).hexdigest()},indent=2)+'\n')

names=['propagate_posterior_summary','_build_gaussian_joint_spec','_sample_from_envelope','_transform_qmc_samples','_run_random_loop','_run_qmc_loop','_evaluate_posterior_outputs']
name='policy-engine/src/polisyos/foundry/uncertainty/monte_carlo.py'
old=ast.parse(subprocess.check_output(['git','show','a396d80cce7c0c593d2c8bf826267b2771092e66:'+name],cwd=root))
new=ast.parse((post/name).read_bytes())
def find(tree,name):
    nodes=[n for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name]
    assert len(nodes)==1,(name,len(nodes))
    return ast.dump(nodes[0],include_attributes=False)
assert all(find(old,n)==find(new,n) for n in names)
for n in ('propagate','propagate_posterior_summary'):
    def signature(tree):
        nodes=[q for q in ast.walk(tree) if isinstance(q,(ast.FunctionDef,ast.AsyncFunctionDef)) and q.name==n]
        return [ast.dump(q.args,include_attributes=False) for q in nodes]
    assert signature(old)==signature(new),n

controls=json.loads((out/'removals.json').read_text())['controls']
results=[]
for control in controls:
    result=subprocess.run(['patch','--dry-run','--batch','-p1'],input=(out/control['patch']).read_bytes(),cwd=post,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    results.append({'id':control['id'],'exit':result.returncode,'stdout':result.stdout.decode(),'stderr':result.stderr.decode()})
    assert result.returncode==0,(control['id'],result.stdout,result.stderr)
(out/'static-checks.json').write_text(json.dumps({'python_postimages_parsed':[p for p in paths if p.endswith('.py')],'unchanged_candidate_AST_functions':names,'public_MC_signature_args_checked':['propagate','propagate_posterior_summary'],'removal_dry_runs':results,'product_imports':False,'native_tests_run':False},indent=2)+'\n')
print('physical preimages match pinned base; postimages parsed; 7 AST bodies and MC signatures unchanged; all removal patches apply by dry run')
