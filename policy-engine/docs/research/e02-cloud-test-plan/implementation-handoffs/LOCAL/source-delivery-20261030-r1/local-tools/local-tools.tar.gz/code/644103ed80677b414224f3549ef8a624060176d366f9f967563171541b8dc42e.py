"""Read-only R3 source/patch/control qualification; never import product code."""
from pathlib import Path
import ast
import hashlib
import json
import re
import subprocess
import sys
import tomllib

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
OUT = Path(__file__).resolve().parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def apply_in_memory(patch, originals):
    """Reconstruct every unified hunk with exact context and line counts."""
    lines = patch.splitlines(keepends=True)
    pos, result = 0, {}
    while pos < len(lines):
        assert lines[pos].startswith('--- '), lines[pos]
        old_name = lines[pos][4:].strip()
        assert lines[pos + 1].startswith('+++ ')
        name = lines[pos + 1][4:].strip().removeprefix('b/')
        old = '' if old_name == '/dev/null' else originals[name]
        source = old.splitlines(keepends=True)
        output, consumed = [], 0
        pos += 2
        while pos < len(lines) and not lines[pos].startswith('--- '):
            match = re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*\n', lines[pos])
            assert match, lines[pos]
            start, old_count, new_start, new_count = [int(x) if x is not None else 1 for x in match.groups()]
            target = max(0, start - 1)
            assert target >= consumed
            output.extend(source[consumed:target])
            consumed = target
            old_seen = new_seen = 0
            pos += 1
            while pos < len(lines) and not lines[pos].startswith(('@@ ', '--- ')):
                line = lines[pos]
                if line.startswith(' '):
                    assert consumed < len(source) and source[consumed] == line[1:]
                    output.append(line[1:]); consumed += 1; old_seen += 1; new_seen += 1
                elif line.startswith('-'):
                    assert consumed < len(source) and source[consumed] == line[1:]
                    consumed += 1; old_seen += 1
                elif line.startswith('+'):
                    output.append(line[1:]); new_seen += 1
                else:
                    raise AssertionError(line)
                pos += 1
            assert (old_seen, new_seen) == (old_count, new_count)
        output.extend(source[consumed:])
        assert name not in result
        result[name] = ''.join(output)
    return result


bindings = json.loads((OUT / 'source-bindings.json').read_text())
base = bindings['source_base_commit']
assert git('rev-parse', base + '^{tree}').decode().strip() == bindings['source_base_tree']
originals, postimages = {}, {}
for row in bindings['source_rows']:
    path = row['path']
    if row['new_file']:
        missing = subprocess.run(['git', 'cat-file', '-e', base + ':' + path], cwd=ROOT, capture_output=True)
        assert missing.returncode != 0
        before = None
    else:
        before = git('show', base + ':' + path)
        assert sha(before) == row['preimage_sha256']
    data = (OUT / row['postimage']).read_bytes()
    assert sha(data) == row['postimage_sha256'] and len(data) == row['postimage_bytes']
    originals[path] = '' if before is None else before.decode()
    postimages[path] = data.decode()
    if path.endswith('.py'):
        ast.parse(data.decode(), filename=path)
    if path.endswith('.toml'):
        parsed = tomllib.loads(data.decode())
        assert parsed['generated_client_compatibility'] == 'not_applicable'
        assert parsed['public_surface_inventory_reviewed'] is False
assert apply_in_memory((OUT / 'source.patch').read_text(), originals) == postimages
controls = json.loads((OUT / 'property-removals.json').read_text())['controls']
for row in controls:
    data = (OUT / row['patch']).read_bytes()
    assert sha(data) == row['patch_sha256']
    result = apply_in_memory(data.decode(), postimages)
    assert set(result) == {row['path']}
    assert sha(result[row['path']].encode()) == row['mutant_sha256']
    ast.parse(result[row['path']], filename=row['path'])
    assert row['runtime'] == 'UNRUN'

plan = json.loads((OUT / 'verification-plan.json').read_text())
tree = ast.parse(postimages[plan['new_test_file']])
counts = {}
for node in tree.body:
    if isinstance(node, ast.FunctionDef) and node.name.startswith('test_'):
        count = 1
        for decorator in node.decorator_list:
            if isinstance(decorator, ast.Call) and isinstance(decorator.func, ast.Attribute) and decorator.func.attr == 'parametrize':
                count *= len(ast.literal_eval(decorator.args[1]))
        counts[node.name] = count
assert len(counts) == 23 and sum(counts.values()) == plan['source_potential_cases'] == 319
assert counts == {x['name']: x['source_potential_cases'] for x in plan['test_definitions']}
ruff = json.loads((OUT / 'static-ruff.json').read_text())
for command in ruff['commands']:
    assert command['exit_code'] == 0
    if 'source_sha256' in command:
        assert command['source_sha256'] == sha(postimages['policy-engine/' + command['logical_filename']].encode())
for p in OUT.glob('*.py'):
    ast.parse(p.read_text(), filename=str(p))

head, tree = git('rev-parse', 'HEAD', 'HEAD^{tree}').decode().splitlines()
working = {}
for row in bindings['source_rows']:
    p = ROOT / row['path']
    actual = sha(p.read_bytes()) if p.exists() else None
    working[row['path']] = actual == row['preimage_sha256']
audit = {'schema': 'policyos.e02.C90.law_admission_r3_static_self_audit.v1',
         'status': 'AUTHOR STATIC ONLY; independent source review pending; no runtime PASS',
         'source_base_commit': base, 'source_base_tree': bindings['source_base_tree'],
         'actual_HEAD_at_readback': head, 'actual_tree_at_readback': tree,
         'all_five_working_preimages_match_base': all(working.values()), 'working_preimages': working,
         'source_patch_in_memory_reconstructs_all_five_postimages': True,
         'all_nine_control_patches_reconstruct_exact_mutants_and_AST_parse': True,
         'test_definitions': len(counts), 'source_potential_cases': sum(counts.values()),
         'actual_collected_cases': None, 'static_Ruff_three_canonical_filenames': 'PASS',
         'AST_and_TOML': 'PASS', 'Python_for_readonly_scanners': sys.version,
         'product_imports': 'UNRUN', 'runtime_tests': 'UNRUN', 'removal_and_restoration': 'UNRUN',
         'native_execution': 'UNRUN', 'backend_versions_or_runtime_RSS_claimed': False,
         'canonical_source_writes': False, 'git_index_ref_object_writes': False,
         'installation': False, 'children': False, 'cloud_launch': False, 'G_acceptance': 'NOT_ESTABLISHED',
         'scope': 'Only pinned Git objects, own sparse RAW artifacts and current five working preimages were read. No source/index/ref repair, no product import, no test collection/execution.'}
if '--write-self-audit' in sys.argv:
    # Author-only pre-freeze receipt generation; default validation is read-only.
    (OUT / 'self-audit.json').write_text(json.dumps(audit, indent=2) + '\n')
print(json.dumps({'five_postimages': True, 'nine_mutants_AST': True, 'test_definitions': 23,
                  'source_potential_cases': 319, 'runtime': 'UNRUN', 'working_preimages_match': all(working.values())}))
