from __future__ import annotations

import ast
import difflib
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
OUT = ROOT / 'LOCAL/raw/e02-execution-20261027/repairs/V3-rule-owner-reentry-r1'
R1 = ROOT / 'LOCAL/raw/e02-execution-20261027/repairs/V3-world-rule-quantity-r1'
BASE = '2130f07de1eb93316d22bf5f91adc05ded67fbd2'
TREE = 'd67b5b827eb0d0f7286603d2c214c3d68a98675a'
P = 'policy-engine/'
DATA = P + 'src/polisyos/runtime/quality/data_state_substrate.py'
EVAL = P + 'src/polisyos/runtime/quality/acquisition_evaluation.py'
DISPATCH = P + 'src/polisyos/runtime/quality/acquisition_evaluation_dispatch.py'
GROWTH = P + 'src/polisyos/runtime/quality/acquisition_world_growth.py'
N5 = P + 'src/polisyos/runtime/quality/n5_execution_basis.py'
AUTH = P + 'src/polisyos/runtime/quality/agent_action_authority.py'
ACTION = P + 'src/polisyos/runtime/http/services/acquisition_action_service.py'
PORT = P + 'src/polisyos/runtime/http/services/acquisition_surface_execution.py'
HELPER = P + 'tests/_helpers/world_model_record.py'
WORLDTEST = P + 'tests/integration/core_runtime/test_acquisition_world_semantic_preparation.py'
DOC = P + 'src/polisyos/runtime/quality/README.md'
RELEASE = P + 'release-fragments/unreleased/2026-10-29-acquisition-owned-evaluation-retention.toml'
PATHS = (DATA, EVAL, DISPATCH, GROWTH, N5, AUTH, ACTION, PORT, HELPER, WORLDTEST, DOC, RELEASE)
sha = lambda x: hashlib.sha256(x).hexdigest()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == BASE
assert subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, text=True).strip() == TREE
r1 = json.loads((R1 / 'manifest.json').read_text())
assert sha((R1 / 'manifest.json').read_bytes()) == 'a6b5b84501ea533b0e8f8f5bca062b78819933fa5650003a67d63d625ba12de2'
before = {}
after = {}
for path in PATHS:
    raw = (ROOT / path).read_bytes()
    assert raw == subprocess.check_output(['git', 'show', f'{BASE}:{path}'], cwd=ROOT)
    before[path] = raw.decode('utf-8')
    if path in (DATA, HELPER, WORLDTEST):
        post = (R1 / 'postimage' / path).read_bytes()
        assert sha(post) == r1['postimages'][path]['sha256']
        after[path] = post.decode('utf-8')
    else:
        after[path] = before[path]


def replace_one(path: str, original: str, replacement: str) -> None:
    assert after[path].count(original) == 1, (path, original)
    after[path] = after[path].replace(original, replacement, 1)

# Subsequent replacements are source-bound to the exact 2130 preimages.

replace_one(EVAL,
'''PRODUCER = "polisyos.runtime.acquisition_evaluation"
''',
'''PRODUCER = "polisyos.runtime.acquisition_evaluation"

# Readers understand both versions before any new comparison record is emitted.
# Enabling v2 requires the staged old-source/restart compatibility controls.
_COMPARISON_V2_EMITTER_ENABLED = False
_BASIS_V1 = "controlled_acquired_observation_ncm_v1"
_BASIS_V2 = "controlled_acquired_observation_ncm_v2"
type _BasisProfile = Literal[
    "controlled_acquired_observation_ncm_v1", "controlled_acquired_observation_ncm_v2"
]
''')
replace_one(EVAL,
'''    schema_version: Literal["AcquisitionEvaluationBasis@1.0"] = "AcquisitionEvaluationBasis@1.0"
''',
'''    schema_version: Literal["AcquisitionEvaluationBasis@1.0", "AcquisitionEvaluationBasis@1.1"] = (
        "AcquisitionEvaluationBasis@1.0"
    )
''')
replace_one(EVAL,
'''    comparison_profile: Literal["controlled_acquired_observation_ncm_v1"] = (
        "controlled_acquired_observation_ncm_v1"
    )
''',
'''    comparison_profile: _BasisProfile = "controlled_acquired_observation_ncm_v1"
''')
replace_one(EVAL,
'''    def _content(self) -> AcquisitionEvaluationBasis:
        try:
''',
'''    def _content(self) -> AcquisitionEvaluationBasis:
        if (self.schema_version, self.comparison_profile) not in {
            ("AcquisitionEvaluationBasis@1.0", _BASIS_V1),
            ("AcquisitionEvaluationBasis@1.1", _BASIS_V2),
        }:
            raise ValueError("acquisition_evaluation_basis_profile_version_mismatch")
        try:
''')
replace_one(EVAL,
'''    schema_version: Literal["AcquisitionEvaluationDecision@1.0"] = (
        "AcquisitionEvaluationDecision@1.0"
    )
''',
'''    schema_version: Literal[
        "AcquisitionEvaluationDecision@1.0", "AcquisitionEvaluationDecision@1.1"
    ] = "AcquisitionEvaluationDecision@1.0"
''')
replace_one(EVAL,
'''    comparison_rule: Literal["AD-E02-B09-01/owned-complete-native-values/v1"] = (
        "AD-E02-B09-01/owned-complete-native-values/v1"
    )
''',
'''    comparison_rule: Literal[
        "AD-E02-B09-01/owned-complete-native-values/v1",
        "AD-E02-B09-01/owned-complete-native-values/v2",
    ] = "AD-E02-B09-01/owned-complete-native-values/v1"
''')
replace_one(EVAL,
'''    def _content(self) -> AcquisitionEvaluationDecision:
        if self.content_hash != exact_n5_content_hash(
''',
'''    def _content(self) -> AcquisitionEvaluationDecision:
        if (self.schema_version, self.comparison_rule) not in {
            ("AcquisitionEvaluationDecision@1.0", "AD-E02-B09-01/owned-complete-native-values/v1"),
            ("AcquisitionEvaluationDecision@1.1", "AD-E02-B09-01/owned-complete-native-values/v2"),
        }:
            raise ValueError("acquisition_evaluation_decision_rule_version_mismatch")
        if self.content_hash != exact_n5_content_hash(
''')
replace_one(EVAL,
'''    payload = record.model_dump(mode="json")
    identity = record.content_hash.removeprefix("sha256:")
''',
'''    payload = record.model_dump(mode="json")
    version = record.schema_version.rsplit("@", 1)[-1]
    if version == "1.1" and not _COMPARISON_V2_EMITTER_ENABLED:
        raise ValueError("acquisition_evaluation_v2_emitter_disabled")
    identity = record.content_hash.removeprefix("sha256:")
''')
replace_one(EVAL,
'''            schema=artifacts.SchemaInfo(name=record.ARTIFACT_SCHEMA_NAME, version="1.0"),
            producer=artifacts.ProducerInfo(component=PRODUCER, version="1.0"),
''',
'''            schema=artifacts.SchemaInfo(name=record.ARTIFACT_SCHEMA_NAME, version=version),
            producer=artifacts.ProducerInfo(component=PRODUCER, version=version),
''')
replace_one(EVAL,
'''        reader_contract_version="1.0",
''',
'''        reader_contract_version=version,
''')
replace_one(EVAL,
'''        or manifest.artifact_schema.version != "1.0"
        or manifest.producer is None
        or manifest.producer.component != PRODUCER
        or manifest.producer.version != "1.0"
''',
'''        or manifest.artifact_schema.version not in {"1.0", "1.1"}
        or manifest.producer is None
        or manifest.producer.component != PRODUCER
        or manifest.producer.version != manifest.artifact_schema.version
''')
replace_one(EVAL,
'''    record = record_type.model_validate(load_core_json_artifact(store, ref))
    expected_inputs = tuple(
''',
'''    record = record_type.model_validate(load_core_json_artifact(store, ref))
    if record.schema_version.rsplit("@", 1)[-1] != manifest.artifact_schema.version:
        raise ValueError("acquisition_evaluation_artifact_version_mismatch")
    expected_inputs = tuple(
''')
replace_one(EVAL,
'''        left.predicate_provenance == right.predicate_provenance == "recomputed"
        and bytes.fromhex(left.effective_native_values_hex)
''',
'''        left.predicate_provenance == right.predicate_provenance == "recomputed"
        and left.comparison_profile == right.comparison_profile
        and bytes.fromhex(left.effective_native_values_hex)
''')

replace_one(EVAL,
'''    actual_evaluation: bool,
    _historical_read_only: bool = False,
) -> tuple[dict[str, object], tuple[str, ...]]:
''',
'''    actual_evaluation: bool,
    _historical_read_only: bool = False,
    _comparison_profile: _BasisProfile = "controlled_acquired_observation_ncm_v1",
) -> tuple[dict[str, object], tuple[str, ...]]:
''')
replace_one(EVAL,
'''    from polisyos.foundry.data_plane import load_input_bindings
    from polisyos.foundry.execute import load_state_snapshot, state_snapshot_value_projection
''',
'''    from polisyos.foundry.data_plane import load_input_bindings, prepare_input_bindings
    from polisyos.foundry.execute import load_state_snapshot, state_snapshot_value_projection
''')
replace_one(EVAL,
'''    if type(prepared) is not AcquisitionCandidatePreparation:
        raise TypeError("acquisition_evaluation_preparation_not_owner_typed")
    reasons: list[str] = []
''',
'''    if type(prepared) is not AcquisitionCandidatePreparation:
        raise TypeError("acquisition_evaluation_preparation_not_owner_typed")
    if _comparison_profile not in {_BASIS_V1, _BASIS_V2}:
        raise ValueError("acquisition_evaluation_comparison_profile_unsupported")
    reasons: list[str] = []
''')
replace_one(EVAL,
'''            rules = list(bindings.rules)
            effective_rule = observation["binding_rule"]
''',
'''            if _comparison_profile == _BASIS_V2:
                owner_preparation = prepare_input_bindings(
                    bridge.artifact_store,
                    data_snapshot_ref=views.data_snapshot_ref,
                    registry_bundle_ref=views.registry_bundle_ref,
                    rules=list(bindings.rules),
                )
                if state_snapshot_value_projection(owner_preparation.materialized_state) != (
                    state_snapshot_value_projection(state)
                ):
                    raise ValueError("acquisition_evaluation_binding_state_mismatch")
                rules = list(owner_preparation.effective_rules)
            else:
                rules = list(bindings.rules)
            effective_rule = observation["binding_rule"]
''')
replace_one(EVAL,
'''        if world["predicate_provenance"] != "recomputed":
            reasons.extend(str(reason) for reason in world["reason_codes"])
        # Verify the exact owner rule before replacing its generated report
''',
'''        if world["predicate_provenance"] != "recomputed":
            reasons.extend(str(reason) for reason in world["reason_codes"])
        elif _comparison_profile == _BASIS_V1:
            # Frozen v1 computation for freshly emitted legacy records only.
            # This is not proof that an older artifact used this source law.
            from polisyos.runtime.quality.data_state_substrate import (
                _effective_acquired_world_rules,
                _prepare_acquired_observation_world,
            )

            if actual_evaluation:
                legacy_rules = tuple(bindings.rules)
            else:
                legacy_rules = _prepare_acquired_observation_world(
                    bridge.artifact_store,
                    base_world_model_record=prepared.base_world,
                    acquired_rule=owned_rule,
                    registry_bundle_ref=world_model_artifact_views(
                        prepared.base_world
                    ).registry_bundle_ref,
                    substrate_registry=prepared.configured_profile.context_inputs.substrate_registry,
                ).rules
            legacy_world = dict(world["effective_values"])
            legacy_world["rules"] = _effective_acquired_world_rules(legacy_rules, owned_rule)
            world = {**world, "effective_values": legacy_world}
        # Verify the exact owner rule before replacing its generated report
''')
replace_one(EVAL,
'''    """Issue only after actual owner recomputation; unsupported facets stay typed."""
    values, reasons = recompute_acquisition_basis_values(
''',
'''    """Issue only after actual owner recomputation; unsupported facets stay typed."""
    profile: _BasisProfile = _BASIS_V2 if _COMPARISON_V2_EMITTER_ENABLED else _BASIS_V1
    values, reasons = recompute_acquisition_basis_values(
''')
replace_one(EVAL,
'''        prior=prior,
        actual_evaluation=actual_evaluation,
    )
    from polisyos.runtime.quality.acquisition_world_growth import AcquisitionCandidatePreparation
''',
'''        prior=prior,
        actual_evaluation=actual_evaluation,
        _comparison_profile=profile,
    )
    from polisyos.runtime.quality.acquisition_world_growth import AcquisitionCandidatePreparation
''')
replace_one(EVAL,
'''        "schema_version": "AcquisitionEvaluationBasis@1.0",
        "authority_purpose": "candidate_evaluation_retention_only",
        "comparison_profile": "controlled_acquired_observation_ncm_v1",
''',
'''        "schema_version": (
            "AcquisitionEvaluationBasis@1.1" if profile == _BASIS_V2
            else "AcquisitionEvaluationBasis@1.0"
        ),
        "authority_purpose": "candidate_evaluation_retention_only",
        "comparison_profile": profile,
''')
replace_one(EVAL,
'''    del control_service  # No present lease/configuration is used as a historical permit.
    selected = prior_evaluation.selected
''',
'''    del control_service  # No present lease/configuration is used as a historical permit.
    # v1 records have no comparator-source witness. Their exact artifact bytes
    # remain readable, but replay cannot silently attribute the current source
    # law to every historical issuance.
    if basis.comparison_profile == _BASIS_V1:
        raise ValueError("acquisition_historical_v1_comparator_source_not_established")
    selected = prior_evaluation.selected
''')
replace_one(EVAL,
'''        actual_evaluation=basis.evaluation is not None,
        _historical_read_only=True,
''',
'''        actual_evaluation=basis.evaluation is not None,
        _historical_read_only=True,
        _comparison_profile=basis.comparison_profile,
''')

# Reuse the existing exact replay verifier without invoking the effect adapter.
replace_one(AUTH,
'''    def execute_bound_effect(
        self,
        *,
        operation: OperationContract,
        invocation: OperationInvocationRecord,
        intent: AgentActionIntent,
        persisted: PersistedAgentActionDecision,
    ) -> object:
        """Revalidate owner inputs and execute only the sealed, exact adapter binding."""

        decision = self._revalidate_persisted_decision(persisted)
''',
'''    def verify_bound_effect(
        self,
        *,
        operation: OperationContract,
        invocation: OperationInvocationRecord,
        intent: AgentActionIntent,
        persisted: PersistedAgentActionDecision,
    ) -> AgentActionEffectBinding:
        """Revalidate the exact action and live owner facts without invoking its adapter."""

        decision = self._revalidate_persisted_decision(persisted)
''')
replace_one(AUTH,
'''        return binding.handler(invocation)

    def _revalidate_persisted_decision(
''',
'''        return binding

    def execute_bound_effect(
        self,
        *,
        operation: OperationContract,
        invocation: OperationInvocationRecord,
        intent: AgentActionIntent,
        persisted: PersistedAgentActionDecision,
    ) -> object:
        """Revalidate owner inputs and execute only the sealed, exact adapter binding."""
        binding = self.verify_bound_effect(
            operation=operation, invocation=invocation, intent=intent, persisted=persisted
        )
        return binding.handler(invocation)

    def _revalidate_persisted_decision(
''')
replace_one(ACTION,
'''        return port.complete_positive_admission(closure)

    def _consume_movement(self, receipt_ref: str) -> None:
''',
'''        return port.complete_positive_admission(closure, action_service=self)

    def _revalidate_semantic_reentry_authority(
        self,
        *,
        closure: VerifiedAcquisitionRouteClosure,
        expected_decision_ref: str,
    ) -> None:
        """Reopen the real worker's action and live mandate without a provider effect."""
        if not self._production_execution_bridge_installed():
            raise AcquisitionActionServiceError("acquisition_reentry_owner_not_composed")
        control = self.control_service
        admission = control._control_store.current_execution_job_admission()
        job, scope = admission.job, admission.scope
        if (
            job.kind != "acquisition"
            or job.run_id != closure.run_id
            or not job.payload_ref
            or scope.status != "established"
            or (scope.tenant_id, scope.cell_id) != (closure.tenant_id, closure.cell_id)
        ):
            raise AcquisitionActionServiceError("acquisition_reentry_job_scope_changed")
        payload = control._load_payload_ref(
            job.payload_ref, kind="runtime.control_job_payload.acquisition"
        )
        payload = control._payload_for_execution_scope(payload, job=job, execution_scope=scope)
        request = AcquisitionRouteMutationRequest.model_validate(payload.get("request"))
        current = self._validated_mutation(
            tenant_id=closure.tenant_id,
            cell_id=closure.cell_id,
            run_id=closure.run_id,
            route_id=str(payload.get("route_id") or ""),
            request=request,
        )
        operation, invocation, intent = self._action_tuple(current.closure, request)
        if (
            current.job_id != job.job_id
            or current.closure != closure
            or payload.get("decision_ref") != expected_decision_ref
            or OperationContract.model_validate(payload.get("operation")) != operation
            or OperationInvocationRecord.model_validate(payload.get("invocation")) != invocation
            or AgentActionIntent.model_validate(payload.get("intent")) != intent
        ):
            raise AcquisitionActionServiceError("acquisition_reentry_action_binding_changed")

        def _no_effect(_invocation: OperationInvocationRecord) -> object:
            raise RuntimeError("reentry verification cannot invoke a provider effect")

        gateway = self._require_authority_provider().for_job(
            closure=closure,
            request=request,
            job_id=job.job_id,
            decision_ref=expected_decision_ref,
            effect_handler=_no_effect,
        )
        persisted = gateway.load_persisted_decision(expected_decision_ref)
        gateway.verify_bound_effect(
            operation=operation, invocation=invocation, intent=intent, persisted=persisted
        )

    def _consume_movement(self, receipt_ref: str) -> None:
''')
replace_one(PORT,
'''    def complete_positive_admission(
        self,
        closure: VerifiedAcquisitionRouteClosure,
    ) -> AcquisitionActionHeadRecord | None:
''',
'''    def complete_positive_admission(
        self,
        closure: VerifiedAcquisitionRouteClosure,
        *,
        action_service: object,
    ) -> AcquisitionActionHeadRecord | None:
''')
replace_one(PORT,
'''        return complete_positive_acquisition_admission(self._world_growth_bridge, closure)
''',
'''        return complete_positive_acquisition_admission(
            self._world_growth_bridge, closure, action_service=action_service
        )
''')

replace_one(GROWTH,
'''        prepared_n5_configuration: PreparedJointSimulationConfiguration | None = None,
    ) -> str:
        """Read verified native activation and enter the original case at the next cycle."""
''',
'''        prepared_n5_configuration: PreparedJointSimulationConfiguration | None = None,
        reentry_owner: object | None = None,
    ) -> str:
        """Read verified native activation and enter the original case at the next cycle."""
''')
replace_one(GROWTH,
'''        _require_promotion_runtime_store_binding(self.promotion_runtime, self.artifact_store)
        current_action_job_id: str | None = None
''',
'''        _require_promotion_runtime_store_binding(self.promotion_runtime, self.artifact_store)
        if reentry_owner is not None:
            from polisyos.runtime.quality.acquisition_evaluation_dispatch import (
                AcquisitionReentryCurrentOwner,
            )

            if type(reentry_owner) is not AcquisitionReentryCurrentOwner or reentry_owner.bridge is not self:
                raise ValueError("acquisition_reentry_current_owner_unbound")
            reentry_owner.revalidate()
        current_action_job_id: str | None = None
''')
replace_one(GROWTH,
'''                    n5_execution_configuration=prepared_n5_configuration,
                )
                controller_kwargs = {
''',
'''                    n5_execution_configuration=prepared_n5_configuration,
                    reentry_owner=reentry_owner,
                )
                controller_kwargs = {
''')
replace_one(GROWTH,
'''            receipt = async_tools.run_coro_sync(
                controller.reenter_after_active_acquisition_overlay(
''',
'''            from polisyos.runtime.quality.n5_execution_basis import require_reentry_n5_preflight

            with require_reentry_n5_preflight(enabled=reentry_owner is not None):
                receipt = async_tools.run_coro_sync(
                    controller.reenter_after_active_acquisition_overlay(
''')
replace_one(GROWTH,
'''                    ),
                )
            )
            # No copied-context borrowing is permitted. Re-read complete owner
''',
'''                    ),
                    )
                )
            # No copied-context borrowing is permitted. Re-read complete owner
''')
replace_one(GROWTH,
'''        refresh: AcquisitionCandidateWorldRefresh,
        n5_execution_configuration: PreparedJointSimulationConfiguration | None = None,
    ) -> AcquisitionCandidatePreparation:
''',
'''        refresh: AcquisitionCandidateWorldRefresh,
        n5_execution_configuration: PreparedJointSimulationConfiguration | None = None,
        transaction_time: datetime | None = None,
    ) -> AcquisitionCandidatePreparation:
''')
replace_one(GROWTH,
'''        transaction_time = datetime.now(UTC)
        preparation = prepare_acquired_observation_snapshot(
''',
'''        if transaction_time is None:
            transaction_time = datetime.now(UTC)
        preparation = prepare_acquired_observation_snapshot(
''')
replace_one(GROWTH,
'''        refresh: AcquisitionCandidateWorldRefresh,
        n5_execution_configuration: PreparedJointSimulationConfiguration | None = None,
    ) -> tuple[object, object, object]:
''',
'''        refresh: AcquisitionCandidateWorldRefresh,
        n5_execution_configuration: PreparedJointSimulationConfiguration | None = None,
        reentry_owner: object | None = None,
    ) -> tuple[object, object, object]:
''')
replace_one(GROWTH,
'''            refresh=refresh,
            n5_execution_configuration=n5_execution_configuration,
        )
        if n5_execution_configuration is not None and prepared.n5_execution_configuration is None:
''',
'''            refresh=refresh,
            n5_execution_configuration=n5_execution_configuration,
            transaction_time=(
                reentry_owner.selection.prepared.transaction_time if reentry_owner is not None else None
            ),
        )
        if reentry_owner is not None:
            reentry_owner.revalidate()
            require_same_candidate_preparation(reentry_owner.selection.prepared, prepared)
        if n5_execution_configuration is not None and prepared.n5_execution_configuration is None:
''')
replace_one(GROWTH,
'''            try:
                current_job_record = control_store.current_execution_job_record()
''',
'''            try:
                if reentry_owner is not None:
                    reentry_owner.revalidate()
                current_job_record = control_store.current_execution_job_record()
''')
replace_one(GROWTH,
'''        from polisyos.foundry.data_plane import InputBindingValuesPreparation, load_input_bindings
''',
'''        from polisyos.foundry.data_plane import (
            InputBindingValuesPreparation,
            load_input_bindings,
            prepare_input_bindings,
        )
''')
replace_one(GROWTH,
'''        if actual_bindings.rules != list(prospective_values.effective_rules):
            raise ValueError("acquisition_prospective_rule_owner_reconciliation_failed")

    @staticmethod
''',
'''        replayed = prepare_input_bindings(
            self.artifact_store,
            data_snapshot_ref=actual_world_views.data_snapshot_ref,
            registry_bundle_ref=actual_world_views.registry_bundle_ref,
            rules=list(actual_bindings.rules),
        )
        if (
            replayed.effective_rules != prospective_values.effective_rules
            or replayed.applied_binding_ids != prospective_values.applied_binding_ids
            or replayed.warnings != prospective_values.warnings
            or state_snapshot_value_projection(replayed.materialized_state)
            != state_snapshot_value_projection(actual_state)
        ):
            raise ValueError("acquisition_prospective_rule_owner_reconciliation_failed")

    @staticmethod
''')
# This comparator covers every preparation field. Job fields not consumed by
# the plan are instead rechecked by the active-lease owner on every use.
replace_one(GROWTH,
'''class AcquisitionWorldGrowthBridge:
''',
'''def require_same_candidate_preparation(
    expected: AcquisitionCandidatePreparation, actual: AcquisitionCandidatePreparation
) -> None:
    """Require the complete freshly prepared plan, with the live lease independently checked."""
    from dataclasses import fields

    from polisyos.foundry.execute import state_snapshot_value_projection
    from polisyos.runtime.quality.n5_execution_basis import exact_n5_content_bytes

    if type(expected) is not AcquisitionCandidatePreparation or type(actual) is not AcquisitionCandidatePreparation:
        raise TypeError("acquisition_reentry_preparation_untyped")
    for field in fields(expected):
        left, right = getattr(expected, field.name), getattr(actual, field.name)
        if field.name == "current_job":
            # These are the only job fields consumed by the handoff; owner,
            # attempt and expiration are enforced by current_execution_job_record.
            equal = (left.job_id, left.run_id) == (right.job_id, right.run_id)
        elif field.name == "workspace_dir":
            equal = left == right
        elif field.name == "prospective_values":
            equal = all(
                state_snapshot_value_projection(getattr(left, item.name))
                == state_snapshot_value_projection(getattr(right, item.name))
                if item.name == "materialized_state"
                else exact_n5_content_bytes(getattr(left, item.name))
                == exact_n5_content_bytes(getattr(right, item.name))
                for item in fields(left)
            ) and type(left) is type(right)
        else:
            equal = exact_n5_content_bytes(left) == exact_n5_content_bytes(right)
        if not equal:
            raise ValueError("acquisition_reentry_preparation_changed:" + field.name)


class AcquisitionWorldGrowthBridge:
''')

replace_one(N5,
'''class N5ImplementationCapture:
''',
'''_REENTRY_N5_PREFLIGHT: ContextVar[bool] = ContextVar(
    "polisyos_reentry_n5_preflight", default=False
)


@contextmanager
def require_reentry_n5_preflight(*, enabled: bool) -> Iterator[None]:
    """Require the actual selected implementation to resolve before reentry numerics."""
    token = _REENTRY_N5_PREFLIGHT.set(enabled)
    try:
        yield
    finally:
        _REENTRY_N5_PREFLIGHT.reset(token)


class N5ImplementationCapture:
''')
replace_one(N5,
'''            self._reasons.append("n5_selected_implementation_or_input_unsupported")
            return self
''',
'''            self._reasons.append("n5_selected_implementation_or_input_unsupported")
            if _REENTRY_N5_PREFLIGHT.get():
                raise ValueError("n5_reentry_implementation_preflight_not_established")
            return self
''')
replace_one(N5,
'''            self._reasons.append(self._observer.reason or "n5_execution_observer_not_active")
            return self
''',
'''            self._reasons.append(self._observer.reason or "n5_execution_observer_not_active")
            if _REENTRY_N5_PREFLIGHT.get():
                raise ValueError("n5_reentry_implementation_preflight_not_established")
            return self
''')
replace_one(N5,
'''        except (OSError, TypeError, ValueError, RuntimeError) as exc:
            self._reasons.append(str(getattr(exc, "code", None) or exc))
        finally:
            self._observer.suspended = False
        return self
''',
'''        except (OSError, TypeError, ValueError, RuntimeError) as exc:
            self._reasons.append(str(getattr(exc, "code", None) or exc))
            if _REENTRY_N5_PREFLIGHT.get():
                raise ValueError("n5_reentry_implementation_preflight_not_established") from exc
        finally:
            self._observer.suspended = False
        return self
''')

replace_one(DISPATCH,
'''from polisyos.runtime.quality.acquisition_evaluation import (
    AcquisitionEvaluationBasis,
''',
'''from polisyos.runtime.quality.acquisition_evaluation import (
    AcquisitionBasisPreparationInputs,
    AcquisitionEvaluationBasis,
''')
replace_one(DISPATCH,
'''    read_acquisition_evaluation_artifact,
    replay_acquisition_basis_for_history,
''',
'''    read_acquisition_evaluation_artifact,
    recompute_acquisition_basis_values,
    replay_acquisition_basis_for_history,
''')
replace_one(DISPATCH,
'''    AcquisitionWorldGrowthReceipt,
)
''',
'''    AcquisitionWorldGrowthReceipt,
    require_same_candidate_preparation,
)
''')
replace_one(DISPATCH,
'''def _current_selection(bridge: AcquisitionWorldGrowthBridge) -> _CurrentSelection:
''',
'''def _current_selection(
    bridge: AcquisitionWorldGrowthBridge, *, transaction_time: datetime | None = None
) -> _CurrentSelection:
''')
replace_one(DISPATCH,
'''        observation_projection=projection,
        refresh=refreshes[0],
    )
''',
'''        observation_projection=projection,
        refresh=refreshes[0],
        transaction_time=transaction_time,
    )
''')
replace_one(DISPATCH,
'''    if (
        old_basis.predicate_provenance != "recomputed"
''',
'''    if old_basis.comparison_profile != current.comparison_profile:
        return (
            current, old_ref, selected, "not_established",
            ("acquisition_comparison_profile_relation_not_established",), frontier, prior,
        )
    if (
        old_basis.predicate_provenance != "recomputed"
''')
replace_one(DISPATCH,
'''    closure = selection.closure
    payload = {
        "schema_version": "AcquisitionEvaluationDecision@1.0",
        "authority_purpose": "candidate_evaluation_retention_only",
        "comparison_rule": "AD-E02-B09-01/owned-complete-native-values/v1",
''',
'''    from polisyos.runtime.quality import acquisition_evaluation

    closure = selection.closure
    v2 = acquisition_evaluation._COMPARISON_V2_EMITTER_ENABLED
    payload = {
        "schema_version": "AcquisitionEvaluationDecision@1.1" if v2 else "AcquisitionEvaluationDecision@1.0",
        "authority_purpose": "candidate_evaluation_retention_only",
        "comparison_rule": (
            "AD-E02-B09-01/owned-complete-native-values/v2" if v2
            else "AD-E02-B09-01/owned-complete-native-values/v1"
        ),
''')
replace_one(DISPATCH,
'''    prior: ResolvedAcquisitionEvaluation | None

    def revalidate(self) -> _CurrentSelection:
        """Recompute source/lease/basis rather than accepting a currentness flag."""
        current = _current_selection(self.bridge)
''',
'''    prior: ResolvedAcquisitionEvaluation | None
    action_service: object

    def revalidate(self) -> _CurrentSelection:
        """Recompute source/lease/basis rather than accepting a currentness flag."""
        _require_current_action_authority(self.action_service, self.bridge, self.selection)
        current = _current_selection(self.bridge)
''')
replace_one(DISPATCH,
'''            or record.predicate_provenance != replay.predicate_provenance
''',
'''            or record.comparison_profile != replay.comparison_profile
            or record.predicate_provenance != replay.predicate_provenance
''')
replace_one(DISPATCH,
'''@dataclass(frozen=True)
class _TerminalScope:
    owner: AcquisitionEvaluationCurrentOwner
''',
'''def _require_current_action_authority(
    service: object, bridge: AcquisitionWorldGrowthBridge, selection: _CurrentSelection
) -> None:
    from polisyos.runtime.http.services.acquisition_action_service import AcquisitionActionService
    from polisyos.runtime.http.services.acquisition_surface_execution import (
        WorldBankWDIAcquisitionExecutionPort,
    )

    if type(service) is not AcquisitionActionService:
        raise ValueError("acquisition_reentry_action_service_not_owned")
    port = service._production_execution_port
    if (
        service.control_service is not bridge._source_control_service
        or type(port) is not WorldBankWDIAcquisitionExecutionPort
        or service._execution_port is not port
        or port._world_growth_bridge is not bridge
    ):
        raise ValueError("acquisition_reentry_action_service_not_composed")
    service._revalidate_semantic_reentry_authority(
        closure=selection.closure, expected_decision_ref=selection.phase.decision_ref
    )


@dataclass(frozen=True)
class AcquisitionReentryCurrentOwner:
    """Purpose-specific current owner; it can reenter but never retain prior N5."""

    bridge: AcquisitionWorldGrowthBridge
    action_service: object
    selection: _CurrentSelection
    decision: AcquisitionEvaluationDecision
    prior: ResolvedAcquisitionEvaluation | None

    def revalidate(self) -> _CurrentSelection:
        """Recompute live guards and the complete consumed plan before actual reentry."""
        _require_current_action_authority(self.action_service, self.bridge, self.selection)
        current = _current_selection(
            self.bridge, transaction_time=self.selection.prepared.transaction_time
        )
        if (
            current.phase_ref != self.selection.phase_ref
            or current.growth_ref != self.selection.growth_ref
            or current.growth != self.selection.growth
            or current.projection != self.selection.projection
            or current.closure != self.selection.closure
            or current.action_generation != self.selection.action_generation
            or current.action_job_id != self.selection.action_job_id
            or current.admitted_source_ref != self.selection.admitted_source_ref
        ):
            raise ValueError("acquisition_reentry_current_selection_changed")
        _saved_execution_configuration(self.bridge, current, self.decision)
        require_same_candidate_preparation(self.selection.prepared, current.prepared)
        basis = read_acquisition_evaluation_artifact(
            store=self.bridge.artifact_store,
            event_log=self.bridge.event_log,
            ref=self.decision.current_basis_ref,
            record_type=AcquisitionEvaluationBasis,
        )
        if type(basis) is not AcquisitionEvaluationBasis:
            raise ValueError("acquisition_reentry_saved_basis_unverified")
        prepared = current.prepared
        selectors = AcquisitionBasisPreparationInputs(
            configured_profile=prepared.configured_profile,
            original_model_declaration=prepared.prospective_model.original_declaration,
            base_data_snapshot_ref=prepared.preparation.base_data_snapshot_ref,
            receipt_ref=prepared.preparation.receipt_ref,
            passport_ref=prepared.preparation.observation_projection.passport_ref,
            boundary_candidate_ref=prepared.passport.semantic_boundary_candidate_ref,
            source_ref=current.admitted_source_ref,
            observation_id=prepared.preparation.selected_observation_id,
            slot_binding=prepared.preparation.selected_profile,
            transaction_time=prepared.transaction_time.isoformat(),
            preparation_job_id=prepared.current_job.job_id,
            n5_execution_configuration=prepared.n5_execution_configuration,
            n5_configuration_reason_codes=prepared.n5_configuration_reason_codes,
        )
        if exact_n5_content_bytes(selectors) != exact_n5_content_bytes(basis.preparation_inputs):
            raise ValueError("acquisition_reentry_saved_plan_inputs_changed")
        # Recompute the complete current plan; old N5 bytes are read only as a
        # historical input to the saved plan, never as permission for retention.
        values, reasons = recompute_acquisition_basis_values(
            bridge=self.bridge,
            closure=current.closure,
            prepared=prepared,
            prior=self.prior,
            actual_evaluation=False,
            _historical_read_only=True,
            _comparison_profile=basis.comparison_profile,
        )
        if (
            basis.predicate_provenance != "recomputed"
            or reasons
            or exact_n5_content_bytes(values) != bytes.fromhex(basis.effective_native_values_hex)
        ):
            raise ValueError("acquisition_reentry_saved_complete_plan_not_established")
        return current


@dataclass(frozen=True)
class _TerminalScope:
    owner: AcquisitionEvaluationCurrentOwner | AcquisitionReentryCurrentOwner
''')
replace_one(DISPATCH,
'''        or type(scope.owner) is not AcquisitionEvaluationCurrentOwner
        or scope.owner.bridge.artifact_store is not artifact_store
''',
'''        or (
            terminal.terminal_outcome == "source_admitted_evaluation_retained"
            and type(scope.owner) is not AcquisitionEvaluationCurrentOwner
        )
        or (
            terminal.terminal_outcome == "reentry_completed"
            and type(scope.owner) is not AcquisitionReentryCurrentOwner
        )
        or terminal.terminal_outcome not in {"source_admitted_evaluation_retained", "reentry_completed"}
        or scope.owner.bridge.artifact_store is not artifact_store
''')
replace_one(DISPATCH,
'''    closure: VerifiedAcquisitionRouteClosure,
) -> AcquisitionActionHeadRecord | None:
    """Perform one durable source reaction, conservatively re-entering unknown profiles.
''',
'''    closure: VerifiedAcquisitionRouteClosure,
    *,
    action_service: object,
) -> AcquisitionActionHeadRecord | None:
    """Perform one durable source reaction, conservatively re-entering unknown profiles.
''')
replace_one(DISPATCH,
'''        if str(exc) in {
            "acquisition_evaluation_controlled_refresh_not_supported",
            "acquisition_evaluation_source_view_not_established",
        }:
            return None
        raise
''',
'''        if str(exc) in {
            "acquisition_evaluation_controlled_refresh_not_supported",
            "acquisition_evaluation_source_view_not_established",
        }:
            from polisyos.runtime.http.errors import RuntimeDependencyError

            raise RuntimeDependencyError(
                dependency="acquisition_evaluation_preparation",
                status_code=503,
                code="acquisition_evaluation_preparation_not_established",
                detail=str(exc),
                retry_state="selected_admission_requires_supported_preparation",
            ) from exc
        raise
''')
replace_one(DISPATCH,
'''        current_basis_ref = decision.current_basis_ref
    else:
        current, old_ref, old_selected, comparison, reasons, frontier, prior = _comparison(
''',
'''        current_basis_ref = decision.current_basis_ref
        saved_basis = read_acquisition_evaluation_artifact(
            store=bridge.artifact_store,
            event_log=bridge.event_log,
            ref=current_basis_ref,
            record_type=AcquisitionEvaluationBasis,
        )
        if type(saved_basis) is not AcquisitionEvaluationBasis:
            raise ValueError("acquisition_reentry_saved_basis_unverified")
        selection = _current_selection(
            bridge, transaction_time=datetime.fromisoformat(saved_basis.preparation_inputs.transaction_time)
        )
    else:
        from polisyos.runtime.quality import acquisition_evaluation
        from polisyos.runtime.http.errors import RuntimeDependencyError

        if not acquisition_evaluation._COMPARISON_V2_EMITTER_ENABLED:
            raise RuntimeDependencyError(
                dependency="acquisition_evaluation_comparison_v2",
                status_code=503,
                code="acquisition_evaluation_comparison_v2_not_enabled",
                detail="The versioned comparison writer is disabled until compatibility controls pass.",
                retry_state="selected_admission_requires_comparison_writer",
            )
        current, old_ref, old_selected, comparison, reasons, frontier, prior = _comparison(
''')
replace_one(DISPATCH,
'''                    selection,
                    prior,
                )
                owner.revalidate()
''',
'''                    selection,
                    prior,
                    action_service,
                )
                owner.revalidate()
''')
replace_one(DISPATCH,
'''    AcquisitionEvaluationCurrentOwner(
        bridge,
        current_basis_ref,
        selection,
        prior,
    ).revalidate()
    reentry_ref = bridge.resume(
        closure,
        pending.owner_receipt_refs,
        prepared_n5_configuration=prepared_configuration,
    )
''',
'''    reentry_owner = AcquisitionReentryCurrentOwner(
        bridge, action_service, selection, decision, prior
    )
    reentry_owner.revalidate()
    reentry_ref = bridge.resume(
        closure,
        pending.owner_receipt_refs,
        prepared_n5_configuration=prepared_configuration,
        reentry_owner=reentry_owner,
    )
''')
replace_one(DISPATCH,
'''        owner = AcquisitionEvaluationCurrentOwner(bridge, current_basis_ref, selection, prior)
        owner.revalidate()
        terminal = _terminal_record(
''',
'''        owner = reentry_owner
        owner.revalidate()
        terminal = _terminal_record(
''')

replace_one(DISPATCH,
'''    try:
        selection = _current_selection(bridge)
''',
'''    # A pending legacy action without an evaluation decision is already an
    # owned old lifecycle; preserve its original recovery instead of inventing
    # a semantic basis or routing it through a new comparison.
    early = bridge.action_head_sink.current_action_outcome(
        tenant_id=closure.tenant_id,
        cell_id=closure.cell_id,
        run_id=closure.run_id,
        source_job_id=closure.source_job_id,
        route_id=closure.route_id,
    )
    if early is not None and early.head.receipt_phase == "world_committed_reentry_pending":
        phase = early.latest_receipt
        if not isinstance(phase, AcquisitionRoutePhaseReceipt):
            raise ValueError("acquisition_evaluation_pending_owner_not_established")
        if not any(
            bridge.artifact_store.get_manifest(ref).kind
            == "runtime_quality.acquisition_evaluation_decision"
            for ref in phase.owner_receipt_refs
        ):
            return None
    try:
        selection = _current_selection(bridge)
''')

replace_one(DISPATCH,
'''def _require_current_action_authority(
    service: object, bridge: AcquisitionWorldGrowthBridge, selection: _CurrentSelection
) -> None:
''',
'''def _require_current_action_authority(
    service: object,
    bridge: AcquisitionWorldGrowthBridge,
    closure: VerifiedAcquisitionRouteClosure,
    phase: AcquisitionRoutePhaseReceipt,
) -> None:
''')
replace_one(DISPATCH,
'''        closure=selection.closure, expected_decision_ref=selection.phase.decision_ref
''',
'''        closure=closure, expected_decision_ref=phase.decision_ref
''')
old_call = "        _require_current_action_authority(self.action_service, self.bridge, self.selection)\n"
new_call = ("        _require_current_action_authority(\n"
            "            self.action_service, self.bridge, self.selection.closure, self.selection.phase\n"
            "        )\n")
assert after[DISPATCH].count(old_call) == 2
after[DISPATCH] = after[DISPATCH].replace(old_call, new_call)
replace_one(DISPATCH,
'''        ):
            return None
    try:
        selection = _current_selection(bridge)
''',
'''        ):
            _require_current_action_authority(action_service, bridge, closure, phase)
            return None
    try:
        selection = _current_selection(bridge)
''')

# Only a mutable draft is emitted here. It is not a review/freeze manifest.
draft = OUT / 'DRAFT-NOT-READY'
draft.mkdir(exist_ok=True)
patch_parts = []
for path in PATHS:
    if path.endswith('.py'):
        ast.parse(after[path], filename=path)
    target = draft / 'postimage' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(after[path])
    patch_parts += list(difflib.unified_diff(
        before[path].splitlines(keepends=True), after[path].splitlines(keepends=True),
        fromfile='a/' + path, tofile='b/' + path,
    ))
(draft / 'proposal.patch').write_text(''.join(patch_parts))
print('DRAFT ONLY: AST parse completed for', len(PATHS), 'paths; no product imports/tests')
