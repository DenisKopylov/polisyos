"""Prepare source-bound removal recipes; never import or execute product code."""
from pathlib import Path
import ast,hashlib,json
ROOT=Path.cwd(); OUT=ROOT/'LOCAL/raw/e02-execution-20261027/repairs/C38-tests-r1'
SRC=ROOT/'LOCAL/raw/e02-execution-20261027/repairs/C38-r3/postimages'
def record(path,symbol,mode,old,new,selector,reason):
    raw=(SRC/path).read_bytes(); text=raw.decode()
    module=ast.parse(raw)
    nodes=[n for n in ast.walk(module) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==symbol]
    assert len(nodes)==1,(symbol,len(nodes))
    node=nodes[0]
    lines=text.splitlines(True)
    if mode=='after_docstring':
        first=node.body[0]; assert isinstance(first,ast.Expr) and isinstance(first.value,ast.Constant) and isinstance(first.value.value,str)
        at=first.end_lineno; indent=' ' * (node.col_offset+4)
        mutated=''.join(lines[:at])+indent+'return ()\n'+''.join(lines[at:]) if symbol=='_envelope_authority_admission_blockers' else ''.join(lines[:at])+indent+'return\n'+''.join(lines[at:])
    else:
        part=''.join(lines[node.lineno-1:node.end_lineno]);assert part.count(old)==1,(symbol,part.count(old))
        newpart=part.replace(old,new,1)
        mutated=''.join(lines[:node.lineno-1])+newpart+''.join(lines[node.end_lineno:])
    ast.parse(mutated,filename=path)
    return {'source_path':path,'source_sha256':hashlib.sha256(raw).hexdigest(),'function':symbol,'mutation_mode':mode,'old':old,'new':new,'mutant_sha256':hashlib.sha256(mutated.encode()).hexdigest(),'pytest_selector':selector,'expected':'nonzero assertion failure; retain complete stdout/stderr/JUnit and actual loaded-code custody','property':reason,'executed':False}
AUTH='policy-engine/src/polisyos/runtime/quality/authority.py'; NL='policy-engine/src/polisyos/runtime/http/services/control/nl_pipeline.py'
items=[record(AUTH,'_envelope_authority_admission_blockers','after_docstring',None,None,'tests/unit/runtime/quality/test_closure_authority_withdrawal.py::test_no_declared_role_can_borrow_a_positive_publication_boundary','Keep boundary/role strings and helper, remove only shared positive-purpose admission.'),record(AUTH,'_assert_closed_consumed_input_closure','after_docstring',None,None,'tests/unit/runtime/quality/test_authority.py::test_runtime_envelope_round_trips_as_legacy_without_new_authority','Retain closed/hash markers but remove closed-input protected admission; legacy role/assertion must expose forbidden positive.'),record(NL,'_load_json_artifact_payload','replace','isinstance(ref_value, ArtifactRef)','type(ref_value) is ArtifactRef','tests/unit/runtime/http/test_nl_selected_read_observation.py::test_actual_selected_helper_read_persists_diagnostic_facts_to_fresh_job_surface[real-subclass]','Real DataSnapshotRef profile A must remain A when default profile B exists.'),record(NL,'_load_json_artifact_payload','replace','runtime_quality_selected_reads.append(observation)','if False:\n                    runtime_quality_selected_reads.append(observation)','tests/unit/runtime/http/test_nl_selected_read_observation.py::test_actual_selected_helper_read_persists_diagnostic_facts_to_fresh_job_surface','Retain observation type/fields, remove actual append after selected read; fresh durable surface must lose the real facts.'),record(NL,'_emit_job_progress','replace','if runtime_quality_selected_reads:','if False and runtime_quality_selected_reads:','tests/unit/runtime/http/test_nl_selected_read_observation.py::test_actual_selected_helper_read_persists_diagnostic_facts_to_fresh_job_surface','Retain actual local read records and event details, remove only progress persistence; fresh job surface must fail.')]
(OUT/'removal-plan.json').write_text(json.dumps({'schema':'policyos.c38_source_bound_removal_plan.v1','source_manifest_sha256':'4a40acfb3151e532d71b23cd87557dd76932d0f4992dbedc3b07425ac7d6af16','runtime':'UNRUN','controls':items,'upstream_blocked':['Later scorecard same-input comparison has no positive issuer; removing it alone may leave correct upstream refusal. Do not fake an issuer or mock CAS to force its witness.']},indent=2)+'\n')
print('Prepared five syntax-checked source-bound removal recipes; none executed.')
