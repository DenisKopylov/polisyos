"""Remove the receiver-side cache read for one focused R1 adversarial run."""
from __future__ import annotations

import json
import os
import sys
from typing import Any

_TARGET = (
    "tests/unit/scientist/orchestration/engine/"
    "test_engine_executor_idempotency.py::"
    "test_incomplete_process_run_resumes_same_cache_and_one_terminal_lifecycle"
)


def _append_control_event(event: dict[str, Any]) -> None:
    """Persist one small mutation lifecycle event under the run output root."""
    marker_path = os.environ.get("POLISYOS_R1_MUTATION_CALL_LOG")
    if not marker_path:
        raise RuntimeError("r1_mutation_call_log_missing")
    flags = os.O_WRONLY | os.O_CREAT | os.O_APPEND | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(marker_path, flags, 0o600)
    try:
        payload = json.dumps(event, sort_keys=True).encode() + b"\n"
        if os.write(fd, payload) != len(payload):
            raise OSError("r1_mutation_call_log_short_write")
        os.fsync(fd)
    finally:
        os.close(fd)


class RemoveCacheReadForR1:
    """Force a miss only in the pytest receiver process, then restore the method."""

    def __init__(self) -> None:
        self._cache_type: type[Any] | None = None
        self._original_get: Any = None
        self._patched = False

    def pytest_runtest_setup(self, item: Any) -> None:
        if item.nodeid != _TARGET:
            return
        from polisyos.scientist.orchestration.engine.idempotency import NodeResultCache

        self._cache_type = NodeResultCache
        self._original_get = NodeResultCache.get

        def forced_miss(
            _cache: Any,
            _key: str,
            *,
            deadline_monotonic: float | None = None,
        ) -> None:
            del deadline_monotonic
            _append_control_event(
                {
                    "event": "NodeResultCache.get_forced_miss",
                    "pid": os.getpid(),
                    "key": _key,
                    "returned": None,
                }
            )
            print("R1_CACHE_READ_REMOVAL_ACTIVE", file=sys.stdout, flush=True)
            return None

        NodeResultCache.get = forced_miss
        self._patched = True
        _append_control_event(
            {
                "event": "NodeResultCache.get_patch_installed",
                "pid": os.getpid(),
                "target_nodeid": item.nodeid,
            }
        )

    def pytest_runtest_teardown(self, item: Any, nextitem: Any) -> None:
        del nextitem
        if item.nodeid != _TARGET or not self._patched:
            return
        assert self._cache_type is not None
        self._cache_type.get = self._original_get
        restored = self._cache_type.get is self._original_get
        _append_control_event(
            {
                "event": "NodeResultCache.get_restored",
                "pid": os.getpid(),
                "restored": restored,
            }
        )
        if not restored:
            raise RuntimeError("r1_cache_reader_restore_failed")
        self._patched = False
        self._cache_type = None
        self._original_get = None


plugin = RemoveCacheReadForR1()


def pytest_runtest_setup(item: Any) -> None:
    """Install the scoped removal after pytest registers this module."""
    plugin.pytest_runtest_setup(item)


def pytest_runtest_teardown(item: Any, nextitem: Any) -> None:
    """Restore the original cache reader after the scoped test."""
    plugin.pytest_runtest_teardown(item, nextitem)
