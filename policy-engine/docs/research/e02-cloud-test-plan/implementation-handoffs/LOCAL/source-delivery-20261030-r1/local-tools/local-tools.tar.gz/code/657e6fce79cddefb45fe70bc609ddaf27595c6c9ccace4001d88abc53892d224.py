"""Measure the declared grammar bound with stdlib only; no product imports.

This is a mathematical grammar experiment, not a replacement serializer or a
runtime admission/reader witness. The production Common codec remains the owner.
"""
from __future__ import annotations

import json
from pathlib import Path


def logical_shape(value: object) -> tuple[int, int]:
    if type(value) is dict:
        children = [logical_shape(item) for item in value.values()]
    elif type(value) is list:
        children = [logical_shape(item) for item in value]
    else:
        return 1, 0
    return 1 + sum(n for n, _ in children), max((d + 1 for _, d in children), default=0)


def grammar_tree(value: object) -> object:
    # Independent specification model for the exact primitive-only owner domain.
    # It is deliberately not a callable production codec or serializer.
    if type(value) is float:
        return {"_type": "float", "repr": "1.5"}
    if type(value) is list:
        return [grammar_tree(item) for item in value]
    if type(value) is dict:
        if "_type" in value:
            return {
                "_type": "mapping",
                "entries": [[key, grammar_tree(item)] for key, item in sorted(value.items())],
            }
        return {key: grammar_tree(item) for key, item in value.items()}
    return value


def wire_shape(value: object) -> tuple[int, int]:
    if type(value) is dict:
        children = [wire_shape(item) for item in value.values()]
        return 1 + len(value) + sum(n for n, _ in children), 1 + max(
            (d for _, d in children), default=0
        )
    if type(value) is list:
        children = [wire_shape(item) for item in value]
        return 1 + sum(n for n, _ in children), 1 + max(
            (d for _, d in children), default=0
        )
    return 1, 0


def envelope(payload: object) -> dict[str, object]:
    return {
        "schema_version": "1.0", "occurrence_id": "i:0:n",
        "invocation_id": "i", "node_id": "n", "artifact_key": "a",
        "payload": grammar_tree(payload),
    }


def cases() -> list[tuple[str, object]]:
    values = [None, False, 0, "x", 1.5, [], {}, {"_type": None}, {"_type": 1.5}]
    rows = [(f"atom-{i}", value) for i, value in enumerate(values)]
    for depth in range(1, 10):
        value: object = 1.5
        for _ in range(depth):
            value = {"_type": value}
        rows.append((f"escaped-chain-{depth}", value))
    for width in (1, 2, 10, 128, 512, 1023):
        rows.append((f"ordinary-wide-{width}", {f"k{i}": 1.5 for i in range(width)}))
        rows.append((f"escaped-wide-{width}", {"_type": 1.5, **{
            f"k{i}": 1.5 for i in range(max(0, width - 1))
        }}))
    for left in values:
        for right in values:
            rows.append(("pair", {"_type": left, "nested": [right]}))
    return rows


def measure_manifest() -> dict[str, object]:
    # Exact fixed-field source-owner envelope from ManifestLifecycle.build and
    # the MethodArtifactOutputPayload PutOptions. Values are synthetic; none
    # are private data, signatures, environment observations, or G authority.
    digest = "f" * 64
    profile = "sha256:" + digest
    manifest = {
        "manifest_schema_version": "v3", "artifact_id": profile,
        "kind": "foundry.method_artifact_output", "media_type": "application/json",
        "byte_size": 65536, "created_at": "9999-12-31T23:59:59.999999+00:00",
        "schema": {"name": "polisyos.core.MethodArtifactOutputPayload", "version": "1.0"},
        "canon": {
            "name": "polisyos.canon.json", "version": "0.3.0", "forbid_floats": False,
            "forbid_nan_inf": True, "exclude_none": True, "max_depth": 9,
            "sort_keys": True, "separators": [",", ":"], "ensure_ascii": False,
        },
        "inputs": [{"artifact_id": profile, "role": role,
                    "manifest_profile_sha256": profile}
                   for role in ("program_graph", "exec_plan", "method_metric_binding_set")],
        "integrity": {"sha256": digest}, "warnings": [],
    }
    raw = json.dumps(manifest, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
    return {"measurement": "stdlib bytes of the fixed source-owned synthetic manifest projection",
            "wire_bytes": len(raw), "proposed_owner_manifest_cap_bytes": 4096,
            "remaining_bytes_at_cap": 4096 - len(raw),
            "constraints": ["Exactly three source-owned lineage roles and strict SHA-256 selectors",
                            "No producer/env/governance/tenant/closure/authority/warning extension in this cohort",
                            "Byte size at most 65536, exact codec/profile and schema fields",
                            "Actual ManifestLifecycle serialization/parsing comparison remains UNRUN"],
            "raw_projection": manifest}


def main() -> None:
    observations = []
    for name, value in cases():
        nodes, depth = logical_shape(value)
        actual_nodes, actual_depth = wire_shape(envelope(value))
        node_bound, depth_bound = 7 * nodes + 10, 1 + 3 * (depth + 1)
        assert actual_nodes <= node_bound, (name, actual_nodes, node_bound)
        assert actual_depth <= depth_bound, (name, actual_depth, depth_bound)
        observations.append({"name": name, "logical_nodes": nodes, "logical_depth": depth,
                             "wire_nodes": actual_nodes, "wire_depth": actual_depth,
                             "node_bound": node_bound, "depth_bound": depth_bound})
    result = {"source_base": "558d24d33f6bfa13d314c033c078b76959ae2d99",
              "status": "stdlib mathematical experiment only; no product gate PASS",
              "case_count": len(observations), "observations": observations,
              "policy_vector_derivation": {"payload_logical_nodes": 1024, "payload_logical_depth": 8,
                    "wrapper_fields": 6, "wrapper_fixed_lexical_nodes": 12,
                    "write_CanonSpec_max_depth": 9, "max_wire_elements": 7178,
                    "max_wire_container_depth": 28, "max_wire_bytes": 65536},
              "manifest_measurement": measure_manifest()}
    destination = Path(__file__).with_name("wire-bound-observations.json")
    destination.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"case_count": len(observations),
                      "synthetic_manifest_bytes": result["manifest_measurement"]["wire_bytes"],
                      "product_imports": "UNRUN", "runtime_tests": "UNRUN"}, sort_keys=True))


if __name__ == "__main__":
    main()
