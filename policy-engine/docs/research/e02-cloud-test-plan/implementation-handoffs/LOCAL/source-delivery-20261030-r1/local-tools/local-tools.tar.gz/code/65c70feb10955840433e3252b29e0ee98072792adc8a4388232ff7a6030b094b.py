"""Prepare source-bound native C43/C50 cases; never execute pytest or backends."""
from __future__ import annotations
import argparse
import hashlib
import json
import runpy
import shutil
import subprocess
from pathlib import Path

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
PRODUCT = ROOT / 'policy-engine'
HERE = Path(__file__).resolve().parent
REPAIRS = ROOT / 'LOCAL/raw/e02-execution-20261027/repairs'
NATIVE = PRODUCT / 'docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1'
LAYER = NATIVE.parent / 'root-layer-lib.py'
SUPERVISOR = PRODUCT / 'docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-postfix-709-q2-helper-actual-20261018/supervise.py'
MANIFESTS = {'C43': ('C43-r5', 'afc483eefa5c65108360bd749643d0866d1979af72044c401accc0fb3d7e3b5d'), 'C50': ('C50-r2', '558e7c21c25d61784d323e67d2c5e3d9d06d05788ea5d9924c907feb31e36d06')}
C43_TEST = 'tests/unit/remediation/test_c43_joint_gaussian.py'
C43_CONSUMERS = [
 'tests/unit/remediation/test_uqp_01.py', 'tests/unit/remediation/test_uqp_02.py', 'tests/unit/remediation/test_uqp_03.py',
 'tests/unit/foundry/uncertainty/test_delta.py', 'tests/unit/foundry/uncertainty/test_monte_carlo.py',
 'tests/unit/foundry/uncertainty/test_quasi_mc.py', 'tests/unit/foundry/uncertainty/test_dispatcher.py',
 'tests/unit/foundry/uncertainty/test_dispatcher_routing.py', 'tests/unit/foundry/uncertainty/test_covariance.py',
 'tests/unit/foundry/uncertainty/test_uncertainty_protocol.py', 'tests/unit/foundry/uncertainty/test_uncertainty_propagation.py',
 'tests/unit/foundry/uncertainty/test_adaptive_stopping.py', 'tests/unit/foundry/uncertainty/test_evaluation_failures.py',
 'tests/unit/foundry/uncertainty/test_artifact_aware_aggregation.py', 'tests/unit/foundry/uncertainty/test_monte_carlo_b194.py',
 'tests/unit/scientist/nodes/builtins/simulate/test_propagate_uncertainty.py',
 'tests/unit/scientist/nodes/builtins/simulate/test_welfare_covariance.py',
 'tests/unit/foundry/calibration/test_calibration_uncertainty_adapter.py',
]
C50_PILOT = [
 'tests/unit/calibration/diagnostics/test_c50_receipt_consistency.py',
 'tests/unit/calibration/diagnostics/test_continuous.py', 'tests/unit/calibration/diagnostics/test_adapters.py',
 'tests/unit/calibration/diagnostics/test_multiclass.py', 'tests/unit/ir/analytics/test_calibration_diagnostics_report.py',
 'tests/unit/foundry/methods/test_truthfulness_protocol.py',
 'tests/unit/foundry/methods/backends/test_dispatch.py',
 'tests/unit/foundry/methods/backends/test_dispatch_output_contract.py',
]
C50_OWNER = [
 'tests/unit/remediation/test_frc_02_owner.py::test_real_ets_owner_persists_content_bound_predictive_evidence',
 'tests/unit/remediation/test_frc_02_owner.py::test_real_forecast_report_is_limited_in_fresh_diagnostic_http_view',
]
COMMON = ['pytest.ini', 'pyproject.toml', 'uv.lock', 'src/polisyos/ir/__init__.py',
 'src/polisyos/ir/analytics/__init__.py', 'src/polisyos/ir/artifacts/__init__.py',
 'src/polisyos/ir/artifacts/contracts.py', 'src/polisyos/ir/artifacts/io.py',
 'src/polisyos/ir/registry/refs.py', 'src/polisyos/core/backends/__init__.py',
 'src/polisyos/core/backends/dispatcher.py', 'src/polisyos/core/observability/__init__.py',
 'src/polisyos/core/canon/__init__.py', 'src/polisyos/core/canon/canon_json.py']
C43_CONTEXT = ['src/polisyos/ir/analytics/uncertainty.py', 'src/polisyos/foundry/uncertainty/config.py',
 'src/polisyos/scientist/nodes/builtins/simulate/propagate_uncertainty.py',
 'src/polisyos/scientist/nodes/builtins/simulate/welfare_covariance.py',
 'src/polisyos/foundry/calibration/uncertainty_adapter.py']
C50_CONTEXT = ['src/polisyos/ir/analytics/query_validation_report.py', 'src/polisyos/ir/governance/validation.py',
 'src/polisyos/ir/analytics/forecasting_uncertainty.py', 'src/polisyos/calibration/curve/__init__.py', 'src/polisyos/calibration/curve/_compute.py',
 'src/polisyos/foundry/methods/backends/protocol.py', 'src/polisyos/foundry/methods/backends/validated.py',
 'src/polisyos/scientist/methods/backtesting/forecast_owner.py']
RUNNER_SHA = '4c3eae2136b6c8941ba09d4438d12ea6ea11310527768f0482877b877b8e30c2'


def sha(path: Path) -> str:
 return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args: str) -> str:
 return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def committed_pin(path: Path, head: str) -> dict:
 if path.is_symlink() or not path.is_file():
  raise SystemExit('Input missing/nonregular: ' + str(path))
 rel = str(path.relative_to(ROOT))
 blob = git('rev-parse', head + ':' + rel)
 content = subprocess.check_output(['git', 'cat-file', 'blob', blob], cwd=ROOT)
 if hashlib.sha256(content).hexdigest() != sha(path):
  raise SystemExit('Input differs from admitted Git blob: ' + rel)
 return {'path': rel, 'sha256': sha(path), 'git_blob': blob,
         'last_change_commit': git('log', '-1', '--format=%H', head, '--', rel)}


def main() -> None:
 parser = argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--admitted-head', required=True)
 parser.add_argument('--admitted-tree', required=True)
 parser.add_argument('--case-prefix', required=True)
 parser.add_argument('--stage', choices=['pilot', 'consumers'], default='pilot')
 parser.add_argument('--include-c50-test-import-fix', action='store_true', help='Require the separately reviewed one-line C50 test-only import postimage')
 args = parser.parse_args()
 if not args.case_prefix or any(not (c.isalnum() or c in '-_') for c in args.case_prefix):
  raise SystemExit('Invalid unique case prefix')
 head, tree = git('rev-parse', 'HEAD'), git('rev-parse', 'HEAD^{tree}')
 if (head, tree) != (args.admitted_head, args.admitted_tree):
  raise SystemExit(f'HEAD/tree mismatch: actual {head}/{tree}; admit explicit current source')
 if git('symbolic-ref', '--short', 'HEAD') != 'codex/e02-unified-local-20261009':
  raise SystemExit('Wrong branch; do not switch')
 if git('status', '--porcelain=v1', '--untracked-files=no'):
  raise SystemExit('Tracked/index mutation present; root must settle source before freeze')
 if subprocess.run(['git', 'merge-base', '--is-ancestor', 'aefc080e6ed12f2fcc5e820b454c6fc4a9b494f2', head], cwd=ROOT).returncode:
  raise SystemExit('Expected original composed C50 commit is not an ancestor')
 if sha(NATIVE/'run_case_with_tools_r2.py') != RUNNER_SHA:
  raise SystemExit('Retained native runner changed; requalify')
 live = runpy.run_path(str(LAYER))['guard']()
 if live['head'] != head:
  raise SystemExit('Root native source-frame admission is not bound to current HEAD')
 free = shutil.disk_usage(ROOT).free
 if free < 8 * 1024**3:
  raise SystemExit(f'Need 8 GiB conservative plan admission; actual free bytes {free}. Reassess reserve; supervisor hard floor is 6 GiB.')
 core_delta = git('diff', '--name-only', 'aefc080e6ed12f2fcc5e820b454c6fc4a9b494f2', head, '--', 'policy-engine/src/polisyos/core', 'policy-engine/src/polisyos/ir')
 core_delta_paths = core_delta.splitlines() if core_delta else []
 changed_code = {ROOT / path for path in core_delta_paths if path.endswith('.py')}
 if any(not p.is_file() for p in changed_code):
  raise SystemExit('A changed Core/IR Python input was removed; qualify the deletion explicitly before binding')
 specs = []
 for family, (folder, manifest_sha) in MANIFESTS.items():
  manifest_path = REPAIRS / folder / 'manifest.json'
  if sha(manifest_path) != manifest_sha:
   raise SystemExit('Reviewed manifest changed: ' + str(manifest_path))
  rows = [row for group in json.loads(manifest_path.read_text())['footprints'].values() for row in group]
  delta = None
  if family == 'C50' and args.include_c50_test_import_fix:
   dp = REPAIRS/'C50-test-import-r1/manifest.json'
   dd = 'd8d119e8e97c45ebaa7d1b3ee77632351bf1640a51e4139a19f0948c20c68230'
   if sha(dp) != dd: raise SystemExit('C50 import delta manifest mismatch')
   dm = json.loads(dp.read_text()); dr=dm['files'][0]
   if dr['path'] != 'policy-engine/tests/unit/calibration/diagnostics/test_c50_receipt_consistency.py': raise SystemExit('Unexpected delta footprint')
   target=next(row for row in rows if row['path']==dr['path'])
   if target['post_sha256']!=dr['preimage_sha256']: raise SystemExit('C50 delta preimage differs from reviewed original')
   target = dict(target); target['post_sha256']=dr['postimage_sha256']
   rows=[target if row['path']==dr['path'] else row for row in rows]
   delta={'path':str(dp.relative_to(ROOT)),'sha256':dd,'test_path':dr['path'],'preimage_sha256':dr['preimage_sha256'],'postimage_sha256':dr['postimage_sha256']}
  for row in rows:
   path = ROOT / row['path']
   if not path.is_file() or sha(path) != row['post_sha256']:
    raise SystemExit('Reviewed postimage changed; qualify exact delta before rebind: ' + row['path'])
  if family == 'C43':
   nodes = [C43_TEST] if args.stage == 'pilot' else C43_CONSUMERS
   context = C43_CONTEXT
  else:
   nodes = C50_PILOT if args.stage == 'pilot' else C50_OWNER
   context = C50_CONTEXT
  test_files = {node.split('::', 1)[0] for node in nodes}
  paths = {ROOT/row['path'] for row in rows} | {PRODUCT/p for p in COMMON + context} | {PRODUCT/p for p in test_files} | changed_code
  bindings = [committed_pin(path, head) for path in sorted(paths)]
  family_id = family.lower()
  case_id = args.case_prefix + '-' + family_id + '-' + args.stage
  plan_path = NATIVE / ('plan-' + case_id + '.json')
  if plan_path.exists() or (NATIVE/case_id).exists():
   raise SystemExit('Refusing to overwrite plan or output: ' + case_id)
  plan = {
   'case_id': case_id, 'source_head': head, 'source_tree': tree,
   'task_ids': ['UQP-01','UQP-02','UQP-03'] if family == 'C43' else ['LA-052','PCL-01'],
   'nodes': nodes, 'extra_env': {}, 'deadline_seconds': 600, 'rss_cap_bytes': 2415919104,
   'scope': ('C43 actual joint Gaussian and effective fixed input defining-oracle pilot' if family == 'C43' and args.stage == 'pilot' else
             'C43 changed UQP/QMC, covariance and named Scientist/calibration consumers' if family == 'C43' else
             'C50 report/continuous/binary/multiclass, typed IR and real Foundry dispatch witnesses' if args.stage == 'pilot' else
             'C50 actual ForecastOwner selected-view persisted/readback and limited HTTP consumers'),
   'source_bindings': bindings, 'reviewed_original_manifest': {'path': str(manifest_path.relative_to(ROOT)), 'sha256': manifest_sha},
   'actual_core_ir_changed_since_c50_commit': core_delta_paths,
   'runner_bindings': {str(p.relative_to(ROOT)): sha(p) for p in [NATIVE/'run_case_with_tools_r2.py', NATIVE/'readset_observer_tools_r1.py', SUPERVISOR, LAYER]},
   'source_frame_binding': live['source_frame'], 'reviewed_c50_test_import_delta': delta, 'case_stage': args.stage, 'closure_ids': [],
   'expected_result': {'outcome': 'PASS', 'failures': 0, 'errors': 0, 'skips': 0, 'note': 'Record actual collected counts and complete JUnit; missing backend or supervisor abort is ERROR/UNRUN, not product FAIL.'},
   'resource_admission': {'c43_pilot_first_alone': True, 'free_bytes_at_preparation': free, 'planned_process_tree_rss_cap_gib': 2.25,
                          'deadline_seconds': 600, 'supervisor_disk_floor_gib': 6, 'preparation_reserve_gib': 8,
                          'numeric_threads': 1, 'requirements': 'Root must remeasure free disk and available RAM, CPU, competing processes and port/database leases before launch; 2.25 GiB is a cap, not measured RAM. C43 first new-cost pilot runs alone. Use actual measured RSS/wall to price later work.'},
   'profile': 'Unchanged D retained runner + supervisor and native pytest.ini/default plugin autoload; no disabled plugins, custom numerical backend, or production data export.',
   'proof_limit': 'These finite tests do not establish production covariance provenance, receipt origin, fresh CAS admission, G acceptance or E02 closure. Read actual imported source readsets and compare all current bytes after execution.'
  }
  specs.append((plan_path, plan))
 if git('rev-parse', 'HEAD') != head or git('rev-parse','HEAD^{tree}') != tree or git('status','--porcelain=v1','--untracked-files=no'):
  raise SystemExit('Canonical state moved during preparation; no plans written')
 runpy.run_path(str(LAYER))['guard']()
 for path, plan in specs:
  with path.open('x') as stream:
   stream.write(json.dumps(plan, indent=2) + '\n')
  if json.loads(path.read_text()) != plan:
   raise SystemExit('Plan readback mismatch: ' + str(path))
 receipt = {'source_head': head, 'source_tree': tree, 'source_frame_binding': live['source_frame'],
            'stage': args.stage, 'generator_sha256': sha(Path(__file__)),
            'plans': [{'path': str(path), 'sha256': sha(path), 'nodes': plan['nodes'], 'source_paths': len(plan['source_bindings'])} for path,plan in specs],
            'native_tests_executed': False, 'closure_ids': []}
 out = HERE / (args.case_prefix + '-' + args.stage + '-preparation.json')
 with out.open('x') as stream:
  stream.write(json.dumps(receipt, indent=2) + '\n')
 print(json.dumps(receipt, indent=2))

if __name__ == '__main__':
 main()
