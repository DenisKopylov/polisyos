"""Complete one-owner AST census of the existing guarded transfer/constructor family."""
import ast
import hashlib
import json
from pathlib import Path
P=Path(__file__).resolve().parent
owner=P.parent/'dynamic-function-code-bridge-r8/candidate/policy-engine/tools/quality/validation/decomposition_preflight.py'
source=owner.read_bytes();tree=ast.parse(source,filename=str(owner));rows=[]
class Walk(ast.NodeVisitor):
 def __init__(self):self.scopes=[]
 def visit_ClassDef(self,node):
  self.scopes.append(node.name);self.generic_visit(node);self.scopes.pop()
 def visit_FunctionDef(self,node):
  self.scopes.append(node.name)
  for arg in (*node.args.posonlyargs,*node.args.args,*node.args.kwonlyargs):
   if arg.arg=='guarded':rows.append({'family':'guarded_formal','scope':'.'.join(self.scopes),'line':arg.lineno})
  self.generic_visit(node);self.scopes.pop()
 visit_AsyncFunctionDef=visit_FunctionDef
 def visit_Attribute(self,node):
  if node.attr=='guarded':rows.append({'family':'guarded_attribute','scope':'.'.join(self.scopes) or '<module>','line':node.lineno,'column':node.col_offset,'context':type(node.ctx).__name__,'expression':ast.unparse(node)})
  self.generic_visit(node)
 def visit_Call(self,node):
  callee=ast.unparse(node.func)
  families=[]
  if isinstance(node.func,ast.Name) and node.func.id=='_DynamicImportBinding':families.append('direct_binding_constructor')
  if isinstance(node.func,ast.Name) and node.func.id=='replace':families.append('direct_replace')
  if any(k.arg=='guarded' for k in node.keywords):families.append('guarded_keyword_call')
  for family in families:rows.append({'family':family,'scope':'.'.join(self.scopes) or '<module>','line':node.lineno,'column':node.col_offset,'callee':callee,'guarded_keyword':[ast.unparse(k.value) for k in node.keywords if k.arg=='guarded'],'positional_guarded':ast.unparse(node.args[2]) if family=='direct_binding_constructor' and len(node.args)>2 else None})
  self.generic_visit(node)
Walk().visit(tree)
counts={family:sum(r['family']==family for r in rows) for family in sorted({r['family'] for r in rows})}
result={'source':str(owner),'source_sha256':hashlib.sha256(source).hexdigest(),'denominator':'one complete .py owner AST, every Attribute(attr=guarded), guarded formal, direct Name(_DynamicImportBinding)/Name(replace) call and any guarded keyword call; families overlap by design','executor':'/root/dynamic_codetype_bridge','provenance_for_executor':'recomputed','counts':counts,'rows':rows,'boundaries':['Not repository-wide evidence.','Direct syntactic constructor/replace calls are the census denominator; runtime constructor aliases are handled by the same class invariant, not asserted absent by this census.','Census is navigation, not the normalization acceptance gate.']}
(P/'guarded-family-census.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'source_sha256':result['source_sha256'],'counts':counts}))
