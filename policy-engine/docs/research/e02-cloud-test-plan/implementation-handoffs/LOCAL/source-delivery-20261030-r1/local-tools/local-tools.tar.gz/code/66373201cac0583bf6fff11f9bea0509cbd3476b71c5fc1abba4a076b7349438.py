"""Synthetic stdlib-only checks for R188 preflight and output cap boundaries."""
import gzip
import importlib.util
import os
import sys
from pathlib import Path

PACKET = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("i2_r188_supervisor", PACKET / "supervisor.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

limits = module.resource_limits(module.MANIFEST)
# Record the exact calls without changing this process's own limits.
original_setrlimit = module.resource.setrlimit
setrlimit_calls = []
def record_setrlimit(which, pair):
    setrlimit_calls.append((which, tuple(pair)))
module.resource.setrlimit = record_setrlimit
try:
    module.set_child_limits(limits)
finally:
    module.resource.setrlimit = original_setrlimit
assert setrlimit_calls == [
    (module.resource.RLIMIT_CPU, tuple(limits["cpu_seconds_soft_hard"])),
    (module.resource.RLIMIT_FSIZE, (limits["per_child_file_bytes"], limits["per_child_file_bytes"])),
]
assert all(which != getattr(module.resource, "RLIMIT_AS", None) for which, _ in setrlimit_calls)
assert limits["max_uncompressed_output_bytes"] == module.MANIFEST["resources"]["hard_caps"]["stdout_uncompressed_bytes"]
assert limits["max_compressed_output_bytes"] == module.MANIFEST["resources"]["hard_caps"]["stdout_compressed_bytes"]
assert limits["max_uncompressed_output_bytes"] == 32 * 1024**2
assert limits["max_compressed_output_bytes"] == 8 * 1024**2
assert limits["max_stderr_bytes"] == 1 * 1024**2
assert limits["tmpdir_bytes"] == 32 * 1024**2
assert limits["metadata_bytes"] == 4 * 1024**2
assert limits["rss_sample_bytes"] == 1 * 1024**2
assert limits["per_child_file_bytes"] == 1 * 1024**2
assert limits["max_process_group_rss_kib"] == 1024 * 1024
assert limits["minimum_free_disk_bytes"] >= 6 * 1024**3 + 512 * 1024**2 + limits["expected_added_disk_upper_bound_bytes"]

sample = b"small synthetic stdout chunk"
member = module.compress_stdout_chunk(sample, 0, 0, len(sample), 1000)
assert gzip.decompress(member) == sample
try:
    module.compress_stdout_chunk(sample, 0, 0, len(sample) - 1, 1000)
except ValueError as exc:
    assert str(exc) == "public_output_uncompressed_cap"
else:
    raise AssertionError("raw output cap accepted an over-limit chunk")
try:
    module.compress_stdout_chunk(sample, 0, 0, len(sample), len(member) - 1)
except ValueError as exc:
    assert str(exc) == "public_output_compressed_cap"
else:
    raise AssertionError("compressed output cap accepted an over-limit member")
assert len(module.compress_stdout_chunk(sample, 0, len(member), len(sample), len(member) * 2)) == len(member)

original_manifest = module.MANIFEST
original_argv = sys.argv
original_popen = module.subprocess.Popen
try:
    bad = {"resources": {"hard_caps": {"wall_timeout_seconds": 120}}}
    try:
        module.resource_limits(bad)
    except ValueError as exc:
        assert "cpu_seconds_soft_hard" in str(exc)
    else:
        raise AssertionError("missing resource caps were accepted")
    low_headroom = {**original_manifest, "resources": {**original_manifest["resources"],
        "execution_admission": {"minimum_free_disk_bytes": 6 * 1024**3 + 512 * 1024**2}}}
    try:
        module.resource_limits(low_headroom)
    except ValueError as exc:
        assert "512 MiB" in str(exc)
    else:
        raise AssertionError("disk margin below forecast was accepted")
    oversized = {**original_manifest, "resources": {**original_manifest["resources"],
        "hard_caps": {**original_manifest["resources"]["hard_caps"], "stdout_compressed_bytes": 16 * 1024**2}}}
    try:
        module.resource_limits(oversized)
    except ValueError as exc:
        assert "R188 ceiling" in str(exc)
    else:
        raise AssertionError("oversized stdout profile was accepted")
    module.MANIFEST = bad
    sys.argv = [str(PACKET / "supervisor.py"), "--execute"]
    module.subprocess.Popen = lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError("Popen crossed preflight"))
    try:
        module.main()
    except ValueError as exc:
        assert "cpu_seconds_soft_hard" in str(exc)
    else:
        raise AssertionError("invalid manifest reached execution")
    assert not module.OUT.exists(), "invalid caps created an attempt output directory"
    module.subprocess.Popen = original_popen

    class PopenBoundary(Exception):
        pass

    actual_out = module.OUT
    boundary_out = PACKET / "run" / ("source-only-preflight-popen-boundary-" + os.environ.get("E02_R188_CONTROL_RUN_ID", "default"))
    module.OUT = boundary_out
    module.MANIFEST = original_manifest
    valid_preflight = module.preflight()
    original_preflight = module.preflight
    module.preflight = lambda: valid_preflight
    sys.argv = [str(PACKET / "supervisor.py"), "--execute"]
    def blocked_launch(command, **kwargs):
        assert command[-1] == str(PACKET / "launch_cli.py")
        raise PopenBoundary()
    module.subprocess.Popen = blocked_launch
    try:
        module.main()
    except PopenBoundary:
        pass
    else:
        raise AssertionError("valid admitted main path did not reach the Popen boundary")
    assert {key: valid_preflight[key] for key in ("branch", "head", "tree")} == original_manifest["source_identity"]
    module.preflight = original_preflight
    assert boundary_out.is_dir() and (boundary_out / "preflight.json").is_file()
    assert (boundary_out / "command.json").is_file() and (boundary_out / "sandbox.sb").is_file()
    module.OUT = actual_out
    module.subprocess.Popen = original_popen

    sampler_child = module.subprocess.Popen(["/bin/sleep", "2"], start_new_session=True)
    try:
        observed_rss, process_count, group_rss, supervisor_rss = module.sample_diagnostic_rss_kib(
            sampler_child.pid, __import__("os").getpid()
        )
        assert observed_rss == group_rss + supervisor_rss and process_count >= 1 and group_rss > 0 and supervisor_rss > 0
    finally:
        sampler_child.terminate()
        sampler_child.wait()
finally:
    module.MANIFEST = original_manifest
    module.subprocess.Popen = original_popen
    sys.argv = original_argv

print("R188 source-only controls: PASS (resource and disk-margin admission, raw/compressed cap edges, invalid-cap preflight-before-write and valid-source Popen-stub boundary, combined supervisor/process-group RSS sampler)")
