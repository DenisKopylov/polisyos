"""Capture effective child-side backend and plugin identity for matched controls."""
from __future__ import annotations
import hashlib
import importlib.metadata
import os
import sys
from pathlib import Path


def snapshot(config) -> dict:
    """Observe installed packages, actual JAX devices/config, inherited numeric flags and pytest plugins."""
    import jax
    import jaxlib
    import numpy
    import scipy

    binary = Path(sys.executable).resolve(strict=True)
    plugins = set()
    for name, plugin in config.pluginmanager.list_name_plugin():
        module = getattr(plugin, '__name__', plugin.__class__.__module__)
        if module in {'c43_select_plugin', 'c43_removal_plugin', 'c43_child_profile'}:
            continue
        if name in {'c43_select_plugin', 'c43_removal_plugin', 'c43_child_profile'}:
            continue
        plugins.add(module)
    names = ('jax', 'jaxlib', 'numpy', 'scipy', 'pytest', 'pydantic')
    versions = {}
    for name in names:
        try:
            versions[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            versions[name] = None
    prefixes = ('JAX_', 'XLA_')
    numeric = {'OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMBA_NUM_THREADS',
               'NUMEXPR_NUM_THREADS', 'ARROW_NUM_THREADS', 'BLIS_NUM_THREADS',
               'SCIENTIST_TORCH_NUM_THREADS', 'SCIENTIST_TORCH_NUM_INTEROP_THREADS', 'PYTHONHASHSEED'}
    relevant_env = {k: v for k, v in os.environ.items() if k in numeric or k.startswith(prefixes)}
    return {
        'python': sys.version,
        'executable': sys.executable,
        'executable_resolved': str(binary),
        'executable_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
        'versions': versions,
        'module_paths': {'jax': jax.__file__, 'jaxlib': jaxlib.__file__, 'numpy': numpy.__file__, 'scipy': scipy.__file__},
        'jax_enable_x64': bool(jax.config.read('jax_enable_x64')),
        'jax_devices': [{'platform': d.platform, 'device_kind': d.device_kind, 'id': d.id} for d in jax.devices()],
        'relevant_inherited_env': dict(sorted(relevant_env.items())),
        'pytest_plugin_modules': sorted(plugins),
    }
