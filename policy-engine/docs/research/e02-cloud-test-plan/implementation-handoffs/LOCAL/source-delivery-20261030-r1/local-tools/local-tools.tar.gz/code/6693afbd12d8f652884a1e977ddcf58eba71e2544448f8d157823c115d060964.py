from pathlib import Path
import ast,hashlib,json,subprocess,tomllib
root=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos');product=root/'policy-engine';raw=root/'LOCAL/raw/e02-execution-20261027/repairs/C94-selected-posterior-consumer-r3';py=product/'.venv/bin/python';rels=['src/polisyos/foundry/calibration/uncertainty_adapter.py','tests/unit/scientist/compute/test_selected_posterior_consumer.py'];results=[]
for i,rel in enumerate(rels):
 p=raw/'postimages/policy-engine'/rel;data=p.read_bytes();before=ast.parse(data)
 commands=[['-m','ruff','check','--no-cache','--select','I','--fix','--stdin-filename',str(product/rel),'-'],['-m','ruff','format','--no-cache','--stdin-filename',str(product/rel),'-']]
 for j,cmd in enumerate(commands):
  a=subprocess.run([str(py),*cmd],cwd=product,input=data,capture_output=True);(raw/f'static-{i}-{j}.stderr').write_bytes(a.stderr);assert a.returncode==0,(rel,j,a.stderr.decode());data=a.stdout
 after=ast.parse(data)
 strip=lambda t:ast.dump(ast.Module(body=[n for n in t.body if not isinstance(n,(ast.Import,ast.ImportFrom))],type_ignores=[]),include_attributes=False)
 assert strip(before)==strip(after),rel
 p.write_bytes(data)
 for j,cmd in enumerate([['-m','ruff','check','--no-cache','--stdin-filename',str(product/rel),'-'],['-m','ruff','format','--check','--no-cache','--stdin-filename',str(product/rel),'-']]):
  a=subprocess.run([str(py),*cmd],cwd=product,input=data,capture_output=True);(raw/f'static-{i}-{j}.stdout').write_bytes(a.stdout);(raw/f'static-{i}-{j}-check.stderr').write_bytes(a.stderr);results.append({'path':rel,'phase':j,'exit':a.returncode,'stderr':a.stderr.decode(),'stdout':a.stdout.decode(),'post_sha256':hashlib.sha256(data).hexdigest()})
(raw/'static-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2));assert all(x['exit']==0 for x in results)
