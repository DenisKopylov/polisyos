"""Finite typed pytest parameter identities; never serialize address-based repr."""
from pathlib import Path
from types import CodeType,FunctionType
import hashlib,marshal

def sha(b):return hashlib.sha256(b).hexdigest()
def fp(c):return (c.co_code,c.co_names,c.co_varnames,c.co_freevars,c.co_cellvars,c.co_argcount,c.co_posonlyargcount,c.co_kwonlyargcount,c.co_flags,tuple(fp(v) if isinstance(v,CodeType) else v for v in c.co_consts))
def codes(c):
 yield c
 for v in c.co_consts:
  if isinstance(v,CodeType):yield from codes(v)
def encode(v):
 if v is None or type(v) in (bool,int,str):return v
 if type(v) is float:return {'kind':'float','hex':v.hex()}
 if type(v) is bytes:return {'kind':'bytes','hex':v.hex()}
 if type(v) in (list,tuple):return {'kind':type(v).__name__,'items':[encode(x) for x in v]}
 if type(v) is dict:return {'kind':'dict','items':[[encode(k),encode(x)] for k,x in v.items()]}
 if type(v) is object:return {'kind':'bare_builtin_object','type':'builtins.object','scope':'No instance attributes/payload; process object identity is not asserted. The actual finite parameter ordinal/node remains separate.'}
 if isinstance(v,FunctionType):
  p=Path(v.__code__.co_filename);row={'kind':'python_function','module':v.__module__,'qualname':v.__qualname__,'filename':str(p),'first_line':v.__code__.co_firstlineno,'code_sha256':sha(marshal.dumps(v.__code__)),'defaults':encode(v.__defaults__),'kwdefaults':encode(v.__kwdefaults__),'closure':[encode(c.cell_contents) for c in v.__closure__ or ()],'scope':'Function globals are covered only by actual imported-source readsets; they are not recursively serialized.'}
  if p.is_file():
   raw=p.read_bytes();row['source_sha256']=sha(raw)
   try:row['source_code_reconciled']=any(c.co_name==v.__code__.co_name and c.co_firstlineno==v.__code__.co_firstlineno and fp(c)==fp(v.__code__) for c in codes(compile(raw,str(p),'exec',dont_inherit=True)))
   except (ValueError,SyntaxError):row['source_code_reconciled']=False
  if not row.get('source_code_reconciled'):row['not_established']='Callable code does not reconcile with compile-only source; pytest rewriting or another wrapper may require a dedicated witness.'
  return row
 return {'kind':'unresolved_object','type':type(v).__module__+'.'+type(v).__qualname__,'not_established':'No supported lossless stable parameter encoder; no arbitrary repr or identity comparison was used.'}
def parameters(mapping):
 result={}
 for k,v in mapping.items():
  try:result[str(k)]=encode(v)
  except Exception as exc:result[str(k)]={'kind':'unresolved_parameter','type':type(v).__module__+'.'+type(v).__qualname__,'not_established':'Stable encoder failed: '+type(exc).__name__}
 return result
def unresolved(v):
 if isinstance(v,dict):return bool(v.get('not_established')) or any(unresolved(x) for x in v.values())
 if isinstance(v,list):return any(unresolved(x) for x in v)
 return False
