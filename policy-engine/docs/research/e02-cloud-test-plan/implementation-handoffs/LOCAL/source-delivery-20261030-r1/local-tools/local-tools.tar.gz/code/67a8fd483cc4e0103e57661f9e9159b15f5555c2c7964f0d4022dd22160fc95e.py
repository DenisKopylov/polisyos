import difflib,hashlib,json,subprocess
from pathlib import Path
root=Path.cwd();r=root/'LOCAL/raw/e02-execution-20261027/repairs/B13-finalization-index-r1';post=r/'postimages'
base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();tree=subprocess.check_output(['git','rev-parse',base+'^{tree}'],text=True).strip();old_base='192fc44303c63e52e4dfa8e0b4ee77790bae3394'
rows=[];parts=[]
for f in sorted(post.rglob('*')):
 if not f.is_file(): continue
 assert not f.is_symlink() and f.stat().st_nlink==1
 rel=f.relative_to(post).as_posix();old=subprocess.run(['git','show',f'{base}:{rel}'],capture_output=True);orig=subprocess.run(['git','show',f'{old_base}:{rel}'],capture_output=True);new=f.read_bytes()
 if old.returncode:
  assert orig.returncode and not (root/rel).exists();before=b'';blob=None
 else:
  before=old.stdout;assert orig.returncode==0 and orig.stdout==before;assert (root/rel).read_bytes()==before
  blob=subprocess.check_output(['git','rev-parse',f'{base}:{rel}'],text=True).strip()
  assert (f.stat().st_dev,f.stat().st_ino)!=((root/rel).stat().st_dev,(root/rel).stat().st_ino)
 assert before!=new
 parts.append(''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile='a/'+rel if blob else '/dev/null',tofile='b/'+rel,n=3)))
 rows.append({'path':rel,'base_blob':blob,'base_sha256':hashlib.sha256(before).hexdigest() if blob else None,'postimage_sha256':hashlib.sha256(new).hexdigest(),'postimage_bytes':len(new),'new':blob is None})
patch=''.join(parts).encode();(r/'source.patch').write_bytes(patch)
m={'base_commit':base,'base_tree':tree,'source_preimages_match_earlier_commit':old_base,'files':rows,'source_patch_sha256':hashlib.sha256(patch).hexdigest(),'source_patch_bytes':len(patch),'selection_control_sha256':hashlib.sha256((r/'removal-prior-state-selection.patch').read_bytes()).hexdigest(),'missing_result_control_sha256':hashlib.sha256((r/'removal-debug-state-fallback.patch').read_bytes()).hexdigest(),'included_retained_ref_oracle_r2_sha256':'dcc437883434cbb751c2535a6aa5f0e7079c04fbe2e067771eb504f883993ecc','evidence':'AST, Ruff, format, source patch and mutant applicability only; native/removal UNRUN','currentness':'not_established; source event head and fresh invalidation bridge missing','review':'PENDING'}
(r/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print('base',base,'tree',tree,'files',len(rows),'patch',len(patch),'sha256',m['source_patch_sha256'])
