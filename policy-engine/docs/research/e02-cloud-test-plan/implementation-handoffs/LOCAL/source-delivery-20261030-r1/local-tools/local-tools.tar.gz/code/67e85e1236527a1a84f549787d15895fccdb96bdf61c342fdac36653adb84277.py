"""Exercise the bounded fixture adapter with read-only mapping values, no product imports."""
from __future__ import annotations

import ast
import hashlib
import json
from collections.abc import Mapping
from pathlib import Path
from types import MappingProxyType, SimpleNamespace
from typing import Any

root = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
source = Path(__file__).with_name('prepare_candidate_inputs.py').read_text()
tree = ast.parse(source)
functions = [x for x in tree.body if isinstance(x, ast.FunctionDef) and x.name in {'_candidate_l6_data_from_declared_owners', '_sha256'}]
namespace = {'Mapping': Mapping, 'Any': Any, 'json': json, 'hashlib': hashlib, 'Path': Path}
future = ast.ImportFrom(module='__future__', names=[ast.alias(name='annotations')], level=0)
exec(compile(ast.fix_missing_locations(ast.Module(body=[future, *functions], type_ignores=[])), '<fixture-adapter>', 'exec'), namespace)
authority = root / 'policy-engine/architecture/policy_design_case/layer3_gy_l6_owner_authority_bindings.json'
data = json.loads(authority.read_text())['world_mechanism_manifest']['mechanisms']
slot_ids = {s for mechanism in data.values() for s in (*mechanism.get('reads_slots', ()), *mechanism.get('writes_slots', ()))}
registry = SimpleNamespace(slots={s: SimpleNamespace(state_path='fixture-state-path') for s in slot_ids})
def edge(modality, payload):
    return SimpleNamespace(modality=modality, admissible_completions=(SimpleNamespace(value=MappingProxyType(payload)),))
def reference(domain, target, operator='tax_relief_rate'):
    d = MappingProxyType(domain)
    return SimpleNamespace(reference_hash='synthetic-test-hash', essential_edges={'op': edge('L6_KNOB_OPERATOR', {'operator_kind': operator, 'parameter_domain': d}), 'slot': edge('L6_KNOB_WORLD_SLOT', {'operator_kind': operator, 'target_world_slots': (target,)})})
valid = {'kind': 'range', 'value_type': 'float', 'min_value': 0.0, 'max_value': 0.5, 'unit': 'ratio'}
run = namespace['_candidate_l6_data_from_declared_owners']
payloads, basis = run(reference(valid, 'global.tax_rate'), authority_path=authority, slot_registry=registry, path_exists=lambda path: True)
assert set(payloads['intervention_knob_dictionary']) == {'tax_relief_rate'}
assert payloads['lex_intervention_map'] == {} and basis['candidate_data_only'] is True
budget = {**valid, 'max_value': 2.0}
budget_payloads, _ = run(reference(budget, 'government.balance', 'budget_allocation_multiplier'), authority_path=authority, slot_registry=registry, path_exists=lambda path: True)
assert set(budget_payloads['intervention_knob_dictionary']) == {'budget_allocation_multiplier'}
for domain, target in [({**valid, 'max_value': 0.7}, 'global.tax_rate'), (valid, 'wrong.slot')]:
    try:
        run(reference(domain, target), authority_path=authority, slot_registry=registry, path_exists=lambda path: True)
    except SystemExit as exc:
        assert str(exc) == 'candidate_l6_fixture_domain_or_targets_differ_from_code_owner'
    else:
        raise AssertionError('inconsistent input admitted')
print('PASS: immutable Mapping domain accepted; changed range and wrong target rejected; no legal facts')
