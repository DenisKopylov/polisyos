from pathlib import Path
base=Path('LOCAL/raw/e02-execution-20261027/repairs/TC-closure-owner-r5/proposal')
p=base/'policy-engine/src/polisyos/foundry/compile/trinity_compiler.py'
s=p.read_text()
a='''    exec_plan_payload_ref = store.put_json(
        exec_plan,
        PutOptions(
            kind=ExecPlan.ARTIFACT_KIND,
            media_type=ExecPlan.ARTIFACT_MEDIA_TYPE,
            schema=SchemaInfo(
                name=ExecPlan.ARTIFACT_SCHEMA_NAME,
                version=ExecPlan.ARTIFACT_SCHEMA_VERSION,
            ),
            inputs=[
                input_ref_from_artifact_ref(program_ref, role="program_graph"),
                input_ref_from_artifact_ref(treasury_plan_ref, role="treasury_plan"),
                *(
                    [
                        input_ref_from_artifact_ref(
                            method_metric_binding_set_ref,
                            role="method_metric_bindings",
                        )
                    ]
                    if method_metric_binding_set_ref is not None
                    else []
                ),
            ],
        ),
'''
b='''    exec_plan_payload_ref = store.put_json(
        exec_plan,
        PutOptions(
            kind=ExecPlan.ARTIFACT_KIND,
            media_type=ExecPlan.ARTIFACT_MEDIA_TYPE,
            schema=SchemaInfo(
                name=ExecPlan.ARTIFACT_SCHEMA_NAME,
                version=ExecPlan.ARTIFACT_SCHEMA_VERSION,
            ),
            inputs=execution_plan_input_refs(
                program_graph_ref=program_ref,
                treasury_plan_ref=treasury_plan_ref,
                method_metric_binding_set_ref=method_metric_binding_set_ref,
            ),
        ),
'''
assert s.count(a)==1;s=s.replace(a,b,1)
s=s.replace('_program_graph_inputs(', 'program_graph_input_refs(')
start=s.index('def program_graph_input_refs(');end=s.index('\ndef _compile_inputs(',start)
old=s[start:end]
needle='''from polisyos.foundry.compile.randomization import (
'''
insert='''from polisyos.foundry.compile.manifest_inputs import (
    execution_plan_input_refs,
    program_graph_input_refs,
)
'''
assert s.count(needle)==1;s=s.replace(needle,insert+needle,1)
p.write_text(s)
rel='policy-engine/src/polisyos/foundry/compile/manifest_inputs.py'
p=base/rel
p.write_text('''"""Derive ordered compiler-owned input edges for selected graph and plan views."""

from __future__ import annotations

from polisyos.core.artifacts.manifest import ArtifactRef, InputRef, input_ref_from_artifact_ref
from polisyos.core.contracts.execution_plan import ExecutionPlanRef


def execution_plan_input_refs(
    *,
    program_graph_ref: ArtifactRef,
    treasury_plan_ref: ArtifactRef,
    method_metric_binding_set_ref: ArtifactRef | None,
) -> list[InputRef]:
    """Return the exact ordered input edges used by the compiler's ExecPlan writer.

    Args:
        program_graph_ref: The selected compiled graph.
        treasury_plan_ref: The selected graph-derived randomization plan.
        method_metric_binding_set_ref: Optional selected method-metric bindings.

    Returns:
        Ordered role-qualified input references. These edges record source
        identity and do not grant authority to any artifact or value.
    """
    inputs = [
        input_ref_from_artifact_ref(program_graph_ref, role="program_graph"),
        input_ref_from_artifact_ref(treasury_plan_ref, role="treasury_plan"),
    ]
    if method_metric_binding_set_ref is not None:
        inputs.append(
            input_ref_from_artifact_ref(
                method_metric_binding_set_ref, role="method_metric_bindings"
            )
        )
    return inputs


'''+old.replace('def _program_graph_inputs(', 'def program_graph_input_refs(')+'''\n''')
s=p.read_text()
s=s.replace(''') -> list[InputRef]:
    inputs = [input_ref_from_artifact_ref(policy_ref, role="ir")]
''',''') -> list[InputRef]:
    """Return the compiler's ordered graph-input lineage for the supplied refs.

    Args:
        policy_ref: Selected Trinity policy input.
        registry_bundle_ref: Optional selected registry bundle.
        link_report_ref: Optional selected linker report.
        lowered_ir_ref: Optional selected lowered IR.
        params_refs: Selected node-parameter references keyed by node id.
        method_execution_plan_ref: Optional selected source method plan.

    Returns:
        Ordered role-qualified references without granting authority.
    """
    inputs = [input_ref_from_artifact_ref(policy_ref, role="ir")]
''',1)
p.write_text(s)
p=base/'policy-engine/src/polisyos/foundry/compile/__init__.py'
s=p.read_text().replace('from typing import Any','from typing import TYPE_CHECKING, Any')
s=s.replace('''__all__ = ["compile", "replay_method_program_graph"]
''','''if TYPE_CHECKING:
    from .manifest_inputs import execution_plan_input_refs, program_graph_input_refs

__all__ = [
    "compile",
    "execution_plan_input_refs",
    "program_graph_input_refs",
    "replay_method_program_graph",
]
''')
s=s.replace('''    "compile": ("polisyos.foundry.compile.api", "compile"),
''','''    "compile": ("polisyos.foundry.compile.api", "compile"),
    "execution_plan_input_refs": (
        "polisyos.foundry.compile.manifest_inputs", "execution_plan_input_refs"
    ),
    "program_graph_input_refs": (
        "polisyos.foundry.compile.manifest_inputs", "program_graph_input_refs"
    ),
''')
p.write_text(s)
p=base/'policy-engine/src/polisyos/foundry/README.md'
s=p.read_text()
s+='''\nThe `polisyos.foundry.compile` facade exposes `program_graph_input_refs` and\n`execution_plan_input_refs`, the same ordered selected-edge builders used by the\nTrinity compiler writer. These functions describe input identity only; they do\nnot verify a source, establish completeness of a caller's basis, or grant\nauthority. Callers must independently select and validate the supplied refs.\n'''
p.write_text(s)
print('compiler input owner extracted')
