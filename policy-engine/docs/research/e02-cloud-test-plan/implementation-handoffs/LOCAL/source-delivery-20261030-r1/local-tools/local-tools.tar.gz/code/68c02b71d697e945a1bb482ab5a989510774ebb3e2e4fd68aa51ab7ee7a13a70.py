"""Actual R7 predecessor collector on true-unknown join witnesses; no source execution."""
import hashlib
import importlib.util
import json
from pathlib import Path
import resource
import signal
import sys
ROOT=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
P=Path(__file__).resolve().parent
signal.alarm(110)
sys.path.insert(0,str(ROOT/'policy-engine'))
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
T=load('r8_predecessor_tests',P/'candidate/policy-engine/tests/repo_quality/architecture/test_dynamic_code_reconstitution.py')
O=load('r8_predecessor_owner',P.parent/'dynamic-function-code-bridge-r7/candidate/policy-engine/tools/quality/validation/decomposition_preflight.py')
T.preflight=O
rows=[]
for name in ('unknown-code-join-escape','unknown-callable-join-call','unknown-callable-join-escape','unknown-code-sequence-escape','unknown-code-mapping-escape','unknown-code-map-lookup-escape','unknown-callable-return','unknown-callable-storage'):
 source=T.CASES[name][0]
 try: entries=T.collect_case(P/'fixtures/r7-gap'/name,source)
 except Exception as e: rows.append({'case':name,'status':'refused','error':str(e)})
 else: rows.append({'case':name,'status':'collected','entries':entries})
result={'owner_origin':O.__file__,'owner_sha256':hashlib.sha256(Path(O.__file__).read_bytes()).hexdigest(),'rows':rows,'product_imports':[n for n in sys.modules if n=='polisyos' or n.startswith('polisyos.')],'ru_maxrss_platform_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
print(json.dumps(result,indent=2))
assert all(r['status']=='collected' and r['entries']==[] for r in rows)
