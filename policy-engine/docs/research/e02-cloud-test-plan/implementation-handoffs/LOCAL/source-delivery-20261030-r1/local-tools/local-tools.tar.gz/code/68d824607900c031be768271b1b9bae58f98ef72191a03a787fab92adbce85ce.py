"""Stdlib-only injected-failure check over the actual observation phase registry."""
from observation import Observer,PHASES
import json
rows=[];covered=set()
for product_raises in [False,True]:
 for injected in sorted(PHASES):
  errors=[];observer=Observer(errors);seen=[];calls=[];result=object();original_failure=ValueError('original fixture owner failure')
  def original(*args,**kwargs):
   calls.append((args,kwargs))
   if product_raises:raise original_failure
   return result
  def phase(name):
   def invoke(*args):
    seen.append(name);covered.add(name)
    if name==injected:raise RuntimeError('injected optional '+name+' failure')
    return {'phase':name}
   return invoke
  returned=None;raised=None
  try:returned=observer.call(original,('actual',),{'scope':'unchanged'},**{p:phase(p) for p in PHASES})
  except ValueError as failure:raised=failure
  assert calls==[(('actual',),{'scope':'unchanged'})]
  assert raised is original_failure if product_raises else returned is result
  assert len(errors)==int(injected in seen)
  rows.append({'product_outcome':'raised_same_object' if product_raises else 'returned_same_object','injected_phase':injected,'phase_reached':injected in seen,'original_calls':len(calls),'observer_errors':len(errors)})
assert covered==PHASES
print(json.dumps({'phase_registry':sorted(PHASES),'cases':rows,'all_original_calls_reached_once_with_unchanged_result_or_exception':True,'product_imports':False,'native_runtime':'UNRUN'},indent=2))
