"""Show the separately reviewed raw-wire versus consumer-meaning divergence."""
import ast
import subprocess
from enum import Enum
from types import SimpleNamespace

source = subprocess.check_output(['git', 'show', '283fb609abfd483504e4f835c79d9b32db3738c0:policy-engine/src/polisyos/foundry/uncertainty/covariance.py'], text=True)
tree = ast.parse(source)
function = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'has_unknown_dependency')
future = ast.ImportFrom(module='__future__', names=[ast.alias(name='annotations')], level=0)
code = compile(ast.fix_missing_locations(ast.Module(body=[future, function], type_ignores=[])), '<extracted covariance predicate>', 'exec')
namespace = {}
exec(code, namespace)

class Meaning(Enum):
    ITEM = 'unknown'
    def __str__(self):
        return 'known'

predicate = namespace['has_unknown_dependency']
live = predicate({'x': SimpleNamespace(metadata={'dependency': Meaning.ITEM})})
wire = predicate({'x': SimpleNamespace(metadata={'dependency': Meaning.ITEM.value})})
assert live is False and wire is True
print('extracted predicate with stdlib stand-in: live_enum_unknown=', live, 'same_wire_string_unknown=', wire)
print('source observation only; full gate and Pydantic serialization are unrun')
