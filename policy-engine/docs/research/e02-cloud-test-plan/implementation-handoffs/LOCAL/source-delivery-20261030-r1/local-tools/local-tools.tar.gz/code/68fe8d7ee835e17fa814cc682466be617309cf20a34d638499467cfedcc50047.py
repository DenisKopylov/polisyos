from pathlib import Path
ROOT=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
OUT=Path(__file__).resolve().parent
POST=OUT/'postimages'
def read(name): return (POST/name).read_text()
def save(name,text):
 p=POST/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
def repl(text,old,new,count=1):
 assert text.count(old)==count,(old[:100],text.count(old));return text.replace(old,new)
P='policy-engine/src/polisyos/foundry/calibration/'
s=read(P+'pure_executor.py')
s=repl(s,'                pending_records,\n            )','                pending_records,\n                bundle=bundle,\n            )')
s=repl(s,'                target_mask=target_mask,\n                bundle=bundle,\n','                target_mask=target_mask,\n')
save(P+'pure_executor.py',s)
s=read(P+'execution_basis.py')
s=repl(s,'from typing import Any, Literal','from typing import Annotated, Any, Literal')
s=repl(s,'    ("ordered_batch_profile", "fit_conditional", "ordered_batch_profile"),\n','')
s=repl(s,'CALIBRATION_RUNTIME_INPUT_NAMES_V1_1 = CALIBRATION_RUNTIME_INPUT_NAMES[:-1]','CALIBRATION_RUNTIME_INPUT_CONTRACT_V1_2 = (\n    *CALIBRATION_RUNTIME_INPUT_CONTRACT,\n    ("ordered_batch_profile", "fit_conditional", "ordered_batch_profile"),\n)\nCALIBRATION_RUNTIME_INPUT_NAMES_V1_2 = tuple(\n    row[0] for row in CALIBRATION_RUNTIME_INPUT_CONTRACT_V1_2\n)')
s=repl(s,'        "selected_base_state_snapshot_ref",\n    ]','        "selected_base_state_snapshot_ref",\n        "ordered_batch_profile",\n    ]')
anchor='class CalibrationExecutionInputBasis(BaseModel):'
models='''_ScheduleStep = Annotated[int, Field(ge=0, strict=True)]
_KeyWord = Annotated[int, Field(ge=0, le=2**32 - 1, strict=True)]


class CalibrationOrderedBatchRow(BaseModel):
    """Bind one positional row to the selected snapshot actually consumed."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    row_id: str = Field(min_length=1)
    state_snapshot_ref: ArtifactRef
    state_values_sha256: str = Field(pattern=_SHA256_PATTERN)
    source_status: Literal["materialized_local_fit_input"] = "materialized_local_fit_input"

    @model_validator(mode="after")
    def validate_selected_state(self) -> CalibrationOrderedBatchRow:
        ref = self.state_snapshot_ref
        if (
            ref.kind != "foundry.state_snapshot"
            or ref.media_type != "application/json"
            or ref.manifest_profile_sha256 is None
        ):
            raise ValueError("ordered_batch_row_requires_selected_state_snapshot")
        return self


class CalibrationOrderedBatchInput(BaseModel):
    """Typed ordered objective inputs; content capture supplies no sampling law."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    profile_kind: Literal["ordered_scalar_mse_v1"] = "ordered_scalar_mse_v1"
    objective_kind: Literal["generic_weighted_mse_curvature_only"] = (
        "generic_weighted_mse_curvature_only"
    )
    key_policy: Literal["explicit_complete_fixed_row_keys_v1"] = (
        "explicit_complete_fixed_row_keys_v1"
    )
    inference_status: Literal["unavailable_generic_loss"] = "unavailable_generic_loss"
    target_id: str = Field(min_length=1)
    target_path: str = Field(min_length=1)
    rows: tuple[CalibrationOrderedBatchRow, ...] = Field(min_length=1)
    row_times: tuple[_ScheduleStep, ...]
    row_times_dtype: str
    row_keys: tuple[tuple[_KeyWord, _KeyWord], ...]
    targets: tuple[float, ...]
    targets_dtype: str
    weights: tuple[float, ...]
    weights_dtype: str
    consumed_profile_sha256: str = Field(pattern=_SHA256_PATTERN)
    loss_epsilon: float = Field(ge=0, allow_inf_nan=False)
    target_priority: float = Field(gt=0, allow_inf_nan=False)

    @model_validator(mode="after")
    def validate_ordered_inputs(self) -> CalibrationOrderedBatchInput:
        count = len(self.rows)
        if len({row.row_id for row in self.rows}) != count:
            raise ValueError("ordered_batch_row_ids_must_be_unique")
        if any(len(values) != count for values in (
            self.row_times, self.row_keys, self.targets, self.weights
        )):
            raise ValueError("ordered_batch_inputs_must_have_exact_row_shape")
        if any(not math.isfinite(value) for value in (*self.targets, *self.weights)):
            raise ValueError("ordered_batch_numeric_inputs_must_be_finite")
        if any(value < 0 for value in self.weights) or not 0 < sum(self.weights) < math.inf:
            raise ValueError("ordered_batch_weights_require_positive_finite_support")
        for name in ("targets_dtype", "weights_dtype"):
            dtype = np.dtype(getattr(self, name))
            if dtype.kind not in "iuf":
                raise ValueError("ordered_batch_numeric_dtype_not_supported")
        if np.dtype(self.row_times_dtype).kind not in "iu":
            raise ValueError("ordered_batch_schedule_dtype_must_be_integer")
        return self


'''
s=repl(s,anchor,models+anchor)
s=repl(s,'ordered_batch_profile: Mapping[str, Any] | None = None','ordered_batch_profile: CalibrationOrderedBatchInput | None = None')
s=repl(s,'CALIBRATION_RUNTIME_INPUT_NAMES_V1_1','CALIBRATION_RUNTIME_INPUT_NAMES')
# Keep the public v1.1 field denominator unchanged. The new version owns the new row.
s=repl(s,'roster_names != CALIBRATION_RUNTIME_INPUT_NAMES:', 'roster_names != CALIBRATION_RUNTIME_INPUT_NAMES:') if False else s
# candidate already has version-specific validation blocks, inspect exact shapes below.
save(P+'execution_basis.py',s)
