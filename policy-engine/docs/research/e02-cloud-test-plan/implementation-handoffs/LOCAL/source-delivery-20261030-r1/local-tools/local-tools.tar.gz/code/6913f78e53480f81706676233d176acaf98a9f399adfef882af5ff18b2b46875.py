from pathlib import Path
import ast,difflib,hashlib,json,subprocess,tomllib
R=Path.cwd();D1=R/'LOCAL/raw/e02-execution-20261027/repairs/C97-census-oracle-r1';D=R/'LOCAL/raw/e02-execution-20261027/repairs/C97-census-oracle-r2'
D.mkdir(exist_ok=False)
T='policy-engine/tests/repo_quality/tools/test_e02_installed_census_contract.py'
s=(D1/'postimages'/T).read_text(); original=s
s=s.replace('import atexit, base64, configparser, csv, hashlib, importlib.machinery','import atexit, base64, configparser, csv, hashlib, importlib.machinery, inspect, marshal')
s=s.replace('import io, json, os, stat, subprocess, sys, time, zipfile','import io, json, os, stat, subprocess, sys, time, tomllib, zipfile')
old='''            origins, origin_errors = gate.verify_loaded_module_origins(purelib, sys.modules.copy())
            if origin_errors:
                raise ValueError("Q2 loaded-origin refusal: " + repr(origin_errors))
            required = {"tools", "tools.cli", "tools.quality.validation.schema_fqn_census"}
            if not required.issubset(origins):
                raise ValueError("real public census modules did not execute")
            report["origins"] = origins
            report["sys_path_at_finish"] = list(sys.path)
'''
assert old in s;s=s.replace(old,'')
needle='''                for name, origin in origins.items():
                    if not (name == "tools" or name.startswith("tools.")
                            or name == "polisyos" or name.startswith("polisyos.")):
                        continue
                    if "file" not in origin:  # Q2 already checked finite namespace locations.
                        continue
                    module = sys.modules[name]
'''
replacement='''                entrypoints = configparser.ConfigParser()
                entrypoints.read_string(wheel.read(record_name.rsplit("/", 1)[0]
                                                   + "/entry_points.txt").decode("utf-8"))
                declared = entrypoints["console_scripts"]["polisyos-tools"].strip()
                project = tomllib.loads(git_bytes("cat-file", "blob", actual_head
                                                 + ":policy-engine/pyproject.toml").decode("utf-8"))
                if declared != project["project"]["scripts"]["polisyos-tools"]:
                    raise ValueError("wheel entrypoint differs from immutable pyproject")
                declared_module, separator, declared_attribute = declared.partition(":")
                if (not separator or not all(part.isidentifier() for part in declared_module.split("."))
                        or not all(part.isidentifier() for part in declared_attribute.split("."))):
                    raise ValueError("unsupported console entrypoint declaration")
                mode = os.environ["C97_ENTRYPOINT"]
                main_module = sys.modules["__main__"]
                main_path = Path(main_module.__file__).resolve(strict=True)
                cli = Path(_binding["cli"]).resolve(strict=True)
                if mode == "console":
                    entry_module = sys.modules.get(declared_module)
                    if entry_module is None:
                        raise ValueError("console did not load its actual declared entry module")
                elif mode == "module":
                    # runpy executes the declared file in __main__.  This is an
                    # explicit execution-role view, not a sys.modules alias.
                    entry_module = main_module
                    if not sys.flags.isolated:
                        raise ValueError("actual module invocation is not isolated")
                else:
                    raise ValueError("unsupported actual CLI invocation mode")
                entry_spec = getattr(entry_module, "__spec__", None)
                if entry_spec is None or entry_spec.name != declared_module:
                    raise ValueError("executing module spec differs from the declared entrypoint")
                # Reuse one Q2 origin invariant for ordinary loaded modules and
                # this actual executing entry module; never mutate sys.modules.
                cached = sys.modules.copy()
                origins, origin_errors = gate.verify_loaded_module_origins(purelib, cached)
                entry_origins, entry_errors = gate.verify_loaded_module_origins(
                    purelib, {declared_module: entry_module})
                if origin_errors or entry_errors:
                    raise ValueError("Q2 loaded/entry origin refusal: "
                                     + repr(origin_errors + entry_errors))
                required = {"tools", "tools.quality.validation.schema_fqn_census"}
                if not required.issubset(origins):
                    raise ValueError("real public census modules did not execute")
                entry_origin = entry_origins[declared_module]
                entry_file = Path(entry_origin["resolved_file"])
                entry_member = entry_file.relative_to(purelib).as_posix()
                # Derive module layout from declared metadata AND actual archive
                # membership; no tools/cli package pathname is assumed.
                stem = declared_module.replace(".", "/")
                candidates = [path for path in (stem + ".py", stem + "/__init__.py")
                              if path in wheel_record]
                if candidates != [entry_member]:
                    raise ValueError("actual entry spec does not select the unique wheel module")
                if mode == "module" and main_path != entry_file:
                    raise ValueError("actual runpy __main__ is not the declared module file")
                callable_object = entry_module
                for attribute in declared_attribute.split("."):
                    callable_object = getattr(callable_object, attribute)
                if (not inspect.isfunction(callable_object)
                        or callable_object.__globals__ is not entry_module.__dict__
                        or Path(callable_object.__code__.co_filename).resolve(strict=True) != entry_file):
                    raise ValueError("actual entry callable code is not defined by the admitted module")
                subjects = [(name, name, cached[name], origin)
                            for name, origin in origins.items()
                            if name == "tools" or name.startswith("tools.")
                            or name == "polisyos" or name.startswith("polisyos.")]
                # The existing cache entry (if any) remains in subjects.  Add the
                # runpy execution object separately, even when it has no alias.
                if mode == "module":
                    subjects.append(("__main__", declared_module, entry_module, entry_origin))
                report["origins"] = origins
                report["entrypoint_execution"] = {
                    "declared": declared, "invocation_mode": mode,
                    "actual_name": entry_module.__name__, "spec_name": entry_spec.name,
                    "spec_origin": entry_spec.origin, "source_member": entry_member,
                    "canonical_cache_present": declared_module in cached,
                    "canonical_cache_is_execution_object": cached.get(declared_module) is entry_module,
                    "actual_origin": entry_origin,
                    "callable_module": callable_object.__module__,
                    "callable_qualname": callable_object.__qualname__,
                    "callable_code_filename": callable_object.__code__.co_filename,
                    "callable_code_sha256": _digest(marshal.dumps(callable_object.__code__)),
                    "code_boundary": "standard source loader/fresh cache; code snapshot is not a call trace",
                }
                report["sys_path_at_finish"] = list(sys.path)
                for name, canonical_name, module, origin in subjects:
                    if "file" not in origin:  # Q2 already checked finite namespace locations.
                        continue
'''
assert needle in s;s=s.replace(needle,replacement)
s=s.replace('''                    if type(module.__spec__.loader) is not importlib.machinery.SourceFileLoader:
                        raise ValueError("product module is not standard file-backed source: " + name)
                    path = Path(origin["resolved_file"])
''','''                    if (module.__spec__.name != canonical_name
                            or type(module.__spec__.loader) is not importlib.machinery.SourceFileLoader):
                        raise ValueError("product execution spec/loader differs: " + name)
                    path = Path(origin["resolved_file"])
                    if (module.__spec__.loader.name != canonical_name
                            or Path(module.__spec__.loader.path).resolve(strict=True) != path):
                        raise ValueError("actual source loader does not select its reported file: " + name)
''')
s=s.replace('''                    loaded[name] = {"member": relative, "bytes": len(data), "sha256": _digest(data),
''','''                    loaded[name] = {"canonical_module": canonical_name,
                                    "actual_module_name": module.__name__,
                                    "member": relative, "bytes": len(data), "sha256": _digest(data),
''')
old='''                entrypoints = configparser.ConfigParser()
                entrypoints.read_string(wheel.read(record_name.rsplit("/", 1)[0]
                                                   + "/entry_points.txt").decode("utf-8"))
                if entrypoints["console_scripts"]["polisyos-tools"].strip() != "tools.cli:main":
                    raise ValueError("wheel public entrypoint differs")
                main_path = Path(sys.modules["__main__"].__file__).resolve(strict=True)
                cli = Path(_binding["cli"]).resolve(strict=True)
                if os.environ["C97_ENTRYPOINT"] == "console":
'''
new='''                if mode == "console":
'''
assert old in s;s=s.replace(old,new)
s=s.replace('''                    report["console_sha256"] = _digest(script)
                else:
                    if main_path != purelib / "tools/cli/__main__.py" or not sys.flags.isolated:
                        raise ValueError("actual module CLI is not isolated installed __main__")
''','''                    if getattr(main_module, "__spec__", None) is not None:
                        raise ValueError("direct console wrapper unexpectedly has a module spec")
                    if not any(value is callable_object for value in main_module.__dict__.values()):
                        raise ValueError("native console wrapper does not hold its declared callable")
                    report["console_wrapper"] = {
                        "path": str(cli), "bytes": len(script), "sha256": _digest(script),
                        "installed_record_key": console_relative,
                        "spec_name": None,
                        "origin_kind": "installer-generated script, not a wheel/Git module member",
                        "delegates_to": declared,
                        "callable_is_admitted_module_object": True,
                    }
''')
assert 'tools/cli/__main__.py' not in s
# No oracle/fixture/consumer execution changes: preserve every outer definition.
a1=ast.parse(original);a2=ast.parse(s)
def outer_functions(tree):
 return {n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
assert outer_functions(a1)==outer_functions(a2)
o1=next(n.value.value for n in a1.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CHILD_OBSERVER' for t in n.targets))
o2=next(n.value.value for n in a2.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CHILD_OBSERVER' for t in n.targets))
ast.parse(o2)
post=D/'postimages'/T;post.parent.mkdir(parents=True);post.write_text(s)
m1=json.loads((D1/'manifest.json').read_text());review=R/'LOCAL/raw/e02-execution-20261027/reviews/C97-repair-source-independent.md'
assert hashlib.sha256(review.read_bytes()).hexdigest()=='7fa5056ad44f3e45896c13c34412e6a0fcd4fb92b0d7105bde2d784e870cb9c7'
old_doc='policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/C97/REPAIR-r1.md';new_doc=old_doc.replace('REPAIR-r1','REPAIR-r2')
old_recipe='policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/C97/EXECUTION-r1.md';new_recipe=old_recipe.replace('EXECUTION-r1','EXECUTION-r2')
rel=next(x['path'] for x in m1['proposal_files'] if x['path'].endswith('.toml'))
new_obs=hashlib.sha256(o2.encode()).hexdigest(); old_obs=hashlib.sha256(o1.encode()).hexdigest()
for old,new in [(old_doc,new_doc),(old_recipe,new_recipe),(rel,rel)]:
 text=(D1/'postimages'/old).read_text().replace('C97 census-oracle repair r1','C97 census-oracle repair r2').replace('C97 immutable execution recipe r1','C97 immutable execution recipe r2').replace('REPAIR-r1.md','REPAIR-r2.md').replace('EXECUTION-r1.md','EXECUTION-r2.md').replace(old_obs,new_obs)
 if new==new_doc:
  text+='''\n## Delta from independently reviewed r1\n\nIndependent full-batch source review `reviews/C97-repair-source-independent.md` (relative to `LOCAL/raw/e02-execution-20261027/`) SHA-256 `7fa5056ad44f3e45896c13c34412e6a0fcd4fb92b0d7105bde2d784e870cb9c7` gives GO_SOURCE for the exact-set/digest oracle, with the sole source HOLD `C97-R1-ENTRY-01`. R2 addresses that same C97-RET-02 consumer/origin class one level deeper, not a new parser defect or hostile-host attestation layer. R1 remains frozen.\n\nThe wheel's actual `console_scripts` declaration is reconciled to immutable pyproject bytes. A single entry-module reconciliation uses the actual executing module's spec/name/origin/standard loader, selected wheel member, installed RECORD and source Git bytes. In module mode, the executing object is `sys.modules["__main__"]` with `__spec__.name == "tools.cli"`; its file at this input is `tools/cli.py`. The Q2 gate receives an explicitly labelled execution-role view and the normal cached-origin view separately; no canonical alias is invented or inserted into sys.modules, and any real cache entry is still verified. The runtime callable/code snapshot is bound to that admitted defining module and fresh-cache source-loader profile.\n\nIn console mode, the actual canonical entry module undergoes the same content/spec invariant, while the real `__main__` is the installer-generated wrapper. That wrapper is checked against the actual installed RECORD, shebang/interpreter and declared callable identity, reported as an installer product rather than a nonexistent wheel/Git module. Retain its small actual bytes once per profile. The code snapshot is not a call-trace claim. No outer fixture, independent Git oracle, changed-set/digest assertion, M1 override, parameter extent, missing-log disposition or outcome claim changes in r2. Positive/module/console/M1/restored runtime remains UNRUN.\n'''
 if new==new_recipe:
  text+='''\n## R2 entrypoint profile reconciliation\n\nThis revision is a source correction for `C97-R1-ENTRY-01`; r1 is immutable. The actual source-owned declaration is pyproject `polisyos-tools = "tools.cli:main"`, with the wheel's real entry_points.txt reconciled against it. `tools.cli` is a source module (`tools/cli.py`) at this input, not a `tools/cli` package. Use the same two actual CLI commands above; do not import the canonical alias as a workaround for `-m`, add a package stub, change invocation to make a guessed path true or drop its binding.\n\nFor `-m`, the observer binds the real `__main__` spec/origin/standard-source-loader/member/RECORD/Git bytes through an explicitly labelled Q2 entry-module view; it does not require `tools.cli` to exist in the module cache. Preserve all genuine cached module subjects separately. For the direct console script, bind the actual loaded declaration target through that same module invariant, while retaining the real wrapper's installed RECORD/shebang and callable identity. It is installer-generated code, not a wheel/Git module. Add exactly the small actual `<prefix>/bin/polisyos-tools` regular-file bytes once per artifact profile to the deciding delivery allowlist, along with its hash/size/installed RECORD key and installer version; do not copy the prefix.\n\nNo runtime was run during r2 preparation. Root still owes physical logical-path Ruff/format and typed release-fragment validation before publication, and the future exact actual installed positive/M1/restored execution. Those are current UNRUN checks; the old32PASS/3SKIP records and unavailable logs are unchanged.\n'''
 dest=D/'postimages'/new;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(text)
# Independent syntax + immutable preimages only: no product imports or runtime.
paths=[T,new_doc,rel,new_recipe]
m=dict(m1);m['schema']='policyos.e02.c97.oracle_repair.v2';m['status']='FROZEN_R2_AUTHOR_PROPOSAL_PENDING_DELTA_REVIEW_RUNTIME_UNRUN'
m['prior_revision']={'path':'LOCAL/raw/e02-execution-20261027/repairs/C97-census-oracle-r1','manifest_sha256':hashlib.sha256((D1/'manifest.json').read_bytes()).hexdigest(),'delivery_index_sha256':hashlib.sha256((D1/'delivery-index.json').read_bytes()).hexdigest()}
m['delta_review_input']={'path':str(review.relative_to(R)),'sha256':hashlib.sha256(review.read_bytes()).hexdigest(),'finding':'C97-R1-ENTRY-01','bucket':'same C97-RET-02 class one level deeper'}
m['observer_sha256']=new_obs;m['r1_observer_sha256']=old_obs;m['outer_functions_ast_identical_to_r1']=True
m['proposal_files']=[]
for path in paths:
 data=(D/'postimages'/path).read_bytes();preblob='38069b822aae8c0ae1ac20ec1612382ef43465d7' if path==T else None
 pre=subprocess.check_output(['git','cat-file','blob',preblob]) if preblob else b''
 m['proposal_files'].append({'path':path,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'candidate_preimage_git_blob':preblob,'candidate_preimage_sha256':hashlib.sha256(pre).hexdigest() if pre else None,'postimage':'postimages/'+path,'root_r7_path_absent':True})
(D/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
for mode in ['root-intake','candidate-repair']:
 patches=[]
 for path in paths:
  pre=subprocess.check_output(['git','cat-file','blob','38069b822aae8c0ae1ac20ec1612382ef43465d7']).decode() if mode=='candidate-repair' and path==T else ''
  post=(D/'postimages'/path).read_text();patches.append('diff --git a/'+path+' b/'+path+'\n')
  if not pre:patches.append('new file mode 100644\n')
  patches.extend(difflib.unified_diff(pre.splitlines(keepends=True),post.splitlines(keepends=True),fromfile='a/'+path if pre else '/dev/null',tofile='b/'+path))
 (D/(mode+'.diff')).write_text(''.join(patches))
(D/'r1-test-delta.diff').write_text(''.join(difflib.unified_diff(original.splitlines(keepends=True),s.splitlines(keepends=True),fromfile='r1/'+T,tofile='r2/'+T)))
# The builder is retained once in r2 so all proposal-generating bytes are delivered.
this=Path(__file__).read_bytes();(D/'prepare_c97_r2.py').write_bytes(this)
print(json.dumps({'r2_test_bytes':len(s.encode()),'r2_test_sha256':hashlib.sha256(s.encode()).hexdigest(),'r2_observer_sha256':new_obs,'outer_functions_ast_identical':True,'proposal_files':len(paths)}))
