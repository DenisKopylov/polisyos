from pathlib import Path
p=Path(__file__).parent/'policy-engine/src/polisyos/scientist/orchestration/llm/prompt_cache.py';s=p.read_text()
s=s.replace('import uuid\n','import uuid\nimport weakref\n')
s=s.replace('    create_cache_settlement_session,\n','    bind_cache_settlement_client,\n    session_for_cache_client,\n')
s=s.replace('    outcome: CacheFlightOutcome | None = None\n\n\nclass _CacheReuseGatewayResponse','    outcome: CacheFlightOutcome | None = None\n    snapshot: _SerializedGatewayResponse | None = None\n    waiters: int = 0\n    released: bool = False\n\n\n@dataclass(slots=True)\nclass _SharedCacheState:\n    lock: Any = field(default_factory=threading.RLock)\n    inflight: dict[tuple[asyncio.AbstractEventLoop, str], _CacheFlight] = field(default_factory=dict)\n\n\n_SHARED_CACHE_STATES_LOCK = threading.RLock()\n_SHARED_CACHE_STATES: dict[int, tuple[weakref.ReferenceType[object], _SharedCacheState]] = {}\n\n\ndef _shared_cache_state(cache: object) -> _SharedCacheState:\n    cache_id = id(cache)\n    with _SHARED_CACHE_STATES_LOCK:\n        current = _SHARED_CACHE_STATES.get(cache_id)\n        if current is not None and current[0]() is cache:\n            return current[1]\n        state = _SharedCacheState()\n        def discard(reference: weakref.ReferenceType[object]) -> None:\n            with _SHARED_CACHE_STATES_LOCK:\n                current = _SHARED_CACHE_STATES.get(cache_id)\n                if current is not None and current[0] is reference:\n                    del _SHARED_CACHE_STATES[cache_id]\n        _SHARED_CACHE_STATES[cache_id] = (weakref.ref(cache, discard), state)\n        return state\n\n\nclass _CacheReuseGatewayResponse')
s=s.replace('                del self._store[cache_key]\n                self._telemetry.expired', '                del self._store[cache_key]\n                self._forget_origin(cache_key)\n                self._telemetry.expired')
s=s.replace('                self._store.popitem(last=False)\n                self._telemetry.evictions', '                evicted_key, _ = self._store.popitem(last=False)\n                self._forget_origin(evicted_key)\n                self._telemetry.evictions')
s=s.replace('    def clear(self) -> None:\n        with self._lock:\n            self._store.clear()', '    def clear(self) -> None:\n        with self._lock:\n            for cache_key in self._store:\n                self._forget_origin(cache_key)\n            self._store.clear()')
s=s.replace('    def stats(self) -> dict[str, Any]:', '    def _forget_origin(self, cache_key: str) -> None:\n        session = session_for_cache_client(self)\n        if session is not None:\n            session.forget_cached_key(cache_key)\n\n    def stats(self) -> dict[str, Any]:')
s=s.replace('        self._inflight: dict[str, _CacheFlight] = {}','        self._shared_cache_state = _shared_cache_state(cache)\n        # Legacy private inspection sees the actual cache-owned flights.\n        self._inflight = self._shared_cache_state.inflight')
s=s.replace('        self._cache_settlement_owner = cache\n        self._cache_settlement_session = create_cache_settlement_session(cache)','        self._cache_settlement_session = bind_cache_settlement_client(cache, self)')
start=s.index('        attempt_id = f"cache-attempt:');end=s.index('    def _ordinary_scope_key',start)
s=s[:start]+'''        flight_key = (asyncio.get_running_loop(), internal_cache_key)
        with self._shared_cache_state.lock:
            cached = self._cache.get(internal_cache_key)
            if cached is not None:
                logger.debug("Prompt cache hit model={} key={}", self._model, cache_key[:12])
                if isinstance(cached, GatewayLLMResponse):
                    return self._reuse_response(
                        cached, cache_key=internal_cache_key, request_digest=request_digest
                    )
                return cached
            self._cache_settlement_session.forget_cached_key(internal_cache_key)
            attempt_id = f"cache-attempt:{uuid.uuid4().hex}"
            registration = self._cache_settlement_session.register_request(
                scope_key, request_digest, attempt_id
            )
            self._cache_settlement_session.bind_request_key(registration, internal_cache_key)
            flight = self._inflight.get(flight_key)
            is_owner = flight is None
            if is_owner:
                self._cache_settlement_session.dispatch(registration, attempt_id)
                producer_event_id = f"llm-provider:{uuid.uuid4().hex}"
                owner_task = asyncio.create_task(
                    self._produce(
                        internal_cache_key,
                        args,
                        _provider_kwargs(kwargs),
                        request_digest=request_digest,
                        scope_key=scope_key,
                        producer_attempt_id=attempt_id,
                        producer_event_id=producer_event_id,
                    )
                )
                flight = _CacheFlight(
                    task=owner_task,
                    request_digest=request_digest,
                    scope_key=scope_key,
                    owner_registration=registration,
                    registrations=[registration],
                    producer_attempt_id=attempt_id,
                    origin_event_id=producer_event_id,
                    cache_key=internal_cache_key,
                )
                self._inflight[flight_key] = flight
                owner_task.add_done_callback(_consume_task_exception)
            else:
                self._cache_settlement_session.join(
                    registration, scope_key, request_digest, internal_cache_key, attempt_id
                )
                flight.registrations.append(registration)
            flight.waiters += 1

        try:
            response = await asyncio.shield(flight.task)
            if is_owner:
                return response
            # A follower consumes its exact flight snapshot, never the mutable
            # current cache head (another event loop may have replaced it).
            if flight.snapshot is not None:
                return self._reuse_response(
                    _thaw_response(flight.snapshot),
                    cache_key=internal_cache_key,
                    request_digest=request_digest,
                    origin_event_id=flight.origin_event_id,
                    outcome=flight.outcome,
                )
            return response
        finally:
            with self._shared_cache_state.lock:
                flight.waiters -= 1
                self._release_completed_flight(flight)

    def _release_completed_flight(self, flight: _CacheFlight) -> None:
        if flight.waiters or not flight.task.done() or flight.released:
            return
        self._cache_settlement_session.release_flight(
            tuple(flight.registrations), flight.outcome
        )
        flight.released = True

'''+s[end:]
s=s.replace('        flight = self._inflight.get(cache_key)\n','        flight_key = (asyncio.get_running_loop(), cache_key)\n        flight = self._inflight.get(flight_key)\n',1)
start=s.index('            self._cache.put(cache_key, response, ttl_s=self._ttl_s)');end=s.index('            return response',start)
s=s[:start]+'''            with self._shared_cache_state.lock:
                if flight is not None:
                    flight.outcome = self._cache_settlement_session.settle_flight(
                        registrations=tuple(flight.registrations),
                        cache_key=cache_key,
                        request_digest=request_digest,
                        producer_attempt_id=producer_attempt_id,
                        terminal="success",
                        origin_event_id=producer_event_id,
                    )
                    if isinstance(response, GatewayLLMResponse):
                        flight.snapshot = _freeze_response(response)
                try:
                    self._cache.put(cache_key, response, ttl_s=self._ttl_s)
                except BaseException:
                    self._cache_settlement_session.forget_cached_key(cache_key)
                    raise
            logger.debug("Prompt cache miss model={} key={}", self._model, cache_key[:12])
'''+s[end:]
s=s.replace('                self._inflight.get(cache_key) is flight','                self._inflight.get(flight_key) is flight')
s=s.replace('                self._inflight.pop(cache_key, None)','                with self._shared_cache_state.lock:\n                    self._inflight.pop(flight_key, None)\n                # Task.done() is false inside its finally. Run cleanup after\n                # completion when a cancelled last waiter already left.\n                current_task.add_done_callback(lambda _task: self._release_completed_flight(flight))')
p.write_text(s)
