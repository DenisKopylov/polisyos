"""Author microprobe: execute helper alone, with no PolicyOS or JAX imports."""
from pathlib import Path
from types import MethodType
import hashlib
import json
import sys

owner = Path(__file__).parent / 'postimages/policy-engine/src/polisyos/foundry/methods/_internal/executable_identity.py'
source = owner.read_bytes()
namespace = {'__name__': 'c60_private_identity_probe', '__file__': str(owner)}
exec(compile(source, str(owner), 'exec'), namespace)
Identity = namespace['_ExecutableIdentity']

def operation(state, params):
    return state + 1

def replacement(state, params):
    return state + 2

class Owner:
    pass

class Proxy:
    __code__ = operation.__code__
    def __call__(self, state, params):
        return state + 3

class Bound:
    def operation(self, state, params):
        return state

baseline = Identity(Owner, operation, ('abi', (), ()))
assert baseline == Identity(Owner, operation, ('abi', (), ()))
assert hash(baseline) == hash(Identity(Owner, operation, ('abi', (), ())))
assert baseline != Identity(Owner, operation, ('abi', (), (('slot', '(0, 1)'),)))
proxy = Proxy()
assert Identity(Owner, proxy, 'abi') != Identity(Owner, proxy, 'abi')
bound = Bound().operation
assert isinstance(bound, MethodType)
assert Identity(Owner, bound, 'abi') == Identity(Owner, bound, 'abi')
operation.__code__ = replacement.__code__
assert baseline != Identity(Owner, operation, ('abi', (), ()))
print(json.dumps({'result':'PASS','python':sys.version,'helper_sha256':hashlib.sha256(source).hexdigest(),'scope':'helper identity only; real compiler/fusion/dispatch/control and Ray UNRUN','checks':['same Python function binding','slot-signature token difference','opaque fake code marker is unshared','same bound method object','changed code object']}))
