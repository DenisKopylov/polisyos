"""In-memory C59 property removals for an already frozen native source.

Load explicitly with pytest's ``-p c59_removal_plugin``. The file and compiled
function identities are checked before a named, single-owner mutation is made.
No source, Git index or fixture is edited. A removal run is successful only
when its corresponding real behavioral test fails for the expected reason.
"""

from __future__ import annotations
import __future__

import ast
import hashlib
import inspect
import os
import sys
import textwrap
from pathlib import Path
from types import CodeType
from typing import Any

SOURCE_SHA256 = "6b59fe5415227d58dacb97334317c5d1cf13e3b5abf0ff095157bd42f78811b1"
TEST_SHA256 = "b0ef6f35358ef11c9aab3c2cc214b5be222d59a6032d7c681715c09fab4d2845"
MODES = {"minimum", "spec", "bytes-node", "carrier", "policy"}


def _fingerprint(code: CodeType) -> tuple[Any, ...]:
    consts = tuple(
        _fingerprint(value) if isinstance(value, CodeType) else value for value in code.co_consts
    )
    return (
        code.co_code,
        code.co_names,
        code.co_varnames,
        code.co_freevars,
        code.co_cellvars,
        code.co_argcount,
        code.co_posonlyargcount,
        code.co_kwonlyargcount,
        code.co_flags,
        consts,
    )


def _call_name(node: ast.AST, name: str) -> bool:
    return (
        isinstance(node, ast.Expr)
        and isinstance(node.value, ast.Call)
        and isinstance(node.value.func, ast.Name)
        and node.value.func.id == name
    )


class _Removal(ast.NodeTransformer):
    def __init__(self, mode: str) -> None:
        self.mode = mode
        self.count = 0

    def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.AST:
        if self.mode == "minimum" and node.name == "require_minimum":
            self.count += 1
            node.body = [ast.Pass()]
            return node
        return self.generic_visit(node)

    def visit_Assign(self, node: ast.Assign) -> ast.AST:
        if (
            self.mode == "spec"
            and len(node.targets) == 1
            and isinstance(node.targets[0], ast.Name)
            and node.targets[0].id == "spec"
            and isinstance(node.value, ast.Call)
            and isinstance(node.value.func, ast.Name)
            and node.value.func.id == "_admit_canon_spec"
        ):
            self.count += 1
            node.value = ast.Name(id="spec", ctx=ast.Load())
        return self.generic_visit(node)

    def visit_If(self, node: ast.If) -> ast.AST:
        if (
            self.mode == "policy"
            and "len(canonical_types) > len(_ALL_CANONICAL_TYPES)" in ast.unparse(node.test)
        ):
            self.count += 1
            node.test = ast.Constant(value=False)
        if (
            self.mode == "bytes-node"
            and ast.unparse(node.test) == "name == 'data' and base64_length is not None"
        ):
            kept = [part for part in node.body if not _call_name(part, "take_element")]
            self.count += len(node.body) - len(kept)
            node.body = kept
        return self.generic_visit(node)

    def visit_Expr(self, node: ast.Expr) -> ast.AST | None:
        if self.mode == "carrier" and _call_name(node, "_require_carrier_profile"):
            self.count += 1
            return None
        return self.generic_visit(node)


def pytest_configure() -> None:
    """Install exactly one falsifier into the already imported real owner."""
    mode = os.environ.get("C59_REMOVAL")
    if mode not in MODES:
        raise RuntimeError(f"C59_REMOVAL must select exactly one of {sorted(MODES)}")

    from polisyos.common import canonical
    from polisyos.core.canon import canon_json

    source_path = Path(canonical.__file__).resolve()
    test_path = Path("tests/unit/common/test_canonical_v3.py").resolve()
    if hashlib.sha256(source_path.read_bytes()).hexdigest() != SOURCE_SHA256:
        raise RuntimeError("C59 removal source SHA-256 mismatch")
    if hashlib.sha256(test_path.read_bytes()).hexdigest() != TEST_SHA256:
        raise RuntimeError("C59 removal test SHA-256 mismatch")

    function_name = "_canonicalize_obj" if mode == "carrier" else "to_bounded_canonical_bytes"
    original = getattr(canonical, function_name)
    if Path(original.__code__.co_filename).resolve() != source_path:
        raise RuntimeError("C59 removal loaded function has the wrong source path")
    source = textwrap.dedent(inspect.getsource(original))
    flags = __future__.annotations.compiler_flag
    original_scope = dict(canonical.__dict__)
    exec(  # noqa: S102 - compare the admitted source with the active function.
        compile(source, str(source_path), "exec", flags=flags, dont_inherit=True), original_scope
    )
    if _fingerprint(original_scope[function_name].__code__) != _fingerprint(original.__code__):
        raise RuntimeError("C59 removal loaded bytecode does not match the frozen source")

    tree = ast.parse(source)
    removal = _Removal(mode)
    tree = removal.visit(tree)
    expected = 3 if mode == "carrier" else 1
    if removal.count != expected:
        raise RuntimeError(f"C59 removal matched {removal.count} nodes, expected {expected}")
    ast.fix_missing_locations(tree)
    scope = canonical.__dict__
    exec(  # noqa: S102 - install the selected removal in memory only.
        compile(tree, f"{source_path}::<C59-{mode}>", "exec", flags=flags, dont_inherit=True), scope
    )
    if mode != "carrier":
        # Core imports the shared function by value; mutate the real Core path too.
        canon_json._to_bounded_canonical_bytes = scope[function_name]
    sys.stderr.write(
        f"C59 removal active: {mode}; source_sha256={SOURCE_SHA256}; "
        f"test_sha256={TEST_SHA256}; mutations={removal.count}\n"
    )
