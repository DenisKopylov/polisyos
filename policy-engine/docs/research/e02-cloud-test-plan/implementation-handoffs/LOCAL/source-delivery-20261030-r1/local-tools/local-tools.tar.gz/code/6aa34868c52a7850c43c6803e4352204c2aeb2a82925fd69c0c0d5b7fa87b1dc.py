from pathlib import Path
import shutil
root = Path('LOCAL/raw/e02-execution-20261027/repairs/C41-r2')
pre = root / 'preimages/policy-engine'
post = root / 'postimages/policy-engine'
gen = post / 'src/polisyos/runtime/quality/generation_cycle.py'
s = gen.read_text()
old = (pre / 'src/polisyos/runtime/quality/generation_cycle.py').read_text()
start = s.index('def simulation_evaluation_input_ref(')
end = s.index('\ndef simulation_value_execution_context(', start)
a = old.index('def simulation_evaluation_input_ref(')
b = old.index('\ndef simulation_value_execution_context(', a)
s = s[:start] + old[a:b] + s[end:]
s = s.replace('        "interaction_numeric_classification_unsupported",\n    }\n)\n# Exhaustive typed projection partition.', '        "interaction_numeric_classification_unsupported",\n        "n5_execution_request_provenance_not_established",\n    }\n)\n# Exhaustive typed projection partition.', 1)
s = s.replace('    """Project N5 only after the producer owner verifies the actual request binding."""', '    """Project an N5 candidate and distinguish absent request from a mismatch."""', 1)
s = s.replace('''            if request is None:
                raise JointSimulationControllerError("selected_plan_execution_binding_missing")
            (controller or JointSimulationHorizonController()).validate_selected_result(
                request=request, result=result
            )''', '''            if request is not None:
                (controller or JointSimulationHorizonController()).validate_selected_result(
                    request=request, result=result
                )
            elif not any(item.decision == "selected" for item in result.engine_decisions):
                raise JointSimulationControllerError("selected_plan_execution_binding_missing")''', 1)
s = s.replace('''    return "joint_simulated", tuple(dict.fromkeys(str(item) for item in blockers))


def persist_joint_simulation_result''', '''    if request is None:
        blockers.append("n5_execution_request_provenance_not_established")
    return "joint_simulated", tuple(dict.fromkeys(str(item) for item in blockers))


def persist_joint_simulation_result''', 1)
s = s.replace('''    if not generic_refs_present:
        return _blocked_value_observation(
            code="n5_execution_request_binding_not_established",
            reason="N8 requires an owner-replayed N5 request and selected result view.",
            mode="simulate_only",
            started=started,
            candidate_id=candidate_id,
            world_model_record_content_hash=world_hash,
        )
''', '''    if not generic_refs_present:
        # Historical results may remain useful, but no selected owner request
        # is recoverable here; never silently promote that absence to authority.
        blockers.add("n5_execution_request_provenance_not_established")
''', 1)
gen.write_text(s)
# Do not change recursive compatibility validators until their selected owner
# request and mixed historical/new composition semantics are wired.
shutil.copyfile(pre / 'src/polisyos/runtime/quality/recursive_generation_cycle.py', post / 'src/polisyos/runtime/quality/recursive_generation_cycle.py')
test = post / 'tests/unit/remediation/test_sim_01.py'
s = test.read_text()
s = s.replace('assert _joint_simulation_is_unsupported(result, request) is False', 'assert _joint_simulation_is_unsupported(result) is False', 1)
s = s.replace('''def test_generation_consumer_refuses_result_without_owner_request() -> None:
    """B06: a selected marker and content receipt do not recover a missing request."""
    result = JointSimulationHorizonController().run(_single_step_request())
    status, blockers = _joint_simulation_port_outcome(result)
    assert status == "simulation_blocked"
    assert "selected_plan_execution_binding_missing" in blockers
''', '''def test_generation_consumer_retains_candidate_without_owner_request() -> None:
    """Historical N5 remains candidate-only with the missing provenance declared."""
    result = JointSimulationHorizonController().run(_single_step_request())
    status, blockers = _joint_simulation_port_outcome(result)
    assert status == "joint_simulated"
    assert "n5_execution_request_provenance_not_established" in blockers
''', 1)
# The old test purported to turn a candidate input reference into authority.
# Remove it; the future behavioral gate test must exercise an actual protected
# consumer with a resolved owner request and a same-ref foreign trajectory.
start = s.index('\ndef test_eval_safety_does_not_promote_a_consumer_asserted_simulation_status(')
s = s[:start] + '\n'
test.write_text(s)
route = post / 'src/polisyos/runtime/http/routes/runs.py'
s = route.read_text()
s = s.replace('''                        if not set(actual_blockers).issubset(blockers):
                            raise ValueError("n5_result_blockers_binding_mismatch")''', '''                        added = set(actual_blockers) - set(blockers)
                        if added - {"n5_execution_request_provenance_not_established"}:
                            raise ValueError("n5_result_blockers_binding_mismatch")
                        blockers = tuple(dict.fromkeys((*blockers, *actual_blockers)))''', 1)
# Embedded parent input is not an independent owner replay; its numeric body
# remains a declared limited candidate.
s = s.replace('''                status, blockers = _joint_simulation_port_outcome(
                    parent_result, request=node.joint_simulation_request
                )''', '''                status, blockers = _joint_simulation_port_outcome(parent_result)''', 1)
s = s.replace('''                    expected_request=node.joint_simulation_request,
                    embedded_result=parent_result,''', '''                    embedded_result=parent_result,''', 1)
route.write_text(s)
