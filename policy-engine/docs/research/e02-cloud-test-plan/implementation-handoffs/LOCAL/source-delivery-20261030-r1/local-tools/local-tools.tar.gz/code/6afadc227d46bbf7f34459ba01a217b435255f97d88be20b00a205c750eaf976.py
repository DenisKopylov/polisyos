"""Bind the RAW proposal and check textual patches without importing product code."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import subprocess
import tempfile

root=Path.cwd();base=root/'LOCAL/raw/e02-execution-20261027/repairs/C93-observer-code-identity-r2'
source='23ce492159cc366feed9a73b0ba7d702f1b50c6d'
current=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
sha=lambda data: hashlib.sha256(data).hexdigest()
def git_read(commit,path):
 p=subprocess.run(['git','show',f'{commit}:{path}'],capture_output=True)
 return p.stdout if p.returncode==0 else None
rows=[];diff=[];post=base/'postimages'
for p in sorted(x for x in post.rglob('*') if x.is_file()):
 path=p.relative_to(post).as_posix();original=git_read(source,path);current_git=git_read(current,path)
 working=(root/path).read_bytes() if (root/path).exists() else None
 assert original==current_git==working,(path,'preimage drift')
 data=p.read_bytes()
 if p.suffix=='.py':ast.parse(data,filename=path)
 oid=subprocess.run(['git','rev-parse',f'{source}:{path}'],capture_output=True,text=True)
 rows.append({'path':path,'preimage_blob':oid.stdout.strip() if oid.returncode==0 else None,
              'preimage_sha256':sha(original) if original is not None else None,
              'postimage_sha256':sha(data),'postimage_bytes':len(data)})
 diff.extend(difflib.unified_diff((original or b'').decode().splitlines(keepends=True),data.decode().splitlines(keepends=True),
       fromfile=('a/'+path if original is not None else '/dev/null'),tofile='b/'+path))
patch=''.join(diff).encode();(base/'root-intake.diff').write_bytes(patch)
extra=[]
for path in ('policy-engine/tests/_helpers/code_identity.py','policy-engine/src/polisyos/fabric/connectors/federation/artifact.py'):
 content=git_read(source,path);assert content is not None and content==git_read(current,path)==(root/path).read_bytes()
 extra.append({'path':path,'git_blob':subprocess.check_output(['git','rev-parse',f'{source}:{path}'],text=True).strip(),'sha256':sha(content)})
controls=json.loads((base/'controls/matrix.json').read_text())['controls'];checks=[]
for row in controls:
 path=row['path'];original=(post/path).read_bytes() if (post/path).exists() else git_read(source,path)
 assert original is not None and sha(original)==row['preimage_sha256']
 raw=(base/'controls'/f"{row['id']}.patch").read_bytes();assert sha(raw)==row['patch_sha256']
 with tempfile.TemporaryDirectory(dir=base) as directory:
  scratch=Path(directory);f=scratch/path;f.parent.mkdir(parents=True);f.write_bytes(original)
  patchfile=scratch/'mutation.patch';patchfile.write_bytes(raw)
  proc=subprocess.run(['patch','--fuzz=0','-s','-p1','-i',str(patchfile)],cwd=scratch,capture_output=True,text=True)
  assert proc.returncode==0,(row['id'],proc.stdout,proc.stderr)
  data=f.read_bytes();ast.parse(data,filename=path)
  if 'mutant_sha256' in row:assert sha(data)==row['mutant_sha256']
  checks.append({'id':row['id'],'patch_apply':'PASS_static','mutant_sha256':sha(data),'runtime':'UNRUN'})
(base/'static-readback.json').write_text(json.dumps({'scope':'stdlib AST and scratch patch reconstruction only; no tests or product imports',
    'controls':checks,'runtime':'UNRUN'},indent=2)+'\n')
manifest={'schema':'c93.observer.source-proposal.v1','source_commit':source,
 'source_tree':subprocess.check_output(['git','rev-parse',f'{source}^{{tree}}'],text=True).strip(),
 'observed_current_commit':current,'observed_current_tree':subprocess.check_output(['git','rev-parse',f'{current}^{{tree}}'],text=True).strip(),
 'source_note':'Root advanced concurrently; all proposed and supporting physical preimages match both commits.',
 'common_helper_commit':'f728cfe467a32eb2a9023fbe157d5d06c4928369','files':rows,'unchanged_pinned_support':extra,
 'control_matrix_sha256':sha((base/'controls/matrix.json').read_bytes()),'root_intake_diff_sha256':sha(patch),
 'handoff_sha256':sha((base/'HANDOFF.md').read_bytes()),'static_readback_sha256':sha((base/'static-readback.json').read_bytes()),
 'probe':{'scope':'synthetic stdlib only','result_sha256':sha((base/'probe-result.json').read_bytes()),
          'stdout_sha256':sha((base/'probe.stdout.json').read_bytes()),'stderr_sha256':sha((base/'probe.stderr.txt').read_bytes())},
 'code_review':'PENDING_independent_delta','runtime':'UNRUN','lint':'UNRUN','original_25_controls':'UNRUN','K01_pilot':'UNRUN',
 'installed_first_party':'observed_as_candidate_reconciliation_not_established','bridge_D01_D02':'deferred_UNRUN'}
(base/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'paths':len(rows),'controls':len(checks),'base':source,'current':current,
                  'manifest_sha256':sha((base/'manifest.json').read_bytes()),'diff_sha256':sha(patch)}))
