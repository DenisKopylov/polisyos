from pathlib import Path
import ast,difflib,hashlib,json,subprocess
R=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos');H=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest()
C='policy-engine/tests/unit/scientist/nodes/builtins/compile/test_compile_foundry.py';T='policy-engine/tests/unit/scientist/nodes/builtins/decide/test_policy_runtime_method_metrics.py';D='policy-engine/src/polisyos/scientist/nodes/README.md'
c=(R/C).read_text();start=c.index('def test_compile_node_passes_explicit_metric_binding_and_stores_derived_ref(');end=c.index('\ndef test_compile_node_threads_request_selected_metric_binding(',start);old=c[start:end]
new='''def test_compile_node_passes_explicit_metric_binding_and_stores_derived_ref(
    execution_context,
    minimal_state,
    artifact_ref_factory,
    cas_store,
    tmp_path,
    monkeypatch,
):
    """Real selected inputs reach the constructor-forwarding seam; no execution is claimed."""
    from unit.scientist.nodes.builtins.decide.test_policy_runtime_method_metrics import (
        _exercise_public_execute_method_metric_source,
    )

    from polisyos.core.contracts.execution_plan import ExecutionPlan, MethodDagNode
    from polisyos.scientist.nodes.builtins.state_keys import INPUT_REGISTRY_BUNDLE_REF
    from polisyos.scientist.orchestration.llm.cycle import persist_candidate_execution_plan

    prepared = _exercise_public_execute_method_metric_source(
        tmp_path / "selected-inputs", monkeypatch, artifact_store=cas_store, prepare_only=True
    )
    selected_plan = ExecutionPlan(
        plan_id="constructor_forwarding_plan", run_id=minimal_state.run_id,
        method_dag=[MethodDagNode(
            node_id="ex_ante_node", method_fqn=prepared["method_fqn"],
            method_version=prepared["method_version"], backend=prepared["method_backend"],
            params={"poverty_line": None}, reads_slots=["baseline", "scenario"],
            writes_slots=["result"],
        )],
    )
    selected_plan_ref, trinity_ref = persist_candidate_execution_plan(
        cas_store, selected_plan, prepared["trinity_ref"]
    )
    compile_report_ref = artifact_ref_factory(kind="foundry.compile_report")
    exec_plan_ref = artifact_ref_factory(kind="foundry.exec_plan")
    binding_set_ref = artifact_ref_factory(kind="foundry.method_metric_binding_set")
    selection = MethodMetricBindingRequest(
        objective_id="objective_ex_ante_mean_change", node_id="ex_ante_node", output_slot_id="result"
    )
    mock_foundry = MagicMock()
    mock_foundry.compile.return_value = MagicMock(
        ok=True, compile_report_ref=compile_report_ref, exec_plan_ref=exec_plan_ref,
        derived_refs=[DerivedArtifact(role="method_metric_binding_set", ref=binding_set_ref)],
    )
    ctx = replace(execution_context, foundry=mock_foundry)
    state = minimal_state.model_copy(deep=True)
    state.inputs[INPUT_TRINITY_BUNDLE_REF] = trinity_ref
    state.inputs[INPUT_REGISTRY_BUNDLE_REF] = prepared["registry_ref"]
    state.execution_plan_ref = selected_plan_ref

    outcome = CompileFoundryNode(method_metric_bindings=(selection,)).execute(ctx, state)

    assert outcome.status == "ok", outcome.error
    mock_foundry.compile.assert_called_once()
    request = mock_foundry.compile.call_args.args[1]
    assert request.schema_version == "1.2"
    assert request.policy_ref == trinity_ref
    assert request.method_execution_plan_ref == selected_plan_ref
    assert request.policy_ref.manifest_profile_sha256 is not None
    assert request.method_execution_plan_ref.manifest_profile_sha256 is not None
    assert request.method_metric_bindings == [selection]
    assert outcome.state.artifacts_index[ARTIFACT_METHOD_METRIC_BINDING_SET_REF] == binding_set_ref
    assert ARTIFACT_METHOD_METRIC_BINDING_SET_REF not in state.artifacts_index

'''
cpost=c[:start]+new+c[end:]
t=(R/T).read_text();needle='    returned_inventory = [\n';addition='''    # Derive the expected scalar independently from the actual selected dispatch
    # inputs, including deliberate source-snapshot swaps. Requested arrays and
    # a caller-supplied expected number cannot establish the producer arithmetic.
    from fractions import Fraction

    from polisyos.foundry.execute import read_state_snapshot_inputs_bounded

    dispatch = captured_occurrence.dispatch
    assert dispatch is not None and dispatch.input_state_ref is not None
    captured_inputs = read_state_snapshot_inputs_bounded(
        store, snapshot_ref=dispatch.input_state_ref,
        slot_ids=("baseline", "scenario"), max_manifest_bytes=16 * 1024 * 1024,
        max_snapshot_payload_bytes=16 * 1024 * 1024,
        max_state_blob_bytes=16 * 1024 * 1024, max_entries=32, max_elements=1_000_000,
    )
    captured_arrays = dict(captured_inputs.arrays)
    captured_baseline = captured_arrays["baseline"].tolist()
    captured_scenario = captured_arrays["scenario"].tolist()
    assert captured_baseline and len(captured_baseline) == len(captured_scenario)
    exact_mean = sum(
        (Fraction(right) - Fraction(left) for left, right in zip(captured_baseline, captured_scenario, strict=True)),
        Fraction(),
    ) / len(captured_baseline)
    expected_from_capture = float(exact_mean)
    assert Fraction(expected_from_capture) == exact_mean, (
        "Observed-source fixture must stay inside the exact-float mean profile; "
        f"actual selected rows produce {exact_mean}"
    )
    if execution_data_snapshot_ref is None:
        assert captured_baseline == baseline.tolist()
        assert captured_scenario == scenario.tolist()
    if expected_executed_mean is not None:
        assert expected_executed_mean == expected_from_capture
''';assert t.count(needle)==1;tpost=t.replace(needle,addition+needle,1)
oldexpect='''    assert observation.value == pytest.approx(
        float(np.mean(scenario - baseline))
        if expected_executed_mean is None
        else expected_executed_mean
    )
''';assert tpost.count(oldexpect)==1;tpost=tpost.replace(oldexpect,'    assert observation.value == expected_from_capture\n',1)
needle='        baseline_values=(10.0, 20.0, 41.0),';assert tpost.count(needle)==1;tpost=tpost.replace(needle,'        # Mean0 is exactly representable; mean2/3 belongs to the law\'s honest precision refusal.\n        baseline_values=(10.0, 20.0, 43.0),',1)
needle='    assert a.comparison_contract_sha256 != b.comparison_contract_sha256\n';start=tpost.index('def test_ex_ante_rank_comparison_detects_changed_baseline(');end=tpost.index('\ndef test_ex_ante_rank_refuses_actual_snapshot_different_from_candidate(',start);part=tpost[start:end];assert part.count(needle)==1;part=part.replace(needle,'    assert (a.maximizing_coordinate, b.maximizing_coordinate) == (1.0, 0.0)\n'+needle);tpost=tpost[:start]+part+tpost[end:]
d=(R/D).read_text();dpost=d+'''
Observed ex-ante source fixtures derive their arithmetic oracle from the actual
selected pre-dispatch baseline/scenario rows, independently of producer output
and any caller-provided expected number. A positive fixture must remain inside
the existing exact-float mean profile: the rational mean 2/3 is honestly
unavailable rather than rounded into admissibility. Baseline-comparability
controls use supported explicit inputs; the captured rows and independent mean
remain checked. Constructor-forwarding tests use selected policy/typed-plan refs
and CompileRequest1.2; a mock forwarding result is not real compiler or Runtime
completion evidence. These test repairs do not widen production admission.
'''
records=[];patch=''
for path,pre,post in [(C,c,cpost),(T,t,tpost),(D,d,dpost)]:
 if path.endswith('.py'):
  logical=path.removeprefix('policy-engine/');r=subprocess.run(['.venv/bin/python','-m','ruff','check','--no-cache','--fix','--stdin-filename',logical,'-'],cwd=R/'policy-engine',input=post.encode(),capture_output=True);assert r.returncode==0,r.stdout+r.stderr;post=r.stdout.decode();r=subprocess.run(['.venv/bin/python','-m','ruff','format','--no-cache','--stdin-filename',logical,'-'],cwd=R/'policy-engine',input=post.encode(),capture_output=True);assert r.returncode==0,r.stderr;post=r.stdout.decode();ast.parse(post)
  checks=[]
  for mode in ('check','format'):
   argv=['.venv/bin/python','-m','ruff',mode,'--no-cache']+(['--check'] if mode=='format' else [])+['--stdin-filename',logical,'-'];r=subprocess.run(argv,cwd=R/'policy-engine',input=post.encode(),capture_output=True);assert r.returncode==0,r.stdout+r.stderr;checks.append({'argv':argv,'exit':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode()})
  (H/(Path(path).stem+'-static.json')).write_text(json.dumps(checks,indent=2)+'\n')
 target=H/'postimage'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(post);patch+=''.join(difflib.unified_diff(pre.splitlines(keepends=True),post.splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path));records.append({'path':path,'pre_sha256':sha(pre.encode()),'post_sha256':sha(post.encode()),'postimage':str(target.relative_to(H))})
(H/'source.patch').write_text(patch);(H/'proposal.json').write_text(json.dumps({'source_base':'d9397c7c0458ec2980fa58115c5ee597eb58dbc8','files':records,'patch_sha256':sha(patch.encode()),'runtime':'UNRUN'},indent=2)+'\n');r=subprocess.run(['git','apply','--check','--',str(H/'source.patch')],cwd=R,capture_output=True);assert r.returncode==0,r.stderr;print({'paths':len(records),'patch_sha256':sha(patch.encode()),'apply_check':r.returncode})
