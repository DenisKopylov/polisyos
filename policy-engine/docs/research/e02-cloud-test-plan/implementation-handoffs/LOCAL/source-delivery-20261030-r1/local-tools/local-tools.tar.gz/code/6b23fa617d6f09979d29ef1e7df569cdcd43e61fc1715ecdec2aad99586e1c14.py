"""Freeze bounded child-only semantic removals; never mutate canonical source."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import subprocess

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
OUT = Path(__file__).resolve().parent
BASE = '545c6990e2bfa42bf580b475e23cf88df04e71d8'
OWNER = 'policy-engine/src/polisyos/ir/analytics/posterior_summary.py'
MC = 'policy-engine/src/polisyos/foundry/uncertainty/monte_carlo.py'
ADAPTER = 'policy-engine/src/polisyos/foundry/calibration/uncertainty_adapter.py'
RUNNER_TEST = 'tests/unit/scientist/compute/test_runner_posterior_summary.py'
UNIT_TEST = 'tests/unit/ir/analytics/test_posterior_summary.py'
owner = (OUT/OWNER).read_text()
mc = (OUT/MC).read_text()
adapter = subprocess.check_output(['git','show',BASE+':'+ADAPTER],cwd=ROOT).decode()
rows=[]

def removal(name, path, original, mutant, selectors, signal):
    assert original != mutant
    ast.parse(mutant)
    target=OUT/'removals'/name
    target.parent.mkdir(exist_ok=True)
    diff='diff --git a/'+path+' b/'+path+'\n'+''.join(difflib.unified_diff(original.splitlines(keepends=True),mutant.splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path))
    target.write_text(diff)
    rows.append({'name':name,'source_path':path,'original_sha256':hashlib.sha256(original.encode()).hexdigest(),'mutant_sha256':hashlib.sha256(mutant.encode()).hexdigest(),'patch':str(target.relative_to(OUT)),'patch_sha256':hashlib.sha256(diff.encode()).hexdigest(),'selectors':selectors,'required_signal':signal,'status':'UNRUN'})

check='''            if key in parameter_summaries:
                raise ValueError("posterior scalar coordinate projection is ambiguous")
'''
assert owner.count(check)==1
removal('remove-injective-projection.patch',OWNER,owner,owner.replace(check,''),[UNIT_TEST+'::test_posterior_draw_artifact_refuses_ambiguous_scalar_coordinate_projection'], 'The same expected ambiguity refusal fails (DID NOT RAISE); noncolliding tensor/scalar positive remains a passing baseline.')
start=owner.index('        # The owner writer runs this parser')
end=owner.index('        return self',start)
old_gate='''        draw_count = self.chain_count * self.draws_per_chain
        if (
            self.source_weights is not None
            or self.draw_order != tuple(range(draw_count))
            or self.parameter_order != tuple(self.parameters)
            or set(self.unit_bindings) - set(self.parameter_order)
            or any(len(item.draws) != draw_count for item in self.parameters.values())
        ):
            raise ValueError("posterior summary source axes or declarations are inconsistent")
'''
removal('remove-complete-owner-source-admission.patch',OWNER,owner,owner[:start]+old_gate+owner[end:],[RUNNER_TEST+'::test_actual_owner_writer_recomputes_complete_source_before_emission[omitted_coordinate]',RUNNER_TEST+'::test_actual_owner_refuses_old_ambiguous_dto_before_emission',RUNNER_TEST+'::test_selected_method_law_reconstructs_source_signed_zero_after_canonical_read'], 'The same direct owner-writer omission/old DTO negative fails because emission succeeds; source sign oracle exposes canonical equal-value substitution. No setup error qualifies.')
point='            selected_point = mean if point_role is PosteriorPointRole.POSTERIOR_MEAN else median\n'
assert owner.count(point)==1
removal('remove-named-mean-functional.patch',OWNER,owner,owner.replace(point,'            selected_point = median\n'),[RUNNER_TEST+'::test_selected_method_law_preserves_asymmetric_point_and_every_draw'], 'The actual mean-role point is0 rather than1 and full-source point assertion fails while labels remain.')
row='        rows = summary.joint_row_values(parameter_names)\n'
assert mc.count(row)==1
independent='''        rows = tuple(
            zip(*(sorted(summary.parameters[name].draws) for name in parameter_names), strict=True)
        )
'''
removal('remove-paired-source-row-order.patch',MC,mc,mc.replace(row,independent),[RUNNER_TEST+'::test_selected_method_law_preserves_joint_products_and_difference_variance'], 'The same real persisted/fresh opposite-pairing product/difference and complete evaluator-row sequence fails; marginal values/labels retained.')
edge='''    if (
        len(source_edges) != 1
        or str(source_edges[0].artifact_id) != str(source_ref.artifact_id)
        or source_edges[0].manifest_profile_sha256 != source_ref.manifest_profile_sha256
    ):
'''
assert adapter.count(edge)==1
removal('remove-selected-evidence-edge-check.patch',ADAPTER,adapter,adapter.replace(edge,edge.replace('    if (\n','    if False and (\n',1)),[RUNNER_TEST+'::test_selected_summary_reader_reconciles_sibling_evidence_profile_before_evaluator'], 'The same actual sibling-selected-profile negative reaches evaluator and expected refusal assertion fails, with valid default/original selected ref still loadable.')
read='''    summary = load_posterior_summary(ir_store, summary_ref)
    source_ref = ArtifactRef.model_validate(
'''
assert adapter.count(read)==1
removal('remove-actual-evidence-reresolution.patch',ADAPTER,adapter,adapter.replace(read,'''    summary = load_posterior_summary(ir_store, summary_ref)
    return summary
    source_ref = ArtifactRef.model_validate(
'''),[RUNNER_TEST+'::test_selected_source_refusals_precede_actual_law_evaluator[changed_draws]',RUNNER_TEST+'::test_selected_source_refusals_precede_actual_law_evaluator[missing_source]'], 'The same missing/changed actual evidence-source negative reaches the evaluator and expected refusal assertion fails, despite self-consistent retained summary/ref markers.')
# Widened actual consumer and source-snapshot controls retain the same tests.
rebind='        summary = recomputed\n'
assert mc.count(rebind)==1
removal('remove-actual-consumer-source-projection.patch',MC,mc,mc.replace(rebind,''),[RUNNER_TEST+'::test_actual_consumer_uses_source_snapshot_after_equal_valued_nested_mutation[point_type_alias]'], 'The actual evaluator sees bool False instead of the source float0.0; the exact observed type/value and typed-output assertion must fail.')
start=owner.index('        source = summarize_posterior_draw_artifact(',owner.index('    def joint_row_values('))
end=owner.index('\n\n\ndef _recompute_posterior_source',start)
borrowed='''        missing = set(parameter_names) - set(self.parameters)
        if missing:
            raise ValueError(
                f"posterior joint row selection has unknown parameters: {sorted(missing)}"
            )
        return tuple(
            tuple(self.parameters[name].draws[row] for name in parameter_names)
            for row in self.draw_order
        )'''
removal('remove-direct-row-source-projection.patch',OWNER,owner,owner[:start]+borrowed+owner[end:],[RUNNER_TEST+'::test_public_joint_rows_reconcile_mutable_fresh_mapping[signed_zero]',RUNNER_TEST+'::test_public_joint_rows_reconcile_mutable_fresh_mapping[unequal_value]'], 'The same direct public row reader returns altered source signs or fails to refuse an unequal value; no CAS/hash marker is removed.')
private='    source_payload = from_canonical_bytes(source_bytes)\n'
assert owner.count(private)==1
removal('remove-private-source-byte-snapshot.patch',OWNER,owner,owner.replace(private,'    source_payload = artifact_payload\n'),[UNIT_TEST+'::test_source_hash_and_decoding_use_the_same_private_snapshot'], 'After the real hash captures valid old bytes, the same deterministic external-dict mutation must fail the named admitted-source-snapshot assertion; no hash is forged. Preserve actual refusal text and do not count import/setup errors.')
format_call='        _PosteriorDrawSourceV1.model_validate(source_payload)\n'
assert owner.count(format_call)==1
removal('remove-complete-v1-format-admission.patch',OWNER,owner,owner.replace(format_call,'        pass\n'),[RUNNER_TEST+'::test_real_method_source_format_refuses_unknown_extensions_without_losing_inspection'], 'The same actual MethodJob foreign-format negative publishes summary refs instead of refusing; unknown purported weights/benign extras cannot silently receive an unweighted-profile claim.')
(OUT/'property-removals.json').write_text(json.dumps({'base':BASE,'application':'one isolated child-process source overlay at a time, never shared canonical Root source','required_order':'fresh positive -> one removal on exact source -> intended semantic red -> exact byte restoration -> positive replay','all_runtime':'UNRUN','rows':rows,'verification_rules':['Exact child module/test/source/hash and full concise outputs must be observed.','A setup/import/backend/profile error does not qualify as the semantic removal red.','If a patch becomes stale, rederive against the frozen composed source and independently review the changed mutant only.','Restore every changed path to its exact pre-removal hash; retain the complete necessary deciding output and actual attempted/collected counts.','Never change tests, skip controls, or weaken surrounding admission to obtain a red/green.']},indent=2)+'\n')
print('frozen',len(rows),'child-only removal recipes; all UNRUN')
