"""Root-only R2 removal: restore exact R1 binder in memory; no canonical edits."""
from pathlib import Path
import ast
import hashlib

import pytest
from polisyos.runtime.quality import generation_cycle as owner

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
R1 = ROOT / "LOCAL/raw/e02-execution-20261027/repairs/V3-costed-route-uniqueness-r1"
source = R1 / "postimages/policy-engine/src/polisyos/runtime/quality/generation_cycle.py"
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == "51155a50cba0d58291f9f1c8dd737d04c64082c572c50050278cf22a9094f666"
tree = ast.parse(data)
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "_n7_bound_source_gap")
namespace = dict(vars(owner))
exec(compile(ast.Module(body=[node], type_ignores=[]), "<frozen-R1-binder-removal>", "exec"), namespace)
original = owner._n7_bound_source_gap
owner._n7_bound_source_gap = namespace["_n7_bound_source_gap"]

class Results:
    def __init__(self):
        self.call_failures = 0
        self.errors = []
    def pytest_runtest_logreport(self, report):
        if report.failed and report.when == "call":
            self.call_failures += 1
        elif report.failed:
            self.errors.append(report.nodeid)

results = Results()
try:
    status = pytest.main([
        "-q", "tests/unit/runtime/quality/test_configured_acquisition_escalation.py::"
        "test_coherent_foreign_cov_basis_cannot_override_current_observation",
    ], plugins=[results])
finally:
    owner._n7_bound_source_gap = original
expected = int(status) == 1 and results.call_failures == 8 and not results.errors
print("expected eight coherent-substitution call failures" if expected else "UNEXPECTED")
raise SystemExit(0 if expected else 1)
