"""Root-only admission for an N7 synthetic fixture case outside product roots."""
from pathlib import Path
import argparse
import hashlib
import json
import runpy
import shutil
import subprocess
from external_admission import external_existing_dir, external_existing_file, no_symlink_components, fresh, fixture_snapshot

R = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
P = R / 'policy-engine'
N = P / 'docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1'
D = N / 'deep-task-status-audit-20261027-r1'
FRAGMENT_SHA = '8a6be8cb31b30ca548403086bc33be95c8db32d367aa9f5658a57c8925ba9dc6'
KEYS = ('CORR_C_WORLD_CAS', 'CORR_C_WORLD_REF', 'CORR_C_WORLD_HASH', 'CORR_C_L6_SOURCE_ROOT', 'CORR_C_L6_SOURCE_HASH')
sha = lambda data: hashlib.sha256(data).hexdigest()


def exclusive_text(path, text):
    with path.open('x', encoding='utf-8') as stream:
        stream.write(text)


def main():
    a = argparse.ArgumentParser()
    a.add_argument('--parent', required=True)
    a.add_argument('--case', required=True)
    a.add_argument('--candidate-receipt', required=True)
    a.add_argument('--candidate-receipt-sha256', required=True)
    a.add_argument('--scope', required=True)
    a.add_argument('--disk-admission-bytes', type=int, default=8 * 1024**3)
    a.add_argument('--disk-budget-reason')
    a.add_argument('node', nargs='+')
    v = a.parse_args()
    assert v.case and all(c.isalnum() or c in '-_' for c in v.case)
    assert v.disk_admission_bytes >= 7 * 1024**3
    assert v.disk_admission_bytes >= 8 * 1024**3 or v.disk_budget_reason
    parent = external_existing_dir(v.parent, R)
    out = parent / v.case
    plan_path = parent / (v.case + '.json')
    snapshot = parent / (v.case + '-root-live-input.json')
    readback = parent / (v.case + '-Git-readback.json')
    for x in (out, plan_path, snapshot, readback): fresh(x, parent)
    guard = runpy.run_path(str(N / 'root-layer-lib.py'))['guard']
    source = guard()
    live_path = R / 'LOCAL/raw/root-live-ownership-20261021.json'
    live_bytes = live_path.read_bytes(); live = json.loads(live_bytes)
    assert not live['known_dirty_paths']
    assert source['head'] == live['head']
    assert subprocess.check_output(['git', '-C', str(R), 'rev-parse', 'HEAD^{tree}'], text=True).strip() == live['tree']
    assert shutil.disk_usage(R).free >= v.disk_admission_bytes
    assert v.node and len(v.node) == len(set(v.node))
    for node in v.node:
        rel = node.split('::')[0]
        assert rel.startswith('tests/') and '..' not in Path(rel).parts
        data = (P / rel).read_bytes()
        assert subprocess.check_output(['git', '-C', str(R), 'show', live['head'] + ':policy-engine/' + rel]) == data
    receipt_path = external_existing_file(v.candidate_receipt, R)
    receipt_bytes = receipt_path.read_bytes()
    assert sha(receipt_bytes) == v.candidate_receipt_sha256
    receipt = json.loads(receipt_bytes)
    assert receipt['status'] == 'CANDIDATE_ONLY_NOT_AUTHENTIC_N7_INPUTS'
    assert receipt['source_cut'] == {'branch': live['branch'], 'head': live['head'], 'tree': live['tree']}
    env = receipt['required_environment']
    assert set(env) == set(KEYS)
    assert all(isinstance(env.get(k), str) and env[k] for k in KEYS)
    assert receipt['forbidden_environment'] == ['CORR_C2_LEGACY_EFFECT_BRIDGE_PATH']
    wmr = external_existing_dir(env['CORR_C_WORLD_CAS'], R)
    l6 = external_existing_dir(env['CORR_C_L6_SOURCE_ROOT'], R)
    fixture_root = external_existing_dir(receipt['case_root'], R)
    assert receipt_path == fixture_root / 'candidate-inputs.json'
    assert wmr.is_relative_to(fixture_root) and l6.is_relative_to(fixture_root)
    assert out != fixture_root and not out.is_relative_to(fixture_root) and not fixture_root.is_relative_to(out)
    fixture_files = fixture_snapshot(str(fixture_root), R)
    assert receipt['world_model']['cas_root'] == str(wmr)
    assert receipt['world_model']['artifact_ref'] == env['CORR_C_WORLD_REF']
    assert receipt['world_model']['logical_content_hash'] == env['CORR_C_WORLD_HASH']
    assert receipt['l6']['source_owner_root'] == str(l6)
    assert receipt['l6']['bundle_content_hash'] == env['CORR_C_L6_SOURCE_HASH']
    additional = {str(receipt_path.relative_to(R)): sha(receipt_bytes)}
    members = receipt['l6']['members']
    expected_keys = {'intervention_knob_dictionary', 'lex_intervention_map', 'observation_to_contract_manifest', 'policy_scenario_templates', 'slot_family_manifest'}
    assert len(members) == 5 and {m['owner_key'] for m in members} == expected_keys
    for member in members:
        rel = Path(member['relative_to_l6_data_root'])
        assert not rel.is_absolute() and '..' not in rel.parts
        file = external_existing_file(str(l6 / rel), R)
        assert file.stat().st_size == member['bytes'] and sha(file.read_bytes()) == member['sha256']
        additional[str(file.relative_to(R))] = member['sha256']
    authority = P / 'architecture/policy_design_case/layer3_gy_l6_owner_authority_bindings.json'
    no_symlink_components(authority)
    assert receipt['l6']['code_authority_bindings_path'] == str(authority)
    assert receipt['l6']['code_authority_sha256_before'] == receipt['l6']['code_authority_sha256_after'] == sha(authority.read_bytes())
    additional[str(authority.relative_to(R))] = sha(authority.read_bytes())
    old = json.loads((D / 'g27t02r2.json').read_bytes())
    fragment = old['sandbox_profile_fragment']
    assert sha(fragment.encode()) == old['sandbox_profile_fragment_sha256'] == FRAGMENT_SHA
    assert (P / 'production_data').resolve() == Path('/Users/deniskopylov/polisyos/policy-engine/production_data')
    profile = '(version 1)\n(allow default)\n(deny file-write*)\n(allow file-write* (subpath ' + json.dumps(str(out)) + '))\n(allow file-write* (literal "/dev/null"))\n' + fragment
    harness_dir = Path(__file__).resolve().parent
    harness_files = ('external_admission.py', 'prepare_external_case.py', 'run_external_case.py', 'readback_external_sources.py')
    harness_sha = {str((harness_dir / name).relative_to(R)): sha((harness_dir / name).read_bytes()) for name in harness_files}
    plan = {'case_id': v.case, 'case_parent': str(parent), 'source_head': live['head'], 'source_tree': live['tree'], 'nodes': v.node,
            'harness_sha256': harness_sha, 'candidate_fixture_root': str(fixture_root), 'candidate_fixture_files': fixture_files,
            'extra_env': {k: env[k] for k in KEYS}, 'unset_env': ['CORR_C2_LEGACY_EFFECT_BRIDGE_PATH'],
            'candidate_input_receipt': str(receipt_path.relative_to(R)), 'candidate_input_receipt_sha256': sha(receipt_bytes),
            'additional_input_sha256': additional, 'deadline_seconds': 600, 'rss_cap_bytes': 2300 * 1024**2,
            'scope': v.scope, 'closure_ids': [], 'sandbox_profile_fragment': fragment, 'sandbox_profile_fragment_sha256': FRAGMENT_SHA,
            'sandbox_profile_text': profile, 'sandbox_profile_sha256': sha(profile.encode()),
            'retained_root_live_snapshot': str(snapshot.relative_to(R)), 'retained_root_live_sha256': sha(live_bytes),
            'prelaunch_free_disk_bytes': shutil.disk_usage(R).free, 'disk_admission_bytes': v.disk_admission_bytes,
            'disk_stop_bytes': 6 * 1024**3, 'disk_budget_reason': v.disk_budget_reason,
            'control': 'Root holds source/index/refs/live and candidate inputs stable through audit and Git qualification; candidate-only synthetic case.'}
    exclusive_text(snapshot, live_bytes.decode())
    exclusive_text(plan_path, json.dumps(plan, indent=2) + '\n')
    print(json.dumps({'plan': str(plan_path), 'sha256': sha(plan_path.read_bytes()), 'source_head': live['head'], 'source_tree': live['tree'], 'nodes': len(v.node)}))

if __name__ == '__main__':
    main()
