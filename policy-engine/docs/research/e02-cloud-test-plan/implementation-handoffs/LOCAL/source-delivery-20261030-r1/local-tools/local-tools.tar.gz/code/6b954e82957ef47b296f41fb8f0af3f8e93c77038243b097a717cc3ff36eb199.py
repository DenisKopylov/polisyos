from pathlib import Path
import difflib, hashlib, json, os, subprocess
root=Path.cwd();out=root/'LOCAL/raw/e02-execution-20261027/repairs/C06'; source=out/'policy-engine';base='8db01b1076e425b7998b05a658776c991b7bd594';candidate='a9a2ec798be651f19c125b0970b98356fdae1659'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();head_tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip()
paths=sorted(p.relative_to(out).as_posix() for p in source.rglob('*.py'))
def obj(rev,path):return subprocess.check_output(['git','show',f'{rev}:{path}'])
def sha(x):return hashlib.sha256(x).hexdigest()
def patch(pre,post,path):
 a=pre.decode('utf-8').splitlines(keepends=True);b=post.decode('utf-8').splitlines(keepends=True)
 return ''.join(difflib.unified_diff(a,b,fromfile='a/'+path,tofile='b/'+path))
records=[];base_diff='';delta_diff=''
for path in paths:
 data=(out/path).read_bytes(); b=obj(base,path); c=obj(candidate,path); h=obj(head,path)
 base_diff+=patch(b,data,path);delta_diff+=patch(c,data,path)
 records.append({'path':path,'base_sha256':sha(b),'candidate_sha256':sha(c),'observed_head_sha256':sha(h),'postimage_sha256':sha(data),'postimage_bytes':len(data),'different_from_base':b!=data,'different_from_candidate':c!=data,'current_matches_base':h==b})
(out/'base-to-proposal.patch').write_text(base_diff);(out/'candidate-to-proposal.patch').write_text(delta_diff)
related=['AGENTS.md','policy-engine/CONTRIBUTING.md','policy-engine/docs/reference/policy-design-case-failure-patterns.md','policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/executor-continuation-plan-20261027/prompts/C06-v5-classification.md','policy-engine/src/polisyos/core/artifacts/manifest.py','policy-engine/src/polisyos/core/artifacts/store.py','policy-engine/src/polisyos/core/artifacts/write_contract.py','policy-engine/src/polisyos/scientist/compute/runner.py','policy-engine/src/polisyos/scientist/policy_design/objectives.py','policy-engine/src/polisyos/scientist/nodes/builtins/decide/policy_runtime_artifacts.py','policy-engine/src/polisyos/scientist/nodes/builtins/decide/policy_runtime_metrics.py','policy-engine/src/polisyos/ir/kernel/units.py']
related_records=[]
for path in related:
 b=obj(base,path);h=obj(head,path)
 related_records.append({'path':path,'base_sha256':sha(b),'observed_head_sha256':sha(h),'observed_head_matches_base':b==h})
cloud=json.loads((root/'LOCAL/raw/e02-execution-20261027/cloud/C06/candidate-manifest.json').read_text());docs=[x for x in cloud['files'] if x['path'].startswith('policy-engine/docs/')]
result={'author':'C06 sparse repair worker','base_commit':base,'candidate_tree':candidate,'observed_head':head,'observed_head_tree':head_tree,'canonical_source_unchanged_by_worker':True,'canonical_index_and_refs_unchanged_by_worker':True,'postimage_files':records,'read_dependencies':related_records,'original_cloud_document_records':docs,'base_to_proposal_patch_sha256':sha((out/'base-to-proposal.patch').read_bytes()),'candidate_to_proposal_patch_sha256':sha((out/'candidate-to-proposal.patch').read_bytes()),'product_tests':'UNRUN','runtime_or_acceptance_claim':'NONE','external_review':'PENDING'}
(out/'manifest.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'observed_head':head,'files':len(records),'base_changed':sum(x['different_from_base'] for x in records),'candidate_revised':sum(x['different_from_candidate'] for x in records),'current_preimages_matching_base':sum(x['current_matches_base'] for x in records),'base_patch_sha256':result['base_to_proposal_patch_sha256'],'delta_patch_sha256':result['candidate_to_proposal_patch_sha256']},indent=2))
