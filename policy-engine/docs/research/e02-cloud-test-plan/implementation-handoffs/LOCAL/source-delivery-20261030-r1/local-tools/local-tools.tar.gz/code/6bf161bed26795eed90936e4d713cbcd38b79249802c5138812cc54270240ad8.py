from pathlib import Path
p=Path('LOCAL/raw/e02-execution-20261027/repairs/C41-r5/postimages/policy-engine/src/polisyos/runtime/http/routes/runs.py');s=p.read_text()
# The generic branch gets the owner expectation type, not an untrusted caller ref.
old='''        GenericCycleSimulationAdmissionOwner,
        GenericCycleSimulationN5ExecutionV3,
        GenericCycleSimulationN5InputV1,'''
new='''        GenericCycleSimulationAdmissionOwner,
        GenericCycleSimulationN5ExecutionV3,
        GenericCycleSimulationN5InputV1,
        GenericN5ExecutionJoinExpectation,'''
assert old in s;s=s.replace(old,new,1)
old='''                if any(value is None for value in generic_refs):
                    raise ValueError("generic_n5_compiled_lineage_incomplete")'''
new='''                if any(value is None for index, value in enumerate(generic_refs) if index != 6):
                    raise ValueError("generic_n5_compiled_lineage_incomplete")'''
assert old in s;s=s.replace(old,new,1)
old='''                execution = parse_generic_cycle_simulation_n5_execution(
                    read_core_json_artifact(store, execution_ref).value
                )
                generic_owner.resolve_n5_execution(execution_ref, expected=execution)
                request_binding_status = ('''
new='''                # Independently bind the cycle, result and source before the owner
                # replay; a real disagreement is not interchangeable with absence.
                if (
                    input_record.job_id != family.job_id
                    or input_record.run_id != family.run_id
                    or input_record.source_run_id != family.source_run_id
                    or input_record.tenant_id != family.tenant_id
                    or input_record.cell_id != family.cell_id
                    or input_record.cycle_index != cycle.cycle_index
                    or input_record.n4_source_ref != cycle_source_ref
                    or input_record.n4_child_profile_family_ref != family.n4_child_profile_family_ref
                    or input_record.n4_child_profile_set_ref != set_ref
                    or input_record.context_job_ref != history_binding.context_job_ref
                    or input_record.profile_ref != binding.handoff.profile_ref
                    or input_record.profile != binding.handoff.profile
                    or input_record.design_problem_ref != cycle.design_problem_basis_ref
                    or input_record.candidate_id != simulation.candidate_id
                    or input_record.candidate_id != source_candidates[0].candidate_id
                    or input_record.candidate_atom_hash != source_candidates[0].atom.content_hash
                    or input_record.profile.profile_selection_ref != selection_ref
                    or simulation.status not in {"joint_simulated", "simulation_blocked"}
                ):
                    raise ValueError("generic_n5_persisted_input_cycle_join_mismatch")
                join = generic_owner.resolve_n5_execution_join(
                    execution_ref,
                    expected=GenericN5ExecutionJoinExpectation(
                        input_ref=input_ref,
                        result_ref=simulation.simulation_result_ref,
                        status=simulation.status,
                        n4_source_ref=cycle_source_ref,
                        context_job_ref=history_binding.context_job_ref,
                        profile_ref=binding.handoff.profile_ref,
                        child_family_ref=family.n4_child_profile_family_ref,
                        child_set_ref=set_ref,
                        profile_selection_ref=selection_ref,
                        candidate_id=simulation.candidate_id,
                        candidate_atom_hash=input_record.candidate_atom_hash,
                        world_model_record_content_hash=(
                            input_record.profile.context_inputs.world_model_record.content_hash
                        ),
                        job_id=family.job_id,
                        run_id=family.run_id,
                        source_run_id=family.source_run_id,
                        tenant_id=family.tenant_id,
                        cell_id=family.cell_id,
                    ),
                )
                if join.status != "resolved":
                    # Preserve only the independently checked candidate result;
                    # a known invalid or mismatching join refuses that row alone.
                    conflict = join.status in {"invalid", "mismatch"}
                    result_ref = simulation.simulation_result_ref
                    candidate_result = None
                    if not conflict and result_ref is not None:
                        candidate_manifest = read_core_manifest_profile(store, result_ref)[0]
                        candidate_scope = candidate_manifest.tenant_context
                        if (
                            candidate_scope is None
                            or candidate_scope.tenant_id != tenant_id
                            or candidate_scope.cell_id != cell_id
                            or not store.verify(result_ref).ok
                        ):
                            raise ValueError("generic_n5_candidate_result_scope_invalid")
                        source_candidate = source_candidates[0]
                        atoms = tuple(getattr(source_candidate, "intervention_atoms", ()) or ())
                        if not atoms:
                            atoms = (source_candidate.atom,)
                        candidate_result = load_joint_simulation_result(
                            result_ref,
                            store=store,
                            expected_world_model_record_content_hash=(
                                input_record.profile.context_inputs.world_model_record.content_hash
                            ),
                            expected_atom_ids=tuple(atom.intervention_id for atom in atoms),
                            expected_selected_outcomes=(input_record.outcome_variable,),
                        )
                        if candidate_result.receipt.payload_hash != simulation.simulation_ref:
                            raise ValueError("generic_n5_candidate_receipt_binding_mismatch")
                    if not conflict and simulation.status == "joint_simulated" and candidate_result is None:
                        raise ValueError("generic_n5_candidate_result_unavailable")
                    limitation = (
                        "n5_execution_request_provenance_conflict"
                        if conflict
                        else "n5_execution_request_provenance_not_established"
                    )
                    row_status = "simulation_blocked" if conflict else simulation.status
                    value_port = cycle.value_port
                    n8_status = (
                        "value_blocked"
                        if conflict
                        else value_port.status
                        if value_port.status == "value_conditional"
                        else "value_pending_n8"
                    )
                    n8_fields = (
                        _n8_interaction_qualification_fields(value_port, include_status=False)
                        if n8_status == "value_conditional"
                        else {}
                    )
                    result_body_status = "not_established" if result_ref is not None else "not_applicable"
                    observations.append(
                        RunGenericCycleSimulationN5Observation(
                            node_ref=node_ref,
                            design_problem_ref=cycle.design_problem_ref,
                            cycle_index=cycle.cycle_index,
                            candidate_id=simulation.candidate_id,
                            status=row_status,
                            simulation_result_ref=result_ref,
                            simulation_result_body_status=result_body_status,
                            simulation_result_body_limitation_code=(
                                "generic_n5_result_body_request_binding_not_established"
                                if result_ref is not None
                                else None
                            ),
                            n4_source_ref=cycle_source_ref,
                            context_job_ref=history_binding.context_job_ref,
                            profile_ref=binding.handoff.profile_ref,
                            child_profile_family_ref=family.n4_child_profile_family_ref,
                            child_profile_set_ref=set_ref,
                            n5_input_ref=input_ref,
                            n5_execution_ref=execution_ref,
                            n5_owner_join_status=join.status,
                            n5_owner_join_limitation_code=join.code,
                            n5_request_binding_status="not_established",
                            profile_selection_ref=selection_ref,
                            atom_ids=tuple(candidate_result.atom_ids) if candidate_result else (),
                            selected_outcomes=(
                                tuple(candidate_result.selected_outcomes) if candidate_result else ()
                            ),
                            world_model_record_content_hash=(
                                input_record.profile.context_inputs.world_model_record.content_hash
                            ),
                            authority_blockers=tuple(
                                dict.fromkeys((*simulation.authority_blockers, limitation))
                            ),
                            n8_status=n8_status,
                            n8_lineage_status="not_established",
                            n8_authority_blockers=tuple(
                                dict.fromkeys((*value_port.authority_blockers, limitation))
                            ),
                            n8_limitation_code=limitation,
                            n5_interaction_evidence=(
                                _n5_interaction_evidence_projection(candidate_result)
                            ),
                            **_n5_interaction_scope_fields(candidate_result),
                            **n8_fields,
                        )
                    )
                    n5_limitation = limitation
                    continue
                execution = join.execution
                if execution is None:
                    raise ValueError("generic_n5_execution_join_resolved_without_record")
                request_binding_status = ('''
assert old in s;s=s.replace(old,new,1)
# Emit owner join classification on fully replayed rows.
old='''                        n5_execution_ref=execution_ref,
                        n5_request_binding_status=request_binding_status,'''
new='''                        n5_execution_ref=execution_ref,
                        n5_owner_join_status="resolved",
                        n5_request_binding_status=request_binding_status,'''
assert old in s;s=s.replace(old,new,1)
# A resolved join is already source replayed and may be used to recompute the
# result's physical-spec identity. Its authority is still candidate-only.
old='''                        expected_atom_ids=expected_atom_ids,
                        expected_selected_outcomes=(input_record.outcome_variable,),
                    )'''
new='''                        expected_atom_ids=expected_atom_ids,
                        expected_selected_outcomes=(input_record.outcome_variable,),
                        expected_request=execution.request_binding.request,
                    )'''
assert old in s;s=s.replace(old,new,1)
old='''                    result_status, result_blockers = _joint_simulation_port_outcome(resolved_result)'''
new='''                    result_status, result_blockers = _joint_simulation_port_outcome(
                        resolved_result, request=execution.request_binding.request
                    )'''
assert old in s;s=s.replace(old,new,1)
p.write_text(s)
