"""Observe existing N7 failures without replacing owner code, statuses, or results."""

from __future__ import annotations

import hashlib
import itertools
import json
import os
import re
import sys
from pathlib import Path

import pytest

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
RAW = ROOT / "LOCAL/raw/e02-execution-20261027"
NATIVE = (
    ROOT
    / "policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1"
)
OWNERS = {
    str(ROOT / "policy-engine/src/polisyos/runtime/quality/promotion_sequence.py"),
    str(ROOT / "policy-engine/src/polisyos/runtime/quality/epoch_validity_cascade.py"),
}
PINS = {
    "policy-engine/src/polisyos/runtime/quality/design_generation.py": "4c645aaca73fbdb00748d98f4f1a832156f5de77d5451bf62e4d26ae85dd1504",
    "policy-engine/tests/unit/runtime/quality/test_generation_source.py": "64c9fc1a4eeca461561aed1004f0a5b7f32965b628b21b0ce5ccc84f68327f60",
    "policy-engine/src/polisyos/runtime/quality/promotion_sequence.py": "81750c5e090946fff6550bcb9fe6fca3a7a31f7bee5f5dc007ed86856750ce8d",
    "policy-engine/src/polisyos/runtime/quality/confidence_ledger.py": "f7e770b6d170dafcaaa9fe566355ff9b64dc138b38b29848726cda3dbf0206c8",
    "policy-engine/src/polisyos/runtime/quality/epoch_validity_cascade.py": "1d7dc7635b59d8b05728d5b8fca66e82143b039a753bc4285d238b5db8781da5",
}
SELECTED = {
    "test_default_controller_custody_and_missing_protected_admission",
    "test_synthetic_independence_source_establishes_mechanics_but_never_authority",
}
_OUTPUT: Path | None = None


def _bounded(value, depth=0, budget=None):
    """Project dynamic values into bounded, payload-safe JSON data."""
    if budget is None:
        budget = [128]
    if budget[0] <= 0:
        return {"omitted": "node_budget"}
    budget[0] -= 1
    if value is None or type(value) is bool:
        return value
    if type(value) is int:
        return value if value.bit_length() <= 63 else {"omitted": "integer_too_large", "bits": value.bit_length()}
    if type(value) is str:
        return {
            "code": value if re.fullmatch(r"[A-Za-z0-9_.:-]{1,160}", value) else None,
            "sha256": hashlib.sha256(value.encode("utf-8", errors="replace")).hexdigest(),
            "characters": len(value),
        }
    if depth >= 4:
        return {"omitted": "depth_limit"}
    if type(value) in (tuple, list):
        return {"items": [_bounded(v, depth + 1, budget) for v in value[:32]], "length": len(value)}
    if type(value) is dict:
        return {
            "entries": [
                {"key": _bounded(k, depth + 1, budget), "value": _bounded(v, depth + 1, budget)}
                for k, v in itertools.islice(value.items(), 32)
            ],
            "length": len(value),
        }
    return {"omitted": "unsupported_type", "type": _bounded(type(value).__name__, depth + 1, budget)}


def pytest_configure(config):
    global _OUTPUT
    observer_sha = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    assert observer_sha == os.environ["N7_SEMANTIC_DIAGNOSTICS_SHA256"], (
        "diagnostic observer pin mismatch"
    )
    for relative, expected in PINS.items():
        assert hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() == expected, relative
    output = Path(os.environ["N7_SEMANTIC_DIAGNOSTICS_OUTPUT"]).absolute()
    assert not output.exists(), "diagnostic output must be fresh"
    for parent in output.parents:
        assert not parent.is_symlink()
    output = output.resolve(strict=False)
    assert output.is_relative_to(RAW) or output.is_relative_to(NATIVE)
    assert output.parent.is_dir()
    header = {
        "schema": "e02.n7.unchanged-owner-diagnostics.r4",
        "observer_sha256": observer_sha,
        "source_pins": PINS,
        "limits": "Main pytest thread only; tracing may affect strong runtime attestation. Dynamic strings are identifier codes or hash and length; collections are bounded; absence of an event is not proof of no exception.",
        "scope": "selected calls in this parent Python process; no code/default/global/status replacement",
        "runtime_acceptance": "none; diagnostic witness only",
    }
    with output.open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(header) + "\n")
    _OUTPUT = output


def _identity_snapshot():
    module = sys.modules.get("polisyos.runtime.quality.confidence_ledger")
    if module is None:
        return {"module_available": False}
    observation = module.capture_loaded_deployment_identity()
    failure = module._IMPORT_TIME_DEPLOYMENT_IDENTITY_FAILURE
    failure_summary = None
    if failure is not None:
        code, detail = failure
        failure_summary = {
            "code": _bounded(code),
            "detail_sha256": hashlib.sha256(detail.encode("utf-8", errors="replace")).hexdigest(),
            "detail_characters": len(detail),
            "detail_code": detail if re.fullmatch(r"[A-Za-z0-9_.:-]{1,160}", detail) else None,
        }
    return {
        "module_available": True,
        "observation": _bounded(observation.model_dump(mode="json")),
        "import_time_loaded_code_consistent": _bounded(module._IMPORT_TIME_LOADED_CODE_CONSISTENT),
        "import_time_typed_failure": failure_summary,
        "import_time_reason": _bounded(module._IMPORT_TIME_DEPLOYMENT_IDENTITY_REASON),
        "import_time_owner_root": _bounded(str(module._IMPORT_TIME_OWNER_ROOT)),
    }


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_call(item):
    if item.originalname not in SELECTED:
        yield
        return
    previous = sys.gettrace()
    assert previous is None, "refuse to replace an existing trace observer"
    events = []
    dropped_events = 0
    seen = set()
    phases = {
        "resolve_with_credal_reference",
        "_read_model",
        "_verifier_provenance_is_exact",
        "_source_ref_from_bridge_manifest",
        "_resolve_independence_record",
        "_source_synthetic_provenance",
    }

    def trace(frame, event, arg):
        nonlocal dropped_events
        if frame.f_code.co_filename not in OWNERS:
            return None
        frame.f_trace_lines = False
        if frame.f_code.co_name in phases and event in {"call", "return"}:
            observed = {
                "event": event,
                "function": _bounded(frame.f_code.co_name),
                "source_file": _bounded(str(Path(frame.f_code.co_filename).relative_to(ROOT))),
            }
            if event == "return":
                observed["return_type"] = _bounded(type(arg).__name__)
                if frame.f_code.co_name == "_verifier_provenance_is_exact":
                    observed["returned_verifier_predicate"] = _bounded(arg)
                elif frame.f_code.co_name == "_source_synthetic_provenance":
                    observed["returned_synthetic_projection"] = _bounded(arg)
                elif frame.f_code.co_name == "_resolve_independence_record" and isinstance(
                    arg, tuple
                ):
                    observed["returned_disposition_and_limitation"] = _bounded(arg[:2])
            if len(events) < 512:
                events.append(observed)
            else:
                dropped_events += 1
        if event == "exception":
            exc_type, exc, _traceback = arg
            try:
                detail = str(exc)
            except Exception:
                detail = "<exception string unavailable>"
            detail_hash = hashlib.sha256(detail.encode("utf-8", errors="replace")).hexdigest()
            key = (frame.f_code.co_name, exc_type.__name__, detail_hash)
            if key not in seen and len(events) >= 512:
                dropped_events += 1
            if key not in seen and len(events) < 512:
                seen.add(key)
                events.append(
                    {
                        "function": _bounded(frame.f_code.co_name),
                        "source_file": _bounded(str(Path(frame.f_code.co_filename).relative_to(ROOT))),
                        "line": frame.f_lineno,
                        "exception_type": _bounded(exc_type.__name__),
                        "exception_code": detail
                        if re.fullmatch(r"[A-Za-z0-9_.:-]{1,160}", detail)
                        else None,
                        "exception_detail_sha256": detail_hash,
                        "exception_detail_characters": len(detail),
                        "exception_detail_omitted": not bool(
                            re.fullmatch(r"[A-Za-z0-9_.:-]{1,160}", detail)
                        ),
                    }
                )
        return trace

    sys.settrace(trace)
    try:
        yield
    finally:
        sys.settrace(previous)
        try:
            identity = _identity_snapshot()
        except Exception as exc:
            identity = {
                "observation_error_type": _bounded(type(exc).__name__),
                "observation_unavailable": True,
            }
        record = {
            "nodeid": _bounded(item.nodeid),
            "selected_test": _bounded(item.originalname),
            "promotion_owner_exception_events": events,
            "dropped_events": dropped_events,
            "sticky_deployment_identity_after_call": identity,
            "code_replacement": False,
            "trace_restored": sys.gettrace() is previous,
        }
        assert _OUTPUT is not None
        with _OUTPUT.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(record, sort_keys=True) + "\n")
