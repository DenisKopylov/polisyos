"""Reconstruct each frozen patch in memory and reread bytes without Git writes."""
from pathlib import Path
import hashlib,json,re
r=Path(__file__).resolve().parent;m=json.loads((r/'manifest.json').read_text());sha=lambda x:hashlib.sha256(x).hexdigest();code=(r/'postimages'/m['files'][0]['path']).read_bytes();assert sha(code)==m['files'][0]['post_sha256'];records=[]
for c in m['controls']:
 p=r/c['patch'];patch=p.read_text().splitlines(keepends=True);assert sha(p.read_bytes())==c['sha256'];original=code.decode().splitlines(keepends=True);out=[];cursor=0;i=0
 while i<len(patch):
  h=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',patch[i])
  if not h:i+=1;continue
  start=int(h.group(1));count=int(h.group(2) or 1);newcount=int(h.group(4) or 1);idx=start-1 if count else start;out.extend(original[cursor:idx]);cursor=idx;deleted=added=0;i+=1
  while i<len(patch) and not patch[i].startswith('@@ '):
   line=patch[i];kind=line[0];val=line[1:]
   if kind in ' -':assert original[cursor]==val;cursor+=1;deleted+=1
   if kind in ' +':out.append(val);added+=1
   i+=1
  assert deleted==count and added==newcount
 out.extend(original[cursor:]);mutant=''.join(out).encode();assert sha(mutant)==c['mutant_sha256'];records.append({'name':c['name'],'patch_sha256':c['sha256'],'mutant_sha256':sha(mutant),'runtime':'UNRUN'})
p=r/'control-readback.json';p.write_text(json.dumps({'source_manifest_sha256':sha((r/'manifest.json').read_bytes()),'controls':records},indent=2)+'\n');print('controls',len(records),'readback_sha256',sha(p.read_bytes()))
