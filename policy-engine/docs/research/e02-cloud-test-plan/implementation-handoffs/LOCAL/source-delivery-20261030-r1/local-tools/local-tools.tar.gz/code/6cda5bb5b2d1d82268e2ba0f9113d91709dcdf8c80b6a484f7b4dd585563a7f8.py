"""Compare the actual old writer AST with the proposed owner across a finite fixture set.

This is an isolated standard-library diagnostic, not a product runtime pass.
"""
from __future__ import annotations

import ast
import hashlib
import itertools
import json
import subprocess
from pathlib import Path
from types import SimpleNamespace

root = Path('LOCAL/raw/e02-execution-20261027/repairs/TC-closure-owner-boundary-r1')
path = 'policy-engine/src/polisyos/foundry/execute/api.py'
old = subprocess.check_output(['git', 'show', '0c2169fd0d17dc59b49733fe6a001ec4114d2d1c:' + path])
new = (root / 'proposal' / path).read_bytes()
old_tree, new_tree = ast.parse(old), ast.parse(new)
writer = next(n for n in old_tree.body if isinstance(n, ast.FunctionDef) and n.name == '_build_execution_input_basis')
start = next(i for i, n in enumerate(writer.body) if isinstance(n, ast.AnnAssign) and isinstance(n.target, ast.Name) and n.target.id == 'source_refs')
end = next(i for i, n in enumerate(writer.body) if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'inventory' for t in n.targets))
old_body = writer.body[start:end] + [ast.Return(value=ast.Name(id='source_refs', ctx=ast.Load()))]
args = ['request','bindings','graph_ref','trinity_ref','candidate_ref','candidate_data_snapshot_ref',
        'candidate_registry_bundle_ref','resolved_state','binding_registry_ref','compile_registry_ref',
        'runtime_registry_ref']
old_def = ast.FunctionDef(name='old_writer_sources',args=ast.arguments(posonlyargs=[],args=[ast.arg(arg=x) for x in args],kwonlyargs=[],kw_defaults=[],defaults=[]),body=old_body,decorator_list=[])
new_def = next(n for n in new_tree.body if isinstance(n, ast.FunctionDef) and n.name == 'execution_input_basis_sources')
new_def.returns = None
for arg in new_def.args.args: arg.annotation = None
class Ref:
    @staticmethod
    def model_validate(value):
        return value
class Payload:
    def __init__(self, rows): self.rows = rows
    def model_dump(self, *, mode):
        assert mode == 'python'
        return dict(self.rows)
models = {
    'empty': [],
    'multiple': [('slot_registry','slot'),('merge_registry','merge'),('optional',None)],
    'repeated': [('slot_registry','same'),('merge_registry','same')],
}
namespace = {'ArtifactRef':Ref,'load_registry_bundle_payload':lambda store, ref: store[ref]}
module = ast.fix_missing_locations(ast.Module(body=[old_def,new_def],type_ignores=[]))
exec(compile(module, '<extracted-owner-source>', 'exec'), namespace)
old_call, new_call = namespace['old_writer_sources'], namespace['execution_input_basis_sources']
failures=[]; count=0
for present in itertools.product((False,True), repeat=4):
    sql,override,observed,feedback=present
    for family,rows in models.items():
        count += 1
        request=SimpleNamespace(exec_plan_ref='plan',input_bindings_ref='bindings',
            parameter_override_bundle_ref='override' if override else None,
            observed_range_bundle_ref='observed' if observed else None,
            feedback_config_ref='feedback' if feedback else None)
        bindings=SimpleNamespace(data_snapshot_ref='actual',bound_state_snapshot_ref='bound',
            registered_sql_admission_ref='sql' if sql else None)
        resolution=SimpleNamespace(state_snapshot_ref='base')
        payloads={role:Payload(rows) for role in ('binding','compile','runtime')}
        namespace['store']=payloads
        values=[request,bindings,'graph','trinity','candidate','candidate_data',
                'candidate_registry',resolution,'binding','compile','runtime']
        old_rows=old_call(*values)
        basis=SimpleNamespace(exec_plan_ref=request.exec_plan_ref, program_graph_ref='graph',
            trinity_bundle_ref='trinity',candidate_ref='candidate',
            candidate_data_snapshot_ref='candidate_data',candidate_registry_bundle_ref='candidate_registry',
            input_bindings_ref=request.input_bindings_ref,data_snapshot_ref='actual',
            bound_state_snapshot_ref='bound',base_state_snapshot_ref='base',
            binding_registry_ref='binding',compile_registry_ref='compile',runtime_registry_ref='runtime',
            binding_registry_members=payloads['binding'],compile_registry_members=payloads['compile'],
            runtime_registry_members=payloads['runtime'],registered_sql_admission_ref=bindings.registered_sql_admission_ref,
            parameter_override_bundle_ref=request.parameter_override_bundle_ref,
            observed_range_bundle_ref=request.observed_range_bundle_ref,request=request)
        new_rows=new_call(basis)
        if old_rows!=new_rows: failures.append({'inputs':[sql,override,observed,feedback,family]})
result={'status':'PASS' if not failures else 'FAIL','kind':'stdlib extracted-AST comparison, not product runtime',
        'old_base_commit':'0c2169fd0d17dc59b49733fe6a001ec4114d2d1c',
        'old_file_sha256':hashlib.sha256(old).hexdigest(),'candidate_file_sha256':hashlib.sha256(new).hexdigest(),
        'case_count':count,'failure_count':len(failures),'failures':failures,
        'denominator':'all 16 presence combinations of SQL, overrides, observed ranges and feedback crossed with 3 registry-member shapes (empty, multiple, repeated)'}
(root/'writer-order-static-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
if failures: raise SystemExit(1)
