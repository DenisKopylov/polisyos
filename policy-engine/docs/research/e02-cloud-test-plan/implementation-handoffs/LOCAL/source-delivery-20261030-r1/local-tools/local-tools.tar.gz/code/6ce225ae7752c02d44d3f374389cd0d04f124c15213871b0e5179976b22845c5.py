from pathlib import Path

out = Path('LOCAL/raw/e02-execution-20261027/repairs/C90-provenance-domain-r5/postimages')
target = out / 'policy-engine/tests/unit/foundry/uncertainty/test_joint_law_admission.py'
source = target.read_text().replace('from datetime import datetime, timedelta, tzinfo', 'from datetime import datetime, time, timedelta, tzinfo')
source += '''\n\ndef _provenance_with_notes(notes: dict[str, object]) -> CompositionProvenance:
    step = CompositionStep(
        op="push_forward",
        stage_name="prior.domain.probe",
        input_flavours=(ComposedFlavour.ANALYTICAL,),
        output_flavour=ComposedFlavour.DELTA,
        assumptions=("measured",),
        notes=notes,
    )
    return CompositionProvenance(
        native_flavour=ComposedFlavour.ANALYTICAL,
        composed_flavour=ComposedFlavour.DELTA,
        exactness=ExactnessKind.APPROXIMATION,
        certificate_kind=CertificateKind.TAYLOR_REMAINDER,
        certificate_radius={"bound": 1.0},
        origin_envelope_ids=("prior-origin",),
        operator_history=(step,),
    )


def _run_provenance_domain_case(route: str, envelope: UncertaintyEnvelope, mutate):
    class Evaluator:
        @property
        def __signature__(self) -> Signature:
            mutate()
            return Signature([Parameter("x", Parameter.POSITIONAL_OR_KEYWORD)])

        def __call__(self, x: float) -> dict[str, float]:
            return {"y": x}

    if route == "mc":
        return _propagate(route, Evaluator(), {"x": 0.0}, {"x": envelope})[0]
    method = {"dispatcher_mc": "monte_carlo", "delta": "delta", "analytical": "analytical"}[
        route
    ]
    return PropagationDispatcher(
        PropagationConfig(
            preferred_method=method,
            mc_n_samples=100,
            mc_batch_size=100,
            compute_sensitivity=False,
            delta_covariance_jitter=0.0,
        )
    ).propagate(
        Evaluator(),
        {"x": 0.0},
        {"x": envelope},
        ["y"],
        weights={"x": 1.0} if route == "analytical" else None,
    )[0]


@pytest.mark.parametrize("route", ["mc", "dispatcher_mc", "delta", "analytical"])
def test_nested_datetime_and_containers_own_the_prior_wire_meaning(route: str) -> None:
    zone = _MutableTimezone()
    marker = ["before"]
    timestamp = datetime(2026, 10, 28, 12, tzinfo=zone)
    prior = _provenance_with_notes({"nested": {"events": [(timestamp, marker)]}})
    envelope = _normal().model_copy(update={"composition_provenance": prior})
    expected = prior.operator_history[0].model_dump(mode="json")
    original_digest = _raw_identity(envelope)
    assert original_digest is not None
    mutations = []

    def mutate() -> None:
        mutations.append(True)
        zone.minutes = 60
        marker.append("after")

    result = _run_provenance_domain_case(route, envelope, mutate)
    assert mutations
    assert result.envelope.gate_eligible is True
    history = result.envelope.composition_provenance
    assert history is not None
    assert history.operator_history[0].model_dump(mode="json") == expected
    event = history.operator_history[0].notes["nested"]["events"][0]
    assert isinstance(event, tuple)
    assert isinstance(event[0], datetime)
    assert event[1] == ["before"]
    if result.method_used is PropagationMethod.MONTE_CARLO:
        ledger = result.diagnostics["draw_outcome_provenance"]
        assert ledger["input_identity_status"] == "content_hashed"
        assert ledger["sampling_recipe"]["input_envelope_sha256"]["x"] == original_digest


@pytest.mark.parametrize("route", ["mc", "dispatcher_mc", "delta", "analytical"])
@pytest.mark.parametrize("kind", ["mutable_enum", "mutable_time", "dict_subclass"])
@pytest.mark.parametrize("input_gate_eligible", [False, True])
def test_unsupported_provenance_context_is_declared_and_non_gating(
    route: str, kind: str, input_gate_eligible: bool
) -> None:
    class MutableEnum(Enum):
        VALUE = {"items": ["before"]}

    class MutableDict(dict):
        pass

    zone = _MutableTimezone()
    data = MutableDict({"items": ["before"]})
    value = {
        "mutable_enum": MutableEnum.VALUE,
        "mutable_time": time(12, tzinfo=zone),
        "dict_subclass": data,
    }[kind]
    prior = _provenance_with_notes({"nested": [(value,)]})
    envelope = _normal().model_copy(
        update={"composition_provenance": prior, "gate_eligible": input_gate_eligible}
    )
    original_digest = _raw_identity(envelope)
    assert original_digest is not None
    mutations = []

    def mutate() -> None:
        mutations.append(True)
        MutableEnum.VALUE.value["items"].append("after")
        zone.minutes = 60
        data["items"].append("after")

    result = _run_provenance_domain_case(route, envelope, mutate)
    assert mutations
    assert result.envelope.gate_eligible is False
    assert result.envelope.metadata["provenance_context_status"] == "not_established"
    assert result.diagnostics["provenance_context_status"] == "not_established"
    assert result.diagnostics["input_identity_status"] == "not_established"
    if result.method_used is PropagationMethod.MONTE_CARLO:
        ledger = result.diagnostics["draw_outcome_provenance"]
        assert ledger["input_identity_status"] == "not_established"
        assert ledger["sampling_recipe"]["input_envelope_sha256"]["x"] == original_digest


@pytest.mark.parametrize("route", ["mc", "dispatcher_mc"])
def test_empirical_cache_owns_unvalidated_ndarray_before_signature_mutation(route: str) -> None:
    samples = np.array([2.0, 2.0], dtype=np.float64)
    carrier = PosteriorSamplesCarrier(samples=(2.0, 2.0), sample_axis="row").model_copy(
        update={"samples": samples}
    )
    envelope = _empirical().model_copy(update={"distribution_payload": carrier})
    calls: list[float] = []

    class Evaluator:
        @property
        def __signature__(self) -> Signature:
            samples[:] = 99.0
            return Signature([Parameter("x", Parameter.POSITIONAL_OR_KEYWORD)])

        def __call__(self, x: float) -> dict[str, float]:
            calls.append(x)
            return {"y": x}

    result = _propagate(route, Evaluator(), {"x": 0.0}, {"x": envelope})[0]
    assert list(samples) == [99.0, 99.0]
    assert calls[0] == 0.0
    assert calls[1:] == [2.0] * 100
    assert result.envelope.point_estimate == pytest.approx(2.0)
'''
target.write_text(source)
