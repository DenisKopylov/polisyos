"""Future integration source for the registered-SQL Ex-Ante Debug oracle.

Not run at the supplied base. The fixture must be implemented with the actual
registered SQL producer, C105 owner, Foundry graph dispatch, workflow finalizer,
and Runtime Debug route. It must not build hand-authored method artifacts.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Protocol

import pytest

pytestmark = pytest.mark.integration


class RunSelection(Protocol):
    run_id: str
    node_alias: str
    simulation_result_ref: dict[str, Any]
    method_execution_bundle_ref: dict[str, Any]
    execution_input_basis_ref: dict[str, Any]
    data_snapshot_ref: dict[str, Any]
    method_input_capture_ref: dict[str, Any]
    selected_profile: dict[str, Any]


class ExAnteSQLDebugScenario(Protocol):
    sql_a_run: RunSelection
    independent_i_run: RunSelection
    carrier_a: dict[str, Any]
    carrier_i: dict[str, Any]
    event_a: str

    def endpoint(self, run: RunSelection, *, artifact_id: str | None = None): ...

    def prove_live_source_to_dispatch(self, run: RunSelection) -> dict[str, Any]:
        """Re-read actual SQL rows, selected snapshot, exact graph ABI, and prestate."""

    def owner_current(self, carrier: dict[str, Any]) -> dict[str, Any]: ...

    def withdraw_a(self) -> None: ...

    def replace_a_with_b(self) -> tuple[RunSelection, dict[str, Any]]: ...

    def read_history(self, event_id: str) -> dict[str, Any]: ...

    def install_basis_mutation(self, run: RunSelection, mutation: str) -> None: ...

    def install_hidden_read_same_scalar(self, run: RunSelection) -> None:
        """Replace pure_step after import; preserve class source and mean_change."""

    def remove_live_debug_property(self, property_name: str, run: RunSelection) -> None:
        """Remove only the actual read/replay while retaining all persisted markers."""


@pytest.fixture
def exante_sql_debug_scenario(tmp_path: Path) -> ExAnteSQLDebugScenario:
    """Root-owned fixture contract for one SQL A→D plus independent actual I run."""
    raise NotImplementedError(
        "Requires the installed SQL handoff, method-call witness, and Debug reader"
    )


def _debug(response):
    assert response.status_code == 200, response.text
    return response.json()["debug"]


def _not_selected(response) -> None:
    if response.status_code == 409:
        return
    assert response.status_code == 200, response.text
    debug = response.json()["debug"]
    replay = debug.get("exante_source_use", {})
    assert replay.get("status") in {"unknown", "verification_missing", "invalid"}
    assert replay.get("method_replay_status") in {"verification_missing", "invalid"}
    assert replay.get("recomputed_mean_change") is None


def test_real_sql_a_is_the_exact_exante_input_and_default_exact_debug_replay(
    exante_sql_debug_scenario: ExAnteSQLDebugScenario,
) -> None:
    scenario = exante_sql_debug_scenario
    run = scenario.sql_a_run
    source = scenario.prove_live_source_to_dispatch(run)

    basis = source["execution_input_basis"]
    assert basis["authority_purpose"] == "execution_input_identity_only"
    assert basis["data_snapshot_ref"] == run.data_snapshot_ref
    assert basis["input_bindings_ref"] == source["input_bindings_ref"]
    assert basis["registered_sql_admission_ref"] == source["registered_sql_admission_ref"]
    assert source["actual_basis_manifest_inputs"] == source["recomputed_basis_manifest_inputs"]
    assert source["ordered_binding_rules"] == [
        {"binding_id": "baseline", "source_path": "baseline", "target_slot_id": "baseline"},
        {"binding_id": "scenario", "source_path": "scenario", "target_slot_id": "scenario"},
    ]

    assert source["sql_rows"]["baseline"] == [10.0, 20.0, 40.0]
    assert source["sql_rows"]["scenario"] == [11.0, 18.0, 44.0]
    assert source["snapshot_ref"] == run.data_snapshot_ref
    assert source["method_input_capture_ref"] == run.method_input_capture_ref
    assert source["captured_inputs"]["baseline"] == source["sql_rows"]["baseline"]
    assert source["captured_inputs"]["scenario"] == source["sql_rows"]["scenario"]
    assert source["method_fqn"] == "policy.evaluation.ex_ante_simulation@1.0.0"
    assert source["method_abi_digest"] == source["registered_exact_abi_digest"]
    assert source["node_count"] == 1 and source["intervention_count"] == 0
    assert source["parameters"] == [
        {
            "name": "poverty_line",
            "source": source["parameter_origin_source"],
            "value": None,
        }
    ]
    assert source["parameter_origin_source"] in {"signature_default", "requested"}
    assert source["requested_backend"] == source["selected_backend"] == "numpy"
    assert source["actual_backend"] == "numpy"
    assert source["fallback_status"] == "not_fell_back"
    assert source["actual_call_witness"] == source["trusted_allowlisted_call_witness"]
    assert source["input_reads"] == ["baseline", "scenario"]
    assert source["parameter_reads"] == ["poverty_line"]

    default_response = scenario.endpoint(run)
    exact_response = scenario.endpoint(
        run,
        artifact_id=run.simulation_result_ref["artifact_id"],
    )
    default = _debug(default_response)
    exact = _debug(exact_response)
    assert default["artifact_ref"] == exact["artifact_ref"] == run.simulation_result_ref
    assert default["execution_input_basis_ref"] == run.execution_input_basis_ref
    assert default["exante_source_use"] == exact["exante_source_use"]
    assert default["exante_source_use"]["method_replay_status"] == "verified"
    assert default["exante_source_use"]["recomputed_mean_change"] == 1.0
    assert default["exante_source_use"]["status"] == "current"
    assert default_response.headers["cache-control"] == "no-store"
    assert exact_response.headers["cache-control"] == "no-store"


def test_withdrawal_of_sql_a_does_not_invalidate_independent_i_or_rewrite_history(
    exante_sql_debug_scenario: ExAnteSQLDebugScenario,
) -> None:
    scenario = exante_sql_debug_scenario
    receipt_before = scenario.read_history(scenario.event_a)
    assert scenario.owner_current(scenario.carrier_a)["status"] == "current"
    assert scenario.owner_current(scenario.carrier_i)["status"] == "current"
    assert _debug(scenario.endpoint(scenario.sql_a_run))["exante_source_use"]["status"] == "current"
    assert _debug(scenario.endpoint(scenario.independent_i_run))["exante_source_use"]["status"] == "current"

    scenario.withdraw_a()

    assert scenario.owner_current(scenario.carrier_a)["status"] == "withdrawn"
    assert scenario.owner_current(scenario.carrier_i)["status"] == "current"
    assert _debug(scenario.endpoint(scenario.sql_a_run))["exante_source_use"]["status"] == "withdrawn"
    assert _debug(scenario.endpoint(scenario.independent_i_run))["exante_source_use"]["status"] == "current"
    assert scenario.read_history(scenario.event_a) == receipt_before
    assert scenario.owner_current(scenario.carrier_a)["status"] == "withdrawn"


def test_a_after_b_is_a_separate_run_and_old_result_cannot_be_reselected(
    exante_sql_debug_scenario: ExAnteSQLDebugScenario,
) -> None:
    scenario = exante_sql_debug_scenario
    run_b, carrier_b = scenario.replace_a_with_b()

    assert scenario.owner_current(scenario.carrier_a)["status"] == "withdrawn"
    assert scenario.owner_current(carrier_b)["status"] == "current"
    assert _debug(scenario.endpoint(scenario.sql_a_run))["exante_source_use"]["status"] == "withdrawn"
    assert _debug(scenario.endpoint(run_b))["exante_source_use"]["status"] == "current"
    old = scenario.endpoint(
        run_b,
        artifact_id=scenario.sql_a_run.simulation_result_ref["artifact_id"],
    )
    assert old.status_code == 409


@pytest.mark.parametrize(
    "mutation",
    [
        "execution_basis_missing",
        "method_bundle_missing",
        "input_capture_profileless",
        "prestate_ref_substituted",
        "baseline_value_changed",
        "scenario_value_changed",
        "source_a_edge_missing",
        "duplicate_method_occurrence",
        "extra_method_or_intervention",
        "abi_or_version_changed",
        "mean_change_path_changed",
        "poverty_line_not_none",
        "default_unresolved",
        "selected_runner_changed",
        "actual_backend_mismatch",
        "fallback_used",
        "output_ref_substituted",
        "cross_tenant_or_cell",
        "prior_run_artifact_profile",
    ],
)
def test_source_basis_and_exact_method_profile_mutations_fail_closed(
    exante_sql_debug_scenario: ExAnteSQLDebugScenario,
    mutation: str,
) -> None:
    scenario = exante_sql_debug_scenario
    scenario.install_basis_mutation(scenario.sql_a_run, mutation)
    _not_selected(scenario.endpoint(scenario.sql_a_run))


def test_same_scalar_hidden_global_read_fails_executable_readset_admission(
    exante_sql_debug_scenario: ExAnteSQLDebugScenario,
) -> None:
    scenario = exante_sql_debug_scenario
    scenario.install_hidden_read_same_scalar(scenario.sql_a_run)
    response = scenario.endpoint(scenario.sql_a_run)

    # The mutant returns the same numeric scalar and leaves class-source/ABI
    # markers unchanged. Only an actual callable witness plus restricted readset
    # admission distinguishes it from the supported built-in execution.
    _not_selected(response)


@pytest.mark.parametrize(
    "removed_property",
    [
        "fresh_c105_current_use_read",
        "method_call_witness_compare",
        "actual_input_readset_observation",
        "registered_mean_change_recompute",
    ],
)
def test_removing_live_property_while_preserving_markers_is_detected(
    exante_sql_debug_scenario: ExAnteSQLDebugScenario,
    removed_property: str,
) -> None:
    scenario = exante_sql_debug_scenario
    scenario.remove_live_debug_property(removed_property, scenario.sql_a_run)
    _not_selected(scenario.endpoint(scenario.sql_a_run))
