"""Prepare one new source-bound C32 native plan; never execute it."""
from __future__ import annotations
import argparse, ast, hashlib, itertools, json, subprocess
from pathlib import Path
R=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos');P=R/'policy-engine';HERE=Path(__file__).resolve().parent
D=P/'docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1'
IDENT='tests/unit/runtime/quality/test_catalog_source_identity.py';VAR='tests/unit/data_forge/domains/catalog/knowledge/test_variable_availability.py';GRAPH='tests/unit/runtime/quality/test_catalog_acquisition_source_binding.py'
MODES={'pilot':[IDENT+'::test_available_owner_reads_all_actual_rows_under_the_admitted_source',VAR+'::test_empty_initial_native_identity_is_typed_error_not_absent_data'],'gateway':[GRAPH],'fabric-family':['tests/unit/fabric/retrieval/test_catalog_read_source_failure.py'],'n7-source':['tests/unit/runtime/quality/test_catalog_n7_source_refusal.py'],'owner':[IDENT,VAR],'store':['tests/unit/data_forge/domains/catalog/knowledge/test_store.py','tests/unit/data_forge/domains/catalog/knowledge/test_overlay.py'],'registry':['tests/unit/runtime/quality/test_substrate_registry.py','tests/unit/runtime/quality/test_data_state_substrate.py','tests/unit/runtime/quality/test_acquisition_planner.py'],'calibration':['tests/unit/runtime/http/test_predictive_calibration_profile_boundary.py','tests/unit/runtime/http/test_predictive_calibration_event_selection.py','tests/integration/core_runtime/test_predictive_calibration_profile_owner_binding.py'],'residual':['tests/unit/data_forge/domains/catalog/knowledge/test_catalog_custody_boundary.py']}
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=R)
def load(p):return json.loads(p.read_text())
def receipt(path,phase,mode):
 q=load(path);assert q['qualification']=='qualified' and q['phase']==phase and q['mode']==mode
 for e in q['evidence']:assert sha((R/e['path']).read_bytes())==e['sha256']
 return {'path':str(path),'sha256':sha(path.read_bytes()),'actual_child_profiles':q['actual_child_profiles'],'selected_nodeids':q['selected_nodeids'],'committed_input_sha256':q['committed_input_sha256'],'observed_module_pins':q['observed_module_pins']}
def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('--source-head',required=True);a.add_argument('--source-tree',required=True);a.add_argument('--case-id',required=True);a.add_argument('--mode',required=True);a.add_argument('--phase',choices=['positive','before','mutant','restored'],default='positive');a.add_argument('--before-receipt',type=Path);a.add_argument('--mutant-receipt',type=Path);a.add_argument('--mutant-review',type=Path);a.add_argument('--preview',action='store_true');x=a.parse_args()
 m=load(HERE/'manifest.json');assert all(sha((R/p).read_bytes())==h for p,h in m['artifacts'].items())
 bind=load(HERE/'source-bindings.json');head=git('rev-parse','HEAD').decode().strip();source_tree=git('rev-parse','HEAD^{tree}').decode().strip();assert (head,source_tree)==(x.source_head,x.source_tree)
 assert git('symbolic-ref','--short','HEAD').decode().strip()=='codex/e02-unified-local-20261009';assert not git('status','--porcelain','--untracked-files=no')
 assert subprocess.run(['git','merge-base','--is-ancestor',bind['base_commit'],head],cwd=R).returncode==0
 assert x.case_id and all(c.isalnum() or c in '-_' for c in x.case_id)
 controls=load(HERE/'controls.json');priors=[]
 if x.phase=='positive':
  if x.mode=='companions':nodes=[n for n in load(R/'LOCAL/raw/e02-execution-20261027/repairs/C32-r7/affected-nodes.json')['nodes'] if not n.startswith('tests/unit/runtime/http/test_search_hte_first_assessment_outbox.py')]
  else:nodes=MODES[x.mode]
 else:
  nodes=[controls[x.mode]['node']]
  if x.phase in ['mutant','restored']:
   assert x.before_receipt;priors.append(receipt(x.before_receipt,'before',x.mode))
  if x.phase=='restored':
   assert x.mutant_receipt and x.mutant_review;priors.append(receipt(x.mutant_receipt,'mutant',x.mode));review=load(x.mutant_review)
   assert review.get('reviewer_identity') and review['verdict']=='expected_semantic_failure' and review['mutant_receipt_sha256']==priors[1]['sha256'] and review['explanation']
   assert priors[0]['selected_nodeids']==priors[1]['selected_nodeids'] and priors[0]['actual_child_profiles']==priors[1]['actual_child_profiles']
 for prior in priors:
  # Compare with the actually selected finite input denominator after it is built below.
  for p,h in prior['observed_module_pins'].items():assert sha((P/p).read_bytes())==h,('prior actual imported module changed; requalify affected baseline',p)
 inputs={p:pin for p,pin in bind['inputs'].items() if p.startswith('policy-engine/src/') and p.endswith('.py') or p in ['policy-engine/pytest.ini','policy-engine/pyproject.toml','policy-engine/uv.lock']};absent=[]
 # Explicit nodes, all ancestor conftests and direct known fixture imports; never rely on selected-test-only pins.
 for node in nodes:
  f=P/node.split('::')[0];assert f.is_file()
  if '::' in node:assert node.split('::')[1] in {n.name for n in ast.parse(f.read_bytes()).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
  inputs[str(f.relative_to(R))]={'sha256':sha(f.read_bytes()),'git_blob':git('rev-parse',head+':'+str(f.relative_to(R))).decode().strip(),'kind':'selected native input'}
  for parent in [f.parent,*f.parents]:
   if not parent.is_relative_to(P):break
   c=parent/'conftest.py';rel=str(c.relative_to(R))
   if c.is_file():inputs[rel]={'sha256':sha(c.read_bytes()),'git_blob':git('rev-parse',head+':'+rel).decode().strip(),'kind':'pytest ancestor'}
   else:absent.append(rel)
 # Syntax-derived local tests/tools import closure, including function-local imports.
 queue=[P/node.split('::')[0] for node in nodes]+[R/p for p in inputs if p.endswith('conftest.py')];seen=set()
 while queue:
  f=queue.pop()
  if f in seen:continue
  seen.add(f);rel=str(f.relative_to(R));raw=f.read_bytes()
  baseline=git('show',bind['base_commit']+':'+rel)
  assert raw==baseline,('selected fixture/helper changed since reviewed base',rel)
  inputs[rel]={'sha256':sha(raw),'git_blob':git('rev-parse',head+':'+rel).decode().strip(),'kind':'finite local test/tools AST-import closure'}
  for n in ast.walk(ast.parse(raw)):
   modules=[]
   if isinstance(n,ast.Import):modules=[a.name for a in n.names]
   elif isinstance(n,ast.ImportFrom) and n.module and not n.level:modules=[n.module]+[n.module+'.'+a.name for a in n.names if a.name!='*']
   for module in modules:
    if not module.startswith(('tests.','tools.')):continue
    base=P/Path(*module.split('.'))
    for candidate in [base.with_suffix('.py'),base/'__init__.py']:
     if candidate.is_file():queue.append(candidate)
 for prior in priors:assert prior['committed_input_sha256']=={p:v['sha256'] for p,v in inputs.items()}
 expected=[]
 for node in nodes:
  f=P/node.split('::')[0];tree=ast.parse(f.read_bytes())
  for fn in tree.body:
   if not isinstance(fn,(ast.FunctionDef,ast.AsyncFunctionDef)) or not fn.name.startswith('test_'):continue
   if '::' in node and fn.name!=node.split('::')[1]:continue
   params=[{}]
   for d in fn.decorator_list:
    if isinstance(d,ast.Call) and isinstance(d.func,ast.Attribute) and d.func.attr=='parametrize':
     names=ast.literal_eval(d.args[0]);names=[v.strip() for v in names.split(',')] if isinstance(names,str) else list(names)
     
     try:values=ast.literal_eval(d.args[1])
     except (ValueError,TypeError):params=None;break
     additions=[dict(zip(names,(v,) if len(names)==1 else v,strict=True)) for v in values]
     params=[{**a,**b} for a,b in itertools.product(params,additions)]
   expected.append({'node_prefix':node.split('::')[0]+'::'+fn.name,'parameters':params})
 for p,pin in inputs.items():assert (R/p).read_bytes()==git('show',head+':'+p) and sha((R/p).read_bytes())==pin['sha256']
 path=D/(x.case_id+'.json');assert not path.exists() and not (D/x.case_id).exists()
 toolpaths=[D/'run_case_with_tools_r2.py',D/'readset_observer_tools_r1.py',D.parent/'root-layer-lib.py',P/'docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-postfix-709-q2-helper-actual-20261018/supervise.py']
 env={'PYTEST_PLUGINS':'c32_native_plugin','PYTHONPATH':str(HERE),'C32_PLUGIN_SHA256':sha((HERE/'c32_native_plugin.py').read_bytes()),'C32_PLAN_PATH':str(path)}
 plan={'case_id':x.case_id,'source_head':head,'source_tree':source_tree,'task_ids':['C32','V4','V7'],'nodes':nodes,'extra_env':env,'deadline_seconds':600,'rss_cap_bytes':2411724800,'scope':'Bounded composed Catalog byte identity/actual consumers/source-refusal transport. No production authority/currentness, atomic filesystem custody, ordinary served N7, full V4/V7, G acceptance or closure. First unknown profile alone. HTE withheld pending C71 source guard.','control_mode':None if x.phase=='positive' else x.mode,'control_phase':x.phase,'prior_qualified_receipts':priors,'expected_roster':expected,'independent_mutant_review':None if x.phase!='restored' else {'path':str(x.mutant_review),'sha256':sha(x.mutant_review.read_bytes()),'reviewer_identity':review['reviewer_identity'],'verdict':review['verdict'],'mutant_receipt_sha256':review['mutant_receipt_sha256']},'c32_binding':{'baseline':bind['base_commit'],'committed_inputs':inputs,'absent_ancestor_conftests':sorted(set(absent)),'tool_pins':{str(p.relative_to(R)):sha(p.read_bytes()) for p in toolpaths},'packet_manifest':str((HERE/'manifest.json').relative_to(R)),'packet_manifest_sha256':sha((HERE/'manifest.json').read_bytes()),'actual_dynamic_readset':'Required after run; static explicit pins are not a transitive import census'},'closure_ids':[]}
 if x.phase!='positive':plan['control_hypothesis']=controls[x.mode]
 data=(json.dumps(plan,indent=2)+'\n').encode()
 if x.preview:
  out=HERE/'previews';out.mkdir(exist_ok=True);path=out/(x.case_id+'.json');assert not path.exists()
 with path.open('xb') as f:f.write(data)
 print(json.dumps({'prepared_only':True,'preview_not_launchable':x.preview,'plan':str(path),'sha256':sha(data),'source_head':head,'source_tree':source_tree,'nodes':nodes,'runtime':'UNRUN'}))
if __name__=='__main__':main()
