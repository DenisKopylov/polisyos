from pathlib import Path
import ast,hashlib,json,subprocess,difflib
R=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos');out=R/'LOCAL/raw/e02-execution-20261027/repairs/C18-r2';cloud=R/'LOCAL/raw/e02-execution-20261027/cloud/C18';base='8db01b1076e425b7998b05a658776c991b7bd594';tree='6d452816f2c7c5e2d121b40c6c0d9b6f58b843c1';m=json.loads((cloud/'candidate-manifest.json').read_text());H=lambda b:hashlib.sha256(b).hexdigest();get=lambda x:subprocess.check_output(['git','cat-file','blob',x],cwd=R);records={x['path']:x for x in m['files']};testsrc='policy-engine/tests/unit/foundry/methods/catalog/causal/test_rdd_rbc_c18_oracle.py';testdst='policy-engine/tests/unit/foundry/methods/catalog/causal/test_rdd_rbc_independent_oracle.py';readme='policy-engine/src/polisyos/foundry/methods/catalog/causal/README.md';t=get(records[testsrc]['postimage_git_blob']).decode();
def repl(old,new):
 global t
 assert t.count(old)==1,(old,t.count(old));t=t.replace(old,new)
repl('COVERAGE_SEED = 2_026_102_701','COVERAGE_SEED = 2_026_102_803')
repl('# Fixed before the run: a conservative three-binomial-SE band about 95% is\n# [0.9173, 0.9827] at n=400; rounded outward to avoid false precision.','# Prospective fixed criterion: three binomial standard errors about 95% give\n# [0.9173, 0.9827] at n=400; round outward to avoid false precision.\n# Do not change the seed or band after observing this deciding run.')
repl('def _oracle_side(x: np.ndarray, y: np.ndarray, *, right: bool) -> tuple[float, float]:','def _oracle_side(\n    x: np.ndarray, y: np.ndarray, *, right: bool, h: float, b: float\n) -> tuple[float, float]:')
# Replace bandwidth symbols inside oracle only; global constants remain the defaults for _params and coverage.
start=t.index('def _oracle_side(');end=t.index('\n\ndef _sample(',start);part=t[start:end];part=part.replace('/ H','/ h').replace('/ B','/ b').replace('(H / b)','(h / b)');assert '/ H' not in part and '/ B' not in part and '(H / b)' not in part
old='def _oracle(x: np.ndarray, y: np.ndarray) -> tuple[float, float]:\n    left, left_variance = _oracle_side(x, y, right=False)\n    right, right_variance = _oracle_side(x, y, right=True)'
new='def _oracle(\n    x: np.ndarray, y: np.ndarray, *, h: float = H, b: float = B\n) -> tuple[float, float]:\n    left, left_variance = _oracle_side(x, y, right=False, h=h, b=b)\n    right, right_variance = _oracle_side(x, y, right=True, h=h, b=b)'
assert part.count(old)==1;part=part.replace(old,new);t=t[:start]+part+t[end:]
repl('def test_independent_sensitivity_oracle_matches_corrected_point_and_hc0_se() -> None:\n    data = _sample()\n    expected_point, expected_se = _oracle(data.running_variable, data.outcome)\n    report = rdd.RegressionDiscontinuity.pure_step(data, _params())["report"]\n    conventional = rdd.RegressionDiscontinuity.pure_step(\n        data, _params(bias_correction=False)\n    )["report"]', '''@pytest.mark.parametrize(("h", "b"), [(0.45, 0.70), (0.70, 0.45)], ids=["h_lt_b", "h_gt_b"])
def test_independent_sensitivity_oracle_matches_corrected_point_and_hc0_se(
    h: float, b: float
) -> None:
    data = _sample()
    expected_point, expected_se = _oracle(data.running_variable, data.outcome, h=h, b=b)
    params = _params(bandwidth=h, bias_bandwidth=b)
    report = rdd.RegressionDiscontinuity.pure_step(data, params)["report"]
    conventional = rdd.RegressionDiscontinuity.pure_step(
        data, _params(bandwidth=h, bias_bandwidth=b, bias_correction=False)
    )["report"]''')
repl('    assert H / B == pytest.approx(9 / 14)\n','    assert report.method_params["h"] == [h, h]\n    assert report.method_params["b"] == [b, b]\n')
repl('    zero = np.zeros_like(ys)\n','')
repl('        store = _ensure_ir_artifact_store(FileSystemCAS(tmp_path))\n        artifact = persist_causal_effect_report(store, result.output["report"])\n        loaded = load_causal_effect_report(store, artifact)','        writer = _ensure_ir_artifact_store(FileSystemCAS(tmp_path))\n        artifact = persist_causal_effect_report(writer, result.output["report"])\n        reader = _ensure_ir_artifact_store(FileSystemCAS(tmp_path))\n        assert reader is not writer\n        loaded = load_causal_effect_report(reader, artifact)')
repl('        assert loaded.method_params["profile"] == "sharp_cct_rbc_hc0_fixed"','''        assert loaded.method_params["profile"] == "sharp_cct_rbc_hc0_fixed"
        assert loaded.method_params["h"] == [H, H]
        assert loaded.method_params["b"] == [B, B]
        assert loaded.method_params["p"] == 1
        assert loaded.method_params["q"] == 2
        assert loaded.method_params["input_sha256"] == result.output["report"].method_params[
            "input_sha256"
        ]''')
insert='''

def test_zero_curvature_produces_zero_correction_and_known_jump() -> None:
    x, _, _ = _fixed_design()
    # Exact piecewise linear means have no p+1 derivative on either side.
    y = 1.0 + 0.3 * x + np.where(x < 0.0, 0.0, TRUE_JUMP + 0.4 * x)
    data = RDDObservationalData(running_variable=x, outcome=y, cutoff=0.0)
    expected_point, expected_se = _oracle(x, y)
    corrected = rdd.RegressionDiscontinuity.pure_step(data, _params())["report"]
    conventional = rdd.RegressionDiscontinuity.pure_step(
        data, _params(bias_correction=False)
    )["report"]
    assert corrected.status is conventional.status is EstimationStatus.SUCCESS
    assert corrected.point_estimate == pytest.approx(TRUE_JUMP, abs=2e-11)
    assert corrected.point_estimate == pytest.approx(expected_point, abs=2e-11)
    assert corrected.standard_error == pytest.approx(expected_se, abs=2e-11)
    assert corrected.point_estimate == pytest.approx(conventional.point_estimate, abs=2e-11)
    assert corrected.method_params["bias"] == pytest.approx(0.0, abs=2e-11)
'''
anchor='\n\ndef test_oracle_checked_profile_survives_dispatch_cas_and_fresh_reader';assert t.count(anchor)==1;t=t.replace(anchor,insert+anchor)
ast.parse(t)
# Canonical ruff formatter receives source via stdin and does not touch either tree.
formatter=subprocess.run([str(R/'policy-engine/.venv/bin/python'),'-m','ruff','format','--stdin-filename',testdst.removeprefix('policy-engine/'),'-'],input=t.encode(),capture_output=True,cwd=R/'policy-engine');assert formatter.returncode==0,formatter.stderr.decode();formatted=formatter.stdout.decode();assert ast.dump(ast.parse(t),include_attributes=False)==ast.dump(ast.parse(formatted),include_attributes=False);t=formatted
check=subprocess.run([str(R/'policy-engine/.venv/bin/python'),'-m','ruff','check','--stdin-filename',testdst.removeprefix('policy-engine/'),'-'],input=t.encode(),capture_output=True,cwd=R/'policy-engine');(out/'ruff-check.stdout').write_bytes(check.stdout);(out/'ruff-check.stderr').write_bytes(check.stderr);assert check.returncode==0,check.stdout.decode()+check.stderr.decode()
files={testdst:t.encode(),readme:get(records[readme]['postimage_git_blob'])}
for x in m['files']:
 if x.get('delivered_file'):
  b=(R/x['delivered_file']).read_bytes();assert H(b)==x['postimage_sha256'];files[x['path']]=b
qual='''# C18 evidence qualification and prospective local witness

This note supplements the received author receipt without changing its historical bytes. The received task diff is SHA-256 `9e668ff47e85bd8600f803cd6314227555bd5a2cc11b42c0e40264f1ffdadc0e`; the candidate tree reconstructed locally from those bytes is `6d452816f2c7c5e2d121b40c6c0d9b6f58b843c1`. Its original test blob is `22353c60eeb99974bb95ed5fa00892a66c462e66` (SHA-256 `aa89ce22233810d1444d2b24f8482d6dcf3d647e7b048d1a771cec07262824df`). The original receipt names neither a final commit/tree nor the test-source hash at execution. The reconstructed delivery tree and the delivered outputs do not independently establish which exact source bytes executed. Its statement that the coverage seed/band were fixed before that run is author-reported; independent prior registration is not established.

The cloud test constructed a new typed report from persisted bytes but reused one filesystem CAS adapter instance for writing and loading. Its "fresh reader" wording does not establish a separately opened store. It asserted the profile field, point and standard error; it did not assert that `h`, `b`, `p`, and `q` survived. The separate existing `test_rdd_rbc.py` bridge has its own source and output boundary. All cloud summaries remain author results, not local composition, independent review, G acceptance or closure. The complete delivered cloud stdout/JUnit and setup output are retained unchanged alongside the receipt.

The proposed capability-named oracle now opens another filesystem CAS adapter, checks `h/b/p/q` and input identity, exercises exact zero-curvature zero correction, and independently calculates point and HC0 SE for both `h < b` and `h > b`. Its fixed deciding coverage seed is `2026102803`, different from the author-reported historical seed `2026102701`. Its 400-replication band remains `[0.915, 0.985]` from the predeclared three-binomial-standard-error formula. Root must commit the exact proposed test and read it back **before** running the new seed to establish ordering for the prospective run; the seed must not be tuned after seeing that result. A commit-before-run record alone does not establish scientific independence from every prior observation. All new tests, coverage and marker-preserving point/variance removals remain **UNRUN** until the source-bound local execution completes.

Scope is original `B210@CAU-03`, coverage `#/findings/131/criterion_refs/0`, with fixed synthetic forcing design, p=1/q=2, triangular kernel, explicit h/b, HC0 and nonconstant conditional SD. Passing it does not establish arbitrary kernels, orders, selectors, production currentness or general finite-sample coverage. `closure_ids=[]`.
'''
qpath='policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/C18/cloud/e02-c18-20261027-r1/RECEIPT-QUALIFICATION.md';files[qpath]=qual.encode();pre={};manifest=[];diff=[]
for p,b in files.items():
 path=R/p;old=path.read_bytes() if path.exists() else None
 try:basebytes=subprocess.check_output(['git','show',base+':'+p],cwd=R,stderr=subprocess.DEVNULL)
 except subprocess.CalledProcessError:basebytes=None
 assert old==basebytes,(p,'current differs from base');dest=out/'postimages'/p;dest.parent.mkdir(parents=True,exist_ok=True);assert not dest.exists();dest.write_bytes(b)
 x={'path':p,'base_sha256':H(basebytes) if basebytes is not None else None,'current_sha256':H(old) if old is not None else None,'postimage_sha256':H(b),'bytes':len(b),'postimage_path':str(dest.relative_to(R)),'historical_delivery':p in records and p!=readme,'new_file':basebytes is None};manifest.append(x)
 oldtext=(basebytes or b'').decode();newtext=b.decode();diff.append('diff --git a/'+p+' b/'+p+'\n')
 if basebytes is None:diff.append('new file mode 100644\n')
 diff.extend(difflib.unified_diff(oldtext.splitlines(keepends=True),newtext.splitlines(keepends=True),fromfile='/dev/null' if basebytes is None else 'a/'+p,tofile='b/'+p))
patch=''.join(diff).encode();(out/'base-to-proposal.patch').write_bytes(patch);manifest_doc={'scope':'C18 B210 independent RDD oracle + truthful bounded README + unchanged received cloud evidence and qualification','base_commit':base,'cloud_candidate_tree':tree,'cloud_received_diff_sha256':m['received_diff_sha256'],'original_test_git_blob':records[testsrc]['postimage_git_blob'],'original_test_sha256':records[testsrc]['postimage_sha256'],'renamed_test':testdst,'coverage_seed':2026102803,'coverage_band':[0.915,0.985],'file_count':len(manifest),'files':manifest,'patch_sha256':H(patch),'runtime':'UNRUN for new proposal; historical cloud results are source-unbound author evidence','canonical_mutations':False,'index_refs_mutations':False,'G_acceptance':False,'closure_ids':[]};(out/'manifest.json').write_text(json.dumps(manifest_doc,indent=2)+'\n');print(json.dumps({'files':len(manifest),'patch_sha256':H(patch),'manifest_sha256':H((out/'manifest.json').read_bytes()),'test_sha256':H(files[testdst]),'ruff_exit':check.returncode}))
