"""Enumerate syntactic world-model fixture consumers across test Python files."""
from __future__ import annotations

import ast
import hashlib
import json
import os
from pathlib import Path

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
TESTS = ROOT / "policy-engine/tests"
PROBE_NAMES = {"_build_record", "_write_fabric_world_snapshot", "_skg_ref"}
paths = []
symlink_files = []
for parent, dirs, names in os.walk(TESTS, followlinks=False):
    dirs[:] = [d for d in dirs if not (Path(parent) / d).is_symlink()]
    for name in names:
        candidate = Path(parent) / name
        if candidate.suffix != ".py":
            continue
        if candidate.is_symlink():
            symlink_files.append(str(candidate.relative_to(ROOT)))
        else:
            paths.append(candidate)
imports = []
calls = []
errors = []
dynamic = []
for path in sorted(paths):
    try:
        text = path.read_text(encoding="utf-8")
    except (OSError, UnicodeError) as exc:
        errors.append({"path": str(path.relative_to(ROOT)), "type": type(exc).__name__})
        continue
    if "world_model_record" not in text or "_helpers" not in text:
        continue
    try:
        tree = ast.parse(text, filename=str(path))
    except SyntaxError as exc:
        errors.append({"path": str(path.relative_to(ROOT)), "type": "SyntaxError", "line": exc.lineno})
        continue
    module_aliases = set()
    direct_aliases = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            if node.module in {"tests._helpers", "_helpers"}:
                module_aliases.update(
                    item.asname or item.name for item in node.names if item.name == "world_model_record"
                )
            if node.module in {"tests._helpers.world_model_record", "_helpers.world_model_record"}:
                direct_aliases.update(
                    {item.asname or item.name: item.name for item in node.names}
                )
        elif isinstance(node, ast.Import):
            for item in node.names:
                if item.name in {"tests._helpers.world_model_record", "_helpers.world_model_record"}:
                    if item.asname:
                        module_aliases.add(item.asname)
                    else:
                        dynamic.append({"path": str(path.relative_to(ROOT)), "line": node.lineno,
                                        "reason": "unaliased dotted import; review manually"})
    if not module_aliases and not direct_aliases:
        continue
    imports.append({"path": str(path.relative_to(ROOT)), "module_aliases": sorted(module_aliases),
                    "direct_aliases": direct_aliases})
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        target = None
        if isinstance(node.func, ast.Name):
            target = direct_aliases.get(node.func.id)
        elif isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name):
            if node.func.value.id in module_aliases:
                target = node.func.attr
        if target in PROBE_NAMES:
            calls.append({"path": str(path.relative_to(ROOT)), "line": node.lineno,
                          "function": target,
                          "first_arg": ast.unparse(node.args[0]) if node.args else None})
        if isinstance(node.func, ast.Name) and node.func.id == "getattr" and node.args:
            if isinstance(node.args[0], ast.Name) and node.args[0].id in module_aliases:
                dynamic.append({"path": str(path.relative_to(ROOT)), "line": node.lineno,
                                "reason": "dynamic fixture attribute; review manually"})
report = {
    "scope": "all physical .py files under policy-engine/tests; symbolic-link files/directories excluded and reported; other repo roots and runtime-generated files not covered",
    "tests_python_file_denominator": len(paths), "symlink_python_files": symlink_files,
    "errors": errors, "importing_files": imports, "calls_to_workspace_helpers": calls,
    "dynamic_or_unaliased": dynamic,
    "method": "stdlib AST; module/dotted imports tracked syntactically; aliases may be shadowed; call arguments not executed",
}
encoded = (json.dumps(report, indent=2, sort_keys=True) + "\n").encode()
out = Path(__file__).with_name("caller-census.json")
with out.open("xb") as stream:
    stream.write(encoded)
print(json.dumps({"report": str(out), "sha256": hashlib.sha256(encoded).hexdigest(),
                  "python_files": len(paths), "importing_files": len(imports),
                  "calls": len(calls), "errors": len(errors), "dynamic": len(dynamic)}))  # noqa: T201
