"""Behavioral release controls through actual Core runs and generic CAS readers."""

from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING
from uuid import uuid4

import pytest
from pydantic import BaseModel, ConfigDict

from polisyos.core.artifacts.child_release import ChildReleaseUnavailableError
from polisyos.core.artifacts.manifest import ArtifactRef, SchemaInfo
from polisyos.core.artifacts.store import FileSystemCAS, PutOptions
from polisyos.core.registry import build_default_registry_bundle
from polisyos.core.run.child_custody import (
    ChildComputationBinding,
    ChildComputationCustody,
    ChildGuardedTransferUnknown,
    ChildParentSettlementError,
    ChildRevocationUnknown,
)
from polisyos.core.run.context import RunContext

if TYPE_CHECKING:
    from collections.abc import Iterator
    from pathlib import Path

    from polisyos.core.artifacts.protocol import ArtifactReader, ArtifactStore


class _Projection(BaseModel):
    """A test-owned typed payload whose edge is intentionally not manifest-only."""

    model_config = ConfigDict(extra="forbid")
    selected: ArtifactRef


class _TypedResolver:
    def resolve(
        self, store: ArtifactReader, projection_ref: ArtifactRef
    ) -> tuple[ArtifactRef, ...]:
        manifest = store.get_manifest(projection_ref)
        if manifest.kind == "tests.child.value":
            return ()
        if manifest.kind != "tests.child.projection":
            raise ValueError("unsupported_test_schema")
        selected = _Projection.model_validate_json(store.get_bytes(projection_ref)).selected
        store.get_bytes(selected)
        return (selected,)


def _root(tmp_path: Path) -> tuple[RunContext, ChildComputationBinding]:
    store = FileSystemCAS(tmp_path / "served", ownership_enforced=False)
    registry = build_default_registry_bundle(store, return_selected_profile=True)
    root = RunContext.start(
        store, registry.bundle_ref, run_id="root", run_dir=store.root / "runs" / "root"
    )
    workflow = store.put_json(
        {},
        PutOptions(kind="tests.workflow", media_type="application/json"),
        return_selected_profile=True,
    )
    state = store.put_json(
        {},
        PutOptions(kind="tests.state", media_type="application/json"),
        return_selected_profile=True,
    )
    attempt_id = str(uuid4())
    basis = root._record_runtime_invocation_started(
        attempt_id=attempt_id,
        attempt_number=1,
        workflow_spec_ref=workflow,
        node_alias="parent",
        component_id="tests.parent",
        input_state_ref=state,
    )
    binding = ChildComputationBinding(
        root_run_id="root",
        control_job_id=None,
        parent_attempt_id=attempt_id,
        parent_basis_ref=basis,
        tenant_id=None,
        cell_id=None,
        policy_id="tests.local_builtin",
        policy_version="1",
        template_sha256="sha256:" + "1" * 64,
        admission_id="actual_test_engine_admission",
        child_invocation_id="parent-session",
        admission_generation=1,
        deadline=datetime.now(UTC) + timedelta(minutes=5),
    )
    return root, binding


def _value(store: ArtifactStore, data: bytes = b"candidate") -> ArtifactRef:
    return store.put_bytes(
        data, PutOptions(kind="tests.child.value", media_type="application/octet-stream")
    )


def test_child_is_distinct_and_private_until_final_parent_selected_release(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    root, binding = _root(tmp_path)
    custody = ChildComputationCustody(
        root, staging_root=tmp_path / "private", closure_resolver=_TypedResolver()
    )
    parent = custody.parent_store(binding, input_refs=())
    scope = custody.open_scope(
        binding.model_copy(update={"child_invocation_id": "child-1"}), input_refs=()
    )
    assert scope.run.run_manifest.run_id != root.run_manifest.run_id
    assert scope.run.run_manifest.parent_run_id == root.run_manifest.run_id
    assert scope.run._runtime_invocation_tail_ref is None
    selected = _value(scope.store)
    unselected = _value(scope.store, b"unselected candidate")
    assert selected.manifest_profile_sha256 is not None
    # Child writers do not create a legacy default sidecar in any CAS.
    assert not custody._stage._paths(selected.artifact_id)[1].exists()
    assert selected.artifact_id not in tuple(custody._stage.iter_artifact_ids())
    scope.run.add_output(selected)
    scope.run.finalize()
    assert root.run_manifest.status == "running"
    handoff = custody.admit_handoff(scope, selected)
    assert parent.get_bytes(selected) == b"candidate"
    with pytest.raises(ChildReleaseUnavailableError, match="private_exact_read_basis_denied"):
        parent.get_bytes(unselected)
    # This unit resolver follows the payload but does not establish production
    # typed-closure reconciliation; the real resolver is verified separately.
    final = parent.put_json(
        _Projection(selected=selected).model_dump(mode="json"),
        PutOptions(
            kind="tests.child.projection",
            media_type="application/json",
            schema=SchemaInfo(name="tests.ChildProjection", version="1"),
        ),
    )
    original_publish = FileSystemCAS._publish_child_release_profiles
    observed_pending: list[str] = []

    def observing_publish(
        self: FileSystemCAS,
        source: FileSystemCAS,
        refs: tuple[ArtifactRef, ...],
        ledger: object,
        *,
        token: object,
    ) -> object:
        result = original_publish(self, source, refs, ledger, token=token)
        reader = FileSystemCAS(self.root, ownership_enforced=False)
        for ref in refs:
            for consume in (
                reader.get_bytes,
                reader.get_manifest,
                reader.get_raw_manifest_bytes,
                reader.get_manifest_bytes,
                reader.verify,
                reader.has,
            ):
                with pytest.raises(ChildReleaseUnavailableError, match="not_released"):
                    consume(ref)
            with pytest.raises(ChildReleaseUnavailableError, match="not_released"):
                with reader.open_member(ref, "blob"):
                    pass
            with pytest.raises(ChildReleaseUnavailableError, match="not_released"):
                reader.export_subgraph([ref], tmp_path / "pending.tar")
            observed_pending.append(str(ref.artifact_id))
        return result

    monkeypatch.setattr(FileSystemCAS, "_publish_child_release_profiles", observing_publish)
    receipt = custody.release_parent((handoff,), final)
    assert observed_pending
    assert receipt.execution_outcome == "completed"
    assert receipt.release_outcome == "released"
    assert {ref.kind for ref in receipt.released_refs} == {
        "tests.child.value",
        "tests.child.projection",
    }
    fresh = FileSystemCAS(root.store.root, ownership_enforced=False)
    assert fresh.get_bytes(selected) == b"candidate"
    assert _Projection.model_validate_json(fresh.get_bytes(final)).selected == selected
    assert fresh.get_manifest(receipt.release_ref).kind == "core.child_computation_release"
    with pytest.raises((FileNotFoundError, ChildReleaseUnavailableError)):
        fresh.get_bytes(unselected)
    root.emit("tests", "PARENT_STILL_ACTIVE")
    root.finalize()


def test_missing_or_corrupt_owner_head_refuses_fresh_generic_read(tmp_path: Path) -> None:
    root, binding = _root(tmp_path)
    custody = ChildComputationCustody(
        root, staging_root=tmp_path / "private", closure_resolver=_TypedResolver()
    )
    parent = custody.parent_store(binding, input_refs=())
    final = _value(parent)
    receipt = custody.release_parent((), final)
    reader = FileSystemCAS(root.store.root, ownership_enforced=False)
    assert reader.get_bytes(final) == b"candidate"
    head = (
        root.store.root
        / "artifacts/ownership/child_releases/heads"
        / (receipt.release_id + ".json")
    )
    original = head.read_bytes()
    head.write_bytes(b"{}")
    with pytest.raises(ChildReleaseUnavailableError):
        reader.get_bytes(final)
    head.write_bytes(original)
    unavailable = head.with_suffix(".unavailable")
    head.rename(unavailable)
    with pytest.raises(ChildReleaseUnavailableError):
        reader.get_bytes(final)
    unavailable.rename(head)
    assert reader.get_bytes(final) == b"candidate"
    root.finalize()


def test_same_blob_independent_profile_keeps_rights_but_cannot_release_child_profile(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    root, binding = _root(tmp_path)
    prior = root.store.put_bytes(
        b"candidate",
        PutOptions(kind="tests.child.value", media_type="application/octet-stream"),
        return_selected_profile=True,
    )
    custody = ChildComputationCustody(
        root, staging_root=tmp_path / "private", closure_resolver=_TypedResolver()
    )
    parent = custody.parent_store(binding, input_refs=(prior,))
    final = _value(parent)
    assert final.artifact_id == prior.artifact_id
    assert final.manifest_profile_sha256 != prior.manifest_profile_sha256
    original_publish = FileSystemCAS._publish_child_release_profiles

    def cancel_after_copy(
        self: FileSystemCAS,
        source: FileSystemCAS,
        refs: tuple[ArtifactRef, ...],
        ledger: object,
        *,
        token: object,
    ) -> object:
        result = original_publish(self, source, refs, ledger, token=token)
        custody.revoke_parent(reason="cancelled_after_copy")
        return result

    monkeypatch.setattr(FileSystemCAS, "_publish_child_release_profiles", cancel_after_copy)
    with pytest.raises(ChildReleaseUnavailableError):
        custody.release_parent((), final)
    fresh = FileSystemCAS(root.store.root, ownership_enforced=False)
    assert fresh.get_bytes(prior) == b"candidate"
    assert fresh.get_bytes(prior.artifact_id) == b"candidate"
    with pytest.raises(ChildReleaseUnavailableError):
        fresh.get_bytes(final)
    root.finalize()


def test_late_parent_writer_and_forged_scope_metadata_cannot_grant_release(tmp_path: Path) -> None:
    root, binding = _root(tmp_path)
    custody = ChildComputationCustody(
        root, staging_root=tmp_path / "private", closure_resolver=_TypedResolver()
    )
    parent = custody.parent_store(binding, input_refs=())
    first = _value(parent)
    info = parent.get_manifest(first).child_release
    with pytest.raises(
        ChildReleaseUnavailableError, match="caller_child_release_metadata_forbidden"
    ):
        parent.put_bytes(
            b"forged",
            PutOptions(kind="unrelated", media_type="application/octet-stream", child_release=info),
        )
    custody.revoke_parent(reason="parent_failed_before_child")
    with pytest.raises(ChildReleaseUnavailableError):
        _value(parent, b"late")
    with pytest.raises(AttributeError):
        parent.export_subgraph([first], tmp_path / "escape.tar")
    root.finalize()


def test_release_gate_removal_oracle_is_semantic(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Deliberately remove the generic gate while keeping all metadata markers.

    This oracle passes only when it observes the intended leak under removal. The
    defining pending-denial assertions above must fail under the same mutation.
    """
    root, binding = _root(tmp_path)
    custody = ChildComputationCustody(
        root, staging_root=tmp_path / "private", closure_resolver=_TypedResolver()
    )
    parent = custody.parent_store(binding, input_refs=())
    final = _value(parent)
    original_publish = FileSystemCAS._publish_child_release_profiles
    leaked: list[bytes] = []

    def removal(
        self: FileSystemCAS,
        source: FileSystemCAS,
        refs: tuple[ArtifactRef, ...],
        ledger: object,
        *,
        token: object,
    ) -> object:
        result = original_publish(self, source, refs, ledger, token=token)
        reader = FileSystemCAS(self.root, ownership_enforced=False)
        with monkeypatch.context() as probe:
            probe.setattr(FileSystemCAS, "_require_enrolled_child_release", lambda *args: None)
            probe.setattr(FileSystemCAS, "_require_child_manifest_release", lambda *args: None)
            probe.setattr(FileSystemCAS, "_require_child_read_result", lambda *args, **kwargs: None)
            leaked.append(reader.get_bytes(final))
        custody.revoke_parent(reason="removal_control_only")
        return result

    monkeypatch.setattr(FileSystemCAS, "_publish_child_release_profiles", removal)
    with pytest.raises(ChildReleaseUnavailableError):
        custody.release_parent((), final)
    assert leaked == [b"candidate"]
    with pytest.raises(ChildReleaseUnavailableError):
        FileSystemCAS(root.store.root, ownership_enforced=False).get_bytes(final)
    root.finalize()


def test_fence_exit_failure_after_durable_head_keeps_explicit_unknown_receipt(
    tmp_path: Path,
) -> None:
    from contextlib import contextmanager

    root, binding = _root(tmp_path)

    class FailingAcknowledgementFence:
        root_run_id = "root"
        control_job_id = None
        tenant_id = None
        cell_id = None

        def check_active(self) -> None:
            pass

        @contextmanager
        def publication(self) -> Iterator[None]:
            yield
            raise OSError("DB fence exit acknowledgement lost")

    custody = ChildComputationCustody(
        root,
        staging_root=tmp_path / "private",
        closure_resolver=_TypedResolver(),
        publication_fence=FailingAcknowledgementFence(),
    )
    parent = custody.parent_store(binding, input_refs=())
    final = _value(parent)
    with pytest.raises(ChildParentSettlementError) as failed:
        custody.release_parent((), final)
    assert failed.value.reason == "child_release_or_parent_settlement_unknown"
    assert failed.value.receipt.projection_ref == final
    assert failed.value.receipt.root_run_id == binding.root_run_id
    assert failed.value.receipt.parent_attempt_id == binding.parent_attempt_id
    assert failed.value.receipt.parent_basis_json is not None
    assert ArtifactRef.model_validate_json(failed.value.receipt.parent_basis_json) == binding.parent_basis_ref
    assert FileSystemCAS(root.store.root, ownership_enforced=False).get_bytes(final) == b"candidate"
    with pytest.raises(ChildParentSettlementError):
        custody.release_parent((), final)
    root.finalize()


def test_parent_events_and_provenance_remain_private_until_selected_release(tmp_path: Path) -> None:
    root, binding = _root(tmp_path)
    custody = ChildComputationCustody(
        root, staging_root=tmp_path / "private", closure_resolver=_TypedResolver()
    )
    parent = custody.parent_store(binding, input_refs=())
    final = _value(parent)
    trace = root._trace_path
    assert trace is not None
    before = trace.read_bytes()
    custody.stage_parent_run_update({"execution_profile": "tests.actual.selected-profile"})
    custody.stage_parent_event("tests", "SELECTED_PARENT_RESULT", outputs=(final,))
    assert trace.read_bytes() == before
    assert root.run_manifest.execution_profile is None
    receipt = custody.release_parent((), final)
    assert root.run_manifest.execution_profile == "tests.actual.selected-profile"
    assert b"SELECTED_PARENT_RESULT" in trace.read_bytes()
    record = json.loads(root.store.get_bytes(receipt.release_ref))
    assert record["parent_effects"]["events"][0]["event"] == "SELECTED_PARENT_RESULT"
    root.finalize()


def test_tagged_default_manifest_cannot_verify_before_release(tmp_path: Path) -> None:
    """A bare ID must resolve the actual default view, not bypass its gate."""
    root, binding = _root(tmp_path)
    custody = ChildComputationCustody(
        root, staging_root=tmp_path / "private", closure_resolver=_TypedResolver()
    )
    parent = custody.parent_store(binding, input_refs=())
    ref = parent.put_json(
        {"candidate": "private"},
        PutOptions(kind="tests.child.json", media_type="application/json"),
    )
    staged = custody._stage
    staged_blob, _ = staged._paths(ref.artifact_id)
    staged_view = staged._manifest_path_for_ref(ref.artifact_id, ref.manifest_profile_sha256)
    public_blob, public_default = root.store._paths(ref.artifact_id)
    public_blob.parent.mkdir(parents=True, exist_ok=True)
    public_blob.write_bytes(staged_blob.read_bytes())
    public_default.write_bytes(staged_view.read_bytes())
    reader = FileSystemCAS(root.store.root, ownership_enforced=False)
    with pytest.raises(ChildReleaseUnavailableError, match="not_released"):
        reader.verify(ref.artifact_id)
    root.finalize()


@pytest.mark.parametrize("error_kind", ["lost_ack", "durability"])
def test_head_write_error_preserves_visible_identity_and_unknown_durability(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, error_kind: str
) -> None:
    from polisyos.core.artifacts import _atomic_write
    from polisyos.core.artifacts._atomic_write import AtomicFileWriter

    root, binding = _root(tmp_path)
    custody = ChildComputationCustody(
        root, staging_root=tmp_path / "private", closure_resolver=_TypedResolver()
    )
    parent = custody.parent_store(binding, input_refs=())
    final = _value(parent)
    original = AtomicFileWriter.write_atomic
    head_path = custody._ledger.path

    def lose_ack(path: Path, data: bytes, *, durable_parent: bool = False) -> None:
        original(path, data, durable_parent=durable_parent)
        if path == head_path:
            raise OSError("acknowledgement lost")

    if error_kind == "lost_ack":
        monkeypatch.setattr(AtomicFileWriter, "write_atomic", staticmethod(lose_ack))
    else:
        fsync = _atomic_write.fsync_directory

        def fail_head_directory(path: Path) -> None:
            if path == head_path.parent:
                raise OSError("directory fsync failed after head replacement")
            fsync(path)

        monkeypatch.setattr(_atomic_write, "fsync_directory", fail_head_directory)
    with pytest.raises(ChildParentSettlementError) as failed:
        custody.release_parent((), final)
    assert failed.value.receipt.release_outcome == "release_visible_durability_unknown"
    assert custody._ledger.head().release_ref == failed.value.receipt.release_ref
    assert custody._ledger.head().status == "released"
    assert not custody._effects_settled
    root.finalize()


def test_input_admission_streams_and_verifies_selected_content(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    root, binding = _root(tmp_path)
    admitted = root.store.put_bytes(
        b"x" * (4 * 1024 * 1024),
        PutOptions(kind="tests.input", media_type="application/octet-stream"),
        return_selected_profile=True,
    )
    original = FileSystemCAS.get_bytes

    def deny_bulk(self: FileSystemCAS, ref: object) -> bytes:
        if isinstance(ref, ArtifactRef) and ref.artifact_id == admitted.artifact_id:
            raise AssertionError("input admission must not materialize the blob")
        return original(self, ref)

    monkeypatch.setattr(FileSystemCAS, "get_bytes", deny_bulk)
    custody = ChildComputationCustody(
        root, staging_root=tmp_path / "private", closure_resolver=_TypedResolver()
    )
    custody.parent_store(binding, input_refs=(admitted,))
    root.finalize()


def test_input_admission_rejects_streamed_corrupt_blob(tmp_path: Path) -> None:
    from polisyos.core.artifacts.store import ArtifactIntegrityError

    root, binding = _root(tmp_path)
    admitted = root.store.put_bytes(
        b"authorized-input",
        PutOptions(kind="tests.input", media_type="application/octet-stream"),
        return_selected_profile=True,
    )
    root.store._paths(admitted.artifact_id)[0].write_bytes(b"corrupted-input!")
    custody = ChildComputationCustody(
        root, staging_root=tmp_path / "private", closure_resolver=_TypedResolver()
    )
    with pytest.raises(ArtifactIntegrityError):
        custody.parent_store(binding, input_refs=(admitted,))
    root.finalize()


def test_reader_refuses_visible_release_when_directory_durability_is_unavailable(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from polisyos.core.artifacts import _atomic_write

    root, binding = _root(tmp_path)
    custody = ChildComputationCustody(
        root, staging_root=tmp_path / "private", closure_resolver=_TypedResolver()
    )
    parent = custody.parent_store(binding, input_refs=())
    final = _value(parent)
    custody.release_parent((), final)
    actual_fsync = _atomic_write.fsync_directory
    head_parent = custody._ledger.path.parent

    def fail_head_directory(path: Path) -> None:
        if path == head_parent:
            raise OSError("head durability unavailable")
        actual_fsync(path)

    monkeypatch.setattr(_atomic_write, "fsync_directory", fail_head_directory)
    reader = FileSystemCAS(root.store.root, ownership_enforced=False)
    with pytest.raises(ChildReleaseUnavailableError, match="release_durability_unavailable"):
        reader.get_bytes(final)
    root.finalize()


def test_prior_selected_input_grant_is_distinct_from_staged_candidate(tmp_path: Path) -> None:
    root, binding = _root(tmp_path)
    prior = root.store.put_bytes(
        b"prior", PutOptions(kind="tests.input", media_type="text/plain"),
        return_selected_profile=True,
    )
    custody = ChildComputationCustody(
        root, staging_root=tmp_path / "private", closure_resolver=_TypedResolver()
    )
    parent = custody.parent_store(binding, input_refs=(prior,))
    candidate = _value(parent, b"new staged candidate")
    assert parent.is_previously_authorized(prior)
    assert not parent.is_previously_authorized(candidate)
    wrong = prior.model_copy(update={"manifest_profile_sha256": "sha256:" + "0" * 64})
    with pytest.raises(ChildReleaseUnavailableError):
        parent.is_previously_authorized(wrong)
    root.finalize()


def test_job_release_reader_refuses_missing_owner_and_missing_locator(tmp_path: Path) -> None:
    from polisyos.core.artifacts.child_release import (
        ChildJobReleaseLocator,
        _record_from_head,
        _verify_job_authorization,
        child_binding_digest,
    )

    root, binding = _root(tmp_path)
    custody = ChildComputationCustody(
        root, staging_root=tmp_path / "private", closure_resolver=_TypedResolver()
    )
    parent = custody.parent_store(binding, input_refs=())
    final = _value(parent)
    custody.release_parent((), final)
    head = custody._ledger.head()
    record = _record_from_head(root.store.root, head)
    altered_infos = []
    altered_payloads = {}
    for info in record.scope_bindings:
        payload = dict(record.binding_payloads[info.scope_id])
        payload["control_job_id"] = "job-with-lease"
        altered_payloads[info.scope_id] = payload
        altered_infos.append(info.model_copy(update={"binding_sha256": child_binding_digest(payload)}))
    job_record = record.model_copy(update={
        "tenant_id": "tenant", "cell_id": "cell",
        "scope_bindings": tuple(altered_infos), "binding_payloads": altered_payloads,
    })
    with pytest.raises(ChildReleaseUnavailableError, match="job_release_authority_bridge_unavailable"):
        _verify_job_authorization(head, job_record)
    located = head.model_copy(update={"job_authorization": ChildJobReleaseLocator(job_id="job-with-lease", event_id=1)})
    with pytest.raises(ChildReleaseUnavailableError, match="job_release_authority_bridge_unavailable"):
        _verify_job_authorization(located, job_record)
    root.finalize()


def test_job_owner_snapshot_rejects_oversized_and_large_collections() -> None:
    from polisyos.core.run.child_custody import _bounded_snapshot, _preflight_raw_shape

    assert _bounded_snapshot({"value": "small"}) == b'{"value":"small"}'
    with pytest.raises(ChildReleaseUnavailableError, match="job_owner_snapshot_limit"):
        _bounded_snapshot({"value": "x" * (256 * 1024 + 1)})
    with pytest.raises(ChildReleaseUnavailableError, match="job_owner_snapshot_limit"):
        _bounded_snapshot([0] * 4097)
    with pytest.raises(ChildReleaseUnavailableError, match="job_owner_snapshot_limit"):
        _preflight_raw_shape([{"retained": "x" * (256 * 1024 + 1)}])


def test_mutated_handoff_ref_cannot_enroll_unselected_sibling(tmp_path: Path) -> None:
    root, binding = _root(tmp_path)
    custody = ChildComputationCustody(
        root, staging_root=tmp_path / "private", closure_resolver=_TypedResolver()
    )
    scope = custody.open_scope(
        binding.model_copy(update={"child_invocation_id": "child-1"}), input_refs=()
    )
    selected = _value(scope.store, b"selected")
    sibling = _value(scope.store, b"unselected")
    assert selected.artifact_id in scope.store.iter_artifact_ids()
    scope.run.add_output(selected)
    scope.run.finalize()
    handoff = custody.admit_handoff(scope, selected)
    exposed = handoff.selected_refs[0]
    exposed.artifact_id = sibling.artifact_id
    exposed.kind = sibling.kind
    exposed.media_type = sibling.media_type
    exposed.manifest_profile_sha256 = sibling.manifest_profile_sha256
    parent = custody.parent_store(binding, input_refs=())
    assert parent.get_bytes(selected) == b"selected"
    with pytest.raises(ChildReleaseUnavailableError, match="private_exact_read_basis_denied"):
        parent.get_bytes(sibling)
    root.finalize()


def test_guarded_read_capability_is_exact_session_ref_and_lifetime(tmp_path: Path) -> None:
    from polisyos.core.run.child_custody import ChildOneRefReadCapability

    root, binding = _root(tmp_path)
    custody = ChildComputationCustody(
        root, staging_root=tmp_path / "private", closure_resolver=_TypedResolver()
    )
    parent = custody.parent_store(binding, input_refs=())
    selected = _value(parent)
    capability = parent._issue_guarded_read(selected)
    source, selected_from_owner = ChildOneRefReadCapability._claim_for_runtime(capability, custody)
    assert source is custody._stage
    assert selected_from_owner == selected
    selected_from_owner.kind = "forged"
    assert ChildOneRefReadCapability._claim_for_runtime(capability, custody)[1] == selected
    other = ChildComputationCustody(
        root, staging_root=tmp_path / "other-private", closure_resolver=_TypedResolver()
    )
    with pytest.raises(ChildReleaseUnavailableError, match="guarded_read_session_or_thread_mismatch"):
        ChildOneRefReadCapability._claim_for_runtime(capability, other)
    parent._release_guarded_read(capability)
    with pytest.raises(ChildReleaseUnavailableError, match="guarded_read_capability_not_current"):
        ChildOneRefReadCapability._claim_for_runtime(capability, custody)
    root.finalize()


def test_unregistered_reader_cannot_claim_guarded_canonical_dispatch(tmp_path: Path) -> None:
    from polisyos.core.artifacts.canonical_profile import (
        CoreJsonReadLimits,
        read_core_json_artifact_bounded,
    )

    store = FileSystemCAS(tmp_path / "cas")
    ref = store.put_json(
        {"value": "real"},
        PutOptions(kind="tests.json", media_type="application/json"),
        return_selected_profile=True,
    )

    class Pretender:
        def __getattr__(self, name: str) -> object:
            return getattr(store, name)

        def _guarded_json_read(self, *args: object, **kwargs: object) -> object:
            raise AssertionError("unappointed method must never be selected")

    result = read_core_json_artifact_bounded(
        Pretender(), ref,
        limits=CoreJsonReadLimits(max_bytes=1024, max_depth=8, max_elements=32, max_manifest_bytes=65536),
    )
    assert result.value == {"value": "real"}


def test_guarded_dispatch_registration_requires_exact_object_identity(tmp_path: Path) -> None:
    from polisyos.core.artifacts.canonical_profile import (
        _GUARDED_CANONICAL_BOOTSTRAP_TOKEN,
        _guarded_canonical_reader,
        _register_guarded_canonical_reader,
    )

    root, binding = _root(tmp_path)
    custody = ChildComputationCustody(
        root, staging_root=tmp_path / "private", closure_resolver=_TypedResolver()
    )
    managed = custody.parent_store(binding, input_refs=())
    _register_guarded_canonical_reader(managed, token=_GUARDED_CANONICAL_BOOTSTRAP_TOKEN)

    class EqualLookingReader:
        def __eq__(self, other: object) -> bool:
            return True

        def __hash__(self) -> int:
            return hash(managed)

    assert _guarded_canonical_reader(managed) is managed
    assert _guarded_canonical_reader(EqualLookingReader()) is None
    root.finalize()


def test_guarded_write_capability_detaches_nested_options_and_json_payload(tmp_path: Path) -> None:
    from polisyos.core.run.child_custody import ChildStageWriteCapability

    root, binding = _root(tmp_path)
    custody = ChildComputationCustody(
        root, staging_root=tmp_path / "private", closure_resolver=_TypedResolver()
    )
    parent = custody.parent_store(binding, input_refs=())
    payload = {"value": "original"}
    options = parent._options(
        PutOptions(kind="tests.child.json", media_type="application/json", schema=SchemaInfo(name="original", version="1"))
    )
    capability = parent._issue_guarded_write("json", payload, options, None)
    payload["value"] = "changed"
    first = ChildStageWriteCapability._claim_for_runtime(capability, custody)
    assert first[0] is custody._stage and first[1] == "json"
    assert first[2] == {"value": "original"}
    assert first[3].schema is not None
    first[3].schema.name = "changed"
    again = ChildStageWriteCapability._claim_for_runtime(capability, custody)
    assert again[3].schema is not None and again[3].schema.name == "original"
    parent._release_guarded_write(capability)
    with pytest.raises(ChildReleaseUnavailableError, match="guarded_write_capability_not_current"):
        ChildStageWriteCapability._claim_for_runtime(capability, custody)
    root.finalize()


def test_guarded_transfer_capability_detaches_selected_refs(tmp_path: Path) -> None:
    from polisyos.core.run.child_custody import ChildSelectedTransferCapability

    root, binding = _root(tmp_path)
    custody = ChildComputationCustody(
        root, staging_root=tmp_path / "private", closure_resolver=_TypedResolver()
    )
    parent = custody.parent_store(binding, input_refs=())
    selected = _value(parent)
    expected = selected.model_copy(deep=True)
    with custody._lock:
        custody._state = "preparing"
        capability = ChildSelectedTransferCapability(custody, (selected,))
        custody._transfer_capability = capability
    selected.kind = "changed"
    source, served, refs, ledger = ChildSelectedTransferCapability._claim_for_runtime(capability, custody)
    assert source is custody._stage and served is custody._served and ledger is custody._ledger
    assert refs == (expected,)
    with custody._lock:
        custody._transfer_capability = None
    with pytest.raises(ChildReleaseUnavailableError, match="guarded_transfer_capability_not_current"):
        ChildSelectedTransferCapability._claim_for_runtime(capability, custody)
    root.finalize()


def test_local_intent_persists_exact_basis_before_work_and_refuses_duplicate(tmp_path: Path) -> None:
    from polisyos.core.artifacts.child_release import find_child_local_intent

    root, binding = _root(tmp_path)
    custody = ChildComputationCustody(
        root, staging_root=tmp_path / "private", closure_resolver=_TypedResolver()
    )
    custody.parent_store(binding, input_refs=())
    locator = find_child_local_intent(
        root.store.root, root_run_id=binding.root_run_id,
        parent_attempt_id=binding.parent_attempt_id, parent_basis_ref=binding.parent_basis_ref,
    )
    assert locator.release_id == custody._release_id
    other = ChildComputationCustody(
        root, staging_root=tmp_path / "other", closure_resolver=_TypedResolver()
    )
    with pytest.raises(ChildReleaseUnavailableError, match="local_intent_already_bound"):
        other.parent_store(binding, input_refs=())
    root.finalize()


def test_local_intent_lost_ack_retains_exact_recovery_locator(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from polisyos.core.artifacts._atomic_write import AtomicFileWriter
    from polisyos.core.artifacts.child_release import find_child_local_intent
    from polisyos.core.run.child_custody import ChildLocalIntentUnknown

    root, binding = _root(tmp_path)
    custody = ChildComputationCustody(
        root, staging_root=tmp_path / "private", closure_resolver=_TypedResolver()
    )
    original = AtomicFileWriter.write_once

    def lose_intent_ack(path: Path, data: bytes, *, durable_parent: bool = False) -> bool:
        result = original(path, data, durable_parent=durable_parent)
        if path.parent.name == "local_intents":
            raise OSError("local intent acknowledgement lost")
        return result

    monkeypatch.setattr(AtomicFileWriter, "write_once", staticmethod(lose_intent_ack))
    with pytest.raises(ChildLocalIntentUnknown) as failed:
        custody.parent_store(binding, input_refs=())
    assert failed.value.recovery is not None
    observed = find_child_local_intent(
        root.store.root, root_run_id=binding.root_run_id,
        parent_attempt_id=binding.parent_attempt_id, parent_basis_ref=binding.parent_basis_ref,
    )
    assert observed.release_id == failed.value.recovery.release_id == custody._release_id
    root.finalize()


def test_local_recovery_reconciles_head_but_never_claims_quiescence(tmp_path: Path) -> None:
    from polisyos.core.artifacts.child_release import reconcile_child_local_intent

    root, binding = _root(tmp_path)
    custody = ChildComputationCustody(
        root, staging_root=tmp_path / "private", closure_resolver=_TypedResolver()
    )
    parent = custody.parent_store(binding, input_refs=())
    pending = reconcile_child_local_intent(
        root.store.root, root_run_id=binding.root_run_id,
        parent_attempt_id=binding.parent_attempt_id, parent_basis_ref=binding.parent_basis_ref,
    )
    assert pending.head_status == "pending"
    assert pending.quiescence == "not_established"
    final = _value(parent)
    receipt = custody.release_parent((), final)
    observed = reconcile_child_local_intent(
        root.store.root, root_run_id=binding.root_run_id,
        parent_attempt_id=binding.parent_attempt_id, parent_basis_ref=binding.parent_basis_ref,
    )
    assert observed.head_status == "released"
    assert observed.release_ref == receipt.release_ref
    assert observed.settlement_status == "settled"
    assert observed.quiescence == "not_established"
    root.finalize()


def test_revocation_failure_preserves_original_unknown_and_recovery(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    root, binding = _root(tmp_path)
    custody = ChildComputationCustody(
        root, staging_root=tmp_path / "private", closure_resolver=_TypedResolver()
    )
    custody.parent_store(binding, input_refs=())
    recovery = custody._recovery_locator()
    assert recovery is not None

    def fail_revoke(reason: str) -> None:
        raise OSError("lost durable revocation acknowledgement")

    monkeypatch.setattr(custody._ledger, "revoke", fail_revoke)
    original = ChildGuardedTransferUnknown(recovery)
    custody._revoke_preserving_outcome(original, reason="transfer_unknown")
    assert original.recovery == recovery
    assert any("revocation" in note for note in original.__notes__)
    with pytest.raises(ChildRevocationUnknown) as failed:
        custody._revoke_preserving_outcome(ValueError("original failure"), reason="failed")
    assert failed.value.recovery == recovery
    assert isinstance(failed.value.__cause__, ValueError)
    root.finalize()
