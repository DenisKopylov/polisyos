from pathlib import Path
import hashlib
import json
import subprocess

ROOT=Path.cwd();CAND='7020abdfcc1bc2f8714a55f148bb0cae0c4c6a67';BASE='cfdb1ac1b7a44a782ec8e13b5f0ed9277beed65c'
OUT=ROOT/'LOCAL/raw/e02-execution-20261027/repairs/C56-phase-r1';assert not OUT.exists();OUT.mkdir(parents=True)
paths=['policy-engine/src/polisyos/scientist/methods/doe/adaptive.py','policy-engine/tests/unit/remediation/test_doe_01.py','policy-engine/src/polisyos/scientist/methods/doe/README.md','policy-engine/release-fragments/unreleased/2026-10-27-doe-adaptive-phase-accounting.toml']
def show(rev,path):return subprocess.check_output(['git','show',f'{rev}:{path}'])
def replace(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
source=show(CAND,paths[0]);tests=show(CAND,paths[1]).decode();readme=show(CAND,paths[2]).decode();release=show(CAND,paths[3]).decode()
tests=replace(tests,'from __future__ import annotations\n\nimport numpy as np','from __future__ import annotations\n\nfrom importlib.metadata import PackageNotFoundError, version\n\nimport numpy as np')
tests=replace(tests,'@pytest.fixture(autouse=True)\ndef _bounded_adaptive_backends','@pytest.fixture\ndef _bounded_adaptive_backends')
marker='''    monkeypatch.setattr(analysis, "analyze_sensitivity", analyze)\n\n\ndef test_grid_extreme'''
insert='''    monkeypatch.setattr(analysis, "analyze_sensitivity", analyze)\n\n\n@pytest.fixture\ndef _real_salib_152() -> None:\n    """Skip only when the actual supported SALib profile is unavailable."""\n    try:\n        actual_version = version("SALib")\n    except PackageNotFoundError:\n        pytest.skip("real adaptive backend requires SALib 1.5.2")\n    if actual_version != "1.5.2":\n        pytest.skip(f"real adaptive backend requires SALib 1.5.2, got {actual_version}")\n\n\ndef test_grid_extreme'''
tests=replace(tests,marker,insert)
tests=replace(tests,'        n_trajectories=n_trajectories,\n        max_estimated_runs=max_estimated_runs,','        n_trajectories=n_trajectories,\n        seed=17,\n        max_estimated_runs=max_estimated_runs,')
for name in ('test_adaptive_sampler_returns_last_completed_round_without_hidden_evaluation','test_adaptive_sampler_stops_before_oversized_follow_up_without_override','test_adaptive_sampler_returns_last_result_when_later_round_fails','test_adaptive_sampler_propagates_first_round_failure'):
 tests=replace(tests,f'def {name}(',f'@pytest.mark.usefixtures("_real_salib_152")\ndef {name}(')
tests=replace(tests,'@pytest.mark.parametrize(\n    "malformed",\n    [np.array(1.0), np.ones((3, 1)), np.ones((2,))],','@pytest.mark.usefixtures("_bounded_adaptive_backends")\n@pytest.mark.parametrize(\n    "malformed",\n    [np.array(1.0), np.ones((3, 1)), np.ones((2,))],')
tests=replace(tests,'def test_adaptive_sampler_propagates_malformed_first_output()','@pytest.mark.usefixtures("_bounded_adaptive_backends")\ndef test_adaptive_sampler_propagates_malformed_first_output()')
tests=replace(tests,'match="generated samples must be a 2-D array|column count"','match=r"generated samples must be a 2-D array|column count"')
added='''\n\n@pytest.mark.usefixtures("_real_salib_152")\ndef test_adaptive_sampler_explicit_override_admits_oversized_follow_up() -> None:\n    """The same cap that blocks a second round permits it only with explicit override."""\n    calls: list[np.ndarray] = []\n\n    def evaluator(samples: np.ndarray) -> np.ndarray:\n        calls.append(samples.copy())\n        return samples[:, 0] + samples[:, 1]\n\n    result = AdaptiveSampler(\n        _adaptive_plan(n_trajectories=1, max_estimated_runs=3, allow_large_run=True),\n        convergence=ConvergenceConfig(\n            max_rounds=2, ranking_stability_threshold=1.01, trajectory_step=1\n        ),\n    ).run(evaluator)\n\n    assert [len(samples) for samples in calls] == [3, 6]\n    assert len(result.rounds) == 2\n    assert result.total_evaluations == 9\n    assert [attempt.evaluator_completed for attempt in result.attempts] == [3, 6]\n    assert result.final_result.total_runs == 6\n    assert result.stop_reason == "max_rounds_reached"\n\n\n@pytest.mark.usefixtures("_real_salib_152")\n@pytest.mark.parametrize("second_output", ["valid", "scalar", "matrix", "short"])\ndef test_adaptive_real_salib_boundary_and_last_result(\n    monkeypatch: pytest.MonkeyPatch, second_output: str\n) -> None:\n    """Real SALib calls retain the last result if the next evaluator output is malformed."""\n    from SALib.analyze import morris as morris_analyzer\n    from SALib.sample import morris as morris_sampler\n\n    from polisyos.scientist.methods.doe import analysis as analysis_module\n\n    original_sample = morris_sampler.sample\n    original_analyze = morris_analyzer.analyze\n    original_doe_analyze = analysis_module.analyze_sensitivity\n    backend_sample_calls = 0\n    backend_analysis_calls = 0\n    analyzed: list[SensitivityResult] = []\n    evaluations: list[np.ndarray] = []\n\n    def record_sample(*args, **kwargs):\n        nonlocal backend_sample_calls\n        backend_sample_calls += 1\n        return original_sample(*args, **kwargs)\n\n    def record_analyze(*args, **kwargs):\n        nonlocal backend_analysis_calls\n        backend_analysis_calls += 1\n        return original_analyze(*args, **kwargs)\n\n    def record_doe_analysis(plan: SensitivityPlan, samples: np.ndarray, outputs: np.ndarray):\n        result = original_doe_analyze(plan, samples, outputs)\n        analyzed.append(result)\n        return result\n\n    monkeypatch.setattr(morris_sampler, "sample", record_sample)\n    monkeypatch.setattr(morris_analyzer, "analyze", record_analyze)\n    monkeypatch.setattr(analysis_module, "analyze_sensitivity", record_doe_analysis)\n\n    def evaluator(samples: np.ndarray) -> np.ndarray:\n        evaluations.append(samples.copy())\n        if len(evaluations) == 2:\n            if second_output == "scalar":\n                return np.array(1.0)\n            if second_output == "matrix":\n                return np.ones((len(samples), 1))\n            if second_output == "short":\n                return np.ones(len(samples) - 1)\n        return samples[:, 0] + 2.0 * samples[:, 1]\n\n    result = AdaptiveSampler(\n        _adaptive_plan(n_trajectories=2, max_estimated_runs=100, allow_large_run=True),\n        convergence=ConvergenceConfig(\n            max_rounds=2, ranking_stability_threshold=1.01, trajectory_step=1\n        ),\n    ).run(evaluator)\n\n    assert [len(samples) for samples in evaluations] == [6, 9]\n    assert backend_sample_calls == 2\n    if second_output == "valid":\n        assert backend_analysis_calls == 2\n        assert len(result.rounds) == 2\n        assert result.final_result is analyzed[-1]\n        assert result.total_evaluations == 15\n        assert [attempt.phase for attempt in result.attempts] == ["completed", "completed"]\n        assert result.stop_reason == "max_rounds_reached"\n    else:\n        assert backend_analysis_calls == 1\n        assert len(result.rounds) == 1\n        assert result.final_result is analyzed[0]\n        assert result.total_evaluations == 6\n        assert result.attempts[-1].phase == "evaluation"\n        assert result.attempts[-1].evaluator_completed is None\n        assert result.stop_reason == "adaptive_evaluation_failed:ValueError"\n    # For y = x1 + 2*x2 on [0,1]^2, normalized Morris effects are 1 and 2.\n    assert result.final_result.mu_star["x1"] == pytest.approx(1.0)\n    assert result.final_result.mu_star["x2"] == pytest.approx(2.0)\n'''
tests+=added
old='''These in-memory attempt records are operational observations, not USD charges,\ndurable provenance, independent replicas, or evidence that the design is\nscientifically sufficient. Monetary settlement requires an admitted typed\nbridge to the orchestration budget owner; none is inferred from row counts.\n'''
new=old+'''\nFocused coordinator-fault tests may explicitly inject synthetic collaborators.\nA real-backend check separately runs the locked SALib sampler and analyzer; an\nunavailable backend is a missing verification profile, not a simulated pass.\n'''
readme=replace(readme,old,new)
old='limitations = "No USD conversion, durable attempt artifact, replica/cache binding, G acceptance, or formal finding closure is claimed."'
new='limitations = "The C56 author runtime used synthetic coordinator collaborators and skipped unavailable SALib modules; real-backend and composed checks require separate evidence. No USD conversion, durable attempt artifact, replica/cache binding, G acceptance, or formal finding closure is claimed."'
release=replace(release,old,new)
# Ruff formatting is static, operates only on supplied stdin, and does not execute tests or touch product files.
product=ROOT/'policy-engine';ruff=product/'.venv/bin/python'
results={}
def format_and_check(data:bytes, logical:str)->bytes:
 cmd=[str(ruff),'-m','ruff','format','--no-cache','--stdin-filename',logical,'-']
 r=subprocess.run(cmd,input=data,cwd=product,capture_output=True,check=True);formatted=r.stdout
 for sub in (['check','--no-cache','--output-format','json'],['format','--check','--diff','--no-cache']):
  c=[str(ruff),'-m','ruff',*sub,'--stdin-filename',logical,'-'];v=subprocess.run(c,input=formatted,cwd=product,capture_output=True)
  results[f'{logical}: {" ".join(sub)}']={'exit':v.returncode,'stdout':v.stdout.decode(),'stderr':v.stderr.decode()}
  if v.returncode: raise RuntimeError((c,v.stdout.decode(),v.stderr.decode()))
 return formatted
formatted_source=format_and_check(source,'src/polisyos/scientist/methods/doe/adaptive.py')
formatted_tests=format_and_check(tests.encode(),'tests/unit/remediation/test_doe_01.py')
outputs=[formatted_source,formatted_tests,readme.encode(),release.encode()]
for path,data in zip(paths,outputs,strict=True):
 out=OUT/('postimages/'+path);out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data);assert out.read_bytes()==data
(OUT/'static-checks.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
files=[]
for path,data in zip(paths,outputs,strict=True):
 candidate=show(CAND,path)
 try: base=show(BASE,path);base_sha=hashlib.sha256(base).hexdigest()
 except subprocess.CalledProcessError: base_sha=None
 files.append({'path':path,'candidate_sha256':hashlib.sha256(candidate).hexdigest(),'proposed_sha256':hashlib.sha256(data).hexdigest(),'proposed_bytes':len(data),'current_base_sha256':base_sha,'scratch_postimage':str((OUT/('postimages/'+path)).relative_to(ROOT))})
manifest={'candidate_tree':CAND,'observed_native_base':BASE,'scope':'sparse proposal only; no canonical writes, no tests executed','files':files,'static_ruff_checks':results,'limitations':['No pytest or removal control has been executed.','Real SALib backend results must be recorded independently at composed source/profile.','B97 real Search/report consumer and C05 monetary cost bridge remain unproved.','Candidate C56 author outputs are historical bounded coordinator-only results.'],'closure_ids':[]}
(OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'directory':str(OUT),'files':files,'ruff':{k:v['exit'] for k,v in results.items()}},ensure_ascii=False))
