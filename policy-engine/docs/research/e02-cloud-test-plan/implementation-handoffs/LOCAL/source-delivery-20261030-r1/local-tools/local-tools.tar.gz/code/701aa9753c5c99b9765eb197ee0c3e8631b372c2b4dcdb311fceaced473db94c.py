from pathlib import Path
p=Path('LOCAL/raw/e02-execution-20261027/repairs/TC-closure-owner-r4/proposal/policy-engine/src/polisyos/runtime/quality/owned_execution_identity.py')
s=p.read_text()
a='''        from polisyos.core.artifacts import SchemaInfo
        from polisyos.ir.kernel import (
'''
b='''        from polisyos.core.artifacts import SchemaInfo, input_ref_from_artifact_ref
        from polisyos.core.artifacts.registry import RegistryBundlePayload
        from polisyos.core.contracts.decision_validity import (
            RegisteredSQLAdmissionBinding,
            RegisteredSQLUseContract,
        )
        from polisyos.core.contracts.execution_plan import ExecutionPlan, ExecutionPlanRef
        from polisyos.core.contracts.fabric import (
            DataSnapshotOwnerBound,
            WarningsBundle,
            data_snapshot_manifest_inputs_match,
        )
        from polisyos.core.contracts.foundry import (
            ExecPlan,
            FoundryExecutionInputBasis,
            FoundryInputBindings,
            LoweredIR,
        )
        from polisyos.foundry.compile.trinity_compiler import _program_graph_inputs
        from polisyos.ir.kernel import (
'''
assert s.count(a)==1;s=s.replace(a,b,1)
a='''            UnitsRegistry,
        )

        # The restricted profile'''
b='''            UnitsRegistry,
        )
        from polisyos.ir.linker.reports import LinkReport
        from polisyos.ir.trinity import TrinityBundle
        from polisyos.scientist.adapters.registered_sql_admission import (
            _capture_edges,
            _RegisteredSQLCapture,
            RegisteredSQLViewContract,
        )
        from polisyos.scientist.policy_design.schema import PolicyCandidateSchema

        snapshot_manifest, snapshot, _, _ = reader.read_typed_model(
            DataSnapshotOwnerBound, basis.data_snapshot_ref
        )
        _, bindings, _, _ = reader.read_typed_model(FoundryInputBindings, basis.input_bindings_ref)
        _, sql_binding, _, _ = reader.read_typed_model(
            RegisteredSQLAdmissionBinding, basis.registered_sql_admission_ref
        )
        if not data_snapshot_manifest_inputs_match(
            snapshot, snapshot_manifest.inputs,
            schema_version=(
                None if snapshot_manifest.artifact_schema is None
                else snapshot_manifest.artifact_schema.version
            ),
        ):
            _fail("debug_snapshot_owner_edges_mismatch")

        # The restricted profile'''
assert s.count(a)==1;s=s.replace(a,b,1)
a='''        members: list[ClosureCasIdentity | ClosureOwnerValueIdentity] = []
        observed_edges: list[InputRef] = []
        json_verified = set(budget.payload_refs)
'''
b='''        # Each supported kind maps to its actual installed typed owner and
        # exact accepted schema. Kinds outside this bounded SQL execution
        # profile refuse instead of being admitted as generic JSON.
        typed_contracts = {
            "foundry.execution_input_basis": (
                FoundryExecutionInputBasis, "polisyos.core.FoundryExecutionInputBasis", {"1.1"}
            ),
            "foundry.exec_plan": (ExecPlan, "polisyos.core.ExecPlan", {"0.2.0"}),
            "foundry.program_graph": (ProgramGraph, "polisyos.core.ProgramGraph", {"0.2.0"}),
            "ir.trinity_bundle": (TrinityBundle, "polisyos.ir.TrinityBundle", {"1.0"}),
            "scientist.policy_design.candidate": (
                PolicyCandidateSchema, PolicyCandidateSchema.ARTIFACT_SCHEMA_NAME,
                {PolicyCandidateSchema.ARTIFACT_SCHEMA_VERSION},
            ),
            "fabric.data_snapshot": (DataSnapshotOwnerBound, "polisyos.core.DataSnapshot", {"0.3.0"}),
            "foundry.input_bindings": (FoundryInputBindings, "polisyos.core.FoundryInputBindings", {"1.1"}),
            "foundry.state_snapshot": (StateSnapshot, "polisyos.core.StateSnapshot", {"2.2.0"}),
            "foundry.lowered_ir": (LoweredIR, "polisyos.foundry.LoweredIR", {"0.2.0"}),
            "scientist.execution_plan": (ExecutionPlan, "polisyos.core.ExecutionPlan", {"1.0"}),
            "compiler.link_report": (LinkReport, "polisyos.ir.LinkReport", {"1.0"}),
            "fabric.registered_sql_admission_binding": (
                RegisteredSQLAdmissionBinding, RegisteredSQLAdmissionBinding.ARTIFACT_SCHEMA_NAME,
                {RegisteredSQLAdmissionBinding.ARTIFACT_SCHEMA_VERSION},
            ),
            "fabric.registered_sql_view": (
                RegisteredSQLViewContract, RegisteredSQLViewContract.ARTIFACT_SCHEMA_NAME,
                {RegisteredSQLViewContract.ARTIFACT_SCHEMA_VERSION},
            ),
            "fabric.registered_sql_use": (
                RegisteredSQLUseContract, RegisteredSQLUseContract.ARTIFACT_SCHEMA_NAME,
                {RegisteredSQLUseContract.ARTIFACT_SCHEMA_VERSION},
            ),
            "fabric.registered_sql_capture": (
                _RegisteredSQLCapture, _RegisteredSQLCapture.ARTIFACT_SCHEMA_NAME,
                {_RegisteredSQLCapture.ARTIFACT_SCHEMA_VERSION},
            ),
            "fabric.warnings": (WarningsBundle, "polisyos.core.WarningsBundle", {"1.0"}),
        }
        simple_contracts = {
            "ir.data_view_request": "polisyos.ir.DataViewRequest",
            "fabric.tabular_payload": "polisyos.fabric.TabularPayload",
            "fabric.data_schema": "polisyos.fabric.DataSchema",
            "fabric.quality_report": "polisyos.fabric.DataQualityReport",
        }
        typed_validated: set[tuple[str, str, str, str | None]] = set()
        members: list[ClosureCasIdentity | ClosureOwnerValueIdentity] = []
        observed_edges: list[InputRef] = []
        json_verified = set(budget.payload_refs)
'''
assert s.count(a)==1;s=s.replace(a,b,1)
a='''            if selected_ref.media_type == "application/json":
                if key in json_verified:
'''
b='''            if selected_ref.media_type == "application/json":
                typed = typed_contracts.get(selected_ref.kind)
                simple_schema = simple_contracts.get(selected_ref.kind)
                registry_kind = selected_ref.kind == "core.registry_bundle" or any(
                    selected_ref.kind == item[0] for item in registry_models.values()
                )
                if not registry_kind and typed is None and simple_schema is None:
                    _fail("debug_source_kind_not_supported")
                schema = manifest.artifact_schema
                if typed is not None:
                    model, schema_name, versions = typed
                    if schema is None or schema.name != schema_name or schema.version not in versions:
                        _fail("debug_source_schema_mismatch")
                    if key not in typed_validated:
                        checked_manifest, value, _, _ = reader.read_typed_model(model, selected_ref)
                        if checked_manifest != manifest:
                            _fail("debug_source_typed_manifest_mismatch")
                        if selected_ref.kind == "foundry.state_snapshot" and (
                            value.schema_version != "2.2"
                            or StateSnapshot.SCHEMA_MANIFEST_VERSION_BY_PAYLOAD_VERSION.get(
                                value.schema_version
                            ) != schema.version
                        ):
                            _fail("debug_state_snapshot_schema_mismatch")
                        typed_validated.add(key)
                if simple_schema is not None and (
                    schema != SchemaInfo(name=simple_schema, version="1.0")
                ):
                    _fail("debug_source_schema_mismatch")
                if key in json_verified:
'''
assert s.count(a)==1;s=s.replace(a,b,1)
# Precompute actual parent edges using producer-owned builders and typed refs.
a='''        # This is the Foundry source owner's ordered enumeration, not a list
        # supplied by the reporting caller. Resolve every direct selected edge.
'''
b='''        def selected_edges(rows: list[tuple[InputRef, ArtifactRef, ArtifactManifest]]) -> dict[str, ArtifactRef]:
            result: dict[str, ArtifactRef] = {}
            for edge, ref, _ in rows[1:]:
                role = edge.role.rsplit(".", 1)[-1]
                if role in result:
                    _fail("debug_parent_duplicate_edge_role")
                result[role] = ref
            return result

        def validate_parent(
            role: str,
            manifest: ArtifactManifest,
            children: list[tuple[InputRef, ArtifactRef, ArtifactManifest]],
        ) -> None:
            if role.endswith("_registry_bundle") or "_registry_member." in role:
                return
            actual = manifest.inputs
            expected: list[InputRef] | None = None
            if role == "exec_plan":
                expected = [input_ref_from_artifact_ref(basis.program_graph_ref, role="program_graph")]
            elif role == "program_graph":
                # Derive the exact closure and order from the same compiler owner.
                by_role = {
                    edge.role.removeprefix("basis.edge.program_graph."): ref
                    for edge, ref, _ in children[1:]
                }
                if set(by_role) != {
                    "ir", "registry_bundle", "link_report", "lowered_ir", "execution_plan_source"
                }:
                    _fail("debug_program_graph_input_roles_mismatch")
                if (
                    by_role["link_report"].kind != "compiler.link_report"
                    or by_role["execution_plan_source"].kind != "scientist.execution_plan"
                ):
                    _fail("debug_program_graph_input_kind_mismatch")
                expected = _program_graph_inputs(
                    policy_ref=basis.trinity_bundle_ref,
                    registry_bundle_ref=basis.compile_registry_ref,
                    link_report_ref=by_role["link_report"],
                    lowered_ir_ref=graph.lowered_ir_ref,
                    params_refs={},
                    method_execution_plan_ref=ExecutionPlanRef.model_validate(
                        by_role["execution_plan_source"].model_dump(mode="python")
                    ),
                )
            elif role == "trinity_bundle":
                expected = [input_ref_from_artifact_ref(basis.candidate_ref, role="policy_candidate")]
            elif role == "candidate":
                expected = [
                    input_ref_from_artifact_ref(
                        basis.candidate_data_snapshot_ref, role="world_model_data_snapshot"
                    ),
                    input_ref_from_artifact_ref(
                        basis.candidate_registry_bundle_ref, role="world_model_registry"
                    ),
                ]
            elif role in {"candidate_data_snapshot", "actual_data_snapshot"}:
                if manifest != snapshot_manifest:
                    _fail("debug_snapshot_selected_manifest_mismatch")
                return
            elif role == "input_bindings":
                expected = [
                    input_ref_from_artifact_ref(basis.data_snapshot_ref, role="input.data_snapshot_ref"),
                    input_ref_from_artifact_ref(basis.binding_registry_ref, role="input.registry_bundle_ref"),
                    input_ref_from_artifact_ref(basis.bound_state_snapshot_ref, role="artifact.bound_state_snapshot_ref"),
                    input_ref_from_artifact_ref(basis.registered_sql_admission_ref, role="input.registered_sql_admission_ref"),
                ]
                if bindings.quality_report_ref is not None:
                    expected.append(input_ref_from_artifact_ref(
                        bindings.quality_report_ref, role="input.quality_report_ref"
                    ))
            elif role in {"bound_state_snapshot", "base_state_snapshot"}:
                expected = state.lineage_inputs
            elif role == "registered_sql_admission":
                expected = _capture_edges(
                    snapshot, basis.data_snapshot_ref, sql_binding.materialization.registration
                )
                expected.append(input_ref_from_artifact_ref(
                    sql_binding.materialization.producer_capture_ref, role="source.capture"
                ))
            else:
                _fail("debug_source_role_not_supported")
            if expected is None or actual != expected:
                _fail("debug_source_parent_edges_mismatch")

        # This is the Foundry source owner's ordered enumeration, not a list
        # supplied by the reporting caller. Resolve every direct selected edge.
'''
assert s.count(a)==1;s=s.replace(a,b,1)
a='''            for edge, selected_ref, manifest in rows:
                record_selected(edge, selected_ref, manifest)
'''
b='''            validate_parent(source_role, source_manifest, rows)
            for edge, selected_ref, manifest in rows:
                record_selected(edge, selected_ref, manifest)
'''
assert s.count(a)==1;s=s.replace(a,b,1)
# Unused helper omitted: edge roles can themselves contain dots.
start=s.index('        def selected_edges(');end=s.index('        def validate_parent(',start)
s=s[:start]+s[end:]
p.write_text(s)
print('supported source roles and schemas authored')
