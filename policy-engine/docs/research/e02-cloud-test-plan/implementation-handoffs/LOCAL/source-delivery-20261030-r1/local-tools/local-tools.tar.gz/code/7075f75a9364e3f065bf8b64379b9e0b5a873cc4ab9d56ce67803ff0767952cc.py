"""Capture immutable probe output and tracked preimage state for a HOLD investigation."""
from __future__ import annotations
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

root=Path.cwd().resolve()
raw=root/'LOCAL/raw/e02-execution-20261027/repairs/N7-protocol-identity-r1'
sha=lambda data: hashlib.sha256(data).hexdigest()
scripts=("source_route_probe.py","adversarial_probe.py","core_protocol_census_probe.py",
         "warmed_provider_boundary_probe.py","property_removals.py",
         "snapshot_candidate_dependency_probe.py","actual_loader_execution_probe.py",
         "loader_facade_combined_probe.py")
env=dict(os.environ);env["PYTHONDONTWRITEBYTECODE"]="1"
runs={}
for script in scripts:
    started=time.monotonic()
    completed=subprocess.run([sys.executable,"-B",str(raw/script)],cwd=root,env=env,capture_output=True,timeout=60)
    (raw/(script+".stdout")).write_bytes(completed.stdout)
    (raw/(script+".stderr")).write_bytes(completed.stderr)
    runs[script]={"exit":completed.returncode,"seconds":round(time.monotonic()-started,3),
        "script_sha256":sha((raw/script).read_bytes()),"stdout_sha256":sha(completed.stdout),"stderr_sha256":sha(completed.stderr)}
    print(script,completed.returncode)
tracked=("policy-engine/src/polisyos/runtime/quality/confidence_ledger.py",
         "policy-engine/src/polisyos/runtime/quality/README.md",
         "policy-engine/src/polisyos/core/artifacts/protocol.py")
source={}
for p in tracked:
    live=(root/p).read_bytes()
    blob=subprocess.run(["git","show","HEAD:"+p],cwd=root,check=True,capture_output=True).stdout
    source[p]={"live_sha256":sha(live),"git_sha256":sha(blob),"matches_head":live==blob}
result={"state":"HOLD: source-extracted investigation only; prototype not composable",
        "branch":subprocess.run(["git","symbolic-ref","--short","HEAD"],cwd=root,check=True,capture_output=True,text=True).stdout.strip(),
        "head":subprocess.run(["git","rev-parse","HEAD"],cwd=root,check=True,capture_output=True,text=True).stdout.strip(),
        "tree":subprocess.run(["git","rev-parse","HEAD^{tree}"],cwd=root,check=True,capture_output=True,text=True).stdout.strip(),
        "tracked_status_uno":subprocess.run(["git","status","--short","-uno"],cwd=root,check=True,capture_output=True,text=True).stdout,
        "source":source,"pre_sha256":sha((raw/"pre"/tracked[0]).read_bytes()),
        "prototype_sha256":sha((raw/"post"/tracked[0]).read_bytes()),"runs":runs}
p=raw/"diagnostic-freeze.json"
p.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
print("result_sha256",sha(p.read_bytes()))
raise SystemExit(0 if all(row["exit"]==0 for row in runs.values()) and all(row["matches_head"] for row in source.values()) else 1)
