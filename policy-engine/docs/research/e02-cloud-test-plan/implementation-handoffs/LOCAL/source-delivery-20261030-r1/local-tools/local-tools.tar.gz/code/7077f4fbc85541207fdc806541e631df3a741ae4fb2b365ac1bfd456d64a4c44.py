"""Recreate local reselection with a profileless writer-to-handoff reference.

Only run on the matching generic witness. The actual handoff must disagree
with the selected binding, so the test must FAIL while payload bytes remain.
"""

import pytest


@pytest.fixture(autouse=True)
def tc_remove_selected_handoff(monkeypatch):
    from polisyos.core.artifacts import artifact_manifest_profile_sha256
    from polisyos.runtime.quality.cycle_substrate import (
        CycleSubstrateContextArtifactOwner,
    )

    persist = CycleSubstrateContextArtifactOwner.persist_for_current_job
    resolve = CycleSubstrateContextArtifactOwner.resolve_for_current_job

    def profileless_persist(owner, *args, **kwargs):
        ref = persist(owner, *args, **kwargs)
        return ref.model_copy(update={"manifest_profile_sha256": None})

    def local_reselection(owner, ref, *args, **kwargs):
        manifest = owner._store.get_manifest(ref)
        selected = ref.model_copy(
            update={"manifest_profile_sha256": artifact_manifest_profile_sha256(manifest)}
        )
        return resolve(owner, selected, *args, **kwargs)

    monkeypatch.setattr(
        CycleSubstrateContextArtifactOwner,
        "persist_for_current_job",
        profileless_persist,
    )
    monkeypatch.setattr(
        CycleSubstrateContextArtifactOwner, "resolve_for_current_job", local_reselection
    )
