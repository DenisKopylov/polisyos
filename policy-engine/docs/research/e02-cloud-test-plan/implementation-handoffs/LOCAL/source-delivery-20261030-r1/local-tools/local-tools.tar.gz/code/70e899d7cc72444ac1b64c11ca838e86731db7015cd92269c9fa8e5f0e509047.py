"""Source-bound, in-memory C24 property removals for the retained native runner."""

from __future__ import annotations

import hashlib
import inspect
import json
import os
import subprocess
import textwrap
from pathlib import Path

import pytest

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")


def _hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _git(*args: str) -> str:
    return subprocess.check_output(["git", "-C", str(ROOT), *args], text=True).strip()


@pytest.fixture(autouse=True)
def c24_remove_property(monkeypatch: pytest.MonkeyPatch, request: pytest.FixtureRequest):
    import polisyos.berl.persistence as persistence
    import polisyos.berl.service as service
    from polisyos.core.artifacts.store import FileSystemCAS

    expected_head = os.environ["C24_EXPECTED_HEAD"]
    expected_node = os.environ["C24_EXPECTED_NODE"]
    mode = os.environ["C24_CONTROL_MODE"]
    pins = json.loads(os.environ["C24_SOURCE_PINS"])
    assert _git("rev-parse", "HEAD") == expected_head
    assert _git("symbolic-ref", "--short", "HEAD") == "codex/e02-unified-local-20261009"
    assert request.node.nodeid == expected_node
    for relative, expected in pins.items():
        assert _hash(ROOT / relative) == expected, relative
    assert _hash(Path(__file__)) == os.environ["C24_PLUGIN_SHA256"]
    destination = Path(os.environ["C24_CONTROL_OUTPUT"])
    assert not destination.exists()
    destination.mkdir(parents=True)

    old_key = service._effective_request_key
    old_route = service._adapter_for_request
    old_identity = service._effective_method_id
    old_explain = service.ExplanationOrchestrator.explain
    old_persist = persistence.persist_explanation_bundle
    active_source = ""

    if mode == "background":
        def key_without_background(**kwargs):
            original = old_key(**kwargs)
            if original is None:
                return None
            assert original[0] == "berl-effective-request-v3" and len(original) >= 11
            return original[:10] + original[11:]

        active_source = inspect.getsource(key_without_background)
        monkeypatch.setattr(service, "_effective_request_key", key_without_background)
    elif mode == "conditional":
        def route_without_conditional_guard(method_id, feature_dependence_policy, adapters):
            if feature_dependence_policy == "conditional_observational":
                return adapters.get(method_id)
            return old_route(method_id, feature_dependence_policy, adapters)

        active_source = inspect.getsource(route_without_conditional_guard)
        monkeypatch.setattr(service, "_adapter_for_request", route_without_conditional_guard)
    elif mode == "identity":
        def caller_label_identity(adapter):
            if service._is_builtin_adapter(adapter):
                return old_identity(adapter)
            candidate = getattr(adapter, "effective_method_id", None)
            return candidate if isinstance(candidate, str) and candidate else adapter.method_id

        original_source = textwrap.dedent(inspect.getsource(old_explain))
        gate = "            and cache_key is not None\n"
        assert original_source.count(gate) == 1
        changed_source = original_source.replace(gate, "", 1)
        scope: dict[str, object] = {}
        exec(compile(changed_source, inspect.getsourcefile(old_explain) or "<control>", "exec"), service.__dict__, scope)
        active_source = inspect.getsource(caller_label_identity) + "\n" + changed_source
        monkeypatch.setattr(service, "_effective_method_id", caller_label_identity)
        monkeypatch.setattr(service.ExplanationOrchestrator, "explain", scope["explain"])
    elif mode == "surface":
        from types import SimpleNamespace
        import polisyos.berl.contracts.display_policy as display

        old_display_validator = display.validate_persisted_explanation_bundle_payload

        def bypass_display_validation(*args, **kwargs):
            return None, SimpleNamespace(passed=True)

        active_source = inspect.getsource(bypass_display_validation)
        monkeypatch.setattr(display, "validate_persisted_explanation_bundle_payload", bypass_display_validation)
    elif mode == "provenance":
        import polisyos.berl.contracts.validation_rules as rules
        from polisyos.berl.contracts.explanation_bundle import ExplanationBundle

        old_persisted_validator = rules.validate_persisted_explanation_bundle_payload

        def admit_numerical_candidate(payload, *, thresholds=None):
            bundle = ExplanationBundle.model_validate(payload)
            return bundle, rules.validate_explanation_bundle(bundle, thresholds=thresholds)

        active_source = inspect.getsource(admit_numerical_candidate)
        monkeypatch.setattr(rules, "validate_persisted_explanation_bundle_payload", admit_numerical_candidate)
    elif mode in {"persistence-runtime", "persistence-scientist"}:
        def persist_in_wrong_store(store, bundle, *, inputs=None):
            assert isinstance(store, FileSystemCAS)
            wrong_store = FileSystemCAS(store.root.parent / (store.root.name + "-unselected-control"))
            return old_persist(wrong_store, bundle, inputs=inputs)

        active_source = inspect.getsource(persist_in_wrong_store)
        monkeypatch.setattr(persistence, "persist_explanation_bundle", persist_in_wrong_store)
    else:
        raise ValueError(f"unknown C24 property removal {mode}")

    (destination / "active-control.py").write_text(active_source)
    metadata = {
        "mode": mode,
        "head": expected_head,
        "node": expected_node,
        "source_pins": pins,
        "plugin_sha256": _hash(Path(__file__)),
        "active_control_sha256": hashlib.sha256(active_source.encode()).hexdigest(),
        "property_removed_only_in_process": True,
    }
    try:
        yield
    finally:
        monkeypatch.undo()
        metadata["functions_restored"] = (
            service._effective_request_key is old_key
            and service._adapter_for_request is old_route
            and service._effective_method_id is old_identity
            and service.ExplanationOrchestrator.explain is old_explain
            and persistence.persist_explanation_bundle is old_persist
        )
        if mode == "surface":
            metadata["functions_restored"] = (
                metadata["functions_restored"]
                and display.validate_persisted_explanation_bundle_payload is old_display_validator
            )
        if mode == "provenance":
            metadata["functions_restored"] = (
                metadata["functions_restored"]
                and rules.validate_persisted_explanation_bundle_payload is old_persisted_validator
            )
        metadata["source_bytes_restored"] = all(_hash(ROOT / path) == pin for path, pin in pins.items())
        (destination / "control-mutation.json").write_text(json.dumps(metadata, indent=2) + "\n")
