"""Remove the receiver-side cache read for one focused R1 adversarial run."""
from __future__ import annotations

import json
import os
import sys
from typing import Any

_TARGET = (
    "tests/unit/scientist/orchestration/engine/"
    "test_engine_executor_idempotency.py::"
    "test_incomplete_process_run_resumes_same_cache_and_one_terminal_lifecycle"
)


class RemoveCacheReadForR1:
    """Force a miss only in the pytest receiver process, then restore the method."""

    def __init__(self) -> None:
        self._cache_type: type[Any] | None = None
        self._original_get: Any = None
        self._patched = False

    def pytest_runtest_setup(self, item: Any) -> None:
        if item.nodeid != _TARGET:
            return
        from polisyos.scientist.orchestration.engine.idempotency import NodeResultCache

        self._cache_type = NodeResultCache
        self._original_get = NodeResultCache.get

        def forced_miss(
            _cache: Any,
            _key: str,
            *,
            deadline_monotonic: float | None = None,
        ) -> None:
            del deadline_monotonic
            marker_path = os.environ.get("POLISYOS_R1_MUTATION_CALL_LOG")
            if not marker_path:
                raise RuntimeError("r1_mutation_call_log_missing")
            flags = os.O_WRONLY | os.O_CREAT | os.O_APPEND | getattr(os, "O_NOFOLLOW", 0)
            fd = os.open(marker_path, flags, 0o600)
            try:
                payload = json.dumps(
                    {
                        "event": "NodeResultCache.get_forced_miss",
                        "pid": os.getpid(),
                        "key": _key,
                        "returned": None,
                    },
                    sort_keys=True,
                ).encode() + b"\n"
                if os.write(fd, payload) != len(payload):
                    raise OSError("r1_mutation_call_log_short_write")
                os.fsync(fd)
            finally:
                os.close(fd)
            print("R1_CACHE_READ_REMOVAL_ACTIVE", file=sys.stdout, flush=True)
            return None

        NodeResultCache.get = forced_miss
        self._patched = True

    def pytest_runtest_teardown(self, item: Any, nextitem: Any) -> None:
        del nextitem
        if item.nodeid != _TARGET or not self._patched:
            return
        assert self._cache_type is not None
        self._cache_type.get = self._original_get
        self._patched = False
        self._cache_type = None
        self._original_get = None


plugin = RemoveCacheReadForR1()


def pytest_runtest_setup(item: Any) -> None:
    """Install the scoped removal after pytest registers this module."""
    plugin.pytest_runtest_setup(item)


def pytest_runtest_teardown(item: Any, nextitem: Any) -> None:
    """Restore the original cache reader after the scoped test."""
    plugin.pytest_runtest_teardown(item, nextitem)
