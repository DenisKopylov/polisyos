"""Exact AST mutation for the R166 removal probe; standard library only."""
from __future__ import annotations

import ast
import copy
import types

CLASS = "GenerationCycleController"
METHOD = "_plan_n7_requirement_gap_if_requested"
_EXPECTED_TEST = 'basis_binding.resolution.state == "not_established"'
_MARKERS = frozenset(
    {
        "not_established",
        "requirement_basis_not_established",
        "unbound_requirement_input_refused",
        "not_estimated",
    }
)


class MutationDriftError(RuntimeError):
    """The observed implementation does not match this probe's exact target."""


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise MutationDriftError(message)


def _method(tree: ast.Module) -> tuple[ast.ClassDef, ast.FunctionDef]:
    classes = [node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == CLASS]
    _require(len(classes) == 1, "expected one controller class")
    cls = classes[0]
    methods = [node for node in cls.body if isinstance(node, ast.FunctionDef) and node.name == METHOD]
    _require(len(methods) == 1, "expected one unwrapped synchronous planner method")
    _require(not methods[0].decorator_list, "planner method must not be decorated")
    return cls, methods[0]


def _code(tree: ast.Module, filename: str) -> types.CodeType:
    cls, method = _method(tree)
    compiled = compile(tree, filename, "exec", dont_inherit=True, optimize=0)
    class_codes = [
        value
        for value in compiled.co_consts
        if isinstance(value, types.CodeType)
        and value.co_name == CLASS
        and value.co_firstlineno == cls.lineno
    ]
    _require(len(class_codes) == 1, "expected one compiled class")
    codes = [
        value
        for value in class_codes[0].co_consts
        if isinstance(value, types.CodeType)
        and value.co_name == METHOD
        and value.co_firstlineno == method.lineno
    ]
    _require(len(codes) == 1, "expected one compiled planner method")
    return codes[0]


def make_codes(source: bytes, filename: str) -> tuple[types.CodeType, types.CodeType, dict[str, object]]:
    """Compile original and selectively disabled basis mapping, never execute module code."""
    tree = ast.parse(source, filename=filename)
    original = _code(tree, filename)
    _, method = _method(tree)
    expected_test = ast.dump(ast.parse(_EXPECTED_TEST, mode="eval").body, include_attributes=False)
    sites = [
        node
        for node in ast.walk(method)
        if isinstance(node, ast.If)
        and ast.dump(node.test, include_attributes=False) == expected_test
        and any(
            isinstance(statement, ast.Assign)
            and len(statement.targets) == 1
            and isinstance(statement.targets[0], ast.Name)
            and statement.targets[0].id == "limitation"
            and isinstance(statement.value, ast.Constant)
            and statement.value.value == "requirement_basis_not_established"
            for statement in node.body
        )
    ]
    _require(len(sites) == 1, "expected one not-established basis mapping")
    site = sites[0]
    untouched = ast.dump(tree, include_attributes=False)
    original_test = site.test
    impossible_test = copy.deepcopy(original_test)
    _require(isinstance(impossible_test, ast.Compare), "expected comparison")
    _require(len(impossible_test.ops) == 1 and isinstance(impossible_test.ops[0], ast.Eq), "expected equality")
    impossible_test.ops[0] = ast.NotEq()
    replacement = ast.BoolOp(op=ast.And(), values=[copy.deepcopy(original_test), impossible_test])
    site.test = ast.copy_location(replacement, original_test)
    ast.fix_missing_locations(tree)
    mutant = _code(tree, filename)
    site.test = original_test
    _require(ast.dump(tree, include_attributes=False) == untouched, "unexpected AST change")
    _require(mutant != original and mutant.co_code != original.co_code, "mutation did not change bytecode")
    for name in (
        "co_argcount",
        "co_posonlyargcount",
        "co_kwonlyargcount",
        "co_flags",
        "co_freevars",
        "co_cellvars",
        "co_varnames",
        "co_names",
        "co_name",
        "co_qualname",
    ):
        _require(getattr(original, name) == getattr(mutant, name), f"code interface drift: {name}")
    for marker in _MARKERS:
        _require(marker in original.co_consts and marker in mutant.co_consts, f"marker lost: {marker}")
    return original, mutant, {
        "target_line": site.lineno,
        "replacement": "state == not_established AND state != not_established",
        "preserved_markers": sorted(_MARKERS),
    }
