"""Bounded stdlib-only source controls; does not import or execute product modules."""
from __future__ import annotations

import ast
import copy
import hashlib
import json
import subprocess
from difflib import unified_diff
from pathlib import Path
from types import SimpleNamespace

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
PACKAGE = ROOT / 'LOCAL/raw/e02-execution-20261027/repairs/N7-fetch-owner-fixture-r1'
BASE = 'fe8f75e6ff2580879ecd5c4ca42c370a3fd82694'
FILES = (
    'policy-engine/tests/unit/fabric/test_retrieval_fetch_custody.py',
    'policy-engine/tests/unit/remediation/test_acq_01.py',
)


def base_bytes(path: str) -> bytes:
    return subprocess.check_output(['git', 'show', f'{BASE}:{path}'], cwd=ROOT)


def function(module: ast.Module, name: str) -> ast.FunctionDef | ast.AsyncFunctionDef:
    return next(node for node in module.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == name)


def digest_node(node: ast.AST) -> str:
    return hashlib.sha256(ast.dump(node, include_attributes=False).encode()).hexdigest()


checks: dict[str, object] = {}
patch: list[str] = []
for rel in FILES:
    old = base_bytes(rel)
    new = (PACKAGE / 'postimages' / rel).read_bytes()
    old_ast = ast.parse(old, filename=rel)
    new_ast = ast.parse(new, filename=rel)
    names = (
        ('test_worldbank_connector_replays_existing_http_fixture_through_real_owner', 'test_real_fetch_owner_closes_graph_on_consumer_error')
        if 'fabric/' in rel else
        ('test_acq01_fixture_reuses_selected_store_and_prior_owner_context', 'test_n7_acq01_real_measurement_root_delta_builds_fresh_wmr')
    )
    for name in names:
        assert digest_node(function(old_ast, name)) == digest_node(function(new_ast, name)), name
        checks[f'unchanged_ast:{name}'] = 'PASS'
    if 'fabric/' in rel:
        old_positive = function(old_ast, 'test_worldbank_fetch_owner_persists_into_the_supplied_cas')
        new_positive = function(new_ast, 'test_worldbank_fetch_owner_persists_into_the_supplied_cas')
        old_asserts = {digest_node(node) for node in ast.walk(old_positive) if isinstance(node, ast.Assert)}
        new_asserts = {digest_node(node) for node in ast.walk(new_positive) if isinstance(node, ast.Assert)}
        assert old_asserts <= new_asserts
        checks['all_original_selected_store_assertions_retained'] = len(old_asserts)
    patch.extend(unified_diff(old.decode().splitlines(keepends=True), new.decode().splitlines(keepends=True), fromfile=f'a/{rel}', tofile=f'b/{rel}'))
    checks[f'parse:{rel}'] = 'PASS'

assert (PACKAGE / 'proposal.patch').read_text() == ''.join(patch)
checks['proposal_patch_recomputed_readback'] = 'PASS'
service_path = 'policy-engine/src/polisyos/fabric/retrieval/service.py'
service = ast.parse(base_bytes(service_path), filename=service_path)
service_cls = next(node for node in service.body if isinstance(node, ast.ClassDef) and node.name == 'RetrievalService')
execute = next(node for node in service_cls.body if isinstance(node, ast.FunctionDef) and node.name == 'execute_fetch_plans')
loops = [node for node in ast.walk(execute) if isinstance(node, ast.For) and isinstance(node.target, ast.Name) and node.target.id == 'plan' and isinstance(node.iter, ast.Name) and node.iter.id == 'plans']
assert len(loops) == 1
harness = ast.parse('''def witness(self, plans):
    previews = []
    persist_payload = False
    allow_fallback = False
    execution_binding = None
    fallback_triggered_count = 0
    promoted_count = 0
    return previews
''')
harness.body[0].body.insert(-1, copy.deepcopy(loops[0]))
ast.fix_missing_locations(harness)
namespace: dict[str, object] = {}
exec(compile(harness, '<extracted-executor-loop>', 'exec'), namespace)
executor = SimpleNamespace(execute=lambda plan, **kwargs: SimpleNamespace(fallback_used=False, metric=None, input_plan=plan))
owner = SimpleNamespace(_executor=executor)
witness = namespace['witness']
assert witness(owner, []) == []
assert [item.input_plan for item in witness(owner, ['a', 'b'])] == ['a', 'b']
checks['extracted_executor_loop_zero_and_two_plans'] = 'PASS'

pipeline_path = 'policy-engine/src/polisyos/data_forge/domains/catalog/batch/pipeline.py'
pipeline = ast.parse(base_bytes(pipeline_path), filename=pipeline_path)
receipt = function(pipeline, 'current_catalog_publish_receipt')
path_assign = next(node for node in receipt.body if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'path' for target in node.targets))
layout_if = next(node for node in receipt.body if isinstance(node, ast.If) and any(isinstance(item, ast.Constant) and item.value == 'unmatched_batch_database' for item in ast.walk(node)))
harness = ast.parse('''def witness(database_path):
    return {"state": "layout_only_not_rejected"}
''')
harness.body[0].body[0:0] = [copy.deepcopy(path_assign), copy.deepcopy(layout_if)]
ast.fix_missing_locations(harness)
namespace = {'Path': Path}
exec(compile(harness, '<extracted-publisher-layout>', 'exec'), namespace)
layout = namespace['witness']
assert layout('/tmp/case/capture/catalog.duckdb')['reason'] == 'unmatched_batch_database'
assert layout('/tmp/case/snapshot/datasets/graph/dataset_catalog.duckdb')['state'] == 'layout_only_not_rejected'
assert layout('/tmp/case/snapshot/other/graph/dataset_catalog.duckdb')['reason'] == 'unmatched_batch_database'
checks['extracted_publisher_layout_bare_and_correct_and_wrong_parent'] = 'PASS_LAYOUT_ONLY'

command = ['git', 'apply', '--check', str(PACKAGE / 'proposal.patch')]
result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
assert (PACKAGE / 'apply-check.stdout.txt').read_text() == result.stdout
assert (PACKAGE / 'apply-check.stderr.txt').read_text() == result.stderr
checks['git_apply_check'] = {'returncode': result.returncode, 'stdout': 'apply-check.stdout.txt', 'stderr': 'apply-check.stderr.txt'}
assert result.returncode == 0
ruff = ROOT / 'policy-engine/.venv/bin/python'
for index, rel in enumerate(FILES, 1):
    data = (PACKAGE / 'postimages' / rel).read_bytes()
    for mode in ('check', 'format'):
        args = [str(ruff), '-B', '-m', 'ruff', mode]
        if mode == 'format':
            args.append('--check')
        args.extend(['--stdin-filename', rel.removeprefix('policy-engine/'), '-'])
        result = subprocess.run(args, cwd=ROOT / 'policy-engine', input=data, capture_output=True)
        stem = f'ruff-{index}-{mode}'
        assert (PACKAGE / f'{stem}.stdout.txt').read_bytes() == result.stdout
        assert (PACKAGE / f'{stem}.stderr.txt').read_bytes() == result.stderr
        checks[stem] = {'returncode': result.returncode, 'stdout': f'{stem}.stdout.txt', 'stderr': f'{stem}.stderr.txt'}
        assert result.returncode == 0, (stem, result.stderr.decode(errors='replace'))

checks['product_imports_and_runtime'] = 'UNRUN'
checks['extracted_controls_boundary'] = 'Only the copied AST blocks above run with synthetic stdlib values; no actual producer, source owner, selected store, or catalog admission is executed.'
print(json.dumps(checks, indent=2, sort_keys=True))
