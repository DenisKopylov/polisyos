from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import platform
import resource
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos").resolve()
PRODUCT = ROOT / "policy-engine"
CASE = Path(__file__).resolve().parent
EXPECTED_HEAD = "4ccfa564f925d048f3c46dc0069ffcbfe028a13a"
EXPECTED_TREE = "5f44a9eca496ff46472ee426daf457cfdcef9beb"
EXPECTED_BRANCH = "refs/heads/codex/e02-unified-local-20261009"
LIVE = ROOT / "LOCAL/raw/root-live-ownership-20261021.json"
GUARD_LIB = PRODUCT / "docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/root-layer-lib.py"
SUPERVISOR = PRODUCT / "docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-postfix-709-q2-helper-actual-20261018/supervise.py"
R148 = PRODUCT / "docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1/r148-n7-identity-independence-diagnostics-r1"
R148_CHILD_SHA = "36733099948caa1a6a46c4b5a5f6dd8ba476d250effc807975d315e912372487"
R148_FRAGMENT_SHA = "8a6be8cb31b30ca548403086bc33be95c8db32d367aa9f5658a57c8925ba9dc6"
SUPERVISOR_SHA = "a94a662308270ba3aca96c1d9c75e53a05e37a923a6188d0f464f8ac1e90909e"
GUARD_SHA = "4b381f40f830180c0aa3d1a3cc6d091bc5e5f4598660a1824894d7a188351d35"
EXPECTED_PROFILE_SHA = "a8e260a92fa958e0042bebc249704eebbb767b928ac7f63baec52b61d747f8a4"
RSS_CAP = 2300 * 1024 * 1024
DISK_START = 8 * 1024**3
DISK_STOP = 6 * 1024**3
WALL_SECONDS = 180
PYTHON = PRODUCT / ".venv/bin/python"
TARGET_FILE = PRODUCT / "src/polisyos/runtime/quality/confidence_ledger.py"
RELATED_FILE = PRODUCT / "src/polisyos/runtime/quality/promotion_sequence.py"


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha_file(path: Path) -> str:
    return sha_bytes(path.read_bytes())


def git(*args: str) -> bytes:
    return subprocess.check_output(["git", "-C", str(ROOT), *args])


def frame() -> dict[str, Any]:
    return {
        "branch": git("symbolic-ref", "-q", "HEAD").decode().strip(),
        "head": git("rev-parse", "HEAD").decode().strip(),
        "tree": git("rev-parse", "HEAD^{tree}").decode().strip(),
        "tracked_status": git("status", "--porcelain=v1", "--untracked-files=no").decode(),
        "index_raw_sha256": sha_bytes(git("diff", "--cached", "--raw", "--no-abbrev", "-z")),
    }


def load_guard():
    spec = importlib.util.spec_from_file_location("r152_root_layer_guard", GUARD_LIB)
    if spec is None or spec.loader is None:
        raise RuntimeError("root_guard_spec_missing")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    guard = getattr(module, "guard", None)
    if not callable(guard):
        raise RuntimeError("root_guard_callable_missing")
    return guard


def memory_pressure() -> dict[str, Any]:
    try:
        proc = subprocess.run(["/usr/bin/memory_pressure"], capture_output=True, text=True, timeout=5, check=True)
        text = proc.stdout
        total = next((line.strip() for line in text.splitlines() if "The system has" in line), None)
        free_pct = next((line.strip() for line in text.splitlines() if "free percentage" in line), None)
        return {"status": "read", "total_line": total, "free_percentage_line": free_pct}
    except BaseException as exc:
        return {"status": "unavailable", "error": f"{type(exc).__name__}: {exc}"}


def git_tree_map() -> dict[str, str]:
    raw = git("ls-tree", "-r", "-z", "HEAD", "--", "policy-engine/src/polisyos", "policy-engine/tools", "policy-engine/tests")
    result: dict[str, str] = {}
    for entry in raw.split(b"\0"):
        if not entry:
            continue
        metadata, path = entry.split(b"\t", 1)
        _mode, kind, oid = metadata.decode("ascii").split()
        if kind == "blob":
            result[path.decode("utf-8", errors="surrogateescape")] = oid
    return result


def reconcile(probe: dict[str, Any], tree: dict[str, str]) -> dict[str, Any]:
    fmap = probe["first_party_origin_map"]["files"]
    results = []
    for physical, observed in sorted(fmap.items()):
        path = Path(physical)
        try:
            rel = path.relative_to(ROOT).as_posix()
            data = path.read_bytes()
            current_sha = sha_bytes(data)
            git_oid = tree.get(rel)
            computed_oid = hashlib.sha1(b"blob " + str(len(data)).encode("ascii") + b"\0" + data).hexdigest()
            results.append({
                "path": rel,
                "observed_sha256": observed.get("sha256"),
                "current_sha256": current_sha,
                "source_bytes_unchanged_since_probe": current_sha == observed.get("sha256"),
                "frozen_tree_blob_oid": git_oid,
                "computed_blob_oid": computed_oid,
                "frozen_tree_match": git_oid is not None and git_oid == computed_oid,
                "bytes": len(data),
            })
        except BaseException as exc:
            results.append({
                "path": physical,
                "error": f"{type(exc).__name__}: {exc}",
                "frozen_tree_match": False,
                "source_bytes_unchanged_since_probe": False,
            })
    bad = [row for row in results if row.get("frozen_tree_match") is not True or row.get("source_bytes_unchanged_since_probe") is not True]
    return {
        "scope": "Every first-party origin file in the probe map; Git blob object and current physical bytes compared to frozen HEAD.",
        "module_count": probe["first_party_origin_map"]["module_count"],
        "file_count": len(results),
        "matched_count": len(results) - len(bad),
        "mismatch_count": len(bad),
        "mismatches": bad[:30],
    }


def tree_snapshot() -> dict[str, Any]:
    paths = [TARGET_FILE, RELATED_FILE, PRODUCT / "pyproject.toml", PRODUCT / "uv.lock", PRODUCT / ".venv/pyvenv.cfg", LIVE]
    return {str(p.relative_to(ROOT)): {"exists": p.is_file(), "sha256": sha_file(p) if p.is_file() else None, "bytes": p.stat().st_size if p.is_file() else None} for p in paths}


def iter_case_files() -> dict[str, Any]:
    out = {}
    for path in sorted(CASE.rglob("*")):
        if path.is_file() and path.name not in {"result.json", "result.sha256"}:
            rel = path.relative_to(CASE).as_posix()
            data = path.read_bytes()
            out[rel] = {"bytes": len(data), "sha256": sha_bytes(data)}
    return out


def write_json_once(path: Path, data: dict[str, Any]) -> None:
    encoded = (json.dumps(data, indent=2, sort_keys=True) + "\n").encode()
    fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    with os.fdopen(fd, "wb") as stream:
        stream.write(encoded)
        stream.flush()
        os.fsync(stream.fileno())


def main() -> int:
    start = time.monotonic()
    deadline = start + WALL_SECONDS
    pre = {
        "source": frame(),
        "root_live_sha256": sha_file(LIVE) if LIVE.is_file() else None,
        "source_inputs": tree_snapshot(),
        "disk_free_bytes": shutil.disk_usage(CASE).free,
        "memory_pressure": memory_pressure(),
        "controller_interpreter": {"executable": sys.executable, "version": sys.version, "platform": platform.platform()},
        "controller_pid": os.getpid(),
        "actual_home": os.environ.get("HOME"),
        "home_environment_not_overridden": True,
    }
    result: dict[str, Any] = {
        "schema": "policyos.e02.n7.import_only_run.r152.v1",
        "classification": "HARNESS_ERROR",
        "semantic_state": "UNRUN",
        "g_acceptance": False,
        "closure_ids": [],
        "source_expected": {"branch": EXPECTED_BRANCH, "head": EXPECTED_HEAD, "tree": EXPECTED_TREE},
        "pre": pre,
        "root_guard_before": None,
        "root_guard_after": None,
        "supervisor_command": None,
        "probe_reconciliation": None,
        "post": None,
        "limits": {
            "wall_deadline_seconds": WALL_SECONDS,
            "process_tree_rss_cap_bytes": RSS_CAP,
            "disk_start_bytes": DISK_START,
            "disk_stop_bytes": DISK_STOP,
            "numeric_threads": 1,
            "supervisor_samples_controller_and_child": True,
            "source_writes": "denied",
            "writable_scope": str(CASE),
            "network": "denied",
            "production_data": "denied",
            "home": "inherited unchanged",
        },
    }
    try:
        names = ("tmp", "xdg-cache", "xdg-config", "xdg-data", "xdg-state", "pycache", "mplconfig", "numba")
        if CASE.resolve() != CASE or any(p.is_symlink() for p in (CASE, *(CASE / name for name in names))):
            raise RuntimeError("case_path_symlink_or_escape")
        if not CASE.is_dir() or not all((CASE / name).is_dir() for name in names):
            raise RuntimeError("fresh_case_or_scratch_missing")
        if any((CASE / "pycache").iterdir()):
            raise RuntimeError("private_pycache_not_empty_at_admission")
        if not PYTHON.is_file() or Path(sys.executable).resolve() != PYTHON.resolve():
            raise RuntimeError("controller_not_product_python")
        current = frame()
        if current["branch"] != EXPECTED_BRANCH or current["head"] != EXPECTED_HEAD or current["tree"] != EXPECTED_TREE:
            raise RuntimeError("source_frame_mismatch")
        if pre["source"]["tracked_status"] or pre["source"]["index_raw_sha256"] != hashlib.sha256(b"").hexdigest():
            raise RuntimeError("tracked_or_index_delta_present")
        if pre["disk_free_bytes"] < DISK_START:
            raise RuntimeError("disk_start_admission_below_8_gib")
        if sha_file(SUPERVISOR) != SUPERVISOR_SHA:
            raise RuntimeError("retained_supervisor_hash_mismatch")
        if sha_file(GUARD_LIB) != GUARD_SHA:
            raise RuntimeError("root_guard_library_hash_mismatch")
        if sha_file(R148 / "child.sb") != R148_CHILD_SHA or sha_file(R148 / "sandbox-fragment.sb") != R148_FRAGMENT_SHA:
            raise RuntimeError("R148_profile_input_hash_mismatch")
        if sha_file(CASE / "sandbox.sb") != EXPECTED_PROFILE_SHA:
            raise RuntimeError("derived_sandbox_profile_hash_mismatch")
        if sha_file(LIVE) != pre["root_live_sha256"]:
            raise RuntimeError("root_live_changed_during_preflight")
        guard = load_guard()
        result["root_guard_before"] = guard()
        if result["root_guard_before"]["head"] != EXPECTED_HEAD:
            raise RuntimeError("root_guard_expected_head_mismatch")
        if result["root_guard_before"]["expected_index"]["raw_diff_sha256"] != pre["source"]["index_raw_sha256"]:
            raise RuntimeError("root_guard_index_mismatch")
        if pre["source_inputs"]["policy-engine/src/polisyos/runtime/quality/confidence_ledger.py"]["sha256"] is None:
            raise RuntimeError("owner_source_missing")

        env = {
            "PYTHONPATH": str(PRODUCT / "src"),
            "PYTHONDONTWRITEBYTECODE": "1",
            "PYTHONNOUSERSITE": "1",
            "PYTHONPYCACHEPREFIX": str(CASE / "pycache"),
            "TMPDIR": str(CASE / "tmp"),
            "XDG_CACHE_HOME": str(CASE / "xdg-cache"),
            "XDG_CONFIG_HOME": str(CASE / "xdg-config"),
            "XDG_DATA_HOME": str(CASE / "xdg-data"),
            "XDG_STATE_HOME": str(CASE / "xdg-state"),
            "MPLCONFIGDIR": str(CASE / "mplconfig"),
            "NUMBA_CACHE_DIR": str(CASE / "numba"),
            "SCIENTIST_TORCH_NUM_THREADS": "1",
            "SCIENTIST_TORCH_NUM_INTEROP_THREADS": "1",
        }
        supervisor_spec = importlib.util.spec_from_file_location("r152_retained_supervisor", SUPERVISOR)
        if supervisor_spec is None or supervisor_spec.loader is None:
            raise RuntimeError("retained_supervisor_spec_missing")
        supervisor = importlib.util.module_from_spec(supervisor_spec)
        supervisor_spec.loader.exec_module(supervisor)
        supervisor.RSS_CAP_BYTES = RSS_CAP
        supervisor.DISK_FLOOR_BYTES = DISK_STOP
        raw_descendant_snapshot = supervisor.descendant_snapshot
        controller_pid = os.getpid()

        def inclusive_snapshot(child_pid: int):
            rows, child_total = raw_descendant_snapshot(child_pid)
            proc = subprocess.run(["/bin/ps", "-o", "pid=,ppid=,pgid=,rss=,etime=,command=", "-p", str(controller_pid)], capture_output=True, text=True, timeout=3, check=True)
            line = proc.stdout.strip()
            if not line:
                raise RuntimeError("controller_rss_sample_missing")
            parts = line.split(None, 5)
            if len(parts) < 4:
                raise RuntimeError("controller_rss_sample_malformed")
            controller_rss = int(parts[3]) * 1024
            rows.append({
                "pid": controller_pid,
                "ppid": os.getppid(),
                "pgid": os.getpgrp(),
                "rss_kib": controller_rss // 1024,
                "elapsed": parts[4] if len(parts) > 4 else "",
                "command": parts[5] if len(parts) > 5 else "R152 controller",
                "sample_role": "controller_included",
            })
            return rows, child_total + controller_rss

        supervisor.descendant_snapshot = inclusive_snapshot
        command = {
            "argv": ["/usr/bin/sandbox-exec", "-f", str(CASE / "sandbox.sb"), str(PYTHON), "-B", "-P", str(CASE / "probe.py")],
            "cwd": str(PRODUCT),
            "extra_env": env,
            "deadline_seconds": WALL_SECONDS,
            "rss_cap_bytes": RSS_CAP,
            "disk_floor_bytes": DISK_STOP,
        }
        result["supervisor_command"] = {
            **command,
            "stdout_path": str(CASE / "import-only.stdout.txt"),
            "stderr_path": str(CASE / "import-only.stderr.txt"),
            "supervisor_script_sha256": sha_file(SUPERVISOR),
            "supervisor_controller_function": "retained supervise.run_command with local R152 caps and controller RSS included in the sampled total",
        }
        run = supervisor.run_command(CASE, "import-only", command["argv"], PRODUCT, start, deadline, env)
        result["supervisor_result"] = run
        stdout_path = CASE / "import-only.stdout.txt"
        stderr_path = CASE / "import-only.stderr.txt"
        if stdout_path.is_file():
            try:
                probe = json.loads(stdout_path.read_text(encoding="utf-8"))
                tree = git_tree_map()
                result["probe_reconciliation"] = reconcile(probe, tree)
                result["probe_summary"] = {
                    "probe_outcome": probe.get("probe_outcome"),
                    "target": probe.get("target"),
                    "sticky_import_time": probe.get("sticky_import_time"),
                    "captured_observation": probe.get("captured_observation"),
                    "first_party_origin_map": {
                        k: v for k, v in probe.get("first_party_origin_map", {}).items() if k not in {"modules", "files"}
                    },
                    "private_full_probe_output": str(stdout_path.relative_to(ROOT)),
                }
                if (
                    run.get("status") == "passed"
                    and probe.get("probe_outcome") in {"import_completed", "import_exception_captured"}
                    and probe.get("first_party_origin_map", {}).get("strict_typed_map_valid")
                    and result["probe_reconciliation"]["mismatch_count"] == 0
                ):
                    result["classification"] = "DIAGNOSTIC_CAPTURED"
                    result["semantic_state"] = "OBSERVED_NOT_PRODUCT_PASS"
            except BaseException as exc:
                result["probe_parse_error"] = f"{type(exc).__name__}: {exc}"
        result["probe_output"] = {
            "stdout_exists": stdout_path.is_file(),
            "stdout_bytes": stdout_path.stat().st_size if stdout_path.is_file() else None,
            "stdout_sha256": sha_file(stdout_path) if stdout_path.is_file() else None,
            "stderr_exists": stderr_path.is_file(),
            "stderr_bytes": stderr_path.stat().st_size if stderr_path.is_file() else None,
            "stderr_sha256": sha_file(stderr_path) if stderr_path.is_file() else None,
        }
    except BaseException as exc:
        result["admission_or_control_error"] = f"{type(exc).__name__}: {exc}"
        result["classification"] = "HARNESS_ERROR"
        result["semantic_state"] = "UNRUN_OR_PARTIAL"

    try:
        result["post"] = {
            "source": frame(),
            "root_live_sha256": sha_file(LIVE) if LIVE.is_file() else None,
            "source_inputs": tree_snapshot(),
            "disk_free_bytes": shutil.disk_usage(CASE).free,
            "memory_pressure": memory_pressure(),
        }
        if result["root_guard_before"] is not None:
            result["root_guard_after"] = load_guard()()
        result["source_unchanged"] = (
            result["pre"]["source"] == result["post"]["source"]
            and result["pre"]["root_live_sha256"] == result["post"]["root_live_sha256"]
            and result["pre"]["source_inputs"] == result["post"]["source_inputs"]
            and result["root_guard_before"] == result["root_guard_after"]
        )
        if not result["source_unchanged"] and result["classification"] == "DIAGNOSTIC_CAPTURED":
            result["classification"] = "HARNESS_ERROR"
            result["semantic_state"] = "UNRUN_OR_PARTIAL"
    except BaseException as exc:
        result["post_error"] = f"{type(exc).__name__}: {exc}"
        result["classification"] = "HARNESS_ERROR"
        result["semantic_state"] = "UNRUN_OR_PARTIAL"

    result["finished_at_epoch_ns"] = time.time_ns()
    result["elapsed_total_seconds"] = time.monotonic() - start
    result["artifacts_before_result"] = iter_case_files()
    write_json_once(CASE / "result.json", result)
    digest = sha_file(CASE / "result.json")
    fd = os.open(CASE / "result.sha256", os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    with os.fdopen(fd, "w", encoding="ascii") as stream:
        stream.write(f"{digest}  result.json\n")
        stream.flush()
        os.fsync(stream.fileno())
    print(json.dumps({
        "classification": result["classification"],
        "semantic_state": result["semantic_state"],
        "probe_outcome": result.get("probe_summary", {}).get("probe_outcome"),
        "failure_code": result.get("probe_summary", {}).get("sticky_import_time", {}).get("failure_tuple", {}).get("code") if isinstance(result.get("probe_summary", {}).get("sticky_import_time", {}).get("failure_tuple"), dict) else None,
        "captured_status": result.get("probe_summary", {}).get("captured_observation", {}).get("status") if isinstance(result.get("probe_summary", {}).get("captured_observation"), dict) else None,
        "origin_files": result.get("probe_reconciliation", {}).get("file_count"),
        "origin_mismatches": result.get("probe_reconciliation", {}).get("mismatch_count"),
        "wall_seconds": result.get("elapsed_total_seconds"),
        "disk_free_bytes_before": result.get("pre", {}).get("disk_free_bytes"),
        "disk_free_bytes_after": result.get("post", {}).get("disk_free_bytes") if result.get("post") else None,
        "result_path": str(CASE / "result.json"),
        "result_sha256": digest,
        "closure_ids": [],
    }, sort_keys=True))
    return 0 if result["classification"] == "DIAGNOSTIC_CAPTURED" else 2


if __name__ == "__main__":
    raise SystemExit(main())
