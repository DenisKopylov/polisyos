"""Build a sparse source packet using stdlib and static Ruff only; never imports product."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import os
import re
import stat
import subprocess
import tomllib

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
OUT = Path(__file__).resolve().parent
POST = OUT / 'postimages'
BASE = '545c6990e2bfa42bf580b475e23cf88df04e71d8'
PRODUCT = ROOT / 'policy-engine'
sha = lambda value: hashlib.sha256(value).hexdigest()
checks = []
for path in sorted(POST.rglob('*.py')):
    logical = str(ROOT / path.relative_to(POST))
    data = path.read_bytes()
    compile(data, logical, 'exec')
    for args in [('check', '--select', 'I', '--fix'), ('format',)]:
        argv = [str(PRODUCT / '.venv/bin/python'), '-m', 'ruff', *args, '--no-cache', '--stdin-filename', logical, '-']
        result = subprocess.run(argv, input=data, cwd=PRODUCT, capture_output=True)
        assert result.returncode == 0, (logical, result.stdout.decode(), result.stderr.decode())
        data = result.stdout
    path.write_bytes(data)
    for args in [('check',), ('format', '--check')]:
        argv = [str(PRODUCT / '.venv/bin/python'), '-m', 'ruff', *args, '--no-cache', '--stdin-filename', logical, '-']
        result = subprocess.run(argv, input=data, cwd=PRODUCT, capture_output=True)
        checks.append({'path': str(path.relative_to(POST)), 'argv': argv, 'exit': result.returncode, 'stdout': result.stdout.decode(), 'stderr': result.stderr.decode()})
        assert result.returncode == 0, checks[-1]
for path in POST.rglob('*.toml'):
    tomllib.loads(path.read_text())

files = []
patch = []
mismatches = []
for path in sorted(POST.rglob('*')):
    if not path.is_file():
        continue
    info = path.stat()
    assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and not path.is_symlink(), str(path)
    rel = str(path.relative_to(POST))
    data = path.read_bytes()
    entry = subprocess.run(['git', 'show', BASE + ':' + rel], cwd=ROOT, capture_output=True)
    old = entry.stdout if entry.returncode == 0 else b''
    if entry.returncode == 0 and old == data:
        continue
    mode = subprocess.check_output(['git', 'ls-tree', BASE, '--', rel], cwd=ROOT, text=True).split()
    current = ROOT / rel
    matches = (current.read_bytes() if current.exists() else None) == (old if mode else None)
    if not matches:
        mismatches.append(rel)
    files.append({'path': rel, 'preimage_mode': mode[0] if mode else None, 'preimage_git_blob': mode[2] if mode else None, 'preimage_sha256': sha(old) if mode else None, 'postimage_git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest(), 'postimage_sha256': sha(data), 'bytes': len(data), 'postimage': str(path.relative_to(ROOT)), 'current_preimage_match': matches, 'role': 'mechanism' if rel.startswith('policy-engine/src/') and rel.endswith('.py') else 'mandatory companion'})
    patch.append(f'diff --git a/{rel} b/{rel}\n')
    if not mode:
        patch.append('new file mode 100644\n')
    patch.extend(difflib.unified_diff(old.decode().splitlines(keepends=True), data.decode().splitlines(keepends=True), fromfile='a/' + rel if mode else '/dev/null', tofile='b/' + rel, n=3))
patch_bytes = ''.join(patch).encode()
(OUT / 'proposal.patch').write_bytes(patch_bytes)

controls = []
def removal(name, path, old, new, selectors, red):
    data = (POST / path).read_text()
    assert data.count(old) == 1, (name, data.count(old))
    mutant = data.replace(old, new)
    if path.endswith('.py'):
        compile(mutant, path, 'exec')
    content = ''.join(difflib.unified_diff(data.splitlines(keepends=True), mutant.splitlines(keepends=True), fromfile='a/' + path, tofile='b/' + path, n=3)).encode()
    dest = OUT / 'removals' / name
    dest.parent.mkdir(exist_ok=True)
    dest.write_bytes(content)
    controls.append({'name': name, 'path': path, 'preimage_sha256': sha(data.encode()), 'postimage_sha256': sha(mutant.encode()), 'patch_sha256': sha(content), 'selectors': selectors, 'intended_semantic_red': red, 'execution': 'UNRUN'})

def source_span(path, node):
    lines = (POST / path).read_text().splitlines(keepends=True)
    return ''.join(lines[node.lineno - 1:node.end_lineno])

cal = 'policy-engine/src/polisyos/foundry/calibration/calibrator.py'
pure = 'policy-engine/src/polisyos/foundry/calibration/pure_executor.py'
basis = 'policy-engine/src/polisyos/foundry/calibration/execution_basis.py'
welfare = 'policy-engine/src/polisyos/scientist/nodes/builtins/simulate/welfare_covariance.py'
ordered_test = 'tests/unit/foundry/calibration/test_ordered_batch_calibration.py::'
pure_test = 'tests/unit/foundry/calibration/test_pure_executor_semantics.py::'
welfare_test = 'tests/unit/scientist/nodes/builtins/simulate/test_propagate_welfare.py::'
cal_tree = ast.parse((POST / cal).read_text())
loss = next(n for n in cal_tree.body if isinstance(n, ast.FunctionDef) and n.name == '_ordered_batch_loss')
valid = next(n for n in loss.body if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'inputs_valid')
removal('remove-numeric-admission.patch', cal, source_span(cal, valid), '    inputs_valid = jnp.array(True)\n', [ordered_test + 'test_ordered_batch_transformed_domain_never_accepts_invalid_support'], 'The original invalid-negative-weight validity/objective assertions fail on finite admitted loss; setup, collection and genuine valid rows must still work.')
removal('remove-exact-row-key.patch', pure, '    return jax.lax.map(_apply, (states, times, keys))', '    return jax.lax.map(_apply, (states, times, jnp.broadcast_to(keys[0], keys.shape)))', [ordered_test + 'test_ordered_batch_matches_independent_scalar_rows_and_exact_keys'], 'Independent stochastic scalar predictions or exact returned row keys disagree for active rows; no replacement oracle is introduced.')
pure_tree = ast.parse((POST / pure).read_text())
compile_node = next(n for n in pure_tree.body if isinstance(n, ast.FunctionDef) and n.name == 'compile_program')
call = next(n for n in ast.walk(compile_node) if isinstance(n, ast.Expr) and isinstance(n.value, ast.Call) and isinstance(n.value.func, ast.Name) and n.value.func.id == '_validate_selector_structure')
removal('remove-static-selector-admission.patch', pure, source_span(pure, call), '            pass  # removal only: retain parsed selector and all runtime markers\n', [pure_test + 'test_compile_program_refuses_inactive_unknown_selector_before_numerical_work'], 'The same inactive unknown-field compile assertion says DID NOT RAISE; no numerical selector/emitter runs. The adjacent no-selector positive remains available.')
active = next(n for n in ast.walk(pure_tree) if isinstance(n, ast.FunctionDef) and n.name == '_active_branch')
mask_assignment, mask_if = active.body[1:3]
assert isinstance(mask_if, ast.If)
inner = source_span(pure, mask_assignment) + source_span(pure, mask_if)
outer = ''.join(line[4:] if line.startswith('    ') else line for line in inner.splitlines(keepends=True)).replace('branch_state,', 'visible_state,')
source = (POST / pure).read_text()
old = source_span(pure, active)
new = outer + old.replace(inner, '')
removal('remove-inactive-numerical-selector-scheduling.patch', pure, old, new, [pure_test + 'test_typed_partial_selector_real_tax_preserves_inactive_and_dependency_visibility'], 'The unchanged first inactive observed_masks == [] assertion fails because a numerical selector callback now executes outside scalar cond; active mask/state effects stay real.')
forward = next(n for n in ast.walk(cal_tree) if isinstance(n, ast.FunctionDef) and n.name == '_execute_forward')
call = next(n for n in ast.walk(forward) if isinstance(n, ast.Assign) and isinstance(n.value, ast.Call) and isinstance(n.value.func, ast.Name) and n.value.func.id == 'evaluate_ordered_batch_objective')
old = source_span(cal, call)
new = '''                first_row_only = replace(
                    batch_profile,
                    states=jax.tree_util.tree_map(lambda value: jnp.broadcast_to(value[0], value.shape), batch_profile.states),
                    row_times=jnp.broadcast_to(batch_profile.row_times[0], batch_profile.row_times.shape),
                    row_keys=jnp.broadcast_to(batch_profile.row_keys[0], batch_profile.row_keys.shape),
                )
''' + old.replace('batch_profile,', 'first_row_only,', 1)
removal('remove-real-batch-row-consumption.patch', cal, old, new, [ordered_test + 'test_real_ordered_batch_run_uses_each_row_in_selected_report'], 'The unchanged actual Calibrator cannot fit distinct 100/300-income rows after consuming row zero for every row; model/objective assertions fail, while validity and report markers remain.')
source = (POST / basis).read_text()
old = '''        or scope.selected_input_ref != basis.ordered_batch_input_ref
        or scope.consumed_profile_sha256 != profile.consumed_profile_sha256
'''
removal('remove-consumed-report-selection.patch', basis, old, '', [welfare_test + 'test_coherent_new_input_and_basis_cannot_replace_the_consumed_report_selection[keys]'], 'A coherent alternate key input/basis with original report markers reaches fresh source status matched, so the original fresh-consumer mismatch assertion fails BEFORE the producer-writer refusal assertion.')
wtree = ast.parse((POST / welfare).read_text())
resolver = next(n for n in wtree.body if isinstance(n, ast.FunctionDef) and n.name == '_resolve_calibration_covariance')
guard = next(n for n in resolver.body if isinstance(n, ast.If) and isinstance(n.test, ast.BoolOp) and isinstance(n.test.values[0], ast.Name) and n.test.values[0].id == 'calibration_fields' and 'curvature_only' in ast.unparse(n.test))
removal('remove-curvature-inference-guard.patch', welfare, source_span(welfare, guard), '    # removal only: retain disjoint-C allowance, typed report/basis/status and issue handling\n', [welfare_test + 'test_generic_batch_curvature_is_not_inferential_welfare_uncertainty[False-delta]'], 'The FIRST calibration-fields bundle.credible_interval is None assertion fails because actual welfare emits a candidate interval after the positive guard is removed. The unrelated external allowance is preserved verbatim; an external-C failure alone is invalid proof.')
removal('remove-objective-ad-connectivity.patch', cal, '    predictions = jnp.asarray(value)\n', '    predictions = jax.lax.stop_gradient(jnp.asarray(value))\n', [ordered_test + 'test_real_ordered_objective_jit_gradient_and_hessian_match_quadratic'], 'Unchanged analytic gradient/Hessian assertions fail (zero versus the real quadratic derivative); forward values, row keys, metadata and test source are unchanged.')
removal('remove-final-state-validity-forwarding.patch', cal, '                valid = valid & traces["__ordered_batch_valid__"]\n', '                # removal only: keep the validity field but discard it in the fitted objective\n', [ordered_test + 'test_parameter_dependent_off_target_nonfinite_state_cannot_win'], 'Initial valid preflight and direct invalid helper assertions stay green; the optimizer incorrectly selects a parameter-dependent off-target-NaN candidate, violating the final retained-valid-parameter/model assertion.')
function = next(n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name == 'replay_ordered_batch_report_projection')
needle = '    if any(\n        ref is None or ref.manifest_profile_sha256 is None\n'
assert source.count(needle) == 1
removal('remove-fresh-final-projection-replay.patch', basis, needle, '    return "matched", ("ordered_hessian_is_unreplayed_curvature_diagnostic",)  # removal only\n' + needle, [welfare_test + 'test_new_report_projection_is_recomputed_from_unchanged_selected_input', welfare_test + 'test_autotune_actual_consumer_admits_only_replayed_new_batch_metrics[changed_metrics]'], 'Changed report model/loss/metrics are no longer rejected by actual fresh welfare/autotune; original mismatch/unavailable-scoring assertions fail, while input selection and typed curvature markers remain.')
(OUT / 'property-removals.json').write_text(json.dumps({'controls': controls, 'protocol': 'UNRUN. Freeze composed source/input/profile/backend. Per control: run exact unchanged selector positive; apply ONE isolated mutation after exact preimage admission; read actual mutant bytes/hash; run same selector and require the named semantic assertion FAIL (not setup/ERROR/SKIP/collection/nonzero exit); byte-exact restore and rerun green. Keep complete quiet deciding output, compressed losslessly if needed. Do not mutate canonical Root source while an unrelated verification uses it.'}, indent=2) + '\n')
prompt = (ROOT / 'LOCAL/raw/e02-execution-20261027/next-cloud/C78/C78-calibrator-chain-r3-v2-frozen.md').read_text()
criteria = []
for match in re.finditer(r'### (B\d+@CAL-\d+) — source lines (\d+)–(\d+)\n\nCoverage (#[^;]+); original span SHA-256 ([0-9a-f]{64})', prompt):
    criteria.append({'occurrence': match[1], 'original_lines': [int(match[2]), int(match[3])], 'criterion_pointer': match[4], 'original_span_sha256': match[5], 'runtime': 'UNRUN', 'G_acceptance': False})
assert len(criteria) == 13
(OUT / 'criteria.json').write_text(json.dumps({'source': 'next-cloud/C78/C78-calibrator-chain-r3-v2-frozen.md', 'source_sha256': sha(prompt.encode()), 'occurrences': criteria, 'formal_closure_ids': []}, indent=2) + '\n')
(OUT / 'static-checks.json').write_text(json.dumps({'checks': checks, 'python_files': len({row['path'] for row in checks}), 'compile': 'PASS, no execution', 'TOML': 'PASS', 'mutation_python_compile': 'PASS, no execution', 'mode': 'canonical logical stdin only; complete physical composed topology remains UNRUN', 'product_imports': False, 'runtime': 'UNRUN'}, indent=2) + '\n')
apply = subprocess.run(['git', 'apply', '--check', '--whitespace=error', str(OUT / 'proposal.patch')], cwd=ROOT, capture_output=True)
(OUT / 'apply-check.json').write_text(json.dumps({'argv': ['git', 'apply', '--check', '--whitespace=error', str(OUT / 'proposal.patch')], 'exit': apply.returncode, 'stdout': apply.stdout.decode(), 'stderr': apply.stderr.decode(), 'mutates_source_index_refs': False}, indent=2) + '\n')
assert apply.returncode == 0, apply.stderr.decode()
manifest = {'schema': 'policyos.e02.sparse_proposal.v1', 'task': 'C78-chain-r2', 'status': 'source_proposal_awaiting_independent_review', 'base_commit': BASE, 'base_tree': 'abd7d9913680d5531081c45536c1cf7d7d701835', 'seed_candidate_tree': '1d55a9c895342e977471ab0edb7259a9a2ff5ef5', 'r1_review': 'reviews/C78-chain-r1-independent.md@f46091491221a2420a0b8617ec9f9f4b088bf286e6148904125d47df9188b336', 'files': files, 'footprint': {'total_paths': len(files), 'mechanism_python_paths': sum(row['role'] == 'mechanism' for row in files), 'companions': sum(row['role'] == 'mandatory companion' for row in files)}, 'patch': {'path': str((OUT / 'proposal.patch').relative_to(ROOT)), 'sha256': sha(patch_bytes), 'bytes': len(patch_bytes)}, 'current_root_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(), 'current_root_tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, text=True).strip(), 'current_preimage_mismatches': mismatches, 'static': 'logical-stdin Ruff/format, compile, TOML, mutation compile, apply-check PASS', 'runtime': 'UNRUN', 'physical_topology': 'UNRUN', 'generated_family': 'Root-only composition, UNRUN', 'capability_state': 'verification_missing', 'canonical_source_changed': False, 'git_index_or_refs_changed': False, 'product_imports_run': False, 'closure_ids': [], 'packet_files': {name: sha((OUT / name).read_bytes()) for name in ['criteria.json', 'property-removals.json', 'static-checks.json', 'apply-check.json']}}
assert not mismatches, mismatches
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'footprint': manifest['footprint'], 'python_files': len({row['path'] for row in checks}), 'controls': len(controls), 'manifest_sha256': sha((OUT / 'manifest.json').read_bytes()), 'patch_sha256': sha(patch_bytes), 'patch_bytes': len(patch_bytes), 'current_root_head': manifest['current_root_head']}))
