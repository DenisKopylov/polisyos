"""Exercise extracted renewal expression and stdlib checker on retained JSON only."""
import ast
import copy
import itertools
import json
import runpy
from pathlib import Path

root = Path.cwd()
packet = root / "LOCAL/raw/e02-execution-20261027/repairs/R4-native-harness-input-r1"
test = packet / "postimages/policy-engine/tests/unit/runtime/http/test_observational_method_runtime.py"
tree = ast.parse(test.read_bytes())
fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "test_real_forest_fit_progress_spans_durable_cancel_post")
assignment = next(n for n in ast.walk(fn) if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "advancing" for t in n.targets))
expr = compile(ast.Expression(assignment.value), "<extracted-advancing-expression>", "eval")
def advance(expiries, times):
    return eval(expr, {"pairwise": itertools.pairwise}, {"expiries": expiries, "eligible_renewals": [{"monotonic_ns": n} for n in times]})
assert not advance(["2026-01-01T00:00:01+00:00"] * 4, [1, 2, 3, 4])
assert advance(["2026-01-01T00:00:01+00:00", "2026-01-01T00:00:02+00:00"], [1, 2])
assert not advance(["2026-01-01T00:00:02+00:00", "2026-01-01T00:00:01+00:00"], [1, 2])
assert not advance(["2026-01-01T00:00:01+00:00", "2026-01-01T00:00:02+00:00"], [1, 1])
assert not advance([None, "2026-01-01T00:00:02+00:00"], [1, 2])
checks = runpy.run_path(str(packet / "native_checks.py"))
observation = json.loads((root / "LOCAL/raw/e02-execution-20261027/repairs/R4-native-control-r1/runs/r4nativep3/evidence/native/fixture-observation.json").read_bytes())
method = observation["method"]
args = dict(job_id=method["job_id"], run_id=method["run_id"], attempt=method["attempt"], owner=method["lease_owner"], actor="test-actor", tenant_id="test-tenant", cell_id="test-cell", positive_post_start_ns=observation["cancel"]["post_start_ns"])
negative = copy.deepcopy(observation["negatives"])
for row in negative:
    row["store_calls"] = []
original = checks["negative_checks"](negative, **args)
assert original["stale_attempt"]["state"] == "INCONCLUSIVE"
assert original["denied_permission"]["state"] == "PASS"
stale = next(r for r in negative if r["kind"] == "stale_attempt")
body = stale["request_body"]; wire = stale["request_wire_utf8"]
stale["store_calls"] = [{"monotonic_ns": stale["request_start_ns"] + 1, "current_authority": True, "bound_job_id_selector": json.dumps(method["job_id"]), "bound_cell_id_selector": json.dumps("test-cell"), "cell_id": "test-cell", "tenant_id": "test-tenant", "authorized_actor": "test-actor", "body_sha256": "sha256:" + checks["sha_bytes"](wire.encode()), "expected_lease_owner": method["lease_owner"], "expected_attempt": body["expected_attempt"], "operation_id": body["operation_id"], "result": "exception", "exception_type": "ControlJobLeaseLostError", "exception_message": "control job cancellation attempt is stale"}]
stale["status_code"] = 409
assert checks["negative_checks"](negative, **args)["stale_attempt"]["state"] == "PASS"
stale["store_calls"][0]["current_authority"] = False
assert checks["negative_checks"](negative, **args)["stale_attempt"]["state"] == "INCONCLUSIVE"
print("5 extracted renewal controls and 4 checker controls PASS; synthetic controls, no product/runtime execution")
