"""Prepare C50 coverage removal triplet after a qualified real positive; never run it."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import re
import runpy
import shutil
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

R=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos');P=R/'policy-engine';HERE=Path(__file__).resolve().parent
D=P/'docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1'
LAYER=D.parent/'root-layer-lib.py';LIVE=R/'LOCAL/raw/root-live-ownership-20261021.json';C59=R/'LOCAL/raw/e02-execution-20261027/repairs/C59-r2-native';REVIEW=R/'LOCAL/raw/e02-execution-20261027/reviews/C59-r2-native-final.md'
SUP=P/'docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-postfix-709-q2-helper-actual-20261018/supervise.py'
MAN=R/'LOCAL/raw/e02-execution-20261027/repairs/C50-r2/manifest.json';DELTA=R/'LOCAL/raw/e02-execution-20261027/repairs/C50-test-import-r1/manifest.json'
PILOT_NODES=['tests/unit/calibration/diagnostics/test_c50_receipt_consistency.py','tests/unit/calibration/diagnostics/test_continuous.py','tests/unit/calibration/diagnostics/test_adapters.py','tests/unit/calibration/diagnostics/test_multiclass.py','tests/unit/ir/analytics/test_calibration_diagnostics_report.py','tests/unit/foundry/methods/test_truthfulness_protocol.py','tests/unit/foundry/methods/backends/test_dispatch.py','tests/unit/foundry/methods/backends/test_dispatch_output_contract.py']
TEST='tests/unit/calibration/diagnostics/test_c50_receipt_consistency.py';FUNCTION='test_positive_metadata_cannot_admit_an_empty_interval_curve';NODE=TEST+'::'+FUNCTION
PINS={C59/'run_guarded.py':'e7d26efd7738eaa482388d00663d7749586a64fffd92d9aff52a1aa39bee2621',C59/'native_env.py':'863a86b08045f0f21677089cad3f48c64ab4b3a2eff427313d00e66648c4273a',C59/'c59_collection_observer.py':'d412489cc0b0d4aea1b3d31276f4cc48f6616df0d5afe640bedf72f989b1a2ce',D/'run_case_with_tools_r2.py':'4c3eae2136b6c8941ba09d4438d12ea6ea11310527768f0482877b877b8e30c2',MAN:'558e7c21c25d61784d323e67d2c5e3d9d06d05788ea5d9924c907feb31e36d06',DELTA:'d8d119e8e97c45ebaa7d1b3ee77632351bf1640a51e4139a19f0948c20c68230'}


def sha(p:Path)->str:return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a:str)->str:return subprocess.check_output(['git',*a],cwd=R,text=True).strip()
def pin(p:Path,head:str)->dict:
 if not p.is_file() or p.is_symlink():raise SystemExit('Missing regular source: '+str(p))
 rel=str(p.relative_to(R));data=subprocess.check_output(['git','show',head+':'+rel],cwd=R)
 if hashlib.sha256(data).hexdigest()!=sha(p):raise SystemExit('Source differs from Git: '+rel)
 if subprocess.run(['git','diff','--cached','--quiet',head,'--',rel],cwd=R).returncode:raise SystemExit('Index differs: '+rel)
 return {'sha256':sha(p),'git_blob':git('rev-parse',head+':'+rel)}


def main()->None:
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--admitted-head',required=True);ap.add_argument('--admitted-tree',required=True);ap.add_argument('--suffix',required=True);ap.add_argument('--positive-case',required=True);ap.add_argument('--plugin',type=Path,required=True);ap.add_argument('--plugin-sha256',required=True);ap.add_argument('--pinset-sha256',required=True);ap.add_argument('--plugin-manifest-sha256',required=True);ap.add_argument('--review',type=Path,required=True);ap.add_argument('--review-sha256',required=True);a=ap.parse_args()
 if not re.fullmatch('[a-z0-9][a-z0-9-]{0,39}',a.suffix) or not re.fullmatch('[a-z0-9_-]+',a.positive_case):raise SystemExit('Invalid case id/suffix')
 if any(not re.fullmatch('[0-9a-f]{64}',x) for x in (a.plugin_sha256,a.pinset_sha256,a.plugin_manifest_sha256,a.review_sha256)):raise SystemExit('Full SHA-256 required')
 head=git('rev-parse','HEAD');tree=git('rev-parse','HEAD^{tree}')
 if (head,tree)!=(a.admitted_head,a.admitted_tree) or git('symbolic-ref','--short','HEAD')!='codex/e02-unified-local-20261009' or git('status','--porcelain=v1','--untracked-files=no'):raise SystemExit('Branch/head/tree/clean tracked state not admitted')
 live=runpy.run_path(str(LAYER))['guard']()
 if live['head']!=head:raise SystemExit('Current root source frame unavailable')
 if shutil.disk_usage(R).free<8*1024**3:raise SystemExit('Disk below 8 GiB reserve')
 if not a.plugin.is_absolute() or not a.plugin.is_file() or not a.plugin.resolve().is_relative_to(R) or a.plugin.name!='c50_removal_plugin.py':raise SystemExit('Plugin must be canonical c50_removal_plugin.py at an existing absolute inside-root path')
 if sha(a.plugin)!=a.plugin_sha256:raise SystemExit('C50 plugin bytes mismatch')
 plugin_manifest=a.plugin.parent/'manifest.json'
 if sha(plugin_manifest)!=a.plugin_manifest_sha256:raise SystemExit('C50 plugin manifest bytes mismatch')
 pm=json.loads(plugin_manifest.read_text());sp=pm['source_test_pins']
 canonical=json.dumps(sp,sort_keys=True,separators=(',',':')).encode()
 if hashlib.sha256(canonical).hexdigest()!=a.pinset_sha256 or pm['source_test_pinset_sha256']!=a.pinset_sha256:raise SystemExit('C50 full pinset mismatch')
 if pm['packet_files']['c50_removal_plugin.py']['sha256']!=a.plugin_sha256:raise SystemExit('C50 plugin manifest binding mismatch')
 if pm['controls']['coverage_reconciliation']['nodes']!=[NODE]:raise SystemExit('C50 coverage selector differs')
 for relative,digest in sp.items():
  if not (P/relative).is_file() or sha(P/relative)!=digest:raise SystemExit('C50 plugin owner/test pin mismatch: '+relative)
 if not a.review.is_absolute() or not a.review.is_file() or not a.review.resolve().is_relative_to(R) or sha(a.review)!=a.review_sha256:raise SystemExit('Exact independently obtained source-review bytes must be present inside root')
 review_text=a.review.read_text()
 if a.plugin_sha256 not in review_text or a.plugin_manifest_sha256 not in review_text or 'coverage_reconciliation' not in review_text:raise SystemExit('Review text does not bind this exact plugin, manifest and coverage_reconciliation mode')
 # This is an integrity check only: root must independently inspect provenance and SOURCE GO.
 for f,v in PINS.items():
  if sha(f)!=v:raise SystemExit('Reviewed artifact mismatch: '+str(f))
 rows=[row for group in json.loads(MAN.read_text())['footprints'].values() for row in group];delta=json.loads(DELTA.read_text())['files'][0]
 for row in rows:
  expected=delta['postimage_sha256'] if row['path']==delta['path'] else row['post_sha256']
  if row['path']==delta['path'] and row['post_sha256']!=delta['preimage_sha256']:raise SystemExit('Import delta preimage mismatch')
  if sha(R/row['path'])!=expected:raise SystemExit('C50 reviewed postimage differs: '+row['path'])
 positive=D/a.positive_case;auditp=positive/'audit-result.json';xml=positive/'pytest.xml';freeze=positive/'source-profile-freeze.json'
 audit=json.loads(auditp.read_text());r=audit['result'];j=list(ET.parse(xml).iter('testcase'))
 actual={'tests':len(j),'failures':sum(c.find('failure') is not None for c in j),'errors':sum(c.find('error') is not None for c in j),'skipped':sum(c.find('skipped') is not None for c in j)}
 if not r['complete'] or r['return_code']!=0 or r.get('aborted_reason') or audit['current_mismatches'] or r.get('junit')!=actual or not actual['tests'] or any(actual[k] for k in ('failures','errors','skipped')):raise SystemExit('C50 positive is not a complete no-skip pass')
 if sha(freeze)!=audit['source_profile_freeze_sha256']:raise SystemExit('Positive freeze hash mismatch')
 frozen=json.loads(freeze.read_text()); prior_head=audit['plan']['source_head']
 if audit['plan']['nodes'] != PILOT_NODES or audit['plan'].get('extra_env') != {}:raise SystemExit('Positive is not the required exact eight-module native pilot')
 if audit['plan']['case_id']!=a.positive_case or frozen['before']['head']!=prior_head or audit['guard_after']['head']!=prior_head or frozen['before']['source_frame']!=audit['guard_after']['source_frame'] or frozen['before']['expected_index']!=audit['guard_after']['expected_index']:
  raise SystemExit('Positive actual plan/head/before-after source frame or index differs')
 if git('rev-parse',prior_head+'^{tree}')!=audit['plan']['source_tree']:raise SystemExit('Positive Git tree mismatch')
 bound=[]
 for rel,digest in frozen['selected_input_pins'].items():
  if digest!=frozen['plan_sha256']:continue
  candidate=R/rel
  if candidate.parent!=D or not candidate.is_file() or sha(candidate)!=digest:continue
  try:data=json.loads(candidate.read_text())
  except (ValueError,UnicodeError):continue
  if data==audit['plan']:bound.append(candidate)
 if len(bound)!=1:raise SystemExit('Positive concrete plan from freeze pins missing, mismatched or ambiguous')
 if subprocess.run(['git','merge-base','--is-ancestor',audit['plan']['source_head'],head],cwd=R).returncode:raise SystemExit('Positive source is not ancestor')
 if sum(c.get('classname')=='tests.unit.calibration.diagnostics.test_c50_receipt_consistency' and c.get('name')==FUNCTION for c in j)!=1:raise SystemExit('Chosen test was not actually passed once')
 actual_modules={c.get('classname','') for c in j}
 for selection in audit['plan']['nodes']:
  module=selection.split('::',1)[0].removesuffix('.py').replace('/','.')
  if not any(name==module or name.startswith(module+'.') for name in actual_modules):raise SystemExit('Positive selected module yielded no JUnit case: '+module)
 if not audit.get('readsets'):raise SystemExit('Positive imported readset missing')
 for row in audit['readsets']:
  source=R/row['path']
  if sha(source)!=row['sha256']:raise SystemExit('Positive readset bytes mismatch')
  for item in json.loads(source.read_text())['modules']:
   p=P/item['path']
   if not p.resolve().is_relative_to(P.resolve()):raise SystemExit('Positive readset path outside product root')
   rel=str(p.relative_to(R))
   if not p.is_file() or sha(p)!=item['sha256'] or hashlib.sha256(subprocess.check_output(['git','show',head+':'+rel],cwd=R)).hexdigest()!=item['sha256']:raise SystemExit('Positive imported source no longer matches current Git: '+rel)
 # Freeze all actual positive selected inputs, not just a caller-declared evidence list.
 for rel,digest in frozen['selected_input_pins'].items():
  if not (R/rel).is_file() or sha(R/rel)!=digest:raise SystemExit('Positive selected input changed: '+rel)
 fixed=['pytest.ini','pyproject.toml','uv.lock','src/polisyos/ir/api.py','src/polisyos/ir/analytics/__init__.py','src/polisyos/ir/governance/validation.py','src/polisyos/core/canon/canon_json.py']
 changed=git('diff','--name-only',audit['plan']['source_head'],head,'--','policy-engine/src/polisyos/core','policy-engine/src/polisyos/ir')
 paths={R/x['path'] for x in rows}|{P/x for x in fixed}|{P/x for x in sp}|{R/x for x in changed.splitlines() if x.endswith('.py')}
 ancestors=set();cur=(P/TEST).parent
 while cur.is_relative_to(P):ancestors.add(cur/'conftest.py');cur=cur.parent
 present={p for p in ancestors if p.exists() or p.is_symlink()};absent=sorted(str(p.relative_to(R)) for p in ancestors-present)
 for path in absent:
  if subprocess.run(['git','cat-file','-e',head+':'+path],cwd=R,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0:raise SystemExit('Missing committed pytest ancestor: '+path)
 pins={str(p.relative_to(R)):pin(p,head) for p in sorted(paths|present)}
 env=os.environ.copy()
 for n in ('PYTHONPATH','PYTEST_ADDOPTS','PYTEST_PLUGINS','PYTEST_DISABLE_PLUGIN_AUTOLOAD','PYTHONHOME','VIRTUAL_ENV'):env.pop(n,None)
 env['PYTHONDONTWRITEBYTECODE']='1';profile=json.loads(subprocess.check_output([str(P/'.venv/bin/python'),str(C59/'native_env.py')],cwd=R,env=env,text=True))
 guardfiles={str(LIVE.relative_to(R)):sha(LIVE),live['source_frame']['path']:live['source_frame']['sha256']}
 files={*PINS,HERE/'run_case.sh',HERE/'c50_child_profile.py',HERE/'prepare_plans.py',a.plugin,plugin_manifest,a.review,D/'readset_observer_tools_r1.py',SUP,LAYER,REVIEW,auditp,xml,freeze,positive/r['stdout_path'],positive/r['stderr_path'],bound[0]}|{R/row['path'] for row in audit['readsets']}|{R/rel for rel in frozen['selected_input_pins']}
 artifact={str(p.relative_to(R)):sha(p) for p in files};bind={'branch':'codex/e02-unified-local-20261009','committed_affected_inputs':pins,'native_python':profile,'absent_pytest_ancestor_conftests':absent,'artifact_pins':artifact,'guard_input_pins':guardfiles}
 plans=[]
 for phase in ('before','mutant','restored'):
  case='c50-coverage-'+a.suffix+'-'+phase;path=D/(case+'.json')
  if path.exists() or (D/case).exists():raise SystemExit('Existing plan or output: '+case)
  plugins='c59_collection_observer,c50_child_profile'+(',c50_removal_plugin' if phase=='mutant' else '')
  extra={'PYTHONPATH':os.pathsep.join([str(C59),str(HERE),str(a.plugin.parent),str(P/'src')]),'PYTEST_PLUGINS':plugins,'C59_COLLECTION_PLUGIN_SHA256':PINS[C59/'c59_collection_observer.py'],'C50_CHILD_PROFILE_SHA256':sha(HERE/'c50_child_profile.py'),'C50_SOURCE_HEAD':head,'C50_SOURCE_TREE':tree,'C50_OUTPUT':str(D/case),'C50_EXACT_NODE':NODE}
  if phase=='mutant':extra.update(POLISYOS_C50_CONTROL_MODE='coverage_reconciliation',POLISYOS_C50_CONTROL_PLUGIN_SHA256=a.plugin_sha256,POLISYOS_C50_CONTROL_PINSET_SHA256=a.pinset_sha256,POLISYOS_C50_CONTROL_SOURCE_HEAD=head,POLISYOS_C50_CONTROL_SOURCE_TREE=tree,POLISYOS_C50_CONTROL_SOURCE_FRAME_SHA256=live['source_frame']['sha256'],POLISYOS_C50_CONTROL_OUTPUT=str(D/case))
  plan={'case_id':case,'source_head':head,'source_tree':tree,'task_ids':['LA-052','PCL-01'],'nodes':[NODE],'extra_env':extra,'deadline_seconds':600,'rss_cap_bytes':2415919104,'source_rebind':bind,'root_manual_mode':'coverage_reconciliation','root_manual_phase':phase,'expected_junit_hypothesis':{'tests':1,'failures':int(phase=='mutant'),'errors':0,'skipped':0},'scope':'C50 actual report/adapter coverage reconciliation; exact same node and direct evidence review before/mutant/restored. Not a source-origin/G/closure proof.','closure_ids':[]}
  plans.append((path,plan))
 if git('rev-parse','HEAD')!=head or git('status','--porcelain=v1','--untracked-files=no'):raise SystemExit('Source moved; no plans written')
 runpy.run_path(str(LAYER))['guard']()
 for path,plan in plans:
  with path.open('x') as f:f.write(json.dumps(plan,indent=2,sort_keys=True)+'\n')
  if json.loads(path.read_text())!=plan:raise SystemExit('Plan readback mismatch')
 rec={'source_head':head,'source_tree':tree,'node':NODE,'positive_case':a.positive_case,'source_review':str(a.review),'source_review_sha256':sha(a.review),'source_review_identity_caveat':'Root must independently confirm actual reviewer, exact coverage mode, plugin/manifest hashes and bounded SOURCE GO; matching text alone is not authority.','plans':[{'path':str(p),'sha256':sha(p)} for p,_ in plans],'status':'PREPARED ONLY; root manual custody and independent semantic review required; runtime UNRUN'}
 out=HERE/('preparation-'+a.suffix+'.json')
 with out.open('x') as f:f.write(json.dumps(rec,indent=2)+'\n')
 print(json.dumps(rec,indent=2))

if __name__=='__main__':main()
