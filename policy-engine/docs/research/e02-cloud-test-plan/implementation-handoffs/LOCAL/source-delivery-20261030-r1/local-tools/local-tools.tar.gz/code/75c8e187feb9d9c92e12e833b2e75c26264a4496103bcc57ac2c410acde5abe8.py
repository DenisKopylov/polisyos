from pathlib import Path
import ast,hashlib,json,subprocess,difflib,tomllib
R=Path.cwd();O=Path(__file__).parent;m=json.loads((O/'manifest.pending.json').read_text());v=R/'policy-engine/.venv/bin/python';c=R/'policy-engine/architecture/tooling/ruff/workspace_root.toml';sha=lambda b:hashlib.sha256(b).hexdigest();checks=[]
for p in O.rglob('*.py'):
 if '/policy-engine/' not in str(p):continue
 rel=str(p.relative_to(O)).removeprefix('contexts/');before=p.read_bytes();ast.parse(before);z=subprocess.run([str(v),'-m','ruff','format','--config',str(c),'--stdin-filename',rel,'-'],input=before,capture_output=True);assert z.returncode==0;assert ast.dump(ast.parse(before),include_attributes=False)==ast.dump(ast.parse(z.stdout),include_attributes=False);p.write_bytes(z.stdout)
 for command in [('check',),('format','--check')]:
  q=subprocess.run([str(v),'-m','ruff',*command,'--config',str(c),'--stdin-filename',rel,'-'],input=p.read_bytes(),capture_output=True);checks.append({'path':rel,'command':list(command),'returncode':q.returncode,'stdout':q.stdout.decode(),'stderr':q.stderr.decode()});assert q.returncode==0,(rel,q.stdout,q.stderr)
patch=''
for row in m['files']:
 rel=row['path'];p=R/row['postimage_path'];b=p.read_bytes();old=subprocess.run(['git','show',m['base_commit']+':'+rel],capture_output=True);base=old.stdout if old.returncode==0 else None;assert (R/rel).read_bytes()==base if base is not None else not (R/rel).exists(),rel;row.update(postimage_sha256=sha(b),bytes=len(b));patch+='diff --git a/'+rel+' b/'+rel+'\n'+('new file mode 100644\n' if base is None else '');patch+=''.join(difflib.unified_diff((base or b'').decode().splitlines(keepends=True),b.decode().splitlines(keepends=True),fromfile='a/'+rel if base is not None else '/dev/null',tofile='b/'+rel))
 if rel.endswith('.toml'):tomllib.loads(b.decode())
(O/'base-to-proposal.patch').write_text(patch);q=subprocess.run(['git','apply','--check',str(O/'base-to-proposal.patch')],capture_output=True);assert q.returncode==0,q.stderr;checks.append({'command':['git','apply','--check','base-to-proposal.patch'],'returncode':q.returncode,'stdout':q.stdout.decode(),'stderr':q.stderr.decode()})
for row in m['context_companions']:
 rel=row['path'];desired=(O/'contexts'/rel).read_bytes();base=(R/rel).read_bytes();found_head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
 if sha(base)!=row['preimage_sha256']:
  base=None
  for head in subprocess.check_output(['git','rev-list','--max-count=80','HEAD','--',rel],text=True).splitlines():
   value=subprocess.check_output(['git','show',head+':'+rel])
   if sha(value)==row['preimage_sha256']:base=value;found_head=head;break
  assert base is not None,('exact saved context preimage unavailable',rel)
 context=''.join(difflib.unified_diff(base.decode().splitlines(keepends=True),desired.decode().splitlines(keepends=True),fromfile='a/'+rel,tofile='b/'+rel));p=R/row['context_patch'];p.write_text(context);row.update(candidate_postimage_sha256=sha(desired),patch_sha256=sha(context.encode()),source_preimage_commit=found_head,source_preimage_git_blob=subprocess.check_output(['git','rev-parse',found_head+':'+rel],text=True).strip());q=subprocess.run(['git','apply','--check',str(p)],capture_output=True);checks.append({'command':['git','apply','--check',p.name],'returncode':q.returncode,'stdout':q.stdout.decode(),'stderr':q.stderr.decode(),'scope':'current root context admission; root must requalify after other writer changes'});assert q.returncode==0,(rel,q.stderr)
# All changed Python/context files were checked; scratch plugins only syntax and source-shape.
plugins=[O/'c19_reader_removal_plugin.py'];
for p in plugins:ast.parse(p.read_text());compile(p.read_text(),str(p),'exec')
m['reader_removal_plugin']={'path':str(plugins[0].relative_to(R)),'sha256':sha(plugins[0].read_bytes()),'runtime':'UNRUN','modes':['codec','authority_band']};m['producer_removal_plugin']={'path':m['removal_plugin_path'],'sha256':m['removal_plugin_sha256'],'runtime':'UNRUN','modes':['executor_owner','no_write']}
test=R/next(x['postimage_path'] for x in m['files'] if x['path'].endswith('test_acquisition_data_preparation.py'));cases=[]
for f in ast.parse(test.read_text()).body:
 if isinstance(f,ast.FunctionDef) and f.name.startswith('test_'):
  variants=[{}]
  for d in f.decorator_list:
   if isinstance(d,ast.Call) and isinstance(d.func,ast.Attribute) and d.func.attr=='parametrize':variants=[{**a,ast.literal_eval(d.args[0]):b} for a in variants for b in ast.literal_eval(d.args[1])]
  cases.extend({'test':f.name,'parameters':x} for x in variants)
assert len(cases)==30,len(cases)
(O/'static-test-case-census.json').write_text(json.dumps({'method':'complete literal AST walk, no pytest collection/runtime','test_sha256':sha(test.read_bytes()),'count':len(cases),'cases':cases},indent=2)+'\n');m['static_case_census_sha256']=sha((O/'static-test-case-census.json').read_bytes());(O/'static-checks.json').write_text(json.dumps({'checks':checks,'runtime':'UNRUN'},indent=2)+'\n');m.update(head_observed=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),tree_observed=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),patch_sha256=sha(patch.encode()),static_checks_sha256=sha((O/'static-checks.json').read_bytes()),source_row_status='not_established in store-only reader; explicit candidate result plus WMR limitation; protected default and PCL refuse',runtime='UNRUN');(O/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({'manifest_sha256':sha((O/'manifest.json').read_bytes()),'patch_sha256':sha(patch.encode()),'postimages':len(m['files']),'context_companions':len(m['context_companions']),'expected_AST_cases':len(cases),'runtime':'UNRUN'},indent=2))
