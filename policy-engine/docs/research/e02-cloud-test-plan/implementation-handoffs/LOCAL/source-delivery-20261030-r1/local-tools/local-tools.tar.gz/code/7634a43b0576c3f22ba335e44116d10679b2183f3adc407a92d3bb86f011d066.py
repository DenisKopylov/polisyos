from pathlib import Path
root=Path('LOCAL/raw/e02-execution-20261027/repairs/C17-r3/postimages/policy-engine')
p=root/'src/polisyos/lex/legal_evaluation/impact_diff.py';s=p.read_text()
def change(old: str, new: str) -> None:
 global s
 assert s.count(old)==1,(s.count(old),old[:100]);s=s.replace(old,new)
change('''    def _compute_compliance_delta(
        self,
        old_issues: list[ComplianceIssue],
''','''    @staticmethod
    def _compute_compliance_delta(
        old_issues: list[ComplianceIssue],
''')
old='''    # These totals are derived from reported delta records only. Reconciliation
    # does not establish that the issue records, backend, or context are true or
    # complete; those inputs are not bound by this selected-view contract.
    deltas = report.compliance_deltas
    changed_norm_ids = set(recomputed.affected_norm_ids)
    for delta in deltas:
        if delta.transition in (
            ComplianceTransition.NEW_ISSUE,
            ComplianceTransition.RESOLVED_ISSUE,
        ):
            if delta.norm_id not in changed_norm_ids:
                raise ValueError("report_compliance_delta_norm_mismatch")
        elif delta.transition in (
            ComplianceTransition.PASS_TO_FAIL,
            ComplianceTransition.FAIL_TO_PASS,
        ):
            if delta.norm_id in changed_norm_ids:
                raise ValueError("report_compliance_delta_norm_mismatch")
    expected_totals = (
'''
new='''    # Replay the whole carried issue multiset through the producer's owner.
    # Unchanged issues are not present in deltas; therefore a successful replay
    # cannot establish a complete issue set, backend execution or input context.
    deltas = report.compliance_deltas
    old_issues = [delta.old_issue for delta in deltas if delta.old_issue is not None]
    new_issues = [delta.new_issue for delta in deltas if delta.new_issue is not None]
    if any(issue.pass_id not in passes for issue in (*old_issues, *new_issues)):
        raise ValueError("report_issue_pass_plan_mismatch")
    if NormImpactAnalyzer._compute_compliance_delta(old_issues, new_issues, recomputed) != deltas:
        raise ValueError("report_compliance_delta_inconsistent")
    for metadata_key, observed in (
        ("old_issues_total", len(old_issues)),
        ("new_issues_total", len(new_issues)),
    ):
        total = report.metadata.get(metadata_key)
        if type(total) is not int or total < observed:
            raise ValueError("report_issue_total_below_carried_issues")
    expected_totals = (
'''
change(old,new);p.write_text(s)

p=root/'tests/unit/remediation/test_lex_impact_semantics.py';s=p.read_text()
change('''from polisyos.ir.loading.norm_pack import NormPack, NormRule, RuleType
''','''from polisyos.core.contracts import ComplianceIssue, IssueSeverity
from polisyos.ir.loading.norm_pack import NormPack, NormRule, RuleType
''')
change('''        ("delta_transition", "report_compliance_delta_norm_mismatch"),
''','''        ("delta_transition", "report_compliance_delta_inconsistent"),
        ("delta_pass_id", "report_compliance_delta_inconsistent"),
        ("delta_fingerprint", "report_compliance_delta_inconsistent"),
        ("delta_norm_id", "report_compliance_delta_inconsistent"),
        ("delta_missing_issue", "report_compliance_delta_inconsistent"),
        ("delta_reordered", "report_compliance_delta_inconsistent"),
        ("issue_pass_not_run", "report_issue_pass_plan_mismatch"),
        ("old_issue_total", "report_issue_total_below_carried_issues"),
        ("new_issue_total", "report_issue_total_below_carried_issues"),
''')
change('''    elif field == "delta_transition":
        delta = next(d for d in payload["compliance_deltas"] if d["transition"] == "new_issue")
        delta["transition"] = "pass_to_fail"
    elif field == "passes_executed":
''','''    elif field == "delta_transition":
        delta = next(d for d in payload["compliance_deltas"] if d["transition"] == "new_issue")
        delta["transition"] = "pass_to_fail"
    elif field == "delta_pass_id":
        payload["compliance_deltas"][0]["pass_id"] = "safety"
    elif field == "delta_fingerprint":
        payload["compliance_deltas"][0]["fingerprint"] = "counterfeit"
    elif field == "delta_norm_id":
        payload["compliance_deltas"][0]["norm_id"] = "n.counterfeit"
    elif field == "delta_missing_issue":
        delta = payload["compliance_deltas"][0]
        delta["old_issue"] = None
        delta["new_issue"] = None
    elif field == "delta_reordered":
        payload["compliance_deltas"].reverse()
    elif field == "issue_pass_not_run":
        delta = payload["compliance_deltas"][0]
        delta["pass_id"] = "safety"
        for issue in (delta["old_issue"], delta["new_issue"]):
            if issue is not None:
                issue["pass_id"] = "safety"
    elif field == "old_issue_total":
        payload["metadata"]["old_issues_total"] = 0
    elif field == "new_issue_total":
        payload["metadata"]["new_issues_total"] = 0
    elif field == "passes_executed":
''')
insert='''def test_selected_issue_replay_preserves_omitted_unchanged_pairs(tmp_path: Path) -> None:
    """Replaying carried issues preserves a severity change amid matching pairs.

    This intentionally uses a synthetic backend to exercise multiset pairing;
    the independent expr_ast fixture supplies the actual legal-backend positive.
    """
    class MixedIssueBackend:
        def evaluate(
            self, norm_pack: NormPack | None, context: dict[str, object]
        ) -> list[ComplianceIssue]:
            assert norm_pack is not None
            severities = (
                [IssueSeverity.BLOCKER, IssueSeverity.WARNING, IssueSeverity.WARNING]
                if norm_pack.pack_id == "pack.old"
                else [IssueSeverity.BLOCKER, IssueSeverity.BLOCKER, IssueSeverity.WARNING]
            )
            return [
                ComplianceIssue(
                    pass_id="backend-provided-label",
                    path=["norm_pack", "n.modified"],
                    message="same issue key",
                    severity=severity,
                    code="MULTISET",
                )
                for severity in severities
            ]

    cas = FileSystemCAS(tmp_path / "cas")
    produced = NormImpactAnalyzer(
        cas, passes=("legal",), legal_backend=MixedIssueBackend(), report_schema_version="1.1"
    ).analyze(*_packs())
    assert produced.cas_artifact_ref is not None
    read = load_norm_impact_report(FileSystemCAS(cas.root), produced.cas_artifact_ref)
    assert read.diff_binding == "exact_selected"
    assert read.report.metadata["old_issues_total"] == 3
    assert read.report.metadata["new_issues_total"] == 3
    assert len(read.report.compliance_deltas) == 1
    delta = read.report.compliance_deltas[0]
    assert delta.transition == ComplianceTransition.SEVERITY_CHANGE
    assert delta.pass_id == "legal"  # LegalPass normalizes a custom backend's label.
    assert delta.old_issue is not None and delta.old_issue.severity == IssueSeverity.WARNING
    assert delta.new_issue is not None and delta.new_issue.severity == IssueSeverity.BLOCKER
    assert read.report.metadata["legal_evaluation_scope"] == "backend_semantics_not_established"


'''
change('def test_selected_report_refuses_incoherent_embedded_diff(',insert+'def test_selected_report_refuses_incoherent_embedded_diff(')
p.write_text(s)
print('Added complete replay of carried issues and independent falsifier variants')
