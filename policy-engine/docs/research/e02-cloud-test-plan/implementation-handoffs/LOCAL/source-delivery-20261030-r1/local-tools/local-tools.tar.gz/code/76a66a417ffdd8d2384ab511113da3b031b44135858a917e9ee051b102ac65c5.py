from pathlib import Path
import subprocess, ast
ROOT=Path.cwd(); OUT=ROOT/'LOCAL/raw/e02-execution-20261027/repairs/C38-tests-r1'
TREE='4396ab7ed42ebcd0aad742ac1f402ffcbccd0c65'
p='policy-engine/tests/unit/runtime/quality/test_authority.py'
s=subprocess.check_output(['git','show',f'{TREE}:{p}']).decode()
s=s.replace('    SameInputClosure,\n','    SameInputClosure,\n    SealedConsumedInputSet,\n',1)
start=s.index('def test_consumed_input_set_seals_sorted_membership_and_closure_identity()')
end=s.index('\n\n@pytest.mark.parametrize(\n    "field",',start)
s=s[:start]+'''@pytest.mark.parametrize(
    "predicate_class",
    ["recomputed", "independently_reconciled", "consumer_asserted",
     "institutionally_supplied", "not_established"],
)
def test_legacy_seal_refuses_declared_predicates_before_new_authority(
    predicate_class: str,
) -> None:
    """A declared resolved string cannot manufacture a new consumed-input seal."""
    with pytest.raises(AuthorityEnvelopeError, match="legacy_not_authoritative"):
        seal_consumed_input_set(
            closure=_closed_input_closure(),
            members=[_consumed_member("runtime", predicate_class=predicate_class)],
        )


@pytest.mark.parametrize("variant", ["valid", "unresolved", "substituted", "duplicate"])
def test_legacy_seal_refusal_is_not_conditional_on_member_shape(variant: str) -> None:
    member = _consumed_member("source")
    members = [member]
    if variant == "unresolved":
        members = [member.model_copy(update={"resolved_identity": None})]
    elif variant == "substituted":
        members = [member.model_copy(update={"resolved_identity": "sha256:other"})]
    elif variant == "duplicate":
        members.append(member)
    with pytest.raises(AuthorityEnvelopeError, match="legacy_not_authoritative"):
        seal_consumed_input_set(closure=_closed_input_closure(), members=members)


def test_parsed_legacy_seal_stays_readable_but_cannot_authorize_reuse() -> None:
    # This is a historical wire fixture, not a new authority admission. Compute
    # its content digest with the documented legacy canonical projection solely
    # to exercise the actual decoder and protected reuse boundary.
    from polisyos.core import canon

    closure = _closed_input_closure()
    member = _consumed_member("source")
    payload = {
        "same_input_closure": closure.model_dump(mode="json"),
        "members": [member.model_dump(mode="json")],
        "membership_sha256": canon.fingerprint(
            {"same_input_closure": closure.identity_tuple(),
             "members": [member.model_dump(mode="json")]},
            prefix=True,
        ),
    }
    sealed = SealedConsumedInputSet.model_validate_json(json.dumps(payload))
    assert sealed.same_input_closure == closure
    for fresh_members in ([member], [], [member, member]):
        with pytest.raises(AuthorityEnvelopeError, match="legacy_not_authoritative"):
            assert_consumed_input_reuse(
                sealed, closure=closure, fresh_members=fresh_members,
            )


def test_runtime_envelope_round_trips_as_legacy_without_new_authority() -> None:
    envelope = deserialize_authority_envelope(_valid_payload())
    assert isinstance(envelope, EvidenceAuthorityEnvelope)
    assert envelope.producer_identity == ProducerIdentity(
        component="polisyos.lex.normpack.applicability_report",
        version="2026.05.14+hds-phase02",
        owner="team-runtime-quality",
    )
    assert classify_authority_role(envelope) == "not_authoritative"
    for consumer in (assert_authority_bearing, assert_runtime_emitted):
        with pytest.raises(AuthorityEnvelopeError, match="legacy_not_authoritative"):
            consumer(envelope)
    with pytest.raises(AuthorityEnvelopeError, match="legacy_not_authoritative"):
        assert_same_input_closure([envelope, deserialize_authority_envelope(_valid_payload())])
    assert assert_same_input_closure(
        [envelope, deserialize_authority_envelope(_valid_payload())],
        historical_advisory=True,
    ) == envelope.same_input_closure
    encoded = serialize_authority_envelope(envelope)
    assert deserialize_authority_envelope(encoded) == envelope
''' + s[end:]
s=s.replace('def test_runtime_emitted_envelope_rejects_runtime_ref_mismatch() -> None:', 'def test_runtime_ref_tampering_cannot_promote_legacy_evidence() -> None:',1)
s=s.replace('with pytest.raises(AuthorityEnvelopeError, match="authority_runtime_ref_mismatch"):', 'with pytest.raises(AuthorityEnvelopeError, match="legacy_not_authoritative"):',1)
# Historical equality still checks mismatch, under the explicit advisory opt-in.
needle='''                deserialize_authority_envelope(mismatched_payload),
            ]
        )
'''
assert needle in s
s=s.replace(needle,'''                deserialize_authority_envelope(mismatched_payload),
            ],
            historical_advisory=True,
        )
''',1)
f=OUT/'postimages'/p; f.parent.mkdir(parents=True,exist_ok=True); f.write_text(s)
print('Prepared cloud authority-test migration; historical reads remain distinct from protected grants.')
