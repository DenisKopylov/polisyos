"""Proposed behavioral tests for the future SQL Ex-Ante Debug source-use reader.

RAW test source only; deliberately not collected or run from LOCAL/raw. The
fixture must invoke the real SQL producer, C105 owner, Foundry graph and
Runtime Debug route. It may not hand-author basis, execution, or witness CAS
artifacts.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Protocol

import pytest

pytestmark = pytest.mark.integration


class SQLExAnteDebugRun(Protocol):
    run_id: str
    node_alias: str
    simulation_result_ref: dict[str, Any]
    execution_input_basis_ref: dict[str, Any]
    method_execution_bundle_ref: dict[str, Any]
    input_capture_ref: dict[str, Any]
    source_carrier: dict[str, Any]
    source_admission_ref: dict[str, Any]
    data_snapshot_ref: dict[str, Any]
    input_bindings_ref: dict[str, Any]
    bound_state_snapshot_ref: dict[str, Any]
    use_contract_ref: dict[str, Any]


class SQLExAnteDebugHarness(Protocol):
    run_a: SQLExAnteDebugRun
    run_i: SQLExAnteDebugRun

    def get_debug(self, run: SQLExAnteDebugRun, *, artifact_id: str | None = None): ...

    def prove_live_source_to_dispatch(self, run: SQLExAnteDebugRun) -> dict[str, Any]: ...

    def actual_c105_current_use(self, run: SQLExAnteDebugRun) -> dict[str, Any]: ...

    def resolve_selected_use_contract(self, run: SQLExAnteDebugRun) -> dict[str, Any]: ...

    def admit_later_carrier_without_withdrawing_a(
        self, run: SQLExAnteDebugRun
    ) -> dict[str, Any]: ...

    def is_selected_carrier(self, carrier: dict[str, Any]) -> bool: ...

    def withdraw_a(self) -> None: ...

    def replace_a_with_b(self) -> SQLExAnteDebugRun: ...

    def read_event_history(self, run: SQLExAnteDebugRun) -> dict[str, Any]: ...

    def mutate_selected_execution(self, run: SQLExAnteDebugRun, mutation: str) -> None: ...

    def monkeypatch_exante_hidden_global_same_scalar(self) -> None:
        """Patch after import and before execution; preserve scalar and class source."""
        ...

    def execute_new_sql_a_run(self) -> SQLExAnteDebugRun: ...

    def remove_only_runtime_property(self, property_name: str) -> None: ...


@pytest.fixture
def sql_exante_debug_harness(tmp_path: Path) -> SQLExAnteDebugHarness:
    """Root integration fixture contract. It is not present at the pinned base."""
    raise NotImplementedError(
        "Requires Foundry actual-call witness owner/verifier and Debug source-use route"
    )


def _view(response) -> dict[str, Any]:
    assert response.status_code == 200, response.text
    return response.json()["debug"]


def _assert_linked_unknown(view: dict[str, Any]) -> None:
    linked = view["exante_source_use"]
    assert linked["status"] == "unknown"
    assert linked["method_replay_status"] in {"verification_missing", "invalid"}
    assert linked.get("recomputed_mean_change") is None


def _assert_linked_current(view: dict[str, Any]) -> None:
    linked = view["exante_source_use"]
    assert linked["status"] == "current"
    assert linked["method_replay_status"] == "verified"
    assert linked["recomputed_mean_change"] == 1.0


def test_missing_selected_call_witness_never_links_c105_current(
    sql_exante_debug_harness: SQLExAnteDebugHarness,
) -> None:
    """Class source, ABI and dispatch markers do not prove the executed callable."""
    harness = sql_exante_debug_harness
    run = harness.run_a
    harness.mutate_selected_execution(run, "method_call_witness_missing")
    owner_fact = harness.actual_c105_current_use(run)
    assert owner_fact["status"] == "current"
    assert harness.resolve_selected_use_contract(run)["selection_mode"] == "any_active"

    view = _view(harness.get_debug(run))
    _assert_linked_unknown(view)
    assert "actual_exante_call_witness_not_established" in view["exante_source_use"][
        "limitations"
    ]
    assert view["exante_source_use"].get("owner_current_use", {}).get("status") == "current"
    assert view["exante_source_use"]["status"] != "current"


def test_verified_profile_positive_and_default_exact_refs_are_identical(
    sql_exante_debug_harness: SQLExAnteDebugHarness,
) -> None:
    """Acceptance after the immutable Foundry allowlist profile is implemented."""
    harness = sql_exante_debug_harness
    run = harness.run_a
    source = harness.prove_live_source_to_dispatch(run)
    basis = source["execution_input_basis"]
    assert basis["authority_purpose"] == "execution_input_identity_only"
    assert basis["data_snapshot_ref"] == run.data_snapshot_ref
    assert basis["input_bindings_ref"] == run.input_bindings_ref
    assert basis["registered_sql_admission_ref"] == run.source_admission_ref
    assert basis["bound_state_snapshot_ref"] == run.bound_state_snapshot_ref
    assert source["actual_basis_manifest_inputs"] == source["recomputed_basis_manifest_inputs"]
    assert source["ordered_binding_rules"] == [
        {"binding_id": "baseline", "source_path": "baseline", "target_slot_id": "baseline"},
        {"binding_id": "scenario", "source_path": "scenario", "target_slot_id": "scenario"},
    ]
    assert source["method_inputs"] == {"baseline": [10.0, 20.0, 40.0], "scenario": [11.0, 18.0, 44.0]}
    assert source["method_input_reads"] == ["baseline", "scenario"]
    assert source["method_parameter_reads"] == ["poverty_line"]
    default_response = harness.get_debug(run)
    exact_response = harness.get_debug(
        run,
        artifact_id=run.simulation_result_ref["artifact_id"],
    )
    default = _view(default_response)
    exact = _view(exact_response)

    assert default["artifact_ref"] == exact["artifact_ref"] == run.simulation_result_ref
    assert default["exante_source_use"] == exact["exante_source_use"]
    linked = default["exante_source_use"]
    assert linked["method_replay_status"] == "verified"
    assert linked["status"] == "current"
    assert linked["recomputed_mean_change"] == 1.0
    assert linked["basis_ref"] == run.execution_input_basis_ref
    assert default_response.headers["cache-control"] == "no-store"
    assert exact_response.headers["cache-control"] == "no-store"


def test_hidden_global_same_scalar_mutation_is_not_admitted_by_profile(
    sql_exante_debug_harness: SQLExAnteDebugHarness,
) -> None:
    harness = sql_exante_debug_harness
    harness.monkeypatch_exante_hidden_global_same_scalar()
    run = harness.execute_new_sql_a_run()

    view = _view(harness.get_debug(run))
    _assert_linked_unknown(view)


def test_any_active_contract_derives_require_selected_false(
    sql_exante_debug_harness: SQLExAnteDebugHarness,
) -> None:
    harness = sql_exante_debug_harness
    run = harness.run_a
    contract = harness.resolve_selected_use_contract(run)
    assert contract["selection_mode"] == "any_active"

    later = harness.admit_later_carrier_without_withdrawing_a(run)
    assert harness.is_selected_carrier(run.source_carrier) is False
    assert harness.is_selected_carrier(later) is True

    owner_fact = harness.actual_c105_current_use(run)
    assert owner_fact["status"] == "current"
    assert owner_fact["selection_checked"] is False


def test_withdrawal_is_a_fresh_get_and_independent_i_stays_current(
    sql_exante_debug_harness: SQLExAnteDebugHarness,
) -> None:
    """Linked withdrawn/current assertions require the verified call profile."""
    harness = sql_exante_debug_harness
    run_a, run_i = harness.run_a, harness.run_i
    history_before = harness.read_event_history(run_a)

    a_before = _view(harness.get_debug(run_a))["exante_source_use"]
    i_before = _view(harness.get_debug(run_i))["exante_source_use"]
    assert a_before["method_replay_status"] == i_before["method_replay_status"] == "verified"
    assert a_before["status"] == i_before["status"] == "current"

    harness.withdraw_a()

    a_after = _view(harness.get_debug(run_a))["exante_source_use"]
    i_after = _view(harness.get_debug(run_i))["exante_source_use"]
    assert a_after["status"] == "withdrawn"
    assert i_after["status"] == "current"
    assert harness.read_event_history(run_a) == history_before


def test_a_after_b_is_a_separate_run_and_old_a_is_not_selectable(
    sql_exante_debug_harness: SQLExAnteDebugHarness,
) -> None:
    harness = sql_exante_debug_harness
    run_a = harness.run_a
    before = harness.read_event_history(run_a)
    run_b = harness.replace_a_with_b()

    # SQL B is a new real execution/run, never an A+B composite or
    # a request-selected basis.
    assert run_b.run_id != run_a.run_id
    assert run_b.data_snapshot_ref != run_a.data_snapshot_ref
    assert harness.actual_c105_current_use(run_a)["status"] == "withdrawn"
    assert harness.actual_c105_current_use(run_b)["status"] == "current"
    b = _view(harness.get_debug(run_b))["exante_source_use"]
    assert b["status"] == "current"
    assert harness.read_event_history(run_a) == before
    old_a = harness.get_debug(
        run_b,
        artifact_id=run_a.simulation_result_ref["artifact_id"],
    )
    assert old_a.status_code == 409


@pytest.mark.parametrize(
    "mutation",
    [
        "execution_basis_missing",
        "execution_basis_profile_missing",
        "execution_basis_inventory_missing",
        "execution_basis_inventory_reordered",
        "execution_basis_inventory_duplicate",
        "execution_basis_fake_carrier",
        "registered_sql_admission_ref_substituted",
        "method_call_witness_missing",
        "method_call_witness_forged",
        "input_bindings_snapshot_mismatch",
        "receipt_materialization_snapshot_mismatch",
        "input_capture_profile_missing",
        "input_capture_values_differ_from_sql_snapshot",
        "duplicate_exante_occurrence",
        "extra_method_or_intervention",
        "method_callable_profile_mismatch",
        "runner_profile_mismatch",
        "postprocessor_profile_mismatch",
        "parameter_default_not_none",
        "output_ref_or_path_mismatch",
        "wrong_tenant_cell_or_scope",
        "prior_run_result_ref",
        "unsupported_use_contract_mode",
        "substituted_use_contract_ref",
    ],
)
def test_selected_basis_and_executable_profile_mutations_fail_closed(
    sql_exante_debug_harness: SQLExAnteDebugHarness,
    mutation: str,
) -> None:
    harness = sql_exante_debug_harness
    harness.mutate_selected_execution(harness.run_a, mutation)
    _assert_linked_unknown(_view(harness.get_debug(harness.run_a)))


@pytest.mark.parametrize(
    "property_name",
    [
        "foundry_live_callable_profile_recompute",
        "bounded_execution_source_admission",
        "registered_exante_mean_change_replay",
        "fresh_c105_current_use_read",
        "debug_owner_reselection_after_read",
        "debug_no_store_header",
    ],
)
def test_remove_one_live_property_keep_all_artifact_markers_fails(
    sql_exante_debug_harness: SQLExAnteDebugHarness,
    property_name: str,
) -> None:
    """P29 control: each deletion must invalidate the associated behavioral assertion."""
    harness = sql_exante_debug_harness
    baseline = harness.get_debug(harness.run_a)
    _assert_linked_current(_view(baseline))
    assert baseline.headers["cache-control"] == "no-store"

    harness.remove_only_runtime_property(property_name)
    response = harness.get_debug(harness.run_a)
    if property_name == "debug_no_store_header":
        with pytest.raises(AssertionError):
            assert response.headers["cache-control"] == "no-store"
        return
    with pytest.raises(AssertionError):
        _assert_linked_current(_view(response))
