"""Build a source-bound review patch from RAW postimages; no product imports."""
from __future__ import annotations

import difflib
import hashlib
import json
import subprocess
from pathlib import Path

repo = Path.cwd()
raw = repo / "LOCAL/raw/e02-execution-20261027/runtime-prep/R144-basis-consistency-proposal-r3"
postroot = raw / "postimages"
base = "4ccfa564f925d048f3c46dc0069ffcbfe028a13a"
head = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
tree = subprocess.check_output(["git", "rev-parse", "HEAD^{tree}"], text=True).strip()
journal = json.loads((repo / "LOCAL/raw/root-live-ownership-20261021.json").read_text())
if journal.get("head") != head:
    raise RuntimeError("root ownership journal does not match HEAD")
postimages = sorted(path for path in postroot.rglob("*") if path.is_file())
paths = [str(path.relative_to(postroot)) for path in postimages]
intersection = subprocess.check_output(
    ["git", "diff", "--name-only", base, head, "--", *paths], text=True
).splitlines()
if intersection:
    raise RuntimeError(f"unexpected source overlap since base: {intersection}")
rows = []
patch = []
for postimage, path in zip(postimages, paths, strict=True):
    source = repo / path
    before = source.read_bytes() if source.exists() else b""
    after = postimage.read_bytes()
    if before == after:
        raise RuntimeError(f"unchanged postimage {path}")
    if source.exists():
        tracked = subprocess.run(["git", "show", f"{head}:{path}"], capture_output=True, check=True).stdout
        if before != tracked:
            raise RuntimeError(f"working tree differs from bound HEAD: {path}")
        old_name = f"a/{path}"
    else:
        old_name = "/dev/null"
    new_name = f"b/{path}"
    patch.append(f"diff --git a/{path} b/{path}\n")
    if not source.exists():
        patch.append("new file mode 100644\n")
    patch.extend(difflib.unified_diff(
        before.decode().splitlines(keepends=True),
        after.decode().splitlines(keepends=True),
        fromfile=old_name,
        tofile=new_name,
        n=3,
    ))
    rows.append({
        "path": path,
        "preimage_sha256": hashlib.sha256(before).hexdigest() if source.exists() else None,
        "postimage_sha256": hashlib.sha256(after).hexdigest(),
    })
patch_file = raw / "proposal.patch"
patch_file.write_text("".join(patch))
check = subprocess.run(["git", "apply", "--check", str(patch_file)], cwd=repo, capture_output=True)
receipt = {
    "argv": ["git", "apply", "--check", str(patch_file)],
    "cwd": str(repo),
    "exit_code": check.returncode,
    "stdout": check.stdout.decode(errors="replace"),
    "stderr": check.stderr.decode(errors="replace"),
}
(raw / "patch-apply-check.json").write_text(json.dumps(receipt, indent=2) + "\n")
manifest = {
    "status": "unreviewed RAW proposal; no product imports or semantic execution",
    "base": base,
    "journaled_head": head,
    "journaled_tree": tree,
    "journal_path": "LOCAL/raw/root-live-ownership-20261021.json",
    "path_intersection_since_base": intersection,
    "postimages": rows,
    "patch_sha256": hashlib.sha256(patch_file.read_bytes()).hexdigest(),
    "patch_apply_check_exit_code": check.returncode,
}
(raw / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps(manifest, indent=2))
if check.returncode:
    raise SystemExit(check.returncode)
