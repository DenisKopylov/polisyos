from pathlib import Path
import subprocess

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
BASE = 'fe8f75e6ff2580879ecd5c4ca42c370a3fd82694'
OUT = ROOT / 'LOCAL/raw/e02-execution-20261027/repairs/N7-fetch-owner-fixture-r1/postimages'


def change(source, old, new):
    count = source.count(old)
    if count != 1:
        raise RuntimeError(f'expected one occurrence, found {count}: {old[:100]!r}')
    return source.replace(old, new, 1)


def read_base(path):
    return subprocess.check_output(['git', 'show', f'{BASE}:{path}'], cwd=ROOT).decode()


fabric_path = 'policy-engine/tests/unit/fabric/test_retrieval_fetch_custody.py'
fabric = read_base(fabric_path)
fabric = change(fabric,
    'def build_worldbank_fetch_owner(tmp_path, *, artifact_store=None):\n',
    'def build_worldbank_fetch_owner(tmp_path, *, artifact_store=None, published_catalog=False):\n')
fabric = change(fabric,
    '    Publisher currentness is witnessed separately through the complete catalog fixture.\n    The USA/DEU GDP identities in the recorded HTTP payload remain unchanged.\n',
    '    When requested, publish the same normalized record through the complete\n    catalog producer before real selection. Otherwise this is a graph-only\n    transport fixture, with no claim of publisher currentness.\n')
fabric = change(fabric,
    '            owner.catalog_record = record\n            yield owner\n',
    '''            owner.catalog_record = record
            if not published_catalog:
                yield owner
                return

            # The publisher fixture controls its own harvest edges. Restore the
            # actual World Bank methods before the selected plan is executed;
            # the outer context still controls only the recorded HTTP exchange.
            actual_fetch = WorldBankConnector.fetch
            actual_describe_dataset = WorldBankConnector.describe_dataset
            published_root = tmp_path / "published-catalog"
            published_root.mkdir()
            with pytest.MonkeyPatch.context() as publisher_patch:
                published = _build_full_published_catalog_fixture(
                    published_root, publisher_patch, additional_records=(record,)
                )
                try:
                    publisher_patch.setattr(WorldBankConnector, "fetch", actual_fetch)
                    publisher_patch.setattr(
                        WorldBankConnector, "describe_dataset", actual_describe_dataset
                    )
                    owner.graph = published.producer_graph
                    owner.graph_path = published.database_path
                    owner.published = published
                    owner.service = RetrievalService(
                        curated_dir=tmp_path / "empty-curated",
                        artifact_store=owner.store,
                        dataset_catalog=owner.graph,
                        providers=providers,
                    )
                    if owner.graph.bind_fetch_target(
                        metric_id=owner.plan.metric_id,
                        connector_id=owner.plan.connector_id,
                        request_dataset_id=owner.plan.dataset_id,
                        profile_id=owner.plan.profile_id,
                        filters=owner.plan.filters,
                    ) is None:
                        raise AssertionError("published_worldbank_plan_not_bound_by_catalog")
                    yield owner
                finally:
                    try:
                        published.producer_graph.close()
                    finally:
                        published.close()
''')
fabric = change(fabric,
    'def _build_full_published_catalog_fixture(tmp_path, monkeypatch):\n',
    'def _build_full_published_catalog_fixture(tmp_path, monkeypatch, *, additional_records=()):\n')
fabric = change(fabric,
    '    spec.loader.exec_module(module)\n    return module.build_published_catalog_fixture(tmp_path, monkeypatch)\n',
    '''    spec.loader.exec_module(module)
    if additional_records:
        graph_records = module._graph_records

        def with_additional_records(base_url, registry_entries):
            return [*graph_records(base_url, registry_entries), *additional_records]

        monkeypatch.setattr(module, "_graph_records", with_additional_records)
    return module.build_published_catalog_fixture(tmp_path, monkeypatch)
''')
anchor = 'def test_worldbank_fetch_owner_persists_into_the_supplied_cas(tmp_path: Path) -> None:\n'
negative = '''def test_worldbank_unpublished_graph_refuses_selection_before_transport(tmp_path: Path) -> None:
    """A bound graph alone cannot stand in for its publisher's current receipt."""
    store = FileSystemCAS(tmp_path / "selected-cas")
    with build_worldbank_fetch_owner(tmp_path / "capture", artifact_store=store) as owner:
        before = set(store.iter_artifact_ids())
        resolved = owner.service.resolve(
            DataResolveRequest(
                data_needs=[DataNeed(metric=owner.plan.metric_id)],
                mode="fastlane",
                catalog_run_profile="prod_full",
            )
        )
        assert not resolved.fetch_plans
        assert "catalog_source_not_established:unmatched_batch_database" in resolved.warnings
        assert not owner.http_requests
        assert set(store.iter_artifact_ids()) == before


'''
fabric = change(fabric, anchor, negative + anchor)
old_positive = '''    with build_worldbank_fetch_owner(tmp_path / "capture", artifact_store=store) as owner:
        assert owner.store is store
        resolved = owner.service.resolve(
            DataResolveRequest(
                data_needs=[DataNeed(metric=owner.plan.metric_id)],
                mode="fastlane",
                catalog_run_profile="prod_full",
            )
        )
        result = owner.service.execute_fetch_plans(
            list(resolved.fetch_plans), persist_payload=True, allow_fallback=False
        )
        assert len(result.previews) == 1
        preview = result.previews[0]
        assert preview.fetch_receipt_ref is not None
        assert preview.metric.payload_ref is not None
        assert store.get_bytes(preview.fetch_receipt_ref)
        assert store.get_bytes(preview.metric.payload_ref)
'''
new_positive = '''    from polisyos.fabric.retrieval.custody import resolve_persisted_fetch

    with build_worldbank_fetch_owner(
        tmp_path / "capture", artifact_store=store, published_catalog=True
    ) as owner:
        assert owner.store is store
        assert owner.published.report_basis_state == "current"
        assert owner.published.publish_receipt_state == "current"
        assert owner.published.readiness["consumer_ready"] is True
        request = DataResolveRequest(
            data_needs=[DataNeed(metric=owner.plan.metric_id)],
            mode="fastlane",
            catalog_run_profile="prod_full",
        )
        resolved = owner.service.resolve(request)
        assert len(resolved.fetch_plans) == 1, (resolved.warnings, resolved.candidates)
        assert len(resolved.candidates) == 1
        candidate = resolved.candidates[0]
        assert candidate.metadata["source_currentness"] == "current"
        assert candidate.metadata["plan_admission_reason"] == "catalog_profile_inputs_covered"
        plan = resolved.fetch_plans[0]
        assert (plan.metric_id, plan.connector_id, plan.dataset_id, plan.profile_id, plan.filters) == (
            owner.plan.metric_id,
            owner.plan.connector_id,
            owner.plan.dataset_id,
            owner.plan.profile_id,
            owner.plan.filters,
        )
        assert not owner.http_requests

        # Remove the actual producer lineage, keeping the catalog graph and
        # selected target intact: real resolve must then refuse a fetch plan.
        stage_path = owner.published.snapshot_root / "datasets/manifests/stage_state.json"
        original_stage = stage_path.read_bytes()
        try:
            stage_path.write_bytes(b"{}")
            refused = owner.service.resolve(request)
            assert not refused.fetch_plans
            assert refused.warnings
            assert not owner.http_requests
        finally:
            stage_path.write_bytes(original_stage)
        restored = owner.service.resolve(request)
        assert len(restored.fetch_plans) == 1, (restored.warnings, restored.candidates)
        assert restored.fetch_plans[0] == plan

        result = owner.service.execute_fetch_plans(
            list(restored.fetch_plans), persist_payload=True, allow_fallback=False
        )
        assert len(result.previews) == 1
        preview = result.previews[0]
        assert preview.fetch_receipt_ref is not None
        assert preview.metric is not None
        assert preview.metric.payload_ref is not None
        assert store.get_bytes(preview.fetch_receipt_ref)
        assert store.get_bytes(preview.metric.payload_ref)
        replay = resolve_persisted_fetch(
            store=store,
            fetch_receipt_ref=preview.fetch_receipt_ref,
            catalog=owner.graph,
            providers=owner.providers,
        )
        assert replay.source_agreement == "recomputed"
        pd.testing.assert_frame_equal(replay.result.data, owner.frame)
        pd.testing.assert_frame_equal(replay.replayed_result.data, owner.frame)
'''
fabric = change(fabric, old_positive, new_positive)
(OUT / fabric_path).write_text(fabric)

acq_path = 'policy-engine/tests/unit/remediation/test_acq_01.py'
acq = read_base(acq_path)
acq = change(acq,
    '    with build_worldbank_fetch_owner(capture_root, artifact_store=artifact_store) as owner:\n',
    '''    with build_worldbank_fetch_owner(
        capture_root, artifact_store=artifact_store, published_catalog=True
    ) as owner:
''')
acq = change(acq,
    '''        execution = owner.service.execute_fetch_plans(
            list(resolved.fetch_plans),
            persist_payload=True,
            allow_fallback=False,
        )
        preview = execution.previews[0]
        assert preview.fetch_receipt_ref is not None
        assert preview.metric.payload_ref is not None

        catalog_binding = owner.graph.bind_fetch_target(
            metric_id=owner.plan.metric_id,
            connector_id=preview.metric.connector_id,
            request_dataset_id=preview.metric.dataset_id,
            profile_id=owner.plan.profile_id,
            filters=owner.plan.filters,
        )
''',
    '''        assert len(resolved.fetch_plans) == 1, (resolved.warnings, resolved.candidates)
        plan = resolved.fetch_plans[0]
        assert (plan.metric_id, plan.connector_id, plan.dataset_id, plan.profile_id, plan.filters) == (
            owner.plan.metric_id,
            owner.plan.connector_id,
            owner.plan.dataset_id,
            owner.plan.profile_id,
            owner.plan.filters,
        )
        execution = owner.service.execute_fetch_plans(
            [plan],
            persist_payload=True,
            allow_fallback=False,
        )
        assert len(execution.previews) == 1
        preview = execution.previews[0]
        assert preview.fetch_receipt_ref is not None
        assert preview.metric is not None
        assert preview.metric.payload_ref is not None

        catalog_binding = owner.graph.bind_fetch_target(
            metric_id=plan.metric_id,
            connector_id=preview.metric.connector_id,
            request_dataset_id=preview.metric.dataset_id,
            profile_id=plan.profile_id,
            filters=plan.filters,
        )
''')
acq = change(acq,
    '''        source_workspace = tmp_path / "selected-substrate-source-workspace"
        source_workspace.mkdir()
        source_context = select_substrate_source_context(
            REPO_ROOT,
            workspace_root=source_workspace,
        )
        source_owner_root = source_context.require_source_owner_root(REPO_ROOT)
''',
    '''        # Case-owned synthetic roots are siblings, as required by the same
        # source-owner guard used in production. No checkout data is read.
        from tests.unit.runtime.quality.test_substrate_registry import (
            _write_substrate_catalog_fixture,
        )

        fixture_code_root = tmp_path / "selected-substrate-code"
        fixture_owner_root = tmp_path / "selected-substrate-owner"
        source_workspace = tmp_path / "selected-substrate-source-workspace"
        fixture_code_root.mkdir()
        source_workspace.mkdir()
        _write_substrate_catalog_fixture(fixture_owner_root)
        (fixture_code_root / "production_data").symlink_to(
            fixture_owner_root / "production_data", target_is_directory=True
        )
        source_context = select_substrate_source_context(
            fixture_code_root,
            workspace_root=source_workspace,
            source_owner_root=fixture_owner_root,
        )
        source_owner_root = source_context.require_source_owner_root(fixture_code_root)
        assert source_owner_root == fixture_owner_root.resolve()
''')
(OUT / acq_path).write_text(acq)
print('wrote exactly two RAW postimages')
