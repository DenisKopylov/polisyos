"""Root-run bounded native identity witness; author must not execute this script."""
from __future__ import annotations

import argparse
import ast
import hashlib
import importlib
import json
import subprocess
from pathlib import Path


def declarations(payload: bytes, name: str) -> object:
    """Read one exact literal source declaration, without executing it."""
    tree = ast.parse(payload)
    values = []
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id == name for target in node.targets
        ):
            values.append(ast.literal_eval(node.value))
        elif (
            isinstance(node, ast.AnnAssign)
            and isinstance(node.target, ast.Name)
            and node.target.id == name
        ):
            values.append(ast.literal_eval(node.value))
    if len(values) != 1:
        raise ValueError(f"Expected one literal declaration for {name}")
    return values[0]


def main() -> None:
    """Verify only actual new bindings on the admitted Root source/profile."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, required=True)
    parser.add_argument("--base-commit", required=True)
    parser.add_argument("--proposal-root", type=Path, required=True)
    parser.add_argument("--proposal-manifest-sha256", required=True)
    parser.add_argument("--expected-head", required=True)
    parser.add_argument("--expected-tree", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = args.repo_root.resolve()
    identity = subprocess.check_output(
        ["git", "rev-parse", "HEAD", "HEAD^{tree}"], cwd=root, text=True
    ).splitlines()
    if identity != [args.expected_head, args.expected_tree]:
        raise ValueError(f"Root source identity mismatch: {identity}")
    if args.output.exists():
        raise ValueError("Use a fresh output path; do not overwrite an earlier witness")
    src = root / "policy-engine/src"
    proposal = args.proposal_root.resolve()
    proposal_bytes = (proposal / "manifest.json").read_bytes()
    if hashlib.sha256(proposal_bytes).hexdigest() != args.proposal_manifest_sha256:
        raise ValueError("Frozen proposal manifest identity mismatch")
    proposal_manifest = json.loads(proposal_bytes)
    proposal_files = {row["path"]: row for row in proposal_manifest["files"]}
    rows = []
    for module, rel in (
        ("polisyos.core.canon", "policy-engine/src/polisyos/core/canon/__init__.py"),
        ("polisyos.fabric", "policy-engine/src/polisyos/fabric/__init__.py"),
    ):
        before = subprocess.check_output(
            ["git", "show", f"{args.base_commit}:{rel}"], cwd=root
        )
        after = (root / rel).read_bytes()
        old_names = declarations(before, "__all__")
        new_names = declarations(after, "__all__")
        if not isinstance(old_names, list) or not isinstance(new_names, list):
            raise ValueError("Expected complete literal __all__ sequences")
        planned_payload = (proposal / "postimages" / rel).read_bytes()
        basis = proposal_files[rel]
        if (
            hashlib.sha256(before).hexdigest() != basis["preimage"]["sha256"]
            or hashlib.sha256(planned_payload).hexdigest() != basis["postimage"]["sha256"]
        ):
            raise ValueError(f"Frozen proposal/preimage mismatch for {module}")
        planned_names = declarations(planned_payload, "__all__")
        added = set(new_names) - set(old_names)
        removed = set(old_names) - set(new_names)
        expected_added = set(planned_names) - set(old_names)
        if removed or added != expected_added:
            raise ValueError(f"Unexpected public-source delta for {module}: {added}, {removed}")
        runtime = importlib.import_module(module)
        origin = Path(runtime.__file__).resolve()
        if not origin.is_relative_to(src.resolve()):
            raise ValueError(f"Unexpected physical import origin: {module}: {origin}")
        if list(runtime.__all__) != new_names:
            raise ValueError(f"Runtime/source __all__ mismatch: {module}")
        owner_map = declarations(after, "_LAZY_IMPORTS") if module == "polisyos.fabric" else {}
        api = importlib.import_module("polisyos.fabric.api") if owner_map else None
        for name in sorted(added):
            if owner_map:
                owner_name, owner_symbol = owner_map[name]
            else:
                owner_name, owner_symbol = "polisyos.core.canon.canon_json", name
            owner = importlib.import_module(owner_name)
            owner_origin = Path(owner.__file__).resolve()
            if not owner_origin.is_relative_to(src.resolve()):
                raise ValueError(f"Unexpected physical owner origin: {owner_origin}")
            actual = getattr(runtime, name)
            expected = getattr(owner, owner_symbol)
            if actual is not expected or (api is not None and getattr(api, name) is not expected):
                raise ValueError(f"Public binding identity mismatch for {module}.{name}")
            rows.append(
                {
                    "entrypoint": module,
                    "symbol": name,
                    "owner": owner_name,
                    "owner_symbol": owner_symbol,
                    "source_sha256": hashlib.sha256(after).hexdigest(),
                    "origin": str(origin),
                    "owner_origin": str(owner_origin),
                    "identity": "PASS",
                }
            )
    payload = {
        "head": identity[0],
        "tree": identity[1],
        "source_base": args.base_commit,
        "proposal_manifest_sha256": args.proposal_manifest_sha256,
        "bindings": rows,
        "scope": "Actual11 new source-derived bindings: Core2 plus Fabric9 through root/api. This is not an all84-entrypoint runtime census.",
        "unresolved": [
            "Canonical static parser's Fabric-root reflective namespace write remains explicitly unresolved; native identity is exact-instance/profile evidence only.",
            "Unselected exports, future namespace mutations, DTO/schema semantics and whole imported/compiled dependency closure are not established by this witness.",
        ],
        "G_acceptance": False,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps(payload, sort_keys=True))


if __name__ == "__main__":
    main()
