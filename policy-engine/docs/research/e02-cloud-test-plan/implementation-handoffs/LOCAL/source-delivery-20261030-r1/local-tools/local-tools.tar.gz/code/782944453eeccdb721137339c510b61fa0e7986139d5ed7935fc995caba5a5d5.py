from pathlib import Path
import subprocess,hashlib,json,ast,difflib
R=Path.cwd();O=R/'LOCAL/raw/e02-execution-20261027/repairs/C29-fixture-owner';O.mkdir(exist_ok=False);base='8db01b1076e425b7998b05a658776c991b7bd594';head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip();paths=['policy-engine/tests/unit/foundry/calibration/test_identifiability_response_basis.py','policy-engine/tests/unit/foundry/uncertainty/test_monte_carlo_b194.py'];pre={p:(R/p).read_bytes() for p in paths};post={}
for p,b in pre.items():assert subprocess.check_output(['git','show',base+':'+p])==b,p
p=paths[0];s=pre[p].decode();s=s.replace('from polisyos.ir.trinity import TrinityBundle\n','from polisyos.ir.trinity import TrinityBundle, persist_trinity_bundle_artifact\n');old='''    policy_ref = store.put_json(
        policy,
        PutOptions(
            kind=TrinityBundle.ARTIFACT_KIND,
            media_type=TrinityBundle.ARTIFACT_MEDIA_TYPE,
            schema=SchemaInfo(
                name=TrinityBundle.ARTIFACT_SCHEMA_NAME,
                version=TrinityBundle.ARTIFACT_SCHEMA_VERSION,
            ),
            inputs=[input_ref_from_artifact_ref(candidate_ref, role="policy_candidate")],
        ),
        return_selected_profile=True,
    )
''';new='''    policy_ref = ArtifactRef.model_validate(
        persist_trinity_bundle_artifact(
            ensure_ir_artifact_store(store),
            policy,
            inputs=[
                input_ref_from_artifact_ref(candidate_ref, role="policy_candidate").model_dump(
                    mode="json"
                )
            ],
        ).model_dump(mode="python")
    )
''';assert s.count(old)==1;s=s.replace(old,new);assert s.count('from polisyos.ir.trinity import TrinityBundle, persist_trinity_bundle_artifact\n')==1;post[p]=s.encode()
p=paths[1];s=pre[p].decode();assert s.count('from polisyos.core.artifacts.manifest import SchemaInfo\n')==1;s=s.replace('from polisyos.core.artifacts.manifest import SchemaInfo\n','from polisyos.core.artifacts.manifest import ArtifactRef, SchemaInfo\n');assert s.count('from polisyos.ir.trinity import TrinityBundle\n')==1;s=s.replace('from polisyos.ir.trinity import TrinityBundle\n','from polisyos.ir.trinity import TrinityBundle, persist_trinity_bundle_artifact\n');old='''    trinity_ref = store.put_json(
        TrinityBundle(
            problem_frame=problem_frame,
            policy_spec=PolicySpec(policy_id="b194_policy", interventions=[]),
            model_spec=ModelSpec(
                model_id="b194_model",
                data_snapshot_ref="sha256:" + "0" * 64,
                fidelity_level=FidelityLevel.HYBRID,
            ),
        ),
        PutOptions(
            kind="ir.trinity_bundle",
            media_type="application/json",
            schema=SchemaInfo(name="polisyos.ir.TrinityBundle", version="1.0"),
        ),
    )
    return trinity_ref
''';new='''    trinity_ref = persist_trinity_bundle_artifact(
        _ensure_ir_artifact_store(store),
        TrinityBundle(
            problem_frame=problem_frame,
            policy_spec=PolicySpec(policy_id="b194_policy", interventions=[]),
            model_spec=ModelSpec(
                model_id="b194_model",
                data_snapshot_ref="sha256:" + "0" * 64,
                fidelity_level=FidelityLevel.HYBRID,
            ),
        ),
    )
    return ArtifactRef.model_validate(trinity_ref.model_dump(mode="python"))
''';assert s.count(old)==1;s=s.replace(old,new);post[p]=s.encode()
rows=[];patch=[]
for p,b in post.items():
 ast.parse(b,filename=p);t=O/'postimages'/p;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(b);rows.append({'path':p,'base_sha256':hashlib.sha256(pre[p]).hexdigest(),'current_readback_sha256':hashlib.sha256((R/p).read_bytes()).hexdigest(),'final_sha256':hashlib.sha256(b).hexdigest(),'postimage_path':str(t.relative_to(R)),'bytes':len(b),'scope':'existing typed test-fixture producer only; no assertion or product reader change'});patch.extend(difflib.unified_diff(pre[p].decode().splitlines(keepends=True),b.decode().splitlines(keepends=True),fromfile='a/'+p,tofile='b/'+p))
patch_path=O/'patch.diff';patch_path.write_text(''.join(patch));assert all((R/p).read_bytes()==pre[p] for p in paths);manifest={'schema':'policyos.e02.sparse_fixture_correction.v1','status':'proposal_not_applied','cloud_source_base':base,'canonical_head_at_read':'{}'.format(head),'canonical_tree_at_read':tree,'source_advance_policy':'Root advances outside these exact preimages are expected; root composes after fresh path/hash admission.','proof_basis':'C29 actual delivered traces: IR owner rejects direct Core Trinity write; adding selected=True alone is insufficient.','files':rows,'patch':{'path':str(patch_path.relative_to(R)),'sha256':hashlib.sha256(patch_path.read_bytes()).hexdigest(),'bytes':patch_path.stat().st_size},'checks':{'ast_parse':'PASS all2 sparse postimages; no imports executed','ruff':'UNRUN per author scope','pytest':'UNRUN per author scope','install':'UNRUN; existing backend present by distribution metadata only'},'preserved':['Trinity payloads and original numerical/original consumer assertions','B190 exact policy_candidate input edge','exact owner/profile admission','B194 selected-profile reference into fresh normative frame','Core/IR reader source and all production code','canonical checkout/index/HEAD/refs'],'independent_review':'requested separately; not author self-approval','G_acceptance':False,'closure_ids':[]};(O/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'folder':str(O.relative_to(R)),'manifest_sha256':hashlib.sha256((O/'manifest.json').read_bytes()).hexdigest(),'patch_sha256':manifest['patch']['sha256'],'paths':rows},indent=2))
