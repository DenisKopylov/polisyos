"""Source-only conditional bootstrap dependency probe; not the R152 cause."""
from __future__ import annotations
import ast
from pathlib import Path
import sys

root = Path.cwd().resolve()
source = root / "LOCAL/raw/e02-execution-20261027/repairs/N7-protocol-identity-r1/pre/policy-engine/src/polisyos/runtime/quality/confidence_ledger.py"
tree = ast.parse(source.read_bytes(), filename=str(source))
selected_names = {
    "ConfidenceLedgerError", "_deployment_relative_paths_from_closure",
    "_deployment_quick_fence", "_stable_deployment_snapshot",
    "_deployment_relative_paths", "_deployment_baseline", "_derived_authority_import_closure",
}
selected = [
    item for item in tree.body
    if isinstance(item, (ast.FunctionDef, ast.ClassDef)) and item.name in selected_names
]
ns = {"__name__": "synthetic.bootstrap.probe", "Path": Path, "sys": sys}
module_ast = ast.Module(
    body=[ast.ImportFrom(module="__future__",names=[ast.alias(name="annotations")],level=0), *selected],
    type_ignores=[],
)
exec(compile(ast.fix_missing_locations(module_ast), str(source), "exec"), ns)
candidate = (("polisyos.runtime.quality.confidence_ledger", "src/polisyos/runtime/quality/confidence_ledger.py"),)
ns["_IMPORT_TIME_AUTHORITY_IMPORT_CLOSURE"] = ()
ns["_resolve_authority_import_closure"] = lambda _root, _entry: candidate
for name in ("_stable_deployment_snapshot", "_deployment_baseline"):
    try:
        ns[name](root / "policy-engine")
    except ns["ConfidenceLedgerError"] as exc:
        print(name, "candidate-not-installed", exc.code, exc.detail)
    else:
        raise AssertionError(name + " unexpectedly accepted empty global closure")
print("CONDITIONAL SOURCE-ONLY PROBE: resolver was stubbed with a nonempty candidate; actual import control flow was not replayed.")
