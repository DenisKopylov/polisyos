from pathlib import Path
import json,subprocess
R=Path.cwd();O=R/'LOCAL/raw/e02-execution-20261027/repairs/C32-r5';O.mkdir(exist_ok=True);r3=R/'LOCAL/raw/e02-execution-20261027/repairs/C32-r3';r4=R/'LOCAL/raw/e02-execution-20261027/repairs/C32-r4'
for row in json.loads((r3/'manifest.json').read_text())['files']:
 f=O/row['path'];f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes((R/row['postimage_path']).read_bytes())
for row in json.loads((r4/'manifest.json').read_text())['own_files']:
 f=O/row['path'];f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes((R/row['postimage_path']).read_bytes())
new_paths=['policy-engine/src/polisyos/fabric/retrieval/service.py','policy-engine/src/polisyos/fabric/retrieval/README.md','policy-engine/src/polisyos/data_forge/read_api/catalog.py','policy-engine/src/polisyos/data_forge/read_api/README.md','policy-engine/src/polisyos/data_forge/domains/catalog/knowledge/derivation_catalog_selection.py']
for p in new_paths:
 f=O/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes((R/p).read_bytes())
p=O/'policy-engine/src/polisyos/data_forge/domains/catalog/knowledge/derivation_catalog_selection.py';s=p.read_text();needle='\n\nclass _StrictModel(BaseModel):';assert s.count(needle)==1;s=s.replace(needle,'''

class CatalogReadSourceError(CatalogSelectionError):
    """Typed unavailable or changed native read source; never an empty result.

    This remains a CatalogSelectionError for existing callers. Consumers
    propagate the complete subtype rather than enumerating reason prefixes;
    code/detail preserve the exact owner failure and do not grant authority.
    """


class _StrictModel(BaseModel):''');s=s.replace('    "CatalogSelectionError",','    "CatalogReadSourceError",\n    "CatalogSelectionError",');p.write_text(s)
p=O/'policy-engine/src/polisyos/data_forge/read_api/catalog.py';s=p.read_text();needle='''    from polisyos.data_forge.domains.catalog.knowledge.derivation_catalog_selection import (
        CatalogSelectionError as CatalogSelectionError,
    )''';assert s.count(needle)==1;s=s.replace(needle,'''    from polisyos.data_forge.domains.catalog.knowledge.derivation_catalog_selection import (
        CatalogReadSourceError as CatalogReadSourceError,
    )
'''+needle);needle='''    "CatalogSelectionError": (
        "polisyos.data_forge.domains.catalog.knowledge.derivation_catalog_selection"
    ),''';assert s.count(needle)==1;s=s.replace(needle,'''    "CatalogReadSourceError": (
        "polisyos.data_forge.domains.catalog.knowledge.derivation_catalog_selection"
    ),
'''+needle);p.write_text(s)
p=O/'policy-engine/src/polisyos/data_forge/domains/catalog/knowledge/store.py';s=p.read_text();s=s.replace('    CatalogSelectionError,','    CatalogReadSourceError,\n    CatalogSelectionError,',1);s=s.replace('raise CatalogSelectionError("catalog_read_','raise CatalogReadSourceError("catalog_read_');s=s.replace('''                raise ValueError("catalog_fetch_source_changed_while_opening")''','''                raise CatalogReadSourceError(
                    "catalog_read_source_changed_while_opening",
                    "catalog_fetch_source_changed_while_opening",
                )''');p.write_text(s)
p=O/'policy-engine/src/polisyos/fabric/retrieval/service.py';s=p.read_text();old='''            if str(getattr(exc, "code", "")).startswith("catalog_read_session_"):
                raise
''';assert s.count(old)==1;s=s.replace(old,'''            if isinstance(exc, catalog_read_api.CatalogReadSourceError):
                raise
''');old='''                    if str(getattr(exc, "code", "")).startswith("catalog_read_session_"):
                        raise
''';assert s.count(old)==2;s=s.replace(old,'''                    if isinstance(exc, catalog_read_api.CatalogReadSourceError):
                        raise
''');old='''                        if str(getattr(exc, "code", "")).startswith("catalog_read_session_"):
                            raise
''';assert s.count(old)==1;s=s.replace(old,'''                        if isinstance(exc, catalog_read_api.CatalogReadSourceError):
                            raise
''');p.write_text(s)
p=O/'policy-engine/src/polisyos/runtime/quality/acquisition_planner.py';s=p.read_text();needle='''class AcquisitionPlannerBindingError(ValueError):
    """Fail-closed mismatch between one N7 plan, its complete input and CAS readback."""
''';assert s.count(needle)==1;s=s.replace(needle,needle+'''
    def __init__(self, *args: object, source_refusal_code: str | None = None) -> None:
        self.source_refusal_code = source_refusal_code
        super().__init__(*args)
''');start=s.index('class RealAcquisitionOwnerGateway:');ix=s.index('''        owner_component = _owner_component_for_record(record, compiled_requirement_spec)''',start);s=s[:ix]+'''        from polisyos.data_forge.read_api import catalog as catalog_read_api
        from polisyos.runtime.quality.substrate_registry import SubstrateRegistryError

        try:
            return self._acquire_from_owner(
                record=record, compiled_requirement_spec=compiled_requirement_spec
            )
        except (
            catalog_read_api.CatalogReadSourceError,
            catalog_read_api.BaselineMutationError,
            catalog_read_api.OverlayAdmissionError,
            SubstrateRegistryError,
        ) as exc:
            raise AcquisitionPlannerBindingError(
                str(exc), source_refusal_code=exc.code
            ) from exc

    def _acquire_from_owner(
        self,
        *,
        record: AcquisitionActionRecord,
        compiled_requirement_spec: Mapping[str, Any],
    ) -> AcquisitionOwnerArtifact | None:
        """Dispatch the actual owner only inside the typed source-failure adapter."""

'''+s[ix:];p.write_text(s)
p=O/'policy-engine/src/polisyos/runtime/quality/generation_cycle.py';s=p.read_text();needle='''        except AcquisitionPlannerBindingError as exc:
            error_code = (''';assert s.count(needle)==1;s=s.replace(needle,'''        except AcquisitionPlannerBindingError as exc:
            if exc.source_refusal_code is not None:
                raise GenerationCycleError(
                    "n7_catalog_source_refused",
                    str(exc),
                    source_refusal_code=exc.source_refusal_code,
                ) from exc
            error_code = (''');p.write_text(s)
p=O/'policy-engine/tests/unit/runtime/quality/test_catalog_source_identity.py';s=p.read_text().replace('''    assert failure.value.code == "catalog_read_session_unavailable"
    assert "catalog_fetch_source_changed_while_opening"''','''    assert failure.value.code == "catalog_read_source_changed_while_opening"
    assert "catalog_fetch_source_changed_while_opening"''');p.write_text(s)
p=O/'policy-engine/tests/unit/runtime/quality/test_catalog_acquisition_source_binding.py';s=p.read_text().replace('    RealAcquisitionOwnerGateway,','    AcquisitionPlannerBindingError,\n    RealAcquisitionOwnerGateway,',1);s=s.replace('    SubstrateRegistryError,\n','');s=s.replace('''        rows = original_bindings(self, metric_name, top_k=top_k)
        native_bindings.append((self.database_path, metric_name, tuple(rows)))
        return rows''','''        entry = {"path": self.database_path, "metric": metric_name, "rows": None}
        native_bindings.append(entry)
        rows = original_bindings(self, metric_name, top_k=top_k)
        entry["rows"] = tuple(rows)
        return rows''');s=s.replace('''        response = original_resolve(self, request, run_profile=run_profile)
        resolutions.append((request, run_profile, response))
        return response''','''        entry = {"request": request, "run_profile": run_profile, "response": None}
        resolutions.append(entry)
        response = original_resolve(self, request, run_profile=run_profile)
        entry["response"] = response
        return response''');s=s.replace('''        request, run_profile, actual_response = resolutions[0]''','''        request = resolutions[0]["request"]
        run_profile = resolutions[0]["run_profile"]
        actual_response = resolutions[0]["response"]
        assert actual_response is not None''');s=s.replace('''        assert all(path == source.database_path for path, _metric, _rows in native_bindings)
        actual_rows = [
            row
            for _path, metric, rows in native_bindings
            if metric == "metric.test"
            for row in rows
        ]''','''        assert all(entry["path"] == source.database_path for entry in native_bindings)
        assert all(entry["rows"] is not None for entry in native_bindings)
        actual_rows = [
            row
            for entry in native_bindings
            if entry["metric"] == "metric.test"
            for row in entry["rows"]
        ]''');s=s.replace('refusal: SubstrateRegistryError | None','refusal: AcquisitionPlannerBindingError | None').replace('except SubstrateRegistryError as exc:','except AcquisitionPlannerBindingError as exc:').replace('assert refusal.code == expected_code','assert refusal.source_refusal_code == expected_code').replace('tuple(str(path) for path, _metric, _rows in native_bindings)','tuple(str(entry["path"]) for entry in native_bindings)');p.write_text(s)
print({'prepared_sparse_r5_paths':len([p for p in (O/'policy-engine').rglob('*') if p.is_file()]),'source_runtime':'UNRUN'})
