"""Read complete source and C05 introduced AST calls against available real definitions."""
from __future__ import annotations
import ast, collections, hashlib, json, os, subprocess
from pathlib import Path
ROOT=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
OUT=Path(__file__).resolve().parent
BASE='545c6990e2bfa42bf580b475e23cf88df04e71d8'
SLICE_BASE='b8fcda7332c89609410e8ca936b472ef2eed43e1'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def sha(raw):return hashlib.sha256(raw).hexdigest()
all_entries={}
for row in git('ls-tree','-r','-z',BASE).split(b'\0'):
 if row:
  info,path=row.split(b'\t',1);mode,kind,oid=info.split(b' ')
  all_entries[os.fsdecode(path)]=(kind.decode(),oid.decode())
changed=[p for p in git('diff','--name-only',SLICE_BASE,BASE,'--','policy-engine').decode().splitlines() if p.endswith('.py')]
selected={p:oid for p,(kind,oid) in all_entries.items() if kind=='blob' and p.startswith('policy-engine/src/') and p.endswith('.py')}
selected.update({p:all_entries[p][1] for p in changed})
proc=subprocess.run(['git','cat-file','--batch'],cwd=ROOT,input=('\n'.join(selected.values())+'\n').encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert proc.returncode==0,proc.stderr
pos=0;source={}
for path,oid in selected.items():
 end=proc.stdout.index(b'\n',pos);header=proc.stdout[pos:end].split();assert header[0].decode()==oid
 size=int(header[2]);pos=end+1;source[path]=proc.stdout[pos:pos+size];pos+=size+1
assert pos==len(proc.stdout)
original=dict(source)
for path in (OUT/'policy-engine').rglob('*.py'):source[str(path.relative_to(OUT))]=path.read_bytes()
trees={p:ast.parse(v,filename=p) for p,v in source.items()}
mods={};functions={}
for path,tree in trees.items():
 if not path.startswith('policy-engine/src/'):continue
 suffix=path.removeprefix('policy-engine/src/').removesuffix('.py').split('/')
 if suffix[-1]=='__init__':suffix.pop()
 mod='.'.join(suffix);mods[mod]=path
 functions[mod]={n.name:n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
def module_name(path):
 suffix=path.removeprefix('policy-engine/src/').removesuffix('.py').split('/')
 if suffix[-1]=='__init__':suffix.pop()
 else:suffix.pop()
 return suffix

def imports(path,tree):
 result={};qualified={}
 for node in ast.walk(tree):
  if isinstance(node,ast.ImportFrom) and node.module:
   if node.level:
    parts=module_name(path);prefix=parts[:len(parts)-node.level+1];mod='.'.join([*prefix,*node.module.split('.')])
   else:mod=node.module
   for name in node.names:
    result[name.asname or name.name]=(mod,name.name)
  if isinstance(node,ast.Import):
   for name in node.names:
    if name.asname:qualified[name.asname]=name.name
 return result,qualified

def signature(fn):
 a=fn.args;pos=[*a.posonlyargs,*a.args];required=[v.arg for v in pos[:len(pos)-len(a.defaults)]]
 kwrequired=[v.arg for v,d in zip(a.kwonlyargs,a.kw_defaults,strict=True) if d is None]
 return {'positional':[v.arg for v in pos],'required_positional':required,'required_keyword_only':kwrequired,'keyword_names':[v.arg for v in [*a.args,*a.kwonlyargs]],'varargs':a.vararg is not None,'varkw':a.kwarg is not None}
def compare(call,sig):
 if any(isinstance(a,ast.Starred) for a in call.args) or any(k.arg is None for k in call.keywords):return {'status':'unresolved_expansion'}
 kws={k.arg for k in call.keywords};n=len(call.args);provided=set(sig['positional'][:n])|kws
 missing=[v for v in [*sig['required_positional'],*sig['required_keyword_only']] if v not in provided]
 extra=sorted(kws-set(sig['keyword_names'])) if not sig['varkw'] else []
 too_many=n>len(sig['positional']) and not sig['varargs']
 return {'status':'mismatch' if missing or extra or too_many else 'static_shape_compatible','missing':missing,'unexpected_keywords':extra,'too_many_positional':too_many}

def imported_call_owner(call,binding,qualified):
 if isinstance(call.func,ast.Name):return binding.get(call.func.id)
 if isinstance(call.func,ast.Attribute):
  if isinstance(call.func.value,ast.Name) and call.func.value.id in qualified:return qualified[call.func.value.id],call.func.attr
  if ast.unparse(call.func)=='polisyos.common.serialization.decode_json_object':return 'polisyos.common.serialization','decode_json_object'
 return None

introduced=[];decoder_rows=[];decoder_before=[];introduced_counts=collections.Counter();definition_pins={}
for path,tree in trees.items():
 binding,qualified=imports(path,tree)
 before_calls=collections.Counter()
 if path in changed:
  cp=subprocess.run(['git','show',SLICE_BASE+':'+path],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  if cp.returncode==0:before_calls=collections.Counter(ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(cp.stdout)) if isinstance(n,ast.Call))
 for call in [n for n in ast.walk(tree) if isinstance(n,ast.Call)]:
  owner=imported_call_owner(call,binding,qualified)
  if owner is not None and owner==('polisyos.common.serialization','decode_json_object'):
   fn=functions[owner[0]][owner[1]];sig=signature(fn);res=compare(call,sig)
   decoder_rows.append({'path':path,'line':call.lineno,'owner':'.'.join(owner),'provided_keywords':[k.arg for k in call.keywords],**res})
  if path not in changed:continue
  key=ast.dump(call,include_attributes=False)
  if before_calls[key]:before_calls[key]-=1;continue
  if owner is None:status={'status':'unresolved_runtime_or_local_call'}
  else:
   mod,name=owner;fn=functions.get(mod,{}).get(name)
   if isinstance(fn,(ast.FunctionDef,ast.AsyncFunctionDef)):
    sig=signature(fn);status=compare(call,sig);definition_pins['.'.join(owner)]={'path':mods[mod],'line':fn.lineno,'source_sha256':sha(source[mods[mod]]),'signature':sig}
   elif isinstance(fn,ast.ClassDef):status={'status':'unresolved_class_constructor'}
   else:status={'status':'unresolved_facade_external_or_binding'}
  row={'path':path,'line':call.lineno,'call_form':ast.unparse(call.func),'owner':'.'.join(owner) if owner else None,'call_shape_sha256':sha(key.encode()),'provided_keywords':[k.arg for k in call.keywords],**status}
  introduced.append(row);introduced_counts[row['status']]+=1
for path,raw in original.items():
 tree=ast.parse(raw);binding,qualified=imports(path,tree)
 for call in [n for n in ast.walk(tree) if isinstance(n,ast.Call)]:
  if imported_call_owner(call,binding,qualified)==('polisyos.common.serialization','decode_json_object'):
   decoder_before.append({'path':path,'line':call.lineno,**compare(call,signature(functions['polisyos.common.serialization']['decode_json_object']))})
owner_path=mods['polisyos.common.serialization'];owner_fn=functions['polisyos.common.serialization']['decode_json_object']
summary={'scope':'Complete pinned source *.py set plus complete C05 introduced Python set from actual slice commit parent→545c and exact 2 forward-fix postimages. Static import/call shape against actual top-level AST definitions; no product imports or execution.','base_commit':BASE,'slice_base':SLICE_BASE,'source_python_files':sum(p.startswith('policy-engine/src/') for p in source),'complete_c05_changed_python_files':changed,'all_selected_python_files':len(source),'canonical_decoder_definition':{'path':owner_path,'line':owner_fn.lineno,'sha256':sha(source[owner_path]),'signature':signature(owner_fn)},'decoder_before':decoder_before,'decoder_after':decoder_rows,'introduced_call_count':len(introduced),'introduced_status_counts':dict(introduced_counts),'introduced_static_mismatches':[r for r in introduced if r['status']=='mismatch'],'introduced_definition_count':len(definition_pins),'definitions':definition_pins,'unresolved_by_construction':['Runtime attribute dispatch, local calls, dynamic decorators/aliases, generated class constructors, lazy facades and external/stdlib contracts are not established by this AST binding.','**kwargs/*args expansions are unresolved; this is not runtime type/compatibility evidence.','Tests were not collected or executed; no pass/inherited-failure attribution follows.'],'source_set_sha256':sha(b''.join(p.encode()+b'\0'+hashlib.sha256(v).digest() for p,v in sorted(source.items()))),'product_imports':False,'runtime':'UNRUN'}
(OUT/'introduced-calls.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in introduced))
(OUT/'contract-census.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'source_python_files':summary['source_python_files'],'C05_changed_python_files':len(changed),'selected_files':len(source),'introduced_calls':len(introduced),'status_counts':dict(introduced_counts),'introduced_mismatches':summary['introduced_static_mismatches'],'decoder_before_mismatches':[r for r in decoder_before if r['status']=='mismatch'],'decoder_after_mismatches':[r for r in decoder_rows if r['status']=='mismatch']},indent=2))
