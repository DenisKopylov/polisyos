"""One non-perturbing optional-observation lifecycle, independent of the product.

Ordinary observer Exceptions are recorded. Product calls/results/exceptions are
never inside the protected observer callback; cancellation BaseExceptions keep
their normal process semantics. Admission and mutation operations are separate.
"""
from __future__ import annotations
from typing import Any,Callable

PHASES={'setup','enter','returned','raised','cleanup'}

class Observer:
    """Dispatch every optional phase through one protected observation owner."""
    def __init__(self,errors:list[dict[str,str]])->None:self.errors=errors
    def generic_safe_observe(self,phase:str,callback:Callable[...,Any]|None,*args:Any,**kwargs:Any)->Any:
        try:
            if phase not in PHASES:raise ValueError('unregistered optional observation phase')
            return callback(*args,**kwargs) if callback is not None else None
        except Exception as exc:
            self.errors.append({'phase':phase,'exception_type':type(exc).__module__+'.'+type(exc).__qualname__})
            return None
    def call(self,original:Callable[...,Any],args:tuple[Any,...],kwargs:dict[str,Any],*,setup:Callable[[],Any]|None=None,enter:Callable[[],Any]|None=None,returned:Callable[[Any,Any],Any]|None=None,raised:Callable[[Any,BaseException],Any]|None=None,cleanup:Callable[[],Any]|None=None)->Any:
        """Forward the original exactly once regardless of optional phase failures."""
        self.generic_safe_observe('setup',setup)
        event=self.generic_safe_observe('enter',enter)
        try:
            try:result=original(*args,**kwargs)
            except BaseException as failure:
                self.generic_safe_observe('raised',raised,event,failure)
                raise
            self.generic_safe_observe('returned',returned,event,result)
            return result
        finally:self.generic_safe_observe('cleanup',cleanup)
