"""Export exact sparse Pydantic owners; this is not product verification."""
from pathlib import Path
import importlib.util
import json
import subprocess
import sys

sys.dont_write_bytecode = True
root = Path.cwd()
scratch = root / 'LOCAL/raw/e02-execution-20261027/repairs/C04-r2'
sys.path.insert(0, str(root / 'policy-engine/src'))
for suffix, relative, owner in [
    ('source_contract', 'src/polisyos/fabric/connectors/contracts/source_contract.py', 'SourceProgressContract'),
    ('source_collection', 'src/polisyos/fabric/ingestion/source_collection.py', 'SourceCollection'),
]:
    name = ('polisyos.fabric.connectors.contracts._c04r2_source_contract_schema' if owner == 'SourceProgressContract' else 'polisyos.fabric.ingestion._c04r2_source_collection_schema')
    spec = importlib.util.spec_from_file_location(name, scratch / 'policy-engine' / relative)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    output_name = 'source_progress' if owner == 'SourceProgressContract' else 'source_collection'
    payload = {
        '$schema': 'https://json-schema.org/draft/2020-12/schema',
        '$id': f'https://polisyos.local/schemas/fabric/{output_name}.schema.json',
        **getattr(module, owner).model_json_schema(),
    }
    output = scratch / 'policy-engine/schemas/fabric' / f'{output_name}.schema.json'
    output.write_text(json.dumps(payload, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'schema': str(output.relative_to(scratch)), 'owner': owner, 'bytes': output.stat().st_size}))
print(json.dumps({'kind':'schema_shape_export_only','root_dependencies_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'runtime_tests':'UNRUN'}))
