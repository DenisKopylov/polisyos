"""Construct an append-only RAW R3 runner proposal without executing it."""
from pathlib import Path
import ast
import difflib
import hashlib
import json

ROOT=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
HERE=Path(__file__).resolve().parent
OLD_FRAME=HERE.parent/'C48-comparison-plan-reconciliation-r2/source-bindings.json'
frame=json.loads(OLD_FRAME.read_text())
old_path=frame['raw_runner_inputs'][0]['path']
new_path=old_path.replace('run_case_with_tools_r2.py','run_case_with_tools_r3.py')
old=(ROOT/old_path).read_text()
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(old.encode())=='4c3eae2136b6c8941ba09d4438d12ea6ea11310527768f0482877b877b8e30c2'
old_profile=next(line for line in old.splitlines() if line.startswith('profile.write_text('))
# The original D write policy remains byte-for-byte the first profile component.
base_expression=old_profile[len('profile.write_text('):-1]
new_profile='\n'.join([
 'fragment=plan["sandbox_profile_fragment"]',
 'assert type(fragment) is str and hashlib.sha256(fragment.encode()).hexdigest()==plan["sandbox_profile_fragment_sha256"]',
 'fragment_path=out/"sandbox-fragment.sb"; fragment_path.write_text(fragment)',
 'profile.write_text('+base_expression+'+fragment)',
 'assert profile.read_text()==plan["sandbox_profile_text"] and sha(profile)==plan["sandbox_profile_sha256"]',
])
new=old.replace(old_profile,new_profile)
old_pins='input_pins={str(p.relative_to(R)):sha(p) for p in pins}'
new_pins='pins += [profile,fragment_path]\n'+old_pins
assert new.count(old_pins)==1
new=new.replace(old_pins,new_pins)
old_freeze='"native_profile":"pytest.ini, default plugin autoload/importlib/strict markers; add read-only sys.modules observer; outputs redirected only; private empty pycache search prefix prevents stale canonical pyc reuse",'
new_freeze=old_freeze+'"sandbox_profile":{"path":str(profile.relative_to(R)),"text":profile.read_text(),"sha256":sha(profile),"fragment_path":str(fragment_path.relative_to(R)),"fragment_text":fragment,"fragment_sha256":sha(fragment_path)},'
assert new.count(old_freeze)==1
new=new.replace(old_freeze,new_freeze)
# Reversing only the declared seam additions yields exactly the original source/AST.
restored=new.replace(new_profile,old_profile).replace(new_pins,old_pins).replace(new_freeze,old_freeze)
assert restored==old
assert ast.dump(ast.parse(restored),include_attributes=False)==ast.dump(ast.parse(old),include_attributes=False)
ast.parse(new)
assert new.count('"/usr/bin/sandbox-exec"')==1
out=HERE/'postimage'/new_path;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(new)
patch=''.join(difflib.unified_diff([],new.splitlines(keepends=True),fromfile='/dev/null',tofile='b/'+new_path))
(HERE/'install-runner.patch').write_text(patch)
delta=''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile=old_path,tofile=new_path))
(HERE/'runner-delta.patch').write_text(delta)
frame['raw_runner_inputs'][0]={'path':new_path,'sha256':sha(new.encode())}
frame['scope']+=' R3 single child sandbox: unchanged D write policy plus a reviewed inline known-production read/network fragment, both generated components and complete profile pinned before first launch. R2 runner/guard failure is preserved; no native result is inferred.'
(HERE/'source-bindings.json').write_text(json.dumps(frame,indent=2)+'\n')
receipt={'old_runner':old_path,'old_sha256':sha(old.encode()),'proposed_runner':new_path,'new_sha256':sha(new.encode()),'runner_bytes':len(new.encode()),'r2_restored_text_equal':True,'r2_restored_ast_equal':True,'declared_deltas':['inline fragment type/hash check and retained fragment file','append fragment to original write policy; require exact plan full profile bytes/hash','pin both generated profile/fragment for unchanged postrun all-input recheck','record both complete profile and fragment bytes/hash in existing source-profile-freeze'],'sandbox_launch_count':1,'source75_entries_unchanged':frame['selected_paths_and_explicit_conftest_absences']==json.loads(OLD_FRAME.read_text())['selected_paths_and_explicit_conftest_absences'],'raw_runner_inputs_count':len(frame['raw_runner_inputs']),'runtime':'UNRUN'}
(HERE/'runner-equivalence.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
