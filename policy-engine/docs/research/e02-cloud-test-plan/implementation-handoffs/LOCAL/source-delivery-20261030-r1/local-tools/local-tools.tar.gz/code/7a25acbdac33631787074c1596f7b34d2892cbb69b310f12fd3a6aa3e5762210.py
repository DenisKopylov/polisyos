from pathlib import Path
import ast, hashlib, json, subprocess
root=Path.cwd()
out=root/'LOCAL/raw/e02-execution-20261027/repairs/C46-r6'
pre=out/'preimages'; post=out/'postimages'
inputs=json.loads((out/'preimages.json').read_text())
paths=[row['path'] for row in inputs['paths']]
patch=[]; manifest=[]
for item in inputs['paths']:
 rel=item['path']; a=pre/rel; b=post/rel
 current=(root/rel).read_bytes()
 if hashlib.sha256(current).hexdigest()!=item['sha256']:
  raise ValueError('current preimage drift: '+rel)
 parsed=ast.parse(b.read_text(),filename=rel)
 assert parsed
 proc=subprocess.run(['git','diff','--no-index','--',str(a.relative_to(out)),str(b.relative_to(out))],cwd=out,text=True,capture_output=True)
 if proc.returncode not in (0,1): raise RuntimeError(proc.stderr)
 if proc.returncode==1:
  lines=[]
  for line in proc.stdout.splitlines(keepends=True):
   if line.startswith(('diff --git ', '--- ', '+++ ')):
    line=line.replace('a/preimages/','a/').replace('b/postimages/','b/')
   lines.append(line)
  patch.append(''.join(lines))
  manifest.append({'path':rel,'preimage_sha256':item['sha256'],'postimage_sha256':hashlib.sha256(b.read_bytes()).hexdigest()})
patch_path=out/'base-to-proposal.patch';patch_path.write_text(''.join(patch))
checks=[]
for args in (['git','apply','--check',str(patch_path)],['git','apply','--check','--whitespace=error',str(patch_path)]):
 r=subprocess.run(args,cwd=root,capture_output=True,text=True)
 checks.append({'command':args,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
 if r.returncode: raise RuntimeError(checks[-1])
config=[]
for name in ('ruff.toml','ruff.generated.toml'):
 a=root/'policy-engine'/name; b=post/'policy-engine'/name
 assert a.read_bytes()==b.read_bytes()
 config.append({'path':name,'sha256':hashlib.sha256(a.read_bytes()).hexdigest()})
py=str(root/'policy-engine/.venv/bin/python')
relpaths=[str(Path(item['path']).relative_to('policy-engine')) for item in manifest]
for args in ([py,'-m','ruff','check',*relpaths],[py,'-m','ruff','format','--check',*relpaths]):
 r=subprocess.run(args,cwd=post/'policy-engine',capture_output=True,text=True)
 checks.append({'command':args,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
 if r.returncode: raise RuntimeError(checks[-1])
report={'base_commit':inputs['base_commit'],'base_tree':inputs['base_tree'],'paths':manifest,'patch_sha256':hashlib.sha256(patch_path.read_bytes()).hexdigest(),'patch_bytes':patch_path.stat().st_size,'ruff_configs':config,'checks':checks,'ast_parse':{'exit':0,'count':len(paths)},'runtime':'UNRUN','mutation_controls':'UNRUN','index_or_ref_mutations':'none'}
(out/'manifest.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'files':len(manifest),'patch_bytes':report['patch_bytes'],'patch_sha256':report['patch_sha256'],'ruff_and_apply_exits':[c['exit'] for c in checks],'ast_count':len(paths)},indent=2))
