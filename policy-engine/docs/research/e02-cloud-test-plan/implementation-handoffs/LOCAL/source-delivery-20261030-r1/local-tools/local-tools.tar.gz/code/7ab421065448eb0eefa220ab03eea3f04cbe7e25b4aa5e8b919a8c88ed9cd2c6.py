from pathlib import Path
import ast
H=Path(__file__).resolve().parent
R=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
p=H/'build_proposal.py'
s=p.read_text()
seam="records=[];patch=''"
addition='''
API='policy-engine/src/polisyos/foundry/compile/api.py'
INIT='policy-engine/src/polisyos/foundry/compile/__init__.py'
C06='policy-engine/src/polisyos/scientist/nodes/builtins/decide/policy_runtime_method_metrics.py'
CTEST='policy-engine/tests/unit/scientist/nodes/builtins/decide/test_policy_runtime_method_metrics.py'
FREADME='policy-engine/src/polisyos/foundry/README.md'
api=(ROOT/API).read_text()
api_post=api.replace('from polisyos.core.artifacts.manifest import InputRef','from polisyos.core.artifacts.manifest import ArtifactRef, InputRef').replace('from polisyos.core.contracts.foundry import CompileRequest, CompileResult','from polisyos.core.contracts.execution_plan import ExecutionPlan\\nfrom polisyos.core.contracts.foundry import CompileRequest, CompileResult, LoweredIR, LoweredIRRef, ProgramGraph\\nfrom polisyos.ir.kernel import ConstraintRegistry\\nfrom polisyos.ir.trinity import TrinityBundle')
api_post += '\\n\\n'+(HERE/'replay_facade.py.txt').read_text()
init=(ROOT/INIT).read_text()
init_post=init.replace('__all__ = ["compile"]','__all__ = ["compile", "replay_method_program_graph"]').replace('    "compile": ("polisyos.foundry.compile.api", "compile"),','    "compile": ("polisyos.foundry.compile.api", "compile"),\\n    "replay_method_program_graph": ("polisyos.foundry.compile.api", "replay_method_program_graph"),')
c06=(ROOT/C06).read_text()
old_graph='''+repr('''        # This first profile admits a single, explicit method invocation only.
        # Graph and plan contents remain comparable; only selected source refs vary.
        if len(graph.nodes) == 1 and not graph.edges and len(plan.order) == 1:
            comparison_graph = {
                "graph": graph.model_dump(mode="json", exclude={"ir_ref", "lowered_ir_ref"}),
                "plan": plan.model_dump(mode="json", exclude={"program_ref"}),
            }
''')+'''
new_graph='''+repr('''        comparison_graph = _compiled_method_comparison_graph(
            store, graph=graph, graph_manifest=graph_manifest, plan=plan,
            policy=policy, policy_ref=policy_ref, registry_bundle=registry_bundle,
            registry_bundle_ref=registry_bundle_ref,
            registry_bundle_manifest=registry_bundle_manifest, read_budget=read_budget,
        )
''')+'''
assert c06.count(old_graph)==1
c06_post=c06.replace(old_graph,new_graph).replace('def _validate_execution_capture_order(', (HERE/'comparison_helper.py.txt').read_text()+'def _validate_execution_capture_order(',1)
ctest=(ROOT/CTEST).read_text()
ctest_post=(HERE/'comparison_tests.py.txt').read_text()
fr=(ROOT/FREADME).read_text()
fr_post=fr+'\\nThe public `polisyos.foundry.compile.replay_method_program_graph` facade is a\\nread-only replay of the canonical zero-mechanism method compiler graph and order.\\nIts caller must content-read and reconcile exact selected Trinity, lowering,\\nconstraint registry and Scientist plan profiles first. It checks lowering content\\nagainst Trinity and retains the full merge/check operator plane. It writes no CAS\\nobjects and issues no completion, observation or publication authority. Enabled\\nintervention mechanisms remain outside this bounded replay profile.\\n'
files.update({API:(api,api_post),INIT:(init,init_post),C06:(c06,c06_post),CTEST:(ctest,ctest_post),FREADME:(fr,fr_post)})
'''
assert seam in s
p.write_text(s.replace(seam,addition+'\n'+seam))
# Add real-compiler mode only to comparison callers, retaining the narrow seam.
target=R/'policy-engine/tests/unit/scientist/nodes/builtins/decide/test_policy_runtime_method_metrics.py'
t=target.read_text().replace('    prepare_only: bool = False,\n','    prepare_only: bool = False,\n    canonical_compile: bool = False,\n',1)
start=t.index('    lowered_ir = LoweredIR(ir_ref=trinity_ref, mechanisms=[], constraints=[])')
end=t.index('    binding = MethodMetricBinding(',start)
original=t[start:end]
actual='''    if canonical_compile:
        from polisyos.core.contracts.foundry import CompileRequest, MethodMetricBindingRequest
        from polisyos.foundry.compile import compile as compile_actual
        from polisyos.scientist.orchestration.llm.cycle import persist_candidate_execution_plan

        selected_plan = ExecutionPlan(
            plan_id=f"{run_id}-comparison-method-plan", run_id=run_id,
            method_dag=[MethodDagNode(
                node_id="ex_ante_node", method_fqn=method_signature.fqn,
                method_version=method_signature.version,
                backend=method_signature.execution_backend.value,
                params={"poverty_line": None}, reads_slots=["baseline", "scenario"],
                writes_slots=["result"],
            )],
        )
        selected_plan_ref, trinity_ref = persist_candidate_execution_plan(store, selected_plan, trinity_ref)
        compiled = compile_actual(store, CompileRequest(
            policy_ref=trinity_ref, registry_bundle_ref=registry.bundle_ref,
            method_execution_plan_ref=selected_plan_ref,
            method_metric_bindings=[MethodMetricBindingRequest(
                objective_id=objective_id, node_id="ex_ante_node", output_slot_id="result"
            )], return_selected_profile=True,
        ))
        assert compiled.ok is True, compiled.notes
        compiled_refs = {item.role: item.ref for item in compiled.derived_refs}
        graph_ref = ProgramGraphRef.model_validate(compiled_refs["program_graph"].model_dump(mode="python"))
        graph = validate_core_model_json_artifact(ProgramGraph, store, graph_ref)
        compiled_plan = validate_core_model_json_artifact(ExecPlan, store, compiled.exec_plan_ref)
        compiled_bindings = validate_core_model_json_artifact(MethodMetricBindingSet, store, compiled_refs["method_metric_binding_set"])
        assert len(compiled_bindings.bindings) == 1
    else:
'''
t=t[:start]+actual+''.join('    '+line if line.strip() else line for line in original.splitlines(keepends=True))+t[end:]
# Bind actual compiler output for the real-compiler mode after original seam assertions.
needle='    actual_method_output = ExAnteSimulationEstimator.pure_step('
t=t.replace(needle,'    if canonical_compile:\n        binding = compiled_bindings.bindings[0]\n'+needle,1)
# Both the principal plan and later deliberately-unavailable binding plan keep full graph order/posture.
t=t.replace('order=["ex_ante_node"],\n', 'order=compiled_plan.order if canonical_compile else ["ex_ante_node"],\n                policy_fidelity_level=compiled_plan.policy_fidelity_level if canonical_compile else None,\n',2)
# Add explicit variant to every call inside a comparison test (the complete AST-defined set).
parsed=ast.parse(t)
edits=[]
for fn in parsed.body:
 if not isinstance(fn,ast.FunctionDef) or not fn.name.startswith('test_'):continue
 if not any(isinstance(n,ast.Name) and n.id=='recompute_completed_ex_ante_rank_projection' for n in ast.walk(fn)):continue
 for n in ast.walk(fn):
  if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='_exercise_public_execute_method_metric_source':
   lines=t.splitlines(keepends=True); pos=sum(map(len,lines[:n.end_lineno-1]))+n.end_col_offset-1
   edits.append(pos)
for pos in sorted(edits,reverse=True):
 before=t[:pos].rstrip(); suffix=t[pos:]; t=before+(' ' if before.endswith(',') else ', ' )+'canonical_compile=True'+suffix
(H/'comparison_tests.py.txt').write_text(t)
