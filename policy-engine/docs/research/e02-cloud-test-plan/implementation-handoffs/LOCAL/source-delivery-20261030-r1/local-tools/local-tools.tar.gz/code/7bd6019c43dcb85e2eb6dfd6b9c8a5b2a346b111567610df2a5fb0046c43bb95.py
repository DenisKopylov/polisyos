from __future__ import annotations
import _abc
import gc
import ast
import builtins as _builtins
import contextvars
import dataclasses as _dataclasses
import dis, functools, hashlib, importlib, importlib.util, inspect as _inspect, json, os, sys, sysconfig, tomllib, types, typing
from collections.abc import Callable, Iterable, Mapping
from contextlib import contextmanager
from dataclasses import dataclass
from enum import Enum
from fractions import Fraction
from pathlib import Path
from importlib.machinery import SourceFileLoader
import copy
ROOT=Path.cwd()
source=ROOT/'LOCAL/raw/e02-execution-20261027/repairs/N7-protocol-identity-r1/pre/policy-engine/src/polisyos/runtime/quality/confidence_ledger.py'
tree=ast.parse(source.read_bytes(),filename=str(source))
module=types.ModuleType('identity_source_census')
sys.modules[module.__name__]=module
ns=vars(module)
ns.update(globals())
class ConfidenceLedgerError(Exception):
    pass
ns['ConfidenceLedgerError']=ConfidenceLedgerError
ns['_UNKNOWN_SOURCE_LITERAL']=object()
ns['_STATIC_FACADE_UNKNOWN']=ns['_UNKNOWN_SOURCE_LITERAL']
ns['_SOURCE_FACADE_NAMESPACE_EFFECT_GUARD']='__polisyos_static_namespace_effect_guard__'
ns['_READ_API_SURFACES_MODULE']='polisyos.data_forge.read_api.surfaces'
ns['_READ_API_SURFACE_ROUTES_MODULE']='polisyos.data_forge.read_api.surface_routes'
ns['_READ_API_PACKAGE_MODULE']='polisyos.data_forge.read_api'
ns['_READ_API_SURFACE_FIELDS']=('name','module','summary')
ns['_SOURCE_DERIVATION_FAILED']=object()
ns['_UNSUPPORTED_SOURCE_LITERAL']=object()
ns['_active_integrity_analysis']=lambda: None
future=ast.ImportFrom(module='__future__', names=[ast.alias(name='annotations')],level=0)
def install(node):
    m=ast.fix_missing_locations(ast.Module(body=[future, node],type_ignores=[]))
    exec(compile(m,str(source),'exec'),ns)
for name in ('_LiteralModuleGetattrProviderIndex','_AuthorityImportClosureSourceIndex','_SourceModuleImportRouteCandidate','_ProviderSourceGraphReconciliation','_LoaderOwnedCallableSlot'):
    install(copy.deepcopy(next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==name)))
missed={}
for node in tree.body:
    if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
        n=copy.deepcopy(node)
        n.decorator_list=[]
        try:
            install(n)
        except NameError as exc:
            missed[n.name]=str(exc)
ns['_active_integrity_analysis']=lambda: None

ns['BaseModel']=type('PlaceholderModel',(),{})
ns['PromotionObligationClass']=type('PlaceholderObligation',(),{})
ns['_LRU_CACHE_WRAPPER_TYPE']=type(functools.lru_cache(maxsize=1)(lambda: None))


raw=ROOT/'LOCAL/raw/e02-execution-20261027/repairs/N7-protocol-identity-r1/loader-fixture'
root_src=raw/'src'/'polisyos'
root_src.mkdir(parents=True,exist_ok=True)
package_file=root_src/'__init__.py'
package_file.write_text('\"\"\"Synthetic loader test package.\"\"\"\n')
source_file=root_src/'subject.py'
source_file.write_text("MODE = 'canonical'\n\ndef read_mode():\n    return MODE\n")
consumer_file=root_src/'consumer.py'
consumer_file.write_text("from polisyos.subject import read_mode\n\ndef consume():\n    return read_mode()\n")
class Analysis:
    code_cache=None
    def source_bytes(self,path): return path.read_bytes()
    def source_tree(self,path): return ast.parse(path.read_bytes(),filename=str(path))
ns['_active_integrity_analysis']=lambda: Analysis()
package_spec=importlib.util.spec_from_file_location('polisyos',package_file,submodule_search_locations=[str(root_src)])
package=importlib.util.module_from_spec(package_spec)
sys.modules[package_spec.name]=package
package_spec.loader.exec_module(package)
original_get_code=SourceFileLoader.get_code
def altered_get_code(self,fullname):
    altered=Path(self.path).read_text().replace("MODE = 'canonical'", "MODE = 'substituted'")
    return compile(altered,self.path,'exec',dont_inherit=True)
spec=importlib.util.spec_from_file_location('polisyos.subject',source_file,loader=SourceFileLoader('polisyos.subject',str(source_file)))
module=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=module
try:
    SourceFileLoader.get_code=altered_get_code
    spec.loader.exec_module(module)
finally:
    SourceFileLoader.get_code=original_get_code
consumer_spec=importlib.util.spec_from_file_location('polisyos.consumer',consumer_file)
consumer=importlib.util.module_from_spec(consumer_spec)
sys.modules[consumer_spec.name]=consumer
consumer_spec.loader.exec_module(consumer)
closure=ns['_resolve_authority_import_closure'](raw,'polisyos.consumer')
print('discovered source closure',closure)
_manifest,consistent=ns['_loaded_code_manifest_body'](raw,closure)
references=[]
facade,supplemental=ns['_source_facade_runtime_projection'](raw,closure,runtime_binding_references=references)
print('actual consumer mode',consumer.consume(),'selected held references',len(references))
print('exact loader?',type(spec.loader) is SourceFileLoader)
print('actual mode',module.read_mode())
print('loaded source-code manifest consistent?',consistent)
print('facade projection returned?',type(facade) is str,'supplemental closure',supplemental)
assert module.read_mode()=='substituted' and consumer.consume()=='substituted' and consistent and type(facade) is str and references
print('BOUNDED: synthetic imported module top-level state was altered; facade plus code-manifest checks both completed. This does not exercise N9 or its full import-time capture.')
