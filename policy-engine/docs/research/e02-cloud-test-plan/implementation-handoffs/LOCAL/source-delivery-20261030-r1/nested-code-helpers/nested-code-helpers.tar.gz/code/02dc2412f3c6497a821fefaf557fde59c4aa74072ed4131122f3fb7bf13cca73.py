"""Isolate one OpenAPI corruption test's cwd; capture its exact checker text."""

from __future__ import annotations

import contextlib
import hashlib
import inspect
import json
import os
import subprocess
import sys
from collections.abc import Iterator  # noqa: TC003 -- pytest may inspect hook annotations
from pathlib import Path
from types import ModuleType  # noqa: TC003 -- retained for runtime annotation consumers

import pytest

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
P = ROOT / "policy-engine"
D = P / (
    "docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/"
    "root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/"
    "deep-task-status-audit-20261027-r1"
)
TEST = "tests/unit/runtime/http/test_runtime_api_contract_hardening.py"
NODE = TEST + "::test_runtime_contract_gate_rejects_nested_epoch_semantic_corruption"
APP = P / "src/polisyos/runtime/http/app.py"
PLUGIN_NAME = "e02_q2_cwd_guard"
WORK_NAME = "q2-isolated-test-cwd"
RECEIPT = "q2-cwd-receipt.json"


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _check(condition: bool, reason: str) -> None:
    if not condition:
        raise RuntimeError(f"q2_cwd_harness_{reason}")


def _allocate(parent: Path) -> Path:
    """Create a fresh child; reject existing objects including dangling symlinks."""
    work = parent / WORK_NAME
    _check(not os.path.lexists(work), "workspace_already_exists")
    work.mkdir(mode=0o700, exist_ok=False)
    return work


def pytest_collection_modifyitems(items: list[pytest.Item]) -> None:
    """Fail before execution if the collected set differs from the bound node."""
    _check([item.nodeid for item in items] == [NODE], "unexpected_collection")


def _validate(item: pytest.Item) -> tuple[Path, dict[str, object]]:
    _check(item.nodeid == NODE, "unexpected_node")
    case_id = os.environ.get("E02_Q2_CASE_ID", "")
    _check(bool(case_id) and all(c.isalnum() or c in "-_" for c in case_id), "invalid_case")
    case = D / case_id
    temp = Path(os.environ.get("TMPDIR", ""))
    _check(temp.is_absolute() and not temp.is_symlink(), "invalid_temp")
    _check(temp.resolve(strict=True) == (case / "tmp").resolve(strict=True), "wrong_temp")
    _check(Path.cwd().resolve() == P.resolve(), "wrong_initial_cwd")
    _check(Path(item.path).resolve() == (P / TEST).resolve(), "wrong_test_path")
    _check(Path(item.config.rootpath).resolve() == P.resolve(), "wrong_pytest_root")
    _check(Path(item.config.inipath).resolve() == (P / "pytest.ini").resolve(), "wrong_pytest_ini")
    _check(item.config.getoption("importmode") == "importlib", "wrong_import_mode")
    _check(bool(item.config.getini("strict_markers")), "strict_markers_disabled")
    _check(not os.environ.get("PYTEST_DISABLE_PLUGIN_AUTOLOAD"), "autoload_disabled")
    _check(Path(sys.prefix).resolve() == (P / ".venv").resolve(), "wrong_venv")
    _check(all(entry and Path(entry).is_absolute() for entry in sys.path), "relative_sys_path")
    _check(
        os.environ.get("POLISYOS_CAS_BACKEND", "filesystem") == "filesystem", "wrong_cas_backend"
    )
    _check(
        os.environ.get("POLISYOS_CACHE_HOME") == str(temp / "polisyos-cache"), "wrong_cache_root"
    )
    _check(os.environ.get("XDG_CACHE_HOME") == str(temp / "xdg"), "wrong_xdg_cache")
    _check(
        os.environ.get("PYTHONPYCACHEPREFIX") == str(temp / "empty-pycache"),
        "wrong_pycache_prefix",
    )
    _check(os.environ.get("PYTHONDONTWRITEBYTECODE") == "1", "bytecode_writes_enabled")
    plugin_dir = Path(os.environ.get("PYTHONPATH", ""))
    _check(plugin_dir.is_absolute() and not plugin_dir.is_symlink(), "invalid_plugin_path")
    _check(plugin_dir.resolve() == Path(__file__).resolve().parent, "wrong_plugin_path")
    _check(
        sorted(p.name for p in plugin_dir.iterdir()) == [f"{PLUGIN_NAME}.py"],
        "plugin_dir_not_exclusive",
    )
    _check(os.environ.get("PYTEST_PLUGINS") == PLUGIN_NAME, "wrong_plugin_selection")
    _check(_sha(Path(__file__)) == os.environ.get("E02_Q2_PLUGIN_SHA256"), "plugin_digest_mismatch")
    _check(_sha(P / TEST) == os.environ.get("E02_Q2_TEST_SHA256"), "test_digest_mismatch")
    _check(_sha(APP) == os.environ.get("E02_Q2_APP_SHA256"), "app_digest_mismatch")
    app = sys.modules.get("polisyos.runtime.http.app")
    _check(app is not None and Path(app.__file__).resolve() == APP.resolve(), "wrong_app_origin")
    _check(
        item.module.export_runtime_openapi_schema is app.export_runtime_openapi_schema,
        "wrong_export_owner",
    )
    defaults = inspect.signature(app.create_runtime_api_app).parameters
    _check(defaults["cas_root"].default == Path(".polisyos/cas"), "default_cas_changed")
    _check(defaults["repo_root"].default is None, "default_repo_root_changed")
    facts = {
        "nodeid": item.nodeid,
        "expected_source_head": os.environ.get("E02_Q2_SOURCE_HEAD"),
        "expected_source_tree": os.environ.get("E02_Q2_SOURCE_TREE"),
        "source_test_sha256": _sha(P / TEST),
        "source_app_sha256": _sha(APP),
        "app_origin": str(Path(app.__file__).resolve()),
        "app_default_cas": str(defaults["cas_root"].default),
        "app_default_repo_root": None,
        "pytest_root": str(item.config.rootpath),
        "pytest_ini": str(item.config.inipath),
        "import_mode": item.config.getoption("importmode"),
        "strict_markers": bool(item.config.getini("strict_markers")),
        "plugin_sha256": _sha(Path(__file__)),
        "python_executable": sys.executable,
        "python_prefix": sys.prefix,
        "python_version": sys.version,
        "sys_path_before": list(sys.path),
        "cas_backend": os.environ.get("POLISYOS_CAS_BACKEND", "filesystem"),
        "cas_root_override_present": "POLISYOS_CAS_ROOT" in os.environ,
        "execution_profile": os.environ.get("POLISYOS_EXECUTION_PROFILE", "<unset>"),
        "cache_home": os.environ["POLISYOS_CACHE_HOME"],
        "xdg_cache_home": os.environ.get("XDG_CACHE_HOME"),
        "pycache_prefix": os.environ.get("PYTHONPYCACHEPREFIX"),
        "profile_limit": (
            "cwd differs only during this one test body; imports, other cwd-sensitive "
            "lookups and any background threads have a bounded unresolved scope"
        ),
    }
    return temp, facts


class _ObservedSubprocess:
    """Delegate without changing call arguments/results; retain test-consumed checker text."""

    def __init__(self, target: ModuleType, temp: Path) -> None:
        self._target = target
        self._temp = temp
        self.calls: list[dict[str, object]] = []
        self.evidence_errors: list[str] = []

    def __getattr__(self, name: str) -> object:
        return getattr(self._target, name)

    def run(self, *args: object, **kwargs: object) -> subprocess.CompletedProcess[str]:
        result = self._target.run(*args, **kwargs)
        argv = args[0] if args else kwargs.get("args")
        if not isinstance(argv, (list, tuple)) or len(argv) < 2:
            self.evidence_errors.append("unexpected_nonsequence_command")
            return result
        if str(argv[1]) != "tools/ops_runners/runtime/check_runtime_api_contract.py":
            self.evidence_errors.append("unexpected_test_subprocess")
            return result
        if (
            len(argv) != 5
            or str(argv[0]) != sys.executable
            or str(argv[2]) != "--openapi"
            or str(argv[4]) != "--skip-client-drift"
            or Path(str(kwargs.get("cwd"))).resolve() != P.resolve()
            or kwargs.get("capture_output") is not True
            or kwargs.get("text") is not True
            or kwargs.get("check") is not False
        ):
            self.evidence_errors.append("checker_call_shape_mismatch")
        index = len(self.calls)
        record: dict[str, object] = {
            "argv": [str(value) for value in argv],
            "cwd": str(kwargs.get("cwd")),
            "capture_output": kwargs.get("capture_output"),
            "text": kwargs.get("text"),
            "check": kwargs.get("check"),
            "return_code": result.returncode,
        }
        if len(argv) == 5:
            comparison = Path(str(argv[3]))
            if not comparison.resolve().is_relative_to(self._temp.parent.resolve()):
                self.evidence_errors.append("comparison_outside_case")
            elif comparison.is_file():
                record["comparison_sha256"] = _sha(comparison)
                record["comparison_bytes"] = comparison.stat().st_size
            else:
                self.evidence_errors.append("comparison_missing")
        try:
            for name in ("stdout", "stderr"):
                value = getattr(result, name)
                if not isinstance(value, str):
                    raise TypeError(f"{name} is not test-consumed text")
                encoded = value.encode("utf-8")
                destination = self._temp / f"q2-checker-{index}.{name}.txt"
                with destination.open("xb") as stream:
                    stream.write(encoded)
                record[f"{name}_path"] = str(destination)
                record[f"{name}_sha256"] = hashlib.sha256(encoded).hexdigest()
                record[f"{name}_bytes"] = len(encoded)
        except (OSError, UnicodeError, TypeError) as exc:
            self.evidence_errors.append(f"output_delivery_{type(exc).__name__}")
        self.calls.append(record)
        return result


@contextlib.contextmanager
def _isolated_body(item: pytest.Item, temp: Path, facts: dict[str, object]) -> Iterator[None]:
    """Temporarily change only this test PID's cwd and restore it even on failure."""
    receipt = temp / RECEIPT
    _check(not os.path.lexists(receipt), "receipt_already_exists")
    work = _allocate(temp)
    before = Path.cwd().resolve()
    module = item.module
    original_subprocess = module.subprocess
    _check(original_subprocess is subprocess, "test_subprocess_not_original")
    observer = _ObservedSubprocess(original_subprocess, temp)
    module.subprocess = observer
    entered = False
    failure: str | None = None
    try:
        os.chdir(work)
        entered = True
        _check(Path.cwd().resolve() == work.resolve(), "working_directory_mismatch")
        yield
    except BaseException as exc:
        failure = type(exc).__name__
        raise
    finally:
        try:
            if entered:
                os.chdir(before)
        finally:
            module.subprocess = original_subprocess
        after = Path.cwd().resolve()
        cas = work / ".polisyos/cas"
        artifacts = cas / "artifacts/sha256"
        details = {
            **facts,
            "cwd_before": str(before),
            "cwd_during": str(work),
            "cwd_after": str(after),
            "cwd_restored": after == before,
            "private_cas_expected": str(cas),
            "private_cas_created": cas.is_dir() and not cas.is_symlink(),
            "private_cas_artifact_layout_created": artifacts.is_dir(),
            "test_body_exception_type": failure,
            "checker_calls": observer.calls,
            "evidence_errors": observer.evidence_errors,
            "checker_output_representation": (
                "complete text as returned to the test, encoded UTF-8; original raw "
                "subprocess bytes were not observed"
            ),
            "scope_limit": (
                "real pytest parent imported-source observer is separate; checker child "
                "imported code and arbitrary cwd-sensitive resources are not comprehensively "
                "observed"
            ),
        }
        try:
            with receipt.open("x", encoding="utf-8") as stream:
                json.dump(details, stream, indent=2, sort_keys=True)
                stream.write("\n")
        except OSError as exc:
            sys.stderr.write(f"q2_cwd_receipt_unavailable: {type(exc).__name__}\n")
            if failure is None:
                raise RuntimeError("q2_cwd_harness_receipt_unavailable") from exc
        if failure is None:
            _check(after == before, "cwd_not_restored")
            _check(cas.is_dir() and not cas.is_symlink() and artifacts.is_dir(), "cas_not_created")
            _check(
                len(observer.calls) == 1 and not observer.evidence_errors,
                "checker_evidence_missing",
            )


@pytest.hookimpl(wrapper=True, tryfirst=True)
def pytest_runtest_call(item: pytest.Item) -> Iterator[None]:
    temp, facts = _validate(item)
    with _isolated_body(item, temp, facts):
        return (yield)
