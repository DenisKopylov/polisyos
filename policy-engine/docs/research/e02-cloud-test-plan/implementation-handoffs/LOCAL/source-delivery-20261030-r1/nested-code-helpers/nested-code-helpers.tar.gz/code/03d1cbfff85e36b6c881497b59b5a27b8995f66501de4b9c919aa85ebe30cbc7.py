from types import FunctionType
from importlib import import_module
def body(callback):
    def inner():
        return callback("bridge_cell")
    callback = opaque
    return inner()
CODE = body.__code__
run = FunctionType(CODE, globals())
run(import_module)
