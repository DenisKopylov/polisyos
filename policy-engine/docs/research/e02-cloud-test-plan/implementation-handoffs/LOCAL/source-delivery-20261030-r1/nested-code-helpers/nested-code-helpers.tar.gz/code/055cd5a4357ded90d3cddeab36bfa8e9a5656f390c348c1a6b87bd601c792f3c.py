from pathlib import Path
import ast
import hashlib
import json

ROOT = Path.cwd()
OUT = ROOT / 'LOCAL/raw/e02-execution-20261027/repairs/V3-basis-history-r1/full-v3-r1/leaf-history-surface'
POST = OUT / 'postimages'
rows = []

def put(path, content):
    src = ROOT / path
    original = src.read_bytes() if src.exists() else None
    body = content.encode()
    target = POST / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(body)
    if path.endswith('.py'):
        ast.parse(content)
    rows.append({'path': path, 'pre_sha256': hashlib.sha256(original).hexdigest() if original is not None else None, 'post_sha256': hashlib.sha256(body).hexdigest(), 'status': 'new' if original is None else 'modified'})

def read(path):
    return (ROOT / path).read_text()

p = 'policy-engine/src/polisyos/core/contracts/runtime.py'
s = read(p)
new = '''class RunCandidateSimulationRetainedEvaluation(BaseModel):
    """Original evaluation occurrence retained under a verified Runtime decision.

    These refs describe the prior execution. They never claim that execution
    consumed the newly admitted acquisition source.
    """

    model_config = ConfigDict(extra="forbid")

    candidate_id: str = Field(min_length=1)
    candidate_content_hash: str = Field(pattern=r"^sha256:[0-9a-f]{64}$")
    design_problem_ref: str = Field(pattern=r"^sha256:[0-9a-f]{64}$")
    world_model_record_hash: str = Field(pattern=r"^sha256:[0-9a-f]{64}$")
    evaluation_job_id: str = Field(min_length=1)
    evaluation_run_id: str = Field(min_length=1)
    generation_run_id: str = Field(min_length=1)
    cycle_index: int = Field(ge=0)
    n4_source_ref: ArtifactRef
    context_job_ref: ArtifactRef
    n5_input_ref: ArtifactRef
    n5_execution_ref: ArtifactRef
    n5_result_ref: ArtifactRef
    basis_ref: ArtifactRef

    @model_validator(mode="after")
    def _verify_selected_refs(self) -> RunCandidateSimulationRetainedEvaluation:
        for ref, kind in (
            (self.n4_source_ref, "runtime.quality.n4_candidate_scenario_source"),
            (self.context_job_ref, "runtime.quality.cycle_substrate_context_job"),
            (self.n5_input_ref, "runtime.quality.candidate_simulation_n5_input"),
            (self.n5_execution_ref, "runtime.quality.candidate_simulation_execution"),
            (self.n5_result_ref, "polisyos.runtime.joint_simulation_result"),
            (self.basis_ref, "runtime_quality.acquisition_evaluation_basis"),
        ):
            if (
                ref.kind != kind
                or ref.media_type != "application/json"
                or ref.manifest_profile_sha256 is None
            ):
                raise ValueError("candidate_acquisition_retained_evaluation_ref_invalid")
        return self


class RunCandidateSimulationAcquisitionHistoryEntryV3(BaseModel):
    """Verified source admission with an unchanged, separate evaluation occurrence.

    Runtime resolves the entire source/decision/frontier/fold join before this
    display DTO is constructed. DTO validation alone is not that verification.
    """

    model_config = ConfigDict(extra="forbid")

    schema_version: Literal["policyos.runtime.run_candidate_simulation_acquisition_history.v3"]
    route_receipt_ref: ArtifactRef
    route_id: str = Field(pattern=r"^sha256:[0-9a-f]{64}$")
    action_generation: int = Field(ge=1)
    terminal_outcome: Literal["source_admitted_evaluation_retained"]
    admitted_source_ref: ArtifactRef
    growth_receipt_ref: ArtifactRef
    evaluation_decision_ref: ArtifactRef
    retained_evaluation: RunCandidateSimulationRetainedEvaluation
    source_admission_status: Literal["admitted"] = "admitted"
    evaluation_disposition: Literal["retained_prior"] = "retained_prior"
    reentry_receipt_ref: None = None
    old_candidate_id: None = None
    new_candidate_id: None = None
    new_candidate_source_ref: None = None
    origin_source_ref: None = None
    expected_origin_source_ref: None = None
    reentry_receipt_schema_version: None = None
    continuation_join_status: None = None
    origin_source_binding_status: None = None
    continuation: None = None
    currentness_status: Literal["not_established"] = "not_established"
    authority_purpose: Literal["candidate_observation_only"] = "candidate_observation_only"
    publication_authority: Literal[False] = False

    @model_validator(mode="after")
    def _verify_retention_refs(self) -> RunCandidateSimulationAcquisitionHistoryEntryV3:
        for ref, kind in (
            (self.route_receipt_ref, "runtime_quality.acquisition_route_loop_receipt"),
            (self.growth_receipt_ref, "runtime_quality.acquisition_world_growth_receipt"),
            (self.evaluation_decision_ref, "runtime_quality.acquisition_evaluation_decision"),
        ):
            if (
                ref.kind != kind
                or ref.media_type != "application/json"
                or ref.manifest_profile_sha256 is None
            ):
                raise ValueError("candidate_acquisition_retention_ref_invalid")
        if self.admitted_source_ref.manifest_profile_sha256 is None:
            raise ValueError("candidate_acquisition_admitted_source_profile_missing")
        return self


'''
s = s.replace('class RunCandidateSimulationProjection(BaseModel):', new + 'class RunCandidateSimulationProjection(BaseModel):', 1)
s = s.replace('    acquisition_history: tuple[RunCandidateSimulationAcquisitionHistoryEntry, ...] = ()', '    acquisition_history: tuple[\n        RunCandidateSimulationAcquisitionHistoryEntry | RunCandidateSimulationAcquisitionHistoryEntryV3,\n        ...,\n    ] = ()', 1)
put(p, s)
p = 'policy-engine/src/polisyos/core/contracts/__init__.py'
s = read(p)
s = s.replace('        "RunCandidateSimulationAcquisitionHistoryEntry",', '        "RunCandidateSimulationAcquisitionHistoryEntry",\n        "RunCandidateSimulationAcquisitionHistoryEntryV3",\n        "RunCandidateSimulationRetainedEvaluation",', 1)
s = s.replace('        RunCandidateSimulationAcquisitionHistoryEntry,', '        RunCandidateSimulationAcquisitionHistoryEntry,\n        RunCandidateSimulationAcquisitionHistoryEntryV3,\n        RunCandidateSimulationRetainedEvaluation,', 1)
s = s.replace('    "RunCandidateSimulationAcquisitionHistoryEntry",\n    "RunCandidateSimulationN5Observation",', '    "RunCandidateSimulationAcquisitionHistoryEntry",\n    "RunCandidateSimulationAcquisitionHistoryEntryV3",\n    "RunCandidateSimulationRetainedEvaluation",\n    "RunCandidateSimulationN5Observation",', 1)
put(p, s)
p = 'policy-engine/src/polisyos/runtime/http/routes/runs.py'
s = read(p)
s = s.replace('    RunCandidateSimulationAcquisitionHistoryEntry,', '    RunCandidateSimulationAcquisitionHistoryEntry,\n    RunCandidateSimulationAcquisitionHistoryEntryV3,', 1)
s = s.replace(') -> tuple[tuple[RunCandidateSimulationAcquisitionHistoryEntry, ...], str | None]:', ') -> tuple[\n    tuple[\n        RunCandidateSimulationAcquisitionHistoryEntry | RunCandidateSimulationAcquisitionHistoryEntryV3,\n        ...,\n    ],\n    str | None,\n]:', 1)
s = s.replace('        history_entries: list[RunCandidateSimulationAcquisitionHistoryEntry] = []', '        history_entries: list[\n            RunCandidateSimulationAcquisitionHistoryEntry\n            | RunCandidateSimulationAcquisitionHistoryEntryV3\n        ] = []', 1)
s = s.replace('                        expected_version="1.0",\n                        expected_job_id=head.job_id,', '                        expected_version=("1.0", "2.0"),\n                        expected_job_id=head.job_id,', 1)
s = s.replace('                route_receipt = AcquisitionRouteLoopReceipt.model_validate(route_payload)\n                receipt = route_receipt', '''                route_manifest = read_core_manifest_profile(store, route_receipt_ref)[0]
                if route_manifest.artifact_schema.version == "2.0":
                    # Dispatch by the selected manifest epoch before legacy parsing.
                    # The Runtime owner reopens the actual closure; payload flags
                    # and a readable decision blob cannot establish this join.
                    if not isinstance(route_payload, dict):
                        raise ValueError("acquisition_history_terminal_payload_invalid")
                    if route_payload.get("compiled_ref") != str(compiled_ref.artifact_id):
                        continue
                    from polisyos.runtime.quality.acquisition_evaluation_history import (
                        verify_acquisition_retention_history,
                    )

                    verified = verify_acquisition_retention_history(
                        artifact_store=store,
                        event_log=event_log,
                        control_store=control_store,
                        control_service=control_service,
                        head=head,
                        route_receipt_ref=route_receipt_ref,
                        compiled_ref=compiled_ref,
                        source_run_id=source_run_id,
                        source_job_id=source_job_id,
                        tenant_id=tenant_id,
                        cell_id=cell_id,
                    )
                    if verified.history_entry is not None:
                        if verified.legacy_receipt is not None:
                            raise ValueError("acquisition_history_v3_projection_ambiguous")
                        history_entries.append(
                            RunCandidateSimulationAcquisitionHistoryEntryV3.model_validate(
                                verified.history_entry
                            )
                        )
                        continue
                    if verified.legacy_receipt is None:
                        raise ValueError("acquisition_history_v3_projection_missing")
                    route_receipt = verified.legacy_receipt
                else:
                    route_receipt = AcquisitionRouteLoopReceipt.model_validate(route_payload)
                receipt = route_receipt''', 1)
s = s.replace('        if not matching_receipts:\n            if matching_incomplete:', '        if not matching_receipts and not history_entries:\n            if matching_incomplete:', 1)
put(p, s)

# Reader companion: preserve the legacy parser and dispatch explicitly by the new literal.
p = 'policy-engine/apps/runtime-dashboard/src/api/validators.ts'
s = read(p)
idx = s.index('const runCandidateSimulationAcquisitionHistoryEntrySchema = z')
v3 = '''const runCandidateSimulationRetainedEvaluationSchema = z
  .object({
    candidate_id: z.string().min(1),
    candidate_content_hash: z.string().regex(/^sha256:[0-9a-f]{64}$/),
    design_problem_ref: z.string().regex(/^sha256:[0-9a-f]{64}$/),
    world_model_record_hash: z.string().regex(/^sha256:[0-9a-f]{64}$/),
    evaluation_job_id: z.string().min(1),
    evaluation_run_id: z.string().min(1),
    generation_run_id: z.string().min(1),
    cycle_index: z.number().int().nonnegative(),
    n4_source_ref: coreArtifactRefSchema,
    context_job_ref: coreArtifactRefSchema,
    n5_input_ref: coreArtifactRefSchema,
    n5_execution_ref: coreArtifactRefSchema,
    n5_result_ref: coreArtifactRefSchema,
    basis_ref: coreArtifactRefSchema,
  })
  .strict()
  .superRefine((evaluation, context) => {
    const expectedKinds = {
      n4_source_ref: "runtime.quality.n4_candidate_scenario_source",
      context_job_ref: "runtime.quality.cycle_substrate_context_job",
      n5_input_ref: "runtime.quality.candidate_simulation_n5_input",
      n5_execution_ref: "runtime.quality.candidate_simulation_execution",
      n5_result_ref: "polisyos.runtime.joint_simulation_result",
      basis_ref: "runtime_quality.acquisition_evaluation_basis",
    } as const;
    for (const [field, kind] of Object.entries(expectedKinds)) {
      const ref = evaluation[field as keyof typeof expectedKinds];
      if (
        ref.kind !== kind || ref.media_type !== "application/json" ||
        ref.manifest_profile_sha256 == null
      ) {
        context.addIssue({ code: "custom", path: [field],
          message: "candidate_acquisition_retained_evaluation_ref_invalid" });
      }
    }
  });

export const runCandidateSimulationAcquisitionHistoryEntryV3Schema = z
  .object({
    schema_version: z.literal("policyos.runtime.run_candidate_simulation_acquisition_history.v3"),
    route_receipt_ref: coreArtifactRefSchema,
    route_id: z.string().regex(/^sha256:[0-9a-f]{64}$/),
    action_generation: z.number().int().positive(),
    terminal_outcome: z.literal("source_admitted_evaluation_retained"),
    admitted_source_ref: coreArtifactRefSchema,
    growth_receipt_ref: coreArtifactRefSchema,
    evaluation_decision_ref: coreArtifactRefSchema,
    retained_evaluation: runCandidateSimulationRetainedEvaluationSchema,
    source_admission_status: z.literal("admitted").default("admitted"),
    evaluation_disposition: z.literal("retained_prior").default("retained_prior"),
    reentry_receipt_ref: z.null().optional(),
    old_candidate_id: z.null().optional(),
    new_candidate_id: z.null().optional(),
    new_candidate_source_ref: z.null().optional(),
    origin_source_ref: z.null().optional(),
    expected_origin_source_ref: z.null().optional(),
    reentry_receipt_schema_version: z.null().optional(),
    continuation_join_status: z.null().optional(),
    origin_source_binding_status: z.null().optional(),
    continuation: z.null().optional(),
    currentness_status: z.literal("not_established"),
    authority_purpose: z.literal("candidate_observation_only"),
    publication_authority: z.literal(false),
  })
  .strict()
  .superRefine((entry, context) => {
    const expectedKinds = {
      route_receipt_ref: "runtime_quality.acquisition_route_loop_receipt",
      growth_receipt_ref: "runtime_quality.acquisition_world_growth_receipt",
      evaluation_decision_ref: "runtime_quality.acquisition_evaluation_decision",
    } as const;
    for (const [field, kind] of Object.entries(expectedKinds)) {
      const ref = entry[field as keyof typeof expectedKinds];
      if (
        ref.kind !== kind || ref.media_type !== "application/json" ||
        ref.manifest_profile_sha256 == null
      ) {
        context.addIssue({ code: "custom", path: [field],
          message: "candidate_acquisition_retention_ref_invalid" });
      }
    }
    if (entry.admitted_source_ref.manifest_profile_sha256 == null) {
      context.addIssue({ code: "custom", path: ["admitted_source_ref"],
        message: "candidate_acquisition_admitted_source_profile_missing" });
    }
  });

'''
s = s[:idx] + v3 + s[idx:]
s = s.replace('.array(runCandidateSimulationAcquisitionHistoryEntrySchema)', '.array(z.union([\n        runCandidateSimulationAcquisitionHistoryEntryV3Schema,\n        runCandidateSimulationAcquisitionHistoryEntrySchema,\n      ]))', 1)
put(p,s)

(OUT / 'manifest.json').write_text(json.dumps({'base': 'a581bc46babc6d14411ba3d3c3291086d3f3dc7e', 'canonical_mutated': False, 'runtime': 'UNRUN', 'files': rows}, indent=2) + '\n')
print(json.dumps({'postimages': len(rows), 'runtime': 'UNRUN', 'ast': 'passed'}))

# Preserve selected head order when v1 and v2 terminals occur together.
p = 'policy-engine/src/polisyos/runtime/http/routes/runs.py'
s = (POST / p).read_text()
s = s.replace('matching_receipts: list[tuple[Any, ArtifactRef, AcquisitionRouteLoopReceipt]] = []', 'matching_receipts: list[\n            tuple[\n                Any,\n                ArtifactRef,\n                AcquisitionRouteLoopReceipt | RunCandidateSimulationAcquisitionHistoryEntryV3,\n            ]\n        ] = []', 1)
s = s.replace('''                        history_entries.append(
                            RunCandidateSimulationAcquisitionHistoryEntryV3.model_validate(
                                verified.history_entry
                            )
                        )''', '''                        matching_receipts.append(
                            (
                                head,
                                route_receipt_ref,
                                RunCandidateSimulationAcquisitionHistoryEntryV3.model_validate(
                                    verified.history_entry
                                ),
                            )
                        )''', 1)
s = s.replace('''        for _head, route_receipt_ref, route_receipt in matching_receipts:
            if route_receipt.terminal_outcome''', '''        for _head, route_receipt_ref, route_receipt in matching_receipts:
            if isinstance(route_receipt, RunCandidateSimulationAcquisitionHistoryEntryV3):
                history_entries.append(route_receipt)
                continue
            if route_receipt.terminal_outcome''', 1)
put(p, s)

p = 'policy-engine/apps/runtime-dashboard/src/features/runs/routes/tabs/OverviewTab.tsx'
s = read(p)
s = s.replace('import type { RunArtifactRef, RunDetailsView } from "@/api/validators";', 'import type { RunArtifactRef, RunDetailsView } from "@/api/validators";\nimport { runCandidateSimulationAcquisitionHistoryEntryV3Schema } from "@/api/validators";', 1)
s = s.replace('''            const row = asRecord(value);
            const reentry''', '''            const row = asRecord(value);
            if (row?.schema_version === "policyos.runtime.run_candidate_simulation_acquisition_history.v3") {
              const parsed = runCandidateSimulationAcquisitionHistoryEntryV3Schema.safeParse(row);
              if (!projectionKnown || projection.artifact_status !== "resolved" || !parsed.success) {
                return <p key={index} data-testid="overview-acquisition-history-refused">
                  {t("pages.runs.candidateSimulation.acquisitionHistoryRefused")}
                </p>;
              }
              const retained = parsed.data;
              const evaluation = retained.retained_evaluation;
              return (
                <div key={index} className="space-y-1 border-t pt-2" data-testid="overview-acquisition-history-retained">
                  <p>{t("pages.runs.candidateSimulation.acquisitionRoute", {
                    route: retained.route_id, generation: String(retained.action_generation),
                  })}</p>
                  <p>{t("pages.runs.candidateSimulation.acquisitionOutcome", {
                    outcome: retained.terminal_outcome,
                  })}</p>
                  <p>{t("pages.runs.candidateSimulation.acquisitionRetainedExplanation")}</p>
                  <p className="text-xs break-all">{t("pages.runs.candidateSimulation.acquisitionAdmittedSource", {
                    ref: retained.admitted_source_ref.artifact_id,
                  })}</p>
                  <p className="text-xs break-all">{t("pages.runs.candidateSimulation.acquisitionRetainedSource", {
                    ref: evaluation.n4_source_ref.artifact_id,
                  })}</p>
                  <p>{t("pages.runs.candidateSimulation.acquisitionRetainedCandidate", {
                    candidate: evaluation.candidate_id,
                  })}</p>
                  <p>{t("pages.runs.candidateSimulation.acquisitionRetainedOccurrence", {
                    run: evaluation.evaluation_run_id, job: evaluation.evaluation_job_id,
                    cycle: String(evaluation.cycle_index),
                  })}</p>
                  <p className="text-xs break-all">{t("pages.runs.candidateSimulation.acquisitionRetentionDecision", {
                    ref: retained.evaluation_decision_ref.artifact_id,
                  })}</p>
                  <p>{t("pages.runs.candidateSimulation.acquisitionCurrentness", {
                    status: retained.currentness_status,
                  })}</p>
                </div>
              );
            }
            const reentry''', 1)
put(p,s)
translations = {
'en': {
'acquisitionRetainedExplanation': 'At the recorded decision, the admitted source did not require a new evaluation within the verified scope. The prior evaluation keeps its original inputs.',
'acquisitionAdmittedSource': 'Newly admitted source: {ref}',
'acquisitionRetainedSource': 'Prior evaluation source: {ref}',
'acquisitionRetainedCandidate': 'Retained candidate: {candidate}',
'acquisitionRetainedOccurrence': 'Original evaluation: run {run}, job {job}, cycle {cycle}',
'acquisitionRetentionDecision': 'Historical retention decision: {ref}',
},
'uk': {
'acquisitionRetainedExplanation': 'На час зафіксованого рішення допущене джерело не вимагало нової оцінки в перевірених межах. Попередня оцінка зберігає початкові входи.',
'acquisitionAdmittedSource': 'Нове допущене джерело: {ref}',
'acquisitionRetainedSource': 'Джерело попередньої оцінки: {ref}',
'acquisitionRetainedCandidate': 'Збережений кандидат: {candidate}',
'acquisitionRetainedOccurrence': 'Початкова оцінка: запуск {run}, завдання {job}, цикл {cycle}',
'acquisitionRetentionDecision': 'Історичне рішення про збереження оцінки: {ref}',
},
'ru': {
'acquisitionRetainedExplanation': 'На момент записанного решения допущенный источник не требовал новой оценки в проверенных пределах. Предыдущая оценка сохраняет исходные входы.',
'acquisitionAdmittedSource': 'Новый допущенный источник: {ref}',
'acquisitionRetainedSource': 'Источник предыдущей оценки: {ref}',
'acquisitionRetainedCandidate': 'Сохранённый кандидат: {candidate}',
'acquisitionRetainedOccurrence': 'Исходная оценка: запуск {run}, задание {job}, цикл {cycle}',
'acquisitionRetentionDecision': 'Историческое решение о сохранении оценки: {ref}',
},
}
for locale, labels in translations.items():
    p = f'policy-engine/apps/runtime-dashboard/src/shared/i18n/locales/{locale}.json'
    s=read(p)
    marker='        "acquisitionHistoryRefused":'
    idx=s.index(marker)
    s=s[:idx]+''.join('        '+json.dumps(k)+': '+json.dumps(v,ensure_ascii=False)+',\n' for k,v in labels.items())+s[idx:]
    json.loads(s)
    put(p,s)

p='policy-engine/apps/runtime-dashboard/src/test/fixtures/retainedAcquisitionHistory.ts'
put(p, '''import type { components } from "@/api/types";

/** Display-only wire fixture; it is not a Runtime verifier success witness. */
export function retainedAcquisitionHistoryFixture(): components["schemas"]["RunCandidateSimulationAcquisitionHistoryEntryV3"] {
  const ref = (kind: string, digit: string) => ({
    artifact_id: `sha256:${digit.repeat(64)}`,
    manifest_profile_sha256: `sha256:${"f".repeat(64)}`,
    kind,
    media_type: "application/json",
  });
  return {
    schema_version: "policyos.runtime.run_candidate_simulation_acquisition_history.v3",
    route_receipt_ref: ref("runtime_quality.acquisition_route_loop_receipt", "1"),
    route_id: `sha256:${"2".repeat(64)}`,
    action_generation: 3,
    terminal_outcome: "source_admitted_evaluation_retained",
    admitted_source_ref: ref("data.snapshot", "3"),
    growth_receipt_ref: ref("runtime_quality.acquisition_world_growth_receipt", "4"),
    evaluation_decision_ref: ref("runtime_quality.acquisition_evaluation_decision", "5"),
    retained_evaluation: {
      candidate_id: "candidate-prior",
      candidate_content_hash: `sha256:${"6".repeat(64)}`,
      design_problem_ref: `sha256:${"7".repeat(64)}`,
      world_model_record_hash: `sha256:${"8".repeat(64)}`,
      evaluation_job_id: "job-original",
      evaluation_run_id: "run-original",
      generation_run_id: "generation-original",
      cycle_index: 1,
      n4_source_ref: ref("runtime.quality.n4_candidate_scenario_source", "9"),
      context_job_ref: ref("runtime.quality.cycle_substrate_context_job", "a"),
      n5_input_ref: ref("runtime.quality.candidate_simulation_n5_input", "b"),
      n5_execution_ref: ref("runtime.quality.candidate_simulation_execution", "c"),
      n5_result_ref: ref("polisyos.runtime.joint_simulation_result", "d"),
      basis_ref: ref("runtime_quality.acquisition_evaluation_basis", "e"),
    },
    source_admission_status: "admitted",
    evaluation_disposition: "retained_prior",
    currentness_status: "not_established",
    authority_purpose: "candidate_observation_only",
    publication_authority: false,
  };
}
''')
p='policy-engine/apps/runtime-dashboard/src/api/validators.test.ts'
s=read(p)
s='import { retainedAcquisitionHistoryFixture } from "@/test/fixtures/retainedAcquisitionHistory";\n'+s
marker='  it("preserves verified acquisition history in a freshly parsed run response", () => {'
idx=s.index(marker)
s=s[:idx]+'''  it("parses retained history separately from a new evaluation and refuses malformed v3", () => {
    const payload = runDetailsPayload("projection only");
    const run = mutableRecord(payload.run);
    const row = retainedAcquisitionHistoryFixture();
    const candidate = {
      schema_version: "policyos.runtime.run_candidate_simulation_projection.v1",
      run_id: "run-projection-mask", artifact_status: "resolved",
      authority_purpose: "candidate_observation_only", publication_authority: false,
      source_ref: { artifact_id: `sha256:${"a".repeat(64)}`,
        kind: "runtime.compiled_recursive_generation_cycle", media_type: "application/json" },
      source_content_hash: `sha256:${"a".repeat(64)}`, n5_observations: [],
      acquisition_history: [row], acquisition_history_limitation_code: null,
    };
    run.candidate_simulation = candidate;
    const parsed = runDetailsSchema.parse(payload).run.candidate_simulation!;
    expect(parsed.acquisition_history[0]).toMatchObject({
      terminal_outcome: "source_admitted_evaluation_retained",
      retained_evaluation: { evaluation_job_id: "job-original", cycle_index: 1 },
      publication_authority: false, currentness_status: "not_established",
    });
    for (const change of [
      { schema_version: "policyos.runtime.run_candidate_simulation_acquisition_history.v4" },
      { new_candidate_id: "candidate-new" },
      { continuation: {} },
      { retained_evaluation: null },
      { evaluation_decision_ref: null },
      { publication_authority: true },
      { currentness_status: "current" },
      { admitted_source_ref: { ...row.admitted_source_ref, manifest_profile_sha256: null } },
      { retained_evaluation: { ...row.retained_evaluation, n5_execution_ref: null } },
    ]) {
      candidate.acquisition_history = [{ ...row, ...change } as typeof row];
      expect(() => runDetailsSchema.parse(payload)).toThrow();
    }
  });

'''+s[idx:]
put(p,s)
p='policy-engine/apps/runtime-dashboard/src/features/runs/routes/tabs/OverviewTab.test.tsx'
s=read(p)
s='import { retainedAcquisitionHistoryFixture } from "@/test/fixtures/retainedAcquisitionHistory";\n'+s
marker='  it("renders same-candidate history only with a joined source and root origin", () => {'
idx=s.index(marker)
s=s[:idx]+'''  it("shows the admitted source and original retained evaluation separately", () => {
    const projection = sameCandidateAcquisitionHistoryProjection();
    overviewState.run.candidate_simulation = {
      ...projection, acquisition_history: [retainedAcquisitionHistoryFixture()],
    };
    renderWithProviders(<OverviewTab />);
    const history = screen.getByTestId("overview-acquisition-history-retained");
    expect(history).toHaveTextContent("Newly admitted source: sha256:" + "3".repeat(64));
    expect(history).toHaveTextContent("Prior evaluation source: sha256:" + "9".repeat(64));
    expect(history).toHaveTextContent("Original evaluation: run run-original, job job-original, cycle 1");
    expect(history).toHaveTextContent("Retained candidate: candidate-prior");
    expect(history).toHaveTextContent("Currentness: not_established");
    expect(history).not.toHaveTextContent("Re-entry candidate:");
  });

  it("withholds a v3 row whose retained evaluation tuple was removed", () => {
    const projection = sameCandidateAcquisitionHistoryProjection();
    overviewState.run.candidate_simulation = {
      ...projection,
      acquisition_history: [{ ...retainedAcquisitionHistoryFixture(), retained_evaluation: null }],
    };
    renderWithProviders(<OverviewTab />);
    expect(screen.queryByTestId("overview-acquisition-history-retained")).not.toBeInTheDocument();
    expect(screen.getByTestId("overview-acquisition-history-refused")).toBeVisible();
  });

'''+s[idx:]
put(p,s)

# Mandatory documentation/release companions describe rollout and explicit evidence limits.
for p, text in {
'policy-engine/src/polisyos/core/contracts/README.md': '''\n## Retained acquisition evaluation history\n\n`RunCandidateSimulationAcquisitionHistoryEntryV3` is a distinct candidate-only\nvariant of `RunCandidateSimulationProjection.acquisition_history`. It separates\nthe newly admitted source, growth and decision refs from\n`RunCandidateSimulationRetainedEvaluation`, whose refs retain the original\nevaluation occurrence. Legacy unversioned/v2 DTO semantics remain unchanged.\nShape validation does not establish the Runtime closure, current eligibility,\ncurrentness, or publication authority.\n''',
'policy-engine/src/polisyos/runtime/http/routes/README.md': '''\n## Acquisition history v3\n\nFresh run GET dispatches terminal manifests by version before parsing the\nlegacy terminal. Route `@2.0` uses\n`acquisition_evaluation_history.verify_acquisition_retention_history`, which\nreopens the selected source, growth, decision, frontier and verified route fold.\nOnly its retained projection enters the v3 DTO. Foreign, unknown, incomplete or\nmismatched closure returns typed incomplete history; readable blobs or payload\nflags do not grant a successful join. Legacy-shaped verified v2 terminals use\nthe existing no-growth/reentry renderer. Retained rows keep all new-evaluation\nfields null and preserve original evaluation inputs and occurrence identity.\nCurrentness remains `not_established`, authority remains\n`candidate_observation_only`, and publication authority remains false.\n''',
'policy-engine/apps/runtime-dashboard/README.md': '''\n## Acquisition history v3 rollout\n\nThe validator accepts the separate v3 retained-evaluation variant alongside\nlegacy history. The run overview shows the newly admitted source and original\nevaluation source/occurrence separately and withholds malformed v3 rows. This\nhistorical decision does not establish currentness or publication authority.\nRegenerate Runtime OpenAPI, the runtime client and dashboard API types together\nbefore rollout; strict older clients do not understand this new union member.\nThe display fixtures are wire-contract examples, not Runtime verifier evidence.\n''',
}.items():
    put(p,read(p)+text)
p='policy-engine/release-fragments/unreleased/2026-10-29-acquisition-retained-evaluation-history.toml'
put(p, '''id = "2026-10-29-acquisition-retained-evaluation-history"
title = "Expose verified retained evaluation acquisition history"
type = "added"
component = "runtime"
owner = "team-runtime"
summary = "Add the distinct v3 candidate history variant for a newly admitted source that retains the original evaluation occurrence."
evidence = ["tests/unit/core/contracts/test_run_candidate_simulation_acquisition_history_v3.py", "apps/runtime-dashboard/src/api/validators.test.ts", "apps/runtime-dashboard/src/features/runs/routes/tabs/OverviewTab.test.tsx"]
compatibility = "Legacy history DTOs retain their meaning; the history union gains a distinct v3 retained member. Strict old clients require regeneration before rollout."
change_class = "schema-openapi-abi"
surface_classification = "public_stable: polisyos.runtime"
migration = "Regenerate Runtime OpenAPI, runtime API client, dashboard API types and public-surface inventory together before enabling the route terminal emitter."
api = "Fresh run GET exposes separate admitted source/growth/decision refs and the original retained evaluation tuple through the Runtime owner verifier."
limitations = "History is candidate observation only; currentness remains not_established and publication authority remains false. Display fixtures do not establish Runtime verification."
generated_client_compatibility = "requires_regeneration"
public_surface_inventory_reviewed = false
migration_docs = ["src/polisyos/runtime/http/routes/README.md", "apps/runtime-dashboard/README.md"]
runbook_docs = []

[[compatibility_change]]
id = "acquisition-history-v3-retained-evaluation"
change_class = "schema-openapi-abi"
impact = "additive"
surface = "public_stable: polisyos.runtime RunCandidateSimulationProjection.acquisition_history"
owner = "team-runtime"
version_owner = "team-runtime"
deprecation_window = "2 minor releases"
release_note = "Acquisition history separates new source admission from the original retained evaluation."
generated_client_compatibility = "requires_regeneration"
migration_docs = ["src/polisyos/runtime/http/routes/README.md", "apps/runtime-dashboard/README.md"]
runbook_docs = []
''')

# One manifest entry per canonical postimage (later puts replace earlier proposals).
unique={row['path']: row for row in rows}
(OUT/'manifest.json').write_text(json.dumps({'base':'a581bc46babc6d14411ba3d3c3291086d3f3dc7e','canonical_mutated':False,'runtime':'UNRUN','files':list(unique.values())},indent=2)+'\n')
print(json.dumps({'postimages':len(unique),'runtime':'UNRUN','ast':'passed'}))
p='policy-engine/tests/unit/core/contracts/test_run_candidate_simulation_acquisition_history_v3.py'
put(p, '''"""Wire-contract negatives for the distinct retained-evaluation history epoch.

These DTO samples are not producer, source admission, or Runtime success evidence.
The integrated served oracle must separately prove the owner/CAS/action/GET chain.
"""

from __future__ import annotations

from copy import deepcopy
from typing import Any

import pytest
from pydantic import ValidationError

from polisyos.core.contracts import (
    RunCandidateSimulationAcquisitionHistoryEntryV3 as PublicHistoryEntryV3,
)
from polisyos.core.contracts.runtime import (
    RunCandidateSimulationAcquisitionHistoryEntry,
    RunCandidateSimulationAcquisitionHistoryEntryV3,
    RunCandidateSimulationProjection,
)


def _ref(kind: str, digit: str) -> dict[str, str]:
    return {
        "artifact_id": f"sha256:{digit * 64}",
        "manifest_profile_sha256": f"sha256:{'f' * 64}",
        "kind": kind,
        "media_type": "application/json",
    }


def _wire_row() -> dict[str, Any]:
    return {
        "schema_version": "policyos.runtime.run_candidate_simulation_acquisition_history.v3",
        "route_receipt_ref": _ref("runtime_quality.acquisition_route_loop_receipt", "1"),
        "route_id": f"sha256:{'2' * 64}",
        "action_generation": 3,
        "terminal_outcome": "source_admitted_evaluation_retained",
        "admitted_source_ref": _ref("data.snapshot", "3"),
        "growth_receipt_ref": _ref("runtime_quality.acquisition_world_growth_receipt", "4"),
        "evaluation_decision_ref": _ref("runtime_quality.acquisition_evaluation_decision", "5"),
        "retained_evaluation": {
            "candidate_id": "candidate-prior",
            "candidate_content_hash": f"sha256:{'6' * 64}",
            "design_problem_ref": f"sha256:{'7' * 64}",
            "world_model_record_hash": f"sha256:{'8' * 64}",
            "evaluation_job_id": "job-original",
            "evaluation_run_id": "run-original",
            "generation_run_id": "generation-original",
            "cycle_index": 1,
            "n4_source_ref": _ref("runtime.quality.n4_candidate_scenario_source", "9"),
            "context_job_ref": _ref("runtime.quality.cycle_substrate_context_job", "a"),
            "n5_input_ref": _ref("runtime.quality.candidate_simulation_n5_input", "b"),
            "n5_execution_ref": _ref("runtime.quality.candidate_simulation_execution", "c"),
            "n5_result_ref": _ref("polisyos.runtime.joint_simulation_result", "d"),
            "basis_ref": _ref("runtime_quality.acquisition_evaluation_basis", "e"),
        },
    }


def test_v3_union_preserves_original_occurrence_without_new_evaluation_claim() -> None:
    assert PublicHistoryEntryV3 is RunCandidateSimulationAcquisitionHistoryEntryV3
    row = RunCandidateSimulationAcquisitionHistoryEntryV3.model_validate(_wire_row())
    projection = RunCandidateSimulationProjection.model_validate(
        {
            "run_id": "source-core-run",
            "artifact_status": "resolved",
            "source_ref": _ref("runtime.compiled_recursive_generation_cycle", "a"),
            "source_content_hash": f"sha256:{'a' * 64}",
            "acquisition_history": [row.model_dump(mode="json")],
        }
    )
    restored = RunCandidateSimulationProjection.model_validate_json(projection.model_dump_json())
    selected = restored.acquisition_history[0]
    assert isinstance(selected, RunCandidateSimulationAcquisitionHistoryEntryV3)
    assert selected.retained_evaluation.evaluation_job_id == "job-original"
    assert selected.retained_evaluation.cycle_index == 1
    assert selected.admitted_source_ref != selected.retained_evaluation.n4_source_ref
    assert selected.new_candidate_id is None
    assert selected.new_candidate_source_ref is None
    assert selected.reentry_receipt_ref is None
    assert selected.continuation is None
    assert selected.currentness_status == "not_established"
    assert selected.authority_purpose == "candidate_observation_only"
    assert selected.publication_authority is False
    with pytest.raises(ValidationError):
        RunCandidateSimulationAcquisitionHistoryEntry.model_validate(_wire_row())


@pytest.mark.parametrize(
    ("field", "value"),
    [
        ("schema_version", "policyos.runtime.run_candidate_simulation_acquisition_history.v4"),
        ("terminal_outcome", "reentry_completed"),
        ("new_candidate_id", "candidate-new"),
        ("new_candidate_source_ref", _ref("runtime.quality.n4_candidate_scenario_source", "e")),
        ("reentry_receipt_ref", _ref("runtime_quality.acquisition_overlay_reentry_receipt", "d")),
        ("continuation", {}),
        ("retained_evaluation", None),
        ("evaluation_decision_ref", None),
        ("currentness_status", "current"),
        ("publication_authority", True),
        ("authority_purpose", "publication"),
    ],
)
def test_v3_cannot_launder_retention_into_reentry_or_authority(field: str, value: Any) -> None:
    wire = _wire_row()
    wire[field] = value
    with pytest.raises(ValidationError):
        RunCandidateSimulationAcquisitionHistoryEntryV3.model_validate(wire)


@pytest.mark.parametrize(
    "field",
    ["n4_source_ref", "context_job_ref", "n5_input_ref", "n5_execution_ref", "n5_result_ref", "basis_ref"],
)
def test_v3_requires_each_exact_selected_prior_evaluation_ref(field: str) -> None:
    wire = _wire_row()
    prior = wire["retained_evaluation"]
    for corrupt in (None, {**prior[field], "kind": "foreign.artifact"},
                    {**prior[field], "manifest_profile_sha256": None}):
        changed = deepcopy(wire)
        changed["retained_evaluation"][field] = corrupt
        with pytest.raises(ValidationError):
            RunCandidateSimulationAcquisitionHistoryEntryV3.model_validate(changed)
''')

unique={row['path']: row for row in rows}
(OUT/'manifest.json').write_text(json.dumps({'base':'a581bc46babc6d14411ba3d3c3291086d3f3dc7e','authorized_successor':'558d24d33f6bfa13d314c033c078b76959ae2d99','canonical_mutated':False,'runtime':'UNRUN','files':list(unique.values())},indent=2)+'\n')
print(json.dumps({'postimages':len(unique),'runtime':'UNRUN','ast':'passed'}))
