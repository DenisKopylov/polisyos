from .api import ANALYTICS_FACADE_EXPORTS as source_map
wrapper = {}
wrapper.setdefault('nested', 'unrelated scalar')
opaque(wrapper)
