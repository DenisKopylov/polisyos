"""Stdlib control-plane checks; no actual product frames or native run claimed."""
from __future__ import annotations
import ast
import base64
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
from typing import Any

HERE=Path(__file__).resolve().parents[1];ROOT=HERE.parents[4]
spec=importlib.util.spec_from_file_location('_r3_gate',HERE/'receipt_gate.py');gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
source=json.loads((HERE/'source-postimages.json').read_text());index={path:row['git_blob'] for path,row in source.items()}
transport='tests.unit.scientist.orchestration.engine.runner.decimal_worker_transport';worker='polisyos.scientist.orchestration.engine.runner._activity_worker';wire='polisyos.scientist.orchestration.engine.runner.serialization'
pairs=[(transport,'execute_decimal_worker'),(transport,'DecimalTransportNode.execute'),(worker,'run_node_in_worker_sync'),(worker,'run_node_in_worker'),(wire,'deserialize_state'),(wire,'serialize_outcome')]
rows=[];frames=[]
for number,(module,name) in enumerate(pairs,1):
    rel='policy-engine/'+('src/' if module.startswith('polisyos.') else '')+module.replace('.','/')+'.py'
    row={'module':module,'qualname':name,'relative_path':rel,'resolved_path':str(ROOT/rel),'process_local_code_object_id':number,'code_sha256':str(number),'source_sha256':source[rel]['sha256'],'git_blob':index[rel],'expected_blob':index[rel],'compilation_match':True,'selected_first_start_consumed':True};rows.append(row)
    frames.append({'module':module,'qualname':name,'repo_path':rel,'pid':123,'code_object_id_process_local':number,'same_process_function_code_identity':True})
unknown={'relative_path':None,'qualname':'generated','module':'non_target','code_sha256':'unknown','compilation_match':False,'origin_error':'generated_source_unavailable'}
report={'pid':123,'selected_observation_mode':'first_start','selected_return_callbacks':0,'errors':[],'codes':rows+[unknown],'observed_selected_first_start_codes':rows,'distinct_captured_codes':7,'callback_invocations':20,'code_census_complete_for_observed_events':False}
value={'process':{'pid':123},'bounded_code_capture':report,'target_code_frames':frames}
check=lambda v:gate.qualify_capture(v,ROOT,index,'policy-engine/tests/_helpers/r2_source_observer.py','unused')+gate.qualify_positive_child(v)
assert check(value)==[],check(value)
negative=[]
for field,bad in [('source_sha256','wrong'),('compilation_match',False),('selected_first_start_consumed',False)]:
    altered=copy.deepcopy(value);altered['bounded_code_capture']['observed_selected_first_start_codes'][0][field]=bad;assert check(altered);negative.append(field)
altered=copy.deepcopy(value);altered['target_code_frames'].pop();assert check(altered);negative.append('missing sixth actual target')
altered=copy.deepcopy(value);altered['target_code_frames'][0]['code_object_id_process_local']=999;assert check(altered);negative.append('unbound CodeType')
altered=copy.deepcopy(value);altered['bounded_code_capture']['code_census_complete_for_observed_events']=True;altered['bounded_code_capture']['observed_selected_first_start_codes'][0]['selected_first_start_consumed']=False;assert check(altered);negative.append('global marker cannot replace selected callback proof')
# Exercise actual forwarding code, not a text marker.
tree=ast.parse((HERE/'observer.py').read_text());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='_TransportSender');events=[];ns={'Any':Any,'base64':base64,'hashlib':hashlib,'_transport_event':lambda event,**fields:events.append((event,fields))};exec(compile(ast.Module(body=[cls],type_ignores=[]),'<actual-transport-proxy>','exec'),ns)
class Sender:
    def send(self,message):self.actual=message;return self
    def close(self):return self
sender=Sender();proxy=ns['_TransportSender'](sender)
for message in [('result',b'exact\0bytes'),object(),('other',object())]:assert proxy.send(message) is sender and sender.actual is message
assert proxy.close() is sender
print(json.dumps({'status':'PASS','control_scope':'synthetic receipt reconciliation and actual proxy only','negative_controls':negative,'global_unknown_stays_not_established':True,'forwarding':'same original object/return for ordinary and unexpected shapes','native_or_product_execution':False},sort_keys=True))
