"""Exercise bounded terminal bytes and the shared actual-transfer budget."""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from polisyos.core.artifacts import PutOptions, SchemaInfo
from polisyos.core.artifacts.canonical_profile import CoreJsonReadLimits
from polisyos.core.artifacts.store import FileSystemCAS
from polisyos.core.canon import CanonSpec
from polisyos.core.trace import RunTerminality
from polisyos.core.trace.record import TraceRecord
from polisyos.runtime.http.services.adapters.core_run import (
    _bounded_terminal_json_read,
    _bounded_terminal_trace_facts,
    _iter_bounded_terminal_bytes,
)
from polisyos.scientist.nodes.builtins.decide.policy_runtime_method_metrics import (
    _ProjectionReadBudget,
)


def test_terminal_trace_consumes_actual_bytes_at_the_shared_limit(tmp_path: Path) -> None:
    """A byte below the actual trace refuses; exact and above preserve every line."""
    path = tmp_path / "trace.jsonl"
    raw = b'{"a":1}\n{"b":"x"}\n'
    path.write_bytes(raw)

    def read(cap: int) -> tuple[list[str], int]:
        budget = _ProjectionReadBudget(max_bytes=cap)
        fd = os.open(path, os.O_RDONLY)
        try:
            return list(_iter_bounded_terminal_bytes(fd, budget)), budget.observed_bytes
        finally:
            os.close(fd)

    with pytest.raises(ValueError, match="terminal_trace_aggregate_budget_exceeded"):
        read(len(raw) - 1)
    assert read(len(raw)) == (['{"a":1}', '{"b":"x"}'], len(raw))
    assert read(len(raw) + 1) == (['{"a":1}', '{"b":"x"}'], len(raw))

    path.write_bytes(b"x" * (2 * 1024 * 1024 + 1) + b"\n")
    with pytest.raises(ValueError, match="terminal_trace_record_exceeds_bound"):
        read(3 * 1024 * 1024)


def test_bounded_trace_retains_the_existing_lifecycle_contract(tmp_path: Path) -> None:
    """The streaming path still requires the actual leading/final owner facts."""
    root = tmp_path / "runs"
    run_id = "R_bounded_trace"
    directory = root / run_id
    directory.mkdir(parents=True)
    trace = directory / "trace.jsonl"
    start = TraceRecord(
        run_id=run_id,
        tenant_id="t",
        cell_id="c",
        phase="core",
        event="RUN_STARTED",
        run_terminality=RunTerminality.NON_TERMINAL,
    )
    end = TraceRecord(
        run_id=run_id,
        tenant_id="t",
        cell_id="c",
        phase="core",
        event="RUN_FINALIZED",
        run_terminality=RunTerminality.TERMINAL,
    )
    raw = (start.model_dump_json() + "\n" + end.model_dump_json() + "\n").encode()
    trace.write_bytes(raw)
    budget = _ProjectionReadBudget(max_bytes=len(raw))
    owner, terminal = _bounded_terminal_trace_facts(root, run_id, read_attempts=None, budget=budget)
    assert owner == start and terminal == end
    assert budget.observed_bytes == len(raw)

    trace.write_text(start.model_dump_json() + "\n", encoding="utf-8")
    with pytest.raises(ValueError, match="RUN_FINALIZED"):
        _bounded_terminal_trace_facts(
            root, run_id, read_attempts=None, budget=_ProjectionReadBudget()
        )


def test_real_selected_json_and_child_phases_share_one_byte_budget(tmp_path: Path) -> None:
    """A real CAS member charges selection, verification, and payload transfers."""
    store = FileSystemCAS(tmp_path / "cas")
    ref = store.put_json(
        {"message": "selected terminal payload"},
        PutOptions(
            kind="test.terminal_budget",
            media_type="application/json",
            schema=SchemaInfo(name="polisyos.tests.TerminalBudget", version="1.0"),
        ),
        canon_spec=CanonSpec(),
        return_selected_profile=True,
    )
    limits = CoreJsonReadLimits(
        max_bytes=4_096, max_depth=16, max_elements=100, max_manifest_bytes=8_192
    )
    observed = _ProjectionReadBudget()
    first = _bounded_terminal_json_read(store, ref, observed, limits=limits)
    assert first.value == {"message": "selected terminal payload"}
    exact = observed.observed_bytes
    assert exact > len(first.raw_payload_bytes)

    for cap in (exact, exact + 1):
        parent = _ProjectionReadBudget(max_bytes=cap)
        phase = _ProjectionReadBudget(parent=parent)
        read = _bounded_terminal_json_read(store, ref, phase, limits=limits)
        assert read.value == first.value
        assert phase.observed_bytes == parent.observed_bytes == exact
    parent = _ProjectionReadBudget(max_bytes=exact - 1)
    phase = _ProjectionReadBudget(parent=parent)
    with pytest.raises(ValueError):
        _bounded_terminal_json_read(store, ref, phase, limits=limits)
    assert parent.observed_bytes == phase.observed_bytes

    oversized = CoreJsonReadLimits(
        max_bytes=4, max_depth=16, max_elements=100, max_manifest_bytes=8_192
    )
    with pytest.raises(ValueError, match="bounded_read_refused"):
        _bounded_terminal_json_read(store, ref, _ProjectionReadBudget(), limits=oversized)
