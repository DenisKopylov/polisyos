from pathlib import Path
from collections import Counter
from datetime import UTC,datetime
import ast,difflib,hashlib,json,re,subprocess,tomllib
root=Path.cwd();r1=root/'LOCAL/raw/e02-execution-20261027/repairs/C49-local-r1';r2=r1.with_name('C49-local-r2')
sha=lambda b:hashlib.sha256(b).hexdigest()
old=json.loads((r1/'manifest.json').read_text());assert sha((r1/'manifest.json').read_bytes())=='96057de47779ce8329d7b1053555d1499e2cc98c0956febf9f1d3027fcfa6896'
rows_by={r['path']:r for r in old['paths']}
paths=sorted(set(rows_by)|{str(p.relative_to(r2/'postimages')) for p in (r2/'postimages').rglob('*') if p.is_file()})
rows=[];patches={'own-source.patch':[],'shared-owner-context.patch':[]};ast_count=0;mismatches=[]
for name in paths:
 path=r2/'postimages'/name
 if not path.exists():path=r1/'postimages'/name
 canonical_pre=r2/'canonical-preimages'/name
 if not canonical_pre.exists():canonical_pre=r1/'preimages'/name
 before=canonical_pre.read_bytes() if canonical_pre.exists() else b'';after=path.read_bytes()
 role=rows_by.get(name,{}).get('role','own_source_or_mandatory_companion')
 if name=='policy-engine/src/polisyos/scientist/orchestration/engine/README.md':role='shared_owner_context_only'
 if after==before:role='unchanged_from_canonical_base'
 if path.suffix=='.py':ast.parse(after.decode(),filename=name);ast_count+=1
 if path.suffix=='.toml':tomllib.loads(after.decode())
 current=root/name
 if canonical_pre.exists() and (not current.exists() or current.read_bytes()!=before):mismatches.append({'path':name,'role':role})
 if not canonical_pre.exists() and current.exists():mismatches.append({'path':name,'role':role,'reason':'new target exists'})
 row={'path':name,'role':role,'source_postimage':str(path.relative_to(root)),'postimage_sha256':sha(after),'postimage_bytes':len(after),
 'canonical_preimage':str(canonical_pre.relative_to(root)) if canonical_pre.exists() else None,'canonical_preimage_sha256':sha(before) if canonical_pre.exists() else None,'runtime':'UNRUN'}
 rows.append(row)
 filename='own-source.patch' if role=='own_source_or_mandatory_companion' else 'shared-owner-context.patch' if role=='shared_owner_context_only' else None
 if filename:
  patches[filename].append(''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+name if canonical_pre.exists() else '/dev/null',tofile='b/'+name)))
for filename,sections in patches.items():(r2/filename).write_text(''.join(sections))
# Contexts stay separate from primary targets; all three bind actual C41-r8 source.
owner_rows=[]
for prior in old['owner_contexts']:
 name=prior['path'];post=r2/'owner-contexts/C41-r8/postimages'/name
 if not post.exists():post=r1/'owner-contexts/C41-r8/postimages'/name
 pre=r1/'owner-contexts/C41-r8/preimages'/name
 assert sha(pre.read_bytes())==prior['preimage_sha256']
 ast.parse(post.read_text(),filename=name);ast_count+=1
 owner_rows.append({'path':name,'preimage':str(pre.relative_to(root)),'preimage_sha256':sha(pre.read_bytes()),'postimage':str(post.relative_to(root)),
 'postimage_sha256':sha(post.read_bytes()),'source_frame':'exact C41-r8 sparse postimage','runtime':'UNRUN'})
controls=json.loads((r2/'controls/index.json').read_text())['controls'];refs=0
for control in controls:
 source=(r2/control['source_postimage']).resolve();assert sha(source.read_bytes())==control['preimage_sha256']
 assert sha((r2/control['patch']).read_bytes())==control['patch_sha256']
 for node in control['nodes']:
  bits=node.split('::');name='policy-engine/'+bits[0];path=r2/'postimages'/name
  if not path.exists():path=r1/'postimages'/name
  if not path.exists():path=root/name
  module=ast.parse(path.read_text());fn=bits[-1].split('[',1)[0]
  assert any(isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==fn for n in ast.walk(module)),node
  if len(bits)==3:assert any(isinstance(n,ast.ClassDef) and n.name==bits[1] for n in ast.walk(module)),node
  refs+=1
# Primary patches never duplicate each other or the explicit C41 contexts.
changed={r['path'] for r in rows if r['role'] in {'own_source_or_mandatory_companion','shared_owner_context_only'}}
assert not changed.intersection(r['path'] for r in owner_rows)
# Current shared context drift is disclosed, never overwritten or repaired blindly.
owned_drift=[row for row in mismatches if row['role']=='own_source_or_mandatory_companion' and not row['path'].endswith('README.md')]
assert not owned_drift,owned_drift
head=subprocess.run(['git','rev-parse','HEAD'],capture_output=True,text=True,check=True).stdout.strip()
branch=subprocess.run(['git','symbolic-ref','--short','HEAD'],capture_output=True,text=True,check=True).stdout.strip();assert branch=='codex/e02-unified-local-20261009'
checks={'at':datetime.now(UTC).isoformat(),'status':'STATIC_ONLY_RUNTIME_UNRUN','observed_head':head,'observed_branch':branch,
 'effective_primary_postimages':len(rows),'effective_python_postimages':ast_count,'selected_file_type_denominator':dict(Counter(Path(r['path']).suffix for r in rows)),
 'owner_contexts':len(owner_rows),'control_recipes':len(controls),'control_node_refs':refs,'canonical_preimage_drift':mismatches,
 'performed':['stdlib AST/TOML/JSON parsing','exact inherited/direct source hashes','complete selected control sources/patches/nodes','disjoint effective primary/context target sets'],
 'not_performed':['product imports','pytest/native/ruff/typecheck/backend checks','removal/restoration execution','canonical/index/ref mutation'],'closure_ids':[]}
(r2/'static-admission.json').write_text(json.dumps(checks,indent=2)+'\n')
manifest={'schema_version':'e02.sparse_author_proposal.v2','slice_id':'C49-local-r2','status':'FROZEN_FOR_DELTA_INDEPENDENT_REVIEW_RUNTIME_UNRUN',
 'inherits':{'path':str((r1/'manifest.json').relative_to(root)),'sha256':sha((r1/'manifest.json').read_bytes()),'delivery':'existing local bytes; verified, not a Cloud ignored-path claim'},
 'review_addressed':{'path':'LOCAL/raw/e02-execution-20261027/reviews/C49-local-r1-independent.md','sha256':'75b31e225148b2cf83ce55b665d0667f123b4f5bd74ea563f6e7b93d6576364c','finding_ids':['R1','R2','R3','R4','R5'],'P40_bucket':'SAME existing current/proxy input/consumer admission class'},
 'initial_source_commit':old['initial_source_commit'],'initial_source_tree':old['initial_source_tree'],'criterion_routes':{'path':str((r1/'criterion-routes.json').relative_to(root)),'sha256':old['criterion_routes']['sha256']},
 'criterion_routes_locator':str((r1/'criterion-routes.json').relative_to(root)),'paths':rows,'owner_contexts':owner_rows,'static_admission':checks,
 'delivery_patches':[],'documents':[],'controls':{'path':'controls/index.json','sha256':sha((r2/'controls/index.json').read_bytes()),'status':'UNRUN'},
 'runtime_results':{'PASS':[],'FAIL':[],'ERROR':[],'SKIP':[],'UNRUN':['all effective product/affected/native consumers','all property removals and restorations']},
 'source_claim':'full direct primary deltas include inherited work; do not apply r1 primary patches first or overwrite shared files',
 'residuals':['B106 independently selected objective intent remains unbound','N5 work unit is not USD pricing/scientific authenticity','Core envelope does not attest restoration relation; differing byte layers retain candidate and explicit not_established without stability','Root owns actual source composition/public-generated inventories/native/served verification/G handoff'],
 'closure_ids':[]}
for path in [r2/'own-source.patch',r2/'shared-owner-context.patch',r2/'owner-contexts/C41-r8/generation-budget-context.patch',r1/'owner-contexts/C41-r8/horizon-budget-work-context.patch',r2/'owner-contexts/C41-r8/recursive-budget-context.patch']:
 manifest['delivery_patches'].append({'path':str(path.relative_to(root)),'sha256':sha(path.read_bytes()),'bytes':path.stat().st_size})
for path in [r2/'README.md',r2/'static-admission.json',r1/'plans/NATIVE-EXECUTION.md',*sorted((r2/'plans').glob('plan-*-template.json'))]:
 manifest['documents'].append({'path':str(path.relative_to(root)),'sha256':sha(path.read_bytes()),'bytes':path.stat().st_size})
(r2/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'manifest_sha256':sha((r2/'manifest.json').read_bytes()),'effective_postimages':len(rows),'owner_contexts':len(owner_rows),'control_recipes':len(controls),'canonical_preimage_drift':mismatches,'runtime':'UNRUN','patches':manifest['delivery_patches']},indent=2))
