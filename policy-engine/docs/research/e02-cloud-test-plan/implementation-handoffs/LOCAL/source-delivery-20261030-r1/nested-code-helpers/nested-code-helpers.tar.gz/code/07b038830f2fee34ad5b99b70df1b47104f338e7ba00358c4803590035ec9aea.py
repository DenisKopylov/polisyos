"""Bounded AST census of named source-acquisition lock references."""
from __future__ import annotations

import ast
import json
from pathlib import Path

root = Path("policy-engine/src/polisyos")
overlay = Path("LOCAL/raw/e02-execution-20261027/repairs/SQL-owner-chain-r3/postimages")
files = {p: p for p in root.rglob("*.py") if p.is_file()}
for path in (overlay / root).rglob("*.py"):
    relative = path.relative_to(overlay)
    files[relative] = path
names = {"run_serialized_acquisition", "_run_source_acquisition_serialized"}
rows, errors = [], []
for logical, physical in sorted(files.items(), key=lambda item: str(item[0])):
    try:
        tree = ast.parse(physical.read_bytes(), filename=str(logical))
    except SyntaxError as exc:
        errors.append({"path": str(logical), "error": str(exc)})
        continue
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name in names:
            rows.append({"path": str(logical), "line": node.lineno, "kind": "definition", "name": node.name})
        elif isinstance(node, ast.Attribute) and node.attr in names:
            rows.append({"path": str(logical), "line": node.lineno, "kind": "attribute", "name": node.attr})
        elif isinstance(node, ast.Constant) and isinstance(node.value, str) and node.value in names:
            rows.append({"path": str(logical), "line": node.lineno, "kind": "literal", "name": node.value})
rows.sort(key=lambda row: (row["path"], row["line"], row["kind"]))
print(json.dumps({
    "denominator": {"root": str(root), "file_type": "Python", "files": len(files)},
    "overlay": str(overlay),
    "parse_errors": errors,
    "references": rows,
    "unresolved_by_construction": ["dynamic aliases", "constructed attribute names", "exec", "outside-root callers"],
}, indent=2))
if errors:
    raise SystemExit(1)
