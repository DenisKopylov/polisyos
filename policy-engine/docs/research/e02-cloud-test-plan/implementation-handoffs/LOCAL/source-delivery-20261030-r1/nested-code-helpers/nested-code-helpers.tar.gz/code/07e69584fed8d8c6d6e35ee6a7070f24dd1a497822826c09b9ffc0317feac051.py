"""Small stdlib-only R3 projection/preservation controls; no product runtime."""

from __future__ import annotations

import ast
import hashlib
import json
from datetime import UTC, datetime, timedelta, timezone
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace

PACKET = Path(__file__).resolve().parent.parent
ROOT = PACKET.parents[4]
HELPER = PACKET / "postimages/policy-engine/tests/_helpers/g27_owner_generation_oracle.py"
TEST = PACKET / "postimages/policy-engine/tests/integration/runtime/http/test_g27_owner_generation_oracle.py"
OUTPUT = PACKET / "author-controls/output"


def main() -> None:
    OUTPUT.mkdir(exist_ok=False)
    namespace = {"__name__": "g27_stdlib_author_control", "__file__": str(HELPER)}
    exec(compile(HELPER.read_bytes(), str(HELPER), "exec"), namespace)
    canonical = namespace["canonical_bytes"]
    quantity = namespace["semantic_quantity"]
    fixture_cas = namespace["FixtureCAS"]
    rows = []

    def record(name: str, operation, expected: str | None = None) -> None:
        try:
            operation()
        except AssertionError as exc:
            if expected is None or expected not in str(exc):
                raise
            rows.append({"case": name, "outcome": "EXPECTED_REFUSAL", "reason": str(exc)})
        else:
            assert expected is None, name + ": missing expected refusal"
            rows.append({"case": name, "outcome": "PASS"})

    def positive_quantity() -> None:
        value = {
            "receipt": {
                "committed_at": datetime(2026, 10, 1, 14, 34, 56, tzinfo=timezone(timedelta(hours=2)))
            },
            "rows": [{"baseline": 10.0, "note": None, "count": 3, "flag": True}],
        }
        assert quantity(value) == {
            "receipt": {"committed_at": "2026-10-01T12:34:56Z"},
            "rows": [{"baseline": 10.0, "note": None, "count": 3, "flag": True}],
        }

    record("decoded-aware-datetime-and-float-generic-projection", positive_quantity)

    def fake_envelope_stays_data() -> None:
        fake = {"nested": {"_type": "float", "repr": "10"}}
        assert quantity(fake) == fake
        assert isinstance(quantity(fake)["nested"], dict)
        assert quantity(fake)["nested"] != 10.0

    record("escaped-native-shaped-mapping-is-not-a-scalar", fake_envelope_stays_data)
    record("naive-datetime-refused", lambda: quantity(datetime(2026, 1, 1)),
           "G27_SELECTED_SEMANTIC_NAIVE_DATETIME")
    record("nonfinite-refused", lambda: quantity(float("nan")), "G27_SELECTED_SEMANTIC_NONFINITE")
    record("unsupported-native-descriptor-refused", lambda: quantity(Decimal("10")),
           "G27_SELECTED_SEMANTIC_TYPE_UNSUPPORTED")

    # Execute only the actual two pure orchestration functions from the proposed
    # test AST, without importing pytest, FastAPI, Core or any product module.
    tree = ast.parse(TEST.read_bytes(), filename=str(TEST))
    functions = [node for node in tree.body if isinstance(node, ast.FunctionDef)
                 and node.name in {"_exchange", "_commit"}]
    assert {node.name for node in functions} == {"_exchange", "_commit"}
    scope = {}
    exec(compile(ast.fix_missing_locations(ast.Module(body=functions, type_ignores=[])),
                 str(TEST), "exec"), scope)

    def observed_200_before_reconciliation_failure() -> None:
        root = OUTPUT / "accepted-then-red/cas"
        evidence = OUTPUT / "accepted-then-red/evidence"
        cas = fixture_cas(root, evidence)
        state = root / "decision_validity"
        state.mkdir(parents=True)
        root_bytes = canonical({"generation": 7, "event_ref": "d" * 64})
        (state / "committed_source_root.json").write_bytes(root_bytes)
        selected_ref = {"artifact_id": "sha256:" + "a" * 64, "kind": "test.binding",
                        "media_type": "application/json", "manifest_profile_sha256": "sha256:" + "b" * 64}
        response_bytes = canonical({"binding_ref": selected_ref, "receipt": {"generation": 7}})
        body = {"slot_id": "source-a", "event_id": "accepted-with-failing-oracle"}

        def fail_accept(*_args) -> None:
            raise AssertionError("CONTROLLED_RECONCILIATION_FAILURE")

        response = SimpleNamespace(status_code=200, content=response_bytes,
                                   text=response_bytes.decode(), json=lambda: json.loads(response_bytes))
        env = {"oracle": SimpleNamespace(cas=cas, accept=fail_accept),
               "client": SimpleNamespace(post=lambda *_a, **_k: response), "headers": {}}
        try:
            scope["_commit"](env, "materializations", body)
        except AssertionError as exc:
            assert str(exc) == "CONTROLLED_RECONCILIATION_FAILURE"
        else:
            raise AssertionError("missing controlled reconciliation failure")
        events = [json.loads(line) for line in (evidence / "observations.jsonl").read_bytes().splitlines()]
        assert [event["kind"] for event in events] == ["http_command", "http_response", "http_reconciliation"]
        assert events[0]["body"] == body
        observed = events[1]
        assert observed["status"] == 200 and observed["selected_refs_observed"] == [selected_ref]
        assert (evidence / "members" / observed["response_member"]).read_bytes() == response_bytes
        assert (evidence / "members" / observed["committed_root_member"]).read_bytes() == root_bytes
        assert events[2]["predicate_provenance"] == "not_established"
        assert events[2]["error_type"] == "AssertionError"

    record("actual-commit-wrapper-retains-200-before-oracle-red", observed_200_before_reconciliation_failure)

    def malformed_selector_preserved() -> None:
        evidence = OUTPUT / "malformed-selector/evidence"
        cas = fixture_cas(OUTPUT / "malformed-selector/cas", evidence)
        ref = {"artifact_id": "missing-profile"}
        try:
            cas.selected(ref)
        except KeyError:
            pass
        else:
            raise AssertionError("missing malformed selector error")
        events = [json.loads(line) for line in (evidence / "observations.jsonl").read_bytes().splitlines()]
        assert events[0]["kind"] == "selected_attempt" and events[0]["ref"] == ref
        assert events[-1]["kind"] == "selected_result"
        assert events[-1]["predicate_provenance"] == "not_established"
        assert events[-1]["error_type"] == "KeyError"

    record("malformed-original-selector-survives-failure", malformed_selector_preserved)

    retained = ROOT / ("LOCAL/raw/e02-execution-20261027/repairs/G27-local-owner-oracle-r2/"
                       "author-quantity-controls/known-physical/members")
    blob = retained / "9e826a0bd5ac688f28d698ea8bf2370fc03cc6bbe0030a272724bc69dc8dd9ff"
    manifest = retained / "ecd931c4d3147db19be6d307f163eaf1cbac06c1b75a35860844e621b949aff4"
    raw, manifest_raw = blob.read_bytes(), manifest.read_bytes()
    manifest_value = json.loads(manifest_raw)
    ref = {key: manifest_value[key] for key in ("artifact_id", "kind", "media_type")}
    ref["manifest_profile_sha256"] = "sha256:3b498aa0d2b41d73c0a9f40a54ee6aa3842861e27b95b4861c5c7e5732b205d3"

    def selected_fixture(name: str, content: bytes):
        root = OUTPUT / name / "cas"
        evidence = OUTPUT / name / "evidence"
        cas = fixture_cas(root, evidence)
        hex_id = ref["artifact_id"][7:]
        base = root / "artifacts/sha256" / hex_id[:2] / hex_id[2:4]
        base.mkdir(parents=True)
        (base / (hex_id + ".blob")).write_bytes(content)
        (base / (hex_id + ".view." + ref["manifest_profile_sha256"][7:] + ".manifest.json")).write_bytes(manifest_raw)
        return cas, evidence

    def unchanged_selector_bad_content() -> None:
        content = raw + b"\n"
        cas, evidence = selected_fixture("bad-content", content)
        try:
            cas.selected(ref)
        except AssertionError as exc:
            assert str(exc) == "G27_SELECTED_CONTENT_MISMATCH"
        else:
            raise AssertionError("content mismatch not detected")
        events = [json.loads(line) for line in (evidence / "observations.jsonl").read_bytes().splitlines()]
        assert events[0]["ref"] == ref
        payload = next(event for event in events if event.get("part") == "payload")
        assert (evidence / "members" / payload["member"]).read_bytes() == content
        assert events[-1]["predicate_provenance"] == "not_established"

    record("unchanged-selector-corrupt-member-retained-before-refusal", unchanged_selector_bad_content)

    def structural_decoder_failure_preserved() -> None:
        cas, evidence = selected_fixture("controlled-decoder-error", raw)
        actual_decoder = namespace["selected_semantic_quantity"]

        def controlled_decoder_error(*_args):
            raise AssertionError("CONTROLLED_NORMATIVE_DECODER_FAILURE")

        namespace["selected_semantic_quantity"] = controlled_decoder_error
        try:
            try:
                cas.selected(ref)
            except AssertionError as exc:
                assert str(exc) == "CONTROLLED_NORMATIVE_DECODER_FAILURE"
            else:
                raise AssertionError("controlled decoder did not fail")
        finally:
            namespace["selected_semantic_quantity"] = actual_decoder
        events = [json.loads(line) for line in (evidence / "observations.jsonl").read_bytes().splitlines()]
        assert events[0]["ref"] == ref
        assert {event["part"] for event in events if event["kind"] == "selected_bytes"} == {"payload", "manifest"}
        assert events[-1]["predicate_provenance"] == "not_established"

    record("selected-physical-members-retained-before-controlled-decoder-red", structural_decoder_failure_preserved)
    result = {
        "schema": "g27-r3-stdlib-author-controls-v1",
        "source_helper_sha256": hashlib.sha256(HELPER.read_bytes()).hexdigest(),
        "source_test_sha256": hashlib.sha256(TEST.read_bytes()).hexdigest(),
        "cases": rows,
        "case_denominator": len(rows),
        "scope": "stdlib generic projection and actual author wrapper preservation only",
        "normative_core_decoder_execution": "UNRUN",
        "g27_product_runtime": "UNRUN",
        "G_acceptance": False,
        "closure_ids": [],
    }
    (PACKET / "author-controls/result.json").write_bytes(canonical(result))
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
