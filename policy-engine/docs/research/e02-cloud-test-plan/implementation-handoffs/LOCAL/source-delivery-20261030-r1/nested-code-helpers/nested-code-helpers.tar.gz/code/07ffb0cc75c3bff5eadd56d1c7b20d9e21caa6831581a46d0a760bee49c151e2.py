import hashlib, json, os, platform, resource, subprocess, sys, time
from pathlib import Path
from importlib import metadata
from xml.etree import ElementTree

ROOT = Path('/evidence/i2-r82')
SELF = Path(__file__)
OUT = ROOT / 'run-output'
BINDING = ROOT / 'launch-input-binding.json'
CORE = ROOT / 'source-admission' / 'source-admission.json'
REMOTE = ROOT / 'remote-readback.json'
CACHE_PREFIX = Path('/scratch/i2-r82/empty-pyc')
CASE = Path('/scratch/i2-r82/run')
EXPECTED_NAMES = {
    'test_dfk_01_census_reads_native_invalid_byte_git_filename',
    'test_dfk_01_native_invalid_byte_removal_control_detects_lossy_fsdecode',
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require_existing(path):
    path = Path(path)
    if not os.path.lexists(path):
        raise SystemExit(f'expected_existing_path_missing:{path}')
    for parent in reversed((path, *path.parents)):
        if not os.path.lexists(parent):
            raise SystemExit(f'path_ancestor_missing:{parent}')
        if parent.is_symlink():
            raise SystemExit(f'path_component_symlink:{parent}')
    return path


def require_absent_leaf(path):
    path = Path(path)
    if os.path.lexists(path):
        raise SystemExit(f'expected_fresh_path_exists:{path}')
    for parent in path.parents:
        if not os.path.lexists(parent):
            raise SystemExit(f'path_ancestor_missing:{parent}')
        if parent.is_symlink():
            raise SystemExit(f'path_component_symlink:{parent}')
    return path


def require_fresh_scratch_parent():
    if os.path.lexists(CASE.parent):
        raise SystemExit(f'scratch_parent_not_fresh:{CASE.parent}')
    for parent in CASE.parent.parents:
        if not os.path.lexists(parent):
            raise SystemExit(f'scratch_ancestor_missing:{parent}')
        if parent.is_symlink():
            raise SystemExit(f'scratch_ancestor_symlink:{parent}')
    for path in (CASE, CASE / 'tmp', CASE / 'cache', CASE / 'benchmarks', CACHE_PREFIX):
        if os.path.lexists(path):
            raise SystemExit(f'scratch_child_not_fresh:{path}')


def write(name, value):
    with (OUT / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def cgroup_snapshot():
    result = {}
    for name in ('memory.events', 'memory.peak', 'memory.current', 'memory.max', 'cpu.max'):
        path = Path('/sys/fs/cgroup') / name
        result[name] = path.read_text() if path.exists() else None
    return result


# Inputs, their ancestors, and the fresh output parent must be real paths before any product import.
for candidate in (SELF, BINDING, CORE, REMOTE):
    require_existing(candidate)
for mount in ('/tmp/src', '/tmp/tests', '/tmp/tools', '/tmp/pyproject.toml', '/tmp/uv.lock', '/tmp/pytest.ini'):
    require_existing(mount)
require_absent_leaf(OUT)
assert sys.platform == 'linux' and sys.version_info[:3] == (3, 14, 3)
assert sys.pycache_prefix == str(CACHE_PREFIX), (sys.pycache_prefix, str(CACHE_PREFIX))
assert sys.dont_write_bytecode is True
assert os.environ.get('PYTEST_ADDOPTS', '') == ''
assert os.environ.get('PYTEST_PLUGINS', '') == ''
assert os.environ.get('PYTEST_DISABLE_PLUGIN_AUTOLOAD', '') == ''
assert not os.path.lexists(CACHE_PREFIX), f'pycache_prefix_not_fresh:{CACHE_PREFIX}'
assert not os.path.lexists(CASE.parent), f'scratch_parent_not_fresh:{CASE.parent}'
assert not any(name == 'polisyos' or name.startswith(('polisyos.', 'tools.')) for name in sys.modules)

binding = json.loads(BINDING.read_text())
core = json.loads(CORE.read_text())
remote = json.loads(REMOTE.read_text())
expected_head = binding['source']['head']
expected_tree = binding['source']['tree']
expected_remote_sha = binding['source']['publication_readback_sha256']
expected_core_sha = binding['launch']['source_admission_sha256']
assert binding['launch']['python_cache_prefix'] == str(CACHE_PREFIX)
assert binding['launch']['runner_sha256'] == sha(SELF)
assert sha(CORE) == expected_core_sha
assert sha(REMOTE) == expected_remote_sha
assert core['base'] == expected_head and core['head'] == expected_head and core['tree'] == expected_tree
assert core['tracked_changed'] == [] and core['untracked_source'] == []
assert core['git_index_entries'] == binding['source']['git_index_entries'] and core['initial_pycache_empty'] is True
core_pins = {row['path']: row for row in core['pins']}
source_pins = binding['source']['host_pins']
assert len(core_pins) == len(source_pins) == 19
for row in source_pins:
    assert core_pins[row['path']]['sha256'] == row['sha256']
    assert core_pins[row['path']]['git_blob'] == row['git_blob']
assert remote['head'] == expected_head and remote['tree'] == expected_tree
assert remote['remote_head'] == expected_head and remote['remote_tree'] == expected_tree
assert remote['remote_ref'] == binding['source']['publication_ref']

mount_pins = binding['container']['runtime_mount_pins']
assert len(mount_pins) == 9
actual_mounts = {}
mountinfo = Path('/proc/self/mountinfo').read_text()
mount_by_point = {}
for line in mountinfo.splitlines():
    fields = line.split()
    if len(fields) > 5:
        mount_by_point[fields[4]] = fields
for row in mount_pins:
    path = require_existing(row['container_path'])
    assert sha(path) == row['sha256'], row
    candidates = [point for point in mount_by_point if str(path) == point or str(path).startswith(point.rstrip('/') + '/')]
    assert candidates, f'mount_not_found:{path}'
    mount_point = max(candidates, key=len)
    fields = mount_by_point[mount_point]
    assert 'ro' in fields[5].split(','), f'mount_not_readonly:{path}:via:{mount_point}'
    actual_mounts[str(path)] = sha(path)
expected_versions = binding['environment']['expected_distributions']
versions = {name: metadata.version(name) for name in expected_versions}
assert versions == expected_versions
assert len(versions) == binding['environment']['expected_distribution_count'] == 43
assert binding['environment']['all_43_expected_versions_match'] is True
assert binding['container']['id'] == '284ff777dbe539b15624ebf5aa85a427dfcb6696b54f8764f0d3a8c64a62f4b3'
assert binding['container']['image_id'] == 'sha256:f9d27fe06a2a3eff6d0dd4ee01c96efc6fb7c752670ba8582f2ee2f4383bc6c3'

# The R82 parent is fresh. Create only its scratch case; keep the unique pycache prefix absent.
require_fresh_scratch_parent()
CASE.parent.mkdir()
CASE.mkdir()
assert not os.path.lexists(CACHE_PREFIX)
assert any(' /scratch ' in line and ' - ext4 ' in line for line in mountinfo.splitlines())
OUT.mkdir()

argv = [
    '-q', '--tb=short', '--color=no', '-o', 'cache_dir=' + str(CASE / 'cache'),
    '--basetemp=' + str(CASE / 'tmp'),
    '--benchmark-storage=file://' + str(CASE / 'benchmarks'),
    '--junitxml=' + str(OUT / 'r82.xml'),
    'tests/unit/remediation/test_dfk_01.py::test_dfk_01_census_reads_native_invalid_byte_git_filename',
    'tests/unit/remediation/test_dfk_01.py::test_dfk_01_native_invalid_byte_removal_control_detects_lossy_fsdecode',
]
start = time.monotonic()
write('r82-admission.json', {
    'source_head': expected_head,
    'source_tree': expected_tree,
    'binding_sha256': sha(BINDING),
    'source_admission_sha256': sha(CORE),
    'remote_readback_sha256': sha(REMOTE),
    'runner_sha256': sha(SELF),
    'selectors': argv[-2:],
    'python': sys.version,
    'executable': sys.executable,
    'platform': platform.platform(),
    'filesystem_encoding': sys.getfilesystemencoding(),
    'filesystem_errors': sys.getfilesystemencodeerrors(),
    'git': subprocess.check_output(['git', '--version'], text=True).strip(),
    'distribution_versions': versions,
    'mount_pin_sha256': actual_mounts,
    'mountinfo': mountinfo,
    'cache_prefix': str(CACHE_PREFIX),
    'cache_prefix_absent_before_imports': True,
    'bytecode_writes_disabled': sys.dont_write_bytecode,
    'cgroup_before': cgroup_snapshot(),
    'scope': 'Two selected DFK-01 Linux tests; finite pytest-process module origins only. Child CLI process origins and C134 CodeType binding are not established.',
})

code = None
error = None
try:
    import pytest
    code = int(pytest.main(argv))
except BaseException as exc:
    error = {'type': type(exc).__name__, 'repr': repr(exc)}
    raise
finally:
    junit_path = OUT / 'r82.xml'
    junit = None
    if junit_path.is_file():
        document = ElementTree.parse(junit_path).getroot()
        cases = list(document.iter('testcase'))
        summary = {'tests': len(cases), 'passed': 0, 'failures': 0, 'errors': 0, 'skipped': 0, 'names': []}
        details = []
        for case in cases:
            name = case.attrib.get('name', '')
            summary['names'].append(name)
            tags = {child.tag for child in case}
            if 'failure' in tags:
                summary['failures'] += 1
                item = case.find('failure')
                details.append({'kind': 'failure', 'name': name, 'message': item.attrib.get('message', '') if item is not None else '', 'text': item.text if item is not None else ''})
            elif 'error' in tags:
                summary['errors'] += 1
                item = case.find('error')
                details.append({'kind': 'error', 'name': name, 'message': item.attrib.get('message', '') if item is not None else '', 'text': item.text if item is not None else ''})
            elif 'skipped' in tags:
                summary['skipped'] += 1
                item = case.find('skipped')
                details.append({'kind': 'skipped', 'name': name, 'message': item.attrib.get('message', '') if item is not None else '', 'text': item.text if item is not None else ''})
            else:
                summary['passed'] += 1
        summary['names'].sort()
        junit = {'summary': summary, 'failure_details': details}
    if error is not None or junit is None or junit['summary']['tests'] != 2 or set(junit['summary']['names']) != EXPECTED_NAMES or junit['summary']['skipped']:
        classification = 'HARNESS_ERROR'
        semantic_state = 'UNRUN_OR_PARTIAL'
    elif junit['summary']['errors']:
        classification = 'TEST_ERROR'
        semantic_state = 'UNCLASSIFIED'
    elif junit['summary']['failures']:
        classification = 'TEST_FAIL_UNCLASSIFIED'
        semantic_state = 'UNCLASSIFIED'
    elif code == 0 and junit['summary']['passed'] == 2:
        classification = 'PASS'
        semantic_state = 'PASS'
    else:
        classification = 'HARNESS_ERROR'
        semantic_state = 'UNRUN_OR_PARTIAL'
    loaded = {}
    for name, module in list(sys.modules.items()):
        origin = getattr(module, '__file__', None)
        if not isinstance(origin, str) or not any(origin.startswith(prefix) for prefix in ('/tmp/src/', '/tmp/tests/', '/tmp/tools/')):
            continue
        path = Path(origin)
        if path.is_file():
            loaded.setdefault(origin, {'sha256': sha(path), 'bytes': path.stat().st_size, 'module_names': []})
            loaded[origin]['module_names'].append(name)
    post_mount_mismatches = []
    for row in mount_pins:
        if sha(row['container_path']) != row['sha256']:
            post_mount_mismatches.append(row['container_path'])
    post_inputs = {
        'binding_sha256': sha(BINDING),
        'source_admission_sha256': sha(CORE),
        'remote_readback_sha256': sha(REMOTE),
        'runner_sha256': sha(SELF),
        'cache_prefix_absent': not os.path.lexists(CACHE_PREFIX),
        'post_mount_mismatches': post_mount_mismatches,
    }
    if not post_inputs['cache_prefix_absent'] or post_mount_mismatches:
        classification = 'HARNESS_ERROR'
        semantic_state = 'UNRUN_OR_PARTIAL'
    write('r82-result.json', {
        'classification': classification,
        'semantic_state': semantic_state,
        'pytest_returncode': code,
        'error': error,
        'junit': junit,
        'wall_seconds': time.monotonic() - start,
        'ru_maxrss_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        'cgroup_after': cgroup_snapshot(),
        'post_inputs': post_inputs,
        'finite_loaded_module_origins': loaded,
        'scope': 'Two selected tests only. Failure classification is deliberately unclassified unless both exact tests pass; a selected test failure alone does not prove the intended oracle assertion was reached. Child CLI imports and C134 CodeType origins are not established.',
        'closure_ids': [],
        'G_acceptance': False,
    })
if code is not None:
    raise SystemExit(code)
