"""Bounded V3 preparation controls; run only as an explicit pytest plugin."""

from __future__ import annotations

import os
from collections.abc import Callable
from dataclasses import replace
from typing import Any

import pytest


@pytest.fixture(autouse=True)
def v3_remove_property_keep_markers(monkeypatch: pytest.MonkeyPatch) -> None:
    """Preserve refs/rules/reports while removing the selected numerical effect."""

    mode = os.environ.get("POLISYOS_V3_PREPARATION_REMOVAL", "")
    if mode == "foundry":
        from polisyos.foundry.data_plane import bindings

        original: Callable[..., Any] = bindings._materialize_state

        def remove_assignments(**kwargs: Any) -> Any:
            _state, applied_ids, errors, warnings = original(**kwargs)
            return kwargs["base_state"], applied_ids, errors, warnings

        monkeypatch.setattr(bindings, "_materialize_state", remove_assignments)
    elif mode == "context":
        from polisyos.foundry import execute

        original_get = execute.get_state_path

        def remove_selected_baseline(state: Any, path: str) -> Any:
            value = original_get(state, path)
            if path in {"government_balance", "gdp"}:
                return 0.0
            return value

        monkeypatch.setattr(execute, "get_state_path", remove_selected_baseline)
    elif mode in {"context-native", "context-alias"}:
        from polisyos.runtime.quality.cycle_substrate import (
            ConfiguredCandidateSimulationContextAdmissionOwner,
        )

        original_prepare = (
            ConfiguredCandidateSimulationContextAdmissionOwner.prepare_context_for_acquired_world
        )

        def remove_native_snapshot(self: Any, **kwargs: Any) -> Any:
            prepared = original_prepare(self, **kwargs)
            inputs = (
                prepared.profile.context_inputs
                if mode == "context-native"
                else self.configured_profile_for_selection_ref(
                    kwargs["profile_selection_ref"]
                ).context_inputs
            )
            return replace(prepared, source_context_inputs=inputs)

        monkeypatch.setattr(
            ConfiguredCandidateSimulationContextAdmissionOwner,
            "prepare_context_for_acquired_world",
            remove_native_snapshot,
        )
    else:
        pytest.fail("select one V3 removal mode: foundry, context, context-native, context-alias")
