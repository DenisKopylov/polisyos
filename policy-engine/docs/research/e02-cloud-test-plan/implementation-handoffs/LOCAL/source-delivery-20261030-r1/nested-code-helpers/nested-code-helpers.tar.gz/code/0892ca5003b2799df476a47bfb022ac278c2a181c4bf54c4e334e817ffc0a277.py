from types import FunctionType
from importlib import import_module
def body(callback):
    return callback("bridge_callback")
container.member = body
CODE = body.__code__
run = FunctionType(CODE, globals())
run(import_module)
