"""Observe frozen source-owned calls; disable repeated non-target dispatch."""
import hashlib
import importlib.machinery
import marshal
from pathlib import Path
import sys
import threading
import types


class ObservationError(RuntimeError):
    """Refuse an unsupported or unestablished measurement profile."""


class BoundedCallObserver:
    """Count selected real code while dispatching other code only once per object.

    The global start event discovers lazily imported/nested targets. DISABLE is
    returned for each non-target code object. No setprofile hook is installed.
    """
    TOOL_ID = 3

    def __init__(self, *, root, owners, extra_compiler=None, code_output=None):
        self.root = Path(root).resolve(strict=True)
        self.owners = list(owners)
        self.extra_compiler = extra_compiler
        self.code_output = Path(code_output) if code_output is not None else None
        self.callback_invocations = 0
        self.calls = {}
        self.errors = []
        self._sources = {}
        self._names = set()
        self._bindings = {}
        self._non_targets = {}
        self._non_target_dispatches = 0
        self._lock = threading.RLock()
        self._started = False

    def _refuse(self, reason):
        self.errors.append({'reason': reason, 'thread_id': threading.get_ident()})
        raise ObservationError(reason)

    def _walk_codes(self, code):
        yield code
        for value in code.co_consts:
            if isinstance(value, types.CodeType):
                yield from self._walk_codes(value)

    def _prepare(self):
        for row in self.owners:
            relative = Path(row['path'])
            if relative.is_absolute() or '..' in relative.parts:
                self._refuse('owner_path_not_relative')
            path = (self.root / relative).resolve(strict=True)
            if not path.is_relative_to(self.root):
                self._refuse('owner_path_outside_root')
            source = path.read_bytes()
            if hashlib.sha256(source).hexdigest() != row['sha256']:
                self._refuse('owner_source_bytes_changed')
            names = set(row['names'])
            compiled = compile(source, str(path), 'exec', dont_inherit=True,
                               optimize=sys.flags.optimize)
            candidates = [(code, 'source') for code in self._walk_codes(compiled)
                          if code.co_name in names]
            if self.extra_compiler is not None:
                for extra, kind in self.extra_compiler(path, source):
                    candidates.extend((code, kind) for code in self._walk_codes(extra)
                                      if code.co_name in names)
            if not names <= {code.co_name for code, _ in candidates}:
                self._refuse('owner_predicate_missing_from_complete_source')
            self._sources[path] = {'relative': relative.as_posix(), 'sha256': row['sha256'],
                                   'names': names, 'candidates': candidates}
            self._names.update(names)

    def start(self):
        if sys.implementation.name != 'cpython' or sys.version_info[:2] != (3, 14) or not hasattr(sys, 'monitoring'):
            self._refuse('unsupported_runtime: CPython3.14 sys.monitoring required')
        if self._started:
            self._refuse('observer_already_started')
        if sys.getprofile() is not None or threading.getprofile() is not None:
            self._refuse('existing_profile_must_not_be_replaced')
        if sys.monitoring.get_tool(self.TOOL_ID) is not None:
            self._refuse('monitoring_tool_already_owned')
        self._prepare()
        sys.monitoring.use_tool_id(self.TOOL_ID, 'c100-bounded-owner-calls')
        sys.monitoring.register_callback(self.TOOL_ID, sys.monitoring.events.PY_START,
                                         self._dispatch)
        self._started = True
        sys.monitoring.set_events(self.TOOL_ID, sys.monitoring.events.PY_START)

    def _physical_claim(self, value):
        if not isinstance(value, str) or not Path(value).is_absolute():
            return None
        try:
            return Path(value).resolve(strict=True)
        except OSError:
            return None

    def _authenticate(self, code, frame, path, owner):
        name = frame.f_globals.get('__name__')
        module = sys.modules.get(name)
        if not isinstance(module, types.ModuleType) or module.__dict__ is not frame.f_globals:
            self._refuse('owner_module_globals_not_established')
        spec = frame.f_globals.get('__spec__')
        if not isinstance(spec, importlib.machinery.ModuleSpec):
            self._refuse('owner_module_spec_not_established')
        if (self._physical_claim(spec.origin) != path or
                self._physical_claim(frame.f_globals.get('__file__')) != path):
            self._refuse('owner_module_origin_mismatch')
        # CodeType equality compares the compiled code/constant structure, avoiding
        # marshal's string-intern representation differences; actual marshal ID is retained.
        compilers = sorted({kind for expected, kind in owner['candidates'] if code == expected})
        if not compilers:
            self._refuse('owner_code_not_equal_to_frozen_source_compilation')
        code_bytes = marshal.dumps(code)
        code_sha256 = hashlib.sha256(code_bytes).hexdigest()
        code_path = None
        if self.code_output is not None:
            target = self.code_output / (code_sha256 + '.marshal')
            if target.exists():
                if target.read_bytes() != code_bytes:
                    self._refuse('observed_code_file_conflict')
            else:
                with target.open('xb') as stream:
                    stream.write(code_bytes)
            code_path = target.name
        binding = {'module': module, 'globals': frame.f_globals, 'module_name': name,
                   'path': owner['relative'], 'source_sha256': owner['sha256'],
                   'code_sha256': code_sha256, 'code_file': code_path,
                   'qualname': code.co_qualname, 'compatible_compilers': compilers}
        self._bindings[id(code)] = (code, binding)
        return binding

    def _dispatch(self, code, offset):
        self.callback_invocations += 1
        if code.co_name not in self._names:
            self._non_targets[id(code)] = code
            self._non_target_dispatches += 1
            return None
        frame = sys._getframe(1)
        if frame.f_code is not code:
            self._refuse('callback_frame_not_established')
        path = self._physical_claim(code.co_filename)
        owner = self._sources.get(path)
        module_file = self._physical_claim(frame.f_globals.get('__file__'))
        if owner is None:
            if module_file in self._sources:
                self._refuse('owner_code_filename_mismatch')
            self._non_targets[id(code)] = code
            self._non_target_dispatches += 1
            return sys.monitoring.DISABLE
        if code.co_name not in owner['names']:
            self._non_targets[id(code)] = code
            self._non_target_dispatches += 1
            return sys.monitoring.DISABLE
        with self._lock:
            cached = self._bindings.get(id(code))
            binding = cached[1] if cached is not None and cached[0] is code else self._authenticate(code, frame, path, owner)
            if (frame.f_globals is not binding['globals'] or
                    sys.modules.get(binding['module_name']) is not binding['module']):
                self._refuse('owner_module_globals_changed')
            label = binding['path'] + '::' + binding['qualname'] + '@' + binding['code_sha256']
            if label not in self.calls:
                self.calls[label] = {key: value for key, value in binding.items()
                                     if key not in {'module', 'globals', 'module_name'}}
                self.calls[label].update(calls=0, first_thread_id=threading.get_ident(), thread_ids=[])
                count = code.co_argcount + code.co_kwonlyargcount
                self.calls[label]['first_argument_types'] = {
                    key: type(frame.f_locals[key]).__module__ + '.' + type(frame.f_locals[key]).__qualname__
                    for key in code.co_varnames[:count] if key in frame.f_locals
                }
            row = self.calls[label]
            row['calls'] += 1
            if threading.get_ident() not in row['thread_ids']:
                row['thread_ids'].append(threading.get_ident())

    def stop(self):
        if self._started:
            sys.monitoring.set_events(self.TOOL_ID, 0)
            sys.monitoring.free_tool_id(self.TOOL_ID)
            self._started = False

    def report(self):
        return {'mechanism': 'CPython3.14 PY_START; incremental DISABLE for non-target code',
                'callback_invocations': self.callback_invocations,
                'non_target_callbacks': self._non_target_dispatches,
                'distinct_non_target_code_objects': len(self._non_targets),
                'reenabled_non_target_callbacks': self._non_target_dispatches - len(self._non_targets),
                'calls': self.calls, 'errors': self.errors,
                'thread_ids': sorted({tid for row in self.calls.values() for tid in row['thread_ids']})}
