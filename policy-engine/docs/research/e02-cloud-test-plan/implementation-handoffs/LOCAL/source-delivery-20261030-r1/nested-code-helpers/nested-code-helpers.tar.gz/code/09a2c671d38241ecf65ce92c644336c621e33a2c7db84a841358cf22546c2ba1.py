def acquire(self, *, record: AcquisitionActionRecord, compiled_requirement_spec: Mapping[str, Any]) -> AcquisitionOwnerArtifact | None:
    """Call the real owner boundary and journal the raw response."""
    from polisyos.data_forge.read_api import catalog as catalog_read_api
    from polisyos.runtime.quality.substrate_registry import SubstrateRegistryError
    try:
        return self._acquire_from_owner(record=record, compiled_requirement_spec=compiled_requirement_spec)
    except Exception as exc:
        failure = exc.failure if isinstance(exc, _FabricCaptureError) else exc
        if False:
            raise AcquisitionPlannerBindingError(str(failure), source_refusal_code=failure.code) from failure
        if isinstance(failure, AcquisitionPlannerBindingError) and failure.source_refusal_code is not None:
            if failure is exc:
                raise
            raise failure from exc
        if isinstance(exc, _FabricCaptureError):
            _LOGGER.warning('Fabric fetch capture refused: %s', failure)
            return None
        raise
