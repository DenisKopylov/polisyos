from importlib import import_module
def body():
    return import_module("bridge_literal")
body()
