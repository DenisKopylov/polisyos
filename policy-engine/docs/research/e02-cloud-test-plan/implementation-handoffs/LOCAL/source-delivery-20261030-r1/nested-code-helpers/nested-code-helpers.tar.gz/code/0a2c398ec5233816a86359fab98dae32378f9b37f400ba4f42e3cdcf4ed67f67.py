"""Bounded stdlib extraction of owner parameter resolution; no product import or pytest."""

from __future__ import annotations

import ast
import json
import math
from pathlib import Path
from types import SimpleNamespace

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
PACKET = ROOT / "LOCAL/raw/e02-execution-20261027/repairs/R4-native-control-r1/fixture-admission-r1"
LIFECYCLE = ROOT / "policy-engine/src/polisyos/runtime/http/services/control/run_lifecycle.py"
FOREST = ROOT / "policy-engine/src/polisyos/foundry/methods/catalog/causal/forest_dr.py"
NUMPY_RUNNER = ROOT / "policy-engine/src/polisyos/foundry/methods/backends/numpy_runner.py"
RUNNER = ROOT / "policy-engine/src/polisyos/scientist/compute/runner.py"
FIXTURE = PACKET / "fixture-postimage.py"


def main() -> None:
    forest = ast.parse(FOREST.read_bytes())
    classes = {node.name: node for node in forest.body if isinstance(node, ast.ClassDef)}
    specs = []
    for name in ("ForestDRLearnerEstimator", "ForestDRLearnerEstimatorV11"):
        signature = next(
            node
            for node in classes[name].body
            if isinstance(node, ast.AnnAssign)
            and isinstance(node.target, ast.Name)
            and node.target.id == "signature"
        )
        for node in ast.walk(signature.value):
            if (
                isinstance(node, ast.Call)
                and isinstance(node.func, ast.Name)
                and node.func.id == "ParameterSpec"
            ):
                args = {item.arg: ast.literal_eval(item.value) for item in node.keywords}
                specs.append(
                    SimpleNamespace(
                        name=args["name"],
                        default=args["default"],
                        bounds=args.get("bounds", (None, None)),
                    )
                )
    signature = SimpleNamespace(parameters=tuple(specs))
    test_tree = ast.parse(FIXTURE.read_bytes())
    test = next(
        node
        for node in test_tree.body
        if isinstance(node, ast.FunctionDef)
        and node.name == "test_real_forest_fit_progress_spans_durable_cancel_post"
    )
    assignments = [
        node
        for node in ast.walk(test)
        if isinstance(node, ast.Assign)
        and any(
            isinstance(target, ast.Name) and target.id == "method_params" for target in node.targets
        )
    ]
    assert len(assignments) == 1
    submitted = ast.literal_eval(assignments[0].value)
    life = ast.parse(LIFECYCLE.read_bytes())
    resolver = next(
        node
        for node in ast.walk(life)
        if isinstance(node, ast.FunctionDef) and node.name == "_resolve_observational_method_params"
    )
    resolver.decorator_list = []
    module = ast.Module(
        body=[
            ast.ImportFrom(module="__future__", names=[ast.alias(name="annotations")], level=0),
            resolver,
        ],
        type_ignores=[],
    )

    class JsonBoundaryStub:
        def validate_python(self, value, *, strict):
            assert strict is True and isinstance(value, dict)
            return value

    ns = {
        "math": math,
        "json": json,
        "JsonValue": object,
        "TypeAdapter": lambda _: JsonBoundaryStub(),
    }
    exec(
        compile(ast.fix_missing_locations(module), "<actual-owner-resolver-extracted>", "exec"), ns
    )
    resolve = ns["_resolve_observational_method_params"]
    result = resolve(signature, submitted)

    def expected_rejection(params, expected):
        try:
            resolve(signature, params)
        except ValueError as exc:
            return str(exc) == expected
        return False

    intent_calls = [
        node
        for node in ast.walk(life)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id == "ObservationalRunIntent"
    ]
    seed_rows = [
        {
            item.arg: ast.literal_eval(item.value)
            for item in node.keywords
            if item.arg in ("seed", "seed_policy_revision") and isinstance(item.value, ast.Constant)
        }
        for node in intent_calls
    ]
    numpy_source = NUMPY_RUNNER.read_text()
    runner_source = RUNNER.read_text()
    forest_source = FOREST.read_text()
    checks = {
        "exact_submitted_workload": submitted
        == {"n_estimators": 128, "cv_folds": 2, "subforest_size": 4, "n_jobs": 1},
        "owner_signature_nullable_default": next(
            spec for spec in specs if spec.name == "random_state"
        ).default
        is None,
        "resolved_nullable_default_present": "random_state" in result
        and result["random_state"] is None,
        "resolved_requested_values_preserved": all(
            result.get(key) == value for key, value in submitted.items()
        ),
        "original_73_override_rejected": expected_rejection(
            {**submitted, "random_state": 73},
            "observational_method_parameter_type_not_established:random_state",
        ),
        "invalid_parallelism_rejected": expected_rejection(
            {**submitted, "n_jobs": 2}, "observational_method_parameter_bounds_invalid:n_jobs"
        ),
        "invalid_estimator_type_rejected": expected_rejection(
            {**submitted, "n_estimators": "128"},
            "observational_method_parameter_type_invalid:n_estimators",
        ),
        "intent_constructor_seed_policy_source": {
            "seed": 0,
            "seed_policy_revision": "server_seed_zero_v1",
        }
        in seed_rows,
        "runner_forwards_admission_seed_source": "seed = admission.seed" in runner_source
        and "seed=seed" in runner_source,
        "numpy_owner_injects_seed_source": 'resolved["__seed__"] = seed' in numpy_source,
        "forest_owner_uses_injected_seed_source": 'seed = params.get("__seed__", 0)'
        in forest_source
        and '"random_state": seed_int' in forest_source,
    }
    output = {
        "pass": all(checks.values()),
        "checks": checks,
        "submitted": submitted,
        "resolved_random_state": result.get("random_state"),
        "signature_parameter_count": len(specs),
        "scope": "actual resolver and signature AST with a stdlib JSON-boundary stub; source-reviewed seed chain, no Pydantic/product import, HTTP or native execution",
        "closure_ids": [],
    }
    print(json.dumps(output, sort_keys=True, indent=2))
    if not output["pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
