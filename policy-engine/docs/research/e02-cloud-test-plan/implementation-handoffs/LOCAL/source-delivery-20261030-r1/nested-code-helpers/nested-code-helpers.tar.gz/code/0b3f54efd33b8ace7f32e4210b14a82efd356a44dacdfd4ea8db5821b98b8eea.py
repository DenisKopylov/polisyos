"""Async adapter layer for the backend-agnostic artifact store protocol."""

from __future__ import annotations

import inspect
from dataclasses import dataclass
from typing import TYPE_CHECKING, TypeGuard, cast

from polisyos.common.async_tools import run_blocking_async
from polisyos.common.canonical import (
    _require_artifact_writer_profile_admitted,
    _snapshot_canon_spec,
)
from polisyos.core.canon import CanonSpec, CanonViolation

from .protocol import (
    ArtifactStore,
    AsyncArtifactStore,
    _require_return_selected_profile_writer,
    _validate_return_selected_profile,
)

if TYPE_CHECKING:
    from ._integrity_ops import VerificationReport
    from .backends.config import ArtifactStoreConfig
    from .ids import ArtifactID
    from .manifest import ArtifactManifest, ArtifactRef
    from .write_contract import ArtifactWriteOptions


def is_async_artifact_store(store: object) -> TypeGuard[AsyncArtifactStore]:
    """Return whether *store* exposes the async CAS contract at runtime."""

    candidate = getattr(store, "put_json", None)
    return inspect.iscoroutinefunction(candidate)


@dataclass(frozen=True, slots=True)
class AsyncArtifactStoreAdapter:
    """Wrap a sync store; explicit ``unbounded`` skips the helper default cap.

    Omitted or ``None`` timeout retains the shared helper default. A finite
    timeout combined with ``unbounded=True`` is rejected before backend admission.
    """

    store: ArtifactStore
    timeout_seconds: float | None = None
    unbounded: bool = False

    async def has(self, artifact_id: ArtifactID | ArtifactRef) -> bool:
        return cast(
            "bool",
            await run_blocking_async(
                self.store.has,
                artifact_id,
                timeout_seconds=self.timeout_seconds,
                unbounded=self.unbounded,
            ),
        )

    async def get_bytes(self, artifact_id: ArtifactID | ArtifactRef) -> bytes:
        return cast(
            "bytes",
            await run_blocking_async(
                self.store.get_bytes,
                artifact_id,
                timeout_seconds=self.timeout_seconds,
                unbounded=self.unbounded,
            ),
        )

    async def get_manifest(self, artifact_id: ArtifactID | ArtifactRef) -> ArtifactManifest:
        return await run_blocking_async(
            self.store.get_manifest,
            artifact_id,
            timeout_seconds=self.timeout_seconds,
            unbounded=self.unbounded,
        )

    async def get_raw_manifest_bytes(
        self,
        artifact_id: ArtifactID | ArtifactRef,
        *,
        manifest_profile_sha256: str | None = None,
    ) -> bytes:
        """Read raw selected-manifest bytes through the shared timeout policy."""
        reader = getattr(self.store, "get_raw_manifest_bytes", None)
        if not callable(reader):
            raise TypeError("Artifact store must expose get_raw_manifest_bytes")
        return cast(
            "bytes",
            await run_blocking_async(
                reader,
                artifact_id,
                **(
                    {"manifest_profile_sha256": manifest_profile_sha256}
                    if manifest_profile_sha256 is not None
                    else {}
                ),
                timeout_seconds=self.timeout_seconds,
                unbounded=self.unbounded,
            ),
        )

    async def put_bytes(
        self,
        data: bytes,
        opts: ArtifactWriteOptions,
        *,
        return_selected_profile: bool = False,
    ) -> ArtifactRef:
        _validate_return_selected_profile(return_selected_profile)
        if return_selected_profile:
            _require_return_selected_profile_writer(self.store, "put_bytes")
        return await run_blocking_async(
            self.store.put_bytes,
            data,
            opts,
            **({"return_selected_profile": True} if return_selected_profile else {}),
            timeout_seconds=self.timeout_seconds,
            unbounded=self.unbounded,
        )

    async def put_json(
        self,
        obj: object,
        opts: ArtifactWriteOptions,
        canon_spec: CanonSpec | None = None,
        *,
        return_selected_profile: bool = False,
    ) -> ArtifactRef:
        _validate_return_selected_profile(return_selected_profile)
        if canon_spec is not None:
            canon_spec = _snapshot_canon_spec(canon_spec, CanonSpec)
        _require_artifact_writer_profile_admitted(canon_spec, violation_type=CanonViolation)
        if return_selected_profile:
            _require_return_selected_profile_writer(self.store, "put_json")
        return await run_blocking_async(
            self.store.put_json,
            obj,
            opts,
            canon_spec=canon_spec,
            **({"return_selected_profile": True} if return_selected_profile else {}),
            timeout_seconds=self.timeout_seconds,
            unbounded=self.unbounded,
        )

    async def verify(self, artifact_id: ArtifactID | ArtifactRef) -> VerificationReport:
        return await run_blocking_async(
            self.store.verify,
            artifact_id,
            timeout_seconds=self.timeout_seconds,
            unbounded=self.unbounded,
        )

    async def iter_artifact_ids(self) -> list[ArtifactID]:
        return cast(
            "list[ArtifactID]",
            await run_blocking_async(
                self.store.iter_artifact_ids,
                timeout_seconds=self.timeout_seconds,
                unbounded=self.unbounded,
            ),
        )

    def artifact_store_config(self) -> ArtifactStoreConfig | None:
        from .backends.config import infer_artifact_store_config

        return infer_artifact_store_config(self.store)


@dataclass(frozen=True, slots=True)
class AsyncFileSystemArtifactStore:
    """Async filesystem facade with the shared adapter timeout policy.

    ``unbounded=True`` delegates time ownership to the caller rather than
    inheriting the helper default; a finite timeout cannot also be unbounded.
    """

    store: ArtifactStore
    timeout_seconds: float | None = None
    unbounded: bool = False

    async def has(self, artifact_id: ArtifactID | ArtifactRef) -> bool:
        return cast(
            "bool",
            await run_blocking_async(
                self.store.has,
                artifact_id,
                timeout_seconds=self.timeout_seconds,
                unbounded=self.unbounded,
            ),
        )

    async def get_bytes(self, artifact_id: ArtifactID | ArtifactRef) -> bytes:
        return cast(
            "bytes",
            await run_blocking_async(
                self.store.get_bytes,
                artifact_id,
                timeout_seconds=self.timeout_seconds,
                unbounded=self.unbounded,
            ),
        )

    async def get_manifest(self, artifact_id: ArtifactID | ArtifactRef) -> ArtifactManifest:
        return await run_blocking_async(
            self.store.get_manifest,
            artifact_id,
            timeout_seconds=self.timeout_seconds,
            unbounded=self.unbounded,
        )

    async def get_raw_manifest_bytes(
        self,
        artifact_id: ArtifactID | ArtifactRef,
        *,
        manifest_profile_sha256: str | None = None,
    ) -> bytes:
        """Read raw selected-manifest bytes through the shared timeout policy."""
        reader = getattr(self.store, "get_raw_manifest_bytes", None)
        if not callable(reader):
            raise TypeError("Artifact store must expose get_raw_manifest_bytes")
        return cast(
            "bytes",
            await run_blocking_async(
                reader,
                artifact_id,
                **(
                    {"manifest_profile_sha256": manifest_profile_sha256}
                    if manifest_profile_sha256 is not None
                    else {}
                ),
                timeout_seconds=self.timeout_seconds,
                unbounded=self.unbounded,
            ),
        )

    async def put_bytes(
        self,
        data: bytes,
        opts: ArtifactWriteOptions,
        *,
        return_selected_profile: bool = False,
    ) -> ArtifactRef:
        _validate_return_selected_profile(return_selected_profile)
        if return_selected_profile:
            _require_return_selected_profile_writer(self.store, "put_bytes")
        return await run_blocking_async(
            self.store.put_bytes,
            data,
            opts,
            **({"return_selected_profile": True} if return_selected_profile else {}),
            timeout_seconds=self.timeout_seconds,
            unbounded=self.unbounded,
        )

    async def put_json(
        self,
        obj: object,
        opts: ArtifactWriteOptions,
        canon_spec: CanonSpec | None = None,
        *,
        return_selected_profile: bool = False,
    ) -> ArtifactRef:
        _validate_return_selected_profile(return_selected_profile)
        if canon_spec is not None:
            canon_spec = _snapshot_canon_spec(canon_spec, CanonSpec)
        _require_artifact_writer_profile_admitted(canon_spec, violation_type=CanonViolation)
        if return_selected_profile:
            _require_return_selected_profile_writer(self.store, "put_json")
        return await run_blocking_async(
            self.store.put_json,
            obj,
            opts,
            canon_spec=canon_spec,
            **({"return_selected_profile": True} if return_selected_profile else {}),
            timeout_seconds=self.timeout_seconds,
            unbounded=self.unbounded,
        )

    async def verify(self, artifact_id: ArtifactID | ArtifactRef) -> VerificationReport:
        return await run_blocking_async(
            self.store.verify,
            artifact_id,
            timeout_seconds=self.timeout_seconds,
            unbounded=self.unbounded,
        )

    async def iter_artifact_ids(self) -> list[ArtifactID]:
        return cast(
            "list[ArtifactID]",
            await run_blocking_async(
                self.store.iter_artifact_ids,
                timeout_seconds=self.timeout_seconds,
                unbounded=self.unbounded,
            ),
        )

    def artifact_store_config(self) -> ArtifactStoreConfig | None:
        from .backends.config import infer_artifact_store_config

        return infer_artifact_store_config(self.store)


def ensure_async_artifact_store(
    store: ArtifactStore | AsyncArtifactStore,
    *,
    timeout_seconds: float | None = None,
    unbounded: bool = False,
) -> AsyncArtifactStore:
    """Adapt a sync store using caller timeout policy; preserve native async stores.

    ``unbounded`` is additive and defaults to the existing helper timeout.
    A native async store retains its own policy rather than being rewrapped.
    """
    if is_async_artifact_store(store):
        return store
    return AsyncArtifactStoreAdapter(
        cast("ArtifactStore", store),
        timeout_seconds=timeout_seconds,
        unbounded=unbounded,
    )


__all__ = [
    "AsyncArtifactStoreAdapter",
    "AsyncFileSystemArtifactStore",
    "ensure_async_artifact_store",
    "is_async_artifact_store",
]
