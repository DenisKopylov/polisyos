"""Read-only runtime observer for one source-pinned public I2 census invocation."""
import atexit
import hashlib
import importlib.abc
import importlib.machinery
import json
import os
import sys
import threading
import time
from pathlib import Path

OUT = Path(os.environ.get("E02_PHASE_PROFILE_DIR", ""))
PACKET = Path(os.environ.get("E02_PHASE_PACKET", ""))
PRODUCT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos/policy-engine")
MANIFEST = json.loads((PACKET / "manifest.json").read_text(encoding="utf-8"))
PINS = MANIFEST["source_pins"]
T0 = time.perf_counter()
LOCK = threading.Lock()
TOTALS = {}
STOP = threading.Event()


def _sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _emit(event, **fields):
    row = {"elapsed_s": round(time.perf_counter() - T0, 3), "event": event, **fields}
    line = json.dumps(row, sort_keys=True, separators=(",", ":"))
    with LOCK:
        with (OUT / "progress.ndjson").open("a", encoding="utf-8") as f:
            f.write(line + "\n")
    print("E02_PHASE " + line, file=sys.stderr, flush=True)


def _record(key, elapsed, *, calls=1, bytes_count=0, matches=0):
    with LOCK:
        row = TOTALS.setdefault(key, {"calls": 0, "wall_s": 0.0, "bytes": 0, "matches": 0})
        row["calls"] += calls
        row["wall_s"] += elapsed
        row["bytes"] += bytes_count
        row["matches"] += matches


def _wrap(module, name, key, result_hook=None):
    original = getattr(module, name, None)
    if original is None or getattr(original, "__e02_observed__", False):
        return

    def observed(*args, **kwargs):
        start = time.perf_counter()
        try:
            result = original(*args, **kwargs)
            if result_hook is not None:
                result_hook(args, result)
            return result
        finally:
            elapsed = time.perf_counter() - start
            _record(key, elapsed)
            if elapsed >= 1.0 or key in {"preflight", "tool_invoke", "registry_discovery", "collector", "package_metadata"}:
                _emit("phase_complete", phase=key, wall_s=round(elapsed, 3))

    observed.__name__ = getattr(original, "__name__", name)
    observed.__doc__ = getattr(original, "__doc__", None)
    observed.__wrapped__ = original
    observed.__e02_observed__ = True
    setattr(module, name, observed)


def _git_hook(stage):
    def capture(args, result):
        paths, meta = result
        _emit("git_stage_complete", stage=stage, path_count=len(paths), selected_text_count=None,
              git_stdout_bytes=meta.get("stdout_bytes"), git_stderr_bytes=meta.get("stderr_bytes"),
              returncode=meta.get("returncode"))
        with LOCK:
            TOTALS.setdefault("git_path_counts", {})[stage] = len(paths)
    return capture


class _TimedPattern:
    """Delegates to the actual compiled regex and yields its exact Match objects."""
    def __init__(self, pattern, key):
        self._pattern = pattern
        self._key = key

    def __getattr__(self, name):
        return getattr(self._pattern, name)

    def finditer(self, *args, **kwargs):
        iterator = self._pattern.finditer(*args, **kwargs)
        elapsed = 0.0
        matches = 0
        while True:
            start = time.perf_counter()
            try:
                match = next(iterator)
            except StopIteration:
                _record(self._key, elapsed, calls=1, matches=matches)
                return
            elapsed += time.perf_counter() - start
            matches += 1
            yield match


class _JSONProxy:
    def __getattr__(self, name):
        return getattr(json, name)

    def dumps(self, *args, **kwargs):
        start = time.perf_counter()
        result = json.dumps(*args, **kwargs)
        _record("json_serialization", time.perf_counter() - start)
        _emit("serialization_complete", wall_s=round(time.perf_counter() - start, 3),
              output_characters=len(result))
        return result


def _patch_census(module):
    if getattr(module, "__e02_phase_observer_ready__", False):
        return
    source = Path(module.__file__).resolve()
    expected = PINS["policy-engine/tools/quality/validation/schema_fqn_census.py"]["sha256"]
    actual = _sha(source)
    if actual != expected or source != (PRODUCT / "tools/quality/validation/schema_fqn_census.py").resolve():
        _emit("source_pin_mismatch", module="schema_fqn_census", expected_sha256=expected, actual_sha256=actual)
        raise ImportError("I2 observer census source pin mismatch")

    _wrap(module, "_git_paths", "git_path_query", lambda args, result: _git_hook(
        "tracked" if "--cached" in args else "untracked_nonignored"
    )(args, result))
    _wrap(module, "_git_status_paths", "git_status", _git_hook("working_tree_status"))
    _wrap(module, "measured_read_bytes", "file_read", lambda args, result: _record(
        "file_read", 0.0, calls=0, bytes_count=len(result)
    ))
    _wrap(module, "_decode_selected_bytes", "decode", lambda args, result: _record(
        "decode", 0.0, calls=0, bytes_count=len(result[0])
    ))
    _wrap(module, "_scan_python", "python_ast_and_import_scan")
    _wrap(module, "_package_metadata", "package_metadata")

    original_collect = module.collect_census
    def observed_collect(repo_root):
        start = time.perf_counter()
        _emit("collector_start", repo_root=str(Path(repo_root).resolve()))
        saved_fqn = module._FQN_PATTERNS
        saved_resource = module._RESOURCE_PATTERNS
        module._FQN_PATTERNS = {k: _TimedPattern(v, "fqn_regex_next") for k, v in saved_fqn.items()}
        module._RESOURCE_PATTERNS = {
            k: tuple(_TimedPattern(v, "resource_regex_next") for v in values)
            for k, values in saved_resource.items()
        }
        try:
            result = original_collect(repo_root)
            receipt, code = result
            denominator = receipt.get("scanned_denominator", {})
            _emit("collector_complete", wall_s=round(time.perf_counter() - start, 3),
                  exit_code=code, result=receipt.get("result"),
                  tracked_paths=receipt.get("git_enumeration", {}).get("tracked_path_count"),
                  untracked_paths=receipt.get("git_enumeration", {}).get("untracked_path_count"),
                  selected_paths=denominator.get("selected_paths"),
                  successful_reads=denominator.get("successful_byte_reads"),
                  decoded_inputs=denominator.get("decoded_utf8_inputs"),
                  unsupported_count=len(receipt.get("unsupported_or_ambiguous_inputs", [])),
                  unreadable_count=len(denominator.get("unreadable_paths", [])))
            return result
        finally:
            module._FQN_PATTERNS = saved_fqn
            module._RESOURCE_PATTERNS = saved_resource
            _record("collector", time.perf_counter() - start)
    observed_collect.__name__ = original_collect.__name__
    observed_collect.__doc__ = original_collect.__doc__
    observed_collect.__wrapped__ = original_collect
    module.collect_census = observed_collect
    module.json = _JSONProxy()
    module.__e02_phase_observer_ready__ = True
    _emit("census_observer_ready", module_origin=str(source), source_sha256=actual)


def _patch(module, fullname):
    origin = Path(getattr(module, "__file__", "")).resolve()
    rel = origin.relative_to(PRODUCT).as_posix() if origin.is_relative_to(PRODUCT) else None
    pin = PINS.get("policy-engine/" + rel) if rel else None
    if pin and _sha(origin) != pin["sha256"]:
        _emit("source_pin_mismatch", module=fullname, path=rel)
        raise ImportError("I2 observer source pin mismatch")
    if fullname == "tools.registry":
        _wrap(module, "_discover_specs", "registry_discovery")
    elif fullname == "tools.lib.preflight":
        _wrap(module, "run_preflight", "preflight")
    elif fullname == "tools.lib.runner":
        _wrap(module, "invoke_tool_main", "tool_invoke")
    elif fullname == "tools.quality.validation.schema_fqn_census":
        _patch_census(module)


class _ObservedLoader(importlib.abc.Loader):
    def __init__(self, delegate, fullname):
        self.delegate = delegate
        self.fullname = fullname

    def create_module(self, spec):
        create = getattr(self.delegate, "create_module", None)
        return create(spec) if create else None

    def exec_module(self, module):
        start = time.perf_counter()
        self.delegate.exec_module(module)
        _patch(module, self.fullname)
        _record("module_import:" + self.fullname, time.perf_counter() - start)

    def __getattr__(self, name):
        return getattr(self.delegate, name)


class _ObservedFinder(importlib.abc.MetaPathFinder):
    TARGETS = {"tools.registry", "tools.lib.preflight", "tools.lib.runner",
               "tools.quality.validation.schema_fqn_census"}

    def find_spec(self, fullname, path=None, target=None):
        if fullname not in self.TARGETS:
            return None
        spec = importlib.machinery.PathFinder.find_spec(fullname, path, target)
        if spec and spec.loader:
            spec.loader = _ObservedLoader(spec.loader, fullname)
        return spec


def _line_phase(line):
    if 1051 <= line <= 1065: return "git_enumeration"
    if 1066 <= line <= 1085: return "path_selection"
    if 1100 <= line <= 1127: return "admission_and_read"
    if 1128 <= line <= 1161: return "gzip_decode"
    if line == 1162: return "utf8_decode"
    if 1163 <= line <= 1176: return "line_index_and_scan_setup"
    if 1177 <= line <= 1200: return "text_search"
    if 1201 <= line <= 1228: return "source_snapshot_and_python_ast_import_scan"
    if 1229 <= line <= 1255: return "receipt_aggregation"
    if 1256 <= line <= 1257: return "package_metadata"
    if line >= 1258: return "final_receipt_assembly"
    return "collector_setup"


def _monitor():
    while not STOP.wait(5.0):
        frame = next((f for f in sys._current_frames().values()
                      if f.f_code.co_name == "collect_census"
                      and Path(f.f_code.co_filename).name == "schema_fqn_census.py"), None)
        if frame is None:
            _emit("heartbeat", phase="startup_registry_preflight_or_module_import")
            continue
        local = frame.f_locals
        selected = local.get("selected", ())
        relative = local.get("relative")
        ordinal = None
        if relative is not None and selected:
            try: ordinal = selected.index(relative) + 1
            except ValueError: pass
        _emit("heartbeat", phase=_line_phase(frame.f_lineno), source_line=frame.f_lineno,
              selected_paths=len(selected), current_ordinal=ordinal,
              read_paths=len(local.get("read_paths", ())),
              unreadable_count=len(local.get("unreadable", ())),
              decoded_inputs=local.get("decoded_input_count", 0),
              import_hits=len(local.get("all_imports", ())),
              match_hits=len(local.get("all_matches", ())),
              ast_calls=TOTALS.get("python_ast_and_import_scan", {}).get("calls", 0))


sys.meta_path.insert(0, _ObservedFinder())
(OUT / "observer.ready").write_text(json.dumps({"observer": "sitecustomize", "source_identity": MANIFEST["source_identity"]}) + "\n", encoding="utf-8")
threading.Thread(target=_monitor, name="e02-i2-phase-heartbeat", daemon=True).start()


def _finish():
    STOP.set()
    with LOCK:
        totals = {k: dict(v) for k, v in TOTALS.items()}
    _emit("observer_exit", totals=totals)


atexit.register(_finish)
