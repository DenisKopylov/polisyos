"""Test-only removal of the actual shared-worker cleanup predicate."""

from __future__ import annotations

import os


def pytest_configure() -> None:
    if os.environ.get("E02_PHYSICAL_COMPLETION_REMOVAL") != "proxy_done":
        return
    from polisyos.common.async_tools import _SharedFuture

    def bypass(future: _SharedFuture) -> str:
        if future.cancelled():
            return "not_started"
        if not future.done():
            return "pending"
        return "failed" if future.exception() is not None else "returned"

    _SharedFuture._physical_completion_state = bypass
