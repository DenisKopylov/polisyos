"""Real installed pytest-AST compiler controls; no pytest/product test execution."""
from __future__ import annotations

import ast
import hashlib
import importlib.util
import json
import os
import sys
import threading
import types
from pathlib import Path

import _pytest.assertion.rewrite as rewriter

for key in ('E02C_ROOT','E02C_OUT','E02C_INDEX'):
    os.environ.pop(key,None)
BASE=Path(__file__).resolve().parent
PACKET=BASE.parent
BASELINE='--baseline' in sys.argv
HELPER=(Path.cwd()/'policy-engine/tools/quality/testing/tc_sql_mc_witness/sitecustomize.py') if BASELINE else PACKET/'files/policy-engine/tools/quality/testing/tc_sql_mc_witness/sitecustomize.py'
spec=importlib.util.spec_from_file_location('capture_under_test',HELPER)
helper=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=helper
spec.loader.exec_module(helper)
PIN=json.loads((PACKET/'files/policy-engine/tools/quality/testing/tc_sql_mc_witness/pins.json').read_bytes())['assertion_rewriter']
RESULTS=[]
class Config:
    def getini(self,name):
        assert name=='enable_assertion_pass_hook'
        return False

def fixture(label,zone='tools',mutate_source=False,mutate_code=False,pin=None):
    root=BASE/f'scratch-{os.getpid()}-{label}'
    path=root/f'policy-engine/{zone}/fixture_{label}.py'
    path.parent.mkdir(parents=True,exist_ok=False)
    source=b'from __future__ import annotations\ndef producer(value):\n    assert value > 0\n    return value + 1\n'
    path.write_bytes(source)
    blob=hashlib.sha1(b'blob '+str(len(source)).encode()+b'\0'+source,usedforsecurity=False).hexdigest()
    syntax=ast.parse(source,filename=str(path))
    rewriter.rewrite_asserts(syntax,source,str(path),Config())
    if mutate_code:
        # Keep rewrite markers/imports/assertions, alter actual executed return code.
        fn=next(n for n in syntax.body if isinstance(n,ast.FunctionDef))
        fn.body[-1].value.right=ast.Constant(value=7,lineno=4,col_offset=19)
        ast.fix_missing_locations(syntax)
    code=compile(syntax,str(path),'exec',dont_inherit=True,optimize=sys.flags.optimize)
    if mutate_source:path.write_bytes(source.replace(b'value + 1',b'value + 2'))
    module_spec=importlib.util.spec_from_file_location('fixture_'+label,path)
    module=importlib.util.module_from_spec(module_spec)
    sys.modules[module_spec.name]=module
    capture=helper.ActualCodeCapture(root,{'policy-engine/'+zone+'/'+path.name:blob},BASE)
    capture.assertion_compiler_pin=dict(PIN if pin is None else pin)
    events=[]
    capture.select_returns(lambda c:c.co_name=='producer' and c.co_filename==str(path),lambda frame,value:events.append((threading.get_ident(),value)),Config())
    capture.start()
    exec(code,module.__dict__)
    return path,module,capture,events

def finish(label,capture,expected,events):
    report=capture.report()
    RESULTS.append({'name':label,'expected_complete':expected,'actual_complete':report['code_census_complete_for_observed_events'],'events':events,'report':report})
    assert report['code_census_complete_for_observed_events'] is expected,label
    return report

for label,zone in [('real_rewritten_tools','tools'),('real_rewritten_test','tests')]:
    path,module,capture,events=fixture(label,zone)
    assert module.producer(2)==3
    thread=threading.Thread(target=lambda:module.producer(3))
    thread.start();thread.join()
    report=finish(label,capture,True,events)
    assert sorted(value for tid,value in events)==[3,4]
    assert len({tid for tid,value in events})==2
    assert all(row['compilation_match'] for row in report['codes'])
    if not BASELINE:
        assert any(row.get('compilation_image')=='pinned_pytest_assertion_rewrite' for row in report['codes'])

path,module,capture,events=fixture('stale_source',mutate_source=True)
assert module.producer(2)==3
finish('stale_wrong_source',capture,False,events);assert not events
path,module,capture,events=fixture('changed_code',mutate_code=True)
assert module.producer(2)==9
finish('changed_code_keep_rewrite_markers',capture,False,events);assert not events
path,module,capture,events=fixture('wrong_origin')
assert module.producer(2)==3
foreign=types.ModuleType('foreign_origin')
foreign.__file__=str(path.parent/'foreign.py');Path(foreign.__file__).write_text('# another owner\n')
foreign.__spec__=importlib.util.spec_from_file_location(foreign.__name__,foreign.__file__)
sys.modules[foreign.__name__]=foreign
clone=types.FunctionType(module.producer.__code__,foreign.__dict__)
# Rewritten code needs its compiler-injected globals, but remains a foreign namespace.
foreign.__dict__.update({k:v for k,v in module.__dict__.items() if k.startswith('@')})
assert clone(3)==4
finish('wrong_origin_remains_false',capture,False,events);assert len(events)==1
path,module,capture,events=fixture('unproved_dynamic')
assert module.producer(2)==3
exec(compile('def generated():\n    return 8\n','<string>','exec'),module.__dict__)
assert module.generated()==8
finish('unproved_dynamic_remains_false',capture,False,events)
bad=dict(PIN,source_sha256='0'*64)
path,module,capture,events=fixture('wrong_compiler_pin',pin=bad)
assert module.producer(2)==3
finish('wrong_compiler_source_pin',capture,False,events);assert not events
path,module,capture,events=fixture('changed_compiler')
original=rewriter.rewrite_asserts.__code__
mutant=compile('def rewrite_asserts(mod,source,module_path=None,config=None):\n    return None\n',original.co_filename,'exec').co_consts[0]
try:
    rewriter.rewrite_asserts.__code__=mutant
    assert module.producer(2)==3
    finish('changed_compiler_code_keep_version_origin_hash',capture,False,events)
    assert not events
finally:
    rewriter.rewrite_asserts.__code__=original
print(json.dumps({'python':sys.version,'baseline':BASELINE,'helper':str(HELPER),'helper_sha256':hashlib.sha256(HELPER.read_bytes()).hexdigest(),'controls':RESULTS},sort_keys=True,indent=2))
