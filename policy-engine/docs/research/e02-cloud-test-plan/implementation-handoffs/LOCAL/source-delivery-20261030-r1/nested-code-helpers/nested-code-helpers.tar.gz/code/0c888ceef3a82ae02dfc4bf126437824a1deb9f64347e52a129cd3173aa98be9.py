"""Build sparse RAW candidate postimages without touching canonical source."""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
from pathlib import Path

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
PACKET = ROOT / "LOCAL/raw/e02-execution-20261027/repairs/R4-candidate-outcome-json-wire-r1"
BASE = "a03a1cb5cab00c24133beb4a60f5438c65c7fa87"
SHA = lambda value: hashlib.sha256(value).hexdigest()


def source(path: str) -> bytes:
    data = subprocess.check_output(["git", "show", BASE + ":" + path], cwd=ROOT)
    assert (ROOT / path).read_bytes() == data, path
    return data


def emit(path: str, data: bytes, before: bytes | None) -> dict[str, object]:
    target = ROOT / path
    if before is None:
        assert not os.path.lexists(target), path
    output = PACKET / "postimages" / path
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("xb") as stream:
        stream.write(data)
    return {
        "path": path,
        "pre_sha256": SHA(before) if before is not None else None,
        "post_sha256": SHA(data),
        "post_bytes": len(data),
        "postimage_file": str(output.relative_to(ROOT)),
    }


rows = []
path = "policy-engine/src/polisyos/core/contracts/runtime.py"
before = source(path)
anchor = b"    @model_validator(mode=\"after\")\n    def _require_candidate_report_shape(self) -> MethodExecutionCandidateOutcome:\n"
assert before.count(anchor) == 1
method = '''    @classmethod
    def from_json_payload(cls, payload: object) -> MethodExecutionCandidateOutcome:
        """Validate a bounded decoded JSON summary with strict wire semantics.

        The caller still owns selected-profile, integrity, provenance and read-limit
        admission. JSON arrays are valid wire values for the DTO's tuple fields;
        this does not relax strict Python validation or the candidate-only limits.

        Args:
            payload: The complete JSON mapping returned by a bounded reader.

        Returns:
            A new immutable candidate summary under the unchanged DTO contract.

        Raises:
            ValueError: If the value is not JSON wire data or violates the contract.
        """
        return _validate_strict_json_wire_payload(
            payload,
            TypeAdapter(cls),
            invalid_code="method_execution_candidate_outcome_wire_payload_invalid",
        )

'''.encode()
rows.append(emit(path, before.replace(anchor, method + anchor), before))

path = "policy-engine/src/polisyos/runtime/http/services/control/run_lifecycle.py"
before = source(path)
old = b"checked_candidate_outcome = MethodExecutionCandidateOutcome.model_validate(\n                evidence_candidate_outcome\n            )"
new = b"checked_candidate_outcome = MethodExecutionCandidateOutcome.from_json_payload(\n                evidence_candidate_outcome\n            )"
assert before.count(old) == 1
rows.append(emit(path, before.replace(old, new), before))

path = "policy-engine/src/polisyos/core/contracts/README.md"
before = source(path)
anchor = b"## Public API\n\n"
assert before.count(anchor) == 1
addition = b"""`MethodExecutionCandidateOutcome.from_json_payload()` is the typed intake for an
already decoded, bounded JSON candidate summary. It reuses Core's strict JSON
wire owner so persisted arrays can reconstruct tuple fields without accepting
numeric strings, non-JSON Python carriers, extra fields or non-finite values.
The DTO's strict Python constructor, candidate limitations and scalar validators
remain unchanged. The method itself grants no artifact custody, authority or
scientific validity; consumers must first verify the selected CAS view and lineage.

"""
rows.append(emit(path, before.replace(anchor, anchor + addition), before))

path = "policy-engine/src/polisyos/runtime/http/README.md"
before = source(path)
anchor = b"## Controlled local Legal runtime profile\n"
assert before.count(anchor) == 1
addition = b"""The fresh direct-method evidence consumer admits the complete decoded candidate
summary through `MethodExecutionCandidateOutcome.from_json_payload()`. This
preserves the producer's JSON-array representation while retaining strict scalar,
candidate-only and limitation validation; it does not cast individual fields.
Selected manifest/profile, resource, source, intent, result-ref and lineage checks
still precede completion. A valid but mismatched summary remains refused. The
transport repair establishes neither a scientifically valid estimate nor a
cancel-during-native-work result.

"""
rows.append(emit(path, before.replace(anchor, addition + anchor), before))

path = "policy-engine/tests/unit/runtime/http/test_method_candidate_evidence_roundtrip.py"
rows.append(emit(path, (PACKET / "scripts/new_test.py").read_bytes(), None))

path = "policy-engine/release-fragments/unreleased/2026-10-29-method-candidate-json-wire.toml"
fragment = '''id = "2026-10-29-method-candidate-json-wire"
title = "Read persisted method candidates through strict JSON wire admission"
type = "fixed"
component = "runtime-http"
owner = "team-runtime"
summary = "Reuse the Core candidate DTO's strict JSON intake after selected bounded CAS reads so producer-emitted arrays round-trip into tuple fields without weakening scalar or candidate-only validation."
evidence = ["src/polisyos/core/contracts/runtime.py", "src/polisyos/runtime/http/services/control/run_lifecycle.py", "tests/unit/runtime/http/test_method_candidate_evidence_roundtrip.py"]
compatibility = "No DTO field, schema version, serialized producer payload or strict Python constructor changes. The public DTO gains a JSON-payload reader; historical valid evidence uses the existing wire representation. Invalid evidence and mismatched selected summaries continue to fail closed."
change_class = "python-public-api; runtime-consumer"
surface_classification = "Additive method on the existing exported MethodExecutionCandidateOutcome DTO; no new HTTP or top-level facade symbol."
migration = "Compose the Core reader before the Runtime consumer, run defining CAS/public-worker and removal controls, then review actual public inventory and affected generated-family checks under the canonical owner."
limitations = "The reader does not grant artifact custody, institutional authority or scientific validity. A completed JSON round-trip does not establish cancellation during native compute."
generated_client_compatibility = "not_applicable"
public_surface_inventory_reviewed = false
migration_docs = ["src/polisyos/core/contracts/README.md", "src/polisyos/runtime/http/README.md"]
runbook_docs = []
'''.encode()
rows.append(emit(path, fragment, None))

with (PACKET / "postimages-manifest.json").open("x") as stream:
    json.dump({"source_base": BASE, "files": rows}, stream, indent=2)
    stream.write("\n")
print(json.dumps({"files": len(rows), "postimage_bytes": sum(row["post_bytes"] for row in rows)}))
