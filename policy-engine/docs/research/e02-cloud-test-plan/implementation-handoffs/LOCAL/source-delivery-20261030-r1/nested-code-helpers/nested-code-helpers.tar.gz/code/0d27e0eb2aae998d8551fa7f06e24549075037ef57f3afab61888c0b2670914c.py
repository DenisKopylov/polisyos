from types import FunctionType
from importlib import import_module
def body():
    return None
def expose(opaque_code):
    if callable(None):
        CODE = body.__code__
    else:
        CODE = opaque_code
    opaque([CODE])
