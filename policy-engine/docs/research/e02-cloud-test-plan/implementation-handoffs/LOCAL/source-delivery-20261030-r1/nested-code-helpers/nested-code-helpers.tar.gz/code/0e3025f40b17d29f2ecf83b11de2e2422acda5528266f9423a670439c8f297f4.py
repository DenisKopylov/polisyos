"""Reconcile retained C07 command evidence without rerunning product computation.

The finite observer set and actual removal observations are read and recomputed;
a missing readset or an asserted success flag can never establish qualification.
"""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import math
import re
import subprocess
import sys
import textwrap
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path
from typing import Any

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
PRODUCT = ROOT / "policy-engine"
DIGEST = re.compile(r"[0-9a-f]{64}")
PREFIXES = ("src/polisyos/", "tests/", "tools/")


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _git(*args: str) -> bytes:
    return subprocess.check_output(["/usr/bin/git", *args], cwd=ROOT)  # noqa: S603 -- fixed local executable and pinned arguments


def _relative_file(raw: str, parent: Path) -> Path:
    path = Path(raw)
    if not path.is_absolute():
        path = ROOT / path
    if path.is_symlink():
        raise ValueError(f"evidence locator is a symlink: {raw}")
    resolved = path.resolve(strict=True)
    resolved.relative_to(parent.resolve(strict=True))
    if not resolved.is_file():
        raise ValueError(f"evidence locator is not a file: {raw}")
    return resolved


def _read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text())
    if not isinstance(value, dict):
        raise ValueError(f"expected an object: {path}")
    return value


def _committed_blob_map(head: str) -> tuple[str, dict[str, str]]:
    object_format = _git("rev-parse", "--show-object-format").decode().strip()
    if object_format not in {"sha1", "sha256"}:
        raise ValueError("unsupported Git object format")
    entries = _git(
        "ls-tree", "-r", "-z", head, "--", *("policy-engine/" + p for p in PREFIXES)
    ).split(b"\0")
    blobs = {}
    for entry in entries:
        if not entry:
            continue
        header, raw_path = entry.split(b"\t", 1)
        _mode, kind, digest = header.decode().split()
        if kind == "blob":
            blobs[raw_path.decode().removeprefix("policy-engine/")] = digest
    return object_format, blobs


def _blob_bytes(path: str, digest: str, object_format: str) -> bytes:
    local = PRODUCT / path
    if local.is_file():
        data = local.read_bytes()
        header = b"blob " + str(len(data)).encode() + b"\0"
        if hashlib.new(object_format, header + data).hexdigest() == digest:
            return data
    # An append-only later source change must not invalidate retained old proof.
    return _git("cat-file", "blob", digest)


def _reconcile_readsets(
    audit: dict[str, Any],
    plan: dict[str, Any],
    freeze: dict[str, Any],
    output: Path,
    required: list[Path],
) -> dict[str, Any]:
    rows = audit.get("readsets")
    if not isinstance(rows, list) or not rows:
        raise ValueError("retained nonempty observer/readset outputs unavailable")
    head = plan["source_head"]
    object_format, committed = _committed_blob_map(head)
    listed = []
    loaded: dict[str, str] = {}
    total_occurrences = 0
    for row in rows:
        path = _relative_file(row["path"], output / "readsets")
        if path in listed:
            raise ValueError("duplicate observer/readset locator")
        listed.append(path)
        required.append(path)
        if _sha(path) != row["sha256"]:
            raise ValueError("retained readset bytes differ from capture receipt")
        readset = _read_json(path)
        modules = readset.get("modules")
        if (
            readset.get("schema") != "r4-runtime-loaded-python-readset-v1"
            or Path(readset["project_root"]).resolve() != PRODUCT.resolve()
            or readset.get("pytest_exitstatus") != audit["result"]["return_code"]
            or row.get("pytest_exitstatus") != readset["pytest_exitstatus"]
            or not isinstance(modules, list)
            or not modules
        ):
            raise ValueError("readset schema/project/exit/nonempty quantity mismatch")
        observer = _relative_file(readset["plugin_path"], ROOT)
        required.append(observer)
        observer_relative = observer.relative_to(ROOT).as_posix()
        if (
            _sha(observer) != readset["plugin_sha256"]
            or freeze["selected_input_pins"].get(observer_relative) != readset["plugin_sha256"]
        ):
            raise ValueError("actual observer bytes are not bound to the captured freeze")
        paths = [module["path"] for module in modules]
        if paths != sorted(set(paths)):
            raise ValueError("readset module paths must form one complete sorted unique set")
        counts = {
            "module_count": len(modules),
            "source_module_count": sum(p.startswith(PREFIXES[0]) for p in paths),
            "test_module_count": sum(p.startswith(PREFIXES[1]) for p in paths),
            "tools_module_count": sum(p.startswith(PREFIXES[2]) for p in paths),
        }
        if (
            any(readset.get(key) != value for key, value in counts.items())
            or row.get("python_paths") != len(modules)
            or not counts["source_module_count"]
            or not counts["test_module_count"]
        ):
            raise ValueError("readset complete module/type denominator mismatch")
        for module in modules:
            name = module["path"]
            digest = module["sha256"]
            if (
                Path(name).is_absolute()
                or ".." in Path(name).parts
                or not name.startswith(PREFIXES)
                or not name.endswith(".py")
                or not DIGEST.fullmatch(digest)
                or not module.get("module_names")
                or name not in committed
            ):
                raise ValueError("readset contains an inadmissible or uncommitted Python input")
            if (
                hashlib.sha256(_blob_bytes(name, committed[name], object_format)).hexdigest()
                != digest
            ):
                raise ValueError(f"runtime readset differs from pinned committed source: {name}")
            if name in loaded and loaded[name] != digest:
                raise ValueError("multiple observers disagree on one loaded Python input")
            loaded[name] = digest
        total_occurrences += len(modules)
    physical = {p.resolve() for p in (output / "readsets").glob("*.json")}
    if physical != set(listed):
        raise ValueError("retained observer-file quantity differs from the complete audit set")
    demanded = plan.get("required_runtime_readset_paths")
    if not isinstance(demanded, list) or not demanded or not set(demanded) <= loaded.keys():
        raise ValueError("selected tests or defining production paths absent from retained readset")
    if audit.get("unique_runtime_loaded_python_paths") != len(loaded):
        raise ValueError("audit unique loaded-Python denominator differs from readset bytes")
    if any(loaded[path] != pin for path, pin in plan["source_test_pins"].items() if path in loaded):
        raise ValueError("loaded source/test digest differs from an issued explicit pin")
    return {
        "retained_observers": len(listed),
        "module_occurrences": total_occurrences,
        "unique_loaded_python_paths": len(loaded),
        "required_runtime_readset_paths": demanded,
        "binding": "complete finite observed Python file set versus pinned Git blobs",
        "limitations": "Not an unimported-source, external-package or executable-code census",
    }


def _function(module: ast.AST, name: str) -> ast.FunctionDef:
    found = [
        node for node in ast.walk(module) if isinstance(node, ast.FunctionDef) and node.name == name
    ]
    if len(found) != 1:
        raise ValueError(f"expected one pinned source function: {name}")
    return found[0]


def _control_shape(source: bytes, mode: str, test: bytes) -> tuple[bytes, int, int | None]:
    name = (
        "_value_owner_rows_from_source_rows"
        if mode == "owner_ambiguity"
        else "_deliver_search_hte_completion_outbox"
    )
    function = _function(ast.parse(source), name)
    lines = source.decode().splitlines(keepends=True)
    parsed = ast.parse(textwrap.dedent("".join(lines[function.lineno - 1 : function.end_lineno])))
    changes = 0
    for node in ast.walk(parsed):
        if (
            mode == "owner_ambiguity"
            and isinstance(node, ast.If)
            and isinstance(node.test, ast.Name)
            and node.test.id == "ambiguous_keys"
        ):
            node.test = ast.BoolOp(
                op=ast.And(),
                values=[
                    node.test,
                    ast.Call(
                        func=ast.Name(id="_c07_ambiguity_guard_enabled", ctx=ast.Load()),
                        args=[],
                        keywords=[],
                    ),
                ],
            )
            changes += 1
        elif (
            mode == "runtime_injection"
            and isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id == "consume_owned_hte_completion"
        ):
            selected = [k for k in node.keywords if k.arg == "source_projection_verifier"]
            if (
                len(selected) != 1
                or not isinstance(selected[0].value, ast.Name)
                or selected[0].value.id != "verify_hte_source_projection_join"
            ):
                raise ValueError("pinned receiver callback shape changed")
            node.keywords = [k for k in node.keywords if k.arg != "source_projection_verifier"]
            changes += 1
    if changes != 1:
        raise ValueError("control does not remove exactly one pinned runtime property")
    ast.fix_missing_locations(parsed)
    test_name = (
        "test_hte_projection_preserves_canonical_owner_refusals_as_typed_join_limits"
        if mode == "owner_ambiguity"
        else "test_owned_hte_outbox_records_first_assessment_without_authority_promotion"
    )
    test_function = _function(ast.parse(test), test_name)
    predicates = []
    for node in ast.walk(test_function):
        if mode == "owner_ambiguity" and isinstance(node, ast.With):
            for item in node.items:
                call = item.context_expr
                if (
                    isinstance(call, ast.Call)
                    and isinstance(call.func, ast.Attribute)
                    and isinstance(call.func.value, ast.Name)
                    and call.func.value.id == "pytest"
                    and call.func.attr == "raises"
                    and len(call.args) == 1
                    and isinstance(call.args[0], ast.Attribute)
                    and call.args[0].attr == "ValueOwnerAccessError"
                ):
                    predicates.append(node.lineno)
        elif (
            mode == "runtime_injection"
            and isinstance(node, ast.Assert)
            and ast.dump(node.test)
            == ast.dump(ast.parse("len(source_join_calls) >= 2", mode="eval").body)
        ):
            predicates.append(node.lineno)
    if len(predicates) != 1:
        raise ValueError("pinned real test predicate changed")
    duplicate_index = None
    if mode == "owner_ambiguity":
        declarations = [
            d
            for d in test_function.decorator_list
            if isinstance(d, ast.Call)
            and isinstance(d.func, ast.Attribute)
            and d.func.attr == "parametrize"
        ]
        if len(declarations) != 1 or not isinstance(declarations[0].args[1], (ast.List, ast.Tuple)):
            raise ValueError("owner refusal case quantity changed")
        declaration = declarations[0]
        parameters = ast.literal_eval(declaration.args[0])
        position = parameters.index("duplicate_cell")
        indices = [
            i
            for i, row in enumerate(declaration.args[1].elts)
            if isinstance(row, ast.Tuple)
            and isinstance(row.elts[position], ast.Constant)
            and row.elts[position].value is True
        ]
        if len(indices) != 1:
            raise ValueError("owner control lacks a unique declared duplicate-cell input")
        duplicate_index = indices[0]
    return (ast.unparse(parsed) + "\n").encode(), predicates[0], duplicate_index


def _finite(value: object) -> bool:
    return isinstance(value, (float, int)) and not isinstance(value, bool) and math.isfinite(value)


def _semantic_signal(control: dict[str, Any], mode: str) -> bool:
    if mode == "owner_ambiguity":
        for observation in control.get("owner_observations", []):
            if observation.get("result") != "returned":
                continue
            for cell in observation.get("ambiguous_cells", []):
                values = cell.get("controlled_values")
                if (
                    not isinstance(values, list)
                    or len(values) <= 1
                    or not all(map(_finite, values))
                ):
                    continue
                mean = math.fsum(values) / len(values)
                if cell.get("independent_mean") == mean and cell.get("returned_value") == mean:
                    return True
        return False
    return any(
        row.get("receipt_status") in {"admitted", "already_admitted"}
        and row.get("verifier_argument_present") is False
        and isinstance(row.get("observation_ref"), dict)
        and not row.get("observer_error")
        and row.get("outcome_kind") == "interval_estimate"
        and _finite(row.get("theta"))
        and _finite(row.get("lower_bound"))
        and _finite(row.get("upper_bound"))
        and row["lower_bound"] <= row["upper_bound"]
        and row.get("routing_status") == "unavailable"
        and "source_variable_to_array_join_refused:source_projection_verifier_unavailable"
        in row.get("limitations", ())
        for row in control.get("completion_observations", [])
    )


def _junit_node(case: ET.Element) -> str:
    return case.attrib["classname"].replace(".", "/") + ".py::" + case.attrib["name"]


def _reconcile_control(
    control: dict[str, Any],
    plan: dict[str, Any],
    output: Path,
    cases: list[ET.Element],
    required: list[Path],
) -> dict[str, Any]:
    env = plan["extra_env"]
    mode = env["POLISYOS_C07_CONTROL_MODE"]
    if mode not in {"owner_ambiguity", "runtime_injection"}:
        raise ValueError("unknown property control")
    plugin = _relative_file(control["plugin_path"], ROOT)
    required.append(plugin)
    expected_plugin = (Path(env["PYTHONPATH"]) / "c07_removal_plugin.py").resolve(strict=True)
    if (
        plugin != expected_plugin
        or control["plugin_sha256"] != env["POLISYOS_C07_CONTROL_PLUGIN_SHA256"]
        or _sha(plugin) != control["plugin_sha256"]
        or env["PYTEST_PLUGINS"] != "c07_removal_plugin"
    ):
        raise ValueError("actual control plugin bytes/locator are not bound to the issued plan")
    if (
        control.get("mode") != mode
        or control.get("source_head") != plan["source_head"]
        or control.get("source_tree") != plan["source_tree"]
        or control.get("source_test_pins") != plan["source_test_pins"]
        or json.loads(env["POLISYOS_C07_CONTROL_PINS"]) != plan["source_test_pins"]
    ):
        raise ValueError("control identity/pins differ from the exact issued source")
    if control.get("python") != plan["backend_metadata"]["python"]:
        raise ValueError("control Python backend differs from issued metadata")
    source_path = (
        "src/polisyos/runtime/quality/generation_cycle.py"
        if mode == "owner_ambiguity"
        else "src/polisyos/runtime/http/services/control/run_lifecycle.py"
    )
    test_path = (
        "tests/unit/runtime/quality/test_hte_source_projection.py"
        if mode == "owner_ambiguity"
        else "tests/unit/runtime/http/test_search_hte_first_assessment_outbox.py"
    )
    original = _git("show", plan["source_head"] + ":policy-engine/" + source_path)
    test = _git("show", plan["source_head"] + ":policy-engine/" + test_path)
    active, predicate_line, duplicate_index = _control_shape(original, mode, test)
    active_path = _relative_file(control["active_function_source_path"], output)
    required.append(active_path)
    if (
        active_path.parent != output.resolve()
        or active_path.read_bytes() != active
        or _sha(active_path) != control["active_function_source_sha256"]
        or control.get("active_compiler_filename") != str(active_path)
    ):
        raise ValueError("active executable bytes are not the exact one-property source transform")
    for key in (
        "original_function_code_sha256",
        "active_function_code_sha256",
        "installed_function_code_sha256",
        "observer_plugin_code_sha256",
    ):
        if not isinstance(control.get(key), str) or not DIGEST.fullmatch(control[key]):
            raise ValueError("active/original/observer executable custody digest unavailable")
    if control["original_function_code_sha256"] == control["active_function_code_sha256"]:
        raise ValueError("recorded executable property did not change")
    installed_key = (
        "observer_plugin_code_sha256"
        if mode == "owner_ambiguity"
        else "active_function_code_sha256"
    )
    if control["installed_function_code_sha256"] != control[installed_key]:
        raise ValueError("recorded installed executable differs from the declared active/observer")
    custody = [
        "source_test_pins_unchanged",
        "plugin_bytes_unchanged",
        "head_unchanged",
        "tree_unchanged",
        "installed_function_unchanged",
        "original_function_restored",
        "namespace_override_unchanged",
    ]
    if mode == "runtime_injection":
        custody += ["consume_observer_still_installed", "consume_observer_restored"]
    else:
        override = control.get("namespace_override", {})
        if (
            override.get("name") != "_c07_ambiguity_guard_enabled"
            or override.get("value_at_admission") is not False
            or not DIGEST.fullmatch(override.get("code_sha256", ""))
        ):
            raise ValueError("removed owner predicate/namespace custody unavailable")
    if (
        any(control.get(key) is not True for key in custody)
        or control.get("runtime_outcome") != "FINISHED"
        or control.get("pytest_exitstatus") != 1
    ):
        raise ValueError(
            "retained in-process restoration/custody observations do not establish control"
        )
    nodes = [_junit_node(case) for case in cases]
    if control.get("selected_nodes") != nodes or any(
        not any(node == selected or node.startswith(selected + "[") for selected in plan["nodes"])
        for node in nodes
    ):
        raise ValueError(
            "control actual selected cases differ from retained JUnit/issued selection"
        )
    expected_failure = [nodes[duplicate_index]] if duplicate_index is not None else plan["nodes"]
    if control.get("expected_property_failure_nodes") != expected_failure:
        raise ValueError("declared failed case is not the source-derived discriminating input")
    reports = control.get("reports", [])
    phase_counts = Counter((row["node"], row["when"]) for row in reports)
    expected_phases = Counter(
        (node, phase) for node in nodes for phase in ("setup", "call", "teardown")
    )
    if phase_counts != expected_phases or any(
        row["outcome"] not in {"passed", "failed"} for row in reports
    ):
        raise ValueError("actual complete report/phase quantity differs from selected cases")
    failures = [row for row in reports if row["outcome"] == "failed"]
    if len(failures) != 1:
        raise ValueError("control did not fail exactly one real test assertion")
    failure = failures[0]
    location = Path(failure.get("failure_path", ""))
    if not location.is_absolute():
        location = PRODUCT / location
    if (
        failure["when"] != "call"
        or [failure["node"]] != expected_failure
        or failure.get("failure_line") != predicate_line
        or location.resolve() != (PRODUCT / test_path).resolve()
        or control.get("test_path") != test_path
        or control.get("test_discriminator_line") != predicate_line
    ):
        raise ValueError("actual failure does not reach the pinned property assertion")
    junit_failed = [_junit_node(case) for case in cases if case.find("failure") is not None]
    if junit_failed != expected_failure:
        raise ValueError("retained JUnit failure is not the discriminating real test")
    signal = _semantic_signal(control, mode)
    if not signal:
        raise ValueError("retained actual values do not exhibit the removed-property divergence")
    if (
        control.get("observed_semantic_signal") is not True
        or control.get("targeted_assertion_failure") is not True
        or control.get("control_discriminator_satisfied") is not True
    ):
        raise ValueError("plugin summary conflicts with independently reconciled observations")
    return {
        "mode": mode,
        "selected_cases": len(nodes),
        "assertion_failure": expected_failure,
        "predicate_line": predicate_line,
        "semantic_signal": "recomputed from retained values, not summary booleans",
        "active_source": (
            "exact one-property transform independently derived from pinned Git source"
        ),
        "object_restoration": (
            "observed by the exact plan-bound in-process plugin; not replayed post hoc"
        ),
        "runtime_code_digests": (
            "opaque plugin-observed identifiers; marshal digests are not independently "
            "reconstructed from compilation or treated as file-content proof"
        ),
    }


def main() -> None:
    """Qualify complete, source-bound deciding bytes or record NOT_ESTABLISHED."""
    parser = argparse.ArgumentParser()
    parser.add_argument("plan", type=Path)
    args = parser.parse_args()
    plan_path = args.plan.resolve(strict=True)
    plan = _read_json(plan_path)
    if not re.fullmatch(r"[A-Za-z0-9_-]+", plan["case_id"]):
        raise ValueError("invalid exact native case ID")
    output = plan_path.parent / plan["case_id"]
    audit_path = output / "audit-result.json"
    audit = _read_json(audit_path)
    result = audit["result"]
    required = [
        plan_path,
        audit_path,
        output / "source-profile-freeze.json",
        output / "pytest.xml",
        Path(__file__).resolve(),
    ]
    reasons = []
    readset_binding = control_binding = None
    if plan.get("qualification_script_sha256") != _sha(Path(__file__)):
        reasons.append("actual qualifier bytes are not bound to the issued exact plan")
    if audit["plan"] != plan:
        reasons.append("captured plan differs from issued exact plan")
    if (
        not result.get("complete")
        or result.get("aborted_reason")
        or not result.get("process_group_gone")
    ):
        reasons.append("command incomplete, aborted or process group not gone")
    if audit.get("current_mismatches"):
        reasons.append("runner observed loaded Python source readset mismatch")
    if (
        audit["guard_after"]["head"] != plan["source_head"]
        or _git("rev-parse", plan["source_head"] + "^{tree}").decode().strip()
        != plan["source_tree"]
    ):
        reasons.append("captured source HEAD or immutable committed tree differs from plan")
    try:
        freeze_path = output / "source-profile-freeze.json"
        freeze = _read_json(freeze_path)
        if _sha(freeze_path) != audit["source_profile_freeze_sha256"] or freeze.get(
            "plan_sha256"
        ) != _sha(plan_path):
            raise ValueError("source/profile freeze bytes or issued plan binding mismatch")
        if any(
            freeze["extra_env"].get(key) != value
            for key, value in plan.get("extra_env", {}).items()
        ):
            raise ValueError("actual captured control environment differs from the issued plan")
        for key in ("stdout_path", "stderr_path"):
            required.append(_relative_file(str(output / result[key]), output))
        readset_binding = _reconcile_readsets(audit, plan, freeze, output, required)
    except (OSError, KeyError, TypeError, ValueError) as exc:
        reasons.append(f"loaded-source custody NOT_ESTABLISHED: {exc}")
    cases = []
    try:
        cases = list(ET.parse(output / "pytest.xml").iter("testcase"))  # noqa: S314 -- own pytest capture
        actual_junit = {
            "tests": len(cases),
            "failures": sum(case.find("failure") is not None for case in cases),
            "errors": sum(case.find("error") is not None for case in cases),
            "skipped": sum(case.find("skipped") is not None for case in cases),
        }
        if actual_junit != result.get("junit") or actual_junit != plan["expected_junit"]:
            raise ValueError(
                "retained complete JUnit differs from captured/issued complete quantity"
            )
    except (OSError, ET.ParseError, KeyError, ValueError) as exc:
        reasons.append(f"test outcome NOT_ESTABLISHED: {exc}")
    mode = plan.get("extra_env", {}).get("POLISYOS_C07_CONTROL_MODE")
    if result.get("return_code") != (1 if mode else 0):
        reasons.append("actual exit differs from declared positive/removal outcome")
    if mode:
        control_path = output / "control-mutation.json"
        required.append(control_path)
        try:
            control_binding = _reconcile_control(
                _read_json(control_path), plan, output, cases, required
            )
        except (OSError, KeyError, TypeError, ValueError, IndexError) as exc:
            reasons.append(f"property-removal custody NOT_ESTABLISHED: {exc}")
    for path in required:
        if not path.is_file():
            reasons.append(f"required deciding output bytes unavailable: {path}")
    evidence = [
        {"path": str(path), "bytes": path.stat().st_size, "sha256": _sha(path)}
        for path in sorted(set(required))
        if path.is_file()
    ]
    record = {
        "source_head": plan["source_head"],
        "source_tree": plan["source_tree"],
        "plan_path": str(plan_path),
        "plan_sha256": _sha(plan_path),
        "case_id": plan["case_id"],
        "command_test_outcome": result.get("junit"),
        "command_exit": result.get("return_code"),
        "verdict": "NOT_ESTABLISHED"
        if reasons
        else "CONTROL_DISCRIMINATES"
        if mode
        else "TARGETED_PASS",
        "reasons": reasons,
        "readset_binding": readset_binding,
        "control_binding": control_binding,
        "wall_seconds": result.get("wall_seconds"),
        "peak_sampled_process_tree_rss_bytes": result.get("max_sampled_process_tree_rss_bytes"),
        "deciding_evidence": evidence,
        "scope": (
            "One exact captured C07 property command; not full E02/S1/B161 or G acceptance. "
            "Removal assertion FAIL remains a test FAIL; its independently reconciled "
            "discriminator can qualify that deliberate negative."
        ),
        "closure_ids": [],
    }
    target = output / "coordinator-qualification.json"
    encoded = json.dumps(record, indent=2) + "\n"
    if target.exists():
        if target.read_text() != encoded:
            raise FileExistsError(f"qualification conflict; preserved prior receipt: {target}")
    else:
        target.write_text(encoded)
    sys.stdout.write(json.dumps(record, sort_keys=True) + "\n")
    raise SystemExit(1 if reasons else 0)


if __name__ == "__main__":
    main()
