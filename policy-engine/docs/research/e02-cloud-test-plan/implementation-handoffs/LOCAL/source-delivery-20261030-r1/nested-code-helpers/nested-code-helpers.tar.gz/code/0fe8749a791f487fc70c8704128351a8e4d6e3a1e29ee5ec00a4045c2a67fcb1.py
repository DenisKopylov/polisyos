from pathlib import Path
import hashlib,json,difflib,ast,subprocess
p=Path(__file__).resolve().parent; out=p/'physical-reader-r1';out.mkdir(exist_ok=True)
paths=['policy-engine/src/polisyos/foundry/data_plane/bindings.py','policy-engine/tests/unit/runtime/http/test_observational_source_access.py']
before={x:(p/'postimages'/x).read_text() for x in paths}; after=dict(before)
x=paths[0]
old='''        if (
            normalized_bytes != effective_read.raw_payload_bytes'''
new='''        # The submitted source is provenance. Normalization and its physical
        # binding are derived artifacts written under the same actual custody;
        # their exact selected lineage still binds the independently read source.
        if effective_read.manifest.tenant_context != binding_read.manifest.tenant_context:
            raise HTEInputPreparationRefusal("source_binding_legacy_derived_custody_mismatch")
        if (
            normalized_bytes != effective_read.raw_payload_bytes'''
assert after[x].count(old)==1;after[x]=after[x].replace(old,new)
old='''            or effective_read.manifest.tenant_context != submitted_read.manifest.tenant_context
'''
assert after[x].count(old)==1;after[x]=after[x].replace(old,'')
after[x]=after[x].replace('''    DTO, and rejects any field, array, row-order, or profile drift. It proves
''','''    DTO, and rejects any field, array, row-order, or profile drift. Legacy
    normalization and the binding must share derived custody; source ownership
    remains provenance bound through exact selected lineage. It proves
''')
x=paths[1]
old='''    from polisyos.foundry.data_plane import prepare_hte_observational_input

    case = request.getfixturevalue("scoped_source_runtime")'''
new='''    from polisyos.foundry.data_plane import (
        HTEInputPreparationRefusal,
        load_hte_physical_source_materialization_binding,
        prepare_hte_observational_input,
    )
    from polisyos.foundry.data_plane.bindings import _persist_hte_physical_source_binding

    case = request.getfixturevalue("scoped_source_runtime")'''
assert after[x].count(old)==2; head,tail=after[x].rsplit(old,1);after[x]=head+new+tail
old='''        assert physical.manifest.tenant_context.tenant_id == case["tenant_b"]
        if protocol == "legacy_hte_json_v1":'''
new='''        assert physical.manifest.tenant_context.tenant_id == case["tenant_b"]
        # Re-enter the actual resolve/recompute consumer, not only its manifest.
        reopened = load_hte_physical_source_materialization_binding(
            store=owner,
            binding_ref=prepared.materialization_binding_ref,
            expected_submitted_ref=source,
            expected_effective_ref=prepared.effective_ref,
            limits=admission.limits,
            expected_data=prepared.data,
        )
        assert reopened.submitted_ref == source
        assert reopened.effective_ref == prepared.effective_ref
        assert reopened.binding_scope == "physical_materialization_only"
        assert reopened.semantic_alignment_status == "not_established"
        if protocol == "legacy_hte_json_v1":'''
assert after[x].count(old)==1;after[x]=after[x].replace(old,new)
old='''            assert effective.manifest.tenant_context.tenant_id == case["tenant_b"]
        admitted_ref = service.persist_content_admitted_intent('''
new='''            assert effective.manifest.tenant_context.tenant_id == case["tenant_b"]
            # Genuine Core-produced alternate binding profile: all bytes,
            # selected input refs and recomputation agree, but its derived
            # custody conflicts with the normalized artifact's writer B.
            with tenant_scope(None, tenant_id=case["tenant_a"], cell_id=case["cell"]):
                conflicting = _persist_hte_physical_source_binding(
                    store=owner.for_tenant(case["tenant_a"], cell_id=case["cell"]),
                    binding=reopened,
                    source_governance=prepared.source_governance,
                    tenant_context=prepared.source_tenant_context,
                    limits=admission.limits,
                )
            assert conflicting.artifact_id == prepared.materialization_binding_ref.artifact_id
            assert conflicting.manifest_profile_sha256 != (
                prepared.materialization_binding_ref.manifest_profile_sha256
            )
            owner._ownership_index.record_view_owner(
                conflicting.artifact_id,
                conflicting.manifest_profile_sha256,
                tenant_id=case["tenant_b"],
                cell_id=case["cell"],
            )
            conflicting_read = read_core_manifest_profile_bounded(
                owner, conflicting, max_manifest_bytes=65_536
            )
            assert conflicting_read.manifest.tenant_context.tenant_id == case["tenant_a"]
            with pytest.raises(
                HTEInputPreparationRefusal,
                match="source_binding_legacy_derived_custody_mismatch",
            ):
                load_hte_physical_source_materialization_binding(
                    store=owner,
                    binding_ref=conflicting,
                    expected_submitted_ref=source,
                    expected_effective_ref=prepared.effective_ref,
                    limits=admission.limits,
                    expected_data=prepared.data,
                )
        admitted_ref = service.persist_content_admitted_intent('''
assert after[x].count(old)==1;after[x]=after[x].replace(old,new)
h=lambda b:hashlib.sha256(b).hexdigest();rows=[];patch=''
for x in paths:
 b=after[x].encode();ast.parse(b,filename=x);q=out/'postimages'/x;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
 rows.append({'path':x,'preimage_sha256':h(before[x].encode()),'postimage_sha256':h(b),'bytes':len(b),'postimage':'postimages/'+x})
 patch+=''.join(difflib.unified_diff(before[x].splitlines(True),after[x].splitlines(True),fromfile='a/'+x,tofile='b/'+x))
(out/'source.patch').write_text(patch)
manifest={'schema':'policyos.e02.sparse_delta.v1','case':'C71-r2-physical-reader-r1','parent_manifest_locator':'../manifest.json','parent_manifest_sha256':h((p/'manifest.json').read_bytes()),'finding_bucket':'SAME source-origin/derived-writer class; widen actual legacy physical resolve/recompute consumer','files':rows,'patch':'source.patch','patch_sha256':h((out/'source.patch').read_bytes()),'runtime':'UNRUN','canonical_index_refs_written':False}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name in ['manifest.json','source.patch']:print(name,h((out/name).read_bytes()))
