"""Observe existing N7 failures without replacing owner code, statuses, or results."""

from __future__ import annotations

import hashlib
import json
import os
import sys
from pathlib import Path

import pytest

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
RAW = ROOT / "LOCAL/raw/e02-execution-20261027"
NATIVE = ROOT / "policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1"
OWNER = ROOT / "policy-engine/src/polisyos/runtime/quality/promotion_sequence.py"
SELECTED = {
    "test_default_controller_custody_and_missing_protected_admission",
    "test_synthetic_independence_source_establishes_mechanics_but_never_authority",
}
_OUTPUT: Path | None = None


def pytest_configure(config):
    global _OUTPUT
    output = Path(os.environ["N7_SEMANTIC_DIAGNOSTICS_OUTPUT"]).absolute()
    assert not output.exists(), "diagnostic output must be fresh"
    for parent in output.parents:
        assert not parent.is_symlink()
    output = output.resolve(strict=False)
    assert output.is_relative_to(RAW) or output.is_relative_to(NATIVE)
    assert output.parent.is_dir()
    header = {
        "schema": "e02.n7.unchanged-owner-diagnostics.r1",
        "observer_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "scope": "selected calls in this parent Python process; no code/default/global/status replacement",
        "runtime_acceptance": "none; diagnostic witness only",
    }
    with output.open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(header) + "\n")
    _OUTPUT = output


def _identity_snapshot():
    module = sys.modules.get("polisyos.runtime.quality.confidence_ledger")
    if module is None:
        return {"module_available": False}
    observation = module.capture_loaded_deployment_identity()
    return {
        "module_available": True,
        "observation": observation.model_dump(mode="json"),
        "import_time_loaded_code_consistent": module._IMPORT_TIME_LOADED_CODE_CONSISTENT,
        "import_time_typed_failure": module._IMPORT_TIME_DEPLOYMENT_IDENTITY_FAILURE,
        "import_time_reason": module._IMPORT_TIME_DEPLOYMENT_IDENTITY_REASON,
        "import_time_owner_root": str(module._IMPORT_TIME_OWNER_ROOT),
    }


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_call(item):
    if item.originalname not in SELECTED:
        yield
        return
    previous = sys.gettrace()
    assert previous is None, "refuse to replace an existing trace observer"
    events = []
    seen = set()
    phases = {
        "resolve_with_credal_reference",
        "_read_model",
        "_verifier_provenance_is_exact",
        "_source_ref_from_bridge_manifest",
        "_resolve_independence_record",
        "_source_synthetic_provenance",
    }

    def trace(frame, event, arg):
        if frame.f_code.co_filename != str(OWNER):
            return None
        frame.f_trace_lines = False
        if frame.f_code.co_name in phases and event in {"call", "return"}:
            observed = {"event": event, "function": frame.f_code.co_name}
            if event == "return":
                observed["return_type"] = type(arg).__name__
                if frame.f_code.co_name == "_verifier_provenance_is_exact":
                    observed["returned_verifier_predicate"] = arg
                elif frame.f_code.co_name == "_source_synthetic_provenance":
                    observed["returned_synthetic_projection"] = arg
                elif frame.f_code.co_name == "_resolve_independence_record" and isinstance(arg, tuple):
                    observed["returned_disposition_and_limitation"] = arg[:2]
            events.append(observed)
        if event == "exception":
            exc_type, exc, _traceback = arg
            key = (frame.f_code.co_name, exc_type.__name__, str(exc))
            if key not in seen:
                seen.add(key)
                events.append(
                    {
                        "function": frame.f_code.co_name,
                        "line": frame.f_lineno,
                        "exception_type": exc_type.__name__,
                        "exception": str(exc),
                    }
                )
        return trace

    sys.settrace(trace)
    try:
        yield
    finally:
        sys.settrace(previous)
        record = {
            "nodeid": item.nodeid,
            "promotion_owner_exception_events": events,
            "actual_sticky_deployment_identity": _identity_snapshot(),
            "code_replacement": False,
            "trace_restored": sys.gettrace() is previous,
        }
        assert _OUTPUT is not None
        with _OUTPUT.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(record, sort_keys=True) + "\n")
