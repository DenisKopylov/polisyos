"""Source-bound C07 property removals with explicit active-code custody.

This opt-in native pytest plugin changes no product file or test assertion. It
transforms one actual frozen owner function in memory, records the distinct
active source/code, observes the real result, and restores all callable objects.
Normal pytest plugins, fixtures, physical-source checks and backends remain.
"""

from __future__ import annotations

import ast
import hashlib
import importlib
import inspect
import json
import marshal
import math
import os
import subprocess
import sys
import textwrap
from collections import defaultdict
from pathlib import Path
from typing import Any

import pytest

_OWNER_PATH = "src/polisyos/runtime/quality/generation_cycle.py"
_LIFECYCLE_PATH = "src/polisyos/runtime/http/services/control/run_lifecycle.py"
_UNIT_PATH = "tests/unit/runtime/quality/test_hte_source_projection.py"
_NATIVE_PATH = "tests/unit/runtime/http/test_search_hte_first_assessment_outbox.py"
_UNIT_FUNCTION = "test_hte_projection_preserves_canonical_owner_refusals_as_typed_join_limits"
_NATIVE_FUNCTION = "test_owned_hte_outbox_records_first_assessment_without_authority_promotion"
_UNIT_NODE = _UNIT_PATH + "::" + _UNIT_FUNCTION
_NATIVE_NODE = _NATIVE_PATH + "::" + _NATIVE_FUNCTION + "[selected-source-unit]"
_STATE: dict[str, Any] = {}


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _code_sha(function: object) -> str:
    if not inspect.isfunction(function):
        raise pytest.UsageError("C07 custody requires a Python function object")
    return _sha(marshal.dumps(function.__code__))


def _required(name: str) -> str:
    value = os.environ.get(name)
    if not value:
        raise pytest.UsageError(f"C07 control input missing: {name}")
    return value


def _save(path: Path, value: object) -> None:
    if path.is_symlink():
        raise pytest.UsageError("C07 control output cannot be a symlink")
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def _git(root: Path, *args: str) -> str:
    return subprocess.check_output(["/usr/bin/git", *args], cwd=root, text=True).strip()  # noqa: S603 -- fixed local executable and pinned arguments


def _predicate_line(path: Path, mode: str) -> int:
    module = ast.parse(path.read_text())
    function_name = _UNIT_FUNCTION if mode == "owner_ambiguity" else _NATIVE_FUNCTION
    functions = [
        node
        for node in module.body
        if isinstance(node, ast.FunctionDef) and node.name == function_name
    ]
    if len(functions) != 1:
        raise pytest.UsageError("C07 control did not find one actual target test")
    candidates = []
    for node in ast.walk(functions[0]):
        if mode == "owner_ambiguity" and isinstance(node, ast.With):
            for context in node.items:
                call = context.context_expr
                if (
                    isinstance(call, ast.Call)
                    and isinstance(call.func, ast.Attribute)
                    and isinstance(call.func.value, ast.Name)
                    and call.func.value.id == "pytest"
                    and call.func.attr == "raises"
                    and len(call.args) == 1
                    and isinstance(call.args[0], ast.Attribute)
                    and call.args[0].attr == "ValueOwnerAccessError"
                ):
                    candidates.append(node.lineno)
        elif mode == "runtime_injection" and isinstance(node, ast.Assert):
            test = node.test
            if (
                isinstance(test, ast.Compare)
                and isinstance(test.left, ast.Call)
                and isinstance(test.left.func, ast.Name)
                and test.left.func.id == "len"
                and len(test.left.args) == 1
                and isinstance(test.left.args[0], ast.Name)
                and test.left.args[0].id == "source_join_calls"
                and len(test.ops) == 1
                and isinstance(test.ops[0], ast.GtE)
                and len(test.comparators) == 1
                and isinstance(test.comparators[0], ast.Constant)
                and test.comparators[0].value == 2
            ):
                candidates.append(node.lineno)
    if len(candidates) != 1:
        raise pytest.UsageError("C07 control test discriminator shape changed")
    return candidates[0]


def _observed_owner_intake(*args: object, **kwargs: object) -> object:
    """Observe the actual removed refusal, without changing inputs or results."""
    cells: dict[tuple[str, int], list[float]] = defaultdict(list)
    for unit, period, value, _dataset, _observation, _condition in kwargs["raw_rows"]:
        number = float(value)
        if math.isfinite(number):
            cells[(str(unit), int(period))].append(number)
    ambiguous = {cell: values for cell, values in cells.items() if len(values) > 1}
    try:
        result = _STATE["active"](*args, **kwargs)
    except Exception as exc:
        if ambiguous:
            _STATE["receipt"]["owner_observations"].append(
                {
                    "ambiguous_cells": len(ambiguous),
                    "result": "raised",
                    "exception": type(exc).__name__,
                }
            )
        raise
    if ambiguous:
        returned = {}
        if result is not None:
            returned = {(row.unit_id, row.period_id): row.outcome_value for row in result[0]}
        _STATE["receipt"]["owner_observations"].append(
            {
                "result": "returned",
                "ambiguous_cells": [
                    {
                        "unit_id": cell[0],
                        "period_id": cell[1],
                        "controlled_values": values,
                        "independent_mean": math.fsum(values) / len(values),
                        "returned_value": returned.get(cell),
                    }
                    for cell, values in sorted(ambiguous.items())
                ],
            }
        )
    return result


def _observed_consume(*args: object, **kwargs: object) -> object:
    """Observe real receipt/CAS output while preserving the original consumer."""
    result = _STATE["consume_original"](*args, **kwargs)
    row: dict[str, Any] = {
        "verifier_argument_present": "source_projection_verifier" in kwargs,
        "receipt_status": result.status,
        "receipt_reason": result.reason_code,
        "observation_ref": None,
    }
    if result.observation_ref is not None:
        row["observation_ref"] = result.observation_ref.model_dump(mode="json")
        try:
            from polisyos.scientist.methods.search import uncertainty

            observation = uncertainty._load_typed_search_artifact(
                kwargs["store"],
                result.observation_ref,
                uncertainty.SearchAssessedObservationV2,
                kind="scientist.search.uncertainty_observation",
            )
            row.update(
                outcome_kind=observation.outcome_kind,
                theta=observation.theta,
                lower_bound=observation.lower_bound,
                upper_bound=observation.upper_bound,
                routing_status=observation.routing_score.status,
                routing_unavailable_reason=observation.routing_score.unavailable_reason,
                limitations=list(observation.limitations),
            )
        except Exception as exc:
            # Observation failure cannot change the consumer's real result;
            # it makes this control non-deciding and is retained explicitly.
            row["observer_error"] = f"{type(exc).__name__}: {exc}"
    _STATE["receipt"]["completion_observations"].append(row)
    return result


def pytest_configure(config: pytest.Config) -> None:
    """Admit exact frozen inputs and install the declared in-memory control."""
    product = Path(config.rootpath).resolve(strict=True)
    if Path.cwd().resolve(strict=True) != product:
        raise pytest.UsageError("C07 control requires the actual product cwd")
    plugin = Path(__file__).resolve(strict=True)
    if _sha(plugin.read_bytes()) != _required("POLISYOS_C07_CONTROL_PLUGIN_SHA256"):
        raise pytest.UsageError("C07 control plugin bytes mismatch")
    pins = json.loads(_required("POLISYOS_C07_CONTROL_PINS"))
    if not isinstance(pins, dict) or not pins:
        raise pytest.UsageError("C07 control needs its complete declared source/test pins")
    for path, digest in pins.items():
        if _sha((product / path).read_bytes()) != digest:
            raise pytest.UsageError(f"C07 correct source/test mismatch: {path}")
    head = _git(product, "rev-parse", "HEAD")
    tree = _git(product, "rev-parse", "HEAD^{tree}")
    if head != _required("POLISYOS_C07_CONTROL_SOURCE_HEAD"):
        raise pytest.UsageError("C07 correct source HEAD mismatch")
    if tree != _required("POLISYOS_C07_CONTROL_SOURCE_TREE"):
        raise pytest.UsageError("C07 correct source tree mismatch")
    output = Path(_required("POLISYOS_C07_CONTROL_OUTPUT")).resolve(strict=True)
    native_output = Path(_required("POLISYOS_R4_INPUT_READSET_DIR")).parent.resolve(strict=True)
    if output != native_output:
        raise pytest.UsageError("C07 output must equal the admitted native output directory")
    active_path = output / "active-control.py"
    receipt_path = output / "control-mutation.json"
    if active_path.exists() or receipt_path.exists():
        raise pytest.UsageError("C07 control outputs already exist")
    mode = _required("POLISYOS_C07_CONTROL_MODE")
    if mode not in {"owner_ambiguity", "runtime_injection"}:
        raise pytest.UsageError("C07 control mode invalid")
    if mode == "owner_ambiguity":
        module = importlib.import_module("polisyos.runtime.quality.generation_cycle")
        owner = module
        target = "_value_owner_rows_from_source_rows"
        source_path = product / _OWNER_PATH
        test_path = product / _UNIT_PATH
    else:
        module = importlib.import_module("polisyos.runtime.http.services.control.run_lifecycle")
        owner = module.ControlPlaneService
        target = "_deliver_search_hte_completion_outbox"
        source_path = product / _LIFECYCLE_PATH
        test_path = product / _NATIVE_PATH
    if Path(module.__file__).resolve(strict=True) != source_path.resolve(strict=True):
        raise pytest.UsageError("C07 loaded owner from a different source")
    original = getattr(owner, target)
    original_source = textwrap.dedent(inspect.getsource(original))
    parsed = ast.parse(original_source)
    changes = 0
    if mode == "owner_ambiguity":
        for node in ast.walk(parsed):
            if (
                isinstance(node, ast.If)
                and isinstance(node.test, ast.Name)
                and node.test.id == "ambiguous_keys"
            ):
                node.test = ast.BoolOp(
                    op=ast.And(),
                    values=[
                        node.test,
                        ast.Call(
                            func=ast.Name(id="_c07_ambiguity_guard_enabled", ctx=ast.Load()),
                            args=[],
                            keywords=[],
                        ),
                    ],
                )
                changes += 1
        description = (
            "Suppress only the canonical duplicate-cell refusal; preserve"
            " unit/source rules and marker strings"
        )
    else:
        for node in ast.walk(parsed):
            if (
                isinstance(node, ast.Call)
                and isinstance(node.func, ast.Name)
                and node.func.id == "consume_owned_hte_completion"
            ):
                selected = [
                    keyword
                    for keyword in node.keywords
                    if keyword.arg == "source_projection_verifier"
                ]
                if (
                    len(selected) != 1
                    or not isinstance(selected[0].value, ast.Name)
                    or selected[0].value.id != "verify_hte_source_projection_join"
                ):
                    raise pytest.UsageError("C07 actual receiver injection shape changed")
                node.keywords = [
                    keyword
                    for keyword in node.keywords
                    if keyword.arg != "source_projection_verifier"
                ]
                changes += 1
        description = (
            "Remove only the actual receiver callback argument; preserve "
            "its import, contracts, native consumer and source markers"
        )
    if changes != 1:
        raise pytest.UsageError(
            f"C07 control requires one actual property transform, got {changes}"
        )
    ast.fix_missing_locations(parsed)
    active_source = ast.unparse(parsed) + "\n"
    active_path.write_text(active_source)
    namespace = dict(vars(module))
    namespace["_c07_ambiguity_guard_enabled"] = lambda: False
    exec(compile(active_source, str(active_path), "exec"), namespace)  # noqa: S102
    active = namespace[target]
    active.__qualname__ = original.__qualname__
    if _code_sha(active) == _code_sha(original):
        raise pytest.UsageError("C07 control executable code did not change")
    _STATE.update(
        mode=mode,
        product=product,
        module=module,
        owner=owner,
        target=target,
        original=original,
        active=active,
        pins=pins,
        receipt_path=receipt_path,
        control_predicate=namespace["_c07_ambiguity_guard_enabled"],
        receipt={
            "mode": mode,
            "property_removed": description,
            "source_head": head,
            "source_tree": tree,
            "source_test_pins": pins,
            "plugin_path": str(plugin),
            "plugin_sha256": _sha(plugin.read_bytes()),
            "python": sys.version,
            "target": module.__name__ + "." + original.__qualname__,
            "namespace_override": (
                {
                    "name": "_c07_ambiguity_guard_enabled",
                    "value_at_admission": namespace["_c07_ambiguity_guard_enabled"](),
                    "code_sha256": _code_sha(namespace["_c07_ambiguity_guard_enabled"]),
                }
                if mode == "owner_ambiguity"
                else None
            ),
            "original_function_source_sha256": _sha(original_source.encode()),
            "original_function_code_sha256": _code_sha(original),
            "active_function_source_path": str(active_path),
            "active_function_source_sha256": _sha(active_path.read_bytes()),
            "active_function_code_sha256": _code_sha(active),
            "active_compiler_filename": active.__code__.co_filename,
            "test_discriminator_line": _predicate_line(test_path, mode),
            "test_path": str(test_path.relative_to(product)),
            "reports": [],
            "owner_observations": [],
            "completion_observations": [],
            "runtime_outcome": "RUNNING",
            "closure_ids": [],
            "limitations": [
                (
                    "Deliberate in-memory removal: readset file hashes describe c"
                    "orrect frozen files; active function code is separately iden"
                    "tified"
                ),
                (
                    "This is a bounded property control, not a product PASS, all-"
                    "E02 claim or G acceptance"
                ),
            ],
        },
    )
    if mode == "owner_ambiguity":
        installed = _observed_owner_intake
    else:
        installed = active
        from polisyos.scientist.methods.search import uncertainty

        _STATE["consume_module"] = uncertainty
        _STATE["consume_original"] = uncertainty.consume_owned_hte_completion
        uncertainty.consume_owned_hte_completion = _observed_consume
    _STATE["installed"] = installed
    setattr(owner, target, installed)
    _STATE["receipt"]["installed_function_code_sha256"] = _code_sha(installed)
    _STATE["receipt"]["observer_plugin_code_sha256"] = _code_sha(
        _observed_owner_intake if mode == "owner_ambiguity" else _observed_consume
    )
    _save(receipt_path, _STATE["receipt"])


def pytest_collection_finish(session: pytest.Session) -> None:
    """Bind control coverage to the actual finite selected test quantity."""
    if not _STATE:
        return
    nodes = [item.nodeid for item in session.items]
    if _STATE["mode"] == "owner_ambiguity":
        if len(nodes) != 5 or any(not node.startswith(_UNIT_NODE + "[") for node in nodes):
            raise pytest.UsageError("C07 owner removal requires the five actual refusal cases")
        expected = [
            item.nodeid
            for item in session.items
            if item.callspec.params.get("duplicate_cell") is True
        ]
        if len(expected) != 1:
            raise pytest.UsageError("C07 owner control needs exactly one duplicate-cell case")
    else:
        if nodes != [_NATIVE_NODE]:
            raise pytest.UsageError(
                "C07 injection removal requires the exact real joined native witness"
            )
        expected = nodes
    _STATE["receipt"]["selected_nodes"] = nodes
    _STATE["receipt"]["expected_property_failure_nodes"] = expected


def pytest_runtest_logreport(report: pytest.TestReport) -> None:
    """Retain actual assertion outcomes; setup/backend errors never count as proof."""
    if not _STATE:
        return
    row = {"node": report.nodeid, "when": report.when, "outcome": report.outcome}
    if report.failed:
        row["longrepr_sha256"] = _sha(str(report.longrepr).encode())
        traceback = getattr(report.longrepr, "reprtraceback", None)
        entries = getattr(traceback, "reprentries", ())
        if entries:
            location = getattr(entries[-1], "reprfileloc", None)
            if location is not None:
                row["failure_path"] = str(location.path)
                row["failure_line"] = int(location.lineno)
    _STATE["receipt"]["reports"].append(row)


def pytest_sessionfinish(session: pytest.Session, exitstatus: int) -> None:
    """Record executable custody and restore original callable objects."""
    if not _STATE:
        return
    receipt = _STATE["receipt"]
    receipt["pytest_exitstatus"] = int(exitstatus)
    receipt["runtime_outcome"] = "FINISHED"
    receipt["source_test_pins_unchanged"] = all(
        _sha((_STATE["product"] / path).read_bytes()) == digest
        for path, digest in _STATE["pins"].items()
    )
    receipt["plugin_bytes_unchanged"] = (
        _sha(Path(receipt["plugin_path"]).read_bytes()) == receipt["plugin_sha256"]
    )
    receipt["head_unchanged"] = (
        _git(_STATE["product"], "rev-parse", "HEAD") == receipt["source_head"]
    )
    receipt["tree_unchanged"] = (
        _git(_STATE["product"], "rev-parse", "HEAD^{tree}") == receipt["source_tree"]
    )
    receipt["installed_function_unchanged"] = (
        getattr(_STATE["owner"], _STATE["target"]) is _STATE["installed"]
    )
    setattr(_STATE["owner"], _STATE["target"], _STATE["original"])
    receipt["original_function_restored"] = (
        getattr(_STATE["owner"], _STATE["target"]) is _STATE["original"]
    )
    receipt["namespace_override_unchanged"] = _STATE["mode"] != "owner_ambiguity" or (
        _STATE["active"].__globals__["_c07_ambiguity_guard_enabled"] is _STATE["control_predicate"]
        and _STATE["control_predicate"]() is False
    )
    if _STATE["mode"] == "runtime_injection":
        receipt["consume_observer_still_installed"] = (
            _STATE["consume_module"].consume_owned_hte_completion is _observed_consume
        )
        _STATE["consume_module"].consume_owned_hte_completion = _STATE["consume_original"]
        receipt["consume_observer_restored"] = (
            _STATE["consume_module"].consume_owned_hte_completion is _STATE["consume_original"]
        )
    if _STATE["mode"] == "owner_ambiguity":
        signal = any(
            item.get("result") == "returned"
            and any(
                cell["returned_value"] == cell["independent_mean"]
                for cell in item.get("ambiguous_cells", ())
            )
            for item in receipt["owner_observations"]
        )
    else:
        signal = any(
            item.get("receipt_status") in {"admitted", "already_admitted"}
            and item.get("verifier_argument_present") is False
            and item.get("outcome_kind") == "interval_estimate"
            and item.get("lower_bound") is not None
            and item.get("upper_bound") is not None
            and item.get("routing_status") == "unavailable"
            and "source_variable_to_array_join_refused:source_projection_verifier_unavailable"
            in item.get("limitations", ())
            for item in receipt["completion_observations"]
        )
    failed = [item for item in receipt["reports"] if item["outcome"] == "failed"]
    expected = receipt.get("expected_property_failure_nodes", [])
    targeted_failure = (
        len(failed) == 1
        and failed[0]["when"] == "call"
        and [failed[0]["node"]] == expected
        and failed[0].get("failure_line") == receipt["test_discriminator_line"]
        and (
            Path(failed[0].get("failure_path", ""))
            if Path(failed[0].get("failure_path", "")).is_absolute()
            else _STATE["product"] / failed[0].get("failure_path", "")
        ).resolve()
        == (_STATE["product"] / receipt["test_path"]).resolve()
    )
    receipt["observed_semantic_signal"] = signal
    receipt["targeted_assertion_failure"] = targeted_failure
    receipt["control_discriminator_satisfied"] = bool(
        int(exitstatus) == 1
        and targeted_failure
        and signal
        and receipt["source_test_pins_unchanged"]
        and receipt["head_unchanged"]
        and receipt["tree_unchanged"]
        and receipt["original_function_restored"]
        and receipt["installed_function_unchanged"]
        and receipt["plugin_bytes_unchanged"]
        and receipt["namespace_override_unchanged"]
        and (
            _STATE["mode"] != "runtime_injection"
            or (
                receipt["consume_observer_still_installed"] and receipt["consume_observer_restored"]
            )
        )
        and not any(item["outcome"] == "skipped" for item in receipt["reports"])
    )
    _save(_STATE["receipt_path"], receipt)
    sys.stdout.write(
        "C07_REMOVAL_CONTROL="
        + json.dumps(
            {
                "mode": receipt["mode"],
                "pytest_exitstatus": int(exitstatus),
                "observed_semantic_signal": signal,
                "targeted_assertion_failure": targeted_failure,
                "control_discriminator_satisfied": receipt["control_discriminator_satisfied"],
                "receipt_path": str(_STATE["receipt_path"]),
            },
            sort_keys=True,
        )
        + "\n"
    )
