from types import FunctionType
from importlib import import_module
def body():
    return None
CODE = body.__code__
bag = {"code": CODE}
chosen = bag.get(unknown_key, opaque_code)
opaque(chosen)
