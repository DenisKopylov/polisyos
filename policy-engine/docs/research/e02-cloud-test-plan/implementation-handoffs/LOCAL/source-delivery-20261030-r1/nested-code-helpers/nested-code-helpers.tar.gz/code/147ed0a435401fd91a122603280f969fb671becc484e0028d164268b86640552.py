"""Four Root-only stdlib controls using the committed shared owner and Mac spawn."""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
import multiprocessing
import os
from pathlib import Path
import sys
import threading
import time
import types

ROOT=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
HERE=Path(__file__).resolve().parents[1]
PROFILE=json.loads((HERE/'runtime-profile.json').read_text())


def silent_exit(sender):
    sender.close()


def unrelated():
    return 3


def main():
    parser=argparse.ArgumentParser();parser.add_argument('control',choices=('bounded','starts','dead','removal'));parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    assert sys.platform=='darwin' and sys.implementation.name=='cpython' and sys.version_info[:2]==(3,14)
    out=args.output;assert out.is_absolute() and out.is_dir() and not out.is_symlink()
    source=ROOT/PROFILE['shared_capture']['path'];data=source.read_bytes();assert hashlib.sha256(data).hexdigest()==PROFILE['shared_capture']['sha256']
    for key in ('E02C_ROOT','E02C_OUT','E02C_INDEX'):assert key not in os.environ,'conflicting shared-owner automatic startup control'
    if args.control=='dead':
        path=ROOT/'policy-engine/tests/_helpers/worker_transport_wait.py'
        spec=importlib.util.spec_from_file_location('canonical_wait',path);wait=importlib.util.module_from_spec(spec);spec.loader.exec_module(wait)
        ctx=multiprocessing.get_context('spawn');parent,sender=ctx.Pipe();process=ctx.Process(target=silent_exit,args=(sender,));process.start();sender.close()
        try:
            process.join(5);assert not process.is_alive() and process.exitcode==0
            entered=time.monotonic()
            try:wait.receive_worker_message(parent,process)
            except AssertionError as error:assert 'without an outcome' in str(error)
            else:raise AssertionError('silent dead child admitted')
            print(json.dumps({'status':'PASS','control':'dead','child_pid':process.pid,'child_exitcode':process.exitcode,'refusal_seconds':time.monotonic()-entered,'helper_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}))
        finally:wait.reap_worker_process(process);parent.close()
        return
    if args.control=='removal':
        text=data.decode();assert 'return sys.monitoring.DISABLE' in text
        source=out/'removed-disable.py';source.write_text(text.replace('return sys.monitoring.DISABLE','return None'))
    spec=importlib.util.spec_from_file_location('_shared_capture_control',source);module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    root=out/'synthetic-root';path=root/'policy-engine/src/polisyos/fixture.py';path.parent.mkdir(parents=True,exist_ok=False)
    body=b'def raising():\n    raise ValueError("actual raise")\ndef ordinary():\n    return 7\n';path.write_bytes(body)
    blob=hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body,usedforsecurity=False).hexdigest();capture=module.ActualCodeCapture(root,{'policy-engine/src/polisyos/fixture.py':blob},out)
    owner_spec=importlib.util.spec_from_file_location('polisyos.synthetic_control',path);owner=importlib.util.module_from_spec(owner_spec);sys.modules[owner_spec.name]=owner
    seen=[];raises=[]
    if args.control=='starts':capture.select_starts(lambda code:code.co_name=='raising',lambda frame:seen.append((frame.f_code.co_name,threading.get_ident())),None)
    capture.start()
    try:
        owner_spec.loader.exec_module(owner)
        if args.control=='starts':
            def call():
                try:owner.raising()
                except ValueError:raises.append(threading.get_ident())
            thread=threading.Thread(target=call);thread.start();thread.join(5);assert not thread.is_alive();call()
        else:
            for _ in range(100_000):assert unrelated()==3
            assert owner.ordinary()==7
    finally:report=capture.report()
    with (out/'capture-report.json').open('x') as output:json.dump(report,output,sort_keys=True)
    if args.control=='starts':
        assert len(seen)==1 and len(raises)==2 and report['selected_return_callbacks']==0
        row=next(row for row in report['observed_selected_first_start_codes'] if row['qualname']=='raising');assert row['selected_first_start_consumed'] and row['compilation_match']
    elif args.control=='bounded':
        assert report['callback_invocations']<100
        refused=[]
        for kind in ('bytecode','globals'):
            image=body.decode().replace('return 7','return 999') if kind=='bytecode' else body.decode()
            code=next(code for code in compile(image,str(path),'exec').co_consts if isinstance(code,types.CodeType) and code.co_name=='ordinary')
            function=types.FunctionType(code,dict(vars(owner)) if kind=='globals' else vars(owner))
            bad=module.ActualCodeCapture(root,{'policy-engine/src/polisyos/fixture.py':blob},out);admitted=[]
            bad.select_starts(lambda candidate:candidate.co_name=='ordinary',lambda frame:admitted.append(frame),None);bad.start()
            try:function()
            finally:bad_report=bad.report()
            assert admitted==[] and any(row.get('compilation_match') is False for row in bad_report['observed_selected_first_start_codes'])
            if kind=='globals':assert any(row.get('origin_error')=='module_globals_not_established' for row in bad_report['observed_selected_first_start_codes'])
            with (out/('auth-negative-'+kind+'.json')).open('x') as output:json.dump(bad_report,output,sort_keys=True)
            refused.append(kind)

    elif args.control=='removal':
        print(json.dumps({'status':'EXPECTED_RED','control':'removal','callbacks':report['callback_invocations'],'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest()}))
        assert report['callback_invocations']<100,'DISABLE removed; actual repeated callback property red'
    print(json.dumps({'status':'PASS','control':args.control,'callbacks':report['callback_invocations'],'selected_starts':len(seen),'actual_raises':len(raises),'return_callbacks':report['selected_return_callbacks'],'auth_refusals':len(refused) if args.control=='bounded' else None,'code_census_complete_for_observed_events':report['code_census_complete_for_observed_events']}))


if __name__=='__main__':main()
