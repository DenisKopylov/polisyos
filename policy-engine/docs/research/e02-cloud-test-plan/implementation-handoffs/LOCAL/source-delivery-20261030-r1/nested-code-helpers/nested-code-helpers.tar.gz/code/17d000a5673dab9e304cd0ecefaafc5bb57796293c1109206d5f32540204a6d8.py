from pathlib import Path
import ast
root=Path.cwd();pkg=root/'LOCAL/raw/e02-execution-20261027/repairs/C49-local-r1'
post=pkg/'postimages'

def edit(rel, fn):
 p=post/rel
 if not p.exists():
  before=(root/rel).read_text();pre=pkg/'preimages'/rel
  pre.parent.mkdir(parents=True,exist_ok=True)
  if not pre.exists():pre.write_text(before)
  p.parent.mkdir(parents=True,exist_ok=True);p.write_text(before)
 text=fn(p.read_text());ast.parse(text);p.write_text(text)

rel=Path('policy-engine/src/polisyos/scientist/agent/_drafter_orchestrator.py')
def orchestrator(s):
 s=s.replace('    ConvergenceState,\n','    ConvergenceState,\n    ConvergenceValidationError,\n',1)
 needle='from polisyos.scientist.orchestration.engine.convergence import ('
 s=s.replace(needle,'from polisyos.scientist.orchestration.engine.budget import BudgetState\n'+needle,1)
 s=s.replace('        metrics: Any | None = None,\n','        metrics: Any | None = None,\n        convergence_budget_state: BudgetState | None = None,\n',1)
 s=s.replace('        self._metrics = metrics\n','        self._metrics = metrics\n        self._convergence_budget_state = convergence_budget_state\n',1)
 s=s.replace('        except Exception as exc:\n            logger.exception("Multipass drafter failed;', '        except ConvergenceValidationError:\n            # Invalid configured stopping/resource inputs must not trigger another LLM call.\n            raise\n        except Exception as exc:\n            logger.exception("Multipass drafter failed;',1)
 s=s.replace('            convergence_detector = ConvergenceDetector(self._config.convergence)','            convergence_detector = ConvergenceDetector(\n                self._config.convergence, budget_state=self._convergence_budget_state\n            )',1)
 s=s.replace('''        if self._config.shadow_mode and pass_results:
            pass1 = pass_results[0]
            if pass1.executed and pass1.draft is not None:
                draft = pass1.draft
''','''        if self._config.shadow_mode and pass_results:
            pass1 = pass_results[0]
            if pass1.executed and pass1.draft is not None:
                checked_state = draft.convergence_state
                if checked_state is not None:
                    checked_state = ConvergenceState.model_validate({
                        **checked_state.model_dump(),
                        "observation_status": "last_checked_in_shadow_run",
                    })
                draft = replace(pass1.draft, convergence_state=checked_state)
''',1)
 return s
edit(rel,orchestrator)

rel=Path('policy-engine/src/polisyos/scientist/agent/drafter_factory.py')
def factory(s):
 s=s.replace('from polisyos.scientist.agent.protocols import DrafterAgent\n','from polisyos.scientist.agent.protocols import DrafterAgent\nfrom polisyos.scientist.orchestration.engine.budget import BudgetState\n',1)
 s=s.replace('    multipass_mode: Literal["off", "active", "shadow"] | None = None,\n','    multipass_mode: Literal["off", "active", "shadow"] | None = None,\n    convergence_budget_state: BudgetState | None = None,\n',1)
 s=s.replace('        config=effective_config,\n','        config=effective_config,\n        convergence_budget_state=convergence_budget_state,\n',1)
 return s
edit(rel,factory)

rel=Path('policy-engine/src/polisyos/scientist/orchestration/engine/convergence.py')
def detector(s):
 s=s.replace('''    def config(self) -> ConvergenceConfig:
        return self._config
''','''    def config(self) -> ConvergenceConfig:
        """Return a detached profile so an observer cannot rewrite an active run."""
        return self._config.model_copy(deep=True)
''',1)
 s=s.replace('''        self._signal_kind = "legacy_numeric"
        self._observation_status = "legacy_numeric_unbound"
''','''        if self._signal_kind != "legacy_numeric":
            self._history.clear()
            self._last_candidate_observation = None
        self._signal_kind = "legacy_numeric"
        self._observation_status = "legacy_numeric_unbound"
''',1)
 return s
edit(rel,detector)

rel=Path('policy-engine/src/polisyos/scientist/methods/search/adversarial.py')
def adversarial(s):
 start=s.index('def _resolve_adversarial_direction(');end=s.index('\n\ndef _is_worse_objective(',start)
 s=s[:start]+'''class StressObjectiveDirectionError(ValueError):
    """Refuse stress evaluation when the raw objective direction is not typed."""

    code = "stress_objective_direction_not_established"


def _resolve_adversarial_direction(base_objective: object) -> OptimizationDirection:
    """Admit the raw direction before any stress evaluator or plateau comparison.

    The legacy duck-composite lower-tail convention remains candidate-only.
    Other values never fall through to an implicit minimization direction.
    """
    if isinstance(base_objective, CompositeObjective):
        if not all(isinstance(item, BaseObjective) for item in base_objective.objectives):
            return OptimizationDirection.MAXIMIZE
    if not isinstance(base_objective, _DirectionProvider):
        raise StressObjectiveDirectionError("stress_objective_direction_not_established")
    direction = base_objective.direction
    if type(direction) is not OptimizationDirection:
        raise StressObjectiveDirectionError("stress_objective_direction_not_established")
    return direction
'''+s[end:]
 return s
edit(rel,adversarial)

rel=Path('policy-engine/src/polisyos/scientist/orchestration/engine/__init__.py')
def facade(s):
 s=s.replace('    "ConvergenceDetector",\n','    "ConvergenceDetector",\n    "ConvergenceObservation",\n',1)
 marker='    "ConvergenceDetector": ('
 start=s.index(marker);end=s.index('\n    ',s.index('),',start)+2)
 s=s[:end]+'''\n    "ConvergenceObservation": (
        "polisyos.scientist.orchestration.engine.convergence", "ConvergenceObservation"
    ),'''+s[end:]
 # Producer budget types are public from their canonical module; no facade alias needed.
 return s
edit(rel,facade)

rel=Path('policy-engine/src/polisyos/scientist/methods/search/__init__.py')
def search_facade(s):
 s=s.replace('    MaxWallTime,\n','    MaxWallTime,\n    PlateauToleranceProfile,\n',1)
 # This facade uses an explicit __all__ list.
 if '    "ImprovementPlateau",\n' in s:
  s=s.replace('    "ImprovementPlateau",\n','    "ImprovementPlateau",\n    "PlateauToleranceProfile",\n',1)
 return s
edit(rel,search_facade)
print('Finished typed direction refusal, real drafter stopping contexts, and manual facade companions; syntax only.')
