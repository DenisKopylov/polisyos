from .api import ANALYTICS_FACADE_EXPORTS as source_map
wrapper = []
wrapper.append('unrelated scalar')
opaque(wrapper)
