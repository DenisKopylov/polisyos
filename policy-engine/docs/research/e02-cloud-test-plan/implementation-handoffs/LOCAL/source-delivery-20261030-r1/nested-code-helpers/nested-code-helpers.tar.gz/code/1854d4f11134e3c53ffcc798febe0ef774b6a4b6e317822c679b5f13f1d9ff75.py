from types import FunctionType
from importlib import import_module
def body(callback):
    return callback("bridge_callback")
if callable(None):
    CODE = body.__code__
else:
    CODE = opaque_code
run = FunctionType(CODE, globals())
