from pathlib import Path
import ast,difflib,hashlib,json
r1=Path('LOCAL/raw/e02-execution-20261027/repairs/C49-local-r1');r2=r1.with_name('C49-local-r2')
rel=Path('policy-engine/src/polisyos/scientist/orchestration/engine/producer_budget.py')
old=(r1/'postimages'/rel).read_text();s=old
needle='    def __call__(self, current_state: BudgetState) -> None:\n'
method='''    def require_bound_state(self, current_state: BudgetState) -> None:
        """Check invocation identity/configuration without inventing a spend read."""
        with self._lock:
            if current_state is not self._state or type(current_state) is not BudgetState:
                raise ProducerBudgetSourceError("control_nl_budget_state_binding_mismatch")
            if self._current_limit() != self._limit:
                raise ProducerBudgetSourceError("control_nl_budget_run_limit_changed")

'''
assert s.count(needle)==1;s=s.replace(needle,method+needle,1)
s=s.replace('''        if current_state is not self._state or type(current_state) is not BudgetState:
            raise ProducerBudgetSourceError("control_nl_budget_state_binding_mismatch")
        with self._lock:
''','''        self.require_bound_state(current_state)
        with self._lock:
''',1)
ast.parse(s)
pre=r2/'preimages'/rel;post=r2/'postimages'/rel;pre.parent.mkdir(parents=True,exist_ok=True);post.parent.mkdir(parents=True,exist_ok=True);pre.write_text(old);post.write_text(s)

rel=Path('policy-engine/src/polisyos/runtime/quality/generation_cycle.py')
base=(r1/'owner-contexts/C41-r8/preimages'/rel).read_text();old=(r1/'owner-contexts/C41-r8/postimages'/rel).read_text();s=old
marker='def _generic_n5_canonical_port_issue(\n'
helper='''def _canonical_n5_budget_binding_issue(
    port: object,
    *,
    expected_observer: ProducerBudgetObserver | None,
    budget_state: BudgetState | None = None,
) -> str | None:
    """Join the one invocation budget owner for default and supplied canonical ports.

    This is identity/configuration admission, not a substitute for the fresh
    per-seed ledger read. Explicit custom contract-testing ports retain their
    separate non-canonical boundary.
    """
    if expected_observer is not None:
        if type(expected_observer) is not ProducerBudgetObserver:
            return "n5_producer_budget_observer_not_canonical"
        if budget_state is not None:
            try:
                expected_observer.require_bound_state(budget_state)
            except ProducerBudgetSourceError:
                return "n5_producer_budget_state_binding_mismatch"
    if type(port) is not JointSimulationPort:
        return None
    if type(port._controller) is not JointSimulationHorizonController:
        return "n5_budget_controller_not_canonical" if expected_observer is not None else None
    if port._controller._producer_budget_observer is not expected_observer:
        return "n5_producer_budget_owner_mismatch"
    return None


'''
assert s.count(marker)==1;s=s.replace(marker,helper+marker,1)
start=s.index(marker);end=s.index('\n\n',s.index('    """Require the real',start)) if False else None
needle='''    cycle_substrate_context: CycleSubstrateContext | None,
) -> str | None:
    """Require the real default N5 port and default production controller configuration."""
'''
replacement='''    cycle_substrate_context: CycleSubstrateContext | None,
    expected_producer_budget_observer: ProducerBudgetObserver | None = None,
) -> str | None:
    """Require the real default N5 port and default production controller configuration."""
'''
assert s.count(needle)==1;s=s.replace(needle,replacement,1)
needle='''    if type(port) is not JointSimulationPort:
        return "generic_cycle_simulation_canonical_n5_port_required"
'''
replacement=needle+'''    budget_issue = _canonical_n5_budget_binding_issue(
        port, expected_observer=expected_producer_budget_observer,
    )
    if budget_issue is not None:
        return budget_issue
'''
assert s.count(needle)==1;s=s.replace(needle,replacement,1)
needle='''        from polisyos.runtime.quality.substrate_registry import (
            current_catalog_serving_source,
        )
'''
# There are other local imports; only the constructor's occurrence after port construction.
idx=s.index(needle,s.index('        self._simulation_port = simulation_port or JointSimulationPort('))
join='''        budget_issue = _canonical_n5_budget_binding_issue(
            self._simulation_port,
            expected_observer=(
                _producer_budget_reconciler
                if type(_producer_budget_reconciler) is ProducerBudgetObserver else None
            ),
        )
        if budget_issue is not None:
            raise GenerationCycleError(budget_issue)
'''
s=s[:idx]+join+s[idx:]
needle='''        if max_cycles < 1:
            raise GenerationCycleError("max_cycles_must_be_positive")
'''
join=needle+'''        budget_issue = _canonical_n5_budget_binding_issue(
            self._simulation_port,
            expected_observer=(
                self._producer_budget_reconciler
                if type(self._producer_budget_reconciler) is ProducerBudgetObserver else None
            ),
            budget_state=budget_state,
        )
        if budget_issue is not None:
            raise GenerationCycleError(budget_issue)
'''
assert s.count(needle)==1;s=s.replace(needle,join,1)
# Bind the same owner at the generic call-site, not just at object construction.
start=s.index('            _generic_n5_canonical_port_issue(\n',s.index('    async def run('))
end=s.index('            )\n',start)
section=s[start:end]
needle='                cycle_substrate_context=self._cycle_substrate_context,\n'
assert section.count(needle)==1
section=section.replace(needle,needle+'''                expected_producer_budget_observer=(
                    self._producer_budget_reconciler
                    if type(self._producer_budget_reconciler) is ProducerBudgetObserver else None
                ),
''',1)
s=s[:start]+section+s[end:]
ast.parse(s)
pre=r2/'owner-contexts/C41-r8/preimages'/rel;post=r2/'owner-contexts/C41-r8/postimages'/rel
pre.parent.mkdir(parents=True,exist_ok=True);post.parent.mkdir(parents=True,exist_ok=True);pre.write_text(base);post.write_text(s)
patch=''.join(difflib.unified_diff(base.splitlines(True),s.splitlines(True),fromfile='a/'+str(rel),tofile='b/'+str(rel)))
(r2/'owner-contexts/C41-r8/generation-budget-context.patch').write_text(patch)
print(json.dumps({'generation_context_preimage':hashlib.sha256(base.encode()).hexdigest(),'postimage':hashlib.sha256(s.encode()).hexdigest(),'patch':hashlib.sha256(patch.encode()).hexdigest(),'runtime':'UNRUN'}))
