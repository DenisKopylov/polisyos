from pathlib import Path
import ast,hashlib,json,difflib,subprocess
r=Path('LOCAL/raw/e02-execution-20261027/repairs/C60-r2');d=r/'delta-r3'
def sha(b):return hashlib.sha256(b).hexdigest()
assert sha((r/'mechanism.patch').read_bytes())=='b13fbb954ba788137003db1672eb3b14389169ccd2983b2bafd9fba33c89c1c9'
def before(path):
 p=r/'postimages'/path
 return p.read_bytes() if p.is_file() else Path(path).read_bytes()
patch='';files=[]
for p in sorted((d/'postimages').rglob('*')):
 if not p.is_file():continue
 path=str(p.relative_to(d/'postimages'));old=before(path);new=p.read_bytes()
 if p.suffix=='.py':ast.parse(new.decode(),filename=path)
 out=d/'preimages'/path;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(old)
 patch+='diff --git a/'+path+' b/'+path+'\n'+''.join(difflib.unified_diff(old.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path))
 files.append({'path':path,'preimage_origin':'frozen-r2-postimage' if (r/'postimages'/path).is_file() else 'current-canonical-readonly','preimage_sha256':sha(old),'postimage_sha256':sha(new),'bytes':len(new)})
(d/'delta.patch').write_text(patch)
check=subprocess.run(['git','apply','--check','--directory='+str(d/'preimages'),str(d/'delta.patch')],capture_output=True,text=True)
assert check.returncode==0,check.stderr
controls=[]
def control(name,path,mutant,test,failure):
 old=(d/'postimages'/path).read_text();ast.parse(mutant,filename=path)
 out=d/'controls'/name/'mutants'/path;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(mutant)
 patch='diff --git a/'+path+' b/'+path+'\n'+''.join(difflib.unified_diff(old.splitlines(keepends=True),mutant.splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path))
 (d/'controls'/name/'property-removal.patch').write_text(patch)
 controls.append({'name':name,'path':path,'correct_sha256':sha(old.encode()),'mutant_sha256':sha(mutant.encode()),'test':test,'expected_named_failure':failure,'outcome':'UNRUN'})
path='policy-engine/src/polisyos/foundry/methods/components/linker.py';s=(d/'postimages'/path).read_text();a=s.index('        issues: list[str] = []',s.index('    def validate_chain('));control('joint-final-gate-rebound',path,s[:a]+'        return []  # property removed, typed markers remain\n'+s[a:],'tests/unit/foundry/methods/components/test_composition_custody.py::test_joint_strict_dag_refuses_missing_input_at_final_gate','DID NOT RAISE ValueError')
control('greedy-matching-rebound',path,s.replace('            augment(target_name, set())','''            for src_slot, _compat in candidate_edges[target_name]:
                if src_slot.name not in matched_sources:
                    matched_sources[src_slot.name] = target_name
                    break'''),'tests/unit/foundry/methods/components/test_composition_custody.py::test_finite_typed_lowering_matches_independent_exhaustive_assignments','bounded exhaustive assignment existence')
control('sequence-uuid-regression',path,(r/'postimages'/path).read_text(),'tests/unit/foundry/methods/test_linker.py::test_sequence_signatures_reconcile_uuid_annotated_links_without_losing_occurrences','UUID Sequence signature compatibility')
path='policy-engine/src/polisyos/foundry/methods/compiler/__init__.py';s=(d/'postimages'/path).read_text().replace('        reconcile_validation_context(chain)\n','        # compile-time reconciliation removed; declaration retained\n',1);a=s.index('        context = reconcile_validation_context(self.chain)',s.index('    def _reconcile_plan'));s=s[:a]+'        return self.chain.validation_context  # execution reconciliation removed\n'+s[a:]
control('compiled-consumer-context',path,s,'tests/unit/foundry/methods/test_compiler.py::test_compiled_executor_reconciles_context_and_exposes_handle_diagnostics','DID NOT RAISE ValueError at forged compile/call context assertion')
(d/'controls/manifest.json').write_text(json.dumps({'controls':controls,'inherited_controls':'R2 controls remain exact except joint-final-gate and greedy-matching, which these rebound variants replace','runtime':'UNRUN'},indent=2)+'\n')
m={'schema':'policyos.e02.c60.r3.review_delta.v1','frozen_base_patch_sha256':'b13fbb954ba788137003db1672eb3b14389169ccd2983b2bafd9fba33c89c1c9','current_head_readonly':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'patch':{'path':str(d/'delta.patch'),'sha256':sha(patch.encode()),'bytes':len(patch.encode())},'files':files,'ast_parse':'PASS; four changed Python files, no imports/runtime','apply_check':{'argv':['git','apply','--check','--directory='+str(d/'preimages'),str(d/'delta.patch')],'exit':check.returncode,'stdout':check.stdout,'stderr':check.stderr},'runtime':'UNRUN','tests':'UNRUN','closure_ids':[]}
(d/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({'patch':m['patch'],'files':len(files),'apply_check':check.returncode,'frozen_base_unchanged':'PASS'}))
