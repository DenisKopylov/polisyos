from types import FunctionType
from importlib import import_module
def body(callback):
    return callback("bridge_callback")
CODE = body.__code__
run = FunctionType(CODE, globals())
del run.__code__
run(import_module)
