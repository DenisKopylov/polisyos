"""Stdlib-only probe of the exact proposed fence class, not a product test."""
from __future__ import annotations

import ast
import fcntl
import hashlib
import json
import os
import tempfile
import threading
from concurrent.futures import Future
from pathlib import Path
from typing import Any

root = Path('LOCAL/raw/e02-execution-20261027/repairs/SQL-owner-chain-r3')
source = root / 'postimages/policy-engine/src/polisyos/scientist/validation/source_admission_owner.py'
raw = source.read_bytes()
tree = ast.parse(raw, filename=str(source))
classes = [node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == '_SourceAcquisitionFence']
assert len(classes) == 1
module = ast.Module(body=[ast.ImportFrom(module='__future__', names=[ast.alias(name='annotations')], level=0), classes[0]], type_ignores=[])
ast.fix_missing_locations(module)
namespace = {'fcntl': fcntl, 'os': os, 'threading': threading, 'Future': Future, 'Any': Any}
exec(compile(module, str(source), 'exec'), namespace)
fence_class = namespace['_SourceAcquisitionFence']
observations = []
with tempfile.TemporaryDirectory(dir=root / 'checks') as directory:
    path = Path(directory) / 'stripe.lock'
    def try_lock() -> bool:
        fd = os.open(path, os.O_CREAT | os.O_RDWR, 0o600)
        try:
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                return False
            fcntl.flock(fd, fcntl.LOCK_UN)
            return True
        finally:
            os.close(fd)

    fd = os.open(path, os.O_CREAT | os.O_RDWR, 0o600)
    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    fence = fence_class(fd)
    first, second = Future(), Future()
    fence.retain_until_complete(first)
    fence.retain_until_complete(second)
    fence.finish()
    observations.append(('caller_finished_both_inflight', try_lock()))
    first.set_result(None)
    observations.append(('one_inflight', try_lock()))
    second.set_result(None)
    observations.append(('all_finished', try_lock()))

    fd = os.open(path, os.O_RDWR)
    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    fence = fence_class(fd)
    complete = Future()
    complete.set_result(None)
    fence.retain_until_complete(complete)
    observations.append(('already_complete_caller_active', try_lock()))
    fence.finish()
    observations.append(('already_complete_caller_finished', try_lock()))

expected = [('caller_finished_both_inflight', False), ('one_inflight', False), ('all_finished', True), ('already_complete_caller_active', False), ('already_complete_caller_finished', True)]
assert observations == expected, observations
print(json.dumps({'source_sha256': hashlib.sha256(raw).hexdigest(), 'scope': 'class-only stdlib probe; no imports, product runtime, process-crash, or network filesystem proof', 'observations': observations}, indent=2))
