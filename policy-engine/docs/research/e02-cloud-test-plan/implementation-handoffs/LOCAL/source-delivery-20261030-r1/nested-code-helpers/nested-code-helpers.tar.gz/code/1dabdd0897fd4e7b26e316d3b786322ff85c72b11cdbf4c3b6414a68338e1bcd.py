from types import FunctionType
def body(value):
    return value and None
CODE = body.__code__
run = FunctionType(CODE, globals())
def later(value):
    return run(value)
