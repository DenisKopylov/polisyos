"""Build the versioned SQL/V3 union successor with SQL rule replay first."""
from __future__ import annotations

import ast
import collections
import copy
import hashlib
import json
import subprocess
from pathlib import Path

repo=Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
product=repo/"policy-engine"
raw=repo/"LOCAL/raw/e02-execution-20261027/repairs/SQL-owner-chain-r3-intake-20261028-r1"
sha=lambda data:hashlib.sha256(data).hexdigest()
old_manifest=raw/"v3-8-after-sql-manifest.json"
assert sha(old_manifest.read_bytes())=="3b92f2c852fa067abbd86f466a3f6ff4ec31cf1ab6b38e5832f1ebe6fe022037"
data=json.loads(old_manifest.read_bytes())
binding="policy-engine/src/polisyos/foundry/data_plane/bindings.py"
test="policy-engine/tests/unit/foundry/data_plane/test_input_bindings_preparation.py"
rows={row["path"]:row for row in data["files"]}
assert sha(Path(rows[binding]["postimage_file"]).read_bytes())=="9836536fc829079bfbc8272db73da383d1335243dd6ef0e38ac5de09e49abd73"
assert sha(Path(rows[test]["postimage_file"]).read_bytes())=="a2c999878c4164b25f42ab92b39896e29e99275f7115924794db7404a9c5c4ab"
text=Path(rows[binding]["postimage_file"]).read_text()
old='''    registry = load_registry_bundle_content(store, registry_bundle_ref)
    binding_payload = _load_binding_payload(store, snapshot)
    preparation = _prepare_input_binding_values(
        store,
        snapshot=snapshot,
        slot_registry=registry.slot_registry,
        binding_payload=binding_payload,
        rules=rules,
    )
    if registered_sql_admission_ref is not None:
        from polisyos.foundry.execute._internal.snapshots import _flatten_state

        replayed, _ = _recompute_registered_sql_state(
            store,
            snapshot=snapshot,
            payload=binding_payload,
            slot_registry=registry.slot_registry,
            rules=list(preparation.effective_rules),
        )
        expected = BytesIO()
        np.savez(expected, **dict(_flatten_state(preparation.materialized_state)))
        if expected.getvalue() != replayed:
            raise ValueError("registered_sql_binding_preparation_replay_mismatch")
    return preparation
'''
new='''    registry = load_registry_bundle_content(store, registry_bundle_ref)
    binding_payload = _load_binding_payload(store, snapshot)
    replayed: bytes | None = None
    if registered_sql_admission_ref is not None:
        effective_rules = _prepare_rules(
            rules=rules, slot_registry=registry.slot_registry, payload=binding_payload
        )
        replayed, _ = _recompute_registered_sql_state(
            store,
            snapshot=snapshot,
            payload=binding_payload,
            slot_registry=registry.slot_registry,
            rules=effective_rules,
        )
    preparation = _prepare_input_binding_values(
        store,
        snapshot=snapshot,
        slot_registry=registry.slot_registry,
        binding_payload=binding_payload,
        rules=rules,
    )
    if registered_sql_admission_ref is not None:
        from polisyos.foundry.execute._internal.snapshots import _flatten_state

        expected = BytesIO()
        np.savez(expected, **dict(_flatten_state(preparation.materialized_state)))
        if replayed is None or expected.getvalue() != replayed:
            raise ValueError("registered_sql_binding_preparation_replay_mismatch")
    return preparation
'''
assert text.count(old)==1
code=text.replace(old,new)
test_text=Path(rows[test]["postimage_file"]).read_text()
old='''    with pytest.raises(ValueError, match="registered_sql_binding_source_read_not_established"):
        _without_writes(
            store,
            monkeypatch,
            lambda: prepare_input_bindings(
                store,
                data_snapshot_ref=materialization.snapshot_ref,
                registry_bundle_ref=registry_ref,
                rules=missing,
                registered_sql_admission_ref=source_ref,
            ),
        )
'''
new='''    from polisyos.foundry.data_plane import bindings as binding_module

    def shared_numerical_owner_must_not_run(*args: object, **kwargs: object) -> NoReturn:
        del args, kwargs
        pytest.fail("shared numerical owner ran before SQL source-path refusal")

    with monkeypatch.context() as patch:
        patch.setattr(binding_module, "_prepare_input_binding_values", shared_numerical_owner_must_not_run)
        with pytest.raises(ValueError, match="registered_sql_binding_source_read_not_established"):
            _without_writes(
                store,
                patch,
                lambda: prepare_input_bindings(
                    store,
                    data_snapshot_ref=materialization.snapshot_ref,
                    registry_bundle_ref=registry_ref,
                    rules=missing,
                    registered_sql_admission_ref=source_ref,
                ),
            )
'''
assert test_text.count(old)==1
test_code=test_text.replace(old,new)
def no_imports(tree):
    class Drop(ast.NodeTransformer):
        def visit_Import(self,node): return None
        def visit_ImportFrom(self,node): return None
    return ast.dump(Drop().visit(copy.deepcopy(tree)),include_attributes=False)
def imports(tree):
    return collections.Counter(ast.dump(node,include_attributes=False)
        for node in ast.walk(tree) if isinstance(node,(ast.Import,ast.ImportFrom)))
proofs=[]
for name,value in ((binding,code),(test,test_code)):
    initial=value.encode()
    ast_before=ast.parse(initial,filename=name)
    target=repo/name
    sort=[str(product/".venv/bin/python"),"-m","ruff","check","--no-cache","--fix","--select","I",
          "--stdin-filename",str(target),"-"]
    run=subprocess.run(sort,cwd=product,input=initial,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    assert run.returncode==0,(name,run.stderr.decode())
    ast_sorted=ast.parse(run.stdout,filename=name)
    assert no_imports(ast_before)==no_imports(ast_sorted) and imports(ast_before)==imports(ast_sorted)
    fmt=[str(product/".venv/bin/python"),"-m","ruff","format","--no-cache","--stdin-filename",str(target),"-"]
    result=subprocess.run(fmt,cwd=product,input=run.stdout,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    assert result.returncode==0,(name,result.stderr.decode())
    assert ast.dump(ast_sorted,include_attributes=False)==ast.dump(ast.parse(result.stdout),include_attributes=False)
    out=raw/"union-r2-postimages"/name
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_bytes(result.stdout)
    rows[name]["postimage_file"]=str(out)
    rows[name]["post_sha256"]=sha(result.stdout)
    checks=[]
    for phase,args in (("check",["check","--no-cache"]),("format",["format","--check","--no-cache"])):
        cmd=[str(product/".venv/bin/python"),"-m","ruff",*args,"--stdin-filename",str(target),"-"]
        c=subprocess.run(cmd,cwd=product,input=result.stdout,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        checks.append({"phase":phase,"command":cmd,"exit":c.returncode,
                       "stdout":c.stdout.decode(),"stderr":c.stderr.decode()})
        assert c.returncode==0,(name,phase,c.stdout.decode(),c.stderr.decode())
    proofs.append({"path":name,"preformat_sha256":sha(initial),"final_sha256":sha(result.stdout),
                   "sort_command":sort,"sort_exit":run.returncode,"sort_stderr":run.stderr.decode(),
                   "nonimport_ast_identical":True,"import_multiset_identical":True,
                   "format_command":fmt,"format_exit":result.returncode,"format_stderr":result.stderr.decode(),
                   "format_full_ast_identical":True,"checks":checks})
data["supersedes_v3_manifest_sha256"]=sha(old_manifest.read_bytes())
data["ordering_delta"]="SQL selected rule/source replay precedes the shared numerical preparation; missing/default source is refused before it is invoked."
manifest=raw/"v3-8-after-sql-r2-manifest.json"
manifest.write_text(json.dumps(data,indent=2)+"\n")
(raw/"checks/v3-r2-style-proof.json").write_text(json.dumps(proofs,indent=2)+"\n")
print("manifest",sha(manifest.read_bytes()))
for name in (binding,test): print(name,rows[name]["post_sha256"])
