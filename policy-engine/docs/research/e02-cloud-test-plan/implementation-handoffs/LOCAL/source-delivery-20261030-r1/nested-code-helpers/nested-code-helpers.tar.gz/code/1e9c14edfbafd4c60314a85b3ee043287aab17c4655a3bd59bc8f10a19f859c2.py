"""Synthetic loader test package."""
