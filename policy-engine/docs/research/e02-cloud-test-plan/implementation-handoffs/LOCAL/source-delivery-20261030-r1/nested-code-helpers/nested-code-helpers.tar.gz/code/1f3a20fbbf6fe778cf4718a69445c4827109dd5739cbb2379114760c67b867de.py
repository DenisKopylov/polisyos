"""Resolve the reviewed SQL and V3 preparation overlap without product imports."""
from __future__ import annotations

import ast
import gzip
import hashlib
import json
from pathlib import Path

repo = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
raw = repo / "LOCAL/raw/e02-execution-20261027/repairs/SQL-owner-chain-r3-intake-20261028-r1"
sql = repo / "LOCAL/raw/e02-execution-20261027/repairs/SQL-owner-chain-r3"
v3 = repo / "LOCAL/raw/e02-execution-20261027/repairs/V3-basis-history-r1/owner-preparation-r1"
rel = Path("policy-engine/src/polisyos/foundry/data_plane/bindings.py")
sha = lambda data: hashlib.sha256(data).hexdigest()
for path, digest in (
    (sql / "preimages" / rel, "f8cf224d4adeb718240e10508f680aeed5d0f1da4f95de9b03e1516848af1980"),
    (sql / "postimages" / rel, "826594ab2d3bae6c98f9c2742c9eb9812aca9c0d3434fd5a8cfc8473efac65d3"),
    (v3 / "postimages" / rel, "4a8bd100862ec9265d94fc6c848d87609a1ac4cdd0259bcfe95c4dd96bf973c7"),
):
    assert sha(path.read_bytes()) == digest, path
merge = raw / "checks/bindings-merge.candidate"
text = merge.read_text() if merge.is_file() else gzip.decompress(
    Path(str(merge) + ".gz").read_bytes()
).decode()
head = "<<<<<<< "
middle = "=======\n"
tail = ">>>>>>> "
assert text.count(head) == text.count(middle) == text.count(tail) == 2
start = text.index(head)
split = text.index(middle, start)
end = text.index("\n", text.index(tail, split)) + 1
sql_functions = text[text.index("\n", start) + 1:split]
v3_functions = text[split + len(middle):text.index(tail, split)]
text = text[:start] + sql_functions + "\n\n" + v3_functions + text[end:]
start = text.index(head)
split = text.index(middle, start)
end = text.index("\n", text.index(tail, split)) + 1
v3_call = text[split + len(middle):text.index(tail, split)]
text = text[:start] + v3_call + text[end:]
old = '''def prepare_input_bindings(
    store: CoreJSONArtifactStore,
    *,
    data_snapshot_ref: ArtifactRef,
    registry_bundle_ref: ArtifactRef,
    rules: list[FoundryInputBindingRule] | None = None,
) -> InputBindingsPreparation:'''
new = '''def prepare_input_bindings(
    store: CoreJSONArtifactStore,
    *,
    data_snapshot_ref: ArtifactRef,
    registry_bundle_ref: ArtifactRef,
    rules: list[FoundryInputBindingRule] | None = None,
    registered_sql_admission_ref: ArtifactRef | None = None,
) -> InputBindingsPreparation:'''
assert text.count(old) == 1
text = text.replace(old, new)
old = '''        rules: Explicit rules, or None for the existing inference behavior.

    Returns:'''
new = '''        rules: Explicit rules, or None for the existing inference behavior.
        registered_sql_admission_ref: Optional selected SQL transport, rechecked
            before numerical preparation; it does not itself grant authority.

    Returns:'''
assert text.count(old) == 1
text = text.replace(old, new)
old = '''    snapshot = _load_data_snapshot(store, data_snapshot_ref)
    registry = load_registry_bundle_content(store, registry_bundle_ref)
    binding_payload = _load_binding_payload(store, snapshot)
    return _prepare_input_binding_values(
        store,
        snapshot=snapshot,
        slot_registry=registry.slot_registry,
        binding_payload=binding_payload,
        rules=rules,
    )
'''
new = '''    snapshot = _load_data_snapshot(store, data_snapshot_ref)
    if registered_sql_admission_ref is not None:
        if (
            data_snapshot_ref.manifest_profile_sha256 is None
            or registry_bundle_ref.manifest_profile_sha256 is None
            or registered_sql_admission_ref.manifest_profile_sha256 is None
        ):
            raise ValueError("registered_sql_binding_selected_profile_required")
        _verify_registered_sql_transport(
            store, snapshot=snapshot, snapshot_ref=data_snapshot_ref,
            admission_ref=registered_sql_admission_ref,
        )
    registry = load_registry_bundle_content(store, registry_bundle_ref)
    binding_payload = _load_binding_payload(store, snapshot)
    preparation = _prepare_input_binding_values(
        store,
        snapshot=snapshot,
        slot_registry=registry.slot_registry,
        binding_payload=binding_payload,
        rules=rules,
    )
    if registered_sql_admission_ref is not None:
        from polisyos.foundry.execute._internal.snapshots import _flatten_state

        replayed, _ = _recompute_registered_sql_state(
            store, snapshot=snapshot, payload=binding_payload,
            slot_registry=registry.slot_registry, rules=list(preparation.effective_rules),
        )
        expected = BytesIO()
        np.savez(expected, **dict(_flatten_state(preparation.materialized_state)))
        if expected.getvalue() != replayed:
            raise ValueError("registered_sql_binding_preparation_replay_mismatch")
    return preparation
'''
assert text.count(old) == 1
text = text.replace(old, new)
old = '''    preparation = prepare_input_bindings(
        store,
        data_snapshot_ref=data_snapshot_ref,
        registry_bundle_ref=registry_bundle_ref,
        rules=rules,
    )
'''
new = '''    if registered_sql_admission_ref is not None and not return_selected_profile:
        raise ValueError("registered_sql_binding_selected_profile_required")
    preparation = prepare_input_bindings(
        store,
        data_snapshot_ref=data_snapshot_ref,
        registry_bundle_ref=registry_bundle_ref,
        rules=rules,
        registered_sql_admission_ref=registered_sql_admission_ref,
    )
'''
assert text.count(old) == 1
text = text.replace(old, new)
old = '''    if registered_sql_admission_ref is not None:
        _reconcile_registered_sql_bound_state(
            store,
            snapshot=snapshot,
            payload=binding_payload,
            slot_registry=registry.slot_registry,
'''
new = '''    if registered_sql_admission_ref is not None:
        registry = load_registry_bundle_content(store, registry_bundle_ref)
        binding_payload = _load_binding_payload(store, snapshot)
        _reconcile_registered_sql_bound_state(
            store,
            snapshot=snapshot,
            payload=binding_payload,
            slot_registry=registry.slot_registry,
'''
assert text.count(old) == 1
text = text.replace(old, new)
assert not any(marker in text for marker in ("<<<<<<< ", "=======\n", ">>>>>>> "))
ast.parse(text, filename=str(rel))
out = raw / "union-postimages" / rel
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(text)
assert out.read_text() == text
print("postimage", out)
print("post_sha256", sha(out.read_bytes()))
