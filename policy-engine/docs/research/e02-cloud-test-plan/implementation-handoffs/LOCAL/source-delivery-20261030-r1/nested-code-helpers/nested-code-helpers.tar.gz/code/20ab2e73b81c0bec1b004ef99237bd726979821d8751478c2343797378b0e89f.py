"""Root-only read-adapter removal; no source edits or dependency execution at prep."""
import ast
import hashlib
import importlib
import json
import marshal
import os
from pathlib import Path
import types

import pytest

SOURCE = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos/policy-engine/src/polisyos/core/artifacts/ir_adapter.py')
SOURCE_SHA = '0c3f35eb8bdf378e5694c8bca78dbed8068ad7039da54b753b8dfda22b625292'
NODE = "tests/unit/ir/analytics/test_ncm.py::test_candidate_ncm_is_derived_from_declared_baseline_and_selected_view"
_function = None
_original_code = None
_mutant_code = None
_stream = None


def _code(tree):
    impl = next(n for n in tree.body if isinstance(n, ast.FunctionDef)
                and n.name == "ensure_ir_artifact_store" and len(n.body) > 1)
    full = compile(tree, str(SOURCE), "exec", dont_inherit=True)
    found = [v for v in full.co_consts if isinstance(v, types.CodeType)
             and v.co_name == impl.name and v.co_firstlineno == impl.lineno]
    assert len(found) == 1
    return found[0]


def _sha(code):
    return hashlib.sha256(marshal.dumps(code)).hexdigest()


def _trace(event, **values):
    _stream.write(json.dumps({"event": event, **values}, sort_keys=True) + "\n")
    _stream.flush()


def pytest_collection_modifyitems(session, config, items):
    global _function, _original_code, _mutant_code, _stream
    assert [item.nodeid for item in items] == [NODE]
    source = SOURCE.read_bytes()
    assert hashlib.sha256(source).hexdigest() == SOURCE_SHA
    assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest() == os.environ["E02_IR_REMOVAL_PLUGIN_SHA256"]
    trace = Path(os.environ["E02_IR_REMOVAL_TRACE"])
    assert trace.parent == Path(os.environ["TMPDIR"]).parent
    assert trace.name == "readonly-ir-removal-trace.jsonl"
    assert not any(q.is_symlink() for q in (trace, *trace.parents))
    _stream = os.fdopen(os.open(trace, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600), "w")
    owner = importlib.import_module("polisyos.core.artifacts.ir_adapter")
    assert Path(owner.__file__).resolve() == SOURCE.resolve()
    _function = owner.ensure_ir_artifact_store
    _original_code = _function.__code__
    tree = ast.parse(source, filename=str(SOURCE))
    assert _original_code == _code(tree)
    impl = next(n for n in tree.body if isinstance(n, ast.FunctionDef)
                and n.name == "ensure_ir_artifact_store" and len(n.body) > 1)
    guards = [n for n in ast.walk(impl) if isinstance(n, ast.If)
              and isinstance(n.test, ast.Call)
              and isinstance(n.test.func, ast.Name)
              and n.test.func.id == "matches_artifact_store_protocol"
              and len(n.test.args) == 2
              and isinstance(n.test.args[1], ast.Name)
              and n.test.args[1].id == "VerifiableArtifactReader"]
    assert len(guards) == 1
    guards[0].test = ast.copy_location(ast.Constant(value=False), guards[0].test)
    ast.fix_missing_locations(tree)
    _mutant_code = _code(tree)
    assert _mutant_code != _original_code
    _trace("admission", source_sha256=SOURCE_SHA, original_code_sha256=_sha(_original_code),
           mutant_code_sha256=_sha(_mutant_code), scope="remove narrow reader dispatch only; aliases retain same function")


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_call(item):
    assert item.nodeid == NODE and _function.__code__ == _original_code
    _function.__code__ = _mutant_code
    try:
        _trace("mutation", code_sha256=_sha(_function.__code__))
        yield
    finally:
        _function.__code__ = _original_code
        _trace("restore", code_sha256=_sha(_function.__code__))


def pytest_unconfigure(config):
    if _function is not None:
        _function.__code__ = _original_code
    if _stream is not None:
        _stream.close()
