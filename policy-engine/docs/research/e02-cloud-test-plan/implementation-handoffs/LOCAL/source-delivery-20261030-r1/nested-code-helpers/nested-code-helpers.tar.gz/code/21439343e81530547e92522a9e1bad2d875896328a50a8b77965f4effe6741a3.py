from pathlib import Path
import ast,difflib,hashlib,json
root=Path.cwd();pkg=root/'LOCAL/raw/e02-execution-20261027/repairs/C49-local-r1'
rel=Path('policy-engine/src/polisyos/runtime/quality/recursive_generation_cycle.py')
source=root/'LOCAL/raw/e02-execution-20261027/repairs/C41-r8/postimages'/rel
base=source.read_text();s=base
lines=s.splitlines(keepends=True)
idx=next(i for i,line in enumerate(lines) if line.startswith('from polisyos.runtime.'))
lines.insert(idx,'from polisyos.scientist.orchestration.engine.producer_budget import ProducerBudgetObserver\n')
s=''.join(lines)
needle='''        if _producer_budget_reconciler is not None:
            if not callable(_producer_budget_reconciler):
'''
assert s.count(needle)==1
s=s.replace(needle,'''        # The reusable parent controller must not retain another run's budget owner.
        invocation_joint_controller = self._joint_simulation_controller
        if type(_producer_budget_reconciler) is ProducerBudgetObserver:
            if _producer_budget_reconciler._state is not budget_state:
                raise RecursiveGenerationCycleError("recursive_n5_budget_state_binding_mismatch")
            if type(invocation_joint_controller) is not JointSimulationHorizonController or (
                invocation_joint_controller._settings.authority_scope != "production"
            ):
                raise RecursiveGenerationCycleError("recursive_n5_budget_controller_not_canonical")
            invocation_joint_controller = JointSimulationHorizonController(
                method_registry=invocation_joint_controller._registry,
                policy=invocation_joint_controller.policy,
                producer_budget_observer=_producer_budget_reconciler,
            )

        if _producer_budget_reconciler is not None:
            if not callable(_producer_budget_reconciler):
''',1)
s=s.replace('joint_simulation = self._joint_simulation_controller.run(request)','joint_simulation = invocation_joint_controller.run(request)',1)
s=s.replace('self._joint_simulation_controller.validate_selected_result(\n','invocation_joint_controller.validate_selected_result(\n',1)
ast.parse(s)
pre=pkg/'owner-contexts/C41-r8/preimages'/rel;post=pkg/'owner-contexts/C41-r8/postimages'/rel
pre.parent.mkdir(parents=True,exist_ok=True);post.parent.mkdir(parents=True,exist_ok=True)
pre.write_text(base);post.write_text(s)
patch=''.join(difflib.unified_diff(base.splitlines(True),s.splitlines(True),fromfile='a/'+str(rel),tofile='b/'+str(rel)))
(pkg/'owner-contexts/C41-r8/recursive-budget-context.patch').write_text(patch)
print(json.dumps({'path':str(rel),'preimage_sha256':hashlib.sha256(base.encode()).hexdigest(),'postimage_sha256':hashlib.sha256(s.encode()).hexdigest(),'patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),'runtime':'UNRUN'},indent=2))
