"""Finite source-owner reconciliation for cursor and stream admission.

SourceContract remains the owner of source, schema and role semantics. This
reader is a bounded integrate adapter over its actual replay fixture. It reads
that entire source file independently of connector output; no caller-supplied
expected member list, row count or completeness declaration is an oracle.

The admitted scope is exactly ``finite_source_fixture``. This adapter does not
verify production completeness/currentness, law, rights or institutional facts.
A live provider needs its own independently admitted source-owner reader.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, fields
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

from pydantic import TypeAdapter

from polisyos.core.artifacts import load_core_json_artifact
from polisyos.core.artifacts.manifest import ArtifactRef, SchemaInfo, artifact_ref_identity_key
from polisyos.core.artifacts.write_contract import ArtifactWriteOptions
from polisyos.core.canon import CanonSpec, content_hash, to_canonical_bytes
from polisyos.core.contracts.fabric import EvidenceBundle, EvidenceBundleRef
from polisyos.core.contracts.provenance import ProvenanceCoreGraph, RelationType
from polisyos.fabric.connectors.contracts.source_contract import (
    SourceContract,
    SourceProgressContract,
)
from polisyos.fabric.connectors.types import FetchError
from polisyos.ir.connectors import DataVersion, FetchRequest, FetchResult, VersionStrategy

if TYPE_CHECKING:
    from polisyos.core.artifacts.protocol import ArtifactStore
    from polisyos.core.contracts.cursor import CursorState

_WITNESS_KIND = "fabric.source_progress_witness"
_WITNESS_SCHEMA = "fabric.FiniteSourceProgressWitness"
_MAX_FINITE_FIXTURE_BYTES = 8 * 1024 * 1024


class SourceProgressAdmissionError(FetchError):
    """Refuse a source result that differs from its independent finite owner."""


def _json_object(pairs: list[tuple[str, object]]) -> dict[str, object]:
    result: dict[str, object] = {}
    for name, value in pairs:
        if name in result:
            raise ValueError("duplicate key in source-owner fixture")
        result[name] = value
    return result


def _bytes(value: object) -> bytes:
    return to_canonical_bytes(value, spec=CanonSpec(forbid_floats=False))


def _rows(payload: object) -> list[dict[str, Any]]:
    if not isinstance(payload, list) or any(not isinstance(row, dict) for row in payload):
        from polisyos.fabric.data_plane.tabular import payload_to_dataframe

        frame = payload_to_dataframe(payload)
        if frame is None:
            raise ValueError("source payload is not tabular")
        payload = frame.to_dict(orient="records")
    if not isinstance(payload, list) or any(not isinstance(row, dict) for row in payload):
        raise ValueError("source payload does not contain object rows")
    return [dict(row) for row in payload]


def _row_set(rows: list[dict[str, Any]]) -> list[bytes]:
    return sorted(_bytes(row) for row in rows)


def _key(row: dict[str, Any], fields: tuple[str, ...]) -> str:
    values = []
    for name in fields:
        value = row.get(name)
        if type(value) not in {str, int} or value == "":
            raise ValueError("source event/version key is missing or ambiguous")
        values.append(value)
    return _bytes(values).decode("utf-8")


def snapshot_fetch_request(request: FetchRequest) -> dict[str, Any]:
    """Snapshot every owner-defined constructor field without filesystem probes."""
    names = {field.name for field in fields(FetchRequest) if field.init}
    return cast(
        "dict[str, Any]",
        TypeAdapter(FetchRequest).dump_python(request, mode="json", include=names),
    )


def _restore_fetch_request(payload: object) -> FetchRequest:
    if not isinstance(payload, dict) or set(payload) != {
        field.name for field in fields(FetchRequest) if field.init
    }:
        raise ValueError("persisted actual request is incomplete or has unknown fields")
    return TypeAdapter(FetchRequest).validate_python(payload)


@dataclass(frozen=True)
class _FiniteSnapshot:
    version: DataVersion
    rows: tuple[dict[str, Any], ...]


@dataclass(frozen=True)
class ReconciledSourceFrame:
    """Frozen whole-fixture basis, independently read before connector fetch."""

    reader: FiniteSourceProgressReader
    fixture_hash: str
    fixture_payload: dict[str, Any]
    fixture_bytes: bytes
    snapshots: tuple[_FiniteSnapshot, ...]
    current_index: int
    tenant_id: str | None

    @property
    def extension(self) -> SourceProgressContract:
        """Return the separately versioned, source-bound role contract."""
        return self.reader.extension

    @property
    def current(self) -> _FiniteSnapshot:
        """Return the finite owner's actual current snapshot."""
        return self.snapshots[self.current_index]

    def snapshot_for(self, value: str) -> _FiniteSnapshot:
        """Resolve one unambiguous version from the frozen complete owner file."""
        matches = [snapshot for snapshot in self.snapshots if snapshot.version.value == value]
        if len(matches) != 1:
            raise ValueError("source version is absent or ambiguous in the owner history")
        return matches[0]

    def assert_current(self) -> None:
        """Refuse source movement while this invocation is using its frozen frame."""
        if content_hash(self.reader.read_fixture_bytes()) != self.fixture_hash:
            raise ValueError("source-owner fixture changed during ingestion")

    def reconcile_fetch(self, request: FetchRequest, result: FetchResult[Any]) -> FetchResult[Any]:
        """Reconcile every actual source row and return its full materialized state.

        Incremental transport is append-only event/version identity. Unchanged
        sources may return an empty delta; the verified whole source state is
        retained for a fresh consumer of this invocation's published result.
        """
        try:
            self.assert_current()
            if (
                request.dataset_id != self.extension.dataset_id
                or request.filters
                or request.date_start is not None
                or request.date_end is not None
                or request.as_of is not None
                or request.page_token is not None
            ):
                raise ValueError("finite owner does not admit a filtered/paginated source view")
            current = self.current
            if (
                result.version.strategy != current.version.strategy
                or result.version.value != current.version.value
                or (
                    current.version.strategy is VersionStrategy.TIMESTAMP
                    and (
                        result.version.timestamp != current.version.timestamp
                        or result.source_updated_at != current.version.timestamp
                    )
                )
                or result.schema_id != self.extension.schema_id
                or result.schema_version != self.extension.schema_version_bound
                or result.has_more
                or result.next_page_token is not None
                or result.completeness != 1.0
            ):
                raise ValueError("source result boundary/schema differs from the finite owner")
            expected_rows = list(current.rows)
            if request.incremental_since is not None:
                previous = self.snapshot_for(request.incremental_since.value)
                if (
                    request.incremental_since.strategy != previous.version.strategy
                    or request.incremental_since.timestamp != previous.version.timestamp
                    or self.snapshots.index(previous) > self.current_index
                ):
                    raise ValueError("request predecessor differs from the owner history")
                previous_keys = {
                    _key(row, self.extension.event_fields + self.extension.version_fields)
                    for row in previous.rows
                }
                expected_rows = [
                    row
                    for row in current.rows
                    if _key(row, self.extension.event_fields + self.extension.version_fields)
                    not in previous_keys
                ]
            actual_rows = _rows(result.data)
            if result.row_count != len(actual_rows) or _row_set(actual_rows) != _row_set(
                expected_rows
            ):
                raise ValueError("actual source rows differ from the complete owner view")
            materialized_rows = [dict(row) for row in current.rows]
            return result.model_copy(
                update={
                    "data": materialized_rows,
                    "row_count": len(materialized_rows),
                    "version": current.version.model_copy(
                        update={"content_hash": "sha256:" + content_hash(_bytes(materialized_rows))}
                    ),
                    "not_modified": result.not_modified,
                }
            )
        except (OSError, TypeError, ValueError) as exc:
            raise SourceProgressAdmissionError(
                "source_progress_not_reconciled",
                connector_id=self.extension.connector_id,
                dataset_id=self.extension.dataset_id,
            ) from exc

    def verify_materialization(
        self, result: FetchResult[Any], *, version: str | None = None
    ) -> None:
        """Verify all rows of a persisted full source contribution."""
        expected = self.snapshot_for(version) if version is not None else self.current
        actual = _rows(result.data)
        if (
            result.version.strategy != expected.version.strategy
            or result.version.value != expected.version.value
            or result.version.timestamp != expected.version.timestamp
            or result.schema_id != self.extension.schema_id
            or result.schema_version != self.extension.schema_version_bound
            or result.row_count != len(actual)
            or _row_set(actual) != _row_set(list(expected.rows))
        ):
            raise ValueError("persisted source contribution differs from the owner view")

    def _validate_key_schema(self, row: dict[str, Any]) -> None:
        from polisyos.fabric.data_plane.schema_rows import field_value_violation

        schema = self.extension.bind(self.reader.source_contract)
        roles = self.extension.event_fields + self.extension.version_fields
        if any(
            field_value_violation(row.get(field.name), field) is not None
            for field in schema.fields
            if field.name in roles
        ):
            raise ValueError("actual source event/version violates its owned schema")

    def admit_stream_rows(self, rows: list[object]) -> None:
        """Resolve event/version membership against the complete actual owner view.

        This admits identity only. Non-key payload remains candidate data;
        equal source event/version keys are redeliveries even when transport
        annotations differ. No payload-truth authority is inferred here.
        """
        self.assert_current()
        fields = self.extension.event_fields + self.extension.version_fields
        owner_keys = {_key(row, fields) for row in self.current.rows}
        for row in rows:
            if not isinstance(row, dict):
                raise ValueError("stream source identity is not an object")
            self._validate_key_schema(row)
            if _key(row, fields) not in owner_keys:
                raise ValueError("stream event/version is absent from the source owner")

    def _load_retained_witness(
        self, store: ArtifactStore, witness_ref: ArtifactRef
    ) -> ReconciledSourceFrame | None:
        try:
            if (
                witness_ref.kind != _WITNESS_KIND
                or witness_ref.media_type != "application/json"
                or witness_ref.manifest_profile_sha256 is None
            ):
                return None
            witness = load_core_json_artifact(store, witness_ref)
            if not isinstance(witness, dict) or (
                witness.get("schema_version") != "fabric.finite_source_progress_witness.v1"
                or witness.get("tenant_id") != self.tenant_id
                or witness.get("extension") != self.extension.model_dump(mode="json")
                or witness.get("extension_content_hash") != self.extension.content_hash
                or witness.get("predicate_class") != "recomputed"
                or witness.get("admission_scope") != "finite_source_fixture"
            ):
                return None
            raw = witness.get("source_history_json")
            if not isinstance(raw, str) or content_hash(raw.encode()) != witness.get(
                "fixture_sha256"
            ):
                return None
            old = self.reader._parse_history(raw.encode("utf-8"), tenant_id=self.tenant_id)
            snapshots = old.fixture_payload["snapshots"]
            if self.fixture_payload["snapshots"][: len(snapshots)] != snapshots:
                return None
            return old
        except (LookupError, OSError, TypeError, ValueError):
            return None

    def retained_witness_is_current(self, store: ArtifactStore, witness_ref: ArtifactRef) -> bool:
        """Reconcile retained source bytes through the complete actual owner parser."""
        return self._load_retained_witness(store, witness_ref) is not None

    def witness(self, store: ArtifactStore) -> ArtifactRef:
        """Persist the exact bounded source bytes and recomputed admission scope."""
        self.assert_current()
        payload = {
            "schema_version": "fabric.finite_source_progress_witness.v1",
            "predicate_class": "recomputed",
            "admission_scope": "finite_source_fixture",
            "unresolved_by_construction": [
                "live_provider_completeness_currentness",
                "external_source_rights",
                "production_event_identity_semantics",
            ],
            "tenant_id": self.tenant_id,
            "extension": self.extension.model_dump(mode="json"),
            "extension_content_hash": self.extension.content_hash,
            "fixture_sha256": self.fixture_hash,
            "source_history_json": self.fixture_bytes.decode("utf-8"),
        }
        ref = store.put_json(
            payload,
            ArtifactWriteOptions(
                kind=_WITNESS_KIND,
                media_type="application/json",
                schema=SchemaInfo(name=_WITNESS_SCHEMA, version="1.0"),
            ),
            canon_spec=CanonSpec(forbid_floats=False),
            return_selected_profile=True,
        )
        if (
            ref.kind != _WITNESS_KIND
            or ref.media_type != "application/json"
            or ref.manifest_profile_sha256 is None
            or not store.verify(ref).ok
            or load_core_json_artifact(store, ref) != payload
        ):
            raise ValueError("source-progress witness was not persisted as its exact selected view")
        return ref

    def admit_cursor(self, cursor: CursorState, store: ArtifactStore) -> DataVersion | None:
        """Resolve source witness, payload and provenance before issuing a hint."""
        try:
            proof = cursor.metadata.get("source_progress")
            if not isinstance(proof, dict):
                return None
            witness_ref = ArtifactRef.model_validate(proof["witness_ref"])
            payload_ref = ArtifactRef.model_validate(proof["payload_ref"])
            evidence_ref = EvidenceBundleRef.model_validate(proof["evidence_ref"])
            if (
                witness_ref.kind != _WITNESS_KIND
                or witness_ref.media_type != "application/json"
                or witness_ref.manifest_profile_sha256 is None
                or payload_ref.manifest_profile_sha256 is None
                or evidence_ref.manifest_profile_sha256 is None
                or cursor.connector_id != self.extension.connector_id
                or cursor.dataset_id != self.extension.dataset_id
                or str(evidence_ref.artifact_id) != cursor.evidence_bundle_ref
                or cursor.ingestion_run_id != cursor.evidence_bundle_ref
            ):
                return None
            old = self._load_retained_witness(store, witness_ref)
            if old is None or old.current.version.value != cursor.watermark_value:
                return None
            actual_request = _restore_fetch_request(proof.get("actual_request"))
            if (
                actual_request.dataset_id != cursor.dataset_id
                or actual_request.cache_key != proof.get("actual_request_key")
            ):
                return None
            bundle = EvidenceBundle.model_validate(load_core_json_artifact(store, evidence_ref))
            if (
                not any(
                    artifact_ref_identity_key(ref) == artifact_ref_identity_key(payload_ref)
                    for ref in bundle.sources
                )
                or bundle.provenance_ref is None
            ):
                return None
            from polisyos.core.artifacts.ids import ArtifactID
            from polisyos.fabric.connectors.cache._store_serialization import ResultSerializer

            persisted = ResultSerializer.deserialize(store.get_bytes(payload_ref))
            from polisyos.fabric.ingestion.ingestion import _cache_payload_ref_matches_result

            if not _cache_payload_ref_matches_result(store, payload_ref, persisted):
                return None
            self.verify_materialization(persisted, version=cursor.watermark_value)
            graph = ProvenanceCoreGraph.from_dict(
                load_core_json_artifact(
                    store, ArtifactID.model_validate(bundle.provenance_ref.artifact_id)
                )
            )
            graph_ref = bundle.provenance_ref
            entity_id = f"dataset.{cursor.connector_id}.{cursor.dataset_id}"
            entity = graph.entities.get(entity_id)
            if (
                graph.graph_id != graph_ref.graph_id
                or graph.compute_stable_id() != graph_ref.stable_id
                or entity is None
                or entity.attributes.get("fetch_status") != "complete"
                or entity.attributes.get("cache_key") != proof.get("actual_request_key")
                or entity.attributes.get("data_artifact_id") != payload_ref.artifact_id.hex
                or entity.attributes.get("version_value") != cursor.watermark_value
                or not any(
                    edge.source_id == entity_id
                    and edge.target_id == "connector_ingestion_run"
                    and edge.relation is RelationType.WAS_GENERATED_BY
                    for edge in graph.edges
                )
            ):
                return None
            version = self.snapshot_for(cursor.watermark_value).version
            if version.strategy.value != cursor.watermark_type.value:
                return None
            self.assert_current()
            return version
        except (KeyError, LookupError, OSError, TypeError, ValueError):
            return None


@dataclass(frozen=True)
class FiniteSourceProgressReader:
    """Host-configured read-only adapter over one actual source-owned fixture.

    The connector cannot select an expected row set or install this dependency.
    The owner-bound fixture itself is the complete finite source denominator.
    No production source is admitted by this bounded adapter.
    """

    source_root: Path
    source_contract: SourceContract
    extension: SourceProgressContract

    def __post_init__(self) -> None:
        # Revalidate actual model values; a model_construct() or subclass
        # self-attestation must not substitute for the source owner contract.
        object.__setattr__(
            self,
            "source_contract",
            SourceContract.model_validate(self.source_contract.model_dump(mode="python")),
        )
        object.__setattr__(
            self,
            "extension",
            SourceProgressContract.model_validate(self.extension.model_dump(mode="python")),
        )

    @property
    def fixture_path(self) -> Path:
        """Resolve only the exact source-owner replay fixture within its root."""
        self.extension.bind(self.source_contract)
        raw = self.source_contract.replay.fixture_ref
        if not isinstance(raw, str):
            raise ValueError("source owner has no finite fixture")
        relative = Path(raw)
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError("finite source fixture must be relative to its configured root")
        root = self.source_root.resolve()
        result = (root / relative).resolve(strict=True)
        if not result.is_relative_to(root) or not result.is_file():
            raise ValueError("source fixture escapes its configured root")
        return result

    def read_fixture_bytes(self) -> bytes:
        """Bound actual owner bytes before JSON parsing or history materialization."""
        with self.fixture_path.open("rb") as stream:
            raw = stream.read(_MAX_FINITE_FIXTURE_BYTES + 1)
        if len(raw) > _MAX_FINITE_FIXTURE_BYTES:
            raise ValueError("finite source fixture exceeds its 8 MiB admission profile")
        return raw

    def freeze(self, *, tenant_id: str | None) -> ReconciledSourceFrame:
        """Independently read and enumerate the actual complete finite source."""
        return self._parse_history(self.read_fixture_bytes(), tenant_id=tenant_id)

    def _parse_history(self, raw: bytes, *, tenant_id: str | None) -> ReconciledSourceFrame:
        if len(raw) > _MAX_FINITE_FIXTURE_BYTES:
            raise ValueError("finite source fixture exceeds its admission profile")
        schema = self.extension.bind(self.source_contract)
        from polisyos.fabric.data_plane.schema_rows import field_value_violation

        payload = json.loads(raw, object_pairs_hook=_json_object)
        if not isinstance(payload, dict) or set(payload) != {
            "schema_version",
            "connector_id",
            "dataset_id",
            "current_version",
            "snapshots",
        }:
            raise ValueError("invalid finite source-owner history")
        if (
            payload["schema_version"] != "fabric.finite_source_history.v1"
            or payload["connector_id"] != self.extension.connector_id
            or payload["dataset_id"] != self.extension.dataset_id
            or not isinstance(payload["snapshots"], list)
            or not payload["snapshots"]
        ):
            raise ValueError("finite source owner identity differs")
        snapshots: list[_FiniteSnapshot] = []
        version_values: set[str] = set()
        prior_rows: dict[str, bytes] = {}
        for snapshot in payload["snapshots"]:
            if not isinstance(snapshot, dict) or set(snapshot) != {"version", "rows"}:
                raise ValueError("invalid source-owner snapshot")
            raw_version = snapshot["version"]
            raw_time = raw_version.get("timestamp") if isinstance(raw_version, dict) else None
            parsed_time = datetime.fromisoformat(raw_time) if isinstance(raw_time, str) else None
            if parsed_time is None or parsed_time.utcoffset() is None:
                raise ValueError("source-owner version timestamp must declare a timezone")
            version = DataVersion.model_validate(raw_version)
            if version.strategy.value != self.extension.version_strategy:
                raise ValueError(
                    "source boundary strategy differs from its versioned owner contract"
                )
            if not version.value.strip():
                raise ValueError("source boundary value is empty")
            if version.strategy is VersionStrategy.REVISION:
                if not version.value.isascii() or not version.value.isdecimal():
                    raise ValueError("source revision must be an unsigned decimal value")
                if snapshots and int(version.value) <= int(snapshots[-1].version.value):
                    raise ValueError("source revisions do not advance")
            if version.strategy is VersionStrategy.TIMESTAMP:
                value_time = datetime.fromisoformat(version.value)
                if value_time.utcoffset() is None or value_time != version.timestamp:
                    raise ValueError("source timestamp value and declared epoch differ")
                if snapshots and version.timestamp <= snapshots[-1].version.timestamp:
                    raise ValueError("source timestamp boundaries do not advance")
            if version.value in version_values:
                raise ValueError("ambiguous source boundary")
            version_values.add(version.value)
            records = _rows(snapshot["rows"])
            actual_rows: dict[str, bytes] = {}
            for row in records:
                roles = self.extension.event_fields + self.extension.version_fields
                if any(
                    field_value_violation(row.get(field.name), field) is not None
                    for field in schema.fields
                    if field.name in roles
                ):
                    raise ValueError("source owner event/version violates its concrete schema")
                key = _key(row, roles)
                if key in actual_rows:
                    raise ValueError("ambiguous source event/version key")
                actual_rows[key] = _bytes(row)
            if any(actual_rows.get(key) != value for key, value in prior_rows.items()):
                raise ValueError("finite owner is not append-only event/version history")
            prior_rows = actual_rows
            snapshots.append(_FiniteSnapshot(version, tuple(records)))
        selected = [
            index
            for index, snapshot in enumerate(snapshots)
            if snapshot.version.value == payload["current_version"]
        ]
        if selected != [len(snapshots) - 1]:
            raise ValueError("current source boundary must be the final actual owner snapshot")
        return ReconciledSourceFrame(
            reader=self,
            fixture_hash=content_hash(raw),
            fixture_payload=payload,
            fixture_bytes=raw,
            snapshots=tuple(snapshots),
            current_index=selected[0],
            tenant_id=tenant_id,
        )


def resolve_source_progress_frame(
    readers: tuple[FiniteSourceProgressReader, ...],
    *,
    connector_id: str,
    dataset_id: str,
    tenant_id: str | None,
) -> ReconciledSourceFrame | None:
    """Resolve a unique host-selected reader without a second source registry."""
    selected = [
        reader
        for reader in readers
        if type(reader) is FiniteSourceProgressReader
        and reader.extension.connector_id == connector_id
        and reader.extension.dataset_id == dataset_id
    ]
    if not selected:
        return None
    if len(selected) != 1:
        raise ValueError("source progress reader is ambiguous")
    return selected[0].freeze(tenant_id=tenant_id)
