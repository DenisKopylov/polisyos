"""One owner-replayed same-input identity for the SQL-backed ex-ante Debug path.

This private slice establishes input identity only. It is not a source-currentness,
scientific, legal, or publication authorization, and is not a generic method owner.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal, NoReturn, cast

from polisyos.core.artifacts import ArtifactRef, InputRef, artifact_ref_identity_key
from polisyos.core.security.access_scope import AccessScope
from polisyos.core.security.tenant_context import get_current_access_scope_or_none
from polisyos.runtime.quality.authority import (
    _VERIFIED_CLOSURE_KEY,
    AuthorityEnvelopeError,
    ClosureCasIdentity,
    ClosureMemberContract,
    ClosureOwnerValueIdentity,
    SameInputClosure,
    SameInputClosureContract,
    VerifiedSameInputClosure,
    _same_input_closure_projection_sha256,
)

if TYPE_CHECKING:
    from polisyos.core.artifacts import ArtifactManifest
    from polisyos.runtime.http.services.control import ControlPlaneService
    from polisyos.scientist.nodes.builtins.decide.policy_runtime_method_metrics import (
        _ProjectionReadBudget,
    )

EXECUTION_INPUT_IDENTITY_PURPOSE: Literal["execution_input_identity_only"] = (
    "execution_input_identity_only"
)
_OWNER_ID = "polisyos.runtime.quality.owned_execution_identity"
_LAW = "restricted-exante-sql-source@1.0"


@dataclass(frozen=True, slots=True)
class _ReplayedIdentity:
    """One in-process, freshly rebuilt owner result; never persisted as a grant."""

    closure: SameInputClosure
    contract: SameInputClosureContract


def _fail(reason: str) -> NoReturn:
    raise AuthorityEnvelopeError("same_input_closure_" + reason)


def _scope_identity(scope: AccessScope) -> tuple[object, ...]:
    """Snapshot all access-scope fields that can distinguish the live principal."""
    return (
        scope.tenant_id,
        scope.cell_id,
        scope.principal_type,
        scope.user_sub,
        tuple(sorted(str(role.value) for role in scope.roles)),
        str(scope.max_pii_tier.value),
        scope.mfa_verified,
        scope.spiffe_id,
        scope.delegation_jti,
        scope.jwt_jti,
    )


def _manifest_member(
    *, name: str, role: str, ref: ArtifactRef, manifest: ArtifactManifest
) -> ClosureCasIdentity:
    """Retain exact observed metadata; absence is not an invented producer."""
    schema = manifest.artifact_schema
    producer = manifest.producer
    return ClosureCasIdentity(
        name=name,
        role=role,
        artifact_ref=ref,
        schema_name=None if schema is None else schema.name,
        schema_version=None if schema is None else schema.version,
        producer_component=None if producer is None else str(producer.component),
        producer_version=None if producer is None else producer.version,
    )


def _edge_text(edge: InputRef) -> str:
    """Preserve this owner's ordered role-qualified selected edge without guessing."""
    return json.dumps(edge.model_dump(mode="json"), sort_keys=True, separators=(",", ":"))


class _RestrictedExecutionIdentityOwner:
    """Concrete Runtime replayer; caller callbacks cannot replace this owner.

    A token holds the installed control service and the lookup key, but no claimed
    member list. Every use re-enters current request scope, completed owner
    selection, restricted dispatch verifier, bounded source and selected bytes.
    """

    __slots__ = (
        "_aggregate_read_budget", "_control", "_run_id", "_scope", "_sealed", "_simulation_key"
    )

    def __init__(
        self,
        *,
        control: ControlPlaneService,
        run_id: str,
        simulation_ref: ArtifactRef,
        aggregate_read_budget: _ProjectionReadBudget,
    ) -> None:
        from polisyos.runtime.http.services.control import ControlPlaneService
        from polisyos.scientist.nodes.builtins.decide.policy_runtime_method_metrics import (
            _ProjectionReadBudget,
        )

        scope = get_current_access_scope_or_none()
        if (
            type(control) is not ControlPlaneService
            or type(aggregate_read_budget) is not _ProjectionReadBudget
            or aggregate_read_budget.parent is not None
            or type(scope) is not AccessScope
            or not scope.tenant_id
            or not scope.cell_id
            or not (scope.user_sub or scope.spiffe_id)
            or type(run_id) is not str
            or not run_id
            or not isinstance(simulation_ref, ArtifactRef)
            or simulation_ref.manifest_profile_sha256 is None
        ):
            _fail("debug_owner_or_access_scope_not_established")
        object.__setattr__(self, "_aggregate_read_budget", aggregate_read_budget)
        object.__setattr__(self, "_control", control)
        object.__setattr__(self, "_run_id", run_id)
        object.__setattr__(self, "_scope", _scope_identity(scope))
        object.__setattr__(self, "_simulation_key", artifact_ref_identity_key(simulation_ref))
        object.__setattr__(self, "_sealed", True)

    def __setattr__(self, name: str, value: object) -> None:
        if getattr(self, "_sealed", False):
            raise AttributeError("restricted_execution_identity_owner_is_immutable")
        object.__setattr__(self, name, value)

    def __delattr__(self, name: str) -> None:
        raise AttributeError("restricted_execution_identity_owner_is_immutable")

    def replay(self) -> _ReplayedIdentity:
        """Re-enter the actual completed source and build its complete owned basis."""
        from polisyos.core.contracts.foundry import (
            MethodExecutionBundle,
            ProgramGraph,
            SimulationResultRef,
            StateSnapshot,
        )
        from polisyos.core.contracts.runtime import GraphMethodExecutionSelection
        from polisyos.foundry.execute.api import (
            _execution_input_basis_sources,
            admit_execution_source_bounded,
        )
        from polisyos.runtime.http.resilience import _require_runtime_ambient_ownership
        from polisyos.runtime.http.services.debug_registered_sql import (
            _is_supported_restricted_graph,
            _reconcile_selected_sql_inputs,
        )
        from polisyos.scientist.nodes.builtins.decide.policy_runtime_method_metrics import (
            MAX_METHOD_METRIC_SOURCE_BYTES,
            _BoundedExecutionSourceReader,
            _ProjectionReadBudget,
            _read_bounded_method_metric_artifact,
            _selected_ref,
            _VerifiedRestrictedExAnteCall,
        )

        control = self._control
        scope = get_current_access_scope_or_none()
        if type(scope) is not AccessScope or _scope_identity(scope) != self._scope:
            _fail("debug_current_access_scope_changed")
        store = control._artifact_store
        _require_runtime_ambient_ownership(store)
        selection = control.get_method_execution_selection(
            run_id=self._run_id, tenant_id=scope.tenant_id, cell_id=scope.cell_id,
            aggregate_read_budget=self._aggregate_read_budget,
        )
        if (
            type(selection) is not GraphMethodExecutionSelection
            or selection.simulation_result_ref is None
            or artifact_ref_identity_key(selection.simulation_result_ref) != self._simulation_key
            or selection.source_candidate_ref is None
            or selection.method_execution_bundle_ref is None
        ):
            _fail("debug_completed_owner_selection_not_established")

        calls: list[Any] = []
        score = control.read_current_completed_ex_ante_candidate_score(
            run_id=self._run_id,
            tenant_id=scope.tenant_id,
            cell_id=scope.cell_id,
            require_restricted_exante_call_witness=True,
            restricted_exante_call_collector=calls,
            aggregate_read_budget=self._aggregate_read_budget,
        )
        if (
            score.status != "selected"
            or len(calls) != 1
            or type(calls[0]) is not _VerifiedRestrictedExAnteCall
        ):
            _fail("debug_actual_restricted_invocation_not_established")
        call = calls[0]
        budget = _ProjectionReadBudget(parent=self._aggregate_read_budget)
        reader = _BoundedExecutionSourceReader(cast("Any", store), budget)
        sim_ref = SimulationResultRef.model_validate(
            selection.simulation_result_ref.model_dump(mode="python")
        )
        source_bytes_before = budget.observed_execution_source_bytes
        admitted = admit_execution_source_bounded(store, sim_ref, reader=reader)
        basis = admitted.basis
        if (
            admitted.mode != "single_step_basis"
            or basis is None
            or admitted.basis_ref is None
            or admitted.basis_manifest is None
            or admitted.basis_inventory is None
            or basis.registered_sql_admission_ref is None
            or basis.candidate_ref != selection.source_candidate_ref
            or type(admitted.source_read_bytes) is not int
            or admitted.source_read_bytes
            != budget.observed_execution_source_bytes - source_bytes_before
        ):
            _fail("debug_source_basis_not_established")
        _, graph, _, _ = reader.read_typed_model(ProgramGraph, basis.program_graph_ref)
        _, bundle, _, _ = reader.read_typed_model(
            MethodExecutionBundle, selection.method_execution_bundle_ref
        )
        if (
            len(bundle.occurrences) != 1
            or bundle.occurrences[0] != call.occurrence
            or not _is_supported_restricted_graph(graph, method_node_id=call.occurrence.node_id)
            or call.occurrence.dispatch is None
            or call.occurrence.dispatch.input_state_source_ref is None
            or artifact_ref_identity_key(call.occurrence.dispatch.input_state_source_ref)
            != artifact_ref_identity_key(basis.base_state_snapshot_ref)
        ):
            _fail("debug_restricted_graph_or_source_state_mismatch")
        _reconcile_selected_sql_inputs(store, basis=basis, call=call, budget=budget)
        _, state, _, _ = reader.read_typed_model(StateSnapshot, basis.bound_state_snapshot_ref)
        state_blob_key = artifact_ref_identity_key(state.state_ref)

        members: list[ClosureCasIdentity | ClosureOwnerValueIdentity] = []
        observed_edges: list[InputRef] = []
        json_verified = set(budget.payload_refs)

        def record_selected(
            edge: InputRef, selected_ref: ArtifactRef, manifest: ArtifactManifest
        ) -> None:
            if selected_ref.manifest_profile_sha256 is None:
                _fail("debug_source_selected_profile_missing")
            key = artifact_ref_identity_key(selected_ref)
            if selected_ref.media_type == "application/json":
                if key in json_verified:
                    if budget.manifests.get(key) != manifest:
                        _fail("debug_source_manifest_changed_during_read")
                else:
                    result = _read_bounded_method_metric_artifact(
                        cast("Any", store),
                        ref=_selected_ref(selected_ref, kind=selected_ref.kind),
                        max_bytes=MAX_METHOD_METRIC_SOURCE_BYTES,
                        read_budget=budget,
                    )
                    if result.manifest != manifest:
                        _fail("debug_source_manifest_changed_during_read")
                    json_verified.add(key)
            elif selected_ref.kind == "foundry.state_blob" and key == state_blob_key:
                # The selected typed StateSnapshot edge and full actual NPZ
                # bytes were independently reconciled immediately above.
                pass
            else:
                _fail("debug_source_binary_not_established")
            observed_edges.append(edge)
            members.append(_manifest_member(
                name=f"input.{len(members):04d}", role=edge.role,
                ref=selected_ref, manifest=manifest,
            ))

        basis_edge = InputRef(
            artifact_id=admitted.basis_ref.artifact_id,
            role="basis.execution_input_basis",
            manifest_profile_sha256=admitted.basis_ref.manifest_profile_sha256,
        )
        record_selected(basis_edge, admitted.basis_ref, admitted.basis_manifest)
        # This is the Foundry source owner's ordered enumeration, not a list
        # supplied by the reporting caller. Resolve every direct selected edge.
        for source_role, source_ref in _execution_input_basis_sources(basis):
            source_manifest, _ = reader.read_selected_manifest(source_ref)
            source_edge = InputRef(
                artifact_id=source_ref.artifact_id,
                role=f"basis.source.{source_role}",
                manifest_profile_sha256=source_ref.manifest_profile_sha256,
            )
            rows = [(source_edge, source_ref, source_manifest)]
            for edge in source_manifest.inputs:
                child_ref, child_manifest, _ = reader.read_edge_manifest(source_ref, edge)
                rows.append((InputRef(
                    artifact_id=edge.artifact_id,
                    role=f"basis.edge.{source_role}.{edge.role}",
                    manifest_profile_sha256=edge.manifest_profile_sha256,
                ), child_ref, child_manifest))
            for edge, selected_ref, manifest in rows:
                record_selected(edge, selected_ref, manifest)
        if tuple(observed_edges) != (basis_edge, *admitted.basis_inventory):
            _fail("debug_source_inventory_or_order_mismatch")

        witness = call.witness
        inputs = call.input_values
        if tuple(item.slot_id for item in inputs) != ("baseline", "scenario"):
            _fail("debug_actual_input_order_not_established")
        # Capture identities, not array contents, and never include output refs,
        # receipt time, or the random closure locator in the input projection.
        members.append(ClosureOwnerValueIdentity(
            name="restricted_execution",
            role="method.execution_input_identity",
            owner=_OWNER_ID,
            rule_version=_LAW,
            value={
                "profile_id": witness.profile_id,
                "profile_revision_sha256": witness.profile_revision_sha256,
                "method_abi_digest": witness.method_abi_digest,
                "method_callable_sha256": witness.method_callable_sha256,
                "runner_callable_sha256": witness.runner_callable_sha256,
                "backend_runtime_fingerprint": witness.backend_runtime_fingerprint,
                "state_reads": list(witness.state_reads),
                "parameter_reads": list(witness.parameter_reads),
                "parameter_origin": witness.parameter_origin,
                "poverty_line": None,
                "inputs": [
                    {"slot_id": item.slot_id, "dtype": item.dtype,
                     "shape": list(item.shape), "value_sha256": item.value_sha256}
                    for item in inputs
                ],
            },
        ))
        contract = SameInputClosureContract(
            owner=_OWNER_ID,
            purpose=EXECUTION_INPUT_IDENTITY_PURPOSE,
            rule_version=_LAW,
            members=tuple(ClosureMemberContract(
                name=member.name, role=member.role,
                identity_domain=member.identity_domain, required=True,
            ) for member in members),
        )
        refs = tuple(_edge_text(edge) for edge in observed_edges)
        closure = SameInputClosure(
            schema_version="2.0", closure_id=f"{selection.job_id}:restricted-exante-inputs",
            status="closed", run_id=self._run_id, job_id=selection.job_id,
            tenant_id=scope.tenant_id, cell_id=scope.cell_id,
            members=tuple(members), evidence_input_refs=refs,
        )
        digest = _same_input_closure_projection_sha256(
            closure=closure, contract=contract, resolved_members=members, observed_refs=refs
        )
        closure = closure.model_copy(update={"closure_sha256": digest})
        if (
            control.get_method_execution_selection(
                run_id=self._run_id, tenant_id=scope.tenant_id, cell_id=scope.cell_id,
                aggregate_read_budget=self._aggregate_read_budget,
            ) != selection
            or get_current_access_scope_or_none() != scope
        ):
            _fail("debug_selection_or_scope_changed_during_replay")
        return _ReplayedIdentity(closure=closure, contract=contract)


def issue_debug_execution_input_identity(
    *,
    control: ControlPlaneService,
    run_id: str,
    simulation_ref: ArtifactRef,
    aggregate_read_budget: _ProjectionReadBudget,
) -> tuple[SameInputClosure, VerifiedSameInputClosure]:
    """Issue the private Debug-use identity only after replaying the actual owner."""
    owner = _RestrictedExecutionIdentityOwner(
        control=control,
        run_id=run_id,
        simulation_ref=simulation_ref,
        aggregate_read_budget=aggregate_read_budget,
    )
    replayed = owner.replay()
    closure = replayed.closure
    verified = VerifiedSameInputClosure(
        _VERIFIED_CLOSURE_KEY,
        closure,
        closure.identity_tuple(),
        replayed.contract,
        owner,  # type: ignore[arg-type]
    )
    return closure, verified


def assert_debug_execution_input_identity(
    closure: SameInputClosure, verified: VerifiedSameInputClosure
) -> None:
    """Require current replay for this fixed input-identity purpose only."""
    if (
        type(verified) is not VerifiedSameInputClosure
        or verified._contract.purpose != EXECUTION_INPUT_IDENTITY_PURPOSE
        or type(verified._resolver) is not _RestrictedExecutionIdentityOwner
        or not verified._revalidate(closure)
    ):
        _fail("debug_execution_identity_not_established")
