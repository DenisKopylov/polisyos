"""Test-only removal of the real durability reconciliation property."""

from __future__ import annotations

import os


def pytest_configure() -> None:
    if os.environ.get("E02_COMPUTE_OWNER_REMOVAL") != "durability":
        return
    from polisyos.scientist.orchestration.engine.budget_ledger import FileBudgetLedger

    def bypass(_self: object, _event_id: str, _snapshot: object) -> None:
        return None

    FileBudgetLedger._confirm_compute_durability = bypass
