from importlib import import_module
from pydantic import BaseModel
class Carrier(BaseModel):
    loader: object
    def __getattribute__(self, name):
        return super().__getattribute__(name)
def consume(value):
    return None
value = Carrier(loader=import_module)
consume([value])
