"""Negative fragment: call inside the actual observed owner callback/lease."""

from polisyos.runtime.quality import generation_cycle as gc


def assert_changed_real_grounding_refuses_old_counterexample(monkeypatch, controller, kwargs):
    """Keep candidate, source and N5 bytes fixed; change current grounding evidence."""
    real = gc.PolicyGroundingPort.__call__
    continuation = gc.GenerationCycleController._retained_configured_cheap_continuation

    def changed_grounding(port, *, candidate, problem, cycle_index, generation_result):
        before = real(
            port, candidate=candidate, problem=problem, cycle_index=cycle_index,
            generation_result=generation_result,
        )
        assert before.status == "grounding_unavailable"
        return gc._grounding_unavailable(
            gc._candidate_id(candidate),
            issue_codes=("current_grounding_test_changed",),
            candidate_content_hash=gc._candidate_content_hash(candidate),
            design_problem_ref=gc._problem_ref(problem),
            authority_level=problem.authority_profile.requested_authority_level,
        )

    with monkeypatch.context() as local:
        local.setattr(gc.PolicyGroundingPort, "__call__", changed_grounding)
        result = continuation(controller, **kwargs)
    assert isinstance(result, gc._RetainedCheapNonReceipt)
    assert result.reason_code == "retained_cheap_counterexample_identity_changed"
    assert result.grounding is not None
    assert result.grounding.issue_codes == ("current_grounding_test_changed",)
    assert result.grounding.acquisition_requirement is not None
