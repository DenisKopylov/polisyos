"""Exercise reservation, finite readset and semantic discriminator with synthetic files."""
from __future__ import annotations

import copy
import gzip
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
CONTROLLER = HERE.parent / "controller.py"
spec = importlib.util.spec_from_file_location("r4_controller_synthetic", CONTROLLER)
assert spec is not None and spec.loader is not None
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
out = HERE / "stdlib-cases-r2"
out.mkdir(exist_ok=False)
checks = []


def refused(label, callback):
    try:
        callback()
    except (OSError, RuntimeError, ValueError, KeyError, TypeError):
        checks.append({"name": label, "status": "PASS"})
    else:
        raise AssertionError(label + " was not refused")


front = out / "front"
front.mkdir()
case = module.reserve_case(front, "pilot")
marker = case / "keep"
marker.write_text("unchanged")
refused("existing_case", lambda: module.reserve_case(front, "pilot"))
assert marker.read_text() == "unchanged"
refused("traversal", lambda: module.reserve_case(front, "../escape"))
(front / "runs/occupied").symlink_to(front / "missing-target")
refused("dangling_case", lambda: module.reserve_case(front, "occupied"))
assert (front / "runs/occupied").is_symlink()
front2 = out / "front2"
front2.mkdir()
target = out / "elsewhere"
target.mkdir()
(front2 / "runs").symlink_to(target, target_is_directory=True)
refused("symlink_runs", lambda: module.reserve_case(front2, "pilot"))
assert not list(target.iterdir())
alias = out / "alias"
alias.symlink_to(front, target_is_directory=True)
refused("symlink_parent", lambda: module.reserve_case(alias, "other"))
checks.append({"name": "fresh_reservation_and_collision_preservation", "status": "PASS"})

product = out / "synthetic-product"
source = product / "src/polisyos/witness.py"
source.parent.mkdir(parents=True)
source.write_bytes(b"VALUE = 1\n")
module.PRODUCT = product
module.ROOT = out
ev = out / "evidence"
ev.mkdir()
path = "src/polisyos/witness.py"
data = source.read_bytes()
git_blob = module.blob(data)
row = {
    "path": path, "sha256": module.sha(data), "git_blob": git_blob,
    "actual_blob": git_blob, "git_match": True,
}
record = {"pid": 123, "source_qualified": True, "foreign_source_modules": [], "files": [row]}


def load_readset(value):
    raw = json.dumps(value).encode()
    payload = gzip.compress(raw, mtime=0)
    (ev / "witness.json.gz").write_bytes(payload)
    observation = {
        "pid": 123, "readset": {"path": "witness.json.gz", "sha256": module.sha(payload),
                                "bytes": len(payload), "uncompressed_bytes": len(raw), "python_paths": 1}
    }
    return module.qualify_readset(observation, ev, {"policy-engine/" + path: git_blob})


assert load_readset(record)["python_paths"] == 1
checks.append({"name": "actual_readset_positive", "status": "PASS"})
bad = copy.deepcopy(record)
bad["files"][0]["sha256"] = "0" * 64
refused("actual_readset_changed_hash", lambda: load_readset(bad))
bad = copy.deepcopy(record)
bad["foreign_source_modules"] = [{"module": "polisyos.foreign"}]
refused("actual_readset_foreign_module", lambda: load_readset(bad))
bad = copy.deepcopy(record)
bad["files"][0]["path"] = "../outside.py"
refused("actual_readset_path_escape", lambda: load_readset(bad))
negative_names = (
    "disabled-rollout", "denied-permission", "wrong-tenant",
    "stale-attempt", "body-proof-substitution",
)
observed = {
    "queue": {"accepted_pending": True, "running_physical": True, "queued_body_calls": 0,
              "physical_workers": 1, "queued_jobs": 1, "outstanding_jobs": 2,
              "overflow_code": "shared_executor_queue_full", "cancelled_queued": False},
    "persisted": {"state": "cancelled", "verified": True, "attempt": 1, "lease_owner": None,
                  "manifest_ref": "m", "cancellation_event_count": 1, "cancellation_outbox_count": 1,
                  "other_terminal_count": 0, "progress_preserved": True},
    "running": {"attempt": 1, "manifest_ref": "m"},
    "fresh_http": {"status": 200, "state": "cancelled", "execution_status": "cancelled",
                   "physical_stop_status": "not_established", "cancellation_disposition": "publication_fenced"},
    "renewal": {"before": "2026-01-01", "after": "2026-01-02", "calls_under_held_compute": 1},
    "adversarial": [{"kind": name, "status": 403, "zero_protected_effects": True} for name in negative_names],
    "catalog": {"real_reader_identity_matches": True},
    "positive_current_authority_calls": 1, "positive_control_entry_calls": 1,
    "positive_control_body_calls": 1, "post": {"status": 200}, "retry": {"status": 200},
    "late_refused": {"progress": True, "manifest": True, "terminal": True},
    "held_until_readback": True,
    "queue_after_release": {"queued_body_calls": 1, "queued_jobs": 0, "outstanding_jobs": 0},
    "thread_errors": [],
}
assert module.property_checks(observed) == []
changed = copy.deepcopy(observed)
changed["persisted"]["state"] = "running"
assert module.property_checks(changed) == ["durable_cancellation"]
changed = copy.deepcopy(observed)
changed["adversarial"].pop()
assert module.property_checks(changed) == ["adversarial_zero_effect"]
checks.extend([
    {"name": "actual_semantic_discriminator", "status": "PASS"},
    {"name": "missing_negative_refused", "status": "PASS"},
])
# Exercise the actual whole qualification path with synthetic parent/child/JUnit.
fake = out / "qualifier-case"
parent_dir = fake / "evidence/parent"
child_dir = fake / "evidence/queued"
parent_dir.mkdir(parents=True)
child_dir.mkdir(parents=True)
head = "a" * 40
tree = "b" * 40
module.PYTHON = product / ".venv/bin/python"
argv = [str(module.PYTHON), "-B", "synthetic-harness", "--observe-pytest", module.NODE]
env = {"PYTHONDONTWRITEBYTECODE": "1", "PYTHONPYCACHEPREFIX": str(fake / "pycache"),
       "OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1",
       "NUMEXPR_NUM_THREADS": "1", "PYTEST_DISABLE_PLUGIN_AUTOLOAD": None, "PYTEST_ADDOPTS": None}
def fake_readset(directory, pid):
    record2 = {"pid": pid, "source_qualified": True, "foreign_source_modules": [], "files": [row]}
    raw = json.dumps(record2).encode()
    data2 = gzip.compress(raw, mtime=0)
    (directory / "readset.json.gz").write_bytes(data2)
    return {"path": "readset.json.gz", "sha256": module.sha(data2), "bytes": len(data2),
            "uncompressed_bytes": len(raw), "python_paths": 1}
parent = {"stage": "pytest_finished", "source": [head,tree], "source_after": [head,tree],
          "pytest_not_yet_imported": True, "initial_private_pycache_empty": True,
          "collected_node_ids_after_deselection": [module.NODE], "argv": argv[2:],
          "pytest": {"importmode": "importlib", "ini_addopts": ["--strict-markers"],
                     "inipath": str(product / "pytest.ini"), "pid": 200},
          "pid": 200, "environment": env, "sys_pycache_prefix": str(fake / "pycache"),
          "executable": str(module.PYTHON), "versions": {}, "pytest_exitstatus": 0,
          "readset": fake_readset(parent_dir,200)}
child = {**copy.deepcopy(observed), "stage":"complete", "source":[head,tree],
         "pid":201, "ppid":200, "environment":env, "executable":str(module.PYTHON),
         "case":{"cancel_queued":False,"remove_write_capacity":False},
         "readset": fake_readset(child_dir,201)}
(parent_dir / "parent-process.json").write_text(json.dumps(parent))
(child_dir / "observation.json").write_text(json.dumps(child))
def junit(failure=False):
    case_name = module.NODE.split("::")[-1]
    failure_xml = "<failure>synthetic deciding assertion</failure>" if failure else ""
    (fake / "junit.xml").write_text(
        '<testsuite><testcase name="' + case_name + '">' + failure_xml + "</testcase></testsuite>"
    )
module.selected_git_tree = lambda _head: {"policy-engine/" + path: git_blob}
result_good = {"complete":True, "aborted_reason":None, "return_code":0}
junit()
assert module.qualify_case(fake,head,tree,result_good,argv)["outcome"] == "PASS"
checks.append({"name":"whole_qualifier_positive","status":"PASS"})
parent_bad = copy.deepcopy(parent)
parent_bad["collected_node_ids_after_deselection"] = ["wrong-node"]
(parent_dir / "parent-process.json").write_text(json.dumps(parent_bad))
assert module.qualify_case(fake,head,tree,result_good,argv)["outcome"] == "ERROR"
checks.append({"name":"whole_qualifier_wrong_collection","status":"PASS"})
(parent_dir / "parent-process.json").write_text(json.dumps(parent))
child_bad = copy.deepcopy(child)
child_bad["persisted"]["state"] = "running"
(child_dir / "observation.json").write_text(json.dumps(child_bad))
parent_bad = copy.deepcopy(parent)
parent_bad["pytest_exitstatus"] = 1
(parent_dir / "parent-process.json").write_text(json.dumps(parent_bad))
junit(True)
result_bad = {"complete":True, "aborted_reason":None, "return_code":1}
bad_out = module.qualify_case(fake,head,tree,result_bad,argv)
assert bad_out["outcome"] == "FAIL" and bad_out["property_failures"] == ["durable_cancellation"],bad_out
checks.append({"name":"whole_qualifier_observed_semantic_failure","status":"PASS"})
child_bad["source"] = ["wrong", tree]
(child_dir / "observation.json").write_text(json.dumps(child_bad))
assert module.qualify_case(fake,head,tree,result_bad,argv)["outcome"] == "ERROR"
checks.append({"name":"whole_qualifier_child_source_mismatch","status":"PASS"})
result = {
    "scope": "actual controller functions over synthetic files and records; no product import or native case",
    "checks": checks,
    "denominator": len(checks),
    "runtime": "UNRUN",
    "closure_ids": [],
}
(HERE / "stdlib-results-r2.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
