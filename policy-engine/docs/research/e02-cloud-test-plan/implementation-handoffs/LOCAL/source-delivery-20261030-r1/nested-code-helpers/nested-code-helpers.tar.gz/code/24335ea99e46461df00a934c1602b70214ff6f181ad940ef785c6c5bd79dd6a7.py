def body():
    return None
def expose(unknown):
    if callable(None):
        value = [body.__code__]
    else:
        value = unknown
    match value:
        case [x]:
            opaque(x)
