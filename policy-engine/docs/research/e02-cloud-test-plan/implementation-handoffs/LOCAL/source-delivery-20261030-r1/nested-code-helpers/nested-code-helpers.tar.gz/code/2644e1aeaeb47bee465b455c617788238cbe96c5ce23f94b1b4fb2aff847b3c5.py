from types import FunctionType
def body():
    return None
CODE = body.__code__
run = FunctionType(CODE, globals())
run()
