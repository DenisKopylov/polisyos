"""Generate marker-preserving mutants against exact frozen RAW postimages."""
from __future__ import annotations

import difflib
from pathlib import Path

root = Path("LOCAL/raw/e02-execution-20261027/repairs/SQL-owner-chain-r3")


def patch(path: str, old: str, new: str, name: str) -> None:
    assert old != new
    prefix = f"diff --git a/{path} b/{path}\n"
    lines = difflib.unified_diff(
        old.splitlines(keepends=True),
        new.splitlines(keepends=True),
        fromfile=f"a/{path}",
        tofile=f"b/{path}",
    )
    (root / "controls" / name).write_text(prefix + "".join(lines))


path = "policy-engine/src/polisyos/runtime/http/services/debug_registered_sql.py"
old = (root / "postimages" / path).read_text()
new = old.replace(
    "if TYPE_CHECKING:\n",
    "_REMOVAL_PROBE_LAST_PROJECTION: dict[str, Any] = {}\n\n\nif TYPE_CHECKING:\n",
    1,
)
before = "            projection = owner.read_source_current_use((carrier,), require_selected=False)\n"
after = (
    "            key = str(carrier.snapshot_ref.artifact_id)\n"
    "            projection = _REMOVAL_PROBE_LAST_PROJECTION.get(key)\n"
    "            if projection is None:\n"
    "                projection = owner.read_source_current_use((carrier,), require_selected=False)\n"
    "                _REMOVAL_PROBE_LAST_PROJECTION[key] = projection\n"
)
assert new.count(before) == 1
patch(path, old, new.replace(before, after), "remove-currentness.patch")

path = (
    "policy-engine/src/polisyos/foundry/methods/catalog/policy/"
    "restricted_executable_profile.py"
)
old = (root / "postimages" / path).read_text()
begin = old.index("    def method_matches(")
end = old.index("    def runner_matches(", begin)
part = old[begin:end]
for before, after in (
    ("            or function is not self.method_operation\n", ""),
    ("            or _function_sha256(function) != self.method_code_sha256\n", ""),
    ("        return identity == self.method_identity\n", "        return identity is not None\n"),
):
    assert part.count(before) == 1
    part = part.replace(before, after)
patch(path, old, old[:begin] + part + old[end:], "remove-callable-binding.patch")
print("generated 2 controls against current postimages")
