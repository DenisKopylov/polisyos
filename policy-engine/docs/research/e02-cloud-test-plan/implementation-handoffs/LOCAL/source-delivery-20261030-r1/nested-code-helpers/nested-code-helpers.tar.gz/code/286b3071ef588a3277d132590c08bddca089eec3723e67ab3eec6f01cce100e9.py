from pathlib import Path
import ast
import hashlib
import json
import subprocess
import tomllib

root=Path.cwd()
base=Path(__file__).resolve().parent
product=root/'policy-engine'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip()
assert head=='662237cec3f0d7f9b01d4ba89f2ad5bdb23a3c80'
assert tree=='8abf5d45b27d8ff4d164b120786328ac914ed99d'
relative=[
'src/polisyos/runtime/quality/joint_simulation_horizon.py',
'src/polisyos/runtime/quality/generation_cycle.py',
' tests/unit/runtime/quality/test_c49_native_stopping_budget.py'.lstrip(),
' tests/unit/remediation/test_sim_01.py'.lstrip(),
]
checks=[]
for name in relative:
 p=base/'post'/'policy-engine'/name
 data=p.read_bytes()
 ast.parse(data,filename=name)
 for kind in ('check','format'):
  command=['./.venv/bin/python','-m','ruff',kind]
  if kind=='format': command+=['--check']
  command+=['--stdin-filename',name,'-']
  proc=subprocess.run(command,cwd=product,input=data,capture_output=True)
  checks.append({'path':name,'check':'ruff_'+kind,'exit_code':proc.returncode,'stdout':proc.stdout.decode(),'stderr':proc.stderr.decode()})
  assert proc.returncode==0,checks[-1]
 checks.append({'path':name,'check':'python_ast','exit_code':0})
with (base/'post/policy-engine/release-fragments/unreleased/2026-10-28-e02-candidate-stopping-budget.toml').open('rb') as f:
 tomllib.load(f)
checks.append({'check':'toml_parse','exit_code':0})
proc=subprocess.run(['git','apply','--check',str(base/'proposal.patch')],cwd=root,capture_output=True)
checks.append({'check':'git_apply_check','exit_code':proc.returncode,'stdout':proc.stdout.decode(),'stderr':proc.stderr.decode()})
assert proc.returncode==0,checks[-1]
report={'head':head,'tree':tree,'checks':checks,'product_imports':False,'tests_or_native_runs':False,'source_writes':False,'proposal_patch_sha256':hashlib.sha256((base/'proposal.patch').read_bytes()).hexdigest()}
(base/'static-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print('STATIC_CHECKS_PASS',len(checks))
