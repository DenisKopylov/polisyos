value = ["safe"]
match value:
    case [x]:
        opaque(x)
