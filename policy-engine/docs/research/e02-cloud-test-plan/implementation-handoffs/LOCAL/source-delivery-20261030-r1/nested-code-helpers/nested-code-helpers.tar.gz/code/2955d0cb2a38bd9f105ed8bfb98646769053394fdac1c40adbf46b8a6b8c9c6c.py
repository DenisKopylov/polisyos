from types import FunctionType
from importlib import import_module
def body():
    return None
CODE = body.__code__
def expose(key, fallback):
    bag = {"code": CODE}
    chosen = bag.get(key, fallback)
    opaque(chosen)
