"""Produce a source draft, then a distinct post-review one-run admission.

The reviewer must actually review the draft and its named fixture/controller
before finalization; this builder checks bytes and identities, not independence.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import re
import sys
from pathlib import Path

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
PACKET = ROOT / "LOCAL/raw/e02-execution-20261027/repairs/R4-native-control-r1"
CONTROLLER = PACKET / "controller/controller.py"
spec = importlib.util.spec_from_file_location(
    "r4_native_controller_for_admission", CONTROLLER
)
if spec is None or spec.loader is None:
    raise RuntimeError("controller unavailable")
controller = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = controller
spec.loader.exec_module(controller)


def selected(path: Path) -> Path:
    if not path.is_absolute() or not path.resolve().is_relative_to(
        controller.RAW.resolve()
    ):
        raise ValueError("path must be an absolute RAW path")
    return path


def write_new(path: Path, data: dict) -> str:
    selected(path)
    if path.is_symlink():
        raise ValueError("output is a symlink")
    cursor = path.parent
    while True:
        if cursor.is_symlink() or not cursor.is_dir():
            raise ValueError("unsafe output parent " + str(cursor))
        if cursor == cursor.parent:
            break
        cursor = cursor.parent
    payload = (json.dumps(data, sort_keys=True, indent=2) + "\n").encode()
    with path.open("xb") as output:
        output.write(payload)
        output.flush()
    return controller.sha(payload)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="mode", required=True)
    draft = sub.add_parser("draft")
    draft.add_argument("--expected-head", required=True)
    draft.add_argument("--expected-tree", required=True)
    draft.add_argument("--fixture-manifest", type=Path, required=True)
    draft.add_argument("--fixture-manifest-sha256", required=True)
    draft.add_argument("--fixture-postimage-sha256", required=True)
    draft.add_argument("--controller-sha256", required=True)
    draft.add_argument("--checks-sha256", required=True)
    draft.add_argument("--output", type=Path, required=True)
    final = sub.add_parser("finalize")
    final.add_argument("--draft", type=Path, required=True)
    final.add_argument("--draft-sha256", required=True)
    final.add_argument("--review", type=Path, required=True)
    final.add_argument("--review-sha256", required=True)
    final.add_argument("--numeric-job-alone-confirmed", action="store_true")
    final.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.mode == "draft":
        manifest = selected(args.fixture_manifest)
        controller.need(
            manifest.resolve(strict=True).is_relative_to(PACKET.resolve()),
            "fixture manifest outside packet",
        )
        controller.need(
            controller.checks.sha_file(manifest) == args.fixture_manifest_sha256,
            "fixture manifest mismatch",
        )
        controller.need(
            controller.checks.sha_file(CONTROLLER) == args.controller_sha256
            and controller.checks.sha_file(controller.CHECKS) == args.checks_sha256,
            "controller input mismatch",
        )
        actual = (
            controller.git("rev-parse", "HEAD", "HEAD^{tree}").decode().splitlines()
        )
        controller.need(
            actual == [args.expected_head, args.expected_tree],
            "source identity differs",
        )
        controller.need(
            controller.git("symbolic-ref", "--short", "HEAD").decode().strip()
            == controller.BRANCH
            and not controller.git("status", "--porcelain", "--untracked-files=no"),
            "branch or tracked/index state differs",
        )
        controller.need(
            controller.checks.sha_file(ROOT / controller.TEST)
            == args.fixture_postimage_sha256,
            "fixture postimage mismatch",
        )
        controller.need(
            __import__("subprocess")
            .run(
                [
                    "git",
                    "-C",
                    str(ROOT),
                    "merge-base",
                    "--is-ancestor",
                    controller.BASE,
                    actual[0],
                ],
                check=False,
            )
            .returncode
            == 0,
            "not a descendant of inspection base",
        )
        changed = sorted(
            p.decode()
            for p in controller.git(
                "diff", "--no-renames", "--name-only", "-z", controller.BASE, actual[0]
            ).split(b"\0")
            if p
        )
        value = {
            "schema": "policyos.e02.r4.native-pilot-draft.v1",
            "branch": controller.BRANCH,
            "source_base": controller.BASE,
            "source_head": actual[0],
            "source_tree": actual[1],
            "changed_paths_from_base": changed,
            "test_path": controller.TEST,
            "fixture_postimage_sha256": args.fixture_postimage_sha256,
            "fixture_manifest_path": str(manifest.relative_to(ROOT)),
            "fixture_manifest_sha256": args.fixture_manifest_sha256,
            "controller_sha256": args.controller_sha256,
            "checks_sha256": args.checks_sha256,
            "source_pins": [
                controller.tracked_pin(path, actual[0])
                for path in sorted(controller.REQUIRED)
            ],
            "node": controller.NODE,
            "resource_profile": {
                "rss_cap_bytes": controller.RSS_CAP,
                "disk_admission_bytes": controller.DISK_START,
                "disk_stop_bytes": controller.DISK_STOP,
                "deadline_seconds": controller.DEADLINE,
                "numeric_threads": 1,
            },
            "state": "DRAFT_REVIEW_REQUIRED",
            "closure_ids": [],
        }
        digest = write_new(args.output, value)
    else:
        draft_path, review = selected(args.draft), selected(args.review)
        controller.need(
            controller.checks.sha_file(draft_path) == args.draft_sha256
            and controller.checks.sha_file(review) == args.review_sha256,
            "draft/review hash mismatch",
        )
        draft_value = json.loads(draft_path.read_bytes())
        controller.need(
            draft_value["schema"] == "policyos.e02.r4.native-pilot-draft.v1"
            and draft_value["state"] == "DRAFT_REVIEW_REQUIRED",
            "not a draft",
        )
        review_text = review.read_text()
        controller.need(
            args.draft_sha256 in review_text
            and re.search(r"(?mi)^\s*(?:decision|verdict):\s*GO\s*$", review_text)
            is not None,
            "review must name exact draft hash and an explicit GO decision",
        )
        controller.need(
            args.numeric_job_alone_confirmed, "Root must confirm one numeric job"
        )
        value = dict(draft_value)
        value.update(
            {
                "schema": "policyos.e02.r4.native-pilot-admission.v1",
                "decision": "GO",
                "review_path": str(review.relative_to(ROOT)),
                "review_sha256": args.review_sha256,
                "draft_path": str(draft_path.relative_to(ROOT)),
                "draft_sha256": args.draft_sha256,
                "numeric_job_alone_confirmed": True,
            }
        )
        del value["state"]
        digest = write_new(args.output, value)
    print(json.dumps({"path": str(args.output), "sha256": digest, "mode": args.mode}))


if __name__ == "__main__":
    main()
