"""Exercise the R3 controller on synthetic records; no product or native execution."""
from __future__ import annotations
import copy
import importlib.util
import json
import sys
from pathlib import Path
from unittest.mock import patch

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
REVIEW = ROOT / 'LOCAL/raw/e02-execution-20261027/repairs/R4-native-control-r1/fixture-admission-synthetic-r1'
PACKET = ROOT / 'LOCAL/raw/e02-execution-20261027/repairs/R4-native-control-r1/fixture-admission-r1'
def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec and spec.loader
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod
ctrl = load(PACKET / 'controller.py', 'r4_r3_independent_synthetic_controller')
controls = load(ROOT / 'LOCAL/raw/e02-execution-20261027/repairs/R4-native-control-r1/controller-r3/controls/stdlib_controls.py', 'r4_r3_independent_synthetic_seed')
checks = ctrl.checks


def execute(name, change):
    case = REVIEW / ('synthetic-r2-' + name)
    assert (case / 'evidence/native').is_dir(), 'expected preserved synthetic case missing'
    obs = controls.observation()
    obs['schema'] = 'policyos.e02.r4.native_forest_fit_cancel.v1'
    source = {'source_kind':'ir.observation_method_input','rows':2000,'sample_ids_unique':True,'source_authority':'fixture_synthetic_candidate','source_ref':{'id':'synthetic'},'payload_file_sha256':'0'*64}
    method = {'requested_fqn':'causal.hte.forest_dr@1.1.0','effective_fqn':'causal.hte.forest_dr@1.1.0','effective_params':{'n_estimators':128,'cv_folds':2,'subforest_size':4,'random_state':None,'n_jobs':1},'resource_policy_ref':{'id':'policy'},'resource_policy_digest':'1'*64,'job_id':'job','run_id':'run','lease_owner':'worker','attempt':1,'work_descriptor':{'job_id':'job','run_id':'run','attempt':1,'requested_source_ref':source['source_ref'],'observational_run_intent_ref':{'id':'intent'}}}
    method['launch']={'request_body':{'observational_input':{'method':{'params':{'n_estimators':128,'cv_folds':2,'subforest_size':4,'n_jobs':1}}}}}
    method['intent_cas']={}
    obs.update(process={'pid':12,'executable':str(ctrl.PYTHON),'source':{'head':'synthetic-head','tree':'synthetic-tree','test_path':ctrl.TEST,'test_sha256':checks.sha_file(ROOT / ctrl.TEST)}},input=source,method=method,catalog={'selected_database_path':str(case),'served_database_path':str(case),'selected_snapshot_root':str(case),'served_snapshot_root':str(case)},errors=[],teardown={'outcome':'naturally_settled','dispatch_alive':False,'method_busy':False,'queued_busy':False,'peer_busy':False},sqlite={'database_path':str(case/'synthetic.sqlite3')})
    obs['case'].update(stage='complete',test_nodeid=ctrl.NODE)
    obs['native']['econml_version']='synthetic'
    obs['executor'].update(profile={'capacity':2,'queue_capacity':2},nonnumeric_peer={'mode':'event_wait','numeric_work':False,'is_current_shared_executor_worker':True,'pid':12,'thread_id':32,'native_thread_id':42,'enter_ns':15,'release_ns':71,'exit_ns':72,'release_observed':True},queue={'pending_when_fit_active':True,'overflow_error_code':'shared_executor_queue_full','overflow_capacity':2,'overflow_queue_capacity':2,'overflow_queue_depth':2,'physical_workers':2,'queued_jobs':2,'outstanding_jobs':4,'full_observed_ns':25,'follower_events':[{'follower_id':1,'pid':12,'monotonic_ns':73},{'follower_id':2,'pid':12,'monotonic_ns':74}]},shared_execution_handle={'captured':True,'done_at_post_end':False})
    obs['lease']={'renewals':[{'result':True,'fresh_owner':'worker','fresh_attempt':1,'expected_attempt':1,'monotonic_ns':26,'fresh_lease_expires_at':'2'},{'result':True,'fresh_owner':'worker','fresh_attempt':1,'expected_attempt':1,'monotonic_ns':27,'fresh_lease_expires_at':'3'}]}
    before={'job_row':{'job_id':'job','run_id':'run','attempt':1,'lease_owner':'worker','state':'running','lease_expires_at':'1','method_execution_selection_json':None},'progress':[],'events':[],'outbox':[]}
    negatives=[]
    for kind,status,attempt,start in [('stale_attempt',409,0,26),('denied_permission',403,1,28)]:
        negatives.append({'kind':kind,'url':'/api/v1/control/jobs/job/cancel','request_url':'http://testserver/api/v1/control/jobs/job/cancel','request_body':{'expected_lease_owner':'worker','expected_attempt':attempt,'operation_id':kind},'status_code':status,'request_start_ns':start,'request_end_ns':start+1,'before_snapshot':copy.deepcopy(before),'before_snapshot_sha256':checks.snapshot_sha(before),'after_snapshot':copy.deepcopy(before),'after_snapshot_sha256':checks.snapshot_sha(before)})
    obs['negatives']=negatives
    wire='{"expected_lease_owner":"worker","expected_attempt":1,"operation_id":"op"}'
    body=json.loads(wire)
    digest='sha256:'+checks.sha_bytes(wire.encode())
    carrier={'authorized_actor':'actor','tenant_id':'tenant','cell_id':'cell','operation_id':'op','body_sha256':digest,'expected_attempt':1,'expected_lease_owner':'worker','disposition':'publication_fenced','physical_stop_status':'not_established','cancelled_attempt':1,'cancelled_lease_owner':'worker'}
    snapshot={'job_row':{'job_id':'job','run_id':'run','attempt':1,'lease_owner':None,'state':'cancelled','method_execution_selection_json':None},'progress':[{'job_id':'job','progress_json':json.dumps({'cancellation':carrier})}],'events':[{'job_id':'job','event_type':'job_created','payload_json':json.dumps({'execution_scope':{'tenant_id':'tenant','cell_id':'cell'}})},{'job_id':'job','event_type':'job_cancelled','payload_json':json.dumps({**carrier,'state':'cancelled'})}],'outbox':[{'job_id':'job','topic':'control.job.cancelled','payload_json':json.dumps({**carrier,'state':'cancelled','job_id':'job','run_id':'run'})}]}
    cancel=obs['cancel']
    cancel.update(authorized=True,current_authority_at_entry=True,actual_store_cancel_entry_ns=40,actual_store_cancel_body_called_at_ns=41,status_code=200,url='/api/v1/control/jobs/job/cancel',request_url='http://testserver/api/v1/control/jobs/job/cancel',request_body=body,request_wire_utf8=wire,authorized_actor='actor',tenant_id='tenant',cell_id='cell',authority={'authorized_actor':'actor','tenant_id':'tenant','bound_job_id_selector':json.dumps('job'),'bound_cell_id_selector':json.dumps('cell'),'body_sha256':digest,'operation_id':'op','expected_lease_owner':'worker','expected_attempt':1},database_path=str(case/'synthetic.sqlite3'),fresh_sqlite_readback={'monotonic_ns':80,'snapshot':copy.deepcopy(snapshot),'snapshot_sha256':checks.snapshot_sha(snapshot),'subsequent_job_read':{k:snapshot['job_row'][k] for k in ('job_id','run_id','state','attempt','lease_owner')},'verified_cancelled_record':True,'verification_error':None},fresh_http_get={'method':'GET','url':'/api/v1/control/jobs/job','request_url':'http://testserver/api/v1/control/jobs/job','status_code':200,'body':{'job_id':'job','run_id':'run','state':'cancelled','execution_status':'cancelled','physical_stop_status':'not_established','cancellation_disposition':'publication_fenced','progress':{'cancellation':{'body_sha256':digest}}}},fresh_run_get={'method':'GET','url':'/api/v1/runs/run','request_url':'http://testserver/api/v1/runs/run','status_code':200,'body':{'run':{'run_id':'run','control_job_id':'job','method_execution_selection':{'status':'withheld'}}}},retry={'method':'POST','url':'/api/v1/control/jobs/job/cancel','request_url':'http://testserver/api/v1/control/jobs/job/cancel','request_body':body,'request_wire_utf8':wire,'status_code':200,'body':{'job_id':'job','run_id':'run','state':'cancelled','cancellation_disposition':'publication_fenced'}})
    refused={'called':True,'refused':True,'returned_normally':False,'exception_type':'ControlJobLeaseLostError'}
    obs['final']={'queued_body_entered_after_peer_release':True,'stale_write_results':{k:copy.deepcopy(refused) for k in ('progress','manifest','terminal')},'database_path':str(case/'synthetic.sqlite3'),'snapshot':copy.deepcopy(snapshot),'snapshot_sha256':checks.snapshot_sha(snapshot)}
    obs['result'].update(handler_errors=[],candidate_outcome=None)
    if change == 'running':
        running=copy.deepcopy(before)
        cancel['fresh_sqlite_readback'].update(snapshot=running,snapshot_sha256=checks.snapshot_sha(running),subsequent_job_read={k:running['job_row'][k] for k in ('job_id','run_id','state','attempt','lease_owner')},verified_cancelled_record=False)
        obs['final'].update(snapshot=copy.deepcopy(running),snapshot_sha256=checks.snapshot_sha(running))
        snapshot=running
    elif change == 'stale':
        obs['final']['stale_write_results']['progress']={'called':True,'refused':False,'returned_normally':True,'exception_type':None}
    elif change == 'race':
        cancel['fresh_sqlite_readback']['subsequent_job_read']['state']='running'
    assert (case/'evidence/native/fixture-observation.json').read_text() == json.dumps(obs), 'saved synthetic inputs differ'
    db={**copy.deepcopy(snapshot),'database':{'path':str(case/'synthetic.sqlite3'),'sha256':'synthetic','bytes':0},'wal':None}
    plan={'source_head':'synthetic-head','source_tree':'synthetic-tree','external_environment':{'package_metadata':{'econml':{'version':'synthetic'}}}}
    parent={'pid':12,'junit':{'error':False,'skipped':False,'failure':change in {'running','stale'}}}
    with patch.object(checks,'verify_loaded_origins',return_value={}),patch.object(checks,'source_custody',return_value={}),patch.object(checks,'intent_custody',return_value={}),patch.object(checks,'selected_cas',return_value=({'seed':0,'seed_policy_revision':'server_seed_zero_v1'},{})),patch.object(checks,'sqlite_final',return_value=db):
        return ctrl.qualify_case(case,plan,parent,{})

results={}
for name,variant,want in [('positive','none','PASS'),('running_after_cancel','running','FAIL'),('guarded_stale_return','stale','FAIL'),('conflicting_fresh_reads','race','INCONCLUSIVE')]:
    try:
        outcome=execute(name,variant)
        results[name]={'actual':outcome['state'],'expected':want,'pass':outcome['state']==want}
    except Exception as exc:
        results[name]={'actual':'EXCEPTION','expected':want,'pass':False,'error':type(exc).__name__+': '+str(exc)}
output={'scope':'synthetic controller integration; CAS, installed origins, SQLite access mocked; no product/native execution','results':results,'pass':all(row['pass'] for row in results.values())}
print(json.dumps(output,indent=2,sort_keys=True))
if not output['pass']:
    raise SystemExit(1)
