VALUE = 'package-initializer'
