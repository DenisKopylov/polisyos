"""Stdlib-only source diagnostic; no pytest/product import or spawned process."""
from pathlib import Path
from importlib.machinery import ModuleSpec, PathFinder
from importlib.util import module_from_spec
from types import ModuleType
import ast
import hashlib
import inspect
import json
import multiprocessing.spawn
import os
import sys

root = Path.cwd()
package = root / "LOCAL/raw/e02-execution-20261027/repairs/C96-real-saturation-oracle-r2"
helper = package / "postimages/policy-engine/tests/_helpers/e02_c96_control_harness.py"
source = helper.read_bytes()
tree = ast.parse(source)
bootstrap = next(node for node in tree.body if isinstance(node, ast.FunctionDef)
                 and node.name == "_bootstrap_checkout_imports")
compiled = compile(ast.Module(body=[bootstrap], type_ignores=[]), str(helper), "exec")
logical_helper = root / "policy-engine/tests/_helpers/e02_c96_control_harness.py"
product = root / "policy-engine"
owned_tests = product / "tests"
assert not (owned_tests / "__init__.py").exists()
assert (owned_tests / "_helpers/__init__.py").read_bytes() == b""
fake = package / "sourcechecks/fake-site"
(fake / "tests").mkdir(parents=True, exist_ok=True)
foreign_init = fake / "tests/__init__.py"
foreign_init.write_text("raise AssertionError('A foreign tests initializer must never execute')\n")
baseline = PathFinder.find_spec("tests", [str(product), str(fake)])
assert baseline is not None and Path(baseline.origin) == foreign_init
assert "tests" not in sys.modules and "pytest" not in sys.modules
original_path = list(sys.path)
checkout_roots = {product, product / "src", owned_tests}
removed = [item for item in original_path if Path(item or ".").resolve() in checkout_roots]
initial_path = [item for item in original_path if Path(item or ".").resolve() not in checkout_roots]
assert str(product) not in initial_path
namespace = {"Path": Path, "ModuleSpec": ModuleSpec, "module_from_spec": module_from_spec,
             "sys": sys, "os": os, "__file__": str(logical_helper), "__name__": "__main__"}
exec(compiled, namespace)
sys.path[:] = [str(fake), *initial_path]
parent = namespace["_bootstrap_checkout_imports"]()
assert parent["sys_path_prefix"] == [str(product), str(product / "src"), str(owned_tests)]
assert list(sys.modules["tests"].__path__) == [str(owned_tests)]
local_helpers = PathFinder.find_spec("tests._helpers", [str(owned_tests)])
assert Path(local_helpers.origin) == owned_tests / "_helpers/__init__.py"
actual_support = PathFinder.find_spec("tests._helpers.runtime_http", local_helpers.submodule_search_locations)
assert Path(actual_support.origin) == owned_tests / "_helpers/runtime_http.py"
# A second, fresh namespace models the bootstrap that the child entrypoint runs;
# this executes no spawn, target import, pytest, empty __init__, or product code.
del sys.modules["tests"]
sys.path[:] = [str(fake), *initial_path]
namespace["__name__"] = "__mp_main__"
child = namespace["_bootstrap_checkout_imports"]()
assert child["sys_path_prefix"] == parent["sys_path_prefix"]
assert child["tests_namespace_paths"] == [str(owned_tests)]
del sys.modules["tests"]
foreign = ModuleType("tests")
foreign.__file__ = str(foreign_init)
foreign.__path__ = [str(foreign_init.parent)]
sys.modules["tests"] = foreign
try:
    namespace["_bootstrap_checkout_imports"]()
except RuntimeError as exc:
    assert "foreign tests module" in str(exc)
else:
    raise AssertionError("Already-loaded foreign tests was accepted")
assert sys.modules["tests"] is foreign
spawn_main = ast.parse(inspect.getsource(multiprocessing.spawn._main))
prepare_call = next(node for node in ast.walk(spawn_main) if isinstance(node, ast.Call)
                    and isinstance(node.func, ast.Name) and node.func.id == "prepare")
pickle_calls = [node for node in ast.walk(spawn_main) if isinstance(node, ast.Call)
                and isinstance(node.func, ast.Attribute) and node.func.attr == "load"]
assert any(node.lineno > prepare_call.lineno for node in pickle_calls)
prepare_source = ast.parse(inspect.getsource(multiprocessing.spawn.prepare))
assert any(isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
           and node.func.id == "_fixup_main_from_path" for node in ast.walk(prepare_source))
fixup = ast.parse(inspect.getsource(multiprocessing.spawn._fixup_main_from_path))
assert any(isinstance(node, ast.keyword) and node.arg == "run_name"
           and isinstance(node.value, ast.Constant) and node.value.value == "__mp_main__"
           for node in ast.walk(fixup))
assert "pytest" not in sys.modules
assert not any(name == "polisyos" or name.startswith("polisyos.") for name in sys.modules)
result = {"schema": "policyos.e02.c96.bootstrap_source_probe.v1",
          "helper_sha256": hashlib.sha256(source).hexdigest(),
          "isolated_flag": sys.flags.isolated,
          "diagnostic_removed_incidental_checkout_path_entries": removed,
          "probe_path_did_not_supply_checkout_roots": not any(str(item) in initial_path for item in checkout_roots),
          "root_prepend_alone_loses_to_foreign_regular_package": str(baseline.origin),
          "parent_bootstrap": parent, "fresh_namespace_child_source_simulation": child,
          "existing_local_support_resolved_without_import": str(actual_support.origin),
          "already_loaded_foreign_module_refused_without_replacement": True,
          "stdlib_spawn_prepare_precedes_target_unpickle_source_order": True,
          "actual_spawn_or_pytest_collection": "UNRUN",
          "product_and_pytest_imports": False}
print(json.dumps(result, indent=2, sort_keys=True))
