"""Losslessly compact uncited redundant scan/readback output with exact readback."""
from __future__ import annotations
import gzip,hashlib,json
from pathlib import Path

root=Path(".")
names=[
 "checks/bindings-merge.candidate",
 "checks/ruff-original.json",
 "checks/ruff-final.json",
 "checks/future-import-scan.json",
 "checks/intake-readback-r2.json",
 "checks/intake-readback-r3.json",
 "checks/sql-root-admission/manifest.json",
 "checks/sql-root-admission-readback/manifest.json",
 "checks/sql-root-admission-readback-r2/manifest.json",
 "checks/sql-root-admission-readback-r3/manifest.json",
]
rows=[]
for name in names:
 original=root/name
 data=original.read_bytes()
 packed=gzip.compress(data,compresslevel=9,mtime=0)
 output=Path(str(original)+".gz")
 output.write_bytes(packed)
 recovered=gzip.decompress(output.read_bytes())
 assert recovered==data,name
 rows.append({"original":name,"original_sha256":hashlib.sha256(data).hexdigest(),
              "original_bytes":len(data),"gzip":str(output),
              "gzip_sha256":hashlib.sha256(packed).hexdigest(),"gzip_bytes":len(packed),
              "readback":"byte-identical"})
 original.unlink()
(root/"checks/historical-compression.json").write_text(json.dumps(rows,indent=2)+"\n")
print("files",len(rows),"before",sum(r["original_bytes"] for r in rows),
      "after",sum(r["gzip_bytes"] for r in rows))
