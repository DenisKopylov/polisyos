"""Ruff check and format check on exact frozen bytes under canonical filenames."""
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from pathlib import Path

repo = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
product = repo / "policy-engine"
base = repo / "LOCAL/raw/e02-execution-20261027/repairs/SQL-owner-chain-r3"
dest = repo / "LOCAL/raw/e02-execution-20261027/repairs/SQL-owner-chain-r3-intake-20261028-r1"
manifest = base / "frozen-77e00604/file-pins.json"
sha = lambda data: hashlib.sha256(data).hexdigest()
assert sha(manifest.read_bytes()) == "c8c729ec6b4fde90145f24f9b2653ad63bb8167af5fc0eda723add400c84afa0"
data = json.loads(manifest.read_bytes())
rows = []
for entry in data["files"]:
    path = entry["path"]
    post = base / "postimages" / path
    raw = post.read_bytes()
    assert sha(raw) == entry["post_sha256"], path
    if not path.endswith(".py"):
        continue
    row = {"path": path, "post_sha256": sha(raw), "checks": []}
    for label, args in (
        ("check", ["check", "--no-cache"]),
        ("format", ["format", "--check", "--no-cache"]),
    ):
        command = [str(product / ".venv/bin/python"), "-m", "ruff", *args,
                   "--stdin-filename", str(repo / path), "-"]
        run = subprocess.run(command, cwd=product, input=raw, stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE, check=False)
        row["checks"].append({"label": label, "command": command, "exit": run.returncode,
                              "stdout": run.stdout.decode(), "stderr": run.stderr.decode()})
    rows.append(row)
(dest / "checks/ruff-original.json").write_text(json.dumps({
    "scope": "every Python postimage in frozen SQL 77e",
    "denominator": len(rows), "ruff_cwd": str(product), "results": rows,
}, indent=2) + "\n")
print("Python postimages:", len(rows))
for phase in ("check", "format"):
    failures = [(row["path"], check["stdout"], check["stderr"]) for row in rows
                for check in row["checks"] if check["label"] == phase and check["exit"]]
    print(phase, "failures", len(failures))
    for path, out, err in failures:
        print(path)
        if phase == "check":
            print(out, err)
