"""Finite synthetic controls for R2; historical observation remains historical."""
from __future__ import annotations

import copy
import importlib.util
import json
import sqlite3
from pathlib import Path

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("r4_r2_synthetic", HERE.parent / "controller.py")
assert spec is not None and spec.loader is not None
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
r1 = m.import_retained()
out = HERE / "stdlib-cases-r3"
out.mkdir(exist_ok=False)
checks = []


def refused(name, callback):
    try:
        callback()
    except (OSError, RuntimeError, ValueError, KeyError, TypeError):
        checks.append({"name": name, "status": "PASS"})
    else:
        raise AssertionError(name + " was not refused")


historic = json.loads((
    m.RAW / "cloud/C144/delivered/raw-return/B1-queued-removal/queued/observation.json"
).read_bytes())
m.common_observation(historic)
m.guard_property(historic, "remove")
m.removal_observation(historic)
checks.append({"name": "historical_removal_shape", "status": "PASS"})
bad = copy.deepcopy(historic)
bad["persisted"]["state"] = "cancelled"
refused("durable_marker_without_actual_red", lambda: m.removal_observation(bad))
bad = copy.deepcopy(historic)
bad["positive_current_authority_calls"] = 0
refused("missing_actual_authority", lambda: m.common_observation(bad))
bad = copy.deepcopy(historic)
bad["guard_identity"]["removal_executor_id"] = -1
refused("removal_wrong_executor", lambda: m.guard_property(bad, "remove"))
bad = copy.deepcopy(historic)
bad["adversarial"].pop()
refused("missing_negative_control", lambda: m.common_observation(bad))

parent = {"pid": 998000001}
child = {"pid": 998000002, "ppid": parent["pid"]}
def fake_supervisor(name, fault=None):
    case = out / name
    case.mkdir()
    (case / "sandbox.sb").write_text("fake")
    plan = {"argv": ["python", "test"], "cwd": str(out), "rss_cap_bytes": 2300*1024**2,
            "disk_stop_bytes": 6*1024**3, "disk_admission_bytes": 8*1024**3, "deadline_seconds": 600}
    argv = ["/usr/bin/sandbox-exec", "-f", str(case / "sandbox.sb"), *plan["argv"]]
    processes = [
        [{"pid":parent["pid"],"ppid":1,"rss_kib":100}],
        [{"pid":parent["pid"],"ppid":1,"rss_kib":200},
         {"pid":child["pid"],"ppid":parent["pid"],"rss_kib":300}],
    ]
    samples=[]
    for i,items in enumerate(processes):
        samples.append({"kind":"sample","command_id":"c96-queued",
                        "disk_free_bytes":9*1024**3-i, "elapsed_command_seconds":float(i),
                        "processes":items,
                        "sampled_process_tree_rss_bytes":sum(p["rss_kib"]*1024 for p in items)})
    result = {"id":"c96-queued","argv":argv,"cwd":str(out),"complete":True,
              "status":"command_failed","return_code":1,"process_group_gone":True,
              "aborted_reason":None,"termination_signal":None,"pid":parent["pid"],
              "sample_count":2,"disk_free_before_bytes":9*1024**3,
              "max_sampled_process_tree_rss_bytes":500*1024,
              "minimum_sampled_disk_free_bytes":9*1024**3-1,"wall_seconds":2.0}
    if fault == "spawn_error":
        result["spawn_or_supervision_error"] = "synthetic"
    elif fault == "phase_error":
        result["phase_receipt_write_error"] = "synthetic"
    elif fault == "nested_error":
        result["extra"] = {"nested_error": "synthetic"}
    elif fault == "group":
        result["process_group_gone"] = False
    elif fault == "signal":
        result["termination_signal"] = "SIGTERM"
    elif fault == "sample_count":
        result["sample_count"] = 3
    elif fault == "rss":
        samples[1]["sampled_process_tree_rss_bytes"] += 1
    elif fault == "disk":
        samples[1]["disk_free_bytes"] = plan["disk_stop_bytes"]-1
    elif fault == "child_absent":
        samples[1]["processes"] = samples[1]["processes"][:1]
        samples[1]["sampled_process_tree_rss_bytes"] = 200*1024
        result["max_sampled_process_tree_rss_bytes"] = 200*1024
    (case / "process-tree.jsonl").write_text("".join(json.dumps(x)+"\n" for x in samples))
    (case / "controller-events.jsonl").write_text(json.dumps(
        {"kind":"command_finish","id":"c96-queued","status":"command_failed","return_code":1})+"\n")
    (case / "phase-output.jsonl").write_text(json.dumps(
        {"phase":"finish","id":"c96-queued","status":"command_failed","return_code":1})+"\n")
    return case,result,plan


case,result,plan=fake_supervisor("supervisor-positive")
assert m.strict_supervisor(case,result,plan,parent,child,"remove")["sample_count"] == 2
checks.append({"name":"strict_supervisor_expected_red_process","status":"PASS"})
original_pid_gone=m.pid_gone
m.pid_gone=lambda _pid:False
refused("new_phase_live_pid",lambda:m.strict_supervisor(case,result,plan,parent,child,"remove"))
assert m.strict_supervisor(case,result,plan,parent,child,"remove",check_current_pids=False)["sample_count"]==2
m.pid_gone=original_pid_gone
checks.append({"name":"prior_pid_reuse_not_misclassified","status":"PASS"})
for fault in ("spawn_error","phase_error","nested_error","group","signal","sample_count","rss","disk","child_absent"):
    case,result,plan=fake_supervisor("supervisor-"+fault,fault)
    refused("strict_"+fault,lambda c=case,r=result,p=plan:m.strict_supervisor(c,r,p,parent,child,"remove"))

# Check path-only normalization against the actual retained baseline plan.
baseline=json.loads((m.BASE_CASE/"plan.json").read_bytes())
phase=out/"profile"
phase.mkdir()
replace=lambda value: m.normalized(value,m.BASE_CASE)
def rewrite(value):
    if isinstance(value,str): return value.replace(str(m.BASE_CASE),str(phase))
    if isinstance(value,list): return [rewrite(x) for x in value]
    if isinstance(value,dict): return {k:rewrite(v) for k,v in value.items()}
    return value
plan=rewrite(copy.deepcopy(baseline))
plan["extra_env"][m.MUTATION]="1"
(phase/"sandbox.sb").write_text((m.BASE_CASE/"sandbox.sb").read_text().replace(str(m.BASE_CASE),str(phase)))
m.compare_profile(plan,phase,baseline,"remove")
checks.append({"name":"profile_only_paths_and_removal", "status":"PASS"})
bad=copy.deepcopy(plan);bad["extra_env"].pop(m.MUTATION)
refused("profile_missing_removal",lambda:m.compare_profile(bad,phase,baseline,"remove"))
bad=copy.deepcopy(plan);bad["extra_env"]["EXTRA_UNDECLARED"]="1"
refused("profile_extra_env",lambda:m.compare_profile(bad,phase,baseline,"remove"))
bad=copy.deepcopy(plan);bad["rss_cap_bytes"]+=1
refused("profile_resource_changed",lambda:m.compare_profile(bad,phase,baseline,"remove"))
restored=copy.deepcopy(plan);restored["extra_env"].pop(m.MUTATION)
m.compare_profile(restored,phase,baseline,"restore")
checks.append({"name":"profile_restoration_absent_mutation","status":"PASS"})

# Final DB witness is independent of the earlier observer's intermediate moment.
def fake_db(name, state, cancellation):
    case=out/name
    db=case/"pytest-tmp/test_authenticated_cancellatio0/case/runtime-env/.polisyos/control_plane.sqlite3"
    db.parent.mkdir(parents=True)
    connection=sqlite3.connect(db)
    connection.executescript(
        "create table control_jobs(job_id text, state text, lease_owner text, attempt integer, capability_manifest_ref text);"
        "create table control_job_events(job_id text, event_type text);"
        "create table control_outbox_events(job_id text, topic text);"
        "create table control_job_progress(job_id text);"
    )
    job="job_execution_admission"
    connection.execute("insert into control_jobs values(?,?,?,?,?)",
                       (job,state,None,historic["running"]["attempt"],historic["running"]["manifest_ref"]))
    connection.execute("insert into control_job_progress values(?)",(job,))
    if cancellation:
        connection.execute("insert into control_job_events values(?,?)",(job,"job_cancelled"))
        connection.execute("insert into control_outbox_events values(?,?)",(job,"control.job.cancelled"))
    else:
        connection.execute("insert into control_job_events values(?,?)",(job,"job_completed"))
    connection.commit();connection.close()
    (case/"pytest-tmp/test_authenticated_cancellatiocurrent").symlink_to(
        "test_authenticated_cancellatio0",target_is_directory=True
    )
    return case


# Relative output locators must resolve within the synthetic ROOT for this isolated control.
m.ROOT=out
removal_case=fake_db("db-removal","completed",False)
assert m.sqlite_witness(removal_case,historic,"remove")["job_state_after_release"]=="completed"
checks.append({"name":"removal_db_after_worker_release","status":"PASS"})
restoration_case=fake_db("db-restored","cancelled",True)
assert m.sqlite_witness(restoration_case,historic,"restore")["cancel_events"]==1
checks.append({"name":"restoration_db_cancelled","status":"PASS"})
wrong_case=fake_db("db-wrong-removal","cancelled",True)
refused("removal_db_with_cancel_event",lambda:m.sqlite_witness(wrong_case,historic,"remove"))

# A receipt-shaped positive assertion without the actual plan and evidence is insufficient.
fake_front=out/"fake-front";(fake_front/"runs/fake").mkdir(parents=True)
fake_receipt={"schema":"e02-r4-c96-matched-phase-receipt-v1","mode":"remove",
              "source_head":m.BASE_HEAD,"source_tree":m.BASE_TREE,
              "baseline_audit_sha256":m.BASE_AUDIT_SHA,"baseline_strict_sha256":m.BASE_STRICT_SHA,
              "qualification":{"outcome":"EXPECTED_SEMANTIC_RED"},"closure_ids":[]}
raw=(json.dumps(fake_receipt)+"\n").encode()
(fake_front/"runs/fake/r2-audit-result.json").write_bytes(raw)
class FakeR1:
    FRONT=fake_front
    no_symlink_ancestors=staticmethod(r1.no_symlink_ancestors)
refused("self_attested_removal_without_evidence",
        lambda:m.predecessor_admission(FakeR1(),"fake",m.sha(raw),baseline))

# Exercise the whole removal qualification, with fake readset admission and a tiny fake DB.
case,result_supervisor,phase_plan=fake_supervisor("whole-phase")
phase_plan["argv"]=[str(r1.PYTHON),"-B",str(r1.HARNESS),"--observe-pytest",r1.NODE]
result_supervisor["argv"]=[*result_supervisor["argv"][:3],*phase_plan["argv"]]
environment={"PYTHONDONTWRITEBYTECODE":"1","PYTHONPYCACHEPREFIX":str(case/"pycache"),
             "PYTEST_DISABLE_PLUGIN_AUTOLOAD":None,"PYTEST_ADDOPTS":None,
             "OMP_NUM_THREADS":"1","OPENBLAS_NUM_THREADS":"1","MKL_NUM_THREADS":"1","NUMEXPR_NUM_THREADS":"1"}
parent_obs={"pid":parent["pid"],"source":[m.BASE_HEAD,m.BASE_TREE],"source_after":[m.BASE_HEAD,m.BASE_TREE],
            "stage":"pytest_finished","pytest_not_yet_imported":True,"initial_private_pycache_empty":True,
            "sys_pycache_prefix":str(case/"pycache"),"argv":phase_plan["argv"][2:],
            "collected_node_ids_after_deselection":[r1.NODE],"pytest_exitstatus":1,
            "pytest":{"pid":parent["pid"],"importmode":"importlib","ini_addopts":["--strict-markers"],
                      "inipath":str(r1.PRODUCT/"pytest.ini")},
            "environment":environment,"executable":str(r1.PYTHON)}
child_obs=copy.deepcopy(historic)
child_obs.update(pid=child["pid"],ppid=parent["pid"],source=[m.BASE_HEAD,m.BASE_TREE],
                 stage="complete",environment=environment,executable=str(r1.PYTHON))
parent_dir=case/"evidence/parent";child_dir=case/"evidence/queued"
parent_dir.mkdir(parents=True);child_dir.mkdir(parents=True)
(parent_dir/"parent-process.json").write_text(json.dumps(parent_obs))
(child_dir/"observation.json").write_text(json.dumps(child_obs))
import xml.etree.ElementTree as ET
suite=ET.Element("testsuite")
testcase=ET.SubElement(suite,"testcase",{"name":r1.NODE.split("::")[-1]})
ET.SubElement(testcase,"failure").text='_assert_persisted_cancellation(observed)\nassert durable["state"] == "cancelled"'
ET.ElementTree(suite).write(case/"junit.xml")
db=case/"pytest-tmp/test_authenticated_cancellatio0/case/runtime-env/.polisyos/control_plane.sqlite3"
db.parent.mkdir(parents=True)
connection=sqlite3.connect(db)
connection.executescript(
    "create table control_jobs(job_id text, state text, lease_owner text, attempt integer, capability_manifest_ref text);"
    "create table control_job_events(job_id text, event_type text);"
    "create table control_outbox_events(job_id text, topic text);"
    "create table control_job_progress(job_id text);"
)
connection.execute("insert into control_jobs values(?,?,?,?,?)",("job_execution_admission","completed",None,
                   historic["running"]["attempt"],historic["running"]["manifest_ref"]))
connection.execute("insert into control_job_progress values(?)",("job_execution_admission",))
connection.execute("insert into control_job_events values(?,?)",("job_execution_admission","job_completed"))
connection.commit();connection.close()
class FakeSource:
    PRODUCT=r1.PRODUCT;PYTHON=r1.PYTHON;NODE=r1.NODE
    PARENT_REQUIRED=r1.PARENT_REQUIRED;CHILD_REQUIRED=r1.CHILD_REQUIRED
    @staticmethod
    def selected_git_tree(_head):return {}
    @staticmethod
    def qualify_readset(_obs,_directory,_index,_required):return {"synthetic":True}
assert m.qualify_phase(FakeSource(),case,phase_plan,result_supervisor,"remove")["outcome"]=="EXPECTED_SEMANTIC_RED"
checks.append({"name":"whole_removal_qualifier_synthetic_source_stub","status":"PASS"})
wrong=copy.deepcopy(child_obs);wrong["persisted"]["state"]="cancelled"
(child_dir/"observation.json").write_text(json.dumps(wrong))
refused("same_junit_markers_without_actual_red",
        lambda:m.qualify_phase(FakeSource(),case,phase_plan,result_supervisor,"remove"))
(child_dir/"observation.json").write_text(json.dumps(child_obs))
wrong=copy.deepcopy(result_supervisor);wrong["spawn_or_supervision_error"]="synthetic"
refused("whole_qualifier_supervisor_error",
        lambda:m.qualify_phase(FakeSource(),case,phase_plan,wrong,"remove"))
result={"scope":"actual R2 functions on synthetic records/SQLite plus retained historical observation; no product import or native run",
        "checks":checks,"denominator":len(checks),"runtime":"UNRUN","closure_ids":[]}
(HERE/"stdlib-results-r3.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
