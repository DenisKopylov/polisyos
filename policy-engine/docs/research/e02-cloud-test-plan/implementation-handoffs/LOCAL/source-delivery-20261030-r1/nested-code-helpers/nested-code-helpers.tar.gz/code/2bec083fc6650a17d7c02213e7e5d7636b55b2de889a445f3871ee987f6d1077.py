from types import FunctionType
from importlib import import_module
run = FunctionType(opaque_code, globals())
