loader_target = "ordinary value"
def __getattr__(name):
    if name == "loader":
        return loader_target
    raise AttributeError(name)
