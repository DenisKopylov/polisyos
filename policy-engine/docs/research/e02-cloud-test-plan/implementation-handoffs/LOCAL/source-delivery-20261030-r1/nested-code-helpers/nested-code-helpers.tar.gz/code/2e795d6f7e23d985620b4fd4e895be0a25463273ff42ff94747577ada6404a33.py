def _capture_fabric(self, *, record: AcquisitionActionRecord, spec: Mapping[str, Any]) -> AcquisitionOwnerArtifact | None:
    from polisyos.core.contracts.control import DataResolveRequest
    from polisyos.data_forge.read_api import catalog as catalog_read_api
    from polisyos.data_requirement import DataRequirementSpec
    from polisyos.fabric import project_data_requirement_to_catalog_needs
    from polisyos.fabric.retrieval.service import RetrievalService
    from polisyos.runtime.quality.substrate_registry import default_substrate_catalog_paths, require_active_catalog_source
    capture_fetches = _fabric_fetch_capture_enabled(spec)
    data_needs, requirement_projection = project_data_requirement_to_catalog_needs(compiled_requirement_spec=spec)
    if requirement_projection.get('disposition') == 'refused':
        return _fabric_catalog_projection_refusal_artifact(record=record, spec=spec, projection=requirement_projection, captured_at=self._captured_at)
    families = tuple((need.metric for need in data_needs))
    require_active_catalog_source(self._catalog_serving_source)
    curated_dir = self._repo_root / 'production_data'
    if capture_fetches and self._artifact_store is None:
        _LOGGER.warning('Fabric fetch capture refused: the owner-supplied artifact store is missing')
        return None
    paths = default_substrate_catalog_paths(self._repo_root)
    if self._dataset_catalog_factory is not None:
        graph = self._dataset_catalog_factory(paths.l1_dcat_path, paths.l1_dcat_path.parent)
    else:
        graph = catalog_read_api.DatasetCatalogGraph(paths.l1_dcat_path, paths.l1_dcat_path.parent, overlay_path=catalog_read_api.default_acquisition_overlay_path(self._repo_root))
    try:
        if self._catalog_serving_source is not None:
            from polisyos.runtime.quality.substrate_registry import require_catalog_serving_graph_binding
            require_catalog_serving_graph_binding(graph, self._catalog_serving_source)
        request = DataResolveRequest(data_needs=list(data_needs), mode='hybrid', allow_explore_fallback=False)
        captured_fetches: list[dict[str, Any]] = []
        if capture_fetches:
            try:
                if self._retrieval_service_factory is not None:
                    service = self._retrieval_service_factory(curated_dir, self._artifact_store, graph)
                else:
                    service = RetrievalService(curated_dir=curated_dir, artifact_store=self._artifact_store, dataset_catalog=graph)
                if not callable(getattr(service, 'resolve', None)) or not callable(getattr(service, 'execute_persisted_fetch_capture', None)):
                    raise ValueError('fabric_fetch_capture_service_invalid')
                service_store = getattr(service, 'artifact_store', None)
                if service_store is None:
                    raise ValueError('fabric_fetch_capture_store_missing')
                if service_store is not self._artifact_store:
                    raise ValueError('fabric_fetch_capture_store_identity_mismatch')
                response = service.resolve(request, run_profile=self._catalog_run_profile)
                if len(response.fetch_plans) != 1:
                    raise ValueError('fabric_fetch_capture_requires_one_plan')
                plan = response.fetch_plans[0]
                preflight_views: list[FetchCapturePreflightView] = []

                def validate_local_route(view: FetchCapturePreflightView) -> None:
                    if preflight_views:
                        raise ValueError('fabric_fetch_capture_preflight_repeated')
                    if view.plan_id != plan.plan_id or view.metric_id != plan.metric_id or view.connector_id != plan.connector_id or (view.profile_id != plan.profile_id):
                        raise ValueError('fabric_fetch_capture_plan_identity_mismatch')
                    if not isinstance(graph, catalog_read_api.DatasetCatalogGraph):
                        raise ValueError('fabric_fetch_capture_catalog_owner_missing')
                    runtime_binding = graph.bind_fetch_target(metric_id=plan.metric_id, connector_id=plan.connector_id, request_dataset_id=plan.dataset_id, profile_id=plan.profile_id, filters=plan.filters)
                    runtime_binding_fingerprint = canon.fingerprint(runtime_binding.model_dump(mode='json'), prefix=True, canon_spec=canon.CanonSpec(forbid_floats=False, exclude_none=False))
                    if runtime_binding_fingerprint != view.catalog_binding_fingerprint:
                        raise ValueError('fabric_fetch_capture_catalog_binding_mismatch')
                    _validate_local_fabric_capture_route(view=view, catalog=graph, approved_root=self._repo_root)
                    preflight_views.append(view)

                def validate_persisted_result(view: FetchCapturePostflightView) -> None:
                    if len(preflight_views) != 1:
                        raise ValueError('fabric_fetch_capture_preflight_missing')
                    preflight_view = preflight_views[0]
                    if view.plan_fingerprint != preflight_view.plan_fingerprint:
                        raise ValueError('fabric_fetch_capture_postflight_binding_mismatch')
                    if view.effective_config_fingerprint != preflight_view.effective_config_fingerprint or view.source_profile_fingerprint != preflight_view.source_profile_fingerprint:
                        raise ValueError('fabric_fetch_capture_postflight_config_binding_mismatch')
                    captured_fetches.extend(_captured_fabric_fetches(plan=plan, postflight=view, store=cast('ArtifactStore', service_store), catalog=graph))
                service.execute_persisted_fetch_capture(response.fetch_plans, preflight=validate_local_route, postflight=validate_persisted_result)
                if len(captured_fetches) != 1:
                    raise ValueError('fabric_fetch_capture_postflight_missing')
            except (AttributeError, OSError, RuntimeError, TypeError, ValueError) as exc:
                return None
        else:
            service = RetrievalService(curated_dir=curated_dir, artifact_store=self._artifact_store, dataset_catalog=graph)
            response = service.resolve(request, run_profile=self._catalog_run_profile)
    finally:
        close = getattr(graph, 'close', None)
        if callable(close):
            close()
    owner_response_kind = 'fabric_fetch_capture' if capture_fetches else 'fabric_catalog_resolution'
    owner_response = {'owner_response_kind': owner_response_kind, 'mode': response.mode, 'fetch_plan_count': len(response.fetch_plans), 'candidate_count': len(response.candidates), 'warnings': response.warnings, 'families': list(families), 'requirement_projection': requirement_projection, 'compiled_requirement_spec_hash': _stable_content_hash({key: value for key, value in spec.items() if key in DataRequirementSpec.model_fields}), 'data_needs': [need.model_dump(mode='json') for need in data_needs], 'candidate_only': True, 'fetch_plans': [plan.model_dump(mode='json') for plan in response.fetch_plans], 'candidates': [candidate.model_dump(mode='json') for candidate in response.candidates]}
    if capture_fetches:
        owner_response.update({'capture_mode': _FABRIC_CAPTURE_MODE_PERSISTED_PAYLOAD, 'captured_fetch_count': len(captured_fetches), 'captured_fetches': captured_fetches})
    payload = _fabric_response_payload(spec=spec, response=owner_response)
    return _artifact_from_owner_response(owner_component='fabric.retrieval', owner_endpoint='RetrievalService.resolve/execute_persisted_fetch_capture' if capture_fetches else 'RetrievalService.resolve', record=record, spec=spec, payload=payload, captured_at=self._captured_at, network_call=False, cost_usd=0.0)
