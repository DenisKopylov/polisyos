"""Versioned world-model bridge over Fabric, Data Forge, IR, Foundry, and SKG.

This module owns only the lifecycle envelope. It does not store facts, own
runtime state, execute mechanisms, or replace SKG priors; it binds existing
substrates into one content-addressed world version that downstream simulation
and value steps can name and resolve.
"""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, Protocol

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    ValidationError,
)

from polisyos.core.artifacts import (
    ArtifactID,
    ArtifactRef,
    ArtifactStore,
    CoreJSONArtifactStore,
    InputRef,
    PutOptions,
    SchemaInfo,
    artifact_ref_identity_key,
    input_ref_from_artifact_ref,
    matches_artifact_store_protocol,
)
from polisyos.core.canon import CanonSpec
from polisyos.core.contracts import (
    ExecPlanRef,
    ExecuteRequest,
    FoundryInputBindingsRef,
)
from polisyos.pdc import (
    WORLD_MODEL_RECORD_ARTIFACT_KIND,
    WORLD_MODEL_RECORD_SCHEMA_NAME,
    WORLD_MODEL_RECORD_SCHEMA_V2_VERSION,
    WORLD_MODEL_RECORD_SCHEMA_VERSION,
    BranchMode,
    DataForgeBindingRef,
    DeploymentUpdateRefs,
    FabricWorldRef,
    FoundryBindingRef,
    PolicySlotBinding,
    ResolvedSubstrateEntryRef,
    SimulationModelRef,
    SkgCausalPriorRef,
    SubstrateRegistryRef,
    WorldModelArtifactViews,
    WorldModelLimitations,
    WorldModelRecord,
    gy_content_hash,
    serialize_world_model_record_for_storage,
    world_model_record_content_hash_from_fields,
)
from polisyos.pdc import (
    SubstrateLayer as _SubstrateLayer,
)
from polisyos.pdc import (
    world_model_record_content_hash as _world_model_record_content_hash,
)
from polisyos.runtime.quality.substrate_registry import (
    SUBSTRATE_REGISTRY_ARTIFACT_KIND,
    SubstrateRegistry,
    SubstrateRegistryEntry,
    SubstrateRegistryError,
    load_substrate_registry,
)

if TYPE_CHECKING:
    from polisyos.core.contracts import DataSnapshot, FoundryInputBindingRule, StateSnapshotRef
    from polisyos.ir import ModelSpec
    from polisyos.ir.kernel import SlotRegistry
    from polisyos.runtime.quality.intervention_atom_binding import InterventionAtomBinding

_DATA_FORGE_SNAPSHOT_BINDING_SCHEMA_VERSION = "policyos.runtime.data_forge_snapshot_binding.v1"

# Compatibility exports preserve the historical Runtime module surface while
# PDC owns the exact objects.
SubstrateLayer = _SubstrateLayer
world_model_record_content_hash = _world_model_record_content_hash


class WorldModelRecordError(ValueError):
    """Fail-closed error raised when world substrates cannot form one version."""

    def __init__(self, code: str, message: str | None = None) -> None:
        self.code = code
        super().__init__(f"{code}: {message or code}")


def derive_candidate_scenario_world_model_record(
    base_record: WorldModelRecord,
    *,
    ncm_artifact_ref: ArtifactRef,
    declaration_content_hash: str,
    substrate_registry_view_ref: ArtifactRef | None = None,
) -> WorldModelRecord:
    """Derive one limited WMR that names a declared candidate NCM view.

    This pure projection preserves the supplied WMR's substrates and status.
    It does not write the world, acquire data, or grant empirical authority.
    The selected view is the full owner-issued CAS reference, including its
    manifest profile selector; the domain-level NCM IDs remain a projection.
    """
    if type(base_record) is not WorldModelRecord:
        raise WorldModelRecordError("candidate_scenario_base_wmr_untyped")
    if base_record.authority_status != "limited":
        raise WorldModelRecordError("candidate_scenario_wmr_basis_not_limited")
    if not isinstance(ncm_artifact_ref, ArtifactRef):
        raise WorldModelRecordError("candidate_scenario_ncm_view_invalid")

    try:
        selected_ncm_ref = ArtifactRef(**ncm_artifact_ref.model_dump(mode="python"))
        canonical_declaration_hash = str(ArtifactID(declaration_content_hash))
        if canonical_declaration_hash != declaration_content_hash:
            raise ValueError("candidate declaration hash is not canonical")
    except (TypeError, ValueError) as exc:
        raise WorldModelRecordError("candidate_scenario_ncm_view_invalid", str(exc)) from exc
    if selected_ncm_ref.kind != "ir.ncm_spec" or selected_ncm_ref.media_type != "application/json":
        raise WorldModelRecordError(
            "candidate_scenario_ncm_view_invalid",
            "expected an owner-issued JSON ir.ncm_spec ref",
        )

    try:
        for prior_id in base_record.simulation_model_ref.ncm_refs:
            if str(ArtifactID(prior_id)) != prior_id:
                raise ValueError("WMR basis NCM ref is not canonical")
    except (TypeError, ValueError) as exc:
        raise WorldModelRecordError(
            "candidate_scenario_wmr_basis_ncm_ref_not_cas", str(exc)
        ) from exc

    try:
        base_views = world_model_artifact_views(base_record)
    except (TypeError, ValueError) as exc:
        raise WorldModelRecordError("candidate_scenario_wmr_basis_views_invalid", str(exc)) from exc

    selected_registry_view: ArtifactRef | None = None
    if substrate_registry_view_ref is not None:
        try:
            selected_registry_view = ArtifactRef(
                **substrate_registry_view_ref.model_dump(mode="python")
            )
            ArtifactID.model_validate(str(selected_registry_view.artifact_id))
        except (AttributeError, TypeError, ValueError) as exc:
            raise WorldModelRecordError(
                "candidate_scenario_substrate_registry_view_invalid", str(exc)
            ) from exc
        if (
            selected_registry_view.kind != SUBSTRATE_REGISTRY_ARTIFACT_KIND
            or selected_registry_view.media_type != "application/json"
        ):
            raise WorldModelRecordError(
                "candidate_scenario_substrate_registry_view_invalid",
                "expected an owner-selected JSON substrate-registry ref",
            )
        existing_registry_view = base_views.substrate_registry_ref
        if existing_registry_view is not None and artifact_ref_identity_key(
            existing_registry_view
        ) != artifact_ref_identity_key(selected_registry_view):
            raise WorldModelRecordError("candidate_scenario_substrate_registry_view_conflict")

    selected_views: list[ArtifactRef] = []
    seen_view_identities: set[tuple[str, str, str, str | None]] = set()
    for ref in (*base_views.ncm_refs, selected_ncm_ref):
        identity = artifact_ref_identity_key(ref)
        if identity in seen_view_identities:
            continue
        selected_views.append(ref)
        seen_view_identities.add(identity)

    try:
        artifact_views = WorldModelArtifactViews.model_validate(
            {
                **base_views.model_dump(mode="python"),
                **(
                    {"substrate_registry_ref": selected_registry_view}
                    if selected_registry_view is not None
                    else {}
                ),
                "ncm_refs": tuple(selected_views),
            }
        )
    except (TypeError, ValueError) as exc:
        raise WorldModelRecordError("candidate_scenario_ncm_view_invalid", str(exc)) from exc

    model_ref = base_record.simulation_model_ref.model_copy(
        update={
            "ncm_refs": tuple(str(ref.artifact_id) for ref in selected_views),
            "assumptions": (
                *base_record.simulation_model_ref.assumptions,
                {
                    "assumption": "declared synthetic candidate model",
                    "declaration_content_hash": declaration_content_hash,
                    "status": "candidate_only_not_empirically_grounded",
                },
            ),
            "fidelity_level": "declared_candidate_scenario",
            "calibrated": False,
            "calibration_ref": None,
        }
    )
    registry_ref = base_record.substrate_registry_ref
    fabric_world_ref = base_record.fabric_world_ref
    data_forge_binding_ref = base_record.data_forge_binding_ref
    if selected_registry_view is not None:
        previous_registry_locator = registry_ref.registry_artifact_ref
        selected_registry_id = str(selected_registry_view.artifact_id)
        registry_ref = registry_ref.model_copy(
            update={"registry_artifact_ref": selected_registry_id}
        )
        # The boundary producer can use the same legacy registry locator for
        # these provenance fields. Rebind only exact aliases; preserve unrelated
        # provenance references and never rewrite the supplied v1 record.
        if (
            previous_registry_locator is not None
            and fabric_world_ref.provenance_manifest_ref == previous_registry_locator
        ):
            fabric_world_ref = fabric_world_ref.model_copy(
                update={"provenance_manifest_ref": selected_registry_id}
            )
        if (
            previous_registry_locator is not None
            and data_forge_binding_ref.provenance_manifest_ref == previous_registry_locator
        ):
            data_forge_binding_ref = data_forge_binding_ref.model_copy(
                update={"provenance_manifest_ref": selected_registry_id}
            )
    draft = base_record.model_copy(
        update={
            "schema_version": WORLD_MODEL_RECORD_SCHEMA_V2_VERSION,
            "artifact_views": artifact_views,
            "producer_ref": (
                "polisyos.runtime.quality.world_model_record."
                "derive_candidate_scenario_world_model_record"
            ),
            "authority_status": "limited",
            "substrate_registry_ref": registry_ref,
            "fabric_world_ref": fabric_world_ref,
            "data_forge_binding_ref": data_forge_binding_ref,
            "simulation_model_ref": model_ref,
            "world_model_record_id": "world_model_record_0000000000000000",
            "content_hash": "sha256:" + "0" * 64,
        }
    )
    content_hash = world_model_record_content_hash(draft)
    payload = draft.model_dump(mode="json")
    payload.update(
        {
            "world_model_record_id": (
                f"world_model_record_{content_hash.removeprefix('sha256:')[:16]}"
            ),
            "content_hash": content_hash,
        }
    )
    try:
        return WorldModelRecord.model_validate(payload)
    except (TypeError, ValueError) as exc:
        raise WorldModelRecordError("candidate_scenario_wmr_invalid", str(exc)) from exc


class _StrictModel(BaseModel):
    """Strict immutable base model for Runtime-owned consumer DTOs."""

    model_config = ConfigDict(extra="forbid", frozen=True)


class WorldModelSimulationInput(_StrictModel):
    """Consumer DTO for running Foundry execution against a world record."""

    world_model_record_id: str
    world_model_record_content_hash: str
    schema_version: str
    branch_mode: BranchMode
    input_bindings_ref: str = Field(..., pattern=r"^sha256:[0-9a-f]{64}$")
    bound_state_snapshot_ref: str = Field(..., pattern=r"^sha256:[0-9a-f]{64}$")
    registry_bundle_ref: str = Field(..., pattern=r"^sha256:[0-9a-f]{64}$")

    def to_execute_request(self, *, exec_plan_ref: ExecPlanRef) -> ExecuteRequest:
        """Build a Foundry ``ExecuteRequest`` using this record's bound state."""

        return ExecuteRequest(
            exec_plan_ref=exec_plan_ref,
            input_bindings_ref=FoundryInputBindingsRef(artifact_id=self.input_bindings_ref),
            registry_bundle_ref=ArtifactRef(
                artifact_id=self.registry_bundle_ref,
                kind="core.registry_bundle",
                media_type="application/json",
            ),
            notes=[
                f"world_model_record_id:{self.world_model_record_id}",
                f"world_model_record_content_hash:{self.world_model_record_content_hash}",
            ],
        )


class ResolvedWorldModelAtomBinding(_StrictModel):
    """Resolved N2 atom hook with concrete world version and state paths."""

    world_model_record_id: str
    world_model_record_content_hash: str
    schema_version: str
    branch_mode: BranchMode
    target_slot_bindings: tuple[PolicySlotBinding, ...]
    input_bindings_ref: str = Field(..., pattern=r"^sha256:[0-9a-f]{64}$")
    bound_state_snapshot_ref: str = Field(..., pattern=r"^sha256:[0-9a-f]{64}$")


@dataclass(frozen=True)
class WorldModelBuildResult:
    """Collect the record and real bound Foundry state emitted by the builder."""

    record: WorldModelRecord
    record_ref: ArtifactRef
    input_bindings_ref: FoundryInputBindingsRef
    input_binding_report_ref: ArtifactRef
    bound_state_snapshot_ref: StateSnapshotRef
    bound_global_state: object
    data_snapshot_ref: ArtifactRef


@dataclass(frozen=True)
class _ParsedSkgSnapshotRef:
    """Parsed local SKG snapshot locator resolved by the SKG owner."""

    db_path: Path
    version_id: int


@dataclass(frozen=True)
class _FabricWorldContentSignal:
    """Stable content signal from owner-resolved Fabric world query results."""

    digest: str
    row_count: int


class _FabricQueryFrame(Protocol):
    """Minimal DataFrame surface returned by Fabric world queries."""

    columns: Sequence[object]

    def to_dict(self, orient: str = "dict") -> object:
        """Return rows in a pandas-compatible dictionary orientation."""
        ...


def _reject_selected_manifest_views_for_wmr_v1(
    refs: Mapping[str, ArtifactRef | None],
) -> None:
    """Refuse selected CAS views before WMR v1 narrows typed refs to bare IDs."""

    selected = sorted(
        label
        for label, ref in refs.items()
        if ref is not None and ref.manifest_profile_sha256 is not None
    )
    if selected:
        raise WorldModelRecordError(
            "selected_manifest_view_not_expressible_by_wmr_v1",
            ", ".join(selected),
        )


def _view_ref_for_id(
    artifact_id: str,
    *,
    kind: str,
) -> ArtifactRef:
    """Construct the explicitly historical default-view ref for WMR v1."""

    return ArtifactRef(
        artifact_id=artifact_id,
        kind=kind,
        media_type="application/json",
    )


def world_model_artifact_views(record: WorldModelRecord) -> WorldModelArtifactViews:
    """Return revalidated selected views, reconstructing defaults only for v1."""

    validated = WorldModelRecord.model_validate(record.model_dump(mode="json"))
    if validated.schema_version == WORLD_MODEL_RECORD_SCHEMA_V2_VERSION:
        if validated.artifact_views is None:
            raise WorldModelRecordError("world_model_v2_artifact_views_missing")
        return validated.artifact_views
    if validated.schema_version != WORLD_MODEL_RECORD_SCHEMA_VERSION:
        raise WorldModelRecordError("world_model_record_schema_unsupported")
    world = validated
    simulation = world.simulation_model_ref
    foundry = world.foundry_binding_ref
    substrate_id = world.substrate_registry_ref.registry_artifact_ref
    return WorldModelArtifactViews(
        data_snapshot_ref=_view_ref_for_id(
            simulation.data_snapshot_ref,
            kind="fabric.data_snapshot",
        ),
        registry_bundle_ref=_view_ref_for_id(
            simulation.registry_bundle_ref,
            kind="core.registry_bundle",
        ),
        model_spec_ref=_view_ref_for_id(simulation.model_spec_ref, kind="ir.model_spec"),
        input_bindings_ref=_view_ref_for_id(
            foundry.input_bindings_ref,
            kind="foundry.input_bindings",
        ),
        bound_state_snapshot_ref=_view_ref_for_id(
            foundry.bound_state_snapshot_ref,
            kind="foundry.state_snapshot",
        ),
        input_binding_report_ref=_view_ref_for_id(
            foundry.mapping_rules_ref,
            kind="foundry.input_binding_report",
        ),
        substrate_registry_ref=(
            _view_ref_for_id(
                substrate_id,
                kind=SUBSTRATE_REGISTRY_ARTIFACT_KIND,
            )
            if substrate_id is not None and substrate_id.startswith("sha256:")
            else None
        ),
        program_graph_refs=tuple(
            _view_ref_for_id(value, kind="foundry.program_graph")
            for value in simulation.program_graph_refs
        ),
        ncm_refs=tuple(
            _view_ref_for_id(value, kind="ir.ncm_spec") for value in simulation.ncm_refs
        ),
    )


def build_world_model_record(
    store: ArtifactStore,
    *,
    fabric_world_ref: FabricWorldRef,
    data_forge_snapshot_binding_path: str | Path,
    data_snapshot_ref: ArtifactRef,
    model_spec: ModelSpec,
    skg_causal_prior_ref: SkgCausalPriorRef,
    substrate_registry: SubstrateRegistry,
    region_or_jurisdiction: str,
    population_scope: str,
    policy_domain: str,
    valid_time_scope: str,
    tx_time_scope: str,
    resolution: str,
    branch_mode: BranchMode,
    policy_slot_ids: Sequence[str],
    producer_ref: str,
    data_forge_role: str = "academic",
    required_substrate_sources: Sequence[str] = (),
    required_substrate_families: Sequence[str] = (),
    substrate_registry_artifact_ref: ArtifactRef | str | None = None,
    registry_bundle_artifact_ref: ArtifactRef | None = None,
    _loaded_substrate_registry: SubstrateRegistry | None = None,
    foundry_binding_rules: Sequence[FoundryInputBindingRule] | None = None,
    mechanism_refs: Sequence[str] = (),
    gcm_refs: Sequence[str] = (),
    ncm_refs: Sequence[str] = (),
    program_graph_refs: Sequence[str] = (),
    program_graph_view_refs: Sequence[ArtifactRef] | None = None,
    ncm_view_refs: Sequence[ArtifactRef] | None = None,
    limitations: WorldModelLimitations | None = None,
    candidate_only: bool = False,
    deployment_update_refs: DeploymentUpdateRefs | None = None,
) -> WorldModelBuildResult:
    """Build and persist one versioned world record from existing substrates.

    Args:
        store: CAS store containing the Fabric ``DataSnapshot`` and receiving
            the Foundry bindings plus record artifact.
        fabric_world_ref: Fabric world snapshot/branch/as-of reference.
        data_forge_snapshot_binding_path: Path to the Data Forge binding file
            emitted by ``data_forge.kernel.snapshot``.
        data_snapshot_ref: CAS ref to the Fabric ``DataSnapshot`` consumed by
            Foundry.
        model_spec: Existing IR simulation contract for this world.
        skg_causal_prior_ref: SKG/G2 prior and transport trace reference.
        substrate_registry: S0 production-data substrate registry this world
            version resolves against.
        region_or_jurisdiction: Jurisdiction this world version represents.
        population_scope: Population this world version represents.
        policy_domain: Policy domain of the world version.
        valid_time_scope: Valid-time scope carried into bitemporal consumers.
        tx_time_scope: Transaction-time scope carried into audit consumers.
        resolution: World-model resolution, such as ``firm_month``.
        branch_mode: Observed/scenario/deployment-update branch semantics.
        policy_slot_ids: Slots that candidate atoms may target in this world.
        producer_ref: Producer reference for the lifecycle bridge.
        data_forge_role: Binding row role to select from the Data Forge report.
        required_substrate_sources: Source ids that must resolve in S0.
        required_substrate_families: Family ids that must resolve in S0.
        substrate_registry_artifact_ref: Optional CAS ref to the persisted S0
            registry artifact.
        registry_bundle_artifact_ref: Optional exact registry bundle view;
            selected manifest metadata is retained in WMRv2.
        _loaded_substrate_registry: Internal S1 handoff that avoids rereading
            a registry already loaded and validated from this CAS.
        foundry_binding_rules: Optional explicit Foundry input binding rules.
        mechanism_refs: Existing mechanism refs to name; mechanisms remain
            owned by Foundry/IR registries.
        gcm_refs: Existing GCM refs to name.
        ncm_refs: Existing NCM refs to name.
        program_graph_refs: Existing program graph refs to name.
        program_graph_view_refs: Exact typed CAS views paired in order with
            ``program_graph_refs``; supplying them selects WMRv2.
        ncm_view_refs: Exact typed CAS views paired in order with ``ncm_refs``;
            supplying them selects WMRv2.
        limitations: Explicit limitation record, if already known.
        candidate_only: Mark this bound substrate as candidate-band only. The
            status is ``limited`` and requires at least one typed
            ``admissibility_blocker``; this does not confer authority.
        deployment_update_refs: Phase-6 forward hooks, not write-back logic.

    Raises:
        WorldModelRecordError: If any required substrate is missing or versions
            do not content-correspond.

    Returns:
        ``WorldModelBuildResult`` containing the persisted record and the real
        bound ``GlobalState`` emitted by Foundry input bindings.
    """

    if not model_spec.registry_bundle_ref:
        raise WorldModelRecordError(
            "model_spec_registry_bundle_missing",
            "ModelSpec must name the registry bundle used by Foundry binding",
        )
    if not matches_artifact_store_protocol(store, CoreJSONArtifactStore):
        raise WorldModelRecordError(
            "world_model_store_core_json_reader_unsupported",
            "WMR construction requires the selected raw-manifest reader capability",
        )
    effective_limitations = limitations or WorldModelLimitations()
    if candidate_only and not effective_limitations.admissibility_blockers:
        raise WorldModelRecordError("candidate_only_wmr_requires_admissibility_blocker")
    data_snapshot = _load_data_snapshot(store, data_snapshot_ref)
    data_snapshot_id = _data_snapshot_version_id(data_snapshot)
    if not data_snapshot_id:
        raise WorldModelRecordError(
            "data_snapshot_version_missing",
            "DataSnapshot must carry stats.snapshot_id or notes snapshot_id:<id>",
        )
    data_forge_binding_ref = _load_data_forge_binding_ref(
        data_forge_snapshot_binding_path,
        role=data_forge_role,
    )
    from polisyos.runtime.quality.data_snapshot_lineage import (
        DataSnapshotSourceRowNotEstablishedError,
        validate_data_snapshot_owner_lineage,
    )

    try:
        lineage_result = validate_data_snapshot_owner_lineage(
            store,
            data_snapshot_ref,
            data_snapshot,
            binding_lineage_refs=data_forge_binding_ref.lineage_refs,
            candidate_only=candidate_only,
        )
        if lineage_result.required_admissibility_blockers:
            if not candidate_only:
                raise DataSnapshotSourceRowNotEstablishedError()
            effective_limitations = effective_limitations.model_copy(
                update={
                    "admissibility_blockers": tuple(
                        dict.fromkeys(
                            (
                                *effective_limitations.admissibility_blockers,
                                *lineage_result.required_admissibility_blockers,
                            )
                        )
                    )
                }
            )
    except (OSError, TypeError, ValueError, RuntimeError) as exc:
        raise WorldModelRecordError(
            "data_snapshot_owner_lineage_invalid",
            str(exc),
        ) from exc
    resolved_fabric_world_ref = _resolve_fabric_world_ref(fabric_world_ref)
    _resolve_skg_causal_prior_ref(skg_causal_prior_ref)
    substrate_registry_input_ref = (
        substrate_registry_artifact_ref
        if isinstance(substrate_registry_artifact_ref, ArtifactRef)
        else None
    )
    substrate_registry_ref = _resolve_substrate_registry_ref(
        store,
        substrate_registry,
        required_sources=required_substrate_sources,
        required_families=required_substrate_families,
        registry_artifact_ref=substrate_registry_artifact_ref,
        loaded_registry=_loaded_substrate_registry,
    )
    _assert_same_world_version(
        fabric_world_ref=resolved_fabric_world_ref,
        data_forge_binding_ref=data_forge_binding_ref,
        model_spec=model_spec,
        data_snapshot_ref=data_snapshot_ref,
        data_snapshot_id=data_snapshot_id,
        skg_causal_prior_ref=skg_causal_prior_ref,
        allow_candidate_skg_source_mismatch=(
            candidate_only
            and "causal_coupling_not_established" in effective_limitations.admissibility_blockers
        ),
    )

    registry_bundle_ref = registry_bundle_artifact_ref or ArtifactRef(
        artifact_id=model_spec.registry_bundle_ref,
        kind="core.registry_bundle",
        media_type="application/json",
    )
    if str(registry_bundle_ref.artifact_id) != model_spec.registry_bundle_ref:
        raise WorldModelRecordError("world_model_registry_bundle_ref_id_mismatch")
    from polisyos.core.registry import load_registry_bundle_content
    from polisyos.foundry.data_plane import build_input_bindings, load_input_bindings
    from polisyos.foundry.execute.executor import load_state_snapshot

    registry_content = load_registry_bundle_content(store, registry_bundle_ref)
    if registry_content.bundle_ref != registry_bundle_ref:
        raise WorldModelRecordError("world_model_registry_bundle_view_not_preserved")
    policy_slot_map = _policy_slot_map(
        registry_content.slot_registry,
        policy_slot_ids=policy_slot_ids,
    )
    input_bindings = build_input_bindings(
        store,
        data_snapshot_ref=data_snapshot_ref,
        registry_bundle_ref=registry_bundle_ref,
        rules=list(foundry_binding_rules or []),
        notes=[f"world_model_record_snapshot_id:{data_snapshot_id}"],
    )
    persisted_bindings = load_input_bindings(store, input_bindings.input_bindings_ref)
    if str(persisted_bindings.data_snapshot_ref.artifact_id) != str(data_snapshot_ref.artifact_id):
        raise WorldModelRecordError(
            "world_substrate_version_mismatch",
            "Foundry input bindings do not point at the requested DataSnapshot",
        )

    model_spec_ref = store.put_json(
        model_spec,
        PutOptions(
            kind="ir.model_spec",
            media_type="application/json",
            schema=SchemaInfo(
                name="polisyos.ir.model_layer.ModelSpec",
                version=model_spec.schema_version,
            ),
        ),
    )
    if substrate_registry_ref.registry_artifact_ref is not None:
        substrate_registry_view_ref = substrate_registry_input_ref or ArtifactRef(
            artifact_id=substrate_registry_ref.registry_artifact_ref,
            kind=SUBSTRATE_REGISTRY_ARTIFACT_KIND,
            media_type="application/json",
        )
    else:
        substrate_registry_view_ref = None
    selected_graph_views = tuple(program_graph_view_refs or ())
    selected_ncm_views = tuple(ncm_view_refs or ())
    graph_views = selected_graph_views or tuple(
        _view_ref_for_id(value, kind="foundry.program_graph") for value in program_graph_refs
    )
    ncm_views = selected_ncm_views or tuple(
        _view_ref_for_id(value, kind="ir.ncm_spec") for value in ncm_refs
    )
    if tuple(str(ref.artifact_id) for ref in graph_views) != tuple(program_graph_refs):
        raise WorldModelRecordError("world_model_program_graph_view_id_mismatch")
    if tuple(str(ref.artifact_id) for ref in ncm_views) != tuple(ncm_refs):
        raise WorldModelRecordError("world_model_ncm_view_id_mismatch")
    view_refs = {
        "input.data_snapshot_ref": data_snapshot_ref,
        "input.registry_bundle_ref": registry_content.bundle_ref,
        "artifact.model_spec_ref": model_spec_ref,
        "artifact.input_bindings_ref": input_bindings.input_bindings_ref,
        "artifact.bound_state_snapshot_ref": input_bindings.bound_state_snapshot_ref,
        "artifact.input_binding_report_ref": input_bindings.input_binding_report_ref,
        "input.substrate_registry_ref": substrate_registry_view_ref,
        **{f"input.program_graph_refs.{index}": ref for index, ref in enumerate(graph_views)},
        **{f"input.ncm_refs.{index}": ref for index, ref in enumerate(ncm_views)},
    }
    use_v2_views = (
        program_graph_view_refs is not None
        or ncm_view_refs is not None
        or any(
            ref is not None and ref.manifest_profile_sha256 is not None
            for ref in view_refs.values()
        )
    )
    if use_v2_views:
        for ref in view_refs.values():
            if ref is None:
                continue
            try:
                if not store.verify(ref).ok:
                    raise ValueError("artifact verification failed")
                store.get_manifest(ref)
            except Exception as exc:
                raise WorldModelRecordError(
                    "world_model_selected_artifact_view_unresolved"
                ) from exc
    else:
        _reject_selected_manifest_views_for_wmr_v1(view_refs)
    artifact_views = (
        WorldModelArtifactViews(
            data_snapshot_ref=data_snapshot_ref,
            registry_bundle_ref=registry_content.bundle_ref,
            model_spec_ref=model_spec_ref,
            input_bindings_ref=input_bindings.input_bindings_ref,
            bound_state_snapshot_ref=input_bindings.bound_state_snapshot_ref,
            input_binding_report_ref=input_bindings.input_binding_report_ref,
            substrate_registry_ref=substrate_registry_view_ref,
            program_graph_refs=graph_views,
            ncm_refs=ncm_views,
        )
        if use_v2_views
        else None
    )
    state_slot_digest = gy_content_hash(
        {
            "bound_state_snapshot_ref": str(input_bindings.bound_state_snapshot_ref.artifact_id),
            "policy_slot_map": [binding.model_dump(mode="json") for binding in policy_slot_map],
        }
    )
    fields: dict[str, Any] = {
        "schema_version": (
            WORLD_MODEL_RECORD_SCHEMA_V2_VERSION
            if use_v2_views
            else WORLD_MODEL_RECORD_SCHEMA_VERSION
        ),
        "authority_status": "limited" if candidate_only else "bound",
        "producer_ref": producer_ref,
        "region_or_jurisdiction": region_or_jurisdiction,
        "population_scope": population_scope,
        "policy_domain": policy_domain,
        "valid_time_scope": valid_time_scope,
        "tx_time_scope": tx_time_scope,
        "resolution": resolution,
        "branch_mode": branch_mode,
        "fabric_world_ref": resolved_fabric_world_ref,
        "data_forge_binding_ref": data_forge_binding_ref,
        "simulation_model_ref": SimulationModelRef(
            model_spec_ref=str(model_spec_ref.artifact_id),
            model_spec_hash=gy_content_hash(model_spec.model_dump(mode="json")),
            model_id=model_spec.model_id,
            data_snapshot_ref=model_spec.data_snapshot_ref,
            registry_bundle_ref=str(registry_bundle_ref.artifact_id),
            mechanism_refs=tuple(mechanism_refs),
            gcm_refs=tuple(gcm_refs),
            ncm_refs=tuple(ncm_refs),
            program_graph_refs=tuple(program_graph_refs),
            assumptions=tuple(
                assumption.model_dump(mode="json") for assumption in model_spec.assumptions
            ),
            fidelity_level=str(model_spec.fidelity_level.value),
            calibration_ref=model_spec.calibration_ref,
            calibrated=model_spec.calibrated,
        ),
        "foundry_binding_ref": FoundryBindingRef(
            input_bindings_ref=str(input_bindings.input_bindings_ref.artifact_id),
            bound_state_snapshot_ref=str(input_bindings.bound_state_snapshot_ref.artifact_id),
            mapping_rules_ref=str(input_bindings.input_binding_report_ref.artifact_id),
            state_slot_digest=state_slot_digest,
        ),
        "skg_causal_prior_ref": skg_causal_prior_ref,
        "substrate_registry_ref": substrate_registry_ref,
        "policy_slot_map": tuple(policy_slot_map),
        "limitations": effective_limitations,
        "deployment_update_refs": deployment_update_refs or DeploymentUpdateRefs(),
    }
    if artifact_views is not None:
        fields["artifact_views"] = artifact_views
    content_hash = world_model_record_content_hash_from_fields(fields)
    record = WorldModelRecord(
        world_model_record_id=f"world_model_record_{content_hash.removeprefix('sha256:')[:16]}",
        content_hash=content_hash,
        **fields,
    )
    record_inputs = [
        input_ref_from_artifact_ref(data_snapshot_ref, role="input.data_snapshot_ref"),
        input_ref_from_artifact_ref(registry_content.bundle_ref, role="input.registry_bundle_ref"),
        input_ref_from_artifact_ref(model_spec_ref, role="input.model_spec_ref"),
        input_ref_from_artifact_ref(
            input_bindings.input_bindings_ref,
            role="artifact.input_bindings_ref",
        ),
        input_ref_from_artifact_ref(
            input_bindings.bound_state_snapshot_ref,
            role="artifact.bound_state_snapshot_ref",
        ),
        input_ref_from_artifact_ref(
            input_bindings.input_binding_report_ref,
            role="artifact.input_binding_report_ref",
        ),
    ]
    if substrate_registry_view_ref is not None:
        record_inputs.append(
            input_ref_from_artifact_ref(
                substrate_registry_view_ref,
                role="input.substrate_registry_ref",
            )
        )
    if artifact_views is not None:
        record_inputs.extend(
            input_ref_from_artifact_ref(ref, role=f"input.program_graph_refs.{index}")
            for index, ref in enumerate(artifact_views.program_graph_refs)
        )
        record_inputs.extend(
            input_ref_from_artifact_ref(ref, role=f"input.ncm_refs.{index}")
            for index, ref in enumerate(artifact_views.ncm_refs)
        )
    record_ref = persist_world_model_record(
        store,
        record,
        inputs=record_inputs,
    )
    bound_state = load_state_snapshot(store, snapshot_ref=input_bindings.bound_state_snapshot_ref)
    return WorldModelBuildResult(
        record=record,
        record_ref=record_ref,
        input_bindings_ref=input_bindings.input_bindings_ref,
        input_binding_report_ref=input_bindings.input_binding_report_ref,
        bound_state_snapshot_ref=input_bindings.bound_state_snapshot_ref,
        bound_global_state=bound_state,
        data_snapshot_ref=data_snapshot_ref,
    )


def consume_world_model_record_for_simulation(
    record: WorldModelRecord,
) -> WorldModelSimulationInput:
    """Return the Foundry execution boundary resolved from a world record."""

    validated = WorldModelRecord.model_validate(record.model_dump(mode="json"))
    return WorldModelSimulationInput(
        world_model_record_id=validated.world_model_record_id,
        world_model_record_content_hash=validated.content_hash,
        schema_version=validated.schema_version,
        branch_mode=validated.branch_mode,
        input_bindings_ref=validated.foundry_binding_ref.input_bindings_ref,
        bound_state_snapshot_ref=validated.foundry_binding_ref.bound_state_snapshot_ref,
        registry_bundle_ref=validated.simulation_model_ref.registry_bundle_ref,
    )


def resolve_intervention_atom_world_binding(
    atom: InterventionAtomBinding,
    record: WorldModelRecord,
) -> ResolvedWorldModelAtomBinding:
    """Resolve an N2 atom's world hook and target slots against a concrete record.

    Args:
        atom: ``InterventionAtomBinding`` carrying the forward
            ``world_model_record_ref`` and target slots.
        record: Concrete world record candidate to bind against.

    Raises:
        WorldModelRecordError: If the atom references a different world version
            or any target slot lacks a state path in the policy-slot map.

    Returns:
        Resolved target slot bindings and Foundry state refs.
    """

    from polisyos.runtime.quality.intervention_atom_binding import (
        InterventionAtomBinding,
    )

    try:
        if not isinstance(atom, InterventionAtomBinding):
            raise TypeError("intervention_atom_binding_contract_required")
        validated_atom = InterventionAtomBinding.model_validate(atom.model_dump(mode="python"))
    except (AttributeError, TypeError, ValidationError) as exc:
        raise WorldModelRecordError(
            "intervention_atom_binding_invalid",
            str(exc),
        ) from exc
    if not validated_atom.target_world_slots:
        raise WorldModelRecordError(
            "world_slot_binding_missing",
            "an atom must resolve at least one target world slot",
        )
    validated = WorldModelRecord.model_validate(record.model_dump(mode="json"))
    accepted_refs = {
        validated.world_model_record_id,
        validated.content_hash,
    }
    if validated_atom.world_model_record_ref not in accepted_refs:
        raise WorldModelRecordError(
            "world_model_record_ref_unresolved",
            (
                f"{validated_atom.world_model_record_ref} does not name "
                f"{validated.world_model_record_id}"
            ),
        )
    resolved: list[PolicySlotBinding] = []
    for slot_id in validated_atom.target_world_slots:
        binding = validated.slot_binding(slot_id)
        if binding is None or not binding.state_path:
            raise WorldModelRecordError(
                "world_slot_state_path_missing",
                f"slot {slot_id!r} has no state_path in WorldModelRecord",
            )
        resolved.append(binding)
    return ResolvedWorldModelAtomBinding(
        world_model_record_id=validated.world_model_record_id,
        world_model_record_content_hash=validated.content_hash,
        schema_version=validated.schema_version,
        branch_mode=validated.branch_mode,
        target_slot_bindings=tuple(resolved),
        input_bindings_ref=validated.foundry_binding_ref.input_bindings_ref,
        bound_state_snapshot_ref=validated.foundry_binding_ref.bound_state_snapshot_ref,
    )


def persist_world_model_record(
    store: ArtifactStore,
    record: WorldModelRecord,
    *,
    inputs: Sequence[InputRef] | None = None,
) -> ArtifactRef:
    """Persist a ``WorldModelRecord`` as a typed CAS artifact."""

    validated = WorldModelRecord.model_validate(record.model_dump(mode="json"))
    manifest_inputs = (
        [
            InputRef(
                artifact_id=artifact_id,
                role=role,
                manifest_profile_sha256=manifest_profile_sha256,
            )
            for artifact_id, role, manifest_profile_sha256 in _world_model_record_manifest_inputs(
                validated
            )
        ]
        if inputs is None
        else list(inputs)
    )
    return store.put_json(
        serialize_world_model_record_for_storage(validated),
        PutOptions(
            kind=WORLD_MODEL_RECORD_ARTIFACT_KIND,
            media_type="application/json",
            schema=SchemaInfo(
                name=WORLD_MODEL_RECORD_SCHEMA_NAME,
                version=validated.schema_version,
            ),
            inputs=manifest_inputs,
        ),
        canon_spec=CanonSpec(forbid_floats=False),
    )


def load_world_model_record(
    store: CoreJSONArtifactStore, ref: ArtifactRef | str
) -> WorldModelRecord:
    """Load and verify one WMR through its selected manifest and lineage."""
    from polisyos.core.artifacts import load_core_json_artifact

    selected_ref: ArtifactRef | str = ref
    try:
        if isinstance(ref, ArtifactRef):
            manifest = store.get_manifest(ref)
            if not store.verify(ref).ok:
                raise ValueError("world model artifact verification failed")
        else:
            manifest = store.get_manifest(ref)
            if not store.verify(ref).ok:
                raise ValueError("world model artifact verification failed")
        payload = load_core_json_artifact(store, selected_ref)
        record = WorldModelRecord.model_validate(payload)
        if (
            manifest.kind != WORLD_MODEL_RECORD_ARTIFACT_KIND
            or manifest.media_type != "application/json"
            or manifest.artifact_schema is None
            or manifest.artifact_schema.name != WORLD_MODEL_RECORD_SCHEMA_NAME
            or manifest.artifact_schema.version != record.schema_version
        ):
            raise ValueError("world model manifest schema mismatch")
        expected_inputs = _world_model_record_manifest_inputs(record)
        actual_inputs = tuple(
            sorted(
                (
                    str(item.artifact_id),
                    item.role,
                    item.manifest_profile_sha256,
                )
                for item in manifest.inputs
            )
        )
        if actual_inputs != expected_inputs:
            raise ValueError("world model manifest lineage mismatch")
        for view_ref in _iter_world_model_view_refs(record):
            if not store.verify(view_ref).ok:
                raise ValueError("world model selected input verification failed")
            store.get_manifest(view_ref)
        views = world_model_artifact_views(record)
        snapshot = _load_data_snapshot(store, views.data_snapshot_ref)
        from polisyos.runtime.quality.data_snapshot_lineage import (
            validate_data_snapshot_owner_lineage,
        )

        lineage_result = validate_data_snapshot_owner_lineage(
            store,
            views.data_snapshot_ref,
            snapshot,
            candidate_only=record.authority_status == "limited",
        )
        if lineage_result.required_admissibility_blockers and record.authority_status != "limited":
            raise WorldModelRecordError("world_model_record_source_row_authority_not_established")
        if not set(lineage_result.required_admissibility_blockers).issubset(
            record.limitations.admissibility_blockers
        ):
            raise WorldModelRecordError("world_model_record_source_row_limitation_missing")
        return record
    except WorldModelRecordError:
        raise
    except Exception as exc:
        raise WorldModelRecordError(
            "world_model_record_integrity_or_lineage_invalid",
            str(exc),
        ) from exc


def _world_model_record_manifest_inputs(
    record: WorldModelRecord,
) -> tuple[tuple[str, str, str | None], ...]:
    """Derive exact direct WMR lineage from its versioned view contract."""

    views = world_model_artifact_views(record)
    expected = [
        (views.data_snapshot_ref, "input.data_snapshot_ref"),
        (views.registry_bundle_ref, "input.registry_bundle_ref"),
        (views.model_spec_ref, "input.model_spec_ref"),
        (views.input_bindings_ref, "artifact.input_bindings_ref"),
        (views.bound_state_snapshot_ref, "artifact.bound_state_snapshot_ref"),
        (views.input_binding_report_ref, "artifact.input_binding_report_ref"),
    ]
    if views.substrate_registry_ref is not None:
        expected.append((views.substrate_registry_ref, "input.substrate_registry_ref"))
    expected.extend(
        (ref, f"input.program_graph_refs.{index}")
        for index, ref in enumerate(views.program_graph_refs)
    )
    expected.extend((ref, f"input.ncm_refs.{index}") for index, ref in enumerate(views.ncm_refs))
    return tuple(
        sorted(
            (
                str(ref.artifact_id),
                role,
                ref.manifest_profile_sha256,
            )
            for ref, role in expected
        )
    )


def _iter_world_model_view_refs(record: WorldModelRecord) -> tuple[ArtifactRef, ...]:
    """Return every direct selected CAS view, preserving its declared selector."""

    views = world_model_artifact_views(record)
    refs = [
        views.data_snapshot_ref,
        views.registry_bundle_ref,
        views.model_spec_ref,
        views.input_bindings_ref,
        views.bound_state_snapshot_ref,
        views.input_binding_report_ref,
        *views.program_graph_refs,
        *views.ncm_refs,
    ]
    if views.substrate_registry_ref is not None:
        refs.append(views.substrate_registry_ref)
    return tuple(refs)


def _load_data_snapshot(store: CoreJSONArtifactStore, ref: ArtifactRef) -> DataSnapshot:
    from polisyos.core.artifacts import load_core_json_artifact
    from polisyos.core.contracts import DataSnapshot

    payload = load_core_json_artifact(store, ref)
    return DataSnapshot.model_validate(payload)


def _data_snapshot_version_id(snapshot: DataSnapshot) -> str:
    stats = getattr(snapshot, "stats", None)
    if isinstance(stats, Mapping):
        value = stats.get("snapshot_id") or stats.get("version_id")
        if value:
            return str(value)
    notes = getattr(snapshot, "notes", None) or []
    for note in notes:
        text = str(note)
        if text.startswith("snapshot_id:"):
            return text.split(":", 1)[1].strip()
    return ""


def _load_data_forge_binding_ref(path: str | Path, *, role: str) -> DataForgeBindingRef:
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    if payload.get("schema_version") != _DATA_FORGE_SNAPSHOT_BINDING_SCHEMA_VERSION:
        raise WorldModelRecordError(
            "data_forge_snapshot_binding_schema_mismatch",
            str(payload.get("schema_version")),
        )
    rows = payload.get("bindings")
    if not isinstance(rows, list) or not rows:
        raise WorldModelRecordError("data_forge_snapshot_binding_missing")
    selected = None
    for row in rows:
        if isinstance(row, Mapping) and str(row.get("role") or "") == role:
            selected = row
            break
    if selected is None:
        raise WorldModelRecordError(
            "data_forge_snapshot_binding_role_missing",
            f"role {role!r} not found",
        )
    snapshot_id = str(payload.get("snapshot_id") or "")
    row_snapshot_id = str(selected.get("snapshot_id") or "")
    if not snapshot_id or row_snapshot_id != snapshot_id:
        raise WorldModelRecordError(
            "data_forge_snapshot_binding_snapshot_mismatch",
            f"{row_snapshot_id!r} != {snapshot_id!r}",
        )
    return DataForgeBindingRef(
        snapshot_id=snapshot_id,
        release_id=str(payload.get("release_id") or selected.get("release_id") or ""),
        role=role,
        read_api_identity=str(selected.get("read_api_identity") or ""),
        snapshot_ref=str(selected.get("snapshot_ref") or ""),
        merkle_root=str(selected.get("merkle_root") or ""),
        data_hash=str(selected.get("data_hash") or ""),
        claim_requirement_bindings=tuple(
            dict(item)
            for item in selected.get("claim_requirement_bindings") or []
            if isinstance(item, Mapping)
        ),
        quality_gate_refs=_quality_gate_refs(selected.get("quality_gates")),
        lineage_refs=tuple(str(item) for item in selected.get("lineage_refs") or []),
        provenance_manifest_ref=str(
            selected.get("provenance_manifest_ref") or payload.get("provenance_manifest_ref") or ""
        ),
        binding_path=str(Path(path)),
    )


def _quality_gate_refs(raw: object) -> tuple[str, ...]:
    if not isinstance(raw, list):
        return ()
    refs: list[str] = []
    for item in raw:
        if not isinstance(item, Mapping):
            continue
        ref = item.get("artifact_id") or item.get("name")
        if ref:
            refs.append(str(ref))
    return tuple(refs)


def _resolve_fabric_world_ref(fabric_world_ref: FabricWorldRef) -> FabricWorldRef:
    """Resolve Fabric snapshot and branch refs through the Fabric owner."""

    root = Path(fabric_world_ref.snapshot_root)
    if not root.exists():
        raise WorldModelRecordError(
            "fabric_world_snapshot_unresolved",
            f"snapshot_root does not exist: {root}",
        )

    import polisyos.fabric as fabric

    try:
        exact_snapshot = fabric.resolve_world_snapshot(
            root,
            snapshot_id=fabric_world_ref.snapshot_id,
        )
        branch_snapshot = fabric.resolve_world_snapshot(
            root,
            branch_name=fabric_world_ref.branch,
            as_of_tx_time=fabric_world_ref.as_of_tx_time,
            as_of_valid_time=fabric_world_ref.as_of_valid_time,
        )
        if branch_snapshot.snapshot_id != exact_snapshot.snapshot_id:
            raise WorldModelRecordError(
                "fabric_world_snapshot_unresolved",
                (
                    f"branch {fabric_world_ref.branch!r} resolves to "
                    f"{branch_snapshot.snapshot_id!r}, not {fabric_world_ref.snapshot_id!r}"
                ),
            )
        with fabric.SimulationDB(db_path=":memory:") as fabric_db:
            exact_frame = fabric.execute_world_query(
                fabric_db,
                fabric.WorldQueryRequest(
                    table="world_nodes",
                    columns=("node_id", "kind", "label", "artifact_id", "props_ref"),
                    order_by=("node_id",),
                    snapshot_root=root,
                    snapshot_id=fabric_world_ref.snapshot_id,
                    limit=100_000,
                ),
            )
            branch_frame = fabric.execute_world_query(
                fabric_db,
                fabric.WorldQueryRequest(
                    table="world_nodes",
                    columns=("node_id", "kind", "label", "artifact_id", "props_ref"),
                    order_by=("node_id",),
                    snapshot_root=root,
                    branch=fabric_world_ref.branch,
                    as_of_tx_time=fabric_world_ref.as_of_tx_time,
                    as_of_valid_time=fabric_world_ref.as_of_valid_time,
                    limit=100_000,
                ),
            )
        signal = _fabric_world_content_signal(
            exact_frame=exact_frame,
            branch_frame=branch_frame,
        )
        return fabric_world_ref.model_copy(
            update={
                "content_query_digest": signal.digest,
                "content_query_row_count": signal.row_count,
            }
        )
    except WorldModelRecordError:
        raise
    except fabric.WorldQueryError as exc:
        raise WorldModelRecordError("fabric_world_not_queryable", str(exc)) from exc
    except (FileNotFoundError, TypeError, ValueError, OSError) as exc:
        raise WorldModelRecordError("fabric_world_snapshot_unresolved", str(exc)) from exc


def _fabric_world_content_signal(
    *,
    exact_frame: _FabricQueryFrame,
    branch_frame: _FabricQueryFrame,
) -> _FabricWorldContentSignal:
    exact_rows = _fabric_query_rows(exact_frame, label="snapshot_id")
    branch_rows = _fabric_query_rows(branch_frame, label="branch")
    if not exact_rows:
        raise WorldModelRecordError(
            "fabric_world_empty",
            "Fabric snapshot query returned no world_nodes rows",
        )
    if not branch_rows:
        raise WorldModelRecordError(
            "fabric_world_as_of_empty",
            "Fabric branch/as-of query returned no world_nodes rows",
        )
    return _FabricWorldContentSignal(
        digest=gy_content_hash(
            {
                "fabric_world_content_query": {
                    "table": "world_nodes",
                    "exact_snapshot_rows": exact_rows,
                    "exact_snapshot_row_count": len(exact_rows),
                    "branch_as_of_rows": branch_rows,
                    "branch_as_of_row_count": len(branch_rows),
                }
            }
        ),
        row_count=len(exact_rows),
    )


def _fabric_query_rows(
    frame: _FabricQueryFrame,
    *,
    label: str,
) -> tuple[dict[str, Any], ...]:
    if not hasattr(frame, "to_dict") or not hasattr(frame, "columns"):
        raise WorldModelRecordError(
            "fabric_world_not_queryable",
            f"Fabric {label} query did not return a DataFrame-like result",
        )
    columns = tuple(str(column) for column in frame.columns)
    if "node_id" not in columns:
        raise WorldModelRecordError(
            "fabric_world_not_queryable",
            f"Fabric {label} query result is missing node_id",
        )
    raw_rows = frame.to_dict(orient="records")
    if not isinstance(raw_rows, list):
        raise WorldModelRecordError(
            "fabric_world_not_queryable",
            f"Fabric {label} query result cannot be serialized",
        )
    return tuple(
        {
            str(key): _json_scalar(value)
            for key, value in sorted(row.items(), key=lambda item: str(item[0]))
        }
        for row in raw_rows
        if isinstance(row, Mapping)
    )


def _json_scalar(value: object) -> object:
    if value is None:
        return None
    try:
        if value != value:
            return None
    except (TypeError, ValueError):
        pass
    item = getattr(value, "item", None)
    if callable(item):
        try:
            return item()
        except (TypeError, ValueError):
            pass
    isoformat = getattr(value, "isoformat", None)
    if callable(isoformat):
        return isoformat()
    return value


def _resolve_skg_causal_prior_ref(skg_causal_prior_ref: SkgCausalPriorRef) -> None:
    """Resolve SKG snapshot refs and versions through the SKG query owner."""

    try:
        parsed = _parse_skg_snapshot_ref(skg_causal_prior_ref.skg_snapshot_ref)
    except WorldModelRecordError as exc:
        raise WorldModelRecordError("skg_prior_ref_unresolved", str(exc)) from exc
    if str(parsed.version_id) != str(skg_causal_prior_ref.skg_version_id):
        raise WorldModelRecordError(
            "skg_prior_ref_unresolved",
            (
                "skg_snapshot_ref version does not match skg_version_id: "
                f"{parsed.version_id} != {skg_causal_prior_ref.skg_version_id}"
            ),
        )
    if not parsed.db_path.exists():
        raise WorldModelRecordError(
            "skg_prior_ref_unresolved",
            f"SKG DuckDB path does not exist: {parsed.db_path}",
        )

    import polisyos.data_forge as data_forge

    query = data_forge.read_api.academic.SKGQuery(
        db_path=parsed.db_path,
        index_dir=parsed.db_path.parent / "index",
    )
    try:
        if not query.has_skg_version_id(version_id=parsed.version_id):
            raise WorldModelRecordError(
                "skg_prior_ref_unresolved",
                f"SKG version not found: {parsed.version_id}",
            )
        owner_ref = query.skg_snapshot_ref(version_id=parsed.version_id)
    except WorldModelRecordError:
        raise
    except (TypeError, ValueError, OSError) as exc:
        raise WorldModelRecordError("skg_prior_ref_unresolved", str(exc)) from exc
    finally:
        query.close()
    if owner_ref is None:
        raise WorldModelRecordError(
            "skg_prior_ref_unresolved",
            f"SKG owner returned no snapshot ref for version {parsed.version_id}",
        )
    if _normalize_skg_snapshot_ref(owner_ref) != _normalize_skg_snapshot_ref(
        skg_causal_prior_ref.skg_snapshot_ref
    ):
        raise WorldModelRecordError(
            "skg_prior_ref_unresolved",
            f"{skg_causal_prior_ref.skg_snapshot_ref!r} does not resolve to {owner_ref!r}",
        )


def _load_substrate_registry_artifact_ref(
    store: CoreJSONArtifactStore,
    ref: ArtifactRef | str,
    *,
    loaded_registry: SubstrateRegistry | None = None,
) -> tuple[ArtifactRef, SubstrateRegistry]:
    """Normalize and load one persisted S0 registry artifact from this CAS."""

    try:
        if isinstance(ref, ArtifactRef):
            if ref.kind != SUBSTRATE_REGISTRY_ARTIFACT_KIND or ref.media_type != "application/json":
                raise ValueError("substrate registry artifact kind or media type is invalid")
            artifact_id = ArtifactID.model_validate(str(ref.artifact_id))
            profile_sha256 = ref.manifest_profile_sha256
        elif isinstance(ref, str):
            artifact_id = ArtifactID.model_validate(ref)
            profile_sha256 = None
        else:
            raise TypeError("substrate registry artifact ref must be ArtifactRef or sha256 string")
        normalized = ArtifactRef(
            artifact_id=artifact_id,
            kind=SUBSTRATE_REGISTRY_ARTIFACT_KIND,
            media_type="application/json",
            manifest_profile_sha256=profile_sha256,
        )
        loaded = (
            load_substrate_registry(store, normalized)
            if loaded_registry is None or normalized.manifest_profile_sha256 is not None
            else SubstrateRegistry.model_validate(loaded_registry.model_dump(mode="json"))
        )
    except Exception as exc:
        raise WorldModelRecordError(
            "substrate_registry_artifact_ref_invalid",
            "supplied substrate registry ref is not a valid persisted CAS artifact",
        ) from exc
    return normalized, loaded


def _substrate_registry_entries_for_comparison(
    registry: SubstrateRegistry,
) -> tuple[dict[str, Any], ...]:
    """Return complete, deterministic registry-entry projections for equality."""

    return tuple(
        sorted(
            (entry.model_dump(mode="json") for entry in registry.entries),
            key=lambda entry: (
                str(entry["source_id"]),
                str(entry["family_id"]),
                str(entry["layer"]),
                str(entry["entry_content_hash"]),
            ),
        )
    )


def _resolved_substrate_entry_ref_from_registry_entry(
    entry: SubstrateRegistryEntry,
) -> ResolvedSubstrateEntryRef:
    """Project one canonical registry entry into its WMR resolved reference."""

    return ResolvedSubstrateEntryRef(
        source_id=entry.source_id,
        family_id=entry.family_id,
        layer=entry.layer,
        coverage_score=entry.coverage.coverage_score,
        trust_tier=entry.trust_tier.tier,
        trust_cap=entry.trust_tier.trust_cap,
        identification_mode=entry.identification_mode,
        schema_regime_id=entry.schema_regime.schema_regime_id,
        data_version=entry.data_version,
        snapshot_id=entry.snapshot_id,
        source_snapshot_id=entry.source_snapshot_id,
        entry_content_hash=entry.entry_content_hash,
    )


def _resolve_substrate_registry_ref(
    store: CoreJSONArtifactStore,
    substrate_registry: SubstrateRegistry,
    *,
    required_sources: Sequence[str],
    required_families: Sequence[str],
    registry_artifact_ref: ArtifactRef | str | None,
    loaded_registry: SubstrateRegistry | None = None,
) -> SubstrateRegistryRef:
    validated = SubstrateRegistry.model_validate(substrate_registry.model_dump(mode="json"))
    normalized_registry_ref: ArtifactRef | None = None
    if registry_artifact_ref is not None:
        normalized_registry_ref, persisted_registry = _load_substrate_registry_artifact_ref(
            store,
            registry_artifact_ref,
            loaded_registry=loaded_registry,
        )
        if (
            persisted_registry.substrate_version_id != validated.substrate_version_id
            or persisted_registry.content_hash != validated.content_hash
            or _substrate_registry_entries_for_comparison(persisted_registry)
            != _substrate_registry_entries_for_comparison(validated)
        ):
            raise WorldModelRecordError(
                "substrate_registry_artifact_ref_content_mismatch",
                "persisted registry does not match the supplied in-memory registry",
            )
        validated = persisted_registry
    resolved: list[SubstrateRegistryEntry] = []
    try:
        for source_id in required_sources:
            resolved.extend(validated.resolve(source_id=source_id))
        for family_id in required_families:
            resolved.extend(validated.resolve(family_id=family_id))
    except SubstrateRegistryError as exc:
        raise WorldModelRecordError(exc.code, str(exc)) from exc
    if not required_sources and not required_families:
        resolved = list(validated.entries)
    unique = {
        entry.registry_key: entry
        for entry in sorted(
            resolved,
            key=lambda item: (item.layer.value, item.source_id, item.family_id),
        )
    }
    if not unique:
        raise WorldModelRecordError("substrate_registry_entries_missing")
    return SubstrateRegistryRef(
        substrate_version_id=validated.substrate_version_id,
        content_hash=validated.content_hash,
        registry_artifact_ref=(
            str(normalized_registry_ref.artifact_id)
            if normalized_registry_ref is not None
            else None
        ),
        resolved_entries=tuple(
            _resolved_substrate_entry_ref_from_registry_entry(entry) for entry in unique.values()
        ),
    )


def _parse_skg_snapshot_ref(raw_ref: str) -> _ParsedSkgSnapshotRef:
    prefix = "duckdb://"
    if not raw_ref.startswith(prefix):
        raise WorldModelRecordError("skg_prior_ref_unresolved", "SKG ref must use duckdb://")
    locator = raw_ref.removeprefix(prefix)
    path_text, separator, version_text = locator.partition("#v")
    if not path_text or separator != "#v" or not version_text:
        raise WorldModelRecordError(
            "skg_prior_ref_unresolved",
            f"SKG ref must include a DuckDB path and #v version: {raw_ref}",
        )
    try:
        version_id = int(version_text)
    except ValueError as exc:
        raise WorldModelRecordError(
            "skg_prior_ref_unresolved",
            f"SKG version is not an integer: {version_text}",
        ) from exc
    return _ParsedSkgSnapshotRef(db_path=Path(path_text), version_id=version_id)


def _assert_same_world_version(
    *,
    fabric_world_ref: FabricWorldRef,
    data_forge_binding_ref: DataForgeBindingRef,
    model_spec: ModelSpec,
    data_snapshot_ref: ArtifactRef,
    data_snapshot_id: str,
    skg_causal_prior_ref: SkgCausalPriorRef,
    allow_candidate_skg_source_mismatch: bool = False,
) -> None:
    snapshot_ids = {
        "fabric_world_ref.snapshot_id": fabric_world_ref.snapshot_id,
        "data_forge_binding_ref.snapshot_id": data_forge_binding_ref.snapshot_id,
        "data_snapshot_ref.snapshot_id": data_snapshot_id,
    }
    if (
        not allow_candidate_skg_source_mismatch
        or skg_causal_prior_ref.source_data_snapshot_id == data_snapshot_id
    ):
        snapshot_ids["skg_causal_prior_ref.source_data_snapshot_id"] = (
            skg_causal_prior_ref.source_data_snapshot_id
        )
    if len(set(snapshot_ids.values())) != 1:
        raise WorldModelRecordError(
            "world_substrate_version_mismatch",
            json.dumps(snapshot_ids, sort_keys=True),
        )
    if model_spec.data_snapshot_ref != str(data_snapshot_ref.artifact_id):
        raise WorldModelRecordError(
            "world_substrate_version_mismatch",
            (
                "ModelSpec.data_snapshot_ref does not match the Fabric "
                f"DataSnapshot CAS ref: {model_spec.data_snapshot_ref} != "
                f"{data_snapshot_ref.artifact_id}"
            ),
        )


def _policy_slot_map(
    slot_registry: SlotRegistry,
    *,
    policy_slot_ids: Sequence[str],
) -> tuple[PolicySlotBinding, ...]:
    if not policy_slot_ids:
        raise WorldModelRecordError("policy_slot_map_missing")
    bindings: list[PolicySlotBinding] = []
    for slot_id in policy_slot_ids:
        slot = slot_registry.slots.get(str(slot_id))
        if slot is None or not getattr(slot, "state_path", None):
            raise WorldModelRecordError(
                "world_slot_state_path_missing",
                f"slot {slot_id!r} has no state_path in registry",
            )
        unit = getattr(getattr(slot, "unit", None), "unit_id", None)
        scope = getattr(getattr(slot, "scope", None), "value", getattr(slot, "scope", None))
        kind = getattr(getattr(slot, "kind", None), "value", getattr(slot, "kind", None))
        bindings.append(
            PolicySlotBinding(
                slot_id=str(slot_id),
                state_path=str(slot.state_path),
                unit=None if unit is None else str(unit),
                entity_scope=str(scope),
                temporal_granularity=str(kind or "unspecified"),
            )
        )
    return tuple(bindings)


def _normalize_skg_snapshot_ref(raw_ref: str) -> str:
    try:
        parsed = _parse_skg_snapshot_ref(raw_ref)
    except WorldModelRecordError:
        return raw_ref
    return f"duckdb://{parsed.db_path.name}#v{parsed.version_id}"
