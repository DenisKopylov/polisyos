"""Read back both exact manifests and simulate their intended sequential preimages."""
from __future__ import annotations
import hashlib,json,subprocess
from pathlib import Path
repo=Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
raw=repo/"LOCAL/raw/e02-execution-20261027/repairs/SQL-owner-chain-r3-intake-20261028-r1"
sha=lambda b:hashlib.sha256(b).hexdigest()
sql_path=raw/"sql-61-manifest.json"
v3_path=raw/"v3-8-after-sql-manifest.json"
assert sha(sql_path.read_bytes())=="edd7e6677f01d48d4044888d92c06fe9e80447bb49b0eaed7e53417b55e8eaad"
assert sha(v3_path.read_bytes())=="3b92f2c852fa067abbd86f466a3f6ff4ec31cf1ab6b38e5832f1ebe6fe022037"
sql=json.loads(sql_path.read_bytes())
v3=json.loads(v3_path.read_bytes())
assert v3["requires_sql_61_manifest_sha256"]==sha(sql_path.read_bytes())
virtual={}
results=[]
for label,manifest in (("sql",sql),("v3_after_sql",v3)):
 for row in manifest["files"]:
    path=row["path"]
    target=repo/path
    assert not target.is_symlink(),path
    before=virtual.get(path,sha(target.read_bytes()) if target.is_file() else None)
    assert before==row["pre_sha256"],(label,path,before,row["pre_sha256"])
    post=Path(row["postimage_file"])
    assert post.is_absolute() and post.is_file() and not post.is_symlink(),post
    got=sha(post.read_bytes())
    assert got==row["post_sha256"],(label,path,got,row["post_sha256"])
    virtual[path]=got
    results.append({"phase":label,"path":path,"pre_sha256":before,"post_sha256":got,
                    "postimage_file":str(post)})
assert len(sql["files"])==61 and len(v3["files"])==8 and len(virtual)==68
sql_paths={x["path"] for x in sql["files"]}
v3_paths={x["path"] for x in v3["files"]}
assert sql_paths & v3_paths == {"policy-engine/src/polisyos/foundry/data_plane/bindings.py"}
command=["python3",str(repo/"LOCAL/raw/e02-execution-20261027/root_compose_frozen_manifest.py"),
         str(sql_path.relative_to(repo)),sha(sql_path.read_bytes()),"sql-source-admission",
         str((raw/"checks/sql-root-admission-readback").relative_to(repo))]
run=subprocess.run(command,cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(raw/"checks/root-admission.stdout").write_bytes(run.stdout)
(raw/"checks/root-admission.stderr").write_bytes(run.stderr)
record={"root_command":command,"root_exit":run.returncode,
        "root_stdout_sha256":sha(run.stdout),"root_stderr_sha256":sha(run.stderr),
        "git_head":subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo).decode().strip(),
        "git_tree":subprocess.check_output(["git","rev-parse","HEAD^{tree}"],cwd=repo).decode().strip(),
        "sql_paths":len(sql["files"]),"v3_paths":len(v3["files"]),"unique_paths":len(virtual),
        "overlap":list(sql_paths & v3_paths),"canonical_mutations":False,
        "v3_following_sql":"preimages matched in virtual SHA overlay; not physically applied",
        "runtime":"UNRUN","files":results}
(raw/"checks/intake-readback.json").write_text(json.dumps(record,indent=2)+"\n")
print(run.stdout.decode().strip())
print("virtual sequencing",len(sql["files"]),len(v3["files"]),len(virtual),"PASS")
assert run.returncode==0
