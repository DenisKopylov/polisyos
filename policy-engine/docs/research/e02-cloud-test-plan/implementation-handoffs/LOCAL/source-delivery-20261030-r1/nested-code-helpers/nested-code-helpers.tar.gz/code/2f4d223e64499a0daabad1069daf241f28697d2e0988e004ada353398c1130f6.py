"""Small synthetic controls for the actual bounded per-code qualifier."""
from __future__ import annotations
import copy
import importlib.util
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
spec_loader=importlib.util.spec_from_file_location('g27_qualifier_control',HERE.parent/'qualify_native.py')
q=importlib.util.module_from_spec(spec_loader);spec_loader.loader.exec_module(q)
out=HERE/'fake-qualifier-r3';out.mkdir(exist_ok=False)
(out/'c134/origins').mkdir(parents=True);(out/'basetemp/case/child').mkdir(parents=True)
test='policy-engine/tests/integration/runtime/http/test_g27_owner_generation_oracle.py'
helper='policy-engine/tests/_helpers/g27_owner_generation_oracle.py'
owner='policy-engine/src/polisyos/scientist/validation/decision_validity.py'
node='tests/integration/runtime/http/test_g27_owner_generation_oracle.py::test_pilot'
paths=[test,helper,owner]
source=[{'path':p,'sha256':str(i)*64,'bytes':10+i,'git_blob':str(i)*40} for i,p in enumerate(paths,1)]
plan={'nodes':[node],'g27':{'selection':'pilot','source_bindings':source}}
spec={'candidate_paths':[test,helper], 'mandatory_pilot_parent':[{'path':test,'qualname':'test_pilot'},
      {'path':owner,'qualname':'DecisionValidityService.read_source_current_use'}],
      'mandatory_pilot_child':[{'path':helper,'qualname':'_child_main'},
      {'path':owner,'qualname':'DecisionValidityService.read_source_current_use'}],
      'assertion_rewriter_sha256':'f'*64}
(out/'collection-events.json').write_text(json.dumps({'pid':101,'expected_nodeids':[node],
    'collected_nodeids_before_guard':[node],'mismatch':None}))
(out/'pytest-execution-profile.json').write_text(json.dumps({'pid':101,'profile_identity_complete':True,
    'within_phase_profile_match':True}))
(out/'basetemp/case/child/command.json').write_text(json.dumps({'pid':102,'status':'EXITED','exit':0,
    'argv':['python','-m','tests._helpers.g27_owner_generation_oracle']}))

def make(pid, pairs):
    rows=[];reads={}
    for rel,name,module in pairs:
        item=next(x for x in source if x['path']==rel);resolved=str(q.ROOT/rel)
        row={'relative_path':rel,'qualname':name,'module':module,'source_read':'READ',
             'source_read_receipt':resolved,'resolved_path':resolved,'source_sha256':item['sha256'],
             'source_bytes':item['bytes'],'git_blob':item['git_blob'],'expected_blob':item['git_blob'],
             'code_sha256':'a'*64,'thread_ids':[1],'compilation_match':True,'compilation_image':'source'}
        rows.append(row);reads[resolved]={'sha256':item['sha256'],'git_blob':item['git_blob']}
    return {'pid':pid,'ppid':101 if pid==102 else 1,'actual_code_capture':{'pid':pid,'codes':rows,
        'source_reads':reads,'code_census_complete_for_observed_events':False}}

parent=make(101,[(test,'test_pilot','tests.sample'),(helper,'helper_body','tests._helpers.g27_owner_generation_oracle'),
    (owner,'DecisionValidityService.read_source_current_use','polisyos.scientist.validation.decision_validity')])
child=make(102,[(helper,'_child_main','__main__'),
    (owner,'DecisionValidityService.read_source_current_use','polisyos.scientist.validation.decision_validity')])

def run(name,p,c):
    (out/'c134/origins/parent.json').write_text(json.dumps(p))
    (out/'c134/origins/child.json').write_text(json.dumps(c))
    result=q.qualify_case(out,plan,spec)
    return {'name':name,'status':result['selected_source_qualification'],'issues':result['issues']}

baseline=run('baseline_global_false',parent,child)
wrong=copy.deepcopy(parent);wrong['actual_code_capture']['codes'][0]['compilation_match']=False
wrong=run('compilation_removed',wrong,child)
missing=copy.deepcopy(child);missing['actual_code_capture']['codes'].pop(0)
missing=run('child_body_removed',parent,missing)
forged=copy.deepcopy(parent);forged['actual_code_capture']['codes'][1]['relative_path']=None
forged=run('actual_helper_origin_forged',forged,child)
assert baseline['status']=='PASS',baseline
assert all(x['status']=='ERROR' for x in (wrong,missing,forged)),(wrong,missing,forged)
result={'scope':'synthetic rows only; exercises actual qualify_case; no product import or pytest',
        'cases':[baseline,wrong,missing,forged], 'product_execution':'UNRUN'}
(HERE/'fake-qualifier-r3-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
