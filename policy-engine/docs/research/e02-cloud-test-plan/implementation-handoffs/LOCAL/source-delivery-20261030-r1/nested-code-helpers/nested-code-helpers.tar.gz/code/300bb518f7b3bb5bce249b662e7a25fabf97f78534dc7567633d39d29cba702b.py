"""Observe actual pytest setup using the exact extracted HTTP cache fixture AST."""
from __future__ import annotations

import ast
import hashlib
import json
import os
import sys
import tempfile
from pathlib import Path

import pytest

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
SOURCE = ROOT / "policy-engine/tests/_helpers/runtime_http.py"
text = SOURCE.read_text(encoding="utf-8")
tree = ast.parse(text)
functions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "runtime_http_cache_isolation"]
if len(functions) != 1:
    raise RuntimeError("fixture source missing or ambiguous")
function = functions[0]
names = {node.id for node in ast.walk(function) if isinstance(node, ast.Name)}
if names != {"pytest", "Path", "tmp_path", "monkeypatch"}:
    raise RuntimeError("fixture source gained unknown dependencies")
module = ast.fix_missing_locations(ast.Module(body=[function], type_ignores=[]))
exec(compile(module, str(SOURCE), "exec"), globals(), globals())
print("E02_FIXTURE_SOURCE=" + json.dumps({"path": str(SOURCE), "sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(), "function_ast_sha256": hashlib.sha256(ast.dump(function, include_attributes=False).encode()).hexdigest()}))

KEYS = ("POLISYOS_CACHE_HOME", "TMPDIR", "XDG_CACHE_HOME", "MPLCONFIGDIR", "NUMBA_CACHE_DIR", "HYPOTHESIS_STORAGE_DIRECTORY", "PYTHONPYCACHEPREFIX", "PYTHONDONTWRITEBYTECODE", "PYTHONPATH", "PYTEST_PLUGINS", "POLISYOS_CAS_BACKEND", "POLISYOS_EXECUTION_PROFILE")


def snapshot(item):
    return {"cwd": str(Path.cwd()), "environment": {k: os.environ.get(k) for k in KEYS},
            "tmp_path": str(item.funcargs.get("tmp_path")) if item.funcargs.get("tmp_path") is not None else None,
            "tempfile_cached": tempfile.tempdir, "sys_pycache_prefix": sys.pycache_prefix,
            "dont_write_bytecode": sys.dont_write_bytecode,
            "absolute_sys_path": all(s and os.path.isabs(s) for s in sys.path)}


@pytest.hookimpl(wrapper=True, tryfirst=True)
def pytest_runtest_setup(item):
    before_env = dict(os.environ)
    before = snapshot(item)
    try:
        return (yield)
    finally:
        changed = sorted(k for k in before_env.keys() | os.environ.keys() if before_env.get(k) != os.environ.get(k))
        print("E02_SETUP_RESOURCE_FACTS=" + json.dumps({"before": before, "after": snapshot(item), "changed_env_names": changed}, sort_keys=True))


@pytest.hookimpl(tryfirst=True)
def pytest_runtest_call(item):
    print("E02_CALL_RESOURCE_FACTS=" + json.dumps(snapshot(item), sort_keys=True))
