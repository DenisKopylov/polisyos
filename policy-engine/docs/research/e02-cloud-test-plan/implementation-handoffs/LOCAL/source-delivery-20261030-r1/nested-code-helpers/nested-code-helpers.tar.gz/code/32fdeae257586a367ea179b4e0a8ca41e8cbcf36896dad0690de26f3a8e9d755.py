"""Exercise two extracted R3 local functions with stdlib fakes; product remains UNRUN."""

from __future__ import annotations

import ast
import json
import sys
import threading
import time
from pathlib import Path

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
SOURCE = (
    ROOT
    / "LOCAL/raw/e02-execution-20261027/repairs/R4-native-control-r1/integrated-source-r3/postimages/policy-engine/tests/unit/runtime/http/test_observational_method_runtime.py"
)


def main() -> None:
    if sys.argv[1:] not in ([], ["--baseline-r2"]):
        raise SystemExit("only --baseline-r2 is supported")
    selected_source = (
        Path(str(SOURCE).replace("integrated-source-r3", "integrated-source-r2"))
        if sys.argv[1:]
        else SOURCE
    )
    tree = ast.parse(selected_source.read_bytes())
    test = next(
        node
        for node in tree.body
        if isinstance(node, ast.FunctionDef)
        and node.name == "test_real_forest_fit_progress_spans_durable_cancel_post"
    )
    functions = {node.name: node for node in ast.walk(test) if isinstance(node, ast.FunctionDef)}
    source = ast.Module(
        body=[
            ast.ImportFrom(module="__future__", names=[ast.alias(name="annotations")], level=0),
            functions["_next_native_event"],
            functions["stale_operation"],
        ],
        type_ignores=[],
    )
    code = compile(ast.fix_missing_locations(source), "<r4_r3_extracted_source>", "exec")

    class Stopped(Exception):
        pass

    class LeaseLost(Exception):
        pass

    LeaseLost.__name__ = "ControlJobLeaseLostError"
    stopped = []

    def skip(stage, reason):
        stopped.append((stage, reason))
        raise Stopped()

    done = threading.Event()
    done.set()
    observations = {"result": {}, "final": {"stale_write_results": {}, "stale_write_refused": {}}}
    errors = [{"type": "RuntimeError", "message": "real dispatch example"}]

    class FastDeadline:
        calls = 0

        def monotonic(self):
            self.calls += 1
            return 0.0 if self.calls == 1 else 601.0

    ns = {
        "time": FastDeadline(),
        "dispatch_done": done,
        "method_handle": None,
        "observation": observations,
        "worker_errors": errors,
        "_skip_with_partial": skip,
        "ControlJobLeaseLostError": LeaseLost,
    }
    exec(code, ns)
    started = time.monotonic()
    try:
        ns["_next_native_event"](600.0)
    except Stopped:
        pass
    elapsed = time.monotonic() - started
    results = {
        "dispatch_without_handle_exits_promptly": bool(
            stopped and stopped[0][0] == "dispatch_finished_without_method" and elapsed < 1.0
        ),
        "dispatch_error_preserved": observations["result"].get("handler_errors") == errors,
        "dispatch_exit_disposition_preserved": observations["result"].get("handler_disposition")
        == "dispatch_returned_without_handle",
    }

    def normal(record):
        record["body_entered"] = True

    def denied(record):
        raise LeaseLost("original lease no longer current")

    def unexpected(record):
        raise RuntimeError("guard failure")

    for name, operation in (("progress", normal), ("manifest", denied), ("terminal", unexpected)):
        ns["stale_operation"](name, operation)
    rows = observations["final"]["stale_write_results"]
    results["normal_guard_return_recorded"] = (
        rows["progress"]["called"]
        and rows["progress"].get("returned_normally") is True
        and rows["progress"]["refused"] is False
    )
    results["actual_lease_refusal_recorded"] = (
        rows["manifest"].get("returned_normally") is False
        and rows["manifest"]["refused"] is True
        and rows["manifest"]["exception_type"] == "ControlJobLeaseLostError"
    )
    results["unexpected_exception_not_refusal"] = (
        rows["terminal"].get("returned_normally") is False
        and rows["terminal"]["refused"] is False
        and rows["terminal"]["exception_type"] == "RuntimeError"
    )
    try:
        ns["stale_operation"](
            "interrupt", lambda record: (_ for _ in ()).throw(KeyboardInterrupt())
        )
        results["interrupt_not_swallowed"] = False
    except KeyboardInterrupt:
        results["interrupt_not_swallowed"] = True
    handlers = [
        handler
        for node in ast.walk(test)
        if isinstance(node, ast.Try)
        for handler in node.handlers
        if isinstance(handler.type, ast.Name) and handler.type.id == "_R4ObservedSemanticError"
    ]
    results["semantic_exception_reraised_without_error_relabel"] = (
        len(handlers) == 1
        and len(handlers[0].body) == 1
        and isinstance(handlers[0].body[0], ast.Raise)
        and handlers[0].body[0].exc is None
    )
    messages = [
        node.value
        for node in ast.walk(test)
        if isinstance(node, ast.Constant) and isinstance(node.value, str)
    ]
    results["old_early_uncancelled_runtimeerror_removed"] = (
        "authorized cancel POST left the job nonterminal and uncancelled" not in messages
    )
    loops = [
        node
        for node in ast.walk(test)
        if isinstance(node, ast.While) and "running_deadline" in ast.unparse(node.test)
    ]
    results["lease_wait_checks_finished_dispatch"] = (
        len(loops) == 1
        and "dispatch_done.is_set() and method_handle is None" in ast.unparse(loops[0])
        and "dispatch_finished_without_method" in ast.unparse(loops[0])
    )
    payload = {
        "pass": all(results.values()),
        "results": results,
        "source": "R2" if sys.argv[1:] else "R3",
        "scope": "AST-extracted local functions with stdlib fakes; no product import, native job, pytest or runtime claim",
        "closure_ids": [],
    }
    print(json.dumps(payload, indent=2, sort_keys=True))
    if not payload["pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
