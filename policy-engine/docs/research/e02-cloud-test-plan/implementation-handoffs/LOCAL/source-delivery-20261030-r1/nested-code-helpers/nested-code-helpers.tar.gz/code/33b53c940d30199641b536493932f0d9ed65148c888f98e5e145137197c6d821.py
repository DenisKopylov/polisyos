def body():
    return None
value = body.__code__
from unseen import *
opaque(value)
