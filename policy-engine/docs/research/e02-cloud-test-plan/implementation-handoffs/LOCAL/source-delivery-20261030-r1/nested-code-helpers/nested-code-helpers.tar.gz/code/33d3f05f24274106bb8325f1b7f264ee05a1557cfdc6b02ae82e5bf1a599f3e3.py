from types import FunctionType
from importlib import import_module
def body(left, right):
    return -left
CODE = body.__code__
run = FunctionType(CODE, globals())
run(unknown_left, unknown_right)
