from types import FunctionType
from importlib import import_module
def body(callback):
    return callback("bridge_callback")
CODE = body.__code__
run = FunctionType(CODE, globals())
setattr(opaque_target, "__code__", opaque_code)
run(import_module)
