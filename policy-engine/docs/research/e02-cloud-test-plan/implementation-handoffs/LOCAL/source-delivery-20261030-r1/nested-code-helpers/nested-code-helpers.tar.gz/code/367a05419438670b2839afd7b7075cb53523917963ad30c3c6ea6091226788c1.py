"""Read-only byte/edge/owner readback for the root's isolated CAS diagnostic."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
D = ROOT / 'policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1'
OLD = D / 'c07-selected-source-unit-native-r5-20261028/basetemp/test_owned_hte_outbox_records_0/.polisyos/artifacts'
if len(sys.argv) != 2:
    raise SystemExit('absolute unique pilot output directory required')
OUT = Path(sys.argv[1])
if not OUT.is_absolute() or OUT.parent != D or not OUT.name.startswith('c07-cas-owner-query-pilot-'):
    raise SystemExit('pilot output must be a uniquely named absolute child of D')
AID = '1286fe7a26486c9a128b112f5bd256b9554f2b586deedd7edfae70bac5851028'
PROFILE = '54d6c1e7dc66328602fb366c2f6a1a906925436193d11c589fc70dcde92db28e'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None


def main():
    result = {'diagnostic_complete': False, 'original_c07_outcome': 'FAIL, not rerun',
              'scope': 'Read-only synthetic probe evidence; no S1/G closure.', 'closure_ids': []}
    audit_path = OUT / 'audit-result.json'
    report_path = OUT / 'c07-cas-probe.json'
    result['audit_sha256'] = sha(audit_path)
    result['probe_sha256'] = sha(report_path)
    if not audit_path.is_file() or not report_path.is_file():
        result['reason'] = 'audit or probe report absent; inspect retained stdout/stderr'
        print(json.dumps(result, indent=2)); raise SystemExit(1)
    audit = json.loads(audit_path.read_text())
    probe = json.loads(report_path.read_text())
    process = audit['result']
    plan_path = D / (OUT.name + '.json')
    readset_path = OUT / 'source-readset.json'
    freeze_path = OUT / 'source-profile-freeze.json'
    if not all(p.is_file() for p in (plan_path, readset_path, freeze_path)):
        raise SystemExit('plan, source freeze or source readset is missing')
    plan = json.loads(plan_path.read_text())
    freeze = json.loads(freeze_path.read_text())
    readset = json.loads(readset_path.read_text())
    before = audit.get('before')
    paths = readset.get('paths')
    pins = plan.get('input_pins')
    if not isinstance(before, dict) or not isinstance(paths, dict) or not paths or not isinstance(pins, dict) or not pins:
        raise SystemExit('source frame, finite readset or input pins are missing')
    def relative_inside(value, prefix):
        return isinstance(value, str) and not Path(value).is_absolute() and '..' not in Path(value).parts and value.startswith(prefix)
    input_mismatches = [path for path, expected in pins.items()
        if not relative_inside(path, '') or not isinstance(expected, str) or sha(ROOT / path) != expected]
    readset_mismatches = [path for path, expected in paths.items()
        if not relative_inside(path, ('src/polisyos/', 'tests/', 'tools/'))
        or not isinstance(expected, str) or sha(ROOT / 'policy-engine' / path) != expected]
    try:
        head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
        tree = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, text=True).strip()
    except (OSError, subprocess.CalledProcessError):
        raise SystemExit('could not re-read current source identity') from None
    expected_owner = 'ba56a58da7f9929d33384e71e8c3bf8877a64775b0a7e3c69deed5f991ec0ce7'
    owner_path = 'policy-engine/src/polisyos/core/artifacts/ownership.py'
    test_path = 'policy-engine/tests/unit/core/artifacts/test_cas_owner_snapshot_query.py'
    inspector_path = str(Path(__file__).resolve().relative_to(ROOT))
    frame = plan.get('source_frame')
    frame_valid = (isinstance(frame, dict) and relative_inside(frame.get('path'), '')
        and isinstance(frame.get('sha256'), str) and sha(ROOT / frame['path']) == frame['sha256'])
    plan_sha = sha(plan_path)
    readset_sha = sha(readset_path)
    freeze_sha = sha(freeze_path)
    result['source_binding'] = {
        'plan_sha256': plan_sha, 'readset_sha256': readset_sha, 'freeze_sha256': freeze_sha,
        'head': head, 'tree': tree, 'input_mismatches': input_mismatches,
        'readset_mismatches': readset_mismatches, 'readset_count': len(paths)}
    result['diagnostic_complete'] = (process.get('return_code') == 0 and process.get('complete') is True
        and process.get('aborted_reason') is None and process.get('process_group_gone') is True
        and result['probe_sha256'] is not None and audit.get('probe_sha256') == result['probe_sha256']
        and plan_sha is not None and audit.get('plan_sha256') == plan_sha and audit.get('plan') == plan
        and readset_sha is not None and audit.get('readset_sha256') == readset_sha
        and freeze_sha is not None and audit.get('source_profile_freeze_sha256') == freeze_sha
        and freeze.get('plan_sha256') == plan_sha and freeze.get('pins') == pins
        and freeze.get('before') == before and audit.get('after') == before
        and before.get('head') == plan.get('source_head') == head
        and frame_valid and before.get('source_frame') == frame
        and plan.get('source_tree') == tree and plan.get('case_id') == OUT.name
        and pins.get(owner_path) == expected_owner
        and pins.get(test_path) == '7335f1be5372e0b47e67c99a4d95458f86204e07bdcdcd2774ff401a40b93de0'
        and pins.get(inspector_path) == sha(Path(__file__))
        and not input_mismatches and not readset_mismatches
        and readset.get('count') == len(paths) and probe.get('source_readset_count') == len(paths)
        and probe.get('source_readset_sha256') == readset_sha
        and audit.get('input_mismatches') == [] and audit.get('imported_mismatches') == [])
    result['caller_error'] = probe.get('caller_error')
    result['guard_seconds'] = probe.get('guard_return_seconds')
    result['effective_timeout_seconds'] = probe.get('effective_guard_timeout_seconds')
    result['queue_seconds'] = probe.get('submit_to_worker_start_seconds')
    result['worker_seconds'] = probe.get('worker_seconds')
    result['worker_finished_within_60s'] = probe.get('worker_finished_within_60s')
    result['worker_error'] = probe.get('worker_error')
    result['worker_returned_after_guard'] = probe.get('late_worker_returned_after_guard')
    result['guarded_verify_ok'] = probe.get('post_worker_real_guarded_verify_ok')
    result['phase_timings'] = probe.get('phase_timings')
    result['thread_samples'] = len(probe.get('thread_samples', []))
    ref = probe.get('worker_actual_ref')
    result['exact_role_edges'] = None
    result['clone_owner_claims'] = None
    result['target_pending_intent'] = None
    if ref is not None:
        got_id = str(ref['artifact_id']).removeprefix('sha256:')
        got_profile = str(ref['manifest_profile_sha256']).removeprefix('sha256:')
        base = OUT / 'private-cas/artifacts/sha256' / got_id[:2] / got_id[2:4]
        got_blob = base / (got_id + '.blob')
        got_manifest = base / (got_id + '.view.' + got_profile + '.manifest.json')
        expected_manifest = OLD / 'sha256/12/86' / (AID + '.view.' + PROFILE + '.manifest.json')
        if got_blob.is_file() and got_manifest.is_file() and expected_manifest.is_file():
            actual = json.loads(got_manifest.read_text())
            expected = json.loads(expected_manifest.read_text())
            key = lambda x: (x['artifact_id'], x['role'], x.get('manifest_profile_sha256'))
            a = [key(x) for x in actual['inputs']]
            b = [key(x) for x in expected['inputs']]
            result['exact_role_edges'] = (got_id == AID and sha(got_blob) == AID
                and len(a) == len(b) == 192 and len(set(a)) == 192 and set(a) == set(b))
            result['clone_manifest_sha256'] = sha(got_manifest)
        owner = OUT / 'private-cas/artifacts/ownership'
        idx = owner / 'index.json'
        if idx.is_file():
            pointer = json.loads(idx.read_text())
            generation = str(pointer['generation_sha256']).removeprefix('sha256:')
            gp = owner / 'generations' / (generation + '.json')
            if gp.is_file() and sha(gp) == generation:
                payload = json.loads(gp.read_text())['payload']
                records = payload['artifacts'].get('sha256:' + AID, [])
                tenant = probe['tenant_id']; cell = probe['cell_id']
                same = lambda x: x.get('tenant_id') == tenant and x.get('cell_id') == cell
                owner_claim = any(same(x) and x.get('manifest_profile_sha256') is None for x in records)
                view_claim = any(same(x) and x.get('manifest_profile_sha256') == ref['manifest_profile_sha256'] for x in records)
                result['clone_owner_claims'] = {'generation_sha256': generation, 'blob_owner': owner_claim, 'view_owner': view_claim}
        result['target_pending_intent'] = (owner / 'transactions/intents' / AID[:2] / (AID + '.json')).exists()
    claims = result['clone_owner_claims'] or {}
    result['guarded_write_succeeded'] = (
        result['diagnostic_complete']
        and result['effective_timeout_seconds'] == 1.5
        and result['caller_error'] is None
        and probe.get('caller_returned_ref') is not None
        and probe.get('caller_returned_ref') == ref
        and result['worker_finished_within_60s'] is True
        and result['worker_error'] is None
        and result['guarded_verify_ok'] is True
        and result['exact_role_edges'] is True
        and claims.get('blob_owner') is True
        and claims.get('view_owner') is True
        and result['target_pending_intent'] is False
    )
    print(json.dumps(result, indent=2))
    if not result['guarded_write_succeeded']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
