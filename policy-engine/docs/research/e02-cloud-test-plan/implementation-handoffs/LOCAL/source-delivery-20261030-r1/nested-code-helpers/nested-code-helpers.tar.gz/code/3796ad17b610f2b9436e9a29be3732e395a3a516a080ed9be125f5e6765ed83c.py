def _run_n7_acquisition_if_requested(self, problem: DesignProblem, *, cycle: GenerationCycleRecord, planner_report: AcquisitionPlannerReport | None=None, planner_report_ref: CASArtifactRef | None=None, planned_route: _N7PlannedRoute | None=None) -> AcquisitionReceipt | None:
    if cycle.terminal_kind != SearchTerminalKind.ACQUISITION_REQUIRED.value:
        return None
    if planned_route is None:
        planned_route = self._plan_n7_requirement_gap_if_requested(problem, cycle=cycle)
        if planned_route is None:
            return None
    if planner_report is None:
        planner_report = planned_route.report
    if planner_report_ref is None:
        planner_report_ref = planned_route.report_ref
    if planner_report != planned_route.report or planner_report_ref != planned_route.report_ref:
        raise GenerationCycleError('n7_planner_report_binding_refused')
    normalized_request = dict(planned_route.acquisition_request)
    basis = planned_route.basis
    world_snapshot = planned_route.world_snapshot
    basis_binding = planned_route.report.requirement_basis_binding
    if planner_report is not None and planner_report.basis_limitation_code in {'requirement_basis_not_established', 'requirement_gap_not_compiled', 'unbound_requirement_input_refused'}:
        return None
    if basis.routing_limitation_code is not None:
        return None
    if self._measurement_root_execution_binding is None or not self._measurement_root_execution_binding.authority_eligible:
        raise GenerationCycleError('n7_execution_scope_not_established')
    specs = basis.specs
    capability_resolutions = basis.capability_resolutions
    if not specs and (not capability_resolutions):
        return None

    def is_compiled_requirement_spec(value: object) -> TypeGuard[BaseModel | Mapping[str, Any]]:
        return isinstance(value, BaseModel) or (isinstance(value, Mapping) and all((isinstance(key, str) for key in value)))
    compiled_specs: list[BaseModel | Mapping[str, Any]] = []
    for spec in specs:
        if not is_compiled_requirement_spec(spec):
            raise GenerationCycleError('n7_data_requirement_specs_invalid')
        compiled_specs.append(spec)
    owner_gateway = self._n7_owner_gateway(problem)
    if owner_gateway is None:
        raise GenerationCycleError('n7_runtime_store_not_supplied')
    artifact_store = self._n7_runtime_artifact_store()
    if planner_report is not None and (planner_report_ref is None or artifact_store is None):
        raise GenerationCycleError('n7_planner_report_persistence_unavailable')
    if planned_route is not None and basis_binding is None:
        raise GenerationCycleError('n7_compiler_report_binding_refused')
    run_id = planner_report.run_id if planner_report is not None else f'n7-cycle:{problem.design_problem_id}:{cycle.cycle_index}'
    try:
        return run_acquisition_closed_loop(run_id=run_id, acquisition_request=normalized_request, data_requirement_specs=tuple(compiled_specs), world_snapshot=world_snapshot, capability_requirement_resolutions=capability_resolutions, requirement_basis_binding=basis_binding, design_problem=problem, owner_gateway=owner_gateway, useful_design_rate_before=float(problem.runtime_hints.get('n7_useful_design_rate_before') or 0.0), generated_at=planner_report.generated_at if planner_report is not None else self._generated_at, planner_report=planner_report, planner_report_ref=planner_report_ref, artifact_store=artifact_store, require_persisted_planner_report=planner_report is not None)
    except AcquisitionPlannerBindingError as exc:
        error_code = 'n7_compiler_report_binding_refused' if 'compiler_report' in str(exc) else 'n7_planner_report_binding_refused'
        raise GenerationCycleError(error_code, str(exc)) from exc
