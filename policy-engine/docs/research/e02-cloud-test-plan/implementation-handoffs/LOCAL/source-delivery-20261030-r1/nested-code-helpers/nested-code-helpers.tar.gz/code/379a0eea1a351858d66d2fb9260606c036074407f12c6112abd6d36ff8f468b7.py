"""Run the complete real preparer main over a synthetic fake helper/filesystem."""
from __future__ import annotations
import contextlib
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
PREPARER = HERE.parent/'prepare_native.py'
QUALIFIER = HERE.parent/'qualify_native.py'
OUT = HERE/'fake-main-r3'
OUT.mkdir(exist_ok=False)
HEAD='c'*40
TREE='d'*40
BASE='a'*40
BASE_TREE='b'*40

def sha(b): return hashlib.sha256(b).hexdigest()
def blob(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b,usedforsecurity=False).hexdigest()
def put(root, name, data):
    path=root/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data);return path

def snapshot(root):
    result={}
    for path in root.rglob('*'):
        if path.is_symlink(): result[path.relative_to(root).as_posix()]='SYMLINK:'+os.readlink(path)
        elif path.is_file(): result[path.relative_to(root).as_posix()]=sha(path.read_bytes())
    return result

def one(name, attack=None):
    root=OUT/name;root.mkdir()
    packet=root/'packet';packet.mkdir()
    prep=packet/'prepare_native.py';prep.write_bytes(PREPARER.read_bytes())
    (packet/'qualify_native.py').write_bytes(QUALIFIER.read_bytes())
    module_spec=importlib.util.spec_from_file_location('fake_preparer_'+name,prep)
    mod=importlib.util.module_from_spec(module_spec);module_spec.loader.exec_module(mod)
    mod.ROOT=root;mod.PACKET=packet;mod.PRODUCT=root/'policy-engine';mod.NATIVE=root/'native';mod.NATIVE.mkdir()
    mod.RAW=root/'raw';mod.F16=mod.RAW/'f16';mod.PROFILE=mod.RAW/'profile';mod.C134=root/'c134'
    mod.HELPER=mod.RAW/'helper.py';mod.ENV_HELPER=mod.RAW/'env.py'
    node='tests/integration/runtime/http/test_g27_owner_generation_oracle.py::test_g27_real_sql_withdraw_a_after_b_fresh_owner'
    test='policy-engine/'+node.split('::')[0]; helper='policy-engine/tests/_helpers/g27_owner_generation_oracle.py'
    objects={test:b'def test_g27_real_sql_withdraw_a_after_b_fresh_owner():\n    pass\n',helper:b'def _child_main():\n    pass\n'}
    for path,data in objects.items(): put(root,path,data)
    post=[]
    for index,(path,data) in enumerate(objects.items()):
        rel=f'packet/post{index}.py';put(root,rel,data)
        post.append({'path':path,'pre_sha256':None,'post_sha256':sha(data),'postimage_file':rel})
    manifest={'files':post};manifest_b=(json.dumps(manifest)+'\n').encode();(packet/'manifest.json').write_bytes(manifest_b)
    static_paths=['raw/f16/f16_local_observer.py','raw/f16/f16_c134_context.py','raw/f16/f16_collection_logic.py',
                  'raw/f16/assertion-rewriter-pin.json','raw/profile/pytest_execution_profile.py',
                  'raw/helper.py','raw/env.py']
    static=[]
    for rel in static_paths:
        data=('input '+rel+'\n').encode();put(root,rel,data);static.append({'path':rel,'bytes':len(data),'sha256':sha(data)})
    frame=put(root,'raw/source-frame.json',b'{"frame":true}\n')
    live={'head':HEAD,'tree':TREE,'known_dirty_paths':[],'source_readback':{'path':'raw/source-frame.json','sha256':sha(frame.read_bytes())}}
    put(root,'LOCAL/raw/root-live-ownership-20261021.json',(json.dumps(live)+'\n').encode())
    spec={'branch':'fake-branch','candidate_paths':[test,helper],'selected_nodes':{'pilot':[node]},
          'source_seed_paths':[test,helper],'static_runtime_inputs':static,'lock_sha256':'f'*64,
          'required_distributions':[],'assertion_rewriter_sha256':'e'*64}
    spec_b=(json.dumps(spec)+'\n').encode();(packet/'phase-inputs.json').write_bytes(spec_b)
    index={path:blob(data) for path,data in objects.items()}
    def fake_git(*args):
        if args==('symbolic-ref','--short','HEAD'): return b'fake-branch\n'
        if args==('rev-parse','HEAD'):return (HEAD+'\n').encode()
        if args==('rev-parse',HEAD+'^{tree}'):return (TREE+'\n').encode()
        if args==('rev-parse',BASE+'^{tree}'):return (BASE_TREE+'\n').encode()
        if args==('rev-parse',HEAD+'^'):return (BASE+'\n').encode()
        if args[0]=='diff' and args[1]=='--name-status':return ''.join('A\t'+p+'\n' for p in sorted(objects)).encode()
        if args[0]=='show':return objects[args[1].split(':',1)[1]]
        if args[0]=='ls-files':
            rel=args[-1];return f'100644 {blob(objects[rel])} 0\t{rel}\n'.encode()
        raise AssertionError(args)
    mod.git=fake_git;mod.git_ok=lambda *a:True;mod.git_tree_index=lambda head:index
    mod.environment_snapshot=lambda spec:{'status':'PASS','binding':'synthetic'}
    calls=[]
    profile=mod.PROFILE/'pytest_execution_profile.py'
    def fake_helper(argv,**kwargs):
        calls.append(argv)
        plan_path=mod.NATIVE/'g27p.json'
        plan={'case_id':'g27p','source_head':HEAD,'source_tree':TREE,'nodes':[node],
              'disk_admission_bytes':8*1024**3,'disk_stop_bytes':6*1024**3,
              'rss_cap_bytes':2300*1024**2,'deadline_seconds':600,
              'sandbox_profile_fragment':'(deny network*)\n'}
        (mod.NATIVE/'g27p-root-live-input.json').write_text('{"snapshot":true}\n')
        if attack=='symlink':plan_path.symlink_to(profile)
        elif attack=='hardlink':os.link(profile,plan_path)
        else:plan_path.write_text(json.dumps(plan)+'\n')
        return SimpleNamespace(returncode=0,stdout='fake helper',stderr='')
    original_run=mod.subprocess.run;original_argv=sys.argv[:]
    before=snapshot(root)
    output=io.StringIO();error=None;code=None
    try:
        mod.subprocess.run=fake_helper
        sys.argv=['prepare','--expected-head',HEAD,'--expected-tree',TREE,'--base-head',BASE,'--base-tree',BASE_TREE,
                  '--candidate-head',HEAD,'--candidate-tree',TREE,'--phase-inputs-sha256',sha(spec_b),
                  '--author-manifest-sha256',sha(manifest_b),'--case-id','g27p','--stage','candidate','--selection','pilot']
        try:
            with contextlib.redirect_stdout(output): code=mod.main()
        except SystemExit as exc:error=str(exc)
    finally:
        mod.subprocess.run=original_run;sys.argv=original_argv
    after=snapshot(root);changed=sorted(p for p in before.keys()|after.keys() if before.get(p)!=after.get(p))
    valid_plan=False
    if attack is None:
        plan=json.loads((mod.NATIVE/'g27p.json').read_text());valid_plan=(plan['g27']['stage']=='candidate' and
            len(plan['g27']['runtime_input_bindings'])==len(static)+1+1+2+2+2+1 and
            plan['extra_env']['E02C_INDEX'].endswith('g27p-source-index.json'))
    expected=['native/g27p-root-live-input.json','native/g27p-source-index.json','native/g27p.json']
    return {'code':code,'error':error,'helper_calls':len(calls),'changed_paths':changed,
            'only_owned_fresh_outputs':changed==expected,'input_bytes_unchanged':all(after.get(p)==v for p,v in before.items()),
            'actual_plan_has_bindings_and_index':valid_plan}

normal=one('normal');symlink=one('symlink','symlink');hardlink=one('hardlink','hardlink')
assert normal['code']==0 and normal['helper_calls']==1 and normal['only_owned_fresh_outputs'] and normal['input_bytes_unchanged'] and normal['actual_plan_has_bindings_and_index'],normal
assert symlink['error']=='helper plan is not the exact regular fresh case path' and symlink['input_bytes_unchanged'],symlink
assert hardlink['error']=='helper plan has multiple hardlinks' and hardlink['input_bytes_unchanged'],hardlink
result={'scope':'entire actual prepare_native.main; fake Git, environment, helper and synthetic filesystem only',
        'normal':normal,'symlink_to_input':symlink,'hardlink_to_input':hardlink,
        'product_imports':False,'real_native_helper':False,'product_tests':'UNRUN'}
(HERE/'fake-main-r3-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
