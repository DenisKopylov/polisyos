"""Read the preserved historical C96 DB; this is not a native-fit run."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
from pathlib import Path

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
PACKET = ROOT / "LOCAL/raw/e02-execution-20261027/repairs/R4-native-control-r1/controller-r3"
CASE = ROOT / "LOCAL/raw/e02-execution-20261027/repairs/R4-control-front-r1/runs/r4c96r2"
DB = (
    CASE
    / "pytest-tmp/test_authenticated_cancellatio0/case/runtime-env/.polisyos/control_plane.sqlite3"
)
EXPECTED_DB = "18ee0d00056f9d96bfd98c4f927325b762d25ef308fbc50b5fd45179bcfc4981"
spec = importlib.util.spec_from_file_location(
    "r4_candidate_checks_historical", PACKET / "native_checks.py"
)
assert spec is not None and spec.loader is not None
checks = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = checks
spec.loader.exec_module(checks)


def main() -> None:
    before = hashlib.sha256(DB.read_bytes()).hexdigest()
    if before != EXPECTED_DB:
        raise RuntimeError("historical C96 database differs; do not overwrite")
    snapshot = checks.sqlite_final(
        DB, CASE, "job_execution_admission", "run_execution_admission", 1
    )
    cancellation = json.loads(snapshot["progress"][0]["progress_json"])["cancellation"]
    body = {
        "operation_id": cancellation["operation_id"],
        "expected_lease_owner": cancellation["expected_lease_owner"],
        "expected_attempt": cancellation["expected_attempt"],
    }
    wire = json.dumps(body, ensure_ascii=False, separators=(",", ":"))
    binding = checks.cancellation_binding(
        snapshot,
        job_id="job_execution_admission",
        run_id="run_execution_admission",
        attempt=1,
        owner=cancellation["expected_lease_owner"],
        tenant=cancellation["tenant_id"],
        cell=cancellation["cell_id"],
        actor=cancellation["authorized_actor"],
        request_body=body,
        request_wire_utf8=wire,
    )
    after = hashlib.sha256(DB.read_bytes()).hexdigest()
    result = {
        "scope": "historical C96 persisted DB read-only / reconstructed request bytes; not current native evidence",
        "db_unchanged": before == after,
        "db_sha256": before,
        "progress_rows": len(snapshot["progress"]),
        "event_rows": len(snapshot["events"]),
        "outbox_rows": len(snapshot["outbox"]),
        "binding": binding,
    }
    print(json.dumps(result, sort_keys=True, indent=2))
    if before != after or not binding["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
