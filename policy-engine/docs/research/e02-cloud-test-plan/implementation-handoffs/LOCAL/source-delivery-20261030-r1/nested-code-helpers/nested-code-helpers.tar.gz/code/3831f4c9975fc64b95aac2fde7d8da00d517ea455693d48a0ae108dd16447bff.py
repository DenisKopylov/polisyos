from pathlib import Path
import ast

root=Path.cwd()
pkg=root/'LOCAL/raw/e02-execution-20261027/repairs/C49-local-r1'
rel=Path('policy-engine/src/polisyos/runtime/quality/joint_simulation_horizon.py')
base=(root/rel).read_text()
pre=pkg/'preimages'/rel
pre.parent.mkdir(parents=True,exist_ok=True)
if not pre.exists():pre.write_text(base)
s=base.replace('from dataclasses import dataclass\n','from dataclasses import dataclass\nfrom datetime import UTC, datetime\n',1).replace('from typing import Any, Literal, Protocol\n','from typing import Any, Literal, Protocol\nfrom uuid import uuid4\n',1)
needle='from polisyos.pdc import gy_content_hash\n'
s=s.replace(needle,needle+'''from polisyos.scientist.orchestration.engine.budget import BudgetExhaustedError
from polisyos.scientist.orchestration.engine.producer_budget import (
    ProducerBudgetObservation,
    ProducerBudgetObserver,
    ProducerBudgetSourceError,
)
''',1)
start=s.index('def _run_cached_replicates(')
end=s.index('\n\nclass InteractionTerm',start)
replacement='''class PhysicalSimulationWorkObservation(_StrictModel):
    """One observed physical invocation, separately from money and scientific proof."""

    schema_version: Literal["policyos.runtime.physical_simulation_work.v1"] = (
        "policyos.runtime.physical_simulation_work.v1"
    )
    invocation_id: str = Field(pattern=r"^[a-f0-9]{32}$")
    event_id: str = Field(pattern=r"^[a-f0-9]{32}$")
    physical_spec_ref: str = Field(pattern=r"^[a-f0-9]{64}$")
    effective_seed: int = Field(strict=True)
    status: Literal["completed", "failed"]
    started_at: datetime
    completed_at: datetime
    work_units: Literal[1] = 1
    work_unit: Literal["physical_simulation_invocation"] = "physical_simulation_invocation"
    observation_basis: Literal["in_process_call_boundary"] = "in_process_call_boundary"
    scientific_authenticity: Literal["not_established"] = "not_established"
    usd_cost: None = None
    usd_cost_status: Literal["not_established"] = "not_established"
    budget_status: Literal["current_owner_checked", "not_established"]
    budget_observation: ProducerBudgetObservation | None = None
    error_type: str | None = None

    @model_validator(mode="after")
    def _work_observation_binding(self) -> PhysicalSimulationWorkObservation:
        if self.completed_at < self.started_at:
            raise ValueError("physical_work_time_order_invalid")
        if (self.budget_status == "current_owner_checked") != (
            self.budget_observation is not None
        ):
            raise ValueError("physical_work_budget_source_mismatch")
        if (self.status == "failed") != (self.error_type is not None):
            raise ValueError("physical_work_error_binding_mismatch")
        return self


class _PhysicalWorkInterrupted(JointSimulationControllerError):
    """Retain actual completed roles and work facts across a bounded interruption."""

    def __init__(
        self,
        code: str,
        trajectories: Sequence[SimulationTrajectory],
        observations: Sequence[PhysicalSimulationWorkObservation],
    ) -> None:
        super().__init__(code)
        self.trajectories = tuple(trajectories)
        self.observations = tuple(observations)


def _run_cached_replicates(
    request: JointSimulationRequest,
    plan: EnginePlan,
    decision: EngineDecision,
    run_once: Callable[[RunLevel, tuple[InterventionAtomBinding, ...], int], SimulationTrajectory],
    *,
    producer_budget_observer: ProducerBudgetObserver | None = None,
) -> list[SimulationTrajectory]:
    """Admit each physical seed once; role projections do not create new work.

    The budget read is current at the actual call boundary. The work unit is a
    physical invocation and does not establish a USD price or numerical producer
    authenticity. An interruption retains only fully completed role trajectories.
    """
    if producer_budget_observer is not None and (
        type(producer_budget_observer) is not ProducerBudgetObserver
        or "admit" in vars(producer_budget_observer)
        or "observe" in vars(producer_budget_observer)
    ):
        raise JointSimulationControllerError("n5_budget_observer_not_canonical")
    cache: dict[str, SimulationTrajectory] = {}
    output: list[SimulationTrajectory] = []
    observations: list[PhysicalSimulationWorkObservation] = []
    invocation_id = uuid4().hex
    seeds = _replication_seeds(request)
    for run_level, raw_subset in _atom_subsets(request.intervention_atoms):
        subset = tuple(raw_subset)
        physical_ref = _physical_run_ref(request, plan, decision, subset)
        reused = physical_ref in cache
        if not reused:
            replicated: list[SimulationTrajectory] = []
            physical_observations: list[PhysicalSimulationWorkObservation] = []
            for seed in seeds:
                budget_observation = None
                if producer_budget_observer is not None:
                    try:
                        budget_observation = producer_budget_observer.admit()
                    except BudgetExhaustedError as exc:
                        raise _PhysicalWorkInterrupted(
                            "n5_current_budget_exhausted", output, observations
                        ) from exc
                    except ProducerBudgetSourceError as exc:
                        raise _PhysicalWorkInterrupted(
                            "n5_current_budget_source_not_established", output, observations
                        ) from exc
                started_at = datetime.now(UTC)
                error: Exception | None = None
                try:
                    trajectory = run_once(run_level, subset, seed)
                except Exception as exc:
                    error = exc
                work = PhysicalSimulationWorkObservation(
                    invocation_id=invocation_id,
                    event_id=uuid4().hex,
                    physical_spec_ref=physical_ref,
                    effective_seed=seed,
                    status="completed" if error is None else "failed",
                    started_at=started_at,
                    completed_at=datetime.now(UTC),
                    budget_status=(
                        "current_owner_checked"
                        if budget_observation is not None else "not_established"
                    ),
                    budget_observation=budget_observation,
                    error_type=type(error).__name__ if error is not None else None,
                )
                observations.append(work)
                physical_observations.append(work)
                if error is not None:
                    raise _PhysicalWorkInterrupted(
                        "n5_physical_work_failed", output, observations
                    ) from error
                replicated.append(trajectory)
            aggregate = _aggregate_replicated_trajectory(replicated, seeds, physical_ref)
            cache[physical_ref] = aggregate.model_copy(update={
                "diagnostics": {
                    **aggregate.diagnostics,
                    "physical_work_observations": [
                        item.model_dump(mode="json") for item in physical_observations
                    ],
                }
            })
        cached = cache[physical_ref]
        output.append(
            cached.model_copy(
                update={
                    "run_level": run_level,
                    "atom_ids": tuple(atom.intervention_id for atom in subset),
                    "diagnostics": {
                        **cached.diagnostics,
                        "physical_run_ref": physical_ref,
                        "physical_run_reused": reused,
                        "role": run_level,
                    },
                }
            )
        )
    return output
'''
s=s[:start]+replacement+s[end:]
# Five actual engine paths share the same physical call boundary.
old='        return _run_cached_replicates(request, plan, decision, run_once)'
assert s.count(old)==5
s=s.replace(old,'''        return _run_cached_replicates(
            request, plan, decision, run_once,
            producer_budget_observer=self._producer_budget_observer,
        )''')
needle='        policy: JointSimulationControllerPolicy | None = None,\n'
assert s.count(needle)==1
s=s.replace(needle,needle+'        producer_budget_observer: ProducerBudgetObserver | None = None,\n',1)
needle='        self._settings = _RuntimeSettings()\n'
s=s.replace(needle,'''        if producer_budget_observer is not None and (
            type(producer_budget_observer) is not ProducerBudgetObserver
        ):
            raise TypeError("n5_budget_observer_not_canonical")
        self._producer_budget_observer = producer_budget_observer
'''+needle,1)
needle='                trajectories = tuple(runner(request, selected_plan, decision))\n'
assert s.count(needle)==1
s=s.replace(needle,'''                try:
                    trajectories = tuple(runner(request, selected_plan, decision))
                except _PhysicalWorkInterrupted as exc:
                    trajectories = exc.trajectories
                    diagnostics["physical_work_interruption"] = exc.code
                    diagnostics["physical_work_observations"] = [
                        item.model_dump(mode="json") for item in exc.observations
                    ]
''',1)
# Complete-set extraction deduplicates role reuse by actual event identity.
needle='        if trajectories:\n            marginal_effects = _marginal_effects(trajectories)\n'
assert s.count(needle)==1
s=s.replace(needle,'''        work_events: dict[str, PhysicalSimulationWorkObservation] = {}
        for raw in diagnostics.get("physical_work_observations", ()):
            item = PhysicalSimulationWorkObservation.model_validate(raw)
            work_events[item.event_id] = item
        for trajectory in trajectories:
            for raw in trajectory.diagnostics.get("physical_work_observations", ()):
                item = PhysicalSimulationWorkObservation.model_validate(raw)
                prior = work_events.get(item.event_id)
                if prior is not None and prior != item:
                    raise JointSimulationControllerError("n5_physical_work_event_collision")
                work_events[item.event_id] = item
        diagnostics["physical_work_observations"] = [
            item.model_dump(mode="json") for item in work_events.values()
        ]
        diagnostics["physical_work_units"] = len(work_events)
        diagnostics["physical_work_unit"] = "physical_simulation_invocation"
        diagnostics["physical_work_usd_cost_status"] = "not_established"
        diagnostics["budget_admission_status"] = (
            "current_owner_checked"
            if self._producer_budget_observer is not None
            and "physical_work_interruption" not in diagnostics
            and work_events else "not_established"
        )
        if trajectories:
            marginal_effects = _marginal_effects(trajectories)
''',1)
needle='        authority_blockers = ["simulation_only_k_sim_not_world_evidence"]\n'
s=s.replace(needle,needle+'''        if "physical_work_interruption" in diagnostics:
            authority_blockers.append(str(diagnostics["physical_work_interruption"]))
''',1)
# Existing content-bound artifact persists typed work observations in diagnostics.
# This reader decodes/reconciles the complete view instead of trusting a count.
needle='    @model_validator(mode="after")\n    def _versioned_state_consumption(self) -> JointSimulationResult:\n'
assert s.count(needle)==1
s=s.replace(needle,'''    @property
    def physical_work_observations(self) -> tuple[PhysicalSimulationWorkObservation, ...]:
        """Decode the persisted complete work set; counts alone are never evidence."""
        raw = self.diagnostics.get("physical_work_observations")
        if raw is None:
            return ()
        if type(raw) is not list:
            raise ValueError("n5_physical_work_observations_not_a_sequence")
        observations = tuple(PhysicalSimulationWorkObservation.model_validate(item) for item in raw)
        ids = [item.event_id for item in observations]
        if len(ids) != len(set(ids)):
            raise ValueError("n5_physical_work_observation_duplicate")
        if self.diagnostics.get("physical_work_units") != len(observations):
            raise ValueError("n5_physical_work_unit_count_mismatch")
        if self.diagnostics.get("physical_work_unit") != "physical_simulation_invocation":
            raise ValueError("n5_physical_work_unit_invalid")
        if self.diagnostics.get("physical_work_usd_cost_status") != "not_established":
            raise ValueError("n5_physical_work_usd_not_established")
        known = {item.event_id: item for item in observations}
        calls: set[tuple[str, str, int]] = set()
        for item in observations:
            call = (item.invocation_id, item.physical_spec_ref, item.effective_seed)
            if call in calls:
                raise ValueError("n5_physical_work_call_duplicate")
            calls.add(call)
        for trajectory in self.trajectories:
            physical_ref = trajectory.diagnostics.get("physical_run_ref")
            trajectory_events = trajectory.diagnostics.get("physical_work_observations", ())
            expected_seeds = tuple(trajectory.diagnostics.get("replication_seeds", ()))
            actual_seeds = []
            for item in trajectory_events:
                parsed = PhysicalSimulationWorkObservation.model_validate(item)
                if known.get(parsed.event_id) != parsed or parsed.status != "completed":
                    raise ValueError("n5_physical_work_trajectory_binding_mismatch")
                if parsed.physical_spec_ref != physical_ref:
                    raise ValueError("n5_physical_work_spec_binding_mismatch")
                actual_seeds.append(parsed.effective_seed)
            if tuple(actual_seeds) != expected_seeds:
                raise ValueError("n5_physical_work_replication_binding_mismatch")
        return observations

    @model_validator(mode="after")
    def _versioned_state_consumption(self) -> JointSimulationResult:
        if "physical_work_observations" in self.diagnostics:
            self.physical_work_observations
''',1)
ast.parse(s)
post=pkg/'postimages'/rel
post.parent.mkdir(parents=True,exist_ok=True)
post.write_text(s)
print('Created separate N5 physical-boundary context postimage; five real engine call sites, runtime UNRUN.')
