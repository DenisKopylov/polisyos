"""P2 timing census and 8k synthetic input preflight, without product imports."""

from __future__ import annotations

import ast
import copy
import hashlib
import importlib.util
import json
import math
import statistics
import sys
from pathlib import Path
from unittest.mock import patch

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
PACKET = (
    ROOT / "LOCAL/raw/e02-execution-20261027/repairs/R4-native-control-r1/native-profile-8k512-r1"
)
CASE = ROOT / "LOCAL/raw/e02-execution-20261027/repairs/R4-native-control-r1/runs/r4nativep2"
SCANNER_SOURCE = ROOT / "policy-engine/src/polisyos/core/artifacts/canonical_profile.py"


def load_checks():
    spec = importlib.util.spec_from_file_location(
        "r4_8k_source_checks", PACKET / "native_checks.py"
    )
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def tag(value: float) -> dict:
    return {"_type": "float", "repr": "0" if value == 0.0 else format(value, ".17g")}


def build(original: dict, rows: int) -> dict:
    envelope = dict(original)
    payload = dict(original["contract_payload"])
    payload.update(
        outcome=[tag(float(i) / 10 + (i % 2) * 0.5) for i in range(rows)],
        treatment=[i % 2 for i in range(rows)],
        covariates=[[tag(float(i)), tag(float(i % 5))] for i in range(rows)],
        confounders=[[tag(float(i % 7))] for i in range(rows)],
        sample_ids=[f"candidate-{i}" for i in range(rows)],
    )
    envelope["contract_payload"] = payload
    return envelope


def encoded(value: dict) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


def main() -> None:
    observation_bytes = (CASE / "evidence/native/fixture-observation.json").read_bytes()
    observation = json.loads(observation_bytes)
    events = observation["native"]["grf_tree_fit_events"]
    entered = {}
    completed = []
    worker = observation["executor"]["occupied_worker"]
    for event in events:
        ident = event["fit_call_id"]
        if event["kind"] == "fit_enter":
            assert ident not in entered
            entered[ident] = event
        elif event["kind"] == "fit_return":
            begin = entered.pop(ident)
            assert event["success"] and begin["tree_identity"] == event["tree_identity"]
            assert all(
                begin[k] == event[k] == worker[k] for k in ("pid", "thread_id", "native_thread_id")
            )
            completed.append((begin, event))
        else:
            raise AssertionError("unexpected event kind")
    assert len(events) == 256 and len(completed) == 128 and not entered
    wall = sorted((end["monotonic_ns"] - begin["monotonic_ns"]) / 1e6 for begin, end in completed)
    p99 = wall[math.ceil(0.99 * len(wall)) - 1]
    outer_in, outer_out = observation["native"]["forest_dr_fit_events"]
    full = observation["executor"]["queue"]["full_observed_ns"]
    renewals = [
        row
        for row in observation["lease"]["renewals"]
        if row["result"] is True
        and row["fresh_owner"] == observation["method"]["lease_owner"]
        and row["expected_attempt"] == row["fresh_attempt"] == observation["method"]["attempt"]
        and full < row["monotonic_ns"] < outer_out["monotonic_ns"]
    ]
    p2_blob = Path(observation["input"]["payload_path"]).read_bytes()
    original = json.loads(p2_blob)
    reconstructed_2k = build(original, 2000)
    candidate = build(original, 8000)
    candidate_bytes = encoded(candidate)
    scanner_ast = ast.parse(SCANNER_SOURCE.read_bytes())
    scanner_class = next(
        node
        for node in scanner_ast.body
        if isinstance(node, ast.ClassDef) and node.name == "_JsonStructureBoundsScanner"
    )
    ns = {}
    exec(
        compile(
            ast.fix_missing_locations(ast.Module(body=[scanner_class], type_ignores=[])),
            "<actual-core-scanner-extracted>",
            "exec",
        ),
        ns,
    )
    scanner = ns["_JsonStructureBoundsScanner"]()
    scanner.feed(candidate_bytes)
    policy_ref = observation["method"]["resource_policy_ref"]["artifact_id"][7:]
    policy_path = (
        Path(observation["input"]["cas_root"])
        / "artifacts/sha256"
        / policy_ref[:2]
        / policy_ref[2:4]
        / (policy_ref + ".blob")
    )
    policy_bytes = policy_path.read_bytes()
    assert hashlib.sha256(policy_bytes).hexdigest() == policy_ref
    policy = json.loads(policy_bytes)
    checks = load_checks()
    source = {
        "source_ref": {"kind": "ir.observation_method_input", "media_type": "application/json"},
        "source_kind": "ir.observation_method_input",
    }

    def rejected(value: dict, expected_rows: int) -> bool:
        try:
            with patch.object(checks, "selected_cas", return_value=(value, {})):
                checks.source_custody(source, Path("/synthetic"), expected_rows=expected_rows)
        except (ValueError, TypeError, KeyError):
            return True
        return False

    with patch.object(checks, "selected_cas", return_value=(candidate, {})):
        reconciled = checks.source_custody(source, Path("/synthetic"), expected_rows=8000)
    bad = copy.deepcopy(candidate)
    bad["contract_payload"]["covariates"][7913][1] = tag(99999.0)
    wrong_count = copy.deepcopy(candidate)
    wrong_count["contract_payload"]["sample_ids"].pop()
    verifications = {
        "reconstructed_all_2000_rows_match_p2_bytes": encoded(reconstructed_2k) == p2_blob,
        "actual_p2_uses_2000_rows_128_trees": observation["input"]["rows"] == 2000
        and observation["method"]["effective_params"]["n_estimators"] == 128,
        "actual_p2_stopped_before_negatives": observation["case"]["stage"]
        == "fit_finished_before_negatives"
        and observation["negatives"] == []
        and observation["cancel"]["post_start_ns"] == 0,
        "proposed_payload_under_actual_p2_bytes_limit": len(candidate_bytes) < policy["max_bytes"],
        "proposed_payload_under_actual_p2_element_limit": scanner.elements < policy["max_elements"],
        "proposed_payload_under_actual_p2_depth_limit": scanner.max_depth < policy["max_depth"],
        "independent_8000_row_formula": reconciled["rows"] == 8000,
        "interior_formula_tamper_rejected": rejected(bad, 8000),
        "truncated_row_denominator_rejected": rejected(wrong_count, 8000),
        "unadmitted_row_limit_rejected": rejected(candidate, 8001),
    }
    output = {
        "pass": all(verifications.values()),
        "checks": verifications,
        "p2": {
            "observation_sha256": hashlib.sha256(observation_bytes).hexdigest(),
            "matched_tree_calls": len(completed),
            "tree_wall_ms_min": wall[0],
            "tree_wall_ms_median": statistics.median(wall),
            "tree_wall_ms_p99_nearest_rank": p99,
            "tree_wall_ms_max": wall[-1],
            "tree_wall_ms_sum": sum(wall),
            "outer_fit_ms": (outer_out["monotonic_ns"] - outer_in["monotonic_ns"]) / 1e6,
            "full_to_outer_return_ms": (outer_out["monotonic_ns"] - full) / 1e6,
            "qualifying_renewals_while_full_and_fit_live": len(renewals),
        },
        "proposed_synthetic_reconstruction": {
            "rows": 8000,
            "trees": 512,
            "input_bytes": len(candidate_bytes),
            "lexical_elements": scanner.elements,
            "max_depth": scanner.max_depth,
            "sha256": hashlib.sha256(candidate_bytes).hexdigest(),
            "p2_policy_sha256": policy_ref,
            "p2_policy_max_bytes": policy["max_bytes"],
            "p2_policy_max_elements": policy["max_elements"],
        },
        "scope": "p2 retained event/selected CAS bytes and owner scanner AST; candidate envelope reconstructed in memory with fixture formula. No product imports, live SQL, backend/native run, or actual future CAS claim.",
        "closure_ids": [],
    }
    print(json.dumps(output, indent=2, sort_keys=True))
    if not output["pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
