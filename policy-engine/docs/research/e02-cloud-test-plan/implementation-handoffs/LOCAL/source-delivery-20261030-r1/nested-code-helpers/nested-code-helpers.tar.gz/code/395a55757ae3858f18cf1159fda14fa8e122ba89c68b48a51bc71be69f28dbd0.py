"""Isolated negative control for the actual N5 tenant-B denial assertion.

Load only for the single pinned N5 test node. The instrument leaves all
tenant-A reads and ownership metadata intact, and bypasses exactly the two CAS
read-guard methods only while the target CAS is read in tenant B scope.
"""

from __future__ import annotations

import ast
import hashlib
import importlib
import json
import os
import subprocess
import threading
from pathlib import Path
from typing import Any

import pytest


TARGET_NODEID = (
    "tests/unit/runtime/quality/test_generation_cycle.py::"
    "test_owner_program_graph_n5_consumes_selected_state_blob_view"
)
TARGET_TEST = "policy-engine/tests/unit/runtime/quality/test_generation_cycle.py"
TARGET_R13_TEST = "policy-engine/tests/unit/runtime/http/test_r13_ingestion_tenant_custody.py"
OWNER_TENANT = "tenant-n5-owner"
FOREIGN_TENANT = "tenant-n5-foreign"
OWNER_CELL = "cell-n5-owner"
SOURCE_HEAD = "67beb3461ab96c4cb64b92226228da39b30bcb06"
SOURCE_TREE = "306e3c150f6a1368f23c8ebece35aeec3feb180b"
PATCH_SHA256 = "999a926733cf2b0fbc0736eb3ee0e57202370a892b0e58db5e45b027b9d37ff8"
TEST_POSTIMAGE_BLOB = "7d7da42238ee2e723d816e30ea0cc8b9b8b66949"
TEST_POSTIMAGE_SHA256 = "ab290f77df01806f39c5139535ab61f118f2affac608a93c297aa83b3eaeea15"
R13_POSTIMAGE_BLOB = "7d13f7398bb37a3d15083acca2d1b3f0f486b3e6"
R13_POSTIMAGE_SHA256 = "756009c36556828117d064a8983caa9ef1fab56ff607abd7a2672b8e1c1a0f53"
BASE_BLOBS = {
    TARGET_TEST: "b02afa5a9a96cd34b44dca94e0f56ebb2d608d93",
    TARGET_R13_TEST: "c64c90ca3bd00c637300b5014207ffe12dbd6e19",
    "policy-engine/src/polisyos/core/artifacts/store.py": (
        "13b65aef57d3db3a126cce455ced16712b27566b"
    ),
    "policy-engine/src/polisyos/core/artifacts/__init__.py": (
        "4eba5d4379b3fde2012d4d549dd04d649a5af0e0"
    ),
    "policy-engine/src/polisyos/core/security/tenant_context.py": (
        "5645cf0bf4f8633dc02e800ae28f4496f8d421a9"
    ),
    "policy-engine/src/polisyos/runtime/http/resilience.py": (
        "f901c59d7f43edf9ed4dc468594f72c2535df4b9"
    ),
}

_STATE: dict[str, dict[str, Any]] = {}
_CONFIG: dict[str, Any] = {}


def _usage_error(message: str) -> None:
    raise pytest.UsageError(f"R3_ORACLE_INPUT_ERROR: {message}")


def _required_env(name: str) -> str:
    value = os.environ.get(name)
    if not value:
        _usage_error(f"required environment input is missing: {name}")
    return value


def _run_git(root: Path, *args: str) -> str:
    try:
        return subprocess.check_output(
            ["git", *args], cwd=root, text=True, stderr=subprocess.STDOUT
        ).strip()
    except (OSError, subprocess.CalledProcessError) as exc:
        _usage_error(f"git source binding unavailable for {args!r}: {exc}")
    raise AssertionError("unreachable")


def _git_blob(data: bytes) -> str:
    header = b"blob " + str(len(data)).encode("ascii") + b"\0"
    return hashlib.sha1(header + data).hexdigest()


def _file_pins(root: Path, plan: dict[str, Any], plugin_path: Path) -> dict[str, Any]:
    if _run_git(root, "rev-parse", "HEAD") != SOURCE_HEAD:
        _usage_error("HEAD changed; regenerate this oracle against the admitted source")
    if _run_git(root, "rev-parse", "HEAD^{tree}") != SOURCE_TREE:
        _usage_error("base tree changed; regenerate this oracle against the admitted source")

    for relative_path, expected_blob in BASE_BLOBS.items():
        if _run_git(root, "rev-parse", f"HEAD:{relative_path}") != expected_blob:
            _usage_error(f"base Git blob changed: {relative_path}")
        actual_blob = _git_blob((root / relative_path).read_bytes())
        if relative_path == TARGET_TEST:
            wanted = TEST_POSTIMAGE_BLOB
            wanted_sha256 = TEST_POSTIMAGE_SHA256
        elif relative_path == TARGET_R13_TEST:
            wanted = R13_POSTIMAGE_BLOB
            wanted_sha256 = R13_POSTIMAGE_SHA256
        else:
            wanted = expected_blob
            wanted_sha256 = None
        if actual_blob != wanted:
            _usage_error(f"working-tree source postimage mismatch: {relative_path}")
        if wanted_sha256 is not None:
            digest = hashlib.sha256((root / relative_path).read_bytes()).hexdigest()
            if digest != wanted_sha256:
                _usage_error(f"working-tree SHA-256 mismatch: {relative_path}")

    patch_path = Path(_required_env("R3_ORACLE_PATCH_PATH")).resolve()
    if hashlib.sha256(patch_path.read_bytes()).hexdigest() != PATCH_SHA256:
        _usage_error("the frozen R3 test-only patch changed")

    plugin_digest = hashlib.sha256(plugin_path.read_bytes()).hexdigest()
    if _required_env("R3_ORACLE_PLUGIN_SHA256") != plugin_digest:
        _usage_error("the loaded oracle plugin does not match the plan pin")

    expected_env = plan.get("extra_env", {})
    if expected_env.get("R3_ORACLE_ROOT") != str(root):
        _usage_error("plan root binding mismatch")
    if expected_env.get("R3_ORACLE_PLAN_PATH") != _required_env("R3_ORACLE_PLAN_PATH"):
        _usage_error("plan self-path binding mismatch")
    if expected_env.get("R3_ORACLE_PATCH_PATH") != str(patch_path):
        _usage_error("plan patch path binding mismatch")
    if (
        _required_env("R3_ORACLE_PATCH_SHA256") != PATCH_SHA256
        or expected_env.get("R3_ORACLE_PATCH_SHA256") != PATCH_SHA256
    ):
        _usage_error("plan patch hash binding mismatch")
    if expected_env.get("R3_ORACLE_PLUGIN_SHA256") != plugin_digest:
        _usage_error("plan plugin hash binding mismatch")
    if expected_env.get("PYTEST_PLUGINS") != plugin_path.stem:
        _usage_error("plan does not load this exact oracle plugin")
    if expected_env.get("PYTHONPATH") != str(plugin_path.parent):
        _usage_error("plan plugin import path mismatch")
    if _required_env("PYTEST_PLUGINS") != plugin_path.stem:
        _usage_error("runtime did not load the exact oracle plugin")
    if _required_env("PYTHONPATH") != str(plugin_path.parent):
        _usage_error("runtime plugin import path mismatch")
    if expected_env.get("R3_ORACLE_RECEIPT_PATH") != _required_env(
        "R3_ORACLE_RECEIPT_PATH"
    ):
        _usage_error("plan receipt path binding mismatch")

    return {
        "head": SOURCE_HEAD,
        "tree": SOURCE_TREE,
        "base_git_blobs": BASE_BLOBS,
        "working_tree_git_blobs": {
            TARGET_TEST: TEST_POSTIMAGE_BLOB,
            TARGET_R13_TEST: R13_POSTIMAGE_BLOB,
            **{path: blob for path, blob in BASE_BLOBS.items() if path not in {TARGET_TEST, TARGET_R13_TEST}},
        },
        "test_postimage_sha256": TEST_POSTIMAGE_SHA256,
        "r13_postimage_sha256": R13_POSTIMAGE_SHA256,
        "patch_sha256": PATCH_SHA256,
        "plugin_sha256": plugin_digest,
    }


def _denial_assertion_line(test_source: Path) -> int:
    tree = ast.parse(test_source.read_text(encoding="utf-8"), filename=str(test_source))
    helper = next(
        (
            node
            for node in ast.walk(tree)
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
            and node.name == "_owner_program_graph_n5_witness"
        ),
        None,
    )
    if helper is None:
        _usage_error("pinned N5 helper is missing")

    matching: list[int] = []
    for node in ast.walk(helper):
        if not isinstance(node, (ast.With, ast.AsyncWith)):
            continue
        for item in node.items:
            expr = item.context_expr
            if not isinstance(expr, ast.Call):
                continue
            func = expr.func
            if not (
                isinstance(func, ast.Attribute)
                and func.attr == "raises"
                and isinstance(func.value, ast.Name)
                and func.value.id == "pytest"
            ):
                continue
            if any(
                isinstance(arg, ast.Name) and arg.id == "ArtifactOwnershipError"
                for arg in expr.args
            ):
                matching.append(node.lineno)
    if len(matching) != 1:
        _usage_error(
            "expected exactly one pinned helper pytest.raises(ArtifactOwnershipError) assertion"
        )
    source_line = test_source.read_text(encoding="utf-8").splitlines()[matching[0] - 1]
    if source_line.strip() != "with pytest.raises(ArtifactOwnershipError):":
        _usage_error("pinned ownership denial assertion source line changed")
    return matching[0]


def pytest_configure(config: pytest.Config) -> None:
    plugin_path = Path(__file__).resolve()
    root = Path(_required_env("R3_ORACLE_ROOT")).resolve()
    if root != Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos"):
        _usage_error("repository root does not match the prepared workspace")

    plan_path = Path(_required_env("R3_ORACLE_PLAN_PATH")).resolve()
    if plan_path.parent != plugin_path.parent:
        _usage_error("plan must be colocated with this RAW-only runner/plugin")
    try:
        plan = json.loads(plan_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        _usage_error(f"plan is missing or malformed: {exc}")
    if plan.get("case_id") != "r3-owner-scope-removal-oracle-20261028-r1":
        _usage_error("unexpected oracle case id")
    if plan.get("source_head") != SOURCE_HEAD or plan.get("source_tree") != SOURCE_TREE:
        _usage_error("plan source binding mismatch")
    if plan.get("nodes") != [TARGET_NODEID]:
        _usage_error("plan must select the single pinned N5 witness node")

    case_output = plugin_path.parent / plan["case_id"]
    receipt_path = Path(_required_env("R3_ORACLE_RECEIPT_PATH")).resolve()
    if receipt_path.parent != case_output.resolve():
        _usage_error("receipt must stay inside this case's isolated output directory")
    if not case_output.is_dir():
        _usage_error("supervisor case output directory was not created")
    if receipt_path.exists():
        _usage_error("receipt already exists; do not overwrite a prior oracle run")

    pins = _file_pins(root, plan, plugin_path)
    test_path = root / TARGET_TEST
    expected_line = _denial_assertion_line(test_path)
    _CONFIG.update(
        {
            "root": root,
            "plan": plan,
            "plan_sha256": hashlib.sha256(plan_path.read_bytes()).hexdigest(),
            "receipt_path": receipt_path,
            "case_output": case_output,
            "source_pins": pins,
            "expected_assertion_line": expected_line,
            "config": config,
        }
    )


def pytest_collection_finish(session: pytest.Session) -> None:
    matches = [item for item in session.items if item.nodeid == TARGET_NODEID]
    if len(matches) != 1:
        _usage_error(f"expected one collected node {TARGET_NODEID!r}, found {len(matches)}")


def _artifact_key(artifact_id: Any, ref: Any, profile: str | None = None) -> tuple[str, str]:
    selected_id = getattr(ref, "artifact_id", None) or artifact_id
    hex_value = getattr(selected_id, "hex", None)
    if not isinstance(hex_value, str) or not hex_value:
        _usage_error("selected CAS read did not carry a typed artifact ID")
    selected_profile = profile
    if selected_profile is None and ref is not None:
        selected_profile = getattr(ref, "manifest_profile_sha256", None)
    if not isinstance(selected_profile, str) or not selected_profile:
        _usage_error("selected CAS read did not carry a manifest profile")
    return hex_value, selected_profile


def pytest_runtest_setup(item: pytest.Item) -> None:
    if item.nodeid != TARGET_NODEID:
        return

    cas_class = getattr(item.module, "FileSystemCAS", None)
    if cas_class is None or cas_class.__module__ != "polisyos.core.artifacts.store":
        _usage_error("target test did not expose the pinned FileSystemCAS class")
    tenant_context = importlib.import_module("polisyos.core.security.tenant_context")
    tenant_getter = tenant_context.get_current_tenant_id_or_none
    cell_getter = tenant_context.get_current_cell_id
    original_blob = cas_class._require_blob_owner
    original_view = cas_class._require_manifest_view_owner
    patcher = pytest.MonkeyPatch()
    state: dict[str, Any] = {
        "item_nodeid": item.nodeid,
        "expected_assertion_line": _CONFIG["expected_assertion_line"],
        "owner_reads": [],
        "bypassed_guards": [],
        "unexpected_foreign_guards": [],
        "methods_restored": False,
        "call_report": None,
        "valid_oracle": False,
        "lock": threading.Lock(),
    }

    def _is_target_store(instance: Any) -> bool:
        try:
            return Path(instance.root).name == "owner-runtime-cas"
        except (AttributeError, TypeError, OSError):
            return False

    def _record(collection: str, row: dict[str, Any]) -> None:
        with state["lock"]:
            state[collection].append(row)

    def _owner_blob_guard(
        instance: Any,
        artifact_id: Any,
        *,
        operation: str,
        ref: Any = None,
    ) -> None:
        tenant_id = tenant_getter()
        cell_id = cell_getter()
        target_store = _is_target_store(instance)
        if tenant_id == FOREIGN_TENANT and operation == "read":
            if not target_store:
                _record(
                    "unexpected_foreign_guards",
                    {"method": "_require_blob_owner", "operation": operation},
                )
                return original_blob(instance, artifact_id, operation=operation, ref=ref)
            key = _artifact_key(artifact_id, ref)
            if cell_id != OWNER_CELL:
                _usage_error("foreign denial phase has unexpected cell scope")
            _record(
                "bypassed_guards",
                {
                    "method": "_require_blob_owner",
                    "tenant_id": tenant_id,
                    "cell_id": cell_id,
                    "root_name": Path(instance.root).name,
                    "artifact_id_hex": key[0],
                    "manifest_profile_sha256": key[1],
                },
            )
            return None

        result = original_blob(instance, artifact_id, operation=operation, ref=ref)
        if (
            tenant_id == OWNER_TENANT
            and cell_id == OWNER_CELL
            and target_store
            and operation == "read"
            and ref is not None
            and getattr(ref, "manifest_profile_sha256", None) is not None
        ):
            key = _artifact_key(artifact_id, ref)
            _record(
                "owner_reads",
                {
                    "method": "_require_blob_owner",
                    "tenant_id": tenant_id,
                    "cell_id": cell_id,
                    "artifact_id_hex": key[0],
                    "manifest_profile_sha256": key[1],
                    "original_guard_returned": True,
                },
            )
        return result

    def _owner_view_guard(
        instance: Any,
        artifact_id: Any,
        manifest_profile_sha256: str | None,
        *,
        operation: str,
        ref: Any = None,
    ) -> None:
        tenant_id = tenant_getter()
        cell_id = cell_getter()
        target_store = _is_target_store(instance)
        if tenant_id == FOREIGN_TENANT and operation == "read_manifest":
            if not target_store:
                _record(
                    "unexpected_foreign_guards",
                    {"method": "_require_manifest_view_owner", "operation": operation},
                )
                return original_view(
                    instance,
                    artifact_id,
                    manifest_profile_sha256,
                    operation=operation,
                    ref=ref,
                )
            key = _artifact_key(artifact_id, ref, manifest_profile_sha256)
            if cell_id != OWNER_CELL:
                _usage_error("foreign denial phase has unexpected cell scope")
            _record(
                "bypassed_guards",
                {
                    "method": "_require_manifest_view_owner",
                    "tenant_id": tenant_id,
                    "cell_id": cell_id,
                    "root_name": Path(instance.root).name,
                    "artifact_id_hex": key[0],
                    "manifest_profile_sha256": key[1],
                },
            )
            return None

        result = original_view(
            instance,
            artifact_id,
            manifest_profile_sha256,
            operation=operation,
            ref=ref,
        )
        if (
            tenant_id == OWNER_TENANT
            and cell_id == OWNER_CELL
            and target_store
            and operation == "read_manifest"
            and ref is not None
            and getattr(ref, "manifest_profile_sha256", None) is not None
        ):
            key = _artifact_key(artifact_id, ref, manifest_profile_sha256)
            _record(
                "owner_reads",
                {
                    "method": "_require_manifest_view_owner",
                    "tenant_id": tenant_id,
                    "cell_id": cell_id,
                    "artifact_id_hex": key[0],
                    "manifest_profile_sha256": key[1],
                    "original_guard_returned": True,
                },
            )
        return result

    try:
        patcher.setattr(cas_class, "_require_blob_owner", _owner_blob_guard)
        patcher.setattr(cas_class, "_require_manifest_view_owner", _owner_view_guard)
    except BaseException:
        patcher.undo()
        raise
    state.update(
        {
            "cas_class": cas_class,
            "patcher": patcher,
            "original_blob": original_blob,
            "original_view": original_view,
            "tenant_getter": tenant_getter,
            "cell_getter": cell_getter,
        }
    )
    _STATE[item.nodeid] = state


def _call_trace(call: pytest.CallInfo[Any], test_path: Path) -> tuple[list[dict[str, Any]], str]:
    frames: list[dict[str, Any]] = []
    traceback = getattr(call.excinfo, "tb", None) if call.excinfo is not None else None
    while traceback is not None:
        frame = traceback.tb_frame
        path = Path(frame.f_code.co_filename)
        frames.append(
            {
                "path": str(path),
                "function": frame.f_code.co_name,
                "line": traceback.tb_lineno,
                "target_test_file": path.resolve() == test_path.resolve(),
            }
        )
        traceback = traceback.tb_next
    exception_text = str(call.excinfo.value) if call.excinfo is not None else ""
    return frames, exception_text


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item: pytest.Item, call: pytest.CallInfo[Any]) -> Any:
    outcome = yield
    report = outcome.get_result()
    if item.nodeid != TARGET_NODEID or report.when != "call":
        return
    state = _STATE.get(item.nodeid)
    if state is None:
        _usage_error("oracle hooks were not installed for the selected test")
    test_path = _CONFIG["root"] / TARGET_TEST
    frames, exception_text = _call_trace(call, test_path)
    expected_line = state["expected_assertion_line"]
    expected_frame = any(
        frame["target_test_file"]
        and frame["function"] == "_owner_program_graph_n5_witness"
        and frame["line"] == expected_line
        for frame in frames
    )
    expected_message = (
        report.failed
        and "DID NOT RAISE" in exception_text
        and "ArtifactOwnershipError" in exception_text
    )
    owner_keys = {
        (row["artifact_id_hex"], row["manifest_profile_sha256"])
        for row in state["owner_reads"]
        if row["method"] == "_require_blob_owner"
    }
    bypass_keys = {
        (row["artifact_id_hex"], row["manifest_profile_sha256"])
        for row in state["bypassed_guards"]
    }
    methods_bypassed = {row["method"] for row in state["bypassed_guards"]}
    bypass_pair_matches = (
        len(bypass_keys) == 1
        and methods_bypassed
        == {"_require_blob_owner", "_require_manifest_view_owner"}
    )
    evidence_ok = (
        len(owner_keys) >= 5
        and bypass_pair_matches
        and bool(owner_keys & bypass_keys)
        and not state["unexpected_foreign_guards"]
    )
    state["call_report"] = {
        "outcome": report.outcome,
        "expected_did_not_raise_message": expected_message,
        "expected_helper_assertion_frame": expected_frame,
        "exception_text": exception_text[:500],
        "traceback_frames": frames,
        "owner_selected_blob_reads": len(owner_keys),
        "bypassed_guard_calls": len(state["bypassed_guards"]),
        "bypassed_methods": sorted(methods_bypassed),
        "one_matching_selected_ref": bypass_pair_matches and bool(owner_keys & bypass_keys),
        "unexpected_foreign_guards": state["unexpected_foreign_guards"],
    }
    state["valid_oracle"] = bool(expected_message and expected_frame and evidence_ok)
    _write_receipt(item.nodeid, state, final=False)


def _write_receipt(nodeid: str, state: dict[str, Any], *, final: bool) -> None:
    receipt_path: Path = _CONFIG["receipt_path"]
    payload = {
        "case_id": _CONFIG["plan"]["case_id"],
        "nodeid": nodeid,
        "source_pins": _CONFIG["source_pins"],
        "plan_sha256": _CONFIG["plan_sha256"],
        "expected_assertion": {
            "path": TARGET_TEST,
            "function": "_owner_program_graph_n5_witness",
            "line": state["expected_assertion_line"],
            "failure": "DID NOT RAISE ArtifactOwnershipError",
        },
        "mutation_scope": {
            "methods": ["_require_blob_owner", "_require_manifest_view_owner"],
            "tenant_id": FOREIGN_TENANT,
            "cell_id": OWNER_CELL,
            "cas_root_basename": "owner-runtime-cas",
            "owner_reads_and_ownership_metadata": "unmodified; original A guards are called",
            "fixture_or_manifest_writes": "none",
        },
        "owner_reads": state["owner_reads"],
        "bypassed_guards": state["bypassed_guards"],
        "call_report": state["call_report"],
        "methods_restored": state["methods_restored"],
        "final": final,
        "valid_oracle": state["valid_oracle"] if final else False,
        "status": (
            "expected_real_denial_assertion_failed_under_guard_removal"
            if final and state["valid_oracle"] and state["methods_restored"]
            else "ORACLE_INPUT_OR_EVIDENCE_ERROR"
        ),
    }
    receipt_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")


@pytest.hookimpl(trylast=True)
def pytest_runtest_teardown(item: pytest.Item, nextitem: pytest.Item | None) -> None:
    if item.nodeid != TARGET_NODEID:
        return
    state = _STATE.get(item.nodeid)
    if state is None:
        _usage_error("selected test did not reach oracle teardown")
    try:
        state["patcher"].undo()
        state["methods_restored"] = (
            state["cas_class"]._require_blob_owner is state["original_blob"]
            and state["cas_class"]._require_manifest_view_owner is state["original_view"]
        )
        _write_receipt(item.nodeid, state, final=True)
    finally:
        if not state["methods_restored"]:
            _usage_error("guard methods were not restored after the isolated test")
    if not state["valid_oracle"]:
        _usage_error(
            "the real N5 denial assertion did not fail with DID NOT RAISE after the two guards were bypassed"
        )


def pytest_unconfigure(config: pytest.Config) -> None:
    for state in _STATE.values():
        patcher = state.get("patcher")
        if patcher is not None and not state.get("methods_restored"):
            patcher.undo()
            state["methods_restored"] = (
                state["cas_class"]._require_blob_owner is state["original_blob"]
                and state["cas_class"]._require_manifest_view_owner is state["original_view"]
            )
