"""Root-only real stdlib dead-child/no-message falsifier; no product imports."""
from __future__ import annotations
import importlib.util
import json
import multiprocessing
from pathlib import Path
import time


def silent_exit(sender):
    """Exit naturally without emitting any transport outcome."""
    sender.close()


def main():
    path = Path(__file__).resolve().parents[1] / 'files/policy-engine/tests/_helpers/worker_transport_wait.py'
    spec = importlib.util.spec_from_file_location('fixture_wait_under_test', path)
    wait = importlib.util.module_from_spec(spec); spec.loader.exec_module(wait)
    ctx = multiprocessing.get_context('spawn'); parent, sender = ctx.Pipe()
    process = ctx.Process(target=silent_exit, args=(sender,)); process.start();sender.close()
    try:
        process.join(5.0)
        assert not process.is_alive() and process.exitcode == 0, 'silent child did not exit'
        entered = time.monotonic()
        try:
            wait.receive_worker_message(parent, process)
        except AssertionError as error:
            assert 'without an outcome' in str(error)
        else:
            raise AssertionError('dead silent child admitted an outcome')
        print(json.dumps({'status':'PASS','pid':process.pid,'exitcode':process.exitcode,'refusal_elapsed_seconds':time.monotonic()-entered,'property':'natural child exit and no message refuses despite enlarged fixture budget'}))
    finally:
        wait.reap_worker_process(process);parent.close()


if __name__ == '__main__':main()
