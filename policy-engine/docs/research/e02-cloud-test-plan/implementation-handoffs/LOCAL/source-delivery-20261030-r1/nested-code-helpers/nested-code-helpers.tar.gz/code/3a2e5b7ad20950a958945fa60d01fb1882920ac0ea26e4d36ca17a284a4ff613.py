"""Bind frozen source/spec identities and check the selected-body AST inventory."""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
PACKET = ROOT / "LOCAL/raw/e02-execution-20261027/repairs/G27-local-owner-oracle-r3"
PROFILE = PACKET / "profile-r3"


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def functions(tree: ast.AST) -> set[str]:
    names: set[str] = set()

    def visit(node: ast.AST, prefix: list[str]) -> None:
        if isinstance(node, ast.ClassDef):
            prefix = [*prefix, node.name]
            names.add(".".join(prefix))
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            prefix = [*prefix, node.name]
            names.add(".".join(prefix))
            prefix = [*prefix, "<locals>"]
        for child in ast.iter_child_nodes(node):
            visit(child, prefix)

    visit(tree, [])
    return names


def main() -> None:
    parser = argparse.ArgumentParser()
    for flag in ("base-head", "base-tree", "manifest-sha256", "spec-sha256"):
        parser.add_argument("--" + flag, required=True)
    args = parser.parse_args()
    command = ["git", "-C", str(ROOT), "rev-parse", args.base_head + "^{tree}"]
    assert subprocess.check_output(command).decode().strip() == args.base_tree
    spec_bytes = (PROFILE / "phase-inputs.json").read_bytes()
    manifest_bytes = (PACKET / "manifest.json").read_bytes()
    assert digest(spec_bytes) == args.spec_sha256
    assert digest(manifest_bytes) == args.manifest_sha256
    spec = json.loads(spec_bytes)
    manifest = json.loads(manifest_bytes)
    candidate = {row["path"]: row for row in manifest["files"]}
    assert len(candidate) == 2 and set(candidate) == set(spec["candidate_paths"])
    rows = (
        spec["mandatory_shared_parent"]
        + spec["mandatory_pilot_parent"]
        + spec["mandatory_pilot_child"]
    )
    assert all(
        path in spec["source_seed_paths"] for path in spec["profile_decoder_paths"]
    )
    inputs = []
    missing = []
    for rel in sorted({row["path"] for row in rows}):
        if rel in candidate:
            row = candidate[rel]
            assert row["pre_sha256"] is None
            data = (ROOT / row["postimage_file"]).read_bytes()
            assert digest(data) == row["post_sha256"]
            origin = "frozen_author_postimage"
        else:
            data = subprocess.check_output(
                ["git", "-C", str(ROOT), "show", args.base_head + ":" + rel]
            )
            assert (ROOT / rel).read_bytes() == data, "worktree source mismatch: " + rel
            origin = "base_git_and_worktree"
        available = functions(ast.parse(data, filename=rel))
        missing.extend(
            row
            for row in rows
            if row["path"] == rel and row["qualname"] not in available
        )
        inputs.append(
            {"path": rel, "bytes": len(data), "sha256": digest(data), "origin": origin}
        )
    result = {
        "scope": "explicit mandatory selected bodies in the source spec, AST presence only",
        "base_head": args.base_head,
        "base_tree": args.base_tree,
        "author_manifest_sha256": digest(manifest_bytes),
        "phase_inputs_sha256": digest(spec_bytes),
        "source_file_denominator": len(inputs),
        "selected_row_denominator": len(rows),
        "missing_rows": missing,
        "inputs": inputs,
        "product_imports": False,
        "runtime": "UNRUN",
        "closure_ids": [],
    }
    print(json.dumps(result, indent=2))
    if missing:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
