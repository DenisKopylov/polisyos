from __future__ import annotations

import asyncio
from collections.abc import Iterator, Mapping
from decimal import Decimal
from typing import ClassVar

import pytest
from pydantic import BaseModel

from polisyos.core.artifacts import (
    CanonInfo,
    FileSystemCAS,
    PutOptions,
    read_core_json_artifact,
)
from polisyos.core.artifacts.async_store import (
    AsyncArtifactStoreAdapter,
    AsyncFileSystemArtifactStore,
)
from polisyos.core.artifacts.backends.caching_store import CachingArtifactStore
from polisyos.core.artifacts.backends.gcs_store import GCSArtifactStore
from polisyos.core.artifacts.backends.s3_store import S3ArtifactStore
from polisyos.core.artifacts.ir_adapter import CoreToIRArtifactStoreAdapter
from polisyos.core.canon import CanonSpec, CanonViolation
from polisyos.core.security.namespace import NamespacedArtifactStore
from polisyos.fabric.storage.tenant_cas import TenantScopedCAS
from polisyos.ir.artifacts.io import put_json_artifact
from polisyos.ir.model_layer.canon import CanonSpec as IRCanonSpec
from polisyos.ir.model_layer.canon import CanonViolation as IRCanonViolation


class _ProjectionSpy(BaseModel):
    value: int
    events: ClassVar[list[str]] = []

    def model_dump(self, *args: object, **kwargs: object) -> dict[str, object]:
        self.events.append("projection")
        return super().model_dump(*args, **kwargs)


class _TraversalSpy(Mapping[str, object]):
    def __getitem__(self, key: str) -> object:
        _ProjectionSpy.events.append("mapping-get")
        raise AssertionError(key)

    def __iter__(self) -> Iterator[str]:
        _ProjectionSpy.events.append("mapping-iterate")
        raise AssertionError("mapping was traversed")

    def __len__(self) -> int:
        _ProjectionSpy.events.append("mapping-length")
        raise AssertionError("mapping length was read")


class _DecimalSpy(Decimal):
    def __str__(self) -> str:
        _ProjectionSpy.events.append("decimal-expand")
        return super().__str__()


class _Sink:
    def __init__(self) -> None:
        self.events: list[str] = []

    def put_json(self, *_args: object, **_kwargs: object) -> object:
        self.events.append("json")
        return object()

    def put_bytes(self, *_args: object, **_kwargs: object) -> object:
        self.events.append("bytes")
        return object()


@pytest.fixture(autouse=True)
def _reset_projection_spy() -> None:
    _ProjectionSpy.events.clear()


@pytest.mark.parametrize("backend", ["filesystem", "s3", "gcs"])
@pytest.mark.parametrize("payload", ["model", "mapping", "decimal"])
def test_concrete_json_writers_refuse_v3_before_projection_or_emission(
    backend: str, payload: str, tmp_path, monkeypatch
) -> None:
    if backend == "filesystem":
        store = FileSystemCAS(tmp_path / "cas")
    elif backend == "s3":
        store = S3ArtifactStore.__new__(S3ArtifactStore)
    else:
        store = GCSArtifactStore.__new__(GCSArtifactStore)
    emissions: list[object] = []
    monkeypatch.setattr(store, "put_bytes", lambda *args, **kwargs: emissions.append(args))
    value: object = {
        "model": lambda: _ProjectionSpy(value=7),
        "mapping": _TraversalSpy,
        "decimal": lambda: _DecimalSpy("7.5"),
    }[payload]()

    with pytest.raises(CanonViolation, match="canonical_writer_profile_unavailable"):
        store.put_json(
            value,
            PutOptions(kind="test.v3", media_type="application/json"),
            CanonSpec(version="0.3.0"),
        )

    assert _ProjectionSpy.events == []
    assert emissions == []


def test_core_v2_real_store_still_projects_and_reads_fresh(tmp_path) -> None:
    root = tmp_path / "cas"
    store = FileSystemCAS(root)
    ref = store.put_json(
        _ProjectionSpy(value=7),
        PutOptions(kind="test.v2", media_type="application/json"),
        CanonSpec(),
    )
    assert _ProjectionSpy.events
    assert FileSystemCAS(root).get_bytes(ref) == b'{"value":7}'


def test_ir_adapter_and_ir_helper_refuse_v3_before_projection_or_store() -> None:
    sink = _Sink()
    adapter = CoreToIRArtifactStoreAdapter(store=sink)
    options = PutOptions(kind="test.ir", media_type="application/json")
    with pytest.raises(IRCanonViolation, match="canonical_writer_profile_unavailable"):
        adapter.put_json(_ProjectionSpy(value=7), options, IRCanonSpec(version="0.3.0"))
    with pytest.raises(IRCanonViolation, match="canonical_writer_profile_unavailable"):
        put_json_artifact(
            adapter,
            _ProjectionSpy(value=7),
            kind="test.ir",
            schema_name="test",
            schema_version="1",
            canon_spec=IRCanonSpec(version="0.3.0"),
        )
    assert _ProjectionSpy.events == []
    assert sink.events == []


def test_ir_adapter_v2_reuses_real_store(tmp_path) -> None:
    root = tmp_path / "cas"
    adapter = CoreToIRArtifactStoreAdapter(store=FileSystemCAS(root))
    ref = adapter.put_json(
        {"value": 7},
        PutOptions(kind="test.ir", media_type="application/json"),
        IRCanonSpec(),
    )
    assert FileSystemCAS(root).get_bytes(ref) == b'{"value":7}'


@pytest.mark.parametrize("owner", ["core", "ir"])
def test_callback_cannot_change_the_admitted_writer_profile(owner: str, tmp_path) -> None:
    spec = CanonSpec() if owner == "core" else IRCanonSpec()

    class _MutatingModel(BaseModel):
        def model_dump(self, *args: object, **kwargs: object) -> dict[str, str]:
            object.__setattr__(spec, "version", "0.3.0")
            return {"_type": "decimal", "value": "1.0"}

    root = tmp_path / "cas"
    store = FileSystemCAS(root)
    options = PutOptions(kind="test.spec-snapshot", media_type="application/json")
    if owner == "core":
        ref = store.put_json(_MutatingModel(), options, spec)
    else:
        ref = CoreToIRArtifactStoreAdapter(store=store).put_json(_MutatingModel(), options, spec)
    fresh = FileSystemCAS(root)
    assert fresh.get_bytes(ref) == b'{"_type":"decimal","value":"1.0"}'
    assert fresh.get_manifest(ref).canon.version == "0.2.0"


@pytest.mark.parametrize("wrapper", ["cache", "namespace", "tenant"])
def test_sync_wrappers_refuse_v3_before_their_wrapped_store(wrapper: str) -> None:
    sink = _Sink()
    if wrapper == "cache":
        store = CachingArtifactStore(remote=sink, local=sink, write_through=True)
    elif wrapper == "namespace":
        store = NamespacedArtifactStore(sink, tenant_id="test")
    else:
        # The refusal must occur before quota admission needs any tenant state.
        store = TenantScopedCAS.__new__(TenantScopedCAS)
    with pytest.raises(CanonViolation, match="canonical_writer_profile_unavailable"):
        store.put_json(
            _ProjectionSpy(value=7),
            PutOptions(kind="test.wrapper", media_type="application/json"),
            CanonSpec(version="0.3.0"),
        )
    assert _ProjectionSpy.events == []
    assert sink.events == []


@pytest.mark.parametrize("wrapper", [AsyncArtifactStoreAdapter, AsyncFileSystemArtifactStore])
def test_async_wrappers_refuse_v3_before_scheduling_wrapped_store(
    wrapper: type,
) -> None:
    sink = _Sink()
    store = wrapper(store=sink)
    with pytest.raises(CanonViolation, match="canonical_writer_profile_unavailable"):
        asyncio.run(
            store.put_json(
                _ProjectionSpy(value=7),
                PutOptions(kind="test.async", media_type="application/json"),
                CanonSpec(version="0.3.0"),
            )
        )
    assert _ProjectionSpy.events == []
    assert sink.events == []


def test_raw_v3_import_remains_unknown_candidate_without_authority(tmp_path) -> None:
    store = FileSystemCAS(tmp_path / "cas")
    raw = b'{"candidate":true}'
    ref = store.put_bytes(
        raw,
        PutOptions(
            kind="test.raw",
            media_type="application/json",
            canon=CanonInfo(version="0.3.0"),
        ),
    )
    read = read_core_json_artifact(store, ref)
    assert read.status == "declared_unknown_candidate"
    assert read.raw_only_candidate_bytes == raw
    with pytest.raises(ValueError, match="canon_profile_not_verified"):
        _ = read.value
