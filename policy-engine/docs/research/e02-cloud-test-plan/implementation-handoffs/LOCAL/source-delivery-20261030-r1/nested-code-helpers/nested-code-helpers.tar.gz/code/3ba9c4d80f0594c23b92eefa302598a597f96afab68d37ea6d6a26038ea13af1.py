"""Semantic tests for vector-memory generation custody."""

from __future__ import annotations

import json
import threading
from pathlib import Path

import pytest

from polisyos.core.artifacts.store import FileSystemCAS
from polisyos.scientist.agent.vector_memory import VectorMemoryStore


class _PortableIndex:
    """Small deterministic native-index stand-in for snapshot protocol tests."""

    def __init__(self, *, space: str, dim: int) -> None:
        del space
        self.dim = dim
        self.max_elements = 0
        self.rows: dict[int, list[float]] = {}

    def init_index(self, *, max_elements: int, **_: object) -> None:
        self.max_elements = max_elements

    def set_ef(self, _: int) -> None:
        return

    def add_items(self, embeddings: list[list[float]], labels: list[int]) -> None:
        self.rows[int(labels[0])] = list(embeddings[0])

    def knn_query(
        self, embeddings: list[list[float]], *, k: int
    ) -> tuple[list[list[int]], list[list[float]]]:
        query = embeddings[0]
        ranked = sorted(
            (
                (
                    sum((left - right) ** 2 for left, right in zip(row, query, strict=True)),
                    label,
                )
                for label, row in self.rows.items()
            )
        )[:k]
        return [[label for _, label in ranked]], [[distance for distance, _ in ranked]]

    def save_index(self, path: str) -> None:
        Path(path).write_text(
            json.dumps({"max_elements": self.max_elements, "rows": self.rows}),
            encoding="utf-8",
        )

    def load_index(self, path: str, *, max_elements: int) -> None:
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        self.max_elements = max_elements
        self.rows = {int(key): value for key, value in payload["rows"].items()}

    def get_current_count(self) -> int:
        return len(self.rows)

    def get_max_elements(self) -> int:
        return self.max_elements


@pytest.fixture(autouse=True)
def _portable_hnsw(monkeypatch: pytest.MonkeyPatch) -> None:
    import polisyos.scientist.agent.vector_memory as module

    class _Module:
        Index = _PortableIndex

    monkeypatch.setattr(module, "hnswlib", _Module())
    monkeypatch.setattr(module, "_HAS_HNSW", True)


def test_query_observes_one_complete_generation_during_load(tmp_path) -> None:
    """A query already in flight returns old keys and old metadata, never a mix."""
    store = FileSystemCAS(tmp_path / "cas")

    memory = VectorMemoryStore(dim=2, max_elements=4)
    memory.add("old", [1.0, 0.0], {"generation": "old"})

    replacement = VectorMemoryStore(dim=2, max_elements=4)
    replacement.add("new", [0.0, 1.0], {"generation": "new"})
    replacement_ref = replacement.save_to_artifact(store)

    query_entered = threading.Event()
    release_query = threading.Event()
    load_finished = threading.Event()
    original_index = memory._index

    def blocked_query(*args: object, **kwargs: object) -> object:
        query_entered.set()
        assert release_query.wait(timeout=5)
        return original_index.knn_query(*args, **kwargs)

    class BlockingIndex:
        def knn_query(self, *args: object, **kwargs: object) -> object:
            return blocked_query(*args, **kwargs)

        def __getattr__(self, name: str) -> object:
            return getattr(original_index, name)

    memory._index = BlockingIndex()
    observed: list[list[tuple[str, float, dict[str, object]]]] = []
    reader = threading.Thread(target=lambda: observed.append(memory.query([1.0, 0.0], 1)))
    loader = threading.Thread(
        target=lambda: (memory.load_from_artifact(store, replacement_ref), load_finished.set())
    )

    reader.start()
    assert query_entered.wait(timeout=5)
    loader.start()
    assert not load_finished.wait(timeout=0.1)
    release_query.set()
    reader.join(timeout=5)
    loader.join(timeout=5)

    assert not reader.is_alive()
    assert not loader.is_alive()
    assert [(key, metadata) for key, _, metadata in observed[0]] == [("old", {"generation": "old"})]
    assert [(key, metadata) for key, _, metadata in memory.query([0.0, 1.0], 1)] == [
        ("new", {"generation": "new"})
    ]


def test_metadata_is_isolated_at_write_and_read_boundaries() -> None:
    """Caller mutation cannot rewrite the metadata pinned to an index label."""
    memory = VectorMemoryStore(dim=2)
    supplied = {"identity": {"run_id": "source"}}
    memory.add("source", [1.0, 0.0], supplied)

    supplied["identity"]["run_id"] = "changed-before-read"
    first = memory.query([1.0, 0.0], 1)
    first[0][2]["identity"]["run_id"] = "changed-after-read"

    assert memory.query([1.0, 0.0], 1)[0][2] == {"identity": {"run_id": "source"}}
