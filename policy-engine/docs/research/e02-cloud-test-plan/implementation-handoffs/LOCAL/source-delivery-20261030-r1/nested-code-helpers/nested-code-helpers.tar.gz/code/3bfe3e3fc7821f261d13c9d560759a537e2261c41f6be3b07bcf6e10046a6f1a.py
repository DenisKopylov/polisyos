from pathlib import Path

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
P = ROOT / 'LOCAL/raw/e02-execution-20261027/repairs/V3-basis-history-r1/full-v3-r1/candidate-r1/postimages/policy-engine/src/polisyos/runtime/quality'
p = P / 'confidence_ledger.py'
s = p.read_text()
start = s.index('def capture_execution_source_bindings(')
stop = s.index('\ndef _loaded_code_evidence_projection(', start)
s = s[:start] + '''def _execution_loaded_slot_bindings(
    root: Path,
    paths: Mapping[str, str],
    executed_code: tuple[tuple[str, types.CodeType], ...],
) -> dict[str, object]:
    """Reconcile the live SOURCE slots which own actually consumed code.

    The original C95 full-module authority census remains unchanged. This
    separate observation has a different denominator: real producer frames and
    its exact entry callables. A nested function/comprehension is owned by the
    nearest source-declared callable, rather than a caller-written helper list.
    Unexecuted N4/N9/LLM alternatives receive a source-byte binding only.
    """
    modules: dict[str, set[str]] = {}
    for module, code in executed_code:
        if module in paths:
            modules.setdefault(module, set()).add(code.co_qualname)
    result: dict[str, object] = {}
    for module_name, qualnames in sorted(modules.items()):
        relative = paths[module_name]
        source_path = (root / relative).resolve(strict=True)
        module = sys.modules.get(module_name)
        spec = getattr(module, "__spec__", None)
        if (
            module is None
            or not isinstance(getattr(spec, "loader", None), SourceFileLoader)
            or Path(str(getattr(spec, "origin", ""))).resolve() != source_path
            or Path(str(getattr(module, "__file__", ""))).resolve() != source_path
        ):
            raise ConfidenceLedgerError("n5_executed_code_origin_mismatch")
        source = source_path.read_bytes()
        compiled = compile(
            source, str(source_path), "exec", dont_inherit=True, optimize=sys.flags.optimize
        )
        hashes = _loader_code_hashes_by_qualname(compiled)
        declarations = _loader_owned_callable_slots(source_path)
        selected: dict[str, _LoaderOwnedCallableSlot] = {}
        for qualname in qualnames:
            matches = tuple(
                slot for slot in declarations
                if qualname == slot.qualname or qualname.startswith(slot.qualname + ".<locals>.")
            )
            if not matches:
                raise ConfidenceLedgerError("n5_executed_owner_slot_not_established")
            slot = max(matches, key=lambda item: len(item.qualname))
            selected[slot.qualname] = slot
        rows: dict[str, object] = {}
        live = _live_defined_code_manifest(module, module_name, source_path=source_path)
        for qualname, slot in sorted(selected.items()):
            row, matches = _loader_owned_slot_binding(
                module, module_name, source_path, slot, hashes.get(qualname, ()), hashes
            )
            if not matches:
                raise ConfidenceLedgerError("n5_consumed_loaded_binding_mismatch")
            # Existing C95 rows include code/wrapper/descriptor provenance;
            # this adds defaults/kwdefaults/closure from its existing generic
            # function-binding owner. Same code with changed defaults differs.
            actual_bindings = {
                label: binding for label, binding in live.items()
                if label == qualname or label.startswith(qualname + ".")
            }
            if not actual_bindings:
                raise ConfidenceLedgerError("n5_consumed_loaded_binding_missing")
            rows[qualname] = {"slot": row, "live_bindings": actual_bindings}
        result[module_name] = {"relative_path": relative, "consumed_slots": rows}
    return result


def capture_execution_source_bindings(
    entry_modules: tuple[str, ...],
    executed_code: tuple[tuple[str, types.CodeType], ...],
) -> dict[str, object]:
    """Reconcile the complete source closure and actual consumed live slots.

    Actual producer frames/entry objects determine the loaded-binding set. The
    static closure still binds every alternative's source bytes, but an
    unrelated loaded function is not asserted to have supplied this N5 result.
    The original C95 full-module admission policy is not changed by this seam.
    """
    root = _loaded_policy_engine_root()
    closure = _resolve_authority_import_closure(root, entry_modules)
    source_rows = tuple(
        (module, relative, _bytes_hash((root / relative).read_bytes()))
        for module, relative in closure
    )
    paths = dict(closure)
    loaded_bindings = _execution_loaded_slot_bindings(root, paths, executed_code)
    executed_rows: list[tuple[str, str, str]] = []
    for module, code in executed_code:
        relative = paths.get(module)
        loaded_module = sys.modules.get(module)
        spec = getattr(loaded_module, "__spec__", None)
        loader = getattr(spec, "loader", None)
        origin = getattr(spec, "origin", None)
        if relative is not None:
            source_path = (root / relative).resolve()
            source = source_path.read_bytes()
            if Path(code.co_filename).resolve() != source_path:
                raise ConfidenceLedgerError("n5_executed_code_origin_mismatch")
            compiled = compile(
                source, str(source_path), "exec", dont_inherit=True, optimize=sys.flags.optimize
            )
        elif isinstance(loader, SourceFileLoader) and isinstance(origin, str):
            source_path = Path(origin).resolve(strict=True)
            if (
                loaded_module is None
                or Path(str(getattr(loaded_module, "__file__", ""))).resolve() != source_path
                or Path(code.co_filename).resolve() != source_path
            ):
                raise ConfidenceLedgerError("n5_executed_dependency_origin_mismatch")
            source = source_path.read_bytes()
            compiled = compile(
                source, str(source_path), "exec", dont_inherit=True, optimize=sys.flags.optimize
            )
        elif origin == "frozen" and hasattr(loader, "get_code"):
            compiled = loader.get_code(module)
            if not isinstance(compiled, types.CodeType):
                raise ConfidenceLedgerError("n5_executed_frozen_dependency_unverified")
        else:
            raise ConfidenceLedgerError("n5_executed_dependency_source_not_established")
        expected = _loader_code_hashes_by_qualname(compiled).get(code.co_qualname, ())
        digest = _content_hash(_normalize_code_object(code))
        if digest not in expected:
            raise ConfidenceLedgerError("n5_executed_code_source_mismatch")
        executed_rows.append((module, code.co_qualname, digest))
    return {
        "source_closure_hash": _content_hash(source_rows),
        "source_module_count": len(source_rows),
        "loaded_binding_hash": _content_hash(loaded_bindings),
        "loaded_module_count": len(loaded_bindings),
        "executed_code": tuple(sorted(set(executed_rows))),
    }

''' + s[stop:]
p.write_text(s)

p = P / 'n5_execution_basis.py'
s = p.read_text()
s = s.replace('''class _VerifiedExecutionInput:
    controller: object''', '''class _VerifiedExecutionInput:
    port: object
    controller: object''')
s = s.replace('''    input_content_hash: str


@contextmanager''', '''    input_content_hash: str
    observer: _ControllerExecutionObserver


@contextmanager''', 1)
s = s.replace('''    token = _ACTIVE_INPUT.set(
        _VerifiedExecutionInput(
            port._controller,''', '''    observer = _ControllerExecutionObserver()
    token = _ACTIVE_INPUT.set(
        _VerifiedExecutionInput(
            port,
            port._controller,''')
s = s.replace('''            record.content_hash,
        )
    )
    try:
        yield
    finally:
        _ACTIVE_INPUT.reset(token)''', '''            record.content_hash,
            observer,
        )
    )
    try:
        # Observe the actual full synchronous controller call: selection,
        # cache/replication, numerical code, and final aggregation/result
        # construction. Capturing only run_once would miss outer consumers.
        with observer:
            yield
    finally:
        _ACTIVE_INPUT.reset(token)''', 1)
start = s.index('def _binding_value(value: object) -> object:')
stop = s.index('\nclass N5ImplementationCapture:', start)
s = s[:start] + '''def _binding_value(value: object) -> object:
    """Bind actual callable defaults/closure and current class method slots."""
    from polisyos.runtime.quality.confidence_ledger import (
        _normalize_function_binding,
        _normalize_runtime_binding_value,
    )

    if isinstance(value, types.FunctionType):
        return {"live_object_token": _token(value), "function": _normalize_function_binding(value)}
    if isinstance(value, type):
        # A class can keep its identity while an inherited constructor or
        # numerical method changes. Observe every actual MRO callable slot,
        # not only the class token/FQN. No method-name whitelist decides this.
        owners = []
        for owner in value.__mro__:
            callables = {}
            for name, raw in vars(owner).items():
                if isinstance(raw, types.FunctionType):
                    functions = (raw,)
                elif isinstance(raw, (classmethod, staticmethod)):
                    functions = (raw.__func__,)
                elif isinstance(raw, property):
                    functions = tuple(item for item in (raw.fget, raw.fset, raw.fdel) if item is not None)
                else:
                    continue
                callables[name] = {
                    "descriptor_type": f"{type(raw).__module__}.{type(raw).__qualname__}",
                    "functions": tuple(_normalize_function_binding(item) for item in functions),
                }
            owners.append({"owner_token": _token(owner), "callable_slots": callables})
        return {"live_object_token": _token(value), "class_mro": owners}
    if isinstance(value, types.MethodType):
        return {
            "bound_owner_token": _token(value.__self__),
            "function": _binding_value(value.__func__),
        }
    if isinstance(value, types.ModuleType) or callable(value):
        return {
            "live_object_token": _token(value),
            "type": f"{type(value).__module__}.{type(value).__qualname__}",
        }
    return _normalize_runtime_binding_value(value, seen=set())


class _ControllerExecutionObserver:
    """Observe real controller frames without replacing a product callable."""

    def __init__(self) -> None:
        self.codes: dict[tuple[str, str, str], _ExecutedCode] = {}
        self.native_calls: dict[str, object] = {}
        self.suspended = False
        self.active = False
        self.reason: str | None = None

    def __enter__(self) -> _ControllerExecutionObserver:
        if sys.getprofile() is not None:
            self.reason = "n5_execution_observer_conflict"
        else:
            self.active = True
            sys.setprofile(self._observe)
        return self

    def _observe(self, frame: types.FrameType, event: str, arg: object) -> None:
        if self.suspended:
            return
        if event == "call":
            module = str(frame.f_globals.get("__name__", ""))
            if module and module != __name__:
                key = (module, frame.f_code.co_qualname, str(id(frame.f_code)))
                self.codes.setdefault(key, _ExecutedCode(module, frame.f_code, frame.f_globals, frame))
        elif event == "c_call":
            module = str(getattr(arg, "__module__", ""))
            if module.startswith(("numpy", "scipy")):
                self.native_calls[_token(arg)] = arg

    def __exit__(self, *exc: object) -> None:
        del exc
        if self.active and sys.getprofile() == self._observe:
            sys.setprofile(None)
        self.active = False


''' + s[stop:]
s = s.replace('''        self._codes: dict[tuple[str, str, str], _ExecutedCode] = {}
        self._native_calls: dict[str, object] = {}''', '''        self._observer = self._admission.observer if self._admission is not None else None
        self._codes = self._observer.codes if self._observer is not None else {}
        self._native_calls = self._observer.native_calls if self._observer is not None else {}''', 1)
start = s.index('    def __enter__(self) -> N5ImplementationCapture:')
stop = s.index('    def bind_trajectories(', start)
s = s[:start] + '''    def __enter__(self) -> N5ImplementationCapture:
        if not self._supported or self._admission is None or self._observer is None:
            self._reasons.append("n5_selected_implementation_or_input_unsupported")
            return self
        if not self._observer.active or sys.getprofile() != self._observer._observe:
            self._reasons.append(self._observer.reason or "n5_execution_observer_not_active")
            return self
        try:
            self._observer.suspended = True
            self._initial = self._current_implementation()
        except (OSError, TypeError, ValueError, RuntimeError) as exc:
            self._reasons.append(str(getattr(exc, "code", None) or exc))
        finally:
            self._observer.suspended = False
        return self

    @contextmanager
    def observe_numerical_call(self) -> Iterator[None]:
        """Keep the numerical boundary inside the full actual call observer."""
        if self._initial is not None and (
            self._observer is None or not self._observer.active
            or sys.getprofile() != self._observer._observe
        ):
            self._reasons.append("n5_execution_observer_interrupted")
        yield

    def __exit__(self, *exc: object) -> None:
        del exc
        # The producer input owner, outside controller.run, closes its observer
        # after result construction. The inner numerical scope must not stop it.

''' + s[stop:]
s = s.replace('''        current_registry = MethodRegistry.get_instance()
        if self._controller._registry is not current_registry:
            raise ValueError("n5_selected_registry_current_owner_not_established")
        selected = self._controller._select_engine(self._request)
        if (
            selected.decision.decision != "selected"
            or selected.decision.method_fqn != self._method_fqn
            or current_registry.get(self._method_fqn) is not self.method
        ):
            raise ValueError("n5_current_selected_implementation_changed")
        modules = {''', '''        from polisyos.runtime.quality.generation_cycle import JointSimulationPort

        if self._admission is None or type(self._admission.port) is not JointSimulationPort:
            raise ValueError("n5_selected_input_port_not_canonical")
        entry_codes = []
        entry_bindings = {}
        for owner, name in (
            (self._admission.port, "__call__"),
            (self._admission.port, "_build_candidate_simulation_request"),
            (self._controller, "run"),
            (self._controller, "_select_engine"),
        ):
            if name in vars(owner):
                raise ValueError("n5_consumed_entry_instance_shadow")
            method = getattr(owner, name)
            if not isinstance(method, types.MethodType) or method.__self__ is not owner:
                raise ValueError("n5_consumed_entry_not_bound")
            function = method.__func__
            entry_codes.append((function.__module__, function.__code__))
            entry_bindings[f"{type(owner).__module__}.{type(owner).__qualname__}:{name}"] = _binding_value(function)
        modules = {''', 1)
s = s.replace('''            *(item.module for item in self._codes.values() if item.module.startswith("polisyos.")),
        }
        bindings''', '''            *(item.module for item in self._codes.values() if item.module.startswith("polisyos.")),
        }
        # Resolve current source/loader slots BEFORE invoking the current
        # selector. A changed selector must not run on the verifier's behalf.
        source = capture_execution_source_bindings(
            tuple(sorted(modules)),
            tuple(entry_codes) + tuple((item.module, item.code) for item in self._codes.values()),
        )
        current_registry = MethodRegistry.get_instance()
        if self._controller._registry is not current_registry:
            raise ValueError("n5_selected_registry_current_owner_not_established")
        selected = self._controller._select_engine(self._request)
        if (
            selected.decision.decision != "selected"
            or selected.decision.method_fqn != self._method_fqn
            or current_registry.get(self._method_fqn) is not self.method
        ):
            raise ValueError("n5_current_selected_implementation_changed")
        bindings''', 1)
s = s.replace('''            "source": capture_execution_source_bindings(
                tuple(sorted(modules)),
                tuple((item.module, item.code) for item in self._codes.values()),
            ),''', '''            "source": source,
            "entry_bindings": entry_bindings,''', 1)
s = s.replace('''        if not self._entry_observed or not self._codes or self._trajectory_hash is None:''', '''        self._entry_observed = isinstance(self._entry, types.FunctionType) and any(
            item.code is self._entry.__code__ for item in self._codes.values()
        )
        if not self._entry_observed or not self._codes or self._trajectory_hash is None:''', 1)
s = s.replace('''for key in ("method_object", "entry_object", "entry_code", "numerical_policy"):''', '''for key in ("method_object", "entry_object", "entry_code", "entry_bindings", "numerical_policy"):''')
s = s.replace('''    from types import TracebackType

''', '')
p.write_text(s)
