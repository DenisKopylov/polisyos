from polisyos.subject import read_mode

def consume():
    return read_mode()
