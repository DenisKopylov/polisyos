import importlib
from importlib import import_module as selected_alias
from opaque_vendor import inspect_class

class Parent: pass
class RefusalError(Parent): pass

inspect_class(Parent)

def refuse():
    raise RefusalError("declared_refusal")

importlib = inspect_class
