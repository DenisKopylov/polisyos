def body():
    return None
value = {"code": body.__code__}
match value:
    case {"code": x}:
        opaque(x)
