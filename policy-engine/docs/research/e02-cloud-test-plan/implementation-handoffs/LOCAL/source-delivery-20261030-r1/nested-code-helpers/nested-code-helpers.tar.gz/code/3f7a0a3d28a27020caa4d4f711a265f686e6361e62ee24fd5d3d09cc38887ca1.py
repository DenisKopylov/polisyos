from types import FunctionType
class Guard:
    def run(self, callback, *args, **kwargs):
        return callback(*args, **kwargs)
CODE = Guard.run.__code__
def invoke(guard, callback, *args, **kwargs):
    run = FunctionType(CODE, globals())
    return run(guard, callback, *args, **kwargs)
