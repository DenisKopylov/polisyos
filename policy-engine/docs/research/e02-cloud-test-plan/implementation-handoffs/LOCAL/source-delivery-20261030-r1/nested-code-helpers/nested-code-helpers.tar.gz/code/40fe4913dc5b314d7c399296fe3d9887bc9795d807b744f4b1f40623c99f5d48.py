from __future__ import annotations
import ast, hashlib, json, pathlib, subprocess, tomllib
R=pathlib.Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
C=R/'LOCAL/raw/e02-execution-20261027/repairs/V3-basis-history-r1/full-v3-r1/candidate-r1'
P=C/'postimages'
rows=[]
config=str(R/'policy-engine/architecture/tooling/ruff/workspace_root.toml')
ruff=[str(R/'policy-engine/.venv/bin/python'),'-m','ruff']
for p in sorted(P.rglob('*')):
 if not p.is_file(): continue
 rel=p.relative_to(P).as_posix()
 row={'path':rel,'bytes':p.stat().st_size}
 if p.suffix=='.py':
  try: ast.parse(p.read_bytes(),filename=str(R/rel));row['ast']='PASS'
  except (SyntaxError,ValueError) as e: row['ast']=str(e);rows.append(row);continue
  if rel!='policy-engine/src/polisyos/runtime/http/services/control_plane_store.py':
   fix=subprocess.run(ruff+['check','--no-cache','--config',config,'--select','I001','--fix','--stdin-filename',str(R/rel),'-'],input=p.read_bytes(),capture_output=True)
   if fix.returncode==0: p.write_bytes(fix.stdout)
   else: row['import_fix_error']=fix.stderr.decode()+fix.stdout.decode()
   fmt=subprocess.run(ruff+['format','--config',config,'--stdin-filename',str(R/rel),'-'],input=p.read_bytes(),capture_output=True)
   if fmt.returncode: row['format_write_error']=fmt.stderr.decode()
   else: p.write_bytes(fmt.stdout)
  check=subprocess.run(ruff+['check','--no-cache','--config',config,'--stdin-filename',str(R/rel),'-'],input=p.read_bytes(),capture_output=True)
  fmtcheck=subprocess.run(ruff+['format','--check','--config',config,'--stdin-filename',str(R/rel),'-'],input=p.read_bytes(),capture_output=True)
  row.update({'ruff_exit':check.returncode,'format_exit':fmtcheck.returncode,'diagnostics':check.stdout.decode()+check.stderr.decode() if check.returncode else ''})
 elif p.suffix=='.json': json.loads(p.read_bytes());row['json']='PASS'
 elif p.suffix=='.toml': tomllib.loads(p.read_text());row['toml']='PASS'
 row['post_sha256']=hashlib.sha256(p.read_bytes()).hexdigest();rows.append(row)
body={'scope':'Complete candidate postimage file set; no production imports/tests/native/generators run','runtime':'UNRUN','imports':'UNRUN','checks':rows}
(C/'static-verification.json').write_text(json.dumps(body,indent=2)+'\n')
counts={}
for p in P.rglob('*'):
 if p.is_file(): counts[p.suffix]=counts.get(p.suffix,0)+1
failures=[row for row in rows if row.get('ast','PASS')!='PASS' or row.get('ruff_exit',0) or row.get('format_exit',0)]
print(json.dumps({'files':len(rows),'file_type_denominator':counts,'python':sum(row['path'].endswith('.py') for row in rows),'failures':failures,'static_receipt_sha256':hashlib.sha256((C/'static-verification.json').read_bytes()).hexdigest()},indent=2))
