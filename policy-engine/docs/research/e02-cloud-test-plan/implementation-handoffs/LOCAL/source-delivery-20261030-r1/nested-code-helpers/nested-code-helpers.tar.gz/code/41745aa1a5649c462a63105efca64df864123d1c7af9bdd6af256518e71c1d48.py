"""Format frozen SQL postimages under real Ruff configuration; compare full AST."""
from __future__ import annotations

import ast
import collections
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

repo = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
product = repo / "policy-engine"
source = repo / "LOCAL/raw/e02-execution-20261027/repairs/SQL-owner-chain-r3"
dest = repo / "LOCAL/raw/e02-execution-20261027/repairs/SQL-owner-chain-r3-intake-20261028-r1"
frozen = json.loads((source / "frozen-77e00604/file-pins.json").read_bytes())
scan_file = dest / "checks/ruff-original.json"
scan_bytes = scan_file.read_bytes() if scan_file.is_file() else gzip.decompress(
    Path(str(scan_file) + ".gz").read_bytes()
)
scan = json.loads(scan_bytes)
scan_by_path = {row["path"]: row for row in scan["results"]}
sha = lambda data: hashlib.sha256(data).hexdigest()
rows, checks, proof = [], [], []
for entry in frozen["files"]:
    path = entry["path"]
    current = repo / path
    pre = sha(current.read_bytes()) if current.is_file() else None
    assert pre == entry["pre_sha256"], (path, pre, entry["pre_sha256"])
    old_path = source / "postimages" / path
    original = old_path.read_bytes()
    assert sha(original) == entry["post_sha256"], path
    postimage = old_path
    selected = original
    if path.endswith(".py"):
        test = scan_by_path[path]
        assert len(test["checks"]) == 2
        format_check = next(c for c in test["checks"] if c["label"] == "format")
        if format_check["exit"] != 0:
            command = [str(product / ".venv/bin/python"), "-m", "ruff", "format", "--no-cache",
                       "--stdin-filename", str(current), "-"]
            run = subprocess.run(command, cwd=product, input=original, stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, check=False)
            assert run.returncode == 0, (path, run.stderr.decode())
            selected = run.stdout
            before = ast.parse(original, filename=path)
            after = ast.parse(selected, filename=path)
            before_ast = ast.dump(before, include_attributes=False)
            after_ast = ast.dump(after, include_attributes=False)
            assert before_ast == after_ast, path
            def imports(tree):
                return collections.Counter(
                    ast.dump(node, include_attributes=False) for node in ast.walk(tree)
                    if isinstance(node, (ast.Import, ast.ImportFrom))
                )
            assert imports(before) == imports(after), path
            postimage = dest / "postimages" / path
            postimage.parent.mkdir(parents=True, exist_ok=True)
            postimage.write_bytes(selected)
            assert postimage.read_bytes() == selected
            proof.append({"path": path, "old_sha256": sha(original), "new_sha256": sha(selected),
                          "format_command": command, "format_exit": run.returncode,
                          "format_stdout": str(postimage), "format_stderr": run.stderr.decode(),
                          "full_ast_identical": True, "import_multiset_identical": True})
        for label, args in (
            ("check", ["check", "--no-cache"]),
            ("format", ["format", "--check", "--no-cache"]),
        ):
            command = [str(product / ".venv/bin/python"), "-m", "ruff", *args,
                       "--stdin-filename", str(current), "-"]
            run = subprocess.run(command, cwd=product, input=selected, stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, check=False)
            checks.append({"path": path, "phase": label, "command": command, "exit": run.returncode,
                           "stdout": run.stdout.decode(), "stderr": run.stderr.decode(),
                           "post_sha256": sha(selected)})
    rows.append({"path": path, "pre_sha256": pre, "post_sha256": sha(selected),
                 "postimage_file": str(postimage)})
assert len(rows) == 61 and len(scan_by_path) == 59
assert len({row["path"] for row in rows}) == len(rows)
report = {"base_source": "frozen-77e00604", "source_diff_sha256":
          "77e00604d48e48b84469c5b8b9565a567ce17d6b470aac28b45403a01288d7fb",
          "current_git_head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo).decode().strip(),
          "files": rows, "runtime": "UNRUN", "closure_ids": []}
(dest / "sql-61-manifest.json").write_text(json.dumps(report, indent=2) + "\n")
(dest / "checks/style-proof.json").write_text(json.dumps(proof, indent=2) + "\n")
(dest / "checks/ruff-final.json").write_text(json.dumps({"python_denominator": 59, "results": checks}, indent=2) + "\n")
print("manifest files", len(rows), "formatted", len(proof), "ruff checks", len(checks))
failures = [row for row in checks if row["exit"]]
for failure in failures:
    print(failure["path"], failure["phase"], failure["stdout"], failure["stderr"])
assert not failures
