from types import FunctionType
from importlib import import_module
def body():
    return import_module("bridge_old_code")
def replacement():
    return None
CODE = body.__code__
body.__code__ = replacement.__code__
run = FunctionType(CODE, globals())
run()
