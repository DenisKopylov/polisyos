"""Finite fake-record controls for strict supervisor reconciliation only."""

from __future__ import annotations

import copy
import importlib.util
import json
import sys
from pathlib import Path
from unittest.mock import patch

PACKET = Path(
    "/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos/LOCAL/raw/e02-execution-20261027/repairs/R4-native-control-r1/controller"
)
spec = importlib.util.spec_from_file_location(
    "r4_native_controller_control", PACKET / "controller.py"
)
assert spec is not None and spec.loader is not None
controller = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = controller
spec.loader.exec_module(controller)
CASE = Path("/synthetic-case")


def record(abort: bool = False) -> tuple[dict, dict, dict]:
    plan = {
        "rss_cap_bytes": controller.RSS_CAP,
        "disk_stop_bytes": controller.DISK_STOP,
        "disk_admission_bytes": controller.DISK_START,
        "deadline_seconds": controller.DEADLINE,
        "argv": ["synthetic-test-command"],
    }
    rss = controller.RSS_CAP + 1024 if abort else 1024
    status, rc, reason = (
        ("resource_limit_abort", -15, "sampled_process_tree_rss_cap")
        if abort
        else ("passed", 0, None)
    )
    result = {
        "id": "r4-native",
        "argv": [
            "/usr/bin/sandbox-exec",
            "-f",
            str(CASE / "sandbox.sb"),
            *plan["argv"],
        ],
        "cwd": str(controller.PRODUCT),
        "complete": True,
        "process_group_gone": True,
        "aborted_reason": reason,
        "termination_signal": None,
        "return_code": rc,
        "status": status,
        "pid": 111,
        "sample_count": 1,
        "disk_free_before_bytes": controller.DISK_START,
        "max_sampled_process_tree_rss_bytes": rss,
        "minimum_sampled_disk_free_bytes": controller.DISK_START,
        "wall_seconds": 1.0,
    }
    sample = {
        "kind": "sample",
        "command_id": "r4-native",
        "elapsed_command_seconds": 0.5,
        "sampled_process_tree_rss_bytes": rss,
        "disk_free_bytes": controller.DISK_START,
        "processes": [{"pid": 111, "rss_kib": rss // 1024}],
    }
    finish = {
        "id": "r4-native",
        "return_code": rc,
        "status": status,
        "aborted_reason": reason,
    }
    rows = {
        "process-tree.jsonl": [sample],
        "controller-events.jsonl": [{"kind": "command_finish", **finish}],
        "phase-output.jsonl": [{"phase": "finish", **finish}],
    }
    return plan, result, rows


def run(plan: dict, result: dict, rows: dict) -> dict:
    def read_bytes(path: Path) -> bytes:
        return b"".join((json.dumps(row) + "\n").encode() for row in rows[path.name])

    with (
        patch.object(Path, "read_bytes", read_bytes),
        patch.object(controller.checks, "sha_file", lambda _path: "synthetic-hash"),
    ):
        return controller.strict_supervisor(CASE, result, plan)


def rejected(plan: dict, result: dict, rows: dict) -> bool:
    try:
        run(plan, result, rows)
    except (ValueError, KeyError, TypeError):
        return True
    return False


def main() -> None:
    plan, result, rows = record()
    results = {
        "complete_samples_accepted": run(plan, result, rows)["status"] == "passed"
    }
    changed = copy.deepcopy(result)
    changed["spawn_or_supervision_error"] = "actual error"
    results["supervisor_error_rejected"] = rejected(plan, changed, rows)
    changed = copy.deepcopy(result)
    changed["sample_count"] = 2
    results["sample_count_mismatch_rejected"] = rejected(plan, changed, rows)
    changed = copy.deepcopy(rows)
    changed["process-tree.jsonl"][0]["sampled_process_tree_rss_bytes"] = 0
    results["sample_rss_sum_mismatch_rejected"] = rejected(plan, result, changed)
    changed = copy.deepcopy(result)
    changed["process_group_gone"] = False
    results["live_process_group_rejected"] = rejected(plan, changed, rows)
    changed = copy.deepcopy(result)
    changed["termination_signal"] = "SIGTERM"
    results["unexpected_signal_rejected"] = rejected(plan, changed, rows)
    changed = copy.deepcopy(plan)
    changed["rss_cap_bytes"] = controller.RSS_CAP + 1
    results["arbitrary_resource_cap_rejected"] = rejected(changed, result, rows)
    changed = copy.deepcopy(rows)
    changed["phase-output.jsonl"].append(
        copy.deepcopy(changed["phase-output.jsonl"][0])
    )
    results["duplicate_finish_rejected"] = rejected(plan, result, changed)
    abort_plan, aborted, abort_rows = record(abort=True)
    results["measured_resource_abort_reconciled"] = (
        run(abort_plan, aborted, abort_rows)["aborted_reason"]
        == "sampled_process_tree_rss_cap"
    )
    altered = copy.deepcopy(abort_rows)
    altered["process-tree.jsonl"][0]["sampled_process_tree_rss_bytes"] = (
        controller.RSS_CAP
    )
    altered["process-tree.jsonl"][0]["processes"][0]["rss_kib"] = (
        controller.RSS_CAP // 1024
    )
    results["unsupported_abort_rejected"] = rejected(abort_plan, aborted, altered)
    value = {
        "schema": "policyos.e02.r4.native-supervisor-stdlib-controls.v1",
        "scope": "synthetic supervisor records; no native/backend/product execution",
        "results": results,
        "pass": all(results.values()),
        "closure_ids": [],
    }
    print(json.dumps(value, sort_keys=True, indent=2))
    if not value["pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
