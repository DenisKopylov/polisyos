"""Preserve the r2 mechanism and align the test with the post-SQL Ruff namespace."""
from __future__ import annotations
import ast,collections,copy,hashlib,json,subprocess
from pathlib import Path
repo=Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
product=repo/"policy-engine"
raw=repo/"LOCAL/raw/e02-execution-20261027/repairs/SQL-owner-chain-r3-intake-20261028-r1"
overlay=repo/"LOCAL/raw/e02-execution-20261027/repairs/SQL-owner-chain-r3/postimages/policy-engine"
config=f'src = [".", "src", "{overlay}"]'
sha=lambda b:hashlib.sha256(b).hexdigest()
old=raw/"v3-8-after-sql-r2-manifest.json"
assert sha(old.read_bytes())=="b469f691dfd86143eec8be9d68120f724c81fc405ee5981d632864bb89c8a575"
data=json.loads(old.read_bytes())
name="policy-engine/tests/unit/foundry/data_plane/test_input_bindings_preparation.py"
row=next(x for x in data["files"] if x["path"]==name)
source=Path(row["postimage_file"]); before=source.read_bytes()
assert sha(before)==row["post_sha256"]
target=repo/name
cmd=[str(product/".venv/bin/python"),"-m","ruff","check","--no-cache","--fix","--select","I",
     "--config",config,"--stdin-filename",str(target),"-"]
run=subprocess.run(cmd,cwd=product,input=before,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
assert run.returncode==0,run.stderr.decode()
after=run.stdout
assert before!=after
def no_imports(t):
 class Drop(ast.NodeTransformer):
  def visit_Import(self,node): return None
  def visit_ImportFrom(self,node): return None
 return ast.dump(Drop().visit(copy.deepcopy(t)),include_attributes=False)
def imports(t):
 return collections.Counter(ast.dump(n,include_attributes=False) for n in ast.walk(t)
     if isinstance(n,(ast.Import,ast.ImportFrom)))
a,b=ast.parse(before),ast.parse(after)
assert no_imports(a)==no_imports(b) and imports(a)==imports(b)
out=raw/"union-r3-postimages"/name
out.parent.mkdir(parents=True,exist_ok=True)
out.write_bytes(after)
row["postimage_file"]=str(out)
row["post_sha256"]=sha(after)
data["supersedes_v3_manifest_sha256"]=sha(old.read_bytes())
data["style_delta"]="The SQL test source root is present after the first intake; sort only this new test's import using that prospective first-party namespace."
manifest=raw/"v3-8-after-sql-r3-manifest.json"
manifest.write_text(json.dumps(data,indent=2)+"\n")
checks=[]
for entry in data["files"]:
 path=entry["path"]
 if not path.endswith(".py"): continue
 content=Path(entry["postimage_file"]).read_bytes()
 assert sha(content)==entry["post_sha256"]
 for phase,args in (("check",["check","--no-cache"]),("format",["format","--check","--no-cache"])):
  command=[str(product/".venv/bin/python"),"-m","ruff",*args,"--config",config,
           "--stdin-filename",str(repo/path),"-"]
  x=subprocess.run(command,cwd=product,input=content,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  checks.append({"path":path,"phase":phase,"command":command,"exit":x.returncode,
                 "stdout":x.stdout.decode(),"stderr":x.stderr.decode()})
proof={"path":name,"old_sha256":sha(before),"new_sha256":sha(after),"sort_command":cmd,
       "sort_exit":run.returncode,"sort_stderr":run.stderr.decode(),
       "nonimport_ast_identical":True,"import_multiset_identical":True,
       "scope":"Ruff src includes exact SQL postimages; physical post-composition Ruff remains unrun",
       "checks":checks}
(raw/"checks/v3-r3-style-proof.json").write_text(json.dumps(proof,indent=2)+"\n")
assert all(x["exit"]==0 for x in checks),checks
print("manifest",sha(manifest.read_bytes()))
print("test",sha(after))
print("checks",len(checks),"PASS")
