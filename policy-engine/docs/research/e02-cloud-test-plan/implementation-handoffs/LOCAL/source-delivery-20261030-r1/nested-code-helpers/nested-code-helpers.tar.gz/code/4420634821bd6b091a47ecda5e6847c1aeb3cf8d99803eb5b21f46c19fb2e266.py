from pathlib import Path
import ast,difflib,re,hashlib,json
root=Path.cwd();pkg=root/'LOCAL/raw/e02-execution-20261027/repairs/C49-local-r1'
rel=Path('policy-engine/src/polisyos/runtime/quality/joint_simulation_horizon.py')
old=(pkg/'preimages'/rel).read_text();new=(pkg/'postimages'/rel).read_text()
source=root/'LOCAL/raw/e02-execution-20261027/repairs/C41-r8/postimages'/rel
base=source.read_text()
patch=list(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+str(rel),tofile='b/'+str(rel)))
# Read-only, exact-context composition: no source/import/index/ref mutation.
lines=base.splitlines(True);cursor=0;output=[];index=2;hunks=0
while index<len(patch):
 assert patch[index].startswith('@@ '),patch[index]
 index+=1;before=[];after=[]
 while index<len(patch) and not patch[index].startswith('@@ '):
  row=patch[index];index+=1
  if row.startswith(' '):before.append(row[1:]);after.append(row[1:])
  elif row.startswith('-'):before.append(row[1:])
  elif row.startswith('+'):after.append(row[1:])
  elif row.startswith('\\'):pass
  else:raise AssertionError(row)
 candidates=[pos for pos in range(cursor,len(lines)-len(before)+1) if lines[pos:pos+len(before)]==before]
 assert len(candidates)==1,(hunks,len(candidates),before[:2])
 pos=candidates[0];output.extend(lines[cursor:pos]);output.extend(after);cursor=pos+len(before);hunks+=1
output.extend(lines[cursor:]);composed=''.join(output)
assert '    def validate_selected_result(' in composed
ast.parse(composed)
pre=pkg/'owner-contexts/C41-r8/preimages'/rel;post=pkg/'owner-contexts/C41-r8/postimages'/rel
pre.parent.mkdir(parents=True,exist_ok=True);post.parent.mkdir(parents=True,exist_ok=True)
pre.write_text(base);post.write_text(composed)
context=''.join(difflib.unified_diff(base.splitlines(True),composed.splitlines(True),fromfile='a/'+str(rel),tofile='b/'+str(rel)))
(pkg/'owner-contexts/C41-r8/horizon-budget-work-context.patch').write_text(context)
result={'path':str(rel),'source_input':str(source.relative_to(root)),'preimage_sha256':hashlib.sha256(base.encode()).hexdigest(),
'postimage_sha256':hashlib.sha256(composed.encode()).hexdigest(),'patch_sha256':hashlib.sha256(context.encode()).hexdigest(),
'exact_context_hunks':hunks,'canonical_source_mutated':False,'runtime':'UNRUN'}
(pkg/'owner-contexts/C41-r8/horizon-context-manifest.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
