from pathlib import Path
D=Path(__file__).resolve().parents[1];base='policy-engine/src/polisyos/scientist/agent/'
def save(p,s):
 import ast
 ast.parse(s);q=D/'postimages'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(s)
s=(D/'preimages'/(base+'_drafter_orchestrator.py')).read_text();s=s.replace('import time\n','import time\nfrom dataclasses import replace\n');s=s.replace('from polisyos.scientist.orchestration.engine.convergence import ConvergenceDetector','from polisyos.scientist.orchestration.engine.convergence import (\n    ConvergenceDetector,\n    ConvergenceObservation,\n    ConvergenceState,\n)');needle='from ._drafter_parsing import _DrafterParsingMixin';s=s.replace(needle,'''from ._drafter_observations import (
    confidence_request_ref,
    confidence_subject_ref,
    observe_candidate_confidence,
)
'''+needle)
old='''            # Feed convergence detector with initial confidence
            if convergence_detector is not None:
                convergence_detector.check(current_draft.confidence)
''';new='''            if convergence_detector is not None:
                current_draft, conv_state = self._record_current_convergence(
                    convergence_detector, problem_frame, pass1, current_draft
                )
                if conv_state.should_stop:
                    stop_reason = self._convergence_stop_reason(conv_state)
                    for number, name in ((2, "side_effects_check"), (3, "constraint_verify"), (4, "consolidation")):
                        if number <= self._config.max_passes:
                            pass_results.append(self._skipped_pass(name, number, stop_reason))
                    return self._finalize(
                        problem_frame=problem_frame,
                        draft=current_draft,
                        pass_results=pass_results,
                        cumulative_cost_usd=cumulative_cost_usd,
                        extra_llm_calls=extra_llm_calls,
                        early_exit=True,
                        stop_reason=stop_reason,
                        parent_span=parent_span,
                        metrics=metrics,
                    )
''';assert old in s;s=s.replace(old,new)
for num in [2,3]:
 old=f'''            # Convergence check after pass {num}
            if convergence_detector is not None:
                conv_state = convergence_detector.check(current_draft.confidence)
                if conv_state.converged:
                    early_exit = True
                    stop_reason = f"convergence:{{conv_state.reason}}"'''
 new=f'''            # Consume only this executed, parsed producer observation.
            if convergence_detector is not None:
                current_draft, conv_state = self._record_current_convergence(
                    convergence_detector, problem_frame, pass{num}, current_draft
                )
                if conv_state.should_stop:
                    early_exit = True
                    stop_reason = self._convergence_stop_reason(conv_state)''';assert old in s;s=s.replace(old,new)
# Preserve current producer observation in pass1 rather than invent a scalar callback.
needle='''                duration_ms=int((time.perf_counter() - started) * 1000),
            )

    # ------------------------------------------------------------------
    # Pass 2''';assert needle in s;s=s.replace(needle,'''                duration_ms=int((time.perf_counter() - started) * 1000),
                confidence_request_ref=draft.confidence_request_ref,
                confidence_observation=draft.confidence_observation,
            )

    # ------------------------------------------------------------------
    # Pass 2''')
old='''                response = await asyncio.wait_for(
                    self._llm.generate(
                        system=prompt,
                        user=(
                            "Review the draft and return strict JSON with findings. "
                            "Do not include markdown."
                        ),''';new='''                user_message = (
                    "Review the draft and return strict JSON with findings. "
                    "Do not include markdown."
                )
                request_ref = confidence_request_ref(system=prompt, user=user_message)
                response = await asyncio.wait_for(
                    self._llm.generate(
                        system=prompt,
                        user=user_message,''';assert old in s;s=s.replace(old,new)
needle='''                span.set_attribute("polisyos.drafter.findings_count", len(findings))
                return PassExecution(''';assert needle in s;s=s.replace(needle,'''                span.set_attribute("polisyos.drafter.findings_count", len(findings))
                observation = None
                if parse_ok and (confidence_adjustment is not None or findings):
                    assessed = self._update_confidence(draft, findings, confidence_adjustment)
                    observation = observe_candidate_confidence(
                        response=response,
                        source_text=content,
                        subject_ref=confidence_subject_ref(problem_frame),
                        request_ref=request_ref,
                        pass_number=pass_number,
                        value=assessed.confidence,
                    )
                return PassExecution(''')
needle='''                    confidence_adjustment=confidence_adjustment,
                    verification_code=verification_code,
                )''';assert needle in s;s=s.replace(needle,'''                    confidence_adjustment=confidence_adjustment,
                    verification_code=verification_code,
                    confidence_request_ref=request_ref,
                    confidence_observation=observation,
                )''')
start=s.index('''        return DraftResult(
            draft_id=draft.draft_id,''',s.index('    def _update_confidence('));end=s.index('\n\n    def _skipped_pass',start);s=s[:start]+'''        return replace(draft, confidence=updated_confidence)'''+s[end:]
pos=s.index('    def _skipped_pass')
methods='''    @staticmethod
    def _convergence_stop_reason(state: ConvergenceState) -> str:
        prefix = "resource_limit" if state.stop_kind == "resource_limit" else "candidate_stability"
        return f"{prefix}:{state.reason}"

    def _record_current_convergence(
        self,
        detector: ConvergenceDetector,
        problem_frame: ProblemFrame,
        current_pass: PassExecution,
        draft: DraftResult,
    ) -> tuple[DraftResult, ConvergenceState]:
        """Join the actual pass/parser result with its current candidate value."""
        observation = current_pass.confidence_observation
        eligible = current_pass.executed and current_pass.parse_ok and observation is not None
        if eligible:
            assert observation is not None
            # Code verification/deterministic checks may adjust the candidate,
            # without pretending the model itself emitted that derived value.
            observation = ConvergenceObservation.model_validate(
                {**observation.model_dump(), "value": draft.confidence}
            )
        else:
            observation = None
        state = detector.check_candidate_observation(
            observation,
            subject_ref=confidence_subject_ref(problem_frame),
            request_ref=current_pass.confidence_request_ref,
            source_text=current_pass.raw_llm_response,
            value=draft.confidence if eligible else None,
            pass_number=current_pass.pass_number,
            unavailable_reason=(
                "pass_not_executed" if not current_pass.executed
                else "pass_parse_failed" if not current_pass.parse_ok
                else "candidate_assessment_not_supplied"
            ),
        )
        return replace(
            draft,
            confidence_request_ref=current_pass.confidence_request_ref,
            confidence_observation=observation,
            convergence_state=state,
        ), state

''';s=s[:pos]+methods+s[pos:]
s=s.replace('''        budget_stop = stop_reason in {"budget_usd_exceeded", "max_extra_calls_exceeded"}''','''        budget_stop = stop_reason in {
            "budget_usd_exceeded", "max_extra_calls_exceeded", "resource_limit:budget_pressure"
        }
        if draft.convergence_state is not None:
            parent_span.set_attribute("polisyos.drafter.stop_kind", draft.convergence_state.stop_kind)
            parent_span.set_attribute("polisyos.drafter.scientific_converged", False)
            parent_span.set_attribute(
                "polisyos.drafter.observation_status", draft.convergence_state.observation_status
            )''')
save(base+'_drafter_orchestrator.py',s)
# Consolidation preserves the last checked state as explicitly historical; no fresh confidence is inferred.
p=base+'_drafter_parsing.py';s=(D/'postimages'/p).read_text();s=s.replace('''                convergence_state=None,
            ),''','''                convergence_state=(
                    type(original.convergence_state).model_validate(
                        {
                            **original.convergence_state.model_dump(),
                            "observation_status": "not_checked_after_consolidation",
                        }
                    )
                    if original.convergence_state is not None else None
                ),
            ),''');save(p,s)
# Narrow N4 context. Root composes this separately from cache/source/grounding changes.
p='policy-engine/src/polisyos/runtime/quality/design_generation.py';s=(D/'preimages'/p).read_text();needle='from polisyos.scientist.agent.drafter_models import MultiPassConfig';assert needle in s;s=s.replace(needle,'''from polisyos.scientist.orchestration.engine.convergence import (
    ConvergenceConfig,
    ConvergenceState,
)
'''+needle)
needle='''    drafter_pass_retry_count: int = Field(..., ge=0)''';assert needle in s;s=s.replace(needle,needle+'''
    drafter_convergence_profile: ConvergenceConfig | None = None
    drafter_convergence_state: ConvergenceState | None = None''',1)
needle='''        pass_retry_count=multipass_config.pass_retry_count,
        constitution_enabled=False,''';assert needle in s;s=s.replace(needle,'''        pass_retry_count=multipass_config.pass_retry_count,
        convergence=multipass_config.convergence,
        constitution_enabled=False,''',1)
needle='''    draft_path = _draft_generator_path(recording_client.calls[draft_call_start:], draft)''';assert needle in s;s=s.replace(needle,'''    effective_runtime_config = EffectiveGenerationRuntimeConfig.model_validate(
        {
            **effective_runtime_config.model_dump(),
            "drafter_convergence_state": getattr(draft, "convergence_state", None),
        }
    )
'''+needle,1)
needle='''        drafter_pass_retry_count=int(multipass_config.pass_retry_count),''';assert needle in s;s=s.replace(needle,needle+'''
        drafter_convergence_profile=multipass_config.convergence,''',1)
save(p,s)
# Reader compatibility: actual tool-loop stops on resource ceilings without scientific claims.
p=base+'tools/tool_loop.py';s=(D/'preimages'/p).read_text();needle='''    convergence_reason: str = ""''';assert needle in s;s=s.replace(needle,needle+'''
    stop_kind: str = "none"
    scientific_converged: bool = False''',1)
old='''            if conv_state.converged:
                return ToolLoopResult(''';assert old in s;s=s.replace(old,'''            if conv_state.should_stop:
                return ToolLoopResult(''',1)
needle='''                    convergence_reason=stop_reason or conv_state.reason,
                    final_score=score,''';assert needle in s;s=s.replace(needle,'''                    convergence_reason=(
                        conv_state.reason if conv_state.stop_kind == "resource_limit"
                        else stop_reason or conv_state.reason
                    ),
                    stop_kind=conv_state.stop_kind,
                    scientific_converged=False,
                    final_score=score,''',1);save(p,s)
print('orchestrator/N4-context/tool-loop AST_PASS; runtimeUNRUN')
