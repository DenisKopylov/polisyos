from types import FunctionType
from importlib import import_module
def harmless():
    return None
def body(callback):
    return callback("deferred_mutator_safe")
CODE = body.__code__
run = FunctionType(CODE, globals())
harmless()
run(import_module)
