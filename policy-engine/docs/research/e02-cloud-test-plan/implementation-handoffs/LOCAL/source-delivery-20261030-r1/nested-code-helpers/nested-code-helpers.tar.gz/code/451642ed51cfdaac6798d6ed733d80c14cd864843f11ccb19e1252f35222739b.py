import fcntl
import os
import subprocess
import sys
import tempfile
from pathlib import Path

scratch = Path("LOCAL/raw/e02-execution-20261027/repairs/SQL-owner-chain-r3/checks")
with tempfile.TemporaryDirectory(dir=scratch) as directory:
    path = Path(directory) / "stripe.lock"
    first = os.open(path, os.O_CREAT | os.O_RDWR, 0o600)
    second = os.open(path, os.O_RDWR)
    fcntl.flock(first, fcntl.LOCK_EX)
    try:
        try:
            fcntl.flock(second, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            print("second descriptor while held: blocked")
        else:
            raise AssertionError("second descriptor unexpectedly acquired lock")
        child_source = """
import fcntl
import os
import sys
descriptor = os.open(sys.argv[1], os.O_RDWR)
try:
    fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
except BlockingIOError:
    print("child while held: blocked")
else:
    raise SystemExit("child unexpectedly acquired lock")
"""
        child = subprocess.run(
            [sys.executable, "-c", child_source, str(path)],
            text=True,
            capture_output=True,
            check=False,
        )
        print("child exit:", child.returncode)
        print("child stdout:", child.stdout.rstrip())
        print("child stderr:", child.stderr.rstrip())
        if child.returncode:
            raise SystemExit(child.returncode)
    finally:
        fcntl.flock(first, fcntl.LOCK_UN)
        os.close(first)
    fcntl.flock(second, fcntl.LOCK_EX | fcntl.LOCK_NB)
    print("second descriptor after release: acquired")
    fcntl.flock(second, fcntl.LOCK_UN)
    os.close(second)
