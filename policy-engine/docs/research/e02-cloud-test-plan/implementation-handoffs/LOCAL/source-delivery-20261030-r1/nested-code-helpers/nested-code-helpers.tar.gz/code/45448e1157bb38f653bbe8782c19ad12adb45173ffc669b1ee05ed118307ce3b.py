"""Reuse reviewed R3 admission with the immutable corrected controller derivative."""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
PACKET = ROOT / "LOCAL/raw/e02-execution-20261027/repairs/R4-native-control-r1"


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError("pinned R4 admission component unavailable")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main() -> None:
    builder = load(
        PACKET / "controller-r3/admission_builder.py", "r4_admission_base_for_correction"
    )
    builder.CONTROLLER = PACKET / "fixture-admission-r1/controller.py"
    builder.controller = load(builder.CONTROLLER, "r4_admission_corrected_controller")
    builder.main()


if __name__ == "__main__":
    main()
