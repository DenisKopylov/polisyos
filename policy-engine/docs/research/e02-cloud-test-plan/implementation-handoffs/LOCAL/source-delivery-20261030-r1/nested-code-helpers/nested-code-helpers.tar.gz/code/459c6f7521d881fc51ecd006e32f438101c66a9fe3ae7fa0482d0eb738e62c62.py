import importlib
loader = (importlib,)[0].import_module
loader('unsupported_subscript_origin')
