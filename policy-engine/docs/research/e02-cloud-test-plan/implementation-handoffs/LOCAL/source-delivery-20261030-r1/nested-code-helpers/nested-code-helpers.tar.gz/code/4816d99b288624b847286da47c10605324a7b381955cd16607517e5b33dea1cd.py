from typing import Any, ClassVar, Protocol, TypeVar
from collections.abc import Mapping
S = TypeVar("S")
P = TypeVar("P", bound=Mapping[str, Any], contravariant=True)
class Signature: ...
class RegisteredMethod(Protocol[S, P]):
    signature: ClassVar[Signature]
    @staticmethod
    def pure_step(state: S, params: P) -> S: ...
class OriginalCompilerProtocol(Protocol):
    signature: Signature
    @staticmethod
    def pure_step(state: Any, params: Mapping[str, Any]) -> Any: ...
class PureStepOnlyProtocol(Protocol):
    @staticmethod
    def pure_step(state: Any, params: Mapping[str, Any]) -> Any: ...
def original(method: type[OriginalCompilerProtocol]) -> None: ...
def minimal(method: type[PureStepOnlyProtocol]) -> None: ...
def witness(registered: type[RegisteredMethod[Any, Any]], compatible: type[OriginalCompilerProtocol]) -> None:
    minimal(registered)
    minimal(compatible)
    original(compatible)
    original(registered)  # intentional old-boundary falsifier
