input raw/f16/f16_local_observer.py
