"""Snapshot observable Python module origins in each normally exiting child PID."""
from __future__ import annotations
import atexit
import hashlib
import importlib.util
import json
import os
import sys
from pathlib import Path

if os.environ.get('E02C_OUT') and os.environ.get('E02C_ROOT'):
    def _finish():
        root = Path(os.environ['E02C_ROOT']).resolve()
        out = Path(os.environ['E02C_OUT'])
        phase = os.environ.get('E02C_PHASE', 'unknown')
        index = json.loads(Path(os.environ['E02C_INDEX']).read_text())
        entries = []
        for name, module in sorted(list(sys.modules.items())):
            if module is None:
                continue
            is_project_name = any(name == prefix or name.startswith(prefix + '.') for prefix in ('polisyos', 'unit', 'tests', 'tools'))
            try:
                raw = getattr(module, '__file__', None)
                paths = list(getattr(module, '__path__', ()) or ())
            except Exception as exc:
                if is_project_name:
                    entries.append({'module':name, 'verdict':'project_origin_attribute_error', 'exception':type(exc).__name__})
                continue
            if raw is None and not is_project_name:
                continue
            item = {'module': name, 'file': str(raw) if raw else None, 'namespace_paths': [str(x) for x in paths]}
            if raw:
                path = Path(raw)
                if path.suffix == '.pyc':
                    try:
                        path = Path(importlib.util.source_from_cache(str(path)))
                    except ValueError:
                        pass
                try:
                    resolved = path.resolve(strict=True)
                    rel = resolved.relative_to(root).as_posix()
                except (OSError, ValueError, RuntimeError):
                    if not is_project_name:
                        continue
                    item['verdict'] = 'foreign_or_unreadable_project_origin'
                    try:
                        foreign = path.resolve(strict=True)
                        data = foreign.read_bytes()
                        item.update({'resolved_path':str(foreign), 'sha256':hashlib.sha256(data).hexdigest(), 'bytes':len(data)})
                    except (OSError, RuntimeError):
                        pass
                    entries.append(item)
                    continue
                if not (rel.startswith('policy-engine/src/') or rel.startswith('policy-engine/tests/') or rel.startswith('policy-engine/tools/')):
                    if not is_project_name:
                        continue
                    item['verdict'] = 'foreign_or_untracked_project_origin'
                    entries.append(item)
                    continue
                try:
                    data = resolved.read_bytes()
                    git_blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
                    item.update({'relative_path': rel, 'sha256': hashlib.sha256(data).hexdigest(),
                                 'bytes': len(data), 'git_blob': git_blob, 'expected_blob': index.get(rel),
                                 'verdict': 'MATCH' if index.get(rel) == git_blob else 'MISMATCH_OR_UNTRACKED'})
                except OSError:
                    item['verdict'] = 'unreadable_project_origin'
                entries.append(item)
            elif is_project_name:
                try:
                    valid = bool(paths) and all(Path(p).resolve(strict=True).is_relative_to(root / 'policy-engine') for p in paths)
                except (OSError, RuntimeError):
                    valid = False
                item['verdict'] = 'NAMESPACE_IN_CHECKOUT' if valid else 'foreign_or_unreadable_project_origin'
                entries.append(item)
        outpath = out / 'origins' / f'{phase}-{os.getpid()}.json'
        outpath.parent.mkdir(parents=True, exist_ok=True)
        outpath.write_text(json.dumps({'pid': os.getpid(), 'ppid': os.getppid(), 'phase': phase,
            'executable': sys.executable, 'entries': entries,
            'boundary': 'sys.modules snapshot at normal interpreter exit; transient imports and processes bypassing sitecustomize are not established'}, sort_keys=True) + '\n', encoding='utf-8')
    atexit.register(_finish)
