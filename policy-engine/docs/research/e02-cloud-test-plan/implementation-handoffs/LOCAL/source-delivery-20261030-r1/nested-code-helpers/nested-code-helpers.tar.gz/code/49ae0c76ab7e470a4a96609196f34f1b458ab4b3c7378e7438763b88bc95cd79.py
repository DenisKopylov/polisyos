"""Parse and lint every differing RAW postimage without importing product code."""
from __future__ import annotations

import ast
import hashlib
import json
import subprocess
import sys
import tomllib
from pathlib import Path

base = Path("LOCAL/raw/e02-execution-20261027/repairs/SQL-owner-chain-r3")
pre, post = base / "preimages", base / "postimages"
results = []
for path in sorted(post.rglob("*")):
    if not path.is_file():
        continue
    relative = path.relative_to(post)
    old = pre / relative
    if old.exists() and old.read_bytes() == path.read_bytes():
        continue
    raw = path.read_bytes()
    item = {"path": str(relative), "post_sha256": hashlib.sha256(raw).hexdigest()}
    if path.suffix == ".py":
        try:
            ast.parse(raw, filename=str(relative))
            item["ast"] = "PASS"
        except SyntaxError as exc:
            item["ast"] = str(exc)
        command = [
            "policy-engine/.venv/bin/python", "-m", "ruff", "check",
            "--config", "policy-engine/architecture/tooling/ruff/workspace_root.toml",
            "--stdin-filename", str(relative), "-",
        ]
        result = subprocess.run(command, input=raw, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        item.update(
            ruff_command=command,
            ruff_exit=result.returncode,
            ruff_stdout=result.stdout.decode("utf-8"),
            ruff_stderr=result.stderr.decode("utf-8"),
        )
    if path.suffix == ".toml":
        try:
            tomllib.loads(raw.decode())
            item["toml"] = "PASS"
        except (ValueError, UnicodeDecodeError) as exc:
            item["toml"] = str(exc)
    results.append(item)
report = {"python": sys.version, "scope": "all differing RAW postimages", "results": results}
(base / "checks/static-final.json").write_text(json.dumps(report, indent=2) + "\n")
print("changed files:", len(results))
print("python files:", sum(item["path"].endswith(".py") for item in results))
print("ast failures:", sum(item.get("ast", "PASS") != "PASS" for item in results))
print("ruff failures:", sum(item.get("ruff_exit", 0) != 0 for item in results))
print("toml failures:", sum(item.get("toml", "PASS") != "PASS" for item in results))
if any(
    item.get("ast", "PASS") != "PASS"
    or item.get("ruff_exit", 0) != 0
    or item.get("toml", "PASS") != "PASS"
    for item in results
):
    raise SystemExit(1)
