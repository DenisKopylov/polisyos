"""Detach one provider call and bind reuse to its actual successful dispatch."""

from __future__ import annotations

import inspect
import json
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from polisyos.common.serialization import decode_json_object

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable


def freeze_wire_object(value: dict[str, Any]) -> bytes:
    """Freeze already projected wire JSON without coercing unknown values.

    Typed DTO owners must apply their public JSON projection before this
    transport boundary. Raw datetime/model/unknown values and nonfinite numbers
    are rejected, rather than stringified or normalized to null.
    """

    def verify(item: object, depth: int) -> None:
        if depth > 128:
            raise ValueError("prepared_wire_depth_exceeded")
        if type(item) in (str, int, float, bool, type(None)):
            return
        if isinstance(item, (list, tuple)):
            for member in item:
                verify(member, depth + 1)
            return
        if type(item) is dict:
            for key, member in item.items():
                if type(key) is not str:
                    raise ValueError("prepared_wire_key_must_be_text")
                verify(member, depth + 1)
            return
        raise ValueError("prepared_wire_value_not_json")

    verify(value, 0)
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def thaw_wire_object(value: bytes) -> dict[str, Any]:
    """Read a detached native object from an immutable prepared call."""
    return decode_json_object(value, kind="prepared LLM request")


@dataclass(frozen=True, slots=True)
class PreparedLLMResult:
    """One physical result and the actual successful request projection."""

    response: Any
    effective_identity: bytes = field(repr=False)


@dataclass(frozen=True, slots=True)
class PreparedLLMRequest:
    """Immutable request identity with one owner-supplied physical executor."""

    identity: bytes = field(repr=False)
    execute: Callable[[], Awaitable[PreparedLLMResult]] = field(repr=False, compare=False)
    reusable: bool = True

    def admits(self, result: PreparedLLMResult) -> bool:
        """Admit only a result from the exact prepared successful request."""
        return self.reusable and result.effective_identity == self.identity


def prepare_immutable_call(
    generate: Callable[..., Any],
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
    *,
    reusable: bool = False,
) -> PreparedLLMRequest:
    """Adapt a non-negotiating provider's actual call-entry contract.

    Opaque adapters default to physical-only work. Known deterministic adapters
    may opt in when this call entry is their complete dispatch boundary.
    """
    snapshot = freeze_wire_object({"args": args, "kwargs": kwargs})

    async def execute() -> PreparedLLMResult:
        detached = thaw_wire_object(snapshot)
        response = generate(*detached["args"], **detached["kwargs"])
        if inspect.isawaitable(response):
            response = await response
        return PreparedLLMResult(response, snapshot)

    return PreparedLLMRequest(snapshot, execute, reusable)


def prepare_provider_call(
    client: object, args: tuple[Any, ...], kwargs: dict[str, Any]
) -> tuple[PreparedLLMRequest, bytes]:
    """Snapshot caller wire values once before provider preparation and dispatch."""
    caller_snapshot = freeze_wire_object({"args": args, "kwargs": kwargs})
    detached = thaw_wire_object(caller_snapshot)
    prepare = getattr(client, "prepare_cache_request", None)
    if callable(prepare):
        prepared = prepare(*detached["args"], **detached["kwargs"])
        if type(prepared) is not PreparedLLMRequest:
            raise TypeError("provider_prepared_request_untyped")
    else:
        generate = getattr(client, "generate", None)
        if not callable(generate):
            raise TypeError("provider_generate_unavailable")
        prepared = prepare_immutable_call(generate, tuple(detached["args"]), detached["kwargs"])
    return prepared, caller_snapshot
