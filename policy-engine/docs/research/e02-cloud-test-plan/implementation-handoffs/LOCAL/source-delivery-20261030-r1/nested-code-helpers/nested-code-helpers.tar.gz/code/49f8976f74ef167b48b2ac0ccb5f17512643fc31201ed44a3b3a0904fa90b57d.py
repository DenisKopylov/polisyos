"""Run synthetic standard-library controls; never import PolicyOS or pytest."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import sys
import threading
import types
from pathlib import Path

for key in ('E02C_OUT', 'E02C_ROOT', 'E02C_INDEX'):
    os.environ.pop(key, None)
BASE = Path(__file__).resolve().parent
HELPER = BASE.parent / 'files/policy-engine/tools/quality/testing/tc_sql_mc_witness/sitecustomize.py'
spec = importlib.util.spec_from_file_location('bounded_fixture_capture', HELPER)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
Capture = module.ActualCodeCapture
RESULTS = []


def fixture(label):
    root = BASE / ('scratch-' + label + '-' + str(os.getpid()))
    path = root / 'policy-engine/src/polisyos/fixture.py'
    path.parent.mkdir(parents=True, exist_ok=False)
    path.write_text('def selected(value):\n    return value + 1\n'
                    'def uncalled():\n    return -1\n'
                    'def outer():\n    def nested(value):\n        return value * 2\n'
                    '    return nested\n')
    data = path.read_bytes()
    blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data, usedforsecurity=False).hexdigest()
    name = 'polisyos.fixture_' + label
    spec = importlib.util.spec_from_file_location(name, path)
    owner = importlib.util.module_from_spec(spec)
    index = {'policy-engine/src/polisyos/fixture.py': blob}
    capture = Capture(root, index, BASE)
    return path, name, spec, owner, capture


def unrelated():
    return 3


path, name, spec, owner, capture = fixture('bounded')
events = []
capture.start()
capture.select_returns(lambda code: code.co_name == 'selected' and code.co_filename == str(path), lambda frame, value: events.append(value), None)
for _ in range(100_000):
    assert unrelated() == 3
sys.modules[name] = owner
spec.loader.exec_module(owner)
assert owner.selected(2) == 3
assert owner.outer()(5) == 10
sys.modules.pop(name)  # A transient first-party module must stay in the actual-code census.
report = capture.report()
assert report['callback_invocations'] < 100, report['callback_invocations']
assert report['code_census_complete_for_observed_events'], report
assert events == [3]
assert 'uncalled' not in {row['qualname'] for row in report['codes']}
assert {'<module>', 'selected', 'outer', 'outer.<locals>.nested'} <= {row['qualname'] for row in report['codes']}
RESULTS.append({'control': '100k_non_target_and_called_uncalled_transient', 'status': 'PASS', 'callbacks': report['callback_invocations'], 'returns': report['selected_return_callbacks'], 'codes': report['codes']})

path, name, spec, owner, capture = fixture('threads')
sys.modules[name] = owner
spec.loader.exec_module(owner)
ready, go = threading.Event(), threading.Event()
values = []
def work():
    ready.set()
    go.wait()
    for value in range(7):
        owner.selected(value)
existing = threading.Thread(target=work)
existing.start()
ready.wait()
capture.start()
capture.select_returns(lambda code: code.co_name == 'selected' and code.co_filename == str(path), lambda frame, value: values.append((threading.get_ident(), value)), None)
go.set()
existing.join()
owner.selected(9)
newer = threading.Thread(target=lambda: owner.selected(10))
newer.start()
newer.join()
report = capture.report()
assert len(values) == 9 and len({row[0] for row in values}) >= 2
assert report['code_census_complete_for_observed_events'], report
assert sys.getprofile() is None and threading.getprofile() is None
RESULTS.append({'control': 'existing_and_new_threads', 'status': 'PASS', 'returns': len(values), 'thread_ids': sorted({row[0] for row in values}), 'census': report})
sys.modules.pop(name)

path, name, spec, owner, capture = fixture('wrong_origin')
sys.modules[name] = owner
spec.loader.exec_module(owner)
seen = []
capture.start()
capture.select_returns(lambda code: code.co_name == 'selected' and code.co_filename == str(path), lambda frame, value: seen.append(value), None)
owner.selected(1)
foreign = types.ModuleType('polisyos.foreign_fixture')
foreign.__file__ = str(path.parent / 'foreign.py')
Path(foreign.__file__).write_text('# different origin\n')
foreign.__spec__ = importlib.util.spec_from_file_location(foreign.__name__, foreign.__file__)
sys.modules[foreign.__name__] = foreign
clone = types.FunctionType(owner.selected.__code__, foreign.__dict__)
assert clone(2) == 3
report = capture.report()
assert seen == [2] and not report['code_census_complete_for_observed_events']
assert any(row['reason'] == 'selected_return_module_globals_changed' for row in report['errors'])
RESULTS.append({'control': 'same_code_wrong_origin', 'status': 'PASS', 'census': report})
sys.modules.pop(foreign.__name__)
sys.modules.pop(name)

path, name, spec, owner, capture = fixture('altered_code')
sys.modules[name] = owner
spec.loader.exec_module(owner)
changed = compile('def selected(value):\n    return value + 99\n', str(path), 'exec').co_consts[0]
owner.selected.__code__ = changed
seen = []
capture.start()
capture.select_returns(lambda code: code.co_name == 'selected' and code.co_filename == str(path), lambda frame, value: seen.append(value), None)
assert owner.selected(1) == 100
report = capture.report()
assert not seen and not report['code_census_complete_for_observed_events']
assert any(not row['compilation_match'] for row in report['codes'])
RESULTS.append({'control': 'same_file_name_changed_executing_code', 'status': 'PASS', 'census': report})
sys.modules.pop(name)

path, name, spec, owner, capture = fixture('foreign_filename')
# Use a non-project namespace, but retain the actual first-party module-origin claim.
name = 'synthetic_origin_claim'
spec = importlib.util.spec_from_file_location(name, path)
owner = importlib.util.module_from_spec(spec)
sys.modules[name] = owner
spec.loader.exec_module(owner)
foreign_path = path.parent.parent.parent.parent / 'foreign.py'
foreign_path.write_text('def hidden(value):\n    return value + 77\n')
changed = compile(foreign_path.read_bytes(), str(foreign_path), 'exec').co_consts[0]
owner.selected.__code__ = changed
capture.start()
assert owner.selected(1) == 78
report = capture.report()
assert report['codes'] and not report['code_census_complete_for_observed_events']
assert any(row.get('origin_error') for row in report['codes'])
RESULTS.append({'control': 'foreign_filename_cannot_hide_first_party_origin', 'status': 'PASS', 'census': report})
sys.modules.pop(name)

print(json.dumps({'python': sys.version, 'executable': sys.executable, 'controls': RESULTS}, sort_keys=True, indent=2))
