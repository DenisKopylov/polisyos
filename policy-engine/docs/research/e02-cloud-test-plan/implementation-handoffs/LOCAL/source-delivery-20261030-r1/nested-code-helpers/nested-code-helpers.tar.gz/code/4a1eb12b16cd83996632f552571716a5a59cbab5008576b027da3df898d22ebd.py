from types import FunctionType
from importlib import import_module
def body(callback):
    return callback("bridge_callback")
def replacement():
    return None
body.__code__ = replacement.__code__
CODE = body.__code__
run = FunctionType(CODE, globals())
