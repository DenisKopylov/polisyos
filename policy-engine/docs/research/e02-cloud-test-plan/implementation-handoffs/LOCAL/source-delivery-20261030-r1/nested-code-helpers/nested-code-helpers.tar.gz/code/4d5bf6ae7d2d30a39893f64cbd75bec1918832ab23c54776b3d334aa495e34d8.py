def require_catalog_serving_graph_binding(graph: object, source: CatalogServingSourcePaths) -> None:
    """Reject an injected graph that does not use the explicitly selected database."""
    return None
