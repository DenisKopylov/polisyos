"""Root-only runner and bounded selected-code qualification for one G27 case."""
from __future__ import annotations

import argparse
from datetime import UTC, datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import xml.etree.ElementTree as ET

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
PACKET = ROOT / 'LOCAL/raw/e02-execution-20261027/repairs/G27-local-owner-oracle-r2'
PRODUCT = ROOT / 'policy-engine'
NATIVE = PRODUCT / ('docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/'
                    'root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/'
                    'deep-task-status-audit-20261027-r1')
RUNNER = NATIVE / 'run_case_with_tools_r3.py'


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def require(condition: object, reason: str) -> None:
    if not condition:
        raise SystemExit(reason)


def snapshot(bindings: list[dict]) -> tuple[list[dict], list[str]]:
    rows, failures = [], []
    for expected in bindings:
        path = ROOT / expected['path']
        try:
            if path.is_symlink() or not path.is_file():
                raise ValueError('not a regular non-symlink file')
            stat = path.stat()
            data = path.read_bytes()
            actual = {'path': expected['path'], 'bytes': len(data), 'sha256': sha(data),
                      'device': stat.st_dev, 'inode': stat.st_ino, 'mtime_ns': stat.st_mtime_ns}
            rows.append(actual)
            if actual != expected:
                failures.append(expected['path'] + ': identity/content changed')
        except (OSError, ValueError) as exc:
            failures.append(expected['path'] + ': ' + type(exc).__name__)
    return rows, failures


def _module_for(path: str) -> str | None:
    prefix = 'policy-engine/src/'
    return path[len(prefix):-3].replace('/', '.') if path.startswith(prefix) and path.endswith('.py') else None


def qualify_case(out: Path, plan: dict, spec: dict) -> dict:
    """Inspect same-PID C134 rows for deciding bodies; never gate on its global census."""
    issues: list[str] = []
    facts: dict = {'pid_witnesses': [], 'selected_rows': [], 'global_census': 'NOT_ESTABLISHED'}
    source = {row['path']: row for row in plan['g27']['source_bindings']}
    try:
        event = json.loads((out/'collection-events.json').read_bytes())
        profile = json.loads((out/'pytest-execution-profile.json').read_bytes())
        nodes = plan['nodes']
        if (event.get('expected_nodeids') != nodes or event.get('collected_nodeids_before_guard') != nodes
            or event.get('mismatch') is not None):
            issues.append('actual collection differs from exact selected nodes')
        if not profile.get('profile_identity_complete') or not profile.get('within_phase_profile_match'):
            issues.append('pytest profile incomplete or changed within phase')
        parent_pid = event['pid']
        if profile.get('pid') != parent_pid:
            issues.append('pytest profile and collection PID differ')
    except (OSError, KeyError, ValueError, TypeError) as exc:
        return {'selected_source_qualification': 'ERROR', 'issues': ['collection/profile missing or invalid: ' + type(exc).__name__], **facts}
    origins = {}
    for path in sorted((out/'c134/origins').glob('*.json')):
        try:
            record = json.loads(path.read_bytes())
            pid = record['pid']
            if pid in origins:
                issues.append('duplicate PID origins: ' + str(pid))
            origins[pid] = (path, record)
        except (OSError, ValueError, KeyError, TypeError) as exc:
            issues.append('origin unreadable: ' + str(path) + ': ' + type(exc).__name__)
    if parent_pid not in origins:
        issues.append('normal pytest PID origin missing')
    children = []
    for path in sorted((out/'basetemp').rglob('command.json')):
        try:
            journal = json.loads(path.read_bytes())
            argv = journal.get('argv', [])
            if 'tests._helpers.g27_owner_generation_oracle' not in argv:
                continue
            pid = journal.get('pid')
            children.append(pid)
            if type(pid) is not int or journal.get('status') != 'EXITED' or journal.get('exit') != 0:
                issues.append('fresh owner child not normal: ' + str(path))
            if pid not in origins:
                issues.append('fresh owner child origin missing: ' + str(pid))
            elif origins[pid][1].get('ppid') != parent_pid:
                issues.append('fresh owner child parent PID mismatch: ' + str(pid))
        except (OSError, ValueError, TypeError) as exc:
            issues.append('child journal invalid: ' + str(path) + ': ' + type(exc).__name__)
    if plan['g27']['selection'] == 'pilot' and not children:
        issues.append('pilot did not retain any fresh owner child journal')
    target_pairs = {(row['path'], row['qualname']) for row in spec['mandatory_pilot_parent']}
    target_pairs |= {(row['path'], row['qualname']) for row in spec['mandatory_pilot_child']}
    new_paths = set(spec['candidate_paths'])
    wanted_pids = {parent_pid, *[pid for pid in children if type(pid) is int]}
    rows_by_pid: dict[int, set[tuple[str, str]]] = {}
    for pid, (path, record) in origins.items():
        capture = record.get('actual_code_capture', {})
        if capture.get('pid') != pid:
            issues.append('capture PID mismatch: ' + str(pid))
            continue
        relevant = []
        for row in capture.get('codes', []):
            pair = (row.get('relative_path'), row.get('qualname'))
            if pair[0] in new_paths or pair in target_pairs:
                relevant.append(row)
        if not relevant:
            continue
        # Every observed relevant PID is validated; an unknown extra PID remains a boundary.
        if pid not in wanted_pids:
            issues.append('relevant source executed in an unjournaled PID: ' + str(pid))
        rows_by_pid[pid] = set()
        for row in relevant:
            rel, name = row.get('relative_path'), row.get('qualname')
            rows_by_pid[pid].add((rel, name))
            expected = source.get(rel)
            expected_module = _module_for(rel) if isinstance(rel, str) else None
            source_read = capture.get('source_reads', {}).get(row.get('source_read_receipt'), {})
            valid = (expected is not None and row.get('compilation_match') is True and
                     row.get('compilation_image') in ('source', 'pinned_pytest_assertion_rewrite') and
                     row.get('source_read') in ('READ', 'CACHED_BOUND_READ') and not row.get('origin_error') and
                     isinstance(row.get('module'), str) and bool(row['module']) and
                     (expected_module is None or row['module'] == expected_module) and
                     row.get('source_sha256') == expected['sha256'] and row.get('source_bytes') == expected['bytes'] and
                     row.get('git_blob') == expected['git_blob'] == row.get('expected_blob') and
                     source_read.get('sha256') == expected['sha256'] and source_read.get('git_blob') == expected['git_blob'] and
                     row.get('resolved_path') == str(ROOT/rel) and
                     isinstance(row.get('code_sha256'), str) and len(row['code_sha256']) == 64 and
                     isinstance(row.get('thread_ids'), list) and bool(row['thread_ids']))
            if row.get('compilation_image') == 'pinned_pytest_assertion_rewrite':
                valid = valid and row.get('compiler_source_sha256') == spec['assertion_rewriter_sha256']
            if not valid:
                issues.append(f'selected code did not bind/compile: pid={pid} {rel}::{name}')
            facts['selected_rows'].append({'pid': pid, 'path': rel, 'qualname': name,
                'module': row.get('module'), 'code_sha256': row.get('code_sha256'),
                'thread_ids': row.get('thread_ids'), 'compilation_image': row.get('compilation_image'),
                'source_sha256': row.get('source_sha256'), 'valid': bool(valid)})
        facts['pid_witnesses'].append({'pid': pid, 'origin': str(path), 'origin_sha256': sha(path.read_bytes()),
            'relevant_rows': len(relevant), 'reported_global_complete': capture.get('code_census_complete_for_observed_events')})
    parent_rows = rows_by_pid.get(parent_pid, set())
    for node in plan['nodes']:
        test_path, function = node.split('::')
        if ('policy-engine/' + test_path, function) not in parent_rows:
            issues.append('actual selected pytest body missing: ' + node)
    if plan['g27']['selection'] == 'pilot':
        for item in spec['mandatory_pilot_parent']:
            if (item['path'], item['qualname']) not in parent_rows:
                issues.append('pilot parent mandatory code missing: ' + item['path'] + '::' + item['qualname'])
        for pid in children:
            for item in spec['mandatory_pilot_child']:
                if (item['path'], item['qualname']) not in rows_by_pid.get(pid, set()):
                    issues.append('fresh child mandatory code missing: ' + str(pid) + ' ' + item['path'] + '::' + item['qualname'])
    return {'selected_source_qualification': 'PASS' if not issues else 'ERROR', 'issues': issues, **facts}


def semantic(out: Path, plan: dict) -> tuple[str, dict]:
    try:
        cases = list(ET.parse(out/'pytest.xml').getroot().iter('testcase'))
        expected = [x.split('::')[-1] for x in plan['nodes']]
        if [case.get('name') for case in cases] != expected:
            return 'ERROR', {'reason': 'JUnit case set/order mismatch'}
        failures = [case for case in cases if case.find('failure') is not None]
        errors = [case for case in cases if case.find('error') is not None]
        skipped = [case for case in cases if case.find('skipped') is not None]
        info = {'cases': len(cases), 'failures': len(failures), 'errors': len(errors), 'skipped': len(skipped)}
        if plan['g27']['stage'] == 'mutant':
            failure = failures[0].find('failure') if len(failures) == 1 else None
            text = '' if failure is None else ''.join(failure.itertext()) + str(failure.get('message', ''))
            return ('EXPECTED_RED' if len(cases) == 1 and failure is not None and not errors and not skipped
                    and 'G27_WITHDRAWN_A_FALSE_CURRENT' in text else 'ERROR'), info
        return ('PASS' if not failures and not errors and not skipped else 'FAIL'), info
    except (OSError, ET.ParseError, ValueError) as exc:
        return 'ERROR', {'reason': 'JUnit missing or malformed: ' + type(exc).__name__}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--plan-sha256', required=True)
    args = parser.parse_args()
    plan_path = args.plan
    require(plan_path.is_absolute() and plan_path.parent == NATIVE and not plan_path.is_symlink() and
            plan_path.is_file(), 'exact regular native plan required')
    plan_bytes = plan_path.read_bytes()
    require(sha(plan_bytes) == args.plan_sha256, 'plan hash mismatch')
    plan = json.loads(plan_bytes)
    case = plan['case_id']
    require(plan_path == NATIVE / (case + '.json'), 'plan filename/case mismatch')
    out = NATIVE/case
    require(not os.path.lexists(out), 'case slot already exists')
    spec_path = PACKET/'phase-inputs.json'
    spec_bytes = spec_path.read_bytes()
    require(sha(spec_bytes) == plan['g27']['phase_inputs_sha256'], 'phase inputs differ')
    spec = json.loads(spec_bytes)
    bindings = plan['g27']['runtime_input_bindings']
    require(len(bindings) == len({row['path'] for row in bindings}), 'duplicate runtime binding')
    before, errors = snapshot(bindings)
    for path in (PRODUCT, PRODUCT/'src', PACKET, PACKET/'postimages',
                 ROOT/'LOCAL/raw/e02-execution-20261027/next-native/F16-current-local-r7',
                 ROOT/'LOCAL/raw/e02-execution-20261027/next-native/F16-full-source-r1/instruments'):
        if os.path.lexists(path/'sitecustomize.py'):
            errors.append('earlier sitecustomize shadow: ' + str(path))
    prepare_spec = importlib.util.spec_from_file_location('g27_prepare_native', PACKET/'prepare_native.py')
    require(prepare_spec is not None and prepare_spec.loader is not None, 'preparer unavailable')
    prepare = importlib.util.module_from_spec(prepare_spec)
    prepare_spec.loader.exec_module(prepare)
    try:
        current_env = prepare.environment_snapshot(spec)
        if current_env != plan['g27']['environment']:
            errors.append('existing environment binding changed')
        if (prepare.git('rev-parse', 'HEAD').decode().strip() != plan['source_head'] or
            prepare.git('rev-parse', 'HEAD^{tree}').decode().strip() != plan['source_tree'] or
            not prepare.git_ok('diff', '--quiet') or not prepare.git_ok('diff', '--cached', '--quiet', 'HEAD')):
            errors.append('source or index differs from plan')
    except (Exception, SystemExit) as exc:
        errors.append('prelaunch admission error: ' + str(exc))
    argv = [str(PRODUCT/'.venv/bin/python'), '-B', str(RUNNER), str(plan_path)]
    runner_exit = None
    launch_error = None
    stdout = stderr = b''
    started = datetime.now(UTC).isoformat()
    if not errors:
        try:
            proc = subprocess.Popen(argv, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                    start_new_session=True)
            try:
                stdout, stderr = proc.communicate(timeout=660)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGTERM)
                try:
                    stdout, stderr = proc.communicate(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid, signal.SIGKILL)
                    stdout, stderr = proc.communicate()
                launch_error = 'wrapper protective timeout; process group stopped'
            runner_exit = proc.returncode
        except (OSError, ValueError) as exc:
            launch_error = type(exc).__name__ + ': ' + str(exc)
    if not out.exists():
        out.mkdir(exist_ok=False)
    require(not out.is_symlink() and out.is_dir(), 'case output is not a regular directory')
    for name, data in (('g27-runner.stdout', stdout), ('g27-runner.stderr', stderr)):
        with (out/name).open('xb') as stream:
            stream.write(data)
    after, post_errors = snapshot(bindings)
    if before != after:
        post_errors.append('consumed input identities changed between boundary samples')
    if plan_path.is_symlink() or not plan_path.is_file() or sha(plan_path.read_bytes()) != args.plan_sha256:
        post_errors.append('plan changed during run')
    try:
        if (prepare.git('rev-parse', 'HEAD').decode().strip() != plan['source_head'] or
            prepare.git('rev-parse', 'HEAD^{tree}').decode().strip() != plan['source_tree'] or
            not prepare.git_ok('diff', '--quiet') or not prepare.git_ok('diff', '--cached', '--quiet', 'HEAD')):
            post_errors.append('source or index changed during run')
        if prepare.environment_snapshot(spec) != plan['g27']['environment']:
            post_errors.append('environment binding changed during run')
    except (Exception, SystemExit) as exc:
        post_errors.append('postrun admission error: ' + str(exc))
    if errors or launch_error or post_errors:
        qualification = {'selected_source_qualification': 'ERROR', 'issues': errors + post_errors +
                         ([launch_error] if launch_error else []), 'global_census': 'NOT_ESTABLISHED'}
        outcome, junit = 'ERROR', {'reason': 'run/admission boundary failed'}
    else:
        qualification = qualify_case(out, plan, spec)
        outcome, junit = semantic(out, plan)
    # Semantic result and code-source qualification are deliberately separate.
    receipt = {'schema': 'g27-local-qualified-case-v1', 'stage': plan['g27']['stage'],
        'selection': plan['g27']['selection'], 'source_head': plan['source_head'],
        'source_tree': plan['source_tree'], 'nodes': plan['nodes'], 'plan_sha256': args.plan_sha256,
        'started_at': started, 'finished_at': datetime.now(UTC).isoformat(), 'runner_argv': argv,
        'runner_exit': runner_exit, 'launch_error': launch_error, 'input_errors_before': errors,
        'input_errors_after': post_errors, 'inputs_before': before, 'inputs_after': after,
        'input_boundary_state': 'IDENTITY_MATCH_AT_BOUNDARIES' if not errors and not post_errors else 'ERROR',
        'continuous_external_mutation': 'NOT_ESTABLISHED; root must hold exclusive writer lease',
        'semantic_outcome': outcome, 'junit': junit, **qualification,
        'scope': 'selected observed CodeTypes and fixture property only', 'closure_ids': []}
    encoded = (json.dumps(receipt, indent=2) + '\n').encode()
    target = out/'g27-qualification.json'
    with target.open('xb') as stream:
        stream.write(encoded)
    print(json.dumps({'receipt': str(target), 'sha256': sha(encoded), 'semantic_outcome': outcome,
                      'selected_source_qualification': receipt['selected_source_qualification'],
                      'runner_exit': runner_exit, 'issues': receipt.get('issues', [])}))
    expected = 'EXPECTED_RED' if plan['g27']['stage'] == 'mutant' else 'PASS'
    return 0 if outcome == expected and receipt['selected_source_qualification'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
