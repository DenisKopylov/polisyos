"""Unrun behavior falsifier for installed Runtime/C105 filesystem scoping.

Historical pre-fix diagnostic only; not an acceptance control for the
current guarded-owner proposal. It directly calls an internal reader the new
wrapper deliberately does not expose. It has never been executed; the current
proposal's actual guard component tests are in the postimage test module.
"""


def test_installed_runtime_owner_scopes_real_cas_and_retains_guard(tmp_path, monkeypatch):
    import pytest

    from polisyos.core.artifacts import ArtifactOwnershipError
    from polisyos.core.artifacts.manifest import SchemaInfo
    from polisyos.core.artifacts.write_contract import ArtifactWriteOptions
    from polisyos.runtime.http.app import create_runtime_api_app
    from polisyos.runtime.http.resilience import BlockingDependencyGuard

    monkeypatch.setenv("POLISYOS_EXECUTION_PROFILE", "dev")
    app = create_runtime_api_app(cas_root=tmp_path / "cas", core_runs_root=tmp_path / "runs")
    container = app.state.runtime_container
    owner = container.decision_validity_service
    store = container.runtime_api_context.store
    assert owner._store is store

    # Actual filesystem ownership, not an asserted owner field or fake store.
    scoped = store.for_tenant("tenant-a", "cell-a")
    ref = scoped.put_json(
        {"fixture": "owned by tenant a"},
        ArtifactWriteOptions(
            kind="fixture.source_contract", media_type="application/json",
            schema=SchemaInfo(name="fixture.SourceContract", version="1.0"),
        ),
        return_selected_profile=True,
    )
    original = BlockingDependencyGuard.run
    guarded_operations = []

    def observe_guard(self, fn, *args, **kwargs):
        guarded_operations.append(fn)
        return original(self, fn, *args, **kwargs)

    monkeypatch.setattr(BlockingDependencyGuard, "run", observe_guard)
    owner._source_admission._verify_ref(ref, tenant_id="tenant-a", cell_id="cell-a")
    assert guarded_operations
    with pytest.raises((ArtifactOwnershipError, OSError, ValueError)):
        owner._source_admission._verify_ref(ref, tenant_id="tenant-b", cell_id="cell-b")
