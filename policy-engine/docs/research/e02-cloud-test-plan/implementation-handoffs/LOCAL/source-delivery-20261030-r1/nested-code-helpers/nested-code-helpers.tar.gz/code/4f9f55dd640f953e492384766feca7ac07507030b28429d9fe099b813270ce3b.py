from collections.abc import Callable, Mapping
from typing import Any, ClassVar, Protocol, TypeVar
S = TypeVar("S")
P = TypeVar("P", bound=Mapping[str, Any], contravariant=True)
class Signature: ...
class Method(Protocol[S, P]):
    signature: ClassVar[Signature]
    @staticmethod
    def pure_step(state: S, params: P) -> S: ...
class Registry(Protocol):
    def get(self, name: str) -> type[Method[Any, Any]]: ...
def requires_method(method: type[Method[Any, Mapping[str, Any]]]) -> int: return 1
def use_builder(builder: Callable[[], int]) -> int: return builder()
def witness(reg: Registry) -> None:
    for i in range(2):
        try:
            method_a = reg.get("a")
            method_b = reg.get("b")
        except Exception:
            method_a = None
            method_b = None
        if method_a is not None and method_b is not None:
            use_builder(lambda: requires_method(method_b))
            requires_method(method_b)
