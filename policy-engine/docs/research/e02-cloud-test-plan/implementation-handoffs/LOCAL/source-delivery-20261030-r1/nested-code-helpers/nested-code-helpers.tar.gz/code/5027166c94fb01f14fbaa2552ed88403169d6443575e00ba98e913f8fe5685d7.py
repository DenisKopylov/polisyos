"""Qualify one captured C07 native command without rerunning any computation."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("plan", type=Path)
    args = parser.parse_args()
    plan_path = args.plan.resolve(strict=True)
    plan = json.loads(plan_path.read_text())
    output = plan_path.parent / plan["case_id"]
    audit_path = output / "audit-result.json"
    audit = json.loads(audit_path.read_text())
    result = audit["result"]
    required = [audit_path, output / "source-profile-freeze.json", output / "pytest.xml"]
    required += [output / result[key] for key in ("stdout_path", "stderr_path")]
    reasons = []
    if audit["plan"] != plan:
        reasons.append("captured plan differs from issued exact plan")
    if (
        not result.get("complete")
        or result.get("aborted_reason")
        or not result.get("process_group_gone")
    ):
        reasons.append("command incomplete, aborted or process group not gone")
    if audit.get("current_mismatches"):
        reasons.append("loaded Python source readset mismatch")
    if audit["guard_after"]["head"] != plan["source_head"]:
        reasons.append("source HEAD changed during capture")
    root = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
    actual_committed_tree = subprocess.check_output(  # noqa: S603 -- fixed local executable and pinned arguments
        ["/usr/bin/git", "rev-parse", plan["source_head"] + "^{tree}"], cwd=root, text=True
    ).strip()
    if actual_committed_tree != plan["source_tree"]:
        reasons.append("pinned committed tree differs from issued source identity")
    freeze_path = output / "source-profile-freeze.json"
    if not freeze_path.is_file():
        reasons.append("retained source/profile freeze unavailable")
    elif _sha(freeze_path) != audit["source_profile_freeze_sha256"]:
        reasons.append("retained source/profile freeze bytes differ from capture receipt")
    try:
        cases = list(ET.parse(output / "pytest.xml").iter("testcase"))  # noqa: S314 -- own pytest capture
    except (FileNotFoundError, ET.ParseError):
        reasons.append("retained complete JUnit bytes unavailable or invalid")
        actual_junit = None
    else:
        actual_junit = {
            "tests": len(cases),
            "failures": sum(case.find("failure") is not None for case in cases),
            "errors": sum(case.find("error") is not None for case in cases),
            "skipped": sum(case.find("skipped") is not None for case in cases),
        }
    if actual_junit != result.get("junit"):
        reasons.append("retained complete JUnit bytes differ from captured case results")
    if result.get("junit") != plan["expected_junit"]:
        reasons.append("actual JUnit complete case/PASS/FAIL/ERROR/SKIP counts differ")
    mode = plan.get("extra_env", {}).get("POLISYOS_C07_CONTROL_MODE")
    expected_exit = 1 if mode else 0
    if result.get("return_code") != expected_exit:
        reasons.append("actual command exit differs from the declared positive/removal outcome")
    control = None
    if mode:
        control_path = output / "control-mutation.json"
        required.append(control_path)
        if not control_path.is_file():
            reasons.append("control executable custody receipt unavailable")
        else:
            control = json.loads(control_path.read_text())
            active_path = Path(control["active_function_source_path"])
            required.append(active_path)
            if active_path.parent.resolve() != output.resolve():
                reasons.append("active executable source locator is outside this native output")
            if not active_path.is_file():
                reasons.append("actual active executable source bytes unavailable")
            elif _sha(active_path) != control["active_function_source_sha256"]:
                reasons.append("active executable source bytes mismatch")
            if (
                control.get("source_head") != plan["source_head"]
                or control.get("source_tree") != plan["source_tree"]
            ):
                reasons.append("control source identity differs from native plan")
            if control.get("mode") != mode or not control.get("control_discriminator_satisfied"):
                reasons.append(
                    "actual targeted assertion/semantic/custody discriminator not established"
                )
    for path in required:
        if not path.is_file():
            reasons.append(f"required deciding output bytes unavailable: {path}")
    evidence = [
        {"path": str(path), "bytes": path.stat().st_size, "sha256": _sha(path)}
        for path in required
        if path.is_file()
    ]
    record = {
        "source_head": plan["source_head"],
        "source_tree": plan["source_tree"],
        "plan_path": str(plan_path),
        "plan_sha256": _sha(plan_path),
        "case_id": plan["case_id"],
        "command_test_outcome": result.get("junit"),
        "command_exit": result.get("return_code"),
        "verdict": "NOT_ESTABLISHED"
        if reasons
        else "CONTROL_DISCRIMINATES"
        if mode
        else "TARGETED_PASS",
        "reasons": reasons,
        "wall_seconds": result.get("wall_seconds"),
        "peak_sampled_process_tree_rss_bytes": result.get("max_sampled_process_tree_rss_bytes"),
        "deciding_evidence": evidence,
        "scope": (
            "One exact captured C07 property command, not full E02/S1/B16"
            "1 or G acceptance. Removal assertion FAIL remains a test FAI"
            "L; the separate discriminator can qualify that deliberate ne"
            "gative."
        ),
        "closure_ids": [],
    }
    target = output / "coordinator-qualification.json"
    encoded = json.dumps(record, indent=2) + "\n"
    if target.exists():
        if target.read_text() != encoded:
            raise FileExistsError(f"qualification conflict; preserved prior receipt: {target}")
    else:
        target.write_text(encoded)
    sys.stdout.write(json.dumps(record, sort_keys=True) + "\n")
    raise SystemExit(1 if reasons else 0)


if __name__ == "__main__":
    main()
