from types import FunctionType
from importlib import import_module
def body(callback):
    return callback("bridge_callback")
def replacement(callback):
    return None
CODE = body.__code__
body.__code__ = replacement.__code__
run = FunctionType(CODE, globals())
run(import_module)
