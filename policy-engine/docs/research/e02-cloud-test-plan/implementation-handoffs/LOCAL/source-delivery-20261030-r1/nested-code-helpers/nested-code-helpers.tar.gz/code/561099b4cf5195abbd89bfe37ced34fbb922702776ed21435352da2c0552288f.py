from types import FunctionType
from importlib import import_module
def body():
    return load("bridge_live")
CODE = body.__code__
ns = globals()
other = ns
run = FunctionType(CODE, ns)
other["load"] = import_module
run()
