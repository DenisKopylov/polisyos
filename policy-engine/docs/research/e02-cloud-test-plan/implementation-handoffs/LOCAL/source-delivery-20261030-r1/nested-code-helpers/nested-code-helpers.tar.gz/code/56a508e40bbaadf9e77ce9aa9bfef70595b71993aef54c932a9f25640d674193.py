import sys
from . import facade
from external_decorators import facade_module_name, replacement
if facade_module_name():
    facade_module = sys.modules[facade_module_name()]
else:
    facade_module = sys.modules.get(facade_module_name())
def install():
    setattr(facade_module, "__getattr__", replacement)
install()
