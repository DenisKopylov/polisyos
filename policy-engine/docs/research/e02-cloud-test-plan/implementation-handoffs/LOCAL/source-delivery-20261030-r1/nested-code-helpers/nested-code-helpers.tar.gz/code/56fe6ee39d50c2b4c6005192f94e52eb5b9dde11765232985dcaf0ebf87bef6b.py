from pathlib import Path
import subprocess

root=Path.cwd()
base=Path(__file__).resolve().parent
paths=[
'policy-engine/src/polisyos/runtime/quality/joint_simulation_horizon.py',
'policy-engine/src/polisyos/runtime/quality/generation_cycle.py',
'policy-engine/tests/unit/runtime/quality/test_c49_native_stopping_budget.py',
'policy-engine/tests/unit/remediation/test_sim_01.py',
'policy-engine/src/polisyos/runtime/quality/README.md',
'policy-engine/release-fragments/unreleased/2026-10-28-e02-candidate-stopping-budget.toml',
]
chunks=[]
for path in paths:
 pre=str((base/'pre'/path).relative_to(root))
 post=str((base/'post'/path).relative_to(root))
 result=subprocess.run(['git','diff','--no-index','--',pre,post],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 assert result.returncode==1 and result.stdout
 patch=result.stdout.replace('a/'+pre,'a/'+path).replace('b/'+post,'b/'+path)
 assert 'LOCAL/raw/' not in patch
 chunks.append(patch)
(base/'proposal.patch').write_text(''.join(chunks))
subprocess.run(['git','apply','--check',str(base/'proposal.patch')],check=True)
print('ROOT_GIT_APPLY_CHECK_PASS',len(paths))
