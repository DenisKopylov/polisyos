"""Tiny current-thread Mach CPU sampler feasibility; no product or native fit."""

from __future__ import annotations

import ctypes
import json
import threading
import time


class TimeValue(ctypes.Structure):
    _fields_ = [("seconds", ctypes.c_int), ("microseconds", ctypes.c_int)]


class ThreadBasicInfo(ctypes.Structure):
    _fields_ = [
        ("user_time", TimeValue),
        ("system_time", TimeValue),
        ("cpu_usage", ctypes.c_int),
        ("policy", ctypes.c_int),
        ("run_state", ctypes.c_int),
        ("flags", ctypes.c_int),
        ("suspend_count", ctypes.c_int),
        ("sleep_time", ctypes.c_int),
    ]


def main() -> None:
    libc = ctypes.CDLL(None)
    libc.pthread_self.restype = ctypes.c_void_p
    libc.pthread_mach_thread_np.argtypes = [ctypes.c_void_p]
    libc.pthread_mach_thread_np.restype = ctypes.c_uint
    libc.thread_info.argtypes = [
        ctypes.c_uint,
        ctypes.c_int,
        ctypes.POINTER(ctypes.c_int),
        ctypes.POINTER(ctypes.c_uint),
    ]
    libc.thread_info.restype = ctypes.c_int
    port = libc.pthread_mach_thread_np(libc.pthread_self())

    def sample() -> dict:
        value = ThreadBasicInfo()
        count = ctypes.c_uint(ctypes.sizeof(value) // ctypes.sizeof(ctypes.c_uint))
        result = libc.thread_info(
            port,
            3,
            ctypes.cast(ctypes.byref(value), ctypes.POINTER(ctypes.c_int)),
            ctypes.byref(count),
        )
        cpu = (
            (value.user_time.seconds + value.system_time.seconds) * 1_000_000
            + value.user_time.microseconds
            + value.system_time.microseconds
        )
        return {"return_code": result, "count": count.value, "cpu_microseconds": cpu}

    before = sample()
    python_before = time.thread_time_ns()
    accumulator = sum(range(250_000))
    python_after = time.thread_time_ns()
    after = sample()
    result = {
        "schema": "policyos.e02.r4.native-mac-sampler-probe.v1",
        "scope": "current stdlib thread only; no native fit or product execution",
        "thread_id": threading.get_ident(),
        "native_thread_id": threading.get_native_id(),
        "mach_thread_port": port,
        "struct_bytes": ctypes.sizeof(ThreadBasicInfo),
        "before": before,
        "after": after,
        "mach_delta_microseconds": after["cpu_microseconds"]
        - before["cpu_microseconds"],
        "python_thread_time_delta_ns": python_after - python_before,
        "accumulator_positive": accumulator > 0,
    }
    print(json.dumps(result, sort_keys=True, indent=2))
    if (
        before["return_code"]
        or after["return_code"]
        or before["count"] != 10
        or after["count"] != 10
        or result["mach_delta_microseconds"] <= 0
    ):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
