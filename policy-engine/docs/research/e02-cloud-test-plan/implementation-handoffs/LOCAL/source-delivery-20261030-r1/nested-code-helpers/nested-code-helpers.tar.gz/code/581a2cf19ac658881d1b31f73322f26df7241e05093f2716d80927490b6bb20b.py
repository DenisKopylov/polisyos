"""Record direct function-level AST differences against frozen R4."""
import ast
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
NEW = HERE.parent
OLD = NEW.parent / "C104-mac-selected-start-r4"


def functions(path):
    tree = ast.parse(path.read_text(), filename=str(path))
    return {node.name: ast.dump(node, include_attributes=False) for node in tree.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}


def main():
    changes = {}
    for name in ("observer.py", "driver.py", "receipt_gate.py", "mac_prerequisites.py"):
        old = functions(OLD / name)
        new = functions(NEW / name)
        changes[name] = {"added": sorted(new.keys() - old.keys()), "removed": sorted(old.keys() - new.keys()),
                         "changed": sorted(key for key in old.keys() & new.keys() if old[key] != new[key])}
    for name in ("_judge", "_plan", "run"):
        if name in changes["mac_prerequisites.py"]["changed"]:
            raise AssertionError("measured R4 prerequisite implementation changed")
    expected = {"observer.py": {"_canonical_selector", "_selection_row", "_reset_after_fork", "_install_profile", "pytest_collection_modifyitems"},
                "driver.py": {"pins", "prepare", "read_observers"},
                "receipt_gate.py": {"qualify_capture"}, "mac_prerequisites.py": {"verify"}}
    for name, names in expected.items():
        if set(changes[name]["changed"]) != names or changes[name]["removed"]:
            raise AssertionError({"unexpected_function_delta": name, "actual": changes[name]})
    print(json.dumps({"status": "PASS", "function_deltas": changes,
                      "scope": "function bodies only; imports, constants and other module-level statements require review"}, sort_keys=True))


if __name__ == "__main__":
    main()
