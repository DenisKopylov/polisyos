"""Record actual pytest Config state for one trivial isolated smoke test."""
import json
import os
import sys

import pytest


def pytest_runtest_call(item):
    config = item.config
    payload = {
        "pytest_version": pytest.__version__,
        "pytest_origin": pytest.__file__,
        "python": sys.executable,
        "prefix": sys.prefix,
        "node": item.nodeid,
        "rootpath": str(config.rootpath),
        "inipath": str(config.inipath),
        "importmode_option": config.getoption("importmode"),
        "strict_markers_ini": config.getini("strict_markers"),
        "strict_ini": config.getini("strict"),
        "strict_markers_option": config.getoption("strict_markers", default=None),
        "strict_option": config.getoption("strict", default=None),
        "override_ini": config.option.override_ini,
        "disable_autoload_env": os.environ.get("PYTEST_DISABLE_PLUGIN_AUTOLOAD"),
        "expected_plugins_env": os.environ.get("PYTEST_PLUGINS"),
        "autoloaded_benchmark_present": config.pluginmanager.hasplugin("benchmark"),
        "absolute_sys_path": all(s and os.path.isabs(s) for s in sys.path),
    }
    print("E02_CONFIG_FACTS=" + json.dumps(payload, sort_keys=True))
