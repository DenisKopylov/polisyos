"""Collect source execution evidence for an already appointed Python process.

This module is an evidence producer, not an authority issuer. Its input mapping
must be independently derived from the selected source snapshot by the host and
reconciled by the confidence-ledger owner. Constructing a recorder, providing a
mapping, or serializing its output cannot appoint a runtime profile or establish
policy authority. It deliberately does not claim material-state completeness or
protection through a later decision.
"""

from __future__ import annotations

import _imp
import builtins
import hashlib
import importlib
import importlib.abc
import importlib.machinery
import json
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from types import CodeType, FrameType, MappingProxyType, ModuleType
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

_COMPILE = compile
_EXEC = exec
_FIND_SPEC = importlib.machinery.PathFinder.find_spec
_SOURCE_LOADER = importlib.machinery.SourceFileLoader
_GETPID = os.getpid
_PROCESS_CAPTURE: SourceExecutionCapture | None = None


class CaptureError(ImportError):
    """Source execution evidence could not be collected or retained."""


@dataclass(frozen=True, slots=True)
class ExpectedSource:
    """One externally selected source path and exact SHA-256 content digest."""

    relative_path: str
    sha256: str


@dataclass(frozen=True, slots=True)
class ModuleExecution:
    """A completed initializer and its retained live execution objects."""

    module_name: str
    relative_path: str
    source_sha256: str
    code: CodeType
    module: ModuleType
    loader: _CapturedSourceLoader
    spec: importlib.machinery.ModuleSpec
    origin: str
    package: str
    search_locations: tuple[str, ...] | None
    watched_exports: Mapping[str, object]


@dataclass(frozen=True, slots=True)
class ImportEvidence:
    """A successful import observed at a selected source-owned call site."""

    importer_name: str
    importer: ModuleType
    caller_code: CodeType
    provider_name: str
    provider: ModuleType
    returned: ModuleType
    requested_exports: tuple[str, ...]
    retained_exports: Mapping[str, object]
    unresolved_exports: tuple[str, ...]
    route: Literal["builtin_import", "import_module"]


@dataclass(frozen=True, slots=True)
class SourceCaptureDiagnostic:
    """Compact evidence-only report; it cannot create a live admission."""

    schema_version: Literal["policyos.runtime.confidence_ledger.source_capture_diagnostic.v1"]
    proof_schema: Literal["policyos.runtime.confidence_ledger.loaded_execution_capture.v1"]
    identity_rule: Literal["canonical-source-execution/1"]
    status: Literal["not_established"]
    phase: Literal["new", "collecting", "failed"]
    runtime_profile_id: None
    first_unestablished_premise: Literal["appointed_profile"]
    failed_premise: str | None
    failure_code: str | None
    selected_source_count: int
    completed_module_count: int
    captured_source_projection_sha256: str | None
    provider_projection_sha256: None
    capture_time_role: Literal["in_progress_or_unavailable"]
    currentness_time_role: Literal["not_evaluated"]
    unresolved_by_construction: tuple[str, ...]


class _CapturedSourceLoader(_SOURCE_LOADER):
    """Execute exactly the bytes admitted by the producer's source input."""

    def __init__(
        self,
        name: str,
        path: str,
        capture: SourceExecutionCapture,
        expected: ExpectedSource,
    ) -> None:
        super().__init__(name, path)
        self._capture = capture
        self._expected = expected

    def exec_module(self, module: ModuleType) -> None:
        attributes = object.__getattribute__(self, "__dict__")
        capture = attributes["_capture"]
        expected = attributes["_expected"]
        name = attributes["name"]
        origin = attributes["path"]
        if type(name) is not str or type(origin) is not str:
            capture._fail("module_initialization_invalid")
            raise CaptureError("module_initialization_invalid")
        capture._begin(name, module, self)
        try:
            source = Path(origin).read_bytes()
            source_sha256 = hashlib.sha256(source).hexdigest()
            if source_sha256 != expected.sha256:
                capture._fail("selected_source_bytes_mismatch")
                raise CaptureError("selected_source_bytes_mismatch")
            code = _COMPILE(
                source,
                origin,
                "exec",
                dont_inherit=True,
                optimize=sys.flags.optimize,
            )
            capture._bind_initialization_code(name, module, code)
            _EXEC(code, module.__dict__)
            capture._complete(name, module, self, source_sha256, code)
        except BaseException:
            capture._fail("module_initialization_failed")
            raise


class _CaptureFinder(importlib.abc.MetaPathFinder):
    """Select standard source loaders while preserving Python import locking."""

    def __init__(self, capture: SourceExecutionCapture) -> None:
        self._capture = capture

    def find_spec(
        self,
        fullname: str,
        path: Sequence[str] | None = None,
        target: ModuleType | None = None,
    ) -> importlib.machinery.ModuleSpec | None:
        capture = self._capture
        if fullname.partition(".")[0] not in capture._package_roots:
            return None
        if not capture._same_process():
            capture._fail("capture_inherited_across_fork")
            return None
        if capture.failed:
            # Candidate imports may continue, but this process can never promote
            # the failed capture into authority.
            return None
        if target is not None:
            capture._fail("module_reload_not_admitted")
            raise CaptureError("module_reload_not_admitted")
        expected = capture._sources.get(fullname)
        if expected is None:
            capture._fail("module_source_not_selected")
            raise CaptureError("module_source_not_selected")
        spec = _FIND_SPEC(fullname, path, target)
        if type(spec) is not importlib.machinery.ModuleSpec:
            capture._fail("module_loader_not_admitted")
            raise CaptureError("module_loader_not_admitted")
        spec_fields = object.__getattribute__(spec, "__dict__")
        if (
            type(spec_fields.get("loader")) is not _SOURCE_LOADER
            or type(spec_fields.get("origin")) is not str
            or type(spec_fields.get("name")) is not str
            or spec_fields["name"] != fullname
        ):
            capture._fail("module_loader_not_admitted")
            raise CaptureError("module_loader_not_admitted")
        try:
            selected = capture._selected_path(expected)
            actual = Path(spec_fields["origin"]).resolve(strict=True)
        except (OSError, RuntimeError, ValueError) as exc:
            capture._fail("module_origin_not_admitted")
            raise CaptureError("module_origin_not_admitted") from exc
        if actual != selected:
            capture._fail("module_origin_not_admitted")
            raise CaptureError("module_origin_not_admitted")
        spec.origin = str(selected)
        spec.loader = _CapturedSourceLoader(fullname, str(selected), capture, expected)
        return spec


class SourceExecutionCapture:
    """Retain completed source executions under a caller-supplied source selection.

    Installation is valid only before any selected top-level package is loaded.
    A failed installation or initializer is terminal for the retained producer
    module. The host must retain that module and exclude reload or replacement
    before the owner can establish process-wide terminality. This primitive does
    not authenticate the caller-supplied selection, interpreter, third-party
    providers, material state, or later mutation ownership.
    """

    def __init__(
        self,
        root: Path,
        sources: Mapping[str, ExpectedSource],
        *,
        exports: Mapping[str, set[str] | frozenset[str]] | None = None,
    ) -> None:
        self._root = root.resolve(strict=True)
        self._process_id = _GETPID()
        if type(sources) not in (dict, MappingProxyType) or not sources or any(
            type(name) is not str
            or not name
            or any(not part.isidentifier() for part in name.split("."))
            for name in sources
        ):
            raise ValueError("capture_source_selection_invalid")
        selected_sources = dict(sources)
        self._sources = MappingProxyType(selected_sources)
        if exports is not None and (
            type(exports) not in (dict, MappingProxyType)
            or any(
                type(name) is not str
                or type(names) not in (set, frozenset)
                or any(type(export) is not str or not export.isidentifier() for export in names)
                for name, names in exports.items()
            )
        ):
            raise ValueError("capture_export_selection_invalid")
        self._exports = MappingProxyType(
            {name: frozenset(names) for name, names in (exports or {}).items()}
        )
        self._package_roots = frozenset(name.partition(".")[0] for name in self._sources)
        self._finder = _CaptureFinder(self)
        self._phase: Literal["new", "collecting", "failed"] = "new"
        self._failure: str | None = None
        self._pending: dict[str, ModuleType] = {}
        self._pending_codes: dict[str, CodeType] = {}
        self._completed: dict[str, ModuleExecution] = {}
        self._code_trees: dict[int, tuple[CodeType, ...]] = {}
        self._import_events: list[ImportEvidence] = []
        self._import_hook: object | None = None
        self._import_module_hook: object | None = None
        if set(self._exports) - self._sources.keys():
            raise ValueError("capture_export_selection_invalid")
        for expected in self._sources.values():
            if (
                type(expected) is not ExpectedSource
                or type(expected.relative_path) is not str
                or type(expected.sha256) is not str
                or len(expected.sha256) != 64
                or any(char not in "0123456789abcdef" for char in expected.sha256)
            ):
                raise ValueError("capture_source_digest_invalid")
            self._selected_path(expected)

    @property
    def failed(self) -> bool:
        """Whether this producer instance has reached its terminal failure."""

        return self._phase == "failed"

    @property
    def failure_reason(self) -> str | None:
        """Return the first producer failure without exposing exception objects."""

        return self._failure

    def diagnostic(self) -> SourceCaptureDiagnostic:
        """Describe collected evidence and its explicitly unresolved premises."""

        if not self._same_process():
            self._fail("capture_inherited_across_fork")
        rows: list[list[str]] = []
        for name, record in self._completed.items():
            if (
                type(name) is not str
                or type(record) is not ModuleExecution
                or type(record.relative_path) is not str
                or type(record.source_sha256) is not str
            ):
                self._fail("capture_record_invalid")
                rows = []
                break
            rows.append([name, record.relative_path, record.source_sha256])
        rows.sort(key=lambda row: row[0])
        source_digest = (
            hashlib.sha256(
                json.dumps(rows, ensure_ascii=True, separators=(",", ":")).encode("ascii")
            ).hexdigest()
            if rows
            else None
        )
        binding_failures = {
            "capture_finder_changed",
            "capture_import_hook_changed",
            "required_module_without_execution",
            "retained_module_changed",
            "retained_export_changed",
            "consumer_binding_changed",
            "capture_record_invalid",
            "importer_execution_not_recorded",
            "import_event_shape_unsupported",
            "import_event_package_unresolved",
            "import_event_provider_unresolved",
            "import_caller_code_unrecorded",
            "import_event_binding_unresolved",
            "import_event_binding_changed",
            "capture_inherited_across_fork",
        }
        failed_premise = (
            "complete_relevant_bindings"
            if self._failure in binding_failures
            else "executed_bound_source"
            if self.failed and self._failure != "selected_package_preloaded"
            else "appointed_profile" if self.failed else None
        )
        return SourceCaptureDiagnostic(
            schema_version="policyos.runtime.confidence_ledger.source_capture_diagnostic.v1",
            proof_schema="policyos.runtime.confidence_ledger.loaded_execution_capture.v1",
            identity_rule="canonical-source-execution/1",
            status="not_established",
            phase=self._phase,
            runtime_profile_id=None,
            first_unestablished_premise="appointed_profile",
            failed_premise=failed_premise,
            failure_code=self._failure,
            selected_source_count=len(self._sources),
            completed_module_count=len(self._completed),
            captured_source_projection_sha256=(
                f"sha256:{source_digest}" if source_digest is not None else None
            ),
            provider_projection_sha256=None,
            capture_time_role="in_progress_or_unavailable",
            currentness_time_role="not_evaluated",
            unresolved_by_construction=(
                "host_profile_appointment",
                "retained_producer_module_and_process_continuity",
                "selected_source_and_dependency_mapping",
                "relevant_graph_completeness",
                "unmediated_dynamic_code_and_uncaptured_importers",
                "direct_module_map_and_unmediated_provider_lookups",
                "owner_sealing_and_currentness",
                "material_decision_state",
                "protected_through_use",
            ),
        )

    def install(self) -> None:
        """Install the finder before a selected package has entered ``sys.modules``."""

        global _PROCESS_CAPTURE
        self._require_same_process()
        if self._phase != "new":
            raise CaptureError("capture_not_new")
        _imp.acquire_lock()
        try:
            if _PROCESS_CAPTURE is not None:
                raise CaptureError("capture_process_already_attempted")
            # One owner for the process, including a failed first attempt. A
            # second recorder cannot retroactively adopt earlier initialization.
            _PROCESS_CAPTURE = self
            try:
                if any(name.partition(".")[0] in self._package_roots for name in sys.modules):
                    self._fail("selected_package_preloaded")
                    raise CaptureError("selected_package_preloaded")
                sys.meta_path.insert(0, self._finder)
                self._phase = "collecting"
                self._install_import_hooks()
            except BaseException:
                self._fail("capture_installation_failed")
                raise
        finally:
            _imp.release_lock()

    def completed(self, module_name: str) -> ModuleExecution:
        """Return a completed execution; a cyclic provisional module is refused."""

        self._require_same_process()
        if self._phase != "collecting":
            raise CaptureError("capture_not_collecting")
        try:
            return self._completed[module_name]
        except KeyError as exc:
            raise CaptureError("module_not_completed") from exc

    def assert_retained(self, required_modules: frozenset[str]) -> None:
        """Reconcile completed anchors for a nonempty, independently derived set.

        The caller must establish the required set separately. Success does not
        seal the capture or prove that every material edge has been selected.
        """

        self._require_same_process()
        if self._phase != "collecting":
            raise CaptureError("capture_incomplete")
        if (
            type(required_modules) is not frozenset
            or not required_modules
            or any(type(name) is not str for name in required_modules)
            or not required_modules.issubset(self._sources)
        ):
            raise CaptureError("capture_required_set_invalid")
        if any(name in self._pending for name in required_modules):
            raise CaptureError("capture_incomplete")
        if not sys.meta_path or sys.meta_path[0] is not self._finder:
            self._fail("capture_finder_changed")
            raise CaptureError("capture_finder_changed")
        if (
            builtins.__import__ is not self._import_hook
            or importlib.import_module is not self._import_module_hook
        ):
            self._fail("capture_import_hook_changed")
            raise CaptureError("capture_import_hook_changed")
        incomplete = required_modules.difference(self._completed)
        if any(name in sys.modules for name in incomplete):
            self._fail("required_module_without_execution")
            raise CaptureError("required_module_without_execution")
        if incomplete:
            raise CaptureError("capture_required_module_not_completed")
        for name in sorted(required_modules):
            record = self._completed[name]
            if (
                type(record.module) is not ModuleType
                or type(record.spec) is not importlib.machinery.ModuleSpec
                or type(record.loader) is not _CapturedSourceLoader
            ):
                self._fail("retained_module_changed")
                raise CaptureError("retained_module_changed")
            namespace = record.module.__dict__
            if not self._metadata_matches(
                name,
                record.module,
                record.loader,
                record.spec,
                record.origin,
                record.package,
                record.search_locations,
            ):
                self._fail("retained_module_changed")
                raise CaptureError("retained_module_changed")
            if any(
                export not in namespace or namespace[export] is not value
                for export, value in record.watched_exports.items()
            ):
                self._fail("retained_export_changed")
                raise CaptureError("retained_export_changed")

    def assert_binding(
        self,
        importer_name: str,
        importer_attribute: str,
        provider_name: str,
        provider_attribute: str,
    ) -> None:
        """Compare a consumer's actual binding to a producer-time retained export."""

        self.assert_retained(frozenset({importer_name, provider_name}))
        importer = self.completed(importer_name)
        provider = self.completed(provider_name)
        if provider_attribute not in provider.watched_exports:
            raise CaptureError("provider_export_not_recorded")
        retained = provider.watched_exports[provider_attribute]
        namespace = importer.module.__dict__
        if importer_attribute not in namespace or namespace[importer_attribute] is not retained:
            self._fail("consumer_binding_changed")
            raise CaptureError("consumer_binding_changed")

    def import_events(self) -> tuple[ImportEvidence, ...]:
        """Return collected import-site events without claiming their completeness."""

        self._require_same_process()
        if self._phase != "collecting":
            raise CaptureError("capture_not_collecting")
        return tuple(self._import_events)

    def assert_import_binding(
        self,
        event: ImportEvidence,
        *,
        importer_attribute: str,
        provider_export: str,
    ) -> None:
        """Reconcile one observed provider value with its actual consumer binding.

        The owner must derive the import obligation independently and qualify
        external providers and material state; one matching event is not closure.
        """

        if (
            type(event) is not ImportEvidence
            or not any(record is event for record in self._import_events)
            or type(importer_attribute) is not str
            or type(provider_export) is not str
            or type(event.importer_name) is not str
            or type(event.provider_name) is not str
            or type(event.retained_exports) is not MappingProxyType
            or type(event.caller_code) is not CodeType
        ):
            raise CaptureError("import_event_not_recorded")
        required = {event.importer_name}
        if event.provider_name in self._sources:
            required.add(event.provider_name)
        self.assert_retained(frozenset(required))
        if (
            type(event.importer) is not ModuleType
            or type(event.provider) is not ModuleType
            or sys.modules.get(event.importer_name) is not event.importer
            or sys.modules.get(event.provider_name) is not event.provider
            or provider_export not in event.retained_exports
        ):
            self._fail("import_event_binding_unresolved")
            raise CaptureError("import_event_binding_unresolved")
        retained = event.retained_exports[provider_export]
        provider_namespace = event.provider.__dict__
        importer_namespace = event.importer.__dict__
        if (
            provider_export not in provider_namespace
            or provider_namespace[provider_export] is not retained
            or importer_attribute not in importer_namespace
            or importer_namespace[importer_attribute] is not retained
        ):
            self._fail("import_event_binding_changed")
            raise CaptureError("import_event_binding_changed")

    def _install_import_hooks(self) -> None:
        original_import = builtins.__import__
        original_import_module = importlib.import_module

        def observed_import(
            name: str,
            globals: dict[str, object] | None = None,
            locals: dict[str, object] | None = None,
            fromlist: tuple[str, ...] | list[str] | None = (),
            level: int = 0,
        ) -> ModuleType:
            caller = sys._getframe(1)
            result = original_import(name, globals, locals, fromlist, level)
            if self._phase == "collecting" and not self._same_process():
                self._fail("capture_inherited_across_fork")
            if self._phase == "collecting":
                self._record_import(caller, name, fromlist, level, result, "builtin_import")
            return result

        def observed_import_module(name: str, package: str | None = None) -> ModuleType:
            caller = sys._getframe(1)
            result = original_import_module(name, package)
            if self._phase == "collecting" and not self._same_process():
                self._fail("capture_inherited_across_fork")
            if self._phase == "collecting":
                self._record_import_module(caller, result)
            return result

        self._import_hook = observed_import
        self._import_module_hook = observed_import_module
        builtins.__import__ = observed_import
        importlib.import_module = observed_import_module

    def _selected_importer(self, caller: FrameType) -> tuple[str, ModuleType] | None:
        namespace = caller.f_globals
        name = namespace.get("__name__")
        if type(name) is not str or name not in self._sources:
            return None
        importer = self._pending.get(name)
        if importer is None:
            completed = self._completed.get(name)
            importer = completed.module if completed is not None else None
        if type(importer) is not ModuleType or importer.__dict__ is not namespace:
            self._fail("importer_execution_not_recorded")
            return None
        root_code = (
            self._pending_codes.get(name)
            if name in self._pending
            else self._completed[name].code
        )
        if root_code is None or not self._code_belongs_to(root_code, caller.f_code):
            self._fail("import_caller_code_unrecorded")
            return None
        return name, importer

    def _code_belongs_to(self, root: CodeType, selected: CodeType) -> bool:
        """Compare actual code identities within the retained compiler tree."""

        key = id(root)
        tree = self._code_trees.get(key)
        if tree is None or tree[0] is not root:
            pending = [root]
            members: list[CodeType] = []
            while pending:
                code = pending.pop()
                members.append(code)
                pending.extend(item for item in code.co_consts if type(item) is CodeType)
            tree = tuple(members)
            self._code_trees[key] = tree
        return any(code is selected for code in tree)

    def _record_import(
        self,
        caller: FrameType,
        requested: str,
        fromlist: tuple[str, ...] | list[str] | None,
        level: int,
        returned: object,
        route: Literal["builtin_import"],
    ) -> None:
        selected = self._selected_importer(caller)
        if selected is None:
            return
        if (
            type(requested) is not str
            or type(level) is not int
            or level < 0
            or (fromlist is not None and type(fromlist) not in (tuple, list))
            or (fromlist is not None and any(type(name) is not str for name in fromlist))
            or type(returned) is not ModuleType
        ):
            self._fail("import_event_shape_unsupported")
            return
        provider_name = requested
        if level:
            package = caller.f_globals.get("__package__")
            if type(package) is not str or not package or level > len(package.split(".")):
                self._fail("import_event_package_unresolved")
                return
            parent = package.rsplit(".", level - 1)[0]
            provider_name = f"{parent}.{requested}" if requested else parent
        provider = sys.modules.get(provider_name)
        if type(provider) is not ModuleType:
            self._fail("import_event_provider_unresolved")
            return
        self._retain_import_event(
            selected, caller.f_code, provider_name, provider, returned, tuple(fromlist or ()), route
        )

    def _record_import_module(self, caller: FrameType, returned: object) -> None:
        selected = self._selected_importer(caller)
        if selected is None:
            return
        if type(returned) is not ModuleType:
            self._fail("import_event_provider_unresolved")
            return
        provider_name = returned.__dict__.get("__name__")
        if type(provider_name) is not str or sys.modules.get(provider_name) is not returned:
            self._fail("import_event_provider_unresolved")
            return
        self._retain_import_event(
            selected, caller.f_code, provider_name, returned, returned, (), "import_module"
        )

    def _retain_import_event(
        self,
        selected: tuple[str, ModuleType],
        caller_code: CodeType,
        provider_name: str,
        provider: ModuleType,
        returned: ModuleType,
        exports: tuple[str, ...],
        route: Literal["builtin_import", "import_module"],
    ) -> None:
        namespace = provider.__dict__
        retained = MappingProxyType(
            {name: namespace[name] for name in exports if name != "*" and name in namespace}
        )
        unresolved = tuple(name for name in exports if name == "*" or name not in namespace)
        self._import_events.append(
            ImportEvidence(
                selected[0], selected[1], caller_code, provider_name, provider, returned,
                exports, retained, unresolved, route,
            )
        )

    def _selected_path(self, expected: ExpectedSource) -> Path:
        relative = Path(expected.relative_path)
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError("capture_source_path_invalid")
        selected = self._root / relative
        if (
            selected.resolve(strict=True) != selected
            or not selected.is_relative_to(self._root)
            or not selected.is_file()
        ):
            raise ValueError("capture_source_path_invalid")
        return selected

    def _begin(self, name: str, module: ModuleType, loader: _CapturedSourceLoader) -> None:
        if (
            self._phase != "collecting"
            or name in self._pending
            or name in self._completed
            or type(module) is not ModuleType
            or sys.modules.get(name) is not module
            or module.__dict__.get("__loader__") is not loader
        ):
            self._fail("module_initialization_invalid")
            raise CaptureError("module_initialization_invalid")
        self._pending[name] = module

    def _bind_initialization_code(self, name: str, module: ModuleType, code: CodeType) -> None:
        if (
            self._phase != "collecting"
            or self._pending.get(name) is not module
            or name in self._pending_codes
            or type(code) is not CodeType
        ):
            raise CaptureError("module_initialization_invalid")
        self._pending_codes[name] = code

    def _complete(
        self,
        name: str,
        module: ModuleType,
        loader: _CapturedSourceLoader,
        source_sha256: str,
        code: CodeType,
    ) -> None:
        if (
            self._phase != "collecting"
            or self._pending.get(name) is not module
            or self._pending_codes.get(name) is not code
        ):
            raise CaptureError("module_initialization_invalid")
        namespace = module.__dict__
        spec = namespace.get("__spec__")
        if type(spec) is not importlib.machinery.ModuleSpec:
            raise CaptureError("module_initialization_invalid")
        spec_fields = object.__getattribute__(spec, "__dict__")
        locations = spec_fields.get("submodule_search_locations")
        if locations is not None and (
            type(locations) is not list or any(type(item) is not str for item in locations)
        ):
            raise CaptureError("module_initialization_invalid")
        search_locations = None if locations is None else tuple(locations)
        package = name if search_locations is not None else name.rpartition(".")[0]
        selected_origin = str(self._selected_path(self._sources[name]))
        if not self._metadata_matches(
            name, module, loader, spec, selected_origin, package, search_locations
        ):
            raise CaptureError("module_initialization_invalid")
        names = self._exports.get(name, frozenset())
        if any(export not in namespace for export in names):
            raise CaptureError("provider_export_not_recorded")
        retained = MappingProxyType({export: namespace[export] for export in names})
        self._completed[name] = ModuleExecution(
            name,
            self._sources[name].relative_path,
            source_sha256,
            code,
            module,
            loader,
            spec,
            selected_origin,
            package,
            search_locations,
            retained,
        )
        del self._pending[name]
        del self._pending_codes[name]

    def _metadata_matches(
        self,
        name: str,
        module: ModuleType,
        loader: _CapturedSourceLoader,
        spec: importlib.machinery.ModuleSpec,
        origin: str,
        package: str,
        search_locations: tuple[str, ...] | None,
    ) -> bool:
        """Inspect exact builtin representations without candidate comparisons."""

        if (
            type(module) is not ModuleType
            or type(spec) is not importlib.machinery.ModuleSpec
            or type(loader) is not _CapturedSourceLoader
        ):
            return False
        namespace = module.__dict__
        spec_fields = object.__getattribute__(spec, "__dict__")
        loader_fields = object.__getattribute__(loader, "__dict__")
        fields = (
            (namespace.get("__name__"), name),
            (namespace.get("__package__"), package),
            (namespace.get("__file__"), origin),
            (spec_fields.get("name"), name),
            (spec_fields.get("origin"), origin),
            (loader_fields.get("name"), name),
            (loader_fields.get("path"), origin),
        )
        if any(type(value) is not str or value != expected for value, expected in fields):
            return False
        if (
            sys.modules.get(name) is not module
            or namespace.get("__loader__") is not loader
            or namespace.get("__spec__") is not spec
            or spec_fields.get("loader") is not loader
            or loader_fields.get("_capture") is not self
            or loader_fields.get("_expected") is not self._sources[name]
        ):
            return False
        locations = spec_fields.get("submodule_search_locations")
        if search_locations is None:
            return locations is None and "__path__" not in namespace
        return (
            type(locations) is list
            and all(type(item) is str for item in locations)
            and tuple(locations) == search_locations
            and namespace.get("__path__") is locations
        )

    def _fail(self, reason: str) -> None:
        self._phase = "failed"
        if self._failure is None:
            self._failure = reason

    def _same_process(self) -> bool:
        return _GETPID() == self._process_id

    def _require_same_process(self) -> None:
        if not self._same_process():
            self._fail("capture_inherited_across_fork")
            raise CaptureError("capture_inherited_across_fork")
