"""Record the narrow real SALib callables used by the C56 native test profile.

This file is a future execution recipe, not evidence that a backend test ran.
"""
from __future__ import annotations

import hashlib
import inspect
import json
import platform
import sys
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path


def identity(fn: object) -> dict[str, str]:
    path = inspect.getsourcefile(fn)
    if path is None:
        raise RuntimeError('backend callable has no inspectable source file')
    file = Path(path).resolve(strict=True)
    return {
        'module': getattr(fn, '__module__', ''),
        'qualname': getattr(fn, '__qualname__', ''),
        'source_path': str(file),
        'source_sha256': hashlib.sha256(file.read_bytes()).hexdigest(),
    }


def optional_version(name: str) -> str | None:
    try:
        return version(name)
    except PackageNotFoundError:
        return None


def main() -> None:
    from SALib.analyze import morris as morris_analyzer
    from SALib.sample import morris as morris_sampler

    result = {
        'python_executable': str(Path(sys.executable).resolve()),
        'python_version': platform.python_version(),
        'SALib_version': version('SALib'),
        'numpy_version': version('numpy'),
        'scipy_version': version('scipy'),
        'sklearn_version': optional_version('scikit-learn'),
        'pytest_version': version('pytest'),
        'sample_callable': identity(morris_sampler.sample),
        'analyze_callable': identity(morris_analyzer.analyze),
        'scope': 'These two direct source files are a bounded external-input identity, not a complete package/dependency readset.',
    }
    print(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2))


if __name__ == '__main__':
    main()
