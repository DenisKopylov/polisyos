"""Stable adapter facade for default Foundry and Fabric runtime ports.

The package exports the production bridge classes used by workflow builders.
Both bridges are imported lazily so environments that only need Scientist state
or workflow specs do not pay the import cost of connector/security stacks.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .fabric_bridge import parse_data_view_request
    from .registered_sql_admission import (
        RegisteredSQLCapture,
        RegisteredSQLViewContract,
        registered_sql_capture_input_refs,
    )

__all__ = [
    "DefaultFabricPort",
    "DefaultFoundryPort",
    "RegisteredSQLCapture",
    "RegisteredSQLViewContract",
    "parse_data_view_request",
    "registered_sql_capture_input_refs",
]


def __getattr__(name: str) -> Any:
    """Resolve adapter classes lazily and preserve the package-level contract."""
    if name == "DefaultFabricPort":
        from polisyos.scientist.adapters.fabric_bridge import DefaultFabricPort

        return DefaultFabricPort
    if name == "DefaultFoundryPort":
        from polisyos.scientist.adapters.foundry_bridge import DefaultFoundryPort

        return DefaultFoundryPort
    if name == "parse_data_view_request":
        from polisyos.scientist.adapters.fabric_bridge import parse_data_view_request

        return parse_data_view_request
    if name in {
        "RegisteredSQLCapture", "RegisteredSQLViewContract", "registered_sql_capture_input_refs"
    }:
        from polisyos.scientist.adapters.registered_sql_admission import (
            RegisteredSQLCapture,
            RegisteredSQLViewContract,
            registered_sql_capture_input_refs,
        )

        return {
            "RegisteredSQLCapture": RegisteredSQLCapture,
            "RegisteredSQLViewContract": RegisteredSQLViewContract,
            "registered_sql_capture_input_refs": registered_sql_capture_input_refs,
        }[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
