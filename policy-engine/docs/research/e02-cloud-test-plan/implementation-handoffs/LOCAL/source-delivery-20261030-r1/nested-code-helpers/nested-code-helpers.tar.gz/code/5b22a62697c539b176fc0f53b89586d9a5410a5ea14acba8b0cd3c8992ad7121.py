"""
Resilience & Reliability Patterns for Data Connectors.

This module provides production-grade resilience patterns that protect
external API calls from transient failures, cascade failures, and overload.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass
from functools import wraps
from typing import Any, TypeVar, cast

from polisyos.common.logger import get_logger

from ._bounded_registry import BoundedResourceRegistry
from .circuit_breaker import (
    CircuitBreaker,
    CircuitBreakerConfig,
    CircuitOpenError,
    CircuitState,
    with_circuit_breaker,
)
from .fallback import (
    CacheFallback,
    FallbackChain,
    FallbackStrategy,
    MockFallback,
    RaiseFallback,
    with_fallback,
)
from .rate_limiter import (
    AdaptiveRateLimiter,
    RateLimiter,
    RateLimiterConfig,
    _call_with_limiter,
    with_rate_limit,
)
from .retry import (
    RetryExhaustedError,
    RetryPolicy,
    is_retryable_error,
    with_retry,
)

logger = get_logger(__name__)

T = TypeVar("T")


@dataclass(frozen=True, slots=True)
class ResilienceConfig:
    """Runtime resilience policy for a connector fetch coroutine.

    ``fallback_chain`` is only used when retries/circuit execution still fail, and
    ``inherit_connection_config`` controls whether per-connection retry/rate-limit values may fill
    missing policy fields. This module wraps calls best-effort; it does not provide persistence or
    cache invalidation guarantees beyond whichever ``CacheFallback`` store is supplied.
    """

    retry_policy: RetryPolicy | None = None
    circuit_breaker: CircuitBreakerConfig | CircuitBreaker | None = None
    rate_limit_rps: float | None = None
    adaptive_rate_limit: bool = False
    fallback_chain: FallbackChain[Any] | None = None
    inherit_connection_config: bool = False


def _build_fallback_chain(
    spec: object,
    *,
    cache_store: object | None = None,
    max_staleness_seconds: float | None = None,
) -> FallbackChain[Any] | None:
    if spec is None:
        return None
    if isinstance(spec, FallbackChain):
        return spec
    if isinstance(spec, list):
        items = spec
    elif isinstance(spec, str):
        items = [spec]
    else:
        return None

    strategies: list[FallbackStrategy[Any]] = []
    for item in items:
        if isinstance(item, FallbackStrategy):
            strategies.append(item)
            continue
        if isinstance(item, str):
            name = item.strip().upper()
            if name in {"CACHE", "CACHE_ONLY", "STALE_CACHE"}:
                strategies.append(
                    CacheFallback(
                        cache_store=cache_store,
                        max_staleness_seconds=max_staleness_seconds,
                    )
                )
            elif name in {"MOCK", "STATIC_MOCK"}:
                strategies.append(MockFallback())
            elif name in {"RAISE", "NONE"}:
                strategies.append(RaiseFallback())

    return FallbackChain(strategies) if strategies else None


def resolve_resilience_config(
    raw: ResilienceConfig | Mapping[str, Any] | None,
    *,
    cache_store: object | None = None,
) -> ResilienceConfig | None:
    """Normalize mapping-style resilience settings into a ``ResilienceConfig`` instance.

    Args:
        raw: Existing ``ResilienceConfig`` or a mapping using keys like ``retry_policy``,
            ``circuit_breaker``, ``rate_limit_rps``, and ``fallback``.
        cache_store: Optional cache object passed to ``CacheFallback`` strategies.

    Returns:
        Resolved config, or ``None`` when ``raw`` is absent or unsupported.
    """
    if raw is None:
        return None
    if isinstance(raw, ResilienceConfig):
        return raw

    if not isinstance(raw, Mapping):
        logger.warning("Unknown resilience config type", value=type(raw).__name__)
        return None

    retry_spec = raw.get("retry_policy") or raw.get("retry")
    circuit_spec = raw.get("circuit_breaker") or raw.get("circuit")
    rate_limit_rps = raw.get("rate_limit_rps") if "rate_limit_rps" in raw else raw.get("rate_limit")
    adaptive = bool(raw.get("adaptive_rate_limit") or raw.get("adaptive"))
    inherit_connection = bool(
        raw.get("inherit_connection_config") or raw.get("use_connection_config")
    )
    fallback_spec = raw.get("fallback") or raw.get("fallback_strategy")
    max_staleness = raw.get("fallback_max_staleness_seconds")

    retry_policy = None
    if isinstance(retry_spec, RetryPolicy):
        retry_policy = retry_spec
    elif isinstance(retry_spec, Mapping):
        retry_policy = RetryPolicy(**retry_spec)

    circuit_breaker = None
    if isinstance(circuit_spec, (CircuitBreaker, CircuitBreakerConfig)):
        circuit_breaker = circuit_spec
    elif isinstance(circuit_spec, Mapping):
        circuit_breaker = CircuitBreakerConfig(**circuit_spec)

    fallback_chain = _build_fallback_chain(
        fallback_spec,
        cache_store=cache_store,
        max_staleness_seconds=max_staleness,
    )

    return ResilienceConfig(
        retry_policy=retry_policy,
        circuit_breaker=circuit_breaker,
        rate_limit_rps=rate_limit_rps,
        adaptive_rate_limit=adaptive,
        fallback_chain=fallback_chain,
        inherit_connection_config=inherit_connection,
    )


def _default_rate_limiter_id[T](
    func: Callable[..., Awaitable[T]],
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
) -> str:
    connector_id = None
    for key in ("handle", "connection", "connection_handle"):
        handle = kwargs.get(key)
        if handle is not None and hasattr(handle, "connector_id"):
            connector_id = handle.connector_id
            break
    if connector_id is None:
        for arg in args:
            if hasattr(arg, "connector_id"):
                connector_id = arg.connector_id
                break

    domain = None
    handle = None
    for key in ("handle", "connection", "connection_handle"):
        handle = kwargs.get(key)
        if handle is not None:
            break
    if handle is None:
        for arg in args:
            if hasattr(arg, "config") and hasattr(arg, "connector_id"):
                handle = arg
                break

    if handle is not None and hasattr(handle, "config"):
        url = getattr(handle.config, "url", None)
        if isinstance(url, str) and "://" in url:
            try:
                from urllib.parse import urlparse

                domain = urlparse(url).netloc or None
            except Exception:
                domain = None

    base = connector_id or f"{func.__module__}.{func.__name__}"
    if domain:
        return f"{base}:{domain}"
    return base


def apply_resilience[T](
    func: Callable[..., Awaitable[T]],
    *,
    config: ResilienceConfig | Mapping[str, Any] | None,
    cache_store: object | None = None,
) -> Callable[..., Awaitable[T]]:
    """
    Apply resilience wrappers to a fetch-like coroutine.

    Resilience is opt-in: if config is None, returns func unchanged.
    """
    resolved = resolve_resilience_config(config, cache_store=cache_store)
    if resolved is None:
        return func

    circuit_breakers = BoundedResourceRegistry[CircuitBreaker]()
    rate_limiters = BoundedResourceRegistry[RateLimiter]()

    @wraps(func)
    async def wrapper(*args: object, **kwargs: object) -> T:
        retry_policy = resolved.retry_policy
        rate_limit_rps = resolved.rate_limit_rps
        adaptive = resolved.adaptive_rate_limit
        breaker_config = resolved.circuit_breaker

        handle = None
        for key in ("handle", "connection", "connection_handle"):
            handle = kwargs.get(key)
            if handle is not None:
                break
        if handle is None:
            for arg in args:
                if hasattr(arg, "config") and hasattr(arg, "connector_id"):
                    handle = arg
                    break

        # Connection-level overrides are explicit opt-in
        if resolved.inherit_connection_config and handle is not None:
            if rate_limit_rps is None:
                rate_limit_rps = getattr(handle.config, "rate_limit_rps", None)

            if retry_policy is None:
                max_retries = getattr(handle.config, "max_retries", None)
                base_delay = getattr(handle.config, "retry_delay_seconds", None)
                if max_retries is not None:
                    retry_policy = RetryPolicy(
                        max_attempts=max_retries,
                        base_delay=base_delay or 1.0,
                    )

        async def _rate_limited_call(*call_args: object, **call_kwargs: object) -> T:
            if rate_limit_rps is None:
                return await func(*call_args, **call_kwargs)
            limiter_id = _default_rate_limiter_id(func, args, kwargs)
            # Different rate limits retain the existing separate-config identity.
            limiter_key = f"{limiter_id}:{rate_limit_rps}"
            with rate_limiters.lease(
                limiter_key,
                lambda: (
                    AdaptiveRateLimiter(
                        initial_rate_rps=rate_limit_rps,
                        config=RateLimiterConfig(rate_limit_rps=rate_limit_rps),
                        limiter_id=limiter_id,
                    )
                    if adaptive
                    else RateLimiter(
                        rate_limit_rps=rate_limit_rps,
                        limiter_id=limiter_id,
                    )
                ),
            ) as limiter:
                return await _call_with_limiter(limiter, func, *call_args, **call_kwargs)

        async def _retry_call(*call_args: object, **call_kwargs: object) -> T:
            if retry_policy is None:
                return await _rate_limited_call(*call_args, **call_kwargs)

            if "request" in call_kwargs:
                request = call_kwargs["request"]
            else:
                request = next(
                    (
                        arg
                        for arg in call_args
                        if hasattr(arg, "cache_key") and hasattr(arg, "dataset_id")
                    ),
                    None,
                )
            retry_handle = handle
            if retry_handle is None:
                retry_handle = next(
                    (arg for arg in call_args if hasattr(arg, "connector_id")),
                    None,
                )

            async def _run_target(
                *_retry_args: object,
                **_retry_kwargs: object,
            ) -> T:
                return await _rate_limited_call(*call_args, **call_kwargs)

            return await retry_policy.execute(
                _run_target,
                request=request,
                handle=retry_handle,
            )

        async def _circuit_call(*call_args: object, **call_kwargs: object) -> T:
            if breaker_config is None:
                return await _retry_call(*call_args, **call_kwargs)
            if isinstance(breaker_config, CircuitBreaker):
                return await breaker_config.execute(_retry_call, *call_args, **call_kwargs)
            from .circuit_breaker import _default_circuit_id

            breaker_id = _default_circuit_id(func, args, kwargs)
            with circuit_breakers.lease(
                breaker_id,
                lambda: CircuitBreaker(circuit_id=breaker_id, config=breaker_config),
            ) as breaker:
                return await breaker.execute(_retry_call, *call_args, **call_kwargs)

        if resolved.fallback_chain is not None:
            # Configuration stores heterogeneous strategies; bind the resolved chain to this
            # invocation's result contract at the wrapper boundary.
            fallback_chain = cast("FallbackChain[T]", resolved.fallback_chain)
            return await fallback_chain.execute(
                _circuit_call,
                *args,
                **kwargs,
            )
        return await _circuit_call(*args, **kwargs)

    wrapper._resilience_config = resolved  # type: ignore[attr-defined]
    wrapper._resilience_circuit_breakers = circuit_breakers  # type: ignore[attr-defined]
    wrapper._resilience_rate_limiters = rate_limiters  # type: ignore[attr-defined]

    return wrapper


__all__ = [
    "AdaptiveRateLimiter",
    "CacheFallback",
    # Circuit Breaker
    "CircuitBreaker",
    "CircuitBreakerConfig",
    "CircuitOpenError",
    "CircuitState",
    "FallbackChain",
    # Fallback
    "FallbackStrategy",
    "MockFallback",
    "RaiseFallback",
    # Rate Limiter
    "RateLimiter",
    "RateLimiterConfig",
    # Resilience integration
    "ResilienceConfig",
    "RetryExhaustedError",
    # Retry
    "RetryPolicy",
    "apply_resilience",
    "is_retryable_error",
    "resolve_resilience_config",
    "with_circuit_breaker",
    "with_fallback",
    "with_rate_limit",
    "with_retry",
]
