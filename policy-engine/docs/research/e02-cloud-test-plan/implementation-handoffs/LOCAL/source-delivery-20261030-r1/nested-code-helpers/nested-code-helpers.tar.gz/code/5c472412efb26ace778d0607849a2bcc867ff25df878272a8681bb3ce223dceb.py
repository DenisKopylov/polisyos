def test_g27_real_sql_withdraw_a_after_b_fresh_owner():
    pass
