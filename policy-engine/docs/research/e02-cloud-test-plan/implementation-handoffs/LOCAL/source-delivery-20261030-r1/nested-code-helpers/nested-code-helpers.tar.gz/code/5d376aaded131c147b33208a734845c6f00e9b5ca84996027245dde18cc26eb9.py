"""Capture complete stdlib-only source checks and the Ruff stdin report."""
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from pathlib import Path

root = Path("LOCAL/raw/e02-execution-20261027/repairs/SQL-owner-chain-r3")
checks = [
    ("static", [sys.executable, str(root / "checks/static.py")]),
    ("fence", [sys.executable, str(root / "checks/fence-probe.py")]),
    ("lock-census", [sys.executable, str(root / "checks/lock-census.py")]),
    ("bundle-schema-census", [sys.executable, str(root / "checks/bundle-schema-census.py")]),
    ("build-controls", [sys.executable, str(root / "checks/build-controls.py")]),
    ("build-source-diff", [sys.executable, str(root / "checks/build-source-diff.py")]),
]
receipts = []
for name, command in checks:
    run = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    out = root / f"checks/final-{name}.stdout"
    err = root / f"checks/final-{name}.stderr"
    out.write_bytes(run.stdout)
    err.write_bytes(run.stderr)
    receipts.append({
        "name": name, "command": command, "exit": run.returncode,
        "stdout": str(out), "stdout_sha256": hashlib.sha256(run.stdout).hexdigest(),
        "stderr": str(err), "stderr_sha256": hashlib.sha256(run.stderr).hexdigest(),
    })
    print(f"{name}: exit {run.returncode}")
    if run.returncode:
        print(run.stdout.decode(errors="replace"))
        print(run.stderr.decode(errors="replace"))
(root / "checks/source-checks.json").write_text(json.dumps(receipts, indent=2) + "\n")
if any(item["exit"] for item in receipts):
    raise SystemExit(1)
