"""Small deterministic classifier checks; NOT a product/runtime test."""

from __future__ import annotations

import copy
import importlib.util
import json
import sys
import threading
from pathlib import Path
from unittest.mock import patch

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
PACKET = (
    ROOT / "LOCAL/raw/e02-execution-20261027/repairs/R4-native-control-r1/native-profile-8k512-r1"
)
spec = importlib.util.spec_from_file_location(
    "r4_native_checks_control", PACKET / "native_checks.py"
)
assert spec is not None and spec.loader is not None
checks = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = checks
spec.loader.exec_module(checks)


def event(kind: str, seq: int, tree: int, when: int, cpu: int) -> dict:
    return {
        "kind": kind,
        "sequence": seq,
        "pid": 12,
        "thread_id": 31,
        "native_thread_id": 41,
        "tree_identity": tree,
        "fit_call_id": tree,
        "monotonic_ns": when,
        "thread_time_ns": cpu,
        "success": True,
        "node_count": 9,
    }


def observation() -> dict:
    return {
        "case": {"verdict": {"backend_load": "PASS"}},
        "executor": {
            "occupied_worker": {
                "pid": 12,
                "thread_id": 31,
                "native_thread_id": 41,
                "mach_thread_port": 55,
                "is_current_shared_executor_worker": True,
            }
        },
        "native": {
            "forest_dr_fit_events": [
                {
                    "kind": "fit_enter",
                    "estimator_identity": 77,
                    "fit_call_id": 99,
                    "pid": 12,
                    "thread_id": 31,
                    "native_thread_id": 41,
                    "monotonic_ns": 5,
                    "success": True,
                },
                {
                    "kind": "fit_return",
                    "estimator_identity": 77,
                    "fit_call_id": 99,
                    "pid": 12,
                    "thread_id": 31,
                    "native_thread_id": 41,
                    "monotonic_ns": 100,
                    "success": True,
                },
            ],
            "grf_tree_fit_events": [
                event("fit_enter", 1, 1, 10, 1),
                event("fit_return", 2, 1, 20, 2),
                event("fit_enter", 3, 2, 25, 3),
                event("fit_return", 4, 2, 75, 6),
            ],
        },
        "cancel": {
            "post_start_ns": 30,
            "post_end_ns": 70,
            "fresh_sqlite_readback": {"monotonic_ns": 80},
            "future_unfinished_at_response": True,
            "worker_cpu_bracket": {
                "available": True,
                "method": "mach_THREAD_BASIC_INFO",
                "pid": 12,
                "thread_id": 31,
                "native_thread_id": 41,
                "mach_thread_port": 55,
                "flavor": 3,
                "count": 10,
                "struct_size_bytes": 40,
                "resolution_microseconds": 1,
                "before": {
                    "monotonic_ns": 29,
                    "return_code": 0,
                    "returned_count": 10,
                    "struct_size_bytes": 40,
                    "error": None,
                    "user_time": {"seconds": 0, "microseconds": 2},
                    "system_time": {"seconds": 0, "microseconds": 1},
                    "thread_cpu_microseconds": 3,
                },
                "after": {
                    "monotonic_ns": 71,
                    "return_code": 0,
                    "returned_count": 10,
                    "struct_size_bytes": 40,
                    "error": None,
                    "user_time": {"seconds": 0, "microseconds": 4},
                    "system_time": {"seconds": 0, "microseconds": 1},
                    "thread_cpu_microseconds": 5,
                },
                "thread_cpu_delta_microseconds": 2,
                "error": None,
            },
        },
        "result": {"fit_natural_return_ns": 100},
    }


def reject(call) -> bool:
    try:
        call()
    except (ValueError, KeyError, TypeError):
        return True
    return False


def snapshot_hash(value: dict) -> str:
    return checks.sha_bytes(json.dumps(value, sort_keys=True, separators=(",", ":")).encode())


def main() -> None:
    results = {}
    baseline = observation()
    results["synthetic_spanning_and_cpu"] = checks.native_overlap(baseline)["state"] == "PASS"
    for label, mutate in (
        (
            "no_spanning",
            lambda x: x["native"]["grf_tree_fit_events"][2].update(monotonic_ns=31),
        ),
        (
            "no_before",
            lambda x: x["native"].update(
                grf_tree_fit_events=x["native"]["grf_tree_fit_events"][2:]
            ),
        ),
        (
            "future_done",
            lambda x: x["cancel"].update(future_unfinished_at_response=False),
        ),
        (
            "cpu_unavailable",
            lambda x: x["cancel"]["worker_cpu_bracket"].update(
                available=False, error="unsupported"
            ),
        ),
        (
            "cpu_no_increment",
            lambda x: (
                x["cancel"]["worker_cpu_bracket"]["after"]["user_time"].update(microseconds=2),
                x["cancel"]["worker_cpu_bracket"]["after"].update(thread_cpu_microseconds=3),
                x["cancel"]["worker_cpu_bracket"].update(thread_cpu_delta_microseconds=0),
            ),
        ),
        (
            "fit_return_before_durable",
            lambda x: (
                x["result"].update(fit_natural_return_ns=79),
                x["native"]["forest_dr_fit_events"][1].update(monotonic_ns=79),
            ),
        ),
    ):
        item = copy.deepcopy(baseline)
        mutate(item)
        results[label] = checks.native_overlap(item)["state"] == "INCONCLUSIVE"
    wrong = copy.deepcopy(baseline)
    wrong["native"]["grf_tree_fit_events"][3]["fit_call_id"] = 9
    results["mismatched_tree_fit_call_rejected"] = reject(lambda: checks.native_overlap(wrong))
    wrong = copy.deepcopy(baseline)
    wrong["native"]["forest_dr_fit_events"][1]["fit_call_id"] = 98
    results["mismatched_outer_fit_call_rejected"] = reject(lambda: checks.native_overlap(wrong))
    wrong = copy.deepcopy(baseline)
    wrong["native"]["forest_dr_fit_events"][1]["estimator_identity"] = 78
    results["mismatched_outer_estimator_rejected"] = reject(lambda: checks.native_overlap(wrong))
    wrong = copy.deepcopy(baseline)
    wrong["native"]["grf_tree_fit_events"][3]["thread_id"] = 99
    results["wrong_worker_rejected"] = reject(lambda: checks.native_overlap(wrong))
    wrong = copy.deepcopy(baseline)
    wrong["cancel"]["worker_cpu_bracket"]["after"]["returned_count"] = 9
    results["short_mach_read_rejected"] = reject(lambda: checks.native_overlap(wrong))
    wrong = copy.deepcopy(baseline)
    wrong["cancel"]["worker_cpu_bracket"]["after"]["monotonic_ns"] = 69
    results["non_bracketing_clock_rejected"] = reject(lambda: checks.native_overlap(wrong))
    unavailable = copy.deepcopy(baseline)
    unavailable["case"]["verdict"]["backend_load"] = "UNAVAILABLE"
    results["unavailable_backend_is_environment_error"] = (
        checks.native_overlap(unavailable)["state"] == "ENVIRONMENT_ERROR"
    )
    # This callable actually waits on a stdlib Event while marker/status fields
    # remain unchanged. It yields no EconML tree events. No product import runs.
    entered, release = threading.Event(), threading.Event()

    def held_callable() -> None:
        entered.set()
        release.wait(3)

    thread = threading.Thread(target=held_callable)
    thread.start()
    entered_ok = entered.wait(1)
    held = copy.deepcopy(baseline)
    held["native"]["grf_tree_fit_events"] = []
    held["cancel"]["queue_marker"] = "full"
    held["cancel"]["status_marker"] = 200
    try:
        results["event_held_marker_falsifier"] = (
            entered_ok
            and thread.is_alive()
            and checks.native_overlap(held)["state"] == "INCONCLUSIVE"
            and checks.cheap_falsifier(baseline)["marker_only"]["state"] == "INCONCLUSIVE"
        )
    finally:
        release.set()
        thread.join(1)
    results["synthetic_thread_joined"] = not thread.is_alive()
    before = {
        "job_row": {
            "job_id": "synthetic",
            "run_id": "run",
            "attempt": 1,
            "lease_owner": "owner",
            "state": "running",
            "lease_expires_at": "1",
            "method_execution_selection_json": None,
        },
        "progress": [],
        "events": [],
        "outbox": [],
    }
    after = copy.deepcopy(before)
    after["job_row"]["lease_expires_at"] = "2"
    rows = [
        {
            "kind": kind,
            "status_code": 403,
            "request_start_ns": 10,
            "request_end_ns": 20,
            "url": "/api/v1/control/jobs/synthetic/cancel",
            "request_url": "http://testserver/api/v1/control/jobs/synthetic/cancel",
            "request_body": {
                "expected_lease_owner": "owner",
                "expected_attempt": 2 if kind == "stale_attempt" else 1,
                "operation_id": "synthetic",
            },
            "response_body": {},
            "before_snapshot": copy.deepcopy(before),
            "after_snapshot": copy.deepcopy(after),
            "before_snapshot_sha256": snapshot_hash(before),
            "after_snapshot_sha256": snapshot_hash(after),
        }
        for kind in ("stale_attempt", "denied_permission")
    ]
    results["heartbeat_only_delta_accepted"] = (
        len(
            checks.negative_checks(
                rows,
                job_id="synthetic",
                run_id="run",
                attempt=1,
                owner="owner",
                positive_post_start_ns=30,
            )
        )
        == 2
    )
    surfaces = checks.negative_checks(
        rows, job_id="synthetic", run_id="run", attempt=1, owner="owner", positive_post_start_ns=30
    )
    results["missing_selection_gets_are_not_established"] = all(
        item["selection_surface"] == "NOT_ESTABLISHED" and item["passed"]
        for item in surfaces.values()
    )
    unavailable = copy.deepcopy(rows)
    for row in unavailable:
        row["selection_before_http"] = {"status_code": 503, "body": {}}
        row["selection_after_http"] = {"status_code": 503, "body": {}}
    surfaces = checks.negative_checks(
        unavailable,
        job_id="synthetic",
        run_id="run",
        attempt=1,
        owner="owner",
        positive_post_start_ns=30,
    )
    results["unavailable_gets_cannot_be_unchanged_surface"] = all(
        item["selection_surface"] == "NOT_ESTABLISHED" for item in surfaces.values()
    )
    observable = copy.deepcopy(rows)
    http = {
        "method": "GET",
        "url": "/api/v1/runs/run",
        "request_url": "http://testserver/api/v1/runs/run",
        "status_code": 200,
        "body": {"run": {"run_id": "run", "method_execution_selection": {"status": "withheld"}}},
    }
    for row in observable:
        row["selection_before_http"] = copy.deepcopy(http)
        row["selection_after_http"] = copy.deepcopy(http)
    surfaces = checks.negative_checks(
        observable,
        job_id="synthetic",
        run_id="run",
        attempt=1,
        owner="owner",
        positive_post_start_ns=30,
    )
    results["bound_equal_gets_observed_unchanged"] = all(
        item["selection_surface"] == "UNCHANGED_OBSERVED" for item in surfaces.values()
    )
    observable[0]["selection_after_http"]["body"]["run"]["method_execution_selection"]["status"] = (
        "selected"
    )
    surfaces = checks.negative_checks(
        observable,
        job_id="synthetic",
        run_id="run",
        attempt=1,
        owner="owner",
        positive_post_start_ns=30,
    )
    results["changed_selection_surface_disclosed"] = (
        surfaces["stale_attempt"]["selection_surface"] == "CHANGED_OBSERVED"
    )
    accepted_changed = copy.deepcopy(rows)
    accepted_changed[0]["status_code"] = 200
    accepted_changed[0]["after_snapshot"]["job_row"]["method_execution_selection_json"] = (
        '{"fake":true}'
    )
    accepted_changed[0]["after_snapshot_sha256"] = snapshot_hash(
        accepted_changed[0]["after_snapshot"]
    )
    accepted_result = checks.negative_checks(
        accepted_changed,
        job_id="synthetic",
        run_id="run",
        attempt=1,
        owner="owner",
        positive_post_start_ns=30,
    )
    results["accepted_stale_request_remains_red_if_snapshot_changed"] = (
        accepted_result["stale_attempt"]["state"] == "FAIL"
    )
    altered = copy.deepcopy(rows)
    altered[0]["after_snapshot"]["job_row"]["method_execution_selection_json"] = '{"fake":true}'
    altered[0]["after_snapshot_sha256"] = snapshot_hash(altered[0]["after_snapshot"])
    results["selection_change_rejected_even_with_rehashed_snapshot"] = not all(
        value["passed"]
        for value in checks.negative_checks(
            altered,
            job_id="synthetic",
            run_id="run",
            attempt=1,
            owner="owner",
            positive_post_start_ns=30,
        ).values()
    )
    altered = copy.deepcopy(rows)
    altered[0]["after_snapshot"]["events"].append({"event_type": "job_cancelled"})
    altered[0]["after_snapshot_sha256"] = snapshot_hash(altered[0]["after_snapshot"])
    results["cancel_event_rejected_even_with_rehashed_snapshot"] = not all(
        value["passed"]
        for value in checks.negative_checks(
            altered,
            job_id="synthetic",
            run_id="run",
            attempt=1,
            owner="owner",
            positive_post_start_ns=30,
        ).values()
    )
    altered = copy.deepcopy(rows)
    altered[1]["status_code"] = 200
    results["allowed_negative_rejected"] = not all(
        value["passed"]
        for value in checks.negative_checks(
            altered,
            job_id="synthetic",
            run_id="run",
            attempt=1,
            owner="owner",
            positive_post_start_ns=30,
        ).values()
    )
    altered = copy.deepcopy(rows)
    altered[0]["request_start_ns"] = 31
    altered[0]["request_end_ns"] = 32
    results["negative_after_positive_not_qualified"] = not all(
        value["passed"]
        for value in checks.negative_checks(
            altered,
            job_id="synthetic",
            run_id="run",
            attempt=1,
            owner="owner",
            positive_post_start_ns=30,
        ).values()
    )
    final = {
        "job_row": {
            "job_id": "job",
            "run_id": "run",
            "attempt": 1,
            "state": "cancelled",
            "lease_owner": None,
            "method_execution_selection_json": None,
        },
        "progress": [],
        "events": [{"job_id": "job", "event_type": "job_cancelled"}],
        "outbox": [{"job_id": "job", "topic": "control.job.cancelled"}],
    }
    results["cancelled_state_recomputed"] = checks.cancellation_state(final, "job", "run", 1)[
        "passed"
    ]
    changed = copy.deepcopy(final)
    changed["job_row"]["method_execution_selection_json"] = '{"selected":true}'
    results["accepted_selection_fails_cancel_property"] = not checks.cancellation_state(
        changed, "job", "run", 1
    )["passed"]
    changed = copy.deepcopy(final)
    changed["events"].append({"job_id": "job", "event_type": "job_completed"})
    results["completed_terminal_fails_cancel_property"] = not checks.cancellation_state(
        changed, "job", "run", 1
    )["passed"]
    changed = copy.deepcopy(final)
    changed["outbox"][0]["job_id"] = "different-job"
    results["sibling_outbox_cannot_substitute"] = not checks.cancellation_state(
        changed, "job", "run", 1
    )["passed"]
    changed = copy.deepcopy(rows)
    changed[0]["after_snapshot"]["progress"].append(
        {"job_id": "synthetic", "progress_json": "{}", "updated_at": "later"}
    )
    changed[0]["after_snapshot_sha256"] = snapshot_hash(changed[0]["after_snapshot"])
    results["progress_change_is_inconclusive"] = (
        checks.negative_checks(
            changed,
            job_id="synthetic",
            run_id="run",
            attempt=1,
            owner="owner",
            positive_post_start_ns=30,
        )["stale_attempt"]["state"]
        == "INCONCLUSIVE"
    )
    results["early_fit_never_becomes_semantic_red"] = (
        checks.classify_complete(
            {"bounded_native_in_flight": "INCONCLUSIVE", "state": "INCONCLUSIVE"},
            observed_failure=True,
            unestablished=False,
            junit_failure=False,
        )
        == "INCONCLUSIVE"
    )
    results["live_semantic_red_not_hidden"] = (
        checks.classify_complete(
            {"bounded_native_in_flight": "PASS", "state": "PASS"},
            observed_failure=True,
            unestablished=False,
            junit_failure=False,
        )
        == "FAIL"
    )
    results["unavailable_cpu_stays_inconclusive"] = (
        checks.classify_complete(
            {"bounded_native_in_flight": "PASS", "state": "INCONCLUSIVE"},
            observed_failure=False,
            unestablished=False,
            junit_failure=False,
        )
        == "INCONCLUSIVE"
    )
    request = {
        "operation_id": "op-1",
        "expected_attempt": 1,
        "expected_lease_owner": "owner",
    }
    wire = json.dumps(request, separators=(",", ":"))
    authority = {
        "authorized_actor": "actor",
        "tenant_id": "tenant",
        "cell_id": "cell",
        "operation_id": "op-1",
        "body_sha256": "sha256:" + checks.sha_bytes(wire.encode()),
        "expected_attempt": 1,
        "expected_lease_owner": "owner",
        "disposition": "publication_fenced",
        "physical_stop_status": "not_established",
        "cancelled_attempt": 1,
        "cancelled_lease_owner": "owner",
    }
    bound = {
        "job_row": {
            "job_id": "job",
            "run_id": "run",
            "attempt": 1,
            "state": "cancelled",
            "lease_owner": None,
            "method_execution_selection_json": None,
        },
        "progress": [{"job_id": "job", "progress_json": json.dumps({"cancellation": authority})}],
        "events": [
            {
                "job_id": "job",
                "event_type": "job_created",
                "payload_json": json.dumps(
                    {"execution_scope": {"tenant_id": "tenant", "cell_id": "cell"}}
                ),
            },
            {
                "job_id": "job",
                "event_type": "job_cancelled",
                "payload_json": json.dumps({**authority, "state": "cancelled"}),
            },
        ],
        "outbox": [
            {
                "job_id": "job",
                "topic": "control.job.cancelled",
                "payload_json": json.dumps(
                    {
                        **authority,
                        "state": "cancelled",
                        "job_id": "job",
                        "run_id": "run",
                    }
                ),
            }
        ],
    }
    kwargs = {
        "job_id": "job",
        "run_id": "run",
        "attempt": 1,
        "owner": "owner",
        "tenant": "tenant",
        "cell": "cell",
        "actor": "actor",
        "request_body": request,
        "request_wire_utf8": wire,
    }
    results["actual_carrier_shape_binds"] = checks.cancellation_binding(bound, **kwargs)["passed"]
    changed = copy.deepcopy(bound)
    wrong_outbox = json.loads(changed["outbox"][0]["payload_json"])
    wrong_outbox["operation_id"] = "other"
    changed["outbox"][0]["payload_json"] = json.dumps(wrong_outbox)
    results["different_outbox_operation_rejected"] = not checks.cancellation_binding(
        changed, **kwargs
    )["passed"]
    changed = copy.deepcopy(bound)
    wrong_progress = json.loads(changed["progress"][0]["progress_json"])
    wrong_progress["cancellation"]["body_sha256"] = "sha256:" + "0" * 64
    changed["progress"][0]["progress_json"] = json.dumps(wrong_progress)
    results["wrong_wire_body_digest_rejected"] = not checks.cancellation_binding(changed, **kwargs)[
        "passed"
    ]
    payload = {
        "outcome": [i / 10 + (i % 2) * 0.5 for i in range(2000)],
        "treatment": [i % 2 for i in range(2000)],
        "covariates": [[float(i), float(i % 5)] for i in range(2000)],
        "confounders": [[float(i % 7)] for i in range(2000)],
        "sample_ids": [f"candidate-{i}" for i in range(2000)],
        "feature_names": ["age", "baseline"],
        "confounder_names": ["risk"],
    }
    envelope = {
        "schema_version": "policyos.ir.observation.method_input_envelope.v1",
        "contract_payload": payload,
    }
    source = {
        "source_ref": {
            "kind": "ir.observation_method_input",
            "media_type": "application/json",
        },
        "source_kind": "ir.observation_method_input",
    }
    with patch.object(checks, "selected_cas", return_value=(envelope, {})):
        results["all_2000_fixture_rows_recomputed"] = (
            checks.source_custody(source, Path("/synthetic-case"))["rows"] == 2000
        )
    bad = copy.deepcopy(envelope)
    bad["contract_payload"]["covariates"][1111][1] = 999
    with patch.object(checks, "selected_cas", return_value=(bad, {})):
        results["interior_row_formula_tamper_rejected"] = reject(
            lambda: checks.source_custody(source, Path("/synthetic-case"))
        )
    saturated = copy.deepcopy(baseline)
    saturated["executor"]["profile"] = {"capacity": 2, "queue_capacity": 2}
    saturated["executor"]["nonnumeric_peer"] = {
        "mode": "event_wait",
        "numeric_work": False,
        "is_current_shared_executor_worker": True,
        "pid": 12,
        "thread_id": 32,
        "native_thread_id": 42,
        "enter_ns": 15,
        "release_ns": 71,
        "exit_ns": 72,
        "release_observed": True,
    }
    saturated["executor"]["queue"] = {
        "pending_when_fit_active": True,
        "overflow_error_code": "shared_executor_queue_full",
        "overflow_capacity": 2,
        "overflow_queue_capacity": 2,
        "overflow_queue_depth": 2,
        "physical_workers": 2,
        "queued_jobs": 2,
        "outstanding_jobs": 4,
        "full_observed_ns": 25,
        "follower_events": [
            {"follower_id": 1, "pid": 12, "monotonic_ns": 73},
            {"follower_id": 2, "pid": 12, "monotonic_ns": 74},
        ],
    }
    results["capacity_two_real_worker_peer_and_follower"] = checks.saturation_premise(saturated)[
        "passed"
    ]
    changed = copy.deepcopy(saturated)
    changed["executor"]["nonnumeric_peer"]["thread_id"] = 31
    results["same_thread_peer_rejected"] = not checks.saturation_premise(changed)["passed"]
    changed = copy.deepcopy(saturated)
    changed["executor"]["nonnumeric_peer"]["release_ns"] = 69
    results["peer_released_during_post_rejected"] = not checks.saturation_premise(changed)["passed"]
    changed = copy.deepcopy(saturated)
    changed["executor"]["queue"]["outstanding_jobs"] = 3
    results["missing_follower_slot_rejected"] = not checks.saturation_premise(changed)["passed"]
    changed = copy.deepcopy(saturated)
    changed["executor"]["queue"]["follower_events"][0]["monotonic_ns"] = 70
    results["follower_entered_before_release_rejected"] = not checks.saturation_premise(changed)[
        "passed"
    ]
    output = {
        "schema": "policyos.e02.r4.native-classifier-stdlib-controls.v1",
        "scope": "synthetic stdlib classifier controls only; no native/backend/product execution",
        "results": results,
        "pass": all(results.values()),
        "closure_ids": [],
    }
    print(json.dumps(output, sort_keys=True, indent=2))
    if not output["pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
