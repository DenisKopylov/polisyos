"""Public scientist decision validity module API."""

from __future__ import annotations

import fcntl
import hashlib
import json
import os
import threading
import uuid
from collections.abc import Callable
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timedelta
from functools import wraps
from pathlib import Path
from typing import TYPE_CHECKING, Any, Concatenate, Literal, TypeVar, cast

from pydantic import BaseModel, ConfigDict, Field, ValidationError

from polisyos.common.timestamps import to_iso_utc, utc_now
from polisyos.core.artifacts import read_core_json_artifact
from polisyos.core.artifacts.ids import ArtifactID
from polisyos.core.artifacts.manifest import (
    ArtifactRef,
    CanonInfo,
    InputRef,
    SchemaInfo,
    artifact_ref_identity_key,
)
from polisyos.core.artifacts.write_contract import ArtifactWriteOptions
from polisyos.core.canon import (
    CanonSpec,
    content_hash,
    from_canonical_bytes,
    to_canonical_bytes,
)
from polisyos.core.contracts.decision_validity import (
    DecisionDependencyEvent,
    DecisionDependencyKind,
    DecisionLifecycleJob,
    DecisionTriggerRecord,
    DecisionTriggerType,
    DecisionValidityEnvelope,
    DecisionValidityEpochImpactOwnerRow,
    DecisionValidityEpochImpactSnapshot,
    DecisionValidityEpochImpactSnapshotHandle,
    DecisionValidityEpochImpactTarget,
    DecisionValidityEvaluation,
    DecisionValidityStatus,
    DecisionValidityTransition,
    EpochDenominatorReconciliationAdmissionBinding,
    EpochTransitionDenominatorReconciliationHandle,
    EpochTransitionDenominatorReconciliationReader,
    EpochTransitionVerificationReceipt,
    EpochTransitionVerifier,
    EpochValidityBatchCompletionStatement,
    EpochValidityBatchReceipt,
    EpochValidityBatchTarget,
    EpochValidityPendingBatch,
    PersistedDecisionValidityEpochImpactSnapshot,
    PersistedEpochTransitionDenominatorReconciliation,
    PersistedEpochValidityBatchEvidence,
    SourceAdmissionCarrier,
    SourceAdmissionReceipt,
    SourceCurrentUseProjection,
    SourceRegistrationReceipt,
)
from polisyos.core.contracts.feedback import DecisionMonitoringContract
from polisyos.scientist.orchestration.engine.operational_monitoring import (
    get_operational_monitor,
)
from polisyos.scientist.validation.source_admission_owner import (
    _RegisteredSourceAdmissionOwner,
)
from polisyos.scientist.validation.source_admission_port import (
    SourceAdmissionAuthority,
    VerifiedRegisteredMaterialization,
)

if TYPE_CHECKING:
    from polisyos.core.artifacts.protocol import ArtifactStore

_StateModel = TypeVar("_StateModel", bound=BaseModel)

_DECISION_VALIDITY_JSON_LOAD_ERRORS = (OSError, ValueError, json.JSONDecodeError)
_DECISION_VALIDITY_MODEL_ERRORS = (TypeError, ValueError, ValidationError)
_DECISION_VALIDITY_ARTIFACT_LOAD_ERRORS = (
    OSError,
    RuntimeError,
    TypeError,
    ValueError,
    ValidationError,
)
_EPOCH_IMPACT_SNAPSHOT_KIND = "scientist.decision_validity_epoch_impact_snapshot"
_EPOCH_IMPACT_SNAPSHOT_MEDIA_TYPE = "application/json"
_EPOCH_IMPACT_SNAPSHOT_SCHEMA = "polisyos.decision-validity.epoch-impact-snapshot.v1"
_EPOCH_IMPACT_SNAPSHOT_CANON = CanonSpec()


def _serialize_datetime(value: datetime | None) -> str | None:
    return to_iso_utc(value) if value is not None else None


class _DecisionPacketState(BaseModel):
    model_config = ConfigDict(extra="forbid")

    packet_ref: str
    decision_lineage_key: str
    current_status: DecisionValidityStatus = DecisionValidityStatus.WARNING
    last_checked_at: datetime | None = None
    evaluation_ref: str | None = None
    reasons: list[str] = Field(default_factory=list)
    active_triggers: list[DecisionTriggerRecord] = Field(default_factory=list)
    sticky_triggers: list[DecisionTriggerRecord] = Field(default_factory=list)
    dependency_keys: list[str] = Field(default_factory=list)
    review_required: bool = False
    supersedes_decision_ref: str | None = None
    superseded_by_ref: str | None = None
    monitoring_contract_ref: str | None = None
    latest_monitoring_report_ref: str | None = None
    latest_compare_report_ref: str | None = None
    latest_reissue_plan_ref: str | None = None
    lifecycle_events: list[DecisionDependencyEvent] = Field(default_factory=list)
    transition_history: list[DecisionValidityTransition] = Field(default_factory=list)
    lifecycle_jobs: list[DecisionLifecycleJob] = Field(default_factory=list)
    last_transition_at: datetime | None = None


class _DecisionLineageState(BaseModel):
    model_config = ConfigDict(extra="forbid")

    decision_lineage_key: str
    head_packet_ref: str
    evaluation_ref: str | None = None
    updated_at: datetime = Field(default_factory=utc_now)


class _DecisionDependencyIndex(BaseModel):
    model_config = ConfigDict(extra="forbid")

    dependency_key: str
    dependency_kind: DecisionDependencyKind
    artifact_id: str | None = None
    packet_refs: list[str] = Field(default_factory=list)
    lineage_keys: list[str] = Field(default_factory=list)
    updated_at: datetime = Field(default_factory=utc_now)


class _PersistedEpochBatchReceiptState(BaseModel):
    """Local index binding a batch id to exact CAS receipt bytes."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    receipt: EpochValidityBatchReceipt
    receipt_artifact_ref: ArtifactRef
    receipt_content_hash: str = Field(pattern=r"^sha256:[0-9a-f]{64}$")


@dataclass(frozen=True)
class _EpochImpactProjection:
    """Private nullable projection shared by legacy and strict owner reads."""

    owner_rows: tuple[dict[str, object], ...]
    targets: tuple[tuple[str, str, str], ...]
    decision_impact_denominator_ref: str


def _completed_hte_basis_warning_trigger(
    *,
    basis: dict[str, Any],
    reason: str,
) -> DecisionTriggerRecord:
    """Build the shared warning record for an unestablished completed-HTE basis."""

    return DecisionTriggerRecord(
        trigger_type=DecisionTriggerType.METRIC_INVALIDATION,
        status=DecisionValidityStatus.WARNING,
        reason=reason,
        details={
            "request_status": basis.get("completed_hte_request_status"),
            "selection_status": basis.get("completed_hte_source_status"),
            "requested_source_run_id": basis.get("completed_hte_requested_source_run_id"),
            "source_run_id": basis.get("completed_hte_source_run_id")
            or basis.get("completed_hte_requested_source_run_id"),
            "source_job_id": basis.get("completed_hte_source_job_id"),
            "source_attempt": basis.get("completed_hte_source_attempt"),
            "authority_purpose": basis.get("completed_hte_authority_purpose"),
            "publication_authorization": basis.get("completed_hte_publication_authorization"),
        },
    )


def _completed_hte_request_selection_trigger(
    *,
    packet_payload: dict[str, Any],
    envelope: DecisionValidityEnvelope,
) -> DecisionTriggerRecord | None:
    """Evaluate the typed completed-HTE request and selected-source basis."""

    basis = envelope.data_basis.summary
    hte_value = packet_payload.get("hte")
    source_status = basis.get("completed_hte_source_status")
    request_status = basis.get("completed_hte_request_status")
    requested_source_run_id = basis.get("completed_hte_requested_source_run_id")
    source_run_id = basis.get("completed_hte_source_run_id")

    if source_status is None:
        # Missing selection state is legacy only when the typed basis contains no
        # completed-HTE request or selection evidence at all. A partial typed basis
        # cannot erase an outstanding request by dropping its status field.
        if any(isinstance(key, str) and key.startswith("completed_hte_") for key in basis):
            return _completed_hte_basis_warning_trigger(
                basis=basis,
                reason="completed_hte_selection_status_not_established",
            )
        # Legacy projections remain read-limited: raw marker dictionaries do not
        # establish a completed-source request or selection.
        if hte_value is None or not isinstance(hte_value, dict):
            return None
        try:
            from polisyos.core.contracts.runtime import DirectMethodExecutionHTESummary

            DirectMethodExecutionHTESummary.model_validate_json(
                json.dumps(hte_value),
                strict=True,
            )
        except (ImportError, TypeError, ValueError):
            return None
        return _completed_hte_basis_warning_trigger(
            basis=basis,
            reason="completed_hte_dependency_basis_not_established",
        )

    if source_status == "verification_missing":
        limitation = basis.get("completed_hte_limitation_code")
        return _completed_hte_basis_warning_trigger(
            basis=basis,
            reason=(
                limitation
                if type(limitation) is str and limitation
                else "completed_hte_source_not_established"
            ),
        )
    if source_status != "selected":
        return _completed_hte_basis_warning_trigger(
            basis=basis,
            reason="completed_hte_selection_status_not_established",
        )

    if (
        request_status != "requested"
        or type(requested_source_run_id) is not str
        or not requested_source_run_id
    ):
        return _completed_hte_basis_warning_trigger(
            basis=basis,
            reason="completed_hte_selection_status_not_established",
        )
    if (
        type(source_run_id) is not str
        or not source_run_id
        or requested_source_run_id != source_run_id
    ):
        return _completed_hte_basis_warning_trigger(
            basis=basis,
            reason="completed_hte_dependency_basis_not_established",
        )

    # Publication authorization is a separate authority boundary. A valid
    # candidate selection remains candidate-grade when publication is unknown.
    return None


class _DecisionValidityStateStore:
    """Persist decision validity packets, lineage heads, dependencies, and dedupe state."""

    def __init__(self, cas: ArtifactStore | Path) -> None:
        root_value = cas if isinstance(cas, Path) else getattr(cas, "root", cas)
        if isinstance(root_value, str):
            root_path = Path(root_value)
        elif isinstance(root_value, Path):
            root_path = root_value
        else:
            raise TypeError("DecisionValidityStateStore requires a local store root or Path")
        self._base = root_path / "decision_validity"
        self._packets = self._base / "packets"
        self._lineages = self._base / "lineages"
        self._dependencies = self._base / "dependencies"
        self._dedupes = self._base / "dedupes"
        self._epoch_pending = self._base / "epoch_pending"
        self._epoch_receipts = self._base / "epoch_receipts"
        self._epoch_reconciliation_admissions = self._base / "epoch_reconciliation_admissions"
        self._epoch_lock_path = self._base / "epoch_batch.lock"
        self._owner_process_lock = threading.RLock()
        self._owner_transaction_state = threading.local()
        self._packets.mkdir(parents=True, exist_ok=True)
        self._lineages.mkdir(parents=True, exist_ok=True)
        self._dependencies.mkdir(parents=True, exist_ok=True)
        self._dedupes.mkdir(parents=True, exist_ok=True)
        self._epoch_pending.mkdir(parents=True, exist_ok=True)
        self._epoch_receipts.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def make_key(value: str) -> str:
        normalized = value.strip()
        return content_hash(normalized) if normalized else "global"

    def _packet_path(self, packet_ref: str) -> Path:
        return self._packets / f"{self.make_key(packet_ref)}.json"

    def _lineage_path(self, lineage_key: str) -> Path:
        return self._lineages / f"{self.make_key(lineage_key)}.json"

    def _dependency_path(self, dependency_key: str) -> Path:
        return self._dependencies / f"{self.make_key(dependency_key)}.json"

    def _dedupe_path(self, dedupe_key: str) -> Path:
        return self._dedupes / f"{self.make_key(dedupe_key)}.json"

    def load_packet(self, packet_ref: str) -> _DecisionPacketState | None:
        return self._load_model_strict(self._packet_path(packet_ref), _DecisionPacketState)

    def save_packet(self, state: _DecisionPacketState) -> None:
        self._save_model(self._packet_path(state.packet_ref), state)

    def load_lineage(self, lineage_key: str) -> _DecisionLineageState | None:
        return self._load_model_strict(self._lineage_path(lineage_key), _DecisionLineageState)

    def save_lineage(self, state: _DecisionLineageState) -> None:
        self._save_model(self._lineage_path(state.decision_lineage_key), state)

    def load_dependency(self, dependency_key: str) -> _DecisionDependencyIndex | None:
        return self._load_model_strict(
            self._dependency_path(dependency_key), _DecisionDependencyIndex
        )

    def save_dependency(self, state: _DecisionDependencyIndex) -> None:
        self._save_model(self._dependency_path(state.dependency_key), state)

    def load_dedupe_event_id(self, dedupe_key: str) -> str | None:
        path = self._dedupe_path(dedupe_key)
        if not path.exists():
            return None
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError, json.JSONDecodeError) as exc:
            raise RuntimeError("decision_validity_owner_state_corrupt") from exc
        value = payload.get("event_id")
        if not isinstance(value, str) or not value:
            raise RuntimeError("decision_validity_owner_state_corrupt")
        return value

    def save_dedupe_event_id(self, dedupe_key: str, event_id: str) -> None:
        path = self._dedupe_path(dedupe_key)
        self._write_bytes_atomic(
            path,
            json.dumps({"event_id": event_id}, sort_keys=True, separators=(",", ":")).encode(
                "utf-8"
            ),
        )

    def load_epoch_pending(self, batch_id: str) -> EpochValidityPendingBatch | None:
        """Load one durable phase-one freeze."""

        return self._load_model_strict(
            self._epoch_pending / f"{self.make_key(batch_id)}.json",
            EpochValidityPendingBatch,
        )

    def save_epoch_pending(self, batch: EpochValidityPendingBatch) -> None:
        """Atomically publish the complete target denominator before mutation."""

        self._save_model(
            self._epoch_pending / f"{self.make_key(batch.batch_id)}.json",
            batch,
        )

    def list_epoch_pending(self) -> tuple[EpochValidityPendingBatch, ...]:
        """Enumerate every durable freeze for restart-safe owner reads."""

        batches: list[EpochValidityPendingBatch] = []
        for item in sorted(self._epoch_pending.glob("*.json")):
            batch = self._load_model_strict(item, EpochValidityPendingBatch)
            if batch is None:  # pragma: no cover - glob established existence
                raise RuntimeError("decision_validity_epoch_pending_disappeared")
            batches.append(batch)
        return tuple(batches)

    def clear_epoch_pending(self, batch_id: str) -> None:
        """Clear phase one only after a completed receipt is durable."""

        target = self._epoch_pending / f"{self.make_key(batch_id)}.json"
        try:
            target.unlink()
        except FileNotFoundError:
            pass
        else:
            self._fsync_directory(target.parent)

    def load_epoch_receipt(self, batch_id: str) -> EpochValidityBatchReceipt | None:
        evidence = self.load_epoch_receipt_evidence(batch_id)
        return evidence.receipt if evidence is not None else None

    def load_epoch_receipt_evidence(self, batch_id: str) -> _PersistedEpochBatchReceiptState | None:
        return self._load_model_strict(
            self._epoch_receipts / f"{self.make_key(batch_id)}.json",
            _PersistedEpochBatchReceiptState,
        )

    def save_epoch_receipt(
        self,
        receipt: EpochValidityBatchReceipt,
        *,
        receipt_artifact_ref: ArtifactRef,
        receipt_content_hash: str,
    ) -> None:
        self._save_model(
            self._epoch_receipts / f"{self.make_key(receipt.batch_id)}.json",
            _PersistedEpochBatchReceiptState(
                receipt=receipt,
                receipt_artifact_ref=receipt_artifact_ref,
                receipt_content_hash=receipt_content_hash,
            ),
        )

    def load_epoch_reconciliation_admission_binding(
        self,
        batch_id: str,
    ) -> EpochDenominatorReconciliationAdmissionBinding | None:
        """Load one exact write-once reconciliation binding by batch address."""

        path = self._epoch_reconciliation_admissions / f"{self.make_key(batch_id)}.json"
        if not path.exists():
            return None
        return self._load_epoch_reconciliation_admission_binding_path(path)

    def save_epoch_reconciliation_admission_binding(
        self,
        binding: EpochDenominatorReconciliationAdmissionBinding,
    ) -> EpochDenominatorReconciliationAdmissionBinding:
        """Write once and strictly reread the winning admission binding."""

        path = self._epoch_reconciliation_admissions / (f"{self.make_key(binding.batch_id)}.json")
        candidate_bytes = to_canonical_bytes(
            binding.model_dump(mode="json"),
            _EPOCH_IMPACT_SNAPSHOT_CANON,
        )
        self._write_bytes_once(path, candidate_bytes)
        winner = self._load_epoch_reconciliation_admission_binding_path(path)
        if winner == binding:
            return winner
        raise ValueError("epoch_denominator_reconciliation_admission_conflict")

    def list_epoch_reconciliation_admission_bindings(
        self,
    ) -> tuple[EpochDenominatorReconciliationAdmissionBinding, ...]:
        """Enumerate every exact binding without creating its lazy directory."""

        if not self._epoch_reconciliation_admissions.exists():
            return ()
        return tuple(
            self._load_epoch_reconciliation_admission_binding_path(item)
            for item in sorted(self._epoch_reconciliation_admissions.glob("*.json"))
        )

    def _load_epoch_reconciliation_admission_binding_path(
        self,
        path: Path,
    ) -> EpochDenominatorReconciliationAdmissionBinding:
        try:
            raw = path.read_bytes()
            binding = EpochDenominatorReconciliationAdmissionBinding.model_validate(
                from_canonical_bytes(raw)
            )
            if raw != to_canonical_bytes(
                binding.model_dump(mode="json"),
                _EPOCH_IMPACT_SNAPSHOT_CANON,
            ):
                raise ValueError("binding_bytes_noncanonical")
            if path.name != f"{self.make_key(binding.batch_id)}.json":
                raise ValueError("binding_address_mismatch")
            return binding
        except (OSError, TypeError, ValueError, ValidationError) as exc:
            raise RuntimeError("decision_validity_owner_state_corrupt") from exc

    @contextmanager
    def owner_transaction(self):
        """Serialize every mutation that can change an owner denominator.

        The process-local lock makes the critical section thread-safe.  The
        outermost entry also takes the shared file lock, so independent
        service instances and processes use the same owner boundary.  Nested
        service calls reuse the outer transaction instead of re-locking it.
        """

        with self._owner_process_lock:
            depth = int(getattr(self._owner_transaction_state, "depth", 0))
            descriptor: int | None = None
            if depth == 0:
                descriptor = os.open(self._epoch_lock_path, os.O_CREAT | os.O_RDWR, 0o600)
                fcntl.flock(descriptor, fcntl.LOCK_EX)
                self._owner_transaction_state.descriptor = descriptor
            self._owner_transaction_state.depth = depth + 1
            try:
                yield
            finally:
                next_depth = int(self._owner_transaction_state.depth) - 1
                self._owner_transaction_state.depth = next_depth
                if next_depth == 0:
                    outer_descriptor = int(self._owner_transaction_state.descriptor)
                    fcntl.flock(outer_descriptor, fcntl.LOCK_UN)
                    os.close(outer_descriptor)
                    del self._owner_transaction_state.descriptor

    epoch_batch_transaction = owner_transaction

    def current_projection_generation_ref(self) -> str:
        """Content-bind every file that can change the owner validity projection."""

        digest = hashlib.sha256()
        roots = (
            self._packets,
            self._epoch_pending,
            self._epoch_receipts,
            self._epoch_reconciliation_admissions,
        )
        for root in roots:
            for item in sorted(root.glob("*.json")):
                relative = item.relative_to(self._base).as_posix().encode("utf-8")
                payload = item.read_bytes()
                digest.update(len(relative).to_bytes(8, "big"))
                digest.update(relative)
                digest.update(len(payload).to_bytes(8, "big"))
                digest.update(payload)
        source_root = self._base / "committed_source_root.json"
        if source_root.exists():
            payload = source_root.read_bytes()
            digest.update(b"committed_source_root.json")
            digest.update(len(payload).to_bytes(8, "big"))
            digest.update(payload)
        return "sha256:" + digest.hexdigest()

    @staticmethod
    def _load_model(path: Path, model_type: type[_StateModel]) -> _StateModel | None:
        if not path.exists():
            return None
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except _DECISION_VALIDITY_JSON_LOAD_ERRORS:
            return None
        try:
            return cast("_StateModel", model_type.model_validate(payload))
        except _DECISION_VALIDITY_MODEL_ERRORS:
            return None

    @staticmethod
    def _load_model_strict(path: Path, model_type: type[_StateModel]) -> _StateModel | None:
        if not path.exists():
            return None
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            return cast("_StateModel", model_type.model_validate(payload))
        except _DECISION_VALIDITY_JSON_LOAD_ERRORS + _DECISION_VALIDITY_MODEL_ERRORS as exc:
            raise RuntimeError("decision_validity_owner_state_corrupt") from exc

    @staticmethod
    def _save_model(path: Path, model: BaseModel) -> None:
        payload = json.dumps(
            model.model_dump(mode="json"), sort_keys=True, separators=(",", ":")
        ).encode("utf-8")
        _DecisionValidityStateStore._write_bytes_atomic(path, payload)

    @staticmethod
    def _write_bytes_atomic(path: Path, payload: bytes) -> None:
        temp = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
        descriptor = os.open(temp, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        try:
            with os.fdopen(descriptor, "wb") as stream:
                descriptor = -1
                stream.write(payload)
                stream.flush()
                os.fsync(stream.fileno())
            temp.replace(path)
            _DecisionValidityStateStore._fsync_directory(path.parent)
        except BaseException:
            try:
                temp.unlink()
            except FileNotFoundError:
                pass
            raise
        finally:
            if descriptor >= 0:
                os.close(descriptor)

    @staticmethod
    def _write_bytes_once(path: Path, payload: bytes) -> bool:
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
        descriptor = os.open(temp, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        try:
            with os.fdopen(descriptor, "wb") as stream:
                descriptor = -1
                stream.write(payload)
                stream.flush()
                os.fsync(stream.fileno())
            try:
                os.link(temp, path)
            except FileExistsError:
                return False
            _DecisionValidityStateStore._fsync_directory(path.parent)
            return True
        finally:
            if descriptor >= 0:
                os.close(descriptor)
            try:
                temp.unlink()
            except FileNotFoundError:
                pass

    @staticmethod
    def _fsync_directory(directory: Path) -> None:
        descriptor = os.open(directory, os.O_RDONLY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)


class NoEpochTransitionVerifier:
    """Production default: no transition verifier has been configured."""

    verifier_provenance_ref = None

    def verify(
        self,
        *,
        transition_artifact_ref: ArtifactRef,
        requested_query_context_ref: str,
        expected_authority_purpose: str,
    ) -> EpochTransitionVerificationReceipt:
        del (
            transition_artifact_ref,
            requested_query_context_ref,
            expected_authority_purpose,
        )
        raise ValueError("verifier_not_configured")


class NoEpochDenominatorReconciliationReader:
    """Typed empty production slot; a missing reader never admits a relation."""

    verifier_provenance_ref = None

    def resolve_for_first_admission(
        self,
        *,
        transition_artifact_ref: ArtifactRef,
        transition_content_hash: str,
        requested_query_context_ref: str,
        authority_purpose: str,
        scientist_snapshot_handle: DecisionValidityEpochImpactSnapshotHandle,
    ) -> PersistedEpochTransitionDenominatorReconciliation:
        """Refuse while the production reconciliation owner is absent."""

        raise ValueError("epoch_denominator_reconciliation_unavailable")

    def resolve_exact(
        self,
        *,
        handle: EpochTransitionDenominatorReconciliationHandle,
    ) -> PersistedEpochTransitionDenominatorReconciliation:
        """Refuse replay without the configured exact owner reader."""

        raise ValueError("epoch_denominator_reconciliation_unavailable")


def _owner_transactional[**P, R](
    method: Callable[Concatenate[Any, P], R],
) -> Callable[Concatenate[Any, P], R]:
    """Run one public owner mutation under the shared re-entrant transaction."""

    @wraps(method)
    def wrapped(self: Any, *args: P.args, **kwargs: P.kwargs) -> R:
        with self._state.owner_transaction():
            return method(self, *args, **kwargs)

    return wrapped


class DecisionValidityService:
    """Coordinate decision packet registration, dependency tracking, and re-evaluation."""

    def __init__(
        self,
        store: ArtifactStore,
        *,
        reevaluate_ttl_seconds: int = 300,
        epoch_transition_verifier: EpochTransitionVerifier | None = None,
        epoch_denominator_reconciliation_reader: EpochTransitionDenominatorReconciliationReader
        | None = None,
    ) -> None:
        self._store = store
        self._state = _DecisionValidityStateStore(store)
        self._source_admission = _RegisteredSourceAdmissionOwner(
            store, self._state._base, self._state.owner_transaction
        )
        self._ttl = max(0, int(reevaluate_ttl_seconds))
        self._epoch_transition_verifier = epoch_transition_verifier or NoEpochTransitionVerifier()
        self._epoch_denominator_reconciliation_reader = epoch_denominator_reconciliation_reader
        if epoch_transition_verifier is None and epoch_denominator_reconciliation_reader is None:
            self._epoch_denominator_reconciliation_reader = NoEpochDenominatorReconciliationReader()

    def register_materialization_source(
        self,
        authority: SourceAdmissionAuthority,
        *,
        event_id: str,
        registration_key: str,
        effective_view_contract_ref: ArtifactRef,
        use_contract_ref: ArtifactRef,
    ) -> SourceRegistrationReceipt:
        """Commit an owner-issued source incarnation for exact protected view/use."""
        return self._source_admission.register(
            authority,
            event_id=event_id,
            registration_key=registration_key,
            effective_view_contract_ref=effective_view_contract_ref,
            use_contract_ref=use_contract_ref,
        )

    def admit_materialization(
        self,
        proof: VerifiedRegisteredMaterialization,
        *,
        event_id: str,
        expected_predecessor: str,
    ) -> SourceAdmissionReceipt:
        """Admit one actual captured occurrence, without selecting it by default."""
        return self._source_admission.admit(
            proof, event_id=event_id, expected_predecessor=expected_predecessor
        )

    def transition_materialization(
        self,
        authority: SourceAdmissionAuthority,
        *,
        event_id: str,
        expected_predecessor: str,
        operation: Literal["withdraw", "readmit", "supersede"],
        target: SourceAdmissionCarrier,
    ) -> SourceAdmissionReceipt:
        """Commit exact withdrawal, new-epoch readmission, or explicit selection."""
        return self._source_admission.transition(
            authority,
            event_id=event_id,
            expected_predecessor=expected_predecessor,
            operation=operation,
            target=target,
        )

    def resolve_source_admission_event(
        self,
        authority: SourceAdmissionAuthority,
        *,
        event_id: str,
    ) -> SourceAdmissionReceipt | None:
        """Read a protected original receipt after uncertain delivery; never re-admit."""
        return self._source_admission.event_receipt(authority, event_id=event_id)

    def read_source_current_use(
        self,
        carriers: tuple[SourceAdmissionCarrier, ...],
        *,
        require_selected: bool = False,
    ) -> SourceCurrentUseProjection:
        """Read bounded source admission at one fresh common-owner fence."""
        return self._source_admission.read(carriers, require_selected=require_selected)

    def state_generation(self) -> int:
        """Return the number of persisted owner-projection records (test diagnostic)."""

        return sum(
            1
            for root in (
                self._state._packets,
                self._state._epoch_pending,
                self._state._epoch_receipts,
                self._state._epoch_reconciliation_admissions,
            )
            for _ in root.glob("*.json")
        )

    def current_projection_generation_ref(self) -> str:
        """Return the content-bound cache identity for all current validity facts."""

        return self._state.current_projection_generation_ref()

    @staticmethod
    def _epoch_verification_target_coordinates(
        receipt: EpochTransitionVerificationReceipt,
    ) -> tuple[tuple[str, str, str], ...]:
        return tuple(
            sorted(
                (
                    row.packet_ref,
                    row.dependency_key,
                    row.decision_lineage_key,
                )
                for row in receipt.targets
            )
        )

    @staticmethod
    def _epoch_reconciliation_target_coordinates(
        persisted: PersistedEpochTransitionDenominatorReconciliation,
    ) -> tuple[tuple[str, str, str], ...]:
        return tuple(
            sorted(
                (
                    row.packet_ref,
                    row.dependency_key,
                    row.decision_lineage_key,
                )
                for row in persisted.receipt.scientist_targets
            )
        )

    @classmethod
    def _require_reconciliation_matches_verification(
        cls,
        *,
        persisted: PersistedEpochTransitionDenominatorReconciliation,
        receipt: EpochTransitionVerificationReceipt,
        mismatch_code: str,
    ) -> None:
        sidecar = persisted.receipt
        if (
            sidecar.transition_artifact_ref != receipt.transition_artifact_ref
            or sidecar.transition_content_hash != receipt.transition_content_hash
            or sidecar.requested_query_context_ref != receipt.requested_query_context_ref
            or sidecar.authority_purpose != receipt.authority_purpose
            or sidecar.verifier_provenance_ref != receipt.verifier_provenance_ref
            or sidecar.decision_impact_denominator_ref != receipt.dependency_denominator_ref
            or sidecar.requested_dependency_keys != tuple(sorted(receipt.dependency_keys))
            or cls._epoch_reconciliation_target_coordinates(persisted)
            != cls._epoch_verification_target_coordinates(receipt)
        ):
            raise ValueError(mismatch_code)

    @classmethod
    def _require_binding_matches_reconciliation(
        cls,
        *,
        binding: EpochDenominatorReconciliationAdmissionBinding,
        persisted: PersistedEpochTransitionDenominatorReconciliation,
        receipt: EpochTransitionVerificationReceipt,
        batch_id: str,
    ) -> None:
        sidecar = persisted.receipt
        if (
            binding.batch_id != batch_id
            or binding.transition_artifact_ref != receipt.transition_artifact_ref
            or binding.transition_content_hash != receipt.transition_content_hash
            or binding.requested_query_context_ref != receipt.requested_query_context_ref
            or binding.authority_purpose != receipt.authority_purpose
            or binding.decision_impact_denominator_ref != receipt.dependency_denominator_ref
            or binding.scientist_snapshot_ref != sidecar.scientist_snapshot_ref
            or binding.scientist_snapshot_content_hash != sidecar.scientist_snapshot_content_hash
            or binding.verifier_provenance_ref != receipt.verifier_provenance_ref
            or binding.reconciliation_receipt_ref != persisted.handle.reconciliation_receipt_ref
            or binding.reconciliation_receipt_content_hash
            != persisted.handle.reconciliation_receipt_content_hash
            or binding.reconciliation_rule_version != sidecar.reconciliation_rule_version
            or binding.canonicalization_profile != sidecar.canonicalization_profile
        ):
            raise ValueError("epoch_denominator_reconciliation_admission_conflict")
        cls._require_reconciliation_matches_verification(
            persisted=persisted,
            receipt=receipt,
            mismatch_code="epoch_denominator_reconciliation_admission_conflict",
        )

    @staticmethod
    def _epoch_pending_from_verification(
        *,
        batch_id: str,
        receipt: EpochTransitionVerificationReceipt,
    ) -> EpochValidityPendingBatch:
        return EpochValidityPendingBatch(
            batch_id=batch_id,
            transition_artifact_ref=receipt.transition_artifact_ref,
            transition_content_hash=receipt.transition_content_hash,
            requested_query_context_ref=receipt.requested_query_context_ref,
            verifier_provenance_ref=receipt.verifier_provenance_ref,
            dependency_denominator_ref=receipt.dependency_denominator_ref,
            adjudication_denominator_ref=receipt.adjudication_denominator_ref,
            targets=receipt.targets,
        )

    @_owner_transactional
    def admit_epoch_validity_batch(
        self,
        *,
        transition_artifact_ref: ArtifactRef,
        requested_query_context_ref: str,
    ) -> EpochValidityBatchReceipt:
        """Verify and apply one complete owner-indexed epoch transition batch."""

        verifier = self._epoch_transition_verifier
        receipt = verifier.verify(
            transition_artifact_ref=transition_artifact_ref,
            requested_query_context_ref=requested_query_context_ref,
            expected_authority_purpose="decision_validity_epoch_transition",
        )
        self._validate_epoch_transition_receipt(
            receipt=receipt,
            transition_artifact_ref=transition_artifact_ref,
            requested_query_context_ref=requested_query_context_ref,
        )
        batch_id = _epoch_batch_id(
            transition_artifact_ref=transition_artifact_ref,
            requested_query_context_ref=requested_query_context_ref,
        )
        with self._state.epoch_batch_transaction():
            completed = self._load_completed_epoch_receipt(batch_id)
            pending = self._state.load_epoch_pending(batch_id)
            reconciliation_reader = self._epoch_denominator_reconciliation_reader
            if reconciliation_reader is None:
                if completed is not None:
                    self._require_completed_matches_verification(
                        completed=completed,
                        receipt=receipt,
                    )
                    if pending is not None:
                        self._require_pending_matches_verification(
                            pending=pending,
                            receipt=receipt,
                        )
                        self._state.clear_epoch_pending(batch_id)
                    return completed

                if pending is None:
                    active = self._state.list_epoch_pending()
                    if active:
                        raise ValueError("batch_pending")
                    expected_targets, expected_denominator = self._resolve_epoch_target_denominator(
                        dependency_keys=receipt.dependency_keys
                    )
                    observed_targets = {
                        (row.packet_ref, row.dependency_key, row.decision_lineage_key)
                        for row in receipt.targets
                    }
                    if observed_targets != expected_targets:
                        raise ValueError("target_denominator_mismatch")
                    if receipt.dependency_denominator_ref != expected_denominator:
                        raise ValueError("dependency_denominator_unresolved")
                    pending = EpochValidityPendingBatch(
                        batch_id=batch_id,
                        transition_artifact_ref=receipt.transition_artifact_ref,
                        transition_content_hash=receipt.transition_content_hash,
                        requested_query_context_ref=receipt.requested_query_context_ref,
                        verifier_provenance_ref=receipt.verifier_provenance_ref,
                        dependency_denominator_ref=receipt.dependency_denominator_ref,
                        adjudication_denominator_ref=receipt.adjudication_denominator_ref,
                        targets=receipt.targets,
                    )
                    # Phase one is the authoritative freeze and precedes every packet write.
                    self._state.save_epoch_pending(pending)
                else:
                    # Resume the exact frozen denominator; later owner-index changes do
                    # not rewrite a batch that was already admitted.
                    self._require_pending_matches_verification(
                        pending=pending,
                        receipt=receipt,
                    )
            else:
                binding = self._state.load_epoch_reconciliation_admission_binding(batch_id)
                if binding is not None:
                    if (
                        reconciliation_reader.verifier_provenance_ref
                        != binding.verifier_provenance_ref
                    ):
                        raise ValueError("epoch_denominator_reconciliation_admission_conflict")
                    persisted_reconciliation = reconciliation_reader.resolve_exact(
                        handle=binding.handle
                    )
                    self._require_binding_matches_reconciliation(
                        binding=binding,
                        persisted=persisted_reconciliation,
                        receipt=receipt,
                        batch_id=batch_id,
                    )
                    if completed is not None:
                        self._require_completed_matches_verification(
                            completed=completed,
                            receipt=receipt,
                        )
                        if pending is not None:
                            self._require_pending_matches_verification(
                                pending=pending,
                                receipt=receipt,
                            )
                            self._state.clear_epoch_pending(batch_id)
                        return completed
                    if pending is None:
                        pending = self._epoch_pending_from_verification(
                            batch_id=batch_id,
                            receipt=receipt,
                        )
                        self._state.save_epoch_pending(pending)
                    else:
                        self._require_pending_matches_verification(
                            pending=pending,
                            receipt=receipt,
                        )
                else:
                    if completed is not None or pending is not None:
                        raise ValueError("epoch_denominator_reconciliation_unavailable")
                    active = self._state.list_epoch_pending()
                    if active:
                        raise ValueError("batch_pending")
                    snapshot = self.persist_epoch_impact_snapshot(
                        dependency_keys=tuple(sorted(receipt.dependency_keys)),
                        requested_query_context_ref=requested_query_context_ref,
                    )
                    observed_targets = {
                        (row.packet_ref, row.dependency_key, row.decision_lineage_key)
                        for row in receipt.targets
                    }
                    snapshot_targets = {
                        (row.packet_ref, row.dependency_key, row.decision_lineage_key)
                        for row in snapshot.snapshot.targets
                    }
                    if observed_targets != snapshot_targets:
                        raise ValueError("target_denominator_mismatch")
                    if (
                        receipt.dependency_denominator_ref
                        != snapshot.snapshot.decision_impact_denominator_ref
                    ):
                        raise ValueError("dependency_denominator_unresolved")
                    persisted_reconciliation = reconciliation_reader.resolve_for_first_admission(
                        transition_artifact_ref=transition_artifact_ref,
                        transition_content_hash=receipt.transition_content_hash,
                        requested_query_context_ref=requested_query_context_ref,
                        authority_purpose="decision_validity_epoch_transition",
                        scientist_snapshot_handle=snapshot.handle,
                    )
                    self._require_reconciliation_matches_verification(
                        persisted=persisted_reconciliation,
                        receipt=receipt,
                        mismatch_code="epoch_denominator_reconciliation_unresolved",
                    )
                    sidecar = persisted_reconciliation.receipt
                    binding = EpochDenominatorReconciliationAdmissionBinding.build(
                        batch_id=batch_id,
                        transition_artifact_ref=receipt.transition_artifact_ref,
                        transition_content_hash=receipt.transition_content_hash,
                        requested_query_context_ref=receipt.requested_query_context_ref,
                        decision_impact_denominator_ref=receipt.dependency_denominator_ref,
                        scientist_snapshot_ref=sidecar.scientist_snapshot_ref,
                        scientist_snapshot_content_hash=(sidecar.scientist_snapshot_content_hash),
                        verifier_provenance_ref=receipt.verifier_provenance_ref,
                        reconciliation_receipt_ref=(
                            persisted_reconciliation.handle.reconciliation_receipt_ref
                        ),
                        reconciliation_receipt_content_hash=(
                            persisted_reconciliation.handle.reconciliation_receipt_content_hash
                        ),
                    )
                    self._state.save_epoch_reconciliation_admission_binding(binding)
                    pending = self._epoch_pending_from_verification(
                        batch_id=batch_id,
                        receipt=receipt,
                    )
                    self._state.save_epoch_pending(pending)

            applied = list(pending.applied_packet_refs)
            targets_by_packet: dict[str, list[EpochValidityBatchTarget]] = {}
            for target in pending.targets:
                targets_by_packet.setdefault(target.packet_ref, []).append(target)
            for packet_ref, packet_targets in targets_by_packet.items():
                if packet_ref in applied:
                    continue
                statuses = [row.status for row in packet_targets]
                status = statuses[0]
                for candidate_status in statuses[1:]:
                    status = _max_status(status, candidate_status)
                reasons = _dedupe_strings([row.reason for row in packet_targets])
                reason = (
                    reasons[0] if len(reasons) == 1 else "epoch_batch_targets:" + "|".join(reasons)
                )
                event = DecisionDependencyEvent(
                    event_id=(f"{batch_id}:{_DecisionValidityStateStore.make_key(packet_ref)}"),
                    dedupe_key=(f"{batch_id}:{_DecisionValidityStateStore.make_key(packet_ref)}"),
                    trigger_type=DecisionTriggerType.HISTORICAL_SEMANTIC_REVISION,
                    status=status,
                    reason=reason,
                    dependency_keys=[row.dependency_key for row in packet_targets],
                    source_ref=str(receipt.transition_artifact_ref.artifact_id),
                    payload={
                        "epoch_batch_id": batch_id,
                        "requested_query_context_ref": requested_query_context_ref,
                        "dependency_denominator_ref": receipt.dependency_denominator_ref,
                        "adjudication_denominator_ref": receipt.adjudication_denominator_ref,
                        "target_dispositions": [
                            row.model_dump(mode="json") for row in packet_targets
                        ],
                    },
                )
                self._apply_event_to_packet(packet_ref=packet_ref, event=event)
                applied.append(packet_ref)
                pending = pending.model_copy(update={"applied_packet_refs": tuple(applied)})
                self._state.save_epoch_pending(pending)

            affected_packet_refs = tuple(dict.fromkeys(row.packet_ref for row in pending.targets))
            completion = EpochValidityBatchCompletionStatement(
                batch_id=batch_id,
                transition_artifact_ref=receipt.transition_artifact_ref,
                transition_content_hash=receipt.transition_content_hash,
                requested_query_context_ref=receipt.requested_query_context_ref,
                dependency_denominator_ref=receipt.dependency_denominator_ref,
                adjudication_denominator_ref=receipt.adjudication_denominator_ref,
                verifier_provenance_ref=receipt.verifier_provenance_ref,
                affected_packet_refs=affected_packet_refs,
                targets=pending.targets,
                predicate_class="independently_reconciled",
            )
            completion_ref = self._store.put_json(
                completion.model_dump(mode="json"),
                ArtifactWriteOptions(
                    kind="scientist.decision_validity_epoch_batch_completion",
                    media_type="application/json",
                    schema=SchemaInfo(
                        name=("polisyos.decision-validity.epoch-batch-completion.v1"),
                        version="1.0",
                    ),
                    inputs=[
                        InputRef(
                            artifact_id=transition_artifact_ref.artifact_id,
                            role="epoch_transition",
                        )
                    ],
                ),
            )
            result = EpochValidityBatchReceipt(
                batch_id=batch_id,
                transition_artifact_ref=receipt.transition_artifact_ref,
                transition_content_hash=receipt.transition_content_hash,
                requested_query_context_ref=receipt.requested_query_context_ref,
                dependency_denominator_ref=receipt.dependency_denominator_ref,
                adjudication_denominator_ref=receipt.adjudication_denominator_ref,
                verifier_provenance_ref=receipt.verifier_provenance_ref,
                completion_receipt_ref=completion_ref,
                affected_packet_refs=affected_packet_refs,
                targets=pending.targets,
            )
            result_ref = self._store.put_json(
                result.model_dump(mode="json"),
                ArtifactWriteOptions(
                    kind="scientist.decision_validity_epoch_batch_receipt",
                    media_type="application/json",
                    schema=SchemaInfo(
                        name="polisyos.decision-validity.epoch-batch-receipt.v1",
                        version="1.0",
                    ),
                    inputs=[
                        InputRef(
                            artifact_id=transition_artifact_ref.artifact_id,
                            role="epoch_transition",
                        ),
                        InputRef(
                            artifact_id=completion_ref.artifact_id,
                            role="completion_statement",
                        ),
                    ],
                ),
            )
            result_raw = self._store.get_bytes(result_ref)
            result_hash = "sha256:" + hashlib.sha256(result_raw).hexdigest()
            self._state.save_epoch_receipt(
                result,
                receipt_artifact_ref=result_ref,
                receipt_content_hash=result_hash,
            )
            self._state.clear_epoch_pending(batch_id)
            return result

    @staticmethod
    def _require_pending_matches_verification(
        *,
        pending: EpochValidityPendingBatch,
        receipt: EpochTransitionVerificationReceipt,
    ) -> None:
        expected = (
            receipt.transition_artifact_ref,
            receipt.transition_content_hash,
            receipt.requested_query_context_ref,
            receipt.verifier_provenance_ref,
            receipt.dependency_denominator_ref,
            receipt.adjudication_denominator_ref,
            receipt.targets,
        )
        observed = (
            pending.transition_artifact_ref,
            pending.transition_content_hash,
            pending.requested_query_context_ref,
            pending.verifier_provenance_ref,
            pending.dependency_denominator_ref,
            pending.adjudication_denominator_ref,
            pending.targets,
        )
        if observed != expected:
            raise ValueError("epoch_pending_verification_binding_mismatch")

    @staticmethod
    def _require_completed_matches_verification(
        *,
        completed: EpochValidityBatchReceipt,
        receipt: EpochTransitionVerificationReceipt,
    ) -> None:
        expected_packets = tuple(dict.fromkeys(row.packet_ref for row in receipt.targets))
        if (
            completed.transition_artifact_ref != receipt.transition_artifact_ref
            or completed.transition_content_hash != receipt.transition_content_hash
            or completed.requested_query_context_ref != receipt.requested_query_context_ref
            or completed.dependency_denominator_ref != receipt.dependency_denominator_ref
            or completed.adjudication_denominator_ref != receipt.adjudication_denominator_ref
            or completed.verifier_provenance_ref != receipt.verifier_provenance_ref
            or completed.affected_packet_refs != expected_packets
            or completed.targets != receipt.targets
        ):
            raise ValueError("epoch_completed_verification_binding_mismatch")

    def _load_completed_epoch_receipt(self, batch_id: str) -> EpochValidityBatchReceipt | None:
        evidence = self._state.load_epoch_receipt_evidence(batch_id)
        if evidence is None:
            return None
        try:
            report = self._store.verify(evidence.receipt_artifact_ref)
            raw = self._store.get_bytes(evidence.receipt_artifact_ref)
            parsed = EpochValidityBatchReceipt.model_validate(
                read_core_json_artifact(
                    self._store,
                    evidence.receipt_artifact_ref,
                    raw_payload_bytes=raw,
                ).value
            )
            completion_report = self._store.verify(parsed.completion_receipt_ref)
            completion_raw = self._store.get_bytes(parsed.completion_receipt_ref)
            completion = EpochValidityBatchCompletionStatement.model_validate(
                read_core_json_artifact(
                    self._store,
                    parsed.completion_receipt_ref,
                    raw_payload_bytes=completion_raw,
                ).value
            )
            transition_report = self._store.verify(parsed.transition_artifact_ref)
            transition_raw = self._store.get_bytes(parsed.transition_artifact_ref)
        except _DECISION_VALIDITY_ARTIFACT_LOAD_ERRORS as exc:
            raise RuntimeError("decision_validity_epoch_receipt_unresolved") from exc
        observed_hash = "sha256:" + hashlib.sha256(raw).hexdigest()
        observed_transition_hash = "sha256:" + hashlib.sha256(transition_raw).hexdigest()
        if (
            not report.ok
            or not completion_report.ok
            or not transition_report.ok
            or observed_hash != evidence.receipt_content_hash
            or observed_transition_hash != parsed.transition_content_hash
            or parsed != evidence.receipt
            or completion.batch_id != parsed.batch_id
            or completion.transition_artifact_ref != parsed.transition_artifact_ref
            or completion.transition_content_hash != parsed.transition_content_hash
            or completion.requested_query_context_ref != parsed.requested_query_context_ref
            or completion.dependency_denominator_ref != parsed.dependency_denominator_ref
            or completion.adjudication_denominator_ref != parsed.adjudication_denominator_ref
            or completion.verifier_provenance_ref != parsed.verifier_provenance_ref
            or completion.affected_packet_refs != parsed.affected_packet_refs
            or completion.targets != parsed.targets
        ):
            raise RuntimeError("decision_validity_epoch_receipt_unresolved")
        return parsed

    def resolve_completed_epoch_batch_evidence(
        self,
        *,
        batch_receipt_ref: ArtifactRef,
    ) -> PersistedEpochValidityBatchEvidence:
        """Resolve exact completed bytes by ref for the Claim owner bridge."""

        for item in sorted(self._state._epoch_receipts.glob("*.json")):
            state = self._state._load_model_strict(
                item,
                _PersistedEpochBatchReceiptState,
            )
            if state is None or state.receipt_artifact_ref != batch_receipt_ref:
                continue
            parsed = self._load_completed_epoch_receipt(state.receipt.batch_id)
            if parsed is None:
                break
            raw = self._store.get_bytes(batch_receipt_ref)
            return PersistedEpochValidityBatchEvidence(
                batch_receipt_ref=batch_receipt_ref,
                batch_receipt_content_hash=state.receipt_content_hash,
                receipt_bytes=raw,
                receipt=parsed,
            )
        raise ValueError("decision_validity_epoch_receipt_unresolved")

    def resolve_completed_epoch_batch_evidence_by_id(
        self,
        *,
        batch_id: str,
    ) -> PersistedEpochValidityBatchEvidence:
        """Resolve the exact artifact handle produced for one admitted batch."""

        state = self._state.load_epoch_receipt_evidence(batch_id)
        if state is None:
            raise ValueError("decision_validity_epoch_receipt_unresolved")
        return self.resolve_completed_epoch_batch_evidence(
            batch_receipt_ref=state.receipt_artifact_ref
        )

    @_owner_transactional
    def enumerate_completed_epoch_batch_evidence(
        self,
    ) -> tuple[PersistedEpochValidityBatchEvidence, ...]:
        """Walk the complete owner receipt index under its transaction lock."""

        evidence: list[PersistedEpochValidityBatchEvidence] = []
        for item in sorted(self._state._epoch_receipts.glob("*.json")):
            state = self._state._load_model_strict(
                item,
                _PersistedEpochBatchReceiptState,
            )
            if state is None:
                raise ValueError("decision_validity_epoch_receipt_index_unresolved")
            parsed = self._load_completed_epoch_receipt(state.receipt.batch_id)
            if parsed is None or parsed != state.receipt:
                raise ValueError("decision_validity_epoch_receipt_index_unresolved")
            raw = self._store.get_bytes(state.receipt_artifact_ref)
            evidence.append(
                PersistedEpochValidityBatchEvidence(
                    batch_receipt_ref=state.receipt_artifact_ref,
                    batch_receipt_content_hash=state.receipt_content_hash,
                    receipt_bytes=raw,
                    receipt=parsed,
                )
            )
        return tuple(evidence)

    def _validate_epoch_transition_receipt(
        self,
        *,
        receipt: EpochTransitionVerificationReceipt,
        transition_artifact_ref: ArtifactRef,
        requested_query_context_ref: str,
    ) -> None:
        if receipt.predicate_class != "independently_reconciled":
            raise ValueError("verifier_provenance_untrusted")
        expected_provenance = getattr(
            self._epoch_transition_verifier,
            "verifier_provenance_ref",
            None,
        )
        if expected_provenance is None or receipt.verifier_provenance_ref != expected_provenance:
            raise ValueError("verifier_provenance_untrusted")
        try:
            self._store.get_bytes(expected_provenance)
            provenance_report = self._store.verify(expected_provenance)
            provenance_manifest = self._store.get_manifest(expected_provenance)
        except (KeyError, OSError, RuntimeError, TypeError, ValueError) as exc:
            raise ValueError("verifier_provenance_untrusted") from exc
        if (
            not provenance_report.ok
            or expected_provenance.kind != "chronology.epoch_transition_verifier"
            or provenance_manifest.kind != "chronology.epoch_transition_verifier"
        ):
            raise ValueError("verifier_provenance_untrusted")
        if receipt.transition_artifact_ref != transition_artifact_ref:
            raise ValueError("ref_unresolved")
        if receipt.requested_query_context_ref != requested_query_context_ref:
            raise ValueError("query_context_mismatch")
        if receipt.authority_purpose != "decision_validity_epoch_transition":
            raise ValueError("authority_purpose_mismatch")
        try:
            raw = self._store.get_bytes(transition_artifact_ref)
            report = self._store.verify(transition_artifact_ref)
        except (KeyError, OSError, RuntimeError, TypeError, ValueError) as exc:
            raise ValueError("ref_unresolved") from exc
        observed_hash = "sha256:" + hashlib.sha256(raw).hexdigest()
        if not report.ok or receipt.transition_content_hash != observed_hash:
            raise ValueError("content_hash_mismatch")

    def _resolve_epoch_impact_projection(
        self,
        *,
        dependency_keys: tuple[str, ...],
    ) -> _EpochImpactProjection:
        """Walk the nullable owner projection once without strengthening legacy behavior."""

        rows: list[dict[str, object]] = []
        targets: set[tuple[str, str, str]] = set()
        for key in sorted(dependency_keys):
            owner = self._state.load_dependency(key)
            if owner is None or owner.dependency_kind != DecisionDependencyKind.SEMANTIC_EPOCH:
                raise ValueError("dependency_denominator_unresolved")
            rows.append(
                {
                    "dependency_key": owner.dependency_key,
                    "dependency_kind": owner.dependency_kind.value,
                    "artifact_id": owner.artifact_id,
                    "packet_refs": sorted(owner.packet_refs),
                    "lineage_keys": sorted(owner.lineage_keys),
                }
            )
            for packet_ref in owner.packet_refs:
                packet = self._state.load_packet(packet_ref)
                if packet is None:
                    raise ValueError("dependency_denominator_unresolved")
                targets.add((packet_ref, key, packet.decision_lineage_key))
        raw = json.dumps(rows, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return _EpochImpactProjection(
            owner_rows=tuple(rows),
            targets=tuple(sorted(targets, key=lambda row: (row[1], row[0], row[2]))),
            decision_impact_denominator_ref="sha256:" + hashlib.sha256(raw).hexdigest(),
        )

    def _resolve_epoch_target_denominator(
        self,
        *,
        dependency_keys: tuple[str, ...],
    ) -> tuple[set[tuple[str, str, str]], str]:
        projection = self._resolve_epoch_impact_projection(dependency_keys=dependency_keys)
        return set(projection.targets), projection.decision_impact_denominator_ref

    @_owner_transactional
    def resolve_epoch_admitted_impact_snapshot(
        self,
        *,
        transition_artifact_ref: ArtifactRef,
        requested_query_context_ref: str,
    ) -> PersistedDecisionValidityEpochImpactSnapshot | None:
        """Read the frozen first-admission basis before verifying a replay.

        A completed or pending strict batch without its owner binding is corrupt
        admission evidence, not an invitation to rescan the live dependency set.
        """

        batch_id = _epoch_batch_id(
            transition_artifact_ref=transition_artifact_ref,
            requested_query_context_ref=requested_query_context_ref,
        )
        binding = self._state.load_epoch_reconciliation_admission_binding(batch_id)
        if binding is None:
            if (
                self._state.load_epoch_pending(batch_id) is not None
                or self._state.load_epoch_receipt(batch_id) is not None
            ):
                raise ValueError("epoch_denominator_reconciliation_unavailable")
            return None
        if (
            binding.transition_artifact_ref != transition_artifact_ref
            or binding.requested_query_context_ref != requested_query_context_ref
        ):
            raise ValueError("epoch_denominator_reconciliation_admission_conflict")
        return self.resolve_epoch_impact_snapshot(
            handle=DecisionValidityEpochImpactSnapshotHandle(
                snapshot_ref=binding.scientist_snapshot_ref,
                snapshot_content_hash=binding.scientist_snapshot_content_hash,
            )
        )

    @_owner_transactional
    def persist_epoch_impact_snapshot_for_targets(
        self,
        *,
        target_refs: tuple[ArtifactRef, ...],
        requested_query_context_ref: str,
    ) -> PersistedDecisionValidityEpochImpactSnapshot:
        """Freeze all owner dependencies of exact Runtime targets.

        The caller selects artifacts, never dependency keys. Both complete local
        owner indexes are read under the registration lock and reconciled before
        selection; an unreadable or missing member cannot become zero impact.
        """

        target_ids: set[str] = set()
        try:
            for ref in target_refs:
                raw = self._store.get_bytes(ref)
                manifest = self._store.get_manifest(ref)
                if (
                    not self._store.verify(ref).ok
                    or manifest.artifact_id != ref.artifact_id
                    or manifest.kind != ref.kind
                    or manifest.media_type != ref.media_type
                    or "sha256:" + hashlib.sha256(raw).hexdigest() != str(ref.artifact_id)
                ):
                    raise ValueError("target profile mismatch")
                target_ids.add(str(ref.artifact_id))
        except (KeyError, OSError, RuntimeError, TypeError, ValueError) as exc:
            raise ValueError("dependency_denominator_unresolved") from exc

        try:
            owners: dict[str, _DecisionDependencyIndex] = {}
            for path in sorted(self._state._dependencies.glob("*.json")):
                owner = self._state._load_model_strict(path, _DecisionDependencyIndex)
                if (
                    owner is None
                    or path != self._state._dependency_path(owner.dependency_key)
                    or owner.dependency_key in owners
                ):
                    raise ValueError("dependency index address mismatch")
                owners[owner.dependency_key] = owner
            packets: dict[str, _DecisionPacketState] = {}
            for path in sorted(self._state._packets.glob("*.json")):
                packet = self._state._load_model_strict(path, _DecisionPacketState)
                if (
                    packet is None
                    or path != self._state._packet_path(packet.packet_ref)
                    or packet.packet_ref in packets
                ):
                    raise ValueError("packet index address mismatch")
                packets[packet.packet_ref] = packet
            # The existing index is shared owner state. A matching dependency
            # artifact cannot grant access to a different tenant's packet. Read
            # every indexed packet before selection; never drop an inaccessible
            # member and call the remaining inventory complete.
            for packet in packets.values():
                packet_id = ArtifactID.model_validate(packet.packet_ref)
                packet_raw = self._store.get_bytes(packet_id)
                packet_manifest = self._store.get_manifest(packet_id)
                if (
                    not self._store.verify(packet_id).ok
                    or packet_manifest.artifact_id != packet_id
                    or packet_manifest.kind != "scientist.decision_packet"
                    or packet_manifest.media_type != "application/json"
                    or "sha256:" + hashlib.sha256(packet_raw).hexdigest() != str(packet_id)
                ):
                    raise ValueError("packet artifact profile mismatch")
            expected_packets: dict[str, set[str]] = {key: set() for key in owners}
            expected_lineages: dict[str, set[str]] = {key: set() for key in owners}
            for packet in packets.values():
                for key in packet.dependency_keys:
                    if key not in owners:
                        raise ValueError("packet dependency index missing")
                    expected_packets[key].add(packet.packet_ref)
                    expected_lineages[key].add(packet.decision_lineage_key)
            for key, owner in owners.items():
                if (
                    set(owner.packet_refs) != expected_packets[key]
                    or set(owner.lineage_keys) != expected_lineages[key]
                    or len(owner.packet_refs) != len(set(owner.packet_refs))
                    or len(owner.lineage_keys) != len(set(owner.lineage_keys))
                ):
                    raise ValueError("owner indexes do not reconcile")
        except (KeyError, OSError, RuntimeError, TypeError, ValueError) as exc:
            raise RuntimeError("decision_validity_owner_state_corrupt") from exc
        return self.persist_epoch_impact_snapshot(
            dependency_keys=tuple(
                sorted(
                    key
                    for key, owner in owners.items()
                    if owner.dependency_kind == DecisionDependencyKind.SEMANTIC_EPOCH
                    and owner.artifact_id in target_ids
                )
            ),
            requested_query_context_ref=requested_query_context_ref,
        )

    @_owner_transactional
    def persist_epoch_impact_snapshot(
        self,
        *,
        dependency_keys: tuple[str, ...],
        requested_query_context_ref: str,
    ) -> PersistedDecisionValidityEpochImpactSnapshot:
        """Persist the exact strict Scientist projection for a reconciliation candidate."""

        projection = self._resolve_epoch_impact_projection(dependency_keys=dependency_keys)
        strict_rows: list[DecisionValidityEpochImpactOwnerRow] = []
        try:
            for row in projection.owner_rows:
                artifact_id = row["artifact_id"]
                if not isinstance(artifact_id, str):
                    raise ValueError("owner artifact id is null")
                ArtifactID.model_validate(artifact_id)
                strict_rows.append(DecisionValidityEpochImpactOwnerRow.model_validate(row))
        except (TypeError, ValueError, ValidationError) as exc:
            raise ValueError("epoch_impact_snapshot_artifact_id_unresolved") from exc
        snapshot = DecisionValidityEpochImpactSnapshot.build(
            requested_query_context_ref=requested_query_context_ref,
            requested_dependency_keys=dependency_keys,
            owner_rows=tuple(strict_rows),
            targets=tuple(
                DecisionValidityEpochImpactTarget(
                    packet_ref=packet_ref,
                    dependency_key=dependency_key,
                    decision_lineage_key=lineage_key,
                )
                for packet_ref, dependency_key, lineage_key in projection.targets
            ),
        )
        if snapshot.decision_impact_denominator_ref != projection.decision_impact_denominator_ref:
            raise RuntimeError("decision_validity_epoch_impact_snapshot_unresolved")
        snapshot_bytes = to_canonical_bytes(
            snapshot.model_dump(mode="json"),
            _EPOCH_IMPACT_SNAPSHOT_CANON,
        )
        snapshot_ref = self._store.put_bytes(
            snapshot_bytes,
            ArtifactWriteOptions(
                kind=_EPOCH_IMPACT_SNAPSHOT_KIND,
                media_type=_EPOCH_IMPACT_SNAPSHOT_MEDIA_TYPE,
                schema=SchemaInfo(name=_EPOCH_IMPACT_SNAPSHOT_SCHEMA, version="1.0"),
                canon=CanonInfo.from_spec(_EPOCH_IMPACT_SNAPSHOT_CANON),
            ),
        )
        return self.resolve_epoch_impact_snapshot(
            handle=DecisionValidityEpochImpactSnapshotHandle(
                snapshot_ref=snapshot_ref,
                snapshot_content_hash=snapshot.snapshot_content_hash,
            )
        )

    def resolve_epoch_impact_snapshot(
        self,
        *,
        handle: DecisionValidityEpochImpactSnapshotHandle,
    ) -> PersistedDecisionValidityEpochImpactSnapshot:
        """Resolve one snapshot with exact CAS, manifest, canonical-byte, and model checks."""

        try:
            snapshot_ref = handle.snapshot_ref
            if (
                snapshot_ref.kind != _EPOCH_IMPACT_SNAPSHOT_KIND
                or snapshot_ref.media_type != _EPOCH_IMPACT_SNAPSHOT_MEDIA_TYPE
            ):
                raise ValueError("snapshot ref profile mismatch")
            report = self._store.verify(snapshot_ref)
            manifest = self._store.get_manifest(snapshot_ref)
            snapshot_bytes = self._store.get_bytes(snapshot_ref)
            if (
                not report.ok
                or str(manifest.artifact_id) != str(snapshot_ref.artifact_id)
                or manifest.kind != _EPOCH_IMPACT_SNAPSHOT_KIND
                or manifest.media_type != _EPOCH_IMPACT_SNAPSHOT_MEDIA_TYPE
                or manifest.artifact_schema
                != SchemaInfo(name=_EPOCH_IMPACT_SNAPSHOT_SCHEMA, version="1.0")
                or manifest.canon != CanonInfo.from_spec(_EPOCH_IMPACT_SNAPSHOT_CANON)
                or "sha256:" + hashlib.sha256(snapshot_bytes).hexdigest()
                != str(snapshot_ref.artifact_id)
            ):
                raise ValueError("snapshot manifest mismatch")
            snapshot = DecisionValidityEpochImpactSnapshot.model_validate(
                read_core_json_artifact(
                    self._store,
                    snapshot_ref,
                    raw_payload_bytes=snapshot_bytes,
                ).value
            )
            if (
                to_canonical_bytes(
                    snapshot.model_dump(mode="json"),
                    _EPOCH_IMPACT_SNAPSHOT_CANON,
                )
                != snapshot_bytes
                or handle.snapshot_content_hash != snapshot.snapshot_content_hash
            ):
                raise ValueError("snapshot bytes mismatch")
            return PersistedDecisionValidityEpochImpactSnapshot(
                handle=handle,
                snapshot_bytes=snapshot_bytes,
                snapshot=snapshot,
            )
        except KeyError as exc:
            raise RuntimeError("decision_validity_epoch_impact_snapshot_unresolved") from exc
        except _DECISION_VALIDITY_ARTIFACT_LOAD_ERRORS as exc:
            raise RuntimeError("decision_validity_epoch_impact_snapshot_unresolved") from exc

    @_owner_transactional
    def register_decision_packet(
        self,
        *,
        packet_ref: str,
        envelope: DecisionValidityEnvelope,
        baseline: DecisionValidityEvaluation,
        monitoring_contract_ref: str | None = None,
    ) -> DecisionValidityEvaluation:
        dependency_keys = envelope.dependency_keys()
        head = self._state.load_lineage(envelope.decision_lineage_key)
        supersedes_ref = head.head_packet_ref if head is not None else None

        evaluation = baseline.model_copy(
            update={
                "decision_packet_ref": packet_ref,
                "decision_lineage_key": envelope.decision_lineage_key,
                "dependency_keys": dependency_keys,
                "evaluated_at": utc_now(),
                "supersedes_decision_ref": supersedes_ref,
                "superseded_by_ref": None,
            }
        )
        persisted = self._persist_evaluation(
            packet_ref=packet_ref,
            evaluation=evaluation,
            sticky_triggers=[],
            monitoring_contract_ref=monitoring_contract_ref,
        )
        self._register_dependencies(
            packet_ref=packet_ref,
            decision_lineage_key=envelope.decision_lineage_key,
            dependencies=tuple(
                dependency
                for section in (
                    envelope.normative_basis,
                    envelope.data_basis,
                    envelope.knowledge_basis,
                    envelope.transportability_basis,
                )
                for dependency in section.dependencies
            ),
        )
        packet_state = self._state.load_packet(packet_ref)
        self._state.save_lineage(
            _DecisionLineageState(
                decision_lineage_key=envelope.decision_lineage_key,
                head_packet_ref=packet_ref,
                evaluation_ref=packet_state.evaluation_ref if packet_state is not None else None,
                updated_at=utc_now(),
            )
        )
        if supersedes_ref and supersedes_ref != packet_ref:
            self._mark_superseded(
                packet_ref=supersedes_ref,
                superseded_by_ref=packet_ref,
                lineage_key=envelope.decision_lineage_key,
            )
        if monitoring_contract_ref:
            self._schedule_monitoring_job(
                packet_ref=packet_ref,
                decision_lineage_key=envelope.decision_lineage_key,
                monitoring_contract_ref=monitoring_contract_ref,
            )
        return persisted

    @_owner_transactional
    def ensure_evaluation(
        self,
        packet_ref: str,
        *,
        packet_payload: dict[str, Any] | None = None,
        force: bool = False,
    ) -> DecisionValidityEvaluation:
        current_state = self._state.load_packet(packet_ref)
        if (
            not force
            and current_state is not None
            and current_state.evaluation_ref
            and current_state.last_checked_at is not None
        ):
            age = utc_now() - current_state.last_checked_at
            if age <= timedelta(seconds=self._ttl):
                loaded = self._load_evaluation(current_state.evaluation_ref)
                if loaded is not None:
                    return self._overlay_epoch_pending(loaded)

        payload = (
            packet_payload if packet_payload is not None else self._load_packet_payload(packet_ref)
        )
        evaluation = self._compute_evaluation(
            packet_ref=packet_ref,
            packet_payload=payload,
            current_state=current_state,
        )
        persisted = self._persist_evaluation(
            packet_ref=packet_ref,
            evaluation=evaluation,
            sticky_triggers=list(current_state.sticky_triggers) if current_state else [],
        )
        return self._overlay_epoch_pending(persisted)

    def read_current_projection(self, packet_ref: str) -> DecisionValidityEvaluation:
        """Read current owner state plus a restart-safe pending-batch overlay."""

        state = self._state.load_packet(packet_ref)
        if state is not None and state.evaluation_ref is not None:
            loaded = self._load_evaluation(state.evaluation_ref)
            if loaded is not None:
                return self._overlay_epoch_pending(loaded)
        return self.ensure_evaluation(packet_ref)

    def _overlay_epoch_pending(
        self,
        evaluation: DecisionValidityEvaluation,
    ) -> DecisionValidityEvaluation:
        pending = tuple(
            batch
            for batch in self._state.list_epoch_pending()
            if any(target.packet_ref == evaluation.decision_packet_ref for target in batch.targets)
        )
        if not pending:
            return evaluation
        status = _max_status(evaluation.status, DecisionValidityStatus.STALE)
        reasons = _dedupe_strings(
            [
                *evaluation.reasons,
                *(f"epoch_validity_batch_pending:{batch.batch_id}" for batch in pending),
            ]
        )
        return evaluation.model_copy(
            update={
                "status": status,
                "reasons": reasons,
                "review_required": _is_review_required_status(status),
                "recommended_action": _recommended_action(status),
            }
        )

    def get_evaluation(
        self,
        packet_ref: str,
        *,
        packet_payload: dict[str, Any] | None = None,
        force: bool = False,
    ) -> tuple[DecisionValidityEvaluation, str | None]:
        evaluation = self.ensure_evaluation(
            packet_ref,
            packet_payload=packet_payload,
            force=force,
        )
        state = self._state.load_packet(packet_ref)
        return evaluation, (state.evaluation_ref if state is not None else None)

    def get_summary(
        self,
        packet_ref: str,
        *,
        packet_payload: dict[str, Any] | None = None,
        force: bool = False,
    ) -> dict[str, Any]:
        evaluation, evaluation_ref = self.get_evaluation(
            packet_ref,
            packet_payload=packet_payload,
            force=force,
        )
        return {
            "status": evaluation.status.value,
            "lifecycle_status": evaluation.status.value,
            "checked_at": evaluation.evaluated_at.isoformat(),
            "reasons": list(evaluation.reasons),
            "triggers": [item.model_dump(mode="json") for item in evaluation.triggers],
            "review_required": bool(evaluation.review_required),
            "supersedes_decision_ref": (
                {"artifact_id": evaluation.supersedes_decision_ref}
                if evaluation.supersedes_decision_ref
                else None
            ),
            "superseded_by_ref": (
                {"artifact_id": evaluation.superseded_by_ref}
                if evaluation.superseded_by_ref
                else None
            ),
            "evaluation_ref": {"artifact_id": evaluation_ref} if evaluation_ref else None,
            "decision_lineage_key": evaluation.decision_lineage_key,
            "recommended_action": evaluation.recommended_action,
            "lifecycle": self._lifecycle_summary(packet_ref),
        }

    def mark_dependency_trigger(
        self,
        *,
        dependency_key: str,
        trigger: DecisionTriggerRecord,
    ) -> list[DecisionValidityEvaluation]:
        event = DecisionDependencyEvent(
            event_id=uuid.uuid4().hex,
            dedupe_key=_build_event_dedupe_key(
                trigger=trigger,
                dependency_keys=[dependency_key],
            ),
            trigger_type=trigger.trigger_type,
            status=trigger.status,
            reason=trigger.reason,
            dependency_keys=[dependency_key],
            source_ref=trigger.source_ref,
            payload=dict(trigger.details),
        )
        return self.record_dependency_event(event=event)

    @_owner_transactional
    def record_dependency_event(
        self,
        *,
        event: DecisionDependencyEvent,
    ) -> list[DecisionValidityEvaluation]:
        owner_rows = tuple(self._state.load_dependency(key) for key in event.dependency_keys)
        if any(
            row is not None and row.dependency_kind == DecisionDependencyKind.SEMANTIC_EPOCH
            for row in owner_rows
        ):
            raise ValueError("semantic_epoch_dependency_requires_owner_batch")
        if self._state.load_dedupe_event_id(event.dedupe_key):
            cached_evaluations: list[DecisionValidityEvaluation] = []
            for dependency_key in event.dependency_keys:
                dependency = self._state.load_dependency(dependency_key)
                if dependency is None:
                    continue
                for packet_ref in dependency.packet_refs:
                    cached_evaluations.append(self.ensure_evaluation(packet_ref))
            return cached_evaluations

        self._state.save_dedupe_event_id(event.dedupe_key, event.event_id)
        if event.trigger_type == DecisionTriggerType.CONTEXT_PROFILE_DRIFT:
            get_operational_monitor().record_alert(
                alert_type="drift",
                severity="warn",
                details={
                    "dependency_keys": list(event.dependency_keys),
                    "event_id": event.event_id,
                },
            )
        packet_refs: list[str] = []
        for dependency_key in event.dependency_keys:
            dependency = self._state.load_dependency(dependency_key)
            if dependency is None:
                continue
            for packet_ref in dependency.packet_refs:
                if packet_ref not in packet_refs:
                    packet_refs.append(packet_ref)
        evaluations: list[DecisionValidityEvaluation] = []
        for packet_ref in packet_refs:
            evaluations.append(self._apply_event_to_packet(packet_ref=packet_ref, event=event))
        return evaluations

    @_owner_transactional
    def mark_packet_trigger(
        self,
        *,
        packet_ref: str,
        trigger: DecisionTriggerRecord,
    ) -> DecisionValidityEvaluation:
        state = self._state.load_packet(packet_ref)
        dependency_keys = (
            [trigger.dependency_key]
            if trigger.dependency_key
            else list(state.dependency_keys)
            if state is not None
            else []
        )
        event = DecisionDependencyEvent(
            event_id=uuid.uuid4().hex,
            dedupe_key=_build_event_dedupe_key(
                trigger=trigger,
                dependency_keys=dependency_keys,
                packet_ref=packet_ref,
            ),
            trigger_type=trigger.trigger_type,
            status=trigger.status,
            reason=trigger.reason,
            dependency_keys=dependency_keys,
            source_ref=trigger.source_ref,
            payload=dict(trigger.details),
        )
        if self._state.load_dedupe_event_id(event.dedupe_key):
            return self.ensure_evaluation(packet_ref)
        self._state.save_dedupe_event_id(event.dedupe_key, event.event_id)
        return self._apply_event_to_packet(packet_ref=packet_ref, event=event)

    @_owner_transactional
    def backfill_packet(self, packet_ref: str) -> DecisionValidityEvaluation:
        payload = self._load_packet_payload(packet_ref)
        evaluation = self.ensure_evaluation(packet_ref, packet_payload=payload, force=True)
        if _load_envelope(payload) is None:
            trigger = DecisionTriggerRecord(
                trigger_type=DecisionTriggerType.LEGACY_PACKET,
                status=DecisionValidityStatus.WARNING,
                reason="legacy_packet_missing_validity_envelope",
            )
            evaluation = self.mark_packet_trigger(packet_ref=packet_ref, trigger=trigger)
        return evaluation

    def _apply_event_to_packet(
        self,
        *,
        packet_ref: str,
        event: DecisionDependencyEvent,
    ) -> DecisionValidityEvaluation:
        state = self._state.load_packet(packet_ref)
        if state is None:
            self.ensure_evaluation(packet_ref)
            state = self._state.load_packet(packet_ref)
        if state is None:
            payload = self._load_packet_payload(packet_ref)
            envelope = _load_envelope(payload)
            lineage_key = envelope.decision_lineage_key if envelope is not None else packet_ref
            dependency_keys = envelope.dependency_keys() if envelope is not None else []
            state = _DecisionPacketState(
                packet_ref=packet_ref,
                decision_lineage_key=lineage_key,
                dependency_keys=dependency_keys,
            )
        previous_status = state.current_status
        previous_evaluation_ref = state.evaluation_ref
        sticky = list(state.sticky_triggers if state is not None else [])
        triggers = _trigger_records_from_event(event)
        sticky = _dedupe_trigger_records([*sticky, *triggers])
        lifecycle_events = _dedupe_events([*state.lifecycle_events, event])
        lifecycle_jobs = list(state.lifecycle_jobs)
        job_key = hashlib.sha256(
            f"{packet_ref}\0{event.event_id}\0evaluation".encode()
        ).hexdigest()[:24]
        lifecycle_jobs.append(
            DecisionLifecycleJob(
                job_id=f"decision_eval_{job_key}",
                job_kind="evaluation",
                packet_ref=packet_ref,
                decision_lineage_key=state.decision_lineage_key,
                state="completed",
                reason=event.reason,
                scheduled_for=event.occurred_at,
                trigger_event_id=event.event_id,
                completed_at=utc_now(),
                payload={"dependency_keys": list(event.dependency_keys)},
            )
        )
        state = state.model_copy(
            update={
                "sticky_triggers": sticky,
                "lifecycle_events": lifecycle_events,
                "lifecycle_jobs": _dedupe_jobs(lifecycle_jobs),
            }
        )
        self._state.save_packet(state)
        evaluation = self.ensure_evaluation(packet_ref, force=True)
        refreshed_state = self._state.load_packet(packet_ref)
        self._record_transition(
            packet_ref=packet_ref,
            decision_lineage_key=evaluation.decision_lineage_key,
            previous_status=previous_status,
            current_status=evaluation.status,
            reason=event.reason,
            event_id=event.event_id,
            review_required=evaluation.review_required,
            evaluation_ref=(
                refreshed_state.evaluation_ref
                if refreshed_state is not None
                else previous_evaluation_ref
            ),
        )
        return evaluation

    def _mark_superseded(
        self,
        *,
        packet_ref: str,
        superseded_by_ref: str,
        lineage_key: str,
    ) -> DecisionValidityEvaluation:
        current = self.ensure_evaluation(packet_ref)
        trigger = DecisionTriggerRecord(
            trigger_type=DecisionTriggerType.SUPERSEDED,
            status=DecisionValidityStatus.SUPERSEDED,
            reason=f"superseded_by:{superseded_by_ref}",
            source_ref=superseded_by_ref,
            details={"superseded_by_ref": superseded_by_ref},
        )
        updated = current.model_copy(
            update={
                "status": DecisionValidityStatus.SUPERSEDED,
                "evaluated_at": utc_now(),
                "reasons": _dedupe_strings([*current.reasons, trigger.reason]),
                "triggers": _dedupe_trigger_records([*current.triggers, trigger]),
                "review_required": False,
                "recommended_action": _recommended_action(DecisionValidityStatus.SUPERSEDED),
                "superseded_by_ref": superseded_by_ref,
                "decision_lineage_key": lineage_key,
            }
        )
        state = self._state.load_packet(packet_ref)
        sticky = list(state.sticky_triggers) if state is not None else []
        return self._persist_evaluation(
            packet_ref=packet_ref,
            evaluation=updated,
            sticky_triggers=sticky,
        )

    def _persist_evaluation(
        self,
        *,
        packet_ref: str,
        evaluation: DecisionValidityEvaluation,
        sticky_triggers: list[DecisionTriggerRecord],
        monitoring_contract_ref: str | None = None,
    ) -> DecisionValidityEvaluation:
        packet_artifact_id = ArtifactID.model_validate(packet_ref)
        evaluation_ref = self._store.put_json(
            evaluation.model_dump(mode="json"),
            ArtifactWriteOptions(
                kind="scientist.decision_validity_evaluation",
                media_type="application/json",
                schema=SchemaInfo(
                    name="polisyos.scientist.DecisionValidityEvaluation",
                    version="1.0",
                ),
                inputs=[InputRef(artifact_id=packet_artifact_id, role="decision_packet")],
            ),
        )
        state = self._state.load_packet(packet_ref)
        dependency_keys = list(evaluation.dependency_keys)
        if state is not None and not dependency_keys:
            dependency_keys = list(state.dependency_keys)
        packet_state = _DecisionPacketState(
            packet_ref=packet_ref,
            decision_lineage_key=evaluation.decision_lineage_key,
            current_status=evaluation.status,
            last_checked_at=evaluation.evaluated_at,
            evaluation_ref=str(evaluation_ref.artifact_id),
            reasons=list(evaluation.reasons),
            active_triggers=list(evaluation.triggers),
            sticky_triggers=sticky_triggers,
            dependency_keys=dependency_keys,
            review_required=evaluation.review_required,
            supersedes_decision_ref=evaluation.supersedes_decision_ref,
            superseded_by_ref=evaluation.superseded_by_ref,
            monitoring_contract_ref=(
                monitoring_contract_ref
                if monitoring_contract_ref is not None
                else (state.monitoring_contract_ref if state is not None else None)
            ),
            latest_monitoring_report_ref=(
                state.latest_monitoring_report_ref if state is not None else None
            ),
            latest_compare_report_ref=(
                state.latest_compare_report_ref if state is not None else None
            ),
            latest_reissue_plan_ref=(state.latest_reissue_plan_ref if state is not None else None),
            lifecycle_events=list(state.lifecycle_events) if state is not None else [],
            transition_history=list(state.transition_history) if state is not None else [],
            lifecycle_jobs=list(state.lifecycle_jobs) if state is not None else [],
            last_transition_at=state.last_transition_at if state is not None else None,
        )
        self._state.save_packet(packet_state)
        return evaluation

    @_owner_transactional
    def update_feedback_refs(
        self,
        packet_ref: str,
        *,
        monitoring_contract_ref: str | None = None,
        monitoring_report_ref: str | None = None,
        compare_report_ref: str | None = None,
        reissue_plan_ref: str | None = None,
    ) -> None:
        state = self._state.load_packet(packet_ref)
        if state is None:
            self.ensure_evaluation(packet_ref)
            state = self._state.load_packet(packet_ref)
        if state is None:
            return
        self._state.save_packet(
            state.model_copy(
                update={
                    "monitoring_contract_ref": (
                        monitoring_contract_ref
                        if monitoring_contract_ref is not None
                        else state.monitoring_contract_ref
                    ),
                    "latest_monitoring_report_ref": (
                        monitoring_report_ref
                        if monitoring_report_ref is not None
                        else state.latest_monitoring_report_ref
                    ),
                    "latest_compare_report_ref": (
                        compare_report_ref
                        if compare_report_ref is not None
                        else state.latest_compare_report_ref
                    ),
                    "latest_reissue_plan_ref": (
                        reissue_plan_ref
                        if reissue_plan_ref is not None
                        else state.latest_reissue_plan_ref
                    ),
                    "lifecycle_jobs": _complete_monitoring_jobs(
                        state.lifecycle_jobs,
                        monitoring_contract_ref=monitoring_contract_ref,
                        monitoring_report_ref=monitoring_report_ref,
                    ),
                }
            )
        )

    def get_feedback_refs(self, packet_ref: str) -> dict[str, str | None]:
        state = self._state.load_packet(packet_ref)
        if state is None:
            self.ensure_evaluation(packet_ref)
            state = self._state.load_packet(packet_ref)
        if state is None:
            return {
                "monitoring_contract_ref": None,
                "latest_monitoring_report_ref": None,
                "latest_compare_report_ref": None,
                "latest_reissue_plan_ref": None,
            }
        return {
            "monitoring_contract_ref": state.monitoring_contract_ref,
            "latest_monitoring_report_ref": state.latest_monitoring_report_ref,
            "latest_compare_report_ref": state.latest_compare_report_ref,
            "latest_reissue_plan_ref": state.latest_reissue_plan_ref,
        }

    def _lifecycle_summary(self, packet_ref: str) -> dict[str, Any]:
        state = self._state.load_packet(packet_ref)
        if state is None:
            return {
                "events": [],
                "transitions": [],
                "pending_reviews": [],
                "scheduled_jobs": [],
                "reissue_candidates": [],
                "latest_transition_at": None,
            }
        pending_reviews = [
            {
                "event_id": event.event_id,
                "trigger_type": event.trigger_type.value,
                "reason": event.reason,
                "occurred_at": event.occurred_at.isoformat(),
            }
            for event in state.lifecycle_events
            if _is_review_required_status(event.status)
        ]
        reissue_candidates = []
        if state.latest_reissue_plan_ref:
            reissue_candidates.append({"artifact_id": state.latest_reissue_plan_ref})
        return {
            "events": [item.model_dump(mode="json") for item in state.lifecycle_events[-20:]],
            "transitions": [
                item.model_dump(mode="json") for item in state.transition_history[-20:]
            ],
            "pending_reviews": pending_reviews,
            "scheduled_jobs": [item.model_dump(mode="json") for item in state.lifecycle_jobs[-20:]],
            "reissue_candidates": reissue_candidates,
            "latest_transition_at": _serialize_datetime(state.last_transition_at),
        }

    def _record_transition(
        self,
        *,
        packet_ref: str,
        decision_lineage_key: str,
        previous_status: DecisionValidityStatus | None,
        current_status: DecisionValidityStatus,
        reason: str,
        event_id: str | None,
        review_required: bool,
        evaluation_ref: str | None,
    ) -> None:
        state = self._state.load_packet(packet_ref)
        if state is None:
            return
        latest = state.transition_history[-1] if state.transition_history else None
        if (
            latest is not None
            and latest.current_status == current_status
            and latest.reason == reason
            and latest.triggered_by_event_id == event_id
        ):
            return
        occurred_at = utc_now()
        transition = DecisionValidityTransition(
            transition_id=f"decision_transition_{uuid.uuid4().hex[:12]}",
            packet_ref=packet_ref,
            decision_lineage_key=decision_lineage_key,
            previous_status=previous_status,
            current_status=current_status,
            reason=reason,
            occurred_at=occurred_at,
            triggered_by_event_id=event_id,
            evaluation_ref=evaluation_ref,
            review_required=review_required,
        )
        self._state.save_packet(
            state.model_copy(
                update={
                    "transition_history": [*state.transition_history, transition],
                    "last_transition_at": occurred_at,
                }
            )
        )

    def _schedule_monitoring_job(
        self,
        *,
        packet_ref: str,
        decision_lineage_key: str,
        monitoring_contract_ref: str,
    ) -> None:
        state = self._state.load_packet(packet_ref)
        if state is None:
            return
        contract = self._load_monitoring_contract(monitoring_contract_ref)
        if contract is None:
            return
        scheduled_for = _monitoring_due_at(contract)
        job = DecisionLifecycleJob(
            job_id=f"decision_monitor_{uuid.uuid4().hex[:12]}",
            job_kind="scheduled_monitoring",
            packet_ref=packet_ref,
            decision_lineage_key=decision_lineage_key,
            state="pending",
            reason="monitoring_contract_registered",
            scheduled_for=scheduled_for,
            monitoring_contract_ref=monitoring_contract_ref,
            payload={"metric_ids": [item.metric_id for item in contract.metrics]},
        )
        self._state.save_packet(
            state.model_copy(
                update={
                    "lifecycle_jobs": _dedupe_jobs([*state.lifecycle_jobs, job]),
                }
            )
        )

    def _completed_hte_dependency_integrity_trigger(
        self,
        *,
        packet_payload: dict[str, Any],
        envelope: DecisionValidityEnvelope,
    ) -> DecisionTriggerRecord | None:
        """Reconcile the scalar HTE projection with its persisted owner basis."""
        basis = envelope.data_basis.summary
        request_selection_trigger = _completed_hte_request_selection_trigger(
            packet_payload=packet_payload,
            envelope=envelope,
        )
        if request_selection_trigger is not None:
            return request_selection_trigger
        if basis.get("completed_hte_source_status") != "selected":
            return None

        requested_source_run_id = basis.get("completed_hte_requested_source_run_id")
        hte_value = packet_payload.get("hte")
        try:
            from polisyos.core.contracts.owned_attempt_anchor import (
                OwnedAttemptAnchorProjectionAssociation,
            )
            from polisyos.core.contracts.runtime import DirectMethodExecutionHTESummary

            association_payload = basis.get("completed_hte_owner_association")
            if not isinstance(hte_value, dict) or not isinstance(association_payload, dict):
                raise ValueError("completed_hte_owner_source_missing")
            summary = DirectMethodExecutionHTESummary.model_validate_json(
                json.dumps(hte_value),
                strict=True,
            )
            association = OwnedAttemptAnchorProjectionAssociation.model_validate_json(
                json.dumps(association_payload),
                strict=True,
            )
            event = association.job_completed_event
            source_run_id = basis.get("completed_hte_source_run_id")
            source_job_id = basis.get("completed_hte_source_job_id")
            source_attempt = basis.get("completed_hte_source_attempt")
            event_id = basis.get("completed_hte_completion_event_id")
            event_payload_sha256 = basis.get("completed_hte_completion_event_payload_sha256")
            if (
                type(source_run_id) is not str
                or not source_run_id
                or type(source_job_id) is not str
                or not source_job_id
                or type(source_attempt) is not int
                or source_attempt < 1
                or type(event_id) is not int
                or event_id < 1
                or type(event_payload_sha256) is not str
                or not event_payload_sha256
                or requested_source_run_id != source_run_id
                or association.run_id != source_run_id
                or association.job_id != source_job_id
                or association.attempt != source_attempt
                or association.outcome_kind != summary.kind
                or event.job_id != source_job_id
                or event.event_id != event_id
                or event.payload_sha256 != event_payload_sha256
                or event.event_type != "job_completed"
                or basis.get("completed_hte_association_status") != association.status
                or basis.get("completed_hte_content_validation_status")
                != association.content_validation_status
                or basis.get("completed_hte_manifest_identity_status")
                != association.manifest_identity_status
                or basis.get("completed_hte_outcome_kind") != summary.kind
                or basis.get("completed_hte_method_profile_id") != summary.method_profile_id
                or basis.get("completed_hte_authority_purpose") != "candidate_method_evidence"
                or basis.get("completed_hte_publication_authorization") != "not_established"
                or basis.get("completed_hte_currentness_status") != "reconciled_at_completed_event"
                or basis.get("completed_hte_limitations") != list(summary.limitations)
            ):
                raise ValueError("completed_hte_owner_source_identity_mismatch")

            summary_digest = hashlib.sha256(
                json.dumps(
                    summary.model_dump(mode="json"),
                    ensure_ascii=False,
                    allow_nan=False,
                    sort_keys=True,
                    separators=(",", ":"),
                ).encode("utf-8")
            ).hexdigest()
            if association.selected_summary_sha256 != summary_digest:
                raise ValueError("completed_hte_owner_summary_digest_mismatch")

            matching_fields = (
                (summary.owned_attempt_anchor_ref, association.anchor_ref),
                (summary.hte_outcome_ref, association.outcome_ref),
                (summary.source_data_ref, association.source_data_ref),
                (summary.method_result_ref, association.method_result_ref),
                (summary.method_evidence_ref, association.method_evidence_ref),
                (summary.point_result_ref, association.point_result_ref),
                (summary.hte_result_ref, association.hte_result_ref),
                (summary.inference_basis_ref, association.inference_basis_ref),
                (summary.refusal_diagnostic_ref, association.refusal_diagnostic_ref),
                (
                    summary.materialization_binding_ref,
                    association.materialization_binding_ref,
                ),
                (
                    summary.search_uncertainty_task_binding_ref,
                    association.search_uncertainty_task_binding_ref,
                ),
            )
            for summary_ref, association_ref in matching_fields:
                if summary_ref != association_ref:
                    raise ValueError("completed_hte_summary_association_ref_mismatch")

            def artifact_refs(value: object) -> tuple[ArtifactRef, ...]:
                if isinstance(value, ArtifactRef):
                    return (value,)
                if isinstance(value, BaseModel):
                    field_names = getattr(type(value), "model_fields", {})
                    if {"artifact_id", "kind", "media_type"}.issubset(field_names):
                        ref = ArtifactRef.model_validate(
                            {
                                "artifact_id": value.artifact_id,
                                "kind": value.kind,
                                "media_type": value.media_type,
                                "manifest_profile_sha256": getattr(
                                    value,
                                    "manifest_profile_sha256",
                                    None,
                                ),
                            }
                        )
                        if ref.manifest_profile_sha256 is None:
                            raise ValueError("completed_hte_selected_ref_profile_missing")
                        return (ref,)
                    return tuple(
                        ref
                        for field_name in field_names
                        for ref in artifact_refs(getattr(value, field_name))
                    )
                if isinstance(value, (tuple, list)):
                    return tuple(ref for item in value for ref in artifact_refs(item))
                if isinstance(value, dict):
                    return tuple(ref for item in value.values() for ref in artifact_refs(item))
                return ()

            refs_by_identity: dict[tuple[str, str, str, str | None], ArtifactRef] = {}
            for ref in (*artifact_refs(summary), *artifact_refs(association)):
                self._store.get_manifest(ref)
                refs_by_identity[artifact_ref_identity_key(ref)] = ref
            if not refs_by_identity:
                raise ValueError("completed_hte_selected_refs_missing")

            expected: dict[
                str,
                tuple[str | None, DecisionDependencyKind, dict[str, Any]],
            ] = {}
            for identity, ref in refs_by_identity.items():
                artifact_id, kind, media_type, profile_sha256 = identity
                if profile_sha256 is None:
                    raise ValueError("completed_hte_selected_ref_profile_missing")
                key = f"hte_completed_source_artifact:{artifact_id}:{profile_sha256}"
                expected[key] = (
                    artifact_id,
                    DecisionDependencyKind.ECONOMETRIC_EVIDENCE,
                    {
                        "media_type": media_type,
                        "manifest_profile_sha256": profile_sha256,
                        "source_run_id": source_run_id,
                        "source_job_id": source_job_id,
                        "source_attempt": source_attempt,
                        "completed_event_id": event_id,
                        "completed_event_payload_sha256": event_payload_sha256,
                    },
                )
            source_run_key = f"hte_completed_source_run:{source_run_id}"
            expected[source_run_key] = (
                None,
                DecisionDependencyKind.ECONOMETRIC_EVIDENCE,
                {
                    "source_run_id": source_run_id,
                    "source_job_id": source_job_id,
                    "source_attempt": source_attempt,
                    "completed_event_id": event_id,
                    "completed_event_payload_sha256": event_payload_sha256,
                },
            )
            event_key = (
                f"hte_completed_source_event:{source_job_id}:{event_id}:{event_payload_sha256}"
            )
            expected[event_key] = (
                None,
                DecisionDependencyKind.ECONOMETRIC_EVIDENCE,
                {
                    "source_run_id": source_run_id,
                    "source_job_id": source_job_id,
                    "source_attempt": source_attempt,
                    "completed_event_id": event_id,
                    "completed_event_payload_sha256": event_payload_sha256,
                },
            )
            expected_keys = sorted(expected)
            if basis.get("completed_hte_dependency_keys") != expected_keys:
                raise ValueError("completed_hte_dependency_summary_mismatch")
            actual_rows = [
                dependency
                for dependency in envelope.data_basis.dependencies
                if dependency.key.startswith("hte_completed_source_")
            ]
            actual_keys = [dependency.key for dependency in actual_rows]
            if len(actual_rows) != len(expected):
                raise ValueError("completed_hte_dependency_cardinality_mismatch")
            if len(set(actual_keys)) != len(actual_keys):
                raise ValueError("completed_hte_duplicate_dependency_key")
            if set(actual_keys) != set(expected):
                raise ValueError("completed_hte_dependency_key_set_mismatch")
            for dependency in actual_rows:
                artifact_id, kind, metadata = expected[dependency.key]
                if (
                    dependency.kind != kind
                    or dependency.artifact_id != artifact_id
                    or dependency.metadata != metadata
                ):
                    raise ValueError("completed_hte_dependency_binding_mismatch")
        except _DECISION_VALIDITY_ARTIFACT_LOAD_ERRORS:
            return _completed_hte_basis_warning_trigger(
                basis=basis,
                reason="completed_hte_dependency_basis_not_established",
            )
        except (AttributeError, ImportError, KeyError, TypeError, ValueError):
            return _completed_hte_basis_warning_trigger(
                basis=basis,
                reason="completed_hte_dependency_basis_not_established",
            )
        return None

    def _compute_evaluation(
        self,
        *,
        packet_ref: str,
        packet_payload: dict[str, Any],
        current_state: _DecisionPacketState | None,
    ) -> DecisionValidityEvaluation:
        envelope = _load_envelope(packet_payload)
        baseline = _load_baseline(packet_payload)
        sticky_triggers = list(current_state.sticky_triggers) if current_state is not None else []
        superseded_by_ref = current_state.superseded_by_ref if current_state is not None else None

        if envelope is None:
            triggers = _dedupe_trigger_records(
                [
                    DecisionTriggerRecord(
                        trigger_type=DecisionTriggerType.LEGACY_PACKET,
                        status=DecisionValidityStatus.WARNING,
                        reason="legacy_packet_missing_validity_envelope",
                    ),
                    *sticky_triggers,
                ]
            )
            reasons = _dedupe_strings(
                [
                    "legacy_packet_missing_validity_envelope",
                    *(trigger.reason for trigger in sticky_triggers),
                ]
            )
            status = DecisionValidityStatus.WARNING
            for trigger in triggers:
                status = _max_status(status, trigger.status)
            if superseded_by_ref:
                status = DecisionValidityStatus.SUPERSEDED
                superseded_reason = f"superseded_by:{superseded_by_ref}"
                reasons = _dedupe_strings([*reasons, superseded_reason])
                triggers = _dedupe_trigger_records(
                    [
                        *triggers,
                        DecisionTriggerRecord(
                            trigger_type=DecisionTriggerType.SUPERSEDED,
                            status=DecisionValidityStatus.SUPERSEDED,
                            reason=superseded_reason,
                            source_ref=superseded_by_ref,
                            details={"superseded_by_ref": superseded_by_ref},
                        ),
                    ]
                )
            return DecisionValidityEvaluation(
                decision_packet_ref=packet_ref,
                decision_lineage_key=packet_ref,
                status=status,
                reasons=reasons,
                triggers=triggers,
                dependency_keys=[],
                recommended_action=_recommended_action(status),
                review_required=_is_review_required_status(status),
                superseded_by_ref=superseded_by_ref,
            )

        if baseline is None:
            baseline = DecisionValidityEvaluation(
                decision_packet_ref=packet_ref,
                decision_lineage_key=envelope.decision_lineage_key,
                status=DecisionValidityStatus.ACTIVE,
                dependency_keys=envelope.dependency_keys(),
                recommended_action=_recommended_action(DecisionValidityStatus.ACTIVE),
            )

        completed_hte_trigger = self._completed_hte_dependency_integrity_trigger(
            packet_payload=packet_payload,
            envelope=envelope,
        )
        integrity_triggers = (
            [
                completed_hte_trigger,
            ]
            if completed_hte_trigger is not None
            else []
        )
        triggers = _dedupe_trigger_records(
            [*baseline.triggers, *sticky_triggers, *integrity_triggers]
        )
        reasons = _dedupe_strings(
            [
                *baseline.reasons,
                *(trigger.reason for trigger in sticky_triggers),
                *(trigger.reason for trigger in integrity_triggers),
            ]
        )
        status = baseline.status
        for trigger in triggers:
            status = _max_status(status, trigger.status)

        if superseded_by_ref:
            status = DecisionValidityStatus.SUPERSEDED
            superseded_reason = f"superseded_by:{superseded_by_ref}"
            reasons = _dedupe_strings([*reasons, superseded_reason])
            triggers = _dedupe_trigger_records(
                [
                    *triggers,
                    DecisionTriggerRecord(
                        trigger_type=DecisionTriggerType.SUPERSEDED,
                        status=DecisionValidityStatus.SUPERSEDED,
                        reason=superseded_reason,
                        source_ref=superseded_by_ref,
                        details={"superseded_by_ref": superseded_by_ref},
                    ),
                ]
            )

        return baseline.model_copy(
            update={
                "decision_packet_ref": packet_ref,
                "decision_lineage_key": envelope.decision_lineage_key,
                "evaluated_at": utc_now(),
                "status": status,
                "reasons": reasons,
                "triggers": triggers,
                "dependency_keys": (
                    baseline.dependency_keys
                    if baseline.dependency_keys
                    else envelope.dependency_keys()
                ),
                "review_required": _is_review_required_status(status),
                "recommended_action": _recommended_action(status),
                "supersedes_decision_ref": (
                    current_state.supersedes_decision_ref if current_state is not None else None
                ),
                "superseded_by_ref": superseded_by_ref,
            }
        )

    def _register_dependencies(
        self,
        *,
        packet_ref: str,
        decision_lineage_key: str,
        dependencies: tuple[object, ...],
    ) -> None:
        for dependency in dependencies:
            dependency_key = str(dependency.key)
            dependency_kind = DecisionDependencyKind(dependency.kind)
            artifact_id = getattr(dependency, "artifact_id", None)
            dependency_state = self._state.load_dependency(dependency_key)
            if dependency_state is None:
                dependency_state = _DecisionDependencyIndex(
                    dependency_key=dependency_key,
                    dependency_kind=dependency_kind,
                    artifact_id=artifact_id,
                )
            elif (
                dependency_state.dependency_kind != dependency_kind
                or dependency_state.artifact_id != artifact_id
            ):
                raise ValueError("decision_dependency_owner_identity_mismatch")
            packet_refs = list(dependency_state.packet_refs)
            lineage_keys = list(dependency_state.lineage_keys)
            if packet_ref not in packet_refs:
                packet_refs.append(packet_ref)
            if decision_lineage_key not in lineage_keys:
                lineage_keys.append(decision_lineage_key)
            self._state.save_dependency(
                dependency_state.model_copy(
                    update={
                        "packet_refs": sorted(packet_refs),
                        "lineage_keys": sorted(lineage_keys),
                        "updated_at": utc_now(),
                    }
                )
            )

    def _load_packet_payload(self, packet_ref: str) -> dict[str, Any]:
        artifact_id = ArtifactID.model_validate(packet_ref)
        payload = read_core_json_artifact(self._store, artifact_id).value
        return payload if isinstance(payload, dict) else {}

    def _load_evaluation(self, evaluation_ref: str) -> DecisionValidityEvaluation | None:
        try:
            artifact_id = ArtifactID.model_validate(evaluation_ref)
            payload = read_core_json_artifact(self._store, artifact_id).value
        except _DECISION_VALIDITY_ARTIFACT_LOAD_ERRORS:
            return None
        if not isinstance(payload, dict):
            return None
        try:
            return DecisionValidityEvaluation.model_validate(payload)
        except _DECISION_VALIDITY_MODEL_ERRORS:
            return None

    def _load_monitoring_contract(
        self,
        monitoring_contract_ref: str,
    ) -> DecisionMonitoringContract | None:
        try:
            artifact_id = ArtifactID.model_validate(monitoring_contract_ref)
            payload = read_core_json_artifact(self._store, artifact_id).value
        except _DECISION_VALIDITY_ARTIFACT_LOAD_ERRORS:
            return None
        if not isinstance(payload, dict):
            return None
        try:
            return DecisionMonitoringContract.model_validate(payload)
        except _DECISION_VALIDITY_MODEL_ERRORS:
            return None


def _load_envelope(packet_payload: dict[str, Any]) -> DecisionValidityEnvelope | None:
    value = packet_payload.get("decision_validity_envelope")
    if not isinstance(value, dict):
        return None
    try:
        return DecisionValidityEnvelope.model_validate(value)
    except _DECISION_VALIDITY_MODEL_ERRORS:
        return None


def _load_baseline(packet_payload: dict[str, Any]) -> DecisionValidityEvaluation | None:
    value = packet_payload.get("decision_validity_baseline")
    if not isinstance(value, dict):
        return None
    try:
        return DecisionValidityEvaluation.model_validate(value)
    except _DECISION_VALIDITY_MODEL_ERRORS:
        return None


def _dedupe_strings(values: list[str]) -> list[str]:
    result: list[str] = []
    for value in values:
        normalized = value.strip()
        if normalized and normalized not in result:
            result.append(normalized)
    return result


def _dedupe_trigger_records(
    values: list[DecisionTriggerRecord],
) -> list[DecisionTriggerRecord]:
    deduped: list[DecisionTriggerRecord] = []
    seen: set[tuple[str, str, str | None, str | None]] = set()
    for item in values:
        key = (
            item.trigger_type.value,
            item.reason,
            item.dependency_key,
            item.source_ref,
        )
        if key in seen:
            continue
        seen.add(key)
        deduped.append(item)
    return deduped


def _dedupe_events(
    values: list[DecisionDependencyEvent],
) -> list[DecisionDependencyEvent]:
    deduped: list[DecisionDependencyEvent] = []
    seen: set[str] = set()
    for item in values:
        if item.event_id in seen:
            continue
        seen.add(item.event_id)
        deduped.append(item)
    return deduped


def _dedupe_jobs(
    values: list[DecisionLifecycleJob],
) -> list[DecisionLifecycleJob]:
    deduped: list[DecisionLifecycleJob] = []
    seen: set[tuple[str, str | None, str]] = set()
    for item in values:
        key = (item.packet_ref, item.trigger_event_id, item.job_kind)
        if key in seen:
            continue
        seen.add(key)
        deduped.append(item)
    return deduped


def _build_event_dedupe_key(
    *,
    trigger: DecisionTriggerRecord,
    dependency_keys: list[str],
    packet_ref: str | None = None,
) -> str:
    return str(
        content_hash(
            json.dumps(
                {
                    "trigger_type": trigger.trigger_type.value,
                    "status": trigger.status.value,
                    "reason": trigger.reason,
                    "dependency_keys": sorted(item for item in dependency_keys if item),
                    "source_ref": trigger.source_ref,
                    "packet_ref": packet_ref,
                    "details": trigger.details,
                },
                sort_keys=True,
                separators=(",", ":"),
            )
        )
    )


def _epoch_batch_id(
    *,
    transition_artifact_ref: ArtifactRef,
    requested_query_context_ref: str,
) -> str:
    payload = json.dumps(
        {
            "transition_artifact_id": str(transition_artifact_ref.artifact_id),
            "transition_kind": transition_artifact_ref.kind,
            "requested_query_context_ref": requested_query_context_ref,
        },
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return "epoch_batch_" + hashlib.sha256(payload).hexdigest()


def _trigger_records_from_event(
    event: DecisionDependencyEvent,
) -> list[DecisionTriggerRecord]:
    if event.dependency_keys:
        return [
            DecisionTriggerRecord(
                trigger_type=event.trigger_type,
                status=event.status,
                reason=event.reason,
                dependency_key=dependency_key,
                source_ref=event.source_ref,
                details=dict(event.payload),
            )
            for dependency_key in event.dependency_keys
        ]
    return [
        DecisionTriggerRecord(
            trigger_type=event.trigger_type,
            status=event.status,
            reason=event.reason,
            source_ref=event.source_ref,
            details=dict(event.payload),
        )
    ]


def _monitoring_due_at(contract: DecisionMonitoringContract) -> datetime:
    max_offset_days = 0
    for metric in contract.metrics:
        max_offset_days = max(
            max_offset_days,
            int(metric.window.end_offset_days) + int(metric.window.grace_days),
        )
    return cast("datetime", contract.anchor_at + timedelta(days=max_offset_days))


def _complete_monitoring_jobs(
    jobs: list[DecisionLifecycleJob],
    *,
    monitoring_contract_ref: str | None,
    monitoring_report_ref: str | None,
) -> list[DecisionLifecycleJob]:
    if monitoring_report_ref is None:
        return jobs
    completed_at = utc_now()
    updated: list[DecisionLifecycleJob] = []
    for job in jobs:
        if job.job_kind != "scheduled_monitoring":
            updated.append(job)
            continue
        if monitoring_contract_ref and job.monitoring_contract_ref != monitoring_contract_ref:
            updated.append(job)
            continue
        updated.append(
            job.model_copy(
                update={
                    "state": "completed",
                    "completed_at": completed_at,
                    "payload": {
                        **job.payload,
                        "monitoring_report_ref": monitoring_report_ref,
                    },
                }
            )
        )
    return updated


def _recommended_action(status: DecisionValidityStatus) -> str:
    if status == DecisionValidityStatus.ACTIVE:
        return "none"
    if status == DecisionValidityStatus.WARNING:
        return "monitor"
    if status == DecisionValidityStatus.STALE:
        return "refresh_decision"
    if status in {
        DecisionValidityStatus.REVIEW_REQUIRED,
        DecisionValidityStatus.REQUIRES_HUMAN_REVIEW,
    }:
        return "human_review"
    if status == DecisionValidityStatus.SUPERSEDED:
        return "review_superseded"
    if status == DecisionValidityStatus.REISSUED:
        return "record_reissue"
    if status == DecisionValidityStatus.WITHDRAWN:
        return "record_withdrawal"
    if status == DecisionValidityStatus.REVOKED:
        return "record_revocation"
    return "human_review"


def _max_status(
    left: DecisionValidityStatus,
    right: DecisionValidityStatus,
) -> DecisionValidityStatus:
    order = {
        DecisionValidityStatus.ACTIVE: 0,
        DecisionValidityStatus.WARNING: 1,
        DecisionValidityStatus.STALE: 2,
        DecisionValidityStatus.REVIEW_REQUIRED: 3,
        DecisionValidityStatus.REQUIRES_HUMAN_REVIEW: 3,
        DecisionValidityStatus.SUPERSEDED: 4,
        DecisionValidityStatus.REISSUED: 5,
        DecisionValidityStatus.REVOKED: 6,
        DecisionValidityStatus.WITHDRAWN: 7,
    }
    return right if order[right] > order[left] else left


def _is_review_required_status(status: DecisionValidityStatus) -> bool:
    return status in {
        DecisionValidityStatus.REVIEW_REQUIRED,
        DecisionValidityStatus.REQUIRES_HUMAN_REVIEW,
        DecisionValidityStatus.WITHDRAWN,
    }


__all__ = [
    "DecisionValidityService",
]
