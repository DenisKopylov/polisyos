"""Bounded, independently replayable checks for one native cancellation witness.

These functions consume observed event records and real SQLite rows; they never
launch a process or create observations. A PASS is limited to these checks and
does not establish production authority or physical preemption.
"""

from __future__ import annotations

import copy
import hashlib
import json
import sqlite3
from pathlib import Path
from urllib.parse import quote, urlsplit


def require(condition: object, reason: str) -> None:
    if not condition:
        raise ValueError(reason)


def sha_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def scalar_int(value: object) -> bool:
    return type(value) is int and value >= 0


def native_overlap(observation: dict) -> dict:
    """Recompute an actual tree fit spanning the unmodified HTTP cancellation.

    A missing backend or sparse overlap is not a product failure. No marker,
    exit code, queue status or declared verdict can manufacture a tree return.
    In-process event authenticity remains bounded by the independently reviewed
    fixture and the retained loaded-origin evidence.
    """
    verdict = observation["case"]["verdict"]
    if verdict["backend_load"] == "UNAVAILABLE":
        return {"state": "ENVIRONMENT_ERROR", "reason": "backend_unavailable"}
    if verdict["backend_load"] != "PASS":
        return {"state": "ERROR", "reason": "backend_load_not_qualified"}
    worker = observation["executor"]["occupied_worker"]
    fit = observation["native"]["grf_tree_fit_events"]
    require(isinstance(fit, list), "fit_events is not a list")
    require(
        worker["is_current_shared_executor_worker"] is True,
        "worker identity not established",
    )
    pid, tid, ntid = worker["pid"], worker["thread_id"], worker["native_thread_id"]
    require(
        all(scalar_int(v) and v > 0 for v in (pid, tid, ntid)),
        "invalid worker identity",
    )
    start = observation["cancel"]["post_start_ns"]
    end = observation["cancel"]["post_end_ns"]
    read = observation["cancel"]["fresh_sqlite_readback"]["monotonic_ns"]
    end_fit = observation["result"]["fit_natural_return_ns"]
    for val in (start, end, read, end_fit):
        require(scalar_int(val), "invalid monotonic interval")
    require(start < end and start <= read, "invalid positive POST/durable timing")
    forest = observation["native"]["forest_dr_fit_events"]
    require(
        isinstance(forest, list)
        and len(forest) == 2
        and [event["kind"] for event in forest] == ["fit_enter", "fit_return"],
        "outer ForestDR fit event pair missing",
    )
    require(
        all(
            (event["pid"], event["thread_id"], event["native_thread_id"]) == (pid, tid, ntid)
            for event in forest
        ),
        "outer fit is not the occupied worker",
    )
    require(
        forest[0]["monotonic_ns"] < forest[1]["monotonic_ns"] == end_fit
        and scalar_int(forest[0]["estimator_identity"])
        and forest[0]["estimator_identity"] > 0
        and forest[0]["estimator_identity"] == forest[1]["estimator_identity"]
        and scalar_int(forest[0]["fit_call_id"])
        and forest[0]["fit_call_id"] > 0
        and forest[0]["fit_call_id"] == forest[1]["fit_call_id"]
        and forest[1]["success"] is True,
        "outer fit did not return naturally",
    )
    sequences: set[int] = set()
    entered: dict[int, dict] = {}
    returns: list[dict] = []
    intervals: list[tuple[dict, dict]] = []
    for event in fit:
        require(event["kind"] in {"fit_enter", "fit_return"}, "unexpected fit event kind")
        seq = event["sequence"]
        require(scalar_int(seq) and seq not in sequences, "invalid/duplicate fit sequence")
        sequences.add(seq)
        require(
            (event["pid"], event["thread_id"], event["native_thread_id"]) == (pid, tid, ntid),
            "fit thread is not selected worker",
        )
        require(
            scalar_int(event["tree_identity"]) and event["tree_identity"] > 0,
            "invalid tree identity",
        )
        require(
            scalar_int(event["monotonic_ns"]) and scalar_int(event["thread_time_ns"]),
            "invalid event clocks",
        )
        ident = event["fit_call_id"]
        require(scalar_int(ident) and ident > 0, "invalid tree fit call identity")
        if event["kind"] == "fit_enter":
            require(ident not in entered, "duplicate tree entry")
            entered[ident] = event
        else:
            require(ident in entered, "tree return without observed entry")
            begin = entered.pop(ident)
            require(
                event["sequence"] > begin["sequence"]
                and event["tree_identity"] == begin["tree_identity"],
                "tree return sequence or identity differs",
            )
            require(
                event["monotonic_ns"] > begin["monotonic_ns"],
                "tree did not finish after entry",
            )
            require(
                event["thread_time_ns"] > begin["thread_time_ns"],
                "tree thread CPU did not advance",
            )
            require(
                event["success"] is True
                and (
                    event["node_count"] is None
                    or (scalar_int(event["node_count"]) and event["node_count"] > 0)
                ),
                "invalid actual tree return",
            )
            returns.append(event)
            intervals.append((begin, event))
    require(not entered, "unmatched tree entries at final readout")
    require(
        all(forest[0]["monotonic_ns"] < event["monotonic_ns"] < end_fit for event in fit),
        "tree event outside outer fit",
    )
    require(
        [event["sequence"] for event in fit] == sorted(event["sequence"] for event in fit)
        and [event["monotonic_ns"] for event in fit]
        == sorted(event["monotonic_ns"] for event in fit)
        and [event["thread_time_ns"] for event in fit]
        == sorted(event["thread_time_ns"] for event in fit),
        "fit event chronology differs",
    )
    ordered = sorted(returns, key=lambda event: event["monotonic_ns"])
    require(
        len({event["monotonic_ns"] for event in ordered}) == len(ordered),
        "duplicate tree return clock",
    )
    before = [event for event in ordered if event["monotonic_ns"] < start]
    after = [event for event in ordered if event["monotonic_ns"] > end]
    spanning = [
        (entry, finished)
        for entry, finished in intervals
        if entry["monotonic_ns"] < start and finished["monotonic_ns"] > end
    ]
    inflight = bool(
        before
        and after
        and spanning
        and observation["cancel"]["future_unfinished_at_response"] is True
        and end_fit > read
        and end_fit > after[-1]["monotonic_ns"]
    )
    clock = observation["cancel"]["worker_cpu_bracket"]
    cpu_state = "UNAVAILABLE"
    delta = None
    if clock["available"] is True:
        require(
            (
                clock["pid"],
                clock["thread_id"],
                clock["native_thread_id"],
                clock["mach_thread_port"],
            )
            == (pid, tid, ntid, worker["mach_thread_port"]),
            "CPU clock belongs to a different worker",
        )
        require(
            scalar_int(clock["mach_thread_port"]) and clock["mach_thread_port"] > 0,
            "invalid Mach thread port",
        )
        require(
            clock["method"] == "mach_THREAD_BASIC_INFO"
            and clock["flavor"] == 3
            and clock["count"] == 10
            and clock["struct_size_bytes"] == 40
            and clock["resolution_microseconds"] == 1,
            "unexpected Mach CPU sampler ABI",
        )
        values = []
        for sample in (clock["before"], clock["after"]):
            require(
                sample["return_code"] == 0
                and sample["returned_count"] == 10
                and sample["struct_size_bytes"] == 40
                and sample["error"] is None
                and scalar_int(sample["monotonic_ns"]),
                "unsuccessful or incomplete Mach sample",
            )
            for key in ("user_time", "system_time"):
                current = sample[key]
                require(
                    scalar_int(current["seconds"])
                    and scalar_int(current["microseconds"])
                    and current["microseconds"] < 1_000_000,
                    "invalid Mach CPU value",
                )
            actual = sum(
                sample[key]["seconds"] * 1_000_000 + sample[key]["microseconds"]
                for key in ("user_time", "system_time")
            )
            require(actual == sample["thread_cpu_microseconds"], "Mach CPU sum differs")
            values.append(actual)
        require(
            clock["before"]["monotonic_ns"] <= start < end <= clock["after"]["monotonic_ns"],
            "CPU samples do not bracket POST",
        )
        require(values[1] >= values[0], "CPU clock regressed")
        delta = values[1] - values[0]
        require(delta == clock["thread_cpu_delta_microseconds"], "CPU delta differs")
        cpu_state = "INCREASED" if delta > 0 else "NOT_OBSERVED"
    elif clock["available"] is not False:
        raise ValueError("CPU availability must be explicit")
    ok = inflight and cpu_state == "INCREASED"
    return {
        "state": "PASS" if ok else "INCONCLUSIVE",
        "reason": "observed" if ok else "insufficient_inflight_or_cpu_clock_evidence",
        "native_fit_spans_post": bool(spanning),
        "bounded_native_in_flight": "PASS" if inflight else "INCONCLUSIVE",
        "future_unfinished_at_response": observation["cancel"]["future_unfinished_at_response"],
        "successful_tree_returns": len(ordered),
        "tree_returns_with_node_count": sum(event["node_count"] is not None for event in ordered),
        "returns_before_post": len(before),
        "returns_after_post": len(after),
        "fit_return_after_durable_read": end_fit > read,
        "cpu_bracket_state": cpu_state,
        "cpu_delta_microseconds": delta,
        "bounded_limitation": "CPU samples bracket the POST; CPU time is not timestamped inside the call and individual native instructions are not observed",
    }


def saturation_premise(observation: dict) -> dict:
    """Check a distinct nonnumeric peer and both owner-configured FIFO slots."""
    executor, cancel = observation["executor"], observation["cancel"]
    profile, queue = executor["profile"], executor["queue"]
    worker, peer = executor["occupied_worker"], executor["nonnumeric_peer"]
    entries = [
        event
        for event in observation["native"]["grf_tree_fit_events"]
        if event["kind"] == "fit_enter"
    ]
    if not entries:
        return {"passed": False, "reason": "no actual tree entry"}
    first_entry = min(event["monotonic_ns"] for event in entries)
    clock_values = (
        first_entry,
        peer["enter_ns"],
        queue["full_observed_ns"],
        cancel["post_start_ns"],
        cancel["post_end_ns"],
        peer["release_ns"],
        peer["exit_ns"],
    )
    if not all(scalar_int(value) for value in clock_values):
        return {"passed": False, "reason": "peer timing unavailable"}
    fit_entry, peer_enter, full, post_start, post_end, peer_release, peer_exit = clock_values
    follower_events = queue["follower_events"]
    follower_ok = (
        isinstance(follower_events, list)
        and len(follower_events) == 2
        and {event["follower_id"] for event in follower_events} == {1, 2}
        and all(
            event["pid"] == worker["pid"]
            and scalar_int(event["monotonic_ns"])
            and event["monotonic_ns"] > peer_exit
            for event in follower_events
        )
    )
    distinct_peer = (
        peer["mode"] == "event_wait"
        and peer["numeric_work"] is False
        and peer["is_current_shared_executor_worker"] is True
        and peer["pid"] == worker["pid"]
        and peer["thread_id"] != worker["thread_id"]
        and peer["native_thread_id"] != worker["native_thread_id"]
        and peer["release_observed"] is True
    )
    timing = (
        fit_entry < peer_enter < full < post_start < post_end < peer_release <= peer_exit
        and follower_ok
    )
    occupancy = (
        profile["capacity"] == 2
        and profile["queue_capacity"] == 2
        and queue["pending_when_fit_active"] is True
        and queue["overflow_error_code"] == "shared_executor_queue_full"
        and queue["overflow_capacity"]
        == queue["overflow_queue_capacity"]
        == queue["overflow_queue_depth"]
        == 2
        and queue["physical_workers"] == 2
        and queue["queued_jobs"] == 2
        and queue["outstanding_jobs"] == 4
    )
    return {
        "passed": bool(distinct_peer and timing and occupancy),
        "distinct_nonnumeric_peer": distinct_peer,
        "full_through_post": timing,
        "sampled_occupancy": occupancy,
        "follower_events_after_peer_exit": follower_ok,
        "scope": "one real numeric fit, one source-reviewed test-only event-wait peer and two nonnumeric followers",
    }


def classify_complete(
    native: dict, *, observed_failure: bool, unestablished: bool, junit_failure: bool
) -> str:
    """Do not attribute an observed failure to a fit that had already ended."""
    if native.get("bounded_native_in_flight") != "PASS":
        return "INCONCLUSIVE"
    if observed_failure:
        return "FAIL"
    if junit_failure:
        return "ERROR"
    if unestablished or native.get("state") != "PASS":
        return "INCONCLUSIVE"
    return "PASS"


def verify_loaded_origins(native: dict, venv: Path) -> dict:
    """Re-read the exact actually reported loaded backend files; no import occurs."""
    require(
        native["grftree_class"] == "econml.grf._base_grftree.GRFTree",
        "wrong GRFTree class",
    )
    require(
        native["forest_dr_defining_class"] == "econml.dr._drlearner.ForestDRLearner"
        and native["forest_dr_public_import_alias"] == "econml.dr.ForestDRLearner",
        "wrong ForestDR defining class or public import alias",
    )
    loaded_native = native["loaded_native_modules"]
    require(
        isinstance(loaded_native, list)
        and len({row["name"] for row in loaded_native}) == len(loaded_native),
        "loaded native origins are missing or duplicated",
    )
    tree_native = [row for row in loaded_native if row["name"] == "econml.tree._tree"]
    require(len(tree_native) == 1, "actual econml tree native module not established")
    require(
        native["fit_original"]["module"] == "econml.grf._base_grftree",
        "wrong fit owner module",
    )
    require(
        native["fit_original"]["qualname"] == "GRFTree.fit",
        "wrong original fit callable",
    )
    site = (venv / "lib/python3.14/site-packages").resolve()
    targets = (
        ("econml_module_origin", "econml_module_sha256", "econml/__init__.py"),
        (
            "grftree_module_origin",
            "grftree_module_sha256",
            "econml/grf/_base_grftree.py",
        ),
        (
            "forest_dr_module_origin",
            "forest_dr_module_sha256",
            "econml/dr/_drlearner.py",
        ),
    )
    result = {}
    for origin, sha_key, relative in targets:
        path = Path(native[origin]).resolve(strict=True)
        require(
            path.is_relative_to(site) and path.is_file(),
            "backend origin outside admitted venv",
        )
        if relative is not None:
            require(path == site / relative, "backend Python module mismatch")
        actual = sha_file(path)
        require(native[sha_key] == actual, "backend origin hash mismatch")
        result[origin] = {
            "path": str(path),
            "sha256": actual,
            "bytes": path.stat().st_size,
        }
    for row in loaded_native:
        path = Path(row["origin"]).resolve(strict=True)
        require(
            path.is_relative_to(site) and path.is_file() and path.name.endswith((".so", ".dylib")),
            "loaded native extension outside admitted venv",
        )
        actual = sha_file(path)
        require(row["sha256"] == actual, "loaded native hash mismatch")
        result["native:" + row["name"]] = {
            "path": str(path),
            "sha256": actual,
            "bytes": path.stat().st_size,
        }
    tree_path = Path(tree_native[0]["origin"]).resolve(strict=True)
    require(
        tree_path.parent == site / "econml/tree" and tree_path.name.startswith("_tree."),
        "unexpected EconML tree extension",
    )
    fit = native["fit_original"]
    require(
        Path(fit["source_path"]).resolve() == site / "econml/grf/_base_grftree.py",
        "fit source mismatch",
    )
    require(
        fit["source_sha256"] == result["grftree_module_origin"]["sha256"],
        "fit source hash mismatch",
    )
    require(
        isinstance(native["econml_version"], str) and native["econml_version"],
        "missing loaded version",
    )
    return result


def selected_cas(ref: dict, locator: dict, case: Path) -> tuple[dict, dict]:
    """Re-read exact blob and selected-view manifest; profile semantics remain bounded."""
    case_root = case.resolve(strict=True)
    cas = Path(locator["cas_root"]).resolve(strict=True)
    blob = Path(locator["payload_path"]).resolve(strict=True)
    manifest = Path(locator["manifest_path"]).resolve(strict=True)
    require(
        cas.is_relative_to(case_root) and blob.is_relative_to(cas) and manifest.is_relative_to(cas),
        "CAS outside admitted case",
    )
    aid, profile = ref["artifact_id"], ref["manifest_profile_sha256"]
    require(
        isinstance(aid, str) and aid.startswith("sha256:") and len(aid) == 71,
        "invalid artifact ID",
    )
    require(
        isinstance(profile, str) and profile.startswith("sha256:") and len(profile) == 71,
        "invalid manifest selector",
    )
    digest, profile_hex = aid[7:], profile[7:]
    require(
        all(char in "0123456789abcdef" for char in digest + profile_hex),
        "invalid hex selector",
    )
    directory = cas / "artifacts/sha256" / digest[:2] / digest[2:4]
    require(
        blob == directory / (digest + ".blob"),
        "blob path differs from selected artifact",
    )
    require(
        manifest == directory / (digest + ".view." + profile_hex + ".manifest.json"),
        "manifest path differs from selected view",
    )
    raw = blob.read_bytes()
    require(
        sha_bytes(raw) == digest == locator["payload_file_sha256"]
        and len(raw) == locator["payload_file_bytes"],
        "CAS bytes differ from selected artifact",
    )
    manifest_raw = manifest.read_bytes()
    require(sha_bytes(manifest_raw) == locator["manifest_sha256"], "manifest bytes differ")
    actual_manifest = json.loads(manifest_raw)
    require(
        (
            actual_manifest["artifact_id"],
            actual_manifest["kind"],
            actual_manifest["media_type"],
        )
        == (aid, ref["kind"], ref["media_type"]),
        "selected manifest/ref identity differs",
    )
    require(
        locator["manifest_profile_sha256"] == profile,
        "selected profile locator differs",
    )
    return json.loads(raw), {
        "artifact_id": aid,
        "kind": ref["kind"],
        "blob_path": str(blob),
        "blob_sha256": digest,
        "bytes": len(raw),
        "manifest_path": str(manifest),
        "manifest_sha256": sha_bytes(manifest_raw),
        "selected_manifest_profile": profile,
        "profile_calculation": "source-reviewed owner read; not independently recomputed",
    }


def numeric_value(value: object) -> float:
    """Interpret only the bounded fixture's Core numeric representation."""
    if type(value) is float:
        return value
    if (
        isinstance(value, dict)
        and set(value) == {"_type", "repr"}
        and value["_type"] == "float"
        and isinstance(value["repr"], str)
    ):
        return float(value["repr"])
    raise ValueError("unsupported fixture numeric representation")


def fixture_json_semantics(value: object) -> object:
    """Decode fixture float tags only; not a general canonical parser."""
    if isinstance(value, dict):
        if set(value) == {"_type", "repr"} and value["_type"] == "float":
            return numeric_value(value)
        return {key: fixture_json_semantics(item) for key, item in value.items()}
    if isinstance(value, list):
        return [fixture_json_semantics(item) for item in value]
    return value


def source_custody(source: dict, case: Path) -> dict:
    """Re-read selected input CAS and independently recompute its bounded rows."""
    ref = source["source_ref"]
    require(
        ref["kind"] == source["source_kind"] == "ir.observation_method_input"
        and ref["media_type"] == "application/json",
        "source ref type mismatch",
    )
    envelope, result = selected_cas(ref, source, case)
    require(
        envelope["schema_version"] == "policyos.ir.observation.method_input_envelope.v1",
        "source envelope schema differs",
    )
    payload = envelope["contract_payload"]
    columns = ("outcome", "treatment", "covariates", "confounders", "sample_ids")
    require(
        all(isinstance(payload[key], list) and len(payload[key]) == 2000 for key in columns),
        "synthetic input column denominator differs",
    )
    samples = payload["sample_ids"]
    require(
        all(isinstance(value, str) for value in samples) and len(set(samples)) == len(samples),
        "sample IDs are not unique",
    )
    for i in range(2000):
        require(samples[i] == f"candidate-{i}", "sample ID formula differs")
        require(
            numeric_value(payload["outcome"][i]) == i / 10 + (i % 2) * 0.5
            and type(payload["treatment"][i]) is int
            and payload["treatment"][i] == i % 2,
            "synthetic outcome/treatment formula differs",
        )
        covariates, confounders = payload["covariates"][i], payload["confounders"][i]
        require(
            isinstance(covariates, list)
            and len(covariates) == 2
            and [numeric_value(value) for value in covariates] == [float(i), float(i % 5)],
            "covariate formula differs",
        )
        require(
            isinstance(confounders, list)
            and len(confounders) == 1
            and numeric_value(confounders[0]) == float(i % 7),
            "confounder formula differs",
        )
    require(
        payload["feature_names"] == ["age", "baseline"] and payload["confounder_names"] == ["risk"],
        "input feature labels differ",
    )
    result.update(
        {
            "rows": len(samples),
            "row_denominator": list(columns),
            "sample_ids_unique": True,
            "deterministic_formula": "recomputed across all 2000 rows",
            "numeric_decoder_scope": "fixture float-tag semantics only; not an independent Core codec proof",
            "scope": "synthetic fixture input",
        }
    )
    return result


def intent_custody(observation: dict, case: Path) -> dict:
    method, source = observation["method"], observation["input"]
    descriptor = method["work_descriptor"]
    intent_ref = descriptor["observational_run_intent_ref"]
    launch = method["launch"]
    request, accepted = launch["request_body"], launch["response_body"]
    require(
        launch["url"] == "/api/v1/control/runs"
        and urlsplit(launch["request_url"]).path == launch["url"]
        and launch["status_code"] == 200
        and accepted["status"] == "accepted",
        "real run POST not accepted",
    )
    require(
        json.loads(launch["request_wire_utf8"]) == request,
        "run POST wire body mismatch",
    )
    require(
        (
            accepted["job_id"],
            accepted["run_id"],
            accepted["observational_run_intent_ref"],
        )
        == (method["job_id"], method["run_id"], intent_ref),
        "accepted job/intent differs from method work",
    )
    require(
        method["observational_run_intent_artifact"]["ref"] == intent_ref,
        "observed owner intent differs from work descriptor",
    )
    submitted = request["observational_input"]
    require(
        submitted["protocol"] == "method_input_envelope_v1"
        and submitted["source_ref"] == source["source_ref"]
        and submitted["method"]["fqn"] == "causal.hte.forest_dr@1.1.0",
        "run POST source/method differs",
    )
    raw, result = selected_cas(intent_ref, method["intent_cas"], case)
    require(
        raw["job_id"] == method["job_id"]
        and raw["run_id"] == method["run_id"]
        and raw["requested_source_ref"] == source["source_ref"],
        "persisted intent job/source differs",
    )
    require(
        raw["method_fqn"] == method["effective_fqn"] == "causal.hte.forest_dr@1.1.0"
        and raw["method_version"] == "1.1.0",
        "persisted intent method differs",
    )
    require(
        fixture_json_semantics(raw["resolved_params"]) == method["effective_params"]
        and raw["resource_policy_ref"] == method["resource_policy_ref"]
        and raw["resource_policy_digest"] == method["resource_policy_digest"],
        "persisted intent params/policy differs",
    )
    require(
        raw["protocol"] == "method_input_envelope_v1"
        and raw["source_manifest_sha256"] == source["manifest_sha256"],
        "persisted intent source manifest differs",
    )
    require(
        raw["submitted_params_present"] is True
        and fixture_json_semantics(raw["submitted_params"]) == submitted["method"]["params"],
        "persisted submitted params differ from run POST",
    )
    result.update(
        {
            "method_fqn": raw["method_fqn"],
            "policy_digest": raw["resource_policy_digest"],
            "job_id": raw["job_id"],
            "run_id": raw["run_id"],
            "scope": "persisted selected intent contents; actual dispatch remains source-reviewed",
        }
    )
    return result


def protected_snapshot(snapshot: dict) -> dict:
    """Select the complete job-specific protected state supplied by the witness."""
    require(
        set(snapshot) >= {"job_row", "progress", "events", "outbox"},
        "incomplete SQLite snapshot",
    )
    require(isinstance(snapshot["job_row"], dict), "job row missing")
    require(
        isinstance(snapshot["progress"], list)
        and isinstance(snapshot["events"], list)
        and isinstance(snapshot["outbox"], list),
        "progress/event/outbox rows missing",
    )
    require(
        all(len(snapshot[key]) <= 1024 for key in ("progress", "events", "outbox")),
        "job snapshot exceeds bounded output cap",
    )
    return {key: snapshot[key] for key in ("job_row", "progress", "events", "outbox")}


def snapshot_sha(snapshot: dict) -> str:
    return sha_bytes(
        json.dumps(protected_snapshot(snapshot), sort_keys=True, separators=(",", ":")).encode()
    )


def negative_checks(
    negatives: list[dict],
    *,
    job_id: str,
    run_id: str,
    attempt: int,
    owner: str,
    positive_post_start_ns: int,
) -> dict:
    require(isinstance(negatives, list), "negatives not a list")
    require(
        len(negatives) == 2
        and {x["kind"] for x in negatives} == {"stale_attempt", "denied_permission"},
        "negative denominator differs",
    )
    result = {}
    for record in negatives:
        before = protected_snapshot(record["before_snapshot"])
        after = protected_snapshot(record["after_snapshot"])
        before_row, after_row = dict(before["job_row"]), dict(after["job_row"])
        before_expiry = before_row.pop("lease_expires_at", None)
        after_expiry = after_row.pop("lease_expires_at", None)
        unchanged = (
            before_row == after_row
            and before["progress"] == after["progress"]
            and before["events"] == after["events"]
            and before["outbox"] == after["outbox"]
            and (
                (before_expiry is None and after_expiry is None)
                or (
                    before_expiry is not None
                    and after_expiry is not None
                    and after_expiry >= before_expiry
                )
            )
        )
        same_live_attempt = (
            before_row["job_id"] == job_id
            and before_row["run_id"] == run_id
            and before_row["attempt"] == attempt
            and before_row["lease_owner"] == owner
            and before_row["state"] == "running"
            and all(item["job_id"] == job_id for item in before["progress"])
            and all(event["job_id"] == job_id for event in before["events"])
            and all(event["job_id"] == job_id for event in before["outbox"])
        )
        timing_ok = record["request_start_ns"] < record["request_end_ns"] < positive_post_start_ns
        request = record["request_body"]
        expected_attempt = request.get("expected_attempt")
        attempt_ok = (
            type(expected_attempt) is int
            and expected_attempt >= 0
            and (
                expected_attempt != attempt
                if record["kind"] == "stale_attempt"
                else expected_attempt == attempt
            )
        )
        request_ok = (
            record["url"] == f"/api/v1/control/jobs/{job_id}/cancel"
            and urlsplit(record["request_url"]).path == record["url"]
            and request.get("expected_lease_owner") == owner
            and attempt_ok
            and bool(request.get("operation_id"))
        )
        encoded_before = json.dumps(before, sort_keys=True, separators=(",", ":")).encode()
        encoded_after = json.dumps(after, sort_keys=True, separators=(",", ":")).encode()
        require(
            sha_bytes(encoded_before) == record["before_snapshot_sha256"],
            "before snapshot hash mismatch",
        )
        require(
            sha_bytes(encoded_after) == record["after_snapshot_sha256"],
            "after snapshot hash mismatch",
        )
        if not same_live_attempt or not timing_ok or not request_ok or not unchanged:
            state = "INCONCLUSIVE"
        elif record["status_code"] < 400 or (
            record["kind"] == "denied_permission" and record["status_code"] != 403
        ):
            state = "FAIL"
        else:
            state = "PASS"
        # Do not promote two unavailable GET bodies (None == None) into
        # evidence of an unchanged public projection. This observation is
        # separate from the independently recomputed SQLite comparison.
        projections = []
        for field in ("selection_before_http", "selection_after_http"):
            observed = record.get(field)
            body = observed.get("body") if isinstance(observed, dict) else None
            run = body.get("run") if isinstance(body, dict) else None
            projection = run.get("method_execution_selection") if isinstance(run, dict) else None
            expected_url = f"/api/v1/runs/{run_id}"
            valid = (
                isinstance(observed, dict)
                and observed.get("method") == "GET"
                and observed.get("url") == expected_url
                and urlsplit(observed.get("request_url", "")).path == expected_url
                and observed.get("status_code") == 200
                and isinstance(run, dict)
                and run.get("run_id") == run_id
                and isinstance(projection, dict)
                and projection.get("status") != "unavailable"
            )
            projections.append(projection if valid else None)
        selection_surface = (
            "NOT_ESTABLISHED"
            if any(value is None for value in projections)
            else "UNCHANGED_OBSERVED"
            if projections[0] == projections[1]
            else "CHANGED_OBSERVED"
        )
        result[record["kind"]] = {
            "state": state,
            "status": record["status_code"],
            "selection_surface": selection_surface,
            "protected_state_unchanged": unchanged,
            "same_running_attempt": same_live_attempt,
            "request_binding": request_ok,
            "before_positive_post": timing_ok,
            "passed": state == "PASS",
            "before_snapshot_sha256": sha_bytes(encoded_before),
            "after_snapshot_sha256": sha_bytes(encoded_after),
        }
    return result


def cancellation_state(snapshot: dict, job_id: str, run_id: str, attempt: int) -> dict:
    """Recompute row/event structure; identity payloads use cancellation_binding."""
    state = protected_snapshot(snapshot)
    row, events, outbox = state["job_row"], state["events"], state["outbox"]
    identity = (
        (row["job_id"], row["run_id"], row["attempt"]) == (job_id, run_id, attempt)
        and all(item["job_id"] == job_id for item in state["progress"])
        and all(event["job_id"] == job_id for event in events)
        and all(event["job_id"] == job_id for event in outbox)
    )
    event_count = sum(event["event_type"] == "job_cancelled" for event in events)
    other_terminals = sum(
        event["event_type"] in {"job_completed", "job_failed"} for event in events
    )
    outbox_count = sum(event["topic"] == "control.job.cancelled" for event in outbox)
    passed = (
        identity
        and row["state"] == "cancelled"
        and row["lease_owner"] is None
        and row["method_execution_selection_json"] is None
        and event_count == outbox_count == 1
        and other_terminals == 0
    )
    return {
        "passed": passed,
        "same_job_attempt": identity,
        "state": row["state"],
        "owner_absent": row["lease_owner"] is None,
        "selection_absent": row["method_execution_selection_json"] is None,
        "cancel_event_count": event_count,
        "cancel_outbox_count": outbox_count,
        "other_terminal_count": other_terminals,
    }


def cancellation_binding(
    snapshot: dict,
    *,
    job_id: str,
    run_id: str,
    attempt: int,
    owner: str,
    tenant: str,
    cell: str,
    actor: str,
    request_body: dict,
    request_wire_utf8: str,
) -> dict:
    """Reconcile the real wire request with all three persisted cancellation carriers."""
    state = protected_snapshot(snapshot)
    body_matches_wire = json.loads(request_wire_utf8) == request_body
    expected = {
        "authorized_actor": actor,
        "tenant_id": tenant,
        "cell_id": cell,
        "operation_id": request_body["operation_id"],
        "body_sha256": "sha256:" + sha_bytes(request_wire_utf8.encode("utf-8")),
        "expected_attempt": attempt,
        "expected_lease_owner": owner,
        "disposition": "publication_fenced",
        "physical_stop_status": "not_established",
        "cancelled_attempt": attempt,
        "cancelled_lease_owner": owner,
    }
    progress = state["progress"]
    cancel_events = [event for event in state["events"] if event["event_type"] == "job_cancelled"]
    creation_events = [event for event in state["events"] if event["event_type"] == "job_created"]
    cancel_outbox = [item for item in state["outbox"] if item["topic"] == "control.job.cancelled"]
    if (
        len(progress) != 1
        or len(cancel_events) != 1
        or len(creation_events) != 1
        or len(cancel_outbox) != 1
    ):
        return {
            "passed": False,
            "reason": "carrier denominator differs",
            "body_matches_wire": body_matches_wire,
        }
    try:
        progress_body = json.loads(progress[0]["progress_json"])["cancellation"]
        event_body = json.loads(cancel_events[0]["payload_json"])
        outbox_body = json.loads(cancel_outbox[0]["payload_json"])
        creation = json.loads(creation_events[0]["payload_json"])["execution_scope"]
        carriers_match = all(
            all(carrier.get(key) == value for key, value in expected.items())
            for carrier in (progress_body, event_body, outbox_body)
        )
        context_matches = creation["tenant_id"] == tenant and creation["cell_id"] == cell
        event_bindings = (
            event_body.get("state") == "cancelled"
            and outbox_body.get("state") == "cancelled"
            and outbox_body.get("job_id") == job_id
            and outbox_body.get("run_id") == run_id
        )
    except (KeyError, TypeError, ValueError):
        return {
            "passed": False,
            "reason": "carrier malformed",
            "body_matches_wire": body_matches_wire,
        }
    return {
        "passed": bool(body_matches_wire and carriers_match and context_matches and event_bindings),
        "body_matches_wire": body_matches_wire,
        "carrier_fields_match": carriers_match,
        "creation_tenant_cell_match": context_matches,
        "event_job_run_state_match": event_bindings,
        "wire_body_sha256": expected["body_sha256"],
        "operation_id": expected["operation_id"],
    }


def sqlite_final(db_path: Path, case: Path, job_id: str, run_id: str, attempt: int) -> dict:
    """Read real, case-owned SQLite final state after pytest exits."""
    real_case, db = case.resolve(strict=True), db_path.resolve(strict=True)
    require(db.is_relative_to(real_case) and db.is_file(), "SQLite is not case-owned")
    with sqlite3.connect("file:" + quote(str(db)) + "?mode=ro", uri=True) as conn:
        conn.row_factory = sqlite3.Row
        jobs = [
            dict(row)
            for row in conn.execute("SELECT * FROM control_jobs WHERE job_id = ?", (job_id,))
        ]
        progress = [
            dict(row)
            for row in conn.execute(
                "SELECT * FROM control_job_progress WHERE job_id = ? ORDER BY job_id LIMIT 1025",
                (job_id,),
            )
        ]
        events = [
            dict(row)
            for row in conn.execute(
                "SELECT * FROM control_job_events WHERE job_id = ? ORDER BY event_id LIMIT 1025",
                (job_id,),
            )
        ]
        outbox = [
            dict(row)
            for row in conn.execute(
                "SELECT * FROM control_outbox_events WHERE job_id = ? ORDER BY event_id LIMIT 1025",
                (job_id,),
            )
        ]
    require(len(jobs) == 1, "final job denominator differs")
    require(
        all(len(rows) <= 1024 for rows in (progress, events, outbox)),
        "job SQLite snapshot exceeds bounded output cap",
    )
    job = jobs[0]
    require(
        (job["job_id"], job["run_id"], job["attempt"]) == (job_id, run_id, attempt),
        "final job identity mismatch",
    )
    wal = db.with_name(db.name + "-wal")
    wal_info = (
        {"path": str(wal), "sha256": sha_file(wal), "bytes": wal.stat().st_size}
        if wal.is_file()
        else None
    )
    return {
        "job_row": job,
        "progress": progress,
        "events": events,
        "outbox": outbox,
        "database": {
            "path": str(db),
            "sha256": sha_file(db),
            "bytes": db.stat().st_size,
        },
        "wal": wal_info,
    }


def cheap_falsifier(observation: dict) -> dict:
    """Keep HTTP, queue and status markers, remove the native tree observations."""
    original = copy.deepcopy(observation)
    marker_only = copy.deepcopy(observation)
    marker_only["native"]["grf_tree_fit_events"] = []
    observed = native_overlap(original)
    removed = native_overlap(marker_only)
    require(
        removed["state"] == "INCONCLUSIVE",
        "marker-only event-held substitute qualified",
    )
    return {
        "original": observed,
        "marker_only": removed,
        "mutation": "remove all actual native fit observations; retain queue/HTTP/verdict markers",
        "scope": "classifier falsifier, not a matched runtime removal",
    }
