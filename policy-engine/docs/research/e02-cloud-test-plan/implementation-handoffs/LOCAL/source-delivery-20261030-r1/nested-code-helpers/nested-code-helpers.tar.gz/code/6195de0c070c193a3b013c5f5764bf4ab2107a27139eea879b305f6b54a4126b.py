from pathlib import Path
import ast,difflib
root=Path.cwd();pkg=root/'LOCAL/raw/e02-execution-20261027/repairs/C49-local-r1';post=pkg/'postimages'
def existing(rel,fn):
 p=root/rel;s=p.read_text();pre=pkg/'preimages'/rel
 pre.parent.mkdir(parents=True,exist_ok=True)
 if not pre.exists():pre.write_text(s)
 after=fn(s);ast.parse(after);out=post/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(after)

def semantic(s):
 for name in ('MockEmbedder','ConstantEmbedder','FailOnThirdEmbedder','DimensionChangingEmbedder','VersionedEmbedder'):
  # Explicit identities belong only to these deterministic test measurement functions.
  start=s.index('class '+name+':')
  end=s.index('\n    def ',start) if '\n    def ' in s[start:] else -1
  assert end>start
  s=s[:end]+f'\n    model_id = "fixture-{name}"\n    model_version = "fixture-v1"\n'+s[end:]
 return s
existing(Path('policy-engine/tests/unit/scientist/orchestration/engine/test_convergence_semantic.py'),semantic)

# The malformed-confidence contract now preserves a candidate with an explicit
# unknown status rather than laundering a scalar conversion error into fallback.
rel=Path('policy-engine/tests/unit/runtime/quality/test_design_generation.py')
def n4(s):
 old='''    with pytest.raises(ValueError, match="could not convert string to float"):
        await LLMDrafterAgent(StaticLLMClient(json.dumps(payload))).draft_policy(
            _test_design_problem().to_scientist_problem_frame()
        )
'''
 new='''    draft = await LLMDrafterAgent(StaticLLMClient(json.dumps(payload))).draft_policy(
        _test_design_problem().to_scientist_problem_frame()
    )
    assert draft.draft_id == "draft_semantically_invalid"
    assert draft.narrative == payload["narrative"]
    assert draft.confidence_status == "not_established"
    assert draft.confidence_observation is None
    assert "candidate_confidence_not_established" in draft.grounding_notes
'''
 assert s.count(old)==1
 return s.replace(old,new,1)
existing(rel,n4)

# Preserve positional dataclass compatibility for existing tool-loop consumers.
p=post/'policy-engine/src/polisyos/scientist/agent/tools/tool_loop.py';s=p.read_text()
s=s.replace('from typing import TYPE_CHECKING, Any\n','from typing import TYPE_CHECKING, Any, Literal\n',1)
s=s.replace('    stop_kind: str = "none"\n    scientific_converged: bool = False\n','',1)
needle='    degraded_events: list[dict[str, Any]] = field(default_factory=list)\n'
s=s.replace(needle,needle+'    stop_kind: Literal["none", "resource_limit", "heuristic_stability"] = "none"\n    scientific_converged: Literal[False] = False\n',1)
ast.parse(s);p.write_text(s)

# Add the public lazy export at the existing adversarial facade owner (root/C48 merges).
p=post/'policy-engine/src/polisyos/scientist/methods/search/__init__.py';s=p.read_text()
s=s.replace('_LAZY_EXPORT_MODULES: dict[str, str] = {\n','_LAZY_EXPORT_MODULES: dict[str, str] = {\n    "StressObjectiveDirectionError": "polisyos.scientist.methods.search.adversarial",\n',1)
s=s.replace('__all__ = [\n','__all__ = [\n    "StressObjectiveDirectionError",\n',1)
ast.parse(s);p.write_text(s)

# Dedicated DTO bridge controls use the real worker serializer and decoder.
rel=Path('policy-engine/tests/unit/scientist/agent/test_drafter_observation_wire_c49.py')
text='''"""Historical wire and current typed worker transport, with no authority inflation."""
from __future__ import annotations

import copy
import hashlib
from datetime import UTC, datetime

import pytest
from pydantic import TypeAdapter, ValidationError

from polisyos.scientist.agent.protocols import DraftResult
from polisyos.scientist.agent.workers import _draft_to_payload, draft_from_payload
from polisyos.scientist.orchestration.engine.convergence import (
    ConvergenceConfig, ConvergenceDetector, ConvergenceObservation,
)


def test_historical_draft_projection_omits_unproduced_new_fields():
    draft = DraftResult(
        draft_id="legacy-draft", problem_frame_ref="legacy-problem", narrative="Useful candidate",
        created_at=datetime(2026, 1, 1, tzinfo=UTC), confidence=0.5,
    )
    projected = TypeAdapter(DraftResult).dump_python(draft, mode="json")
    assert set(projected) == {
        "draft_id", "problem_frame_ref", "narrative", "interventions", "rationale",
        "domain_references", "citations", "claim_supports", "grounding_notes", "confidence",
        "alternatives_considered", "raw_llm_response", "created_at",
    }
    assert _draft_to_payload(draft)["created_at"] == draft.created_at
    assert draft_from_payload(_draft_to_payload(draft)) == draft


def test_actual_worker_bridge_round_trips_typed_current_observation_and_rejects_authority():
    raw = "actual-current-response"
    digest = lambda text: hashlib.sha256(text.encode()).hexdigest()
    observation = ConvergenceObservation(
        subject_ref=digest("problem"), request_ref=digest("request"), source_ref=digest(raw),
        producer_event_id="real-call-id", model_ref="fixture-model", model_version="fixture-v1",
        pass_number=1, value=0.2,
    )
    state = ConvergenceDetector(ConvergenceConfig()).check_candidate_observation(
        observation, subject_ref=observation.subject_ref, request_ref=observation.request_ref,
        source_text=raw, value=0.2, pass_number=1,
    )
    draft = DraftResult(
        draft_id="current-draft", problem_frame_ref="problem", narrative="Useful candidate",
        citations=[{"ref": "existing-citation"}], claim_supports=[{"id": "existing-claim"}],
        grounding_notes=["candidate-only"], confidence=0.2,
        confidence_status="candidate_self_assessment", confidence_request_ref=observation.request_ref,
        confidence_observation=observation, convergence_state=state,
    )
    payload = _draft_to_payload(draft)
    assert type(payload["confidence_observation"]) is dict
    assert type(payload["convergence_state"]) is dict
    reopened = draft_from_payload(payload)
    assert type(reopened.confidence_observation) is ConvergenceObservation
    assert reopened.convergence_state == state
    assert reopened.citations == draft.citations and reopened.claim_supports == draft.claim_supports
    forged = copy.deepcopy(payload)
    forged["convergence_state"]["scientific_converged"] = True
    with pytest.raises(ValidationError):
        draft_from_payload(forged)
    with pytest.raises(TypeError):
        draft_from_payload({**payload, "authority": "publication"})
'''
ast.parse(text);p=post/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)

rel=Path('policy-engine/tests/unit/scientist/agent/tools/test_tool_loop_stopping_c49.py')
text='''"""The real tool-loop consumer distinguishes resource halt from convergence."""
from __future__ import annotations

import pytest

from polisyos.scientist.agent.tools.tool_loop import run_tool_loop
from polisyos.scientist.orchestration.engine.convergence import ConvergenceConfig
from tests.unit.scientist.agent.tools.test_tool_loop import (
    MockResponse, MockToolCallAttr, _make_registry_with_echo,
)


@pytest.mark.asyncio
async def test_actual_tool_loop_resource_cap_does_not_return_converged():
    class Wire:
        def __init__(self):
            self.calls = 0
        async def generate(self, **kwargs):
            self.calls += 1
            return MockResponse(content="candidate tool work", tool_calls=[
                MockToolCallAttr(id=f"call-{self.calls}", name="echo", arguments={"text": "fixture"}),
            ])
    client = Wire()
    result = await run_tool_loop(
        client=client, system="fixture", user="bounded tool work",
        tool_registry=_make_registry_with_echo(), max_iterations=4,
        convergence_config=ConvergenceConfig(min_iterations=1, max_iterations=1),
    )
    assert client.calls == 1 and len(result.tool_calls_made) == 1
    assert result.convergence_reason == "max_iterations"
    assert result.stop_kind == "resource_limit"
    assert not result.converged and not result.scientific_converged
'''
ast.parse(text);p=post/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
print('Prepared mandatory changed-expectation, versioned-fixture, worker-wire and tool-loop companions; runtime UNRUN.')
