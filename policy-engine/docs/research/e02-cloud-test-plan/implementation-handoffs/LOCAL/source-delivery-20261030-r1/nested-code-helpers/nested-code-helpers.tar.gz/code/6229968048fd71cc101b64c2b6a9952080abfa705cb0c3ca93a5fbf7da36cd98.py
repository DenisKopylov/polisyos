"""Small sequential actual-pytest Config and marker behavior smoke; no product import."""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
P = ROOT / "policy-engine"
HERE = Path(__file__).resolve().parent
PY = P / ".venv/bin/python"
SELECTOR = str(HERE / "test_config_behavior.py") + "::test_unknown_marker_behavior"
CASES = (
    ("product-addopts", P / "pytest.ini", []),
    ("product-explicit-cli", P / "pytest.ini", ["--strict-markers"]),
    ("scratch-negative", HERE / "negative.ini", []),
    ("scratch-ini-strict", HERE / "ini-strict.ini", []),
)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


records = []
for name, config, flags in CASES:
    out = HERE / name
    out.mkdir(exist_ok=False)
    tmp = out / "tmp"
    tmp.mkdir()
    env = os.environ.copy()
    for key in ("PYTEST_DISABLE_PLUGIN_AUTOLOAD", "PYTEST_ADDOPTS", "PYTHONHOME", "VIRTUAL_ENV"):
        env.pop(key, None)
    env.update({
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONPYCACHEPREFIX": str(tmp / "pycache"),
        "TMPDIR": str(tmp),
        "XDG_CACHE_HOME": str(tmp / "xdg"),
        "PYTHONPATH": str(HERE),
        "PYTEST_PLUGINS": "e02_cfg_smoke",
    })
    argv = [str(PY), "-B", "-m", "pytest", "-c", str(config), "--noconftest", "-s",
            "-o", "cache_dir=" + str(out / "pytest-cache"),
            "--benchmark-storage=file://" + str(out / "benchmarks"),
            "--basetemp", str(out / "basetemp"), *flags, SELECTOR]
    t = time.monotonic()
    result = subprocess.run(argv, cwd=P, env=env, capture_output=True, check=False, timeout=45)
    (out / "stdout.bin").write_bytes(result.stdout)
    (out / "stderr.bin").write_bytes(result.stderr)
    text = result.stdout.decode("utf-8", errors="strict")
    fields = {}
    for line in text.splitlines():
        for prefix in ("E02_CONFIG_FACTS=", "E02_MARKER_BEHAVIOR="):
            if line.startswith(prefix):
                fields[prefix[:-1]] = json.loads(line[len(prefix):])
    records.append({
        "case": name, "config": str(config), "config_sha256": sha(config),
        "argv": argv, "cwd": str(P), "returncode": result.returncode,
        "wall_seconds": time.monotonic() - t, "stdout_sha256": sha(out / "stdout.bin"),
        "stderr_sha256": sha(out / "stderr.bin"), "observed": fields,
        "environment": {k: env.get(k) for k in (
            "PYTHONDONTWRITEBYTECODE", "PYTHONPYCACHEPREFIX", "TMPDIR", "XDG_CACHE_HOME",
            "PYTHONPATH", "PYTEST_PLUGINS", "PYTEST_DISABLE_PLUGIN_AUTOLOAD", "PYTEST_ADDOPTS")},
    })
result = {"scope": "actual pytest Config and unknown-marker behavior only; no product imports, product tests, or conftest loading", "cases": records, "runtime": "UNRUN"}
output = HERE / "results.json"
with output.open("x", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2, sort_keys=True)
    stream.write("\n")
sys.stdout.write(json.dumps({"results": str(output), "sha256": sha(output), "cases": [
    {"case": x["case"], "rc": x["returncode"], "observed": x["observed"]} for x in records
]}, sort_keys=True) + "\n")
