from pathlib import Path
import ast,hashlib,json
ROOT=Path.cwd();OUT=ROOT/'LOCAL/raw/e02-execution-20261027/repairs/V3-basis-history-r1/full-v3-r1/leaf-world-basis';POST=OUT/'postimages';OBS=ROOT/'LOCAL/raw/e02-execution-20261027/repairs/V3-basis-history-r1/full-v3-r1/leaf-observation-basis/postimages';manifest=json.loads((OUT/'manifest.json').read_text())
def put(path,text):
    prepath=OBS/path if (OBS/path).exists() else ROOT/path;pre=prepath.read_bytes() if prepath.exists() else None;body=text.encode();target=POST/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(body)
    if path.endswith('.py'):ast.parse(text)
    manifest['files'].append({'path':path,'preimage_source':'observation-postimage' if (OBS/path).exists() else 'canonical558d','pre_sha256':hashlib.sha256(pre).hexdigest() if pre is not None else None,'post_sha256':hashlib.sha256(body).hexdigest()})
def read(path):return (OBS/path if (OBS/path).exists() else ROOT/path).read_text()
p='policy-engine/src/polisyos/runtime/quality/data_state_substrate.py';s=(POST/p).read_text();s=s.replace('''        _require_selected_profile(ref, "acquisition_historical_evidence_profile_unselected")
        return epoch.load_verified_epoch_statement(''','''        # Nested owner-native refs can predate their CAS copy. The Core reader
        # owns the exact declared default-profile law; never invent a selector.
        return epoch.load_verified_epoch_statement(''',1);(POST/p).write_text(s)
p='policy-engine/tests/integration/core_runtime/test_acquisition_world_semantic_preparation.py'
put(p,'''"""Real-owner witnesses for write-free world preparation and immutable source replay."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from polisyos.core.artifacts import FileSystemCAS
from polisyos.foundry.data_plane import prepare_json_input_binding_values
from polisyos.runtime.quality import data_state_substrate as owner
from polisyos.runtime.quality.substrate_registry import persist_substrate_registry
from polisyos.runtime.quality.world_model_record import world_model_artifact_views
from tests._helpers import world_model_record as world_fixture
from tests.integration.core_runtime.test_acquisition_data_preparation import _observe_store_writes
from tests.integration.core_runtime.test_acquisition_observation_semantics import _case


def test_historical_source_preparation_replays_without_current_overlay_or_writes(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    case = _case(tmp_path)
    expected = case.prepared
    writes = _observe_store_writes(monkeypatch)

    def no_current_owner(**_kwargs: object) -> None:
        raise AssertionError("historical replay requested a current native permit")

    monkeypatch.setattr(case.scenario.overlay, "read_activated_semantic_epoch_observations", no_current_owner)
    observed = owner.replay_acquired_observation_snapshot_preparation(
        FileSystemCAS(case.scenario.store.root),
        base_data_snapshot_ref=expected.base_data_snapshot_ref,
        receipt_ref=expected.receipt_ref, passport_ref=expected.observation_projection.passport_ref,
        boundary_candidate_ref=case.scenario.candidate.candidate_ref,
        source_ref=case.scenario.candidate.statement.source_record_ref,
        observation_id=expected.selected_observation_id, slot_binding=expected.selected_profile,
        transaction_time=case.args["transaction_time"],
    )
    assert observed == expected
    assert writes == []
    assert not case.workspace.exists()


def test_historical_source_replay_requires_exact_boundary_source_join(tmp_path: Path) -> None:
    case = _case(tmp_path)
    prepared = case.prepared
    wrong = case.scenario.candidate.statement.source_record_ref.model_copy(update={"kind": "foreign.opaque"})
    with pytest.raises(owner.DataStateSubstrateError, match="source_binding_mismatch"):
        owner.replay_acquired_observation_snapshot_preparation(
            case.scenario.store, base_data_snapshot_ref=prepared.base_data_snapshot_ref,
            receipt_ref=prepared.receipt_ref, passport_ref=prepared.observation_projection.passport_ref,
            boundary_candidate_ref=case.scenario.candidate.candidate_ref, source_ref=wrong,
            observation_id=prepared.selected_observation_id, slot_binding=prepared.selected_profile,
            transaction_time=case.args["transaction_time"],
        )


def _world_case(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    case = _case(tmp_path / "source")
    monkeypatch.setattr(world_fixture, "FileSystemCAS", lambda _path: case.scenario.store)
    store, base, _model, _registry = world_fixture._build_record(tmp_path / "base")
    substrate = world_fixture._substrate_registry()
    views = world_model_artifact_views(base.record)
    plan = owner._prepare_acquired_observation_world(
        store, base_world_model_record=base.record, acquired_rule=case.prepared.foundry_binding_rule,
        registry_bundle_ref=views.registry_bundle_ref, substrate_registry=substrate,
    )
    numerical = prepare_json_input_binding_values(
        store, payload_json=case.prepared.payload_json,
        registry_bundle_ref=views.registry_bundle_ref, rules=list(plan.rules),
    )
    return case, base, substrate, views, numerical


def test_prospective_world_values_write_nothing_and_match_the_actual_produced_world(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    case, base, substrate, views, numerical = _world_case(tmp_path, monkeypatch)
    writes = _observe_store_writes(monkeypatch)
    before = owner.prepare_acquired_observation_world_semantic_values(
        store=case.scenario.store, base_world_model_record=base.record,
        data_preparation=case.prepared, prepared_state_values=numerical,
        registry_bundle_ref=views.registry_bundle_ref, substrate_registry=substrate,
    )
    assert before["status"] == "established", before
    assert before["predicate_provenance"] == "recomputed"
    assert writes == []
    materialized = owner.materialize_acquired_observation_snapshot(
        case.scenario.store, **case.args, workspace_dir=case.workspace, prepared=case.prepared
    )
    substrate_ref = persist_substrate_registry(case.scenario.store, substrate)
    actual = owner.build_acquired_observation_candidate_world(
        case.scenario.store, base_world_model=base.record, substrate_registry=substrate,
        substrate_registry_artifact_ref=substrate_ref, materialization=materialized,
        workspace_dir=tmp_path / "world", transaction_time=case.args["transaction_time"],
    )
    after = owner.read_acquired_observation_world_semantic_values(
        store=FileSystemCAS(case.scenario.store.root), world_model_record=actual.world_model.record,
        registry_bundle_ref=views.registry_bundle_ref,
    )
    assert after["status"] == "established", after
    assert before["effective_values"] == after["effective_values"]
    # Keep every CAS ref and producer marker, but falsify the actual quality output.
    binding_path = Path(actual.world_model.record.data_forge_binding_ref.binding_path)
    original = binding_path.read_bytes()
    altered = json.loads(original)
    altered["bindings"][0]["quality_gates"][0]["status"] = "fail"
    try:
        binding_path.write_text(json.dumps(altered), encoding="utf-8")
        refused = owner.read_acquired_observation_world_semantic_values(
            store=case.scenario.store, world_model_record=actual.world_model.record,
            registry_bundle_ref=views.registry_bundle_ref,
        )
        assert refused["status"] == "not_established"
    finally:
        binding_path.write_bytes(original)


def test_supplied_state_plan_cannot_self_attest_completeness(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    case, base, substrate, views, _numerical = _world_case(tmp_path, monkeypatch)
    result = owner.prepare_acquired_observation_world_semantic_values(
        store=case.scenario.store, base_world_model_record=base.record,
        data_preparation=case.prepared, prepared_state_values={"complete": True},
        registry_bundle_ref=views.registry_bundle_ref, substrate_registry=substrate,
    )
    assert result["status"] == "not_established"
    assert result["reason_codes"]
''')
for p,addition in {
'policy-engine/src/polisyos/runtime/quality/README.md':'''\n## Prospective acquired-world values\n\n`prepare_acquired_observation_world_semantic_values` and\n`read_acquired_observation_world_semantic_values` return explicit status, predicate\nprovenance, reason codes and effective values. The actual acquired-world producer\nuses the same pure model/rules/limitations and native-row constructors. Preparation\nresolves complete numerical state and registry values without emitting a world.\nHistorical replay reconciles actual native rows, full model/rule/source relations,\nand the existing Data Forge finalizer before projecting occurrence roles. Active\nSKG references, other executable graphs, QC-dependent finalization and unresolved\nowners remain `not_established`; this is not a generic-world completeness claim.\n\n`replay_acquired_observation_snapshot_preparation` reconstructs the real historical\npreparation from compact base/receipt/passport/boundary/source/row/binding/time\nselectors and optional exact typed activation. It replays immutable admission\nevidence and source bytes, then calls the native producer's shared constructor.\nIt emits no DataSnapshot/WMR and grants no current admission or retention permit.\n''',
'policy-engine/src/polisyos/data_forge/kernel/README.md':'''\n## Write-free publish and binding meaning\n\n`prepare_publish_manifest` is the actual publisher's shared input constructor.\nThe snapshot finalizer uses one full binding-row constructor for writing and\nhistorical readback. `prepare_snapshot_binding_meaning` projects explicit owner\noccurrence roles at constructor inputs; `read_snapshot_binding_meaning` first\nrecomputes the entire emitted row/provenance and source-copy relations. Supplied\nclaim/transform fields retain their meaning; no output-prefix stripping is used.\nThe current candidate profile refuses QC-report-dependent meaning until that\nowner relation is supplied. Occurrence tokens in a prospective meaning projection\nare variable roles, never issued artifact refs or claims that a new publish ran.\n''',
'policy-engine/src/polisyos/data_forge/read_api/README.md':'''\nThe runtime-safe facade exposes the existing publisher JSON reader plus\n`prepare_publish_manifest`, `prepare_snapshot_binding_meaning` and\n`read_snapshot_binding_meaning`. Runtime candidate preparation uses these owner\nconstructors instead of recreating finalization law or treating generated hashes\nas effective source meaning. Historical binding projection rechecks full emitted\nvalues before any owner-generated occurrence field is projected.\n''',
}.items():put(p,read(p)+addition)
p='policy-engine/release-fragments/unreleased/2026-10-29-acquired-world-semantic-preparation.toml'
put(p,'''id = "2026-10-29-acquired-world-semantic-preparation"
title = "Share prospective acquired-world and historical source preparation"
type = "added"
component = "runtime-quality"
owner = "team-runtime"
summary = "Reuse actual model/rule/native/publish/finalizer constructors for write-free candidate world comparison and immutable historical source replay."
evidence = ["tests/integration/core_runtime/test_acquisition_world_semantic_preparation.py"]
compatibility = "Existing publication and world wire meanings remain unchanged. New read/preparation ports are candidate values, never current eligibility or retention permission."
change_class = "python-public-api"
surface_classification = "public_experimental: polisyos.data_forge.read_api; internal: polisyos.runtime.quality"
migration = "Compose the observation-owner prerequisite first, regenerate public inventory and run the real prospective/actual/fresh-history oracle before enabling retention."
api = "Adds shared pure publisher/finalizer meaning and acquired-world preparation/read ports with explicit not_established results for unsupported profiles."
limitations = "QC-dependent finalization, executable graph families and active SKG references without a complete selected owner relation remain not_established. Runtime tests are required before rollout."
generated_client_compatibility = "not_applicable"
public_surface_inventory_reviewed = false
migration_docs = ["src/polisyos/runtime/quality/README.md", "src/polisyos/data_forge/kernel/README.md", "src/polisyos/data_forge/read_api/README.md"]
runbook_docs = []

[[compatibility_change]]
id = "acquired-world-preparation-owner-ports"
change_class = "python-public-api"
impact = "additive"
surface = "public_experimental: polisyos.data_forge.read_api"
owner = "team-runtime"
version_owner = "team-data-forge"
deprecation_window = "2 minor releases"
release_note = "Expose shared publisher/finalizer candidate-meaning constructors and historical binding readback through the runtime-safe facade."
generated_client_compatibility = "not_applicable"
migration_docs = ["src/polisyos/data_forge/read_api/README.md"]
runbook_docs = []
''')
for row in manifest['files']:
    row['post_sha256']=hashlib.sha256((POST/row['path']).read_bytes()).hexdigest()
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'postimages':len(manifest['files']),'runtime':'UNRUN'}))
