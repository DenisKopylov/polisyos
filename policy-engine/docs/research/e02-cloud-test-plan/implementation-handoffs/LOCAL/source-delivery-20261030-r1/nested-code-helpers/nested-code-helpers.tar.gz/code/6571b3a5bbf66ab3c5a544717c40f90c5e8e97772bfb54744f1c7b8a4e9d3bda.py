"""Scientist compute surface for job execution contracts."""

from __future__ import annotations

import importlib
from typing import TYPE_CHECKING, Any

from .job_spec import JobKey, JobResult, JobSpec, MethodExecutionCaptureProvenance
from .runner import MethodBackend, read_job_result_method_execution_capture, run_job

if TYPE_CHECKING:
    from polisyos.scientist.nodes.builtins.decide.policy_runtime_method_metrics import (
        MAX_METHOD_METRIC_SOURCE_BYTES,
    )
    from polisyos.scientist.nodes.builtins.decide.policy_runtime_method_metrics import (
        _BoundedExecutionSourceReader as BoundedMethodMetricSourceReader,
    )
    from polisyos.scientist.nodes.builtins.decide.policy_runtime_method_metrics import (
        _ProjectionReadBudget as MethodMetricSourceReadBudget,
    )
    from polisyos.scientist.nodes.builtins.decide.policy_runtime_method_metrics import (
        _read_bounded_method_metric_artifact as read_bounded_method_metric_artifact,
    )
    from polisyos.scientist.nodes.builtins.decide.policy_runtime_method_metrics import (
        _selected_ref as selected_method_metric_ref,
    )
    from polisyos.scientist.nodes.builtins.decide.policy_runtime_method_metrics import (
        _VerifiedRestrictedExAnteCall as VerifiedRestrictedExAnteCall,
    )

__all__ = [
    "C7AdvancedInputs",
    "C7AdvancedSuiteResult",
    "C7PersistedArtifact",
    "BoundedMethodMetricSourceReader",
    "MAX_METHOD_METRIC_SOURCE_BYTES",
    "MethodMetricSourceReadBudget",
    "VerifiedRestrictedExAnteCall",
    "read_bounded_method_metric_artifact",
    "selected_method_metric_ref",
    "JobKey",
    "JobResult",
    "JobSpec",
    "MethodExecutionCaptureProvenance",
    "MethodBackend",
    "read_job_result_method_execution_capture",
    "run_c7_advanced_suite",
    "run_job",
]

_ADVANCED_EXPORTS = {
    "C7AdvancedInputs",
    "C7AdvancedSuiteResult",
    "C7PersistedArtifact",
    "run_c7_advanced_suite",
}


_METHOD_METRIC_OWNER_EXPORTS = {
    "BoundedMethodMetricSourceReader": "_BoundedExecutionSourceReader",
    "MAX_METHOD_METRIC_SOURCE_BYTES": "MAX_METHOD_METRIC_SOURCE_BYTES",
    "MethodMetricSourceReadBudget": "_ProjectionReadBudget",
    "VerifiedRestrictedExAnteCall": "_VerifiedRestrictedExAnteCall",
    "read_bounded_method_metric_artifact": "_read_bounded_method_metric_artifact",
    "selected_method_metric_ref": "_selected_ref",
}


def __getattr__(name: str) -> Any:
    if name in _METHOD_METRIC_OWNER_EXPORTS:
        module = importlib.import_module(
            "polisyos.scientist.nodes.builtins.decide.policy_runtime_method_metrics"
        )
        value = getattr(module, _METHOD_METRIC_OWNER_EXPORTS[name])
        globals()[name] = value
        return value
    if name not in _ADVANCED_EXPORTS:
        raise AttributeError(f"module 'polisyos.scientist.compute' has no attribute {name!r}")
    module = importlib.import_module("polisyos.scientist.methods.advanced")
    value = getattr(module, name)
    globals()[name] = value
    return value
