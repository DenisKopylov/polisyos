from .analytics import load

load("polisyos.hidden_lazy_import")
