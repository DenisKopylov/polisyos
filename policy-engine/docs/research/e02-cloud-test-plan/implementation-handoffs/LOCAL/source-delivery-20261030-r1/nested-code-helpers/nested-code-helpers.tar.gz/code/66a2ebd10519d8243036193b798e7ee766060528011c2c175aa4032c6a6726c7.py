def read_session(self) -> Iterator[duckdb.DuckDBPyConnection]:
    """Check byte identity around one complete logical catalog read."""
    active = _ACTIVE_CATALOG_READS.get()
    key = id(self)
    if key in active:
        yield self._con
        return
    self._require_current_read_session()
    token = _ACTIVE_CATALOG_READS.set(active | {key})
    try:
        try:
            yield self._con
        except BaseException as exc:
            self._require_current_read_session()
            if isinstance(exc, duckdb.Error):
                raise CatalogReadSourceError('catalog_read_native_query_unavailable', type(exc).__name__) from exc
            raise
    finally:
        _ACTIVE_CATALOG_READS.reset(token)
