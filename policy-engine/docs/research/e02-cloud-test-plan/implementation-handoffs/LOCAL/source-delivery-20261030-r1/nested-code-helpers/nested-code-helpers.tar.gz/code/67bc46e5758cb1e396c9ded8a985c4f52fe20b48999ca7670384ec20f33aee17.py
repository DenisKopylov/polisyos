"""Expose the declared generic-context residual through actual Funnel evaluation.

This desired-property oracle is expected to fail on the pinned old context
filter. It is a portable programming fixture, not a scientific or fiscal proof.
"""

from __future__ import annotations

from typing import Any

from polisyos.scientist.methods.search.funnel.orchestrator import FunnelOrchestrator
from polisyos.scientist.methods.search.funnel.types import FunnelStage, FunnelStageResult
from polisyos.scientist.methods.search.objective import GDPGrowthObjective


class _ContextConsumingStage(FunnelStage):
    """Declare valid time as a real evaluator input, with a replayable scalar."""

    def __init__(self) -> None:
        self.calls = 0

    @property
    def fidelity_level(self) -> int:
        return 0

    @property
    def stage_name(self) -> str:
        return "context-valid-time-fixture"

    @property
    def estimated_cost_usd(self) -> float:
        return 0.1

    def evaluate(self, candidate: dict[str, Any], context: dict[str, Any]) -> FunnelStageResult:
        self.calls += 1
        valid_time = context["model_config"]["valid_at"]
        source = {
            "gdp_change": {"2026-10-28": 0.1, "2026-10-29": 0.2}[valid_time],
            "metric_units": {"gdp_change": "fixture-unit"},
        }
        assessment = GDPGrowthObjective(expected_unit="fixture-unit").evaluate(source)
        return FunnelStageResult(
            policy_candidate=candidate,
            objective_value=assessment.raw_value,
            score_status=assessment.score_status,
            score_assessment=assessment.score_assessment,
            simulation_results=source,
            is_promising=True,
            feedback={"verdict": "APPROVE"},
            stage_name=self.stage_name,
            fidelity_level=self.fidelity_level,
            compute_cost_usd=self.estimated_cost_usd,
            compute_cost_origin="estimated",
        )


def test_changed_context_consumed_by_the_evaluator_cannot_reuse_old_physical_work() -> None:
    stage = _ContextConsumingStage()
    runtime = FunnelOrchestrator([stage])
    candidate = {"candidate_id": "same-payload-real-context-change"}
    first = runtime.advance(runtime.submit(candidate, {"model_config": {"valid_at": "2026-10-28"}}))
    assert first.final_action == "complete"
    assert first.final_result is not None
    assert first.final_result.objective_value == 0.1

    changed = runtime.advance(
        runtime.submit(candidate, {"model_config": {"valid_at": "2026-10-29"}})
    )

    # A new organizational ID alone does not satisfy the changed scientific
    # input. Assert real producer work and the source-replayed changed value.
    assert stage.calls == 2
    assert changed.final_result is not None
    assert changed.final_result.objective_value == 0.2
    assert first.final_result.objective_value == 0.1
