from types import FunctionType
from importlib import import_module
load = import_module
def body():
    return load("bridge_removed")
CODE = body.__code__
run = FunctionType(CODE, globals())
globals()["load"] = None
run()
