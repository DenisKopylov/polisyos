def _child_main():
    pass
