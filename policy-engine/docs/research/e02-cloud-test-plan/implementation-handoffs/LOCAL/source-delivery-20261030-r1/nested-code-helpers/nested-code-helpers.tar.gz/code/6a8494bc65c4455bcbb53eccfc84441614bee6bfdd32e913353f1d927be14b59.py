"""Synthetic checks of the real candidate controller seed-binding gate."""

from __future__ import annotations

import ast
import importlib.util
import json
import sys
from pathlib import Path

PACKET = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "r4_corrected_seed_controller", PACKET / "controller.py"
)
assert spec is not None and spec.loader is not None
controller = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = controller
spec.loader.exec_module(controller)


def accepted(intent: dict, params: dict) -> bool:
    method = {"launch": {"request_body": {"observational_input": {"method": {"params": params}}}}}
    try:
        controller.require_default_seed_profile(intent, method)
        return True
    except (ValueError, KeyError, TypeError):
        return False


def main() -> None:
    intent = {"seed": 0, "seed_policy_revision": "server_seed_zero_v1"}
    params = {"n_estimators": 512, "cv_folds": 2, "subforest_size": 4, "n_jobs": 1}
    tree = ast.parse((PACKET / "controller.py").read_bytes())
    function = next(
        node
        for node in tree.body
        if isinstance(node, ast.FunctionDef) and node.name == "qualify_case"
    )
    assignments = [
        node
        for node in ast.walk(function)
        if isinstance(node, ast.Assign)
        and any(
            isinstance(target, ast.Name) and target.id == "required_params"
            for target in node.targets
        )
    ]
    assert len(assignments) == 1
    required = ast.literal_eval(assignments[0].value)
    checks = {
        "server_zero_and_omitted_override_accepted": accepted(intent, params),
        "explicit_original_override_rejected": not accepted(intent, {**params, "random_state": 73}),
        "even_explicit_null_override_rejected": not accepted(
            intent, {**params, "random_state": None}
        ),
        "nonzero_seed_rejected": not accepted({**intent, "seed": 73}, params),
        "boolean_seed_rejected": not accepted({**intent, "seed": False}, params),
        "wrong_seed_policy_rejected": not accepted(
            {**intent, "seed_policy_revision": "other"}, params
        ),
        "missing_seed_rejected": not accepted(
            {"seed_policy_revision": "server_seed_zero_v1"}, params
        ),
        "required_resolved_profile_is_exact": required
        == {
            "n_estimators": 512,
            "cv_folds": 2,
            "subforest_size": 4,
            "random_state": None,
            "n_jobs": 1,
        },
        "resolved_param_presence_required": any(
            isinstance(node, ast.Compare)
            and isinstance(node.left, ast.Name)
            and node.left.id == "k"
            and len(node.ops) == 1
            and isinstance(node.ops[0], ast.In)
            and len(node.comparators) == 1
            and isinstance(node.comparators[0], ast.Subscript)
            and isinstance(node.comparators[0].value, ast.Name)
            and node.comparators[0].value.id == "method"
            and isinstance(node.comparators[0].slice, ast.Constant)
            and node.comparators[0].slice.value == "effective_params"
            for node in ast.walk(function)
        ),
    }
    payload = {
        "pass": all(checks.values()),
        "checks": checks,
        "scope": "synthetic controller helper and bounded AST check; no product import or native execution",
        "closure_ids": [],
    }
    print(json.dumps(payload, indent=2, sort_keys=True))
    if not payload["pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
