from __future__ import annotations
import ast,collections,difflib,hashlib,json,pathlib,subprocess,tomllib
R=pathlib.Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos');F=R/'LOCAL/raw/e02-execution-20261027/repairs/V3-basis-history-r1/full-v3-r1';A=F/'candidate-r1';X=F/'candidate-r2'
old=json.loads((A/'manifest.json').read_text());assert hashlib.sha256((A/'manifest.json').read_bytes()).hexdigest()=='60daab3237d6ad337c909f10d1172ed99dc2346c8596ec6f37e073108587fe99'
for row in old['files']: assert hashlib.sha256(pathlib.Path(row['postimage']).read_bytes()).hexdigest()==row['post_sha256']
files={row['path']:pathlib.Path(row['postimage']) for row in old['files']};delta={p.relative_to(X/'postimages').as_posix():p for p in (X/'postimages').rglob('*') if p.is_file()};files.update(delta)
ruff=[str(R/'policy-engine/.venv/bin/python'),'-m','ruff'];config=str(R/'policy-engine/architecture/tooling/ruff/workspace_root.toml');statics=[]
# Existing r1 members retain their exact prior checks. Recheck changed inputs only.
for rel,p in sorted(delta.items()):
 row={'path':rel,'input_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 if p.suffix=='.py':
  ast.parse(p.read_bytes(),filename=str(R/rel));row['ast']='PASS'
  for op in ('check','format'):
   command=ruff+[op]+(['--no-cache'] if op=='check' else ['--check'])+['--config',config,'--stdin-filename',str(R/rel),'-']
   q=subprocess.run(command,input=p.read_bytes(),capture_output=True)
   row[op+'_exit']=q.returncode
   if q.returncode:row[op+'_diagnostics']=q.stdout.decode()+q.stderr.decode()
 elif p.suffix=='.toml':tomllib.loads(p.read_text());row['toml']='PASS'
 statics.append(row)
if any(row.get('check_exit',0) or row.get('format_exit',0) for row in statics):
 print(json.dumps(statics,indent=2));raise SystemExit(1)
(X/'checks/delta-static.json').write_text(json.dumps({'scope':'All changed r2 inputs; unchanged r1 exact bytes retain r1 static evidence','runtime':'UNRUN','files':statics},indent=2)+'\n')
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=R,text=True).strip();branch=subprocess.check_output(['git','symbolic-ref','--short','HEAD'],cwd=R,text=True).strip();ledger=json.loads((R/'LOCAL/raw/root-live-ownership-20261021.json').read_text());assert(base,tree,branch)==(ledger['head'],ledger['tree'],ledger['branch'])
rows=[];full=[];change=[];counts=collections.Counter();holds=[]
oldpaths={row['path']:pathlib.Path(row['postimage']) for row in old['files']}
for rel,p in sorted(files.items()):
 after=p.read_bytes();before=subprocess.run(['git','show',base+':'+rel],cwd=R,capture_output=True);b=before.stdout if before.returncode==0 else None
 actual=R/rel
 if b is None and actual.exists():holds.append({'path':rel,'reason':'untracked canonical destination exists'})
 if b is not None and (not actual.exists() or actual.read_bytes()!=b):holds.append({'path':rel,'reason':'canonical committed/work preimage mismatch'})
 oldrow=next((row for row in old['files'] if row['path']==rel),None)
 if oldrow and (hashlib.sha256(b).hexdigest() if b is not None else None)!=oldrow['pre_sha256']:holds.append({'path':rel,'reason':'Root changed a shared preimage; explicit union required'})
 row={'path':rel,'pre_sha256':hashlib.sha256(b).hexdigest() if b is not None else None,'post_sha256':hashlib.sha256(after).hexdigest(),'preimage':f'git:{base}:{rel}' if b is not None else 'absent','postimage':str(p),'bytes':len(after),'change':'modify' if b is not None else 'add','r2_delta':rel in delta};rows.append(row);counts[p.suffix]+=1
 full.extend(difflib.unified_diff((b or b'').decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),fromfile='a/'+rel if b is not None else '/dev/null',tofile='b/'+rel,n=3))
 if rel in delta:
  prior=oldpaths[rel].read_bytes() if rel in oldpaths else None
  change.extend(difflib.unified_diff((prior or b'').decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),fromfile='a/'+rel if prior is not None else '/dev/null',tofile='b/'+rel,n=3))
if holds:(X/'preimage-holds.json').write_text(json.dumps(holds,indent=2)+'\n');print(json.dumps(holds,indent=2));raise SystemExit(2)
checks=[]
for name,body,directory in [('source.diff',''.join(full).encode(),None),('source-r1-to-r2.diff',''.join(change).encode(),str((A/'postimages').relative_to(R)))]:
 p=X/name;p.write_bytes(body);cmd=['git','apply','--check','--whitespace=error']+(['--directory',directory] if directory else [])+['--',str(p)];q=subprocess.run(cmd,cwd=R,capture_output=True);(X/'checks'/(name+'.stdout')).write_bytes(q.stdout);(X/'checks'/(name+'.stderr')).write_bytes(q.stderr);checks.append({'path':str(p),'sha256':hashlib.sha256(body).hexdigest(),'bytes':len(body),'apply_check_exit':q.returncode,'applies_to':'canonical '+base if directory is None else 'frozen r1 postimages','stderr':q.stderr.decode()})
if any(c['apply_check_exit'] for c in checks):print(json.dumps(checks,indent=2));raise SystemExit(3)
selectors=[]
for rel,p in sorted(files.items()):
 if p.suffix=='.py' and p.name.startswith('test_'):
  for n in ast.parse(p.read_bytes()).body:
   if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_'):selectors.append({'selector':rel.removeprefix('policy-engine/')+'::'+n.name,'source':str(p)})
(X/'test-selectors.json').write_text(json.dumps({'scope':'Complete changed union top-level test functions, parametrizations require collection','runtime':'UNRUN','selectors':selectors},indent=2)+'\n')
manifest={'schema':'policyos.e02.raw-composition-intake.v2','status':'author_proposal_unapplied','owner':'/root/v3_basis_history_oracle','root_sole_canonical_writer':True,'base_commit':base,'base_tree':tree,'branch':branch,'r1':{'manifest':str(A/'manifest.json'),'sha256':'60daab3237d6ad337c909f10d1172ed99dc2346c8596ec6f37e073108587fe99','postimages':'all63 immutable, readback PASS'},'storage':'Unchanged files reuse immutable r1 postimages; only eight delta files have new r2 copies','expected_source_files':len(rows),'file_type_denominator':dict(counts),'delta_paths':sorted(delta),'files':rows,'patches':checks,'checks':{'delta_static':str(X/'checks/delta-static.json'),'unchanged_static':str(A/'static-verification.json'),'product_imports':'UNRUN','runtime':'UNRUN','pytest':'UNRUN','removals':'UNRUN','generators':'UNRUN'},'independent_reviews':{'runtime_M1_delta':{'path':str(F.parent/'leaf-input-review/candidate-r2-witness-construction-lookup-review.md'),'sha256':'19f3ee7cd5e0a88c7a3347b06cda146554e8472702e39b1394b371644c419b7d','scope':'bounded2productpaths sourceGO; no runtime'},'store_bridge':'unchanged r1 complete bounded SOURCEGO retained; no runtime','oracle_surface':'r1 OS01 repair authored; Root delta re-review required'},'original_e02_denominator':old['original_e02_denominator'],'canonical_original_occurrences':old['canonical_original_occurrences'],'selected_decision':'AD-E02-B09-01','mandatory_pending_companions':old['mandatory_pending_companions'],'closure_ids':[]}
(X/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
assert json.loads((X/'manifest.json').read_text())['files']==rows
for row in rows:assert hashlib.sha256(pathlib.Path(row['postimage']).read_bytes()).hexdigest()==row['post_sha256']
print(json.dumps({'base':base,'tree':tree,'union_files':len(rows),'file_type_denominator':dict(counts),'delta_paths':sorted(delta),'manifest_sha256':hashlib.sha256((X/'manifest.json').read_bytes()).hexdigest(),'patches':checks,'top_level_test_functions':len(selectors),'postimage_readback':'PASS','r1_immutable':'PASS'},indent=2))
