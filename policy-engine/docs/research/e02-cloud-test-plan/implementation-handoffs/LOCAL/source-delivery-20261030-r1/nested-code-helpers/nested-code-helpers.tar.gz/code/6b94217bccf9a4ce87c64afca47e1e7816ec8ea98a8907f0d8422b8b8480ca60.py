def identify_read_sources(database_path: Path, *, overlay_path: Path | None=None) -> tuple[CatalogContentIdentity, str | None, CatalogContentIdentity | None]:
    """Stream exact checkpointed read-source identities with bounded memory.

        A live native WAL is part of the database state, not an ignorable
        neighboring file. This byte-identity protocol refuses it until its
        owner checkpoints/closes the writer; it never deletes native files.
        The scan does not claim an atomic filesystem custody transaction.
        """

    def identify(path: Path) -> CatalogContentIdentity:
        if not path.is_file():
            raise CatalogReadSourceError('catalog_read_source_unavailable')
        wal = path.with_name(path.name + '.wal')
        digest = hashlib.sha256()
        byte_size = 0
        with path.open('rb') as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b''):
                digest.update(chunk)
                byte_size += len(chunk)
        return CatalogContentIdentity(source_path=str(path.resolve()), content_sha256=f'sha256:{digest.hexdigest()}', byte_size=byte_size)
    try:
        overlay = overlay_path
        present = overlay is not None and (overlay.exists() or overlay.is_symlink())
        return (identify(database_path), str(overlay.resolve()) if overlay is not None else None, identify(overlay) if present else None)
    except CatalogReadSourceError:
        raise
    except (OSError, RuntimeError, ValueError) as exc:
        raise CatalogReadSourceError('catalog_read_source_unavailable', type(exc).__name__) from exc
