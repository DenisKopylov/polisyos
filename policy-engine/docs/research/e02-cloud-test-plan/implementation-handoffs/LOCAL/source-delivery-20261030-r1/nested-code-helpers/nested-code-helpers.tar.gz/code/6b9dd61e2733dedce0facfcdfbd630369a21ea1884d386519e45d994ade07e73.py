import types
from importlib import import_module
def body(callback):
    return callback("bridge_callback")
CODE = body.__code__
types.FunctionType = opaque
run = types.FunctionType(CODE, globals())
run(import_module)
