from types import FunctionType
def body(value=None):
    return value
CODE = body.__code__
run = FunctionType(CODE, globals(), "copy", (None,))
run()
