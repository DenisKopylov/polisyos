"""Check frozen removal patches against RAW postimages without applying them."""
from __future__ import annotations

import hashlib
import json
import subprocess
from pathlib import Path

root = Path("LOCAL/raw/e02-execution-20261027/repairs/SQL-owner-chain-r3")
rows = []
for name in ("remove-currentness", "remove-callable-binding"):
    patch = root / f"frozen-77e00604/controls/{name}.patch"
    command = [
        "git", "apply", "--check", "--whitespace=error", f"--directory={root}/postimages",
        str(patch),
    ]
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    out = root / f"checks/final-{name}-apply.stdout"
    err = root / f"checks/final-{name}-apply.stderr"
    out.write_bytes(result.stdout)
    err.write_bytes(result.stderr)
    rows.append({
        "command": command, "exit": result.returncode,
        "stdout": str(out), "stdout_sha256": hashlib.sha256(result.stdout).hexdigest(),
        "stderr": str(err), "stderr_sha256": hashlib.sha256(result.stderr).hexdigest(),
    })
    print(name, result.returncode)
(root / "checks/control-apply.json").write_text(json.dumps(rows, indent=2) + "\n")
if any(row["exit"] for row in rows):
    raise SystemExit(1)
