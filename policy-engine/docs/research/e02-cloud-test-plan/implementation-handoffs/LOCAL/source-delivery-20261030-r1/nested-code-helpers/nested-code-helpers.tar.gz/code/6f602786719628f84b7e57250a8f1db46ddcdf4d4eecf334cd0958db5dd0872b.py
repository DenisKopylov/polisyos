from pathlib import Path
import ast
r1=Path('LOCAL/raw/e02-execution-20261027/repairs/C49-local-r1');r2=r1.with_name('C49-local-r2')
def put(rel,text):
 rel=Path(rel);pre=r2/'preimages'/rel;post=r2/'postimages'/rel
 if not pre.exists() and (r1/'postimages'/rel).exists():
  pre.parent.mkdir(parents=True,exist_ok=True);pre.write_text((r1/'postimages'/rel).read_text())
 post.parent.mkdir(parents=True,exist_ok=True);ast.parse(text);post.write_text(text)
rel='policy-engine/tests/unit/scientist/search/test_stopping_c49.py'
s=(r1/'postimages'/rel).read_text()+'''

@pytest.mark.parametrize("direction,within,beyond", [
    ("minimize", -0.005, -0.02), ("maximize", 0.005, 0.02),
])
def test_absolute_tolerance_controls_small_gain_from_zero(direction, within, beyond):
    profile = PlateauToleranceProfile(direction, "fixture-points", 0.01, 0.01)
    criterion = ImprovementPlateau(patience=2, tolerance_profile=profile)
    assert criterion.check(_history(0.0, within, within), {}).should_stop
    assert not criterion.check(_history(0.0, beyond, beyond), {}).should_stop
    # Regressions on either sign are not mistaken for useful progress.
    assert criterion.check(_history(0.0, -within, -within), {}).should_stop


@pytest.mark.parametrize("direction,values", [
    ("minimize", (0.0, -0.005, -0.005)),
    ("maximize", (0.0, 0.005, 0.005)),
    ("minimize", (-1.0, -1.02, -1.02)),
    ("maximize", (-1.0, -0.98, -0.98)),
])
def test_coherent_value_and_absolute_tolerance_scale_conversion(direction, values):
    outcomes = []
    for scale in (1.0, 1000.0):
        criterion = ImprovementPlateau(patience=2, tolerance_profile=PlateauToleranceProfile(
            direction, "fixture-points" if scale == 1.0 else "fixture-millipoints",
            0.01 * scale, 0.01,
        ))
        result = criterion.check(_history(*(value * scale for value in values)), {})
        outcomes.append(result.should_stop)
    assert outcomes[0] == outcomes[1]
'''
put(rel,s)
rel='policy-engine/tests/unit/scientist/agent/test_drafter_profile_intake_c49.py'
s=(r2/'postimages'/rel).read_text()+'''

def test_actual_sanitized_restoration_retains_grade_with_named_unestablished_relation():
    import json
    import re
    from types import SimpleNamespace
    from polisyos.core.llm.sanitization import PromptSanitizer
    class RestoringWire:
        def __init__(self):
            self.calls = []
            self.produced = ""
        async def generate(self, **kwargs):
            self.calls.append(kwargs)
            placeholder = re.search(r"\\[POLISYOS_SECRET_EMAIL_[a-f0-9]+\\]", kwargs["user"])
            assert placeholder is not None
            payload = json.loads(_draft())
            payload["narrative"] = "Contact " + placeholder.group(0)
            self.produced = json.dumps(payload)
            return SimpleNamespace(
                content=self.produced, model_version="fixture-weights-1", cost_usd=0.001,
                usage=SimpleNamespace(prompt_tokens=1, completion_tokens=1),
            )
    provider = RestoringWire()
    events = []
    traced = TracedLLMClient(
        provider, model_name="fixture-model", prompt_sanitizer=PromptSanitizer(),
        call_observer=events.append,
    )
    problem = replace(_problem(), problem_statement="Contact fixture.user@example.org")
    agent = MultiPassLLMDrafter(LLMDrafterAgent(traced), config=MultiPassConfig(
        max_passes=3, convergence=ConvergenceConfig(min_iterations=1, max_iterations=1),
        enable_memory_logging=False,
    ))
    result = asyncio.run(agent.draft_policy(problem))
    view = result.convergence_state.last_checked_observation
    import hashlib
    assert len(provider.calls) == 1
    assert result.narrative == "Contact fixture.user@example.org"
    assert view.value == result.confidence
    assert view.producer_request_ref == events[0]["producer_event"].request_digest
    assert view.producer_response_ref == hashlib.sha256(provider.produced.encode()).hexdigest()
    assert view.source_ref == hashlib.sha256(result.raw_llm_response.encode()).hexdigest()
    assert view.response_binding_status == "not_established"
    assert view.producer_response_ref != view.source_ref
    assert result.convergence_state.observation_status == "producer_consumer_response_relation_not_established"
    assert result.convergence_state.stop_kind == "resource_limit"
    assert not result.convergence_state.scientific_converged


def test_actual_drafter_budget_pressure_without_admitted_signal_keeps_final_reason_and_metric():
    from decimal import Decimal
    from polisyos.scientist.orchestration.engine.budget import BudgetLimit, BudgetState
    class Span:
        def __init__(self, owner): self.owner = owner
        def __enter__(self): return self
        def __exit__(self, *args): return None
        def set_attribute(self, name, value): self.owner.attributes[name] = value
        def set_status(self, value): pass
        def record_exception(self, error): pass
    class Trace:
        def __init__(self): self.attributes = {}
        def start_as_current_span(self, *args, **kwargs): return Span(self)
    class Metrics:
        def __init__(self): self.runs = []
        def record_drafter_multipass_run(self, **kwargs): self.runs.append(kwargs)
        def record_drafter_multipass_pass(self, **kwargs): pass
    for spent, pressured in (("0.96", True), ("0.20", False)):
        provider = WireProvider([_draft()], version=None)
        trace, metrics = Trace(), Metrics()
        state = BudgetState(
            limits={"run": BudgetLimit(key="run", max_usd=Decimal("1.00"))},
            spent={"run": Decimal(spent)},
        )
        agent = MultiPassLLMDrafter(LLMDrafterAgent(provider), config=MultiPassConfig(
            max_passes=1, constitution_enabled=False, enable_memory_logging=False,
            convergence=ConvergenceConfig(budget_key="run"),
        ), convergence_budget_state=state, tracer=trace, metrics=metrics)
        result = asyncio.run(agent.draft_policy(_problem()))
        assert len(provider.calls) == 1 and result.narrative == "Useful candidate"
        assert result.convergence_state.observation_status == "model_version_not_established"
        assert not result.convergence_state.scientific_converged
        assert metrics.runs[-1]["budget_stop"] is pressured
        if pressured:
            assert result.convergence_state.stop_kind == "resource_limit"
            assert result.convergence_state.reason == "budget_pressure"
            assert trace.attributes["polisyos.drafter.stop_reason"] == "resource_limit:budget_pressure"
        else:
            assert not result.convergence_state.should_stop
            assert result.convergence_state.stop_kind == "none"
'''
put(rel,s)
print('R3/R5 actual restored-wire and allocation-pressure consumers plus near-zero/coherent-scale oracles prepared; runtime UNRUN.')
