from types import FunctionType
from importlib import import_module
def body():
    return load("bridge_mutation")
CODE = body.__code__
run = FunctionType(CODE, globals())
load = import_module
run()
