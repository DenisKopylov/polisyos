def _catalog_publish_admission(self, catalog: object, run_profile: CatalogRunProfile | None) -> tuple[str, str, dict[str, object] | None]:
    """Join recomputed local publish currentness to the exact open DB session."""
    if run_profile is None:
        return ('not_established', 'catalog_run_profile_unresolved', None)
    path = getattr(catalog, 'database_path', None)
    identity_reader = getattr(catalog, 'source_content_identities', None)
    if not isinstance(path, Path) or not callable(identity_reader):
        return ('not_established', 'catalog_open_session_identity_unavailable', None)
    try:
        baseline, _overlay_path, overlay = identity_reader()
        if overlay is not None:
            return ('not_established', 'catalog_overlay_not_bound_by_publish_receipt', None)
        resolver = cast('Callable[..., dict[str, object]]', catalog_read_api._current_catalog_publish_receipt)
        receipt = resolver(path, run_profile=run_profile)
    except Exception as exc:
        return ('not_established', 'catalog_publish_receipt_unavailable', None)
    state = str(receipt.get('state') or 'not_established')
    if state != 'current':
        return (state, str(receipt.get('reason') or 'receipt_not_current'), None)
    expected = {'source_path': baseline.source_path, 'content_sha256': baseline.content_sha256, 'byte_size': baseline.byte_size}
    if receipt.get('database_identity') != expected:
        return ('stale', 'publish_database_identity_differs_from_open_session', None)
    profile_coverage = receipt.get('profile_input_coverage')
    if receipt.get('profile_input_coverage_state') != 'established' or not isinstance(profile_coverage, dict):
        return ('not_established', 'catalog_profile_input_coverage_unknown', None)
    return ('current', 'publish_receipt_matches_open_session', profile_coverage)
