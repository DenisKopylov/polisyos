from types import FunctionType
from importlib import import_module
class Plain:
    def load(self, callback):
        return callback("bridge_class")
CODE = Plain.load.__code__
run = FunctionType(CODE, globals())
run(None, import_module)
