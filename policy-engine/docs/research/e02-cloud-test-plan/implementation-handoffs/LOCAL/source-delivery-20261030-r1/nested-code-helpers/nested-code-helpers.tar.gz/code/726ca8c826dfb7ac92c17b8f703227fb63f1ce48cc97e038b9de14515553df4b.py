"""Reconstruct an already cited test-only predecessor and preserve both packets."""
from __future__ import annotations

import difflib
import hashlib
import json
from pathlib import Path

root = Path("LOCAL/raw/e02-execution-20261027/repairs/SQL-owner-chain-r3")
current = (root / "source.diff").read_text()
pins = json.loads((root / "file-pins.json").read_text())
path = "policy-engine/tests/unit/runtime/http/test_debug_registered_sql_graph.py"
post = (root / "postimages" / path).read_text()
assert "import pytest" not in post
post = post.replace("from __future__ import annotations\n\n", "from __future__ import annotations\n\nimport pytest\n\n", 1)
post = post[:post.index("def test_actual_compiler_graph_with_unsupported_dependency_is_refused()")] + '''@pytest.mark.parametrize(
    "mutation",
    [
        ("hidden_read",),
        ("constraint",),
        ("extra_operation",),
        ("omitted_edge",),
        ("reordered_nodes",),
    ],
)
def test_actual_compiler_graph_with_unsupported_dependency_is_refused(mutation: str) -> None:
    graph = _actual_compiler_graph()
    method, merge, check = graph.nodes
    if mutation == "hidden_read":
        nodes = [method.model_copy(update={"inputs": ["baseline", "scenario", "hidden"]}),
                 merge, check]
        changed = graph.model_copy(update={"nodes": nodes})
    elif mutation == "constraint":
        changed_check = check.model_copy(
            update={"op": ProgramOp(op_kind="check_constraints", params={"constraint_ids": ["x"]})}
        )
        changed = graph.model_copy(update={"nodes": [method, merge, changed_check]})
    elif mutation == "extra_operation":
        extra = ProgramNode(node_id="hidden", node_kind="op", op=ProgramOp(op_kind="read_view"))
        changed = graph.model_copy(update={"nodes": [method, merge, check, extra]})
    elif mutation == "omitted_edge":
        changed = graph.model_copy(
            update={"edges": [ProgramEdge(src="op.merge_state", dst="op.check_constraints")]}
        )
    else:
        changed = graph.model_copy(update={"nodes": [method, check, merge]})

    assert not _is_supported_restricted_graph(changed, method_node_id="ex_ante_node")
'''
new_block = (
    f"diff --git a/{path} b/{path}\nnew file mode 100644\n"
    + "".join(difflib.unified_diff(
        [], post.splitlines(keepends=True), fromfile="/dev/null", tofile=f"b/{path}"
    ))
)
header = f"diff --git a/{path} b/{path}\n"
begin = current.index(header)
end = current.find("diff --git a/", begin + len(header))
if end < 0:
    end = len(current)
old_diff = (current[:begin] + new_block + current[end:]).encode()
old_hash = hashlib.sha256(old_diff).hexdigest()
assert old_hash == "cfe1a9f5c142839cc68a3bc51b603fe020ee36bf4e94cca79e558964cf04b992", old_hash
entry = next(item for item in pins["files"] if item["path"] == path)
entry["post_sha256"] = hashlib.sha256(post.encode()).hexdigest()
old_pins = (json.dumps(pins, indent=2) + "\n").encode()
pins_hash = hashlib.sha256(old_pins).hexdigest()
assert pins_hash == "257ac816aee9aec1cb6df5d7dcf7f7e7550d1072b3dda7d854fa203d2c57b97a", pins_hash
for label, diff, manifest in (
    ("frozen-cfe1", old_diff, old_pins),
    ("frozen-8ccbbe", (root / "source.diff").read_bytes(), (root / "file-pins.json").read_bytes()),
):
    target = root / label
    target.mkdir(exist_ok=False)
    (target / "source.diff").write_bytes(diff)
    (target / "file-pins.json").write_bytes(manifest)
    print(label, hashlib.sha256(diff).hexdigest(), hashlib.sha256(manifest).hexdigest())
