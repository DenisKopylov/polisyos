from types import FunctionType
from importlib import import_module
def body():
    return import_module("bridge_literal")
CODE = body.__code__
run = FunctionType(CODE, globals())
run()
