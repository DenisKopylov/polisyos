"""Isolate one OpenAPI corruption test's cwd; capture its exact checker text."""

from __future__ import annotations

import contextlib
import hashlib
import inspect
import json
import os
import subprocess
import sys
import tempfile
from collections.abc import Iterator  # noqa: TC003 -- pytest may inspect hook annotations
from pathlib import Path
from types import ModuleType  # noqa: TC003 -- retained for runtime annotation consumers

import pytest

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
P = ROOT / "policy-engine"
D = P / (
    "docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/"
    "root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/"
    "deep-task-status-audit-20261027-r1"
)
TEST = "tests/unit/runtime/http/test_runtime_api_contract_hardening.py"
NODE = TEST + "::test_runtime_contract_gate_rejects_nested_epoch_semantic_corruption"
APP = P / "src/polisyos/runtime/http/app.py"
PLUGIN_NAME = "e02_q2_cwd_guard"
WORK_NAME = "q2-isolated-test-cwd"
RECEIPT = "q2-cwd-receipt.json"
SETUP_RECEIPT = "q2-setup-observation.json"
RESOURCE_KEYS = (
    "TMPDIR",
    "XDG_CACHE_HOME",
    "MPLCONFIGDIR",
    "NUMBA_CACHE_DIR",
    "HYPOTHESIS_STORAGE_DIRECTORY",
    "POLISYOS_CACHE_HOME",
    "PYTHONPYCACHEPREFIX",
    "PYTHONDONTWRITEBYTECODE",
)
OBSERVED_ENV_KEYS = (
    *RESOURCE_KEYS,
    "PYTHONPATH",
    "PYTEST_PLUGINS",
    "POLISYOS_CAS_BACKEND",
    "POLISYOS_EXECUTION_PROFILE",
    "JAX_PLATFORMS",
    "JAX_PLATFORM_NAME",
    "XLA_PYTHON_CLIENT_PREALLOCATE",
)
ALLOWED_SETUP_ENV_CHANGES = frozenset((*RESOURCE_KEYS, "PYTEST_CURRENT_TEST"))
_SETUP_TRACES: dict[int, dict[str, object]] = {}
PYTEST_PROFILE_SOURCES = {
    "_pytest.mark.structures": (
        "_pytest/mark/structures.py",
        "918f3cb7d117aca993d949c8873b50a02119294493c037e3d93227402b59c392",
    ),
    "_pytest.config": (
        "_pytest/config/__init__.py",
        "ff967dc8cbd4baeaa10b2e370f638ead045306b13926b06d06eb778c3f81e1ea",
    ),
    "_pytest.main": (
        "_pytest/main.py",
        "7ca2b20cc41fbfc2761bcb231eecb26967d553651035c40000f44d70e174b693",
    ),
}


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _check(condition: bool, reason: str) -> None:
    if not condition:
        raise RuntimeError(f"q2_cwd_harness_{reason}")


def _allocate(parent: Path) -> Path:
    """Create a fresh child; reject existing objects including dangling symlinks."""
    work = parent / WORK_NAME
    _check(not os.path.lexists(work), "workspace_already_exists")
    work.mkdir(mode=0o700, exist_ok=False)
    return work


def _case_owned_path(value: object, case: Path, label: str, *, exists: bool = False) -> Path:
    """Validate a case-owned directory without following a descendant symlink."""
    _check(isinstance(value, (str, Path)) and bool(value), f"{label}_missing")
    path = Path(value)
    _check(path.is_absolute() and ".." not in path.parts, f"{label}_invalid")
    _check(path.is_relative_to(case), f"{label}_outside_case")
    cursor = case
    _check(case.is_dir() and not case.is_symlink(), "case_not_owned_directory")
    for part in path.relative_to(case).parts:
        cursor /= part
        _check(not cursor.is_symlink(), f"{label}_symlink")
    _check(path.resolve(strict=False).is_relative_to(case.resolve(strict=True)), f"{label}_escape")
    _check(not os.path.lexists(path) or path.is_dir(), f"{label}_not_directory")
    _check(not exists or path.is_dir(), f"{label}_missing_directory")
    return path


def _resource_snapshot(item: pytest.Item) -> dict[str, object]:
    funcargs = getattr(item, "funcargs", {})
    tmp_path = funcargs.get("tmp_path") if isinstance(funcargs, dict) else None
    return {
        "cwd": str(Path.cwd()),
        "environment": {name: os.environ.get(name) for name in OBSERVED_ENV_KEYS},
        "fixture_tmp_path": str(tmp_path) if tmp_path is not None else None,
        "tempfile_cached": os.fsdecode(tempfile.tempdir) if tempfile.tempdir is not None else None,
        "sys_pycache_prefix": sys.pycache_prefix,
        "dont_write_bytecode": sys.dont_write_bytecode,
        "sys_path": list(sys.path),
    }


def _validate_setup_snapshot(state: dict[str, object], case: Path, label: str) -> None:
    """Check resource ownership at both sides of fixture setup."""
    env = state.get("environment")
    _check(isinstance(env, dict), f"{label}_environment_missing")
    for key in RESOURCE_KEYS:
        if key == "PYTHONDONTWRITEBYTECODE":
            _check(env.get(key) == "1", f"{label}_bytecode_setting_changed")
        else:
            _case_owned_path(env.get(key), case, f"{label}_{key.lower()}", exists=key == "TMPDIR")
    prefix = _case_owned_path(state.get("sys_pycache_prefix"), case, f"{label}_pycache")
    _check(prefix == case / "tmp/empty-pycache", f"{label}_pycache_changed")
    _check(env.get("PYTHONPYCACHEPREFIX") == str(prefix), f"{label}_child_pycache_changed")
    _check(state.get("dont_write_bytecode") is True, f"{label}_bytecode_enabled")
    cached_temp = state.get("tempfile_cached")
    if cached_temp is not None:
        _case_owned_path(cached_temp, case, f"{label}_tempfile")
    cwd = state.get("cwd")
    _check(isinstance(cwd, str), f"{label}_cwd_missing")
    if Path(cwd).resolve() != P.resolve():
        _case_owned_path(cwd, case, f"{label}_cwd", exists=True)


@pytest.hookimpl(wrapper=True, tryfirst=True)
def pytest_runtest_setup(item: pytest.Item) -> Iterator[None]:
    """Observe setup changes, preserving pytest's setup result and exception."""
    nodeid = item.nodeid
    if nodeid != NODE:
        return (yield)
    before_env = dict(os.environ)
    before: dict[str, object]
    errors: list[dict[str, str]] = []
    try:
        before = _resource_snapshot(item)
    except Exception as exc:
        before = {"snapshot_error": type(exc).__name__}
        errors.append({"operation": "before_snapshot", "error_type": type(exc).__name__})
    primary: BaseException | None = None
    try:
        return (yield)
    except BaseException as exc:
        primary = exc
        raise
    finally:
        pending_interrupt: BaseException | None = None

        def observe_error(operation: str, exc: BaseException) -> None:
            nonlocal pending_interrupt
            errors.append({"operation": operation, "error_type": type(exc).__name__})
            if primary is None and not isinstance(exc, Exception) and pending_interrupt is None:
                pending_interrupt = exc

        try:
            after = _resource_snapshot(item)
        except BaseException as exc:
            after = {"snapshot_error": type(exc).__name__}
            observe_error("after_snapshot", exc)
        after_env: dict[str, str] | None = None
        try:
            after_env = dict(os.environ)
        except BaseException as exc:
            observe_error("after_environment", exc)
        changed: list[str] = []
        if after_env is not None:
            try:
                changed = sorted(
                    name
                    for name in before_env.keys() | after_env.keys()
                    if before_env.get(name) != after_env.get(name)
                )
            except BaseException as exc:
                observe_error("environment_diff", exc)
        record: dict[str, object] = {
            "nodeid": nodeid,
            "before": before,
            "after": after,
            "setup_changed_env_names": changed,
            "setup_primary_exception_type": type(primary).__name__ if primary is not None else None,
            "observation_errors": errors,
        }
        write_error: str | None = None
        try:
            case_id = before_env.get("E02_Q2_CASE_ID", "")
            _check(bool(case_id) and all(c.isalnum() or c in "-_" for c in case_id), "invalid_case")
            case = D / case_id
            temp = _case_owned_path(case / "tmp", case, "setup_receipt_root", exists=True)
            with (temp / SETUP_RECEIPT).open("x", encoding="utf-8") as stream:
                json.dump(record, stream, indent=2, sort_keys=True)
                stream.write("\n")
        except BaseException as exc:
            write_error = type(exc).__name__
            observe_error("setup_receipt", exc)
            try:
                sys.stderr.write(f"q2_setup_observation_unavailable: {write_error}\n")
            except BaseException as report_exc:
                observe_error("error_report", report_exc)
        storage_error: BaseException | None = None
        try:
            _SETUP_TRACES[id(item)] = {
                **record,
                "env_after_private": after_env,
                "write_error": write_error,
            }
        except BaseException as exc:
            storage_error = exc
            observe_error("trace_store", exc)
            try:
                sys.stderr.write(f"q2_setup_trace_unavailable: {type(exc).__name__}\n")
            except BaseException as report_exc:
                observe_error("error_report", report_exc)
        if primary is None and pending_interrupt is not None:
            raise pending_interrupt
        if primary is None and storage_error is not None:
            raise RuntimeError("q2_setup_trace_unavailable") from storage_error


def _validate_resources(
    item: pytest.Item, case: Path, setup_changes: list[str], late_changes: list[str]
) -> dict[str, object]:
    """Qualify the actual post-setup resources and their case ownership."""
    unexpected = sorted((set(setup_changes) | set(late_changes)) - ALLOWED_SETUP_ENV_CHANGES)
    _check(not unexpected, "unclassified_setup_environment_changes_" + ",".join(unexpected))
    evidence_root = _case_owned_path(case / "tmp", case, "evidence_root", exists=True)
    base = _case_owned_path(item.config.getoption("basetemp"), case, "pytest_basetemp", exists=True)
    _check(base == case / "basetemp", "pytest_basetemp_changed")
    tmp_path = _case_owned_path(item.funcargs.get("tmp_path"), case, "fixture_tmp", exists=True)
    _check(tmp_path.is_relative_to(base), "fixture_tmp_outside_pytest_basetemp")
    cache = _case_owned_path(os.environ.get("POLISYOS_CACHE_HOME"), case, "fixture_cache")
    _check(cache == tmp_path / "runtime-http-cache", "fixture_cache_not_bound_to_tmp_path")
    paths = {
        key: str(_case_owned_path(os.environ.get(key), case, key.lower(), exists=key == "TMPDIR"))
        for key in RESOURCE_KEYS
        if key not in {"POLISYOS_CACHE_HOME", "PYTHONDONTWRITEBYTECODE"}
    }
    prefix = _case_owned_path(sys.pycache_prefix, case, "interpreter_pycache")
    _check(prefix == evidence_root / "empty-pycache", "interpreter_pycache_changed")
    _check(paths["PYTHONPYCACHEPREFIX"] == str(prefix), "child_pycache_differs_from_interpreter")
    _check(os.environ.get("PYTHONDONTWRITEBYTECODE") == "1", "bytecode_writes_enabled")
    _check(sys.dont_write_bytecode, "interpreter_bytecode_writes_enabled")
    cached_temp = None
    if tempfile.tempdir is not None:
        cached_temp = str(_case_owned_path(os.fsdecode(tempfile.tempdir), case, "cached_tempfile"))
    cwd = Path.cwd().resolve()
    if cwd != P.resolve():
        _case_owned_path(cwd, case, "pre_body_cwd", exists=True)
    return {
        "evidence_root": str(evidence_root),
        "pytest_basetemp": str(base),
        "fixture_tmp_path": str(tmp_path),
        "fixture_cache_home": str(cache),
        "runtime_http_cache_fixture_present": "runtime_http_cache_isolation" in item.funcargs,
        "catalog_cache_root_from_source": str(cache / "catalog-graphs"),
        "resource_environment": paths,
        "sys_pycache_prefix": str(prefix),
        "dont_write_bytecode": sys.dont_write_bytecode,
        "tempfile_cached": cached_temp,
        "cwd_before_body": str(cwd),
        "setup_changed_env_names": setup_changes,
        "after_setup_changed_env_names": late_changes,
        "hypothesis_boundary": {
            "module_loaded": "hypothesis" in sys.modules,
            "fixture_configured_path_if_available": str(P / "_cache/hypothesis"),
            "database_access": "NOT_ESTABLISHED",
        },
    }


def _pytest_profile(config: pytest.Config) -> dict[str, object]:
    """Record requested flags separately from pytest's actual marker policy."""
    mode = config.getoption("importmode")
    marker_option = config.getoption("strict_markers", default=None)
    strict_option = config.getoption("strict", default=None)
    strict_config_option = config.getoption("strict_config", default=None)
    marker_ini = config.getini("strict_markers")
    strict_ini = config.getini("strict")
    strict_config_ini = config.getini("strict_config")
    _check(marker_ini is None or type(marker_ini) is bool, "invalid_marker_ini_type")
    _check(strict_ini is None or type(strict_ini) is bool, "invalid_strict_ini_type")
    _check(strict_config_ini is None or type(strict_config_ini) is bool, "invalid_config_ini_type")
    effective_marker = marker_ini if marker_ini is not None else strict_ini
    effective_config = strict_config_ini if strict_config_ini is not None else strict_ini
    early = getattr(config, "known_args_namespace", None)
    _check(
        early is not None and hasattr(early, "disable_plugin_autoload"), "autoload_state_missing"
    )
    early_disable = bool(early.disable_plugin_autoload)
    late_disable = bool(config.getoption("disable_plugin_autoload", default=False))
    env_disable = bool(os.environ.get("PYTEST_DISABLE_PLUGIN_AUTOLOAD"))
    addopts = config.getini("addopts")
    _check(
        isinstance(addopts, list) and "--strict-markers" in addopts, "strict_marker_addopts_missing"
    )
    _check(mode == "importlib", "wrong_import_mode")
    _check(marker_option is True, "strict_marker_option_missing")
    _check(not (early_disable or late_disable or env_disable), "autoload_disabled")
    return {
        "import_mode": mode,
        "strict_markers_option": marker_option,
        "strict_option": strict_option,
        "strict_config_option": strict_config_option,
        "strict_markers_ini": marker_ini,
        "strict_ini": strict_ini,
        "strict_config_ini": strict_config_ini,
        "effective_marker_strict": bool(effective_marker),
        "effective_marker_basis": "strict_markers_ini" if marker_ini is not None else "strict_ini",
        "strict_marker_behavior": (
            "NOT_ESTABLISHED" if effective_marker else "NOT_ESTABLISHED/observed_relaxed"
        ),
        "effective_config_strict": bool(effective_config),
        "autoload_early_disabled": early_disable,
        "autoload_final_disabled": late_disable,
        "autoload_environment_disabled": env_disable,
        "addopts": addopts,
    }


def _pytest_profile_source_facts() -> dict[str, dict[str, str]]:
    """Bind the finite external pytest source subset defining this profile law."""
    _check(pytest.__version__ == "9.0.2", "pytest_version_changed_review")
    package = P / ".venv/lib/python3.14/site-packages"
    facts: dict[str, dict[str, str]] = {}
    for name, (rel, expected) in PYTEST_PROFILE_SOURCES.items():
        module = sys.modules.get(name)
        source = package / rel
        _check(
            module is not None and Path(module.__file__).resolve() == source.resolve(),
            "pytest_origin_changed",
        )
        actual = _sha(source)
        _check(actual == expected, "pytest_profile_source_changed_review")
        facts[name] = {"path": str(source), "sha256": actual}
    return facts


def pytest_collection_modifyitems(items: list[pytest.Item]) -> None:
    """Fail before execution if the collected set differs from the bound node."""
    _check([item.nodeid for item in items] == [NODE], "unexpected_collection")


def _validate(item: pytest.Item) -> tuple[Path, dict[str, object]]:
    _check(item.nodeid == NODE, "unexpected_node")
    case_id = os.environ.get("E02_Q2_CASE_ID", "")
    _check(bool(case_id) and all(c.isalnum() or c in "-_" for c in case_id), "invalid_case")
    case = D / case_id
    trace = _SETUP_TRACES.get(id(item))
    _check(trace is not None and trace.get("write_error") is None, "setup_trace_unavailable")
    _check(not trace.get("observation_errors"), "setup_observation_error")
    before = trace.get("before")
    after = trace.get("after")
    _check(isinstance(before, dict) and "snapshot_error" not in before, "setup_before_unavailable")
    _check(isinstance(after, dict) and "snapshot_error" not in after, "setup_after_unavailable")
    _validate_setup_snapshot(before, case, "before_setup")
    _validate_setup_snapshot(after, case, "after_setup")
    _check(
        before.get("sys_path") == after.get("sys_path") == list(sys.path), "setup_sys_path_changed"
    )
    env_after = trace.get("env_after_private")
    _check(isinstance(env_after, dict), "setup_environment_unavailable")
    late_changes = sorted(
        name
        for name in env_after.keys() | os.environ.keys()
        if env_after.get(name) != os.environ.get(name)
    )
    setup_changes = trace.get("setup_changed_env_names")
    _check(isinstance(setup_changes, list), "setup_changes_unavailable")
    resources = _validate_resources(item, case, setup_changes, late_changes)
    temp = Path(str(resources["evidence_root"]))
    setup_receipt = temp / SETUP_RECEIPT
    _check(setup_receipt.is_file() and not setup_receipt.is_symlink(), "setup_receipt_missing")
    _check(Path(item.path).resolve() == (P / TEST).resolve(), "wrong_test_path")
    _check(Path(item.config.rootpath).resolve() == P.resolve(), "wrong_pytest_root")
    _check(Path(item.config.inipath).resolve() == (P / "pytest.ini").resolve(), "wrong_pytest_ini")
    profile = _pytest_profile(item.config)
    pytest_profile_sources = _pytest_profile_source_facts()
    markers = sorted(mark.name for mark in item.iter_markers())
    _check(markers == ["integration", "slow"], "unexpected_selected_item_markers")
    _check(Path(sys.prefix).resolve() == (P / ".venv").resolve(), "wrong_venv")
    _check(all(entry and Path(entry).is_absolute() for entry in sys.path), "relative_sys_path")
    _check(
        os.environ.get("POLISYOS_CAS_BACKEND", "filesystem") == "filesystem", "wrong_cas_backend"
    )
    plugin_dir = Path(os.environ.get("PYTHONPATH", ""))
    _check(plugin_dir.is_absolute() and not plugin_dir.is_symlink(), "invalid_plugin_path")
    _check(plugin_dir.resolve() == Path(__file__).resolve().parent, "wrong_plugin_path")
    _check(
        sorted(p.name for p in plugin_dir.iterdir()) == [f"{PLUGIN_NAME}.py"],
        "plugin_dir_not_exclusive",
    )
    _check(os.environ.get("PYTEST_PLUGINS") == PLUGIN_NAME, "wrong_plugin_selection")
    _check(_sha(Path(__file__)) == os.environ.get("E02_Q2_PLUGIN_SHA256"), "plugin_digest_mismatch")
    _check(_sha(P / TEST) == os.environ.get("E02_Q2_TEST_SHA256"), "test_digest_mismatch")
    _check(_sha(APP) == os.environ.get("E02_Q2_APP_SHA256"), "app_digest_mismatch")
    app = sys.modules.get("polisyos.runtime.http.app")
    _check(app is not None and Path(app.__file__).resolve() == APP.resolve(), "wrong_app_origin")
    _check(
        item.module.export_runtime_openapi_schema is app.export_runtime_openapi_schema,
        "wrong_export_owner",
    )
    defaults = inspect.signature(app.create_runtime_api_app).parameters
    _check(defaults["cas_root"].default == Path(".polisyos/cas"), "default_cas_changed")
    _check(defaults["repo_root"].default is None, "default_repo_root_changed")
    facts = {
        "nodeid": item.nodeid,
        "expected_source_head": os.environ.get("E02_Q2_SOURCE_HEAD"),
        "expected_source_tree": os.environ.get("E02_Q2_SOURCE_TREE"),
        "source_test_sha256": _sha(P / TEST),
        "source_app_sha256": _sha(APP),
        "app_origin": str(Path(app.__file__).resolve()),
        "app_default_cas": str(defaults["cas_root"].default),
        "app_default_repo_root": None,
        "pytest_root": str(item.config.rootpath),
        "pytest_ini": str(item.config.inipath),
        "pytest_version": pytest.__version__,
        "pytest_profile": profile,
        "pytest_profile_sources": pytest_profile_sources,
        "selected_item_markers": markers,
        "setup_observation_path": str(setup_receipt),
        "setup_observation_sha256": _sha(setup_receipt),
        "actual_call_resources": resources,
        "plugin_sha256": _sha(Path(__file__)),
        "python_executable": sys.executable,
        "python_prefix": sys.prefix,
        "python_version": sys.version,
        "sys_path_before": list(sys.path),
        "cas_backend": os.environ.get("POLISYOS_CAS_BACKEND", "filesystem"),
        "cas_root_override_present": "POLISYOS_CAS_ROOT" in os.environ,
        "execution_profile": os.environ.get("POLISYOS_EXECUTION_PROFILE", "<unset>"),
        "cache_home": os.environ["POLISYOS_CACHE_HOME"],
        "xdg_cache_home": os.environ.get("XDG_CACHE_HOME"),
        "pycache_prefix": os.environ.get("PYTHONPYCACHEPREFIX"),
        "profile_limit": (
            "cwd differs only during this one test body; imports, other cwd-sensitive "
            "lookups and background threads remain bounded. Requested strict marker flag "
            "and actual effective marker enforcement are recorded separately."
        ),
    }
    return temp, facts


class _ObservedSubprocess:
    """Delegate without changing call arguments/results; retain test-consumed checker text."""

    def __init__(self, target: ModuleType, temp: Path) -> None:
        self._target = target
        self._temp = temp
        self.calls: list[dict[str, object]] = []
        self.evidence_errors: list[str] = []

    def __getattr__(self, name: str) -> object:
        return getattr(self._target, name)

    def run(self, *args: object, **kwargs: object) -> subprocess.CompletedProcess[str]:
        result = self._target.run(*args, **kwargs)
        argv = args[0] if args else kwargs.get("args")
        index = len(self.calls)
        record: dict[str, object] = {
            "case": ("clean", "corrupted")[index] if index < 2 else "unexpected",
            "return_code": result.returncode,
        }
        # Append first so post-child instrumentation failures never lose the call.
        self.calls.append(record)
        for name in ("stdout", "stderr"):
            try:
                value = getattr(result, name)
                if not isinstance(value, str):
                    raise TypeError(f"{name} is not test-consumed text")
                encoded = value.encode("utf-8")
                destination = self._temp / f"q2-checker-{index}.{name}.txt"
                with destination.open("xb") as stream:
                    stream.write(encoded)
                record[f"{name}_path"] = str(destination)
                record[f"{name}_sha256"] = hashlib.sha256(encoded).hexdigest()
                record[f"{name}_bytes"] = len(encoded)
            except Exception as exc:
                self.evidence_errors.append(f"{name}_delivery_{type(exc).__name__}")
        # Capture both available streams before touching the comparison file.
        try:
            if not isinstance(argv, (list, tuple)) or len(argv) < 2:
                self.evidence_errors.append("unexpected_nonsequence_command")
                return result
            record.update(
                {
                    "argv": [str(value) for value in argv],
                    "cwd": str(kwargs.get("cwd")),
                    "capture_output": kwargs.get("capture_output"),
                    "text": kwargs.get("text"),
                    "check": kwargs.get("check"),
                }
            )
            child_env = kwargs.get("env")
            if not isinstance(child_env, dict):
                self.evidence_errors.append("child_environment_missing")
            else:
                expected_env = dict(os.environ)
                expected_env["PYTHONPATH"] = f"{P / 'src'}:{P}"
                env_differences = sorted(
                    str(name)
                    for name in expected_env.keys() | child_env.keys()
                    if expected_env.get(name) != child_env.get(name)
                )
                record["child_environment_difference_names"] = env_differences
                if env_differences:
                    self.evidence_errors.append("child_environment_changed")
            if str(argv[1]) != "tools/ops_runners/runtime/check_runtime_api_contract.py":
                self.evidence_errors.append("unexpected_test_subprocess")
                return result
            if (
                len(argv) != 5
                or str(argv[0]) != sys.executable
                or str(argv[2]) != "--openapi"
                or str(argv[4]) != "--skip-client-drift"
                or Path(str(kwargs.get("cwd"))).resolve() != P.resolve()
                or kwargs.get("capture_output") is not True
                or kwargs.get("text") is not True
                or kwargs.get("check") is not False
            ):
                self.evidence_errors.append("checker_call_shape_mismatch")
            if len(argv) == 5:
                comparison = Path(str(argv[3]))
                record["comparison_path"] = str(comparison)
                if not comparison.resolve().is_relative_to(self._temp.parent.resolve()):
                    self.evidence_errors.append("comparison_outside_case")
                elif comparison.is_file():
                    record["comparison_sha256"] = _sha(comparison)
                    record["comparison_bytes"] = comparison.stat().st_size
                else:
                    self.evidence_errors.append("comparison_missing")
        except Exception as exc:
            self.evidence_errors.append(f"checker_evidence_{type(exc).__name__}")
        return result


@contextlib.contextmanager
def _isolated_body(item: pytest.Item, temp: Path, facts: dict[str, object]) -> Iterator[None]:
    """Temporarily change only this test PID's cwd and restore it even on failure."""
    receipt = temp / RECEIPT
    _check(not os.path.lexists(receipt), "receipt_already_exists")
    work = temp / WORK_NAME
    before = Path.cwd().resolve()
    module = item.module
    original_subprocess = module.subprocess
    _check(original_subprocess is subprocess, "test_subprocess_not_original")
    observer = _ObservedSubprocess(original_subprocess, temp)
    attempted_chdir = False
    body_started = False
    failure: BaseException | None = None
    cleanup_errors: list[dict[str, str]] = []
    try:
        _allocate(temp)
        module.subprocess = observer
        attempted_chdir = True
        os.chdir(work)
        _check(Path.cwd().resolve() == work.resolve(), "working_directory_mismatch")
        body_started = True
        yield
    except BaseException as exc:
        failure = exc
        raise
    finally:
        if attempted_chdir:
            try:
                os.chdir(before)
            except BaseException as exc:
                cleanup_errors.append(
                    {"operation": "restore_cwd", "error_type": type(exc).__name__}
                )
        try:
            module.subprocess = original_subprocess
        except BaseException as exc:
            cleanup_errors.append(
                {"operation": "restore_subprocess", "error_type": type(exc).__name__}
            )
        after: Path | None = None
        try:
            after = Path.cwd().resolve()
        except BaseException as exc:
            cleanup_errors.append({"operation": "read_cwd", "error_type": type(exc).__name__})
        cas = work / ".polisyos/cas"
        artifacts = cas / "artifacts/sha256"
        cas_created = False
        layout_created = False
        try:
            cas_created = cas.is_dir() and not cas.is_symlink()
            layout_created = artifacts.is_dir()
        except BaseException as exc:
            cleanup_errors.append(
                {"operation": "read_cas_layout", "error_type": type(exc).__name__}
            )
        qualification_errors: list[str] = []
        if not body_started:
            qualification_errors.append("test_body_not_entered")
        if cleanup_errors:
            qualification_errors.append("cleanup_error")
        if after != before:
            qualification_errors.append("cwd_not_restored")
        if observer.evidence_errors:
            qualification_errors.append("checker_evidence_error")
        if failure is None and (not cas_created or not layout_created):
            qualification_errors.append("cas_layout_missing")
        if failure is None and len(observer.calls) != 2:
            qualification_errors.append("checker_call_missing_or_ambiguous")
        if failure is None and len(observer.calls) == 2:
            if [call.get("return_code") for call in observer.calls] != [0, 1]:
                qualification_errors.append("checker_return_codes_unexpected")
            names = [Path(str(call.get("comparison_path", ""))).name for call in observer.calls]
            if names != [
                "runtime_api_v1.clean.openapi.json",
                "runtime_api_v1.corrupted.openapi.json",
            ]:
                qualification_errors.append("checker_comparison_paths_unexpected")
        details = {
            **facts,
            "cwd_before": str(before),
            "cwd_during": str(work),
            "cwd_after": str(after) if after is not None else None,
            "cwd_restored": after == before,
            "test_body_started": body_started,
            "private_cas_expected": str(cas),
            "private_cas_created": cas_created,
            "private_cas_artifact_layout_created": layout_created,
            "test_body_exception_type": type(failure).__name__ if failure is not None else None,
            "checker_calls": observer.calls,
            "evidence_errors": observer.evidence_errors,
            "cleanup_errors": cleanup_errors,
            "qualification_errors": qualification_errors,
            "qualification_status": "ERROR" if qualification_errors else "COMPLETE",
            "checker_output_representation": (
                "complete text as returned to the test, encoded UTF-8; original raw "
                "subprocess bytes were not observed"
            ),
            "scope_limit": (
                "real pytest parent imported-source observer is separate; checker child "
                "imported code and arbitrary cwd-sensitive resources are not comprehensively "
                "observed"
            ),
        }
        receipt_error: BaseException | None = None
        try:
            with receipt.open("x", encoding="utf-8") as stream:
                json.dump(details, stream, indent=2, sort_keys=True)
                stream.write("\n")
        except BaseException as exc:
            receipt_error = exc
            with contextlib.suppress(BaseException):
                sys.stderr.write(f"q2_cwd_receipt_unavailable: {type(exc).__name__}\n")
        if failure is None and (qualification_errors or receipt_error is not None):
            raise RuntimeError("q2_cwd_harness_qualification_failed") from receipt_error


@pytest.hookimpl(wrapper=True, tryfirst=True)
def pytest_runtest_call(item: pytest.Item) -> Iterator[None]:
    temp, facts = _validate(item)
    with _isolated_body(item, temp, facts):
        return (yield)
