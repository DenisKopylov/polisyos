"""Real-owner checks for the write-free acquisition preparation seam."""

from __future__ import annotations

import hashlib
import json
from dataclasses import replace
from datetime import UTC, datetime
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import duckdb
import pytest

from polisyos.core.artifacts import FileSystemCAS, PutOptions, SchemaInfo
from polisyos.core.canon import CanonSpec, from_canonical_bytes
from polisyos.core.contracts.fabric import DataSnapshot
from polisyos.data_forge.domains.catalog.knowledge.overlay import OverlayAdmissionError
from polisyos.runtime.quality.data_snapshot_lineage import validate_data_snapshot_owner_lineage
from polisyos.runtime.quality.data_state_substrate import (
    AcquiredObservationDataPreparation,
    ControlledAcquisitionSlotBinding,
    DataStateSubstrateError,
    _acquisition_preparation_sha256,
    materialize_acquired_observation_snapshot,
    prepare_acquired_observation_snapshot,
)
from tests._helpers import world_model_record as world_fixture
from tests._helpers.semantic_epoch_native import _real_epoch_scenario
from tests.unit.runtime.quality.test_acquisition_executor import _activate_real_epoch_scenario


@pytest.fixture
def owner_case(tmp_path: Path):
    """Activate the actual native overlay without the unrelated N7 route."""

    scenario = _real_epoch_scenario(tmp_path)
    _, activated = _activate_real_epoch_scenario(scenario)
    projection = scenario.overlay.read_activated_semantic_epoch_observations(
        receipt_ref=activated.receipt_ref,
        artifact_store=scenario.store,
        passport=scenario.passport,
        authority=scenario.authority,
    )
    selected = projection.observations[0]
    args = {
        "base_data_snapshot_ref": world_fixture._data_snapshot_ref(scenario.store),
        "overlay": scenario.overlay,
        "receipt_ref": activated.receipt_ref,
        "passport": scenario.passport,
        "authority": scenario.authority,
        "observation_id": selected.observation.observation_id,
        "slot_binding": ControlledAcquisitionSlotBinding(
            profile_selection_ref="sha256:" + "7" * 64,
            canonical_variable_id=selected.observation.canonical_var,
            target_slot_id="government.balance",
        ),
        "transaction_time": datetime(2026, 10, 2, 12, 0, tzinfo=UTC),
    }
    return SimpleNamespace(
        scenario=scenario,
        args=args,
        selected=selected,
        projection=projection,
        workspace=tmp_path / "candidate-data-forge",
    )


def _observe_store_writes(
    monkeypatch: pytest.MonkeyPatch,
) -> list[str]:
    """Observe real CAS write entrypoints without replacing their behavior."""

    writes: list[str] = []
    for name in ("put_json", "put_bytes", "put_signature", "import_exact_view", "import_subgraph"):
        original = getattr(FileSystemCAS, name)

        def observed(*args: Any, _name: str = name, _original=original, **kwargs: Any) -> Any:
            writes.append(_name)
            return _original(*args, **kwargs)

        monkeypatch.setattr(FileSystemCAS, name, observed)
    return writes


def _resign(prepared: AcquiredObservationDataPreparation, **updates: Any):
    """Model an adversary who can recompute every public candidate digest."""

    changed = replace(prepared, **updates)
    return replace(
        changed,
        preparation_sha256=_acquisition_preparation_sha256(changed, include_digest=False),
    )


def test_preparation_has_no_cas_write_and_materialization_rechecks_actual_owner(
    owner_case: SimpleNamespace, monkeypatch: pytest.MonkeyPatch
) -> None:
    store = owner_case.scenario.store
    writes = _observe_store_writes(monkeypatch)
    read_owner = owner_case.scenario.overlay.read_activated_semantic_epoch_observations
    reads: list[object] = []

    def observed_owner(**kwargs: Any):
        result = read_owner(**kwargs)
        reads.append(result)
        return result

    monkeypatch.setattr(
        owner_case.scenario.overlay, "read_activated_semantic_epoch_observations", observed_owner
    )
    prepared = prepare_acquired_observation_snapshot(store, **owner_case.args)
    assert writes == []
    assert not owner_case.workspace.exists()
    assert len(reads) == 1
    first = prepared.payload()
    first["acquisition"]["selected"]["value"] = "mutated"
    assert prepared.payload()["acquisition"]["selected"]["value"] == (
        owner_case.selected.observation.value
    )
    materialized = materialize_acquired_observation_snapshot(
        store, **owner_case.args, workspace_dir=owner_case.workspace, prepared=prepared
    )
    assert len(reads) == 2
    assert writes
    fresh_store = FileSystemCAS(store.root)
    snapshot = DataSnapshot.model_validate(
        from_canonical_bytes(fresh_store.get_bytes(materialized.data_snapshot_ref))
    )
    payload = from_canonical_bytes(fresh_store.get_bytes(snapshot.data_ref))
    validate_data_snapshot_owner_lineage(fresh_store, materialized.data_snapshot_ref, snapshot)
    assert payload == prepared.payload()
    assert payload["_policyos_acquisition"]["base_data_snapshot_id"] == str(
        owner_case.args["base_data_snapshot_ref"].artifact_id
    )
    assert materialized.data_snapshot_ref.manifest_profile_sha256 is not None
    assert prepared.base_snapshot_id != str(owner_case.args["base_data_snapshot_ref"].artifact_id)
    assert (
        snapshot.source_lineage.base_data_snapshot_ref == owner_case.args["base_data_snapshot_ref"]
    )
    assert materialized.observation_projection == owner_case.projection


@pytest.mark.parametrize("field", ["payload", "foundry_rule", "lineage", "base_profile"])
def test_resigned_preparation_cannot_replace_fresh_owner_result(
    owner_case: SimpleNamespace, monkeypatch: pytest.MonkeyPatch, field: str
) -> None:
    store = owner_case.scenario.store
    prepared = prepare_acquired_observation_snapshot(store, **owner_case.args)
    if field == "payload":
        payload = prepared.payload()
        payload["acquisition"]["selected"]["value"] = "999"
        encoded = json.dumps(
            payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")
        ).encode()
        forged = _resign(
            prepared,
            payload_json=encoded,
            payload_sha256=hashlib.sha256(encoded).hexdigest(),
        )
    elif field == "foundry_rule":
        forged = _resign(
            prepared,
            foundry_binding_rule=prepared.foundry_binding_rule.model_copy(
                update={"target_slot_id": "agents.income"}
            ),
        )
    elif field == "lineage":
        forged = _resign(prepared, lineage_inputs=())
    else:
        forged = _resign(
            prepared,
            base_data_snapshot_ref=prepared.base_data_snapshot_ref.model_copy(
                update={"manifest_profile_sha256": "sha256:" + "0" * 64}
            ),
        )
        assert (
            forged.base_data_snapshot_ref.artifact_id == prepared.base_data_snapshot_ref.artifact_id
        )
    # The content digest is internally consistent: it cannot establish owner issuance.
    forged.validate_content_binding()
    writes = _observe_store_writes(monkeypatch)
    with pytest.raises(
        DataStateSubstrateError, match="acquisition_preparation_owner_state_changed"
    ):
        materialize_acquired_observation_snapshot(
            store, **owner_case.args, workspace_dir=owner_case.workspace, prepared=forged
        )
    assert writes == []
    assert not owner_case.workspace.exists()


@pytest.mark.parametrize("drift", ["activation", "row"])
def test_prepared_candidate_does_not_bypass_current_overlay_owner(
    owner_case: SimpleNamespace, monkeypatch: pytest.MonkeyPatch, drift: str
) -> None:
    store = owner_case.scenario.store
    prepared = prepare_acquired_observation_snapshot(store, **owner_case.args)
    con = duckdb.connect(str(owner_case.scenario.overlay.overlay_path))
    try:
        if drift == "activation":
            con.execute(
                "UPDATE acquisition_epochs SET epoch_activation_state = 'legacy_not_established' "
                "WHERE epoch_id = ? AND passport_id = ?",
                [owner_case.scenario.passport.epoch_id, owner_case.scenario.passport.passport_id],
            )
            code = "epoch_activation_state_not_active"
        else:
            con.execute(
                "UPDATE ds_observations SET value = ? WHERE observation_id = ?",
                [
                    float(owner_case.selected.observation.value) + 1.0,
                    prepared.selected_observation_id,
                ],
            )
            code = "active_epoch_observation_content_mismatch"
    finally:
        con.close()
    writes = _observe_store_writes(monkeypatch)
    with pytest.raises(OverlayAdmissionError, match=code):
        materialize_acquired_observation_snapshot(
            store, **owner_case.args, workspace_dir=owner_case.workspace, prepared=prepared
        )
    assert writes == []
    assert not owner_case.workspace.exists()


@pytest.mark.parametrize("wrong", ["overlay", "passport", "authority"])
def test_prepared_candidate_preserves_materialization_owner_inputs(
    owner_case: SimpleNamespace, monkeypatch: pytest.MonkeyPatch, wrong: str
) -> None:
    store = owner_case.scenario.store
    prepared = prepare_acquired_observation_snapshot(store, **owner_case.args)
    changed = dict(owner_case.args)
    if wrong == "overlay":
        changed[wrong] = object()
        code = "acquisition_overlay_owner_untyped"
        expected = DataStateSubstrateError
    elif wrong == "passport":
        changed[wrong] = changed[wrong].model_copy(update={"passport_id": "wrong-passport"})
        code = "active_epoch_passport_binding_mismatch"
        expected = OverlayAdmissionError
    else:
        changed[wrong] = object()
        code = "acquisition_authority_unresolved"
        expected = OverlayAdmissionError
    writes = _observe_store_writes(monkeypatch)
    with pytest.raises(expected, match=code):
        materialize_acquired_observation_snapshot(
            store, **changed, workspace_dir=owner_case.workspace, prepared=prepared
        )
    assert writes == []
    assert not owner_case.workspace.exists()


def test_duck_preparation_cannot_supply_materialized_payload(
    owner_case: SimpleNamespace, monkeypatch: pytest.MonkeyPatch
) -> None:
    store = owner_case.scenario.store
    prepared = prepare_acquired_observation_snapshot(store, **owner_case.args)
    calls: list[str] = []

    def forged_payload():
        calls.append("forged_payload")
        return {"candidate": "wrong"}

    forged = SimpleNamespace(**vars(prepared), payload=forged_payload)
    writes = _observe_store_writes(monkeypatch)
    with pytest.raises(DataStateSubstrateError, match="acquisition_preparation_untyped"):
        materialize_acquired_observation_snapshot(
            store, **owner_case.args, workspace_dir=owner_case.workspace, prepared=forged
        )
    assert calls == []
    assert writes == []
    assert not owner_case.workspace.exists()


def test_explicit_preparation_preserves_aware_transaction_time_check(
    owner_case: SimpleNamespace, monkeypatch: pytest.MonkeyPatch
) -> None:
    store = owner_case.scenario.store
    prepared = prepare_acquired_observation_snapshot(store, **owner_case.args)
    changed = {**owner_case.args, "transaction_time": datetime(2026, 10, 2, 12, 0)}
    writes = _observe_store_writes(monkeypatch)
    with pytest.raises(DataStateSubstrateError, match="acquisition_transaction_time_must_be_aware"):
        materialize_acquired_observation_snapshot(
            store, **changed, workspace_dir=owner_case.workspace, prepared=prepared
        )
    assert writes == []
    assert not owner_case.workspace.exists()


def test_unresigned_payload_drift_fails_content_check(owner_case: SimpleNamespace) -> None:
    prepared = prepare_acquired_observation_snapshot(owner_case.scenario.store, **owner_case.args)
    with pytest.raises(DataStateSubstrateError, match="acquisition_preparation_content_changed"):
        replace(prepared, payload_json=prepared.payload_json + b" ").payload()


def test_supplied_preparation_is_bound_to_the_actual_declared_target_slot(
    owner_case: SimpleNamespace, monkeypatch: pytest.MonkeyPatch
) -> None:
    store = owner_case.scenario.store
    prepared = prepare_acquired_observation_snapshot(store, **owner_case.args)
    changed = {
        **owner_case.args,
        "slot_binding": owner_case.args["slot_binding"].model_copy(
            update={"target_slot_id": "agents.income"}
        ),
    }
    writes = _observe_store_writes(monkeypatch)
    with pytest.raises(
        DataStateSubstrateError, match="acquisition_preparation_owner_state_changed"
    ):
        materialize_acquired_observation_snapshot(
            store, **changed, workspace_dir=owner_case.workspace, prepared=prepared
        )
    assert writes == []
    assert not owner_case.workspace.exists()


@pytest.mark.parametrize(
    "invalid", ["child_profile", "missing_parent_edge", "owner_schema_without_lineage"]
)
def test_generic_legacy_base_still_requires_selected_typed_closure(
    owner_case: SimpleNamespace, monkeypatch: pytest.MonkeyPatch, invalid: str
) -> None:
    store = owner_case.scenario.store
    original_ref = owner_case.args["base_data_snapshot_ref"]
    snapshot = DataSnapshot.model_validate(from_canonical_bytes(store.get_bytes(original_ref)))
    assert snapshot.source_lineage is None
    original_manifest = store.get_manifest_by_profile(
        original_ref.artifact_id, original_ref.manifest_profile_sha256
    )
    schema_version = "0.2.0"
    if invalid == "child_profile":
        snapshot.data_ref = snapshot.data_ref.model_copy(update={"manifest_profile_sha256": None})
        code = "acquisition_base_snapshot_child_profile_unselected"
    elif invalid == "missing_parent_edge":
        snapshot.quality_report_ref = store.put_json(
            {"quality": "candidate_fixture"},
            PutOptions(kind="fabric.quality_report", media_type="application/json"),
            return_selected_profile=True,
        )
        code = "acquisition_base_snapshot_owner_lineage_invalid"
    else:
        schema_version = "0.3.0"
        code = "acquisition_base_snapshot_owner_lineage_invalid"
    alternate = store.put_json(
        snapshot.model_dump(mode="json"),
        PutOptions(
            kind="fabric.data_snapshot",
            media_type="application/json",
            schema=SchemaInfo(name="polisyos.core.DataSnapshot", version=schema_version),
            inputs=list(original_manifest.inputs),
        ),
        canon_spec=CanonSpec(forbid_floats=False),
        return_selected_profile=True,
    )
    writes = _observe_store_writes(monkeypatch)
    with pytest.raises(DataStateSubstrateError, match=code):
        prepare_acquired_observation_snapshot(
            store, **{**owner_case.args, "base_data_snapshot_ref": alternate}
        )
    assert writes == []
    assert not owner_case.workspace.exists()
