"""Typed runtime container and lifecycle helpers for the HTTP API surface."""

from __future__ import annotations

import inspect
from dataclasses import dataclass, field, replace
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any, Literal

from polisyos.common import (
    async_tools as common_async_tools,
)
from polisyos.core.observability import get_metrics, get_tracer
from polisyos.runtime.http.access_audit import RuntimeDataAccessAuditTrail
from polisyos.runtime.http.dependencies import (
    RuntimeApiContext,
    build_runtime_api_context,
)
from polisyos.runtime.http.mutation_policy import build_runtime_mutation_services
from polisyos.runtime.http.resilience import build_runtime_opa_async_guard
from polisyos.runtime.http.services.acquisition_action_service import (
    AcquisitionActionService,
)
from polisyos.runtime.http.services.control import ControlPlaneService
from polisyos.runtime.http.services.control.capability_discovery import (
    CapabilityDiscoveryService,
)
from polisyos.runtime.http.services.control_registry_providers import (
    ControlRegistryProviders,
    resolve_control_registry_providers,
)
from polisyos.runtime.http.services.public_decision_verification_configuration import (
    build_public_decision_verification_service,
)
from polisyos.runtime.http.services.review_collaboration import ReviewCollaborationHub
from polisyos.runtime.quality.chronology_custody import (
    build_production_epoch_anchor_custody_provider,
)
from polisyos.runtime.quality.cycle_substrate import (
    ConfiguredCandidateSimulationContextAdmissionOwner,
)
from polisyos.runtime.quality.design_axes.value_choice_provenance import (
    NormativeAuthorityTrust,
)
from polisyos.runtime.quality.open_world_risk import PromotionRuntime
from polisyos.scientist import (
    BudgetState,
    ClaimLedgerOwnerPort,
    EpochClaimLifecycleBridgeService,
    build_default_claim_ledger_owner,
    build_epoch_claim_lifecycle_bridge,
)
from polisyos.scientist.governance.continuous import (
    PublicVerificationRecordPopulationProvider,
)
from polisyos.scientist.orchestration.engine import BudgetMiddleware, FileBudgetLedger

if TYPE_CHECKING:
    from collections.abc import Callable
    from pathlib import Path

    from polisyos.core import contracts as core_contracts
    from polisyos.core.contracts import CatalogRunProfile
    from polisyos.runtime.http.execution_policy import ResolvedExecutionPolicy
    from polisyos.runtime.http.security import RuntimeSecurityConfig
    from polisyos.runtime.http.services.control.evaluation_safety import (
        EvaluationSafetyAuthoritiesSource,
    )
    from polisyos.runtime.http.services.human_decisions import HumanDecisionService
    from polisyos.runtime.http.services.public_decision_verification import (
        PublicDecisionVerificationService,
    )
    from polisyos.runtime.quality.acquisition_movement import AcquisitionMovementService
    from polisyos.runtime.quality.approval import ProductionApprovalPacketResolver
    from polisyos.runtime.quality.epoch_certificate_issuance import (
        DecisionPacketEpochIssuanceOwner,
    )
    from polisyos.runtime.quality.generic_simulation_admission import (
        GenericCycleSimulationAdmissionOwner,
        GenericCycleSimulationProfileV1,
    )
    from polisyos.runtime.quality.substrate_registry import (
        CatalogServingSourceSelection,
    )

LifecycleStatus = Literal["created", "starting", "ready", "stopping", "stopped", "failed"]


class LegalQueryEncoderProviderError(ValueError):
    """Typed refusal from the runtime-composed Legal encoder provider."""

    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__(code)


@dataclass(frozen=True, slots=True, eq=False)
class LegalQueryEncoderProvider:
    """Carry a legacy candidate or Legal-owned runtime profile to the reader.

    Legacy encoder objects remain refused after their generation checks. An
    exact Legal runtime-material owner is resolved only by the shared store gate.
    """

    encoder: object | None = field(default=None, repr=False, compare=False)
    runtime_material_owner: object | None = field(default=None, repr=False, compare=False)
    _asset_identity: str = field(init=False, repr=False)
    _device: str = field(init=False, repr=False)
    _dimension: int = field(init=False, repr=False)

    def __post_init__(self) -> None:
        """Require a legacy candidate or exact Legal owner without loading it."""
        from polisyos.data_forge.read_api import legal as legal_read_api

        if self.encoder is not None and self.runtime_material_owner is not None:
            raise ValueError("legal_query_encoder_provider_source_conflict")
        if self.runtime_material_owner is not None:
            if type(self.runtime_material_owner) is not legal_read_api.LegalRuntimeMaterialOwner:
                raise ValueError("legal_query_runtime_material_owner_invalid")
            object.__setattr__(self, "_asset_identity", "")
            object.__setattr__(self, "_device", "")
            object.__setattr__(self, "_dimension", 0)
            return
        if self.encoder is None:
            raise ValueError("legal_query_encoder_provider_source_required")
        dimension_method = getattr(self.encoder, "get_sentence_embedding_dimension", None)
        encode_method = getattr(self.encoder, "encode", None)
        device_value = getattr(self.encoder, "device", None)
        device = str(device_value) if device_value is not None else ""
        try:
            dimension = int(dimension_method()) if callable(dimension_method) else -1
            identity = legal_read_api.derive_encoder_identity(self.encoder)
        except (
            AttributeError,
            ImportError,
            OSError,
            RuntimeError,
            TypeError,
            ValueError,
        ) as exc:
            raise ValueError("legal_query_encoder_assets_unavailable") from exc
        if not callable(encode_method) or not device or dimension < 1:
            raise ValueError("legal_query_encoder_profile_unavailable")
        object.__setattr__(self, "_asset_identity", identity.content_identity)
        object.__setattr__(self, "_device", device)
        object.__setattr__(self, "_dimension", dimension)

    def resolve_encoder(self) -> object:
        """Refuse raw candidates; owned handles are invoked only by the shared store gate."""
        if self.runtime_material_owner is not None:
            raise LegalQueryEncoderProviderError("query_encoder_call_requires_shared_gate")
        if self.encoder is None:
            raise LegalQueryEncoderProviderError("query_encoder_assets_unavailable")
        from polisyos.data_forge.read_api import legal as legal_read_api

        dimension_method = getattr(self.encoder, "get_sentence_embedding_dimension", None)
        encode_method = getattr(self.encoder, "encode", None)
        device_value = getattr(self.encoder, "device", None)
        device = str(device_value) if device_value is not None else ""
        try:
            dimension = int(dimension_method()) if callable(dimension_method) else -1
            identity = legal_read_api.derive_encoder_identity(self.encoder)
        except (
            AttributeError,
            ImportError,
            OSError,
            RuntimeError,
            TypeError,
            ValueError,
        ) as exc:
            raise LegalQueryEncoderProviderError("query_encoder_assets_unavailable") from exc
        if (
            not callable(encode_method)
            or identity.content_identity != self._asset_identity
            or device != self._device
            or dimension != self._dimension
        ):
            raise LegalQueryEncoderProviderError("query_encoder_assets_changed")
        # The selected generation records model-asset identity, not the
        # executable runtime that implements encode. No canonical owner-issued
        # runtime bundle is composed here, so do not return this arbitrary object.
        raise LegalQueryEncoderProviderError("query_encoder_runtime_material_not_established")


@dataclass(frozen=True)
class RuntimeContainerOverrides:
    """Optional dependency overrides used by tests or alternate embeddings.

    ``llm_producer_settlement_store`` must use a durable ledger. The default
    runtime creates an app-scoped file ledger under ``core_runs_root/.runtime``;
    overrides can supply the same existing producer-settlement owner explicitly.
    """

    runtime_api_context: RuntimeApiContext | None = None
    review_collaboration_hub: ReviewCollaborationHub | None = None
    control_service: ControlPlaneService | None = None
    evaluation_safety_authorities_source: EvaluationSafetyAuthoritiesSource | None = None
    runtime_metrics: Any | None = None
    runtime_tracer: Any | None = None
    runtime_access_audit: RuntimeDataAccessAuditTrail | None = None
    runtime_rate_limiter: Any | None = None
    runtime_idempotency_store: Any | None = None
    runtime_mutation_audit: Any | None = None
    runtime_review_opa_guard: Any | None = None
    control_registry_providers: ControlRegistryProviders | None = None
    decision_validity_service: Any | None = None
    claim_ledger_owner: Any | None = None
    epoch_claim_lifecycle_bridge: Any | None = None
    acquisition_authority_provider: Any | None = None
    acquisition_execution_port: Any | None = None
    legal_query_encoder_provider: LegalQueryEncoderProvider | None = None
    llm_producer_settlement_store: BudgetMiddleware | None = None
    llm_cache_reuse_authorizer: Any | None = None
    llm_prompt_cache: Any | None = None


@dataclass(frozen=True)
class RuntimeContainerConfig:
    """Factory inputs required to assemble the runtime service graph."""

    cas_root: Path
    core_runs_root: Path
    max_preview_bytes: int = 64 * 1024
    lineage_max_depth: int = 64
    lineage_max_nodes: int = 2000
    allow_unscoped_artifacts: bool = False
    artifact_redaction_hooks: dict[str, Any] | None = None
    metrics_factory: Callable[[], Any] | None = None
    tracer_factory: Callable[[], Any] | None = None
    overrides: RuntimeContainerOverrides = field(default_factory=RuntimeContainerOverrides)
    normative_authority_trust: NormativeAuthorityTrust = field(
        default_factory=NormativeAuthorityTrust
    )
    candidate_simulation_profiles: tuple[Any, ...] = ()
    candidate_simulation_model_declarations: tuple[Any, ...] = ()
    generic_cycle_simulation_profiles: tuple[GenericCycleSimulationProfileV1, ...] = ()
    generic_cycle_simulation_root_profile_id: str | None = None
    enable_contract_testing_credal_source_attempts: bool = False
    process_worker_capacity: int | None = None
    process_worker_profile_revision: str | None = None
    catalog_run_profile: CatalogRunProfile | None = None
    catalog_source_selection: CatalogServingSourceSelection | None = None
    repo_root: Path | None = None
    allow_candidate_run_predictive_calibration_surface: bool = True
    _resolved_process_worker_profile: common_async_tools.SharedExecutorProfile = field(
        init=False,
        repr=False,
        compare=False,
    )

    def __post_init__(self) -> None:
        """Reject incomplete runtime profiles during composition."""
        profile = common_async_tools.resolve_shared_executor_profile(
            capacity=self.process_worker_capacity,
            revision=self.process_worker_profile_revision,
        )
        object.__setattr__(self, "_resolved_process_worker_profile", profile)
        if self.repo_root is not None:
            from pathlib import Path

            if not isinstance(self.repo_root, Path):
                raise TypeError("runtime_source_repo_root_must_be_path")
            if not self.repo_root.is_absolute():
                raise ValueError("runtime_source_repo_root_must_be_absolute")
            try:
                source_root = self.repo_root.resolve(strict=True)
            except (OSError, RuntimeError) as exc:
                raise ValueError("runtime_source_repo_root_invalid") from exc
            if not source_root.is_dir():
                raise ValueError("runtime_source_repo_root_invalid")
            object.__setattr__(self, "repo_root", source_root)
        if self.catalog_run_profile is not None:
            if not isinstance(self.catalog_run_profile, str):
                raise ValueError("catalog_run_profile_invalid")
            from polisyos.data_forge.read_api.catalog import (
                validate_catalog_run_profile,
            )

            validate_catalog_run_profile(self.catalog_run_profile)
        if self.catalog_source_selection is not None:
            from polisyos.runtime.quality.substrate_registry import (
                CatalogServingSourceSelection,
            )

            if type(self.catalog_source_selection) is not CatalogServingSourceSelection:
                raise ValueError("catalog_source_selection_invalid")
            selected_profile = self.catalog_source_selection.catalog_run_profile
            if self.catalog_run_profile not in (None, selected_profile):
                raise ValueError("catalog_source_selection_profile_mismatch")
            if self.catalog_run_profile is None:
                object.__setattr__(self, "catalog_run_profile", selected_profile)

    def shared_executor_profile(self) -> common_async_tools.SharedExecutorProfile:
        """Resolve the configured candidate profile or the legacy host fallback."""
        return self._resolved_process_worker_profile


@dataclass
class RuntimeLifecycleState:
    """Mutable lifecycle and dependency-health snapshot for the runtime container."""

    status: LifecycleStatus = "created"
    started_at: datetime | None = None
    stopped_at: datetime | None = None
    last_error: str | None = None

    def mark(self, status: LifecycleStatus, *, error: str | None = None) -> None:
        self.status = status
        if status == "ready":
            self.started_at = datetime.now(UTC)
            self.stopped_at = None
            self.last_error = None
            return
        if status in {"failed", "stopped"}:
            self.stopped_at = datetime.now(UTC)
        if error:
            self.last_error = error


@dataclass
class RuntimeServiceContainer:
    """Own runtime-scoped services and expose startup/shutdown/health hooks."""

    config: RuntimeContainerConfig
    deployment_policy: ResolvedExecutionPolicy
    runtime_security: RuntimeSecurityConfig
    runtime_metrics: Any
    runtime_tracer: Any
    runtime_api_context: RuntimeApiContext
    review_collaboration_hub: ReviewCollaborationHub
    runtime_access_audit: RuntimeDataAccessAuditTrail
    runtime_rate_limiter: Any
    runtime_idempotency_store: Any
    runtime_mutation_audit: Any
    runtime_review_opa_guard: Any
    epoch_anchor_custody_provider: core_contracts.EpochAnchorCustodyProvider
    promotion_runtime: PromotionRuntime
    decision_validity_service: core_contracts.EpochValidityCompletedBatchEvidenceResolver
    claim_ledger_owner: ClaimLedgerOwnerPort
    epoch_claim_lifecycle_bridge: EpochClaimLifecycleBridgeService
    control_registry_providers: ControlRegistryProviders
    public_decision_verification_service: PublicDecisionVerificationService
    candidate_simulation_context_admission_owner: Any | None = None
    generic_cycle_simulation_admission_owner: GenericCycleSimulationAdmissionOwner | None = None
    generic_cycle_simulation_root_profile_id: str | None = None
    legal_query_encoder_provider: LegalQueryEncoderProvider | None = None
    llm_producer_settlement_store: BudgetMiddleware | None = None
    llm_cache_reuse_authorizer: Any | None = None
    llm_prompt_cache: Any | None = None
    control_service: ControlPlaneService | None = None
    epoch_certificate_issuance_owner: DecisionPacketEpochIssuanceOwner | None = None
    human_decision_service: HumanDecisionService | None = None
    acquisition_action_service: AcquisitionActionService | None = None
    acquisition_movement_service: AcquisitionMovementService | None = None
    production_approval_resolver: ProductionApprovalPacketResolver | None = None
    lifecycle: RuntimeLifecycleState = field(default_factory=RuntimeLifecycleState)

    @classmethod
    def build(
        cls,
        *,
        config: RuntimeContainerConfig,
        deployment_policy: ResolvedExecutionPolicy,
        runtime_security: RuntimeSecurityConfig,
    ) -> RuntimeServiceContainer:
        """Construct a container with lazy startup for heavyweight services."""
        overrides = config.overrides
        if (
            overrides.control_service is not None
            and overrides.evaluation_safety_authorities_source is not None
        ):
            raise ValueError(
                "evaluation_safety_authorities_source_conflicts_with_prebuilt_control_service"
            )
        common_async_tools.configure_shared_executor_profile(config.shared_executor_profile())
        if type(config.candidate_simulation_profiles) is not tuple:
            raise TypeError("candidate_simulation_profiles_must_be_tuple")
        if type(config.candidate_simulation_model_declarations) is not tuple:
            raise TypeError("candidate_simulation_model_declarations_must_be_tuple")
        if type(config.generic_cycle_simulation_profiles) is not tuple:
            raise TypeError("generic_cycle_simulation_profiles_must_be_tuple")
        if type(config.allow_candidate_run_predictive_calibration_surface) is not bool:
            raise TypeError("candidate_run_predictive_calibration_surface_flag_must_be_bool")
        if type(config.enable_contract_testing_credal_source_attempts) is not bool:
            raise TypeError("contract_testing_credal_source_attempts_flag_must_be_bool")
        if (
            config.enable_contract_testing_credal_source_attempts
            and deployment_policy.default_profile != "dev"
        ):
            raise ValueError("contract_testing_credal_source_attempts_dev_profile_required")
        if config.enable_contract_testing_credal_source_attempts and not (
            config.generic_cycle_simulation_profiles
            and config.generic_cycle_simulation_root_profile_id
        ):
            raise ValueError("contract_testing_credal_source_attempts_require_generic_owner")
        if config.generic_cycle_simulation_root_profile_id is not None and (
            not isinstance(config.generic_cycle_simulation_root_profile_id, str)
            or not config.generic_cycle_simulation_root_profile_id.strip()
        ):
            raise ValueError("generic_cycle_simulation_root_profile_id_invalid")
        runtime_metrics = overrides.runtime_metrics or (config.metrics_factory or get_metrics)()
        runtime_tracer = overrides.runtime_tracer or (config.tracer_factory or get_tracer)()
        producer_settlement_store = overrides.llm_producer_settlement_store
        if producer_settlement_store is None:
            producer_settlement_store = BudgetMiddleware(
                BudgetState(),
                ledger=FileBudgetLedger(
                    config.core_runs_root / ".runtime" / "llm-cost-ledger.json"
                ),
            )
        if type(producer_settlement_store) is not BudgetMiddleware:
            raise TypeError("llm_producer_settlement_store_must_be_budget_middleware")
        cache_reuse_authorizer = overrides.llm_cache_reuse_authorizer
        if cache_reuse_authorizer is not None and not callable(
            getattr(cache_reuse_authorizer, "authorize_reuse", None)
        ):
            raise TypeError("llm_cache_reuse_authorizer_invalid")
        llm_prompt_cache = overrides.llm_prompt_cache
        if llm_prompt_cache is not None and not all(
            callable(getattr(llm_prompt_cache, name, None)) for name in ("get", "put")
        ):
            raise TypeError("llm_prompt_cache_invalid")
        if llm_prompt_cache is None and cache_reuse_authorizer is not None:
            from polisyos.scientist.orchestration.llm.factory import GatewayLLMConfig
            from polisyos.scientist.orchestration.llm.prompt_cache import InMemoryPromptCache

            cache_config = GatewayLLMConfig.from_env()
            if (
                cache_config is not None
                and cache_config.cache_maxsize > 0
                and cache_config.cache_ttl_s > 0
            ):
                llm_prompt_cache = InMemoryPromptCache(
                    maxsize=cache_config.cache_maxsize,
                    default_ttl_s=cache_config.cache_ttl_s,
                )
        try:
            _ = producer_settlement_store.settlement_owner_identity
        except (OSError, RuntimeError, ValueError) as exc:
            raise ValueError("llm_producer_settlement_store_must_be_durable") from exc
        runtime_api_context = overrides.runtime_api_context or build_runtime_api_context(
            cas_root=config.cas_root,
            core_runs_root=config.core_runs_root,
            max_preview_bytes=config.max_preview_bytes,
            lineage_max_depth=config.lineage_max_depth,
            lineage_max_nodes=config.lineage_max_nodes,
            allow_unscoped_artifacts=config.allow_unscoped_artifacts,
            allow_candidate_run_predictive_calibration_surface=(
                config.allow_candidate_run_predictive_calibration_surface
            ),
            artifact_redaction_hooks=config.artifact_redaction_hooks,
            metrics=runtime_metrics,
            tracer=runtime_tracer,
            producer_settlement_store=producer_settlement_store,
        )
        runtime_api_context.debug.bind_producer_settlement_store(producer_settlement_store)
        candidate_context_owner = (
            ConfiguredCandidateSimulationContextAdmissionOwner(
                profiles=config.candidate_simulation_profiles,
                model_declarations=config.candidate_simulation_model_declarations,
                store=runtime_api_context.store,
            )
            if config.candidate_simulation_profiles
            or config.candidate_simulation_model_declarations
            else None
        )
        from polisyos.runtime.quality.generic_simulation_admission import (
            GenericCycleSimulationAdmissionOwner,
            GenericCycleSimulationProfileV1,
        )

        if any(
            type(profile) is not GenericCycleSimulationProfileV1
            for profile in config.generic_cycle_simulation_profiles
        ):
            raise TypeError("generic_cycle_simulation_profiles_must_be_typed")
        if bool(config.generic_cycle_simulation_profiles) != bool(
            config.generic_cycle_simulation_root_profile_id
        ):
            raise ValueError("generic_cycle_simulation_root_profile_configuration_incomplete")
        generic_context_owner = (
            GenericCycleSimulationAdmissionOwner(
                profiles=config.generic_cycle_simulation_profiles,
                store=runtime_api_context.store,
            )
            if config.generic_cycle_simulation_profiles
            else None
        )
        if generic_context_owner is not None:
            root_profiles = tuple(
                profile
                for profile in generic_context_owner.profiles
                if profile.profile_id == config.generic_cycle_simulation_root_profile_id
            )
            if len(root_profiles) != 1 or root_profiles[0].profile_selection_kind != "problem":
                raise ValueError("generic_cycle_simulation_root_profile_not_configured")
            generic_root_selectors = {profile.profile_selection_ref for profile in root_profiles}
            candidate_selectors = {
                getattr(profile, "profile_selection_ref", None)
                for profile in config.candidate_simulation_profiles
            }
            if generic_root_selectors & candidate_selectors:
                raise ValueError("simulation_profile_selection_owner_ambiguous")
        runtime_rate_limiter, runtime_idempotency_store, runtime_mutation_audit = (
            build_runtime_mutation_services(
                cas_root=config.cas_root,
                metrics=runtime_metrics,
            )
        )
        control_registry_providers = overrides.control_registry_providers
        if control_registry_providers is None:
            control_registry_providers = _resolve_default_control_registry_providers(
                catalog_run_profile=config.catalog_run_profile,
                catalog_source_selection=config.catalog_source_selection,
            )
        else:
            if config.catalog_run_profile is not None:
                if control_registry_providers.catalog_run_profile not in (
                    None,
                    config.catalog_run_profile,
                ):
                    raise ValueError("catalog_run_profile_runtime_configuration_mismatch")
                if control_registry_providers.catalog_run_profile is None:
                    control_registry_providers = replace(
                        control_registry_providers,
                        catalog_run_profile=config.catalog_run_profile,
                    )
            if config.catalog_source_selection is not None:
                supplied = control_registry_providers.catalog_source_selection
                if supplied not in (None, config.catalog_source_selection):
                    raise ValueError("catalog_source_selection_runtime_configuration_mismatch")
                if supplied is None:
                    control_registry_providers = replace(
                        control_registry_providers,
                        catalog_source_selection=config.catalog_source_selection,
                    )
        if overrides.decision_validity_service is not None and not (
            ControlPlaneService.is_decision_validity_owner(overrides.decision_validity_service)
        ):
            raise ValueError("decision_validity_owner_invalid")
        decision_validity_service = (
            overrides.decision_validity_service
            or ControlPlaneService.build_decision_validity_owner(runtime_api_context.store)
        )
        if decision_validity_service._store is not runtime_api_context.store:
            raise ValueError("decision_validity_owner_store_mismatch")
        if overrides.control_service is not None and not isinstance(
            overrides.control_service, ControlPlaneService
        ):
            raise ValueError("control_service_owner_invalid")
        if (
            overrides.legal_query_encoder_provider is not None
            and type(overrides.legal_query_encoder_provider) is not LegalQueryEncoderProvider
        ):
            raise ValueError("legal_query_encoder_provider_invalid")
        if candidate_context_owner is not None and overrides.control_service is not None:
            override_owner = overrides.control_service._cycle_substrate_context_admission_owner
            if (
                type(override_owner) is not ConfiguredCandidateSimulationContextAdmissionOwner
                or override_owner.profiles != candidate_context_owner.profiles
                or override_owner.model_declarations != candidate_context_owner.model_declarations
                or override_owner.store is not runtime_api_context.store
            ):
                raise ValueError("candidate_simulation_context_owner_override_mismatch")
        if overrides.control_service is not None:
            override_generic_owner = getattr(
                overrides.control_service,
                "_generic_cycle_simulation_admission_owner",
                None,
            )
            override_generic_root = getattr(
                overrides.control_service,
                "_generic_cycle_simulation_root_profile_id",
                None,
            )
            if generic_context_owner is None:
                if (
                    override_generic_owner is not None
                    or override_generic_root is not None
                    or getattr(
                        overrides.control_service,
                        "_enable_contract_testing_credal_source_attempts",
                        False,
                    )
                ):
                    raise ValueError("generic_cycle_simulation_context_owner_override_mismatch")
            elif (
                type(override_generic_owner) is not GenericCycleSimulationAdmissionOwner
                or override_generic_owner.store is not runtime_api_context.store
                or override_generic_owner.profiles != generic_context_owner.profiles
                or override_generic_root != config.generic_cycle_simulation_root_profile_id
                or getattr(
                    overrides.control_service,
                    "_enable_contract_testing_credal_source_attempts",
                    False,
                )
                != config.enable_contract_testing_credal_source_attempts
            ):
                raise ValueError("generic_cycle_simulation_context_owner_override_mismatch")
        if type(config.normative_authority_trust) is not NormativeAuthorityTrust:
            raise TypeError("normative_deployment_trust_must_be_typed")
        if overrides.control_service is not None and (
            overrides.control_service._normative_authority_trust != config.normative_authority_trust
        ):
            raise ValueError("normative_deployment_trust_owner_mismatch")
        inherited_claim_owner = (
            overrides.control_service._epoch_claim_lifecycle_bridge.claim_owner
            if overrides.control_service is not None
            else None
        )
        claim_ledger_owner = (
            overrides.claim_ledger_owner
            or inherited_claim_owner
            or build_default_claim_ledger_owner(store=runtime_api_context.store)
        )
        if getattr(claim_ledger_owner, "store", None) is not runtime_api_context.store:
            raise ValueError("claim_ledger_owner_store_mismatch")
        inherited_claim_bridge = (
            overrides.control_service._epoch_claim_lifecycle_bridge
            if overrides.control_service is not None
            else None
        )
        epoch_claim_lifecycle_bridge = (
            overrides.epoch_claim_lifecycle_bridge
            or inherited_claim_bridge
            or build_epoch_claim_lifecycle_bridge(
                completed_batches=decision_validity_service,
                claim_owner=claim_ledger_owner,
                artifacts=runtime_api_context.store,
            )
        )
        if (
            not isinstance(epoch_claim_lifecycle_bridge, EpochClaimLifecycleBridgeService)
            or epoch_claim_lifecycle_bridge.completed_batches is not decision_validity_service
            or epoch_claim_lifecycle_bridge.claim_owner is not claim_ledger_owner
            or epoch_claim_lifecycle_bridge.artifacts is not runtime_api_context.store
        ):
            raise ValueError("epoch_claim_lifecycle_bridge_owner_store_mismatch")
        if overrides.control_service is None:
            promotion_runtime = PromotionRuntime(
                store=runtime_api_context.store,
                completed_epoch_batches=decision_validity_service,
                signature_verifier=runtime_api_context.signature_verifier,
            )
        else:
            if not isinstance(overrides.control_service, ControlPlaneService):
                raise ValueError("control_service_owner_invalid")
            promotion_runtime = overrides.control_service._promotion_runtime
            if (
                config.repo_root is not None
                and overrides.control_service._repo_root != config.repo_root
            ):
                raise ValueError("runtime_source_repo_root_control_service_mismatch")
            if (
                not isinstance(promotion_runtime, PromotionRuntime)
                or overrides.control_service._decision_validity_service
                is not decision_validity_service
                or promotion_runtime.store is not runtime_api_context.store
                or promotion_runtime.signature_verifier
                is not runtime_api_context.signature_verifier
                or promotion_runtime.epoch_n9_evidence_resolver._completed_batches
                is not decision_validity_service
                or overrides.control_service._epoch_claim_lifecycle_bridge
                is not epoch_claim_lifecycle_bridge
            ):
                raise ValueError("control_service_owner_runtime_mismatch")
        return cls(
            config=config,
            deployment_policy=deployment_policy,
            runtime_security=runtime_security,
            runtime_metrics=runtime_metrics,
            runtime_tracer=runtime_tracer,
            runtime_api_context=runtime_api_context,
            review_collaboration_hub=(
                overrides.review_collaboration_hub or ReviewCollaborationHub()
            ),
            runtime_access_audit=(
                overrides.runtime_access_audit
                or RuntimeDataAccessAuditTrail(
                    path=config.cas_root / "runtime" / "audit" / "access.jsonl"
                )
            ),
            runtime_rate_limiter=overrides.runtime_rate_limiter or runtime_rate_limiter,
            runtime_idempotency_store=(
                overrides.runtime_idempotency_store or runtime_idempotency_store
            ),
            runtime_mutation_audit=(overrides.runtime_mutation_audit or runtime_mutation_audit),
            runtime_review_opa_guard=(
                overrides.runtime_review_opa_guard or build_runtime_opa_async_guard()
            ),
            epoch_anchor_custody_provider=(build_production_epoch_anchor_custody_provider()),
            promotion_runtime=promotion_runtime,
            decision_validity_service=decision_validity_service,
            claim_ledger_owner=claim_ledger_owner,
            epoch_claim_lifecycle_bridge=epoch_claim_lifecycle_bridge,
            control_registry_providers=control_registry_providers,
            public_decision_verification_service=build_public_decision_verification_service(
                cas_root=config.cas_root,
                store=runtime_api_context.store,
                claim_owner=claim_ledger_owner,
            ),
            candidate_simulation_context_admission_owner=candidate_context_owner,
            generic_cycle_simulation_admission_owner=(
                generic_context_owner
                if overrides.control_service is None
                else overrides.control_service._generic_cycle_simulation_admission_owner
            ),
            generic_cycle_simulation_root_profile_id=(
                config.generic_cycle_simulation_root_profile_id
            ),
            legal_query_encoder_provider=overrides.legal_query_encoder_provider,
            llm_producer_settlement_store=producer_settlement_store,
            llm_cache_reuse_authorizer=cache_reuse_authorizer,
            llm_prompt_cache=llm_prompt_cache,
            control_service=overrides.control_service,
        )

    def install(self, app: Any) -> None:
        """Expose the container and legacy-compatible aliases on `app.state`."""
        deployment_security = getattr(app.state, "runtime_deployment_security", None)
        if deployment_security is not None:
            from polisyos.runtime.http.deployment_security import (
                require_factory_produced_deployment_security,
            )

            deployment_security = require_factory_produced_deployment_security(deployment_security)
            self.runtime_security = replace(
                self.runtime_security,
                human_decision_custody=deployment_security.human_decision_custody,
            )
            from polisyos.runtime.quality.semantic_epoch import SemanticEpochService

            epoch_deployment = deployment_security.epoch_deployment
            from polisyos.runtime.quality.epoch_transition_verification import (
                build_deployed_epoch_issuance_owner,
                configure_deployed_epoch_intake,
            )

            configure_deployed_epoch_intake(
                owner=self.decision_validity_service,
                deployment=epoch_deployment,
            )
            self.epoch_certificate_issuance_owner = build_deployed_epoch_issuance_owner(
                store=self.runtime_api_context.store,
                deployment=epoch_deployment,
            )
            if self.control_service is not None:
                self.control_service._epoch_certificate_issuance_owner = (
                    self.epoch_certificate_issuance_owner
                )
            with epoch_deployment.composition_scope():
                self.epoch_anchor_custody_provider = (
                    build_production_epoch_anchor_custody_provider()
                )
            self.runtime_api_context.temporal._semantic_epoch_service = (
                SemanticEpochService.for_deployment_policy_query(
                    artifact_store=self.runtime_api_context.store,
                    deployment=epoch_deployment,
                )
            )
            self.promotion_runtime.configure_semantic_epoch_service(
                semantic_epoch_service=self.runtime_api_context.temporal._semantic_epoch_service
            )
        app.state.runtime_container = self
        self._bind_legacy_state(app)

    async def startup(self, app: Any) -> None:
        """Transition the container to ready and initialize lazy services."""
        self.lifecycle.mark("starting")
        try:
            control_service = self.control_service
            if control_service is None:
                control_service = ControlPlaneService(
                    cas_root=self.config.cas_root,
                    core_runs_root=self.config.core_runs_root,
                    repo_root=self.config.repo_root,
                    metrics=self.runtime_metrics,
                    tracer=self.runtime_tracer,
                    artifact_store=self.runtime_api_context.store,
                    signature_verifier=self.runtime_api_context.signature_verifier,
                    evaluation_safety_authorities_source=(
                        self.config.overrides.evaluation_safety_authorities_source
                    ),
                    async_artifact_store=self.runtime_api_context.async_store,
                    registry_providers=self.control_registry_providers,
                    decision_validity_service=self.decision_validity_service,
                    epoch_certificate_issuance_owner=self.epoch_certificate_issuance_owner,
                    promotion_runtime=self.promotion_runtime,
                    epoch_claim_lifecycle_bridge=self.epoch_claim_lifecycle_bridge,
                    normative_authority_trust=self.config.normative_authority_trust,
                    published_signature_population_provider=(
                        PublicVerificationRecordPopulationProvider(
                            source=self.public_decision_verification_service,
                            admission_source=self.public_decision_verification_service.governed_owner,
                            store=self.runtime_api_context.store,
                        )
                    ),
                    cycle_substrate_context_admission_owner=(
                        self.candidate_simulation_context_admission_owner
                    ),
                    generic_cycle_simulation_admission_owner=(
                        self.generic_cycle_simulation_admission_owner
                    ),
                    generic_cycle_simulation_root_profile_id=(
                        self.generic_cycle_simulation_root_profile_id
                    ),
                    enable_contract_testing_credal_source_attempts=(
                        self.config.enable_contract_testing_credal_source_attempts
                    ),
                    llm_producer_settlement_store=self.llm_producer_settlement_store,
                    llm_cache_reuse_authorizer=self.llm_cache_reuse_authorizer,
                    llm_prompt_cache=self.llm_prompt_cache,
                )
                self.control_service = control_service
            control_service.bind_llm_producer_settlement_store(self.llm_producer_settlement_store)
            control_service.bind_llm_cache_reuse(
                authorizer=self.llm_cache_reuse_authorizer,
                prompt_cache=self.llm_prompt_cache,
            )
            self.runtime_api_context.debug.bind_producer_control_job_store(
                control_service._control_store
            )
            control_service.bind_legal_query_encoder_provider(self.legal_query_encoder_provider)
            custody = self._resolve_human_decision_custody(app)
            from polisyos.runtime.http.services.human_decision_contracts import (
                HumanDecisionResolverPolicy,
            )
            from polisyos.runtime.http.services.human_decisions import (
                HumanDecisionService,
            )

            access_audit_path = self.config.cas_root / "runtime" / "audit" / "access.jsonl"
            self.human_decision_service = HumanDecisionService(
                authority_sink=control_service.human_decision_sink,
                custody=custody,
                resolver_policy=HumanDecisionResolverPolicy(
                    expected_consumer=("polisyos.runtime.quality.agent_action_authority"),
                    expected_audience="polisyos-runtime",
                    principal_audience="polisyos-runtime",
                    expected_agent_operation=None,
                    required_permission="runs.human_decisions.create",
                ),
                access_audit_path=access_audit_path,
            )
            from polisyos.runtime.quality.approval import (
                _issue_production_decision_packet_resolver,
            )

            self.production_approval_resolver = _issue_production_decision_packet_resolver(
                self.human_decision_service,
                expected_audience="polisyos-runtime",
                deployment_security=getattr(
                    app.state,
                    "runtime_deployment_security",
                    None,
                ),
            )
            from polisyos.runtime.http.deployment_security_attestation import (
                DeploymentSecurityAttestationError,
                _register_production_approval_resolver_installation,
            )

            try:
                _register_production_approval_resolver_installation(
                    app,
                    container=self,
                    service=self.human_decision_service,
                    custody=self.human_decision_service.custody,
                    verifier_epoch=self.production_approval_resolver.issuer_epoch,
                    resolver=self.production_approval_resolver,
                )
            except DeploymentSecurityAttestationError:
                # The existing request guard owns the typed 503 surface for a
                # mutated deployment authority.  Keep startup observable while
                # removing the unregistered resolver from every consumer seam.
                self.production_approval_resolver = None
            from polisyos.runtime.http.deployment_security import (
                require_factory_produced_deployment_security,
            )
            from polisyos.runtime.http.services.acquisition_authority_provider import (
                ProductionAcquisitionAuthorityProvider,
            )
            from polisyos.runtime.quality.acquisition_movement import (
                AcquisitionMovementService,
            )
            from polisyos.runtime.quality.epoch_deployment import build_epoch_deployment

            deployment = getattr(app.state, "runtime_deployment_security", None)
            if deployment is not None:
                deployment = require_factory_produced_deployment_security(deployment)
            epoch_deployment = (
                deployment.epoch_deployment
                if deployment is not None
                else build_epoch_deployment(None)
            )
            self.acquisition_movement_service = AcquisitionMovementService(
                control_store=control_service._control_store,
                artifact_store=control_service._artifact_store,
                event_log=control_service._diagnostic_event_log,
                epoch_deployment=epoch_deployment,
            )
            authority_provider = self.config.overrides.acquisition_authority_provider
            if authority_provider is None and deployment is not None:
                authority_provider = ProductionAcquisitionAuthorityProvider(
                    deployment_security=deployment,
                    artifact_store=control_service._artifact_store,
                    event_log=control_service._diagnostic_event_log,
                    idempotency_store=self.runtime_idempotency_store,
                    execution_profile=self.deployment_policy.effective_profile,
                    human_decision_service=self.human_decision_service,
                    production_approval_resolver=self.production_approval_resolver,
                )
            self.acquisition_action_service = AcquisitionActionService(
                control_service=control_service,
                human_decision_service=self.human_decision_service,
                authority_provider=authority_provider,
                execution_port=self.config.overrides.acquisition_execution_port,
                world_growth_config=(
                    deployment.config.acquisition_world_growth if deployment is not None else None
                ),
                epoch_deployment=epoch_deployment,
                movement_service=self.acquisition_movement_service,
            )
            control_service.bind_capability_discovery_service(
                CapabilityDiscoveryService(
                    providers=(self.control_registry_providers.capability_discovery_providers),
                    operation_registry=(
                        self.control_registry_providers.capability_live_operation_registry
                    ),
                    conformance_verifier=(
                        self.control_registry_providers.capability_conformance_verifier
                    ),
                    policy_resolver=control_service.execution_policy_resolver,
                    production_approval_resolver=self.production_approval_resolver,
                )
            )
            self._bind_legacy_state(app)
            self.lifecycle.mark("ready")
        except (
            AttributeError,
            KeyError,
            OSError,
            RuntimeError,
            TypeError,
            ValueError,
        ) as exc:
            self.lifecycle.mark("failed", error=str(exc))
            raise

    async def shutdown(self, app: Any) -> None:
        """Close owned resources in dependency order."""
        self.lifecycle.mark("stopping")
        error: str | None = None
        try:
            await _close_maybe_async(self.review_collaboration_hub)
            runtime_store = getattr(self.runtime_api_context, "store", None)
            if runtime_store is not None and hasattr(runtime_store, "close"):
                runtime_store.close()
            if self.control_service is not None and hasattr(self.control_service, "close"):
                self.control_service.close()
            if self.llm_prompt_cache is not None:
                clear_cache = getattr(self.llm_prompt_cache, "clear", None)
                if callable(clear_cache):
                    clear_cache()
        except (AttributeError, OSError, RuntimeError, TypeError, ValueError) as exc:
            error = str(exc)
            self.lifecycle.mark("failed", error=error)
            raise
        finally:
            self._bind_legacy_state(app)
            if error is None:
                self.lifecycle.mark("stopped")

    def health_payload(self) -> dict[str, Any]:
        """Return a serializable lifecycle/dependency snapshot for health endpoints."""
        dependencies = {
            "runtime_api_context": _resource_state(self.runtime_api_context),
            "review_collaboration_hub": _resource_state(self.review_collaboration_hub),
            "control_plane_service": _resource_state(self.control_service, pending_ok=True),
            "human_decision_service": _human_decision_resource_state(self.human_decision_service),
            "acquisition_action_service": _resource_state(
                self.acquisition_action_service,
                pending_ok=True,
            ),
            "production_approval_resolver": _resource_state(
                self.production_approval_resolver,
                pending_ok=True,
            ),
            "runtime_metrics": _resource_state(self.runtime_metrics),
            "runtime_tracer": _resource_state(self.runtime_tracer),
            "runtime_access_audit": _resource_state(self.runtime_access_audit),
            "runtime_rate_limiter": _resource_state(self.runtime_rate_limiter),
            "runtime_idempotency_store": _resource_state(self.runtime_idempotency_store),
            "runtime_mutation_audit": _resource_state(self.runtime_mutation_audit),
        }
        return {
            "status": self.lifecycle.status,
            "started_at": (
                self.lifecycle.started_at.isoformat()
                if self.lifecycle.started_at is not None
                else None
            ),
            "stopped_at": (
                self.lifecycle.stopped_at.isoformat()
                if self.lifecycle.stopped_at is not None
                else None
            ),
            "last_error": self.lifecycle.last_error,
            "dependency_graph": {
                "runtime_api_context": [
                    "artifact_store",
                    "run_index",
                    "timeline",
                    "debug",
                    "feedback",
                    "fabric",
                    "lineage",
                    "compare",
                    "temporal",
                    "scenarios",
                    "artifacts",
                    "analysis",
                ],
                "control_plane_service": ["runtime_metrics", "runtime_tracer"],
                "human_decision_service": [
                    "control_plane_service",
                    "runtime_access_audit",
                    "deployment_security",
                ],
                "production_approval_resolver": [
                    "human_decision_service",
                    "deployment_security",
                ],
                "acquisition_action_service": [
                    "control_plane_service",
                    "human_decision_service",
                    "runtime_access_audit",
                ],
                "mutation_policy": [
                    "runtime_rate_limiter",
                    "runtime_idempotency_store",
                    "runtime_mutation_audit",
                ],
                "review_collaboration_hub": [],
                "runtime_access_audit": [],
            },
            "dependencies": dependencies,
        }

    def _bind_legacy_state(self, app: Any) -> None:
        if self.control_service is not None:
            self.runtime_api_context.debug.bind_producer_control_job_store(
                self.control_service._control_store
            )
            self.runtime_api_context.scenarios.bind_scenario_head_store(
                self.control_service.scenario_head_store,
            )
        app.state.runtime_api_ctx = self.runtime_api_context
        app.state.review_collaboration_hub = self.review_collaboration_hub
        app.state.execution_policy = self.deployment_policy
        app.state.runtime_security = self.runtime_security
        app.state.allow_fixture_identity = self.runtime_security.allow_fixture_identity
        app.state.runtime_metrics = self.runtime_metrics
        app.state.runtime_tracer = self.runtime_tracer
        app.state.runtime_access_audit = self.runtime_access_audit
        app.state.runtime_rate_limiter = self.runtime_rate_limiter
        app.state.runtime_idempotency_store = self.runtime_idempotency_store
        app.state.runtime_mutation_audit = self.runtime_mutation_audit
        app.state.runtime_review_opa_guard = self.runtime_review_opa_guard
        app.state._control_service = self.control_service
        app.state._human_decision_service = self.human_decision_service
        app.state._acquisition_action_service = self.acquisition_action_service
        app.state._production_approval_resolver = self.production_approval_resolver
        app.state.promotion_runtime = self.promotion_runtime

    def _resolve_human_decision_custody(self, app: Any) -> Any:
        """Re-attest custody at service construction; aliases never carry authority."""

        from polisyos.runtime.http.deployment_security import (
            DeploymentHumanDecisionCustody,
            require_factory_produced_deployment_security,
        )

        installed = getattr(app.state, "runtime_deployment_security", None)
        configured = self.runtime_security.human_decision_custody
        if installed is None:
            if configured is not None:
                raise TypeError("human-decision custody requires deployment attestation")
            return DeploymentHumanDecisionCustody(
                available=False,
                unavailability_code="DS9-DECISION-PRODUCER-MISSING",
            )
        try:
            attested = require_factory_produced_deployment_security(installed)
        except TypeError:
            return DeploymentHumanDecisionCustody(
                available=False,
                unavailability_code="DS9-DECISION-SOURCE-INVALID",
            )
        custody = attested.human_decision_custody
        if configured is not custody:
            raise TypeError("runtime human-decision custody identity changed")
        return custody


def get_runtime_container(subject: Any) -> RuntimeServiceContainer | None:
    """Return the installed runtime container from a request/websocket/app."""
    app = getattr(subject, "app", subject)
    state = getattr(app, "state", None)
    container = getattr(state, "runtime_container", None)
    return container if isinstance(container, RuntimeServiceContainer) else None


def resolve_runtime_api_context(subject: Any) -> RuntimeApiContext | None:
    """Resolve the public runtime API context from the runtime container."""
    container = get_runtime_container(subject)
    return container.runtime_api_context if container is not None else None


def resolve_control_service(subject: Any) -> ControlPlaneService | None:
    """Resolve the public control-plane service from the runtime container."""
    container = get_runtime_container(subject)
    if container is None:
        return None
    return (
        container.control_service
        if isinstance(container.control_service, ControlPlaneService)
        else None
    )


def resolve_human_decision_service(subject: Any) -> HumanDecisionService | None:
    """Resolve the deployment-composed human-decision service."""

    from polisyos.runtime.http.services.human_decisions import HumanDecisionService

    container = get_runtime_container(subject)
    if container is None:
        return None
    service = container.human_decision_service
    return service if type(service) is HumanDecisionService else None


def resolve_acquisition_action_service(subject: Any) -> AcquisitionActionService | None:
    """Resolve the sole container-composed acquisition action service."""

    container = get_runtime_container(subject)
    if container is None:
        return None
    service = container.acquisition_action_service
    return service if type(service) is AcquisitionActionService else None


def resolve_production_approval_resolver(
    subject: Any,
) -> ProductionApprovalPacketResolver | None:
    """Resolve the sole deployment-issued production approval resolver."""

    from polisyos.runtime.quality.approval import ProductionApprovalPacketResolver

    container = get_runtime_container(subject)
    if container is None:
        return None
    resolver = container.production_approval_resolver
    if type(resolver) is not ProductionApprovalPacketResolver:
        return None
    from polisyos.runtime.http.deployment_security_attestation import (
        DeploymentSecurityAttestationError,
        require_installed_production_approval_resolver,
    )

    try:
        registered = require_installed_production_approval_resolver(
            subject,
            candidate=resolver,
        )
    except DeploymentSecurityAttestationError:
        return None
    return resolver if registered is resolver else None


def resolve_review_collaboration_hub(subject: Any) -> ReviewCollaborationHub | None:
    """Resolve the review collaboration hub from the runtime container."""
    container = get_runtime_container(subject)
    return container.review_collaboration_hub if container is not None else None


def resolve_runtime_metrics(subject: Any) -> Any | None:
    """Resolve runtime metrics provider from the runtime container."""
    container = get_runtime_container(subject)
    return container.runtime_metrics if container is not None else None


def resolve_runtime_tracer(subject: Any) -> Any | None:
    """Resolve runtime tracer provider from the runtime container."""
    container = get_runtime_container(subject)
    return container.runtime_tracer if container is not None else None


def resolve_runtime_access_audit(subject: Any) -> RuntimeDataAccessAuditTrail | None:
    """Resolve the data-access audit trail from the runtime container."""
    container = get_runtime_container(subject)
    return container.runtime_access_audit if container is not None else None


def resolve_runtime_security(subject: Any) -> RuntimeSecurityConfig | None:
    """Resolve runtime security config from the runtime container."""
    container = get_runtime_container(subject)
    return container.runtime_security if container is not None else None


def resolve_runtime_rate_limiter(subject: Any) -> Any | None:
    """Resolve runtime mutation/live-stream rate limiter from the runtime container."""
    container = get_runtime_container(subject)
    return container.runtime_rate_limiter if container is not None else None


def resolve_runtime_review_opa_guard(subject: Any) -> Any | None:
    """Resolve runtime OPA async guard from the runtime container."""
    container = get_runtime_container(subject)
    return container.runtime_review_opa_guard if container is not None else None


def _resolve_default_control_registry_providers(
    *,
    catalog_run_profile: CatalogRunProfile | None = None,
    catalog_source_selection: CatalogServingSourceSelection | None = None,
) -> ControlRegistryProviders:
    return resolve_control_registry_providers(
        catalog_run_profile=catalog_run_profile,
        catalog_source_selection=catalog_source_selection,
    )


async def _close_maybe_async(resource: Any) -> None:
    close = getattr(resource, "close", None)
    if not callable(close):
        return
    result = close()
    if inspect.isawaitable(result):
        await result


def _resource_state(resource: Any, *, pending_ok: bool = False) -> dict[str, str]:
    if resource is None:
        return {"status": "pending" if pending_ok else "missing"}
    return {
        "status": "ready",
        "type": type(resource).__name__,
    }


def _human_decision_resource_state(
    service: HumanDecisionService | None,
) -> dict[str, str]:
    if service is None:
        return {"status": "pending"}
    if service.available:
        return {"status": "ready", "type": type(service).__name__}
    return {
        "status": "unavailable",
        "type": type(service).__name__,
        "reason": service.unavailability_code or "DS9-DECISION-PRODUCER-MISSING",
    }


__all__ = [
    "LegalQueryEncoderProvider",
    "LegalQueryEncoderProviderError",
    "RuntimeContainerConfig",
    "RuntimeContainerOverrides",
    "RuntimeLifecycleState",
    "RuntimeServiceContainer",
    "get_runtime_container",
    "resolve_acquisition_action_service",
    "resolve_control_service",
    "resolve_human_decision_service",
    "resolve_production_approval_resolver",
    "resolve_review_collaboration_hub",
    "resolve_runtime_access_audit",
    "resolve_runtime_api_context",
    "resolve_runtime_metrics",
    "resolve_runtime_rate_limiter",
    "resolve_runtime_review_opa_guard",
    "resolve_runtime_security",
    "resolve_runtime_tracer",
]
