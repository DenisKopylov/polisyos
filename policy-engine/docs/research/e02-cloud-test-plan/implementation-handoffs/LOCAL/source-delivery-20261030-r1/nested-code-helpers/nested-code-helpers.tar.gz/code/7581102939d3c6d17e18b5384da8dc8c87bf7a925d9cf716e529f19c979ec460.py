def body():
    return None
value = body.__code__
def expose(unknown):
    if callable(None):
        values = [value]
    else:
        values = unknown
    first, = values
    opaque(first)
