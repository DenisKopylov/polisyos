"""Generate source-only unified patches; never imports or executes product code."""
from __future__ import annotations

import difflib
from pathlib import Path

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
LEAF = ROOT / "LOCAL/raw/e02-execution-20261027/repairs/SQL-owner-chain-r3-leaf-consumer"
PARENT = ROOT / "LOCAL/raw/e02-execution-20261027/repairs/SQL-owner-chain-r3/postimages/policy-engine"


def transform(path: Path, replacements: list[tuple[str, str]]) -> str:
    text = path.read_text()
    for before, after in replacements:
        count = text.count(before)
        if count != 1:
            raise RuntimeError(f"expected one source anchor in {path}: got {count}: {before[:80]!r}")
        text = text.replace(before, after, 1)
    return text


def patch_for(path: str, before: str, after: str, *, fromfile: str | None = None) -> str:
    old_lines = before.splitlines(keepends=True)
    new_lines = after.splitlines(keepends=True)
    old_name = fromfile or f"a/{path}"
    new_name = fromfile or f"b/{path}"
    return "".join(
        difflib.unified_diff(old_lines, new_lines, fromfile=old_name, tofile=new_name, n=3)
    )


def protocol_patch() -> str:
    rel = "policy-engine/src/polisyos/foundry/methods/backends/protocol.py"
    path = ROOT / rel
    original = path.read_text()
    evidence = '''@dataclass(frozen=True, slots=True)
class RestrictedMethodInvocationEvidence:
    """Internal exact-call observation before binding it to a graph occurrence."""

    status: Literal["verified", "unavailable"]
    limitation: str | None
    profile_id: str
    profile_revision_sha256: str
    method_fqn: str
    method_version: str
    method_abi_digest: str
    method_callable_sha256: str | None
    runner_callable_sha256: str | None
    backend_runtime_fingerprint: str | None
    state_reads: tuple[str, ...]
    parameter_reads: tuple[str, ...]
    parameter_origin: Literal["signature_default", "explicit_parameter", "not_established"]
    poverty_line_value: None
    output_slot_id: str
    output_value_path: tuple[str, ...]
    output_value_sha256: str | None


'''
    anchor = "@dataclass(frozen=True, slots=True)\nclass MethodResult:\n"
    if original.count(anchor) != 1:
        raise RuntimeError("MethodResult source anchor changed")
    updated = original.replace(anchor, evidence + anchor, 1)
    before = "    validated_bound: ValidatedBound | None = None\n"
    after = before + "    restricted_invocation: RestrictedMethodInvocationEvidence | None = None\n"
    if updated.count(before) != 1:
        raise RuntimeError("MethodResult field anchor changed")
    updated = updated.replace(before, after, 1)
    return patch_for(rel, original, updated)


def numpy_patch() -> str:
    rel = "policy-engine/src/polisyos/foundry/methods/backends/numpy_runner.py"
    path = ROOT / rel
    original = path.read_text()
    updated = original
    before = "        runtime_context: OwnedAttemptAnchorDispatchContext | None = None,\n    ) -> MethodResult:\n        resolved = _resolve_params(signature, params)\n"
    after = "        runtime_context: OwnedAttemptAnchorDispatchContext | None = None,\n        _captured_dispatch_execute: Any | None = None,\n    ) -> MethodResult:\n        pure_step = getattr(method_class, \"pure_step\", None)\n        postprocess = getattr(method_class, \"postprocess_output\", None)\n        resolved = _resolve_params(signature, params)\n"
    if updated.count(before) != 1:
        raise RuntimeError("NumpyRunner signature anchor changed")
    updated = updated.replace(before, after, 1)
    before = """        started = time.perf_counter()
        if runtime_context is None:
            output = method_class.pure_step(state, resolved)
        else:
"""
    after = """        started = time.perf_counter()
        restricted_invocation = None
        if runtime_context is None:
            from polisyos.foundry.methods.catalog.policy.restricted_executable_profile import (
                run_restricted_exante_if_selected,
            )

            profile_selected, output, restricted_invocation = (
                run_restricted_exante_if_selected(
                    runner=self,
                    captured_runner_execute=_captured_dispatch_execute,
                    method_class=method_class,
                    signature=signature,
                    pure_step=pure_step,
                    postprocessor=postprocess,
                    state=state,
                    resolved_params=resolved,
                    original_params=params,
                )
            )
            if not profile_selected:
                output = pure_step(state, resolved)
        else:
"""
    if updated.count(before) != 1:
        raise RuntimeError("NumpyRunner invocation anchor changed")
    updated = updated.replace(before, after, 1)
    before = '        postprocess = getattr(method_class, "postprocess_output", None)\n        if callable(postprocess):\n'
    after = "        if callable(postprocess):\n"
    if updated.count(before) != 1:
        raise RuntimeError("NumpyRunner postprocess anchor changed")
    updated = updated.replace(before, after, 1)
    before = '            warnings=tuple(dict.fromkeys(warnings)),\n        )\n'
    after = '            warnings=tuple(dict.fromkeys(warnings)),\n            restricted_invocation=restricted_invocation,\n        )\n'
    if updated.count(before) != 1:
        raise RuntimeError("NumpyRunner result anchor changed")
    updated = updated.replace(before, after, 1)
    return patch_for(rel, original, updated)


def dispatch_patch() -> str:
    rel = "policy-engine/src/polisyos/foundry/methods/backends/dispatch.py"
    path = ROOT / rel
    original = path.read_text()
    updated = original
    before = "        validated_bound=result.validated_bound,\n"
    after = before + "        restricted_invocation=result.restricted_invocation,\n"
    if updated.count(before) != 2:
        raise RuntimeError("dispatch overlay/merge anchors changed")
    updated = updated.replace(before, after, 2)
    before = "                    validated_bound=validated_bound,\n"
    after = before + "                    restricted_invocation=result.restricted_invocation,\n"
    if updated.count(before) != 1:
        raise RuntimeError("validated dispatch result anchor changed")
    updated = updated.replace(before, after, 1)
    start = updated.index("    def _execute_on_backend(\n")
    end = updated.index("\n    def _select_backend(\n", start)
    replacement = '''    def _execute_on_backend(
        self,
        *,
        backend: ComputeBackend,
        method_class: type,
        signature: MethodSignature,
        state: Any,
        params: Mapping[str, Any],
        seed: int,
        runtime_context: OwnedAttemptAnchorDispatchContext | None = None,
    ) -> MethodResult:
        runner = self._resolve_runner(backend)
        # Capture the dispatcher-selected bound callable exactly once. The same
        # local is passed through the breaker and to the restricted NumPy witness.
        runner_execute: Any = runner.execute
        from polisyos.foundry.methods.backends.numpy_runner import NumpyRunner

        breaker = get_circuit_breaker_registry().get(backend.value)

        def _execute() -> MethodResult:
            if runtime_context is not None:
                if backend is not ComputeBackend.NUMPY:
                    raise RuntimeContextDispatchError("backend_not_supported")
                if not isinstance(runner, NumpyRunner):
                    raise RuntimeContextDispatchError("backend_not_supported")
                kwargs = {
                    "method_class": method_class,
                    "signature": signature,
                    "state": state,
                    "params": params,
                    "seed": seed,
                    "runtime_context": runtime_context,
                }
            else:
                kwargs = {
                    "method_class": method_class,
                    "signature": signature,
                    "state": state,
                    "params": params,
                    "seed": seed,
                }
            if type(runner) is NumpyRunner:
                kwargs["_captured_dispatch_execute"] = runner_execute
            return runner_execute(**kwargs)

        result = breaker.call(_execute)
        from polisyos.foundry.methods.catalog.policy.restricted_executable_profile import (
            bind_dispatch_runner_identity,
            profile_for_method_fqn,
        )

        if profile_for_method_fqn(signature.fqn) is not None:
            result = replace(
                result,
                restricted_invocation=bind_dispatch_runner_identity(
                    method_fqn=signature.fqn,
                    runner=runner,
                    captured_execute=runner_execute,
                    evidence=getattr(result, "restricted_invocation", None),
                ),
            )
        return result
'''
    updated = updated[:start] + replacement + updated[end:]
    return patch_for(rel, original, updated)


def registry_patch() -> str:
    rel = "policy-engine/src/polisyos/foundry/methods/catalog/policy/_registry_boot.py"
    path = ROOT / rel
    original = path.read_text()
    anchor = ")\nfrom .frontier import (\n"
    insert = ")\n# Load the immutable restricted profile only after the registered built-in is loaded.\nfrom .restricted_executable_profile import TRUSTED_EXANTE_NUMPY_PROFILE as _EXANTE_PROFILE\n\nfrom .frontier import (\n"
    if original.count(anchor) != 1:
        raise RuntimeError("policy registry bootstrap anchor changed")
    updated = original.replace(anchor, insert, 1)
    return patch_for(rel, original, updated)


def graph_patch() -> str:
    rel = "policy-engine/src/polisyos/foundry/execute/_internal/graph/__init__.py"
    path = ROOT / rel
    original = path.read_text()
    updated = original
    before = "    MethodExecutionReturnedSlot,\n    MethodMetricBinding,\n"
    after = "    MethodExecutionReturnedSlot,\n    RestrictedMethodCallWitness,\n    MethodMetricBinding,\n"
    if updated.count(before) != 1:
        raise RuntimeError("graph Foundry import anchor changed")
    updated = updated.replace(before, after, 1)
    before = "    dispatch: MethodExecutionDispatchRecord | None = None,\n    artifacts: list[MethodExecutionArtifact] | None = None,\n) -> None:\n"
    after = "    dispatch: MethodExecutionDispatchRecord | None = None,\n    artifacts: list[MethodExecutionArtifact] | None = None,\n    restricted_call_witness: RestrictedMethodCallWitness | None = None,\n) -> None:\n"
    if updated.count(before) != 1:
        raise RuntimeError("graph occurrence-replacement signature anchor changed")
    updated = updated.replace(before, after, 1)
    before = '                    "artifacts": artifacts if artifacts is not None else occurrence.artifacts,\n'
    after = before + '                    "restricted_call_witness": (\n                        restricted_call_witness\n                        if restricted_call_witness is not None\n                        else occurrence.restricted_call_witness\n                    ),\n'
    if updated.count(before) != 1:
        raise RuntimeError("graph occurrence-replacement update anchor changed")
    updated = updated.replace(before, after, 1)
    before = "        occurrence_artifacts: list[MethodExecutionArtifact] | None = None\n"
    after = before + "        occurrence_restricted_call_witness: RestrictedMethodCallWitness | None = None\n"
    if updated.count(before) != 1:
        raise RuntimeError("graph occurrence local anchor changed")
    updated = updated.replace(before, after, 1)
    before = """                    occurrence_dispatch = _successful_method_dispatch_record(
                        planned_dispatch,
                        started_at=method_started_at,
                        started_counter=method_started_counter,
                        method_seed=method_seed,
                        key_words=key_words,
                        root_seed=effective_seed,
                        step=step,
                        prestate_identity=prestate_identity,
                        input_state_ref=dispatch_prestate_ref,
                        source_state_ref=(method_input_state_source_ref or base_ref),
                        method_class=method_class,
                        method_result=method_result,
                        input_slot_values=dispatch_input_slot_values,
                        input_role_values=dispatch_input_role_values,
                        metric_input_capture_ref=metric_input_capture_ref,
                        metric_input_capture_status=metric_input_capture_status,
                        metric_input_capture_limitation=metric_input_capture_limitation,
                    )
                    (
                        occurrence_output_slots,
"""
    after = """                    occurrence_dispatch = _successful_method_dispatch_record(
                        planned_dispatch,
                        started_at=method_started_at,
                        started_counter=method_started_counter,
                        method_seed=method_seed,
                        key_words=key_words,
                        root_seed=effective_seed,
                        step=step,
                        prestate_identity=prestate_identity,
                        input_state_ref=dispatch_prestate_ref,
                        source_state_ref=(method_input_state_source_ref or base_ref),
                        method_class=method_class,
                        method_result=method_result,
                        input_slot_values=dispatch_input_slot_values,
                        input_role_values=dispatch_input_role_values,
                        metric_input_capture_ref=metric_input_capture_ref,
                        metric_input_capture_status=metric_input_capture_status,
                        metric_input_capture_limitation=metric_input_capture_limitation,
                    )
                    if signature.fqn == "policy.evaluation.ex_ante_simulation@1.0.0":
                        from polisyos.foundry.methods.catalog.policy.restricted_executable_profile import (
                            bind_occurrence_call_witness,
                        )

                        occurrence_restricted_call_witness = bind_occurrence_call_witness(
                            evidence=getattr(method_result, "restricted_invocation", None),
                            occurrence=occurrence,
                            input_capture_ref=metric_input_capture_ref,
                            input_capture_status=metric_input_capture_status,
                        )
                    (
                        occurrence_output_slots,
"""
    if updated.count(before) != 1:
        raise RuntimeError("graph actual dispatch result anchor changed")
    updated = updated.replace(before, after, 1)
    before = "                    dispatch=occurrence_dispatch,\n                    artifacts=occurrence_artifacts,\n                )\n"
    after = "                    dispatch=occurrence_dispatch,\n                    artifacts=occurrence_artifacts,\n                    restricted_call_witness=occurrence_restricted_call_witness,\n                )\n"
    if updated.count(before) != 1:
        raise RuntimeError("graph terminal occurrence replacement anchor changed")
    updated = updated.replace(before, after, 1)
    return patch_for(rel, original, updated)


def core_patch() -> str:
    rel = "policy-engine/src/polisyos/core/contracts/foundry.py"
    parent_path = PARENT / "src/polisyos/core/contracts/foundry.py"
    original = parent_path.read_text()
    updated = original
    witness = '''class RestrictedMethodCallWitness(BaseModel):
    """Bounded actual-call evidence nested in its existing graph occurrence."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    status: Literal["verified", "unavailable"]
    limitation: StrictStr | None = Field(default=None, max_length=512)
    profile_id: StrictStr = Field(min_length=1, max_length=128)
    profile_revision_sha256: StrictStr = Field(pattern=r"^[0-9a-f]{64}$")
    method_fqn: StrictStr = Field(min_length=1, max_length=512)
    method_version: StrictStr | None = Field(default=None, max_length=128)
    method_abi_digest: StrictStr | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    method_callable_sha256: StrictStr | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    runner_callable_sha256: StrictStr | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    backend_runtime_fingerprint: StrictStr | None = None
    state_reads: tuple[StrictStr, ...] = Field(default=(), max_length=32)
    parameter_reads: tuple[StrictStr, ...] = Field(default=(), max_length=32)
    parameter_origin: Literal["signature_default", "explicit_parameter", "not_established"]
    poverty_line_value: None = None
    output_slot_id: StrictStr = Field(min_length=1, max_length=256)
    output_value_path: tuple[StrictStr, ...] = Field(min_length=1, max_length=16)
    output_value_sha256: StrictStr | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    occurrence_id: StrictStr = Field(min_length=1, max_length=512)
    invocation_id: StrictStr = Field(min_length=1, max_length=64)
    node_id: StrictStr = Field(min_length=1, max_length=256)
    input_capture_ref: MethodMetricInputCaptureRef | None = None

    @model_validator(mode="after")
    def validate_witness(self) -> RestrictedMethodCallWitness:
        if self.status == "verified":
            if (
                self.limitation is not None
                or self.method_version is None
                or self.method_abi_digest is None
                or self.method_callable_sha256 is None
                or self.runner_callable_sha256 is None
                or self.state_reads != ("baseline", "scenario")
                or self.parameter_reads != ("poverty_line",)
                or self.parameter_origin not in {"signature_default", "explicit_parameter"}
                or self.input_capture_ref is None
                or self.output_value_sha256 is None
            ):
                raise ValueError("verified_restricted_call_witness_is_incomplete")
        elif not self.limitation:
            raise ValueError("unavailable_restricted_call_witness_requires_limitation")
        return self


'''
    anchor = "class MethodExecutionOccurrence(BaseModel):\n"
    if updated.count(anchor) != 1:
        raise RuntimeError("parent Foundry occurrence anchor changed")
    updated = updated.replace(anchor, witness + anchor, 1)
    before = "    dispatch: MethodExecutionDispatchRecord | None = None\n    artifacts: list[MethodExecutionArtifact] = Field(default_factory=list, max_length=32)\n"
    after = "    dispatch: MethodExecutionDispatchRecord | None = None\n    restricted_call_witness: RestrictedMethodCallWitness | None = None\n    artifacts: list[MethodExecutionArtifact] = Field(default_factory=list, max_length=32)\n"
    if updated.count(before) != 1:
        raise RuntimeError("parent Foundry occurrence fields changed")
    updated = updated.replace(before, after, 1)
    before = """            if self.dispatch is None:
                raise ValueError("method_occurrence_requires_dispatch_record")
"""
    after = """            if self.dispatch is None:
                raise ValueError("method_occurrence_requires_dispatch_record")
            witness = self.restricted_call_witness
            if witness is not None and (
                witness.occurrence_id != self.occurrence_id
                or witness.invocation_id != self.invocation_id
                or witness.node_id != self.node_id
                or witness.method_fqn != self.method_fqn
                or witness.method_version != self.method_version
                or witness.method_abi_digest != self.method_abi_digest
                or witness.input_capture_ref != self.dispatch.method_metric_input_capture_ref
            ):
                raise ValueError("restricted_call_witness_occurrence_binding_mismatch")
            if witness is not None and witness.status == "verified" and (
                self.status != "succeeded"
                or self.dispatch.method_metric_input_capture_status != "captured"
            ):
                raise ValueError("verified_call_witness_requires_succeeded_bound_input_capture")
"""
    if updated.count(before) != 1:
        raise RuntimeError("parent Foundry occurrence validator anchor changed")
    updated = updated.replace(before, after, 1)
    before = "            or self.dispatch is not None\n            or self.artifacts\n"
    after = "            or self.dispatch is not None\n            or self.restricted_call_witness is not None\n            or self.artifacts\n"
    if updated.count(before) != 1:
        raise RuntimeError("parent Foundry non-method exclusion anchor changed")
    updated = updated.replace(before, after, 1)
    before = '    ARTIFACT_SCHEMA_VERSION: ClassVar[str] = "1.1"\n    ARTIFACT_KIND: ClassVar[Literal["foundry.method_execution_bundle"]] = (\n'
    after = '''    ARTIFACT_SCHEMA_VERSION: ClassVar[str] = "1.2"
    ARTIFACT_SCHEMA_VERSIONS: ClassVar[tuple[str, ...]] = ("1.1", "1.2")
    ARTIFACT_PAYLOAD_SCHEMA_VERSION_BY_MANIFEST: ClassVar[dict[str, str]] = {
        "1.1": "1.1",
        "1.2": "1.2",
    }
    ARTIFACT_KIND: ClassVar[Literal["foundry.method_execution_bundle"]] = (
'''
    if updated.count(before) != 1:
        raise RuntimeError("parent Foundry bundle schema anchor changed")
    updated = updated.replace(before, after, 1)
    before = '    schema_version: Literal["1.1"] = "1.1"\n    captured_at: datetime = Field(default_factory=lambda: datetime.now(UTC))\n'
    after = '    schema_version: Literal["1.1", "1.2"] = "1.2"\n    captured_at: datetime = Field(default_factory=lambda: datetime.now(UTC))\n'
    if updated.count(before) != 1:
        raise RuntimeError("parent Foundry bundle payload version anchor changed")
    updated = updated.replace(before, after, 1)
    before = """        if len(ids) != len(set(ids)):
            raise ValueError("duplicate_method_execution_occurrence_id")
        if len(positions) != len(set(positions)):
            raise ValueError("duplicate_method_execution_plan_position")
        return self
"""
    after = """        if len(ids) != len(set(ids)):
            raise ValueError("duplicate_method_execution_occurrence_id")
        if len(positions) != len(set(positions)):
            raise ValueError("duplicate_method_execution_plan_position")
        if self.schema_version == "1.1" and any(
            item.restricted_call_witness is not None for item in self.occurrences
        ):
            raise ValueError("legacy_method_execution_bundle_cannot_claim_call_witness")
        if self.schema_version == "1.2" and any(
            item.status == "succeeded"
            and item.method_fqn == "policy.evaluation.ex_ante_simulation@1.0.0"
            and item.restricted_call_witness is None
            for item in self.occurrences
        ):
            raise ValueError("succeeded_exante_occurrence_requires_call_witness_or_refusal")
        return self
"""
    if updated.count(before) != 1:
        raise RuntimeError("parent Foundry bundle validator anchor changed")
    updated = updated.replace(before, after, 1)
    oldname = str(parent_path.relative_to(ROOT))
    return patch_for(rel, original, updated, fromfile=oldname)


def reader_patch() -> str:
    rel = "policy-engine/src/polisyos/scientist/nodes/builtins/decide/policy_runtime_method_metrics.py"
    path = ROOT / rel
    original = path.read_text()
    updated = original
    # Keep the lightweight result at the existing bounded-reader owner.
    dataclass_anchor = "@dataclass(frozen=True, slots=True, init=False)\nclass _MethodMetricSourceTuple:\n"
    call_type = '''@dataclass(frozen=True, slots=True)
class _VerifiedRestrictedExAnteCall:
    """Ephemeral bounded result exposing the exact verified call inputs to Runtime."""

    occurrence: Any
    witness: Any
    input_capture_ref: SelectedMethodMetricArtifactRef
    input_capture: Any
    input_values: tuple[Any, ...]
    output_ref: SelectedMethodMetricArtifactRef
    output_payload: Any
    observation: MethodMetricObservation


'''
    if updated.count(dataclass_anchor) != 1:
        raise RuntimeError("method metric source tuple class anchor changed")
    updated = updated.replace(dataclass_anchor, call_type + dataclass_anchor, 1)
    before = '''    comparison_candidate: Any | None = None,
) -> tuple[MethodMetricObservation, ...]:
'''
    after = '''    comparison_candidate: Any | None = None,
    require_restricted_exante_call_witness: bool = False,
    restricted_exante_call_collector: list[_VerifiedRestrictedExAnteCall] | None = None,
) -> tuple[MethodMetricObservation, ...]:
'''
    if updated.count(before) != 1:
        raise RuntimeError("method metric admission signature changed")
    updated = updated.replace(before, after, 1)
    before = '    """Resolve and reconcile the whole selected graph → bundle → binding source chain."""\n'
    after = before + '''    require_restricted_exante_call_witness = (
        require_restricted_exante_call_witness or restricted_exante_call_collector is not None
    )
    restricted_call_start = (
        len(restricted_exante_call_collector)
        if restricted_exante_call_collector is not None
        else 0
    )
'''
    if updated.count(before) != 1:
        raise RuntimeError("method metric admission docstring anchor changed")
    updated = updated.replace(before, after, 1)
    before = '        or bundle_schema.version not in {"1.0", "1.1"}\n'
    after = '        or bundle_schema.version not in {"1.0", "1.1", "1.2"}\n'
    if updated.count(before) != 1:
        raise RuntimeError("method metric bundle schema gate changed")
    updated = updated.replace(before, after, 1)
    before = '''    if bundle_schema.version == "1.0":
        # The v1.0 contract predates the dispatch-time sparse prestate and full
        # method-metric input capture. Keep it readable as a typed limitation, but
        # never coerce the v1.1 model or treat an adjacent manifest edge as proof.
        raise _UnestablishedProjectionError(
            "legacy_method_execution_bundle_v1_0_lacks_current_prestate_contract"
        )
'''
    after = before + '''    if require_restricted_exante_call_witness and bundle_schema.version != "1.2":
        raise _UnestablishedProjectionError(
            "restricted_exante_call_witness_requires_method_execution_bundle_v1_2"
        )
'''
    if updated.count(before) != 1:
        raise RuntimeError("method metric legacy bundle branch changed")
    updated = updated.replace(before, after, 1)
    before = '        expected_schema_versions={"1.1"},\n    )\n    _require_exact_payload_ref(bundle.program_graph_ref'
    after = '        expected_schema_versions={"1.1", "1.2"},\n    )\n    _require_exact_payload_ref(bundle.program_graph_ref'
    if updated.count(before) != 1:
        raise RuntimeError("method metric bundle typed version allowlist changed")
    updated = updated.replace(before, after, 1)
    # Pass the selected bundle version and optional collector into the existing occurrence reader.
    before = '''                        comparison_environment=comparison_environment,
                        comparison_graph=comparison_graph,
                    )
'''
    after = '''                        comparison_environment=comparison_environment,
                        comparison_graph=comparison_graph,
                        bundle_schema_version=bundle.schema_version,
                        require_restricted_exante_call_witness=(
                            require_restricted_exante_call_witness
                        ),
                        restricted_exante_call_collector=(
                            restricted_exante_call_collector
                        ),
                    )
'''
    if updated.count(before) != 1:
        raise RuntimeError("method metric occurrence call anchor changed")
    updated = updated.replace(before, after, 1)
    before = "    return tuple(observations)\n\n\ndef _compiled_method_comparison_graph(\n"
    after = """    if require_restricted_exante_call_witness:
        if len(observations) != 1 or observations[0].source_status != "observed":
            raise _UnestablishedProjectionError(
                "restricted_exante_single_observation_not_established"
            )
        if restricted_exante_call_collector is not None and (
            len(restricted_exante_call_collector) - restricted_call_start != 1
        ):
            raise _UnestablishedProjectionError(
                "restricted_exante_verified_call_inventory_not_single"
            )
    return tuple(observations)


def _compiled_method_comparison_graph(
"""
    if updated.count(before) != 1:
        raise RuntimeError("method metric admission return anchor changed")
    updated = updated.replace(before, after, 1)
    # Extend only the private per-occurrence method-metric admission path.
    before = '''    comparison_environment: dict[str, Any] | None = None,
    comparison_graph: dict[str, Any] | None = None,
) -> MethodMetricObservation:
'''
    after = '''    comparison_environment: dict[str, Any] | None = None,
    comparison_graph: dict[str, Any] | None = None,
    bundle_schema_version: str = "1.1",
    require_restricted_exante_call_witness: bool = False,
    restricted_exante_call_collector: list[_VerifiedRestrictedExAnteCall] | None = None,
) -> MethodMetricObservation:
'''
    if updated.count(before) != 1:
        raise RuntimeError("method metric occurrence reader signature changed")
    updated = updated.replace(before, after, 1)
    before = '''    dispatch = occurrence.dispatch
    if dispatch is None or dispatch.outcome != "succeeded":
        raise _InvalidProjectionError("successful_method_occurrence_dispatch_mismatch")
'''
    after = before + '''    restricted_witness = None
    if require_restricted_exante_call_witness:
        if (
            bundle_schema_version != "1.2"
            or binding.method_fqn != "policy.evaluation.ex_ante_simulation@1.0.0"
            or occurrence.method_fqn != binding.method_fqn
            or occurrence.restricted_call_witness is None
            or occurrence.restricted_call_witness.status != "verified"
        ):
            raise _UnestablishedProjectionError(
                "actual_exante_call_witness_not_established"
            )
        restricted_witness = occurrence.restricted_call_witness
'''
    if updated.count(before) != 1:
        raise RuntimeError("method metric occurrence dispatch gate changed")
    updated = updated.replace(before, after, 1)
    # Compare the selected occurrence witness only after both selected CAS payloads are loaded.
    anchor = '''    captured_input_values, recomputed_prestate_identity_sha256 = (
        _captured_input_arrays_from_snapshot(
            store=store,
            read_budget=read_budget,
            snapshot_ref=input_state_ref,
            origin_state_ref=prestate_source_ref,
            capture=input_capture,
            dispatch=dispatch,
            signature=signature,
        )
    )

'''
    addition = '''    if require_restricted_exante_call_witness:
        # MethodOutputPayload.value is already the selected numeric scalar;
        # slot/path identity was reconciled against the binding above.
        selected_output_value = output_payload.value
        if type(graph_node.method_params) is not dict or set(graph_node.method_params) - {
            "poverty_line"
        }:
            raise _InvalidProjectionError("restricted_exante_graph_parameter_basis_not_supported")
        parameter_rows = [
            row for row in dispatch.parameter_values if row.name == "poverty_line"
        ]
        expected_source = (
            "requested" if "poverty_line" in graph_node.method_params else "signature_default"
        )
        if (
            len(parameter_rows) != 1
            or parameter_rows[0].status != "captured"
            or parameter_rows[0].source != expected_source
            or parameter_rows[0].value is not None
        ):
            raise _InvalidProjectionError("restricted_exante_literal_parameter_origin_mismatch")
        expected_parameter_origin = (
            "explicit_parameter"
            if expected_source == "requested"
            else "signature_default"
        )
        from polisyos.foundry.methods.catalog.policy.restricted_executable_profile import (
            verify_persisted_restricted_call_witness,
        )

        if not verify_persisted_restricted_call_witness(
            restricted_witness,
            occurrence=occurrence,
            expected_input_capture_ref=input_capture_ref,
            selected_output_slot_id=binding.output_slot_id,
            selected_output_value_path=binding.output_value_path,
            selected_output_value=selected_output_value,
            expected_parameter_origin=expected_parameter_origin,
        ):
            raise _UnestablishedProjectionError(
                "actual_exante_call_witness_recomputation_failed"
            )

'''
    if updated.count(anchor) != 1:
        raise RuntimeError("method metric captured-input read anchor changed")
    updated = updated.replace(anchor, anchor + addition, 1)
    # Return selected bounded refs and already-read content in an ephemeral collector.
    before = '''    if comparison_collector is not None:
        contract = _ex_ante_rank_comparison_contract(
            observation=observation,
            execution_context=execution_context,
            capture=input_capture,
            environment=comparison_environment,
            graph=comparison_graph,
        )
        if contract is not None:
            comparison_collector.append(contract)
    return observation
'''
    after = '''    if comparison_collector is not None:
        contract = _ex_ante_rank_comparison_contract(
            observation=observation,
            execution_context=execution_context,
            capture=input_capture,
            environment=comparison_environment,
            graph=comparison_graph,
        )
        if contract is not None:
            comparison_collector.append(contract)
    if restricted_exante_call_collector is not None:
        if not require_restricted_exante_call_witness or restricted_witness is None:
            raise _UnestablishedProjectionError(
                "restricted_exante_call_collector_requires_verified_witness"
            )
        restricted_exante_call_collector.append(
            _VerifiedRestrictedExAnteCall(
                occurrence=occurrence,
                witness=restricted_witness,
                input_capture_ref=input_capture_ref,
                input_capture=input_capture,
                input_values=captured_input_values,
                output_ref=output_ref,
                output_payload=output_payload,
                observation=observation,
            )
        )
    return observation
'''
    if updated.count(before) != 1:
        raise RuntimeError("method metric observation return anchor changed")
    updated = updated.replace(before, after, 1)
    # Reuse the same flag/collector when the completed candidate comparison branch replays.
    before = '''def recompute_completed_ex_ante_rank_projection(
    store: _MethodMetricProjectionArtifactStore,
    *,
    basis: object | None,
    candidate_ref: ArtifactRef | None,
) -> CompletedExAnteRankProjection:
'''
    after = '''def recompute_completed_ex_ante_rank_projection(
    store: _MethodMetricProjectionArtifactStore,
    *,
    basis: object | None,
    candidate_ref: ArtifactRef | None,
    require_restricted_exante_call_witness: bool = False,
    restricted_exante_call_collector: list[_VerifiedRestrictedExAnteCall] | None = None,
) -> CompletedExAnteRankProjection:
'''
    if updated.count(before) != 1:
        raise RuntimeError("completed Ex-Ante replay signature changed")
    updated = updated.replace(before, after, 1)
    before = '''            comparison_collector=contracts,
            comparison_candidate=candidate,
        )
'''
    after = '''            comparison_collector=contracts,
            comparison_candidate=candidate,
            require_restricted_exante_call_witness=(
                require_restricted_exante_call_witness
            ),
            restricted_exante_call_collector=(restricted_exante_call_collector),
        )
'''
    if updated.count(before) != 1:
        raise RuntimeError("completed Ex-Ante admission call anchor changed")
    updated = updated.replace(before, after, 1)
    return patch_for(rel, original, updated)


def write_current_base_patches() -> None:
    """Regenerate source patches still anchored to the pinned base checkout.

    `core-call-witness.patch` is intentionally frozen against the parent's
    pre-integration Core SQL postimage; once that file contains this DTO the
    anchor no longer exists, and regeneration would risk clobbering its SQL work.
    """
    patches = {
        "foundry-call-witness.patch": (
            protocol_patch() + numpy_patch() + dispatch_patch() + registry_patch() + graph_patch()
        ),
        "bounded-call-witness.patch": reader_patch(),
    }
    out_dir = LEAF / "postimages/patches"
    for name, contents in patches.items():
        (out_dir / name).write_text(contents)
        print(f"{name}: {len(contents.encode())} bytes")


if __name__ == "__main__":
    write_current_base_patches()
