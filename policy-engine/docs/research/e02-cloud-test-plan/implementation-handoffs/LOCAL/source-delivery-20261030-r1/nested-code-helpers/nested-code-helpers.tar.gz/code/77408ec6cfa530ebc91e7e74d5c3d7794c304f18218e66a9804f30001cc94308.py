"""Exercise real pytest items with the candidate's actual source-owner functions."""
import hashlib
import json
import os
from pathlib import Path

from selected_item_falsifier import CAPTURE, FIXTURE, HERE, PACKET, ROOT, module, observer_functions


state = {}


def pytest_collection_modifyitems(session, config, items):
    observer = observer_functions()
    rows = [observer["_selection_row"](item, ROOT, config.rootpath) for item in items]
    if any(row.get("qualification_error") for row in rows):
        raise RuntimeError("real pytest selection did not bind")
    code_owner = module("c104_synthetic_pytest_capture", CAPTURE)
    gate = module("c104_synthetic_pytest_gate", PACKET / "receipt_gate.py")
    source = FIXTURE.read_bytes()
    blob = hashlib.sha1(b"blob " + str(len(source)).encode() + b"\0" + source, usedforsecurity=False).hexdigest()
    capture = code_owner.ActualCodeCapture(ROOT, {"policy-engine/tests/test_code_identity.py": blob}, HERE)
    capture.select_starts(observer["_is_selected_item_code"], lambda frame: None, config)
    capture.assertion_compiler_pin = {"version": "9.0.2", "distribution_relative_path": "_pytest/assertion/rewrite.py",
        "source_sha256": "376adab93672026552858ffaca009cbef553f082f2e4dee87ace75e7966d4b10", "source_bytes": 48206}
    capture.start()
    observer["_register_selected_items"](items, rows)
    state.update(rows=rows, capture=capture, gate=gate)


def pytest_sessionfinish(session, exitstatus):
    capture = state["capture"]
    for code, row in tuple(capture.codes.values()):
        row["process_local_code_object_id"] = id(code)
    report = capture.report()
    actual = report["observed_selected_first_start_codes"]
    results = [{"node": row["canonical_selector"], "qualified": state["gate"].qualify_selected_item_code(row, actual)}
               for row in state["rows"]]
    verdict = {"pytest_exit": int(exitstatus), "results": results, "capture_errors": report["errors"],
               "scope": "isolated synthetic pytest items; product UNRUN"}
    path = Path(os.environ["C104_SYNTHETIC_RESULT"])
    with path.open("x", encoding="utf-8") as stream:
        json.dump(verdict, stream, sort_keys=True)
        stream.write("\n")
    if exitstatus or not all(row["qualified"] for row in results):
        session.exitstatus = 1
