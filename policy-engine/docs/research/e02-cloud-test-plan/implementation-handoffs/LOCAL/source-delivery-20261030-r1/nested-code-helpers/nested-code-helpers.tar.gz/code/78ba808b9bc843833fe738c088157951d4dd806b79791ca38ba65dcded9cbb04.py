"""Source-bound in-memory removal probes for the real Lex impact paths.

The plugin is loaded only for an explicitly named negative run. It mutates one
in-process callable after verifying canonical source bytes, keeps normal pytest
plugins, and restores the original callable at session finish. It never writes
tracked source or deletes any CAS material.
"""

from __future__ import annotations

import ast
import hashlib
import inspect
import json
import marshal
import os
import textwrap
from pathlib import Path
from typing import Any

_original: tuple[object, str, Any] | None = None
_record: dict[str, Any] = {}


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _code_sha(value: Any) -> str:
    return hashlib.sha256(marshal.dumps(value.__code__)).hexdigest()


def pytest_sessionstart(session: Any) -> None:
    global _original, _record
    from polisyos.lex.legal_evaluation import impact_diff
    from polisyos.lex.simulator import cli

    mode = os.environ["POLISYOS_LEX_CONTROL_MODE"]
    expected = json.loads(os.environ["POLISYOS_LEX_CONTROL_PINS"])
    for path, digest in expected.items():
        if _sha(Path(path)) != digest:
            raise RuntimeError(f"source pin mismatch: {path}")
    plugin = Path(__file__).resolve()
    if _sha(plugin) != os.environ["POLISYOS_LEX_CONTROL_PLUGIN_SHA256"]:
        raise RuntimeError("control plugin pin mismatch")

    if mode == "producer_topics":
        owner, name = impact_diff, "_infer_candidate_topics_v1_1"
        original = getattr(owner, name)
        old_descriptions = {
            "compliance_cost": "Operational and reporting costs needed to maintain compliance.",
            "operational_restrictions": "Direct restrictions on operational policy space.",
            "regulatory_flexibility": "Available discretionary actions under permissions.",
        }

        def mutant(diff: Any) -> Any:
            topics = original(diff)
            return [
                topic.model_copy(update={"description": old_descriptions[topic.kpi_id]})
                for topic in topics
            ]

    elif mode in {"report_reconciliation", "diff_reconstruction", "delta_replay", "issue_total_bound"}:
        owner, name = impact_diff, "_reconcile_selected_report"
        original = getattr(owner, name)

        def mutant(report: Any, diff: Any) -> None:
            # Remove only the 1.1 content reconciliation, preserving the exact
            # selected-profile edge, kind, report shape and marker strings.
            return None

    elif mode == "scope_guard":
        owner, name = impact_diff.NormImpactAnalyzer, "analyze"
        original = getattr(owner, name)
        tree = ast.parse(textwrap.dedent(inspect.getsource(original)))

        class RemoveScopeGuard(ast.NodeTransformer):
            count = 0

            def visit_If(self, node: ast.If) -> Any:
                test = ast.unparse(node.test)
                if (
                    "old_pack.jurisdiction != new_pack.jurisdiction" in test
                    and "self._report_schema_version == '1.1'" in test
                ):
                    self.count += 1
                    node.test = ast.Constant(value=False)
                return self.generic_visit(node)

        transformer = RemoveScopeGuard()
        mutated = ast.fix_missing_locations(transformer.visit(tree))
        if transformer.count != 1:
            raise RuntimeError(f"unexpected scope guard count: {transformer.count}")
        namespace = dict(vars(impact_diff))
        exec(compile(mutated, inspect.getsourcefile(original) or "<missing>", "exec"), namespace)
        mutant = namespace[name]

    elif mode == "report_bridge":
        owner, name = impact_diff.NormImpactAnalyzer, "_persist_report"
        original = getattr(owner, name)

        def mutant(self: Any, report: Any) -> Any:
            # Keep the producer's object, old ID field, report version, pass
            # markers and status; omit the selected diff from persisted bytes.
            return original(self, report.model_copy(update={"norm_diff_artifact_ref": None}))

    elif mode == "markdown_disclaimer":
        owner, name = cli, "render_impact_markdown"
        original = getattr(owner, name)
        disclaimer = (
            "These are heuristic topics inferred from changed rule types, not measured "
            "effects or legal conclusions."
        )

        def mutant(report: Any) -> str:
            rendered = original(report)
            if rendered.count(disclaimer) != 1:
                raise RuntimeError("disclaimer source did not match expected removal")
            return rendered.replace(disclaimer, "")

    elif mode == "manifest_edge":
        owner, name = impact_diff, "load_norm_impact_report"
        original = getattr(owner, name)
        tree = ast.parse(inspect.getsource(original))

        class DeriveExpectedFromManifest(ast.NodeTransformer):
            count = 0

            def visit_Assign(self, node: ast.Assign) -> Any:
                if len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
                    if node.targets[0].id == "expected_edge":
                        self.count += 1
                        # Keep the check, exception and marker but feed the
                        # declared edge back as its own expected value.
                        node.value = ast.Subscript(
                            value=ast.Attribute(
                                value=ast.Name(id="manifest", ctx=ast.Load()),
                                attr="inputs",
                                ctx=ast.Load(),
                            ),
                            slice=ast.Constant(value=0),
                            ctx=ast.Load(),
                        )
                return self.generic_visit(node)

        transformer = DeriveExpectedFromManifest()
        mutated = ast.fix_missing_locations(transformer.visit(tree))
        if transformer.count != 1:
            raise RuntimeError(f"unexpected edge assignment count: {transformer.count}")
        namespace = dict(vars(impact_diff))
        exec(compile(mutated, inspect.getsourcefile(original) or "<missing>", "exec"), namespace)
        mutant = namespace[name]
    else:
        raise RuntimeError(f"unknown control mode: {mode}")

    _original = (owner, name, original)
    setattr(owner, name, mutant)
    _record = {
        "mode": mode,
        "source_pins": expected,
        "plugin_path": str(plugin),
        "plugin_sha256": _sha(plugin),
        "callable": f"{getattr(owner, '__name__', type(owner).__name__)}.{name}",
        "original_code_sha256": _code_sha(original),
        "mutant_code_sha256": _code_sha(mutant),
        "source_files_changed": False,
        "normal_pytest_plugins_disabled": False,
        "closure_ids": [],
    }
    if _record["original_code_sha256"] == _record["mutant_code_sha256"]:
        raise RuntimeError("control did not change executable code")
    print("LEX_IMPACT_CONTROL_ACTIVE=" + json.dumps(_record, sort_keys=True))


def pytest_sessionfinish(session: Any, exitstatus: int) -> None:
    if _original is None:
        return
    owner, name, original = _original
    setattr(owner, name, original)
    _record["restored_original_object"] = getattr(owner, name) is original
    _record["pytest_exitstatus"] = exitstatus
    _record["after_source_pins"] = {
        path: _sha(Path(path)) for path in _record["source_pins"]
    }
    _record["source_pins_unchanged"] = _record["after_source_pins"] == _record["source_pins"]
    output = Path(os.environ["POLISYOS_LEX_CONTROL_RECEIPT"])
    output.write_text(json.dumps(_record, indent=2, sort_keys=True) + "\n")
    print("LEX_IMPACT_CONTROL_FINISHED=" + json.dumps(_record, sort_keys=True))
