from pathlib import Path
import ast,subprocess
O=Path('LOCAL/raw/e02-execution-20261027/repairs/C71-r2/batch-r2');P=O/'postimages';BASE='aaefd17075b84ef45fbac6a56e04e29148e7e724'
p='policy-engine/src/polisyos/runtime/http/services/control/run_lifecycle.py';s=subprocess.check_output(['git','show',BASE+':'+p]).decode()
# Every replacement is limited to the named owned definition; unrelated current
# root C37/C49 code is retained byte-for-byte.
def edit(name,fn,method=True):
 global s
 t=ast.parse(s);nodes=[n for n in ast.walk(t) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name and (n.col_offset>0)==method];assert len(nodes)==1,(name,len(nodes));n=nodes[0];lines=s.splitlines(keepends=True);part=''.join(lines[n.lineno-1:n.end_lineno]);new=fn(part);assert new!=part,name;s=''.join(lines[:n.lineno-1])+new+''.join(lines[n.end_lineno:])
def replace_once(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b,1)
imports='''from polisyos.runtime.http.services.control.observational_source_access import (\n    _current_source_read_scope,\n    _job_source_read_scope,\n    _ObservationalSourceReadScope,\n    _reader_source_read_scope,\n    _request_source_read_scope,\n    _require_source_read_owner,\n    _require_supported_candidate_source,\n)\n'''
s=replace_once(s,'from polisyos.core.security import AccessScope, clear_tenant_context\n','from polisyos.core.security import AccessScope, clear_tenant_context\n'+imports)
# Remove the obsolete metadata-only gate, not its source-policy distinction.
t=ast.parse(s);n=next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='_require_public_candidate_source');ls=s.splitlines(keepends=True);s=''.join(ls[:n.lineno-1])+''.join(ls[n.end_lineno:])
def validator(x):
 x=replace_once(x,'    limits: CoreJsonReadLimits,\n','    limits: CoreJsonReadLimits,\n    source_scope: _ObservationalSourceReadScope | None = None,\n')
 x=replace_once(x,'    def read_manifest(\n','    source_scope = source_scope or _current_source_read_scope()\n    _require_source_read_owner(store, source_scope)\n\n    def read_manifest(\n')
 x=x.replace('    _require_public_candidate_source(source_governance, source_tenant_context)','    _require_supported_candidate_source(\n        store, source_scope, source_governance, source_tenant_context\n    )')
 return x
edit('_validate_direct_method_execution_selection_artifacts',validator,False)
def source_read(x):
 x=replace_once(x,'        expected_sha256: str | None = None,\n','        expected_sha256: str | None = None,\n        source_scope: _ObservationalSourceReadScope | None = None,\n')
 x=replace_once(x,'        limits = self._observational_read_limits()','        _require_source_read_owner(\n            self._artifact_store, source_scope or _current_source_read_scope()\n        )\n        limits = self._observational_read_limits()')
 return x
edit('_read_observational_source_manifest',source_read)
def launch(x):
 marker='        try:\n            (\n                bounded_manifest,'
 x=replace_once(x,marker,'''        try:\n            source_read_scope = _request_source_read_scope(\n                principal, self._execution_scope_for_policy(policy)\n            )\n            _require_source_read_owner(self._artifact_store, source_read_scope)\n        except ValueError as exc:\n            raise forbidden(\n                "The selected source owner does not match the admitted request scope.",\n                code="observational_source_current_access_not_established",\n            ) from exc\n\n'''+marker)
 x=replace_once(x,'self._read_observational_source_manifest(selection.source_ref)','self._read_observational_source_manifest(\n                selection.source_ref, source_scope=source_read_scope\n            )')
 x=replace_once(x,'_require_public_candidate_source(source_governance, source_tenant)','_require_supported_candidate_source(\n                self._artifact_store, source_read_scope, source_governance, source_tenant\n            )')
 x=x.replace('Asynchronous candidate execution requires an unscoped public observation.','Asynchronous candidate execution requires an admitted currently owned public observation.')
 return x
edit('_launch_observational_workflow_run',launch)
def worker(x):
 x=replace_once(x,'        job = current.job\n','        job = current.job\n        source_read_scope = _job_source_read_scope(current)\n        _require_source_read_owner(self._artifact_store, source_read_scope)\n')
 x=replace_once(x,'                expected_sha256=intent.source_manifest_sha256,','                expected_sha256=intent.source_manifest_sha256,\n                source_scope=source_read_scope,')
 x=replace_once(x,'_require_public_candidate_source(source_governance, source_tenant_context)','_require_supported_candidate_source(\n                self._artifact_store, source_read_scope, source_governance, source_tenant_context\n            )')
 return x
edit('resolve_method_execution_admission',worker)
def persist(x):
 x=replace_once(x,'        job = current.job\n','        job = current.job\n        source_read_scope = _job_source_read_scope(current)\n        _require_source_read_owner(self._artifact_store, source_read_scope)\n')
 x=replace_once(x,'                expected_sha256=admission.source_manifest_sha256,','                expected_sha256=admission.source_manifest_sha256,\n                source_scope=source_read_scope,')
 x=replace_once(x,'_require_public_candidate_source(current_governance, current_tenant_context)','_require_supported_candidate_source(\n            self._artifact_store, source_read_scope, current_governance, current_tenant_context\n        )')
 return x
edit('persist_content_admitted_intent',persist)
def wrapper(x):
 x=replace_once(x,'        self, selection: _DirectMethodExecutionSelection\n','        self,\n        selection: _DirectMethodExecutionSelection,\n        *,\n        source_scope: _ObservationalSourceReadScope | None = None,\n')
 x=replace_once(x,'            limits=self._observational_read_limits(),','            limits=self._observational_read_limits(),\n            source_scope=source_scope,')
 return x
edit('_validate_direct_method_execution_selection_artifacts',wrapper)
def intentread(x):
 x=replace_once(x,'        intent_ref = _require_full_profile_ref(','        _require_source_read_owner(self._artifact_store, _current_source_read_scope())\n        intent_ref = _require_full_profile_ref(')
 return x
edit('_read_bounded_intent_artifact_read',intentread)
def complete(x):
 marker='        (\n            requested_source_ref,'
 x=replace_once(x,marker,'        source_read_scope = _job_source_read_scope(\n            self._control_store.current_execution_job_admission()\n        )\n        _require_source_read_owner(self._artifact_store, source_read_scope)\n'+marker)
 x=replace_once(x,'self._validate_direct_method_execution_selection_artifacts(selection)','self._validate_direct_method_execution_selection_artifacts(\n            selection, source_scope=_job_source_read_scope(\n                self._control_store.current_execution_job_admission()\n            )\n        )')
 return x
edit('_complete_observational_method_control_job',complete)
def getselection(x):
 marker='        try:\n            record = self._control_store.get_unique_completed_job_by_run_and_kind('
 x=replace_once(x,marker,'        try:\n            source_read_scope = _reader_source_read_scope(tenant_id, cell_id)\n            _require_source_read_owner(self._artifact_store, source_read_scope)\n        except ValueError:\n            return None\n'+marker)
 x=replace_once(x,'self._validate_direct_method_execution_selection_artifacts(selection)','self._validate_direct_method_execution_selection_artifacts(\n                    selection, source_scope=source_read_scope\n                )')
 return x
edit('get_method_execution_selection',getselection)
def projection(x):
 marker='        if not run_id or not tenant_id:\n'
 x=replace_once(x,marker,'        try:\n            source_read_scope = _reader_source_read_scope(tenant_id, cell_id)\n            _require_source_read_owner(self._artifact_store, source_read_scope)\n        except ValueError:\n            return unavailable("execution_outcome_not_established")\n\n'+marker)
 x=replace_once(x,'self._validate_direct_method_execution_selection_artifacts(selection)','self._validate_direct_method_execution_selection_artifacts(\n                selection, source_scope=source_read_scope\n            )')
 return x
edit('get_observational_method_run_projection',projection)
# Only the internally built default handle is upgraded using the existing Core
# adapter. An explicitly injected unenforced handle is refused at candidate use.
s=replace_once(s,'                    build_artifact_store(\n                        store_config,\n                        metrics=self._metrics,\n                        tracer=self._tracer,\n                    )','                    with_ambient_ownership_enforcement_if_supported(\n                        build_artifact_store(\n                            store_config,\n                            metrics=self._metrics,\n                            tracer=self._tracer,\n                        )\n                    )')
# Add the helper to the existing backend config import.
needle='from polisyos.core.artifacts.backends.config import ('
assert needle in s
idx=s.index(needle);end=s.index(')',idx);s=s[:end]+'    with_ambient_ownership_enforcement_if_supported,\n'+s[end:]
pout=P/p;pout.parent.mkdir(parents=True,exist_ok=True);pout.write_text(s);ast.parse(s)
print(pout,len(s.encode()))
