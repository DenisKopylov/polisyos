from types import FunctionType
from importlib import import_module
def body():
    return load("bridge_foreign")
CODE = body.__code__
run = FunctionType(CODE, {"load": import_module})
run()
