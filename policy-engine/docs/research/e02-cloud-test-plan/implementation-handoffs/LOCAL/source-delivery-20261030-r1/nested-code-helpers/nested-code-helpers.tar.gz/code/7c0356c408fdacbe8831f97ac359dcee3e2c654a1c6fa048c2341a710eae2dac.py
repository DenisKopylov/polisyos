import sys
from . import facade
from external_decorators import facade_module_name, replacement
def install():
    vars(sys.modules[facade_module_name()])["__getattr__"] = replacement
install()
