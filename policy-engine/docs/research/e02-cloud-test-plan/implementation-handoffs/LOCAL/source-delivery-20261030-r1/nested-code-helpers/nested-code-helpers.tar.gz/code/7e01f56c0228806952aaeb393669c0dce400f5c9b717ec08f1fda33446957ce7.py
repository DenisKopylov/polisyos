def body():
    return None
CODE = body.__code__
run = opaque_constructor(CODE, globals())
run()
