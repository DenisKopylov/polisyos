"""Prepare one explicitly bound G27 case. Never run pytest or mutate source."""
from __future__ import annotations

import argparse
import ast
import hashlib
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
PACKET = ROOT / 'LOCAL/raw/e02-execution-20261027/repairs/G27-local-owner-oracle-r2'
PRODUCT = ROOT / 'policy-engine'
NATIVE = PRODUCT / ('docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/'
                    'root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/'
                    'deep-task-status-audit-20261027-r1')
RAW = ROOT / 'LOCAL/raw/e02-execution-20261027'
F16 = RAW / 'next-native/F16-current-local-r7'
PROFILE = RAW / 'next-native/F16-full-source-r1/instruments'
C134 = PRODUCT / 'tools/quality/testing/tc_sql_mc_witness'
HELPER = RAW / 'prepare_root_native_case_r2.py'
ENV_HELPER = RAW / 'next-cloud/G27-owner-oracle-current-r2/env_admission.py'


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def blob(data: bytes) -> str:
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data, usedforsecurity=False).hexdigest()


def git(*args: str) -> bytes:
    return subprocess.check_output(['git', '-C', str(ROOT), *args])


def git_ok(*args: str) -> bool:
    return subprocess.run(['git', '-C', str(ROOT), *args], capture_output=True).returncode == 0


def require(condition: object, message: str) -> None:
    if not condition:
        raise SystemExit(message)


def identity(path: Path) -> dict:
    if path.is_symlink() or not path.is_file():
        raise SystemExit(f'input is not a regular non-symlink file: {path}')
    s = path.stat()
    data = path.read_bytes()
    return {'path': str(path.relative_to(ROOT)), 'sha256': sha(data), 'bytes': len(data),
            'device': s.st_dev, 'inode': s.st_ino, 'mtime_ns': s.st_mtime_ns}


def environment_snapshot(spec: dict) -> dict:
    """Reuse the existing read-only metadata admission; no package/product imports."""
    env_spec = importlib.util.spec_from_file_location('g27_readonly_environment', ENV_HELPER)
    require(env_spec is not None and env_spec.loader is not None, 'environment helper unavailable')
    module = importlib.util.module_from_spec(env_spec)
    env_spec.loader.exec_module(module)
    result = module.snapshot(PRODUCT, spec['lock_sha256'], spec['required_distributions'])
    require(result['status'] == 'PASS', 'ENVIRONMENT_ERROR: ' + json.dumps(result, sort_keys=True))
    dist = importlib.metadata.distribution('pytest')
    rewriter = Path(dist.locate_file('_pytest/assertion/rewrite.py'))
    data = rewriter.read_bytes()
    require(dist.version == '9.0.2' and sha(data) == spec['assertion_rewriter_sha256'] and
            len(data) == 48206, 'ENVIRONMENT_ERROR: pytest assertion producer differs')
    result['rewriter_sha256'] = sha(data)
    result['rewriter_bytes'] = len(data)
    return result


def git_tree_index(head: str) -> dict[str, str]:
    tree = git('ls-tree', '-r', '-z', head, '--', 'policy-engine/src', 'policy-engine/tests',
               'policy-engine/tools')
    result = {}
    for item in tree.split(b'\0'):
        if not item:
            continue
        meta, path = item.split(b'\t', 1)
        _mode, kind, oid = meta.decode().split()
        rel = path.decode()
        if kind == 'blob' and rel.endswith('.py'):
            result[rel] = oid
    return result


def imported_test_closure(seeds: list[str], index: dict[str, str], head: str) -> list[str]:
    """Derive static tests/unit import closure from stage source, not an old pin list."""
    pending = list(seeds)
    seen: set[str] = set()
    while pending:
        path = pending.pop()
        if path in seen:
            continue
        seen.add(path)
        if not path.endswith('.py') or not path.startswith('policy-engine/tests/'):
            continue
        body = git('show', head + ':' + path)
        tree = ast.parse(body, filename=path)
        relative = path.removeprefix('policy-engine/tests/').removesuffix('.py')
        module = 'tests.' + relative.replace('/', '.')
        package = module.rpartition('.')[0]
        for node in ast.walk(tree):
            names: list[str] = []
            if isinstance(node, ast.Import):
                names = [alias.name for alias in node.names]
            elif isinstance(node, ast.ImportFrom):
                name = node.module or ''
                if node.level:
                    try:
                        name = importlib.util.resolve_name('.' * node.level + name, package)
                    except (ImportError, ValueError):
                        continue
                names = [name] + [name + '.' + alias.name for alias in node.names if alias.name != '*']
            for name in names:
                if name.startswith('tests.'):
                    stem = 'policy-engine/tests/' + name.removeprefix('tests.').replace('.', '/')
                elif name.startswith('unit.'):
                    stem = 'policy-engine/tests/' + name.replace('.', '/')
                else:
                    continue
                for rel in (stem + '.py', stem + '/__init__.py'):
                    if rel in index and rel not in seen:
                        pending.append(rel)
    return sorted(seen)


def apply_unified(source: bytes, patch: bytes, target: str) -> bytes:
    """Apply one exact reviewed unified patch in memory, checking every context line."""
    lines = patch.decode('utf-8').splitlines(keepends=True)
    old_header, new_header = '--- a/' + target, '+++ b/' + target
    starts = [i for i, line in enumerate(lines) if line.rstrip('\n') == old_header]
    require(len(starts) == 1 and lines[starts[0] + 1].rstrip('\n') == new_header,
            'mutation patch target/header mismatch')
    require(sum(line.startswith('--- ') for line in lines) == 1, 'mutation patch must contain one file')
    original = source.decode('utf-8').splitlines(keepends=True)
    out: list[str] = []
    cursor = 0
    i = starts[0] + 2
    hunks = 0
    while i < len(lines):
        match = re.match(r'^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', lines[i])
        require(match is not None, 'mutation patch contains unexpected content')
        old_start = int(match.group(1)) - 1
        old_count = int(match.group(2) or 1)
        new_count = int(match.group(4) or 1)
        require(old_start >= cursor, 'mutation patch overlaps prior hunk')
        out.extend(original[cursor:old_start])
        cursor = old_start
        removed = added = 0
        i += 1
        while i < len(lines) and not lines[i].startswith('@@ '):
            line = lines[i]
            require(line and line[0] in ' +-','mutation patch line unsupported')
            tag, text = line[0], line[1:]
            if tag in ' -':
                require(cursor < len(original) and original[cursor] == text,
                        'mutation patch context/preimage mismatch')
                cursor += 1
                removed += 1
            if tag in ' +':
                out.append(text)
                added += 1
            i += 1
        require((removed, added) == (old_count, new_count), 'mutation hunk count mismatch')
        hunks += 1
    require(hunks == 1, 'mutation patch must contain one reviewed hunk')
    out.extend(original[cursor:])
    return ''.join(out).encode()


def changed(head1: str, head2: str) -> list[tuple[str, str]]:
    rows = git('diff', '--name-status', '--no-renames', head1, head2, '--').decode().splitlines()
    return [tuple(row.split('\t', 1)) for row in rows]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    for flag in ('expected-head', 'expected-tree', 'base-head', 'base-tree', 'candidate-head',
                 'candidate-tree', 'phase-inputs-sha256', 'author-manifest-sha256', 'case-id'):
        parser.add_argument('--' + flag, required=True)
    parser.add_argument('--selection', choices=('pilot', 'cohort'), required=True)
    parser.add_argument('--stage', choices=('candidate', 'mutant', 'restored'), required=True)
    parser.add_argument('--mutation-patch', type=Path)
    parser.add_argument('--mutation-sha256')
    parser.add_argument('--positive-receipt', type=Path)
    parser.add_argument('--positive-receipt-sha256')
    args = parser.parse_args()
    require(re.fullmatch(r'[A-Za-z0-9_-]{1,20}', args.case_id) is not None,
            'case ID must be 1-20 safe characters (SQLite path budget)')
    spec_path = PACKET / 'phase-inputs.json'
    manifest_path = PACKET / 'manifest.json'
    spec_bytes = spec_path.read_bytes()
    manifest_bytes = manifest_path.read_bytes()
    require(sha(spec_bytes) == args.phase_inputs_sha256, 'phase specification hash mismatch')
    require(sha(manifest_bytes) == args.author_manifest_sha256, 'author manifest hash mismatch')
    spec = json.loads(spec_bytes)
    manifest = json.loads(manifest_bytes)
    require(git('symbolic-ref', '--short', 'HEAD').decode().strip() == spec['branch'], 'branch mismatch')
    for head, tree in ((args.expected_head, args.expected_tree), (args.base_head, args.base_tree),
                       (args.candidate_head, args.candidate_tree)):
        require(git('rev-parse', head + '^{tree}').decode().strip() == tree, 'commit/tree mismatch')
    require(git('rev-parse', 'HEAD').decode().strip() == args.expected_head, 'HEAD mismatch')
    require(git('rev-parse', args.candidate_head + '^').decode().strip() == args.base_head,
            'candidate is not the one checkpoint on the explicitly admitted base')
    require(git_ok('diff', '--quiet') and git_ok('diff', '--cached', '--quiet', 'HEAD'),
            'tracked worktree or index is not clean')
    require(changed(args.base_head, args.candidate_head) == [('A', p) for p in sorted(spec['candidate_paths'])],
            'base-to-candidate footprint must be exactly the two new tests')
    require(git_ok('merge-base', '--is-ancestor', args.candidate_head, args.expected_head),
            'candidate is not an ancestor of the phase')
    if args.stage == 'candidate':
        require((args.expected_head, args.expected_tree) == (args.candidate_head, args.candidate_tree),
                'candidate phase must use the candidate commit/tree')
    elif args.stage == 'restored':
        require(args.selection == 'pilot' and args.expected_tree == args.candidate_tree,
                'restored phase must exactly restore the candidate tree and pilot')
    else:
        require(args.selection == 'pilot', 'mutant is limited to the pilot')
        if args.mutation_patch is None and args.mutation_sha256 is None:
            args.mutation_patch = ROOT / spec['default_mutation_patch']
            args.mutation_sha256 = spec['default_mutation_sha256']
        require(args.mutation_patch is not None and args.mutation_sha256 is not None and
                args.positive_receipt is not None and args.positive_receipt_sha256 is not None,
                'mutant requires reviewed patch and qualified positive receipt')
        patch = args.mutation_patch.read_bytes()
        require(sha(patch) == args.mutation_sha256, 'reviewed mutation hash mismatch')
        receipt_bytes = args.positive_receipt.read_bytes()
        require(sha(receipt_bytes) == args.positive_receipt_sha256, 'positive receipt hash mismatch')
        receipt = json.loads(receipt_bytes)
        require(receipt.get('stage') == 'candidate' and receipt.get('selection') == 'pilot' and
                receipt.get('source_head') == args.candidate_head and
                receipt.get('source_tree') == args.candidate_tree and
                receipt.get('selected_source_qualification') == 'PASS' and
                receipt.get('semantic_outcome') == 'PASS', 'positive was not source-qualified')
        mutation = spec['mutation_path']
        require(changed(args.candidate_head, args.expected_head) == [('M', mutation)],
                'mutant differs from candidate beyond its one owner path')
        require(apply_unified(git('show', args.candidate_head + ':' + mutation), patch, mutation) ==
                git('show', args.expected_head + ':' + mutation), 'actual mutant differs from reviewed patch')
    rows = manifest['files']
    require(len(rows) == 2 and {row['path'] for row in rows} == set(spec['candidate_paths']),
            'author manifest must select the two candidate files')
    bound_extra = [spec_path, manifest_path]
    for row in rows:
        path = row['path']
        post = ROOT / row['postimage_file']
        data = post.read_bytes()
        require(row.get('pre_sha256') is None and sha(data) == row['post_sha256'], 'postimage mismatch')
        require(git('show', args.candidate_head + ':' + path) == data and
                git('show', args.expected_head + ':' + path) == data, 'candidate file bytes mismatch')
        bound_extra.append(post)
    index = git_tree_index(args.expected_head)
    seeds = spec['source_seed_paths']
    source_paths = imported_test_closure(seeds, index, args.expected_head)
    source_bindings = []
    for path in source_paths:
        data = git('show', args.expected_head + ':' + path)
        work = ROOT / path
        require(not work.is_symlink() and work.read_bytes() == data, f'worktree source mismatch: {path}')
        stage = git('ls-files', '--stage', '--', path).decode().split()
        require(len(stage) >= 3 and stage[1] == blob(data) and stage[2] == '0', f'index mismatch: {path}')
        source_bindings.append({'path': path, 'sha256': sha(data), 'bytes': len(data), 'git_blob': blob(data)})
    nodes = spec['selected_nodes'][args.selection]
    for node in nodes:
        path, function = node.split('::')
        tree = ast.parse((PRODUCT / path).read_bytes())
        selected = [n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == function]
        require(len(selected) == 1 and not any(isinstance(d, ast.Call) and isinstance(d.func, ast.Attribute)
                and d.func.attr == 'parametrize' for d in selected[0].decorator_list), 'selected node mismatch')
    runtime_inputs = []
    for row in spec['static_runtime_inputs']:
        path = ROOT / row['path']
        actual = identity(path)
        require(actual['sha256'] == row['sha256'] and actual['bytes'] == row['bytes'],
                'instrument mismatch: ' + row['path'])
        runtime_inputs.append(path)
    live = ROOT / 'LOCAL/raw/root-live-ownership-20261021.json'
    live_doc = json.loads(live.read_bytes())
    require((live_doc['head'], live_doc['tree']) == (args.expected_head, args.expected_tree) and
            live_doc['known_dirty_paths'] == [], 'root live-ownership identity mismatch')
    frame = ROOT / live_doc['source_readback']['path']
    require(sha(frame.read_bytes()) == live_doc['source_readback']['sha256'], 'root source-frame mismatch')
    runtime_inputs.extend([live, frame, *bound_extra, Path(__file__), PACKET / 'qualify_native.py'])
    if args.stage == 'mutant':
        runtime_inputs.extend([args.mutation_patch, args.positive_receipt])
    before_env = environment_snapshot(spec)
    out = NATIVE / args.case_id
    plan_path = NATIVE / (args.case_id + '.json')
    index_path = NATIVE / (args.case_id + '-source-index.json')
    snapshot_path = NATIVE / (args.case_id + '-root-live-input.json')
    require(not any(os.path.lexists(path) for path in (out, plan_path, index_path, snapshot_path)),
            'case, plan, source index or helper snapshot slot already exists')
    index_bytes = (json.dumps(index, sort_keys=True, separators=(',', ':')) + '\n').encode()
    fd = os.open(index_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(index_bytes)
    runtime_inputs.append(index_path)
    inputs_before = [identity(path) for path in runtime_inputs]
    require(len({row['path'] for row in inputs_before}) == len(inputs_before), 'duplicate input path')
    command = [str(PRODUCT / '.venv/bin/python'), '-B', str(HELPER), args.case_id, *nodes,
               '--scope', 'G27 bounded real SQL admission/withdrawal and fresh owner fixture; '
               'no packet, external currentness, race/process-kill or G acceptance claim.']
    helper = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, check=False)
    require(helper.returncode == 0, 'native helper failed: ' + helper.stderr)
    require([identity(path) for path in runtime_inputs] == inputs_before, 'input changed during helper')
    require(plan_path.parent.resolve() == NATIVE.resolve() and not plan_path.is_symlink() and plan_path.is_file(),
            'helper plan is not the exact regular fresh case path')
    plan_stat = plan_path.stat()
    require(plan_stat.st_nlink == 1, 'helper plan has multiple hardlinks')
    require(all((row['device'], row['inode']) != (plan_stat.st_dev, plan_stat.st_ino) for row in inputs_before),
            'helper plan aliases a consumed input')
    plan_preimage = plan_path.read_bytes()
    plan = json.loads(plan_preimage)
    require((plan['case_id'], plan['source_head'], plan['source_tree'], plan['nodes']) ==
            (args.case_id, args.expected_head, args.expected_tree, nodes), 'helper plan identity mismatch')
    require((plan['disk_admission_bytes'], plan['disk_stop_bytes'], plan['rss_cap_bytes'],
             plan['deadline_seconds']) == (8 * 1024**3, 6 * 1024**3, 2300 * 1024**2, 600),
            'unexpected resource bounds')
    fragment = plan['sandbox_profile_fragment']
    require(fragment.count('(deny network*)\n') == 1, 'unexpected network policy')
    fragment = fragment.replace('(deny network*)\n', '(deny network*)\n'
        '(allow network-bind (local tcp "localhost:*"))\n'
        '(allow network-inbound (local tcp "localhost:*"))\n'
        '(allow network-outbound (remote tcp "localhost:*"))\n')
    profile = ('(version 1)\n(allow default)\n(deny file-write*)\n(allow file-write* (subpath '
               + json.dumps(str(out)) + '))\n(allow file-write* (literal "/dev/null"))\n' + fragment)
    phase = args.case_id
    plan.update({'sandbox_profile_fragment': fragment, 'sandbox_profile_fragment_sha256': sha(fragment.encode()),
                 'sandbox_profile_text': profile, 'sandbox_profile_sha256': sha(profile.encode()),
                 'extra_env': {'PYTHONPATH': os.pathsep.join(map(str, (F16, PROFILE, C134))),
                    'PYTEST_PLUGINS': 'f16_local_observer,f16_c134_context,pytest_execution_profile',
                    'F16_PHASE': phase, 'F16_EXPECTED_NODEIDS_JSON': json.dumps(nodes, separators=(',', ':')),
                    'F16_COLLECTION_EVENT': str(out/'collection-events.json'),
                    'F16_ASSERTION_REWRITER_PIN': str(F16/'assertion-rewriter-pin.json'),
                    'F16_PYTEST_PROFILE_PATH': str(out/'pytest-execution-profile.json'),
                    'F16_PHASE_ROOT': str(out), 'E02C_ROOT': str(ROOT), 'E02C_INDEX': str(index_path),
                    'E02C_OUT': str(out/'c134'), 'E02C_PHASE': phase, 'POLISYOS_R4_CHILD': '1'},
                 'g27': {'stage': args.stage, 'selection': args.selection, 'base_head': args.base_head,
                    'base_tree': args.base_tree, 'candidate_head': args.candidate_head,
                    'candidate_tree': args.candidate_tree, 'phase_inputs_sha256': sha(spec_bytes),
                    'author_manifest_sha256': sha(manifest_bytes), 'source_bindings': source_bindings,
                    'source_index_sha256': sha(index_bytes), 'source_index_count': len(index),
                    'runtime_input_bindings': inputs_before, 'environment': before_env,
                    'mutation_sha256': args.mutation_sha256 if args.stage == 'mutant' else None,
                    'positive_receipt_sha256': args.positive_receipt_sha256 if args.stage == 'mutant' else None,
                    'global_census': 'NOT_ESTABLISHED', 'closure_ids': []}})
    require(git('rev-parse', 'HEAD').decode().strip() == args.expected_head and
            git_ok('diff', '--quiet') and git_ok('diff', '--cached', '--quiet', 'HEAD'),
            'source/index moved during preparation')
    plan_bytes = (json.dumps(plan, indent=2) + '\n').encode()
    fd = os.open(plan_path, os.O_RDWR | os.O_NOFOLLOW)
    with os.fdopen(fd, 'rb+') as stream:
        actual = os.fstat(stream.fileno())
        require(stat.S_ISREG(actual.st_mode) and (actual.st_dev, actual.st_ino, actual.st_nlink) ==
                (plan_stat.st_dev, plan_stat.st_ino, 1) and stream.read() == plan_preimage,
                'helper plan inode/preimage changed before write')
        stream.seek(0)
        stream.write(plan_bytes)
        stream.truncate()
        stream.flush()
    require(plan_path.read_bytes() == plan_bytes, 'plan readback mismatch')
    require([identity(path) for path in runtime_inputs] == inputs_before, 'input changed during plan write')
    print(json.dumps({'plan': str(plan_path), 'sha256': sha(plan_bytes), 'index': str(index_path),
                      'index_sha256': sha(index_bytes), 'head': args.expected_head, 'tree': args.expected_tree,
                      'stage': args.stage, 'selection': args.selection, 'nodes': nodes,
                      'helper_stdout': helper.stdout, 'product_execution': 'UNRUN', 'closure_ids': []}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
