from pathlib import Path
import ast,json,hashlib
root=Path.cwd();r1=root/'LOCAL/raw/e02-execution-20261027/repairs/C49-local-r1';r2=r1.with_name('C49-local-r2')
(r2/'plans').mkdir(parents=True,exist_ok=True)

def edit(rel,change):
 rel=Path(rel);source=r1/'postimages'/rel;before=source.read_text();after=change(before)
 assert after!=before,str(rel)
 ast.parse(after,filename=str(rel))
 pre=r2/'preimages'/rel;post=r2/'postimages'/rel
 pre.parent.mkdir(parents=True,exist_ok=True);post.parent.mkdir(parents=True,exist_ok=True)
 if pre.exists():assert pre.read_text()==before
 else:pre.write_text(before)
 post.write_text(after)

rel='policy-engine/src/polisyos/scientist/agent/_drafter_observations.py'
def observation(s):
 s=s.replace('import math\n','import math\nimport re\n',1)
 s=s.replace('def confidence_subject_ref(problem_frame: ProblemFrame) -> str:\n    """Bind the semantic problem; the exact prompts are bound separately per call."""','def confidence_subject_ref(problem_frame: ProblemFrame) -> str | None:\n    """Bind a serializable semantic problem; missing identity stays unavailable."""',1)
 old='''    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    ).hexdigest()
'''
 new='''    try:
        encoded = json.dumps(
            payload, sort_keys=True, separators=(",", ":"), allow_nan=False
        ).encode()
    except (TypeError, ValueError, OverflowError):
        return None
    return hashlib.sha256(encoded).hexdigest()
'''
 assert s.count(old)==1;s=s.replace(old,new,1)
 s=s.replace('    subject_ref: str,\n','    subject_ref: str | None,\n',1)
 s=s.replace('''    if type(response) is not LLMSettledResponse:
        return None
''','''    if type(response) is not LLMSettledResponse or subject_ref is None:
        return None
''',1)
 s=s.replace('''    if event.response_digest != source_ref:
        return None
''','''    if event.response_digest != source_ref or (
        type(event.request_digest) is not str
        or re.fullmatch(r"[a-f0-9]{64}", event.request_digest) is None
    ):
        return None
''',1)
 s=s.replace('        request_ref=request_ref,\n','        request_ref=request_ref,\n        producer_request_ref=event.request_digest,\n',1)
 s=s.replace('''    """Bind the actual drafter wire request without storing another prompt copy."""''','''    """Bind the actual caller input, separately from Core's scoped/sanitized request."""''',1)
 return s
edit(rel,observation)

rel='policy-engine/src/polisyos/scientist/orchestration/engine/convergence.py'
def convergence(s):
 s=s.replace('    request_ref: str = Field(pattern=r"^[a-f0-9]{64}$")\n','    request_ref: str = Field(pattern=r"^[a-f0-9]{64}$")\n    producer_request_ref: str = Field(pattern=r"^[a-f0-9]{64}$")\n',1)
 # The missing semantic identity is admitted only as absence, never an observation.
 start=s.index('    def check_candidate_observation(');end=s.index('    def check_with_text(',start)
 section=s[start:end].replace('        subject_ref: str,\n','        subject_ref: str | None,\n',1).replace('''                observation.subject_ref != subject_ref
''','''                subject_ref is None
                or observation.subject_ref != subject_ref
''',1)
 s=s[:start]+section+s[end:]
 return s
edit(rel,convergence)

rel='policy-engine/src/polisyos/scientist/agent/drafter_clients.py'
def client(s):
 old='''    def __init__(self, llm_client: Any, model_name: str | None = None) -> None:
        if llm_client is not None and not isinstance(llm_client, TracedLLMClient):
'''
 new='''    def __init__(
        self,
        llm_client: Any,
        model_name: str | None = None,
        *,
        capture_convergence_observations: bool = False,
    ) -> None:
        if type(capture_convergence_observations) is not bool:
            raise TypeError("capture_convergence_observations_must_be_bool")
        self._capture_convergence_observations = capture_convergence_observations
        if llm_client is not None and not isinstance(llm_client, TracedLLMClient):
'''
 assert s.count(old)==1;s=s.replace(old,new,1)
 marker='    async def draft_policy(\n'
 start=s.index('class LLMDrafterAgent:');idx=s.index(marker,start)
 s=s[:idx]+'''    def _with_convergence_observations(self) -> LLMDrafterAgent:
        """Return an opt-in wrapper over the same canonical traced client owner."""
        if self._capture_convergence_observations:
            return self
        return LLMDrafterAgent(
            self._llm, capture_convergence_observations=True,
        )

'''+s[idx:]
 start=s.index('        observed_confidence = finite_candidate_confidence(data.get("confidence"))',s.index('class LLMDrafterAgent:'))
 end=s.index('        return DraftResult(',start)
 replacement='''        capture = self._capture_convergence_observations
        observed_confidence = (
            finite_candidate_confidence(data.get("confidence"))
            if capture else float(data.get("confidence", 0.6))
        )
        request_ref = confidence_request_ref(system=prompt, user=user_message) if capture else None
        subject_ref = confidence_subject_ref(problem_frame) if capture else None
        response_subject = data.get("problem_frame_ref", problem_frame.frame_id)
        observation = None
        if capture and observed_confidence is not None and response_subject == problem_frame.frame_id:
            assert request_ref is not None
            observation = observe_candidate_confidence(
                response=response,
                source_text=content,
                subject_ref=subject_ref,
                request_ref=request_ref,
                pass_number=1,
                value=observed_confidence,
            )
        grounding_notes = _context_grounding_notes(problem_frame)
        if capture and observed_confidence is None:
            grounding_notes.append("candidate_confidence_not_established")
        if capture and subject_ref is None:
            grounding_notes.append("candidate_convergence_subject_not_established")
        if capture and response_subject != problem_frame.frame_id:
            grounding_notes.append("candidate_confidence_problem_frame_mismatch")
'''
 s=s[:start]+replacement+s[end:]
 s=s.replace('''                "candidate_self_assessment" if observed_confidence is not None
                and response_subject == problem_frame.frame_id else "not_established"
''','''                "candidate_self_assessment" if capture and observed_confidence is not None
                and response_subject == problem_frame.frame_id else "not_established"
''',1)
 return s
edit(rel,client)

rel='policy-engine/src/polisyos/scientist/agent/_drafter_orchestrator.py'
def orchestrator(s):
 marker='from .drafter_models import (\n'
 s=s.replace(marker,'from .drafter_clients import LLMDrafterAgent\n'+marker,1)
 old='''        self._inner = inner
        self._config = config or MultiPassConfig()
        self._memory = memory
        self._llm = self._resolve_llm(llm_client, inner)
'''
 new='''        self._config = config or MultiPassConfig()
        if self._config.convergence is not None and type(inner) is LLMDrafterAgent:
            inner = inner._with_convergence_observations()
        self._inner = inner
        self._memory = memory
        self._llm = self._resolve_llm(llm_client, self._inner)
'''
 assert s.count(old)==1;s=s.replace(old,new,1)
 old='''        observation = current_pass.confidence_observation
        eligible = (
'''
 s=s.replace(old,'''        subject_ref = confidence_subject_ref(problem_frame)
        observation = current_pass.confidence_observation
        eligible = (
''',1)
 s=s.replace('''            and draft.confidence_status != "not_established"
        )
''','''            and draft.confidence_status != "not_established"
            and subject_ref is not None
        )
''',1)
 s=s.replace('''            subject_ref=confidence_subject_ref(problem_frame),
            request_ref=current_pass.confidence_request_ref,
''','''            subject_ref=subject_ref,
            request_ref=current_pass.confidence_request_ref,
''',1)
 s=s.replace('''                else "candidate_assessment_not_supplied"
''','''                else "semantic_subject_not_established" if subject_ref is None
                else "candidate_assessment_not_supplied"
''',1)
 return s
edit(rel,orchestrator)

rel='policy-engine/src/polisyos/scientist/agent/_drafter_parsing.py'
def parsing(s):
 s=s.replace('''                    "candidate_self_assessment" if payload.confidence is not None
                    else original.confidence_status
''','''                    "candidate_self_assessment"
                    if payload.confidence is not None and (
                        original.confidence_status != "not_established"
                        or original.convergence_state is not None
                    ) else original.confidence_status
''',1)
 return s
edit(rel,parsing)

rel='policy-engine/tests/unit/scientist/orchestration/engine/test_convergence_c49.py'
edit(rel,lambda s:s.replace('subject_ref=_digest("selected-problem"), request_ref=_digest(f"request-{number}"),','subject_ref=_digest("selected-problem"), request_ref=_digest(f"request-{number}"),\n        producer_request_ref=_digest(f"actual-core-request-{number}"),',1))
rel='policy-engine/tests/unit/scientist/agent/test_drafter_observation_wire_c49.py'
edit(rel,lambda s:s.replace('subject_ref=digest("problem"), request_ref=digest("request"), source_ref=digest(raw),','subject_ref=digest("problem"), request_ref=digest("request"), source_ref=digest(raw),\n        producer_request_ref=digest("core-scoped-request"),',1))
# Restore the original no-profile malformed-confidence behavior/test; do not
# silently re-specify the existing default in a convergence opt-in change.
rel=Path('policy-engine/tests/unit/runtime/quality/test_design_generation.py')
before=(r1/'postimages'/rel).read_text();after=(r1/'preimages'/rel).read_text()
pre=r2/'preimages'/rel;post=r2/'postimages'/rel;pre.parent.mkdir(parents=True,exist_ok=True);post.parent.mkdir(parents=True,exist_ok=True)
pre.write_text(before);post.write_text(after);ast.parse(after)
# Explicitly record the partial/immutable inheritance; final delivery is composed
# directly against canonical r1 preimages after all review findings are batched.
inherit={'status':'UNFROZEN_AUTHOR_DELTA_DO_NOT_COMPOSE','inherits':'../C49-local-r1/manifest.json',
 'inherits_sha256':hashlib.sha256((r1/'manifest.json').read_bytes()).hexdigest(),
 'scope':'One configured current-observation intake; no r1 mutation, no product runtime/import/install/canonical/index/ref edits.',
 'known_author_findings':['profile capture defaults','unavailable semantic subject without fallback','separate Core producer request provenance'],
 'runtime':'UNRUN','closure_ids':[]}
(r2/'plans/inheritance.json').write_text(json.dumps(inherit,indent=2)+'\n')
print(json.dumps({'status':inherit['status'],'changed_python_postimages':len(list((r2/'postimages').rglob('*.py'))),'runtime':'UNRUN'}))
