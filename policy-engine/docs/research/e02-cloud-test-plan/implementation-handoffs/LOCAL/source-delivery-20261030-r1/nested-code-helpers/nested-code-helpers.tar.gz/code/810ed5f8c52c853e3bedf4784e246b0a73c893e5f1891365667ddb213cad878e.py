from pathlib import Path
import hashlib
import json
import subprocess

root = Path.cwd()
base = Path(__file__).resolve().parent
selected = [
    'policy-engine/src/polisyos/runtime/quality/joint_simulation_horizon.py',
    'policy-engine/src/polisyos/runtime/quality/generation_cycle.py',
    'policy-engine/tests/unit/runtime/quality/test_c49_native_stopping_budget.py',
    'policy-engine/tests/unit/remediation/test_sim_01.py',
    'policy-engine/src/polisyos/runtime/quality/README.md',
    'policy-engine/release-fragments/unreleased/2026-10-28-e02-candidate-stopping-budget.toml',
]
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
tree = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], text=True).strip()
assert head == '662237cec3f0d7f9b01d4ba89f2ad5bdb23a3c80'
assert tree == '8abf5d45b27d8ff4d164b120786328ac914ed99d'
file_rows = []
for name in selected:
    data=(root/name).read_bytes()
    assert data == (base/'pre'/name).read_bytes()
    assert data == subprocess.check_output(['git','show',f'HEAD:{name}'])
    assert data == subprocess.check_output(['git','show',f':{name}'])
    file_rows.append({'path':name,'pre_sha256':hashlib.sha256(data).hexdigest()})
paths = subprocess.check_output(['git','ls-files','-z','--','policy-engine/src','policy-engine/tests']).split(b'\0')
paths = [Path(p.decode()) for p in paths if p.endswith(b'.py')]
tokens = [b'physical_spec_ref', b'physical_run_ref', b'physical_work_observations', b'physical_simulation_work']
matched = []
for path in paths:
    data = path.read_bytes()
    hits = [t.decode() for t in tokens if t in data]
    if hits:
        matched.append({'path':str(path),'tokens':hits,'sha256':hashlib.sha256(data).hexdigest()})
report={'head':head,'tree':tree,'tracked_python_scope':['policy-engine/src','policy-engine/tests'],'tracked_python_files':len(paths),'token_matched_files':len(matched),'matches':matched,'proposal_preimages':file_rows,'census_limit':'Exact string occurrence only; indirect consumers are traced separately in README.'}
(base/'census.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'head':head,'python_files':len(paths),'matched_files':len(matched),'matches':[x['path'] for x in matched]}))
