from types import FunctionType
from importlib import import_module
def body(callback):
    return callback("bridge_callback")
CODE = body.__code__
setattr(body, "__code__", opaque_code)
run = FunctionType(CODE, globals())
run(import_module)
