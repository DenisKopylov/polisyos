from pathlib import Path
import subprocess,sys
root=Path.cwd()
base=root/'LOCAL/raw/e02-execution-20261027/repairs/C52-r2/r3/postimages/policy-engine'
for p in sorted(base.rglob('*.py')):
    rel=str(p.relative_to(base))
    cmd=[str(root/'policy-engine/.venv/bin/python'),'-m','ruff','format','--config',str(root/'policy-engine/ruff.toml'),'--stdin-filename',rel,'-']
    result=subprocess.run(cmd,input=p.read_text(),text=True,capture_output=True,cwd=root/'policy-engine')
    if result.returncode:
        print(rel,'format FAIL',result.stderr)
        sys.exit(1)
    p.write_text(result.stdout)
    cmd=[str(root/'policy-engine/.venv/bin/python'),'-m','ruff','check','--no-cache','--config',str(root/'policy-engine/ruff.toml'),'--stdin-filename',rel,'-']
    result=subprocess.run(cmd,input=p.read_text(),text=True,capture_output=True,cwd=root/'policy-engine')
    print(rel,'PASS' if result.returncode==0 else 'FAIL',result.stdout,result.stderr)
