"""Witness overrefusal of an unrequired initializer; not an authority test."""
import hashlib
import importlib
import json
import pathlib
import sys

sys.path.insert(0, sys.argv[1])
from tools.loaded_execution_capture import CaptureError, ExpectedSource, SourceExecutionCapture

root = pathlib.Path(sys.argv[2])
package = root / "noninterference_witness"
package.mkdir()
files = {
    "noninterference_witness": ("noninterference_witness/__init__.py", b"value = 1\n"),
    "noninterference_witness.unrelated": ("noninterference_witness/unrelated.py", b"raise RuntimeError('unrelated failed')\n"),
}
for name, (relative, content) in files.items():
    (root / relative).write_bytes(content)
expected = {name: ExpectedSource(relative, hashlib.sha256(content).hexdigest())
            for name, (relative, content) in files.items()}
capture = SourceExecutionCapture(root, expected)
capture.install()
sys.path.insert(0, str(root))
importlib.import_module("noninterference_witness")
required = frozenset({"noninterference_witness"})
capture.assert_retained(required)
try:
    importlib.import_module("noninterference_witness.unrelated")
except RuntimeError:
    pass
else:
    raise AssertionError("unrelated initializer did not fail")
try:
    capture.assert_retained(required)
except CaptureError as exc:
    reason = str(exc)
else:
    raise AssertionError("expected conservative false refusal was not reproduced")
assert capture.failed and reason == "capture_incomplete"
print(json.dumps({"outcome": "UNRELATED_INITIALIZER_FALSE_REFUSAL", "reason": reason, "authority": False}, sort_keys=True))
