"""Freeze exact composed local inputs after Root's ordinary source checkpoint."""
import argparse,ast,hashlib,json,subprocess
from pathlib import Path
ROOT=Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
HERE=Path(__file__).resolve().parent
Q2='policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/q2-packaging/raw/run.py'
TEST='policy-engine/tests/repo_quality/tools/test_q2_app_dependency_partition.py'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['/usr/bin/git',*args],cwd=ROOT)
def main():
 p=argparse.ArgumentParser();p.add_argument('--source-commit',required=True);p.add_argument('--source-tree',required=True);p.add_argument('--destination',type=Path,required=True);p.add_argument('--approved-tool-sha256',default='4e3b00e8471d1fa775a8ebb77a6dbe7961c87625e15b03b662d93bad646ba617');p.add_argument('--approved-companion-sha256',default='bb0c87ba1ff85653d88082c2053c5165256bd30931c98a6892c4104747abbac0');a=p.parse_args()
 assert git('rev-parse','HEAD').decode().strip()==a.source_commit
 assert git('rev-parse','HEAD^{tree}').decode().strip()==a.source_tree
 for path,expected in [(Q2,a.approved_tool_sha256),(TEST,a.approved_companion_sha256)]:
  raw=git('cat-file','blob',a.source_commit+':'+path);assert sha(raw)==expected and (ROOT/path).read_bytes()==raw
 old=json.loads((ROOT/'LOCAL/raw/e02-execution-20261027/next-cloud/I2-installed-terminus-r12-r3/config.json').read_bytes())
 for name in ('tool_extension_sha256','tool_post_sha256'):old.pop(name,None)
 rows=[]
 for i,suffix,ignored in old['pins']:
  path=old['prefixes'][i]+suffix;raw=git('cat-file','blob',a.source_commit+':'+path);assert (ROOT/path).read_bytes()==raw;rows.append([i,suffix,sha(raw)])
 i=old['prefixes'].index('policy-engine/');rows.append([i,TEST.removeprefix('policy-engine/'),a.approved_companion_sha256]);old['pins']=rows
 old.update(source_commit=a.source_commit,source_tree=a.source_tree,composed_tool_sha256=a.approved_tool_sha256,composed_companion_sha256=a.approved_companion_sha256,host_environment_mutations=False)
 for control in old['controls']:
  control['source_commit']=a.source_commit
  if 'repository_path' in control:assert sha(git('cat-file','blob',a.source_commit+':'+control['repository_path']))==control['base_sha256']
 controller=(HERE/'local_run.py').read_bytes();ast.parse(controller)
 a.destination.mkdir(parents=True,exist_ok=False);raw=(json.dumps(old,separators=(',',':'))+'\n').encode();(a.destination/'config.json').write_bytes(raw)
 manifest={'kind':'BOUND_LOCAL_INPUTS_NOT_EXECUTION','source_commit':a.source_commit,'source_tree':a.source_tree,'tool_sha256':a.approved_tool_sha256,'companion_sha256':a.approved_companion_sha256,'controller_sha256':sha(controller),'config_sha256':sha(raw),'direct_pin_denominator':len(rows),'source32':'historical; excluded from execution','installed_selector':'policy-engine/tests/repo_quality/tools/test_e02_installed_census_contract.py::test_installed_census_exact_git_denominator','installed_literal_occurrences_per_wave':28,'artifact_arms':2,'waves_per_artifact':['positive','M1','restored'],'compatibility_literal_occurrences':24,'new_tool_companion_definitions':2,'runtime':'UNRUN','G_acceptance':False,'closures':[]};(a.destination/'binding.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n');print(json.dumps(manifest))
if __name__=='__main__':main()
