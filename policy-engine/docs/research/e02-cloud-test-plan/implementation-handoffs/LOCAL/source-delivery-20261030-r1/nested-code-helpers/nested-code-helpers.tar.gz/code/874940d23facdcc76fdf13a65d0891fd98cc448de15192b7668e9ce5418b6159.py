import sys
from . import facade
from external_decorators import facade_module_name, replacement
registry = sys.modules
facade_module = registry[facade_module_name()]
def install():
    setattr(facade_module, "__getattr__", replacement)
install()
