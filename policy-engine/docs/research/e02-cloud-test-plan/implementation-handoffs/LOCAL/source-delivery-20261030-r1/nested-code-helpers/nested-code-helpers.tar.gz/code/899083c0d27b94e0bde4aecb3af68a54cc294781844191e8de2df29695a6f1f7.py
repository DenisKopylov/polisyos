"""Prepare source-pinned Lex removal plans; never execute tests or alter source."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
SCOPE = ROOT / "LOCAL/raw/e02-execution-20261027/repairs/C17-r3"
PRODUCT = ROOT / "policy-engine"
NATIVE = PRODUCT / (
    "docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/"
    "root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/"
    "deep-task-status-audit-20261027-r1"
)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-head", required=True)
    parser.add_argument("--suffix", required=True)
    args = parser.parse_args()
    if not args.suffix or not all(c.isalnum() or c in "-_" for c in args.suffix):
        raise ValueError("suffix must contain only letters, digits, '-' or '_'")
    actual = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
    if actual != args.source_head:
        raise ValueError(f"source mismatch: expected {args.source_head}, actual {actual}")
    manifest = json.loads((SCOPE / "manifest.json").read_text())
    needed = {
        "policy-engine/src/polisyos/lex/legal_evaluation/impact_diff.py",
        "policy-engine/src/polisyos/lex/simulator/cli.py",
        "policy-engine/src/polisyos/core/components/_cli_lex.py",
        "policy-engine/tools/ops_runners/runtime_cli.py",
        "policy-engine/src/polisyos/lex/normpack/diff.py",
        "policy-engine/tests/unit/remediation/test_lex_impact_semantics.py",
    }
    rows = {item["path"]: item for item in manifest["files"]}
    if not needed.issubset(rows):
        raise ValueError("required source pins absent from manifest")
    pins = {str(ROOT / path): sha(ROOT / path) for path in sorted(needed)}
    for path in needed:
        if pins[str(ROOT / path)] != rows[path]["postimage_sha256"]:
            raise ValueError(f"source postimage mismatch: {path}")
    plugin = SCOPE / "removal_controls/lex_impact_removal_plugin.py"
    plugin_dir = plugin.parent
    scenarios = {
        "producer_topics": "test_real_impact_report_reopens_its_diff_and_preserves_issue_and_topic_semantics",
        "report_bridge": "test_real_impact_report_reopens_its_diff_and_preserves_issue_and_topic_semantics",
        "markdown_disclaimer": "test_real_impact_report_reopens_its_diff_and_preserves_issue_and_topic_semantics",
        "manifest_edge": "test_selected_diff_profile_is_reconciled_with_issued_report_manifest",
        "report_reconciliation": "test_selected_report_refuses_forged_derived_values[norms_added-report_norm_diff_counts_mismatch]",
        "diff_reconstruction": "test_selected_report_refuses_incoherent_embedded_diff[missing_added_rule]",
        "delta_replay": "test_selected_report_refuses_forged_derived_values[delta_pass_id-report_compliance_delta_inconsistent]",
        "issue_total_bound": "test_selected_report_refuses_forged_derived_values[old_issue_total-report_issue_total_below_carried_issues]",
        "scope_guard": "test_cross_jurisdiction_is_declared_for_legacy_and_refused_for_opt_in",
    }
    outputs: list[str] = []
    for mode, node in scenarios.items():
        case_id = f"lex-impact-{mode}-{args.suffix}"
        plan_path = NATIVE / f"plan-{case_id}.json"
        if plan_path.exists() or (NATIVE / case_id).exists():
            raise FileExistsError(case_id)
        receipt = NATIVE / case_id / "control.json"
        plan = {
            "case_id": case_id,
            "source_head": args.source_head,
            "task_ids": ["Q0", "LA-017"],
            "nodes": [f"tests/unit/remediation/test_lex_impact_semantics.py::{node}"],
            "extra_env": {
                "PYTHONPATH": str(plugin_dir),
                "PYTEST_PLUGINS": "lex_impact_removal_plugin",
                "POLISYOS_LEX_CONTROL_MODE": mode,
                "POLISYOS_LEX_CONTROL_PINS": json.dumps(pins, sort_keys=True),
                "POLISYOS_LEX_CONTROL_PLUGIN_SHA256": sha(plugin),
                "POLISYOS_LEX_CONTROL_RECEIPT": str(receipt),
            },
            "deadline_seconds": 300,
            "rss_cap_bytes": 2411724800,
            "scope": (
                "Explicit in-memory property removal in the real Lex path. Correct-source "
                "positive must pass first. A useful control is a completed assertion FAIL "
                "at the named property, with unchanged source pins and restored callable; "
                "setup/import/timeout/errors are not a successful removal."
            ),
        }
        plan_path.write_text(json.dumps(plan, indent=2) + "\n")
        outputs.append(str(plan_path))
    print(json.dumps({"plans": outputs, "plugin_sha256": sha(plugin), "source_head": actual}))


if __name__ == "__main__":
    main()
