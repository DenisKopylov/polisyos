from pathlib import Path
D=Path(__file__).resolve().parents[1]
def read(p):return (D/'preimages'/p).read_text()
def save(p,s):
 q=D/'postimages'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(s)
 import ast
 ast.parse(s)
base='policy-engine/src/polisyos/scientist/agent/'
helper='''"""Observe candidate drafter assessments on the existing traced LLM producer.

These are content-bound candidate observations, never calibration, scientific
convergence or publication authority. Missing provider versions stay unknown.
"""

from __future__ import annotations

import hashlib
import json
import math
from typing import TYPE_CHECKING, Any

from polisyos.core.llm.settlement import LLMSettledResponse
from polisyos.scientist.orchestration.engine.convergence import ConvergenceObservation

if TYPE_CHECKING:
    from polisyos.scientist.agent.protocols import ProblemFrame


def confidence_subject_ref(problem_frame: ProblemFrame) -> str:
    """Bind the semantic problem; the exact prompts are bound separately per call."""
    payload = {
        "frame_id": problem_frame.frame_id,
        "domain": problem_frame.domain,
        "problem_statement": problem_frame.problem_statement,
        "actors": problem_frame.actors,
        "goals": problem_frame.goals,
        "constraints": problem_frame.constraints,
        "success_criteria": problem_frame.success_criteria,
        "assumptions": problem_frame.assumptions,
    }
    return hashlib.sha256(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    ).hexdigest()


def confidence_request_ref(*, system: str, user: str) -> str:
    """Bind the actual drafter wire request without storing another prompt copy."""
    return hashlib.sha256(
        json.dumps(
            {"system": system, "user": user, "response_format": {"type": "json_object"}},
            sort_keys=True,
            separators=(",", ":"),
        ).encode()
    ).hexdigest()


def finite_candidate_confidence(value: object) -> float | None:
    """Refuse bools, coercible strings and nonfinite or out-of-range self-grades."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    result = float(value)
    return result if math.isfinite(result) and 0.0 <= result <= 1.0 else None


def observe_candidate_confidence(
    *,
    response: object,
    source_text: str,
    subject_ref: str,
    request_ref: str,
    pass_number: int,
    value: float,
) -> ConvergenceObservation | None:
    """Use the real Core producer event and recompute its response binding.

    Monetary settlement status is deliberately separate: missing cost does not
    erase an observed response, and content does not establish a USD charge.
    """
    if type(response) is not LLMSettledResponse:
        return None
    event = response.settlement.event
    source_ref = hashlib.sha256(source_text.encode("utf-8")).hexdigest()
    if event.response_digest != source_ref:
        return None
    raw = response.response
    version: Any = raw.get("model_version") if isinstance(raw, dict) else getattr(raw, "model_version", None)
    if type(version) is not str or not version.strip():
        version = None
    else:
        version = version.strip()
    return ConvergenceObservation(
        subject_ref=subject_ref,
        request_ref=request_ref,
        source_ref=source_ref,
        producer_event_id=event.event_id,
        producer_kind=event.kind,
        model_ref=event.model,
        model_version=version,
        pass_number=pass_number,
        value=value,
    )
'''
save(base+'_drafter_observations.py',helper)
p=base+'protocols.py';s=read(p);idx=s.index('\n\nclass TaskPriority');s=s[:idx]+'''\n\nfrom polisyos.scientist.orchestration.engine.convergence import (
    ConvergenceObservation,
    ConvergenceState,
)
'''+s[idx:];needle='''    raw_llm_response: str | None = None
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))''';assert needle in s;s=s.replace(needle,'''    raw_llm_response: str | None = None
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    confidence_request_ref: str | None = None
    confidence_observation: ConvergenceObservation | None = None
    convergence_state: ConvergenceState | None = None''',1);save(p,s)
p=base+'drafter_models.py';s=read(p);s=s.replace('from polisyos.scientist.orchestration.engine.convergence import ConvergenceConfig','from polisyos.scientist.orchestration.engine.convergence import (\n    ConvergenceConfig,\n    ConvergenceObservation,\n)');needle='''    verification_code: str | None = None


class MultiPassConfig''';assert needle in s;s=s.replace(needle,'''    verification_code: str | None = None
    confidence_request_ref: str | None = None
    confidence_observation: ConvergenceObservation | None = None


class MultiPassConfig''')
needle='''        raw_max_passes = os.getenv("POLISYOS_DRAFTER_MAX_PASSES")''';assert needle in s;s=s.replace(needle,'''        raw_convergence = os.getenv("POLISYOS_DRAFTER_CONVERGENCE_JSON")
        if raw_convergence:
            # Explicit typed opt-in; no default confidence/convergence authority.
            kwargs["convergence"] = ConvergenceConfig.model_validate_json(raw_convergence)
        raw_max_passes = os.getenv("POLISYOS_DRAFTER_MAX_PASSES")''')
s=s.replace('''    confidence_adjustment: float | None = None
    verification_code: str | None = None


class _ConsolidationPayload''','''    confidence_adjustment: float | None = Field(
        default=None, ge=-1.0, le=1.0, allow_inf_nan=False, strict=True
    )
    verification_code: str | None = None


class _ConsolidationPayload''');s=s.replace('confidence: float | None = Field(default=None, ge=0.0, le=1.0)','confidence: float | None = Field(\n        default=None, ge=0.0, le=1.0, allow_inf_nan=False, strict=True\n    )');save(p,s)
p=base+'drafter_clients.py';s=read(p);s=s.replace('import uuid\n','import uuid\nfrom dataclasses import replace\n');needle='from polisyos.scientist.orchestration.llm import TracedLLMClient';assert needle in s;s=s.replace(needle,needle+'''\n\nfrom ._drafter_observations import (
    confidence_request_ref,
    confidence_subject_ref,
    finite_candidate_confidence,
    observe_candidate_confidence,
)''')
needle='''        return DraftResult(
            draft_id=data.get("draft_id", f"draft_{uuid.uuid4().hex[:8]}"),''';assert needle in s;s=s.replace(needle,'''        observed_confidence = finite_candidate_confidence(data.get("confidence"))
        request_ref = confidence_request_ref(system=prompt, user=user_message)
        subject_ref = confidence_subject_ref(problem_frame)
        response_subject = data.get("problem_frame_ref", problem_frame.frame_id)
        observation = None
        if observed_confidence is not None and response_subject == problem_frame.frame_id:
            observation = observe_candidate_confidence(
                response=response,
                source_text=content,
                subject_ref=subject_ref,
                request_ref=request_ref,
                pass_number=1,
                value=observed_confidence,
            )
        grounding_notes = _context_grounding_notes(problem_frame)
        if observed_confidence is None:
            grounding_notes.append("candidate_confidence_not_established")
        if response_subject != problem_frame.frame_id:
            grounding_notes.append("candidate_confidence_problem_frame_mismatch")
        return DraftResult(
            draft_id=data.get("draft_id", f"draft_{uuid.uuid4().hex[:8]}"),''')
s=s.replace('''            grounding_notes=_context_grounding_notes(problem_frame),
            alternatives_considered=data.get''','''            grounding_notes=grounding_notes,
            alternatives_considered=data.get''');s=s.replace('''            confidence=float(data.get("confidence", 0.6)),
            raw_llm_response=content,
            created_at=datetime.now(UTC),''','''            confidence=observed_confidence if observed_confidence is not None else 0.0,
            raw_llm_response=content,
            created_at=datetime.now(UTC),
            confidence_request_ref=request_ref,
            confidence_observation=observation,''')
# Refinement is a local transformation, not a new model confidence observation.
start=s.index('''        return DraftResult(
            draft_id=f"{draft.draft_id}_refined",''',s.index('class LLMDrafterAgent'))
end=s.index('\n\n    @staticmethod',start)
s=s[:start]+'''        return replace(
            draft,
            draft_id=f"{draft.draft_id}_refined",
            narrative=refined_narrative,
            rationale=f"{draft.rationale} [Refined based on critique]",
            confidence=min(0.95, draft.confidence + 0.05),
            created_at=datetime.now(UTC),
            confidence_request_ref=None,
            confidence_observation=None,
            convergence_state=None,
        )'''+s[end:];save(p,s)
p=base+'_drafter_parsing.py';s=read(p);s=s.replace('from datetime import UTC, datetime','from dataclasses import replace\nfrom datetime import UTC, datetime');start=s.index('''            DraftResult(
                draft_id=f"{original.draft_id}_mp",''');end=s.index('''            True,
        )''',start);s=s[:start]+'''            replace(
                original,
                draft_id=f"{original.draft_id}_mp",
                narrative=payload.narrative or original.narrative,
                interventions=payload.interventions or original.interventions,
                rationale=payload.rationale or original.rationale,
                confidence=payload.confidence
                if payload.confidence is not None
                else original.confidence,
                alternatives_considered=(
                    payload.alternatives_considered or original.alternatives_considered
                ),
                raw_llm_response=raw_response,
                created_at=datetime.now(UTC),
                confidence_request_ref=None,
                confidence_observation=None,
                convergence_state=None,
            ),
'''+s[end:];save(p,s)
print('producer/helper/DTO/parser AST_PASS; runtimeUNRUN')
