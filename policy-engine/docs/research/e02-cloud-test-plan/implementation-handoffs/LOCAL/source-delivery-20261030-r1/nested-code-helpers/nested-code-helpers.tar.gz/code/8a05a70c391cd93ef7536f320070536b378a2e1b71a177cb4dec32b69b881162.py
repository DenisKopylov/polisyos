def body():
    return None
value = body.__code__
def expose(unknown):
    if callable(None):
        values = {"code": value}
    else:
        values = unknown
    opaque({**values})
