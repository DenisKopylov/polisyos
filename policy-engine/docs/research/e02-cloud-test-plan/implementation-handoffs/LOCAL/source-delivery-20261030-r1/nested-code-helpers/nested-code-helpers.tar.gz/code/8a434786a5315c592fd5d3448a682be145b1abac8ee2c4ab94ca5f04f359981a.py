from importlib import import_module
from opaque_vendor import inspect_class

class RefusalError(ValueError):
    pass

inspect_class(RefusalError)

def refuse():
    raise RefusalError("declared_refusal")

def selected():
    return import_module("deferred_escaped_class_selected_target")
