"""Pin registered generator metadata and concrete current/selected inputs, without running it."""
from __future__ import annotations
import hashlib,json,subprocess,tomllib
from pathlib import Path
repo=Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
product=repo/"policy-engine"
raw=repo/"LOCAL/raw/e02-execution-20261027/repairs/SQL-owner-chain-r3-intake-20261028-r1"
sha=lambda b:hashlib.sha256(b).hexdigest()
sql=json.loads((raw/"sql-61-manifest.json").read_bytes())
v3=json.loads((raw/"v3-8-after-sql-manifest.json").read_bytes())
selected={item["path"]:{"post_sha256":item["post_sha256"],"postimage_file":item["postimage_file"]}
          for item in sql["files"]}
for item in v3["files"]:
    selected[item["path"]]={"post_sha256":item["post_sha256"],"postimage_file":item["postimage_file"]}
affected={p:value for p,value in sorted(selected.items())
          if p.startswith("policy-engine/src/") or p.startswith("policy-engine/release-fragments/")}
names=[
 "architecture/generated_artifacts.toml","architecture/public_surface/contract.toml",
 "architecture/policies/directory_contracts.toml","pyproject.toml","uv.lock","hatch.toml",
 "ruff.toml","ruff.generated.toml","package.json","pnpm-lock.yaml","pnpm-workspace.yaml",
 "tools/ops_runners/runtime/export_runtime_openapi.py",
 "tools/ops_runners/runtime/check_runtime_api_contract.py",
 "tools/ops_runners/runtime/generate_runtime_client.py",
 "tools/devx/architecture/guardrails.py","tools/devx/foundry/generate_stubs.py",
 "tools/quality/diagnostics/gen_schema.py",
 "src/polisyos/schemas/abi_models/__init__.py","src/polisyos/schemas/abi_models/catalog.py",
 "src/polisyos/runtime/http/openapi_contract.py",
 "src/polisyos/runtime/http/_resources/confidence_ledger_risk_spend_openapi_example.json",
 "packages/runtime-api-client/package.json",
 "packages/runtime-api-client/scripts/generate-runtime-api-client.sh",
 "packages/runtime-api-client/scripts/generate-openapi-types.mjs",
 "packages/runtime-api-client/scripts/normalize-recursive-openapi-types.mjs",
 "packages/runtime-api-client/scripts/canonicalize-runtime-client.mjs",
 "apps/runtime-dashboard/package.json","apps/runtime-dashboard/scripts/generate-api-client.sh",
 "schemas/runtime_api_v1.openapi.json",
]
inputs=[]
for name in names:
    p=product/name
    assert p.is_file(),p
    inputs.append({"path":"policy-engine/"+name,"current_sha256":sha(p.read_bytes())})
families=tomllib.loads((product/"architecture/generated_artifacts.toml").read_text())["family"]
ids=["abi-schema-snapshots","runtime-openapi-snapshot","runtime-api-client",
     "runtime-dashboard-api-types","public-surface-inventory","foundry-method-stubs"]
found={f["id"]:f for f in families if f["id"] in ids}
assert set(found)==set(ids)
needed=("id","source_of_truth","outputs","regenerate_commands","check_command",
        "output_probe_command","probe_required_paths","probe_input_roots","probe_runtime_paths",
        "freshness_rule","workflow")
record={"schema":"policyos.e02.registered-generated-companion-recipe.v1",
        "current_head":subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo).decode().strip(),
        "current_tree":subprocess.check_output(["git","rev-parse","HEAD^{tree}"],cwd=repo).decode().strip(),
        "sql_manifest_sha256":sha((raw/"sql-61-manifest.json").read_bytes()),
        "v3_manifest_sha256":sha((raw/"v3-8-after-sql-manifest.json").read_bytes()),
        "concrete_baseline_inputs":inputs,"prospective_changed_source_inputs":affected,
        "registered_families":[{k:found[id].get(k) for k in needed} for id in ids],
        "input_boundary":"Pinned named inputs and prospective changed files are exact. Full generator import, file-read, toolchain and environment closure is not established by this source-only recipe; Root must record actual origins and final committed tree when running.",
        "execution_status":"UNRUN"}
(raw/"generated-companions.json").write_text(json.dumps(record,indent=2)+"\n")
print("baseline named inputs",len(inputs),"prospective source inputs",len(affected),"families",len(ids))
print("sha256",sha((raw/"generated-companions.json").read_bytes()))
