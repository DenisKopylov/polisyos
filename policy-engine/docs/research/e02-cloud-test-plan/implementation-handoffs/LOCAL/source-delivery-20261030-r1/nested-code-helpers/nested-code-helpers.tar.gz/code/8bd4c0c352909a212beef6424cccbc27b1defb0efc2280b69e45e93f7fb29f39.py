from types import FunctionType
from importlib import import_module
def body():
    return None
CODE = body.__code__
run = FunctionType(CODE, globals())
if callable(None):
    chosen = run
else:
    chosen = opaque_callable
chosen()
