VALUES = ("one", "two")

def choose(index):
    return VALUES[index]
