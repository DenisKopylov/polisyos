from .api import ANALYTICS_FACADE_EXPORTS as source_map
wrapper = {"nested": [source_map]}
observed_size = len(wrapper)
