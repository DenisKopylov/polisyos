import importlib
from importlib import import_module as selected_alias
from opaque_vendor import inspect_class

class Parent: pass
class Other: pass
if uncertain:
    Base = Parent
else:
    Base = Other
class RefusalError(Base): pass

inspect_class(Parent)

def refuse():
    raise RefusalError("declared_refusal")

selected_alias = inspect_class
