
import importlib
loader = ordinary_function
(loader := importlib.import_module) if condition else (loader := importlib.import_module)
condition and (loader := importlib.import_module)
loader("same_origin_expression_branch")
