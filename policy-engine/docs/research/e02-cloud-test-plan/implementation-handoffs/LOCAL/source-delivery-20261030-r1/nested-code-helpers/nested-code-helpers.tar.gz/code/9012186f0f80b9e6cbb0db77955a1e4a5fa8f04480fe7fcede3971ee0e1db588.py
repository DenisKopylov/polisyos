from types import FunctionType
from importlib import import_module
def body():
    return __import__("bridge_builtin")
CODE = body.__code__
run = FunctionType(CODE, globals())
globals()["__builtins__"] = {}
run()
