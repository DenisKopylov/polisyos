"""Read one preserved historical C96 CAS view; not new native-fit evidence."""

from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
import sys
from pathlib import Path

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
PACKET = ROOT / "LOCAL/raw/e02-execution-20261027/repairs/R4-native-control-r1/controller-r3"
CASE = ROOT / "LOCAL/raw/e02-execution-20261027/repairs/R4-control-front-r1/runs/r4c96r2"
CAS = CASE / "pytest-tmp/test_authenticated_cancellatio0/case/runtime-env/.polisyos"
AID = "8e4cae7271013aa0ee136a847a0b6ffa5301a537084341c0755942af57fee043"
PROFILE = "6594ce4676c0a300ead3ae8321fd0da411eb4656030131485f4fc364bced98a9"
spec = importlib.util.spec_from_file_location(
    "r4_candidate_cas_historical", PACKET / "native_checks.py"
)
assert spec is not None and spec.loader is not None
checks = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = checks
spec.loader.exec_module(checks)


def main() -> None:
    directory = CAS / "artifacts/sha256" / AID[:2] / AID[2:4]
    blob = directory / (AID + ".blob")
    manifest = directory / (AID + ".view." + PROFILE + ".manifest.json")
    blob_bytes, manifest_bytes = blob.read_bytes(), manifest.read_bytes()
    actual_manifest = json.loads(manifest_bytes)
    ref = {
        "artifact_id": "sha256:" + AID,
        "kind": actual_manifest["kind"],
        "media_type": actual_manifest["media_type"],
        "manifest_profile_sha256": "sha256:" + PROFILE,
    }
    locator = {
        "cas_root": str(CAS),
        "payload_path": str(blob),
        "payload_file_bytes": len(blob_bytes),
        "payload_file_sha256": hashlib.sha256(blob_bytes).hexdigest(),
        "manifest_path": str(manifest),
        "manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
        "manifest_profile_sha256": ref["manifest_profile_sha256"],
    }
    _value, receipt = checks.selected_cas(ref, locator, CASE)
    bad_ref = copy.deepcopy(ref)
    bad_ref["kind"] = "wrong.kind"
    rejected_kind = False
    try:
        checks.selected_cas(bad_ref, locator, CASE)
    except ValueError:
        rejected_kind = True
    bad_ref = copy.deepcopy(ref)
    bad_ref["manifest_profile_sha256"] = "sha256:" + "0" * 64
    rejected_profile = False
    try:
        checks.selected_cas(bad_ref, locator, CASE)
    except ValueError:
        rejected_profile = True
    result = {
        "scope": "one historical C96 selected CAS view read-only; no current native-fit evidence",
        "artifact_id": ref["artifact_id"],
        "manifest_profile": ref["manifest_profile_sha256"],
        "cas_identity": receipt,
        "wrong_kind_rejected": rejected_kind,
        "wrong_profile_rejected": rejected_profile,
        "bytes_unchanged": blob.read_bytes() == blob_bytes
        and manifest.read_bytes() == manifest_bytes,
    }
    print(json.dumps(result, sort_keys=True, indent=2))
    if not (rejected_kind and rejected_profile and result["bytes_unchanged"]):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
