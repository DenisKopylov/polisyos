from pathlib import Path
import ast, difflib, hashlib, json, subprocess, tomllib
root=Path.cwd()
dir=root/'LOCAL/raw/e02-execution-20261027/repairs/C52-r2/r3'
base='cfdb1ac1b7a44a782ec8e13b5f0ed9277beed65c'
candidate='93ac5821efeb5c5d797ed822b6322d73f44699c2'
postdir=dir/'postimages'
files=sorted(str(p.relative_to(postdir)) for p in postdir.rglob('*') if p.is_file())
def read_git(rev,path):
    p=subprocess.run(['git','show',f'{rev}:{path}'],capture_output=True)
    return p.stdout if p.returncode == 0 else None
def sha(b): return hashlib.sha256(b).hexdigest()
def blob(b):
    return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def diff(old,new,path):
    if old==new: return ''
    return ''.join(difflib.unified_diff((old or b'').decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+path if old is not None else '/dev/null',tofile='b/'+path))
patches={'base-to-r3.patch':'','candidate-to-r3.patch':'','r2-to-r3.patch':''}
records=[]
for path in files:
    old=read_git(base,path); cand=read_git(candidate,path); new=(postdir/path).read_bytes()
    prior=(dir.parent/'postimages'/path).read_bytes() if (dir.parent/'postimages'/path).exists() else None
    patches['base-to-r3.patch']+=diff(old,new,path)
    patches['candidate-to-r3.patch']+=diff(cand,new,path)
    patches['r2-to-r3.patch']+=diff(prior,new,path)
    records.append({'path':path,'base_blob':None if old is None else blob(old),'candidate_blob':None if cand is None else blob(cand),'postimage_blob':blob(new),'postimage_sha256':sha(new),'bytes':len(new)})
for name,data in patches.items(): (dir/name).write_text(data)
checks=[]
for path in files:
    file=postdir/path
    if file.suffix=='.py':
        ast.parse(file.read_text(),filename=path)
        rel=str(file.relative_to(postdir/'policy-engine'))
        cmd=[str(root/'policy-engine/.venv/bin/python'),'-m','ruff','check','--no-cache','--config',str(root/'policy-engine/ruff.toml'),'--stdin-filename',rel,'-']
        p=subprocess.run(cmd,input=file.read_text(),text=True,capture_output=True,cwd=root/'policy-engine')
        checks.append({'path':path,'check':'AST and Ruff','exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
    if file.suffix=='.toml':
        tomllib.loads(file.read_text()); checks.append({'path':path,'check':'TOML parse','exit_code':0})
cmd=['git','apply','--check',str(dir/'base-to-r3.patch')]
p=subprocess.run(cmd,capture_output=True,text=True,cwd=root)
checks.append({'check':'git apply --check against current working tree','exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip()
difference=subprocess.check_output(['git','diff','--name-only',base,head,'--',*files],text=True).splitlines()
checks.append({'check':'base-to-observed-head destination path intersection','files':difference})
(dir/'static-checks.json').write_text(json.dumps({'checks':checks,'runtime':'UNRUN','semantic_removals':'UNRUN'},indent=2)+'\n')
manifest={'schema':'policyos.e02.scratch_repair.v1','slice':'C52-r3','base_commit':base,'candidate_tree':candidate,'observed_head':head,'observed_head_tree':tree,'later_head_path_intersection':difference,'review':{'path':'LOCAL/raw/e02-execution-20261027/reviews/C52-r2-code.md','sha256':sha((root/'LOCAL/raw/e02-execution-20261027/reviews/C52-r2-code.md').read_bytes())},'postimages':records,'patches':{name:{'sha256':sha((dir/name).read_bytes()),'bytes':(dir/name).stat().st_size} for name in patches},'support_files':{name:{'sha256':sha((dir/name).read_bytes()),'bytes':(dir/name).stat().st_size} for name in ['README.md','make_mutant.py','static-checks.json']},'runtime':'UNRUN','semantic_removals':'UNRUN','canonical_source_changed':False,'index_or_ref_changed':False,'code_acceptance':False,'closure_ids':[]}
(dir/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('manifest',sha((dir/'manifest.json').read_bytes()))
print('head',head,tree,'destination differences',difference)
print('checks',[(c['check'],c.get('exit_code')) for c in checks])
