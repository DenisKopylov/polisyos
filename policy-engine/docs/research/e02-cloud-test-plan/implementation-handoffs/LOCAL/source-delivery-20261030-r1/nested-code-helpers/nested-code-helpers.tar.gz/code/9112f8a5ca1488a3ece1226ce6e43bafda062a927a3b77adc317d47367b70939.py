from types import FunctionType
run = FunctionType(opaque_code, globals())
run()
