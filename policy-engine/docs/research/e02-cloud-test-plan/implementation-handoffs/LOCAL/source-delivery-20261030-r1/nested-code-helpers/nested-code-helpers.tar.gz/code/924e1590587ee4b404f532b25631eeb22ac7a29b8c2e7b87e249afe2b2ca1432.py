from pathlib import Path
import ast,json
ROOT=Path.cwd();POST=ROOT/'LOCAL/raw/e02-execution-20261027/repairs/V3-basis-history-r1/full-v3-r1/leaf-world-basis/postimages';p=POST/'policy-engine/src/polisyos/runtime/quality/data_state_substrate.py';s=p.read_text()
s=s.replace('    from polisyos.runtime.quality.world_model_record import WorldModelOwnerValues\n','    from polisyos.runtime.quality.world_model_record import WorldModelOwnerValues\n    from polisyos.runtime.quality.acquisition_executor import ActivatedSemanticEpochAdmissionReceipt\n',1)
# Full immutable historical activation closure. Core owns each codec and domain hash.
idx=s.index('def _replay_acquired_observation_projection(')
helper='''def _verify_historical_acquisition_activation(
    store: ArtifactStore, *, receipt: object, passport: object,
    receipt_ref: ArtifactRef, passport_ref: ArtifactRef,
    activation: ActivatedSemanticEpochAdmissionReceipt | None,
) -> None:
    """Reconcile immutable activation evidence without a current native permit."""
    from polisyos.core.contracts import epoch
    from polisyos.fabric import data_plane
    from polisyos.runtime.quality.acquisition_executor import ActivatedSemanticEpochAdmissionReceipt

    def read(ref: ArtifactRef, kind: str) -> dict[str, Any]:
        _require_selected_profile(ref, "acquisition_historical_evidence_profile_unselected")
        return epoch.load_verified_epoch_statement(
            store=store, ref=ref, expected_kind=kind, expected_media_type=ref.media_type,
        )

    production = epoch.SemanticEpochProductionReceiptStatement.model_validate(read(
        receipt.semantic_epoch_production_receipt_ref, "epoch.production_receipt"
    ))
    if (production.production_mode != "acquisition_finalization"
        or production.status not in {"appended", "no_change"}
        or production.admitted_boundary_evidence_ref != receipt.admitted_boundary_evidence_ref
        or production.prepared_epoch_ref != receipt.prepared_semantic_epoch_ref
        or production.epoch_ref != receipt.semantic_epoch_stamp.epoch_ref
        or production.semantic_manifest_ref != receipt.semantic_epoch_stamp.semantic_manifest_ref
        or production.requested_query_context_ref != receipt.semantic_epoch_stamp.requested_query_context_ref):
        raise DataStateSubstrateError("acquisition_historical_production_binding_mismatch")
    admitted = epoch.AdmittedAcquisitionBoundaryEvidence.model_validate(read(
        receipt.admitted_boundary_evidence_ref, "epoch.admitted_acquisition_boundary_evidence"
    ))
    actual_activation = ActivatedSemanticEpochAdmissionReceipt(
        passport_ref=passport_ref, prepared_epoch_ref=admitted.prepared_epoch_ref,
        pending_overlay_receipt_ref=admitted.pending_overlay_receipt_ref,
        semantic_epoch_production_receipt_ref=receipt.semantic_epoch_production_receipt_ref,
        overlay_admission_receipt_ref=receipt_ref,
        native_membership_receipt_ref=admitted.native_membership_receipt_ref,
        semantic_denominator_receipt_ref=admitted.semantic_denominator_receipt_ref,
        semantic_projection_verification_receipt_ref=admitted.semantic_projection_verification_receipt_ref,
        semantic_epoch_stamp=admitted.semantic_epoch_stamp, activation_state="active",
    )
    if activation is not None and actual_activation != ActivatedSemanticEpochAdmissionReceipt.model_validate(activation.model_dump(mode="python")):
        raise DataStateSubstrateError("acquisition_historical_growth_activation_mismatch")
    if (admitted.passport_ref != passport_ref
        or admitted.passport_content_hash != data_plane.content_sha256(passport.model_dump(mode="json"))
        or admitted.epoch_id != passport.epoch_id
        or admitted.prepared_epoch_ref != passport.prepared_semantic_epoch_ref
        or admitted.pending_overlay_receipt_ref != receipt.pending_overlay_receipt_ref
        or admitted.semantic_candidate_ref != passport.semantic_boundary_candidate_ref
        or admitted.semantic_candidate_content_hash != passport.semantic_boundary_candidate_content_hash
        or admitted.semantic_epoch_stamp != passport.semantic_epoch_stamp):
        raise DataStateSubstrateError("acquisition_historical_admitted_binding_mismatch")
    loaded: dict[str, object] = {}
    recipe = (
        ("prepared_epoch", "epoch.prepared", None, "polisyos.epoch.prepared.v1"),
        ("native_member", "epoch.acquisition_native_member", None, "polisyos.epoch.acquisition-native-member.v1"),
        ("pending_overlay_receipt", "epoch.pending_overlay_admission_receipt", epoch.PendingOverlayAdmissionStatement, None),
        ("native_membership_receipt", "epoch.acquisition_native_membership", epoch.AcquisitionNativeMembershipReceipt, "polisyos.epoch.acquisition-native-membership-receipt.v1"),
        ("semantic_denominator_receipt", "epoch.acquisition_semantic_denominator_receipt", epoch.AcquisitionSemanticCandidateDenominatorReceipt, "polisyos.epoch.acquisition-semantic-denominator-receipt.v1"),
        ("semantic_projection_verification_receipt", "epoch.acquisition_semantic_projection_verification_receipt", epoch.AcquisitionSemanticProjectionVerificationReceipt, "polisyos.epoch.acquisition-semantic-projection-verification-receipt.v1"),
    )
    for name, kind, model, domain in recipe:
        mapping = read(getattr(admitted, name + "_ref"), kind)
        value = model.model_validate(mapping) if model is not None else mapping
        loaded[name] = value
        observed = (epoch.epoch_semantic_content_hash(domain=domain, value=value)
                    if domain is not None else data_plane.content_sha256(mapping))
        if observed != getattr(admitted, name + "_content_hash"):
            raise DataStateSubstrateError("acquisition_historical_evidence_content_mismatch")
    native = loaded["native_membership_receipt"]
    semantic = loaded["semantic_denominator_receipt"]
    projection = loaded["semantic_projection_verification_receipt"]
    pending = loaded["pending_overlay_receipt"]
    provenance = epoch.AcquisitionProjectionVerifierProvenance.model_validate(read(
        admitted.verifier_provenance_ref, "epoch.acquisition_projection_verifier_provenance"
    ))
    if (native.status != "resolved" or semantic.status != "resolved" or projection.status != "verified"
        or native.query != semantic.query
        or projection.native_membership_receipt_ref != admitted.native_membership_receipt_ref
        or projection.native_membership_receipt_content_hash != admitted.native_membership_receipt_content_hash
        or projection.semantic_denominator_receipt_ref != admitted.semantic_denominator_receipt_ref
        or projection.semantic_denominator_receipt_content_hash != admitted.semantic_denominator_receipt_content_hash
        or projection.verifier_provenance_ref != admitted.verifier_provenance_ref
        or projection.verifier_provenance_content_hash != epoch.epoch_semantic_content_hash(
            domain="polisyos.epoch.acquisition-projection-verifier.v1", value=provenance)
        or pending.epoch_id != passport.epoch_id or pending.passport_id != passport.passport_id
        or pending.boundary_candidate_ref != admitted.semantic_candidate_ref
        or pending.admission_content_sha256 != receipt.admission_content_sha256
        or not any(row.semantic_candidate_ref == admitted.semantic_candidate_ref
                   and row.semantic_candidate_content_hash == admitted.semantic_candidate_content_hash
                   and row.passport_ref == passport_ref and row.binding_status == "bound"
                   and row.query_disposition == "applicable" for row in native.assessments)
        or not any(row.semantic_candidate_ref == admitted.semantic_candidate_ref
                   and row.semantic_candidate_content_hash == admitted.semantic_candidate_content_hash
                   and row.disposition == "applicable" for row in semantic.assessments)):
        raise DataStateSubstrateError("acquisition_historical_projection_binding_mismatch")


'''
s=s[:idx]+helper+s[idx:]
# Pass the actual typed activation on fresh no-snapshot history; snapshot replay reconstructs it.
a=s.index('def _replay_acquired_observation_projection(');b=s.index('def replay_acquired_observation_snapshot_preparation(',a);part=s[a:b];part=part.replace('    expected_source_ref: ArtifactRef | None = None,','    expected_source_ref: ArtifactRef | None = None,\n    activation: ActivatedSemanticEpochAdmissionReceipt | None = None,',1)
needle='''    candidate = epoch.AcquisitionSemanticBoundaryCandidateStatement.model_validate(''';idx=part.index(needle);part=part[:idx]+'''    _verify_historical_acquisition_activation(
        store, receipt=receipt, passport=passport, receipt_ref=receipt_ref,
        passport_ref=passport_ref, activation=activation,
    )
'''+part[idx:];s=s[:a]+part+s[b:]
a=s.index('def replay_acquired_observation_snapshot_preparation(');b=s.index('def _read_acquired_observation_selection(',a);part=s[a:b];part=part.replace('    transaction_time: datetime,','    transaction_time: datetime,\n    activation: ActivatedSemanticEpochAdmissionReceipt | None = None,',1).replace('        expected_source_ref=source_ref,','        expected_source_ref=source_ref,\n        activation=activation,',1);s=s[:a]+part+s[b:]
# Include the complete actual owner application/warning outcomes, alongside state/rules.
a=s.index('def _prepare_acquired_world_semantic_result(');b=s.index('def _verify_actual_acquired_native_world(',a);part=s[a:b];part=part.replace('    data_preparation: AcquiredObservationDataPreparation,','    data_preparation: AcquiredObservationDataPreparation,\n    binding_execution: dict[str, object],',1).replace('    effective["model_dependencies"] = dependencies','    effective["model_dependencies"] = dependencies\n    effective["binding_execution"] = binding_execution',1);s=s[:a]+part+s[b:]
needle='''            state=current.materialized_state,
            data_preparation=data_preparation,''';assert needle in s;s=s.replace(needle,needle+'''\n            binding_execution={"applied_binding_ids": current.applied_binding_ids,
                               "warnings": current.warnings},''',1)
needle='''        effective["model_dependencies"] = _acquired_model_dependency_values(store, world)''';s=s.replace(needle,needle+'''\n        report = load_core_json_artifact(store, views.input_binding_report_ref)
        if (not isinstance(report, dict)
            or report.get("warnings") != list(prepared.warnings)
            or report.get("applied_binding_ids") != list(prepared.applied_binding_ids)):
            raise DataStateSubstrateError("acquisition_world_binding_report_mismatch")
        effective["binding_execution"] = {"applied_binding_ids": prepared.applied_binding_ids,
                                           "warnings": prepared.warnings}''',1)
# Avoid an unnecessary dynamic kwargs dict; keep explicit typed owner arguments.
a=s.index('    arguments = dict(',s.index('def _acquired_binding_meaning('));b=s.index('\n\ndef _acquired_model_dependency_values(',a)
s=s[:a]+'''    if actual_binding_path is None:
        return data_forge_read_api.prepare_snapshot_binding_meaning(
            manifest=manifest, pipeline=_DATA_FORGE_SNAPSHOT_PIPELINE,
            artifact_contents=(content,), artifact_meanings=(artifact_meaning,),
            expected_lineage_refs=lineage_refs, lineage_meanings=lineage_meanings,
        )
    return data_forge_read_api.read_snapshot_binding_meaning(
        binding_path=actual_binding_path, expected_manifest=manifest,
        pipeline=_DATA_FORGE_SNAPSHOT_PIPELINE, artifact_contents=(content,),
        artifact_meanings=(artifact_meaning,), expected_lineage_refs=lineage_refs,
        lineage_meanings=lineage_meanings,
    )
'''+s[b:]
p.write_text(s);ast.parse(s)
