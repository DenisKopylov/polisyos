from types import FunctionType
from importlib import import_module

def body(callback):
    return None

def replacement(callback):
    return callback("deferred_mutator_target")

CODE = body.__code__
run = FunctionType(CODE, globals())

def mutate(target, code):
    setattr(target, "__code__", code)

def consume(unknown_target, unknown_code):
    mutate(unknown_target, unknown_code)
    return run(import_module)
