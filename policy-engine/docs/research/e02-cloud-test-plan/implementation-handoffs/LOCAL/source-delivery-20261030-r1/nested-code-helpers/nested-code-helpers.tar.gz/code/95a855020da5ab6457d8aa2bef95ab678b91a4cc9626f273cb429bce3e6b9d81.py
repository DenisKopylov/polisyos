from types import FunctionType
from importlib import import_module
def body(callback):
    def inner():
        return callback("bridge_context")
    return executor.submit(context.run, inner)
CODE = body.__code__
run = FunctionType(CODE, globals())
run(import_module)
