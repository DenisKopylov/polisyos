"""Prepare one late-bound T02-only native plan; never execute product code/tests."""
from __future__ import annotations
import argparse
from datetime import UTC, datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
PACKAGE = ROOT / 'LOCAL/raw/e02-execution-20261027/repairs/G27-t02-owner-fixture-r2/profile'
RAW = ROOT / 'LOCAL/raw/e02-execution-20261027'
D = ROOT / ('policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/'
            'root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/'
            'deep-task-status-audit-20261027-r1')
PREPARER = RAW / 'prepare_root_native_case_r2.py'
RUNNER = D / 'run_case_with_tools_r3.py'
OBSERVER = D / 'readset_observer_tools_r1.py'
SUPERVISOR = ROOT / ('policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/'
                     'root-postfix-709-q2-helper-actual-20261018/supervise.py')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def ensure_no_symlink_parents(path):
    for parent in [path.parent, *path.parents]:
        if parent.is_symlink():
            raise RuntimeError('symlink output parent: ' + str(parent))
        if not parent.is_dir():
            raise RuntimeError('missing output parent: ' + str(parent))


def require_fresh(path):
    ensure_no_symlink_parents(path)
    if os.path.lexists(path):
        raise RuntimeError('output already exists: ' + str(path))


def stage_exact_plan(path, before, after):
    """Update only the fresh helper-owned regular inode after complete preimage checks."""
    ensure_no_symlink_parents(path)
    original = path.lstat()
    if not stat.S_ISREG(original.st_mode) or original.st_nlink != 1:
        raise RuntimeError('plan must be a regular single-link file')
    fd = os.open(path, os.O_RDWR | os.O_NOFOLLOW)
    try:
        opened = os.fstat(fd)
        if (opened.st_dev, opened.st_ino, opened.st_nlink) != (original.st_dev, original.st_ino, 1):
            raise RuntimeError('plan inode changed')
        chunks = []
        while True:
            chunk = os.read(fd, 65536)
            if not chunk:
                break
            chunks.append(chunk)
        if b''.join(chunks) != before:
            raise RuntimeError('plan preimage differs')
        current = path.lstat()
        if (current.st_dev, current.st_ino, current.st_nlink, current.st_size, current.st_mtime_ns) != (
            opened.st_dev, opened.st_ino, 1, opened.st_size, opened.st_mtime_ns
        ):
            raise RuntimeError('plan path identity changed before write')
        os.lseek(fd, 0, os.SEEK_SET)
        os.ftruncate(fd, 0)
        pending = memoryview(after)
        while pending:
            written = os.write(fd, pending)
            if written <= 0:
                raise OSError('short plan write')
            pending = pending[written:]
        os.fsync(fd)
        current = path.lstat()
        if (current.st_dev, current.st_ino, current.st_nlink) != (opened.st_dev, opened.st_ino, 1):
            raise RuntimeError('plan path identity changed after write')
        if path.read_bytes() != after:
            raise RuntimeError('plan readback mismatch')
    finally:
        os.close(fd)


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=ROOT)


def admit_sources(contract):
    branch = git('symbolic-ref', '-q', 'HEAD').decode().strip()
    if branch != 'refs/heads/codex/e02-unified-local-20261009':
        raise RuntimeError('unexpected branch: ' + branch)
    head = git('rev-parse', 'HEAD').decode().strip()
    tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
    if git('status', '--porcelain=v1', '--untracked-files=no').strip():
        raise RuntimeError('tracked/index state not clean; preserve work and finish Root composition first')
    ancestry = subprocess.run(['git', 'merge-base', '--is-ancestor', contract['commission_source_commit'], head], cwd=ROOT, check=False)
    if ancestry.returncode != 0:
        raise RuntimeError('current source is not an admitted append-only descendant')
    expected = {row['path']: row['sha256'] for row in contract['stable_reviewed_source_pins']}
    paths = [*expected, *contract['late_bound_context_paths']]
    rows = []
    for relative in paths:
        path = ROOT / relative
        work = path.read_bytes()
        committed = git('show', head + ':' + relative)
        indexed = git('show', ':' + relative)
        if work != committed or work != indexed:
            raise RuntimeError('Git/index/work input mismatch: ' + relative)
        if relative in expected and sha(work) != expected[relative]:
            raise RuntimeError('reviewed T02 owner/input changed; delta review required: ' + relative)
        rows.append({'path': relative, 'sha256': sha(work), 'bytes': len(work),
                     'git_blob': git('rev-parse', head + ':' + relative).decode().strip(),
                     'binding': 'reviewed stable' if relative in expected else 'actual dispatch context'})
    return {'head': head, 'tree': tree, 'branch': branch, 'files': rows}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--case', default='g27t02r1')
    parser.add_argument('--prepare', action='store_true', help='Root dispatch only: create the one future helper plan, never a test case/run')
    args = parser.parse_args()
    if not args.case.startswith('g27t02') or not all(c.isalnum() or c in '-_' for c in args.case):
        raise RuntimeError('T02-only fresh case name required')
    contract_path = PACKAGE / 'profile-contract.json'
    contract = json.loads(contract_path.read_bytes())
    source = admit_sources(contract)
    fragment_bytes = (PACKAGE / 'localhost-fragment.sb').read_bytes()
    if sha(fragment_bytes) != contract['fragment_sha256']:
        raise RuntimeError('admitted localhost fragment differs')
    out = D / args.case
    plan_path = D / (args.case + '.json')
    snapshot = D / (args.case + '-root-live-input.json')
    record_dir = PACKAGE / ('preparation-' + args.case)
    for path in (out, plan_path, snapshot, record_dir):
        require_fresh(path)
    tool_paths = [Path(__file__), contract_path, PACKAGE / 'localhost-fragment.sb', PREPARER, RUNNER, OBSERVER, SUPERVISOR]
    tools_before = [{'path': str(path.relative_to(ROOT)), 'sha256': sha(path.read_bytes())} for path in tool_paths]
    for row in contract['reviewed_raw_tool_pins']:
        if sha((ROOT / row['path']).read_bytes()) != row['sha256']:
            raise RuntimeError('reviewed generic native tool changed: ' + row['path'])
    preview = {'case': args.case, 'source': source, 'profile_contract_sha256': sha(contract_path.read_bytes()),
               'tools': tools_before, 'runtime': 'UNRUN', 'case_directory_created': False,
               'source_qualification': contract['source_qualification'], 'G_acceptance': False, 'closure_ids': []}
    if not args.prepare:
        print(json.dumps(preview, indent=2))
        return 0
    record_dir.mkdir(mode=0o700)
    helper_argv = [str(ROOT / 'policy-engine/.venv/bin/python'), '-B', str(PREPARER), args.case,
                   contract['selector'], '--scope',
                   'G27 T02-only actual commit/fault/retry/conflict/gap graph; finite loaded-byte observation only; CodeType/41-role/global98 NE; no G closure']
    with (record_dir / 'helper.stdout.txt').open('xb') as stdout, (record_dir / 'helper.stderr.txt').open('xb') as stderr:
        status = subprocess.run(helper_argv, cwd=ROOT, stdout=stdout, stderr=stderr, check=False).returncode
    (record_dir / 'helper-exit.json').write_text(json.dumps({'argv': helper_argv, 'exit': status}) + '\n')
    if status != 0:
        raise RuntimeError('generic helper refused; actual output retained, no native run')
    before = plan_path.read_bytes()
    (record_dir / 'plan-before.json').write_bytes(before)
    plan = json.loads(before)
    if plan['case_id'] != args.case or plan['source_head'] != source['head'] or plan['source_tree'] != source['tree']:
        raise RuntimeError('helper actual source/case binding differs')
    if plan['nodes'] != [contract['selector']] or plan.get('extra_env') != {}:
        raise RuntimeError('helper selector or environment differs')
    if os.path.lexists(out):
        raise RuntimeError('native case appeared during preparation; do not overwrite')
    if git('rev-parse', 'HEAD').decode().strip() != source['head']:
        raise RuntimeError('Root source changed during preparation')
    fragment = fragment_bytes.decode()
    profile = '(version 1)\n(allow default)\n(deny file-write*)\n(allow file-write* (subpath ' + json.dumps(str(out)) + '))\n(allow file-write* (literal "/dev/null"))\n' + fragment
    plan.update(rss_cap_bytes=3 * 1024**3, deadline_seconds=600,
                sandbox_profile_fragment=fragment, sandbox_profile_fragment_sha256=sha(fragment_bytes),
                sandbox_profile_text=profile, sandbox_profile_sha256=sha(profile.encode()))
    plan['t02_profile_admission'] = {'profile_contract_sha256': sha(contract_path.read_bytes()),
                                     'source_pins': source['files'], 'raw_tools': tools_before,
                                     'source_qualification': contract['source_qualification'],
                                     'single_test_only': True, 'no_experimental_plugin': True}
    after = (json.dumps(plan, indent=2) + '\n').encode()
    stage_exact_plan(plan_path, before, after)
    for row in tools_before:
        if sha((ROOT / row['path']).read_bytes()) != row['sha256']:
            raise RuntimeError('preparation tool input changed')
    receipt = {**preview, 'prepared_at_utc': datetime.now(UTC).isoformat(),
               'helper_argv': helper_argv, 'plan_path': str(plan_path),
               'plan_before_sha256': sha(before), 'plan_after_sha256': sha(after),
               'plan_readback_equal': plan_path.read_bytes() == after,
               'case_directory_created': os.path.lexists(out),
               'run_argv': [str(ROOT / 'policy-engine/.venv/bin/python'), '-B', str(RUNNER), str(plan_path)],
               'resource_snapshot_is_not_reservation': True}
    if receipt['case_directory_created']:
        raise RuntimeError('case path unexpectedly exists; no native dispatch')
    receipt_path = record_dir / 'receipt.json'
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'case': args.case, 'prepared_plan': str(plan_path), 'plan_sha256': sha(after),
                      'actual_head': source['head'], 'actual_tree': source['tree'],
                      'receipt': str(receipt_path), 'receipt_sha256': sha(receipt_path.read_bytes()),
                      'runtime': 'UNRUN', 'case_directory_created': False}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
