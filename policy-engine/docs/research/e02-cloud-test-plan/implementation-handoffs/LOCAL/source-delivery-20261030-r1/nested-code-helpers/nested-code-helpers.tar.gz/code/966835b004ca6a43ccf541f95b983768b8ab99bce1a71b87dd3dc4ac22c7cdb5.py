from types import FunctionType
from importlib import import_module
def body(callback=None):
    return callback("bridge_default")
CODE = body.__code__
run = FunctionType(CODE, globals())
run()
