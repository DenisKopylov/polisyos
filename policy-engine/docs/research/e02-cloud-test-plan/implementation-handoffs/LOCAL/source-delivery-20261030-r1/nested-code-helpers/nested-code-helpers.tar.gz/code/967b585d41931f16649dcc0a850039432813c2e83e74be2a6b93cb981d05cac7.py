from .api import ANALYTICS_FACADE_EXPORTS as source_map
wrapper = []
wrapper.extend(['unrelated scalar'])
opaque(wrapper)
