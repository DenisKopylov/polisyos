"""Behavioral controls for a non-authoritative source-execution producer.

These isolated synthetic modules exercise the producer, not owner admission or
N9. Every failure runs in a fresh process because a failed capture is terminal.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

_PRODUCT_ROOT = Path(__file__).resolve().parents[4]


def _run_fresh(tmp_path: Path, program: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, "-I", "-S", "-B", "-c", program, str(_PRODUCT_ROOT), str(tmp_path)],
        text=True,
        capture_output=True,
        check=False,
        timeout=20,
    )


def _assert_case(tmp_path: Path, program: str) -> None:
    result = _run_fresh(tmp_path, program)
    assert result.returncode == 0, result.stderr


def test_selected_bytes_execute_without_replaced_get_code_and_spoofed_metadata(
    tmp_path: Path,
) -> None:
    _assert_case(
        tmp_path,
        r"""
import builtins
import hashlib
import importlib.machinery
import pathlib
import sys

sys.path.insert(0, sys.argv[1])
from tools.loaded_execution_capture import CaptureError, ExpectedSource, SourceExecutionCapture

root = pathlib.Path(sys.argv[2])
package = root / "capture_witness"
package.mkdir()
source = b"value = 'canonical'\n"
(package / "__init__.py").write_bytes(source)
expected = {"capture_witness": ExpectedSource("capture_witness/__init__.py", hashlib.sha256(source).hexdigest())}
capture = SourceExecutionCapture(root, expected)
initial = capture.diagnostic()
assert initial.phase == "new" and initial.status == "not_established"
assert initial.runtime_profile_id is None and initial.currentness_time_role == "not_evaluated"
assert initial.first_unestablished_premise == "appointed_profile" and initial.failed_premise is None
capture.install()
sys.path.insert(0, str(root))
original = importlib.machinery.SourceFileLoader.get_code

def poisoned(self, fullname):
    return compile("value = 'changed'\n", self.path, "exec")

importlib.machinery.SourceFileLoader.get_code = poisoned
try:
    import capture_witness
finally:
    importlib.machinery.SourceFileLoader.get_code = original
assert capture_witness.value == "canonical"
record = capture.completed("capture_witness")
assert record.module is capture_witness
assert record.source_sha256 == hashlib.sha256(source).hexdigest()
assert record.code.co_filename == str(package / "__init__.py")
observed = capture.diagnostic()
assert observed.phase == "collecting" and observed.status == "not_established"
assert observed.completed_module_count == 1 and observed.captured_source_projection_sha256.startswith("sha256:")
assert observed.provider_projection_sha256 is None
capture.assert_retained(frozenset({"capture_witness"}))

class MetadataSpoof:
    def __eq__(self, other):
        builtins.capture_comparator_called = True
        raise AssertionError("candidate comparator executed")
    def __ne__(self, other):
        builtins.capture_comparator_called = True
        raise AssertionError("candidate comparator executed")

builtins.capture_comparator_called = False
capture_witness.__spec__.origin = MetadataSpoof()
try:
    capture.assert_retained(frozenset({"capture_witness"}))
except CaptureError as exc:
    assert str(exc) == "retained_module_changed"
else:
    raise AssertionError("changed spec origin was accepted")
assert capture.failed and not builtins.capture_comparator_called
failed = capture.diagnostic()
assert failed.phase == "failed" and failed.failure_code == "retained_module_changed"
assert failed.failed_premise == "complete_relevant_bindings"
try:
    SourceExecutionCapture(root, expected).install()
except CaptureError as exc:
    assert str(exc) == "capture_process_already_attempted"
else:
    raise AssertionError("failed process was recaptured")
""",
    )


_BINDING_CASE = r"""
import hashlib
import importlib
import pathlib
import sys

sys.path.insert(0, sys.argv[1])
from tools.loaded_execution_capture import CaptureError, ExpectedSource, SourceExecutionCapture

root = pathlib.Path(sys.argv[2])
package_name = "capture_bindings"
(root / package_name).mkdir()
provider_name = package_name + ".provider"
consumer_name = package_name + ".consumer"
unrelated_name = package_name + ".unrelated"
files = {
    package_name: (package_name + "/__init__.py", b""),
    provider_name: (package_name + "/provider.py", b"def answer():\n    return 1\n"),
    consumer_name: (package_name + "/consumer.py", b"from .provider import answer\nimport importlib\ncached = importlib.import_module(__package__ + '.provider')\n"),
    unrelated_name: (package_name + "/unrelated.py", b"marker = object()\n"),
}
for name, (relative, content) in files.items():
    (root / relative).write_bytes(content)
expected = {name: ExpectedSource(relative, hashlib.sha256(content).hexdigest())
            for name, (relative, content) in files.items()}
capture = SourceExecutionCapture(root, expected, exports={provider_name: {"answer"}, unrelated_name: {"marker"}})
capture.install()
sys.path.insert(0, str(root))
consumer = importlib.import_module(consumer_name)
provider = importlib.import_module(provider_name)
unrelated = importlib.import_module(unrelated_name)
unrelated.marker = object()
capture.assert_retained(frozenset({package_name, provider_name, consumer_name}))
capture.assert_binding(consumer_name, "answer", provider_name, "answer")
events = capture.import_events()
direct = [event for event in events if event.importer is consumer and event.provider is provider
          and event.route == "builtin_import" and event.requested_exports == ("answer",)]
cached = [event for event in events if event.importer is consumer and event.provider is provider
          and event.route == "import_module"]
assert len(direct) == 1 and direct[0].retained_exports["answer"] is provider.answer
assert direct[0].unresolved_exports == () and direct[0].caller_code.co_filename == str(root / files[consumer_name][0])
assert len(cached) == 1 and consumer.cached is provider
capture.assert_import_binding(direct[0], importer_attribute="answer", provider_export="answer")

def spoof():
    return 1

if CASE_MODE:
    provider.answer = spoof
consumer.answer = spoof
try:
    capture.assert_import_binding(direct[0], importer_attribute="answer", provider_export="answer")
except CaptureError as exc:
    expected_reason = "retained_export_changed" if CASE_MODE else "import_event_binding_changed"
    assert str(exc) == expected_reason
else:
    raise AssertionError("substituted provider/importer binding was accepted")
assert capture.failed
"""


def test_importer_only_substitution_is_refused(tmp_path: Path) -> None:
    _assert_case(tmp_path, _BINDING_CASE.replace("CASE_MODE", "False"))


def test_coherent_provider_and_importer_substitution_is_refused(tmp_path: Path) -> None:
    _assert_case(tmp_path, _BINDING_CASE.replace("CASE_MODE", "True"))


_EARLY_CASE = r"""
import hashlib
import pathlib
import sys
import types

sys.path.insert(0, sys.argv[1])
from tools.loaded_execution_capture import CaptureError, ExpectedSource, SourceExecutionCapture

root = pathlib.Path(sys.argv[2])
package = root / "capture_drift"
package.mkdir()
source = b"value = 1\n"
(package / "__init__.py").write_bytes(SOURCE_BYTES)
expected = {"capture_drift": ExpectedSource("capture_drift/__init__.py", hashlib.sha256(source).hexdigest())}
"""


def test_preloaded_module_refuses_and_cannot_retry_in_process(tmp_path: Path) -> None:
    _assert_case(
        tmp_path,
        _EARLY_CASE.replace("SOURCE_BYTES", "source")
        + r"""
sys.modules["capture_drift"] = types.ModuleType("capture_drift")
first = SourceExecutionCapture(root, expected)
try:
    first.install()
except CaptureError as exc:
    assert str(exc) == "selected_package_preloaded"
else:
    raise AssertionError("preloaded module was retroactively adopted")
del sys.modules["capture_drift"]
try:
    SourceExecutionCapture(root, expected).install()
except CaptureError as exc:
    assert str(exc) == "capture_process_already_attempted"
else:
    raise AssertionError("failed process was recaptured")
assert first.failed
""",
    )


def test_post_install_cached_module_refuses_and_candidate_can_continue(tmp_path: Path) -> None:
    _assert_case(
        tmp_path,
        _EARLY_CASE.replace("SOURCE_BYTES", "source")
        + r"""
capture = SourceExecutionCapture(root, expected)
capture.install()
try:
    capture.assert_retained(frozenset())
except CaptureError as exc:
    assert str(exc) == "capture_required_set_invalid"
else:
    raise AssertionError("empty selected set was accepted")
sys.modules["capture_drift"] = types.ModuleType("capture_drift")
try:
    capture.assert_retained(frozenset({"capture_drift"}))
except CaptureError as exc:
    assert str(exc) == "required_module_without_execution"
else:
    raise AssertionError("post-install cached module was accepted")
del sys.modules["capture_drift"]
sys.path.insert(0, str(root))
import capture_drift
assert capture_drift.value == 1 and capture.failed
try:
    SourceExecutionCapture(root, expected).install()
except CaptureError as exc:
    assert str(exc) == "capture_process_already_attempted"
else:
    raise AssertionError("failed process was recaptured")
""",
    )


def test_removed_finder_is_a_terminal_failure(tmp_path: Path) -> None:
    _assert_case(
        tmp_path,
        _EARLY_CASE.replace("SOURCE_BYTES", "source")
        + r"""
capture = SourceExecutionCapture(root, expected)
capture.install()
sys.meta_path.remove(capture._finder)
try:
    capture.assert_retained(frozenset({"capture_drift"}))
except CaptureError as exc:
    assert str(exc) == "capture_finder_changed"
else:
    raise AssertionError("removed capture finder was accepted")
assert capture.failed
""",
    )


def test_replaced_import_hook_is_a_terminal_failure(tmp_path: Path) -> None:
    _assert_case(
        tmp_path,
        _EARLY_CASE.replace("SOURCE_BYTES", "source")
        + r"""
import builtins
original = builtins.__import__
capture = SourceExecutionCapture(root, expected)
capture.install()
builtins.__import__ = original
try:
    capture.assert_retained(frozenset({"capture_drift"}))
except CaptureError as exc:
    assert str(exc) == "capture_import_hook_changed"
else:
    raise AssertionError("replaced import hook was accepted")
assert capture.failed
""",
    )


def test_changed_source_refuses_exactly_and_candidate_can_continue(tmp_path: Path) -> None:
    _assert_case(
        tmp_path,
        _EARLY_CASE.replace("SOURCE_BYTES", "b'value = 2\\n'")
        + r"""
capture = SourceExecutionCapture(root, expected)
capture.install()
sys.path.insert(0, str(root))
try:
    import capture_drift
except CaptureError as exc:
    assert str(exc) == "selected_source_bytes_mismatch"
else:
    raise AssertionError("different selected bytes executed")
assert capture.failed
assert capture.diagnostic().failure_code == "selected_source_bytes_mismatch"
import capture_drift
assert capture_drift.value == 2
try:
    SourceExecutionCapture(root, expected).install()
except CaptureError as exc:
    assert str(exc) == "capture_process_already_attempted"
else:
    raise AssertionError("failed process was recaptured")
""",
    )


def test_initializer_metadata_refusal_does_not_invoke_comparator(tmp_path: Path) -> None:
    _assert_case(
        tmp_path,
        r'''
import builtins
import hashlib
import pathlib
import sys

sys.path.insert(0, sys.argv[1])
from tools.loaded_execution_capture import CaptureError, ExpectedSource, SourceExecutionCapture
root = pathlib.Path(sys.argv[2])
package = root / "capture_invalid_metadata"
package.mkdir()
source = b"""import builtins
class Spoof:
    def __eq__(self, other):
        builtins.capture_comparator_called = True
        raise AssertionError('candidate comparator executed')
    def __ne__(self, other):
        builtins.capture_comparator_called = True
        raise AssertionError('candidate comparator executed')
__file__ = Spoof()
"""
(package / "__init__.py").write_bytes(source)
capture = SourceExecutionCapture(root, {
    "capture_invalid_metadata": ExpectedSource("capture_invalid_metadata/__init__.py", hashlib.sha256(source).hexdigest())
})
builtins.capture_comparator_called = False
capture.install()
sys.path.insert(0, str(root))
try:
    import capture_invalid_metadata
except CaptureError as exc:
    assert str(exc) == "module_initialization_invalid"
else:
    raise AssertionError("non-string source metadata was accepted")
assert capture.failed and not builtins.capture_comparator_called
''',
    )


def test_unrecorded_dynamic_import_caller_cannot_join_capture(tmp_path: Path) -> None:
    _assert_case(
        tmp_path,
        r"""
import hashlib
import pathlib
import sys

sys.path.insert(0, sys.argv[1])
from tools.loaded_execution_capture import CaptureError, ExpectedSource, SourceExecutionCapture
root = pathlib.Path(sys.argv[2])
package = root / "capture_dynamic"
package.mkdir()
source = b"exec(compile('import pathlib', __file__, 'exec'), globals())\n"
(package / "__init__.py").write_bytes(source)
capture = SourceExecutionCapture(root, {
    "capture_dynamic": ExpectedSource("capture_dynamic/__init__.py", hashlib.sha256(source).hexdigest())
})
capture.install()
sys.path.insert(0, str(root))
try:
    import capture_dynamic
except CaptureError:
    pass
else:
    raise AssertionError("unrecorded compiled caller entered the capture")
assert capture.failed and capture.failure_reason == "import_caller_code_unrecorded"
""",
    )


def test_forked_child_cannot_reuse_parent_capture(tmp_path: Path) -> None:
    _assert_case(
        tmp_path,
        r"""
import hashlib
import os
import pathlib
import sys

sys.path.insert(0, sys.argv[1])
from tools.loaded_execution_capture import CaptureError, ExpectedSource, SourceExecutionCapture
root = pathlib.Path(sys.argv[2])
package = root / "capture_fork"
package.mkdir()
source = b"value = 1\n"
(package / "__init__.py").write_bytes(source)
expected = {"capture_fork": ExpectedSource("capture_fork/__init__.py", hashlib.sha256(source).hexdigest())}
capture = SourceExecutionCapture(root, expected)
capture.install()
sys.path.insert(0, str(root))
import capture_fork
capture.assert_retained(frozenset({"capture_fork"}))
parent_pid = os.getpid()
pid = os.fork()
if pid == 0:
    os.getpid = lambda: parent_pid
    try:
        capture.assert_retained(frozenset({"capture_fork"}))
    except CaptureError as exc:
        if str(exc) != "capture_inherited_across_fork":
            os._exit(2)
    else:
        os._exit(3)
    if capture.diagnostic().failure_code != "capture_inherited_across_fork":
        os._exit(4)
    try:
        SourceExecutionCapture(root, expected).install()
    except CaptureError as exc:
        os._exit(0 if str(exc) == "capture_process_already_attempted" else 5)
    os._exit(6)
_, status = os.waitpid(pid, 0)
assert os.waitstatus_to_exitcode(status) == 0
capture.assert_retained(frozenset({"capture_fork"}))
""",
    )


def test_cycle_is_provisional_and_initializer_failure_is_terminal(tmp_path: Path) -> None:
    _assert_case(
        tmp_path,
        r"""
import builtins
import hashlib
import pathlib
import sys

sys.path.insert(0, sys.argv[1])
from tools.loaded_execution_capture import CaptureError, ExpectedSource, SourceExecutionCapture
root = pathlib.Path(sys.argv[2])
package = root / "capture_cycle"
package.mkdir()
files = {
    "capture_cycle": ("capture_cycle/__init__.py", b"from . import child\nready = True\n"),
    "capture_cycle.child": ("capture_cycle/child.py", b"import builtins\nfrom tools.loaded_execution_capture import CaptureError\ntry:\n    builtins.capture_test.completed('capture_cycle')\nexcept CaptureError as exc:\n    provisional = str(exc) == 'module_not_completed'\nelse:\n    provisional = False\n"),
    "capture_cycle.broken": ("capture_cycle/broken.py", b"raise RuntimeError('initializer failed')\n"),
}
for name, (relative, content) in files.items():
    (root / relative).write_bytes(content)
expected = {name: ExpectedSource(relative, hashlib.sha256(content).hexdigest())
            for name, (relative, content) in files.items()}
capture = SourceExecutionCapture(root, expected)
builtins.capture_test = capture
capture.install()
sys.path.insert(0, str(root))
import capture_cycle
assert capture_cycle.child.provisional
assert capture.completed("capture_cycle").module is capture_cycle
capture.assert_retained(frozenset({"capture_cycle", "capture_cycle.child"}))
try:
    import capture_cycle.broken
except RuntimeError:
    pass
else:
    raise AssertionError("broken initializer unexpectedly succeeded")
assert capture.failed
try:
    capture.assert_retained(frozenset({"capture_cycle"}))
except CaptureError:
    pass
else:
    raise AssertionError("terminal failure still supports evidence")
""",
    )
