"""Root-only finite observed Python byte reconciliation; no runtime verdict."""
from pathlib import Path
import argparse
import hashlib
import io
import json
import runpy
import subprocess
from external_admission import external_existing_dir, no_symlink_components, fresh

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
PRODUCT = ROOT / 'policy-engine'
D = PRODUCT / 'docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/deep-task-status-audit-20261027-r1'

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('case')
    parser.add_argument('head')
    parser.add_argument('--parent', required=True)
    args = parser.parse_args()
    assert args.case and all(c.isalnum() or c in '-_' for c in args.case)
    assert git('rev-parse', 'HEAD').decode().strip() == args.head
    parent = external_existing_dir(args.parent, ROOT)
    output = parent / args.case
    no_symlink_components(output)
    assert output.is_dir()
    audit_path = output / 'audit-result.json'
    no_symlink_components(audit_path)
    audit = json.loads(audit_path.read_text())
    assert audit['plan']['source_head'] == args.head
    assert audit['plan']['case_parent'] == str(parent)
    assert audit['plan']['source_tree'] == git('rev-parse', 'HEAD^{tree}').decode().strip()
    runpy.run_path(str(PRODUCT / 'docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/root-layer-lib.py'))['guard']()
    live_path = ROOT / 'LOCAL/raw/root-live-ownership-20261021.json'
    assert hashlib.sha256(live_path.read_bytes()).hexdigest() == audit['plan']['retained_root_live_sha256']
    observed = {}
    readsets = sorted((output / 'readsets').glob('*.json'))
    assert readsets
    for source in readsets:
        no_symlink_components(source)
        for row in json.loads(source.read_text())['modules']:
            relative = Path(row['path'])
            assert not relative.is_absolute() and '..' not in relative.parts
            assert relative.parts[0] in {'src', 'tests', 'tools'}
            target = PRODUCT / relative
            assert target.resolve().is_relative_to(PRODUCT)
            path = str(target.relative_to(ROOT))
            assert path not in observed or observed[path] == row['sha256']
            observed[path] = row['sha256']
    committed = {}
    for record in git('ls-tree', '-r', '-z', args.head).split(b'\0'):
        if record:
            left, path = record.split(b'\t')
            committed[path.decode()] = left.split()[2].decode()
    index = {}
    for record in git('ls-files', '--stage', '-z').split(b'\0'):
        if record:
            left, path = record.split(b'\t')
            _mode, oid, stage = left.split()
            assert stage == b'0'
            index[path.decode()] = oid.decode()
    for path in observed:
        assert committed[path] == index[path], path
    query = ('\n'.join(committed[path] for path in observed) + '\n').encode()
    batch = subprocess.run(['git', '-C', str(ROOT), 'cat-file', '--batch'], input=query, capture_output=True, check=True)
    stream = io.BytesIO(batch.stdout)
    sha = lambda data: hashlib.sha256(data).hexdigest()
    mismatches = []
    for path, expected in observed.items():
        _oid, _kind, length = stream.readline().split()
        body = stream.read(int(length))
        assert stream.read(1) == b'\n'
        current = sha((ROOT / path).read_bytes())
        if sha(body) != expected or current != expected:
            mismatches.append({'path': path, 'observed': expected, 'git': sha(body), 'work': current})
    result = {'source_head': args.head, 'source_tree': git('rev-parse', 'HEAD^{tree}').decode().strip(), 'case': args.case, 'finite_loaded_py_paths': len(observed), 'git_index_work_mismatches': mismatches, 'denominator': 'All observed imported src/polisyos, tests and tools Python paths; unimported paths, external packages/native libraries excluded', 'audit_sha256': sha((output / 'audit-result.json').read_bytes()), 'runtime_result': audit['result'].get('junit'), 'G_acceptance': False, 'closure_ids': []}
    destination = parent / (args.case + '-Git-readback.json')
    fresh(destination, parent)
    with destination.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(result, indent=2) + '\n')
    assert not mismatches
    assert git('rev-parse', 'HEAD').decode().strip() == args.head
    assert hashlib.sha256(live_path.read_bytes()).hexdigest() == audit['plan']['retained_root_live_sha256']
    print(json.dumps({'receipt': str(destination), 'sha256': sha(destination.read_bytes()), 'paths': len(observed), 'mismatches': len(mismatches), 'runtime': result['runtime_result']}))

if __name__ == '__main__':
    main()
