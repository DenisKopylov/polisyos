"""Root-only, source-reviewed, single native ForestDR cancellation pilot.

Importing this controller does not start pytest or import product code. The
required admission JSON is made only after canonical source composition and
independent source/profile review. A fresh output directory is never reused.
"""

from __future__ import annotations

import argparse
import importlib.metadata
import importlib.util
import json
import math
import os
import platform
import re
import runpy
import shutil
import signal
import subprocess
import sys
import time
import traceback
import xml.etree.ElementTree as ET
from datetime import UTC, datetime
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
PRODUCT = ROOT / "policy-engine"
RAW = ROOT / "LOCAL/raw/e02-execution-20261027"
PACKET = RAW / "repairs/R4-native-control-r1"
NODE = "tests/unit/runtime/http/test_observational_method_runtime.py::test_real_forest_fit_progress_spans_durable_cancel_post"
TEST = "policy-engine/" + NODE.split("::")[0]
BASE = "8f7c22436143cf52cf182b1fcc5c95d22b8be451"
BRANCH = "codex/e02-unified-local-20261009"
SPEC = RAW / "reviews/R4-native-control-next-r1/README.md"
SPEC_SHA = "abf53b85e59f56ad00e0c1680a7d33c9028c7fc846f8fbcf2f5b8eee3888dad2"
RETAINED = RAW / "repairs/R4-control-native-r1/controller.py"
RETAINED_SHA = "47acd822e06bb8b3f2979e35f93d2adfbfc0a8a46744de371f8d4752b3f34809"
CHECKS = PACKET / "native-profile-8k512-r1/native_checks.py"
GUARD = PRODUCT / (
    "docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/"
    "root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/"
    "root-layer-lib.py"
)
GUARD_SHA = "4b381f40f830180c0aa3d1a3cc6d091bc5e5f4598660a1824894d7a188351d35"
SUPERVISOR = PRODUCT / (
    "docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/"
    "root-postfix-709-q2-helper-actual-20261018/supervise.py"
)
SUPERVISOR_SHA = "a94a662308270ba3aca96c1d9c75e53a05e37a923a6188d0f464f8ac1e90909e"
REFERENCE = PRODUCT / (
    "docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/"
    "root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1/"
    "deep-task-status-audit-20261027-r1/r37c1.json"
)
FRAGMENT_SHA = "56a5de85bbead034300385917ae76c7718487c044df7311baf1bb8713b02f719"
LIVE = ROOT / "LOCAL/raw/root-live-ownership-20261021.json"
PYTHON = PRODUCT / ".venv/bin/python"
HARNESS = PRODUCT / "tests/_helpers/e02_c96_control_harness.py"
CLEAR = (
    "PYTHONPATH",
    "PYTEST_ADDOPTS",
    "PYTEST_PLUGINS",
    "PYTEST_DISABLE_PLUGIN_AUTOLOAD",
    "PYTHONHOME",
    "VIRTUAL_ENV",
)
DISK_START = 8 * 1024**3
DISK_STOP = 6 * 1024**3
RSS_CAP = 3 * 1024**3
DEADLINE = 600
WITNESS_PROFILE = {
    "rss_cap_bytes": RSS_CAP,
    "disk_admission_bytes": DISK_START,
    "disk_stop_bytes": DISK_STOP,
    "deadline_seconds": DEADLINE,
    "numeric_threads": 1,
    "real_numeric_jobs": 1,
    "shared_executor_capacity": 2,
    "shared_executor_queue_capacity": 2,
    "nonnumeric_peer": "event_wait_after_real_tree_entry_release_after_post_response",
    "queued_followers": 2,
    "input_rows": 8000,
    "forest_estimators": 512,
    "workload_profile": "synthetic_8k_512_tree_sizing_v1",
}
REQUIRED = {
    TEST,
    "policy-engine/tests/conftest.py",
    "policy-engine/tests/_helpers/e02_c96_control_harness.py",
    "policy-engine/tests/_helpers/r4_native_fit_observer.py",
    "policy-engine/tests/_helpers/runtime_http.py",
    "policy-engine/tests/_helpers/observational_source_runtime.py",
    "policy-engine/src/polisyos/common/async_tools/__init__.py",
    "policy-engine/src/polisyos/runtime/http/services/control/run_lifecycle.py",
    "policy-engine/src/polisyos/runtime/http/services/control_plane_store.py",
    "policy-engine/src/polisyos/runtime/http/services/control_worker.py",
    "policy-engine/src/polisyos/scientist/compute/runner.py",
    "policy-engine/src/polisyos/foundry/methods/catalog/causal/forest_dr.py",
    "policy-engine/pytest.ini",
    "policy-engine/pyproject.toml",
}


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load pinned helper " + str(path))
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


checks = load(CHECKS, "r4_native_checks")
need = checks.require
sha = checks.sha_bytes


def git(*args: str) -> bytes:
    return subprocess.check_output(["git", "-C", str(ROOT), *args])


def tracked_pin(path: str, head: str) -> dict:
    rel = Path(path)
    need(not rel.is_absolute() and ".." not in rel.parts, "unsafe source pin")
    data = (ROOT / rel).read_bytes()
    need(
        data == git("show", head + ":" + path),
        "worktree differs from admitted Git pin: " + path,
    )
    blob = sha1_blob(data)
    index = git("ls-files", "--stage", "--", path).decode().split()
    need(
        len(index) >= 3 and index[1] == blob and index[2] == "0",
        "index pin differs: " + path,
    )
    return {"path": path, "bytes": len(data), "sha256": sha(data), "git_blob": blob}


def sha1_blob(data: bytes) -> str:
    import hashlib

    return hashlib.sha1(
        b"blob " + str(len(data)).encode() + b"\0" + data, usedforsecurity=False
    ).hexdigest()


def admission(path: Path, expected_sha: str, controller_sha: str, checks_sha: str) -> dict:
    """Admit one externally reviewed candidate; do not silently update a binding."""
    need(path.resolve(strict=True).is_relative_to(RAW.resolve()), "admission outside RAW")
    data = path.read_bytes()
    need(sha(data) == expected_sha, "admission hash mismatch")
    item = json.loads(data)
    need(
        item["schema"] == "policyos.e02.r4.native-pilot-admission.v1" and item["decision"] == "GO",
        "source/profile not admitted",
    )
    need(item["branch"] == BRANCH and item["source_base"] == BASE, "branch/base mismatch")
    need(
        item["controller_sha256"] == controller_sha and item["checks_sha256"] == checks_sha,
        "reviewed controller differs",
    )
    need(
        item["numeric_job_alone_confirmed"] is True,
        "exclusive numeric profile not confirmed by Root",
    )
    need(item["resource_profile"] == WITNESS_PROFILE, "reviewed witness profile differs")
    review = ROOT / item["review_path"]
    need(
        review.resolve(strict=True).is_relative_to(RAW.resolve())
        and checks.sha_file(review) == item["review_sha256"],
        "review bytes unavailable",
    )
    draft = ROOT / item["draft_path"]
    need(
        draft.resolve(strict=True).is_relative_to(RAW.resolve())
        and checks.sha_file(draft) == item["draft_sha256"],
        "reviewed draft unavailable",
    )
    review_text = review.read_text()
    need(
        item["draft_sha256"] in review_text
        and re.search(r"(?mi)^\s*(?:decision|verdict):\s*GO\s*$", review_text) is not None,
        "review does not admit this exact draft",
    )
    draft_item = json.loads(draft.read_bytes())
    for key in (
        "branch",
        "source_base",
        "source_head",
        "source_tree",
        "changed_paths_from_base",
        "test_path",
        "fixture_postimage_sha256",
        "fixture_manifest_path",
        "fixture_manifest_sha256",
        "controller_sha256",
        "checks_sha256",
        "source_pins",
        "node",
        "resource_profile",
    ):
        need(
            draft_item[key] == item[key],
            "admission differs from reviewed draft: " + key,
        )
    fixture_manifest = ROOT / item["fixture_manifest_path"]
    need(
        fixture_manifest.resolve(strict=True).is_relative_to(PACKET.resolve())
        and checks.sha_file(fixture_manifest) == item["fixture_manifest_sha256"],
        "fixture author manifest differs",
    )
    need(item["test_path"] == TEST, "candidate test path differs")
    need(
        checks.sha_file(ROOT / TEST) == item["fixture_postimage_sha256"],
        "fixture postimage differs",
    )
    actual_head, actual_tree = git("rev-parse", "HEAD", "HEAD^{tree}").decode().splitlines()
    need(
        (actual_head, actual_tree) == (item["source_head"], item["source_tree"]),
        f"source commit/tree mismatch: actual={(actual_head, actual_tree)}, expected={(item['source_head'], item['source_tree'])}; do not repair",
    )
    need(
        git("symbolic-ref", "--short", "HEAD").decode().strip() == BRANCH,
        "branch mismatch",
    )
    need(
        not git("status", "--porcelain", "--untracked-files=no"),
        "tracked/index state dirty",
    )
    need(
        subprocess.run(
            ["git", "-C", str(ROOT), "merge-base", "--is-ancestor", BASE, actual_head],
            check=False,
        ).returncode
        == 0,
        "source is not append-only from reviewed inspection base",
    )
    changed = sorted(
        p.decode()
        for p in git("diff", "--no-renames", "--name-only", "-z", BASE, actual_head).split(b"\0")
        if p
    )
    need(
        changed == sorted(item["changed_paths_from_base"]),
        "candidate changed-path denominator differs",
    )
    pins = item["source_pins"]
    need(
        isinstance(pins, list) and len(pins) == len({x["path"] for x in pins}),
        "duplicate selected pin",
    )
    need(
        REQUIRED <= {x["path"] for x in pins},
        "required owner inputs omitted from review",
    )
    need(
        sorted(pins, key=lambda x: x["path"])
        == [tracked_pin(p["path"], actual_head) for p in sorted(pins, key=lambda x: x["path"])],
        "admitted source pins differ",
    )
    return item


def recursive_errors(value: object, prefix: str = "result") -> dict:
    found = {}
    if isinstance(value, dict):
        for key, child in value.items():
            name = prefix + "." + str(key)
            if "error" in str(key).lower() and child not in (None, "", [], {}, False):
                found[name] = child
            else:
                found.update(recursive_errors(child, name))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            found.update(recursive_errors(child, prefix + "[" + str(index) + "]"))
    return found


def strict_supervisor(case: Path, result: dict, plan: dict) -> dict:
    """Recompute all samples; a resource abort can never qualify as PASS."""
    need(
        plan["rss_cap_bytes"] == RSS_CAP
        and plan["disk_stop_bytes"] == DISK_STOP
        and plan["disk_admission_bytes"] == DISK_START
        and plan["deadline_seconds"] == DEADLINE,
        "resource plan differs from reviewed profile",
    )
    need(not recursive_errors(result), "supervisor reported infrastructure error")
    need(
        result["id"] == "r4-native"
        and result["argv"]
        == ["/usr/bin/sandbox-exec", "-f", str(case / "sandbox.sb"), *plan["argv"]]
        and result["cwd"] == str(PRODUCT),
        "actual command differs",
    )
    need(
        result["complete"] is True and result["process_group_gone"] is True,
        "supervisor did not reap process group",
    )
    aborted = result["aborted_reason"]
    if aborted is None:
        need(result["termination_signal"] is None, "unexpected termination signal")
        need(
            (result["return_code"] == 0 and result["status"] == "passed")
            or (result["return_code"] != 0 and result["status"] == "command_failed"),
            "normal status/exit mismatch",
        )
    else:
        need(
            result["status"] == "resource_limit_abort"
            and aborted in {"sampled_process_tree_rss_cap", "disk_floor", "overall_wall_cap"},
            "unqualified supervisor abort",
        )
    samples_path = case / "process-tree.jsonl"
    samples = [json.loads(line) for line in samples_path.read_bytes().splitlines()]
    need(
        bool(samples) and len(samples) == result["sample_count"],
        "sample denominator differs",
    )
    peak = 0
    minimum = result["disk_free_before_bytes"]
    need(minimum >= DISK_START, "disk admission absent")
    times = []
    parent_seen = False
    for position, sample in enumerate(samples):
        need(
            sample["kind"] == "sample" and sample["command_id"] == result["id"],
            "sample identity mismatch",
        )
        processes = sample["processes"]
        need(
            isinstance(processes, list)
            and all(type(p["rss_kib"]) is int and p["rss_kib"] >= 0 for p in processes),
            "invalid RSS samples",
        )
        rss = sum(p["rss_kib"] * 1024 for p in processes)
        need(rss == sample["sampled_process_tree_rss_bytes"], "sample RSS sum mismatch")
        if position != len(samples) - 1 or aborted is None:
            need(
                rss <= RSS_CAP and sample["disk_free_bytes"] >= DISK_STOP,
                "unreported resource breach",
            )
        peak = max(peak, rss)
        minimum = min(minimum, sample["disk_free_bytes"])
        times.append(sample["elapsed_command_seconds"])
        parent_seen |= any(p["pid"] == result["pid"] for p in processes)
    need(
        parent_seen and times == sorted(times) and min(times) >= 0,
        "sample process/time mismatch",
    )
    need(
        peak == result["max_sampled_process_tree_rss_bytes"]
        and minimum == result["minimum_sampled_disk_free_bytes"],
        "supervisor aggregate mismatch",
    )
    need(0 <= result["wall_seconds"] <= DEADLINE + 10, "unexplained wall duration")
    if aborted == "sampled_process_tree_rss_cap":
        need(
            samples[-1]["sampled_process_tree_rss_bytes"] > RSS_CAP,
            "RSS abort lacks deciding sample",
        )
    if aborted == "disk_floor":
        need(
            samples[-1]["disk_free_bytes"] < DISK_STOP,
            "disk abort lacks deciding sample",
        )
    for name, kind_key, finish in (
        ("controller-events.jsonl", "kind", "command_finish"),
        ("phase-output.jsonl", "phase", "finish"),
    ):
        rows = [json.loads(line) for line in (case / name).read_bytes().splitlines()]
        matches = [
            row for row in rows if row.get(kind_key) == finish and row.get("id") == result["id"]
        ]
        need(
            len(matches) == 1
            and matches[0]["status"] == result["status"]
            and matches[0]["return_code"] == result["return_code"]
            and matches[0]["aborted_reason"] == aborted,
            "supervisor finish record mismatch",
        )
    return {
        "status": result["status"],
        "aborted_reason": aborted,
        "samples": len(samples),
        "sample_sha256": checks.sha_file(samples_path),
        "sampled_peak_rss_bytes": peak,
        "minimum_sampled_disk_free_bytes": minimum,
        "wall_seconds": result["wall_seconds"],
        "scope": "sampled process tree only; not continuous machine maximum",
    }


def qualify_parent(case: Path, plan: dict, result: dict, retained) -> dict:
    parent_dir = case / "evidence/parent"
    obs = json.loads((parent_dir / "parent-process.json").read_bytes())
    head, tree = plan["source_head"], plan["source_tree"]
    need(
        obs["stage"] == "pytest_finished" and obs["source"] == obs["source_after"] == [head, tree],
        "parent source/stage differs",
    )
    need(
        obs["pytest_not_yet_imported"] is True
        and obs["initial_private_pycache_empty"] is True
        and obs["sys_pycache_prefix"] == str(case / "pycache"),
        "parent startup mismatch",
    )
    need(
        obs["argv"] == plan["argv"][2:] and obs["collected_node_ids_after_deselection"] == [NODE],
        "selected node/argv mismatch",
    )
    need(
        obs["pytest"]["importmode"] == "importlib"
        and "--strict-markers" in obs["pytest"]["ini_addopts"],
        "pytest profile differs",
    )
    need(
        Path(obs["pytest"]["inipath"]).resolve() == (PRODUCT / "pytest.ini").resolve(),
        "pytest ini differs",
    )
    need(
        obs["environment"]["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] is None
        and not obs["environment"]["PYTEST_ADDOPTS"],
        "pytest ambient controls persisted",
    )
    need(
        obs["environment"]["PYTHONDONTWRITEBYTECODE"] == "1"
        and obs["environment"]["PYTHONPYCACHEPREFIX"] == str(case / "pycache")
        and all(
            obs["environment"][key] == "1"
            for key in (
                "OMP_NUM_THREADS",
                "OPENBLAS_NUM_THREADS",
                "MKL_NUM_THREADS",
                "NUMEXPR_NUM_THREADS",
            )
        ),
        "parent process environment differs",
    )
    need(
        obs["pid"] == result["pid"] == obs["pytest"]["pid"]
        and Path(obs["executable"]).resolve() == PYTHON.resolve(),
        "actual interpreter/PID differs",
    )
    need(obs["pytest_exitstatus"] == result["return_code"], "pytest exit differs")
    index = retained.selected_git_tree(head)
    readset = retained.qualify_readset(
        obs,
        parent_dir,
        index,
        {
            "tests/_helpers/e02_c96_control_harness.py",
            "tests/_helpers/r4_native_fit_observer.py",
            NODE.split("::")[0],
        },
    )
    cases = list(ET.parse(case / "junit.xml").getroot().iter("testcase"))
    need(
        len(cases) == 1 and cases[0].get("name") == NODE.split("::")[-1],
        "JUnit node differs",
    )
    return {
        "pid": obs["pid"],
        "versions": obs["versions"],
        "readset": readset,
        "observation_sha256": checks.sha_file(parent_dir / "parent-process.json"),
        "junit": {
            "skipped": cases[0].find("skipped") is not None,
            "failure": cases[0].find("failure") is not None,
            "error": cases[0].find("error") is not None,
        },
    }


def require_default_seed_profile(admitted_intent: dict, method: dict) -> None:
    """Require the omitted override and the persisted server-owned seed policy."""
    submitted = method["launch"]["request_body"]["observational_input"]["method"]["params"]
    need(
        "random_state" not in submitted
        and type(admitted_intent.get("seed")) is int
        and admitted_intent["seed"] == 0
        and admitted_intent.get("seed_policy_revision") == "server_seed_zero_v1",
        "submitted override or persisted seed policy differs",
    )


def qualify_case(case: Path, plan: dict, parent: dict, result: dict) -> dict:
    """Bind the real observation to the parent, backend and independent SQLite."""
    observation_path = case / "evidence/native/fixture-observation.json"
    observation = json.loads(observation_path.read_bytes())
    need(
        observation["schema"] == "policyos.e02.r4.native_forest_fit_cancel.v1",
        "observation schema differs",
    )
    process = observation["process"]
    need(
        process["pid"] == parent["pid"]
        and Path(process["executable"]).resolve() == PYTHON.resolve(),
        "fixture ran in another process/interpreter",
    )
    need(
        process["source"]["head"] == plan["source_head"]
        and process["source"]["tree"] == plan["source_tree"]
        and process["source"]["test_path"] == TEST
        and process["source"]["test_sha256"] == checks.sha_file(ROOT / TEST),
        "fixture source differs",
    )
    case_info = observation["case"]
    need(case_info["test_nodeid"] == NODE, "fixture node differs")
    backend = case_info["verdict"]["backend_load"]
    base = {
        "parent": parent,
        "observation_sha256": checks.sha_file(observation_path),
        "backend_load": backend,
        "fixture_stage": case_info["stage"],
    }
    if backend == "UNAVAILABLE":
        return {
            "state": "ENVIRONMENT_ERROR",
            "semantic": "UNRUN",
            "reason": "backend load unavailable",
            **base,
        }
    early_stages = {
        "public_admission_refused",
        "worker_lease_not_observed",
        "dispatch_finished_without_method",
        "peer_not_observed",
        "method_finished_before_tree",
        "tree_entry_not_observed",
        "saturation_premise_missing",
        "live_renewal_premise_missing",
        "fit_finished_before_negatives",
        "fit_finished_during_negative_controls",
        "fit_finished_before_cancel",
        "fit_finished_during_cancel",
        "negative_snapshot_changed_during_live_attempt",
        "insufficient_live_overlap",
    }
    if case_info["stage"] in early_stages:
        if case_info["stage"] == "dispatch_finished_without_method":
            teardown = observation.get("teardown", {})
            errors = observation.get("result", {}).get("handler_errors", [])
            partial_job = observation.get("final", {}).get("snapshot", {}).get("job_row")
            if (
                teardown.get("outcome") != "naturally_settled"
                or observation.get("errors")
                or errors
            ):
                return {
                    "state": "ERROR",
                    "semantic": "UNRUN",
                    "reason": "dispatch ended before method submission; actual error or teardown retained",
                    "handler_errors": errors,
                    "observation_errors": observation.get("errors", []),
                    "teardown": teardown,
                    "job_state": partial_job.get("state")
                    if isinstance(partial_job, dict)
                    else None,
                    **base,
                }
        failure = observation.get("result", {}).get("shared_execution_failure")
        outcome = observation.get("result", {}).get("shared_execution_outcome")
        unsuccessful_outcome = isinstance(outcome, dict) and outcome.get(
            "candidate_status"
        ) not in (None, "success")
        if failure is not None or unsuccessful_outcome:
            partial_job = observation.get("final", {}).get("snapshot", {}).get("job_row")
            return {
                "state": "ERROR",
                "semantic": "NOT_ESTABLISHED",
                "reason": "actual shared method failure before the native witness",
                "shared_execution_failure": failure,
                "shared_execution_outcome": outcome,
                "job_state": partial_job.get("state") if isinstance(partial_job, dict) else None,
                "scope": "actual fixture-observed typed completion; no inferred failure cause",
                **base,
            }
        return {
            "state": "INCONCLUSIVE",
            "semantic": "UNRUN",
            "reason": case_info["stage"],
            "partial_observation_scope": "raw fixture observations retained; no positive property inferred",
            **base,
        }
    need(backend == "PASS", "backend load not established")
    native_files = checks.verify_loaded_origins(observation["native"], PRODUCT / ".venv")
    need(
        observation["native"]["econml_version"]
        == plan["external_environment"]["package_metadata"]["econml"]["version"],
        "loaded EconML version differs from installed metadata",
    )
    need(
        case_info["stage"] == "complete",
        "fixture did not reach complete evidence collection",
    )
    need(not observation["errors"], "fixture instrumentation error")
    handler_errors = observation["result"]["handler_errors"]
    need(isinstance(handler_errors, list), "handler error list malformed")
    teardown = observation["teardown"]
    need(
        teardown["outcome"] == "naturally_settled"
        and not any(
            teardown[key] for key in ("dispatch_alive", "method_busy", "queued_busy", "peer_busy")
        ),
        "actual worker/follower/peer drain not established",
    )
    method = observation["method"]
    source = observation["input"]
    catalog = observation["catalog"]
    need(
        catalog["selected_database_path"] == catalog["served_database_path"]
        and catalog["selected_snapshot_root"] == catalog["served_snapshot_root"]
        and Path(catalog["served_database_path"])
        .resolve(strict=True)
        .is_relative_to(case.resolve(strict=True))
        and Path(catalog["served_snapshot_root"])
        .resolve(strict=True)
        .is_relative_to(case.resolve(strict=True)),
        "served catalog is not the selected case-owned source",
    )
    input_custody = checks.source_custody(source, case, expected_rows=8000)
    intent_custody = checks.intent_custody(observation, case)
    admitted_intent, _ = checks.selected_cas(
        method["work_descriptor"]["observational_run_intent_ref"], method["intent_cas"], case
    )
    require_default_seed_profile(admitted_intent, method)
    required_params = {
        "n_estimators": 512,
        "cv_folds": 2,
        "subforest_size": 4,
        "random_state": None,
        "n_jobs": 1,
    }
    need(
        source["source_kind"] == "ir.observation_method_input"
        and source["rows"] == 8000
        and source["sample_ids_unique"] is True
        and source["source_authority"] == "fixture_synthetic_candidate"
        and isinstance(source["source_ref"], dict)
        and bool(source["source_ref"])
        and isinstance(source["payload_file_sha256"], str)
        and len(source["payload_file_sha256"]) == 64,
        "synthetic input not established",
    )
    need(
        method["requested_fqn"] == method["effective_fqn"] == "causal.hte.forest_dr@1.1.0"
        and all(
            k in method["effective_params"] and method["effective_params"][k] == v
            for k, v in required_params.items()
        ),
        "actual method/profile differs",
    )
    need(
        bool(method["resource_policy_ref"])
        and isinstance(method["resource_policy_digest"], str)
        and len(method["resource_policy_digest"]) == 64,
        "resource policy binding missing",
    )
    need(
        bool(method["job_id"])
        and bool(method["run_id"])
        and bool(method["lease_owner"])
        and type(method["attempt"]) is int
        and method["attempt"] > 0,
        "job/lease identity missing",
    )
    descriptor = method["work_descriptor"]
    need(
        (descriptor["job_id"], descriptor["run_id"], descriptor["attempt"])
        == (method["job_id"], method["run_id"], method["attempt"])
        and descriptor["requested_source_ref"] == source["source_ref"]
        and bool(descriptor["observational_run_intent_ref"]),
        "real work descriptor/source identity differs",
    )
    executor = observation["executor"]
    queue = executor["queue"]
    need(
        executor["profile"]["capacity"] == 2 and executor["profile"]["queue_capacity"] == 2,
        "actual executor profile differs from admitted capacity-two witness",
    )
    saturation = checks.saturation_premise(observation)
    if not saturation["passed"]:
        return {
            "state": "INCONCLUSIVE",
            "semantic": "UNRUN",
            "reason": "actual capacity-two saturation premise not established",
            "saturation": saturation,
            "input_custody": input_custody,
            "intent_custody": intent_custody,
            "loaded_backend_origins": native_files,
            **base,
        }
    renewals = observation["lease"]["renewals"]
    forest_fit_start = observation["native"]["forest_dr_fit_events"][0]["monotonic_ns"]
    queue_full_ns = queue["full_observed_ns"]
    if not (
        type(queue_full_ns) is int
        and forest_fit_start < queue_full_ns < observation["cancel"]["post_start_ns"]
    ):
        return {
            "state": "INCONCLUSIVE",
            "semantic": "UNRUN",
            "reason": "queue-full timing premise not established",
            **base,
        }
    good = [
        row
        for row in renewals
        if row["result"] is True
        and row["fresh_owner"] == method["lease_owner"]
        and row["fresh_attempt"] == row["expected_attempt"] == method["attempt"]
        and max(forest_fit_start, queue_full_ns)
        < row["monotonic_ns"]
        < observation["cancel"]["post_start_ns"]
    ]
    good.sort(key=lambda row: row["monotonic_ns"])
    renewals_established = (
        len(good) >= 2
        and len({row["monotonic_ns"] for row in good}) >= 2
        and all(
            a["fresh_lease_expires_at"] <= b["fresh_lease_expires_at"]
            for a, b in zip(good, good[1:])
        )
        and good[0]["fresh_lease_expires_at"] < good[-1]["fresh_lease_expires_at"]
    )
    if not renewals_established:
        return {
            "state": "INCONCLUSIVE",
            "semantic": "UNRUN",
            "reason": "two renewed leases while real fit and queue were active not established",
            "eligible_renewals": len(good),
            **base,
        }
    negatives = checks.negative_checks(
        observation["negatives"],
        job_id=method["job_id"],
        run_id=method["run_id"],
        attempt=method["attempt"],
        owner=method["lease_owner"],
        positive_post_start_ns=observation["cancel"]["post_start_ns"],
    )
    cancel = observation["cancel"]
    need(
        cancel["url"] == f"/api/v1/control/jobs/{method['job_id']}/cancel"
        and urlsplit(cancel["request_url"]).path == cancel["url"]
        and cancel["request_body"].get("expected_lease_owner") == method["lease_owner"]
        and cancel["request_body"].get("expected_attempt") == method["attempt"]
        and bool(cancel["request_body"].get("operation_id")),
        "positive request identity differs",
    )
    authority = checks.positive_authority(cancel, method)
    if not authority["passed"]:
        return {
            "state": "INCONCLUSIVE",
            "semantic": "UNRUN",
            "reason": "exact current authority at the actual store entry not established",
            "authority": authority,
            **base,
        }
    durable = cancel["fresh_sqlite_readback"]
    need(
        executor["shared_execution_handle"]["captured"] is True
        and executor["shared_execution_handle"]["done_at_post_end"]
        is (not cancel["future_unfinished_at_response"]),
        "real execution handle observation differs",
    )
    snapshot = checks.protected_snapshot(durable["snapshot"])
    need(
        checks.snapshot_sha(snapshot) == durable["snapshot_sha256"],
        "durable snapshot hash differs",
    )
    row = snapshot["job_row"]
    need(
        (row["job_id"], row["run_id"], row["attempt"])
        == (method["job_id"], method["run_id"], method["attempt"]),
        "fresh durable job identity differs",
    )
    first_state = checks.qualified_first_cancel_state(
        row,
        durable.get("subsequent_job_read"),
        method,
        durable["verified_cancelled_record"],
        durable.get("verification_error"),
    )
    if first_state == "INCONCLUSIVE":
        return {
            "state": "INCONCLUSIVE",
            "semantic": "UNRUN",
            "reason": "the first post-read no longer establishes the same running attempt or a verified cancellation",
            "first_cancel_state": first_state,
            **base,
        }
    durable_checks = checks.cancellation_state(
        snapshot, method["job_id"], method["run_id"], method["attempt"]
    )
    durable_ok = durable_checks["passed"] and durable["verified_cancelled_record"] is True
    for field in ("authorized_actor", "tenant_id", "cell_id"):
        need(
            isinstance(cancel[field], str) and bool(cancel[field]),
            "cancellation authority identity missing",
        )
    bound_args = {
        "job_id": method["job_id"],
        "run_id": method["run_id"],
        "attempt": method["attempt"],
        "owner": method["lease_owner"],
        "tenant": cancel["tenant_id"],
        "cell": cancel["cell_id"],
        "actor": cancel["authorized_actor"],
        "request_body": cancel["request_body"],
        "request_wire_utf8": cancel["request_wire_utf8"],
    }
    durable_binding = checks.cancellation_binding(snapshot, **bound_args)
    durable_ok = durable_ok and durable_binding["passed"]
    need(
        all(
            row.get("state") == "cancelled"
            and error.get("type") == "ControlJobLeaseLostError"
            and type(error.get("monotonic_ns")) is int
            and error["monotonic_ns"] > cancel["actual_store_cancel_entry_ns"]
            for error in handler_errors
        ),
        "unexpected handler error; preserve actual details",
    )
    fresh = cancel["fresh_http_get"]
    body = fresh["body"] if isinstance(fresh.get("body"), dict) else {}
    progress = body.get("progress") if isinstance(body.get("progress"), dict) else {}
    cancellation = (
        progress.get("cancellation") if isinstance(progress.get("cancellation"), dict) else {}
    )
    fresh_ok = (
        fresh["method"] == "GET"
        and fresh["url"] == f"/api/v1/control/jobs/{method['job_id']}"
        and urlsplit(fresh["request_url"]).path == fresh["url"]
        and fresh["status_code"] == 200
        and body.get("job_id") == method["job_id"]
        and body.get("run_id") == method["run_id"]
        and body.get("state") == body.get("execution_status") == "cancelled"
        and body.get("physical_stop_status") == "not_established"
        and body.get("cancellation_disposition") == "publication_fenced"
        and cancellation.get("body_sha256") == durable_binding.get("wire_body_sha256")
    )
    retry = cancel["retry"]
    retry_body = retry["body"] if isinstance(retry.get("body"), dict) else {}
    retry_ok = (
        None
        if first_state != "PASS"
        else (
            retry["method"] == "POST"
            and retry["url"] == cancel["url"]
            and urlsplit(retry["request_url"]).path == retry["url"]
            and retry["request_body"] == cancel["request_body"]
            and retry["request_wire_utf8"] == cancel["request_wire_utf8"]
            and retry["status_code"] == 200
            and retry_body.get("job_id") == method["job_id"]
            and retry_body.get("run_id") == method["run_id"]
            and retry_body.get("state") == "cancelled"
            and retry_body.get("cancellation_disposition") == "publication_fenced"
        )
    )
    run_get = cancel["fresh_run_get"]
    run_body = run_get["body"]
    run = run_body.get("run") if isinstance(run_body, dict) else None
    run_projection = run.get("method_execution_selection") if isinstance(run, dict) else None
    run_identity = (
        run_get["method"] == "GET"
        and run_get["url"] == f"/api/v1/runs/{method['run_id']}"
        and urlsplit(run_get["request_url"]).path == run_get["url"]
        and run_get["status_code"] == 200
        and isinstance(run, dict)
        and run.get("run_id") == method["run_id"]
        and run.get("control_job_id") in (None, method["job_id"])
    )
    if (
        not run_identity
        or not isinstance(run_projection, dict)
        or run_projection.get("status") == "unavailable"
    ):
        run_surface = "NOT_ESTABLISHED"
    elif run_projection.get("status") == "selected" or run_projection.get("selection") is not None:
        run_surface = "FAIL"
    else:
        run_surface = "NO_SELECTED_PROJECTION_OBSERVED"
    need(
        observation["final"]["queued_body_entered_after_peer_release"] is True,
        "queued follower did not enter after peer release",
    )
    stale = checks.classify_stale_results(observation["final"]["stale_write_results"], durable_ok)
    need(stale["state"] != "ERROR", "unexpected exception from actual guarded stale write")
    need(
        checks.snapshot_sha(observation["final"]["snapshot"])
        == observation["final"]["snapshot_sha256"],
        "final snapshot hash differs",
    )
    need(
        Path(observation["final"]["database_path"]).resolve()
        == Path(cancel["database_path"]).resolve()
        == Path(observation["sqlite"]["database_path"]).resolve(),
        "fresh/final SQLite owner differs",
    )
    db = checks.sqlite_final(
        Path(observation["final"]["database_path"]),
        case,
        method["job_id"],
        method["run_id"],
        method["attempt"],
    )
    need(
        checks.protected_snapshot(observation["final"]["snapshot"])
        == {key: db[key] for key in ("job_row", "progress", "events", "outbox")},
        "fixture final snapshot differs from independent SQLite read",
    )
    final_row, final_events, final_outbox = db["job_row"], db["events"], db["outbox"]
    final_checks = checks.cancellation_state(
        db, method["job_id"], method["run_id"], method["attempt"]
    )
    final_ok = final_checks["passed"]
    final_binding = checks.cancellation_binding(db, **bound_args)
    final_ok = final_ok and final_binding["passed"]
    native = checks.native_overlap(observation)
    falsifier = checks.cheap_falsifier(observation)
    actual_post_ok = cancel["status_code"] == 200
    semantic_result = observation["result"]["candidate_outcome"]
    # The cancelled attempt must have no accepted selection. A fixture-reported
    # number is neither typed CAS evidence nor a numerical correctness claim.
    producer = {"state": "NOT_OBSERVED"}
    if semantic_result is not None:
        point = semantic_result.get("point_estimate") if isinstance(semantic_result, dict) else None
        producer = {
            "state": "NOT_QUALIFIED",
            "predicate_provenance": "consumer_asserted",
            "reported_point_is_finite": isinstance(point, (int, float))
            and not isinstance(point, bool)
            and math.isfinite(point),
            "reason": "typed result and CAS are not independently reconciled",
        }
    if parent["junit"]["error"] or parent["junit"]["skipped"]:
        raise ValueError("JUnit error/skip after completed observation")
    protected_ok = durable_ok and final_ok
    negative_states = [value["state"] for value in negatives.values()]
    live_premise = native.get("bounded_native_in_flight") == "PASS"
    observed_failure = (
        not actual_post_ok
        or not protected_ok
        or not fresh_ok
        or retry_ok is False
        or stale["state"] == "FAIL"
        or run_surface == "FAIL"
        or "FAIL" in negative_states
    )
    unestablished = (
        native["state"] != "PASS"
        or run_surface == "NOT_ESTABLISHED"
        or "INCONCLUSIVE" in negative_states
        or stale["state"] == "NOT_ESTABLISHED"
    )
    state = checks.classify_complete(
        native,
        observed_failure=observed_failure,
        unestablished=unestablished,
        junit_failure=parent["junit"]["failure"],
    )
    if state == "ERROR":
        raise ValueError("JUnit failed without a reconciled semantic failure")
    return {
        "state": state,
        "semantic": state,
        "native_activity": native,
        "durable_cancel": "PASS"
        if protected_ok
        else ("FAIL" if live_premise else "NOT_ESTABLISHED"),
        "durable_check": durable_checks,
        "durable_binding": durable_binding,
        "final_check": final_checks,
        "final_binding": final_binding,
        "fresh_run_surface": run_surface,
        "client_post_status": cancel["status_code"],
        "fresh_http": "PASS" if fresh_ok else ("FAIL" if live_premise else "NOT_ESTABLISHED"),
        "retry": "UNRUN"
        if retry_ok is None
        else "PASS"
        if retry_ok
        else ("FAIL" if live_premise else "NOT_ESTABLISHED"),
        "first_cancel_state": first_state,
        "current_authority": authority,
        "stale_guarded_writes": stale,
        "negative_controls": negatives,
        "saturation": saturation,
        "input_custody": input_custody,
        "intent_custody": intent_custody,
        "loaded_backend_origins": native_files,
        "final_sqlite": {
            "database": db["database"],
            "wal": db["wal"],
            "job_state": final_row["state"],
            "job_attempt": final_row["attempt"],
            "has_selection": final_row["method_execution_selection_json"] is not None,
            "job_events": len(final_events),
            "job_outbox": len(final_outbox),
        },
        "falsifier": falsifier,
        "producer_numeric_outcome": producer,
        "observed_handler_errors": handler_errors,
        **base,
    }


def output_rows(case: Path) -> list[dict]:
    """Inventory actual bounded case outputs, not environments or input copies."""
    result = []
    roots = [
        case / "r4-native.stdout.txt",
        case / "r4-native.stderr.txt",
        case / "junit.xml",
        case / "process-tree.jsonl",
        case / "controller-events.jsonl",
        case / "phase-output.jsonl",
        case / "evidence",
    ]
    for root in roots:
        paths = sorted(root.rglob("*")) if root.is_dir() else [root]
        for path in paths:
            if path.is_file() and not path.is_symlink():
                result.append(
                    {
                        "path": str(path.relative_to(ROOT)),
                        "bytes": path.stat().st_size,
                        "sha256": checks.sha_file(path),
                    }
                )
    return result


def external_environment() -> dict:
    """Bind interpreter and metadata only; this does not claim a backend loaded."""
    binary = PYTHON.resolve(strict=True)
    cfg = PRODUCT / ".venv/pyvenv.cfg"
    packages = {}
    for name in (
        "econml",
        "scikit-learn",
        "numpy",
        "scipy",
        "joblib",
        "threadpoolctl",
        "pytest",
        "lightgbm",
    ):
        try:
            distribution = importlib.metadata.distribution(name)
            metadata_members = [
                member
                for member in (distribution.files or ())
                if str(member).endswith(".dist-info/METADATA")
            ]
            metadata_path = (
                Path(distribution.locate_file(metadata_members[0])).resolve()
                if len(metadata_members) == 1
                else None
            )
            packages[name] = {
                "version": distribution.version,
                "metadata_path": str(metadata_path) if metadata_path else None,
                "metadata_bytes_sha256": checks.sha_file(metadata_path)
                if metadata_path and metadata_path.is_file()
                else None,
            }
        except importlib.metadata.PackageNotFoundError:
            packages[name] = {
                "version": "unavailable",
                "metadata_path": None,
                "metadata_bytes_sha256": None,
            }
    return {
        "interpreter": {
            "path": str(binary),
            "sha256": checks.sha_file(binary),
            "version": sys.version,
        },
        "pyvenv_cfg_sha256": checks.sha_file(cfg),
        "package_metadata": packages,
        "scope": "installed metadata only; loaded origins reconciled separately",
    }


def observe_environment() -> dict:
    values = {
        "disk_free_bytes": shutil.disk_usage(ROOT).free,
        "cpu_count": os.cpu_count(),
        "platform": platform.platform(),
    }
    for key, argv in [
        ("memory_pressure", ["/usr/bin/memory_pressure"]),
        ("memory_total", ["/usr/sbin/sysctl", "-n", "hw.memsize"]),
    ]:
        run = subprocess.run(argv, capture_output=True, text=True, check=False)
        values[key] = {
            "exit": run.returncode,
            "stdout": run.stdout,
            "stderr": run.stderr,
        }
    return values


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case-id", required=True)
    parser.add_argument("--admission", type=Path, required=True)
    parser.add_argument("--admission-sha256", required=True)
    parser.add_argument("--controller-sha256", required=True)
    parser.add_argument("--checks-sha256", required=True)
    args = parser.parse_args()
    need(
        sys.version_info[:2] == (3, 14)
        and sys.flags.isolated == 1
        and sys.dont_write_bytecode
        and Path(sys.prefix).resolve() == (PRODUCT / ".venv").resolve(),
        "use existing venv Python 3.14 -I -B",
    )
    need(
        checks.sha_file(Path(__file__)) == args.controller_sha256
        and checks.sha_file(CHECKS) == args.checks_sha256,
        "controller/checks hash differs",
    )
    for path, expected in (
        (SPEC, SPEC_SHA),
        (RETAINED, RETAINED_SHA),
        (GUARD, GUARD_SHA),
        (SUPERVISOR, SUPERVISOR_SHA),
    ):
        need(checks.sha_file(path) == expected, "retained input mismatch: " + str(path))
    git_controls = sorted(
        key
        for key in os.environ
        if key.startswith("GIT_") and key not in {"GIT_PAGER", "GIT_TERMINAL_PROMPT"}
    )
    need(not git_controls, "unsupported inherited Git controls")
    item = admission(
        args.admission,
        args.admission_sha256,
        args.controller_sha256,
        args.checks_sha256,
    )
    head, tree = item["source_head"], item["source_tree"]
    live = json.loads(LIVE.read_bytes())
    need(live["known_dirty_paths"] == [], "root reports dirty source")
    guard = runpy.run_path(str(GUARD))["guard"]
    before = guard()
    need(before["head"] == head and live["tree"] == tree, "live source guard mismatch")
    reference = json.loads(REFERENCE.read_bytes())
    fragment = reference["sandbox_profile_fragment"]
    need(sha(fragment.encode()) == FRAGMENT_SHA, "sandbox fragment mismatch")
    resources = observe_environment()
    external_before = external_environment()
    need(resources["disk_free_bytes"] >= DISK_START, "8 GiB disk admission unmet")
    inherited = sorted(
        key
        for key in os.environ
        if key.startswith(("PYTHON", "PYTEST", "POLISYOS_C96_")) or key == "VIRTUAL_ENV"
    )
    allowed = set(CLEAR) | {
        "PYTHONPYCACHEPREFIX",
        "PYTHONDONTWRITEBYTECODE",
        "PYTHONUNBUFFERED",
        "POLISYOS_C96_EVIDENCE_DIR",
        "POLISYOS_C96_EXPECTED_HEAD",
        "POLISYOS_C96_EXPECTED_TREE",
    }
    need(
        not [key for key in inherited if key not in allowed],
        "unknown Python/pytest/C96 control",
    )
    cleared = [key for key in CLEAR if key in os.environ]
    for key in CLEAR:
        os.environ.pop(key, None)
    retained = load(RETAINED, "r4_c96_retained")
    case = retained.reserve_case(PACKET, args.case_id)
    for name in ("pycache", "tmp", "benchmarks", "evidence"):
        (case / name).mkdir(mode=0o700)
    need(not any((case / "pycache").iterdir()), "private pycache not initially empty")
    profile = (
        "(version 1)\n(allow default)\n(deny file-write*)\n(allow file-write* (subpath "
        + json.dumps(str(case))
        + '))\n(allow file-write* (literal "/dev/null"))\n'
        + fragment
    )
    sandbox = case / "sandbox.sb"
    with sandbox.open("x") as stream:
        stream.write(profile)
    env = {
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONPYCACHEPREFIX": str(case / "pycache"),
        "TMPDIR": str(case / "tmp"),
        "XDG_CACHE_HOME": str(case / "tmp/xdg"),
        "MPLCONFIGDIR": str(case / "tmp/mpl"),
        "NUMBA_CACHE_DIR": str(case / "tmp/numba"),
        "HYPOTHESIS_STORAGE_DIRECTORY": str(case / "tmp/hypothesis"),
        "POLISYOS_C96_EVIDENCE_DIR": str(case / "evidence"),
        "POLISYOS_C96_EXPECTED_HEAD": head,
        "POLISYOS_C96_EXPECTED_TREE": tree,
        "SCIENTIST_TORCH_NUM_THREADS": "1",
        "SCIENTIST_TORCH_NUM_INTEROP_THREADS": "1",
    }
    argv = [
        str(PYTHON),
        "-B",
        str(HARNESS),
        "--observe-pytest",
        "-q",
        "-ra",
        "-o",
        "cache_dir=" + str(case / "pytest-cache"),
        "--benchmark-storage=file://" + str(case / "benchmarks"),
        "--basetemp",
        str(case / "pytest-tmp"),
        "--junitxml",
        str(case / "junit.xml"),
        NODE,
    ]
    monitor = load(SUPERVISOR, "r4_native_supervisor")
    monitor.RSS_CAP_BYTES, monitor.DISK_FLOOR_BYTES, monitor.SAMPLE_SECONDS = (
        RSS_CAP,
        DISK_STOP,
        1.0,
    )
    signal.signal(signal.SIGTERM, monitor.note_stop_signal)
    signal.signal(signal.SIGINT, monitor.note_stop_signal)
    frame = ROOT / live["source_readback"]["path"]
    inputs = [
        SPEC,
        RETAINED,
        GUARD,
        SUPERVISOR,
        REFERENCE,
        LIVE,
        frame,
        args.admission,
        ROOT / item["review_path"],
        ROOT / item["draft_path"],
        ROOT / item["fixture_manifest_path"],
        Path(__file__),
        CHECKS,
    ]
    hashes = {str(path.relative_to(ROOT)): checks.sha_file(path) for path in inputs}
    plan = {
        "schema": "policyos.e02.r4.native-pilot-plan.v1",
        "created_at": datetime.now(UTC).isoformat(),
        "source_head": head,
        "source_tree": tree,
        "branch": BRANCH,
        "admission_sha256": args.admission_sha256,
        "review_path": item["review_path"],
        "review_sha256": item["review_sha256"],
        "selected_source_pins": item["source_pins"],
        "changed_paths_from_base": item["changed_paths_from_base"],
        "root_guard_before": before,
        "inputs": hashes,
        "argv": argv,
        "cwd": str(PRODUCT),
        "extra_env": env,
        "inherited_control_names_only": inherited,
        "cleared_control_names": cleared,
        "numeric_threads": monitor.NUMERIC_THREADS,
        "witness_profile": WITNESS_PROFILE,
        "sandbox_sha256": sha(profile.encode()),
        "sandbox_fragment_sha256": FRAGMENT_SHA,
        "sandbox_scope": "fixture localhost TCP exception includes wildcard bind; production_data denied",
        "resources_before": resources,
        "external_environment": external_before,
        "disk_admission_bytes": DISK_START,
        "disk_stop_bytes": DISK_STOP,
        "rss_cap_bytes": RSS_CAP,
        "deadline_seconds": DEADLINE,
        "numeric_job_exclusivity": "coordinator_asserted_and_manually_checked",
        "closure_ids": [],
    }
    plan_sha = retained.write_json(case / "plan.json", plan)
    result, outcome, strict, errors, after = (
        {},
        {"state": "ERROR", "reason": "not launched"},
        None,
        [],
        None,
    )
    try:
        started = time.monotonic()
        result = monitor.run_command(
            case,
            "r4-native",
            ["/usr/bin/sandbox-exec", "-f", str(sandbox), *argv],
            PRODUCT,
            started,
            started + DEADLINE,
            env,
        )
        strict = strict_supervisor(case, result, plan)
        if result["aborted_reason"]:
            outcome = {
                "state": "RESOURCE_ABORT",
                "semantic": "UNRUN",
                "reason": result["aborted_reason"],
            }
        else:
            parent = qualify_parent(case, plan, result, retained)
            outcome = qualify_case(case, plan, parent, result)
    except BaseException as exc:
        errors.extend([type(exc).__name__ + ": " + str(exc), traceback.format_exc()])
    try:
        after = guard()
        need(
            after["head"] == head
            and git("rev-parse", "HEAD^{tree}").decode().strip() == tree
            and not git("status", "--porcelain", "--untracked-files=no"),
            "source moved during execution",
        )
        for pin in item["source_pins"]:
            need(tracked_pin(pin["path"], head) == pin, "selected source changed")
        for rel, digest in hashes.items():
            need(checks.sha_file(ROOT / rel) == digest, "consumed input changed: " + rel)
        need(
            external_environment() == external_before,
            "interpreter or package metadata changed during run",
        )
        need(
            checks.sha_file(case / "plan.json") == plan_sha
            and checks.sha_file(sandbox) == sha(profile.encode()),
            "plan/sandbox changed",
        )
    except BaseException as exc:
        errors.append("post-run identity: " + type(exc).__name__ + ": " + str(exc))
    if errors:
        outcome = {"state": "ERROR", "semantic": "UNRUN", "errors": errors}
    receipt = {
        "schema": "policyos.e02.r4.native-pilot-receipt.v1",
        "finished_at": datetime.now(UTC).isoformat(),
        "plan_sha256": plan_sha,
        "source_head": head,
        "source_tree": tree,
        "supervisor": result,
        "strict_supervisor": strict,
        "qualification": outcome,
        "root_guard_after": after,
        "outputs": output_rows(case),
        "disk_free_after_bytes": shutil.disk_usage(ROOT).free,
        "limitations": [
            "synthetic input and fixture authority",
            "loaded Python readset is finite; native event provenance is bounded by reviewed observer",
            "sampled RSS is not a continuous machine maximum",
            "no physical preemption or expiry/takeover established",
            "no production authority or G acceptance",
        ],
        "closure_ids": [],
    }
    receipt_sha = retained.write_json(case / "audit-result.json", receipt)
    print(
        json.dumps(
            {
                "case": str(case),
                "qualification": outcome,
                "receipt_sha256": receipt_sha,
            },
            sort_keys=True,
        )
    )
    return 0 if outcome["state"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
