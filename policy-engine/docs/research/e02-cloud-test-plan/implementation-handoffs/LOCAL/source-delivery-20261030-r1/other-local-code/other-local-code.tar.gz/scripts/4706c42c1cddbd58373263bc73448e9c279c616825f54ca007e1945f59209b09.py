"""Bind a short commission to normally published tracked witness files (RAW-only)."""
from __future__ import annotations

import argparse
import ast
import hashlib
import itertools
import json
import re
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
REL = 'policy-engine/tools/quality/testing/tc_sql_mc_witness'
NAMES = ['source_admit.py', 'measure.py', 'backend_probe.py', 'sitecustomize.py',
         'cloud_observer.py', 'run_case.py', 'pins.json', 'README.md']
COMPANION_PATH = 'policy-engine/tools/quality/testing/README.md'
COMPANION_EXPECTED_BYTES = 12456
COMPANION_EXPECTED_SHA256 = '9b9501c071cdb4d3b854a60b4e78fbaf0a6b9e9616600a351f7e913b6c08ba40'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    for key in ['root', 'commit', 'tree', 'ref', 'readback', 'readback-sha256', 'destination']:
        ap.add_argument('--' + key, required=True)
    a = ap.parse_args()
    root = Path(a.root).resolve()

    def git(*args):
        return subprocess.run(['git', *args], cwd=root, capture_output=True, check=True).stdout

    def body(path):
        return git('show', a.commit + ':' + path)

    if not all(re.fullmatch('[0-9a-f]{40}', value) for value in [a.commit, a.tree]):
        raise SystemExit('full immutable source identities required')
    if not a.ref.startswith('refs/heads/codex/'):
        raise SystemExit('author codex topic ref required')
    receipt_bytes = Path(a.readback).read_bytes()
    if sha(receipt_bytes) != a.readback_sha256:
        raise SystemExit('readback hash mismatch')
    receipt = json.loads(receipt_bytes)
    if tuple(receipt.get(key) for key in ['remote_ref', 'head', 'tree', 'remote_head', 'remote_tree']) != (a.ref, a.commit, a.tree, a.commit, a.tree):
        raise SystemExit('actual local/remote receipt identities mismatch')
    if git('rev-parse', a.commit + '^{tree}').decode().strip() != a.tree:
        raise SystemExit('Git source tree mismatch')
    changed = set(git('diff', '--name-only', receipt['previous_published'], a.commit).decode().splitlines())
    changed_rows = receipt['actual_changed_blob_readback']
    if len(changed_rows) != len({row['path'] for row in changed_rows}) or changed != {row['path'] for row in changed_rows}:
        raise SystemExit('complete changed-blob readback denominator mismatch')
    for row in changed_rows:
        data = body(row['path'])
        if (len(data), sha(data)) != (row['bytes'], row['sha256']):
            raise SystemExit('changed-blob content mismatch:' + row['path'])
    blobs = []
    for name in NAMES:
        path = REL + '/' + name
        data = body(path)
        if name.endswith('.py'):
            ast.parse(data)
        blobs.append({'path':path, 'bytes':len(data), 'sha256':sha(data),
                      'git_blob':git('rev-parse', a.commit + ':' + path).decode().strip()})
    # The ninth adoption path is documentation custody, not executable coverage.
    companion_bytes = body(COMPANION_PATH)
    if (len(companion_bytes), sha(companion_bytes)) != (COMPANION_EXPECTED_BYTES, COMPANION_EXPECTED_SHA256):
        raise SystemExit('mandatory parent README differs from reviewed adoption postimage:' + COMPANION_PATH)
    companion = {'path':COMPANION_PATH, 'bytes':len(companion_bytes),
                 'sha256':sha(companion_bytes),
                 'git_blob':git('rev-parse', a.commit + ':' + COMPANION_PATH).decode().strip(),
                 'role':'parent_discovery_documentation_companion',
                 'runtime_execution_claim':False}
    adoption_inputs = [*blobs, companion]
    if len(adoption_inputs) != 9 or len({row['path'] for row in adoption_inputs}) != 9:
        raise SystemExit('complete nine-path adoption footprint missing or duplicate')
    pins_bytes = body(REL + '/pins.json')
    pins = json.loads(pins_bytes)
    drift = []
    for row in pins['files']:
        actual = body(row['path'])
        blob = git('rev-parse', a.commit + ':' + row['path']).decode().strip()
        if (len(actual), sha(actual), blob) != (row['bytes'], row['sha256'], row['git_blob']):
            drift.append(row['path'])
    if drift:
        raise SystemExit('selected pins drift; normally regenerate on actual committed input and republish: ' + json.dumps(drift))
    nodes = pins['expected_nodes']
    pin_paths = {row['path'] for row in pins['files']}
    missing_conftests = []
    for path in {node.split('::')[0] for expected in nodes.values() for node in expected}:
        parent = Path('policy-engine') / Path(path).parent
        while parent.as_posix().startswith('policy-engine/'):
            conftest = (parent / 'conftest.py').as_posix()
            probe = subprocess.run(['git', 'cat-file', '-e', a.commit + ':' + conftest], cwd=root, capture_output=True)
            if probe.returncode == 0 and conftest not in pin_paths:
                missing_conftests.append(conftest)
            parent = parent.parent
    if missing_conftests:
        raise SystemExit('new applicable ancestor conftest outside tracked pins:' + json.dumps(sorted(set(missing_conftests))))
    for phase, expected in nodes.items():
        if phase == 'mc_refusal':
            selector = expected[0].split('[', 1)[0]
            path, name = selector.split('::')
            mod = ast.parse(body('policy-engine/' + path))
            fn = next(node for node in mod.body if isinstance(node, ast.FunctionDef) and node.name == name)
            axes = []
            for dec in reversed(fn.decorator_list):
                if len(dec.args) != 2 or dec.keywords:
                    raise SystemExit('MC custom IDs need fresh reviewed derivation')
                values = ast.literal_eval(dec.args[1])
                if any(type(value) is not str or not value.isascii() for value in values):
                    raise SystemExit('MC IDs outside bounded string derivation')
                axes.append(values)
            derived = [selector + '[' + '-'.join(values) + ']' for values in itertools.product(*axes)]
        elif phase == 'architecture':
            path = expected[0].split('::')[0]
            mod = ast.parse(body('policy-engine/' + path))
            derived = [path + '::' + node.name for node in mod.body if isinstance(node, ast.FunctionDef) and node.name.startswith('test_')]
        else:
            path, name = expected[0].split('::')
            mod = ast.parse(body('policy-engine/' + path))
            functions = [node for node in mod.body if isinstance(node, ast.FunctionDef) and node.name == name]
            if len(functions) != 1 or functions[0].decorator_list:
                raise SystemExit('selected function missing/parametrized:' + expected[0])
            derived = [path + '::' + name]
        if derived != expected:
            raise SystemExit('expected-node drift:' + phase)
    if {phase:len(expected) for phase, expected in nodes.items()} != {'sql_aba':1, 'sql_workflow':1, 'sql_purpose':1, 'architecture':3, 'mc_refusal':132, 'served':1}:
        raise SystemExit('139-case scope changed; review before commissioning')
    table = '\n'.join('| `' + row['path'] + '` | ' + str(row['bytes']) + ' | `' + row['sha256'] + '` | `' + row['git_blob'] + '` |' for row in blobs)
    companion_table = '| `' + companion['path'] + '` | ' + str(companion['bytes']) + ' | `' + companion['sha256'] + '` | `' + companion['git_blob'] + '` |'
    helper_checks = json.dumps({row['path']:row['sha256'] for row in adoption_inputs}, separators=(',', ':'))
    prompt = f'''# C148 — tracked TC/SQL/MC witness execution

Execution only. Do not delegate, change product/tests/config/lock/authority, install ad hoc packages, access private/production inputs, or launch other tasks. Source commit `{a.commit}`, tree `{a.tree}`, author ref `{a.ref}`. Root's actual remote readback receipt SHA-256 is `{a.readback_sha256}`. It reconciles actual head/tree/remote_head/remote_tree and changed blobs; no publication boolean is substituted. A matching source on `work`/detached HEAD without origin is valid. No ls-remote, reclone, source switch/reset/stash or network workaround.

C134's full 139 cases remained UNRUN after missing-file helper preflight. Its four matching helpers and pins were returned; no backend ERROR, semantic FAIL, or proven network/interface cause resulted. This task removes message copying: execute the tracked helper source directly. Read AGENTS.md, CONTRIBUTING.md, the failure-pattern register, and the exact tracked README below. That README is the complete command, resource, backend, observation, return and limitation recipe; it is an available immutable source input, not an external RAW dependency. Preserve all R17/R19/R20 historical result scopes described there. No 373-case rerun; no G acceptance/closure.

Require actual HEAD/tree above before any helper import. Set the following from this dispatch and follow the README's commands; a variable is not permission to substitute another source or output:

```sh
E02C_ROOT="$(git rev-parse --show-toplevel)"
E02C_COMMIT={a.commit}
E02C_TREE={a.tree}
E02C_HARNESS="$E02C_ROOT/{REL}"
E02C_PINS_SHA={sha(pins_bytes)}
E02C_OUT="$E02C_ROOT/policy-engine/docs/research/e02-cloud-test-plan/implementation-handoffs/tc-sql-mc-c148-cloud-r1"
export E02C_ROOT E02C_COMMIT E02C_TREE E02C_HARNESS E02C_PINS_SHA E02C_OUT
```

First verify actual working and index bytes for all nine adoption inputs and every selected pin against their immutable Git objects and this table using standard-library Python. Retain the exact checking argv/code, full stdout/stderr/exit and initial source receipt in the new nonignored output. If a file is absent/corrupt/unreadable, retain that explicit failure and keep dependent work UNRUN. Do not recreate code from a message, create replacement hashes, or infer a backend failure. The check below is source-only; run it before putting the helper directory on PYTHONPATH:

```sh
if [ -e "$E02C_OUT" ]; then printf 'output path collision\\n' >&2; exit 1; fi
mkdir -p "$(dirname "$E02C_OUT")"
mkdir "$E02C_OUT"
mkdir "$E02C_OUT/commands" "$E02C_OUT/origins" "$E02C_OUT/observations"
python3 -B - <<'E02_TRACKED_CHECK' >"$E02C_OUT/commands/tracked-inputs.stdout" 2>"$E02C_OUT/commands/tracked-inputs.stderr"
import datetime, hashlib, json, os, pathlib, subprocess
root = pathlib.Path(os.environ['E02C_ROOT'])
commit, tree = os.environ['E02C_COMMIT'], os.environ['E02C_TREE']
def git(*args):
    return subprocess.run(['git', *args], cwd=root, check=True, capture_output=True).stdout
actual_head = git('rev-parse', 'HEAD').decode().strip()
actual_tree = git('rev-parse', 'HEAD^{{tree}}').decode().strip()
branch = subprocess.run(['git', 'symbolic-ref', '-q', '--short', 'HEAD'], cwd=root, capture_output=True, text=True)
start = {{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head':actual_head,
          'tree':actual_tree, 'branch':branch.stdout.strip() if branch.returncode == 0 else 'DETACHED',
          'state':'STARTED; tests UNRUN'}}
(pathlib.Path(os.environ['E02C_OUT']) / '00-start.json').write_text(json.dumps(start, indent=2) + '\\n')
assert actual_head == commit
assert actual_tree == tree
expected = {helper_checks}
for path, digest in expected.items():
    actual = (root / path).read_bytes()
    assert actual == git('show', commit + ':' + path), path
    assert actual == git('show', ':' + path), 'index:' + path
    assert hashlib.sha256(actual).hexdigest() == digest, path
    print(digest, len(actual), path)
pins = json.loads((root / '{REL}/pins.json').read_bytes())
for pin in pins['files']:
    path = pin['path']
    actual = (root / path).read_bytes()
    assert actual == git('show', commit + ':' + path), 'working:' + path
    assert actual == git('show', ':' + path), 'index:' + path
    assert len(actual) == pin['bytes'], path
    assert hashlib.sha256(actual).hexdigest() == pin['sha256'], path
    print(pin['sha256'], len(actual), path)
E02_TRACKED_CHECK
tracked_exit=$?
printf '%s\\n' "$tracked_exit" >"$E02C_OUT/commands/tracked-inputs.exit"
if [ "$tracked_exit" -ne 0 ]; then exit "$tracked_exit"; fi
```

Then use the README's actual source-admission command, backend probe, measurement and six serialized commands with fresh scratch. The eight nested runtime/recipe inputs are distinct from the ninth parent README discovery companion. Both sets are admitted by actual Git/working/index bytes. The parent README identity proves the reviewed discovery-link postimage was published; it is documentation custody, not a claim that README code executes. All six helpers are tracked inputs; copy only the tracked pins.json to output with a normal byte copy. The pins' original derivation is `{pins['commit']}`; Root's late binder separately reconciled every selected path/length/hash/blob and complete expected-node set against this dispatch commit. Matching actual bytes are required again in Cloud.

Scope is exactly 139: sql_aba 1, sql_workflow 1, sql_purpose 1, architecture 3, mc_refusal 132, served 1. Preserve complete stdout/stderr/JUnit/observer/origin/command evidence and per-phase setup/call/teardown outcomes. The real pytest collection must exactly match tracked expected nodes; collection/markers/proxy exit codes do not prove runtime assertions. Missing dependency, loopback denial, resource stop or missing observations stays scoped ERROR/UNRUN, never product FAIL/PASS. Establish the compact actual managed output path with complete preflight bytes before expensive execution; no mid-run coordinator acknowledgement is needed.

Return modest complete deciding output through ordinary managed diff/snapshot, deterministic individual gzip when needed with byte-exact decompression hashes. No CAS/DB/fixture/source/environment archives, private keys, uploads, CI workflows or encoded fragments. Recheck source and named pins after phases. Root must retrieve/hash the actual bytes before claiming delivery. Tests, source qualification, transport and broad authority remain distinct; G_acceptance=false.

| Eight nested runtime/recipe inputs | Bytes | SHA-256 | Git blob |
| --- | ---: | --- | --- |
{table}

| Ninth adoption companion (documentation only) | Bytes | SHA-256 | Git blob |
| --- | ---: | --- | --- |
{companion_table}
'''
    destination = Path(a.destination).resolve()
    if not destination.is_relative_to(HERE):
        raise SystemExit('destination must stay under this RAW proposal')
    destination.mkdir(parents=True, exist_ok=False)
    (destination / 'prompt.md').write_text(prompt)
    result = {'status':'BOUND_PENDING_INDEPENDENT_REVIEW', 'commit':a.commit, 'tree':a.tree,
              'ref':a.ref, 'readback_sha256':a.readback_sha256,
              'prompt_sha256':sha(prompt.encode()), 'prompt_bytes':len(prompt.encode()),
              'inputs':blobs, 'runtime_recipe_input_count':len(blobs),
              'adoption_inputs':adoption_inputs, 'adoption_footprint_count':len(adoption_inputs),
              'documentation_companion':companion,
              'pins_derivation_commit':pins['commit'],
              'selected_pins_requalified':len(pins['files']), 'expected_cases':139,
              'runtime_status':'UNRUN', 'cloud_launched':False}
    (destination / 'manifest.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
