"""Selected executed-code/source admission; global bootstrap unknowns stay explicit."""
from __future__ import annotations
import hashlib
from pathlib import Path
from typing import Any


def qualify_capture(value: dict[str, Any], root: Path, index: dict[str, str], overlay: str, overlay_sha: str) -> list[str]:
    """Qualify authenticated selected starts, not whole-Python attestation."""
    report = value.get('bounded_code_capture')
    if not isinstance(report,dict):return ['bounded capture absent']
    rows=report.get('codes');selected=report.get('observed_selected_first_start_codes')
    if not isinstance(rows,list) or not isinstance(selected,list):return ['actual code/selected sets absent']
    problems=[]
    if report.get('pid')!=value.get('process',{}).get('pid'):problems.append('capture PID mismatch')
    if report.get('selected_observation_mode')!='first_start' or report.get('selected_return_callbacks')!=0:problems.append('capture is not exclusive first-start mode')
    if report.get('errors')!=[]:problems.append('capture dispatcher/consumer errors')
    if report.get('distinct_captured_codes')!=len(rows):problems.append('captured set denominator differs')
    # Concurrent initial callbacks can precede DISABLE propagation; no exact callback/set equality claim.
    if type(report.get('callback_invocations')) is not int or report['callback_invocations']<len(rows):problems.append('callback denominator malformed')
    all_rows={(r.get('relative_path'),r.get('qualname'),r.get('module'),r.get('code_sha256')) for r in rows if isinstance(r,dict)}
    files={}
    # All captured readable checkout sources retain the byte/Git admission gate.
    # Non-target code-generation/global-identity failures remain recorded unknowns.
    for row in rows:
        if not isinstance(row,dict):problems.append('captured row malformed');continue
        rel=row.get('relative_path')
        if not isinstance(rel,str) or not rel.startswith(('policy-engine/src/','policy-engine/tests/','policy-engine/tools/')):continue
        path=root/rel
        if not path.is_file():problems.append('captured checkout source disappeared');continue
        if rel not in files:
            data=path.read_bytes();files[rel]=(hashlib.sha256(data).hexdigest(),hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data,usedforsecurity=False).hexdigest())
        sha,blob=files[rel]
        expected=blob if rel==overlay and sha==overlay_sha else index.get(rel)
        if row.get('source_sha256')!=sha or row.get('git_blob')!=blob or row.get('expected_blob')!=expected or expected!=blob:problems.append('captured checkout source bytes/Git differ')
    for row in selected:
        if not isinstance(row,dict):problems.append('selected code row malformed');continue
        if (row.get('relative_path'),row.get('qualname'),row.get('module'),row.get('code_sha256')) not in all_rows:problems.append('selected row not in actual captured set')
        if row.get('selected_first_start_consumed') is not True or row.get('compilation_match') is not True or row.get('origin_error'):problems.append('selected start source/code/consumer not established')
        rel=row.get('relative_path')
        if not isinstance(rel,str) or Path(rel).is_absolute() or '..' in Path(rel).parts or not rel.startswith(('policy-engine/src/','policy-engine/tests/','policy-engine/tools/')):
            problems.append('selected code path outside source roots');continue
        path=root/rel
        if path.is_symlink() or not path.is_file():problems.append('selected source unavailable');continue
        if rel not in files:
            data=path.read_bytes();files[rel]=(hashlib.sha256(data).hexdigest(),hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data,usedforsecurity=False).hexdigest())
        sha,blob=files[rel];expected=blob if rel==overlay and sha==overlay_sha else index.get(rel)
        if row.get('source_sha256')!=sha or row.get('git_blob')!=blob or row.get('expected_blob')!=expected or blob!=expected:problems.append('selected actual source/Git binding differs')
        if Path(str(row.get('resolved_path',''))).resolve()!=path.resolve():problems.append('selected code resolved path differs')
    return problems


def qualify_positive_child(value: dict[str, Any]) -> list[str]:
    """Bind every commissioned target frame to the same captured CodeType/PID."""
    transport='tests.unit.scientist.orchestration.engine.runner.decimal_worker_transport'
    worker='polisyos.scientist.orchestration.engine.runner._activity_worker'
    wire='polisyos.scientist.orchestration.engine.runner.serialization'
    required={(transport,'execute_decimal_worker'),(transport,'DecimalTransportNode.execute'),
              (worker,'run_node_in_worker_sync'),(worker,'run_node_in_worker'),
              (wire,'deserialize_state'),(wire,'serialize_outcome')}
    report=value.get('bounded_code_capture',{});pid=value.get('process',{}).get('pid')
    selected={row.get('process_local_code_object_id'):row for row in report.get('observed_selected_first_start_codes',[]) if isinstance(row,dict)}
    bound=set();problems=[]
    for frame in value.get('target_code_frames',[]):
        key=(frame.get('module'),frame.get('qualname'))
        if key not in required:continue
        row=selected.get(frame.get('code_object_id_process_local'))
        if not isinstance(row,dict) or frame.get('pid')!=pid or frame.get('same_process_function_code_identity') is not True or row.get('selected_first_start_consumed') is not True or row.get('compilation_match') is not True or row.get('origin_error'):
            problems.append('required target lacks same-process authenticated first-start CodeType');continue
        if key!=(row.get('module'),row.get('qualname')) or frame.get('repo_path')!=row.get('relative_path'):
            problems.append('target/capture source identity diverged');continue
        bound.add(key)
    if bound!=required:problems.append('six commissioned child targets not established')
    return problems
