"""Audit-only runner: native pytest, retained outputs, no canonical writes."""
from pathlib import Path
import datetime, hashlib, importlib.util, json, os, runpy, shutil, signal, subprocess, sys, time, xml.etree.ElementTree as ET
from external_admission import external_existing_dir, external_existing_file, fresh, no_symlink_components, fixture_snapshot
R=Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
P=R/"policy-engine"
N=P/"docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1"
D=N/"deep-task-status-audit-20261027-r1"
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
save=lambda p,d: p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+"\n")
assert len(sys.argv)==4, "usage: runner ABS_PLAN EXPECTED_SHA256 ABS_CASE_PARENT"
plan_path=external_existing_file(sys.argv[1],R)
O=external_existing_dir(sys.argv[3],R)
assert plan_path.parent==O and sha(plan_path)==sys.argv[2]
plan=json.loads(plan_path.read_text()); case=plan["case_id"]
assert case and all(c.isalnum() or c in "-_" for c in case)
assert plan["case_parent"]==str(O) and plan_path.name==case+".json"
out=O/case
fresh(out,O)
guard=runpy.run_path(str(N/"root-layer-lib.py"))["guard"]; before=guard()
assert before["head"]==plan["source_head"]
assert subprocess.check_output(["git","-C",str(R),"rev-parse","HEAD^{tree}"],text=True).strip()==plan["source_tree"]
assert plan["disk_stop_bytes"]==6*1024**3 and plan["disk_admission_bytes"]>=7*1024**3
assert shutil.disk_usage(R).free>=plan["disk_admission_bytes"]
assert set(plan["extra_env"])=={"CORR_C_WORLD_CAS","CORR_C_WORLD_REF","CORR_C_WORLD_HASH","CORR_C_L6_SOURCE_ROOT","CORR_C_L6_SOURCE_HASH"}
assert all(isinstance(v,str) and v for v in plan["extra_env"].values())
assert plan["unset_env"]==["CORR_C2_LEGACY_EFFECT_BRIDGE_PATH"]
assert plan["sandbox_profile_fragment_sha256"]=="8a6be8cb31b30ca548403086bc33be95c8db32d367aa9f5658a57c8925ba9dc6"
for rel, expected in plan["harness_sha256"].items():
 path=R/rel; assert not Path(rel).is_absolute() and ".." not in Path(rel).parts
 no_symlink_components(path); assert sha(path)==expected,rel
for name in ("CORR_C_WORLD_CAS","CORR_C_L6_SOURCE_ROOT"):
 external_existing_dir(plan["extra_env"][name],R)
assert fixture_snapshot(plan["candidate_fixture_root"],R)==plan["candidate_fixture_files"],"candidate input fixture census mismatch"
for rel, expected in plan["additional_input_sha256"].items():
 path=R/rel; assert not Path(rel).is_absolute() and ".." not in Path(rel).parts
 no_symlink_components(path); assert sha(path)==expected,rel
snapshot=R/plan["retained_root_live_snapshot"]
no_symlink_components(snapshot); assert sha(snapshot)==plan["retained_root_live_sha256"]
assert sha(R/"LOCAL/raw/root-live-ownership-20261021.json")==plan["retained_root_live_sha256"],"root live ownership changed after admission"
out.mkdir(exist_ok=False)
selected=plan["nodes"]; assert selected and len(selected)==len(set(selected))
test_paths=sorted({v.split("::")[0] for v in selected})
assert all(v.startswith("tests/") and (P/v).is_file() for v in test_paths)
observer=D/"readset_observer_tools_r1.py"
monitor=P/"docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-postfix-709-q2-helper-actual-20261018/supervise.py"
launcher=out/"pytest_launcher.py"
launcher.write_text("import importlib.util, pathlib, sys\nimport pytest\npath=pathlib.Path("+repr(str(observer))+")\nspec=importlib.util.spec_from_file_location('loaded_source_observer',path)\nplugin=importlib.util.module_from_spec(spec); spec.loader.exec_module(plugin)\nif __name__ == '__main__':\n    raise SystemExit(pytest.main(sys.argv[1:],plugins=[plugin]))\n")
tmp=out/"tmp"; tmp.mkdir()
profile=out/"child.sb"
fragment=plan["sandbox_profile_fragment"]
assert type(fragment) is str and hashlib.sha256(fragment.encode()).hexdigest()==plan["sandbox_profile_fragment_sha256"]
fragment_path=out/"sandbox-fragment.sb"; fragment_path.write_text(fragment)
profile.write_text('(version 1)\n(allow default)\n(deny file-write*)\n(allow file-write* (subpath '+json.dumps(str(out))+'))\n(allow file-write* (literal "/dev/null"))\n'+fragment)
assert profile.read_text()==plan["sandbox_profile_text"] and sha(profile)==plan["sandbox_profile_sha256"]
pins=[P/"pytest.ini",P/"pyproject.toml",P/"uv.lock",Path(__file__),Path(__file__).with_name("external_admission.py"),plan_path,observer,monitor,launcher,N/"root-layer-lib.py",R/"LOCAL/raw/root-live-ownership-20261021.json",R/before["source_frame"]["path"]]
pins += [P/p for p in test_paths]
pins += [q for q in [P/"conftest.py",P/"tests/conftest.py"] if q.is_file()]
pins += [profile,fragment_path]
input_pins={str(p.relative_to(R)):sha(p) for p in pins}
removed={}
for name in ["PYTHONPATH","PYTEST_ADDOPTS","PYTEST_PLUGINS","PYTEST_DISABLE_PLUGIN_AUTOLOAD","PYTHONHOME","VIRTUAL_ENV","CORR_C2_LEGACY_EFFECT_BRIDGE_PATH"]:
 if name in os.environ: removed[name]="present_removed"
 os.environ.pop(name,None)
env={"PYTHONDONTWRITEBYTECODE":"1","TMPDIR":str(tmp),"XDG_CACHE_HOME":str(tmp/"xdg"),"MPLCONFIGDIR":str(tmp/"mpl"),"NUMBA_CACHE_DIR":str(tmp/"numba"),"HYPOTHESIS_STORAGE_DIRECTORY":str(tmp/"hypothesis"),
     "PYTHONPYCACHEPREFIX":str(tmp/"empty-pycache"),"POLISYOS_R4_INPUT_PROJECT_ROOT":str(P),"POLISYOS_R4_INPUT_READSET_DIR":str(out/"readsets"),
     "SCIENTIST_TORCH_NUM_THREADS":"1","SCIENTIST_TORCH_NUM_INTEROP_THREADS":"1",**plan.get("extra_env",{})}
argv=[str(P/".venv/bin/python"),"-B",str(launcher),"-o","cache_dir="+str(out/"pytest-cache"),"--benchmark-storage=file://"+str(out/"benchmarks"),"--basetemp",str(out/"basetemp"),"--junitxml="+str(out/"pytest.xml"),"--tb=short","--color=no","--maxfail=0",*selected]
spec=importlib.util.spec_from_file_location("audit_bounded_monitor",monitor)
s=importlib.util.module_from_spec(spec);sys.modules[spec.name]=s;spec.loader.exec_module(s)
s.RSS_CAP_BYTES=plan.get("rss_cap_bytes",2300*1024**2);s.DISK_FLOOR_BYTES=6*1024**3;s.SAMPLE_SECONDS=1.0
signal.signal(signal.SIGTERM,s.note_stop_signal);signal.signal(signal.SIGINT,s.note_stop_signal)
save(out/"source-profile-freeze.json",{"at":datetime.datetime.now(datetime.UTC).isoformat(),"before":before,"plan_sha256":sha(plan_path),"selected_input_pins":input_pins,"native_profile":"pytest.ini, default plugin autoload/importlib/strict markers; add read-only sys.modules observer; outputs redirected only; private empty pycache search prefix prevents stale canonical pyc reuse","sandbox_profile":{"path":str(profile.relative_to(R)),"text":profile.read_text(),"sha256":sha(profile),"fragment_path":str(fragment_path.relative_to(R)),"fragment_text":fragment,"fragment_sha256":sha(fragment_path)},"cleared_ambient_control_names":removed,"extra_env":env,"numeric_threads":s.NUMERIC_THREADS,"argv":argv,"cwd":str(P),"scope":plan["scope"],"unresolved_by_construction":["unimported source and arbitrary executable parser/plugin inputs are not a repository-wide runtime census","observer records src/polisyos, tests and tools Python modules; external package modules are outside this observer selection","this is an audit-specific source/profile freeze, not E02 global acceptance"],"closure_ids":[]})
started=time.monotonic()
result=s.run_command(out,case,["/usr/bin/sandbox-exec","-f",str(profile),*argv],P,started,started+plan.get("deadline_seconds",600),env)
if (out/"pytest.xml").exists():
 cases=list(ET.parse(out/"pytest.xml").iter("testcase"))
 result["junit"]={"tests":len(cases),"failures":sum(q.find("failure") is not None for q in cases),"errors":sum(q.find("error") is not None for q in cases),"skipped":sum(q.find("skipped") is not None for q in cases)}
 result["skips"]=[{"node":q.get("classname","")+"::"+q.get("name",""),"reason":q.find("skipped").get("message","")} for q in cases if q.find("skipped") is not None]
readsets=[]; mismatches=[];seen={}
for f in sorted((out/"readsets").glob("*.json")):
 no_symlink_components(f)
 d=json.loads(f.read_text())
 readsets.append({"path":str(f.relative_to(R)),"sha256":sha(f),"python_paths":len(d["modules"]),"pytest_exitstatus":d["pytest_exitstatus"]})
 for row in d["modules"]:
  path=P/row["path"]
  actual=sha(path) if path.is_file() else None
  if actual!=row["sha256"]:mismatches.append({"path":str(path.relative_to(R)),"run":row["sha256"],"current":actual})
  seen[row["path"]]=row["sha256"]
assert all(sha(R/path)==digest for path,digest in input_pins.items()),"selected input mutation"
for rel, expected in {**plan["additional_input_sha256"],**plan["harness_sha256"]}.items():
 no_symlink_components(R/rel); assert sha(R/rel)==expected,rel
assert fixture_snapshot(plan["candidate_fixture_root"],R)==plan["candidate_fixture_files"],"candidate input fixture set or bytes changed"
after=guard()
record={"plan":plan,"source_profile_freeze_sha256":sha(out/"source-profile-freeze.json"),"result":result,"readsets":readsets,"unique_runtime_loaded_python_paths":len(seen),"current_mismatches":mismatches,"guard_after":after,"scope":"Fresh canonical-source audit run. Readset is the observer's finite imported src/tests/tools set, not a whole-repository or all-backend proof.","closure_ids":[]}
save(out/"audit-result.json",record)
print(json.dumps({"case":case,"exit":result["return_code"],"complete":result["complete"],"abort":result["aborted_reason"],"junit":result.get("junit"),"seconds":result["wall_seconds"],"peak_rss":result["max_sampled_process_tree_rss_bytes"],"runtime_py":len(seen),"mismatches":len(mismatches),"audit_result_sha256":sha(out/"audit-result.json")}),flush=True)
raise SystemExit(0 if result["return_code"]==0 and result["complete"] and not result["aborted_reason"] and not mismatches else 1)

