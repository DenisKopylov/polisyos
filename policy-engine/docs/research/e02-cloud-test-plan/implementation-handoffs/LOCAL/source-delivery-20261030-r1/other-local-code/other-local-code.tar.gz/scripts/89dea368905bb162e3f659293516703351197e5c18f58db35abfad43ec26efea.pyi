"""UNRATIFIED vocabulary sketch; not an installed ABI, issuer or capability.

A Protocol shape/ref alone grants nothing. An appointed owner must independently
verify issuer, source, live implementation, freshness, read/effect and lease basis.
"""

from typing import Literal, Protocol

from polisyos.core.artifacts import ArtifactRef

class WorkspaceRefusal(Protocol):
    @property
    def status(self) -> Literal["rejected", "unavailable", "limited_candidate"]: ...
    @property
    def refusal_ref(self) -> ArtifactRef: ...
    # Deliberately no successful settled-workspace receipt.

class SettledCandidateWorkspace(Protocol):
    @property
    def status(self) -> Literal["settled_candidate"]: ...
    @property
    def admitted_computation_capability_ref(self) -> ArtifactRef: ...
    @property
    def parent_invocation_basis_ref(self) -> ArtifactRef: ...
    @property
    def registered_composition_ref(self) -> ArtifactRef: ...
    @property
    def candidate_observation_ref(self) -> ArtifactRef: ...
    @property
    def settled_journal_receipt_ref(self) -> ArtifactRef: ...
    # Candidate settlement is not parent/public/authority publication permission.

class AppointedEngineWorkspaceOwner(Protocol):
    """Issuer appointment is independent of this shape and registered child specs."""
    def evaluate_registered_candidate(
        self,
        *,
        admitted_computation_capability_ref: ArtifactRef,
        registered_composition_ref: ArtifactRef,
        candidate_ref: ArtifactRef,
    ) -> SettledCandidateWorkspace | WorkspaceRefusal: ...
