"""Root-only one exact stdlib A five-second-stack diagnostic extending R6 using the retained D monitor APIs.

This file is a harness, not a product entrypoint. Do not execute it until this
wrapper has its own review and the active C60 native lease has ended.
"""
from __future__ import annotations

import argparse
import base64
import datetime as dt
import errno
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time
import traceback
import xml.etree.ElementTree as ET
from typing import Any


R = Path("/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos")
P = R / "policy-engine"
PKG = R / "LOCAL/raw/e02-execution-20261027/repairs/C104-measured-worker-harness-r2"
PRIOR = R / "LOCAL/raw/e02-execution-20261027/repairs/C104-measured-worker-harness-r1"
OBSERVER_SOURCE = PRIOR / "observer/r7_source_observer.py"


def load_retained_owner(name: str, filename: str, expected_sha: str) -> Any:
    """Load only the exact frozen stdlib owner reused by this style revision."""
    path = PRIOR / filename
    if not path.is_file() or path.is_symlink() or hashlib.sha256(path.read_bytes()).hexdigest() != expected_sha:
        raise RuntimeError("retained C104 owner identity differs")
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError("retained C104 owner loader unavailable")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


c104_cleanup_gate = load_retained_owner("_c104_r2_cleanup_gate", "cleanup_gate.py", '01cc8f13ba90fef032522229c8cd9385ba79b727dbd976f6695df414400a07a4')
qualify_capture = load_retained_owner("_c104_r2_receipt_gate", "receipt_gate.py", '391dc484337fde255c0f0dc304c32cf560864195fc60a35a7821e36e9fea9eff').qualify_capture

R4_SOURCE = R / "LOCAL/raw/e02-execution-20261027/next-cloud/C104-local-r4"
DRIVER_R4 = R / "LOCAL/raw/e02-execution-20261027/next-cloud/C104-local-root-driver-r4"
R3_SOURCE = R / "LOCAL/raw/e02-execution-20261027/next-cloud/C104-local-r3"
DRIVER_R3 = R / "LOCAL/raw/e02-execution-20261027/next-cloud/C104-local-root-driver-r3"
DRIVER_R2 = R / "LOCAL/raw/e02-execution-20261027/next-cloud/C104-local-root-driver-r2"
DRIVER_R1 = R / "LOCAL/raw/e02-execution-20261027/next-cloud/C104-local-root-driver-r1"
R2 = R / "LOCAL/raw/e02-execution-20261027/next-cloud/C104-local-r2"
R1 = R / "LOCAL/raw/e02-execution-20261027/next-cloud/C104-local-r1"
REVIEWS = R / "LOCAL/raw/e02-execution-20261027/reviews"
N = P / "docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-ir-transport-composition-20261024-r1/g-native-priority-20261025-r1"
HISTORICAL_D = N / "deep-task-status-audit-20261027-r1"
D = PKG / "runs"
FAILED_R3_CASE = HISTORICAL_D / "c104-local-r2-root-driver-r3"
FAILED_R4_CASE = HISTORICAL_D / "c104-local-r3-root-driver-r4"
FAILED_PREFLIGHT_R4_CASE = HISTORICAL_D / "c104-local-r4-collection-preflight-r5"
PREFLIGHT_R4_PLAN = DRIVER_R4 / "plan-collection-preflight-r5.json"
MONITOR = P / "docs/research/e02-cloud-test-plan/implementation-handoffs/LOCAL/raw/root-postfix-709-q2-helper-actual-20261018/supervise.py"
GUARD = N / "root-layer-lib.py"
LIVE = R / "LOCAL/raw/root-live-ownership-20261021.json"
RESOURCE = R / "LOCAL/raw/e02-execution-20261027/generated-admission-r1/c60-local-cli-admission-r5/root_native.py"
SANDBOX_JSON = R / "LOCAL/raw/e02-execution-20261027/generated-admission-r1/c60-local-cli-admission-r5/sandbox-fragment.json"
SANDBOX_PLAN = HISTORICAL_D / "c48-two-source-composed-r5-20261028.json"
OVERLAY_REL = "policy-engine/tests/_helpers/r2_source_observer.py"
OVERLAY = R / OVERLAY_REL
BRANCH = "codex/e02-unified-local-20261009"
R2_MANIFEST_SHA = "f94a8969e5f9138cccdac720e35fa7d9ecf0edeafcf2e93c375a5bdc3dfb4447"
R2_REVIEW_SHA = "7854f33b047c367c345afafd78b23436e203098ca70a1cf51225f245de65ee6c"
R1_MANIFEST_SHA = "fd2796b37b3a70391db8beef0f09926dc1ed8a7e8ae2bf77501c679a274fae39"
R1_REVIEW_SHA = "eb80b4311f5b298e905ebf422b83556445afc01d210191a6562c73df66e0607c"
MONITOR_SHA = "a94a662308270ba3aca96c1d9c75e53a05e37a923a6188d0f464f8ac1e90909e"
GUARD_SHA = "4b381f40f830180c0aa3d1a3cc6d091bc5e5f4598660a1824894d7a188351d35"
RESOURCE_SHA = "5359a0542cc2a3019e0a2e03073aaea2922865312ae4765c9d549d92a6b47f48"
SANDBOX_JSON_SHA = "942022b517bd9ea69b7cf9508e773e7c53bca22726c52d187df595d907e5cb89"
SANDBOX_FRAGMENT_SHA = "e32b29d96c194caa1b6d22981823771d1f3b618dd5c73d4956f61bde4fb2f6db"
SANDBOX_PLAN_SHA = "15a3e0dfb02f33e4c678d2af0f8a1a6d1151a2bdb8309da12d0dc2aca3fd22dd"
DRIVER_R1_README_SHA = "2310cd2c220a5a3001161103d2a86605225248b3c0a8da3488238be5c8a1f85d"
DRIVER_R1_DRIVER_SHA = "6ac5a0dbc097d9284de834523b41835b5f6f06ace6b0efb243968eb46bc52057"
DRIVER_R1_MANIFEST_SHA = "ceff8bde2ce0afe98c21ec67474bc6585d1ab7be5431c79cef29063df5cb8586"
DRIVER_R1_REVIEW_MD_SHA = "a871dee87c1137a573f2346ea5a5d25bbeb8b27254c622dd8afc7cd854c12fd5"
DRIVER_R1_REVIEW_JSON_SHA = "8492c2b64c9e0e5a020197a0b7d4c581311e50f3b8429752e446bd0473610aac"
R4_REVIEW_MD_SHA = "0f9d1a7a2337b78071f4448abd7fc0e08f91989224e49ad798b28e893e9e01d4"
R4_REVIEW_JSON_SHA = "edaab9f4e51abfa2a4c78d2b03ae36531d6c446bcce44a930e22598c23127ac0"
RSS_CAP = 3 * 1024**3
DISK_FLOOR = 8 * 1024**3
WALL_CAP = 135.0
SAMPLE_SECONDS = 1.0
CLEAR_ENV = ("PYTHONHOME", "VIRTUAL_ENV", "PYTEST_ADDOPTS", "PYTEST_PLUGINS",
             "PYTEST_DISABLE_PLUGIN_AUTOLOAD", "PYTEST_CURRENT_TEST", "PYTHONOPTIMIZE", "MYPYPATH", "MYPY_CACHE_DIR",
             "E02_B_PROPERTY_REMOVAL", "E02_A_PROFILE_PARENT_PID")
PHASE_A = ['tests/unit/scientist/orchestration/engine/runner/test_serialization_e02.py::test_real_worker_process_consumes_state_and_emits_exact_typed_outcome[stdlib]', 'tests/unit/scientist/orchestration/engine/runner/test_serialization_e02.py::test_real_worker_process_consumes_state_and_emits_exact_typed_outcome[orjson]']
PHASE_B = [
    "tests/unit/scientist/orchestration/engine/test_prepared_b_removal_controls.py::test_branch_isolation_removal_leaks_to_real_parallel_sibling",
    "tests/unit/scientist/orchestration/engine/test_prepared_b_removal_controls.py::test_merge_operation_removal_is_red_for_direct_and_executor_replay",
    "tests/unit/scientist/orchestration/engine/test_prepared_b_removal_controls.py::test_replay_proof_removal_admits_stale_real_cache_to_fresh_reader",
    "tests/unit/scientist/orchestration/engine/test_prepared_b_removal_controls.py::test_current_wire_schema_removal_accepts_unknown_version_with_markers",
    "tests/unit/scientist/orchestration/engine/test_prepared_b_removal_controls.py::test_typed_decimal_refusal_survives_actual_worker_and_marker_removal",
    "tests/unit/scientist/orchestration/engine/test_prepared_b_removal_controls.py::test_worker_merge_conflict_removal_changes_real_typed_receiver",
]


class Hold(RuntimeError):
    """Fail-closed source, profile, or resource admission."""


def need(value: object, reason: object) -> None:
    if not value:
        raise Hold(reason)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical_sha(value: Any) -> str:
    return digest(json.dumps(value, sort_keys=True, separators=(",", ":")).encode())


def file_sha(path: Path) -> str:
    need(path.is_file() and not path.is_symlink(), {"expected a regular non-symlink file": str(path)})
    return digest(path.read_bytes())


def utc() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def git(*args: str, check: bool = True) -> str:
    result = subprocess.run(["/usr/bin/git", *args], cwd=R, capture_output=True, text=True, check=False)
    if check and result.returncode:
        raise Hold({"git": args, "exit": result.returncode, "stderr": result.stderr[-1500:]})
    return result.stdout.strip()


def save_new(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def write_new(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def load_file_module(name: str, path: Path) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    need(spec is not None and spec.loader is not None, ("retained API unavailable", str(path)))
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def apis() -> tuple[Any, Any, Any]:
    # These are the existing Root monitor, Root resource sampler, and Root guard.
    # This driver does not import PolicyOS or replace their implementations.
    return (load_file_module("c104_d_supervise", MONITOR),
            load_file_module("c104_root_resource_sample", RESOURCE),
            load_file_module("c104_root_guard", GUARD))


def pins() -> dict[str, str]:
    fixed = {
        R2 / "manifest.json": R2_MANIFEST_SHA,
        R2 / "README.md": "79c4665b17e7090e6632955598bce55cc0fdd6532a9784daa0736ca3baac5c4a",
        R2 / "DELTA.md": "666dc19dde70fc21b05cd2e27933685b64548cc3d910b37ee031ef3fcce37f74",
        R2 / "r2_source_observer.py": "211ab0fee60faa7ac6d5af1a3e661bc609b3493f8a9912f1dbb0ad3003437352",
        R2 / "phase_c_spawn_witness.py": "8c6e9f6babc62a6e939ebdc7fc2e5c0d9566af76c2497962b3e2819b25c9488e",
        R1 / "manifest.json": R1_MANIFEST_SHA,
        REVIEWS / "C104-local-r1-source-admission-independent.md": R1_REVIEW_SHA,
        REVIEWS / "C104-local-r1-source-admission-independent.json": "7ff34b6b318d136bbd7af0a8599a5b015da6b5163de2eccd645081fa49ed09c5",
        REVIEWS / "C104-local-r2-independent.md": R2_REVIEW_SHA,
        REVIEWS / "C104-local-r2-independent.json": "1d16a0606ae6b09697b234bdef58aa84d85948d9cc3c125b2a1a8820d0230977",
        REVIEWS / "C104-r3-actual-independent.md": "bf13c905d78b1e5db58ff5d82028b08d7a4776e7968621bdbb5bd60c6cea57f4",
        REVIEWS / "C104-r3-actual-independent.json": "b1ee3582f9abdc213a6eda151ba251581c800854a6c008c2a0595bd8a6b22506",
        REVIEWS / "C104-r3-delta-independent.md": "0ad0fd6838f2d37899f7d053b08c9c240854e2fbaf937c5459149330d25d9e07",
        REVIEWS / "C104-r3-delta-independent.json": "a9adc5907c13b01bbc38808193c08080e6c838186d36cd63d3820dab1baf7fb6",
        DRIVER_R1 / "README.md": DRIVER_R1_README_SHA,
        DRIVER_R1 / "driver.py": DRIVER_R1_DRIVER_SHA,
        DRIVER_R1 / "manifest.json": DRIVER_R1_MANIFEST_SHA,
        DRIVER_R1 / "independent-review.md": DRIVER_R1_REVIEW_MD_SHA,
        DRIVER_R1 / "independent-review.json": DRIVER_R1_REVIEW_JSON_SHA,
        DRIVER_R2 / "README.md": "3215287caff98bfd69729010fc9165faf50bf58f65a8b30ec54f7122562ceb34",
        DRIVER_R2 / "driver.py": "3be8cccc7aa6442ec1b7aa7012c9746cd59fb6faded3f8050b1628bd662eb86b",
        DRIVER_R2 / "cleanup_gate.py": "01cc8f13ba90fef032522229c8cd9385ba79b727dbd976f6695df414400a07a4",
        DRIVER_R2 / "cleanup_gate_falsifier.py": "7e86e11f98a890d76d1d6c82be435ab701a41c0b50fcea0a0c9feed0a4bbaaf6",
        DRIVER_R2 / "DELTA.md": "b2c190f2dfdc5c4e5300dd1be9b5e4bf15354d9f701e3852811651b278bd2614",
        DRIVER_R2 / "manifest.json": "15a4e2728ccdd32b00f6afeeedb4693d209096ccb78e4cc69e2ac8f99a8ea84d",
        DRIVER_R3 / "README.md": "8f4b6313308f59362c31c38c666acf2ba2c3bad9c730c32b824f23834d57a1f4",
        DRIVER_R3 / "driver.py": "aa0ea9641bf501b870fc93dfea43b722df98f82d0ee7a70d09a79a1687e20b9c",
        DRIVER_R3 / "cleanup_gate.py": "01cc8f13ba90fef032522229c8cd9385ba79b727dbd976f6695df414400a07a4",
        DRIVER_R3 / "cleanup_gate_falsifier.py": "7e86e11f98a890d76d1d6c82be435ab701a41c0b50fcea0a0c9feed0a4bbaaf6",
        DRIVER_R3 / "DELTA.md": "4e650df4d99016b1f71d133ca5715415d03155d4a0fa82d474f4d181276eeca5",
        DRIVER_R3 / "manifest.json": "14bc93e46a2bd326239eb5ceebd164be751d19463614077f94bdae8edc7cacbf",
        FAILED_R3_CASE / "phases/phase-a/monitor/phase-a.stdout.txt": "a9a5bc40ad9960e9a97192abfabf7a915137b3f2297130aac7c4e25a8eb7e38a",
        FAILED_R3_CASE / "phases/phase-a/monitor/phase-a.stderr.txt": "1d34312fe47155b263be48e66bf41ac62ccaf4231b13b2046cec16703e3d496d",
        FAILED_R3_CASE / "phases/phase-a/phase-receipt.json": "63276802729fb071ba687fbd9c2e858b6b314288572c035d41a89bd7f295ba06",
        FAILED_R3_CASE / "run-summary.json": "8b3ec4a4890fc33383f01567d9b6ae3af33bc608e3af61eb11080285653acbf3",
        FAILED_R3_CASE / "audit-readback.json": "eeca9eb9dc59fe5e96c89ddd1207be584f54c13f398ed8fdd87cc8f0fe88830d",
        FAILED_R3_CASE / "cleanup-readback.json": "631e000b80094f86570a4ca8b6f779457cd92f8ed994dd1a4da4b61071ecf24e",
        FAILED_R4_CASE / "phases/phase-a/monitor/phase-a.stdout.txt": "5ba6beb6a589697551d8e57f791386093ee08ab0578c86d9d679456e6777ba40",
        FAILED_R4_CASE / "phases/phase-a/monitor/phase-a.stderr.txt": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        FAILED_R4_CASE / "phases/phase-a/phase-receipt.json": "f20cefbe44b63a8818b1e06534354403253ed4f889820a44cf95b2f04c75320a",
        FAILED_R4_CASE / "run-summary.json": "04ecfdbe02c7478922d55e97e9ca3dbd90264694a225129009a9ebe18d3efe80",
        FAILED_R4_CASE / "audit-readback.json": "78afb8179303d3fa7b22daee569f29acb4f6087f4267c5bed26d8ccb8bfaef98",
        FAILED_R4_CASE / "cleanup-readback.json": "41c235dbb23cc644d9b21e09afb8dc3f9e8490e95652c121386549c122069ae4",

        # Hash-bound R4 driver packet and actual collection-only return; no outputs copied.
        DRIVER_R4 / 'DELTA.md': 'd5a0514ad4f366b83de233ed5712d12048bcc0560d96c8bb20015a404734f5ee',
        DRIVER_R4 / 'README.md': '37810ec6749e1301ad593913b9202019519171067574fd32084738223f091416',
        DRIVER_R4 / 'cleanup_gate.py': '01cc8f13ba90fef032522229c8cd9385ba79b727dbd976f6695df414400a07a4',
        DRIVER_R4 / 'cleanup_gate_falsifier.py': '422982ee5f1e8ba4562b1b906a509a5e6ae9a11c4cc26fb3f94ac54c9bfae8e5',
        DRIVER_R4 / 'driver.py': 'b01245eb3c5577631d1ef6f08f65ab9f77ead2e89fd2bb6fc4f84466e6b7dde7',
        DRIVER_R4 / "manifest.json": '2edb71f2ecb4fc69c23bc7ab312c63e6fc39aa2b9404baf01d773fb1429b59e5',
        REVIEWS / "C104-local-r4-independent.md": R4_REVIEW_MD_SHA,
        REVIEWS / "C104-local-r4-independent.json": R4_REVIEW_JSON_SHA,
        PREFLIGHT_R4_PLAN: '89e37fdbe34da34a485530559a8859518896160f64e8fb158f6a9c06abbca983',
        FAILED_PREFLIGHT_R4_CASE / 'child.sb': '6d7d85571075b5ab8873e99c75b73753520e02afc9e8c7a43f571a816fa07c1a',
        FAILED_PREFLIGHT_R4_CASE / 'events.jsonl': '2d4fc2bcc044d9ac67e18301834b6c9e64e6c911f0bde64cde6639e688b54964',
        FAILED_PREFLIGHT_R4_CASE / 'observer-overlay-source.py': '7fddc6c2126ba15f1cbc25036a6427d39415cb8e54890f1d6b426a923f53bf52',
        FAILED_PREFLIGHT_R4_CASE / 'overlay-created.json': '7f6517eae0a743a79fd553fb8454af60adb963a2fc597ceacb8e3cf39dbded00',
        FAILED_PREFLIGHT_R4_CASE / 'phases/phase-a/invocation.json': '50170a9febd2908ddf22a3c09c14ed6bca72760df5bccdbbd044f26602c5d2da',
        FAILED_PREFLIGHT_R4_CASE / 'phases/phase-a/junit.xml': 'e1185816455101f3796c28c75f2c9dff2ed05d48a02a616695394f902b621c36',
        FAILED_PREFLIGHT_R4_CASE / 'phases/phase-a/monitor-result.json': '6267dc816db0493fad368ff63769dc92f19fba2beb47d33edab1c0f042e68b98',
        FAILED_PREFLIGHT_R4_CASE / 'phases/phase-a/monitor/controller-events.jsonl': 'd0b06b19016f2982c9706ab19408ee4b62dd64f269037cbff88a2a8e022aed29',
        FAILED_PREFLIGHT_R4_CASE / 'phases/phase-a/monitor/phase-a.stderr.txt': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
        FAILED_PREFLIGHT_R4_CASE / 'phases/phase-a/monitor/phase-a.stdout.txt': '92860b61e0ff98bb9895cc9f8f1d88cbe841a00a36a6764e3324f72df104ddd2',
        FAILED_PREFLIGHT_R4_CASE / 'phases/phase-a/monitor/phase-output.jsonl': '5c4afaef0b8ca7f475e20ebc70d125f4fdabb8ecc112a933d84bea3db44d0d92',
        FAILED_PREFLIGHT_R4_CASE / 'phases/phase-a/monitor/process-tree.jsonl': '9d2de744ef7653a7e6a9f9c03d49ad1555fcfe46c821dc8d4056a1c80a0efab9',
        FAILED_PREFLIGHT_R4_CASE / 'phases/phase-a/observer/selection-diagnostic-94437.json': 'e518cdc26c064e020bcb4bf8a65164d93effbb4f10af6c934b689fa8c5f330fb',
        FAILED_PREFLIGHT_R4_CASE / 'phases/phase-a/observer/source-observer-94437.json': 'd7913cbd6853062ca2bc6ba24b170965d77561d9a896db02ca1a682980e2d0be',
        FAILED_PREFLIGHT_R4_CASE / 'phases/phase-a/phase-receipt.json': '66fb197caa504bad9146dcdac18feb74c365f6a30288e7c2306b642341217e85',
        FAILED_PREFLIGHT_R4_CASE / 'phases/phase-b/invocation.json': 'f439599328b139f61137b745158b2885e11e6aed835f8b037165463d23f144a2',
        FAILED_PREFLIGHT_R4_CASE / 'phases/phase-b/junit.xml': 'e14699fe8824e9e038bc3c2e37e95267945613b50729a8c9265398dca05c78e1',
        FAILED_PREFLIGHT_R4_CASE / 'phases/phase-b/monitor-result.json': 'dce69e4833892177e3af7c618c13553654c8b3f7e6b65255934eb5a7e31d92eb',
        FAILED_PREFLIGHT_R4_CASE / 'phases/phase-b/monitor/controller-events.jsonl': 'e52907b876f31eb832eaa96db1cdccc40f3a527cb21c734a4ae767f774a9b875',
        FAILED_PREFLIGHT_R4_CASE / 'phases/phase-b/monitor/phase-b.stderr.txt': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
        FAILED_PREFLIGHT_R4_CASE / 'phases/phase-b/monitor/phase-b.stdout.txt': '49dd29968034fd90ad2a80047d3e90c75a0d74ada1f5a83dfe1fb6f5231ecbce',
        FAILED_PREFLIGHT_R4_CASE / 'phases/phase-b/monitor/phase-output.jsonl': 'df53a12ffdd19a9720425ba9d5c13b02529cc3f08feb79f9ce602617829f598f',
        FAILED_PREFLIGHT_R4_CASE / 'phases/phase-b/monitor/process-tree.jsonl': 'e478ebfb2eaf3cda57d41fd4b427608257cdc7d958bbf413e24db00d942cd810',
        FAILED_PREFLIGHT_R4_CASE / 'phases/phase-b/observer/selection-diagnostic-95099.json': 'f2e918e50f9ef2d2195fc46ebc53d7d429572144e3593c71be73bec8944d4aea',
        FAILED_PREFLIGHT_R4_CASE / 'phases/phase-b/observer/source-observer-95099.json': 'c76634216d7fcbeebd228dbab7120b0634069cbc9313d380f670dab7eb537e03',
        FAILED_PREFLIGHT_R4_CASE / 'phases/phase-b/phase-receipt.json': '659d1e2154aea311e8797380862a36442136e8686c2520835279e547781cc05e',
        FAILED_PREFLIGHT_R4_CASE / 'root-live-input.json': '74451d5bca5f9d39cc693746593173a36dfead2516070fdea7bf63725a571507',
        FAILED_PREFLIGHT_R4_CASE / 'root-source-frame.json': 'f1207bcc22713adf21b63a40802194f69db70193b81a16d01917914d4beea644',
        FAILED_PREFLIGHT_R4_CASE / 'run-summary.json': '630a25aebcf5f88b3fb2a6892ef504f1fbc2322a1a0ad55fc33fe7b7ef28d38c',
        FAILED_PREFLIGHT_R4_CASE / 'source-profile-freeze.json': 'bf62fec5a6b172c73bdac6eba884c5aaea861344e54bd54237eae19796a64a26',
        FAILED_PREFLIGHT_R4_CASE / 'audit-readback.json': '18e0d7bd8b0e6badbed9e912091130f526b509dec93de5d31cdb72160079702e',
        FAILED_PREFLIGHT_R4_CASE / 'manual-root-cleanup-r1.json': '2a8c40ad7c9892afe20841a83f02aa5e2d6dbe862e83226b167f5ab0ba07c054',
        R3_SOURCE / "manifest.json": "00bb214980acf48c7aef9146b3ac94fddb0d7ca7cb3b481cae95e8e4239dd6a5",
        R3_SOURCE / "README.md": "3b8c1a56783c0f337589b039b72e20a078438ff348c7a6add077c0783bbb884e",
        R3_SOURCE / "DELTA.md": "3481e40c56777498d9fee2f67be882088e4abf0d87c8fb019742a6fc05ba8097",
        R3_SOURCE / "r2_source_observer.py": "be99d91fb32eb2bd660dd84b84927702e9e41e6501afff5aefebcadd236dd111",
        R3_SOURCE / "observer_delta_falsifier.py": "ac2710975cd216e36428175116c13afe2dfe15c93a22b088072dd30711ad541a",
        R4_SOURCE / "manifest.json": "893d67683da5fbb71f5f1ba9ae3024d5895fa933ada9b69576fb04e119b5d383",
        R4_SOURCE / "README.md": "8a38de577240a351b253218d96725fddee9bafb7245962d48770cdc584352bec",
        R4_SOURCE / "DELTA.md": "d4cc194a66d4d9c8411350fde876cabeb5bd75ffb7cab878f320bc25eea0a62e",
        R4_SOURCE / "r2_source_observer.py": "7fddc6c2126ba15f1cbc25036a6427d39415cb8e54890f1d6b426a923f53bf52",
        R4_SOURCE / "collection_identity_falsifier.py": "1aadb83cccac14519ce8dc495343c5c1dd237b2593b47cab4d9cfcebbac0e588",
        MONITOR: MONITOR_SHA, GUARD: GUARD_SHA, RESOURCE: RESOURCE_SHA,
        SANDBOX_JSON: SANDBOX_JSON_SHA, SANDBOX_PLAN: SANDBOX_PLAN_SHA,
    }
    fixed[OBSERVER_SOURCE] = "f95db35fef116a5a4e8ef3a4bc673bfa37caa103f662e9c3caba54df3739e2b3"
    fixed[PRIOR / 'manifest.json'] = 'bf173000328b7807a1e83fb9187f3bfb0ead5cefd7a47458480c633799378b2b'
    fixed[PRIOR / 'cleanup_gate.py'] = '01cc8f13ba90fef032522229c8cd9385ba79b727dbd976f6695df414400a07a4'
    fixed[PRIOR / 'receipt_gate.py'] = '391dc484337fde255c0f0dc304c32cf560864195fc60a35a7821e36e9fea9eff'
    fixed[PRIOR / 'observer/bounded_code_capture.py'] = '5cce83b6853a5e7bd34b0346a7af24d38479fb1801700c203ad65699edb26743'
    fixed[R / "LOCAL/raw/e02-execution-20261027/next-cloud/C104-local-root-driver-r5/driver.py"] = "5ddbd83051519d8aac88205f8d960fcf4c4112e721c9ff105f9b6bf078706536"
    for path, expected in fixed.items():
        actual = file_sha(path) if path.is_file() else "MISSING"
        need(actual == expected, {"reviewed_input_changed": str(path), "expected": expected, "actual": actual})
    package_manifest = json.loads((PKG / "manifest.json").read_text())
    package_files = package_manifest.get("package_files")
    need(isinstance(package_files, dict), "Root driver package manifest lacks package file bindings")
    declared_package_names = set(package_files) - {"manifest_self_hash"}
    expected_package_names = {'source-postimages.json', 'driver.py', 'README-helper-fragment.md', 'README.md', 'bound-basis.json', 'source-conservation.json'}
    need(declared_package_names == expected_package_names,
         {"Root driver package file inventory differs": sorted(declared_package_names)})
    for name, expected in package_files.items():
        if name == "manifest_self_hash":
            continue
        path = PKG / name
        need(path.is_file() and not path.is_symlink(), {"Root driver package file is absent": name})
        actual = {"bytes": path.stat().st_size, "sha256": file_sha(path)}
        need(actual == expected, {"Root driver package file differs from its manifest": name,
                                  "expected": expected, "actual": actual})
    return {str(path.relative_to(R)): value for path, value in fixed.items()} | {
        str((PKG / name).relative_to(R)): file_sha(PKG / name)
        for name in sorted(declared_package_names | {"manifest.json"})
    }


def check_pins(values: dict[str, str]) -> list[dict[str, str]]:
    bad = []
    for rel, expected in sorted(values.items()):
        path = R / rel
        actual = file_sha(path) if path.is_file() else "MISSING"
        if actual != expected:
            bad.append({"path": rel, "expected": expected, "actual": actual})
    return bad


def r2() -> dict[str, Any]:
    path = R2 / "manifest.json"
    need(file_sha(path) == R2_MANIFEST_SHA, "C104 R2 manifest differs from independently reviewed bytes")
    return json.loads(path.read_text())


def check_reviewed_sources(head: str) -> dict[str, Any]:
    checked = []
    postimages = json.loads((PKG / "source-postimages.json").read_text())
    for original in r2()["source_snapshot"]["relevant_source_readback"]:
        row = dict(original)
        if row["path"] in postimages:
            row.update(postimages[row["path"]])
        rel = row["path"]
        rel_path = Path(rel)
        need(not rel_path.is_absolute() and ".." not in rel_path.parts
             and rel.startswith(("policy-engine/src/", "policy-engine/tests/")),
             {"unexpected R2 source path": rel})
        blob = git("rev-parse", f"{head}:{rel}")
        path = R / rel
        actual = file_sha(path) if path.is_file() else "MISSING"
        ok = blob == row["git_blob"] and actual == row["sha256"]
        checked.append({"path": rel, "reviewed_blob": row["git_blob"], "actual_blob": blob, "actual_sha256": actual, "matches_review": ok})
    existing = {row["path"] for row in checked}
    for rel, expected in postimages.items():
        if rel in existing:
            continue
        blob = git("rev-parse", f"{head}:{rel}")
        actual = file_sha(R / rel)
        checked.append({"path": rel, "actual_blob": blob, "actual_sha256": actual,
                        "matches_review": blob == expected["git_blob"] and actual == expected["sha256"]})
    need(all(x["matches_review"] for x in checked), {"C104 source changed after R2 review; require a source delta review": checked})
    return {"count": len(checked), "paths": checked}


def env_profile(python: Path) -> dict[str, Any]:
    # Standard-library-only probe: records Python, installed metadata, pytest11
    # entry points, sys.path, and .pth bytes while preserving normal startup.
    probe = r'''import hashlib, importlib.metadata as md, json, pathlib, sys
dist = {}
for name in ("pytest", "orjson", "psutil"):
 try: dist[name] = md.version(name)
 except md.PackageNotFoundError: dist[name] = None
installed = [{"name": str(d.metadata.get("Name") or ""), "version": str(d.version)} for d in md.distributions()]
installed.sort(key=lambda d: (d["name"].casefold(), d["version"]))
eps = [{"name": e.name, "value": e.value, "distribution": e.dist.metadata.get("Name") if e.dist else None} for e in md.entry_points(group="pytest11")]
pth = {}
for value in sys.path:
 p = pathlib.Path(value)
 if p.is_dir():
  for x in sorted(p.glob("*.pth")): pth[str(x.resolve())] = hashlib.sha256(x.read_bytes()).hexdigest()
print(json.dumps({"python":sys.version,"executable":str(pathlib.Path(sys.executable).resolve()),"prefix":sys.prefix,"base_prefix":sys.base_prefix,"flags":{"no_site":sys.flags.no_site,"no_user_site":sys.flags.no_user_site,"no_bytecode":sys.flags.dont_write_bytecode},"sys_path":sys.path,"distributions":dist,"installed_distributions":installed,"pytest11":sorted(eps,key=lambda x:(x["name"],x["value"])),"pth":pth},sort_keys=True))'''
    child_env = os.environ.copy()
    removed = sorted(k for k in CLEAR_ENV if k in child_env)
    for key in CLEAR_ENV:
        child_env.pop(key, None)
    result = subprocess.run([str(python), "-B", "-c", probe], cwd=P, env=child_env, capture_output=True, text=True, check=False)
    need(result.returncode == 0, {"environment_probe_error": result.stderr[-1500:]})
    data = json.loads(result.stdout)
    data["ambient_controls_removed"] = removed
    data["pytest_autoload"] = "enabled; default config/.pth retained; only the task-authored C104 observer overlay is explicit"
    return data


def check_environment(profile: dict[str, Any]) -> None:
    expected = {"pytest": "9.0.2", "orjson": "3.11.5", "psutil": "7.2.1"}
    actual_python = profile.get("python", "").split()[0]
    problems = {k: {"expected": v, "actual": profile.get("distributions", {}).get(k)} for k, v in expected.items() if profile.get("distributions", {}).get(k) != v}
    if actual_python != "3.14.3":
        problems["python"] = {"expected": "3.14.3", "actual": actual_python}
    need(not problems, {"environment changed or dependency missing": problems, "action": "record setup ERROR; never install/reinstall"})


def environment_fingerprint(profile: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in profile.items() if key != "ambient_controls_removed"}


def resource_sample(native: Any) -> dict[str, Any]:
    result = native.resource_sample()
    need(result.get("free_disk_bytes", -1) >= DISK_FLOOR, {"required_free_disk_bytes": DISK_FLOOR, "sample": result})
    need(not result.get("other_python_above_100MiB"), {"another Python profile is active; serialize this native run": result.get("other_python_above_100MiB")})
    ram = result.get("memory_samples", {}).get("physical_ram", {})
    try:
        total_ram = int(str(ram.get("stdout", "")).strip())
    except ValueError:
        total_ram = 0
    need(ram.get("exit") == 0 and total_ram >= 16 * 1024**3, {"physical RAM not established": ram})
    return result


def identity(monitor: Any, head: str | None = None, tree: str | None = None) -> dict[str, Any]:
    current = monitor.source_frame(R)
    short = git("symbolic-ref", "--short", "HEAD")
    need(short == BRANCH and current.get("branch") == f"refs/heads/{BRANCH}", {"wrong author branch": current})
    if head is not None:
        need(current.get("head") == head and current.get("tree") == tree, {"source identity changed": current, "expected": [head, tree]})
    need(not monitor.tracked_status(R), "tracked changes exist; source must be committed before run")
    return {"short_branch": short, **current}


def observer_source_projection(root_source: Any) -> dict[str, str]:
    """Return the exact head/tree fields carried by the task observer diagnostic."""
    need(isinstance(root_source, dict)
         and root_source.get("branch") == f"refs/heads/{BRANCH}"
         and root_source.get("short_branch") == BRANCH
         and isinstance(root_source.get("head"), str)
         and re.fullmatch(r"[0-9a-f]{40}", root_source["head"])
         and isinstance(root_source.get("tree"), str)
         and re.fullmatch(r"[0-9a-f]{40}", root_source["tree"]),
         "full Root source identity lacks the pinned author branch, HEAD, or tree")
    return {"head": root_source["head"], "tree": root_source["tree"]}


def validate_observer_source_binding(root_source: Any, observer_source: Any) -> None:
    """Require the observer's exact two-field source projection of Root identity."""
    need(observer_source == observer_source_projection(root_source),
         "observer diagnostic source differs from the exact Root HEAD/tree projection")


def guard(guard_module: Any) -> dict[str, Any]:
    value = guard_module.guard()
    need(value.get("head") == git("rev-parse", "HEAD"), "retained Root guard did not bind actual HEAD")
    return value


def frame_bytes(receipt: dict[str, Any]) -> tuple[bytes, dict[str, Any]]:
    row = receipt.get("source_frame")
    need(isinstance(row, dict) and row.get("path") and row.get("sha256"), "Root guard lacks full source-frame binding")
    rel = Path(row["path"])
    need(not rel.is_absolute() and ".." not in rel.parts, "Root guard source-frame locator is unsafe")
    path = R / rel
    need(path.resolve().is_relative_to(R.resolve()) and path.is_file() and not path.is_symlink(), "Root source frame is outside checkout or unavailable")
    data = path.read_bytes()
    need(digest(data) == row["sha256"], "source frame readback does not match Root guard")
    return data, {"path": row["path"], "sha256": digest(data), "bytes": len(data)}


SOURCE_STATUS_PATHS = (
    "policy-engine/src", "policy-engine/tests", "policy-engine/tools",
    ":(top,glob)policy-engine/*.py", "policy-engine/polisyos",
)


def source_status_state(overlay_expected: bool = False) -> dict[str, Any]:
    """Reconcile importable in-repository source paths without scanning RAW outputs."""
    result = subprocess.run(
        ["/usr/bin/git", "status", "--porcelain=v1", "-z", "--untracked-files=all", "--", *SOURCE_STATUS_PATHS],
        cwd=R, capture_output=True, check=False,
    )
    need(result.returncode == 0, {"source status failed": result.stderr.decode(errors="replace")[-1000:]})
    records = [x.decode("utf-8", errors="surrogateescape") for x in result.stdout.split(b"\0") if x]
    expected = [f"?? {OVERLAY_REL}"] if overlay_expected else []
    if records != expected:
        need(False, {"unexpected importable source/index drift": {"count": len(records),
             "sha256": digest(result.stdout), "sample_first_20": records[:20]}, "expected": expected})
    return {"scope": list(SOURCE_STATUS_PATHS), "records": records,
            "raw_sha256": digest(result.stdout), "raw_bytes": len(result.stdout),
            "tracked_changes_checked_separately_by_retained_guard": True}


def check_live(plan: dict[str, Any], monitor: Any, guard_module: Any) -> dict[str, Any]:
    identity(monitor, plan["source"]["head"], plan["source"]["tree"])
    need(check_prior_release(repo_path(plan["prior_runtime_release"]["path"]), monitor, overlay_expected=OVERLAY.is_file())
         == plan["prior_runtime_release"], "prior preserving-release receipt changed")
    now = guard(guard_module)
    need(now == plan["root_guard"], "Root live/source frame changed; prepare a new append-only revision")
    need(file_sha(LIVE) == plan["root_live_sha256"], "Root live ownership bytes changed")
    current_frame = R / plan["source_frame"]["path"]
    need(file_sha(current_frame) == plan["source_frame"]["sha256"], "full Root source frame changed")
    need(not check_pins(plan["input_pins"]), "frozen R2/monitor/driver input changed")
    if plan.get("mode") == "runtime":
        validate_preflight_binding(plan.get("collection_preflight"), plan["source"],
                                   plan["environment_profile_sha256"], plan["overlay"]["sha256"])
    runtime_binding = plan.get("_runtime_binding")
    if runtime_binding:
        runtime_path = R / runtime_binding["path"]
        need(file_sha(runtime_path) == runtime_binding["sha256"], "prepared run plan changed after admission")
    check_reviewed_sources(plan["source"]["head"])
    source_state = source_status_state(overlay_expected=OVERLAY.is_file())
    need(plan["source_status_baseline"].get("records") == [], "source admission baseline was not clean")
    if OVERLAY.is_file():
        check_overlay(plan["overlay"]["sha256"])
    need(not source_state["records"] or source_state["records"] == [f"?? {OVERLAY_REL}"],
         {"source status escaped the bounded overlay allowance": source_state})
    return now


def validate_collection_preflight(run_dir: Path, source: dict[str, Any], profile_sha: str,
                                  overlay_sha: str) -> dict[str, Any]:
    """Require a completed, audited, cleaned collection-only proof for this exact source/profile."""
    need(run_dir.is_absolute() and run_dir.parent == D and run_dir.is_dir() and not run_dir.is_symlink()
         and run_dir.name.startswith("c104-observer-r5-collection-preflight-"),
         "runtime requires a retained C104 R5 collection-preflight case directory")
    summary_path = run_dir / "run-summary.json"
    audit_path = run_dir / "audit-readback.json"
    cleanup_path = run_dir / "cleanup-readback.json"
    need(all(path.is_file() and not path.is_symlink() for path in (summary_path, audit_path, cleanup_path)),
         "preflight summary, audit, and cleanup readbacks are all required")
    summary, audit, cleanup = (json.loads(path.read_text()) for path in (summary_path, audit_path, cleanup_path))
    need(summary.get("mode") == "collection-preflight" and summary.get("run_status") == "COLLECTION_PASS"
         and summary.get("source") == source and summary.get("unrun") == ["phase-c"],
         "collection preflight did not PASS both selected phases at the current exact source")
    need([row.get("phase_id") for row in summary.get("phases", [])] == ["phase-a", "phase-b"]
         and all(row.get("status") == "COLLECTION_PASS" for row in summary["phases"]),
         "collection preflight did not completely collect both commissioned selector groups")
    need(audit.get("cleanup_allowed") is True and audit.get("all_started_groups_gone") is True
         and audit.get("problems") == [] and audit.get("source") == source,
         "collection preflight audit has unresolved evidence or process state")
    need(cleanup.get("overlay_absent_after") is True and cleanup.get("removed_only") == OVERLAY_REL
         and cleanup.get("sha256") == overlay_sha,
         "collection preflight overlay cleanup is not read back absent")
    plan_path = repo_path(str(summary.get("plan", "")))
    need(plan_path.parent == PKG and plan_path.is_file() and not plan_path.is_symlink()
         and file_sha(plan_path) == summary.get("plan_sha256"),
         "collection preflight does not bind an intact local plan")
    preflight_plan = json.loads(plan_path.read_text())
    need(preflight_plan.get("mode") == "collection-preflight"
         and preflight_plan.get("source") == source
         and preflight_plan.get("environment_profile_sha256") == profile_sha
         and preflight_plan.get("overlay", {}).get("sha256") == overlay_sha,
         "collection preflight source, environment, or observer differs from this runtime admission")
    summary_binding = file_binding(summary_path)
    audit_binding = file_binding(audit_path)
    plan_binding = file_binding(plan_path)
    validate_preflight_receipt_chain(audit, cleanup, summary_binding, audit_binding, plan_binding)
    verified = {row.get("path"): row for row in audit.get("verified_outputs", []) if isinstance(row, dict)}
    need(len(verified) == len(audit.get("verified_outputs", [])),
         "preflight audit contains malformed or duplicate output paths")
    need(verified.get(summary_binding["path"]) == summary_binding
         and verified.get(plan_binding["path"]) == plan_binding,
         "preflight audit does not bind the exact current summary and plan bytes")
    diagnostics = []
    for phase in summary["phases"]:
        receipt_path = repo_path(str(phase.get("receipt", "")))
        need(receipt_path == run_dir / "phases" / str(phase.get("phase_id")) / "phase-receipt.json"
             and receipt_path.is_file() and not receipt_path.is_symlink(),
             {"preflight phase receipt escaped its exact case": phase.get("phase_id")})
        receipt_binding = file_binding(receipt_path)
        need(receipt_binding["sha256"] == phase.get("receipt_sha256")
             and verified.get(receipt_binding["path"]) == receipt_binding,
             {"preflight audit does not bind the exact phase receipt": phase.get("phase_id")})
        receipt = json.loads(receipt_path.read_text())
        need(receipt.get("phase_id") == phase.get("phase_id")
             and receipt.get("status") == phase.get("status")
             and receipt.get("source") == source
             and receipt.get("execution_mode") == "collection-only"
             and receipt.get("product_result") == "UNRUN",
             {"preflight phase receipt differs from the bound summary": phase.get("phase_id")})
        readset = receipt.get("readset", {})
        rows = readset.get("selection_diagnostics") if isinstance(readset, dict) else None
        need(isinstance(rows, list) and len(rows) == 1,
             {"preflight phase lacks its decisive identity diagnostic": phase.get("phase_id")})
        row = rows[0]
        binding = verified.get(row.get("path"))
        diagnostic_path = repo_path(str(row.get("path", "")))
        diagnostic_pid = row.get("pid")
        need(diagnostic_path.parent == receipt_path.parent / "observer"
             and diagnostic_path.name == f"selection-diagnostic-{diagnostic_pid}.json"
             and diagnostic_path.is_file() and not diagnostic_path.is_symlink(),
             {"preflight item diagnostic escaped its exact observer directory": phase.get("phase_id")})
        actual_diagnostic_binding = file_binding(diagnostic_path)
        need(isinstance(binding, dict) and binding == actual_diagnostic_binding
             and binding.get("sha256") == row.get("sha256")
             and binding.get("bytes") == row.get("bytes"),
             {"preflight audit did not read back its identity diagnostic": phase.get("phase_id")})
        diagnostic_value = json.loads(diagnostic_path.read_text())
        expected_phase = {"phase-a": "typed-worker", "phase-b": "prepared-removal"}.get(phase.get("phase_id"))
        expected_selectors = sorted(canonical_file_selector(item)
                                    for item in configured_phase_selectors(preflight_plan, str(phase.get("phase_id"))))
        diagnostic_items = diagnostic_value.get("items")
        need(diagnostic_value.get("schema") == "policyos.e02.c104.collection_identity_diagnostic.v1"
             and diagnostic_value.get("source") == observer_source_projection(source)
             and diagnostic_value.get("phase") == expected_phase
             and diagnostic_value.get("process", {}).get("pid") == diagnostic_pid
             and diagnostic_value.get("expected_file_selectors") == expected_selectors
             and isinstance(diagnostic_items, list)
             and sorted(row.get("canonical_selector") for row in diagnostic_items if isinstance(row, dict)) == expected_selectors
             and all(isinstance(item, dict) and item.get("qualification_error") is None for item in diagnostic_items),
             {"preflight item diagnostic content differs from the exact selected phase/source": phase.get("phase_id")})
        diagnostics.append(dict(row))
    return {
        "case_dir": str(run_dir.relative_to(R)),
        "summary": file_binding(summary_path),
        "audit": file_binding(audit_path),
        "cleanup": file_binding(cleanup_path),
        "plan": file_binding(plan_path),
        "source": source,
        "environment_profile_sha256": profile_sha,
        "overlay_sha256": overlay_sha,
        "selection_diagnostics": diagnostics,
        "product_result": "UNRUN; pytest collection-only preflight",
    }


def validate_preflight_receipt_chain(audit: dict[str, Any], cleanup: dict[str, Any],
                                     summary_binding: dict[str, Any], audit_binding: dict[str, Any],
                                     plan_binding: dict[str, Any]) -> None:
    """Bind the cleanup receipt to the exact audit, summary, plan, and recomputed process proof."""
    need(cleanup.get("audit_sha256") == audit_binding.get("sha256"),
         "cleanup readback does not bind the current audit bytes")
    need(cleanup.get("root_guard_before") == cleanup.get("root_guard_after"),
         "cleanup readback does not preserve the audited Root source frame")
    rows = audit.get("verified_outputs")
    need(isinstance(rows, list), "preflight audit output bindings are unavailable")
    outputs: dict[str, dict[str, Any]] = {}
    for row in rows:
        need(isinstance(row, dict) and isinstance(row.get("path"), str),
             "preflight audit output binding is malformed")
        need(row["path"] not in outputs, {"duplicate preflight audit output binding": row["path"]})
        outputs[row["path"]] = row
    need(outputs.get(summary_binding.get("path")) == summary_binding
         and outputs.get(plan_binding.get("path")) == plan_binding,
         "preflight audit output set does not bind the current summary and plan bytes")
    proof = audit.get("cleanup_process_proof")
    cleanup_proof = cleanup.get("process_proof")
    need(isinstance(proof, dict) and proof.get("schema") == "policyos.e02.c104.cleanup_process_proof.v2"
         and proof.get("summary_binding") == summary_binding
         and proof.get("plan_binding") == plan_binding
         and proof.get("all_started_command_exit_states_reconciled") is True
         and proof.get("all_observed_child_receipts_hash_bound") is True
         and proof.get("cleanup_authorized_by_recomputed_evidence") is True,
         "preflight audit lacks recomputed process proof for the current summary and plan")
    need(cleanup_proof == proof,
         "cleanup readback process proof differs from the audited recomputed proof")
    need(audit_binding.get("bytes", -1) >= 0 and isinstance(audit_binding.get("sha256"), str)
         and len(audit_binding["sha256"]) == 64,
         "current audit binding is malformed")


def validate_preflight_binding(binding: Any, source: dict[str, Any], profile_sha: str, overlay_sha: str) -> None:
    need(isinstance(binding, dict) and binding.get("source") == source
         and binding.get("environment_profile_sha256") == profile_sha
         and binding.get("overlay_sha256") == overlay_sha,
         "runtime plan is missing an exact collection-preflight source/profile binding")
    for field in ("summary", "audit", "cleanup", "plan"):
        verify_binding(binding.get(field, {}))
    run_dir = repo_path(str(binding.get("case_dir", "")))
    need(run_dir.parent == D and run_dir.name.startswith("c104-observer-r5-collection-preflight-"),
         "runtime preflight binding escaped its exact retained case")
    refreshed = validate_collection_preflight(run_dir, source, profile_sha, overlay_sha)
    for field in ("summary", "audit", "cleanup", "plan"):
        need(refreshed[field] == binding.get(field), {"collection preflight evidence changed": field})
    need(refreshed.get("selection_diagnostics") == binding.get("selection_diagnostics"),
         "collection preflight item identity diagnostics changed")


def check_overlay(expected: str, identity: dict[str, int] | None = None) -> dict[str, Any]:
    need(os.path.lexists(OVERLAY) and OVERLAY.is_file() and not OVERLAY.is_symlink(), "expected task observer overlay missing or not a regular file")
    st = OVERLAY.stat()
    actual = file_sha(OVERLAY)
    need(actual == expected, {"observer overlay changed": actual, "expected": expected})
    if identity:
        need(st.st_dev == identity["device"] and st.st_ino == identity["inode"], "observer overlay inode replaced")
    need(not git("ls-files", "--error-unmatch", OVERLAY_REL, check=False), "observer overlay became tracked")
    state = git("status", "--porcelain=v1", "--untracked-files=all", "--", OVERLAY_REL, check=False).strip()
    need(state == f"?? {OVERLAY_REL}", {"observer overlay status unexpected": state})
    return {"path": OVERLAY_REL, "sha256": actual, "bytes": st.st_size, "device": st.st_dev, "inode": st.st_ino}


def check_overlay_parent() -> None:
    need(OVERLAY.parent.is_dir() and OVERLAY.parent.resolve().is_relative_to(R.resolve()),
         "observer overlay parent is missing or outside the author checkout")
    current = OVERLAY.parent
    while current != R:
        need(not current.is_symlink(), {"observer overlay parent component is a symlink": str(current)})
        current = current.parent


def canonical_file_selector(selector: str) -> str:
    """Resolve a configured pytest selector to the repository-relative source path."""
    locator, separator, suffix = selector.partition("::")
    need(separator and locator and suffix, {"malformed configured pytest selector": selector})
    path = Path(locator)
    need(not path.is_absolute() and ".." not in path.parts and locator.startswith("tests/"),
         {"configured selector is not a project-relative test source": selector})
    resolved = (P / path).resolve()
    need(resolved.is_relative_to((P / "tests").resolve()), {"configured selector escaped tests root": selector})
    rel = resolved.relative_to(R.resolve()).as_posix()
    return f"{rel}::{suffix}"


def configured_phase_selectors(plan: dict[str, Any], phase_id: str) -> list[str]:
    if phase_id == "phase-a":
        rows = plan.get("phases", {}).get("phase-a")
    elif phase_id == "phase-b":
        rows = plan.get("phases", {}).get("phase-b")
    elif phase_id == "phase-c":
        rows = []
    else:
        raise Hold({"unknown C104 phase selector owner": phase_id})
    need(isinstance(rows, list) and all(isinstance(item, str) for item in rows),
         {"phase selector list is malformed": phase_id})
    return rows


def read_observers(obs: Path, head: str, tree: str, expected_overlay_sha: str, pytest_pid: int | None,
                   expected_selectors: list[str] | None = None,
                   collection_only: bool = False) -> dict[str, Any]:
    files = sorted(obs.glob("source-observer-*.json"))
    receipts = []
    selection_diagnostics = []
    issues = []
    tree_bytes = subprocess.check_output(["git", "-C", str(R), "ls-tree", "-rz", head])
    index = {}
    for row in tree_bytes.split(b"\0"):
        if row:
            metadata, rel = row.split(b"\t", 1)
            _mode, kind, blob = metadata.split(b" ")
            if kind == b"blob":
                index[os.fsdecode(rel)] = blob.decode("ascii")
    expected_canonical = [canonical_file_selector(item) for item in expected_selectors] if expected_selectors is not None else None
    expected_paths = {item.partition("::")[0] for item in expected_canonical or []}
    for path in files:
        try:
            value = json.loads(path.read_text())
        except Exception as exc:
            issues.append({"path": str(path), "error": f"{type(exc).__name__}: {exc}"})
            continue
        for problem in qualify_capture(value, R, index, OVERLAY_REL, expected_overlay_sha):
            issues.append({"path": str(path), "problem": problem})
        process = value.get("process", {})
        try:
            file_pid = int(path.stem.removeprefix("source-observer-"))
        except ValueError:
            file_pid = -1
        if process.get("pid") != file_pid:
            issues.append({"path": str(path), "problem": "filename/PID mismatch"})
        if value.get("source") != {"head": head, "tree": tree}:
            issues.append({"path": str(path), "problem": "source commit/tree mismatch"})
        origins = value.get("module_origins")
        sources = value.get("source_identities")
        if not isinstance(origins, list) or not isinstance(sources, list):
            issues.append({"path": str(path), "problem": "module/readset arrays missing"})
            origins, sources = [], []
        overlay_origins = [item for item in origins if isinstance(item, dict) and item.get("path") == OVERLAY_REL]
        if len(overlay_origins) != 1:
            issues.append({"path": str(path), "problem": "task observer source path is not uniquely admitted", "origins": overlay_origins})
        if expected_canonical is not None and process.get("pid") == pytest_pid:
            origin_paths = {item.get("path") for item in origins if isinstance(item, dict)}
            if not expected_paths <= origin_paths:
                issues.append({"path": str(path), "problem": "selected source path absent from path-based module census",
                               "expected_source_paths": sorted(expected_paths), "observed_source_paths": sorted(origin_paths)})
            meta = value.get("selection_diagnostic")
            diagnostic_path = obs / f"selection-diagnostic-{process.get('pid')}.json"
            try:
                need(isinstance(meta, dict), "collection observer omitted its durable item-identity diagnostic binding")
                claimed_path = Path(str(meta.get("path", "")))
                need(claimed_path.resolve() == diagnostic_path.resolve(), "selection diagnostic path differs from its process-bound location")
                need(diagnostic_path.is_file() and not diagnostic_path.is_symlink(), "selection diagnostic bytes are unavailable")
                diagnostic_bytes = diagnostic_path.read_bytes()
                diagnostic_sha = digest(diagnostic_bytes)
                need(meta.get("bytes") == len(diagnostic_bytes) and meta.get("sha256") == diagnostic_sha,
                     "selection diagnostic bytes differ from the observer receipt")
                diagnostic = json.loads(diagnostic_bytes)
                need(diagnostic.get("schema") == "policyos.e02.c104.collection_identity_diagnostic.v1"
                     and diagnostic.get("source") == {"head": head, "tree": tree}
                     and diagnostic.get("process", {}).get("pid") == pytest_pid,
                     "selection diagnostic identity differs from the admitted run")
                selection_diagnostics.append({"path": str(diagnostic_path.relative_to(R)),
                                              "sha256": diagnostic_sha, "bytes": len(diagnostic_bytes),
                                              "pid": pytest_pid,
                                              "selectors": diagnostic.get("expected_file_selectors", [])})
                if collection_only:
                    events = value.get("events", [])
                    need(isinstance(events, list) and not any(
                        isinstance(event, dict) and str(event.get("checkpoint", "")).startswith(("test-setup:", "test-teardown:"))
                        for event in events
                    ), "collection-only observer recorded a test setup/teardown event")
                need(diagnostic.get("expected_file_selectors") == sorted(expected_canonical),
                     "selection diagnostic expected selectors differ from the invoked selectors")
                rows = diagnostic.get("items")
                need(isinstance(rows, list), "selection diagnostic item list is malformed")
                actual = [row.get("canonical_selector") for row in rows if isinstance(row, dict)]
                need(len(rows) == len(expected_canonical) and len(actual) == len(expected_canonical)
                     and sorted(actual) == sorted(expected_canonical),
                     {"collection selected-set mismatch": {"expected": sorted(expected_canonical), "actual": actual}})
                by_path = {item.get("path"): item for item in sources if isinstance(item, dict)}
                for row in rows:
                    need(isinstance(row, dict), "selection diagnostic row is malformed")
                    canonical = row.get("canonical_selector")
                    source_rel, _separator, node_suffix = str(canonical).partition("::")
                    need(row.get("qualification_error") is None and source_rel in expected_paths,
                         {"selected item did not qualify to a commissioned source": row})
                    need(row.get("item_path_repo_relative") == source_rel
                         and row.get("node_file_path_repo_relative") == source_rel
                         and row.get("module_file_repo_relative") == source_rel
                         and row.get("function_code_filename_repo_relative") == source_rel,
                         {"selected item path/module/code source identities disagree": row})
                    need(isinstance(row.get("module_label"), str) and row.get("function_is_code_type") is True
                         and row.get("item_name") == node_suffix.rsplit("::", 1)[-1]
                         and row.get("function_code_name") == node_suffix.rsplit("::", 1)[-1].split("[", 1)[0],
                         {"selected item code identity differs from its selector": row})
                    identity = row.get("item_source_identity")
                    module_identity = row.get("module_file_source_identity")
                    function_identity = row.get("function_code_source_identity")
                    admitted = by_path.get(source_rel)
                    need(isinstance(identity, dict) and identity.get("classification") == "tracked-source"
                         and identity.get("matches_current_head") is True
                         and row.get("module_file_admitted_repo_path") == source_rel
                         and row.get("function_code_admitted_repo_path") == source_rel
                         and isinstance(module_identity, dict) and module_identity.get("classification") == "tracked-source"
                         and module_identity.get("actual_sha256") == identity.get("actual_sha256")
                         and isinstance(function_identity, dict) and function_identity.get("classification") == "tracked-source"
                         and function_identity.get("actual_sha256") == identity.get("actual_sha256")
                         and isinstance(admitted, dict)
                         and identity.get("actual_sha256") == admitted.get("actual_sha256")
                         and admitted.get("path") in origin_paths,
                         {"selected item source bytes/origin are not admitted": row})
            except Exception as exc:
                issues.append({"path": str(path), "problem": "selected item diagnostic did not reconcile",
                               "error": f"{type(exc).__name__}: {exc}"})
        by_path = {item.get("path"): item for item in sources if isinstance(item, dict)}
        for origin in origins:
            if not isinstance(origin, dict) or origin.get("path") not in by_path:
                issues.append({"path": str(path), "problem": "module origin lacks source identity"})
        for source in sources:
            if not isinstance(source, dict):
                issues.append({"path": str(path), "problem": "source identity is malformed"})
                continue
            rel = source.get("path")
            rel_path = Path(str(rel))
            if rel_path.is_absolute() or ".." in rel_path.parts or not (
                str(rel).startswith(("policy-engine/src/", "policy-engine/tests/", "policy-engine/tools/"))
                or rel == OVERLAY_REL
            ):
                issues.append({"path": str(path), "problem": "source identity escaped admitted in-repository roots", "source_path": rel})
                continue
            if rel == OVERLAY_REL:
                if source.get("classification") != "task-authored-observer-overlay" or source.get("actual_sha256") != expected_overlay_sha:
                    issues.append({"path": str(path), "problem": "task observer bytes mismatch"})
            elif source.get("classification") != "tracked-source" or source.get("matches_current_head") is not True:
                issues.append({"path": str(path), "problem": "loaded in-repo source is not current HEAD", "source": source})
            else:
                physical = R / str(rel)
                if not physical.is_file() or file_sha(physical) != source.get("actual_sha256"):
                    issues.append({"path": str(path), "problem": "current source bytes differ from observed", "source_path": rel})
        receipts.append({"path": str(path.relative_to(R)), "sha256": file_sha(path), "bytes": path.stat().st_size,
                         "pid": process.get("pid"), "ppid": process.get("ppid"), "role": process.get("role"),
                         "module_origin_count": len(origins), "source_identity_count": len(sources),
                         "target_frame_count": len(value.get("target_code_frames", []))})
    if expected_canonical and not collection_only:
        child_rows = [row for row in receipts if row["pid"] != pytest_pid]
        if len(child_rows) != len(expected_canonical):
            issues.append({"problem": "one actual observer child per selected positive case required"})
        required = {"execute_decimal_worker", "run_node_in_worker_sync", "run_node_in_worker",
                    "deserialize_state", "serialize_outcome", "DecimalTransportNode.execute"}
        for row in child_rows:
            value = json.loads((R / row["path"]).read_text())
            frames = value.get("target_code_frames", [])
            names = {item.get("qualname") for item in frames if item.get("pid") == row["pid"]
                     and item.get("same_process_function_code_identity") is True}
            if row.get("ppid") != pytest_pid or row.get("role") != "outer-worker:execute_decimal_worker" or not required <= names:
                issues.append({"problem": "positive child required actual source-bound target frames absent", "pid": row["pid"]})
    parent_present = pytest_pid is None or any(row.get("pid") == pytest_pid for row in receipts)
    if not files:
        issues.append({"problem": "observer receipts absent"})
    return {"qualified": not issues and parent_present, "receipt_count": len(files), "parent_pid": pytest_pid,
            "parent_receipt_present": parent_present, "receipts": receipts,
            "selection_diagnostics": selection_diagnostics, "problems": issues}


def junit(monitor: Any, path: Path | None) -> dict[str, Any]:
    if path is None or not path.is_file() or path.is_symlink():
        return {"present": False, "summary": None, "testcases": []}
    summary = monitor.junit_summary(path)
    cases = ET.parse(path).getroot().iter("testcase")
    records = [{"classname": c.get("classname"), "name": c.get("name"), "failure": c.find("failure") is not None,
                "error": c.find("error") is not None, "skipped": c.find("skipped") is not None} for c in cases]
    return {"present": True, "path": str(path.relative_to(R)), "summary": summary, "testcases": records,
            "bytes": path.stat().st_size, "sha256": file_sha(path)}


def file_binding(path: Path) -> dict[str, Any]:
    need(path.is_file() and not path.is_symlink(), {"deciding file missing or non-regular": str(path)})
    return {"path": str(path.relative_to(R)), "bytes": path.stat().st_size, "sha256": file_sha(path)}


def repo_path(relative: str) -> Path:
    rel = Path(relative)
    need(not rel.is_absolute() and ".." not in rel.parts, {"unsafe repository locator": relative})
    path = R / rel
    need(path.resolve().is_relative_to(R.resolve()), {"repository locator escaped checkout": relative})
    return path


def verify_binding(binding: dict[str, Any]) -> dict[str, Any]:
    rel = Path(str(binding.get("path", "")))
    path = repo_path(str(rel))
    need(path.is_file() and not path.is_symlink(), {"evidence path unavailable": binding})
    actual = {"path": str(rel), "bytes": path.stat().st_size, "sha256": file_sha(path)}
    need(actual["bytes"] == binding.get("bytes") and actual["sha256"] == binding.get("sha256"),
         {"evidence readback mismatch": binding, "actual": actual})
    return actual


def classify(monitor_result: dict[str, Any], junit_result: dict[str, Any], observer_result: dict[str, Any], selectors: list[str]) -> str:
    if (not monitor_result.get("complete") or monitor_result.get("process_group_gone") is not True
            or monitor_result.get("aborted_reason") or monitor_result.get("sample_count", 0) < 1):
        return "ERROR"
    summary = junit_result.get("summary")
    expected_cases = []
    for selector in selectors:
        path, node = selector.split("::", 1)
        module = Path(path).with_suffix("").as_posix().replace("/", ".")
        expected_cases.append((module, node))
    actual_cases = [(item.get("classname"), item.get("name")) for item in junit_result.get("testcases", [])]
    if (not junit_result.get("present") or not summary or summary.get("tests") != len(selectors)
            or sorted(actual_cases) != sorted(expected_cases) or not observer_result.get("qualified")):
        return "ERROR"
    if summary.get("errors"):
        return "ERROR"
    if summary.get("failures"):
        return "FAIL"
    if summary.get("skipped"):
        return "SKIP"
    return "PASS" if monitor_result.get("return_code") == 0 else "ERROR"


def build_command(name: str, phase: str, selectors: list[str], root: Path, head: str, tree: str,
                  collect_only: bool = False) -> tuple[list[str], dict[str, str], Path | None]:
    obs = root / "observer"
    for dirname in ("observer", "pycache", "pytest-cache", "pytest-basetemp", "benchmarks", "tmp", "monitor", "xdg-cache", "stack"):
        (root / dirname).mkdir(exist_ok=False)
    python = P / ".venv/bin/python"
    env = {"E02_C104_ROOT": str(R), "E02_C104_EXPECTED_HEAD": head, "E02_C104_EXPECTED_TREE": tree,
           "E02_C104_PHASE": phase, "E02_C104_OBSERVATION_DIR": str(obs),
           "E02_A_STACK_DIR": str(root / "stack"),
           "PYTHONPYCACHEPREFIX": str(root / "pycache"), "TMPDIR": str(root / "tmp"),
           "TMP": str(root / "tmp"), "TEMP": str(root / "tmp"), "XDG_CACHE_HOME": str(root / "xdg-cache")}
    if name == "phase-c":
        code = f"import runpy; runpy.run_path({str(R2 / 'phase_c_spawn_witness.py')!r}, run_name='__main__')"
        return [str(python), "-B", "-c", code], env, None
    junit_path = root / "junit.xml"
    argv = [str(python), "-B", "-m", "pytest", "-p", "tests._helpers.r2_source_observer", *selectors,
            *( ["--collect-only"] if collect_only else [] ),
            "-o", f"cache_dir={root / 'pytest-cache'}", f"--benchmark-storage=file://{root / 'benchmarks'}",
            f"--basetemp={root / 'pytest-basetemp'}", f"--junitxml={junit_path}", "--tb=short", "--color=no", "--maxfail=0"]
    return argv, env, junit_path


def append_event(path: Path, value: dict[str, Any]) -> None:
    with path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(value, sort_keys=True) + "\n")
        stream.flush()
        os.fsync(stream.fileno())


def check_prior_release(path: Path, monitor: Any, overlay_expected: bool = False) -> dict[str, Any]:
    """Reconcile a real preserving release and recompute the complete old PID set."""
    prior = R / "LOCAL/raw/e02-execution-20261027/diagnostics/phase-a-profiler-off-r1/runs/c104-a-stdlib-profiler-off-r1"
    need(path.is_absolute() and path.resolve().is_relative_to((R / "LOCAL/raw").resolve())
         and path.is_file() and not path.is_symlink(), "a real Root preserving-release receipt is required")
    release = json.loads(path.read_text())
    need(release.get("removed_only") == OVERLAY_REL and release.get("overlay_absent_after") is True
         and release.get("move_action") == "os.rename", "prior runtime overlay was not preserved and released")
    verify_binding(release.get("retained_overlay", {}))
    need(release["retained_overlay"]["sha256"] == "406bdbdac474a92abac70281b30233e84c2b7b164a0a47648a822538d825bb49",
         "prior retained overlay differs from actual profiled baseline")
    if not overlay_expected:
        need(not os.path.lexists(OVERLAY), "canonical observer path is not released")
    summary_path = prior / "run-summary.json"
    need(file_sha(summary_path) == "f71c3440ab2fbe50dd2ea050fe4b52237991088977840d915f469e089f243fff", "historical runtime summary changed")
    summary = json.loads(summary_path.read_text())
    created_binding = next(row for row in summary["artifacts"] if Path(row["path"]).name == "overlay-created.json")
    verify_binding(created_binding)
    created = json.loads(repo_path(created_binding["path"]).read_text())
    retained_stat = repo_path(release["retained_overlay"]["path"]).stat()
    need(retained_stat.st_dev == created["device"] and retained_stat.st_ino == created["inode"],
         "prior retained observer does not conserve its admitted inode/device")
    proof = release.get("process_proof", {})
    for command in proof.get("started_commands", []):
        for key in ("phase_receipt", "monitor_result", "invocation", "process_tree"):
            if command.get(key) is not None:
                verify_binding(command[key])
        for key in ("observer_receipts", "child_receipts"):
            for binding in command.get(key, []):
                verify_binding(binding)
    need(proof.get("summary_binding") == file_binding(summary_path), "release is not bound to the actual prior runtime")
    expected_child_sha256 = {'01-positive-typed': '1dd5581f64413eb18a922c5b473744e0ce1c7bb1f0ed42a13723bcc8a8305daf', '02-negative-malformed-typed': '00980c7e0f085eef2333e65325d11dab40f405f388c7336bed37cc9948309102', '03-removal-malformed-untyped': '7a5c6b22ae1e363f8e334558c3fa41d6d254f2875b990738965f0f71c79c139c', '04-restored-malformed-typed': 'ed5803ada10278f22b8f4cf5e95f83662a677c4d9c3355b914f7fc586caae871'}
    pids: set[int] = set()
    groups: set[int] = set()
    for row in summary["phases"]:
        receipt_path = repo_path(row["receipt"])
        need(file_sha(receipt_path) == row["receipt_sha256"], "historical phase receipt changed")
        receipt = json.loads(receipt_path.read_text())
        result = receipt["monitor"]
        need(type(result.get("pid")) is int and result.get("complete") is True
             and result.get("process_group_gone") is True, "prior command exit is incomplete")
        pids.add(result["pid"])
        groups.add(result["pid"])
        tree = verify_binding(receipt["outputs"]["process_tree"])
        samples = [json.loads(line) for line in repo_path(tree["path"]).read_text().splitlines()]
        need(len(samples) == result["sample_count"], "prior process sample denominator changed")
        for sample in samples:
            need(sample["command_id"] == row["phase_id"] and sample["kind"] == "sample", "prior sample identity differs")
            for process in sample["processes"]:
                pids.add(process["pid"])
                groups.add(process["pgid"])
        for observed in receipt["readset"]["receipts"]:
            observed_path = repo_path(observed["path"])
            need(file_sha(observed_path) == observed["sha256"], "prior observer bytes changed")
            value = json.loads(observed_path.read_text())
            need(value["process"]["pid"] == observed["pid"], "prior observer PID differs")
            pids.add(observed["pid"])
        if row["phase_id"] == "phase-c":
            files = sorted((prior / "phases/phase-c/phase-c").glob("*/receipt.json"))
            need(len(files) == len(c104_cleanup_gate.CHILD_CASES), "prior child receipt set is incomplete")
            for child_path in files:
                need(file_sha(child_path) == expected_child_sha256.get(child_path.parent.name), "historical child receipt changed")
                value = json.loads(child_path.read_text())
                need(value["case"] in c104_cleanup_gate.CHILD_CASES, "prior child case differs")
                pids.add(value["process"]["process_object_pid"])
    need(pids == set(proof.get("observed_pids", [])) and groups == set(proof.get("observed_process_group_ids", [])),
         "release process sets do not reconcile with the complete raw prior runtime")
    need(not any(process_pid_is_live(pid) for pid in pids)
         and not any(monitor.process_group_exists(group) for group in groups), "a prior numeric PID/group identifier is currently live; hold without inferring ownership")
    return file_binding(path)


def prepare(args: argparse.Namespace) -> int:
    monitor, native, guard_module = apis()
    need(PKG.is_dir() and not PKG.is_symlink() and D.is_dir() and not D.is_symlink(),
         {"retained driver packet or D output root is unavailable": {"packet": str(PKG), "D": str(D)}})
    need(sys.platform == "darwin" and Path("/usr/bin/sandbox-exec").is_file(),
         {"unsupported local execution platform": {"platform": sys.platform, "sandbox_exec": Path("/usr/bin/sandbox-exec").is_file()}})
    need(re.fullmatch(r"[0-9a-f]{40}", args.head) and re.fullmatch(r"[0-9a-f]{40}", args.tree), "full source SHA and tree required")
    need(re.fullmatch(r"r[0-9]+", args.revision), "revision must be rN")
    need(args.mode == "diagnostic", "only the commissioned single-A diagnostic is admitted")
    source = identity(monitor, args.head, args.tree)
    release_binding = check_prior_release(args.release_receipt, monitor)
    root_guard = guard(guard_module)
    need(root_guard.get("head") == args.head, "Root guard is not at requested source")
    source_bytes, frame = frame_bytes(root_guard)
    source_status = source_status_state(overlay_expected=False)
    check_overlay_parent()
    python = P / ".venv/bin/python"
    need(python.is_file() and os.access(python, os.X_OK), "existing product venv Python is unavailable; do not reinstall")
    source_review = check_reviewed_sources(args.head)
    input_pins = pins()
    profile = env_profile(python)
    check_environment(profile)
    profile_sha = canonical_sha(environment_fingerprint(profile))
    resources = resource_sample(native)
    need(bool(monitor.NUMERIC_THREADS) and all(value == "1" for value in monitor.NUMERIC_THREADS.values()),
         {"retained supervisor does not enforce one numeric thread": monitor.NUMERIC_THREADS})
    need(not os.path.lexists(OVERLAY), "observer overlay path already exists; never overwrite")
    need(not git("ls-files", "--error-unmatch", OVERLAY_REL, check=False), "observer overlay path is already tracked")
    overlay_sha = file_sha(OBSERVER_SOURCE)
    preflight_binding = None
    case_id = f"c104-measured-positive-a-style-r2-{args.revision}"
    execution_phase_order = ["phase-a"]
    need(not (D / case_id).exists(), "append-only native output path already exists")
    plan_name = f"plan-{args.mode}-{args.revision}.json"
    need(not (PKG / plan_name).exists(), "append-only plan path already exists")
    sandbox = json.loads(SANDBOX_JSON.read_text())
    need(digest(sandbox["fragment"].encode()) == SANDBOX_FRAGMENT_SHA and file_sha(SANDBOX_PLAN) == SANDBOX_PLAN_SHA, "retained sandbox bytes changed")
    plan = {
        "schema": "policyos.e02.c104.local_root_driver_plan.v2", "revision": args.revision,
        "mode": args.mode, "case_id": case_id, "created_at": utc(),
        "source": source, "root_guard": root_guard, "root_live_sha256": file_sha(LIVE),
        "source_frame": frame, "source_frame_readback_bytes": len(source_bytes),
        "source_status_baseline": source_status, "reviewed_c104_source_reconciliation": source_review,
        "input_pins": input_pins, "environment_profile": profile,
        "environment_profile_sha256": profile_sha, "resource_snapshot": resources,
        "limits": {"sampled_process_tree_rss_bytes": RSS_CAP, "free_disk_floor_bytes": DISK_FLOOR,
                   "overall_wall_seconds": WALL_CAP, "sample_interval_seconds": SAMPLE_SECONDS,
                   "numeric_threads": monitor.NUMERIC_THREADS, "one_job_at_a_time": True},
        "sandbox": {"source": str(SANDBOX_JSON.relative_to(R)), "source_sha256": SANDBOX_JSON_SHA,
                    "source_plan": str(SANDBOX_PLAN.relative_to(R)), "fragment_sha256": SANDBOX_FRAGMENT_SHA,
                    "fragment": sandbox["fragment"], "writes": "case directory and /dev/null only",
                    "network_denied": True, "production_data_read_denied": True},
        "phases": {"phase-a": PHASE_A, "phase-b": PHASE_B, "phase-c": {"four_spawn_cases": True}},
        "phase_order": ["phase-a", "phase-b", "phase-c"],
        "execution_phase_order": execution_phase_order,
        "collection_preflight": preflight_binding,
        "prior_runtime_release": release_binding,
        "diagnostic_only": True,
        "product_result": "UNADJUDICATED_DIAGNOSTIC",
        "diagnostic_basis": json.loads((PKG / "bound-basis.json").read_text()),
        "overlay": {"path": OVERLAY_REL, "sha256": overlay_sha,
                    "preimage_absent": True, "exclusive_create": True, "explicit_cleanup_only": True},
        "classification": {"PASS": "raw single selected pytest case passed; diagnostic only",
                           "FAIL": "raw pytest assertion failed; no product timeout verdict until cause review", "ERROR": "setup/source/profile/monitor uncertainty",
                           "SKIP": "reported skip", "UNRUN": "not launched"},
        "boundaries": ["actual current source must retain all six reviewed C104 R2 blobs",
                       "source identity is determined by resolved item path, pytest node file path, module file, and the test function CodeType filename; module labels are evidence but not selectors",
                       "module census includes loaded modules from declared in-repository source roots by resolved source path, regardless of import label",
                       "single diagnostic only; exact source/profile and prior runtime preserving-release proof are rechecked; no A/B/C acceptance",
                       "Darwin spawn evidence only; Linux timed/fork remains UNRUN", "no G acceptance or closure"],
    }
    plan_path = PKG / plan_name
    save_new(plan_path, plan)
    print(json.dumps({"status": "PREPARED_NOT_RUN", "plan": str(plan_path.relative_to(R)),
                      "sha256": file_sha(plan_path), "source": source, "resources": resources,
                      "source_frame": frame}, sort_keys=True))
    return 0


def sanitized_environment() -> dict[str, str]:
    old = {}
    for name in CLEAR_ENV:
        if name in os.environ:
            old[name] = os.environ.pop(name)
    return old


def restore_environment(old: dict[str, str]) -> None:
    os.environ.update(old)


def one_phase(name: str, phase: str, selectors: list[str], case: Path, plan: dict[str, Any], monitor: Any,
              native: Any, guard_module: Any, overlay_identity: dict[str, int], sandbox: Path,
              wall_start: float, wall_deadline: float, collect_only: bool = False) -> dict[str, Any]:
    root = case / "phases" / name
    root.mkdir(exist_ok=False)
    before_guard = check_live(plan, monitor, guard_module)
    overlay_before = check_overlay(plan["overlay"]["sha256"], overlay_identity)
    resources_before = resource_sample(native)
    profile_before = env_profile(P / ".venv/bin/python")
    need(environment_fingerprint(profile_before) == environment_fingerprint(plan["environment_profile"]), "Python/plugin/.pth profile changed")
    argv, extra_env, junit_path = build_command(name, phase, selectors, root, plan["source"]["head"],
                                                plan["source"]["tree"], collect_only=collect_only)
    invocation = {"argv": argv, "cwd": str(P), "phase": phase, "selectors": selectors,
                  "junitxml": str(junit_path) if junit_path else None,
                  "pytest_autoload": "default enabled; only task-authored C104 observer overlay explicitly loaded",
                  "collection_only": collect_only,
                  "product_test_bodies_run": False if collect_only else None}
    save_new(root / "invocation.json", invocation)
    monitored_argv = ["/usr/bin/sandbox-exec", "-f", str(sandbox), *argv]
    result = monitor.run_command(root / "monitor", name, monitored_argv, P, wall_start, wall_deadline, extra_env)
    save_new(root / "monitor-result.json", result)
    observers = read_observers(root / "observer", plan["source"]["head"], plan["source"]["tree"],
                               plan["overlay"]["sha256"], result.get("pid"), selectors if selectors else None,
                               collection_only=collect_only)
    junit_data = junit(monitor, junit_path)
    if collect_only:
        status = ("COLLECTION_PASS" if name in {"phase-a", "phase-b"} and selectors
                  and result.get("complete") is True and result.get("process_group_gone") is True
                  and result.get("return_code") == 0 and observers.get("qualified") is True
                  else "ERROR")
    else:
        status = classify(result, junit_data, observers, selectors) if name != "phase-c" else "ERROR"
    phase_c = None
    if name == "phase-c":
        croot = root / "phase-c"
        try:
            control_paths = [croot / item for item in ("path-binding-control.json", "synthetic-code-identity-control.json")]
            controls = [json.loads(path.read_text()) for path in control_paths]
            summary_path = croot / "summary.json"
            summary = json.loads(summary_path.read_text())
            case_names = ("01-positive-typed", "02-negative-malformed-typed", "03-removal-malformed-untyped", "04-restored-malformed-typed")
            expected_roles = ("outer-worker:execute_decimal_worker", "outer-worker:execute_decimal_worker",
                              "outer-worker:execute_decimal_worker_without_budget_tag", "outer-worker:execute_decimal_worker")
            case_paths = [croot / case_name / "receipt.json" for case_name in case_names]
            cases = [json.loads(path.read_text()) for path in case_paths]
            child_by_pid = {row.get("pid"): row for row in observers["receipts"] if row.get("pid") != result.get("pid")}
            parent_rows = [row for row in observers["receipts"] if row.get("pid") == result.get("pid")]
            child_scope_ok = (len(observers["receipts"]) == 5 and len(child_by_pid) == 4
                              and len(parent_rows) == 1 and parent_rows[0].get("role") == "observer-process")
            child_checks = []
            for case_name, expected_role, item in zip(case_names, expected_roles, cases, strict=True):
                receipt = item.get("receipt", {})
                process = receipt.get("process", {})
                binding = receipt.get("source_binding", {})
                pid = process.get("process_object_pid")
                observed = child_by_pid.get(pid)
                delivery = receipt.get("observer_delivery", {})
                attempt = receipt.get("attempt_bytes", {})
                attempt_path = Path(receipt.get("inputs", {}).get("attempts_path", ""))
                attempt_path = attempt_path if attempt_path.is_absolute() else R / attempt_path
                need(attempt_path.resolve().is_relative_to(croot.resolve()),
                     {"child attempt path escaped private C104 case": str(attempt_path)})
                if attempt.get("absent"):
                    attempt_file_ok = not attempt_path.exists()
                else:
                    attempt_file_ok = attempt_path.is_file() and file_sha(attempt_path) == attempt.get("sha256") and attempt_path.stat().st_size == attempt.get("length")
                result_bytes = receipt.get("actual_result_bytes")
                if result_bytes:
                    decoded = base64.b64decode(result_bytes.get("base64", ""), validate=True)
                    result_bytes_ok = len(decoded) == result_bytes.get("length") and digest(decoded) == result_bytes.get("sha256")
                else:
                    result_bytes_ok = True
                frame_rows = binding.get("selected_actual_frames", [])
                delivered_path = Path(delivery.get("path", ""))
                delivered_path_matches = bool(observed and delivered_path.is_absolute()
                                              and delivered_path.resolve() == (R / observed["path"]).resolve())
                child_ok = bool(
                    receipt.get("case") == case_name
                    and pid is not None and observed is not None
                    and observed.get("ppid") == result.get("pid")
                    and observed.get("role") == expected_role
                    and process.get("parent_pid") == result.get("pid")
                    and process.get("child_exit_code") == 0 and process.get("child_observed_message") is True
                    and delivery.get("sha256") == observed.get("sha256")
                    and delivered_path_matches
                    and binding.get("valid") is True
                    and frame_rows and all(frame.get("pid") == pid and frame.get("same_process_function_code_identity") is True for frame in frame_rows)
                    and attempt_file_ok and result_bytes_ok
                )
                child_checks.append({"case": case_name, "pid": pid, "expected_role": expected_role,
                                     "observed_pid": observed.get("pid") if observed else None,
                                     "observed_role": observed.get("role") if observed else None,
                                     "observer_sha256": observed.get("sha256") if observed else None,
                                     "actual_child_readset_bound": child_ok,
                                     "attempt_file": file_binding(attempt_path) if attempt_path.is_file() else {"absent": True},
                                     "receipt_file": file_binding(case_paths[len(child_checks)])})
            binding_ok = (child_scope_ok and len({row.get("pid") for row in child_checks}) == 4
                          and all(row["actual_child_readset_bound"] for row in child_checks))
            controls_ok = all(item.get("passed") is True for item in controls)
            controls_well_formed = len(controls) == 2 and all(isinstance(item.get("passed"), bool) for item in controls)
            verdicts_ok = summary.get("verdicts") == [True, True, True, True] and summary.get("source_binding_valid_for_each_case") == [True, True, True, True]
            phase_c = {"controls": controls, "control_files": [file_binding(path) for path in control_paths],
                       "summary": summary, "summary_file": file_binding(summary_path),
                       "child_receipt_count": len(cases), "child_checks": child_checks,
                       "observer_scope_exactly_parent_plus_four_children": child_scope_ok,
                       "child_source_bindings_valid": binding_ok, "controls_well_formed": controls_well_formed,
                       "all_controls_pass": controls_ok,
                       "all_verdicts_pass": verdicts_ok}
            fully_observed = (result.get("complete") and result.get("process_group_gone") is True
                              and observers.get("qualified") and binding_ok and controls_well_formed)
            status = ("PASS" if fully_observed and controls_ok and result.get("return_code") == 0 and verdicts_ok
                      else "FAIL" if fully_observed and controls_ok and not verdicts_ok
                      else "ERROR")
        except Exception as exc:
            phase_c = {"error": f"{type(exc).__name__}: {exc}"}
            status = "ERROR"
    outputs = {}
    monitor_dir = root / "monitor"
    for key in ("stdout_path", "stderr_path"):
        path = monitor_dir / str(result[key]) if result.get(key) else None
        outputs[key] = {"path": str(path.relative_to(R)), "bytes": path.stat().st_size, "sha256": file_sha(path)} if path and path.is_file() else {"missing": True}
    tree_log = monitor_dir / "process-tree.jsonl"
    outputs["process_tree"] = {"path": str(tree_log.relative_to(R)), "bytes": tree_log.stat().st_size, "sha256": file_sha(tree_log)} if tree_log.is_file() else {"missing": True}
    deciding_files = [file_binding(root / "invocation.json"), file_binding(root / "monitor-result.json")]
    if junit_data.get("present"):
        deciding_files.append({"kind": "junit", **{k: junit_data[k] for k in ("path", "bytes", "sha256")}})
    for key in ("controller-events.jsonl", "phase-output.jsonl"):
        path = monitor_dir / key
        if path.is_file():
            deciding_files.append({"kind": key, **file_binding(path)})
    for observer_row in observers["receipts"]:
        deciding_files.append({"kind": "source-observer", **{k: observer_row[k] for k in ("path", "bytes", "sha256")}})
    for diagnostic_row in observers.get("selection_diagnostics", []):
        deciding_files.append({"kind": "selection-diagnostic", **{k: diagnostic_row[k] for k in ("path", "bytes", "sha256")}})
    if phase_c is not None:
        deciding_files.extend(phase_c.get("control_files", []))
        if phase_c.get("summary_file"):
            deciding_files.append(phase_c["summary_file"])
        for child in phase_c.get("child_checks", []):
            deciding_files.append(child["receipt_file"])
            attempt_binding = child.get("attempt_file", {})
            if attempt_binding.get("path"):
                deciding_files.append(attempt_binding)
    stack_artifacts = [file_binding(path) for path in sorted((root / "stack").iterdir()) if path.is_file()]
    deciding_files.extend({"kind": "five-second-stack-diagnostic", **row} for row in stack_artifacts)
    outputs["stack_artifacts"] = stack_artifacts
    outputs["deciding_files"] = deciding_files
    after_guard = check_live(plan, monitor, guard_module)
    overlay_after = check_overlay(plan["overlay"]["sha256"], overlay_identity)
    resources_after = resource_sample(native)
    profile_after = env_profile(P / ".venv/bin/python")
    need(environment_fingerprint(profile_after) == environment_fingerprint(plan["environment_profile"]), "Python/plugin/.pth profile changed during phase")
    receipt = {"schema": "policyos.e02.c104.local_phase_driver_receipt.v1", "phase_id": name,
               "status": status, "source": plan["source"], "before": {"guard": before_guard, "overlay": overlay_before, "resources": resources_before},
               "after": {"guard": after_guard, "overlay": overlay_after, "resources": resources_after},
               "environment_profile": {"before_sha256": canonical_sha(environment_fingerprint(profile_before)),
                                       "after_sha256": canonical_sha(environment_fingerprint(profile_after)),
                                       "before_removed_controls": profile_before.get("ambient_controls_removed", []),
                                       "after_removed_controls": profile_after.get("ambient_controls_removed", []),
                                       "matches_prepared_profile": canonical_sha(environment_fingerprint(profile_after)) == plan["environment_profile_sha256"]},
               "invocation": invocation, "monitor": result, "outputs": outputs,
               "execution_mode": "collection-only" if collect_only else "runtime",
               "product_result": "UNRUN" if collect_only else "UNADJUDICATED_DIAGNOSTIC",
               "junit": junit_data, "readset": observers, "phase_c": phase_c,
               "G_acceptance": False, "closure_ids": []}
    save_new(root / "phase-receipt.json", receipt)
    return receipt


def execute(plan_path: Path, expected_mode: str) -> int:
    need(plan_path.is_absolute() and plan_path.parent == PKG and plan_path.is_file() and not plan_path.is_symlink(), "use an absolute regular plan in this packet")
    plan = json.loads(plan_path.read_text())
    need(plan.get("mode") == expected_mode, {"plan mode does not match action": {"plan": plan.get("mode"), "action": expected_mode}})
    plan["_runtime_binding"] = {"path": str(plan_path.relative_to(R)), "sha256": file_sha(plan_path)}
    monitor, native, guard_module = apis()
    input_pins = dict(plan["input_pins"])
    input_pins[str(plan_path.relative_to(R))] = file_sha(plan_path)
    need(not check_pins(input_pins), "prepared input pins changed")
    check_live(plan, monitor, guard_module)
    current_profile = env_profile(P / ".venv/bin/python")
    check_environment(current_profile)
    need(environment_fingerprint(current_profile) == environment_fingerprint(plan["environment_profile"]),
         "prepared Python/plugin/.pth profile changed before overlay staging")
    resources = resource_sample(native)
    case = D / plan["case_id"]
    need(not case.exists() and not case.is_symlink(), "append-only D case path already exists")
    case.mkdir(parents=False, exist_ok=False)
    (case / "phases").mkdir(exist_ok=False)
    source_bytes, source_frame = frame_bytes(plan["root_guard"])
    save_new(case / "root-input-bindings.json", {
        "root_live": file_binding(LIVE),
        "root_source_frame": source_frame,
    })
    need(digest(source_bytes) == plan["source_frame"]["sha256"], "current source frame differs from admission")
    sandbox = case / "child.sb"
    fragment = plan["sandbox"]["fragment"]
    need(digest(fragment.encode()) == plan["sandbox"]["fragment_sha256"], "retained sandbox fragment digest mismatch")
    write_new(sandbox, ("(version 1)\n(allow default)\n(deny file-write*)\n(allow file-write* (subpath " + json.dumps(str(case)) + "))\n(allow file-write* (literal \"/dev/null\"))\n" + fragment).encode())
    startup = {"schema": "policyos.e02.c104.local_source_profile_freeze.v2", "at": utc(),
               "plan": str(plan_path.relative_to(R)), "plan_sha256": file_sha(plan_path),
               "mode": plan["mode"],
               "source": plan["source"], "root_guard_sha256": canonical_sha(plan["root_guard"]),
               "root_live_sha256": plan["root_live_sha256"],
               "source_frame_reference": source_frame,
               "environment_profile_sha256": plan["environment_profile_sha256"],
               "resources": resources, "sandbox": {"path": str(sandbox.relative_to(R)), "sha256": file_sha(sandbox)},
               "phase_order": plan["execution_phase_order"],
               "overlay": "not yet written"}
    save_new(case / "source-profile-freeze.json", startup)
    old_env = sanitized_environment()
    try:
        need(not os.path.lexists(OVERLAY), "overlay preimage is not absent; do not overwrite")
        check_overlay_parent()
        need(git("status", "--porcelain=v1", "--untracked-files=all", "--", OVERLAY_REL, check=False).strip() == "", "overlay destination already has Git status")
        overlay_bytes = OBSERVER_SOURCE.read_bytes()
        need(digest(overlay_bytes) == plan["overlay"]["sha256"], "task observer bytes differ from plan")
        write_new(case / "observer-overlay-source.py", overlay_bytes)
        write_new(OVERLAY, overlay_bytes)
        stat = OVERLAY.stat()
        overlay_identity = {"device": stat.st_dev, "inode": stat.st_ino}
        overlay = check_overlay(plan["overlay"]["sha256"], overlay_identity)
        save_new(case / "overlay-created.json", {"path": OVERLAY_REL, "preimage_absent": True, "created_exclusive": True, **overlay})
        events = case / "events.jsonl"
        with events.open("x", encoding="utf-8") as stream:
            stream.write(json.dumps({"event": "overlay_created", "at": utc(), "overlay": overlay}) + "\n")
        monitor.RSS_CAP_BYTES = RSS_CAP
        monitor.DISK_FLOOR_BYTES = DISK_FLOOR
        monitor.SAMPLE_SECONDS = SAMPLE_SECONDS
        need(monitor.run_command.__globals__ is monitor.__dict__
             and monitor.run_command.__globals__["RSS_CAP_BYTES"] == RSS_CAP
             and monitor.run_command.__globals__["DISK_FLOOR_BYTES"] == DISK_FLOOR,
             "effective monitor resource globals differ from the admitted diagnostic")
        save_new(case / "effective-monitor-bindings.json", {"rss_cap_bytes": monitor.run_command.__globals__["RSS_CAP_BYTES"],
                 "disk_floor_bytes": monitor.run_command.__globals__["DISK_FLOOR_BYTES"],
                 "wall_seconds": WALL_CAP, "monitor_sha256": file_sha(MONITOR)})
        signal.signal(signal.SIGTERM, monitor.note_stop_signal)
        signal.signal(signal.SIGINT, monitor.note_stop_signal)
        wall_start = time.monotonic()
        wall_deadline = wall_start + WALL_CAP
        phases = []
        stop = None
        phase_specs = [("phase-a", "typed-worker", PHASE_A)]
        for name, phase, selectors in phase_specs:
            try:
                receipt = one_phase(name, phase, selectors, case, plan, monitor, native, guard_module,
                                    overlay_identity, sandbox, wall_start, wall_deadline,
                                    collect_only=plan["mode"] == "collection-preflight")
                phases.append(receipt)
                append_event(events, {"event": "phase_finished", "phase": name, "status": receipt["status"], "pid": receipt["monitor"].get("pid"), "at": utc()})
                if not receipt["readset"].get("qualified"):
                    stop = f"{name}_readset_not_qualified"
                    break
                if not receipt["monitor"].get("complete") or receipt["monitor"].get("process_group_gone") is not True:
                    stop = f"{name}_process_exit_not_established"
                    break
            except Exception as exc:
                stop = f"{name}_driver_error:{type(exc).__name__}:{exc}"
                append_event(events, {"event": "phase_driver_error", "phase": name, "detail": stop, "at": utc()})
                break
        statuses = [item["status"] for item in phases]
        if plan["mode"] == "diagnostic":
            run_status = "DIAGNOSTIC_RECORDED" if len(statuses) == 1 and statuses[0] in {"PASS", "FAIL", "SKIP"} and stop is None else "ERROR"
        elif plan["mode"] == "collection-preflight" and len(statuses) == 2 and statuses == ["COLLECTION_PASS", "COLLECTION_PASS"] and stop is None:
            run_status = "COLLECTION_PASS"
        elif plan["mode"] == "collection-preflight":
            run_status = "ERROR" if "ERROR" in statuses or stop is not None else "UNRUN"
        elif len(statuses) == 3 and statuses == ["PASS", "PASS", "PASS"] and stop is None:
            run_status = "PASS"
        elif "FAIL" in statuses:
            run_status = "FAIL"
        elif "ERROR" in statuses or stop is not None:
            run_status = "ERROR"
        elif "SKIP" in statuses:
            run_status = "SKIP"
        else:
            run_status = "UNRUN"
        summary = {"schema": "policyos.e02.c104.local_root_driver_run.v2", "case_id": plan["case_id"],
                   "plan": str(plan_path.relative_to(R)), "plan_sha256": file_sha(plan_path), "source": plan["source"],
                   "mode": plan["mode"], "product_result": "UNADJUDICATED_DIAGNOSTIC",
                   "run_status": run_status,
                   "phases": [{"phase_id": p["phase_id"], "status": p["status"], "pid": p["monitor"].get("pid"),
                               "return_code": p["monitor"].get("return_code"), "process_group_gone": p["monitor"].get("process_group_gone"),
                               "receipt": str((case / "phases" / p["phase_id"] / "phase-receipt.json").relative_to(R)),
                               "receipt_sha256": file_sha(case / "phases" / p["phase_id"] / "phase-receipt.json")} for p in phases],
                   "unrun": [x for x in plan["phase_order"] if x not in {p["phase_id"] for p in phases}],
                   "stop_reason": stop, "overlay_retained_for_explicit_audit_and_cleanup": True,
                   "artifacts": [file_binding(case / name) for name in ("root-input-bindings.json", "effective-monitor-bindings.json",
                                                                          "child.sb", "source-profile-freeze.json",
                                                                          "observer-overlay-source.py", "overlay-created.json",
                                                                          "events.jsonl") if (case / name).is_file()],
                   "cleanup_performed": False, "G_acceptance": False, "closure_ids": []}
        save_new(case / "run-summary.json", summary)
        print(json.dumps({"run": str(case.relative_to(R)), "summary": summary}, sort_keys=True))
        return 0 if run_status in {"PASS", "COLLECTION_PASS", "DIAGNOSTIC_RECORDED"} else 2
    finally:
        # Restore only this coordinator process environment. Never auto-clean the source overlay.
        restore_environment(old_env)


def audit(run_dir: Path) -> int:
    need(run_dir.is_absolute() and run_dir.parent == D and run_dir.is_dir() and not run_dir.is_symlink()
         and run_dir.resolve().parent == D.resolve(), "run directory must be a regular direct child of retained D")
    summary_path = run_dir / "run-summary.json"
    need(summary_path.is_file() and not summary_path.is_symlink(), "run summary is unavailable")
    summary = json.loads(summary_path.read_text())
    plan_path = repo_path(summary["plan"])
    need(plan_path.parent == PKG and plan_path.is_file() and not plan_path.is_symlink(), "run summary plan is outside the driver packet")
    plan = json.loads(plan_path.read_text())
    plan["_runtime_binding"] = {"path": str(summary["plan"]), "sha256": summary["plan_sha256"]}
    monitor, _native, guard_module = apis()
    problems = []
    verified_outputs: dict[str, dict[str, Any]] = {}
    if (file_sha(plan_path) != summary.get("plan_sha256") or plan.get("case_id") != summary.get("case_id")
            or plan.get("mode") != summary.get("mode")):
        problems.append({"check": "plan_binding", "problem": "run summary does not bind its plan and case"})
    expected_phase_order = plan.get("phase_order", ["phase-a", "phase-b", "phase-c"])
    phase_ids = [row.get("phase_id") for row in summary.get("phases", [])]
    if phase_ids != expected_phase_order[:len(phase_ids)] or summary.get("unrun") != expected_phase_order[len(phase_ids):]:
        problems.append({"check": "phase_order", "phase_ids": phase_ids, "unrun": summary.get("unrun")})
    statuses = [row.get("status") for row in summary.get("phases", [])]
    if summary.get("mode") == "diagnostic":
        expected_run_status = "DIAGNOSTIC_RECORDED" if len(statuses) == 1 and statuses[0] in {"PASS", "FAIL", "SKIP"} and summary.get("stop_reason") is None else "ERROR"
    elif summary.get("mode") == "collection-preflight" and len(statuses) == 2 and statuses == ["COLLECTION_PASS", "COLLECTION_PASS"] and summary.get("stop_reason") is None:
        expected_run_status = "COLLECTION_PASS"
    elif summary.get("mode") == "collection-preflight":
        expected_run_status = "ERROR" if "ERROR" in statuses or summary.get("stop_reason") is not None else "UNRUN"
    elif len(statuses) == 3 and statuses == ["PASS", "PASS", "PASS"] and summary.get("stop_reason") is None:
        expected_run_status = "PASS"
    elif "FAIL" in statuses:
        expected_run_status = "FAIL"
    elif "ERROR" in statuses or summary.get("stop_reason") is not None:
        expected_run_status = "ERROR"
    elif "SKIP" in statuses:
        expected_run_status = "SKIP"
    else:
        expected_run_status = "UNRUN"
    if summary.get("run_status") != expected_run_status:
        problems.append({"check": "run_status", "expected": expected_run_status, "actual": summary.get("run_status")})
    try:
        need(summary.get("source") == plan.get("source"), "run source differs from prepared source")
        artifact_names = {Path(item["path"]).name for item in summary.get("artifacts", [])}
        required_artifacts = {"root-input-bindings.json", "child.sb",
                              "source-profile-freeze.json", "observer-overlay-source.py", "overlay-created.json", "events.jsonl"}
        need(required_artifacts <= artifact_names, {"required run artifact is missing": required_artifacts - artifact_names})
        for binding in summary.get("artifacts", []):
            checked = verify_binding(binding)
            verified_outputs[checked["path"]] = checked
        root_inputs = json.loads((run_dir / "root-input-bindings.json").read_text())
        need(root_inputs.get("root_live", {}).get("path") == str(LIVE.relative_to(R))
             and root_inputs.get("root_live", {}).get("sha256") == plan["root_live_sha256"]
             and root_inputs.get("root_source_frame") == plan["source_frame"],
             "root input references differ from the admitted Root snapshot")
        for binding in root_inputs.values():
            checked = verify_binding(binding)
            verified_outputs[checked["path"]] = checked
        sandbox_expected = ("(version 1)\n(allow default)\n(deny file-write*)\n(allow file-write* (subpath "
                            + json.dumps(str(run_dir)) + "))\n(allow file-write* (literal \"/dev/null\"))\n"
                            + plan["sandbox"]["fragment"]).encode()
        if digest(sandbox_expected) != file_sha(run_dir / "child.sb"):
            raise Hold("applied sandbox file differs from the frozen network/production/write policy")
    except Exception as exc:
        problems.append({"check": "run_artifact_readback", "error": f"{type(exc).__name__}: {exc}"})
    try:
        check_live(plan, monitor, guard_module)
    except Exception as exc:
        problems.append({"check": "source_guard_and_pins", "error": f"{type(exc).__name__}: {exc}"})
    created_path = run_dir / "overlay-created.json"
    try:
        need(created_path.is_file() and not created_path.is_symlink(), "overlay creation receipt is unavailable")
        created = json.loads(created_path.read_text())
        created_binding = file_binding(created_path)
        verified_outputs[created_binding["path"]] = created_binding
        overlay = check_overlay(plan["overlay"]["sha256"], {"device": created["device"], "inode": created["inode"]})
    except Exception as exc:
        overlay = None
        problems.append({"check": "overlay_identity", "error": f"{type(exc).__name__}: {exc}"})
    results = []
    groups_gone = True
    accounted_phase_dirs: set[str] = set()
    for phase in summary["phases"]:
        path = repo_path(phase["receipt"])
        try:
            need(path.parent.parent == run_dir / "phases", "phase receipt escaped its admitted case")
            accounted_phase_dirs.add(path.parent.name)
            need(file_sha(path) == phase.get("receipt_sha256"), "phase receipt changed after run summary")
            row = json.loads(path.read_text())
            need(row.get("source") == plan["source"] and row.get("phase_id") == phase["phase_id"], "phase receipt source or id differs")
            if summary.get("mode") == "collection-preflight":
                argv = row.get("invocation", {}).get("argv", [])
                expected_selectors = configured_phase_selectors(plan, phase["phase_id"])
                need(row.get("execution_mode") == "collection-only" and row.get("product_result") == "UNRUN"
                     and row.get("status") in {"COLLECTION_PASS", "ERROR"}
                     and row.get("invocation", {}).get("collection_only") is True
                     and row.get("invocation", {}).get("selectors") == expected_selectors
                     and isinstance(argv, list) and "--collect-only" in argv,
                     {"preflight phase was not a collection-only execution": phase["phase_id"]})
                if row.get("status") == "COLLECTION_PASS":
                    need(bool(row.get("readset", {}).get("qualified"))
                         and len(row.get("readset", {}).get("selection_diagnostics", [])) == 1,
                         {"preflight PASS lacks reconciled selected-item identity evidence": phase["phase_id"]})
            elif phase["phase_id"] in {"phase-a", "phase-b"}:
                need(row.get("invocation", {}).get("collection_only") is False
                     and row.get("invocation", {}).get("selectors") == configured_phase_selectors(plan, phase["phase_id"]),
                     {"runtime phase was not an executing pytest invocation": phase["phase_id"]})
            phase_receipt_binding = file_binding(path)
            verified_outputs[phase_receipt_binding["path"]] = phase_receipt_binding
            pid = row["monitor"].get("pid")
            live_group = bool(pid and monitor.process_group_exists(pid))
            result_gone = ((pid is None and row["monitor"].get("complete") is True)
                           or (pid is not None and not live_group and row["monitor"].get("process_group_gone") is True))
            groups_gone &= result_gone
            bindings = list(row.get("outputs", {}).get("deciding_files", []))
            for key in ("stdout_path", "stderr_path", "process_tree"):
                candidate = row.get("outputs", {}).get(key, {})
                if candidate.get("path"):
                    bindings.append(candidate)
                elif pid is not None:
                    problems.append({"check": "required_monitor_output", "phase": phase["phase_id"], "name": key, "problem": "missing for started command"})
            if pid is not None and row.get("monitor", {}).get("sample_count", 0) < 1:
                problems.append({"check": "resource_samples", "phase": phase["phase_id"], "problem": "started command has no process-tree sample"})
            for binding in bindings:
                try:
                    checked = verify_binding(binding)
                    verified_outputs[checked["path"]] = checked
                except Exception as exc:
                    problems.append({"check": "deciding_output_readback", "phase": phase["phase_id"], "binding": binding,
                                    "error": f"{type(exc).__name__}: {exc}"})
            results.append({"phase_id": phase["phase_id"], "status": row["status"], "pid": pid,
                            "return_code": row["monitor"].get("return_code"),
                            "process_group_still_exists": live_group, "process_group_exit_established": result_gone,
                            "receipt": str(path.relative_to(R)), "receipt_sha256": file_sha(path)})
        except Exception as exc:
            groups_gone = False
            problems.append({"check": "phase_receipt", "phase": phase["phase_id"], "error": f"{type(exc).__name__}: {exc}"})
    phases_root = run_dir / "phases"
    if phases_root.is_dir():
        for phase_dir in sorted(path for path in phases_root.iterdir() if path.is_dir()):
            if phase_dir.name in accounted_phase_dirs:
                continue
            result_path = phase_dir / "monitor-result.json"
            if not result_path.is_file():
                if (phase_dir / "invocation.json").exists():
                    groups_gone = False
                    problems.append({"check": "unaccounted_phase_directory", "phase": phase_dir.name,
                                     "problem": "invocation exists without monitor result; started process state is not established"})
                continue
            try:
                result = json.loads(result_path.read_text())
                pid = result.get("pid")
                live_group = bool(pid and monitor.process_group_exists(pid))
                result_gone = ((pid is None and result.get("complete") is True)
                               or (pid is not None and not live_group and result.get("process_group_gone") is True))
                groups_gone &= result_gone
                if not result_gone:
                    problems.append({"check": "unaccounted_phase_process", "phase": phase_dir.name,
                                     "pid": pid, "process_group_still_exists": live_group})
                problems.append({"check": "unaccounted_phase_directory", "phase": phase_dir.name,
                                 "problem": "monitor result exists but no phase receipt; deciding outputs need manual review"})
                binding = file_binding(result_path)
                verified_outputs[binding["path"]] = binding
            except Exception as exc:
                groups_gone = False
                problems.append({"check": "unaccounted_phase_monitor_result", "phase": phase_dir.name,
                                 "error": f"{type(exc).__name__}: {exc}"})
    events_binding = file_binding(run_dir / "events.jsonl")
    verified_outputs[events_binding["path"]] = events_binding
    report = {"schema": "policyos.e02.c104.local_root_driver_audit.v2", "at": utc(), "case_id": summary["case_id"],
              "mode": summary.get("mode"),
              "product_result": "UNADJUDICATED_DIAGNOSTIC",
              "source": summary["source"], "phases": results, "overlay": overlay, "all_started_groups_gone": groups_gone,
              "verified_outputs": list(verified_outputs.values()), "problems": problems,
              "cleanup_allowed": not problems and groups_gone and overlay is not None,
              "G_acceptance": False, "closure_ids": []}
    for path in (summary_path, plan_path):
        binding = file_binding(path)
        if binding["path"] not in verified_outputs:
            verified_outputs[binding["path"]] = binding
    report["verified_outputs"] = list(verified_outputs.values())
    if report["cleanup_allowed"]:
        try:
            report["cleanup_process_proof"] = c104_cleanup_gate.derive_cleanup_proof(
                summary, read_cleanup_phase_evidence(run_dir, summary, plan), report,
                file_binding(summary_path), file_binding(plan_path),
                monitor.process_group_exists, process_pid_is_live,
            )
        except Exception as exc:
            report["problems"].append({
                "check": "cleanup_process_set_reconciliation",
                "error": f"{type(exc).__name__}: {exc}",
            })
            report["cleanup_allowed"] = False
    save_new(run_dir / "audit-readback.json", report)
    print(json.dumps({"audit": str((run_dir / "audit-readback.json").relative_to(R)), "sha256": file_sha(run_dir / "audit-readback.json"),
                      "cleanup_allowed": report["cleanup_allowed"], "problems": problems}, sort_keys=True))
    return 0 if report["cleanup_allowed"] else 2


def read_cleanup_phase_evidence(run_dir: Path, summary: dict[str, Any], plan: dict[str, Any]) -> list[dict[str, Any]]:
    """Read phase, monitor, process-tree, and child receipts from current bytes."""
    phase_rows = summary.get("phases")
    need(isinstance(phase_rows, list), "run summary phase list is malformed")
    phase_ids = [row.get("phase_id") for row in phase_rows if isinstance(row, dict)]
    need(phase_ids == list(c104_cleanup_gate.PHASE_ORDER[:len(phase_ids)]),
         "run summary phase IDs are not the exact started prefix")
    phases_root = run_dir / "phases"
    need(phases_root.is_dir() and not phases_root.is_symlink(), "phase root is unavailable or unsafe")
    entries = list(phases_root.iterdir())
    need(all(path.is_dir() and not path.is_symlink() for path in entries),
         "phase root contains a non-directory or symlink entry")
    need(sorted(path.name for path in entries) == sorted(phase_ids),
         "on-disk phase directories differ from the run summary")
    expected_names = {
        "invocation.json": {str((phases_root / phase_id / "invocation.json")) for phase_id in phase_ids},
        "monitor-result.json": {str((phases_root / phase_id / "monitor-result.json")) for phase_id in phase_ids},
        "phase-receipt.json": {str((phases_root / phase_id / "phase-receipt.json")) for phase_id in phase_ids},
    }
    for name, expected_paths in expected_names.items():
        observed_paths = {str(path) for path in phases_root.rglob(name) if path.is_file() or path.is_symlink()}
        need(observed_paths == expected_paths,
             {"recursive command receipt inventory differs from the exact phase set": name,
              "expected": sorted(expected_paths), "observed": sorted(observed_paths)})

    evidence: list[dict[str, Any]] = []
    for summary_row in phase_rows:
        phase_id = summary_row["phase_id"]
        phase_dir = phases_root / phase_id
        expected_receipt = phase_dir / "phase-receipt.json"
        expected_rel = str(expected_receipt.relative_to(R))
        need(summary_row.get("receipt") == expected_rel,
             {"summary phase receipt path differs from the exact phase directory": phase_id})
        need(expected_receipt.is_file() and not expected_receipt.is_symlink(),
             {"phase receipt is unavailable": phase_id})
        phase_receipt_binding = file_binding(expected_receipt)
        need(phase_receipt_binding["sha256"] == summary_row.get("receipt_sha256"),
             {"phase receipt hash differs from run summary": phase_id})
        phase_receipt = json.loads(expected_receipt.read_text())

        invocation_path = phase_dir / "invocation.json"
        monitor_path = phase_dir / "monitor-result.json"
        need(invocation_path.is_file() and not invocation_path.is_symlink()
             and monitor_path.is_file() and not monitor_path.is_symlink(),
             {"phase invocation or monitor result is unavailable": phase_id})
        invocation_binding = file_binding(invocation_path)
        monitor_result_binding = file_binding(monitor_path)
        invocation = json.loads(invocation_path.read_text())
        monitor_result = json.loads(monitor_path.read_text())
        need(invocation == phase_receipt.get("invocation"),
             {"phase invocation differs from its hash-bound receipt": phase_id})
        expected_selectors = configured_phase_selectors(plan, phase_id)
        expected_collection_only = plan.get("mode") == "collection-preflight"
        need(invocation.get("selectors") == expected_selectors
             and invocation.get("collection_only") is expected_collection_only,
             {"phase invocation selectors/mode differ from the admitted plan": phase_id})

        declared_observers = phase_receipt.get("readset", {}).get("receipts")
        need(isinstance(declared_observers, list), {"phase observer receipt list is malformed": phase_id})
        observer_receipts = []
        for declared in declared_observers:
            need(isinstance(declared, dict), {"observer receipt binding is malformed": phase_id})
            observer_path = repo_path(str(declared.get("path", "")))
            observer_root = phase_dir / "observer"
            need(observer_root.is_dir() and not observer_root.is_symlink()
                 and observer_path.parent == observer_root
                 and observer_path.name == f"source-observer-{declared.get('pid')}.json",
                 {"observer receipt escaped its exact phase directory": phase_id})
            binding = file_binding(observer_path)
            need(binding["bytes"] == declared.get("bytes") and binding["sha256"] == declared.get("sha256"),
                 {"observer receipt bytes differ from the phase receipt": phase_id})
            value = json.loads(observer_path.read_text())
            observer_receipts.append({"binding": binding, "value": value})

        declared_diagnostics = phase_receipt.get("readset", {}).get("selection_diagnostics")
        need(isinstance(declared_diagnostics, list), {"selection diagnostic binding list is malformed": phase_id})
        selection_diagnostics = []
        for declared in declared_diagnostics:
            need(isinstance(declared, dict), {"selection diagnostic binding is malformed": phase_id})
            diagnostic_path = repo_path(str(declared.get("path", "")))
            observer_root = phase_dir / "observer"
            need(observer_root.is_dir() and not observer_root.is_symlink()
                 and diagnostic_path.parent == observer_root
                 and diagnostic_path.name == f"selection-diagnostic-{declared.get('pid')}.json",
                 {"selection diagnostic escaped its exact phase directory": phase_id})
            binding = file_binding(diagnostic_path)
            need(binding["bytes"] == declared.get("bytes") and binding["sha256"] == declared.get("sha256"),
                 {"selection diagnostic bytes differ from the phase receipt": phase_id})
            deciding = phase_receipt.get("outputs", {}).get("deciding_files", [])
            need(any(isinstance(item, dict) and item.get("path") == binding["path"]
                     and item.get("bytes") == binding["bytes"] and item.get("sha256") == binding["sha256"]
                     and item.get("kind") == "selection-diagnostic" for item in deciding),
                 {"selection diagnostic is absent from deciding output inventory": phase_id})
            value = json.loads(diagnostic_path.read_text())
            process = value.get("process", {})
            validate_observer_source_binding(summary.get("source"), value.get("source"))
            need(process.get("pid") == declared.get("pid")
                 and value.get("schema") == "policyos.e02.c104.collection_identity_diagnostic.v1",
                 {"selection diagnostic source/PID/schema changed": phase_id})
            selection_diagnostics.append({"binding": binding, "value": value})

        if expected_selectors:
            rechecked = read_observers(phase_dir / "observer", summary["source"]["head"],
                                       summary["source"]["tree"], plan["overlay"]["sha256"],
                                       monitor_result.get("pid"), expected_selectors,
                                       collection_only=expected_collection_only)
            declared_readset = phase_receipt.get("readset", {})
            need(rechecked.get("receipts") == declared_readset.get("receipts")
                 and rechecked.get("selection_diagnostics") == declared_diagnostics
                 and rechecked.get("problems") == declared_readset.get("problems"),
                 {"cleanup-time selected item diagnostics differ from the hash-bound phase receipt": phase_id,
                  "qualified": rechecked.get("qualified"), "problems": rechecked.get("problems")})

        process_tree_meta = phase_receipt.get("outputs", {}).get("process_tree", {})
        process_tree_binding = None
        process_tree_samples = []
        if isinstance(process_tree_meta, dict) and process_tree_meta.get("path"):
            process_tree_binding = verify_binding(process_tree_meta)
            tree_path = repo_path(process_tree_binding["path"])
            need(tree_path == phase_dir / "monitor" / "process-tree.jsonl"
                 and tree_path.parent.is_dir() and not tree_path.parent.is_symlink(),
                 {"process-tree path differs from the retained supervisor phase directory": phase_id})
            for line_number, line in enumerate(tree_path.read_text().splitlines(), start=1):
                try:
                    process_tree_samples.append(json.loads(line))
                except json.JSONDecodeError as exc:
                    raise Hold({"process-tree receipt is malformed": phase_id, "line": line_number, "error": str(exc)}) from exc

        child_receipts = []
        if phase_id == "phase-c" and monitor_result.get("pid") is not None:
            phase_c = phase_receipt.get("phase_c")
            need(isinstance(phase_c, dict) and isinstance(phase_c.get("child_checks"), list),
                 "started Phase C lacks child check rows")
            phase_c_root = phase_dir / "phase-c"
            need(phase_c_root.is_dir() and not phase_c_root.is_symlink(), "Phase C output root is unavailable or unsafe")
            for check in phase_c["child_checks"]:
                need(isinstance(check, dict) and isinstance(check.get("receipt_file"), dict),
                     "Phase C child receipt binding is malformed")
                binding = verify_binding(check["receipt_file"])
                child_path = repo_path(binding["path"])
                need(child_path.name == "receipt.json" and child_path.parent.parent == phase_c_root
                     and child_path.parent.is_dir() and not child_path.parent.is_symlink()
                     and child_path.parent.name == check.get("case"),
                     "Phase C child receipt escaped its exact case directory")
                child_receipts.append({"binding": binding, "value": json.loads(child_path.read_text())})

        evidence.append({
            "phase_id": phase_id,
            "phase_receipt_binding": phase_receipt_binding,
            "phase_receipt": phase_receipt,
            "invocation_binding": invocation_binding,
            "monitor_result_binding": monitor_result_binding,
            "monitor_result": monitor_result,
            "process_tree_binding": process_tree_binding,
            "process_tree_samples": process_tree_samples,
            "observer_receipts": observer_receipts,
            "selection_diagnostics": selection_diagnostics,
            "child_receipts": child_receipts,
        })
    return evidence


def process_pid_is_live(pid: int) -> bool:
    """Return true unless the current host proves the exact PID absent."""
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError as exc:
        if exc.errno == errno.ESRCH:
            return False
        raise Hold({"cannot establish process PID state": pid, "errno": exc.errno}) from exc
    return True


def cleanup(run_dir: Path) -> int:
    need(run_dir.is_absolute() and run_dir.parent == D and run_dir.is_dir() and not run_dir.is_symlink()
         and run_dir.resolve().parent == D.resolve(), "run directory must be a regular direct child of retained D")
    report_path = run_dir / "audit-readback.json"
    need(report_path.is_file() and not report_path.is_symlink(), "run audit before explicit cleanup")
    report = json.loads(report_path.read_text())
    summary_path = run_dir / "run-summary.json"
    need(summary_path.is_file() and not summary_path.is_symlink(), "run summary is unavailable")
    summary = json.loads(summary_path.read_text())
    summary_binding = file_binding(summary_path)
    plan_path = repo_path(summary["plan"])
    need(plan_path.parent == PKG and plan_path.is_file() and not plan_path.is_symlink(), "run summary plan is outside the driver packet")
    need(file_sha(plan_path) == summary.get("plan_sha256"), "run summary plan hash differs")
    plan = json.loads(plan_path.read_text())
    plan["_runtime_binding"] = {"path": str(summary["plan"]), "sha256": summary["plan_sha256"]}
    plan_binding = file_binding(plan_path)
    need(report.get("case_id") == summary.get("case_id") and report.get("source") == summary.get("source"),
         "audit report is not bound to the current run summary")
    monitor, _native, guard_module = apis()
    phase_evidence = read_cleanup_phase_evidence(run_dir, summary, plan)
    try:
        process_proof = c104_cleanup_gate.derive_cleanup_proof(
            summary, phase_evidence, report, summary_binding, plan_binding,
            monitor.process_group_exists, process_pid_is_live,
        )
    except c104_cleanup_gate.CleanupGateError as exc:
        raise Hold({"cleanup process evidence did not reconcile": str(exc)}) from exc
    for binding in report.get("verified_outputs", []):
        verify_binding(binding)
    created_path = run_dir / "overlay-created.json"
    need(created_path.is_file() and not created_path.is_symlink(), "overlay creation receipt is unavailable")
    created = json.loads(created_path.read_text())
    need(created.get("path") == OVERLAY_REL and created.get("preimage_absent") is True
         and created.get("created_exclusive") is True
         and created.get("sha256") == plan["overlay"]["sha256"],
         "overlay creation receipt differs from the exact admitted overlay")
    before = check_live(plan, monitor, guard_module)
    check_overlay(plan["overlay"]["sha256"], {"device": created["device"], "inode": created["inode"]})
    # Recheck the source and every observed PID/group immediately before the
    # only atomic move. Audit flags are not consulted for this final admission.
    try:
        final_proof = c104_cleanup_gate.derive_cleanup_proof(
            summary, read_cleanup_phase_evidence(run_dir, summary, plan), report,
            file_binding(summary_path), file_binding(plan_path),
            monitor.process_group_exists, process_pid_is_live,
        )
    except c104_cleanup_gate.CleanupGateError as exc:
        raise Hold({"cleanup final process recheck failed": str(exc)}) from exc
    need(final_proof["observed_pids"] == process_proof["observed_pids"]
         and final_proof["observed_process_group_ids"] == process_proof["observed_process_group_ids"],
         "started/observed process set changed during cleanup admission")
    check_overlay(plan["overlay"]["sha256"], {"device": created["device"], "inode": created["inode"]})
    retained_path = run_dir / "retained-stack-source-observer.py"
    need(not os.path.lexists(retained_path), "preservation destination already exists")
    os.rename(OVERLAY, retained_path)
    need(not os.path.lexists(OVERLAY), "overlay removal readback failed")
    after = check_live(plan, monitor, guard_module)
    need(after == before, "Root guard changed during overlay cleanup")
    for binding in report.get("verified_outputs", []):
        verify_binding(binding)
    result = {"schema": "policyos.e02.c104.local_root_driver_cleanup.v1", "at": utc(), "removed_only": OVERLAY_REL,
              "sha256": plan["overlay"]["sha256"], "overlay_absent_after": True, "root_guard_before": before,
              "root_guard_after": after, "audit_sha256": file_sha(report_path), "other_outputs_preserved": True,
              "process_proof": final_proof,
              "G_acceptance": False, "closure_ids": []}
    retained = file_binding(retained_path)
    st = retained_path.stat()
    need(st.st_dev == created["device"] and st.st_ino == created["inode"]
         and retained["sha256"] == plan["overlay"]["sha256"], "retained overlay bytes/inode differ")
    result.update({"move_action": "os.rename", "retained_overlay": retained,
                   "retained_device": st.st_dev, "retained_inode": st.st_ino,
                   "removed_only_scope": "canonical pathname; original bytes retained"})
    save_new(run_dir / "cleanup-readback.json", result)
    print(json.dumps({"cleanup": str((run_dir / "cleanup-readback.json").relative_to(R)), "sha256": file_sha(run_dir / "cleanup-readback.json")}, sort_keys=True))
    return 0


def record_error(args: argparse.Namespace, exc: Exception) -> dict[str, Any]:
    detail: dict[str, Any] = {"status": "ERROR", "product_result": "UNRUN" if args.action == "prepare" else "UNADJUDICATED_DIAGNOSTIC", "action": args.action,
                              "exception_type": type(exc).__name__, "at": utc(), "detail": str(exc),
                              "traceback": "".join(traceback.format_exception(exc)),
                              "G_acceptance": False, "closure_ids": []}
    revision = None
    if args.action == "prepare":
        revision = args.revision
    elif args.action in {"run", "preflight"}:
        revision = args.plan.stem.rsplit("-", 1)[-1]
        if args.plan.is_file() and not args.plan.is_symlink():
            detail["plan"] = str(args.plan)
            try:
                detail["plan_sha256"] = file_sha(args.plan)
            except Exception as digest_error:
                detail["plan_hash_error"] = f"{type(digest_error).__name__}: {digest_error}"
    if revision and re.fullmatch(r"r[0-9]+", revision):
        if args.action == "prepare":
            error_name = f"prepare-{args.mode}-error-{revision}.json"
        elif args.action == "preflight":
            error_name = f"preflight-error-{revision}.json"
        else:
            error_name = f"run-error-{revision}.json"
        path = PKG / error_name
        try:
            save_new(path, detail)
            detail["receipt"] = str(path.relative_to(R))
            detail["receipt_sha256"] = file_sha(path)
        except FileExistsError:
            detail["receipt"] = "existing append-only error receipt preserved"
        except Exception as receipt_error:
            detail["receipt_write_error"] = f"{type(receipt_error).__name__}: {receipt_error}"
    return detail


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="action", required=True)
    prep = sub.add_parser("prepare", help="bind fresh Root source, environment, and resources; no tests or overlay")
    prep.add_argument("--head", required=True)
    prep.add_argument("--tree", required=True)
    prep.add_argument("--revision", required=True)
    prep.add_argument("--mode", choices=("diagnostic",), required=True)
    prep.add_argument("--release-receipt", type=Path, required=True)
    run = sub.add_parser("run", help="Root-only one exact stdlib A five-second-stack diagnostic")
    run.add_argument("--plan", type=Path, required=True)
    audit_cmd = sub.add_parser("audit", help="read back deciding outputs and source custody")
    audit_cmd.add_argument("--run-dir", type=Path, required=True)
    clean = sub.add_parser("cleanup", help="explicitly remove only the exact overlay after a passing audit")
    clean.add_argument("--run-dir", type=Path, required=True)
    args = parser.parse_args()
    try:
        if args.action == "prepare":
            return prepare(args)
        if args.action == "run":
            return execute(args.plan, "diagnostic")
        if args.action == "audit":
            return audit(args.run_dir)
        return cleanup(args.run_dir)
    except Exception as exc:
        detail = record_error(args, exc)
        print(json.dumps(detail, sort_keys=True), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
