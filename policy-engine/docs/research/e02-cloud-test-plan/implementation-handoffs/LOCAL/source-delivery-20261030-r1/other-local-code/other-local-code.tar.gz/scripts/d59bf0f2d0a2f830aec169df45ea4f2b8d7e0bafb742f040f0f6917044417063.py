"""Root-only scoped canonical-owner rendering after reviewed R3 composition.

This script is authored but UNRUN by the RAW-only worker. It imports the real
architecture owner (which imports product Markdown helpers), so only Root may
execute it. It never installs output or collects global deep-import edges.
"""
from __future__ import annotations

import argparse
import difflib
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos')
PRODUCT = ROOT / 'policy-engine'
HERE = Path(__file__).resolve().parent
sha = lambda payload: hashlib.sha256(payload).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--output-root', type=Path, required=True)
    args = parser.parse_args()
    target = args.output_root.resolve()
    target.relative_to(ROOT / 'LOCAL/raw/e02-execution-20261027')
    if target.exists():
        raise SystemExit('Use a fresh retained RAW output root')
    pins = json.loads((HERE / 'owner-pins.json').read_text())
    for name, digest in pins['owner_and_baseline_sha256'].items():
        if sha((ROOT / name).read_bytes()) != digest:
            raise SystemExit(f'Owner/baseline pin changed; requalify before staging: {name}')
    # Root has composed the source packet; all source postimages must be actual.
    packet = ROOT / pins['source_packet_manifest']
    if sha(packet.read_bytes()) != pins['source_packet_manifest_sha256']:
        raise SystemExit('Source packet manifest drift')
    manifest = json.loads(packet.read_text())
    for item in manifest['files']:
        if sha((ROOT / item['path']).read_bytes()) != item['post_sha256']:
            raise SystemExit(f'Reviewed R3 source not installed exactly: {item["path"]}')
    sys.path.insert(0, str(PRODUCT))
    from tools.devx.architecture import guardrails as owner

    baseline = json.loads(owner.DEFAULT_PUBLIC_JSON.read_text())
    policies = owner._parse_public_surface(owner.DEFAULT_PUBLIC_MANIFEST)
    families = owner._parse_public_generated_artifact_families(owner.DEFAULT_PUBLIC_MANIFEST)
    inventory = []
    for record in baseline['packages']:
        fields = dict(record)
        fields['entrypoints'] = tuple(owner.SupportedEntrypointInventory(**row) for row in fields['entrypoints'])
        inventory.append(owner.PackageInventory(**fields))
    # No candidate is written unless the same canonical renderer reproduces the
    # complete baseline format. Outside Foundry, retained entries are not remeasured.
    if owner.render_public_surface_json(inventory, generated_artifact_families=families) != owner.DEFAULT_PUBLIC_JSON.read_text():
        raise SystemExit('Canonical public JSON baseline round-trip differs')
    if owner.render_public_surface_markdown(inventory) != owner.DEFAULT_PUBLIC_MD.read_text():
        raise SystemExit('Canonical public Markdown baseline round-trip differs')
    selected = [policy for policy in policies if policy.module in {'polisyos.foundry', 'polisyos.fabric'}]
    if len(selected) != 2 or sum(len(policy.supported_entrypoints) for policy in selected) != 21:
        raise SystemExit('Reviewed Foundry/Fabric policy scope changed')
    refreshed = owner.build_public_surface_inventory(selected)
    compile_entry = next(row for package in refreshed for row in package.entrypoints if row.module == 'polisyos.foundry.compile')
    if compile_entry.export_resolution.get('complete') is not True or 'replay_method_program_graph' not in compile_entry.exports:
        raise SystemExit('New facade export is not source-established by canonical owner')
    refreshed_by_module = {package.module: package for package in refreshed}
    old_by_module = {package.module: package for package in inventory}
    changed_entrypoints = [
        row.module for package in refreshed for row in package.entrypoints
        if row != next(old for old in old_by_module[package.module].entrypoints if old.module == row.module)
    ]
    inventory = [refreshed_by_module.get(row.module, row) for row in inventory]
    candidates = {
        'architecture/public_surface/inventory.json': owner.render_public_surface_json(inventory, generated_artifact_families=families),
        'docs/reference/public-surface.md': owner.render_public_surface_markdown(inventory),
    }
    # This separately registered reference has actual C57/C60 registry drift.
    # Render it through its real owner and stage its exact diff for Root review.
    generated = owner.render_generated_artifacts_markdown(owner._parse_generated_artifacts(owner.DEFAULT_GENERATED_MANIFEST))
    generated_baseline = owner.DEFAULT_GENERATED_MD.read_text()
    generated_diff = ''.join(difflib.unified_diff(
        generated_baseline.splitlines(keepends=True), generated.splitlines(keepends=True),
        fromfile='a/policy-engine/docs/reference/generated-artifacts.md',
        tofile='b/policy-engine/docs/reference/generated-artifacts.md',
    ))
    attribution = json.loads((HERE / 'generated-reference-attribution.json').read_text())
    candidates['docs/reference/generated-artifacts.md'] = generated
    target.mkdir(parents=True)
    outputs = []
    for relative, content in candidates.items():
        destination = target / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(content)
        original = (PRODUCT / relative).read_bytes()
        outputs.append({'path': 'policy-engine/' + relative, 'before_sha256': sha(original), 'candidate_sha256': sha(content.encode()), 'changed': original != content.encode(), 'staged_path': str(destination.relative_to(ROOT))})
    (target / 'generated-reference.diff').write_text(generated_diff)
    receipt = {
        'scope': 'Actual canonical owner, existing Foundry12+Fabric9 entrypoints; other public records preserved, not remeasured. Separately stage actual C57/C60 generated-reference drift. No full guardrail/generated freshness verdict.',
        'source_packet_manifest_sha256': pins['source_packet_manifest_sha256'],
        'entrypoint_denominator': sum(len(package.entrypoints) for package in refreshed),
        'generated_reference_attribution': attribution,
        'generated_reference_diff_sha256': sha(generated_diff.encode()),
        'changed_entrypoints': changed_entrypoints,
        'outputs': outputs,
        'compile_exports': list(compile_entry.exports),
        'compile_export_resolution': compile_entry.export_resolution,
        'canonical_install': 'UNRUN: Root must inspect and apply only changed candidates, then rebind exact installed outputs.',
    }
    (target / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'outputs': outputs, 'changed_entrypoints': changed_entrypoints}, indent=2))


if __name__ == '__main__':
    main()
