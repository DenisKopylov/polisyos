"""Task-private R5 observer overlay; copy only for the admitted local run.

This module intentionally imports only the standard library at import time.
It is not product code and is not installed in the checkout by this packet.
"""

from __future__ import annotations

import atexit
import hashlib
import importlib
import importlib.util
import io
import json
import os
import subprocess
import sys
import threading
import time
from pathlib import Path
from types import CodeType, FrameType, ModuleType
from typing import Any


_ROOT = Path(os.environ.get("E02_C104_ROOT", "")).resolve()
_OBS = Path(os.environ.get("E02_C104_OBSERVATION_DIR", "")).resolve()
_HEAD = os.environ.get("E02_C104_EXPECTED_HEAD", "")
_TREE = os.environ.get("E02_C104_EXPECTED_TREE", "")
_PHASE = os.environ.get("E02_C104_PHASE", "")
_TRANSPORT = "tests.unit.scientist.orchestration.engine.runner.decimal_worker_transport"
_PREPARED = "policy-engine/tests/unit/scientist/orchestration/engine/test_prepared_b_removal_controls.py"
_TYPED_TEST = "policy-engine/tests/unit/scientist/orchestration/engine/runner/test_serialization_e02.py"
_OVERLAY = "policy-engine/tests/_helpers/r2_source_observer.py"
_SOURCE_PREFIXES = ("policy-engine/src/", "policy-engine/tests/", "policy-engine/tools/")

_EXPECTED = {
    "polisyos.scientist.orchestration.engine.runner._activity_worker:run_node_in_worker_sync",
    "polisyos.scientist.orchestration.engine.runner._activity_worker:run_node_in_worker",
    "polisyos.scientist.orchestration.engine.runner.serialization:deserialize_state",
    "polisyos.scientist.orchestration.engine.runner.serialization:serialize_outcome",
    "polisyos.scientist.orchestration.engine.registry:discover_nodes",
    "polisyos.scientist.orchestration.engine.retry:execute_with_retry_async",
    "polisyos.scientist.orchestration.engine.retry:_execute_with_timeout_process",
    f"{_TRANSPORT}:execute_decimal_worker",
    f"{_TRANSPORT}:execute_decimal_worker_without_budget_tag",
    f"{_TRANSPORT}:DecimalTransportNode.execute",
}
_PHASE_SELECTORS = {
    "typed-worker": {
        f"{_TYPED_TEST}::test_real_worker_process_consumes_state_and_emits_exact_typed_outcome[stdlib]",
        f"{_TYPED_TEST}::test_real_worker_process_consumes_state_and_emits_exact_typed_outcome[orjson]",
    },
    "prepared-removal": {
        f"{_PREPARED}::test_branch_isolation_removal_leaks_to_real_parallel_sibling",
        f"{_PREPARED}::test_merge_operation_removal_is_red_for_direct_and_executor_replay",
        f"{_PREPARED}::test_replay_proof_removal_admits_stale_real_cache_to_fresh_reader",
        f"{_PREPARED}::test_current_wire_schema_removal_accepts_unknown_version_with_markers",
        f"{_PREPARED}::test_typed_decimal_refusal_survives_actual_worker_and_marker_removal",
        f"{_PREPARED}::test_worker_merge_conflict_removal_changes_real_typed_receiver",
    },
}


def _canonical_selector(item: Any, root: Path, pytest_root: Path) -> dict[str, Any]:
    """Bind a selected item to its exact source file and executable function."""
    nodeid = getattr(item, "nodeid", None)
    if not isinstance(nodeid, str):
        raise RuntimeError("C104 collected item has no textual pytest node ID")
    file_locator, separator, node_suffix = nodeid.partition("::")
    if not separator or not file_locator or not node_suffix:
        raise RuntimeError(f"C104 collected item has a malformed pytest node ID: {nodeid!r}")

    item_path = Path(item.path).resolve()
    pytest_root = Path(pytest_root).resolve()
    node_path = Path(file_locator)
    if not node_path.is_absolute():
        node_path = pytest_root / node_path
    if node_path.resolve() != item_path:
        raise RuntimeError("C104 pytest node file locator differs from the collected item's path")

    repo_root = Path(root).resolve()
    tests_root = (repo_root / "policy-engine" / "tests").resolve()
    try:
        relative = item_path.relative_to(tests_root)
    except ValueError as exc:
        raise RuntimeError("C104 selected item is outside the admitted tests tree") from exc
    if relative.suffix != ".py":
        raise RuntimeError("C104 selected item does not resolve to a Python source file")

    module = getattr(item, "module", None)
    module_name = getattr(module, "__name__", None)
    module_origin = getattr(module, "__file__", None)
    if not isinstance(module_name, str) or not module_name:
        raise RuntimeError("C104 pytest item module label is unavailable")
    if not module_origin or Path(module_origin).resolve() != item_path:
        raise RuntimeError("C104 pytest item module origin differs from its exact collected source")

    function = getattr(item, "obj", None)
    code = getattr(function, "__code__", None)
    if not isinstance(code, CodeType):
        raise RuntimeError("C104 selected pytest item has no Python CodeType function")
    code_path = Path(code.co_filename).resolve()
    if code_path != item_path:
        raise RuntimeError("C104 selected function code filename differs from its collected source")
    actual_item_name = getattr(item, "name", None)
    if actual_item_name != node_suffix.rsplit("::", 1)[-1]:
        raise RuntimeError("C104 pytest item name differs from its exact node suffix")
    function_name = node_suffix.rsplit("::", 1)[-1].split("[", 1)[0]
    if code.co_name != function_name:
        raise RuntimeError("C104 selected function code name differs from its exact node suffix")
    repo_path = item_path.relative_to(repo_root).as_posix()
    return {
        "canonical_selector": f"{repo_path}::{node_suffix}",
        "source_path": repo_path,
        "node_suffix": node_suffix,
        "item_name": actual_item_name,
        "module_label": module_name,
        "module_origin": module_origin,
        "function_module_label": getattr(function, "__module__", None),
        "function_code_filename": code.co_filename,
        "function_code_name": code.co_name,
        "function_code_qualname": code.co_qualname,
        "function_code_firstlineno": code.co_firstlineno,
        "function_is_code_type": True,
    }


def _diagnostic_value(value: Any) -> str | None:
    if isinstance(value, str):
        return value
    if isinstance(value, Path):
        return str(value)
    return None


def _diagnostic_attr(value: Any, name: str) -> tuple[Any, str | None]:
    try:
        return getattr(value, name), None
    except Exception as exc:
        return None, f"{type(exc).__name__}: {exc}"


def _selection_row(item: Any, root: Path, pytest_root: Path) -> dict[str, Any]:
    """Capture actual pytest item attributes without trusting module labels."""
    nodeid, nodeid_error = _diagnostic_attr(item, "nodeid")
    item_path, item_path_error = _diagnostic_attr(item, "path")
    module, module_error = _diagnostic_attr(item, "module")
    row: dict[str, Any] = {"nodeid": _diagnostic_value(nodeid)}
    row["item_path_raw"] = _diagnostic_value(item_path)
    module_label, module_label_error = _diagnostic_attr(module, "__name__")
    module_file, module_file_error = _diagnostic_attr(module, "__file__")
    function, function_error = _diagnostic_attr(item, "obj")
    function_module_label, function_module_error = _diagnostic_attr(function, "__module__")
    item_name, item_name_error = _diagnostic_attr(item, "name")
    original_name, original_name_error = _diagnostic_attr(item, "originalname")
    code, code_error = _diagnostic_attr(function, "__code__")
    row["module_label"] = _diagnostic_value(module_label)
    row["module_file_raw"] = _diagnostic_value(module_file)
    row["function_module_label"] = _diagnostic_value(function_module_label)
    row["item_name"] = _diagnostic_value(item_name)
    row["original_name"] = _diagnostic_value(original_name)
    row["attribute_errors"] = {
        key: error for key, error in {
            "nodeid": nodeid_error, "item_path": item_path_error, "module": module_error,
            "module_label": module_label_error, "module_file": module_file_error,
            "function": function_error, "function_module_label": function_module_error,
            "item_name": item_name_error, "original_name": original_name_error,
            "function_code": code_error,
        }.items() if error is not None
    }
    row["function_is_code_type"] = isinstance(code, CodeType)
    if isinstance(code, CodeType):
        row.update({
            "function_code_filename_raw": code.co_filename,
            "function_code_name": code.co_name,
            "function_code_qualname": code.co_qualname,
            "function_code_firstlineno": code.co_firstlineno,
        })
    repo_root = Path(root).resolve()
    for raw_key, rel_key in (
        ("item_path_raw", "item_path_repo_relative"),
        ("module_file_raw", "module_file_repo_relative"),
        ("function_code_filename_raw", "function_code_filename_repo_relative"),
    ):
        raw_value = row.get(raw_key)
        try:
            row[rel_key] = Path(raw_value).resolve().relative_to(repo_root).as_posix() if raw_value else None
        except (OSError, RuntimeError, ValueError):
            row[rel_key] = None
    try:
        locator = row["nodeid"].partition("::")[0]
        locator_path = Path(locator)
        if not locator_path.is_absolute():
            locator_path = Path(pytest_root) / locator_path
        row["node_file_path_repo_relative"] = locator_path.resolve().relative_to(repo_root).as_posix()
    except (AttributeError, OSError, RuntimeError, ValueError, TypeError):
        row["node_file_path_repo_relative"] = None
    try:
        row["canonical_selector"] = _canonical_selector(item, root, pytest_root)["canonical_selector"]
        row["qualification_error"] = None
    except Exception as exc:
        row["canonical_selector"] = None
        row["qualification_error"] = f"{type(exc).__name__}: {exc}"
    return row

_lock = threading.RLock()
_pid = os.getpid()
_frames: dict[str, dict[str, Any]] = {}
_code_refs: dict[str, CodeType] = {}
_modules: set[tuple[str, str]] = set()
_events: list[dict[str, Any]] = []
_selection_rows: list[dict[str, Any]] = []
_selection_diagnostic: Path | None = None
_flushed = False
_profile_guard = threading.local()
_original_execute: Any = None
_original_without: Any = None
_role = "observer-process"
_capture: Any = None
_previous_profile: Any = sys.getprofile()
_previous_thread_profile: Any = threading.getprofile()


def _same_code_object(actual: CodeType | None, expected: CodeType | None) -> bool:
    """Compare actual code object identity within one process only."""
    return actual is not None and expected is not None and actual is expected


def observation_path_for_pid(pid: int) -> Path:
    """Return the one configured observer receipt path for a process."""
    return _OBS / f"source-observer-{pid}.json"


def _check_environment() -> None:
    if not _ROOT.is_dir() or not _OBS.is_dir() or not _HEAD or not _TREE:
        raise RuntimeError("C104 observer environment is incomplete")
    if "E02_B_PROPERTY_REMOVAL" in os.environ:
        raise RuntimeError("C104 requires E02_B_PROPERTY_REMOVAL to be absent")
    actual_head = subprocess.check_output(
        ["git", "-C", str(_ROOT), "rev-parse", "HEAD"], text=True
    ).strip()
    actual_tree = subprocess.check_output(
        ["git", "-C", str(_ROOT), "rev-parse", "HEAD^{tree}"], text=True
    ).strip()
    if (actual_head, actual_tree) != (_HEAD, _TREE):
        raise RuntimeError(
            f"C104 source mismatch: expected {_HEAD}/{_TREE}, "
            f"observed {actual_head}/{actual_tree}"
        )


def _reset_after_fork() -> None:
    global _pid, _frames, _code_refs, _modules, _events, _selection_rows, _selection_diagnostic, _flushed
    current = os.getpid()
    if current != _pid:
        _pid = current
        _frames = {}
        _code_refs = {}
        _modules = set()
        _events = []
        _selection_rows = []
        _selection_diagnostic = None
        _flushed = False


def _inside_root(path: Path) -> bool:
    try:
        path.resolve().relative_to(_ROOT)
        return True
    except ValueError:
        return False


def _repo_relative(path: Path) -> str | None:
    try:
        rel = path.resolve().relative_to(_ROOT).as_posix()
    except ValueError:
        return None
    return rel if rel.startswith(_SOURCE_PREFIXES) else None


def _record_census(checkpoint: str) -> None:
    _reset_after_fork()
    with _lock:
        for name, module in tuple(sys.modules.items()):
            path = _module_path(module)
            rel = _repo_relative(path) if path is not None else None
            if rel is not None:
                _modules.add((name, rel))
        _events.append(
            {"event": "module_census", "checkpoint": checkpoint, "pid": os.getpid(), "time_ns": time.time_ns()}
        )


def _write_selection_diagnostic(items: list[Any], root: Path, pytest_root: Path) -> dict[str, Any]:
    """Persist real collection identities before any selector assertion can fail."""
    global _selection_rows, _selection_diagnostic
    _reset_after_fork()
    rows = [_selection_row(item, root, pytest_root) for item in items]
    identity_slots: list[tuple[dict[str, Any], str, str]] = []
    source_fields = (
        ("item_path_raw", "item_path_repo_relative", "item_source_identity"),
        ("module_file_raw", "module_file_admitted_repo_path", "module_file_source_identity"),
        ("function_code_filename_raw", "function_code_admitted_repo_path", "function_code_source_identity"),
    )
    for row in rows:
        for raw_key, rel_key, identity_key in source_fields:
            raw_path = row.get(raw_key)
            try:
                resolved = Path(raw_path).resolve()
                rel = _repo_relative(resolved)
            except (TypeError, OSError, RuntimeError):
                rel = None
            row[rel_key] = rel
            row[identity_key] = None
            if rel is not None:
                identity_slots.append((row, identity_key, rel))
    # Resolve the full selected-item/module/function union once for this
    # checkpoint; the later runtime census performs its own fresh batch.
    paths = sorted({rel for _row, _key, rel in identity_slots if rel != _OVERLAY})
    batch = _git_blob_batch(paths)
    for row, identity_key, rel in identity_slots:
        row[identity_key] = _source_identity(rel, batch)
    payload = {
        "schema": "policyos.e02.c104.collection_identity_diagnostic.v1",
        "source": {"head": _HEAD, "tree": _TREE},
        "phase": _PHASE,
        "process": {"pid": os.getpid(), "ppid": os.getppid(), "role": _role},
        "expected_file_selectors": sorted(_PHASE_SELECTORS.get(_PHASE, set())),
        "items": rows,
        "identity_rule": "resolved item path == pytest node file path == module.__file__ == function CodeType.co_filename; module labels are recorded but do not determine source identity",
    }
    data = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode() + b"\n"
    path = _OBS / f"selection-diagnostic-{os.getpid()}.json"
    with path.open("xb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    _selection_rows = rows
    _selection_diagnostic = path
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def _module_path(module: ModuleType) -> Path | None:
    spec = getattr(module, "__spec__", None)
    origin = getattr(spec, "origin", None) if spec is not None else None
    if not origin or origin in {"built-in", "frozen"}:
        origin = getattr(module, "__file__", None)
    if not origin:
        return None
    path = Path(origin)
    return path if path.is_absolute() and _inside_root(path) else None


def _profile(frame: FrameType, event: str, _arg: Any) -> None:
    _reset_after_fork()
    if event != "call" or getattr(_profile_guard, "active", False):
        return
    module = frame.f_globals.get("__name__", "")
    key = f"{module}:{frame.f_code.co_qualname}"
    if key not in _EXPECTED:
        return
    path = Path(frame.f_code.co_filename)
    rel = _repo_relative(path) if path.is_absolute() else None
    if rel is None:
        return
    code_key = f"{os.getpid()}:{id(frame.f_code)}"
    with _lock:
        _code_refs[code_key] = frame.f_code
        _frames.setdefault(
            code_key,
            {
                "pid": os.getpid(),
                "ppid": os.getppid(),
                "module": module,
                "qualname": frame.f_code.co_qualname,
                "first_line": frame.f_code.co_firstlineno,
                "observed_line": frame.f_lineno,
                "repo_path": rel,
                "is_code_type": isinstance(frame.f_code, CodeType),
                "code_object_id_process_local": id(frame.f_code),
                "call_count": 0,
                "threads": [],
            },
        )["call_count"] += 1
        row = _frames[code_key]
        ident = threading.get_ident()
        thread_row = next((item for item in row["threads"] if item["ident"] == ident), None)
        if thread_row is None:
            thread_row = {
                "ident": ident,
                "native_id": threading.get_native_id(),
                "name": threading.current_thread().name,
                "call_count": 0,
            }
            row["threads"].append(thread_row)
        thread_row["call_count"] += 1


def _resolve_qualname(module: ModuleType, qualname: str) -> Any:
    value: Any = module
    for part in qualname.split("."):
        if part == "<locals>":
            return None
        value = getattr(value, part, None)
        if value is None:
            return None
    return value


def _parse_git_batch(paths: list[str], raw: bytes) -> dict[str, dict[str, Any]]:
    """Parse exact ordered Git batch replies; reject malformed or rebound blobs."""
    stream = io.BytesIO(raw)
    results: dict[str, dict[str, Any]] = {}
    for rel in paths:
        header = stream.readline()
        if header == f"{_HEAD}:{rel} missing\n".encode():
            results[rel] = {"error": "source path absent from admitted HEAD"}
            continue
        fields = header.rstrip(b"\n").split(b" ")
        if len(fields) != 3 or not header.endswith(b"\n") or fields[1] != b"blob":
            raise RuntimeError("invalid Git batch blob header")
        oid = fields[0].decode("ascii")
        if len(oid) not in (40, 64) or any(char not in "0123456789abcdef" for char in oid):
            raise RuntimeError("invalid Git batch object ID")
        if not fields[2].isdigit():
            raise RuntimeError("invalid Git batch blob size")
        size = int(fields[2])
        data = stream.read(size)
        if len(data) != size or stream.read(1) != b"\n":
            raise RuntimeError("truncated Git batch blob or invalid delimiter")
        object_bytes = b"blob " + str(size).encode() + b"\0" + data
        actual_oid = (
            hashlib.sha1(object_bytes, usedforsecurity=False).hexdigest()
            if len(oid) == 40 else hashlib.sha256(object_bytes).hexdigest()
        )
        if actual_oid != oid:
            raise RuntimeError("Git batch blob content does not bind its object ID")
        results[rel] = {"blob": oid, "bytes": data}
    if stream.read(1):
        raise RuntimeError("unexpected trailing Git batch output")
    return results


def _git_blob_batch(paths: list[str]) -> dict[str, dict[str, Any]]:
    """Resolve the entire frozen source-path set in one read-only Git process."""
    if any(any(char in path for char in "\n\r\0") for path in paths):
        raise ValueError("source path cannot be represented in the Git batch protocol")
    if not paths:
        return {}
    requests = "".join(f"{_HEAD}:{path}\n" for path in paths).encode()
    try:
        raw = subprocess.check_output(
            ["git", "-C", str(_ROOT), "cat-file", "--batch"],
            input=requests,
            stderr=subprocess.PIPE,
        )
        return _parse_git_batch(paths, raw)
    except (OSError, subprocess.CalledProcessError, RuntimeError, ValueError) as exc:
        return {path: {"error": f"{type(exc).__name__}: {exc}"[-500:]} for path in paths}


def _source_identity(rel: str, batch: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """Compare actual local bytes against the admitted batch result, failing closed."""
    result: dict[str, Any] = {"path": rel}
    try:
        actual = (_ROOT / rel).read_bytes()
    except OSError as exc:
        return {**result, "classification": "SOURCE_ERROR", "source_error": str(exc)[-500:]}
    result.update({"actual_bytes": len(actual), "actual_sha256": hashlib.sha256(actual).hexdigest()})
    if rel == _OVERLAY:
        result["classification"] = "task-authored-observer-overlay"
        return result
    entry = batch.get(rel)
    if entry is None or "error" in entry:
        return {**result, "classification": "SOURCE_ERROR", "git_error": (entry or {}).get("error", "batch identity absent")}
    expected = entry["bytes"]
    result.update({
        "git_blob": entry["blob"],
        "git_bytes": len(expected),
        "git_sha256": hashlib.sha256(expected).hexdigest(),
        "matches_current_head": actual == expected,
        "classification": "tracked-source" if actual == expected else "SOURCE_ERROR",
    })
    return result



def _flush(reason: str) -> None:
    global _flushed
    _reset_after_fork()
    with _lock:
        if _flushed:
            return
        _flushed = True
        frame_rows = [{**row, "threads": [dict(item) for item in row["threads"]]} for row in _frames.values()]
        module_rows = [{"module": name, "path": rel} for name, rel in sorted(_modules)]
        code_refs = dict(_code_refs)
        events = list(_events)
        selection_rows = list(_selection_rows)
        selection_diagnostic = _selection_diagnostic

    paths = {row["path"] for row in module_rows}
    paths.update(row["repo_path"] for row in frame_rows)
    tracked_paths = sorted(path for path in paths if path != _OVERLAY)
    batch_started_ns = time.monotonic_ns()
    batch = _git_blob_batch(tracked_paths)
    batch_elapsed_ns = time.monotonic_ns() - batch_started_ns
    identities = {path: _source_identity(path, batch) for path in sorted(paths)}
    for row in frame_rows:
        code = code_refs.get(f"{row['pid']}:{row['code_object_id_process_local']}")
        module = sys.modules.get(row["module"])
        resolved = _resolve_qualname(module, row["qualname"]) if module is not None else None
        row["same_process_function_code_identity"] = _same_code_object(
            code, getattr(resolved, "__code__", None)
        )
        row["identity_kind"] = "in-process CodeType object identity; do not compare across PIDs"

    bounded_report = _capture.report() if _capture is not None else None
    payload = {
        "bounded_code_capture": bounded_report,
        "schema": "policyos.e02.c104.local_source_observer.v1",
        "phase": _PHASE,
        "reason": reason,
        "source": {"head": _HEAD, "tree": _TREE},
        "process": {
            "role": _role,
            "pid": os.getpid(),
            "ppid": os.getppid(),
            "python": sys.version,
            "executable": sys.executable,
            "argv": sys.argv,
            "cwd": os.getcwd(),
            "sys_path": sys.path,
            "named_controls": {
                name: os.environ.get(name)
                for name in (
                    "E02_C104_ROOT",
                    "E02_C104_EXPECTED_HEAD",
                    "E02_C104_EXPECTED_TREE",
                    "E02_C104_PHASE",
                    "E02_C104_OBSERVATION_DIR",
                    "PYTHONPYCACHEPREFIX",
                    "E02_B_PROPERTY_REMOVAL",
                )
            },
        },
        "source_identity_batch": {
            "requested_path_count": len(tracked_paths),
            "git_subprocess_count": 1 if tracked_paths else 0,
            "elapsed_ns": batch_elapsed_ns,
            "mechanism": "one git cat-file --batch; exact ordered blob framing and content/object-ID binding",
        },
        "profile_scope": "C134/C100 bounded first PY_START per CodeType across Python threads; selected authenticated starts; no complete call counts or native trace",
        "module_origins": module_rows,
        "target_code_frames": frame_rows,
        "source_identities": list(identities.values()),
        "selected_item_diagnostics": selection_rows,
        "selection_diagnostic": (
            {
                "path": str(selection_diagnostic),
                "bytes": selection_diagnostic.stat().st_size,
                "sha256": hashlib.sha256(selection_diagnostic.read_bytes()).hexdigest(),
            }
            if selection_diagnostic is not None and selection_diagnostic.is_file()
            else None
        ),
        "events": events,
        "limitations": [
            "module census is bounded to loaded in-repository source modules observed by this process",
            "code object identity is process-local; no marshal digest is used as a stable cross-run identity",
            "thread hooks observe selected Python call events after activation, not earlier calls, C/native execution, every function, or other processes",
            "one batch captures loaded source blobs in memory; resource bounds remain the separate supervisor's responsibility",
            "the native supervisor separately records process ancestry, resource samples, sandbox, stdout/stderr, JUnit and child receipts",
        ],
    }
    out = observation_path_for_pid(os.getpid())
    out.write_text(json.dumps(payload, sort_keys=True, separators=(",", ":")) + "\n", encoding="utf-8")


def _shutdown_profile(reason: str) -> None:
    """Release monitoring before normal module teardown and retain the receipt."""
    if _capture is not None:
        _capture.stop()
    _flush(reason)




def _install_profile() -> None:
    """Install the reused bounded C134/C100 owner; no Python profile hooks."""
    global _capture
    _check_environment()
    _record_census("observer-import")
    if _capture is not None:
        return
    path = Path('/Users/deniskopylov/.codex/worktrees/e02-unified-local-20261009/polisyos/LOCAL/raw/e02-execution-20261027/repairs/C104-measured-worker-harness-r1/observer/bounded_code_capture.py')
    if hashlib.sha256(path.read_bytes()).hexdigest() != '5cce83b6853a5e7bd34b0346a7af24d38479fb1801700c203ad65699edb26743':
        raise RuntimeError("bounded code owner bytes changed")
    spec = importlib.util.spec_from_file_location("_e02_c104_bounded_code_capture", path)
    if spec is None or spec.loader is None:
        raise RuntimeError("bounded code owner loader unavailable")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    data = subprocess.check_output(["git", "-C", str(_ROOT), "ls-tree", "-rz", _HEAD])
    index = {}
    for row in data.split(b"\0"):
        if not row:
            continue
        metadata, rel = row.split(b"\t", 1)
        mode, kind, blob = metadata.split(b" ")
        if kind == b"blob":
            index[os.fsdecode(rel)] = blob.decode("ascii")
    # The only overlay exemption remains the exact driver-admitted bytes.
    overlay = Path(__file__).read_bytes()
    index[_OVERLAY] = hashlib.sha1(b"blob " + str(len(overlay)).encode() + b"\0" + overlay,
                                  usedforsecurity=False).hexdigest()
    _capture = module.ActualCodeCapture(_ROOT, index, _OBS)
    def selected(code: CodeType) -> bool:
        path = Path(code.co_filename).resolve()
        for key in _EXPECTED:
            module_name, qualname = key.split(":", 1)
            prefix = _ROOT / "policy-engine" / ("src" if module_name.startswith("polisyos.") else "")
            owner = prefix / (module_name.replace(".", "/") + ".py")
            if code.co_qualname == qualname and path == owner:
                return True
        return False
    _capture.select_starts(selected, lambda frame: _profile(frame, "call", None), None)
    _capture.start()




def _load_originals() -> tuple[Any, Any, ModuleType]:
    global _original_execute, _original_without
    module = importlib.import_module(_TRANSPORT)
    if _original_execute is None:
        candidate = getattr(module, "execute_decimal_worker")
        if candidate is not wrapped_execute:
            _original_execute = candidate
    if _original_without is None:
        candidate = getattr(module, "execute_decimal_worker_without_budget_tag")
        if candidate is not wrapped_without_budget_tag:
            _original_without = candidate
    if _original_execute is None or _original_without is None:
        raise RuntimeError("C104 observer could not resolve the original worker helpers")
    return _original_execute, _original_without, module


def wrapped_execute(*args: Any, **kwargs: Any) -> Any:
    global _role
    _role = "outer-worker:execute_decimal_worker"
    _install_profile()
    execute, _without, _module = _load_originals()
    _record_census("worker-helper-imported")
    try:
        return execute(*args, **kwargs)
    finally:
        _record_census("worker-helper-return")
        _flush("worker-helper-return")


def wrapped_without_budget_tag(*args: Any, **kwargs: Any) -> Any:
    global _role
    _role = "outer-worker:execute_decimal_worker_without_budget_tag"
    _install_profile()
    _execute, without, module = _load_originals()
    _record_census("worker-helper-imported")
    current = getattr(module, "execute_decimal_worker")
    try:
        # The original mutant delegates to the ordinary helper by module global.
        # Restore only that exact binding for this child call to avoid recursion.
        module.execute_decimal_worker = _execute
        return without(*args, **kwargs)
    finally:
        module.execute_decimal_worker = current
        _record_census("worker-helper-return")
        _flush("worker-helper-return")


def pytest_sessionstart(session: Any) -> None:
    _record_census("pytest-session-start")


def pytest_collection_modifyitems(session: Any, config: Any, items: list[Any]) -> None:
    global _original_execute, _original_without
    if _PHASE not in _PHASE_SELECTORS:
        raise RuntimeError(f"unsupported C104 phase {_PHASE!r}")
    # Persist the actual item/module/function source identities before checking
    # any assumption about selectors, labels, or source ownership.
    diagnostic = _write_selection_diagnostic(items, _ROOT, Path(config.rootpath))
    _record_census("pytest-collection-items-loaded")
    actual_rows = [_canonical_selector(item, _ROOT, Path(config.rootpath)) for item in items]
    actual = [row["canonical_selector"] for row in actual_rows]
    expected = _PHASE_SELECTORS[_PHASE]
    if len(actual) != len(expected) or set(actual) != expected:
        raise RuntimeError(
            f"C104 selected file selector mismatch for {_PHASE}: "
            f"expected={sorted(expected)!r} actual={sorted(actual)!r} "
            f"identity_diagnostic={diagnostic['path']} sha256={diagnostic['sha256']}"
        )
    transport = importlib.import_module(_TRANSPORT)
    _original_execute = getattr(transport, "execute_decimal_worker")
    _original_without = getattr(transport, "execute_decimal_worker_without_budget_tag")
    transport.execute_decimal_worker = wrapped_execute
    for item in items:
        if Path(item.path).resolve() == (_ROOT / _PREPARED).resolve():
            item.module.execute_decimal_worker = wrapped_execute
            item.module.execute_decimal_worker_without_budget_tag = wrapped_without_budget_tag
    _record_census("exact-selection-and-wrapper-bindings")


def pytest_runtest_setup(item: Any) -> None:
    _record_census(f"test-setup:{item.nodeid}")


def pytest_runtest_teardown(item: Any, nextitem: Any) -> None:
    _record_census(f"test-teardown:{item.nodeid}")


def pytest_sessionfinish(session: Any, exitstatus: int) -> None:
    _record_census(f"pytest-session-finish:{exitstatus}")
    _shutdown_profile("pytest-session-finish")


_install_profile()
atexit.register(_shutdown_profile, "atexit")
